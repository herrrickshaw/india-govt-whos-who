---
doc_id: "ad6f6cced20129eb"
source_url: "https://doj.gov.in/static/uploads/2025/09/03f998baf9a893b9a7dd7753c2bfa1d1.pdf"
ministry: "Department of Justice (DoJ)"
title: "The Delhi High Court Act, 1966"
date: "2023-02-15"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f7b5427936a6d60d"
---

<!-- page 1 -->

THE DELIn

...

HIOlf

COURT ACT, J9.66

(Am' No. ?'6:bP 1()(j(i)
,

,....

An Act to provide for the constitution of a High Court for the
Dillon territory of. Delhi, for the extension of the JUriSdiction of that. High Court to the Union territory of
Himachal Pradeshand
Ior matters connected therewith.

BE it enacted by Parliament

in Hie Seventeenth

1. Short title nnd commcnccmcnt=-If)

Year -of the Republic

This Act may be called

of India as followat=-

the Dellii High Court

..

Act, 1966. :

·
(2) Section 17 shall come into force Oil such dalel .as tlle Central Governmellt
may, by notification
the Official Gazette, appoint; and the remaining provisions of this Act shall come into force at once.
.
2. Definitions-In
. (0)

"appointed

(b) "notified

this Act, unless the context otherwise

requires,-

day" means the date appointed under section 3:
order"

means

order notified

in, the 'Offlcial Gazelle.

3. High Court-(l)
As from such dates as the Central Government may, by notification
Gazette, appoint, there shall be a High Court for the Union territory of Delhi (hereinafter
the High Court of Delhi).
.'

•...•.••

.
"

..

'

in the Official
referred to as

(2) The principal scat of the High Court of Delhl shall be at Delhi or at such other place as the Presi-

<

':":":.:
~"~

':

in
..

<lent may, by notified

.~

. :;: ..':..

order,

appoint.

.

_

· . (3) Notwithstanding
anything c~))!ained in s~b.sectioll (2), the Judges and Division
Cou rt of Delhi may sit at such other place or places other thaw its principal seat as the
with the approval of the President, appoint.
. .
.

Courts of th~ High
Cheif

Justice

may,

.
31~A. ~nl:t' '._ ;.::,J ;;l;,Ir. uuces of Judges (0 be expenditure charged on Consolldatcd Fund of 'India-i-Expen,
diture in respect of the salaries and idlow:111CCS of Judges of the High Court of Delhi shall he expenditure
charged on the Consolidated
Fund of India.]·
.
.

· .,4.

I.

EXCC1 lli?1l S nlIlI
mOfl ifi l'fl,f,i?lIs(s)"bject to njli~h the provlsions of chapter V 01 Part Vlof the Constitution
C 0 r')C1 11- 1 The provisions of Chapter V of Part VI of the Constitution
. app y tothe. H19 I 1 curt
shall, in
their application
to the High .Courr of Delhi, have effect subject
the following exceptions and modifications, namely :..
.
.
.
..
.
(a) ill article 217, thc words "the Governor of the State" shall be omitted and ill relation 10 appointmcnts to be made under sub-section (2), thatarticle shall beconstrued as if the words "and, in the case

1.1.

or appointment of a Judge other than the Chief Justice, the Chief Justice of the Hi~h Court," had also
been omitted I
.
:.
.

I'

to

.:: .

"

. '.'.

.

'

.. , . ;',

'. '.

~
..-"

~

(lJ) in article 219, the refercllce to the Governor ()[ the State,
nrticlc 217. the reference 10 Ihe. Governor,
shall be {,OIlS( rued
of the Union IcnilofY ()r Uclhi I .

(c) the provisions

of article

:1

;1

and in the proviso to clause. (3) of
as n reference to the .IIIImin lsl rnlor

II

!I
!
!.

225 shall not apply I

(d) ill article 229;·I. t ;5·1%7, vide G,S,n.
~OR, dated I i-4-19G7. Gnzcttc of India, PL IJ, Sec. 3(i) p, 563.
2, 31st October, 1%6, vide Notiflcntlon No. S.O, 327), dated 27·10·1%6, Gazette of India, PI. II, Sec. 3(11), p, 29Q6 •..
:l. Inserted by Act :n of 1%9, section 2, (W.6.r. 1.10.19(9).
Sec Appcndlx J.
.
.
,

i

iI

r !l
_

I

. 11

i
;

I'

I

It
I

<!-- page 2 -->

.

•.~.~'.'=;I'~::'::"
:.- . .....

.

(i) the references
trl\tm
of \hl) Unton

.

'.

~..

to the Governor of the Slate shal! be construed as references
territory
of Delhi;
. .
.

to the admiuis •.
. .'

.

(i/) the rcfc'fences to the State Public Service Commission, tbe Lcgislatu re of the Sta~e and tl~e
Consolidated
Fuud of the State shall be conslrt!ed, respcctlvely, us. references
to the Union Public
Service Conuuission, Parliament and the Consolidated
Fund of India;
'.'
I
(c) the provisions

of ~rlick

230 shall apply subject

to the modiflcatlonsthnt->

(i) in Clause (I) thereof, for the. words "High .Collrt" ill
words "High Court for a Union territory" and for the words
other. Union- tcr~itory" shall be substituted;
(if) for Clause (2) thereof;

toth .thc 'places. ~vher~, they 'occur:, the
any Union

clause shall be substituted,

the following

territory
'.

,the

namely':-

'.

any

words

to

"(2) ·\'\There the Higli Court for a Union territory exercises ijtlr,isdiction .in relation
another
Union torritot;,' the reference in article 227 to the ntll)lini!lITutor of tit,> Union tc>rr~tory .of DolM
shaU, In retallOll to any rules, forms or tables for subordinate courts in that other Union territory,
be construed as a reference to the administrator
of that other Union territory.".
.

(2) Uctwcen the coming into force ofthis section and the appointed day, the President may, after consultation with the Chief Justice of India, appoint the Chief Justice .of tlie .High Court of Delhi and as many other
'Judges of the said High Court as he thinks fit, and any appointments
so made shall take effect as from the
api)oillled day.
. .
'.'
'. . . . . . .
'

'.

5.• Jlicistiiclioll

of riigh Court of ))c1hi-~(1) The High COII)'t ofDclhl

ttlfit'~JIlI' the time being included

ill the Uuion

dit:li~11l as, under the law in force immediately
,erritories by the High Court of Punjab.
.t

Icrrito ry of Ddhi,all

shall have, in I'CSpCct of the terrisuch original, uppclkuc nnd other juris-

before tho appointed

day, is exercisable in respect of the said

.'

..

. . .

'

..

.
.

·
(2) Nolwithstanding
anything contained in any law for the time being in force, the I ligh Court of Delh]
shall also have in respect or the s:~id tcrritorlcs ordinary t;dginal civil ju risd iction in every su it the value of which
·ellceeds ~[nlpecS ~ne lakh] "
'

. 6,

»0\"('[ (0 enrol Iegul prnctltlouers,
cle.-:-:(i) The 11igh Couri (II' l>d!li shall havelike powers to approve,
. rulrnit, enrol, remove and suspend legal practittoners, and to make rules WIth respect to them, as are, under the
. inw iuforce immediately before the appointed day, exercisable by the High Court of Punjab.
.

(.?) Th~'right ofaudience
in Ihe High Court of Delhi shall be rcpulutcd in accordance with the like prinCiI)les, as, immediately before the appointed day, are in force with TC~reC( to the right of audience in the High
nlurl

HI' Pllnjah:'

.'

.
Provided titn:t subject to any rule made or direction given by the j-ligh Court of Delhi in the exercise"
of the powers conferred by this section, any person \\')\0 immediately before the' appo inted day is an advocnr ('
entitled to practise or an attorney
entitled to act in the High Com! of Punjab sl. " :_" recognised
as an
ud vocate or an -attorney entitled to practise or net, as the: cusc may be, in the High Oourt of Deihl.
'.

. 7. Practice a~d Procedure in the Higll Court of Dclhi~Suhie~t
to Ihe provisions of this Act, the Jaw in
lilrq' iuuncd intcly IlI'fOlc Ihl'UPllIdllkti
duy with respet'llo
prnclkl! nlld proccdllri: ill tho Jligh Court nf 1'II111aIJ
NI,udl, wj~h the,nel'essary
nuulillcntious, IIPI)ly .ill relntlnn In Ih(; Illgh <;0111'1 of I>dhlllllli
~('{'lll'djllgJy thl) J figh
CIIIlII 01 1l1'lhl slurll hllVt' nil sltl'h pl}\\'('r,~ In nmke rIlJ!'~ 1\1111llnklH \\'1111 rC'!llwC'! 10 (llIrdln'
IIl1d proveduro 11I1
nrc lnuncdiutcly before lhe :~PPOilllell day (.'n·f'~is:lblc by the J Iigh .Cnlll'[
PUIl)nh III~d shal! also have powers
!(l ,llla,k(~.J'IIlc~nnd orders wlth respect 10 prucucc and procedure lor thu exercise of us nnlinary original civll
JUIIsL!Ic!WIl:
.
..
,

'.

,

i
I

or

.. '
Provided that any rules or orders which arc in force immediately before the appointed day with respect
· to practice and procedure in the High Court of Punjab shall, until varied or revoked by rules or orders made by
the High Court of Delhi, apply with the necessary modifications ill relation to practice and procedure in the
· High Court of Delhi as if made by that High Court.
.

f

I

.1
. 8. Custody of the Seal of the High Court of Delhi-The
law in force immediately before the appointed day'
. with respect to (he custody of the Seal of the High Court of Punjab shall, with the necessary' modifications,
apply with respect to the custody of the Seal of the High Court of Delhi.'
.
.

.'

!

. 9. Form of writs and other processcs=- The law in force immediately before the appointed day \\-ilh respect
10 tlfe form of writs and olher processes used, issued or aWflrded by the High Court of Punjab shall, with the
necessary modifications,
apply 'I'Iilh respect to the form of wdls anu other processes used, issued or awarded
. by the High Court of Delhi.
. .'
:.'
.
'.'
1~ Substituted by Act 37 of 1980,s. 2, for the \\'o;ds "fifty Ihousnndrupees"

I
t

I

(

,!

(w,e.f. 1-10-1980): Sec Appendix 2,
1-4910LLCJND/84

j

.

, I

._~,

_

•.• c..,·_,·

. ,-:---.--~

.~.

a
m-

f.-I'"

~,. ,,'

~~.·~-:'cc

, "-b "

!

~

",c

"

~

<!-- page 3 -->

I)l'Cl iOlls . l()- I ·1

J

. .I

(,I) Where a Sillr,le JlItl1}C of the lligh
civil jllri"dil'li(l1l
cunforrcd
by SLlb-~;l'dioll (.:)
lIt'ctlon 5 Oil thai
11ll'1l1 (II; Ille :>illgk Judge 10 1\ DivlsluuConrt
of lIwt High Court.
HI. l'mll'ls

(If ,llIcll!~'s·

or

.1

f. !

.or

.

('11l1I'1 o l' Delhi exercises ordinary original
Court, Ill! IIJ:peal i'hall lie 11·(1111Ole judg'

(1) Stlhjcd
[0. the Jlruvisi~)J!s
Sllb-Sl'~~lil)1\ (i), the law i.".r~l1TC illll~wdialcly
b$!foro,l"c ap1?uifll~'d day
1'C,lalilll' 10. tile P()\~'f(~r:lor.lllOChlcl JUSIICL',slIlglo
J,lIdges IIlIllDIVJSIClll
COllrl.s.ofthc High Court 01 1'1!I~plh.lllld
wilh 1'1"'1'1'1'1 In 1111Illil/h·nt, tllll'.t!lilry In. lilt· ('.~('n'I'HI 111'th(1~il'I"'\\IT"
shull, wllh lhe Ilt'C"S':IITY JllI,dllll'lIllnm,
apply ill II'IIUlo~\ to 1110 IlIgh ll'lHI 01 Deihl,
..

.

I I.

I'fCH.'ellllrt' n~ 10 nl'!,cal'l 10 Suprcllu' C()IIlI··--'I'I,e
I.Lw ill lilln:
iuuucdintely hLlllll\' the uppuintcd JlIY
hI IlI'PI'nl:i III IIIIl ~1I1111"111"·( '1II1.rlrt'lllll
Ihl' Iii!," ('I'ltll .. r 1'11111:11\ :lllt1,llp, I II c,1I'ps
II lid Dlvlsiun ('ourl!!
11!l'1l'I,r;ihall,
wllh Ihl~ Ilcn'·'i~llIy l1l11dlhcall'IlI~,
apply tu Wll\llllil III Iltl, IIlg11 t 11111'1(lj lJdhl.
.. ~_.:: --._'::.
lI,hlil1)'.

11. 1'!'Illl',f", r uf 1)('III'III'llhll~!i Ill/Ill Hili Illgh (:1)11]1 ill' l'II!IJlh In Ilw lligll (~Illlli fir 1)\11111 ( f) 1(.'tCl'P' II'; 11l'le.
ill.L1ler provlltcd, lhe II igh COli rt or. I'lll~al> shall, liS From the appoilllcd
day, hi! vc IHI Jll i lsd klion in respect

or lite Union territory

uf Delhi.

.

or

(2) Such procc~Jillgs pending ill the Iligh COliI'[
Punjab iuuucdiutcly
ln-lo rc Ihe appuintctl
day as are
ccrtilicd, whether before or ark!' tluu day, by the Chief Justice or lilal High Court huvingrcgard
10 the place
·lli' accrual of the cause
action ;llHI other circumstunccs 10 b~~proceed ings which ought I_O be hcnrd and decidcd by the High Court of Delhi, shall, as SOOll as may be afld s:ld! ccrtilicntion, be transferred to the High
-.CourtofDelhi.

or

,
,(J)
Notwlthstundiug
anything
contained
in sub-sections
(/) n nd (2) of tlris section and in section 5,
.. but save as hereinafter provided, the High Court of Punjab :;halll,a','l', and tile High Court c I' Delhi shall not
have, jlll:i~djction to entertain,
hear or dispose of, appeals,
applicnt ions for leave 10 appea I includ ing leave
to appca l Io the Supremo Court, applications for review and other proceedings where any such proceedings seek
any relief in respect of any order passed by the High Court of Punjab before the appointed day:
.
Provided lilal if alter UIl.\' such proceed jug" haw been rnlt:rf uincd l,y the 11igh Court of Punjab, it appears
. to the Chief Justice of that High-Courttluit
IIll'Y ought to he translc rrcd to (he High Court of Delhi.
he shall
. order that they shall be so transferred,
and such proceedings
shall thereupon
be transferred
accordingly.
(4) Any order

made

by the High Court

«(I) before;' tile appointed
of sub-secriontz):

day,

(b.l ill (Illy procc~'dj.llgs Wilh
ur sub-section
(3),

of' Punjub->-

in any proceedings

respect 10 which

transferred

Ihe Iligll

(0 the High

Cl)PI t of

Punjab

of Delhi

by virtue

jurisdiction

bv virtue
-

Court

retains

.

~hall for all purposes have cllcci, not only as an order of the High Court of Punjab, but

also as an order

made

by the High Court of Delhi.
13. High! rll appear or 10 lid in 1IHln'l'clillgs transferred 10 the nigh COI!I'( of neJhi~ Anv .person who
immediately
before the appointed
day, is an advocate rlliitled to practise or all attorney entitled 10 ad, ill lb~
High Court of Punjab, and was authorised 10 appear or to act in any proceedings tronsfcrfed
from thal High
Court to the ll igh Court of Delhi under sec: ion 12, shall have the .right to appear or [0 act, lis the case may be
in the High Courtof Delhi in relation to those proceedings.
, .'

1-1. lu({'Iprl;lntiun-For

[he pUl'pO~I.!S

or sections

12 ami

l'l,__:_ .

(0) l)Jocccdings
shall he deemed Lo be pl'lttiing in a C(I II1'1llnlit llm( court has dispose(! of all issues
be: \'.'('cnthe parties, including any issues with respect to Ihe taxation of the C(l.~tsof (he procc(.!dings and shall

include appeals, applications for leave
for revision and petitions for wrilS;

10 appeal

10 the

Supreme

Court,

appitc!lliollS

rot review, ()clition

II igh ·Courl ~hall be C!11,slt'IIl·d :.... iIIduti ioe· rl'krt'lll'('s (0 a Judge or Division CIlIi rl
anti reli.'relll'tS (0 till order made by" coui! ur a Jud~c sl1<l11 be coHstrucd
as includil1grcfcccnees to <I sOltcnce, judgment
or uecree: passed Of maJc by that court or Judge .
(h)

I di.'rclli:cs III a

lhl'l.'llf,

..~-~
_",

, ..~.

..-

<!-- page 4 -->

. I

i

(Sections 15-19)

I

· ,~ .. 5 S:I\'illir~-Save as provided in section 4, nothing
ln this Ad shall afTert the. application to ,tl,le High
·
It''f DelilY ofanv provisionsof
the Constitution
and this Act shall have effect subject to any provisrou that
· COllf
o
.,
"
I C
I·
L'
I
'I'

: lila\' be made on or after the appOilll~(l day with respect to thilt HI!.;J
g I.. y't'n"_"' rcower to make .. such .provrsron. . , .
.
.; ,..
. ~ In
'r~~ .'
-,: ....

ri

~6 pCII(llnl~ prol;;ctfhl~~ .hef'ore

ourt by allY
, ..

I,

cgts alurc or othcr aulhority

courts ·In Deihl-Ail proceedings pending immediately ·before
court ill the Union territory of Delhi in or ill relation to
such civil
Sl~it 'as is referred to in sub-section (2) of section 5 shall oil that ~a',' s[allt1lransrc~rcd
10 tl~e High COUll of D\lhi
which shall. proceed to try, hear and determine the matter as If I~ had been pending therein. ,
:.

:\ II c rqJj;oinled day in any subordinate

suhordlnatc

any

17~ Extension of the jurisdiction of the High Coilri of Dclhi-'(J)
/\~ from such dale 11<; tilt) Centml
c·rn11\en1 may, by notlficatlon In the Olllcinl Gazelle, appoint (he!'cinaftcl: referred ,10 liS the prescrlbed
jhc jurisdiction of the High Court of Delhi shall extend to the Union territory of Himachal PrJ'lesh~

f.· (2) AsJrolll ~he prescribed ~Ialc the COllrt of the Judicial Commissioner
;{ __!~_.f~~~C_I_i.~I:.
and IS hereby abolishcd : ,
..

(Jov-

date)

.I

for l limachnl Pradesh shall cease
.
. ..

~.

f . Provided that nothing ill this sub-section

'it ·servcd.

injultction

issued,

shall prejudice or nflccl the continued oper .Iinn of nnv notic:
dirl'dillll l'iVl'lI. or pro!'l'l.:dingsJakclI hefnrc tlic prescribed .elale by Ihe Court of the
for II imachn I Pradesh ubnlishod by this sub-sect ion.

.-,'lGr· .:
~Judid:\1 Commissioner
.~-.\,
:l ••....(.1) The Ili~h Court of"lklhi :;lIall have, ill respect of the IcrritPfic:: Inr tho lillH'ht:ing iJ\,:I'Ir(,'d in Ihc "nj:)11
=:':

.

·.:I..•.•.
'..~,.,
•..•.
•.•.
•.·"..:· orv (:: :
I" ,i'

:;n:::::n

~,:~:::::~h;p",

" I·
)f!

IIII. " ('/)
t.

U"' lcr Ihe I"" i'l I;" cc bur", lin lei) h"fn"
by the Court of the J udicinl Commissloner
.

(b) ordinary original civil jurisdiction
in every suit the value of which exccd
Illltwilhsfnn!ling
anything contninerl in nny low for the lime hrillJ! ill force,

"'.

s
~
\

and her

Ilnl c
01 j urisdiclion us
date; is excrcisn hie in respect of the said territories
for H lmachal Pradesh; and also·

t he prescribed

~.

1\11 pronTtiings IWllding ill IIH' Courl of the Judicial Cnnunisxiouer
·Jlrc~(.;rilll',1 clute shull slalld
It) till' .1.1 i/-(II· Court of Delhi.

..~'

Imush'fretl

l[firty thousand

for l limnchnl l'ru.lcsh

T

rupees]

..

Ill'rtlrl~ the

(,II ,An~ ordc .. made hcf, ire I he I'" crt he" ,1111o by I he Cnll' I rclerr« II,! I, su h'Ret'! I"" (41 shnll for 0 II 1''' r.
,~ : poscs have effect no! only as an order (.' .I Ht Court but also (IS 1\11 oldcr of the JIIgh Court of Delhi, . .:
.(0) Fm tht' ITlllOV:t1 or dtitlllls, il it; ht'ft"~Y (kda·rctl Ihal (he Pftl\'i~illll-;
or set"linl)~ 6 In 11 II lid I~ shall, with
the ncccssnry modifications,
apply 10 the IJigh Court 0(' Delhi ill the exercise of [uri-aliction conl'erred UPOII it
by rhis secti(llt,
.
.
.

~"I
:f~;I .
l,1 (~)r!~~~1
~~~
~1~~:;ld~';~'st~I;;dl~~~:ni~}l'~~~dl
[~li\~~°r.[f~ha~~~;~<:~ltt~\I~il~\~I;i~~~~~f1~;ic!~di~oc:~.~},SIIC~:
pending
.- ..~•.•..~;.,.,~ ..:.,~:...'..•. ,•:..,...

~'

:.'~.,!.,'

'

pending il1llll~di:\tely before the prescribed

dale in any subordinate

:

tr ..
:

.':

(7) All proceedings

-r

i

court in the Union·
~1~J'~~~~~~l~ii~~
.'j.

i"

the matter
.

as if it had been

therein,

.

.

.

..

..

(J~

'.

.

.~.:

. 18. Rule of cunsfruclio!l-(l)
Referenccs
COllrt of Punjab shall, as from the appointed
'! . to the High Court of Delhi. .

in any law in force in the Union territory of Delhi to the High
in relation (0 that Univli telfitol'.y as r\ll"'ercncc~
.
.

day, ~)e construed

(2) R~fcrences in any law in force in the Uni~n territory of lJimachal Pradesh to the High Court or.rulljao
or .In the Court of the Judicial Commissioner
f()r that tcrrit()fY shall, as from the. prescribed dale, be conslrilCd
in relalion
that Union territory as references to thc High Courl of Delhi.
.

to

. 19; [Am(!Jldlll('J/( of certaill /nil's,l Rcp('o/Nl by Ihe J?cp('(llillg (llld Am('nding ;1c/, 197·1 (56 of· 1974), 5('c(io//
? olld First Schedllle.
..
. .

__ .:.. ..-..

...

:. -..:-__:.-~

L

.'

t· .

!.

<!-- page 5 -->

J)C/ili lJigll

COlli"

Act,

[Sect ion 20- Schedule

1966

I"
Illlllclllli~~ ..'-;-(J) ,r lilly tlillkully nrlses ill givll\g clrcl:l
lh~ provisl()n~ or lhi\ AGI,
·.'. lli. ~f'll Governmenl
may, by
II"''''? r.uch l1rovi~iul\~ WI IIp\)i!\lr~
to be necessary or ex••.. ....

n~1l11l\'C

'UI\(,r

tl)

n.ulillcll

[r) .Il

lH'tlcf,

the, C~\ f~r the removal of the tlillicully.
;pcd1ell .,..
, • '.'
'..... . 2 I~vcry orll,cf ~'\1\t.lc under this seclioi; shaill~e I~hl as soon as may he; after it is made ,bcro~e each 110~ISC
.. ; 1'~lrktllll'lll wh,IIe It b, Ill. seNDII. ,ror I~ 101111.pcw!ll \If thirty ·(1;\)':1:vhkh. lnl\Y !)O CI)m\)fISctl.1I\ ;01\0 .sc~s~on

(II in tWO :;t1cci:SSIVC SC~';t911).und II, befl~rl) the 7xplry of I he ~~~s~l(?nIn-which it 13 .50 lad or tho ' SC~~HlII II".- '
or l' 1,Iy 1\ll1IlWIII!',. hllth II()\I~','<;ugrco III maKing lilly lllod,hclilion in the order or both l louscs ngicc (hut ;
: ,,1l:1(~~\I\.~r
sll(lult'
II~(;uc t'i\~~\ illlly

IHII. houuul«, 11111(.•nlt-r
be: so I hnwever;lhalllllY

·H~,I yillill" Ilft'vio\l~ly

:(.1 11'.1"

dOIH'

lI11dl·.r

thut

Hlmll 1111'11':1,1'1
cr, liuvc dl'l'I'1 Dilly ill slich 1lIild HIell rurm of
SlIdl
IllOdlhClIlIOlllll'
1111111111111:111.shall 1>0 \\'lIlIotll prcjlldlcll

order,

..

r

he or nll I' Irc~~I,
to tho validity

.:

.

..

i

I

!I
.i I

...

1'111 Ih'l \'111111''>'; III Indlllnlllll\
11)111I1'1'111'iltillll "I' IIl1i'·'IIW hi. l'l'IIIII"li~ I .. Ih.\ Ilnlnn
1111)('1111111 1111l1lt1.'hltlllllldcfll.I,Il'(
:I'I".II\II.lp~I\IIIIIIIIIlIIII'I\·, ~lI'rtllllllll',rxpilllllllllllr
two ~\'i\lij 1111111
!, I II' IItl,IIHlilllt ..d "1,1),In 1,;'1111','" III Ih,' ~ hlilln I~'II'IIIII~',III llt-Iltllllld
(il'flll" 1110 1'~pll'llllllll·1l1
h\'I 1 Yl'lIni 1111111 Ihu.
; 1!1'l'~~:'ibcd dule III rclution
10 1I1(~ Uuiou tcn llnry 01 Hlmuchu!
Pmdcsh.
IIy nnlor, IllIt"'l ~tl\~h Ittl1l11l1l1lC1J1'1 IIIHI
: ,I 'liliu'llh
(If tho luw, whether
by way or repeal 01' 1\1IIe 11'.1men I, .I\'{ IlIIIY Ill) IH~t:\'s~arv ur expedlcn; to glve
L :~;:':<:lll~ illS
the provisiClIlS or ll,lis Ad,aml thereupon every such law shall have dfcd syhjcct La the uduptutions
1I11U
. :;::".j .idilicllliOl\s
:;0 made unltl lIlleted.
repc;\\eu or amendeu hy tl compcll.:lll
Legislature
or ..other competent
:. II .t
,
. ..
.._", .. "

:.

) I

. ~ ,:,;il

1'11\11'" In 111111111III""'·
)'

~ authority .
. . rJ'lw,\C!tc:t!II(<']
It! ,

Scfl(!c/I

1kpcafed b)' tlu: Rvpeuling

and Amending

AeI, 1f)74 (56 of .1974) S{;ct/OI1 2 mil} First

..

,.

i
I

,i

!

· '(

;

I
I

'I.

.·1
·.~
· ~.

l

,, ,

· ~'r
~k. .

·~i
·

,.

..

I. .: .. '",
·~

.

_.

-2TtW? ~

,

~-

<!-- page 6 -->

-J

!

. I

THE DELHI HIGH COURT (AMENDMENT)
~,,.;r~-.7.~, ',,,",

".'

.. '

':

ACT, 1969 '.

r t.·

.

",;'
,;

(ACT No.

37 OF 1969)

......

[9th'SepiellIber,

Ail Act to amend
Ba it cnacted by Parliament

the.Delhi

High Court Act, 1966

19691

. I

i:

in the Twentieth Year of the Republic of India as follows :~

.

I, Short rille lind COliUIWJJC'rllu·nl.-(l)

"

"

This Act may be culled the Delhi High Court (Amendment)

"J

Act,

!

1%9.

;

,

;,

•. ..... (2) It shall COIl1~ intoforcc
GuieHe, appoint..
[Sections

..

as the Central Government

on such unlet

may, by notitication ill the Official
.'
,.

.'

2, 3 ami 4. 'Iucorporated ill file principal

!

'r'

Act].

I

I

5. Amcndmcnt of certain laws.--(J) III section 25 of the Punjab Courts Act, 1918, (Punjab Act V I or 1918),
as in force in the Union territory of Delhi, for the words "twenty-five thousand rupees", the weirds "fifty thou-

I
I·

sand rupees" shall be substituted.
(2) In the Himachal Pradesh (Courts) Order, 1948, in paragraphzu,
rupees", the words "fifty thousand rupees" shall be substituted.

for the words "twenty-five

r:

thousand

.

j'

6. Power of Chief Justice to transfer pending sults and proceedings (0 subordinate eouds.-The Chief Justice
.of the High Court of Delhi may transfer any snit or other proceedings which is or are pending in the High Court
immediately before the commencement of this Act and in which 110 witnesses have been examined before such
commencement to such subordinate court in the Union territory of Delhi, or, us the case may be, Himachal
Pradesh as would have jurisdiction to cntertuln such suit or proceedings had such suit or proceedings been instituted or filet! for the first lime after such commencement.
.

j,

j

"

I·

I

i',
I

ri
I.

I

I'

.----'-~_:.....
__ .~._'~ I';

': I.

I. Jst October, 1969; vide O.S.R.
Sec. 3(i), p. 629.

No. 2317. dated 23rd September,

1969, Gazelle

of India,

1969, Bxtraordlnary,

PI.B,

<!-- page 7 -->

:..
.

. APPENDJX
.""" ...

~::,..-

...

2

..

THE DELHl BlOH COURT (AMENDMENT) ACT, 1980
.

..

.

'.

-

~i !;

'.

.

, -'.7" .

, .. ~c,''-,' -

.

. ,).:-.-

.":'

(Acr No, 37 OF 1980)

. ' [2,lJd .July.

.

1980)

. ~f·.
. ;k'

~;.

,q.

An Act further to amend the Delhi l:ligh Court Act, 1966.

:

r,:,:...,. C

,

. ~; .

'

by I'nrlinmcnt

III; il cllllckd

I
.Ii .

~

.

I. Shorl 1111,nod

1980.

Gnz:!/e;::~:,:::~::~

rj .
~'~
1':1'1.

.

..,'

in the 'I'hirty-Ilrs! Year

of the l{cplIhlie

of ""Iii,

IlS

follows :..i-

00",,,,,,,,,,,,,,, •.-(/) Thi, Act may be called the Delhi High Court (A,~endmcnt; Act, tF
"
(~V,

i.:': a,

ih, Central

GJvunment

may. by

notiflcation

in the Official .

~1

flAo

). Am,.dn"nl
of Punjab Ad VI of 191H. as in fore' in II" Union tcrrltory of Dclhi.v-Jn section 25 or the
.I'o"jnb CO""" Act, 1918. as in force i nthc Uni on I erritor v of l)eJhi. r or the words "fin y thousand m pees",
the words "rupees one lakh" shall he substituted.
",-'
. . ......
. .-. - ." -,:;:j

. ,

t:·}'

.(
m.

I III' Ilil'~.
1'0"''' of Chief" J ,i,lI" 10 """,r" 1",,,11,," ,,,II< "",I I" "'·"',11""' ." ""h""I1,,' ,o"rl'. ·-The eh kr J" sllce ~l
Ilil\h Court of 1)o.:Ihi mav
suit or other
which is or nrc pending in the High Court
:i~:~
0

Ir:lIl~,rcl' lillY

111.:...

prcll·rTdill).!.~
1111,(1ill whidl. nil Willll'SqCH

IlIlJlll'diilldy
1ll'l'uro 11l~~cnlllllll'lln'lllI'lIl ill' thi~ At'l
huvc been C)o;fllllinrl\ hr,l'ore ~1H:h
\'1\111 llli'IH:tlllll'n I 10 fwdl ~lIhl)rdiflllll) court In lho Union
lerritory of Iklhlnqwollitl have .Il1l'istllllll()I\ 1(1 enter~L Illill .~lll:h ~lIil 01' prrH'l'\~dillg~hall ~lIt:h sult.ur Pl'\lI,:ci.:t1II1~'i IWL'II 111~tilull!ll or IIbl I'I)r theIIr~l'tltlll) IIlh~1' SUu"

£::~,.'~,

~ _ COllllllencement.

"- ~

~

~.

-

I

:t~

.It-

...
---~--.
"-~~
. .
' Ji.

r

~
~

.

~.

,:,-1

I
I

'.'.'

'I

.;ij

i

,c

'I
~"

,~.

Ji;-.

t$

.••••. '.

..~.~it

"

.i

. '

l

.. .., .
.~~.
.

;;

r,

..",
..

t;

~.'

~~

!~

.~

"I~.

;.

'.i

I

J ~

~~';,

.F .
g

, .

',\
l),

.

',"{
\'.

',.

.:

~':~ :~."

~.,

I

....... - .... "

:

;;~j;.,:.}1

.q.0'r:." ,

~.

GO,
W

ttl<

If;
.~:,

.

I',.· ~---------------------I.I~t

October.

....n, Sec.

1911'). "id.i G,S,R.

No. 522(E).

d ucd 6th S~ptcm')~r, 19~O, a izette

of Jniiu!

t

1,980, B_xlraordlQuY

PI .

3(i). page No. 992.

,~.

,."
