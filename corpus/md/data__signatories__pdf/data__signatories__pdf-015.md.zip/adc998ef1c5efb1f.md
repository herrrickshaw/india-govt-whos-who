---
doc_id: "adc998ef1c5efb1f"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/d44ff2aec0505d538d9f3d51eba88936.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "G.S.R. 468(E): Use of Short-Range Automotive Radar System in the 77-81 GHz band (Exemption from Licensing Requirements) Rules, 2026"
date: "2026-06-11"
pages: 9
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "093f44c654339856"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-12062026-273377
xxxGIDHxxx
CG-DL-E-12062026-273377
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 418]
No. 418]

नई ददल्ली, बृहस्ट्पजतिार, िून 11, 2026/ज्येष्ठ 21, 1948
NEW DELHI, THURSDAY, JUNE 11, 2026/JYAISTHA 21, 1948

संचार मंत्रालय
(दूरसंचार जिभाग)
अजधसूचना
नई ददल्ली, 11 िून, 2026
सा.का.जन. 468(अ).— के न्‍दरीय सरकार, भारतीय तार अजधजनयम, 1885 (1885 का 13) की धारा 4 और 7 और भारतीय
बेतार तारयांजत्रकी अजधजनयम, 1933 (1933 का 17) की धारा 4 और 10 द्वारा प्रदत्त िजियों का प्रयोग करते हुए,
जनम्नजलजखत जनयम बनाती है, अर्ाात:् 1.

संजिप्त नाम और प्रारं भ— (1) इन जनयमों का संजिप्त नाम 77-81 गीगाहर्ट्जा बैंड में िॉर्ा रेंि ऑर्ोमोटर्ि रडार

जसस्ट्र्म का उपयोग (लाइसेंससंग अपेिाओं से छू र्) जनयम, 2026 है।
(2)

ये रािपत्र में उनके प्रकािन की तारीख से प्रिृत्त होंगे।

2.

लागू होना— ये 77-81 गीगाहर्ट्जा फ़्रीक्वेंसी बैंड के संबंध में लागू होंगे।

3.

पटरभाषाएँ— (1) इन जनयमों में, िब तक दक संदभा से अन्‍दयर्ा अपेजित न हो,-

(क)

"समतुल्य आइसोरोजपक जिदकरजणत िजि" से कु ल िह िजि अजभप्रेत है जिसे एंर्ीना के सबसे मिबूत बीम की

ददिा में िास्ट्तजिक स्रोत के समान जसग्नल िजि देने के जलए एक काल्पजनक आइसोरोजपक एंर्ीना द्वारा जिकीणा करना होगा;
4207 GI/2026

(1)

<!-- page 2 -->

2
(ख)

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

"हस्ट्तिेप" से एक रे जडयो संचार प्रणाली में जसग्नल प्राप्त होने पर उत्सिान, जिदकरण या प्रेरण के एक या उनके

संयोिन के कारण अिांजछत ऊिाा का प्रभाि अजभप्रेत है, िो दकसी भी प्रदिान जगरािर् की िानकारी, गलत व्याख्या या उसके
ना जमलने से प्रकर् होता है िो इस तरह की अिांजछत ऊिाा न होने पर प्राप्त की िा सकती र्ी;
(ग)

"अंतरााष्ट्रीय मानकों" से अंतरााष्ट्रीय दूरसंचार संघ, यूरोपीय दूरसंचार मानक संस्ट्र्ान, अमेटरकी राष्ट्रीय मानक संस्ट्र्ान

और गैर-आयनीकरण जिदकरण संरिण पर अंतरााष्ट्रीय आयोग िैसे अंतरााष्ट्रीय संगठनों द्वारा प्रकाजित मानक अजभप्रेत है;
(घ)

"पोर्ाल" से ऐसा पोर्ाल अजभप्रेत है जिसे के न्‍दरीय सरकार दूरसंचार जिभाग, भारत सरकार की िेबसाइर् पर इस

संबंध में जनर्दाष्ट करे;
(ङ)

"िॉर्ा रें ि ऑर्ोमोटर्ि रडार जसस्ट्र्म" से रे जडयोलोके िन उद्देश्यों के जलए िाहन पर स्ट्र्ाजपत 77-81 गीगाहर्ट्िा

फ्रीक्वेंसी बैंड में काम करने िाला एक रे जडयो उपकरण अजभप्रेत है; तर्ा
(च)

"िाहनों" में यात्री कार, बस, रक, र्ैक्सी के रूप में प्रयुक्त जिमान, रे ल रोड़ लोकोमोटर्ि, रेन कार, मोनोरे ल या

राम, जनमााण िाहन, मोर्रसाइदकल, स्ट्कू र्र और भारत के िेत्रीय िल के भीतर संचाजलत नाि या पोत िाजमल हैं, ककं तु ये
इन्‍दहीं तक सीजमत नहीं होंगे।
(2)

उन िब्दों और पदों के , िो इसमें प्रयुक्त है और पटरभाजषत नहीं है ककं तु भारतीय तार अजधजनयम, 1885 (1885

का 13), भारतीय बेतार तारयांजत्रकी अजधजनयम, 1933 (1933 का 17), उि अजधजनयमों के अधीन बनाए गए जनयमों या
के न्‍दरीय सरकार की राष्ट्रीय आिृजत्त आिंर्न योिना में पटरभाजषत है, िही अर्ा होंगे िो उन्‍दहें क्रमिः उि अजधजनयमों, जनयम
या उि योिना में ददए गए हैं।
4.

लाइसेंससंग अपेिा से छू र्- (1) भारतीय बेतार तारयांजत्रकी (कब्िा) जनयम, 1965 में जनजहत दकसी बात के होते

हुए भी, उप-जनयम (2) से (5) में जिजनर्दाष्ट ितों को पूरा करने के अध्यधीन (क)

दकसी िाहन पर स्ट्र्ाजपत और 77-81 गीगाहर्ट्िा फ्रीक्वेंसी बैंड में संचाजलत िॉर्ा रें ि ऑर्ोमोटर्ि रडार जसस्ट्र्म की

स्ट्र्ापना, रखरखाि या कायाकरण को रे जडयो फ्रीक्वेंसी की आिंर्न दकए जबना, गैर-हस्ट्तिेप, गैर-संरिण और गैर-अनन्‍दय आधार
पर अनुमजत दी िाएगी; और
(ख)

दकसी भी व्यजि द्वारा इस तरह के िॉर्ा रें ि ऑर्ोमोटर्ि रडार जसस्ट्र्म को रखने या दकसी भी डीलर द्वारा इसकी

जबक्री करने या दकराए पर लेने के जलए दकसी लाइसेंस की अपेिा नहीं होगी।
(2)

िॉर्ा रें ि ऑर्ोमोटर्ि रडार जसस्ट्र्म नीचे दी गई सारणी में जिजनदष्ट पैरामीर्रों के अनुरूप होगा सारणी

दफ़्रक्वेंसी बैंड

#अजधकतम औसत

* अजधकतम उच्चतम

अजधकतम उत्सिान

अजधकतम अिांजछत
उत्सिान सीमा

समतुल्य आइसोरोजपक
जिदकरजणत िजि

समतुल्य आइसोरोजपक
जिदकरजणत िजि

बैंडजिड्र्

(1)

(2)

(3)

(4)

(5)

77-81 गीगाहर्ट्जा

50 डीबीएम

55 डीबीएम

4 गीगाहर्ट्जा

-30 डीबीएम/मेगाहर्ट्िा

# औसत जडर्ेक्र्र का उपयोग करके 1 मेगाहर्ट्िा टरजॉल्यूिन बैंडजिड्र् में मापा िाना है और कु ल उत्सिान बैंडजिड्र् पर
एकीकृ त दकया िाना है।
* पूरे उत्सिान बैंडजिड्र् पर पीक जडर्ेक्र्र का उपयोग करके 1 मेगाहर्ट्िा टरजॉल्यूिन बैंडजिड्र् में मापा िाना है, उत्सिान
बैंडजिड्र् पर एकीकृ त नहीं दकया िाएगा।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

(3)

भारत का रािपत्र : असाधारण

3

उप-जनयम (1) के खंड (क) के अधीन अनुमजत और खंड (ख) के अधीन छू र्, प्रत्येक प्रकार के िॉर्ा रें ि ऑर्ोमोटर्ि

रडार जसस्ट्र्म के जलए इन जनयमों के सार् संलग्न अनुसूची में जनधााटरत रूप में पोर्ाल पर इस संबंध में आिेदन करके प्राप्त
की िाएगी:
परं तु यह दक ऐसे दकसी आिेदन की अपेिा नहीं होगी िब इस तरह की मंिूरी पहले संगत उपकरण प्रकार के जलए
दी गई हो और पोर्ाल पर प्रकाजित की गई हो।
(4)

िार्ारेंि ऑर्ोमेटर्ि रडार जसस्ट्र्म ऐसे मानकों के अनुरूप होगा जिन्‍दहें भारतीय मानक ब्यूरो या के न्‍दरीय सरकार या

दोनों द्वारा अजधसूजचत दकया िाए:
परं तु यह दक िहां ऐसे कोई मानक प्रकाजित नहीं दकए गए हैं, िॉर्ा रें ि ऑर्ोमोटर्ि रडार जसस्ट्र्म संगत अंतरराष्ट्रीय
मानकों के अनुरूप होगा।
(5)

भारतीय तार अजधजनयम, 1885 और भारतीय बेतार तारयांजत्रकी अजधजनयम, 1933 के अधीन अनुज्ञजप्तधारक

दकसी व्यजि से इस आिय की कोई भी सूचना प्राप्त होने पर दक उसकी अनुज्ञजप्तधारी प्रणाली को इन जनयमों के अधीन छू र्
प्राप्त दकसी अन्‍दय रे जडयो उपकरण से हाजनकारक हस्ट्तिेप प्राप्त हो रहा है, के न्‍दरीय सरकार या ऐसे अजधकारी, िो इस संबंध
में उसके द्वारा प्राजधकृ त दकया िाए, ऐसे छू र् प्राप्त रे जडयो उपस्ट्करों के प्रयोिा को िीघ्रता से और ऐसी समय-सीमा के भीतर,
िैसा दक ऐसे जनदेि में जनर्दाष्ट दकया िाए, हस्ट्तिेप से बचने के उपाय (िैसे दक उपकरणों का स्ट्र्ानांतरण, इसकी िजि में
कमी और जनर्दाष्ट प्रकार के एंर्ीना का उपयोग) करने के जनदेि दे सकता है।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY
अनुसच
ू ी
[जनयम 4(3) देख]ें
उपकरण प्रकार अनुमोदन के जलए आिेदन का रूप*

खंड क: आिेदक का जििरण
1.

उपकरण प्रकार अनुमोदन के जलए

:

आिेदन करने िाली जिजनमााण अजभकरण का नाम
2.

जनमााण अजभकरण का डाक पता

:

3.

प्रकार अनुमोदन के जलए आिेदन करने िाली

:

भारतीय अजभकरण का नाम और पता
4.

उत्पाद का नाम और उत्पाद

:

पहचान (मॉडल नंबर आदद)

खंड ख: रांसमीर्र का जििरण
5.

दफ़्रक्वेंसी रें ि

:

6.

प्रीसेर् जस्ट्िच करने योग्य चैनलों की संख्या

:

7.

िॉयस/डेर्ा/र्ेलीजििन चैनलों की संख्या

:

(मल्र्ी-चैनल उपकरण के मामले में)
8.

Tx-Rx चैनल पृर्क्करण

:

(डु प्लेक्स/मल्र्ी-चैनल उपकरण के मामले में)
9.

आसन्न चैनल पृर्क्करण

:

(मल्र्ी-चैनल उपकरण के मामले में)
10.

दफ्रक्िेंसी जस्ट्र्रता

:

11.

नकली/हामोजनक जिदकरण

:

(क)

कै टरयर दबाि

:

(कै टरयर सप्रेस्ट्सड जसस्ट्र्म के मामले में)
(ख)

अिांजछत साइड बैंड दबाि

:

(ससंगल साइड बैंड जसस्ट्र्म के मामले में)
(ग)

दूसरा हामोजनक जिदकरण

:

(घ)

तीसरा हामोजनक जिदकरण

:

12.

अजधकतम दफ्रक्िेंसी जिचलन:

13.

उत्सिान की रीजत

:

14.

उत्सिान की बैंडजिड्र्

:

[PART II—SEC. 3(i)]

<!-- page 5 -->

[भाग II—खण्ड 3(i)]
15.

परीिण स्ट्िर जिचलन

16.

बेस बैंड दफ्रक्िेंसी

भारत का रािपत्र : असाधारण

5

:
:

(मल्र्ी-चैनल उपकरण के मामले में)
17.

अपेजित मॉड्यूलेिन का प्रकार

:

18.

प्री-एम्फे जसजस

:

19.

पािर आउर्पुर् (एंर्ीना के इनपुर् पर)

:

20.

कोई भी अन्‍दय िानकारी

:

खंड ग: टरसीिरों का जििरण
21.

दफ़्रक्वेंसी रें ि

:

22.

टरसेप्िन की रीजत

:

23.

टरसीिर की नकली प्रजतदक्रया

:

24.

संिेदनिीलता

:

25.

दफ़्रक्वेंसी जस्ट्र्रता

:

26.

(क) प्रभािी िोर तापमान

:

(ख) न्‍दयूनतम इनपुर् स्ट्तर

:

27.

मध्यिती दफ़्रक्वेंसी

:

28.

डी-िोर

:

29.

चयनात्मकता

:

30.

कोई अन्‍दय जिजिजष्र्यां

:

आिेदक के हस्ट्तािर
स्ट्र्ान:
तारीख:
*टर्प्पण: प्रत्येक प्रकार के उपकरण के जलए अलग-अलग आिेदन प्रस्ट्तुत दकया िाना चाजहए

[फा. सं. आर-11014/03/2025-एनर्ी]
देिेंर कु मार राय, संयि
ु सजचि

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)
NOTIFICATION
New Delhi, the 11th June, 2026
G.S.R. 468(E).— In exercise of the powers conferred by sections 4 and 7 of the Indian Telegraph Act, 1885 (13 of
1885) and sections 4 and 10 of the Indian Wireless Telegraphy Act, 1933 (17 of 1933), the Central Government hereby
makes the following rules, namely:—
1.
Short title and commencement.—(1) These rules may be called the Use of Short-Range Automotive
Radar System in the 77-81 GHz band (Exemption from Licensing Requirements) Rules, 2026.
(2)

They shall come into force on the date of their publication in the Official Gazette.

2.

Application.—They shall apply in respect of the 77-81 GHz frequency band.

3.

Definitions.—(1) In these rules, unless the context otherwise requires,—

(a)
“equivalent isotropic radiated power” means the total power that would have to be radiated by a
hypothetical isotropic antenna to give the same signal strength as the actual source in the direction of the strongest beam of
the antenna;
(b)
“interference” means the effect of unwanted energy due to one or a combination of emissions, radiations
or induction on reception in a radio communication system, manifested by any performance degradation, misinterpretation
or loss of information that could have been extracted in the absence of such unwanted energy;
(c)
“international standards” mean standards published by international organisations such as the International
Telecommunications Union, the European Telecommunications Standards Institute, the American National Standards
Institute and the International Commission on Non-Ionising Radiation Protection;
(d)
“portal” means such portal as the Central Government may specify in this behalf on the website of the
Department of Telecommunications, Government of India;
(e)
“Short-Range Automotive Radar System” means a radio equipment operating in the 77-81 GHz frequency
band installed on a vehicle for radiolocation purposes; and
(f)
"vehicles" include, but are not limited to, passenger cars, buses, trucks, aircraft while taxing, railroad train
locomotives, train cars, monorails or trams, construction vehicles, motorcycles, scooters and boats or ships operated within
territorial waters of India.
(2)
Words and expressions used in these rules and not defined but defined in the Indian Telegraph Act, 1885
(13 of 1885), the Indian Wireless Telegraphy Act, 1933 (17 of 1933), the rules made under the said Acts or the National
Frequency Allocation Plan of the Central Government shall have the same meanings respectively assigned to them in those
Acts, the said rules or the said plan.
4.
Exemption from licensing requirement.—(1) Notwithstanding anything contained in the Indian
Wireless Telegraphy (Possession) Rules, 1965, subject to fulfilment of the conditions specified in sub-rules (2) to (5),—
(a)
the establishment, maintenance or working of a Short-Range Automotive Radar System installed on a
vehicle and operating in the 77–81 GHz frequency band, shall be permitted without assignment of radio frequency, on noninterference, non-protection and non-exclusive basis; and
(b)
no license shall be required for possession of such Short-Range Automotive Radar System by any person
or its sale or hire by any dealer.
(2)
The Short-Range Automotive Radar System shall conform to the parameters specified in the following
Table, namely:—
TABLE
Frequency band

(1)
77-81 GHz

#

Maximum average
equivalent isotropic
radiated power

*Maximum peak
equivalent isotropic
radiated power

Maximum emission Maximum unwanted
bandwidth

(2)

(3)

(4)

50 dBm

55 dBm

4 GHz

emissions limit
(5)
-30 dBm/MHz

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

# To be measured over 1 MHz resolution bandwidth using average detector and integrated over the total emission
bandwidth.
* To be measured over 1 MHz resolution bandwidth using peak detector over the entire emission bandwidth, shall
not be integrated over the emission bandwidth.
(3)
Permission referred to in clause (a) of sub-rule (1) and exemption referred to in clause (b) of sub-rule (1)
shall be sought for each equipment type of Short-Range Automotive Radar System by making an application in this behalf
on the portal in the form set out in the Schedule annexed to these rules:
Provided that no such application shall be required where such approval has previously been accorded for
the similar equipment type and is published on the portal.
(4)
The Short-Range Automotive Radar System shall be in conformity with such standards as may be notified
by the Bureau of Indian Standards or the Central Government or both:
Provided that where no such standards have been published, the Short-Range Automotive Radar System
shall conform to relevant international standards.
(5)
On receipt of any information from a person, who holds a license under the Indian Telegraph Act, 1885
and the Indian Wireless Telegraphy Act, 1933 that his licensed system is receiving harmful interference from any other radio
equipment exempted under these rules, the Central Government or such officer as may be authorised by it in this behalf may
direct the user of such exempted radio equipment to expeditiously and not later than such timeframe as may be specified in
such direction, carry out measures to avoid interference, such as relocation of equipment, reduction in its power and use of
antennae of specified type.

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY
SCHEDULE
[See rule 4(3)]
Form of application for equipment type approval*
Section A: Details of applicant
1.

Name of manufacturing agency applying

:

for equipment type approval
2.

Postal address of manufacturing agency

:

3.

Name and address of Indian agency

:

applying for the type approval
4.

Name of product and the product

:

identification (model number etc.)
Section B: Details of transmitter
5.

Frequency range

:

6.

Number of preset switchable channels

:

7.

Number of voice/data/television channels

:

(In case of multi-channel equipment)
8.

Tx-Rx channel separation

:

(In case of duplex/multi-channel equipment)
9.

Adjacent channel separation

:

(In case of multi-channel equipment)
10.

Frequency stability

:

11.

Spurious/harmonic radiations

:

(a)

Carrier suppression

:

(In case of carrier suppressed systems)
(b)

Unwanted side band suppression

:

(In case of single side band systems)
(c)

2nd harmonic radiations

:

(d)

3rd harmonic radiations

:

12.

Maximum frequency deviation:

13.

Mode of emission

:

14.

Bandwidth of emission

:

15.

Test tone deviation

:

16.

Base band frequency

:

(In case of multi-channel equipment)
17.

Type of modulation to be required

:

18.

Pre-emphasis

:

19.

Power output (At the input of antenna)

:

20.

Any other information

:

[PART II—SEC. 3(i)]

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

9

भारत का रािपत्र : असाधारण

Section C: Details of receivers
21.

Frequency range

:

22.

Mode of reception

:

23.

Spurious response of receiver

:

24.

Sensitivity

:

25.

Frequency stability

:

26.

(a) Effective noise temperature

:

(b) Threshold input level

:

27.

Intermediate frequency

:

28.

De-emphasis

:

29.

Selectivity

:

30.

Any other particulars

:

Signature of the applicant
Place:
Date:
*Note: Separate application should be submitted for each type of equipment

[F. No. R-11014/03/2025-NT]
DEVENDRA KUMAR RAI, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2026.06.12 01:45:20 +05'30'
