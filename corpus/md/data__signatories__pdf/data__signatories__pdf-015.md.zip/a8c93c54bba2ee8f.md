---
doc_id: "a8c93c54bba2ee8f"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6acf52a94845e7.09554964.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Order - The year of allotment and inter se seniority of the SFS officers of Punjab Cadre appointed as IFS Officers in Punjab Cadre against the Select List 2021, order dated 14-10-2026"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ca1d0f5e76cdf675"
---

<!-- page 1 -->

ना No. 17013/08/2025-IFS I(Part-!)
: Government of India
Ministry of Environment, Forest & Climate Change
Indira Paryavaran Bhawan,
: 6th floor, Prithvi Block, |
: Jor Bagh Road, Ali Ganj, New Delhi-110003
Dated: October, 2026
ORDER I" |
In terms of the provisions contained in Rule 3(3)(ii) & Rule 4 of IFS |
. (Regulation of Seniority) Rules, 1997, as amended from time to time, the year of \
allotment and inter-se-seniority of the following SFS officers of Punjab Cadre, who |
have been appointed as IFS officers in Punjab Cadre against the Select List 2021 |;
vide this Ministry’s notification of even no. dated 07.08.2026 is determined as |
under:
|
Name of छि6 ठा Completed [Total roposed [Placement |
Officer appointment] years of Weightagelyear _ofjin the| |
(Shri./Smt)jin SFS as service as on allotment |Seniority |
& (Select {Assistant 31st day of las perjList :
List) Conservator] December of weightage |
lof Forests | the year for 1
which meeting :
of selection :
committee .
was held.
leeraj 07.12.2012 9 Years Below Shri ।
Kumar Dharamvee: |
Diaru, IFS i
(RR:2018)
haranjit 07.72: 20T2 9 Years 2018 Below Shri
Singh Neeraj L
Kumar, :
: fers Promottee
IFS
la
Gore or '
(Shravan Kumar)
Under Secretary to the Government of India
, Tel. No. 011-20819160
Copy to:
1. The Chief Secretary, Government of Punjab, Punjab. !
2. The Principal Secretary (Forests), Government of Punjab, Punjab.
3. The PCCF & HoFF, Government of Punjab, Punjab. :
4. The Accountant General, Government of Punjab, Punjab.
