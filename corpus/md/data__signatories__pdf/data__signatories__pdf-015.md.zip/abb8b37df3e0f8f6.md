---
doc_id: "abb8b37df3e0f8f6"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6890a43789b510.57419653.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Notification - Offer of appointment - Smt. Nabanita Gaunguly, IFS (AGMUT:2010) appointment to the post of Sr. Deputy Director, FSI, Kolkata on deputation basis under the CSS-MoEFCC, offer dated 04.08.2025"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "246085329f54504f"
---

<!-- page 1 -->

BY SPEED POST
Computer No: 253223
File No: 12026/05/2024-IFS-I
Government of India
Ministry of Environment, Forest and Climate Change
Prithvi Wing, 6th Floor,
Indira Paryavaran Bhawan, |
Jor Bagh Road, New Delhi - 110 003. |
Dated: (August, 2025. |
To oe '
The Chief Secretary
Government of Goa
Panaji |
i
Subject: Appointment of Smt. Nabanita Gaunguly, IFS(AGMUT:2010) to the post of Sr. :
Deputy Director, FSI, Kolkata on deputation basis under the Central Staffing Scheme of |
Ministry of Environment, Forest and Climate Change (CSS-MoEFCC) -regarding |
Sir, |
| am directed to inform that with the approval of the competent authority, Smt. '
Nabanita Gaunguly, IFS(AGMUT:2010) has been selected for appointment to the post of Sr. |
Deputy Director, FSI, Kolkata on tenure deputation basis under the Central Staffing Scheme }
of this Ministry on the following terms and conditions:
(i) She will draw pay as per the scale allowed by the Cadre Controlling Authority plus
allowances as applicable to that grade. |
(ii) The central deputation tenure of the officer will be for 05 years from the date of |
joining to the post. |
(iii) The headquarters of the post will be at Kolkata; however, the services of the officer |
can be utilized anywhere in India.
(iv) Other terms and conditions will be the same as applicable to the other officers of i
her grade on deputation to the Central Government and as per CSS-MoEF&CC. |
2. Government of Goa is, therefore, requested to relieve the officer at the earliest with i
the direction to take up the new assignment. |
Vesa jthfully,
Oo ay”
ws
(Prem Pral jaurya)
Under Secretary to the Government of India |
011-20819192 !
Copy to: |
4. PS to Hon’ble Minister, Environment, Forest and Climate Change. i
2. PS to Hon'ble Minister of State, Environment, Forest and Climate Change. i
3.PPSs to Secretary(EF&CC)/DGF&SS/ADGF(WL)/ADGF(FC)/ADGF(NTCA)/CEO(CAMPA) i
4. The Principal Secretary (Forests), Government of Goa, Panaji. i
5. PCCF & HoFF, Government of Goa, Panaji. :
6. DG, FSI, Dehradun. i
7. Regional Director, FSI, Kolkata. |
8. US(AGMUT), MoEFCC, New Delhi. i
9. US, Department of Personnel Govt. of Goa, with reference to your letter no. 7/21/2022- |
PER/1882 dated 19/06/2025. |
10. Smt. Nabanita Gaunguly, IFS(AGMUT:2010), CF (Conservation) Government of Goa. |
11. NIC for uploading on the IFS website/Guard file/Spare copies. i
