---
doc_id: "aced3df69a0ab3f7"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/109e17825ddadca7bb4b736d3f3ad56a.pdf"
ministry: "Tourism"
title: "Filling up the post of Principal (Group A Gazetted in Level 13 Pay Scale PB 4 Rs 37 400 67 000  + GP Rs 8700 Prerevised on deputation including Short Term Contract basis in the IIS&M Gulmarg  J&K   Extension of date for application"
date: "2019-10-14"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5a6e6b8617b438c9"
---

<!-- page 1 -->

SNATATHR/ Government of India
qdeaaarera/ Ministry of Tourism
यात्राव्यवसायप्रभाग/(17मए४९० 17406 एंएशंडांणा)
7 Floor, Chanderlok Building,
36 Janpath, New Delhi -110001
File No: TT-501/1/2020-TT Dated 02.03.2020
OFFICE MEMORANDUM
Subject: Withdrawal of guidelines issued by the Ministry of Tourism, Govt. of India
vide communication no. 7-TT.II (07)/2000-GD-Vol.I1 dated: 227 September 2011
pertaining to the selection and grant of guide license to ‘Regional Level Tourist Guides
(RLG) - 2011’.

The undersigned is directed to refer the matter regarding guidelines issued by the
Ministry of Tourism, Govt. of India vide communication no. 7-TT.II (07)/2000-GD-Vol.II
dated: 2274 September 2011 pertaining to the selection and grant of guide license to ‘Regional
Level Tourist Guides (RLG) — 2011’ whereby a detailed procedure was laid down by the
Ministry of Tourism, Govt. of India for the induction of Regional Level Guides and issuance

. of Regional Level Guide licenses.
2. The matter has been reconsidered and reviewed at various forums, and it has now
been decided that guidelines issued by the Ministry vide communication no. 7—-TT.II
(07)/2000-GD-Vol.I dated: ‘agra September 2011 pertaining to the selection and grant of
guide license to ‘Regional Level Tourist Guides (RLG) — 2011” stands withdrawn with the
following provisions:

a. Henceforth, Ministry of Tourism, Govt. of India will not induct any fresh Regional
Level Guides or Issue fresh Regional Level Guide Licenses.

b. The existing valid Regional Level Guide License issued by the Ministry of Tourism,
Govt. of India will be valid up till 31" March, 2021 only.

c. The existing valid Regional Level Guide License holders will have to undergo the
IITF Refresher Course before 31 March, 2021 in order to get IITF Advanced
Category (Heritage) certificate, which would enable them to continue guiding at ASI
Protected Monuments and Heritage Sites.

This issues with the approval of competent authority.
oo _ ook
AO ort
(C. Gangadhar)

Assistant Director General (TT/AAH)
Copy to,
To all divisions of Ministry of Tourism
To all Indiatourism offices overseas and domestic
To all Tour Operators Associations: - IATO/ADTOI/TAAI/ATOIITTA
To all Regional Level Guides Associations
