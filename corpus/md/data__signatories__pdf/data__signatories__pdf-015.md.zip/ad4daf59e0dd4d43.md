---
doc_id: "ad4daf59e0dd4d43"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/101d464165e668a3cea1ea23ed52ab76.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Guidelines for Detection, Prevention and Management of Arsenicosis in India"
date: "2025-08-01"
pages: 26
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aada880cb040eab3"
---

<!-- page 1 -->

Detection,Prevention and
Management of Arsenicosis in India

A Field Guide

Directorate General of Health Services
Ministry of Health and Family Welfare
Government of India

1

<!-- page 2 -->

FOREWORD
Arsenicosis has been known to be a health problem in some parts of our
country. It occurs mainly by drinking Arsenic contaminated ground water and also
through contaminated food chain or Industrial pollution for prolonged period. It
results in skin manifestations such as Kerotosis, Melanosis and may also affect
lungs, liver or lead to various types of cancers. The condition is preventable if
measures are taken to provide safe drinking water to the community, promotion of
nutrition and also if diagnosed early.
With a view to formulate Guidelines for prevention, control and
management of Arsenicosis, an Expert Group was constituted under my
Chairmanship. After detailed round of discussions and subsequent exchange of
communications, these Guidelines have now been finalized. I am sure that these
Guidelines shall be very useful for sensitizing the Health Programme Managers and
for training of Medical & Paramedical personnel in the field.
I compliment the officials of the Nutrition & IDD Cell of the Dte. General of
Health Services for facilitating in preparation and finalization of these Guidelines.
It is hoped that these Guidelines shall be helpful in prevention and control of
Arsenicosis in the affected areas of the country.

Dr. Jagdish Prasad
Director General of Health Services,
Ministry of Health & Family Welfare,
Government of India.

2

<!-- page 3 -->

CONTENTS
1. Preamble
2. Health Impacts of exposure
3. Detection and Management of Arsenicosis
Goal and Objectives
Components
Linkages & Coordination mechanism
Recording and Reporting
Review and Evaluation

4. Guidelines
Case Definition for Arsenicosis
Laboratory support
Management of Arsenicosis.

5. References

6. Annexures
1. District- wise Excess Presence of Arsenic in Water.
2. Clinical manifestations of Arsenicosis.
3. Reporting Form S-IDSP.
4. Reporting Form P-IDSP.
5. Reporting Form L –IDSP.

3

<!-- page 4 -->

Detection, Prevention and Management of Arsenicosis in India
1. PREAMBLE
Arsenic occurs naturally in the environment and can be released into water through natural
activities such as hydrothermal action & dissolution of rocks. It occurs in both inorganic and
organic forms.

Inorganic Arsenic compounds (such as those found in water) are highly

toxic while organic Arsenic compounds (such as those found in seafood) are less harmful to
health. Shift from surface water and shallow open well sources to deep tube well in Arsenic
affected areas has also led to Arsenic contamination in some States. Arsenic leaching may
also occur from industrial sources or from Arsenic containing insecticides, herbicides or
rodenticides.
People are exposed to elevated levels of inorganic Arsenic by drinking and using
contaminated water (mostly groundwater) for cooking, irrigation of food crops, industrial
processes and smoking tobacco.
Arsenic is also found in groundwater at an average of between 10m and 60m depth and
deeper groundwater is generally free from Arsenic.1
Arsenic contamination of groundwater may also occur from anthropogenic activities such as
mining, over exploitation of ground water etc.In rural areas, more than 85% of drinking
water sources are ground water based.
Long-term exposure to inorganic Arsenic can lead to chronic Arsenic poisoning. Skin
lesions and skin cancers are the more characteristic features. Presently there is no effective
remedy for Arsenic poisoning. The only effective management is through prevention by
finding safe alternative sources of drinking water. Once patients switch to a safe source
of drinking water, the skin lesions improve and this improvement may be accelerated
by taking High Protein Diet, Vitamin B Complex, Anti-oxidant supplements (e.g.
Vitamins A, C, E and Selenium).
The problem of high Arsenic levels in drinking water has been observed in parts of USA,
Canada, Argentina, Chile, Mexico, Hungary and many countries of the South-East Asia
Region which contains a natural Arsenic-rich eco-belt formed by Arsenic-laden alluvium or
sediments deposited in the Brahmaputra-Gangetic river basins millions of years ago.
Countries of South-East Asia that are in this belt include Bangladesh, parts of India,
Myanmar and Nepal.
4

<!-- page 5 -->

Bureau of Indian Standards (BIS) has specified two types of values for general physicochemical parameters and toxic elements in drinking water:1) Maximum desirable limit and
2) permissible limit in case of absence of alternative Drinking Water sources.. BIS,
specification for drinking water (IS10500:2003) specified both values as 0.05mg/l. However
in 2012, BIS reduced the desirable limit of Arsenic from 0.05mg/l to 0.01mg/l while retaining
the permissible limit of 0.05mg/l.

In India, groundwater Arsenic contamination was first identified in 1983 and patients were
reported from 3 families in a village of 24 Parganas district in West Bengal. Thereafter
many more cases were reported from West Bengal and other States like Bihar, Uttar
Pradesh, Jharkhand, Assam etc. As per the online Integrated Management Information
System (IMIS) of Ministry of Drinking Water and Sanitation , there are about 1800 Arsenic
affected rural habitations in the country where 23.98 lakhs people are at risk. IMIS 2015
data indicates that there are 6 Arsenic affected states with regard to ground water sources.
State wise no. of habitations :- West Bengal (1218), Assam (290), Bihar (66 ),Uttar Pradesh
(39), Karnataka (9) and Punjab (178). The list of affected districts (subject to change) is
shown in Annexure 1.
In order to provide relief to persons affected by the excess Arsenic in water and
prevent further exposure, these Guidelines have been prepared for use by the Health
Authorities and Programme Managers in the affected areas. These are also to be
used for Training of field functionaries such as Medical Officers, Paramedical
workers etc.
2. HEALTH IMPACT OF EXPOSURE
The health impact of exposure to Arsenic depends on the dose, the modality and duration
of exposure as well as the source and type of Arsenic.
The first visible symptoms caused by exposure to high Arsenic concentrations in drinking
water are abnormal black-brown skin pigmentation known as melanosis and symmetricallydistributed, multiple, small elevated lesions of palms and soles known as keratosis. If the
Arsenic intake continues, skin de-pigmentation develops resulting in white spots that looks
like raindrops (medically described as leukomelanosis). Palms and soles further thicken
and painful cracks emerge. These symptoms are described as hyperkeratosis and can lead
on to skin cancer (WHO 2001). The disease syndrome caused by chronic Arsenic exposure

5

<!-- page 6 -->

is called Arsenicosis and it develops when Arsenic contaminated water is consumed for
prolonged period of time. .
It is recognized that Arsenicosis may manifest with or without skin manifestations.However,
as skin manifestations are the leading reason for a patient to seek medical care, hence
these are used for diagnosis of Arsenicosis based on dermal manifestations, generally
Hyperpigmentation and keratosis. Though pigmentation and keratosis are the specific skin
lesions characteristics of chronic arsenic toxicity, it also produces various systemic
manifestations over and above skin lesions, important ones being chronic lung disease like
chronic bronchitis, chronic obstructive pulmonary disease , liver disease like non-cirrhotic
portal fibrosis and other diseases like polyneuropathy, peripheral vascular disease, nonpitting oedema of feet/hands3 ( Details in Annex 2).
Trivalent Arsenic is believed to be a carcinogen that induces chromosomal abnormalities
including changes in the structure and number of chromosomes and sister chromatid
exchanges. The pentavalent Arsenic causes Arsenolysis.The exact molecular mechanism
of Arsenic induced carcinogenesis is less understood.
3. DETECTION AND MANAGEMENT OF ARSENICOSIS
In view of the serious consequences of chronic Arsenic toxicity, it is essential to address
the situation in a coordinated and focused manner. The Management of Arsenicosis is to
be done as follows:3.1 Objectives:1. To create awareness in the community about preventability, signs and symptoms of
Arsenicosis; availability of diagnostic and treatment facilities and measures that can be
taken at community level to ensure availability of Arsenic free water etc.
2. Identification of Arsenicosis cases in the community using standard case definitions
and algorithms.
3

Capacity building for early diagnosis and management of Arsenicosis.

4 Instituting Linkages with the facilities for treatment, management and establishing a
referral system for appropriate management of cases at different levels.
5 Establishing linkages with the existing diagnostic facilities for testing Arsenic in urine,
hair and nails.
6 To establish intersectoral linkages for ensuring uninterrupted supply of safe and
Arsenic free drinking water.
7 Introducing a mechanism for surveillance of drinking water quality.
6

<!-- page 7 -->

3.2 Components
A. Health Education
Health Education is absolutely necessary to change community behavior related to use of
water, which in turn will help in prevention of Arsenicosis. Vulnerable populations should
also be made aware about common signs and symptoms of Arsenicosis through use of
simple, pictorial, context specific IEC material at the community and facility levels.
A combination of learning experiences will have to be designed to help individuals and
communities prevent Arsenicosis and facilitate early diagnosis and treatment by increasing
their knowledge or influencing their attitudes
Every opportunity – interfaces between health care provider and individuals, groups and
communities – e.g. Inter personal communication in clinics, group meetings and mass
meetings organized by health and other sectors, should be utilized to disseminate relevant
messages.
Traditional folk media, street plays etc. involving the community could also help in
awareness generation, motivation and adoption of safe water use practices such as not
using water from Hand pumps and Tubewells coloured Red for drinking and cooking
purposes..
B. Surveillance of Arsenicosis in the community:Survey will be conducted by the trained health workers in the community/ schools

in

association with district health officials as per surveillance guidelines to identify Arsenicosis
at community level.

The affected cases to be first referred to the Medical Officers of

Primary Health Center (PHC) for further diagnosis and management. After availability of
baseline data and after six months of undertaking interventions, a resurvey to be
conducted. A mechanism under Integrated Disease Surveillance Programme (IDSP) is to
be introduced for surveillance for early case detection and reporting. Cases shall be
identified based on two major criteria, namely:(a) Presence of pigmentary and keratotic skin lesions, and
(b) Evidence of exposure to elevated levels of Arsenic established by history of intake of
Arsenic contaminated water, or by Arsenic concentration in hair or nails.
The Surveillance and Reporting for Arsenicosis under IDSP shall as follows:

The terminology such as Suspected case, Probable case and Clinically Confirmed
case to be taken as Syndromic, Presumptive and Confirmed case respectively under
IDSP.

7

<!-- page 8 -->





Suspected case to be taken as Syndromic case and is classified by the ANM /
Health Worker (Male ) or other non medical persons. The S form of IDSP would be
used (Annexure 3).
Probable case to be taken as Presumptive case and should be diagnosed by a
Medical Officer or a Doctor in the private sector.The P form of IDSP would be used
(Annexure 4).
Clinically confirmed case to be taken as Confirmed case and the criteria are
diagnosis by a Dermatologist. Till the time laboratory facilities are easily available at
the district level to confirm the presence of Arsenic in the nails and hairs of a patient,
the criteria of a Clinically confirmed case may be taken as Confirmed. The L form of
IDSP would be used (Annexure 5).

Recording and Reporting
Reports to be compiled at the affected Block/District/State Levels and sent to the next
higher level as hard copy and by Email,as per IDSP reporting system.
C. Capacity building at different levels of health care delivery system for early detection
and management of Arsenicosis cases.
C.1 Manpower : In order to coordinate the activities, monitor progress and provide
feedback provision to be made for following officials:National Level:- Nodal Officer (to be designated at the National level).
One Consultant and One DEO.
State Level:-State Nodal Officer (to be designated in each of the affected state) and one
DEO.
District level:- District Nodal Officer (to be designated in every affected district) and one
DEO.

C.2 Training:
Trainings to be undertaken at the Central, State and District level.

Training of Trainers to

be organized for State Nodal Officer, District Nodal Officers, at the National Institutions /
Head Quarter of any affected State / Medical College by the experts. Besides, Laboratory
Technicians of the identified laboratories for estimation of Arsenic in hair, nails and urine
will undergo training at any recognized National Reference Laboratory.
Further, trainings, advocacy and sensitization of various categories of health professionals
/personnel at different levels of health care facilities will be undertaken at district level.
These includes Policy Makers, Health workers, ASHAs, ANMs, Anganwadi Workers, PRIs,
VHSC & Teachers.

8

<!-- page 9 -->

D. Linkages with existing facilities in the District/ Medical College Hospitals:
Strengthening of existing laboratory diagnostic facilities for Arsenic content in water, Hair &
nails, urine in district hospitals/ medical colleges/ Public Health Laboratories for early
detection and confirmation of Arsenicosis cases to be done in the affected areas. Sentinel
sites must be established in the Medical Colleges.

E. Management of detected Arsenicosis cases including supplementation with
vitamins and minerals
Symptomatic treatment of Arsenicosis at the PHC with referrals. A referral mechanism is to
be developed to refer the affected person to the trained dermatogist / specialist in the
district hospital/state hospital or state medical college for further diagnosis and
management .
Patients need to be screened for associated malignancies (esp. skin malignancies) and
systemic complication (esp. respiratory, hepatic, neurological, and peripheral vascular
affection) which are the major cause of mortality and morbidity; and treated accordingly.
Keratolytic agents (e.g., 5-10% salicylic acid or 20% urea) may be given for symptomatic
management of keratosis. Supplementation with with high protein diet, B-vitamins and
Antioxidants (e.g., Vitamins A, C and E etc.) to be undertaken as these. may reduce the risk
of Arsenic-related skin lesions.
F. Coordination Mechanism
National Level:-

_ Coordination Committee between Ministry of Health & Family Welfare

and the Drinking Water and Sanitation for simultaneous provision of safe water, health
education & IEC activities and review of progress made in Arsenic mitigation
State Level:-_ Coordination at State Level shall be similar to the above coordination at
National level.
District Level:- District Committees to be constituted to oversee the programme
implementation, monitoring the progress on regular basis.

G. Review and Evaluation
Review meetings to be held at National and State levels every year to assess the
achievements. Review meetings at the District level to be held quarterly.

9

<!-- page 10 -->

4. GUIDELINES
4.1 CASE DEFINITION
Arsenicosis is defined as a chronic health condition arising from prolonged ingestion of
Arsenic above the safe dose for at least six months, usually manifested by characteristic
skin lesions of melanosis and keratosis, occurring alone or in combination, with or without
the involvement of internal organs.
Clinical Criteria _

the first diagnostic criterion requires the presence on physical

examination of any of the pigmentary or keratotic skin signs listed earlier. These signs
encompass a spectrum of non-cancerous and cancerous cutaneous findings that are wellrecognized features of chronic Arsenic ingestion.

Laboratory Criteria _ a reliable history of consuming water with an elevated concentration
of Arsenic for at least six months is sufficient to establish exposure. In the absence of
adequate information regarding a subject’s exposure history, the finding of elevated levels
of Arsenic in a subject’s hair or nails could offer presumptive evidence of elevated Arsenic
exposure.

Arsenic testing should be conducted using standardized sample collection

methods and acceptable laboratory techniques as elaborated subsequently

Suspected Case _

A ―suspected case‖ is a subject who shows characteristic skin lesions

or pigmentary changes or keratosis on first presentation and who has not undergone indepth medical examination or laboratory testing. The classification of ―suspected case‖ is
temporary. It should be reclassified as ―probable‖, ―confirmed‖ or ―non-Arsenic‖ after further
clinical examination and or laboratory testing.
Probable Case _ A ―probable case‖ is a suspected case that has undergone further clinical
examination and belongs to one of the two categories as below:
Either

(a) a suspected case showing melanosis AND bilateral keratosis involving palms

and soles

OR

(b) a suspected case showing unilateral melanosis or keratosis after

excluding other skin lesions mimicking Arsenicosis.

Probable cases whose Arsenic tests are subsequently found to be negative maintain the
status of probable case.
10

<!-- page 11 -->

Clinically Confirmed case _

A ―clinically confirmed case‖ is a ―probable case‖ in whom the

presence of other Arsenicosis-simulating skin lesions has been ruled out by differential indepth skin examination by either a trained dermatologist or an Arsenic expert. The
differential features to be used are given in Annex 2.
Laboratory Confirmed Case _ A probable case classified on the basis of differential
skin diagnosis becomes a ―laboratory confirmed case‖ when subsequent laboratory tests for
Arsenic prove to be positive.
Clinically and Laboratory Confirmed Case _ A ―clinically and laboratory confirmed case‖
is a ―clinically confirmed case‖ in whom the Arsenic test is also positive by the criteria
recommended.
Non-Arsenic Case _ A ―non-Arsenic case‖ is a ―suspected‖ or ―probable‖ case in which
the medical specialist finds that the patient’s skin condition is due to a cause other than
Arsenic exposure.
4.2 LABORATORY SUPPORT
Laboratory support provides ancillary information in instances where probable cases
cannot be clinically confirmed or in instances or countries where a laboratory
diagnosis is required for final confirmation.
4.2.1 TYPES OF SPECIMEN
WATER: Arsenic exposure can be established by testing the water that is currently being
consumed.
HAIR AND NAIL: Hair or nails provide circumstantial evidence for history of past exposure
within the preceding nine months.
URINE: Both organic and inorganic forms of Arsenic are excreted in the urine which will test
positive for Arsenic. Thus, recent exposure to Arsenic can be established from urine
samples provided the subjects have not been consuming sea-food in the preceding four
days. Alternatively, the chemical form of Arsenic must be differentiated by laboratory
methods.
BLOOD: Blood is of no value in establishing chronic Arsenic exposure because of the short
half-life of Arsenic in blood.
4.2.2 COLLECTION, STORAGE and TRANSPORTATION
WATER AND URINE: For water and urine samples it is advisable to collect 50 ml of
samples. Care must be taken to avoid contamination and prevent speciation changes
during sample collection and storage. Plastic containers should be acid washed and traces
11

<!-- page 12 -->

of oxidizing agents avoided to preserve the oxidation state of the Arsenic compounds, in
instances where speciation is required. The container should also be completely filled to
prevent oxidation from the air in the bottle.
Concentrated hydrochloric acid (1 ml of acid to 100 ml of urine) can be used to prevent
bacterial growth for urine samples. The samples are stable at room temperature for at least
a week and at –20°C for 6 months. For longer periods it is recommended that samples are
frozen at -80 C.
Urine and water samples can be transported at room temperature. All specimens must be
accompanied by a duly filled request form containing information on the patient’s name,
referring doctor, clinical diagnosis and an address for sending results. The request form
should be packed in a separate plastic bag for protection in the event of specimen leakage.
HAIR AND NAILS: Care should be taken to avoid superficial Arsenic contamination. The
hair must be washed with Arsenic-free shampoo and also be free of colouring chemicals
containing Arsenic. For a female subject, collect 30 hairs 6 cm. long from the base of the
hair, discard the hair beyond 6 cm. For males, collect 60 short hairs from the base. For
nails, let them grow for one month then clip every finger and toe nail—this represents 9
months of exposure.
Specimens of hair and nails can be stored at 4°C until tested. Prolonged storage may lead
to endogenous fungal growth in some instances. Hair and nails can be transported at room
temperature.

4.2.3 ANALYTICAL PROCEDURES
In recent years, the technique of atomic absorption spectrometry (AAS) has become the
method of choice due to its selectivity and sensitivity in the detection of Arsenic. Thus, AAS
may be considered as the standard reference method (―gold standard‖) for the evaluation of
other test methods. A commonly-used variant of the AAS technique is the highly sensitive
hydride generation atomic absorption spectrometric method (HGAAS).
For mass screening under field conditions, or in a situation where no laboratory facilities
exist, it is often practical to use a reliable test-kit for testing Arsenic. A number of such test
kits are commercially available. However, the validity of these kits in comparison toother
test methods must be established. Chemicals such as sulfite and selenium or other
impurities can interfere with the performance of some kits and these must be
established for each instance.

12

<!-- page 13 -->

4.2.4 INTERPRETATION OF LABORATORY RESULTS
WATER:- As per the Bureau of Indian Standards, the desirable limit of Arsenic in water is
0.01 mg/ litre and the permissible limit is 0.05 mg/ litre. [The current WHO guideline value
of Arsenic in water is 0.01 mg/L (or 10 μg/L also expressed as 10 part per billion (ppb)].
Thus, any sample containing Arsenic concentration of greater than 0.05 mg/ litre is
considered positive in the Indian context.
URINE:- A urine sample showing more than 50 μg / litre may be taken as evidence of
recent exposure provided the subject has not consumed sea food during the previous four
days.
HAIR AND NAILS:- The value in hair and nails is not known with certainty. However,
Arsenic concentration of greater than 1 mg/kg in dry hair and Arsenic concentration of more
than 1.5 mg/kg in nail may be considered as indicative of exposure to an unsafe dose of
Arsenic within the preceding 11 months.
4.3 MANAGEMENT OF ARSENICOSIS
4.3.1 CESSATION OF EXPOSURE TO DRINKING WATER
As there is no known specific treatment for Arsenicosis, the prudent intervention is to stop
consumption of Arsenic-contaminated water. Together with the Public Health Engineering
Department, take up appropriate counselling for safe water options and health
consequences of consuming Arsenic contaminated water. In general, the water supply
option for an area will depend on the availability, quality and development potentials of
available alternative water sources in a given area. A single option may not be suitable or
affordable for people with different social and economic conditions. Some of the main
strategies for safe water should include:
(1) Provision of safe surface water for drinking & cooking.

(2) Rainwater harvesting has good potential in most parts where there is rainfall. It can be
combined with household-based technology with provision for adequate storage tanks. This
method is particularly useful in areas where adequate quantity and good quality of surface
water sources are limited.
(3) Treatment of Arsenic contaminated water. A variety of options are available depending
on technologies, cost and acceptability and range from filter units for domestic use, through
filter units for community level use to piped supply of Arsenic treated-water.

13

<!-- page 14 -->

TECHNOLOGICAL OPTIONS FOR AVAILABILITY OF ARSENIC SAFE WATER IN
ARSENIC AFFECTED REGIONS IN INDIA 4
Based on the experiences in countries like India, China, Bangladesh etc, the following are
the major technology options for providing Arsenic safe water in the affected areas:

Tapping ground water from alternate arsenic-free aquifers at a higher depth and proper
sealing-off of the arsenic bearing aquifer from the same. (>100m).



Large scale piped water supply for the rural communities by drawing water from the
rivers and treating them for removal of pathogenic microbes.



Conservation and quality up gradation of traditional surface water sources like ponds,
dug-wells etc. in the villages. These sources are generally free from Arsenic but grossly
contaminated with faecal pollution.



Removing Arsenic from the ground water, by using technologies like, adsorption
(activated alumina/Iron oxide), co-precipitation (oxidation, coagulation &
filtration) or ion exchange. These technologies could be applied in community
plants attached to hand pump tube-wells or large dia. tube-wells. Otherwise
domestic filters could also be developed on the basis of these
technologies.Among the emerging technologies, the Nanotechnology using
various kinds of nano materials, developed by the Madras IIT Group, appears to
be holding great promise in terms of cost effectiveness and area requirement.
Reverse Osmosis process is also being used widely though it consumes huge
amount of water.
Of the various options stated above, Tapping of Arsenic free aquifers is restricted by

the absence of clay barrier between the upper arseniferrous aquifer and the deeper Arsenic
free aquifers, as has been found in parts of West Bengal, India. In some places, the water
bearing aquifer is restricted to 80 to 90 m only, due to presence of hardrock beneath the
same. The use of Arsenic Treatment Units fitted to hand pumps, are also facing the
problem of sustainability because of the problem of operation & maintenance. A community
based system of operation & maintenance, active participation and cost sharing by the
people are essential for these to be successful. So far as domestic units are concerned,
experience so far suggests low acceptability by the people. Considering that in the long run,
use of ground water must be restricted in the Arsenic affected areas, the most appropriate
technology option for countries with high annual rainfall and large perennial surface water
sources appear to be the surface water based piped water supply systems. However, it is
also the most capital intensive among all the options. Sustainability of such systems would
be assured by people’s participation in the operation and maintenance & cost sharing.

14

<!-- page 15 -->

4.3.2 ADMINISTRATION OF NUTRITIONAL SUPPLEMENTS
Though there is no large-scale randomized-controlled double-blinded trial to evaluate the
efficacy of supplementation, administration of nutritional supplements like beta carotene,
vitamin E and

vitamin C have been reported to hasten recovery or averting disease

progression. These may be provided to the affected population as an interim measure.
4.3.3 PROVISION OF NON-SPECIFIC THERAPY
Symptomatic treatment for patients with keratosis or keratosis and melanosis includes the
application of keratolytic agents. Presently, 5-10% of salicylic acid and 10-20% of ureabased ointment for the treatment of keratotic lesions is the most common prevailing
practice.
4.3.4 SECONDARY PREVENTION OF LATENT EFFECTS
Secondary prevention of latent effects should be done through medical surveillance The
management of Arsenic-associated cancer patients be done as done for management of
cancer patients in general.
4.3.5 PATIENT MANAGEMENT FLOW CHART
The first step, examination of the patient for the presence of non-cancer Arsenic-related
skin lesions, may be conducted by trained health care personnel such as medical doctors
or other skilled health care providers at the primary care level. These personnel should
receive standardized training in the recognition of characteristic Arsenic-related skin
lesions. In order to maximize sensitivity of the case detection process at the primary health
care level, the personnel are instructed to exercise an inclusive and non-stringent approach
when identifying Arsenic related skin lesions.
Patients who are designated ―probable cases‖ should be referred for a second evaluation
by a dermatologist or other physicians with specialized expertise in the recognition and
diagnosis of Arsenic-related skin lesions and other abnormal conditions of the skin. This
evaluation, which should include a complete physical examination and a review of the
patient’s medical and exposure history, may be conducted at either the
Primary or Secondary care level. The purpose of the secondary examination is two-fold:(a) The criteria outlined earlier should be used to perform a differential diagnosis to either
confirm or rule out the presence of skin lesions consistent with chronic Arsenic exposure;
and
(b) The patient should be evaluated for the presence of other medical conditions potentially
related to Arsenic exposure. All patients should be referred, as appropriate, for further
evaluation or treatment of any medical conditions detected by the medical specialist. If the
15

<!-- page 16 -->

patient’s clinical presentation is such that the medical specialist cannot confirm or rule out
the presence of characteristic skin lesions, the patient should retain the diagnosis of
―suspected/probable case‖, and be referred for re-evaluation by the medical specialist in 6
to 12 months.
---------------------------------------------------------------------------------------------------------------

References
1. Arsenic primer guidance for UNICEF country offices on the investigation and
mitigation of Arsenic contamination. Water, Environment and Sanitation Section
Programme Division, UNICEF, New York UNICEF 3 UN Plaza, New York, NY 10017
2008
2. WORLD HEALTH ORGANIZATION, A Field Guide for Detection, Management and
Surveillance of Arsenicosis cases. WORLD HEALTH ORGANIZATION, Regional Office
for South-East Asia, Edited by Deoraj Caussy, New Delhi, 2005.
3. Guha Mazumder DN. Chronic Arsenic Toxicity and Human Health, Indian J Med
Res 128, pp 436-447, 2008.
4. Contributed by Prof K.J. Nath , Chairman, Task Force of Arsenic & Water Quality,
Safety & Security, Govt. of West Bengal and Ex Director, All India Institute of Hygiene
and Public Health, Kolkata.
-----------------------------------------------------

16

<!-- page 17 -->

Annexure- 1
State/District- wise Excess Presence of Arsenic in Water as per IMIS of
Ministry of Drinking Water and Sanitation ( as on 01.4.2015)
Name of the State

Affected District with
Arsenic

No of
habitations

Remarks

1. West Bengal #
(1218)

1. Maldha

65

Also NPPCF

2. Murshidabad

312

3. Nadia

523

4. North 24 Paraganas 297

2. Assam (290)

3. Bihar (66)

5. Hooghly

6

6. Bardhaman

15

1. Nagaon

1

2. Nalbari

6

3. Baksha

1

4. Barpeta

19

5. Cachar

5

6. Darrang

24

7. Dhubri

22

8. Golpara

5

9. Golaghat

109

10. Jorhat

85

11. Kokrajhar

1

12. Morigaon

2

13. Shivsagar

8

14. Sonitpur

2

1. Bhagalpur

2

Also NPPCF

2. Munger

25

Also NPPCF

Also NPPCF

17

<!-- page 18 -->

4. Uttar Pradesh
(39)

5 Karnataka (9)

6. Punjab (178)

3. Begusarai

7

4. Darbhanga

5

5. Lakhisarai

8

6. Patna

3

7. Samastipur

12

8. Saran

4

1. Balia

12

2. Gorakhpur

8

3. Kheri

13

4. Sant Kabeer Nagar

6

1. Raichur

3

Also NPPCF

2. Gadag

3

Also NPPCF

3. Yadgir

3

1. Fazilka

1

2. Amritsar

106

3. Ferozpur

5

4. Gurdaspur

40

5. Hoshiarpur

1

6. Kapurthala

1

7. Roopnagar

6

8. Tarantaran

18

TOTAL

1800

# In addition, as per data of Public Health Engineering Deptt.,Govt of West Bengal,
267 habitations of South 24 Parganas and 7 habitations of Haora Districts of the State are
Arsenic affected.
Note:-The above number of Arsenic affected habitations is subject to change.

18

<!-- page 19 -->

Annexure- 2

Clinical manifestations of Arsenicosis
2.1 Skin Manifestations:
The dermal changes are characterized by increased
pigmentation and hardening of the skin, that is a combination of melanosis and keratosis. .
The most common sequence is the gradual development of spotted or ―raindrop
pigmentation‖, followed by the gradual emergence of hyper-keratotic changes. Both
conditions take several years ranging from 6 to 9 years depending on the exposure dose
and other host factors. The ―raindrop‖ pattern is particularly pronounced on the trunk
and extremities and is symmetrically distributed bilaterally. Mucous membranes such as
the undersurface of tongue or buccal mucosa may also be involved. Other patterns
include diffused hyper-pigmentation (melanosis);
localized or patchy pigmentation and
so-called leukodermia or leukomelanosis in which the hypo-pigmented macules take a
spotty, white appearance.
ArsenicArsenical hyper-keratosis predominantly appears on palms and the plantar aspect
of the feet, although involvement of the dorsum of the extremities and trunk has also been
described. In the early stages, the involved skin might have an indurated, grit-like character
that can be best appreciated by palpation; however, the lesions usually advance to form
raised, punctuated, 2-4 mm wart-like keratosis that are readily visible. Occasional lesions
might be larger (approximately 1 cm) and have a nodular or horny appearance. In severe
cases, the hands and soles present with diffused verrucous lesions. Cracks and fissures
may be severe in the soles.
MELANOSiS

KERATOSIS



Fine-freckled or spotted
pattern on trunk and
extremities (rain-drop
pigmentation)

Characterized by thickening of the
skin and appearance of papules or
nodules that can both be further
sub-categorized as :



Diffused or generalized hyper
pigmentation



Rounded hypo-pigmented or
de-pigmented macules on a
normal or hyper-pigmented
background (leukomelanosis)

MILD _ Slight thickening, or minute
Papules (less than 2 mm) of palms
and soles, often associated with a
grit-like
texture, that may be primarily
detectable by palpation



Localized or patchy
pigmentation generally on the
body



Pigmentation of mucous
membranes (e.g. oral
mucosa),

MODERATE _ Multiple, raised
keratosis
thickening, (>2 to 5 mm), appearing
mainly or exclusively in a symmetric
distribution on palms and soles
SEVERE _ Large discrete or
confluent keratotic elevations (> 5
19

<!-- page 20 -->

usually in combination with
other changes listed above
(less common)

mm) on palms and
soles, with nodular, wart-like
or horny appearance.
Less commonly, there may also be
involvement of the dorsum of the
extremities, and trunk. Diffused
thickening of the palms and soles
may occur alone or in combination
with the
keratotic nodules.

Arsenical pigmentation

Arsenical keratosis
[Photos provided by Dr. D N Guha Mazumder ]

2.2 Malignancy _ The most common type of malignancy following chronic exposure are
skin cancer such as Bowen’s disease, squamous cell carcinomas or basal cell carcinomas,
although internal malignancies are probably related as well.
BOWEN’S DISEASE
May appear as multiple macules, papule, or plaque (1mm to many cm) in non-sun
exposed areas. Usually a scaly, crusted erythematous plaque. They are usually
sharply demarcated and seldom indurated (pic overleaf). If the crust is removed, the
underlying surface may be red and oozing.
SQUAMOUS CELL & BASAL CELL CARCINOMA
Both these cancers have highly variable clinical appearances, depending in part on
the stage of the malignancy. Squamous Cell
Carcinoma is characterized by ulcerated or fungating growth. Basal cell carcinoma
is initially characterized by pearly translucent nodules leading to ulcerations
20

<!-- page 21 -->

2.3 Differential Dermal Diagnosis
The classic pattern of rain-drop pigmentation is relatively specific for Arsenic, and its
occurrence together with palmar-plantar hyperkeratosis is pathognomonic for Arsenicosis.
Nonetheless, some of the skin changes associated with Arsenic may appear the same or
similar to those encountered in other medical conditions.
There are at least five categories of dermal manifestations mimicking Arsenical
dermatosis and include diffused melanosis, spotted melanosis, leukomelanosis, diffused
keratosis, and nodular keratosis. Clinicians and paramedical personnel practising in
primary care settings can be trained to screen patients for the possible presence of
characteristic Arsenic-related skin lesions, but a differential diagnosis examination by an
experienced dermatologist or other physician with relevant expertise is recommended for
confirmation of the diagnosis.
2.4 Other manifestations of chronic Arsenicosis
The most common systemic manifestations include neurological, haematological,
gastrointestinal and respiratory complications.
Complications of the central and
peripheral nervous systems are neuropathy characterized by paresthesias and numbness.
Though the incidence of leg pain or intermittent cramp in the leg muscles is not uncommon,
dry gangrene is less frequently seen in the Indo-Gangetic Basin.
Haematological complications include leukopenia, anaemia and spleenomegaly.
Gastrointestinal complications include symptoms like anorexia, vague abdominal pain or
chronic diarrhoea; liver enlargement with or without non-cirrhotic portal fibrosis are also
seen. Respiratory complications include chronic cough or bronchitis.
COMMON CONDITIONS TO BE CONSIDERED FORDIFFERENTIAL DIAGNOSIS OF
NON-CANCER SKIN LESIONS

CATEGORY

Diffused
Melanosis

MAJOR
CONDITIONS
FOR
CONSIDERAT
ION
Actinic dermatosis
Melasma
Ashy dermatosis

Spotted
Melanosis

Pityriasis versicolor

DISTINGUISHING FEATURES

Found on exposed part of the body
Found mainly on face
Diffused pigmented macules mainly on
trunk
Hyperpigmented macules with fine
scale on trunk, face and neck
extremities.
21

<!-- page 22 -->

Freckle
Mottled pigmentation on face and
trunk increases with sun exposure.
Lichen planus
Starts with violaceous pruritic
papular lesion on trunk and
extremities and produces spotty
pigmentation on resolution.
LeucoMelanosis

Idiopathic guttate
hypomelanosis

Multiple depigmented macules on trunk and
extremities.

Pityriasis versicolor

Hyper and hypo-pigmented macules with
scales on trunk, face, neck and extremities.

Pityriasis – lichenoides
chronica
Leprosy

Erythematous papular lesion followed by
hypo-pigmented macules
Macular hypo-pigmented or erythematous
lesions, usually with loss of sensation. There
may be involvement of peripheral nerves
which are usually thickened and tender.

Diffused
keratosis

Psoriasis (palms and
soles)

Diffused keratoderma on palms and soles,
with or without scaly psoriatic patches on
the other sites.

Eczema

Lichenified lesions with pruritus and
occasional oozing.

Occupational keratosis
Tinea pedis

Pitted keratolysis

Nodular
Keratosis

Occupational keratosis
Verruca vulgaris

Corns/calluses
Seborrheic keratosis

Keratotic lesions corresponding to site of
friction.
Scaly fissured keratotic lesion, with or
without fissures on webs.
Multiple pitted (depressed) and keratotic
lesions on soles.
Same as above.
Multiple verrucous pigmented papules and
nodules on trunk, extremities and dorsum of
hands and feet.
Localized keratotic lesions at the site of
frictionDiscrete well-defined pigmented
papules and plaques on sun-exposed areas.

22

<!-- page 23 -->

Annexure-3
Form S
Reporting Format for Syndromic Surveillance
(To be filled by Health Worker, Village Volunteer, Non-formal Practitioners)
State

District

Block

Name of the Health Worker/Volunteer/Practitioner

Name of the Supervisor

ID No./Unique Identifier (To be filled by DSU)

Reporting

Year

Name of the Reporting Unit

From

w eek

mm

dd

yy

To

a

b

c

d

e

f

g

h

i

Cases
Male

j

k

l

m

n

Deaths
Female

< 5 yr > 5 yr Total < 5 yr > 5 yr Total

Total

Male
< 5 yr > 5 yr Total < 5 yr

Female
> 5 yr

Total
Total

1. Fever
Fever < 7 days
1 Only Fever
2 With Rash
3 With Bleeding
4 With Daze/Semiconsciousness/
Unconsciousness
Fever > 7 days

2. Cough with or without fever
< 3 weeks
> 3 weeks

3. Loose Watery Stools of Less Than 2 Weeks Duration
With Some/Much Dehydration
With no Dehydration
With Blood in Stool

4. Jaundice cases of Less Than 4 Weeks Duration
Cases of acute Jaundice

5. Acute Flacid Paralysis Cases in Less Than 15 Years of Age
Cases of Acute Flacid Paralysis

6. Unusual Symptoms Leading to Death or Hospitalization that do not fit into the above.

Date

Signature

23

<!-- page 24 -->

Annexure-4
FORM P
(Weekly Reporting Format –IDSP)
Name of Reporting Institution:

I.D. No.:

State:

District:

Block/Town/City:

Officer-in-Charge

Name:

Signature:

IDSP Reporting Week:-

Start Date:/

Sl.No.

End Date:/

/

Date of
Reporting:/

Diseases/Syndromes

1

Acute Diarrhoeal Disease (including acute gastroenteritis)

2

Bacillary Dysentery

3

Viral Hepatitis

4

Enteric Fever

5

Malaria

6

Dengue / DHF / DSS

7

Chikungunya

8

Acute Encephalitis Syndrome

9

Meningitis

10

Measles

11

Diphtheria

12

Pertussis

13

Chicken Pox

14

Fever of Unknown Origin (PUO)

15

Acute Respiratory Infection (ARI) / Influenza Like Illness (ILI)

16

Pneumonia

17

Leptospirosis

18

Acute Flaccid Paralysis
< 15 Years of Age

19

Dog bite

20

Snake bite

21

Any other State Specific Disease
(Specify)

22

Unusual Syndromes NOT Captured Above (Specify clinical
diagnosis)

23

Total New OPD attendance (Not to be filled up when data
collected for indoor cases)

24

Action taken in brief if unusual increase noticed in
cases/deaths for any of the above diseases

/

/

No. of cases

24

<!-- page 25 -->

Annexure-5
FORM L
(Weekly Reporting Format – IDSP)
Name of the Laboratory:

Institution:

State:

District:

Block/Town/City:

Officer-in-Charge:

Name:

Signature:

IDSP Reporting Week:-

Start Date:/

Diseases

End Date:/

/

Date of
Reporting:/

No. Samples Tested

/

/

No. found Positive

Dengue / DHF / DSS
Chikungunya
JE
Meningococcal Meningitis
Typhoid Fever
Diphtheria
Cholera
Shigella Dysentery
Viral Hepatitis A
Viral Hepatitis E
Leptospirosis
Malaria

PV:

PF:

Name of Test
Done

Diagnosis (Lab
confirmed)

Other (Specify)
Other (Specify)

Line List of Positive Cases (Except Malariacases):
Name
Age
Sex
Address:
(Yrs) (M/F)
Village/Town

25

<!-- page 26 -->

26
