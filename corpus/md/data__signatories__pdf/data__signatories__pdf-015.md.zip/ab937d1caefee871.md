---
doc_id: "ab937d1caefee871"
source_url: "https://www.dahd.gov.in/static/uploads/2026/06/405df9633add87aeebb01fee3629e003.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Applications are invited for filling up of one vacant post of Assistant, General Central Service, Group 'B', NonGazetted, Non-Ministerial in Level 6 of CCS (RP) Rules 2016 in the office of Regional Fodder Station, Hisar (Haryana) on Deputation (ISTC)"
date: "2026-05-07"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d1c3243fd810465c"
---

<!-- page 1 -->

mm ~~/Government of India
Jtct-QQIC'l.:t. 'flJ'l@~ 3f'h ~~ lt~~.Ministry of Fisheries, Animal Husbandry & Dairying
Q~Qi("f-1 ~ ~~~ fcl,:n-lr, / Department of Animal Husbandry& Dairying
~~ ~m ~~./Regional Fodder Station

me ~ : t·-cm-e1-i[C'J ~ . ft'tlt~ 12soo1 (t>Rmu11)/ Post Office Textile Mills, Hisar
t~cffl 01662-259184, i.Jl(.>f rfs.hisar-ahd@gov. in, web: www.rfshisar.com

Tcl./fax: 01662-259184, email: rfs.hisar-ahd@gov.in .... rfshisardirector@gm ail.com
Dated the 4rh May 2026

No: RFS/ 2-25/2018-Estt.

VACANCY CIRCULAR
Applications are invited for filling up of one vacant post of Assistant, General Central Service, Group 'B', NonGazetted, Non-Ministerial in Level 6 of CCS (RP) Rules 2016 in the office of Regional Fodder Station, Hisar
(Haryana) on Deputation (ISTC) basis
Assistant
Name of the Post:
General Central Service, Group 'B ',Non-Gazetted, Non-Ministerial
Classification:
Pay Band -2 (9300-34800+Grade pay 4200/-)
Pay level & Scale of
Level - 6 of CCS (RP) Rules, 2016 (Rs. 35,400 -1, 12,400/-)
Pay:
Deputation (Including short-term contract):
Method of recruitment:
Officers of the Central Government or State Government or Union Territory
Eligibility:
Administration or Universities or Public Sector Undertakings or Recognized Research
Institutions or Semi-Government or Statutory or Autonomous Organizations: (i)
Holding analogous posts on regular basis in the parent cadre or
(A)
Department; or
With six years of service in the grade rendered after appointment
(ii)
thereto on a regular basis in pay band I, Rs. 5200-20200 with
Pay of Rs. 2800 [Level- 5 of CCS (RP) Rules, 2016 Rs.
Grade
29,200 - 92,300/-] or equivalent m the parent cadre or
Department: and
Possessing the following educational qualifications and experience: (B)
Bachelor's degree from a recognized University or Institute.
(i)
Two years' experience in Administration, Establishment and
(ii)
Accounts matters.
The Departmental officers in the feeder category who are in the direct line of promotion
Similarly,
will not be eligible for consideration for appointment on deputation.
deputationists shall not be eligible for consideration for appointment by promotion.
(Period of deputation including short-term contract including period of deputation including shortterm contract in another ex-cadre post held immediately preceding this appointment in the same or
some other Organization or Department of the Central Government shall ordinarily not to exceed
three years. The maximum age limit for appointment by Deputation Including Short Term Contract
shall not be exceeding 56 years, as on the closing date of receipt of applications)

Note: For the purpose of appointment on deputation basis. the service rendered on a
regular basis by an officer prior to Ist January 2006, the date from which the revised pay
structure based on the sixth Central Pay commission recommendation has been extended.
shall be deemed to be service rendered in the corresponding grade pay or pay scale
extended based on the recommendations of the Pay Commission except where there has
been merger of more than one pre-revised scale of pay into one grade with a common grade
pay or pay scale and where this benefit will extend only for the post(s) for which that
grade pay or pay scale is the normal replacement grade without any up gradation.
Applications received after the due date or found incomplete will not be considered. Applications ( in duplicate) in
given proforma (Annexure-1) complete in all respects should reach this Department THROUGH PROPER
CHANNEL within sixty (60) days from the date of issue of this letter or from the date of publication of vacancy in
the Employment News/Rozgar Samachar, whichever is later, to The Director, Regional Fodder Station, Post
Office: Textile Mills, Hisar (Haryana) Pin-12500 I. Applicants will not be allowed to withdraw their

candidature at a later stage.
Director 1/c

<!-- page 2 -->

PROFORMA;vtr,I'
I. o=ITT,/Name (Block letter)
2. ~·an~~/Date of Oi11h
3. fH<fil:fl WTT ~

rnr® fcmt;

Date of entry in Government service
4. ~ tl{cfil,( ~ ~4.J.I~ ~ ~ ~ql~<{ffi ® ~
Date ofretirement under Central Government Rules

s. ~ ma4a1 m~, ~ ~ ITT
Educational qualification and training, if any
6. #<TT <fir mq{vl/ Details of service
~ <fir

t

o=m,

From

c=tcfi'
To

Name of
post

;:ro-m ~~cftl

~~Ra®~

fcw 7fCr cfi<l c4i

~~m.3tR

t ~ ~4~<1

® ~

m~1

I~

Basic pay and pay
level in the new
pay matrix

Nature of
appointment is i.e.
regular/Ad hoc

(~atcf ~)
Nature of duties
performed (in
brief)

(,

7. a) qJJ.tlo-1 ~ <fir ;;::JTJ.t'/ Name of Present Post held
b) 3Fftl Fzflfcf<{.tft".~

Whether Temporary/Q.P/Permanent
8. cldAH mR JfRfiR:rcJRRcT~ffl Flcpl@ ifTffiE

Present Pay and the date from which it are being draw
(acio-lJ.llo-1 ~ ~ ~ ~ t)
(Scale of pay also to be indicated)
9. fij, ~mmr1JITTfRfr <fir ITT
Whether belongs to SC/ST/OBC
IO. ftcqful,aT, ~ ~ ITT/Remarks, if any

~/Station:
dlft&/Date:
3Rfl4qF( $ ~

Signature of Candidate

<!-- page 3 -->

31-jffl<;it/ENDORSEMENT BY THE EMPLOYER
s.,-11f&k1 ~ mrr ~ ~ ~,~ ............................................ ~~ mr 34<lcfc1
fclq.(Oj fk.Qi~c1 ~ mrr ~ 3ttt ~ ~ mrr ~I <$ ,ff- t;l1lifulc1 fct;m ~ ~

% ~ ~c-1,<h ~ -Hc14'c11 J.1IJ.1c-11 ~ m ~ ~ ~ ~ ~ 3ft{ 3.fi<A

$'1 lcrl~l:fl .............................. .
Certified that the above particulars given by Shri/Smt. ............... ............... ...... • have
been verified and found to be correct. It is also certified that no vigilance case is pef!ding or
contemplated against him/her and that his/her integrity is ............... .............. ..

~/Statio n:
a11\a/Date :

~~ ~~/Sig nature with Seal

of Office
chllllc-14 m/Head
.:>
