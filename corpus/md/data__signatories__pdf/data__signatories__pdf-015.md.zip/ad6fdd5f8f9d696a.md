---
doc_id: "ad6fdd5f8f9d696a"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/4ca03504b1a7787e419fea9f5eccd624.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Guidelines issued by DPE-Implementation thereof"
date: "2023-11-03"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a1490794cd581b0b"
---

<!-- page 1 -->

Tio w-02/0008/2023-p PE (wc)

fuf,dTf,q

eilo' rgq*ft*

cto ggq utF[ , qTo. Tio lq,

fr.fr ofr.onq0-w,eilfr ts,
T{ ffi-

11ooo3

pqio: 03.11 .2023

CIRCUI,AII

fr[I-q: Guidclincs issucd by l)l,li- Implcmcntation thcrcol- rcg.
It has comc to thc noticc of this dcpartrncnt that its guidclincs on lcasing ol'llouscs ftrr
officcrs in thc Contral Public Scctor Irntcrprises (CPSL) arc not bccn strictly lollowcd by
CPSIls. I lon'blc Division llcnch of Lokpal of India has obscrvcd that dcspitc thcrc bcing clcar
guidclincs of l)l'}ll datcd 05.6.2003,04.[i.2017 an<123.7.2018 on lcasing of houscs, thc samc
arc not bcing adhcrcd by Cl'}Slis. lt is thc rcsponsibility of thc CI'}SI]s and thcir administrativc
Ministrics to cnsurc that such lapscs do not occur.

l)t'li OMs dalcd 05.6.2003.04.8.2017 and 23.7.2018 aro cncloscd hcrcwith for slrict
compliancc.

'l'his issucs with thc approval ol'compctcnl authority.

/

%

14q1SqR)

3l{{qfu-4

l.'['hc Sccrctary ol'all Adrninistralivc Ministrics/l)cpartmcnl

2. CMD of allCPSIis
Copy to:

NIC DPL with thc rcqucst to upload this circular on [)PI: wcbsitc.

<!-- page 2 -->

t.3k a

No.2(16)/03-DPE(WC) - (r
Ministry of Heavy lndustries and Public Enterprises
Department of Publrc Enterprises

o

*L*

Block No.14, CGO Comptex,
Lodi Road, New Delhi.110003
Dated the 5rh June, 2003

orFrcE MEMo_BAN.aUM
Leasing of llouses for oflicers in the Central Pubtic [lnterprises.

Sublecl -

Reference is invited to DPE O.M No.2(49y98-DPE(WC)'dated 25,6.99 in regard to piay revision for the
boardlevelandbelowboardlevelexecutivesof theCentral Publicflnterprisesw.ef. 11.97. paial0of theOM
reads as under:-

"ln respecl of leased accommorlation, the boards ol public enterprises will have the flexibility to revrew
and provide for an adequate level of leased accommodation for the executives who are entitled to this facilig "

2. ll has come to the notice of the Government that there have been certain irregularilies in the rnatter of
allowlng leased accommodation, payment of higher rental value of the leased accdmmodation, aflowing leasecl
accommodation to non-entitted officers, allowing bigger accommodation to retatively junior offtcers etc. Such
practices have been seriously viewed by the Central Vigilance Commission.
Although the Boards of public enterprises have the flexibility to review and provrde for an adequate levet
3
of leased accommodation to their executives, the Boards should exercise control metrculously in order io see that
no ttndue advantage accrues to the concerned offrcers who rnay be getting their own houses/flats self. leased or
even getling comfrany houses/flats on lease basis ln this regard appropriate action on the following lines needs
to be takcn by tht: Boards of PSLIs while allowing leasad accornrnodatron to their executives:-

(a)

The Boards of PSUs may rdontify tlte executives who are entitled to leased accommodation and
notify the same;

(b)

ln case the company's own quarters/flats are given to the executives, these should be of the
entitled plinth area. Such entitlement would also need to be specrfred by the Board crf Directors,

(c)

ll any offrcer is allowed to get his own flaUhouse on self-lease basis, the payment of lease money
should in no case be trigher than the market rate keeping in view the area/location of the
flaUhouse. The basic point to be seen is that self-leased accommodation should not become a

'source of additional income by the officer concerned.

(d)

lf the cornpany provides leased accommodation after obtaining it from any private owner on
lease basis, such decision of taking the flats on lease basis may be taken after following the set
procedures such.as inviting quotations/openino quotations in the presence of others etc.

(e)

ln all case'.swhere the company provides leased accommodation to its executives or even allows
self-leased accornmodation to its executives, the Board of Directors must fix the plinth area and
the ceilings in terms of value whrch such area might attract keeping in vrew the categories of the
crties the executrves%re posted r.e. A, tl, C & unclassified ctties.

4.

l he administrative Minislries are requested to bring the above to the notice of the Central PSUs under
their charge and the PSUs may be advised 1o follow the alrove scrupulously. The adminrstrative Ministries may
{ike to monitor the implementation of the above conditions in their periodrc review

-1'*'*''"-

(Dr. S. Banerjee)
Joint Adviser
To

l'he Secretaries of the administrative Ministries
Copy to:. I he Chief Executives of the Central Public Enterprises

<!-- page 3 -->

tt

No. W-osloo s,a / e,otz -DpE (WC)-GI, -XIy /
Government of India
Ministry of Heavy Industries and Public Enterprises
Department of Public Enterprises
Public Enterprises Bhawan
Block No. 14,, C. G. O. Complex,
Lodhi Road, New Delhi-r rooos
Dated: 4.th August, gOlT
OFFICE MEMORANDUM
Subject:-Pay Revision of Board level and below Board level Executives and NonUnionised Supervisors of Central Public Sector Enterprises (CPSEs)
w.e.f. Or.ol.9Ol?-decision on allowances other than the allowances

under'Cafeteria approach'

,

The undersigned is directed to refer to para f3 and to of this department's O.M.
No.W-ozloo28/2o17-DPE (WC) dated I'd August, satl regarding the issue of
separate guidelines in respect of allorvances mentioned therein. After due
consideration, the Government has decided as follorvs:

(r) House Rent Allowance:

(i)

The house rent allowance to the employees of cPSEs will be at the

()11'Ing ra
follo*,inq
rates

Classification of cities
X-Class (Population of So Lakh and above)
Y-Class (Population of s Lakh to do Lakh)
Z-Class (Population below S Lakh)

Rate of HRA
24o/o of Basic Pay
teo6 of Basic Pay
s% of Basic Pay

The rates of HRA will be revised to e7o/o rs% & 9yo for X, y and
Z class cities respectively r,vhen IDA cross es 2So/o and further revised to
30% %oyo and tO% rvhen IDA crosses So%.

(ii)

(2) Leasedaccommodation:
(i) The Board of Directors may decide on the grade-wise lease rental
ceilings in a standarclized manner fbr the diflbrent level ofexecutives. The
amount of lease rental ceilings should be decided on its merit keeping in
view / linkage to the HRA amouRt, classification of cities for l{RA
purposc, pay-scales of thc executives, House Rent Recovery (HRR) rate,
etc.

(ii)

If an executive is staying in his/her ow'n house then normally he
or she should be entitled to the HRA amount but if the said house is taken
as lease accommodation for self*occupation pury)ose, the lease rental
ceilings (after adjusting the HRR amount) should not exceed the net
applicable I{RA amount.

(iii)

The HRR in respect of leased accommodation should be at the
filllowing rate, or the actual rent, rvhichever is lower:Classifi cation of cities
K-class

Rates of HRR
7.5o/o of BP

<!-- page 4 -->

(ir)

For accommodation arranged by CPSE in its own township, the

ifnn shall be 7.5o/o of BP (for X-class cities) / 5o/o of BP (for Y-class cities)
/ q,.1o/o of BP (for Z-class cities), or standard rent fixed by CPSE,

whichever is lower.

(S) Other Allowances/Perks: The following allowances will be outside the
purvrew of Ceiling of g5o/o of Basic Pay under 'Cafeteria Approach':

Work based Hardship Duty Allowances : The payment of work

' (u)based hardship duty allowance upto r2o/o of Basic Pay shall be
admissible for the period the executives / non-unionized supervisors
has actually performed one of the following hardship duty:i) For performing duty in Underground mines, and
ii) For performing duty at Offshore exploration site

(b) Separate guidelines regarding Location based Compensatory
Allowance and Non-Practicing Allowance would be issued later.
s. The additional financial impact in the year of implementing the revised paypackage for Board level executives, Below Board level executives and Non-Unionized
^Srp".iiro.r,
as mentioned in para g of the DPE O.M. No.W-O2/OO98/2O11OeelWC; dated 3.d August, 2017, would be calculated taking into account the OM
No. W-ozl oozS/qotl-DPE(WC) dated srd August,2orT and OMs issued on payment
of allowances.

s.

The allowances specified in this O.M. would be effective from the date of issue
presidential directive.

L.-

(Rajesh Xfumar ChaudhrY)
to
the Govdrnment of India
Joint Secretary

Administrative Ministry/Department (Secretary by Name) of the Government
of India

'

<!-- page 5 -->

Copy to Chief Executives of CPSEs.
Copy also to:

i) Financial Advisors in the Administrative Ministry,/Department
ii) Comptroller & Auditor General of India, 9 Deen Dayal Upadhyay Marg,
New Delhi.

iii) Department of Expenditure, E-V Branch, North Block, New Delhi
iv) Department of Persbnnel & Training(CPC Pay t), North Block, New
Delhi.

v) Chairman, PESB/Secretary, PESB, CGO Complex New Delhi
Copy also to

i) Prime Minister's Oflice (Shri Tarun Bajaj, Addl. Secretary)
ii) Cabinet Secretariat (Shri S.A.M' Rizvi, Joint Secretary)
Copy for information to

i) PS to Minister (HI&PE)
ii) PS to MoS (HI&PE)
iii) PS to Secretary, PE
iv) AS & rA FE)

v) All Officers of DPE
vi) NIC Cell, DPE with the request to upload the OM on the DPE website.

gF{r..^q(Samsul Haque)
Under Secretary to the Government of lndia

i

<!-- page 6 -->

F. No. W-02/0031/2018-DPE (WC)-GI-XX/18
Government of India
Ministry of Heary Industries & Public Enterprises
Department of Public Enterprises
Public Enterprises Bhawan
Block No.14, CGO Complex, Lodhi Road
New Delhi, the 23 r{gu1r, 291t
OFFICE MEMORANDUM
Subject:- Standard Terms and Conditions for 2O'1.7 IDA pay scales in respect of Board
. level executives of CPSEs-reg.
The undersigned is directed to refer to DPE's OM dated t4.12.2012 and to state
that guidelines on revised pay scales etc. in.,respect of executives of CPSEs following
IDA pattern of pay scales w.e.f. 01.01.2017 have been issued vide DPE OMs dated
03.08.2017, 04.08.2017 and 07.09.2017. Based on the Government policy declared in
these OMs, standard terms and conditions in respect, of Board level executives of the
CPSEs following IDA pay scales have been finahzed by DPB. A copy of the standard
terms and conditions is enclosed.

2.

AII proposals for pay fixation and terms & conditions of Board level executives
in 2017 pay scales may be finalized in the model format enclosed, as per the procedure
prescribed in the aforesaid DPE OM dated 14.12.20L2.

3.

All the cases where the pay fixation based on 2017 IDA pay scales in respect of

Board level executives of CPSEs have already been finalized, the terms and conditions
of such Board level executives may be reviewed in light of the enclosed standard terms
& conditions.

4.

"

This issues with the approval of the Competent Authority.

ge("<(Samsul Haque)
Under Secretary

Encl: As above
To

All Administrative Ministries/Departments.
Copy to:'
i. Secretary, PESB
ii. Office of the Comptroller & Auditor General, 10, Deen Dayal Upadhayay Marg,
New Delhi
iii. FAs inAdministrative MinistrieslDepartments
iv. Joint Secretary, Department of Expenditure, North Block, New Delhi
v. Joint Secretary, Department of Personnel & Training, North Block, New Delhi
Copy also to:

i.
ii.
iii.

NIC,DPE with a request to upload this OM on DPE website,
Director, Management Division, DPE
Director, GM Division, DPE

gr{/tr*-(Samsul Haque)
Under Secretary

<!-- page 7 -->

sTANpARp TERMS AND CONDITIONS FOR 2017 PAY SqALES
GOVERNMENT qF INDIA
MINISTRY OF
DEPARTMENT OF

Dated:.
To

as-

Subject- Appointment of Shri/Smt./Kum.
-terms and conditions thierof.

in

Sir/Madam,

I am directed to convey the sanction of the President to the appointment of

Shri/Smt./Kum.w.e.f.
1.1

as

in

on the following terms and conditions:Period: The period of his/her appointment will be for a period of """""' years

(date of appointment) in the first instance or till the date of
superannuation or until further orders, whichever event occurS earlier and in
from time to
accordance with the provisions of the Companies Act, 2013 as amended

w.e.f.

period by either
time. The appointment may, however, be terminated even during this
side on 3 rnonths' notice or on payment of three months salary in lieu thereof.

After the expiry of the first year, the performance of
1.2
Shri/Smt./Kum_ will be reviewed to enable the Government to take a view
regarding continuance or otherwise for the balance period of his/her tenure.

1.3

Headquarters: His/her headquarters will be at-

1.4

Pa)r Shri/Smt./Kum.

where the
will be
registered office/corporate office/headquarters of the CPSE is located. He/She
liable to serve in any part of the country at the discretion of the CPSE.

Rs._

will draw a basic PaY of
pay scale as per DPE
per month in the scale of Rs.-(2017

oM dated 03.0g.2017) from the date of assumption of office (w.e.f. date of pay revision
in case appointed earlier than that).
new
Dearness Allowance: He/She would be paid DA in accordance with the
IDA scheme as spelt out in the DPE',s OM dated 03.08.2017.

1.5

<!-- page 8 -->

Annual Increment: He/She will be eligible to draw his/her annual increment
@ 3%of basic pay on the anniversary date of his/her appointment in the scale referred
to in para 1.4 above and further increments on the same date in subsequent years
until the maximum of pay scale in reached. After reaching the maximum of the scale,
one stagnation increment equal to the rate of last increment drawn will be granted
after completion of every two year period from the date he/she reaches the maximum
of his/her pay scale provided he/she gets a performance rating of "Good" or above'
He/She will be granted a maximum of three such stagnation increments.
1.6

House Rent Allowance: He/She will be entitled to HRA as per the rates
indicated in OMs dated 03.08.2017 & 04.08.2017.
1.7

1.8.

provided.
Company's own accommodation: Wherever the CPSE has built residential
flats in the industrial township or purchased residential flats in the cities, arrangements
would be made by the CPSE to provide a suitable residential accommodation to
1.8.1

him/her.

1.8.2 Leased accommodation: If the CPSE is not able to provide residential

accommodation either in township or out of the residential flats, purchased by it in the
Headquarters, suitable accommodation could be arranged by the CPSE by taking the
premises on lease basis at their headquarters. The Board of Directors may decide the
size, type and locality of such accommodations as per DPE OMs dated 05.06.2003,
03.08.201 7 and 04.08.2017 .

1.8.3 Self-lease: If he/she owns a house at the place of his posting (Headquarters)

and is desirous of taking his/her own house on self-lease basis for his/her residential
purposes, the CPSE may permit him/her to do so provided he/she executes a leasedeed in favour of the CPSE. The Board of Directors may decide the size, type and
locality of such accommodations as per DPE OMs dated 05.06.2003,03.08.2017 and
04.08.2017.

The responsibility for repair
and maintenance of leased accommodation is that of the lessor. Lease rent will be
allowed only for12 months in a year and no additional amount will be provided towards
1.8.4

repair/maintenance of leased accommodation.

1.8.5 Existing lease deeds: The lease agreement signed by the CPSE in respect of

the accommodation taken on lease basis for him/her, if any, prior to 03.08.2017 would
not be re-opened during the pendency of the lease period. The lease money, in other
words, should not be hiked till the expiry of lease period. This proviso would be
applicable even if he/she had been permitted to take his/her own house on self-lease
basis.

<!-- page 9 -->

1.8.6 Office accommodation: No office accommodation at the expense of the
CPSE would be provided or arranged by the CPSE at his/her residence.

1.9 Rent Recovery:
1.9.1 CPSE's township/own flats: Recovery of rent for the accommodation
arranged by the company in its own township or from the pool of flats purchased by
it in cities and towns and so allotted to him/her would be made at the rate spelt out in
or the standard rent fixed
DpE OM dated 04.08.2017 from (date of joining)
by the company, whichever is lower.

1.9.2 Lease accommodation: In respect of leased accommodation arranged by
the CPSE, rent would be recovered from him/her at the rate spelt out in DPE OM dated
or the actual rent, whichever is lower.
04.08.2017 from (date of joining)

1.10

Conveyance: He will be entitled to the facility of staff car'for private use as
indicated below, in terms of DPE OMs dated 21.01 .2013 & 04.11.2013:
Ceiling on non-dutyiourneys
Name of the City
Delhi, Mumbai, Kolkata, Chennai
Bangaluru, Hyderabad

1000KM/PM

All the other cities

750KM/PM

Monthly recovery amount (ACINon AC) for private use/non-duty journeys
would be Rs 2000/- PM.

1.11

Leave: He/She will remain subject to the Leave Rules of the CPSE.

1.12

Club Membership: He/She will be allowed the Corporate Club Membership
(upto maximum of two clubs), co-terminus with his/her tenure.

Other Allowances/Perks: The Board of Directors will decide on the
Allowances and Perks subject to a ceiling of 35o/o of his/her basic pay as indicated in

1.13

OM s dated 03.08.20 1 7, 04.08.2017 &. 07 .09.2017 .

1.14

Performance Related Payment(PRP): He/She shall be eligible for approved
PRP as per OM dated 03.08.2017.

Superannuation Benefits: He/She shall be eligible for superannuation
benefits based on approved schemes as per OM dated 03.08.2017.

1.15

<!-- page 10 -->

1.16

Conduct, Discipline & Appeal Rules:

1.16.L The Conduct, Discipline and Appeal Rules framed by the CPSE in respect of

their below Board level Executives would also mutatis mutandis apply to him/her with
the modification that the Disciplinary Authority in his/her case would be the President
of India.

1.16.ZThe Government also reserves the right not to accept his/her resignation, if the
circumstances so warrant i.e. the disciplinary proceedings are pending or a decision
has been taken by the Competent Authority to issue a charge sheet to him/her.
1.17.
Reti rement/Resi g nation

after retirement/resignation from the service
1.17.1 Shri/Smt./Kum.
of this CPSE shall not accept any appointment or post, whether, advisory or
administrative, in any firm or company whether Indian or foreign, with which the CPSE

has or had business relations, within one year from the date of his
retirement/resignation, without prior approval of the Government.

1.17.2 In order to secure compliance of these restrictions, CPSE shall secure a bond

from him/her at the time of their employment/retirement/resignation in CPSE for an
appropriate sum of money payable by him/her as damages for any violation of these
restrictions in terms of DPE OM No.2(22)/99-GM dated 8th August,2012'

Lien: In case, he/she was holding a below board level post before his/her
appointment to the board level post in a CPSE, he/she will retain lien on their below
board level post, if applicable, as per the extant guidelines of DPE/CPSE concerned.

1.18

Z.

In respect of any other item, concerning him/her which is not covered in

preceding paras, he/she will be governed by the relevant Rules/instructions of the CPSE
concerned/Govern ment.
This issues with the concurrence of the Finance Division, Ministry of
dated
vide their U.O. No.

3.

Yours faithfully
