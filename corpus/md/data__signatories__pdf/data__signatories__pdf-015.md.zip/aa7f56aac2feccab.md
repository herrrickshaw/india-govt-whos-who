---
doc_id: "aa7f56aac2feccab"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/ababea97a817f1aa2d96533be7761f91.pdf"
ministry: "Labour and Employment (MoLE)"
title: "The Industrial Disputes (Central) Rules,1957"
date: "2025-06-19"
pages: 53
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "771c9213df55174a"
---

<!-- page 1 -->

THE INDUSTRIAL DISPUTES (CENTRAL)
RULES, 19571
/ 11 e:rercise rl/ t/1¢ I"IWI'YS cqlift'rrt•d l1y ~t'CIIOH 1(1 of Ilit• lntlu~l rih/ l )ispules 11t t, 1M7
I i 4 of 19471. f/It' 0 '1!1m/ GO!>mHII!'tll licrdllfl/lc1kt•s Ill<' f'ollowin,~ rult~>. t!w !lame lrntJing
"'-'"'' J>revii>tl.~ly rmbll.<lltd 11s '''''fllim( /1v sui> 61'clwn (1! t'.f llw mill scctitm, uamely:-

I'lUJllMINAftY
L Title and ~pplkation. (I) I hrc"<l t·11l"" may(..., t·all~u ti1e Industrial Disputes
(Central) Rules, 1957.
(2) TI\~)' ext~n<1 IQ U •1im> lt'frth>•'it•, 111 rciJii<lll ht .111 trl<ht<U'iol d.isput~s 1tnd
to the Stat~s in rcl.nion •111 1y IH ,, ind u~tri,)l .J l.,pu lc , ,mcern1ng (a) an)' inclustr)' ,·arri..d on by or und~r lh~ •ILithofity 111 tlw Central
G<lvemm ent or hy 1' r-ail w:t) tutnp.lny: <H

(b) a banking o r ~JI IIISil t,mn• (\>mpany, a mint', dl1 oilfi~ld, or a ma1or
purt;or
(r.) 3ny surh '-''l'lt"ltl(.,.j it\Justry a~ m~y t>.. 'P<'<ifit'd und~r s«tion 2(·')(i)
uf th~ Ad by the c~ntral Gowmmcnt.

,...,

2. lnterprelalion. In Ill<:><' ruJ,...., w•k"' there b ast> thing ft'J>ugnant in the
subject or rontc~t.
(a) "Act" means lh« !Jltlul>lnnl OI,J)Lilt'$ Act , 1'147 (l4 <Jf 19,17);
(b) ·chairm~n· means th•· ChAtrnw1 ul a Bo., rd 01 Cn11rt or, if the Court
consis.Js of one: per'S(m tmly. such person;
(c) ··committN" m1."ar•~., Worl' loJl\n\llllX' consll11•t~>d Ulldenul>-section
(!) or s..'Ciion .l of th•• A•t:
(d) "FormH llli!dll'- ,) f'Orllt U\ the' !:iChc:dUit• to the41' ntJe>.;
(e) "St.~·tiun" meat,. a ~ecl.lon (I( th~ Art;
(f) in relation to an indu$tri.tl di•pul<' in \1 Union lt•rntury, for which th<'
.1ppropri.lte Gnvcn•mtmt is th., C.mlral Govltrn m<•nt, rcl"rence to the
C~ntral Govemmcnt or the Government of ln(ii" ~haU b~ construed as
a ro?fercnce to the 1\•i•nin;,trat...r of the territory, and reft:~ru:e to the
C11ict 1.1bl>Ur C'om!lll%1~••wr {C~ntr<>l), Rcglunall.abour ConttniSStoner
(Ccr\tr.\l) ~ ·•d tlw '[AssistaJ\t LJbLIUI Commissioner (Central) I shall bt>
construt•d as •·efcr<'l1c~ til U1e "fpmprl111·c authnrlty, 'lppninted in that
4[(g)

bchnlf by the l\ctmilti~tnl\l11' ,, tlw trrr ltory;
with nderen"~ to d tlll»e (g) uf s.:ctlon 2, it is lwreby prescribed that-

1, VMt SJtO. 770, d,ucd ltlth MMch, 1?~7. I'\JhU:-.Iw-<1 \fl fhc C•\1'-Cit<' oJ lndi:.;, Extra.j Pt
11, .'>o<. 3(1), dated ll)th MMtl\, 19(>7,
2. Proviso omincd by r.$.Tt '!'-;~. l.1dh·1.l ~u. Jv•v·, ' 'Y/2.
3. Sul>>< by C ~. I( II~Z. d,,,,.,l I~lh l)CI••Ihtr. I~~'i
4 . S~1bs.. b)• G$1{. 1 1~2. d~,~od llith Ol!t'-'bw . l ~t:y

121

<!-- page 2 -->

122

The lndl.lstrfal Disputes (Central) Rutes. 1957

[Rule 3

(i) in relation to an Industry, not being an industry referred to in subclau~e (ii), c~rrled on by or under the author.ity of a Dep<~rtment
of the Ccntml or a State CovenUl\Cnt, the otflcer·in·charge of the
industria l est~blisluncnt shall~ the 'employer' tn respect of that
establishment; and
(i.i) in relati<m to an industry conceming rnilways, carried on by or
under the authority of a Department of the Central Govemmcnt,(<1) in the case of establishment of a Zonul R;iilw<ty, the General
Mannger of that Railway sha ll be the 'employer' in respect of
regtllar railway wrvants t>ther tban ca.-ual labour;
(b) in the case of an esmblishmcnt independent of a Zonal
Railway, the officer-in<harge of the establishment shall be the
'employer' in respect of regulnr railway sefVl\1\ts other than
casual labour; and
(c) the District Officer·ln·charge or thto Di~-ll'ional Personnel
Officer or the Per.'<Onnl:l Officer shall be th~.> 'employer' in
r..Sp;!<:l of CdS\lal labour employed on Zon<>l R.mway or any
oth<!r rnilway I:StJbll.qltmet\1 independoot o( a Zonal R.1ilway.j

PART I
PROCEDURE FO R R EfERENCE Of INDUSTRIAl Ol SPUTES TO
BOARDS O F CONCILIAT ION, COURT OF ENQIJTRY,
LABOUR CO URTS, INOUSTRlAl TIUBUNAI,S OR
N AT IONAl TRIBUNALS
3. Applkation,-An appUcntion under sub-s<.>ellon (2) of scctiou 10 for the
rekrence of an ind.ustrial dispute to a Board, Court, Labour Court, Triburn~l or
National Tribunal shall be made in Fonn A and shall be delivered personally or
forwarded by registered pG''t ' Ito the 54!cr"tary to the G<:"emment of India in the
Ministry of Labour and Employm~nt (ln triplicatc)J the Chi.e f labo\11"
Commissioner (Central), New Delhl, and the Regional l..abour Commissioner
(Central), and the Assistant Labour Commissioner (CtJntral) concerned. The
application shall be accompanied by a statement setting forth(a) the parties to the dispute;
(b) the sperifi~ matters in dispute;
(c) the total number uf wmkm.,, elf\ployf'd in the tmdertakhlg affected;
(d) an estimate of the number of workmen afft.'Cted or likrly to be affected
by the dispute; otnd
(e) the efforts mode by the parties themselves to adjust the dispute.
4. Attestation o f appliration,-The appli<:ation and the statem<>nt
accompanying it shall be sig:ned(a) In Uu~ cas.! of an employ('r t>y the employer himself, or when the
employer is an incorporntcd company or other body corporate, by the
agent, manager <Jr other prindpa l of(iccr of the Corporation;

I. Subs. by C.S.R. 811, dtll<'<l 3rd July, 19S'l.

<!-- page 3 -->

r/'le lndas/rial DISPcJI8s: (Ci!illlill/ Rules, 19!:J1

Rule B]

t23

(b) In th~ CaSt! of wurk1 "., ,, t'ltlwr ~y th .. t'rt•,idt'lll ,\11, I ;;,.n~t-• rv 11i ,, lr,,d('
union of thl' I'V(lrk nWI], Ill' bV til'(' 1'1'\ll'l'<<'ilhlti\'f"· 1lf th1• 1\'Pll,mrn onl y
a••thorist•d in th i> bdl<lll ~~ ,, 1\h'i'l lng ot tlw lli!rl.me n hf'ld ft•r the
pu rpose;
1

1(~)

in the-: case nf ..11 \ ht(.llvh..llllll wol'km.ll\, by thr wurknm11 tHn,s•Jit or by

anv offic~r of th~ tr:<ldtt uniwl uf wh\dt ill' 1.'1 H rnpmbl'l' 0 1 h\' .~noth~·r
wOrkman in th~ S.lm., (•o;t.lbliMhrnunl duh .tpthod"·(•d hv hin, in lh_i.,
b~h.,lf:

Provided tht~ t :SlLCh WOr'kma.u, 6 11dl ,1 U."'l:tnl't~J (tf <I ltilft•i( 1fll l1 c:Hk lU fUh t I
5. Notification of oppointm.:111 o l llt)a"l, Court, lab<'UJ Ct>url, Tribunal nr
National T ribunal.-111e ij pptlintnwlll of,, 111>1\rd, t ourl.
t nmt. I "bonnl

I,,.,,,.,.

or :-.Jational Trlbun~ l t(lgl'lhN with lt\l' n,lnll'' oll•l·l';.,.n·, <'t•n<titultnf> th<> lk>,ml.

Court, l,,bour Court, Tribunn l or '\nllcJn.11 I flhllllol l ,Jo,\ 11 I>~ n«l • ti~d in the Olfici• I
Gazetle,
6. Notice to pdriies lu nnminnttt repreM~nl.1hVtt"i. ( 1) I tht l t•njra l
Government pr()po~ tn ;1ppmnt ,, Bnurd , tt ·1h.1ll '>4•tut ·' t !f~hn' m t-\~rn1 lJ it• ~
parties requiring tht•rn t~) OUIOH1oltf ~ Wilhm .1 T't'•'"'«'11,tbk t ttW, r•tt""<)JN tO r--epr~ent
them on th.- Bo.1rd.

(2) n,. notice to u,e employer 'hall he li;•l\l lc• u,, t.'lllpll•\1" l '' rwn.•lll (If If
the employer 15. an incorp<)ratt-J """P~I\} ,,, ·' '"~" ,,,.., .... atl'. '" tht" o\j:.c II
manager <>r utlu:r prindpaJ offiwr Cl[ >Uth •••mp.uw 111 ht"-1
(:1) TI1e notice to the worknWl> ,1\,\lll'<· '-''Ill
(a) in fhe cac;co <t( workn•wn w hn •"• nh'~nd~·r .. ut .s h·.ll.io urut1n, tu the
Pn:sidcnt or Sccrt•t.lr)t ni th1· tr~H1f' umun; md
(b) m the <iiS!' of worl.mt.!n whl> ~1'<1 noLIJWI\1b,•rs ,,, ,, 1r.•de Ut'""' to •Jnv
tlnt' of the fi\'e rtpresct\t.tliV~ \It the WUr~f'l1t•f1 wht

h,\\\· ,Hfi·~t~"''i th~t
apl~llcatiun made ur'ttier rule 1; <H'd m tht-. ,,\. . ,· ~~ .:c..'r" '" lhl· rWHt.r
,hall al>u bt• ~~rlt tu tht• t!!nph>YI'r ~~ho ,I1.1U Jl'.p 1 ~1 o·llpl~ l)l~r,~·t on
nutit~ boards U\ .,, .;.:~•~PI'-'C..h.'l.L' tlhl""'-'1 ,•t lh1• tll un ..ntrMK(" tn r~,
prernii'<IS 1>f th~ t:"tablbhnll'tll

PAR'l II

AR8f'l'RA 1'1 O'N AG REf:.MEN l
7. Arbitration agre~mcnt. ·An ~rl'>itrnH,>n """''<'mt'ilt f,lr tlw refcrcll<<' ''' '" '
industrial dispu te to nn ~rbttrator or Jrhltraln,.,. >h.rll bt· t MJc• in h1rn1 ( Jlltl ,1\,111
be delivered per~onally or forwMde<l b1· I'CW"lc·r~tl pn'l '[b >tb1• ~wrn:l<ll') til the
Government of lndi.a in llle 'vUni~try tJf l..lbtlur (In trlpiiNt(•)] thu Chi<'f L.t!Jt,ur
CommissionN (Ct'ntral), NL'W D<'lhi, .md lh1· H••t-~hm.:~l J,,[1,' "' C'olnllll:>S•o•l<''
(Ceotral) and the 1\ ssislant I abottr Cm11 111i>•hln••r (C<·11t1nl) <~l< l<ull>ed 111<'
agrc<'mcnt sha ll bt• ~>C0<11p iH1ied by tlw C()li>!'rl l. ln wntin)!.; tlf the •11'1:>\tmh>:' ,,..
arbitrators.
8. Att~$tati<\n M the nrbitration asn:em<-nt. I lw 11•'11<1 r,,l""' "fl'"''nwnt .;hall
be sif;ncc.l 1. 1•'>· hy C.S.R. !•159, li•t<-.1 \ii!h M w, lq\>6
~.

Subs. ~y G.S.R. 19K. dl•t~d 21~~ M·•Hh. I ~)~U

<!-- page 4 -->

1:!4

The lnt:lvstrlal Olspvtes (Centre/) Rvles. 1957

[RuleS

(a) in the c~>se o{ an employcr, l>y th~ e m pl()ycr l1in111elf, o r when the
employf<r is aJ>inwrporateu Company w: CJthru· body corporate by the
agent, manager, o r other principal officer of the Corporation;
'l(b) in the case of the wvrkm.;n, by any offkt·l' of a trade w >ion (>i the
workmen or by five rt>pn•scntatlvc,. o f tlw WMkmcn duly i\Uthorised
In this behalf nt a meeting of the W<lrkmcn held for the purpose;]
2[(c) in the ca1<e of an individual workn•an, by th<! workrnan himself or by
a.•y officer of <1 trade union of wlti.:h he is a member or by another
workman in the snmc c~toblishment duly authCJriscd by hinl in this
behalf:
Provided that surh W<>rkmnn is not a member of <1 different tr,>dc union.]
c:Cpl<mation.-ln this rule "officer" means an>· of the follo~"ing pfficers,
namcly:(a) th~ Prt>Sident;
(b) the Vice-President;
(c) the Secretary (including the General Secretary);
(d) a joint Secrt>t<1ry;
(e) any other officflr of the trade union a\rthorist..:l in thts blilialf by the
Pre;Jdent and Secretary of the Union.
3(8A. Notification regarding a.rbitr~Uon agreeJ~~enl by majority of each
pa:rty.- Where an industrial dispute l>as bee11 refcrr~-d to ;~rbitration and the
Central Government is 1>atisfioo that the P<'I'SOns ma.kl.ng the refctllnc:e represent the
majority of each partv, it shall publi>.h a n(ltification in this behalf in the Official
Ga7.ette for the information of the l!mployi!I'S and worl<n~en who are not parties to
the arbitratitm agn.>emcnt but are concerned m the dispute.)

PART Ill
POWHR, PROCEDURE ANO OUTlES OF CONCTLlATION OFFICERS,
BOARDS, COURTS, LABOUR COU RTS, TI.UBUNALS, NATIONAL
'fRJBUNALS AND ARBITRATORS
9. Conciliation proceedings in pllblic utility servire.- 1((1)] U1e Conciliation
Officer, on receipt of a n<Jtice of a strike or lock-out given undM rule 71 or rule n,
shall forthwith arrange tn intcrvic.>w both the employer and the workmen
concerned with 11\e dh.pute at such places and a t such tinws as he may deem fi t
and ,;hall endeavour to bring about a settlcnumt of the dispute in qu~stion 5.
'l(2) Where the Conciliation Officer rcceivllS no notke of a stri ke or Jock-out
under l'ule 71 or rule 72 but he consider; it necessary to intervene in thE> dispute
he may give formal intimation in writing tn the partio:s CPncemed dm:larins his
intention to commence conciliation prqcc.>edings wlth effect from snch date as may
be inserted th~rein.]
I. Subs. by C.S.K. J~~. doled 21 <I Mal'<'h, 195'1,
2. In•. by C.S.R. lU$9, d.tl<'d 30th Moy, t'lftl!.
J, .Ins. by GS.R. 'lll8, dllte-d 16~t M•t<'h, 191>5.
4. Rule 9 tc-numbered •• sub-rule (1) by l~.S.R. 1220, d.>tt'<l 7th Oct,,bct, 1960.

S. Added ~y C.S,R. 1220, dattlll 7th Och'll><'r, 1%0.

<!-- page 5 -->

Rule l OB]

rne Industrial Disputes (Central) Rules, 1957

125

10. Concili• li un proce~d.lngs in noll·pltbllc utility servi<'e.-Wiwtt' the
Cont;iliJtiOLI Ol'fic~r r;•rt>Nl'~ ~ny inf,mn~tihl1 ,,IJ<>ut "" t•id•tin/( ''' ~j>prt•hendrd
indtlSt rial dispute whkh docs nol tvl~ltl to p11hlk utility >lo'I'Vicc! olltl he carl$iders
1t D{'C"'~"IJ' 1·o in lwvmr· li1 lh~ cliopule, 1\r '"·'"~\I V<' lormal inti nwli<ll1 in wtiling
t<) the p:~rtit•,; (<mccrn~d .:l!•dnrJng hi~ 1nknli<ll1 IH <'!))11 nWMt' r;,~l'iliati<m
pn>ce.;d;n(is with o•ffe<'t fri>m such dl\tC .1s mnv lw ,.pe>'ilit:.j therein .
1[10A. f'arties to •ubmit st~ten1ents.- lh11 t•mplnvt••· or llw part)' rcpn•sen ting
w<•rkmtln 'fm in tht• mse nl indivlllua l wurkm.m, tlw workman himM!IfJ invoked
in an industrial d••rutc ,hall furwru•tl n st.ll<'ment S<'lting forth th<' '1'.-clfic m•tters
in dispute to the Cundliari()n Otfit."(-!r <'unturrwd wh~n~vt!r It is iutervljn.tion ln the!
Ji,;pute is requ~r,U. I
' !lOB. Proco~iling before the L.tbourCourt, Tribun~l orNatfon~l 'ltibuna!.(l) Wlu1e rt>f<•fllJIS a11 UlJu~triJI dispute ''" ildjucllcntlt111 to 11 Lnl>tlur Cl>urt,
Tribunal or \latitmol fribUJia), th~ Centro) C.-wernm~··· <tmll thrcct the rM'IV
raisitlg the JJSpute to tile it Slillt'lru'l11 Of dillni<Omplctc With l't•I('\'MI liOl.'l\mi'ots,
list of rellruwtt and wttrtesSo?S with tho L.tbour C1lurt. Trlbtlll•JI or N~ti0r1,1l I ribunal
within fifte~n Jays nt the receipt uf tlw <'l'd<•r <lf t<:'fcl\'r1,L' tlnd al<o forward n copy
of such ~tatem<'nt tc> <'ach "''~ 111 the "f'~"''' t ~ partie; lnvoll•l-.:1 in the dhpute.
(2) The Labour Coun, Tribunal o)t "'o1tton.ll 1 ribun~l dftor ·ll.<'ertnilling that
cupil>s of statement of d.1im .u-e fwnll>h•-..1 to II~ other ~icl(' by partY ra,.ing the
d.lspme $11.1!1 tl' the lust 1\~aron~; <•n .1 Jak not beyond om· month from till! dat~
or receipt of Inc otdcr <ll r·cf<'n:nc.: ~n•l trw <lpf>O!•il•·pMty ur !'<'ttl~'- !>h~ll fil~ th~<rr
written ~t.ltcmcnl together will\ d<~rumt·llb, 1M t•t rcli3n(C dOd wiht~ 1~tthin
a period nf 15 dayl' frnrn tlw d,11<: nf fi.~t bNrlf\)! J.nJ simuJI\lneousl\' fo,....•.ud a

"'P'. thereof to the <lthcr p~rh•

(J) Wht!re tlw laoour Cm.rt, TNbunal Of N.\tf110.ll Tribunal, olS the C.ll\C m.w
bt:, finds th~t the party raos!n~: the ,l.,plt<! th<1ugh d1rt>CII!d drd nol tnrw.1rd th,•
copy Hf th" •latem,nt of dai:H hi th" upposltll pa.t~ u( parties. ll $hallll'v<' clin'<'lion
tu the wntem«<J pMt~ IH lumioh t!w l<lpl' <If trw slah•n\l'nt to thl' Opf"J~il1! rar~
or parne. and lor the smJ pwpo.e or' lu• M\V utlwr suftlnC<ll cau>~e, cxhmcl the h=
limit fur filing the >laielllt'ol ul\<1"' sub•• ul~ (I) ur lvritl~n slal•·m~nhrnder •<>h-rul<"
(2) hy an additiunalperio..J <li 15 <l;lys.
(4) The party raising,, d•splttl' m•\Y <vhmit ., r<')omcler 11 it dull>WS to do su,
to th~ writt•11 st~tement(s) b) Lht.' appropro,lt~ pnrty '" parh"" within a pl.'riod of
fifteen J >tys from th~ Cillng or writt~n statcm~nt by the IJ tter.
(5) The I ,Jbotor Court, 'I ribun~ l t>r N;<tiortal TribunDI. ,,~the .;,1sc "'·') h(•, shall
fix ,, do tc f(lr evidcnc.• w lthi:n , nw n~t•nth frnm til.: •late 1'\X:etpl •tf t"c stJt~nlcnl!.,
docwnent:-,, li6t uf witn~~Se$, ~lt:, 1 whtd i '"~lll>c l•r>IJJI,ltiiV withlll <ixty clay~ of

,,r

w,,,

the d ,,t(! <lJ1 wkk.h tlw uisput~
rl'icrred fm •td]tt<lk,Jttt>tt.
(6) Evidence •ha ll be wcordc:tl eilh~r In ColJJ t •lr on .1ffldavit but in the C<~>e of
nHidavit th« upposite p.wty , 11,1 11 ha"'' th~ rtj\ltl lo cross t',\.umir\c e,ld l (lf the
clep<ments fi ling the aHiJ.nvrt. A, th~ 11rnl c~nlllhlatlon uJ vnrh >Vrlnl.':;.~ p n ><·e.,ds,
the L.abo>ur Cr>urt, Tribuua l or N.lllonal Ttlblll\;\1shnll mnkv il hwmorc.n<lum of the
1. C::ubs. by (';.S,R, 857. ~1 11 tNJ :2ntt hm11. 11/tol ,
2. I I ~. by (: ~.J< l( l ~IJ, ~.~. , ,.,r1 'M)tb MiiY, 1,\IIIHt

3. .:;ut-.5 l'l\• (":.$.I< 'J)~. \11\k\1 I ~it), AIIJj\l)ll1 I''~ l

<!-- page 6 -->

126

The Industrial Disputes (C~ntral) Rules, 1957

(Rule 108

substance of what is being deposed. While recordi11g the evidence the Labour
Court, Tribuna l OT National lribuna l s h" IJ foUuw the procedure laid do~o~o-n in
rule 5 of Order XV ill of the First Schcdul~ to the Code of Civtl Prooedure, 1908 (5
of 19ot\),
(7) On completion of evidence either ~rguments shall be heard immedidtely ()r
a date shall ~ fi~ed for arguments/oral huaring which shaU not be beyond J
period of fifteen days from the dose uf ~vid.mce.
(8) The Labour Court, Tnbunal or "atlon.ll TnoUMl, as the ~ase trulY be, 9hall
not ordinarily grant an adjournment for a p<!l'iod e><cceding a week at time but
in any case not more than lhr~ adjournments in all at the instance of the pnti(lj)
to the di~pute:
Pr<>vided ihat the Labour Cpurt, 1 ribunal or National Tribunal, as the case
n'ay be, for r~asons to be recorded in 1vrlting, grant an adjournment exc.::"ding a
week a t a l'lme but in any case not more th~n thrt>e udjoumment:s at the ins tance
of any one of the parties to th e rlisput\:.
(9) 111 case "''Y party defaults OJ' fails to app~ar atany s tage the Labour Court,
'l'ribun~l or National Tribtmal, as the case may be, may pro<:eed with the reference
~.Y pflrlt and c;!ecide the ref~renc:e applicnlion in the absence of the defaulting party:
Provided that the Labour Cow·t, Tribunal or Natio!'llll Tribunal, as the ~aw
may be, may on the application of either part)' liled before the subrnT!;..~ion of tlw
award revoke the o•der that the cas~ sl1a ll proceed ex porte; if it i~ satisfk>d th~t
the absent-e of the party was on juslitiable grounds.
(10) The Labour Court Tribunal or Natiortal Tn1>un.11, as the case may be, shall
''tabmit its award to the Central Govemmem within one month from th;, date of
arguments oral hearing or within the period n11mtioned in the order of reference
whichever is earlier.
(11) ln respect of reference \mder ~ection 2A, lhe Labour C.o urt <lr h i bunnl,
National Tribunal, as the case may be, shall ordirutrily submit its awards within
,, period of three months :
Provided t:haHhe Labour Court, Tribunal or National Tril;>uM I, may, as a11d
wl'tcn necessary, extend the period of three months 1111d sh~ll recoa·d its r«ason~ in
wrtting to extend the time for submission nf the award for another specified
period.]
11. The Conciliation Officer may hold a nw~ting of the representatives nf both
p.1rties jointly or of each party separatcl} .
12. The Conciliation Officer shall C<)ndlact the procl!<ldings e:~:peditiously :and
in such manner as he may deem fit.
13. Ma<"e and time of bearing. ' ISublt'd to th.- pcnvi.o;icml. contained in rules
lOA and 1081 the sittings of a Board, Cour1, l..abour Court, Tribunal or National
TribuNI or of an Atbjtratw shall be held at such times and places as the C'hairman
or tl1e !'residing Officer or the Arbitrntor, as the case may be, may fix and the
Chainnan, Presiding OJficer or Arbitrator, as the case may be, ~hall in(onn the
parties of tl1e same in such maru1er "'hr. thinks fit

a

I. lro•

by S.R O . Ht, daaod 31sl 0 11<embc•, 1 ~57.

,

<!-- page 7 -->

Rule 201

The lndll$111.11 Ot~11IOS (Cer>tra/J Rules. 1957

127

H . Quuf'llm for Boards ~nd Courts.-'! h~ II""'"'" IWC'<'"nry to conshtute a
silting "I ~ 13oard or lnurl >htlll l>c• ·" fc tl lnw•
Quonun
(il In tht' "a·"'' nl llol."·.l
wht\l'l' tht! 1\~tmbttr of an,•mhc\fto 'l.f 1
2
wht-n' thl' 1\Uf\)bC..' t' ll( llll·ml~~r~ i'i 5

3

(U) in the ted><' ul """''
wh~rt" lhP nurnt'lt:t t.•l llU..•IHl't!r."t as t Hor~ thJn :!

1

wht•re thP. "'tm~·r ut nwml't•r:. b nlUrt' lhnn 2
but I<,.~ than ~
wheN lhe uun\l'cr uf m•·ml""N t-; :; pr m('rt"

2

3

tS. Evidence.-A Bmr<l, t '"" 1, I .lhnltr l uurt, Trll:>Ut'WI ur "'a tiona! Tribunal
or an arbitta lt.r
a•n•pl, ndm tt or .:nil lt•r ,•vid~ut(! .11 dny <t.lge of thP
pr(l(e."<ffnl\> heiu"' rt !hi rn ami "'ch m~rv1cr as 1!/he 1'1'1~)' think fit.
16. Administratiun of ooth. An:-' r'lwmhcr tlf ~ llO!lrti 01 CotLrl or Presiding
Offk<•r of a L.1~ur Court. Irlhun.•l or N,rtitmal Trlb11nal or .1n arbitcdtor rnav
admmi~h·r ~n oMh
•
17. Summons. Sunom'"" ,.,_,u,·c.l h1 ,, Bn.tnl, l nurt, I c1~>1tr Court, Tnbunal
or :O.~hon.u I rihUNI ...,,,II t>o· m I""" [l .u...t ma1 ~~~"~am p~r>On to produce
bt.funr it ·•ny t>oxob P·'f'<'"' o•t <•1!\l't
umc..•ut~ a~~tl thrn&' tn tht.- f'0"5eS~n ol or
unJcY lht· '"f'ltro• ''' ''"?\ !''''""' 111 ~111 "'") n.l~hn~ In tht.- matter undcr
iroH..,hgation ur ·l<ltutlk.ll u11 \11 till' !X,rrd Court. I.Jl-.>11r { ourt, Tn"bunaJ or
Nattunal lnbt,mal Whkh tilt• ·~~lid, (.uurl, Tnbllndl ur ~Jtrunal rribunal thlok,
""'~-..1r,1 fur th~ purp'"""' o>t 'll'h 101 ••sll)labon or adtudi<.Jtion
1
(18. Service of sunlrttons nr nor ice '>uloto'Ct tu the l'rovl~tons contained in
rule 20. •ll'Y JlOht.t' SUIIUl\UO"'t; rttM't.''i.... ur order I~UP\t ~\' ,, [~lr\1. Court, Labour
Court, Tnbunal. Nahunal l11hun.ll nr .m llrl'lttr.ll•>r cmpowl'rcd to I6SUe such
notu:e. >Umm\01!>. P""-"'' ur ur.t••r, m.1\ lx· "<·n l'll'itl'l..r p.·ro..>n.11fy or by registef'\'d
post ~nJ on the L"'""t ui ro•fuo,.rl l-1 thr• P"''" cnnccrncd to ·l«O!fll the said notice,
summc>n:>. prox~N> ur urd~t tlw •.moe 'h~ll be ,...,.,, 3)1~'" undcr certificate ot

'''"l'

oJ,,.

postmK·I
lq, Dr~niption of pa rtie5 inlNt•in case;.-WikN rn dl'ly prt~ing befnre
o lloMn, (. ourt, Labo•~r Tttllllll·'' <Jr 1\ialwno~l Trtbtllttll ''' Jll Arbttrator, there a re
nu m<\rous 1·wrsons arr 1l}l'd on .ll\~ "'ld~1 ... u~.:-h rt!r~l)f\"1 ,JM II be dt~Scribed as

lnfiVWN:
(h tlll ,-:urh p~.-·r~r"~n"i '':-. nr~~ mcrr.btUS t.1f any trw•..ll+ urtion nr nssociation
'tMII bt' lit"lcribt••i hy lh•• """'"of >llCh tro~dc Ut1inn l)t ,1ssooaliou; dlld
(2) all !!tUCh flt-'''lm:-. d-. ~,r..t nut mernhers of an>· trade union nr aSOQCiation
shall!>., d.,.-rll><~l in Mt(h mann~r as tlw IX1<1rn, <.ourt, I .1bour Court,
Tnbunal. Nahun.ll I nbun.ll or Arbitr~t<>r ,,, lht• m"' may be. may
detenllrr\e
20. Manner o( sendee in the case of numerous pcr..uns as parties to a
di sput~. (1) When~ thcr~ oll t' nli iiWI'IIti' )'t'rs•>n~ '" Jl.lrH·:~ to .Jny p roceedings
before a Board, l.Qurt, l.abom ( '<11 11'1, ' I ribun.l l or N.1tio mn l Tribuna l or nn
Arhi trtl tor {\nd su~h per:;<•o~ ..JrL' 1114\lll b~!r!' nf ,u\y h'ih,i •· un ion ur ;)~sociation1 tht!
J

"ub~.

bv c.,s.R. l l ~ t

,,,,tt~o 1 t t th 1 1\ h•t\t ...

ltrl~t,

<!-- page 8 -->

128

Tlle lndustlfal Disputes (CenrraQ Ruies, 1957

[Rule 20

servire of notice on th e Secretary, or wh~rc; ther<· i.~ M Se.cretary, on the pri11clpal
officer, of the trade union or associ~ tit>n shall be d~-emed to be Sf•tvict~ on suc:h

persons.
(2) Wil('I'C there are num<,rous pers<)I'IS as parties to any pro<:eeding bll/orc n
Board, Cottrt, Labom Comt, T ribunal or National Tribunal or an Arbiltatot nnd
such pe•·son~ are not members of any lTade unlon or association, U1e Board, Court,
Labour Court, Tribunal, National Tnbunal or Arbitrator, as Ule case may be, shall,
"here personal service is not pracbcable, (a lise the service of any notice to be made
by .lffll(lng the ..ame at or near the mam entrnnre of ihe establishment concerned.
(.') A notice ~rved in the maruwr ~~'I<)Cified in sub-rule (2) shaU abo be
cvnsidete..l as sufficient in the .:ase of such workmen as cannot be ascel'laint'<i and
follnd.
21. Procedure at ihe first sitting.-Al the first silting of a Board, Court, l..1bour
Court, Tribunal or National Tribtu'\al, tt\e ChJ iJ'man or the Presid ing Offi~er, a, the
case moy bl', shall call upon the pa1'ties in such or<,Jer a~ he may thi11k fit tn s tate
theit ca:,e.
22, 'Bollrd, Court, Labour Court, Tdbunal, National Tribunal or Arbitrator
m~y proceed er parte.-lf without sufficient cause be.ing sho....-n, any patty to
procet.'ding before a Board, Court, Labour Court, Tri.bunal, National Tribunal or
Arbitrator fafls to attend or to b" rcpr<>Senicd, the Board, ·court. Labour Court,
iribonnl, N.1tional Tribunal or Arbitrator mav proc<:ed, as if the party h:l.d duly
anendcd or h,,d been represented.
23. Power of ecntry and inspectio.o.-A Board, or Court, or any member thereof,
or ~ ct>nciliation ofli~r. a Labour Court, Tribunal or National Tribunal, or any
person authorised in writing by the Bo.u<t Court, Labour Court, Tribunal or
Nauonal Tribunal in ihis behalf •nay, ior the purposes of any conciliation,
1rwestigatJon, enquiry or adjudi,cation entrusted to the conciliatinn officer, 13Qard,
Court, Labour Court, Trib•mal or National Tribunal und er the Act, at a11y tiJ,e
between the hours of stmrise and suJl>et and in the case of a per$<ln au thoriS<:d
i.n wdlUlS by a Board, Cour t, LabOLtr Court, Tribunal or National Tribunal aft11r he
has g iven r~<:~sonabte notice enter a<\)' b uild ill!); fac!ory, \vorl<shop, or Cllher place
or prernlscs whatsoever, and inspect the same Many- work, machinery, appliance
or article therein or interrogate any person th~rein in respect of anything >'ituntcd
thercm or any matter relevant to the subject-matter of the ctmcilintion.
investigation, enquiry or adjudic..tion.
Z4. l'ov,ler of Boards, Cou.rts, l~bnur Coo'(ts, Tribunals and National
Tribunals.-ln addition to the powers amferred b~r the Ad, llo;trds, CouJIS, l.1bour
Court!:, Tribunals and :\!ational Tribunals <hall n~ve the same powe1'S as are
vesred in a Ovil Court under the Code of Ci\ril l'rocroure, 1908, wl1el'l trymg a Sllit,
in respect of the following matters, namdy:(J) discovery and iJlSpectlon;
(b) granting (l.djomnment;
(c) tt::ception of evid.,n(:e taf<(•n tnl nff\d avH,
and the Board, Court, Labour Court, Tribunal or National Tribw1al may sumtnOI\
~Jld <'Xa nti:ne any persol\ whose evidence appears to it to be material and shaU be

<!-- page 9 -->

Rule 311

fhe lndus l!ial Disputes (Cemral) Rules. 1957

129

dO>el'tl~-..1 111 1:>.· •• d1 il rtll.Jrt withtn the nu·.toun!; of _,.,nuns -180 and 41'1 "' Ill<' Code
of ( nmin~ll'nW<1ure, 11198.'
25. 1\.oe~~or•.-l'l'h<<r~ ....._,..,~sur> ,,,.... oppointed to adviSe a 1nbunal or
Nationo l I rlbun.1l umier s ub -><!<:IIOI\ (•I) <>f sectio n 7A o r S<tb scrtion (4) of
sectl,m 711 <lt' l>y th~ Court, Lab.,u r Cout \, ·rlibunol o r 1\'ational Tl'ibull,l.J 1111rlcr s ubSl''C'Iit>n (;>) nf " •d ion 11, the Com t, L1bo11 r Cuurt, Tribunal nr N~ltonal Tribunal
iiS the CJ"'' may bo, sha ll, in r clat io11 II> prtteCC<Ii11g bd<\re it, o b taln tlw uJvic" of
such \l~:,tlSSm'*', but such adv ice s h11 ll uot be binding on it.
26, Fee~ for cupies of awards or uthe1' documents of Labour Cou.rt, 'r'ribunal
o r Nation3 l 'l'rlbunal -1[(1) f.?"" IM nwkmg a copy of an awotrd '" "" ordvr " ' a
l..,lbour Court, Tribunal or !'o;ad01\lll r.••l•unal 01 anv document fllt•d in anv
prac<"'dtns~ bo?lt>rt' ~ labour Court, l • tbuMI w Natlon<U Tnh•"'al l>e charged 3't
thll rate of R~ I ~r page.J
(2) Jlur ;:~rHfytng a ~opy ot ilfl) 'u\'11 .m.trd or ord er or dO<YUttiCIII, a f<.>e of
Re, I >hu II b~ payable.
('I) lllpl' lr~g .tHd certifying fees sh,lll bt· paynbtc in ca~h in atl v.l.,~<>(4) Wht•t•~ ,, pttt'lYapplies for imm~dlnk d~livery of a copy ,,f any •twh awa rd
or n1·dev o r J ocum ent, an ,tddition,t llh · rqunl ltl o ne-ha lf of th~ fee l11v i <lbl~ tutti~•·
thi~ ruM ~h.•ll be pavable,

n. Oeclsion by 0\aj ority.- /\ II qu~·'tltm' .Jti, ing ior deci~iur1 <II ""Y tlleeling
of a Boar,! pr Court, ~.we wher e !he l<llln «>n>b hi tlf •me peNOn, >hall be ciecided
by a ma}llrll)' tlf the ,·core of the membt'l'llh~r(,Jf (in Cluding the Chaumnn) present
at !he llll"'!lmg. In the event of an l'tj\J11titv "' ''"'~ tht! C hatrman <h.tll nl1o0 h.w c
a c.1stinn "''\h'
'
21! 8. ('nFTCr tlon o l erron.-A lll•~r\1, t oun. l.lbour Court. Tri.bllnoll, NM10nal
T nbunnl ,.,. Arbttmll:>r m::ty a t a n_v tintc c:nr!\.~ ~m deridll mlsla kc- m· <-rnrr Mi..ing
frorn i1n it<"(\d.,n t~l sti }'"' or <:.lmis...o.;it)U in .UlV t''r()(t!'C'dings, report, aw.u d or ctt•(.' i~ion
eit her o f its q r hio "wn ntqtio n or o n appl1cathm or ,tny of the pa rH1~,]
29. !t ight n f rep.resentatiws.-TJ1~ 1'\:'pt·es~·nt,,tivcs of the pnrth!> appe<tring
bdorc ,, Bo,1f•cl1 Court, Labi>ur C<11J1't, l'rll>un~l or Nation~ l 'l'ribun,,l t)r an
A1hi tr.1to•· 1<hnlt hav~ the right ol ~Mmlna t •on, cross--ex.amin~tiun • nd of
ad d ressi ng tht' llc•ard Cuurt, Labolll' lourt, Tribun~l or N alinllal l'ribu11al or
A Jbitr,1 1o r v..•h\,n an cvidtmc:e has bi..'C:n ~,..)Hct.l
~0. l'rurccding• before a BoaT'(!, Co <trl, Labour Cout'~ T rib\ln4l or
National Tribun al-The procet.'<iit1g~ ht•f11rc a Board, Court:. L.lbo\tr CollCI.
Tribunal ur 1\utionul Tribunal shall \)" hl.'l.-1 in pnblk:
l'rov11kd that the Board, Cuurt, L.lh<•ltr ((lurt, Tribunal'" Natlt111al TrtbUllol
mo.y olt any , t.1ge direct that any w tlrW56
II II(' ex<~ min~J '" lt$ pr;..._'ecdtng;s l'>e
held 11'1 <,\merJ.

,It,,

l 'AJ~ I' IV
REM UNERATION Of CHAIRM/\N AND M EMBERS OF COURTS,
PRES IUINC omCERS O F LA.IlOUlt COURTS, T RlBUN AI.S AND
NATIONAL T RIBUNALS, ASSESSOUS AND WlTNESSllS
3'1. 'f'o'avclling allowanc~.-n1~ U1mrm.1n ,, " membe <.,[a BMrd or Court or
lilt' l'n~iding, Offic<'r ur an ASSE:>S<'T 11! a '·'""ur Cnurt, Ttibuo1al <lr National
'lm,. "' th•• Codf• ,,f Cr.mut..f l'n"'-'~U"'•, }q71 (: ui t-97-1-~
.Sut;... t•, l·!i K 116~ a~lt"-'! lrd f• lr\l+tr• 1--..'ii
1 Sutu, l\\ (,,S R t 15l d<tb:d lltJ ( \ hlt\t•r, W74

<!-- page 10 -->

The Industrial Disputes (Cenlra/) Rules. 1957

130

!Rule 31

l o'lbutt.\1, if a non-official, shall be enlitlud lo draw trav~ling- allowa nce and
loalhng allowance, for any journey perfoo·med by him in coru1cction with the
pertormam:<· uf hb duties, at the rate~ !lnmissibte and sllbject to the cond itions
applicAble I<> .1 \.ovel'nm~nt S<~rv~nl· d the first grad~ und er the Supplementary
Roue• ib'"ed by th., Central Govcmm~nt from time to time.
32.. re~~.-The .Chaimr~.n and a mcmb('r of D Board or Court, the Pre;'iding
t)flicer lnd an Assessor o f n Labo ur Court, Td:bunal or National TrlbunaJ
wlumNI'I' hi' is not a salaried offu:er of Co\'<'mmen t may be granted s uch lees as
rn.1 I' be ...,ncboned by the Central Governm<'nl in each case.
JJ, e~pen~ of wimes.~.-Fv<'f')' pNson who is s ummoned and duly
ath!>'Kh m •lllwrwise appea.n. a.. a witn<!J>>; before a Board, Court, Labour Court,
I rihun.~t •>r ll;auanal Tribunal or an Arbitrat<lr s hall be entitled k> 411 a llo wance
ft•r ,•xpt•nw~ ~cwrding to the sc,11•• lor the time being in force with respect k>
'witll'""''' in dvil courts in the St~tc w he re the ;1\vestigation, enquiry, adjudication
til' Mhitr. llion iJ; being concl ud ed

PART V
NOTICE Of CHANGE
34. Notice of change.-Any ,;mpl<>ycr in tending to effect any chDngc in the
c•mdilit>ns t)h.en~ce a pplicable to any workma.n in respect of any matter s pecified
in ttw F<>Urlh Schedule 1[.to the Act] •hall give notice of such intention in Form E.
111 he notice sh.tU be displayed conspkuously by the employer on a notice
l"l<trd •I th•· mam entrance to Uu' ..,.t.ll>libhntL'nt in the Manager's Q(fice:
l'rm'ld.cd that where .ut\' registered h"~de union of workmen elcists, a ropy of
tbe notice sh~JI also be sei'Ved by registered post on the secretary of such unioo>.[
~t

..•J

PART VI
REPRESENTATION OF PARTIES
31>. Form o f authority under section36. The authority in favour of a person
ur p<'r>.UM to rep1·esent a workman or grnup nf workmen or an employer in any
P">~t•<·•lint•, nndcr the Ad sha ll be in f'orm F.
37. l'.1rtie~ bound by acts of r~presentative.-A party appearing by a
t·t.vr.,•cnt,ohv~ ,t·mll be bound by lnc act» of that representative
PAl<T VH
WORKS COMMITTEE
38. \om;titution.- Any employer to whom an orde r made under sub·
bl.'dlpn (I) ol section 3 relate. ~hilll fur thwith p roceed to constitute a Works
Lommill'<'<' in the manner pR>scribt.od i11 this pa rt.
39. 'IJumbPl' of members.- ! he number <)f members constituting th<:
Cummitlt'l' 'h~ll l:le lixed so as to a fflJrd r<'prcsenlation to the variO\\S categories,
gwups <~n<i dM' pf workmen engag~d in, and to the sections, s hops or
d<!pM tnwnb of t!"' cstablislunent;
1 ht_ h~ (* S,R 402. dated llc.t M1uC'h, l ~oU.
R ,,,. ~ vttutt..-d b) G.S.R •ru. d,tt4'd ~1...-t Milrt'h, 1'960.

~

~

<!-- page 11 -->

Rule 431

The lndustnal Osovlo~ (i.et>lr81) Pu41s. 1957

131

f>n""ll'll •·••th· totAl numh.•r "' •nror>l'oo"T'I <haU not ~c,'C\il"l'flh .
I''''' i,lt'\1 horlh<?r thai Ill~ nurnr. '<II n·pr.·-.ent.Jitvcs of IJ\c workmen shall mtt
he It'"> lholll lhe number oi rep"··••rH.tll>r'> nl the employer.
40. Rfprrscnla.live> of empluvr·r. ~nhJr>ct lo the p rov•siOrh of lh<~ rul,;, the
rcprt·•t·nt.tlll't•s of the employer 'h~fll•r• "Vmina tcd by the employer and shall, as
f"' ,,, I'""''"'~'· l'><: tlffici,\b en IIi"'' t tourh wllh Ol' associotcd wleh the working of
th•• ,.,,,,h fl•luncnt
41. Cot"ultdlion with lrJde union,, (I) \<\'here an\' worllmtat of an
<"'t~rh•hmcnl.lr~ meml•O!l'~ ot J J'\•t:htt•r"ltrad•· onion thc:-l'mplover oh.IU ask th"
um•m to if'l(tt rn h1m if'l wulm,:t-

(.,1 hnw m.an\ ,11 th•' '' l•r.lll'1vn..ve i1'\Cmber. of the unir•n. ,,nd
ibl hP« then mt'mt-..·r-tnr " .i"lnl>uled among the
shops or
J-.'pv.rtuu:nb uf ~tw ,..,,.,.,,\..;hmtmt
(2) Wlwn· .m employer hJ' rt".JI-olfllo•l•t•lk>e that th(• infonnahtm lumlsh~d to
htm tm<h'l >Ub rule (1) b) "") t.·.•d•• linton i• t•I'IC, he moy, ,,fiN tnlorming U1c
lln(nn. r"l• ·r the mattt!'r to the A•>i,t.ll11 I ,\l><lLir t'om mi:,sion(•r (C<'nlr~ l) Cl'lll<""erned
lt>r hh d"'t<iml; .1nd the Ass.,t.ml L>hnur t'ommi"ioncr ((cntrnl), nftcr hearing
the pM th•.,, ~h.\ II <it!<:1tle Ult' rnatll'r .1nd h1' dt•cbion shall lx: lin11l
~2. Crnup of v.·orl..men'> repr<'M"nl~hves. On f<'Ccipl of 1hc m1orn1abon
c.lll<'<llur unrlcr ntll' 41 the L-mrl•" t·r ~lull """ •d" ft>r tht> <'IC'<'rim or workmen':.
r~P''""'"I.Itl\<' ''"the (.nmmJtlt" 111 ''"'Joth>Uf'!'11 • thn....._ In ],p I•Wcft"'t-f ~\ If-.• "''L:m,·f'\ ,,r th... ~•A'hl'~hn\t~nt ,,.fol£1 are
!nt•mbcoro;, nt tht., rP~I•,h·r,~J f ohh• lJOJOn!", JOd
(J) th\>M: tu l>t> dedl'<l b1 tllt' W<trl..nw" oi the ,.,to~bk-:hm<'l1l who are nut

"'"tl'""'·

11'\cmll~N of tht' n-->~i~lt•n·d h,hl~ union or unum..;,

bc..,rtn); th~ 'l...lmt! pruporburt tn t\H'h utht!r d.'! tht! unum mc·m~r~ in the
cstablbhmctll b\'al to lh" non·nwmbt•.-·
f>rO\
th.11 wh('r(' mM<' th.UI h. til th•• "orkmcn arc mcmll<'rs pf the unton
nr dn} mw nt tht• uniun~, nfl .. urh •h\ l"'''•ll shall N: n«1dc:
l"r<l\ ltlood futlho!r tlut "ht't<· ,, "'<>''""n~llr,•tle uni<m n£"!;li'Ct• or f4ib tu fum.,,\
the '"'""'"'''"'" ,.,.u...t ior under """'"'''" (II nt nue 41 w1ttun "'"' month of the
<.la.t~ nl il><'tll•tu:c n•qmnn& it'" nt-nl'h ,m·h mftmnatinn 'll(h untm•hJU tor the

1"'"'

purp<N· nl th1> rul« l"" ttcilt<-d ·'' tf II d1<l n<lt Ni"t
f'rlt\ t<lcd huthcr th.11 whorl' ·'"'' ,,.,,,,.,Ht'l! h.l~ ~n made h) lhc '""l'luyl.'l'
umlcr ,ul> nih- (2) ol ntfp 41 , th1• vl~ctlprt 'h.lll be held on ""cipl of lhl! ill!usion
of 1\~o,(,l,,nll uhour CummJo>IIHWI (L<•nlr,>l),
43. r:l~tlural c<Jn•tituendf,, Wl>t•rr· under rulc 42 Inc workmcn's
n·prt'"'"'·'""''~ •lfl' h> be cll'<:tcd <n l'>t> ~fill ttl!.. lhc workmen enlitlc..l tn vote shall
be di\ltl.-1 '"'" hw> dl'<:tnr.,l con-htn<'rltll'~. lhc t>-'11.' constsling of thi'S(' who arc
mcml't.''"' ol ;"J rcJ!hft>red tr,ld~ Ull!C''' .atu the otht·t of thof.e whu arc na~
l'n•vJ<kJ th<lt th<' emplnyt•r n.a', 11 hr Jh•nlc• lit, snb·dh'tde the 1jclcctoral

I

ctm-tihtrnn ,,, ron;lilut'n.-it-., ·" '""',,.,..mol)' t><o) and direct thai workmen shall
\'Ott' m "•itlwr f,) groupo;,, "-t""Chon ..., 'hnp"t nr df•r"rlmf"nb.

<!-- page 12 -->

132

T/le lrtdus111111 Disputes (Central) Rules. 1957

[Role 44

44. Qualification of cal\did>~tes for election .-An)' wMl<man of not less
than 19 years of age nnd with " scrvict! of not less than one year in the
establishmel\t may, if nomlnolt!d ns provid<•d in the'~ I'Uies, b.E' a cru1d idatc for
election as a reprc~~nta live t>f the workm<•n on the Committee:
l'rovided that thl• St!rvicc qu.1 1i flc<tticm ~hall not apply to the first <?k>ction in
an establishment whicl1 hru; been lp a~;srcnl'e for las~ than a year,
'fExplmwtwn.-A worl\mDn whv ka~ put in a c<ml;inuuus S(l.rvice of not k'Ss
than one year in two or mort· <:stablishmcnt' belonging lo the sante employer shall
be deemed to have satisfied the ~ervicc qualification prescnbcd ~mdl'f this rule.l
1!5. Oua.llfkation.s for votets~.::..AII workmen ~1·•~1 who are not Jess th11n 18
years of age and wht' have put ln "ot 110!11 than 6 months' continuous service in
the ,;stablishmenl shall be entitled to vute In the election of the represent« live of
workmen.
1[F.':rplmmtwJI.-A workman"'"' h,1.S pl•t in continuous service nf not less than
6 months in two qr more e&tablishl'ilents b<llonglng to thc ll<1me employer shall be
deemed to have ,;ati:.fit!d the St'J'vfcc qwilification prescribed 11nder this rule.]
46. Procedure for dection.-(1) I h~ employer ~hall fix a date as the closing
dato! for rec~?iving nomination• from candidates for election .\5 workmo:>n's
repreS4?ntatives on tile commlttl!t>.
(2) For holding the ck>ction, the ~mployer shall fix a date whiCh shall not be
earlier than t.hrce day:; and later than fiitren day• after the closing date for
receivmg no•ninations.
I •I II be:! noUiled at IC."\$1
-en <1ay~ In .i"dvanc;e to the
(3) The cL.t..; "•
wo.rlcmen <~nd the registered tr~de union or unions concerned. Such notice shall
be affixed on the noli~ bQard or givt>n adequate publicity amongst the workmen.
The notice shall specify the numher nl se•ls tn ~ ei<!Cted by the groups, sections,
shops or departmcnlS and the numt>o:r to !><: d~ted by the members of lh<>
registered trade union or unions and by the non-nu~ml:>~rs.
(4} A copy of ~uch notice shall be sent to ret,-isl~tt.'<l trade Wlion or unions
concerned.
47. Notninatfon of candidates for clecti4n.-(l) Every nomination shall be
mad e on • nomination paper in Ponn G ,·opies of whlc.h !ihall b« supplied by the
empJoyer to l:he wor kuwn requiring them .
(2} Each nomination paper $hall hC? ~gn~d by Ihe e<1ndldnt~ to whom it relates
and att~sted by at least two other voters b~longing to tht' group, st'Ction, shop or
department the candidate seeking election will represt'l1t, and shall be deliv~red
to Ute employer.
48. Scrutiny of nomination papers. -(I ) On the el i!)' fnllnwin~G the last day
fixed for filing nomin.<ltion pap.:rs, lh~ nomination pAJNrs 'hall be !len Jtinised by
the employer in the presenc« <•f the ranttidates Jnd t·hc nl"tt'" ting person~ and those
which are not valid ~ha ll be rcj~cted.
(2) Por the puJpose of ~ub·rule (1), a nol1llnatlon paper sha ll be he1d to be not
va lid if (a) the cand idate nominated i~ lndlglble (o•· member~hi p under rule 44, or
{b) the requireme~tts of rule 4,7 have nnt bee11 CMlpli\!d w ith;
1. Added by C.S.R lOi'S, Joled •lUI A.1lJSUSI, 1962.
2. Omitted by G.$.R. 1078, d,lle<l ~~~~ A•tt~u•t. t%2

1

<!-- page 13 -->

Rulol 521

133

l'r••l 1ded that whcrP a <:ano1l·loll•· '" 111 ollh:stu•~ pt:N>n "un•hl<· toJ !.'<' l'I'(",CI1l
Jt ttw linw "' ,.crutin~·. he md)l'<•flll •• I Ill\ oluthori:;cd 110n\llll'i.' lur lht' P"irc'>C.
'l•lliA. Withdrawal of c•ndidatro v~lidly nominated.-An} ('.lnd,.tntt• wht•s..•
numil\.ltio~' to1· c(ec:tion hct~ bi•t·n .lH fiJ'h'd mrtv wl1hd f<l\\' his ~,lndl\.t1ltm..! \Vilhiu
<18 h••ur• ll >l'c'oruplt'fior~ vf ••C'l'lll lny of nom m~tion
•1'1. Voting in dection . ( I) II the 1Wn1ber of .:llndid.tt<'s who hnvt~ lw••" v"lldlv

.,r

P•'P''"· I

llotidtutlt•<l t•; rqual to thC' nuJ1tl11•r 111 " '•'''• tht• ,-.,ndida tcs >ho1ll b~ fl'tlltwitf,
dt-cl~t<'\'1 dull e]E.'( te<L

171 It II> ''"' com.lituenn tht numf><·r nt l":lndnlatcs b more lhan th.! 11nmb<•r
o'll "''~I' wllo>tt...d tu it. •·o!ing '"·•II tJI.<• fl·l<l' <•II Ill<' day h\ed lur el...cti<>ll
til I he' t'lection <.hall No hch1 tn ''..:n 111 >nn...-.,. m.J\ be> n>m·mi,•nt for l'ach
t'k~ tur.tl o•cm~tit\tl'nco;
•
H) 1 h~ "'ling Mia II be «1110\l<t,-.1 I'>\ tho; cmplowr, and J
11f 111\• ,,,ndtddl:l.$
bt·l1mg .1 1mion ~uch ol them '" tlw llllltlll mav nommJt<' sh,l ll lx• .>WJ\:>~trd
wllil \Itt• ,.Jl-clicm
(~) h cry wotkman "ntitl••tl tO VIlle• oil oln electoral COI1lotltu~ncy Shtlti hiiVe •~'
11 llli1Y vnt~' .1~ there are "'als 111 lw fillo·tl in the consti tu~n~y:
l'uiVtdeJ th.Jt each voto'l' sh,1 1l l>o: <'11 1itlcd In ~<1st only OIIC vote in I 'VO\I r of .tny

""Y

t••

tlnt.• C".tndi d~IC.

SO. Arr~ngements for elertion.

fn•• l'tnpi(>Yer >hall be tC:.pllruublt> fur dll

arrnn~~ment.. ln connection WlU\ thl• t.·l.,>c.:lu•n

51. Offic~ts of the Committ~~--{11 lht• tmnmitt('(' wll h~''' o\nmn~ II•
offtCc·b<cdR't-> .1 Chainnan. a \ ~e,"(.h.llnn.lf• .1 ~an and a lt>uii·So:creLul 11~e
'!'"") dnd the Jomi·Sc<.'T('IM'I •h.\II bc l'il'\ted ~~ av) "-"'
·1(2) flw Chairman shall lx• nmn>noll,·ll hv the L-rnploycr trom 3mong..t the
employtr'' rrpr<'5(>[11aiJ.Ycs on i.l•~ Cunmllttl,.; and he ~hJJI. "' (.,. "" p<l'o•ihi(•, be

s....

thr hc•,>d ,,, o;o,tabbshment.
(:lA) Ilk Vk<•-Chairm .1n <11<1111,.. 1'11•'1~•·' by thl' member$ ut\ !he Conmllltl!l'
rc•pt<•M<ntiny. lh<' workers. (rum ~rthhl);"l th~m:,dv.."':
l'rm IUL'li that in the ~Vl'lll II( '''JIIoliil) tlf VIII<><; in the l'ir<'tinn pf tho Vkc
Chdtrrn,ln tlw matter >hall h1• clt>o tdc•,l h\ .I raw ot ~ lot. I
I ht• Committee ~h,1ll clc<l the "<:<rcl.trv au<.l th" Joint St.o.. re~ry prnvfdtoJ
th.tl '' h1·rr the Sccrc1<1n "' dc.t<...t fn•on auwng:,t lhe rcpresenrnthc> ut the
l'tnplll\ ,.,...,, the )•lint ~-ret.tt\ ,11.11 1-c· "''" t..J fwm amongst the r<')'rN:'nt.lhws ot
th~ wc\•Jrr-.u,...,, and ritr ..·t',-..11.
l ~,., tth·d that the post ol tiw s.~·,dan (If the }oll\1 S.:Crctary a. tlw c..;.e may
hc •h>llnnl !.'<'held by a repre,...nt.th• ,. of tlw umpi"Y''' nr thr workm~>n hlt hYu

n1

t

\.tt1',"'t'tUliH• \e.tr.."":.

'(l'r>~ll<l;·<l that thl' n:prt'<;C.'nt.lll\l"o rll the l'mplo,•cr $hall not take part 111 th~
••It'< '"'" nt the St.'Cfetar" or jwnt ""'' tcl.or\ , ,., the'~"" may b!l, fn•m 3m•m~··l the
rc)ltl'WIII•tll'~' ul th" worknl<~l ,,n.l •lllh tlw n•prt"o<'TII.,hn•" t1f lh<' wurlo.m('n :;11~11
b.> t•nlttl"l '" 1 utco in <u~h "'"'liOn~ J
1(4) In ·111\' elc><hon Wlckr •uh ouk (1), 111 th... ""<'litO( cqu.11itl <tf l't •k•. th"
R1.11ll't •h.>U be dedJed b1 " <.lral\ nl lnr I
52. I trm of office.....:ZJ< I) I'll<' tcoom nt lllttcc ot the rcprl'!'<'l\1.\llve!! 1111 tltl'
cnmm1lh"'' nth~,.•r than J n1cmlx-t -.:hu;..nt lttlill a casual \'<lCdn<:.v ~1-utiJ be tw~i ;wars J
(l) A ltletnb,·r chosen to iiiJ d .......u.tl \ ,1(\111( \' ~h31l hnlJ orfi, ,. tur the UllC'J'ir.,<.J
I;,Htl 111 J1j, prt«.!f'C""'"r·

I \tMC"-1 I'\\ '-• c.., I-:, 1C1~, liAh••f Hh 1\ur,urtl l';;,z
;J '-11h, ., t; o., J( 07'R. t.t.•h.J
. ~th ,\uq~• t tv..l..
J In• IY\ .::tR._ ~" d.b ~d \1,f('l• l "ltl. ' • I

1~1-1lJ$.h.

<!-- page 14 -->

The Industrial Disputus (Cenlrtll) Rules, 1957

134

(Rule 52

(3) A memt>er who w ithout ol.>tDining lc,we fm the Committee, fails to a~nd
three con~<J\'Ulive m~tings of the Cnm 111ilt~u sl,nlltorfc>H hi'l mt·mbersh ip .
r[s3. Vacan des.- h1 th~ (;VI/Ill of workmtm's rcpre.cntntive ceasing to be a
member under sub-rule (3) of ruli! S2 <lr ct•a,ing to ht· e mploy<)<) in the
establishm..,nt or in th•• evi!nt of 11b ~u,l~in)l to rCl'~'t!.<\ellt U1e tr«de or V~ation he
was repres.:!nting, t1r reosignntion nr death, .his succe~sor sh•ll be e lected in
accord,mce w ith tho pruvl~it>ns of thi~ part fmm Ihe ~a me cntegory, group, section,
shop or department to wi\!Ch th~ mcmht•r V~Q'Ith1g th~ scat bdonged.]
54. Power to co-opt.-The Committee shllll have the right to m·opt in a
consult<1tive capacity per~or\S ernphrycd In the .;,ta blishmenl having particular or
speciaJ knowledge ol u math•r under di,;,.'\J'''""· .,ud\ co-opted rnember !>haU not
be entitled to vote Jnd shJII be pr,..;,:mt •11 m(O(•til'lg• ••niy for the p<1riod during
whicll the pattkular qlrestion 1s 11dorl' the r..:ummilt<'c.

55. Meetings.-(1) Tilt' CommrHt'C m.1y m".:t ~s nften llsnect><S.1ty bu~not less
often than once In th""' months (a 'lu,lotel')
(2) The Committee $hn II at lilt first m~l'ling rt•guh1t,• fls nwn proce..lure.
56. Facilities for meeting, etc.-21( I)( The t?mployct sh.11J pro,'ide
accommodaiion for holding nlc'Cting!l •>I thO! Contn\itlee. lie shall also provide all
neci?SSM)' fucilltics to the Committ.'\' <1nd 111 tht• nwmbl.'r< then.'(lf for carrying out
the work of the Con\mlttec.11w CnrnmJIIC<' <hnll ordinanly mc.ct during working
hours of the estabti!<hmcnt ron<X1mcd on anv working dew .md the r"J'resentativc
of the workmen sha.U be d<'t!llll'<l ''' be l>n duty while attending the meeting.
3((2) The Secretan of the \ommittCt' ma} w1th the prior concurrence of the
Chalnnan, put up notice r~>g.nditlg lh1· wt>rk of th•' tt1mmitn.-e on the notice t>oard
of the establishmenL(
4[S6A. Annual R~tum•.-41) l;,v.,ry cmpl<>) l!t shall tm ur before the 1st day of
February in eilch ycM uplood annual rt>hlm' in P.mn (,1 l>n the w~b portal <>f the
Ministry of Labour and [mplt>)'ffit>nt ~:wing informahc>n as to the paliirulars
specified in respect of the pre.:•-dil1g I'CM
(2) Every employer on or bdore tht' 1~~ da) of F~bruar) in each year may file
annual xctums in th•• h>nn Gl to tht• et"'ccmed AuU10rity mammlly giving
information as to the parhculruo specified an re$pec1 uJ U1~ preceding vear.
Providt!d that dunng in.<p....:tlon, the 11\l>pa:tor/cont-emPd Authority ;;hall
require the producl'ion nf thv ar~o•mt:., books, n-gisler· and nthl'r do<;Umenjs ifihe
same are maintained u1 manual lnrm or in electronic form, as the case may be.
E:rpiPitillic>n..-For lhe purpoo~ nf thl$ ~ul:>-~·ule, tlu~ cxp,.es.~ion "elt.'dr<lnic fonn•
shall have the same m<>dJIItl!l ~~ a~siglled It> it in dau~ (rj uf ~('Ction 2 of the
Information Technology Act, ::10011 (21 oi 21l(l0).)
57. Dissolution of Wc>rks Conunittec. The Ccnt.tal Government, or where the
power under Section 3 h<\S bu•n dell!gated 111 .lnVnffirer or All fh1,1rity 1mder ~ttion
39, such officrr or authority may, ~fiN making'su~h in<]lliry as il or he 111ay d<X'm
fit, d issolve any Works Coll'\ll\itlcl' Jl ~ny lime, by <U'I 01~cr In writing, if he or it
1. St•bs-. b-\1 G.S.R. J151, t.t~•t~~t lith Od,li':IL·l', 1~7-4.
~, Rule s6 n::o-rtumbul'\xJ .u. !>Ub~ruJc (\) "'''"'r)f l•y C:.S.)t 11)7J.:.. rlt'lrd 4-th Angust. 1962.
3.

Arl d~d

~.

Subs..
G.S.R. ll7(E), d.lh:ct 2.~1h Moly, :!UIS, f(U n 1h• ,1\6;\ (w I.' .I. 2545·201-5~. EMiier rule
S6A Wi'H> .addt:d by C:.$.R. nms. dt\h+,l ·ht• J\uf~U~t . lY(.~t Rufl'-$ '56A, lx~fo re Sllbstit\lt:ion,

by (;.-$,fl., 11)7X, cl,1\~ •rt 1tlh 1\tJRI.J+,I, $\16:1.

,y

stood ~ tJnclel'!

"$6A. Suii'Jms:'l'''' oj rflurrtl, I l\1.1 ,.,, ,~· I <)Y'-'r :-~h" ll ~\1\)ml~ half yc:11'1)' n~tums iii tn
Form G t m triplk~\h! to th\' ,\,.,~t~ l11nt I 11buut Cnmmi~k~ner (C~ntl'3 1) COJ\CU'i\ed not
Idler tha•' the 2<)1~1 d.,y Qf lhC' m\111th tu)lmvul¥. tilt: IMii·yf..'.fll',"

<!-- page 15 -->

Aut~ 59]

Th& lnf}ustru•l DI5PIIIN; {Cf>ll/fjj/) Rtil~s. 1957

135

ls SJtls{ied tho t t he Comm itte" h.ts 11ol l•iul<t>ll~lllllt«J ln accord;UI\.e IVilh th••S<~
rules or that not Jess tha n 1w0 11\lr'tb til lh.: 11umtw r oJ rep resen t.>t ivcs of th"
workJiwn l1ave without anv ,.,..,,...n,,l•lt· Jt"lltkatlon failed to <ttlend three
\Ull~rn tivC-" meetings of the ('ununillt'( ! JI ltMt th~· CumntHtt-1:' ha,..;, for Jny Oth\-!r
rea~ •n. cea.o;etf t< ; functitln:

u,at

Pn;J\'id~J
"''hert! !:l \l\1ur.J..... littllUIIUtt.-' t.'-1 t.fl.bsoh ed. under this. rult! the
ttmph.1~1cr tndy, and if !K) ~t.uJci.llt~ lht· l ••r,ir~•l Cuvenmwnt or. a~ the ca."'(!. 11\.lY

ll<!,l" ;udlt•ffiLcr or auth!lnl\ 'h"ll t.tk.<• '"'I'' h> rt-,uru.titute the CuUlU)ith!e ill
·''-'((trd,\tt(~ \~ith thee mil.~.

l'AKI VIII
MISCFI IAN"F.OUS
58, Memorandum of settlem~nt. ( 1) A M!tllemo:nt <1rrlveJ at lu the cvurse llf
ctmdlL.lHtU\ pro~.-eedings l,)r t)thi.!J1 WJ~'t Mh.dl lw U1 fnt•tu rI.
(2) Tl\~ 'ettfement slt~IJ b~ Sif;tl<•u uy
(n)

in the ca~;t> of lin tu n ph,~ 1tr, 11} tlw 11mplqyer himsel f, t)r by his

. l: uthoriscd ~gent, (Jt'l w lwll llw \ 111pluy,'r is an tncorpnm ted compa ny
\)j' tJther bodV rOrpnto1t~'t hv lfH' 1\g(.).lll , manager {)T t)tht:r nri.n(ipt\J
\lffker of thC' corpun111111~,
1

tl(ll) in !h~ c.><e of the wm knu•ll, b\ <111\' oifitt!r of a trade UJ1lllrt tJf th~
wod~n1en or J-.y fin.! n·prPM'utatlv._..s of the \'l.'orkmttn July .authur~d
in :his beha lf at m~11hnn ur tlw wur!-m~n held for the purpow; )
21(<) in thP <115\" m th<' worJ... ,,,., n .m mdustrial dispu te undt'I'St'Clioll 2t\
ol the Act. bv the wor~"'•'" •:or1t~mc,i I

C:xplonaumr -In ihis rul•• "•>lfl· ,.,

Rl<··ln~

am ol the i,,llowmll (llfi(t'tS,

n"'lmttCVt.-

th" f're;;ident;
th•· Vice-Presitient;
(c) the s.>cn•tary (inrtudli\jl tlwl •<'n~r,tl Sc.:ro>tar•).
(tl} d Joint ~crelar):
(<') any other offict'r o f tlu tredt tlll i<m •11 •1horiS<.:d in tJ u;; belwlt by tho
President and. Sccrct.11' )' 111 l inton,
(~) Wht!rl! a settlement is aniw d .1t i11 lht• "''''"~ of (nndliatinn prnceed.it~g tlw
Com •liabou Officer shall Sl'ild a l't')'tll't I h1•revf 1<• tlw C.•n iTal Gov.,rnrnet~t together
w ith" copy of th~ memorandum nl "'ttlomomt "1:"''1by the partit'll to the diSpute.
(4) Wh~ra • settlemenlts JrJ II'\ .I .11 ht•ll''''''ll '"' employer <Jnd his workmer1
~>th41""·i:...e than in tht- .._uur~ of "tmrili.,lion prn(,•f.!ding bcforf! o1 Board or a
~ondliollloll Oflicer-, the parties tu thr• "''tth•m••nl 'lwll jvmth• send a copy tlu.•rNI
ht th" C<'nttal Government, rh<> t'hil•t I .thnm ( ""'mis•iuner (C<'~tlral) New 11..-lhi,
.nu.l the R"gtunal Labour Com"""""" r (t o•nt•Jh .1ntl to the Assistant L•l'<lur
Cunmtisstunet (Central) ~onc<'ffil'<l
.W . Complaints regardiug ch,,ng<• of (ond ltio11s of service, etf.-(1) !lvery
mmpldltll Wltlff ·~tion 33A ·'' n..- A<'l ~h.lll !-, prcs.ented in bipll<:ate fn
h>rn\ l 1truJ shall be accontp(lnit',l hv ·'' 111.1nv ~ 11p1tj$ of the: t.:Otllf l<'lir\l as Lhcn! ~;1 r"
opjlo~it~ partie:; to th~ complaint.
(2} Evt:ry complaint u.ndcr •1111 rult• (I) ' huO be venfied at the ioul l1y tha
\VIII'kll l~ll IOakmg it or by s(:omi' flll tl'l' rl'f~\!11 PNVI'tl to th.- ;;atis facllun nf th(•
(;1)

(n)

1 :o:;\th\\, l.,v C$.1t 2S-l. dnh:.-d ' 1 ~1 t\'l!'ll'd\1 HI W.
1 , ln.!- b)' ·t:.~. « ')Ilk.. dM\"rl ::n~.-1 111111' 1~117

<!-- page 16 -->

136

The Industrial DlsptJII/s (Control) Rules. 1957

!RUle 59

Labour Court, Tribtmal or Nationa l Tribuna l to bo acquainted with tl1e facts of the
case.
(3) 'rhe per~on ''erifying ~ha l l sr~Hy, by refc,·ences ro t11e numbeJ·ed
paragraphs of the complaint, what h<! vt>rifiC'S t1f hJs own kl1owledge and what he
wrlfies upon informa !;ion re<:eivcd and belicv~ to be true.
(4) The verification sh.ill be sigPed by th~ person 111aking it and shall stale the
datu nn which and the place at IVhiC:h it was 6igned.
6(). Application under section 33.-( I) 1\n employer intending to oblrun th.l
expn..,"<S permission in writing of the Conciliation Officer, Board, labour Court,
Tribunal or Natiooal Tribm1al, as thl' c~se O'lol'\' be, under sub-section ( 1) 1•r '!libsection (3) of se<:tion 33 shall present an applica lion in Foon J in triplicate to such
Conciliati011 Officer, Board, L.,hour L•JIIrl, 'frihun~l or National Tribtmal and shall
file along with the application as many l'Opil\' thcroof as there axe oppt'>St\e parties.
(2) An employer Set!king the approval ol the Conciliation OUicet, Board,
Labour Comt, Tribunal or NatioM I l'ribuJ1JI, as th" ~<~se may be, d My nction
taken l>y him vnder dausc (a) or clause (b) of sub-section (2) of sectirm 33 $hall
prt'llent an applic,ltion in form Kin triplicate to such Conciliation Oifieer, Bc..>.~rd,
Labour Cotu't, Tribuna l or National TtibuMI and shan file along w ith the
«pplkation as many copies thereof os th~r~ nr!! opposite parties.
(3) Every application under sub-rule (1) ur sub-rule (2) shall b.. verifieclnt the
foot by the t>mployer making it or by -on I<' other person proved to the .satisfaction
of t:lw Conciliation Otliccr, Board, Labour Court, 1 ribunal or National Tribunal to
be acquainted with the facts of the ~a.s<:.
(4) The pel'S<m verifying shall spt!C"lfy by rdcrern."<' to the numbered paragraphs
of tile applkation, what ht.> verilk-, nf hiN own kno"'ledge and what he ,·erifies
upon inforn'\;llion received and believed to be troe.
(5) Th~ verification shall b.. sign<'<'~ hy llw P"""'" making it and shall smtc the
<iatt> on which and the place at whkh 11 W~lS signed.
61. Protected workmen.-(1) Every register~ tmde union connectti>d with an
industrial ~stablishmen t, to which the Act •tpplic~, ~h~ll comtntUlicatt' to ~he
cmptoyt>r before the 1!30th April] ~very yrnr, the 11am~:~ and addresses ·oJ s uch of
the officers of the un ion who are empl<Jycd in th<~l c~tablishment and who, in the
opinion ol the union should be r~ognls<'d as "protected workmen". Any \'flange
in th<' incumbency of any sut:h tlffker ~h.111 b.- communi!:'"dted to the employer by
the union within fifteen day5 of ~uch change
(2) The employer shall, suhj~ tu M..:tic>n 33, sub-sa"lion (4), rt'Cog>U... wch
wclrkm~on to be "protected workmen" fur tht! J>nrp<J'ii.'S of suh-sectioJt (3) uf th" ""id
S<.'ction nnd communicate to the uniull, In writing, "~thi11 fifteen days of the fl!91!ipt
of the namt>:. lll1d addresses unde.; sub-rule (1}, the list of workmen ci!COgnisl!d as
prOk.'\'ted worknum 2{for the pl'riod of twelv" months hom the date of such
communication].
(31 Where the total number of n<m1es J"eeelved by lhe employer w1der sub-:rule
('I) exceeds the ma~imum number ol prote,ted workmen, admissible lor the
I, Sui>,.. b) G.S:R. 1283, dMtd Ulth tviJy.

19~"

z. ~"' bv G.S.R. 128.1, dated 28th M>y, t%9

<!-- page 17 -->

Tne lr.diJstnal Otsl>ui~H (CI!n/to31) Rules, 1957

137

~t.1t>h•hnwnt. under s..~•oo 33 uh •o'(l'"" (-ll. the emplo\cr -lull ~~~~~~rlc.e as
pnlh."\tc:"t w.,tkm~u only suLh nM,~m'lnt '1lnnl•er of ""urk.m~n~
t>rcmtlo•.I 111,11 where \here I' muu· th,ul one reg~tl!rt!d tr<11h• ''''"'" '" lhe
•••t.lhh•hnwnt, tht• nl(l\lmum rHuHl'<'l >11.111 "'" so distrrbutt>d by tlw <'l'iployeJ
~ m01111, th1• 1111ions lhut the 1\111111'~'·' of oecogrused p n>tl'd<.'d \YOrkmen in

inrlrvit.lu.•l uruons bear wughl) tlw ""'"" p roporHtH• to on•' <tnnthN ;1~ th"
m('l11bt.•r:;h1p Ii~ures of tht: lUlJtlll~. t hi.! c:mplo) er t:-haU in th.-1t la..;t.• int-irtMh.!· in
writrn.: hi the Pn;sldcnl or the !>o.-..11'1.11> "t th<' umon ttw numb,r of prnt<'<'l"J
wur~1m•n .,llniiNi to it:
l'tnl 1111'\1 lur!h\'T that Wl>liC 1h1 num"-•r (1t rrolt>ct<'<i \"(>ri.JlWn all->ltl'd IO a
unec;m und,"lt th·-. ·~nt- role r~,ll~ ,h,ttt nt tfw null\~., tll ofhc.c~ vi the unwn tH..Yio.:J.Ilt
pn..'b'h'-l*l, ~fw umon ~ho11f t"'it 1'""htl1'tf

"'""'It, t lhl" OftrC"" to~· ll"C.~·~n1~1-d ·lS

pn,tl'-h-~\ W4.1rknwn. ~nrh ~"'lf"\·hnn ._h,,ll"' m.h11..-. b' th~~.-. lll"'i,_,n .lr~,t, c•rtll"'hlnh.-... t-.·d

tu th~· c.•mplllVCr w-ilhi-n fit t' d•.c~y' nt ttw f\ 1 ~ ~apt u~ thl~ empiU}t't ~ t~.•tt<•l
(4) Wht•n ~ disput~ urisc> bctiVC<!II·lll t'lllf'lo)W dfld <UI) rcgi•t<·r~d Lt.u.lt'llfliOII
In «11\ l\11\ltcr• connected wtlh th" t'<'"'tl'oillon of 'prot<!<. ted wurklltcrl' 1111d~r tl16
rul1•, th~ ""PIIll! s hall b" rt•i,!rtt•d t11 tlw 'lllrl) Regional l.•bntu Ctllllllli_.lllllt!r
(C'entr.tl)url A"'i;tant LJbour Commh··llltll'r (C't•ntral) nln<"<'MI<'I, who>~<• deci,iun
tht-*Tt- 0t\ "'h~Jtl t"'C final.
'161. Applkation fur recover> uf .Ju...-( II \\'ht!re an~ mun"'' c' duelrorn an
emph.l\~r tu it \\Or ,man or d g:rc.)Up ,,f "ork1:M!n under a ~tlen".cnt nr .tn .J\\•atd
or ltll<.kl tht.· pro' r.lt~of Ch.tph:l \' 1\, 1Chaple.l VBJ th~ \\urkrn.m r•r rht.• group
ot \\Orkrrh rt. '"" lhi.' t.<\5<" m~n k• tt'·'' ·'rPI\ ut fotm K 1 forth~ rc"C•n l'r'\. n( tlwmoncv dw;
f-'r'"lVIdcd that in rtw c~l:,(• ot 1' J" 1 r~m .lul.hunst.J in w-riting h~ tht· workman,
''r ill tht.• ~,,,,. <II tht> dc.1th ol thrt w11rkm.u1 tlw a<,ignt'<' ur ht•ir 111 til•· tlt:t"ea>cd
workn1o1o, tlw •1pplic.ltion sh.,lllw "''" ''' m ~orm K 2.
(2) Whi'li' dr\} wnrkn1.1n or o.\ )frullll ~'I \-"t'')rkrncrt is entitJ~d to f\,'i '~iv~ t tom the
~mph')''' .my rnurlt!y or Jl\) lwnl'lit whtth '' ~.lp.lblc of being ~omputct1 in ll'rm~
uf mmwv, ''"' wt~rkman or th" t.truup u( wt•rkm.,n, .u the c.\!><' mav t>e. Ill•\\ ~ppl)
In the 'I"" rliL-J Labour Court U\ r ...., .. II til thc dclenrunahon 01 th(' amuunt due
ur, ' ' tl" <·'"' 11\il) be, the am••t•n• .tl \\ h1<h ~uch l'ocnt!ftl <-hvuld l'<' '''"'putt'<i:J
ll'tm ,.J,-.1 th." rn the ca~ <•I th, .tc.IUI ot a workman, •'PPh•·ahon ~h.tll bt!
maJ< m lurrn!.. 4 l-\ lht.• aS>Lgf\w '''heir ul the di'CC•''-''i ''nrkrnanl.
63. Appoonlmcn t of Comnti.. hmN. Wlwl'<' it rs
111 appl>\111 a
Con\mhsiun~r umicr sub·S<•cllon !1) nl "''''"" ~'I(' o( thl' 1\d, tlw l.4b1•ur Cou.rl
01•1) <1PP•llol ol pt•...,.m with t•xpt•ri••nt••rn th" pdrticuld.r indu.>tr_)-, trddc 1\r blt'IIICl>S
IIWI'h••,i 1n lh<· mdu;,tri.11 dbputr ur ~ f'''""" with e>.fJ"ri~n<e a'·' Jlrdge uf civil
court~ ur ~l~ •' stipcndMrv m,lhl'tr.ltt• ur ,,..,. .t f<pgbtrdr ur St•nt•tary uf ,, Lc'\bour
1

"'""'"''I')

,,r

Courl, TrllluMI conslttut,-d undt•r ·'"' l'rm·inc1al Art or ~!ott• A<l1>r nf .1 Labour
C•'tlll, f rrl •un.rl or \l,ltion.ll I ntoun•l•·;mstillttt>d undt•r tlw Ad nr uf lht• Lab.1ur

Appcll.llc ltibUI\.tl ronslituh:d under •h··lndustriall>i~putl"- CApf'l\'11•11<' l rillun.ll)
A•t. ~"''
I In
''r 1;-;R; 7''.1 d.'t \'\J ""n..i \t ..r I" tY.ot..~ tw.ll_
2 S\.llt.._ b~ '• :J N. tiS::' datt.,i l61h ~\~r,tt jw/1
) tn I•\ (~~u fffi'O, llrd lul\ tm

IJ..)..i"l.'\~t

<!-- page 18 -->

138

Tile Industrial Disputes (~ntral) Rules. 1957

[Rule 64

64. Fees for the Commissioner, cttr. - (1) Tiw Labour Court l'l>all, after
consultntion with the parties, estima~ thP. proh~hl~ duration of the enquiry and
fix the amount of the Commi;;s.i oner's fees .1nd oth,>r inddentaJ expetl:>e~ and Jh·ect
the payment thereof i!lto the rtenr~t l'rca~;ury, within a s pedfit>.d time, hy such
party or parties and in such proporlatlun 1\S it may con,ider fit. t"hc Commission
shall nnt issu~ •mtiJ satisfactory evidcn<'l' of the d~pmil into the l.rensu •·y of the
sum fix~:d ia filed before the Labour Cublrt:
Provided that !he Labour Court n1<1Y frmn tin1e to time direct that ~ny further
sum ot sums be deposited intt1 the h'<'ilsun· w1thln such lime and by wch parties
as lt may considff fit:
Prm•ided further that tht> Lahour Ct•urt md~ u1 it;. t.!iscretion, exttm.i the time
lor depositin@. the s um into thE' tr<'aSUI')'•
(2) The Labour Court ma~·. al any 11m<>, tor n·asons to be recorded m writing,
vary the iUllount of tl1e Commissic>~wr'q fcc> In consUltation with the parties.
(3) 'I h~ Labour Court may dircxt th~t the f!'E'S shall be disbursed to the
Commis,o;iot,cr in sucl1 instalments. and <Ill ~ut:h dak• as it may cons.ider fit.
(<\) The und isl;mr:>ed balance, il any, of t·he s lllll deposited ~ha ll be refunded
to th"' party or parties who deposited the~ ~t• m in the ~ame propo.rtion .1s that in
which it was deposited.
65. TIJne for submission of r~port. ( l) Evm·y order for the il!suc of a
Commission wU appoint a date, aliOW\1\fol ~uflicient time, for the Commissioner
to subudl his report.
(2) If for any reason the Conun~•oner anticipates that the datE' flJc~d for the
submission of his report is likely to b~ excu<>t.ll!d he -;hall apply, before Ute expiry
of the. said date, f<>r extens;on of tim~; J;t,ltini> forth grounds ther..'Of and the l..abc)ur
Court shall take such grounds inlu ~nnsiJerntion in passing ord111:s on the
app1!cation:
Provided that the Labour ( OLU'l m~y grarlt exten.•i()n of till\t' notwithstanding
thnlno application for such cxt('nsion has l.l~:en received from the Corltmi$sioner
within the prescribi.'d time limit.
66. Locallnvesligalion.-In any Industria l di~puw in which the LabO\ll' C<1urt
dee<ns a local invt.'Stigation to be requisite or pL'OpeF lor the purpv& t>f computing
the money value of a benefit, the Lalxmr Court cnay ISSue a commt-sion too person
referred In in rule 63 directing him to make such invteiligatiun and to report
thereon to lt
67. Commissioners .report.-{1) Tiw Commissioner after 5Ud1100llmspcctlon
as he deems n~ry and after r~udng tn writing the evidence tali.cn by him,
shall retu.rn such evidence togetl1er with his report 10 wliting :;igncd by him tot.he

Labour Court.
(2) The report of the Commissione r and th~ evid<;:ncc W:<-en by him (but not
ev idence without the report} s ha iJ be cvidt·nce il\ tlw industrial dispute ond s ha U
form part· of the recNd o f the proceedings in the' imh•,trial dispLtl~ but th~ i,,abour
Court or, with the permisaion of Labour Cuurt ony of the p;~rtie~ to tlw industrial
dispute may examine the Comllii.Ssion...r person.tlly be.f.ore the Labour Court
reg.w:Ung any of the matters referred to him Uf mention~ in his report o r as to his
report, or, as to the manner in which he h.><l macle the fm-estigation.

<!-- page 19 -->

Rule 70A1

The Industrial Oispvtes (Central) Rvles. 1957

139

(3) Where th e Labunr Court· ~~ lor ncly c'c/<ISI>II dissa tisfied with the procccdi"ils
nf the Comnussioner it may d iroct such fnrl'lwr !'nquiry tn be made as it s ha U think

lit.
68. Powers of C6m.mission~r.-Any Cnn\ll\issioner appointed under liWli('
nclc•s may 1mle;s otherwise clin'(·ted by fhc ''rd~r ol appointment·(~) ex;~mine the parlfu, lhem~lvc'> ~ncl 4ny witnesses whom they or any
of them may produ(~, aml ~".)' oth"r pecwn whom thl? Commissioner

thinks proper to <"aU uf>lln ''' fo}lvc "'~de.ncl' in the matter referred 10
lum;
(h) call fo r and exanuM dOC\•mcnts ~ncl other things relevam to the

subject of enqwry;
(c) at any reasonable time l'llh'r upon or lnto any premises mentioncol in
the ordt>r.
6~. Summo1ling of witnesses, etc. (J} The pru•·isions of the Code ol Civil
l'roc~dlU'<', 1908 (5 of 1908) retatint) lO lh(' ~llmmoning, a tt~ndance, exami~~atiot\
of wittt(.'SS<'S and p en<'llties to br• impu~t'<.lltp(m witnesses, shall apply to persOn$
•·cquired to give cvidence <>r to produru dot•tu cwnl> before the Commissionrr nntic:r
tlwsl:' rules.
(2) Every person who is "'lmmoood ;md appears as a w rlness beforo too
Cl>mml~>Sloiler shall be 1'l1litl~1 to pJym<·nl by the L!bonr CQur! out of the sum
dt:~>Siled W>der rule 64, ol ~n alluwnntt· tor CKJ"!!lS<!S incurred by hfm ll'l
~C\·ord.li\C'e' witl> the ~-ale for the tim~ l'>t·ing in ferro: for payment of such allowance
!(' Wltli~.....S arpearing in the Civil C..:ourt70. Kepre;;entation of parties bc(orv the Commi~ioner.-The parties to the
lndll.>t:ri,\1 Dispute shall appe.>r bclt~n: the Cuuu:ni.ss!Ql\et. either 1n person or by
di\Y other person who Is compl'ttmt to r.:pr.'l>E.'flt them in thE- proccedin~ bcrorc the
Cabo\1! Court.
1
170A. Prese.r vation of rrcords by the National Industrial T ribunals,
Industrial Tribunals or Labour Cout'ls. ( I ) The records of the Nationallndustria l
l'tibundls, ind<L~trial Tribunals or l.~b•ll • r Clturt:; ;;p.,ciHed u1 Column 'I <)f the
'!'able below· shall be preserved, fo r tlw rc•rinc.b specified in the corresponding cnh')'
In <'Oiumn 2 thereof after the proct·~ciillf;~ arc fi,lally disposed of by such Notional
TrlbW'I<lls, Industrial Tribunal,, l.llbou r Courts

TAiltE
Number o/ years lor
which th~ rtoro"ls
shall be pTloserved
li)

Ord•rs ancf )udgm"""' of NatM'•ll
lnrll,.lnal Tribun.ili, lnc!u.,tridl

Cribunals or Labour Courts.
b hibitv.d document;; in the ,,b<IV~
rtll'nt\Qn\.>d I ~lbvnat<. ot Court·~~
(tU) Ulh(•t r•~pers.

10 yeaN

\li)

I, ln.• by G.S:R. 93'1. datcct 151~ july. 1~15.

10 ye~ rs
7 ye-an,

<!-- page 20 -->

140

The Industria) Otspotll$ (CentrtJI) Rules, 1957

(Rule 70A

(2) Notwithstanding anything con tamed 1n ~ub-rule (1) the records of the
Natlonal lndu>trial Tribunals, lndustrl.ll Tnbun,\1~ or Labour Courts, connected
with writ petitions, if any, filed in the High Court<. or Supreme Court, or conn«ted
with appeal. by special leave, if any, fikod •n lh<• 5uprt•mc Court shall be preserved
at least till the final dispo<:al of such wr•t petilonn' or appeal by ~pedal leave. I
71. Notice of s trike.- (l) Ihe notiw of ,tnt..<: to be given by worknlL'I1 in public
utilily 54:r\'ice shall be in Fonn L.
(2) On receipt of a notice of a str1kc under sub·rule (1), the employer shall
furthwith lntunate the fact to the Concil~abon Officer having juri.<;diction in the

mancr.

n. Notice of lock-out.-The notia.• of lod.-out to bc givt.>n by an employer
carrying on a public utility ~cc ;.hall bo' m form M. '[The notice >hall be
displayed conspicuously by the cmpl•'Y''' till,, noliet: board ot the mam entrance
to the establi~hment and in the Man.lger'h Offic(':
Provided that where a registered trade union exists, a copy oi tnt' notice shall
also be 54:rved on the Secretory of the Unicm.J
73. Report of lock-out or strike.-TI1e notice of lock-out or >trike in a public
utility scn·ice to be submiUcd by t.h<' l'mploycr under su~tion (3) of
section 22, ,ru. II be In Form K
74. R~port of 11otice of strike or lock·ouL The n:port of notice of a stril"' or
lock-out to be ~ubmittcd by the employ•·r lmder sub-.ection (6) of section 22, 'hall
be sent by registered post or gi<en pcrsonnUy to the Assistant Labour
CoOIJJ\bsloncr (Central) appointed for 1<'1<'·'1 olrt.>.l C<>ncerned, with copy by
registel't.'CI post to(I) The Administrative De!Jartm~nt ol the C.ovemment of India
concerned,
(2) fht' Regional Labour Comnus~ioncr (C.·ntral) for th~ Zone,
(3) Chief Labour Corrunissioncr (t'••ntral),
(4) Ministry of Labour of the GoVI'rnrucnt of !ndin,
(5) Labour Department of the State Government concerned, and
(6) The District Magistrate concerned.
75. R~gister of settlements--The Conciliation Of6CM" shaJJ file aD "¢11)em<!flts
effected under this Act in respect of dll!puk'!> on the area within his jurisdiction in
a n!g~Sil'T mamtaull!d for the purpose as m Furm 0.
lf7SA. Notice of lay-off.-(!) U any w<•rl.mcn emptored in an mdustnal
C$1.\bll..hment .1s defined in the explanation below '«tiun 25A no1 being an
industrial establishment referred to in ~ub·,~'l·Mn (1) of that !\<'Ction is laid·uff,
then, the empiHycr roncemed shall gi,·c not•ws of commencement and tcmunati1m
of such lay-<>fl in Porms 0 I and 0 2 re:.p•·< Hvcly wiU\in seven days of suc:h
comrncucenwnt or terminalil>n, as the ca:w 1113)' be.
(2) Such noticl'~ ~hall be given by An employe•· in every case ioTe~pectivc of
whether, in h.is opinion, the workman lnid oH is nr is not entitled to compen$,ltil>n
under li(.'Ctioo 25C. I

I. Ins. by CS.R. 1151, dated 8th ~·r, 105'1
2 . ..... ~ C:.S.lt 229. dated 22nd 1-<bru.uy, 1%11

<!-- page 21 -->

Rule 761

The lndusrrial DtSpures (Central) Rules. J957

141

1!756 . Applk ati'o n for pcnnt~~ion for lay-off under s cdio11 25M.
(l) i\pplk"Hon for perm ission to In)' off .my w11r kman ttnder sub-sed ion (J ), '"' It•••
prrn1b;,Jc" ' w continue a lay-off und or l f;ub ~•·rti< •n (3)] (ia) of ~ection 25M ;hnll
be~ made In Potm 0 3 and d elivered to lilt~ ,luthnrity $pe<:ified W\der S\lb·~··ctlou
( I) either r~r!ltma Uy or by r egis terl!d P"~' .wknuwl~dg<IIrtent due RIKI w hco·~ lht•
·'Pplit'ation I> >ent by reglster<?d pmt ttw tl~tc• on wh ir h !he same .s dellverN1 "'
tlw "'lid Juthority ;,hall be deemed to t'ot• th,• t1alo' tm whkh the applicath>n ·~ fllild~.
for ttw purpl>'l<~ of :(;.ab-se<tion (!'Ill ot lh~ !i<1id sechon.
'1(2) Th.. applicallon for pemu,..ic>n ~1><~11 bet made in triplicate and "'P'"'' ot
•urh olpplirnl1on shall be served t>y the cmphl)•~r l)n the workmen conn•nw<t 11nd
.J pr•M>f h> that efiect shall also IX' •ubm111...! by the eruployE't along with lht•
ol}>phmllun.l
(.3) I ho• employer conct'l'n~tl 6h<lil f11mlsh to the authority tu wh1•m iht'
!lpphcotir.m fnr permi~sion h a.; l?et!n made such further infom,ation .1S the
,1uthorl ty considcfS necessa ry for arriving a t ,, decision on the applicatltm, ,Is <lnd
wht.i<l ~.,Ucd fo r by such autht>rity, 't>~stu enable U1c authority to comrnlll1 iCIH!~
t·hc p!•rmiss(ul\ or refusal to g t'•1n l pcrm isr.icm withil1 the period spedfic•d ln 'l:>~ lb­
,ectron (!ill of section 25M.
(4) Wher-e IhE' pE'm lission to lay•<lff h11oiJei!n grnnted by the 5aiol ~utlouflty, tlw
emplliY~•· cr>ncr.-rned shall give tu the ltq(lunal Labotrr C!!mmi>ilionet (<.:cnh•J11)
'"'"l!llll'll, • notice ot comment.mn.-tlt .tud h·rmmotion uf sud; lav-off ho lllrtl•·· <'
1 .1nd 0 l n:~pectively und Wh(!('(' J'CrTni!<~i<ln t!l cvntinue a iay-olf h•l' l•t"('ll
gr.lnii'J hy lhu said authority, the emf>I"Y''' >hall !,olVe to !he Ref,iot-.11 I ·•1.>•'111
Commj,,,iom:r (Centtal) concerned, a nob(<• llf fommencement or ~ud1 l.o\y·!•tl ill
Form 0 I, 111 <a<,e:;udt a tlOtice has not ~ln·o1dy ~"" );i\' en under •uh n1le (II of
rult• 7~1\, dnd a nufu:e of termio.;tion "' '"'" J...y-uff In Fllnn 0 2.
(5) I h~ rmhce of commcncenw nt .utd tt!l'mltlation of lay-off referreJ to ill sub
nok (4) slt~tll l>~ given ,_;thin th1: r~rmd s pet·ifkd in sub-rt•le (I) M rul., 75A.j
76. Notice of i·ctrenchmenl.- [f nny <'mploycr d•:$ire$ to •·~lrench nny

workmtlll ~mployccl in his ioidustrl~ l ~5lal:>l i.shmcr1t w ho has bt!e)1 In (()1\iliiii(IIIS
•<·r·v ice tor not less than one year undcv )1 l111 (hrreinafte r referred to iiS 'w<>rkrt\an'
in thl> ru h1 and in rules 77 arnl 7!i)1 Ill.' sh,, lt givt> notie« of s uch relrcnrhn11•nt .ts
in f•t>rtl> 1' to the Centra·! Govenun<!J111 Lhe Hcgi~;~n.,l l abour Cmru:nissiat•c.>r (\ o•r•tr.ll)
,111d l\:<.,i$l~J1t L.1bottr Ctlmmissioner (lentr,,l) an~ t.hc Hmplu)'ff11!11t fxdiAn!'.l'
c<m.:~med ~,,.; such notke ,;hall b .. ;;<•rv••,J na1 that C'.ovenutu~ot. lh<• K<'!\itm.•l
I .1bnur Ct,nml.is;iortcr (G;ntralj, the Asst,;t,,ntl at>nnr C<>rrunis.stoner Kc·ntr.tl), .ontl
th~ f mplovmcnt irl«:hange .:OI'Kl'ml•\l tly reglhtered post \1\ thP fnllthVOI\S

m.\nncr·

<·•)

\l'h<'fo' notice 6 givel\ leo lh<' Wlltkrnan, non~~ of retren.-hmcnt ~·hliU b~
S•·nt w ithin three da~o tm111 the• clat~ un which n.otie<' i• givt•11 hr lht!
WDr krrumi

I
'
l

h1::_.. , J~v C.S.R L l(E), 11.Hed 5th Mllt\'h, IV?h.
!t.uh•. ~~v c;,o 2485 d~llt\1 11hh "'~t'. J u,,~~.
~• l h•, ~" L,S.R. 28'l, d>ie<l 2n.l MM<II, I'IIQ (1\.d
~~h> hy ~.o -oz4H5~ dat.tl! ..'!Oll -''~t>,

'""'

13+19$~)

<!-- page 22 -->

142

Tile llldustmll Oosputes (Central} Rule~>. 1957

(Rule 76

(b) where no notice L' goven ••• lht' wurkmJn anJ h..o •• paid one month's
wa~ in heuthcrrof, nollcc nt retrendlm.,nt ..hJII b.! ....•nt within three
days from the dat~ on wht<h ~uch wagt-. .m: p~ld, o~nd
(c) where retrenchmt!nl b carril'd out und~r iln agr~m~nl which speciftcs
a dnte for the tcrmln.lt!on of scrvi<;c, I\Ohc~ of r~trcnchment shall be
sent so as to rcad1 th" Ccntr.11 Govcrnnwnt, th .. Ro-gron~l l..lbour
Commis.sioner (Lt•ntral), thl' Assi~tant Lsl>our Commissioner
(Central), and the l'mrloyment Fxchangt> .:un.:cmt!d, at le.1st one
month before ~uch .i.ltc;
Provoded that if th<! datoo uf h:rmironon of~ •cc ~~-....! upon i~ ";thm J(l
dayo of the agrtlemcnt, the nc>ttw of R'lr.,nchment 'hall be "''"' to the Central
Government, ~ R<>git>nal l.1bc'tur Comou,.~ioncr (Ctontral), the Assistant
Comm1:,sooner (Central), and tilt! I' mpl.,\mcnt Exchang" cunnomt-d, within 3 days
of the agreemt'tlt.
1(76A. Notice of, and appllutlon for, retrenchment. (1) Notice 1(or, as till!
case may tx>, the application und~rl ,u[>-.,.'Cfion (1) of !oe<.hon 2$N for rcll'l'tiChment
shall be served in Form PA and -erved t>n the Centr.1l Cm t'rnment ur suc;h
authonty as may be ~-pcofi~..J to~ tlw Government under th., "'"d claUS(' either
~Uy or by regblt'n!d f'l-"1 ·Kknowledgcm.mt du" dnd where the notice "'
served by regs.-tered p<>"t. tht• dati' on wh1c.h the !;;lml.' ., d•·hvcred to the Central
Gon~mment or the authority !J\all be dL>emOO tu "-' <l.lk uf "<'tnce of the noti.:e fl•r
the purposes of 'fsu~oo (4)) of the .aod S<.'dson.
'(•-(
'1'((2)) The notice or, aq tht• c.1-e may tx>, the ~rplir.lhun, shall be made in
triplic,,tc •1nd copies of ~uch mlh~<' o>r, a• the ca;;e mny h<!, th<• .1pplication, shall
be ~rYed b) the employl'r on lht• wurkmcn concenw.J .1nd .1 proof to that effect
shall also be submit!OO b}· the cmplo1 cr alt•ng "ith th" nuhcc or, as the case may
be, the appiJcation.
•((3)) The emplo)·t'r conn'l'tl<>d sh.1ll hslllbb to th.- CmtTal Government or the
authonty to whom the ootlu' for rt-tre11Chnwlt h,, bt.'l.·n g"·m or the applu:ation
for pcrrrus$101\ for reli\<11Chment fw, bt.-cn made undl'l' '1ob-'-«llm (1) of !>L'Ctilm
251\, •uch turtne.- infom~.~tion as th<• CentTal Go1emmL'Ilt or.11~ the c:ase mav b.>,
the uuthonty consider.. noo...,o.;uy for"'"' •ns .:st" dL.._,,a>n un the notice or, a5 th"
C<l!>C IT\ll)' be, tile applicatilm, a~ .1nd when called fur hy •uch authority l>O ,,s to
cnablc the Central Government or tlw authority to conununlcMc it., permiSSion or
wfu11411 to grant permiSsion within th<' pcriod sfX'Cilled in ~ub-'I('Ciion (4) of section
25N.)
1(1768. Notice of c:losure.
If an t!111ployer intend' to dose doi'ITI an
undcrtaking he shall gi~e ll(ltin~ of >uch dO!>ure tn Form Q t•l tht' Central

I !no. b\ G.S.R III(EI. d•k<d '•h \t4n·h, 1'17o
2. SuM. "' so 2~. d.lod :!lllh \t., , 19i!S
\ Sul>-n.lt 12) onutk<l I>~ SO. 24i<~ J,ok.J 21>tl• \14\, !'/115
4. Sub-Nit (3) s.W.. by (,.S R '1<'1 dott'd ltlcl M.>mo, 1""2 lw <I tH.)9Jil)
5. "ub-ruko (~J ...,."11111bo;o;'(l '" '"~ rul• (2) b¥ S.O. .'4o5, tt.ue<l 20<h M•v. tq~s.
b Sub ruk (4) """"mbtrod ., ...~ n.Jo Ill l'V ~U. 24~5, d•l"l 21Hh M•y. 1'185

<!-- page 23 -->

Rule 781

The INiuslrm/ D•sptJ/es (Ctmlrnl) Rules, 1957

t43

Govcmnwnt, the Rc;;wn~l hll:>our Cmnmi'!"10I\~1 (Cctltral), the A$1l;tant L.1bour
Commi!<Sit>n<:r (Central)••1nd the Fmrtm n111nt r.xch~ngc concem~'d. b)' rcgistef<-d
pa.t.)
1
(76C. Notice of, a nd 3 ppliration for permission fo r, closurt!.-0) Notice
under sub-s<.'<:tJOn (I) ut "-'<'!inn !."-0 ul mtended cli!Sunt $haU bo> gh en in Form
QA and wn•"'l <Ill dw Cenh'.11 Guv ..mm<nt eitlwr l'>~'ro«mally or by regt"erl!d !><l!it
.lcltmwl(-dg~mt!nt dul'.
~I A copy ot o;uch ·•rphmtion !-hall be '<t!rvc"i ~tmult.meously by l'l>gistercd post

l>n thl' l't<">ident "' ~'<.'ret~ry uf rcs•.•tcrl!d tr.1dc union(~) functioning "' the
est.1bli!'l1rnent .>nd " no!J<e in tlllo rc):anl •l~<sll .1lso be dl!>pl.>ycd cnnspkuo~ly
b~· the emplowr on,, nc,tiCt' bo.uJ at th" rna on cntmnce to the cstabli~hmcnt for
the Information nl ,\lithe conttmed workm<>n ,,I tlw sMne llme wh<>n application>
arv .ervcd <m the C~nlrdl Gm crnnwnt.(

'l..'l
•1(2)1 Thl' nohcc, or, a. the «''I' m.l\ b1•. thl' apphc.11ion sh~ll Ill' made in
trtplicatc
'H3)) Th~ t·mpl":-'"1' c.•ncem<'<i 'h~ll furni~h tu the• <.entral t.ovt>mm~nl to
whom the r><IHc<' of itllt•nd<'ti dn•ur.. h;" "'"'" giv~n or lh~ applicatlun for
pt•rmissoon In cinS(' down
lx'<•n rna<i" ~uch further infonnation •I> th.ot
(.:nven1n1~nt con.-;idl'r~ n-._-c.·._~"l, fur #'lrrlviny, at a t.k~i:;.-iou un th~ notice, or, as the
calK' ma\' i.x', th" applk~lll>n, .1nci .-all• for fmm <uch employer.
n. M •l nhm• n cc of seniority list nf workmen.- flw employer •hall pt.:parc
o list of .oil wurkmc•n in th<' pitrtic ular c.;le!;ory (rom which l'<!lrcnchmcnt i~
contcmpi.JI<'(l arrang<'<l according to th~ ~lllorit~ elf their >Cf\'1«' m that category
an(! ~auS(' a <opy th~r<•nf to 1"!1! f"l~ted on a nut1ce bo.ud u\ ,, con.•pi<'uou~ pl.tce
in the r"'m"""' uf the mJuMrial ,.,hlbh~hmen1.11 lc.ht seven day• !Jel<>re the artu~l
date nf retrcnrhm~;~nt .
78. Re·entploym ent of ,..,lll'.nch ed workm en.-(!) Alle.l~l len daY"$ before the
,1,\t(, Ql1 whi.-h \ olCMidl'' arc In bl' (ill~'<f, lh~ t!111plny!!r ~h~ll arr.tnji,C for the display
em a nntk<• bo,1nl in ,, wn.,pirliiiU' ph11-e In tlw pnmuses ot tl\l' industrial
csli!bli.<hnwnt d~t..,ol~ of thoo;e ''~c"n'"i"" ~nd ,.hall ~'"'' givl! •nlimation of those
vaconoes bv ~"<'t:ISlNt'd f""il tu c•vc•ry nne uf all tlw r<lrt<ndt!!d wofkmen eligible 10
be .:unsidcr<.'\llhere<>f, to the• ,,c!Jrc.">• gin•n by him at the tim" or rl!lttnchment or
'" ""' hmco lhereaft~r;
Provtrll..:lthat whet•' th<' nun1ber ot ".och \'Acandes ,.,~than the number of
rclrenchl"d wQrktncn, it shall be •uflkic'flt ,r mtimation "' gi~>cn lw lh~ <>mployer
Individually to th,• l'Cninr ""'"' rcll'<'flrht'll workmen m the hsl nderted to in
rule 77 t11e number ut sud1 ,;cnil~r·mO&I workm<.'fl being double the number of such

h."

V~c~dl\~l.~

'
\'

...
5

ln.... b~ ti.:' K I Jt(l1, ,J.tk'tl ;th M.url\. l 1f!f\.
I not. h\'" S0 2-&3'i. ,ttb-"l.i lOth \t.\\ 1~115.
~Jh•·nilt•
Sul~rul"

(21 1l1'1dllt ,1

l.''' '-.(t H!'\ rl.Ut'\1 !/Jtk ~t.t}

1~~

tJt n ..-numt:o.OJt"Ci ~• .-.u)•·nlk t ..) b.., S:.O 14!l5 tJ,Ul"\i 20th M1\y, t'#Ji:i
Su.,_~._. HI ~·nU.at~u.··J .,!r W~' nt"-• t~ ln ~. .(\ 24.."' ,f,1tt'd 2t)th MA\ 198:;:

<!-- page 24 -->

t«

T1ul lndustnal Disputes (Central) Ru/6s, I 957

[Rule 80

Provuled furtht•r thai where th~ v•,·•ncy os of a dur01tion of less than one
month th1>re ~hJII be no obligation on the employer tol M'nd Intimation of such
vacJncy to indlvldu.ll retr..nthLod wnr~mc·n:
1[Provided abo tlwl if a reltenched workllliln, without !.ufficumt cause being
shown m wnting to thl' employer, dOo.., nett offer himself for r~'-t'mployment on the
date or dates spcct!oed in the intimation ~>nt to him by the ••mployt'r onder this
sub-rule, the employer llliiY not inhlllilll' to him the vacanocs tlwt llliiY be filled on
any subs<!quent <l<'C"il~ion. I
(2) lmml'diatcly ~fkr complying with the provisions of ~ub·ntle (1), the
employer shall also inform the tmd~ union., connected with the industrial
cstablbh.ment, of thl' number of vacanctNo to be fillt.'<l and rome!> of the retrenched
workmen to whom mhm.lh<ln ha!. bel!n b('lll under that sub-rule;
Provided th.Jt tht• p101.1Soon9 of this ow b-rule nl!ed nc>l be cotnplied with by the
employer tn an) "'"' wht•rt' intuNtie>n •~ ..-nl to every ont' of the workmen
mentioned til tlw h•t rr'l'ared under ruk.> 77
79. J'enaJties. -Any breach of the&c rulil'o 'hall be punl!>h.lbl!' with fine not
e'tceedmg fifty nopccs.
80. Repnl.- ln..• Industrial Di~pute<> (Central) RuiC!>, 1947, are hereby

repealed
PrO\ ided th.st any order madtl or acb(W'I talc.o.'!l Wldet" tht' ruk..,. so repealed shall
be deemed to have bt_,,n ma<k' or taken Wld.,r the ~mg pro\-'isions ol these
ruk.>-

liSCHHil/lf
FORM A
(5« rul•• 1)

FORM Of API'LICATI0:-1 FOR 1'Hii IU.FERENC£ OF AN INDIJSTIUAL
DISPUTt. 10 A BOARD OF COJI,CILJAnON/COVRT Of EI'.QVTRY/
LABOUR COCRTn1UBUNAUNAnONAL T!UliUNAL UNDER
Sl;CTJON 10(2) OF TH!l INDUSTRIAL DISPUTES ACT, 1947
Whereas an ondu~lrl.>l do,;-pule ..Is ai'J>1'1'l,Cndtod/<!xlsts bl'lw,.._'l\. ...................................
and . .. .................... nd II i• •"'f'edl<'111 thai ~~~~ mnlle,... sprofll'd In the <-ncl0$<'d
stalrmenl which are -mnn<.'Cit-d w•tll the dbpuh!/1'1'11'\-,>nt ''' 1M dlo;pute •hould ~
refcm.-d for "enquiry/u<.ljudocatwn h1 • Uo.lrd <of ('t')J'-ihabon/a court of Enquiry/a
l..lb.>ur Court/a 11'1!-ul\<llf• :o.;abon.ll lul.>-.onal lor iml">l1!911bUII .mJ <ctllement, .,..
epphC11bon is hereb> m.>d~ undt'r ""~"""" (2) <>f >«~•on 10 ol tht- lndu-lrial Dtsput•~
Act, 1947, lb.lt the •• ....;d m.>tl<1s/>.~id tli•put~ •hould toe relerrod 10 ... Board of

('On(lllahon/a court of Fn,.uory/a I..Jbour Ct>llrt/a Tnbunal/a NatoonAI Tnbunal
Thi·. application i~ mad~ by 1111.' undrNgoll'd who h.we/h•• "'"'" dul) auiJ>oriSI!d to
do "' by virtu~ of a re;;.>ho.tllon (ropy ~nci~J) ~dupted by n rMjority of the memJx.rs
pNs.-nt al a m<~eling <If thr ..............-..... .. .. hdd on lhl' ............................... 20....

I. In>. In G.."( -1(), d.t..'<l 31~ Otn<ml'<'f 19o;,.
Subs. b) C S.R 302. d•h.'<l 2.1td Apnl, l<>SJ.

~

<!-- page 25 -->

The /ndtJstrial DJSfiUtes (Central) Rules, 1957

Form A]

145

t\ ~~l hlnlt:.'Hl gjvitl~ th~ patti' u l.u:o h'"l'"""l nthl t•r fl.JJe :3 of the lndu-.trial [}!.~put~
(Cc.miMI) K~d1 •.,, 19 t;7J i~ aftilcht!'(l.
IJatt·d lhc ................ .
Sign aturt! of t:mplvy'"'I' .................................................................
o r n)\t"'nL .................................... ... ...................................,

or mllnilger., ................................ .. _.,....,.........~..·•·•-•·•·•···

t.'r -pnndt1.tl ('\lfitt r- ot thtc_·C.'fl'<'ratH'~'····· .................-.....~-························-.............
Signarurc .,; the
rrcsw~nl n, l.h~: tTad~ union ·•............................ .......... .

5c\.1fctary t'f lhf" tf".tde unio n ....................... 4 ............. . .
Or

....Si~at\lrCl.' ut ltvt!. t•topr~entatives
d~ly Jt.~Uivti•~d (a!Ji' resoltttion
t.- ncltt~L·d ) .. ,....................................................... ,............. .

1101
»-$i g:rutl UJ'(.1 Hf U1~ W'Orkrnan,.,,.,.,

01
--slgru~tun: of the wodar~an in

the <am• ...,tal>ll<l\tncnt dulr
authori..<c;l (vitlr authonsabon
<nclv,.~l).................................... ................. ....................... 1

1•1
l he Sccret.flry to the Government (If lt"'dlj\,
Ministry uf L.abl)ul'.
Stnt~m~nt n~uired und er rul~ 1 <>I the lmlustrial !Jisput.-s (Ce ntral) Ru les, 1957, to
acmnl pa~>y the form of app lk&tion p rl$(1'ilwll 111\d(., <ub-soc~on (;2) of <eclion 10 ol the

IJ1du'tnol Dlsp\ltes Act, 1947:
(•I Porti"" to the <li_<pute ind o11llny, thr n•me a nd address of the est;lb lishm\•n t 1>r
\l.ooertaking j~yoJved;
HI] 5f'l-dl'iC ma.tters in dJ>putv.

(() Tot..tl numbtr or '-"'t>T.'.rrlm '""'Pim t'tl l n the undertaking affected,
(rl) li•H111a~ numbet of Wl'll'iancn .lfl«:ted m likely to !><! i!lf<-ct~.J by th~ <h•puto•;
(t\) Efforl~ mad e b >,. the pa rtie;; tht..rtP~c.:I\'CS- tu .adjusi t.he disputl¢.

'ICopr to{i)

n,eA;;sisl," " Labom Cvmm1s.~io11er (Centr'lll) ............. ........... ...............................
lhe-f'e ..,.. nt('f' f•t'tk c addn.~~ o ( l.he Assrsl.uit L~,bour Co mmis.sjoner ((\\n ~r;.J) ln
l h ~ local a rea concerned j;

::.

ll\11. b\' <..-SJ~ W59, d ,lt~ M!th M.,y, 1'-H'ls
hW~ h\' <.$. 1~ . BI L dat\.~ 3rd tulv. Hi'"'·

<!-- page 26 -->

The lndUstnal 0/spulss (Central) Rule$, 1957

146

(Fonn A

(u) 1M Regional L..•bou~ Conunissioner (C~nlr~l);

(iii) 1M Chief Labour Commisbioner (Central), N~-w O;>lhi.J

••Del'* whidlever IS nut applicabl<..
FORM 8
(Sa- rule 6)
Whereas an lndustn.'ll dlsput.> h..s arisen/ is apprcllended bel"'""" ..........................
and.........................and it Is e:.•IX'Cilent to refer th~ ::aid d~ute under section 10 of the
Industrial Oi$put<>s Act. 1947, to a Board otConallation for the purpo6e of lnvl-stigating
the salN! and for promoting a S<'ttlemcnt lh<'reof, you nrf hercl>y n"Julred to intimare
to the undersigned 1101 l•wr tllan tbe .................. the na~'(S) ~nd addn.'U (.s) of ooe
(two) person(s) whom you '<ish to recoounend lor •ppointm(•nt as your
~resentat:ive(s) on the said Board.
If you 1~11 to IIUlkc the rec:ornm(1td4tion by the dati! SIX'Cified above, the Cl'lltral
Govemn\1'111 will S<'l<ocl .u1d appoint ~uch per.son(s) as it thinb llt to rfprl'Selll you.

Secrt!t.lry to lh<' Covemm<'fll of Indio,
Mini~try ol Labour.
1(FORM

C

(Srt ride 7)

AGREEMENT

lUnder $ection lOA of th~ lndustri.al Oi$p111<!;1 Act, 19-17(
Name of me P3rtic.:
Represeotlng employers:
Representing •••ork~Mo/<vorkm.>n:
h b hereby agret>d betwl"-'fl the parties to rder the following dl$putc to lh<'
arbitration of ........._................................. I~Tt "!lf:Ci/y lht nattr.<s) •ttd t~ddrf>S(rs} of the

ar/oitratorlsI}.
(I) SpecifiC matter'~ m di.sput<:s;
(li) Details or lh<' patli<'S to th<> dlsput" including the name 11nd addn.."'l! or the
~tabll5hmcnt or undcrt>king involved;

fill) Name or lh<' workman in C'<~SC he him:!elf tS in\' otved 111 th~ di.sputv or the name
of the Union, tf any. ~.--'filing thr workm1'11 or workman in question;

(lv) Tol3l number of "'orkm"" C'mployl'<l in me und<l't41cing afiecled;
(v) Es"""'ted number or workmen affected or Ukcly to be alf<>ctl'<l by the dispute.
' We further agree that the majonty deci;ions of the arbltrator(s) be bindiJ>g on us/
in case the 4rl>itrntor.s are O!qu.tlly divided in their opinion. mat they shall appoint another
pet"$011 .,. wn~ "'hoiie award '>hall be binding on us.
The arl>itrnK>r(s) shall make his (their) award wltlun ,, po!riod uf ....................... (h~rc

<!-- page 27 -->

Fonn 0)
!ipO<ify Ill• J"'rl«>d •11••'«~U)>QI\ by tl\e f"'rbest or \vi thin •udl further rime a, is extended
by mu!Wll •IV•'<'rlll.'nt betwl""' u• In writing. In c•IIC th<o award Is not ma1le wltl\in tl\e
pt'nod ain"'ml'fltion.,.;J. th<- rrfcrofl<'t' tv arbitration •n•ll stand autOl:liAtically cancrlled

•114 we <hall b.' (r,., 10 ~otlatt lo< freoih <Ubtttob<>n

S.gnoture ol ~ p&rlles
RAip.........,tmg employ~
"Wnrkman / Repre!lel\t!ng wnrlc.maro/worlc:mm
Wr""""""
(I)

(2)

Copy to
(I) The AMi~tant Labour Con•mis!liuner (Central), (he"' enw- olf'la> address ol tl\e
CuodliAtinn OffrO<r 1n loc-al ~'"" ~);
(ii) 1M ~··mal ubour ('omtru"'IOn<'f (Cmlrll}.-.~
ffil) Th• (1\lef t..bour Ctlll\0\l,....,_ (Ciontr•l), N~ Odhl;

(iv) Th< S«rt.'idry to tl\r C.o\'l'mmont ttf India. Ministry of Labour, Employment
and il(>hahilitatiun (Ocp~rtment of l..1bnur •nd Enl!'loymrnt), New Dollhi.
•Whtort ~pplic.\ble.
"~lei<- "'hl<hrter rs not appl ltlli>lel

FORM D
(5« rul• 17)

SUMJitONS
~a• an lndustnAl d10pute betWl'e'l ~ _ ................ .and .. ....
..---··--·- hlol
been referM:I 10 th•· Boord ot CUOClliioboll for UWt"bgalion Mid ~ .. Court of
Enquiry for uw,...t~ption/Labour Court{tnbunai/ N•tional TnbuNJ for •dJU<lobOI\
undor sect1nn 10 nf the lndustnal Olspulh Act, 1947, you are hetc!by 5UJn.ti'IOMd to
appe.trbclo,... tn<> lloard/ Court/ l"bour Court/TrlbWUII/ National Trtbunal in penon on
the .............
ttf .......... ot ......... u'dod< In the ........... n<lOI\ to &r\Swor aO moterfal
qu<'<lion.~ rrl.lhnt~ to tl\e 9rd dl•put." •nd you .Sit' dlrcct.;d to pmclu<e on that clay aU llw
books. f'll'l"" •nd other docuiJK'nb and tl\inp "' your ~loo Df und~ c:ontn>l 1n
any way reiAhng "'llw matter under ln\"e>bgolllM by this Boani/ Coutt/ l.Abour CON.rtl
Tribun.>l!N•Mr>al Tnl>\11\.\1

""Y

l);t\(" ····- ..........

llolltd or Condliation.
~u~/~,.--------------

Court of Enquiry.
U.bour Court.
Tnbun.l
Pn."lkllng Oflkcr/S«tttary, - -- --

----

<!-- page 28 -->

The lnduslrllil 0/sput(l$ (0«111111) Rulos. 1957

148

(FormE

'LFORM E
(Stt rule 3'1)

NOTICB OF CHANGE OP SERVICE CONDITION
I'ROPOSED UY 1\N I!MrLOYI!R

Name of c:rnployer ............................................ u •. , . .......... , . .................. .... . .................. .....~ ...... .
1\ddress......................................................... ... ............................................................................
Oatl!d the............ day ol.............. 20....... .
In a«ordance with section 'JA of the lnduslxial Ojsputes Act, 1947, 1/ w" hereby ~ve
nod<lo "'" all ~ tllat It l• m yl our onllmdon to e((~ the change/ changes
speclrr.-! In lfle annrxure, woth err~ lrom...- -........in IM con<titions of service
app14<able to workmen In r..,pc<l of th• mattO!tli ~'Cifoed in th~ Fourth Schedule to the
said Ad.
Sig:Mt\lrt' .......................................... .
l.kslgnntlon. ........................................

ANI'II:XUII.E
fH.-n !fJ«</y tlr; th6ngt/l.'lwnR"" inlnvkJ to Itt' tff«tGII

Cop)• forwarded tor
( I) The Secretary oi ~-~ trad<! union, U any,
{2) AM\ohnr ~ '-"'lmi!Oiioner (Ct-nlnll-·

- .. --.................
................. (/U'I'f rnkt uf!ict llildff'i&ll{ thL As>tsl.rnt r...u.n,, GltnmtSSJOHtT (CmiT'III)
m tM looll """ ronamnll;

(3) R<!glonal Labour Cnmmll.;.lon.-r {C<'IItral)......... _

.........._..................... ,.... _,

Zone;
{4) Chief Labour Commmiuner tCt-ntral), Nl'W Delhi)

FORM f
(Str rul• 36)

Defore

(llcre 111~11too11 tilt 9111/writy <'oncrrrt<dl
In the matt~r of :

Reference No .........................................or......................
........... ........................ ,.......................................... ,_.,.......................................................workmen

Vtr$11$
........................... _ ....................................................................................................Employer

1/we hereby outhorise Shri/ SMVJ5hrte ....................... to represent me/ us in the
obove maHer.

<!-- page 29 -->

148A

<l•• of ... " 20

-····---··----··-

Si,-;tWufr ~1 JV1'JtD'ff~l ,.,, muJRtm.f\ tlk* rt;rrt"f<fita/'ttttfs}

1\ddl'('>..,

Stgr>diUI\' of t\'l"'"""''~bv~•)
AliJr.~< .... .
........ .. .......

FORM C

IS... rulo ~71
rORM Of NOMl'JATION PAPER
----:--::---:~"""" of lt,.hr•tml E..Ubl>•lm1ertl
Cro<op/Wr•oln/!:1\op/Department
I _,,,...., ,...,..., ent<'f u,., Nm<' e>f t1w workmen , ~ttb•~ ~ug•IM for
dr<bon) a• • cAndkiOI\" lut I!~ lu 1M Wotl..• Cnmmlll•"' HI! ,. digoble as a vote<
m 1M ro<hliiU\11€) f<>r wl>id1 hto l• fl<1m tn.tred
I:Mt.-._, " ....

I •gr~ tn th;, rro~ nomu..llttn

..................................... -·
O.te••., .

olo•••'"'"'''''

All<.,.l<d by

jl)
(2)

Cr~ t.. "(ntd /.<y omy r.ro "''M lor/~,gon.~ 10) tlti dt'Cio"'/ ll>n<lih.m<y.t

1

fFORM 'Gl'

IS... rule! 5b lA!(
UNIA~O ANSIJAL R£1 UR"

fORM

A. C•ntr•l p.,L
P.utiC\II•nt:
(o) Narnt' uf the "''-'blbhtl"'nl

'-----

•tldr••, ul the .,.l.lhh,IIIN'IIL Huw;c '1111./n>l Nu.

St'r<!<'t/ f'lm Nu.j ~ Town

Di.<tnrt

-

I

St4t~ r-c-==::::,-:,,:,-"--'nl<l,

r1- -- ,

!ou1>o 0\ l·" R 4t7(H dot<'d 2Xh \1.11,· 2111~ h roRM Cl (" "' 1S-S.20t:;t
I'O!l\1 C. I "'.,. ~ l.oy C S.R '075. ~!>tool 4111
1962

""It''"

f..ar1..,

<!-- page 30 -->

(Fonn Gl

!.a8
(b) N•I"M of the emplo)<r

address of t1w employ~r. Hou:ie no./Fiatl\o

I

Town I

I Pin Code I

I Dl•tn(t C ] State C

j Slrl.'t't/Pl<>t 1\o. J

I

1!-mall ID~====;--' Telephone Numhc>r ._1-----'1 Mobil~
Number
. _ I- -- - - '

(c) N.- of the rrww)ler or petSM~ m;pons•l>w f<>r -.uperviolon and control of
~t

Nn. l
I Slnrl/1'101 l'o.
I OiMn<t ( ~ SUteJ.__ __.

Address House 'o./Aat
Town ;

Pin Code ~~
E-mail 10

;:::=::'_--,
Telephone Numbl>r

._r_ __.

__

.___

_, MobU~

Number !.__ _ __,
B. Elnployt.t's Regl$1£.atlorVLk tn.., numbu undtr tht Acts mtntlontd In C'Olumn (.2)
of the t.ablt bt.low:

Sl

Namf'

Rl.'fP>IT•non

(2)

(I)

01.

Ole 8uildir1g and other Cun,tructlon
Work.."" (Regul•lion r>f I mployment
& ConditioN of Sto"'i<t>) Act, 1996.

02.

1'he Contrlct Labour (RtgulllhOn &
Abolition) Ad. 1970

03

~ lnter·Siate M~&R"t W<>rkmtn

(~bon of Empklyn~nt and
Condition of SefviQ,) Act. 191'1.
()1,

The Elnployt'<'S' Pro•·•dent Fund~ and
M~llaneous ProVlS>OM Act. 1952.

OS.

The Ernploy~· State ln.urant'C Act, 1948.

06.

The Mines Act, 1952.
Notice of opcrung under Rt'JIUI•tion 3
of Cool \fln<'S Rrgul•tlon. 1957 or
Rtgul•lion 3 of Metalhfl'roU~ \i.uw>
~bon,l961.

rn.

Tht Factones Act, 1').13

08.
09.

Tlw Motor T.-.nspo<t Woriwt'l Act. 1%1.

1M Shops and fstabli~mcnts Act
(State Act).

10.

lfy~

(Regls1ration !'<o.)

No.

Any other Law for the tlnw being

In force.

(3)

(4)

<!-- page 31 -->

t48C
C ~ull• uf Principal Employor, Contra<tur •nd Contract ubour.

"'"J.T Nome t•f the prindpnll'mplo)·er In the case of a

- -- -- - -

_! contractor's t"Stablbhmcnt.
2.

O.·u tt uf oommHWE'flwtlt of the L".St.,btJ,1'uneoL.

Number of Contracto" ~aged on th• ,.,t~blishmeol

3.

rtunng the yt'ar.
~-

lut.ll Number of day' durtng the vear on whid•

c..ntract labour w•• ""'rlu)ed

5.

ToW numl>er of IJWl-dal• "-o<W 1.\) c..,ntract
labour during

!he'"''

6.

N~ml" ot the :r..-tanagt.., vr Agrnl (in ca~<' of mines,.

7.

Ac:tdn•<• HouS<'

L.

1o./Fiot Nv

DL•tri• I

::----:~:-;:::==~:---

L~ St...,t/ Plot

l -:J Statt> I

E·m.o1l 10

No.I

I Town

j Pin Code

Telophoot' Numl..,.. : - -

~~-=-~-:-;,==----,

--:..

D. Working hours and w••kly rnt d ay:
Numbt•r oi day> wor~ dunng tho Y<at

-01

\\drkl"d duri•lX ~· \'ear.
~ f- Nun\l\l"r o1 n'k"lndd\.:\
•

03.

0311)' hours of worl!,

04.

Wo'01kly day of resl.

Sl.l M.aleo.

Females

No

Adol<"Ce\t< lb<·IW....., the Childre-n (belon· U
VN<' oi age.)
•ll" oi I~ to 18 1ears.1

Total

I
F. Wage rate• !Category WI~):
C.t<'SOtl'

..

1((-gui,IJ

w.~

--

No+ o( '""'r\4..,...

JWto. ot~

male rrrn.at~ <h\ld"·n t\\tolescent mttle

l'ontr.:~c t

!em ale childm> !Adoi•K•ol
I

llighlv

Skilled

-

Sluu.d

I

l

Serru·

slolled
Ut'>kiU''<I

I
-

I

<!-- page 32 -->

The Industrial Disputes (Central) Rules, t957

1480

!Form Gl

C. (a) Details of Paym~nts:
Gross wag!!$ paid

ln cash

N~t wu.g<:'.l'l t'iiil;J

Deductions

In kind

Fines

Ot>ductions for

Othen;

In cash

In ldnd

damage or loss
(b) Number of work<!JS who~ 8J3.nt~d luve with wag.., during the year.

Sl. No.

During the year

Number oJ workers

C'uanted lea,•e with wages
1

~

11. DNails of various welfare omeniiies provid~d Wlder th~ statutory schemes:

51. No. Nature of vario.a welfaxe amenities provided Statutory (specify the statute)

•M. The lnd~>slrlat Disputes Act, 1947 Industrial Disputes (CI!ntral) Rules1 "1957:
(1)

lf the work$ committee has been functioning.

l(a)

Date of its constitution.

I (b)

Number ol workmen's representati\'es {elected membeN).

t{c)

Number uf employer's representatives (no.minated members).

l(d)

Number of meetings held durlng the year with daks.

2.

lf the works ,0,1'111\(ttee haq not been functionP,g. the
difficulties cncOLlJ'Ite·r..:t in ill; ronstilutlon or" functioning.

3.

Number of Unions in t~ establl$lunents.

Yes/No

, _

..

(J.) Number of workers diS<hatged, dism.i'"ed, retrenched or whose services w~r~
ttrmin~ted during the year.

N<>. of workers

Di9clW~ed

Dismissed

Retrenched

Terminated or Removed

(bl Man-days lost dll.dng the yur on account of:

$1. No.

Reasons

(a)

Strike

(b)

Loc~out

(c)

Fatal accidents

(d)

~on-fatal a«idents
or seriou; a<dde.>ts

No. of man-days lost

in~fuu.~
~

l?.d.-Pflrt no scc.Jns tu be in error. It oushl to be "'1".

Loss in term of money

<!-- page 33 -->

FOIIIl Gil

The lndustnal O.sputBS (Cel!lral) Rules. 1957
UF.C I.AKAnON

ll io to t't'rtily that the abovr infonn•tion is true and correct and also I certif)' that
I lm•e l'Qmplic<l with the aU provlsioM
L.1txlm Llws appllcobl~ to my establl~hmcnl.

or

Sl~

HERE

O.ptal Signal~ or the t;mployer. il •nyl
O.tr - - -- - - t'L>n>·---~

FOKM H

(St·r· rule 58)
fORM FOR MEMOkANilUM OF SETTI.EMENT

Rt-p""""'tmg employe~s):
II"Pri'Sl..,bng worlanen.
Slwrt Rootal ol thv.

c::.,.,

T"rm• ul settlemt'l'>l
Signatur~ ot the parties..................... .

Witnt•••"'"
(ll

(2) ................................ .

Condli~tion O(Illco

Copy to:

f3o;ud o( Coodb•Unn.

(HtTe min lhL <>ffi.-, JJJfi!S, II{ rio< Aomtanl lAbour Comno:J"totln
(Cer.trlll) in I}" /(1(111 4'01 ,.,...l'n1<\l/;

I (I) Assistant Llbouo Coonml~'loowr (<.'"'teal)........................ - .............. .
(2) Regional Labour ComOiiMinncr (C<•nlr~l) ........................;
(,1) Chief Labour Commb~loner (C.mtral), New Dcllu;

J

<!-- page 34 -->

The lndusttlaJ CN;putes {Ctlrtltal) Rules 1957

150

(Fonn H

(4) Tlw S«retu) to 1M Go'~ oi lodra, Ministry of Labour, 1':1!>¥ Delhi.

Concsliation Officer.
Board of Conciliation
ln case where settlements are arrived at between the employ<'~' and hJs workmen
otherwise than in the course <lf ooncili•tion proceeding.
t

FORM I
(Str rut• 59)

Labour Court.- ...................................................

Belote w

Tribunal
____..............rompbo•nt unJer S«liqn 33A
National Tribunal
of tl>e IMUSirial Disputes Act. 19t7.
In the matter of :
Reference No. ........--...............- ..
A........,.., ............_,,,,._........_.... .
Complainant(s);

Versus
Opposite Party(ies).

8.................... ...................
Address:

The f"'litloner(s) begs/beg to complain llut the Opposite Party(lcs) has/have been
guilty o( a contnvmtion of the pn>VlSION of Si!ction 33 of the lndu.tnal Disputes Act.
19t7 (14 of 19t7), as sho"" b<!low:
fHm st11111t l>riefty the pGriJCJ~,.,.. <hru1fllllhr nomnn m ll'hu:h 1~..- aliiJd amtnmrrimt
1w Wm ~ IUtll lhe grounds on v.'itot.ll IIJt min or ocl af llrr MlMJitm<fll IS dr41Jmgnl I
Labour Court
The tomplalnant(s) ocrordingly prays/pray that th<'
Tribunal
N~Uonal Tribunal
may be pleas«! to dedde the rompLiint set out above and pnss such order or ordetS
thetMn u It may deem fit and proper.
The number ol copies of the complamt Md its annexure.. required under n•le 59 of
the IMustrial Dispute (Central) Rules, IYS7. ore ;;ubmitted herewith.
Signaturr of the Complalnant(s)
Oa~ thia. ....- ... .day of.-........20.....

Vmfic•t""'
I do tolemnly declare that what ~ •~li'<l In p;~ragraph.......... abov" is true to my
lcnowledgt and that what a stated 111 paragroph>-·-... abo\•e is stated upon lnfunnotion
nlCeived 111\d believed by me to b<! true. Thls verification L• signed by me aL ................. ..
on ............doy of.. ...................20......
Signature or Thumb impression
of the pen;on verifying

FORM J
(Str ru~ 60 (1)1
Beforr flint mmtimt the Cor:alil>lttin Of!tar, &lard. IAbo<~r Court TnbutUJI or NottorUJJ
Trib~lllll.)
sub-section (ll
Applicotion lor pennission under oub«ction (Jl of section 33 uf 111~ Industrial
~pules Act, 1947 (14 of 1947).

<!-- page 35 -->

Form K]

The lnaustrial Olsputes (Centrtll) Rules. 1957

In the Ola~r ot
A-- "
Address;

151

RtU~tt;Ut.V "'o. .... ............ ·-··········

.!,pplic.inl

B...............•.......•.
Address(e~):

The abov~·nlC11tlOI\NI ~llJIIh otnl "''II~ to StiiW •" lnllr>w$:
{Here mention tile act,'on ~pee:ifietl ln ('(lfli~1 ta} or , (tHib'1 CM ot-~•lb·:iel H(m (I) grumrd$ tnT
wl:fch the ;:~rlllissiQil is S<Jug/11 jor,J
11>e applicant, therelore, pray~ ttmtcxpl'l'S!I per"ttsslon " '"Y kit\dly be gnu•ied to him
lo take th~ following action namely:

IHete mention !l~e tJCtim: specifi··<l ;, "'""''' ut! or <'~flus< 1111 ~1
of .<eclion .HI

sulrsection (1 )

Dattod this............. da)' ol............ 211.... ,..

IS"'"" far \lmfi<.<lionl
Date (on which tht' verllic'ation was 'lll•l~ll ...........
Place (at which the \'erificalion was <igtWd)
' fOI!M K

j!in· n.al< U)(2)J

Before (1:t>'t mortum u,, Cm•~·th.ltJV~I Oftiu'r, RA~nJ, LJbou1 :_'oun
Trll>u~otl '" Mlhoo/111 TribuiOil/1
Application under "~ti011 (2) t>f 6e('lil)n )'I ,,( I~· ln.;Justnal Dts.putes Ac~ 1947
(14 of19V)
ln the mau~r oi :
A............................ ,
ApplaranL
Address.
\t,.,~,

..

Opposit~ Party(i.,},

B......... .......................
Address:

Tile •boYe-mention~l ttppll!'<lnt beg~ ~. st.Hc dH '••ll<lW~!(J lt:rt: .~t QUI tlfJf ti'lt'WIIl f.w!'ft 111{<;1 C'lrtUm:>!rtUC<"S Vj t/tf' 'a~?)
'The Wl)rl<mcn/wnrknum dischar~l~/ dhmds~d undc:11 clau~e (b) n£ sub-section (2)
of section 33 has/have bL~n. paid Wl\g\t~ fur c)nc: month.
The applicant prays that the Cundlilllif•ll \)ffkcr/ll<Mrd /Labour Court/Tribun al/
National Tril>unol may be plca<t>.d to t~pprow ul t·lle adhm t•k•n namely:
[Here men6on tht" at..tiOrl f,,k,•n umliU' tlthtStJ <a) "'

d•Ht:>( (lJJ <1' .)Ub~"'<#::m <n ()i

se;:!Wn 33.]

s,.,,.,.

~ijlf\d tu re of the applicant.
~?I'

•'<'rl/ifntrno:

Dat;od th\s .............day of............. .20.....

Dah> (on which !he veriflronon was "11""'11 .......
Place (at which the venlkatioo wa• '>l)tll•'\1)
-Delete, if not applicable.

<!-- page 36 -->

The lndusllia/ 0/sputes (Central) Rules, 1957

152

[Form K 1

1lfOR.'vt

K l
[.See rulo 62(1) 1
A.PPUCATION UNDER SUS-SECDON (1) OP SECllON 33C OF
Tirr INOUST1UAI DlSPI.J1'£S ACr, 19~7
1\t

(I) The Secret.1ry 10 the GO\ l'fTlliWlt of lndt.1, Ministry ol Labour and Employmenl.

N,.,, Delhi

12) The ~'gional labour Comatlli>IOn.!r (C<"'Iral)" ...... ~.. ·-·····-· (here insert the ruunc
uf lhe region).

Sir.
1/1\'e have to stqte that I .ml/W~ ~rc entillt!d to receive from Mi s ...........................
of R!.-. ·-····-·· on account of f"'"''"''"' ... U l1det the provlsions of Chapt"er VA/
C:h•pter VB of lhe !odustrl" l Disput"" Act, l9.t7/in 1:crms of the award dated
ti1C .... -~....~. given by..................... / in tcnns of the settlemen t dated the .................... .

.t ~o~um

ai'Tlved

,,t

betweam

the

;!.;aid

M/s

...................... ...

an,d

their

workmen

through........................... the d uly etect~d r<!pre~"ntativcs.
1/Wc fu rther state that 1/we scrv~d the ma nagcmel't w1th a demand notice by
re...,ris:tc.rcd post on ..................... for the ~afd ,,mount which the Jllanagem.eau has neither
r~id nor o ffered to pay to me/'"' even though a fo·r tnight has since elapsed. The details
of the an10un1 have been ment~oned in the •talement hereto aMe><ed.
1/We request that the said sum may londly b<; ~"<:Overed for the roanagement under
Mll>-""<'tion (1) of section 33C of Ut~ tndu.>trial Dbput<lS Act, 1947, and paid to me/..s as
t·MIY OS pq;,ibte.
Sigrullur~ .,.f th~ <~ppllcant(s)

1
St~lionc ...- ...~ .......

Date:;, ...._ ..._.__

2.
3.
4.

ANNEXI.IRil
(H•re indi.:nte till' tMail• of 1/~r nm~omtls) claimed.)/
'fFOitM K 2

[Se• 11.1le 62(1)]
APPLICATION BY A PERSON AliTHORJSED flY A WORKMAN OR BY 111.£
ASSICI'lEE OR FrEtR Of A DECilASE'O WORKMAN UNDER SUB-S ECTION (l)
Of SECTION 33C OF THE INDUSTRIAl DISPUTES ACT, 1947

'" (I) rhe Secretary to the Guwmmenl of India, Ministry of Labour and Employment,
'~w Uc!lhi.
(2) I he R<!giooal Labour Commi...,imwr tCentral)..................... llwre msm 1/tt Mmr of

lito• rtgiun I,
c;;r.

I 'Sho/Shrim.>ti/ Kumari..............JI.lvl' to <tate that "Shri/Shrimati KumarL.............'i~/\v~• f'ntiUed to receive from M / ........................ a •um of Rs.................... oa account

ut. ..................... under the p rovision> ofChapl4•r VA/Chapt<'l' VB of the h1dustTial Oisput""
1. Suf,. by G.S.R. 48$. dal!!<i 16dt Marth, l"6fi.

<!-- page 37 -->

Form K9)

The Indus/ria/ D/spu/95 (Central) Rules, 1957

153

Act, 1947 / m terms ot the award datt'<ltll<l..................... given by ..................../ 111 terms oi
th_e, ~ttff.!Jtu:nt. dated t~e····~····---.... ..arrwed At ~tween the said M / s.-.. ··uu "' ctnd their
Wt>flmWil through....... - ....... tJu, duly ~1<-Ctcd representatives..
1 f<~rth"r state thllt l5e!Ved the "t"rt•g~menl with a demand l\otke by tegostered post

on... ~""'"'"""'' '1Clr tht::" .said amount which th(• nlltnagemen.t has netth\lr ~11d nt'.lr offered
'" pay to me cv~n though • fortnight h•" since elapsed, The det~fls ot the nrrt(lunt have
b(~en numtioncd ln the s tatement heretQ unnCX4td.
I r~<jm•st thnt the said $u m m~y kind ly l>e rt..:overed from the m,U1<tg~mt!llt under
sub·:k'Ctton (I) u( •ec~vn 33C of the lndustrldL 01~pul~s Act, 1947, iltld p3ld to me os early
~· pnsolblo,
•f hnVI' l>11·n duly authoriSt.'<l In writing b)'............
Ill!' llilllic l)j lhr
worlm11111~ tn malw tJu. application ""'' to r«'t~\•e the paJffi"''l ai th~ nfo>rt'Said amount

,_,_(l,..,.,, '""'''

due to him
•t am lht- """'!!nee/ herr of the dec:eaS«I wor~Jnan and •.m ~ntltlcd I(' n-cen-e the
payment r-t the aforesaid amount Juu to> hun.
Stntloro .... , ..... ""·-·.. .~
Signature of the applk.!nl ................... .
.1\.ddress..... ·· ···~·~ ....,,......,,............... -······· ..

Date .. .................. .......

ANNiiXW<E.
_

_

(Here indicate tiJt ilt•NIU-: rt/ tile amount claimtd.)

•St,rike 11111 the portlors inappUcablo,)

'rFORM I< J
(Sir rule 6~2)]
1\PPLICATION UNDER SUa.-SECrTON ( 21 OF SECTION 33<:' Of
THE INOUSTRii\1. OISI'UTES ACT, 1947
Govemrr~t,.nt
Court
Labour
i>eiWC<!n ......................... artd................ .......... .
(1) Naonc "' the applicant(s)
(2) N~o•c ol the ""'ploy<>r
Betort!'

th~

Centr.al

at. .......__, ........._

,1"~ J't!llt1oner(s) ........................... . {l wtwkll1:Jn of .......................... M/8. '"' .. ,,................. of
.. ,,_,_,...... , uu.u , . .'llw pt>titioner(s) uodcl'$'1gnedl worklnen of ~.,. .. , .. ,............. .

is/ are ""tltl~d tu n>ceive lr<lln the '(lid M/s............................. th~ mnn~y(benefits
in d\1\ .staterw,mt hereto 4M~·t<t
h ls pray....t that the t•ourt be plt-"'-""<1 on determine the arnountf .•mnunl• due lo tlw

mentiun~

petiti(>rll'r(~).

Signatm• or Thuml>lrnp,..,.,.1unM nl

tlw otppll~~nl\S)

'·

2. ~·······

:t

4
St<~lion .......... - ......- ..
Datl:?-·1""' ..... ......__..............

1. Sub>. by C.SJt 4!1ll, ,iated )6th Mlll,·h, l%5,

AddrCll<(<IS)
• • • •• , • • , , • •••• j ,. . .. . . . .. .

.................,.........

...................,,....

_,

<!-- page 38 -->

1he lndllstnal Olsput115 (Cenllal) Rules, 1957

{Form K3

IINNCXURE
{/ltrt set out lht det•ils of lht llfOili!y dur or II" wrrefit$ QCmted
togethtr with tltt '"""for t!ttir Mmi$sibility.)f
1lFOKM K 4
(Sff rule 62(2)1
Al'PtlCATION BY A PERSON WHO IS AN ASSIGNEE OR HEIR OF A
OECEASID WOR.l<MAN UNDER SUB-SECTION (2) Of SECTION 33C
Of THE INDUSTRIAL 015 Pl1TES ACT, 1947 (14 OF l'H7l
Belote the Central Coverrunent Labour Coort at.....................

~"""'

(i) Name of the appli<ant/ appt>CAnt,
(li) Nam<! of the employer
I am/ We are the assjgllee(s) of the dec:e.t!>NI workman and am/ are entiUcd to malat

a.n appliA:abOn on his behalf.
$hrl......................., fonner wotkman of M/s ................. ........... of.. .....................is entiUod
Itt the
ata temcnt hereto aru1exed;
h is prayed that the court be plea<cd to det•rmine the amount/amounts due to the
decc~ workman.
l'.;JI1W ;lnd Addn!SS of worlan.>n. ............- -..
Sign.ot~ or thumb imp~ o(
theApplianl(s) ............ _ . .......- ............ Statton--.-......
Add""'"" of the apphcas>l(sk.-·-..-·--........
to receive ftom the sa:id M/s .......................... .. the money/benefits mentioned

0.~--.....................

IINN£XUR£
IHtrtlll srl 011t l1rt detl1!1s of lht rrt~ttry ''"' or lht btntftts /JIXrrwd tQXdl"f rt1tlr
''" ca$t (or t/lm ;u/missfbility.)J

fORM L

(&c rule 71)

fORM OF NOTICE OF STRIKJl ·ro Bl! GIVEN BY 'IUNION/WORKMENI
IN PUBLIC lTllLITY SERVICE

Name o( Union
(Name~ of Ove elected repre>entollv<"' of workmen.)

Dated the ......day o£......20......
To
(Th<' rwne of the employer).
Dear Sir/51,.,

In .acwrdal>ce with the provision.~ ( <>ntamtd ins~ (I) ot section 22 oi the
I
lruiUJtnltl Dispull!s Act, 1.947 - - -- -- - ;V:-:
_.,
.- -- - -- hereby glve you
notice that
I propose to call a siJ'il<e
on.................20...... for the rea«>ns explauw!d
we propose to go on <tnb
m the IN\CXU!e.

Youn faothfully,
1. ~,. by r..s.R. 1070, dAted 23rd July, !9?'1.
2. Sulw. by C.S.R. 488, d•ted 16tio Mor<h. 1965.

<!-- page 39 -->

For111 MJ

The Industrial Disputes (Cenrmf) Rules, 1957

155

5«retarv of the Umon
1

(Fiv~t
<>n ..., .. ,

"'l''""""tativcs of the •"'rl.men duly .-!ected
···--- (dale), <'rilr• r.••uluhc.m atta.chl'd.]

111

•

rnl!t'ling held

ANNI'XIIR£.
Stntenumt of the Case.

Cupy lo:
( I) 1\;~,•lstanl Labour Commisslmwr (Cenlral) .......................,.,., ................................... .
(J lrr•• l!r7tt--r office addrtW'I ()( IJ'W Assi.'ilant l..a;)()ur Cot111111$Sioutr (Centrali
in tlw IDC:li arm ronr-J~nmf.l
(2) kegronal labour Commi.<stonel ICentTal)............ Zone.
(3) CJ,;,.r IAtbour CommiS>i<">\"
New Delhi.

(('""''•'>•

1(FOilM

M

(S<·r rule 72)
FORM OF NOTICE OF LOCK·<lUT TO BE GIVEN BY AN I!MPLOYI!R
CARRYING ON A I'UBI,IC lrriUTY S.ERVICl!
Natnt'" of cu,p1oyer........,., ......... _ ... ,...... ,.,_ ..... , .. ~ ..., ............ ~····~................................... ~................... .
A.d\lc~s-.................~···~"-···················-···· .........._.........._..........._ ...................._ ......-............................-

Da'""1 the., ,, .....d.ay oi...-...............20..

u

ln li'('(OrdanCl' With tfte J'fOvislatl.' of ~\IIH«tion (2) Of :;ectlup 2l Of the lndu.'OtriaJ
Di!.-p~to> ACI, 19.47, 1/wt' her~b)' give no1100 111 all corlc"med that it is my/our inh!ntion
tu •11~<1 ·• I,K~ tl~t. in ....................... d"pnrtmon\(~). section(s) of my/o\lr ost~bli.shmcnl
\-\·ith eff«t Jmm., ..................... for thtt reilt~Ot~ ~xpfa"ined _fn the a.nn~rc.

Signature.................................... .
Desit;nauon ... ,........ ~~................. ..

ANN/' XI/IlL
Statnmml

•>/ Rms<'n:;

C<:>py forwafded to:
l l n,~ Secretary o{ the Rt!gi$t~red UlliOn, if any,
(2) 1\.~slstant Lot>our Commh.sion<r (CvnlT<l l)............ ........................................................ .
JH,·re e11ter offite addr"<$ ~f /lie A~istunt Lnbour
Commrssroner (Central ) m lire /Qtalllri'/1 corrcemed.}
(3) fl11gluMl 1-"t>ollf Commill$ion~r (C<'ntrai)............Zone.
(4) Olid l..alx1UJ Commis,;ionnr ((\.'!1tr•l), New Delhi(

<!-- page 40 -->

fORMN

(StrNle13)
I'ORMOFREPORTOFSTIUKEORLOCk.OlTTINAP\rBUCUTIUTYSERVlCE

IrUonn.tion to.,_, supplied m thisionnimmtd;.ltly on che~of a slrikeor lock-out m o publiC utilitysenice •o the
A..-sistmtl.abow-CornmL..ioroeT (C<ntral) lor the local area"" ~<ml<d

N~:me

Station

of

and
District

und<~

Nonnal
working

NumberofWorl<crs
involved

strength

taking

Strike
or
Lock-out

Directly Indirectly

1$ there any
Wasnoh«of
Dote of com· Cause strll<e or lode·
perm~nent
Any other
mooremcnt
out given? lho, agt-ncyor agree- infotmaticm
olstnkeor
on v.1hat date
mrnt in the un.-.
Jock-out
and for what
demldngfor
tho settlement
period

of dispute>
bo.:tween111<>

2

3

4

3

6

8

9

10

I

'
:

emplo~md

worknw:n? If
any <'Xisll!, patti·
<ulMs then:<>f
7

l

~
ii

II

""

J
~

Notts.-Column(3)Civttheaver•geno•m11<>rolworkmenemployedduringtlwmonthprevioustothedoyonwluohthestril<l!orlod<-<>utoccurred.
W'hHt rec...koning the averag;e.or:nit th~days ou which the attendance was not normal for reasons other than individual reason.s
olparticulorworkmcn.Thusdoysonwhichshik~orlock-outo<>.-tm,orcommunalholidayiseni<>yedbyalargeS<!ctionolw•>rl<e<!<

should 11<> omit!(.-d.
Column (4) lf.~y. 200 worl«!<S in a factory~hike workond Inc""'""!""""' lhe whole factorytnoploying I,000 workers has to IM)cl<>sed than,
200should b.)shown uncl<r ''direct~y" -nd the ,.,..lllir1glll\der "indirectly".11 the otrilwof200 workcnl dOO:H1(ltalfect the working
of theotlwrdep.utmcntsol lhefadory, the num.,.,.ofworke!:s involvtd w<>Uid only b.) 200, which figure should appear under
"dlt:e<:tly" andcolumn"tndir«<ly' would .,_,blank.
Column (8) Give the main c.>uses of the disputus weU u the Immediate cause !hat led to the stnu ot lo<ko()Ut.

j

:1
z

<!-- page 41 -->

Fonn ().I)

'57
fOR\1 0

rs., ruJ.· n1
RrGISTER
I'ART I

Sc-ri•l

htdU>UV

1\o.

f'.tr1h"' tu U'!oe
0.\U· ,.,
•ttllem~o;;,n:.;l_ _ _ _ "lllem<·nt

•Whc-thct- lhc ••ttknlt'f"' "•n ehtctL-.-:1 Jt t.ht· lnh:rHT*"" (tf th&:o o"OCII.i.ihun
~IWI') orb\· mu~ua "'-'l:OtulJt'lft' bttkn-n •h•• l'lrtH ..... nw' b.o- n.:hc-atN t--4'1(~
f'AIII II
'th,luf,l (Vf\tun one cur~ r.Jch ut tht.· ~ott.:.cmC'n~ '" till "tMI urtlt•t 1nJ C"-ak.;t n

P•rt I

1

1~0 KM 0·1

b,,. nrl< 75AI

Tn.

!-or.
Uni.Jt.'f' rul~ 75A uf the lndu:"ttt.lt fJ.t... p•Jh" tC4•ntr.ch Rut... 1'~ I \olo(" hct..:b\ 111h•m•
th•~ lh"t: Nve Ltrd ()!.,., ••••.• ...
out ot a 1\)t.\l '"'ft
\'lnt"kiTI.._.n
rmployt'tlm the e..<ii.t-ablt.J\nw.nl wtth tth{l\ t frurn• t
tur t.,(. rt.'d'""-U\.... .._~rbtn.xl •n
the Ann~'-un•.

2 ~ch oi the "'OrknM~r~ cuuu·mt"\J.a:.. .ut:t ~nUlled tn 'Oil\~·n~htU\ un•h'f' •I' hnn 2t;t
u( the lndu~trial [>a.§put~ Ac1. l't147, \.\ •tl b-. l'·•llf ,.-mpt:r' ...'"''" tluc I•• then'

C"'fl~ '"""""r,t.....J to ~.,u.unt L.sbour l"'om.m-" ...:.c'.ot1r l(l-:"!,h411 ... - .•·-········
/llo"f1' "1'•1/V IN &!,I'"''~
\c,;,rjmt L ,tlfltu- C•.,..

O•('

"'' ••l"''ll If. I ''''dlI I)( 1~.·
lrl\'tJt Jlh'•'l , t''"•'riW•I)

•fltttt UlSt"1't the numbt•r n( WUtknH'Il

• IIL>n! •1\>1.'1'1 Ihe d~t<

••Hrt(" .nco-.c-rt tht• f't_...lhvo \\.tuch the P<~" "'h~• ...s;:n' t~,, ldh'f h liJ ... ~uh lh•
mtpluwr wumg the lett<-r.l
,\\.'1:1 -.:r 1111
St,,,,.:Jif1tt PI JV.-:...v,t

<!-- page 42 -->

The lnduslti8J Olsput., (Central} Ru/8s, 1957

158

(Fonn 0-2

1(FORM

0-2
(54-r rule 75A)

r..
fho· l(o•gional Labour Coonmi»ionl!r (C~ntr•l),

1/wro· 'l'•'cifil the rrgim: toll<'tntrd./
Sir,

A• tt'\!UitOO by tul~ 75A ol the lndu,triol Disputes (Central) Rut... 1'!57 and in
ronbnu~tiooo nf my /our nobce dott>d • ..... in Form 0 1 I/ we Mreby mf()rm you that the

IJ)-<'fl 10 m)/o>ur ,'<tabl.i>lunmt 11.1. end('d ort<o........................................_,_
Yr.tt> Jauhfwlly,

C<'J'Y tu tlo.! Msi<laOI Labour ('nmnw.....oner (Central)......................................- ...- .. .
IHm spl'Cljy the address of the A>&1SIImt !AI>mlr
( ·.,m,uiS<IouPr (Central} of til< lorn/ "'"" cor...,.,u·dl
1ll~rt.- il\s~rt the date.

H I I<'"' '"""" the position with the prrson who signs the letter holds with the
l"ulng the letter.]

''"'I'''"'''

1(FORM

0-3

(Tn ...., )Ubmltted In tnplkate 11- J)
(5« rule 7!ill (1)]
fORM OF APPUCATION FOR PERMISSION TO I.AY.OFF, TO CONJlNU'E
THr LAY.OFF O'F WORKM£N lN INDUSTRIAL ESTABUSHMENI'S TO
WlilCH I'ROVlSIONS OF CIIAP'T'ER VB OF TH1! INDUSTRIAL
OJSPtrnS ACT, 1947 (14 OF 1947) APPLY

'lo

lllw .outhoril) <p«ified under •ub >«!JOn (I) of se('tion 25 Ml
lln.J...,. '•lltH.:ctlon (1)/~ub-.«ticn '((l)l ol section 25~ of the lndus!Nl Oi.spure. Ad,
1~7 (14 of 1~7) read wilb sub-rule (I) ot rule 758 of the Industrial Oisputes (Cerotnl)
to the lay-off/petm.t.~lon to contin~ the
Rut..,., lq'i7, I/ we hereby apply lor

·.,..nn,,uon

lay-ott ..............-workmen nf • loW of.......................worla:nen employed In my/our
"'Mhlbhmlont with effect from............ , ..... kir th~ reo<ons set out in th<> Annt!X\U'Cl.
l'crmLw"n JS solicited •(or thr lay~((/!O rontinue the lay-uff the ..Ud workmen.
<ou<h uf the wor.kJnen permitted to be laid-off will be paid such ro•npen~Sation, if any,
lo> wlu,h llwy •"' entttled under bUIH!ectinn 1((6)) of section 25M, read with section 25C,
ol thl· lndu>tri•l Oisput.., Act, l94i (14 of 1947).
Yours faithfully,
(Signature)

•-stnkt.t ~ •ut whatever is. inapphc.tble
I. lruo. '01· C5.R. I I HE). d•IO<I 5th M.or<h 1976.
1 Clmi"L'<I lTV G.5.ll 289, d>!t'd 2nd M•rdl. 1'182 (w.d 13-3-1982).
1 Sui>< by S.t). 2-185 dat<d 21lth M•l'• 1'135.

<!-- page 43 -->

Fon11 <H)

The Industrial Disputes (Cetttrsl) Rulss. 1957

A.NNI!.Xl/RI!.
(I'~

ltmr No.

I

Ill'" replieo< "&"'"" nd1 item\

N<unc of the undenakmg with ron1pldt'
p<>5lal addres.•, incl11dil1g t•lo,gnptuo ~ddl1l;.•

~nd f<li"Phone numbor.
2. Stai\Js of undcrt•klr\g(11 Whether C'•nlral publlc fi«Ulr/Scl"'
publ.c S<'<'tor r. ''~IIJ' nujonl) """l'""Y

joinli<'C!Or ~~

(ri) If beloo1gs !I) large lndu•tn•l Mllw,
plea"" ln,Hutto the co11trollinll Qrq~~p;
and if ~ fm·Hign tt~ojority comp.,ny~
indkal:l! the c~tcn! uf (orci0 n h()lrltng3.
(lil) Whether the undertaking •• 11«-n'!td/
~"Ut.erf<l •nJ If 50, 1\oii'N' u( "'""'ulgl
~·uon

•ulhonty

and

licen<'c'/

registration n!rtif~<:ate num~
~

(•) 'N•m"" and ltd<lre"-"'" of tl~ uttoch~l
wodonen prc1vn~d to bt" lni~i"l>fl /
names .~1'\d "dd~ts of the wor1ctt\4.'J'
laid-<>ff befort the ooll\IJ\.,..<ement of
the lndustn.ol Orspu'" (Amal<IIT'..,,)
Ad. 1'176 (~ nf 1'176) olnd the dt1t"'
1rom wtuch ~.ti,l\ ut tlwm lw bet'!~
'~·d~ff.

(ll) n.e n~tti!C ot tl\e tlutl•s of the worknM•
re/erl'\'d to In •uh-ltem (a), lh•· tmits/
sectiON/ shop• where they ore or w~rr
working and the WAge!jl drav.n by liiCin.
4 ft....U o/ IIWIUf.octure a.nd -lul•d
lfidustry / indu~lri.,. under whid> they (1\11.
5. l'lelail6 r.~l~tin.; 10 il.,.t.,Jit<d C>~pac:ltv, ll((•!l<ll(l
(;l!)<ldty and .. uhsod capocity.
6 (I) Annual pr<Xh!41ion, itcrnwL'!<• l<>r pre®ing th...., }"'•1'$.
(il) Produalon fi~;un5, monlh·wi.oe, lor the
~g tw••lvc mnnths.
1 Work in P~'- •t<•tn·wis<' •nd <•olu("
wi$<-.

8

Any arrangomenl ~·ding off·loadin,<! or
sub·CQntracting of pn>dut"ts or any rQfl\

ponents !hereof.
'I

l'osili.or> of the order buok·i~-w\54> and

vtthte-""""' for • f'l'ri<><l of .,, montlu, •nd
utw ye.u nexl lollowln.g. and for tl>r. f"'l"l()ll
aJb.r lh~ ""l'"Y nt lht- said one vear
10. N~r of wnrlclng da)'llln a w""\. ¥o'itl\ tlwl
number of •hlflv I"" •lay and Uk •trenglh of

159

<!-- page 44 -->

The Industrial Disputes (Central) Rules, 1957

160

workm., per each shift.
11. Balan.ce sb..,.,., proR.t and los; accounts and
audit report$ lnr the last three yeats.
12 Financial poSition of the company.
tS. Names o/ th<: i l'lltr..<;otmected companies ot
c.'OI'I'lpanies under the sam~? .management·,
14. (i) The total number of workmen (categorywise}, and the number of employees
other than '''orkmen as delinc.><l und"r
the Industrial Di~pu~ Act. 1947 (l<t of
1947), em.ploycd in the undertak•ng.
(il) Percentage of wages of workmen to the
total cost of pwd uctipn.
15, Adn•inisttati.ve, general and selling (()lit In
absolute letm$ per year in the Llst three
yeaiS a11d f""'<""~~g• thereof It> the total
.osl
16. Oetail~ of lay-off~ resorted to in the l3!t three
years (other lhan the ta:y-<>£1 for which
permi$1on is sought), including th~ periods
of such lay-offs, the number of workmen
involved in each such lay-off and tb~ reasons
therefor.

11. Anticipated savings due to the •propoo>ed
lay off/lay-o£1 !or the rontinua....-e of which
permission is !l<lugh~
18. Any proposal for effecting &iiVlng~ on
account of r<.'<ludion i.n-

(i) mana~rl<\1 r~uneration,
(ii) sales promotion cost, ru.d
(iii) ge!Ulral administration e~
\9. Position of ~lOCks on last day of each of
the months In lhe p~ing twcl"e nmnth.<20. Annual sales figures tor the last three year;;
and montll-wisc sales figures f()r the
preceding twelve months both itcm·wise

a

n
d
value-wise.
21. Reasons for the <proposed lay-off/loy-oil for
the continuonco? of which pernusoion is
sougbt.
22. Any spe<;iiic attcn,piS made so far to ovoid
the •propQ~;<:d Jay-off/lay-off for tlw t'Qnttnuance of which pemussion is sought.
23. Any other rcleva.n t factors with d~tails

(Form 0-3

<!-- page 45 -->

•

I

form PI

181

lh•m.>f
~trik~ out wh'lte,~r IS onApph••bl<~.l

WllM P
(SN rut~ 76)

FORM OF NOTICE O f RE'I RENCHMENT 1'0 BE CJVEN BY AN
I!MPLOYF.R UNDER CLAUSE (0 OF SECTION 25F OF
INDUSTRJAL DISPUTES ACT, 1947
'-•n,.. of emplo}"'--·

Add~ ·--·· ---..
day of
II),
The S«Not.lt'Y to lht C.ovttmm('l1't uf ln,JI.l,

\loJ\I.!lry ol t.ab<>ur, :-;ew Delhi

Sir,
Und~r d~u<e (c) of !l«tlon 251

ol the lndv--.tri~l Obpule> A,,, I!N7 (H of 1947), II
wori:nwn wtlh
~11'-"1 from... ...
tor tl>t' <N""''' (>•pl•lned in thr Annt'wr~.
2 • Tlw wcxl.mm CUJ..,.mo'd w~re go\'CI' on tl>t'
20 '""' ~th s no~ 111
wnhnt; •' I"'JUirOO under dauw (a) ol -«two1 251' o{ th•· Art ~"""""'-t u boSng
rlf«Wd 111 pursu.oncr o{ .111 •grttm<ftl • "'!')' uf "1Ud1 o;. <'n<'lno.rd Tlw! workmen .,......
IQ'<n un tilt' " ... _ ..... ·- :lll , Of\<! month'> p.l) on 11.-u ol """"" ~ lt!CJUU<d under
wt- tw"~Y lnfunn you. th~e l/ w~

h""""• dl."'d«< to N1n~C'h•.

dluw (•I of "-~00 2Sf of th.>t Act
J The oot•l nu""""' of worl.ll\('1\ empl<>y~ in~ ~t~o.Ju,tr~•l <"t.lbiJ..<hment os·4J>d iht' tot.tl I'Urnb& ol th""· who will be offect~ by the r•tr.,o\l:hmenl l• l)tvetl below·
Number ol wonmt:n

Col\>gory al'd d•~ign•tmn
ol workmen to be retrench<od

01

l!tnJ'lny~
To b.. rctrl'n(:h<d
- ----;...,(-:'21--- - ----::p,..l- -

4 1/We htr'l'bv d<d.~n- thoollllf' "''"km.on/ worlmen ·~~'"' ho•/h~vc b<t>n/will
~ paid '"""'l""""iion du<! 111 them under .:r«b<•n 2.'if of tho Art on •• .• .. . ........ /the
•••plry nf the nQtic\! pen<>d

- .......... ..

•Jit•rc.- ut.~ the nunlbc:t t,f worktnt'f'
u•""rt the date.
'Orlrtr ~ portion wh•dl " n<>t ol('phc~ble.
···~ 11\Wrl ~ IOI;ll num~r nl "'"'luno.'11 '""rk•n-d .n the! tndU$trul

..,le,.,

e,t;abh.,hrnt1'\l

' II«~ 11\'<'ft the! pot~oban "'hich tlw ~""""" "1\(1 ..Ill" thb leno·r h<>lds With the!
~nlpkwer ..sumg the lelwr

MIN'EXUR£

Copv to

<!-- page 46 -->

(Form P

The Industria! Dfspute$ (C81ltral) Rules. I957

162

(1) A:ISistant labour Commissioner (Cen!nl) . .... ., ......................................................
tHerf ente,. office address of tl•t Ass'isl«"l Labour
Commissioner (Ccutrnl) in IOC<tl arta concemed.}

(2) Regional labour Commis.•1oner (Cet>tral).
1((3) Employment Officer, Employment Exchange...........- ..........................................
(En~T the full address of the Employment
Exchange roncerru:d.)]

'[FORM I'A
(To be made ill tdplkate lj•..J)
[$..., rule 76A(1)]
FORM OF NOTICE FOR PERMISSION FOR RIIT.RENCHMENT Of
WOR.KMEN TO BE GIVEN 'BY AN EMPLOYER lJNDER
CLAUSE 4((Dl) OF SUB·SECTION (1) OF SECTION 25N OF
THE INDOSTRJAL DISPOTllS ACf, 1947 (14 OF 1947)

Date.......................

To

.............................,..... ..
(The Central Governrnent/autliority" spt.>cified <mder clause(~) of sub-section (1) of
sectiDn 2SN].
Sir,
Under S[clause (c)] of sub-section (1) of $eclion 2SN of the Industrial Disputes Act,
1947 (14 of 1947), 1/we hereby Inform you that •r;we propose to
retxench ....................... workmen [being workmen to whom sub-~cction (1) o£ sectl.o n 2SN
applies] 'with effect from......................for the roasons set out ln the Anne~ure.
2. The wodanen •concerned have ~ given notice in writing as required under
clause (a) of .sub-section (1) of section 2SN/bave not been given notice since lhe
retrenchrnmt is under a.n •greement (copy of which is e~>dosed) as provided in the
proViso to th~ said clause.
3. The total number of workmen employ~d in the industrial 1!$labli$h ment
is........- .......................and the total number of those who will be alfe<:ted by the proposed
r~t is as given below:
Number of workmen
Category a.nd designation
of workmen to be r~trenched

Bmployed

To be retrenched

(1)

(2)

(3)

1. w. by G:S.R 410(8), d•ted 13th Sepremb<:r, 19n.
2. iJls, by C.S.R. lll(ll), doted 5th Maocl1, 197~3. Omllltd by G.S.R. 289, doted 2nd Matcll, 1982 (W.e.f. 13-."l-1'182)
4. sw... by s.o. 2-135, dAted 20th ¥ay. 1985.

5. Subs. by GSR 761. doted 2nd August, 1985.

J
•

<!-- page 47 -->

Foom PAl

The Industrial Oi$puta (Central) Rulss. 1957

183

4. l'etmission is solicited lor the propot.e;t retrenchment under dause (c) of sub~odinn (I) 111 ;;ecthm 25N.

5. 1/W~ hereby doclar~ tn•t the wndmwn punnilted lobe retrencl\l.>d wiJ\ be pllld
compcnsahon due to them under cl~us~ (hluf &ub-section (I ) ol ~Lion 25N of the Al.'t.
Yours fllithlully,

'Strik• out what...-er ,. m.pphcal>l., I
ANNFXU/I.t
(VIeo.., JPVe repbcs agamst earh )rom)
lttm Nn.
l. Non11l of the undertaking witl1 Ctll\1plut~
addres•, including t~lcgrnphk
•d•lra<o;es and !elephon~ numb.lr,
2 St~tu' of unck!'!aking11) Whether Central publk ~or / Sial<'
rublic <<>ctor I fo~gn nla)l.lrlty
c:umpanr/ jmnt sector, e lc.
Iii) II bciOI'IgB 10 largt> onthutn•l Mu~.
please indicalr the contrOlling
and d • to,..;~ marml) <•rmpony,
mdicare the extent ot for~ogn huldtnp
(iii) Whethur th., und•rto):Jng i~ li~/
"'gistered and lf so, 1\0illt ol
lict'11.iU1g/ registranon authurlly And
licent-e registration certlfiratv numbtm'l
1 Names and adc~Nss.>s of th~ wurkrtWII
propooed to be retrenched and the n.1ture
of the duties, the uniiS /OC!Ciilln•/•1~1~
wl,....,. they are working and the w~g<'O
drawn by them.
~
lterru. ot manufacture and ..chetluled
lndt>.<lly/ industries under whtd1 tlwy f•IJ,
5. Oetalls relating to in<IAilC'd Cllpftdl'\'
ll<"t'I\Setl capacity a.nd the utili.-...! tAradtv.
o, (t) Annual production, item wt,. fnr

r"""J

s•vup.

prt'<·toding tlu-.... Y"""'
(Ill Production figures mooll> Wi>l• lut
ri'\'Cedmg twelve months
7 \VQrl. 111 progress-item WLO<! And valu.,..
WI""

A. Ally arrang.=ent regardin11 olf·loadol\8 '"
...b-conltacting of pl'()(lucl• nr ;my
compon~ts thereof,
9. Poltliliooo of the o rder book-itcrn•Wi:« •11tl
vttlUt'-,~'ise for a -period of six munth~ 1md

""e yta r next following, ~nli t·o r Uw
porlod after the expiry of lhc ~Aid 011.:

<!-- page 48 -->

Tile lndustltlll Dlsputss (Central) Ru/8$, 1957

164

year
10. Number of working d.ly< in a week with
munbo?r of shifts per day and •tr.!ngth of
workmen per each shift.
11 . Balance !!h('t't; profit aNI loss nc:count ond
audit reports for the la<t three years
12 f'inandal position of the company.
13. N.,.,... of the inte.--ccnn«ted companies
or
companies
undn
the
s;une
INNigemenL

14 (1) 1be total number of "'orkmm
(category-wise), and the nurnb(r of
employees other tha.n workmm as
defined in the lndu<triol Disputes Act,
1947 (14 of 1947), employed in the
undt•ttaki.ng.
(li) Pc.rcentage of wages of workmen to
the total cost of production.
15. Administrative, general and lo<'IJmg OO<>t
in absolute terms per year fo< th~ ~I
three years and percentage thereof to the
IOU! costs.
16 OrWis of retrenchment ~ to m the
d.at"" of
l;a,t three years. including
r~trenclu:rk'nt, tht' number ()( ~orkmeo
Involved in each Ol541, and the rea~~on.,
therefor.
17. Hns any of the retrenched workmen been
given ~ployment and if oo, when?
Give details.
18. Arc seniority lists maintained In rcspKt of
the categories of workmen proposed to
be reb:enched and if so. the detail' end the
position of the wor~n a lf«ttd
lnd1c•llng their length of service Including
broken periods of ~rvice?
19. Anticipated savings due to th" prupoo.ed
rctwnchn>e:nL

20. Any

proposal for eHc-cting !>'!Vll\f!$ 011

account of reduction ln-

(1) managerial remuneration,
('II) u.!e$ promotion cost, and
(hi) g""eral administration ex~.
21. Position of stocks on the last d&) uf each of
the month in the pr<!Ceding twolve months.
22. Annual sales figllres for ih~ last thn.>e
years an d month-w i~ •ale~ figures-for
th~ preceding twelve months buth it~m­
wii3C and value-.wise.
23. Reasons for the pruposed retr~nclml\.'1\t.

IFonn PA

<!-- page 49 -->

Form OAJ

18S

24 An) •pecrlk alt.>mpt m"'i•• so fM to •• ood lhe
2S. Any <>Iller rekvonl t.\CIOI"' w>th det.til• tlwn.'U!

pn>f""""d retrenchment.

1

1""1

){fORM Q
(S,. ~ 7~8)

FOR.\1 OF NOl iCf 0~ CLOSURE TO Bto CIVEII BY AJI/ EMPLOYER
UNOrR SECTIO'II lSfFA Or TilE INDUSTRIAl. DISI'IJTES
ACT. 19-17 (14 OF 19-17)
Nome nf empfclyt'r..... .................................. Addt1Wi::S.. .................. ,...... .....
IJatt'<l tlw..

do) ol.. .211 . ..

1"hP ~1.11') to lhl• ( ..n\ ••mn\ftlt nf ln,hA
Drpattmmt oi U.bnur ~nJ Empi<>Vmml
N ..... DeihL
Cndcr !l«hon 2.5FfA ul the ludustrtol U&>put"' Ad, 111~71 II"' 1'14?), ll>w' h...eby
lnlttrm you thM 1/we h••• dt'Ci<ll.'<l tn •' I""• Jnwn .......................(Nme o( th•
und~rtolking) wilh olfcct ln•m. ..........-.
fo>r lh• reol>On> "'J'I.!Int'd m llw IIM<'XUrt'. 1 ht'
number uf workrnm .,..h.,.., ,...-viol> would b, ttormi~•ti"d "" •ccuunl nl tlw cle><urt' 1'>1
lhe undl'fU~IJ\g ''
(number 1'>1 W<>rl.mt-nl

--·-

'(lll'rl' U\M'f'f rffl J".,.,lttC,.n w-hit.h &h._. pt'f'IM ..l W}'lll.t Sij(,fb thb k1k.'1' holds. witl\ ltMo

tll\rloy<r '""ung lhi• lt•ner )
tWNlXIJRI.
SIOoltcmnll •rl TN.. r•ll•

t:Hp)' ""

11) n.., RegiOnAl Labour Com..,.....,.wr (t.c•tr•ll' ·--·--·····- - (21 0.., A.•'>ISI'ant l"'"-"" ComtniS<i('lner (C•-ntr•tl• ."
PI ThO! Emrloym"''' 1 'd1·"'11". .. .• _
·----- ..
'IHm <nll!r til<· •fl•cr /IJdrts> t.tf tht /V)Iuln~l IA"""r Cilntlf!l.•>llollft ICntlmll/1\nUIIml
lA'-.MJr c~lltlr"i.;..;;wun (Cnttr.ll~ iiUd tJh: tmpiOt{mtfltl Uthlltixe m thr '"'''' .,'tl cU,('t"'1JrJ,./
'!FORM QA
(I u t"' >uNn•l~od 111 tnphate)

IS.. ruk 7t.CII ll
fOR\! OF NOTI<.:t fOR 1'ER.\11SSION OF CLOSl.'RE TO BE GIVtN BY
At-. EMPLOYER UNDER SUB·SFCTION (1) OF SECTI0:-1 25-0 OF
1116 1NOU!> fltiAL DISPUTES 1\CT, l9-l7 (14 OF 1q4n
Dote. ............. .. ..

r"·
I
l

r.,.,..

'""'"'..!

I'll
b) 50. l4~. .loiN -.~~ t.Lty I'''"
IJ,., I>• (;.SR ~1!111 ' ~•1<'<1 13<h S..~ t97l

3 tn. b'v ~R lll!h d.ot,'<l 5<h M•fd\ 197o

<!-- page 50 -->

The Industrial Ol$pUI6S (Central) Rules, 1957

166

(Fotm QA

TI1e Secretary t<1 the Go.vemment of India,

Ministry ol. Labour,
New Delbl.

Sir,
Under seetlcm 2SC of the lndustrlal Disputl'S Act. 1947 (14 of 1947), 1/we hereby
lnform you that 1/we prop<>S~: to dose down the undertal<in& specified below of (name
of th" induslrial establishment).
(Giv~ det:alls o( the undertaking)

.....................................................................................................................................................
with effect from ......... ,........... .for the reasons explained i.n the Annexu~.
2. The number of workmen whose sorvices wiU be tenninoted on a~ount of the·
closure of the Wldertal<inll is.................(numbc!r of workmen).
3. Pe~loo is solicited for the propos<!d closure.
1[~. l(we hereby declare that in tile event of approval for the dosu"' bdng granted,
evety wor1cmatl In the undertakiJ)g to whom sub-sedion (8) of 1M :<aid .section 25-0
app!i<!'!l shall be paid compensation as spedlled in that section.]
Your,; faithfully,

.....................

~.····

(Signature)
ANN£XllRE
(Please give replies agaJnst each l!el\1)

Item No.

I. No.me of the industrial e;tablishmmt lvith complete postal addrt!$$, including
telegraphic a d d - and b!lt>phoM oumber.
2. SCat"" of undertaking:(!) Whether Cenrral public secl01'/State public sector/ioreign mojority company/
joint $ector, etc.
(ii) lf belong$ to large industrial house, please .indicate the oonll:oll!ng group;
and if a foreign majo,rity company, indicate the extent <)( foreign holdiogs.
(iii) Wlwther the undertaking i$ licen•ed/ registeu-d and if so, name of
licensiog/ reg:i.rtration authority and licence/ registration cc.rtlficate numbers.
3. The total number and categories ol workmen affected by the prop<>Sf:d OO$\Ire,
along with the addresses of the workmen and the details of wag.. drawn by
them.
4. Ill!m5 of manulacture and scheduled ind\IStry /.industries und~r wbich they fall.
5. !ll'tAils rdatiJ1g to UCI!nSed cap.odty, installed capacity and the ulili.sed capacity.
6. (i) Annual produ.cti.on ilem·wi><! for pl't'Ct'dirig three years.
(ii) Production figures month-wise lot the preceding twelve months.
7. Work ill progcess-ite.m-wise and v3lue-wise.
8. Any arrangc'ment regarding off.Joodlng or sul>·oont:racting of products or any
con>poM!ll thereof.
9. Detailll of persons or the organi&,tion to whom the job/jobs 1.•/are being
entrusted rel~tlonship/interest of the per:;on&/organisations with the director/
directom or the offic:et/offl"" of lhf' rompany.
10. POSition of the order book-item-wise and v~wiSe lot a period of six months
and one year neJ« ioUowing. and for the period after the expiry of the S<~id """

year.
11. Number of working days in wtcl< With the number of shifls per day and the
Strength of workmen per each shift.
1. Subs. by S.O.. 2485. dated 20th May.

t985.

<!-- page 51 -->

Foml OAI

167

12. &l~'t!l 4!>d profit .. ml lo);>S MC'rount and audit r~rnrts IOO" the last lhm.
years.
13. Financial po•ltion ol the compa11y,
14. (i) Nanteo 111 inter-«tnno:>c\~.1 tM 1ponr or compa11le• u nder the ..:unc
m~gcml!nt.

(ii) O,lails 'bout lnll'rcorpnr.ue inv.,.lment 11nd chong"" dllrlng the last orw year.
(iii) lnttreot of any of the dlt~r$/Oflice!'! of the undertaluttt ptoducing ""ITl< or
sunilar lyJ't' ol product.
IS. P~tag" o( wages of worknwn 1<> th" ICital cost of pn..lu.1Wn
16 Admintstrabv.,, geneta1 and
,:(loll in i>b.olttl\' t«nn• ,~.,. ) e.r lor tlw IA•t
chree yea"' and perrentag~ tl\er<-;~1 t~ the total ro<l
17. Inventory position-item-wise and v•lue-wise lor the prt'<'l>ding nvelvc mMUil>
(bwentorie~~ to be shown in ""'P'l<'l of finished product.., <dtnponents and raw
materiAl!~ to be llhown separaMy tlem·wiloe a11d vRiu~· wlhC).
18. S.,lling •rrMgeole'l\t for the 111~1 tltrCI> y~an; and any rh•n~tc m the se!hn~
arra;ngc·mt·nt In pn..-..>ding twdve m(lnlhs.
lY. Full de~,O.< nf lfle interests nf lfle d.lr«toPs and olfic..D uf the ""npany 111 ll11•
organis<ttiQn•l 1'\'t>Cins involvfd IHI\4ilhns products ot the undertalung
lO. Buying >mngemenill for row mol.rii\l.s ..,d ctrotpon...,lo.
11. lnt..reil:. of tltv d\m.1ors and nlfkPn< with the org.uu.,3llt>n•/pel'll005 uwol-.-d In
buying raw mal~rials and compont.'flb ior the untlett•oku•ll·
22. Annual "'~ 6~ for the thl'\.ot )'l!lttS and month wl"" ..Jes figures for lh~
preceding twdve month~ bnlh l~·wlse and val.,.,.wl'i<!
23. R.ealoon.• fin the prop<l!led doour•
24. Any sp«ific •"=P~ made "" far to nold lfle
25. Any olht< rclennl fudon With d.UU. thereof.]

"'"lnl!

d"'""'

11"' 1

<!-- page 52 -->

LABOUR COURTS IN DELffi AND THEffi
JURISDICfiON ORDER1
In ilUP"N*-•i<m of this Government's order No. P. 25(1)/90/Sectt./Lab/ /03/
18285 dat<..od 8th june, 1990, th~ I.t. Governor of the 1-<ational Capital Terdtory of
Delhi, b pleased lo specify the jurisdictions of the Labom Cotuts for the purposes
of s ub-st>ctio.n (2) nf >ection 33-C of ihc lnJustri• l Disputes Act, 1947, ('14 <)f 'l947)
which shall have the jurisdictiort as shown ,1gainsl each in the table below,

namely:TAstE

51.

N•n•~ !)( th~ labouc

No.

C(.lUTt

I

labour (omt No. I

2'

L.1b<l\1r Cut.rl No. 2

3

l.ah>ur Courl No. 3

4

l.1bnur Court No. 4

Jwifidictlon
Area• und~r Bndarpur, Sarita Vil,.r, Sangam Vihar,
Nt•" l•riend• Colony, Kalloaji, Okhlo And HaJ<arat
Niz<lmudcen l'olice Stations of the South Districl
A~.as undt!r Aml)edlatr Nagar, Me)1rn uli, liaU2
Khas, Mal.1viy,, Nagar, Greater Kailash I, Chitranjan
i'ark, l..ajpal NagHr, Kotla Muborakpur, Defence
Colcmy, Srlniv~url and L.odi Rood l'olicc StnliQns of
th~ Sou th Di•trlr.t.
under Mangolpuri, Sultanpuri, K.lnjltawala,
L.m "'nee !load (J<csha ...putam), Sarru;wali Vihar
and Ash<»: Vlhar l'oHte !>'lations of the North West

Ar•••

Dislrn:l
Atcu..'t- und1...,. Narcla... S:!maypur, .J\lipur~ Bawa:na;
A<.l~n;h N•s~r. Model Tm"', Mukerjee Nagar,
ShaUJllllrb~gh,
Rohini, Prashan t Vihor and

5

WOO<Ir Court 1\o. 5

6

l.Jb.>ur O.>>lrl No. b

7
8

Lab<Jur tourt No. 7
LJbour C<>urt No. 8
Labour Courl No. 9
L.tbour Court Nt>. 10

9

lO

Jahangirpuri Police Stations of the North West
1>i>tsict.
Area~ under Anand Parbat, Moli NagM, Ptmjabi
B.1gh, Po.>d>'"' Vihar and NangloJ l'olice St.•llons of
the Wt.~t Dblrict,
Areas un<kr ra~el Nagar, IGrti Nagar, Rajouri
G.ud(-n, llari Nagar, J~nakpuri. Vd<tlspuri, Utlam
Nagar ,1nd hl.tk ..;agar Polire Stations of the West
District.
New Ddhl .111d Central Dirukn<.
F.a>t and North lill•t Districts
North District
So1>lh W<•>l DL•trict

Further, the s.ame labour Courts shall have the jurisdiction to entert-ain cases
of the work.~r;. faUin~ wrthin the scope of ••ed;on 2.1\. of the Industrial Disputes Act,
1947. (H of IY47) wher~ an indi,'idu.11 worker conremed may, within twelve

168

<!-- page 53 -->

LsbOIIr Ccurf8 In Delhi and lheir JurfsdJcliOfl OrdBr

169

months front the date of communication to him of the ordt'r of discharge, dismissal.
retrenchment or temtination or th~ date of comn\Cf\<"emcnt <)f th~ Industrial
Disputes (Delhi Amendment) Act. 2003, whiche\'er is later, file his industrial
dispute directly.
This order shall come into lorre with Immediate effect. Old casc.s/claJm~
already pending with the l..1bour Courts shall be dlspooed of by the Labour Courts
in which they are pending on the datt> olthe order.

By order and in th~ name Qf the Lt. Governor
tJf the National Clpital Territory of Dellu.

•••
