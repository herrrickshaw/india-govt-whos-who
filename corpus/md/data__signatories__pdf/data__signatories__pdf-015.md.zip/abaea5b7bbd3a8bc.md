---
doc_id: "abaea5b7bbd3a8bc"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/56c79d050ce6f7c06546ae28c2d6139d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment dated 25th February 2005 to License agreement for commercial VSAT"
date: "2005-02-25"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "61386ba96226c1e5"
---

<!-- page 1 -->

Government of India
Ministry of Communications & I.T.
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road,
New Delhi - 110001.
(LR Cell)
No. 815-1/2004-LR/A

Dated : 25.2.2005

To
Commercial VSAT Providers
Subject: Amendment to License Agreement for provision of VSAT service
using INSAT System.
The Clause No. 6.5 & 6.8 under “financial Conditions” of license No. 815- /
been amended to read as follows :

-LR has

6.5: Any delay in payment of LICENSE Fee, or any other dues payable under the
LICENSE beyond the stipulated period will attract interest at a rate which will be 2%
above the Prime Lending Rate (PLR) of State Bank Of India existing on 1st April of that
financial year. The interest shall be compounded monthly and a part of the month shall be
reckoned as full month for the purpose of calculation of interest.
6.8: In case, the total amount paid on the self assessment of the LICENSEE as quarterly
LICENCE Fee for the 4 (four) quarters of the financial year, falls short by more than 10%
of the payable LICENCE Fee, it shall attract a penalty of 50% of the entire amount of
short payment. This amount of short payment along with the penalty shall be payable
within 15 days of the date of signing the audit report on the annual accounts, failing
which interest shall be further charged as per terms of Condition 6.5. However, if such
short payment is made good within 60 days from the last day of the financial year, no
penalty shall be imposed.
The amendment will be applicable from 2005-2006 i.e. in respect of License Fees
arising for the period from 1st April 2005.
ADG(SAT-IV)
Tel:011-23717418
Copy to :
1.
2.
3.

Secretary, Telecom Regulatory Authority of India
DDG (LF)/Wireless Advisor, WPC
Jt. DDG (NOCC), Eastern Court, New Delhi

<!-- page 2 -->

Government of India
Ministry of Communications & I.T.
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road,
New Delhi - 110001.
(LR Cell)
No. 815/2004-LR/B

Dated :25.2.2005

To
Commercial VSAT Providers. (under NTP-99)
Subject: Amendment to License Agreement for provision of VSAT service
Using INSAT System.

The Clause No. 1.5 & 1.8 under “financial Conditions” of license No. 815- /
LR has been amended to read as follows :

-

1.5: Any delay in payment of LICENSE Fee, or any other dues payable under the
LICENSE beyond the stipulated period will attract interest at a rate which will be 2%
above the Prime Lending Rate (PLR) of State Bank Of India existing on 1st April of that
financial year. The interest shall be compounded monthly and a part of the month shall be
reckoned as full month for the purpose of calculation of interest.
1.8: In case, the total amount paid on the self assessment of the LICENSEE as
quarterly LICENCE Fee for the 4 (four) quarters of the financial year, falls short by more
than 10% of the payable LICENCE Fee, it shall attract a penalty of 50% of the entire
amount of short payment. This amount of short payment along with the penalty shall be
payable within 15 days of the date of signing the audit report on the annual accounts,
failing which interest shall be further charged as per terms of Condition 1.5. However, if
such short payment is made good within 60 days from the last day of the financial year,
no penalty shall be imposed.
The amendment will be applicable from 2005-2006 i.e. in respect of License Fees
arising for the period from 1st April 2005.
ADG(SAT-IV)
Tel:011-23717418
Copy to :
1.
2.
3.

Secretary, Telecom Regulatory Authority of India
DDG (LF)/Wireless Advisor, WPC
Jt. DDG (NOCC), Eastern Court, New Delhi

<!-- page 3 -->
