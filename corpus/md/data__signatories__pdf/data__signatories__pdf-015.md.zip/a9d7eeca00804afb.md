---
doc_id: "a9d7eeca00804afb"
source_url: "https://www.dhr.gov.in/static/uploads/2025/08/a55bd198f1e8d9d44fa656638bf809cb.pdf"
ministry: "Department of Health Research (DHR)"
title: "Notification"
date: "2025-09-02"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "94943d88c9e434a1"
---

<!-- page 1 -->

F. No. R-12018/03/2020-HRD-PartFile
Government of India
Ministry of Health & Family Welfare
Department of Health Research
2nd Floor, IRCS Building,
1, Red Cross Road, New Delhi — 110001
Date: py November 2020
OFFICE MEMORANDUM

Subject: Extension of the last date of call for online research proposals under ‘Grant-
in-Aid (GIA) Scheme of DHR for Inter-Sectoral Convergence and
Coordination for Promotion and Guidance on Health Research’ and
‘Human Resource Development (HRD) Scheme of DHR for Health

Research’ for the year 2020-21 — regarding.

The undersigned is directed to refer to the advertisements uploaded on the
website of DHR (dhr.gov.in) on 16.10.2020 on the subject mentioned above and to
say that the last date for call for proposals have been extended upto 27.11.2020.

५222
Deputy Secretary to the Government of India
Tel. No. 23736087
