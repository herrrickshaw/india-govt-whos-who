---
doc_id: "abffa211ecdf84b2"
source_url: "https://mohua.gov.in/static/uploads/2025/10/fc5088b028d1e134d781ca2d10690642.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Transfer Posting of PPS (3)"
date: "2025-10-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dda4e06d9e5b7fa3"
---

<!-- page 1 -->

f{

F.No. A-320n Atioi' l - tdmin.r (Vol.II)
Goverrrment of India
Ministry of Urban Development
(Shahari Vikas Mantralaya)

Ninnan Bhawan, New Delhi.
Dated

)GMaV.20t6

o['FrcE oRpER
The following internal transfers/postings in the grade of Principal Private Secretary are
ordered with immediate efTect and until further orders:

Name

of
the
Offi cer( S hri/ S rnt. /S mt. )

sl.
No.

Kamal Monga, PPS
D S Rawat, PPS

I
2.

From (place of 'fo (place of posting)
posting)

JS(w&H)

DG, CPWD

DG, CPWD

JS(w&H)
(S.K. Gupta)
Under Secretary to the Govt. of India
Tel. No.23061426

To
The Pay and Accounts Officer (Sectt.),
Ministry of Urban Development,
New Delhi.
Copy to:-

l. Officers concerned

2. JS(W&H)

' Director (Admin.), DG, CPWD with a request to forward the L,pC and service book of Shri
D S Rarvat, PPS to this Minishy.
4. PS to JS (A)
3

5. Admn-II (with a copy for p&AO)

6' Admn-lll/Admn-lv Section/ AV Unit of Ministry of Urban Development, New
Delhi.

7. cR seat/Service Book Seat/ personal file in Admn-l Section

8. Officerdrdcr File.
J

(S.K. Gupta)
Under Secretary (Admn)
