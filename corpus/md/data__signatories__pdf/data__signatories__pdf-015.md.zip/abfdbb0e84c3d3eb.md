---
doc_id: "abfdbb0e84c3d3eb"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/06/427b3bc5a605e368e17ac1703bfb1337.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Guidelines for Transition Facilitation (Quality Control) Order, 2026"
date: "2026-06-30"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ccc7ca4d8d051ed0"
---

<!-- page 1 -->

Government of India
Ministry of Commerce and Industry
Department for Promotion of Industry and Internal Trade
(Light Engineering Industries Section)

Subject: Guidelines for Transition Facilitation (Quality Control) Order, 2026

1.

PREAMBLE

1.1. The Guidelines are intended to operationalize the Transition Facilitation (Quality Control)
Order, 2026 as notified vide S.O. 3417 (E) dated 25.06.2026 (hereinafter referred to as
‘the Order’).
1.2. The Order establishes an alternative risk-based facilitation mechanism aimed at promoting
technology advancement or adoption, enhancing ease of doing business, and
strengthening supply chain resilience, while ensuring continued conformity with applicable
Indian Standards and safeguarding consumer interests. It further seeks to foster
cooperation with companies by providing handholding, particularly to those bringing
technology, design, and research and development into India.

2.

APPLICATION

2.1. An applicant shall be a company incorporated under the Companies Act, 2013 and submits
an application to DPIIT in order to avail of the exemption.
2.2. The applicant shall apply in the form at Annexure A, which shall be made available on the
National Single Window System (NSWS), and till the time such a facility is available, in
physical manner to the Joint Secretary/Director, DPIIT (I/c Technical Regulations), Ministry
of Commerce & Industry, Government of India. The application shall be accompanied by
the documents as specified in the form at Annexure A.
2.3. The applicant shall provide details of the goods or articles to be permitted for license under
the Order, including annual quantity of goods or articles to be permitted and their specific
8-digit ITC-HS codes, and the manufacturing facilities from where the goods and articles
1

<!-- page 2 -->

will be supplied. The applicant shall provide specific and sufficient details to enable the
Implementation Committee to conduct its assessment.
2.4. Where the applicant proposes to establish supply chain capabilities in India directly or
through contract manufacturing arrangements or partnerships, by promoting technology
adoption/ advancement, design capabilities, research and development, it shall provide
details of the activities to be conducted, supply chain capabilities to be developed,
proposed location(s) in India, and implementation plan along with timelines.
2.5. Wherever the applicant is being supplied from a manufacturing facility operated by, or
sourcing from a contract manufacturing facility under an arrangement with, its parent,
holding or group company, the applicant shall file a declaration authorized by the Board of
such entity confirming its manufacturing credentials or its arrangement for contract
manufacturing.
2.6. Where applicant relies on the credentials of a parent, holding company, or group company
under Clause 4(1) of the Order, the application shall additionally be accompanied by:
a) audited financial statements of the applicant entity for the preceding three financial
years;
b) factory registration certificate or equivalent industrial license issued by the relevant
authority in the jurisdiction of manufacture from where the articles or goods are to be
supplied;
c) evidence of the applicant’s or its parent, holding or group company’s technical
capability and control over the design and manufacturing of the goods or articles, which
may include patents or designs registrations, contractual specification rights, tooling
ownership documentation, engineering capability records, etc.; and
d) a declaration authorized by the Board of such entity confirming its relationship with the
Applicant.
2.7. The details provided in the application shall bear the approval of the Board of the company
or its parent, holding or group company, whichever is appropriate.
3.

IMPLEMENTATION COMMITTEE

3.1. The Implementation Committee shall have the following composition:
2

<!-- page 3 -->

i.

Addl. Secretary/Jt. Secretary (I/c Technical Regulations), DPIIT…… .........…Chair

ii.

Addl. Secretary/Jt. Secretary, DPIIT of the concerned Product…….……. Member

iii.

Jt. Secretary, Department of Commerce (DoC)…..…………….…………. Member

iv.

Representative of Directorate General of Foreign Trade (DGFT) (not below the
rank of Jt. Secretary level)…………………………………………….………. Member

v.

Representative

of

Bureau

of

Indian

Standard

(BIS)

(Jt.

Secretary

level)……...Member
vi.

Director/DS or equivalent (I/c Technical Regulations), DPIIT………...…...Convenor

3.2. The Chair may invite any other Ministry/ Department/ Organization. The representative
from other Ministries/departments/Organization should be not below the rank of
DS/Director.
3.3. The Committee shall assess applications in accordance with the risk based framework,
interact with the applicant for seeking clarifications, and give its recommendations with
regard to issue of permission letter to the applicant(s).

4. ASSESSMENT FRAMEWORK
4.1. The Implementation Committee may, while undertaking the risk-based assessment for
grant of permission, consider the following aspects of the applicant:
i.

Technical capability and demonstrated experience of the applicant in the relevant
product category;

ii.

Manner of ensuring quality across the supply chain, such as control over design,
specifications, and production processes;

iii.

Record of conduct and compliance integrity;

iv.

Commitment to establish and strengthen supply chain capabilities in India for the
concerned goods or articles, including through promotion of technological adoption/
advancement, development of design capabilities, or undertaking research and
development;

3

<!-- page 4 -->

Any other relevant considerations in public interest, including protection of human,
animal or plant health, safety of the environment, prevention of unfair trade practices,
and national security.

5. APPROVING AUTHORITY:
5.1. The recommendation of the Implementation Committee will be submitted for approval of
Hon’ble Union Minister of Commerce and Industry.
5.2. Government may convey the permission letter laying down the conditions under which the
exemptions under the Order would be availed.

6. CONDITIONS FOR APPROVAL:
6.1. The permission letter issued by DPIIT may specify the products covered, the quantity limits,
the validity period, the milestones, details of the manufacturer(s) and the reporting
requirements, etc.
6.2. The applicant shall cooperate with market surveillance activities.
6.3. The supply of permitted goods shall be as per the extant import-export policy, and
investment shall be as per the FDI Policy of Government of India.
7. MONITORING AND COMPLIANCE.
7.1. The Applicant shall submit to DPIIT, within sixty days of the end of each year reckoned from
the date of the undertaking, an annual compliance report certified by a practicing Chartered
Accountant, setting out the status of implementation of conditions contained in the
permission letter.
7.2. The details of the consignments and declaration regarding the grant of BIS license as
mentioned in Clause 3(1) of the Order, shall be filed with DPIIT on the online facility
provided for the purpose on a quarterly basis as would be specified in the letter to the
applicant, and till the time such a facility is available in physical manner to the Joint
Secretary/Director, DPIIT (I/c Technical Regulations), Ministry of Commerce & Industry,
Government of India.
4

<!-- page 5 -->

7.3. The permission granted under this Order shall be subject to periodic review. In case of
doubt, a post audit wherever required by 3rd party reputed audit agency may be conducted
to verify the conditions and compliances.
7.4. The Committee shall not be required to conduct any physical verification of the
manufacturing units for the purpose of the assessment.
7.5. In case of non-conformance to the Indian Standards or failure to meet the committed
milestones, the Central Government may withdraw the permission granted under this
clause and take appropriate action.

8. REVIEW, SUSPENSION OR WITHDRAWAL
8.1. Permissions granted shall be reviewed annually. Review shall include compliance with
standards, surveillance findings, implementation of milestones.
8.2. Permission may be suspended or withdrawn where material misrepresentation is
discovered, product fails to conform to Indian standards, surveillance reveals noncompliance, applicant fails to implement commitments under any plan submitted by it.

5

<!-- page 6 -->

ANNEXURE A
Draft Application Form
1. Applicant Details
Applicant Details: (Mandatory)

1.1.

Name
of
Applicant

the

Corporate Identification
Number (CIN)

PAN
(auto-populate
from CIN)

Importer Exporter
Code (IEC)

Website

Copy of Certificate of Incorporation, & IEC certificate of the applicant, to be uploaded.

Registered Office
Address-Line 1

Registered
Office
Address-Line 2

City/ District

State/UT

Pin code

GSTIN
Registered
office

of

Copy of GST certificate of the applicant, as applicable, to be uploaded.
Authorized Person of the Applicant: (Mandatory)

1.2.

Primary Authorised signatory
S. No.

Name

Designation

Passport/ Aadhar number

PAN

Email

Mobile
Number

Passport/ Aadhar number

PAN

Email

Mobile
Number

Additional Authorised signatory
S. No.

Name

Designation

Copy of Authorisation letter to be uploaded. Copy of self-attested Passport/ Aadhar and PAN card to be
uploaded.
2. Eligibility requirements
2.1.

Whether the applicant : (Mandatory to select 1)
i. Committing to develop supply chain capability through itself or
ii. Committing to develop supply chain capability through Contract manufacturing Agreement.
6

<!-- page 7 -->

iii. Successful Quality Control Order implementation for 3 years
Whether the applicant is promoting: (Mandatory in case 2.1.(i) & (ii) selected)

2.2.

i. Technology Adoption / Advancement
ii. Design
iii. Research & Development
2.3.
S. No.

Details of Products for which Application is being made:
Product

Indian Standard

Concerned QCO

(Mandatory )

(Mandatory )

(Mandatory )

Total Investment
in
Plant
&
Machinery
(Mandatory in case
2.1.(i)
&
(ii)
selected)

2.4.

S.No.

Proposed Installed
Capacity
Select Units : Nos /
MT
(Mandatory in case
2.1.(i) & (ii) selected)

Details of Parent/Holding/Group Company(ies) whose credentials have been used for
qualifying the eligibility criteria under the Order (as applicable)
Company Name

Registered Address

Country of
incorporation

Relation with the
Applicant

Copy of Audited financial statements of such entity for the preceding three financial years, to be uploaded.
Copy of Factory registration certificate or equivalent industrial licence issued by the relevant authority in
the jurisdiction of manufacturer, to be uploaded.
Copy of Declaration authorised by the Board of such entity confirming its manufacturing credentials, its
relationship with the Applicant, to be uploaded.
2.5.

S.No.

Details establishing technical capability of the Applicant or its parent, holding or group
company’s: (Mandatory in case 2.1.(i) & (ii) selected)
Brief on Technical Capability

Details of Document provided

Copy of document supporting applicant’s or its parent, holding or group company’s technical capability
and control over the design and manufacturing of the goods or articles, which may include patents or
designs registrations, contractual specification rights, tooling ownership documentation, engineering
capability records, etc, to be uploaded.

7

<!-- page 8 -->

Current manufacturing facilities for the concerned Product in India of Applicant & its
Parent/Holding/Group Company (ies): (Mandatory in case 2.1.(i) & (iii) selected)

2.6.

S. No.

Company
Name

Address

GSTIN

Current
production
capacity per annum
(in number of units)

Concerned
Indian
Standard, if
applicable

Concerned QCO

3. Details of Products to be imported (Mandatory)

Product
S.
No.

Specific 8-digit Indian
ITC-HS Codes Standard

Name &
Address of the
Foreign
Manufacturer
(s)

Whether supplier is a
Group Company,
Parent/Holding/Group
Company/ Contract
Manufacturer?

Supplying
Country

4. Project details
4.1.

Details of Contract Manufacturers in India (Mandatory, if 2.1.(ii) is selected):

Value
of
Procurement
S. Company Address GSTIN Date of
by
the
No. name
Contract
Applicant in
Manufacturing last
Agreement
Financial
Year

Proposed
Investment

Copy of Contract/ Manufacturing Agreement to uploaded.
8

Current
production
capacity
per annum
(in number
of units)

Proposed Commitment
production of Applicant
capacity
to procure
per annum
(in number
of units)

<!-- page 9 -->

4.2.

Proposed facility(s) for enhancing supply chain capabilities for Eligible Product under the
Order (Mandatory, if 2.1.(i) is selected):

S. No. Address

City/District

State/UT

Pin code

GSTIN

Proposed
Installed
Capacity

Whether new
facility is
greenfield/
brownfield
project?

Copy of Investment Plan with Board approval to be uploaded.
4.3.

Plan for promoting technological adoption/ advancement, or design capabilities, or
research and development (as applicable). (Mandatory in case 2.1.(i) & (ii) selected)
Plan with Board approval to be uploaded.

4.4.

Indicative breakup of Investment to be made (INR Crores): (Mandatory in case 2.1.(i) & (ii)
selected)

Particulars

Details

Land
Building (of main plant and utilities)
Plant, Machinery & Equipment
Others (Technological adoption/
advancement, or design capabilities,
or research and development)
Total
Cumulative Investment

4.5.

Milestones/ Timeline of the Plan proposed by the Applicant: (Mandatory in case 2.1.(i) &
(ii) selected)

Milestone
Acquisition of Land (if applicable)
Order of 50% of Plant & Machinery

Year 1
Yes/ No
Estimated Value to be
mentioned in INR
Crores
9

Year 2

Year 3

<!-- page 10 -->

Commencement of Pilot
Production
Commencement of Commercial
Production
Proposed Direct Employment (in No.s)
Proposed Exports (in INR Crores)

Yes/ No

Yes/ No

Yes/ No

Yes/ No

Yes/ No

No information to be provided n Grey box -

Note: All the above-mentioned document(s) to be uploaded shall be attested
5. Compliance & Conduct Intergity:
5.1.

I confirm that ________ (Applicant) has a demonstrated track record of complying with
applicable Quality Control Orders (QCOs) in India for a continuous period of at least three (3)
years preceding this application, without any default. (Mandatory in case 2.1.(iii) is selected)
Copy of BIS license for the concerned QCO and its renewal certificate (if any), to be uploaded.

5.2.

I confirm that ________ (Applicant) has a demonstrated track record of complying with
applicable laws and regulations, and confirms that there have been no instances of material noncompliance affecting its credibility or operations. (Mandatory)

6. Declaration: (Mandatory)
6.1.

The data, documents, declaration and any other information submitted in this application form is
based on the latest information available with me and is true and correct to the best of my
knowledge and belief. I have read and understood the provisions of the Transition Facilitation
(Quality Control) Order, 2026 as notified vide S.O. ______ dated ________ and relevant
guidelines thereto and have submitted all information, data, documents and declaration in
accordance with the same. Any decision taken by Department for Promotion of Industry and
Internal Trade, Ministry of Commerce & Industry with respect to acceptance of this application,
eligibility under the Order, and any other related matter will be final and binding on the Applicant
company.
I understand the Terms & Conditions.

Authorised Signatory
Date:
Designation

10
