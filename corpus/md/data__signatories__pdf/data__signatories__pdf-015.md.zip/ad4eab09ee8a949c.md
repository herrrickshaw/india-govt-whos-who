---
doc_id: "ad4eab09ee8a949c"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/09/57ea2ad9b925f3d1cd576517b782104c.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Laksh Hospital, Bhandara, Maharashtra"
date: "2023-06-30"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b2abfa0a88a8f040"
---

<!-- page 1 -->

No. S. 14021/16/2021-EHS
Govemment of India

Ministry of Health & Family Welfare
Nirman Bhawan, New Delhi
Dated the 30'h June, 2023

0 F' l-t C E NIEIIORAT\DUNt
Subject: Empanelment of "Renewal of empanelment of "Laksh Ilospital, Bhsndara, Maharashtra" under
CS (MA) Rules, 1944.

*Renewal of empanelment of
The undersigned is direcred to say that the proposal received for empanelment of
.Laksh Hospital, -Bhandara, Maharashtra" for Beatment of Central Govemment Employees and their family
members under Central Services (Medical Attendance) Rules, 1944 has been examined in this Ministry and it has been
decided to empanel the Hospital under CS (MA) Rules, l9zl4.

The Schedule of charges for the treatment of Central Govemment Employees and the members of their family
under the CS (MA) Rules, 1944, will be the rates fixed for CGHS (NABH), or hospital's o\r'n rates, whichever is less.

2.

The approved rates are available on the website ofCGHS and may be downloaded/ printed.

3.

The undersigned is further directed to clarify as under: -

(a)

"Package Rate" shall mean and include tump sum cost of in-patient treatmenr/day care/diagnostic procedure
ior which a CS(MA) beneficiary has been permitted by the compet€nt authority or for treatment under emergency fiom
the time of admission to the time of discharge, including (but not limited to){i) Registration charges, (ii) Admission
charges, (iii) Accommodation charges including patient's diet, (iv) Operation charges, (v) Injection charges, (vi)

Dressing charges, (vii) Doctor/consultant visit charges, (viii) ICU,{CCU charges, (ix) Monitoring charges, (x)
Transfuiion charges, (xi) Anesthesia charges, (xii) Operation theatre charges, (xiii) Procedural charges / Surgeon's fee,
(xiv) Cost of surgical disposables and all sundries used during hospitalization, (xv) Cost of medicines, (xvi) Related
investigations, (xvii) Physiotherapy charges etc, (xviii) Nursing care and charges for its services.
ioutine and

""."niial

(b)

Cost of Implants is reimbursable in addition to package rates as per CGHS ceiling rates for implants.

(c)

',Renewat of empanelment of"Laksh Hospital, Bhandara, Maharashtra" shall not charge
package rates fixed for CGHS (NABH) rates.

more than the

(d) Expenses on toiletries, cosmetics, telephone bills etc. are not reimbursable and are not included in package rates.
4.

Package rates envisage duration ofindoor treatrnent as follows:

Up to 12 days: for Specialized (Super Specialties) treatment
Up to 7 days: for other Major Swgeries
Up to 3 tlays: for Laparoscopic surgerieJnormal Deliveries
for day care/\'Iinor (OPD) surgeries'
I

day

No additional charge orr account of extended period of stay shall be allowed ifthat extension is due to infection on the
consequences of surgical procedure or due to any improper procedure and is not justified'

<!-- page 2 -->

-)ln case, there are no CGHS prescribed rates for any test/procedure, then AIMS rates are applicable. If there are no
AIIMS rates, then reimbursement is to be arived at by calculating admissible amount item-wise (e.g. room rent,
investigations, cost of medicines, procedure charges etc) as per approved rates/actually, in case of investigations.

5.

(a) CS (MA) beneficiaries are entitled to facilities of private, semi-private or general ward depending on their
pay.
The eotitlement is as follows:basic
S.No.

l.

z

orresponding Basic Pay drawn by the officer in 7" Ward Entitlement

t:PC per month
JUpto Rs. 36,500/-

lGeneral Ward

lns. :o-soti- to 50,500L

Semi-Private Ward
Private Ward

3. 1R.J0500/- and ,bo*

(b) The package rates given in rate list ofCGHS are for semi-private ward.

(c) The package rates prescribed are for semi-private ward. If the beneficiary is entitled for general ward there
will be a decrease of l07o in the rates; for private ward eDtitlement there will be an increase of 150/0. However, the rates
shall be same for investigation irrespective of entitlement, whether the patient is admined or not and the test, per-se,
does not require admission.

6.

The hospital shall charge from the beneficiary as per the CGHS (NABH) , prescribed rates or its own rate list
whichever is lower.
7.

(a) The maximum room rent admissible for different cateSories would be:
General ward

Semi-private ward
Private ward
Day care (6 to 8 IIrs.)

Rs. 1500/- per day
Rs. 3000/- per day
Rs. 4500/- per day
Rs. 5001 (same for all categories)

(b) Room rent mentioued above at (a) above is applicable only for reatment procedures for which there is no
CGHS prescribed package rate.
Room rent will include charges for occupation ofbed, diet for the patient, charges for water and electricity supply, linen
charges, nursing charges and routine up keeping.
(c) During the treatment in ICCU CU, no separate loom rent will be admissible.

(d) Private ward is defmed as a hospital room where single patient is accommodated and which has an attached
(tavatory
and bath). The room should have fumishings like wardrobe, dressing table, bed-side table, sofa set, etc.
toilet
as well as a bed for attendant. The room has to be air-conditioned.
(e) Semi Private ward is defined as a hospital room where two to three patients are accommodated and which
has attached toilet facilities and necesmry fumishings.

(f) General ward is defined as hall that accommodates four to ten patietrts.
Continue...3

<!-- page 3 -->

-3-

(g) Normally the treatment in higher category of accommodation than the entitled category is not permissible.
However, in case of an emergency when the entitled category accommodation is not available, admission in the
immediate higher category may be allowed till the €ntitled category accommodation becomes available. However, ifa
particular hospital does not have the ward as per entitlement of beneficiary, then the hospital can only bill as per
entitlement ofthe beneficiary even though the Eeatment was given in higher tlpe of ward.

I! on the request of the beneficiary, treatment is provided in a higher category of ward, then the expenditure
over and above entitlement will have to be bome by the beneficiary.
8.

In case of non-emergencies, the beneficiary shall have the option of availing specific treatmenti investigation

from any of the empanelled hospitals of hiVher choice (provided the hospital is recognized for that treatment
procedure/test), after the specific treatment/investigation has been advised by Authorized Medical Attendant and on
production of valid ID card and permission letter ftom hisher concemed Ministry/Department.

9.

The hospital shall honour permission letter issued by competent authority and provide treatment/investigation
facilities as specified in the permission letter.

10.

The hospital shall also provide treatment/investigation facilities to the CGHS beneficiaries and their eligible
dependent family members at its own rates or rates approved under CS (MA) Rules, whichever is lower. The hospital
shall provide treatment to p€nsioner CGHS beneficiaries after authentication through verification ofvalid CGHS Cards.

11. However, pensioner CGHS beneficiaries would make payment for th€ medical treatment at approved rates as
mentioned above and submit the medical reimbursement claim to the Addl. Director, CGHS drough the CMO i/c of the
CGHS Wellness Centre, where the CGHS Card of the beneficiary is registered.
12.

[n case of emergencies, the beneficiary shall have the option ofavailing specific treatment/investigation fiom
any of the empanelled hospitals of his/her choice (provided the hospital is recognized for that treatm€nt procedure/test),
on production of valid ID card, issued by competent authority.

13. During the in-parient rreatment of the CS (MA) beneficiary, the Hospital will not ask the beneficiary or his
attendant to purchase separately the medicines/sundries/equipment or accessories from outside and will provide the
treatment within the package rate, fixed by the CGHS which includes the cost ofall the items.
14.

In case of treatment taken in emergency in any non-recognized private hospitals, reimbursement shall be

considered by competent authority at CGHS prescribed Package/rates only.

15.

If one or more minor procedures form part of a major treatment procedure, then package charges would be

permissible for major procedure and only 50% of charges for minor procedure.

16.

The Hospital shall agree for conducting all iovestigation/diagnostic testVconsultations etc. ofthe Central Civil
Services Group "A' OIlicers of age of 40 years and above and olher categories of CGHS/CS (MA) beneficiaries as
specified by government from time to time as per prescribed protocol as per Annexure, subject to the condition that the
hospital shall not charge more than Rs. 2000/- for conducting the prescribed medical examination ofthe male officers
and Rs. 2200 for female ofiicers of Central Government who come to the hospital/institution with the requisite
permission letter from their Ministry/Department/Competent authority. The above rates for medical examination are

valid until such time when the above rates are revised by the Central Govemment.

Continue...4/

<!-- page 4 -->

-4-

17.

Any legal liability arising out of such services shall be the sole responsibility and shall be dealt with by the
concerned empanelled hospital. Services will be provided by the Hospital as per the terms given above.

18.

Ministry of Health & Family Welfare reserves the right to withdra cancel the above recognition without

assigning any reason.

19.

The order takes effect from the date of issue of the O.M. The hospital stands recognized under CS (MA) Rules,
1944 for a period of4 (four) years fiom the date ofissue ofthis O.M.

20.

"Renewal of empanelment of "Laksh Ilospital, Bhandara, Maharashtra" will have to enter into an

agreement (copy enclosed) with the Govemment of India to th€ effect that the Hospital will charge from the Central

Governm€nt employees at the rates fixed by the Govemment and they will have to sign a Memorandum of
Understanding (MoU) within a period of 3 months from the date of issue of the above mentioned OM failing which the
Hospital will be derecognized (Two original copies of MoU printed on the stamp paper and duly signed by the Hospital
to be sent to this Ministry for necessary action). Subject to above, the Hospital can start lreating Central Government
employees covered under CS (MA) Rules, 1944.

21. A communication in acceptance ofthe Para 20 above may be sent to the undersigned within a week from the
receipt of this Office Memorandum.

$"$'}9t
(Hemlata Singh)
Under Secretary to the Government of India

tr'6)
To,

r. Laksh Hospital Takiya Ward, Bhandara-rul906 (Maharash

"4ffiffi"

2. AllMinistriesiDepartmentsofcov'oflndiaasperdiroiur,ioo'ilil
3. Directorate General ofHealth Services (MG-tr Section)
4. Estt-yEstt.IyEstt.[yEstt.[V Sections, Ministry of Health & Family Welfare.
5. Admn.yAdmn.Il Sections of Directorate General Health Services
6. OfEce of the Comptroller and Auditor General of India, Bahadur Shah Zafar Marg, New Delhi.
7. Finance Division of Ministry of Health & Family Welfare, Nirman Bhawan, New Delhi
8. All staff side members of National Council (JCM).
9. MC, Nimran Bhawan, with the request that the O.M. be uploaded in the website of the Ministry.
10. Hindi Section for Hindi version.

t1. Guard file ofEHS Section.

<!-- page 5 -->

MOU
No. S. 14021/16/2021-EHS

Memorandum ofUnderstanding between The Central Government and "Renewal of empanelment of "Laksh
Hospital, Bhandara, Maharashtra" for recognition under CS (MA) Rules, 1944.
Whereas, this Memorandum of Understanding is made on.... . . .. ..... . .. .....(Date) b€tween the president of
India who shatl be the l" party and "Renewal of empanelment of'Laksh Eospital, Bhandara, Maharashtra" who
shall be 2"d party under which the HospitaVlnstitution shall undertake for the treatment ofCentral Govt. employees.
Whereas, the *Renewal of emprnelment of "Laksh Hospitat, Bhandara, Mrharashtra" had applied for recognition
under CS (MA) Rules, 1944 for treatment of Central Govemment Employees;

And whereas the Cenral Govemment in the Ministry of Health and Family Welfare vide its O.M. No 5.14021/16/2021EHS dated....................(Recognition Date) had recognized "Renewal of empanelment of "Laksh Hospital'
Bhandara, Maharashtra" under CS(MA) Rules, 1944 for treatment of Central Govemment Employees and Members
of their families subject to the condition that the schedule of charges for treatment of Central Govemment Employees
and members of their family under CS(MA) Rules, 1944 shall be regulated as per the schedule of approved charges of
CGHS rates and also subject to the condition that the "Renewal of empanelment of "Laksh llospital' Bhandara,
Maharashtra" would enier into an agreement with the Govemment of India within a period of 3 months from date of
issue of O.M., to the effect that the hospital witl charge Central Govemment employees at the rate fixed by the
Govemmenr, failiag which the hospital would be derecognized. The hospital shall charge CGHS (NABH) rates or its
own rates, whichever is less. If the hospitat gets NABH accreditation, then it will charge CGHS- NABH rates or its own
rates, whichever is less, till the expiry of its accreditation.

(Laksh Hospital'
Now, therefore, the Central Govemment and the "Renewal of empanelment of
Bhandar& Maharashtra" hereby enter into an agreement to be mutually adhered to by both the parties whose terms,
conditions and applications are as below:-

l.

*Renewal of empanelment of

"Laksh llospital, Bhandara, Maharashtra" is recognized under CS (MA)

Rules, 1944 for treatment

of Central Govemment Employees and Members of their family subject to the conditions that:..Renewal of empanelment of *Laksh llospital, Bhandarq Maharashtra" will charge all the Central
Govemment Employees as per
website of CGHS.
ll

I

ll.

the schedule of approved charges of CGHS, which are available on the

"Renewal of empanelment of "Laksh Hospital, Bhandara, Maharashtra" shall, in no circumstance, charge
an amount more than that agreed to as para l(i) above from any Central Government employee for a period of4
years fiom the date of issue ofthe O.M. or until such time that the rates are revised by the Central Govemment;
..Renewal of empanelment of
"Laksh Hospital, Bhandara, Mahrrtshtra' t5u11 ns1 disqriminate in any way
against the Central Government Employees receiving treatment in the hospital as compared to any other patient;
The hospital shall provide access to the financial and medical records for review by medical and financial

auditors ofthe Central Govemment, as and when necessary;
The Hospital witl pay damages to the beneficiaries, if any injury, loss of part or death occurs due to gross
negligence, or due to transfusion of improperly checked blood, if such injuries occur in consequence of
treatment in the hospital/diagnostic centre.
Any legal liability coming our of such services shall be dealt with by the hospitaVdiagnostic centre and it shall
alone be responsible.

vll.

In case of any complaint of overcharging/ deficiency in services the Central Govemment may, after due
enquiry, reserve the right to derecognize 'Renewal of empanelment of "Laksh Hospital, Bhandara'
Maharashtra" without any notice, and without any prejudice to any other action to be taken as per law.

<!-- page 6 -->

Further, sRenewal of empanelment of "Laksh Hospitrt, Bhandara, Maharashtra" shall undenake
investigation/diagnostic tests/consultations etc. of the Central Civil Services Group "A" Officers of age of40 years and
above and other categories of CGHS/CS (MA) beneficiaries as specified by govemment from time to time as per

2.

prescribed protocol as per Annexure, subject to the condition that:

.Renewal of empanelment of "Laksh Hospital, Bhandsra, Maharashtra" shall not chfige more than Rs.
2000/- for conducting the prescribed medical examination of the male officers and Rs. 2200 for female officers
of Central Govemment who come to the hospital/institution with the requisite permission letter fiom their
lt.

iii.

t\'.

Ministry/Department/Competent authority.
The above rates shall be valid until such time when the rates are revised by the Central Govemmenq
..Renewal of empanelment of *Laksh Hospital, Bhandara, Maharashtra' shall not discriminate in any way
against the Central Government officerVemployees for conducting the investigations/diagnostic
tests/consultations/examinatioDs etc in the hospital as compared to any other patient;
Any legal liability arising out of such services shall be dealt with by the hospital/institution and it shall alone be
responsible.

The Central Govemment reserves the right to derecognize "Renewal of empanelment of "Laksh Hospital'
Bhandara, Maharashtra" - 44l906after due enquiry, in the case ofany complaint of overcharging/deficiency
in service, without any notice, and without prejudice to any other action to be taken as per law.

3.

None of the parties could change any provision contained in this MoU without the written consent of the
other party. The laws of the Govemment of India shall govem the construction and interpretation ofthis MoU.

4.

If any provision of this MoU or any provision of any document incorporated by reference shall be hold

invalid, such invalidity shatl not affecl other provisions of this MoU. This MoU can be given effect without the invalid
provision and to this end, its other provisions are declared to be severable.

5.

This MoU contains the entire Agreement b€tween the two parties and no statement, promise or inducement
made by either party, its authorized parties or expert groups that are not contained in this MoU shall be valid and
binding. This MoU can be modified or altered only on written agreement signed by both the parties.

6.

The original copy ofthis Memoraldum of Understanding (MoLI) shall be kept at the office ofFirst Party and
a true copy shall be retained in the office of Second Party.

Signed on

For the Hospital

-:-------

day of -----------"-- 2023

For Central Govemment.
