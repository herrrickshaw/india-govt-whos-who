---
doc_id: "ab7494e53ebecae3"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/ED-Appointmend-GIC.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "ED-Appointmend-GIC.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cfd634de2db11516"
---

<!-- page 1 -->

F. No. A-l l0l li05l2023Jns.I

Government of India
Ministry of Finance
Department of Financial Services
Jeevan Deep Building, 2nd floor
Sansad Marg, New Delhi- I l0 001
Dated 9m JulY, 2024

To:

Chairman-cum-Managin g Director

GIC RC
Mumbai

Subject: Appointment of Executive Director
Sir,

I am directed to hereby convey that the Appointment Committee of the Cabinet has
approved proposal of Department of Financial Service for appointment

of:

(i)ShriHiteshRameshChandraJoshi(dateofbirth:19.9.1968),cunentlyGeneral
pay of
i,iunug", in GIC Re to the post of Executive Director in GIC Re, in the scale of
Rs. t,io.goo-z,z+,000 with Lffect from the date of assumption of office

and up to the date

ofhisattainingtheageofsup€rannuation(i'e',30'9'2028)'oruntilfurtherorders'
whichever is earlier; and

(ii)Ms.RadhikaC.S.(dateofbirth:24.6.1965),currentlyGenerallVlanagerin.United
lndialnsuranceCompanyLimitedtothepostExecutiveDirectorinGlCRe'inthescale
and.up
of pay of Rs. t,76,gOb-2i4,OOO with effect from the date of assumption of offrce
further
until
or
to the date of her auaining the age of superannuation (i e'' 30'6'2025)'
orders, whichever is earlier.

2.

A copy of the Board's approval for their appointment as Executive Director in the

companymaypleasebefumishedtothisDepartment'alongwiththedateofassumptionofoffice.
Yours faithfullY

)L&,l!fu_
[:a-1
o9l o1

lAbdul Gdfrin)
Under Secretary to the Govemment of India
Tele: 0l I 23748788
Email: abdul.qufran@nic.in

<!-- page 2 -->

l-F

F. No. A-l l0l l/05/2023-lns.I

Dated 9th luly,2024

Copy to:

l) Shri Hitesh Ramesh Chandra Joshi, General Manager, GIC Re

2) Ms. Radhika C. S., General Manager, UIICL

ij Establistrment officer, Departrnent ;f personnel and Training w.r.t their communication no.
l8l t t 12024-EO(ACC) dated 08.07.2024
4) P.S. to F.M. / P.S. to MoS (Finance)
Sr. ePs to Secretary (DFS)/PS to Additional SectEtary (DFS)
61 Joint Secretary flnsurance), Departrnent ofFinancial Services
chai.p"rson, iniurance Regulaiory and Development Authority oflndia
8) Chairperson, Life lnsurance Corporarion oflndia
Chairman<um-Managing Director NIACL/OICLNICLTIICUAIClL

5j

zi

9i

l0) Secretary, FSIB, Mumbai
I l) Director (lnsuranceJl)
l2) Guard File

lru)

(Abdul

tJffi^"..*

Under Secretary to the Govemment of India
