---
doc_id: "adc0e0bae28dfaee"
source_url: "https://financialservices.gov.in/sites/default/files/rti/2026-06/Appointment-of-CPIOs-AAs-16.06.2026.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Appointment of Central Public Information Officers (CPIOs)/Appellate Authorities (AAs) in the Department of Financial Services"
date: "2026-06"
pages: 22
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "7d41311b10cbe4b4"
---

<!-- page 1 -->

»!
F.No.12/6/2013-RTI
Government of India
Ministry of Finance ‘
Department of Financial Services
(RTI Cell) :
3rd Floor, Jeevan Deep Building,
10, Parliament Street, .
New Delhi - 110001
Dated: 1.6" June, 2026
OFFICE ORDER .
Sub: - Appointment of Central Public Information. Officers (CP1Os)/Appellate Authorities (AAs) in the
Department of Financial Services under section 5(1) and (2) of the Right to Information Act,
2005.
In supersession of this Department's Office Orders of even number dated 15.05.2026 and है
20.05.2026, consequent upon the changes due to postings/transfers/promotions/superannuation ete.
of the Officers in the Department of Financial Services, the list of Central Public Information Officers :
(CPIOs)/Appeliate Authorities (AAs) is hereby modified as under:
List of Central Public Information Officers (CPIOs)/Appellate Authorities (AAs) in the
Department of Financial Services
Name, Designation,. |Name, Designation, e-
e-mail address, mall address and . हि
telephone number of telephone number of Work Allocation
Central Public Appellate Authority
information Officer |(AA)
: (CPIO)
| पिला ४७४७ वि ल्‍:"“______ $$ ||
1. |Sanjay Kumar Mohamed Ashraf J.S. {Banking Operations ~1 (BO-1):
Mishra Deputy Secretary :
Under Secretary + Appointment of Governor/ Deputy
Governor of RBI, Chairman & MDs
lusbo1-dfs@nic.in lashraf.js@gov.in of SBI, CMDs and EDs of a
(Tel No, 23747189) (Tel No. 23346874) Nationalised Banks, salary
allowances and other terms and
conditions of Whole Time Directors
of PSBs.
* Constitution of Boards of Directors :
है of RBI and PSBs: appointment of *
Workmen Employee Directors, i
appointment of Part Time Non- '
हि Official Directors and Officer :
Employee Directors of PSBs. ‘
« Nomination of Directors on the
Board of PSBs.

<!-- page 2 -->

2 |Abhay Joshi Manasa Gangotri Kata [Banking Operations - II (BO-II):
Deputy Direcior Director
« Administration of alt
Acts/Regulations/Rules related to |
labhay.joshi@gov.in _|gangotri.kata@nic.in Financial Systems like the
(Tel No. 23748743) —j(Tel No. 23360250) Negotiable Instruments Act, 1881,
the Chit Funds Act, 1982 and the
Price Chits and Money Circulation
Schemes (Banning) Act, 1978,
: etc., Banning of Unregulated
: Deposit Scheme Act, 2019
« Deposit Insurance and Credit
Guarantee Corporation (DICGC), :
Act, 1961. ः
e Goordination of work on matters |
related to Disaster management |
and crisis management.
« Payment and Settlement System
Act, 2007,
« Matters relating to Digifocker,
wherein the proposal is to enable
the updation of the address of the
account-holder in banks.
« Disposal of appeals received unde
section 9 of the Payment and
हु Settlement Systems Act, 2007
« Factoring Regulation Act, 2011.
« State Legislations — Protection of
Interest of Depositors Acts of State .
Governments :
« Matters relating to Multi-Level :
Marketing and Ponzi Schemes.
« Setting up of iFSC — GIFT.
* International Relations (Banking) /
Bilateral issues
« International Cooperation in. WTO,
RCEP, JCCII and
CEPAs/CECAs/FTAs of India with :
bilateral and multilateral partners.
e Matters relating to Financial Sector :
Development Council and its Sub-
committees.
» Matters relating to Central
Economic Intelligence Bureau
(CEIB)
« Matters relating to office of Court
Liquidator, Kolkata
« Work relating to Government :
Agency Business
e Financial Action Task Force
FATF);

<!-- page 3 -->

« Setting up of Currency Chest by
banks in border districts (within 80
Km of International Border)
» Rationalization of Bank Holidays / है
declaration of bank holidays under},
: section 25 of the Negotiable
; Instruments Act, 1881 .
« Know Your Customer (KYC) all :
matters - AML and CFT matters
¢ Matter pertaining to FSDC :
SL including coordination with RBI
IK M Nandakumar Swapnil Agrawal Financial Services Custome!
Under Secretary Director Excellence (FSCE): :
« Customer Service in Banks/Fl/Ins.
km.nandakumar@nic.in |dir.sa-dfs@gov.in ¢ All kinds of complaints/
(Tel No, 23748746) (Tel No. 23348993) representations received from
individual/ associations for
redressal of their grievances in
these institutions such as delay in
| clearance of cheques, non- :
payment/non-issue of drafts, non- :
issue/delay in issue of duplicate
drafts, misbehaviour/rude
behaviour/ harassment on the part
of staff of the Institution, non-
settlement/ delay in settlement of
deceased accounts, non-
transfer/delay in transfer of
accounts from one office to
another, non-opening/delay in
opening of new accounts, non- ;
compliance with standing
instructions of the customers, non-
payment of term deposits before
maturity, delay in payment to
pensioners, including those related
to credit cards, ATMs, grievances
relating to NPS , UPS and APY
etc. :
. « Allkind of complaints received
from DARPG/DPG relating to
Public/ Private Sector/Foreign
Banks/Fi/Ins.
¢ All kinds of complaints received
from MPs/VIPs /PMO against
Private Sector & Foreign Banks.
« Banking Customer Service
¢ Banking Ombudsman. :
+ Coordination of PRAGATI
meetings

<!-- page 4 -->

4 Jnanatosh Roy Jitendra Asati Banking Operations & Accounts-| (BOA-
Under Secretary Director (1
jnanatosh.roy@nic.in dirbanking-dfs@gov.in ° हक जा the working conpolidated
(rel No 2374875 » (Tel No. 23344462) Sector Banks (PSBs) and laying it
. on the Tables of both Houses of
Parliament.
« Pattern of accounting and final
accounts in Public Sector Banks.
« Study and analysis of the working
results of PSU Banks.
« Taxation matters of PSBs/Fls.
e Dividend payable to Central
हु Government by PSBs.
¢ Scrutiny of the annual financial
reviews of PSBs conducted by RBI
under Section 35 of the Banking
Regulation Act, 1949 and follow up
हे action.
. ¢ Capital restructuring of PSBs
(including restructuring of weak
PSBs) and Government's
contribution to share capital, public
issue of banks.
e Release of externally aided grants
to ICICI Bank under USAID.
+ Disputes and arbitration between
PSBs and between PSBs and
other Govt. Departments/PSEs.
« Appointment of advocates in
PSBs.
. » Residuary matters of Portuguese
Banks in Goa.
« Opening and shifting of
administrative offices of banks.
e All Policy matters related to
Banking Operation such as
Licensing, amalgamation,
reconstruction, moratorium funds,
and acquisition of private sector
banks.
e Functioning of PSBs
« Notification regarding exemption
from various sections of the
Banking Regulation Act, 1949 and
appointment of appellate authority ;
to hear appeals under BR Act and हि
Banking Companies (Acquisition
: and Transfer of Undertakings) Act
of 1970 and 1980 ;

<!-- page 5 -->

» Administration of all Acts/
Regulations/ Rules related to
Public Sector Banks, RBI and
State Level Banks
« Laying of annual reports and audit
reports etc., of PSBs in Parliament
[Anitesh Kumar Neelam Agrawal Banking Operation & Accounts — II (BOA-| i
Under Secretary Director HI): :
हि . « Credit Information Companies
lboa2-dfs@nic.in dir-boa2@gov.in (CICs).

(Tel No. 23748751) _|(Tel No. 23744571) » Works relating to monitoring of /
NPAs and Recovery including
compromises and OTS of all :

हि 72589. :
« Parliament matters, VIP/PMO
references, complaints and other i
matters relating to above works.
e All matters related to
NPA/Stressed Assets (other than
Sectoral Stress), including relief
measures by banks in area
affected by natural calamities.
» Stressed Assets Stabilization Fund
(SASF).
» Audit of banks, appointment and
: fixation of remuneration of auditors
of PSBs/Fls.
» Bank guarantees, Letters of Credit
. and Letters of Undertaking /
Comfort by PSBs and related
है complaints.
« Citizen's Charter of PSBs/RBI.
* Acquisition/Leasing/Renting/Vacati |
on of premises, Estate Officers
under Public Premises Act, 1971.
« Operation of foreign banks in India
(including IDC and FDI Policy
matters).
» Banking Sector Reforms (including
EASE Index and PSB Reforms
Agenda)
« NBFCs and Appellate Authority on
NBFCs.
e Operational risk management
(other than cyber-security and
digital payments security),
including frauds and fugitive
offenders.

<!-- page 6 -->

« Administration of all
Acts/Regulations/Rules related to
: NBFCs and CICs.
« Statement of Intent / Key
Performance Indicators /
Performance evaluation of whole-
time Directors.
. + Insolvency Bankruptcy Code (IBC)
« Overseas branches of Indian
banks
a |“ फऊखञ़ख़खऊ खख'<घ खखखख * NBFC Appeal related matter _
ह Vijay Shankar Tiwari [Mohamed Ashraf J.S. [Industrial Relations (IR):
Under Secretary Peputy Secretary « Service matters of PSBs including
IDBI/ RBI हे ह
it@nic.in lashrat js@gov.in न dustrial Disputes bas te ear
* हि है maiters relating sani
(Tel No. 23748753) | (Tel No. 23346874) Unions and Associations in the
Banking Industry, Bipartite
settlements of policy of transfer,
promotion, and HRD in banks :
« 1B reports about politica! activities :
of bank employees.
s Pay and Allowances of bank
employees in overseas branches
« HR Reforms.
7 ~~ |Ratnakar Jha Shwetha Rao B Agriculture Credit (AC):
Under Secretary Pirector » Credit flow to Agriculture and allied
sectors
ratnakar.moca@nic.in |director.ea-dfs@gov.in * mace A ee maven and Debt
(Tel No. 23740615) [Tel No. 28748736) + Matters relating to NABARD
(including pension maiters of :
NABARD), Agriculture Finance
Corporation (except Service
matters), State Legislations on the
subject, Co-operative Banks
{including Urban Co-operative
Banks), external aided projects
relating to rural/agriculture credit,
appeals made by co-operative
banks, financial assistance to
persons affected by natural
calamities, riots disturbances, etc.
Bank credit to KVIC, handloom and}
handicraft sector, |
« Citizen Charter of NABARD
« Appointment of CMDs & Directors 5
of NABARD
« Kisan Credit Card (KCC) Scheme

<!-- page 7 -->

« Secretarial assistance to the
designated appellate authority in .
regard to appeal by Urban
Cooperative banks against
cancellation of license by RBI.
Kr. Shyamal Shwetha Rao B IRegional Rural Bank (RRB):
Parthsarathi :
. + Legislative matters with regard to :
Under Secretary ——_—Pirector RRB Act, 1976 and framing of
rules there under.
» Nomination of non-official directors
ishymal.pr@nic.in ldirector.ea-dfs@gov.in on the Board of RRB, appointment
(Tel No. 23747119) (Tel No. 23748736) of Chairman, Recommendation of
RRBs, review of performance of
RRBs, wage revision, manpower
. planning.
« Laying of Annual Reports of all :
RRBs along with review thereof,
: « Formation of Staff Service
Regulation and Promotion Rules
for employees and officers of
RRBs, IR matters of RRBs.
« Citizen's Charter of RRBs. :
+ Priority Sector Lending, Micro
Finance and other related matters
which includes lending to weaker
: sections including SC/ST, PM's
New 15 Point Programme for the
Welfare of Minorities, Credit to
minorities, follow up action of
Select Parameters recommended
by Sachar Committee, DRI
Scheme.
urinder Kumar Vivek Gupta Financial Inclusion (Fl):
Under Secretary PPirector « National Mission for Financial
Inclusion (NMFI) related matters
usfi-dfs@nic.in lvivekgupta.irs@gov.in including moe of flagship
(Tel No. 23365808) (Tel No. 23748718) » Pradhan Mantri Jan Dhan Yojana
(PMJDY) (Policy &
implementation)
« Pradhan Mantri Jeevan Jyoti Bima
Yojana (PMJJBY) (Only
implementation)
« Pradhan Mantri Suraksha Bima
Yojana (PMSBY) (Only
implementation)
« Pradhan Mantri Mudra Yojana
(PMMY) (Policy & implementation)

<!-- page 8 -->

« Stand Up India (SUP!) (Policy &
implementation)

« Work relating to financial inclusion,
coordination with other sections,
offices, institutions etc on Financial
inclusion.

« Branch expansion of banks

« Lead Bank Scheme and Service

. Area Approach.

« District and State Level Bankers'
Committee (SLBC).

« Regional imbalances of banking
network, matters related to
Business Correspondents/
Business Facilitators, Mobile

हि Banking etc.,

e Deployment of banking

touchpoints/BCs/ATMs and Jan
Garima Kapoor शिया Parshak App (JDD) related
Deputy Secretary » BC related policy matters including

monitoring of their activities.

: हे « Matters relating to Minimurn
garima.kapoor25@gov.in deposit balance, cash handling &
(Tel No. 23748775) digital payment charges;

* Administrative matters of Mission
Office. हे

« Banking matters Pradhan Mantri
Jan Dhan Yojana (PMJDY),

Mission Office

» India Post Payment Banks (IPPB)
and other payment bank related
matters.

« Inter- State Zonal Council
Meetings.

¢ Aspirational District, LWE and
other interventions for financial
inclusion by government.

¢ Financial Literacy, Coordination

‘ with RBI on National Strategy for
Financial Inclusion (NSFI)/
Financial Inclusion Advisory
Committee FIAC)/ TGFIFL and !
related issues i

: » Matter related to 75 Blocks —
DoNER program (SAMBHAV),
SVAMITVA Scheme, Antyodaya
program, AKAM 2.0, SVANidhi. :
PM Vishwakarma Scheme etc. :
Under Secretary Director

<!-- page 9 -->

luscoord-dfs@nic.in _ |vinod.k70@gov.in . Organisation rus meetings with
Inath.gopi@nic.in (Tel No. 23748742) s of PSBs and regional!
(Tel No. 23365608) consultative committee meetings.
. « Staff Meeting of Secretary (FS)
Senior Officers Meeting (SOM).
» Monitoring & Review of disposal of :
VIP references, PMO references, 2
coordination of RBI pending
matters.
e Parliament Questions regarding
VIP references.
« Monthly DO letter to Cabinet
Secretary from Secretary (FS).
« Updation of Induction Material for :
DFS; Co-ordination of VIP, PMO, 1
President-Sectt.,etc, references :
\ involving more than two Divisions
of DFS.
11 {Sudip Dutta A K Thakur Establishment (ESTT):
Under Secretary Director
« Matters pertaining to the Officers
and Staff of DFS including RRs, :
lusestt-dfs@nic.in thakur.ak@nic.in appointment, ACRs, deputation
lsudip.dutta@nic.in (Tel No. 23748731) (including abroad), training, IWSU,
\(Tel No. 23747413) . SIU, welfare, review of officers ः
under FR 56(J), internal vigilance,
. staff grievances, pension, etc.
« Grant of various advances to
officers and staff, payment of fees
to advocates, settlement of :
medical claims and CGHS matters,
family welfare programme.
Rahul Kumar A K Thakur IGenerat Administration (GA):
है Under Secratary Director « Housekeeping/Security matters,
cleanliness, stores, canteen, R&l,
rahul.kumar84@nic.in |thakur.ak@nic.in rey . .
(Tel No, 23362349) _|(Tel No. 23748731) * Staff Car Drivers, vehicles to the
officers of DFS. :
: » Purchase of Computer Hardware
and maintenance of Computers,
Printers and other equipment
» Maintenance of furniture and
electricity items
+ Logistic support for arranging
farewell of staff of DFS.
» Providing of Identity Cards to the
Staff of DFS and CMDs/EDs/PROs
of Public Sector Banks/Financial

<!-- page 10 -->

Institutions/Insurance companies,
a ३ 0 रझ्झझः etc.
13  jRakesh Kumar Dixit |Dheeraj Bhaskar Parliament (Parl.):
Under Secretary Deputy Secretary * Collection, identification and
है marking of Parliament Questions,
. a Notices, admitted Questions, and
lus.welfare@nic.in dheeraj.bhaskar@nic.in ot »
(Tel No. 35740725) (Tel No. 23365809) eee the files approved from the
« Preparation of facts and replies for
pads of Ministers. :
« Keeping track and record of
pending Assurances, Special
Mentions and References under
377 and other matters as
mentioned in the Induction
Material. : i
¢ Presidential address to the Joint
Session of Parliament
e ‘Compilation and submission of
materia! for Parliament Questions
to other Ministries/Departments. :
« Parliamentary Committee Matters
14 |Dharmbir [Dheeraj Bhaskar Hindi (OL):
Deputy Director Deputy Secretary « Implementation of Official
Language Policy of the :
a . oe Government. :
lol@nic.in dheeraj.bhaskar@nic.in . relati
‘ [Tei No. 23742134) {Tel No. 23905800) + Translation work relating to
Parliament Questions.
+. Standing Committees, Minutes of
the Meetings.
¢ - Hindi Teaching Scheme and other
miscetlaneous work as mentioned
in induction material of DFS.
15 {Rakesh Kumar Dixit |Dheeraj Bhaskar elfare (WEL):
Under Secretary Deputy Secretary
+ Matters relating to recruitment,
promotion and welfare measures :
lus.welfare@nic.in dheeraj.bhaskar@nic.in of SC/ST/OBC/PH and Ex- :
(Tet No, 23748725) —|(Tel No. 23365809) servicemen in Public Sector
. Banks/Financial Institutions and :
Public Sector Insurance
Companies (PSBs/Fls/PSICs).
« Matter of policy regarding
reservation for these categories in
PSBs/Fls/PSICs, reservation :
matters in RRBs etc. :
: « Inspection/examination of :
. Reservation Roster for -
SCs/STs/OBCs in PSBs/Fls/PSICs
