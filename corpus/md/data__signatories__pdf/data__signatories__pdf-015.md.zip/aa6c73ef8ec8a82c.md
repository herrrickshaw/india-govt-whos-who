---
doc_id: "aa6c73ef8ec8a82c"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/10/8b02cd9219d067dba13ada7d04e80ebf.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "The Administrative Tribunal (Procedure for investigation of misbehavior or incapacity of Chairmen, Vice-Chairmen and other Members) Rules, 2000"
date: "2000-02-07"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e60a1570945e420"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

The Gazette of India
EXTRAORDINARY
PART II—Section 3—Sub-section (i)

PUBLISHED BY AUTHORITY

No. 80]

343 GI/2000

NEW DELHI, MONDAY, FEBRUARY 7,2000/MAGHA 18,1921

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

<!-- page 3 -->

3

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC 3(i)]

<!-- page 5 -->

5

MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES AND PENSIONS
(Department of Personnel and Training)
NOTIFICATION
New Delhi, the 7th February, 2000

G. S. R. 91(E).— In exercise of the powers conferred by sub-section (3) of
section 9 read with sub-section (1) and clause (b) of sub-section (2) of section 35 of the
Administrative Tribunals Act, 1985 (13 of 1985), the Central Government hereby makes
the following rules, namely :1. Short title and commencement-(l) These rules may be called the
Administrative Tribunals (Procedure for investigation of misbehaviour or incapacity of
Chairmen, Vice-Chairmen and other Members) Rules, 2000.

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) They shall come into force on the date of their publication in the Official
Gazette.
2. Extent of application.-These rules shall be applicable to every Chairman,
Vice-Chairman, Administrative Member and Judicial Member of the Central
Administrative Tribunal, Administrative Tribunals for States and Joint Administrative
Tribunal for two or more States established under the Act.
3. Definitions.-(l) In these rules, unless the context otherwise requires,(a) "Act" means the Administrative Tribunals Act, 1985 (13 of 1985);
(b) "Administrative Member" means a Member of the Central
Administrative Tribunal, Administrative Tribunal for a State or, as the case
may be, of a Joint Administrative Tribunal for two or more States established
under the Act who is not a Judicial Member within the meaning of clause (i)
of section 3;
(c) "Chairman" means a Chairman of a Tribunal and includes a ViceChairman authorised to act as the Chairman in accordance with section 7;
(d) "Committee" means the Committee referred to in sub-rule (2) of rule
4;

(e) "Judge" means a sitting Judge of the Supreme Court appointed by the
President under sub-rule (2) of rule 5 to conduct the inquiry;
(f) "Judicial Member" means a Member of a Tribunal appointed as such
under the Act, and includes the Chairman or a Vice-Chairman who possesses
any of the qualifications specified in sub-section (3) of section 6;
(g) "Member" means a Member (whether Judicial or Administrative) of a
Tribunal, and includes a Chairman and a Vice-Chairman;
(h) "section" means a section of the Act;
(i) "Tribunal" means the Central Administrative Tribunal or a State
Administrative Tribunal or a Joint Administrative Tribunal established under
the Act;
(j) "Vice-Chairman" means a Vice-Chairman of a Tribunal.
(2) Words and expressions used herein and not defined but defined in the
Administrative Tribunals Act, 1985 (13 of 1985) shall have the meaning
respectively assigned to them in that Act.
4. Committee for investigation of complaints.-(1) If a written complaint,
alleging any definite charges of misbehaviour or incapacity to perform the
functions of the office in respect of a Member, is received by the Central
Government, it shall make a preliminary scrutiny of such complaint.

<!-- page 7 -->

7

(2) If, on preliminary scrutiny, the Central Government considers it necessary
to investigate into the allegation, it shall place the complaint together with
supporting material as may be available, before a Committee consisting of the
following officers to investigate the charges of allegations made in the
complaint:(i) Cabinet Secretary

- Chairman;

(ii) Secretary, Ministry of Personnel, Public Grievances
and Pensions

(iii)

- Member;

Secretary, Department of Legal Affairs, Ministry of Law, Justice
and Company Affairs

-Member.

(3) The Committee shall devise its own procedure and method of
investigation which may include recording of evidence of the complainant and
collection of material relevant to the inquiry which may be conducted by a Judge
of the Supreme Court under these rules.
(4) The Committee shall submit its findings to the President as early as
possible within a period that may be specified by the President in this behalf.
5. Judge to conduct inquiry.-(1) If the President is of the opinion that there
are reasonable grounds for making an inquiry into the truth of any imputation of
misbehaviour or incapacity of a Member, he shall make a reference to the Chief
Justice of India requesting him to nominate a Judge of the Supreme Court to
conduct the inquiry.
(2) The President shall, by order, appoint the Judge of the Supreme Court
nominated by the Chief Justice of India for the purpose of conducting the inquiry.
(3) Notice of appointment of a Judge under sub-rule (2) shall be given to the
Member concerned.
(4) The President shall forward to the Judge a copy of-

(a)

the articles of charges against the Member concerned and the
statement of imputations;

(b)

the statement of witnesses, if any ; and

(c)

material documents relevant to the inquiry.

(5) The Judge appointed under sub-rule (2) shall complete the inquiry within
such time or further time as may be specified by the President.

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(6) The Member concerned shall be given a reasonable opportunity of
presenting a written statement of defence within such time as may be specified in
this behalf by the Judge.
(7) Where it is alleged that the Member concerned is unable to discharge the
duties of his office efficiently due to any physical or mental incapacity and the
allegation is denied, the Judge may arrange for the medical examination of the
Member by such Medical Board as may be appointed for the purpose by the
President and the Member concerned shall submit himself to such medical
examination within the time specified in this behalf by the Judge.
(8) The Medical Board shall undertake such medical examination of the
Member as may be considered necessary and submit a report to the Judge stating
therein whether the incapacity is such as to render the Member unfit to continue
in office.
(9) If the Member refuses to undergo such medical examination as considered
necessary by the Medical Board, the Board shall submit a report to the Judge
stating therein the examination which the Member has refused to undergo, and the
Judge may, on receipt of such report, presume that the Member suffers from such
physical or mental incapacity as is alleged in the Member.
(10) The Judge may, after considering the written statement of the Member
and the Medical Report, if any, amend the charges referred to in clause (a) of subrule (5) and in such a case, the Member shall be given a reasonable opportunity of
presenting a fresh written statement of defence.
(11) The Central Government shall appoint an officer of that Government or
an advocate to present the case against the Member.
(12) Where the Central Government has appointed an advocate to present its
case before the Judge, the Member concerned shall also be allowed to present his
case by an advocate chosen by him.
6. Application of the Departmental Inquiries (Enforcement of Witness
and Production of Documents) Act, 1972 to inquiries under these rules.-The
provisions of the Departmental Inquiries (Enforcement of Witness and Production
of Documents) Act, 1972 (18 of 1972), shall apply to the inquiries made under
these rules as they apply to departmental inquiries.
7. Powers of Judge.-The Judge shall not be bound by the procedure to be laid
down by the Code of Civil Procedure, 1908 (5 of 1908) but shall be guided by the
principles of natural justice and shall have power to regulate his own procedure
including the fixing of places and times of his inquiry.
8. Suspension of Member.- Notwithstanding anything contained in rule 4
and without any prejudice to any action being taken in accordance with the said
rule, the President, keeping in view the gravity of charges may suspend the
Member of the Tribunal against whom a complaint is under investigation or
inquiry.

<!-- page 9 -->

9

9. Subsistence allowance.- The payment of subsistence allowance to a
Member under suspension shall be regulated in accordance with the rules and
orders for the time being applicable to a Secretary to the Government of India
belonging to the Indian Administrative Service.
10. Inquiry Report.- After the conclusion of the investigation, the Judge shall
submit his report to the President stating therein his findings and the reasons
therefor on each of the articles of charges separately with such observations on
the whole case as he thinks fit.

[No. A-11013/10/98-AT]
R. K. TANDON, Jt. Secy.

Printed by the Manager, Govt of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications,
Delhi-110054.

<!-- page 10 -->
