---
doc_id: "ac8fb5fd161c9f5e"
source_url: "https://shipmin.gov.in/sites/default/files/Draft%20guidelines%20for%20Pillar%201i.e.%20SBFAS%20%20NSbM_.pdf"
ministry: "Ports, Shipping and Waterways (MoPSW)"
title: "Draft guidelines for Pillar 1i.e. SBFAS NSbM_.pdf"
date: ""
pages: 168
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ced834c4b2ef19de"
---

<!-- page 1 -->

File No. SY-13017/2/2014-SBR
Government of India
Ministry of Ports, Shipping and Waterways
(SBR Section)
3rd Floor, PTI building,
1 – Parliament Street,
New Delhi – 110001
Dated: November 4th, 2025

To,
1. CMD, Cochin Shipyard Limited (CSL)
2. CMD, Shipping Corporation of India (SCI)
3. CMD, Hindustan Shipyard Limited
4. CMD, Mazagon Dock Shipbuilder Limited
5. CMD, Goa Shipyard Limited
6. CMD, Garden Reach Shipbuilder and Engineers Limited (GRSE)
7. CMD, Swan Defence and Heavy Engineering
8. CMD, L&T Shipbuilding
9. CMD, Shoft Shipyard pvt. Ltd.
10. CMD, Chowgule and Company Pvt. Ltd.
11. CMD, Titagarh Wagon Limited
12. CMD, Chowgule Global
13. Head, ISTC
14. Directorate General of Shipping
15. Advisor, Shipyards Association of India (SAI)
16. CEO & MD, Indian Shipbuilders Association of India (ISBA)
17. CEO, Indian National Shipowenrs Association (INSA)
18. VC & CEO, Gujarat Maritime Board (GMB)
19. New India Assurance (NIA)
20. Export Credit Guarantee Corporation of India (ECGC)
21. Sagarmala Finance Corporation Limited (SMFCL)
22. Indian Register of Shipping (IRS)
23. Indian Maritime University (IMU)
24. Centre of Excellence in Maritime and Shipbuilding (CEMS)
25. Ship Recycling Industries Association (SRIA)
26. International Shipyards (HD KSOE, Hanwha Ocean, Imabari Shipyards, CMA
CGM, AP Mollar Maersk, MSC, Damen Shipyards, Royal HSC, DP World,
NYK Line Japan)
27. Container Shipping Lines Association (CSLA)

Subject: Draft Guidelines for P1 i.e., Shipbuilding Financial Assistance Scheme &
National Shipbuilding Mission (NSbM) – reg.
Sir,
The undersigned is directed to say that Union Cabinet, in its meeting held on
24.09.2025, approved the Shipbuilding Financial Assistance Scheme (SBFAS)
and National Shipbuilding Mission (NSbM) of this Ministry to promote
shipbuilding in India.

<!-- page 2 -->

2.

In this regard, it is stated the draft guidelines for the above
been prepared in consultation with various stakeholders. A copy of
submitted for perusal. NIC team is requested, the same have been also

scheme have

draft guidelines is
on the Ministry

website/portal.

3.

It is requested that your opinion / comments on draft guir
Division in the attached proforma latest by 13th November, 2025
mail - js-shipping@gov.in, js-ports@nic.in, dirl-psw@gov.in and

4.

DG Shipping is requested to upload the same on their portal and
suggestion from public/stakeholders.

5.

be sent to SBR
on the following
-psw@gov.in.
inputs/ comments/

Your Co-operation and early reply will be highly appreciated.
Yours faithfully,

(*r
(Pranav Mittal)
to the Golt. of India
Tet: 0l l -233 1 1659
-psw@gov.in

<!-- page 3 -->

Format for seeking comments on Guidelines for adopting
Shipbuilding Financial Assistance Scheme (SBFAS) and National
Shipbuilding Mission (NSbM)

Organization/Agency Name :
Address with Contact details:

Type of Agency (GovVPrivate/PSU/lndividual/othe0 :
Para wise remarks on the draft:

sl.

Para No. ol Existing text in the draft Proposed

No.

the Draft

guidelines

Remarks

changes

Other Remarks (lf any):

E-mail this format to js-shipping@gov.in, js-ports@nic.in, dirl psw@gov. in and usshipping2-psw@gov. in.

<!-- page 4 -->

Committee Report on formulation
of Draft Guidelines for Ship
Building Financial Assistance
Scheme (SBFAS)

<!-- page 5 -->

INDEX
Sr. No.
1
2

3

4

5

6

7
8

Background
Minutes of Stakeholder meeting dated
10.10.2025 at MoPSW (Physical/Online)
– Annexure I
Minutes of meeting- core committee
along with other stakeholders- dated
14.10.2025 (Online) – Annexure II
Minutes of meeting – core committee
along with other stakeholders- dated
17.10.2025 (Physical/Online) – Annexure
III
Minutes of meeting - core-committeedated 30.10.2025 (forenoon) (Online) –
Annexure IV
Minutes of core-committee meeting with
other stakeholder dated 30.10.2025
(afternoon) (Physical/virtual) – Annexure
V
Summary of all stakeholder suggestions
and action taken – Annexure VI
Draft SBFAS Guidelines - Annexure VII

Page Number
3-6
7-12

13-20

21-30

30-39

40-66

67-91
92-165

<!-- page 6 -->

1. Background
In pursuance of the Office Memorandum No. SY-13017/III/2025-SBR dated 9th
October 2025 issued by the Ministry of Ports, Shipping and Waterways (MoPSW), the
Directorate General of Shipping (DGS) was entrusted with the task of constituting
three committees for formulation of guidelines under the Shipbuilding Development
Scheme (SBDS) and the Shipbuilding Financial Assistance Scheme (SBFAS).
Accordingly, three committees were constituted:
1. Committee-I – For framing guidelines on the Shipbuilding Financial Assistance
Scheme (SBFAS).
2. Committee-II – For framing guidelines on Capacity and Capability Building of
Greenfield Shipbuilding Clusters and Brownfield Shipyard Expansion Projects.
3. Committee-III – For formulating Credit Risk Coverage Guidelines for
Shipbuilding Projects.
This report pertains to the work carried out by Committee-I, constituted to prepare draft
guidelines for Shipbuilding Financial Assistance Scheme (SBFAS)
2. Objective of the Committee
The Committee was established to:




Operationalize the ₹24,736 crore corpus allocated under Shipbuilding
Financial Assistance Scheme.
Develop the institutional framework for release of financial assistance to the
Shipyards.
Ensure alignment with the Cabinet-approved framework for the Shipbuilding
Financial Assistance Scheme (SBFAS).

The guidelines aim to provide financial assistance to Indian Shipyards to offset the
cost disadvantages of Indian shipyards viz-a-viz foreign shipyards.
3. Constitution of the Committee
As per MoPSW’s order, the Directorate General of Shipping (DGS) constituted
Committee-I with representation from:







MoPSW (Director–SBR)
Directorate General of Shipping (DGS)
Shipyard Association of India (SAI)
Indian Shipbuilders Association (ISBA)
Indian Register of Shipping (IRS)
Gujarat Maritime Board (GMB)

<!-- page 7 -->







Shipping Corporation of India (SCI)
Ship Recycling Industries Association (SRIA)
Cochin Shipyard Limited (CSL)
Indian National Shipowners Association (INSA)
ICC Shipowners Association (ICCSA)

Director (SBR), MoPSW served as the Member from the Ministry, and an officer from
DGS, Shri Ankur Anal, Jr. Ship Surveyor-cum-Asst. Director General (Tech), acted as
the Member Convener of the Committee.
4. Meetings Conducted with Stakeholders

Date

Type

Venue

Participants
MoPSW, DGS,
SAI, ISBA,CSL
Physical/Hybrid
IRS, GMB, SCI,
Stakeholder
INSA, ICCSA,
10.10.2025
meeting
MoPSW
SRIA, GRSE,
convened by
MDL, L&T and
MoPSW
other industry
participants.
MoPSW, DGS,
SAI, ISBA,CSL
Online
IRS, GMB, SCI,
Stakeholder
14.10.2025
Virtual
INSA, ICCSA,
Meeting with Core
SRIA, GRSE,
committee
MDL, L&T and
other shipyards.
DGS, GMB,
Gujarat Maritime
Physical/Hybrid
regional
Board Office,
Stakeholder
shipyards (L&T,
17.10.2025
GIFT City,
Meeting with Core
ABG, Chowgule,
Ahmedabad
committee
Mandovi), cluster
(Hybrid)
associations
MoPSW, DGS,
SAI, ISBA, CSL
Core Committee
30.10.2025(Forenoon)
Virtual
IRS, GMB, SCI,
(Internal Review)
INSA, ICCSA,
SRIA
Directorate
MoPSW, DGS,
30.10.2025
Physical/Hybrid
General of
SAI, ISBA, CSL
(Afternoon)
Stakeholder
Shipping (Hybrid) IRS, GMB, SCI,

<!-- page 8 -->

Meeting with Core
committee

INSA, ICCSA,
SRIA and other
shipyards.

5.Institutional Framework




Nodal Body: National Shipbuilding Mission (NSbM) – Apex oversight body.
Implementing Agency: Directorate General of Shipping (DGS)
Corpus Allocation: ₹24,736 crore including ₹4001 crore towards
shipbreaking credit note.

6. Key Deliberations
6.1.1 The detailed list of deliberated items and inputs from stakeholders on the
Shipbuilding financial assistance scheme guidelines are attached as Annexures I to
Annexure V
6.1.2 The Minutes of meetings for the three core committee meetings along with
industry stakeholders and one only core-committee meeting is attached.

7. Items to be Finalized with NSbM
The following aspects require policy-level finalization by the National Shipbuilding
Mission (NSbM):
1. Effective date for applicability of Guidelines for Shipbuilding Financial
Assistance Scheme.
8. Annexures








Annexure I: Minutes of Meetings dated 10.10.2025
Annexure II: Minutes of meeting dated 14.10.2025
Annexure III: Minutes of meeting dated 17.10.2025
Annexure IV: Minutes of meeting dated 30.10.2025 (forenoon)
Annexure V: Minutes of meeting dated 30.10.2025 (Afternoon)
Annexure VI: Summary of all stakeholder suggestions and action taken –
Annexure VII: Draft SBFAS guidelines
Submitted by
(Ankur Anal)
Jr. Ship Surveyor-cum-Asst. Director General (Tech)
Member Convener – Committee on Shipbuilding Financial Assistance Scheme

<!-- page 9 -->

Directorate General of Shipping, Mumbai
To:
The Director General of Shipping
For onward submission to
Ministry of Ports, Shipping and Waterways (MoPSW)
Government of India

<!-- page 10 -->

Annexure I
Minutes of Meeting
Stakeholder Consultation on Shipbuilding Financial Assistance Scheme
(SBFAS) Guidelines
Date: 10th October 2025
Time: 10:00 Hrs – 18:00 Hrs
Venue: Online Discussion
Convened by: Ministry of Ports, Shipping & Waterways
Participants:
Representatives from MoPSW, DGS, INSA, CSL, IRS, MSC, SCI and other
shipyards.
Key Discussion Points and Actions Taken
During the consultation held on 10th October 2025, several key issues and
clarifications were discussed under the Shipbuilding Financial Assistance Scheme
(SBFAS).
1. Shri. KK Dhawan (IRS) requested that the new scheme guidelines be prepared
in the same format as the SBFAP 1.0 guidelines, as the industry is already
comfortable with that format and there will be limited ambiguity.
Action Taken: DGS informed that the new guidelines have been prepared on
the same skeleton as that of the previous guidelines.
2. Shri. Saket Kandoi (Titagarh Rail Systems) sought clarity on whether auxiliary
vessels (non-combat) of the Navy will be included under the scheme.
Action Taken: DGS Clarified that the vessels built for defence purposes or for
use by Navy or Coast Guard have been excluded. However, vessels like tugs,
tankers, cargo ships and passenger ships that are not fitted with any weaponry,
contracted for construction by foreign defence entities are eligible.
3. Shri. Anil Devli (INSA) asked whether, if a shipowner scraps a vessel after
placing a new ship order, the scrap credit note will still be counted towards
eligibility under SbFAS. Further requested clarification on the term “Fair Scrap
Value” and the methodology for its evaluation. Also, suggested that brokers or
independent evaluators should be selected from an empanelled list of
evaluators with defined criteria, and that there should be a periodic review of
the list.

<!-- page 11 -->

Action Taken: DGS clarified that, the credit note can be tagged with a new
build anytime before the last payment is received by the ship owner. For the
“Fair Scrap Value” and the methodology for its evaluation was explained.
Checklist for assessment of international valuators has been prepared and
added as an Annexure to the draft guidelines.
4. Anil Devli (INSA) suggested that the Certificate of Recycling (CoR) issuance
process should be based on clear, transparent, and standardized parameters
to avoid operational hurdles or delays. The process should be digitized and
automated through online portals.
Action Taken: This issue will be separately discussed with State Maritime
Boards to ensure a smooth and transparent process.

5. Anil Devli (INSA) mentioned that in many cases, shipowners directly contract
with suppliers and procure components rather than the shipyard doing so.
Suggested the possibility of allowing shipowners to seek SbFAS benefits as
well, depending on the nature of the contract between the shipowner and the
shipyard.
Action Taken: DGS clarified that, as per the Cabinet note, financial assistance
is to be paid directly to the shipyard only not the shipowner.
6. Nikhil Raj (SCI) requested clarity on the commencement of SbFAS and the start
date of SbFAS 2.0.
Action Taken: DGS clarified that the commencement date of SbFAS is yet to
be finalized.
7. Rajeev Nayyer (Swan) raised concern regarding the Domestic Content
Requirement (DCR) for specialized vessels where equipment costs are high,
making it difficult to achieve the 40% threshold. Requested clarification on
whether the percentage is linearly proportional or exponential, and on how the
subsidy will be calculated on a pro-rata basis.
Action Taken: The calculation is based on pro rata basis with 30% DC = 75%
FA, >=40% DC = 100% FA, <30% DC = 0% FA, >30% DC<40% DC - Linear
variation. Calculation methodology has been detailed in Schedule V of the draft
guidelines.

<!-- page 12 -->

8. Pandurang Dhond (Chowgule & Co.) suggested defining eligibility in the case
of Self-Build by shipyards. If shipyards build vessels without a confirmed buyer
or for captive use, they should still be eligible to claim the subsidy.
Action Taken: In the current scheme, a shipbuilding contract is mandatory.
Thus, shipyards need to sign a shipbuilding contract to avail financial
assistance.
9. Cdr. Vikramjeet (HSL) requested clarity on the engagement of Indian valuers
and valuation standards, mentioning that the industry supports the engagement
of Indian valuers.
Action Taken: DGS clarified that the Indian valuators are already added to the
list.
10. Mitesh Agarwal (Swan) suggested eligibility for vessel conversion projects,
requesting that the conversion of vessels into specialized vessels be made
eligible for SbFAS, as such projects can cost over ₹100 crores. Currently, this
category is not covered. He also raised a point on overlap with other schemes
or top-up schemes by State Governments, seeking clarification on the matter.
Action Taken: DGS clarified that, as per the Cabinet note, financial assistance
is to be paid for new builds only.
11. Kalpesh Vithlani (GMB) pointed out that under SBFAP 1, no top-up or support
was allowed under any Central or State schemes alongside SBFAS, and sought
clarity on whether the same restriction will apply to SbFAS 2.0. The industry
also requested reconsideration of this restriction, such as permitting state-level
top-up subsidies.
Action Taken: DGS clarified that States can support shipyards over and above
SBFAS support provided by the Government of India, provided it meets the
exclusion criteria as mentioned in the Cl. 5(d) of the draft SBAS Guidelines.

<!-- page 13 -->

Sl.
No.

Key Discussion Point

Raised By

Action to be Taken / Decision

1

Requested that the new
scheme guidelines be
prepared in the same
format as the SBFAP
1.0 guidelines as the
industry is already
comfortable with the
same and there will be
limited ambiguity.

KK Dhawan
(IRS)

It was informed that the new
guidelines have been prepared on
the same skeleton as that of the
previous guidelines.

Saket
Kandoi
(Titagarh
Rail
Systems)

Vessels built for defence purposes
or for use by Navy or Coast Guard
have been excluded. However,
vessels like tugs, tankers, cargo
ships and passenger ships that are
not fitted with any weaponry,
contracted for construction by
foreign defence entities are eligible.

Anil Devli
(INSA)

Yes, credit note can be tagged with
a new build anytime before the last
payment is received by the ship
owner

Anil Devli
(INSA)

Explained in the guidelines

Anil Devli
(INSA)

Checklist for assessment of
international valuators has been
prepared for adding new valuators
to this list.

Anil Devli
(INSA)

This issue will be separately
discussed with State Maritime
Boards to ensure a smooth and
transparent process.

2

3

4

5

6

Clarity on whether
auxiliary vessels (noncombat) of the Navy will
be included under the
scheme.
If a shipowner scraps a
vessel after placing a
new ship order, will the
scrap credit note still be
counted towards
eligibility under SbFAS.
The term “Fair Scrap
Value” and the
methodology for its
evaluation.
Brokers / independent
evaluators: An
empanelled list of
evaluators with defined
criteria should be there
and periodic review
should be carried out.
Certificate of Recycling
(CoR): issuance
process should be
based on clear,
transparent, and
standardized
parameters to avoid
operational hurdles or
delays. The process
should be digitized and
automated through
online portals.

<!-- page 14 -->

Sl.
No.

Key Discussion Point

Raised By

Action to be Taken / Decision

7

In many cases,
shipowners directly
contract with suppliers
and procure
components rather than
the shipyard doing so.
Possibility for allowing
shipowners to seek
SbFAS benefits too,
depending on the
nature of the contract
between the shipowner
and the shipyard.

Anil Devli
(INSA)

As per the Cabinet note, financial
assistance is to be paid directly to
the shipyard only not the shipowner

8

Commencement of
SbFAS and the start
date of SbFAS 2.0.

Nikhil Raj
(SCI)

Yet to be finalized.

Rajeev
Nayyer
(Swan)

The calculation is based on pro rata
basis with 30% DC = 75% FA,
>=40% DC = 100% FA, <30% DC =
0% FA, >30% DC<40% DC - Linear
variation

Pandurang
Dhond
(Chowgule
& Co.)

In the current scheme, a
shipbuilding contract is mandatory.

Cdr.
Vikramjeet
(HSL)

Indian valuators are already added
to the list.

Mitesh
Agarwal
(Swan)

As per the Cabinet note, financial
assistance is to be paid for new
builds only

9

10

11

12

Domestic Content
Requirement (DCR):
For specialized vessels,
where equipment costs
are high, it may not be
feasible to achieve the
40% threshold.
Clarification required on
whether the % is
linearly proportional or
exponential and on
calculation of subsidy
on a pro-rata basis.
Eligibility in case of
Self-Build by Shipyards:
If shipyards build
vessels without a
confirmed buyer or for
captive use, they should
be able to claim
subsidy.
Valuation: Clarity on
engagement of Indian
valuers and valuation
standards. Industry
supports engagement
of Indian valuers.
Eligibility for Vessel
Conversion Projects:
Request to consider

<!-- page 15 -->

Sl.
No.

13

Key Discussion Point
making conversion of
vessels into specialized
vessels eligible for
SbFAS as these
projects’ cost can run
into 100+ crores.
Currently, this is not
covered. Overlap with
other schemes / top-up
schemes by State
Governments also
raised.
Under SBFAP 1, no
top-up or support is
allowed under any
Central/State schemes
alongside SBFAS.
Clarity sought on
whether this will also
apply to SbFAS 2.0.
Industry seeks
reconsideration (e.g.,
state-level top-up
subsidies).

Raised By

Action to be Taken / Decision

Kalpesh
Vithlani
(GMB)

States can support shipyards over
and above SBFAS support provided
by the Government of India,
provided it meets the exclusion
criteria as mentioned in the Cl. 5(d)
of the draft SBAS Guidelines.

<!-- page 16 -->

Annexure II
Stakeholder Consultation on ShipBuilding Financial Assistance Scheme
Background : As part of the implementation of the Shipbuilding Financial Assistance
Scheme (SBFAS), the Directorate General of Shipping (DG Shipping), under the
Ministry of Ports, Shipping and Waterways (MoPSW), convened a series of
stakeholder consultations in October 2025 to deliberate on the draft guidelines.
Minutes of Meeting
Stakeholder Consultation on Shipbuilding Financial Assistance Scheme
(SBFAS) Guidelines
Date: 14th October 2025
Time: 16:00 Hrs – 18:00 Hrs
Venue: Online Consultation
Convened by: Directorate General of Shipping (DG Shipping), Ministry of Ports,
Shipping & Waterways
Participants:
DG Shipping
 Shri Pradeep Sudhakaran, Chief Ship Surveyor-cum-Joint DG (Tech.)
 Shri Nebu Oommen, Dy. Chief Ship Surveyor-cum- Senior Deputy Director
General (Tech.), DG Shipping
 Shri Ravi Kumar, Ship Surveyor-cum- Deputy Director General (Tech.), DG
Shipping
 Shri Ankur Anal – Junior Ship Surveyor-cum-Assistant Director General
(Tech.), DG Shipping
Core Committee Members
 Vipul Sinhgal, Director (SBR), Ministry of Ports, Shipping and Waterways
(MoPSW)
 Ravi Kumar, Ship Surveyor-cum-Deputy Director General (Tech.), Directorate
General of Shipping (DGS)
 Ankur Anal, Junior Ship Surveyor-cum-Assistant Director General (Tech.),
Directorate General of Shipping (DGS)
 Shrikant Itagi, CCPL, Shipyards Association of India
 Prantik Sen, Hon. Secretary, Indian Shipbuilders Association (ISBA)
 K.K. Dhawan, Senior Vice President, Indian Register of Shipping (IRS)
 Kalpesh Vithlani, GM, Gujarat Maritime Board (GMB)
 Nikhil Raj, Deputy General Manager i/c (SB&S), Shipping Corporation of India
(SCI)
 Haresh Parmar, Hon. Secretary, Ship Recycling Industries Association (SRIA)
 Nagesh K. Moorthy, General Manager (Business Development), Cochin
Shipyard Limited (CSL)

<!-- page 17 -->



Anil Devli, Chief Executive Officer, Indian National Shipowners Association
(INSA)
 Rakesh Singh, President, ICC Shipping Association (ICCSA)
Industry Participants
Representatives from GRSE, CSL, MDL, GSL, L&T, IRS, San Marine, Chowgule
Shipyard, Konkan Barge Builders, and other shipyards
Key Discussion Points and Actions to be Taken
1. Opening Remarks and Overview of the Scheme
Key Discussion Points:


Shri Ankur Anal welcomed all participants and introduced the consultation as
part of the process for finalizing the Shipbuilding Financial Assistance Scheme
(SBFAS) guidelines following Cabinet approval on 24th September 2025.



Shri Pradeep highlighted that the SBFAS is an extension of the earlier SBFAP
(2016–2026), with an overall outlay of ₹24,000 crore (including ₹4,000 crore
for Ship Recycling Credit Notes).



The scheme extends assistance till 2036 and incorporates ship recycling,
shipbuilding capacity enhancement, and insurance mechanisms under one
umbrella.

2. Presentation on Draft Guidelines
Key Discussion Points:


Shri Ankur Anal presented the salient features of the draft guidelines:
o

Introduction of three-stage payment structure (Launching, Delivery, and
Post-Delivery).

o

Mandatory domestic content requirement (minimum 30%, preferably
40%).

o

Classification based on vessel cost (₹100 crore threshold).

o

Expanded specialised vessel categories including hybrid, dual-fuel, and
green vessels.

o

Ship Breaking Credit Notes (SBCN) introduced with 3-year validity and
transferability.

o

Simplified approval process through enhanced powers of the
Institutional mechanism, MoPSW.

Actions Taken:


Stakeholders to review the full draft document and submit section-wise
suggestions with data-backed justifications by 16th October 2025.

<!-- page 18 -->

3. Committee Roles and Review Structure
Key Discussion Points:


Shri Ankur Anal explained that six subcommittees were formed to review
sections such as eligibility, valuation, domestic content, credit notes,
compliance, and subsidy claims.



Shri Anil Devli sought clarity on whether comments could go beyond assigned
sections.



Shri Pradeep clarified that all members can provide feedback on any clause in
the document.

4. Bank Guarantee and Surety Bonds
Key Discussion Points:


Shri S.V. Rambabu (HSL) proposed the use of insurance surety bonds as an
alternative to bank guarantees for first-stage payments, citing cost efficiency
and precedents from other government departments.

Actions Taken:


Basis the current discussions, Bank Guarantee is considered necessary.

5. Transition from SBFAP and Timelines for Large Vessels
Key Discussion Points:


Shri Sanjiv Walia (SAI) raised issues faced under SBFAP, including the
inability to avail assistance on amended contract prices.



Shri Srinivasa Rao Padala (HSL) emphasized that PSU shipyards require
flexible milestone-based timelines for large vessels due to extended design
approvals and procurement cycles.



Suggested that project-linked milestones be adopted instead of rigid timelines.

Actions Taken:


In-principal approval is granted basis the initial contract price based on which
a budget estimate is prepared. Also, valuations carried out by valuers are also
based on the initial specifications. Subsequently, if specifications are revised,
a fresh set of assessment is required. Hence, considering revised contract
price is not feasible.
 Timelines as mentioned in the guidelines are applicable to all shipyards.
6. Inclusion of Broader Compliance Standards
Key Discussion Points:

<!-- page 19 -->



A representative suggested inclusion of EU Ship Recycling Regulation
(EUSRR) compliant yards in addition to Hong Kong Convention (HKC)
compliance.

Action Taken:


It is noted that all EU(SSR) compliant yards are HKC compliant, hence
amendment is not required.

7. Scrap Value and Credit Note Transferability
Key Discussion Points:


Concerns were raised by Shri Rakesh Singh regarding determination of scrap
value and the challenges in transferring credit notes through intermediaries.



Shri Pradeep clarified that credit notes are transferable or tradable with
mandatory registration through the DG Shipping portal.

Action Taken:


Detailed procedure for determination of scrap value and transfer of credit
notes has been included in the draft guidelines.

8. Eligibility for Government and Defence Projects
Key Discussion Points:


Shri Ghoshal (Suryadipta Projects) highlighted the exclusion of vessels built
for defence purposes from current eligibility provisions.



Shri Srinivasa Rao Padala (HSL) recommended inclusion of PSU-built
auxiliary and dual-purpose defence vessels under the scheme.



He also suggested redefining “delivery date” to align with Ministry of Defence
acceptance procedures.

Action Taken:


Vessels built for defence purposes or for use by Navy or Coast Guard are
excluded. However, vessels like tugs, tankers, cargo ships and passenger
ships that are not fitted with any weaponry, contracted for construction by
foreign defence entities are eligible.



Delivery date is decided based on the ‘Protocol of delivery and Acceptance’
document submitted by the shipyard.

9. Financial Assistance and Vessel Classification
Key Discussion Points:


Shri Rakesh Singh sought clarity on owner-supplied equipment and inclusion
of refrigerated cargo vessels under the specialised list.

<!-- page 20 -->



Suggested higher assistance rates for small specialised vessels below ₹100
crore.



Shri Nagesh Krishna Moorthy raised similar concerns for green tugs.



Diving Support Vessels (DSVs) to be considered in the Specialised vessel
category

Actions Taken:


Owner supplied equipment is to be a part of the shipbuilding contract.



Complexity of Refrigerated cargo vessels is not considered equivalent to
"specialized vessels". Accordingly, not considered as a “specialized vessel”.
As per the approved Cabinet note, rate of financial assistance has been
frozen and no further change can be made at this stage.




Diving support vessel with a moonpool has been included in the list of
specialized vessels.

10. PSU-Specific Issues and Procedural Delays
Key Discussion Points:


Proposed introduction of a grace period (6–9 months) beyond declared
timelines for large PSU projects before financial penalties are applied.



Recommended cost-plus valuation methodology for audited PSU projects
instead of market comparison.



Suggested allowing corporate or government guarantees in place of bank
guarantees for PSUs.



Requested DG Shipping to issue a standard closure certificate format
compatible with PSU audit and MoD systems.



Proposed inclusion of DGQA/Navy representatives in the Fair Price
Committee (FPC) for defence-linked projects.

Actions tTaken:






Timelines as mentioned in the guidelines are applicable to all shipyards.
Complexity of the projects has been suitably addressed by classifying vessels
as “Specialized”
Basis the current discussions, Bank Guarantee is considered necessary.
Methodology as mentioned in the guidelines is vessel specific and neutral to
the type of shipyard.
Valuations are carried out by international evaluators who are essentially ship
brokers in the international market. Under the present structure, presence of a
committee for calculation of fair price is not considered necessary.

<!-- page 21 -->

11. Taxation Issues in Ship Recycling
Key Discussion Points:


Shri Haresh Parmar (SRIA) raised concerns over double GST when Indian
owners sell ships domestically for recycling, diverting ships abroad.



Shri Pradeep explained that the 40% ship recycling assistance is intended to
offset such cost disadvantages.

Actions Taken:


Issue is not related to the current scheme.

12. Clarifications on Definitions and Timeline
Key Discussion Points:


Shri Anil Devli (INSA) and Shri Srinivasa Rao Padala (HSL) requested clearer
definitions of “specialised” and “non-specialised” vessels and default six-year
timeline for specialised vessels.

Actions Taken:


Guidelines have been suitably amended to address the ambiguity.

13. Closing Remarks
Key Discussion Points:


Shri Pradeep Shri Ravi Kumar and Shri Ankur Anal appreciated all members
for their participation and assured that every suggestion would be examined
carefully.



Final draft to be consolidated after upcoming consultations in Ahmedabad and
Mumbai.

Actions to be Taken:


Stakeholders to send all final written inputs by 16th October 2025.



Final consolidated guidelines to be submitted to the Ministry by 24th October
2025.

Comprehensive Summary of the Meeting
Sl. Key Discussion Point
No.

Raised By

Action to be Taken /
Decision

1

Shri Anil Devli
(INSA)

Subcommittee roles and
review mechanism was
explained.

Subcommittee roles and
review mechanism

<!-- page 22 -->

2

Insurance surety bonds as
BG alternative

Shri S.V.
Rambabu
(HSL)

Basis the current discussions,
Bank Guarantee is
considered necessary.

3

Milestone-linked project
timelines for large vessels

Shri Srinivasa
Rao Padala
(HSL) Shri
Sanjiv Walia
(SAI)

4

To consider EU(SSR)
compliance as a eligibility
criterion for defining
‘eligible ship recycling
yards’.

SRIA

Subsequent to several
discussions with industry
stakeholders, 3 stage
payments has been
considered a feasible solution
for all vessels i.e. launching,
delivery and 3rd stage upon
receipt of final payment from
ship owner.
It is noted that all EU(SSR)
compliant yards are HKC
compliant, hence amendment
is not required.

5

Scrap value determination
and credit note transfer

Shri Rakesh
Singh, ICCSA

6

Eligibility for PSU and
auxiliary defence vessels

Shri Srinivasa
Rao Padala
(HSL), Shri
Ghoshal
(Suryadipta
Projects)

7

Cost-plus valuation for
PSU projects

Shri Srinivasa
Rao Padala
(HSL)

8

Government/corporate
guarantees for PSUs

Shri Srinivasa
Rao Padala
(HSL)

9

Inclusion of DGQA/Navy in
Fair Price Committee

Shri Srinivasa
Rao Padala
(HSL)

Scrap value will be assessed
by the international valuators.
Credit notes are transferrable
hence cash buyers can resell
the credit note to the ship
owner.
Vessels built for defence
purposes or for use by Navy
or Coast Guard are excluded.
However, vessels like tugs,
tankers, cargo ships and
passenger ships that are not
fitted with any weaponry,
contracted for construction by
foreign defence entities are
eligible.
Under SBFAS, in case of
bidding, contract price is
considered the fair price
whereas for negotiation,
market valuation is
considered appropriate.
Basis the current discussions,
Bank Guarantee is
considered necessary.
Valuations are carried out by
international evaluators who
are essentially ship brokers in
the international market.

<!-- page 23 -->

Under the present structure,
presence of a committee for
calculation of fair price is not
considered necessary.
10

Grace period for PSU
project delays

Shri Srinivasa
Rao Padala
(HSL)

Timelines as mentioned in the
guidelines are applicable to
all shipyards.

11

Clarification of delivery
definition for MoD projects

Shri Srinivasa
Rao Padala
(HSL)

Delivery date is decided
based on the ‘Protocol of
delivery and Acceptance’
document submitted by the
shipyard.

12

Higher assistance rates for Shri Rakesh
smaller specialised vessels Singh
(ICCSA), Shri
Nagesh
Krishna
Moorthy (CSL)

As per the approved Cabinet
note, rate of financial
assistance has been frozen
and no further change can be
made at this stage.

13

Double GST on domestic
ship recycling

Shri Haresh
Parmar (SRIA)

Issue is not related to the
current scheme.

14

Provide clear and
unambiguous default sixyear timeline for
specialised vessels.

Shri Anil Devli
(INSA)

Relevant clause suitably
amended.

<!-- page 24 -->

Minutes of Meeting
Stakeholder Consultation on Shipbuilding Financial Assistance Scheme
(SBFAS) Guidelines
Date: 17th October 2025
Time: 10:00 Hrs – 18:00 Hrs
Venue: GIFT City, Gujarat Maritime Board
Convened by: Directorate General of Shipping (DG Shipping), Ministry of Ports,
Shipping & Waterways

<!-- page 25 -->

<!-- page 26 -->

<!-- page 27 -->

<!-- page 28 -->

Key
Discussion Points and Actions Taken
During the consultation held on 17th October 2025 at Ahmedabad, several key issues
and clarifications were discussed under the Shipbuilding Financial Assistance Scheme
(SBFAS).
1. Lt Cdr. Pravat Haldar (Titagarh) raised the point regarding the scenario when
the whole construction is offloaded to another party. It was clarified that the
Builder’s Certificate should be issued by the yard that has signed the
shipbuilding contract.

<!-- page 29 -->

Action Taken: Builder's certificate is to be issued by the yard which has
signed the shipbuilding contract.
2. Shri Amit Waje (IRS) sought clarification on the minimum requirements or
framework for registration of a shipyard. It was explained that the intent of the
registration process is to enable shipyards to apply for an in-principal approval,
and therefore, the process has been kept simple to encourage wider
participation.
Action Taken: The intent of registration is to allow the shipyard to apply for an
in-principal application, hence, the registration process has been kept simpler.
3. Sh Anshul Wadia (Wadia boat builders) requested clarification regarding the
definition of small ships and the applicability of financial assistance to
specialized vessels such as tugs and inland towing vessels under 24 meters.
Action Taken: It was explained that as long as the benchmark of 100 cr is met
irrespective of any length the financial assistance will be provided. For the
hybrid vessels the length requirement is 12 m.
4. Sh Talavia, CE, GMB : The issue of determining the fair scrap value prior to
dismantling was discussed.
Action Taken: Fair Scrap value is based on the values provided by the
international valuer before the application for shipbreaking credit note is
submitted.
5. Sh Bharat Krishnan (L&T): Clarifications were also sought on the definition of
Domestic Content under the Contract Price, especially in cases where OEMs
have Indian offices. An example was given of MAN, where engines may be
imported but payment is made in INR.
Action Taken: Certificate from OEM would ascertain the country of origin.
6. Shri Anshul Wadia (Wadia Boatbuilders) raised a query regarding the length
requirement for export orders and whether only boats are eligible for financial
assistance. He also enquired about the necessity of IACS or type approval.
Action Taken: It was clarified that there is no minimum length requirement for
export orders, and propulsion is not a mandatory condition. Vessels built under
SBFAS must be constructed under a Recognized Organization of the
Government of India.
7. Representatives from the Shipping Corporation of India (SCI) suggested that in
cases where PSU vessels are scrapped through tendering, the tender price
should be taken into consideration.

<!-- page 30 -->

Action Taken: Guidelines have been suitably amended to include this
provision,
8. Shri Gaurav (SWAN) sought clarification on the utilization of credit notes and
their linkage with the SBFAS process.
Action Taken: The procedures and timelines were explained in detail to all
attendees.
9. Another query was raised regarding contracts that do not include ammunition
or weapons and whether such vessels could still qualify for assistance.
Action Taken: It was clarified that vessels built for defence purposes or for use
by the Navy or Coast Guard are excluded. However, tugs, tankers, cargo ships,
and passenger ships contracted by foreign defence entities without weaponry
are eligible for assistance.
10. Participants sought clarification on the list of specialized vessels.
Action Taken: It was confirmed that the list has been suitably amended to
include additional categories based on industry feedback. Accordingly, Diving
support vessel with a moonpool has been added to the list of specialized
vessels.
11. Mr. Amit Waze (IRS) discussed the issue of vessel launching and the role of the
classification society.
Action Taken: It was explained that while shipyards schedule launchings
based on tides and operational convenience, the launching date recorded by
the Recognized Organization (RO) will be considered final for the purpose of
the scheme.
12. Cmde Sanjeev Kapoor (SWAN) raised a query on the requirement of Bank
Guarantees (BG) at various stages of payment.

Action Taken: It was clarified that BG is required at the launching stage,
whereas it is not necessary at the time of delivery if the payment is taken in one
instalment.
Comprehensive Summary of the Meeting
Sl.
No.

Key Discussion Point

Raised By

Action to be Taken / Decision

1

If the whole construction
is offloaded to another
party. The "Shipbuilding
Contract" to be
rephrased.

Lt Cdr.
Pravat
Haldar
(Titagarh)

Builder's certificate is to be
issued by the yard which has
signed the shipbuilding contract.

<!-- page 31 -->

Sl.
No.

Key Discussion Point

Raised By

Action to be Taken / Decision

2

"Contract Price" there are
some parts/ items which
are supplied by the
owner.

Sh Talavia,
CE, GMB

The contract should include all
the prices i.e., should be inclued
with owner's supplied items.

3

Minimum set of
requirement or framework Sh Amit
for registration of the
Waje (IRS)
shipyard

The intent of registration is to
allow the shipyard to apply for an
in-principal application, hence,
the registration process has been
kept simpler.

4

Definition of Small ships,
exemptions to specialized
vessels like tugs, inland
towing vessels which are
lesser than 24 m.

Shri. Anshul
Wadia
(Wadia
Boatbuilders)

It was explained that as long as
the benchmark of 100 cr is met
irrespective of any length the
financial assistance will be
provided. For the hybrid vessels
the length requirement is 12 m.

5

Fair scape value is
decided well in advance
before ship is sent to
scrap.

Sh Talavia,
CE, GMB

Fair Scrap value is based on the
values provided by the
international valuer before the
application made.

6

How and what timelines
of approval, international
Physical
valuer will take.The
Attendee
process of the scrap to be
considered.

Timelines cannot be mandated to
the international valuators.
However, in case shipyard does
not receive 3 valuations within 45
days of the receipt of valuator
list, yard can request for a fresh
list of valuators and then yard is
provided another 45 days for
submitting 3 valuator certificates.

7

Domestic Contect is this
Contract Price - anything
imported.
Attendee also brought out Sh Bharat
Krishnan
that many of the OEMs
(L&T)
has offices in India. The
best example is MAN if
the the engine is imported
by them and payment is

Certificate from OEM would
ascertain the country of origin

<!-- page 32 -->

Sl.
No.

Key Discussion Point

Raised By

Action to be Taken / Decision

done in INR will it be
considered as domestic
content

8

9

10

Length requirement for
the export order.
Only boats are eligible for
the financial assistance.
Is IACS mandatory? Is
Type approved boats are
eligible
PSU scraps the vessels
through tendering.
Requested to consider
the tender price
Utilization of the credit
note and linking with the
SBFAS.

There is no length requirement
for an export order.
Shri. Anshul There is no requirement of the
propulsion.
Wadia
Vessels built under SBFAS need
(Wadia
Boatbuilders) to be built under the classification
of a Recognized Organization of
the Government of India.

SCI

Amended in the guidelines.

Shri. Gaurav
(SWAN)

Process and timelines were
explained to the shipyard

If the contract does not
include ammunition,
weapons will be assisted
finances
OPVs, vessels fitted with
small arms can be
included

Sh Bharat
Krishnan
(L&T)

12

Specialized Vessels list

Sh Bharat
Krishnan
(L&T)

13

Launching of the vessel.
Shipyards takes up the
launching according to
tides etc. Class only

Mr. Amit
Waze (IRS)

11

Vessels built for defence
purposes or for use by Navy or
Coast Guard are excluded.
However, vessels like tugs,
tankers, cargo ships and
passenger ships that are not
fitted with any weaponry,
contracted for construction by
foreign defence entities are
eligible.
The list of specialized vessel has
been suitably amended to
include ‘Diving Support vessel
with a moonpool’
Launching date mentioned by
RO will be considered as final.

<!-- page 33 -->

Sl.
No.

Key Discussion Point

Raised By

Action to be Taken / Decision

Cmde
Sanjeev
Kapoor
(SWAN)

At launching stage BG is
required. At delivery BG is not
required.

provides the only
clearances.

14

If subsidy at the
launching stage to be
availed is there any
necessity of paying BG.
If one time payment to be
taken will there be any
requirement of BG

Annexure IV
Minutes of Meeting
Stakeholder Consultation on Shipbuilding Financial Assistance Scheme
(SBFAS) Guidelines
Date: 30th October 2025
Time: 11:00 Hrs – 12:15 Hrs
Venue: Online
Convened by: Directorate General of Shipping (DG Shipping), Ministry of Ports,
Shipping & Waterways
Participants:
DG Shipping
 Shri Pradeep Sudhakaran, Chief Ship Surveyor-cum-Joint DG (Tech.)

<!-- page 34 -->



Shri Nebu Oommen, Dy. Chief Ship Surveyor-cum- Senior Deputy Director
General (Tech.), DG Shipping
 Shri Ravi Kumar, Ship Surveyor-cum- Deputy Director General (Tech.), DG
Shipping
 Shri Ankur Anal – Junior Ship Surveyor-cum-Assistant Director General
(Tech.), DG Shipping
Core Committee Members
 Vipul Sinhgal, Director (SBR), Ministry of Ports, Shipping and Waterways
(MoPSW)
 Ravi Kumar, Ship Surveyor-cum-Deputy Director General (Tech.), Directorate
General of Shipping (DGS)
 Ankur Anal, Junior Ship Surveyor-cum-Assistant Director General (Tech.),
Directorate General of Shipping (DGS)
 Shrikant Itagi, CCPL, Shipyards Association of India
 Prantik Sen, Hon. Secretary, Indian Shipbuilders Association (ISBA)
 K.K. Dhawan, Senior Vice President, Indian Register of Shipping (IRS)
 Kalpesh Vithlani, GM, Gujarat Maritime Board (GMB)
 Nikhil Raj, Deputy General Manager i/c (SB&S), Shipping Corporation of India
(SCI)
 Haresh Parmar, Hon. Secretary, Ship Recycling Industries Association (SRIA)
 Nagesh K. Moorthy, General Manager (Business Development), Cochin
Shipyard Limited (CSL)
 Rakesh Singh, President, ICC Shipping Association (ICCSA)
Industry Participants
Representatives from GRSE, CSL, MDL, GSL, L&T, IRS, San Marine, Chowgule
Shipyard, Konkan Barge Builders, and other shipyards

Key Discussion Points and Actions Taken
This meeting was a core-committee (ONLY) meeting to discuss all the stakeholder
suggestions and the action taken report in order to finalize the guidelines before
discussing the final draft of the guidelines with other industry stakeholders in the
meeting scheduled on the same day in the afternoon.
It was noted that roughly 100 stakeholders suggestions/clarifications have been
received and all suggestions along with the action taken were discussed with the
members of the core-committee.
Core-committee members agreed to the actions taken.
Hindustan Shipyard queries received vide email

<!-- page 35 -->



A request was made to include the concept of the effective date of the
contract, which could be defined as the date of receipt of the first-stage
payment, or the date of design/model test approval, depending on the
contract terms.



Action Taken: DGS clarified that this cannot be considered, as the effective
date is highly subjective and varies from contract to contract, potentially
affecting the timelines defined under the scheme.



It was enquired whether financial assistance could be claimed for a repeat
order if such a clause was not mentioned in the tender or contract.



Action Taken: DGS responded that in such cases, eligibility for financial
assistance would need to be reassessed after reviewing the relevant tender
documents.



Another clarification was sought regarding the inclusion of Gazette Notification
No. S.O. 3316(E) dated 26th December 2014 in the base scheme document
for reference.



Action Taken: DGS explained that the notification could not be annexed as it
is subject to periodic revisions.



A participant observed that there was no distinct definition for “Standard
Vessel” and suggested introducing it to avoid confusion during implementation
of fair price assessments.



Action Taken: DGS responded that non-specialized vessels constitute a
negative list of the specialized vessel category and are therefore not
separately defined.



DGS To confirm that the values (Rs 100 Cr) are excluding taxes and duties.



Action Taken: It was confirmed by DGS that the benchmark vessel value of
₹100 crore is exclusive of all taxes and duties.



Clarification was sought regarding the difference in the text highlighted in bold
concerning credit notes.



DGS explained that a credit note can be redeemed against a new building
contract at any time up to the last payment receipt from the ship owner.



Participants requested that certain sections of the guidelines be
supplemented with examples for better understanding.



DGS agreed and confirmed that a Frequently Asked Questions (FAQ)
document containing relevant examples will be prepared.

<!-- page 36 -->



Regarding the validity of credit notes, DGS clarified that the validity period of
three years is counted from the date of redemption — i.e., the date on which
the credit note is attached to a shipbuilding contract.



It was also confirmed that the minimum length restriction does not apply to
vessels valued above ₹100 crore or those built for export orders. For vessels
valued below ₹100 crore, the minimum length requirement is 24 meters for
regular vessels and 12 meters for hybrid vessels.



A query was raised on the validity of paragraph 1.(g)(iii) of the guidelines.



Action Taken: DGS confirmed that the reference was checked and found to
be correct.



Participants from Hindustan Shipyard Limited (HSL) requested clarity on the
inclusion of Diving Support Vessels (DSVs) in the specialized vessel list.



Action Taken: DGS informed that the matter is under further discussion.



It was requested that valid email IDs and contact details of all approved
valuers be updated in the list.



Action Taken: DGS confirmed that revised details have already been
incorporated.



A query was raised regarding the percentage of financial assistance to be
released at the launching stage, as defined in Annexure II-1 of the procedure
for release of financial assistance.



Action Taken: DGS clarified that the amount considered for computation will
be the minimum of 50% of the contract price or the price received by the ship
owner, as certified by a Chartered Accountant.



Another clarification was sought on whether a Bank Guarantee (BG) is
required at the delivery stage.



Action Taken: DGS confirmed that a BG is not required at delivery.



It was further clarified that financial assistance will be released in three stages
as per the scheme, and relevant modifications have been made in the
guidelines to address earlier inconsistencies.



No reference was made to certain paragraphs cited in the document.



Action Taken: DGS noted this observation for review.



Based on indigenous content, a table showing the proportionate reduction in
financial assistance has now been incorporated into the revised guidelines in
Schedule V.

<!-- page 37 -->

Cochin Shipyard queries received vide email


Clarification was sought on the definition and application methodology for
“domestic content,” particularly the treatment of projects with below 30%,
between 30–40%, and above 40% domestic value addition.



Action Taken: DGS responded that this aspect has been elaborated and
explained in the guidelines in Schedule V



CSL proposed extending the capping of non-specialized vessels from three
years to a longer duration, considering that even diesel engines, especially
two-stroke slow-speed types, currently have a lead time exceeding 30
months.



Action Taken: DGS confirmed that the guidelines have been suitably
amended to include an extended timeline of four years for normal vessels and
six years for projects involving more than two vessels.



CSL further suggested simplifying Clause 3 by removing the requirement to
obtain separate approvals from the Competent Authority for delivery
extensions beyond three years and by indicating the timeline as up to six
years by default for specialized vessels.



Action Taken: DGS informed that the guidelines have been suitably
amended to incorporate this recommendation.



It was also proposed that a clear definition of “eligible vessels” be added.



Action Taken: DGS confirmed that the definition has been included in the
guidelines.



Regarding the Government’s Remission of Duties and Taxes on Export
Products (RoDTEP) scheme under the Foreign Trade Policy 2023–28, CSL
suggested that its benefits—being a remission of embedded taxes and
duties—align with the intent of the SBFAS provisions and should be treated as
permissible under the scheme.



Action Taken: DGS stated that the proposal would be further discussed and
provisionally inserted as Paragraph 2.b.i of the guidelines.



CSL further elaborated that RoDTEP is not a form of monetary support but
rather a neutralization mechanism for embedded taxes, and that its benefits
are equivalent in effect and intent to tax exemptions. Accordingly, CSL
requested that Clause 5(d)(i) be amended to explicitly include RoDTEP as a
specific exception to the restriction, and that other export-linked schemes
such as duty drawback also be considered for inclusion.



Action Taken: This matter will be reviewed further by DGS.

<!-- page 38 -->



CSL recommended that the list of green fuel types be expanded to include all
forms of green fuels, instead of limiting it to methanol, ammonia, and
hydrogen fuel cells.



Action Taken: DGS advised that the shipyard specify the types of vessels
utilizing fuels other than the mentioned three that may be considered for
inclusion in the updated list.



It was also noted that under SBFAS 1.0, vessels constructed on nomination
from Central or State Public Sector Enterprises were eligible for assistance,
whereas under SBFAS 2.0 they are excluded. CSL requested that this clause
be retained in alignment with the earlier version, as such projects fall under
the category of negotiated contracts. DGS clarified that nomination contracts
from Central and State Governments would be included in the exclusion list
under the revised scheme.



CSL expressed concern that the ₹100 crore distinction would adversely
impact special programs such as GTTP and Harith Nauka. It was suggested
that for special vessels, a uniform financial assistance rate of 25% be applied
without any cost-based distinction.



Action Taken: DGS clarified that, as per the approved Cabinet note, the rate
of financial assistance has been frozen and cannot be modified.

SWAN queries received vide email


It was highlighted that these new categories of vessels are two to three times
larger in size compared to LR/MR tankers, falling within a displacement range
of approximately 0.8L to 3.2L DWT. The VLCC, Suezmax, and Aframax
vessels have not been previously constructed in India and require a
significantly higher level of technological capability, design expertise, skilled
manpower, and capital investment.



Accordingly, it was proposed that these vessel types be incorporated under
Schedule-II, “List of Specialized Vessels,” of the document Guidelines for
Implementation of the Shipbuilding Financial Assistance Scheme (SBFAS),
under the category “Crude Carrying Vessels – VLCC, Suezmax, and
Aframax.”



Action Taken: DGS informed that the guidelines have already been suitably
amended to consider an extended delivery timeline for all vessels.
Specifically, the standard timeline has been extended to four years for normal
vessels and six years for contracts involving more than two vessels.



It was further discussed under the Energy and Forex Security consideration
that the principal objective of the Four-Pillar approach for the Shipbuilding and
Maritime sector is to enhance national energy and foreign exchange security

<!-- page 39 -->

by promoting the construction of high-GRT liquid and bulk carriers in India.
CSL proposed that a reference text may be incorporated in the guidelines to
acknowledge the strategic importance of such shipbuilding projects, stating:
“Energy and Forex Security imperatives of the country may warrant prioritizing
certain specific shipbuilding cases as necessitated.”


Action Taken: DGS clarified that this provision is not directly relevant to the
SBFAS framework and therefore may not be included in the scheme
guidelines.

HHI queries received vide email


It was proposed that the salaries of foreign engineers and production
managers, who are either directly employed by Indian shipyards or deputed to
India under a service agreement, should be recognized as part of the Local
Content.



Action Taken: DGS clarified that irrespective of nationality, if such salaries
are paid in Indian Rupees (INR) and appropriate taxation is in India they shall
be considered under the local content requirement subject to meeting other
local laws.



Further, it was suggested that if the total construction cost includes overhead
expenses, the corresponding local overhead costs should also be recognized
in the numerator while calculating local content.



Action Taken: DGS confirmed that expenditures made in INR, including
overhead expenses, may be accounted under the local content requirement
subject to meeting the local laws and value addition requirements as
mentioned in the guidelines.

ICCSA queries received vide email


ICCSA representatives sought clarification on several aspects related to the
Shipbuilding Financial Assistance Scheme (SBFAS) during the consultation.



It was clarified that the scheme is available to all Indian shipyards; however,
yards must be registered on the SBFAS portal to be eligible to apply for an inprinciple approval.



A query was raised regarding the inclusion of owner-supplied equipment and
machinery in the computation of overall shipbuilding costs.



Action Taken: DGS confirmed that all costs associated with the construction
of the vessel, including items supplied directly by the owner, will be
considered toward the total project cost for determining financial assistance
eligibility.



Regarding cost escalation,

<!-- page 40 -->



Action Taken: DGS explained that in-principle approval is granted on the
basis of the initial contract price, which serves as the budget estimate.
Valuations conducted by approved valuers are also based on these initial
specifications. If any technical or commercial parameters are revised later, a
fresh set of assessments will be required.



Participants noted that most shipbreaking contracts entered into by Indian
shipowners are executed through “cash buyers,” who subsequently deal with
the ship recycling yards.



Action Taken: DGS acknowledged this reality and informed that credit notes
have been made transferable, thereby allowing cash buyers to sell them to
the actual shipowners.



Clarification was sought regarding the intent of a particular section of the
guidelines.



Action Taken: DGS explained that the clause ensures financial assistance is
extended only when the majority of the vessel’s construction activity occurs
within India.



The time limits prescribed for completion of vessel construction were also
discussed. It was requested that the provision for schedule relaxation should
not be limited only to specialized vessels.



Action Taken: DGS clarified that the extended construction timeline of four
years will now apply to regular vessels as well.



A request was made to confirm that, in cases where the value of a credit note
exceeds 5% of the value of a new vessel, the redeemable amount would be
capped at 5%.



Action Taken: DGS confirmed that credit notes may indeed be redeemed up
to 5% of the new vessel’s value.



It was further proposed that, considering the prolonged period often involved
between the sale of a vessel for demolition and the completion of scrapping,
an alternate document such as a “beaching certificate” issued by local
authorities could be accepted to facilitate timely processing.



Action Taken: DGS clarified that, in accordance with Cabinet approval, credit
notes can only be issued upon completion of the demolition or recycling
process.



ICCSA suggested allowing greater flexibility in the utilization of credit notes.
DGS responded that credit notes are already designed to be stackable and
transferable, offering sufficient flexibility; however, partial utilization remains
disallowed.

<!-- page 41 -->



Proposals for phased realization or partial encashment of credit notes were
also raised. These points were taken under advisement for further
consideration by the shipyards.



Further, it was proposed to include additional vessel types—such as Ro-Ro,
Ro-Pax, reefer vessels, and high bollard pull tugs—under the specialized
category, particularly to enhance salvage capability and emergency response
preparedness.



ICCSA observed that the ₹100-crore threshold for specialized vessels
employing emerging technologies may be too restrictive and suggested
reducing it to ₹50 crore to encourage investment.



Action Taken: DGS clarified that the ₹100-crore threshold has been fixed
under the Cabinet-approved framework and therefore cannot be modified.

APMB queries received vide email


What happens when an SPV is formed with an international company?



Action Taken: The registered shipyard as per the certificate will be eligible for
the financial assistance.



Please clarify the non-inclusion of Indian valuers and provide the final list of
empanelled valuers.



Action Taken: Indian valuers are already in the empanelled list.



Please confirm whether duly approved contractual extensions (e.g., forcemajeure or owner-caused delay(s)) extend the six-year eligibility window.



Action Taken: No. May be evaluated on case by case basis as directed by
the IM.



Priority rules / wait-list mechanism: Please share the method used when
the budget is insufficient (e.g., First In First Out, contract size, strategic
category).
Delay compensation: Please clarify whether interest/compensation is
payable for delayed release.



Action Taken: 1. In case of insufficient funds, shipyards are paid in the next
financial year. 2 No. (Please add a clause in the guidelines to avoid ambiguity)



Stacking of credit notes: Please clarify whether multiple credit notes may be
combined/stacked for a single newbuild.
Transfer documentation: Please specify the documentation and approval flow
required when credit notes are transferred.

<!-- page 42 -->



Action Taken: 1. Yes 2. Explained in the guidelines.

<!-- page 43 -->

Annexure V
Minutes of Meeting
Date: 30.10.2025 (afternoon)
Time: 15:45 hrs – 17:15 hrs
Venue: DG Shipping, Kanjurmarg
Convened by: Directorate General of Shipping (DG Shipping), Ministry of Ports,
Shipping & Waterways

<!-- page 44 -->

<!-- page 45 -->

<!-- page 46 -->

Key Discussions:Summary
Sl
Point
No.

1

2

3

“Date of Contract”
means the date of
signing of the initial
or the first Contract
for construction of
underlying vessel
or vessels, as the
case may be.
In the case of
repeat orders, the
L1 price
discovered /
determined
through the initial
competitive, open
and fair bidding
process will be
considered as Fair
Price for vessels
under the repeat
order, subject to
the initial tender
document and the
contract clearly
mentioning about
the repeat order
and the criteria to
be followed,
including that of
pricing, for
awarding the
repeat order.
“Recognized
Organization”
means an
organization
recognized by the
Government of
India as per the
Gazette
Notification No.

Inputs/ Clarification
sought
Request to include
the concept of
effective date of
contract which may
be date of receipt of
stage 1 payment or
finalization/approval
of design/model test
etc (as per contract)

DGS
Response
Cannot be
considered as
it is very
subjective and
varies from
contract to
contract which
will effect the
timelines fixed
under the
scheme.

If repeat order clause
not mentioned in the
tender or contract,
can I claim financial
assistance for repeat
order?
No, financial
assistance
eligibility will
need to be
reascertsined
after
reviewing the
tender
documents.
Gazette Notification
No. S.O. 3316(E)
dated December 26,
2014 be included in
the base scheme
document for ready
reference.

Cannot be
annexed as it
changes from
time to time.

<!-- page 47 -->

S.O. 3316(E)
dated December
26, 2014, as
amended from
time to time.

4

5

6

“Non-Specialized
Vessel” means
vessel which is not
a specialized
vessel as
described above.
(s) “Small vessel”
refers to those
vessels whose fair
price or the
contract price;
whichever is less is
equal to or less
than INR 100
crore.
(t) “Large vessel”
refers to vessels
whose fair price or
the contract price;
whichever isless, is
more than INR 100
crore.
• Credit note
available at the
time of order
placement: If a
credit note is
available from the
outset or at the
time the order is
placed,
redemption is
allowed.
• Credit note
obtained after
order for new
vessel is placed: If
a credit note is
obtained after the
order has been
placed,

No diffence found
with the definition of
Standard vessel, as
explained in meeting
be introduced when
fair price for standard
vessels is
implemented to
avoid confusion to
stakeholders.

Non
specialized
vessels is a
negative list of
the
specialized
vessel list.

DGS To confirm that
the values (Rs 100
Cr) are excluding
taxes and duties.
Yes, the value
is excluding
taxes and
duties

Please explain the
difference between
the text in bold

Credit note
can be
redeemed
against a new
building
contract
anytime upto
the last
payment
receipt from
the ship
owner.

<!-- page 48 -->

redemption is
allowed any time
before the final
settlement by the
Owner to the
shipyard.
4.4 Eligibility of
ship orders for
credit note
redemption
7
4.5 Guidelines for
the issuance and
usage of credit
notes

This section be
explained with some
examples for better
understanding of the
scheme.

8

Validity: - Credit
Note will have a
validity period (for
redemption) of 3
(three) years from
the completion
date of scrapping
the vessel.

Does Credit note
which valid for 3 yrs
lapse when utilised
on construction of
specialised vessel of
4~6yrs.

9

However, for
export orders and
vessels with fair
price greater than
100 crore,
minimum length
restriction is not
applicable.

Request to confirm
the critieria in this
para applies to other
vessels also and not
restricted to export
orders only.

10

11

However, for
export orders and
vessels with fair
price greater than
100 crore,
minimum length
restriction is not
applicable.
Vessels built under
contracts secured
on nomination
basis from the
Central or State
Government or
their agencies

What is the min
length if value is <
Rs 100 Crs does
para 1 applies for
these cases.

Paragraph 1.(g)(iii)
reference is not
valid, kindly check
and confirm

FAQ with
relevant
example will
be prepared.
The date of
validity of a
credit note is
basis the date
of redemption
i.e. when a
creditnote is
attached to a
shipbuilding
contract.
Yes, minimum
length
restriction
does not
apply for the
following: 1)
ships above
100 crore 2)
Export orders.

24m for
regular
vessels and
12m for hybrid
vessels

Reference
confirmed and
found correct.

<!-- page 49 -->

including Central
or State Public
Sector Enterprises,
except for cases
not complying with
Paragraph 1.(g)(iii)

12

LIST OF
SPECIALIZED
VESSELS

Process/guidelines
for inlcusion of
vessels into
specialised list be
bought out as HSL
wants to include
Diving Support
Vessel into the list.

13

LIST OF
INTERNATIONAL
VALUERS

Valid email id and
contact details of all
the valuers be
updated in the list.

14

• Certificate of
Actual Payment
received for a
vessel duly
certified by a
Chartered Account
registered with
Institute of
Chartered
Accountants of
India.
• Certificate of
Actual payment
received by the
recipient bank. The
certificate should
be provided as per
the format
provided in
Annexure III B2, on
the bank’s official
letterhead, and
must be duly
signed and
stamped by an
authorized official
of the bank.
• Bank Guarantee
issued by a
scheduled

% of amount that
would be released in
this stage is unclear
as defind in
ANNEXURE-II-1
PROCEDURE FOR
RELEASE OF
FINANCIAL
ASSISTANCE
(AFTER
LAUNCHING) :The
claim amount is
limited to the rate of
financial assistance
for the applicable
financial year, as
received for that
vessel by the
shipyard, as certified
by the Chartered
accountant, or 50%
of the contract price,
whichever is less

Complexity of
these vessels
is not
considered
equivalent to
"specialized
vessels".
Accordingly,
not
considered
Revised
details have
been added

Amount
considered for
computation
of FA = min of
(50% of
contract price,
price received
by the ship
owner as
certified by a
CA)

<!-- page 50 -->

commercial bank,
for an amount
equal to the
financial
assistance claimed
at this stage,

15

16

17

18

Bank Guarantee
issued by a
scheduled
commercial bank,
for an amount
equal to the
financial
assistance claimed
at this stage,
1.1 In case of
contracts, wherein
any payment is
deferred by the
buyer or any
payment is
withheld as
performance
guarantee as per
the terms stated in
the shipbuilding
contract initially
submitted to
Directorate
General of
Shipping, the
shipyard shall
apply for release of
financial
assistance, limited
to only two
instances, in the
following manner;
FORMAT OF THE
INDEMNITY
BOND
Format for
Chartered
Accountant’s
Certificate

New Query
BG is not
required at
delivery stage

It is explained that
the financial
assistance will be
released in three
stage where as this
para says it is limited
to only two
instances, request to
confirm.

Relevant
changes
made in the
guidelines.
no reference made
to the paras in the
document.
Based on indigenous
content, table
showing
proportionate
reduction in financial

New text
added in the
guidelines

<!-- page 51 -->

assistance is not
mentioned in the
document.
• Details of
Newbuilding where
credit is to be
used: Shipyard,
Vessel Name
being built,
Contract Price,
Date of contract,
applicable 10%
cap = [0.1 *
contract price].
Max cap is 5%,
• Claim: “I/We
whereas here it is
19 hereby redeem this
mentioned as 10%,
Credit Note
request to reconcile.
towards the above
project. The
permissible usage
is ₹___ (enter
lesser of note
value and 10%
cap). Please offset
this against the
payment due for
financial
assistance.”
Cochin Shipyard queries received vide email











Guidelines
have been
suitably
revised

Clarification was sought on the definition and application methodology for
“domestic content,” particularly the treatment of projects with below 30%,
between 30–40%, and above 40% domestic value addition.
Action Taken: DGS responded that this aspect has been elaborated and
explained in the guidelines.
CSL proposed extending the capping of non-specialized vessels from three
years to a longer duration, considering that even diesel engines, especially twostroke slow-speed types, currently have a lead time exceeding 30 months.
Action Taken: DGS confirmed that the guidelines have been suitably amended
to include an extended timeline of four years for normal vessels and six years
for projects involving two or more vessels.
CSL further suggested simplifying Clause 3 by removing the requirement to
obtain separate approvals from the Competent Authority for delivery extensions
beyond three years and by indicating the timeline as up to six years by default
for specialized vessels.
Action Taken: DGS informed that the guidelines have been suitably amended
to incorporate this recommendation.

<!-- page 52 -->



















It was also proposed that a clear definition of “eligible vessels” be added.
Action Taken: DGS confirmed that the definition has been included in the
guidelines.
Regarding the Government’s Remission of Duties and Taxes on Export
Products (RoDTEP) scheme under the Foreign Trade Policy 2023–28, CSL
suggested that its benefits—being a remission of embedded taxes and duties—
align with the intent of the SBFAS provisions and should be treated as
permissible under the scheme.
Action Taken: DGS stated that the proposal would be further discussed and
provisionally inserted as Paragraph 2.b.i of the guidelines.
CSL further elaborated that RoDTEP is not a form of monetary support but
rather a neutralization mechanism for embedded taxes, and that its benefits are
equivalent in effect and intent to tax exemptions. Accordingly, CSL requested
that Clause 5(d)(i) be amended to explicitly include RoDTEP as a specific
exception to the restriction, and that other export-linked schemes such as duty
drawback also be considered for inclusion.
Action Taken: This matter will be reviewed further by DGS.
CSL recommended that the list of green fuel types be expanded to include all
forms of green fuels, instead of limiting it to methanol, ammonia, and hydrogen
fuel cells.
Action Taken: DGS advised that the shipyard specify the types of vessels
utilizing fuels other than the mentioned three that may be considered for
inclusion in the updated list.
It was also noted that under SBFAS 1.0, vessels constructed on nomination
from Central or State Public Sector Enterprises were eligible for assistance,
whereas under SBFAS 2.0 they are excluded. CSL requested that this clause
be retained in alignment with the earlier version, as such projects fall under the
category of negotiated contracts. DGS clarified that nomination contracts from
Central and State Governments would be included in the exclusion list under
the revised scheme.
CSL expressed concern that the ₹100 crore distinction would adversely impact
special programs such as GTTP and Harith Nauka. It was suggested that for
special vessels, a uniform financial assistance rate of 25% be applied without
any cost-based distinction.
Action Taken: DGS clarified that, as per the approved Cabinet note, the rate
of financial assistance has been frozen and cannot be modified.

Sl. No.

CSL Comments
1.
2.

With effect from
24 Sep 2025
BOLD

DGS Response
Date of effect of the guidelines is being further
discussed.

<!-- page 53 -->

3.

4.

5.

Definition of
domestic content
is mentioned.
However,
nowhere in the
policy, the
methodology of
applying SBFAS
to below 30%,
30-40% and
above 40% is
mentioned.
Needs
elaboration.
capping of nonspecial vessels at
3 years
considering that
even diesel
engines
(especially 2
stoke slow speed
engines)
presently have a
lead time of over
30 months. We
my consider
longer period for
‘Large’ vessels.
Second last line
of second para of
clause 3 may be
removed ( i.e
’’and thereafter
the delivery
period provided
for in this Clause
shall be such
extended period
as permitted by
the Competent
Authority”). This
line gives a
meaning that the
yard has to take
a separate
approval from the
competent
authority for the
extent period

Explained in the guidelines.

Guidelines have been suitably amended to
include extended timeline of 4 years for normal
vessels. For contracts with more than 2 vessels
timeline has been extended to 6 years.

Guidelines have been suitably amended.

<!-- page 54 -->

beyond three
years. Hence
kindly make this
para more
simplified and
indicate the
timeline as upto 6
years by default
for specialized
vessels.
6.

7.

The definition of
eligible vessel
Added to the Guidelines.
needs to be
added
Under the
Foreign Trade
Policy 2023-28,
the Government
has promulgated
the RoDTEP
(Remission of
Taxes and Duties
for Export
Products)
Scheme. This
scheme is
expressly
designed to
Amended the guidelines to insert as Para 2.b.i
provide remissio
n of duties and
taxes embedded
in exported
products. This
has been done to
ensure that our
exports do not
suffer due to
embedded taxes
and thereby
make our exports
competitive.

<!-- page 55 -->

Accordingly, the
RoDTEP benefit
aligns with the
category of
“exemptions or
remissions of
domestic taxes or
import duties”
which the SBFAP
clause allows
alongside SBFAP
assistance. The
remission of
duties under this
scheme is not a
monetary support
but negation of
the embedded
taxes in the
exported product
by providing
neutralization.
Hence, RoDTEP
remission is the
same as
exemption in
effect and intent.
It is therefore
requested that
the Clause 5
(d)(i) may be
amended to
include RoDTEP
as a specific
exception to the
restriction. Simil
arly, other exportoriented
schemes like
duty drawback
etc also be
considered to
inclusion in the
exception.

<!-- page 56 -->

8.

9.

May include all
types of green
fuels, instead of
limiting to
Methanol,
Ammonia &
Hydrogen fuel
cells.

Shipyard to clarify specifically which vessel other
than methanol, ammonia, hydrogen fuel cell is
required to be added to the list.

In SBFA 1.0, the
vessels on
nomination from
Central or State
Public Sector
Enterprises were
not excluded. In
SBFA 2.0, the
same is excluded
from availing
SBFA. Kindly
retain the clause
as per SBFA 1.0,
as such contracts
comes under the
type of
negotiated
contracts.
Nomination contracts from Central/state
government to be considered in the exclusion
list.

10
.

The restriction of
100 Cr will
adversely affect
GTTP and Harith

As per the approved Cabinet noe, the rate of FA
has been frozen.

<!-- page 57 -->

Nauka
programmes.
Therefore, in
case of special
vessels, there
should be only
one rate of 25%,
without 100 Cr
distinction
SWAN queries received vide email










It was highlighted that these new categories of vessels are two to three times
larger in size compared to LR/MR tankers, falling within a displacement range
of approximately 0.8L to 3.2L DWT. The VLCC, Suezmax, and Aframax vessels
have not been previously constructed in India and require a significantly higher
level of technological capability, design expertise, skilled manpower, and capital
investment.
Accordingly, it was proposed that these vessel types be incorporated under
Schedule-II, “List of Specialized Vessels,” of the document Guidelines for
Implementation of the Shipbuilding Financial Assistance Scheme (SBFAS),
under the category “Crude Carrying Vessels – VLCC, Suezmax, and Aframax.”
Action Taken: DGS informed that the guidelines have already been suitably
amended to consider an extended delivery timeline for all vessels. Specifically,
the standard timeline has been extended to four years for normal vessels and
six years for contracts involving two or more vessels.
It was further discussed under the Energy and Forex Security consideration that
the principal objective of the Four-Pillar approach for the Shipbuilding and
Maritime sector is to enhance national energy and foreign exchange security
by promoting the construction of high-GRT liquid and bulk carriers in India. CSL
proposed that a reference text may be incorporated in the guidelines to
acknowledge the strategic importance of such shipbuilding projects, stating:
“Energy and Forex Security imperatives of the country may warrant prioritizing
certain specific shipbuilding cases as necessitated.”
Action Taken: DGS clarified that this provision is not directly relevant to the
SBFAS framework and therefore may not be included in the scheme guidelines.

1 List of specialized ships

<!-- page 58 -->

Specialised Ships. During the review on 17
Oct 25 by Secretary Shipping with the Oil
companies the list of vessels required by the
Oil companies was pruned down from 112 to
59 in number. This has been done by
reducing the number of LR / MR Tankers and
increasing the VLCC, Suezmax and Aframax
vessels. It is submitted that the new category
of vessels are double or triple in size of
LR/MR tankers and fall in the displacement
range of 0.8L-3.2L DWT. The VLCC,
Suezmax & Aframax vessels have never
been made in the country and require an
extremely high level of technology, design,
skill set and CAPEX infusion. It is there fore
proposed that the same be included at Page
18, Schedule-II - List of Specialised Vessels
of the document ?Guidelines for
Implementation of Shipbuilding Financial
Assistance Scheme (SBFAS)?. 19. Crude
carrying vessels ? VLCC, Suezmax, Aframax
(b) Energy & Forex Security. It is
understood that the primary aim of the Four
Pillar approach for Shipbuilding and Maritime
sector is Energy and Forex which is mainly
possible by constructing high GRT liquid and
bulk carriers in India. Accordingly following
text could be included at page 4 of the
document ?Guidelines for Implementation of
Shipbuilding Financial Assistance Scheme
(SBFAS)?. (w) ?Energy & Forex Security?
imperatives of the country may warrant
prioritising certain specific shipbuilding cases
2 as necessitated.
Hyundai queries received vide email








Extended timeline has been
considered for the delivery of
all vessels, accordingly,
Guidelines have been suitably
amended to include extended
timeline of 4 years for normal
vessels. For contracts with
more than or equal to 2
vessels timeline has been
extended to 6 years.

This provision is not relevant to
the SBFAS scheme

It was proposed that the salaries of foreign engineers and production
managers, who are either directly employed by Indian shipyards or deputed to
India under a service agreement, should be recognized as part of the Local
Content.
Action Taken: DGS clarified that irrespective of nationality, if such salaries are
paid in Indian Rupees (INR), they shall be considered under the local content
requirement in accordance with applicable Indian laws.
Further, it was suggested that if the total construction cost includes overhead
expenses, the corresponding local overhead costs should also be recognized
in the numerator while calculating local content.
Action Taken: DGS confirmed that all expenditures made in INR, including
overhead expenses, will be accounted for under the local content requirement.

<!-- page 59 -->

Query Raised

DGS Response

1 (I) Specialized vessel Category
- Proposal in Brief
To strengthen the competitiveness of the Indian
shipbuilding industry, it would be desirable to
include not only high value-added specialized
vessels but also large general-purpose commercial
ships (such as Aframax-class tankers and mediumsized product carriers) in the category of
Specialized Vessels under the SBFAP..

Complexity of these
vessels is not considered
equivalent to "specialized
vessels". Accordingly,
not considered

2 Domestic Content Requirement
Brief: Salaries of foreign engineers and production
managers who are either directly employed by
Indian shipyards or dispatched to India under a
Service Agreement should be recognized as part of
Local Content.
Proposal: If total construction costs include
overhead expenses, corresponding local overhead
costs should also be recognized in the numerator.

Irrespective of the
nationality, If salaries are
paid in INR, the same
would be considered in
the local content
requirement/as per the
local indian laws
All expenses made in
INR including overheads,
would be considered in
the local content
requirement.

If not, the denominator should be recalculated
based on direct costs only.
ICCSA queries received vide email









ICCSA representatives sought clarification on several aspects related to the
Shipbuilding Financial Assistance Scheme (SBFAS) during the consultation.
It was clarified that the scheme is available to all Indian shipyards; however,
yards must be registered on the SBFAS portal to be eligible to apply for an inprinciple approval.
A query was raised regarding the inclusion of owner-supplied equipment and
machinery in the computation of overall shipbuilding costs.
Action Taken: DGS confirmed that all costs associated with the construction
of the vessel, including items supplied directly by the owner, will be considered
toward the total project cost for determining financial assistance eligibility.
Regarding cost escalation,
Action Taken: DGS explained that in-principle approval is granted on the basis
of the initial contract price, which serves as the budget estimate. Valuations

<!-- page 60 -->
























conducted by approved valuers are also based on these initial specifications. If
any technical or commercial parameters are revised later, a fresh set of
assessments will be required.
Participants noted that most shipbreaking contracts entered into by Indian
shipowners are executed through “cash buyers,” who subsequently deal with
the ship recycling yards.
Action Taken: DGS acknowledged this reality and informed that credit notes
have been made transferable, thereby allowing cash buyers to sell them to the
actual shipowners.
Clarification was sought regarding the intent of a particular section of the
guidelines.
Action Taken: DGS explained that the clause ensures financial assistance is
extended only when the majority of the vessel’s construction activity occurs
within India.
The time limits prescribed for completion of vessel construction were also
discussed. It was requested that the provision for schedule relaxation should
not be limited only to specialized vessels.
Action Taken: DGS clarified that the extended construction timeline of four
years will now apply to regular vessels as well.
A request was made to confirm that, in cases where the value of a credit note
exceeds 5% of the value of a new vessel, the redeemable amount would be
capped at 5%.
Action Taken: DGS confirmed that credit notes may indeed be redeemed up
to 5% of the new vessel’s value.
It was further proposed that, considering the prolonged period often involved
between the sale of a vessel for demolition and the completion of scrapping, an
alternate document such as a “beaching certificate” issued by local authorities
could be accepted to facilitate timely processing.
Action Taken: DGS clarified that, in accordance with Cabinet approval, credit
notes can only be issued upon completion of the demolition or recycling
process.
ICCSA suggested allowing greater flexibility in the utilization of credit notes.
DGS responded that credit notes are already designed to be stackable and
transferable, offering sufficient flexibility; however, partial utilization remains
disallowed.
Proposals for phased realization or partial encashment of credit notes were also
raised. These points were taken under advisement for further consideration by
the shipyards.
Further, it was proposed to include additional vessel types—such as Ro-Ro,
Ro-Pax, reefer vessels, and high bollard pull tugs—under the specialized
category, particularly to enhance salvage capability and emergency response
preparedness.

<!-- page 61 -->





ICCSA observed that the ₹100-crore threshold for specialized vessels
employing emerging technologies may be too restrictive and suggested
reducing it to ₹50 crore to encourage investment.
Action Taken: DGS clarified that the ₹100-crore threshold has been fixed
under the Cabinet-approved framework and therefore cannot be modified.

Secti
on Proposed provision
Applicability :
The said policy as well
as the guidelines shall
be applicable to all the
Indian shipyards.
Whereas section 4.1 sta
tes:
The above Credit
Note(s) can be
redeemed by the vessel
owner towards payment
for the vessel being
ordered/under
construction at an
Indian shipyard, which
1 ( c is registered in the
) SBFAS web portal.
“Actual
Payment” means the
total quantum of
payment received by
the shipyard pertaining
to a shipbuilding
contract including such
payment received
subsequent to the
delivery of the vessel as
is duly certified by a
Chartered Accountant
registered with Institute
of Chartered
Accountants of India in
the format prescribed at
Annexure-III of these
guidelines and
supported by requisite
2 (a ) documentary evidence.

ICCSA’s
inputs/co
mments

IS the
scheme
available
to yards
registered
in the
SBFAS
portal or
open to all
yards in
India.
Request
clarificatio
n.
It is very
common
practice in
shipbuildin
g
contracts
in India
where key
equipment
,
machinery
may be
“owners
supply”
and paid
by the
owner
directly to
the
vendor.
Would
such cost

Committee Response

The scheme is available to all
Indian Shipyards, however, they
would need to be registered on the
SBFAS portal in order to apply for
an in-principal application.

All costs attached to the
construction of the ship whether a
part of owner's supplied item or
otherwise is considered towards
the computation of financial
assistance,

<!-- page 62 -->

incurred
toward
shipbuildin
g will be
factored in
the
“overall
cost” and
thus be
eligible for
SBFAS.
“Contract
Price” means the price
at which the initial or the
first shipbuilding
contract has been
signed, or any such
lower price agreed at a
later date in a
supplementary or
subsequent Contract for
the vessels required to
be constructed under
the Contract involving
the shipyard as one of
2 ( d the parties to the said
) later Contract.

Cost
escalation
may also
be
considere
d.
Most
shipbreaki
ng
contracts
by Indian
shipowner
s are with
“Cash
buyers”
who in
turn enters
(iv)
For shipbreaking into an
credit note, the fair price agreement
refers to the lowest of
with
the prices for ship
scrapyard
recycling, as on the
at his/her
date
convenien
of contract with the Ship ce.
breaking yard, as are
Signing a
determined by three
direct
approved International
contract
3 ( g Valuers listed in
with
) iv Schedule–III.
shipbreaki

In-principal approval is granted
basis the initial contract price
based on which a budget estimate
is prepared. Also, valuations
carried out by valuers are also
based on the initial specifications.
Subsequently, if specifications are
revised, a fresh set of assessment
is required.

This is true, Accordingly, credit
notes have been made
transferrable, hence cash buyers
can sell the credit notes to the ship
owners.

<!-- page 63 -->

ng yard is
rare.
Mechanis
m is
required to
address
this
ground
reality.
(r) “Major portion of the
hull” means, the main
hull of the ship
/ vessel, that is made of
Shipbuilding Grade
Steel, Aluminum or any
such materials as
approved for the
purpose of construction
of ships/ vessels by
Recognized Maritime
Authorities, and does
not include,
Superstructure,
Equipment &
Machineries, Mast,
Equipment foundations,
Shaft Support Brackets,
Stern tube, Bow
Thruster Tunnels,
2 (r ) Rudder etc.

Eligibility of vessel for
availing the Financial
3 Assistance.

The
purpose of
this
section is
not
understoo
d?
The time
limits set
for
completion
of
constructio
n require
more
realistic
assessme
nt. The
scope of
relaxation
in time
limit is
granted
only for
“specialize
d vessels”.

This clause ensures that financial
assistance is available only if
majority of the construction
happens in India

Extended timeline of 4 years for
regular vessels has been
considered.

<!-- page 64 -->

•
Provided that,
the maximum amount
that can be redeemed
by the government to
the shipyard would be
the value of the credit
note(s) or 5% of the
value of the new vessel
among the lowest of fair
price, contract price,
price received by
the shipyard for the new
4.1 vessel
2.
A statement
from the Chartered
Accountant endorsing
the evidence for
confirmation of Bank
transaction indicating
4.2- the price received from
2 the ship breaking yard.

Request
clarity that
even if the
value of
the credit
note
exceeds
5% of the
value of
the new
vessel, 5%
of the
value of
new
vessel will
be the cut
off credit
Yes, credit note can be redeemed
limit.
upto 5% of the value of new vessel.

Same as 3
(g ) iv
Between
the sale of
the vessel
for
demolition
and
completion
of
scrapping
can be a
very long
drawn
process.
Alternative
•
A certificate of
ly, to make
“recycling” from a
the
certified recycling yard
process
and a certificate of
more
demolition completion
efficient,
issued by the respective alternate
State Maritime Board/
document
state government shall
such as
As per the cabinet approval, credit
be obtained and
“beaching note can be issued only upon
4.3 submitted.
certificate” completion of demolition/recycling.

<!-- page 65 -->

4.5

Anne
xure
VI

4.7

4.8

Sche
dule
II

issued by
the local
authority
may be
considere
d.
Request to
provide
more
flexibility
to utilize
the credit
note

•
Single-contract
utilization: Each credit
note must be
applied in full to a single
newbuilding contract.
Partial utilization is not
permitted.
4.
Proof of
Scrapping: Certificate of
Recycling Completion
issued by the respective
State Maritime
Board/State
Government competent
authority, Copy of the
statutory Ships
Recycling Certificate or Same as
ship deletion certificate
4.3
Realizatio
At the time of delivery of n
the new vessel, the
(encashm
vessel owner shall
ent) of
submit the Credit Note
credit note
to the shipyard for full
may be
and final settlement of
considere
the credit note value
d in
payable to the shipyard. phases.
•
Credit Notes are Partial
indivisible and must be
encashme
utilized in full against a
nt of credit
single new shipbuilding note may
contract. Partial
be
application is not
considere
permitted.
d as well.
Suggest to
add RoRo, RoPax,
Reefers,
and High
bollard pull
Tugs (with
Specialized list of
emphasis
vessels
on

Credit notes have been made
stackable, transferrable, thus
providing adequate flexibility,
However, partial utlization is not
permitted.

As per the cabinet approval, credit
note can be issued only upon
completion of demolition/recycling.
Shipyards need to be paid the
credit note as soon as possible
because they have already
delivered the vessel, before raising
a request for redemption of credit
note. Hence, phased payment of
credit note is not considered.
Shipyards need to be paid the
credit note as soon as possible
because they have already
delivered the vessel, before raising
a request for redemption of credit
note. Hence, phased payment of
credit note is not considered.

Complexity of these vessels is not
considered equivalent to
"specialized vessels". Accordingly,
not considered

<!-- page 66 -->

developing
salvage
capability
and
emergenc
y
response)
A
threshold
of 100 Cr
is rather
high for
specialize
d vessel
using
developing
technologi
es. A
threshold
of 50 Cr
may be
more
Specialized vessel of
conducive
value up to 100 Crore
to kick
Sche 15% of value below 100 start the
dule Crore and 25% on value investment Threshold of 100 cr has been
IV above 100 Crore
s.
frozen in the cabinet approval.
APMB queries received vide email











What happens when an SPV is formed with an international company?
Action Taken: The registered shipyard as per the certificate will be eligible for
the financial assistance.
Please clarify the non-inclusion of Indian valuers and provide the final list of
empanelled valuers.
Action Taken: Indian valuers are already in the empanelled list.
Please confirm whether duly approved contractual extensions (e.g., forcemajeure or owner-caused delay(s)) extend the six-year eligibility window.
Action Taken: No. May be evaluated on case by case basis as directed by the
IM.
Priority rules / wait-list mechanism: Please share the method used when the
budget is insufficient (e.g., First In First Out, contract size, strategic category).
Delay compensation: Please clarify whether interest/compensation is payable
for delayed release.
Action Taken: 1. In case of insufficient funds, shipyards are paid in the next
financial year. 2 No. (Please add a clause in the guidelines to avoid ambiguity)
Stacking of credit notes: Please clarify whether multiple credit notes may be
combined/stacked
for
a
single
newbuild.

<!-- page 67 -->



Transfer documentation: Please specify the documentation and approval flow
required when credit notes are transferred.
Action Taken: 1. Yes 2. Explained in the guidelines.

<!-- page 68 -->

<!-- page 69 -->

Response to the queries against their respective Sr. No. is mentioned below:1
2
3
4
5

The registered shipyard as per the certificate will be eligible for the
financial assistance
Indian valuers are already in the empanelled list.
No. May be evaluated on case by case basis as directed by the IM.
1. In case of insufficient funds, shipyards are paid in the next financial
year. 2 No
1. Yes 2.Explained in the guidelines

<!-- page 70 -->

Annexure VI
Summary of stakeholder discussions and action taken

1. Workshop on 10.10.2025

<!-- page 71 -->

Stakeholder meeting dated 14.10.2025 and 17.10.2025
Sl. No.

Stakeholder
Name &
Organization

Input/Suggestion

1

Shri Anil Devli
(INSA)

Subcommittee roles and
review mechanism

2

Shri S.V.
Rambabu
(HSL)

Insurance surety bonds as
BG alternative

3

Shri Srinivasa
Rao Padala
(HSL), Shri

Milestone-linked project
timelines for large vessels

DGS Response
Subcommittee roles and
review mechanism
explained.
Basis the current
discussions, Bank
Guarantee is considered
necessary.
3 stage payments has
been finalized for all
vessels i.e. launching,
delivery and 3rd stage

<!-- page 72 -->

Sanjiv Walia
(SAI)

4

5

6

7

upon receipt of final
payment from ship owner.

SRIA

A representative
suggested inclusion of EU
Ship Recycling Regulation
(EUSRR) compliant yards
in addition to Hong Kong
Convention (HKC)
compliance

Shri Rakesh
Singh (ICCSA)

Concerns were raised by
Shri Rakesh Singh
regarding determination of
scrap value and the
challenges in transferring
credit notes through
intermediaries.

Shri Srinivasa
Rao Padala
(HSL), Shri
Ghoshal
(Suryadipta
Projects)

Recommended inclusion
of PSU-built auxiliary and
dual-purpose defence
vessels under the
scheme. He also
suggested redefining
“delivery date” to align
with Ministry of Defence
acceptance procedures.

Shri Rakesh
Singh (ICCSA)
Shri Nagesh
Krishna
Moorthy (CSL)

Clarity on owner-supplied
equipment and inclusion
of refrigerated cargo
vessels under the
specialised list.
Suggested higher
assistance rates for small,
specialised vessels below
₹100 crore. Similar
concern was raised for
green tugs as well.
Diving Support Vessels
(DSVs) to be considered
in the Specialised vessel
category

It is noted that all
EU(SSR) compliant yards
are HKC compliant, hence
no amendment required.
Scrap value will be
assessed by the
international valuators.
Credit notes are
transferrable hence cash
buyers can resell the
credit note to the ship
owner.
Vessels built for defence
purposes or for use by
Navy or Coast Guard are
excluded. However,
vessels like tugs, tankers,
cargo ships and
passenger ships that are
not fitted with any
weaponry, contracted for
construction by foreign
defence entities are
eligible.

1.Diving support vessel
with a moonpool has been
added to the list of
specialized vessel
whereas refrigrerated
cargo vessel was not
considered complex
enough. 2. Rate of FA has
been frozen in the cabinet
note.

<!-- page 73 -->

8

Shri Srinivasa
Rao Padala
(HSL)

9

Shri Haresh
Parmar (SRIA)

10

Shri Anil Devli
(INSA)
Shri Srinivasa
Rao Padala
(HSL)

11

Shri Prashant
(Chowgule)

12

Lt Cdr. Pravat
Haldar
(Titagarh)

13

Sh Talavia, CE,
GMB

Proposed introduction of a
grace period (6–9 months)
beyond declared timelines
for large PSU projects
before financial penalties
are applied.
Recommended cost-plus
valuation methodology for
audited PSU projects
instead of market
comparison.
Suggested allowing
corporate or government
guarantees in place of
bank guarantees for
PSUs.
Requested DG Shipping
to issue a standard
closure certificate format
compatible with PSU audit
and MoD systems.
Proposed inclusion of
DGQA/Navy
representatives in the Fair
Price Committee (FPC) for
defence-linked projects.
Raised concerns over
double GST when Indian
owners sell ships
domestically for recycling,
diverting ships abroad.
Requested clearer
definitions of “specialised”
and “non-specialised”
vessels and default sixyear timeline for
specialised vessels.
Attendee requested to
extend the guidelines as
much as possible.
If the whole construction is
offloaded to another party.
The "Shipbuilding
Contract" to be rephrased.
"Contract Price" there are
some parts/ items which
are supplied by the owner.

In case of bidding,
contract price is
considered the fair price
whereas for negotiation,
market valuation is
considered appropriate.

Issue is not related to the
current scheme.

Relevant clause suitably
amended.

This matter is being
discussed further.
Builder's certificate is to
be issued by the yard
which has signed the
shipbuilding contract.
The contract should
include all the prices i.e.,
should be inclued with
owner's supplied items.

<!-- page 74 -->

The intent of registration
is to allow the shipyard to
apply for an in-principal
application, hence, the
registration process has
been kept simpler.
It was explained that as
long as the benchmark of
100 cr is met irrespective
of any length the financial
assistance will be
provided. For the hybrid
vessels the length
requirement is 12 m.
Fair Scrap value is based
on the values provided by
the international valuer
before the application
made.
Timelines cannot be
mandated to the
international valuators.
However, in case shipyard
does not receive 3
valuations within 45 days
of the receipt of valuator
list, yard can request for a
fresh list of valutors and
then yard is provided
another 45 days for
submitting 3 valutor
certificates.

Sh Amit Waje
(IRS)

Minimum set of
requirement or framework
for registration of the
shipyard

15

Shri. Anshul
Wadia (Wadia
Boatbuilders)

Defination of Small ships,
levay to specialized
vessels like tugs, inland
towing vessels which are
lesser than 24 m.

16

Sh Talavia, CE,
GMB

Fair scape value is
decided well in advance
before ship is sent to
scrap.

Sh Talavia, CE,
GMB

How and what timelines of
approval, international
valuer will take.The
process of the scrap to be
considered.

Sh Bharat
Krishnan (L&T)

Domestic Contect is this
Contract Price - anything
imported.
Attendee also brought out
that many of the OEMs
has offices in India. The
best example is MAN if
the the engine is imported
by them and payment is
done in INR will it be
considered as domestic
content

Certificate from OEM
would ascertain the
country of origin.

Shri. Anshul
Wadia (Wadia
Boatbuilders)

Lenth requirement for the
export order.
Only boats are eligilble for
the financial assistance.
Is IACS mandetory? Is

There is no length
requirement for an export
order.
There is no requirement of
the propulsion.
Vessels built under

14

17

18

19

<!-- page 75 -->

Type approved boats are
eligible

20

SCI

21

Shri. Gaurav
(SWAN)

PSU scraps the vessels
through tendering.
Requested to consider the
tender price
Untilization of the credit
note and linking with the
SBFAS.

22

Sh Bharat
Krishnan (L&T)

If the contract does not
include ammunition,
weapons will be assisted
finances
OPVs, vessels fitted with
small arms can be
included

23

Sh Bharat
Krishnan (L&T)

Specialized Vessels list

24

Mr. Amit Waze
(IRS)

25

Cmde Sanjeev
Kapoor
(SWAM)

Launching of the vessel.
Shipyards takes up the
launching according to
tides etc. Class only
provides the only
clearances.
If subsidy at the launching
stage to be availed is
there any necessity of
paying BG.
If one time payment to be
taken will there be any
requirement of BG

SBFAS need to be built
under the classification of
a Recognized
Organization of the
Governement of India.
Amended in the
guidelines.
Process and timelines
were explained to the
shipyard
Vessels built for defence
purposes or for use by
Navy or Coast Guard are
excluded. However,
vessels like tugs, tankers,
cargo ships and
passenger ships that are
not fitted with any
weaponry, contracted for
construction by foreign
defence entities are
eligible.
The list of specialized
vessel has been suitably
amended.
Launching date
mentioned by RO will be
considered as final.

At launching stage BG is
required. At delivery BG is
not required.

Inputs received from HSL(ISBA) vide email
Points forwarded to DG Shipping on 14 Oct 25 - SBFAS
Sl No. Point

Inputs/ Clarification
sought

DGS
Response

<!-- page 76 -->

1

2

3

4

“Date of Contract” means
the date of signing of the
initial or the first Contract
for construction of
underlying vessel or
vessels, as the case may
be.
In the case of repeat
orders, the L1 price
discovered / determined
through the initial
competitive, open and fair
bidding process will be
considered as Fair Price for
vessels under the repeat
order, subject to the initial
tender document and the
contract clearly mentioning
about the repeat order and
the criteria to be followed,
including that of pricing, for
awarding the repeat order.
“Recognized Organization”
means an organization
recognized by the
Government of India as per
the Gazette Notification No.
S.O. 3316(E) dated
December 26, 2014, as
amended from time to time.
“Non-Specialized Vessel”
means vessel which is not
a specialized vessel as
described above.

Request to include the
concept of effective date of
contract which may be
date of receipt of stage 1
payment or
finalization/approval of
design/model test etc (as
per contract)

If repeat order clause not
mentioned in the tender or
contract, can I claim
financial assistance for
repeat order?

Gazette Notification No.
S.O. 3316(E) dated
December 26, 2014 be
included in the base
scheme document for
ready reference.
No diffence found with the
definition of Standard
vessel, as explained in
meeting be introduced
when fair price for
standard vessels is
implemented to avoid
confusion to stakeholders.

Cannot be
considered as
it is very
subjective and
varies from
contract to
contract which
will effect the
timelines fixed
under the
scheme.

No, financial
assistance
eligibility will
need to be
reascertsined
after reviewing
the tender
documents.

Cannot be
annexed as it
changes from
time to time.
Non
specialized
vessels is a
negative list of
the specialized
vessel list.

<!-- page 77 -->

5

6

7

(s) “Small vessel” refers to
those vessels whose fair
price or the contract price;
whichever is less is equal to
or less than INR 100 crore.
(t) “Large vessel” refers to
vessels whose fair price or
the contract price;
whichever isless, is more
than INR 100 crore.
• Credit note available at
the time of order
placement: If a credit note
is available from the outset
or at the time the order is
placed, redemption is
allowed.
• Credit note obtained after
order for new vessel is
placed: If a credit note is
obtained after the order
has been placed,
redemption is allowed
any time before the final
settlement by the Owner
to the shipyard.
4.4 Eligibility of ship orders
for credit note redemption
4.5 Guidelines for the
issuance and usage of
credit notes

DGS To confirm that the
values (Rs 100 Cr) are
excluding taxes and duties.

Yes, the value
is excluding
taxes and
duties

Credit note
can be
redeemed
Please explain the
against a new
difference between the text
building
in bold
contract
anytime upto
the last
payment
receipt from
the ship
owner.
This section be explained
with some examples for
better understanding of the
scheme.

8

Validity: - Credit Note will
have a validity period (for
redemption) of 3 (three)
years from the completion
date of scrapping the
vessel.

Does Credit note which
valid for 3 yrs lapse when
utilised on construction of
specialised vessel of
4~6yrs.

9

However, for export orders
and vessels with fair price
greater than 100 crore,
minimum length restriction
is not applicable.

Request to confirm the
critieria in this para applies
to other vessels also and
not restricted to export
orders only.

FAQ with
relevant
example will
be prepared.
The date of
validity of a
credit note is
basis the date
of redemption
i.e. when a
creditnote is
attached to a
shipbuilding
contract.
Yes, minimum
length
restriction
does not apply
for the
following: 1)
ships above

<!-- page 78 -->

100 crore 2)
Export orders.

10

11

However, for export orders
and vessels with fair price
greater than 100 crore,
minimum length restriction
is not applicable.
Vessels built under
contracts secured on
nomination basis from the
Central or State
Government or their
agencies including Central
or State Public Sector
Enterprises, except for
cases not complying with
Paragraph 1.(g)(iii)

24m for
What is the min length if
regular
value is < Rs 100 Crs does
vessels and
para 1 applies for these
12m for hybrid
cases.
vessels

Paragraph 1.(g)(iii)
reference is not valid,
kindly check and confirm

12

LIST OF SPECIALIZED
VESSELS

Process/guidelines for
inlcusion of vessels into
specialised list be bought
out as HSL wants to
include Diving Support
Vessel into the list.

13

LIST OF INTERNATIONAL
VALUERS

Valid email id and contact
details of all the valuers be
updated in the list.

14

• Certificate of Actual
Payment received for a
vessel duly certified by a
Chartered Account
registered with Institute of
Chartered Accountants of
India.
• Certificate of Actual
payment received by the
recipient bank. The
certificate should be
provided as per the format
provided in Annexure III B2,
on the bank’s official
letterhead, and must be
duly signed and stamped
by an authorized official of
the bank.

% of amount that would be
released in this stage is
unclear as defind in
ANNEXURE-II-1
PROCEDURE FOR
RELEASE OF FINANCIAL
ASSISTANCE (AFTER
LAUNCHING) :The claim
amount is limited to the
rate of financial assistance
for the applicable financial
year, as received for that
vessel by the shipyard, as
certified by the Chartered
accountant, or 50% of the
contract price, whichever is
less

Reference
confirmed and
found correct.
Complexity of
these vessels
is not
considered
equivalent to
"specialized
vessels".
Accordingly,
not considered
Revised
details have
been added

Amount
considered for
computation of
FA = min of
(50% of
contract price,
price received
by the ship
owner as
certified by a
CA)

<!-- page 79 -->

• Bank Guarantee issued
by a scheduled commercial
bank, for an amount equal
to the financial assistance
claimed at this stage,

15

16

17

18

Bank Guarantee issued by
a scheduled commercial
bank, for an amount equal
to the financial assistance
claimed at this stage,
1.1 In case of contracts,
wherein any payment is
deferred by the buyer or
any payment is withheld as
performance guarantee as
per the terms stated in the
shipbuilding contract initially
submitted to Directorate
General of Shipping, the
shipyard shall apply for
release of financial
assistance, limited to only
two instances, in the
following manner;
FORMAT OF THE
INDEMNITY BOND
Format for Chartered
Accountant’s Certificate

New Query

It is explained that the
financial assistance will be
released in three stage
where as this para says it
is limited to only two
instances, request to
confirm.

no reference made to the
paras in the document.
Based on indigenous
content, table showing
proportionate reduction in
financial assistance is not
mentioned in the
document.

BG is not
required at
delivery stage

Relevant
changes made
in the
guidelines.
-

New text
added in the
guidelines

<!-- page 80 -->

19

• Details of Newbuilding
where credit is to be used:
Shipyard, Vessel Name
being built, Contract Price,
Date of contract, applicable
10% cap = [0.1 * contract
price].
• Claim: “I/We hereby
redeem this Credit Note
towards the above project.
The permissible usage is
₹___ (enter lesser of note
value and 10% cap).
Please offset this against
the payment due for
financial assistance.”

Max cap is 5%, whereas
here it is mentioned as
10%, request to reconcile.

Guidelines
have been
suitably
revised

Inputs received from CSL vide email

Sl. No.

CSL Comments
1.
2.

3.

4.

With effect from
24 Sep 2025

DGS Response
Date of effect of the guidelines is being further
discussed.

BOLD
Definition of
domestic content
is mentioned.
However, nowhere
in the policy, the
methodology of
applying SBFAS
to below 30%, 3040% and above
40% is mentioned.
Needs
elaboration.
capping of nonspecial vessels at
3 years
considering that
even diesel
engines
(especially 2 stoke
slow speed
engines) presently
have a lead time

Explained in the guidelines.

Guidelines have been suitably amended to
include extended timeline of 4 years for normal
vessels. For contracts with more than 2 vessels
timeline has been extended to 6 years.
