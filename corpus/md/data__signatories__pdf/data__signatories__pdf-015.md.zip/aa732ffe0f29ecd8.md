---
doc_id: "aa732ffe0f29ecd8"
source_url: "https://www.legislative.gov.in/static/uploads/2025/07/668c0a931068200ee948e24724b1b505.pdf"
ministry: "Legislative Department (LD)"
title: "Outsourcing OM Reg.Extension-2023030361"
date: "2014-10-28"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "7cd96106b39e0dab"
---

<!-- page 1 -->

F. No. A-60011/05/2011-Admn.IV(LA)
Government of India
Ministry of Law and Justice
Department of Legal Affairs
2 2K नेट

Shastri Bhawan, New Delhi
Dated the 28" October, 2014

OFFICE MEMORANDUM
Subject: Outsourcing of services of Data Entry Operators in Department of Legal

Affairs on contract basis- reg.

The undersigned is directed to refer to tender document dated 12.09.2014
inviting tenders from agencies for outsourcing of services of 13 DEQs in Department of
Legal Affairs by 3:00 P.M. of 29.09.2014 and to inform that the last date of submission
of bids has been extended to 3:00 P.M. of 17.11.2014.

® Sota)

Under Secretary to the Govt. of India

Tele. No. 23389127

NIC Cell with a request to upload the same on the webpage of this Department
alongwith the tender notice.
