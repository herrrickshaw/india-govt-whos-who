---
doc_id: "ac855d56c3eebd3f"
source_url: "https://doj.gov.in/static/uploads/2025/09/fa974c1b385838e0f18a8f547c35845d.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of transfer of Shri Justice Raj Mohan Singh Judge of P&H High Court as Judge of Madhya Pradesh High Court (18.10.2023)"
date: "2023-10-18"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c9895bcee395fa57"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K-11019/26/2023-US.I/II (ix)
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, dated 18'" October, 2023.
NOTIFICATION
In exercise of the power conferred by clause (1) of Article 222 of the
Constitution of India, the President, after consultation with the Chief Justice of
India, is pleased to transfer Shri Justice Raj Mohan Singh, Judge, Punjab and
Haryana High Court, as a Judge of Madhya Pradesh High Court and to direct him
to assume charge of his office in the Madhya Pradesh High Court.
ie) 19}
(Rajinder Kashyap)
Special Secretary to the Government of India
Tele: 23383037
To
The Manager,
Government of India Press,
Minto Road, New Delhi.

<!-- page 2 -->

223
No. K-11019/26/2023-US.I/II (ix) Dated: 18.10.2023
Copy to:-

iL Shri Justice Raj Mohan Singh, Judge, Punjab and Haryana High Court
through the Registrar General, Punjab and Haryana High Court,
Chandigarh.

Be. The Secretary to Governor, Madhya Pradesh, Bhopal.

3. The Secretary to Governor of Punjab, Chandigarh.

4. The Secretary to Governor of Haryana, Chandigarh.

5. The Secretary to Chief Minister, Madhya Pradesh, Bhopal.

6. The Secretary to Chief Minister of Punjab, Chandigarh.

a The Secretary to Chief Minister of Haryana, Chandigarh.

8. The Secretary to the Chief Justice, Madhya Pradesh High Court,
Jabalpur.

के Secretary to the Acting Chief Justice, Punjab and Haryana High Court,
Chandigarh.

10. The Chief Secretary, Government of Madhya Pradesh, Bhopal.

ll. The Chief Secretary, Government of Punjab, Chandigarh.

12. The Chief Secretary, Government of Haryana, Chandigarh.

13. The Registrar General, Madhya Pradesh High Court, Jabalpur.

14. The Registrar General, Punjab and Haryana High Court, Chandigarh.

15. The Accountant General, Madhya Pradesh, Bhopal.

16. The Accountant General, Punjab, Chandigarh.

17. | The Accountant General, Haryana, Chandigarh.

18. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.

19. PS to Principal Secretary to the Prime Minister, PM’s Office, South
Block, New Delhi.

20. Registrar (Conf.), o/o Chief Justice of India, 07, Krishna Menon Marg,
New Delhi.

21. PS to MoS, L&J (I/C)/PPS to Secretary (J).

22. Technical Director, NIC, Department of Justice, with a request to upload
on the Website of the Department (www.doj.gov.in).

Bc
(Prem Chand)
Under Secretary (Appointments-I)
Tele: 23382978
