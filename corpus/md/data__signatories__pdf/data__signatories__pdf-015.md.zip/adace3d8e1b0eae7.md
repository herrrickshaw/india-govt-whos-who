---
doc_id: "adace3d8e1b0eae7"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/53d91a9cd4c3a6bfb33350351f58f282.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Draft recruitment rules for the post of Supply Officer, BCGVL, Chennai"
date: "2019-04-16"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "760da4f0b72916f7"
---

<!-- page 1 -->

Government of India
Ministry of Health & Family Welfare
Directorate General of Health Services
Public Notice on draft Recruitment Rules for the post of Supply Officer, Group ‘B’
Gazetted in level-8 at BCGVL, Chennai.
In compliance with DoPT,s O.M. AB.14017/61/2008-Estt. (RR) dated 13.10.2015, the
draft Recruitment Rules for the post of Supply Officer in BCGVL, Chennai is annexed.
The stakeholders interested in making any objections/comments or suggestions on the
draft Recruitment Rules may do so in writing, within a period of 30 days from the date of
publication of draft recruitment Rules to Swwarupa Saraan, Deputy Director (EPI), Room No.
647-A, Wing, Directorate general of Health Services, Nirman Bhawan, New Delhi-110108 and
the soft copy may be sent to epidghs@gmail.com.

(Swwarupa Saraan)
Deputy Director
New Delhi
Dated

<!-- page 2 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART II, SECTION 3, SUB-SECTION (i)]
Government of India
Ministry of Health and Family Welfare
Notification
New Delhi, Dated the

2019

G.S.R. - In exercise of the powers conferred by the proviso to Article 309 of the Constitution, the
President hereby makes the following rules regulating the method of recruitment to the post of Supply
Officer in the Ministry of Health and Family Welfare, BCG Vaccine Laboratory, Guindy, Chennai
namely: 1.
Short title and commencement .- (1) These rules may be called the Ministry of Health and
Family Welfare, BCG Vaccine Laboratory, Guindy, Chennai, Supply Officer (Group ‘B’ Post),
Recruitment Rules, 2019.
(2)

They shall come into the force on the date of their publication in the Official Gazette.

2.
Number of post, classification, level in the pay matrix.- The number of post, its classification
and the level in the pay matrix attached thereto shall be as specified in columns (2) to (4) of the Schedule
annexed to these rules.
3.
Method of recruitment, age-limit, qualifications, etc.- The method of recruitment, age-limit,
qualifications and other matters relating to the said post shall be as specified in columns (5) to (13) of the
aforesaid Schedule.
4.

Disqualification.- No person,(a)

who has entered into or contracted a marriage with a person having a spouse living; or

(b)
who, having a spouse living, has entered into or contracted a marriage with any person,
shall be eligible for appointment to the said post:
Provided that the Central Government may, if satisfied that such marriage is permissible under
the personal law applicable to such person and the other party to the marriage and that there are other
grounds for so doing, exempt any person from the operation of these rules.
5.
Power to relax .- Where the Central Government is of the opinion that it is necessary or
expedient so to do, it may, by order and for reasons to be recorded in writing, in consultation with Union
Public Service Commission, relax any of the provisions of these rules with respect to any class or
category of persons.
6.
Saving .- Nothing in these rules shall affect reservation, relaxation of age-limit and other
concessions required to be provided for the Scheduled Castes, the Scheduled Tribes, the Other Backward
Classes, Ex-Servicemen and other special categories of persons in accordance with the orders issued by
the Central Government from time to time in this regard.

<!-- page 3 -->

Name of the
post.

Number
of post.

(1)
(2)
Supply Officer 1* (2018)
*Subject
to
variation
depending
on
workload.

Classificati Level in the
on.
pay matrix.

(3)
General
Central
Services,
Group ‘B’,
Gazetted,
NonMinisterial.

(4)
Level - 8,
(Rs. 47600151100) in
the pay
matrix

Whether
selection post
or non selection.
(5)
Not applicable

Schedule
Age limit for direct recruits.

Educational and other
qualifications required for direct
recruits.

(6)
Not applicable

(7)
Not applicable

<!-- page 4 -->

Whether
age
and
educational
qualificatio
ns
prescribed
for direct
recruits
will apply
in the case
of
promotees.
(8)
Not
applicable

Period of
probation,
if any.

Method
of
recruitment
whether by direct
recruitment or by
promotion or by
deputation/absor
ption
and
percentage of the
vacancies to be
filled by various
methods.

In case of recruitment by promotion or deputation or absorption,
grades from which promotion or deputation or absorption to be
made.

If
a
Departmental
Promotion
Committee
exists, what is
its composition

Circumstance
s in which
Union Public
Service
Commission
is
to
be
consulted in
making
recruitment.

(9)
Not
applicable

(10)
Deputation
(Including Short
Term Contract)

(11)
(12)
(13)
Deputation (Including Short Term Contract):
Not applicable
Consultation
Officers under the Central Government/ State Government/ UTs/ Statutory
with
Union
Bodies, PSUs, Universities, Recognised Research Institute:Public Service
(a) (i) Holding analogous posts on regular basis in the parent cadre/
Commission is
Department, or
necessary
(ii) With two years’ service in the grade rendered after appointment
while making
thereto on regular basis in Level-7 (Rs. 44900-142400) or equivalent in
appointment.
parent cadre or department,
or
(iii) With six years’ service in the grade rendered after appointment
thereto on regular basis in Level-6 (Rs. 35400-112400) or equivalent
in parent cadre or department,
and
(b) Possessing the following qualifications and experience(i)
MSc Degree in Microbiology or Bio-chemistry or BioTechnology or B.Pharma or B.Tech. (Bio-Technology) from a
Recognised University/ Institute.
(ii) Three years experience in handling of supply chain of a
Biologicals/ Pharamacuticals products from a recognised Institute.
Note 1: Period of deputation including period of deputation in another excadre post held immediately preceding this appointment in the same or
some other Organization/ Department of the Central Government shall
ordinarily not exceed three years.
Note2: The maximum age limit for appointment by deputation shall be
not exceeding 56 years as on the closing date of the receipt applications.
(No. A-12018/07/2017-EPI)
(Varinder Kaur Bhalla)
Under Secretary to the Government of India
