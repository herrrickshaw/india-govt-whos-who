---
doc_id: "aac8e0c04fa279dc"
source_url: "http://www.mib.gov.in/sites/default/files/2025-01/advisory-for-carriage-of-mandatory-channels.pdf"
ministry: "Information and Broadcasting (MIB)"
title: "Advisory for carriage of mandatory channels"
date: "2025-01"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ded7b536e0a9ddb6"
---

<!-- page 1 -->

Website Link: mib.gov.in

No. N-45001/10/2021-DAS
Government of India
Ministry of Information and Broadcasting
'A' Wing, Shastri Bhawan, New Delhi- 110001
Dated the °January, 2025
ADVISORY

The Ministry of Information and Broadcasting issue certificate of registration to
the Multi-System Operators (MSOs) and the Local Cable Operators (LCOs) (collectively
known as cable operators) under rules 11 C and 5 respectively, of the Cable Television
Networks Rules, 1994 (the Rules). Such registration is subject to adherence to the terms
and conditions stipulated therein which inter a/ia include compliance with the provisions
of the Cable Television Networks (Regulation) Act, 1995 (the Act) and the Rules.

2.

Sub-section (1) of section 8 of the Act empowers the Central Government to

notify the names of Doordarshan channels or the channels operated by or on behalf of
Parliament, to be mandatorily carried by the cable operators in their cable service
(mandatory channels) and the manner of reception and re-transmission of the said
channels.

3.

In exercise of these powers, this Ministry vide Notification No. S.O. No. 2693 (E)

dated 05.09.20 13 (the principal notification) had notified the list of mandatory channels
that are to be essentially carried by the cable operators on their cable TV networks.

4.

The principal notification has been subsequently amended to modify the list of

mandatory channels, the last such amendment having been made vide S.O. No. 292 (E)
dated 19.01.2024. Advisories to the cable operators have been issued from time to time
with instructions to ensure carriage of mandatory channels on their network.

5.

Now, in exercise of these powers, this Ministry vide Notification No. S.O. 325 (E)

dated 17.01 .202 5 has further modified the list of mandatory channels by way of

<!-- page 2 -->

modification of existing mandatory channels, viz. S No. 16, 21, 22, 23, 24 and 28 with
channels as under:
SN

Name of Channel

Genre

1

DD Assam

General Entertainment (Regional)

2

DD Odia

General Entertainment (Regional)

3

Sansad TV-i HID

News and Current Affairs (Lok Sabha)

4

Sansad TV-i

News and Current Affairs (Lok Sabha)

5

Sansad TV-2 HD

News and Current Affairs (Rajya Sabha)

6

Sansad TV-2

News and Current Affairs (Rajya Sabha)

6.

Further, vide above amendment, certain new channels have been added in the said

list of mandatory channels as under:
SN

Name of channel

Genre

1

DD National HD

General Entertainment (Hindi)

2

DD News HID

News and Current Affairs (Hindi)

3

DDSportsHD

Sports

4

DD India HD

News and Current Affairs (English)

7.

Accordingly, all cable operators are directed to carry the mandatory channels

appropriately in respective genre on their cable TV network.

8.

Any violation of section 8 of the Act shall invite such action as provided in therein

and the Rules framed thereunder as well as the terms and conditions stipulated in the
registration certificate, as the case may be.
-qjLrry

(Satbir Singh)
Under Secretary to the Govt. of India

To.
All MSOs/ LCOs
