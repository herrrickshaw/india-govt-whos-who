---
doc_id: "aa69af6c3cad988b"
source_url: "https://doj.gov.in/static/uploads/2025/09/3bec108f89ff760b9f0a7649002d03a7.pdf"
ministry: "Department of Justice (DoJ)"
title: "Appointment of Sh. Justice Sanjeev Sachdeva, Judge MP High Court as Acting Chief Justice of MP High Court (04.07.2024)"
date: "2024-07-04"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b35f4ab7c096e72e"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K. 11019/21/2024-USI/II
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House,
26, Man Singh Road,
New Delhi-11011.
Dated: 04th July, 2024.
NOTIFICATION
In exercise of the powers conferred by Article 223 of the Constitution of India,
the President is pleased to appoint Shri Justice Sanjeev Sachdeva, Judge of the
Madhya Pradesh High Court, to perform the duties of the office of the Chief Justice
of that High Court consequent upon appointment of Shri Justice Sheel Nagu, Judge
of the Madhya Pradesh High Court as the Chief Justice of the Punjab and Haryana
High Court.
11171°A '
(Jagannai Srinivasan)
Joint Secretary to the Government of India
Tele :011-23383037
To
The Manager,
Government of India Press,
Minto Road, New Delhi.

<!-- page 2 -->

-2No. K. 11019/21/2024-USI/II

Dated 04.07.2024.

Copy to:
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

Shri Justice Sanjeev Sachdeva, Judge of Madhya Pradesh High Court,
through Registrar General, Madhya Pradesh High Court, Jabalpur.
The Secretary to the Governor, Madhya Pradesh, Bhopal.
The Secretary to the Chief Minister, Madhya Pradesh, Bhopal.
The Secretary to the Chief Justice, Madhya Pradesh High Court, Jabalpur.
The Chief Secretary, Government of Madhya Pradesh, Bhopal.
The Registrar General, Madhya Pradesh High Court, Jabalpur.
The Accountant General, Madhya Pradesh, Bhopal.
The President's Secretariat, (CA.II Section), New Delhi.
PS to the Principal Secretary to the Prime Minister, PM's Office, New Delhi.
Registrar (Conf.), 0/o the Chief Justice of India, 07 Krishna Menon Marg,
New Delhi.
PS to the MoS (I/C) L&J / PPS to the Secretary (Justice).
Technical Director, NIC, Department of Justice, with a request to upload the
notification on the website of the Department (www.doj.gov.in).

21041
(Prem Chand)
Under Secretary to the Government of India
Tele :011-23382978
