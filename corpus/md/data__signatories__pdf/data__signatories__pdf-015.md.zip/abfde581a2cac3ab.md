---
doc_id: "abfde581a2cac3ab"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/f6d73451a1a5d624c63a06500ea6b218.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Circulation of draft document on BMMP & FDI for Inputs/Comments from General Public/ Stakeholders - Circulation of Policy & Procedure Manucal, SPMU, BMMP Technical Manual"
date: "2019-05-24"
pages: 64
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "25705e0692d3393b"
---

<!-- page 1 -->

Preface

1|Page

<!-- page 2 -->

Foreword

2|Page

<!-- page 3 -->

Index
Part A: Policy and Procedure Manual, State Program Management Unit ............................................. 6
1. Background ........................................................................................................................................... 7
2. Operations Summary ............................................................................................................................ 8
3. Objective of SEMU ................................................................................................................................ 8
4. Equipment Cell Structure, Facility etc.................................................................................................... 9
4.1 Introduction Unit........................................................................................................................... 9
4.2 Maintenance Load under Equipment Centre.............................................................................. 10
4.3. Facilities to be planned at all the Divisional /District Equipment Cell ...................................... 11
4.4. Tools & Equipment .................................................................................................................... 11
5. Human Resources ................................................................................................................................ 12
6. Activities of the Cell ............................................................................................................................. 13
6.1. Maintenance Activities .............................................................................................................. 13
A. Breakdown Maintenance .......................................................................................................... 13
B. Preventive Maintenance- PM .................................................................................................... 13
6.2. AMC and CMC Management ..................................................................................................... 14
6.3. Warranty management ............................................................................................................. 14
6.4. Training Activities ...................................................................................................................... 14
7. Equipment requirement for each Workshop ..................................................................................... 16
8. Disposal of obsolete and condemned equipment ............................................................................... 18
Part B. Biomedical Equipment Management & Maintenance Program: Technical Manual .................. 19
Introduction ............................................................................................................................................. 20
I Implementation Plan ............................................................................................................................. 21
1. Technical Infrastructure ................................................................................................................... 21
i. Repair Workshop ........................................................................................................................ 21
ii. Tools and test equipment .......................................................................................................... 21
iii. Spare parts ................................................................................................................................ 22
iv. Operation and Service Manuals ................................................................................................ 22
2. Tagging of medical Equipment ........................................................................................................ 22
3. Call Centre ........................................................................................................................................ 22
4. Software/Dashboard ........................................................................................................................ 23
i. Work Order management .......................................................................................................... 23
ii. Equipment Tagging .................................................................................................................... 23
3|Page

<!-- page 4 -->

iii. Invoicing .................................................................................................................................... 23
iv. Dashboard ................................................................................................................................ 23
v. Mobile ....................................................................................................................................... 23
5. Training ............................................................................................................................................ 24
Gantt chart .................................................................................................................................... 24
II Standard Operating Procedure (SOP) ................................................................................................... 25
Organogram ..................................................................................................................................... 26
1 Equipment tagging ............................................................................................................................ 27
2 Complaint log .................................................................................................................................... 28
3 Breakdown Maintenance .................................................................................................................. 29
4. Preventive Maintenance & Calibration ............................................................................................ 30
5. User Training .................................................................................................................................... 31
6. New Equipment Installation ............................................................................................................. 32
7. Biomedical Equipment Not Found during Preventive/Corrective Maintenance ............................. 33
8. Warranty / AMC Management ........................................................................................................ 34
9. Condemnation of Biomedical Equipment ........................................................................................ 35
10. Process the Bills for Payment and Documentation ........................................................................ 36
11. Adverse Event Reporting (Materiovigilance) ................................................................................. 37
III Training Manuals ................................................................................................................................ 38
1. Objectives of the Program ................................................................................................................ 38
2. Installation and Commissioning ...................................................................................................... 38
3. AMC/CAMC/Warranty Management ............................................................................................... 39
4. User Training .................................................................................................................................... 39
5. Break down Maintenance ................................................................................................................ 39
6. Preventive Maintenance (PM Service) ............................................................................................. 39
7. Calibration Services .......................................................................................................................... 40
8. Condemnation .................................................................................................................................. 40
9. SMS & email Feedback at the time of Registering Breakdown Call ................................................. 40
10. Documents Required to Process the Quarterly Invoice ................................................................. 41
Other Reports to be submitted ......................................................................................................... 42
Reports to be kept in each Health Facility ........................................................................................ 42
IV. Oversight Committee ......................................................................................................................... 43
V Reporting Formats ................................................................................................................................ 44
4|Page

<!-- page 5 -->

Equipment Registration Form ........................................................................................................... 44
Certificate of Medical Equipment Tagging Status ............................................................................. 45
LIST OF EQUIPMENT – TAGGED AS PER RFP .................................................................................... 46
Recommendation for Beyond Economical Repair (BER) ................................................................... 47
Format for Equipment Not found during Preventive Maintenance ................................................. 48
Service Report ................................................................................................................................... 49
Training Feedback Form .................................................................................................................... 50
Training Attendance Record ............................................................................................................. 51
SUMMARY – USER TRAINING CONDUCTED ..................................................................................... 52
SUMMARY – EQUIPMENT NEWLY TAGGED ...................................................................................... 53
WALKTHROUGH REPORT .................................................................................................................. 54
LIST OF EQUIPMENT NEWLY TAGGED .............................................................................................. 55
Breakdown Feedback Report ........................................................................................................... 56
List of equipment out of warranty .................................................................................................... 57
List of Preventive Maintenance ........................................................................................................ 58
List of equipment – tagged as per RFP ............................................................................................. 59
ANNEXURE-I: Inspection of new equipment. Devices ............................................................................ 60
Annexure-II: Disposal of condemned and obsolete equipment ............................................................. 61
ANNEXURE-III: Samples of various sticker designs ................................................................................. 62
List of Contributors .................................................................................................................................. 64

5|Page

<!-- page 6 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT

Part A:
POLICY AND PROCEDURE MANUAL
STATE EQUIPMENT MANAGEMENT UNIT
For inhouse implementation of Biomedical
Equipment and Maintenance Program (BMMP)

6|Page

<!-- page 7 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT

1. Background
There was no proper facility in the public sector for maintenance of health care equipment in the states till
a couple of years ago. Hon’ble Prime Minister had observed that many equipment in hospitals and other
health facilities are either unused or there is no maintenance resulting wastage of resources. He directed
that Ministry may consider either maintenance or management contract along with purchases or outsource
maintenance after the guarantee period.


To address this, MoHFW organized consultations with officials from states to devise appropriate
mechanisms to ensure that medical equipment already purchased are properly maintained. An
extensive exercise was undertaken to map the inventory of all Bio-medical equipment including
their functionality status. The mapping was undertaken in 29 States under the guidance of
NHSRC. 7,56,750 no. of equipment in 29,115 health facilities costing approximately Rs 4564
Crores were identified. The mapping data State wise is available on NHSRC website



Equipment in range of 13% to 34% were found dysfunctional across states.



Comprehensive guidelines were designed on Biomedical Equipment Management and
Maintenance Program (BMMP), linked with uptime of equipment (95% in District Hospitals, 90%
in Community Health Centres, and 80% in Primary Health Centres). The guidelines along with the
model tender document were developed in 2014.
Under BMMP, support is being provided to state governments to outsource medical equipment
maintenance comprehensively for all its machinery across all the facilities.



Subsequent to inventory mapping, RFPs/tenders were rolled out to award maintenance contract for
the respective states.



20 States in PPP mode in the state of Andhra Pradesh, Arunachal Pradesh, Assam,
Chhattisgarh, Jharkhand, Kerala, Madhya Pradesh, Maharashtra, Meghalaya, Mizoram,
Nagaland, Puducherry, Punjab, Sikkim, Telangana, Tripura, Rajasthan, Uttar Pradesh,
West Bengal, Jammu and Kashmir.

Presently, an asset base of approx. Rs 2416 Crores worth of equipment (as per initial mapping) is being
served under the program in 16 states in PPP mode and four more states have outsourced the services. In
short time of less than 6 months of award of contract, dysfunctional equipment worth nearly Rs 555 Cr was
made functional, with an investment of 119 Crore only in the first year. It is expected that with more states
joining the BMMP program this year, a total of 900 Crores worth of dysfunctional equipment is expected
to be made functional by the end of this financial year.
The implementation of Biomedical Equipment Management and Maintenance Program (BMMP) has
helped in providing assured quality diagnostics services in public health facilities, thereby reducing cost
of care and improving the quality of care for poor patients
6 States/UT have implemented the program in inhouse mode. However, as there is no guidelines on
implementation in in-house mode. The filed review of ongoing BMMP program highlighted that there is
lack of implementation guideline for Medical Equipment Maintenance and Management program at State
level. The draft a revised guidance document for inhouse as well as PPP Model of implementation of
BMMP Program has been developed to support State for smooth implementation and monitoring of
services.

7|Page

<!-- page 8 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT
With this mandate the HCT Division has drafted the guidelines for implementation and formation of State
Equipment Management Unit for inhouse management of BMMP as well as monitors the program in PPP
Mode also. With the formation of SEMU (State Equipment Management Unit) a beginning will be made
towards addressing the maintenance issues of Medical Equipment. Costly & valuable medical equipment
are imported with hard earned foreign exchange and used for some time before being discarded for want of
maintenance. It is intended to start the unit with a mandate to be an independent unit to undertake entire
equipment maintenance issues independently. The mandate of SEMU will be to oversee the Medical
Equipment Maintenance and Management including Preventive Maintenance and calibration of all the
Medical Equipment.

2. Operations Summary:
The SEMU will have the following functions:
a. Follow the policy outlined in Annexure I for Inspection of new equipment. Devices used within the
Public Health System in the entire state will be inspected prior to patient use to ensure safe and
effective operation.
b. Maintenance of Medical Equipment and proper usage of new equipment.
Many medical equipment can be maintained in- house. Some of the specialized equipment viz. CT scanner,
MRI, Blood Gas Analyzer, Auto analyzer, Laparoscopes etc. will need company maintenance for which
AMC/CAMC will need to be signed. Unit will maintain the basic medical equipment for repair and
Calibration at the central workshop at the head office, the divisional workshops at four divisions and in the
District hospital Workshops and appropriately will also maintain the equipment at hospital by sending
repair team. Medical equipment of different District hospital and hospital which the unit cannot repair due
to non-availability of spare parts, maintenance manual & circuit diagram and technical skill will be repaired
through private companies/vendors under the supervision of Biomedical Engineer at the head office and
other divisional offices.
Problem has multiplied due to procurement of medical equipment from different countries of different
makes and brands without supply of spare parts, operation manual and circuit diagram from the supplier
and manufacturing companies.
In District hospital & other institution, only technician and instrument care taker (ICT) are responsible to
maintain all medical equipment. But actually ICT play a role as a custodian of medical equipment. There
is lack of basic medical equipment repair toolkits, spare parts and workshop facility at division and district
level. Secondly, spare parts, calibration and troubleshooting tools for repair of medical equipment are also
not available. So in most of the cases, ICT become helpless to repair simple types of equipment due to want
of spare parts and workshop facilities. The SEMU will appoint Certified Technicians and Engineers for
maintenance and calibration.

3. Objective of SEMU:
1. To do acceptance and inspection tests for new equipment prior to the equipment being used on any
patient.
2. To function as Asset Management Centre for all Medical Equipment with their functional status.
8|Page

<!-- page 9 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT
3. To assist in the repair and maintenance of hospital/electro-medical equipment used for diagnostic,
therapeutic and patient care in hospital and medical institutions.
4. To train technical personnel to undertake the repair/maintenance job by imparting regular training to
different categories and fields.
5. To train user of the medical equipment in its proper care and for preventive maintenance.
6. To assist in calibration and installation of medical equipment.
7. To collaborate and assist in repair activities of medical equipment at different District hospital etc.
8. To assist procurement agencies in the field of repair, maintenance services and giving technical
support for procurement of general and sophisticated medical equipment.
9. To assist for detection and declaration of medical equipment which is not feasible for repair and the
unit will gives further technical assistance to declare condemnation of the medical equipment.
10. The SEMU will function by establishing Equipment Cells at various levels of healthcare facilities.

4. Equipment Cell Structure, Facility etc:
4.1 Introduction:
SEMU will be an in-house system for medical technologies management equipped with experienced
engineers and technicians trained in multi-modality. It will provide hands-on experience of supporting
technical activities per annum comprises preventive, breakdown, performance verification services
equipment of various types. Continuous professional training programs, e-training modules for the technical
staff across from the level of Sub center up to the level of District hospital. It will store technical and
operation manuals of various equipment. The key priorities will be to ensure the best supplies of cost
effective spares, tools etc. for the better life cycle of equipment. The unit will establish IT based dashboard
for medical technologies asset management. It will include Breakdown call management, Preventive and
Predictive maintenance, Calibration schedule record etc. It will ensure effective user training modules and
programs covering a wide array of life support equipment. The unit will have in-house specialized
workshops for calibration, PCB repair, Flexible Endoscope, Dental Hand piece, Pipette calibration etc.
The briefed structure is as below:

S.no.

Designation

Number

1

State Equipment Cell - At capital headquarter

1

2

Divisional Equipment Cell – At all the divisions of the
state located in District Hospitals of the Divisional Head 01 each per division
Quarter/Govt. District hospital

3

District Equipment Cell- In all the district hospital

9|Page

01 each per district

<!-- page 10 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT

4.2 Maintenance Load under Equipment Centre
There are about <INSTERT NUMBERS> Medical Institutions in Public Health Sector in <insert name
of the State> as below:
1.
2.
3.
4.

District Headquarter Hospitals. -------------------------------------DD
Sub Divisional Hospitals ---------------------------------------------- SS
Community Health Centers ------------------------------------------CC
Primary Healthcare Centers------------------------------------------PP
TOTAL

This center will provide maintenance services to these institutions as and when asked for. The center
will be able to provide maintenance services for basic health care equipment like X-ray machine, ECG,
Autoclave, Portable Sterilizers, Distill Water Plant, Suction Apparatus, Anesthesia equipment, O.T.
Light, O.T. Table, Dental Chair, Microscope, B.P. Instruments etc. This center will coordinate but not
handle directly sophisticated and specialized equipment like Nuclear Medicare equipment, Gamma
Camera, Auto Analyzer, Angiogram, Scanner, Laser equipment, CT Scanner, MRI etc.
State Equipment Management Unit - Will be headed by Chief Biomedical Engineer with an
experience of 15 years or more and will be located in Capital City in the Central Workshop which will
be located preferably in Head quarter. He will be assisted by a Biomedical Engineer having 05 years of
experience and a team of Certified Technicians.
State Equipment Cell will be the administrative head of State Equipment Management Unit and will
be responsible for entire equipment management including the following:
i. Assisting in Drafting of Technical Specifications.
ii. CMC/AMC Management.
iii. Monitoring of the functional status of all the equipment in the state health facilities. Will submit
fortnightly report on Functional and Calibration status of all the equipment in the state. Shall
also be responsible for pending maintenance of all the equipment in the state.
iv. Shall submit acceptance report of all the new equipment installation and will facilitate the
installation support requirement including the site readiness and other pre installment
requirements.
v. A Centralized Dash board for Equipment Maintenance and Management will be available in
the SEMU. SEMU shall be responsible for maintaining the Dash Board containing the
inventory of all the equipment, with warranty, calibration, preventive maintenance and
functional status of all the equipment in the state. CDAC has made such a dashboard for the
state of Madhya Pradesh and Rajasthan and the same may be customized for in-house
maintenance for all the equipment.
Divisional Equipment Cell - Will be available in Divisional Workshop and will cater to average of six
districts each. This will be located in the District Hospital located in Divisional Headquarters.
These workshops will be having commonly used necessary spare parts and technical support manuals.
The Divisional Workshop will be headed by Divisional Workshop Superintendent /Divisional
Biomedical Engineer (with 10 years of experience) and 02 Biomedical Engineers and 2 nos. of
technicians each (Certified Medical Equipment Technician).

10 | P a g e

<!-- page 11 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT
District Equipment Cell- Will be available in the Electro-Medical workshops in districts and will be
headed by District Workshop Superintendent (Certified Biomedical Engineer with certification in any
one advanced equipment skill with 07 years of experience) with 5 nos. of technical manpower each
(Certified Medical Equipment Technician). These workshops will be engaged to look after the
maintenance, repair and services of medical equipment in the District Hospital as well as provide
assistance to all the public healthcare facilities in the district.
The District Equipment Cell will be providing the support to the technicians at the CHC and PHC
Level.
The deployment at the CHC and PHC Level will be as below:
Certified Medical Equipment Technician at CHC and PHC as per the requirement
Certified Medical Equipment Technician at PHC- 01 per PHC. The technicians at PHC will be
responsible for equipment at Sub Centre also.

4.3 Facilities to be planned at all the Divisional /District Equipment Cell:
1. Main Building, floor area: 15,000 Sq. ft. with provisions as below:
a.) Workshop and Store area for large equipment.
b.) Office, Stores of accessories and spares & Lecture room.
2. Office Building- 1500 Sq. ft.
3. Transport Vehicles: A mobile van will be placed at all the locations of Workshops (preferably on
rented basis)- Total of <insert numbers> vans will be required. The Equipment Van will carry out
the following functions:
a.) These vehicles will carry the Technicians/Engineers to the maintenance/ installation site.
b.) Will be used as mobile repair workshop as well as preventive maintenance of the equipment.
c.) Will pick up any equipment that will be required to be carried at the workshop for repairs.

4.4

Tools & Equipment:
The Mechanical Section will be equipped with lathe and grinding machine, mechanical hand tools,
power tools and electronic testing and calibration equipment, Instruments. Besides a good number of
technical books on different engineering fields will also be made available.
Workshop Facilities: Workshops will be planned as below:
i) Central Workshop- This will have all the repair, maintenance and calibration facilities. All the
equipment that can’t be repaired at the divisional level will be sent to Central Workshop for the
same. This will also be the administrative head quarter for all the equipment related issues.
ii) Divisional Workshop- Each Divisional Workshop will cater to 5-6 districts on an average. This
will have all the facilities except calibration facilities for specialized equipment.
iii) District Workshop- Each District Hospital will have an Equipment Repair Workshop and will cater
to all the healthcare facilities in the district viz. DH, CHC and PHC. The equipment which can’t be
repaired at the district Workshop will be transferred to Divisional Workshop for repairs.
All the workshops will have the following sectionsa) Mechanical Section.
b) Electrical Section.
c) Electronics Section.
d) Air Condition & Refrigeration Section.
e) X-Ray Section

11 | P a g e

<!-- page 12 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT
f) Optical Section.

5. Human Resources:
Recommended Technical Manpower:
a.) The Technical Human Resources for State Equipment Cell will be as below:
GM (Equipment)/Chief Biomedical Engineer/State Biomedical Engineer-01 each
Essential Qualification - B.E.
Minimum Experience of 15 years and preferably having Management/ Hospital Administration
qualification.
Biomedical Engineers-02 each
Essential Qualification-B.E.-Biomedical Engineering - Minimum 10 Years of experience.
Certified Medical Equipment Technicians - 05
Should be certified by Health Sector Skill Council in Basic Clinical Equipment Maintenance Skills or
Certified by the OEM/Manufacturer for common basic medical equipment.

b.) The Human Resources for Divisional Equipment Cell will be as below:
Divisional Biomedical Engineer—01 each per division

Essential Qualification- B.E. - Biomedical Engineering
Minimum Experience of 10 years
Biomedical Engineer-02 each per division
Essential Qualification- B.E. - Biomedical Engineering with Minimum 07 Years of experience.
Certified Medical Equipment Technicians- 2

c.) The Human Resources for District Equipment Cell will be as below:
District Biomedical Engineer - 01 each per district
Essential Qualification- B.E. - Biomedical Engineering
Minimum Experience of 10 years
Biomedical Engineer- 02 each per district
Essential Qualification- B.E-Biomedical Engineering with Minimum 05 Years of experience.
Certified Medical Equipment Technicians- 05
District Equipment Cell will also support and supervise the deployment of the Medical Equipment
Technicians at CHC and PHC level as below:

d.) Certified Medical Equipment Technicians- 01 each in all the CHC.
e.) Certified Medical Equipment Technicians- 01 each in all the PHC. The Technicians at the PHC will
support all the SC attached to it. The Electricians may be trained and Certified as Medical Equipment
Technicians for the Medical Equipment Technicians positions at the SC and PHC level

12 | P a g e

<!-- page 13 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT

6. Activities of the Cell:
6.1 Maintenance Activities:
The flow of the activities for maintenance will be as below:
Initiating a service request- The Service Request by the facility will be raised as below:
a.) For District Hospital- CMO/ Hospital Manager (HM)/End user
b.) For Sub District Hospital- CMO/ Program Manager (PM)/Hospital Manager/End user.
c.) For Community Health Centers- MOIC/Block Program Manager (BPM)/End user.
d.) ADMO/SDMO & MOIC will be the accountable entities and HM, PM and BPM will be their
authorized representatives for communicating to the Equipment Cell.
e.) For PHC and SC- Facility in-charge will be the accounting as well as Communicating entities.

A. Breakdown Maintenance
1. The facility raises a request through a tollfree number. The request is forwarded to the
Divisional/District Biomedical Engineer of the division or the Biomedical Engineer i/c of the
District hospital and the job is allocated to appropriate Biomedical Engineer with SMS
acknowledged to all concerned.
2. The respective Biomedical Engineers raises a job number and allocates the job to the technician
with an intimation to Head Office.
3. Technician attends to the request and submits a closure report to the respective Biomedical
Engineer. If he is unable to solve the problem Biomedical Engineer will assist him further. The
closure report will be submitted to the facility as well as to the Head Office. In case the problem
is not resolved by the divisional office the same will need to be highlighted to the Head Office
to the General Manager Equipment/State Biomedical Engineer/Chief Biomedical Engineer.
The Technician attaches a tag with date of repair or if it needs to carry to workshop the tag
indicates-Not working with date.
4. General Manager Equipment/State Biomedical Engineer/Chief Biomedical Engineer submits a
monthly report on the status of the equipment to the top management classifying: Functional
Equipment, Non-Functional Equipment needing replacement, Equipment under repairs.

B. Preventive Maintenance- PM
1. The Divisional Biomedical Engineer submits a Planned Preventive Maintenance Programme
and schedules dates and then allocates District BME/Facility Technician for the job and sends
the copy of the schedules to the health facilities under his jurisdiction as well as to the General
Manager- equipment at HO and the schedule is uploaded on the Dashboard so that all the
stakeholders are aware about the PM and time planning is done accordingly. PM includes
appropriate calibration of the equipment.
2. The facility intimates all the technicians and staffs to co-operate with the preventive
maintenance.
3. The technician undertaking the preventive maintenance tags the equipment with date of PM
and also indicates the date when next PM is due.
4. During PM the technicians also carries out breakdown maintenance if the same is advised to
him by the facility.

13 | P a g e

<!-- page 14 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT
5. The functional status of all the equipment is submitted by the Divisional Biomedical Engineer
to the GM- Equipment.
6. GM-Equipment combines the status of Breakdown as well as the Preventive Maintenance and
submits the functional status to the top management every month.

6.2 AMC and CMC Management1. The specialized and lifesaving critical equipment will require AMC- Annual Maintenance Contract
without spares and CMC- Comprehensive Maintenance Contract with all the spares included.
2. The AMC and CMC will be monitored centrally. It will be initiated by the Divisional Biomedical
Engineer based on the assessment as to whether to go in for CMC or for AMC. The Divisional
Biomedical Engineer will initiate the process at least 30 days in advance of the date of expiry of
the warranty period.
3. The procurement division will procure the equipment with either 2 years warranty and five years
CMC (For equipment costing less than 1 Crore) OR with 5 Years warranty and 5 years CMC (for
equipment costing more than one crore). In both the cases the post warranty AMC/CMC rates are
approved and the supplier will have to sign contract based on approved rates only. Post warranty
the rates can’t be modified by the vendor unless there is a clause to do so.
4. The Divisional Biomedical Engineer will examine the AMC/ CMC rates with respect to the
approved rates and will send the contract for formal approval to the GM-Equipment.
5. GM- Equipment will examine the same and will sign the contract and send the same back to the
Divisional Engineer.
6. The Divisional Biomedical Engineer can also go in for per call basis of maintenance.

6.3 Warranty management1. The Divisional Engineer will update the arrival of any new equipment into the Equipment Asset
Register on the Dashboard which will be maintained at the HO.
2. After entry into the Asset Register he will make Preventive Maintenance schedules for the vendor
and send an intimation of the schedules.
3. If the vendor fails to respond to the PM schedules he may be issued a show cause notice and on
repeated violations of three times the HO may initiate actions to forfeit his performance security
and initiate a show cause notice for blacklisting him for two years. If he fails to respond he may be
issued a blacklisting notice and be barred for participation in the future procurements.
4. The same applies for breakdown maintenance if the vendor fails to attend to the service breakdown
requests his performance security may be forfeited if the equipment is lying unrepaired for days
provided in the contract. He may be subsequently issued a show cause notice for blacklisting
followed by barring him for further procurements.

6.4 Training Activities:
Biomedical Engineers of the unit will be simultaneously engaged in developing health care manpower
to fulfill needs of the public healthcare facilities.
The following regular Training Modules (3 months each) will be available at this center. There will be
certification provided jointly by GM-Equipment and Health Sector Skill Council.



14 | P a g e

Training modules for Laboratory Technicians
Training modules for end users- Junior Doctors/Nursing staffs.
Training modules for Store Personnel for Inventory Management.

<!-- page 15 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT



Training Modules for Medical Equipment Technicians- Basic
Training Modules for Medical Equipment Experts- Advanced Skills

Objective of Training:
1. To develop skill and competency among users of medical equipment.
2. To acquire knowledge in detection of trouble shooting.
3. To carry out preventive maintenance.
4. To apprise communication method among user of medical equipment for
carrying out maintenance work.
5. To carry out survey, inspection and preparation of inventory for medical
equipment.
6. To impart skills by on the job training for technicians and engineers and be
certified for the acquired skills.
Training Curriculum for orientation of engineers and technicians:
All the Technicians joining the cell will have to complete the orientation program.
The following are included in the curriculum:
1.
Basics of Electrical / Mechanical Engineering.
2.
Workshop practice and Mechanical maintenance.
3.
Biomedical Electronics and Applied Physics.
4.
Basics of Cold Chain Equipment
5.
On job training in operation and maintenance of basic medical equipment.
6.
On job training for repair and maintenance of SNCU Equipment.
7.
On the job training for repair and maintenance of Basic Clinical Equipment8.
Medical Equipment Technician- Certification by Health Sector Skill Council.
The centre will be equipped with modern training aids like projectors (Slide and Overhead), Audio-Visual
Equipment and these will be used during training programme. In addition, occasional field trips to medical
institutions will be conducted for the trainees.

Acceptance Test and Inspection of new equipment prior to use on patient or in a clinical lab.
The cell will follow the policy and procedures for any new/ demo/ clinical research equipment being put to
use as per safe practices of usage.

15 | P a g e

<!-- page 16 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT

7. Equipment requirement for each Workshop: (Each center will be equipped
with five work benches)
The following equipment will be required for the each workshop at the Divisional and District level
workshops in Phase-1
S/N
01
02
03
04
04-01
05
06
07
08
09
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

DESCRIPTION
Digital Multimeter- Bench-top
DC Power Supply
Variac
Oscilloscope
Scope meter (OPTIONAL)
Electrical Safety Analyzer (OPTONAL)

Unit Price INR
5000
2500
1500
50,000
2,50,000
1,50,000

QTY
05
05
05
01
01
01

Amount INR
25,000
12,500
7,500
50,000
250,000
150,000

Multipara
Patient
Simulator
2,00,000
01
2,00,000
(OPTIONAL)
ECG Simulators
10,000
01
10,000
BP Simulator
10,000
01
10,000
Tachometer
5,000
01
5,000
Humidity and Temperature meter
1,000
01
1,000
Lux Meter & Irradiance Meter
30,000
01
30,000
Precision Weight Set
5,000
01
5,000
Multipurpose Tool Kit with Drill Machine
5,000
01
5,000
with 10 piece Hex Wrench Set
Electro Mechanical Tool Kit
1500
05
7500
Table Lathe Machine
5000
01
5000
Grinder / sharpener
5250
01
5250
Power Drill
1000
01
1000
Extension Boards
250
05
1250
SPARES & CONSUMABLES
Halogen Bulbs
500
10
10,000
Universal Coaxial Adaptor Kit
400
10
4000
Coaxial Adaptor Connector Set
200
10
2000
Antistatic Wrist strap
200
10
2000
Complete Grounding Kit
500
10
5000
Basic Audio Video Tool Kit
500
05
2500
Compression Termination Kit
2500
01
2500
Assorted Fuses
500
10
5000
Assorted Resistor
500
10
5000
Assorted Capacitors
500
10
5000
Assorted Transistors, ICS etc
20000
01
20000
Miscellaneous
20000
01
20000
Technical Books and Manuals
20000
01
20000
Biomedical Equipment Field Tool Kit
5000
01
5000
with portable multimeter
Healthcare Product Management System
01
2,50,000
Database Annual Membership
TOTAL INR per center
Rs 3,37,000/----------------------------------------------------------------------------

16 | P a g e

<!-- page 17 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT
OPTIONAL FOR CENTRAL WORKSHOP AT HEAD QUARTER – Rs 6,00,000
Field Kit for each technical staff
Total budget required for equipment:
For Divisional/District workshops @ 3,37,000/- each x no. of Workshops- XXXXXX
Additional for Central Workshop
--------------------------------------------- 6,00,000
(This will be extended for other workshops during next financial years)
Field Engineers Toolkit – 5,000 x no. of BME/Technicians----------------- YYYYYY
Healthcare Product Management System Database
------2,50,000

Equipment requirement Phase-2: It is proposed to upgrade the workshops during next five years with
additional facilities as given below:
EQUIPMENT REQUIREMENT PHASE-2
The following equipment will be required for the up-gradation of workshops during next 5 years for eight
identified Divisional Workshops for States having 40 districts. For districts having more than 40 or less
than 40 the numbers may be reduced on pro rata basis.
S/N
DESCRIPTION
Unit Price- INR
QTY Amount-INR
01
Scope meter
2,50,000
08
20,00,000
02
Electrical Safety Analyzer
1,50,000
08
12,00,000
03
220 V , 1A Source Current
2,000
08
16,000
04
Ultrasound Safety Tester with all
1,80,000
01
1,80,000
accessories[ At HO]
05(A) Universal Patient Simulator
1,80,000
08
14,40,000
05(B) Calibrated Fingers set for SPO2
30,000
08
2,40,000
06
Defibrillator Analyzer[At HO]
2,40,000
01
2,40,000
07
ESU Analyzer[At HO]
2,40,000
01
2,40,000
08
Infusion Pump Analyzers[At HO]
1,20,00
01
1,20,000
09
Ultrasound Wattmeter[HO]
75,000
01
75,000
10
Digital Pressure Meters
50,000
08
4,00,000
11
Gas Supply Fitting Kit
3,000
08
24,000
12
Medical Gas Outlet Kit
3,000
08
24,000
13
Ventilator Analyzer[At HO]
6,00,000
01
6,00,000
14
Gas Calibration Flow meter
60,000
08
4,80,000
15
Adult Lungs Simulator
60,000
08
4,80,000
16
Pediatric Lungs Simulator
60,000
08
4,80,000
17
Oxygen Analyzers
40,000
08
3,20,000
18
Ultrasound Phantom[At HO]
2,50,000
01
2,50,000
19
X-Ray meters with all accessories
3,00,000
01
3,00,000
[At HO]

TOTAL INR

17 | P a g e

Rs 91,09,000/-

<!-- page 18 -->

POLICY AND PROCEDURE MANUAL: STATE EQUIPMENT MANAGEMENT UNIT

8. Disposal of obsolete and condemned equipment
The disposal of condemned and obsolete equipment will be made as per the attached guidelines in
Annexure- II.

18 | P a g e

<!-- page 19 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Part B:
Biomedical Equipment Management &
Maintenance Program:
Technical Manual for implementation in PPP
mode

19 | P a g e

<!-- page 20 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Introduction
Medical device availability and upkeep is one of the key interventions for mass access to diagnostic,
preventive, assistive and therapeutic services. Inventory mapping of medical device is the first key step in
situational analysis and formulation of next stride for medical device management. On completing
inventory mapping in approximately 29 States/UTs which have done the inventory mapping, it was found
that Government Hospitals have around 13-34% of medical device dysfunctional. This amounts to INR
4,500-6,000 Crores worth of medical inventory lying idle, large proportion of it due to small problems.
A Medical Device may vary from a simple instrument to complex implants, as defined by WHO and
IMDRF. However, engaging trained engineering human resources, adequate to provide asset management
and maintenance for the entire medical devices in the state both in terms of availability and feasibility is a
challenge.
To address this, MOHFW organized consultations with officials from states to devise appropriate
mechanisms to ensure that medical device remain functional. Based on best practices, it was felt that
outsourcing of this activity with payment linked to service delivery would improve time bound maintenance
service which was named as Biomedical Equipment Management and Maintenance Program (BMMP).
BMMP is an initiative by the Ministry of Health Family Welfare, Govt. of India under which support is
being provided to state governments to outsource medical equipment maintenance comprehensively for all
facilities. The guideline with model RFP document was disseminated to states on 16th February 2015. The
extent of financial support is based on actual tendering process subsequent to state wide inventory mapping
and is largely dependent upon Equipment Density, Current Dysfunctional rate and geographical constraints
in a state. The inventory mapping exercise is also supported by the central government and is completed in
majority of states.
Two years since the first state launched the program of Biomedical Equipment Management & maintenance
Program, it is about time that we strengthen our monitoring mechanism. With this objective, the technical
manual is intended to streamline the implementation plan across states.

20 | P a g e

<!-- page 21 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

I Implementation Plan
The implementation plan of Biomedical Equipment Maintenance Program intends to break each strategy
into identifiable step and suggest when each step would be completed. A maintenance strategy includes
procedure for corrective and preventive maintenance and its technical inspection on completeness. Such
inspections shall ensure that equipment are operating correctly and is safe for user, patient, public in
general and the environment.
This section is important for review of service provider’s performance at the implementation stage.

1. Technical Infrastructure
The infrastructure required for Biomedical Equipment Maintenance Program has number of requirements
including workshop, tools, test equipment, spare parts and operation & service manual.

i. Repair Workshop
When service provider plans for implementing the program, the location for maintenance workshop is to
be considered critically. There would be mainly two kinds of equipment, firstly like X-Ray, laboratory
analysers, etc. where maintenance would be only possible on site. Secondly smaller equipment which would
be transported to the workshop for maintenance. While there is a need for transporting of medical devices,
the service provider must also ensure that no equipment is transferred across health facilities to meet
requirements at random as this could disturb patient care and planning. On need basis service provider is
also expected to setup satellite workshop at remote location to meet frequent failures.
A good workshop should be clean, well-lit and organised. It should have proper availability required for
equipment maintenance like electricity, work stations, store for spare parts and test equipment. Workshop
is also expected to have provision like electrostatic workbench/testbench, pneumatic outlets etc.
The workshop is also expected for demarcated areas like:
A. Receipt and despatch area should be suitably equipped for the handling and storage of components
and materials.
B: Storage rooms and/or areas should be furnished as required for the storage of items such as:
- working spare parts
- consumable items (such as gaskets, bolts and nuts, etc.)
- Chemical products (for analyser testing, etc.).
C: Standards equipment room (Cold room) should house all special tests, measuring
equipment/analysers and calibration standards. The workshop can also function as an office for
documentation, record keeping, operation and service manuals, etc.

ii. Tools and test equipment
Human resource employed by the service provider are of limited use, if they are not equipped and trained
to use proper tools and test equipment. Proper usage of the equipment will ensure reliability, accuracy and
safety for the user and al the stakeholders.
The basic set of such tool will include voltmeter, weight &temperature measuring devices, resistance and
capacitance substitution box and electrical safety meter. Middle ranged tool kit may include physiological
simulator, electrosurgical unit and safety analyser. These test equipment needs to be stored in good
condition, calibrated regularly and repaired as required.

21 | P a g e

<!-- page 22 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual
Some of the test equipment which are expensive to maintain and procure may be used on sharing/renting
basis for the services or as and when required. Without which, it’s not appropriate to take responsibility of
maintaining that equipment.

iii. Spare parts
In order to ensure a good medical equipment maintenance program, an inventory of spare parts and supplies
should be in place. A proper forecast should be made on items like batteries, filters, valves, tubings etc. and
should be procured in advance to save time. Cleaning and lubricating material should also be procured in
advance with bigger quantity. The service provider is expected to make contacts with medical equipment
manufactures with proper need anticipation to ensure availability of spare parts for equipment. The service
provider is expected to change worn out parts at a time frame specified by manufacture during preventive
maintenance.

iv. Operation and Service Manuals
The service provider should maintain a library with operating and service manual for every model of
equipment under his/her maintenance contract. These manuals shall help support in inspection, preventive
maintenance, repair and calibration.

2. Tagging of medical Equipment
It is very important that the service provider label each and every medical equipment under his service
contract with a unique identification number or a bar code for an easy access/breakdown call via Toll free
number. This number shall act as a reference for registering and complaint medical equipment breakdown.
Similar type of stickers or online QR code may be used for signifying the preventive maintenance and
calibration status of medical equipment. Every sticker should clearly highlight the NHM logo. Samples of
various sticker designs are attached in Annexure III for reference.

3. Call Centre
Call centre is a backbone of any maintenance service and like any other service, the Biomedical Equipment
Maintenance Service provider has to setup a centralised call centre with a toll-free number. Call centre is
expected to handle state/ regional language in addition to other languages. These call centres would receive
phone calls directly from clinical staff, public healthcare professional having equipment
issues/breakdowns/request for training/calibration, available 24 hours a day 7 days a week. When a medical
device is having issues/breakdowns/request for training/calibration the hospital staff calls the call centre
giving the operator their name, phone number, asset ID number, and a brief description of the problem.
This could be using an automated Interactive Voice Response System (IVRS) mechanism as well.
The call centre has access to the Medical Equipment Maintenance Software system and generates a work
order to the assigned technician. The work order is then e-mailed to the concerned technician.
The call is kept open in the software database until the work is complete and the call is closed. This system
enables complainant to receive status of the repair. Keeping the complainant informed of their equipment
status helps build relationships and trust between the clinical staff and the service provider.
Closing of complaint calls shall be done only by nodal officer of concerned PHC/CHC/DH. Every public
health facility is expected to have three nodal officers, anyone could be called from call centre to convey
rectification of opened call and make record of call closure. Call closure via response through
SMS/Email/IVRS from registered nodal officer of concerned facility is also allowed.

22 | P a g e

<!-- page 23 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

4. Software/Dashboard
The Biomedical Equipment Maintenance and management services under NHM are usually outsourced to
a service provider, selected via tender process at the state level. Hence it is very important to monitor the
program at the state level. One of the important tools to monitor this program at the state (and even
below) level is through a dashboard (online real-time monitoring web page) provided by the service
provider. Some of the important features a dashboard should have are:
i.

ii.

iii.

iv.

v.

23 | P a g e

Work Order management: The moment a complaint is registered on the toll-free number,
the system software in the call centre should be able to generate a work order, depute a
person for the job and reflect the same on the dashboard. The software should be capable of
tracking the equipment and also inform if the equipment is under any service agreement with
the OEM or elsewhere. The system should be capable of generating emails and SMSs to
customer as well as the technical team on various notifications. The dashboard and all the
reports generated should clearly highlight the NHM log.
Equipment Tagging: Once all the equipment are tagged, the data should be available on the
software/dashboard. This data should contain the serial number, model number, and all other
requisite details for tracking. The tracking mechanism should also allow tracking the
maintenance history and maintenance schedule (preventive maintenance, calibration etc.) of
the equipment. Every field of individual should also allow uploading relevant photographs,
manuals, etc.
Invoicing: The software shall allow generation of invoice and also have the feature of
import/export bills. These invoices should be linked to uptime, material (spare parts, tools,
etc.) and other expenses.
Dashboard: Like majority of the states, the dashboard can be shared on a public domain,
however certain states may like to secure it with a login password. In case service provider
wants to ensure secure access by user name and password, keep a “Guest login access” for
public information. The dashboard should be easily customisable as per the requirements of
the state. The dashboard should give a summary of all medical equipment maintenance in the
state including but not limited to total number of equipment, total number of call received,
total number of call resolved, total function/non-functional equipment, summary of user
training conducted, information on asset value and periodic revision, details of equipment
under beyond economical repair category, information on organisation structure, location of
workshop and expertise of human resources hired for maintenance . These details should also
allow to be traced down to district as well as facility level with percentage functionality. The
dashboard should display Preventive Maintenance and Calibration schedule for all the
equipment. Maintenance details of all the critical equipment with uptime should be separately
displayed. It is also pertinent to note that the dashboard should also display the NHM logo.
Mobile: The dashboard should preferably be accessible from mobile phone as well. This
allows flexibility. These features allows capturing the signature of the user on electronic
service reports and then email them directly, saving paper and environment. This feature also
allows capturing photographs and uploading with relevant documents. Mobile based
applications further enhances the user experience from both the customer as well as the
technician’s side.

<!-- page 24 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

5. Training
Proper training is crucial for both technical staff and users to ensure safety and appropriate use of medical
equipment. Service providers are expected to provide continued training on every equipment under
maintenance contract to own technical staff and end user (healthcare professional).Training should be an
ongoing activity to ensure that users are trained and informed of their particular responsibility. The
service provider needs to ensure that he setups a system in place all the necessary training.
Such trainings can be given by following methods:
i. Through knowledge on equipment service and training manuals or any other additional training
material provided by the Original Equipment Manufacturer (OEM).
ii. By sourcing specialised training expert to teach staff about particular medical equipment
maintenance and usage.
iii. Training given by the OEM on operations and maintenance of a particular equipment.
iv. Third party training program
The service provider shall submit a Gantt chart at the time of signing contract and the authority shall
ensure compliance to the same.

Gantt chart

1st Month
Technical Infrastructure
Equipment Tagging
Call center
Software/Dashboard
Training

24 | P a g e

2nd Month

3rd Month

4th Month

5th Month

<!-- page 25 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

II Standard Operating Procedure (SOP)
About the program:
Scope of services: Comprehensive maintenance (including spares, user training, real-time monitoring
etc.) of all medical equipment in public health facilities from (PHC, CHC, and DH)
(i) To maintain Biomedical Equipment in all public healthcare facilities up to the PHC level supported
by 24 X 7 call center ;
(ii) To provide 24x7, 365 days uptime of 95% for all medical equipment in District Hospitals, 90%for
CHCs and 80% for PHCs. At no point of time in a single breakdown the breakdown should not be
more than 7 days from the date and time of registration of fault.
(iii) Medical Equipment that are already in AMC or CMC. The service provider shall administer the
contract on behalf of state health department. For this purpose, the service provider shall take
authorization from services providers for the respective equipment for which AMC/CMC may be
in existence.
(iv) For Medical Equipment that is currently under warranty. The service provider shall administer all
maintenance activities on behalf of the state health department for the entire duration.
(v) For all medical equipment that is under any form of AMC/CMC/Spares agreement or under
warranty, the state health department shall not be renewing the equipment specific maintenance
contracts
(vi) The maintenance service provider shall not be including cost of maintaining any equipment which
is under any kind of AMC/CMC/warranty in its first proposal and cost of such equipment shall not
be included till the time existing contract(s) with other service provider(s) is valid for the respective
equipment. The maintenance service provider may choose to take authorization for doing
maintenance such equipment from existing AMC/CMC contract holder(s).
(vii) Maintenance costs for equipment that are currently in any AMC/CMC/warranty contract shall be
added by the service provider only after the expiry of contracts for the respective equipment.
(viii) The sole service provider shall however be liable to ensure upkeep time declared in the bid for
all equipment irrespective of any AMC/CMC/warranty status for any equipment.
(ix) The maintenance service provider shall be identifying and responding to requests seeking
maintenance of all requests seeking maintenance of all Biomedical Equipments available on the
district/sub district/state up to the level of primary health centre through the maintenance process
tracking identification number (MPT-IDs)
(x) Maintenance service provider shall establish and operate an exclusive 24x7-customer care center
for accepting calls and managing the maintenance services.
For purposes of clarity, operationalization will be regarded as:
(a) Setting up of maintenance workshop for maintenance of medical equipment, and
(b) Setting up Customer Care Centre to accept user calls
(c) Appointment and recruitment of trained engineering and administrative human resource and
(d) To provide Equipment Management Information System and
(e) To provide categorization of all equipment, clearly identifying critical equipment along with their
25 | P a g e

<!-- page 26 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual
clinical functions
(f) To maintain biomedical equipment in all public healthcare facilities in an entire district/ region/ state;
and
(g) To furnish the format of equipment identification code system
The Contracting Authority (Usually a government body/agency) shall have the right to increase the number
of equipment beyond the present number from the date of execution of the Agreement. In the event of any
such increase in the number and density of equipment by the Authority, the Operator shall operate and
maintain the additional equipment till the remaining term/duration of the Agreement in the given year and
the monetary value for the maintenance of the added equipment shall be included in the subsequent years;
as part of the existing scope of work and upon the same terms and condition specified in the Agreement.
Equipment are being classified based on their criticality as below:
1. Ventilator- ICU & Transport
2. Defibrillator
3.Dialysis Machines

5. Baby Incubators.
8.Electrosurgical Units- Surgical
Cautery
18.ICU Monitors
19. Blood Gas Analyser
24.ICU Nebulizers

Any other equipment as deemed appropriate by the state authority.

Organogram:
The service provider is expected to develop an organogram suiting State Specific terms and condition of
Biomedical maintenance and management agreement, considering State health authority/State National
health mission and State Medical service corporation.

26 | P a g e

<!-- page 27 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

1 Equipment tagging:




Objective: To carry out Tagging and Registration of Biomedical Equipment
Scope: All Biomedical Equipment under Contract
Responsibility: Service provider, dept. in charge of health facility, district medical officers
Procedure:

S.No Activity

Responsibility

1

Service Provider visits the hospital

Service Provider

2

Tagging Sticker is pasted by the SP

Service Provider

Tagging sticker

3

Service provider records this info in registration form

Service Provider

Registration form

4

SP keeps the record of registration form and updates the
dashboard

Service Provider

Dashboard

5

Facility in charge provides the details of year of installation,
warranty and etc.

Facility In charge

-

6

Facility in charge verifies the registration and approves it

Facility In charge

Copy of registration
form

27 | P a g e

Record
-

<!-- page 28 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

2 Complaint log:




Objective: To register a Medical Equipment maintenance complaint
Scope: All Biomedical Equipment under Contract
Responsibility: user of Medical Equipment, Facility In charge, Deputy In charge

Procedure:
S.No.

Activity

Responsibility

Record

1

User calls the toll-free no. to register equipment problem

End user

Call log

2

User provides the mandatory info to register the complaint
Equipment Identification number
Location
User name and contact
Nature of complaints

Users

Call log

3

Call centre register the request with work order no

Call centre

4

Call centre forwards the work order to respective technical staff
and regional In charge

Call centre

Work order no. via
email and SMS
email and SMS

5

Technical Staff resolves the problem and gets it acknowledged
on a service report

Service provider

Service report

6

Closure of work order is followed by a SMS to respective user
In charge

Facility incharge or
Nodal officer
through Call centre

SMS and work order

28 | P a g e

<!-- page 29 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

3 Breakdown Maintenance


Objective: To ensure Breakdown Maintenance Activity is carried out for All Biomedical

Equipment within specific time frame as per the contract agreement
 Scope: All Biomedical Equipment under Contract
 Responsibility: Service report, Facility In charge, Deputy In charge, end users
Procedure:

S.
No

Activity

Responsibility

1

Service provider visits the facility after call registration

Service provider

2

Service provider performs necessary repairs

Service provider

3

Feedback is provided to the user if machine is not repaired in the 1st
instance

Service provider

Email & SMS

4

Service report is signed and updated on the dashboard

Service provider

Dashboard

5

In charge verifies the functionality through Deputy In charge, end
user

Facility In charge

Service report

6

Service provider prepares the Service report and submits to the In
charge

Service provider

Service report

7

Call Closure

Facility In charge
/Nodal Officer

Call Record and SMS

29 | P a g e

Record
-

<!-- page 30 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

4. Preventive Maintenance & Calibration




Objective: To provide Preventive Maintenance & Calibration on all Biomedical equipment
Scope: All Biomedical Equipment under Contract
Responsibility: Service provider, Facility In charge
Procedure:

S.
No

Activity

Responsibility

Record

1

Annual Schedule of Preventive Maintenance and Calibration is
submitted to the state

Service provider

2

Checklist for Preventive Maintenance & Calibrations is also
submitted by the Service provider initially

Service provider

3

Preventive Maintenance is performed as by facility In charge per
schedule and verified by the checklist

Service provider &
end users

4

Preventive Maintenance of under maintenance equipment is
rescheduled

Service provider

5

Details are updated on the dashboard

Service provider

6

Sticker is affixed stating the date of PM&C and next due date

Service provider

Preventive
Maintenance and
Calibration &
Dashboard
Preventive
Maintenance and
Calibration &
checklist, report
Preventive
Maintenance and
Calibration &
Dashboard
Preventive
Maintenance and
Calibration &
Dashboard
Preventive
Maintenance and
Calibration &
Dashboard
Preventive
Maintenance and
Calibration & sticker

30 | P a g e

<!-- page 31 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

5. User Training




Objective: To provide Periodic User training of all types of medical equipment
Scope: All Biomedical Equipment under Contract
Responsibility: Service provider and Mission Director
Procedure:

S.
No

Activity

Responsibility

Record

1

Prepare annual user training schedule

Service provider

Training schedule &
dashboard

2

Schedule is approved by the authority

Mission Director

3

User training is conducted (at least once a year per equipment

Service provider

Training schedule &
dashboard
Training report

4

Attendance and feedback of the training is collected

Service provider

31 | P a g e

Attendance &
feedback report

<!-- page 32 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

6. New Equipment Installation


Objective: To ensure that newly installed Equipment are smoothly brought into the system of

Biomedical Equipment maintenance program and supported by their respective suppliers’ during
the warranty period.
 Scope: All Biomedical Equipment under Contract
 Responsibility: Service provider, Facility In charge, supplier
Procedure:

S.
No

Activity

Responsibility

Record

1

Information to the Service provider for new equipment through
toll free no.

Facility In charge

Call log

2

Service Provider asks for a copy of records from the
supplier/manufacturer with the support of the facility in charge

Service provider,
Supplier & facility In
charge

3

Service provider coordinates with supplier for installation

4

Dash Board is updated

Service provider,
Supplier & facility In
charge
Service provider

Purchase order,
warranty duration,
operating manual,
maintenance manual
-

5

Service provider ensures training provided to the end user by the
supplier

6

If any of the point 2, 3 or 5 is complied partially or fully, the
service provider informs the facility in charge to withhold the
payment
Service provider registers the equipment, affix the tag and
informs the supplier/manufacturer

7

32 | P a g e

Service provider,
Supplier & facility In
charge
Service provider,
Supplier & facility In
charge
Service provider

Installation report

Email, letter

Equipment tag

<!-- page 33 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

7. Biomedical Equipment Not Found during Preventive/Corrective Maintenance


Objective: To notify the user for Biomedical Equipment Not Found during Preventive

Maintenance
 Scope: All Biomedical Equipment under Contract
 Responsibility: Service Provider, Dept. In charge of Health Facility, facility In charge
Procedure:

S.
No

Activity

Responsibility

1

Service Provider technical staffs visit the Healthcare facility for
preventive Maintenance as scheduled.

Service provider

2

Service provider

4

Any equipment not found in its registered location, the technical
staff record in Service report.
Submit the form to Respective Health facility Nodal officer/ Dept
In Charge
Health facility Nodal officer acknowledges the Service report

5

Technical staff to submit the Service report to DMO

Service provider &
Facility In charge
Service provider

6

Service provider &
facility In charge
Service provider &
dept. health officer
Service provider

Email & letters

8

Service Provider to follow up with respective nodal officer to
provide the equipment not found during technical staff visit
Service provider shall send follow up letter to DMO after one
month if no feedback from Nodal officer
Preventive Maintenance work order is completed with remarks

9

The equipment is removed from the asset base of inventory

Service Provider

Dash Board

3

7

33 | P a g e

Service provider

Record
Service report
Service report
Service report
-

Service report

<!-- page 34 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

8. Warranty / AMC Management:


Objective: To ensure that biomedical equipment under warranty are maintained and supported by

their respective suppliers in accordance with the provisions of the warranty terms of supply.
 Scope: All biomedical equipment under warranty.
 Responsibility: Service Provider, Dept. In charge of Health Facility, Equipment In charge,
facility In charge
Procedure:

S.
No

Activity

Responsibility

Record

1

Health facility In charge / end users to report any Equipment under
Warranty / AMC requires repair

Facility In charge &
End users

Call log

2

Service provider to notify respective Vendor for any repair / service

Service provider

3

The copy of such letter and email will be submitted to Health
facility In Charge
Service provider to notify respective vendor one month prior to
expiry of warranty
Medical equipment under AMC will be added to service provider
contract after the expiry of such AMC to the inventory asset base
Service provider updates all service done in Dashboard

Service provider

Call centre/call
log/letter/email
Call log/letter/email

Service provider

Call log/letter/email

Service provider

Dash board

Service provider

Dash board

4
5
6

34 | P a g e

<!-- page 35 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

9. Condemnation of Biomedical Equipment




Objective: To formally condemn equipment for reason defined below
Scope: All Biomedical Equipment under Contract
Responsibility: Service provider, Facility In charge, Mission Director, Condemnation committee
Procedure
S.No.

Activity

Responsibility

Record

1

Service Provider to indicate a list of equipment to be condemned

Service provider

Condemnation

2

State government to form a committee to declare the
condemnation of equipment

Mission director

Condemnation order

3

To recommend for condemnation of Biomedical Equipment
shall satisfy one or more following conditions:
 Beyond Economic repair
 Obsolescence
 Reliability
 Worn Out

Mission Director &
Service provider

Dashboard

4

The condemnation committee to issue a list of biomedical
equipment approved for condemnation
Approved equipment for condemnation shall be removed from
the asset inventory asset base and billing henceforth

Condemnation
Committee
Service provider

Letter

For radiology equipment, approval from AERB to be taken and
condemnation to be done as per the guidelines

Condemnation
committee

Government order

5

6

Recommended Member of Condemnation Committee:
1.
2.
3.
4.
5.
6.
7.

Mission Director or his representative
BMMP Nodal Officer
Facility In charge
Biomedical Engineer of the state
Store In charge
Purchase officer/ Finance Officer
Service Provider as an invitee

35 | P a g e

Condemnation

<!-- page 36 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

10. Process the Bills for Payment and Documentation





Objective: Document requirement and verification for processing the service providers Invoice
Scope: Biomedical Equipment Maintenance Bills
Responsibility: Service provider, Facility In charge, BMMP state Nodal Officer
Procedure: Service Provider to prepare following reports ( Facility Wise) for processing the
Bills








No

REPORTS

Record

1

Breakdown Report

Service Report duly signed by respective
MO

2

Preventive Maintenance / Calibration PM report with Check List and calibration
Report
report

3

Penalty Report

Service Report

4

User Training Report

Attendance record & Feedback Form

5

Lists of Equipment
Condemnation

6

Lists of Out of Warranty Equipment

Installation Reports / Copy of Department
Register

7

Lists of Out of AMC / CAMC Equipment

AMC / CAMC Agreement

8

Lists of newly Registered Equipment

Equipment Registration form

Proposed

for Condemnation Reports
Equipment wise )

(

Service Provider to prepare Facility wise all above reports, duly approved by the facility in charge
and submit to accounts department with copy of Support Document.
Service Provider Prepare the State Wise Summary as per the Monthly Reports.
Service Provider Shall submit all the reports on or before 5th of every month.
Nodal Officer shall verify the reports within 7 days of submission and forward the same to the
accounts department for payment. In case of objection the invoice may be sent back to the service
provider stating the reasons thereof.
Accounts to clear the payment within 30 days of receipt of invoice by the facility incharge/ Nodal
officer

36 | P a g e

<!-- page 37 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

11. Adverse Event Reporting (Materiovigilance)
Materiovigilance Programme of India was launched by DCG (I) on 6th July 2015 at Indian Pharmacopoeia
Commission (IPC) Ghaziabad. Following organisation plays below key roles for this program, Indian
Pharmacopoeia Commission functions as a National Coordination Centre (NCC) for MvPI. Sree Chitra
Tirunal Institute for Medical Sciences & Technology (SCTIMST), Thiruvananthapuram, shall act as
National Collaboration Centre, National Health System Resource Centre (NHSRC), New Delhi shall act as
Technical Support & Resource Centre and Central Drugs Standard Control Organisation (CDSCO), New
Delhi shall act as regulator.
Materiovigilance Programme of India aims to monitor medical devices in health system and weed out
substandard or unreliable medical devices from marketing or selling in India. Even though Materiovigilance
is not in the scope of services of service provider, any activity like informing National Coordination Centre
on spurious or unreliable medical devices will be appreciated. Toll free number for reporting is
18001803024 and technical support can be sought from NHSRC.

37 | P a g e

<!-- page 38 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

III Training Manuals
Training is a key element in the Biomedical Equipment Maintenance Program. This requires ensuring
adequate training programs are in place for safety and reliability of equipment. The below thematic areas
may be converted into PowerPoint slides and used for in-house personnel for giving an overview of the
program.

1. Objectives of the Program
The objective of this program are as below.









Exact assessment of all equipment available in DHs, SDHs, CHCs & PHCs.
Make all the equipment in working condition to deliver uninterrupted patient service.
Provide periodic user training to all the users to improve the patient care.
Manage the equipment under AMC/CAMC/Warranty in coordination with service providers and
to ensure the suppliers provide services as per purchase terms.
Carry out Preventive maintenance of all equipment to meet the manufacturer’s specifications to
ensure availability of equipment at all times for patient care
Calibration of all the equipment to ensure performance and standards.
Submission of monthly/ quarterly report on functional status of equipment
Assist in site-preparation, installation and commissioning and arrange the user-training with
suppliers.

Scope of services








Break down Maintenance
Preventive Maintenance & Calibration Services
User Training
Installation and Commissioning support
Acceptance testing
AMC/CAMC/ Warranty Management
Condemnation ( Beyond Economic Repair)

2. Installation and Commissioning
a. Service provider/Supplier responsibilities





To help the authorities to ensure the new equipment are installed in a location to ensure the
proper functioning of the equipment.
To advise the authorities to arrange a proper electrical supply, air conditioning, environmental
requirements and other installation requirements
To support the Authorities to ensure proper delivery of the equipment as per the purchase order
and its installation.
The Service provider’s engineer need to ensure the functionality and performance of the supplied
new equipment in support with the user.

b. User responsibilities




To inform the service provider about the new purchase and expected installation period and its
location.
To arrange a proper electrical supply, air conditioning, and other installation requirements.
To allow the service provider engineer to coordinate with the supplier to ensure all the equipment
delivery as per the purchase order.

38 | P a g e

<!-- page 39 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

3. AMC/CAMC/Warranty Management


The service provider need to coordinate with the supplier for Preventive Maintenance Service and
Calibration of the equipment.
 It is the responsibility of the service provider need to decide whether the equipment is necessary
to get AMC/CAMC from the supplier.
 The user can discuss with the service provider to get the supplier’s support if necessary for future
service and criticality of the equipment for patient service.
However it is the responsibility of the service provider to keep the equipment functioning either by
engaging supplier or by appointing in-house engineer to ensure the equipment meet the uninterrupted
patient service. In case the supplier is not responding to any of the request the service provider should
escalate the matter with higher authorities which may lead to penalising the supplier.

4. User Training




The user training need to be conducted across all the DH/SDH/CHC/PHC
A schedule to be given to the respective Nodal officer / Facility In-charge
Upon acceptance of the user training schedule the training to be given to the users to ensure the
equipment is used properly for patient care safely.

5. Break down Maintenance


It is the user responsibility to call the customer care (Call Centre) toll free number to make a
complaint about the non-functioning of the equipment.
 The user need to note down the following information to register a complaint with the customer
care about the non-functioning of the equipment
 Equipment ID Number, Equipment name, User’s Name, User’s mobile contact number, E mail
ID and the nature of the problem.
An E mail & SMS notification sent to the caller upon registration of the complaint in the maintenance
management system and another notification of completion of the repair. The caller need to verify the
equipment function with this E mail or SMS information. If not satisfied with the repair again the caller
can reregister the complaint to the customer care (Call centre)




The service provider need to ensure to repair the equipment at the earliest without affecting the
patient services.
If necessary based on the criticality of the equipment, the user may have to provide the standby
equipment to ensure the patient services are not affected.
Upon completion of the repair the service provider need to prepare a service report and get the
acknowledgement from the facility In-charge or Nodal officer. In case the user wants to observe
the function of the equipment then the user needs to write a note in the service report and
acknowledge the report.

6. Preventive Maintenance (PM Service)
The Preventive Maintenance is to ensure the reliability during use usage, user safety & patient safety.
This is done in order to:




To prevent breakdowns and ensure the machine is available for patient services.
To make the equipment functioning at all times to its specified performance and safe to the user
and the patient.
To increase the expected lifespan of equipment

39 | P a g e

<!-- page 40 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual



To increase the effective utilisation
The service provider should ensure the PM is carried out as per the accepted scheduled and as per
the standards with use of approved check list.

7. Calibration Services





Calibration/ Performance verifications need to carry out by using the proper test equipment as per
the manufacturer’s recommendations or NABL/as per the Regulatory authorities like AERB.
The equipment which do not require calibrations need to mentioned clearly and submit a list to
the user and the Nodal officer.
Upon calibration a certificate need to be submitted to the user or the facility In-charge/ Nodal
officer.
If any equipment failed during the calibration, a corrective action need to carried out by
registering a complaint through call centre and after the corrective action, the calibration need to
be again carried out for that particular equipment.

8. Condemnation




If any equipment cannot be repaired due to obsolete or discontinued or very high cost, to be
informed to the user and the nodal officer.
A technical report is to be submitted with the reasons for proposing the Condemnation and get it
approved by the user / Nodal officer/ Committee.
Upon Condemnation (BER) approval a quarterly report need to be submitted for the removal of
the equipment from the list/ Dash board.

9. SMS & email Feedback at the time of Registering Breakdown Call
SMS Format:
Service Call <Insert automatic call generation number > on <date > < Equipment Name > Not
Working > Engineer :< Name > <Phone Number > will attend shortly

Email Format:
Subject: Repair / Service Call XY-ZA-2018-00042 is created
Dear Sir / Madam
The below mentioned service call is created.
Service call No: ………………
Customer name: ………..DH/CHC/PHC
Equipment Identification No: ………………….
Equipment Name: ………………
Call logged on date: ………………
Problem Reported: ………………
Pl. call ………………, if any queries
This email is system automatically generated. Please do not reply

40 | P a g e

<!-- page 41 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

10. Documents Required to Process the Quarterly Invoice
Reports

Service Provider

Hospital Authority/ Nodal
Officer

Equipment List

Prepare Hospital wise
Equipment list – Quarterly
Once

Respective MO to
Acknowledge in Verified
column of List

2.Equipment List – Out of
Warranty, Out of AMC / CMC

Prepare Hospital wise
Equipment list – Quarterly
Once

Respective MO to
Acknowledge in Verified
column of List

3.Equipment List proposed for
Condemnation & Summary

Prepare Hospital wise
Equipment list – Quarterly
Once

Respective MO to
Acknowledge in Verified
column of List

4.Equipment List – Newly
Tagged & Summary

Prepare Hospital wise
Equipment list – Quarterly
Once

Respective MO to
Acknowledge in Verified
column of List

5.Breakdown Calls Report

Prepare Hospital wise –
Monthly

Respective MO to
Acknowledge in Verified
column of List

6.Preventive maintenance /
Calibration Report

Prepare Hospital wise –
Monthly

Respective MO to
Acknowledge in Verified
column of List

7.User Training Report

Prepare Hospital wise –
Monthly

Respective MO to
Acknowledge in Verified
column of List

Prepare Hospital wise –
Monthly

Acknowledge Summary along
with Reports and Invoice

Prepare Hospital wise
Equipment list – Quarterly
Once

Acknowledge Summary along
with Reports and Invoice

8.Penalty report
9.Summary of Variation to
Service

41 | P a g e

<!-- page 42 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Other Reports to be submitted
Reports
1. Walkthrough Report
i. DH – Monthly ( Dept.
Wise)
ii. SDH – Monthly ( Dept.
Wise)
iii. CHC / PHC – Quarterly
( As per Equipment
List)

Prepare Hospital wise critical
and major important equipment
list and submit to respective
MO, CMO,DMO and NHM (
Equipment functionality is
checked and recorded during
walk through report)

Respective MO, CMO,DMO to
acknowledge the List

2. Breakdown Feedback Report
– Hospital wise ( every
fortnight)

Prepare Breakdown Feedback
report with Expected Date of
Completion to Respective MO,
CMO , DMO

Respective MO, CMO,DMO to
acknowledge the List

Reports to be kept in the each Health Facility









Equipment List – While Taking over
Equipment list – Out of Warranty , AMC , CMC
Equipment List – New tagging List
Breakdown Service Report Copy
Preventive Maintenance report
User Training report
Walkthrough Report
Breakdown Feedback Report

42 | P a g e

<!-- page 43 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

IV. Oversight Committee
A national programme has the responsibility of creating support systems that would ensure that the goals
of the program are achieved in a time-bound manner, are replicable in the and can be continually
improved, both upstream and downstream.
A State Oversight Committee (SatCom) would be set up as the overall owner of the Biomedical Equipment
Maintenance Programme. The SatCom shall establish an overall policy-framework, assess progress,
identify areas of improvement and guide StateCom in implementation of policy. SatCom will also formulate
the standards of professional conduct and maintain an oversight on the overall conduct of the participating
Service Providers.
The SatCom would support and promote human resource and academic development of Service Providers
and coordinate with Bidders to organize and deliver such activities. In addition, the SatCom would
commission committees or working groups, conduct meetings and seminars for disseminating knowledge.
The SatCom would meet every quater where districts would present the progress of the program in their
area. The structure of the SatCom would be as follows:
1.
2.
3.
4.
5.
6.

Mission Director, Chair
Chief Medical Officer(s)
State Biomedical Engineers
External Biomedical Engineering experts
State Program Manager (BMMP) , Member secretary
Any other member as deemed appropriate by the state

43 | P a g e

<!-- page 44 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

V Reporting Formats
Equipment Registration Form
1. Hospital /Clinic Details

2. Equipment Details

Hospital /Clinic
Name*
Hospital /Clinic
Category
Hospital /Clinic
Address
Department

Equipment No.*
MC( )
CHC()

DH( )
PHC( )

Manufacturer*
Model*

District Name

Name*

Supplier/Service
Agent.
Supplier Contact
info
ME functional
Status
Contract Start Date

Mobile

Type Of Equipment

Email

Date of Installation

Zone
State

Contact Details

ME General name*

Equipment Value

AMC/CAMC
Value

3. Remarks
4. Standard Components /Accessories
S.No
Part Description Part No. Qty.

Registration Done
by(Engineer/Technician)
Signature:

Verified &Approved by
User
Signature:

Name:
Date:

Name:
Date:
Stamp:

Note: In the status field, except for the condition “function Good” for all other condition should
carry detailed explanation in the remarks field.
FG: Functional Good /NW: Not Working/ AMC: Annual Maintenance Contract/CAMC:
Comprehensive Annual Maintenance Contract
DH: District Hospital/CHC: Community Health Centre/PHC: Primary Health Centre/MCH:
Medical College Hospital
*Mandatory Fields to be filled

44 | P a g e

<!-- page 45 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Certificate of Medical Equipment Tagging Status
District
Health Facility
Category of Health Facility
Total Number Of Equipment Tagged

MC( )

DH( )

CHC( )

PHC( )

Number of Equipment Functioning
Number of Equipment Not Functioning

I hereby certify that all the Medical Equipment available in the Hospital/Clinic has been tagged by (name
of service provider).There is no more Medical Equipment available in the Hospital/Clinic pending for
Tagging. There are no equipment mentioned in the list which do not physically exist.

For Hospital /Clinic
Name
Designation
Sign
Date

45 | P a g e

Service Provider
Name
Designation
Sign
Date

<!-- page 46 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

STATE:
RFP
No

District

Hospital
name

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15

46 | P a g e

LIST OF EQUIPMENT – TAGGED AS PER
Me
number

Medical
Equipmen
t name

Manufacture

Model

Serial
number

Function
al status

Department

<!-- page 47 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Recommendation For Beyond Economical Repair (BER)
BER Ref No:
ME NO
ME Name
Manufacturer
Model
Serial No.

Hospital Code
Hospital Name
District
State
Hospital Type

Purchase Cost

Date Of Purchase

Estimated Repair Cost exceeds
Depreciated Cost or it is more
than 50% of market value of
new equipment

GH()

Accumulated Maintenance Cost(1 Year)
Estimated Cost of Present Repair
Total Cost
Depreciated Cost

CHC( )

Rs
Rs
Rs
Rs 0.00

Condition Appraisal &Recommendation for Beyond Economic Repair Certification
Obsolescence
Reliability
Statutory Requirement
Worn Out

Prepared By

Verified By

Engineer/Technician

State In-Charge
Name
Date

Name
Date

47 | P a g e

Approved By

Nodal Officer
Name
Date

PHC( )

<!-- page 48 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Format for Equipment Not found during “Preventive Maintenance”
Date:
Dr……………………
Hospital:

Dear Dr,
The below equipment scheduled for Preventive Maintenance in ……….Month is not able to locate in its
registered location. Kindly provide the Equipment to perform the Preventive Maintenance.
NO Distric
t

Hospital Department ME
Name
Number

Prepared By
Acknowledged By

48 | P a g e

ME
Manufacturer Model Serial Functiona
Name
no. l status

<!-- page 49 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Service Report
Hospital Type

DH

CH

PH Work Order Number

Hospital Name

WO Date &Time

ME No

WO Respond Date
&Time
WO Respond Date
&Time
Under Warranty( )
Under AMC( )
Reimbursed Work( )
Standby Provided( )

Contract Equipment( )
BER ( )
Problem Reported

Action Taken

Material Used
No

Stand By Equipment Details
Item Description

Qty

Equipment No :
Equipment Provided
Date:
Equipment Condition : Good ( )
Damaged( )
Equipment Returned Date:
Customer Acceptance for Stand By
Equipment

Breakdown Execution details
Engineer/Technician
Name

Date

Start Time

End Time

Customer Remarks
Engineer/Technician Signature

Customer Signature for WO
Completion

Name:
Name:
Designation
Stamp
Verification
In charge

49 | P a g e

<!-- page 50 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Training Feedback Form
Name:

Designation

Program Title

Date

Trainer Name

Venue

The purpose of this evaluation form is to assess the effectiveness of the course that you have just
attended. Please refer to the ratings below to assist us in your evaluation .We thank you for your
participation
1. Course Objectives:

Rating System1=Very Poor, 10 =Very Good

How well has this course met its stated objectives? 1 2 3 4 5

6

7

8

9 10

Have the objectives met your personal needs?

6

7

8

9 10

1 2 3 4 5

2. Course Contents:
The subject content/skills applicable to your job

1 2 3 4 5

6

7

8

9 10

New ideas /skills knowledge gained by attending this1 2 3 4 5 6

7

8

9 10

program?
The quality of Contents

1 2 3 4 5

6

7

8

9 10

Knowledge of subject matter

1 2 3 4 5

6

7

8

9 10

Ability to Present views and ideas clearly

1 2 3 4 5

6

7

8

9 10

Communication skill

1 2 3 4 5

6

7

8

9 10

1 2 3 4 5

6

7

8

9 10

Training Venue

1 2 3 4 5

6

7

8

9

Course /Program coordination

1 2 3 4 5

6

7

8

9 10

Any Other comments/suggestions

1 2 3 4 5

6

7

8

9 10

3. Facilitator /Trainer

4. Overall Rating
How do you rate this course /program
5. Miscellaneous

User Signature

50 | P a g e

10

Trainer Signature

<!-- page 51 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Training Attendance Record
Date

Event Type Training

Venue

Trainer Name

District

State

Meeting

Training Subject
No

51 | P a g e

Employee Name

Dept.

Phone no/Email id Signature

<!-- page 52 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

SUMMARY – USER TRAINING CONDUCTED
District

52 | P a g e

Hospital

Equipment

Trainer Name

No. of Staffs Attended

<!-- page 53 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

SUMMARY – EQUIPMENT NEWLY TAGGED
DISTRICT

HOSPITAL

QUANTITY

TOTAL

53 | P a g e

TOTAL PURCHASE
COST

<!-- page 54 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

WALKTHROUGH REPORT
District
No ME
Number
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19

54 | P a g e

Medical
Equipment
Name

Hospital
Manufacture

Model

department

Functional User
Status
Signature

<!-- page 55 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

STATE:
No

District

1
2
3
4
5
6
7
8

55 | P a g e

LIST OF EQUIPMENT NEWLY TAGGED
Hospital
name

Department

ME
number

ME
Name

Manufacturer

Model

Seria
l

Functional
status

<!-- page 56 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

State:
No

District

Breakdown Feedback Report
Hospital

1
2
3
4
5
6
7
8
9
10
11
12
13
14

56 | P a g e

Me
number

M.E.
name

Make Model

Work
order no

Call
date

Spare
requireme
nt

Actio
n
taken

Expected
date of
completion

<!-- page 57 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

LIST OF EQUIPMENT OUT OF WARRANTY
No

District

Hospital

1
2
3
4
5
6
7

57 | P a g e

M.E.
number

M.E.
name

Manufacture

Model

Serial
no

Functi
onal
Status

Dept.
/locatio
n

Warran
ty

Warranty
end

<!-- page 58 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

State:
No

District

1
2
3
4
5
6
7
8
9
10
11

58 | P a g e

Work
order
no

List of Preventive Maintenance
Work
order
date

Hospital

M.E
name

M.E.
Completed
number date & time

status

Remarks

<!-- page 59 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

LIST OF EQUIPMENT – TAGGED AS PER
RFP

STATE:

No

District

Hospital
name

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15

59 | P a g e

Me
number

Medical
Equipmen
t name

Manufacture

Model

Serial
number

Function
al status

Department

<!-- page 60 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

ANNEXURE-1
Form GFR-10
(See rule 217(iii) of the General Finance Rules 2017)

Report of surplus, Obsolete and Unserviceable Stores for Disposal
Item
No.

1

Date

60 | P a g e

Particulars of
Stores

2

Quant Book
Condition
ity/W Value/Original and year
eight Purchase Price of
purchase
3
4
5

Mode of Disposal
(Sale, open
auction, advertised
tender etc.)
6

Signature of Indenter
Designation of Indenter

Remarks

7

<!-- page 61 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Annexure-II
FORM GFR 11
[See Rule 222 of GFR 2017]
Sale Account
Ite
m
No
.
1

Particular
s
of Stores
2

Date

\

61 | P a g e

Quantity
/
Weight
3

Name and
full
address
of
purchaser
4

High
est
bid
acce
pted
5

Highest
bid
rejected
6

Earnest
money
realized
on the
spot
7

Date on
which
the
complet
e
amount
is
realized
and
credited
into
treasury
8

Whether the
articles were
actually
handed
over on the
spot. If
not, the
actual date
of handing
over of
the articles
with
quantities
9

Signature of Indenter
Designation of Indenter

Auctio
neer's
Commi
ssion
and
ackno
wledge
ment
for its
payme
nt
10

<!-- page 62 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

Annexure III
DANGERI

CAUTION

Do Not Use with
AC Power Source

OUT OF
ORDER

INSPECTED

Problem-----------Signed--------------

Date

Date-----------------------

Due

BIOMEDICAL ENGINEERNG SERVICES
SAFETY CHECKED

By

SERVICED
Date------------ By
Due----------------------------------

BY------------------------------DATE ----------------------------

CAL
Service Performed

70MM

MZZ1AWLGH0010001
MI Z1 AWL GH01 0001
62 | P a g e

PM

<!-- page 63 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

50MM

For service 1-800-123-4320

63 | P a g e

<!-- page 64 -->

Biomedical Equipment Management & Maintenance Program: Technical Manual

List of Contributors
State Representatives:
1.
2.
3.
4.
5.
6.
7.
8.
9.

Mr Narendranath K.R, Kerala Medical Services Corporation Ltd.
Mr Bryan Don, NHM Meghalaya
Dr Aruna Kumar, NHM Telangana
Mr Shivakumar, NHM Karnataka
Dr Ved Prakash, NHM Uttar Pradesh
Mr Neel Ranjan, NHM Jharkhand
Mr Praveen Singh, NHM Jharkhand
Mr Amit Karwal, NHM Rajasthan
Mr K Dhineshkumar, NHM Puducherry

Industry representatives
1. Mr Rajesh Jain, Instromedix (India) Ltd.
2. Mr Selvakumar, Mediciti Healthcare Services Pvt. Ltd
3. Mr AL Biren Chandar, HLL Lifecare Ltd
4. Mr Padmanaban, Faber Sindoori Management
5. Mr PR Srinivas, Faber Sindoori Management
6. Mr Vijay , Faber Sindoori Management
7. Mr Mahadeo, Faber Sindoori Management
8. Mr Chelvadorai, TBS India Pvt Ltd
9. Mr Ajai Dang, AOV International
10. Mr Vishwas, Kirlosakar Technologies

Secretariat
1. Dr Manohar Aghnani, Joint Secreatary (Policy), MoHFW
2. Ms Sunita Sharma, Director NHM – III, MoHFW
3. Dr Yuvaraj, Direcotr, NHM – I , MoHFW
4. Mr SD Nayak, Deputy Secretary, NHM – IV, MoHFW
5. Mr Niranjan Khamabate, External Biomedical Engineering expert
6. Dr SB Sinha, Ex- Advisor HCT , NHSRC
7. Mr Bhaswat Kumar Das, Sr Consultant, RRCNE Guwahati
8. Mr Anjaney, Consultant NHSRC
9. Mr Ajai Basil , Consultant NHSRC
10. Mr Vigneshwaran, Consultant NHSRC
11. Ms Akriti Chahar, Consultant NHSRC
12. Mr Mohd. Zoheb, NHSRC
13. Ms Kesari Thukran, NHSRC
14. Mohammad Ameel, Sr. Consultant, NHSRC

64 | P a g e
