---
doc_id: "adf7b7e4f124bef1"
source_url: "https://www.legislative.gov.in/static/uploads/2025/07/b5316613037ac03bb7afd63ae63db03b.pdf"
ministry: "Legislative Department (LD)"
title: "The Maintenance Orders Enforcement Act, 1921-2023010393"
date: "2025-07-01"
pages: 8
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a954698a94046688"
---

<!-- page 1 -->

रजिस्ट्री सं डी 221 Registered No. D 221
Jae AGIA Ae AG Axo
Hr ata es
पल
piv
Ceo)
सत्यपेय जयते
भारत का राजपत्र
THE GAZETTE OF INDIA
wilted <e7g
असाधारण
. EXTRA ORDINARY
जामाशावन
भाग शा - अनुभाग 1
PART VI - Section 1
wl & -SEPSHA >
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
aiftetae at eerie है
No.8] NEWDELHI, MONDAY, DECEMBER 24, 2018/3 PAUSA, 1940 (Saka) [VOL: 10
न१७०] नऊून लिल्ली, (मोशवांब, झिएफबब २8, २०५० / ७ शूछू, ५७8० (जैक) [५७४३ ५०
है Separzte paging is given to this part in order that it may be filed as a separate compilation
विशि जांक नाग Tate
(fata feet)
छबन-(शोसन जांटरने धंवर्डन जाधिनिग्वण, २७२५ (५७२० ब ५०)
७७ झूलांईे, ५७४७ डांविटश गशीविश्लमभान : co
CEE a eee nnn cnc न मम >>: टटटश-7 “7 _ _ *_ ** *  +  +++ +ऋ++

<!-- page 2 -->

wat-coret wont tata wit, seas
(saasa wftfiag seat sy)
APR GT
दाबासमूझू oper

> aig any ere fare > हि

२ । शबिछाया 5

७ | शाबरू्शबिक यादव ८वासना रे :

8 | शाबस्जबिक बास्तटक्तजड कया उबने-८भारुण WIC SST NGlge कबा R

@ | SITwS fin Sat -corest STEM Cae रे

७ । शावस्शबिक बाज्तटक्रअजज वाम कबा URE Race Tale Set- cones wre कबिवधल

Ape ARE TST x

4 1 SAR TRS Set -cones STOTT YD Bate seine SRST ge ATTEN FIST ©

& | SAT CORT ONT SAIS 8

» | SaT-cornest se waits waht celara ACS PST VTS VT YES ONS HOTS WATT 8
do | armen omftent छावा य्राक्रविज ज्लाटवकब शशान : 8 ;
>> | आडिमाक्राटवाब माता झ/व 8
9२ । नियश धभग्नन कबाद TST ५ 8

a —“—i—s—s~s~s—s—s—~—~—

<!-- page 3 -->

उबन-८भायन जादक्न धंदर्शन अधिनिग्रण, ५७२५
(५०४२५ब जथिनिग्रम सश्यां 9०)
> [५ जटशीवब, ४४२४]
) [ भावस्थबिक बाणाटकज,] [5 5 हु] ere Rew °[°x x x] धंगोड उरन-८शाबणव
आएत्नं, “[छावठ[|ऊ यनवदुकब॒न जून कबियटेन अबनि झगिनिग्रश ।
frag >[ शाबन्‍्भविक बालाटकज,] ' [5 » 7] जाक विभशेदड शगीछ उबण-८लासगव आाटकन “ [ उाबऊ] ऊ
यनवश्कबन मष्तन कबिवट्रैन अडैटरगा मपोशिन इस ; Bars Bars wa Malaise «or weak कबा छुछेक ३---
अहक्ति्ध नाथ ५ । (५) जद जविनियमथन ऊवन-टथावण जाटत्न वर्जन झबिनिग्रय, ५७२५ यूनि अजिड्िल शशय ।
wre fare)
© [(a) 2" [esp ere oriite arena aitcace] ss crrwades Rate 2 ।]
“ENT! ३ | अंश जयिनिग्रमर Rafe fear a MG core विकक्क कथा नाशाटक, ,
“शक्ति जविकाबिजाद नाग्रानग्र”” ग्राटन गूथा ८मश्टिफलि रछाधोश वा छिना मझीशव नाग्रालग्र ;
हि Corfe”? RIC eT TARE टन वाक़ि याव विकक्‍्टक्क उबन-टशायनब जाटनण कबा डब़, “ [शाव्थबिक बाका
८कज]७ रु उबन-८शाबनव जाटकन कया झग, (मई ठाडैछ दनव« शका विधि खनूसबि उबग-८शारण कबिव्टैल शशी झुड ;
. *[ CRU”? RI BF] STS SH ares VGS BA Crewe ATEN 5]
‘Sas Cas BC”? NCA AUTOR BIT Ba a Hes Utara acme Rem ais Rea
BA CTR BTM BT BW, COSA Ia TOT elise ऊबण-८शावगब शछि यनदाशिब rNs CTT TA
याटव कबा, मन्नकीकबनव अंग जाटत्गंब वाजिटबटक अँग BA at STO |
“Ride” we ok SARs Baw athe Pama war AS ; .
91 उबण-८लावण जाटमण थदर्सन (मश्य्याथन) झविनिद्रए, ५»»७२ब थाबा २ ब बांदा शजिहाशिऊ 1
२ । दियि आनूकूलन जाप्मश, >»»००१ दावा (नाथ का टेडटएइ ।
७। “जाने छांश मगूशऊ”'ब गाट्व जनुकूलन जाटमन, ३७०० दायां धछिछानिऊ
8 । “ऊाश्- | बाछ्ममभूद या”! शकटगी २७००ब अधिनिग्रभव शाबा ७ आाक जनूमृणिव घास (लाभ FAT ORE)
STB ATCT आाक उात्ञ-॥ TRH”? व वाटव उाञ-३ वाला (विधि) LRA, sess थाबा ७ आक झनूमूणेव वाया
ofits i
1 RR SRP जाएलन, >»९० य घाबा शणिशानि ।
१। छाभ-३ बाज (विधि) जधिनिय्रम, »»००व थाबा © ore BPP wa afd |
vy) Beso Sree senda (मश्ट्गाथन) जविमिग्रए, »»७२ग यावा © a we we |
हु bl St बाब्तमशश्व (विधि) अधिनिग्रण, ५७»५५व MAT © Gre PL ara Searels |
CE मा ााौाी ी यममायमयमम््म््म्म्म्भ्भ्भ्््भ्भ्भ्ट््टखध््श् ्टि जिस ननभभ ccc nnn nn ce WwW°WW”—”W”““—=$= : नशा :ण।ण।ण।ण।  आकऋहकनक्‍त्ई_________

<!-- page 4 -->

(a)
उबन-६गायन जाटर्ग aaa BARRA, yas
“sais enter)’ aa wares, ficaata KS GRIMS ACH Fea, CHAI ATS OIE CHAT
कबियोन शावस्शबिक़ याज्टक्रंजन छाया या छाब अधीनऊ नियृ्छ धायिकारी ; wre
)[“आवस्शबिक वाब्तत्कज”” माटन छावज्व दाडिवव ८काटना (7व या बाछटऋ, याव (कज, SR UATE eT
OF BAT GT CUI FAS SHA CATT ZT 1] है
शूट. x x x x]
भाबल्भविक ७। “ [यफ्ति rele aa eR I a RE (ऋण या बाछाटकुजब झिछवऊ ऊावऊ माग्रानग्रव पाया छिग्रा ऊबन-टशासन
SORT | CICA SHRI BCI SHOT TTT COAT CHT वालाट्कज विधिक Gerace Pr car” ce
ज्वकाटब, ज्वकशि ATH AS HOTS TAT CUT TRS Cl © oR aT HR CT ATTRA HFRS ATT
VI OTE OA NGS RSPCA ACA 2S |]
81 (9) 2B, ab उबन-८भासनंब ero, GR Uta oS ere HR BSS a TSR BSS, CAT 7
artis x
areas WMS TCS CIT UTES BRT, CHICA वाफिव विकटक निशा झु़, Ore CHET aot emits asia,
Fa wae (मंदे बाजाटकजब असन ममृण्ि शाविकाशेब rT, © CHET DARTH core ware, © HG Daa NGA ATCA
on * आदफ्भब आग शिनिशि * उादऊव ८काटना नाग्रानग्रव विड्छ शमाविकाशेटेन Bars ore Bare eew remo RAS
जानडछ.. त्रोडिछ शह्षीजृक कबा हद ।
EQS . .
कया । (२) थबन नाग्रानग्रंड ग/ऊ AP STC CT HCA ATTA MASS कबा झुग, यमि नाग्रानग्रव बाबा जाटात्य
मिग्रा शा, '८क्रीग छबकाबब मऊ वबिष्े खथिकाबिछाब ८काटना नाग्रानग्र अथन एफ नाग्ानग्र झःव, जाक aH aT,”
डेशाब मठऊ यविह जधिकाबिडाब ८काटना न्गग्रानग्र नड्य ८उट्छ मशक्रेष्ठ जधिकाबिडाब ८काटना ATT 2S | .
sree tl या ”जाबऊंऊ शका ८काटना नाग्रानट्य थर णगिनिग्रमव धाककनव शूटकरड AIF MIOCSR RSS ८काटना वाफिद
Sat 34 विकटद्य ८काटना उंबग-८शासगब जाटरग कबिछ्िन, जाक ८मरै न्णग्रानगटेन अडैटग शघानिर टशटछ ८य अटन वाकि, गाव यिखूटका
remy | SCENE ar Caer, Cod rem TERT MM a, नाग्रानट्य जाटर्वटरॉगद जज शमावि शिनिशि (मई *
CENT) rence Tabs aiterAta ceraera aca coat ज्वकाबैन शठिग्राद ।
arms ७। (9५) यज ८काटना खाटवनन, CHAT Ties Rag at war-crerma ans Saws Aes aoe
awe fad coral arate FARE, oe aa erie eel CRUE ICT Teme aE TBAT SE,
safes ATRIA, (मई वाक्िव खनृशश्जिऊ, यप्ि माष्का रुनाव शाप है, जाटवकनव माग्रऊ जद झुस, ८काटना जटन जाटरतन कविय
Reg PR RR eT SOAR OR वाझिखटन देशशकृछजादव नाग्रानग्र् फैशश्छि क्वपैन जवदइना कट, किल्न धटन (कडऊ
जामगत्रिक. आटत्थटोन ८कदन माग्रग्रिक इःद जाक ८काटना TST MRNAS CY GTS ASMA ATA बाजाटक्रजछ (काटना मशूण्छि हि
SAT CHONG TTT BRT YG FI ABT |
आटनल ® a हि
did (2) SCORE APR APT AS ATA HE GIA GAS ATT PR BT, CHATS PAV’, GF ATT
नाग्रानग्र4.. अडिसाक्ता GI R's OTe COST RUNES BAT "A |
Ws |
St Sacre eee ada Crone) oftay, sacat eto व थाया धणिहाशि । =
*। छाश्र-प बार्छ (दियि) झगिनिग्रए, २७७>य थाझ्र ७ ज्यांक जनूमूजिय घाव GT BH OR |
७। उबम-टभाशन जाएन्‍न cea (जश्टभाथन) जधिनिग्रम, ००५२३ बाबा 8३ शावगा शछिहानि ।
8 1 अपन ८घास्वाव याटव ere Aare Rae ere ore Be |
* ७९ । विधि जनूकूनन जातमन, ५»७११ घाव गछिछाशिऊ 1 .
७ । छाश्न-व बाज्ममशूद (विधि) अयिनिग्रम, >»»००व थाबा ७ आाक जनूमूतिक घाबा शिकलानिझ ।
१1 विधि जनूकूलन जातमथ, २४०११ ““र्जनव CRAIN” A RAS after |
wl ate OOM घाया “(छ्ंब' गणन झानरऊ शणजिछाशि |
»। छाश्र-व बास्ममग्रद (दिवि) अधिनिग्रम, २७०७ व थाबा ७ आक जनूमूंगिव दावा शजिछ्रानिऊ ।
so) RR SE OM, sess an ““म-शविस्त शर्डनव (अटनटकल!' अव्फ्ममूह शजिहाशिऊ ।
< . है
_ _ Neen तरतअ लत कलर सर रु

<!-- page 5 -->

-_
(७)
उबग-८शायन जाटएण शरर्न झशिनिग्रण, ५४२४
(७) य”ऊ जटन TCT BTC छा डग्, नांग्रानट्य शाबश्लबिक बाणाटऋदब जशूछ्छि शाधिकावीटेन ८/दभ कबाव
याटव [erty छवकाब] ta a T'S ८काटना वाफि, याव विकटःश झाटएन कवा टशुप्छू दा कबिवटेन खडिकथिछ झुस
GAA CR AI TF RD AH HI SATA OA A CTS COMET SATS SMS VACA,
a Rais, ae erg STMT Sar Cafe CAR छम्नमण मशकउाट्य Enh Say Caer OTS VAIANG SS
जाशिन जाक टन मुछना गिल्टव HY cates BANS IATS Ya Fa Tes Te CHSa Beary facy ASOD FR
अडियूछ कवा झड़ ।
(8) VS GAT ACA FARE GI, HPSS ICA TAT ATOMS ARTO ८काटना न्गाग्रालग्रन
ICR WF OTOP ICT CHE नाग्रानबब दावा मशक्रिष्ठ अधिकाबिछा शका नगग्रानग्रटन (भवन का डब, यिट्य्र अछिबिक जातक
पनाबाव स्याजनाटर्थ जादल्ग मिट्ग्र, RR area, RRS GRA fran aw, HPN DSS APT aaa ISIE BA
OIE TA SCAR FATS ATIC HHP BATAAN ICT BF I
(५) यमि धन माक्ता खानी नाग्रानग्रऊ ART She za ca TCM Sa SPS cy ATR, ANTATEACT
आटसगए TR कबिद भाटव किछ जान ८काटना ८ज्राष्यठ झजिमाकऋा *[८कठ्ेम ज्वकाब] ऐल नठिछंता झ!द झाक मृन खजिजाका
. RCH TP वीछिछ जश्वाइशूछ कदा |"T |
‘ (७) G3 Mae BRAS HA CHICA SICH HRA, HR STE RASA TT BA CHICA HPS
जविकाबिठा थका नाग्रानग्रब (काटना ऋशऊाक शादी नकबिय 8
1 OTC CICA MRS aT HBSS ARTETA, Bae SBT IAAT SKE orem AUT
safds anfterite coats 1a * [(कन्ीग्र एबकाब] टन Bara 2s yer rec IG Fal Caer aI Acbea ACEI
erate ice Baal Cala wre CTCL शविद्र्डन कदा ८काटना जाटल्गब CHAS, SICHNCGI OIC BETS
नाशाकिव, यप्टिद ज्राक Camas ONE TT STMT ACM, TPT HSS HHA AAT |
छायडबव. १। (५) य'छ ८काटना नाग्रानग्रव दावा ८काटना ARS ATT HRAS AF) BII- CMT HOP SA HIF VS
eer HORNE (कवन FATS BN जाक शजाद नाथाटक यम्टि९ जारू ८यिग्नाटरैलटक “[छाबड]ऊ मश्क्रिड जविकाबिझा शका जन
८भाबनब. माग्रालग्रद बाबा मृछ कया नश्झ, झाक मा्क्रीसकनव झडिमा'्की जाक विवृिमश सिट्वावव जाथावऊ जाटकवए जाशडिजनक
SEL AG area, *[coita waar] ta cores Fa 84, आाक थरेटी * [८कड्ीग्र ज्वकार]ब शडठीऊ दवा ८य, वाफि, गिक्षमव
जशक्िर. विकटक्ष जाटल्थटॉग कबा tay, “[ors ja ahr इग, “ [८कशिश छदकाटव, ] मश्क्रे्ठ छधिकाबिछाब (काटना माग्रानग़ब ;
अविकानिजा विडिछ शाधिकरिट्रैन फैक हहाटवजमशूब जविधश्नमझ शठिग्राव, व जाटमणर्क़ा किग्र मृएठ मइद काबन प्र्थीवदेन दाफिझनक
arta SIR कबि ८काटना मन जाबि कविय जाक ac FEISS OTe BRIE STS ANTE OTA BIA SIS BAA खाक
FAST ako aces Tie Grae ois BRAC Bas SHAS Be |
(२) >श-धांवा (»)व उधोनछ खाबि कब! अयन मन मकटना शंट्याजनब वाटव डैग्ाब शुन जकिक आअधिकाबिजाब
: SCHON नाग्रालग़्व TT BR aT ae oH ZH 517 B'S |
(0) Bate, akebr ata ya wide, lets can aS Serr sata oA wa sar
. tata, Rcd cod am oriaie Sar ScackaR, af cod BIE UT rs VACA a IT STH
८नाट्शवाटैक जाक नाग्रालग्रब शा (लावा शमानशज, सिट्य काबन वर्ना कबि, माभग्रिक खाटएण फिटग दि काब॒बब 8शवऊ
ICT ATS VMAS Say CLA AT ca BB, wea विकटक जाटत्पय्ा कवा टेशछिन, कार्यवशिछ (काटना शब्क जाशिन,
BIS GAC PORTS APRS Sa CA SAAS, MATA STA झुग, गिट्वादब 3भवऊ जरा लद थाट्व ।
(8) यप्ति SATA Bae ज्तदि कबा वाझिजटन शजिव नद्य वा AR CARS STMT HG कबा फैण्छि नड्य दूलि
माग्रालंग्रक जन्नडे कबियटरेन अमकल डग, माशग्रानट्त्र,  [ऊावऊ]७ जन्ध्यछि वलव« शंका (काटना विधि छावा डैग्राब कशऊाब —
SATS IATA ८काटना OHA AT VHT ACTS, AP खनाव था, भवितर्जन नकबाटेकट्य या शब्दिर्जनमझ जाटतगदग
पूछ कबिद शाटव ८यटनछटब नाग्रालग्रव नाग्रमकरऊ ८वाद डग ६ :
oN लपमननन+-+-न-सनमलन नमक 3 न न कफ कल ५-ग-_-०२००२००न> लग“ अनननलत+«+9»9».
हे ५ । विधि खनकूलन जाटरण, >>०१३ पाया ““स-शविदत Aa CITA ee BAT चंजिशाशिफ ।
२1 दिवि जनूकूलम आाटनन, ५७०११ घरादा “श्र्डनव (खटनटबल”” जय अमूझव शान शजिहासिल।
७1 “शाज्जमगूदब”'द याटव उाञज-व बाझ्यमशद (विधि) अधिनिम्रम, ५»०४५व थाबा ७ खाक जनुमृशिक चारा शैजिछानिछ ।
a

<!-- page 6 -->

(8)
Wa Corey BCH RSA SAAT, Sd2>
HAE OT ATM, GR TATA HAS, ATT ACHPTT AAS PASH GHG CAM A AAT GSAI- CMV HON
BARAT Ha] ART A ACATACA GRACIA AA |
(०) यहि वाफिसन, गिछतमट्रैन छमन झाबि कवा टेशछिन WAS Bs Vers AIRTETTS मह॒ड़े कटव ८य धंछिव'फाब
ACA SCT ATT CONBACDT Cota BANC जाठशाक डञ़, मग़्ग्रानट्य ८काटना झडिबिक APH HIM ACT
IMS ere SRR, WIS ARIAT CHE ITS IA HAS aTeCRE ABS afters cuca
oR ammeter cease ana (rate rae] ta wiser ae शशानिऊ शंडिनिशि शिय्राव, खाक कार्यावाशि
afte afte orca
(४) यःऊ अं थाबाब अंधिमऊ ८कांटना मामग्रिक जाटफण पृ TAT RR, aR APT ASS शविद्र्जन या बल कबिय
I ERT <रैटंग जाकछनिटछ मृकबन नग्रानग्रव SPAT FAT CCK TF YS AHA वा TSA TCT SCT
GAAS AMES HSE VI (य, CMBACT ATTA Calg SAIC STS Ba, aT (काटना खछिब्सि जान्‍्का
CART ercarenentced ares acre FRR, CHR ATTEN CR. ICTR aCe TOMAS बाजाएकजब मभूछ्छि शाविकरिव
ध्याटशमि ८महै क्ताग्रानग्रएन ८धंबगव वाटव “ [८क्षीग़ छबकाब]ठन झडिटनयब शब्रानिउ धछिनिनि शम्थग्राव जाक कार्यावशि -
eit aa oes I
उयन-८शागनव ० (५) अ*े जथिनिग्रशव भवक्तावनीव माटसटक, य/ऊ जाँग़ जाटफन अड जधिनिम्रगव जधिनऊ ७यन एफ नह़ंग्रानग्रऊ &
जाटमगब॒ ASS Va PAK, जाटत्वट, जटन शक्षोग्रनव ऊाबियब शबा, ममृ| कशऊ वनव९ थाकिव जाक शवों <*व, जाक ST
वजयध्कबन । ५,बऊ जकटना कार्यावशि ८नावा इव ८यनिवा अर शैग्राय शिडिन जविकारिंडाऊ फैक़ ना़ग्रानग्रऊ वा अरे मटलाँ एक
ORT SAT A Ra aT RR Sos area aR aca cot PBA ATES UAE AIS SAT aI
TOPS TRS, OT HR माग्रानग्रव उमनूमाटब आाटत्व वनद< कबिवदेन ऋणशएऊा शाकिद ।
(२)मशफ्रि्ठ जधिकाबिठाब जश्न नाग्रानग्र यःऊ अंक जथिनिग्रशव aw Gh SoM NBloe a1 Cee या
A GAT थे झाटन्न थडे जदिनिग्रणब जोन Hy Sar Caer Tare अटन नग्ग्रालग्रद श्तधिकरोमकमन विड्डि कबा ACA,
HMC TAS, FATS ACMA ATA PST UTA ON AC PSAP TMT BART |
ऊबग-८नागव »। अरे जथिनिशग्रगव एैशवदक्नद जअनूसबनऊ उबग-८शायनब ah BOM NESS Fa GTS YORAM SATS CHITA
अधिनिगीेज गन निट* फिव ८य नाख्रान्टेन ८!बषव वाटव <शुद्धा शदह य/द शवा ITM corel Cafe वा विद सामग्रिक
धनवाणि BICC कदा टेशछिन, यशाशिछि, उऊबन-८भाबण कटल जधिनिवोठ थनवाशि वाक्िद द्वादा याव विकटझ जाएक्‍नर्टत जप्नम्टव
re कब टेशुशिन दा मृए कवा टेशुछिन, धावि कबा A’G GTS HEI CHAS ACM AT AIPA GARG GAS CaM TTF
आन बग5 APT NSS acs Or वाग्र जाक शजाब OSS Ta GTN Sal VA रिमटव नगग्रानग्रद घ्रादा जधिनिषोछ दा ऊकशिऊ कया
OTe TETAS BEY : .
आताग्र 1 .
जााग्राणग्र*र ४०। थरैजधिनिग्रमव शंट्याजमाटर्श  [डादऊ[द वाडिवऊ बन नाग्राल्ग्रद अझन नाग्धिण या शपाधिकाशिव छावा ्राक्षबिल
सह विकॉमोब डुनि जादथगिए (कादना ग्खाट्दज, शडिकृल शशान नकवांदनट्क डैग्राक ग्रापकविछ कबिवनश्रीग्रा ऊँभश्छ शका Bisa as वा .
reefs OVS DRA ज्ाक्ररव धंमान दिना थट्नमटव द्राक्रबिउ कदा टेडटुछ दूनि भरगा कदा IT TE CHAT ATER TTT
मक्ाट्वकब याद दावा I RITA AAG SAE, ABA erie ATAATS GIT ACTH WHA FAI AIMS TYPOS
watt अप्ताथिकाशी वृनि क्षण कबा BS | :
जअडिमाकराट्वाव ५५। अर जधिनिग्रभव शट्यांजनाटर्थ, (काटना MNS TC HAS LIA ATS CATT SSAPHITAAS, AR
साक्ता झ|य। aR eT ART CHAT HPS SRST नाग्रानग्रठ कार्यावशिऊ मात्का शडन कबिद शाट्व ।
निग्रम शनग्रन »२। ([(३)] '[८कह्ीग्र छबकाटब] “[छब्कडि दाज्लंजऊ जविमृष्माद घावा थड ARTE CARCI HEI FATS
Ser Beare Pama धनग्नन कबिव भाटव | खाक विटनबऊ: «रै अगिनिग्रमव जधीनछ कबा ८काटना कार्याव वाग्र वा धडाब निया
Capea aca wre RRs sata Aeahe a aT ene मकटना awe area Mane ata SERS ACT |
9 । विधि जनूकृलन जाए, ५»७११ दावा “म-शबिसत शर्उनव ८जटनटगल”” ee BAS afore |
३२1 छात्र य-गाछ्त मगूद (विवि) झिनिग्रए, २»७७०व याया ७ आक जनूमृणेब घाबा शछिछेनिऊ ।
७1 धात्याखिऊ विवान (मश्टभाथन) जशिनिश्रम, २»०७व वाया २ आाक जनूमृजित घाया (मई धाबाव ऊँस-धावा (७)बव फ्टव शून३
जश्याकिए कबा टेशटएइ (५०-७-५७७०४ शंगा थावी ८शवाप्रैक)
81 Sar comes erent tase Fm, seed Ts |
ee

<!-- page 7 -->

(@)
BR - CTR BCI eG MTA, yd2>

१[(२) अंश जविनिग्रशब झधोनऊ ८क्लिग्र ध्बकाबब दावा शवोऊ श्छाक निग्नश डेशाक शगग्नन कबाब शिष्छ रथानीट्छ
जअधिट्वशन OF Fal TS aay ARE TENA a Crores wm Geeta she Ba rai HD ft fea
BAS AC HATS ACSI HHS SAT BA A’S, GTS Hherg Gricans Rew Sass rea GSA a
Bans Beery Gane yal Gora Rae ८काटना मान-मननि कबिवैन aS Sa aT Soy A HHS
wr @ ay gma afag arenes, cous UM Pigs निम्रभदती (कदन धटम जान-जननि कशऊ शाती शव वा यशाहिडि
FSS) RS 5 CRT REIS oA Ta a a वल्कबन, ८महै निग्रश्व झशीनल शूटवर्दकृछ ८काटना कार्यीब दिविशानाजाद
SHAS HEPA AST ८नट्शटनावाटैक रद ।]

५1. शजाद्याछिऊ विधान (अध्टभाथन) अगिनिग्रश, pro a Mat 9 Gre CDE TET (मछ धाबाव ऊश-धावा
SAAC PE HAMS Sa CAH (d¢-0- yav-9s Hor cya) | .

nnn HWHWHWH7TTITT___m_ ss खःःःआ््ः

<!-- page 8 -->

(७)
डाब्रेशजिटइ छबग-८नायन याट्रुम शवर्धन झविनिश्वश, ५४२५ (५४२ ४४ झधिनिग्रश मश्णा ५४)ब उशटदाएक
अमशीग्रा जनूवाम, शायिकृछ भाठ, (टकन्तीग्न विधि) झंधिनिद्रण, »४१७व धाबा ३२ व च७ (क)व उंशिेनड बाजनखऊ
धकाशिऊ कबाब काबटन शाथिकृछ कबि म्िह (५४१७ब जथिनिश्वश मश्या ७०) ।
ap Fe मष्वि, छाबड उबकाब
ऊाबिथ 8
The above translation in Assamese of The Maintenance Orders Enforcement
Act, 1921 ( Act No. 18 of 1921) has been authorised by the President to be
published in the Official Gazette under clause (a) of section 2 of the’ Authoritative
Texts (Central Laws) Act, 1973 (Act No. 50 of 1973).
G. NARAYANA RAJU, :
New Delhi Secretary to the Govt. of India.
Date: : *
Slaw कक कक इटक यमय 5क्काव (क्शिन FOIA) Bal HENS Ola OH DATA RHMIATS YS, SAAR >, 28-92-90
