---
doc_id: "accc153d625d0aae"
source_url: "https://mnre.gov.in/static/uploads/2025/08/725046280d03efadd14442fbac3aebd2.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Simplification of Guidelines for the implementation of PM-KUSUM"
date: "2021-12-14"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "52caccbddec78076"
---

<!-- page 1 -->

F. No. 32/54/2018-SPV Division
Government of India
Ministry of New and Renewable Energy
sok

Block no. 14, CGO Complex,
Lodi Road, New Delhi -110003
Date: 14 December 2021

Office Memorandum

Subject: Simplification of Guidelines for the implementation of PM-KUSUM.

The guidelines of PM-KUSUM have a provision for centralised tendering by an
agency of the Government of India for price discovery and empanelment of vendors for
installation of standalone solar pumps under Component-B of the Scheme. The objective is to
take advantage of lower prices resulting from aggregation of demand and economies of scale.
However, it has been observed that the said process result in sufficient vendors not being
available in some States causing difficulty in completing the sanctioned capacities within the
given time limit. After careful consideration, Government have decided that States may, in
addition, invite their own bids for empanelment of vendors for different regions in the State
for installation of standalone solar pumps. However, the ceiling price for the bids in the State
tender would be the price discovered in the latest centralised tender,

2. During implementation of the Scheme it has also been observed that the present
timelines prescribed for completion of sanctioned capacities is often not sufficient and States
are seeking extension for completion of targets. In order to give sufficient time to States for
implementation it has been decided to increase the implementation period to 24 months from
the date of issue of sanction for all three components of PM-KUSUM. Extension beyond 24
months will be considered as per provisions of the Scheme guidelines.
3. For feeder level solarisation the Scheme guidelines have a provision for incentivising
farmers who consume less electricity than the benchmark consumption, by paying them per
unit for the consumption less than the benchmark. This provision encourages conservation of
groundwater as well as electricity. Some of the States have indicated that for a feeder being
solarised not all farmers may be willing to install meters necessary for availing those
incentives. Government have reviewed this provision and have decided that availing the said
incentives under the scheme will be optional for the farmers. The DISCOM will inform the
farmers about the benchmark consumption and amount of incentive per unit which they can
avail of in case of lower consumption. However, it will be the farmers choice to opt or not
for this facility. MNRE will prepare and circulate the formats for informing the farmers and
obtaining their option to avail this facility. .
aA
Scientist-D
To
All Additional Chief Secretaries/Principal Secretaries of
Energy/Renewable Energy of the States
