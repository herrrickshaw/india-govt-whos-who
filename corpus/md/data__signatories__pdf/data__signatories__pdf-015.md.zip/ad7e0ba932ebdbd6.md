---
doc_id: "ad7e0ba932ebdbd6"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/1acf055886ed4c856ee72ed27b51a892.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "FCA - Comparative Figures (Post Policy Period)"
date: "2025-07-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7b22022e52d4f9fe"
---

<!-- page 1 -->

Foreign Colloboration Approvals - Comparative Figures (Post Policy Period)
-----------------------------------------------------------------------------Post-Policy Period
<------------------------------------------------------->
(1st to 7th Years)
8th Year
Total
(August '91-July '98)
(Aug'98 - May'99)
(Aug'91-May'99)
-----------------------------------------------------------------------------1. Total No. of Foreign
Collaboration approvals i) SIA
3015
118
3133
ii) RBI
4891
392
5283
iii) FIPB
5663
927
6590
TOTAL
2. No. of FC approvals
(Technical) approvals i) SIA
ii) RBI
iii) FIPB
TOTAL
3. No. of FC approvals
involving Foreign
investment i) SIA
ii) RBI
iii) FIPB
TOTAL
3. Total Amount of
Foreign Investment
involved (Rs in Billions)
---------------i) SIA
ii) RBI
iii) FIPB

13569

1437

15006 *

2095
3205
200

109
294
6

2204
3499
206

5500

409

5909

920
1686
5463

9
98
921

929
1784
6384

8069

1028

9097

37.0
133.4
1526.0

0.4
3.5
254.0

37.4
136.9
1780.0

TOTAL (In Indian Rupees)
1696.4
257.9
1954.3 *
-----------------------------------------------------------------------------Note : (i) 1 Billion = 100 Crores
(ii) "*" -- includes 60 proposals approved by FIPB
for Global Depositary Receipts(GDR)/Foreign Currency
Convertable Bonds (FCCBs) involving investment of
210.72 Billion
SIA

- Secretariat for Industrial Assistance

RBI

- Reserve Bank of India

FIPB - Foreign Investment Promotion Board
------------------------------------------------------------------------------------------------------------------------

FOCUS MONTH – MAY' 1999
FDI APPROVALS May' 99
(a) Total (FDI + Tech.) (Nos.) 159
- FDI Approvals 107
- Technical Collaboration 52
(b) Total FDI Amount Approved 9879.11
(Amount in Rs. Million)
(c) Share of top 5 investing countries in FDI approvals :
Country

Amount

% share

(Rs. in million)
Japan

5623.52

52.92

USA

2054.90

20.80

Netherlands

455.18

4.61

Saudi Arbia

351.30

3.56

Singapore

294.45

2.98

d. Sectors attracting highest FDI during the month :

<!-- page 2 -->

Sector

Amount

% share

(Rs. in million)
Transportation Industry

6780.62

68.64

886.01

8.97

Fuel (Power & Oil Ref)

571.30

5.78

Glass Industry

400.00

4.05

Service Sector (financial & nonfinancial services)

205.40

2.08

Electric Equipment
software)

(Computer

II. FDI INFLOWS :
May'99 - May'99 - Rs. Million 382.46
(a) Share of top 5 investing countries in FDI inflows :
Country

Amount

% share

(Rs. in million)
Mauritius

1337.65

14.26

USA

983.91

10.49

Netherlands

640.87

6.83

U.K.

310.97

3.31

Italy

182.39

1.94

Amount

% share

(b) Sectors attracting highest FDI inflows :
Sector

(Rs. in million)
Electrical Equipment (computer
software & electronic equipments)

819.67

8.74

Metallurgical Industry

448.65

4.78

Transportation Industry

443.77

4.73

Food Processing Industries

302.55

3.22

Chemicals (other than fert.)

254.59

2.71
