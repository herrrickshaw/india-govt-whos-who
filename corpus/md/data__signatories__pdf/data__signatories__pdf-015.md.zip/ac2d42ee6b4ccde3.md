---
doc_id: "ac2d42ee6b4ccde3"
source_url: "https://www.dahd.gov.in/static/uploads/2026/04/4c88bb88f285301cd623194c4b2afce0.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "RTI Order 03.05.2023"
date: "2023-05-03"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ec71c4c4e1b1562a"
---

<!-- page 1 -->

. LL MOST IMMEDIATE
RTI MATTER
File No, 0-1101312/1/2020 -RTI
Government of India
Ministry of Fisheries, Animal Husbandry and Daitying
Department of Animal Husbandry & Dairying
Krishi Bhawan, New Delhi-110001,
Dated the 03" May , 2023
ORDER
In partial modification of this Deparanent’s order No. O 1101312/1/2020-RTI dated
15"November, 2021, the following officers are being designated as Central Public Information Officers
and Appellate Authorities in respect of the specific subject matters mentioned against cach in the
Department of Animal Husbandry & Dairying :-
Head Quarters:-
IName, designation & address(Subject Allotted jame, designation & addtess|
रण पार Central Public] lof the Appellat
nformation Officer (CPIO)| Authority(AA) with Tel. No.
with Tel. No.
fl. |Shri Naveen Kumar, Section Personnel Administration — including|Shri Madhusudanan V. K, Unde:
Officer (Estt.) (HQ), Room No. {Establishment matters of the officials Sccretary (Hstt.) (HQ), Root
435, Krishi Bhawan, New Delhi. and staff at headquarters. Matters{No. 532-A, Krishi Bhawan, New
Tele. No. 011-23384857 relating to reservation of SC/STsJDelhi. Tele. 23070149
AX २9 Backward Classes,  Ex-setvicemen,
है AN Physically Handicapped _persons|
including compilation of information,
eports/returns thereof.
Shri Vikash Kumar VikrosyA matters pertaining to Gener:
Section Officer, Room No. 531,Administration.
Krishi ee New Dd Administrative work of all AQCS Shi 5. C. Stivastav, Director
(Estt) (HQ), Room No. (| be
wri 432-A, Keishi Bhawan, New
M Dethi, Tele. 23383340 wy fea

3. {Shri K. S. Rawat, DDO (CASH) [All matters pertaining to Cash Section. | Shri Ram Partap Sinha, Under
IRoom No. 435-A, Krishi Secretary (Cash), Room No.
Bhawan, New Delhi, Tel No, 529, Krishi Bhawan, New

Ay Delhi.
(011-23388630 aly

4. [Shri Shailendra Kumar, Fodder [Technical work of Feed and Fodder andShri Vijay R. Thakrey, Directo
Agronomist, Stilt Floor, Regional Fodder Stations (RFS), Stilt Floor, Chandralo!
\Chandzalok Building, Janpath, ५ Building, Janpath, New Delhi.

lew Delhi. 9 “
ZY “

5. [Dr. Ani Bency Jacob, Animal Matters pertaining to Livdstock|Sha Sarbeswar Majhi, Deputy
Nutritionist, Stilt Floor, Insurance Secretary, Room No. 398,
Chandralok Building, Janpath, Kush? Bhawan, New Delhi-

hi 110001, Tele No. 29388534
INew Delhi. = पर

Il Matters pertaining to Al by Dr, H.R. Khanna, — Joini
jutrition ॥ [Commissioner (AH), 2“ Floor,
& e|Chandralok Building, Janpath|

AC ew Delhi

Dee ~
EGE
O [ ८ ode

<!-- page 2 -->

—2-
Shri Manish Kumar DiwakarJAdmn (NLM) (Administrative worlf Dr. H.R. Khanna, Joint
inder Secretary, (Admn.V1), Stilfof CSBF Hissar, Poultry, Feed & Fodder] Commissioner (AR), 2" Floor,
loor, | Chandralok Building |Stations, Chandralok Building, Janpath,
anpath, New Delhi. New Delhi
ux All Matter related to Kaamdhenu Aayog | Dr. Vinod Bhatt, Director,
(9 ८2 R.No.346, Krishi Bhawan,
eee?
०5 : New Delhi
ll matter pertains to Animal WelfareDr 3... 5 Dutta Join
‘oard and Cow Slaughter, CPCSHA &dCommissioner (AH), 2“ Floor,
INTAW (Chandralok Building, Janpath,
INew Delhi.
Tr. Lipi Sairiwal, DC, (Poultry)Technical work of Poultry, Poult
Stilt Floor, "१३०६८ uilding JDevelopment, Central Poult
janpath, New A i Development Organization and Cent
092. [Poultry Performance ‘Testing Centre
6
Dr. Anirban Guha, Livestock work related to Sheep and Goat
Officer (AH), Room No. 153, evelopment, All work related to Do; SL. ae
Keishi Bhawan, New Delhiand Cat, Technical work relating to] ९.०2 7
Tel. No. Ol1 23386318 Equine and Pack Anitnals, Pig Unit, aN”
(Meat, Meat Product
(Dr. Chandra Bhadra, Assistant technical matters related to Rashtriyal Dr. Bhushan Tyagi, Deputy
(Commissioner (Catde), Room okul Mission and Central Frozen! Commissioner (AED) Room *}
INo. 501, Krishi Bhawan, New Semen Production Training Institute No. 479, Krishi Bhawan Tel. ( \ 23
Delhi, Tel:- 23389876 No. 011-23383699.
a, |All technical matters related to, Central] Dr. R. G. Bambal, Room No.
gee NW Herd Registration Scheme, Central Cattld 346, Krishi Bhawan, New
on Breeding Farms Delhi, Tele No. 23097013
Dr. Sulekha L, Assistant |All matter relating to Credit, Extensio
Commissioner (CE&P), Room [and Publicity (CE&P) Division.
INo.544, 5" Floor, Krishi
hawan, New Delhi के
Dr. Debalina Mitra, Asstt|AN matters related to NADCP & FMD [Dr Sujit Nayak, Joint
Commissioner, Stilt Floor, (Commissioner (1.H), Krishi
Chandralok Building, Janpath, Bhawan, New Delhi.
|New Delhi
N12. \Shri Deepak Sethi,  Under!Adminisuation work pertaining tolShri K.P. J. Gerald, Director.
Secretary (Admn-IV)., Roos \CCBF, CHRS and CFSP'1T. Room =No. 432-A, Krishi
jo. 491, Krishi Bhawan, Nev — - — Bhawan, New Delhi, Tele}
(Delhi.Tel. No.011- 23386099, Administration work pertaining — to/23389606
INDDB & DMS, Vigilance matters
4 vi 2 है ग
Y 5 Jam Css
2/ Los is

<!-- page 3 -->

13. |Shti Dayanand Appa SawantJAll Technical matters of  Daity|Shri Chinmoyjit Sen, Deputy|
Assistant Commissioner (D1D)JDevelopment Schemes. (Commissioner, (DD), Room No]
oom No. 501, Krishi Bhawan, 334, Krishi Bhavan, New Delhi.
lew Delhi. Tel. No. 23389876 \Tel. No. 23389206 हे

14. Ms. Vandana Gautam, Deputy[Plan Coordination, Work relating to|Shri Sarbeswar Majhi, Deputy
Director (PC), Room No. 544. VY, NMPS and Annual Report, FivelSecretary, Room No. 398, Krishi
IKrishi Bhawan, New Delhi. ear Plans, Annual Plans, matters|Bhawan, New Delhi-110001

relating to Parliamentary Standing{Tele No. 23388534
(Committee on Demand for Grants

15. |Shn Siddharth Shankar] All matter related छा Genenal a
ISSO(GC), Room No. 298-B,Coordination, Administration Reform &
lXtishi Bhawan, New Delhi Tele/Public Grievances, and Citizen charter.

INo. 23384030

1G. |Sher Madhusudanan V. K, matters relating to Internationall Shri R.K Gupta, DS, Room
Under Secretary —_ (Estt.) (Cooperation (IC) No. 586-A, Krishi Bhawan,
(HQ), Room No. 532-A, iNew Delhi
Keishi 7, Bhawan, New matters relating to Information|SAei Sarbeswar Majhi, Deputy
Dethi. Tele. 23070149 ‘echnology Secretary, Room No. 398,

Krishi Bhawan, New Delhi-
110001, Tele No. 23388534

17, [Shri Ram Partap Sinha, UnderxjAll matters pertaining to Parliament shri S. C. Stivastav, Director
Secretary (Cash), Room No. 529, (Estt.) (HQ), Room No. 432-A,
Ktishi Bhawan, New Delhi. IKtishi Bhawan, New

Delhi. ‘Tele. 23383340

All matters pertaining to RTI. Shri R.K. Gupta, DS, Room

lo. 586-A, Krishi Bhawan,
|New Delhi
atters pertaining to APAR Shri K. P. J. Gerald, Director,
IRoom No. 432-A, Krishi
shawan, New Delhi, Tele:
3389606

18. Ms. Swati Melt, Assistant All matters relating to OfficiallSha RK Gupta, DS, Roo:
WDirector (OL), Room No. 557JLanguage. No. 586-A, Krishi Bhawan,
Krishi Bhawan. Tel No. 0114 lew Delhi
23070319.

19, [100.. Aniraddha = PadmnakarMatters relating to Trade and] Dr. Gagan Garg, Deputy
Udaykar, AC (Trade), 2" FloorjInvestment, Veterinary Pharmaceuticals) Commissioner, (Trade), 2"
Chandralok Building, Janpath and Biological and Health Protocol. Floor, Chandralok Building,
INew Delhi. Tele No. 011 ye le anpath, New Delhi
23097034, Nowe 0: Jes

20. Ms. Ritu Singh, AssistanqAll matters pertaining to Animal) Shri V. P. Singh, Director
irector, (AHS), 2" FloorjHusbandry Statistics & ~~ Livestocl (AHS), 2% Floor, Chandralok

handralok Building, JanpathCensus. Building, Janpath, New Delhi-
[New Delhi.

1. Shri B. D. Panwar, UnderfAll Matters pertaining to Finance. IMs. Anandi Venketeswaran,
Secretary (Finance), Room No| Director (IFD), Room No. 586-
417 Krishi Bhawan, New Delhi] |A, Krishi Bhawan, New Delhi
Tele No. 011- 23382863.

<!-- page 4 -->

. Ge

22. jS_. CL. Gautam, UnderAll matters relating to Budget
Secretary (Budget), Room No|
4479-86, 4" गा Krishi Bhawan,

INew Delhi RAL ०"

23. |Shri Manish Kumar Diwakar|Administrative matter relating to NIAH | Dr. RG. Bambal, Joint
JUnder Secretary, (Admun.1I1) Commissioner (AH), Room
Stilt Floor, Chandralok Buildin, No. 346, F' Floor, Keishi

anpath, New Delhi. Bhawan, New Delhi
Ph;- O14-23097013 हे
124. [27 Aruna SharmaJAll matters related to RDDLs/CDDLJDr. Sujit Nayak, Join’
eputy Commissioner (LH) SilHOIE/FAO/USDA and Risk Analysis Commissioner (LH)
loot,  Chandralok Building,imatter related with application fo:
anpath, New Delhi, License of drugs and vaccines, Avia!
influenza, matter related tol
eview/revision and framing of sanita!
regulations/health certificates for import]
lof livestock and livestock products,
fmatter related to International
Cooperation.
5. |Dr. Surender Pal, Deputy |All matters related to CSF-CP, ESVHD.
(Commissioner (LH), Stilt Floor, ASCAD, Mobile Veterinary & healt!
Chandralok Building, Janpath, |Camps- New EFC & related matters ani
lew Delhi Krishi Bhawan, [all matters related with PED and LSD
INew Delhi.
Sage fatter relating to Veterinary Council off De R.G. Bambal, Joint
43 India, Commissioner (AH), Room
° No. 346, F' Floor, Krishi
Bhawan, New Delhi
Ph;- 011-23097013
2. These Orders will come into effect from the date of issue.
® xe Pratap Sinha)
Under Secretary (RTT)
To,
1. All officers /Divisions/Sections/Units in the Department of Animal Husbandry and Dairying
2. Technical Director/Senior System Analyst, NIC-AGRID (DADE), Department of Animal
Husbandry and Dairying, New Delhi with the request that the above information may kindly be :
put on the website of the Department.

<!-- page 5 -->

_. FOND On HOLS EYP] /Aeee- KIL Sy:
Copy for kind information to:-
1. PS to Hon’ble Minister (FAHD) A Wibs
2. PS to Hon'ble MOS (SKB) (FAHD) a ot
3. St. PPS to Secretary, AHD— OG La 8५10९ s\ne 23
4. PS to AS (V))/ JS(OPC)/JS(GNS)/JS(UB) /Adve. (Stat)
2 : flies ln
bf > Nya wm / Wes
(sl? von °
1० “ey &,
to
5.4 4 .
