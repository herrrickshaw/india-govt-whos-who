---
doc_id: "ab2f6deba129d0f6"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/ee92f2317c148f63d71a391085209e35.pdf"
ministry: "Tourism"
title: "Tender For Design And Construction Of India Stand At Various Exhibitions In Uzbekistan, Romania And Greece"
date: "2019-10-21"
pages: 12
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "dd7763384aae10ee"
---

<!-- page 1 -->

1
India Tourism Paris
(Ministry of Tourism, Government of India)
13 Boulevard Haussmann, 75009 - Paris
Tel: 0033- (0)145233045 Fax: 0033- (0)145233345
EMail: directorindiatourismparis“ gmail.com
IT.Moscow/Stand Construction (2)/2019-20 Dated:20.10.2019
NOTICE INVITING TENDER
India Tourism, Paris/Moscow has the given jurisdiction of
Commonwealth of Independent States (CIS), Baltic and Eastern Bloc
Countries. India Tourism will be participating in the following forthcoming
International Travel & Tourism Exhibition in the jurisdiction:-
1. Tashkent International Tourism Fair(TITF), Tashkent, Uzbekistan
2. Romanian Tourism fair(TTR), Bucharest, Romania
3. Athens International Tourism Expo, Athens, Greece
India Tourism Paris/Moscow invites bids from professional agencies
/consortium of agencies (i.e. one lead agency + one Partner) for designing
and construction of India stand at above mentioned exhibitions, providing
ancillary services and dismantling of India Stand after the event is over. The
interested agencies may download full tender document with detailed scope
of work, eligibility criteria and format for application from
www.tourism.gov.in ( click on the tab “Tenders & RFP”) at the home page.
Sealed quotations as per the format should reach Assistant
Director, India Tourism Frankfurt , Baseler Strasse 48 -60329,
Frankfurt Am Main, Germany on or before 1400 hrs. 1st November,
2019.
६३...
(Sanjiv Vashist)
Assistant Director

<!-- page 2 -->

2
India Tourism Paris
(Ministry of Tourism, Government of India)
13 Boulevard Haussmann, 75009 - Paris
Tel: 0033- (0)145233045 — Fax: 0033- (0)145233345
EMail: directorindiatourismparis/ email.com
IT.Moscow/Stand Construction (2)/2019-20 Dated: 20.10.2019
TENDER
DESIGN & CONSTRUCTION OF INDIA STAND
AT VARIOUS EXHIBITIONS IN UZBEKISTAN, ROMANIA & GREECE
India Tourism Paris/Moscow will be participating in the forthcoming 3
International trade fair for travel & tourism. The objective of our
participation in the said fairs is to showcase India’s myriad tourism products
and to promote India as a ‘Must Visit’ destination for travelers from
Uzbekistan, Romania, Greece.
India Tourism Paris/Moscow, invites bids from professional agencies
/consortium of agencies {i.e one lead agency + one Partner) for designing
and construction of India stand at Tashkent International Tourism
Fair(TITF), Tashkent, Uzbekistan, Romanian Tourism fair(TTR), Bucharest,
Romania, Athens International Tourism Expo, Athens, Greece providing
ancillary services and dismantling of India Stand after the events are over, as
per details given below:
2. Space
India Tourism has booked raw spaces in these exhibitions (location
map is enclosed) India Tourism will be the main exhibitor along with co-
exhibitors. A detail on the same is as below:-
Name of | Dates No. of Co
No. _| Exhibition/Location exhibitors
Tashkent International | 13-15 60 Square | 4
Tourism Fair(TITF), | November 2019 | Meter
Tashkent, Uzbekistan
2 Romanian Tourism | 14-17 36 Square | 2
fair(TTR), Bucharest, | November 2019 | Meter*
Romania
3 Athens International | 06-08 56 Square | 3
Tourism Expo, Athens, | December 2019 | Meter
Greece
Note: *The area is subject to change
3. SCOPE OF WORK (including design specifications & requirements)

<!-- page 3 -->

3

3.1 To Design, fabricate and install the stand on time and dismantle the
stand after the event is over.

3.2 To provide good quality, comfortable furniture as per stand design and
space.

3.3 The Pavilion should be erected on a raised platform of 2 inches, with
slope on the edges.

3.4 To provide Screen for showing tourism films from CD DVD and pen
drives along with a DVD Player, Mike with Speakers as per below
exhibition:-

eee
Exhibition/L
ocation

||
International | November Meter more, CD/DVD Player, Pen drives,
Tourism 2019 2 portable Mikes with Speakers
Fair(TITF),
Tashkent,
Uzbekistan

2 Romanian 14-17 36 Square | 1 Digital Screen of 65 Inches or
Tourism November Meter* more, CD/DVD Player, Pen drives,
fair(TTR), 2019 2 portable Mikes with Speakers
Bucharest,

Romania

3 Athens 06-08 56 Square | 2 Digital Screen of 65 Inches or
International | December Meter more, CD/DVD Player, Pen drives,
Tourism 2019 2 portable Mikes with Speakers
Expo,

Athens,
Greece
Note: *The area is subject to change

3.5 To provide high speed Internet / WIFI connection to the participants &
India Tourism (Cost to be included. No extra payment would be made)

3.6 To provide Electricity Connections.( To be paid as per actual invoice)

3.7 To provide plants & beautification and liaison with the fair authorities
for setting up of our stand.(Minimum 6 indoor Plants and 2 Flower
vases at each exhibition)

3.8 The work also includes construction of booth at site well in time,
maintenance & daily cleaning etc.

3.9 Coordination with the fair authorities for setting up of our stand, with
proper lighting.

3.10 To provide 1 Hostess cum interpreter and 1 Henna/Mehdi Artist.

3.11 A representative of the stand constructor should be available
throughout the working hours of the event.

3.12 Stand Design:

i) It should be functional and projecting an image of “Incredible India”.
The booth should essentially reflect an ethnic Indian décor &
ambiance.

<!-- page 4 -->

4

ii) The pavilion should essentially reflect Indian décor and ambience and
at the same time a professional and business type lay out best suited
for buyer — seller meetings with effective and adequate branding of the
Incredible India as per design.

iii) The Pavilion must showcase Cultural Tourism Product of India.

iv) There should be easy accessibility and visibility. Double sided pictures
/ signage are to be produced by the agency of high quality, and
backdrop with their logos for all participants / co-exhibitors in the
Pavilion as per the design. All the images should be backlit.

v) A small area for cultural activity like Dance, Yoga demonstrations etc.
to be provided. One small table and two small chairs for Henna /
Mehendi applying also to be provided.

vi) There should be a Store Rooui, with wall racks & sufficient hooks for
hanging clothes, coat stand and a small wall mirror may also be
provided. The outer wall of the storage area may bce used for branding
with Incredible India images.

vii) There should also be a small Pantry area in the stand along with a
small refrigerator, Water dispenser, Tea/Coffee machine for providing
tea / coffee, soft drinks etc. It should also have a big dust-bin and
needs to be cleaned regularly.

viii) All other ancillary works related to India Pavilion like provision of back
drops for VIP area, coffee/tea machine, provision for soft drinks, milk,
coffee, tea and sugar, cookies, mineral water with dispenser and paper
napkins, disposable spoons/stirrers/ glasses/cup, dustbins with bags
etc. are within the scope of work of the agency. There should be
regular cleaning of the dustbins & carpet.

ix) All visual display materials produced will be the property of India
Tourism Paris/Moscow and should be handed over after the
completion of the exhibition.

3.13 Provisions for Co-Exhibitors

i. Each co-exhibitor would be given a space of 4 Sq.mtr.

ii. They are to be provided with one table with 4 chairs (two chairs on
either side of the table)

iii. Sufficient storage space with lock to be provided within their stand.

iv. 2 Electricity points for charging laptop, mobile phone, etc.

ve There should be a partition between the co-exhibitors.

<!-- page 5 -->

5

vi. Double sided attractive pictures / signage to be produced by the
agency, and backdrop with the logos of the co-exhibitors /participants
as per design.

vii. Each individual booth of the co-participants should be designed in an
uniform manner with easy visibility. Stand Number and Name of the
company should be clearly visible.

3.14 Meeting Area:

i. There should be an arrangement for small meeting area in the stand
and a three-seater sofa and 1 to 2 sofa chairs along with a center table
with flower bouquet are to be provided for India Tourism,
Paris/Moscow. It should preferably a closed area to avoid
disturbance /noise.

ii. The Meeting area should be given Indian ambience, by using Indian
decor and colors. It should have electricity points and a small dustbin.
It should also have backdrop with Indian Tourism Image/Collage of
images.

3.15 Information Counter:

i. The Information Counter of India Tourism Paris/Moscow is to be
placed along with 2 barstools and 2 display racks to display
brochures/maps etc.

ii The information desk should also have storage space (shelves) with the
provision of lock.

iii, The backdrop of the information counter should have a prominent
image of a popular India Tourism product such as Taj Mahal etc.; so
that image is clearly visible.

iv. Reception / Information area should be well designed for the main
exhibitor (India Tourism) at the entrance.

v. There should be a Name Board near the entrance displaying the
names of all the co-participants and their booth Nos.

vi. Design of the India Stand should showcase the Indian architecture. It
should also reflect the diversity, culture, heritage and vibrancy of
India.

vii. There should be extensive branding with images provided by India
Tourism or if required may be purchased by the agency(No additional
payment would be made) and the logo of Incredible India should be
used frequently and prominently.

4. Guidelines for Submission of Tender:

4.1 The tender should be submitted in two covers as per details given
below:

4.2 Cover-I: Superscribed “TECHNICAL BID FOR DESIGN &

CONSTRUCTION OF INDIA STAND AT VARIOUS EXHIBITIONS IN

<!-- page 6 -->

6

Uzbekistan, Romania & Athens”. To include the following

documents / details:

i Profile & Track record of the agency / both the agencies in the case of
consortium.

ii) Details of work undertaken relating to design and construction of
pavilion / stands in fairs / exhibitions / Marts in the last three years
ie 2016-17, 2017-18 and 2018-19, with copies of relevant work
orders. Experience of setting up Pavilions/ Booths/ Stands at
International Fairs / Exhibitions / Events overseas as well as at
International Tourism related Fairs /Exhibitions Events overseas
during the last three years i.e 2016-17, 2017-18 and 2018-19 may be
highlighted.

iii) | Specific experience relating to the particular events, if any, with copies
of relevant work orders / Client Completion Certificate specifying the
dates, months and year of the project and total cost of the project in
support of details furnished.

iv) The Firm/ Agency (all members/ agencies in case of Consortium) shall
not be under declaration of ineligibility for corrupt or fraudulent
practices with any Government department/ agencies/ ministries or
PSUs and should not have been black listed at the time of submission
of bid. All bidders (both the agencies in case of consortium) should
submit a self-undertaking on the company’s letter head duly
signed by the authorized signatory, stating that they have never
been blacklisted by any Government of India Ministry/
Department /Public Sector Undertaking / Authority/
Organization/ Agency.

v) Details of any awards won for stand design in the past three years i.e
2016-17, 2017-18 and 2018-19 supported by documentary proof.

vi) In the case of consortium, MoU signed between the lead agency and
the partner agency clearly specifying the name of the lead agency in
the consortium to be submitted. The MoU should be signed by both
the agencies. A total of two agencies only permitted in a consortium.

vii) Concept/ Design of the India Pavilion with detailed layout, decoration
plan, space utilizations etc. (only single design) must be submitted in
hard copy as well as on CD/pen drive. (In case multiple designs only
first design would be taken for consideration.)

viii) Bid securing declaration in the letter head of the company duly signed
by the authorized signatory to be submitted by bidders, accepting and
stating that if they withdraw or modify their bids during the period of
validity, or if they are awarded the contract and they fail to sign the

<!-- page 7 -->

7
contract, or to submit a performance security before the deadline
defined in the tender document, they will be suspended for one year
including the next edition of the exhibition from being eligible to
submit Bids for contracts with the India Tourism, Paris/Moscow.

4.3 Cover - 2: Superscribing “FINANCIAL BID FOR DESIGN &
CONSTRUCTION OF INDIA STAND AT VARIOUS EXHIBITIONS IN
UZBEKISTAN, ROMANIA, GREECE” and to include the following documents
/ details:
i) Financial Bid, duly dated, signed by the authorized representative of
the agency and clearly indicating the cost as per format given below :-
~

design, construction, | cost in | rate of

dismantling and | Euros (€) tax, if any

ancillary services as in€

per scope of work &

requirements

detailed at Para-3 of

the Bid document

Tashkent

International

Tourism Fair(TITF),

Tashkent,

Uzbekistan

Romanian Tourism

fair(TTR), Bucharest,

Romania

Athens International

Tourism Expo,

Athens, Greece

ii) All bidders should indicate cost for the fair as well as the total cost
inclusive of all taxes. All components related to construction of
pavilion as per submitted design should be inclusive. No additional
payment would be made for any components related to construction of
the pavilion. The financial bids will be evaluated on the basis of
total cost inclusive of taxes of each exhibition.

(iii) The financial bid should be only in Euros.

(iv) The financial bid should contain an undertaking by the agency that
the agency accepts and agrees to abide by the terms and conditions as
mentioned in this tender document No. IT.Moscow/Stand
Construction (2)/2019-20 dated 16.10.2019.

(v) The agency may apply for one or all exhibition.

<!-- page 8 -->

8

(vi) No additional payment would be made for any elevated structure
/rigging/hanging supports etc.

4.4 The agencies submitting their bids should also mention in the covering
letter that they agree to the terms and conditions mentioned in the
tender document.

4.5 All the documents submitted by the agencies should be signed on each
page by the authorised signatory of the company. The document
should be spiral bound, duly page numbered, and properly indexed.
The agencies who do not submit their bids in the proper format, with
required documents and in the required format would be liable for
rejection.

4.6 The two sealed covers, i.e Cover-I -Technical Bid & Cover-II Financial
Bid should be put up in an outer cover, which should be sealed and
superscribed as “TECHNICAL & FINANCIAL BID FOR DESIGN &
CONSTRUCTION OF INDIA STAND AT VARIOUS EXHIBITIONS IN
UZBEKISTAN, ROMANIA, GREECE”. The left bottom of the outer cover
should have details of the bidding agency such as, Name in full of the
contact person in the agency, Postal Address, Tel. No., E-mail and sent
to the Assistant Director, India Tourism Frankfurt, Baseler Strasse 48-
60329, Frankfurt am Main, Germany to reach on or before 1400 hrs.
on 15t November, 2019.

5. Opening of Bids and selection procedure:

5.1 Technical bids will be opened by a Constituted Committee which will

evaluate the technical Bids of the agencies which are found eligible after

initial scrutiny of the bids at 1600 hrs on 1st November 2019.

5.2 The technical bids will be judged by following the criteria:

[अर Particulars Marks

Profile & Track Record | ४ |
2 Experience of setting up Pavilions/ Booths/ Stands at
International Fairs / Exhibitions / Events not related to
tourism during last three years 2016-17, 2017-18 and
2018-19.
(1 Mark per project for a maximum of 5 Marks)
3 Experience of setting up Pavilions/ Booths/ Stands at
International Tourism related Fairs / Exhibitions
/Events in overseas during last three years 2016-17,
2017-18 and 2018-19.

<!-- page 9 -->

9
[2 Marks per project for a maximum of 10 Marks) =—4
Awards received for Pavilions / Booths / Stands at
events at Sr. Nos. 2 & 3 above.
(1 Mark per award for a maximum of 5 Marks)

Concept & Design of Pavilion | |

| s | Effective Utilization of Space | 5 |

Effective Branding in the Pavilion | 9 |

| | Innovative ideas and other attractions in the Pavilion | ० |

=

5.3 Whereas, Technical Evaluation will carry a weightage of 70 marks,
financial bids will carry weightage of 30 marks. The agencies scoring
70 per cent marks (49 marks) or above in Technical Evaluation shall
be eligible for opening of their financial bids.

5.4. The financial bids of only those agencies that score 70 percent mark
(49 marks) or above in Technical Evaluation will be opened in the
presence of their representatives. The date and time of opening of the
financial bids will be conveyed to the selected agencies. Financial
evaluation will carry a weightage of 30 Marks.

5.5 The agency which scores the highest aggregate marks on the basis of
technical and financial evaluation (after adding the scores from the
technical and financial evaluation) for each exhibition will be awarded
the contract for construction of the India Pavilion for that exhibition.

6. Terms of Payment:

Payment will be made to the successful bidder as per the following schedule:

6.1 Payment of 30% of the total contractual amount will be made by

cheque/bank draft/electronic transfer as advance 14 days before the fair.

6.2 Payment of 70% of the total contractual amount will be made through

cheque/bank draft/electronic transfer on completion of the Travel Mart,

dismantling the pavilion and clearing of site.
7. Submission of Performance Security:
The selected agency/ies has/have to submit Performance Security for 10% of
the total contract value in the form of a Account Payee Demand Draft, Fixed
Deposit Receipt from a Commercial bank, Bank Guarantee from a
Commercial bank or online payment in favor of ‘India Tourism, Paris’ from

<!-- page 10 -->

10

a scheduled bank. The Performance Security should remain valid for a

period of 60 days beyond the date of completion of all contractual

obligations. The selected agency/ies will submit Performance Security
within 3 days from the date of receipt of Letter of Intent from India Tourism,

Paris/Moscow. In case of any deficiency and unsatisfactory performance by

the consultant, the Performance Guarantee would be invoked and the

payment due to the agency would be withheld. No interest will be paid by the

Ministry of Tourism on the Performance Guarantee.

8. Additional Information:

8.1 India Tourism Paris/Moscow reserves the right to reject or accept any
offer in full or in part without assigning any reasons whatsoever.

8.2 Incomplete and conditional bids will be rejected outright.

8.3 Any Displays / Translites produced for the India Pavilion at the event
will be the property of the Ministry of Tourism, Govt. of India, on
completion of the event and shall be handed over post event.

8.4 Validity of Tender: Tender shall remain valid for acceptance for a
period of 90 days from the last date of opening of Tender/or till the end
of the event for which the tenders were called for, whichever is earlier.

8.5 Insurance: Insurance, including transit and third-party insurance will
be arranged by the service provider only.

8.6 Liquidated Damages: In the event of service provider's failure to
complete the work within the specified time, and as per the
requirements of standards of quality constructions, as mentioned in
the tender document, India Tourism Paris/Moscow will recover from
the service provider, as Liquidated Damages, a sum of 10 % of the
contract price for every day's delay. Besides, if the execution is delayed
the IT, Paris/Moscow may take action to debar the agency from
participation in further tenders and/or blacklist the agency.

8.7 Termination by default: India Tourism Paris/Moscow reserves the right
to terminate contract of any agency in case of change in the
Government procedures or for unsatisfactory services.

8.8 Risk — Purchase Clause: If the service provider, after submission of

tender and the acceptance of the same, fails to abide by the Terms and
Conditions of the tender document or fails to complete the work within
the specified time or at any time repudiates the contract, India
Tourism Paris/Moscow will have the right to:
a) In case, India Tourism Paris/Moscow gets the incomplete job
completed through alternative sources and if price of completing the
work is higher, the service provider shall pay the balance amount
incurred by the office for completing the work, to IT, Paris/Moscow.
