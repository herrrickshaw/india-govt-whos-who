---
doc_id: "abbde82bf046a4dd"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/f392ea4fe96c834959083fc3ab937e8d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer Posting of officers in HAG of ITS Group A reg"
date: "2024-08-29"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9cc0a36d9eec2169"
---

<!-- page 1 -->

12-4/2024-STG-|

1/3205539/2024

No. 12-4/2024-STG-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi

OFFICE ORDER

Dated the 28 August, 2024

Subiec-t: - Transfer & Posting of officers in HAG of ITS Group ‘A’ - reg.

posting

Approval of the competent authority is hereby conveyed for transfer &
of the following officers in the grade of HAG of ITS Group ‘A, with

immediate effect:
E
No
.

W
|No
8600

Name
(Shri)
|Ajatshatru
Somani

I

20040

|[S. Parthiban|Under transfer to Gujarat LSA

Place of Posting

Posting on
transfer
|Under Transfer to BSNL (vide DoT |Gujarat LSA
Order of even No. dated
26.07.2024)
BSNL

(vide DoT’s Order No. 31704/2023-STG-IIl dated
26.07.2024)

2.
follow.

The charge report may be furnished to all concerned. Hindi version will

Signed by Bijender Singh
Date: 28-08-2024 10:25:18
(Bijender Singh)
Under Secretary to the Government of India

Tele 011-2303 6282
Email: bijender.s83@gov.in
Copy to:

1. Chairman, DCC/Member(S)/Member(T)/Member(F)/DG(Telecom), DoT;
2. AS(T)/ Administrator USoF / All Advisors, DoT;

3. CMD, BSNL;
4. CVO, DoT HQs;
5. All Sr. DDGs/DDGs DoT HQs;
6. Admn.I-IV/Cash/Pension/Library/G-I/G-1l/PFP/PHP/RTI/Vig.l Sec., DoT HQs;
7. Pay Bill Section, DoT HQs;

-

8. US (STG-II)/ADG (APAR)/AD (STG-1)/AAO (STG-l), DoT HQs;
9. The Officers concerned;
10. Official Language Section, DoT for Hindi version of the order;

<!-- page 2 -->

12-4/2024-STG-

1/3205539/2024

11. Order Bundle/PA to US(SGT) for uploading this order on 001 website.
