---
doc_id: "ab1f6cb185ae1c1e"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/d807a7fdd75eac6a3c8ab23ce3d0f4cc.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment to the Recruitment rules for the post of Accounts Officer in the Central Government Health Scheme (CGHS)"
date: "2019-04-15"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0131f36536038d69"
---

<!-- page 1 -->

F.No. A- 12018/1412018-CGHS-l

Government of lndia
Ministry of Health and Family Welfare
Department of Health & Family Welfare
CGHS Division
(CGHS-l Section)
:t ,i ,* *,t

Room No. 430, 'C' Wing,
Nirman Bhawan, New Delhi

oated:2'l- l9-2o78.
This Department is examining the proposal for amendment to the Recruitment Rules

for the post of Accounts officer in the central Government Health Scheme (CGHS).

Accordingly, a draft Recruitment Rules have been prepared and a copy of the same is
enclosed.

The comments of the stakeholders are invited in the matter. The comments may be
furnished within 30 days from the placing on the website to the Under Secretary (Admn.),
CGHS, Department of Health & Family Welfare, Room No.430, 'C'Wing, Nirman Bhawan, New
Delhi. The soft form may also be furnished on s.dharminder@nic.in.

Encls. : As above.
DHARMIN,DER SINGH)

Under 5ec
To

All concerned.

ry to the Govt. of lndia

<!-- page 2 -->

[TO BE PUBLISHED IN THE GAZET1E OF INDIA, PART II, SECTION 3, SUB-SECTION

(i)l
Govemment of India
Ministry of Health and Family Welfare
(CGHS Division)

New Delhi. dated

,2018.

NOTIFICATION

G.S.R.

In exercise of the powers conferred by the proviso to article 309 of the
Constitution and in supersession of the Central Govemment Health Scheme (Accounts Officer)
Recruitment Rules, 1996, except as respect things done or omitted to be done before such
supersession, the President hereby makes the following rules regulating the method of recruitment
to the post of Accounts Officer in the Ministry of Health and Family Welfare, Central
Govemment Health Scheme, namely:These rules may be called the Ministry of
Short title and commencement. - (l)
Health and Family Welfare, Central Govemment Health Scheme Organisation (Accounts Officer)

1.

Recruitment Rules, 2018.

(2)
2.

They shall come into force on the date ofpublication in the Official Gazette.

Number of post, classification and level in the Pay Matrix. - The number of the said
post, its classification and level in the Pay Matrix attached thereto shall be as specified in columns
(2) to (a) of the Schedule annexed to these rules.

3.

Method of recruitment, age limit, qualifications etc. . - The method of recruitment to
the said post, age limit, qualifications and other matters relating thereto shall be as specified in
columns (5) to (13) ofthe aforesaid Schedule.

4.
(a)
(b)

Disqualification. - No person,who has entered into or contracted a marriage with a person having a spouse living; or
who, having a spouse living, has entered into or contracted a marriage with any person,

shall be eligible for appointment to the said post:
Provided that the Central Govemment may, if satisfied that such marriage is permissible under the
personal law applicable to such person and the other party to the marriage and that there are other
grounds for so doing exempt any person from the operation ofthis rule.

5.

Power to relax. - Where the Central Govemment is of the opinion that it is necessary or
expedient so to do, it may, by order, for reasons to be recorded in writing and in consultation with
Union Public Service Commission, relax any of the provisions of these rules with respect to any
class or category olpersons.

6.

Savings. - Nothing in these rules shall affect reservation, relaxation of age limit and other
concession required to be provided for the Scheduled Castes, the Scheduled Tribes, the Other
Backward Classes, the Ex-servicemen and other special categories of persons in accordance with
the orders issued by the Central Government from time to time in this regard.

<!-- page 3 -->

;o
9)

!)

Y'E ^a!(,
o d@
A).D.)

<O-*

.0

o

o-

c)

o

z

.D

a,

stJ
s

5
5
\o

F

o

@

p-

a='

Eo

6>
o0a

* ,.c

='(D

oo

,LC

Xa!

9{

X

D)

z

co

(!

o
!

o.D

|.
o

o

ol

o

!d

C'

o\

NJ

a!

3

z

3
co
o

z

9)

i-ry8_

Z "3_

a

o

3.gl'!r

;'o:..D

:JNJ:
=.

!D :-: .}

e9

Y
B

3 a\aa\

X=
rl)'

<p

5'!
@Y

t1

9>
i..ii

<!-- page 4 -->

o)

o-

9)

:o

CE
!D

?9

r

i

ia
g? g

ge

Ci=frrg,f,

[iHggAE F

FiaiBa:u F

aa-

9e
,6P
o9)
o
orJ
(!o

DE
c,_ 0)

Yo
,B

1€

g1

:r@

-aD
5Fr
a=.

l0a
fDo)5
c).o_^
(Doti
'ail

-ii -niI

.Y

+i A+ ftiter;; i

=-

5ci

*

c @

B: E? Eet"a3d+ E

ix
r: eI F+$i*Zqi

ei
+ ae+;
ia
iggai
a+cr g
aFi*is E;
as a

sc8e8 E s*i;;eEr

t< I

o

.)x

'i.:^< 1qB 5: E 3sg q

oNe-=-J

=c=EiF:E.+=.=
' x 6 E.=.i.3 :i 3 0='.

a=fi9f,.€IETIA

.o o) O- rC : < A 7

o-

sa< a'E'=

ff1fi[BE4

Y='a-:=A'i.a=Q

3E;'6
E 3{
3--.5:j
>

E lD o-'tr -o o

.5

b) i'd'0o
Fi
O

@

x

6E.g',0
GdE)

ai o- ).(

x.D='i+

= =r <

co

o'

o)

TD
ro

zo

(D

d

p)

z

!

3E.:.d
E
-'rFna)

6'
!:]=-; e:y

sD

d

o)

Ez

<!-- page 5 -->

gi;eileictg;El

HBrirEEgFit "HH=

aEi *3 ; *;; +$ :; f;

iE;igiegitFiiil

:; lsaaa ;;iA [! ;;x

EigEEgiEEIiiiEIEg

<!-- page 6 -->

=dOQ
lDi

+,4

=d
1a
'9;

v

.o

cz
;9
o.D

r

A

:E

A

o

^,

L.r
^ r

;r

o53

Qo'=

Zz^

3.

=
ao
b3
do
!D

za
z
Y

i'!

o

o

=A)
6.6'P=
)
,aD
=
A- v' >;
,'r
-; a

5<.

o
@

E

o
o

o

o

9)

.D

Yi*;<+
iD'r:!Oa o

+e |r5

!!/-P+L<l
=-iirir^
;5
^ E) Y
.D 'i F:
f
^.5
=-rao
d

BA d E.EI

JOI:f=r

aD

5',95'>a
< !(e
O-!!

i-i

ts

i.i

5'o
ni .6 oi
3E6c).)
Olv;i

9)

ro

(aUUUU

t)

=-

Ial='
an:

)Ai

q i"a

o

-.a
'!
P5{

r=ao

a'1 a

a;.=).,

a aa\
Oan-1

o
o
3

ID

*

.D

(!
(!

5

o

o

5

r-i.

(D

3

(D
