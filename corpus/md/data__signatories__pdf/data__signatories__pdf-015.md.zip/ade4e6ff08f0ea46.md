---
doc_id: "ade4e6ff08f0ea46"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/4f87190ecfb05dfd3a76a140225ef5c6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 1152 of 2025 in the Hon’ble High Court of Delhi: DoT instructions dated 04.05.2026 to ISPs"
date: "2026-05-04"
pages: 30
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "911bee0588f33b7e"
---

<!-- page 1 -->

4-10/2025-DGT/4

I/3393778/2026

By Email/ DoT Website
File No.:4-10/2025-DGT/4
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date: -04-2026
To
All Licensees with Internet Service Authorization
Subject: CS(COMM) 1152/2025: Dazn Limited & Anr. vs. 9goals.io & Ors. in the
Hon’ble High Court of Delhi.
Please find enclosed the Hon’ble High Court of Delhi order dated 06.11.2025 in the
captioned case.
2.
Please refer to para 33 & 34 of the said Court order along with 22nd and 23rd additional
lists received from the plaintiff counsel regarding blocking access to the website(s)/domain(s)
[113 in number] as listed in the enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action in respect of blocking access to the said
website(s)/domain(s), as per the enclosed list, in compliance with the said court orders.

Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Mr. Manish Rawat (mrawat@saikrishnaassociates.com), Plaintiﬀ's Counsel For kind information and with a request to take action as per the enclosed Annexure
pl.

<!-- page 2 -->

4-10/2025-DGT/4

I/3393778/2026

CS(COMM) 1152/2025 :
Website(s)/domain(s) :
List - 22
S.No.
Domain
1
vipflash.online
2
kora-extra.net
3
tv.buzkora-live.website
4
yalla-shoot-kooora.live
5
calciostream.art
6
okestream.today
7
nobar.website
8
risebet32.live
9
atomsportv496.top
10
bally-sports.sbs
11
calcio-ga.lol
12
elitegoltv.blog
13
footy100.net
14
footybite.info
15
methstreama.top
16
taraftarium24canli.in
17
poscstreams.sbs
18
live5.totalsportek.fyi
19
streamwest.cc
20
ppv.cx
21
ppv.link
22
ropeingame.top
23
shd247.live
24
streamsports99.su
25
foxxy.dad
26
gomitoep.xyz
27
ggsport.live
28
privatemedia.click
29
hubafootball.live
30
9goals.me
31
streamhq.top
32
footybite.best
33
daddylive.pw
34
daddylives.nl
35
24hsport.tv
36
chilistream.net
37
sng.liveball.st
38
tarjetarojatv.top

Registrar Name
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
Key-Systems LLC
Squarespace Domains II LLC
Tucows Domains Inc.
NameSilo, LLC
NameSilo,LLC
Dynadot LLC
NameSilo, LLC
Tucows Domains Inc.
Unstoppable Domains Inc.
CentralNic Ltd
NameSilo, LLC
NameSilo,LLC
Sav.com, LLC
R01-SU
Tucows Domains Inc
Name.com, Inc
Tucows Domains Inc.
Sav.com, LLC
NameSilo, LLC
Immaterialism Limited
Spaceship, Inc.
Dynadot LLC
NameSilo, LLC
Key-Systems GmbH
Immaterialism Limited
Hosting Concepts B.V. d/b/a Registrar.eu
NETIM
Spaceship, Inc.

<!-- page 3 -->

4-10/2025-DGT/4

I/3393778/2026

39
40
41
42
43

yallashout.com
ls5.site
ls21.site
xoilac68.com
incredibleart.org

List - 23
S.No.
Domain
1
socolive8c.com
2
pelotalibrelibre.com
3
live.tv96.site
4
ovogoal.site
5
empire-sport.sbs
6
goalkick.live
7
damitv.pro
8
ask4sport.xyz
9
ask4sport.live
10
ask4sport.co
11
ask4sport.link
12
nobartv.boats
13
nontonbola.tv
14
matchbola.co
15
korax90.com
16
tvsembox.com
17
futbol-libre.hair
18
streamingbola.net
19
deporflix.site
20
futbollibremx.com
21
bintv.net
22
sportsbite.online
23
sportsbite.site
24
daddylive.im
25
streamcorner.info
26
streamcorner.cfd
27
streamcorner.sbs
28
falconstreams.com
29
streamup.top
30
weflix.to
31
privatemedia.app
32
rbsports77.rest
33
sk21live.xyz
34
sbotv.live
35
36
37

gasstv.pw
stream2watch.life
tennisonline.me

GoDaddy.com, LLC
GoDaddy.com, LLC
GoDaddy.com, LLC
GoDaddy.com, LLC
GoDaddy.com, LLC

Registrar Name
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NAMECHEAP
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
HOSTINGER operations, UAB
HOSTINGER operations, UAB
NameSilo, LLC
nic.im
OwnRegistrar, Inc.
OwnRegistrar, Inc.
Dynadot LLC
Spaceship, Inc.
Tucows.com Co
Government of Kingdom of Tonga
Sav.com, LLC
Dynadot
Web Commerce Communications Ltd
Web Commerce Communications Limited dba
WebNic.cc
PDR Ltd. d/b/a PublicDomainRegistry.com
Cloudflare, Inc
Immaterialism Limited

<!-- page 4 -->

4-10/2025-DGT/4

I/3393778/2026

38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70

720pstream.co
myp2p.info
piratemedia.cc
piratemedia.su
totalsportek.mobi
lapakstreaming.site
koora.alkoora.live
fel3arda-tv.org
kora-sport-live.com
bzbuz.cc
kora4live-tv.com
coolkora.io
koraonlinee.live
yallashoootx.com
koraonlinee.pro
koraoonline.blog
shoflkora.com
librefutboltv.live
pelotalibrestv.su
skylivefu.com
yoresport.com
halastream.live
soccerstreams.cx
tupelotalibre.com
deporflix.net
pirlotvenvivo.org
rojadirectahd.lol
4stream.fans
strmd.link
livesport24.watch
streameast.rip
808fubo15.com
rd-live.com

Tucows Domains Inc.
Cloudflare, Inc
GoDaddy.com, LLC
RUCENTER-SU
Ultahost, Inc
HOSTINGER operations, UAB
Cloudflare, Inc
Spaceship, Inc.
GoDaddy.com, LLC
Spaceship, Inc.
Unstoppable Domains Inc.
Dynadot Inc
NameSilo, LLC
GoDaddy.com, LLC
NameSilo, LLC
NameSilo, LLC
Name.com, Inc.
Ultahost, Inc
R01-SU
Tucows Domains Inc.
Cloudflare, Inc.
NameSilo, LLC
CentralNic Ltd
Tucows Domains Inc.
Cloudflare, Inc.
Hosting Concepts B.V. d/b/a Registrar.eu
Dynadot LLC
Tucows.com Co.
Tucows Domains Inc.
Cloudflare, Inc
Porkbun LLC
Dynadot Inc
GoDaddy.com, LLC

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

List - 22
S.No.
Domain
1
vipflash.online
2
kora-extra.net
3
tv.buzkora-live.website
4
yalla-shoot-kooora.live
5
calciostream.art
6
okestream.today
7
nobar.website
8
risebet32.live
9
atomsportv496.top
10
bally-sports.sbs
11
calcio-ga.lol
12
elitegoltv.blog
13
footy100.net
14
footybite.info
15
methstreama.top
16
taraftarium24canli.in
17
poscstreams.sbs
18
live5.totalsportek.fyi
19
streamwest.cc
20
ppv.cx
21
ppv.link
22
ropeingame.top
23
shd247.live
24
streamsports99.su
25
foxxy.dad
26
gomitoep.xyz
27
ggsport.live
28
privatemedia.click
29
hubafootball.live
30
9goals.me
31
streamhq.top
32
footybite.best
33
daddylive.pw
34
daddylives.nl
35
24hsport.tv
36
chilistream.net
37
sng.liveball.st
38
tarjetarojatv.top
39
yallashout.com
40
ls5.site

Registrar Name
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
Spaceship, Inc.
Key-Systems LLC
Squarespace Domains II LLC
Tucows Domains Inc.
NameSilo, LLC
NameSilo,LLC
Dynadot LLC
NameSilo, LLC
Tucows Domains Inc.
Unstoppable Domains Inc.
CentralNic Ltd
NameSilo, LLC
NameSilo,LLC
Sav.com, LLC
R01-SU
Tucows Domains Inc
Name.com, Inc
Tucows Domains Inc.
Sav.com, LLC
NameSilo, LLC
Immaterialism Limited
Spaceship, Inc.
Dynadot LLC
NameSilo, LLC
Key-Systems GmbH
Immaterialism Limited
Hosting Concepts B.V. d/b/a Registrar.eu
NETIM
Spaceship, Inc.
GoDaddy.com, LLC
GoDaddy.com, LLC

<!-- page 11 -->

41
42
43

ls21.site
xoilac68.com
incredibleart.org

GoDaddy.com, LLC
GoDaddy.com, LLC
GoDaddy.com, LLC

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

List - 23
S.No.
Domain
1
socolive8c.com
2
pelotalibrelibre.com
3
live.tv96.site
4
ovogoal.site
5
empire-sport.sbs
6
goalkick.live
7
damitv.pro
8
ask4sport.xyz
9
ask4sport.live
10
ask4sport.co
11
ask4sport.link
12
nobartv.boats
13
nontonbola.tv
14
matchbola.co
15
korax90.com
16
tvsembox.com
17
futbol-libre.hair
18
streamingbola.net
19
deporflix.site
20
futbollibremx.com
21
bintv.net
22
sportsbite.online
23
sportsbite.site
24
daddylive.im
25
streamcorner.info
26
streamcorner.cfd
27
streamcorner.sbs
28
falconstreams.com
29
streamup.top
30
weflix.to
31
privatemedia.app
32
rbsports77.rest
33
sk21live.xyz
34
sbotv.live
35
36
37
38
39

gasstv.pw
stream2watch.life
tennisonline.me
720pstream.co
myp2p.info

Registrar Name
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NAMECHEAP
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Namecheap
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
HOSTINGER operations, UAB
HOSTINGER operations, UAB
NameSilo, LLC
nic.im
OwnRegistrar, Inc.
OwnRegistrar, Inc.
Dynadot LLC
Spaceship, Inc.
Tucows.com Co
Government of Kingdom of Tonga
Sav.com, LLC
Dynadot
Web Commerce Communications Ltd
Web Commerce Communications Limited dba
WebNic.cc
PDR Ltd. d/b/a PublicDomainRegistry.com
Cloudflare, Inc
Immaterialism Limited
Tucows Domains Inc.
Cloudflare, Inc

<!-- page 17 -->

40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70

piratemedia.cc
piratemedia.su
totalsportek.mobi
lapakstreaming.site
koora.alkoora.live
fel3arda-tv.org
kora-sport-live.com
bzbuz.cc
kora4live-tv.com
coolkora.io
koraonlinee.live
yallashoootx.com
koraonlinee.pro
koraoonline.blog
shoflkora.com
librefutboltv.live
pelotalibrestv.su
skylivefu.com
yoresport.com
halastream.live
soccerstreams.cx
tupelotalibre.com
deporflix.net
pirlotvenvivo.org
rojadirectahd.lol
4stream.fans
strmd.link
livesport24.watch
streameast.rip
808fubo15.com
rd-live.com

GoDaddy.com, LLC
RUCENTER-SU
Ultahost, Inc
HOSTINGER operations, UAB
Cloudflare, Inc
Spaceship, Inc.
GoDaddy.com, LLC
Spaceship, Inc.
Unstoppable Domains Inc.
Dynadot Inc
NameSilo, LLC
GoDaddy.com, LLC
NameSilo, LLC
NameSilo, LLC
Name.com, Inc.
Ultahost, Inc
R01-SU
Tucows Domains Inc.
Cloudflare, Inc.
NameSilo, LLC
CentralNic Ltd
Tucows Domains Inc.
Cloudflare, Inc.
Hosting Concepts B.V. d/b/a Registrar.eu
Dynadot LLC
Tucows.com Co.
Tucows Domains Inc.
Cloudflare, Inc
Porkbun LLC
Dynadot Inc
GoDaddy.com, LLC

<!-- page 18 -->

$~29
*
IN THE HIGH COURT OF DELHI AT NEW DELHI
+
CS(COMM) 1152/2025
DAZN LIMITED & ANR.
.....Plaintiffs
Through: Mr. Siddharth Chopra, Mr. Yatinder
Garg, Mr. Priyansh Kohli & Ms. Ishi
Singh, Advocates.
Versus
9GOALS.IO & ORS.
.....Defendants
Through: Ms. Nidhi Raman, Mr. Mayank
Sansanwal & Mr. Om Ram,
Advocates. For D-46&47.
CORAM:
HON'BLE MR. JUSTICE TEJAS KARIA
ORDER
%
06.11.2025
I.A. No.26658/2025 (Exemption from pre-institution Mediation)
1.

This is an Application filed by the Plaintiffs seeking exemption from

instituting pre-litigation Mediation under Section 12A of the Commercial
Courts Act, 2015 (“CC Act”).
2.

As the present matter contemplates urgent interim relief, in light of the

judgment of the Supreme Court in Yamini Manohar v. T.K.D. Krithi, 2023
SCC OnLine SC 1382, exemption from the requirement of pre-institution
Mediation is granted.
3.

The Application stands disposed of.

I.A. No. 26656/2025 (for exemption from giving written notice to the
government authority)
4.

The present Application has been filed under Section 80 of the Code of

Civil Procedure, 1908 (“CPC”) seeking exemption from issuing Notice to
Defendant No. 38, Bharat Sanchar Nigam Ltd, Defendant No. 41, Mahanagar
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 1 of 12

<!-- page 19 -->

Telephone

Nigam

Ltd.,

Defendant

No.

46,

Department

of

Telecommunications (“DoT”), and Defendant No. 47, Ministry of Electronics
and Information Technology (“MeITY”).
5.

In view of the urgent relief and the nature of relief sought against

Defendant Nos. 38, 41, 46 and 47 the Plaintiffs are exempted from effecting
two months’ prior notice under Section 80 of the CPC upon Defendant Nos.
38, 41, 46 and 47.
6.

The Application stands disposed of.

CS(COMM) 1152/2025
7.

Let the Plaint be registered as a Suit.

8.

Issue Summons.

9.

The learned Counsel appearing for Defendant Nos. 46 and 47 accepts

Summons. Let Summons be issued to the remaining Defendants through all
permissible modes upon filing of the Process Fee.
10.

The Summons shall state that the Written Statement(s) shall be filed

by the Defendant(s) within four weeks from the date of the receipt of
Summons. Along with the Written Statement(s), the Defendant(s) shall also
file Affidavit(s) of Admission / Denial of the documents of the Plaintiffs,
without which the Written Statement(s) shall not be taken on record.
11.

Liberty is granted to the Plaintiffs to file Replication(s), if any, within

thirty days from the receipt of the Written Statement(s). Along with the
Replication(s) filed by the Plaintiffs, Affidavit(s) of Admission / Denial of the
documents of Defendant(s) be filed by the Plaintiffs, without which the
Replication(s) shall not be taken on record.

CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 2 of 12

<!-- page 20 -->

12.

In case any Party is placing reliance on a document, which is not in

their power and possession, its details and source shall be mentioned in the
list of reliance, which shall also be filed with the pleadings.
13.

If any of the Parties wish to seek inspection of any documents, the same

shall be sought and given within the prescribed timelines.
14.

List before the learned Joint Registrar on 24.12.2025 for completion of

service and pleadings.
I.A. No.26657/2025 (O-XI R-1(4) of the Code of Civil Procedure, 1908)
15.

The present Application has been filed on behalf of the Plaintiffs under

Order XI Rule 1(4) of CPC as applicable to Commercial Suits under the CC
Act seeking leave to place on record additional documents.
16.

The Plaintiffs are permitted to file additional documents in accordance

with the provisions of the CC Act and the Delhi High Court (Original Side)
Rules, 2018.
17.

Accordingly, the Application stands disposed of.

I.A. No. 26655/2025 (U/O XXXIX Rule 1 & 2 of CPC)
18.

Issue Notice. The learned Counsel for Defendant Nos. 46 and 47

accepts Notice.
19.

Issue Notice to the remaining Defendants through all permissible

modes including through e-mail upon filing of the Process Fee.
20.

The Plaintiffs have filed the present Suit seeking a permanent

injunction to restrain infringement of their broadcast reproduction rights by
Defendant Nos. 1 to 26 and other unknown parties.
21.

Defendant Nos. 27 to 36 are Domain Name Registrars (“DNRs”)

arrayed for the purpose of blocking access to Defendant Nos. 1 to 26 and to
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 3 of 12

<!-- page 21 -->

disclose information such as Name, Address, Email address, Mobile Number,
payment details etc. related to the Registrants of Defendant Nos. 1 to 26.
22.

Defendant Nos. 37 to 45 are Internet Service Providers (“ISPs”),

Defendant Nos. 46 and 47 are arrayed by the Plaintiffs to assist in enforcing /
ensuring compliance with any order of injunction that may be granted during
the course of proceedings.
23.

The learned Counsel for the Plaintiffs made the following submissions

before this Court:
23.1 The Plaintiffs have acquired exclusive global media rights,
comprising television rights to be exercised via broadcast delivery
systems, digital rights to be exercised via digital delivery systems,
including internet and mobile technology, and certain ancillary
rights (“Exclusive Rights”) in respect of the ongoing event ‘Serie
A Championship’ (“Event”) commenced on 23.08.2025. In
exercise of the Exclusive Rights in the Event granted by one Lega
Calcio Serie A (“LCA”) which is the owner of the Exclusive
Rights, the Plaintiffs have acquired the Exclusive Rights to be
exercised via Plaintiff No. 2.
23.2 Defendant Nos. 1 to 26 primarily host and disseminate live
sporting events without authorization from lawful rights holders
(“Impugned Services”). The Event matches are exclusively
licensed to the Plaintiffs and that the Plaintiffs have not authorised
Defendant Nos. 1 to 26 to broadcast the Event matches on
Defendant Nos. 1 to 26.
23.3 Defendant Nos. 1 to 26 are streaming the Plaintiffs’ DAZN
streams by circumventing the Plaintiffs’ exclusive streaming
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 4 of 12

<!-- page 22 -->

mechanism. Defendant Nos. 1 to 26 have also made categories for
different sports including boxing and have been using the
Plaintiffs’ contents, including the Plaintiffs’ prior events. The
Plaintiffs apprehend similar unauthorized streaming of the
pending Event matches, which are exclusively licensed to the
Plaintiffs, as per the Rights Confirmation Letter dated 10.10.2025
by LCA.
23.4 There are several other websites, similar to Defendant Nos. 1 to
26, which already exist, or are likely to be created. The identity,
constitution, and other particulars of such unknown websites will
become known only when such websites start communicating and
making available the Plaintiffs’ exclusively licensed broadcasts
and related content unauthorizedly over the internet.
23.5 The offering of Impugned Services is not geo-restricted and freely
accessible to users across India, including in Delhi. The Plaintiffs,
as rightsholders and exclusive licensees of the ‘original works’ as
well as ‘broadcasts’, enjoy protection under Section 37 of the
Copyright Act, 1957 (“Act”). Therefore, the making available and
/ or communication to the public of the content in which the
Plaintiffs have the Exclusive Rights, without the Plaintiffs’
authorization by Defendant Nos. 1 to 26 and / or any other
unknown websites would amount to a violation of the Plaintiffs’
Exclusive Rights. The alleged reproduction / communication is
contemporaneous and has a potential of eroding the Plaintiffs’
market, a considerable compensation for which has been paid by
the Plaintiffs. The balance of convenience is against Defendant
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 5 of 12

<!-- page 23 -->

Nos. 1 to 26, who do not have authorization with respect to the
Exclusive Rights, including, inter alia, to host, stream, reproduce,
distribute, make available to the public and / or communicate the
content in which the Plaintiffs have the Exclusive Rights. If the
illegal activities of Defendant Nos. 1 to 26 are not restrained
during the pendency of the present proceedings, the Plaintiffs
shall suffer irreparable harm since Defendant Nos. 1 to 26 intend
to continue to exploit, diminish and dilute the value of the
Exclusive Rights.
23.6 In the past whenever such Impugned Services have been injuncted
by the courts, while the initial injunction may be applicable to a
few websites which are identified in the Plaint, during the course
of the events itself a large number of websites are uncovered
which continue to disseminate unlawfully the said sporting
events. Therefore, a relief of real time live blocking of other
uncovered rogue websites is necessitated in the present case as
Defendant Nos. 1 to 26 may activate other domains / websites and
URLs during the Event so as to continue the Impugned Services
even if blocking orders are passed by this Court.
24.

Having considered the submissions advanced by the learned Counsel

for the Plaintiffs, the pleadings and the documents on record, a prima facie
case has been made out by the Plaintiffs for the grant of an ex-parte ad-interim
injunction. The Event is broadcasted through the Plaintiffs’ website and
mobile application namely DAZN, which is accessible across a variety of
digital devices including computers, smartphones, tablets, and other
electronic gadgets. The Plaintiffs have secured the Exclusive Rights for
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 6 of 12

<!-- page 24 -->

various events, including, the Event as specified in the Rights Confirmation
Letter dated 10.10.2025, through considerable financial investment.
25.

The apprehension of the unauthorized dissemination, telecasting, or

broadcasting of the Event on Defendant Nos. 1 to 26 shall pose a significant
threat to the Plaintiffs’ revenue streams undermining the value of the
considerable investment made by the Plaintiffs in acquiring the Exclusive
Rights. Additionally, the broadcast content, including footage, commentary,
and other composite elements, is fully safeguarded under the Act. Therefore,
the unauthorized use of these elements shall also infringe upon the copyright
protections accorded to the broadcast content under the Exclusive Rights.
26.

The issue of rogue websites engaging in the piracy of copyrighted

content presents a recurring threat and disseminating or communicating any
portions of the Event, without proper authorization or licensing from the
Plaintiffs, would violate the Plaintiffs’ Exclusive Rights.
27.

This Court in Universal City Studios LLC v. Dotmovies.baby,

2023:DHC:5842, granted a ‘Dynamic+’ injunction granting protection to
works generated during the course of the pendency of the suit as also future
works that will be created in the future so that while the content is generated,
the same is not infringed upon in violation of Section 37 of the Act, till the
time courts come to the rescue of the right holder. A relevant portion thereof,
is reproduced below:
“17. Any injunction granted by a Court of law ought to be effective in
nature. The injunction ought to also not merely extend to content
which is past content created prior to the filing of the suit but also to
content which may be generated on a day-to-day basis by the
Plaintiffs. In a usual case for copyright infringement, the Court firstly
identifies the work, determines the Copyright of the Plaintiff in the
said work, and thereafter grants an injunction. However, owing to the
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 7 of 12

<!-- page 25 -->

nature of the illegalities that rogue websites indulge in, there is a need
to pass injunctions which are also dynamic qua the Plaintiffs as well,
as it is seen that upon any film or series being released, they may be
immediately uploaded on the rogue websites, causing severe and
instant monetary loss. Copyright in future works comes into existence
immediately upon the work being created, and Plaintiffs may not be
able to approach the Court for each and every film or series that is
produced in the future, to secure an injunction against piracy.
19. As innovation in technology continues, remedies to be granted
also ought to be calibrated by Courts. This is not to say that in every
case, an injunction qua future works can be granted. Such grant of an
injunction would depend on the fact situation that arises and is placed
before the Court.
20. In the facts and circumstances as set out above, an ex parte ad
interim injunction is granted restraining the Defendants, who are all
rogue websites, from in any manner streaming, reproducing,
distributing, making available to the public and/or communicating to
the public any copyrighted content of the Plaintiffs including future
works of the Plaintiffs, in which ownership of copyright is undisputed,
through their websites identified in the suit or any mirror/redirect
websites or alphanumeric variations thereof including those websites
which are associated with the Defendants’ websites either based on
the name, branding, identity or even source of content. To keep pace
with the dynamic nature of the infringement that is undertaken by
hydra-headed websites, this Court has deemed it appropriate to issue
this ‘Dynamic+ injunction’ to protect copyrighted works as soon as
they are created, to ensure that no irreparable loss is caused to the
authors and owners of copyrighted works, as there is an imminent
possibility of works being uploaded on rogue websites or their newer
versions immediately upon the films/shows/series etc. The Plaintiffs
are permitted to implead any mirror/redirect/alpha numberic
variations of the websites identified in the suit as Defendants Nos.1 to
16 including those websites which are associated with the Defendants
Nos.1 to 16, either based on the name, branding, identity or even
source of content, by filing an application for impleadment under
Order I Rule 10 CPC in the event such websites merely provide new
means of accessing the same primary infringing websites that have
been injuncted. The Plaintiffs are at liberty to also file an appropriate
application seeking protection qua their copyrighted works, including
future works, if the need so arises. Upon filing such applications
before the Registrar along with an affidavit with sufficient supporting
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 8 of 12

<!-- page 26 -->

evidence seeking extension of the injunction to such websites, to
protect the content of the Plaintiffs, including future works, the
injunction shall become operational against the said websites and qua
such works. If there is any work in respect of which there is any
dispute as to ownership of copyright, an application may be moved by
the affected party before the Court, to seek clarification.”
(Emphasis Supplied)

28.

In view of the above, given the fact that the Plaintiffs’ Exclusive Rights,

as acquired from LCA are in question, if an ex-parte ad-interim injunction is
not granted at this stage, irreparable harm would be caused to the Plaintiffs.
Balance of convenience also lies in favour of the Plaintiffs. The need for
immediate relief is particularly pressing in this case, considering the live
broadcast of the Event. Any delay in blocking access to Defendant Nos. 1
to 26 or any other rogue websites providing the Impugned Services, could
lead to financial losses for the Plaintiffs, and an irreparable breach of the
Exclusive Rights. Therefore, swift action to prevent the alleged infringements
is crucial in the present case.
29.

Accordingly, Defendant Nos. 1 to 26, their owners, partners,

proprietors, officers, servants, employees and all others in capacity of
principal or agent acting for and on their behalf or anyone claiming through,
by or under them are restrained from hosting, streaming, broadcasting,
rebroadcasting, retransmitting, exhibiting, making available for viewing /
downloading, providing access to and / or communicating to the public,
displaying, uploading, modifying, publishing, updating and / or sharing
without authorization, any part of the Event i.e., ‘Serie A Championship’ in
any manner whatsoever so as to infringe the Plaintiffs’ Exclusive Rights.

30. Defendant Nos. 27 to 36, their directors, partners, proprietors, officers,
affiliates, servants, employees, and all others in capacity of principal or agent
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 9 of 12

<!-- page 27 -->

acting for and, on their behalf, or anyone claiming through, by or under are
directed to block and suspend the following Domain Names of Defendant
Nos. 1 to 26 immediately upon service of copy of this Order by the Plaintiffs’
Counsel:
Defendant
No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
31.

Website
9goals.io
tvonline123.com
in.yalla-live.org
yalla--shoot.live
socceronline.me
yalla-live.app
pelotaalibre.com
watch.streameast.soccer
kevinsport.top
totalsportek.army
tvmoca.net
kooora4life.com
pirlotvlibre.com
rakhoixv.cc
fbstreams.pm
en84.sportplus.live
freestreams-live1.watch
sportsdark.com
yalla-kooora.live
kooora365.io
koooralive-tv.io
pelotalibre-tv.futbol
rojatvdirecta.ws
yalla-lives.io
yalla-shoot-8k.com
atsport.tv

DNR
Defendant No. 27

Defendant No. 28
Defendant No. 29

Defendant No. 30

Defendant No. 31
Defendant No. 32
Defendant No. 33
Defendant No. 34
Defendant No. 35

Defendant No. 36

Further, Defendant Nos. 27 to 36 shall file an Affidavit in a sealed cover

/ password protected document disclosing the complete details of Defendant
CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 10 of 12

<!-- page 28 -->

Nos. 1 to 26, as available with Defendant Nos. 27 to 36, including e-mail
addresses, mobile numbers, contact details, payment details and KYC details,
within four weeks.
32.

Defendant Nos. 37 to 45, their directors, partners, proprietors, officers,

affiliates, servants, employees, and all others in capacity of principal or agent
acting for and on their behalf, or anyone claiming through, by or under them
are also directed to block Defendant Nos. 1 to 26, immediately upon service
of copy of this Order by the Plaintiffs’ Counsel.
33.

Defendant Nos. 46 and 47 are directed to issue necessary directions to

all ISPs for blocking / removing access to the websites as specified in
Paragraph No. 30 of this Order.
34.

Prior to or during the currency of the Event, if any further websites are

discovered, which are unauthorizedly streaming and communicating content
over which the Plaintiffs have Exclusive Rights, the Plaintiffs are granted
liberty to communicate the details of such websites to Defendant Nos. 27 to
45 for blocking the said websites on a real time basis without undue delay.
Upon receiving the said intimation from the Plaintiffs, Defendant Nos. 27 to
45 shall take steps to immediately block the said websites in question and
Defendant Nos. 46 and 47 shall also issue necessary blocking orders
immediately upon the Plaintiffs communicating the details of the websites,
which are illegally streaming the Event.
35.

Such a relief is called for in the present matter as any delay in blocking

the websites would, in fact, result in considerable pecuniary loss to the
Plaintiffs and result in irreparable violation of the Exclusive Rights of the
Plaintiffs.

CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 11 of 12

<!-- page 29 -->

36.

The Plaintiffs shall continue to file affidavits providing the details of

the newly discovered websites, their Domain Names, the DNRs and the
URLs, which are communicated and blocked to ensure that the Court is fully
informed of the websites in respect of which blocking orders are sought. The
Plaintiffs shall also file appropriate applications for impleadment of the said
websites and this Order shall be extended against the said newly added
Defendants.
37.

If any website, which is not primarily an infringing website, is blocked

in pursuance of this Order, it is permitted to approach the Court by giving an
undertaking that it does not intend to do any illegal dissemination of the
content over which the Plaintiffs have Exclusive Rights and the Court would
consider modifying the injunction if the facts and circumstances, so warrant.
38.

Let the Reply to the present Application be filed within four weeks after

service of the Notice. Rejoinder thereto, if any, be filed within four weeks
thereafter.
39.

The Plaintiffs are permitted to ensure compliance of Order XXXIX

Rule 3 of CPC within a period of two days and file the Compliance Affidavit
within two weeks.
40.

List before this Court on 27.02.2026.

TEJAS KARIA, J
NOVEMBER 6, 2025/‘gsr’

CS(COMM) 1152/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 07/11/2025 at 19:10:32

Page 12 of 12

<!-- page 30 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
