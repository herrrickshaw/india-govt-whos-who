---
doc_id: "ae066fcfcd42fe4e"
source_url: "https://www.meity.gov.in/static/uploads/2025/08/061923fea1b650bcbd84f2d8994635d2.pdf"
ministry: "Electronics and Information Technology (MeitY)"
title: "Notification (Extraordinary) regarding declaration of certain computer resources relating to identified Critical Information Infrastructures (CIIs) of the Government e Marketplace (GeM) and the computer resources of their associated dependencies as p"
date: "2025-08-20"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "204a2395d857233e"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-07082025-265274
xxxGIDHxxx
CG-DL-E-07082025-265274
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3521]
No. 3521]

िई दिल्ली, बुधवार, अगस्ट्त 6, 2025/िावण 15, 1947
NEW DELHI, WEDNESDAY, AUGUST 6, 2025/SHRAVANA 15, 1947

इलेक्ट्रॉजिकी और सूचिा प्रौद्योजगकी मंत्रालय
अधिसूचना
िई दिल्ली, 5 अगस्ट्त, 2025

का.आ. 3607(अ).—कें द्रीय सरकार, सूचिा प्रौद्योजगकी अजधजियम, 2000 (2000 का 21) की धारा 70 की
उप-धारा (1) और (2) द्वारा प्रित्त िजियों का प्रयोग करते हुए, सरकारी ई-माके टप्लेस प्लेटफ़ॉमम से संबंजधत कं प्यूटर
संसाधिों, िो सरकारी ई-माके टप्लेस की िािुक सूचिा अवसंरचिा है, और उिकी सहयुि आजितताओं के कं प्यूटर
संसाधिों को उि अजधजियम के प्रयोििों के जलए एतद्द्वारा संरजित प्रणाली घोजित करती है और संरजित प्रणाजलयों तक
पहुंच बिािे के जलए जिम्नजलजखत कार्ममकों को प्राजधकृ त करती है, अर्ामत:(क) संरजित प्रणाली तक पहुंच बिािे के जलए, सरकारी ई-माके टप्लेस द्वारा जलजखत रूप में प्राजधकृ त सरकारी ईमाके टप्लेस प्लेटफ़ॉमम का कोई अजभजहत कममचारी;
(ख) संजविात्मक प्रबंजधत सेवा-प्रिाता या तृतीय पिकार जवक्रेता के िल का कोई सिस्ट्य जिसे आवश्यकता के आधार
पर पहुुँच बिािे के जलए सरकारी ई-माके टप्लेस द्वारा जलजखत रूप में प्राजधकृ त दकया गया है; और
(ग) मामला िर मामला के आधार पर, सरकारी ई-माके ट प्लेस द्वारा जलजखत रूप में प्राजधकृ त कोई परामिी,
जवजियामक, सरकारी पिाजधकारी, संपरीिक और पणधारी।
2. यह अजधसूचिा रािपत्र में इसके प्रकािि की जतजर् से प्रवृत्त होगी।
[फा. सं. एए-14/2/2025-सीएसडी]
सजवता उत्तरे िा, वैज्ञाजिक िी
5249 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF ELECTRONICS AND INFORMATION TECHNOLOGY
NOTIFICATION
New Delhi, the 5th August, 2025

S.O. 3607(E).—In exercise of the powers conferred by sub-sections (1) and (2) of section 70 of the
Information Technology Act, 2000 (21 of 2000) (hereinafter referred to as the said Act), the Central Government
hereby declares the computer resources relating to the Government e Marketplace Platform, being Critical Information
Infrastructure of the Government e Marketplace, and the computer resources of their associated dependencies, to be
protected systems for the purposes of the said Act and authorises the following personnel to access the protected
systems, namely:—
(a)

any designated employee of the Government e Marketplace Platform, authorised in writing by the
Government e Marketplace to access the protected system;

(b)

any team member of contractual managed service provider or third-party vendor, who have been
authorised in writing by the Government e Marketplace for need-based access; and

(c)

any consultant, regulator, Government official, auditor and stakeholder, authorised in writing by the
Government e Marketplace on case to case basis.

2. This notification shall come into force on the date of its publication in the Official Gazette.
[F.No. AA-14/2/2025-CSD]
SAVITA UTREJA, Scientist G

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
AMIT KUMAR
JAISWAL

Digitally signed by AMIT KUMAR
JAISWAL
Date: 2025.08.07 17:32:18 +05'30'
