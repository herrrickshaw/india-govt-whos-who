---
doc_id: "ad31f6071baaacc6"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/278cf4dde14568283a1c26605c097979.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Mrs. Priyanka, CGC, Punjab & Haryana HC: Order dated 13.02.2018"
date: "2018-02-21"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "af995332e2384524"
---

<!-- page 1 -->

F. No. J-11017/15/2017-Judicial (Part-2)
Government of India
Ministry of Law & Justice
Department of Legal Affairs
Judicial Section
wee
Shastri Bhawan, New Delhi,
Dated 13" February, 2018
ORDER |
|
The President is pleased to engage Mrs. Priyanka, Advocate as Central Government
Counsel for conducting Central Government litigation (except the cases of Railways &
Taxation) before the Punjab & Haryana High Court at Chandigarh, as shown below, for a
period of three years from the date of this order or until further orders, whichever is earlier: |
Punjab & Haryana High Court at Chandigarh
Central Government Counsel |
a Contact details Ent Ne] No. |
Mrs. Priyanka Wio Shri Jaswinder Singh, Vill. Jubbal | P/1244/2014
(Radaur), Distt. Yamunanagar
(Haryana).
Mob: 9818890743, 9215500743
Email: jaswinder26po@gmail.com
2. The engagement and professional fee of the aforesaid advocate will be governed by
the terms and conditions contained in this Department's O.M. No. 26(1)/1999-Judl. dated
24.09.1999 read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through OMs. The aforesaid OMs are available on the official website of this
Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial Section’ under heading ‘Circulars
pertaining to litigations’.
3. Hindi version of this order will follow.
Soon
(Inder Kumar)
Additional Secretary
Copy for information to:-
1. PS to ML&J/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.
2. Shri Satya Pal Jain, Addl. SGI, Punjab & Haryana High Court, Chandigarh.
३. Shri Chetan Mittal, Asstt. SGI, Punjab & Haryana High Court, Chandigarh.
4. The Registrar, Punjab & Haryana High Court, Chandigarh.
5. Mrs. Priyanka, Central Govt. Counsel at the address as mentioned herein above.
6. Hindi unit, Department of Legal Affairs for Hindi translation of the order. ।
7. Guard File/Judicial Section with 5 spare copies
SoA
“© Siinvés)
Section Officer (Judicial)
Phone: 011-23384945
Email: Judicial-dla@nic.in
