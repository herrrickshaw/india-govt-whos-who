---
doc_id: "fe77de7e5ce4a1ff"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/52b80f8f1d4922640899eca0cc6a5c66.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of UL(VNO) ISP category 'B' for Mumbai Service Area bearing license no. DS-11/272/2022- DS-III dated 15.11.2022 of M/s JK BROADBAND INTERNET PRIVATE LIMITED"
date: "2025-01-01"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "90f4ed51cbb3fc74"
---

<!-- page 1 -->

DS-11/272/2022-DS-III(Vo.III)

I/3237511/2025

WITHOUT PREJUDICE
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(DS Cell)

DS-11/272/2022-DS-III(Vo.III)

Dated: 01-01-2025

To,
M/s JK BROADBAND INTERNET PRIVATE LIMITED
Ramnath Tiwari Chawl 3rd Golibar Top Mens Wear,
Santacruze, Mumbai City, Mumbai, Maharashtra, India, 400055
startup@neonbroadband.com
jkbroadband01@gmail.com
U64204MH2022PTC381812
Subject: - Termination/Revocation/Cancellation of UL(VNO) ISP category 'B' for
Mumbai Service Area bearing license no. DS-11/272/2022- DS-III dated 15.11.2022
o f M/s JK BROADBAND INTERNET PRIVATE LIMITED , under condition of clause
10.2 (i) (Part-I) of the said License Agreement.

Whereas, Department of Telecommunication, Government of India (“the
Licensor”) has granted an UL(VNO) license no. DS-11/272/2022- DS-III dated
15.11.2022 ( “the License”) to M/s JK BROADBAND INTERNET PRIVATE LIMITED
(“the Licensee”).
2.
WHEREAS, the LICENSEE is required to provide the services under the terms
and conditions of the License and instructions issued by the LICENSOR from time to
time.
3.
That for alleged violation of Conditions No. 18.2.1, 20.3, 20.5, 20.9, 21.2 & 21.3.
of the License , a Show Cause Notice No. DS-11/286/2023-DS-II dated 26-09-2024
(“SCN”) was issued to the Licensee on the address provided in the License and on the
address as obtained from Ministry of Corporate Aﬀairs website, in the event, the two
addresses were diﬀerent. The aforesaid SCN was sent by way of speed post bearing ID
No ED405188652IN as well as by an email on the registered email ID(s) of the Licensee
on 30.09.2024.
4.
That the aforementioned SCN was issued to the Licensee to submit its reply,
within 21 days, as to why the License granted to it should not be terminated, in terms of
the Condition No 10.2(i) under Chapter 1 of the Part-I of the License.
5.
That despite having given enough time and opportunity to the licensee to show
cause and explain the alleged violation of terms and conditions of the license mentioned
in the SCN, the licensee has failed to submit any reply whatsoever to the licensor within
the time frame allowed to the licensee.

<!-- page 2 -->

DS-11/272/2022-DS-III(Vo.III)

I/3237511/2025

6.
That the failure of the Licensee to submit any reply or explanation to alleged
violation of terms and conditions of the license mentioned in the SCN implies that the
Licensee has nothing to say in this regard and that the Licensee has failed to comply
with the conditions of the License and therefore, has violated the conditions of the
License as alleged in the SCN.
7.
Therefore, the competent Authority has now decided to terminate/ revoke/ cancel
t h e UL(VNO) ISP category 'B' for Mumbai Service Area bearing license no. DS11/272/2022- DS-III dated 15.11.2022 of M/s JK BROADBAND INTERNET PRIVATE
LIMITED, in terms of clause 10.2 (i) under Chapter I of Part-I of the License and that
the said license is terminated/ revoked/ cancelled eﬀective on and after the 61st
calendar day from the date of issue of this letter
8.
That the Licensee is further directed to terminate and stop all interconnections
with all service providers effective from the date of termination of the License.
9.
That the Licensee is further directed to issue a notice of at least 30 calendar days
to all its customers within 30 days from today in terms of the condition 10.2(i) of the
License Agreement reproduced as under:
“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order”.
10.
That the Licensee shall take note of the clause 11.2 of Chapter I of Part-I of the
License, which is reproduced as under:
“On revocation or surrender or cancellation of License/Service Authorization(s) due to
reasons whatsoever or expiry of the License, the relevant Bank Guarantee(s) shall be
released to the Licensee only after ensuring clearance of all dues, which the Licensee is
liable to pay to Licensor. In case of failure of the Licensee to pay the amounts due to
the Licensor, the outstanding amounts shall be realized through encashment of the Bank
Guarantees without prejudice to any other action(s) for recovery of the amounts due to
the Licensor without any further communication to the Licensee”.
11.
That the Licensee shall also take note that in case, it comes to the notice of the
Licensor about any other violation of license conditions by the Licensee, necessary
action in respect of said violation may be initiated by the Licensor in due course of time.
12. That the Bank Guarantee(s) submitted by the Licensee against the said the license
will be released under clause 11.2 Part-I of the License after ensuring clearance of dues,
including dues/ penalty arising, if any, as a consequence of the aforesaid violation.
13.

That the Licensee may acknowledge the receipt.

Director (DS-II)
dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to:-

1. DG Telecom, DoT, with a request to instruct the concerned LSA(s) to intimate all

<!-- page 3 -->

DS-11/272/2022-DS-III(Vo.III)

I/3237511/2025

Licensees / Infrastructure Providers in their area to discontinue to provide / obtain
any “telecom resources” to/ from M/s JK BROADBAND INTERNET PRIVATE
LIMITED

2. The Additional DGT, Mumbai LSA,
3. Sr. Joint CGCA(Revenue), Office of CGCA with a request to release the Bank
Guarantees of the aforesaid company after ensuring dues from respective sections
of DoT as per letter

No. vide 1-90/2012/LF-1(Pt.1) dated 05.09.2018 and letter

No. 1-8/2017/LFP-1 dated

17.04.2017. As far as due(s) of DS wing concerned

the same will be intimated to O/o CGCA in due course of time.

4. Secretary, TRAI
5. Wireless Advisor, for issue of Dues/ No Dues Certificate till the effective date of
termination of License and convey to office of CGCA.

6. Dy. CCA, O/o Pr CCA, Mumbai Circle
7. DDG(AS)/DDG(CS)/DDG(SAT)/ DDG(SA)/DDG(SPPI)/ DDG(LFP)/ DDG(WPF),
DoT HQ.

8. Director (IT), DOT HQ for uploading on DoT website for information to all Service
Providers to disconnect all telecom resources for the terminated service area as
per above.

9. F.N. DS-11/272/2022-DS-III(Vo.III)
