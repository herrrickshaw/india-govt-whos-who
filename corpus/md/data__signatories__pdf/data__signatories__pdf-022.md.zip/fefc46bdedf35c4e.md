---
doc_id: "fefc46bdedf35c4e"
source_url: "https://www.labour.gov.in/static/uploads/2026/09/a4ebfa45f9f65a29117f031c806f62e0.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification i.r.o. under Rule 164 of the OSH&WC Rules, 2026"
date: "2026-07-10"
pages: 7
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "21241203deab74a3"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-जे.एच.-अ.-16072026-274529
xxxGIDHxxx
CG-JH-E-16072026-274529
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 562]
No. 562]

नई कदल्ली, सोमिार, िुलाई 13, 2026/आषाढ 22, 1948
NEW DELHI, MONDAY, JULY 13, 2026/ASHADHA 22, 1948

श्रम और रोिगार मंत्रालय
(खान सुरक्षा महाजनदेिालय)
अजधसूचना
धनबाद, 10 िुलाई, 2026
सा.का.जन. 620(अ).— उपिीजिकािन्य सुरक्षा, स्ट्िास्ट््य और काययदिाएं (कें द्रीय) जनयम, 2026 के जनयम 164
के तहत मुझे जमली िजियों का प्रयोग करते हुए, मैं, उज्ज्िल ताह, खानों के मुख्य जनरीक्षक-सह-सुजिधा प्रदाता (जिन्हें खान
सुरक्षा महाजनदेिक के रूप में भी नाजमत ककया गया है), इसके द्वारा व्यािसाजयक प्रजिक्षण कें द्र में स्ट्टाफ, उपकरण और अन्य
सुजिधाओं के प्रािधानों का जिजनदेिन करता हं |
दायरा: यह मानक व्यािसाजयक प्रजिक्षण कें द्रों में उपलब्ध कराए िाने िाले स्ट्टाफ,उपकरण और अन्य सुजिधाओं
को जनर्दयष्ट करता है,िैसा कक उपिीजिकािन्य सुरक्षा, स्ट्िास्ट््य और काययदिाएं (कें द्रीय) जनयम, 2026 के जनयम 164 के
तहत आिश्यक है।
लागू होना: यह मानक उन सभी व्यािसाजयक प्रजिक्षण कें द्रों पर लागू होता है िो कोयला, धातु-युि (मेटैजलफे रस)
और तेल खदानों की प्रजिक्षण आिश्यकताओं को पूरा करने के जलए उपिीजिकािन्य सुरक्षा, स्ट्िास्ट््य और काययदिाएं (कें द्रीय)
जनयम, 2026 के जनयम 163 के तहत स्ट्थाजपत ककए गए हैं।

5289 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

अनुपालन की आिश्यकता |
I. यकद व्यािसाजयक प्रजिक्षण कें द्र कोयला या धातु-युि खदानों की प्रजिक्षण आिश्यकताओं को पूरा करता है:
(A) स्ट्टाफ:
1. जनयम 165 के उप-जनयम (1) के तहत जनर्दयष्ट योग्यता और अनुभि रखने िाले एक पूणयकाजलक प्रजिक्षण
अजधकारी को व्यािसाजयक प्रजिक्षण कें द्र के प्रभारी के रूप में जनयुि ककया िाएगा।
2. व्यािसाजयक प्रजिक्षण कें द्र के प्रजिक्षण अजधकारी की सहायता इनके द्वारा की िाएगी:
(a) एक पूणयकाजलक प्रजिक्षक [खनन] जिसके पास जनयम 169 के तहत जनर्दयष्ट योग्यता, प्रजिक्षण और अनुभि हो।
(b) एक पूणयकाजलक प्रजिक्षक [यांजत्रक] जिसके पास जनयम 169 के तहत जनर्दयष्ट योग्यता, प्रजिक्षण और अनुभि
हो।
(c) एक पूणयकाजलक प्रजिक्षक [जिद्युत] जिसके पास जनयम 169 के तहत जनर्दयष्ट योग्यता, प्रजिक्षण और अनुभि हो।
(d) उपरोि के अलािा, जििेष जिषयों में जििेषज्ञता रखने िाले अजतजथ संकाय (गेस्ट्ट फै कल्टी) या OEM (मूल
उपकरण जनमायता) के प्रजतजनजध को आिश्यकतानुसार आमंजत्रत ककया िा सकता है।
ितय यह है कक, अगर ककसी िोके िनल रेननंग सेंटर में 2000 से ज़्यादा कमयचाररयों को रेननंग दी िानी है, तो रेननंग
ऑकफसर की मदद के जलए एक फु ल-टाइम अजसस्ट्टेंट रेननंग ऑकफसर होगा, जिसके पास कम से कम 5 साल का
अनुभि और प्रबंधक का योग्यता प्रमाण-पत्र (certificate of competency) हो।
इसके अलािा, अगर ककसी िोके िनल प्रजिक्षण सेंटर में 4000 से ज़्यादा कमयचाररयों को रेननंग दी िानी है, तो
रेननंग ऑकफसर की मदद के जलए एक अजतररि फु ल-टाइम इं स्ट्रक्टर [माइननंग] भी होगा, जिसके पास जनयम 169
में बताई गई योग्यता, रेननंग और अनुभि हो।
3. रेननंग सेंटर/िकय िेड में रेनीज़ को प्रैजक्टकल रेननंग देने के जलए, अनुभिी कमयचाररयों/कामगारों/रेड्समेन में से
अलग-अलग रेड के जलए पयायप्त संख्या में रेनसय जनयुि ककए िाएंगे।
4. सहयोगी स्ट्टाफ़: जडजिटल और कफ़जज़कल ररकॉडय को मैनि
े करने के जलए ररकॉडय कीपर (क्लकय ), लाइब्रेररयन,
डेटा एंरी ऑपरे टर और मल्टी-टानस्ट्कं ग स्ट्टाफ़/ऑकफ़स अटेंडेंट, माली और सफ़ाई कमयचारी।
5. स्ट्पेिलाइज़्ड इं स्ट्रक्टर: संबजं धत जिषय/क्षेत्र के एक्सपर्टसय को फ़ु ल-टाइम/पाटय-टाइम जिजज़टटंग स्ट्पेिलाइज़्ड
इं स्ट्रक्टर के तौर पर रखा िाएगा, िो जिषय-जिजिष्ट लेक्चर देंगे और फ़स्ट्टय-एड रेननंग भी देंगे।
(B) उपकरण
िोके िनल रेननंग सेंटर को ये उपकरण उपलब्ध कराए िाएंग:े
1. रेननंग के जलए ज़रूरी उपकरण और साधन, िैसे इं टरनेट/LAN कनेजक्टजिटी िाले कं प्यूटर, संबंजधत सुरक्षा और
टेकिकल सॉफ़्टिेयर, ओिरहेड प्रोिेक्टर (OHP), स्ट्लाइड/कफ़ल्म प्रोिेक्टर, ऑजडयो-जिज़़ुअल साधन िैसे TV, LCD
प्रोिेक्टर (जिसमें सुरजक्षत काम करने के तरीकों और इमरिेंसी ररस्ट्पॉन्स पर रेननंग िीजडयो िाजमल हों)। अलगअलग रेननंग कोसय के जलए तैयार ककया गया कोसय मटीररयल, जिसमें खदान के सुरक्षा प्रबंधन योिना (SMP) का
अप-टू-डेट िियन और लेटेस्ट्ट सुरजक्षत संचालन प्रकियाएँ (SOP) िाजमल हों।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

2. मॉडल और डेमोंस्ट्रेिन रूम/हॉल, जिसमें मिीनरी, सुरक्षा उपकरणों और इलेजक्रकल उपकरणों के काम करने
िाले या कट-अिे मॉडल हों, िो अलग-अलग प्रकियाओं, ऑनलाइन/ऑफलाइन रेननंग मॉड्यूल और समय-समय पर
बताए गए अन्य जििरणों को कदखाते हों।
3. िुरुआती/ररफ्रेिर/खास रेननंग के जलए जडजिटल डेटा मैनेिमेंट का जडजिटल इंफ्रास्ट्रक्चर, ताकक ज़रूरत के जहसाब
से रेननंग कै लेंडर बनाया िा सके , दी गई रेननंग का मूल्यांकन ककया िा सके , आकद।
बिते, अगर कोई िोके िनल रेननंग सेंटर बहुत ज़्यादा मिीनीकृ त ओपनकास्ट्ट खदानों की ज़रूरतों को पूरा करता
है, तो िहां HEMM ऑपरे िन की रेननंग के जलए जसमुलेटर होने चाजहए, ताकक मौिूदा और नए जनयुि लोगों को
जस्ट्कल्स जसखाई िा सकें और उनकी जस्ट्कल्स को बेहतर बनाया िा सके
2. मॉडल और डेमोंस्ट्रेिन रूम/हॉल, जिसमें मिीनरी, सुरक्षा उपकरणों और इलेजक्रकल उपकरणों के काम करने
िाले या कट-अिे मॉडल हों, िो अलग-अलग प्रकियाओं, ऑनलाइन/ऑफलाइन रेननंग मॉड्यूल और समय-समय पर
बताए गए अन्य जििरणों को कदखाते हों।
3. िुरुआती/ररफ्रेिर/खास रेननंग के जलए जडजिटल डेटा मैनेिमेंट का जडजिटल इंफ्रास्ट्रक्चर, ताकक ज़रूरत के जहसाब
से रेननंग कै लेंडर बनाया िा सके , दी गई रेननंग का मूल्यांकन ककया िा सके , आकद।
बिते, अगर कोई िोके िनल रेननंग सेंटर बहुत ज़्यादा मिीनीकृ त ओपनकास्ट्ट खदानों की ज़रूरतों को पूरा करता
है, तो िहां HEMM ऑपरे िन की रेननंग के जलए जसमुलेटर होने चाजहए, ताकक मौिूदा और नए जनयुि लोगों को
जस्ट्कल्स जसखाई िा सकें और उनकी जस्ट्कल्स को बेहतर बनाया िा सके .
तेल खदानों (Oil Mines) की रेननंग ज़रूरतों को पूरा करने िाली िोके िनल रेननंग के मामले में:
(A) स्ट्टाफ़:
1. जनयम 165 के उप-जनयम (1) में बताई गई योग्यता और अनुभि रखने िाले एक पूणयकाजलक (whole-time)
रेननंग ऑकफ़सर को िोके िनल रेननंग सेंटर का इं चािय जनयुि ककया िाएगा।
बिते कक, 1000 से ज़्यादा रेननंग लेने योग्य कमयचाररयों िाले िोके िनल रेननंग सेंटर के मामले में, रेननंग ऑकफ़सर
की मदद के जलए एक पूणयकाजलक अजसस्ट्टेंट रेननंग ऑकफ़सर होगा, जिसके पास इं िीजनयटरं ग में जडग्री और
ऑयलफ़ील्ड में कम से कम दस साल का काम का अनुभि हो।
2. िोके िनल रेननंग सेंटर के रेननंग ऑकफ़सर की मदद इनके द्वारा की िाएगी:
a. इं स्ट्रक्टर: जिषय-जिजिष्ट लेक्चर देने के जलए, पूणयकाजलक/पाटय-टाइम इंस्ट्रक्टर - जिनलंग, पेरोजलयम, मैकेजनकल,
इलेजक्रकल, के जमकल और जियो-कफ़जज़क्स जिषयों में से प्रत्येक से एक-एक, और अन्य जिषयों से अजतररि इं स्ट्रक्टर।
खास इं स्ट्रक्टर: संबंजधत जिषय/क्षेत्र के एक्सपर्टसय को फु ल-टाइम/पाटय-टाइम जिजिटटंग खास इं स्ट्रक्टर के तौर पर
रखा िाएगा (जिसमें फस्ट्टय-एड रेननंग भी िाजमल है), ताकक िे जिषय-जििेष पर लेक्चर दे सकें ।
c. रेनसय: हर ऑयल माइन में खास या जस्ट्कल्ड काम की "ऑन-द-िॉब" रेननंग के जलए अनुभिी कमयचाररयों/रेड्समैन
को जनयुि ककया िाएगा। ये जिनलंग, पेरोजलयम, मैकेजनकल, इलेजक्रकल, के जमकल, जियो-कफजिक्स और अन्य
संबंजधत क्षेत्रों से होंगे और इन्हें माइन एिेंट की मंज़रू ी से रेननंग सेंटर के इं चािय ने अजधकृ त ककया होगा।
d. रेननंग सुपरिाइज़र: हर ऑयल माइन में रेनीज़ की ऑन-द-िॉब रेननंग की देखरे ख के जलए एक रेननंग सुपरिाइज़र
जनयुि ककया िाएगा, जिसे माइन एिेंट की मंज़ूरी से रेननंग सेंटर के इं चािय ने अजधकृ त ककया होगा।
e. सहयोगी स्ट्टाफ़: जडजिटल और कफजिकल ररकॉड्सय को मैनि
े करने के जलए ररकॉडय कीपर (क्लकय ), लाइब्रेररयन,
डेटा एंरी ऑपरे टसय और मल्टी-टानस्ट्कं ग स्ट्टाफ़/ऑकफ़स अटेंडेंट, माली और सफ़ाई कमयचारी।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(B) उपकरण:
(i) रेननंग टूल्स और एड्स िैसे इं टरनेट/LAN कनेजक्टजिटी िाले कं प्यूटर
(B) उपकरण:
(i) रेननंग के जलए ज़रूरी टूल्स और साधन िैसे इं टरनेट/LAN कनेजक्टजिटी िाले कं प्यूटर, ज़रूरी सेफ्टी और टेकिकल
सॉफ्टिेयर, ओिरहेड प्रोिेक्टर (OHP), स्ट्लाइड/कफल्म प्रोिेक्टर, ऑजडयो-जििुअल साधन िैसे TV, LCD
प्रोिेक्टर (जिसमें सुरजक्षत काम करने के तरीकों और इमरिेंसी ररस्ट्पॉन्स पर रेननंग िीजडयो िाजमल हों)। अलगअलग रेननंग कोसय के जलए तैयार ककया गया कोसय मटीररयल, जिसमें माइन का अप-टू -डेट सेफ्टी मैनेिमेंट प्लान
(SMP) और लेटेस्ट्ट सेफ ऑपरे टटंग प्रोसीिर (SOP) िाजमल हों।
(ii) मॉडल और डेमोंस्ट्रेिन रूम/हॉल जिसमें मिीनरी, ब्लोआउट जप्रिेंिन (BOP), सेफ्टी जडिाइस और इलेजक्रकल
इकिपमेंट के काम करने िाले या कट-अिे मॉडल हों; िो अलग-अलग प्रकियाओं, ऑनलाइन/ऑफलाइन रेननंग
मॉड्यूल और समय-समय पर बताए गए अन्य जििरणों को कदखाते हों।
(iii) िेल कं रोल, जिनलंग और अन्य महत्िपूणय ऑपरे िन्स के जलए एडिांस्ट्ड जसमुलेटर। मौिूदा और नए जनयुि लोगों
की जस्ट्कनलंग और अप-जस्ट्कनलंग के जलए असल नज़ंदगी के खतरों का अनुभि कराने िाले 3D िचुयअल ररयजलटी
(VR) जसस्ट्टम।
(iv) बेजसक/ररफ्रेिर रेननंग से िुडे जडजिटल डेटा के प्रबंधन के जलए जडजिटल इं फ्रास्ट्रक्चर, ताकक ज़रूरत के जहसाब
से रेननंग कै लेंडर बनाया िा सके (बेहतर होगा कक इसके जलए उपयुि AI टू ल्स का इस्ट्तेमाल हो), दी गई रेननंग का
मूल्यांकन ककया िा सके , आकद।
(C) इंफ्रास्ट्रक्चर और अन्य सुजिधाएं:
(i) ज़रूरी फनीचर से लैस इं चािय प्रजिक्षण अजधकारी का कमरा
(ii) ज़रूरी फनीचर से लैस अजसस्ट्टेंट िोके िनल प्रजिक्षण अजधकारी का कमरा
(iii) ज़रूरी फनीचर से लैस इं स्ट्रक्टर का कमरा
(iv) ज़रूरी फनीचर से लैस पयायप्त संख्या में लेक्चर हॉल/क्लास रूम
(v) ज़रूरी फनीचर से लैस ऑकफस, स्ट्टोर, ररकॉडय रूम आकद
(vi) ई-बुक्स, पढ़ने की ज़रूरी सुजिधा और ज़रूरी फनीचर के साथ लाइब्रेरी रूम का जिकल्प
(vii) रेननंग िेड और ऑक्यूपेिनल हेल्थ एंड सेफ्टी गैलरी, जिसमें स्ट्टैंडडय स्ट्टैंनडंग ऑडयसय, इमरिेंसी ररस्ट्पॉन्स प्लान,
पसयनल प्रोटेजक्टि इकिपमेंट (PPE) और ऑयलफील्ड्स में ऑपरे िन्स से िुडे खतरों के अन्य संबंजधत मॉडल कदखाए
गए हों।
(viii) आग बुझाने और प्राथजमक जचककत्सा (फस्ट्टय एड) की रेननंग और प्रदियन की सुजिधा।
(ix) ऊंचाई पर काम करने के जलए रेननंग की सुजिधा।
(x) पीने का पानी, िौचालय की सुजिधा (पुरुषों और मजहलाओं दोनों के जलए), और काफी खुली पार्किं ग की िगह।
[फा. सं. डीिीएमएस/03-4/2026/सीएमसी (मुख्यालय)]
उज्ज्िल ताह, मुख्य जनरीक्षक-सह-सुजिधाप्रदाता

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

MINISTRY OF LABOUR AND EMPLOYMENT
(Directorate General Of Mines Safety)
NOTIFICATION
Dhanbad, the 10th July, 2026
G.S.R. 620(E).— In exercise of the powers conferred on me under Rule 164 of the Occupational Safety, Health
and Working Conditions (Central) Rules, 2026, I, Ujjwal Tah, Chief Inspector-cum-Facilitator of Mines, also designated
as the Director General of Mines Safety, hereby, specify the provisions of staff, equipment and other facilities in
Vocational Training Centre, as follows:
Scope:

This standard specifies the staff, equipment and other facilities to be provided in Vocational Training
Centres, as required under Rule 164 of the Occupational Safety, Health and Working Conditions
(Central) Rules, 2026.

Applicability:

This standard is applicable to all Vocational Training Centres established under Rule 163 of the
Occupational Safety, Health and Working Conditions (Central) Rules, 2026 for catering the training
needs of Coal, Metalliferous, Oil Mines.

Compliance Requirement:
I. In case of the Vocational Training Centre catering the training needs of Coal or Metalliferous Mines:
(A) Staff:
1.

A whole time Training officer having qualification, experience as specified under sub-Rule (1) of Rule 165
shall be appointed as in-charge of the Vocational Training Centre.

2.

The Training officer of Vocational Training Centre shall be assisted by:
(a) One whole time instructor [Mining] having qualification, training and experience as specified under
Rule 169.
(b) One whole time instructor [Mechanical] having qualification, training and experience as specified under
Rule 169.
(c) One whole time instructor [Electrical] having qualification, training and experience as specified under
Rule 169.
(d) In addition to the above, guest faculties with expertise in specialised subjects or OEMs representative may
be invited as and when required.
Provided that, in case of vocational training centre, catering to more than 2000 trainable employees, the
Training officer shall be assisted by one whole time assistant Training Officer, having at least 5 years of
experience and possessing Manager’s certificate of competency.
Provided further that, in case of vocational training centre, catering to more than 4000 trainable employees, the
Training officer shall also be assisted by one additional whole time instructor [Mining] having qualification,
training and experience as specified in Rule 169.

3.

Adequate numbers of trainers in different trades from amongst the experienced employee/workmen/tradesmen
shall be appointed to impart practical training to the trainees in the training centre /work shed.

4.

Subordinate Staff: Record keeper (Clerks), Librarians, Data Entry Operators to manage digital & physical
records and Multi-Tasking Staff/Office attendant, Gardener & Sweeper.

5.

Specialized Instructors: Domain experts related to relevant subject/field shall be arranged as full/part-time
visiting Specialised Instructors, including first-aid training, for delivering subject-specific lectures.

(B) Equipment
The Vocational Training Centre shall be provided with following equipment:
1.

Training Tools and aids such as Computers with internet/LAN connectivity relevant safety and
technical software, Overhead Projectors (OHP), Slide/Film Projectors, Audio-Visual Aids such as
TV, LCD projector including training videos on safe work procedures and emergency responses.
Course material prepared for different training courses consisting of up-to-date version of the Safety
Management Plan (SMP) of mine and the latest Safe Operating Procedures (SOP).

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

2.

Model & Demonstration room/hall with working or cut-away models of machinery, safety devices
and electrical equipment, depicting different procedures, online/ offline Training Modules and other
details as directed from time to time.

3.

Digital infrastructure for management of Digital Data in respect of Initial/Refresher/ Special Training
for generation of need based Training Calendar, evaluation of training imparted, etc.
Provided that, in case of Vocational Training Centre catering the needs of highly mechanised
Opencast Mines, a Simulator for training on HEMM operations for skilling and up skilling of existing
and newly appointed persons.

(C)

Infrastructure and Other Facilities
1.

The training centre shall be provided with—

(a)

Class rooms equipped with large digital display system or LCD Projector with screen and computer /
laptop- 01 no.
Provided that if the trainable employees are more than 2000 persons 01 (one) additional class room
shall be provided for every additional 2000 persons or part thereof.

(b)

Training officer room -01 no.

(c)

Instructor room- 01 no.

(d)

Model room consisting of working models or cut-away models of machinery, safety devices and
electrical equipment -01 no.

(e)

Firefighting training and demonstration facility.

(f)

Library – 01 no.

(g)

Office/record room – 01 no.

(h)

Store room – 01 no.

(i)

Toilets – 03 (Separate for gents, ladies and transgender)

(j)

Training shed/work shed with all the necessary arrangement for demonstration and practice for job
training.

2.

Arrangement for conveyance of the trainees from the respective mine to training centre and back shall
be provided.

II. In case of the Vocational Training catering the training needs of Oil Mines:
(A)

Staff:

1.

A whole time Training officer having qualification, experience as mentioned under sub-Rule (1) of
Rule 165 shall be appointed as in-charge of the Vocational Training Centre.
Provided that, in case of vocational training centre, catering to more than 1000 trainable employees,
the Training officer shall be assisted by one whole time assistant Training Officer, possessing at least
Degree in Engineering with at least ten years of work experience in oilfields.

2.

The Training officer of Vocational Training Centre shall be assisted by:
a.

Instructors: For delivering subject-specific lectures, whole time/ Part time instructors, one
each from Drilling, Petroleum, Mechanical, Electrical, Chemical and Geo-Physics
disciplines and additional instructors from other disciplines.

b.

Specialized Instructors: Domain experts related to relevant subject/field shall be arranged as
full/part-time visiting Specialised Instructors, including first-aid training, for delivering
subject-specific lectures.

c.

Trainers: Every oil mine shall designate experienced workmen/ tradesman for "on-the-job"
training of specialised or skilled job, from Drilling, Petroleum, Mechanical, Electrical,
Chemical, Geo-Physics and other relevant disciplines, who has been authorised by the in
charge of Training Centre with the approval of the Mine Agent.

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

7

भारत का रािपत्र : असाधारण

d.

Training Supervisors: Every oil mine shall designate a training supervisor for supervising on
the job training of trainees, who has been authorised by the in charge of Training Centre with
the approval of the Mine Agent.

e.

Subordinate Staff: Record keeper (Clerks), Librarians, Data Entry Operators to manage
digital & physical records and Multi-Tasking Staff/Office attendant, Gardener & Sweeper.

(B) Equipment:
(i)

Training Tools and aids such as Computers with internet/LAN connectivity relevant safety and
technical software, Overhead Projectors (OHP), Slide/Film Projectors, Audio-Visual Aids such as
TV, LCD projector including training videos on safe work procedures and emergency responses.
Course material prepared for different training courses consisting of up-to-date version of the Safety
Management Plan (SMP) of mine and the latest Safe Operating Procedures (SOP).

(ii)

Model & Demonstration room/hall with working or cut-away models of machinery, Blowout
Prevention (BOP), safety devices and electrical equipment, depicting different procedures, online/
offline Training Modules and other details as directed from time to time.

(iii)

Advanced Simulators for well control, drilling and other important operations. 3D Virtual Reality
(VR) systems to simulate real-life hazards for skilling and up skilling of existing and newly appointed
persons.

(iv)

Digital infrastructure for management of Digital Data in respect of Basic/Refresher Training for
generation of need based Training Calendar (preferably using suitable AI tools), evaluation of training
imparted, etc.

(C) Infrastructure and Other facilities:
(i)

In-charge Training Officer Room equipped with the required furniture

(ii)

Assistant Vocational Training Officer Room equipped with the required furniture

(iii)

Instructor’s Room equipped with the required furniture.

(iv)

Adequate number of Lecture Hall(s)/Class Rooms equipped with the required furniture

(v)

Office, Store, Record room etc., equipped with the required furniture

(vi)

Library room option with e-books and necessary reading facility and required furniture

(vii)

Training shed & Occupational Health & Safety Gallery displaying standard standing orders,
Emergency response plan, personal protective equipment (PPE), and other relevant models of hazards
associated with operations in oilfields.

(viii)

Firefighting and First Aid training and demonstration Facility.

(ix)

Training facility for working at height.

(x)

Drinking water, toilet facilities (for both male & female), ample open parking space.
[F. No. DGMS/03-4/2026/CMC(HQ)]
UJJWAL TAH, Chief Inspector-cum-Facilitator of Mines

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. SARVESH KUMAR
SRIVASTAVA

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2026.07.16 00:51:49 +05'30'
