---
doc_id: "fff4d6c9ca6b6f8b"
source_url: "https://www.dahd.gov.in/static/uploads/2026/10/1a2585523eedcccdb68e25f63711d525.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Seeking comments/ views/ suggestions from stakeholders on draft proposal for Amendment of Recruitment Rules for the post of Office Superintendent in various Central Poultry Development Organisations and Central Poultry Performance Testing Centre."
date: "2026-10-07"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ffe87bb7d1f5906d"
---

<!-- page 1 -->

No. Q-14014/5/2023-Admin-6 [E-25r401

qRdv{iDTI
rtiFrrIRFL q{qItFI sfir grfl r*rgq

q{qrei ofufqfrArrrq
q:m$l-6 (NLM Division)

ffi6trr{,T{ftd,
ftai6': oz.ro.2026

OFFICE MEMORANDUM
Subject:

Seeking comments/ views/ suggestions from stakeholders on draft proposal for
Amendment of Recruitment Rules for the post of Oflice Superintendent, General
Central Service Group 'B' Non-Gazetted, Non- Ministerial in Level-6 (Rs.
35400-112400/-) of the pay matrix in various Central Poultry Development
Organisations and Central Poultry Performance Testing Centre, subordinate
offices under this Departrnent for uploading on the website of this Department regarding.

In pursuance of DoP&Ts OM No. AB-1401716112008-Estt.(RR) dated 13.10.2015,
regarding uploading of draft proposals for framing / amendment of Recruitment Rules on the
website and calling for comments, the draft Recruitment Rules proposed for amendment /
revision in respect of the post of Office Superintendent in various Central Poultry Development
Organisations and Centml Poultry Performance Testing Centre as per Annexure A is put up in

the official website of Department of Animal Husbandry and Dairying, Ministry of Fisheries,
Animal Husbandry and Dairying for comments from stakeholders'

Before finalizing the Recruifinent Rules in consultation with DoP&T and UPSC'
comments, if any, are invited from all stakeholders in the matter within a period of ttrirty days
from the date of notification in the website of this Departsnent. The objections / suggestions
received fiom the stakeholders within the specified period shall be considered by the Department

2.

as per rules / requirements.

Encl:asabove.

V

(Atimika Nigam)
Under Secretary to the Government of India

To,
Director, NIC, Dio AH&D, with a request to upload the draft Recruitment Rules proposal
on the website of this Departrnent.

<!-- page 2 -->

Annexure A
Column No. of the Provisions in the RRs
for the post of Head
Schedule
Clerk.

Provisions in RRs for
the post of Office
Superintendent.

Revised provisions
Proposed in light of
DOPT's guidelines.

Name ofpost ( l)

Head Clerk

Office Superintendent

Office Superintendent

Number ofpost (2)

J

0l* (One) 2007

4t(Four), (2026)
*Subject to variation

*Subject to variation

Classification (3)

Non-Gazetted
Ministerial Class-III

Level in Pay Matrix 2t0-10-290-15-320-E
(4)
B-15-380

Whether selection

post or

Selection post

dependent on workload

dependent on workload

General Central
Service Group 'B'

General Central Service

Non-Cazetted, NonMinisterial.

Non-Gazetted, Non-

Rs. 5500- 175-9000/-

Level-6 (Rs.
35400-l12400)

Selection

Selection

Group'B'
Ministerial.

non-

selection post (5)

Age limit for direct 2l -35 Years.
recruitment (6)

Not applicable

Not exceeding thirty years
(Relaxable
for
servant
upto
Govemment
5 years in accordance with
the instructions or orders

issued by the Central
Govemment)

Note: The crucial date for
determining the age limit
shall be as advertised by

Staff

Selection

Commission.

Educational and Essential:
other qualifrcations Intermediate/Senior

required for direct Cambridge/Higher
recruits (7)
Secondary with 5 years
office experience.
Desirable: Klowledge
in Accounts works and
Stores.

Not applicable

Essential:

Bachelor's degree of a
recognised University.

Note:

Qualifications are
relaxable at the discretion
of the Staff Selection
Commission or
Competent Authority, for
reasons to be recorded in
writing, in the case of
candidates otherwise
well qualified.

<!-- page 3 -->

Whether age and

N.A

Not Applicable

Not applicable

3 Years

Two Years

Two years for direct
recruits and promotees

educational

qualifications
prescribed for direct

recruitment will
apply in the case of
promotees (8)
Period of probation,
ifany (9)

Note 2: Direct Recruits
and

promotees shall be
required to complete

two to four weeks

training as specified by
the Competent authority
successful

for
completion

of

probation.

of Direct recruitment
Method
66-2/3o/o
recruitment:
Whether by direct Promotion 33-l/3%
recruitment or by failing both by transfer
promotion
by
deputation/
and
absorption

or

percentage

vacancies

filled by
methods (10)

of

to be
various

Promotion Failing
which by Deputation

Promotion failing

which by deputation

(ISTC) failing both by
direct recruitment.

<!-- page 4 -->

case

tbv

tlon
bsorption,

tlon
tlon
on

(l t)

tion

o Promotion:

From L.D. Clerks

(including
Steno-typist,
grades Storekeeper) with 3
which years service in the
grade.

to be Transfer:

Cashier or U

ivision Clerk cum

torekeeper in the pay
of Rs. 4000-6000/ith ten years regular
in the grade.

Person working in
similar or equivalent

on: Offrcers
the Central

grades from Central
Government/State
Govemments Offrces.

on:

tal Assistant

emment
a)

(D

Division Clerk
in various Central
ultry
Development
ons or Central
Performanc
g Centre in Level-4
f the pay matrix with ten
regular service in
grade
pper

ultry

eputation (lncludin
Holding

term contract):

ogous post

fficers under the Central
vemment or State
arent
cadre
Union
;or
EITI tories or Recognised
iD with ten years esearch Institutions or
niversities or Public
ervlce tn the
Undertakings or
emi
or
Government
intment thereto on
tatutory
or
Autonomous
regular basis in the

gular basis in the

ale ol pay of Rs.
5000

anlsatlons

o

valent in the paren
or Department,

a) (i) holding

posts(s) in the
iiD Possessing two nalogous
t cadre or
experience
lishment

istration

unts work.

o

artment; or (ii) with
ix years regular service in
and
e grade rendered after
ppointment thereto on a
gular basis in Level-5 of
pay matrix in the

t cadre or
ent; or

(iii) with ten years
lar service in the
rendered after
pointment thereto on a
lar basis in Level-4 of
e pay matrix in the
t cadre or
; and

<!-- page 5 -->

(b) possessing the
educational qualifications
and experience prescribed
for direct recruits under
column 7.

lf a Departmental Class III D.P.C.
Promotion

Committee exists,

what is

Group

'B' Group 'B' Departmental
Promotion Committee
Departmental
(
considering
Promotion Committee
or
considering
promotion ) consisting confirmation) consisting
of:of :-

for

its

composition ( l2)

(for
promotion

(i) Director (Animal
Husbandry) or Deputy 1. Joint Secretary in the
Secretary (Poultry)- Departmen! Chairman;
Chairman
Joint
Director

or
(ii) Director, Central Commissioner in the
Poultry Development Department - Member;
2.

Organisation,
Chandigarh - Member

and

3. Deputy Secretary or

(iii) A Group 'A' Deputy Commissioner in
offrcer from any the Department- Member;
Central Govemment una"r Secretary of the
Ofiice located in l+.
iDivision - Member
Chandigarh- Member

Circumstances in
which Union Public
Service Commission
is to be consulted in

making recruitment
( 13)

N.A.

with Consultation with Union
Consultation
Service
Public
Service
Union Public
not Commission not
Commission
necessary
necessary
