---
doc_id: "fe57adc4cde5b0ec"
source_url: "https://doj.gov.in/static/uploads/2025/12/2862373b77483290ff29def5869febbf.pdf"
ministry: "Department of Justice (DoJ)"
title: "KIIT University"
date: "2023-07-28"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "1c880ac4c3213124"
---

<!-- page 1 -->

File No. N-9/1/2023-NM (e-8335)
] Government of India
Ministry of Law and Justice
(Department of Justice) ‘
Jaisalmer House,26, Mansingh Road,
New Delhi-110011
Dated: 28.07.2023
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded to the payment of Rs. 4,99,714/- (Rupees
Four Lakh Ninety Nine Thousand Seven Hundred and Fourteen Only) to KIIT University towards First
instalment (being 20% of total project cost of Rs. Rs. 24,98,570/- (Rupees Twenty Four Lakh Ninety
Eight Thousand Five Hundred and Seventy only) for undertaking research project titled “Mapping Global
Best Practices in Pendency Reduction to Indian Judicial System and Tracing the Way Forward: An In-
depth Empirical Engagement with Select Courts of India” under the Scheme of Action Research and
Studies on Judicial Reforms as per the terms of the agreement signed between KIIT University and
Department of Justice on 25" July, 2023. 15" instalment of Rs. 4,99,714/- (Rupees Four Lakh Ninety
Nine Thousand Seven Hundred and Fourteen Only) is payable to the Implementing Agency. The
Implementing Agency is requested to adhere to the timeline mentioned in the approved proposal and
agreement dated 25" July. 2023
2. The expenditure involved is debitable to Demand no.65 during 2023-24 (Non-Scheme) Major Head
2052-Secretariat General Services-00. 090-Secretariat, 08-Department of Justice, 08.00.31-Grant-in-
Aid (General). |
3. This has been entered in the Register of Grants / Expenditure at SI.No. 1 at page no.191-192
4 This issues with the approval of IFD (Law) vide Note no.9 Dated 14.07.2023 & Secretary (J)
approval vide Note no.13 dated 14.07.2023 in eOffice /Computer File No. e-8335.
Yj
Jp
(Yashasvi Kumar)
Director
Tel./Fax No. 011- 23072135
E-mail: dir-nm-doj@gov.in
To, .
Pay & Account Officer,
Ministry of Law & Justice, Department of Legal Affairs
Janpath Bhawan, Janpath ;
New Delhi 4
Copy to: -
1 Cash section, Department of Justice with one spare copy and copy of Agreement. It is requested
that payment may be made through e-payment to “KIIT University”.
2 DDO & Under Secretary (Admin.!l), Department of Justice, Jaisalmer House, New Delhi
vi FD/Budget division, Ministry of Law & Justice, Legislative Department, Shastri Bhawan, New
Delhi
4f NIC, Jaisalmer House. New Delhi for uploading on the Department of Justice website
Kalinga Institute of Industrial Technology (KIIT) University, Bhubaneswar, District Khorda, Odisha
- 751024 (Kind Attention: Dr. Pinaki Nandan Pattnaik, Principal Investigator)
6 Principal Accounts Office, 4" Floor, Ministry of Law & justice, Lok Nayak Bhawan, Khan Market,
New Delhi.
7. Guard File
