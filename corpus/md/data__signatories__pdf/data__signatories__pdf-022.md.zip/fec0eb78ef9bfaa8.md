---
doc_id: "fec0eb78ef9bfaa8"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/b7aed7ec7384a25fb14d289612134337.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '155304' to Tiruppur City Municipal Corporation"
date: "2022-06-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ee1c6c43ce48f5e5"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-10/2018-AS-III/Short codes/387/ IL/6

2,_\

Dated: ... /06/2022

To,
The Commissioner,
Department of Telecommunications,
Tirupur City Municipal Corporation,
Tiruppur.
Subject:Allotment of short code '155304' to Tiruppur City Municipal
Corporation, Tiruppur.
Kindly refer to your letter No. El/6630/2011-XI dated 08.06.2022 requesting to
allocate a Short Code to Tiruppur City Municipal Corporation, Tiruppur.
2.
In this regard, it is hereby stated that the short code '155304' has already been
allocated by DoT to all Municipal Corporation to all State/UTs vide DoT letter No. 16­
3/2011-AS-III/Part-IW24/918 dated 27.05.2014 (copy enclosed).
3.
Accordingly, it is requested that the same may be utilized by Tiruppur City
Municipal Corporation, Tiruppur.
4.

This is issued with the approval of competent authority.

Encl: As above.
(Sane
Copy forwarded for information and necessary action, if any, to:
1. Secretary, TRAI.
2. CMD MTNL /CMD BSNL.
3. Shri Thiru. Kranthikumar Pati, Commissioner, Tiruppur City Municipal Corporation,
Tiruppur w.r.t. letter No. El/6630/2011-XI dated 08.06.2022 with a request to
appoint a nodal officer to implement the helpline. The Nodal officer may contact Sr.
DDG (LSA), LSA Unit, concerned States/UTs ..
4. Director (P&N), DoT (HQ) (respective LSA field unit may be asked to co-ordinate
with respective Nodal Officers and TSPs for implementation of Helpline, as and
when approached).
5. A copy for upload on DoT Website.

<!-- page 2 -->

17211'91
46527272020/ASdll'

tfovernrnent dflndia:
Minisoy of.@ mmurrleation &Jnf.amiation Technology
t).tpattmerit.ef'.feletpmmuni<;atiorts·

· · Acc'CSs.Ser.'iccsWint
20~ tl@ioku.'Road,.New:Oelfif-11 oo-OJ
'""'
. :.,,..,;,,.1.!•.
·:c· ,,,.,,,,1.3
.,......,.,.,,11,
1 .0 rrr1 n . "'"'.,..4 A ·\ i;b:
J,.0;,]
11 :rart..µ .u.,. r~~ .

.Dated ~7/0512014

.SubJe¢-,AJfo:cabl:!11 of Sb~rrenac; '1'5SJ«W! fg~Jl'~µnfoipliiCorporations.
Tam directed to ®tiv.e,:y:the approval o.f competent aulhorify for .aJfocatlon.of'
$hort'Q>de '1S5304':tq art Munitjptl -Ctirporatfons with fo11owfn~ feature$,al; IJilder.:
(i~

.ca~ot:y•fr Sorv.lc~ .;(i.e. mandat.Ory ·5ervice:-fo be provided br «ll'the,
A«e$S ·ptoviders•.

(ii)

A.tcess'ibtfity: Un-testriClcilfai. .l!Vliilable:oil ST:D also.

(ili) Metered :Service,

1.

A-ttSra~· Gbvt'./'UTS.Chief'$()Cretifles; (It is i;equeSicdto qiroulatethe.i'nsirucfions

w au ·~U!licipal'<;<lrporatio11s wbo m~.~i.rtt ~.Ncidal ffili¢erf~Jto c:i>-0T.llii11itc
w.iih Telecom Seryice ProViaers).
·2 ,

3.

•SCcretar}s 1'~

Additi(ltJal 'Commi5sfoner, Mirn i<iipal ©orpoi'atfon Chandigarh with ref~nce ·ro

Momo·lettcr. N0,MGC.lJTJ2014/44'7 oatecLlJ/05l20lik,
·4.

CMDMTNTJj~sNL,

·s.

l)irecttw ·(S~l),f, DGT (;$~), '.(AU TERM Cells iri11,y ·be ~sk¢cl tl'.t~lilat~ :wifh
i:especiiYe NodaJ·offiecTs. and TS'Pl' f0r impf-ementatlo11 ofHelpfuie~ ~:and when
ap,ptoa:c;n e4)~,

~OG &IJ:witlrrequest ta kintlly up16ad·on DoT Website.
