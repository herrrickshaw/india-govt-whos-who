---
doc_id: "ffe93427eac1dad7"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6992c825ec5412.94995279.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Notification - Shri K. Kannan, an IFS Officer of 2004 batch of Punjab Cadre to voluntarily retire from service, notification dated 16-02-2026"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5b6e10b5554c3e87"
---

<!-- page 1 -->

|
|
पे कि (To be published in Part I Section 2 of the Gazette of India) . "
F.No. 25012/01/2026-IFS-Il * यु |
Government of India - पं |
. Ministry of Environment, Forest & Climate Change |
Indira Paryavaran Bhawan, ned
: : 6% Floor, Prithvi Block, .. .*- “ |
: Jor Bagh Road, AliGanj : a |
New Delhi -110003. i
5 a Dated: The 16 February, 2026 - wae |
: NOTIFICATION =. ।
|
The President is pleased to permit Shri K. Kannan, an IFS Officer of * a |
हु 2004 batch of Punjab Cadre to retire.from service voluntarily in accordance wg ol
with Rule 16(2A) of the All India Service (Dedth-cum-Retirement Benefits) A ag en
se i Rutlesy 1958: 0 + नव जयीफिियाए «जन - «० वन्य edit y une ARETE AMAL PETE ete का च i
/ |
(xk on ve
: x i
. 4 . (Prem Prakash Maurya) “: pM or
. ५ Under Secretary to.the Government of India “ |
Tel: 011-20819192 + * «४५ oa
To, :
The Manager, . |
Govt. of India Press, Le Bote
- Minto Road, Delhi-with a copy of Hindi Version. :
Copy to:- * a
1. The Chief Secretary, Govt. of Punjab, Chandigarh. ४ :
2. The Secretary, Union Public Service Commission, Dholpur House, .
New Delhi.
3. The Principal Secretary, Govt. of Punjab; Chandigarh |
4. The PCCF, Govt. of Punjab, Chandigarh.
5. Shri K. Kannan, IFS(PB:2004). .
6. File No. 17012/01/1999-IFS-II and F. No. 17015/01/1999-IFS-II.
7. Hindi Section for Hindi translations of Notification. |
i
|
1
i
