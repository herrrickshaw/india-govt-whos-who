---
doc_id: "fdd2e0cab0d4290c"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/aa567fbc495553f168b2d25cd864c2e4.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Call Data Records CDR format with 22 fields"
date: "2025-06-17"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6883663cacb11964"
---

<!-- page 1 -->

of

India
Government
Ministry of Communications
Department of Telecommunications
(Licensing Policy)
Sanchar Bhawan, 20 Ashoka Road New Delhi
File No.: 800-23/2015-AS-II-Volume(2)

Dated: 17.06.2025

To

All UASL/UL (having Access Service Authorization)

Licensees

Subject: Call Data Records (CDR) format with 22 fields-reg
20.07.2021 on
supersession to letter no. 800-23/2015-AS-II dated
the
approval of
abovementioned subject, the undersigned is directed to convey
Records (CDR) format having 22
competent authority to implement the Call Data

In

fields as enclosed at Annexure-l.
Encl.: Annexure-I

Ge

aor
ADG

Copy

to:

(Nisha)

(LPU)

DG(T), DoT HQ-for kind information & necessary action.
2. DDG(AS), DoT HQ-for kind information & necessary action.
HQ-for kind
3. DDG(CS)/DDG(DS)/DDG(AI&DIU)/ DDG(SPPI)/DDG(SA),DoT

1.

information.

<!-- page 2 -->

Annexure-!
CDR Format

S. No.
1.

Target / A-Party Number*: to be provided as
received subject to Licence provisions

2.

Call Type (In/ Out)

3.
4.

Type of Connection (Prepaid/ Postpaid)
B Party Number
to be provided as received
Licence
provisions
ta
subject

5.

LRN:

6.

Translation of LRN

7,
3.

Call date
Call Initiation Time (CTT): to be supplied as Hr/

9.

Call Duration (second)

10,|

11.|

Remark
Mandatory

Field required

:

Mandatory
Mandatory
Mandatory

:

Mandatory for called party
number. However, not
applicable for PSTN, ILD and
toll free numbers.

A/B Party Number

:

TSP- LSA name

to be Supplied in DD/MM/YY YY format

Minute/ Second i.e, 23:40:35

First BTS location (Brief description of location
and mark)

First Cell Global ID (MCC/ MNC/ LAC/ Site ID)
,

party number
Mandatory
Mandatory

of the called

Mandatory- SMS/MMS delivery
duration should be Zero
TSPs will ensure to provide BTS
address of their own managed
Network. In rest scenario, CellId will be provided by them.
First BTS location may/may not
be available in case target has
forwarded his number.
Mandatory
it will be First EUTRAN Cell
Global identity in case of 4G
and ANI. in case of VoWiFi

access.
12.|

13.|

Last BTS location (Brief description of location
and mark)

Last Cell Global ID

TSPs will ensure to provide BTS

address of their own managed
Network. In rest scenario, CellId will be provided by them.
Last BTS location may/may not
be available in case target has
forwarded his number.
Mandatory
Last EUTRAN Cell
Global identity in-case of 4G
and ANI in case of VoWiFi
It

14.|

SMS Centre No. — in case of SMS/MMS

will

be

access.
Mandatory

ago

<!-- page 3 -->

os

19.|

Service Type — Mention voice call (v), SMS
the case may be,
IMEI/ ESN GSM or CDMA
provide the full digit
case may be,
IMSI /MIN-GSM or CDMA as
provide the full digit
Call forwarding number — Provide the call
case of call forwarding
forwarding Number
— Provide the name of
Circle
Network
/
Roaming

20.|

Switch ID /MSC Id

21.|

INnTG

15.|
16.|

17.|

13.|

as

-

the

in

the network and Circle

Mandatory
Mandatory
Mandatory — MSC Id of
concerned network to be
supplied
Mandatory
Mandatory
In case. of end to end4G VoLTE
call, it will be Originating IOI.

:

22.|

Mandatory
Mandatory

Mandatory

Out. TG

In case of end to end 4G VoLTE

call, it will be Terminating IOI.

to

be reflected:in
also needs
*j. In case of CDR of a number, party is target number and
covering letter.
the number latched with the target tower.
ii. In case of Tower dump/tower CDR, A party
|Ol & Out
or from circuit switched network, Originating
iii. In case 4G VoLTE call is made
TG OR InTG & Terminating |O! will be provided.
A

to

is

sq
