---
doc_id: "fdae85c688db5feb"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/1286414a264d721a6c86e0f15e34281e.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Notification dated 06.04.2010 for nomination of Member, NCMEI"
date: "2010-04-06"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b2770dbaa1afe631"
---

<!-- page 1 -->

TO BE PUBLISHED IN PART | OF THE GAZETTE OF [NDIA है
Government of india
Ministry of Human Resource Development
Department of Higher Educatior.
New Delhi, tne 6" April, 2016
NOTIFICATION
No. F, 7-8/2009-(MC):- in pursuance of the Section 3 (2) read with
Section 5 of the National Commission for Minority Educational Institutions Act,
2004, the Ceniral Government is hereby pieased to nominate Dr.-Cyriac Thomas,
former Vice Chancellor, Mahatma Gendti University, Kottayam, Kerala and Dr.
Mohinder Singh, former Member, National Commission for Religious and
Linguistic Minorities as Members of the National Commission for Minority
: Educational Institutions (NCMED.
2. The tenure of the appointment of, the aforesaid persons as Member.
NCMEI shall .be for five years with effect from the date they respectively assume
office as such Member; and their salaries-and allowances shal! be regulated in
accerdance with the ‘Salaries and Allowances and other conditions of service. of
Chairperson and other Members, Rules’ under Section 24 (2) (a) of the National
Commission for Minority Educational-Institutions Act. 2004. -
3. The Headquarters of the office of the aforesaid Members shall be in New
Delhi. . . .
ORDER
"Ordered, that notification be published in the Gazette of india for general
information. .
Ordered aiso, that a copy of the notification be communitated to Dr. .
Cyriac Thomas and Dr. Mohinder Singh.
We Mer a
: (Sunil Kug
Joint Secretary to the Soren India
Manager, हे . ao \j
Government of India
. (Bharat Sarkar Press)
Faridabad.
