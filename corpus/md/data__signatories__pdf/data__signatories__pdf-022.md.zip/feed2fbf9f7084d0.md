---
doc_id: "feed2fbf9f7084d0"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/007961761ebdd11a9fa9b9d1d0543655.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Office Memorandum - Placing details of CPIOs and FAA on the website of Public Authorities."
date: "2019-10-24"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b6ac6e90ba192fa"
---

<!-- page 1 -->

F, No. 11-5l2019-TC

Government oflndia
MinisEy of Human Resource Development
DeparEnent of Higher Education
Technical Coordihation Sectior
Shastri Bhawan, New Delhi
Dated clY october, 2019
OFFICE MEMORANDUU

Subiect:

Placing details ofCPIOs and FAA on the website of Public Attlorities.

NIC section is requested toupdate the details of the CPIOs ((:cntral Public Informarion Officer) and
FAA (First Appeuate Authority) for Technical Coordination (TC), Tcchnicat Education (TE) and Technical
Education Quality Improvenrent Programme (TEQIP) section as follows:

CPIO, Department of

Higher
Education, MHRD, Room No. 102 B,
C-Win& Shastri Bhawan, New Delhi

FAA Details
Dr. llenuka Mishra, Director (TEJ &
F'i rst Appellate Authority, Department
o[ lligher Education, MHRD, Room
No. iJ26, C-Wing, Shastri Bhawan,

- 110001.

New l)elhi - 110001.

CPIO Details

Section

S.No.

Mr. Aieet Kumar, Under Secretary &

TC

1

I

Ph:2307 0426
a eet.kuma

Matters
related

2

Ph:21'li.iBB632

Mr- Ajeet Kumar, Under Secretary &

CPIo, Department of

to

EdCIL

I.-irst nppellate Authority, Department

Education, MHRD, Room No. 102 B,
C-WinB, Shastri Bhawan, New Delhi

of Iligher Education, MHRD, Room

Ph.23070426
a ieet. ku m a r12 @ n ic. in

4

TE

Mr. Ajeet Kumar, Under Secretary &
CPIo, Department of Higher
I Education, MHRD, Room No. 102 B,
C-Wing, Shastri Bhawan, New Delhi

TEQIP

Mr. I)rashant Agarwal, Director &

Higher

- 110001.
3.

I

rer l r ka.Inishra@Oic.i0

ntc tn

No.4 27, C-Wing, Shastri Bhawan, New
Dellr i - 110001.

Ph:01i23073271
rashant.a
ov. rn
Dr'. Ilenuka Mishra, Director (TEJ &
First Appellate Authority, Department

of lligher Education, MHRD, Room
No. ..i26, C-Wing, Shastri Bhawan,

- 110001.

New l)elhi - 110001

Ph:2307 O426

re n u ka.mishra

aieet.kumarl2(anic.in
Mr. Aieet Kumal Under Secretary &

CPIO, Department of

Higher

I

n rc. rn

Mr I'rashant Agarwal, Director &
First nppellate Authority, Department

ol llrgher Education, MHRD, Room

I

I

Plt 23O7 0426

Dellrr 110001.
l,h ot123073271.

aieet. kuma 112 @nic.in

rasira nt.a

Education, MHRD, Room No. 102 B,
C-Wing, Shastri Bhawan, New Delhi

- 110001.

No 127, C-Wing, Shastri Bhawan, New

I

ov.ln

(Aieet Kumar)

lnt:480
To

Director (NtC), MHRD, Shastri Bhawan, New Delhi.

so(rE)
TEQIP Section

I

I

Under Secretary & CPIO

Copy for information to

|
