---
doc_id: "fd9071c7aba4eb2e"
source_url: "https://steel.gov.in/sites/default/files/2025-04/Steel%20and%20Steel%20Products%20%28Quality%20Control%29%20%28second%20amendment%29%20Order%2C%202016_2.pdf"
ministry: "Steel (MoS)"
title: "Steel and Steel Products (Quality Control) (second amendment) Order, 2016_2.pdf"
date: "2025-04"
pages: 8
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "f9c811b4fb072392"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 2261]

ubZ fnYyh] 'kqØokj] flrEcj 16] 2016@Hkkæ 25] 1938

No. 2261]

NEW DELHI, FRIDAY, SEPTEMBER 16, 2016/BHADRA 25, 1938

इ पात मं ालय
आदेश
नई द ली, 16 िसत बर, 2016
का. आ. 2966(अ).—के

ीय सरकार, भारतीय मानक यूरो अिधिनयम, 1986 (1986 का 63) क धारा 14 ारा

द त शि य का योग करते ए इ पात और इ पात उ पाद (गुणव ता िनयं ण) आदेश, 2015 म िनम्निलिखत संशोधन
करती है, अथात्:1.

यह आदेश इ पात और इ पात उ पाद (गुणव ता िनयं ण) (ि तीय संशोधन) आदेश, 2016 कहा जाएगा।

2.

इ पात और इ पात उ पाद (गुणव ता िनयं ण) आदेश, 2015 क अनुसूची के थान पर िन निलिखत अनुसूची रखी

जाएगी, अथात्:“अनुसच
ू ी
(पैरा ाफ 2(च), पैरा ाफ 3 और पैरा ाफ 8 देख)
भारतीय मानक यूरो के अिनवाय माणन वाले इ पात उ पाद क सूची
.
सं.

भारतीय
मानक सं या

शीषक

आईटीसी (एचएस)

कॉलम (2) म दशाये गये मानक के
उ पाद

भावी होने
क तारीख

(1)

(2)

(3)

(4)

(5)

(6)

1.

आईएस 432
: पाट 1

4449 GI/2016

कॉन ट रइनफोसमट 72139190
के िलए माइ ड टील
72139990
और
मीिडयम
टेनसाइल टील बॉस 72149190

सभी उ पाद

18 माच,
2016

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

तथा हाड- ॉन टील 72149990
वायर: पाट 1 माइ ड
72159090
टील और मीिडयम
72279090
टेनसाइल टील बॉस
72283019
72283029
72286099
2.

आईएस
432 : पाट 2

कॉन ट रइनफोसमट
के िलए माइ ड टील
और मीिडयम
टेनसाइल टील बॉस
तथा हाड- ॉन टील
वायर: पाट 2 हाडॉन टील वायर

721710
721790
सभी उ पाद

72299031

18 माच,
2016

72299033
72299040
72299059
72299090

3.

आईएस 513

को ड र ू ड लो
काबन टील शी स
और ी स

720915

72255010

(क) ेड पद नाम सीआर1, सीआर 2,

720916

72255020

सीआर 3, सीआर 4, सीआर 5 के

720917

72259900

अनुसार उ पाद;

720918

72269210

720925

72269220

(ख) उपयु

720926

72269920

उ पाद के िलए ;

720927

72269930

720928

72269940

72099000

72269952

721123

72269990

18 दस बर,
2016

(क) के अलावा अ य
18 माच,
2016

72119090
4.

आईएस 1079 हॉट रो ड काबन टील
शीट और ीप

720825

72089000

(क) ेड पद नाम एचआर 1, एचआर

720826

72111300

2, एचआर 3, एचआर 4, एचआर 5 के

720827

721114

अनुसार उ पाद;

720836

721119

720837

72119090

(ख) उपयु

720838

722530

उ पाद के िलए;

720839

722540

720840

72259900

720852

722691

720853

722699

18 दस बर,
2016

(क) के अलावा अ य
18 माच,
2016

720854
5.

आईएस

फो जग के िलए काबन

1875

टील िबले स, लू स,
लै स और बॉस

72071120

72149190

(क) ेड पदनाम, 15सी8, 30सी8,

72071190

72149990

35सी8, 45सी8, 55सी 8, 65सी 6

18 दस बर,

के अनुसार उ पाद;

2016

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k

3

72071220

72159090

(ख) उपयु

72071290

72249040

उ पाद के िलए;

720719

72249091

72072010

72249099

72072090

72283029

(क) के अलावा अ य
18 माच,
2016

72286099
6.

आईएस
2879

मेटल आक वै डग
इले ो स के िलए
माइ ड टील

72061090

72139910

72071190

72149990

72071290

72241000

72071920

72249091

72071990

72249099

72132010

72279090

सभी उ पाद

18 माच,
2016

72139110
7.

8.

आईएस

टील चेकड ले स

3502

आईएस
5872

को ड रो ड टील
ी स (बॉ स
टै् प स)

72081000

72259900

720840

72269130

721114

72269190

721190

72269910

72254019

72269990

721123

72262030

721129

72269210

721220

72269930

721230

72269952

721240

72269990

सभी उ पाद

18 माच,
2016

सभी उ पाद

18 माच,
2016

721250
9.

आईएस
5986

चरल फो मग और
ल गग उ े य के िलए
हॉट रो ड टील लैट
उ पाद

720825

72111300

(क) ेड पद नाम 205, 235, 255,

720826

721114

325, 355, 420, 560 के अनुसार

720827

721119

उ पाद ;

720836

72119012

720837

72119090

(ख) उपयु

720838

72253090

उ पाद के िलए;

720839

72254013

720840

72254019

720851

72254020

720852

72254030

720853

72259900

720854

722691

72089000

722699

18 दस बर,
2016
(क) के अलावा अ य
18 माच,
2016

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY
10
.

11
.

आईएस
6240

लो ेशर
िल फएबल गैस
िसिल डस के
िविनमाण के िलए हॉट
रो ड टील लेट (6
एमएम तक) शीट और
ीप

आईएस

ाईट बॉस

7283

और इं जीिनय रग
अनु योग के िलए
मशी ड पाट के
उ पादन के िलए हॉट
रो ड बॉस

[PART II—SEC. 3(ii)]

720825

72089000

720826

721114

720827

721119

720837

72119090

720838

72253090

720839

722540

720852

72259900

720853

722691

720854

722699

721320

72283021

(क) आईएस 1570 के साथ प ठत

721391

72283022

आईएस 7283 के

721399

72283023

72143000

72283029

721491

72286091

721499

72286092

72159090

72286093

72279090

72286099

सभी उ पाद

18 माच,
2016

ेड पद नाम

ेड 21सीआर4एमओ2,
ेड 42सीआर4एमओ2,
ेड 42सीआर4एमओ2,

18
दस बर,
2016

ेड 15सीआर3,
ेड 17सीआर3,
ेड 20एनआई7सीआर2एमओ2,
ेड 15एनआई5सीआर4एमओ1,
के अनुसार उ पाद;
(ख) उपयु

(क) के अलावा अ य

उ पाद के िलए;

18 माच,
2016

12
.

आईएस
7887

सामा य इं जीिनय रग
उ े य के िलए माइ ड
टील वायर रॉड

72139190
72139990
सभी उ पाद

72279090

18 माच,
2016

13 आईएस
. 10748

वेि डड ू स और
पाइप के िलए हॉट
रो ड टील ीप

720825

721114

(क) ेड पद नाम 3, 4 एवं 6 के

720826

721119

अनुसार उ पाद;

720827

721190907

720836

2253090

(ख) उपयु

720837

72259900

उ पाद के िलए;

2016

720838

722691

720839

722699

18 दस बर,
2016

(क) के अलावा अ य

18 माच,

72089000
14
.

आईएस
11513

को ड रो लग उ ेश्य
के िलए हॉट रो ड
काबन टील ीप

720825

721114

(क) ेड पद नाम सीआर5 के अनुसार

18 दस बर,

720826

721119

उ पाद;

2016

720827

721190907 (ख) उपयु

(क) के अलावा अ य

<!-- page 5 -->

¹Hkkx IIµ[k.M 3(ii)º

Hkkjr dk jkti=k % vlk/kj.k
720836

2253090

720837

72259900

720838

722691

720839

722699

5
उ पाद के िलए;

18 माच,
2016

72089000
15
.

आईएस

वेि डड ू स और
पाईप के िलए हॉट
रो ड टील नैरो िव द
ीप

15647

नोट 1 : इस आदेश के

सभी उ पाद

721114

18 माच,
2016

721119
72119090

ावधान कॉलम(2) म उि लिखत ासंिगक भारतीय मानक सं या के तहत शािमल अनुसूची के

कॉलम (3) के अधीन व णत उ पाद पर लागू ह गे।
नोट 2 : कॉलम (4) के तहत उि लिखत आईटीसी (एचएस) को स क

कृ ित जेने रक और संकेता मक है।”.
[एफ. सं. 1(1)/2016-टी डी (ख ड 1)]
सुनील बड़ वाल, संयु क सिचव

नोट :

दनांक 15 दस बर, 2015 का मूल आदेश भारत के राजप , असाधारण, भाग II, ख ड 3, उपख ड (ii) म
दनांक 18 दस बर, 2015 के का.आ. 3458(अ) के

ारा कािशत कया गया था, िजसे बाद म दनांक

17 माच, 2016 क अिधसूचना सं या का.आ. 1149(अ) के ारा संशोिधत कया गया है।
MINISTRY OF STEEL
ORDER
New Delhi, the 16th September, 2016
S.O. 2966(E).—In exercise of the powers conferred by section 14 of the Bureau of Indian Standards Act, 1986
(63 of 1986), the Central Government after consulting the Bureau of Indian Standards hereby makes the following
amendment to the Steel and Steel Products (Quality Control) Order, 2015, namely:1. This Order may be called the Steel and Steel Products (Quality Control) (Second Amendment) Order, 2016.
2. In the Steel and Steel Products (Quality Control) Order, 2015 for the SCHEDULE, the following SCHEDULE shall
be substituted, namely:-

“SCHEDULE
[See paragraph 2(f), paragraph 3 and paragraph 8]
List of steel products under mandatory Bureau of Indian Standards certification
Indian
Sl.
Standard
No.
number
(1)
(2)
1.
IS 432 :
Part 1

Title
(3)
Mild
Steel
and
Medium Tensile Steel
Bars and Hard–Drawn
Steel
Wire
for
Concrete
Reinforcement: Part
1 Mild steel and
medium tensile steel
bars

ITC(HS)
(4)
72139190
72139990
72149190
72149990
72159090
72279090
72283019
72283029
72286099

Products of the
Standard indicated in
the column (2)
(5)

All products

Date of coming
into force
(6)

18th March, 2016

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY
2.

3.

4.

5.

6.

7.

8.

IS 432 :
Part 2

IS 513

IS 1079

IS 1875

IS 2879

IS 3502

IS 5872

Mild
steel
and
Medium Tensile steel
bars and Hard–Drawn
Steel
Wire
for
Concrete
Reinforcement: Part
2 Hard-Drawn Steel
Wire
Cold reduced low
carbon steel sheets
and strips

Hot Rolled Carbon
Steel Sheet and Strip

Carbon steel billets,
blooms, slabs and
bars for forgings

Mild steel for metal
arc
welding
electrodes

Steel
Plates

Chequered

Cold Rolled
Strips
Strappings)

Steel
(Box

721710
721790
72299031
72299033
72299040
72299059
72299090
720915
720916
720917
720918
720925
720926
720927
720928
72099000
721123
72119090
720825
720826
720827
720836
720837
720838
720839
720840
720852
720853
720854
72071120
72071190
72071220
72071290
720719
72072010
72072090
72061090
72071190
72071290
72071920
72071990
72132010
72139110
72081000
720840
721114
721190
72254019
721123
721129
721220
721230
721240
721250

All products

[PART II—SEC. 3(ii)]

18th March, 2016

72255010
72255020
72259900
72269210
72269220
72269920
72269930
72269940
72269952
72269990

(a) Products
conforming to grade
designations CR1, CR2, 18th December, 2016
CR3, CR4, CR5 ;

72089000
72111300
721114
721119
72119090
722530
722540
72259900
722691
722699

(a) Products
conforming to grade
designations HR1, HR2, 18th December, 2016
HR3, HR4, HR5 ;

72149190
72149990
72159090
72249040
72249091
72249099
72283029
72286099
72139910
72149990
72241000
72249091
72249099
72279090

(a) Products
conforming to grade
designations: 15C8,
30C8, 35C8, 45C8,
55C8, 65C6;
(b) For products other
than (a) above;

72259900
72269130
72269190
72269910
72269990
72262030
72269210
72269930
72269952
72269990

(b) For products other
than (a) above;

(b) For products other
than (a) above;

18th March, 2016

18th March, 2016

18th December, 2016

18th March, 2016

All products

18th March, 2016

All products

18th March, 2016

All products

18th March, 2016

<!-- page 7 -->

¹Hkkx IIµ[k.M 3(ii)º
9.

IS 5986

Hot Rolled Steel Flat
Products for Structural
Forming and Flanging
Purposes

10.

IS 6240

Hot Rolled Steel Plate
(up to 6 mm) Sheet
and Strip for the
Manufacture of Low
Pressure Liquefiable
Gas Cylinders

Hkkjr dk jkti=k % vlk/kj.k
720825
720826
720827
720836
720837
720838
720839
720840
720851
720852
720853
720854
72089000
720825
720826
720827
720837
720838
720839
720852
720853
720854

72111300
721114
721119
72119012
72119090
72253090
72254013
72254019
72254020
72254030
72259900
722691
722699
72089000
721114
721119
72119090
72253090
722540
72259900
722691
722699

(a) Products
conforming to grade
designations: 205, 235, 18th December, 2016
255, 325, 355, 420, 560 ;
(b) For products other
than (a) above;
18th March, 2016

72283021
72283022
72283023
72283029
72286091
72286092
72286093
72286099

(a) Products
conforming to grade
designations of IS 7283 18th December, 2016
read with IS 1570:
Gr. 21Cr4Mo2,
Gr. 42Cr4Mo2 (High
Mn),
Gr.
42Cr4Mo2,
Gr.
15Cr3,
Gr. 17Cr3,
Gr. 20Ni7Cr2Mo2,
Gr. 15Ni5Cr4Mo1 ;
(b) For products other
than (a) above;
18th March, 2016

11.

IS 7283

Hot Rolled bars for
production of bright
bars and machined
parts for engineering
applications

721320
721391
721399
72143000
721491
721499
72159090
72279090

12.

IS 7887

Mild steel wire rods
for
general
engineering purposes

72139190
72139990
72279090
720825
720826
720827
720836
720837
720838
720839
72089000
720825
720826
720827
720836
720837
720838
720839
72089000

13.

14.

IS 10748

IS 11513

Hot Rolled Steel Strip
for Welded Tubes and
Pipes

Hot Rolled Carbon
Steel Strip For Cold
Rolling Purposes

7

All products

All products
721114
(a) Products
conforming to grade
721119
72119090722 designations: 3, 4 & 6;
53090
(b) For products other
72259900
than (a) above;
722691
722699
721114
(a) Products
conforming to grade
721119
72119090722 designations: CR5;
53090
(b) For products other
72259900
than (a) above;
722691
722699

18th March, 2016

18th March, 2016

18th December, 2016
18th March, 2016

18th December, 2016
18th March, 2016

<!-- page 8 -->

8
15.

THE GAZETTE OF INDIA : EXTRAORDINARY
IS 15647

Hot
rolled
steel
narrow width strip for
welded tubes and
pipes

721114
721119
72119090

All products

[PART II—SEC. 3(ii)]

18th March, 2016

Note 1 : The provisions of this Order shall apply to the products described under column (3) of the Schedule
covered under relevant Indian Standard number mentioned under column (2).
Note 2 : The ITC (HS) Codes mentioned under column (4) are generic and indicative in nature.”.
[F. No. 1(1)/2016-TD (Vol. 1)]
SUNIL BARTHWAL, Jt. Secy.
th

Note : The principal order dated the 15 December, 2015, was published in the Gazette of India, Extraordinary,
Part II, Section 3, Sub-section (ii) vide number S.O. 3458(E) dated the 18th December, 2015 and
subsequently amended vide notification number S.O. 1149(E), dated 17th March, 2016.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

HARINDRA
KUMAR

Digitally signed by HARINDRA
KUMAR
Date: 2016.09.19 10:04:04
+05'30'
