---
doc_id: "ff4fc3763cf7cccb"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/dabbd6dc08d50abec3dc182e265e97b6.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Appointment of New Financial Advisor at PGIMER, Chandigarh"
date: "2025-01-10"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bdcef084be01a86a"
---

<!-- page 1 -->

v - 1 7020I 193t201 7-tNt-t I

Government of lndia
Ministry ot Health & Family Wetfare
(tNt-il Section)
Nirman Bhawan, New Delhi

Dale:24.12.2024
OFFICE TilEMORANDUM

Subject: Fillng up the post ol Flnanclal Advisor ln pGlMER,

Chandlgarh

. Ilq und,ersigned is directed to refer to this Ministry's oM of even number
dated 07.11.2024folowed by OM dated02.1z.zlz4;; the subjeit;;td;;;
above and ro say that the rast date oJ receipt of apprications io,. tri- pori
J
Financial Advisor in PGTMER has been further extendeli upto t0.0I.2025.
S*,f'od by l{oohm

me:2ffi{$fi{.ff:szror
Under Secretary to the Govt. Ol lndia
Tet: 0 t 1-23061881
To,
1. The Dy. Comptroller & Auditor General ol lndia - HH: O.o the C&AG of lndia, #9,
Deen Dayal Upadhyay Marg, New Dethi - '1 1 0124
2. The Controller General oJ Accounts, Ministry o, Finance, (Deptt. of Expenditure),
7th Floor Lok Nayak Bhawan, Khan Market, New Delhi-1 10003.
3. The Controller General of Defence Acdounts, West Block-V, R.K. Puram, New
Delhi- 1 10022
4. The Chairman Railway Board, Railway Board, Rail Bhawan, New Delhi-1 10001
5. Member (Finance) Telecom Commission, Sanchar Bhawan, New Delhi-1 1 0001
6. NIC Section, Ministry of Health & Family Welfare with a request to upload it on
the website of lhe Ministry.
7. DDA, PGIMER, Chandigarh for uploading it on the website ol the lnstitute.

<!-- page 2 -->

fqe - {isf.d't' tl'N">) $-/Sf
;?
1.. RIY
'ltL )${

*

,4

fr{

v- 1 7020i 1 93i?01 7':!Nl-il
Govtrnrnent ol kdH
Uinlsw ot neann U FamilY Wellare
(F.ll.ll Secen)
Nirntan srawanbl:1.H&

'

oslce rElffitEu$
Suhect. Fltlng up tlB P{il

q{ PlnanclEl Adrvttor €um'ch'cl Accosnlmt'

PchlEn, Chandqtrn'

-i3i[[i3:JEffi ftr,ffi,ffi

$]:'rH]rk!#f $l

i,Nsslamr

unds, seorefl;t

fr f.$r8tr'i$

1?'{6:!l

<!-- page 3 -->

-. :\

ls!

+
(i

)^.4p/
v - 1 7 020 I 1 93t 201 7-t Nt-t I

Government of lndia
ttrS:

Minislry ol Heallh & Family weltare
(lNl'll Sectlon)
Nirman Bhawan. New Delhi
Oaled 02-12-2024

/(*

L,

OFFICE MEMORANOUM

Subject:- Filing up the post ol Financial Advisor in PGIMER, Ohandigarh- reg.

V7

The undersigned i9 difscted to rerer to lhis Mnistry's earlier OM ol even
number dated 07.11.2024 on the subject mentionsd above and to say that the

lasl date ol receipl ol applications for the post d Financial Advisor in

POIMER has been ertondod upto 15,12.2024.|t is, thererore, requesled that a
panel ol names ol suitable otlicers may be sent along with the complete ACR
dossiers, Vigilance Clearance and Cadre Clearance to the Undersigned in Room
No. 753- A Wing, Ministry of l'lealth and Family Wefare, Nirrnan Bhawan, New
Delhi.

Signed by
Shambhu Kumar
D ate : o z- 1 z - 2a

1$"?,gi3P,jJ"g

Under Secretary to the Govt. Of lndia
Tel: 011.23061510

To.

All concerned as Per list enclosed

LIST TO WHOM,THE OM IS TO BE SENT

X f n. Addrtional Secretary & Esrablishmenl Oillcer' Do PT No(h Block'

New

' Delhi.

General of lndia'HR: O/o theC&AG
Z. The Dy. Comptroller & Auditor
- 110124
-:11 "
Ib. oeen'oav"i Lpiottvav Marg' New Delhi

ol lndia'

\.,\"'''
ol
"t-\
Accounts' Ministry ol Flnance {D-eptt
of
General
controller
Jhe
3.
,,
New Delhi'110003
.-r'\ Expenditure. liniloo-' loi n"yak Bhawan Knan Maixet
New
Accounts, wost Block-v' R K Puram'
4. The controrler General ot Defence
-\$:"
t 10022
-\L'"Delhithawan' New DelhiBailway Board' Railway Board Rail
\Ctt
charrman
The
5.
\ * l1oool

\

\\
\\,
..\\

^\

.\

\ .-,
c\'

<!-- page 4 -->

s$'

Tdecom Commission, Sanchar Bhawan, Nev/ Delhi1

to upload it on
8. ODA;

u\?*

\',), '\

\''\

upfoading il on the website of the lnstitute.
