---
doc_id: "ff77d3abaddf3a8a"
source_url: "https://www.mea.gov.in/images/pdf/Advertisement-for-Appointment-of-Director-General-RIS.pdf"
ministry: "External Affairs (MEA)"
title: "Advertisement for Appointment of Director General RIS"
date: ""
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "80089b1ba9903573"
---

<!-- page 1 -->

a \
‘Ss Ministry of External Affairs
Jawaharlal Nehru Bhawan
23-D Janpath Road, New Delhi- 110011
: ADVERTISEMENT FOR APPOINTMENT OF DIRECTOR GENERAL RIS
Set up by the Ministry of External Affairs after the 7 NAM Summit in Delhi in 1983, Research
and Information Systems for Developing Countries(RIS) is an important think tank. It is based in
New Delhi. RIS is pursuing research work in the fields of international economic relations,
economic and financial crisis, global economic governance, climate change, regional economic
cooperation, WTO, WIPO, etc.
\t is proposed to appoint a Director General for RIS on the basis of direct recruitment or
promotion out of a panel to be recommended by a Search-cum-Selection Committee
constituted by the Ministry of External Affairs in terms of RIS Bye-Laws.
The Director General shall hold office for a term of five years from the date on which he/ she
assumes the charge of his/her office. As the Director General, in his/her capacity of Principal
Executive Officer, shall exercise the powers and discharge the duties as delegated by the
: Chairman of the Governing Council and the President of the General Body of RIS, he/she must
be a person of the highest level of competence, integrity, moral and institutional commitment.
Essential Qualifications:

e Ahigh second class Post Graduate degree in Economics/ Public Administration, from a

है recognized university.

e Adoctoral degree in the relevant discipline.

e 12 years experience in research and training in the Economics/Public Administration
out of which at least five years should be in a senior supervisory level including guiding
research studies, in an Institute of repute/ university.

Pay Scale:
e Equivalent to Level 16 in the Government of India

<!-- page 2 -->

cn le Limit:

fF

, © Not exceeding 55 years of age on the last date of receipt of applications for the post
Selection Process:
The procedure for selection shall be based on personal interaction of shortlisted candidates
with a Search-cum-Selection Committee constituted by the Ministry of External Affairs,
Government of India.
How to Apply:

; Those having the above mentioned qualifications and desirous of being considered for the post
may send in their applications, in duplicate, in the proforma given below by post/e-mail within
one month of the publication of this advertisement to Shri Raghuram S., Joint Secretary(Policy
Planning and Research), Ministry of External Affairs, Room No.74, South Block, New Delhi.
Email: jspp@mea.gov.in
Applications received after the last date or found incomplete will not be entertained.

Sd/-
Member Secretary
Search-cum-Selection Committee

<!-- page 3 -->

A Proforma for Application

1. Name:
7 2. Date of Birth:
3. Current Position and Address:
4. Educational Qualifications:
5. Academic/Research Experience/Employment:
6. Area of Specialization:
7. Honors/Awards received:
8. Professional Affiliations:
9. Number and Details of Research Publications:
10. Number of Books authored/edited:
Date: Signature of the Applicant
।
