---
doc_id: "feffb2aca2ef8600"
source_url: "https://www.dsir.gov.in/static/uploads/2025/10/c59ab4335c17099036dd926b144e14dd.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Office Order No. H-12019/01/2005-Estt dated 13th September, 2013"
date: "2025-10-28"
pages: 2
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "47f855606bb31eec"
---

<!-- page 1 -->

a ज+-<-०-+-०+ पाक -+-3+ “० >८- मम ऊक. 3. <-.3+.33. ८33... 3. लिननननमनम-म«नभथ७ कक ननननननन-यननाणागाणाणीीी-पनननमम«»»म»» मम.
No.H-12019/05/2013-Estt.
GOVERNMENT OF INDIA
MINISTRY OF SCIENCE & TECHNOLOGY
DEPARTMENT OF SCIENTIFIC & INDUSTRIAL RESEARCH
Technology Bhawan,
New Mehrauli Road,
New Delhi-110016.
Dated: 13' September, 2013
OFFICE ORDER
Subject: Right to Information Act, 2005 — Nomination for Nodal Officer under RTI
Online Scheme.

Shri Vimal Kumar Varun, Scientist ‘F’, Department of Scientific & Industrial
Research (DSIR) has been nominated as the Nodal Officer under RTI Online Scheme vice
Dr. K. Jayakumar, Joint Secretary, DSIR, with immediate effect, and until further orders,
with the approval of competent authority. -
vs Shri Varun will continue to discharge his duties and responsibilities as CPIO, DSIR.

nwa ali
(Kuldip Kumar)
Under Secretary to the Govt. of India

Tel. No. 26590682

To

1. Shri Vimal Kumar Varun, Scientist ‘F’, CPIO & Nodal Officer - RTI, DSIR.

2. US to Secretary, DSIR & DG, CSIR.

3. ~ US to Joint Secretary (Admn.)/PS to Financial Adviser, DSIR/CSIR.

4. All Officers/Sections in DSIR.

5. CMD, CEL/CMD, NRDC/DG, CDC.

6. Hindi Section for Hindi version.

<!-- page 2 -->

सं.एच-12019/05/2013-स्थापना
भारत सरकार
विज्ञान और प्रौद्योगिकी मंत्रालय
वैज्ञानिक और औद्योगिक अनुसंधान विभाग
टेक्नोलाजी भवन,
नया मेहरौली मार्ग,
नई दिल्‍ली - 10016
दिनांक; सितम्बर, 2013
कार्यालय आदेश
विषय: सूचना का अधिकार अधिनियम, 2005 - आरटीआई आनलाइन योजना के अर्न्तगत नोडल
अधिकारी के लिए नामांकन।
श्री विमल कुमार वरूण, वैज्ञानिक 'एफ' वैज्ञानिक और औद्योगिक अनुसंधान विभाग
(डीएसआईआर) को सक्षम प्राधिकारी के अनुमोदन से डा0 के. जयकुमार, संयुक्त सचिव, डीएसआईआर
की ओर से आरटीआई आनलाइन योजना के अर्न्तगत नोडल अधिकारी के रूप में तत्काल प्रभाव से तथा
अगले आदेशों तक के लिए नामित किया गया है।
2. श्री वरूण, सीपीआईओ, डीएसआईआर के रूप में अपने कर्तव्यों और जिम्मेदारियों का निर्वाहन
जारी रखेंगे।
सख्त लत
(कुलदीप कुमार)
अवर सचिव, भारत सरकार
दूरभाष सं. 26590682
प्रतिः
Wr श्री विमल कुमार वरूण, वैज्ञानिक 'एफ', सीपीआईओ एवं नोडल अधिकारी - आरटीआई,
डीएसआईआर।
a सचिव, डीएसआईआर तथा महानिदेशक, सीएसआईआर के अवर सचिव।
3 संयुक्त सचिव(प्रशा.) के अवर सचिव/वित्तीय सलाहकार, डीएसआईआर/सीएसआईआर के निजी
सचिव।
4. डीएसआईआर के सभी अधिकारी/अनुभाग।
5. सीएमडी,सीईएल/सीएमडी, एनआरडीसी/डीजी, सीडीसी।
