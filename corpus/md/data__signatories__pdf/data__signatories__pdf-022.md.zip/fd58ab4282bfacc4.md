---
doc_id: "fd58ab4282bfacc4"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/f277254bf9e5f05de1cdd79b9298af25.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Corrigendum for the post of Field lnvestigator (Fl) dated 18.04.2025 Job Code: IEG/Admin/CO/Estab-iv / 67 / 40"
date: "2025-04-18"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "db18c405841fa3c6"
---

<!-- page 1 -->

INSTITUTE OF ECONOMIC GROWTH
University Enclave, North Campus, Delhi – 110007

CORRIGENDUM
File No.IEG/Admin/CO/IV/

18th April 2025

In continuation to the Corrigendum dated 11.04.2025, this is to inform all concerned
that the qualifications and experience for the posts of Research Investigator and Field
Investigator as advertised earlier have been revised to align with the approved guidelines
issued by the Ministry of Health & Family Welfare (MoH&FW), Government of India, vide
letter dated 12.03.2021.
The revised eligibility criteria are as follows:
Designation

Qualification for Direct Recruitment

Experience

3 years’ experience in data
At least 2nd Class Post Graduate Degree
collection, analysis, and report
in Demography / Population Studies /
Research
writing. (Relaxable for
Statistics / Economics / Mathematics /
Investigator
candidates with higher
Sociology / Social Work / Psychology /
qualifications. Posts may be from
Anthropology / Geography. Knowledge of
different disciplines.)
Computer Applications is essential.
At least 2nd Class Post Graduate Degree
Some experience in data
in Demography / Population Studies /
Field
collection and analysis. (Posts
Statistics / Economics / Mathematics /
Investigator
may be from different
Sociology / Social Work/ Psychology /
disciplines.)
Anthropology / Geography.
This issues with the approval of the Competent Authority.
Sd/(Siba Sankar Sahoo)
Administrative Officer
