---
doc_id: "fd5ba3d5c9cf1fa7"
source_url: "https://dohe-education.gov.in/static/uploads/2026/07/52ecccb1d2751c884428b16aba2aa2cf.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Notification No. 9-26/94-U.3(A) dated 16th June 2026 regarding withdrawal of the Ministry’s Notification No. 9-26/94-U.3 dated 15th March 2000.(Hindi)"
date: "2026-06-16"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1dc21b2265fa5fb7"
---

<!-- page 1 -->

(swa t rrErrir trTrT-l Gig-I cl rmnrarttl
E{I{f, HtrFR
fq=Iqnr

dTrilq

rrqcr{ fQtHr ftarrJr
En*S:rr qsTrry

frfu ema.2, il$ Errft
fdFiltm: 16

W, zozl

grfrstrar
_-------

d'. 9-20r94-T.3(q): trEfu, Affi {rr.rr mi ftlafracronr }ryffi 3ndrrr 1qfiff)
3{frfrqrr, tSS6 fi emr 3 t rfa EqEF{flrffi ryffi 3Trqbr 6r rsrO qt rqrq IeTqn
+irema at sa-fte
drsll t sq fr'dfud *ri fir 3{fr6'K srna tr

2.

3it{ cmfu, *a €tsx i q-ffi 3rfufirrff, tgso fr errcr 3 *' a-ra vqd qrfut

+r r*ar *ri gn, {-ffi trr ronO w fraim 15.03.2000 fir sfrT[qeTr d-€qr 9-26l94-q..3

h qBqq t Fnorqr ?B rir?nd (w$r$), ilan6rilra, r.Tt vtrqr +t rq fuaB -aum+
dT?rrfr Eilfrd fr;qr ant $Ffr 3rfrti'd, ftJEr d?rdrq t dFqr t ryllr-r 3itr q-ffi fir
sdr6 qr Haio. 22.09.2009 fi q*:deqr 13-712008-{.3((') *'ms+lr fi "nor5rcrE +ft
TiFerFr' .Fr ilEr s(trF{ 't+fr frftfrdfca Tfr, @Frfir $k fff,ra rir:?fl;:r" mr Eqrt

3.
*i+ena

3il'{ fsfi 3ftmrT il{fu, g;aufua, ta ftfrraefi,m 78, ffiftf,r Jit{ funrd

i E+ zott rt Rreil dTffiq t dH GA;aafc.l+ gR, @ffir 3ll-{ Brila +i+ena

s*r fawfe -4+rr+ i+ena or rut qrqs de +l sgttr B-qr ?Tr, BHfr uo qfua f*-+r
,rqr ?rT io:mr rtqr s{firt i Eaim, 27.12.2010 * qq zoto *'rrr qerr srfrfr{fr
d'€?Tr 35 *' qrt-qq t r+a :dr?rra mt ta ftffi-ca 7R, ffitBtf,r 3i1-r fufrrfr
EFr

fuEfc.cqrfrq

t arq t rcq Fd falafc-c+rr+ F?rrfud f*.qr tl

4.

sik rqfu, aFqrrfra q-ffi (lrq fuaf+cqrilq drena) Bfrql+, zoto 1a* zoto fr
qqr+iqifufry *. srE*rt :ic?rrfr t sgilq qq TiTrtrq fr ff,{R l+qr erqr rit* zro qr?Tr eEr
ffr Tffi fdft{rflt + fffird uq-trEEBcurrq :ireild +t rl;q AO hqdf{flrilq fr

Tffii t Te d;ndrq t rdnqfr nFrtgl q-r qTqr rfr f+qr erqrt

5.

t kqrqrtffa ?rT, irG[ dT?fla i TtrI 3rEfrqff,
tgso fit qrr 2 (q) t rra ftqEfr{qrffi fr qfr fr gror a1-q qnfril ari a-r qttr
3it{ il{fu, ffir q6 Enrrflr dTrilq

mTt gv Hrrtrrq ildr6nr< rr.rr ;qr.rrrrrr *' $ITqr E{ zotg fr w' fte qrfufir 1fr) +i-Eqr
6583 Erqrr fig ryrdr+ 3irq Fqr{nrrq

i P4aifr 28.10.202s }. 3TTi grllr t are-{fr t

fr

<!-- page 2 -->

ftilr trqr ffi Tdrm {fi ilr6 *' wqr&ra w kqr 6trn, qerff lfi eTrtcr s{dFR fil 3{tr t
il$ ar5 qr arrEru t E), 3itt qC l+'ilq-sr 6t$ +,q-fi EI?n qfud fr unrt

o.

3ik fst' 3Trrr?rT ildft', go anri 6i frfr +.14 ft?Tr+ +t :m6r fdfrm, {rq *' Rq

alsn arqn Efu frr{ ffi{rrr

i qrq fi ffr gw arr& fr or+n Rtft tnT srntnf, d rqr H

+T t, tr$ ftFqufr a,re gv fu Hrrdrq Fq ;qr+tirq
slk T6 Fnffilr grq q?rsfrfi'
"tfr
fi Crtq st 3iFa sq t frr* * t 3it{ grfir srql-aa{d ge derr+ * gfu+,r qt{ fr
gTrdT t $k
fs +tr{ rR mO sfr'ftrd +r"rdl rrq fI 3rrra+ffirT rfr tt

7.

t

3nqbl 3{EfrTfr, 1956 fiT emr 3
sre rsfir', tH s{+rt fuqffflrfrq
3iilrtd q-{f, erRrqt mr rqtrr +.re gv sift fuaBqrrau qera 3Trdfrr fit rsrO w kqrr

ryffi

m-{*', silqq-qr{r r+a *i+arrr fi 3ifff +E d'raRrd

ffit

fi 3cff dfi * srq €l

fffia. 15-03-2000 f,r 3{Tff 3{fuqrdr deqr 9-20/94-q-3 *'} arms dfr t ffi frrsqn
t tff BFffica +ft, ffitrr€r sfu frsra :drera 1x6 fr E,aTr6rqr< gfr draral,
lrzrTaT{T;d,

rrr riqr +t +rq ftear+-<qrr+ dFera dfud fuqr arqr qTt Tsh:tFfr+a, tq

BArmfirq gR, @ftfrr rfu frsm *ir:na t rnl6{ fit qo qd ffi

ilrft ffr A

rah r.*nr 3ifrn dq * ilniffia 6Ht fr ftd fir Gil nt; qrd t rffi 6rjt t
fiffi7s6r11 +i Ti{Fa +t; tq Bfnefi.ff 7fr, dHtrrFr 3fu fd-iila rirefla t ffid
,6 ,n-frar+
fifr+lR-+. q-ilrrr lfelfir+fr spd mtlqr+ff e 3ik HFr 6I d-6rq frffi

$?ffit d +n BAnEf,m Tfr, @ftf,r 3ik f{f,rn t'Fr"r $ E} e}, r+h mt +t
gfFa af't

-g!G-ra=t
qmg tuet{ ilnfr)
q+d gfud, aJT{Fr Tr{frR

ffin:

+91 11 2401 5038

t[G[tlEF-,

eTr{f, TrfdFR

ry,

ffi {tE, aS ftrfr 11ooo2.
ffifrtfr sr-Afta:
sfuE, fowfe _c+rr+ Jqara 3Trfir, il6rg{an6 aq-{ qrJr, r$ frdr-t10002. qtr€r

fr fdfu{d cffi-qr EFr 3rrnnrr 6rA 6(r fuWR {-ffi 3sfrftrrT, tgS0 fir qnr

<!-- page 3 -->

u

2 (q) t rca il;il\r rrr ftqEfu{qmq fiI q-dl fr +n Bptaeffira Efr, @trrfir
3ifr fufrra fuafe -Eqrr+ EFr ;nfr tnBa mtt
2. sTrf,rq fl ry+ttm sftsq, 7ft ar+a, d. {rfi qsrE rts, a$ ffi-t10001.
3. BtQra', 31idft6 1ur+ar gfdftVrd 3ik q;"rrfifr tsrtr"qw'1, wwqfrrfr,
![qTeT{T;i[,

rfl ytrqrt

4. gfrq, :rar qeer +rr.FR, TR Er**, TB Bttnas, Tfr er+a, r{a frra Hr6rdrq
qrat, ilqffr, Jiri[ rtrqr, 226001

5. qqm uEq, rnrrr f,eTqil fteTrq, 5irt seer s{firtt
6. q{ q{frr 6Tqtdq, tngfr ar+a, r$ fr,.-fr -110001
7. q6r€fuE, eTrdrq frEafu-<urr+ du, v.:n$.{. FrrE, 16,6tar Hrrt,;r$ fdafr 1 10002.

g. q-+A frters (qer$T) 3lk tE Tr€t, rr.ftR R'teil EeTra, q1ffi ar+a, r$ frd
+i gm a-{fu t srq fr(rffi{r$(r€ Ffrrg frI -r.*r{ Rrail fteTrrr fil i{srgc q{ {s
sfrTfrdr 6t rffitd 6Ti t fr(' 3Tr+qrfi' frfqr arfr +tt
9. grwr m.r5alufug+ar lnr{frr
lo.Hmdrq fr-rffir dfr t ffi *rfuqr

("dfr {trm)
3ftr{ Trrdq, sTRd €-{S'R

tffffr : +91 11 24014923
