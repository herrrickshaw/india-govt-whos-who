---
doc_id: "ffaf8aeea6909c7a"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/f5688f54e527d148e572198aac01ad7d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '155260' - Cyber Crime Prevention for Women and Children"
date: "2018-04-09"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "add03abdd989c573"
---

<!-- page 1 -->

r lie NO. l b-.5/LU"l .5-A~-111

Government oflndia
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-3/2013-AS-111/349/ C, LIS J

Dated : o.~/04/2018

To,
All Access Service Providers.
Subject:Allocation of shori code to Ministry of Home Affairs, Govt. oflndia regarding.
The undersigned is directed to convey the allocation of Short Code "155260' to Ministry of
Home Affairs, Govt. of India for Cyber Crime Prevention for Women and Children with
teatmes as under:
(i) Category-I: Service i.e. mandatory service to be provided by all the Access providers.
(ii) Accessibility: Un-restricted i.e. available on STD also.
(iii) Metered service: (It may be taken as C alled Pa1ty Pays or Calling Party Pays depending
on intimation, to this effect, issued by the agency to which this short code is allocated in
fi.trtherance to this DoT instruction).

2.

All are requested to take necessaiy action.

3.

This is issued with the approval of DOG (AS- I).

u ar arg
ADG (AS-III)
Tel. No.-011-23372725

Sanchi

Copy furwarded for information and necessa1y action to, if any, to :
I . Secreta1y, TRA T.
2. CM D MTNL /CM D BSNL.
3. Under Secreta1y, CIS-IT Desk, MHA, Govt. oflndia, 192-A, North Block , New Delhi with
reference to your O .M no . 22006/03 /2018-CIS-ll dated 15-03-18 , to appoint a nodal officer
to implement the helpline. The Nodal officer may contact Sr. DOG (LSA), LSA Unit, Delhi.
4 . Director (P&N ), DoT (HQ) (respective LSA Unit may be asked to co-ordinate with
respective Nodal Officers and TSPs for implementation of Helpline, as and when approached).
5. A copy for upload on DoT Website.
