---
doc_id: "fdfe4677aeed39f0"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/44f3417fceed52a1fd63fdefbf903de3.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment in Recruitment Rules for the post of 'Laundry Supervisor' in Ram Manohar Lohia Hospital"
date: "2021-04-01"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e072f27f3ad3e994"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE

PublicNoticeondraftRecruitmentRulesforthepostof"LaundrySupervisor"in
Dr. Ram Manohar Lohia Hospital, New Delhi.

ln compliance with DoPT's OM. No AB-140'17/61/2008-Estt.(RR) dated

"Laundry Supervisor" in Dr' Ram
13.10.15. the draft Recruitment Rules for post of
Manohar Lohia Hospitat, New Delhi is annexed'

The stakeholders, interested in making any ob.iections/commenls or

a period of
suggestions on the draft Recruitment Rules may do so in writing' within
eo-jays tro, the date of publication of draft Recruitment Rules to Section Officer
services' Nirman Bhawan'
1MH-l[, Room No.4osA, Directorate General of Health
e-mail address:
Aizad Road, New Delhi-110108

Maulana

or al

medicalhospital6l @qmail.com.

'Q-* 't-r--"-

(Prem Narain )
Under Secretary to the Govt. of lndia
Tele fax No. 23062032

New Delhi
Dated:

<!-- page 2 -->

125
21 32931 /2021 /MH-ll-DGHS

INDIA, PART II' SECTION 3' SUB'SECTION (OI
[TO BE PUBLISHED tN THE GAZETTE OF
GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
Notiilcalion
New Delhi. lhe

,2021.

and in
G.S.R.....- ln exercise of the powers conferred b) the proliso lo article 109 of lhe Const;tution
la?l
inso
Rules
-roe6e*ion of lhe willinqdon Hospilal and \ursing Home tClas' lll posls) Recruhmenl
to
be
done
a ttt. pJsts of Luunary Supervisdr' except as respects things done or omitted
ii* ir,.t
ofrecruitmenl
"ir,.
t"f*. .rir, .rp""".rion, the president hereby makes the foliowing rules regulating the methodManohar
Lohia
Supervisor in lhe Ministry of Health and Family welfare, Dr' Ram
a iir" p"ri

"r'l-^ra.y
Delhi, namelyi
Hospital, New

L Sho( title and commencement - (l) These rules may be called the Ministry of Health and Family
welfare, Dr. Ram Manohar Lohia Hospital. New Delhi, Laundry Sup€rvisor (Group C Posl), (Amendmenl)
Recruitment Rules. 2021.
(2) They shall come into force on the date oftheir publication in the Oflcial Gazette.
2. Number of post, classifications, level in pay matrix - The number of the said posts, its classification and
level in lhe pay matrix attached thereto shall be as specified in columns (2) to (4) ofthe Schedule annexed to
lhes€ rules.

J. Method ofrecruitmen! age-limil, qualifications. etc. The method ofrecru;tmenl, age-limit, qualificalions
and other matters relating to ihe said posts shall be as specified in columns (5) to (13) ofthe said Schedule.
4. Disqualification. - No person, (a) who has entered inlo or contmcted a marriage with a person having a spouse livinS; or
(b) who. having a spouse liv;ng, has entered into or contracted a marriage with any person,

shallbe eligible for appointment to the said post:
Provided that the Central Covernment may. if satisfied that such marriage is permissible under the
personal law applicable to such person and the other party to the marriage and that there are other grounds for
so doing, exempt any person from lhe operation ofthis rule.

5. Power to rela\. - Where the Central Govemment is ofthe opinion that it is necessary or expedient so lo

do, it may, by order, for reasons to be recorded in writing relax any of the provisions of these rules with
resp€ct to any class or category of persons,
6. Saving.- Nolhing in these rules shall affect reservation, relaxation of age-limit and other concessions
required to be provided for the Scheduled Casles, lhe Scheduled Tribes, the Other Backward Classes, the Exservicemen and other special categories of person in accordance with the orders issued by the Central
Govemment lrom rime ro rime in rhi\ regard.

<!-- page 3 -->

126
21 32931/202',1lMH-ll-DGHS
Schedule

Name ofpost.

Number of posts.

(l)
LaLindry

Supervisor.

Classiflcation.

Level in pay
matrix.

(r)

(4)

(2.)

General Centml

t* (2021)

Whether selection
post or nonselection,
(5)
Non-Selection

Level-5

Service, Croup 'C',

*Subjecl lo variation Non'Gazetted.

dependeni

on

Non-Ministerial.

workload.

Age-limit for direcl recruits.

Educationaland other qualifications required for direct
recruits.

(6)
Between 22-27 years

(7)
A. Passed Higher Secondary Examination (10+2) from
a recognized board/university.

Relaxable for Govemment servanls upto age of forty
years in case ofgeneral candidales and upto the age of
fonl five lears in lhe case ol'candidale' bclongint to

B. Diploma in House Keepingand Laundry Operation.

accordance wilh the instruclions or orders issued by the

C- Two years' experience of Laundry Work from a
Covemment
reputed Commercid Organiz tion
involved in laundry work.

the Scheduled Castes and Scheduled Tribes in

Central Government.

or

Nole l: The crucial date for derermining the a8e-limil
shall be the closing dale for receipt of applications
from candidates and not the closing date prescribed for
those in Assam, Meghalaya. Arunachal Pradesh, Degree from a recognized university/institule and a 6
Mizoram, Man;pur. Nagaland. Iripura, Sikkim, Union months experience
Laundry Work from a
le[itories of Ladakh and Lahaul, Spiti Disrrict and Covemment or reputed Commercial OBanization
Pangi Sub-Division of Chamba District of Himachal involved in laundry work.
Pmdesh, Andaman and Nicobar Islands and Note l: Qualifications are relaxable at the discretion of
Lakshdweep.
lhe competent authority for the reasons to be recorded
Note 2: The crucial date for delermining the age,limit in writing in case of candidates olherwise well
in the case of candidates from employment exchange qualified.
shall be lhe last darc up to lvhich the employmenl Note 2i Qualifications regarding experienc€ are
exchange is asked to submit the names.
relaxable at lhe discretion of the Slaff Selection
Commission for the reasons to be recorded in *ritinp
in rhe case of candidates belonging lo rhe Schedulei
Castes and the Scheduled Tribes, if, at any stage of
selection the StafI Seleclion Commission is of the
opinion thal sulficient number ofcandidates belonging

of

lo lhese communities posse\sing the requisite

experience are not likely to be available to lill up the
vacancies reserved for fiem.

<!-- page 4 -->

't27
21 32931/2021lMH-IFDGHS

b, d'recl recruilmenl

if anY' M.rh.d
"ir*.ttr""l.
d:p"'1lt"lfrhetfre, - ag" una Ei ifliobation,
; t, -htlh;
p'".""i,-"

1,:-biT'::.,1f.
various
"i'ili
;il:#;;";;il;';-ci;s to be nled bY

educational qualifi cations

nrescribed for direct
iecruits will aPPIY in the

methods

Tio years for dirett

Not applicable

@ri*"nd
bY dhecl recruilment
failing bolh

con!r.maion Committee t-ircumstancrsin*hich
Services

tlTo.pann.nrrt
ii--as. of r.cruitment bYor exists.
what ls its comPoslllon'

Union Public

Commission is to be

Dromolion or dePutation
absorplion grade from- which
promotion or deputatron or

consulted in

tepartmentaaffiimtati0'Lommittee

for

making

Not applicable.

confirmalion

Boiler Atte$dant of Dr' Ram

Manohar Lohia HosPilal with
five vears regular service in
level four of PaY mattix with

Medical Supennlendent
irAdditional
'

covemmenl Laundry and

iii !Deoutv Direclor Administralion

lwo years e:.perience in
Knowledge of store accounting'

ii)Head of Department (Laundry)

-Member
_Member

-Member

iv) Deputy Direc$r (MH), Dte GHS

Depulationr

Ofncers of

the

Covemment or
Covemment;

a(i)holding analogous Post on
regLrlar basis or

iirwirh frve Years Iegular

sirvice in the Post in level 4 of
pay matrix.

(b)Possessing the qualifr cation

and experience Prescrib€d tor
direct r;cruits under column 7'

lA. I l0t8/45/2019'MH lll
(Prem Narain)
lndia'
Under Secrctary to the Govemment of
