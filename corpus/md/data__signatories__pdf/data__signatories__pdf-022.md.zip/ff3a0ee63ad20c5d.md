---
doc_id: "ff3a0ee63ad20c5d"
source_url: "https://www.moes.gov.in/static/uploads/2025/07/72a97529f9f3a181f33653bcdb807c34.pdf"
ministry: "Earth Sciences (MoES)"
title: "Corrigendum Dated 11/09/2014"
date: "2014-09-26"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "80b13b01e6f68e9a"
---

<!-- page 1 -->

~./"SR.-~/01

12014-cfu:ft-V

~~

'!~cft~ ~~1~4
"'!~cft~"
6l1{lI>lOill CfillOq~ 'Rl,

mcft m,

~~-110003

~

4 ~,

eFT RifC1¢1 ~

2014

u~rru;:rm '[Q:, ~~,

~

~

if ~

U. ~./"SR.-~/01/2014-cfu:ft-V

if ~

::sicHftst111 olllql{

l"j~1,111 ~

qfC1R111"1 eFT ~\j1I~Ri'll

3th: ~~1'1,
"SR~m eFT~,
60,0001- (5 eFT GfllT'iT urn eFT 1,00,0001-(5 'mT ~I

3. m RifC1¢1 ~it
~

~tTm

fll ~ \jj Ri Cfi 'SlTYllT 'llfu 'Cf{ '@ ~

~~/qftfulsc~
~

~

2014 ~ ~

qfC1R14"1 ~ {@{@Ig ~

l"j~1~4

'Rli 11i

~

eFT ~<Slfll~20 3th: ~~~

~I

( 31 ~iTCfi 'ffTQT)
~~IRiCfi

,!~cfT~

-

--

-----------------------

l"j~1'111, ~~

m

<!-- page 2 -->

MoES/Exh-Fairs/01l2014

PC-V

GOVERNMENT OF INDIA
MINISTRY OF EARTH,SCIENCES
"PRffHVI BHAWAN",
IMD COMPLEX, LODI ROAD,
NEW DELHI - 110 003
~~

r

CORRIGENDUM

In Partial modification of Tender Notice No. MoES/Exh-Fairs/01/2014
PC-V, dated 4th
Sept., 2014 for Designing
and Fabrication
of Ministry's
pavilion, exhibits preparation,
maintenance of pavilion for India International Trade Fair 2014 at Pragati Maidan, New Delhi,
the earnest money deposit amounting to Rs.60,0001- should be read as Rs. 1,00,00012.

All other terms & conditions

of the tender remain unchanged.

3.
AU the corrigendum/addendum
with regards to this tender notice will be published
ONLY on the Ministry website and Central Public Procurement Portal of Government of India.

(Ashok Saha)
Scientist-C,
Ministry of Earth Sciences, New Delhi
