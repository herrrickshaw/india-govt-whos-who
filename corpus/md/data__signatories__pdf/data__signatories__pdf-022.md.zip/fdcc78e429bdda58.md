---
doc_id: "fdcc78e429bdda58"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/09/07b0931993f1312478ec8031a6a64daa.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Irregularities in Appointment of Notary Public"
date: "2023-07-28"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6c5e3ac296099420"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF LAW AND JUSTICE
DEPARTMENT OF LEGAL AFFAIRS
LOK SABHA
UNSTARRED QUESTION NO. 1527
TO BE ANSWERED ON FRIDAY, THE 28.07.2023
IRREGULARITIES IN APPOINTMENT OF NOTARY PUBLIC
1527. SHRI NALIN KUMAR KATEEL:
Will the Minister of LAW AND JUSTICE be pleased to state:
(a)
whether the Government has taken note of the reports regarding irregularities
in the appointment of Notary Public in the country;
(b)

if so, the details thereof;

(c)
whether the Government has taken steps to investigate the said scam to
ensure transparency in the appointment of Notary Public in the country; and
(d)

if so, the details thereof?

ANSWER
MINISTER OF STATE (INDEPENDENT CHARGE) OF THE MINISTRY OF LAW
AND JUSTICE; MINISTER OF STATE IN THE MINISTRY OF PARLIAMENTARY
AFFAIRS; AND MINISTER OF STATE IN THE MINISTRY OF CULTURE
(SHRI ARJUN RAM MEGHWAL)
(a) to (d): Yes, Sir. Complaint has been received regarding alleged irregularities in
the appointment of notary public and the Government having taken note of the same
has accorded approval for conduct of an investigation in the matter, as per law.

*******
