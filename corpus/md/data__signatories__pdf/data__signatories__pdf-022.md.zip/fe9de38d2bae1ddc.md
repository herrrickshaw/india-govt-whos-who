---
doc_id: "fe9de38d2bae1ddc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/0fd484372c1bc143e2a049a26a1548ba.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Note 1 (2022)"
date: "2025-06-02"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7941f73849eb7846"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
FDI Policy Section
Press Note No. 1 (2022 Series)

Subject: Review of FDI Policy for permitting foreign investment in Life
Insurance Corporation of India (LIC) and other modifications for
further clarity of the existing FDI Policy.
The Government of India has reviewed the extant FDI policy for permitting
foreign investment in Life Insurance Corporation of India (LIC) and other modifications
for consistency and further clarity of the existing FDI Policy. Accordingly, the following
amendments have been made under the Consolidated FDI Policy Circular of 2020, as
amended from time to time (FDI Policy):
1.1

Para 2.1.5 of the FDI Policy is amended to be read as under:
'Capital' means equity shares; fully, compulsorily and mandatorily convertible
preference shares; fully, compulsorily and mandatorily convertible debentures
and warrants;
Note: The equity shares issued by an Indian Company in accordance with the
provisions of the Companies Act, 2013 or any other applicable law, shall include
equity shares that have been partly paid. Preference shares and convertible
debentures shall be required to be fully paid, and to be mandatorily and fully
convertible. Further, 'warrant' includes Share Warrant issued by an Indian
Company in accordance with the regulations made by the Securities and
Exchange Board of India (SEBI), the Companies Act, 2013 or any other
applicable law.

1.2

Para 2.1.9 of the FDI Policy is amended to be read as under:
'Convertible Note' means an instrument issued by a startup company
acknowledging receipt of money initially as debt, which is repayable at the
option of the holder, or which is convertible into such number of equity shares
of such startup company, within a period not exceeding ten years from the date
of issue of the convertible note, upon occurrence of specified events as per the
other terms and conditions agreed to and indicated in the instrument.

Page 1 of 8

<!-- page 2 -->

1.3

Para 2.1.17 of FOi Policy is amended to be read as under:
'Foreign Investment' means any investment made by a person resident
outside India on a repatriable basis in capital instruments of an Indian company
or to the capital of a LLP;
Explanation: If a declaration is made by a person as per the provisions of the
Companies Act, 2013 or any other applicable law, about a beneficial interest
being held by a person resident outside India, then even though the investment
may be made by a resident Indian citizen, the same shall be counted as foreign
investment;
Note: A person resident outside India may hold foreign investment either as
FDI or as FPI in any particular Indian company;

1.4

Para 2.1.27 of FDI Policy is amended to be read as under:
'Indian Company' means a company as defined in the Companies Act, 2013
which is incorporated in India, or a body corporate established or constituted
by or under any Central or State Act;
Note:
1.

2.

3.

1.5

It is clarified that reference to 'company' or 'investee company' or
'transferee company' or 'transferor company' in the FDI Policy also
includes a reference to a body corporate established or constituted by or
under any Central or State Act.
It is further clarified that if the term 'Company' or 'Indian company' or
'Investee Company' is qualified by reference to a company incorporated
under the Companies Act, such term shall mean a company incorporated
under the Companies Act but not a body corporate.
It is also clarified that 'Indian Company' does not include a society, trust
or any entity, which is excluded as an eligible investee entity under the
FDI Policy.

A new Para 2.1.47A is inserted under the FDI Policy as follows:
'Share Based Employee Benefits' means any issue of capital instruments to
employees, pursuant to share based employee benefits schemes formulated
by a body corporate established or constituted by or under any Central or State
Act.

1.6

A new Para 2.1.48A is inserted under the FDI Policy as follows:
'Subsidiary' shall have the same meaning as is assigned to it under the
Companies Act, 2013, as amended from time to time.

Page 2 of 8

<!-- page 3 -->

1.7

The existing provisions under Para 3.4.2 (vi) and Para 3.4.2 (vii) of the FDI
Policy are re-numbered as new Para 3.4.3 and new Para 3.4.4.

1.8

The existing definitions of 'Real Estate Business' under Para 5.1 (f) and Note
(i) to Para 5.2.10.2 of the FDI Policy, are amended and aligned in the following
manner:
Para 5.1 (f) of the FDI Policy is amended to be read as under:

(i)

Real Estate Business or Construction of Farm Houses
'Real estate business' means dealing in land and immovable property
with a view to earning profit there from and does not include
development of townships, construction of residential/commercial
premises, roads or bridges, educational institutions, recreational
facilities, city and regional level infrastructure, townships and Real
Estate Investment Trusts (REITs) registered and regulated under the
SEBI (REITs) Regulations 2014. Further, earning of rent/income on
lease of the property, not amounting to transfer, will not amount to real
estate business.
(ii)

Note (i) to Para 5.2.10.2 of the FDI Policy is amended to be read as
under:
It is clarified that FDI is not permitted in an entity which is engaged or
proposes to engage in real estate business, construction of farm houses
and trading in transferable development rights (TDRs).
"Real estate business" means dealing in land and immovable property
with a view to earning profit there from and does not include
development of townships, construction of residential/commercial
premises, roads or bridges, educational institutions, recreational
facilities, city and regional level infrastructure, townships and Real
Estate Investment Trusts (REITs) registered and regulated under the
SEBI (REITs) Regulations 2014. Further, earning of rent/income on
lease of the property, not amounting to transfer, will not amount to real
estate business.

1.9

A new Para 5.2.22.1A is inserted under Para 5.2.22.1 of the FDI Policy as
follows:
Sector/Activity

% of Equity/ FDI
cap

Entry Route

5.2.22.1A
Life
Insurance
Corporation of India

20%

Automatic

Page 3 of 8

<!-- page 4 -->

1.10

Para 5.2.22.3 of the FDI Policy on "Other Conditions", is to be bifurcated in two
parts through insertions of new Paras 5.2.22.3.1 and 5.2.22.3.2 applicable on
Indian insurance companies/intermediaries or insurance intermediaries and
UC, respectively. The existing clauses (a) to (j) and amended clause (k) under
Para 5.2.22.3 are placed under Para 5.2.22.3.1 titled 'Other conditions
applicable to Indian insurance companies and intermediaries or insurance
intermediaries' and new clauses (a) to (c) are placed under Para 5.2.22.3.2
titled 'Other conditions applicable to the Life Insurance Corporation of India
(LIC)'. Accordingly, Para 5.2.22.3 of the FDI Policy is amended to be read as
under:
5.2.22.3

Other Conditions

5.2.22.3.1

Other conditions applicable to Indian insurance companies
and intermediaries or insurance intermediaries:

(a)

No Indian Insurance company shall allow the aggregate holdings by way
of total foreign investment in its equity shares by foreign investors,
including portfolio investors, to exceed seventy-four percent of the paid­
up equity capital of such Indian Insurance company.

(b)

The foreign investment up to seventy-four percent of the total paid-up
equity of the Indian Insurance Company shall be allowed on the
automatic route subject to approval/verification by the Insurance
Regulatory and Development Authority of India.

(c)

Foreign investment in this sector shall be subject to compliance with the
provisions of the Insurance Act, 1938 and the condition that Companies
receiving FDI shall obtain necessary license/approval from the
Insurance Regulatory and Development Authority of India for
undertaking insurance and related activities.

(d)

(I)

In an Indian Insurance Company having foreign investment,1.
ii.
iii.

a majority of its directors;
a majority of its Key Management Persons; and
at least one among the Chairperson of its Board, its
Managing Director and its Chief Executive Officer

shall be Resident Indian Citizens.
Explanation: For the above purposes, the expression - "Key
Management Person" shall have the same meaning as assigned
to it in guidelines made by the Insurance Regulatory and
Development Authority of India on corporate governance for
insurers in India.
(II)

An Indian Insurance company having foreign investment shall
comply with the provisions under the Indian Insurance
Companies (Foreign Investment) Rules, 2015, as amended from
time to time and applicable rules/regulations notified by the
Page 4 of 8

<!-- page 5 -->

Department of Financial Services/Insurance Regulatory and
Development Authority of India from time to time.
(e)

Foreign portfolio investment in an Indian Insurance company shall be
governed by the provisions contained in Chapter-IV, Rule 10 and 11 read
with Schedule II of Foreign Exchange Management (Non-Debt
Instruments) Rules, 2019, as amended from time to time and provisions
of the Securities and Exchange Board of India (Foreign Portfolio
Investors) Regulations, 2019, as amended from time to time.

(f)

Any increase in foreign investment in an Indian Insurance company shall
be in accordance with the pricing guidelines specified by Reserve Bank
of India under the FEMA Regulations.

(g)

The foreign equity investment cap of 100 percent shall apply on the same
terms as above to insurance brokers, re-insurance brokers, insurance
consultants, corporate agents, third party administrator, Surveyors and
Loss Assessors and such other entities, as may be notified by the
Insurance Regulatory and Development Authority of India from time to
time. The composition of the Board of Directors and key management
persons of Intermediaries or Insurance Intermediaries shall be as
specified by the concerned regulator from time to time.

(h)

The foreign direct investment proposals shall be allowed under the
automatic route subject to verification by the Authority and the foreign
investment in intermediaries or insurance intermediaries shall be
governed by the same terms as provided under rules 7 and 8 of the
Indian Insurance Companies (Foreign Investment) Rules, 2015, as
amended from time to time:
Provided that where an entity like a bank, whose primary business is
outside the insurance area, is allowed by the Insurance Regulatory and
Development Authority of India to function as an insurance intermediary,
the foreign equity investment caps applicable in that sector shall continue
to apply, subject to the condition that the revenues of such entities from
their primary (i.e., non-insurance related) business must remain above
50 percent of their total revenues in any financial year.

(i)

The insurance intermediary that has majority shareholding of foreign
investors shall undertake the following:
1.
11.

111.

be incorporated as a limited company under the provisions of the
Companies Act, 2013;
at least one from among the Chairman of the Board of Directors
or the Chief Executive Officer or Principal Officer or Managing
Director of the insurance intermediary shall be a resident Indian
citizen;
shall take prior permission of the Authority for repatriating
dividend;
Page 5 of 8

<!-- page 6 -->

iv.
v.

vi.

vii.

shall bring in the latest technological, managerial and other skills;
shall not make payments to the foreign group or promoter or
subsidiary or interconnected or associate entities beyond what is
necessary or permitted by the Authority;
shall make disclosures in the formats to be specified by the
Authority of all payments made to its group or promoter or
subsidiary or interconnected or associate entities;
composition of the Board of Directors and key management
persons shall be as specified by the concerned regulators;

(j )

The provisions of paragraphs (i) (b) and (d) of Annexure 8 relating to
'Banking-Private Sector', shall be applicable in respect of bank promoted
insurance companies.

(k)

Terms 'Equity Share Capital', 'Foreign Direct Investment' (FOi), 'Foreign
Investors', 'Foreign Portfolio Investment', 'Indian Insurance Company',
'Indian Company', 'Non-resident Entity', 'Public Financial Institution',
'Resident Indian Citizen', 'Total Foreign Investment' will have the same
meaning as provided in the rules notified by the Department of Financial
Services under the Insurance Act, 1938 or in the regulations issued by
Insurance Regulatory and Development Authority of India from time to
time, in respect of foreign investment in Indian Insurance Companies
and intermediaries or insurance intermediaries.

5.2.22.3.2

Other conditions applicable to the Life.
Corporation of India (LIC) shall be as follows:

Insurance

(a) Foreign investment in LIC shall be subj ect to compliance with the
provisions of the Life Insurance Corporation Act, 1956, as amended from
time to time (LIC Act) and such provisions of the Insurance Act, 1938, as
amended from time to time, as are applicable to LIC as per the provisions
of Section 43 of the LIC Act.
(b) Clauses (e) and (f) of Paragraph 5.2.22.3.1 above, shall also apply to LIC
as if reference therein to an Indian Insurance Company is a reference to
LIC.
(c) The terms referred to in clause (k) of Paragraph 5.2.22.3.1 above, shall
have the meaning as referred to therein.
Explanation: For the purposes of Paragraph 5.2.22.3.2 any reference to Indian
insurance company or company in the meaning provided to any term (referred
to in clause (k) of Paragraph 5.2.22.3.1) in the rules or regulations referred to
therein, shall be construed as a reference to LIC.

Page 6 of 8

<!-- page 7 -->

1.11

Para 4 of Annexure 3 of the FDI Policy is amended to be read as under:
Where a scheme of compromise or arrangement or merger or amalgamation of
two or more Indian companies, or a reconstruction by way of demerger or
otherwise of an Indian company, or transfer of undertaking of one or more
Indian company to another Indian company, or involving division of one or more
Indian company, has been approved by the National Company Law Tribunal or
other authority competent to do so by law, the transferee company or the new
company, as the case may be, may issue capital instruments to the existing
shareholders of the transferor company resident outside India, subject to the
following conditions:
(i) the percentage of shareholding of persons resident outside India in the
transferee or new company does not exceed the sectoral cap; and
(ii) the transferor company or the transferee or the new company is not
engaged in activities which are prohibited under the FDI Policy.
Note: Government approval shall not be required in case of mergers and
acquisitions taking place in sectors under automatic route.

1.12

Para 5 of Annexure 3 of the FDI Policy is amended to be read as under:
Issue of Employees Stock Option (ESOP) scheme I sweat equity shares/
Share Based Employee Benefits
An Indian company may issue 'employees' stock option', and/or 'sweat equity
shares' and/or Share Based Employee Benefits to its employees/ or directors
or to the employees/ or directors of its holding company or joint venture or
wholly owned overseas subsidiary/subsidiaries who are resident outside India,
provided that: (a)

(b)

(c)

(d)

the scheme has been drawn either in terms of regulations made under the
Securities Exchange Board of India Act, 1992 or the Companies (Share
Capital and Debentures) Rules, 2014 notified by the Central Government
under the Companies Act, 2013 or as per any other applicable law, as the
case may be;
the 'employee's stock option' or 'sweat equity shares' or Share Based
Employee Benefits issued to non-resident employees/ or directors under
the applicable rules/ or regulations or other law are in compliance with the
sectoral cap applicable to such company;
issue of 'employee's stock option'/ or 'sweat equity shares' or Share Based
Employee Benefits by a company where foreign investment is under the
approval route shall require prior approval of the Government of India;
issue of 'employee's stock option'/ or 'sweat equity shares' or Share Based
Employee Benefits under the applicable rules/ or regulations or other law
to an employee/ or director who is a citizen of Bangladesh/ or Pakistan
shall require prior approval of the Government of India;
Page 7 of 8

<!-- page 8 -->

(e)

the Indian company shall file with the Foreign Exchange Department of
the Reserve Bank of India, within 30 days of the issue of ESOPs or sweat
equity shares or shares issued on exercise of ESOPs, a return in the form­
"ESOP Reporting".

Note: The form "ESOP Reporting" shall mean the form so named and specified
by the Reserve Bank of India for reporting either the statement of shares
allotted to Indian employees/ directors under ESOP schemes or the statement
of shares repurchased by the issuing foreign company from Indian employees
/ directors under ESOP schemes, as the case may be.

1.13

2.

Clause (e) of Para 1.2(v) of Annexure 4 of the FOi Policy is amended to be
read as under:

If a declaration is made by a person under the provisions of section 187C of the
Companies Act, 1956 or section 89 of the Companies Act, 2013 or any other
applicable law, as the case may be, about a beneficial interest being held by a
non-resident entity, then even though the investment may be made by a
resident Indian citizen, the same shall be counted as Foreign Investment.
The above decision will take effect from the date of FEMA notification.

5
-yV
Joint Secretary t��:

DPIIT File No. 5(3)/2021-FDI Policy dated 14.03.2022
Copy forwarded to:

1. Press Information Officer, Press Information Bureau- for giving wide
publicity to the above Press Note.
2. Joint Secretary(l&C), Department of Economic For suitably incorporating the
policy changes in Foreign
Affairs, North Block, New Delhi
Exchange Management (Non
3. Reserve Bank of India, Foreign Exchange Debt Instruments) Rules,
2019, the relevant schedules
Department, Mumbai
thereof and FIRMS portal.
4. NIC Section in the Department for Promotion of
Industry and Internal Trade - for uploading the Press
Note on DPIIT's website.
5. Hindi Section, DPIIT- for providing Hindi version.

Page 8 of 8
