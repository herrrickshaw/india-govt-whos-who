---
doc_id: "ff2ab56c0bb1f53f"
source_url: "https://mohua.gov.in/static/uploads/2025/12/459d95124be0975ae26ace837ca09d2a.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Drainage and Sewerage"
date: "2016-11-14"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "db82909903aa881d"
---

<!-- page 1 -->

Chapter XXIII
Drainage and Sewerage
A. Functions in Relation to Drainage and Sewerage
Municipality
to provide
drainage,
sewerage
and outfall.

194. The Municipality shall, either on its own or through any other agency, construct
and maintain drains and sewers, and provide a safe and sufficient outfall, in
or outside the municipal area, for effectual drainage and proper discharge of
storm-water and sewage of the municipal area in such manner as may not
cause any nuisance, whether by flooding any part of the municipal area, or
of the areas surrounding the outfall, or in any other way :
Provided that no place, which has not been used before the
commencement of this Act for any of the purposes specified in this section,
shall be so used except (i) in conformity with the provisions of any State law relating to land
use planning or any other law relating thereto for the time being in
force, or
(ii) with the approval of the State Government, in the absence of any
such law :
Provided further that with effect from such date as may be appointed
by the State Government in this behalf, no sewage shall be discharged into
any watercourse until it has been so treated as not to affect prejudicially the
purity and the quality of the water of such water course.

Provision of
means for
disposal of
sewage.

195. For the purposes of receiving, treating, storing, disinfecting, distributing, or
otherwise disposing of sewage, the Municipality may, either on its own or
through any other agency, construct, operate, maintain, develop and manage
any works within or outside the municipal area.
B. Proprietary Rights of Municipality
in Respect of Drains and Sewage Disposal Works

113

<!-- page 2 -->

Vesting of
196. Subject to the provisions of chapter XXI, public drains
and sewage
(a) all public drains, all drains in, alongside or under any public street,
disposal works.

and all sewage disposal works, constructed or acquired out of the
Municipal Fund or otherwise, and all works, materials and things
appertaining thereto, which are situated within or outside the
municipal area, shall vest in the Municipality,
(b) for the purposes of laying, constructing, enlarging, deepening
or otherwise repairing or maintaining any such drain or sewage
disposal system, so much of the sub-soil appertaining thereto,
as may be necessary for such purposes, shall be deemed also
to vest in the Municipality, and
(c) all drains and ventilation shafts, pipes and all appliances and
fittings connected with the drainage works constructed, erected
or set up out of the Municipal Fund in or upon premises, not
belonging to the Municipality, whether (i) before or after the commencement of this Act, and
(ii) for the use of the owner or the occupier of such
premises or not,
shall, unless the Municipality has otherwise determined, or does at any time
otherwise determine, vest, and shall be deemed always to have vested, in
the Municipality.
Explanation. - All public and other drains, which vest in the Municipality,

are hereinafter referred to in this Act as municipal drains.
Power to make 197. The Municipality may, with the prior approval of the State Government
over to, or to
and subject to such conditions as the Municipality may determine, make
take over from,
statutory
over to, or take over from, an authority under any law for the time
authority
being in force any drain or sewer or sewage disposal works for
drainage and
sewerage
administration and management thereof.
works.
C. Municipal Drains
Power of
198. (1) The Chief Municipal Officer, or any other agency authorized by
making drains.

him in this behalf, may carry any municipal drain through, across,
114

<!-- page 3 -->

or under, any street, or any place laid out as, or intended for, a street or
under any cellar or vault, which may be under any street, and, after
giving a reasonable notice in writing to the owner or the occupier thereof,
into, through or under any land whatsoever within the municipal area,
or, for the purpose of out-fall or distribution of sewage, outside the
municipal area.
(2) The Chief Municipal Officer, or any other agency authorized by
him in this behalf, may construct any new drain in place of an
existing drain or repair or alter any municipal drain so constructed.
Sewage and
rain water
drains to be
separate.

199. For the purpose of effectual drainage of any premises in accordance
with the provisions of this chapter, it shall be competent for the Chief
Municipal Officer, or any other agency authorized by him in this behalf,
to require that there shall be one drain for sewage, offensive matter and
polluted water and an entirely separate drain for rain water or unpolluted
sub-soil water or both rain water and unpolluted sub-soil water, each
emptying into separate municipal drains or other suitable places.

Alteration,
200. Subject to such terms and conditions as may be specified by regulations
discontinuance,
from time to time, the Chief Municipal Officer, or any other agency
cleansing, etc.,
of drains.
authorized by him in this behalf, may -

(a) enlarge, alter the course of, lessen, or arch over, or otherwise
improve, any municipal drain within the municipal area,
(b) discontinue, close up, or destroy any such drain,
(c) properly flush, clean, and empty such drain, and
(d) restrict throwing, emptying, or turning into any municipal
drain, or into any drain communicating into the municipal
drain, any matter likely to damage the drain or interfere with
the free flow of its contents or affect prejudicially the treatment
and disposal of its contents, or any chemicals, refuse or waste
steam, or any liquid which is dangerous or is the cause of a
nuisance or is prejudicial to health, or any petroleum Class
‘A’, petroleum Class ‘B’ or petroleum Class ‘C’.
Explanation. - For the purposes of this section, the expression “petroleum
115

<!-- page 4 -->

Class ‘A’, petroleum Class ‘B’ or petroleum Class ‘C’” shall have the same 30 of
meaning as in the Petroleum Act, 1934.
D. Drains of Private Streets and Drainage of Premises
Powers in
relation to
drainage.

201. Subject to such terms and conditions as may be specified by regulations
from time to time, the Chief Municipal Officer, or any other agency
authorized by him in this behalf, may (a) permit the owner or the occupier of any premises having a
drain, or the owner of a private drain, to have his drain made
to communicate with the municipal drain for discharge of foul
water,
(b) limit the use of the municipal drain by the owner or the occupier
of any premises having a private drain or the owner of a private
drain,
(c) require the owner of any land or building, which is without
sufficient means of effectual drainage, to construct a drain
and to provide all such appliances and fittings as may be
necessary for drainage of such undrained land or building,
(d) require the group of owners of a block of premises, which may be
drained more economically or advantageously in combination than
separately, to undertake at their own expense any work necessary
for drainage of such block of premises to be drained by a combined
operation,
(e) require the owner of any land or building to carry out such
construction, repair or other work as may be necessary for
effectual drainage of such land or building, or
(f) authorize any person, who desires to drain his land or building
into a municipal drain through a drain of which he is not an
owner, to use the drain or declare such person to be the joint
owner thereof.

116

1934.

<!-- page 5 -->

Premises not 202.
to be erected
without drains.

(1) It shall not be lawful to erect or re-erect any premises in the municipal
area or to occupy any such premises unless (a) a drain is constructed of such size, materials and
description, at such level, and with such fall, as may appear
to the Chief Municipal Officer to be necessary for the
effectual drainage of such premises,
(b) there have been provided and set up on such premises
such appliances and fittings as may appear to the Chief
Municipal Officer to be necessary for the purposes of
gathering or receiving the filth and other polluted and
obnoxious matters, and conveying the same, from such
premises and of effectually flushing the drain of such
premises and every fixture connected therewith.
(2) The drain so constructed shall empty into a municipal drain situated
at a distance of not exceeding thirty metres from the premises, but
if no municipal drain is situated within such distance, then, such
drain shall empty into a cesspool situated within the distance to be
specified by the Chief Municipal Officer for the purpose.
E. Trade Effluent

Special
203. Subject to the provisions of this Act and the regulations made thereunder
provisions
and of any other law for the time being in force, the occupier of any
relating to
trade effluent.

trade premises may, with the approval of the Municipality or, so far as
may be permitted by this Act or the regulations made thereunder or any

other law for the time being in force, without such approval, discharge
into the municipal drain any trade effluent proceeding from such
premises.
Special
204. Notwithstanding anything contained in this Act or the regulations made
provisions
thereunder or any usage, custom or agreement, where, in the opinion of
regarding
drainage of
the Chief Municipal Officer, any trade premises are without sufficient
trade effluent.

means of effectual drainage and treatment of trade effluent or the drains
117

<!-- page 6 -->

thereof, though otherwise not objectionable, are not adapted to the general
drainage system of the municipal area, or the effluent is not of specified
purity, the Chief Municipal Officer may, by notice, in writing, require the
owner or the occupier of such premises (a) to discharge the trade effluent in such manner, at such times,
through such drains, and subject to such conditions, as may
be specified in the notice, and to cease to discharge the trade
effluent otherwise than in accordance with the notice,
(b) to purify the trade effluent before its discharge into a municipal
drain and to set up for purifying the trade effluent such
appliances, apparatus, fittings and plants, as may be specified
in the notice,
(c) to construct a drain of such material, size and description, and
laid at such level, and according to such alignment, and with
such fall and outlet, as may be specified in the notice,
(d) to alter, amend, repair or renovate any purification plant,
existing drain, apparatus, plant-fitting or article used in
connection with any municipal or house-drain.

118
