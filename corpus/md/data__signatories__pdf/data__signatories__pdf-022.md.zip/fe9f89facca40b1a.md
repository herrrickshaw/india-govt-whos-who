---
doc_id: "fe9f89facca40b1a"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/315607542899dc39ec95d35951fc52cf.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of UL(ISP) Category 'C' license no. DS-11/220/2018-DS-III dated 20.05.2019 for Dhanbad SSA in Bihar Service Area of M/s Aamak Network Pvt Ltd"
date: "2023-10-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d5bbe57391e81c61"
---

<!-- page 1 -->

DS-11/220/2018-DS-III(Vol.III)
I/3133605/2023

WITHOUT PREJUDICE
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20-Ashoka Road, New Delhi-110001
(DS Cell)
No. DS-11/220/2018-DS-III (Vol.III)

Dated:18-10-2023

To,
M/s Aamak Network Pvt Ltd.
No. D-84, Central Market Bokaro Thermal,
DVC Bokaro, Jharkhand - 829 107
CIN- U01110JH2017PTC010504
Email: - mdkhalidhussain777@gmail.com & aamakinetwork@gmail.com
Sub: - Termination/Revocation/Cancellation of UL(ISP) Category 'C' license
no. DS-11/220/2018-DS-III dated 20.05.2019 for Dhanbad SSA in Bihar Service
Area of M/s Aamak Network Pvt Ltd, under condition of clause 10.2 (i) (Part-I)
of the License Agreement.
In respect of no reply received from you to the Show Cause Notice issued
dated 25.06.2023, it is noted that you have not complied with the ﬁnancial
conditions of the License as stated in the said show cause notice and it is
understood that you have nothing to say about the said show cause notice.
2. As such, the competent Authority has decided to treat the DOT letter No. DS11/220/2018-DS-III Dated 27-09-2023 regarding the acceptance of surrender of
ca t e g o r y UL(ISP) Category 'C' license no. DS-11/220/2018-DS-III
dated 20.05.2019 for Dhanbad SSA in Bihar Service Area of M/s Aamak
Network Pvt Ltd, as letter for termination
3. This is under condition of clause 10.2 (i) (Part-I) of the License Agreement.
Accordingly, the said license is terminated/revoked/cancelled vide DOT letter No.
DS-11/220/2018-DS-III Dated 27-09-2023. You are directed to terminate and stop
all interconnections with all service providers w.e.f. the said date of termination of
this License / Authorization as stated in said DOT letter No. DS-11/220/2018-DS-III
Dated 27-09-2023.
4. It may be noted that if any other violation of license conditions is reported against
you then necessary action i.r.o said violation may be initiated in due course of time.
The Bank Guarantee(s) submitted against the said license will be released under
clause 11.2 (Part-I) of Uniﬁed License after ensuring clearance of dues including
dues/penalty arising, if any, as a consequence of the aforesaid violation.
5. As far as the dues of DS division are concerned the same shall be intimated in

<!-- page 2 -->

DS-11/220/2018-DS-III(Vol.III)
I/3133605/2023

due course of time to O/o CGCA. Further, DG(T), WPC, Concerned CCA, WPF
divisions are requested to ascertain their dues and issue "No Dues Certiﬁcate" /
details of dues to O/O CGCA expeditiously.
6. Kindly acknowledge the receipt.

(R. K Meena)
Director (DS-II)
Email: dirds2-dot@nic.in
Copy to: -

1. DG Telecom, DOT (HQ), With a request to instruct the concerned LSA /
LSAs to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any "telecom resources” to/from the M/s
Aamak Network Pvt Ltd and for issue of Dues/No Dues Certificate till the
effective date of termination of License and convey to office of CGCA
2. Sr. DDG Bihar LSA for necessary action for disconnection of all
interconnections with other TSPs/ISPs as per above
3. Sr. Joint CGCA(Revenue), Oﬃce of CGCA (With a request to Release
the Bank Guarantees of the aforesaid company after ensuring dues
from respective sections of DOT as per letter no. vide letter No.190/2012/LF-1(Pt.1) dated 05.09.2018 and letter No.1-8/2017/LFP-1 dated
17.04.2017)
4. Secretary, (TRAI)
5. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective
date of termination of License and convey to office of CGCA
6. DDG(LFP).
7. Dy. CCA, O/o CCA, Jharkhand
8. Director (DS-III),
9. DOT website for all Licensees to discontinue all telecom resources as
per above.
10. F.No. DS-11/220/2018-DS-III (Vol.III)
