---
doc_id: "fec3cb2d5cb80a73"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/03b8c4703c262cbf5aaf6577c15ea75c.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "RBI - Circular No. 44 RBI/2007-2008/342 - A.P. (DIR Series) dated: 30th May, 2008 in regard to reporting under FDI scheme"
date: "2025-07-15"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7a67d63bee88bfaf"
---

<!-- page 1 -->

RBI/2007-2008/342
A. P. (DIR Series) Circular No. 44
May 30, 2008
To
All Category - I Authorised Dealer Banks
Madam / Sir,
Reporting under FDI Scheme - Revised procedure
Attention of Authorised Dealer Category - I (AD Category - I) banks is invited to provisions of the Foreign
Exchange Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations,
2000, notified vide Notification No. FEMA 20/2000-RB dated May 3, 2000, as amended from time to time and
A. P. (DIR Series) Circular No.40 dated April 20, 2007.
2. In terms of para 9 (1) A of Schedule I to the Notification, Indian companies are required to report the details
of the amount of consideration received for issuing shares and convertible debentures under the Foreign
Direct Investment (FDI) scheme to the Regional Office of the Reserve Bank in whose jurisdiction the
Registered Office of the company operates, within 30 days of receipt of the amount of consideration. Further,
in terms of Para 9 (1) B of Schedule ibid, the companies are required to report the details of the issue of
shares / convertible debentures in form FC-GPR, to the Regional Office concerned, within 30 days of issue of
shares / convertible debentures.
3. In order to capture the details of FDI in a more comprehensive manner, form FC-GPR was revised vide A.
P. (DIR Series) Circular No.40 dated April 20, 2007. The reporting framework was again reviewed and further
revisions were proposed and the revised draft of form FC-GPR was placed in public domain on March 14,
2008 inviting feedback from the public. Based on the feedback received, form FC-GPR has been revised. The
revised form is enclosed at Annex I. Further, a standard format for reporting of the receipt of the amount of
consideration for issue of shares / convertible debentures has been prescribed as Annex II. A format for the
KYC report on the non-resident investor from the overseas bank remitting the amount required to be
submitted along with the form FC-GPR has also been introduced (Annex III). The KYC report should,
henceforth, be submitted at the time of reporting the receipt of the amount of consideration from the nonresident investor.
4. Accordingly, Indian companies are required to report the details of the receipt of the amount of
consideration for issue of shares / convertible debentures in Annex II, together with a copy/ies of the FIRC/s
evidencing the receipt of the remittance along with the KYC report on the non-resident investor in Annex III,
through an AD Category – I bank, not later than 30 days from the date of receipt of the amount of

<!-- page 2 -->

consideration. The report would be acknowledged by the Regional Office concerned, which would allot a
Unique Identification Number (UIN) for the amount reported.
5. The details of the issue of shares / convertible debentures should, henceforth, be reported in the revised
form FC-GPR (Annex I). While forwarding form FC-GPR to the Regional Office concerned, the AD Category –
I bank should ensure that the UIN is correctly indicated in the form. It is also clarified that the annual report of
all investments which is to be filed in Part B of the revised form FC-GPR, which is hitherto to be submitted by
June 30 every year, would now have to be submitted by July 31 every year.
6. Necessary amendments to the Foreign Exchange Management (Transfer or Issue of Security by a Person
Resident outside India) Regulations, 2000 notified vide Notification No. FEMA 20/2000-RB dated May 3, 2000
will be issued separately.
7. AD Category - I banks may bring the contents of this circular to the notice of their constituents and
customers concerned.
8. The directions contained in this circular have been issued under sections 10(4) and 11(1) of the Foreign
Exchange Management Act, 1999 (42 of 1999) and is without prejudice to permissions / approvals, if any,
required under any other law.
Yours faithfully,
(Salim Gangadharan)
Chief General Manager -in- Charge

<!-- page 3 -->

Annex I
[Annex to A. P. (DIR Series) Circular No. 44 dated May 30, 2008]
FC-GPR
PART - A
(To be filed by the company through its Authorised Dealer Category – I bank with the Regional
Office of the RBI under whose jurisdiction the Registered Office of the company making the
declaration is situated as and when shares / convertible debentures are issued to the foreign
investor, along with the documents mentioned in item No. 4 of the undertaking enclosed to this
form)

Permanent Account Number
(PAN) of the investee company
given by the Income Tax
Department
Date of issue of shares /
convertible debentures

No.
1.

Particulars

(In Block Letters)

Name

Address of the Registered Office

State
Registration No. given by Registrar
of Companies
Whether existing company or new
company (strike off whichever is not
applicable)
If existing company, give
registration number allotted by RBI
for FDI, if any
Telephone
Fax
e-mail

Existing company / New company

<!-- page 4 -->

2. Description of the main business
activity

3

NIC Code
Location of the project and NIC
code for the district where the
project is located
Percentage of FDI allowed as per
FDI policy
Automatic Route / Approval Route
State whether FDI is allowed under
Automatic Route or Approval Route
(strike out whichever is not
applicable)
Details of the foreign investor / collaborator∗
Name
Address

Country

Constitution / Nature of the
investing Entity
[Specify whether
1.
2.
3.
4.
5.
6.
7.
8.
9.

Individual
Company
FII
FVCI
Foreign Trust
Private Equity Fund
Pension / Provident Fund
Sovereign Wealth Fund (SWF)†
Partnership / Proprietorship
Firm
10. Financial Institution
11. NRIs / PIO
12. Others (please specify)]

Date of incorporation
∗

If there is more than one foreign investor/collaborator, separate Annex may be included for items 3 and 4 of
the Form.
†

SWF means a Government investment vehicle which is funded by foreign exchange assets, and which manages those
assets separately from the official reserves of the monetary authorities.

<!-- page 5 -->

4
(a)

Particulars of Shares / Convertible Debentures Issued
Nature and date of issue
Nature of issue
01
02
03
04
05
06
07
08
09
10

(b)

Date of issue

IPO / FPO
Preferential allotment /
private placement
Rights
Bonus
Conversion of ECB
Conversion of royalty
(including lump sum
payments)
Conversion against import

of capital goods by units in
SEZ

ESOPs
Share Swap
Others (please specify)
Total
Type of security issued
No.

Nature of
security

01
02

Equity
Compulsorily
Convertible
Debentures
Compulsorily
Convertible
Preference
shares
Others
(please
specify)
Total

03

04

Number of shares/
convertible debentures

Number

Maturity

Face
value

Premium

Issue
Price per
share

Amount
of inflow*

i) In case the issue price is greater than the face value please give break up of the premium
received.
ii) * In case the issue is against conversion of ECB or royalty or against import of capital goods by
units in SEZ, a Chartered Accountant's Certificate certifying the amount outstanding on the date of
conversion

(c)

@

Break up of premium
Control Premium
Non competition fee
Others@
Total

please specify the nature

Amount

<!-- page 6 -->

(d)

Total inflow (in Rupees) on account of
issue of shares / convertible debentures to
non-residents (including premium, if any)
vide
(i) Remittance through AD:
(ii) Debit to NRE/FCNR A/c with
Bank_________
(iii) Others (please specify)

a)

Non-Resident
01
Individuals
02
Companies
03
FIIs
04
FVCIs
05
Foreign Trusts
06
Private Equity Funds
07
Pension/ Provident Funds
08
Sovereign Wealth Funds
09
Partnership/ Proprietorship
Firms
10
Financial Institutions
11
NRIs/PIO
12
Others (please specify)
Sub Total
b) Resident
Total

%

No.
of
shares

Investor category

Compulsorily
convertible
Preference
Shares/
Debentures
Amount
(Face
Value) Rs.

Equity

No.
of
shares

5. Post issue pattern of shareholding

*(Please indicate as applicable)

%

** before issue of shares

Amount
(Face
Value) Rs.

(e)

Date of reporting of (i) and (ii) above to RBI
under Para 9 (1) A of Notification No. FEMA
20/2000-RB dated May 3, 2000, as
amended from time to time.
Disclosure of fair value of shares issued**
We are a listed company and the market
value of a share as on date of the issue is*
We are an un-listed company and the fair
value of a share is*

<!-- page 7 -->

DECLARATION TO BE FILED BY THE AUTHORISED REPRESENTATIVE OF THE
INDIAN COMPANY: (Delete whichever is not applicable and authenticate)
We hereby declare that:
1. We comply with the procedure for issue of shares / convertible debentures as laid down
under the FDI scheme as indicated in Notification No. FEMA 20/2000-RB dated 3rd May
2000 as amended from time to time.
2. The investment is within the sectoral cap/statutory ceiling permissible under the
Automatic Route of RBI and we fulfill all the conditions laid down for investments under
the Automatic Route namely (strike off whichever is not applicable) .
a) Foreign entity/entities—(other than individuals), to whom we have issued shares
have existing joint venture or technology transfer or trade mark agreement in India
in the same field and Conditions stipulated in Press Note 1 of 2005 Series dated
January 12, 2005 have been complied with.
OR
Foreign entity/entities—(other than individuals), to whom we have issued shares
do not have any existing joint venture or technology transfer or trade mark
agreement in India in the same field.
b) We are not an SSI unit.

OR

We are a SSI unit and the investment limit of 24 % of paid-up capital has been
observed/ requisite approvals have been obtained.
c) Shares issued on rights basis to non-residents are in conformity with Regulation
6 of the RBI Notification No FEMA 20/2000-RB dated 3rd May 2000, as amended
from time to time.
OR
Shares issued are bonus shares.
OR
Shares have been issued under a scheme of merger and amalgamation of two or
more Indian companies or reconstruction by way of de-merger or otherwise of an
Indian company, duly approved by a court in India.
OR
Shares are issued under ESOP and the conditions regarding this issue have been
satisfied

<!-- page 8 -->

3. Shares have been issued in terms of SIA/FIPB approval No.___________________
dated ____________________
4. We enclose the following documents in compliance with Paragraph 9 (1) (B) of
Schedule 1 to Notification No. FEMA 20/2000-RB dated May 3, 2000:
(i)

(ii)

A certificate from our Company Secretary certifying that
(a)
all the requirements of the Companies Act, 1956 have been
complied with;
(b)
terms and conditions of the Government approval, if any, have been
complied with;
(c)
the company is eligible to issue shares under these Regulations;
and
(d)
the company has all original certificates issued by authorised
dealers in India evidencing receipt of amount of consideration in
accordance with paragraph 8 of Schedule 1 to Notification No.
FEMA 20/2000-RB dated May 3, 2000.
A certificate from Statutory Auditors / Chartered Accountant indicating the
manner of arriving at the price of the shares issued to the persons resident
outside India.

5. Unique Identification Numbers given for all the remittances received as consideration
for issue of shares/convertible debentures (details
as above), by Reserve Bank.
R
.
.
.
R

(Signature of the Applicant)* :___________________________________________
(Name in Block Letters)

:___________________________________________

(Designation of the signatory) :___________________________________________
Place:
Date:
(* To be signed by Managing Director/Director/Secretary of the Company)

<!-- page 9 -->

CERTIFICATE TO BE FILED BY THE COMPANY SECRETARY‡ OF THE INDIAN
COMPANY ACCEPTING THE INVESTMENT:
(As per Para 9 (1) (B) (i) of Schedule 1 to Notification No. FEMA 20/2000-RB dated
May 3, 2000)
In respect of the abovementioned details, we certify the following :
1. All the requirements of the Companies Act, 1956 have been complied with.
2. Terms and conditions of the Government approval, if any, have been complied with.
3. The company is eligible to issue shares / convertible debentures under these
Regulations.
4. The company has all original certificates issued by AD Category – I banks in India,
evidencing receipt of amount of consideration in accordance with paragraph 8 of Schedule
1 to Notification No. FEMA 20/2000-RB dated May 3, 2000.
(Name & Signature of the Company Secretary) (Seal)
FOR USE OF THE RESERVE BANK ONLY:
Registration Number for the FC-GPR:
Unique Identification Number allotted to the
Company at the time of reporting receipt of
remittance

‡

R

If the company doesn’t have a full time Company Secretary, a certificate from a practising Company
Secretary may be submitted.

<!-- page 10 -->

[Part-B of Annex I to A. P. (DIR Series) Circular No. 44 dated May 30, 2008]
FC-GPR
PART-B
(i) This part of form FC-GPR is to be submitted to the Director, Balance of Payment
Statistical Division, Department of Statistical Analysis & Computer Services, Reserve
Bank of India, C8, 3rd Floor, Bandra-Kurla Complex, Bandra (E), Mumbai – 400051;
Tel: 2657 1265, 2657 2513, Fax: 26570848; email:surveyfla@rbi.org.in
(ii) This is an annual return to be submitted by 31st of July every year by all companies,
pertaining to all investments by way of direct/portfolio investments/re-invested
earnings/others in the Indian company made during the previous years (e,g. the
information in Part B submitted by 31st July 2008 will pertain to all the investments made
in the previous years up to March 31, 2008). The details of the investments to be reported
would include all foreign investments made into the company which is outstanding as on
the date of the balance sheet. The details of overseas investments in the company both
under Direct / portfolio investment may be separately indicated. Please use end-March
Market prices/exchange rates for compiling the relevant information.
--------------------------------------------------------------------------------------------------------------------Permanent Account
Number (PAN) of the
investee company given
by the Income Tax
Department
No.
1.

Name

Particulars

(In Block Letters)

Address

State

2.

Registration No. given by the
Registrar of Companies
Name of the Contact Person:
Tel.
Fax:

Designation:
E-mail:

<!-- page 11 -->

3.
4.

Account closing date:
Details of changes if any, with regard
to information furnished earlier
(Change in name of company /
Change of location, activities, etc.)
5.
Whether listed company or
unlisted company
5.1 If listed,
i)
ii)

Listed / Unlisted

Market value per share as at
end-March
Net Asset Value per share as on
date of latest Audited Balance
Sheet

5.2 If unlisted, Net Asset Value per
share as on date of latest Audited
Balance Sheet
6. Foreign Direct Investment (FDI)

6.0 Equity Capital
6.1 Other Capital Ω
6.2 Disinvestments during
the year
6.3 Retained earnings during
the year +

Foreign Liabilities In
India ∗
Outstanding Outstanding
at endat endMarch of
March of
Previous
Current
Year
Year

Amount in Lakhs of Rupees
Foreign Assets Outside
India &
Outstanding Outstanding
at endat endMarch of
March of
Previous
Current
Year
Year

∗

Please furnish the outstanding investments of non-resident investors (Direct Investors) who were holding
10 per cent or more ordinary shares of your Company on the reporting date.

&

Please furnish your total investments outside the country in each of which your Company held 10 per cent
or more ordinary shares of that non-resident enterprise on the reporting date.

Ω

Other Capital includes transactions between the non-resident direct investor and investee / reporting
company, relating to i) Short Term Borrowing from overseas investors, ii) Long Term Borrowing from overseas
investors, iii) Trade Credit, iv) Suppliers Credit, v) Financial Leasing, vi) Control Premium, vii) NonCompetition Fee in case of transactions not involving issue of shares, viii) Non-cash acquisition of shares
against technical transfer, plant and machinery, goodwill, business development and similar considerations
and ix) investment in immovable property made during the year.
+
Under foreign liabilities, for retained earnings (undistributed profit), please furnish the proportionate amount
as per the share holding of non-resident investors (Direct investors). Similarly under foreign assets outside

<!-- page 12 -->

7. Portfolio and Other Investment

[Please furnish here the outstanding investments other than those mentioned under FDI above]

7.0
7.1

Foreign Liabilities In
India
Outstanding Outstanding
at endat endMarch of
March of
Current
Previous
Year
Year

Equity Securities
Debt Securities
7.1.1 Bonds and Notes
7.1.2 Money Market
Instruments
7.2 Disinvestments during
the year
8. Financial Derivatives
(notional value)
9. Other Investment
9.1 Trade Credit
9.1.1 Short Term
9.1.2 Long Term
Please see the note below
9.2 Loans∞
9.3 Others
9.3.1 Short Term
9.3.2 Long Term

Amount in Lakhs of Rupees
Foreign Assets Outside
India
Outstanding Outstanding
at endat endMarch of
March of
Current
Previous
Year
Year

India, the retained earnings of your company would be proportionate to your shareholding of ordinary shares
in the non-resident enterprise.
∞

Note: As the details of the Loans availed of by your company are collected through Authorised Dealers
separately by Foreign Exchange Department of the Reserve Bank in ECB returns, the details of external loans
availed by your company need not be filled in. However, the external loans extended by your company to nonresident enterprises other than WOS/JVs outside India should be reported under “Foreign Assets outside
India”.

<!-- page 13 -->

%

Amount
(Face
Value) Rs.

No.
of
shares

Compulsorily
convertible
Preference Shares/
Debentures

%

Amount
(Face
Value) Rs.

Investor category / Nature of investing entity

Equity

No.
of
shares

10. Shareholding pattern as at end-March

a) Non-Resident
01 Individuals
02 Companies
03 FIIs
04 FVCIs
05 Foreign Trusts
06 Private Equity Funds
07 Pension/ Provident Funds
08 Sovereign Wealth Fund (SWF)§
08 Partnership / Proprietorship
Firms
09 Financial Institutions
10 NRIs/PIO
11 Others (please specify)
Sub Total
b) Resident
Total
11.

Persons employed during the financial year ending March 31®
Directly
Indirectly
Total

Signature of the authorised
Official
:__________________________________________
Name (in block letters)

:__________________________________________

Designation

:__________________________________________

Place:

Date:

§

SWF means a Government investment vehicle which is funded by foreign exchange assets, and which
manages those assets separately from the official reserves of the monetary authorities.

®

Please indicate the number of persons recruited by your company during the financial year for which the
return is being submitted. Under “Directly’, indicate the number of persons on the roll of your company,
whereas under “Indirectly”, indicate the number of persons otherwise engaged by your company during the
year.

<!-- page 14 -->

Annex II
[Annex to A. P. (DIR Series) Circular No. 44 dated May 30, 2008]
Report by the Indian company receiving amount of consideration for issue of shares /
convertible debentures under the FDI Scheme
(To be filed by the company through its Authorised Dealer Category – I bank, with the Regional
Office of the Reserve Bank under whose jurisdiction the Registered Office of the company
making the declaration is situated, not later than 30 days from the date of receipt of the amount
of consideration, as specified in para 9 (I) (A) of Schedule I to Notification No. FEMA 20/2000RB dated May 3, 2000)
Permanent Account
Number (PAN) of the
investee company given
by the IT Department

No.
Particulars
1.
Name of the Indian company

(In Block Letters)

Address of the Registered Office

2

Fax
Telephone
e-mail
Details of the foreign investor/ collaborator
Name
Address

3.
4.
5.

Country
Date of receipt of funds
Amount

In foreign currency

In Indian Rupees

Whether investment is under Automatic Route / Approval Route
Automatic Route or Approval
Route
If Approval Route, give details (ref.
no. of approval and date)

<!-- page 15 -->

6.
7.

Name of the AD Category – I bank
through whom the remittance is
received
Address of the AD Category – I
bank

Copy of the FIRC/s evidencing the receipt of consideration for issue of shares / convertible
debentures as above is enclosed.
(Authorised signatory of
the investee company)

(Stamp)

FOR USE OF THE RESERVE BANK ONLY:

Unique Identification Number for the remittance received:

(Authorised signatory of the AD)

(Stamp)

<!-- page 16 -->

Annex III
[Annex to A. P. (DIR Series) Circular No. 44 dated May 30, 2008]
Know Your Customer (KYC) Form in respect of the non-resident investor
Registered Name of the Remitter / Investor
(Name, if the investor is an Individual)
Registration Number (Unique Identification
Number* in case remitter is an Individual)
Registered Address (Permanent Address if
remitter Individual)
Name of the Remitter’s Bank
Remitter’s Bank Account No.
Period of banking relationship with the
remitter
*Passport No., Social Security No, or any Unique No. certifying the bonafides of the
remitter as prevalent in the remitter’s country
We confirm that all the information furnished above is true and accurate as provided
by the overseas remitting bank of the non-resident investor.
(Signature of the Authorised Official
of the AD bank receiving the remittance)
Date:
Place:
Stamp :
