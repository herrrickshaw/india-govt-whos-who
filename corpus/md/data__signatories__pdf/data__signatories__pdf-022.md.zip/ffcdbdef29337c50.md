---
doc_id: "ffcdbdef29337c50"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/2640b24f65e8eede3ffd866f0987239c.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Spectrum e-Auction Day 2 Report"
date: "2021-03-02"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "15ff5339b8118637"
---

<!-- page 1 -->

Spectrum Auction 2021
Daily Public Report: End of day 2
Date

02-03-2021

Number of Clock Rounds completed today :

2

Total Number of Clock Rounds completed till Date :

6
Information By Service Area

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
No.)
Price per
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Andhra
Pradesh

700 MHz

2785

0

-6

0

0

Assam

700 MHz

460

0

-6

0

0

Bihar

700 MHz

875

0

-6

0

0

Delhi

700 MHz

4575

0

-6

0

0

Gujarat

700 MHz

2730

0

-6

0

0

Haryana

700 MHz

565

0

-6

0

0

Himachal
Pradesh

700 MHz

185

0

-6

0

0

Jammu &
Kashmir

700 MHz

170

0

-6

0

0

Karnataka

700 MHz

1095

0

-6

0

0

Kerala

700 MHz

950

0

-6

0

0

<!-- page 2 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Kolkata

700 MHz

1735

0

-6

0

0

Madhya
Pradesh

700 MHz

950

0

-6

0

0

Maharashtra 700 MHz

3645

0

-6

0

0

Mumbai

700 MHz

5610

0

-6

0

0

North East

700 MHz

170

0

-6

0

0

Odisha

700 MHz

270

0

-6

0

0

Punjab

700 MHz

885

0

-6

0

0

Rajasthan

700 MHz

1055

0

-6

0

0

Tamil Nadu

700 MHz

995

0

-6

0

0

Uttar Pradesh 700 MHz
(East)

1525

0

-6

0

0

Uttar Pradesh 700 MHz
(West)

1150

0

-6

0

0

West Bengal 700 MHz

525

0

-6

0

0

Andhra
Pradesh

800 MHz

487.5

5

-6

487.5

0

Assam

800 MHz

80

0

-2

0

0

Bihar

800 MHz

170

4

-6

170

0

Delhi

800 MHz

800

7

-3

800

0

Gujarat

800 MHz

481.25

4

-1

481.25

0

<!-- page 3 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Haryana

800 MHz

71.25

7

-1

71.25

0

Himachal
Pradesh

800 MHz

30

4

-4

30

0

Jammu &
Kashmir

800 MHz

18.75

0

-2

0

0

Karnataka

800 MHz

240

8

-3

240

0

Kerala

800 MHz

196.25

8

-3

196.25

0

Kolkata

800 MHz

200

8

-2

200

0

Madhya
Pradesh

800 MHz

178.75

8

-2

178.75

0

Maharashtra 800 MHz

637.5

10

-2

637.5

0

Mumbai

800 MHz

908.75

6

-2

908.75

0

North East

800 MHz

18.75

0

-2

0

0

Odisha

800 MHz

58.75

4

-5

58.75

0

Punjab

800 MHz

196.25

5

-4

196.25

0

Rajasthan

800 MHz

332.5

4

-2

332.5

0

Tamil Nadu

800 MHz

217.5

8

-3

217.5

0

Uttar Pradesh 800 MHz
(East)

313.75

4

-6

313.75

0

Uttar Pradesh 800 MHz
(West)

201.25

8

-2

201.25

0

West Bengal 800 MHz

92.5

8

-1

92.5

0

<!-- page 4 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Andhra
Pradesh

900 MHz

83.4

0

-18

0

0

Assam

900 MHz

16.6

0

-29

0

0

Bihar

900 MHz

40.2

17

-35

40.2

0

Delhi

900 MHz

117

0

-11

0

0

Gujarat

900 MHz

74.97

0

-21

74.6

0

Haryana

900 MHz

20.4

0

-4

0

0

Himachal
Pradesh

900 MHz

7.4

13

-13

7.4

0

Karnataka

900 MHz

47.6

0

-19

0

0

Kerala

900 MHz

39.99

0

-23

39.8

0

Kolkata

900 MHz

44.2

0

-21

0

0

Madhya
Pradesh

900 MHz

39

0

-29

0

0

Maharashtra 900 MHz

104.6

0

-21

0

0

Mumbai

900 MHz

138.2

0

-11

0

0

North East

900 MHz

4.6

6

-19

4.6

0

Odisha

900 MHz

17.2

19

-7

17.2

0

Tamil Nadu

900 MHz

47

50

-38

47

0

52.4

25

-7

52.4

0

Uttar Pradesh 900 MHz
(East)

<!-- page 5 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Uttar Pradesh 900 MHz
(West)

42.2

0

-12

0

0

West Bengal 900 MHz

24.8

18

-8

24.8

0

Andhra
Pradesh

1800 MHz

55.8

21

-61

55.8

0

Assam

1800 MHz

9.2

23

-11

9.2

0

Bihar

1800 MHz

17.6

39

-4

17.6

0

Delhi

1800 MHz

91.4

23

-54

91.4

0

Gujarat

1800 MHz

54.6

20

-69

54.6

0

Haryana

1800 MHz

11.4

25

-91

11.4

0

Himachal
Pradesh

1800 MHz

3.6

24

-90

3.6

0

Jammu &
Kashmir

1800 MHz

3.4

50

-20

3.4

0

Karnataka

1800 MHz

21.8

101

-23

21.8

0

Kerala

1800 MHz

19

50

-41

19

0

Kolkata

1800 MHz

34.6

5

-67

34.6

0

Madhya
Pradesh

1800 MHz

19

39

-55

19

0

Maharashtra 1800 MHz

73

25

-86

73

0

Mumbai

1800 MHz

112.2

17

-61

112.2

0

North East

1800 MHz

3.4

18

-1

3.4

0

<!-- page 6 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Odisha

1800 MHz

5.42

0

-38

5.4

0

Punjab

1800 MHz

17.6

49

-48

17.6

0

Rajasthan

1800 MHz

21

0

-84

0

0

Tamil Nadu

1800 MHz

20

91

-6

20

0

Uttar Pradesh 1800 MHz
(East)

30.6

41

-53

30.6

0

Uttar Pradesh 1800 MHz
(West)

23

43

-73

23

0

West Bengal 1800 MHz

10.6

19

-16

10.6

0

Andhra
Pradesh

2100 MHz

925

0

-3

0

0

Assam

2100 MHz

150

1

-1

150

0

Bihar

2100 MHz

495

0

-1

0

0

Delhi

2100 MHz

3175

0

-3

0

0

Gujarat

2100 MHz

905

0

-2

0

0

Haryana

2100 MHz

315

0

-1

0

0

Himachal
Pradesh

2100 MHz

60

0

-3

0

0

Jammu &
Kashmir

2100 MHz

65

0

-1

0

0

Karnataka

2100 MHz

455

0

-2

0

0

Kerala

2100 MHz

1015

0

-1

0

0

<!-- page 7 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Kolkata

2100 MHz

575

0

-2

0

0

Madhya
Pradesh

2100 MHz

340

0

-2

0

0

Maharashtra 2100 MHz

1955

0

-1

0

0

Mumbai

2100 MHz

2640

0

-2

0

0

North East

2100 MHz

30

1

-1

30

0

Odisha

2100 MHz

220

0

-2

0

0

Punjab

2100 MHz

520

0

-1

0

0

Uttar Pradesh 2100 MHz
(West)

380

0

-2

0

0

West Bengal 2100 MHz

175

1

-1

175

0

Andhra
Pradesh

2300 MHz

780

1

-1

780

0

Assam

2300 MHz

20.1

0

-2

20

0

Bihar

2300 MHz

70.35

0

-2

70

0

Delhi

2300 MHz

1640

1

-1

1640

0

Gujarat

2300 MHz

703.5

0

-2

700

0

Haryana

2300 MHz

80.4

0

-4

80

0

Himachal
Pradesh

2300 MHz

10.05

0

-2

10

0

Jammu &
Kashmir

2300 MHz

10.05

0

-4

10

0

<!-- page 8 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Karnataka

2300 MHz

1120

1

-1

1120

0

Kerala

2300 MHz

201

0

-2

200

0

Kolkata

2300 MHz

380

1

-1

380

0

Madhya
Pradesh

2300 MHz

90.45

0

-2

90

0

Maharashtra 2300 MHz

723.6

0

-2

720

0

Mumbai

2300 MHz

1670

1

-1

1670

0

North East

2300 MHz

10.05

0

-2

10

0

Odisha

2300 MHz

50.25

0

-2

50

0

Punjab

2300 MHz

211.05

0

-4

210

0

Rajasthan

2300 MHz

60.3

0

-4

60

0

Tamil Nadu

2300 MHz

1510

1

-1

1510

0

Uttar Pradesh 2300 MHz
(East)

90.45

0

-4

90

0

Uttar Pradesh 2300 MHz
(West)

120.6

0

-4

120

0

West Bengal 2300 MHz

60.3

0

-2

60

0

Andhra
Pradesh

2500 MHz

780

0

-3

0

0

Bihar

2500 MHz

70

0

-1

0

0

Delhi

2500 MHz

1640

0

-2

0

0

<!-- page 9 -->

Service area Band

Clock Round Aggregate Demand at Round 6 Price (In
Price per
No.)
Block in
Round 6 (In
Crore)

Excess
Demand at
Round 6
Price (In
No.)

Provisional Price Increment Applicable
Winning
for Round 7 (In Crore)
Price per
Block at end
of Round 6
(In Crore)

Gujarat

2500 MHz

450

0

-1

0

0

Himachal
Pradesh

2500 MHz

10

0

-1

0

0

Jammu &
Kashmir

2500 MHz

10

0

-1

0

0

Karnataka

2500 MHz

980

0

-4

0

0

Kolkata

2500 MHz

380

0

-2

0

0

Maharashtra 2500 MHz

660

0

-1

0

0

Mumbai

2500 MHz

1670

0

-2

0

0

Punjab

2500 MHz

240

0

-1

0

0

Tamil Nadu

2500 MHz

1320

0

-4

0

0
