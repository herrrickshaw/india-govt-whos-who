---
doc_id: "ff1f1b0f53aee9ed"
source_url: "https://dsel-education.gov.in/static/uploads/2025/09/1dcd41c2e5a66e19f55ddf7488bf96ec.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "RTE (Amendment) Rules, 2017"
date: "2017-02-22"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ea4b493efaae7c85"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 127]
No. 127]

ubZ fnYyh] cq/okj] iQjojh 22] 2017@iQkYxqu 3] 1938
NEW DELHI, WEDNESDAY, FEBRUARY 22, 2017/PHALGUNA 3, 1938

मानव संसाधन िवकास मं ालय
( कू ल िश ा और सा रता िवभाग)

अिधसूचना
नई द ली, 20 फरवरी, 2017
सा.का.िन. 155(अ).—िनःशु क और अिनवाय बाल िश ा का अिधकार अिधिनयम, 2009 (2009 का
35) क धारा 38 ारा द अिधकार का योग करते ए के

ीय सरकार िनःशु क और अिनवाय बाल िश ा का

अिधकार िनयम, 2010 म िन िलिखत संशोधन करती है, नामतः1.

लघु शीष और आरं भः- (1) इन िनयम को िनःशु क और अिनवाय बाल िश ा का अिधकार (संशोधन)
िनयम, 2017 कहा जाएगा।
(2)

2.

ये राजक य राजप म इनके काशन क ितिथ से वृ ह गे।

िनःशु क और अिनवाय बाल िश ा का अिधकार िनयम, 2010 के

ारं िभक िश ा क पा

चया और उसे

पूरा करने से संबंिधत भाग VII म िनयम 23, उप-िनयम (2) के खंड (ग) के थान पर िन िलिखत खंड ित थािपत
कए जाएंगे, नामतः“(ग) सभी ारं िभक क ा

के िलए क ा-वार, िवषय-वार अिधगम प रणाम तैयार करना; और

(घ) प रभािषत अिधगम प रणाम को ा करने के िलए सतत् और

ापक मू यांकन को अमल म लाने के

िलए दशा-िनदश तैयार करना।”
[फा.सं. 16-3/2016-ईई-17/ईई-13/ईई-4]
रीना रे, अपर सिचव
ट पणीः- अिधसूचना सं या सा.का.िन. 301 (ई), दनांक 8 अ ैल, 2010 के ज रए भारत के राजप के भाग II,
खंड-3, उपखंड (i), दनांक 9 अ ैल, 2010 म मूल िनयम कािशत कए गए थे।
1010GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF HUMAN RESOURCE DEVELOPMENT
(Department of School Education and Literacy)

NOTIFICATION
New Delhi, the 20th February, 2017.
G.S.R 155(E).—In exercise of the power conferred by section 38 of the Right of Children to Free and
Compulsory Education Act, 2009 (35 of 2009), the Central Government hereby makes the following amendments in the
Right of Children to Free and Compulsory Education Rules, 2010, namely:1.
Short title and commencement:- (1) These rules may be called the Right of Children to Free and Compulsory
Education (Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.
In the Right of Children to Free and Compulsory Education Rules, 2010 in Part VII relating to Curriculum and
Completion of Elementary Education, in rule 23, in sub-rule (2) for clause (c), the following clauses shall be substituted,
namely :“(c) prepare class-wise, subject-wise learning outcomes for all elementary classes; and
(d) prepare guidelines for putting into practice continuous and comprehensive evaluation, to achieve the defined
learning outcomes.”.
[F.No. 16-3/2016-EE-17/EE-13/EE-4]
RINA RAY, Addl. Secy.

Note:- The principal rules were published vide notification number G.S.R. 301(E), dated the 8th April, 2010 in the
Gazette of India, Part II, Section 3, Sub-Section (i), dated the 9th April, 2010.

signed by RAKESH SUKUL
RAKESH SUKUL Digitally
Date: 2017.02.28 11:18:07 +05'30'

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
