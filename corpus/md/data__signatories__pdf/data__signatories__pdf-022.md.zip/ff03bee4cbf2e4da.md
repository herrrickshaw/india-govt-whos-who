---
doc_id: "ff03bee4cbf2e4da"
source_url: "https://www.texmin.gov.in/static/uploads/2025/06/ff5b1a3b5bf78b210a7e52897d4b08ed.pdf"
ministry: "Textiles (MoT)"
title: "RFP for Empanelment of Implementing Partners (IPs) for undertaking training programme under (Samarth)"
date: "2024-12-16"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3ca4d93fe056d6b0"
---

<!-- page 1 -->

Government of India

Ministry of Textiles
Request for Proposals (RFP)
for
Textiles Industry/ Associations registered under Central/ State
Government/Chambers of Commerce of Central/ State Government

Empanelment of Implementing Partners (IPs) for undertaking
training programme
under
(Samarth)"
Scheme for Capacity Building in Textiles Sector (SCBTS)
Online Proposal Submission Start Date
Online Proposal Submission End Date

06.12.2024
(from 10:00 AM)
31.03.2025
(upto 06:00 PM)

The present RFP is for empanelment of fresh Implementing Partners from Industry/
Industry Associations. IP’s already empanelled under Samarth scheme need not apply.
Already empanelled IP’s may approach Ministry for enhancement of allocated targets/
addition of new centres directly. State Government Agencies may also directly approach
Ministry for partnering with us for conducting training under Samarth Scheme in their
respective states.

<!-- page 2 -->

1. Introduction
The textile and apparel industry is one of the earliest industries developed in India. Its entire value chain
from fiber to apparel manufacturing has a strong presence within the country. It is the biggest employer
after agriculture. In order to meet the skill gap in the industry and also to supplement the efforts of the
industry in employment generation, Government of India h a s approved the new scheme titled
"Scheme for Capacity Building in Textiles Sector" for the entire value chain of textiles except Spinning
and Weaving in the organized sector. The scheme was initially launched in 2017-18. Further Scheme is
extended till March 2026 i.e., 2024-25 to 2025-2026 co-terminus with 15th Finance Commission to train
3 lakh persons.

2.

Objectives
i.

ii.

Demand driven placement-oriented skilling programme to incentivize the efforts of the industry in
creating jobs in textile and related sectors, which includes skilling, re-skilling, skill up-gradation,
multi-skilling in various job roles for entire value chain of mainstream sectors except spinning &
weaving.
To promote skilling and skill up-gradation in the decentralized traditional sectors such as
handlooms, handicrafts, jute, silk etc. through respective enhancement of wages of weavers,
artisans, and craftsman. To promote skilling and skill upgradation in the traditional sectors of
handlooms, handicrafts, sericulture and jute.

3. Terms and Conditions
i.

ii.

The Ministry through this RFP intends to empanel organizations working in textile value chain /
textile related item in India / Textile Industry Associations registered under Central/ State
Government/Chambers of Commerce of Central/ State as Implementing Partners (IPs) to
undertake training programmes across the entire value chain of organized textiles sectors except
Spinning & Weaving on the terms and conditions as stipulated in the scheme guidelines which
rd
have been issued on 23 April, 2018.
The empanelment of Implementing Partners will be based on the following parameters:
a.
b.

iii.

iv.

v.

vi.

vii.

viii.

Organization credentials
Financial strength

Empanelment of the agencies will be provisional and target for training under the scheme will be
awarded to the agency subject to the availability of the training target, budget and training
capacity as laid down by the Ministry from time to time.
Trainees under the scheme will be selected through a transparent and inclusive process. The
trainee must be a citizen of India possessing an Aadhaar Card (unless exempted under Aadhaar
Act, 2016) with age over 14 years. Preference will be given to the marginalized social groups like
women, SC/ST, differently-abled persons, minorities and persons from the BPL category.
A minimum of 80% attendance during training is mandatory for a trainee to be eligible for
assessment. Aadhaar Enabled Biometric Attendance System integrated with centralized MIS will
be adopted to ensure real time attendance of the trainers and the trainees.
Infrastructure for conduct of Training: The IP must possess the requisite training infrastructure as
laid down in the Training Centre (TC) infrastructure protocol downloadable form the Samarth
website (https://samarth-textiles.gov.in).
Trainer: Each of the training centre will be run by a qualified trainer and support staff. The
capacity of the trainers shall be enhanced through a comprehensive Training of Trainers (ToT)
Programme. Training of Trainers will be conducted by the Resource Support Agency (RSA) of
Samarth and Sector Skill Councils in line with the common norms and guidelines of Ministry of
Skill Development & Entrepreneurship (MSDE).
Course Content: Only the courses which are aligned with NSQF and approved by the RSA will be
offered to the trainees. The content for each course/programme shall be need-based to meet the

<!-- page 3 -->

ix.

x.

xi.
xii.
xiii.

xiv.

xv.

xvi.
xvii.
xviii.
xix.

xx.
xxi.

highest standards and requirements of the related industry segment, including awareness about
labour laws, and will be designed by the RSA in consultation with the industry. Use of multimedia
content and other applications of Information Technology (IT) would be encouraged.
Mandatory CCTV recording has to be done for the entire training programme. Recordings have to
be kept by Implementing Partners (IP) for a minimum period of one year from the date of
completion of training programme.
Assessment and Certification: Third Party Assessment and Certification will be mandatory for all
the eligible trainees. The RSA will specify the assessment protocol and procedure in line with the
Common Norms of the MSDE. Assessment Agencies will be required to ensure video recording
of the entire assessment process and record to be kept for one year from date of assessment.
Placement: The IP shall provide placement to 70% of successfully certified trainees, trained in
organized sector under the scheme in wage employment.
Placement Retention: The IP shall provide 6 months of placement retention to each placed
trainee.
Post Placement Tracking: Each trainee will be tracked by the IP for a period of -one year from the
date of certification of training. The IP will be required to upload the details of placement and
tracking on MIS every month along with the supporting documentary proof.
Funding: The assistance under the scheme will be only towards the cost heads (refer para 7.4.1.
of the scheme guidelines) covered under the Common Norms of the MSDE and agreed to by the
Ministry under this scheme. Funds will be provided as per the scheme guidelines and
amendments done from time-to-time. Detailed costing of training programme under “Samarth”
may be referred to at Annexure-III of the scheme guidelines.
Where any implementing partner is already obtaining assistance from GOI or State Government
under any other scheme for any cost component or where Government infrastructure is involved
in the training, appropriate deduction from GOI share shall be made as per the cost norms
notified by MSDE from time to time.
Sub-contracting / sub-letting of the training programme is strictly prohibited.
In the case of Textile Industry unit, allocation of training target is for meeting the requirement of
skilled manpower in respective organizations.
In the case of Industry Associations, allocation of training target is for meeting the requirement of
skilled manpower of its Member / Partners.
Textile Industry can either submit application directly for empanelment or can participate in the
training programme under the banner of Industry Association / Chamber of Commerce etc.,
subject to fulfilling eligibility criteria as per the para 4 of the RFP.
The empanelment of agencies will be valid till March, 2026.
For more details in respect of any point, please refer to the scheme guidelines issued on 23rd
April, 2018 (available at www.texmin.nic.in/ Samarth website (https://samarth-textiles.gov.in).

4. Minimum Qualification Criteria
4.1 Types of Applicants
The skilling programme will be implemented through the following Implementing Partners. and
they would be in existence as such for a period of at least five years for meeting the requirement
of skilled manpower in respective organizations. Also, they should possess requisite infrastructure
available with them for conducting the training program:
i. Any organization working in textile value chain / textile related item in India, which is
incorporated under Companies Act, Indian Partnership Act/LLP Act.
ii. An Industry Association related with Textile Sector having member industry engaged in
production of textiles
iii. Chamber of Commerce registered with Ministry / Department under Central or State
Government empanelment having member industry engaged in production of textiles.

<!-- page 4 -->

4.2

Minimum Turnover

S. No. Type of Organization

Minimum Average Turnover (based
on the average of last three financial
years)

1

Company (Textile Industry)

Rs. 3 Crore

2

Associations registered under Central / State
Government / Chambers of Commerce registered
with Ministry / Department under Central or State
Government

Rs. 50 Lakhs

5. General Conditions

The interested applicant will be required to apply online through MIS (Samarth portal) following
the under mentioned process:
i. The submission of proposal by Consortium / Group of Entities / proprietorship firm is not
permitted under the Scheme.
ii. The applicant should pay application processing fee (non-refundable) of Rs. 10,000/- in the
form of Demand Draft (DD) drawn in favour of Pay and Accounts Officer, Ministry of Textiles,
New Delhi. The original DD will have to be sent to the Under Secretary (HRD Section), Ministry
of Textiles, Udyog Bhawan, New Delhi - 110011 within 10 days of submission of online
application. A scanned copy of the DD to be uploaded in MIS (Samarth Portal) while
submitting the application. The proposal will be treated as incomplete and cancelled in case of
non-receipt of Original of DD in the Ministry.
iii. Empanelment of applicant is based on meeting the "Minimum Qualification Criteria" for
availing assistance under the scheme prescribed in this RFP.
iv. Applicant will be required to submit a Performance Security in the form of bank guarantee to
the tune of 5% of the total eligible government funding at the time of signing of Memorandum
of Agreement which will remain valid for a period of 6 months beyond the date of scheme.
v. The Applicant will utilize the funds released to it for the purposes for which the same are
sanctioned. Under no circumstances, the funds will be utilized for purposes other than those
specified under the project.
vi. Applicant shall be responsible for training center's infrastructure resources, trainee
mobilization, assessment & certification, placement and post placement tracking as per the
scheme guidelines. Any amendments to the scheme guidelines shall be applicable and
binding on the empaneled IP.
vii. Any applicant who is found to have a Conflict of Interest shall be disqualified. The conflict of
Interest will arise if:
a. A constituent/ principal of such applicant is also a constituent/ principal of another applicant; or
b. Such applicant or any associate is an existing consultant to the Ministry or its organization in
the preparation of any documents, design or technical specifications of the scheme.
viii. An applicant shall be liable for disqualification if any legal, financial or technical adviser of the
Ministry in relation to the scheme is engaged by the applicant, its member or any associate
thereof, as the case may be, in any manner for matters related to or incidental to the project.
ix. The applicant shall open a separate dedicated Bank Account (as per the applicable
Guidelines) for conducting training programme under the scheme and to map the account on
Public Financial Management System (PFMS).

<!-- page 5 -->

x. Any entity which has been barred by the Central/ State Government, or any Ministry under,
from participating in any project (PPP or otherwise) would not be eligible to apply. An
undertaking to this effect has to be furnished by the agency in the prescribed format.
xi. Notwithstanding anything contained in this RFP, the Ministry reserves the right to accept or
reject any or all application and to annul the selection process at any time without any liability
or any obligation for such acceptance, rejection or annulment, without assigning any reason
thereof.
xii. Applicants requiring any clarification on the RFP may send their queries via email at nmccmot@nic.in. The Ministry will respond to the queries submitted by the applicant. However, the
Ministry reserves the right not to respond to any query or provide any clarification, in its sole
discretion and nothing in this Clause shall be taken or read as compelling or requiring the
Ministry to respond to any question or to provide any clarification.
xiii. The Ministry may also on its own motion, if deemed necessary, issue interpretations and
clarifications which shall be duly uploaded on the Ministry's website (www.texmin.nic.in). All
clarifications and interpretations issued by the Ministry shall be deemed to be a part of the
RFP.
xiv. The Ministry may, for any reason, whether at its own initiative or in response to clarifications
requested by any applicant, modify the RFP by the issuance of Addenda.
xv. The empanelment of agencies will be entirely at the discretion of the Ministry. The applicants
will be deemed to have understood and agreed that no explanation or justification on any
aspect of the empaneling process will be given.
xvi. The Ministry reserves the right to reject any application which is incomplete in any respect and
no request for alteration, modification, substitution, or withdrawal shall be entertained by the
Ministry thereof.
xvii. The agency will furnish details of the training centre(s) available along with the seating
capacity and relevant machines as per the course curriculum proposed. In support of the
above criteria, the agency will submit the available Training Infrastructure and other details as
per the prescribed format given in with supporting documents thereof. The training
infrastructure will be verified physically by the authorized agencies appointed by the Ministry of
Textiles and minimum training requirement will have to be submitted online.
xviii. Acknowledging the high levels of employment of women in the sector after the training, all
partner institutions and employers will be required to comply with the guidelines regarding
Internal Complaints Committee to be constituted under the Sexual Harassment of Women at
Workplace (Prevention, Prohibition &Redressal) Act, 2013 to become eligible for funding
under the scheme
xix. The implementing partners are encouraged to skill Divyang Jan for the Jobs Roles as defined
by Department of Empowerment of Persons With Disabilities, Ministry of Social Justice and
Empowerment in conjunction with NSDA.

6. Document to be submitted in online proposal
6.1 Organization Credentials
All the following documents have to be uploaded in the online application:
a.

b.
c.

Application Processing Fee (scanned copy of Demand Draft of requisite amount).
Original DD is required to be sent to the Ministry of Textile within 10 days of
submission of online application. In case of non- receipt of physical copy of DD,
the proposal will summarily be rejected.
Details of the applicant entity with contact number and email id (on the letter
head of the organization)
Power of Attorney for Signing of Application (on the letter head of the
organization). The authorized person having power of Attorney for signing of
application will only be allowed to submit the application with his valid Digital
Signature Certificate

<!-- page 6 -->

d.
e.

f.

g.

h.
i.
j.

A copy of the PAN card
Online declaration form by the applicant entity for not having been barred by the
Central/State government or any of its bodies including CPSEs for any project
(on letter head of the organization) and it is to be digitally signed.
In the case of company documents in support of legal existence of the applicant
entity (s) e.g. Certificate of Incorporation, Registration License under Section 25
of the Indian Companies Act, 1956 etc.
In the case of Textiles Associations document in support of legal existence of the
applicant entity example Certificate of Registration of Society / Trust Deed /
License under Section 25 of Companies Act, 1956 / License under Section 8 of
Companies Act, 2013 / Registration document under Chambers of Commerce.
Copy of Charter document/ Memorandum of Association.
An affidavit to the effect of providing training and requisite percentage of trainees
in wage employment as per scheme guidelines.
An undertaking stating that existing employee will not be trained under the
scheme.

6.2 Placement - Captive requirement
The agency should also certify the total workers' strength of the organization, employment
license capacity, annual requirement of trained manpower (entry level)*, attrition rate per month
(during the last five years) duly signed by the authorized signatory.
*Industry associations may submit self-declaration on behalf of its members (Textile Industry
Partners).

6.3 Minimum Average Turnover
Applicant has to submit audited annual financial statement of the last 3 years and Auditor's
Certificate in the prescribed format. Detailed information along to be filled up online.

7.

General Instructions for submission of application
a.

b.
c.

d.
e.
f.

g.
h.
i.
j.

Applicant shall be required to apply online through http://samarth-textiles.gov.in in
response to this RFP document. Acknowledgement receipt will be generated on
successful submission of online application. Please read the manual before submission.
As part of the enrolment process, the applicants will be required to choose a unique
username and assign a password for their accounts.
Applicants are advised to register their valid email address and mobile numbers as part
of the registration process. These email-ids would be used for any communication from
the Ministry of Textiles.
The Application shall be digitally signed by the authorized signatory of the applicant using
Digital Signature Certificate (DSC).
DSC should be of type ePass 2003 or ePass 2003 Auto. DSC should contain single
certificate of your identity only while submitting the application.
Only one valid DSC should be registered by an applicant. Please note that the applicants
are responsible to ensure that they do not lend their DSC's to others which may lead to
misuse.
Applications submitted by fax, e-mail and hard copy shall not be entertained and shall be
rejected.
Failure to furnish the required information in the application or submitting incomplete
application may result in the rejection of the application
st
This RFP will remain open till 31 March, 2025.
Applicants should take into account corrigendum, if any, published on the RFP before
submitting their proposals.

<!-- page 7 -->

k.
l.

m.

The Applicant has to digitally sign and upload the required supporting documents one by
one as indicated in the RFP document.
Applicant should log into the Samarth portal well in advance for application submission so
that they can upload the application in time i.e. on or before the application submission
time. Applicant will be responsible for any delay due to other issues.
If the document is in regional language (other than English/Hindi), then it should be
submitted along with true certified and notarized copy of document in English language.

<!-- page 8 -->

Tentative List of Courses
S. No

Name of the
Sector

G1

General

1.
2.
3.
4.
5.
6.
7.

Garment

8.
9.
10.
11.
12.
13.
14.
15.

17.
18.

20.

Course
Code

NSQF Notional
Level
Hours

Soft Skills

TC SS 01

-

30

Embroidery Machine Operator

TC GMT 01

2

300

Fuser & Ironer

TC GMT 02

2

300

Computer Embroidery Machine Operator

TC GMT 03

3

300

Garment Checker

TC GMT 04

2

300

CAD Operator

TC GMT 05

3

300

Sewing Machine Operator

TC GMT 06

2

300

Pattern Maker

TC GMT 07

2

300

Fabric Checker

TC GMT 08

2

300

Fabric Cutter

TC GMT 09

2

300

Overlock & Flatlock Machine Operator

TC GMT 10

2

300

Sewing Machine Mechanic

TC GMT 11

3

300

Sewing Machine Operator Knits

AMH/Q0305

3

330

Circular Knitting Machine Operator

TC KNT 01

2

300

Warp Knitting Machine Operator

TC KNT 02

2

300

Crochet Machine Operator

TC KNT 03

3

300

Junior Supervisor - Crochet Machine

TC KNT 04

4

300

HTHP Cheese Dyeing Machine Operator

TC PRC 01

2

300

Singeing Machine Operator

TC PRC 02

2

300

Desizing Machine Operator

TC PRC 03

2

300

Continuous Bleaching Range Machine
Operator

TC PRC 04

2

300

Knitting

16.

19.

Name of the Course

Processing

<!-- page 9 -->

21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.
42.
43.
44.

Textiles &
Handloom

Mercerizing Machine Operator

TC PRC 05

2

300

Jigger Machine Operator

TC PRC 06

2

300

Stenter Machine Operator

TC PRC 07

2

300

Calendering Machine Operator

TC PRC 08

2

300

Zero Zero Finishing Machine Operator

TC PRC 09

2

300

Winch Dyeing Machine Operator

TC PRC 10

2

300

Soft Flow Dyeing Machine Operator

TC PRC 11

2

300

Compacting Machine Operator

TC PRC 12

2

300

Washing Operator (Denim)

TC PRC 13

2

300

Rotary Printing Machine Assistant
Operator

TC PRC 14

2

300

Rotary Printing Machine Operator

TC PRC 15

3

300

Assistant Printing Paste Maker

TC PRC 16

2

210

Handloom Weaver (Frame Loom)

TC HLM 01

2

300

Assistant Hand Dyeing Operator

TC HLM 02

2

300

Assistant Hand Block Printing

TC HLM 03

2

300

Assistant Dobby Handloom Weaver

TC HLM 04

2

300

Jacquard Handloom Weaver

TC HLM 05

2

300

Assistant Handloom Weaver - Two
Treadles

TC HLM 06

2

270

Assistant Handloom Weaver - Multi
Treadles

TC HLM 07

2

270

Assistant Handloom Weaver - Draw boy
or Jala

TC HLM 08

2

270

Handloom Weaver (Advance) - Dobby

TC HLM 09

3

300

Handloom Weaver (Advance)- Jacquard

TC HLM 10

3

300

Assistant Handloom Designer (Manual)

TC HLM 11

2

270

Assistant Handloom Hand Dyer

TC HLM 12

2

210

<!-- page 10 -->

45.
46.
47.
48.
49.

Assistant Handloom Hand Block Printer

TC HLM 13

2

210

Electroplating and Effluent Treatment

TC MET 01

2

300

Assistant Engraver - Metal Handicrafts

TC MET 02

2

270

Lacquering and Painting Assistant

TC MET 03

2

300

Assistant Packaging

TC MET 04

2

300

TC MET 05

2

300

TC MET 06

2

300

TC MET 07

2

300

TC MET 08

2

300

Assistant Powder Coater - Metal
Handicrafts
Assistant Quality Controller - Metal
Handicrafts
Assistant Computer Aided Designer Metal Handicrafts
Assistant Welding and Soldering - Metal
Handicrafts

50.
51.
52.
53.
54.

Carving Artisan (Stonecraft)

HCS/Q1502

4

570

55.

Inlay Artisan - Stonecraft

HCS/Q1504

4

570

56.

Casting Operator (Metal Handicrafts)

HCS/Q2801

4

570

Electives:
1. Engraving Artisan
2. Stamping Operator

HCS/Q2802

4

510 with
one
elective

Engraving/ Carving/ Etching Assistant

HCS/Q7001

3

480

HCS/Q7301

4

600 with
one
elective

HCS/Q7703

3

480

HCS/Q8702

3

570 with
one
elective

57.

58.

Handicrafts &
Carpet

Engraving and Stamping Artisan

Traditional Hand Embroiderer
59.

Electives:
1. Phulkari Embroidery
2. Chikankari Embroidery
3. Zari-Zardosi Embroidery

60.

Hand Crochet Lace Maker
Bamboo Work Artisan

61.

Electives:
1. Bamboo Basket Maker
2. Bamboo Mat Weaver
3. Bamboo Utility Handicraft Assembler
Carpet Weaver

62.

Elective:
1.Carpet Weaver Knotted
2.Carpet Weaver Tufted
3.Handloom Weaver (Carpets)

HCS/Q5701

3

540 with
one
elective

<!-- page 11 -->

Ceramics Preparation Artisan
Electives:
1. Casting Operator-Ceramics
2. Colour Mixing Operator
3. Engobing operator (Ceramics)
4. Furnace Operator
5. Glazing operator (Ceramics)
6. Jigger operator (Ceramics)
7. Moudler (Ceramics)
8. Mixing operator

63.

600 with
HCS/Q0801

3

one
elective

64.

Modeller

HCS/Q0201

4

450

65.

Sketching and Painting Artisan (Ceramics) HCS/Q0802

4

450

66.

Stringing/Beading Assembler (Fashion

HCS/Q1101

2

300

Jewellery)
67.

Product Maker (Fashion Jewellery)

HCS/Q1102

4

480

68.

Jute Products Stitching Operator

HCS/Q7403

3

510

69.

Applique Artisan

HCS/Q7303

4

360

70.

Hand Block Printer

HCS/Q7201

4

420

71.

Jute Handloom Weaver

HCS/Q7402

4

360

72.

Jute Products Artisan

HCS/Q7405

4

450

73.

Finisher (Woodware)

HCS/Q7101

4

270

74.

Lacquerer (Woodware)

HCS/Q7102

4

250

75.

Designer (Woodware Products)

HCS/Q6601

5

270

76.

Painter (Metal Handicrafts)

HCS/Q3101

4

485

77.

Polisher (Metalware)

HCS/Q3002

4

330

78.

Paper Mache Craft Specialist

HCS/Q4501

4

340

79.

Master Crochet Lace Maker

HCS/Q7704

4

300

80.

Crochet Lace Tailor

HCS/Q7705

3

300

81.

Finisher (Carpet)

HCS/Q5407

4

200

Jute Selector cum Assorter

TSC/Q0107

2

330

82.

Jute

<!-- page 12 -->

83.
84.

Jute Spinning Sardar (Jobber) cum Jr.
Supervisor

TSC/Q0204

4

450

Jute Weft Winding Operator

TSC/Q0304

2

330

TSC/Q2210

3

330

TSC/Q2211

3

330

Shuttle loom operator cum pirn winder
(Powerloom/Automatic Shuttle loom)
Shuttleless Loom Operator (Airjet/ Rapier/
Projectile/ Waterjet)

85.
86.
87.

Vanya Silk Reeling & Spinning
Manufacturing Operator

TC SILK 01

3

300

88.

Mulberry Silk Reeling Manufacturing
Operator

TC SILK 02

3

300

Silk Weaving Manufacturing Operator

TC SILK 03

3

300

Silk Wet Processing Manufacturing
Operator

TC SILK 04

3

300

Silk Twister

TC SILK 05

2

210

Silk Handloom Weaver

TC SILK 06

3

270

Silk Powerloom Weaver

TC SILK 07

3

270

Computer Aided Textile Designer (Silk)

TC SILK 08

3

270

Mulberry Silk Reeler

TC SILK 09

2

210

Asst. Supervisor - Wool Cleaning and
Scouring

TC WOOL 01

4

390

Machine Operator - Wool Fiber Scouring

TC WOOL 02

3

300

Asst. Supervisor - Wool Dyeing

TC WOOL 03

4

390

Machine Operator - Wool Fiber Dyeing

TC WOOL 04

3

300

Machine Operator - Surgical Mask

TC TT 01

3

300

Machine Operator - Sanitary Napkin

TC TT 02

3

300

Machine Operator - Needle Punch
Nonwoven

TC TT 03

3

300

Machine Operator - Thermal Bonded
Nonwoven

TC TT 04

3

300

Machine Operator - Chemical Bonded
Nonwoven

TC TT 05

3

300

Machine Operator - Textile Coating

TC TT 06

3

300

Narrow Loom Operator

TC TT 07

3

300

89.
90.
91.

Silk

92.
93.
94.
95.
96.
97.
98.

Others (Wool)

99.
100.
101.
102.
103.
104.
105.
106.

Technical
Textiles

<!-- page 13 -->

107.

Junior Supervisor - Narrow Loom

TC TT 08

4

300

Junior Supervisor - Shade Net Fabric
Machine

TC TT 09

4

300

Shade Net Fabric Machine Operator

TC TT 10

3

300

N95 Face Mask Machine Operator

TC TT 11

3

300

Lab Technician- N95 Face Mask

TC TT 12

4

390

112.

PPE Coverall (Disposable Gown)
Stitching & Sealing Machine Operator

TC TT 13

3

300

113.

Lab Technician - PPE Coverall
(Disposable Gowns)

TC TT 14

4

390

TC FIBER 01

3

300

108.
109.
110.
111.

114.

Hand Held Kapas Plucker Machine
Other (Other
Operator
Fiber-Cotton)
