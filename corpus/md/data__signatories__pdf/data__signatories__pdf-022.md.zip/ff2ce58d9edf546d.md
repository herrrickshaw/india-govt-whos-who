---
doc_id: "ff2ce58d9edf546d"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/e4f66c62b8604c8cf02942f1c162395b.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Promotion of Shri Vinay Kumar Trivedi, Dy. CLC(C), Asansol to SAG of CLS - reg.	 (Office Order 21/2024)"
date: "2024-10-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "13255e215234ec0a"
---

<!-- page 1 -->

No. A-31011/04/2023-CLS.I
Government of India

Ministry of Labour & Employment
Shram ShaktiBhawan, Rafi Marg

New Delhi, date

October, 2024

OFFICE ORDER No. 21/2024

The President is plcascd to appoint Shri Vinay Kumar Trivedi, Junior
Administrative Grade (NFSG) officer of Central Labour Service (CLS) to Senior
Administrative Grade (SAG) of CLS on promotion on regular basis in Level 14 of the
Pay Matrix (Rs. 1,44,200-2,18,200/-) with effect from the date of assumption of charge
of the post.
2.

On promotion, Shri Vinay Kumar Trivedi, Deputy Chief Labour Commissioner

(Central), Asansol will be posted as Deputy Director General (Hq), O/o DG(LW).
Jaisalmer House, New Delhi.

3.

The concerned organization is requested to relieve the above mentioned officer

to enable him to join his new place of posting. The officer concerned is also directed to
submit his joining report to this Ministry through the respective organization of his
posting at the earliest.
4.

This issues with the approval of the Competent Authority.

(Dhananjay Sharma)
Under Secretary to the Govt. of India
Tel: 011-23711582

Copy to:

1. Shri Vinay Kumar Trivedi, Deputy Chief Labour Commissioner (Central),
Asansol

2. PS to Hon'ble Minister for Labour & Employment/ PS to Hon'ble Minister
of State for Labour & Employment
3. PPS to Secretary, L&E/ PSO to AS, L&E/ Sr. PPS to AS&DGLW(KKS)
PPSto DG(Stats.)/ PSO to SLEA

4. PPS to JS(DK) PS to JS&FA/ PS to JS(AM) PPS to JS(RKT)) PA to
JS(MK) PPS to DDG(Emp)/ PA toDDG(NKS)) Sr. PPS to EA(SD)

5. Admin-I section,Olo Chief Labour Commissioner (Central), Shramev Jayate
Bhawan, G4, Sector 10, Dwarka, New Delhi

6. Admin-I section, Ministry of Labour &Employment

7. Directorate General (Labour Welfare), Jaisalmer House, New Delhi
8. CLS (Vig) Section/ Vigilance section (MS), MoL&E, New Delhi
9. DoP&T [Kind Attention: Shri Ramesh Chandra Jha, Under Secretary, EO

SM.II| - for information with reference to Order No. 3//2023-EO(SM.II)
dated 24.01.2024

10.Office Order Folder/ Personal file of the Officer concerned
