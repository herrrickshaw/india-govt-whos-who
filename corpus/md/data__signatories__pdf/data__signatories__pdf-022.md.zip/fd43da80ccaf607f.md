---
doc_id: "fd43da80ccaf607f"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/9017ad1042405caada990295bbbda50c.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum - RFP for Hiring of Consulting Agency for Project Management Unit for UNNATI, 2024, Dated 15th March, 2024"
date: "2025-07-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bade383c7658b12a"
---

<!-- page 1 -->

P-44026/14/2024-DBA-I
P-44026/14/2024-DBA-III
Government of India
Ministry of Commerce and Industry
Department for Promotion of Industry and Internal Trade
(NERS Division)
****
****

CORRIGENDUM
CORRIGENDUM

Udyog Bhawan
Bhawan
th
Dated 13
1 3 June, 2024

Subject:- RFP
RFP for
for Hiring
Hiring of
of Consulting
Consulting Agency
Agency for
for Project
Project Management
Management Unit
Unit for
for
Subject:UNNATI,
UNNATI, 2024,
2024, Dated
Dated 15th
15th March,
March, 2024
2024
27 May, 2024 on the subject
In
In continuation of this Department's Corrigendum dated 2?1h
in the table below.
below.
mentioned above, the changes are made as indicated in
S.No Proposal due date as per
corrigendum dated 2?1h
27� May,
2024
� June, 2024
1
1
03 rd
03

Extension/ Last date for submission

th June,
Two-week extension
extension (Last Date 17
17
2024)

t9f)?',, Jr

3»mt ♦
J,/

e/et #
-w~f.A.t

(Ganesh H. Nikhare)
Under Secretary to the Govt.
Govt.of India
Tel: 011-2306 2122
