---
doc_id: "ff1f0de71a31cd8f"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/497c672ec66d81709037de5282b578bc.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "mtnl sr"
date: "2017-02-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6dc8eefb523a8552"
---

<!-- page 1 -->

No. 11-03/2014-Estates(Pt.II)
Government of India
Ministry of Comm unications(Sanchar Mantralaya)
Department of Telecommunications(Sanchar Vibhag)

New Delhi-1, the 61h February, 2017
OFFICE MEMORANDUM
Subject:

Guidelines for retention of BSNL/MTNL Staff Quarters to DoT employees in the
event of transfer/repatriation/deputation/training etc.

In continuation of O.M. of even number dated 17.01.2017 on the subject mentioned above, the
undersigned is directed to say that the said guidelines will be applicable for the Staff Quarters
occupied by DoT Officers in Delhi only.

/Ltt-tf:ir~,7

(Budh RataD)
Under Secretary to the Government of India
Tel.23711239
To,
I.

The Chairman --<:um-Managing Director,

Bharat Sanchar Nigam Ltd.
Bharat Sanchar Bhawan,
Dr. Harish Chand Mathur Lane,
Jan path,
New Delhi-11000 I
2. The Chairman-cum-Managing Director,
Mahanagar Telephone Nigarn Ltd.
Mahanagar Doorsanchar Sadan,
5th Floor, 9, C.G.O. Complex,
Lodhi Road,New Delhi- I I 0003
Copy to:
I. Sr. PPS to Secretary(T)
2. Sr. PPS to Member(S)/Member(T)/Member(F)/Pre. Eco Advisor, DoT
3. PPS to Additional Secretary(T), DoT
4. Sr. PPS to Wireless Advisor, DoT
5. PPS to Administrator (USOF), DoT
6. Sr. DDG(TERM), Sr. DDQ(TEC), CVO, .JS(A), JS(T), DDG(Estt.), DDG(E&F), DDG(C&A)
ar, TDS~
/
7. CMD, BBJl:lLI CMD, TCIL/ CMD, ITI/ Executive Director, C-DoT/ The R~gis
Secretary(TRAI)
.
8. IT Wing for the uploading the OM on website.
-;;J,j/ ~
(Budh Ratan) .. -1 I '/ )
