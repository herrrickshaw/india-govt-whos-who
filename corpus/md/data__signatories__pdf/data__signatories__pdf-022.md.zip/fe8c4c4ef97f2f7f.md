---
doc_id: "fe8c4c4ef97f2f7f"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/57c14993d75319232a53e52bacd71f4a.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Guidelines for Indian Students seeking graduate medical qualifications (MBBS or equivalent) from foreign Countries"
date: "2025-12-03"
pages: 54
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3d0fba17376a3dbc"
---

<!-- page 1 -->

GUIDELINES FOR INDIAN STUDENTS SEEKING GRADUATE
MEDICAL QUALIFICATIONS (MBBS or equivalent)
FROM FOREIGN COUNTRIES
1.

It is open to Indian students to seek medical qualification from any
recognized medical education institution in a foreign country.

2.

Such students in order to practice in India after completion of medical
education are required to register with a State Medical Council (SMC).

3.

SMC can register a student with foreign medical qualification only after
he appears and passes in the Foreign Medical Graduate Examination
(FMGE) conducted by the National Board of Examination (NBE). This is
a statutory requirement as per section 13(4A) of the IMC Act, 1956
amended in 2002. Details regarding FMGE may be seen at the website :
www.natboard.edu.in
It is provided that a person seeking provisional or permanent registration
shall not have to qualify the Screening Test if he/she holds an under
graduate medical qualification from Australia/ Canada/ New
Zealand/United Kingdom/United States of America and the holder
thereof has also been awarded a post graduate medical qualification in
Australia/ Canada/ New Zealand/United Kingdom/United States of
America and has been recognized for enrolment as medical practitioner in
that country.

4.

In order to appear at the FMGE, a candidate must have obtained
Eligibility Certificate (EC) from the MCI before taking admission to
medical course in a foreign institution. This is as per Section 13(4B) of
the Indian Medical Council Act, 1956. Please visit website
www.mciindia.org to see details.

5.

The candidates are issued EC by the MCI subject to fulfillment of
criteria laid down under Section 4 and Section 5 of the “Medical Council
of India Regulation on Graduate Medical Education, 1997”. Since the
criteria for selection are defined in the Regulation, it is mandatory to
follow these criteria. Please visit website www.mciindia.org to see
details.

<!-- page 2 -->

6.

It is also brought to the notice of all candidates that as per directions of
Hon’ble Supreme Court of India dated 17.12.2013 in SLP
No.36956/2013, all candidates taking admission in medical courses in
foreign countries after 16.04.2010 are required to pass out from the same
institution.

7.

The Screening Test is conducted twice a year in June and December by
NBE as a computer based test. The country and college wise details of
pass percentage of students are given at Annexure as complied by NBE.
A large number of candidates graduating from foreign Medical
Institutions are waiting to clear FMGE to obtain Registration Certificate
to practice medicine. The students are advised to exercise due discretion
in selecting foreign institutions and countries considering the quality of
medical education imparted there vis-à-vis the requirements of clearing
FMGE.
Candidates are advised to check the medium of medical education in
college the candidate proposes to take admission and also the monthly
living expenses / availability of hostel facility etc. before taking
admission.

8.

Foreign medical universities/institutions are advised to make selection of
Indian candidates to their medical courses themselves and not through
travel agents. They should ensure compliance with necessary
qualifications prescribed under Indian regulations viz. Section 4
“Graduate Medical Education Regulations, 1997”.
They must take note of selection procedure prescribed under Section 5 of
“Graduate Medical Education Regulations, 1997” regarding admission of
students in medical courses in India.
Foreign medical institutions are strongly advised to give inter se
preference to Indian students who have scored higher marks in
competitive examination in India like All India Pre- Medical Test
(AIPMT). (obtaining 50% marks in Physics, Chemistry and Biology
(PCB) subjects at qualifying examination is the minimum).

<!-- page 3 -->

The foreign medical institutions must ensure the quality of Indian
students being admitted to their courses. The performance of their Indian
students in the Screening Exam in India (FMGE) would reflect on the
standard of medical education in the concerned institution and, in cases of
continuous poor performance in FMGE, it may lead to withdrawal of
permission of MCI for the institution in the interest of Indian students.
9.

Candidates must ensure that they have been given full and correct
information by the College/ University/ Selection Agency about tuition &
other fee, facilities, curriculum of the course, language of instruction/
teaching, availability of hostel facilities, monthly living expenses etc.
MCI may consider obtaining undertaking from the candidates in this
regard. A copy of the Indian MBBS curriculum as per Graduate Medical
Regulation may be provided to the candidates at the time of issuance of
Eligibility Certificate so that they can refer the same in the context of
their training at overseas medical institutions.

10.

Medical Institutions abroad which are admitting Indian students must
particularly visit the website of MCI for the following information:
i. MBBS curriculum followed in India.
ii. Statutory requirements for Medical Colleges in India in terms of
faculty, infrastructure etc. for obtaining various approvals of
Government.
iii. Clinical competencies at UG level.

11.

The foreign medical institutions must pay particular attention to the
medium of imparting education to Indian students, preferably in English,
and also sufficient exposure to clinical material by removing restrictions,
if any, on access to local patients for Indian Medical students.

12.

The Indian Missions abroad must assess the local medical institutions and
attendant regulations in those countries in consultation with the
Government of India to help guide Indian students seeking admissions in
medical courses there. Counsellor access must be available to Indian
students abroad to resolve various issues pertaining to their medical
education.
*****

<!-- page 4 -->

<!-- page 5 -->

Performance of Candidates
In
Screening test conducted by NBE

National Board of Examinations
New Delhi

<!-- page 6 -->

Contents
S.No

Index

Page No.

I

Introduction

3

II.

Russia & Commonwealth of Independent States

4 - 18

III

Rest of the world

19 - 50

2

<!-- page 7 -->

Introduction
National Board of Examinations has been conducting computerised based
Foreign Medical Graduate Examination (FMGE) screening test in June &
December every year. It has been introduced through screening test
regulations 2002. As per the regulations, “An Indian citizen/Overseas citizen
of India possessing a primary medical qualification awarded by any medical
institution outside India who is desirous of getting provisional or
permanent registration with the Medical Council of India or any State
Medical Council on or after 15.03.2002 shall have to qualify a screening test
conducted by the prescribed authority for that purpose as per the provisions
of section 13 of the Act.”

Foreign Medical Graduate Examination (FMGE) is a licensure exam, which
aims to sift the charlatans from those, who have acquired their medical
degrees from another country, but are knowledgeable and skilled enough to
bloster the country’s physician workforce. It is an exercise in transparency,
with a well defined curriculum, which specifies the distribution and
weightage of each subject, has no negative marking, and no limit on the
number of attempts.

National Board of Examinations has prepared ranking of institutions based
on performance of various candidates who had appeared under two
categories.
Group I – Russia & Commonwealth of Independent States
Group II - Rest of the world

3

<!-- page 8 -->

GROUP - I – RUSSIA & COMMONWEALTH OF INDEPENDENT STATES
Country

RUSSIA FEDERATION

Period of Review

2012-2014

Number of Colleges

34

Country Performance

Appeared

Passed

Pass %

5950

1094

18.4

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
RANK

INSTITUTE/UNIVERSITY NAME

APPEARED

PASS

PASS %

1

KYRGYZ RUSSIAN SLAVIC UNIVERSITY

1

1

100

2

CRIMEA STATE MEDICAL UNIVERSITY

31

12

38.7

3

SMOLENSK STATE MEDICAL ACADEMY

759

239

31.5

8

2

25

4

1

25

255

62

24.3

270

63

23.3

146

31

21.2

10

2

20

195

39

20

859

155

18

56

10

17.9

202

36

17.8

653

116

17.7

678

115

16.9

4
5
6
7
8
9
10
11
12
13
14
15

I P PAVLOV STATE MEDICAL
UNIVERSITY
KABARDINO BALKARIAN STATE
UNIVERSITY
RYAZAN STATE IP PAVLOV MEDICAL
UNIVERSITY
DAGESTAN STATE MEDICAL ACADEMY
NORTHERN STATE MEDICAL
UNIVERSITY
YAROSLAVL STATE MEDICAL
ACADEMY
SARATOV STATE MEDICAL
UNIVERSITY
STAVROPOL STATE MEDICAL
ACADEMY RUSSIA
PEOPLES FRIENDSHIP UNIVERSITY OF
RUSSIA
KURSK STATE MEDICAL UNIVERSITY
SAINT PETERSBURG STATE MEDICAL
ACADEMY
TVER STATE MEDICAL ACADEMY

4

<!-- page 9 -->

16
17
18

BASHKIRIAN STATE MEDICAL
UNIVERSITY
VOLGOGRAD STATE MEDICAL
UNIVERSITY
ASTRAKHAN STATE MEDICAL
ACADEMY

20

3

15

475

70

14.7

15

2

13.3

19

KUBAN STATE MEDICAL UNIVERSITY

151

20

13.2

20

KAZAN STATE MEDICAL UNIVERSITY

138

18

13

149

19

12.8

152

18

11.8

21
22

VORONEZH STATE MEDICAL
ACADEMY
I M SECHENOV MOSCOW MEDICAL
ACADEMY

23

ROSTOV STATE MEDICAL UNIVERSITY

397

45

11.3

24

IRKUTSK STATE MEDICAL UNIVERSITY

18

2

11.1

98

7

7.1

25

NORTH WEST STATE MEDICAL
UNIVERSITY

26

RUSSIAN STATE MEDICAL UNIVERSITY

128

5

3.9

27

SAMARA STATE MEDICAL UNIVERSITY

70

1

1.4

1

0

0

4

0

0

2

0

0

2

0

0

1

0

0

1

0

0

28
29
30
31
32
33

LOMONOSOV MOSCOW STATE
UNIVERSITY
MOSCOW MEDICAL STOMATOLOGICAL
INSTITUTE
NIZHNY NOVGOROD STATE MEDICAL
ACADEMY
RAZAN STATE MEDICAL UNIVERSITY
RUSSIAN FEDERATION
ULYANOVSK STATE UNIVERSITY

VORONEZH STATE MEDICAL
UNIVERSITY

5

<!-- page 10 -->

Country

ARMENIA

Period of Review

2012-2014

Number of Colleges

3

Country Performance

Appeared

Passed

Pass %

527

95

18

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University name

Appeared

Pass

Pass
%

1

YEREVAN STATE MEDICAL UNIVERSITY

524

95

18.1

2

HAYBUSAK UNIVERSITY OF YEREVAN

1

0

0

3

ST. THERESA’S MEDICAL UNIVERSITY

2

0

0

6

<!-- page 11 -->

Country

REPUBLIC OF AZERBAIJAN

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

106

21

19.8

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
KHAZAR UNIVERSITY

7

Appeared

Pass

Pass
%

106

21

19.8

<!-- page 12 -->

Country

REPUBLIC OF BELARUS

Period of Review

2012-2014

Number of Colleges

5

Country Performance

Appeared

Passed

Pass %

253

57

21

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University Name

Appeared

Pass

Pass
%

1

VITEBSK MEDICAL UNIVERSITY

122

32

26.2

2

GOMEL STATE MEDICAL UNIVERSITY

78

16

20.5

3

GRODNO STATE MEDICAL UNIVERSITY

33

6

18.2

4

BELARUS STATE MEDICAL UNIVERSITY

20

3

15.0

8

<!-- page 13 -->

Country

GEORGIA

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

157

40

25.5

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
TBILISI STATE MEDICAL UNIVERSITY

9

Appeared

Pass

Pass %

157

40

25.5

<!-- page 14 -->

Country

KAZAKHSTAN

Period of Review

2012-2014

Number of Colleges

3

Country Performance

Appeared

Passed

Pass %

858

178

20.7

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University Name

Appeared

Pass

Pass %

1

SEMEY STATE MEDICAL UNIVERSITY

38

9

23.7

2

KARAGANDA STATE MEDICAL UNIVERSITY

160

35

21.9

3

KAZAKH NATIONAL MEDICAL UNIVERSITY

660

134

20.3

10

<!-- page 15 -->

Country

KYRGYZSTAN

Period of Review

2012-2014

Number of Colleges

4

Country Performance

Appeared

Passed

Pass %

570

105

18.4

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University Name

Appeared

Pass

Pass %

1

KYRGYZ STATE MEDICAL ACADEMY

90

24

26.6

2

KYRGYZ INTERNATIONAL HIGH SCHOOL
OF MEDICINE

219

51

23.2

3

OSH STATE MEDICAL UNIVERSITY

251

30

11.9

4

INTERNATIONAL UNIVERSITY OF
KYRGYSTAN

10

0

0.0

11

<!-- page 16 -->

Country

REPUBLIC OF MOLDOVA

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

5

2

40

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
NICOLAE TESTEMITANU STATE
UNIVERSITY OF MEDICINE AND
PHARMACY.

12

Appeared

Pass

Pass %

5

2

40

<!-- page 17 -->

Country

REPUBLIC OF LATVIA

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

4

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
UNIVERSITY OF LATVIA, FACULTY OF
MEDICINE

13

Appeared

Pass

Pass %

4

0

0

<!-- page 18 -->

Country

LITHUANIA

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

3

1

33.3

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
LITHUANIAN UNIVERSITY OF HEALTH
SCIENCES, FACULTY OF MEDICINE

14

Appeared

Pass

Pass %

3

1

33.3

<!-- page 19 -->

Country

TAJAKISTAN

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

485

92

18.9

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
TAJIK STATE MEDICAL UNIVERSITY

15

Appeared

Pass

Pass %

485

92

18.9

<!-- page 20 -->

Country

UKRAINE

Period of Review

2012-2014

Number of Colleges

18

Country Performance

Appeared

Passed

Pass %

3520

671

19.1

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University Name

Appeared

Pass

Pass %

1

V.N.KARAZIN KHARKIV NATIONAL UNIVERSITY

1

1

100.0

2

UKRAINIAN MEDICAL STOMATOLOGICAL
ACADEMY

2

1

50.0

3

BUKOVINIAN STATE MEDICAL UNIVERSITY

277

85

30.6

4

DANYLO HALYTSKY LVIV NATIONAL MEDICAL
UNIVERSITY

42

10

23.8

5

VINNITSA STATE MEDICAL UNIVERSITY

22

5

22.7

6

DONETSK NATIONAL MEDICAL UNIVERSITY

24

5

20.8

7

LUGANSK STATE MEDICAL UNIVERSITY

1268

260

20.5

8

ZAPOROZHYE STATE MEDICAL UNIVERSITY

713

139

19.5

9

DNEPROPETROVSK STATE MEDICAL ACADEMY

60

10

16.7

10

BOGOMOLETS NATIONAL MEDICAL UNIVERSITY

13

2

15.3

11

ODESSA NATIONAL MEDICAL UNIVERSITY

467

71

15.2

12

IVANO FRANKIVSK NATIONAL MEDICAL
UNIVERSITY

20

3

15.0

13

CRIMEA STATE MEDICAL UNIVERSITY

159

23

14.4

14

NATIONAL PIROGOV MEMORIAL MEDICAL
UNIVERSITY

120

16

13.3

15

TERNOPIL STATE MEDICAL UNIVERSITY

135

17

12.6

16

KHARKOV NATIONAL MEDICAL UNIVERSITY

168

20

11.9

17

DONETSK NATIONAL MEDICAL UNIVERSITY

19

2

10.5

18

SUMY STATE UNIVERSITY

10

1

10.0

16

<!-- page 21 -->

17

<!-- page 22 -->

Country

UZBEKISTAN

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

2

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name
TASHKENT MEDICAL ACADEMY

18

Appeared

Pass

Pass %

2

0

0

<!-- page 23 -->

Group II - Rest of the world
Country

BANGLADESH

Period of Review

2012-2014

Number of Colleges

22

Country Performance

Appeared

Passed

Pass %

626

193

30.83

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank Institute/University Name
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22

Appeared

UNIVERSITY OF DHAKA
BANGLADESH MEDICAL COLLEGE (BMSRI)
SIR SALIMULLAH MEDICAL COLLEGE
IBRAHIM MEDICAL COLLEGE
KUMUDINI WOMEN'S MEDICAL COLLAGE
AND HOSPITAL
DHAKA NATIONAL MEDICAL COLLEGE
COMMUNITY BASED MEDICAL COLLEGE
BANGLADESH
ZAINUL HAQUE SIKDER WOMEN'S
MEDICAL COLLEGE AND HOSPITAL (PVT)
LTD
SHAHEED SUHRAWARDY MEDICAL
COLLEGE AND HOSPITAL
JAHURUL ISLAM MEDICAL COLLEGE AND
HOSPITAL
RAJSHAHI MEDICAL COLLEGE
MEDICAL COLLEGE FOR WOMEN AND
HOSPITAL
MYMENSINGH MEDICAL COLLEGE
SHER-E-BANGLA MEDICAL COLLEGE
HOLY FAMILY RED CRESCENT MEDICAL
COLLEGE
UNIVERSITY OF SCIENCE AND
TECHNOLOGY, CHITTAGONG
JALALABAD RAGIB-RABEYA MEDICAL
COLLEGE
CHITTAGONG MEDICAL COLLEGE
RANGPUR MEDICAL COLLEGE
DHAKA MEDICAL COLLEGE
FARIDPUR MEDICAL COLLEGE
TAIRUNNESSA MEMORIAL MEDICAL
COLLEGE
19

Pass

Pass %

1
5
12
4

1
4
7
2

100.0
80.0
58.3
50.0

15

7

46.6

56

26

46.4

21

9

42.9

7

3

42.9

12

5

41.7

80

31

38.7

32

11

34.4

52

17

32.7

52
4

16
1

30.8
25.0

37

9

24.3

163

33

20.2

10

2

20.0

11
6
42
3

2
1
6
0

18.2
16.7
14.3
0.00

1

0

0.00

<!-- page 24 -->

Country

BELIZE

Period of Review

2012-2014

Number of Colleges

5

Country Performance

Appeared

Passed

Pass %

77

9

11.6

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Ran
k
1
2
3

Institute/University Name
CENTRAL AMERICA HEALTH SCIENCES
UNIVERSITY
BELIZE MEDICAL COLLEGE
CAHSU BELIZE MEDICAL COLLEGE RELIZE CITY
DELIZE

20

Ap
p

Pas
s

Pass
%

75

9

12.0

1

0

0.0

1

0

0.0

<!-- page 25 -->

Country

BULGARIA

Period of Review

2012-2014

Number of Colleges

6

Country Performance

Appeared

Passed

Pass %

90

11

12.22

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

4
5

Institute/University Name
MEDICAL UNIVERSITY - PLEVEN
IP PAVLOV HIGHER MEDICAL INSTITUTE
PLOVDIV
MEDICAL UNIVERSITY-SOFIA
HIGHER INSTITUTE OF DENTISTRY AND
MEDICINE PLOVDIV
MEDICAL UNIVERSITY - PLOVDIV

6

THRACIAN MEDICAL UNIVERSITY

2
3

21

App
32

Pass
6

Pass %
18.8

7
10

1
1

14.3
10.0

11
29

1
2

9.1
6.9

1

0

0.0

<!-- page 26 -->

Country

PEOPLE'S REPUBLIC OF CHINA

Period of Review

2012-2014

Number of Colleges

87

Country Performance

Appeared

Passed

Pass %

11825

2239

18.9

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32

Institute/University Name
CHENYANG MEDICAL COLLEGE, PR CHINA
COLLEGE OF THE LEFT SIDE OF CHINA
GUANGZHOU CHINA
SHEJIANG UNIVERSITY,SCHOOL OF MEDICINE
WEIFANG MEDICAL COLLEGE, CHINA
ZHENGZHOU UNIVERSITY
WUHAN UNIVERSITY CHINA
WEST CHINA UNIVERSITY OF MEDICAL SCIENCE
SHENYANG MEDICAL COLLEGE
COLLEGE OF PEOPLE'S REPUBLIC OF CHINA
HEBEI NORTH UNIVERSITY
QIQIHAR MEDICAL UNIVERSITY
ZHEJIANG UNIVERSITY
GANNAN MEDICAL UNIVERSITY
WEIFANG MEDICAL COLLEGE
SOUTHERN MEDICAL UNIVERSITY
SUZHOU MEDICAL COLLEGE
XINJIANG MEDICINE UNIVERSITY
CAPITAL MEDICAL UNIVERSITY
QINGDAO UNIVERSITY
WEST CHINA SCHOOL OF MEDICAL SCIENCE
(SICHUAN UNIVERSITY)
WUHAN UNIVERSITY
HEBEI MEDICAL UNIVERSITY
FIRST MILITARY MEDICAL UNIVERSITY
LUZHOU MEDICAL COLLEGE
NANTONG UNIVERSITY
SOUTHEAST UNIVERSITY
NANJING MEDICAL UNIVERSITY
CHINA MEDICAL UNIVERSITY
NINGXIA MEDICAL COLLEGE
TONGJI MEDICAL COLLEGE OF HOST,P.R CHINA
JINAN UNIVERSITY
22

App
1
1
2
2
14
786
85
27
239
175
153
49
156
79
92
414
117
169
78
197

Pass
1
1
1
1
7
290
30
9
73
50
42
13
40
20
23
102
28
40
18
45

Pass %
100.00
100.00
50.00
50.00
50.00
36.90
35.29
33.33
30.54
28.57
27.45
26.53
25.64
25.32
25.00
24.64
23.93
23.67
23.08
22.84

101

23

22.77

453
184
54
194
278
282
215
207
176
5
78

102
41
12
43
61
61
46
43
36
1
15

22.52
22.28
22.22
22.16
21.94
21.63
21.40
20.77
20.45
20.00
19.23

<!-- page 27 -->

33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73

NORMAN BETHUNE COLLEGE OF MEDICINE
TIANJIN MEDICAL UNIVERSITY
TAISHAN MEDICAL UNIVERSITY
CHONGQING UNIVERSITY OF MEDICAL
SCIENCES
BETHUNE MEDICAL COLLEGE
FIRST AFFILIATED HOSPITAL OF ZHENGZHOU
GUANGXI MEDICAL UNIVERSITY CHINA
NANCHANG UNIVERSITY
SOOCHOW UNIVERSITY
JILIN UNIVERSITY
NORTH SICHUAN MEDICAL COLLEGE
DALI UNIVERSITY
XI'AN JIAOTONG UNIVERSITY
GUANGXI MEDICAL UNIVERSITY
HAINAN MEDICAL COLLEGE
JINZHOU MEDICAL COLLEGE
HUAZHONG UNIVERSITY OF SCIENCE AND
TECHNOLOGY
DALIAN MEDICAL UNIVERSITY
YANGZHOU UNIVERSITY
XIAMEN UNIVERSITY
JIAMUSI MEDICAL UNIVERSITY
GANNAN MEDICAL UNIVERSITY
BEI HUA UNIVERSITY
CHINA (SOUTH EAST UNIVERSITY)
JING GANGSHAN MEDICAL SCHOOL
JIUJIANG UNIVERSITY
WENZHOU MEDICAL COLLGE
YICHUN UNIVESITY
CHINA THREE GORGES UNIVERSITY
JIANGSU UNIVERSITY
LIAONING MEDICAL UNIVERSITY
HAINAN MEDICAL COLLEGE CHINA
SICHUAN UNIVERSITY
SUN YAT-SEN UNIVERSITY
TONGJI UNIVERSITY
JINGGANGSHAN UNIVERSITY MEDICAL SCHOOL
JIANGXI COLLEGE OF TRADITIONAL CHINESE
MEDICINE
JIAMUSI UNIVERSITY
HUANGHE SCEINCE AND TECHNOLOGY
COLLEGE
HUBEI COLLEGE OF TRADITIONAL CHINESE
MEDICINE
AFFILIATED HOSPITAL OF LUZHOU LUZHOU
23

159
276
272

30
51
50

18.87
18.48
18.38

736

127

17.26

53
6
72
136
762
130
52
762
82
96
21
14

9
1
12
22
120
20
8
114
12
14
3
2

16.98
16.67
16.67
16.18
15.75
15.38
15.38
14.96
14.63
14.58
14.29
14.29

58

8

13.79

264
120
101
94
174
32
32
42
135
145
253
299
107
125
9
239
125
48
101

36
16
13
12
22
4
4
5
16
17
29
34
12
14
1
25
13
4
8

13.64
13.33
12.87
12.77
12.64
12.50
12.50
11.90
11.85
11.72
11.46
11.37
11.21
11.20
11.11
10.46
10.40
8.33
7.92

147

11

7.48

217

16

7.37

38

2

5.26

129

4

3.10

3

0

0.00

<!-- page 28 -->

74
75
76
77
78
79
80
81
82
83
84
85
86
87

MEDICAL COLLEGE
BALIAN MEDICAL UNIVERSITY CHINA
BIRGDAO UNIVERSITY CHINA
COLLEGE OF INTERNATIONAL STUDENTS
SOUTHEAST UNIVERSITY PR CHINA
CQUMS CHINA
DAHAN MEDICAL UNIVERSITY
HARBIN MEDICAL UNIVERSITY
GXMU NANNNING CHINA
HARBIN MEDICAL UNIVERSITY
HAYBUSAK MEDICAL UNIVERSITY
INTERNATIONAL SCHOOL OF ZHENGZHOU
UNIVERSITY
HUEM CITY WUHAM CHINA
SHANDONG UNIVERSITY
XINXIANG MEDICAL COLLEGE
XUZHOU MEDICAL COLLEGE

24

1
2

0
0

0.00
0.00

1

0

0.00

1
1
36
1
4
2

0
0
0
0
0
0

0.00
0.00
0.00
0.00
0.00
0.00

2

0

0.00

2
11
28
4

0
0
0
0

0.00
0.00
0.00
0.00

<!-- page 29 -->

Country

CURACAO

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

17

6

35.3

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name

App

Pass

Pass %

AVALON UNIVERSITY SCHOOL OF
MEDICINE

17

6

35.3

25

<!-- page 30 -->

Country

CZECH REPUBLIC

Period of Review

2012-2014

Number of Colleges

2

Country Performance

Appeared

Passed

Pass %

2

1

50

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank
1

Institute/University Name

App

Pass

Pass %

CHARLES UNIVERSITY IN PRAGUE

2

1

50

26

<!-- page 31 -->

Country

DOMINICAN REPUBLIC

Period of Review

2012-2014

Number of Colleges

3

Country Performance

Appeared

Passed

Pass %

6

2

33.3

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank Institute/University Name

App

Pass

Pass %

1

ALL SAINTS UNIVERSITY SCHOOL OF
MEDICINE

1

1

100

2

ROSS UNIVERSITY

1

1

100

3

UNIVERSIDAD TECNOLOGICA DE SANTIAGO
(UTESA)

4

0

0

27

<!-- page 32 -->

Country

GERMANY

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

1

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name

App

Pass

Pass %

FRIEDRICH-ALEXANDER-UNIVERSITAET
ERLANGEN-NUERNBERG

1

0

0

28

<!-- page 33 -->

Country

ETHIOPIA

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

5

1

20

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1

Institute/University Name

App

Pass

Pass %

JIMMA UNIVERSITY ETHIOPIA

5

1

20

29

<!-- page 34 -->

Country

INDONESIA

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

1

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank

Institute/University Name

App

Pass

Pass %

1

UNIVERSITAS HAND TUAH

1

0

0

30

<!-- page 35 -->

Country

IRAN

Period of Review

2012-2014

Number of Colleges

2

Country Performance

Appeared

Passed

Pass %

5

2

40

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University Name

App

Pass

Pass %

1

SHAHID BEHESHTI UNIVERSITY OF MEDICAL
SCIENCES AND HEALTH SERVICES

4

2

50

2

TEHRAN UNIVERSITY OF MEDICAL SCIENCES.
SCHOOL OF MEDICINE

1

0

0

31

<!-- page 36 -->

Country

MALAYSIA

Period of Review

2012-2014

Number of Colleges

2

Country Performance

Appeared

Passed

Pass %

2

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank

Institute/University Name

App

Pass

Pass %

1

AIMST UNIVERSITY. FACULTY OF MEDICINE

1

0

0

2

INTERNATIONAL MEDICAL UNIVERSITY

1

0

0

32

<!-- page 37 -->

Country

MAURITIUS

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

48

31

64.6

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank
1

Institute/University Name

App

Pass

Pass %

SIR SEEWOOSAGAR RAMGOOLAM
MEDICAL COLLEGE

48

31

64.6

33

<!-- page 38 -->

Country

HUNGARY

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

1

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank
1

Institute/University Name

App

Pass

Pass %

UNIVERSITY OF DEBRECEN
(DEBRECENI EGYETEM)

1

1

100

34

<!-- page 39 -->

Country

Nepal

Period of Review

2012-2014

Number of Colleges

14

Country Performance

Appeared

Passed

Pass %

3163

670

21.2

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3
4
5
6
7
8
9
10
11
12
13
14

Institute/University Name
NOBEL MEDICAL COLLEGE BIRATNAGAR
NEPAL
B.P. KOIRALA INSTITUTE OF HEALTH SCIENCES
MANIPAL COLLEGE OF MEDICAL SCIENCES
TRIBHUVAN UNIVERSITY
NEPALGUNJ MEDICAL COLLEGE
JANAKI MEDICAL COLLEGE NEPAL
UNIVERSAL COLLEGE OF MEDICAL SCIENCES,
BHAIRAHAWI
COLLEGE OF MEDICAL SCIENCES-NEPAL
NEPAL MEDICAL COLLEGE PVT. LTD.
KATHMANDU MEDICAL COLLEGE (PVT.) LTD.
NATIONAL MEDICAL COLLEGE
KATHMANDU UNIVERSITY, SCHOOL OF
MEDICAL SCIENCES
MAHARAJGUNJ KATHMANDU
LUMBINI MEDICAL COLLEGE AND TEACHING
HOSPITAL (KATHMANDU UNIVERSITY)

35

App

Pass

Pass %

25
116
403
640
425
155

8
36
106
156
93
33

32.0
31.0
26.3
24.4
21.9
21.3

319
591
35
189
234

61
109
6
29
31

19.1
18.4
17.1
15.3
13.3

29
1

2
0

6.9
0.0

1

0

0.0

<!-- page 40 -->

Country

NETHERLANDS

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

27

11

40.7

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank
1

Institute/University Name

App

Pass

Pass %

XAVIER UNIVERSITY SCHOOL OF
MEDICINE

27

11

40.7

36

<!-- page 41 -->

Country

NIGERIA

Period of Review

2012-2014

Number of Colleges

2

Country Performance

Appeared

Passed

Pass %

2

0

0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Institute/University Name

App

Pass

Pass %

UNIVERSITY OF JOS

1

0

0

UNIVERSITY OF MAIDUGURI

1

0

0

37

<!-- page 42 -->

Country

PAKISTAN

Period of Review

2012-2014

Number of Colleges

15

Country Performance

Appeared

Passed

Pass %

49

16

32.7

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE

Rank Institute/University Name

App

Pass

Pass
%

1

KING EDWARD MEDICAL UNIVERSITY (KEMU)

2

2

100.0

2

PUNJAB MEDICAL COLLEGE FAISALABAD

1

1

100.0

3

RAWALPINDI MEDICAL COLLEGE PAKISTAN

1

1

100.0

4

QUAID-E-AZAM MEDICAL COLLEGE

1

1

100.0

5

PUNJAB MEDICAL COLLEGE

3

2

66.7

6

ALLAMA IQBAL MEDICAL COLLEGE

1

50.0

7

LIAQUAT UNIVERSITY OF MEDICAL AND HEALTH
SCIENCES, FACULTY OF MEDICINE AND ALLIED
SCIENCES

2
18

6

33.3

8

BOLAN MEDICAL COLLEGE

9

2

22.2

9

DOW UNIVERSITY OF HEALTH SCIENCES

6

0

0.0

10

FATIMA JINNAH MEDICAL COLLEGE FOR WOMEN

1

0

0.0

11

UNIVERSITY OF KARACHI

1

0

0.0

12

UNIVERSITY OF SIND

1

0

0.0

13

QUAID-E-AZAM MEDICAL COLLEGE

1

0

0.0

1

0

0.0

1

0

0.0

14

PEOPLE MEDICAL COLLEGE LIAQUAT
UNIVERSITY OF MED AND HEALTH SCIENCES
PAKISTAN

15

KARACHI UNIVERSITY

38

<!-- page 43 -->

Country

PHILIPPINES

Period of Review

2012-2014

Number of Colleges

12

Country Performance

Appeared

Passed

Pass %

431

106

24.6

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3
4
5
6
7
8
9
10
11
12

Institute/University Name
VIRGEN MILAGROSA UNIVERSITY
FOUNDATION
JFSM UPHR MANILA PHILIPPINES
SOUTHWESTERN UNIVERSITY-MATIAS H.
AZNAR MEMORIAL COLLEGE OF MEDICINE,
INC.
EMILIO AGUINALDO COLLEGE. SCHOOL OF
MEDICINE
CAGAYAN STATE UNIVERSITY
OUR LADY OF FATIMA UNIVERSITY,
COLLEGE OF MEDICINE
UNIVERSITY OF NORTHERN PHILIPPINES
DAVAO MEDICAL SCHOOL FOUNDATION,
INC., COLLEGE OF MEDICINE
JONELTA FOUNDATION SCHOOL OF
MEDICINE
ANGELES UNIVERSITY FOUNDATION
UNIVERSITY OF PERPETUAL HELP RIZAL JONELTA FOUNDATION SCHOOL OF
MEDICINE
SAINT LOUIS UNIVERSITY

39

App

Pass

Pass %

3
2

3
2

100.00
100.00

6

3

50.00

14
9

6
3

42.86
33.33

30
57

10
18

33.33
31.58

151

38

25.17

6
59

1
9

16.67
15.25

90
4

13
0

14.44
0.00

<!-- page 44 -->

Country

Poland

Period of Review

2012-2014

Number of Colleges

3

Country Performance

Appeared

Passed

Pass %

7

2

28.6

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3

Institute/University Name
MEDICAL UNIVERSITY OF SILESIA
KATOWICE
PLOVDIV MEDICAL UNIVERSITY
MEDICAL UNIVERSITY OF LUBLIN

40

App

Pass

2

1

4
1

1
0

Pass %
50
25
0

<!-- page 45 -->

Country

ROMANIA

Period of Review

2012-2014

Number of Colleges

12

Country Performance

Appeared

Passed

Pass %

125

14

11.2

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3
4
5
6
7
8
9
10
11
12

Institute/University Name
VICTOR BABES,UMFT
UNIVERSITATEA 'OVIDUS'
UNIVERSITATEA DE MEDICINA SI FARMACIE
UNIVERSITATEA DIN ORADEA
GR T POPA UNIVERSITY OF MEDICINE
TIMISOARA
UNIVERSITATEA DE MEDICINA SI FARMACIE
"VICTOR BABES" DIN TIMISOARA
UNIVERSITATEA DE MEDICINA SI FARMACIE
'CAROL DAVILA'
UNIVERSITATEA DE MEDICINA SI FARMACIE
'GRIGORE T. POPA'
UNIVERSITATEA DE MEDICINA SI FARMACIE
''VICTOR BABES '' DIN TIMISOARA
VICTOR BABES UNIVERSITY OF MEDICINE
VICTOR BABES UNIVERSITY OF MEDICINE AND
PHARMACY TIMISOARA

41

App
3
8
41
32
5
1

Pass
2
3
8
1
0
0

Pass %
66.67
37.50
19.51
3.13
0.00
0.00

3

0

0.00

5

0

0.00

3

0

0.00

9
11

0
0

0.00
0.00

4

0

0.00

<!-- page 46 -->

Country

SAINT KITTS AND NEVIS

Period of Review

2012-2014

Number of Colleges

5
Appeared

Country Performance

Passed

134

Pass %

13

9.70

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3
4
5

Institute/University Name
LITHUANIAN UNIVERSITY OF HEALTH
SCIENCES
INTERNATIONAL MEDICAL & TECHNOLOGICAL
UNIVERSITY
ST CHRISTOPHER AND NEVIS
WINDSOR UNIVERSITY SCHOOL OF MEDICINE
INTERNATIONAL UNIVERSITY OF HEALTH
SCIENCES (IUHS)

42

App

Pass

Pass %

1

1

100.0

6

1

16.7

8
22

1
2

12.5
9.1

97

8

8.3

<!-- page 47 -->

Country

SAINT LUCIA

Period of Review

2012-2014

Number of Colleges

3

Country Performance

Appeared

Passed

Pass %

56

16

28.6

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank

Institute/University Name
AMERICAN INTERNATIONAL MEDICAL
UNIVERSITY, AIM-U MEDVERSITY, SCHOOL OF
1 MEDICINE
2 ATLANTIC UNIVERSITY SCHOOL OF MEDICINE
3 SPARTAN HEALTH SCIENCES UNIVERSITY

43

App

Pass

Pass %

46

16

34.78

1
9

0
0

0.00
0.00

<!-- page 48 -->

Country

SEYCHELLES

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

6

2

33.3

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Institute/University Name
UNIVERSITY OF SEYCHELLES - AMERICAN
INSTITUTE OF MEDICINE

44

App

Pass

Pass %

6

2

33.3

<!-- page 49 -->

Country

SINGAPORE

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

3

1

33.3

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank Institute/University Name
1

NATIONAL UNIVERSITY OF SINGAPORE

45

App

Pass

Pass %

3

1

33.3

<!-- page 50 -->

Country

Sudan

Period of Review

2012-2014

Number of Colleges

1
Appeared

Country Performance

2

Passed
0

Pass %
0

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank Institute/University Name
1

AL ZAIEM AL AZHARI UNIVERSITY,
FACULTY OF MEDICINE

46

App

Pass

Pass %

2

0

0

<!-- page 51 -->

Country

TANZANIA

Period of Review

2012-2014

Number of Colleges

2

Country Performance

Appeared

Passed

Pass %

33

5

15.2

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2

Institute/University Name

App

Pass

Pass %

UNITED REPUBLIC OF TANZANIA COLLEGE

5

1

20.0

INTERNATIONAL MEDICAL AND
TECHNOLOGICAL UNIVERSITY. FACULTY OF
MEDICINE

28

4

14.3

47

<!-- page 52 -->

Country

UNITED ARAB EMIRATES

Period of Review

2012-2014

Number of Colleges

4

Country Performance

Appeared

Passed

Pass %

43

9

20.9

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Rank
1
2
3
4

Institute/University Name

App

Pass

Pass %

RAK COLLEGE OF MEDICAL SCIENCES

2

2

100.0

5

2

40.0

28

4

14.3

8

1

12.5

UNIVERSITY OF SHARJAH. COLLEGE OF
MEDICINE
GULF MEDICAL UNIVERSITY. COLLEGE OF
MEDICINE
DUBAI MEDICAL COLLEGE FOR GIRLS

48

<!-- page 53 -->

Country

United Kingdom

Period of Review

2012-2014

Number of Colleges

1

Country Performance

Appeared

Passed

Pass %

2

1

50

Ranking of Institutions based on performance of candidates in Screening
Test conducted by NBE
Institute/University Name

App

Pass

Pass %

UNIVERSITY OF EDINBURGH

2

1

50

49

<!-- page 54 -->

Country

OTHER COUNTRIES

Period of Review

2012-2014

Number of Colleges

Appeared

Country Performance

6707

50

Passed
1617

Pass %
24.1
