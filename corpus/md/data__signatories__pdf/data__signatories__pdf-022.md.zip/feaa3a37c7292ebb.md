---
doc_id: "feaa3a37c7292ebb"
source_url: "https://powermin.gov.in/static/uploads/2025/06/29f4c825733b11eb28a75630760bb2d0.pdf"
ministry: "Power"
title: "tender 9"
date: "2015-03-27"
pages: 35
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4e4194be77004de7"
---

<!-- page 1 -->

Annexure X – Format of Trust and Retention Account Agreement for SGPs
TRUST AND RETENTION ACCOUNT AGREEMENT
TRUST AND RETENTION ACCOUNT AGREEMENT (hereinafter referred to as this
“Agreement”) is entered into on this the ____________________________ day of
____________________________ (Month), 2016 at ____________________________
(Place).
BETWEEN:
M/S ___________________________ LIMITED, an existing company within the meaning
of the Companies Act, 2013 with CIN No.__________________________ and its
registered office at _______________________________ (hereinafter referred to as the
"Successful Bidder", which expression shall, unless it be repugnant to the subject or
context thereof, include its successors and permitted assigns) of the FIRST PART;
AND
M/S ___________________________ LIMITED, an existing company within the meaning
of the Companies Act, 2013 with CIN No.__________________________ and a banking
company within the meaning of Section 5 (c) of the Banking Regulation Act, 1949 (10 of
1949) and having its registered office at _______________________________ (the
"Account Bank", which expression shall, unless it be repugnant to the subject or
context thereof, include its successors, transferees and permitted assigns) of the
SECOND PART;
AND
M/S ___________________________ LIMITED, an existing company within the meaning
of the Companies Act, 2013 with CIN No.__________________________ and a banking
company within the meaning of Section 5 (c) of the Banking Regulation Act, 1949 (10 of
1949) and having its registered office at _______________________________ in its
capacity as the lenders’ agent for the Lenders (hereinafter referred to as the "Lenders’
Agent", which expression shall, unless it be repugnant to the subject or context thereof,
include its successors and permitted assigns) of the THIRD PART.
The Successful Bidder, the Account Bank and the Lenders’ Agent are individually referred
to as “Party” and collectively as “Parties”.
WHEREAS:
RECITALS
A.

Government of India (“GOI”) vide Office Memorandum No.4/2/2015-Th-I dated
27th March 2015 (“Office Memorandum”) has introduced the Scheme for

Successful Bidder

Account Bank
Page 1 of 35

Lenders’ Agent

<!-- page 2 -->

utilisation of Gas based power generation capacity for the financial years (AprilMarch) 2015-16 and 2016-17 (“Scheme”).
B.

The Scheme has envisaged provision of support from PSDF Fund (hereinafter
defined) in connection with supply of RLNG (hereinafter defined) to stranded gas
based plant (“SGP”) and the power plants receiving limited domestic gas
(“DGP”) selected through a reverse e-bidding process.

C.

Accordingly, the GOI invited bids from the SGPs under the Tender Document
bearing no [●]1 dated [●]2 for grant of support from PSDF Fund (“Tender
Document”). The Successful Bidder being the owner of a SGP i.e. the Power
Plant (hereinfter defined), submitted its bid in response to the Tender Document.

D.

Pursuant to the Tender Document and the bid submitted by the Successful
Bidder, the GOI through the Letter of Award dated [●] 3 bearing no. [●]4 (“Letter
of Award”) sanctioned support from the PSDF Fund upto the Sanctioned PSDF
Support Amount (hereinfter defined) for generation of the Total Incremental
Electricity (hereinfter defined) during the Relevant Period (hereinfter defined) by
the Successful Bidder at its Power Plant.

E.

The Successful Bidder has agreed to supply the Total Incremental Electricity to
the Discom(s) (hereinafter defined) under the PPA (hereinafter defined).

F.

As per the terms and conditions of the Tender Document, the Sanctioned PSDF
Support Amount will be transferred to the Discoms being the purchaser of the
Total Incremental Electricity. The Discoms are required to make payment of and
the Successful Bidder is required to collect the payment of the Gross Payment
(hereinafter defined) directly in the Trust and Retention Account (hereinafter
defined) of the Successful Bidder.

G.

Further, the Successful Bidder is required to utilise the money collected in the
Trust and Retention Account in accordance with the waterfall mechanism set out
in this Agreement.

H.

The Successful Bidder has availed loans (hereinafter collectively referred to as
the "Loans") from the lenders (the “Lenders”) for meeting the costs of setting
up and implementing the Power Plant, the details of which are set out under
Schedule – I. The Lenders’ Agent has been appointed by the Lenders to act as
the agent of the lenders under the Financing Documents (hereinafter defined).

Insert the number of the Tender Document.
Insert the date of the Tender Document.
3
Insert the date of the Letter of Award.
4
Insert the number of the Letter of Award.
1
2

Successful Bidder

Account Bank
Page 2 of 35

Lenders’ Agent

<!-- page 3 -->

I.

In view of the aforesaid, the Parties wish to enter into this Agreement for setting
out the terms and conditions to deal with all receipt and payments including the
Gross Payment in accordance with the requirements of the Tender Document.

NOW, THEREFORE, in consideration of the premises herein set forth and other good
and valid consideration, the receipt and adequacy of which are hereby expressly
acknowledged, the Parties hereby agree as follows:
1.

DEFINITIONS AND INTERPRETATION

1.1

Definitions
In this Agreement the following words and expressions shall, unless repugnant to
the context or meaning thereof, have the meaning hereafter respectively
assigned to them.
Account(s)

means the Trust and Retention Account and each of the
sub – accounts being the Revenue Account, the Statutory
Dues Account, the Fuel Cost Account, Operations and
Maintenance Expense Account, Interest Service Account,
Debt Repayment Account and the Surplus Account.

Affiliates

means in relation to any Person, a Person that controls, is
controlled by or is under the common control with such
party.

Applicable Law

means all applicable statutes, laws, by – laws, rules,
regulations,
orders,
ordinances,
protocols, codes,
guidelines, policies, notices, directions, judgments,
decrees or other requirements or official directive of any
governmental authority or court or other law, rule or
regulation, approval from the relevant governmental
authority, government resolution, directive, or other
government restriction or any similar form of decision of,
or determination by, or any interpretation or adjudication
having the force of law in India.

Appropriate
Commission

means the Central Electricity Regulatory Commission or
the State Electricity Regulatory Commission (as the case
may be) constituted under the Electricity Act, 2003 or
such other succeeding authority or commission as may be
notified by Government of India from time to time.

Successful Bidder

Account Bank
Page 3 of 35

Lenders’ Agent

<!-- page 4 -->

Business Day

means a day on which banks are normally open for
business in [●]5, India.

Debt Repayment
Account

means the sub – account so named established by the
Successful Bidder with the Account Bank and maintained
in accordance with Section 8.

Debt Repayment
Amount

means, in relation to the Relevant Period, the principal
amounts of the Loans which is due or payable to the
Lenders in accordance with the Financing Documents.

Discom(s)

means [●]6 being a distribution licensees holding licence
for distribution of electricity issued under Section 14 of the
Electricity Act, 2003 or under the acts set out in the
Schedule specified in Section 14 to the Electricity Act,
2003, to which the Successful Bidder is required to supply
the Total Incremental Electricity under the PPA.

E-bid RLNG

shall have the meaning as ascribed to it in the PSDF
Support Agreement.

E-bid
Operator

E-bid RLNG Sale
Agreement

means the E-bid RLNG Sale Agreement executed / to be
executed between the Successful Bidder and the E-Bid
RLNG Operator pursuant to the Tender Document for the
Relevant Period, as may be amended, supplemented or
modified from time to time.

Event of Default

means, collectively, the Event of Default and the Potential
Event of Default or such similar term as may be defined in
the Financing Documents.

Financing
Documents

means, collectively, any loan agreements, security
documents and any other financing documents entered
into inter alia between the Successful Bidder and the
Lenders in relation to the Loans.

Fuel
Account

5
6

RLNG means GAIL (India) Ltd.

Cost

means the sub – account so named established by the
Successful Bidder with the Account Bank and maintained
in accordance with Section 5.

Insert the place.
Insert the name of the Discom.

Successful Bidder

Account Bank
Page 4 of 35

Lenders’ Agent

<!-- page 5 -->

7
8

Fuel Cost

means all amounts, costs and expenses payable by the
Successful Bidder to the E-bid RLNG Operator under the
E-bid RLNG Sale Agreement and to the Gas Transporter
under the Gas Transportation Agreement.

Gas
Transportation
Agreement

means the gas transportation agreement executed / to be
executed between the Successful Bidder and the Gas
Transporter.

Gas Transporter

means [●]7 being the gas transporter for the E-bid RLNG.

Gross Payment

means all monies / revenues generated from the sale or
supply of the Incremental Electricity including the
amounts required to be paid by the Discoms to the
Sucessful Bidder under the PPA for purchase of
Incremental Electricity including the Sanctioned PSDF
Support Amount.

GOI

shall have the meaning as ascribed to it in Recital A.

Incremental
Electricity

shall have the meaning as ascribed to it in the PSDF
Support Agreement.

Interest Amount

means, in relation to the Relevant Period, the amount of
interest and default interest on the Loans, which is due or
payable to the Lenders in accordance with the Financing
Documents.

Interest
Account

means the sub – account so named established by the
Successful Bidder with the Account Bank and maintained
in accordance with Section 7.

Service

Letter of Award

shall have the meaning as ascribed to it in Recital D.

Monthly
Distribution
Date

means [•]8 of a month for the Relevant Period.

Office
Memorandum

shall have the meaning as ascribed to it in Recital A.

Operations
and
Maintenance

means the operation and maintenance expenses as
defined / provided for in the applicable regulations issued

Insert the name of the Gas Transporter.
Insert the day of the month for the Monthly Distribution Date..

Successful Bidder

Account Bank
Page 5 of 35

Lenders’ Agent

<!-- page 6 -->

Expenses

by the Appropriate Commission under the Electricity Act,
2003, which operation and maintenance expenses are
incurred / to be incurred by the Successful Bidder
proportionately for generation of the Incremental
Electricity during the Relevant Period.

Operations
and
Maintenance
Expense Account

means the sub – account so named established by the
Successful Bidder with the Account Bank and maintained
in accordance with Section 6.

Person

includes any company or association or individual or body
of individuals, whether incorporated or not.

PPA

means the power purchase agreement dated [●] 9
executed by the Successful Bidder with the Discom for
supply of the Total Incremental Electricity.

Power Plant

means [●]10 MW gas fired power plant of the Successful
Bidder located at [●]11.

Priority
Cashflow
Application

shall have the meaning as set forth in Section 3.1.2.

Proceedings

shall have the meaning as set forth in Section 23.

PSDF Fund

shall have the meaning as ascribed to it in the PSDF
Support Agreement.

PSDF
Support
Agreement

means the Power System Development Fund Support
Agreement to be entered into between the Successful
Bidder and the GOI in the form and format set out in
Annexure – XI of the Tender Document.

RLNG

means re – gasified liquefied natural gas.

Relevant Period

shall have the meaning as ascribed to it in the PSDF
Support Agreement.

Revenue
Account

means the sub – account so named established and
maintained by the Successful Bidder with the Account
Bank In accordance with Section 3.

Insert the date of the PPA.
The installed capacity of the Specified End Use Plant o be inserted as set out in Annexure – I of the Tender
Document.
11
Insert the address.
9

10

Successful Bidder

Account Bank
Page 6 of 35

Lenders’ Agent

<!-- page 7 -->

Sanctioned PSDF shall have the meaning as ascribed to it in the PSDF
Support Amount
Support Agreement.

1.2

Scheme

shall have the meaning as ascribed to it in Recital A.

Secured Parties

means collectively the Lenders and all other secured
parties under the Financing Documents.

Statutory Dues

means: (i) all Taxes and any other payment due and
payable for the Relevant Period, to any governmental
authority under any Applicable Law; and (ii) negative
amount of PSDF Support Amount payable by the
Successful Bidder to the Nodal Authority as per the PSDF
Support Agreement.

Statutory
Account

Dues

means the sub – account so named established and
maintained by the Successful Bidder with the Account
Bank in accordance with Section 4.

Surplus Account

means the sub – account so named established and
maintained by the Successful Bidder with the Account
Bank in accordance with Section 9.

Taxes

means any and all present and future taxes, including
without limitation, gross receipts, sales, turn-over, value
added, use consumption, property, income, franchise,
capital, occupational, license, excise, interest and
documentary stamps taxes, and customs and other duties,
assessments, or fees, however imposed, withheld, levied,
or assessed by any country or government subdivision
thereof or any other taxing authority.

Total
Incremental
Electricity

shall have the meaning as ascribed to it in the PSDF
Support Agreement.

TRA Default

shall have the meaning set forth in Section 13.

Trust
and shall have the meaning set forth in Section 2.1.
Retention
Account
Principles of Construction
In this Agreement, unless the context otherwise requires:

Successful Bidder

Account Bank
Page 7 of 35

Lenders’ Agent

<!-- page 8 -->

(a)

reference to an Account includes a reference to any sub – account of
that Account;

(b)

reference to an "amendment" includes a supplement, modification,
novation, replacement or re-enactment and "amended" is to be
construed accordingly;

(c)

a reference to “assets” include all properties whatsoever both present
and future, (whether tangible, intangible or otherwise) (including
intellectual property and intellectual property rights), investments, cashflows, revenues, rights, benefits, interests and title of every description;

(d)

a reference to "authorization" includes an authorization, consent,
clearance, approval, permission, resolution, license, exemption, filing and
registration;

(e)

a reference to "control" includes the power to direct the management
and policies of an entity, whether through the ownership of voting
capital, by contract or otherwise;

(f)

a reference to "encumbrance" includes a mortgage, charge, lien, pledge,
hypothecation, security interest or any lien of any description
whatsoever;

(g)

unless the context otherwise requires, the singular includes the plural
and vice versa;

(h)

headings and the use of bold typeface shall he ignored in its
construction;

(i)

a reference to a Section or Schedule is, unless indicated to the contrary,
a reference to a section or schedule to this Agreement;

(j)

references to this Agreement shall be construed as references also to any
separate or independent stipulation or agreement contained in it;

(k)

the words "other", "or otherwise" and "whatsoever" shall not be
construed ejusdem generis or be construed as any limitation upon the
generality of any preceding words or matters specifically referred to;

(l)

references to the word "includes" or "including" are to be construed
without limitation;

(m)

references to a person shall include such person's successors and
permitted assignees or transferees;

Successful Bidder

Account Bank
Page 8 of 35

Lenders’ Agent

<!-- page 9 -->

2.

(n)

all references to agreements, documents or other instruments include
(subject to all relevant approvals) a reference to that agreement,
document or instrument as amended, supplemented, substituted,
novated or assigned from time to time;

(o)

words importing a particular gender include all genders;

(p)

any reference to a public organization shall be deemed to include any
successor to such public organization or any organization or functions or
responsibilities of such public organization;

(q)

references to "Party" to this Agreement and references to “Parties” shall
be construed accordingly;

(r)

"year" "month" and "day" wherever used in this Agreement imply that of
English calendar;

(s)

references to any law shall include any constitution, statute, law, rule,
regulation, ordinance, judgment, order, decree, authorization, or any
published evidence, requirement or governmental restriction having the
force of law, or any determination by, or interpretation of any of the
foregoing by, any judicial authority, whether in effect as of the date of
the Finance Documents or thereafter and each as amended from time to
time;

(t)

words and abbreviations, which have, well known technical or trade /
commercial meanings are used in the Agreement in accordance with
such meanings;

(u)

"repayment" includes "redemption" and vice-versa and repaid, repayable,
repay, redeemed, redeemable and redemption shall be construed
accordingly;

(v)

in the event of ally disagreement or dispute between the lenders and the
Successful Bidder regarding the materiality of any matter including any
event, occurrence, circumstance, change, fact, information, document
authorization, proceeding, act, omission, claims, breach, default or
otherwise, the opinion of the Lenders’ Agent as to the materiality of any
of the foregoing shall be final and binding on the Successful Bidder; and

(w)

a Potential Event of Default is "continuing" if it has not been remedied or
waived by the Lenders’ Agent and an Event of Default is "continuing" if it
has not been waived by the Lenders’ Agent.

THE ACCOUNTS

Successful Bidder

Account Bank
Page 9 of 35

Lenders’ Agent

<!-- page 10 -->

2.1

Establishment of the Accounts
The Successful Bidder has established with the Account Bank an account with its
branch, the details of which are provided in Schedule – II hereto, titled the
"Trust and Retention Account". The Successful Bidder acknowledges and
agrees that it shall maintain the Trust and Retention Account, with the following
accounts as sub – accounts to the Trust and Retention Account:

2.2

(i)

a sub – account denominated in Rupees titled, "Revenue Account";

(ii)

a sub – account denominated in Rupees titled, "Statutory Dues
Account";

(iii)

a sub – account denominated in Rupees titled, "Fuel Cost Account";

(iv)

a sub – account denominated in Rupees titled, "Operations and
Maintenance Expense Account";

(v)

a sub – account denominated in Rupees titled, “Interest Service
Account”;

(vi)

a sub – account denominated in Rupees titled, "Debt Repayment
Account"; and

(vii)

a sub – account denominated in Rupees titled, "Surplus Account".

Declaration of Trust
The Successful Bidder hereby settles in trust with the Account Bank the sum of
Rs. 100/- (Rupees One Hundred only). The Successful Bidder also hereby
declares that all the beneficial right, title and interest in and to the trust, Trust
and Retention Account, (which, for avoidance of doubts, includes its other sub –
accounts as well), the monies therein made from the Trust and Retention
Account shall be vested in the Account Bank and held for the benefit of the GOI
(PSDF Fund), E-bid RLNG Operator, the Gas Transporter, the Secured Parties and
thereafter the Successful Bidder, in such order of priority, in accordance with the
terms of this Agreement and their respective interests are provided for herein.
The Account Bank hereby accepts the above amount of Rs. 100/- (Rupees One
Hundred only) in the trust hereby declared upon the terms and conditions set
forth in this Agreement. Amounts deposited in the Trust and Retention Account
from time to time shall be held in trust and the monies received and applied as
provided in this Agreement. No person other than the GOI (PSDF Fund), E-bid
RLNG Operator, the Gas Transporter, the Secured Parties and the Successful
Bidder shall have any rights hereunder as the beneficiaries of or as third party
beneficiaries under this Agreement.

Successful Bidder

Account Bank
Page 10 of 35

Lenders’ Agent

<!-- page 11 -->

2.3

Maintenance of the Accounts
The Account Bank shall, save as otherwise provided herein, maintain the Trust
and Retention Account in accordance with the terms of this Agreement and its
usual practices.

2.4

Operating Procedures
The Account Bank, the Lenders’ Agent and the Successful Bidder have prior to
execution of this Agreement agreed on the detailed mandates, terms and
conditions and operating procedures for the Trust and Retention Account (as set
out in Schedule – III), provided however, in the event of any inconsistency
between this Agreement and such mandates, terms and conditions or
procedures, this Agreement shall prevail. All transfers and payments pursuant to
this Agreement shall be in a manner consistent with the operating procedures.
The Successful Bidder shall submit to the Lenders’ Agent the usage monies
withdrawn from the various account of the Trust and Retention Account together
with a statement from the Account Bank evidencing receipt and withdrawal of
funds into and from the Trust and Retention Account. The Lenders’ Agent shall
be entitled to verify the usage of funds withdrawn from the Trust and Retention
Account.
At any time the Lenders’ Agent is entitled to seek an account statement from the
Account Bank and such evidence of usage of funds by the Successful Bidder from
the Trust and Retention Account as required by the Lenders’ Agent.

2.5

Business Day
If a Monthly Distribution Date is not a Business Day, the Successful Bidder shall
be entitled to instruct the Account Bank to make payment to or withdrawal from
such Account (and the corresponding withdrawal from or payment to any other
Account) on the immediately preceding Business Day, provided that any such
payments and withdrawals would have been permitted on such Monthly
Distribution Date.

2.6

Obligations of the Successful Bidder
Nothing contained in this Agreement shall affect the obligations of the Successful
Bidder under any of the Financing Documents.
The Successful Bidder shall simultaneously deliver a copy to the Lenders’ Agent
of any notice or document delivered to the Account Bank pursuant to this
Agreement.

2.7

Event of Default

Successful Bidder

Account Bank
Page 11 of 35

Lenders’ Agent

<!-- page 12 -->

Upon the occurrence of an Event of Default, the Lenders’ Agent shall inform the
Account Bank by way of a written notice.
3.

REVENUE ACCOUNT
The Revenue Account shall be opened in the name of the Successful Bidder and
shall be denominated in Rupees.

3.1.1

Deposits
The Successful Bidder shall procure that all amounts of the Gross Payment shall
be credited or deposited in the Revenue Account. The Successful Bidder shall
issue necessary instructions to the Discoms and other relevant person for this
purpose.

3.1.2

Withdrawals
On each Monthly Distribution Date, the Account Bank shall withdraw from the
Revenue Account in accordance with the Successful Bidder’s instructions only for
the following purposes and in the following order of priority (hereinafter called
the "Priority Cashflow Application"):
(a)

to pay amounts into the Statutory Dues Account equal to the Statutory
Dues that would be due and payable in the month immediately following
that Monthly Distribution Date. The transfer into this sub – account will be
only for the Statutory Dues payable for the Relevant Period and not for the
past or future dues;

(b)

to pay amounts into the Fuel Cost Account equal to the Fuel Cost that
would be due and payable to the E-bid RLNG Operator and / or the Gas
Transporter in the month immediately following that Monthly Distribution
Date for the Relevant Period. The transfer into this sub – account will be
only for the Fuel Cost incurred for the Incremental Electricity during the
Relevant Period and not for the past or future costs;

(c)

to pay amounts into the Operations and Maintenance Expense Account
equal to the Operations and Maintenance Expenses that would be due and
payable in the month following that Monthly Distribution Date for the
Relevant Period. The transfer into this sub-account will be only for the
Operations and Maintenance Expenses proportionately incurred payable for
the Incremental Electricity during the Relevant Period and not for the past
or future expenses;

(d)

to pay amounts into the Interest Service Account equal to the Interest
Amount for the month following that Monthly Distribution Date;

Successful Bidder

Account Bank
Page 12 of 35

Lenders’ Agent

<!-- page 13 -->

(e)

to pay amounts into the Debt Repayment Account equal to the Debt
Repayment Amount for the Relevant Period; and

(f)

all amounts remaining after the transfer required pursuant to Sections
3.1.2 (a) – to – (e) shall be transferred to the Surplus Account.

4.

STATUTORY DUES ACCOUNT

4.1

Statutory Dues Account
The Statutory Dues Account shall be established in the name of the Successful
Bidder and shall be denominated in Rupees. Any requests for transfer and
withdrawal of funds from the Statutory Dues Account shall be in accordance with
Schedule - III.

4.2

Deposits
On each Monthly Distribution Date, the Account Bank shall deposit to the
Statutory Dues Account, amounts equal to the Statutory Dues as per the request
of the Successful Bidder.

4.3

Withdrawals
(a) On any date, upon receiving instructions from the Successful Bidder, the
Account Bank shall withdraw amounts from this Account to pay amounts
towards payment of Statutory Dues.
(b) On each Monthly Distribution Date, to the extent that the balance in the
Statutory Dues Account exceeds the Statutory Dues amount during such
month, the Account Bank shall transfer such amounts to the Revenue
Account for the Priority Cashflow Application in accordance with Section
3.1.2.

5.

FUEL COST ACCOUNT

5.1

Account
The Fuel Cost Account shall be established in the name of the Successful Bidder
and shall be denominated in Rupees. Any requests for transfer herein under shall
be in accordance with Schedule - III.

5.2

Deposits

Successful Bidder

Account Bank
Page 13 of 35

Lenders’ Agent

<!-- page 14 -->

On each Monthly Distribution Date, the Account Bank shall transfer amounts to
the Fuel Cost Account equivalent to the amounts equal to the Fuel Cost payable
by the Successful Bidder as per the request of the Successful Bidder.
5.3

Withdrawals
(a) On any date, upon receiving instructions from the Successful Bidder, the
Account Bank shall withdraw amounts from this Account to pay amounts
towards payment of Fuel Cost. The Successful Bidder's request for transfer
and withdrawal towards the Fuel Cost shall be accompanied by the invoices
received from the E-bid RLNG Operator and the Gas Transporter for supply
and transport of the E-Bid RLNG.
(b) On each Monthly Distribution Date, to the extent that the balance in the Fuel
Cost Account exceeds the Fuel Cost amount during such month, the Account
Bank shall transfer such amounts to the Revenue Account for the Priority
Cashflow Application in accordance with Section 3.1.2.

6.

OPERATIONS AND MAINTENA NCE EXPENSE ACCOUNT

6.1

Account
The Operations and Maintenance Expense Account shall be established in the
name of the Successful Bidder and shall be denominated in Rupees. Any
requests for transfer and withdrawal of funds from the Operations and
Maintenance Expense Account shall be in accordance with Schedule - III.

6.2

Deposits
On each Monthly Distribution Date, the Account Bank shall transfer amounts to
the Operations and Maintenance Expense Account equivalent to the amounts
equal to the Operations and Maintenance Expense incurred by the Successful
Bidder as per the request of the Successful Bidder.

6.3

Withdrawals
(a) On any date, at the instructions of the Successful Bidder, the Account Bank
shall withdraw amounts, not exceeding the Operations and Maintenance
Expenses for the month as evidenced by a certificate of the Successful
Bidder.
(b) On the Monthly Distribution Date, the surplus in the Operations and
Maintenance Expense Account shall be withdrawn and deposited into the
Revenue Account for the Priority Cashflow Application in accordance with
Section 3.1.2.

Successful Bidder

Account Bank
Page 14 of 35

Lenders’ Agent

<!-- page 15 -->

7.

INTEREST SERVICE ACCOUNT

7.1

Account
The Interest Service Account shall be established in the name of the Successful
Bidder and shall be denominated in Rupees. Any requests for transfer and
withdrawal of funds from the Interest Service Account shall be in accordance
with Schedule - III.

7.2

Deposits
On each Monthly Distribution Date, the Account Bank shall transfer amounts
equivalent to the Interest Amount for the succeeding month to the Interest
Service Account.

7.3

Withdrawals
On any date, the Account Bank may permit withdrawal of amounts from the
Interest Service Account not exceeding the Interest Amount due to the Lenders
in accordance with the Financing Documents. The Account Bank will transfer
such amounts directly into the designated accounts of the respective Lenders as
set out in Schedule – I.

8.

DEBT REPAYMENT ACCOUNT

8.1

Account
The Debt Repayment Account shall be established in the name of the Successful
Bidder and shall be denominated in Rupees. Any requests for transfer and
withdrawal of funds from the Statutory Dues Account shall be in accordance with
Schedule - III.

8.2

Deposits
On each Monthly Distribution Date, the Account Bank shall deposit amounts
equivalent to the Debt Repayment Amount into the Debt Repayment Account.

8.3

Withdrawals
The Account Bank may permit withdrawal of amounts from the Debt Repayment
Account to pay the Debt Repayment Amount due to the Lenders under the
Financing Documents. This withdrawal shall be in accordance with the Successful
Bidder's request together with a statement or certificate from the Lenders’ Agent
containing the details of the amounts to be paid to the Lenders. The Account
Bank will transfer such amounts directly into the designated accounts of the
respective Lenders as set out in Schedule – I.

Successful Bidder

Account Bank
Page 15 of 35

Lenders’ Agent

<!-- page 16 -->

9.

SURPLUS ACCOUNT

9.1

Account
The Surplus Account shall be established in the name of the Successful Bidder
and shall be denominated in Rupees.

9.2

Deposits
At the end of the Relevant Period, the Account Bank shall transfer all balance
amounts left in the Revenue Account after giving effect to the Priority Cashflow
Application to the Surplus Account in accordance with Section 3.1.2.

9.3

Withdrawals
At the end of the Relevant Period, the Account Bank shall withdraw and transfer
the balance amounts left in the Surplus Account to the PSDF Fund of the GOI in
the manner instructed by the GOI.

10.

GENERAL RIGHT OF WITHDRAWAL
The Account Bank shall not make any transfer or withdrawal from the Trust and
Retention Account except as provided for in this Agreement.

11.

WITHDRAWALS FOLLOWING EVENT OF DEFAULT

11.1

Events of Default
If any Secured Party notifies the Account Bank that an Event of Default or a TRA
Default has occurred, and is continuing, then, until such time as the Secured
Party has notified the Account Bank that the Event of Default or the TRA Default
(as the case maybe) has been cured or waived under the relevant Financing
Document, the Account Bank shall act only on the instructions of the Lenders’
Agent and make withdrawals from the Accounts in accordance with the
instructions of the Lenders’ Agent but subject to the Priority Cashflow
Application.

11.2

Procedure following an Event of Default
The Account Bank, at any time after the notification by any Secured Party of the
occurrence and continuance of an Event of Default or a TRA Default and until
such time as it is notified by the Secured Party that such Event of Default or TRA
Default has been remedied, shall:

Successful Bidder

Account Bank
Page 16 of 35

Lenders’ Agent

<!-- page 17 -->

(a)

not act on the instructions of the Successful Bidder pursuant to this
Agreement in relation to any sums at such time standing to the credit of
the Accounts except with the prior written consent of the Lenders’ Agent;

(b)

be entitled to pay to the Lenders’ Agent any sums standing to the credit of
the Accounts for application by the Lenders’ Agent in or towards the
payment and discharge of any amounts owing to the Secured Parties
under the Financing Documents; and

(c)

not honour any cheques (if there are any) or other payment instructions of
the Successful Bidder without the prior written consent of the Lenders’
Agent.

11.3

Upon the occurrence and during the continuance of an Event of Default or TRA
Default, the Successful Bidder undertakes not to issue any cheque or payment
instructions to the Account Bank without the prior written consent of the
Lenders’ Agent.

12.

ACCOUNT BANK PROVISIONS

12.1

The Account Bank and the Secured Parties
The Successful Bidder hereby appoints the Account Bank to act as trustee for the
Secured Parties, and the Successful Bidder in connection herewith, and
authorizes the Account Bank to exercise such rights, powers, authorities and
discretions as are specifically delegated to the Account Bank by the terms hereof
together with all such rights, powers, authorities and discretions as are
reasonably incidental hereto, and the Account Bank accepts such appointment
pursuant to the terms hereof. The Account Bank shall act only upon either (i) the
instructions of the Lenders’ Agent, or (ii) instructions from the Successful Bidder,
if the same have been confirmed by the Lenders’ Agent, and make withdrawals
from the Accounts upon receiving such instructions or confirmation, as the case
may be, from the Lenders’ Agent.

12.2

Obligations of the Account Bank
The Account Bank:
(a)

undertakes to perform only such duties as are specifically set forth to be
performed in this Agreement and such other duties as are specifically
directed by the Secured Parties, without gross negligence or willful default.
In the absence of clear direction in this Agreement, the Account Bank shall
take no action under this Agreement until it has received specific direction
from the Lenders’ Agent as provided in this Section;

Successful Bidder

Account Bank
Page 17 of 35

Lenders’ Agent

<!-- page 18 -->

12.3

(b)

may, in the absence of willful misconduct or gross negligence on its part,
rely as to any matters of fact which might reasonably be expected to be
within the knowledge of the Successful Bidder and are contained in a
certificate signed by or on behalf of the Successful Bidder;

(c)

may, in the absence of willful misconduct or gross negligence on its part,
rely upon the authenticity any communication or documents believed by it
to be authentic;

(d)

shall, within 3 (three) Business Days after receipt, deliver a copy to the
Secured Parties of any notice or document received by the Account Bank
in its capacity as Account Bank from the Successful Bidder or any other
person hereunder or in connection herewith; and,

(e)

shall, within 3 (three) Business Days after receipt, deliver a copy to the
Successful Bidder of any notice or document received by the Account Bank
from (a) any of the Secured Parties; and (b) any other Person at the
discretion of the Lenders’ Agent, in connection herewith.

Segregation of Funds
Monies and other property received by the Account Bank under this Agreement
shall, until used or applied in accordance with this Agreement, be held in trust of
the purposes for which they were received and shall be segregated from other
funds and property of the Account Bank. The Account Bank agrees not to claim
or exercise any right of set off, banker's lien or other right or remedy with
respect to amounts standing to the credit of the Trust and Retention Account.
For the avoidance of doubt, the monies and properties held by the Account Bank
shall not be considered as part of the assets of the Account Bank, and, being
trust property shall not, in the case of bankruptcy or liquidation of the Account
Bank, be considered as its assets and shall not be available to the liquidator,
bankruptcy trustee or other creditor of the Account Bank and such monies and
properties shall be wholly excluded from the assets of the Account Bank in such
bankruptcy.

12.4

Termination
(a)

This Agreement shall automatically terminate if the PSDF Support
Agreement is terminated or, the Power Plant becomes ineligible to receive
support from the PSDF Fund or, the Successful Bidder is otherwise
disqualified or becomes disentitled to receive support from the PSDF Fund
or, any other alternate support scheme formulated by the Ministry of
Power. This Agreement may be terminated earlier by the mutual consent
of the Parties provided that the Parties have agreed to replace this
Agreement with another trust and retention account agreement complying
with the Office Memorandum and the Tender Document.

Successful Bidder

Account Bank
Page 18 of 35

Lenders’ Agent

<!-- page 19 -->

(b)

The Successful Bidder may, by not less than 20 (Twenty) days prior notice
to the Account Bank and with the prior written consent of the Lenders’
Agent, terminate this Agreement and appoint one or more Account
Bank(s), provided that the new Account Bank(s) is / are acceptable to the
Lenders’ Agent and arrangements are made satisfactory to the Lenders’
Agent for transfer of the amounts deposited in the Account to new
Accounts established, with the successor Account Bank(s).

(c)

The Lenders’ Agent may, after consultation with the Secured Parties and
the Successful Bidder (unless an Event of Default has occurred and is
continuing, in which event no such consultation shall be required), after
giving notice of 20 (Twenty) days at any time remove the Account Bank
with or without cause or the Account Bank may after giving notice of 60
(sixty) days resign and the Lenders’ Agent shall appoint a successor
Account Bank by written notice of such action to the Successful Bidder, the
Account Bank and the successor Account Bank within the aforesaid notice
period, failing which the Account Bank shall be entitled to appoint the
successor Account Bank. The successor Account Bank must be a scheduled
commercial bank.

(d)

The Account Bank shall be entitled to terminate this Agreement if the
Successful Bidder fails to comply with any of its material obligations to the
Account Bank under this Agreement and fails to remedy the failure within
60 (sixty) days after receipt of notice thereof from the Account Bank to the
Successful Bidder and the Lenders’ Agent, provided the Successful Bidder
has arranged for the appointment of a new Account Bank(s) acceptable to
the Secured Parties and arrangements are made satisfactory to the
Secured Parties for the transfer of amounts deposited in the Accounts to
new Accounts established with successor Account Bank(s).

(e)
(i)

any successor Account Bank appointed as provided in this Section
shall execute, acknowledge and deliver to the Secured Parties, the
Successful Bidder and to its predecessor trustee Account Bank an
instrument accepting such appointment, and thereupon the
resignation or removal of the predecessor trustee Account Bank
shall become effective and such successor Account Bank, without
any further act, deed or conveyance, shall become vested with all
the rights, powers, duties and obligations of its predecessor
hereunder, as if it was originally named as Account Bank;

(ii)

provided that on the written request of the Secured Parties or of the
successor Account Bank, the Account Bank ceasing to act shall,
upon payment of all amounts then due to it, execute and deliver an
instrument or instruments transferring and assigning to such

Successful Bidder

Account Bank
Page 19 of 35

Lenders’ Agent

<!-- page 20 -->

successor Account Bank (without obligation to indemnify such
successor Account Bank) all the rights and powers of the Account
Bank so ceasing to act; and,
(iii)

12.5

12.6

upon the request of any such successor Account Bank, the
Successful Bidder shall execute any and all instruments in writing in
order more fully and certainly to vest in and confirm to such
successor Account Bank all such rights and powers.

(f)

Any corporation into which the Account Bank may be merged or converted
or with which it may be consolidated, or any corporation resulting from
any merger, conversion or consolidation to which the Account Bank shall
be a party, or any corporation succeeding to the corporate trust business
of either, shall, subject to the consent of the Lenders’ Agent, be the
successor of the Account Bank.

(g)

The Account Bank may resign from its duties at any time during the
pendency of this Agreement by giving 60 (sixty) days notice in writing to
the Successful Bidder. If the Account Bank resigns, the Successful Bidder,
with the approval of the Lenders’ Agent shall appoint a successor Account
Bank. Provided, however, that if no successor Account Bank has been so
appointed by the Successful Bidder within 30 (thirty) days after notice of
resignation has been given, the Lenders’ Agent may appoint a successor
Account Bank account in consultation with the Successful Bidder.

Fees
(a)

In consideration of the services to be rendered by the Account Bank, the
Successful Bidder shall pay to the Account Bank fees in such amounts and
at such times as may be agreed between the Account Bank and the
Successful Bidder.

(b)

The Successful Bidder shall promptly pay or put the, Account Bank in
sufficient funds to meet and discharge all expenses, disbursements and
advances incurred or to be incurred by the Account Bank under any action
taken pursuant to this Agreement on any other Financing Documents, or
any amendment, supplement, modification, re – negotiation, restructuring
or "workout" thereof (including the compensation and the expenses of its
sub-agents or employees and any other Person whose services are utilized
by the Account Bank in the performance of their functions.

Books and Records
The Account Bank shall be responsible for maintaining a correct and complete
record of all transactions, deposits, withdrawals or transfer of funds relating to
each of the Accounts.

Successful Bidder

Account Bank
Page 20 of 35

Lenders’ Agent

<!-- page 21 -->

12.7

Determination of Amount and Events
(a)

12.8

The Account Bank shall be entitled to rely as to the following matters
exclusively upon the following documents (insofar as the same are
delivered to the Account Bank by the Lenders’ Agent and / or the
Successful Bidder, as the case may be):
(i)

with respect to Debt Repayment Amount, a certificate or statement
from the Lenders’ Agent; and,

(ii)

with respect to events, acts or occurrences (including, without
limitation, with respect to a Event of Default), the relevant notice of
Event of Default.

(b)

The Account Bank may for all purposes rely on a certificate, signed by an
authorized officer of the Lenders’ Agent or the Successful Bidder as to any
fact or matter the manner of ascertainment of which is not specifically
provided for therein.

(c)

Any determination made by the Account Bank in accordance with this
Agreement shall in the absence of any apparent error on the face of the
record be conclusive and binding upon the Parties.

(d)

The Account Bank shall, within 3 (three) Business Days after its receipt of
any notice of an Event of Default or any other notice from the Lenders’
Agent, send a copy thereof to each Secured Party.

Notice of Breach
The Account Bank undertakes to the Lenders’ Agent that it shall notify the
Lenders’ Agent of any breach by the Successful Bidder (to the best of its
knowledge) of any of the provisions of this Agreement.

12.9

Indemnity
The Successful Bidder shall indemnify and keep indemnified the Account Bank for
any and all liabilities, obligations, losses, damages, penalties, actions, judgments,
suits, costs, expenses, claims or disbursements of any kind or nature whatsoever
which may be imposed upon, incurred by or asserted against the Account Bank
in any way in connection with or arising out of the negotiation, preservation or
enforcement of any rights under, or in carrying out its duties under this
Agreement or the Financing Documents (other than those arising as a result of
the Account Bank's gross negligence or willful default).

Successful Bidder

Account Bank
Page 21 of 35

Lenders’ Agent

<!-- page 22 -->

The Successful Bidder shall further indemnify and keep indemnified the Account
Bank for any and all liabilities, obligations, losses, damages, penalties, actions,
judgments, suits, costs, expenses, claims or disbursements of any kind or nature
whatsoever which may be imposed upon, incurred by or asserted against the
Account Bank upon the Account Bank (a) acting upon any request sent by
facsimile, if such facsimile was found to be sent in an unauthorized manner; or
(b) not acting upon any request if such facsimile was sent but not received by
the concerned person of the Account Bank.
The obligations of the Successful Bidder under this Section to indemnify and
keep indemnified the Account Bank shall survive the satisfaction, discharge or
other termination of this Agreement and the resignation or removal of the
Account Bank under this Agreement.
12.10

Not Acting in Individual Capacity
In accepting the trusts hereby created, the Account Bank acts solely in its
capacity as Account Bank and not in its individual capacity and all persons having
any claim against the Account Bank by reason of the transactions contemplated
by the Financing Documents shall look only to the Successful Bidder for payment
or satisfaction thereof, save and except as provided in this Agreement, other
than as a result of its willful, default or gross negligence.

13.

TRA DEFAULT
If the Successful Bidder is in breach of any of the following obligations under this
Agreement and fails to remedy the same:
(a)

in the case of a failure to deposit funds received by the Successful Bidder
in the appropriate Account in accordance with this Agreement, by
depositing the same in such appropriate Account;

(b)

in the case of a breach consisting of causing the Account Bank to transfer
funds to any Account in breach of the terms of this Agreement, by
depositing the relevant funds in the Account in which such transfer should
have been made (or, in the case of a transfer to the Revenue Account, by
requesting the Lenders’ Agent to authorize the transfer of amounts
incorrectly deposited in such Account to the Account to which the transfer
should have been made); and,

(c)

any other breach by the Successful Bidder under this Agreement;

Such breach / default shall be deemed to be a “TRA Default”, and the Lenders’
Agent shall promptly authorize the Account Bank to make transfers required
pursuant to paragraph (b) above. An Event of Default shall include a TRA
Default.

Successful Bidder

Account Bank
Page 22 of 35

Lenders’ Agent

<!-- page 23 -->

14.

REPRESENTATION AND WARRANTIES
THE SUCCESSFUL BIDDER

OF THE

ACCOUNT

BANK AND

Each of the Account Bank and the Successful Bidder represents and warrants
that it is duly organized and validly existing under the laws of India with power
to enter into this Agreement and to exercise its rights and perform its obligations
hereunder and has taken all corporate and other actions required for the
execution of this Agreement and the performance of its obligations hereunder
and the Successful Bidder further represents and warrants that all the
representations and warranties under the Financing Documents shall be valid for
the purposes of this Agreement. The Successful Bidder represents and warrants
that all Accounts shall have been opened in the name of the Successful Bidder
and shall be maintained in accordance with the provisions of this Agreement. The
Account Bank represents and warrants that it shall hold all funds in the Accounts
on trust and in accordance with the provisions of the Agreement and further
represents and warrants that it has obtained all approvals, permits and other
clearances required for the execution of this Agreement and the performance of
its obligations hereunder.
15.

CONFIDENTIALITY
The Account Bank shall keep confidential all information furnished to it by or on
behalf of the Successful Bidder, the Secured Parties or their Affiliates pursuant to
or in connection with the Financing Documents, including without limitation, any
information received by the Account Bank from a nominee director; provided,
that the Account Bank may disclose such information (i) to its attorneys and
auditors to the extent they have a bona fide need for such information; (ii) to
regulatory authorities charged with the supervision and examination of the
Account Bank; (iii) to any potential successor Account Bank or any, potential
assignee of all or a portion of the Account Bank's rights under the Financing
Documents so long as such potential successor Account Bank or any potential
assignee covenants in writing to uphold this confidentiality provision; (iv) that
was in the public domain at the time of the Account Bank's disclosure; (v) that
subsequently comes into the public domain through no fault of the Account
Bank; (vi) that is disclosed to the Account Bank by a third party who is under no
obligation to any other party to keep such information confidential; (vii) to
enable it to comply with any Applicable Law; (viii) in connection with the defence
of any litigation or transactions contemplated by the Financing Documents to the
extent necessary; (ix) to any other Secured Party or Lenders’ Agent; and (x) in
connection with the enforcement of the rights and remedies of any Secured
Party under any Financing Documents to the extent necessary.

16.

RESTRICTION ON ASSIGNMENT

Successful Bidder

Account Bank
Page 23 of 35

Lenders’ Agent

<!-- page 24 -->

Save as provided in Section, none of the Successful Bidder or the Account Bank
shall assign or transfer any part of their respective rights or obligations under
this Agreement without the prior consent of the Secured Parties and the Lenders’
Agent, provided that this Section shall not prevent my Secured Party or the
Lenders’ Agent from assigning or transferring its rights under this Agreement.
17.

BENEFIT OF AGREEMENT
Nothing in this Agreement shall give to any other Person (other than the Parties
hereto and their successors and permitted assigns) any benefit or any legal or
equitable right or remedy under this Agreement.
This Agreement shall be binding on and shall inure to the benefit of the Parties
hereto and the respective successors and permitted assigns.

18.

NOTICES
(a)

Except as otherwise expressly provided herein or in any Financing
Document, all notices and other communications provided for hereunder
or thereunder shall be (i) in writing (including telex and telecopier, except
as noted below); and (ii) telexed, telecopier or sent by a Person, overnight
courier (if for inland delivery) or international, courier (if for overseas
delivery) to a Party hereto at its address and contact number specified
herein or at such other address and contact number as is designated by
such party in a written notice to the other parties hereto. The address for
notices of the Successful Bidder, Lenders’ Agent and Account Bank shall be
as provided at (d) below.

(b)

All such notices and communications shall be effective only on actual
receipt by the officer of the Secured Party or the Successful Bidder as the
case may be for whose attention the notice or communication has been
expressly marked. Provided however that any notice or communication to
the Successful Bidder by the Secured Party with respect to Event of
Default, TRA Event of Default, enforcement of any Security shall be
effective if (i) if sent by telex, when sent (with the correct answerback);
(ii) if sent by telecopier, when sent(on receipt of a confirmation to the
correct telecopier number); (iii) if sent by Person, when delivered; (iv) if
sent by courier, (a) 1 (one) Business Day after deposit with an overnight
courier if for inland delivery; and (b) 5 (five) Business Days after deposit
with an international courier if for overseas delivery; and (v) if sent by
registered letter, when the registered letter would, in the ordinary course
of post, be delivered whether actually delivered or not.

(c)

An original of each notice and communication sent by telex or telecopy
shall be dispatched by person, overnight courier (if for inland delivery) or
international courier (if for overseas delivery) and, if such Person or

Successful Bidder

Account Bank
Page 24 of 35

Lenders’ Agent

<!-- page 25 -->

courier service is not available, by registered airmail (or, if for inland
delivery, registered first class mail) with postage prepaid, provided that the
effective date of any such notice shall be determined in accordance with
this Section as the case may be, without regard to the dispatch of such
original.
(d)

Addresses:
The address for notices and communication in respect of this Agreement
shall be as follows:
For the Successful Bidder:
[●]12
Attention:

[●]13

Address:

[●]14

Fax No.:

[●]15

Tel No.:

[●]16

For the Lenders’ Agent:
[●]17
Attention:

[●]18

Address:

[●]19

Fax No.:

[●]20

Tel No.:

[●]21

For the Account Bank:
Insert the name of the Successful Bidder.
Insert the name of the authorized person of the Successful Bidder.
14
Insert the address of the Successful Bidder.
15
Insert the fax number of the Successful Bidder.
16
Insert the telephone number of the Successful Bidder.
17
Insert the name of the Lenders’ Agent.
18
Insert the name of the authorized person of the Lenders’ Agent.
19
Insert the address of the Lenders’ Agent.
20
Insert the fax number of the Lenders’ Agent.
21
Insert the telephone number of the Lenders’ Agent.
12
13

Successful Bidder

Account Bank
Page 25 of 35

Lenders’ Agent

<!-- page 26 -->

[●]22

(e)

Attention:

[●]23

Address:

[●]24

Fax No.:

[●]25

Tel No.:

[●]26

Change of Address
Any Party may by notice change the addresses and / or addresses to
which such notices and communications to it are to be delivered or mailed.
Such change shall be effective when all the Parties have written notice of
it.

19.

WAIVER
No failure or delay on the part of any of the Secured Party in exercising any
right, power or privilege hereunder or under any other Financing Document and
no course of dealing between the Successful Bidder, on the one hand, and the
Secured Parties, on the other hand, shall impair any such right, power or
privilege or operate as a waiver thereof nor shall any single or partial exercise of
any right, power or privilege hereunder or under any other Financing Document
preclude any other or further exercise thereof or the exercise of other right,
power or privilege hereunder or thereunder. The rights, powers and remedies
herein or in any other Financing Document or expressly provided are cumulative
and not exclusive of any rights, powers or remedies which any of the Secured
Parties would otherwise have. No notice to or demand on the Successful Bidder
in any case shall entitle the Successful Bidder to any other or further notice or
demand in similar or other circumstances or constitute a waiver of the rights of
any of the Secured Parties to any other or further action in any circumstances
without notice or demand.

20.

SEVERABILITY
Any provision of this Agreement, which is prohibited or unenforceable in any
jurisdiction, shall, as to such jurisdiction, be ineffective to the extent of

Insert the name of the Account Bank.
Insert the name of the authorized person of the Account Bank.
24
Insert the address of the Account Bank.
25
Insert the fax number of the Account Bank.
26
Insert the telephone number of the Account Bank.
22
23

Successful Bidder

Account Bank
Page 26 of 35

Lenders’ Agent

<!-- page 27 -->

prohibition or unenforceability but shall not invalidate the remaining provisions of
such Financing Document or affect such provision in any other jurisdiction.
21.

AMENDMENTS
No amendment to this Agreement shall be binding unless in writing and signed
by the duly authorized representatives of the Parties.

22.

GOVERNING LAW
This Agreement shall be governed by and construed in accordance with Indian
laws.

23.

JURISDICTION
(a)

The Successful Bidder agrees that the courts and tribunals (including the
debt recovery tribunals) in [●]27 shall have exclusive jurisdiction to settle
any disputes which may arise out of or in connection with this Agreement
and that accordingly any suit, action or proceedings (together referred to
as "Proceedings") arising out of or in connection with this Agreement
may be brought in such courts or the tribunals and the Successful Bidder
irrevocably submits to and accepts for itself and in respect of its property,
generally and unconditionally, the jurisdiction of those courts or tribunals.

(b)

The Successful Bidder irrevocably waives any objection now or in future, to
the laying of the venue of any Proceedings in the courts and tribunals at
[●]28 and any claim that any such. Proceedings have been brought in an
inconvenient forum and further irrevocably agrees that a judgment in any
Proceedings brought in the courts and tribunals at [●]29 shall be conclusive
and binding upon it and may be enforced in the courts of any other
jurisdiction (subject to the laws of such jurisdiction) by a suit upon such
judgment, a certified copy of which shall be conclusive evidence of such
judgment, or in any other manner provided by Applicable Law.

(c)

The Successful Bidder hereby consents generally in respect of any
Proceedings arising out of or in connection with this Agreement to the
giving of any relief or the issue of any process in connection with such
Proceedings including, without limitation, the making, enforcement or
execution against any property whatsoever (irrespective of its use or
intended use) of any order or judgment which may be made or given in
such Proceedings.

Insert the place of jurisdiction.
Insert the place of jurisdiction.
29
Insert the place of jurisdiction.
27
28

Successful Bidder

Account Bank
Page 27 of 35

Lenders’ Agent

<!-- page 28 -->

24.

REGULA TORY APPROVALS
The Successful Bidder shall procure and shall thereafter maintain and comply
with all regulatory approvals required for the establishment and operation of the
Accounts and the making of any deposits, transfers or withdrawals and for the
performance of its obligations under this Agreement.

25.

NOTIFICA TION OF BALANCES
Within 7 (seven) days following the end of each calendar month, the Account
Bank shall notify the Lenders’ Agent and the Successful Bidder of the respective
balances in the Accounts and furnish a statement of the deposits into and
payment out of the Accounts as at the close of business of such calendar month.

26.

ADDITIONAL RIGHTS
Any rights conferred on the Account Bank, the Lenders’ Agent or any of them, by
this Agreement shall be in addition to and not in substitution for or in derogation
of any other rights and remedies which the lenders or Lenders’ Agent or any of
them, may at any time have under the Financing Documents or otherwise,
including, without limitation, rights to seek and obtain from the Successful Bidder
or any party to the Financing Documents reimbursement of or indemnification
against payments made or liabilities incurred under the Financing Documents or
otherwise.

27.

ACCOUNT BANK MAY CARRY ON OTHER BUSINESS
Notwithstanding its appointment as an Account Bank, the Account Bank may
carry on any business and other transactions with the lenders, its Affiliates or
other entities so long as such business, in the opinion of the Lenders’ Agent, do
not conflict with its obligations under this Agreement and the other Financing
Agreements.

28.

SUCCESSORS AND ASSIGNORS
This Agreement shall be binding on and shall inure to the benefit of the Parties
hereto and their respective successors in title and permitted assigns. Neither of
the Parties shall assign or transfer any part of their respective rights or
obligations under the Agreement without the prior consent of each of the other
Parties.

29.

COUNTERPARTS
This Agreement may be executed in several counterparts, each of which shall be
deemed an original, but all of which together shall constitute one and the same
agreement.

Successful Bidder

Account Bank
Page 28 of 35

Lenders’ Agent

<!-- page 29 -->

30.

GENERAL
Notwithstanding anything contained in this Agreement, the Account Bank shall
not be responsible for calculating any amount to give effect to the provisions of
this Agreement and the Account Bank shall act only as per the written
instructions of the Successful Bidder or as may otherwise be specified in the
Agreement.

Successful Bidder

Account Bank
Page 29 of 35

Lenders’ Agent

<!-- page 30 -->

SCHEDULE – I
PARTICULARS OF LOANS AVAILED BY THE SUCCESSFUL BIDDER

Sr.No.

Lenders

Outstanding
amounts (in crores)

Particulars of
the designated
accounts of the
Lenders

1.

[●]30

[●]31

[●]32

2.

[●]33

[●]34

[●]35

3.

[●]36

[●]37

[●]38

Total:

[●]39

Insert the name of the Lender.
Insert the outstanding amount in crores for the respective Lender.
32
Insert the particulars of the designated accounts of the respective Lender.
33
Insert the name of the Lender.
34
Insert the outstanding amount in crores for the respective Lender.
35
Insert the particulars of the designated accounts of the respective Lender.
36
Insert the name of the Lender.
37
Insert the outstanding amount in crores for the respective Lender.
38
Insert the particulars of the designated accounts of the respective Lender.
39
Insert the aggregate outstanding amount in crores to the account of the Successful Bidder.
30
31

Successful Bidder

Account Bank
Page 30 of 35

Lenders’ Agent

<!-- page 31 -->

SCHEDULE – II
DETAILS OF TRUST AND RETENTION ACCOUNT

Particulars and
Address of the
Branch Office of the
Account Bank for the
Trust and Retention
Account

[●]40

IFSC Code

[●]41

Account Number of
the Trust and
Retention Account

[●]42

Insert the particulars and address of the branch office for the Trust and Retention Account.
Insert the name of IFSC Code of the Branch of the Account Bank.
42
Insert the Account Number of TRA Account.
40
41

Successful Bidder

Account Bank
Page 31 of 35

Lenders’ Agent

<!-- page 32 -->

SCHEDULE – III
OPERATING PROCEDURES

1.

Interpretation

1.1

This Schedule is divided into two Parts:
Part A provides details of the mechanics for transfers and / or withdrawals
Part B provides steps to be taken and / or documents to be reviewed before
certain transfers or withdrawals are made.

1.2

If there is any conflict between the provisions of this Schedule and the
Agreement then the provisions of the Agreement shall apply. Terms defined in
the Agreement shall apply to this Schedule.

2.

BENEFIT OF PROVISIONS
Each of the restrictions contained in this Agreement relating to the Accounts shall
be for the benefit of the Secured Parties. Any such restrictions may accordingly
be relaxed or waived, either:(A)

by the Lenders’ Agent, or

(B)

if the Successful Bidder requests and the Lenders’ Agent agrees,
provided that the Lenders’ Agent shall not be obliged to agree to such
request,

and none of the restrictions shall limit the rights of the Secured Parties under the
Financing Documents.
PART – A
GENERAL PROVISIONS RELATING TO TRANSFER AND WITHDRAWALS
3.

WITHDRAWAL / TRANSFER PROCEDURES

3.1

The Account Bank shall not make any transfer except as expressly provided in
the Agreement.

3.2

All requests by the Successful Bidder to the Account Bank for a withdrawal from
an Account to any third party:

3.2.1

shall be in writing, signed by an authorized officer of the Successful Bidder and
sent to the Account Bank by facsimile to the facsimile number specified in this
Agreement three (3) Business Days prior to the proposed date of withdrawal;

Successful Bidder

Account Bank
Page 32 of 35

Lenders’ Agent

<!-- page 33 -->

3.2.2

shall specify the purpose of the transfer; and

3.2.3

shall be accompanied by such documents or other verifying evidence of the
expenditure as the Account Bank may request.

3.2.4

Such request by the Successful Bidder shall be approved / confirmed by the
Lenders’ Agent.

4.

IMPLEMENTATION OF WITHDRAWAL / TRANSFER REQUEST

4.1

Except as otherwise provided in this Agreement, and, subject to Clause 3.2 of
Part A above in case of request from the Successful Bidder, upon the receipt
from the Lenders’ Agent or the Successful Bidder of a request ("Request")
delivered pursuant to this Agreement, the Account Dank shall, provided (where
required) it has received the documentary evidence set out in Part B of this
Schedule pay or transfer the amount(s) requested in such Request or other
written instructions of the Successful Bidder or Lenders’ Agent (as the case may
be).

4.2

Any transfer requested in accordance with paragraph 4.1 of this Schedule shall
be made as follows.

4.2.1

in the case of a Request requesting a withdrawal or transfer to another Account,
directly to such Account, by initiating such transfer not later than [●]43, [●]44
time on, or as soon as practicable after, the date set out in such Request; and

4.2.2

in the case of any Request requesting a payment to any Person or the transfer to
an account other than an Account, directly to such Person or account set out in
such Request, by initiating such payment or transfer not later than [●]45, [●]46
time on, or as soon as practicable after, the date set out in such Request.

5.

FAILURE
OF
SUCCESSFUL
TRANSFER REQUEST

5.1

Notwithstanding any other provision of this Agreement to the contrary, if the
Successful Bidder fails to timely submit a Request to the Account Bank for the
withdrawal, transfer, conversion or payment of amounts to any Account or
Person (whether on a Monthly Distribution Date or otherwise), the Account Bank
shall be authorized (and in each case, the Successful Bidder hereby authorizes
the Lenders’ Agent to so act) upon the receipt of a written direction by the
Lenders’ Agent.

BIDDER

TO

SUBMIT

WITHDRAWAL/

Insert the time of day.
Insert the place.
45
Insert the time of day.
46
Insert the place.
43
44

Successful Bidder

Account Bank
Page 33 of 35

Lenders’ Agent

<!-- page 34 -->

5.1.1

to effect any withdrawal, transfer, conversion or payment, as the case may be,
of any amounts then due and payable or required to be transferred pursuant to
the terms of any Financing Documents; or

PART – B
TRANSFERS FROM ANY ACCOUNT IN ANY MONTH
6.

CALCULATIONS FOR MONTHLY TRANSFERS

6.1

Timing of Requests
At least 5 (five) Business Days prior to the first Business Day of each month, the
Successful Bidder shall deliver to the Lenders’ Agent and the Account Bank a
written Request specifying:

6.2

A.

the withdrawals for such month from each Account and transfers to the
Accounts and / or Person(s);

B.

the amount requested to be withdrawn or transferred from such
Account; and,

C.

the date upon which such withdrawal or transfer is to be made

Implementation of Requests
(A)

Upon the receipt of a duly authorised Request from the Successful
Bidder, and subject to Clause 3.2 of Part A above in case of request of
request from the Successful Bidder, the Account Bank shall transfer/pay
on each Monthly Distribution Date monies in deposit in the Accounts
directly to the relevant Accounts set out in the Request or to the Persons
or the account of Persons set out in the Request.

(B)

In the event that the Request furnished by the Successful Bidder is not
in accordance with this Agreement, the Account Bank shall seek the
approval of the Lenders’ Agent before implementing the Request.

7.

WITHDRAWALS DURING AN EVENT OF DEFAULT

7.1

The Account Bank shall not, except with the prior written consent of the Lenders’
Agent, permit any withdrawal to be made from an Account:

7.1.1

on or after receipt of a notice from any of the Secured Patties that an Event of
Default has occurred unless and until such notice is subsequently withdrawn by
the Lenders’ Agent,

Successful Bidder

Account Bank
Page 34 of 35

Lenders’ Agent

<!-- page 35 -->

7.1.2

on or after receipt of notification from any of the Secured Parties that such
withdrawal is not or would not be permitted under the Financing Documents

72

Upon the occurrence of an Event of Default

7.2.1

no withdrawals may be made from any of the Accounts without the prior wr itten
consent of the Secured Parties.

IN WITNESS WHEREOF the Successful Bidder has caused its Common Seal to be
affixed hereto on the date first above written the Lenders’ Agent, the Account Bank and
the Successful Bidder have caused the same and the said counterparts to be executed by
the hand of an authorized official.
SIGNED AND DELIVERED BY [.]4 7 ,
the
within
named
SUCCESSFUL
BIDDER,
by
the
hand
of
………………………………………. its Director.
THE COMMON SEAL OF [.] 4 8 has
pursuant to the Resolutions of its Board
of Directors passed in that behalf on
………………………………………
hereunto
been affixed in the presence Mr.
.......................................... its Director
who has signed these presents in token
thereof
SIGNED AND DELIVERED BY [.]4 9 ,
the within named ACCOUNT BANK, by
the hand of ………………………….………. its
Authorised Representative.
SIGNED AND DELIVERED BY [.]5 0 ,
the within named LENDERS’ AGENT,
by
the
hand
of
………………………….………. its Authorised
Representative.
Insert the name of the Successful Bidder.
Insert the name of the Successful Bidder.
49
Insert the name of the Account Bank.
50
Insert the name of the Lenders’ Agent.
47
48

Successful Bidder

Account Bank
Page 35 of 35

Lenders’ Agent
