---
doc_id: "fdcb6fcab8dc2a97"
source_url: "https://mohua.gov.in/static/uploads/2025/11/e11b1aaa5b36cbf774f22a7f8bd4df4f.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs.1,07,40,000/- as 1*t installment of Central Assistance for 1 AHP projects sanctioned in 51st CSMC to the State Government of Gujarat under Pradhan Mantri Awas Yojana - Urban (PMAY-U) for the financial year 2020-21."
date: "2021-03-02"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a8a539205161e958"
---

<!-- page 1 -->

https://pfims.nic.in/Sanction/TemplateA dvice.aspx?A dviceNum=...
: U3
. PAO(Sectt.)/HUA/Admin/Advice/2020-21/ /9é/~ 6 2_.
GOVERNMENT OF INDIA
PAO(Sectt.), M/o Housing & Urban Affairs
507-C(wing), Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The Genera! Manager, OO
Reserve Bank of India, (Code No: [707
Central Accounts Section, |
Additional Office Building, [03/03/2021
East High Court Road,
NAGPUR - 440 001
Sir,

Please debit our account with Rs.1,07,40,000/- (One Crore Seven Lakh Forty Thousand
Only.) by contra credit to the following accounts of the Governments with the amounts mentioned
against each:

Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
[sume Name of State | Scteme code | Code | Amount] Sanction No. and Date
the State _ Code
1 GUJARAT 104 1989-STATE AND UT 1,07,40,000 | N-11012/5/2020-HFA-IV-UD
दि GRANTS UNDER PMAY (EFS 9087450) dated
(URBAN) 02/03/2021
[|
Signature of the authorized official
(Pawan Kumar Bhatnagar)
Sr.Accounts Officer
US /o the Accountant General (A&E), Gujarat, Rajkot-360001.
“Sh. Sanjeev Kumar Sharma, US (HFA-IV), M/o HUA, Nirman Bhawan, New Delhi.
(Pawan Kuirar Bhatnagar)
Sr. Accounts Officer
(0 Ao-HF A
BO Yon CHI ५,
2291 2
(2 ः
(2 MIG Hr A
wW
we ¢
is
lofl 03-03-2021, 12:28

<!-- page 2 -->

eee
. बह 43t
N-11012/5/2020-HFA-IV-UD (EFS: 9087450)
Government of India
Ministry of Housing & Urban Affairs
HFA4V Section
teks
Nirman Bhawan, New Delhi - 110011
Dated: 95 March, 2021

To
The Pay and Account Officer (Sect.),

Ministry of Housing & Urban Affairs,
Nirman Bhawan, New Delhi - 110011.

Sub: Release of Rs.1,07,40,000/- as 1“ installment of Central Assistance for 1 AHP projects
sanctioned in 51** CSMC to the State Government of Gujarat under Pradhan Mantri
Awas Yojana — Urban (PMAY-U) for the financial year 2020-21.

Sir,

| am directed to convey the Sanction of the President of India to the release of

Rs.1,07,40,000/- (Rupees One Crore Seven Lakh Forty Thousand only) as 1* installment of

Central Assistance for 1 AHP project sanctioned in 51% CSMC meeting held on 07.08.2020 for

Creation of Capital Assets under PMAY (U) Mission under allocation (For Scheduled Caste

Beneficiaries) to the State Government of Gujarat for the FY 2020-21.

2. The statement showing details of the 1 AHP project against which the above amount stands

sanctioned is annexed.

3. Based on decision and recommendations of CSMC under PMAY (U) Mission, the amount of

central grant is being released subject to following conditions:

i. State should ensure that data entries in PMAY (U) — MIS portal are completed at the earliest.
Second/Subsequent installment will be released based on valid beneficiaries in PMAY (U) —
MIS portal.

ii.. The State Government shall furnish the Utilization certificates of the Grant released for the
PMAY-HFA (Urban) in the prescribed format as per GFR - 2017 and as provided in the
scheme guidelines.

ili. | The funds shall be utilised for the purpose for which these are sanctioned: otherwise funds
will have to be refunded along with the interest as per provisions in GFR — 2017. No
deviation from the framework for implementation of PMAY (U) is permissible.

iv. State should ensure immediate rollout of EAT all ULBs.

v. 58810 ensure immediate utilisation of balance funds lying with State/ULBs/IAs.

vi. The expenditure on the implementation of the scheme/projects will be shared between the
Central and the State/ULB/Implementing Agency (IA) as committed. The committed State
share should also be released within 15 days from the date of receipt of Central Share in the
SLNA account. in case of shortfall of State/ULB/IA share, corresponding amount of Central
share will be deducted from the subsequent instalment(s).

vii. The funds including Central and State share will thereafter be released by the State/UT
“Government to the implementing agencies without any delay failing which the amount would
be recovered from the State/UT Government with interest, as applicable, for the period of
default.

4-4० Page 1 of 2

<!-- page 3 -->

viii, Necessary sanctions/ approvals/ compliances fequired under the statutory or other
regulatory regime as applicable would be obtained by the authority (ies) concemed with the
project {s).

ix. The State Government and implementing agency shail put in place a monitoring system to
ensure that the project (s) achieve its scheduled milestone and envisaged outcomes
including implementation of reforms and other conditionalities required under the scheme.

x. The State Government/implementing agency shall utilize the grant in accordance with the
approved guidelines of PMAY (U) for the implementation of the Scheme.

xi. The State Govermment/ULB shall provide funds as per approvals in the projects.

xii. | The State Government/implementing agencies shall utilize the grant in accordance with the
approved guidelines of PMAY (U) for the implementation of the Scheme.

xiii, The State Government shall furnish Utilization Certificates of the Grant released in the
prescribed format as per GFR — 2017 to the Ministry of Housing and Urban Affairs as
provided in the scheme guidelines.

xiv. The agencies responsible for implementation of PMAY (U) should get themselves registered
on PFMS portal.

xv. Where there is an element of cash transfer to individual beneficiaries, the same may be
made through PFMS/DBT mode as applicable and necessary transaction details may be
updated in MIS immediately after the disbursement. The State Government shall submit an
authenticated certificate from the bank showing complete details of disbursement of funds to
each beneficiary before release of subsequent instalment.

xvi, The State Government shall ensure the geo-tagging of all these projects approved under
PMAY (U) for monitoring of progress of construction.

xvii, State Government shall ensure that the specifications of the houses conform to NBC/IS
Standards and that requisite infrastructure will be provided by the State Government /
ULB. State Government shall submit the Action Taken Report (ATR) .on the
observations/recommendations of Third Party Quality Monitoring Agency (TPQMA) for
quality monitoring purpose before release of subsequent instalment.

xviii, | State shall comply with Model Code of Conduct while teleasing funds to implementing

agencies/beneficiaries.

4. The payment may kindly be made to the State Government immediately. The funds may

thereafter be released to the implementing agencies without any delay failing which the amounts

would be recovered from the State Government with interest for the period of defauit.

5. The amount is debitable from the account of the Central Government in the books under the

following Head of Account under Demand No. 57 of Mlo. Housing and Urban Affairs for the year

2020-21.

Major Head 7 ऊतत ।

[6

Lo

BubHead | ot

Ca

Ls ०

4.७८
Page 2 of 3 है

<!-- page 4 -->

6. The amount will be credited to the State Government's account in RBI as
per procedure laid down by Ministry of Finance, Department of Expenditure vide O.M. No. F-
I(48/76/SC) dated 22.02.1977.
7. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee institution (s) /
Organisation(s) shall be open to inspection by the sanctioning authority and audit, both by the
Comptroller and Auditor General of India under the provision of CAG (DPC) Act 1971 and internal
audit by the Principal Accounts Office of the Ministry or Department, whenever the institution or
Organisation is called upon to do so.
8. This being the 1* installment of the Central Assistance under PMAY (U), No UC is pending
from State Government against these projects.
9. This issues with the concurrence of the Finance Division vide their Note# 28, dated
23.02.2021.
10. This sanction has been registered at SI. No. 434 34 in the Register of HFA Mission
Directorate (HFA-III Section) of the Ministry of HUA for the year 2020-21.
Yours faithfully,
Za
(Sanjeev Kumar Sharma)
Under Secretary to the Government of India
Tele No. 011-23061285
Copy to:
1. Pr. Secretary/Secretary Urban Development /Housing of State Govt. of Gujarat.
2. Affordable Housing Mission, Block No.2, 2nd Floor, Dr. Jivraj Mehta Bhavan Sankul Old
Sachivalaya, Sector 10 — B, Gandhinagar (Gujarat) — 382010.
3. Accountant General (A&E), Gujarat.
4. CCA, MoHUA.
5. Director, FD, MoHUA.
6. Budget Division, MoHUA.
7. NIT! Aayog, SP Divn. / DR Divn. New Delhi.
8. Ofo CGA, MahalekhaNiyantrakBhavan, New Delhi.
9. Dir (HFA-3), MoHUA.
10. DDO/Section Officer (Admin-Il), MoHUA.
41. Dy. Chief (MIS), MoHUA to place this sanction at appropriate place on the Website of the
Ministry.
12. PMU (MIS), HFA Directorate.
13. AO (HFA), MoHUA.
14. Sanction folder/File copy. हि ao :
. Lae
(Sanjeev Kumar Sharma)
Under Secretary to the Government of India
Page 3 of 3

<!-- page 5 -->

g x 5
५ 3 8 3 :
3 a :
3 2
2 8s
=a
डे 2
a «|S
ड़ Es
< 3 =
z
Ze हि 3
fs. 5 5
23%
553
; S22\38
8 5583
5 zs
3 2338
a 85:
के ड्ड
s
< c
2./| §
ad
es eg
g $8
g\| 38
8 2s
ae|| >
gs
a e a
85६ 3 g
gg z
ge 8
R= Sa
<8 3a y
Zz 6५ 18
a< ca
E§ 3
=< 5 a
ui Oo 2
SE z 3 \
fS< 3 कर
टन “aA
a g 3) NA
हू नष्ट
$8 न
23
aR
ag
38
ge
as
as
ig 2
58 gs g
£8 34 g
as z=
23 gé 8
es #8 5
zy 82
#2 डे
s* # 2-5
3 ape HE
oa ata Zz
2 25382
ड़ =ese2
=
= g 2829z22-
2 Sea z<
g Ss 2e>50458
8 = eae<225
है ogseara
2. Beegess
s 3 0258५७
2 Z25ea25E
a OmOura
1
an बट a
बंद
SSFRES%
a eee
55985&509<%
8_| $ ||
&
=
eS
$5
SE
25
8
| $ [ - [|
