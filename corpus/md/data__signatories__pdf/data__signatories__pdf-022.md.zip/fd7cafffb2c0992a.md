---
doc_id: "fd7cafffb2c0992a"
source_url: "https://www.mospi.gov.in/uploads/administration/administration1772016811619_e1c4e995-9fdb-4113-992c-377bf049407a_1768553543_Office_Order_dated_16_01_2026.pdf"
ministry: "Statistics and Programme Implementation (MoSPI)"
title: "Office Order dated 16.01.2026"
date: "2026-01-16"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f1010be9ee0fbce9"
---

<!-- page 1 -->

‘ARB /No. A-20002/31/2025-Ad.1-Part(1)
URd UPIR/Government of India
सांख्यिकी और कार्यक्रम कार्यान्वयन मंत्रालय
Ministry of Statistics and Programme Implementation
aaiia at WaA/Khurshid Lal Bhawan
orgy aM, Ag feceht/tanpath Marg, New Delhi
दिनांक / 0॥०१: 16.01.2026
कार्यालय आदेश/0ाप700 0र9एछर
In supersession of Office Order No. A-20002/31/2025-Ad.I dated 18.06.2025 and
partial modification of Order No. A-46030/3/2024-Admn.I dated 11.06.2024 & Office Order
No, A-22011/2/2013-Ad.I dated 19.02.2025, with the approval of Competent Authority, it has
been decided that the Additional Secretary (PI) and Joint Secretaries, MoSPI will look after the
work, with immediate effect and until further orders, as mentioned below:
IS. No. [Name &/Work Allocation Remarks
Pe Deigmae “ee F|
IMs. Puja Singh,|(i) Indian Statistical Service|
Mandol, AS(PI)_ |Division;
(ii) Media & Publicity Unit;
(iii) MPLADS Division;
(iv) ISI Division;
(v) Research and Analysis}
Division
(vi) Coordination &|
Parliament, RTI, PIGR;
(vii) Official Language;
viii) Legal Cell
2. |Sh. Supreet Singh|(i) Administration; fe will report to Secretary, MoSPI|
Gulati, JS \(ii) Infrastructure Projectithrough DG(DG) on the matter o’
Monitoring Division (IPMD);SSS Cadre and directly to  the|
(iii) State Unit; and Secretary, MoSPI for the rest of the|
(iv)Subordinate —_Statisticallwork.
Service (SSS) Cadre
3. |Sh. Ashish Kumari) Indian Statistical Service|He will report to Secretary, MoSP]|
(Gupta, JS Division; through AS(PI)
\(ii) Coordination &
Parliament, RTI, PIGR;
(iii) Official Language;
iv) Legal Cell
Mee"
(मुकेश PAR /Mukesh Kumar)
अवर सचिव, भारत सरकार
Under Secretary to the Govt. of India

<!-- page 2 -->

To:-

1. Ms, Puja Singh Mandol, AS(PI), MoSPI

2. Shri Supreet Singh Gulati, Joint Secretary, [AS (GJ:2008), MoSPI.
3. Shri Ashish Kumar Gupta, Joint Secretary, JOFS:2002, MoSPI.

4. Deputy Secretary (Admn./Vig), MoSPI, Khurshid Lal Bhawan, New Delhi.
5, All concerned Sections/Divisions

6. All offices of MoSPI through e-Office Portal.

7. Master Set — 2026.
Copy To:

1. PS to Hon’ble MoS(I/C), for S&PI

2. Sr. PPS to Secretary (S&PI)

3. Director(DIID) to upload the orderon the website of MoSPI.
