---
doc_id: "ff2ec31ece3479ce"
source_url: "https://mohua.gov.in/static/uploads/2025/10/1986c8d7cbab736d5023c063e691096e.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Transfer & Posting of SOs"
date: "2025-10-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7c5b42a7cd4d5e3c"
---

<!-- page 1 -->

No.4-220 1 3 I 5 12012- Admn.I(Pt.)
qTCfrq'Is-t-V Govr. of India
r6ft G-+m q"Tw"/ M/o Urban Devetopment

,

)c$r-l qtYr{T(/ (Admn.t Section)
Nirman Bhawan. New Delhi
Dated: 5- February 2016

OFFICE ORDER

The competent authority has decided the following transfer/ posting in the grade of

Section Officer with immediate effect and until fuither orders:S.No.
1

2.

Name/ DoB
Md. Mushtaq Alam
(7.s.62)
Ms. Asha Devi
(3.4.63)

Date of reportine
01 .01 .2016 (FN)

Posted at

Remarks

Dte. of Estates

Against existing vacancy

21.12.20rs (FN)

Dte. of Printing

Against existing vacancy

2.

The concerned attached offices are requested to take the officers on their rolls from the date of
their respective reporting as mentioned in the table above as Section Officer on regular basis for Section
Officer Select List year 2015 against seniority quota, in pursuance of DoP&T's OM No.6/10/2015-

CS-(S) dated 3 ll8l20l5.

%-) _

(S.K. Gupta)
Under Secretary to Govt. of India
Ph:23061426
To,

1. PSO to Secy (UD)/ PPS to AS (UDy ppS to AS(SC)
2. PPS to JS(L&Ey PPS to JS & Dy. FA
3. Dy. Director (Estt.), Dte. of Estates, Nirman Bhawan, New Delhi
4. Dy. Director (Estt.), Dte. of Printing, Nirman Bhawan, New Delhi
5. DG, CPWD, Nirman Bhawn, New Delhi.
6. Section Officer (Admn.), O/o Chief Engineer (IBBZ), CPWD, 2nd Floor, Nirman Bhawan,
Parivahan Nagar, Matigara, Siliguri - with the request to fumish the CR dossier in r/o Md.
Mushtaq Alam to this Ministry.

EE(HQ), O/o CE (NDZ)-N, CPWD, Nirman Bhawan, New Delhi - with the request to furnish
the CR dossier of Ms. Asha Devi to this Ministry.
8. Officers concerned.
9. Sh. V. Srinivasaragavan, Under Secretary (CS-D, DoP&T, 2nd Floor, Lok Nayak Bhawan, New
Delhi - w.r.t. their above referred OM.
10. Ad. tV/ PI CelV PG CellllT.Cell for uploading.
11. Disciplinary seatl Offic7brder file/ Guard File
12. NIC for uploading in the ministry's website.
7.

1

3. F.No. A-3201415 120 1 S-Admn.I
