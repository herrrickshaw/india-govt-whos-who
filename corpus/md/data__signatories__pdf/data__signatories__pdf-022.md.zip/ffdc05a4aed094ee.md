---
doc_id: "ffdc05a4aed094ee"
source_url: "https://consumeraffairs.gov.in/public/upload/files/Recruitment%20Rules,%202022%20%20for%20the%20post%20of%20Junior%20Translator%20in%20National%20Test%20House,%20Department%20of%20Consumer%20Affairs_1763698510.pdf"
ministry: "Department of Consumer Affairs (DoCA)"
title: "Download Amendment of Recruitment Rules for Junior Translator , NTH"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "23a600288c4451f5"
---

<!-- page 1 -->

732

THE GAZETTE OF I.ND[A: AUGUST 20, 202ZlSIiRA VANA 29,194'1

(1)
12. l'v!ulli Tas!iillg
Staff

(2)
9~
(2022)
,. Subject to V",iMioll
dependent on workload.

-

(3)
Not .pplienble

(6)
B~I\Vecn eighteen and twenty five years.

(7)

(3)

Not ap;>licable

I

(10)
I3y direct recruitment

(Il)

No: apnlicable

I"
( ·JI

consistin:;_ of _

NOl zprli:aol[:

Director or ill his absence an offiocr to be nominated by tlre
[Soard under section 24 of [he Act

-Ch[!!irnall

(ii)

A nominee of tl.c District MJgistrat. and
Collector, Rarnpur

-Member

'iii)

An expert to be co-opted, if necessary, by 1;'0
Chairman Oflhc: Sclccrion Ccrnrnirtcc

-- Member.

(il

No! orrlie.ble

10'" pass or eql!iv~lent from J
recognised board.

(12)
Selection Cornmittee

(5)-

Level-l
(R5. 18000-5£900i.

Note: The crucial date for determining tile age limit shall the
closing date for receipt of applications from candidate in I"Jb
and not (!,e closing tf.r~ prescribed for those in
Assam,
\-Ieghalaya,
Arunachal Pradesh,
Ivlizorant.
[\'fanip:J(,
Nag,bnd, Tripur., Sikkim, Lahul and Spif district and Pallsi
Sub-Division of Charuba District of Himachal Pradesh,
Andarnan ami Niool>ar Islands Dr Lakshadweep "Old Uuio»
territory of Ladakh) .. _

(9)
Two years

-

(4)

I

(Relaxable for Government Servant or Scheduled Caste or
Sdleduled Tribe Of Other Backward Class irl tire accordance
,,-,ith ir.stmetion or orders issued by Central Government).

[PART 11--5rc. 3(i\1

(F. No. 2".412020-Libj
U'''!A NANDURJ, II. Seey.

;;{~.

16 &1'1.-<1,2022

m.'f.T_f.t_ 111.-~Fct,
mm;:r ~ 3i1....
<1il 309 it;~IiJTI~
~IRt,·fiIf,T'1<i't1f ;p}r s'f:;f;-J:
~
'!il!ff1lT ~rrnT(lfof.h;o ~),
It-m Rrn1. 2017 ~, ~ <mIT it; fucrr>.r m'!hr.i<r m §'Z" fir-%' ~
arfIDiil1"f if 'J:'f f?i;on 1P-IT ~ '!IT m'f.T <frq-'~ 1fIn t \l'T>n'RlT;fTl'ltf ft~wr,\N\TI<m '1Tl'Iir. em. 3ir::
~
f.itrorr "timr.r, t 3fEfr.;- uq_')c; qft~fOT qiTm it ~
3~
~ tR" If\ ..,'if ;t;'r 4.;Ri ;r,r
f4fii"f?la 'liB ij;- fFnr ~--:rf@(r f.l<rq- q;n-ci" ~ 3,"'~ia:.

<!-- page 2 -->

>1

( •.:r,;r If --!iiVir 3(i

733

m+r Zih: IDT- (1) ~ ft<n:r tl"!!)"

1.
~
2022 ~I
(2) iT ~

if !f'!iT~r::r;ft arfur;ir '!T¥"[tfrl

m;f.t mm. <flf~

2.

'1cr~T'lT~mH,<Fm--<flTiIT ('l'R-GC: 3t~~)

~

~tf'f '4~

it ~.-tR

*;.nrrr ~r.,~

<f.t mr. '-i'1<foT ~
iTRI"T (4) itMR~~1

q~4'fl iTRR~Wm;;frR<ni'fir~~~f&~(2)

3.
'>TIff;fiT ~..-fct. 1Y,~-tfhrr.~Im $nt. 3!lR.~
'R tn.. 'l1<ff iff q~fct, ~-m'IT,
aih';offir mIT1r?' ~R <lTd' if ~r.IT uri' ;r-.,.'"(f ~~~
~ m}T (5) ir
(13) it' fu~
~I

-m~

4.

1m f.P.m,

~iRn;
z; ~cl ,,~

0!Jfu--

~.-~
~

o1fRfi iI', ~ <iI~ ~

(lZi) f,?,!1; ~

qfu 1fi tr;;fr ~

(<ii) ~

t 1fi ~

<liT tf~

~ ~: f.nm qfff 'IT ~

qc;fr -rn'Rf

~, 1fi

.o;~d ~

g\( wJ'r ~

ii~

~

t ;;<f'd' q; 'IT ~fu; ?[;

~rmr~l1iT;
1ft[ lif1;: ~.1fI'i ~
ipT ~
ITlriUR ~r ;;mrr t f'i; itm~
~. o~ re, 3]TT. foI;rr~ ~ .~1'1T'Hf'I'TT.
,,~ <TT1J:?fi1r fmr ~ are."l., J~I ~ 3lf< ~r m~F.rc: 3F<r 31i<IR ~ ciT ~ Mr oq RI, q,"t ~ fifirq- t.
'I!<Rf;r iT W hi~,'ill
5.
;;if,;;

liiB <lit ~rfa;.~

~

~

'P:'fT 3rr<r~«iFlIT rrrtl<lT=i~, <iQ.i 'TQ

mom: ;f.t ~ U<r ~ ~ ~

Rrc: ;;iT 'foTtIlj~, ~ <W<r.;r m. ~ f.flfl'iT ?j;. ~.

\3'CI"'-t~r '!i'r mfr'l,r lIT m ~ ~

<Rr <mo.

~Tc:~iGro fuf<m ~ ~fTl

6.
~.-B
R<Pft <f.t ~ cfRf. frir 3lT\f:fVT. 3n~-~ if W 3IT<:'R ~
'IT v"fr<r;rtf
~wfr.~''f>T W.( ~?:m
m *-tu it 'l'1'f-tilnf 'IT. m:m-lI'{ a.rR~iTi!p 3r:filT':;,;,:!~r;<1 urrRl<i'i,
31 :M~cl '" 1VII Rl Ill, ~
frHoif atr{ W'f ;;:pr ~if'l' m ~ ~<IT ~ Rfq: ~u 'M'lT aroelCf ~I
'l7. ipT ;w:r

~.if.T~

cnff.r.\r.r

~fa.f-~

'f<fil q~ ~

if «I~

3f~'IT

(1)

mliO
3l~

~

(2)

(3)

5' (2021)

lW!A' ~

c· m"fIT ~ ir.rr ~
;mID<:

~
3f~1l'ill;r).

'1<

q;

z~

I

mm >nff ~ fmr ~ Ifr-rr

'llr

(3t~I"'GJ;jd)

".
'0
~

(4)
rtrt-6

<i11I. ~

(35400

~r

'<''11:(-

112400f-)

(5)

(6)

ani' q1:( ir Jrfihi ~T (~
mom: ~ru ~
R>v. >rc;
a,"¥~iT3{i\ ~u~~rr~ ~
11<'!>TU fl<i"':i ~ F.n:; 'IN <i'f
Wi> ~rr't1 <iiT"fT <I'Oal t)

~
'f"'~

3o'll fl'rn f.r ~.rTf7.d
~

~

~

~

'f<I'f 3rnWr

~

F'1 if iPiT,

~

~m <r~

<!-- page 3 -->

734

THE GAZETTE or INDIA: AUGUST 2et,2022/SHRAVANA 29, 1944

,fhfr ..rcrr ~

;;rf.r ~

Rr, <iT ~

O<j

111W .rtff ~
'Ift<ft-..rr
~-Thi, 'lfCff;f,t~,
wn&ra- ~r::r
Grof "'If$7fr m- ;f.'rt ~r1

~

~lm~;wq-~

~ fi:nl: M~i1 ~

(8)

<1'l1J:;;-@ ~
!frc<r

~

-I'

mar ~ mn

<IT ,,-q-

~:

if lfi' <R <IT .3ffi'l<r; ~ fmt' ;~T'8'

11To<ni ~; ~

~-zfl: 'iff

f.t;ffi

T,j"fqf

lfT'l"«IT

fif~qf<!<lni<f fr ft!fT 'f<R"
3f'RT cl.,f(:q""

it 31"'<rr ';'T1rirT
~ 11T~">.fJ1ij;- 0r if ~ffi';;fT
(i1lT ~"'
!fTe~ <'r", ~
~

3f<T<iT 3;"S;fT

'N UI,,'1l~

~r ..fi ~
tr.it; <IT

ii' 'RT ('"111 <1 "

~

~

'ilRl

"?r R"1ft 'Rf\

'1{ 3jj.;qIQ

3f'.rqr

~

~

il' 3f<i'ij wan

ftcfr

~ llTfll'li ~ ~ 'if
<NT
3rnuf1'11V,ftT fr eytt ~

I atfr;;ft '!iT ~I~"'{~T ..rr
~ii:

~

f%1:r1

11"RCIT

f<r~~

DTI.m

('P) (i)

~r

'R'Uift>i!

urI ~

'R" ~m:ur

"?r

~

~ Hi;;f,T1

3lf'ifIT rrr

m;f~t: m

Oi) m 4f%'ft1

I

!{ RIT-6
(3S400-112400~,) ~ <P.T if
qR <:Cf

<it f.1'lf'qo il"fr ~

<W.f; 3il-;:

(cr) ;;rf ~~T 7 r,; ~d'l"T tj:hFr

~mf.i;U; 011';' wi

?q']~

fult P~

3ih" 3,~

*'
m&1

'"

fu'o:rcft 1: R l1{'\!"R i;; ::nf'r lIT

fif~<n~
i;; ~

st ft~;'Qi, ~

'r. Q:"-ci-

~

<rUm if;
it i%'"<fr ~ RP..r

wro if Rr~
rrr ~

'<; "ii'T'{Uf

t1 ,<J;f(

.. ",~q'1'

<IT
3f'.(9T

~?r;

~

if fi;lT HIT I

~~~

Rcnr

"f)'I"J lIT)

'!IT <'hIT
lIT f.:r;fT 3R "Iftff'-lTh"

<~

mea'

"i\: ~

rrr

'l"WTU ~ lfffif~

3f'O"1!1R ~

amrr ~
~

qrffi

----I

-+'_----::c.c.(9"-.)
,-----t~~;:::-=:=-'"(-10~)

~~<tfil .. T<P-1 it rn-:fr ~
rrr "11-.'114'~
[qq'l
ar>rowm ~ lTf<'?pf ~
~ if
trN ~
it
~
T?'!.1-; <IT

R>m

q~fd~-I rnT'IT ~

ftftr;<IT <iif ...mr~1<1ciT
i

(7)
1fq>m

3f'.rqr

if <-1l'lJ: ifilfy

<IT?!

~

~rn;;ro

em

mrl 311B<'1..f em ;?j1T I

lfm-~

3rr-c ~'ITlR;~il'rtt
~"'H(J ·qRI,l,ii ~
<;"m

'PiT ffi-JT

13f~ ~

J(il]

[PART II~EC,

g.!iT; 'iff
'ilRl

if mtr «IT

rrr "1Mq I·f 3ftf'iT ~

f.Tcr<r .~ ~ it ~
a~

3j1ffi

~
t,- m~ 3f~:IT
m if <!?r{ ~ 'iftm ~
l1T~"'.flf ~ ~
if
3F<f

am:

frn ~";:<f 4'10'1 'l!T ~'ifPT it ~
F~ tl· W. ~ mfur fum'
'0<-;j-,m 'R 'R II fd r::;;\ ~;; <f.'r
ifr a,--;ffir fl f~<1 )
3lPf <11\ q <fi;;' eN if 3rf~ ~
ap.j'

'~{,.fm- (!.[<i j.; !iRt;

~i

2: ~faf;jgf\l1 rrr f.p;!fu> iF
arr1hd'l ;?j1!-m-crr 3l,q<~
;;'fqf ;;;;B ;f,j ~
ell t)", <;iT 56
~ ~ a{TU<i; 'Iff irfh
~
~

<!-- page 4 -->

[~"TIiIH.'~ 3(i)]
735

arf.m!f q-<rr ~"I1r;q-'f' ~Cf
~ ~

~r.~cIT 3f~

.q-

3s~T

<it ~I';'f", mit m-

~"Q"l[

~

fffi;

~

am:
~

ti?..fT'T if

liFl!'aT ~

ft-;fr ~ at~ am- f<l~:
~
it ~
ar!l'1T

~

~

~

m'iil\

$ ~

on:nrr

~

~q",q

3f~"{R!f

mm~~it~·
ir ~
3irt f4"'lia:
3fl'!R m 'it 02 cnf ;;;r

ar:i'fCi1

R:arufT 1;

31401•.!, ;.;;:r

'ffi11IT ~ R~ :;fr arr<fl.Ii
~

3f'I:err~;j;t

it

~fT

mm 'il<R" affi1r '1fT
<r~
~~q;litll~

v.rfcl1;;Jfr
~
fufu=r ;f.T ;;rr

~~I

ft.zrufT 2: 3fJ"'1'i ti'cf2,"r

a,"t<rr ~

"f<F1 ~,

<rafll"
>ITT~
fqq'i'>lj!ir~
~
~
err
~

;;,

~,., Jt Ifa !Ii ~ 3I1-<rrfiliIT .if;r

it ~ ~
<&t Gil
U<Hft t \iICf -q q., ~ fq..--.ft
~fT

mt>'Il

tIT

'l<f.'I"

~

"Inittr lIT u:.-r.r 1I1fil'l'lft
~ ~ Ulf ~ f.l; ~
fmJ;
3!Rfucr fmrm ;f,j \n7; i;;

lm{ ~

~\{q

~

~

\R

~

'l'

~!T

~

;fiT tt>mi"IT

3I1-<ril<flIT it. '1<J'\i:(r .mr it
~~I

iIiwftcr
$:"i'I'T1~
~~i

l

<!-- page 5 -->

736
THE GAZETTE OF [NDrA : AUGUST 20. 20221SHRAVANA 29. 1944

rpAP.TIi-SEC. 3(i))

=-

2.

3.

f.;t~rr..~"R 'ffrefUimBT

~~<1iJ:1'F',r,
(iq;I,.; tfTIej1lmmr

-'H<?~

I

['hI. tf T:-12018/03/2011-\;.'fihfil (BIT.)]

MINIS1'RY OF CONSUMER AFFAI{{S, FOOD AND PUJ3LlC I>lSTitiII crrox
(Dcp"l'tnICl1t

or Consumer A(i~irs)

New Delhi. the !6th August. 2022
C.S.R. I J I.-In exercise of th~ powers COll[C'T:d by tho proviso to article 309 of the Constitution. and in
supersession of the Netiona! Test House (Junior Translator) Recruitment Rules. 2017. except as respects tlringsdone
or omitted to be done before such supersession, (he Presidcut hereby makes Hlc foflowing rules rcbul;niag the
method of recruitment co [he post of Junior Translator in IE1':National Test House, KOU,Clt:1, under the rvfinislry of
Co"untcr Aff.irs. Food and Public Distriburion, Department of Consumer Aff:lir.s.Ilamely:1.
ShDrt tirlc and comnrcncement.-(l)
Tran$btor) Roc(uiCmcn( Ru;cs, 2022.

These rules maybe called the National Test House (Junia-

(2). They shall come ioto force 011the dale of their publication ill the Officia] Gazette,
2..
Number of post, cl.ssiiicoiioll, Icvcl ill pay m.Cl'ix. - The number of post, it's classification, level ill Ole
pay matrix attached thereto sh.~Ube as specified in columns (2) to (4) of the Schedule annexed to these rules.

J.
Method of rccr'uitmcut, age-limit, edueationnl qu.liiic:!lions, etc, _ The method of recruitrueat, agelimit, edl!calional qualifications and other matters rel.lting ("0 the said post sh,1I be os specified in column, (5) to (U)
of lite Schedule.
4.

Disqualilicl(ion. - No perscn, _
(a)

who has entered into or coutrectcd a JllClrriagc with a person h~vin~ 2 spouse living: or

(0)

\,,'110. h:lving a spouse livinz. has eutercd inCo or contracted a maningc with no)' orh:!f person,
shall be cligil>1cror appointment [0 the said po<l:

Provided that the Ccntrill Governmenr may, if slttisficd. (hat such mUliage Ii p:rmis.;iblc tlnd~r thc
pcrsoll"la\v applicable to such person and other pJr!y to the marriage and [tra!there "'" other grounds for so dOing.
exempt any p:rson from [Ireop~r.tion oftllis rub.

5.
Power 10 relax. -Where Ihe Ce:llral Govcmmcnt is of the opinion tlrat it i:; n.~eessaryand e.~p~dicntso to
do, it may. by order and for the re•• oC!sto be rec!')rdcd it: writing. rda,; any of tit~ provisi OilS of these r"les with
r\}spcetto 3ny class or cat~gory of rersons.

<!-- page 6 -->

C'lT'T II-i'J'If> 3(i)]
7Ji
6.
S~vi"g. -Nothing
ill these rtlles sh,1I affect re3ervation, rdaxution of age-limit and oH,cr concessiolls
required (0 be provided for the Scheduled Castes, III" Scheduled Tribes, ex-Servicemen and other special cnt~eorios
of persons in :locord.:}c! wilh the orders issued by 'the Central Goverument lrom time to time ill thi~ ("pro.

SCHEDULE
Name

post.

of

Number
posts.

of Classification.

ILcv~l
in pay \Vilether
matnx,

Age limit for direct recruits,

selection
post or non
-selection
~ost.

_1!1
...f._2)
(:u_
_Hl
_.~(5~lNot --t-o-::-..
- --::---:-.,....1<,..,.6)
r.j::-u,-u"':·
o-rJ----r-::5::;·':-';(2~O:::2::-2:c):-T-::G:;-O!-1-le-ra'-;Ic'---;;fLc-'-'\-,C71-6~.-~
Not e.\cccding thirty years.
Translator.

«Subject
10 variariou
dependent

all

workload).

Central
35400·Service, Group ts.l i2400i-)
'W,
NcnGazeued,
~fillist~ri3J.

applicable.

--1

(Rela;(ablc [or Go\'cnllllcm servants
lip to five ye ars in accordanee with the
instructions or orders issued by the
Ccurral
Goverument),
NotoJ.- The
crucial
date
for
determining the ngc:-limit sh:!ll be as f
advertised by the Staff Select i On
Cornruissiou.

Edllc,l!ionnl and ocher qllnjifjC~lionSI Whether
required for direct recruits.
and

I

Essential:
Master's degree III Hindi with
english as Il compulsory or (!kc(iv~
or

as

a

educational
qualiLications
p,escribed for
direct recruits
will apply in
""S"
of

Period
profJatiun,

medium

of

c!;~a1l\rnation at tI,e dc-grcc level from
a recognised University; or

Not applicable.

of
if

Method of recruitment, whether by direct
rccruitrncnr
Or by I'n:unatioll or by

Of/

any.

..
__ 4-ln~r.::;~m::::::::~~c:;;~~=::s::..
-+--(;;;')-:-)

t-------::(7"')--

SUbject

age

dCl'ur~lion{absQ[]JtlOn and percentage
the vacancies to be filled by various
method.

--+------.~(
1:-;;0:;") -

Two years.

__

----'~..__

By direct rccruiunent.
: Vacancies caused by the
incumbl!LHS being awey on depu(ati~1\ 0;IOlla illness or study leave or under other
circumstances for D duration of on-..: YCJr
or more may b-~ filled by depu~1tion ba;is
Note

l'.Ifaster·s degree in EngIiih widl
Hindi 3$ ~ compulsory or elective
iubject
or as a m~dium
of
examination al Ih~ degree level from
a recogni.ed Ulliversjt)~ or

from nmong the onidals of rIll! Cenlral
Govemmt!'nt,w-

Master's degree in an)' subject othcr
tila!! Hindi or En~lis!t. will> Hindi
medium aud English as a compulsory
Orelective subject or a, a mediulO of
examination at the degree It.:'1cl from
a recognised University; or

(li) with five years rcguIJf service in
post. iu Icvd-6 (Rs.354CO-112~OO)
in the pay matrix; and

Master's degree in tiny subject other
than Hindi or English, with English
mcdi!Jnl and Hindi as a compul,ory
or elective subject Or as a medium of
examination at tIl.:: de,gree J.Jvel from
a recognised University; or
Masto!r's dcgrc" in any subject ocher
Ihan Hindi or English, with Hindi
.!Id English~:;
compulsory or
cl"clive subjects or ciritl!r of the two
~s a mediwll of exami!1ation and the

(a) (i) holding anJlogous posts
regular basis; or

0"

(b) possessing the qu"lilicariol1 altd
expC!rience prescribed
fo:" direct
recruits under column (7).
Note J. The ('eriod of deputotion
(including p~riod of d!!P'JI.tiQn) in
another ex-cadre po.t held ill\!Iledi~tcly
preccding this ~ppointmcnt in the s~rnc or
some cUlcr organisation or dcparunenc of
the Coutc.l Government sh~li ordinarily
not exceed thre~ yt!li"S.
Note 2. The maximum ~gc-limil for
nppoimmem by deputation shall not be
exceeding fifty-six years as On the clo:;illS

<!-- page 7 -->

736
THE GAZE1TE OF INDIA: AUGUST 20, 20221SHRAVANA 29,19014
ether as a compl/liory Or el(:<:til'~
subjcc; at the dcg,~c level from a
r~.:ognised University; and
Diploma

0: Certificare

[P'.RT if-SEC. 3(i)]

date of receipt of applic<!r-jo:1::i.

Course ill

translation from Hindi to English aud
vice versa (i'om any rc,:.ogllised
illstitu(c or two years' experience of
rrallsi~!ion
work Iroru HiJldi 10
English and vice versa in anv Cenlcal
Govt!rnment

or Stilt:

Go~enlll1en[

Office, including Govcmme.n of
India Undertaking.
Note J: Quoli(ications 31'0 rcla,.ulo
ar the discretion of the Staff
Sel~r.tiol1 Commission or comperenr
autllorily ill the case of candidates
otherwise \\,,,11 qualified.

I

Nnte 2; The Qualification c~g3cding
experience is relaxablc a~ (he
djscr~tjc>n of the SI3ff Sel~ctiol1
COflllnissioo; or compelent autllO,ity
if! the CHC 0 f candidal", belonging 10
the Schcdul:d
Casres
or the
Scheduluci Tribes. if at any stage o[
selection,
eh..: Staff Selection
Commiision or competent authority
is of the opinion that sufficit:nt
number of e.1ndid.res frcm these
cOlllmunHic$ possessing the rcq~isi[c
c'p-,rience are not likely 10 be
available ro till up 'he vacancy
reserved for HIt!Gl_
fn else or

If a DCflartmCl1t~1 Promotion
composition.

by
promotion or
dcputationl
ebsorption, grades
from which
promotion or
rccruiuucnt

committee

c)..;ist$,

what

i:; its

Circumstances

ill

~vLiCT

Union
P\ltJlic
Service
Commission
IS
to be
consulted
LII
makin;i:
rcCmitOll.'nt.

deputation/

abscrpucn to be
made.
(ll)

Not applicable

_(12)
(13)
Confirll1ation
Committee
(Inr Consulration \Vi!hUnion
considaation
Confirmation) conSisting of:Public Service
J.
Director General, Natioual
Commission is nOI
Tcsr House
necessary.
~. CJ~aiq~~{:iOll
!
2.
Director. N.t;0:131 Tesr House

Group '.c'

OcpUrlmCnl"r

-iI

- M~mb~,

3.

Seniormosr Seientist D,
Nnlional Test House

-.Mcmbc;·

[f. No.A-12018/03/201 I-Ntll- (ESlt.)]
PARAMlIT SI!'(GH THAKUR. UnJer SC"y.

Uplo.d,d by Dto. ofPrinling.r Oovernm~nr o({ndi~ :'."'. Ri~: Ro.d. 1:1~Y"l'u'i.Now ~oIhi.t IOOG1,,,,__ ~,"~ •.
and Puulished by II," CO"lrotlcr or rubllcll,ons. Deli"., 1005.1. AlOK KUMAR e•• ""M'" .....,.,.
