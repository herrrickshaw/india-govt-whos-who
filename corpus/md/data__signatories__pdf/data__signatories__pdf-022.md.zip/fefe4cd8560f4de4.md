---
doc_id: "fefe4cd8560f4de4"
source_url: "https://www.darpg.gov.in/static/uploads/2025/10/92223f16774eab71e00a3ae67fceab5b.pdf"
ministry: "Department of Administrative Reforms and Public Grievances (DARPG)"
title: "Delegation of Financial Power Rules"
date: "2023-12-13"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d9ace8c8f3693688"
---

<!-- page 1 -->

No. G-17012 / 1./2023-Ad min-DARPG (8403 )
Government of India
Ministry of Personnel, Public Grievances & Pensions
Department of Administrative Reforms & Public Grievances
6th Floor, Jawahar Vyapar Bhavan,
'l'olstoy Marg, New Delhi- 110001
Dated the 13th December, 2023

ORDER

In pursuance of Department of Expenditure, Ministry of Finance's Notifications dated
23.10.2001 and 16.09.2003 and subsequent O.Ms l/ll/E.ll(A)12003 dated 01.02.2005 and
llTlE.ll(A) 2008 dated 30.05.2008 and in supersession of this Department's Order No. G1701211/2013/AR-Admn-l dated 13.05.2020 regarding Delcgation of Financial Powers
(Amendment) Rules 2003, competent authority has decided to enhance the Financial Powers
of Head of Department (HOD) in the Department of Administrative Reforms & Public
Grievances for incurring Contingent and Miscellaneous Expenditure under Schedule V and VI
of DFPRs 1978 as details given below, with immediate effect-

Existing Powcrs

Item

.A) Contingent Expenditure (Schedule-V)
Rs.l .00 lakh per annum in each
Recurring
:ase (without consultation with
rFD)
Rs.5.00 lakhs in each case (in
Non-recurring
consultation with IFD)
tB) Miscellaneous Expenditure (Schedule-Vt)
Rs.l .00 lakh per annum in each
Recurring
:ase (without consultation with
rFD)
Rs.5.00 lakhs in each case (in
Non-recurring
consultation with IFD)

2.

Revised Power

Rs. 1.50 lakh in each case

Rs.3.00 lakhs in each case

Rs.l.50 lakh in each case

Rs.3.00 lakhs in each case

HOf), Department of Administrative Reforms & Public Gricvances shall not be

required to consult IIrD in exercising the above mentioned enhanced Financial Powers.

3.

The following Financial Powers have been delegated to Additional Secretary/Joint
Secretary of subject matter / HOD, DARPG (over and above the delegated power) in terms
of Rule 4 and Rule l3(2) of DFPR, 1978:
sl.
No
I

Lcvel to which power Delegated Power (in
consultation with IFD)
is to bc delegated
Less than Rs. l0 lakhs
Expenditure sanction fbr Additional/.loint
but above Rs. 5 lakhs on
running office and associated Secretary concerned
each occasion.
activities under Schedule-V
ofDFPR

Items

/t

h ',1*,n -?/ I

Paee 1o 3

<!-- page 2 -->

2.

Contingent Expenditure

Joint

under Schedule-Vl of DFPR

(Admin) concerned
Addl. Secretary/Joint

Procurement through
negotiated or single tender or
propriety contracts as per
DFPR 2l(b)

Addl. Secretary/Joint

Agreement on contracts for
technical collaboration and
consultancy services as per
per DFPR 2l (b)

Addl. Secretary/Joint

For issue of administrative
approval and expenditure

Addl. Secretary/Joint

executing

IIOD. DARPG

Upto Rs. 5 Lakhs on each
occasion.
More than lts. 20.00
Lakhs and upto Rs. 1.00
Crore on each occasion
lJpto Rs. 20.00 Lakhs on
each occasion
More than Rs.20.00
lakhs and upto Rs.1.00
Crore on each occasion
Upto Rs. 20.00 Lakhs on
each occasion
More than Rs.20.00
lakhs and upto Rs.1.00
Crore on each occasion
Upto Rs.20.00 Lakhs on
each occasion
Above Rs.20.00 Lakhs
and upto Rs.50.00 t.akhs
on each occasion
Upto Rs.20.00 Lakhs on
each occasion
More than Rs. 25.00
Lakhs and upto Rs.l .00
Crore
lJpto Rs. 25.00 Lakhs

Addl. Secretary/.loint

More than Rs.20.00

Secretary concerned

lakhs and upto Rs.l.00
Crore
Upto Rs. 20.00 Lakhs
Full Powers

Expenditure sanction for

3.

4

Secretary

payment to agencies/ entities
in terms of approved valid
contracts/agreements/ MoU

Secretary concerned

Procurements through open

Addl. Secretary/Joint

or limited tenders as DFPR

Secretary concerned

HOD. DARPG

2l (b)
HOD. DARPG
t.

6.

7.

sanction (AA&tlS) for
under

Infrastructure/C ivil/Electrical
Works
for
the
projects/schemes approved
and appraised by the
competent authority in terms
of MoF OM dated 5.8.16.
Expenditure under IT (OE)

8.

9

Payment of leased lines under
approved activities

r0

Outsourcing
Housekeeping

Secretary concerned
} IOD. DARPG

Secretary concerned

I{OD, DARPG

Secretary concerned

IIOD. DARPG
Addl. Secretary/Joint
Secretary concerned

of

Addl. Secretary/Joint

staff/

Secretary concerned

Upto Rs.l.00 Crore

MTS/DEO etc.

4.

The above mentioned enhanced Financial Powers shall be exercised subject to

observance of the following:

Provisions of GGFRs/GFPRs, Work Manual, Economy instruction, Financial/Fiscal
Codes and procedures
b. Procedural and other instructions issued by the Government
a.

Page 2 of 3

<!-- page 3 -->

c.
d.
e.

5.

Any instruction issued by Ministry of Finance and Ministry Finance and Ministry of
Personnel, P.G. & Pensions from time to time in this regard.
Availability of funds and budgetary limits.
The above delegated powers shall not be further delegated to any other subordinate
authority without the prior approval of IFD/MHA.
This issues with the concurrence of IFD Vide their Note # 22 Dated 6.12.2023 on e-

flle No. 8403.

Under Secretary to the Govt. of India
Tele- 23367060

Distribution:
l. PAO, DoPT, Lok Nayak Bhawan, Khan Market, New Delhi.
2. AFA (Fin-Pers), MHA, North Block, New Delhi.
3. PPS to Secretary, DARPG, Sardar Patel Bhawan, New Delhi.
4. PSOiPA to Joint Secretaries, DARPG, Sardar Patel Bhawan, New Delhi
5. All Divisional Heads
6. Cash Section, DARPG, STC Building, New Delhi.
7. E-Office Notice Board

Page 3 of 3
