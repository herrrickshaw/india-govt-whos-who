---
doc_id: "fe13dba9ebf7031b"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/NITExtnA02-06_18052026.PDF"
ministry: "Department of Space"
title: "Corrigendum: VSSC/CMG/A0310612026-27 Dated: 29.04.2026      226.52 KB"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "30c57059ff0534b2"
---

<!-- page 1 -->

31ffif m<f)f{IGOVERNMENT OF INDIA
~ fcrn'miDEPARTMENT OF SPACE

~ ~ JiaftaJ ~NIKRAM SARABHAI SPACE CENTRE

f.id::ITur lJcf ~ "JJCriCONSTRUCTION AND MAINTENANCE GROUP
f.id::ITur 1Jcf ~ ~-~/CONSTRUCTION AND MAINTENANCE DIVISION-CONTRACTS
~

~

~

k1'6ao:iC1qMfTHIRUVANANTHAPURAM- 22/ (~./Ph. No.0471 - 2564568/2565726)
~

J-f!rftrnr *t 3rcffit ilalill/EXTENSION OF E-TENDER
~ /Dt. 15.05.2026
Sfl."ff

~/Details

fmRur/Description

Sl. No.
QCf1 <fliT ~ 3fCffU"

1.

m CflT ~~/Jitle of work

2.

~-~~~-I E-Tender Notice No.

3.

fa1Fclc:r ti" <fr dT$" 3101Jii~C1
~ I Estimate cost
..:>

4.

m tffi ~~~ I Period of completion

5.
51301('1~5

put to tender

"

~ "3fJiT ufil (~)I Earnest money

deposit (EMD)
~

3fCffU"

I

Period

for

downloading: ~ 30.04.2026, 17.00 ~/hrs
~I to~ 10.05.2026, 23.00 ~lhrs

Extended upto 23 :00 hrs. on 21.05.2026

~"

Emergency Maintenance Contract for Air conditioning installations at VSSC for a period of one year.

"

~

<t ~ q~ Q fl Qfl tfl <t aiC1101Cfl('I01 ~ <t ~ 311q1C1Cfl1Jl01 ~fifctml
..:>

q"IQflQflfl'l /'f1~QJi ,,1Vc!03/06/2026-27 ~ 29.04.2026

VSSCIC MGI A0310612026-2 7 Dated 29.04.2026
~11.94 ~ILakhs

1 (Q<f>/One) ifl~Tiyear
~23 , 880.00

~ fq~t'JCfl{OI I Bid clarifications: ~

01 .05.2026, 9.00

~lhrs

~Ito

~

11.05.2026,12.00 ~lhrs
Extended
22.05.2026

upto

12.00

hrs.

on

fa1Fclc:r3IT ~ ~ I Receipt of fa1Fclc:r3IT CflT man- I 0 pen ing of
tenders: ~ 13.05.2026 CflT

tenders:

23.00 ~/hrs

15.00 ~/hrs

Extended upto 23:00 hrs. on

Extended

26.05.2026

29.05.2026

~ 15.05.2026
to

CflT

15:00 hrs. on

L1

~~ 3"tf 1J3ITlT llf.nif, 'fft QJi ~ -m~ >~. d'l Q 'ft Q 'ft 'ffl
Deputy Division Head, CMD-CON, CMG, VSSC
