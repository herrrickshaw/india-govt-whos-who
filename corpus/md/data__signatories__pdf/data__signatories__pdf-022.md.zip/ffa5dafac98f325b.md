---
doc_id: "ffa5dafac98f325b"
source_url: "https://powermin.gov.in/static/uploads/2025/06/ea1d6307848893a142e0b675cf8a8572.pdf"
ministry: "Power"
title: "Coal linkage policy for 12th plan projects"
date: "2025-06-28"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "85bd68c30506c5ec"
---

<!-- page 1 -->

F.No.FU-9/2009-IPC
Government of India
Ministry of Power
…….
New Delhi, dated the 21st October, 2009
OFFICE MEMORANDUM
Sub: Coal linkage policy for 12th plan projects
……..
The undersigned is directed to refer to Ministry of Coal’s OM No. 23011/27/2008CPD dated 26.12.2008 regarding the shelf of 12th Plan projects and to say that in view
of the shortage of coal and a number of power projects proposed for commissioning
during 12th Plan awaiting linkage, it has been decided in the Ministry to adopt the
following methodology for allocating coal linkage for 12th Plan projects :A. Sector wise priority :
Following is the order of priority for allocation of coal linkage :
i)
Power projects of Central Sector CPSUs, state sector and projects to
be bid out by states on tariff based competitive bidding ( Case II)
ii)
IPP Projects
iii)
Captive Power Projects .
B. Prequalification of projects for coal linkage:
(i)
(ii)
(iii)
(iv)
(v)

Water allocation should be available to meet the full requirements of the
project and a certificate to this effect issued by the competent authority of the
State Government must be produced.
The proposed project should have clearly identified the location and the area
required for setting up of the power project.
Report of the State Government about availability of land for project purposes
should be produced along with evidence of initiation of process for
procurement of land.
The developer of the project should furnish the report of the Expert Appraisal
Committee of Ministry of Environment & Forests along with Terms of
Reference issued by MOEF.
The project developer meets the financial pre-qualifications as defined in the
Standard Bid Document for procurement of power through tariff based
competitive bidding (Case-I).
Authenticated copies of financial documents along with supporting affidavit
signed by the authorized representative of the Board or the Chief Promoter(s)

<!-- page 2 -->

of the Project have to be furnished. The promoter shall remain responsible
for the genuineness of the documents.

C. Weightage for priority :
Ministry of Coal will indicate the availability of coal for the 12th Plan. 60%
percent of available coal would be earmarked for the Central and State sector
projects, including the projects based on tariff based competitive bidding (CaseII).
For State sector projects, coal will be allocated based on the projected
demand supply gap of the State.
35% of the coal available will be earmarked for the IPPs and balance 5%
will be earmarked for the CPPs. Inter-se priority will apply for each category viz.
Central and State Sector projects including those to be bid on tariff based
competitive bidding (Case II) by the State Governments and IPPs. Prioritisation
will be based on points to be allocated as detailed below:
projects
Points allotted to Other
projects which are which are not
fulfilling
the fulfilling
the
conditions
conditions
1
Projects proposing installation
20
0
of units with supercritical
technology
20
0
2
Project at pit-head or in State
where no major power
projects have been planned in
the 11th / 12th Plan shelve
3
Projects using sea water
10
0
instead of fresh water*
4
Progress of land acquisition **
50
(i)
>25% <50% land acquired
20}
0
(ii)
>50% <75% land acquired
30}
0
(iii)
>75% <100% land acquired
40}
0
(iv)
100% land acquired
50}
0
Total
100
* Only the IPP projects located within 150 km from the nearest port will be required to
meet at least 30% of their coal requirements through import. This is not applicable to
SPSUs and CPSUs as Government is already fixing target for import of coal for them
Sl. No.

Parameter

** For weightage for progress of land acquisition, the developer shall submit a
certificate from the District Collector or the State Revenue Authority or the authorized
agency of the State Government such as Industrial Development Corporation. The

<!-- page 3 -->

responsibility of correctness of the certificate will rest with the developer as it will not be
possible for CEA to verify the land records.
D.

Captive Power Projects

For CPPs, linkage will be recommended for those who are having capacity more
than 10 MW.
Following industries for captive use may be given preference :
i.
ii.
iii.

Steel Industry
Aluminium industry
Process industries such as cement, textile, sugar etc.

2.
Cases of linkage for CPPs/IPPs having unit size less than 200 MW will be
considered only if equipment are sourced from reputed domestic manufacturers.
However, if the equipment are ordered before 24.07.2008 to others, linkage may be
considered.
3.
There will be no domestic linkage to power plants based on imported coal in 12th
Plan.
4.
For washery rejects, the ratio of coal and rejects to be considered is 22:78 based
on grade of coal. With bio-mass, coal as support fuel upto 15% may be considered.
5.

This issues with the approval of the competent authority.

(S.Narayanan)
Under Secretary to the Govt. of India
Secretary
Ministry of Coal
Shastri Bhawan
New Delhi,
Copy to the Chairperson, Central Electricity Authority, Sewa Bhavan, R.K.Puram, New
Delhi with a request to prepare a shelf of 12th Plan projects awaiting coal linkage with
appropriate marking against those projects.
