---
doc_id: "ffe50d1d1e8ec87d"
source_url: "https://dof.gov.in/static/uploads/2025/09/3a7eef0bfca9d9c171af9bcee8ba3ad6.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Guidelines for Solid  Waste Management in Coastal Aquaculture Units or Activities"
date: "2024-03-15"
pages: 11
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "184542f0c59ac082"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-18032024-253181
xxxGIDHxxx
CG-DL-E-18032024-253181
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 1392]
No. 1392]

नई दिल्ली, िजनिार, माचच 16, 2024/फाल्गुन 26, 1945
NEW DELHI, SATURDAY, MARCH 16, 2024/PHALGUNA 26, 1945

मत्सस्ट्यपालन, पिुपालन और डेयरी मंत्रालय
(मत्सस्ट्यपालन जिभाग)
अजधसूचना
नई दिल्ली, 15 माचच, 2024
का.आ. 1458(अ).— तटीय िलीय कृ जि प्राजधकरण जनयम, 2024 के जनयम 3 के खंड (छ) के साथ पठित, तटीय
िलीय कृ जि प्राजधकरण अजधजनयम, 2005 (2005 का 24) की धारा 3 के अनुसरण में, कें द्र सरकार एतिद्वारा
जनम्नजलजखत दििाजनिेि अजधसूजचत करती है, अथाचत्:1.
संजिप्त िीिचक और प्रारं भ - (1) इन दििाजनिेिों को तटीय िल कृ जि इकाईयों या गजतजिजधयों में िोस अपजिष्ट
प्रबंधन के जलए दििाजनिेि कहा िाएगा ।
(2) ये रािपत्र में उनके प्रकािन की तारीख से लागू होंगे।
तटीय िल कृ जि इकाईयों या गजतजिजधयों में िोस अपजिष्ट प्रबंधन के जलए दििाजनिेि
1.

सामान्य:

(1) पयाचिरण के अनुकूल तटीय िलीय कृ जि के सतत जिकास को प्राप्त करने के उद्देश्य से, उत्सपािन इकाईयों सजहत तटीय
िलीय कृ जि हैचरी, फामच, न्यूजललयस ब्रीडडंग सेंटर, ब्रूडस्ट्टॉक मल्टीप्लीके िन सेंटर और िलीय कृ जि इनपुट सजहत
उत्सपािन से उत्सपन्न कचरे को कम करने और प्रबंजधत करने के तरीकों पर ध्यान कें दद्रत करेगा।
(2) तटीय िलीय कृ जि इकाइयां अपजिष्ट उत्सपािन को कम करने के जलए तटीय िलीय कृ जि इकाइयों में उत्सपािन चक्र के
िौरान पुन: प्रयोज्य सामजियों के उजचत चयन और उपयोग का पालन करेंगी।
2070 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(3) सभी तटीय िलीय कृ जि इकाइयााँ गैर-पुनचचक्रण (नॉन री साईललेबल) योग्य उत्सपािों के उपयोग को कम करेंगी और
पयाचिरण-अनुकूल िैकजल्पक सामिी के उपयोग को बढािा िेंगी, जिन्हें आसानी से री – साईकल या पुन: उपयोग
दकया िा सकता है या डीिेड और डी कं पोस दकया िा सकता है।
(4) तटीय िलीय कृ जि इकाइयों से उत्सपन्न अपजिष्टों को अपजिष्ट िल और िोस अपजिष्ट में जनम्नानुसार िगीकृ त दकया िा
सकता है, अथाचत:् (क) अपजिष्ट िल- तटीय िलीय कृ जि इकाइयों से जनकलने िाले अपजिष्ट िल या अपजिष्टों को तटीय िलीय कृ जि
प्राजधकरण द्वारा जनर्िचष्ट प्रोटोकॉल के अनुसार, प्रिाह उपचार प्रणाली (एफफ्लुएंट रीटमेंट जसस्ट्टेम) में उपचाठरत
दकया िाएगा और सुजनजित दकया िाएगा दक खुले िल स्रोत में छोडे िाने से पहले तटीय िलीय कृ जि
प्राजधकरण जनयम, 2024 के जनयम 3 के तहत िारी तटीय िलीय कृ जि को जिजनयजमत करने के जलए
दििाजनिेिों के मानकों के अनुरूप है ।
बिते दक कु छ मापिंडों के जलए यदि मानक या जनधाचरण उपलब्ध नहीं है तो ऐसे मापिंडों के जलए जडस्ट्चािच
दकया गया पानी प्रिूिण जनयंत्रण बोडच के मानकों के अनुरूप होगा ।
(ख) िोस अपजिष्ट - तटीय िलकृ जि इकाइयों से उत्सपन्न िोस अपजिष्टों को आसपास के तटीय पयाचिरण को
संभाजित प्रिूिण से बचाने के जलए पयाचप्त िेखभाल के साथ प्रबंजधत दकया िाएगा:
(i) इकाइयां पयाचिरण (संरिण) अजधजनयम 1986 (1986 का 29) के तहत बनाए गए जनयमों के अनुसार िोस
अपजिष्ट को संभालने के जलए जिम्मेिार होंगी;
(ii) तटीय िलीय कृ जि इकाइयााँ िोस या प्लाजस्ट्टक कचरे को अलग करने, संिहण, भंडारण, पठरिहन, प्रसंस्ट्करण
और जनपटान के जलए स्ट्ियं या एिेंजसयों या उत्सपािकों के माध्यम से उक्त पयाचिरण (संरिण) अजधजनयम,
1986 के तहत बनाए गए जनयमों के अनुसार उजचत इनफ्रास्ट्रलचर जिकजसत करेंगी ।
2. अपजिष्ट का मूल्यांकन - (1) प्रत्सयेक तटीय िलकृ जि इकाईयां िेत्रों या िगों, उत्सपन्न होने िाले अपजिष्ट का प्रकार और
मात्रा, अपजिष्ट की जिजभन्न धाराओं के भंडारण और उपचार के जलए िेत्र की पहचान करेंगी, सुरजित रूप से उनका
जनपटान करने के जलए उजचत तरीकों या तरीकों का जनधाचरण करेंगी और एक िोस अपजिष्ट प्रबंधन योिना तैयार
करें गी ।
(2) िोस कचरे को बायोजडिेडेबल, गैर-बायोजडिेडेबल और घरेलू खतरनाक में िगीकृ त दकया िाएगा और कचरे को स्रोत से
इस प्रकार के िगीकरण और संिह, भंडारण और जनपटान में उजचत िेखभाल की िाएगी।
(3) उप-पैरािाफ (2) में जनर्िचष्ट अनुसार तीन अलग अलग प्रकार के कचरे के जलए प्रत्सयेक िेत्र या सेलिन में पयाचप्त िमता
िाले तीन कचरे के डब्बे अलग अलग रंगों में स्रोत से कचरे को जिभाजित करने और संिह करने के जलए रखा
िाएगा ।
(4) हैंडडलंग और अनुपालन आिश्यकता आदि पर साइन बोडच और पोस्ट्टर, उत्सपन्न होने िाले कचरे के प्रकार के अनुसार
पहचाने गए दकसी भी अनुभाग या िेत्र में प्रिर्िचत दकए िाएंगे।
(5) सुजिधा प्रबंधक िोस अपजिष्ट प्रबंधन योिना को लागू करने और प्रबंजधत करने के जलए पयचिेिकों के स्ट्तर से नीचे के
कमचचाठरयों को जिजिष्ट कायच सौंपेंगे।
(6) प्रत्सयेक इकाई को जनम्नजलजखत कचरे के संिहण और जनपटान के जलए उपयुक्त या अजधकृ त एिेंजसयों के साथ समझौता
करना होगा, अथाचत:् अथाचत:् (i) री साईकलेबल नॉन-डीिेडेबल अपजिष्ट;
(ii) एफफ्लुएंट रीटमेंट जसस्ट्टम से कीचड;
(iii) बायोजडिेडेबल नॉन-री-साईललेबल अपजिष्ट;
(iv) नॉन-डीिेडेबल नॉन री साईकलेबल अपजिष्ट; और
(v) घरेलू सीिेि।

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

3

(7) सुजिधा प्रबंधक सुजिधा से प्रसंस्ट्करण या जनपटान स्ट्थलों तक जिजिष्ट िाहनों में जिजभन्न कचरे के पठरिहन की योिना
बनाएगा और सुजनजित करेगा।
(8) पठरिहन को कम करते हुए कचरे के पुन: उपयोग या री साईकल की योिना बनाई िाएगी और उसे लागू करेंगे ;
(9) एिेंजसयों द्वारा कचरे की सफाई के जलए अलग ठरकॉडच बनाए रखा िाएगा।
(10) जिजभन्न तटीय िलकृ जि इकाइयों से उत्सपन्न प्रमुख प्रकार के संभाजित कचरे की सूची नीचे िी गई ताजलका में जनर्िचष्ट
है:ताजलका – 1
क्र.सं.
(1)
1.

इकाई का अनुभाग
(2)
ब्रूड स्ट्टॉक प्राप्त करने िाला
िेत्र

उत्सपन्न अपजिष्ट
(3)
ब्रूड स्ट्टॉक बैग, थमोकोल बॉलस (और कभी-कभी काटचन बॉलस), आइस पैक,
ब्रूड स्ट्टॉक पैककं ग और मृत िानिरों (ब्रूडसच) या मरणासन्न िानिरों के जलए
उपयोग दकए िाने िाले रबर बैंड।
फीड पैककं ग प्लाजस्ट्टक पाउच या बलसे, ठटन, या ऐसे दकसी भी पिाथच, फीड
ओिर, फीड अििेि और मृत िानिर (ब्रूडसच) या मरणासन्न िानिर।

2.

पठरपक्वता

3.

लािाच पालन

4.

पैककं ग

5.

प्रयोगिाला

6.

रखरखाि

7.
8.

प्रिाह उपचार प्रणाली
(एफफ्लुएंट रीटमेंट जसस्ट्टेम)
घरेलू

9.

बीि भंडारण

एकल उपयोग प्लाजस्ट्टक की प्लेटें, जगलास, चम्मच और अन्य बतचन जिनका
उपयोग भोिन, भोिन और सजब्ियों के अपजिष्ट, मल आदि को परोसने के
जलए दकया िाता है।
पॉजलथीन बैग जिसमें पोस्ट्ट लािाच या नॉप्ली खरीिा गया है।

10.

एक्वा इनपुट

प्रयुक्त जिजभन्न इनपुट के कं टेनर, पाउच।

फीड पैककं ग प्लाजस्ट्टक पाउच या बलसे, ठटन, या ऐसे कोई पिाथच, फीड जस्ट्पल
ओिर और फीड अििेि
पोस्ट्ट लािाच पैककं ग किर, रबर बैंड और िजतिस्ट्त पैककं ग बैग के बलसे या पैक
रसायनों के खाली प्लाजस्ट्टक या कांच के कं टेनर, समाप्त हो चुके रसायन,
िजतिस्ट्त प्रयोगिाला उपकरण, सूक्ष्मिीिजिज्ञानी प्रयोगिालाओं में कल्चर
प्लेटें, पॉलीमरे ज़ चेन ठरएलिन प्रयोगिालाओं में तैयार िैल आदि।
पॉलीजिनाइल ललोराइड पाइपों के बचे हुए/टू टे हुए टु कडे, छोटे और बडे िायु
नली, िजतिस्ट्त िाल्ि, रसायनों और अन्य कीटाणुनािकों का फै ला हुआ जहस्ट्सा
और सफाई के जलए उपयोग दकए िाने िाले स्ट्पंि या अन्य स्ट्क्रब।
प्रिाह उपचार प्रणाली से कीचड

फीड की पैकेडिंग सामिी.
11.

कीचड हटाना

संस्ट्कृ जत तालाबों और प्रिाह उपचार प्रणाली से।

3. प्लाजस्ट्टक कचरे का मूल्यांकन – (1) इकाइयों द्वारा दकसी भी समय दकसी भी िेड के प्लाजस्ट्टक को िलाया नहीं िाएगा,
और ऐसे प्लाजस्ट्टक को इकट्ठा करने के जलए उन्हें स्ट्थानीय जनकाय या जनयुक्त एिेंसी को सौंप दिया िाएगा।
(2) जिजभन्न प्रकार के प्लाजस्ट्टक और उनकी रीसाइडललंग जस्ट्थजत नीचे िी गई ताजलका में िी गई होगी:

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

ताजलका 2
क्र.सं

प्रतीक

संजिप्त नाम

िैज्ञाजनक नाम

अपजिष्ट उत्सपन्न होने िाले संभाजित
समजियााँ

(1)

(2)

(3)

(4)

(5)

1

पालतू

पॉलीथीन
टैरीजपथालेट

िीतल पेय की बोतलें, फनीचर, कालीन,
पैनडलंग, आदि।

2

एचडीपीई

हाइ डेजन्सटी
पोजलथीन

बोतलें, कै री बैग, िूध के पाउच,
रीसाइडललंग जडब्बे, कृ जि पाइप, बेस
कप, आदि।

3

पीिीसी

पॉलीजिनाइल
ललोराइड

पाइप, जखडकी प्रोफाइल, बाड लगाना,
फिच, िॉिर पिे, लॉन कु र्सचयााँ, गैर-खाद्य
बोतलें, आदि।

4

एलडीपीई

कम घनत्सि
पोलीथाईलीन

प्लाजस्ट्टक बैग, जिजभन्न कं टेनर,
जडस्ट्पेंडसंग बोतलें, िॉि बोतलें, ट्यूडबंग
इत्सयादि।

5

पीपी

पोलीप्रोपलीन

ऑटो पार्टसच, औद्योजगक फाइबर, खाद्य
कं टेनर, जडििेयर, आदि।

6

पी.एस.

7

O

पोल्येस्ट्रीन

कै फे टेठरया रे, प्लाजस्ट्टक के बतचन,
जखलौने, ललैम िेल कं टेनर, इन्सुलेिन
बोडच, आदि।

अन्य

थमोसेट प्लाजस्ट्टक, मल्टीलेयर और
लैजमनेर्टस, बैललाइट , पॉलीकाबोनेट,
नायलॉन िीट मोडल्डंग कं पाउं ड, फाइब
री -रीइन्फोस्ट्डच प्लाजस्ट्टक, आदि।

री साएललेबल या
नॉन री
साएललेबल
(6)

री साएललेबल

नॉन री
साएललेबल

4.
अपजिष्ट संिहण एिं अलग-अलग करना - (1) प्रत्सयेक तटीय िलीय कृ जि इकाइयां अपने स्रोत या खंडों पर कचरे
को अलग-अलग श्रेजणयों में अलग करें गी और उन्हें ढक्कन िाले जडब्बे में एकत्र करेंगी, िैसा दक नीचे िी गई ताजलका में
जनर्िचष्ट है:
ताजलका – 3
अपजिष्ट का प्रकार

बायोजडिेडेबल और नॉन री
साएललेबल

नॉन डीिेडेबल और रीसाईललेबल

(1)
जडब्बे का रंग

(2)
हरा

(3)
पीला

नॉन-डीिेडेबल , नॉन री
साईललेबल पुनचच और घरेलू
खतरनाक
(4)
लाल

(2) प्रत्सयेक 12 घंटे में उसकी श्रेणी के आधार पर कचरे को इकट्ठा करने, अलग करने और जनपटान करने के जलए पहचाने गए
प्रत्सयेक िेत्र में ड्यूटी पर व्यजक्त होंगे और कचरे को साफ करने के जलए ठरकॉडच बनाए रखा िाएगा।
(3) सभी कायचबल, जििेि रूप से िे जिन्हें कचरे को संभालने, भंडारण करने या अन्यथा प्रबंजधत करने के जलए जनयुक्त दकया
गया है , को जडब्बे के इजछछत उपयोग पर प्रजिजित दकया िाएगा जिसमें जनम्नजलजखत का पठरचय िाजमल हो सकता है -

<!-- page 5 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

5

(i) अपजिष्ट प्रबंधन के जलए बुजनयािी प्रदक्रयाएाँ;
(ii) मानिीय और पयाचिरणीय िोजखम; और
(iii) अपजिष्ट प्रबंधन आदि में एहजतयात के उपाय आदि

(4) नॉन डीिेडेबल , री साईललेबल अपजिष्ट िैसे दक ब्रूडस्ट्टॉक बैग, थमाचकोल बॉलस, कायाचलय स्ट्टेिनरी और सामान्य
रखरखाि से उत्सपन्न अपजिष्ट, आदि को ऐसे अपजिष्ट के अस्ट्थायी भंडारण के जलए जनर्िचष्ट िेत्र में अस्ट्थायी रूप से संिहीत
दकया िाएगा और सौंप दिया िाएगा। जनयजमत आधार पर रीसाइडललंग एिेंसी।
(5) बायोजडिेडेबल और नॉन री साईललेबल कचरे को ऐसे कचरे के अस्ट्थायी भंडारण के जलए नाजमत अस्ट्थायी भंडारण
याडच में स्ट्थानांतठरत दकया िाएगा।
(6) तािे चारे की बबाचिी और पठरपक्वता से मृत िानिरों के जनपटान के जलए हैचरी, ब्रूडस्ट्टॉक मल्टीजप्लके िन सेंटर और
न्यूजललयस ब्रीडडंग सेंटर आदि में एक छोटा इन-हाउस इं सीनरे टर स्ट्थाजपत दकया िाएगा तादक िंगल में दकसी भी
संभाजित संिि
ू ण से बचा िा सके ।
(7) जनपटान होने तक नॉन डीिेडेबल नॉन री साईललेबल कचरे के भंडारण के जलए एक अस्ट्थायी भंडारण स्ट्थान जनर्िचष्ट
दकया िाएगा ।
(8) कचरे को कू डेिान में डालते समय सािधानी बरती िाएगी तादक उसे फै लने से रोका िा सके ।
(9) कचरे को जनकटिती खुले तटीय िातािरण या सािचिजनक भूजम या नाली या िल जनकायों में नहीं डाला िाएगा।
5.
अपजिष्ट का अस्ट्थायी भंडारण और उजचत जनपटान - (1) प्रत्सयेक तटीय िलीय कृ जि इकाई ऐसे कचरे की जिजभन्न
श्रेजणयों को संभालने के जलए उजचत िमता का अस्ट्थायी भंडारण बनाए रखेगी।
(2) री साईललेबल नॉन डीिेडेबल अपजिष्ट को उनकी जििेिताओं के आधार पर एकत्र दकया िाता है और ऐसे कचरे के
अस्ट्थायी भंडारण के जलए जनर्िचष्ट गोिाम में संिहीत दकया िाता है, भंडारण के आकार, धारण िमता और प्रकृ जत के
आधार पर समय-समय पर बेचा िाएगा या री साईलरर को सौंप दिया िाएगा। जनपटान में िेरी से बचने के जलए
सुजिधा और उजचत िेखभाल की िाएगी िैसे जनपटान का एक जनजित साप्ताजहक कायचक्रम।
(3) तटीय िलकृ जि इकाइयां संबंजधत कायों को करने के जलए स्ट्थानीय जनकाय के साथ अपजिष्ट प्रबंधन प्रणाली की स्ट्थापना,
संचालन और समन्िय करेंगी।
(4) तटीय िलकृ जि इकाइयां िो बडी हैं और बडी मात्रा में सीिेि उत्सपन्न करती हैं, प्रिूिण जनयंत्रण बोडच के मानकों के
अनुसार एक इन-हाउस सीिेि उपचार संयंत्र स्ट्थाजपत और संचाजलत करेंगी।
(5) भंडारण याडच में स्ट्थानांतठरत दकए गए िैजिक कचरे को अलग से खाि बनाने के जलए उजचत फरमेंटेिन या िैजिक पाचन
या कं पोडस्ट्टंग प्रदक्रया के अधीन दकया िाएगा।
(6) बायोजडिेडेबल कचरे को जनपटान के जलए अन्यथा स्ट्थानीय जनकाय िैसे नगर पाजलकाओं, िाम पंचायतों आदि को सौंप
दिया िाएगा।
(7) तटीय हैचठरयों, ब्रूडस्ट्टॉक मल्टीजप्लके िन सेंटर और न्यूजललयस ब्रीडडंग सेंटर के प्रत्सयेक जतमाही में पुराने िानिरों, मृत
या मरणासन्न िानिरों को िला दिया िाएगा।
(8) रसोई के कचरे, कीचड और अन्य िैजिक कचरे का, िहां भी संभि हो, खाि तैयार करने के जलए उजचत रूप से उपयोग
दकया िाएगा और उत्सपन्न खाि का उपयोग घर के बगीचे में दकया िाएगा या उसके संिह के जलए जनयुक्त एिेंसी के
माध्यम से जनपटान दकया िाएगा।
(9) सभी रसायनों या कीटाणुनािकों और प्रयोगिाला से उत्सपन्न कचरे को अत्सयंत सािधानी से एकत्र दकया िाएगा और
उनके जनपटान के जलए जनर्िचष्ट प्रोटोकॉल के अनुसार जनपटान दकया िाएगा।
(10) िोस अपजिष्ट के जनपटान के जलए सैजनटरी लैंडदफल के जलए एक जनर्िचष्ट स्ट्थान का भी उपयोग दकया िाएगा।

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(11) तटीय िलकृ जि इकाइयों, जििेि रूप से हैचरी, ब्रूडस्ट्टॉक गुणन कें द्रों और न्यूजललयस ब्रीडडंग सेन्टेसच के एफफ्लुएंट
रीटमेंट जसस्ट्टेम उपचार प्रणाली में कीचड को हटाने के जलए एक स्ट्ल््ि पंप स्ट्थाजपत दकया िाएगा और स्ट्थानीय जनकाय के
माध्यम से इसका जनपटान दकया िाएगा ।
(12) तटीय िलकृ जि फामों के मामले में, कीचड को सूखने के िौरान स्ट्थाजपत प्रदक्रयाओं के साथ उपचाठरत दकया िाएगा
या यदि आिश्यक हो, तो कटाई के बाि तालाबों के तल से जनकाल दिया िाएगा और उजचत रूप से जनपटान दकया िाएगा।
(13) मात्रा के आधार पर कीचड को समय-समय पर हर हफ्ते या उत्सपािन के प्रत्सयेक चक्र के बाि हटा दिया िाएगा और
िेजिटी जथनर में या जडिॉल्िड एयर फ्लोटेिन द्वारा गाढा दकया िाएगा।
(14) िोस पिाथों के कु ल मास को कम करने के जलए कीचड में काबचजनक िोस पिाथों को िैजिक प्रदक्रया के माध्यम से
पचाया िाएगा।
(15) कीचड को पानी से जनकाला िाएगा, सुखाया िाएगा और िब भी इसे एकत्र दकया िाएगा या समय-समय पर
अस्ट्थायी भंडारण द्वारा स्ट्थानीय जनकाय या इस उद्देश्य के जलए जनयुक्त एिेंसी को सौंप दिया िाएगा।
(16) कीचड को ललोरीन से उपचाठरत करने, डीललोरीनीकरण करने तथा धोने और सुखाकर लिणता हटाने के बाि खाि
के रूप में पुन: उपयोग दकया िाएगा।
(17) िनरे टर और यांजत्रक उपकरणों के संचालन के जलए ईंधन या तेल, लूजब्रके न्र्टस और अन्य उपभोग्य सामजियों के जलए
एक भंडारण कि प्रत्सयेक तटीय िलीय कृ जि इकाई में नाजमत दकया िाएगा।
(18) प्रत्सयेक तटीय िलकृ जि इकाई ईंधन या तेल, लूजब्रके न्र्टस और अन्य उपभोग्य सामजियों के भंडारण के जलए कानूनी
आिश्यकताओं, यदि कोई हो, की पहचान करेगी और उनका अनुपालन करे गी।
(19) भंडारण कि में तेल, लूजब्रके न्र्टस और अन्य उपभोग्य सामजियों के कं टेनरों की समय-समय पर िांच की िाएगी और
जबना दकसी ठरसाि के उनका रखरखाि दकया िाएगा।
(20) िहां लूजब्रके न्र्टस या ईंधन संिहीत दकया िाता है, िहां उजचत चेतािनी संकेत प्रिर्िचत दकए िाएंगे।
(21) प्रत्सयेक तटीय िलीय कृ जि इकाई िनरे टर और यांजत्रक उपकरण चलाने िाले कमचचाठरयों को प्रजििण िेगी और
बिलते या एकत्र करते समय तेल या लूजब्रके न्र्टस को फै लने से बचाने के जलए िेखभाल की िाएगी।
(22) एकत्र दकए गए प्रयुक्त तेल को ठरसाि-रोधी कै न या कं टेनर में संिजहत दकया िाएगा और इसे के िल सरकार द्वारा
अनुमोदित या अजधकृ त िे केिारों को सौंपा िाएगा।
(23) प्रत्सयेक तटीय िलकृ जि इकाइयां खतरनाक कचरे के उपिे केिारों को बेचे गए खतरनाक कचरे का ठरकॉडच बनाए रखेंगी।
6.
ठरकाडच रखना - ( 1) अपजिष्ट उत्सपािन के जलए पहचाने गए प्रत्सयेक िेत्र या अनुभाग में अपजिष्ट के प्रकार, मात्रा
और हटाने की आिृजि के जििरण के साथ ठरकॉडच या रजिस्ट्टर रखे िाएंगे।
(2) प्रत्सयेक तटीय िलीय कृ जि इकाई में कीचड, सीिेि और अन्य री साईललेबल और नॉन री साईललेबल कचरे के
जनपटान का ठरकॉडच रखा िाएगा।
(3) प्राजधकरण तटीय िलकृ जि इकाइयों द्वारा रखे गए अजभलेखों का यािृजछछक जनरीिण करेगा ।
7. अनुपालन का मूल्यांकन - (1) प्रत्सयेक तटीय िलीय कृ जि इकाइयां समय-समय पर अपजिष्ट प्रबंधन प्रणाली की
गजतजिजधयों का मूल्यांकन करें गी और दकसी भी गैर-अनुपालन के मामले में अनुपालन सुजनजित करने के जलए उजचत तरीके
अपनाएंगी ।
(2) प्राजधकरण सभी तटीय िलकृ जि इकाइयों में अपजिष्ट प्रबंधन प्रणाली की गजतजिजधयों का मूल्यांकन करेगा और
अनुपालन न होने की जस्ट्थजत में अनुपालन सुजनजित करने के जलए उजचत कारच िाई िुरू की िाएगी।
[फा. सं. िे-1903336/2/2024-डीओएफ (ई-23648)]
नीतू कु मारी प्रसाि, संयुक्त सजचि

<!-- page 7 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

7

MINISTRY OF FISHERIES, ANIMAL HUSBANDRY AND DAIRYING
(Department of Fisheries)
NOTIFICATION
New Delhi, the 15th March, 2024
S.O. 1458(E).—In pursuance of section 3 of the Coastal Aquaculture Authority Act, 2005 (24 of 2005), read
with clause (g) of rule 3 of the Coastal Aquaculture Authority Rules, 2024, the Central Government hereby notifies
the following guidelines, namely:1. Short title and commencement. – (1) These guidelines may be called the Guidelines for solid waste management in
coastal aquaculture units or activities.
(2) They shall come into force from the date of their publication in the Official Gazette.
Guidelines for Solid Waste Management in Coastal Aquaculture Units or Activities
2.

General: (1) For the purpose of achieving sustainable development of environmentally friendly coastal
aquaculture, the aquaculture sector shall focus on methods to reduce and manage the waste generated from
production including coastal aquaculture hatcheries, farms, Nucleus Breeding Centres, Broodstock
Multiplication Centres, and aquaculture inputs production units.

(2)

The coastal aquaculture units shall follow appropriate selection and use of reusable materials during the
production cycle in the coastal aquaculture units to reduce waste generation.

(3)

All coastal aquaculture units shall minimise the use of non-recyclable products and promote the use of ecofriendly alternate material, which can be easily recycled or reused or degraded and decomposed.

(4)

The wastes generated from coastal aquaculture units may be categorised into waste water and solid waste as
under, namely:(a)
Waste water.- The wastewater or effluents from the coastal aquaculture units shall be treated in the
Effluent Treatment System, in accordance with the protocol specified by the Coastal Aquaculture Authority
which shall conform to the standards for treatment of wastewater discharged from the aquaculture units as
specified under the Guidelines for regulating coastal aquaculture issued under rule 3 of the Coastal Aquaculture
Authority Rules, 2024 before it is discharged into the open water source:
Provided that in the absence of standards or loads for certain parameters, the discharged water shall be in
conformity with the standards of the Pollution Control Board for such parameters.
(b)
Solid waste.- The solid wastes generated from the coastal aquaculture units shall be managed with
adequate care to protect the adjoining coastal environment from possible pollution as under:
(i) the units shall be responsible for handling the solid waste in accorance with the rules made under the
Environment (Protection) Act 1986 (29 of 1986);
(ii) the coastal aquaculture units shall develop appropriate infrastructure for segregation, collection,
storage, transportation processing and disposal of solid or plastic waste either by its own or by engaging
agencies or producers in accordance with the rules made under the said Environment (Protection) Act,
1986.

2.

Evaluation of Waste .- (1) Every coastal aquaculture units shall identify the areas or sections, the type and
quantity of waste being generated, area for the storage and treatment of different streams of waste, determine the
appropriate methods or ways to safely dispose them and prepare a solid waste management plan for the
facility.

(2) The solid wastes shall be categorised in to biodegradable, non-biodegradable and domestic hazardous and an
appropriate care shall be provided in segregation and collection of such different streams of waste at source, its
storage and disposal.
(3) Each area or section shall be provided with sufficient capacity bins in three different colours for three different
streams referred to in sub-paragraph (2) for the segregation and collection of them at source.
(4) Sign boards and posters on handling and compliance requirement etc., shall be displayed at any section or area
identified in accordance with the type of waste that is being generated.
(5) The facility managers shall assign specific functions to be performed by the employees not below the level of
supervisors, to implement and manage the solid waste management plan.

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(6) Every units shall enter into agreement with appropriate or authorised agencies for the collection and disposal of
following wastes, namely:(i) recyclable non-degradable waste;
(ii) sludge from Effluent Treatment System;
(iii) biodegradable non-recyclable waste;
(iv) non-degradable non-recyclable waste; and
(v) domestic sewage.
(7) The facility manager shall plan and ensure the transportation of different wastes in specific vehicles from the
facility to the processing or disposal sites.
(8) The facility managers shall plan and implement the reuse or recycling of the waste minimising the transportation.
(9) Separate records shall be maintained for clearing of waste by the agencies.
(10) The list of major types of possible wastes generated from various coastal aquaculture units are specified in the
table below:Table-1
Sl. No.

Section of the unit

Waste generated

(1)

(2)

(3)

1.

Brood stock receiving area

2.

Maturation

3.

Larval rearing

4.

Packing

5.

Laboratory

6.

Maintenance

7.
8.

Effluent Treatment System
Domestic

9.
10.

Seed stocking
Aqua inputs

11.

Sludge removal

Brood stock bags, Thermocol boxes (and sometimes carton boxes), ice
packs, rubber bands used for brood stock packing and dead animals
(brooders) or moribund animals.
Feed packing plastic pouches or boxes, tins, or any such substances, feed
spill overs, feed residues and dead animals (brooders) or moribund
animals.
Feed packing plastic pouches or boxes, tins, or any such substances, feed
spill overs and feed residues.
Boxes or packs of the Post Larvae packing covers, rubber bands and
damaged packing bags.
Empty plastic or glass containers of chemicals, expired chemicals,
damaged lab equipment, the culture plates in the microbiological labs,
gels prepared in Polymerase Chain Reaction labs etc.
Leftovers/broken pieces of Polyvinyl chloride pipes, small and large air
hoses, damaged valves, spill overs of chemicals and other disinfectants
and sponges or other scrub used for cleaning.
Sludge from the Effluent Treatment System.
Single use plastic plates, tumblers, spoons and other vessels used to serve
food, food and vegetable waste, sewage, etc.
Polythene bags in which the Post Larvae or Nauplii has been purchased.
Containers, pouches of the various inputs used.
Packaging materials of feed.
From culture ponds and Effluent Treatment System.

3. Evaluation of plastic wastes. – (1) Plastics of any grade shall NOT be burnt at any time by the units,
and they shall be handed over to the local body or the appointed agency for collecting such plastics.
(2) Different types of plastics and their recycling status shall be as given in the table below:
Table-2
S.No

Symbol

(1)

(2)

1

Short
Name
(3)
PET

Scientific Name

Possible waste generated from

(4)

(5)

Polyethylene
terephthalate

Soft drink Bottles, furniture,
carpet, paneling, etc.

Recyclable or
non-recyclable
(6)

<!-- page 9 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

9

2

HDPE

High-Density
polyethylene

Bottles, carry bags, milk pouches,
recycling bins, agricultural pipe,
base cups, etc.

3

PVC

Polyvinyl chloride

Pipe, window profile, fencing,
flooring, shower curtains, lawn
chairs, non-food bottles, etc.

4

LDPE

Low
density
polyethylene

Plastic bags, various containers,
dispensing bottles, wash bottles,
tubing, etc.

5

PP

Polypropylene

Auto parts, industrial fibers, food
containers, dishware, etc.

6

PS

Polystyrene

Cafeteria trays, plastic utensils,
toys, clam shell containers,
insulation board, etc.

7

O

Recyclable

Non - Recyclable

Thermoset plastics, multilayer and
laminates, bakelite, polycarbonate,
nylon sheet moulding compound,
fibre-reinforced plastic, etc.

Others

4.
Collection and Segregation of Waste. – (1) Every coastal aquaculture units shall segregate the waste at its
source or sections into different categories and collect them in bins with lids, as specified in the table below:
Table-3
Type of waste

(1)
Bins colour

Biodegradable and Nonrecyclable

non-degradable and
Recyclable

Non-degradable, nonrecyclable& domestic
hazardous

(2)

(3)

(4)

Green

Yellow

Red

(2) There shall be persons on duty at each area identified to collect, segregate and dispose the waste based on its
category, every 12 hours and records shall be maintained for clearing the waste.
(3) All the work force, especially those who are assigned for handling, storing, or otherwise managing the waste, shall
be trained on the intended use of the bins which may include introduction to,(i) basic procedures for waste management;
(ii) human and environmental risks; and
(iii) measures of precaution in waste management, etc.
(4) The non-degradable, recyclable waste such as broodstock bags, thermocol boxes, waste generated from office
stationery and general up keeping, etc., shall be stored temporarily in the area designated for temporary storage of
such waste and handed over to the recycling agency on a regular basis.
(5) The biodegradable and non-recyclable waste shall be transferred to temporary storage yard designated for
temporary storage of such waste.
(6) A small in-house incinerator shall be installed at the hatcheries, Broodstock Multiplication Centres and Nucleus
Breeding Centres, etc., to handle the fresh feed wastage and the dead animals from maturation to avoid any possible
contamination in the wild.

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(7) There shall be a temporary storage space designated for the storage of non-degradable non-recyclable waste till the
disposal of the same.
(8) Care shall be taken while depositing the waste into the bins to avoid spill overs.
(9) The waste shall be not dumbed into the adjacent open coastal environment or public land or the drain or water
bodies.
5.
Temporary Storage and Proper Disposal of Waste. – (1) Every coastal aquaculture unit shall maintain
temporary storage of appropriate capacity for handling different categories of such wastes.
(2) The recyclable non-degradable waste gathered based on their characteristics and stored at the warehouse designated
for the temporary storage of such waste, shall be periodically sold or handed over to the recycler based on the size,
holding capacity and nature of the storage facility and appropriate care must be taken to avoid the delay in disposal
such as a fixed weekly schedule of disposal.
(3) The coastal aquaculture units shall establish, operationalise and co-ordinate the waste management system with the
local body for performing the associated functions.
(4) The coastal aquaculture units which are larger and generating larger quantity of sewage shall establish and operate
an in-house sewage treatment plant in accordance with the standards of Pollution Control Board.
(5) The biological wastes transferred to the storage yard, shall be subjected to appropriate fermentation or biological
digestion or composting process to generate manure separately.
(6) The biodegradable waste shall otherwise be handed over to the local body such as municipalities, gram panchayats,
etc., for disposal.
(7) In coastal hatcheries, Broodstock Multiplication Centre’s and Nucleus Breeding Centre’s old animals at every
quarter, dead or moribund animals shall be incinerated.
(8) The kitchen wastes, sludge and other organic waste shall wherever possible, be appropriately used to prepare
compost and the manure generated shall be used in the inhome garden or be disposed of through the agency
appointed for collection of the same.
(9) All chemicals or disinfectants and the waste generated from the laboratory shall be collected with utmost care and
disposed of as per the protocol specified for disposing them.
(10) A designated space for sanitary landfills shall also be used to dispose of the solid waste.
(11) A sludge pump shall be set up for the removal of sludge at Effluent Treatment System of the coastal aquaculture
units especially hatcheries Broodstock Multiplication Centres and Nucleus Breeding Centres and disposed of through
the local body.
(12) In the case of coastal aquaculture farms, the sludge shall be treated with the established procedures during dry out
or scrapped if required, from the bottom of the ponds after the harvest and disposed appropriately.
(13) The sludge depending on the quantity shall be removed periodically every week or after each cycle of production
and shall be thickened in a gravity thickener or by dissolved air floatation.
(14) The organic solids in the sludge shall be digested through biological process to reduce total mass of solids.
(15) The sludge shall be dewatered, dried and handed over to the local body or agency appointed for such purpose as
and when it is collected or on a periodical basis with temporary storage.
(16) The sludge shall otherwise be reused as manure after treating with chlorine, dechlorinating and removing salinity
by washing and drying.
(17) A storage room for fuel or oil, lubricants and other consumables for operating generators and mechanical
equipment shall be designated at every coastal aquaculture unit.
(18) Every coastal aquaculture unit shall identify and comply with legal requirements, if any, for storing fuel or oil,
lubricants and other consumables.
(19) The containers of oil, lubricants and other consumables in the storage room, shall be periodically checked and
maintained without any leakage.
(20) Proper warning signs shall be displayed where lubricants or fuel is stored.
(21) Every coastal aquaculture unit shall impart training to the staff operating the generators and mechanical
equipment and care shall be taken to avoid spill oil or lubricants spill while changing or collecting.

<!-- page 11 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

11

(22) The used oil collected shall be stored in a leak-proof can or container and it shall be handed over to Government
approved or authorised contractors only.
(23) Every coastal aquaculture units shall maintain the records of hazardous waste sold to subcontractors of hazardous
waste.
6.
Record Keeping. –(1) The records or registers shall be maintained at each area or section identified for
generation of waste with the details of type and quantity and frequency of removal of waste.
(2) The records for the disposal of sludge, sewage and other recyclable and non-recyclable waste shall be
maintained at every coastal aquaculture unit.
(3) The Authority shall conduct the random inspection of the records maintained by the coastal aquaculture units.
7.
Evaluation of Compliance.- (1) Every coastal aquaculture units shall periodically evaluate the activities of
the waste management system and in case of any non-compliance, adopt appropriate methods to ensure compliance.
(2) The Authority shall evaluate the activities of the waste management system in all the coastal aquaculture units
and in case of non-compliance, suitable action shall be initiated to ensure compliance.
[F. No. j-1903336/2/2024-DOF (E-23648)]
NEETU KUMARI PRASAD, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

Digitally signed by MANOJ
KUMAR VERMA
Date: 2024.03.18 22:38:32
+05'30'
