---
doc_id: "ff9df53ea886e4bb"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/5f64f50d1c7c4e841312ced2743a6ae1.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Status of Industrial Entrepreneur Memorandum Intentions & Implementation (State Wise)"
date: "2022-09-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4483eeeea551c299"
---

<!-- page 1 -->

STATUS OF INDUSTRIAL ENTREPRENEUER MEMORANDUM INTENTIONS & IMPLEMENTATION (STATEWISE)
INDUSTRIAL ENTREPRENURS MEMORANDUM (Part A)
FILED
Name of the
State

2020

IEMs IMPLEMENTED (Based on Part B filed)

upto August
2022

2021

2020

Numbers
Filed

Proposed
Investment
(Rs.Cr)

Numb
ers
Filed

0

0

0

0

0

0

0

0

0

0

0

0

59

9727

47

9373

34

6949

42

9840

47

10350

36

40673

1

60

2

15

0

0

0

0

0

0

0

0

Assam

4

99

17

1221

12

18582

9

989

4

452

10

480

Bihar

5

1304

21

11004

5

1203

2

121

2

71

3

431

Chandigarh

1

3

0

0

0

0

0

0

0

0

0

0

Chhattisgarh
Dadra &
Nagar Haveli

109

22193

98

31564

27

5888

51

73567

70

16492

24

2658

13

516

8

2787

6

305

8

2364

4

68

13

2657

Daman & Diu

5

0

6

700

3

0

5

326

3

176

2

642

Delhi

32

3710

7

901

14

14326

0

0

2

106

0

0

Goa

5

0

7

163

3

1850

0

0

3

62

2

Gujarat

220

46141

214

92566

138

93772

285

34866

110

104968

103

21132

Haryana
Himachal
Pradesh
Jammu &
Kashmir

42

2243

44

5714

27

2591

15

4915

19

3562

13

1738

7

218

5

591

6

245

5

855

8

1473

5

729

4

151

5

681

3

0

1

15

5

126

3

150

Jharkhand

8

547

10

1347

5

4135

18

1667

11

2728

6

4670

Karnataka

120

162492

114

61726

68

64527

41

6565

43

6327

45

6408

Kerala

10

382

4

121

2

1

1

97

4

79

2

1

Lakshadweep
Madhya
Pradesh

0

0

0

0

0

0

0

0

0

0

0

0

93

32831

113

21859

50

5309

60

5275

63

14500

26

4288

Maharashtra

296

44188

273

277335

161

24610

101

33715

171

45855

137

23140

Manipur

0

0

0

0

0

0

0

0

0

0

0

0

Meghalaya

1

405

0

0

3

284

0

0

0

0

0

0

Mizoram

0

0

1

220

0

0

0

0

0

0

0

0

Nagaland

0

0

0

0

0

0

0

0

0

0

0

0

Orissa

46

37721

60

137939

42

69657

28

28954

30

89167

19

37070

Puducherry

0

0

5

406

2

1300

0

0

3

6

1

0

Punjab

42

1479

40

8016

17

2250

22

1198

29

5627

14

1978

Rajasthan

40

12698

61

42452

29

12757

21

5917

14

7571

27

13339

Sikkim

0

0

2

40

0

0

0

0

0

0

2

22

Tamil Nadu

76

6807

115

29636

43

7144

17

1184

40

13684

44

5235

Telengana

57

7392

41

4614

23

3314

12

6057

25

6739

24

2957

Tripura

0

0

1

15

0

0

1

29

0

0

0

0

Uttar Pradesh

91

11384

114

17278

51

7699

51

14177

60

11333

39

7460

Uttarakhand

18

377

27

5609

19

983

11

459

22

4489

16

1454

West Bengal

27

9552

27

5535

18

3016

11

817

20

1967

15

1719

1432

414620

1489

771428

811

352697

818

233969

812

347978

631

181133

Total

Numb
ers
Filed

Actual
Investme
nt
Reported
(Rs.Cr)

upto August 2022

Propose
d
Investme
nt
(Rs.Cr)

Andaman &
Nicobar
Andhra
Pradesh
Arunachal
Pradesh

Numb
ers
Filed

Propose
d
Investme
nt
(Rs.Cr)

2021

Num
bers
Filed

Actual
Investme
nt
Reported
(Rs.Cr)

Numb
ers
Filed

Actual
Investment
Reported
(Rs.Cr)

Note: IEM Part A is being filed by non-MSME category Industries ; Part B is being filed at the time of commencement of commercial
production for Part A filed since December 1991.

102
