---
doc_id: "fe3ed29efe101bc5"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/a449ea71f46808cd55eef28116876087.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Telecom eServices Portal under Telecommunications (Authorisation for Telecommunication Network) Rules, 2026"
date: "2026-07-20"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ba04fce2ddec4809"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-22072026-274693
xxxGIDHxxx
CG-DL-E-22072026-274693
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3804]
No. 3804]

नई ददल्ली, सोमिार, िुलाई 20, 2026/आषाढ 29, 1948
NEW DELHI, MONDAY, JULY 20, 2026/ASHADHA 29, 1948

संचार मंत्रालय
(दूरसंचार जिभाग)
अजधसूचना
नई ददल्ली, 20 िुलाई, 2026
का.आ. 3974(अ).—दूरसंचार (दूरसंचार नेटिकक के जलए प्राजधकार) जनयम, 2026 के जनयम 65 के अनुसरण में,
कें द्रीय सरकार एतद्द्वारा उक्त जनयम के जडजिटल कायाकन्ियन के जलए दूरसंचार जिभाग के “दूरसंचार ईसेिा पोटकल” को
पोटकल के तौर पर अजधसूजचत करती है।

[फा. सं. 24-020/2026-यूबीबी]
देिेन्द्र कु मार राय, संयुक्त सजचि

5523 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)
NOTIFICATION
New Delhi, the 20th July, 2026
S.O. 3974(E).—In pursuance of the provisions of rule 65 of the Telecommunications (Authorisation for
Telecommunication Network) Rules, 2026, the Central Government hereby notifies the “Telecom eServices Portal”
of the Department of Telecommunications as the portal for digital implementation of the said rules.

[F. No. 24-020/2026-UBB]
DEVENDRA KUMAR RAI, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. BHABAJIT DEKA
Digitally signed by BHABAJIT DEKA
Date: 2026.07.22 19:22:15 +05'30'
