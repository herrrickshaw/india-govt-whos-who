---
doc_id: "feb008d53cca1f9b"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/26c430e594b655280a567d61bae8dff1.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Consolidated FDI Policy Circular of 2016"
date: "2025-07-02"
pages: 110
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "851668c3f1ab5978"
---

<!-- page 1 -->

Department of Industrial Policy and Promotion
Ministry of Commerce and Industry
Government of India

Consolidated FDI Policy
(Effective from June 07, 2016)

<!-- page 2 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion

Consolidated FDI Policy Circular of 2016
Subject: Consolidated FDI Policy
The “Consolidated FDI Policy” is attached.
2. This Circular will take effect from June 07, 2016

(Atul Chaturvedi)
Joint Secretary to the Government of India
D/o IPP F. No. 5(1)/2016-FC-1 Dated the June 07, 2016
Copy forwarded to:
1.
2.
3.
4.
5.

Press Information Officer, Press Information Bureau- for giving wide publicity to the
above circular.
NIC, DIPP for uploading the Circular on DIPP's website.
Department of Economic Affairs, Ministry of Finance, New Delhi.
Reserve Bank of India, Mumbai.
Hindi Section for Hindi Translation.

1

<!-- page 3 -->

Contents

Chapter 1: Intent and Objective................................................................................................... 4
1.1 Intent and Objective.................................................................................................................. 4
Chapter 2: Definitions .................................................................................................................. 5
2.1 Definitions................................................................................................................................. 5
Chapter 3: General Conditions on FDI .......................................................................................11
3.1 Eligible investors......................................................................................................................11
3.2 Eligible investee entities ..........................................................................................................12
3.3 Instruments of investments, issue/transfer of shares etc..........................................................14
3.4 Entry Routes for Investment ....................................................................................................14
3.5 Caps on Investments ...............................................................................................................15
3.6 Entry Conditions on Investment ...............................................................................................15
3.7 Other Conditions on Investment besides Entry Conditions ......................................................15
3.8 Foreign Investment into/downstream Investment by eligible Indian entities .............................15
Chapter 4: Foreign Investment Promotion Board(FIPB)...........................................................18
4.1 Constitution of FIPB.................................................................................................................18
4.2 Levels of Approvals for Cases under Government Route ........................................................18
4.3 Cases which do not require Fresh Approval ............................................................................18
4.4 Online Filing of Applications for FIPB/Government’s Approval.................................................19
Chapter 5: Sector Specific Conditions on FDI..........................................................................20
5.1 Prohibited Sectors ...................................................................................................................20
5.2 Permitted Sectors ....................................................................................................................20
Agriculture ...................................................................................................................................21
5.2.1 Agriculture & Animal Husbandry ...........................................................................................21
5.2.2 Plantation Sector ..................................................................................................................22
Mining and Petroleum & Natural Gas.........................................................................................23
5.2.3 Mining...................................................................................................................................23
5.2.4 Petroleum & Natural Gas ......................................................................................................24
Manufacturing..............................................................................................................................25
5.2.5 Manufacturing.......................................................................................................................25
5.2.6 Defence ................................................................................................................................25
Services Sector ...........................................................................................................................26
5.2.7 Broadcasting.........................................................................................................................26
5.2.8 Print Media ...........................................................................................................................27
5.2.9 Civil Aviation .........................................................................................................................28
5.2.10 Construction Development: Townships, Housing, Built-up Infrastructure ............................31
5.2.11Industrial Parks....................................................................................................................33
5.2.12 Satellites- establishment and operation ..............................................................................33

2

<!-- page 4 -->

5.2.13 Private Security Agencies ...................................................................................................33
5.2.14 Telecom Services ...............................................................................................................34
5.2.15 Trading ...............................................................................................................................34
5.2.16 Railway Infrastructure .........................................................................................................41
Financial Services .......................................................................................................................42
5.2.17 Asset Reconstruction Companies .......................................................................................42
5.2.18 Banking- Private Sector ......................................................................................................43
5.2.19 Banking- Public Sector .......................................................................................................43
5.2.20Credit Information Companies (CIC) ....................................................................................43
5.2.21 Infrastructure Company in the Securities Market.................................................................44
5.2.22 Insurance............................................................................................................................45
5.2.23 Pension Sector ...................................................................................................................47
5.2.24 Power Exchanges...............................................................................................................47
5.2.25 White Label ATM Operations ..............................................................................................48
5.2.26 Non-Banking Finance Companies (NBFC)..........................................................................48
Others...........................................................................................................................................50
5.2.27 Pharmaceuticals .................................................................................................................50
Annexures....................................................................................................................................52
Annexure-1 Form FC-GPR ............................................................................................................52
Annexure-2 Types of Instruments..................................................................................................59
Annexure-3 Provisions Relating to Issue/Transfer of Shares .........................................................61
Annexure-4 Specific Conditions in Certain Cases..........................................................................71
Annexure-5 Total Foreign Investment i.e. Direct and Indirect Foreign Investment in eligible Indian
entities...........................................................................................................................................74
Annexure-6 Remittance, Reporting and Violation ..........................................................................78
Annexure-7 Conditions for Broadcasting Sector ..........................................................................103
Annexure-8 Conditions for Industrial Parks..................................................................................106
Annexure-9 Permissible limits under portfolio investment schemes through stock exchanges for
FIIs/FPIs and NRIs ......................................................................................................................107
Annexure – 10 Certificate to be Furnished by the Prospective Investor as well as the Prospective
Recipient Entity ...........................................................................................................................109

3

<!-- page 5 -->

Chapter 1: Intent and Objective
1.1

Intent and Objective

1.1.1 It is the intent and objective of the Government of India to attract and promote foreign direct
investment in order to supplement domestic capital, technology and skills, for accelerated
economic growth. Foreign Direct Investment, as distinguished from portfolio investment, has
the connotation of establishing a ‘lasting interest’ in an enterprise that is resident in an
economy other than that of the investor.
1.1.2 The Government has put in place a policy framework on Foreign Direct Investment, which is
transparent, predictable and easily comprehensible. This framework is embodied in the
Circular on Consolidated FDI Policy, which may be updated every year, to capture and keep
pace with the regulatory changes, effected in the interregnum. The Department of Industrial
Policy and Promotion (DIPP), Ministry of Commerce & Industry, Government of India makes
policy pronouncements on FDI through Press Notes/Press Releases which are notified by
the Reserve Bank of India as amendments to the Foreign Exchange Management (Transfer
or Issue of Security by Persons Resident Outside India) Regulations, 2000 (notification No.
FEMA 20/2000-RB dated May 3, 2000). These notifications take effect from the date of
issue of Press Notes/ Press Releases, unless specified otherwise therein. In case of any
conflict, the relevant FEMA Notification will prevail. The procedural instructions are issued
by the Reserve Bank of India vide A.P. (DIR Series) Circulars. The regulatory framework,
over a period of time, thus, consists of Acts, Regulations, Press Notes, Press Releases,
Clarifications, etc.
1.1.3 The present consolidation subsumes and supersedes all Press Notes/Press
Releases/Clarifications/Circulars issued by DIPP, which were in force as on June 06, 2016
and reflects the FDI Policy as on June 07, 2016.This Circular accordingly will take effect
from June 07, 2016 and will remain in force until superseded in totality or in part thereof.
Reference to any statute or legislation made in this Circular shall include modifications,
amendments or re-enactments thereof.
1.1.4 Notwithstanding
the
rescission
of
earlier
Press
Notes/Press
Releases/Clarifications/Circulars, anything done or any action taken or purported to have
been
done
or
taken
under
the
rescinded
Press
Notes/Press
Releases/Clarifications/Circulars prior to June 07, 2016, shall, in so far as it is not
inconsistent with those Press Notes/Press Releases/Clarifications/Circulars, be deemed to
have been done or taken under the corresponding provisions of this circular and shall be
valid and effective.

4

<!-- page 6 -->

Chapter 2: Definitions
2.1

Definitions

2.1.1

‘AD Category-I Bank’ means a bank(Scheduled Commercial, State or Urban
Cooperative) which is authorized under Section 10(1) of FEMA to undertake all
current and capital account transactions according to the directions issued by the
RBI from time to time.

2.1.2

‘Authorized Bank’ means a bank including a co-operative bank (other than an
authorized dealer) authorized by the Reserve Bank to maintain an account of a
person resident outside India.

2.1.3

‘Authorized Dealer’ means a person authorized as an authorized dealer under
sub-section (1) of section 10 of FEMA.

2.1.4

‘Authorized Person’ means an authorized dealer, money changer, offshore
banking unit or any other person for the time being authorized under sub-section (a)
of section 10 of FEMA to deal in foreign exchange or foreign securities.

2.1.5

‘Capital’ means equity shares; fully, compulsorily & mandatorily convertible
preference shares; fully, compulsorily & mandatorily convertible debentures and
warrants.
Note: The equity shares issued in accordance with the provisions of the Companies
Act, as applicable, shall include equity shares that have been partly paid.
Preference shares and convertible debentures shall be required to be fully paid, and
should be mandatorily and fully convertible. Further, ‘warrant’ includes Share
Warrant issued by an Indian Company in accordance to provisions of the
Companies Act, as applicable.

2.1.6

‘Capital account transaction’ means a transaction which alters the assets or
liabilities, including contingent liabilities, outside India of persons resident in India or
assets or liabilities in India of persons resident outside India, and includes
transactions referred to in sub-section (3) of section 6 of FEMA.

2.1.7

‘Control’ shall include the right to appoint a majority of the directors or to control the
management or policy decisions including by virtue of their shareholding or
management rights or shareholders agreements or voting agreements. For the
purposes of Limited Liability Partnership, ‘control’ will mean right to appoint majority
of the designated partners, where such designated partners, with specific exclusion
to others, have control over all the policies of the LLP.

2.1.8

‘Depository Receipt’ (DR) means a negotiable security issued outside India by a
Depository bank, on behalf of an Indian company, which represent the local Rupee
denominated equity shares of the company held as deposit by a Custodian bank in
India. DRs are traded on Stock Exchanges in the US, Singapore, Luxembourg, etc.
DRs listed and traded in the US markets are known as American Depository
Receipts (ADRs) and those listed and traded anywhere/elsewhere are known as
Global Depository Receipts (GDRs). DRs are governed by Notification No. FEMA

5

<!-- page 7 -->

330/ 2014-RB, issued by Reserve bank of India.
2.1.9

“Employees’ Stock Option” means the option given to the directors, officers or
employees of a company or of its holding company or joint venture or wholly owned
overseas subsidiary/subsidiaries, if any, which gives such directors, officers or
employees, the benefit or right to purchase, or to subscribe for, the shares of the
company at a future date at a pre-determined price.

2.1.10

‘Erstwhile Overseas Corporate Body’(OCB) means a company, partnership firm,
society and other corporate body owned directly or indirectly to the extent of at least
sixty percent by non-resident Indians and includes overseas trust in which not less
than sixty percent beneficial interest is held by non-resident Indians directly or
indirectly but irrevocably and which was in existence on the date of commencement
of the Foreign Exchange Management (Withdrawal of General Permission to
Overseas Corporate Bodies (OCBs) ) Regulations, 2003 (the Regulations) and
immediately prior to such commencement was eligible to undertake transactions
pursuant to the general permission granted under the Regulations.

2.1.11

‘Foreign Currency Convertible Bond’(FCCB) means a bond issued by an Indian
company expressed in foreign currency, the principal and interest of which is
payable in foreign currency. FCCBs are issued in accordance with the Foreign
Currency Convertible Bonds and ordinary shares (through depository receipt
mechanism) Scheme, 1993 and subscribed by a non-resident entity in foreign
currency and convertible into ordinary shares of the issuing company in any
manner, either in whole, or in part.

2.1.12

‘FDI’ means investment by non-resident entity/person resident outside India in the
capital of an Indian company under Schedule 1 of Foreign Exchange Management
(Transfer or Issue of Security by a Person Resident Outside India)
Regulations,2000
(Original
notification
is
available
at
https://rbi.org.in/Scripts/BS_FemaNotifications.aspx?Id=174
Subsequent
amendment
notifications
are
available
at
https://rbi.org.in/Scripts/BS_FemaNotifications.aspx).

2.1.13

‘FEMA’ means the Foreign Exchange Management Act, 1999 (42 of 1999).

2.1.14

‘FIPB’ means the Foreign Investment Promotion Board constituted by the
Government of India. Details of FIPB including filing application for FIPB can be
accessed on the FIPB website www.fipb.gov.in.

2.1.15

‘Foreign Institutional Investor’(FII) means an entity established or incorporated
outside India which proposes to make investment in India and which is registered as
a FII in accordance with the Securities and Exchange Board of India (SEBI)
(Foreign Institutional Investor) Regulations 1995.

6

<!-- page 8 -->

2.1.16

‘Foreign Portfolio Investor’(FPI)1 means a person registered in accordance with
the provisions of Securities and Exchange Board of India (SEBI) (Foreign Portfolio
Investors) Regulations, 2014, as amended from time to time.

2.1.17

‘Foreign Venture Capital Investor’ (FVCI) means an investor incorporated and
established outside India, which is registered under the Securities and Exchange
Board of India (Foreign Venture Capital Investor) Regulations, 2000 {SEBI(FVCI)
Regulations} and proposes to make investment in accordance with these
Regulations.

2.1.18

‘Government route’ means that investment in the capital of resident entities by
non-resident entities can be made only with the prior approval of Government
(FIPB, Department of Economic Affairs (DEA), Ministry of Finance or Department of
Industrial Policy &Promotion, as the case may be).

2.1.19

‘Group Company’ means two or more enterprises which, directly or indirectly, are
in a position to:

(i) exercise twenty-six percent or more of voting rights in other enterprise; or
(ii) appoint more than fifty percent of members of board of directors in the other
enterprise.
2.1.20

‘Holding Company’ would have the same meaning as defined in Companies Act,
as applicable.

2.1.21

‘Indian Company’ means a company incorporated in India under the Companies
Act, as applicable.

2.1.22

‘Indian Venture Capital Undertaking’(IVCU) means an Indian company:
(i) whose shares are not listed in a recognised stock exchange in India;
(ii) which is engaged in the business of providing services, production or
manufacture of articles or things, but does not include such activities or sectors
which are specified in the negative list by the SEBI, with approval of Central
Government, by notification in the Official Gazette in this behalf.

2.1.23

‘Investment Vehicle’ shall mean an entity registered and regulated under relevant
regulations framed by SEBI or any other authority designated for the purpose and
shall include Real Estate Investment Trusts (REITs) governed by the SEBI (REITs)
Regulations, 2014, Infrastructure Investment Trusts (InvIts) governed by the SEBI
(InvIts) Regulations, 2014 and Alternative Investment Funds (AIFs) governed by the
SEBI (AIFs) Regulations, 2012.

2.1.24

‘Investing Company’ means an Indian Company holding only investments in other
Indian company/(ies), directly or indirectly, other than for trading of such

1

For details please refer to SEBI (FPI) Regulations, 2014 and the Foreign Exchange Management (Transfer or Issue of Security by
a Person Resident outside India) (Second Amendment) Regulations, 2014 notified vide Notification No. FEMA.297/2014-RB
dated March 13, 2014 and A.P. (DIR Series) Circular No.112 dated March 25, 2014.Wherever the words or acronyms FPI or FII
occur in this document, the meaning and implications must be according to the above Regulations/Notifications, particularly
during the transition period as prescribed in these Regulations.

7

<!-- page 9 -->

holdings/securities.
2.1.25

‘Investment on repatriable basis’ means investment, the sale proceeds of which,
net of taxes, are eligible to be repatriated out of India and the expression
‘investment on non-repatriable basis’ shall be construed accordingly.

2.1.26

‘Joint Venture’(JV) means an Indian entity incorporated in accordance with the
laws and regulations in India in whose capital a non-resident entity makes an
investment.

2.1.27

‘Limited Liability Partnership’ means a Limited Liability Partnership firm, formed
and registered under the Limited Liability Partnership Act, 2008.

2.1.28

‘Manufacture’, with its grammatical variations, means a change in a non-living
physical object or article or thing- (a) resulting in transformation of the object or
article or thing into a new and distinct object or article or thing having a different
name, character and use; or (b) bringing into existence of a new and distinct object
or article or thing with a different chemical composition or integral structure.

2.1.29

‘Non-resident entity’ means a ‘person resident outside India’ as defined under
FEMA.

2.1.30

‘Non-Resident Indian’ (NRI) means an individual resident outside India who is a
citizen of India or is an ‘Overseas Citizen of India’ cardholder within the meaning of
section 7 (A) of the Citizenship Act, 1955. ‘Persons of Indian Origin’ cardholders
registered as such under Notification No. 26011/4/98 F.I. dated 19.8.2002 issued by
the Central Government are deemed to be ‘Overseas Citizen of India’ cardholders’

2.1.31

A company is considered as ‘Owned’ by resident Indian citizens if more than 50%
of the capital in it is beneficially owned by resident Indian citizens and / or Indian
companies, which are ultimately owned and controlled by resident Indian citizens. A
Limited Liability Partnership will be considered as owned by resident Indian citizens
if more than 50% of the investment in such an LLP is contributed by resident Indian
citizens and/or entities which are ultimately ‘owned and controlled by resident Indian
citizens’ and such resident Indian citizens and entities have majority of the profit
share.

2.1.32

‘Person’ includes-

2.1.33

(i) an individual,
(ii)a Hindu undivided family,
(iii) a company,
(iv)a firm,
(v) an association of persons or a body of individuals whether incorporated or not,
(vi)every artificial juridical person, not falling within any of the preceding subclauses, and
(vii) any agency, office, or branch owned or controlled by such person.
‘Person of Indian Origin’(PIO) means a citizen of any country other than
Bangladesh or Pakistan, if

8

<!-- page 10 -->

(i)

he at any time held Indian Passport; or

(ii)

he or either of his parents or any of his grandparents was a citizen of India by
virtue of the Constitution of India or the Citizenship Act, 1955 (57 of 1955); or

(iii)the person is a spouse of an Indian citizen or a person referred to in sub-clause
(i) or (ii).
2.1.34

‘Person resident in India’ means(i) a person residing in India for more than one hundred and eighty-two days
during the course of the preceding financial year but does not include(A) A person who has gone out of India or who stays outside India, in either
case(a) for or on taking up employment outside India, or
(b) for carrying on outside India a business or vocation outside India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay outside India for an uncertain period;
(B) A person who has come to or stays in India, in either case, otherwise than(a) for or on taking up employment in India; or
(b) for carrying on in India a business or vocation in India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay in India for an uncertain period;
(ii) any person or body corporate registered or incorporated in India,
(iii) an office, branch or agency in India owned or controlled by a person resident
outside India,
(iv) an office, branch or agency outside India owned or controlled by a person
resident in India.

2.1.35

‘Person resident outside India’ means a person who is not a Person resident in
India.

2.1.36

‘Portfolio Investment Scheme’ means the Portfolio Investment Scheme referred to
in Schedules 2, 2A& 3 of FEMA (Transfer or Issue of Security by a Person Resident
Outside India) Regulations, 2000.

2.1.37

‘RBI’ means the Reserve Bank of India established under the Reserve Bank of
India Act, 1934.

2.1.38

‘Resident Entity’ means ‘Person resident in India’ excluding an individual.

2.1.39

‘Resident Indian Citizen’ shall be interpreted in line with the definition of ‘person
resident in India’ as per FEMA, 1999, read in conjunction with the Indian Citizenship
Act, 1955.

2.1.40

‘SEBI’ means the Securities and Exchange Board of India established under the

9

<!-- page 11 -->

Securities and Exchange Board of India Act, 1992.
2.1.41

‘SEZ’ means a Special Economic Zone as defined in Special Economic Zone Act,
2005.

2.1.42

‘SIA’ means Secretariat of Industrial Assistance in DIPP, Ministry of Commerce &
Industry, Government of India.

2.1.43

‘Sweat Equity Shares’ means such equity shares as issued by a company to its
directors or employees at a discount or for consideration other than cash, for
providing their know-how or making available rights in the nature of intellectual
property rights or value additions, by whatever name called.

2.1.44

‘Transferable Development Rights’ (TDR) means certificates issued in respect of
category of land acquired for public purposes either by the Central or State
Government in consideration of surrender of land by the owner without monetary
compensation, which are transferable in part or whole.

2.1.45

‘Unit’ shall mean beneficial interest of an investor in the Investment Vehicle and
shall include shares or partnership interests.

2.1.46

‘Venture Capital Fund’ (VCF) means an Alternative Investment Fund which invests
primarily in unlisted securities of start-ups, emerging or early-stage venture capital
undertakings mainly involved in new products, new services, technology or
intellectual property right based activities or a new business model and shall
include an angel fund as defined under Chapter III-A of SEBI (AIF) Regulations,
2012.

10

<!-- page 12 -->

Chapter 3: General Conditions on FDI
3.1

Eligible investors

3.1.1

A non-resident entity can invest in India, subject to the FDI Policy except in those
sectors/activities which are prohibited. However, a citizen of Bangladesh or an entity
incorporated in Bangladesh can invest only under the Government route. Further, a
citizen of Pakistan or an entity incorporated in Pakistan can invest, only under the
Government route, in sectors/activities other than defence, space and atomic energy
and sectors/activities prohibited for foreign investment.

3.1.2

NRIs resident in Nepal and Bhutan as well as citizens of Nepal and Bhutan are
permitted to invest in the capital of Indian companies on repatriation basis, subject to
the condition that the amount of consideration for such investment shall be paid only by
way of inward remittance in free foreign exchange through normal banking channels.

3.1.3

OCBs have been derecognized as a class of investors in India with effect from
September 16, 2003. Erstwhile OCBs which are incorporated outside India and are not
under the adverse notice of RBI can make fresh investments under FDI Policy as
incorporated non-resident entities, with the prior approval of Government of India if the
investment is through Government route; and with the prior approval of RBI if the
investment is through Automatic route.

3.1.4

A company, trust and partnership firm incorporated outside India and owned and
controlled by NRIs can invest in India with the special dispensation as available to NRIs
under the FDI Policy.

3.1.5

(i) Foreign Institutional Investor (FII) and Foreign Portfolio Investors (FPI) may in terms
of Schedule 2 and 2A of FEMA (Transfer or Issue of Security by Persons Resident
Outside India) Regulations, as the case may be, respectively, invest in the capital of an
Indian company under the Portfolio Investment Scheme which limits the individual
holding of an FII/FPI below 10% of the capital of the company and the aggregate limit
for FII/FPI investment to 24% of the capital of the company. This aggregate limit of 24%
can be increased to the sectoral cap/statutory ceiling, as applicable, by the Indian
company concerned through a resolution by its Board of Directors followed by a special
resolution to that effect by its General Body and subject to prior intimation to RBI. The
aggregate FII/FPI investment, individually or in conjunction with other kinds of foreign
investment, will not exceed sectoral/statutory cap.
(ii) An Indian company which has issued shares to FIIs/FPIs under the FDI Policy for
which the payment has been received directly into company’s account should report
these figures separately under item no. 5 of Form FC-GPR (Annexure-1).
(iii)A daily statement in respect of all transactions (except derivative trade) has to be
submitted by the custodian bank in soft copy in the prescribed format directly to RBI
and
also
uploaded
directly
on
the
OFRS
web
site
(https://secweb.rbi.org.in/ORFSMainWeb/Login.jsp).

11

<!-- page 13 -->

3.1.6

Only registered FIIs/FPIs and NRIs as per Schedules 2,2A and 3 respectively of
Foreign Exchange Management (Transfer or Issue of Security by a Person Resident
Outside India) Regulations, 2000, can invest/trade through a registered broker in the
capital of Indian Companies on recognised Indian Stock Exchanges.

3.1.7

A SEBI registered Foreign Venture Capital Investor (FVCI) may contribute up to 100%
of the capital of an Indian company engaged in any activity mentioned in Schedule 6 of
Notification No. FEMA 20/2000, including startups irrespective of the sector in which it
is engaged, under the automatic route. A SEBI registered FVCI can invest in a
domestic venture capital fund registered under the SEBI (Venture Capital Fund)
Regulations, 1996 or a Category- I Alternative Investment Fund registered under the
SEBI (Alternative Investment Fund) Regulations, 2012.Such investments shall also be
subject to the extant FEMA regulations and extant FDI policy including sectoral caps,
etc. The investment can be made in equities or equity linked instruments or debt
instruments issued by the company (including start-ups and if a startup is organised as
a partnership firm or an LLP, the investment can be made in the capital or through any
profit-sharing arrangement) or units issued by a VCF or by a Category-I AIF either
through purchase by private arrangement either from the issuer of the security or from
any other person holding the security or on a recognised stock exchange.It may also
set up a domestic asset management company to manage its investments. SEBI
registered FVCIs are also allowed to invest under the FDI Scheme, as non-resident
entities, in other companies, subject to FDI Policy and FEMA regulations.

3.1.8

A Non- Resident Indian may subscribe to National Pension System governed and
administered by Pension Fund Regulatory and Development Authority (PFRDA),
provided such subscriptions are made through normal banking channels and the
person is eligible to invest as per the provisions of the PFRDA Act. The annuity/
accumulated saving will be repatriable.

3.2 Eligible investee entities
3.2.1 FDI in an Indian Company
Indian companies can issue capital against FDI.
3.2.2 FDI in Partnership Firm/Proprietary Concern
(i)

A Non-Resident Indian (NRI) or a Person of Indian Origin (PIO) resident outside
India can invest in the capital of a firm or a proprietary concern in India on nonrepatriation basis provided;
(a)

Amount is invested by inward remittance or out of NRE/FCNR(B)/NRO
account maintained with Authorized Dealers/Authorized banks.

(b)

The firm or proprietary concern is not engaged in any agricultural/plantation
or real estate business or print media sector.

(c)

Amount invested shall not be eligible for repatriation outside India.

12

<!-- page 14 -->

(ii) Investments with repatriation option: NRIs/PIO may seek prior permission of
Reserve Bank for investment in sole proprietorship concerns/partnership firms with
repatriation option. The application will be decided in consultation with the
Government of India.
(iii) Investment by non-residents other than NRIs/PIO:A person resident outside India
other than NRIs/PIO may make an application and seek prior approval of Reserve
Bank for making investment in the capital of a firm or a proprietorship concern or
any association of persons in India. The application will be decided in consultation
with the Government of India. (iv) Restrictions: An NRI or PIO is not allowed to
invest in a firm or proprietorship concern engaged in any agricultural/plantation
activity or real estate business or print media.
3.2.3

FDI in Trusts
FDI is not permitted in Trusts other than in ‘VCF’ registered and regulated by SEBI and
‘Investment vehicle’.

3.2.4

FDI in Limited Liability Partnerships (LLPs)
FDI in LLPs is permitted subject to the following conditions:
(i) FDI is permitted under the automatic route in Limited Liability Partnership (LLPs)
operating in sectors/activities where 100% FDI is allowed, through the automatic
route and there are no FDI-linked performance conditions.
(ii) An Indian company or an LLP, having foreign investment, is also permitted to make
downstream investment in another company or LLP in sectors in which 100% FDI is
allowed under the automatic route and there are no FDI-linked performance
conditions.
(iii) FDI in LLP is subject to the compliance of the conditions of LLP Act, 2008.

3.2.5

‘Investment Vehicle’
An entity being ‘investment vehicle’ registered and regulated under relevant regulations
framed by SEBI or any other authority designated for the purpose including Real Estate
Investment Trusts (REITs) governed by the SEBI (REITs) Regulations, 2014,
Infrastructure Investment Trusts (InvIts) governed by the SEBI (InvIts) Regulations,
2014, Alternative Investment Funds (AIFs) governed by the SEBI (AIFs) Regulations,
2012 and notified under Schedule 11 of Foreign Exchange Management (Transfer or
Issue of Security by a Person Resident outside India) Regulations, 2000 is permitted to
receive foreign investment from a person resident outside India (other than an
individual who is citizen of or any other entity which is registered / incorporated in
Pakistan or Bangladesh), including an Registered Foreign Portfolio Investor (RFPI) or a
non-resident Indian (NRI).

13

<!-- page 15 -->

3.2.6

FDI in other Entities
FDI in resident entities other than those mentioned above is not permitted.

3.3

Instruments of investments, issue/transfer of shares etc.
Types of instruments for investment and provisions relating to issue/ transfer of shares
are given at Annexure 2 & Annexure 3 respectively. Further, specific conditions of
compliance for certain cases are given in Annexure-4.

3.4

Entry Routes for Investment

3.4.1

Investments can be made by non-residents in the equity shares/fully, compulsorily and
mandatorily convertible debentures/fully, compulsorily and mandatorily convertible
preference shares of an Indian company, through the Automatic Route or the
Government Route. Under the Automatic Route, the non-resident investor or the Indian
company does not require any approval from Government of India for the investment.
Under the Government Route, prior approval of the Government of India is required.
Proposals for foreign investment under Government route, are considered by FIPB.

3.4.2

Foreign investment in sectors/activities under government approval route will be
subject to government approval where:
(i)

An Indian company is being established with foreign investment and is not owned
by a resident entity or

(ii) An Indian company is being established with foreign investment and is not
controlled by a resident entity or
(iii) The control of an existing Indian company, currently owned or controlled by
resident Indian citizens and Indian companies, which are owned or controlled by
resident Indian citizens, will be/is being transferred/passed on to a non-resident
entity as a consequence of transfer of shares and/or fresh issue of shares to nonresident entities through amalgamation, merger/demerger, acquisition etc. or
(iv) The ownership of an existing Indian company, currently owned or controlled by
resident Indian citizens and Indian companies, which are owned or controlled by
resident Indian citizens, will be/is being transferred/passed on to a non-resident
entity as a consequence of transfer of shares and/or fresh issue of shares to nonresident entities through amalgamation, merger/demerger, acquisition etc.
(v) It is clarified that Foreign investment shall include all types of foreign investments,
direct and indirect, regardless of whether the said investments have been made
under Schedule 1 (FDI), 2 (FII), 2A (FPI), 3 (NRI), 6 (FVCI), 9 (LLPs), 10 (DRs)
and 11(Investment Vehicles) of FEMA (Transfer or Issue of Security by Persons
Resident Outside India) Regulations. FCCBs and DRs having underlying of
instruments which can be issued under Schedule 5, being in the nature of debt,
shall not be treated as foreign investment. However, any equity holding by a

14

<!-- page 16 -->

person resident outside India resulting from conversion of any debt instrument
under any arrangement shall be reckoned as foreign investment.
(vi) Investment by NRIs under Schedule 4 of FEMA (Transfer or Issue of Security by
Persons Resident Outside India) Regulations will be deemed to be domestic
investment at par with the investment made by residents.
(vii) A company, trust and partnership firm incorporated outside India and owned and
controlled by non-resident Indians will be eligible for investments under Schedule
4 of FEMA (Transfer or issue of Security by Persons Resident Outside India)
Regulations and such investment will also be deemed domestic investment at par
with the investment made by residents.
3.5

Caps on Investments

3.5.1

Investments can be made by non-residents in the capital of a resident entity only to the
extent of the percentage of the total capital as specified in the FDI policy. The caps in
various sector(s) are detailed in Chapter 5 of this Circular.

3.6

Entry Conditions on Investment

3.6.1

Investments by non-residents can be permitted in the capital of a resident entity in
certain sectors/activity with entry conditions. Such conditions may include norms for
minimum capitalization, lock-in period, etc. The entry conditions in various
sectors/activities are detailed in Chapter 5 of this Circular.

3.7

Other Conditions on Investment besides Entry Conditions

3.7.1

Besides the entry conditions on foreign investment, the investment/investors are
required to comply with all relevant sectoral laws, regulations, rules, security conditions,
and state/local laws/regulations.

3.8

Foreign Investment into/downstream Investment by eligible Indian entities

3.8.1

The Guidelines for calculation of total foreign investment, both direct and indirect in
an Indian company/LLP, at every stage of investment, including downstream
investment, have been detailed in Annexure-5.

3.8.2

For the purpose of this chapter,
(i)

‘Downstream investment’ means indirect foreign investment, by an eligible
Indian entity, into another Indian company/LLP, by way of subscription or
acquisition. Annexure-5 provides the guidelines for calculation of indirect
foreign investment, with conditions specified in paragraph 1.2 (v).

(ii)

‘Foreign Investment’ would have the same meaning as in Annexure-5.

15

<!-- page 17 -->

3.8.3

Foreign investment into an Indian company engaged only in the activity of
investing in the capital of other Indian company/ies (regardless of its
ownership or control):

3.8.3.1 Foreign investment into an Indian company, engaged only in the activity of investing in
the capital of other Indian company/ies/ LLP, will require prior Government/FIPB
approval, regardless of the amount or extent of foreign investment. Foreign
investment into Non-Banking Finance Companies (NBFCs), carrying on activities
approved for FDI, will be subject to the conditions specified in paragraph 5.2.26 of
this Circular.
3.8.3.2

Those companies, which are Core Investment Companies (CICs), will have to
additionally follow RBI’s Regulatory Framework for CICs.

3.8.3.3

For undertaking activities which are under automatic route and without foreign
investment linked performance conditions, Indian company which does not have any
operations and also does not have any downstream investments, will be permitted to
have infusion of foreign investment under automatic route. However approval of the
Government will be required for such companies for infusion of foreign investment
for undertaking activities which are under Government route, regardless of the
amount or extent of foreign investment. Further, as and when such a company
commences business(s) or makes downstream investment, it will have to comply
with the relevant sectoral conditions on entry route, conditionalities and caps.

Note:

Foreign investment into other Indian companies/LLPs would be in accordance/
compliance with the relevant sectoral conditions on entry route, conditionalities and
caps.

3.8.4

Downstream investment by an eligible Indian entity which is not owned and/or
controlled by resident entity/ies

3.8.4.1

Downstream investment by an eligible Indian entity, which is not owned and/or
controlled by resident entity/ies, into another Indian company, would be in
accordance/compliance with the relevant sectoral conditions on entry route,
conditionalities and caps, with regard to the sectors in which the latter Indian
company is operating.

Note:

Downstream investment/s made by a banking company, as defined in clause(c) of
Section 5 of the Banking Regulation Act, 1949, incorporated in India, which is owned
and/or controlled by non-residents/a non-resident entity/non-resident entities, under
Corporate Debt Restructuring (CDR), or other loan restructuring mechanism, or in
trading books, or for acquisition of shares due to defaults in loans, shall not count
towards indirect foreign investment. However, their 'strategic downstream
investment' shall count towards indirect foreign investment. For this purpose,
'strategic downstream investments' would mean investment by these banking
companies in their subsidiaries, joint ventures and associates.

16

<!-- page 18 -->

3.8.4.2

Downstream investments by eligible Indian entities/LLPs will be subject to the
following conditions:
(i)

Such an entity is to notify SIA, DIPP and FIPB of its downstream investment in
the form available at http://www.fipbindia.com within 30 days of such
investment, even if capital instruments have not been allotted along with the
modality of investment in new/existing ventures (with/without expansion
programme);

(ii) Downstream investment by way of induction of foreign investment in an existing
Indian Company to be duly supported by a resolution of the Board of Directors
as also a share-holders agreement, if any;
(iii) Issue/transfer/pricing/valuation of capital shall be in accordance with applicable
SEBI/RBI guidelines;
(iv) For the purpose of downstream investment, the eligible Indian entities making
the downstream investments would have to bring in requisite funds from abroad
and not leverage funds from the domestic market. This would, however, not
preclude downstream companies/LLPs, with operations, from raising debt in the
domestic market. Downstream investments through internal accruals are
permissible, subject to the provisions of paragraphs 3.8.3 and 3.8.4.1. For the
purposes of foreign investment policy, internal accruals will mean as profits
transferred to reserve account after payment of taxes.
3.9
3.9.1

Remittance, Reporting and Violation
The Government has provided elaborated scheme for remittance, reporting and
violation of FDI policy. These are available at Annexure-6.

17

<!-- page 19 -->

Chapter 4: Foreign Investment Promotion Board (FIPB)
4.1
4.1.1

Constitution of FIPB
FIPB comprises of the following Secretaries to the Government of India:
(i) Secretary to Government, Department of Economic Affairs, Ministry of
Finance – Chairperson
(ii) Secretary to Government, Department of Industrial Policy &Promotion,
Ministry of Commerce & Industry
(iii) Secretary to Government, Department of Commerce, Ministry of
Commerce & Industry
(iv) Secretary to Government, Economic Relations, Ministry
Affairs

of

External

4.1.2

The Board would be able to co-opt other Secretaries to the Central Government and
top officials of financial institutions, banks and professional experts of Industry and
Commerce, as and when necessary.

4.2

Levels of Approvals for Cases under Government Route

4.2.1

The Minister of Finance who is in-charge of FIPB would consider the recommendations
of FIPB on proposals with total foreign equity inflow of and below Rs.5000 crore.

4.2.2

The recommendations of FIPB on proposals with total foreign equity inflow of more
than Rs. 5000 crore would be placed for consideration of Cabinet Committee on
Economic Affairs (CCEA).

4.2.3

The CCEA would also consider the proposals which may be referred to it by the
FIPB/the Minister of Finance (in-charge of FIPB).

4.3

Cases which do not require Fresh Approval

4.3.1

Companies may not require fresh prior approval of the Government i.e. Minister-incharge of FIPB/CCEA for bringing in additional foreign investment into the same entity,
in the following cases:
(i) Entities the activities of which had earlier required prior approval of FIPB/Cabinet
Committee on Foreign Investment (CCFI)/CCEA and which had, accordingly, earlier
obtained prior approval of FIPB/CCFI/CCEA for their initial foreign investment but
subsequently such activities/sectors have been placed under automatic route;
(ii) Entities the activities of which had sectoral caps earlier and which had, accordingly,
earlier obtained prior approval of FIPB/CCFI/CCEA for their initial foreign investment
but subsequently such caps were removed/increased and the activities placed under

18

<!-- page 20 -->

the automatic route; provided that such additional investment along with the
initial/original investment does not exceed the sectoral caps;
(iii) Additional foreign investment into the same entity where prior approval
of
FIPB/CCFI/CCEA had been obtained earlier for the initial/original foreign investment
due to requirements of Press Note 18/1998 or Press Note 1 of 2005 and prior
approval of the Government under the FDI policy is not required for any other
reason/purpose; and
(iv) Additional foreign investment into the same entity within an approved
equity percentage/or into a wholly owned subsidiary.

foreign

4.4

Online Filing of Applications for FIPB/Government’s Approval

4.4.1

Guidelines for e-filing of applications, filing of amendment applications and instructions
to applicants are available at FIPB’s website (http://finmin.nic.in/) and
(http://fipb.gov.in).

19

<!-- page 21 -->

Chapter 5: Sector Specific Conditions on FDI
5.1Prohibited Sectors
FDI is prohibited in:
a)
Lottery Business including Government/private lottery, online lotteries, etc.
b)

Gambling and Betting including casinos etc.

c)

Chit funds

d)

Nidhi company

e)

Trading in Transferable Development Rights (TDRs)

f)

Real Estate Business or Construction of Farm Houses
‘Real estate business’ shall not include development of townships, construction of
residential /commercial premises, roads or bridges and Real Estate Investment Trusts
(REITs) registered and regulated under the SEBI (REITs) Regulations 2014.

g)

Manufacturing of cigars, cheroots, cigarillos and cigarettes, of tobacco or of tobacco
substitutes

h)

Activities/sectors not open to private sector investment e.g.(I) Atomic Energy and (II)
Railway operations(other than permitted activities mentioned in para 5.2).
Foreign technology collaboration in any form including licensing for franchise,
trademark, brand name, management contract is also prohibited for Lottery Business
and Gambling and Betting activities.

5.2 Permitted Sectors
a)

In the following sectors/activities, FDI up to the limit indicated against each sector/activity is
allowed, subject to applicable laws/regulations; securityand other conditionalities. In
sectors/activities not listed below, FDI is permitted up to100% on the automatic route,
subject to applicable laws/regulations; security and other conditionalities.
Wherever there is a requirement of minimum capitalization, it shall include share premium
received along with the face value of the share, only when it is received by the company
upon issue of the shares to the non-resident investor. Amount paid by the transferee during
post-issue transfer of shares beyond the issue price of the share, cannot be taken into
account while calculating minimum capitalization requirement.

b)

Sectoral cap i.e. the maximum amount which can be invested by foreign investors in an
entity, unless provided otherwise, is composite and includes all types of foreign
investments, direct and indirect, regardless of whether the said investments have been
made under Schedule 1 (FDI), 2 (FII), 2A (FPI), 3 (NRI), 6 (FVCI), 9 (LLPs), 10 (DRs) and
11(Investment Vehicle) of FEMA (Transfer or Issue of Security by Persons Resident
Outside India) Regulations. FCCBs and DRs having underlying of instruments which can
be issued under Schedule 5, being in the nature of debt, shall not be treated as foreign

20

<!-- page 22 -->

investment. However, any equity holding by a person resident outside India resulting from
conversion of any debt instrument under any arrangement shall be reckoned as foreign
investment under the composite cap.
c)

Foreign investment in sectors under Government approval route resulting in transfer of
ownership and/or control of Indian entities from resident Indian citizens to non-resident
entities will be subject to Government approval. Foreign investment in sectors under
automatic route but with conditionalities, resulting in transfer of ownership and/or control of
Indian entities from resident Indian citizens to non-resident entities, will be subject to
compliance of such conditionalities.

d)

The sectors which are already under 100% automatic route and are without conditionalities
would not be affected.

e)

Notwithstanding anything contained in paragraphs a) and c) above, portfolio investment, up
to aggregate foreign investment level of 49% or sectoral/statutory cap, whichever is lower,
will not be subject to either Government approval or compliance of sectoral conditions, as
the case may be, if such investment does not result in transfer of ownership and/or control
of Indian entities from resident Indian citizens to non-resident entities. Other foreign
investments will be subject to conditions of Government approval and compliance of
sectoral conditions as laid down in the FDI policy.

f)

Total foreign investment, direct and indirect, in an entity will not exceed the sectoral/statutory
cap.

g)

Any existing foreign investment already made in accordance with the policy in existence
would not require any modification to conform to amendments introduced through Press
Note 8 (2015 Series).

h)

The onus of compliance of above provisions will be on the investee company.

Agriculture
5.2.1 Agriculture & Animal Husbandry
Sector/Activity

% of Equity/
FDI Cap

Entry
Route

a) Floriculture, Horticulture, Apiculture and Cultivation of

100%

Automatic

Vegetables & Mushrooms under controlled conditions;
b) Development and Production of seeds and planting material;
c) Animal Husbandry (including breeding of dogs), Pisciculture,
Aquaculture, under controlled conditions; and
d) Services related to agro and allied sectors
Note: Besides the above, FDI is not allowed in any other
agricultural sector/activity

21

<!-- page 23 -->

5.2.1.1 Other Conditions
I.

The term “under controlled conditions” covers the following:
(i) ‘Cultivation under controlled conditions’ for the categories of floriculture, horticulture,
cultivation of vegetables and mushrooms is the practice of cultivation wherein rainfall,
temperature, solar radiation, air humidity and culture medium are controlled artificially.
Control in these parameters may be effected through protected cultivation under green
houses, net houses, poly houses or any other improved infrastructure facilities where
micro-climatic conditions are regulated anthropogenically.
(ii) In case of Animal Husbandry, scope of the term ‘under controlled conditions’ covers(a)Rearing of animals under intensive farming systems with stall-feeding. Intensive farming
system will require climate systems (ventilation, temperature/humidity management),
health care and nutrition, herd registering/pedigree recording, use of machinery, waste
management systems as prescribed by the National Livestock Policy, 2013 and in
conformity with the existing ‘Standard Operating Practices and Minimum Standard
Protocol.’
(b)Poultry breeding farms and hatcheries where micro-climate is controlled through
advanced technologies like incubators, ventilation systems etc.
(iii) In the case of pisciculture and aquaculture, scope of the term ‘under controlled conditions’
covers –
(a) Aquariums
(b) Hatcheries where eggs are artificially fertilized and fry are hatched and incubated in
an enclosed environment with artificial climate control.
(iv) In the case of apiculture, scope of the term ‘under controlled conditions’ covers–
(a) Production of honey by bee-keeping, except in forest/wild, in designated spaces with
control of temperatures and climatic factors like humidity and artificial feeding during
lean seasons.

5.2.2 Plantation Sector
Sector/Activity
5.2.2.1

% of Equity/
FDI Cap

Entry Route

100%

Automatic

(i) Tea sector including tea plantations
(ii) Coffee plantations
(iii) Rubber plantations
(iv) Cardamom plantations
(v) Palm oil tree plantations
(vi) Olive oil tree plantations
Note: Besides the above, FDI is not allowed in any
other plantation sector/activity.

22

<!-- page 24 -->

5.2.2.2 Other Condition
Prior approval of the State Government concerned is required in case of any future land use
change.
Mining and Petroleum & Natural Gas
5.2.3 Mining
Sector/Activity

% of
Equity/
FDI Cap

Entry Route

5.2.3.1
Mining and Exploration of metal and non-metal ores
including diamond, gold, silver and precious ores but
excluding titanium bearing minerals and its ores; subject to
the Mines and Minerals (Development & Regulation) Act,
1957.

100%

Automatic

5.2.3.2
Coal & Lignite
(1) Coal & Lignite mining for captive consumption by power
projects, iron & steel and cement units and other eligible
activities permitted under and subject to the provisions of

100%

Automatic

100%

Government

Coal Mines (Nationalization) Act, 1973.
(2) Setting up coal processing plants like washeries subject
to the condition that the company shall not do coal mining and
shall not sell washed coal or sized coal from its coal
processing plants in the open market and shall supply the
washed or sized coal to those parties who are supplying raw
coal to coal processing plants for washing or sizing.
5.2.3.3
Mining and mineral separation of titanium bearing
minerals and ores, its value addition and integrated
activities
5.2.3.3.1
Mining and mineral separation of titanium bearing minerals &
ores, its value addition and integrated activities subject to
sectoral regulations and the Mines and Minerals (Development
and Regulation Act 1957).
5.2.3.3.2 Other Conditions
(i) FDI for separation of titanium bearing minerals & ores will be subject to the following additional
conditions viz.:

23

<!-- page 25 -->

(A) value addition facilities are set up within India along with transfer of technology;
(B) disposal of tailings during the mineral separation shall be carried out in accordance with
regulations framed by the Atomic Energy Regulatory Board such as Atomic Energy
(Radiation Protection) Rules, 2004 and the Atomic Energy (Safe Disposal of Radioactive
Wastes) Rules, 1987.
(ii) FDI will not be allowed in mining of “prescribed substances” listed in the Notification No. S.O.
61(E), dated 18.1.2006, issued by the Department of Atomic Energy.
Clarification:
(1) For titanium bearing ores such as Ilmenite, Leucoxene and Rutile, manufacture of titanium
dioxide pigment and titanium sponge constitutes value addition. Ilmenite can be processed to
‘produce 'Synthetic Rutile or Titanium Slag as an intermediate value added product.
(2) The objective is to ensure that the raw material available in the country is utilized for setting
up downstream industries and the technology available internationally is also made available
for setting up such industries within the country. Thus, if with the technology transfer, the
objective of the FDI Policy can be achieved, the conditions prescribed at (i) (A) above shall
be deemed to be fulfilled.
5.2.4 Petroleum & Natural Gas
Sector/Activity

% of
Equity/
FDI Cap

Entry
Route

5.2.4.1
Exploration activities of oil and natural gas fields, infrastructure
related to marketing of petroleum products and natural gas,
marketing of natural gas and petroleum products, petroleum product
pipelines, natural gas/pipelines, LNG Regasification infrastructure,
market study and formulation and Petroleum refining in the private
sector, subject to the existing sectoral policy and regulatory
framework in the oil marketing sector and the policy of the
Government on private participation in exploration of oil and the
discovered fields of national oil companies.

100%

Automatic

5.2.4.2

49%

Automatic

Petroleum refining by the Public Sector Undertakings (PSU), without
any disinvestment or dilution of domestic equity in the existing
PSUs.

24

<!-- page 26 -->

Manufacturing
5.2.5 Manufacturing: Subject to the provisions of the FDI policy, foreign investment in
‘manufacturing’ sector is under automatic route. Further, a manufacturer is permitted to sell its
products manufactured in India through wholesale and/or retail, including through e-commerce
without Government approval.
5.2.6 Defence
Sector/Activity

5.2.6.1
Defence Industry subject to Industrial
license
under
the
Industries
(Development & Regulation) Act,
1951

% of
Equity/
FDI Cap
49%

Entry Route

Automatic up to 49%
Above 49% under Government route on
case to case basis, wherever it is likely
to result in access to modern and ‘stateof-art’ technology in the country.

5.2.6.2 Other Conditions
(i) Infusion of fresh foreign investment within the permitted automatic route level, in a company
not seeking industrial license, resulting in change in the ownership pattern or transfer of
stake by existing investor to new foreign investor, will require Government approval.
(ii) Licence applications will be considered and licences given by the Department of Industrial
Policy & Promotion, Ministry of Commerce & Industry, in consultation with Ministry of
Defence and Ministry of External Affairs.
(iii) Foreign investment in the sector is subject to security clearance and guidelines of the M/o
Defence.
(v) Investee company should be structured to be self-sufficient in areas of product design and
development. The investee/joint venture company along with manufacturing facility, should
also have maintenance and life cycle support facility of the product being manufactured in
India.

25

<!-- page 27 -->

Services Sector
5.2.7 Broadcasting
5.2.7.1 Broadcasting Carriage Services
Sector/Activity

% of
Equity/
FDI Cap

5.2.7.1.1
(1)Teleports(setting up of up-linking HUBs/Teleports);

100%

Entry Route

Automatic
49%

up

to

Government route
beyond 49%

(2)Direct to Home (DTH);
(3)Cable Networks (Multi System operators (MSOs)
operating at National or State or District level and
undertaking upgradation of networks towards digitalization
and addressability);
(4)Mobile TV;
(5)Headend-in-the Sky Broadcasting Service(HITS)
5.2.7.1.2
Cable

Networks(Other

MSOs

not

undertaking

100%

upgradation of networks towards digitalization and
addressability and Local Cable Operators (LCOs))

Automatic
49%

up

to

Government route
beyond 49%

5.2.7.2 Broadcasting Content Services
Sector/Activity

% of
Equity/
FDI Cap

Entry Route

5.2.7.2.1 Terrestrial Broadcasting FM(FM Radio),
subject to such terms and conditions, as specified from
time to time, by Ministry of Information & Broadcasting, for
grant of permission for setting up of FM Radio stations

49%

Government

5.2.7.2.2

49%

Government

Up-linking of ‘News & Current Affairs’ TV Channels

26

<!-- page 28 -->

5.2.7.2.3
Up-linking of Non-‘News & Current Affairs’ TV
Channels/ Down-linking of TV Channels

100%

Automatic

5.2.7.3 Detailed guidelines on the Broadcasting Sector are given in Annexure-7.
5.2.8 Print Media
Sector/Activity
5.2.8.1

% of Equity/ FDI Cap

Entry Route

26%

Government

26%

Government

Publishing of newspaper and periodicals dealing
with news and current affairs
5.2.8.2
Publication of Indian editions of foreign
magazines dealing with news and current affairs

5.2.8.2.1 Other Conditions
(i) ‘Magazine’, for the purpose of these guidelines, will be defined as a periodical publication,
brought out on non-daily basis, containing public news or comments on public news.
(ii) Foreign investment would also be subject to the Guidelines for Publication of Indian editions
of foreign magazines dealing with news and current affairs issued by the Ministry of Information
& Broadcasting on 4.12.2008.
Sector/Activity

5.2.8.3

% of Equity/
FDI Cap

Entry
Route

100%

Government

100%

Government

Publishing/printing
of
scientific
and
technical
magazines/specialty journals/ periodicals, subject to
compliance with the legal framework as applicable and
guidelines issued in this regard from time to time by Ministry of
Information and Broadcasting.
5.2.8.4Publication of facsimile edition of foreign newspapers

27

<!-- page 29 -->

5.2.8.4.1 Other Conditions
(i) FDI should be made by the owner of the original foreign newspapers whose facsimile
edition is proposed to be brought out in India.
(ii) Publication of facsimile edition of foreign newspapers can be undertaken only by an entity
incorporated or registered in India under the provisions of the Companies Act, as
applicable.
(iii) Publication of facsimile edition of foreign newspaper would also be subject to the
Guidelines for publication of newspapers and periodicals dealing with news and current
affairs and publication of facsimile edition of foreign newspapers issued by Ministry of
Information & Broadcasting on 31.3.2006, as amended from time to time.

5.2.9 Civil Aviation
5.2.9.1 Airports
Sector/Activity

% of Equity/ FDI Cap

Entry Route

(a) Greenfield projects

100%

Automatic

(b) Existing projects

100%

Automatic up to 74%
Government route beyond 74%

5.2.9.2Air Transport Services
Sector/Activity

% of Equity/
FDI Cap

Entry Route

(1) (a) Scheduled Air Transport Service/
Domestic Scheduled Passenger Airline

49% FDI

Automatic

(100% for NRIs)

(b) Regional Air Transport Service
(2)Non-Scheduled Air Transport Service

100%

Automatic

(3)Helicopter services/seaplane services
requiring DGCA approval

100%

Automatic

28

<!-- page 30 -->

5.2.9.3Other services under Civil Aviation sector
Sector/Activity

% of Equity/
FDI Cap

Entry Route

(1)Ground Handling Services subject to

100%

Automatic

100%

Automatic

sectoral regulations and security clearance
(2)Maintenance and Repair organizations;
flying training institutes; and technical
training institutions.

Definitions: The Civil Aviation sector includes Airports, Scheduled and Non-Scheduled domestic
passenger airlines, Helicopter services/Seaplane services, Ground Handling Services,
Maintenance and Repair organizations; Flying training institutes; and Technical training
institutions.
For the purposes of the Civil Aviation sector:

(i) “Airport” means a landing and taking off area for aircrafts, usually with runways and aircraft
maintenance and passenger facilities and includes aerodrome as defined in clause (2) of
section 2 of the Aircraft Act, 1934;

(ii)“Aerodrome” means any definite or limited ground or water area intended to be used, either
wholly or in part, for the landing or departure of aircraft, and includes all buildings, sheds,
vessels, piers and other structures thereon or pertaining thereto;

(iii) “Air transport service” means a service for the transport by air of persons, mails or any other
thing, animate or inanimate, for any kind of remuneration whatsoever, whether such service
consists of a single flight or series of flights;

(iv) “Air Transport Undertaking” means an undertaking whose business includes the carriage by
air of passengers or cargo for hire or reward;

(v) “Aircraft component” means any part, the soundness and correct functioning of which, when
fitted to an aircraft, is essential to the continued airworthiness or safety of the aircraft and
includes any item of equipment;

(vi) “Helicopter” means a heavier-than-air aircraft supported in flight by the reactions of the air
on one or more power driven rotors on substantially vertical axis;

(vii) “Scheduled air transport service” means an air transport service undertaken between the
same two or more places and operated according to a published time table or with flights
so regular or frequent that they constitute a recognizably systematic series, each flight
being open to use by members of the public;

29

<!-- page 31 -->

(viii) “Non-Scheduled air transport service” means any service which is not a scheduled air
transport service and will include Cargo airlines;

(ix) “Cargo airlines” would mean such airlines which meet the conditions as given in the Civil
Aviation Requirements issued by the Ministry of Civil Aviation;

(x) “Seaplane” means an aeroplane capable normally of taking off from and alighting solely on
water;

(xi) “Ground Handling” means (i) ramp handling, (ii) traffic handling both of which shall include
the activities as specified by the Ministry of Civil Aviation through the Aeronautical
Information Circulars from time to time, and (iii) any other activity specified by the Central
Government to be a part of either ramp handling or traffic handling.
Other Conditions
(a) Air Transport Services would include Domestic Scheduled Passenger Airlines; NonScheduled Air Transport Services, helicopter and seaplane services.
(b) Foreign airlines are allowed to participate in the equity of companies operating Cargo airlines,
helicopter and seaplane services, as per the limits and entry routes mentioned above.
(c) Foreign airlines are also allowed to invest in the capital of Indian companies, operating
scheduled and non-scheduled air transport services, up to the limit of 49% of their paid-up
capital. Such investment would be subject to the following conditions:
(i) It would be made under the Government approval route.
(ii) The 49% limit will subsume FDI and FII/FPI investment.
(iii)The investments so made would need to comply with the relevant regulations of SEBI,
such as the Issue of Capital and Disclosure Requirements (ICDR)
Regulations/Substantial Acquisition of Shares and Takeovers (SAST) Regulations, as
well as other applicable rules and regulations.
(iv)A Scheduled Operator’s Permit can be granted only to a company:
a) that is registered and has its principal place of business within India;
b) the Chairman and at least two-thirds of the Directors of which
are citizens of India; and
c) the substantial ownership and effective control of which is vested
nationals.

in

Indian

(v) All foreign nationals likely to be associated with Indian scheduled and non-scheduled air
transport services, as a result of such investment shall be cleared from security view
point before deployment; and

30

<!-- page 32 -->

(vi)All technical equipment that might be imported into India as a result of such investment
shall require clearance from the relevant authority in the Ministry of Civil Aviation.
Note:(i) The FDI limits/entry routes, mentioned at paragraph 5.2.9.2 (1) and 5.2.9.2 (2) above,
are applicable in the situation where there is no investment by foreign airlines.

(ii) The dispensation for NRIs regarding FDI up to 100% will also continue in respect of the
investment regime specified at para (c)(ii) above.

(iii) The policy mentioned at para (c) above is not applicable to M/s Air India Limited.
5.2.10 Construction Development: Townships, Housing, Built-up Infrastructure
Sector/Activity

5.2.10.1

%% of Equity/
FDI Cap

Entry Route

100%

Automatic

Construction-development projects (which would include
development
of
townships,
construction
of
residential/commercial premises, roads or bridges,
hotels, resorts, hospitals, educational institutions,
recreational facilities, city and regional level
infrastructure, townships)
5.2.10.2
Each phase of the construction development project would be considered as a separate project
for the purposes of FDI policy. Investment will be subject to the following conditions:
(A) (i) The investor will be permitted to exit on completion of the project or after development of
trunk infrastructure i.e. roads, water supply, street lighting, drainage and sewerage.
(ii)Notwithstanding anything contained at (A) (i) above, a foreign investor will be permitted to
exit and repatriate foreign investment before the completion of project under automatic
route, provided that a lock-in-period of three years, calculated with reference to each
tranche of foreign investment has been completed. Further, transfer of stake from one
non-resident to another non-resident, without repatriation of investment will neither be
subject to any lock-in period nor to any government approval.
(B) The project shall conform to the norms and standards, including land use requirements and
provision of community amenities and common facilities, as laid down in the applicable building
control regulations, bye-laws, rules, and other regulations of the State
Government/Municipal/Local Body concerned.

31

<!-- page 33 -->

(C) The Indian investee company will be permitted to sell only developed plots. For the purposes
of this policy “developed plots” will mean plots where trunk infrastructure i.e. roads, water supply,
street lighting, drainage and sewerage, have been made available.
(D) The Indian investee company shall be responsible for obtaining all necessary approvals,
including those of the building/layout plans, developing internal and peripheral areas and other
infrastructure facilities, payment of development, external development and other charges and
complying with all other requirements as prescribed under applicable rules/bye-laws/regulations
of the State Government/Municipal/Local Body concerned.
(E) The State Government/Municipal/Local Body concerned, which approves the
building/development plans, will monitor compliance of the above conditions by the developer.
Note:
(i) It is clarified that FDI is not permitted in an entity which is engaged or proposes to engage in
real estate business, construction of farm houses and trading in transferable development
rights (TDRs).
“Real estate business” means dealing in land and immovable property with a view to
earning profit there from and does not include development of townships, construction of
residential/ commercial premises, roads or bridges, educational institutions, recreational
facilities, city and regional level infrastructure, townships. Further, earning of rent/ income on
lease of the property, not amounting to transfer, will not amount to real estate business.
(ii) Condition of lock-in period at (A) above will not apply to Hotels &Tourist Resorts, Hospitals,
Special Economic Zones (SEZs), Educational Institutions, Old Age Homes and investment by
NRIs.
(iii) Completion of the project will be determined as per the local bye-laws/rules and other
regulations of State Governments.
(iv) It is clarified that 100% FDI under automatic route is permitted in completed projects for
operation and management of townships, malls/ shopping complexes and business centres.
Consequent to foreign investment, transfer of ownership and/or control of the investee
company from residents to non-residents is also permitted. However, there would be a lock-inperiod of three years, calculated with reference to each tranche of FDI, and transfer of
immovable property or part thereof is not permitted during this period.
(v) “Transfer", in relation to FDI policy on the sector, includes,—
(a) the sale, exchange or relinquishment of the asset ; or
(b) the extinguishment of any rights therein; or
(c) the compulsory acquisition thereof under any law ; or

32

<!-- page 34 -->

(d) any transaction involving the allowing of the possession of any immovable property to
be taken or retained in part performance of a contract of the nature referred to in
section 53A of the Transfer of Property Act, 1882 (4 of 1882) ; or
(e) any transaction, by acquiring shares in a company or by way of any agreement or any
arrangement or in any other manner whatsoever, which has the effect of transferring,
or enabling the enjoyment of, any immovable property.
5.2.11Industrial Parks
Sector/Activity
Industrial Parks -new and existing

5.2.11.1

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Other conditions for investment in Industrial Parks are at Annexure-8.

5.2.12 Satellites- establishment and operation
Sector/Activity

% of Equity/
FDI Cap

Entry Route

Satellites- establishment and operation, subject to the
sectoral guidelines of Department of Space/ISRO

100%

Government

% of Equity/
FDI Cap

Entry Route

49%

Government

5.2.13 Private Security Agencies
Sector/Activity
Private Security Agencies
5.2.13.1 Other Conditions
(1) FDI in Private Security Agencies is subject to compliance with Private Security Agencies
(Regulation) (PSAR) Act, 2005, as amended from time to time.
(2) For the purposes of FDI policy on the sector, terms “Private Security Agencies”, “Private
Security” and “Armoured Car Service” will have the same meaning as provided under PSAR
Act, 2005, which is reproduced as under:
"Private Security Agency" means a person or body of persons other than a government
agency, department or organisation engaged in the business of providing private security
services including training to private security guards or their supervisor or providing private
security guards to any industrial or business undertaking or a company or any other person
or property;

33

<!-- page 35 -->

"Private Security" means security provided by a person, other than a public servant, to
protect or guard any person or property or both and includes provision of armoured car
service;
"Armoured Car Service" means the service provided by deployment of armed guards along
with armoured car and such other related services which may be notified by the Central
Government or as the case may be, the State Government from time to time.
5.2.14 Telecom Services
Sector/Activity

% of Equity/
FDI Cap

Entry Route

Telecom Services
(including Telecom Infrastructure Providers
Category-I)
All telecom services including Telecom Infrastructure
Providers Category-I, viz. Basic, Cellular, United Access
Services, Unified License (Access Services), Unified
License,
National/International
Long
Distance,
Commercial V-Sat, Public Mobile Radio Trunked
Services
(PMRTS),
Global
Mobile
Personal
Communications Services (GMPCS), All types of ISP
licenses, Voice Mail/Audiotex/UMS, Resale of IPLC,
Mobile Number Portability Services, Infrastructure
Provider Category-I (providing dark fibre, right of way,
duct space, tower) except Other Service Providers.

100%

Automatic up to
49%
Government
route beyond
49%

5.2.14.1 Other Condition
FDI in Telecom sector is subject to observance of licensing and security conditions by licensee
as well as investors as notified by the Department of Telecommunications (DoT) from time to
time, except “Other Service Providers”, which are allowed 100% FDI on the automatic route.
5.2.15 Trading
Sector/Activity

5.2.15.1

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Cash & Carry Wholesale Trading/Wholesale Trading
(including sourcing from MSEs)
5.2.15.1.1Definition: Cash & Carry Wholesale trading/Wholesale trading, would mean sale of
goods/merchandise to retailers, industrial, commercial, institutional or other professional
business users or to other wholesalers and related subordinated service providers. Wholesale
trading would, accordingly, imply sales for the purpose of trade, business and profession, as

34

<!-- page 36 -->

opposed to sales for the purpose of personal consumption. The yardstick to determine whether
the sale is wholesale or not would be the type of customers to whom the sale is made and not
the size and volume of sales. Wholesale trading would include resale, processing and thereafter
sale, bulk imports with ex-port/ex-bonded warehouse business sales and B2B e-Commerce.
5.2.15.1.2 Guidelines for Cash & Carry Wholesale Trading/Wholesale Trading (WT):
(a) For undertaking WT, requisite licenses/registration/ permits, as specified under the relevant
Acts/Regulations/Rules/Orders of the State Government/Government Body/Government
Authority/Local Self-Government Body under that State Government should be obtained.
(b) Except in case of sales to Government, sales made by the wholesaler would be considered
as ‘cash & carry wholesale trading/wholesale trading’ with valid business customers, only
when WT are made to the following entities:
(I) Entities holding sales tax/ VAT registration/service tax/excise duty registration; or
(II) Entities holding trade licenses i.e. a license/registration certificate/membership
certificate/registration under Shops and Establishment Act, issued by a Government
Authority/Government Body/Local Self-Government Authority, reflecting that the
entity/person holding the license/ registration certificate/ membership certificate, as the
case may be, is itself/ himself/herself engaged in a business involving commercial activity;
or
(III) Entities holding permits/license etc. for undertaking retail trade (like tehbazari and similar
license for hawkers) from Government Authorities/Local Self Government Bodies; or
(IV) Institutions having certificate of incorporation or registration as a society or registration as
public trust for their self consumption.
Note: An entity, to whom WT is made, may fulfill any one of the 4 conditions.
(c) Full records indicating all the details of such sales like name of entity, kind of entity,
registration/license/permit etc. number, amount of sale etc. should be maintained on a day to
day basis.
(d) WT of goods would be permitted among companies of the same group. However, such WT
to group companies taken together should not exceed 25% of the total turnover of the
wholesale venture.
(e) WT can be undertaken as per normal business practice, including extending credit facilities
subject to applicable regulations.
(f) A wholesale/cash & carry trader can undertake single brand retail trading, subject to the
conditions mentioned in para 5.2.15.3. An entity undertaking wholesale/cash and carry as well
as retail business will be mandated to maintain separate books of accounts for these two arms
of the business and duly audited by the statutory auditors. Conditions of the FDI policy for
wholesale/cash and carry business and for retail business have to be separately complied with
by the respective business arms.

35

<!-- page 37 -->

5.2.15.2 E-commerce activities
Sector/Activity
E-commerce activities

% of Equity/FDI Cap

Entry Route

100%

Automatic

5.2.15.2.1 Subject to provisions of FDI Policy, e-commerce entities would engage only in
Business to Business (B2B) e-commerce and not in Business to Consumer (B2C) e-commerce.
5.2.15.2.2 Definitions:
i) E-commerce- E-commerce means buying and selling of goods and services including digital
products over digital & electronic network.
ii)E-commerce entity- E-commerce entity means a company incorporated under the
Companies Act 1956 or the Companies Act 2013 or a foreign company covered under section 2
(42) of the Companies Act, 2013 or an office, branch or agency in India as provided in section 2
(v) (iii) of FEMA 1999, owned or controlled by a person resident outside India and conducting the
e-commerce business.
iii) Inventory based model of e-commerce- Inventory based model of e-commerce means an
e-commerce activity where inventory of goods and services is owned by e-commerce entity and
is sold to the consumers directly.
iv) Marketplace based model of e-commerce- Marketplace based model of e-commerce
means providing of an information technology platform by an e-commerce entity on a digital &
electronic network to act as a facilitator between buyer and seller.
5.2.15.2.3 Guidelines for Foreign Direct Investment on e-commerce sector
i) 100% FDI under automatic route is permitted in marketplace model of e-commerce.
ii) FDI is not permitted in inventory based model of e-commerce.
5.2.15.2.4 Other Conditions
i) Digital & electronic network will include network of computers, television channels and any
other internet application used in automated manner such as web pages, extranets, mobiles
etc.
ii) Marketplace e-commerce entity will be permitted to enter into transactions with sellers
registered on its platform on B2B basis.
iii) E-commerce marketplace may provide support services to sellers in respect of warehousing,
logistics, order fulfillment, call centre, payment collection and other services.

36

<!-- page 38 -->

iv) E-commerce entity providing a marketplace will not exercise ownership over the inventory i.e.
goods purported to be sold. Such an ownership over the inventory will render the business
into inventory based model.
v)

An e-commerce entity will not permit more than 25% of the sales affected through its
marketplace from one vendor or their group companies.

vi) In marketplace model goods/services made available for sale electronically on website should
clearly provide name, address and other contact details of the seller. Post sales, delivery of
goods to the customers and customer satisfaction will be responsibility of the seller.
vii) In marketplace model, payments for sale may be facilitated by the e-commerce entity in
conformity with the guidelines of the Reserve Bank of India.
viii) In marketplace model, any warrantee/ guarantee of goods and services sold will be
responsibility of the seller.
ix) E-commerce entities providing marketplace will not directly or indirectly influence the sale
price of goods or services and shall maintain level playing field.
x) Guidelines on cash and carry wholesale trading as given in para 5.2.15.1.2 above will apply
on B2B e-commerce.

Subject to the conditions of FDI policy on services sector and applicable laws/regulations,
security and other conditionalities, sale of services through e-commerce will be under
automatic route.
5.2.15.3 Single Brand product retail trading
Sector/Activity

Single Brand product retail trading

% of Equity/
FDI Cap

Entry Route

100%

Automatic up to 49%
Government

route

beyond 49%
(1) Foreign Investment in Single Brand product retail trading is aimed at attracting investments
in production and marketing, improving the availability of such goods for the consumer,
encouraging increased sourcing of goods from India, and enhancing competitiveness of Indian
enterprises through access to global designs, technologies and management practices.
(2) FDI in Single Brand product retail trading would be subject to the following conditions:
(a) Products to be sold should be of a ‘Single Brand’ only.
(b) Products should be sold under the same brand internationally i.e. products should

37

<!-- page 39 -->

be sold under the same brand in one or more countries other than India.
(c) ‘Single Brand’ product-retail trading would cover only products which are branded
during manufacturing.
(d) A non-resident entity or entities, whether owner of the brand or otherwise, shall be
permitted to undertake ‘single brand’ product retail trading in the country for the
specific brand, directly or through a legally tenable agreement with the brand owner
for undertaking single brand product retail trading. The onus for ensuring
compliance with this condition will rest with the Indian entity carrying out singlebrand product retail trading in India. The investing entity shall provide evidence to
this effect at the time of seeking approval, including a copy of the
licensing/franchise/sub-licence agreement, specifically indicating compliance with
the above condition. The requisite evidence should be filed with the RBI for the
automatic route and SIA/FIPB for cases involving approval.
(e) In respect of proposals involving foreign investment beyond 51%, sourcing of 30%
of the value of goods purchased, will be done from India, preferably from MSMEs,
village and cottage industries, artisans and craftsmen, in all sectors. The quantum
of domestic sourcing will be self-certified by the company, to be subsequently
checked, by statutory auditors, from the duly certified accounts which the company
will be required to maintain. This procurement requirement would have to be met, in
the first instance, as an average of five years’ total value of the goods purchased,
beginning 1st April of the year of the commencement of the business i.e. opening of
the first store. Thereafter, it would have to be met on an annual basis. For the
purpose of ascertaining the sourcing requirement, the relevant entity would be the
company, incorporated in India, which is the recipient of foreign investment for the
purpose of carrying out single-brand product retail trading.
(f) Subject to the conditions mentioned in this Para, a single brand retail trading entity
operating through brick and mortar stores, is permitted to undertake retail trading
through e-commerce.
(3) Application seeking permission of the Government for FDI exceeding 49% in a company
which proposes to undertake single brand retail trading in India would be made to the
Secretariat for Industrial Assistance (SIA) in the Department of Industrial Policy & Promotion.
The applications would specifically indicate the product/product categories which are proposed
to be sold under a ‘Single Brand’. Any addition to the product/product categories to be sold
under ‘Single Brand’ would require a fresh approval of the Government. In case of FDI up to
49%, the list of products/product categories proposed to be sold except food products would
be provided to the RBI.
(4) Applications would be processed in the Department of Industrial Policy & Promotion, to
determine whether the proposed investment satisfies the notified guidelines, before being
considered by the FIPB for Government approval.

38

<!-- page 40 -->

Note:
(i) Conditions mentioned at Para 5.2.15.3 (2) (b) & 5.2.15.3 (2) (d) will not be applicable for
undertaking SBRT of Indian brands.
(ii) An Indian manufacturer is permitted to sell its own branded products in any manner i.e.
wholesale, retail, including through e-commerce platforms.
(iii) Indian manufacturer would be the investee company, which is the owner of the Indian
brand and which manufactures in India, in terms of value, at least 70% of its products in
house, and sources, at most 30% from Indian manufacturers.
(iv) Indian brands should be owned and controlled by resident Indian citizens and/or
companies which are owned and controlled by resident Indian citizens.
(v) Government may relax sourcing norms for entities undertaking single brand retail trading of
products having ‘state-of-art’ and ‘cutting-edge’ technology and where local sourcing is not
possible.

5.2.15.4 Multi Brand Retail Trading
Sector/Activity

Multi Brand Retail Trading

% of Equity/
FDI Cap

Entry Route

51%

Government

(1)FDI in multi brand retail trading, in all products, will be permitted, subject to the following
conditions:
(i) Fresh agricultural produce, including fruits, vegetables, flowers, grains, pulses, fresh
poultry, fishery and meat products, may be unbranded.
(ii) Minimum amount to be brought in, as FDI, by the foreign investor, would be US $ 100
million.
(iii) At least 50% of total FDI brought in the first tranche of US $ 100 million, shall be
invested in 'back-end infrastructure' within three years, where ‘back-end
infrastructure’ will include capital expenditure on all activities, excluding that on frontend units; for instance, back-end infrastructure will include investment made towards
processing, manufacturing, distribution, design improvement, quality control,
packaging, logistics, storage, ware-house, agriculture market produce infrastructure
etc. Expenditure on land cost and rentals, if any, will not be counted for purposes of
backend infrastructure. Subsequent investment in backend infrastructure would be
made by the MBRT retailer as needed, depending upon its business requirements.
(iv) At least 30% of the value of procurement of manufactured/processed products
purchased shall be sourced from Indian micro, small and medium industries, which

39

<!-- page 41 -->

have a total investment in plant & machinery not exceeding US $ 2.00 million. This
valuation refers to the value at the time of installation, without providing for
depreciation. The ‘small industry’ status would be reckoned only at the time of first
engagement with the retailer, and such industry shall continue to qualify as a ‘small
industry’ for this purpose, even if it outgrows the said investment of US $ 2.00 million
during the course of its relationship with the said retailer. Sourcing from agricultural
co-operatives and farmers co-operatives would also be considered in this category.
The procurement requirement would have to be met, in the first instance, as an
average of five years’ total value of the manufactured/processed products
purchased, beginning 1st April of the year during which the first tranche of FDI is
received. Thereafter, it would have to be met on an annual basis.
(v) Self-certification by the company, to ensure compliance of the conditions at serial
nos. (ii), (iii) and (iv) above, which could be cross-checked, as and when required.
Accordingly, the investors shall maintain accounts, duly certified by statutory auditors.
(vi) Retail sales outlets may be set up only in cities with a population of more than 10
lakh as per 2011 Census or any other cities as per the decision of the respective
State Governments, and may also cover an area of 10 kms around the
municipal/urban agglomeration limits of such cities; retail locations will be restricted to
conforming areas as per the Master/Zonal Plans of the concerned cities and provision
will be made for requisite facilities such as transport connectivity and parking.
(vii) Government will have the first right to procurement of agricultural products.
(viii) The above policy is an enabling policy only and the State Governments/Union
Territories would be free to take their own decisions in regard to implementation of
the policy. Therefore, retail sales outlets may be set up in those States/Union
Territories which have agreed, or agree in future, to allow FDI in MBRT under this
policy. The list of States/Union Territories which have conveyed their agreement is at
(2) below. Such agreement, in future, to permit establishment of retail outlets under
this policy, would be conveyed to the Government of India through the Department of
Industrial Policy & Promotion and additions would be made to the list at (2) below
accordingly. The establishment of the retail sales outlets will be in compliance of
applicable State/Union Territory laws/ regulations, such as the Shops and
Establishments Act etc.
(ix) Retail trading, in any form, by means of e-commerce, would not be permissible, for
companies with FDI, engaged in the activity of multi-brand retail trading.
(x) Applications would be processed in the Department of Industrial Policy & Promotion,
to determine whether the proposed investment satisfies the notified guidelines,
before being considered by the FIPB for Government approval.
(2) List of States/Union Territories as mentioned in Paragraph 5.2.15.4(1)(viii)
1.Andhra Pradesh
2.Assam
3.Delhi

40

<!-- page 42 -->

4.Haryana
5.Himachal Pradesh
6.Jammu & Kashmir
7. Karnataka
8.Maharashtra
9.Manipur
10. Rajasthan
11. Uttarakhand
12. Daman & Diu and Dadra and Nagar Haveli (Union Territories)
5.2.15.5 Duty Free Shops
Sector/Activity

Duty Free Shops

% of Equity/
FDI Cap

Entry Route

100%

Automatic

(i) Duty Free Shops would mean shops set up in custom bonded area at International
Airports/International Seaports and Land Custom Stations where there is transit of
international passengers.
(ii) Foreign investment in Duty Free Shops is subject to compliance of conditions stipulated
under the Customs Act, 1962 and other laws, rules and regulations.
(iii) Duty Free Shop entity shall not engage into any retail trading activity in the Domestic Tariff
Area of the country.

5.2.16 Railway Infrastructure
Sector/Activity

Railway Infrastructure

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Construction, operation and maintenance of the following:
(i) Suburban corridor projects through PPP, (ii) High speed
train projects, (iii) Dedicated freight lines, (iv) Rolling stock
including train sets, and locomotives/coaches manufacturing
and maintenance facilities, (v) Railway Electrification, (vi)
Signaling systems, (vii) Freight terminals, (viii) Passenger
terminals, (ix) Infrastructure in industrial park pertaining to
railway line/sidings including electrified railway lines and
connectivities to main railway line and (x) Mass Rapid
Transport Systems.

41

<!-- page 43 -->

Note:
(i) Foreign Direct Investment in the abovementioned activities open to private sector
participation including FDI is subject to sectoral guidelines of Ministry of Railways.
(ii)Proposals involving FDI beyond 49% in sensitive areas from security point of view, will be
brought by the Ministry of Railways before the Cabinet Committee on Security (CCS) for
consideration on a case to case basis.

Financial Services
Foreign investment in other financial services, other than those indicated below, would require
prior approval of the Government.
5.2.17 Asset Reconstruction Companies
Sector/Activity

% of Equity/
FDI Cap

Entry Route

5.2.17.1‘Asset Reconstruction Company’ (ARC) means a
company registered with the Reserve Bank of India
under Section 3 of the Securitisation and Reconstruction
of Financial Assets and Enforcement of Security Interest
Act, 2002 (SARFAESI Act).

100%

Automatic

5.2.17.2 Other Conditions
(i) Persons resident outside India can invest in the capital of Asset Reconstruction Companies
(ARCs) registered with Reserve Bank of India, up to 100% on the automatic route.
(ii) Investment limit of a sponsor in the shareholding of an ARC will be governed by the
provisions of Securitisation and Reconstruction of Financial Assets and Enforcement of
Security Interest Act, 2002, as amended from time to time. Similarly, investment by
institutional / non-institutional investors will also be governed by the said Act, as amended
from time to time.
(iii) The total shareholding of an individual FII/FPI shall be below 10% of the total paid-up capital.
(iv) FIIs / FPIs can invest in the Security Receipts (SRs) issued by ARCs registered with Reserve
Bank of India. FIIs / FPIs may be allowed up to 100 per cent of each tranche in SRs issued
by ARCs, subject to directions / guidelines of Reserve Bank of India.
(v) All investments would be subject to provisions of the Securitisation and Reconstruction of
Financial Assets and Enforcement of Security Interest Act, 2002, as amended from time to
time.

42

<!-- page 44 -->

5.2.18 Banking- Private Sector
Sector/Activity

% of Equity/ FDI Cap

5.2.18.1

74%

Entry Route
Automatic up to 49%

Banking- Private Sector

Government
route
beyond 49% and up to
74%.

5.2.18.2 Other Conditions
(1) This 74% limit will include investment under the Portfolio Investment Scheme (PIS) by
FIIs/FPIs, NRIs and shares acquired prior to September 16, 2003 by erstwhile OCBs, and
continue to include IPOs, Private placements, GDR/ADRs and acquisition of shares from
existing shareholders.
(2) The aggregate foreign investment in a private bank from all sources will be allowed up to a
maximum of 74 per cent of the paid up capital of the Bank. At all times, at least 26 per cent
of the paid up capital will have to be held by residents, except in regard to a wholly-owned
subsidiary of a foreign bank.
(3) The stipulations as above will be applicable to all investments in existing private sector banks
also.
(4) Other conditions in respect of permissible limits under portfolio investment schemes through
stock exchanges for FIIs/FPIs and NRIs, setting-up of a subsidiary by foreign banks and
limits in respect of voting rights are at Annexure-9.
5.2.19 Banking- Public Sector
Sector/Activity

% of Equity/
FDI Cap

Entry Route

5.2.19.1 Banking- Public Sector subject to Banking

20%

Government

Companies (Acquisition & Transfer of Undertakings) Acts
1970/80. This ceiling (20%) is also applicable to the
State Bank of India and its associate Banks.

5.2.20Credit Information Companies (CIC)
Sector/Activity

% of Equity/ FDI Cap

Entry Route

100%

Automatic

5.2.20.1
Credit Information Companies

43

<!-- page 45 -->

5.2.20.2 Other Conditions
(1) Foreign investment in Credit Information Companies is subject to the Credit Information
Companies (Regulation) Act, 2005.
(2) Foreign investment is permitted subject to regulatory clearance from RBI.
(3) Such FII/FPI investment would be permitted subject to the conditions that:
(a) A single entity should directly or indirectly hold below 10% equity.
(b) Any acquisition in excess of 1% will have to be reported to RBI as a mandatory
requirement; and
(c) FIIs/FPIs investing in CICs shall not seek a representation on the Board of Directors
based upon their shareholding.
5.2.21 Infrastructure Company in the Securities Market
Sector/Activity

5.2.21.1Infrastructure

companies

in

% of Equity/ FDI Cap

Entry Route

49%

Automatic

Securities
Markets,
namely,
stock
exchanges,
commodity
exchanges,
depositories and clearing corporations, in
compliance with SEBI Regulations

5.2.21.2 Other Conditions
(i) FII/FPI can invest only through purchases in the secondary market.
(ii) No non-resident investor/entity, including persons acting in concert, will hold more than 5% of
the equity in commodity exchanges.
(iii) Foreign investment in commodity exchanges will be subject to the guidelines of the Central
Government/SEBI from time to time.
Definitions:
(1) Futures trading in commodities are regulated under the Forward Contracts (Regulation) Act,
1952. Commodity Exchanges, like Stock Exchanges, are infrastructure companies in the
commodity futures market. With a view to infuse globally acceptable best practices, modern
management skills and latest technology, it was decided to allow foreign investment in
Commodity Exchanges.
(2) For the purposes of this chapter,

44

<!-- page 46 -->

(i)“Commodity Exchange” is a recognized association under the provisions of the Forward
Contracts (Regulation) Act, 1952, as amended from time to time, to provide exchange
platform for trading in forward contracts in commodities.
(ii) “recognized association” means an association to which recognition for the time being has
been granted by the Central Government under Section 6 of the Forward Contracts
(Regulation) Act, 1952
(iii)“Association” means any-body of individuals, whether incorporated or not, constituted for
the purposes of regulating and controlling the business of the sale or purchase of any
goods and commodity derivative.
(iv)“Forward contract” means a contract for the delivery of goods and which is not a ready
delivery contract.
(v) “Commodity derivative” means-

 a contract for delivery of goods, which is not a ready delivery contract; or
 a contract for differences which derives its value from prices or indices of prices of
such underlying goods or activities, services, rights, interests and events, as may be
notified in consultation with SEBI by the Central Government, but does not include
securities.
5.2.22 Insurance
Sector/Activity

5.2.22.1

% of Equity/ FDI Cap

49%

Entry Route

Automatic

(i) Insurance Company
(ii) Insurance Brokers
(iii) Third Party Administrators
(iv) Surveyors and Loss Assessors
(v)Other Insurance Intermediaries appointed
under the provisions of Insurance
Regulatory and Development Authority Act,
1999 (41 of 1999)
5.2.22.2 Other Conditions
(a) No Indian Insurance company shall allow the aggregate holdings by way of total foreign
investment in its equity shares by foreign investors, including portfolio investors, to exceed
forty-nine percent of the paid up equity capital of such Indian Insurance company.

45

<!-- page 47 -->

(b) The foreign investment up to forty-nine percent of the total paid-up equity of the Indian
Insurance Company shall be allowed on the automatic route subject to approval/verification
by the Insurance Regulatory and Development Authority of India.
(c) Foreign investment in this sector shall be subject to compliance with the provisions of the
Insurance Act, 1938 and the condition that Companies receiving FDI shall obtain necessary
license /approval from the Insurance Regulatory & Development Authority of India for
undertaking insurance and related activities.
(d) An Indian Insurance company shall ensure that its ownership and control remains at all times
in the hands of resident Indian entities as determined by Department of Financial Services/
Insurance Regulatory and Development Authority of India as per the rules/regulation issued
by them from time to time.
(e) Foreign portfolio investment in an Indian Insurance company shall be governed by the
provisions contained in sub-regulations (2), (2A), (3) and (8) of Regulation 5 of FEMA
Regulations, 2000 and provisions of the Securities and Exchange Board of India (Foreign
Portfolio Investors) Regulations, 2014.
(f) Any increase in foreign investment in an Indian Insurance company shall be in accordance
with the pricing guidelines specified by Reserve Bank of India under the FEMA Regulations.
(g) The foreign equity investment cap of 49 percent shall apply on the same terms as above to
Insurance Brokers, Third Party Administrators, Surveyors and Loss Assessors and Other
Insurance Intermediaries appointed under the provisions of the Insurance Regulatory and
Development Authority Act,1999 (41 of 1999).
(h) Provided that where an entity like a bank, whose primary business is outside the insurance
area, is allowed by the Insurance Regulatory and Development Authority of India to function
as an insurance intermediary, the foreign equity investment caps applicable in that sector
shall continue to apply, subject to the condition that the revenues of such entities from their
primary (i.e., non-insurance related) business must remain above 50 percent of their total
revenues in any financial year.
(i) The provisions of paragraphs (i) (b) and (d) of Annexure 9 relating to ‘Banking-Private
Sector’, shall be applicable in respect of bank promoted insurance companies.
(j) Terms ‘Control’, ‘Equity Share Capital’, ‘Foreign Direct Investment’ (FDI), ‘Foreign Investors’,
‘Foreign Portfolio Investment’, ‘Indian Insurance Company’, ‘Indian Company’, ‘Indian
Control of an Indian Insurance Company’, ‘Indian Ownership’, ‘Non-resident Entity’, ‘Public
Financial Institution’, ‘Resident Indian Citizen’, ‘Total Foreign Investment’ will have the same
meaning as provided in Notification No. G.S.R 115 (E), dated 19th February, 2015 issued by
Department of Financial Services and regulations issued by Insurance Regulatory and
Development Authority of India from time to time.

46

<!-- page 48 -->

5.2.23 Pension Sector
Sector/Activity

Pension Sector

% of Equity/ FDI Cap

49%

Entry Route

Automatic

Other Conditions
(i) Foreign investment in the Pension Funds is allowed as per the Pension Fund Regulatory and
Development Authority (PFRDA) Act, 2013.
(ii) Foreign Investment in Pension Funds will be subject to the condition that entities bringing in
foreign equity investment as per Section 24 of the PFRDA Act shall obtain necessary
registration from the Pension Fund Regulatory and Development Authority and comply with
other requirements as per the PFRDA Act, 2013 and Rules and Regulations framed under it
for so participating in Pension Fund Management activities in India.
(iii) Wherever such foreign equity investment involves control or ownership by the foreign
investor or, transfer of control or ownership of an existing pension fund from resident Indian
citizens and/ or Indian companies owned and controlled by resident Indian citizens to such
foreign investing entities as a consequence of the investment, including through transfer of
shares and or fresh issue of shares to Non-Resident entities through acquisition,
amalgamation, merger etc., it would require Government approval in consultation with the
Department of Financial Services, PFRDA and other entities concerned and the onus of
compliance to these conditions will be on investee Indian pension fund company. The
meaning of ownership and control would be as per the Foreign Direct Investment policy.
5.2.24 Power Exchanges
Sector/Activity

5.2.24.1

% of Equity/ FDI Cap

Entry Route

49%

Automatic

Power Exchanges registered under the
Central Electricity Regulatory Commission
(Power Market) Regulations, 2010.
5.2.24.2 Other Conditions
(i) FII/FPI purchases shall be restricted to secondary market only;
(ii) No non-resident investor/entity, including persons acting in concert, will hold more than 5% of
the equity in these companies; and

47

<!-- page 49 -->

(iii) The foreign investment would be in compliance with SEBI Regulations; other applicable
laws/regulations; security and other conditionalities.
5.2.25 White Label ATM Operations
Sector/Activity

% of Equity/
FDI Cap

Entry Route

100%

Automatic

White Label ATM Operations

Other Conditions
(i)

Any non-bank entity intending to set up WLAs should have a minimum net worth of Rs. 100
crore as per the latest financial year’s audited balance sheet, which is to be maintained at all
times.

(ii) In case the entity is also engaged in any other 18 NBFC activities, then the foreign
investment in the company setting up WLA, shall also have to comply with the minimum
capitalization norms for foreign investments in NBFC activities as provided in Para 5.2.26.2..
(iii) FDI in the WLAO will be subject to the specific criteria and guidelines issued by RBI vide
Circular No. DPSS.CO.PD.No. 2298/02.10.002/2011-2012, as amended from time to time.
5.2.26 Non-Banking Finance Companies (NBFC)
Sector/Activity

% of Equity/
FDI Cap

Entry Route

5.2.26.1
Foreign investment in NBFC is allowed under the
automatic route in only the following activities:

100%

Automatic

(i)Merchant Banking
(ii) Under Writing
(iii) Portfolio Management Services
(iv) Investment Advisory Services
(v) Financial Consultancy
(vi) Stock Broking
(vii)Asset Management
(viii) Venture Capital
(ix) Custodian Services
(x) Factoring
(xi) Credit Rating Agencies

48

<!-- page 50 -->

(xii)Leasing & Finance
(xiii) Housing Finance
(xiv) Forex Broking
(xv) Credit Card Business
(xvi) Money Changing Business
(xvii) Micro Credit
(xviii) Rural Credit

5.2.26.2 Other Conditions
(1) Investment would be subject to the following minimum capitalisation norms:
(i) US $ 0.5 million for foreign capital up to 51% to be brought upfront.
(ii) US $ 5 million for foreign capital more than 51% and up to 75% to be brought upfront.
(iii)US $ 50 million for foreign capital more than 75% out of which US $ 7.5 million to be
brought upfront and the balance in 24 months.
(iv)NBFCs (i) having foreign investment more than 75% and up to 100%, and (ii) with a
minimum capitalisation of US $ 50 million, can set up step down subsidiaries for
specific NBFC activities, without any restriction on the number of operating subsidiaries
and without bringing in additional capital. The minimum capitalization condition as
mandated by para 3.8.4.1, therefore, shall not apply to downstream subsidiaries.
(v) Joint Venture operating NBFCs that have 75% or less than 75% foreign investment can
also set up subsidiaries for undertaking other NBFC activities, subject to the
subsidiaries also complying with the applicable minimum capitalisation norm mentioned
in (i), (ii) and (iii) above and (vi) below.
(vi)Non- Fund based activities: US $0.5 million to be brought upfront for all permitted nonfund based NBFCs irrespective of the level of foreign investment subject to the
following condition:
It would not be permissible for such a company to set up any subsidiary for any other
activity, nor it can participate in any equity of an NBFC holding/operating company.
Note: The following activities would be classified as Non-Fund Based activities:
(a) Investment Advisory Services
(b) Financial Consultancy
(c) Forex Broking

49

<!-- page 51 -->

(d) Money Changing Business
(e) Credit Rating Agencies
(vii) This will be subject to compliance with the guidelines of RBI.
Note:(i)Credit Card business includes issuance, sales, marketing & design of various payment
products such as credit cards, charge cards, debit cards, stored value cards, smart
card, value added cards etc.
(ii) Leasing & Finance covers only financial leases and not operating leases. FDI in
operating leases is permitted up to 100% on the automatic route.
(2)The NBFC will have to comply with the guidelines of the relevant regulator/s, as applicable.
Others
5.2.27 Pharmaceuticals
Sector/Activity

% of Equity/ FDI Cap

Entry Route

5.2.27.1
Greenfield

100%

Automatic

5.2.27.2
Brownfield

100%

Government

5.2.27.3 Other Conditions
(i) ‘Non-compete’ clause would not be allowed except in special circumstances with the approval
of the Foreign Investment Promotion Board.
(ii) The prospective investor and the prospective investee are required to provide a certificate
along with the FIPB application as per Annexure-10.
(iii) Government may incorporate appropriate conditions for FDI in brownfield cases, at the time
of granting approval.
Note:
i. FDI up to 100%, under the automatic route is permitted for manufacturing of medical
devices. The above mentioned conditions will, therefore, not be applicable to greenfield as
well as brownfield projects of this industry.
ii. Medical device meansa. any instrument, apparatus, appliance, implant, material or other article, whether used
alone or in combination, including the software, intended by its manufacturer to be
used specially for human beings or animals for one or more of the specific purposes
of-

50

<!-- page 52 -->

(aa)diagnosis, prevention, monitoring, treatment or alleviation of any disease or
disorder;
(ab) diagnosis, monitoring, treatment, alleviation of, or assistance for, any injury or
handicap;
(ac) investigation, replacement or modification or support of the anatomy or of a
physiological process;
(ad) supporting or sustaining life;
(ae) disinfection of medical devices;
(af) control of conception,
and which does not achieve its primary intended action in or on the human body or
animals by any pharmacological or immunological or metabolic means, but which
may be assisted in its intended function by such means;
b. an accessory to such an instrument, apparatus, appliance, material or other article;
c. a device which is reagent, reagent product, calibrator, control material, kit, instrument,
apparatus, equipment or system whether used alone or in combination thereof
intended to be used for examination and providing information for medical or
diagnostic purposes by means of in vitro examination of specimens derived from the
human body or animals.
iii. The definition of medical device at Note (ii) above would be subject to the amendment in
Drugs and Cosmetics Act.

51

<!-- page 53 -->

Annexures

Annexure-1

Form FC-GPR
(To be filed by the company through its Authorised Dealer Category – I bank with the Regional Office of the
RBI under whose jurisdiction the Registered Office of the company making the declaration is situated as
and when shares/convertible debentures / others are issued to the foreign investor, along with the
documents mentioned in item No. 5 of the undertaking enclosed to this form. All fields are mandatory) .

Permanent Account Number (PAN)
of the investee company given by
the Income Tax Department

Date of issue of shares /
convertible debentures/others

Particulars

No.
1.

(In Block Letters)

Name of the Investee Company

Address of the Registered Office of
the Investee Company with City,
District and State clearly mentioned
Telephone
Fax
e-mail
State
Registration No. given by Registrar of
Companies and Date of
Incorporation.

Whether existing company or new
company (strike off whichever is not
applicable)

Existing company / New company
(Brownfield)
( Greenfield)

If existing company, give registration
number allotted by RBI for FDI, if any

2.

Description of the main business

52

<!-- page 54 -->

activity NIC Code
Location of the project and NIC code
for the district where the project is
located
a)Detailed address including Name,
City, District and State
b) Code for District
c) Code for State
Percentage of FDI allowed as per
FDI policy (Sectoral cap under FDI
Policy)
State whether FDI is allowed under
Automatic Route or Approval Route
(strike out whichever is not
applicable) (If under approval route,
give SIA/FIPB approval No. with
date)

3

Automatic Route / Approval Route

Details of the foreign investor / collaborator2 (Details of foreign residence to be
given. Indian address if any should not be given)
Name
Address
Country
Constitution / Nature of the investing
Entity
[Specify whether
1. Individual
2. Company (Please specify if

erstwhile OCB)
3. FII


4. FVCI

5. Foreign Trust
6. Private Equity Fund
7. Pension / Provident Fund
8. Sovereign Wealth Fund


If there is more than one foreign investor/collaborator, separate Annexure may be included for items 3 and 4 of the
Form.
2 SWF means a Government investment vehicle which is funded by foreign exchange assets, and which manages those assets
separately from the official reserves of the monetary authorities.


The investment/s is/are made by FVCI under FDI Scheme in terms of Schedule I to Notification No. FEMA
20/2000-RB dated May 3, 2000.

53

<!-- page 55 -->

(SWF)3
9. Partnership / Proprietorship

Firm
10. Financial Institution
11. NRIs / PIO
12. Others (please specify)]

Date of incorporation:

4

Particulars of Shares / Convertible Debentures /others Issued

(a)

Nature and date of issue
Nature of issue

Date of issue

01

IPO / FPO

02

Preferential allotment /
private placement

03

Rights

04

Bonus

05

Conversion of ECB

06

Conversion of royalty
(including lump sum
payments)

07

Conversion against import of
capital goods by units in SEZ

08

ESOPs

09

Share Swap

10

Others (please specify)

Number of shares/ convertible
debentures/others

Total
(b)

Type of security issued
No.

Nature of
security

01

Equity

02

Compulsorily
Convertible
Debentures

Number

Maturity

Face
value

Premium

Issue
Price per
security

Amount of
inflow*

54

<!-- page 56 -->

03

Compulsorily
Convertible
Preference
shares

04

Others
(please
specify)
Total

i) In case the issue price is greater than the face value please give break up of the premium received.
ii) * In case the issue is against conversion of ECB or royalty or against import of capital goo’s by units in
SEZ, a Chartered Accountant's Certificate certifying the amount outstanding on the date of conversion

(c)

Break up of premium

Amount

Control Premium
Non competition fee
Others@
Total
@

Please specify the nature
(d)

Total inflow (in Rupees) on account of issue of
shares / convertible debentures/others to nonresidents (including premium, if any) vide
(i) Remittance through AD:
(ii) Debit to NRE/FCNR/Escrow A/c with
Bank_________
(iii) Others (please specify)
Date of reporting of (i) and (ii) above to RBI under
Para 9 (1) A of Schedule I to Notification No.
FEMA 20 /2000-RB dated May 3, 2000, as
amended from time to time.

(e)

Disclosure of fair value of shares issued**
We are a listed company and the market value of
a share as on date of the issue is*
We are an un-listed company and the fair value
of a share is*

** before issue of shares

*(Please indicate as applicable)

5. Post issue pattern of shareholding
Equity

Compulsorily
convertible
Preference Shares/

55

<!-- page 57 -->

Debentures/others

a)

No.
of
shares
Amount
(Face
Value)
%
Rs.

No.
of
shares
Amount
(Face
Value)
%
Rs.

Investor category

Non-Resident
01

Individuals

02

Companies

03

FIIs

04

FVCIs

05

Foreign Trusts

06

Private Equity Funds

07

Pension/ Provident Funds

08

Sovereign Wealth Funds

09

Partnership/ Proprietorship Firms

10

Financial Institutions

11

NRIs/PIO

12

Others (please specify)
Sub Total

b)

Resident

Total
DECLARATION TO BE FILED BY THE AUTHORISED REPRESENTATIVE OF THE INDIAN
COMPANY:(Delete whichever is not applicable and authenticate)
We hereby declare that:
1. We comply with the procedure for issue of shares / convertible debentures as laid down under the FDI
scheme as indicated in Notification No. FEMA 20/2000-RB dated 3rd May 2000, as amended from time
to time.
2. The investment is within the sectoral cap / statutory ceiling permissible under the Automatic Route of
RBI and we fulfil all the conditions laid down for investments under the Automatic Route namely (strike
off whichever is not applicable).
a) Shares issued on rights basis to non-residents are in conformity with Regulation 6 of the RBI
Notification No FEMA 20/2000-RB dated 3rd May 2000, as amended from time to time.
OR
b) Shares issued are bonus.
OR



The investment/s is/are made by FVCI under FDI Scheme in terms of Schedule I to Notification No. FEMA
20/2000-RB dated May 3, 2000.

56

<!-- page 58 -->

c)Shares have been issued under a scheme of merger and amalgamation of two or more Indian
companies or reconstruction by way of de-merger or otherwise of an Indian company, duly
approved by a court in India.
OR
d)Shares are issued under ESOP and the conditions regarding this issue have been satisfied
3. Shares have been issued in terms of SIA /FIPB approval No.___________________ dated
____________________
4 The foreign investment received and reported now will be utilized in compliance with the provision of a
Prevention of Money Laundering Act 2002 (PMLA) and Unlawful Activities(Prevention) Act, 1967
(UAPA). We confirm that the investment complies with the provisions of all applicable Rules and
Regulations
5. We enclose the following documents in compliance with Paragraph 9 (1) (B) of Schedule 1 to
Notification No. FEMA 20/2000-RB dated May 3, 2000:
(i)

A certificate from our Company Secretary certifying that

(ii)

(a)

all the requirements of the Companies Act, 1956 have been complied with;

(b)

terms and conditions of the Government approval, if any, have been complied with;

(c)

the company is eligible to issue shares under these Regulations; and

(d)

the company has all original certificates issued by authorised dealers in India
evidencing receipt of amount of consideration in accordance with paragraph 8 of
Schedule 1 to Notification No. FEMA 20/2000-RB dated May 3, 2000.

A certificate from SEBI registered Merchant Banker / Chartered Accountant indicating the
manner of arriving at the price of the shares issued to the persons resident outside India.

6. Unique Identification Numbers given for all the remittances received as consideration for issue of
shares/ convertible debentures/others (details as above), by Reserve Bank.
R
.
.
.
R

(Signature of the Applicant)* :___________________________________________
(Name in Block Letters)

:___________________________________________

(Designation of the signatory) :___________________________________________
Place:
Date:
(* To be signed by Managing Director/Director/Secretary of the Company)

57

<!-- page 59 -->

CERTIFICATE TO BE FILED BY THE COMPANY SECRETARY 4 OF THE INDIAN COMPANY
ACCEPTING THE INVESTMENT:
(As per Para 9 (1) (B) (i) of Schedule 1 to Notification No. FEMA 20/2000-RB dated May 3, 2000)
In respect of the abovementioned details, we certify the following :
1. All the requirements of the Companies Act, 1956 have been complied with.
2. Terms and conditions of the Government approval, if any, have been complied with.
3. The company is eligible to issue shares / convertible debentures/others under these Regulations.
4. The company has all original certificates issued by AD Category – I banks in India, evidencing receipt
of amount of consideration in accordance with paragraph 8 of Schedule 1 to Notification No. FEMA
20/2000-RB dated May 3, 2000.

(Name & Signature of the Company Secretary) (Seal)

FOR USE OF THE RESERVE BANK ONLY:
Registration Number for the FC-GPR:
Unique Identification Number allotted to the
Company at the time of reporting receipt of remittance

4

If the company doesn’t have full time Company Secretary, a certificate from practicing Company Secretary may be
submitted

58

<!-- page 60 -->

Types of Instruments
1.

Annexure-2

Indian companies can issue equity shares, fully, compulsorily and mandatorily convertible
debentures and fully, compulsorily and mandatorily convertible preference shares subject to
pricing guidelines/valuation norms prescribed under FEMA Regulations. The price/conversion
formula of convertible capital instruments should be determined upfront at the time of issue of
the instruments. The price at the time of conversion should not in any case be lower than the
fair value worked out, at the time of issuance of such instruments, in accordance with the
extant FEMA regulations [as per any internationally accepted pricing methodology on arm’s
length basis for the unlisted companies and valuation in terms of SEBI (ICDR) Regulations, for
the listed companies].

1.1 Optionality clauses are allowed in equity shares, fully, compulsorily and mandatorily
convertible debentures and fully, compulsorily and mandatorily convertible preference shares
under FDI scheme, subject to the following conditions:
(a) There is a minimum lock-in period of one year which shall be effective from the date of
allotment of such capital instruments.
(b) After the lock-in period and subject to FDI Policy provisions, if any, the non-resident
investor exercising option/right shall be eligible to exit without any assured return, as per
pricing/valuation guidelines issued by RBI from time to time.
2.

Other types of Preference shares/Debentures i.e. non-convertible, optionally convertible or
partially convertible for issue of which funds have been received on or after May 1, 2007 are
considered as debt. Accordingly all norms applicable for ECBs relating to eligible borrowers,
recognized lenders, amount and maturity, end-use stipulations, etc. shall apply. Since these
instruments would be denominated in rupees, the rupee interest rate will be based on the
swap equivalent of London Interbank Offered Rate (LIBOR) plus the spread as permissible for
ECBs of corresponding maturity.

3.

The inward remittance received by the Indian company vide issuance of DRs and FCCBs are
treated as FDI and counted towards FDI.

4.

Acquisition of Warrants and Partly Paid Shares - An Indian company may issue warrants
and partly paid shares to a person resident outside India subject to terms and conditions as
stipulated by the Reserve Bank of India in this behalf, from time to time.

5.

Issue of Foreign Currency Convertible Bonds (FCCBs) and Depository Receipts(DRs)
a)FCCBs/DRs may be issued in accordance with the Scheme for issue of Foreign Currency
Convertible Bonds and Ordinary Shares (Through Depository Receipt Mechanism)
Scheme, 1993 and DR Scheme 2014 respectively, as per the guidelines issued by the
Government of India there under from time to time.
b)DRs are foreign currency denominated instruments issued by a foreign Depository in a
permissible jurisdiction against a pool of permissible securities issued or transferred to
that foreign depository and deposited with a domestic custodian.

59

<!-- page 61 -->

c)In terms of Notification No. FEMA.20/2000-RB dated May 3, 2000 as amended from time to
time, a person will be eligible to issue or transfer eligible securities to a foreign depository,
for the purpose of converting the securities so purchased into depository receipts in terms
of Depository Receipts Scheme, 2014 and guidelines issued by the Government of India
thereunder from time to time.
d)A person can issue DRs, if it is eligible to issue eligible instruments to person resident
outside India under Schedules 1, 2, 2A, 3, 5 and 8 of Notification No. FEMA 20/2000-RB
dated May 3, 2000, as amended from time to time.
e)The aggregate of eligible securities which may be issued or transferred to foreign
depositories, along with eligible securities already held by persons resident outside India,
shall not exceed the limit on foreign holding of such eligible securities under the relevant
regulations framed under FEMA, 1999.
f) The pricing of eligible securities to be issued or transferred to a foreign depository for the
purpose of issuing depository receipts should not be at a price less than the price
applicable to a corresponding mode of issue or transfer of such securities to domestic
investors under the relevant regulations framed under FEMA, 1999.
g)The issue of depository receipts as per DR Scheme 2014 shall be reported to the Reserve
Bank by the domestic custodian as per the reporting guidelines for DR Scheme 2014.
6. (i) Two-way Fungibility Scheme: A limited two-way Fungibility scheme has been put in place
by the Government of India for ADRs/GDRs. Under this Scheme, a stock broker in India,
registered with SEBI, can purchase shares of an Indian company from the market for
conversion into ADRs/GDRs based on instructions received from overseas investors. Reissuance of ADRs/GDRs would be permitted to the extent of ADRs/GDRs which have been
redeemed into underlying shares and sold in the Indian market.
(ii) Sponsored ADR/GDR issue: An Indian company can also sponsor an issue of ADR/GDR.
Under this mechanism, the company offers its resident shareholders a choice to submit their
shares back to the company so that on the basis of such shares, ADRs/GDRs can be issued
abroad. The proceeds of the ADR/GDR issue are remitted back to India and distributed
among the resident investors who had offered their Rupee denominated shares for
conversion. These proceeds can be kept in Resident Foreign Currency (Domestic) accounts
in India by the resident shareholders who have tendered such shares for conversion into
ADRs/GDRs.

60

<!-- page 62 -->

Annexure-3
Provisions Relating to Issue/ Transfer of Shares
1.

The capital instruments should be issued within 180 days from the date of receipt of the
inward remittance received through normal banking channels including escrow account
opened and maintained for the purpose or by debit to the NRE/FCNR (B) account of the
non-resident investor. In case, the capital instruments are not issued within 180 days from
the date of receipt of the inward remittance or date of debit to the NRE/FCNR (B) account,
the amount of consideration so received should be refunded immediately to the nonresident investor by outward remittance through normal banking channels or by credit to
the NRE/FCNR (B) account, as the case may be. Non-compliance with the above
provision would be reckoned as a contravention under FEMA and would attract penal
provisions. In exceptional cases, refund of the amount of consideration outstanding
beyond a period of 180 days from the date of receipt may be considered by the RBI, on
the merits of the case.

2.

Issue price of shares
Price of shares issued to persons resident outside India under the FDI Policy, shall not be
less than –
a. the price worked out in accordance with the SEBI guidelines, as applicable, where the
shares of the company are listed on any recognised stock exchange in India;
b. the fair valuation of shares done by a SEBI registered Merchant Banker or a Chartered
Accountant as per any internationally accepted pricing methodology on arm’s length basis,
where the shares of the company are not listed on any recognised stock exchange in
India; and
c. the price as applicable to transfer of shares from resident to non-resident as per the
pricing guidelines laid down by the Reserve Bank from time to time, where the issue of
shares is on preferential allotment.
However, where non-residents (including NRIs) are making investments in an Indian
company in compliance with the provisions of the Companies Act, as applicable, by way of
subscription to its Memorandum of Association, such investments may be made at face
value subject to their eligibility to invest under the FDI scheme.

3.

Foreign Currency Account
Indian companies which are eligible to issue shares to persons resident outside India
under the FDI Policy may be allowed to retain the share subscription amount in a Foreign
Currency Account, with the prior approval of RBI.

4.
(i)

Transfer of shares and convertible debentures
Subject to FDI sectoral policy (relating to sectoral caps and entry routes), applicable laws
and other conditionalities including security conditions, non-resident investors can also
invest in Indian companies by purchasing/acquiring existing shares from Indian
shareholders or from other non-resident shareholders. General permission has been
granted to non-residents/NRIs for acquisition of shares by way of transfer subject to the
following:

61

<!-- page 63 -->

(ii)

(a)

A person resident outside India (other than NRI and erstwhile OCB) may transfer by
way of sale or gift, the shares or convertible debentures to any person resident
outside India (including NRIs). Government approval is not required for transfer of
shares in the investee company from one non-resident to another non-resident in
sectors which are under automatic route. In addition, approval of Government will be
required for transfer of stake from one non-resident to another non-resident in
sectors which are under Government approval route.

(b)

NRIs may transfer by way of sale or gift the shares or convertible debentures held
by them to another NRI.

(c)

A person resident outside India can transfer any security to a person resident in
India by way of gift.

(d)

A person resident outside India can sell the shares and convertible debentures of an
Indian company on a recognized Stock Exchange in India through a stock broker
registered with stock exchange or a merchant banker registered with SEBI.

(e)

A person resident in India can transfer by way of sale, shares/ convertible
debentures (including transfer of subscriber’s shares), of an Indian company under
private arrangement to a person resident outside India, subject to the guidelines
given in para 5.2 and Section 1 of this Annexure.

(f)

General permission is also available for transfer of shares/convertible debentures,
by way of sale under private arrangement by a person resident outside India to a
person resident in India, subject to the guidelines given in para 5.2 and Section 1 of
this Annexure.

(g)

The above General Permission also covers transfer by a resident to a non-resident
of shares/convertible debentures of an Indian company, engaged in an activity
earlier covered under the Government Route but now falling under Automatic Route,
as well as transfer of shares by a non-resident to an Indian company under buyback
and/or capital reduction scheme of the company.

(h)

The Form FC-TRS should be submitted to the AD Category-I Bank, within 60 days
from the date of receipt of the amount of consideration. The onus of submission of
the Form FC-TRS within the given timeframe would be on the transferor/transferee,
resident in India. However, in cases where the NR investor, including an NRI,
acquires shares on the stock exchanges under the FDI scheme, the investee
company would have to file form FC-TRS with the AD Category-I bank.
The sale consideration in respect of equity instruments purchased by a person resident
outside India, remitted into India through normal banking channels, shall be subjected
to a Know Your Customer (KYC) check by the remittance receiving AD Category-I bank
at the time of receipt of funds. In case, the remittance receiving AD Category-I bank is
different from the AD Category-I bank handling the transfer transaction, the KYC check
should be carried out by the remittance receiving bank and the KYC report be
submitted by the customer to the AD Category-I bank carrying out the transaction along
with the Form FC-TRS.

(iii) A person resident outside India including a Non-Resident Indian investor who has
already acquired and continues to hold the control in accordance with the SEBI

62

<!-- page 64 -->

(Substantial Acquisition of Shares and Takeover) Regulations can acquire shares of a
listed Indian company on the stock exchange through a registered broker under FDI
scheme provided that the original and resultant investments are in line with the extant
FDI policy and FEMA regulations in respect of sectoral cap, entry route,mode of
payment, reporting requirement, documentation, etc.
(iv)

Escrow: AD Category-I banks have been given general permission to open Escrow
account and Special account of non-resident corporate for open offers/exit offers and
delisting of shares. The relevant SEBI (Substantial Acquisition of Shares and
Takeovers) Regulations, 2011 (SAST) Regulations or any other applicable SEBI
Regulations/provisions of the Companies Act, as applicable will be applicable. AD
Category-I banks have also been permitted to open and maintain, without prior
approval of RBI, non-interest bearing Escrow accounts in Indian Rupees in India on
behalf of residents and/or non-residents, towards payment of share purchase
consideration and/or provide Escrow facilities for keeping securities to facilitate FDI
transactions subject to the63terms and conditions specified by RBI. SEBI authorised
Depository Participants have also been permitted to open and maintain, without prior
approval of RBI, Escrow accounts for securities subject to the terms and conditions as
specified by RBI. In both cases, the Escrow agent shall 63necessarily be an AD
Category-I bank or SEBI authorised Depository Participant (in case of securities’
accounts). These facilities will be applicable for both issue of fresh shares to the nonresidents as well as transfer of shares from/to the non- residents.

5. Prior permission of RBI in certain cases for transfer of capital instruments
5.1

Except cases mentioned in paragraph 5.2 below, the following cases require prior
approval of RBI:
(i)

Transfer of capital instruments from resident to non-residents by way of sale where:
(a) Transfer is at a price which falls outside the pricing guidelines specified by the
Reserve Bank from time to time and the transaction does not fall under the
exception given in para 5.2.
(b) Transfer of capital instruments by the non-resident acquirer involving deferment
of payment of the amount of consideration. Further, in case approval is granted
for a transaction, the same should be reported in Form FC-TRS, to an AD
Category-I bank for necessary due diligence, within 60 days from the date of
receipt of the full and final amount of consideration.

(ii) Transfer of any capital instrument, by way of gift by a person resident in India to a
person resident outside India. While forwarding applications to Reserve Bank for
approval for transfer of capital instruments by way of gift, the documents mentioned
in Section 2 of this Annexure should be enclosed. Reserve Bank considers the
following factors while processing such applications:
(a) The proposed transferee (donee) is eligible to hold such capital instruments under
Schedules 1, 4 and 5 of Notification No. FEMA 20/2000-RB dated May 3, 2000, as
amended from time to time.

63

<!-- page 65 -->

(b) The gift does not exceed 5 per cent of the paid-up capital of the Indian
company/each series of debentures/each mutual fund scheme.
(c) The applicable sectoral cap limit in the Indian company is not breached.
(d) The transferor (donor) and the proposed transferee (donee) are close relatives as
defined in Section 2 (77) of Companies Act, 2013, as amended from time to time.
The current list is reproduced in Section 3 of this Annexure.
(e) The value of capital instruments to be transferred together with any capital
instruments already transferred by the transferor, as gift, to any person residing
outside India does not exceed the rupee equivalent of USD 50,000 during the
financial year.
(f)

Such other conditions as stipulated by Reserve Bank in public interest from time to
time.

(iii) Transfer of shares from NRI to non-resident.
In the following cases, approval of RBI is not required:

5.2
A.

Transfer of shares from a Non-Resident to Resident under the FDI scheme
where the pricing guidelines under FEMA, 1999 are not met provided that:
i. The original and resultant investment are in line with the extant FDI policy and
FEMA regulations in terms of sectoral caps, conditionalities (such as minimum
capitalization, etc.), reporting requirements, documentation, etc.;
ii. The pricing for the transaction is compliant with the specific/explicit, extant and
relevant SEBI regulations/guidelines (such as IPO, Book building, block deals,
delisting, exit, open offer/substantial acquisition/SEBI SAST, buy back); and
iii. Chartered Accountants Certificate to the effect that compliance with the relevant
SEBI regulations/guidelines as indicated above is attached to the form FC-TRS to
be filed with the AD bank.

B.

Transfer of shares from Resident to Non-Resident:
i) where the transfer of shares requires the prior approval of the Government
conveyed through FIPB as per the extant FDI policy provided that:
a) the requisite approval of the FIPB has been obtained; and
b) the transfer of shares adheres with the pricing guidelines and documentation
requirements as specified by the Reserve Bank of India from time to time.
ii) where the transfer of shares attract SEBI (SAST) Regulations subject to the
adherence with the pricing guidelines and documentation requirements as specified
by Reserve Bank of India from time to time.
iii)where the transfer of shares does not meet the pricing guidelines under the
FEMA, 1999 provided that:

64

<!-- page 66 -->

a) The resultant FDI is in compliance with the extant FDI policy and FEMA regulations
in terms of sectoral caps, conditionalities (such as minimum capitalization, etc.),
reporting requirements, documentation etc.;
b) The pricing for the transaction is compliant with the specific/explicit, extant and
relevant SEBI regulations/guidelines (such as IPO, Book building, block deals,
delisting, exit, open offer/substantial acquisition/SEBI SAST); and
c) Chartered Accountants Certificate to the effect that compliance with the relevant
SEBI regulations/guidelines as indicated above is attached to the form FC-TRS to
be filed with the AD bank.
iv)where the investee company is in the financial sector provided that:
a) Any ‘fit and proper/due diligence’ requirements as regards the non-resident investor
as stipulated by the respective financial sector regulator, from time to time, have
been complied with; and
b) The FDI policy and FEMA regulations in terms of sectoral caps, conditionalities
(such as minimum capitalization, pricing, etc.), reporting requirements,
documentation etc., are complied with.
6.
(i)

Conversion of ECB/Lump sum Fee/Royalty etc. into Equity
Indian companies have been granted general permission for conversion of External
Commercial Borrowings (ECB) (excluding those deemed as ECB) in convertible foreign
currency into equity shares/fully compulsorily and mandatorily convertible preference
shares, subject to the following conditions and reporting requirements:
(a) The activity of the company is covered under the Automatic Route for FDI or
the company has obtained Government approval for foreign equity in the
company;
(b) The foreign equity after conversion of ECB into equity is within the sectoral cap,
if any;
(c) Pricing of shares is as per the provision of para 2 above;
(d) Compliance with the requirements prescribed under any other statute and
regulation in force; and
(e) The conversion facility is available for ECBs availed under the Automatic or
Government Route and is applicable to ECBs, due for payment or not, as well
as secured/unsecured loans availed from non-resident collaborators.

(ii)

General permission is also available for issue of shares/preference shares against
lump sum technical know-how fee, royalty due for payment, subject to entry route,
sectoral cap and pricing guidelines (as per the provision of para 2 above)and
compliance with applicable tax laws. Further, issue of equity shares against any other
funds payable by the investee company, remittance of which does not require prior
permission of the Government of India or Reserve Bank of India under FEMA, 1999 or
any rules/ regulations framed or directions issued thereunder is permitted, provided
that:
(I) The equity shares shall be issued in accordance with the extant FDI guidelines on
sectoral caps, pricing guidelines etc. as amended by Reserve bank of India, from
time to time;

65

<!-- page 67 -->

Explanation: Issue of shares/convertible debentures that require Government
approval in terms of paragraph 3 of Schedule 1 of FEMA 20 or import dues deemed
as ECB or trade credit or payable against import of second hand machinery shall
continue to be dealt in accordance with extant guidelines;
(II)The issue of equity shares under this provision shall be subject to tax laws as
applicable to the funds payable and the conversion to equity should be net of
applicable taxes.
(iii)

Issue of equity shares under the FDI policy is allowed under the Government route for
the following:
(I) import of capital goods/ machinery/ equipment (excluding second-hand
machinery), subject to compliance with the following conditions:
(a)Any import of capital goods/machinery etc., made by a resident in India, has to
be in accordance with the Export/Import Policy issued by Government of
India/as defined by DGFT/FEMA provisions relating to imports.
(b)The application clearly indicating the beneficial ownership and identity of the
Importer Company as well as overseas entity.
(c)Applications complete in all respects, for conversions of import payables for
capital goods into FDI being made within 180 days from the date of shipment
of goods.
(II)
pre-operative/pre-incorporation expenses (including payments of rent etc.),
subject to compliance with the following conditions:
(a)Submission of FIRC for remittance of funds by the overseas promoters for
the expenditure incurred.
(b)Verification and certification of the pre-incorporation/pre-operative expenses
by the statutory auditor.
(c) Payments should be made by the foreign investor to the company directly
or through the bank account opened by the foreign investor as provided
under FEMA Regulations.
(d)The applications, complete in all respects, for capitalization being made
within the period of 180 days from the date of incorporation of the
company.
General conditions:
(i) All requests for conversion should be accompanied by a special resolution of the
company.
(ii) Government’s approval would be subject to pricing guidelines of RBI and
appropriate tax clearance.
SECTION 1

Terms and conditions for Transfer of Shares/Convertible Debentures, by way of Sale, from
a Person Resident in India to a Person Resident Outside India and from a Person Resident
Outside India to a Person Resident in India
1.1In order to address the concerns relating to pricing, documentation, payment/ receipt and
remittance in respect of the shares/convertible debentures of an Indian company, in all sectors,
transferred by way of sale, the parties involved in the transaction shall comply with the guidelines
set out below.

66

<!-- page 68 -->

1.2Parties involved in the transaction are(a) seller (resident/non-resident), (b) buyer
(resident/non-resident), (c) duly authorized agent/s of the seller and/or buyer, (d) Authorised Dealer
bank (AD) branch and (e) Indian company, for recording the transfer of ownership in its books.
2. Pricing Guidelines
2.1 The under noted pricing guidelines are applicable to the following types of transactions:
i.
Transfer of shares by way of sale under private arrangement by a person resident in India to a
person resident outside India.
ii. Transfer of shares by way of sale under private arrangement by a person resident outside India
to a person resident in India.
iii. Exit by non-resident investor on exercising option/right in shares or compulsorily & mandatorily
convertible preference shares or fully, compulsorily & mandatorily convertible debentures.
2.2 Transfer by Resident to Non-resident (i.e. to foreign national, NRI, FII, FPI and incorporated
non-resident entity other than erstwhile OCB) Price of shares transferred by way of sale by resident
to a non-resident where the shares of an Indian company are:
(a) listed on a recognized stock exchange in India ,shall not be less than the price at which the
preferential allotment of shares can be made under the SEBI guidelines , as applicable,
provided the same is determined for such duration as specified therein, preceding the relevant
date, which shall be the date of purchase or sale of shares,
(b) not listed on a recognized stock exchange in India, shall not be less than the fair value to be
determined by a SEBI registered Merchant Banker or a Chartered Accountant as per any
internationally accepted pricing methodology on arm’s length basis. The price per share arrived
at should be certified by a SEBI registered Merchant Banker or a Chartered Accountant.
2.3 Transfer by Non-resident(i.e. by incorporated non-resident entity, erstwhile OCB, foreign
national, NRI, FII, FPI)to Resident
Sale of shares by a non-resident to resident shall be in accordance with Regulation 10 B (2) of
Notification No. FEMA 20/2000-RB dated May 3, 2000 which shall not be more than the minimum
price at which the transfer of shares can be made from a resident to a non-resident as given at para
2.2 above.
2.4 After the lock-in period, as applicable above, and subject to FDI Policy provisions, if any, in this
regard, the non-resident investor exercising option/right in shares or convertible debentures issued
under FDI Scheme shall be eligible to exit without any assured return, as per pricing/valuation
guidelines issued by RBI from time to time.
3. Responsibilities / Obligations of the parties
All the parties involved in the transaction would have the responsibility to ensure that the relevant
regulations under FEMA are complied with and consequent on transfer of shares, the relevant
individual limit/sectoral caps/foreign equity participation ceilings as fixed by Government are not
breached. Settlement of transactions will be subject to payment of applicable taxes, if any.
4. Method of payment and remittance/credit of sale proceeds
4.1The sale consideration in respect of the shares purchased by a person resident outside India
shall be remitted to India through normal banking channels. In case the buyer is a FII,FPI, payment
should be made by debit to its Special Non-Resident Rupee Account. In case the buyer is a NRI,
the payment may be made by way of debit to his NRE/FCNR (B) accounts. However, if the shares

67

<!-- page 69 -->

are acquired on non-repatriation basis by NRI, the consideration shall be remitted to India through
normal banking channel or paid out of funds held in NRE/FCNR (B)/NRO accounts.
4.2. The sale proceeds of shares (net of taxes) sold by a person resident outside India may be
remitted outside India. In case of FII/FPI, the sale proceeds may be credited to its special NonResident Rupee Account. In case of NRI, if the shares sold were held on repatriation basis, the sale
proceeds (net of taxes) may be credited to his NRE /FCNR(B) accounts and if the shares sold were
held on non repatriation basis, the sale proceeds may be credited to his NRO account subject to
payment of taxes.
4.3 The sale proceeds of shares (net of taxes) sold by an OCB may be remitted outside India
directly if the shares were held on repatriation basis and if the shares sold were held on nonrepatriation basis, the sale proceeds may be credited to its NRO (Current) Account subject to
payment of taxes, except in the case of OCBs whose accounts have been blocked by Reserve
Bank.
5. Documentation
Besides obtaining a declaration in the enclosed Form FC-TRS (in quadruplicate), the AD branch
should arrange to obtain and keep on record the following documents:
5.1 For sale of shares by a person resident in India
i.
Consent Letter duly signed by the seller and buyer or their duly appointed agent indicating
the details of transfer i.e. number of shares to be transferred, the name of the investee
company whose shares are being transferred and the price at which shares are being
transferred. In case there is no formal Sale Agreement, letters exchanged to this effect may
be kept on record.
ii.
Where Consent Letter has been signed by their duly appointed agent, the Power of
Attorney Document executed by the seller/buyer authorizing the agent to purchase/sell
shares.
iii.
The shareholding pattern of the investee company after the acquisition of shares by a
person resident outside India showing equity participation of residents and non-residents
category-wise (i.e. NRIs/OCBs/foreign nationals/incorporated non-resident entities/FIIs,
FPIs) and its percentage of paid up capital obtained by the seller/buyer or their duly
appointed agent from the company, where the sectoral cap/limits have been prescribed.
iv.
Certificate indicating fair value of shares from a Chartered Accountant.
v.
Copy of Broker’s note if sale is made on Stock Exchange
vi.
Undertaking from the buyer to the effect that he is eligible to acquire shares/convertible
debentures under FDI policy and the existing sectoral limits and Pricing Guidelines have
been complied with.
vii.
Undertaking from the FII/sub account to the effect that the individual FII/ Sub account
ceiling as prescribed by SEBI has not been breached, till it gets registered as FPI.
5.2.
i.

For sale of shares by a person resident outside India
Consent Letter duly signed by the seller and buyer or their duly appointed agent indicating
the details of transfer i.e. number of shares to be transferred, the name of the investee
company whose shares are being transferred and the price at which shares are being
transferred.

68

<!-- page 70 -->

ii.

iii.

iv.
v.
vi.

Where the Consent Letter has been signed by their duly appointed agent the Power of
Attorney Document authorizing the agent to purchase/sell shares by the seller/buyer. In
case there is no formal Sale Agreement, letters exchanged to this effect may be kept on
record.
If the sellers are NRIs/OCBs, the copies of RBI approvals evidencing the shares held by
them on repatriation/non-repatriation basis. The sale proceeds shall be credited NRE/NRO
account, as applicable.
Certificate indicating fair value of shares from a Chartered Accountant.
No Objection / Tax Clearance Certificate from Income Tax authority/Chartered Account.
Undertaking from the buyer to the effect that the Pricing Guidelines have been adhered to.

6. Reporting requirements
6.1 Reporting of transfer of shares between residents and non-residents and vice versa is to be
done in Form FC-TRS. The Form FC-TRS should be submitted to the AD Category-I bank, within 60
days from the date of receipt of the amount of consideration. The onus of submission of the Form
FC-TRS within the given timeframe would be on the transferor / transferee, resident in India. The
AD Category-I bank, would forward the same to its link office. The link office would consolidate the
Forms and submit a monthly report to the Reserve Bank5.
For the purpose the Authorized Dealers may designate branches to specifically handle such
transactions. These branches could be staffed with adequately trained staff for this purpose to
ensure that the transactions are put through smoothly. The ADs may also designate a nodal office
to coordinate the work at these branches and also ensure the reporting of these transactions to the
Reserve Bank.
6.2When the transfer is on private arrangement basis, on settlement of the transactions, the
transferee/his duly appointed agent should approach the investee company to record the transfer in
their books along with the certificate in the Form FC-TRS from the AD branch that the remittances
have been received by the transferor/payment has been made by the transferee. On receipt of the
certificate from the AD, the company may record the transfer in its books.
6.3The actual inflows and outflows on account of such transfer of shares shall be reported by the
AD branch in the R-returns in the normal course.
6.4 In addition the AD branch should submit two copies of the Form FC-TRS received from their
constituents/customers together with the statement of inflows/outflows on account of remittances
received/made in connection with transfer of shares, by way of sale, to IBD/FED/or the nodal office
designated for the purpose by the bank in the enclosed proforma (which is to be prepared in MSExcel format). The IBD/FED or the nodal office of the bank will in turn submit a consolidated
monthly statement in respect of all the transactions reported by their branches together with copies
of the FC-TRS Forms received from their branches to Foreign Exchange Department, Reserve
Bank, Foreign Investment Division, Central Office, Mumbai in soft copy (in MS- Excel) by e-mail to
fdidata@rbi.org.in

5

To the Chief General Manager-in-Charge, Reserve Bank of India, Foreign Exchange Department, Foreign
Investment Division, Central Office, Mumbai

69

<!-- page 71 -->

6.5 Shares purchased / sold by FIIs/FPIs under private arrangement will be by debit /credit to their
Special Non-Resident Rupee Account. Therefore, the transaction should also be reported in Form
LEC by the designated bank of the FII/FPI concerned.
6.6 Shares/convertible debentures of Indian companies purchased under Portfolio Investment
Scheme by NRIs, OCBs cannot be transferred, by way of sale under private arrangement.
6.7 On receipt of statements from the AD, the Reserve Bank may call for such additional details or
give such directions as required from the transferor/transferee or their agents, if need be.
SECTION 2
Documents to be submitted by a person resident in India for transfer of shares to a person
resident outside India by way of gift
i. Name and address of the transferor (donor) and the transferee (donee).
ii. Relationship between the transferor and the transferee.
iii. Reasons for making the gift.
iv. In case of Government dated securities and treasury bills and bonds, a certificate issued by a
Chartered Accountant on the market value of such security.
v. In case of units of domestic mutual funds and units of Money Market Mutual Funds, a
certificate from the issuer on the Net Asset Value of such security.
vi. In case of shares and convertible debentures, a certificate from a Chartered Accountant on
the value of such securities according to the guidelines issued by Securities & Exchange
Board of India or as per any internationally accepted pricing methodology on arm’s length
basis for listed companies and unlisted companies, respectively.
vii. Certificate from the concerned Indian company certifying that the proposed transfer of
shares/convertible debentures by way of gift from resident to the non-resident shall not
breach the applicable sectoral cap/ FDI limit in the company and that the proposed number of
shares/convertible debentures to be held by the non-resident transferee shall not exceed 5
per cent of the paid up capital of the company.
viii. An undertaking from the resident transferor that the value of security to be transferred
together with any security already transferred by the transferor, as gift, to any person residing
outside India does not exceed the rupee equivalent of USD 50,000during a financial year*.
*RBI’s A.P. (DIR Series) Circular No. 14 Dated 15.09.2011
ix. A declaration from the donee accepting partly paid shares or warrants that donee is aware of
the liability as regards calls in arrear and consequences thereof.
SECTION 3
Definition of "relative" as given in Section 2 (77) of Companies Act, 2013
“Relative”, with reference to any person, means any one who is related to another, if(a) they are members of a Hindu undivided family ;
(b) they are husband and wife ; or
(c) one person is related to the other in such manner as may be prescribed.

70

<!-- page 72 -->

Specific Conditions in Certain Cases

Annexure-4

1.

Issue of Rights/Bonus Shares
FEMA provisions allow Indian companies to freely issue Rights/Bonus shares to existing
non-resident shareholders, subject to adherence to sectoral cap, if any. However, such
issue of bonus/rights shares has to be in accordance with other laws/statutes like the
Companies Act, as applicable, SEBI (Issue of Capital and Disclosure Requirements)
Regulations, 2009 (in case of listed companies), etc. The offer on right basis to the
persons resident outside India shall be:
(a)
in the case of shares of a company listed on a recognized stock exchange in
India, at a price as determined by the company;
(b)
in the case of shares of a company not listed on a recognized stock exchange
in India, at a price which is not less than the price at which the offer on right
basis is made to resident shareholders.

2.

Prior permission of RBI for Rights issue to erstwhile OCBs
OCBs have been de-recognised as a class of investors from September 16, 2003.
Therefore companies desiring to issue rights share to such erstwhile OCBs will have to
take specific prior permission from RBI. As such, entitlement of rights share is not
automatically available to erstwhile OCBs. However bonus shares can be issued to
erstwhile OCBs without the approval of RBI.

3.

Additional allocation of rights share by residents to non-residents
Existing non-resident shareholders are allowed to apply for issue of additional shares/fully,
compulsorily and mandatorily convertible debentures/fully, compulsorily and mandatorily
convertible preference shares over and above their rights share entitlements. The
investee company can allot the additional rights share out of unsubscribed portion, subject
to the condition that the overall issue of shares to non-residents in the total paid-up capital
of the company does not exceed the sectoral cap.

4.

Acquisition of shares under Scheme of Merger/Demerger/Amalgamation
Mergers/demergers/ amalgamations of companies in India are usually governed by an
order issued by a competent Court on the basis of the Scheme submitted by the
companies undergoing merger/demerger/amalgamation. Once the scheme of merger or
demerger or amalgamation of two or more Indian companies has been approved by a
Court in India, the transferee company or new company is allowed to issue shares to the
shareholders of the transferor company resident outside India, subject to the conditions
that:
(i) the percentage of shareholding of persons resident outside India in the transferee or
new company does not exceed the sectoral cap, and
(ii) the transferor company or the transferee or the new company is not engaged in
activities which are prohibited under the FDI policy.
Note: FIPB approval would not be required in case of mergers and acquisitions taking
place in sectors under automatic route.

71

<!-- page 73 -->

4.1 Issue of Non convertible/redeemable bonus preference shares or debentures
Indian companies are allowed to issue non-convertible/redeemable preference shares or
debentures to non-resident shareholders, including the depositories that act as trustees
for the ADR/GDR holders, by way of distribution as bonus from its general reserves under
a Scheme of Arrangement approved by a Court in India under the provisions of the
Companies Act, as applicable, subject to no-objection from the Income Tax Authorities.
5.

Issue of Employees Stock Option Scheme (ESOPs) / Sweat Equity
An Indian company may issue “employees’ stock option” and/or “sweat equity shares” to
its employees/directors or employees/directors of its holding company or joint venture or
wholly owned overseas subsidiary/subsidiaries who are resident outside India, provided
that :
a.

b.

c.

d.

e.

The scheme has been drawn either in terms of regulations issued under the
Securities Exchange Board of India Act, 1992 or the Companies (Share Capital
and Debentures) Rules, 2014 notified by the Central Government under the
Companies Act 2013, as the case may be.
The “employee’s stock option”/ “sweat equity shares” issued to non-resident
employees/directors under the applicable rules/regulations are in compliance with
the sectoral cap applicable to the said company.
Issue of “employee’s stock option”/ “sweat equity shares” by a company where
foreign investment is under the approval route shall require prior approval of the
Foreign Investment Promotion Board (FIPB) of Government of India.
Issue of “employee’s stock option”/ “sweat equity shares” under the applicable
rules/regulations to an employee/director who is a citizen of Bangladesh/Pakistan
shall require prior approval of the Foreign Investment Promotion Board (FIPB) of
Government of India.
The issuing company shall furnish to the Regional Office concerned of the
Reserve Bank of India under whose jurisdiction the registered office of the
company operates, within 30 days from the date of issue of employees’ stock
option or sweat equity shares, a return as per the Form-ESOP.

6. Share Swap
In cases of investment by way of swap of shares, irrespective of the amount, valuation
of the shares will have to be made by a Merchant Banker registered with SEBI or an
Investment Banker outside India registered with the appropriate regulatory authority in
the host country. Approval of the Government will also be a prerequisite for investment
by swap of shares for sector under Government approval route. No approval of the
Government is required for investment in automatic route sectors by way of swap of
shares.
7. Pledge of Shares
(A)
A person being a promoter of a company registered in India (borrowing company),
which has raised external commercial borrowings, may pledge the shares of the
borrowing company or that of its associate resident companies for the purpose of
securing the ECB raised by the borrowing company, provided that a no objection for
the same is obtained from a bank which is an authorised dealer. The authorized dealer,

72

<!-- page 74 -->

shall issue the no objection for such a pledge after having satisfied itself that the
external commercial borrowing is in line with the extant FEMA regulations for ECBs and
that:
i)
ii)
iii)

(B)

(C)

the loan agreement has been signed by both the lender and the borrower,
there exists a security clause in the Loan Agreement requiring the borrower to
create charge on financial securities, and
the borrower has obtained Loan Registration Number (LRN) from the Reserve
Bank:

and the said pledge would be subject to the following conditions:
a) the period of such pledge shall be co-terminus with the maturity of the
underlying ECB;
b) in case of invocation of pledge, transfer shall be in accordance with the
extant FDI Policy and directions issued by the Reserve Bank;
c) the Statutory Auditor has certified that the borrowing company will
utilized/has utilized the proceeds of the ECB for the permitted end use/s
only.
Non-residents holding shares of an Indian company, can pledge these shares in favour
of the AD bank in India to secure credit facilities being extended to the resident
investee company for bonafide business purpose, subject to the following conditions:
(i) in case of invocation of pledge, transfer of shares should be in accordance with the
FDI policy in vogue at the time of creation of pledge;
(ii) submission of a declaration/ annual certificate from the statutory auditor of the
investee company that the loan proceeds will be / have been utilized for the
declared purpose;
(iii) the Indian company has to follow the relevant SEBI disclosure norms; and
(iv) pledge of shares in favour of the lender (bank) would be subject to Section 19 of
the Banking Regulation Act, 1949.
Non-residents holding shares of an Indian company, can pledge these shares in favour
of an overseas bank to secure the credit facilities being extended to the non-resident
investor/non-resident promoter of the Indian company or its overseas group company,
subject to the following:
(i) loan is availed of only from an overseas bank;
(ii) loan is utilized for genuine business purposes overseas and not for any
investments either directly or indirectly in India;
(iii) overseas investment should not result in any capital inflow into India;
(iv) in case of invocation of pledge, transfer should be in accordance with the FDI
policy in vogue at the time of creation of pledge; and
(v) submission of a declaration/annual certificate from a Chartered Accountant/
Certified Public Accountant of the non-resident borrower that the loan proceeds
will be / have been utilized for the declared purpose.

73

<!-- page 75 -->

Annexure-5
Total Foreign Investment i.e. Direct and Indirect Foreign Investment in eligible Indian
entities
1.

1.1

1.2

Investment in an eligible Indian entity can be made both by non-resident as well as
resident Indian entities. Any non-resident investment in an Indian company is direct
foreign investment. Investment by resident Indian entities could again comprise of both
resident and non-resident investment. Thus, such an Indian company would have
indirect foreign investment if the Indian investing company has foreign investment in it.
The indirect investment can also be a cascading investment i.e. through multi-layered
structure.
For the purpose of computation of indirect foreign investment in an Indian company,
foreign investment in an Indian company shall include all types of foreign investments
i.e. FDI; investment by FIIs (holding as on March 31), FPIs (holding as on March 31);
NRIs; ADRs; GDRs; Foreign Currency Convertible Debentures (FCCBs); Investment
Vehicles fully, compulsorily and mandatorily convertible preference shares and fully,
compulsorily and mandatorily convertible Debentures or units of an Investment Vehicle,
regardless of whether the said investments have been made under Schedule 1, 2, 2A,
3, 6, 9, 10 and 11 of FEMA (Transfer or Issue of Security by Persons Resident Outside
India) Regulations, 2000.
Guidelines for calculation of total foreign investment i.e. direct and indirect
foreign investment
(i) Counting of direct foreign investment
All investment directly by a non-resident entity into the Indian company/ LLP would
be counted towards foreign investment.
(ii) Counting of indirect foreign investment
(a) The foreign investment through the investing Indian company/LLP would not
be considered for calculation of the indirect foreign investment in case of
Indian companies/LLPs which are ‘owned and controlled’ by resident Indian
citizens and/or Indian Companies/LLPs which are owned and controlled by
resident Indian citizens .
(aa) Downstream investment by an Investment Vehicle shall be regarded as foreign
investment if either the Sponsor or the Manager or the Investment Manager is
not Indian ‘owned and controlled’ as defined in Regulation 14 of the principal
Regulations as defined in RBI Notification No.362/2015-RB dated February 15,
2016.
Provided that for sponsors or managers or investment managers organized in
a form other than companies or LLPs, SEBI shall determine whether the
sponsor or manager or investment manager is foreign owned and controlled.
(b) For cases where condition (a) above is not satisfied or if the investing
company is owned or controlled by ‘non-resident entities’, the entire
investment by the investing company/LLP into the subject Indian Company
would be considered as indirect foreign investment, provided that, as an
exception, the indirect foreign investment in only the 100% owned subsidiaries

74

<!-- page 76 -->

of operating-cum-investing/investing companies, will be limited to the foreign
investment in the operating-cum-investing/ investing company. This exception
is made since the downstream investment of a 100% owned subsidiary of the
holding company is akin to investment made by the holding company and the
downstream investment should be a mirror image of the holding company.
This exception, however, is strictly for those cases where the entire capital of
the downstream subsidiary is owned by the holding company.

Illustration
To illustrate, if the indirect foreign investment is being calculated for Company X which has
investment through an investing Company Y having foreign investment, the following would be
the method of calculation:
(A)
where Company Y has foreign investment less than 50%- Company X would not be
taken as having any indirect foreign investment through Company Y.
(B)
where Company Y has foreign investment of say 75% and:
(I) invests 26% in Company X, the entire 26% investment by Company Y would be
treated as indirect foreign investment in Company X;
(II) invests 80% in Company X, the indirect foreign investment in Company X would
be taken as 80%;
(III) where Company X is a wholly owned subsidiary of Company Y (i.e. Company Y
owns 100% shares of Company X), then only 75% would be treated as indirect
foreign equity and the balance 25% would be treated as resident held equity. The
indirect foreign equity in Company X would be computed in the ratio of 75:25 in
the total investment of Company Y in Company X.
(iii) The total foreign investment would be the sum total of direct and indirect foreign
investment.
(iv) The above methodology of calculation would apply at every stage of investment in
Indian companies and thus to each and every Indian company.
(v) Additional conditions
(a) The full details about the foreign investment including ownership details etc. in
Indian company(s) and information about the control of the company(s) would
be furnished by the Company(s) to the Government of India at the time of
seeking approval.
(b) In any sector/activity, where Government approval is required for foreign
investment and in cases where there are any inter-se agreements
between/amongst shareholders which have an effect on the appointment of the
Board of Directors or on the exercise of voting rights or of creating voting rights
disproportionate to shareholding or any incidental matter thereof, such
agreements will have to be informed to the approving authority. The approving
authority will consider such inter-se agreements for determining ownership and
control when considering the case for approval of foreign investment.
(c) In all sectors attracting sectoral caps, the balance equity i.e. beyond the
sectoral foreign investment cap, would specifically be beneficially owned
by/held with/in the hands of resident Indian citizens and Indian companies,
owned and controlled by resident Indian citizens.

75

<!-- page 77 -->

(d) In the I& B sector where the sectoral cap is up to 49%, the company would
need to be ‘owned and controlled’ by resident Indian citizens and Indian
companies, which are owned and controlled by resident Indian citizens.
(A)For this purpose, the equity held by the largest Indian shareholder would have to
be at least 51% of the total equity, excluding the equity held by Public Sector
Banks and Public Financial Institutions, as defined in Section 4A of the
Companies Act, 1956 or Section 2 (72) of the Companies Act, 2013, as the
case may be. The term ‘largest Indian shareholder’, used in this clause, will
include any or a combination of the following:
(I) In the case of an individual shareholder,
(aa)The individual shareholder,
(bb) A relative of the shareholder within the meaning of Section 2 (77) of
Companies Act, 2013.
(cc) A company/group of companies in which the individual
shareholder/HUF to which he belongs has management and controlling
interest.
(II)In the case of an Indian company,
(aa)The Indian company
(bb)A group of Indian companies under the same management and
ownership control.
(B)For the purpose of this Clause, “Indian company” shall be a company which must
have a resident Indian or a relative as defined under Section 2 (77) of Companies
Act, 2013/ HUF, either singly or in combination holding at least 51% of the
shares.
(C)Provided that, in case of a combination of all or any of the entities mentioned in
Sub-Clauses (I) and (II) of clause 1.2(v)(d)(A) above, each of the parties shall
have entered into a legally binding agreement to act as a single unit in managing
the matters of the applicant company.
(e) If a declaration is made by persons as per section 187C of the Companies
Act,1956 or section 89 of the Companies Act, 2013, as the case may be about
a beneficial interest being held by a non-resident entity, then even though the
investment may be made by a resident Indian citizen, the same shall be
counted as foreign investment.
1.3

The above mentioned policy and methodology would be applicable for determining the
total foreign investment in all sectors, except in sectors where it is specified in a statute
or rule there under. The above methodology of determining direct and indirect foreign
investment therefore does not apply to the Insurance Sector which will continue to be
governed by the relevant Regulation. Similarly, above methodology will also not apply
to downstream investments by an Investment Vehicle. Relevant conditions of
downstream investment by Investment Vehicles are as under:
(i) Downstream investment by an Investment Vehicle shall be regarded as foreign
investment if either the Sponsor or the Manager or the Investment Manager is not Indian
‘owned and controlled’ as defined in Regulation 14 of the principal Regulations as
defined in RBI Notification No. 362/2015-RB dated February 15, 2016.

76

<!-- page 78 -->

Provided that for sponsors or managers or investment managers organized in a form
other than companies or LLPs, SEBI shall determine whether the sponsor or manager
or investment manager is foreign owned and controlled.
Explanation 1: Ownership and control is clearly determined as per the extant FDI policy.
AIF is a pooled investment vehicle. ‘Control’ of the AIF should be in the hands of
‘sponsors’ and ‘mangers/investment managers’, with the general exclusion of others. In
case the ‘sponsors’ and ‘managers/investment managers’ of the AIF are individuals, for
the treatment of downstream investment by such AIF as domestic, ‘sponsors’ and
‘managers/investment managers’ should be resident Indian citizens.
Explanation 2: The extent of foreign investment in the corpus of the Investment Vehicle
will not be a factor to determine as to whether downstream investment of the Investment
Vehicle concerned is foreign investment or not.
(ii) Downstream investment by an Investment Vehicle that is reckoned as foreign
investment shall have to conform to the sectoral caps and conditions / restrictions, if
any, as applicable to the company in which the downstream investment is made as per
the FDI Policy.
(iii) Downstream investment in an LLP by an Investment Vehicle that is reckoned as
foreign investment has to conform to the provisions of Schedule 9 of the principal FEMA
Regulations as well as the extant FDI policy for foreign investment in LLPs.
(iv) An Alternative Investment Fund Category III with foreign investment shall make
portfolio investment in only those securities or instruments in which a Registered
Foreign Portfolio Investor is allowed to invest under the principal Regulations.
(v) The Investment Vehicle receiving foreign investment shall be required to make such
report and in such format to Reserve Bank of India or to SEBI as may be prescribed by
them from time to time.
1.4

Any foreign investment already made in accordance with the guidelines in existence
prior to February 13, 2009 (date of issue of Press Note 2 of 2009) would not require
any modification to conform to these guidelines. All other investments, past and future,
would come under the ambit of these new guidelines.

77

<!-- page 79 -->

Remittance, Reporting and Violation
1.
1.1

Annexure-6

Remittance and Repatriation
Remittance of sale proceeds/Remittance on winding up/Liquidation of
Companies:
(i)
Sale proceeds of shares and securities and their remittance is ‘remittance of
asset’ governed by The Foreign Exchange Management (Remittance of
Assets) Regulations, 2000 under FEMA.
(ii)
AD Category-I bank can allow the remittance of sale proceeds of a security (net
of applicable taxes) to the seller of shares resident outside India, provided the
security has been held on repatriation basis, the sale of security has been
made in accordance with the prescribed guidelines and NOC/tax clearance
certificate from the Income Tax Department has been produced.
(iii)

Remittance on winding up/liquidation of Companies
AD Category-I banks have been allowed to remit winding up proceeds of
companies in India, which are under liquidation, subject to payment of
applicable taxes. Liquidation may be subject to any order issued by the
court winding up the company or the official liquidator in case of voluntary
winding up under the provisions of the Companies Act, , as applicable. AD
Category-I banks shall allow the remittance provided the applicant submits:
a. No objection or Tax clearance certificate from Income Tax Department
for the remittance.
b. Auditor's certificate confirming that all liabilities in India have been
either fully paid or adequately provided for.
c. Auditor'scertificatetotheeffectthatthewindingupisinaccordancewiththe
provisions of the Companies Act, as applicable.
d. In case of winding up otherwise than by a court, an auditor's certificate
to the effect that there are no legal proceeding spending in any court in
India against the applicant or the company under liquidation and there
is no legal impediment in permitting the remittance.

1.2

Repatriation of Dividend
Dividends are freely repatriable without any restrictions (net after Tax deduction at
source or Dividend Distribution Tax, if any, as the case may be). The repatriation is
governed by the provisions of the Foreign Exchange Management (Current Account
Transactions) Rules, 2000, as amended from time to time.

1.3

Repatriation of Interest
Interest on fully, mandatorily & compulsorily convertible debentures is also freely
repatriable without any restrictions (net of applicable taxes). The repatriation is
governed by the provisions of the Foreign Exchange Management (Current Account
Transactions) Rules, 2000, as amended from time to time.

78

<!-- page 80 -->

2.
Reporting of FDI
2.1 Reporting of Inflow
(i) An Indian company receiving investment from outside India for issuing
shares/convertible debentures/preference shares under the FDI Scheme, should
report the details of the amount of consideration to the Regional Office concerned
of the Reserve Bank not later than 30 days from the date of receipt in the Advance
Reporting Form as in Section 1 of this Annexure.
(ii) Indian companies are required to report the details of the receipt of the amount of
consideration for issue of shares/convertible debentures, through an AD CategoryI bank, together with a copy/ies of the FIRC/s evidencing the receipt of the
remittance along with the KYC report (Section-2) on the non-resident investor
from the overseas bank remitting the amount. The report would be acknowledged
by the Regional Office concerned, which will allot a Unique Identification Number
(UIN) for the amount reported.
Explanation: An Indian company issuing partly paid equity shares, shall furnish a
report not later than 30 days from the date of receipt of each call payment.
2.2

Reporting of issue of shares
(i) After issue of shares (including bonus and shares issued on rights basis and
shares issued under ESOP)/fully, mandatorily & compulsorily convertible
debentures/fully, mandatorily & compulsorily convertible preference shares, the
Indian company has to file Form FC-GPR, not later than 30 days from the date of
issue of shares.
(ii) Form FC-GPR has to be duly filled up and signed by Managing
Director/Director/Secretary of the Company and submitted to the Authorized
Dealer of the company, who will forward it to the Reserve Bank. The following
documents have to be submitted along with the form:
(a) A certificate from the Company Secretary of the company certifying that:
(A) all the requirements of the Companies Act, as applicable, have been
complied with;
(B) terms and conditions of the Government of India approval, if any,
have been complied with;
(C) the company is eligible to issue shares under these Regulations; and
(D) the company has all original certificates issued by authorized dealers
in India evidencing receipt of amount of consideration.
Note: For companies with paid up capital with less than Rs.5 crore, the above mentioned
certificate can be given by a practicing company secretary.
(b) A certificate from SEBI registered Merchant Banker or Chartered
Accountant indicating the manner of arriving at the price of the shares
isIndiad to the persons resident outside India.
(c) The report of receipt of consideration as well as Form FC-GPR have to be
submitted by the AD Category-I bank to the Regional Office concerned of
the Reserve Bank under whose jurisdiction the registered office of the
company is situated.
Note: An Indian company issuing partly paid equity shares shall file a report in
form FC-GPR to the extent they become paid up.

79
