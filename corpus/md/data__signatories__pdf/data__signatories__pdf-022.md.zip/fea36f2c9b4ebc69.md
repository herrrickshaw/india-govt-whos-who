---
doc_id: "fea36f2c9b4ebc69"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/181a862dfcec83f24f70a91ee204f404.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Appointment of Shri Pankaj Garg, ITS, Staff No. 20657 as Director General in National Mineral Exploration Trust under the Ministry of Mines on deputation basis - reg."
date: "2025-07-17"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "223ba8149bdd3c46"
---

<!-- page 1 -->

391-51/2024-STG-III

I/3297240/2025

No. 391-51/2024-STG-III
Government of India
Ministry of Communications
Department of Telecommunications
Room No. 419, Sanchar Bhawan
20 Ashoka Road, New Delhi 110001
Dated: 17.07.2025
Office Memorandum
Subject: Appointment of Shri Pankaj Garg, ITS (Staﬀ No. 20657) as Director
General in National Mineral Exploration Trust (NMET) under the Ministry of
Mines on deputation basis - reg.
The undersigned is directed to refer to DoPT order No. 17/2/2025-EO (SMII) dated 11.07.2025 & NMET Memorandum No. 59/03/2021-NMET dated
15.07.2025 on the subject mentioned above and to say that Shri Pankaj Garg, ITS
(Staﬀ No. 20657) DDG (Rural) DDG (Rural) in o/o DGT, New Delhi, has been
selected as Director General in National Mineral Exploration Trust (NMET) under
the Ministry of Mines, in pay level-14 of the pay matrix on deputation basis, initially
for a period of ﬁve years from the date of assumption of charge for the post or until
further orders whichever is earlier.
2.
The terms and conditions as laid down in the DoP&T OM No. 2/6/2016Estt. (Pay-II) dated 17.02.2016 and OM No. 14017/30/2006-Estt. (RR) dated
29.11.2006 as amended from time to time are applicable in the case of deputation
of aforesaid oﬃcer to the post of Director General in National Mineral Exploration
Trust (NMET) under the Ministry of Mines. Anything not covered in these OMs will
be decided as per the policy of borrowing organization.
3.
Therefore, aforesaid oﬃcer may be relieved immediately with instructions to
take up his new assignment in National Mineral Exploration Trust (NMET) under
the Ministry of Mines.
4.

This issues with the approval of the Competent Authority.

(Bijender Singh)
Under Secretary to the Govt. of India
Tele No. 23036226
To,
The DGT,
New Delhi.
Copy to:
1. PS to Hon’ble MoC/ PS to Hon’ble MoS(C).
2. PS to Secretary (T)/Member(S).
3. Shri Ramesh Chand Jha, Under Secretary, Secretariat of the ACC, DoPT,
North Block, New Delhi-11001
4. Smt. Geetika Sharma, Deputy Secretary & HoD, NMET, Ministry of Mines,
Room No. 326, F-Wing, Udyog Bhawan, New Delhi-110011.
5. Officer concerned.
6. AO, STG-I/ADG(APAR)/SO (Pay Bill).
7. Order Bundle/ Spare Copy.

<!-- page 2 -->

391-51/2024-STG-III

I/3297240/2025
