---
doc_id: "ff8bb4fb336cbfa9"
source_url: "https://powermin.gov.in/static/uploads/2025/08/f6279a10c00d18715b55f719d463572a.pdf"
ministry: "Power"
title: "Appointment of Consultant"
date: "2014-07-16"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d36d8114c5dd3f8d"
---

<!-- page 1 -->

exw
/
. No. 11/48/2012-PG
Government of India
Ministry of Power
रू मई मे मर मर के,
Shram Shakti Bhawan, Rafi Marg
New Delhi, dated 16th July' 2014
ORDER
Subject: Appointment of Consultant to conduct the study/analysis to ensure secure and
reliable operation of the National Grid and constitution of a Grid Study Committee to
facilitate Consultant in his task based on the follow up action on decisions taken on
the recommendations contained in the report submitted by Task Force on Power
System Analysis under contingencies-regarding
In pursuance of the decisions taken in the meeting by Secretary (P) to consider
recommendations contained in the report submitted by Task Force on Power System Analysis
under contingencies, it has been decided by the Competent Authority that Power Grid

Corporation of India Limited (PGCIL) would appoint a Consultant to conduct the study/analysis

to ensure secure and reliable operation of the National Grid with the following Terms of

Reference (TOR):-

Tasks to be taken up in the timeframe of 3 months

(i) Analysis of Third Party Protection Audit carried out earlier of PGCIL and individual States
system, identify gaps and suggest methodology to address them.

(ii) Calculation of Transfer Capability Fees for entire country State-wise, including
neighbouring countries where the power transfer is taking place- Existing, required up
to 2016-17 and suggestions for addressing the gap: The methodology for optimum
calculation of TTC/ ATC may be given. .

A preliminary report in this regard would be submitted to the Ministry of Power in 6 weeks.

Tasks to be taken up in the timeframe of 6 months

(i) Review the status of implementation of the recommendations of the Enquiry
Committee.

(ii) Carrying out actual Protection Audit to address the gaps, in consultation and
collaboration with states and all stakeholders as per present and future requirements
up to 2016-17.

|

<!-- page 2 -->

(iii) | Guidelines for computer aided studies related to relay settings and recommendations
thereof.
(iv) Guidelines for developing and implementing Islanding schemes
(v) Suitable suggestions in the Regulatory framework to ensure Secure and efficient grid
operation.
2. Further, a Grid Study Committee comprising the following as members would also be
constituted to facilitate the Consultant's study/analysis :-
(i) Member (GO&D), CEA - Chairman
(ii) Chief Engineer (GM), CEA - Member
(iii) | COO, CTU - Member
(५) STUs (One from each region) - Member
(v) Executive Director, POSOCO Ls Member
(vi) Other Members, as required
|
3. All administrative and logistic expenses on account of Grid Study Committee will be
borne by the Central Transmission Utility, i.e. Power Grid Corporation of India Limited.
Yours faithfully
ai
Under Secretary tothe Govt. of India
Telefax:011-23730264
To
1. CMD, PGCIL +
2. Chairman & all Members of the Grid Study Committee
3. Chairperson, CEA |
4. Member (GO&D), CEA |
5. CEO, POSOCO
(6४८ for updating the website
Copy for information: |
1. PPS to Secretary (P)/Sr.PPS to AS(DC)/ PPS to JS (Trans)/PPS to Director(PG), MoP,
Shram Shakti Bhawan, New Delhi.
