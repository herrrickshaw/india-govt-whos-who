---
doc_id: "fef66d6be7c1ba2a"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6acf009b70fda3.89662908.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Vacancy Circular - First Vacancy Circular for inviting nominations of Indian Forest Service officers for the appointment to the posts at various levels on tenure deputation basis under the Central Staffing Scheme of the Ministry of Environment, Forest and Climate Change (Vacancy Year: 2027), circula"
date: ""
pages: 11
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c67cc839132a1272"
---

<!-- page 1 -->

No: 12026/02/2026-IFS-I [E- 311076]
Government of India
Ministry of Environment, Forest and Climate Change
(IFS-I Section)
RARE

6" Floor, Prithvi Wing,

Indira Paryavaran Bhawan,

Jor Bagh Road, New Delhi -110 003.
Dated: 13" October, 2026

To

The Chief Secretaries/ Administrators,

All State Governments/ Union Territories
Subject : First Vacancy Circular for inviting nominations of Indian Forest Service officers for
the appointment to the posts at various levels on tenure deputation basis under the Central
Staffing Scheme of the Ministry of Environment, Forest and Climate Change (Vacancy Year:
2027) — regarding..

Sir/ Madam,

The Ministry of Environment, Forest and Climate Change (hereinafter referred to as
‘Ministry’) invites nominations of eligible and willing Indian Forest Service officers for appointment
in the posts in various Ministries and Organisation etc. in Goverment of India at the level of ADGF/
DDGF /IGF /DIGE/ AIGF, to prepare “OFFER LIST” for the vacancy year 2027, under the Central
Staffing Scheme of the Ministry Environment, Forest and Climate Change (hereinafter referred to as
‘Scheme’) dated 06.05.2011, which is available on website https://Awww.ifs.nic.in
(or) https://moef.gov.in/ifs.

2. As far as the eligibility of batches vis-a-vis the minimum years of service is concerned, it has
been decided to invite the applications from willing IFS officers who are eligible as per the conditions
laid down in Scheme of the Ministry.
3. The minimum years of service, for the respective posts will be with reference
to 01.01.2027 and the minimum year of service left before superannuation (wherever applicable) will
be counted from 01.01.2027.
4. It may kindly be ensured that the names of only those officers are sponsored who have
completed their “cooling off” period. An officer, who has previously been on deputation, will be
considered again for deputation only if the officer has completed the mandatory “cooling off” period
as per extant guidelines.
5. The officers may indicate their preferences for three station in their order of priority (in column
3 of Annexure-I) of the application where they would like to be posted. However, actual appointments
will be subject to availability and suitability of the officers for the post at any particular station.
6. In addition to above, as per provisions of Scheme, in exceptional cases, where sufficient
number of IFS officers are not available for the appointment to specific posts, the officers borne on
the State Forest Service (SFS) whose names are included in the ‘Select List’ referred to in Regulation
7(3) of the IFS (Appointment by Promotion) Regulations, 1966, shall also be considered for selection
for appointment. In case of posts in the North Eastern Region, the SFS officers who are yet to be
included in the ‘Select List’ referred to above, shall also be considered.
r
yea
wd

<!-- page 2 -->

hs If the officer selected for appointment fails to take up the central deputation assignment after
the appointment is approved, he/ she will attract debarment of five years from central deputation in
accordance with the provisions laid down in the Scheme.
8. Last date of receipt of complete application: The application, complete in all respects as per
Annexure-I (Part ik II and Ill available on the
website https://www.ifs.nic.in (or) https://moef.gov.in/ifs for different level posts), vigilance
clearance, duly attested APARs (in accordance with the Scheme) and concurrence of the State
Government/ Concerned Administrative Ministries where the officer is already on deputation, should
be sent on email id: ifs@nic.in latest by 01.12.2026. It may also be ensured that the correct and
updated Executive Record Sheet (blank copy enclosed) of the applicant is also attached along
with the application.
9. Application received without the consent of the concerned State/ UT Government and/ or after
the last date of receipt of applications will not be entertained.
10. The table showing the number of existing/ expected vacancies at different level and stations
is placed at Annexure-II. However, number of vacancies and stations are tentative and may change
at any time without any prior intimation. The selection will be based on actual vacancy positions
available as per the administrative and technical requirement.
1. A checklist of documents to be submitted including the application in due format, has been
given at Annexure — III.
12. The applications for the vacant posts of NTCA at Delhi, Nagpur, Bangalore, Guwahati need
additional requirements which are given at Annexure-IV.
13. In most of the State/ Joint cadres, the Central Deputation Reserve (CDR) is highly under
utilized. Therefore, the State Governments are requested to nominate sufficient number of IFS
officers to apply against this vacancy circular. "
७००४४
(Phalguni Banerjee)
Under Secretary to the Govt. of India
Tele. No.: O11 - 2081 9192
Copy to:
1. All Principal Chief Conservators of Forests (HoFF) of State/UT Administrations.
2.The Director General, Indian Council of Forestry Research and Education,
P.O. New Forest, Dehradun-248 006.
3. Director, IIFM, Nehru Nagar, Bhopal-462 003.
4. The Director General, Forests Survey of India, Kaulagarh Road, Dehradun.
5. The Director, Indira Gandhi National Forest Academy, P.O. New Forest, Dehradun.
6. All IFS officers in the Ministry of Environment, Forest and Climate Change (including
National Afforestation Eco-Development Board)/ Ministry of Agriculture/ Ministry of
Rural Development.
7. All Ministries of Government of India
8. NIC for placing the circular on the IFS website/Spare copies. Date
iero4qiaje™
(Phalguni Banerjee)
Under Secretary to the Govt. of India
Tele. No.: O11 - 2081 9192

<!-- page 3 -->

ANNEXURE-I
APPLICATION FORM FOR CENTRAL DEPUTATION POSTINGS UNDER THE CENTRAL
STAFFING SCHEME OF THE MINISTRY OF ENVIRONMENT, FORESTS AND CLIMATE
CHANGE FOR INDIAN FOREST SERVICE OFFICERS (FOR THE POSTS AT THE LEVEL OF
ADGF/DDGF/IGF/DIGF/AIGF)
Part-I (to be filled in by the applicant)
he year for which application is made | |
he level at which deputation is sought |______ |
3. |Choice of Station (in order of Preference) (0)
(ii)
iii)
ame of the applicant | |
Batch/year of allotment | [|
[cadre _ _/। +__॒&#$ऋआख खझ्/्३1ररझझऊईझ- ऊझऋ
Date of Birth PT
Present pay scale with date of
commencement of scale of pay
(0. [Present post held Po ृ क्‍फझऑझट
Full Address for correspondence:
(phone/fax/mobile/e-mail)
11. Educational qualifications
Degree/Diploma]University/Institute Subject(s)
[fT
a ३ [ / /७&/[ऊ-.( ऊऑऋ##ऋ#ऋऊइउ्ऑ्सॉ़ऊ्ऑ|
LT
12. Details of postings for the last 10 years: (in descending order)
IS |Years Post held |Name of the Main Special
0.|(from— to) rganization |responsibilities in| attributes/
Ithe post achievements
(in about
100words)
[of
PT
DT
13. Details of all deputation postings (in descending order):
IS |Years Post held Organisation Main areas of
}0.|(from— responsibilities in the
0) lpost
Co ३ ३ ् आ३७8०७क्डठउ़् ्/ू रू ््ऊझ_ऊ_
Cp # |
LT

<!-- page 4 -->

14. Details of experience in wildlife conservation, tiger reserves or the National Tiger
Conservation Authority, if any (Additional requirements for NTCA posts may be seen at Annexure
IV):
15. Date of return to Cadre from last deputation/ if currently on deputation, date of expiry of current
deputation tenure:
Station: Signature:
Date: Name:
Ph/Mob:
Part-II (to be filled in by the concerned State/UT Government)
C4
PiCadre || | ०  &€ |
Year of allotment [| |]
EiDate of superanniation S| SC
[Whether the officer is clear from vigilance angle | ७9 |
Is there any disciplinary proceedings pending against the officer (only
the cases where charge sheets have been served)
7.JHas the officer ever been reprimanded/penalized or debarred from]
deputation, if so the details thereof
Whether original/copies(attested) of ACRs of last eight years enclosed
9. Central Deputation Reserve (in figures) as on date of sponsorship:
[Authorized Filled Gap
10. State Deputation Reserve (in figures) as on date of sponsorship:
[Authorized Filled |
11. It is certified that the particulars given above about the officer are correct and that in the
event of the officer being selected for a posting under the CSS of the MoEFCC, the services of
the officer shall be placed at the disposal of the Central Government.
ame & designation of the Head of the Forest
Department of the State/UT or the Authorized Officer
Date:
Place:
Signature of the officer concerned
In the State Government/UT Government

<!-- page 5 -->

Annexure-IT
S. |Level offNumber of Existing) Stations*
No.|Post Expected Vacancies*|
ADGF 02 New Dethi (2)
Level
2 |DDGF 03 Nagpur (1), Ranchi (1), Shillong (1)
Level
3 |IGF 07 Bangalore (1), Guwahati (1), Kolkata (1), Nagpur (2), New Delhi (1),
Level Shimla (1)
IDIGF 34 Bangalore (1), Bhopal (1), Bhubaneswar (1), Burnihat (1),
Level Chandigarh (3), Dehradun (10), Kolkata (1), Lucknow (1), Nagpur
(3), New Delhi (8), Ranchi (2), Shillong (1), Shimla (1),
5 |AIGF 35 Bangalore (1), Bhubaneswar (1), Burnihat (4), Coimbatore (2),
Level Dehradun (9), Guwahati (1), Kolkata (2), Kurseong (3), Mumbai (1),
New Delhi (11)
*Number of vacancies and posting stations are tentative and liable to be changed.

<!-- page 6 -->

Annexure-IIT
CHECK LIST
1. Whether the application has been signed by the officer applying for deputation?
2. Whether Part II and Part [I has duly been filled and signed by:
(i) Head of Forest Department, Department of the State/UT or the Autonomous Offices.
(ii) Officer concerned in the State Government/ UT Government/ Concerned Administrative
Ministries where the officer is on deputation.
3. Whether the duly attested APARS for respective level posts (in accordance with CSS-MoEFCC) are
attached.
4. Whether State Government’s Vigilance Clearance is enclosed in part III of Annexure I.
5. Whether Updated Executive Record Sheet is enclosed.

<!-- page 7 -->

Annexure-IV
Additional requirements for NTCA posts
i. The criteria for AIGF (NTCA) posts are as under:
(a) (i) holding an analogous post on a regular basis; or
(ii) holding posts in the scale pay of Rs. 10,000 — 15200 (Pre-revised) or equivalent
with five years’ regular service in the grade; and
(b) having at least five years’ field experience in wildlife management
ii. The criteria for DIGF (NTCA) posts are as under:
a. (i) holding analogous post on regular basis; or
(ii) holding posts in the scale pay of Rs.12,000 - 18,000 (Pre-revised) or equivalent
with six years’ regular service in the grade; and
(b) having at least five years of experience in a tiger reserve or protected area.
iii. The criteria for IGF (NTCA) posts are as under:
a. (i) holding an analogous post on regular basis; or
(ii) the officer has completed a minimum of 19 years of service in IFS, with respect
to the year of allotment; and
b. having at least 8 years of experience in wildlife conservation, out of which five years should
be in tiger reserves or the National Tiger Conservation Authority/ Project Tiger Division of
the Ministry;
के कलर

<!-- page 8 -->

Areot xuRe - A
* Complete Executive Record Sheet Report
of the =
Service: Indian - Service
Cadre/Allotment Year ;
Date of Birth :
Gender :
Place of Domicile :
Date of Appointment to IFS :
Recruitment Source ;
IFS Cadre :
Officer Address: [ MartalStaus: ~~ OL
Telephone Office: | Telephone Residential: |
Fax Number: oO —e Do —
EmailAddress; | Tif Tenure Post (YesiNo).
If Yes, Date of Expiry of the i
ee Tenure cee J
Educational Qualifications.
[ Qualification 1 Qualification It ॥ Qualification It |
| a | po err |

<!-- page 9 -->

Posting Details
Ee ‘| Date of | Date of | 1 — =f Under | Pay Date of |
No | Posting | Posting (CadrelEx- | Levell Pay

From | To लि | Pay Level

css-Dopat) | Scale & | Scale
| Grade

a Po . ee ee झ#झ$ः
Training Details
iF Training cP EE हु "i |
No. | Type Year {in Day/ | From To Name Name | Name

(Domestic/ Month)
.....[Foreign | | ne
Specialization Details
[हलक . Area oF . Area oF . | ewosteation Award
specialization! | specialization It specialization Ill

xo - oF

<!-- page 10 -->

. , PARTICULARS OF THE OFFICER FOR WHOM VIGILANCE
COMMENTS/ CLEARANCE BEING SOUGHT
(To be furnished and signed by the CVO or HOD)
1. Name of the Officer (in full) :
2 Father's name :
3. Date of Birth :
4. Date of Retirement :
3. Date of Kntry into Service :
6 Service to which the officer :
belongs including bately
year/cadre etc. wherever applicable
(A). Positions held during the ten preceding years:
PiNo-Greaniationssiation “TAdminisirative? nodal M inistry/ निजी |
1 (Name in & Place of Deptt. concerned (in case of |
| ely posting, alficers of PSUs ete.) | fo
| | | |
|. |] । | जि
choo Bo 1 1ई<
(3. Whether the officer has functioned as a CVO in parl-time or
additional charge capaciiy(details thereof) :
“C), Whether the officer is currently placed under suspension: Yes/No
DATE:
(NAME AND SIGNATURE) है
