---
doc_id: "fd54f84cd4eae6b6"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/CORRIGENDUm_11062026.pdf"
ministry: "Department of Space"
title: "Corrigendum:LEOS/PT/05/2026-27 Dated:11.06.2026      116.56 KB"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "681e5760669a3ca0"
---

<!-- page 1 -->

भारत स रकार Government of India
अंत र

िवभाग Department of Space

िवद् यु त $कािशकी तं' $योगशाला
LABORATORY FOR ELECTRO-OPTICS SYSTEMS
$थम 9े ज ,$थम =ॉस /1 ST STAGE, IST CROSS,
पीBा औDोिगक सEदा/ PEENYA INDUSTRIAL ESTATE,
बIग लु J /BENGALURU-560 058.
दू रभाष सं॰./ Phone No.080 28398836
फ़ै Y सं/ Fax No:080-28391964
ई मेल : Email:purchase@leos.gov.in
Ref :िलयोस / LEOS/ पी टी /PT/05/2026-27/ िदनांक / Dated 11 June. 2026.
संशोधन सं
2026

ा : CORRIGENDUM NO.1 / Tender Posting on HQ Website -िव*ापन संदभ. सं /Advt. Ref. Number LEOS/PT/03/2026-27, िदनां क /Dated: 25 May

िवषय / Subject: LEOS 2026001018 01 for EOI FOR Supply, Installation, Demonstration and Training of Large Area Thin Film Coating System
(LATCS)
कृपया उपरोG िनिवदा को इसरो, ई-पोट. ल के िदनां क 25/05/2026
Kindly refer the subject e tender published in ISRO e portal dated 25.05.2026
अधोहSाTरी के Vारा उG िनिवदा मX िनYिलZखत प]रवत.न अिधसूिचत िकया जाता है ।
The undersigned hereby notify the following changes in the subject e tender.
dम सं / Sl. No.
01

िनिवदा सं

ा / Tender No

िववरण / Description

EOI FOR Supply, Installation, Demonstration and
Training of Large Area Thin Film Coating System
(LATCS)

LEOS 2026001018 01
बदले मX / In Place of

यथा प]रवित. त / Read As

following changes are recommended:
In Place of

To be read as

Laboratory for Electro-Optics Systems [LEOS], of Indian Space Research Laboratory for Electro-Optics Systems [LEOS], of Indian Space Research
Organization [ISRO] under Department of Space, Government of India is Organization [ISRO] under Department of Space, Government of India is
responsible for Design, Development, Production and Delivery Of Electro- responsible for Design, Development, Production and Delivery Of ElectroOptic Sensors And Optics To Spacecrafts. LEOS is currently inviting Optic Sensors And Optics To Spacecrafts. LEOS is currently inviting Global
indigenous Industry Partners for Supply, Installation, Demonstration, and Industry Partners for Supply, Installation, Demonstration, and Training of
Training of Large Area Thin Film Coating System (LATCS).
Large Area Thin Film Coating System (LATCS).
The EOI will be evaluated on the basis of bidder’s experience, The EOI will be evaluated as per 28.7 of EOI Specifications.
understanding of scope of work, facility infrastructure, proposed
methodology and work plan, skilled manpower and the financial strength
of the industry
Please address your clarifications quoting the EOI number to E-mail: Please address your clarifications quoting the EOI number to E-mail:
purchase@leos.gov.in. Request for participation in Pre-EoI meeting shall purchase@leos.gov.in. Request for participation in Pre-EoI meeting shall
reach on or before 30.06.2026 10:00 @ Hrs IST to the Email mentioned reach on or before 29.06.2026 16:00 @ Hrs IST to the Email mentioned
herein. However, response to EOI (hardcopy) shall be sent to above herein. However, response to EOI (hardcopy) shall be sent to above
mentioned postal address only). E-mail & Fax quotations are not mentioned postal address only). E-mail & Fax quotations are not
acceptable. Quotation received after due date & time are not acceptable. Quotation received after due date & time are not acceptable
acceptable
As per Below EOI Tender Documents
मूल िनिवदा सूच ना की अo सभी िन यम और शतI अप रवितp त रहेग ी ।
All other terms and conditions of the original tender notice shall remain unchanged.
Sd/=य एवं भंड ार अिधकारी
Purchase & Stores Officer
कृ ते एवं वाwे भारत के राxy पित,=े ता
For & on behalf of President of India,
The Purchaser

Page i

<!-- page 2 -->

भारत सरकार

Government of India

अंत र

Department of Space

िवभाग

िवद् युत $कािशकी तं' $योगशाला

LABORATORY FOR ELECTRO-OPTICS SYSTEMS

$थम 9े ज ,$थम =ॉस

1ST STAGE, IST CROSS,

पीBा औDोिगक सEदा

PEENYA INDUSTRIAL ESTATE,

बI ग लु J-560 058.

BENGALURU-560 058.

दू रभाष सं ॰-080 28398836.

Phone No.080 28398836

फ़ै Y सं -080-28391964

Fax No:080-28391964

ई मेल : purchase@leos.gov.in

Email:purchase@leos.gov.in

Ref No: LEOS 2026001018/EoI/2026-27

25.05.2026

Invitation for Expression of Interest (EOI) for
Large Area Thin Film Coating System (LATCS)
Laboratory For Electro-Optics Systems [LEOS], of Indian Space Research Organization [ISRO]

under Department of Space, Government of India is responsible for Design,
Development, Production And Delivery Of Electro-Optic Sensors And Optics To
Spacecrafts. LEOS is currently inviting Global Industry Partners for Supply, Installation,
Demonstration, and Training of Large Area Thin Film Coating System (LATCS).
This proposal is to invite Expression of Interest Global industries having technical
infrastructure and capability for Supply, Installation, Demonstration, and Training of Large
Area Thin Film Coating System (LATCS). Those vendors who are interested in qualifying

Supply, Installation, Demonstration, and Training of Large Area Thin Film Coating System
(LATCS) may respond to this enquiry, detailed EOI document attached.

In this regard, LEOS invites the Expression of Interest [EoI] from Global Industries/Vendors
who have or are in the process of establishing full-fledged Supply, Installation,
Demonstration, and Training of Large Area Thin Film Coating System (LATCS) to LEOS.
LEOS reserves the right to cancel/re-issue the process of EOI if the necessity so arises or
to seek further information/details.
Companies/Firms, if found to have indulged in any corrupt or fraudulent practices, will
be debarred taking part in the Tendering process and their EOI Document will not be
taken up for consideration.
Along with “Expression of Interest” Suppliers/ Firm[s] should furnish the following
information also in detail:
Page ii

<!-- page 3 -->

1. Registered address of the Companies with Phone, Fax, Email, Web etc.
2. Company/Organization Status (Proprietary/Partnership/Private/Public Ltd. etc.) with
Name and Address of Proprietor, Partners, Board of Directors, etc.
3. Associates: (a) Indian (b) Foreign.
4. List of Major Customers during the last 3 Years with full address and their Contact
Persons.
5. Details of Infrastructure Facilities owned / available.
6. Names and addresses of the major Shareholders of the Company and the percentage
of their share capital.
7. Capital and Turnover for the preceding 3 Financial Years with copy of latest Annual
Report.
8. Financial Capacity/Credit facilities available.
9. Name and Address of Bankers.
10. Trade Association to which Industry/ies belong to.
11. Establishment/Sales/Service Tax Registration Number.
12. Nature of Business
13. Solvency/Financial capacity of the Firm issued by their Bankers.
14. Any other information the Industry/ies consider relevant.
15. The Profile of the Company/ies clearly bringing out the areas of Strength

and

Weaknesses.
16. Self-Assessment Technical and Organizational Competence to take part in the EOI.
17. Response forms as mentioned in the EoI
Completion of the EOI Response:
a. Company/Firms are advised to study all the instructions; Terms and Conditions; Forms;
Requirements and other information in the EOI documents carefully. The submission
of EOI shall be deemed to have been done after a careful study and examination of the
EOI documents with full understanding of its implications.
b. The response to this EOI should be full and complete in all respect. Failure to furnish
all the information required by the EOI document or submission of proposal not
substantially responsive to the EOI documents to every aspect will be at the risk of the
Company/Firms and may result in rejection of the document.
c. All the pages of the EOI submitted must be numbered and signed by the authorized
signatory.
Page iii

<!-- page 4 -->

d. Canvassing in connection with the EOI be strictly prohibited and such canvassed EOI
submitted by the Agency are liable to be rejected.
A Pre-EoI meeting will be arranged by Laboratory For Electro-Optics Systems [LEOS],
Bengaluru in order to have a better understanding of the activities involved, clarify
doubts, if any. Subsequently, the vendor(s) shall submit the response to Expression of
Interest.
Interested Vendor[s] may please provide the details of the representative[s] taking part
in the Pre-EoI meeting well in advance prior to dates specified in Table-1 to the Focal
Point in order to arrange for Security clearance. Vendor[s] representative shall carry an
“Authorization Letter” for attending the Pre-EoI meeting. Member Representative shall
be limited to maximum of two (2) per bidder/company/organisation
Pre-EOI Queries from vendor [s] shall reach LEOS 5 days prior to date of Pre-EOI meeting
to

Mail

ID:

purchase@leos.gov.in.

Please

note

that

request

for

“Pre-

ponement/postponement of Pre-EoI meeting” will not be entertained under any
circumstances.
“Expression of Interest” with all the above information shall reach the address given
below, quoting the above Reference Number on or before the due date & time.
dय एवम भंडार अिधकारी / Purchase & Stores officer
िवद् युत •कािशकी तं € •योगशाला (िलयोस)
Laboratory For Electro-Optics System(LEOS)
भारतीय अ‚]रT अनु संधान सं गठन
Indian Space Research Organisation
अ‚]रT िवभाग, भारत सरकार Dept. of Space, Govt of India
बXगलू„ - 58 Bengaluru-58
कना. टक, भारत/Karnataka, India
Please

address

your

clarifications

quoting

the

EOI

number

to

E-mail:

purchase@leos.gov.in. Request for participation in Pre-EoI meeting shall reach on or
before 29.06.2026 16:00 @ Hrs IST to the Email mentioned herein. However, response
to EOI (hardcopy) shall be sent to above mentioned postal address only). E-mail & Fax
quotations are not acceptable. Quotation received after due date & time are not
acceptable.
Page iv

<!-- page 5 -->

तािलका 1
Table 1:
ई ओ आई िववरण की •Sु ित
Submission of EOI Details
‡ˆीकरण •Sु त करने की अं ितम ितिथ
Last date of submission of clarification
Pre-EOI meeting (at Conference
Hall, Reception (CISF), LEOS)
ईओआई •Sु त करने की अं ितम ितिथ
Last date for submission of EOI
ई ओ आई की खोलने की ितिथ
Opening date of EOI

25.06.2026 16:00 Hrs IST
30.06.2026 11:00 Hrs IST
14.08.2026 16:00 Hrs IST
17.08.2026 11:00 Hrs IST

“Expression of Interest” with all the above information shall reach the undersigned,
Quoting above Reference Number on or before 14.08.2026 @16:00 Hrs IST. This
proposal is initiated as a Pre-EOI Qualification. LEOS reserves the right to accept or reject
all or any such “Expression of Interest” without assigning any reasons what so ever.

हSा/sddय एवम भंडार अिधकारी / PSO

Page v
