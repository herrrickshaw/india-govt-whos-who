---
doc_id: "fde1d0998dc71afb"
source_url: "https://www.legislative.gov.in/static/uploads/2025/12/7c8dd73e299a8119c9b22babf0bc1008.pdf"
ministry: "Legislative Department (LD)"
title: "2021 to 2025"
date: "2025-12-04"
pages: 383
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d0a15223fa3d3bed"
---

<!-- page 1 -->

Central Regulation
2021
NIL
2022
1. The Lakshadweep Value Added Tax Regulation, 2022
2. The Lakshadweep (Right to Public Services) Regulation, 2022
3. The Lakshadweep Building Development Board (Repeal) Regulation, 2022
4. The Lakshadweep Co-Operative Societies Regulation, 2022
5. The Lakshadweep Panchayat Regulation, 2022
6. The Lakshadweep Open Place (Prevention of Defacement) Regulation, 2022
2023
1. The Laccadive, Minicoy and Amindivi Island Land Revenue and Tenancy (Amendment)
Regulation, 2023
2. The Andaman And Nicobar Island Tenancy Regulation, 2023
3. The Dadra And Nagar Haveli And Daman And Diu Tenancy Regulation, 2023
4. The Lakshadweep Tenancy Regulation, 2023
2024
1. The Dadra and Nagar Haveli and Daman and Diu Co-operative Societies Regulation, 2024
2025
1. The Union territory of Ladakh Reservation (Amendment) Regulation, 2025
2. The Ladakh Autonomous Hill Development Councils (Amendment) Regulation, 2025
3. The Ladakh Official Languages Regulation, 2025
4. The Ladakh Civil Services Decentralization and Recruitment (Amendment) Regulation, 2025
5. The Andaman And Nicobar Islands Co-operative Societies (Amendment) Regulation, 2025
6. The Lakshadweep Registration Of Societies Regulation, 2025
7. The Factories (Andaman And Nicobar Islands) Amendment Regulation, 2025
8. The Contract Labour (Regulation And Abolition) Andaman And Nicobar Islands (Amendment)
Regulation, 2025
9. The Industrial Disputes (Andaman and Nicobar Islands) Amendment Regulation, 2025.
10. The Andaman And Nicobar Islands Shops And Establishments (Amendment) Regulation, 2025
11. The Contract Labour (Regulation and Abolition) Dadra and Nagar Haveli and Daman and Diu
(Amendment) Regulation, 2025.
12. The Factories (Dadra and Nagar Haveli and Daman and Diu) Amendment Regulation, 2025.
13. The Industrial Disputes (Dadra and Nagar Haveli and Daman and Diu) Amendment
Regulation, 2025.
14. The Dadra And Nagar Haveli And Daman And Diu Shops And Establishments (Regulation Of
Employment And Conditions Of Service) Amendment Regulation, 2025
15. The Factories (Ladakh) Amendment Regulation, 2025.
16. The Industrial Disputes (Ladakh) Amendment Regulation, 2025
17. The Contract Labour (Regulation And Abolition) Lakshadweep (Amendment) Regulation,
2025
18. The Factories (Lakshadweep) Amendment Regulation, 2025
19. The Industrial Disputes (Lakshadweep) Amendment Regulation, 2025

<!-- page 2 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—22

REGISTERED

NO.

DL—(N)04/0007/2003—22

सी.जी.-डी.एल.-अ.-20092022-238921
xxxGIDHxxx
CG-DL-E-20092022-238921
xxxGIDExxx

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 20]

ubZ fnYyh] lkseokj] flrEcj 19] 2022@ Hkknzin 28] 1944 ¼'kd½

No. 20]

NEW DELHI, MONDAY, SEPTEMBER 19, 2022/BHADRA 28, 1944 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 19th September, 2022/Bhadra 28, 1944 (Saka)

THE LAKSHADWEEP VALUE ADDED TAX REGULATION, 2022
NO. 1 OF 2022
Promulgated by the President in the Seventy-third Year of the Republic of India.
A Regulation to provide for a tax system on the goods excluded from the Union Territory
Goods and Services Tax Act, 2017 and to widen the tax base by levying tax on sale of
the said goods at every point of sale, making the levy of tax transparent and for
matters connected therewith or incidental thereto.
In exercise of the powers conferred by article 240 of the Constitution, the President is
pleased to promulgate the following Regulation made by her:—
CHAPTER I

PRELIMINARY
1. (1) This Regulation may be called the Lakshadweep Value Added Tax
Regulation, 2022.
(2) It extends to the whole of the Union territory of Lakshadweep.
(3) The provisions of this Regulation shall come into force on such date as the
Administrator may, by notification in the Official Gazette, appoint.

Short title,
extent and
commencement.

<!-- page 3 -->

2
Definitions.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

2. (1) In this Regulation, unless the context otherwise requires,—
(a) "accountant" means—
(i) a chartered accountant as defined in clause (b) of sub-section (1) of
section 2 of the Chartered Accountant's Act, 1949;

38 of 1949.

(ii) a cost accountant as defined in the Cost and Works Accountants
Act, 1959;

23 of 1959.

(iii) an auditor appointed under section 139 of the Companies Act, 2013;

18 of 2013.

(b) "adequate proof" means such documents, testimony or other evidence as
may be prescribed;
(c) "Appellate Tribunal" means the Appellate Tribunal constituted under
section 73;
(d) "business" includes—
(i) the provision of any services, but excluding the services provided by
an employee;
(ii) any trade, commerce or manufacture;
(iii) any adventure or concern in the nature of trade, commerce or
manufacture;
(iv) any transaction in connection with, or incidental or ancillary to, such
trade, commerce, manufacture, adventure or concern; and
(v) any occasional transaction in the nature of such service, trade,
commerce, manufacture, adventure or concern,
whether or not—
(A) there is volume, frequency, continuity or regularity of such transaction;
(B) service, trade, commerce, manufacture, adventure or concern is carried on
with a motive to make gain or profit; and
(C) any gain or profit accrues from such service, trade, commerce, manufacture,
adventure or concern;
(e) "business premises" includes—
(i) the address of a dealer, registered with the Commissioner;
(ii) any building or place used by a person for the conduct of his business,
except for those parts of the building or place used principally as a residence;
(iii) any place from where a dealer carries on business through an agent
(by whatever name called), the place of business of such agent and a warehouse,
godown or such other place where a dealer stores his goods;
(f) "capital goods" means plant, machinery and equipment used, directly or indirectly,
in the process of trade or manufacturing or for execution of works contract in Lakshadweep;
(g) "casual trader" means a person who, whether as principal, agent or in any
other capacity undertakes occasional transactions in the nature of business involving
buying, selling, supply or distribution of goods or conducting any exhibition-cum-sale
in Lakshadweep whether for cash, deferred payment, commission, remuneration or
other valuable consideration;
(h) "Commissioner" means the Commissioner of Value Added Tax appointed
under sub-section (1) of section 66;

<!-- page 4 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(i) "dealer" means any person who, for the purposes of or consequential to his
engagement in or in connection with or incidental to or in the course of his business,
buys or sells goods in Lakshadweep directly or otherwise, whether for cash or for
deferred payment or for commission, remuneration or other valuable consideration
and includes,—
(i) a factor, commission agent, broker, del credere agent or any other
mercantile agent by whatever name called, who for the purposes of or
consequential to his engagement in or in connection with or incidental to or in
the course of the business, buys or sells or supplies or distributes any goods on
behalf of any principal or principals whether disclosed or not;
(ii) a non-resident dealer or as the case may be, an agent, residing in the
State of a non-resident dealer, who buys or sells goods in Lakshadweep for the
purposes of or consequential to his engagement in or in connection with or
incidental to or in the course of the business;
(iii) a local branch of a firm or company or an association of persons,
outside Lakshadweep where such firm, company, association of persons is a
dealer under any other sub-clause of this definition;
(iv) a club, association, society, trust, or co-operative society, whether
incorporated or unincorporated, which buys goods from or sells goods to its
members for price, fee or subscription, whether or not in the course of business;
(v) an auctioneer, who sells or auctions goods whether acting as an agent
or otherwise or, who organises the sale of goods or conducts the auction of
goods whether or not he has the authority to sell the goods belonging to any
principal, whether disclosed or not and whether the offer of the intending
purchaser is accepted by him or by the principal or a nominee of the principal;
(vi) a casual trader;
(vii) any person who, for the purposes of or consequential to his
engagement in or in connection with or incidental to or in the course of his
business disposes of any goods as unclaimed or confiscated, or as unserviceable
or scrap, surplus, old, obsolete or as discarded material or waste products by
way of sale;
52 of 1962.

(viii) Customs Department of the Government of India administering
Customs Act, 1962;
(ix) Departments of the Central Government, the State Governments and
the Union territory Administrations;
(x) local authorities, Panchayats, Municipalities, Development Authorities
and Cantonment Boards;
(xi) Public Charitable Trusts;
(xii) incorporated or unincorporated societies, clubs or other associations
of persons;
(xiii) each autonomous or statutory body or corporation or company or
society or any industrial, commercial, banking, insurance or trading undertaking,
corporation, institution or company whether or not of the Union Government or
any of the State Governments or of a local authority;
(xiv) shipping and construction companies, air transport companies, airlines
and advertising agencies;

<!-- page 5 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(j) "fair market value" means the value at which goods of like kind and quality are
sold or would be sold in the same quantities between unrelated parties in the open
market in Lakshadweep;
(k) "goods" means goods specified in the First Schedule, as amended from time
to time;
(l) "goods vehicle" means a motor vehicle, vessel, boat, animal and any other
form of conveyance used for carrying goods;
(m) "Government" means the Administration of Union territory of Lakshadweep
headed by the Administrator appointed by the President under article 239 of the
Constitution;
(n) "import" means sale or purchase in the course of the import of goods into the
territory of India if the sale or purchase either occasions such import or is effected by
transfer of document of title to the goods before the goods have crossed the customs
frontiers of India and includes procurement of goods from outside the Lakshadweep
either as a result of purchase or otherwise.
Explanation.—In the case of goods arriving in Lakshadweep from a foreign
country through customs, the "import of the goods in Lakshadweep" shall occur at
the place where the goods are cleared by Customs for home consumption;
(o) "importer" shall include—
(i) a person who brings his own goods into Lakshadweep;
(ii) a person on whose behalf another person brings goods into
Lakshadweep;
(iii) in the case of a sale occurring in the circumstances referred to in
sub-section (2) of section 6 of the Central Sales Tax Act, 1956, the person in
Lakshadweep to whom the goods are delivered;
(p) "input tax", in relation to the purchase of goods, means the proportion of the
price paid by the buyer for the goods which represents tax for which the selling dealer
is liable under this Regulation;
(q) "Lakshadweep" means the Union territory of Lakshadweep;
(r) "manufacture" with its grammatical variations and cognate expressions, means
producing, making, extracting, altering, ornamenting, finishing or otherwise processing,
treating or adapting any goods, but does not include any such process or mode of
manufacture as may be prescribed;
(s) "net tax" means the amount calculated for a tax period under section 11;
(t) "non-resident" means a person who has no fixed place of business or residence
in Lakshadweep;
(u) "notification" means the notification published in the Official Gazette and
the expressions "notify" and "notified" shall be construed accordingly;
(v) "Official Gazette" means the Lakshadweep Gazette;
(w) "prescribed" means prescribed by rules made by the Government under this
Regulation;
(x) "registered dealer" means a dealer registered under this Regulation;
(y) "related person" means a person who is related to another person (referred
to in this definition as a "dealer") if the person—
(i) is a relative of the dealer;

74 of 1956.

<!-- page 6 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

5

(ii) is a partnership of which the dealer is a partner;
(iii) is a company in which the dealer [either alone or in conjunction with
another person who is, or persons who are, related to the dealer under subclauses (i), (ii), (iv), (v) and (vi)].—directly or indirectly holds forty per cent. or
more of outstanding voting stock or shares;
(iv) is a person who [either alone or in conjunction with another person
who is, or other persons who are, related to the person under sub-clauses (i),
(ii), (iii), (v) and (vi)].—directly or indirectly owns forty per cent. or more of
outstanding voting stock or shares of the dealer;
(v) is a company in which forty per cent. or more of outstanding voting
stock is held directly or indirectly by a person [either alone or in conjunction
with another person who is, or other persons who are, related to the person
under sub-clauses (i), (ii), (iii), (iv) and (vi)] who also holds forty per cent. or
more of the outstanding voting stock or shares of the dealer; or
(vi) is controlled by the dealer or a person whom the dealer controls, or is
a person who is controlled by the same person who controls the dealer;
18 of 2013.

(z) "relative" means a relative as defined in clause (77) of section 2 of the
Companies Act, 2013;
(za) "sale" with its grammatical variations and cognate expression, means any
transfer of property in goods by one person to another for cash or for deferred payment
or for other valuable consideration (not including a grant or subvention payment made
by one Government agency or department, whether of the Central Government or of
any State Government, to another) and includes—
(i) a transfer of goods on hire purchase or other system of payment by
instalments, but does not include a mortgage or hypothecation of, or a charge or
pledge on goods;
(ii) supply of goods by a society (including a co-operative society), club,
firm, or any association to its members for cash or for deferred payment or for
commission, remuneration or other valuable consideration, whether or not in the
course of business;
(iii) transfer of property in goods by an auctioneer referred to in subclause (v) of clause (i), or sale of goods in the course of any other activity in the
nature of banking, insurance who in the course of their main activity also sell
goods repossessed or re-claimed;
(iv) transfer, otherwise than in pursuance of a contract, of property in any
goods for cash, deferred payment or other valuable consideration;
(v) transfer of the right to use any goods for any purpose (whether or not
for a specified period) for cash, deferred payment or other valuable consideration;
(vi) supply, by way of or as part of any service or in any other manner
whatsoever, of goods, being food or any other article for human consumption or
any drink (whether or not intoxicating), where such supply or service is for cash,
deferred payment or other valuable consideration;
(vii) every disposal of goods referred to in sub-clause (vii) of clause (i) of
this sub-section and the words "sell", "buy" and "purchase" wherever appearing
with all their grammatical variations and cognate expressions, shall be construed
accordingly;
(zb) "sale price" means the amount paid or payable as valuable consideration
for any sale, including—

<!-- page 7 -->

6

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(i) the amount of tax, if any, for which the dealer is liable under section 3;
(ii) in relation to the delivery of goods on hire purchase or any system of
payment by instalments, the amount of valuable consideration payable to a
person for such delivery including hire charges, interest and other charges
incidental to such transaction;
(iii) in relation to transfer of the right to use any goods for any purpose
(whether or not for a specified period), the valuable consideration or hiring
charges received or receivable for such transfer;
(iv) any sum charged for anything done by the dealer in respect of goods
at the time of, or before, the delivery thereof;
(v) amount of duties levied or leviable on the goods under the Central
Excise Act, 1944 or the Customs Act, 1962, or the Lakshadweep excise regulation
whether such duties are payable by the seller or any other person;
(vi) amount received or receivable by the seller by way of deposit (whether
refundable or not) which has been received or is receivable whether by way of
separate agreement or not, in connection with, or incidental to or ancillary to the
sale of goods; and
(vii) in relation to works contract means, the amount of valuable
consideration paid or payable to a dealer for the execution of the works contract,
less—
(a) any sum allowed as discount which goes to reduce the sale price
according to the practice, normally, prevailing in trade;
(b) the cost of freight or delivery or the cost of installation in cases
where such cost is separately charged and the words "purchase price"
with all their grammatical variations and cognate expressions, shall be
construed accordingly:
Provided that where the dealer makes sale of goods imported into the territory of
India, the sale price shall be higher of the following—
(a) the valuable consideration received or receivable by the dealer;
(b) value determined by the Custom authorities for payment of custom
duty at the time of the import of such goods;
(zc) "Schedule" means the Schedules appended to this Regulation;
(zd) "tax" means tax payable under this Regulation;
(ze) "taxable quantum" means the quantum of amount referred to in sub-section (2)
of section 18;
(zf) "tax invoice" means the invoice referred to in section 50;
(zg) "tax period" means the period prescribed in the rules made under this
Regulation;
(zh) "tax fraction" means the fraction calculated in accordance with formula,
r / (r+100) where 'r' is the percentage rate of tax applicable to the sale under this
Regulation;
(zi) the expression, "in the course of " includes activities done for the purposes
in connection with or incidental to, and activities done as part of the preparation for
the activity and the termination of the activity;
(zj) "transporter" means any person who, for the purposes of or in connection
with or incidental to or in the course of his business transports or causes to transport
goods, and includes any person whose business consists of or includes operating a

1 of 1944.
52 of 1962.

<!-- page 8 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

7

railway, shipping company, air cargo terminal, inland container depot, container freight
station, courier service or airline;
(zk) "turnover" means the aggregate of the amounts of sale price received or
receivable by the person in any tax period, reduced by any tax for which the person is
liable under section 3;
(zl) "turnover of purchases" means the aggregate of the amounts of purchase
price paid or payable by a person in any tax period, excluding any input tax;

74 of 1956.

(zm) "value of goods" means the fair market value of the goods at that time
including insurance charges, excise duties, countervailing duties, tax paid or payable
under the Central Sales Tax Act, 1956 in respect of the sale, transport charges, freight
charges and all other charges incidental to the transaction of the goods;
(zn) "works contract" includes any agreement for carrying out for cash or for
deferred payment or for valuable consideration, the building construction, manufacture,
processing, fabrication, erection, installation, fitting out, improvement, repair or
commissioning of any movable or immovable property;
(zo) "year" means the financial year from the first day of April to the last day of
March.
(2) Unless otherwise specified in this Regulation—
(a) expressions referring to "writing" shall include printing, typing, lithography,
photography and other methods of representing or reproducing words in a visible
form; and
(b) with reference to a person who is unable to sign his name, the word "signature"
shall include his thumb impression or other mark duly attested to signify his signature.

9 of 1972.

(3) The words and expressions not defined in this Regulation but defined in the Indian
Contract Act, 1872 shall have the meanings respectively assigned to them in that Act.
CHAPER II

LEVY OF TAX
3. (1) Subject to the other provisions of this Regulation, every dealer who is—
(a) registered under this Regulation; or
(b) required to be registered under this Regulation,
shall be liable to pay tax calculated in accordance with this Regulation, at the time and in the
manner provided in this Regulation.
(2) Every dealer who has become liable to pay tax under this Regulation on the sale of
goods shall continue to be so liable unless his taxable turnover during the preceding twelve
months, or such further period as may be prescribed, has remained below the taxable quantum
and on the expiry of the twelve months or such further period his liability to pay tax shall
cease:
Provided that any dealer whose liability to pay tax under this Regulation ceases for
any other reason may apply earlier for the cancellation of his registration, and on such
cancellation, his liability to pay tax shall cease:
Provided further that a dealer shall remain liable to pay tax until the date on which his
registration is cancelled.
(3) Every dealer whose liability to pay tax under this Regulation has ceased or whose
registration has been cancelled, shall, if his turnover calculated from the commencement of
any year, including the year in which the registration has been cancelled, again exceeds the
taxable quantum on any day within such year be liable to pay such tax on and from the date

Levy of tax.

<!-- page 9 -->

8

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

on which his turnover again exceeds the taxable quantum, on all sales effected by him on and
after that day.
(4) Where it is found that any person registered as a dealer ought not to have been so
registered, then notwithstanding anything contained in this Regulation, such person shall
be liable to pay tax for the period during which he was registered.
(5) If any person who transports goods or holds goods in custody for delivery to or on
behalf of any person, on being required by the Commissioner so to do, fails—
(a) to furnish any information in his possession in respect of the goods; or
(b) to permit inspection thereof,
then without prejudice to any other action which may be taken against such person, a
presumption may be raised that the goods in respect of which he has failed to furnish
information or permit inspection, are owned by him and are held by him for sale in Lakshadweep
and the provisions of this Regulation shall apply.
(6) If any person who, whether as principal, agent or in any other capacity organises
any exhibition-cum-sale in Lakshadweep and fails—
(a) to furnish any information in respect of the goods brought or kept in stock or
sold by any participant before or during or after the exhibition-cum-sale; or
(b) to ensure that all the participants in the exhibition-cum-sale have obtained
registration under this Regulation and paid due tax; or
(c) to permit inspection of the business premises or goods or account and
records of the participants; or
(d) to permit inspection of the accounts and records of the organiser in respect
of the exhibition-cum-sale,
then, without prejudice to any other action which may be taken against such participant, a
presumption may be raised that the goods of the participant who fails to obtain registration
under this Regulation or the goods in respect of which the participant has failed to furnish
information or failed to permit inspection, are owned by the organiser and are held by him for
sale in Lakshadweep and the provisions of this Regulation shall apply.
Rates of tax.

4. (1) The rates of tax as specified in the First Schedule shall be payable on the taxable
turnover of a dealer in respect of goods description of which have been given in that
Schedule.
(2) The Government may, by notification, if it deems necessary, amend the rates of tax
as specified in the First Schedule.

Taxable
turnover.

5. For the purposes of this Regulation, "taxable turnover" means the turnover of a
dealer during the tax period which remains after deducting therefrom—
(a) the turnover of sales not subject to tax under section 7; and
(b) the turnover of sales of goods declared exempt under section 6.

Sale exempt
from tax.

6. The goods to be listed in the Second Schedule shall be exempted from tax subject to
the conditions and exceptions set out in the said Schedule.

Certain sales
not liable to
ta x.

7. Nothing contained in this Regulation or the rules made thereunder shall be deemed
to impose or authorise the imposition of tax on any sale of goods when such sale takes
place—
(a) in the course of inter-State trade or commerce; or
(b) outside Lakshadweep; or

<!-- page 10 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

9

(c) in the course of import of the goods into or export of the goods out of, the
territory of India; or

36 of 2002.

(d) in accordance with the notification issued by the Central Government in
exercise of its powers under section 3 of the Foreign Aircraft (Exemption from Taxes
and Duties on Fuel) Act, 2002, no tax shall be levied on sales of the fuel and lubricants
which are filled into receptacles forming part of any aircraft registered in a country
other than India, if—
(i) the said country is a party to the Convention on International and Civil
Aviation, 1944;
(ii) the said country has entered into an Air Services agreement with
India; and
(iii) the aircraft is operating on a scheduled or non-scheduled service to or
from India.
8. (1) Subject to such conditions as may be prescribed, this section shall apply where,
in relation to the sale of goods by any dealer,—
(a) that sale has been cancelled;
(b) the nature of that sale has been fundamentally varied or altered;
(c) the previously agreed consideration for that sale has been altered by agreement
with the recipient, whether due to the offer of a discount or for any other reason;
(d) the goods or part of the goods sold have been returned to the dealer within
six months of the date of sale; or
(e) the whole or part of the price owed by the buyer for the purchase of the
goods has been written-off by the dealer as a bad debt,
and the dealer has—
(i) provided a tax invoice in relation to that sale and the amount shown therein as tax
charged on that sale is not the tax properly chargeable on that sale; or
(ii) furnished a return in relation to a tax period in respect of which tax on that
sale is attributable, and has accounted for an amount of tax on that sale that is not the
amount properly chargeable on that sale.
(2) Where a dealer has accounted for an incorrect amount of tax as contemplated in
sub-section (1), that dealer shall make an adjustment in calculating the tax payable by that
dealer in the return for the tax period during which it has become apparent that the tax is
incorrect, and if—
(a) the tax payable in relation to that sale exceeds the tax actually accounted for
by the dealer, the amount of that excess shall be deemed to arise in the tax period in
which the adjustment is made, and shall not be attributable to any prior tax period; or
(b) the tax actually accounted for exceeds the tax payable in relation to the sale,
the amount of that deficiency shall be subtracted from the tax payable by the dealer in
the tax period in which the adjustment is made, and shall not be attributable to any
prior tax period.
(3) Where a dealer sells goods that have been used in part for making—
(a) sales that are subject to tax under this Regulation or sales that are not liable
to tax under section 7; and
(b) partly for other purposes, the amount of tax on the sale of the goods shall be
the greater of—
(i) A— (A x B / C); or
(ii) A— B;

Adjustments of
tax.

<!-- page 11 -->

10

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

where—
A = the tax for which the dealer would be liable in respect of the sale apart
from this section;
B = the amount by which the tax credit of the dealer in respect of the goods
was reduced under sub-section (4) of section 9;
C = the amount of the tax credit before reduction under sub-section (4)
of section 9.
Tax credit.

9. (1) No tax credit shall be allowed—
(a) in the case of the purchase of goods for goods purchased from a person who
is not a registered dealer;
(b) for the purchase of non-creditable goods as listed in the Third Schedule;
(c) for the purchase of goods which are to be incorporated into the structure of
a building owned or occupied by the person;
(d) for goods purchased from a dealer who has elected to pay tax under section 16;
(e) for goods purchased from a casual trader;
(f) to the dealers or class of dealers unless the tax paid by the purchasing dealer
has actually been deposited by the selling dealer with the Government or has been
lawfully adjusted against output tax liability and correctly reflected in the return filed
for the respective tax period.
(2) The amount of the tax credit to which a dealer is entitled in respect of the purchase
of goods shall be the amount of input tax arising in the tax period reduced in the manner
described in sub-sections (3), (5) and (7).
(3) Where a dealer has purchased goods and the goods are to be used partly for the
purpose of making the sales referred to in sub-section (1) and partly for other purposes, the
amount of the tax credit shall be reduced proportionately.
(4) The method used by a dealer to determine the extent to which the goods are used
in the manner specified in sub-section (4) of section 10, shall be fair and reasonable in the
circumstances:
Provided that the Commissioner may—
(a) after giving reasons in writing, reject the method adopted by the dealer and
calculate the amount of tax credit; and
(b) prescribe methods for calculating the amount of tax credit or the amount of
any adjustment or reduction of a tax credit in certain instances.
(5) Notwithstanding anything to the contrary contained in sub-section (1), where—
(a) a dealer has purchased goods (other than capital goods) for which a tax
credit arises under sub-section (1);
(b) the goods or goods manufactured out of such goods are to be exported from
Lakshadweep by way of transfer to a—
(i) non-resident consignment agent; or
(ii) non-resident branch of the dealer; and
(c) the transfer shall not be by way of a sale made in Lakshadweep; the amount
of the tax credit shall be reduced by the prescribed percentage.
Explanation.—For the removal of doubts, it is hereby clarified that no tax credit shall
be allowed for the purchase of goods from an unregistered dealer.

<!-- page 12 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

11

(6) The tax credit may be claimed by a dealer only if he holds a tax invoice at the time the
prescribed return for the tax period is furnished.
(7) Notwithstanding anything to the contrary contained in sub-section (1), where—
(a) a dealer has purchased goods (other than capital goods) for which a tax
credit arises under sub-section (1); and

74 of 1956.

(b) the goods or goods manufactured out of such goods are to be exported from
Lakshadweep by way of sale made under sub-section (1) of section 8 of the Central
Sales Tax Act, 1956, the amount of the tax credit shall be reduced by the prescribed
percentage.
(8) Subject to the provisions of sub-sections (1) and (2), the tax credit of goods to be
used for sale, as defined in sub-clause (v) of clause (zb) of sub-section (1) of section 2, shall
be allowed as follows:—
(a) 1/4th of the input tax on such goods arising in the tax period, in the same tax
period;
(b) balance 3/4th of such input tax, in equal proportions, in corresponding tax
periods, in three immediately successive financial years.
10. (1) Where any purchaser has been issued with a credit note or debit note in terms
of section 51 or if he returns or rejects goods purchased, as a consequence of which the tax
credit claimed by him in any tax period in respect of which the purchase of goods relates,
becomes short or excess, he shall compensate such short or excess by adjusting the amount
of the tax credit allowed to him in respect of the tax period in which the credit note or debit
note has been issued or goods are returned.
(2) If goods which have been purchased were—
(a) intended to be used for the purposes specified under sub-section (1) of
section 9 and are subsequently used, fully or partly, for purposes other than those
specified under the said sub-section; or
(b) intended for purposes other than those specified under sub-section (1) of
said section 9, and are subsequently used, fully or partly, for the purposes specified in
the said sub-section,
the tax credit claimed in respect of such purchase shall be reduced or increased (as the case
may be) for the tax period during which the said utilisation otherwise has taken place.
(3) Where—
(a) goods were purchased by a dealer;
(b) the dealer claimed a tax credit in respect of the goods, and did not reduce the
tax credit by the prescribed percentage; and
(c) the goods are exported from Lakshadweep,—

74 of 1956.

(i) by way of a sale made as per the provisions of sub-section (1) of
section 8 of the Central Sales Tax Act, 1956; or
(ii) other than by way of a sale, to a branch of the registered dealer or to
a consignment agent,
the dealer shall reduce the amount of tax credit originally claimed by the prescribed proportion.
(4) If goods which have been purchased by a dealer were—
(a) intended to be used for the purposes specified under sub-section (1) of
section 9; and
(b) are subsequently incorporated into the structure of a building owned or
occupied by the person,
the tax credit claimed in respect of such purchase shall be reduced in the tax period during
which such incorporation takes place.

Adjustment of
tax credit.

<!-- page 13 -->

12

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(5) Where the goods which have been purchased by a dealer are sold at a price lower
than the price at which it was purchased by the dealer, the tax credit on such purchases shall
be reduced proportionately in the tax period during which the goods are sold.
Net tax.

11. (1) The net tax payable by a dealer for a tax period shall be determined by the
formula: Net tax = O — I — C
Where—
O = the amount of tax payable by the person at the rates stipulated in section 4
in respect of the taxable turnover arising in the tax period, adjusted to take into account
any adjustments to the tax payable required by section 8.
I = the amount of the tax credit arising in the tax period to which the person is
entitled under section 9, adjusted to take into account any adjustments to the tax credit
required by section 10.
C = the amount, if any, brought forward from the previous tax period under
sub-section (2).
(2) Where the net tax of a dealer calculated under sub-section (1) amounts to a negative
value, the dealer shall—
(a) adjust the said amount in the same tax period against the tax payable by him
under the Central Sales Tax Act, 1956 if any; and
(b) be entitled to carry forward the amount remaining after application under
clause (a) of sub-section (2) to next calendar month or tax period, as the case may be,
of the same year, or claim a refund of the amount remaining after application under
clause (a) of sub-section (2) at the end of a tax period of the same year and the
Commissioner shall deal with the refund claim in the manner described in section 38
and section 39.
(3) No tax shall be payable under this Regulation by a contractor on the amount
representing the value of the goods supplied by the contractee to the contractor in the
execution of works contract in which the ownership of such goods remains with the contractee
under the terms of the contract and the amount representing the value of the goods supplied
by the contractee to the contractor does not form part of the contract and is not deductible
from the amount payable to the contractor by the contractee for the execution of the works
contract.

Time at which
amount of
turnover,
turnover of
purchases and
adjustments
arise.

12. (1) Subject to the provisions of sub-sections (2), (3) and (4), the amount of the
turnover and the turnover of purchases of a dealer which arises during any tax period shall
be the amount recorded in the accounts of the dealer where those accounts are regularly and
systematically prepared and maintained, give a true and fair view of his dealings, and are
employed by the dealer in determining the turnover of the dealer's business for commercial or
income-tax purposes.
(2) The Commissioner may by notification—
(a) permit certain classes of dealer to record turnover based on amounts paid or
received; and
(b) require certain classes of dealer to record turnover based on amounts payable
or receivable.
(3) Where a dealer wishes to change the method of determining the turnover and
turnover of purchases, he may only make the change with the consent of the Commissioner
and on such terms and conditions as the Commissioner may impose.
(4) The Government may prescribe the time at which a dealer shall treat the—
(a) turnover;

74 of 1956.

<!-- page 14 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

13

(b) turnover of purchases; and
(c) adjustment of tax or adjustment to a tax credit,
as arising for a class of transactions.
CHAPTER III

SPECIAL REGIMES
13. Where a provision in this Chapter is inconsistent with a provision in Chapter II, the
provision in this Chapter shall, to the extent of the inconsistency, prevails.

Priority.

14. (1) Within a period of four months of the commencement of this Regulation, all
registered dealers wishing to claim the credit referred to in sub-section (2), shall furnish to
the Commissioner a statement of their trading stock, raw materials and packaging materials
for trading stock (in this section referred to as "opening stock").

Treatment of
stock brought
forward during
transition.

(2) For the avoidance of doubt, no tax credit under sub-section (2) can be claimed—
(a) for finished goods manufactured out of tax paid on raw material or capital
goods;
(b) in a statement furnished more than four months after the commencement; or
(c) for opening stock which is held outside Lakshadweep.
(3) Every dealer wishing to claim a tax credit in excess of one lakh rupees on opening
stock shall furnish with the statement a certificate signed by an accountant in the prescribed
form certifying that the net credit claim made is true and correct.
15. (1) The provisions of this section shall apply where—
(a) a registered dealer sells second hand goods;

Second hand
goods.

(b) the registered dealer has purchased goods from a resident seller who was
not registered under this Regulation;
(c) the goods were purchased either as trading stock for re-sale in an unmodified
form or otherwise or as raw material for incorporation or division into trading stock;
(d) the registered dealer shall be liable to pay tax under section 3 on the sale of
the goods or the goods into which they were incorporated, as the case may be; and
(e) the registered dealer has adequate proof of the amount paid for the goods.
(2) In the circumstances mentioned in sub-section (1), the registered dealer shall be
entitled to a tax credit for the purposes of section 9 of the least of—
(a) the input tax borne by the resident seller when he purchased the goods;
(b) the tax fraction of the original cost of the goods to the resident seller;
(c) the tax fraction of the fair market value of the goods at the time of their
purchase by the registered dealer; or
(d) the tax fraction of the consideration paid by the registered dealer for the
goods.
(3) Where the amount paid by the registered dealer for the goods exceeds two thousand
rupees, the tax credit shall be allowed in the tax period when the goods are sold by the
registered dealer or the goods into which they have been incorporated are sold by the
registered dealer.
16. (1) Notwithstanding anything contrary to this Regulation, every dealer whose—
(a) turnover in the year preceding the commencement; or

Composition
of scheme for
specified
dealers.

<!-- page 15 -->

14

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) turnover in the current year, does not exceed five lakh rupees or such other
amount as may be specified by the Government by notification in the Official Gazette,
shall have an option to pay tax under this section:
Provided that this sub-section shall not apply to dealers procuring goods from any
place outside Lakshadweep or selling or supplying goods to any place outside Lakshadweep
at any time during the year in which he opts to pay tax under this sub-section or if he is a
registered dealer in the Lakshadweep under the Central Sales Tax Act, 1956:
Provided further that in case the Government has notified a composition scheme for a
class of dealers under sub-section (12), such dealers shall not have an option to pay tax
under this sub-section.
(2) At the time of making application for registration under section 19 of this Act, the
dealer covered under sub-section (1) shall be required to specify if he intends to pay tax
under this section:
Provided that once the dealer chooses to pay tax under this section, the option may be
reversed only after the end of the year for which the option is made, by application to the
Commissioner within such time and in such manner as may be prescribed:
Provided further that where a dealer chooses to reverse his option to pay tax under this
section, he shall be eligible to claim credit of the tax paid under this Regulation on the trading
stock, raw material and packaging material held by him in Lakshadweep on the date when
such reversal takes effect subject to the conditions contained in section 20 in so far as they
are applicable.
(3) In case a person who elects to pay tax under this section whose turnover in the year
preceding the commencement of this Regulation does not exceed five lakh rupees or such
other amount as may be specified by the Government by notification in the Official Gazette,
he shall be required to specify the election to pay tax under this section within such time and
in such manner as may be prescribed.
(4) Where a dealer elects to pay tax under this section, the dealer's net tax shall be the
amount determined at the rate of one paisa in the rupee of the turnover of the dealer.
(5) A dealer who elects to pay tax under this section shall—
(a) not purchase goods from a person who is not registered under this Regulation;
(b) not compute his net tax under section 11;
(c) not be allowed to claim credit under section 9, section 14 and section 15;
(d) not be entitled to issue tax invoice;
(e) not be allowed to collect any amount by way of tax under this Regulation; and
(f) continue to retain tax invoices and retail invoices for all of his purchases as
required under section 48.
(6) In case a person—
(a) whose turnover in the year preceding the commencement of this Regulation
does not exceed five lakh rupees or such other amount as may be specified by the
Government by notification in the Official Gazette; and
(b) who has opted to pay tax under this section in terms of sub-section (3) of this
section,
he shall be required to pay tax on the goods held on the date of the commencement of this
Regulation at the rates specified in section 4 on the fair market value of goods where such
goods have not borne any tax under the Lakshadweep.

74 of 1956.

<!-- page 16 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

15

(7) The tax due under sub-section (6) shall be paid at any time before the person
specifies his intention to pay tax under this section.
(8) The proof of payment of tax referred to in sub-section (6) along with a statement of
opening stock and finished goods in such form as may be prescribed shall be furnished to
the Commissioner at the time the person specifies his intention to pay tax under this section.
(9) Subject to the other provisions, where a registered dealer pays tax at the rates
specified in section 4, he may choose to pay tax under this section only from the beginning
of the following year:
Provided that such registered dealer shall be required to pay tax at the rates specified
in section 4 on the goods held by him on the first day of the said following year.
(10) If the turnover of a dealer who elects to pay tax under this section exceeds five
lakh rupees or such other amount as may be specified by the Government by notification in
the Official Gazette, he shall be liable to pay tax under section 3 on and from the day his
taxable turnover exceeds five lakh rupees or such other amount as may be specified by the
Government by notification in the Official Gazette and shall be entitled to claim credit of the
input tax paid under this Regulation on goods held by him in Lakshadweep on such day:
Provided that such dealer has intimated the Commissioner within seven days of his
becoming liable to pay tax under section 3 in the prescribed form and has furnished such
other information to the Commissioner as may be prescribed.
(11) The Commissioner may notify a dealer or a class of dealers who shall not be
entitled to opt for payment of tax under this section.
(12) Notwithstanding anything to the contrary contained in this Regulation, the
Government may—
(a) by notification in the Official Gazette, notify schemes of composition, subject
to such conditions and restrictions as may be specified therein, of tax payable by a
class of dealers or classes of dealers and different types of schemes may be notified for
different classes of dealers;
(b) specify, in any scheme of composition of tax payable by the class of dealers
or classes of dealers, different rates of taxes for different class or classes of dealers but,
in such scheme, the net tax liability of the dealer opting to pay tax thereunder shall not
exceed eight paise in the rupee of the turnover of the dealer.
(13) (a) Notwithstanding anything to the contrary contained in this Regulation, a
casual trader shall—
(i) at least three days before commencing business in Lakshadweep, inform the
Commissioner of such particulars of his business in such form and manner as may be
prescribed;
(ii) deposit security in cash or in the form of bank draft as may be fixed by the
Commissioner which shall not exceed estimated liability to pay tax for seven days or
such lesser period for which the casual trader is conducting the business in
Lakshadweep;
(iii) pay tax daily on the sales made during the previous day;
(iv) furnish to the Commissioner, immediately after conclusion of his business in
Lakshadweep, a return in the prescribed form and manner; and
(v) not issue any tax invoice.
(b) The Commissioner shall, after verification of information furnished to him under
clause (a) of sub-section (1) and after getting security under clause (b) of that sub-section,
shall register the casual trader.

<!-- page 17 -->

16

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(c) Upon registration of casual trader, the Commissioner may issue the required forms
to him for use as the declaration referred to in sub-section (4) of section 61 for bringing
goods for sale in Lakshadweep and for taking the unsold goods out of Lakshadweep and the
casual trader shall render complete account of the used forms and surrender the unused
forms along with the return referred to in section 26.
(d) The Commissioner shall, after examination of the return furnished by the casual
trader, the forms and the accounts maintained by him including the retail invoices issued,
assess him to tax within five days and shall serve upon him a notice of assessment and after
adjusting any tax and any other dues payable under this Regulation, refund the balance
amount of security to him in case security is deposited in the form of cash deposit.
(e) The casual trader shall pay immediately the amount mentioned in the notice of
assessment.
(f) On being satisfied that the amount due has been paid, the Commissioner shall
release the security or balance security, as the case may be.
(g) Notwithstanding anything contained in this Regulation, the taxable quantum in
respect of a casual trader shall be nil.
Transactions
between
related parties.

17. If—
(a) a registered dealer sells or gives goods to a related person;
(b) the terms or conditions of the transaction have been influenced by the
relationship; and
(c) the related person had purchased the goods, the related person would not be
entitled to a tax credit for the purchase, or the amount of the tax credit would be
reduced under sub-section (3) of section 9,
the transaction shall be deemed to be a sale made by the registered dealer and the sale price
of the goods shall be deemed to be their fair market value.
CHAPTER IV

REGISTRATION AND SECURITY
Mandatory and
voluntary
registration.

18. (1) Every dealer is required to apply for registration under this Regulation if—
(a) the dealer's turnover in the year preceding the commencement exceeded the
taxable quantum; or
(b) the dealer's turnover in the current year exceeds the taxable quantum; or
(c) the dealer is liable to pay tax, or is registered or required to be registered
under the Central Sales Tax Act, 1956:
Provided that a dealer dealing exclusively in goods mentioned in the First Schedule
shall not be required to register.
(2) For the purposes of this Regulation, "taxable quantum" of a dealer shall be two lakh
rupees, or such other amount as may be notified by the Government by notification in the
Official Gazette:
Provided that a dealer who imports for sale any goods into Lakshadweep, the taxable
quantum shall be "Nil" or such other amount as may be notified by the Government.
(3) The taxable quantum of a dealer shall not include turnover from—
(a) the sales of capital assets;
(b) the sales made in the course of winding up the dealer's activities; and
(c) sales made as part of the permanent diminution of the dealer's activities.

74 of 1956.

<!-- page 18 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

17

(4) Any person who is not required by sub-section (1) to be registered but who—
(a) is a dealer; or
(b) intends from a particular date to undertake activities which would make him
a dealer,
may apply for registration.
19. (1) An application for registration shall be made in such form, within such time,
containing such particulars and information and accompanied by such fee, security and
other documents as may be prescribed.

Registration.

(2) Where—
(a) an applicant furnishes a security in the prescribed form and for the prescribed
amount; and
(b) all other forms and evidence required by and prescribed under this Regulation
are complete and in order,
the Commissioner shall register the applicant.
(3) Where the Commissioner has not registered the person within fifteen days from the
date on which the application is made, the Commissioner shall, after conducting such inquiries
as he deems fit, either—
(a) register the person forthwith as a registered dealer; or
(b) issue a notice to the applicant, clearly stating the grounds on which his
application is proposed to be rejected and permitting him to show cause in writing,
within fifteen further days, why his application should not be rejected:
Provided that where the Commissioner has not registered the person or issued a notice
by the required date, the applicant shall be deemed to be registered for the purposes, and the
Commissioner shall issue a certificate of registration to such person.
(4) Where, pursuant to clause (b) of sub-section (3), the applicant furnishes a reply to
the notice, the Commissioner may, either accept the application and register the person, or
reject the application for reasons to be recorded in writing.
(5) If the applicant fails to respond to the notice issued under clause (b) of subsection (3) within the stipulated time, the application for registration shall stand rejected.
(6) Where a registered dealer has furnished a security as a condition of registration,
such security shall be required for the continuance in effect of registration, unless otherwise
provided by the Commissioner.
20. (1) If at the time at which an unregistered dealer's registration takes effect after the
commencement and—
(a) the dealer holds trading stock for the purpose of sale, or for use as raw
materials for the production of finished goods;
(b) the dealer has borne input tax on the purchase of the trading stock or raw
materials;
(c) the dealer furnishes a statement of its trading stock and raw materials in the
prescribed form to the Commissioner; and
(d) the dealer holds adequate proof of the amount of input tax in respect of the
purchases,
the dealer shall be entitled to a tax credit for the trading stock or raw materials held by the
dealer on the date that the dealer's registration takes effect:
Provided that the dealer must claim the entire amount of tax credit to which he is
entitled in a single claim, which accompanies the first return furnished by the dealer under
this Regulation.

Effect of
registration.

<!-- page 19 -->

18

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(2) For the purposes of sub-section (3) of section 9, the amount of the tax credit shall
be the least of—
(a) the amount of input tax disclosed in the proof referred to in clause (d) of
sub-section (1);
(b) the tax fraction of the cost of the goods; or
(c) the tax fraction of the fair market value of the goods at the time of
registration; or
(d) such amount as may be prescribed.
(3) Where the registered dealer accounts for turnover on the basis of amounts received
and amounts paid, he shall exclude from his turnover—
(a) any amount received after he is registered in respect of sales made while he
was unregistered; and
(b) any amount paid after he is registered in respect of purchases made while he
was unregistered.
Amendment of
registration.

21. (1) A registered dealer shall inform the Commissioner in the prescribed manner
within one month, if he—
(a) sells or otherwise disposes of his business or any part of his business or any
place of business, or effects or comes to know of any other change in the ownership of
the business; or
(b) discontinues his business or changes his place of business or warehouse, or
opens a new place of business, or closes the business for a period of more than one
month; or
(c) changes the name, style, constitution or nature of his business; or
(d) enters into partnership or other association in regard to his business or adds,
deletes or changes the particulars of the persons having interest in business; and if
any such registered dealer dies, his legal representative shall, in like manner, inform the
said authority.
(2) The Commissioner may, after considering any information furnished under this
Regulation or otherwise received and after making such inquiry as he may deem fit, amend
from time to time any registration.
(3) An amendment of the registration made under sub-section (2) shall take effect from
the date of contingency which necessitates the amendment whether or not information in
that behalf is furnished within the time prescribed under sub-section (1).
(4) Any amendment of a registration under this section shall be without prejudice to
any liability for tax or penalty imposable or for any prosecution for an offence under this
Regulation.
(5) For the removal of doubts, it is hereby clarified that where a registered dealer—
(a) effects a change to the nature of the goods ordinarily sold;
(b) is a firm and there is a change in the constitution of the firm without dissolution
thereof; or
(c) is a trustee of a trust and there is a change in the trustees thereof; or
(d) is a firm or a company or a trust or other organisation, and a change occurs in
the management of the organisation,
then, merely by reason of the circumstances aforesaid, it shall not be necessary for the
registered dealer to apply for a fresh certificate of registration and on information being
furnished the registration shall be amended.

<!-- page 20 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

19

22. (1) Where—
(a) a registered dealer who is required to furnish security under the provisions
has failed to furnish or maintain such security;
(b) a registered dealer has ceased to carry on any activity which would entitle
him to be registered as a dealer under the provisions of this Regulation;
(c) an incorporated body is closed down or otherwise ceases to exist;
(d) the owner of a proprietorship business dies leaving no successor to carry on
the business;
(e) in the case of a firm or association of persons, it is dissolved;
(f) a registered dealer has ceased to be liable to pay tax under this Regulation;
(g) a registered dealer knowingly furnishes a return which is misleading or
deceptive in a material particular; or
(h) a registered dealer has committed one or more offences or contravened the
provisions of this Regulation and the offence or contravention is, in the opinion of the
Commissioner, of such magnitude that it is necessary to do so,
the Commissioner may, after conducting proper inquiries and after service of a notice in the
prescribed form and after providing the dealer an opportunity of being heard, cancel the
registration of the dealer with effect from the date specified by him in the notice.
(2) Where—
(a) a registered dealer has ceased to carry on any activity which would entitle
him to be registered as a dealer under this Regulation;
(b) an incorporated body is closed down or otherwise ceases to exist;
(c) the owner of a proprietorship business dies leaving no successor to carry on
business;
(d) in the case of a firm or association of persons, it is dissolved; or
(e) a registered dealer has ceased to be liable to pay tax under this Regulation,
the registered dealer or the dealer's legal representative in case of clause (c), shall apply for
cancellation of his registration to the Commissioner in the manner and within the time
prescribed.
(3) On receipt of such application, if the Commissioner is satisfied that the dealer has
ceased to be entitled to be registered, he may cancel the registration with effect from a
specified date.
(4) If a dealer's registration which has been cancelled under this section is reinstated
as a result of an appeal or other proceeding under this Regulation, the registration of the
dealer shall be restored and he shall be liable to pay tax as if his registration had never been
cancelled.
(5) If any registered dealer whose registration has been restored under sub-section (4)
satisfies the Commissioner that excess tax has been paid by him during the period his
registration was inoperative which but for the cancellation of his registration he would not
have paid, then the amount of such tax shall be adjusted or refunded to the dealer in such
manner as may be prescribed.
(6) Every registered dealer who applies for cancellation of his registration shall surrender
with his application the certificate of registration granted to him and every registered dealer
whose registration is cancelled otherwise than on the basis of his application shall surrender
the certificate of registration within seven days of the date of communication to him of the
cancellation.

Cancellation
of registration.

<!-- page 21 -->

20

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(7) The Commissioner shall, at intervals not exceeding three months, host on the
departmental website, such particulars as may be prescribed, of registered dealers whose
registration has been cancelled.
(8) The cancellation of registration shall not affect the liability of any person to pay tax
due for any period and unpaid as on the date of such cancellation or which is assessed
thereafter notwithstanding that he is not otherwise liable to pay tax under this Regulation.
Effect of
de-registration.

23. (1) Every registered dealer whose registration is cancelled shall pay in respect of all
goods held on the date of cancellation an amount equal to the higher of—
(a) the tax that would be payable in respect of those goods if the goods were
sold at their fair market value on that date; or
(b) the tax credit previously claimed in respect of those goods.
(2) Where the dealer has accounted for turnover on the basis of amounts received and
amounts paid, he shall include in the turnover of his final return—
(a) any amount not yet received in respect of sales made while he was
registered; and
(b) any amount not yet paid in respect of purchases made while he was registered.

Regisatration
during
transition.

24. Every dealer who is dealing in goods listed in the First Schedule shall register
under the provisions of the Central Sales Tax Act, 1975 and the rate of tax with respect to
such goods shall be such as mentioned in the third column of the First Schedule.

Security from
certain classes
of dealers and
other persons.

25. (1) The Commissioner may, if it appears to him to be necessary so to do, for the
continuance of the certificate of registration, or for the proper realisation of tax, composition
money or other dues payable under this Regulation or as a condition of registering a person
as a dealer or as a condition of making a refund under section 38, or as a condition of desealing or release under sub-section (4) of section 60, require a person or such class of
persons as may be prescribed to furnish security for the proper performance of their
responsibilities under this Regulation or under the Central Sales Tax Act, 1956 on payment of
such amount in such manner and in such time as may be prescribed.
(2) Notwithstanding anything contained in sub-section (1), the Commissioner may
increase, vary, reduce or waive the amount of the security, having regard to—
(a) the nature and size of the business activities of the person;
(b) the amount of any tax, interest or penalty for which the person may be or is
likely to become liable at any time under this Regulation;
(c) the credit worthiness of the person;
(d) the nature of the security; and
(e) any other matter which the Commissioner considers relevant.
(3) Where the security furnished by a person is in the form of a surety bond and the
surety dies or becomes insolvent, the person shall within one month of the occurrence of
such event, inform the Commissioner and shall within three months of such occurrence,
execute a fresh surety bond.
(4) Where the surety bond has been executed by another registered dealer and the
dealer's registration is either cancelled or he has closed down his business, the person shall
furnish a fresh security as may be prescribed and in the manner as stated in sub-section (3).
(5) The Commissioner may, for good and sufficient cause, order the forfeiture of the
whole or any part of the security furnished by a person.
(6) Where the security furnished by any person is forfeited in whole or is rendered
insufficient, he shall furnish a fresh security of the requisite amount or, as the case may be,
shall make up the deficiency in such manner and within such period as may be specified.

43 of 1975.

74 of 1956.

<!-- page 22 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

21

CHAPTER V
RETURNS
26. Every registered dealer who is liable to pay tax under this Regulation shall furnish
to the Commissioner such returns for each tax period and by such dates and in such form and
manner as may be prescribed.

Periodical
payment of
tax and
furnishing of
returns.

27. In addition to the returns specified in section 26, the Commissioner may require
any person, whether a registered dealer or not, to furnish (whether on that person's own
behalf or as an agent or trustee) him with such other returns in such form as may be prescribed.

Power to
require other
returns.

28. If a person discovers a discrepancy in a return furnished by him for a tax period
under this Regulation, he shall remove such discrepancy and furnish a revised return within
the year following the year of such tax period:

Correction of
deficiencies.

Provided that if, as a result of the discrepancy, the person has paid less tax than was
due under this Regulation, he shall, pay the tax owed and interest thereon.
29. Every return under this Chapter shall be signed and verified—

Signing
returns.

(a) in the case of an individual, by the individual himself, and where the individual
is absent from India, by some person duly authorised by him in this behalf and where
the individual is mentally incapacitated from attending to his affairs, by his guardian or
by any other person competent to act on his behalf;
(b) in the case of a company or local authority, by the principal officer thereof;
(c) in the case of a firm, by any partner thereof, not being a minor;
(d) in the case of any other association, by any member of the association or
persons;
(e) in the case of a trust, by the trustee or any trustee; and
(f) in the case of any other person, by some person competent to act on his
behalf.
CHAPTER VI
ASSESSMENT AND PAYMENT OF TAX, INTEREST AND PENALTIES AND MAKING REFUNDS
30. No payment may be made by the Commissioner for the claim by a person of an
amount of tax, interest or penalty or other amount in the nature of tax, interest or penalty due
under this Regulation except by making an assessment for the amount.

Assessment of
tax, interest
or penalty.

31. (1) Where a return is furnished by a person as required under section 26 or
section 27 and contains such information as may be prescribed and complies with the
requirements of this Regulation and the rules—

Self
assessment.

(a) the Commissioner is taken to have made, on the day on which the return is
furnished, an assessment of the tax payable of the amount specified in the return;
(b) the return is deemed to be a notice of the assessment and to be under the
hand of the Commissioner; and
(c) the notice referred to in clause (b) is deemed to have been served on the
person on the day on which the Commissioner is deemed to have made the assessment.
(2) No assessment shall arise under sub-section (1), if the Commissioner has already
made an assessment of tax in respect of the same tax period under any other provision of this
Regulation.

<!-- page 23 -->

22
Default
assessment of
tax payable.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

32. (1) If any person—
(a) has not furnished returns by the date required under section 26 of this
Regulation;
(b) has furnished incomplete or incorrect returns;
(c) has furnished a return which does not comply with the requirements of this
Regulation; or
(d) for any other reason the Commissioner is not satisfied with the return
furnished by a person,
the Commissioner may, for reasons to be recorded in writing, assess or re-assess the amount
of net tax due for a tax period or more than one tax period by a single order so long as all such
tax periods are comprised in one year.
(2) If the Commissioner, upon the information which has come into his possession, is
satisfied that any person who has been liable to pay tax under this Regulation in respect of
any period, has failed to get himself registered, the Commissioner may, for reasons to be
recorded in writing, assess the amount of net tax due for such period and all subsequent
periods and serve on that person a notice of assessment of the amount of any additional tax
due for that tax period.
(3) Where the Commissioner has made an assessment under this section and further
tax is assessed as owed, the amount of further tax assessed is due and payable on the same
date as the date on which the net tax for the tax period was due.

Assessment of
penalty.

33. (1) Where the Commissioner has reason to believe that a person is liable to pay a
penalty under this Regulation, he, after recording the reason in writing, shall make and serve
on such person a notice of assessment of the penalty that is due under this Regulation.
(2) The amount of any penalty assessed under this section is due and payable on the
date on which the notice of assessment is served by the Commissioner.
(3) Any assessment made under this section shall be without prejudice to prosecution
for any offence under this Regulation.

Limitation on
assessment and
re-assessment.

34. (1) No assessment or re-assessment shall be made by the Commissioner after the
expiry of four years from—
(a) the end of the year comprising of one or more tax periods for which the
person furnished a return under section 26 or section 27; or
(b) the date on which the Commissioner made an assessment of tax for the tax
period, whichever is the earlier:
Provided that where the Commissioner has reason to believe that tax was not paid by
reason of concealment, omission or failure to disclose fully material particulars on the part of
the person, the said period shall stand extended to six years.
(2) Notwithstanding anything contained in sub-section (1), the Commissioner may
make an assessment of tax within one year after the date of any decision of the Appellate
Tribunal or court where the assessment is required to be made in consequence of, or to give
effect to, the decision of the Appellate Tribunal or court which requires the re-assessment of
the person.

Collection of
assessed tax
and penalties.

35. (1) Subject to provisions of sub-sections (2) and (4), where an amount of tax or
penalty has been assessed under section 32 or section 33, the Commissioner may not proceed
to enforce payment of the amount assessed until two months after the date of service of the
notice of assessment.

<!-- page 24 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

23

(2) Where a person has made an objection to an assessment or part of an assessment
and has complied with the condition, if any, to entertain such objection in the manner
provided in section 74, the Commissioner may not enforce the payment of balance amount in
dispute under that assessment until the objection is resolved by the Commissioner.
(3) Nothing contained in this section shall stay any proceedings by the Commissioner
or before a court for the recovery of—
(a) any amounts due under this Regulation that are not the subject of a dispute
before the Commissioner; or
(b) any amounts due under this Regulation where the person has made an
appeal to the Appellate Tribunal.
(4) Notwithstanding anything contained in sub-section (1), where an amount of tax or
penalty has been assessed by the Commissioner and he is satisfied that there is a likelihood
that it may not be possible to recover the amount assessed if collection is delayed, the
Commissioner may specify a date in the notice of assessment as the date on which collection
of the amounts due and payable may commence which is earlier than two months after the
date of service of the notice of assessment.
36. Every person liable to pay tax, interest, penalty or any other amount under this
Regulation shall pay the amount to a branch in Lakshadweep of a bank prescribed under the
rules, or at such other place or in such other manner as may be prescribed.

Manner of
payment of
tax, penalties
and interest.

37. Where a person owes to the Commissioner tax, interest, or penalty and the person
pays to the Commissioner or the Commissioner recovers some but not all of the amounts
owed by the person, the amounts shall be treated as reducing the person's obligations to
pay—

Order of
application of
payments.

(a) interest, penalty and tax owed under this Regulation; and
74 of 1956.

(b) interest, penalty and tax owed under the Central Sales Tax Act, 1956, in the
above order.
38. (1) Subject to the other provisions of this Regulation and the rules, the
Commissioner shall refund to a person the amount of tax, penalty and interest, if any, paid by
such person in excess of the amount due from him.

74 of 1956.

(2) Before making any refund, the Commissioner shall first apply such excess towards
the recovery of any other amount due under this Regulation, or under the Central Sales Tax
Act, 1956.
(3) Subject to the provisions of sub-section (4) and sub-section (5), any amount
remaining after the application referred to in sub-section (2) shall be at the election of the
dealer, either—
(a) refunded to the person,—
(i) within one month after the date on which the return was furnished or
claim for the refund was made, if the tax period for the person claiming refund is
one month; or
(ii) within two months after the date on which the return was furnished or
claim for the refund was made, if the tax period for the person claiming refund is
a quarter; or
(b) carried forward to the next tax period as a tax credit in that period.
(4) Where the Commissioner has issued a notice to the person under section 58
advising him that an audit, investigation or inquiry into his business affairs shall be undertaken
or sought additional information under section 59 of this Regulation, the amount shall be
carried forward to the next tax period as a tax credit in that period.

Refunds.

<!-- page 25 -->

24

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(5) The Commissioner may, as a condition of the payment of a refund, demand security
from the person pursuant to the powers conferred in section 25 within fifteen days from the
date on which the return was furnished or claim for the refund was made.
(6) The Commissioner shall grant refund within fifteen days from the date the dealer
furnishes the security to his satisfaction under sub-section (5).
(7) For calculating the period prescribed in clause (a) of sub-section (3), the time taken
to—
(a) furnish the security under sub-section (5) to the satisfaction of the
Commissioner; or
(b) furnish the additional information sought under section 59; or
(c) furnish returns under section 26 and section 27; or
(d) furnish the declaration or certificate forms as required under the Central
Sales Tax Act, 1956, shall be excluded.
(8) Notwithstanding anything contained in this section, where—
(a) a registered dealer has sold goods to an unregistered person;
(b) the price charged for the goods includes an amount of tax payable under this
Regulation; and
(c) the dealer is seeking the refund of this amount or to apply this amount under
clause (b) of sub-section (3),
no amount shall be refunded to the dealer or may be applied by the dealer under clause (b) of
sub-section (3) unless the Commissioner is satisfied that the dealer has refunded the amount
to the purchaser.
(9) Where—
(a) a registered dealer has sold goods to another registered dealer; and
(b) the price charged for the goods expressly includes an amount of tax payable
under this Regulation,
the amount may be refunded to the seller or may be applied by the seller under clause (b) of
sub-section (3) and the Commissioner may reassess the buyer to deny the amount of the
corresponding tax credit claimed by such buyer, whether or not the seller refunds the amount
to the buyer.
(10) Where a registered dealer sells goods and the price charged for the goods is
expressed not to include an amount of tax payable under this Regulation the amount may be
refunded to the seller or may be applied by the seller under clause (b) of sub-section (3)
without the seller being required to refund an amount to the purchaser.
(11) Notwithstanding anything to the contrary contained in sub-section (3), no refund
shall be allowed to a dealer who has not filed any return due under this Regulation.
Power to
withhold
refund in
certain cases.

39. (1) Where a person is entitled to a refund and any proceeding under this Regulation,
including an audit under section 58, is pending against him, and the Commissioner is of the
opinion that payment of such refund is likely to adversely affect the revenue and that it may
not be possible to recover the amount later, the Commissioner may for reasons to be recorded
in writing, either obtain a security equal to the amount to be refunded to the person or
withhold the refund till such time the proceeding or the audit has been concluded.
(2) Where a refund is withheld under sub-section (1), the person shall be entitled to
interest as provided under sub-section (1) of section 42 if as a result of the appeal or further
proceeding, or any other proceeding he becomes entitled to the refund.

74 of 1956.

<!-- page 26 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

25

40. (1) No person who is not a registered dealer shall collect in respect of any sale of
goods by him in Lakshadweep any amount by way of tax under this Regulation and no
registered dealer shall make any such collection except in accordance with this Regulation
and the rules made thereunder and at the rates specified under this Regulation.

Collection of
tax only by
registered
dealers.

(2) The tax collected by a person who is not a registered dealer shall not be refunded
and shall stand forfeited.
41. (1) The bodies listed in the Fourth Schedule shall be entitled to claim a refund of tax
paid on goods purchased in Lakshadweep, subject to such restrictions and conditions as
may be prescribed.
(2) Any person entitled to a refund under sub-section (1) may apply to the Commissioner
in the manner and within the time prescribed.
42. (1) A person entitled to a refund under this Regulation, shall be entitled to receive,
in addition to the refund, simple interest at the annual rate notified by the Government from
time to time, computed on a daily basis from—

Refund of tax
for embassies,
officials,
international
and public
organisations.
Interest.

(a) the date that the refund was due to be paid to the person; or
(b) the date that the overpaid amount was paid by the person,
whichever is later, and such interest shall be calculated upon the date on which the refund is
given:
Provided that the interest shall be calculated on the amount of refund due after deducting
therefrom any tax, interest, penalty or any other dues under this Regulation:
Provided further that if the amount of such refund is enhanced or reduced, as the case
may be, such interest shall be enhanced or reduced accordingly.
(2) When a person is in default in making the payment of any tax, penalty or other
amount due under this Regulation, he shall, in addition to the amount assessed, be liable to
pay simple interest on such amount at the annual rate notified by the Government from time
to time, computed on a daily basis, from the date of such default for so long as he continues
to make default in the payment of the said amount.
(3) Where the amount of tax including any penalty due is wholly reduced, the amount
of interest, if any, paid shall be refunded, or if such amount is varied, the interest due shall be
calculated accordingly.
(4) Where the collection of any amount is stayed by the order of the Appellate Tribunal
or any court or any other authority and the order is subsequently vacated, interest shall be
payable for any period during which such order remained in operation.
(5) The interest payable by a person under this Regulation may be collected as tax due
under this Regulation and shall be due and payable once the obligation to pay interest has
arisen.
CHAPTER VII
RECOVERY OF TAX, INTEREST AND PENALTIES
43. (1) The amount of any tax, interest, penalty or other amount due under this
Regulation shall be paid in the manner specified in section 36 and a notice of assessment
served on the person for such an amount shall constitute a demand for payment of the
amount stated in the assessment by the time stipulated in the notice of assessment.
(2) On an application made before the expiry of the due date specified under
section 35, the Commissioner may, in respect of any dealer or person and for reasons to be
recorded in writing, extend the time for payment or allow payment by instalments, subject to
such conditions as he may think fit to impose in the circumstances of the case.

Recovery of
tax.

<!-- page 27 -->

26

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(3) Any amount of tax, interest or penalty, composition money or other amount due
under this Regulation which remains unpaid, shall be recoverable—
(a) as arrears of land revenue, or
(b) by the Commissioner in accordance with the provisions of sub-section (6)
and the rules regulating the procedure of recovery of tax, interest or penalty, composition
money or other amount due as may be prescribed.
(4) Where security, other than in the form of surety bond, has been furnished under
the Regulation, the Commissioner may, for reasons to be recorded in writing, recover any
amount of tax, interest, penalty, composition money or other amount due or part thereof by
ordering the forfeiture of the whole or any part of the security.
(5) Where any security tendered for the purposes is to be sold, it shall be sold in the
manner stipulated in section 63.
(6) Where any amount of tax, interest or penalty, composition money or other amount
due under this Regulation is recoverable in accordance with the provisions of clause (b) of
sub-section (3), the Commissioner may prepare a recovery certificate (hereafter in this Chapter
referred to as "certificate") under his signature specifying the amount of such tax, interest or
penalty, composition money or other amount due from the dealer, casual dealer, transporter,
carrier or transporting agent, owner or lessee or occupier of warehouse, owner of any goods
or any other person (hereafter in this Chapter referred to as the "certificate-debtor") and he
shall cause the said certificate to be served upon the certificate-debtor, in such manner and
form as may be prescribed and proceed to recover from the certificate-debtor the amount
specified in the certificate by one or more of the following modes in accordance with the rules
as may be prescribed—
(a) attachment and sale of movable property of the certificate-debtor;
(b) attachment and sale of immovable property of the certificate-debtor;
(c) arrest of the certificate-debtor and his detention in prison for a period of
fifteen days;
(d) appointing a receiver for the management of the movable and immovable
properties of the certificate-debtor.
(7) The Commissioner may serve upon the defaulter the recovery certificate under
sub-section (6), notwithstanding that proceedings for recovery of such tax, interest or penalty,
composition money or other amount due have been initiated or continuing by any other
mode.
(8) On the service of the certificate under sub-section (6) upon a certificate-debtor—
(a) any private transfer or delivery of any of his immovable property or of any
interest in any such property, shall be void against any claim enforceable in the execution
of the certificate; and
(b) the amount due from time to time in respect of the certificate shall be a charge
upon the immovable property of the certificate-debtor, to which every other charge
created subsequently to the service of the said certificate shall be postponed.
(9) The certificate-debtor may, within thirty days from the service of the certificate,
present to the Commissioner a petition denying his liability in whole or in part.
(10) The Commissioner shall hear the petition, take evidence, if necessary, and determine
whether the certificate-debtor is liable for the whole or any part of the amount for which
certificate was signed.
(11) Where any proceedings for the recovery of any tax, interest or penalty, composition
money or other amount due remaining unpaid have been commenced under this section and

<!-- page 28 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

27

the tax, interest or penalty, composition money or other amount due is subsequently modified,
enhanced or reduced in consequence of any assessment made, or order passed on objection,
appeal, revision or review under this Regulation, the Commissioner may inform the
certificate-debtor and thereupon such proceedings may be continued as if the tax, interest or
penalty, composition money or other amount due as so modified, enhanced or reduced has
been substituted for the tax, interest or penalty, composition money or other amount due
which was to be recovered under sub-section (3).

Reg. 6 of
1965.

1 of 1890.

44. (1) For the purposes of recovery of any amount recoverable as arrears of land
revenue under this Regulation, the provisions of the Lacadive, Minicoy and Amindivi Islands
Land Revenue and Tenancy Regulation, 1965, as to the recovery of arrears of land revenue
shall, notwithstanding anything contained in that Regulation or in any other enactment, be
deemed to be in force throughout the Lakshadweep and the provisions of the Revenue
Recovery Act, 1890 shall have effect accordingly.
(2) For the purposes of sub-section (1)—

Reg. 6 of
1965.

(a) the Additional Commissioner of Value Added Tax and the Joint Commissioner
of Value Added Tax shall have and exercise all the powers and perform all the duties of
the Deputy Commissioner under the Lacadive, Minicoy and Amindivi Islands Land
Revenue and Tenancy Regulation, 1965;

Application of
Lacadive,
Minicoy and
Amindivi
Islands Land
Revenue and
Tenancy
Regulation,
1965 for
purposes of
recovery.

(b) the Deputy Commissioner of Value Added Tax and the Assistant Commissioner
of Value Added Tax shall have and exercise all the powers and perform all the duties of
Assistant Commissioner or Assistant Commissioner (Settlement) under the said
Regulation;
(c) the Value Added Tax Officers and the Assistant Value Added Tax Officers
shall have and exercise all the powers and perform all the duties of Tehsildar under the
said Regulation.
45. Where an assessment or notice of demand in respect of any tax, penalty or other
amount payable under this Regulation (hereafter in this section referred to as " Government
dues") is served upon any person and any objection or appeal is initiated by the person
against the assessment or demand for such Government dues then—
(a) if the objection or appeal is disallowed in whole or in part, any recovery
proceedings taken for the recovery of such Government dues before the making of the
objection or appeal, may, without the service of any fresh assessment or notice of
demand, be continued from the stage at which such recovery proceedings stood
immediately before the person who made the objection or appeal;
(b) where such Government dues are reduced in any objection or appeal—
(i) it shall not be necessary for the Commissioner to serve upon the person
a fresh assessment or notice of demand;
(ii) the Commissioner shall give intimation of such reduction to him and
to the person with whom recovery proceedings are pending; and
(iii) any recovery proceedings initiated on the basis of an assessment or
notice of demand served upon a person before the disposal of such objection or
appeal, may be continued in relation to the amount so reduced from the stage at
which such proceedings stood immediately before the person who made the
objection or appeal; and
(c) no recovery proceedings in relation to such Government dues shall be invalid
by reason only that no fresh notice of demand was served upon the dealer or person
after the disposal of such objection or appeal or such Government dues have been
enhanced or reduced in such objection or appeal.

Continuation
of certain
recovery
proceedings.

<!-- page 29 -->

28
Special mode
of recovery.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

46. (1) Notwithstanding anything contained in any law for the time being in force or
contract to the contrary, the Commissioner may, at any time or from time to time, by notice
in writing, a copy of which shall be forwarded to the person at his last known address,
require,—
(a) any person from whom any amount of money is due, or may become due, to
the person (in this section called "the taxpayer") liable to pay tax, interest or penalties
under section 45; or
(b) any person who holds or may subsequently hold money for or on account of
the taxpayer, to pay to the Commissioner, either forthwith upon the money becoming
due or being held or within the time specified in the first mentioned notice (but not
before the money becomes due or is held as aforesaid) so much of the money as is
sufficient to pay the amount due by the taxpayer in respect of the arrears of tax, interest
and penalty under this Regulation, or the whole of the money when it is equal to or less
than that amount.
(2) The Commissioner may amend or revoke any such notice or extend the time for
making any payment in pursuance of the notice.
(3) Any person making any payment in compliance with a notice under this section
shall be deemed to have made the payment under the authority of the taxpayer, and the
receipt thereof by the Commissioner shall constitute a good and sufficient discharge of the
liability of such person to the extent of the amount specified in the receipt.
(4) Any person discharging any liability to the taxpayer after receipt of the notice
referred to in this section, shall be personally liable to the Commissioner to the extent of the
liability discharged or to the extent of the liability of the dealer for tax and penalty, whichever
is less.
(5) Where a person to whom a notice under this section is sent, proves to the satisfaction
of the Commissioner that the sum demanded or any part thereof is not due to the taxpayer or
that he does not hold any money for or on account of the taxpayer, then, nothing contained
in this section shall be deemed to require such person to pay any such sum or part thereof,
as the case may be, to the Commissioner.
(6) Any amount of money which the aforesaid person is required to pay to the
Commissioner, or for which he is personally liable to the Commissioner under this section
shall, if it remains unpaid, be recoverable as if arrears of land revenue.
(7) The Commissioner may apply to the court in whose custody there is money belonging
to the taxpayer for payment to him of the entire amount of such money or if it is more than the
tax, interest and penalty, if any, due, an amount sufficient to discharge such tax and the
penalty.
(8) Where, during the course of inquiry of any proceeding including any proceeding
for recovery of any amount due in respect of any person or dealer or during any inspection
or search in relation to the business of any person or dealer under this Regulation, the
Commissioner is of the opinion that for the purpose of protecting the interest of the revenue
it is necessary so to do, he may, notwithstanding anything contained in any law for the time
being in force or any contract to the contrary, by order in writing, attach provisionally any
property movable or immovable, belonging to such person or dealer.
(9) Every provisional attachment referred to in sub-section (8) shall cease to have
effect after the expiry of a period of six months from the date of the order made under
sub-section (1):
Provided that the Commissioner may, for reasons to be recorded in writing, extend the
aforesaid period by such further period or periods as he thinks fit, so, however, that the total
period of extension shall not in any case exceed two years:

<!-- page 30 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

29

Provided further that the Commissioner may, by an order, revoke such order if the
person or the dealer furnishes to the Commissioner, a Bank Guarantee in such time, for such
period as may be specified by the Commissioner in this behalf:
Provided also that the power under this section shall be exercised by the Commissioner
himself or by the Additional Commissioner to whom the Commissioner has delegated such
power.
47. Where, during the pendency of any proceedings for the recovery of an amount
owed by a person under this Regulation, that person creates a charge on or parts with the
possession by way of sale, mortgage, gift or exchange or any other mode of transfer
whatsoever, any of his assets in favour of any other person, such charge or transfer shall be
void against any claim by the Commissioner in respect of the amount which is the subject of
proceedings, unless the other person—

Transfer of
assets during
pendency of
proceedings
void.

(a) acted bona fide and without notice of the recovery proceedings; and
(b) has paid the fair market value for the assets.
CHAPTER VIII
ACCOUNTS AND RECORDS
48. (1) Every dealer or person, on whom a notice has been served to furnish returns
under section 27, shall prepare, maintain and retain sufficient records at the principal place of
business as recorded in his certificate of registration to allow the Commissioner to readily
ascertain the amount of tax due under this Regulation, and to explain all transactions, events
and other acts engaged in by the person that are relevant for any purpose:
Provided that the dealer maintaining computerised books of account using a software
should be able to readily provide soft or hard copy of the records at the principal place of
business as recorded in his certificate of registration, as and when required by the
Commissioner.
(2) Notwithstanding anything contained in sub-section (1)—
(a) every registered dealer shall preserve a copy of all tax invoices issued by
him;
(b) every dealer shall preserve the original of all tax invoices received by him; and
(c) every person who has paid an amount of tax, interest, penalty or other amount
owed under this Regulation, shall preserve a copy of the challan which shall be a
documentary evidence that the amount has been paid.
(3) The Commissioner may prescribe the manner and form in which accounts and
records are to be prepared.
(4) If the Commissioner considers that such records are not sufficiently clear and
intelligible to enable him to make a proper check of the obligations required of the person
under this Regulation, he may require such person by notice in writing to keep such accounts
(including records of purchase and sales) as may be specified therein.
(5) The Commissioner may, by notification in the Official Gazette, direct any class of
dealers, transporters or operators of warehouses to keep such accounts (including records
of purchases and sales) as may be specified in the notification.
(6) Every person required to prepare or preserve records and accounts shall retain the
required records and accounts for, at least, seven years after the conclusion of the events or
transactions which they record unless any proceedings in respect of that year are pending in
which case they shall be preserved till the final decision in those proceedings. Any loss
thereof shall be reported to the Police and the Commissioner within a period of fifteen days
from the date of occurrence.

Records and
accounts.

<!-- page 31 -->

30

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

Accounts to
be audited in
certain cases.

49. If, in respect of any particular year, the gross turnover of a dealer exceeds sixty lakh
rupees or such other amount as may be prescribed, then, such dealer shall submit a report in
such manner, form and period as may be notified by the Commissioner.

Tax invoices.

50. (1) A registered dealer making a sale liable to tax under this Regulation shall, at the
request of the purchaser, provide the purchaser at the time of sale with a tax invoice containing
the particulars specified in sub-section (2) and retain a copy thereof:
Provided that a tax invoice shall not be issued by a dealer who—
(a) elects to pay tax under section 16; or
(b) is making the sale in the course of inter-State trade or commerce or export:
Provided further that not more than one tax invoice shall be issued for each sale:
Provided also that if an invoice has been issued under the provisions of the Central
Excise Act, 1944, it shall be deemed to be a tax invoice if it contains the particulars specified
in sub-section (2).
(2) The tax invoice issued under sub-section (1) shall contain the following particulars
on the original as well as copies thereof—
(a) the words "tax invoice" in a prominent place;
(b) the name, address and registration number of the selling registered dealer;
(c) the name and address of the purchaser and his registration number, where the
purchaser is a registered dealer;
(d) an individual pre-printed serialised number and the date on which the tax
invoice is issued:
Provided that a dealer may maintain separate numerical series, with distinct
codes either, as a prefix or suffix, for each place of business in case the dealer has more
than one place of business in Lakshadweep or for each product in case he deals in
more than one product or both:
Provided further that such numerical series may be granted by the Commissioner,
in such manner and from such date as may be notified by him;
(e) description, quantity, volume and value of goods sold and services provided
and the amount of tax charged thereon indicated separately;
(f) the signature of the selling dealer or his servant, manager or agent, duly
authorised by him; and
(g) the name and address of the printer and first and last serial number of tax
invoices printed and supplied by him to the dealer.
(3) A tax invoice in respect of a sale shall be issued in duplicate, the original shall be
issued to the purchaser (or the person taking the delivery, as the case may be) and the
duplicate shall be retained by the selling dealer.
(4) Except when a tax invoice is issued under sub-section (1), if a dealer sells any
goods exceeding such amount in value as may be prescribed, in any one transaction to any
person, he shall issue to the purchaser a retail invoice containing the particulars specified in
sub-section (5) and retain a copy thereof.
(5) The retail invoice issued under sub-section (4) shall contain the following
particulars on the original as well as copies thereof—
(a) the words "retail invoice" or "cash memorandum" or "bill" in a prominent
place;
(b) the name, address and registration number of the selling dealer, if registered;

1 of 1944.

<!-- page 32 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

31

(c) in case the sale is in the course of inter-State trade or commerce, the name,
registration number and address of the purchasing dealer and type of statutory form,
if any, against which the sale has been made;
(d) an individual pre-printed serialised number and the date on which the retail
invoice is issued:
Provided that a dealer may maintain separate numerical series with distinct codes,
either as prefix or suffix, for each place of business, in case the dealer has more than
one place of business in Lakshadweep or for each product in case he deals in more
than one product or both:
Provided further that such numerical series may be granted by the Commissioner,
in such manner and from such date as may be notified by him;
(e) description, quantity, volume and value of goods sold and services provided
and the amount of tax charged thereon indicated separately; and
(f) the signature of the selling dealer or his servant, manager or agent, duly
authorised by him.
(6) Retail invoice shall be issued in duplicate, the original shall be issued to the purchaser
and the copy shall be retained by the selling dealer.
(7) The Commissioner may, by notification in the Official Gazette, specify the manner
and form in which the particulars on a tax invoice or retail invoice are to be recorded.
(8) If a purchaser claims to have lost the original tax invoice, the selling dealer may,
subject to such conditions and restrictions as may be prescribed, provide a copy clearly
marked as a duplicate.
51. Where a tax invoice has been issued in respect of a sale and—
(a) the amount shown as tax in that tax invoice exceeds the tax payable in respect
of the sale, the dealer shall provide the purchaser with a credit note, containing such
particulars as may be prescribed; or

Credit and
debit notes.

(b) the tax payable in respect of the sale exceeds the amount shown as tax on the
tax invoice,
the dealer shall provide the purchaser with a debit note, containing such particulars as may
be prescribed.
CHAPTER IX
LIABILITY IN SPECIAL CASES
52. (1) Where a dealer liable to pay tax under this Regulation transfers his business in
whole or in part, by sale, gift, lease, leave or license, hire or in any other manner whatsoever,
the dealer and the person to whom the business is so transferred shall jointly and severally
be liable to pay the tax, interest or penalty due from the dealer up to the time of such transfer,
whether such amount has been assessed before such transfer, but has remained unpaid or is
assessed thereafter.

Liability in
case of
transfer of
business.

(2) Where the transferee or the lessee of a business referred to in sub-section (1)
carries on such business either in his own name or in some other name, he shall be liable to
pay tax on the sale of goods effected by him with effect from the date of such transfer and
shall, if he is registered as a dealer, apply within the time specified in section 21 for the
amendment of his registration.
53. (1) Every person—
(a) who is a liquidator of any company which is being wound up, whether under
the orders of a court or otherwise; or

Liability in
case of
company in
liquidation.

<!-- page 33 -->

32

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) who has been appointed the receiver of any assets of a company (hereafter
in this section referred to as the "liquidator"),
shall, within one month after he has become such liquidator, give notice of his appointment
as such to the Commissioner.
(2) The Commissioner shall, after making such inquiries or calling for such information
as he may deem fit, notify the liquidator within three months from the date on which he
received notice of the appointment of the liquidator, the amount which, in the opinion of the
Commissioner, would be sufficient to provide for any tax, interest or penalty which is then, or
is likely thereafter, to become payable by the company.
(3) The liquidator shall not part with any of the assets of the company or the properties
in his hand until he has been notified by the Commissioner under sub-section (2) and on
being so notified, the liquidator shall set aside an amount equal to the amount notified and,
until he so sets aside such amount, he shall not part with any of the assets of the company
or the properties in his hand:
Provided that nothing contained in this sub-section shall debar the liquidator from
parting with such assets or properties in compliance with any order of a court or for the
purpose of the payment of the tax and penalty, if any, payable by the company under this
Regulation or for making any payment to secured creditors whose debts are entitled under
law to priority of payments over debts due to Government on the date of liquidation or for
meeting such costs and expenses of the winding up of the company as are in the opinion of
the Commissioner reasonable.
(4) If the liquidator fails to give notice in accordance with sub-section (1) or fails to set
aside the amount as required by sub-section (3) or parts with any assets of the company or
the properties in his hand in contravention of the provisions of that sub-section, he shall
be personally liable for the payment of tax and penalty, if any, which the company would be
liable to pay under this Regulation:
Provided that if the amount of tax and penalty, if any, payable by the company is
notified under sub-section (2) the personal liability of the liquidator under this sub-section
shall be to the extent of such amount.
(5) Where there is more than one liquidator, the obligations and liabilities attached to
a liquidator under this section shall attach to all the liquidators jointly and severally.
(6) When any private company is wound up and any tax and penalty, if any, assessed
under this Regulation on the company for any period, whether before or in the course of or
after its liquidation, cannot be recovered, then every person who was a director of the private
company at any time during the period for which the tax is due, shall be jointly and severally
liable for the payment of such tax and penalty, if any, unless he proves to the satisfaction of
the Commissioner that non-recovery cannot be attributed to any gross neglect, misfeasance
or breach of duty on his part in relation to the affairs of the company.
(7) The provisions of this Regulation shall have effect notwithstanding anything to
the contrary contained in any other law for the time being in force.
(8) For the purposes of this section, the expressions "company" and "private company"
shall have the meanings respectively assigned to them under clauses (20) and (68) of
section 2 of the Companies Act, 2013.
Liability of
partners of
firm to pay
ta x.

54. Notwithstanding any contract to the contrary, where any firm is liable to pay any
tax, interest or penalty under this Regulation, the firm and each of the partners of the firm
shall be jointly and severally liable for such payment:
Provided that where any such partner retires from the firm, he shall intimate the date of
his retirement to the Commissioner by a notice to that effect in writing and he shall be liable

18 of 2013.

<!-- page 34 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

33

to pay tax, interest or penalty remaining unpaid at the time of his retirement and any tax,
interest or penalty due up to the date of his retirement though unassessed on that date:
Provided further that if no such intimation is given within fifteen days from the date of
retirement, the liability of the partner under the first proviso shall continue until the date on
which such intimation is received by the Commissioner.
55. Where the business in respect of which tax is payable under this Regulation is
carried on by, or is in the charge of any guardian, trustee or agent of a minor or other
incapacitated person on his behalf and for the benefit of such minor or other incapacitated
person, the tax, interest or penalty shall be levied upon and recoverable from such guardian,
trustee or agent, as the case may be, in like manner and to the same extent as it would be
assessed upon and recoverable from any such minor or other incapacitated person, if he
were of full age and of sound mind and if he were conducting the business himself, and all
the provisions shall, so far as may be, apply accordingly.

Liability of
guardians,
trustees, etc.

56. Where the estate or any portion of the estate of a dealer owning a business in
respect of which tax is payable under this Regulation is under the control of the Court of
Wards, the Administrator-General, the Official Trustee or any receiver or manager (including
any person, whatever be his designation, who in fact manages the business) appointed by or
under any order of a court, the tax, interest or penalty shall be levied upon and be recoverable
from such Court of Wards, Administrator-General, Official Trustee, receiver or manager in
like manner and to the same extent as it would be assessable upon and be recoverable from
the dealer if he were conducting the business himself, and all the provisions shall, so far as
may be, apply accordingly.

Liability of
Court of
Wards, etc.

57. (1) Where a dealer is a firm or an association of persons or a Hindu Undivided
Family, and such firm, association or family has discontinued business—

Liability in
other cases.

(a) the tax payable under this Regulation, by such firm, association or family up
to the date of such discontinuance may be assessed as if no such discontinuance had
taken place; and
(b) every person who was at the time of such discontinuance a partner of such
firm, or a member of such association or family, shall, notwithstanding such
discontinuance be liable jointly and severally for the payment of tax assessed and
penalty imposed and payable by such firm, association or family, whether such tax,
interest or penalty has been assessed prior to or after such discontinuance, and subject
as aforesaid, the provisions shall, so far as may be, apply as if every such person or
partner or member were himself a dealer:
Provided that where the partner of a firm liable to pay such tax, interest or penalty dies,
the provisions of sub-section (4) shall, so far as may be, apply.
(2) Where a change has occurred in the constitution of a firm or an association of
persons, the partners of the firm or members of the association as it existed before and as it
exists after its reconstitution shall, without prejudice to the provisions of section 54, jointly
and severally be liable to pay tax, interest or penalty due from such firm or association for any
period before its reconstitution.
(3) The provisions of sub-section (1) shall, so far as may be, apply where the dealer,
being a firm or association of persons is dissolved or, being a Hindu Undivided Family, has
effected partition with respect to the business carried on by it and accordingly references in
that sub-section to discontinuance shall be construed as references to dissolution or, as the
case may be, to partition.
(4) Where a dealer liable to pay tax under this Regulation dies, then—
(a) if a business carried on by the dealer is continued after his death by his legal
representative or any other person, such legal representative or other person, shall be
liable to pay the tax, interest or penalty due from the dealer under this Regulation,

<!-- page 35 -->

34

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

whether such tax, interest or penalty had been assessed before his death but has
remained unpaid, or is assessed after his death;
(b) if the business carried on by the dealer is discontinued after his death, his
legal representative shall be liable to pay out of the estate of the deceased, to the
extent the estate is capable of meeting the charge, the tax, interest or penalty due from
the dealer under this Regulation, whether such tax, interest or penalty had been
assessed before his death, but has remained unpaid, or is assessed after his death,
and the provisions shall, so far as may be, apply to such legal representative or other person
as if he were the dealer himself.
CHAPTER X
AUDIT, INVESTIGATION AND ENFORCEMENT
Audit,
investigation
and
enforcement.

58. (1) The Commissioner may serve on any person in the prescribed manner a notice
informing him that an audit of his business affairs shall be performed and where applicable,
that an assessment already concluded under this Regulation may be reopened.
(2) A notice served under sub-section (1) may require the person on whom it is served,
to appear on a date and place specified therein, which may be at his business premises or at
a place specified in the notice, to either attend and produce or cause to be produced the
books of account and all evidence on which the dealer relies in support of his returns
(including tax invoices, if any), or to produce such evidence as is specified in the notice.
(3) The person on whom a notice is served under sub-section (1) shall provide all
co-operation and reasonable assistance to the Commissioner as may be required to conduct
the proceedings under this section at his business premises.
(4) The Commissioner shall, after considering the return, the evidence furnished with
the returns, if any, the evidence acquired in the course of the audit, if any, or any information
otherwise available to him, either—
(a) confirm the assessment under review; or
(b) serve a notice of the assessment or re-assessment of the amount of tax,
interest and penalty if any pursuant to sections 32 and 33.
(5) Any assessment pursuant to an audit of the person's business affairs shall be
without prejudice to prosecution for any offence under this Regulation.
(6) (i) If the Commissioner, having regard to,—
(a) the nature and complexity of the business of a dealer; or
(b) the interest of the revenue; or
(c) volume of accounts; or
(d) doubts about the correctness of the accounts; or
(e) multiplicity of transactions in the accounts; or
(f) specialised nature of business activity; or
(g) non-production of all records and accounts; or
(h) non-filing of audit report under this Regulation; or
(i) any other reason, is of the opinion that it is necessary so to do,
he may direct the dealer by a notice in writing to get his records including books of account,
examined and audited by an accountant or a panel of accountants or any other professional
or panel of professionals nominated by the Commissioner in this behalf and to furnish a
report of such examination and audit in the format that he may specify, duly signed and

<!-- page 36 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

35

verified by such accountant or panel of accountants or professional or panel of professionals
and setting forth such particulars as may be specified;
(ii) The provision of sub-section (1) shall have effect notwithstanding that the accounts
of the dealer have been audited under any other provision or any other law for the time being
in force or otherwise;
(iii) Every report under sub-section (1) shall be furnished by the dealer to the
Commissioner within such period as may be specified by the Commissioner:
Provided that the Commissioner may, on an application made in this behalf by the
dealer and for any good and sufficient reason, extend the said period by such further period
or periods as he thinks fit:
Provided further that the aggregate of the period originally fixed and the period or
periods so extended shall not, in any case, exceed one hundred eighty days from the date on
which the direction under sub-section (1) is received by the dealer;
(iv) The expenses of, and incidental to, the examination and audit of records under
sub-section (1), (including the remuneration of the accountant or a panel of accountants or
professional or panel of professionals) shall be determined and paid by the Commissioner
and that determination shall be final.
59. (1) All records, books of account, registers and other documents, maintained by a
dealer, transporter or operator of a warehouse shall, at all reasonable times, be open to
inspection by the Commissioner.

Inspection of
records.

(2) The Commissioner may, for the proper administration and subject to such conditions
as may be prescribed, require—
(a) any dealer; or
(b) any other person, including a banking company, post office, a person who
transports goods or holds goods in custody for delivery to, or on behalf of any dealer,
who maintains or has in his possession any books of account, registers or documents
relating to the business of a dealer, and, in the case of a person which is an organisation,
any officer thereof, to—
(i) produce before him such records, books of account, registers and other
documents;
(ii) answer such questions; and
(iii) prepare and furnish such additional information,
relating to his activities or to the activities of any other person as the Commissioner may
deem necessary.
(3) The Commissioner may require a person referred to in sub-section (2), to—
(a) prepare and provide any documents; and
(b) verify the answer to any question,
in the manner specified by him.
(4) The Commissioner may retain, remove, take copies or extracts, or cause copies or
extracts to be made of the said records, books of account, registers and documents without
fee by the person in whose custody the records, books of account, registers and documents
are held.
60. (1) All goods kept at any business premises by a dealer, transporter or operator of
a warehouse shall at all reasonable times be open to inspection by the Commissioner.
(2) Where the Commissioner, upon information in his possession or otherwise has
reasonable grounds to believe that any person or dealer is attempting to avoid or evade tax

Power to
enter premises
and seize
records and
goods.

<!-- page 37 -->

36

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

or is concealing his tax liability in any manner and for the purposes of administration, it is
necessary so to do, the Commissioner may—
(a) enter and search any business premises or any other place or building;
(b) break open the lock of any door, box, locker, safe, almirah or other receptacle
for exercising the powers conferred by clause (a) where the keys thereof are not readily
available;
(c) seize and remove any records, books of account, registers, other documents
or goods;
(d) place marks of identification on any records, books of account, registers and
other documents or make or cause to be made extracts or copies thereof without
charge;
(e) make a note or any inventory of any such money or goods found as a result
of such search or place marks of identification on such goods; and
(f) seal the premises including the office, shop, godown, box, locker, safe, almirah
or other receptacle.
(3) Where it is not feasible to remove any records, books of account, registers, other
documents or goods, the Commissioner may serve on the owner and any person who is in
immediate possession or control thereof, an order that he shall not remove or part with or
otherwise deal with them except with the previous permission of the Commissioner.
(4) Where any premises have been sealed under clause (f) of sub-section (2), or an
order made under sub-section (3), the Commissioner may, on an application made by the
owner or the person in occupation or in-charge of such shop, godown, box, locker, safe,
almirah or other receptacle, permit the de-sealing or release thereof, as the case may be, on
such terms and conditions including furnishing of security for such sum in such form and
manners as may be prescribed.
(5) The Commissioner may requisition the services of any police officer or any public
servant, or of both, to assist him for all or any of the purposes specified in sub-section (2).
(6) Save as otherwise provided in this section, every search or seizure made under this
section shall as far as possible be carried out in accordance with the provisions of the Code
of Criminal Procedure, 1973 relating to searches or seizures made under that Code.
Power to stop,
search and
detain goods
vehicles.

61. (1) The Commissioner may at any check-post or barrier or any other place to enable
proper administration of this Regulation, require the owner, driver or person in-charge of a
goods vehicle to stop the vehicle and keep it stationary so long as may be required to search
the vehicle, examine the contents therein and inspect all records relating to the goods carried,
which are in the possession of such owner, driver or person in-charge.
(2) The owner, driver or person in-charge of a goods entering or leaving Lakshadweep
shall carry such records and also file a declaration containing such particulars in the prescribed
form obtainable from the Commissioner and in such manner as may be prescribed, before the
officer in-charge of a check-post or barrier or before any other officer of agent empowered as
aforesaid:
Provided that where the owner, driver or person in-charge of a goods vehicle, after
filing a declaration at the time of entering Lakshadweep that the goods are meant to be
carried to a place outside Lakshadweep fails, without reasonable cause, to carry such goods
outside Lakshadweep within the prescribed period, he shall, in addition to the payment of
tax, if any, be liable to a penalty not exceeding two and a half time the tax that would have
been payable had the goods been sold inside Lakshadweep or one thousand rupees,
whichever is more.

2 of 1974.

<!-- page 38 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

37

(3) The owner, driver or person in-charge of a goods vehicles entering or leaving
Lakshadweep Islands shall also file a declaration containing such particulars in prescribed
form obtainable from the Commissioner and such manner as may be prescribed, before the
officer in-charge of a check-post or barrier or before any other officer or agent empowered as
aforesaid:
Provided that where the owner, driver or person in-charge of a goods vehicles after
filling a declaration at the time of entering Lakshadweep Islands that goods are meant to be
carried to a place outside Lakshadweep Islands fails, without reasonable cause, to carry
such goods outside Lakshadweep Islands within the prescribed period, he shall, in additional
to the payment of tax, if any, be liable to a penalty not exceeding two and a half time the tax
that, would have been payable had the goods been sold inside Lakshadweep Islands or one
thousand rupees, whichever is more.
(4) The owner, driver or person in-charge of the goods vehicle shall, if required, inform
the Commissioner of—
(a) his name and address;
(b) the name and address of the owner of the vehicle;
(c) the name and address of the consignor of the goods;
(d) the name and address of the consignee of the goods; and
(e) the name and address of the transporter.
(5) If, on an examination of the contents of a goods vehicle or the inspection of
documents relating to the goods carried, the Commissioner has reason to believe that the
owner or driver or person in-charge of such goods vehicle is not carrying the documents as
required by sub-section (2) or is not carrying proper and genuine documents or is attempting
to evade payment of tax due under this Regulation, he may, for reasons to be recorded in
writing, do any one or more of the following, namely:—
(a) refuse to allow the goods or the goods vehicle to enter or leave Lakshadweep;
(b) seize the goods and any documents relating to the goods; and
(c) seize the goods vehicle and any documents relating to the goods vehicle.
(6) Where the owner, driver or person in-charge of the goods vehicle—
(a) requests time to adduce evidence of payment of tax in respect of the goods
to be detained or impounded; and
(b) furnishes security to the satisfaction of the Commissioner in such form,
manner and for such amount as may be prescribed,
the goods vehicle, the goods and the documents so seized may be released:
Provided that where the owner or his agent, driver or person in-charge of the goods
vehicle exercises the option of paying a penalty of an amount equal to three and a half times
the tax, which in the opinion of the Commissioner, would be leviable on such goods, if such
goods were sold in Lakshadweep, the Commissioner instead of detaining or impounding the
goods or the goods vehicle or the documents relating to the goods and goods vehicle shall
release the same.
(7) The Commissioner may permit the owner, driver or person in-charge of goods
vehicle to remove any goods or goods vehicle seized under sub-section (6) subject to an
undertaking—
(a) that the goods and goods vehicle shall be kept in the office, godown or other
place within Lakshadweep, belonging to the owner of the goods vehicle and in the
custody of such owner; and

<!-- page 39 -->

38

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) that the goods shall not be delivered to the consignor, consignee or any
other person without the approval in writing of the Commissioner, and for this
purpose the person in-charge of the goods vehicle shall furnish an authorisation
from the owner of the goods vehicle authorising him to give such undertaking on
his behalf.

Custody and
release of
records.

(8) Save as otherwise provided in this section, every search or seizure made under
this section shall as far as possible be carried out in accordance with the provisions of the
Code of Criminal Procedure, 1973 relating to searches or seizures made under that Code.

2 of 1974.

(9) Nothing contained in this section shall apply to the rolling stock as defined in
the Railways Act, 1989.

24 of 1989.

62. (1) Where the Commissioner seizes any books of account or other documents,
he shall give the dealer or the person present on his behalf, as the case may be, a receipt
for the same and obtain acknowledgement of the receipt so given to him:
Provided that if the dealer or person from whose custody the books of account or
other documents are seized refuses to give an acknowledgement, the Commissioner may
leave the receipt at the premises and record this fact.
(2) The Commissioner shall keep in his custody the books of account, registers,
other documents seized under section 60 for a period not exceeding one year, and thereafter
shall return the same to the dealer or person from whose custody or power they were
seized:
Provided that the Commissioner may, before returning the books of account, registers
and other documents, require the dealer or the person, as the case may be, to give a
written undertaking that the books of account, registers and other documents shall be
presented whenever required by the Commissioner for any proceedings under this
Regulation:
Provided further that the Commissioner shall, when requested, allow the person
whose books of account, registers and documents have been seized, reasonable access
to the books of account, registers and documents for the purpose of inspection and shall
allow the person the opportunity to make copies thereof at the person's own expense:
Provided also that the period of custody of the books of account, registers and
other documents seized under section 60 may be extended beyond one year if any
proceedings under this Regulation are pending or for reasons to be recorded by the
Commissioner in writing.

Custody,
return and
disposal of
goods, goods
vehicle and
security.

63. (1) Where the Commissioner seizes any goods or goods vehicle, he shall give
the dealer or person in-charge of the goods vehicle or a person present on his behalf, as
the case may be, a receipt for the same and obtain acknowledgement of the receipt so
given to him:
Provided that if the person from whose custody the goods or goods vehicle are
seized refuses to give an acknowledgement, the Commissioner may leave the receipt in his
presence and record this fact.
(2) The Commissioner—
(a) shall keep any goods or goods vehicle seized under section 61 in his
custody;
(b) may retain them for such time as he considers reasonable; and
(c) subject to the provisions of sub-section (3), shall return the goods or
goods vehicle to the dealer or other person from whose custody or power they were
seized.

<!-- page 40 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

39

(3) Where the Commissioner—
(a) has seized any goods;
(b) has seized a goods vehicle; or
(c) holds any goods as security for the performance of an obligation under
this Regulation,
he may, not sooner than one month after the service of notice on—
(i) the person from whom the goods were seized;
(ii) the person from whom the goods vehicle was seized;
(iii) the person for whom the security was given; and
(iv) any person against whom the security is to be enforced,
of his intention to sell the goods, direct the auction of such goods or goods vehicle to
meet any arrears of tax, interest or penalty owed under this Regulation.
(4) An auction of goods or a goods vehicle shall be carried out in the manner
prescribed for the sale of property held by the Commissioner.
64. (1) If any person on being required by the Commissioner, fails to give any
information in respect of any goods in his possession or fails to permit the inspection
thereof, the Commissioner may seize any goods in his custody or possession in respect of
which the default is committed.

Detention of
goods pending
disclosure.

(2) The seizure shall remain in force until it is revoked or the person concerned
furnishes the information required or makes proper arrangements for the inspection of the
goods, whichever occurs first.
65. Every person shall provide co-operation and reasonable assistance to the
Commissioner as may be required to conduct the Commissioner's activities under the
Regulation.

Obligation to
provide
reasonable
assistance.

CHAPTER XI
VALUE ADDED TAX AUTHORITIES AND APPELLATE TRIBUNAL
66. (1) The Government shall appoint a person to be known as the Commissioner of
Value Added Tax.

Value Added
Tax
Authorities.

(2) The Government may, to assist the Commissioner in the administration of this
Regulation, appoint as many Special Commissioners of Value Added Tax, Value Added Tax
Officers and such other persons with such designations as the Government thinks
necessary (hereafter in this Chapter referred to as "Value Added Tax Authority").
(3) The Commissioner and the Value Added Tax Authorities shall exercise such
powers as may be conferred and perform such duties under this Regulation.
(4) The powers exercised by the Value Added Tax Authorities for the making of
assessments of tax, the computation and imposition of penalties, the computation of
interest due or owed, the computation of the entitlement and the amount of any refund,
the determination of specific questions under section 84, the making of general rulings
under section 85, and the conduct of audit or investigations shall, for the purposes of this
Regulation, be the administrative functions.
67. (1) The Commissioner shall have responsibility for the due and proper
administration and shall have jurisdiction over the whole of the Union territory of
Lakshadweep.

Powers and
responsibilities
of
Commissioner.

<!-- page 41 -->

40

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(2) Subject to the provisions of sub-section (3) the Commissioner may, from time to
time, issue such orders, instructions and directions to any Value Added Tax Authority as
he thinks fit for the due and proper administration and all such persons engaged in the
administration shall observe and follow such orders, instructions and directions of the
Commissioner.
(3) No orders, instructions or directions may be issued by the Commissioner to a
person exercising the power to determine—
(a) a particular objection made or to be made under section 74; or
(b) a particular question made under section 84,
so as to require the person to determine the objection or answer the question of a particular
person in a particular manner.
(4) Nothing in sub-section (3) shall prevent the Commissioner from issuing general
orders, instructions and directions to any person who determines objections made under
section 74 or answers questions made under section 84 about the manner of determining
classes of objections or answering classes of questions.
Delegation of
Commissioner's
powers.

68. (1) Subject to such restrictions and conditions as may be prescribed, the
Commissioner may delegate any of his powers under this Regulation to any Value Added
Tax Authority.
(2) Where the Commissioner delegates his powers under Chapter X, the delegate
shall carry and produce on demand evidence in the prescribed form of the delegation of
these powers when exercising the powers.
(3) Where the Commissioner has delegated a power to a Value Added Tax Authority,
the Commissioner may supervise, review and rectify any decision made or action taken by
that Authority.
(4) Notwithstanding anything to the contrary contained in any law for the time
being in force, the power delegated by the Commissioner to a person to determine an
objection under section 74 may be exercised by that person, even though the person
determining the objection is equal in rank to the person whose decision is under objection.

Change of
incumbent of
office.

69. Whenever in respect of any proceeding under this Regulation the
Commissioneror any Value Added Tax Authority is succeeded by another person—
(a) no delegation of power made by the former incumbent shall be revoked by
virtue of the succession; and
(b) the person so succeeding may continue the proceeding from the stage at
which the proceeding was left by his predecessor.

Powers of
Commissioner
to notify
forms.

70. (1) The Commissioner may notify such forms which may be necessary for the
reporting of information to the Value Added Tax Authorities.
(2) Where the Commissioner has notified a form for a particular purpose, all persons
shall be required to report the information using the form, in such manner as may be
notified by him.
(3) Where in his opinion it is necessary or convenient to do so, the Commissioner
may issue notifications for carrying out the purposes:
Provided that any notification shall not be inconsistent with this Regulation or any
rules or Regulations made pursuant to it.
(4) In particular and without prejudice to the generality of the foregoing power, a
notification issued by the Commissioner may stipulate all or any of the matters which in
the opinion of the Commissioner are necessary or convenient for the proper administration.

<!-- page 42 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

41

(5) Every notification issued by the Commissioner under this Regulation shall be
published in the Official Gazette, and shall not have any effect prior to such publication.

45 of 1860.

71. The Commissioner, Value Added Tax Authorities and all members of the Appellate
Tribunal shall be deemed to be public servants within the meaning of section 21 of the
Indian Penal Code.

Persons to be
public
servants.

72. No suit or proceeding shall be brought in any civil court against the Government,
the Commissioner, any Value Added Tax Authority, or member of the Appellate Tribunal
for anything done or intended to be done in good faith under this Regulation or the rules
made thereunder.

Immunity
from civil suit.

73. (1) The Government shall, as soon as may be after the commencement of this
Regulation, constitute an Appellate Tribunal consisting of one or more members, as it
thinks fit, to exercise the powers and discharge the functions conferred on the Appellate
Tribunal by or under this Regulation or may request the Central Government to designate
any Tribunal of the nearby State to function as Appellate Tribunal for the purpose:

Appellate
Tribunal.

Provided that where the Appellate Tribunal consists of one member, that member
shall be a person who has held a civil judicial post for at least five years or who has been
a member of the Indian Legal Service (not below Grade III) for at least three years or who
has been in practice as an advocate for at least ten years, and where the Appellate
Tribunal consists of more than one member, one such member shall be a person qualified
as aforesaid.
(2) Where the number of members of the Appellate Tribunal is more than one, the
Government shall appoint one of those members to be the Chairperson of the Appellate
Tribunal.
(3) Subject to the provisions of sub-section (1), the qualifications and other
conditions of service of the member or members constituting the Appellate Tribunal and
the period for which such member or members shall hold office, shall be such as may be
determined by the Government.
(4) Any vacancy in the Appellate Tribunal shall be filled up by the Government as
soon as practicable.
(5) Where the number of members of the Appellate Tribunal is more than one and if
the members differ in opinion on any point, the point shall be decided according to the
opinion of the majority, if there is a majority, but if the members are equally divided, the
decision of the Chairperson of the Appellate Tribunal thereon shall be final.
(6) Subject to the previous sanction of the Government, the Appellate Tribunal
shall, for the purpose of regulating its procedure and disposal of its business, make
regulations consistent with the provisions and the rules made thereunder.
(7) The regulations made under sub-section (6) shall be published in the Official
Gazette.

45 of 1860.
2 of 1974.

(8) The Appellate Tribunal shall, for the purpose of discharging its functions, have
all the powers which are vested in the Commissioner under section 75 and any proceeding
before the Appellate Tribunal shall be deemed to be a judicial proceeding within the
meaning of sections 193 and 228, and for the purposes of section 196 of the Indian Penal
Code and the Appellate Tribunal shall be deemed to be a Civil Court for all the purposes
of section 195 and Chapter XXVI of the Code of Criminal Procedure, 1973.
(9) Notwithstanding anything to the contrary contained in this section, the
Government, may, by a notification in the Official Gazette, constitute benches comprising
of one or more members, subject to such conditions and regulations as may be laid down
in the notification.

<!-- page 43 -->

42

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

CHAPTER XII
OBJECTIONS, APPEALS, DISPUTES AND QUESTIONS
Objections.

74. (1) Any person who is dissatisfied with—
(a) an assessment made under this Regulation; or
(b) any other order or decision made under this Regulation,
may make an objection against such assessment or order or decision, as the case may be, to
the Commissioner:
Provided that no objection may be made against a non-appealable order as defined in
section 79:
Provided further that no objection against an assessment shall be entertained unless
the amount of tax, interest or penalty assessed that is not in dispute has been paid failing
which the objection shall be deemed to have not been filed:
Provided also that the Commissioner may, after giving to the dealer an opportunity of
being heard, may direct the dealer to deposit an amount deemed reasonable, out of the
amount under dispute, before such objection is entertained:
Provided also that only one objection may be made by the person against any
assessment, decision or order:
Provided also that in the case of an objection to an amended assessment, order, or
decision, an objection may be made only to the portion amended:
Provided also that no objection shall be made to the Commissioner against an order
made under section 84 or section 85 if the Commissioner has not delegated his power under
the said sections to other Value Added Tax Authorities.
(2) A person who is aggrieved by the failure of the Commissioner to reach a decision or
issue any assessment or order, or undertake any other procedure under this Regulation,
within six months after a request in writing was served by such person, may make an objection
against such failure in such form and in such manner as may be prescribed.
(3) The objection shall be made—
(a) in the case of an objection made under sub-section (1), within two months of
the date of service of the assessment, or order or decision, as the case may be; or
(b) in the case of an objection made under sub-section (2), not earlier than six
months and not later than eight months after the written request was served by the
person:
Provided that where the Commissioner is satisfied that the person was prevented for
sufficient cause from lodging the objection within the time specified, he may accept such
objection within a further period not exceeding two months.
(4) The Commissioner shall conduct its proceedings by an examination of the
assessment, or order or decision, as the case may be, the objection and any other document
or information as may be relevant:
Provided that where the person aggrieved, requests a hearing in person, such person
shall be given an opportunity to be heard in person.
(5) Where a person has requested a hearing under sub-section (4) and the person fails
to attend the hearing at the time and place stipulated, the Commissioner shall proceed and
determine the objection in the absence of the person.

<!-- page 44 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

43

(6) Within three months after the receipt of the objection, the Commissioner shall
either—
(a) accept the objection in whole or in part and take appropriate action to give
effect to the acceptance (including the remission of any penalty assessed either in
whole or in part); or
(b) refuse the objection or the remainder of the objection, as the case may be;
and in either case, serve on the person objecting, a notice in writing of the decision and
the reasons for it, including a statement of the evidence on which it is based:
Provided that where the Commissioner within three months of the making of the
objection notifies the person in writing, he may continue to consider the objection for a
further period not exceeding two months:
Provided further that the person may, in writing, request the Commissioner to delay
considering the objection for a period of three months for the proper preparation of its
position, in which case the period of the adjournment shall not be counted towards the
period by which the Commissioner shall reach his decision.
(7) Where the Commissioner has not notified the person of his decision within the
time specified under sub-section (6), the person may serve a written notice requiring him to
make a decision within fifteen days.
(8) If the decision has not been made by the end of the period of fifteen days after
being given the notice referred to in sub-section (7), then, at the end of that period, the
Commissioner shall be deemed to have allowed the objection.
(9) (a) In case of revision of any order under this section or any decision in objection
is passed under this Regulation, rules or notifications made thereunder, by any officer or
person sub-ordinate to him, the Commissioner may, of his own motion or upon information
received by him, call for the record of such order and examine whether—
(i) any turnover of sales has not been brought to tax or has been brought to tax
at lower rate, or has been incorrectly classified, or any claim is incorrectly granted or
that the liability to tax is understated; or
(ii) any case, the order is erroneous, in so far as it is prejudicial to the interest of
revenue, and after examination, the Commissioner may pass an order to the best of his
judgment, where necessary.
(b) (i) For the purpose of the examination and passing of the order, the Commissioner
may require, by service of notice, the dealer to produce or cause to be produced before him
such books of account and other documents or evidence as he thinks necessary for the
purposes aforesaid.
(ii) Notwithstanding anything to the contrary contained in section 34, no order under
this section shall be passed after the expiry of four years from the end of the year in which
the order passed by the sub-ordinate officer has been served on the dealer.
(iii) Notwithstanding anything to the contrary contained in section 34, where in respect
of any order or part of the said order passed by the sub-ordinate officer, an order has been
passed by any authority hearing the objection or any appellate authority including the
Tribunal or such order is pending for decision in objection or in appeal, or an objection or an
appeal is filed, then, whether or not the issues involved in the examination have been decided
or raised in the objection or the appeal, the Commissioner may, within five years of the end of
the year in which the said order passed by the sub-ordinate officer has been served on the
dealer, make a report to the said objection hearing authority or the appellate authority
including the Tribunal regarding his examination or the report or the information received by
him and the said appellate authority including the Tribunal shall thereupon, after giving the

<!-- page 45 -->

44

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

dealer a reasonable opportunity of being heard, pass an order to the best of its judgment,
where necessary.
(c) If the Commissioner has initiated any proceeding before an appropriate forum
against an issue which is decided against the revenue by an order of the Tribunal, then the
Commissioner may, in respect of any order, other than the order which is the subject-matter
of the order of the Tribunal, call for the record, conduct an examination as aforesaid, record
his findings, call for the said books of account and other evidence and pass an order as
provided for under this section as if the issue was not so decided against the revenue, but
shall stay the recovery of the dues including the interest or penalty, in so far as they relate to
such issue until the decision by the appropriate forum and after such decision, may modify
the order of revision, if necessary.
(d) No proceedings under this section shall be entertained on any application made by
a dealer or a person.
(e) Notwithstanding anything contained in any judgment, decree or order of any court,
the provisions of this Regulation, shall be deemed to have come into force on the date of the
publication of this Regulation in the Official Gazette.
(10) (a) Notwithstanding anything to the contrary contained in section 34, the
Commissioner may, at any time within four years from the end of the year in which any order
passed by him has been served, on his own motion, rectify any mistake apparent on record
and shall within the said period or thereafter rectify any such mistake which has been
brought to his notice within the said period, by any person affected by such order.
(b) The provisions of sub-section (1) shall apply to the rectification of a mistake by the
appellate authority or an objection hearing authority as they apply to the rectification of
mistake by the Commissioner:
Provided that where any matter has been considered and decided in any proceedings
by way of objection or appeal or review in relation to any order or part of an order, the
authority passing the order on objection, appeal or review, may, notwithstanding anything
contained in this Regulation, rectify the order or part of the order on any matter other than
the matter which has been so considered and decided.
(c) Where any such rectification has the effect of reducing the amount of the tax or
penalty or interest, the Commissioner shall refund any amount due to such person in
accordance with the provisions.
(d) Where any such rectification has the effect of enhancing the amount of the tax or
penalty or interest or reducing the amount of refund, the Commissioner shall recover the
amount due from such person in accordance with the provisions.
(e) Save as provided in the foregoing sub-sections, and subject to such rules as may
be prescribed, any assessment or re-assessment made or order passed under this Regulation
or the rules made thereunder by any person appointed under section 66 may be reviewed by
such person suo motu or upon an application made in that behalf.
Power of
Commissioner
and other
authorities to
take evidence
on oath, etc.

75. (1) The Commissioner or any person determining objections under section 74, for
the purposes of this Regulation, have the same powers as are vested in a court under the
Code of Civil Procedure, 1908 when trying a suit, in respect of the following matters, namely:—

5 of 1908.

(a) enforcing the attendance of any person and examining him on oath or
affirmation;
(b) compelling the production of accounts and documents; and
(c) issuing commissions for the examination of witnesses and any proceeding
under this Regulation before the Commissioner or person determining objections under
section 74 shall be deemed to be a judicial proceeding within the meaning of sections
193 and 228 and for the purposes of section 196 of the Indian Penal Code.

45 of 1860.

<!-- page 46 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

45

(2) Subject to any rules made in this behalf, the Commissioner or any person determining
objections under section 74 may impound and retain in his custody, any books of account
or other documents produced before him in any proceedings under this Regulation until
such proceedings are concluded:
Provided that the Commissioner or the person determining an objection under section 74
shall not impound any books of account or other documents without recording in writing his
reasons for so doing.
76. (1) Any person aggrieved by a decision made by the Commissioner under
sections 74, 84 and 85 may appeal to the Appellate Tribunal against such decision.
(2) Subject to the provisions of section 77, no appeal shall be entertained unless it is
made within two months from the date of service of the decision appealed against.
(3) Every appeal made under this section shall be in form, verified in such manner and
shall be accompanied by such fee as may be prescribed.
(4) No appeal against an assessment shall be entertained by the Appellate Tribunal
unless the appeal is accompanied by satisfactory proof of the payment of the amount in
dispute and any other amount assessed as due from the person:
Provided that the Appellate Tribunal may, if it thinks fit, for reasons to be recorded in
writing, entertain an appeal against such order without payment of some or all of the amount
in dispute, on the appellant furnishing in the prescribed manner security for such amount as
it may direct:
Provided further that no appeal shall be entertained by the Appellate Tribunal unless
it is satisfied that such amount as the appellant admits to be due from him has been paid.
(5) In proceedings before the Appellate Tribunal—
(a) the person aggrieved shall be limited to disputing only those matters stated
in the objection;
(b) the person aggrieved shall be limited to arguing only those grounds stated in
the objection; and
(c) the person aggrieved may be permitted to adduce evidence not presented to
the Commissioner for good and sufficient reasons.
(6) The Appellate Tribunal shall—
(a) in the case of an assessment, confirm, reduce, or annul the assessment
(including any penalty and interest imposed);
(b) in the case of any other decision of the Commissioner, affirm or reject the
decision; or
(c) pass such other order for the determination of the issue as it thinks fit:
Provided that the Appellate Tribunal shall give reasons in writing for its decision
which shall include its findings on material questions of fact and the evidence or other
material on which those findings were based.
(7) The Appellate Tribunal shall use its best endeavors to make a final resolution of
the matter before it and for this purpose may make a decision in substitution for the order in
dispute, including the exercise or re-exercise of any discretion or power vested in the
Commissioner.
(8) The Appellate Tribunal shall not set aside an assessment and remit the matter to the
Commissioner for a further assessment, unless it has first—
(a) advised the aggrieved person of the proposed order;

Appeals to
Appellate
Tribunal.

<!-- page 47 -->

46

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) offered the person the opportunity to adduce such further evidence before it
as might assist the Appellate Tribunal to reach a final determination.
(9) Where the Appellate Tribunal sets aside an assessment and remits the matter to the
Commissioner for a further assessment, the Appellate Tribunal shall at the same time order
the Commissioner to refund to the person some or all of the amount in dispute:
Provided that where no order is made, it shall be presumed that the Appellate Tribunal
has ordered the refund of the amount in dispute.
(10) Where a person has failed to attend the hearing at the time and place stipulated,
the Appellate Tribunal may adjourn the proceedings, strike out the appeal or proceed to
make an order determining the objection in the absence of the person.
(11) Save as provided in section 81 and sub-section (12), an order passed by the
Appellate Tribunal on an appeal shall be final.
(12) The Appellate Tribunal may rectify any mistake or error apparent from the record
of its proceedings.
(13) Any order passed by the Appellate Tribunal may be reviewed suo motu or upon
an application made in that behalf:
Provided that before any order which is likely to affect any person adversely is passed,
such person shall be given a reasonable opportunity of being heard.
Extension of
period of
limitation in
certain cases.

77. (1) The Appellate Tribunal may admit an appeal under section 76 after the period of
limitation laid down in that section, if the appellant satisfies the Appellate Tribunal that he
had sufficient cause for not preferring the appeal within such period.
(2) In computing the period laid down under sections 76 and 81, the provisions of
sections 4 and 12 of the Limitation Act, 1963, shall, so far as may be, apply.
(3) In computing the period of limitation prescribed by or under any provision, or the
rules made thereunder, other than section 76 or section 81, any period during which any
proceeding is stayed by an order or injunction of any court shall be excluded.

Burden of
proof.

Bar on appeal
or objection
against
certain orders.

78. The burden of proving any matter in issue in proceedings under section 74, or
before the Appellate Tribunal which relates to the liability to pay tax or any other amount
under this Regulation shall lie on the person alleged to be liable to pay the amount.
79. (1) No objection or appeal shall lie against—
(a) a decision of the Commissioner to make an assessment of tax or penalty;
(b) a notice requiring a person to furnish a return;
(c) a notice issued under section 58 or section 59;
(d) a decision of the Commissioner to notify any matter;
(e) a notice asking a dealer to show cause why he should not be prosecuted for
an offence under this Regulation;
(f) a decision relating to the seizure or retention of books of account, registers
and other documents;
(g) a decision sanctioning a prosecution under this Regulation;
(h) an interim decision made in the course of any proceedings;
(i) a decision of the Commissioner touching on the internal administration of the
Value Added Tax Authorities;
(j) an assessment issued by the Commissioner to give effect to an order of the
Appellate Tribunal or a court; or

36 of 1963.

<!-- page 48 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

47

(k) a notice served on the person under sub-section (10) of section 84 referred to
as "non-appealable orders".
(2) Save as provided in clause (j) of sub-section (1), nothing contained in subsection (1) shall prevent the person from objecting to the amount or the obligation to pay
any amount assessed by the Commissioner under section 74.
80. (1) No assessment, notice, summons or other proceedings made or issued or taken
or purported to have been made or issued or taken in pursuance of any of the provisions or
under the earlier law shall be invalid or shall be deemed to be invalid merely by reason of any
mistake, defect or omission in such assessment, notice, summons or other proceedings, if
such assessment, notice, summons or other proceedings are in substance and effect in
conformity with or according to the intent and purposes or any earlier law.

Assessment
proceedings,
etc., not to be
invalid on
certain
grounds.

(2) The service of any notice, order or communication shall not be called in question if
the said notice, order or communication, as the case may be, has already been acted upon by
the dealer or person to whom it is issued or which service has not been called in question at
or in the earliest proceedings commenced, continued or finalised pursuant to such notice,
order or communication.
(3) No assessment made under this Regulation shall be invalid merely on the ground
that the action could also have been taken by any other authority under any other provisions.
81. (1) An appeal shall lie to the High Court from every order passed by the Appellate
Tribunal in appeal under this Regulation, if the High Court is satisfied that the case involves
a substantial question of law.
(2) The Commissioner or the other party aggrieved by any order passed by the Appellate
Tribunal may file an appeal to the High Court and such appeal under this sub-section shall
be—
(a) filed within sixty days from the date on which the order appealed against is
received by the Commissioner or served upon the other party:
Provided that the High Court may entertain an appeal after the expiry of the
period of sixty days, if it is satisfied that there was sufficient cause for not filing it
within that period:
Provided further that the above proviso shall be deemed to have come into force
on the date of the publication of this Regulation in the Official Gazette;
(b) in the form of a memorandum of appeal precisely stating therein the substantial
question of law involved.
(3) Where the High Court is satisfied that a substantial question of law is involved in
any case, it shall formulate that question.
(4) The appeal shall be heard only on the question so formulated, and the respondents
shall, at the hearing of the appeal, be allowed to argue that the case does not involve such
question:
Provided that nothing in this sub-section shall be deemed to take away or abridge the
power of the court to hear, for reasons to be recorded, the appeal on any other substantial
question of law not formulated by it, if it is satisfied that the case involves such question.
(5) The High Court shall decide the question of law so formulated and deliver such
judgment thereon containing the grounds on which such decision is founded and may
award such cost as it deems fit.
(6) The High Court may determine any issue which—
(a) has not been determined by the Appellate Tribunal;
(b) has been wrongly determined by the Appellate Tribunal, by reason of a
decision on such question of law as is referred to in sub-section (1).

Appeal to
High Court.

<!-- page 49 -->

48

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(7) Where an appeal has been filed before the High Court, it shall be heard by a bench
of not less than two judges of the High Court, and shall be decided in accordance with the
opinion of such judges or of the majority, if any, of such judges.
(8) Where there is no such majority, the judges shall state the point of law upon which
they differ and the case shall, then, be heard upon that point only by one or more of the other
judges of the High Court and such point shall be decided according to the opinion of the
majority of the judges who have heard the case including those who first heard it.
(9) Save as otherwise provided in this Regulation, the provisions of the Code of Civil
Procedure, 1908, relating to appeals to the High Court shall, as far as may be, apply in the
case of appeals under this section.
Appearances
before any
authority in
proceedings.

82. (1) Any person, who is entitled or required to attend before any authority in
connection with any proceedings under this Regulation, may attend—
(a) by a person authorised by him in writing in this behalf, being a relative or a
person regularly employed by him; or
(b) by a legal practitioner or chartered accountant or cost accountant or company
secretary who is not disqualified by or under sub-section (2); or
(c) by a Value Added Tax practitioner who possesses the prescribed qualifications
and is entered in the list, which the Commissioner shall maintain in that behalf, and
who is not disqualified by or under sub-section (2).
(2) The Commissioner may, for reasons to be recorded in writing, disqualify for a
period from appearing before any such authority, any legal practitioner, chartered accountant,
cost accountant, company secretary or Value Added Tax practitioner—
(a) who has been dismissed from government service; or
(b) who, being a legal practitioner or chartered accountant or cost accountant or
company secretary is found guilty of misconduct in connection with any proceedings
under this Regulation by an authority empowered to take disciplinary action against
the members of the profession to which he belongs; or
(c) who, being a Value Added Tax practitioner, is found guilty of such misconduct
by the Commissioner.
(3) Any person who is disqualified under this section may, within one month of the
date of disqualification, appeal to the Government to have the disqualification cancelled.
(4) The decision of the Commissioner shall not take effect until one month of the
making thereof or when an appeal is preferred, until the appeal is decided.
(5) The Commissioner may, at any time, suo motu or on an application made to him in
this behalf, revoke any decision made against any person under sub-section (2) and thereupon
such person shall cease to be disqualified.

Bar of suits in
civil courts.

83. No suit or proceeding shall be brought in any civil court to set aside or modify any
assessment made or any order passed under this Regulation or the rules made thereunder.

Determination
of specific
questions.

84. (1) If any determinable question arises, otherwise than in proceedings before a
court, a person may apply in the prescribed manner to the Commissioner for the determination
of that question.
(2) Subject to sub-section (3), an application for the determination of a determinable
question may be made in respect of a proposed transaction, a transaction that is being
undertaken, or a transaction has been concluded.
(3) An application for the determination of a determinable question may not be made
after—
(a) the Commissioner has commenced the audit of the person pursuant to
section 58; or

5 of 1908.

<!-- page 50 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

49

(b) the Commissioner has issued an assessment for the tax period in which the
transaction that is the subject of the determinable question occurred.
(4) For the purposes of this section, the following shall be determinable questions—
(a) whether any person, society, club or association or any firm or any branch or
department of any firm is or would be a dealer;
(b) whether any dealer is or would be required to be registered under this
Regulation;
(c) the amount of the taxable quantum of a dealer for a period;
(d) whether a transaction is or would be a sale, or requires an adjustment to be
made under section 8 arising out of a sale;
(e) whether a transaction is or would be in the nature of works contract, or
transfer of right to use any goods;
(f) whether a sale is not liable to tax under section 7;
(g) whether a sale is exempted from tax under section 6;
(h) the sale price of a transaction;
(i) the proportion of the turnover or turnover of purchases of a dealer which
arises in a tax period, and the time at which an adjustment to tax or tax credit arises;
(j) whether any transaction is or would be the import of goods;
(k) the value of any goods imported into Lakshadweep;
(l) the rate of tax that is payable on a sale or import of goods and the classification
of the goods under the Schedules;
(m) whether a transaction is the purchase of goods, or requires an adjustment to
be made under section 10 arising out of a purchase;
(n) the amount of any tax credit to which the dealer is entitled in respect of a
purchase or import of goods;
(o) the amount of any tax credit in respect of any used goods purchased by a
dealer;
(p) the location of any sale or purchase;
(q) the application of a composition scheme in the circumstances of a dealer; or
(r) the tax period of a dealer.
(5) The Commissioner shall make the determination within such period as may be
prescribed.
(6) Where—
(a) the Commissioner fails to make a determination under this section within the
time prescribed under sub-section (5);
(b) the person thereafter implements the transaction which is the subject of the
application and in the manner described in the application; and
(c) the person has, in the application for the determination of the determinable
question, indicated the answer to the determinable question which the person believes
to be correct (in this section called the "proposed determination"),
the Commissioner shall be deemed for the purposes to have made and issued to the person
on the day after the expiry of the prescribed period, a determination of the determinable
question in the terms of the proposed determination.

<!-- page 51 -->

50

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(7) The Commissioner may—
(a) direct that the determination shall not affect the liability of any person under
this Regulation with respect to any transaction effected prior to the determination;
(b) limit the period for which the determination will apply;
(c) limit the transactions to which the determination will apply; and
(d) impose such other limitations or restrictions on the determination as seem
appropriate.
(8) If any such question arises from any order already passed under this Regulation,
no such question shall be entertained for determination under this section but such question
may be raised in an objection or appeal against such order.
(9) Where—
(a) the Commissioner has issued to a person a determination in respect of a
particular transaction; and
(b) the person implements the transaction based on the determination issued to
him under this section and in the manner described in the application,
no assessment may be raised by the Commissioner against that person which is inconsistent
with the determination and no penalty may be imposed on the person if the determination is
later held incorrect.
(10) The Commissioner may, by notice served on the person, withdraw or qualify a
determination issued under this section but such withdrawal or qualification shall not affect
the entitlement of any person to rely on the determination with respect to any transaction or
action which he has commenced or which he has completed prior to the withdrawal or
qualification.
Ruling on
general
questions.

85. (1) The Commissioner may, by notification in the Official Gazette, publish his ruling
on the answer to any question involving the interpretation or application to a class of
persons or class of transactions.
(2) A ruling issued by the Commissioner under this section may be issued subject
tosuch restrictions and conditions as the Commissioner may deem fit.
(3) The ruling shall be treated as coming into effect on the date stated in the ruling
(which may be a date prior to the publication of the ruling) or, if no date is stated in the ruling,
on the date of publication of the Official Gazette.
(4) Where—
(a) the Commissioner has published a ruling in respect of a class of persons or
transactions;
(b) a person implements a transaction or undertakes any action based on the
ruling;
(c) the ruling has, at the time of implementing the transaction or undertaking the
action, not been withdrawn by the Commissioner; and
(d) according to the terms of the ruling, the ruling purports to apply to the
transaction or action undertaken by the person,
no assessment which is inconsistent with the ruling, may be raised by the Commissioner
against that person and no penalty may be imposed on the person if the ruling is later held
incorrect.
(5) The Commissioner may, by notification published in the Official Gazette, withdraw
or qualify a ruling already issued under this section but such withdrawal or qualification

<!-- page 52 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

51

shall not affect the entitlement of any person to rely on the ruling with respect to any
transaction or action commenced or completed by him prior to such withdrawal or
qualification.
CHAPTER XIII
PENALTIES AND OFFENCES
86. (1) In this Chapter "tax deficiency" means the difference between the tax properly
payable by the person in accordance with the provisions of this Regulation and the amount
of tax paid by the person in respect of a calendar month.

Interpretation.

(2) Where two or more penalties arise under this Regulation in respect of the same
person, such person shall be liable to pay only the higher penalty.
87. Where a person who is required to be registered under this Regulation has failed
to apply for registration within one month from the day on which the requirement arose, such
person shall be liable to pay a penalty of an amount equal to five hundred rupees per day
from the day immediately following the expiry of the said period until such person makes an
application for registration in such form, containing such particulars and information and
accompanied by such fee, security and other documents as may be prescribed:

Penalty for
nonregistration.

Provided that the amount of penalty payable under this sub-section shall not exceed
an amount of fifty thousand rupees.
88. If, a registered dealer fails to comply with the provisions of sub-section (1) of
section 21, he shall be liable to pay a penalty of an amount of two hundred and fifty rupees
per day of default subject to a maximum of five thousand rupees.
89. If a registered dealer—
(a) fails to comply with the provisions of sub-section (2) of section 22; or

Penalty for
contravenetion
of section 21.
Penalty for
contravenetion
of section 22.

(b) fails to surrender his certificate of registration as provided in sub-section (7)
of section 22,
the registered dealer shall be liable to pay a penalty of an amount equal to five hundred
rupees for every day of default subject to a maximum of fifteen thousand rupees.
90. If any person falsely represents that he is registered as a dealer under this Regulation,
he shall be liable to pay a penalty equal to the amount of tax wrongly collected or fifty
thousand rupees, whichever is higher.
91. Where a person—
(a) has applied for registration under sub-section (4) of section 18;
(b) has been registered; and either—

Penalty for
false
representation.
Penalty for
noncompliance of
certain
conditions.

(i) has failed to undertake activities which would make the person a dealer
within the period specified in his application; or
(ii) has failed to comply with any of the restrictions or conditions subject
to which such registration was granted,
such person shall be liable to pay a penalty of five thousand rupees.
92. If a person required to furnish a return under Chapter V—
(a) fails to furnish any return by the due date; or
(b) fails to furnish with a return any other document that is required to be
furnished with the return; or
(c) being required to revise a return already furnished, fails to furnish the revised
return by the due date; or

Penalty for
failure to
furnish return.

<!-- page 53 -->

52

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(d) fails to comply with a requirement in a notification issued under section 70,
such person shall be liable to pay a penalty of an amount two hundred and fifty rupees per
day from the day immediately following the due date until the failure is rectified:
Provided that the total amount of penalty payable under this sub-section shall not
exceed twenty-five thousand rupees.
Penalty for
filing false
returns.

93. Any person who—
(a) furnishes a return under this Regulation which is false, misleading or deceptive
in a material particular; or
(b) omits from a return furnished under this Regulation any matter or thing
without which the return is false, misleading or deceptive in a material particular,
shall be liable to pay a penalty of an amount of five thousand rupees or the amount of the tax
deficiency, whichever is higher.

Other
penalties.

94. (1) Any dealer who—
(a) has claimed tax credit under section 14 to which he is not entitled; or
(b) has claimed a greater tax credit under section 14 than is allowed,
shall be liable to pay a penalty of an amount equal to the amount of tax credit so claimed or
five thousand rupees, whichever is higher.
(2) Where a tax deficiency arises in relation to a person, the person shall be liable to
pay a penalty of an amount equal to one per cent. of the tax deficiency per week or an amount
equal to rupees fifty per week, whichever is higher, for the period of default.
(3) Where a person is required under this Regulation to—
(a) prepare records or accounts; or
(b) prepare records or accounts in a prescribed manner; or
(c) retain prescribed or notified records or accounts,
and such person—
(i) fails to prepare the prescribed or notified records and accounts; or
(ii) fails to prepare prescribed or notified records and accounts in the prescribed
manner; or
(iii) fails to retain the prescribed or notified records and accounts for the
prescribed period; or
(iv) fails to retain or produce the prescribed or notified records at the principal
place of business as recorded in his certificate of registration; or
(v) fails to comply with a direction issued or fails to produce prescribed or
notified records and accounts, or cause them to be produced, on or before the date
specified in any notice served on him by the Commissioner or by an accountant or a
panel of accountants or any other professional or panel of professionals nominated by
the Commissioner in this behalf under clause (a) of sub-section (6) of section 58,
such person shall be liable to pay a penalty of an amount of twenty-five thousand rupees or
twenty per cent. of the tax deficiency, if any, whichever is higher.
(4) If, any dealer fails to comply with the provisions of section 49, the dealer shall be
liable to pay a penalty of an amount equal to one per cent. of his turnover or a sum of fifty
thousand rupees, whichever is less.
(5) Where a person who is required to prepare records and accounts under this
Regulation, prepares records and accounts in a manner that is false, misleading or deceptive,

<!-- page 54 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

53

the person shall be liable to pay a penalty of an amount of fifty thousand rupees or the
amount of the tax deficiency, if any, whichever is higher.
(6) Where a person—
(a) has issued a tax invoice or retail invoice with incomplete or incorrect
particulars; or
(b) having issued a tax invoice or retail invoice, has failed to account it correctly
in his books of account,
such person shall be liable to pay a penalty of an amount of three thousand rupees or twenty
per cent. of the tax deficiency, if any, whichever is higher.
(7) Where a person who is not authorised under this Regulation to issue a tax invoice
has issued a tax invoice for a sale, such person shall be liable to pay a penalty of an amount
of fifty thousand rupees or the tax deficiency, if any, whichever is higher.
(8) Any person who fails to comply with the requirement under sub-section(2) or
sub-section (3) of section 59 shall be liable to pay a penalty of an amount of twenty-five
thousand rupees.
(9) Where goods are being carried by a transporter without the documents or without
proper and genuine documents or without being properly accounted for in the documents
referred to in sub-section (2) of section 61, the transporter shall be liable to a penalty equal
to twenty paisa in a rupee for the value of such goods.
(10) Any person who—
(a) makes a statement to the Commissioner which is false, misleading or deceptive
in a material particular; or
(b) omits from a statement made to the Commissioner any matter or thing without
which the statement is false, misleading or deceptive in a material particular,
such person shall be liable to pay a penalty of an amount of twenty-five thousand rupees, or
the amount of the tax deficiency, whichever is higher.
95. (1) Where a casual trader who is required to be registered under this Regulation
has failed to apply for registration within stipulated period, the casual trader shall be liable to
pay a penalty of an amount equal to three thousand rupees per day, from the day immediately
following the expiry of the due date until the person makes an application for registration
under this Regulation:
Provided that the amount of penalty payable under this sub-section shall not exceed
fifty thousand rupees.
(2) If a casual trader required to furnish a return under this Regulation—
(a) fails to furnish any return by the due date; or
(b) fails to furnish with a return any other document that is required to be
furnished with the return,
such person shall be liable to pay a penalty of an amount of five hundred rupees per day
from the day immediately following the due date until the failure is rectified:
Provided that the amount of penalty payable under this sub-section shall not exceed
fifteen thousand rupees.
(3) Where any person who, whether as principal, agent or in any other capacity
organises any exhibition-cum-sale in Lakshadweep and fails—
(a) to furnish any information in respect of the goods brought or kept in stock or
sold by any participant before or during or after the exhibition-cum-sale; or

Penalties on
certain
persons.

<!-- page 55 -->

54

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) to ensure that all such participants in the exhibition-cum-sale have obtained
registration under this Regulation and paid due tax; or
(c) to permit inspection of the business premises or goods or account and
records of the participants; or
(d) to permit inspection of the accounts and records of the organiser in respect
of the exhibition-cum-sale,
such person shall be liable to pay a penalty of an amount equal to twenty-five thousand
rupees or an amount equal to the amount of tax payable on such goods if such goods were
sold in Lakshadweep, whichever is higher.
General
penalty.

96. Any person, who contravenes any of the provisions of this Regulation or any rules
made thereunder for which no penalty is separately provided under the Act, shall be liable to
pay a penalty of five thousand rupees.

Automatic
mitigation
and increase
of penalties.

97. (1) Where as a result of any proceedings, the amount of tax with respect to which
a penalty was levied has been wholly reduced, the penalty levied shall be cancelled and if
the penalty has been paid, it shall be refunded.
(2) If—
(a) a person is liable to pay a penalty under sub-section (2) of section 94; and
(b) the person voluntarily discloses to the Commissioner in writing the existence
of the tax deficiency before the Commissioner informs the person that an audit of the
person's tax obligations is to be carried out,
the amount of the penalty otherwise due shall be reduced by eighty per cent. of the
penalty.
(3) If—
(a) a person is liable to pay a penalty under sub-section (2) of section 94; and
(b) the person voluntarily discloses to the Commissioner in writing the existence
of the tax deficiency after the Commissioner informs the person that an audit of the
person's tax obligations is to be carried out,
the amount of the penalty due shall be reduced by fifty per cent. of the penalty.
(4) If—
(a) a person is liable to pay a penalty under sub-section (2) of section 94;
(b) the tax deficiency arose because the person treated this Regulation as
applying to the person in a particular way; and
(c) the decision to adopt that treatment was made by the person relying on a
determination given to the person by the Commissioner under section 84 or a ruling
issued by the Commissioner under section 85,
the amount of the penalty otherwise due, shall be reduced to nil.
(5) Where—
(a) the penalty under this Regulation has been assessed;
(b) the penalty has not been remitted in full after objection; and
(c) the person is subsequently assessed to a further penalty in respect of the
same or a substantially similar failure occurring on another occasion (hereafter in this
section called the "subsequent offence"),
the penalty otherwise due under this Regulation shall be increased by—
(i) in the case of the first subsequent offence, fifty per cent. of the specified
penalty; and

<!-- page 56 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

55

(ii) in the case of the second and any further subsequent offence, one hundred
per cent. of the specified penalty.
(6) If—
(a) a person is liable to pay penalty under section 86;
(b) the person voluntarily discloses to the Commissioner, in writing, the existence
of the tax deficiency, during the course of proceedings under section 60; and
(c) makes payment of such tax deficiency within three working days of the
conclusion of the said proceedings,
the amount of the penalty otherwise due, against the admitted and paid tax, shall be reduced
by eighty per cent.
98. (1) The penalties specified under this Regulation are owed notwithstanding that
no assessment of tax owed under this Regulation has been made.
(2) Any penalty imposed under this Regulation shall be without prejudice to any
prosecution for any offence under this Chapter.
99. (1) Whoever—
(a) not being a registered dealer, falsely represents that he is or was a registered
dealer at the time when he sells or buys goods;
(b) knowingly keeps false account or does not keep the account of the value of
the goods bought or sold by him in contravention of section 48; or
(c) issues to any person a false invoice, bill, cash memorandum, voucher or other
document which he knows or has reason to believe to be false,
shall, on conviction, be punishable with rigorous imprisonment for a term which may extend
to six months, and with a fine which may extend to three thousand rupees.
(2) Whoever knowingly—
(a) furnishes a false return;
(b) produces before the Commissioner, false bill, cash memorandum, voucher,
declaration, certificate, tax invoice or other document for claiming deduction on tax
credit; or
(c) produces false accounts, registers or documents or knowingly furnishes
false information,
he shall—
(i) in case where the amount of tax which could have been evaded if the false
return, bill, cash memorandum, voucher, declaration, certificate, tax invoice or other
document for claiming deduction on tax credit, accounts, registers or documents or
false information, as the case may be, had been accepted as true exceeds fifty thousand
rupees, on conviction, be punished with rigorous imprisonment for a term which may
extend to six months; and
(ii) in any other case, with rigorous imprisonment for a term which may extend to
six months, and with fine which may extend to three thousand rupees.
(3) Whoever, willfully attempts, in any manner whatsoever, to evade payment of tax,
penalty or interest or all of them under this Regulation, shall, on conviction, be punished—
(a) in any case where the amount involved exceeds fifty thousand rupees during
the period of a year, with rigorous imprisonment for a term which may extend to six
months, and with a fine which may extend to three thousand rupees; and

Relationship
to assessment
and impact on
criminal
penalties.

Imprisonment
and fine for
certain acts.

<!-- page 57 -->

56

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) in any other case, with rigorous imprisonment for a term which may extend to
three months and with fine which may extend to three thousand rupees.
(4) Whoever—
(a) carries on business as a dealer without being registered in willful contravention
of sub-section (1) of section 18;
(b) fails without sufficient cause to furnish any information required under
section 21;
(c) fails to surrender his certificate of registration as provided in sub-section (7)
of section 22;
(d) fails without sufficient cause to furnish any returns as required under section
27 by the date or in the manner prescribed;
(e) without reasonable cause, contravenes any of the provisions of section 40;
(f) without sufficient cause fails to issue invoice as required under section 50;
(g) fails without sufficient cause, when directed so to do under section 48 to
keep any accounts or record, in accordance with the directions;
(h) fails without sufficient cause, to comply with any requirements made of him
under section 58 or section 59, or obstructs any officer making inspection or search or
seizure under sections 60 and 61;
(i) obstructs or prevents any officer performing any function under Chapter X;
(j) being owner in-charge of a goods vehicle fails, neglects or refuses to comply
with any of the requirements contained in section 61; or
(k) interferes with or obstructs the Commissioner or any officer exercising any
other power conferred under this Regulation,
shall, on conviction, be punishable with imprisonment for a term which may extend to six
months, and with a fine which may extend to five thousand rupees.
(5) Whoever aids or abets any person in the commission of any act specified in
sub-sections (1) to (3) shall, on conviction, be punishable with rigorous imprisonment which
may extend to six months, and with a fine which may extend to five thousand rupees.
(6) Whoever commits any of the acts specified in sub-sections (1) to (5) and the
offence is a continuing one under any of the provisions of these sub-sections, shall, on
conviction, be punishable with a fine of not less than one hundred rupees per day during the
period of the continuance of the offence, in addition to the punishments provided under this
section.
(7) Notwithstanding anything contained in sub-sections (1) to (5) of this section, no
person shall be proceeded under these sub-sections, if—
(a) the total amount involved is less than two hundred rupees during the period
of a year; or
(b) the person has voluntarily disclosed existence of tax deficiency under the
provisions of the Act.
(8) Where a dealer is accused of an offence specified in sub-section (1), (2) or (3) or in
clauses (a), (b), (c), (d), (e), (f), (g), (h) and (i) of sub-section (4), or sub section (6), the
person deemed to be the manager of the business of such dealer under section 95 shall also

<!-- page 58 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

57

be deemed to be guilty of such offence, unless he proves that the offence was committed
without his knowledge or that he exercised all due diligence to prevent the commission
thereof.
100. (1) Where an offence under this Regulation or the rules has been committed by a
company, every person who, at the time the offence was committed, was in-charge of, and
was responsible to the company for the conduct of the business of the company, as well as
the company shall be deemed to be guilty of the offence and shall be liable to be proceeded
against and punished accordingly:

Offences by
companies,
etc.

Provided that nothing contained in this sub-section shall render any such person
liable to any punishment provided in this Regulation if he proves that the offence was
committed without his knowledge or that he exercised all due diligence to prevent the
commission of such offence.
(2) Notwithstanding anything contained in sub-section (1), where an offence under
this Regulation has been committed by a company and it is proved that the offence has been
committed with the consent or connivance of, or is attributable to any neglect on the part of
any director, manager, secretary or other officer of the company, such director, manager,
secretary or other officer shall also be deemed to be guilty of that offence and shall be liable
to be proceeded against and punished accordingly.
101. (1) No court shall take cognizance of any offence under this Regulation or rules
made thereunder except with the previous sanction of the Commissioner, and no court
inferior to that of a Judicial Magistrate of first class shall try any such offence.
2 of 1974.

(2) Notwithstanding anything contained in the Code of Criminal Procedure, 1973 all
offences punishable under this Regulation or the rules made there under shall be cognizable
and bailable.
102. (1) Subject to such conditions as may be prescribed, the Commissioner may
authorise either generally or in respect of a particular case or class of cases any officer or
person subordinate to him to investigate all or any of the offences punishable under this
Regulation.

2 of 1974.

Cognizance of
offences.

Investigation
of offences.

(2) Every officer or person so authorised shall, in the conduct of such investigation,
exercise the powers conferred by the Code of Criminal Procedure, 1973 upon an officer
in-charge of a police station for the investigation of a cognizable offence.
103. (1) The Commissioner may, before the institution of proceedings for any offence
punishable under sub-section (4) of section 89 or under any rules made under this Regulation,
accept from any person charged with such offence by way of composition of offence, an
amount not exceeding fifty thousand rupees or a sum not exceeding three times the amount
of tax which would thereby have been avoided, whichever is higher.

Compounding
of offences.

(2) On payment of such sum as may be determined by the Commissioner under
sub-section (1), no further proceedings shall be taken against such person in respect of the
same offence.
2 of 1974.

104. Nothing contained in Chapter XXXVI of the Code of Criminal Procedure, 1973,
shall apply to—
(a) any offence punishable under this Regulation; or
(b) any other offence which under the provisions of that Code may be tried
along with such offence,
and every offence referred to in clause (a) or clause (b) may be taken cognizance of by the
court having jurisdiction under this Regulation as if the provisions of that Chapter were not
enacted.

Chapter
XXXVI of the
Code of
Criminal
Procedure,
1973, not to
apply in
certain case.

<!-- page 59 -->

58

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

CHAPTER XIV
MISCELLANEOUS
Dealer to
declare the
name of
manager of
business,
Permanent
Account
Number and
Importer
Exporter
Code.

105. (1) Every dealer being an association of persons or club or society or firm or
company or any person or body who is engaged in business as the guardian or trustee or
otherwise on behalf of another person, and who is liable to pay tax under this Regulation,
shall, within the period prescribed, furnish a declaration in the manner prescribed, stating the
name of the person or persons who shall be deemed to be the manager or managers of such
person's business for the purposes.
(2) The declaration furnished under sub-section (1) may be revised from time to time as
required.
(3) Every dealer at the time of applying for registration under this Regulation shall
mention the Permanent Account Number obtained under the Income-tax Act, 1961:
Provided that the dealers already registered under this Act shall intimate their Permanent
Account Number obtained under the Income-tax Act, 1961 in the prescribed form, within a
period of two months from the date of issuance of notification of this amendment.
(4) Every dealer liable to pay tax under this Regulation and having an Importer Exporter
Code under the provisions of the Foreign Trade (Development and Regulation) Act, 1992,
shall mention the Importer Exporter Code, at the time of applying for registration under this
Regulation:
Provided that the dealers already registered under the Act and having Importer Exporter
Code under the provisions of the Foreign Trade (Development and Regulation) Act, 1992,
shall intimate the details in the prescribed form, within a period of two months from the date
of issuance of notification of this amendment:
Provided further that every dealer registered under the Act, who obtains an Importer
Exporter Code under the provisions of the Foreign Trade (Development and Regulation)
Act, 1992, subsequently shall provide the Code details in the prescribed form, within a period
of fifteen days from the date of obtaining such Code.
(5) Any person who fails to furnish a declaration or, as the case may be, a revised
declaration as provided in sub-section (1) and sub-section (2) or fails to provide details of
the Permanent Account Number obtained under the Income-tax Act, 1961, as provided in
sub-section (3) or fails to provide the Importer Exporter Code under the provisions of the
Foreign Trade (Development and Regulation) Act, 1992 as provided in sub-section (4), shall
be liable to pay a penalty of an amount equal to one thousand rupees per week of default
subject to a maximum of fifty thousand rupees.

Service of
notice when
family is
disrupted or
firm is
dissolved.

106. (1) Where a Hindu Undivided Family has been partitioned, notices under this
Regulation shall be served on the person who was the last manager of the Hindu Undivided
Family, or if such person cannot be found, then, on all adults who were members of the Hindu
Undivided Family, immediately before the partition.

Service of
notice in the
case of
discountinued
business.

107. Where an assessment is to be made in respect of business which has been
discontinued, a notice under this Regulation shall be served in the case of a firm or an
association of persons or any person who was a member of such firm or association at the
time of its discontinuance or in the case of a company on the principal officer thereof.

Return, etc.,
to be
confidential.

108. (1) All the particulars contained in any statement made, return furnished or
accounts or documents produced in accordance with this Regulation, or in any record of
evidence given in the course of any proceedings under this Regulation, other than proceedings
before a criminal court, shall, save as provided in sub-section (3), be treated as confidential,

(2) Where a firm or an association of persons is dissolved, notices under this Regulation
may be served on any person who was a partner (not being a minor) of the firm, or member of
association, as the case may be immediately before its dissolution.

43 of 1961.

43 of 1961.

22 of 1992.

22 of 1992.

22 of 1992.

43 of 1961.
22 of 1992.

<!-- page 60 -->

SEC. 1]
1 of 1872.

THE GAZETTE OF INDIA EXTRAORDINARY

59

and notwithstanding anything contained in the Indian Evidence Act, 1872, no court shall,
save as aforesaid, be entitled to require any servant of the Government to produce before it
any such statement, return, account, document or record or any part thereof, or to give
evidence before it in respect thereof.
(2) If, save as provided in sub-section (3), any servant of the Government discloses
any of the particulars referred to in sub-section (1), he shall be punishable with imprisonment
for a term which may extend to six months, and shall also be liable to a fine.
(3) Nothing contained in this section shall apply to the disclosure—

45 of 1860.

(a) of any of the particulars referred to in sub-section (1) for the purposes of
investigation or prosecution under this Regulation or the Indian Penal Code or any
other enactment for the time being in force;
(b) of such facts to an officer of the Central Government or any State Government
as may be necessary for the verification of such facts or for the purposes of enabling
that Government to levy or realise any tax imposed by it;
(c) of any such particulars where such disclosure is occasioned by the lawful
employment under this Regulation of any process for the service of any notice or the
recovery of any demand;
(d) of any such particulars to a civil court in any suit or proceeding to which the
Government or any Value Added Tax authority is a party and which relates to any
matter arising out of any proceeding under this Regulation or under any other law for
the time being in force authorising any Value Added Tax authority to exercise any
powers thereunder;

2 of 1899.

(e) of any such particulars by any public servant where the disclosure is
occasioned by the lawful exercise by him of his powers under the Indian Stamp Act,
1899 to impound an insufficiently stamped document;
(f) of any such particulars to the Reserve Bank of India as are required by that
Bank to enable it to compile financial statistics of international investment and balance
of payment;
(g) of any such particulars to any officer appointed by the Comptroller and
Auditor-General of India for the purpose of audit of tax receipts or refunds;
(h) of any such particulars relevant to any inquiry into a charge of misconduct in
connection with income-tax proceedings against a legal practitioner or chartered
accountant, to the authority empowered to take disciplinary action against members
of the profession to which he belongs;
(i) of such particulars to the officers of the Central Government or any State
Government for such other purposes, as the Government may, by general or special
order, direct; or
(j) of any information relating to a class of dealers or class of transactions, if, in
the opinion of the Commissioner it is desirable in the public interest to publish such
information.
109. (1) The tax imposed by section 3 applies to every—
(a) sale, including an instalment sale and hire purchase of goods, made on and
after the date of commencement of this Regulation;
(b) sale in the form of the transfer of a right to use goods, to the extent that the
right to use goods is exercised after the date of commencement of this Regulation.
(2) Tax credits arising under section 9 shall be allowed for—
(a) a purchase, including a purchase under an installment sale and hire purchase
of goods, made on and after the date of commencement of this Regulation; and

Application to
sales and
purchases.

<!-- page 61 -->

60

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(b) a purchase occurring in the form of the acquisition of a right to use goods, to
the extent that the right to use goods is exercised after the date of commencement of
this Regulation.
(c) where an amount is paid or received prior to the date of the commencement of this
Regulation, in respect of a sale or purchase occurring on or after the date of the commencement
of this Regulation and the person calculates his turnover or turnover of purchases based on
amounts paid and received, such amount shall be treated as forming part of the person's
turnover or turnover of purchases in the tax period in which the sale occurs.
Publication
and disclosure
of
information in
respect of
dealers and
other persons
in public
interests.

110. (1) Notwithstanding anything contained in this Regulation, if the Government is
of the opinion that it is necessary or expedient in the public interest to publish or disclose the
names of any dealers or other persons and any other particulars relating to any proceedings
under this Regulation in respect of such dealers and persons, it may publish or disclose or
cause to be published or disclosed such names and particulars in such manner as it thinks fit.

Power to
collect
statistics.

111. (1) If the Commissioner considers that for the purposes of the better administration
it is necessary so to do, he may, by notification in the Official Gazette, direct that statistics be
collected relating to any matter dealt with, by or in connection with this Regulation.

(2) No publication or disclosure under this section shall be made in relation to any tax
levied or penalty imposed or interest levied or any conviction for any offence connected
with any proceeding under this Regulation, until the time for presenting an appeal to the
appropriate appellate body has been expired without an appeal having been presented or the
appeal, if presented has been disposed of.

(2) Upon such direction being made, the Commissioner or any person or persons
authorised by him in this behalf may call upon all dealers or any class of dealers or persons
to furnish such information or statements as may be stated therein relating to any matter in
respect of which statistics are to be collected and the form in which the persons to whom or,
the authorities to which, such information or returns should be furnished, the particulars
which they should contain, and the intervals in which such information or returns should be
furnished, shall be such as may be prescribed:
Provided that the call for information may be made by notification in the Official
Gazette, by notice in newspapers or in such other manner as, in the opinion of the
Commissioner or the said person, is best calculated to bring to the attention of the dealers
and other persons.
(3) Without prejudice to the generality of the foregoing provisions, the Government
may by rules provide that every dealer or, as the case may be, any class of dealer shall furnish
such statements as may be prescribed, with the self assessment, and different provisions
may be made for different classes of dealers.
(4) (a) The Government may, by notification in the Official Gazette, provide that the
provisions contained in the Information Technology Act, 2000, as amended from time to time,
and the rules made and directions given under that Act, including the provisions relating to
digital signatures, electronic governance, attribution, acknowledgement and dispatch of
electronic records, secure electronic records and secure digital signatures and digital signature
certificates as are specified in the said notification, shall, in so far as they may, as far as
feasible, apply to the procedures under this Regulation.
(b) Where a notice or communication is prepared on any automated data processing
system and is properly served on any dealer or person, then, the said notice or communication
shall not be required to be personally signed by the Commissioner or any other officer
subordinate to him, and the said notice or communication shall not be deemed to be invalid
only on the ground that it is not personally signed by the Commissioner.
Setting up of
check-posts
and barriers.

112. The Government may, by notification in the Official Gazette, set up check-posts or
barriers, or both, at any place in Lakshadweep with a view to prevent evasion of tax and other
dues payable under this Regulation.

21 of 2000.

<!-- page 62 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

61

113. If the Government is of opinion that it is expedient in the interest of general public
so to do, it may, by notification in the Official Gazette, add to, or omit from, or otherwise
amend, the First, the Second, the Third and the Fourth Schedules, prospectively, and thereupon
the said Schedules shall be deemed to have been amended accordingly:

Power to
amend
Schedules.

Provided that no such amendment shall be made retrospectively if it would have the
effect of prejudicially affecting the interests of a dealer.
114. (1) The Government may, by notification in the Official Gazette and subject to the
condition of previous publication hereby makes the rules not inconsistent with the provisions
of this Regulation to carry out the provisions and purposes of this Regulation.

Power to
make rules.

(2) Every rule made under this Regulation shall be be laid, as soon as may be after it is
made, before each House of Parliament while it is in session, for a total period of thirty days
which may be comprised in one session, or in two or more successive sessions, and if, before
the expiry of the session immediately following the session or the successive sessions
aforesaid, both Houses agree in making any modification in the rule or both Houses agree
that the rule should not be made, the rule shall thereafter have effect only in such modified
form or be of no effect, as the case may be; so, however, that any such modification or
annulment shall be without prejudice to the validity of anything previously done under that
rule.
115. (1) If any difficulty arises in giving effect to the provisions, the Government may,
by general or special order published in the Official Gazette, make such provisions not
inconsistent with the provisions of this Regulation as may appear to it to be necessary or
expedient for the removal of the difficulty:
Provided that no such order shall be made under this section after the expiry of two
years from the date of commencement of this Regulation.
(2) Every order made under this section shall be laid, as soon as may be after it is made,
before each House of Parliament.

Power to
remove
difficulties.

<!-- page 63 -->

62

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

THE FIRST SCHEDULE
(See section 4)
LIST OF GOODS TO BE TAXED
Sl. No.

Description of Goods

Rate of Tax

(1)

(2)

(3)

1.

Petroleum Crude

10 per cent.

2.

High Speed Diesel

10 per cent.

3.

High Speed Diesel (Ship)

10 per cent.

4.

Motor Spirit (Commonly known as petrol)

10 per cent.

5.

Natural Gas

10 per cent.

6.

Aviation Turbine Fuel

10 per cent.

7.

Indian Made Foreign Liquor

10 per cent.

8.

Beer

10 per cent.

<!-- page 64 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

63

THE SECOND SCHEDULE
(See section 6)
LIST OF GOODS TO BE EXEMPTED
Sl. No.

Description of Goods

Rate of Tax

(1)

(2)

(3)
Nil

<!-- page 65 -->

64

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

THE THIRD SCHEDULE
[See section 9(1)(b)]
NON CREDITABLE GOODS
Sl. No.

Description of Goods

Rate of Tax

(1)

(2)

(3)
Nil

<!-- page 66 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

65

THE FOURTH SCHEDULE
[See section 41(1)]
BODIES ENTITLED TO CLAIM A REFUND OF TAX PAID ON GOODS PURCHASE
Sl. No.

Name of Organisation

Conditions

(2)

(3)

(1)

Nil

————

DROUPADI MURMU,
President.

————

K. BISWAL,
Additional Secretary to the Govt. of India.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
JAGANATHA

Digitally signed by
JAGA NAT HA N

N ANANTHA ANA NT HA K UMA R
Date : 2022.09.20
KUMAR
09:31 :05 +05 '30 '

MGIPMRND—1035GI(S3)—19-09-2022.

<!-- page 67 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—22

REGISTERED

NO.

DL—(N)04/0007/2003—22

सी.जी.-डी.एल.-अ.-20092022-238922
xxxGIDHxxx
CG-DL-E-20092022-238922
xxxGIDExxx

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 21]

ubZ fnYyh] lkseokj] flrEcj 19] 2022@ Hkknzin 28] 1944 ¼'kd½

No. 21]

NEW DELHI, MONDAY, SEPTEMBER 19, 2022/BHADRA 28, 1944 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 19th September, 2022/Bhadra 28, 1944 (Saka)

THE LAKSHADWEEP (RIGHT TO PUBLIC SERVICES)
REGULATION, 2022
NO. 2 OF 2022
Promulgated by the President in the Seventy-third Year of the Republic of' India.
A Regulation to lay down an obligation upon every public authority in the Union territory
of Lakshadweep to provide for timely delivery of public services to the eligible
persons and for grievance redressal mechanism in case of default and for matters
connected therewith or incidental thereto.
In exercise of the powers conferred by article 240 of the Constitution, the President
is pleased to promulgate the following Regulation made by her:—
CHAPTER I
PRELIMINARY
1. (1) This Regulation may be called the Lakshadweep (Right to Public Services)
Regulation, 2022.
(2) It shall come into force on such date as the Administrator may, by notification in the
Official Gazette, appoint; and different dates may be appointed for different provisions of
this Regulation.

Short title and
commencement.

<!-- page 68 -->

2
Definitions.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

2. In this Regulation, unless the context otherwise requires,—
(a) "Administrator" means the Administrator of the Union territory of
Lakshadweep appointed by the President under article 239 of the Constitution;
(b) "Appellate Authority" means a Union territory Appellate Authority
constituted under sub-section (1) of section 12;
(c) "complaint" means a complaint filed by an eligible person regarding any
grievance relating to, or arising out of, any failure in rendering of services as notified
in section 4 or in the functioning of a public authority, but does not include grievance
relating to the service matters of a public servant whether serving or retired;
(d) "Designated Authority" means the officers designated by the public authority
under sub-section (1) of section 9;
(e) "Designated Officer" means an officer whose name is published under
sub-section (1) of section 5 for rendering of services;
(f) "eligible person" means a person who is eligible for obtaining the services
notified under section 4;
(g) "Grievance Redressal Officer" means a Grievance Redressal Officer designated
as such under sub-section (1) of section 6;
(h) "member" means a person appointed as a member of the Union territory
Appellate Authority under sub-section (2) of section 12;
(i) "notification" means a notification published in the Official Gazette and the
term "notify" or "notified" shall be construed accordingly;
(j) "prescribed" means prescribed by rules made by the Administrator under
section 29;
(k) "public authority" means any authority or body or institution of Government
established or constituted,—
(i) by or under the Constitution in the Union territory of Lakshadweep;
(ii) by any other law made by Parliament;
(iii) by notification issued or order made by the Administrator, and includes
any,—
(a) body owned, controlled or substantially financed by funds
provided by the Administrator;
(b) non-Government organisation substantially financed directly or
indirectly by funds provided by the Administrator;
(c) an organisation or body corporate in its capacity as an
instrumentality of "State" as defined under article 12 of the Constitution
and rendering services of public utility in the Union territory of
Lakshadweep;
(d) a Government company as defined under clause (45) of
section 2 of the Companies Act, 2013, which is a State Public Sector
Undertaking;
(e) any other company which supplies goods or renders services to
the Union territory in pursuance of an obligation imposed under any
Central Act or State Act or under licence or authorisation under any law
for the time being in force;
(iv) by an agreement or memorandum of understanding between the Union
territory and any private entity as Public Private Partnership or otherwise;

18 of 2013.

<!-- page 69 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(l) "service" means all the goods and services, including functions, obligations,
responsibility or duty, to be provided or rendered by a public authority;
(m) "Union territory" means the Union territory of Lakshadweep.
CHAPTER II
RIGHT TO DELIVERY OF SERVICES
3. Subject to the provisions of this Regulation, every eligible person shall have the
right to time bound delivery of services and redressal of grievances.

Right to
services.

4. The Administrator may, from time to time, notify the services to which this Regulation
shall apply and the stipulated time limits within which the services shall be provided.

Notification
of services by
Administrator.

5. (1) A public authority shall, within two months of the notification issued under
section 4, publish the names and addresses of Designated Officers responsible for
rendering of services notified under section 4.

Obligation of
public
authority to
publish names
of Designated
Officers
responsible for
rendering
services.

(2) It shall be the duty of the Designated Officer to provide public services to
the eligible persons within the time limit as specified in the notification issued under
section 4.
CHAPTER III
GRIEVANCE REDRESSAL OFFICERS
6. (1) Every public authority shall designate as many officers as may be necessary as
Grievance Redressal Officers in all departments, administrative units or offices in the Union
territory, notified areas, panchayats and such other offices where services are rendered to
receive, enquire into and redress any complaints from eligible persons in such manner as
may be prescribed:

Grievance
Redressal
Officers.

Provided that the Grievance Redressal Officer so designated shall be an officer of the
level as may be prescribed.
(2) Every public authority shall display at its office or its website or customer care
centre or help desk or Jan Seva Kendra and at the sales outlet, if any, and at the office of the
Grievance Redressal Officer, the name of the Grievance Redressal Officer, his address and
telephone number, E-mail address, facsimile number and other means, if any, of contacting
him.
(3) Every public authority shall designate such number of Grievance Redressal Officers
under sub-section (1) for such areas, as it may consider necessary, for the Grievance Redressal
Officer to be easily accessible and available for redressal of grievance of the public.
(4) Where a complainant is unable to make a complaint in writing, the Grievance
Redressal Officer shall render all reasonable assistance to the person making the request
orally to reduce the same in writing.
7. The Grievance Redressal Officer shall, within three working days of receipt of the
complaint, acknowledge such receipt, in writing or through electronic means or through text
message or through any other means as may be prescribed, specifying the date, time, place,
unique complaint number and particulars of receiver of complaint along with the stipulated
time frame within which the complaint shall be redressed.

Acknowledgement
of complaint
by receipt
thereof.

8. (1) Upon receipt of a complaint under section 6, it shall be the duty of the concerned
Grievance Redressal Officer to ensure that,—

Duties of
Grievance
Redressal
Officer.

(a) the grievance is remedied within such time as may be prescribed;
(b) the reason for the grievance is identified, the grievance is redressed
satisfactorily and the responsibility, if any, of the defaulting person is fixed;

<!-- page 70 -->

4

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(c) where the grievance has occurred as a result of a deficiency, negligence or
malfeasance on the part of an individual, action is taken in accordance with the
applicable rules; and
(d) where the Grievance Redressal Officer is convinced that the Designated
Officer responsible for the rendering of the services has wilfully neglected to render
the service or there exists prima facie grounds for a case under the Prevention of
Corruption Act, 1988, the Grievance Redressal Officer shall make an observation to
that effect and refer the same to the appropriate authority in writing.

49 of 1988.

(2) The Grievance Redressal Officer shall ensure that the complainant is informed in
writing the manner in which his grievance is redressed.
(3) The Grievance Redressal Officer shall, within such time as may be prescribed,
report every complaint which has not been redressed along with the details of the
complainant, nature of complaint, and reasons for non-redressal of the complaint to the
Designated Authority referred to in section 9.
CHAPTER IV
DESIGNATED AUTHORITY
Designated
Authority.

9. (1) Every public authority shall designate such officers as Designated Authorities in
all its administrative units and offices as it may deem necessary who shall hear complaints
referred to it under sub-section (3) of section 8.
(2) Every complaint received by the Designated Authority under sub-section (3) of
section 8 shall be deemed to be an appeal before such authority.
(3) Any person aggrieved by a decision of the concerned Grievance Redressal Officer
or who has not been informed in writing the manner in which his grievance has been redressed
in respect of a complaint filed by him may, within thirty days from the expiry of such decision
or from the receipt of such decision, prefer an appeal to the Designated Authority:
Provided that the Designated Authority may admit the appeal after the expiry of thirty
days if it is satisfied that the complainant was prevented by sufficient cause from filing the
appeal in time.
(4) The receipt of an appeal under sub-section (3) shall be acknowledged by the
Designated Authority in writing or through electronic means or through text message or
through any other means as may be prescribed, within three working days.
(5) Every appeal filed under sub-section (3) or deemed appeal under sub-section (2)
shall be disposed of by the Designated Authority within such time as may be prescribed.
(6) The Designated Authority shall arrange to deliver copies of the decision to the
parties concerned within such time as may be prescribed.

Other powers
of Designated
Authority.

10. (1) Where it appears to the Designated Authority that the grievance complained of
is prima facie indicative or representative of a corrupt act or practice in terms of the Prevention
of Corruption Act, 1988 on the part of the officer complained against, then it shall record in
writing such evidence as may be found in support of such conclusion and shall in writing
refer the same to the appropriate authority.
(2) The Designated Authority shall upon adjudication of a complaint have the
powers to issue directions requiring the concerned officers of the public authority to
take such steps as may be necessary to render the services in compliance of the
notification issued under section 4.

49 of 1988.

<!-- page 71 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

5

CHAPTER V
UNION TERRITORY APPELLATE AUTHORITY
11. (1) Any person who does not receive a decision within such time as may be
prescribed or is aggrieved by a decision of the Designated Authority may, within thirty days
from the expiry of such period or from the receipt of such a decision, prefer an appeal to the
Union territory Appellate Authority:

Appellate
Authority.

Provided that the Appellate Authority may admit the appeal after the expiry of thirty
days if it is satisfied that the complainant was prevented by sufficient cause from filing the
appeal in time.
(2) The decision of the Appellate Authority under this section shall be binding.
12. (1) The Administrator shall, by notification in the Official Gazette, constitute one or
more Union territory Appellate Authority to exercise the powers conferred on or imposed
upon and to perform the functions assigned to it under this Regulation.
(2) A Union territory Appellate Authority shall consist of such number of members,
not exceeding three, as may be prescribed.

Constitution
of Union
territory
Appellate
Authority.

13. A person shall not be qualified for appointment as a member of Appellate Authority
unless he is or has been an officer holding or has held a post in the rank of, or equivalent to,
a Secretary or Principal Secretary or Additional Chief Secretary or Chief Secretary to the
Union territory Administration.

Qualifications
for
appointment
as member of
Appellate
Authority.

14. (1) A person appointed as member of Appellate Authority shall hold the office for
a term of three years from the date on which he enters upon office or until he attains the age
of sixty-five years, whichever is earlier.

Term and
other
conditions of
service of
member of
Appellate
Authority.

(2) The salary and allowances payable to and the other terms and conditions of service
of a member of the Appellate Authority shall be such as may be prescribed:
Provided that if a member at the time of his appointment is in receipt of a pension, other
than a disability or widow pension in respect of any previous service under the Union
territory, his salary in respect of the service as member of Appellate Authority shall be
reduced by the amount of that pension, including any portion of pension which was
commuted and pension equivalent of other forms of retirement benefits excluding pension
equivalent or retirement gratuity:
Provided further that where a member, if at the time of his appointment, is in receipt of
retirement benefits in respect of any previous service rendered in a Corporation established
by or under any State Act or a Government company owned or controlled by the Union
territory Administration, his salary in respect of the service as a member shall be reduced by
the amount of pension equivalent to the retirement benefit:
Provided also that neither the salary and allowances nor the other terms and conditions
of service of a member of Appellate Authority shall be varied to his disadvantage after the
appointment.
15. (1) Any member of the Appellate Authority, may, by notice in writing under his
hand addressed to the Administrator, resign his office.
(2) Notwithstanding anything contained in sub-section (1), the Administrator may by
order remove from office a member if the member,—
(i) is adjudged an insolvent; or
(ii) has been convicted of an offence which, in the opinion of the Administrator
involves moral turpitude; or

Resignation
and removal.

<!-- page 72 -->

6

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

(iii) engages during his term of office in any paid employment outside the duties
of his office; or
(iv) is, in the opinion of the Administrator, unfit to continue in office by reason
of infirmity of mind or body; or
(v) has acquired such financial or other interest as is likely to affect prejudicially
his functions as a member.
Powers of
Appellate
Authority.

16. (1) The Appellate Authority shall, for the purposes of its functions under this
Regulation, have the same powers as are vested in a civil court under the Code of Civil
Procedure, 1908, in respect of the following matters, namely:—

5 of 1908.

(i) summoning and enforcing the attendance of any person and examining him
on oath;
(ii) discovery and production of any document or other material object producible
as evidence;
(iii) receiving evidence on affidavits;
(iv) requisitioning of any public record;
(v) issuing commission for the examination of witnesses; and
(vi) such other matter which may be prescribed.
(2) The Appellate Authority shall not be bound by the procedure laid down in the
Code of Civil Procedure, 1908, but shall be guided by the principles of natural justice and
subject to the other provisions of this Regulation and of any rules made thereunder, the
Appellate Authority shall have the power to regulate its own procedure.
Delivery of
copies of
decision.

17. The Appellate Authority shall arrange to deliver copies of its decision to the
parties concerned within such time as may be prescribed.

Other powers
of Appellate
Authority.

18. (1) The Appellate Authority shall, upon adjudication of a complaint, have the
power to issue directions requiring the public authority to take such steps as may be necessary
to render the services in compliance of the notification issued under section 4.

5 of 1908.

(2) It shall be the duty of the Appellate Authority to receive and inquire into a complaint
from any person—
(a) who has been unable to submit an appeal to the Designated Authority;
(b) who has been refused redress of grievance under this Regulation;
(c) whose complaint has not been disposed of within the specified time limit; and
(d) in respect of any other matter relating to registering and redressing of a
complaint or appeal under this Regulation.
Burden of
proof to be on
Grievance
Redressal
Officer.

19. In any appeal proceedings, the burden of proof to establish the non-redressal of
complaint, shall be on the Grievance Redressal Officer who denied the request.

Where
grievance
complained of
is a result of
corrupt
practices.

20. Where it appears to the Appellate Authority that the grievance complained of
is prima facie indicative of a corrupt act or practice in terms of the Prevention of
Corruption Act, 1988 on the part of the responsible officer of the public authority
complained against, then it shall record such evidence as may be found in support of
such conclusion and shall refer the same to the appropriate authority.

49 of 1988.

<!-- page 73 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

7

CHAPTER VI
PENALTIES AND COMPENSATION
21. (1) The Appellate Authority or the Designated Authority may impose a penalty on
the Designated Officer responsible for rendering of service to the eligible person or Grievance
Redressal Officer for failing to discharge his duties without any sufficient and reasonable
cause.

Penalty and
compensation.

(2) The penalty to be imposed on the Designated Officer or Grievance Redressal
Officer under sub-section (1) shall not be less than one thousand rupees but may extend to
ten thousand rupees, which shall be recovered from the salary of the officer against whom
penalty has been imposed:
Provided that the concerned Designated Officer or Grievance Redressal Officer, as the
case may be, shall be given a reasonable opportunity of being heard before any penalty is
imposed on him under this section.
(3) On imposition of the penalty under sub-section (1), the Appellate Authority or the
Designated Authority, as the case may be, may by order, direct that such portion of the
penalty imposed under sub-section (1) shall be awarded to the appellant as compensation,
as it may deem fit:
Provided that the amount of such compensation awarded shall not exceed the
amount of penalty imposed under this section.
CHAPTER VII
MISCELLANEOUS
22. (1) Every public authority shall ensure that every Grievance Redressal Officer
keeps a record of complaints made to it or appeal therein and the decisions on such complaints
and appeals under this Regulation.

Reporting
requirements.

(2) Every public authority shall publish, in such manner and within such time as may
be prescribed, a report mentioning therein—
(a) the number of appeals and complaints received;
(b) the number of appeals and complaints disposed of;
(c) the number of appeals and complaints pending; and
(d) such other particulars, as may be prescribed, for discharge of its functions
under this Regulation.
23. (1) The Administrator shall provide to the Appellate Authority with such officers
and employees as may be necessary for efficient performance of its functions under this
Regulation.

Officers and
employees of
Appellate
Authority.

(2) The officers and employees so appointed under sub-section (1) shall discharge
their functions under the general superintendence of the Appellate Authority.
45 of 1860.

24. The officers and employees of the Appellate Authority shall be deemed to be
public servants within the meaning of section 21 of the Indian Penal Code.

Officers and
employees of
Appellate
Authority to
be public
servants.

25. No civil court shall have jurisdiction to settle, decide or deal with any question or
to determine any matter which is by or under this Regulation required to be settled, decided
or dealt with or to be determined by the Grievance Redressal Officer or the Designated
Authority or the Appellate Authority.

Bar of
Jurisdiction of
court.

<!-- page 74 -->

8
Enforcement
of orders by
Appellate
Authority.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

26. Every order made by the Appellate Authority may be enforced by it in the same
manner as if it were a decree or order made by a court in a suit pending therein and it shall be
lawful for the Appellate Authority to send, in the event of its inability to execute it, such
order to the court within the local limits of whose jurisdiction,—
(a) in the case of public authority not falling under clauses (b) and (c), the place
at which the main office of such public authority is situated; or
(b) in the case of an order against a public authority being a company, the
registered office of the company is situated; or
(c) in the case of an order against any other person, the place where the person
concerned voluntarily resides or carries on business or personally works for gain is
situated, and thereupon, the court to which the order is so sent, shall execute the order
as if it were a decree or order sent to it for execution.

Protection of
action taken
in good faith.

27. No suit, prosecution or other legal proceedings shall lie against any person for—
(a) anything which is in good faith done or intended to be done, in pursuance of
this Regulation or any rule made thereunder; or
(b) delay in rendering of service or not being able to render service where such
delay or inability is on account of reasonable cause beyond the control of the person
responsible for delivery of the service.

Provisions to
be in addition
to existing
laws.

28. The provisions of this Regulation shall be in addition to and not in derogation of
any other law for the time being in force.

Power to
make rules.

29. (1) The Administrator may, by notification in the Official Gazette, make rules, not
inconsistent with this Regulation, for carrying out the purposes of this Regulation.
(2) In particular and without prejudice to the generality of the foregoing provisions,
such rules may provide for all or any of the following matters, namely:—
(i) the manner of receipt, enquiry, redressal of complaints and the level of officer
to be designated as Grievance Redressal Officer under sub-section (1) of section 6;
(ii) the manner of acknowledgement of complaints received, particulars of receiver
of complaint and time frame for redressal of complaint under section 7;
(iii) the time within which grievances shall be redressed by the Grievance
Redressal Officer under sub-section (1) and time within which report shall be made by
him to the Designated Authority of complaints which are not redressed under subsection (3), of section 8;
(iv) the other means of acknowledgement under sub-section (4), the time within
which an appeal may be disposed of under sub-section (5) and the time within which
copies of the decision shall be delivered under sub-section (6), of section 9;
(v) the time within which the Designated Authority shall deliver copies of the
decision to the parties concerned under sub-section (1) of section 11;
(vi) the number of members of the Union territory Appellate Authority under
sub-section (2) of section 12;
(vii) the salary and allowances payable to and the other terms and conditions of
service of a member of the Union territory Appellate Authority under sub-section (2)
of section 14;
(viii) the other matters for which the Union territory Appellate Authority shall
have power of civil court under clause (vi) of sub-section (1) of section 16;

<!-- page 75 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

9

(ix) the time within which the Appellate Authority shall arrange to deliver copies
of its decision to the parties concerned under section 17;
(x) the manner and the time within which the public authority shall publish a
report and other particulars for discharge of functions of the public authority under
sub-section (2) of section 22;
(xi) any other matter which is or may be provided by rules under this Regulation.
(3) Every rule made under this section shall be laid, as soon as may be after it is made,
before each House of Parliament, while it is in session, for a total period of thirty days which
may be comprised in one session or in two or more successive sessions, and if, before the
expiry of the session immediately following the session or the successive sessions aforesaid,
both Houses agree in making any modification in the rule or both Houses agree that the rule
should not be made, the rule shall thereafter have effect only in such modified form or be of
no effect, as the case may be; so, however, that any such modification or annulment shall be
without prejudice to the validity of anything previously done under that rule.
30. If any difficulty arises in giving effect to the provisions of this Regulation, the
Administrator may, by order published in the Official Gazette, make such provisions not
inconsistent with the provisions of this Regulation as may appear to be necessary for
removing the difficulty:

Power to
remove
difficulties.

Provided that no order shall be made under this section after expiry of two years from
the commencement of this Regulation.

————

DROUPADI MURMU,
President.

————

K. BISWAL,
Additional Secretary to the Govt. of India.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
MGIPMRND—1036GI(S3)—19-09-2022.

tally si gned b y
JAGANATHA JDigi
A G A NA T HA N
N ANANTHA A NA NT HA K UMAR
Dat e: 2022. 09.20
KUMAR
09: 29: 18 +05' 30'

<!-- page 76 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—22

REGISTERED NO. DL—(N)04/0007/2003—22

सी.जी.-डी.एल.-अ.-20092022-238923
xxxGIDHxxx
CG-DL-E-20092022-238923
xxxGIDExxx

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 22]

ubZ fnYyh] lkseokj] flrEcj 19] 2022@ Hkknzin 28] 1944 ¼'kd½

No. 22]

NEW DELHI, MONDAY, SEPTEMBER 19, 2022/BHADRA 28, 1944 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 19th September, 2022/Bhadra 28, 1944 (Saka)

THE LAKSHADWEEP BUILDING DEVELOPMENT BOARD (REPEAL)
REGULATION, 2022
NO. 3 OF 2022
Promulgated by the President in the Seventy-third Year of the Republic of India.
A Regulation to repeal the Lakshadweep Building Development Board Regulation, 1997
in force in the Union territory of Lakshadweep.
In exercise of the powers conferred by article 240 of the Constitution, the President is
pleased to promulgate the following Regulation made by her:—
1. (1) This Regulation may be called the Lakshadweep Building Development Board
(Repeal) Regulation, 2022.
(2) It shall come into force at once.

Short title and
commencement.

<!-- page 77 -->

2
Repeal of
Regulation and
savings.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—SEC. 1]

2. (1) The Lakshadweep Building Development Board Regulation, 1997 is hereby
repealed.

1 of 1997.

(2) The repeal of the Regulation shall not—
(a) affect any other enactment or Regulation in which the repealed Regulation
has been applied, incorporated or referred to;
(b) affect any principle or rule of law, or established jurisdiction, form or course
of pleading, practice or procedure, or existing usage, custom, privilege, restriction,
exemption, office or appointment, notwithstanding that the same respectively may
have been in any manner affirmed or recognised or derived by, in or from any Regulation
hereby repealed;
(c) revive or restore any jurisdiction, office, custom, liability, right, title, privilege,
restriction, exemption, usage, practice, procedure or other matter or thing not now
existing or in force;
(d) affect the previous operation of any law so repealed or anything duly done or
suffered thereunder;
(e) affect any right, privilege, obligation or liability acquired, accrued or incurred
under this Regulation so repealed;
(f) affect any penalty, forfeiture or punishment incurred in respect of any offence
committed against this Regulation so repealed;
(g) affect any investigation, legal proceeding or remedy in respect of any such
right, privilege, obligation, liability, penalty, forfeiture or punishment as aforesaid, and
any such investigation, legal proceeding or remedy may be instituted, continued or
enforced and any such penalty, forfeiture or punishment may be imposed, as if this
Regulation had not been made;
(h) affect any duty, or fee levied, assessed or collected or purported to have
been levied, assessed or collected under this Regulation under repeal, before the
commencement of the Regulation, shall be deemed to have been validly levied, assessed
or collected in accordance with law:
Provided that anything done or any action taken (including any appointment or
delegation made, notification, instruction or direction issued, form, bye-law or scheme framed,
certificate obtained, patent permit or licence granted, or registration effected) under this
Regulation under repeal, shall be deemed to have been done or taken under the corresponding
provision of this Regulation and shall continue to be in force accordingly unless and until
superseded by anything done or any action taken under the said Regulation.
(3) The mention of particular matters referred to in sub-section (2) shall not be held to
prejudice or affect the general application of section 6 of the General Clauses Act, 1897 with
regard to the effect of repeal.

10 of 1897.

————
DROUPADI MURMU,
President.
————
K. BISWAL,
Additional Secretary to the Govt. of India.
UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
MGIPMRND—1037GI(S3)—19-09-2022.

itally sig ned by
JAGANATHA DigJAGANATHAN
N ANANTHA ANANTHA KUMAR
Date: 2022.09.20
KUMAR
09:27:46 +05'30'

<!-- page 78 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—22

REGISTERED NO. DL—(N)04/0007/2003—22

सी.जी.-डी.एल.-अ.-20092022-238924
xxxGIDHxxx
CG-DL-E-20092022-238924
xxxGIDExxx

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 23]

ubZ fnYyh] lkseokj] flrEcj 19] 2022@ Hkknzin 28] 1944 ¼'kd½

No. 23]

NEW DELHI, MONDAY, SEPTEMBER 19, 2022/BHADRA 28, 1944 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 19th September, 2022/Bhadra 28, 1944 (Saka)

THE LAKSHADWEEP CO-OPERATIVE SOCIETIES
REGULATION, 2022
NO. 4 OF 2022
Promulgated by the President in the Seventy-third Year of the Republic of India.
A Regulation for registration, incorporation and management of Co-operative Societies
in the Union territory of Lakshadweep and to repeal the Laccadive, Minicoy and
Amindivi Islands Co-operative Societies Regulation, 1960 and for matters connected
therewith or incidental thereto.
In exercise of the powers conferred by article 240 of the Constitution, the President is
pleased to promulgate the following Regulation made by her:—
CHAPTER I
PRELIMINARY
1. (1) This Regulation may be called the Lakshadweep Co-operative Societies
Regulation, 2022.
(2) It extends to the whole of the Union territory of Lakshadweep.
(3) It shall come into force on such date as the Administrator may, by notification in the
Official Gazette, appoint.

Short title,
extent and
commencement.

<!-- page 79 -->

10
Definitions.

THE GAZETTE OF INDIA EXTRAORDINARY

[PART II—

2. In this Regulation, unless the context otherwise requires,—
(1) “Administration” means the Administration of the Union territory of
Lakshadweep;
(2) “Administrator” means the Administrator of the Union territory of
Lakshadweep, appointed by the President under article 239 of the Constitution;
(3) “auditor” means a certified auditor, who is authorised and appointed by the
Registrar to audit the accounts of the society.
Explanation.—For the purposes of this clause, the expression “certified auditor”
means a person who possesses the prescribed qualifications and is authorised by the
Registrar as an auditor under section 84;
(4) “authorised person” means any person duly authorised by the Registrar to
take action under the provisions of this Regulation;
(5) “Board” means the Board of Directors or the governing body of a co-operative
society, by whatever name called, to which the direction and control of the management
of the affairs of a society is entrusted;
(6) “bye-laws” means the registered bye-laws for the time being in force, and
includes a registered amendment of such bye-laws;
(7) “central bank” means a co-operative bank, the objects of which include the
creation of funds to be loaned to other societies, but does not include the urban cooperative bank;
(8) “Committee” means the Managing Committee or other governing body of a
society to which the direction and control of the management of the affairs of a society
is entrusted;
(9) “company” means a company as defined in the Companies Act, 2013 and
includes a banking company, any board, corporation or other corporate body,
constituted or established by any Central, State or Provincial Act for the purpose of
the development of any organisation;
(10) “co-operative bank” means a society registered under this Regulation
and carrying the business of banking as defined in clause (b) of sub-section (1) of
section 5 of the Banking Regulation Act, 1949;

18 of 2013.

10 of 1949.

(11) “co-operative election authority” means an authority constituted by the
Administrator under section 68;
(12) “co-operative society” means a society registered or deemed to be registered
under the regulations and rules or any other law relating to co-operative societies for
the time being in force in Union territory of Lakshadweep;
(13) “Deposit Insurance Corporation” means the Deposit Insurance and Credit
Guarantee Corporation established under section 3 of the Deposit Insurance and
Credit Guarantee Corporation Act, 1961;

47 of 1961.

(14) “dividend” means the amount paid, out of the profit of a society, to a
member in proportion to the shares held by such member;
(15) “federal society” means a society—
(a) not less than five members of which are themselves societies; and
(b) in which the voting rights are so regulated that the members which are
societies have not less than four-fifths of the total number of votes in the general
meeting of such society;
(16) “firm” means a firm registered under the Indian Partnership Act, 1932;

9 of 1932.

<!-- page 80 -->

SEC. 1]

THE GAZETTE OF INDIA EXTRAORDINARY

3

(17) “General Body” means the individuals or institutions obtaining membership
of respective societies;
(18) “Islands” means the Islands of the Union territory of Lakshadweep;
(19) “Liquidator” means a person appointed under section 108;
(20) “member” means a person joining in an application for the registration of a
co-operative society which is subsequently registered or a person duly admitted to
membership of a society after registration and includes a nominal, associate or
sympathiser member;

61 of 1981.

(21) “National Bank” means the National Bank for Agriculture and Rural
Development established under section 3 of the National Bank for Agriculture and
Rural Development Act, 1981;
(22) “officer” means a person elected or appointed by a society to any office of
such society according to its bye-laws and includes a Chairperson, Vice-Chairperson,
President, Vice-President, Managing Director, General Manager, Manager, Secretary,
Treasurer, Member of the Committee, and any other person elected or appointed under
this Regulation, the rules or the bye-laws, to give directions in regard to the business
of such society;
(23) “office bearer” means a President, Vice-President, Secretary or Treasurer of
a co-operative society and includes any other person to be elected by the board of any
co-operative society;
(24) “official assignee” means a person or body of persons appointed under
sub-section (2) of section 22;
(25) “Official Gazette” means the Official Gazette of the Union territory of
Lakshadweep;
(26) “prescribed” means prescribed by rules made under this Regulation;
(27) “rebate” means any payment made in cash or kind, out of the profits of a
society, to a member or any other person, on the basis of his contribution to the
business of the society;
(28) “Registrar” means a person appointed to be the Registrar of co-operative
societies under this Regulation and includes an Additional Registrar, Joint Registrar,
Deputy Registrar and Assistant Registrar;

2 of 1934.

(29) “Reserve Bank” means the Reserve Bank of India constituted under subsection (1) of section 3 of the Reserve Bank of India Act, 1934;
(30) “rules” means rules made under this Regulation;
(31) “society” means a co-operative society registered, or deemed to be registered,
under this Regulation;
(32) “society with limited liability” means a society having the liability of its
members limited by its bye-laws;
(33) “Tribunal” means the Union territory Co-operative Tribunal constituted
under section 123;
(34) “Union territory” means the Union territory of Lakshadweep.
CHAPTER II
REGISTRAR AND REGISTRATION
3. (1) For carrying out the purposes of this Regulation, the Administrator shall appoint
a person to be called the Registrar of co-operative societies for the Union territory.

Registrar and
officers and
their powers.
