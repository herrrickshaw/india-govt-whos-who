---
doc_id: "fd1f79eaddd6683b"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/08e187de586ba012d6566956e1c0582c.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Additional Charge of CLS Officer reg. (6 feb 2019)	 (Office Order- 03-19)"
date: "2019-02-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2322916fca7a8971"
---

<!-- page 1 -->

F.No.A-22012/01/2018-CLS.I(Part-I)
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan, Rafi Marg,
New Delhi, dated the b February, 2019

OFFICE ORDER No. 03 /2019
With the approval of Competent Authority, the additional charge of the post of
Dy.CLC(C), Kanpur is entrusted upon to Shri G. K. Mohapatra, Dy.CLC(C), Dehradun in
addition to his present posting with immediate effect till joining of a regular incumbent
or until further orders, whichever is earlier.
2.
Shri G. K. Mohapatra shall not be entitled for any additional remuneration in this
regard.

ZJ.W

(C.S. ~

Under Secretary to the Government of India
To

1. Shri G. K. Mohapatra, Dy.CLC(C), Dehradun
2. PS to MOS(L&E)/PPS to Secretary, L&E/PS to AS, L&E/PS to JS(RKG)/PA to
DS(CLS.I)
3. Chief Labour Commissioner (Central), New Delhi.
4. Director General, Labour Welfare, New Delhi
5. Adm.I, 0/oCLC(C), New Delhi
6. CLS.II (Vig) Section, Ministry of Labour & Employment, New Delhi.
7. Personal file of the Officer concerned/ spare copies
