---
doc_id: "fdbe27d8a5c5c08c"
source_url: "https://mnre.gov.in/static/uploads/2025/07/6e2f6b6e76dc0e94d24461f280b618cd.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Gazette Notification for Extension of Self Certification for SPV Inverters in MNRE Quality Control Order 2017 up to 31st December 2022 (852 kb)"
date: "2022-08-02"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "97480596baaab0a8"
---

<!-- page 1 -->

रजजस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-29072022-237716
xxxGIDHxxx
CG-DL-E-29072022-237716
xxxGIDExxx
ऄसाधारण
EXTRAORDINARY
भाग II—खण्ड 3—ईप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3370]
No. 3370]

नइ ददल्ली, िुक्रवार, जुलाइ 29, 2022/श्रावण 7, 1944
NEW DELHI, FRIDAY, JULY 29, 2022/SHRAVANA 7, 1944

नवीन और नवीकरणीय उजाा मंत्रालय
ऄजधसूचना
नइ ददल्ली, 28 जुलाइ, 2022
का.अ. 3535(ऄ).—यतः के न्द्र सरकार ने ऄनुसूची में सजममजलत छह ईत्पादों हेतु ददनांक 05.09.2017 के
का.अ. 2920 (ऄ) के तहत “सौर प्रकािवोल्टीय, प्रणाजलयााँ, ईपकरण और घटक वस्ट्तुएं (ऄजनवाया पंजीकरण की
अवश्यकता) अदेि, 2017” जारी दकया था, जजसके प्रभावी होने की तारीख 05.09.2018 थी और आसे ददनांक
12.10.2018 को भारत के राजपत्र में प्रकाजित का.अ. 5259(ऄ) के तहत संिोजधत दकया गया था। और यतः ददनांक
02.02.2022 को भारत के राजपत्र में प्रकाजित का.अ. 513(ऄ) के तहत एसपीवी आन्द्वटारों (मद 4-5) के जलए स्ट्वप्रमाणन को ददनांक 30.06.2022 तक बढाया गया था।
2. और यतः सीजमत परीक्षण सुजवधाओं की ईपलब्धता और ऄनुपालन के जलए ऄजधक समय की मांग को ध्यान
में रखते हुए, एसपीवी आन्द्वटार (मद 4-5) के गुणवत्ता जनयंत्रण अदेि, 2017 के कायाान्द्वयन को स्ट्व-प्रमाणन के अधार पर
आस िता के ऄध्यधीन ददनांक 30.06.2022 से 31.12.2022 तक बढाया जाता है दक ऐसे जवजनमााताओं के पास आन मदों के
जलए ईक्त अदेि में जवजनर्ददष्ट अइएस [मद सं. 4 के जलए अइएस 16221 (भाग 2): 2015/अइइसी 62109-2 : 2011
और मद सं. 5 के जलए अइएस 16169 : 2014/अइइसी 62116 : 2008] के ऄनुरूप वैध अइइसी प्रमाणपत्र हो और
मान्द्यताप्राप्त परीक्षण प्रयोगिालाओं से परीक्षण ररपोटा हो, तादक अदेिों का सुचारु कायाान्द्वयन हो सके ।
[फा. सं. 223/140/2017-अर एंड डी (गुणवत्ता जनयंत्रण)]
डॉ. ऄरुण कु मार जत्रपाठी, सलाहकार/वैज्ञाजनक ‘जी’
5132 GI/2022

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF NEW AND RENEWABLE ENERGY
NOTIFICATION
New Delhi, the 28th July, 2022
S. O. 3535(E).—Whereas the Central Government had issued “Solar Photovoltaics, Systems,
Devices and Components Goods (Requirements for Compulsory Registration) Order, 2017” vide S.O. 2920
(E) dated 5.9.2017 for six products included in the Schedule with the date of coming into force with effect
from 5.9.2018 and the same was modified vide S.O. 5259(E) published in Gazette of India dated 12.10.2018.
And whereas, self- certification for SPV inverters (items 4-5) was extended up to 30.06.2022 vide S.O. 513(E)
published in Gazette of India dated 02.02.2022.
2. And whereas, in view of the availability of limited test facilities and providing more time for
compliance, the implementation of Quality Control Order, 2017 for SPV inverters (items 4-5) stands
extended from 30.06.2022 to 31.12.2022 based on self-certification, subject to the condition that such
manufacturers have valid IEC certificates corresponding to IS (IS 16221(Part 2):2015/IEC 62109-2:2011
for item No 4 and IS 16169:2014/IEC 62116:2008 for item No. 5), specified in the said order for these
items and test reports from accredited test labs, for smooth implementation of the order.
[F. No. 223/140/2017-R&D (Quality Control)]
Dr. ARUN K. TRIPATHI, Adviser/Scientist G

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. MANOJ
VERMA
Digitally signed by MANOJ
KUMAR VERMA
Date: 2022.07.29 22:47:10
+05'30'
