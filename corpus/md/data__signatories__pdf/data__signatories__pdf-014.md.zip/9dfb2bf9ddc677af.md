---
doc_id: "9dfb2bf9ddc677af"
source_url: "https://doj.gov.in/static/uploads/2025/11/73511fc0807d246c0c455cdd5ca21d4a.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Pavankumar Bhimappa Bajanthri, Judge of the Patna High Court, as Chief Justice of Patna High Court (20.09.2025)"
date: "2025-09-20"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "db78d1ab9f334e20"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1SECTION 2)
No. K-13028/05/2025-US.II
Government of India

Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,

New Delhi-110 011, dated 20h September, 2025.
NOTIFICATION

In exercise of the power conferred by clause (1 ) of Article 217 of the
Constitution of India, the President is pleased to appoint Shri Justice Pavankumar
Bhimappa Bajanthri, Judge of thePatna High Court, to be Chief Justice of the Patna
High Court with effect from the date he assumes charge of his office.

(Jagannath Shinivasan)

Joint Secretary to the Govemment of India
Tele: 2338 3037

To

The Manager,
Government of India Press,
Minto Road,

New Delhi.

<!-- page 2 -->

-2
No. K-13028/05/2025-US.II

Dated: 20.09.2025

Copy to:

Shri Justice Pavankumar Bhimappa Bajanthri, Acting Chief Justice of the
2
3
4.

Patna High Court through the Registrar General, Patna High Court, Patna.

The Secretary to Governor, Bihar, Patna.
The Secretary to Chief Minister, Bihar, Patna.

The Secretary to the Acting Chief Justice, Patna High Court, Patna.

The Chief Secretary, Government of Bihar, Patna.

6
7.
8

The Registrar General, Patna High Court, Patna.
The Accountant General, Bihar, Patna.

The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New

Delhi.
9.

PS to the Principal Secretary to the Prime Minister, Prime Minister's Office,
South Block, New Delhi.

10. Registrar (Conf), Supreme Court of India, Room Nos. 1,2 and 3,Ground
Floor, Supreme Court Main Building, New Delhi - 110001.
11. PS to the MoS (I/C), L&J PPS to Secretary (J).
12. Technical Director, NIC, Department of Justice, with a request to upload the

notification on the website of the Department (www.doj.gov.in).

(Prem Chand)
Under Secretary (Appointments-I)
Tele: 011-23382978
