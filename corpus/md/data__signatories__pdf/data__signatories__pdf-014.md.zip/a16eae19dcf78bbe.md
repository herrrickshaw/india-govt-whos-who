---
doc_id: "a16eae19dcf78bbe"
source_url: "https://powermin.gov.in/static/uploads/2025/06/5de19288a619ab0ddfb4bc9a3dcb8a67.pdf"
ministry: "Power"
title: "Office Order Dated 26th June 2020 (AS/JS)"
date: "2025-06-28"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "3f58705df3126367"
---

<!-- page 1 -->

No.2-1/2/2018-Adm.II
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg, New Delhi - 110001
Telephone No. 23715507; FAX No. 23717519
ee
Date: 26.06.2020
OFFICE ORDER
It has been decided that the following shall be the “Link Officer Arrangement”
in the grade of AS/JS in the Ministry with immediate effect and until further orders:
ditional Secretary dditional Secretary
i. \(Transmission, V&S and <--> |(Distribution, R&R and OM)
thermal)
[currently held by Shri Sanjay Malhotra,
[currently held by Shri S.K.G. AS (SM)}
IRahate, AS (SKGR)
oint Secretary (Thermal, ‘S(Hydro, Trans and Admn.)
(Coal and IC) <-->
{currently held by Shri Tanmay Kumar,
{currently held by Shri V.K. S(TK)]
iDewangan, JS D
joint Secretary (Distribution ‘S(R&R and O&M)
and Reforms) <-->
[currently held by Shri Ghanshyam
[currently held by Shri Prasad, JS(GP)]
iMritunjay Kumar Narayan, JS
MKWN
In the absence of Economic Adviser (RP), who is directly reporting t
Secretary(P), the work of P&P, T&R & Energy Conservation will be look afte:
by JS(VKD) and Coordination & Parliament will be look after by JS(MKN) in|
ddition to the regular work allocated to them. Files on these subjects will be
directly submitted to Secretary (P) by them.
2. This issues with the approval of Secretary (Power). @t
—_— लक माा
(Hausuanthang Guite)
Under Secretary to the Government of India
Tel No: 2371 5327
Copy to:
1. Officers concerned.
2. O/o MoS (1/C) for Power.
3. Sr. PPS to Secretary (P)/PPS to AS (SKGR)/PPS to AS (SM).
ate Officers /Desks/Sections/Units in the Ministry of Power.
~ The Technical Director, NIC Cell, Ministry of Power, for updating the website.
6. Personal Files/Office Order File/OL Section for providing Hindi version.
