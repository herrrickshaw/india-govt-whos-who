---
doc_id: "a09599bbff5cd9ff"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/03/007efae3f3e25f7b95c3a55dcf0bfaa4.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 13.02.2026 regarding deletion of Shri. G. Manoharan, Central Government Counsel for High Court of Madras at Madurai Bench"
date: "2026-02-13"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f7b07c70114f7dd9"
---

<!-- page 1 -->

No. J-11017/8/2025-Judicial/ E. 146103
Government of India
Ministry of Law and Justice
Department of Legal Affairs s
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated the 13! February, 2026
ORDER
The President is pleased to delete the name of Sh.G. Manoharan, Central
Government Counsel before High Court of Madras at Madurai Bench rare vide
this Department's Order No.J-11017/8/2025-Judicial’ E.146103 dated 05. 1.2026,
occurring at SI. No. '19' under Table 'B' of said Order.
2. Hindi version of this order will follow.
Var wo
to 151 »]| ad
(Dr. Krishna Mohan Arya)
Additional Legal Advisor
Copy (through email) to:

1. PS to Hon'ble Minister of State (Independent Charge) for Law & Justice.

2. PSO to Law Secretary/AS/JS in the main secretariat of this Department.

3. Ld. ASGI, High Court of Madras.

4. DSGI, High Court of Madras at Madurai Bench.

5. Registrar, High Court of Madras.

6. The Litigation In-charge, Branch Secretariat, Chennai

7. Shri G. Manoharan, Advocate.

8. To be uploaded on website of this Department i.e. www.legalaffairs.gov.in
under tab ‘Judicial Section’ in the link “Orders related to empanelment of
Advocate for Union of India’.

9. Hindi Section, Department of Legal Affairs, for translation of this order.

10. Office/spare copies. Axe
G
Ae a
(Ramesh Kairamkonda)
: ” Section Officer (Judicial)
: Tel. 011-23384945
है “Email: judicial-dla@nic.in
