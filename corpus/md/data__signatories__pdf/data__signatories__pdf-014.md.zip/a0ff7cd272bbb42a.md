---
doc_id: "a0ff7cd272bbb42a"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/06373455dba32d12799302ce7c5da39e.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Specification of establishment under the section 6 of the Payment of Wages Act, 1936 (26 Apr 2017)"
date: "2017-04-26"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "75f7c95bd1d63b84"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

EXTRAORDINARY
II—
—
(ii)
PART II—Section 3—Sub-section (ii)
PUBLISHED BY AUTHORITY
1167]
No. 1167]

NEW DELHI, WEDNESDAY, APRIL 26, 2017/VAISAKHA 6, 1939

श्रम और रोजगार मंत्रालय
अधधसूचना
नई ददल्ली, 25 अप्रैल, 2017

का.आ. 1316(अ).—के न्द्रीय सरकार, मजदूरी संदाय अधधधनयम, 1936 (1936 का 4) की धारा 6 के परंतुक द्वारा
प्रदत्त शधियों का प्रयोग करते हुए, उि परं तुक के प्रयोजनों के धलए धनम्नधलधखत स्थापनों को धिधनर्ददष्ट क करती ,ै, अथा्त :(1) रे ल ;
(2) िायु यातायात सेिा ;
(3) खान ;
(4) तेल क्षेत्र ।
[फा. सं. एस-31018/01/2016-डब्लल्यूसी (पीडब्लल्यू)]
के . एम. गुप्ता, मुख्य श्रम और रोजगार सला,कार

2782 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 25th April, 2017
S.O. 1316(E).—In exercise of the powers conferred by the proviso to section 6 of the Payment of Wages Act,
1936 (4 of 1936), the Central Government hereby specifies the following establishments for the purposes of the said
proviso, namely:1.

Railway;

2.

air transport services;

3.

mines;

4.

oil fields.
[F. No. S-31018/01/2016-WC(PW)]
K. M. GUPTA, Principal Labour and Employment Adviser

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

ALOK KUMAR

Digitally signed by ALOK KUMAR
Date: 2017.05.01 15:10:44 +05'30'
