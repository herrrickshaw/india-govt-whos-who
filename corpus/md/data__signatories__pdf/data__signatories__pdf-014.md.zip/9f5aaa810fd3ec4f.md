---
doc_id: "9f5aaa810fd3ec4f"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6a0ad130a64831.90686860.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Notification - Shri Kailash Chandra Meena, IFS (RJ:1997), appoint to the post of Deputy Director General of Forests (DDGF), MoEF&CC, Regional Office, Bhopal, in level 15 of the Pay Matrix, on deputation basis under the CSS-MoEF&CC, notification dated 18-05-2026."
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b683021b0889e3e5"
---

<!-- page 1 -->

(TO BE PUBLISHED IN PART-I SECTION (Il) OF THE GAZETTE OF INDIA)
Government of India
Ministry of Environment, Forests and Climate Change
हक
6th Floor, Prithvi Wing,
Indira Paryavaran Bhawan, Jor Bagh Road,
Ali Ganj, New Delhi-110003.
Datei May, 2026
NOTIFICATION
F.No. 19011/04/2026-IFS-I (E-299325). The President is pleased to
appoint Shri Kailash Chandra Meena, IFS (RJ:1997), to the post of Deputy
Director General of Forests (DDGF), MoEFCC, Regional Office, Bhopal, in
level 15 of the Pay Matrix, on deputation basis under the Central Staffing Scheme
of the Ministry of Environment, Forest and Climate Change w.e.f. 04.05.2026 (FN)
for a period of 05 years or till attaining the age of superannuation, or until further
orders, whichever is the earliest. Coney
~ of?
\ A
x
(Prem Prakash Maurya)
Under Secretary to the Government of India
Tel: 011-20819192
To,
The Manager,
Government of India Press,
Minto Road, New Delhi (with a copy of Hindi version)
Distribution:
A PS to Hon'ble Minister of Environment, Forest and Climate Change.
a: PS to Hon'ble Minister of State for Environment, Forest and Climate
Change.
3. PPS to Secretary (EF&CC)/PPS to DGF & SS/ PPSs to All ADGs/All
ASs/AS&FA/Sr Economic Advisor/MS CZA/MS NTCA/CEO CAMPA.
4. PPS to all IGFs/ JSs/EA/Advisors/CCA/DIGS/AIGs, MoEF&CC.
5. The Principal Secretary (Forests), Govt. of Rajasthan- Jaipur.
6. The PCCF & HoFF, Govt. of Rajasthan.
7. JS(Admin), MoEFCC, New Delhi.
8. Director, GA, MoEF&CC, New Delhi.
9: ROHQ Division, MoEFCC, New Delhi.
10. Shri Kailash Chandra Meena, IFS (RJ:1997), RO, Bhopal.
11... PPS to All JSs/ All IGFs/ All DIGs/All AlGs, MoEF&CC.
12. P&AO, Ministry of Environment, Forest and Climate Change, New Delhi.
