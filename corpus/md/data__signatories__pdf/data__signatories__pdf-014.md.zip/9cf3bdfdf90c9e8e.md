---
doc_id: "9cf3bdfdf90c9e8e"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/5865690b712b23dfabeb9cae7043bb96.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Consolidated FDI Policy Circular of 2017"
date: "2025-07-15"
pages: 113
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4ec18ed0322d2294"
---

<!-- page 1 -->

Department of Industrial Policy and Promotion
Ministry of Commerce and Industry
Government of India

Consolidated FDI Policy
(Effective from August 28, 2017)

<!-- page 2 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion

Consolidated FDI Policy Circular of 2017
Subject: Consolidated FDI Policy
The “Consolidated FDI Policy” is attached.
2. This Circular will take effect from August 28, 2017

(Atul Chaturvedi)
Additional Secretary to the Government of India
D/o IPP F. No. 5(1)/2017-FC-1 Dated the August 28, 2017
Copy forwarded to:
1.
2.
3.
4.
5.

Press Information Officer, Press Information Bureau- for giving wide publicity to the
above circular.
NIC, DIPP for uploading the Circular on DIPP's website.
Department of Economic Affairs, Ministry of Finance, New Delhi.
Reserve Bank of India, Mumbai.
Hindi Section for Hindi Translation.

1

<!-- page 3 -->

Contents
Chapter 1: Intent and Objective ................................................................................................... 4
1.1 Intent and Objective ................................................................................................................ 4
Chapter 2: Definitions .................................................................................................................. 5
2.1 Definitions................................................................................................................................. 5
Chapter 3: General Conditions on FDI .......................................................................................11
3.1 Eligible investors......................................................................................................................11
3.2 Eligible investee entities ..........................................................................................................12
3.3 Instruments of investments, issue/transfer of shares etc. .........................................................15
3.4 Entry Routes for Investment ....................................................................................................15
3.5 Caps on Investments ...............................................................................................................16
3.6 Entry Conditions on Investment ...............................................................................................16
3.7 Other Conditions on Investment besides Entry Conditions ......................................................16
3.8 Foreign Investment into/downstream Investment by eligible Indian entities .............................17
3.9 Remittance, Reporting and Violation………………………,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,……….………..18
Chapter 4: Procedure for Government Approval ......................................................................19
4.1 Competent Authority ................................................................................................................19
4.2 Cases which do not require Fresh Approval ............................................................................20
4.3 Online Filing of Applications for Government Approval ............................................................21
Chapter 5: Sector Specific Conditions on FDI .........................................................................22
5.1 Prohibited Sectors ...................................................................................................................22
5.2 Permitted Sectors ....................................................................................................................22
Agriculture ..................................................................................................................................23
5.2.1 Agriculture & Animal Husbandry ...........................................................................................23
5.2.2 Plantation Sector ..................................................................................................................24
Mining and Petroleum & Natural Gas .........................................................................................24
5.2.3 Mining ...................................................................................................................................24
5.2.4 Petroleum & Natural Gas ......................................................................................................26
Manufacturing..............................................................................................................................26
5.2.5 Manufacturing: ......................................................................................................................26
5.2.6 Defence ................................................................................................................................26
Services Sector ...........................................................................................................................27
5.2.7 Broadcasting.........................................................................................................................27
5.2.8 Print Media ...........................................................................................................................28
5.2.9 Civil Aviation .........................................................................................................................29
5.2.10 Construction Development: Townships, Housing, Built-up Infrastructure ............................32
5.2.11Industrial Parks ....................................................................................................................34

2

<!-- page 4 -->

5.2.12 Satellites- establishment and operation ..............................................................................34
5.2.13 Private Security Agencies ...................................................................................................35
5.2.14 Telecom Services ...............................................................................................................35
5.2.15 Trading ...............................................................................................................................36
5.2.16 Railway Infrastructure .........................................................................................................43
Financial Services .......................................................................................................................43
5.2.17 Asset Reconstruction Companies .......................................................................................43
5.2.18 Banking- Private Sector ......................................................................................................44
5.2.19 Banking- Public Sector .......................................................................................................45
5.2.20Credit Information Companies (CIC) ....................................................................................45
5.2.21 Infrastructure Company in the Securities Market.................................................................45
5.2.22 Insurance ............................................................................................................................47
5.2.23 Pension Sector ...................................................................................................................48
5.2.24 Power Exchanges ...............................................................................................................49
5.2.25 White Label ATM Operations ..............................................................................................49
5.2.26 Other Financial Services .....................................................................................................50
Others...........................................................................................................................................50
5.2.27 Pharmaceuticals .................................................................................................................50
Annexures ....................................................................................................................................53
Annexure-1 Form FC-GPR ............................................................................................................53
Annexure-2 Types of Instruments ..................................................................................................61
Annexure-3 Provisions Relating to Issue/Transfer of Shares………………………………………….63
Annexure-4 Specific Conditions in Certain Cases ..........................................................................74
Annexure-5.Total Foreign Investment i.e. Direct and Indirect Foreign Investment in eligible Indian
entities ...........................................................................................................................................77
Annexure-6..Remittance, Reporting and Violation .........................................................................81
Annexure-7 Conditions for Broadcasting Sector ..........................................................................106
Annexure-8 Conditions for Industrial Parks ..................................................................................109
Annexure-9 Permissible limits under portfolio investment schemes through stock exchanges for
FIIs/FPIs and NRIs ......................................................................................................................110
Annexure – 10 Certificate to be furnished by the Prospective Investor as well as the Prospective
Recipient Entity ...........................................................................................................................112

3

<!-- page 5 -->

Chapter 1: Intent and Objective
1.1

Intent and Objective

1.1.1 It is the intent and objective of the Government of India to attract and promote foreign direct
investment in order to supplement domestic capital, technology and skills, for accelerated
economic growth. Foreign Direct Investment, as distinguished from portfolio investment, has
the connotation of establishing a ‘lasting interest’ in an enterprise that is resident in an
economy other than that of the investor.
1.1.2 The Government has put in place a policy framework on Foreign Direct Investment, which is
transparent, predictable and easily comprehensible. This framework is embodied in the
Circular on Consolidated FDI Policy, which may be updated every year, to capture and keep
pace with the regulatory changes, effected in the interregnum. The Department of Industrial
Policy and Promotion (DIPP), Ministry of Commerce & Industry, Government of India makes
policy pronouncements on FDI through Press Notes/Press Releases which are notified by
the Reserve Bank of India as amendments to the Foreign Exchange Management (Transfer
or Issue of Security by Persons Resident Outside India) Regulations, 2000 (notification No.
FEMA 20/2000-RB dated May 3, 2000). These notifications take effect from the date of
issue of Press Notes/ Press Releases, unless specified otherwise therein. In case of any
conflict, the relevant FEMA Notification will prevail. The procedural instructions are issued
by the Reserve Bank of India vide A.P. (DIR Series) Circulars. The regulatory framework,
over a period of time, thus, consists of Acts, Regulations, Press Notes, Press Releases,
Clarifications, etc.
1.1.3 The present consolidation subsumes and supersedes all Press Notes/Press
Releases/Clarifications/Circulars issued by DIPP, which were in force as on August 27,
2017 and reflects the FDI Policy as on August 28, 2017.This Circular accordingly will take
effect from August 28, 2017 and will remain in force until superseded in totality or in part
thereof. Reference to any statute or legislation made in this Circular shall include
modifications, amendments or re-enactments thereof.
1.1.4 Notwithstanding
the
rescission
of
earlier
Press
Notes/Press
Releases/Clarifications/Circulars, anything done or any action taken or purported to have
been
done
or
taken
under
the
rescinded
Press
Notes/Press
Releases/Clarifications/Circulars prior to August 28, 2017, shall, in so far as it is not
inconsistent with those Press Notes/Press Releases/Clarifications/Circulars, be deemed to
have been done or taken under the corresponding provisions of this circular and shall be
valid and effective.

4

<!-- page 6 -->

Chapter 2: Definitions
2.1

Definitions

2.1.1

‘AD Category-I Bank’ means a bank(Scheduled Commercial, State or Urban
Cooperative) which is authorized under Section 10(1) of FEMA to undertake all
current and capital account transactions according to the directions issued by the
RBI from time to time.

2.1.2

‘Authorized Bank’ means a bank including a co-operative bank (other than an
authorized dealer) authorized by the Reserve Bank to maintain an account of a
person resident outside India.

2.1.3

‘Authorized Dealer’ means a person authorized as an authorized dealer under
sub-section (1) of section 10 of FEMA.

2.1.4

‘Authorized Person’ means an authorized dealer, money changer, offshore
banking unit or any other person for the time being authorized under sub-section (a)
of section 10 of FEMA to deal in foreign exchange or foreign securities.

2.1.5

‘Capital’ means equity shares; fully, compulsorily & mandatorily convertible
preference shares; fully, compulsorily & mandatorily convertible debentures and
warrants.
Note: The equity shares issued in accordance with the provisions of the Companies
Act, as applicable, shall include equity shares that have been partly paid.
Preference shares and convertible debentures shall be required to be fully paid, and
should be mandatorily and fully convertible. Further, ‘warrant’ includes Share
Warrant issued by an Indian Company in accordance to provisions of the
Companies Act, as applicable.

2.1.6

‘Capital account transaction’ means a transaction which alters the assets or
liabilities, including contingent liabilities, outside India of persons resident in India or
assets or liabilities in India of persons resident outside India, and includes
transactions referred to in sub-section (3) of section 6 of FEMA.

2.1.7

‘Competent Authority’ means the concerned Administrative Ministry/Department
empowered to grant government approval for foreign investment under the extant
FDI Policy and FEMA Regulations.

2.1.8

‘Control’ shall include the right to appoint a majority of the directors or to control the
management or policy decisions including by virtue of their shareholding or
management rights or shareholders agreements or voting agreements. For the
purposes of Limited Liability Partnership, ‘control’ will mean right to appoint majority
of the designated partners, where such designated partners, with specific exclusion
to others, have control over all the policies of the LLP.

2.1.9

‘Convertible Note’ means an instrument issued by a startup company evidencing
receipt of money initially as debt, which is repayable at the option of the holder, or
which is convertible into such number of equity shares of such startup company,

5

<!-- page 7 -->

within a period not exceeding five years from the date of issue of the convertible
note, upon occurrence of specified events as per the other terms and conditions
agreed to and indicated in the instrument.
2.1.10

‘Depository Receipt’ (DR) means a negotiable security issued outside India by a
Depository bank, on behalf of an Indian company, which represent the local Rupee
denominated equity shares of the company held as deposit by a Custodian bank in
India. DRs are traded on Stock Exchanges in the US, Singapore, Luxembourg, etc.
DRs listed and traded in the US markets are known as American Depository
Receipts (ADRs) and those listed and traded anywhere/elsewhere are known as
Global Depository Receipts (GDRs). DRs are governed by Notification No. FEMA
330/ 2014-RB, issued by Reserve bank of India.

2.1.11

“Employees’ Stock Option” means the option given to the directors, officers or
employees of a company or of its holding company or joint venture or wholly owned
overseas subsidiary/subsidiaries, if any, which gives such directors, officers or
employees, the benefit or right to purchase, or to subscribe for, the shares of the
company at a future date at a pre-determined price.

2.1.12

‘Erstwhile Overseas Corporate Body’(OCB) means a company, partnership firm,
society and other corporate body owned directly or indirectly to the extent of at least
sixty percent by non-resident Indians and includes overseas trust in which not less
than sixty percent beneficial interest is held by non-resident Indians directly or
indirectly but irrevocably and which was in existence on the date of commencement
of the Foreign Exchange Management (Withdrawal of General Permission to
Overseas Corporate Bodies (OCBs) ) Regulations, 2003 (the Regulations) and
immediately prior to such commencement was eligible to undertake transactions
pursuant to the general permission granted under the Regulations.

2.1.13

‘Foreign Currency Convertible Bond’ (FCCB) means a bond issued by an Indian
company expressed in foreign currency, the principal and interest of which is
payable in foreign currency. FCCBs are issued in accordance with the Foreign
Currency Convertible Bonds and ordinary shares (through depository receipt
mechanism) Scheme, 1993 and subscribed by a non-resident entity in foreign
currency and convertible into ordinary shares of the issuing company in any
manner, either in whole, or in part.

2.1.14

‘FDI’ means investment by non-resident entity/person resident outside India in the
capital of an Indian company under Schedule 1 of Foreign Exchange Management
(Transfer or Issue of Security by a Person Resident Outside India)
Regulations,2000
(Original
notification
is
available
at
https://rbi.org.in/Scripts/BS_FemaNotifications.aspx?Id=174.
Subsequent
amendment
notifications
are
available
at
https://rbi.org.in/Scripts/BS_FemaNotifications.aspx).

2.1.15

‘FDI linked performance conditions’ means the sector specific conditions for
companies receiving foreign investment.

6

<!-- page 8 -->

2.1.16

‘FEMA’ means the Foreign Exchange Management Act, 1999 (42 of 1999).

2.1.17

‘Foreign Institutional Investor’(FII) means an entity established or incorporated
outside India which proposes to make investment in India and which is registered as
a FII in accordance with the Securities and Exchange Board of India (SEBI)
(Foreign Institutional Investor) Regulations 1995.

2.1.18

‘Foreign Portfolio Investor’(FPI)1 means a person registered in accordance with
the provisions of Securities and Exchange Board of India (SEBI) (Foreign Portfolio
Investors) Regulations, 2014, as amended from time to time.

2.1.19

‘Foreign Venture Capital Investor’ (FVCI) means an investor incorporated and
established outside India, which is registered under the Securities and Exchange
Board of India (Foreign Venture Capital Investor) Regulations, 2000 {SEBI(FVCI)
Regulations} and proposes to make investment in accordance with these
Regulations.

2.1.20

‘Government route’ means that investment in the capital of resident entities by
non-resident entities can be made only with the prior approval of Government
(Competent Ministry/Department for grant of approval).

2.1.21

‘Group Company’ means two or more enterprises which, directly or indirectly, are
in a position to:
(i) exercise twenty-six percent or more of voting rights in other enterprise; or
(ii) appoint more than fifty percent of members of board of directors in the other
enterprise.

2.1.22

‘Holding Company’ would have the same meaning as defined in Companies Act,
as applicable.

2.1.23

‘Indian Company’ means a company incorporated in India under the Companies
Act, as applicable.

2.1.24

‘Indian Venture Capital Undertaking’(IVCU) means an Indian company:
(i) whose shares are not listed in a recognised stock exchange in India;
(ii) which is engaged in the business of providing services, production or
manufacture of articles or things, but does not include such activities or sectors
which are specified in the negative list by the SEBI, with approval of Central
Government, by notification in the Official Gazette in this behalf.

2.1.25

‘Investment Vehicle’ shall mean an entity registered and regulated under relevant
regulations framed by SEBI or any other authority designated for the purpose and
shall include Real Estate Investment Trusts (REITs) governed by the SEBI (REITs)
Regulations, 2014, Infrastructure Investment Trusts (InvIts) governed by the SEBI

1

For details please refer to SEBI (FPI) Regulations, 2014 and the Foreign Exchange Management (Transfer or Issue of Security by
a Person Resident outside India) (Second Amendment) Regulations, 2014 notified vide Notification No. FEMA.297/2014-RB
dated March 13, 2014 and A.P. (DIR Series) Circular No.112 dated March 25, 2014.Wherever the words or acronyms FPI or FII
occur in this document, the meaning and implications must be according to the above Regulations/Notifications, particularly
during the transition period as prescribed in these Regulations.

7

<!-- page 9 -->

(InvIts) Regulations, 2014 and Alternative Investment Funds (AIFs) governed by the
SEBI (AIFs) Regulations, 2012.
2.1.26

‘Investing Company’ means an Indian Company holding only investments in other
Indian company/(ies), directly or indirectly, other than for trading of such
holdings/securities.

2.1.27

‘Investment on repatriable basis’ means investment, the sale proceeds of which,
net of taxes, are eligible to be repatriated out of India and the expression
‘investment on non-repatriable basis’ shall be construed accordingly.

2.1.28

‘Joint Venture’(JV) means an Indian entity incorporated in accordance with the
laws and regulations in India in whose capital a non-resident entity makes an
investment.

2.1.29

‘Limited Liability Partnership’ means a Limited Liability Partnership firm, formed
and registered under the Limited Liability Partnership Act, 2008.

2.1.30

‘Manufacture’, with its grammatical variations, means a change in a non-living
physical object or article or thing- (a) resulting in transformation of the object or
article or thing into a new and distinct object or article or thing having a different
name, character and use; or (b) bringing into existence of a new and distinct object
or article or thing with a different chemical composition or integral structure.

2.1.31

‘Non-resident entity’ means a ‘person resident outside India’ as defined under
FEMA.

2.1.32

‘Non-Resident Indian’ (NRI) means an individual resident outside India who is a
citizen of India or is an ‘Overseas Citizen of India’ cardholder within the meaning of
section 7 (A) of the Citizenship Act, 1955. ‘Persons of Indian Origin’ cardholders
registered as such under Notification No. 26011/4/98 F.I. dated 19.8.2002 issued by
the Central Government are deemed to be ‘Overseas Citizen of India’ cardholders’

2.1.33

A company is considered as ‘Owned’ by resident Indian citizens if more than 50%
of the capital in it is beneficially owned by resident Indian citizens and / or Indian
companies, which are ultimately owned and controlled by resident Indian citizens. A
Limited Liability Partnership will be considered as owned by resident Indian citizens
if more than 50% of the investment in such an LLP is contributed by resident Indian
citizens and/or entities which are ultimately ‘owned and controlled by resident Indian
citizens’ and such resident Indian citizens and entities have majority of the profit
share.

2.1.34

‘Person’ includes(i) an individual,
(ii) a Hindu undivided family,
(iii) a company,
(iv) a firm,
(v) an association of persons or a body of individuals whether incorporated or not,
(vi) every artificial juridical person, not falling within any of the preceding subclauses, and

8

<!-- page 10 -->

2.1.35

(vii) any agency, office, or branch owned or controlled by such person.
‘Person of Indian Origin’(PIO) means a citizen of any country other than
Bangladesh or Pakistan, if
(i)

he at any time held Indian Passport; or

(ii) he or either of his parents or any of his grandparents was a citizen of India by
virtue of the Constitution of India or the Citizenship Act, 1955 (57 of 1955); or
(iii) the person is a spouse of an Indian citizen or a person referred to in subclause (i) or (ii).
2.1.36

‘Person resident in India’ means(i) a person residing in India for more than one hundred and eighty-two days
during the course of the preceding financial year but does not include(A) A person who has gone out of India or who stays outside India, in either
case(a) for or on taking up employment outside India, or
(b) for carrying on outside India a business or vocation outside India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay outside India for an uncertain period;
(B) A person who has come to or stays in India, in either case, otherwise than(a) for or on taking up employment in India; or
(b) for carrying on in India a business or vocation in India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay in India for an uncertain period;
(ii) any person or body corporate registered or incorporated in India,
(iii) an office, branch or agency in India owned or controlled by a person resident
outside India,
(iv) an office, branch or agency outside India owned or controlled by a person
resident in India.

2.1.37

‘Person resident outside India’ means a person who is not a Person resident in
India.

2.1.38

‘Portfolio Investment Scheme’ means the Portfolio Investment Scheme referred to
in Schedules 2, 2A& 3 of FEMA (Transfer or Issue of Security by a Person Resident
Outside India) Regulations, 2000.

2.1.39

‘RBI’ means the Reserve Bank of India established under the Reserve Bank of
India Act, 1934.

2.1.40

‘Resident Entity’ means ‘Person resident in India’ excluding an individual.

2.1.41

‘Resident Indian Citizen’ shall be interpreted in line with the definition of ‘person
resident in India’ as per FEMA, 1999, read in conjunction with the Indian Citizenship

9

<!-- page 11 -->

Act, 1955.
2.1.42

‘SEBI’ means the Securities and Exchange Board of India established under the
Securities and Exchange Board of India Act, 1992.

2.1.43

‘SEZ’ means a Special Economic Zone as defined in Special Economic Zone Act,
2005.

2.1.44

‘SIA’ means Secretariat of Industrial Assistance in DIPP, Ministry of Commerce &
Industry, Government of India.

2.1.45

‘Sweat Equity Shares’ means such equity shares as issued by a company to its
directors or employees at a discount or for consideration other than cash, for
providing their know-how or making available rights in the nature of intellectual
property rights or value additions, by whatever name called.

2.1.46

‘Transferable Development Rights’ (TDR) means certificates issued in respect of
category of land acquired for public purposes either by the Central or State
Government in consideration of surrender of land by the owner without monetary
compensation, which are transferable in part or whole.

2.1.47

‘Unit’ shall mean beneficial interest of an investor in the Investment Vehicle and
shall include shares or partnership interests.

2.1.48

‘Venture Capital Fund’ (VCF) means a Fund registered as a ‘venture capital fund’
under SEBI (Venture Capital Funds) Regulations, 1996.

10

<!-- page 12 -->

Chapter 3: General Conditions on FDI
3.1

Eligible investors

3.1.1

A non-resident entity can invest in India, subject to the FDI Policy except in those
sectors/activities which are prohibited. However, a citizen of Bangladesh or an entity
incorporated in Bangladesh can invest only under the Government route. Further, a
citizen of Pakistan or an entity incorporated in Pakistan can invest, only under the
Government route, in sectors/activities other than defence, space, atomic energy and
sectors/activities prohibited for foreign investment.

3.1.2

NRIs resident in Nepal and Bhutan as well as citizens of Nepal and Bhutan are
permitted to invest in the capital of Indian companies on repatriation basis, subject to
the condition that the amount of consideration for such investment shall be paid only by
way of inward remittance in free foreign exchange through normal banking channels.

3.1.3

OCBs have been derecognized as a class of investors in India with effect from
September 16, 2003. Erstwhile OCBs which are incorporated outside India and are not
under the adverse notice of RBI can make fresh investments under FDI Policy as
incorporated non-resident entities, with the prior approval of Government of India if the
investment is through Government route; and with the prior approval of RBI if the
investment is through Automatic route.

3.1.4

A company, trust and partnership firm incorporated outside India and owned and
controlled by NRIs can invest in India with the special dispensation as available to NRIs
under the FDI Policy.

3.1.5

(i) Foreign Institutional Investor (FII) and Foreign Portfolio Investors (FPI) may in terms
of Schedule 2 and 2A of FEMA (Transfer or Issue of Security by Persons Resident
Outside India) Regulations, as the case may be, respectively, invest in the capital of an
Indian company under the Portfolio Investment Scheme which limits the individual
holding of an FII/FPI below 10% of the capital of the company and the aggregate limit
for FII/FPI investment to 24% of the capital of the company. This aggregate limit of 24%
can be increased to the sectoral cap/statutory ceiling, as applicable, by the Indian
company concerned through a resolution by its Board of Directors followed by a special
resolution to that effect by its General Body and subject to prior intimation to RBI. The
aggregate FII/FPI investment, individually or in conjunction with other kinds of foreign
investment, will not exceed sectoral/statutory cap.
(ii) An Indian company which has issued shares to FIIs/FPIs under the FDI Policy for
which the payment has been received directly into company’s account should report
these figures separately under item no. 5 of Form FC-GPR (Annexure-1).
(iii) A daily statement in respect of all transactions (except derivative trade) has to be
submitted by the custodian bank in soft copy in the prescribed format directly to RBI
and
also
uploaded
directly
on
the
OFRS
web
site
(https://secweb.rbi.org.in/ORFSMainWeb/Login.jsp).

11

<!-- page 13 -->

3.1.6

Only registered FIIs/FPIs and NRIs as per Schedules 2,2A and 3 respectively of
Foreign Exchange Management (Transfer or Issue of Security by a Person Resident
Outside India) Regulations, 2000, can invest/trade through a registered broker in the
capital of Indian Companies on recognised Indian Stock Exchanges.

3.1.7

A SEBI registered Foreign Venture Capital Investor (FVCI) may contribute up to 100%
of the capital of an Indian company engaged in any activity mentioned in Schedule 6 of
Notification No. FEMA 20/2000, including startups irrespective of the sector in which it
is engaged, under the automatic route. A SEBI registered FVCI can invest in a
domestic venture capital fund registered under the SEBI (Venture Capital Fund)
Regulations, 1996 or a Category- I Alternative Investment Fund registered under the
SEBI (Alternative Investment Fund) Regulations, 2012.Such investments shall also be
subject to the extant FEMA regulations and extant FDI policy including sectoral caps,
etc. The investment can be made in equities or equity linked instruments or debt
instruments issued by the company (including start-ups and if a startup is organised as
a partnership firm or an LLP, the investment can be made in the capital or through any
profit-sharing arrangement) or units issued by a VCF or by a Category-I AIF either
through purchase by private arrangement either from the issuer of the security or from
any other person holding the security or on a recognised stock exchange.It may also
set up a domestic asset management company to manage its investments. SEBI
registered FVCIs are also allowed to invest under the FDI Scheme, as non-resident
entities, in other companies, subject to FDI Policy and FEMA regulations.

3.1.8

A Non- Resident Indian may subscribe to National Pension System governed and
administered by Pension Fund Regulatory and Development Authority (PFRDA),
provided such subscriptions are made through normal banking channels and the
person is eligible to invest as per the provisions of the PFRDA Act. The annuity/
accumulated saving will be repatriable.

3.2 Eligible investee entities
3.2.1 Indian Company
Indian companies can issue capital against FDI.
3.2.2 Partnership Firm/Proprietary Concern
(i)

A Non-Resident Indian (NRI) or a Person of Indian Origin (PIO) resident outside
India can invest in the capital of a firm or a proprietary concern in India on nonrepatriation basis provided;
(a)

Amount is invested by inward remittance or out of NRE/FCNR(B)/NRO
account maintained with Authorized Dealers/Authorized banks.

(b)

The firm or proprietary concern is not engaged in any agricultural/plantation
or real estate business or print media sector.

(c)

Amount invested shall not be eligible for repatriation outside India.

12

<!-- page 14 -->

(ii) Investments with repatriation option: NRIs/PIO may seek prior permission of
Reserve Bank for investment in sole proprietorship concerns/partnership firms with
repatriation option. The application will be decided in consultation with the
Government of India.
(iii) Investment by non-residents other than NRIs/PIO:A person resident outside India
other than NRIs/PIO may make an application and seek prior approval of Reserve
Bank for making investment in the capital of a firm or a proprietorship concern or
any association of persons in India. The application will be decided in consultation
with the Government of India. (iv) Restrictions: An NRI or PIO is not allowed to
invest in a firm or proprietorship concern engaged in any agricultural/plantation
activity or real estate business or print media.
3.2.3

Trusts
FDI is not permitted in Trusts other than in ‘VCF’ registered and regulated by SEBI and
‘Investment vehicle’.

3.2.4

Limited Liability Partnerships (LLPs)
FDI in LLPs is permitted subject to the following conditions:
(i)

FDI is permitted under the automatic route in Limited Liability Partnership (LLPs)
operating in sectors/activities where 100% FDI is allowed through the automatic
route and there are no FDI-linked performance conditions.

(ii) An Indian company or an LLP, having foreign investment, is also permitted to
make downstream investment in another company or LLP in sectors in which
100% FDI is allowed under the automatic route and there are no FDI-linked
performance conditions.
(iii) Conversion of an LLP having foreign investment and operating in sectors/activities
where 100% FDI is allowed through the automatic route and there are no FDIlinked performance conditions, into a company is permitted under automatic route.
Similarly, conversion of a company having foreign investment and operating in
sectors/activities where 100% FDI is allowed through the automatic route and
there are no FDI-linked performance conditions, into an LLP is permitted under
automatic route.
(iv) FDI in LLP is subject to the compliance of the conditions of LLP Act, 2008.
3.2.5

Investment Vehicle
An entity being ‘investment vehicle’ registered and regulated under relevant regulations
framed by SEBI or any other authority designated for the purpose including Real Estate
Investment Trusts (REITs) governed by the SEBI (REITs) Regulations, 2014,
Infrastructure Investment Trusts (InvIts) governed by the SEBI (InvIts) Regulations,
2014, Alternative Investment Funds (AIFs) governed by the SEBI (AIFs) Regulations,

13

<!-- page 15 -->

2012 and notified under Schedule 11 of Foreign Exchange Management (Transfer or
Issue of Security by a Person Resident outside India) Regulations, 2000 is permitted to
receive foreign investment from a person resident outside India (other than an
individual who is citizen of or any other entity which is registered / incorporated in
Pakistan or Bangladesh), including an Registered Foreign Portfolio Investor (RFPI) or a
non-resident Indian (NRI).
3.2.6

Startup Companies
Start-ups can issue equity or equity linked instruments or debt instruments to FVCI
against receipt of foreign remittance, as per the FEMA Regulation. In addition, startups can issue convertible notes to person resident outside India subject to the following
conditions:
(i) A person resident outside India (other than an individual who is citizen of Pakistan or
Bangladesh or an entity which is registered / incorporated in Pakistan or
Bangladesh), may purchase convertible notes issued by an Indian startup company
for an amount of twenty five lakh rupees or more in a single tranche.
Explanation: For the purpose of this Regulation, a ‘startup company’ means a
private company incorporated under the Companies Act, 2013 or Companies Act,
1956 and recognised as such in accordance with notification number G.S.R. 180(E)
dated February 17, 2016 issued by the Department of Industrial Policy and
Promotion, Ministry of Commerce and Industry, and as amended from time to time.
(ii) A startup company engaged in a sector where foreign investment requires
Government approval may issue convertible notes to a non-resident only with
approval of the Government.
Explanation: For the purpose of this regulation, the issue of shares against such
convertible notes shall have to be in accordance with the Schedule 1 of the
Notification No.FEMA.20/2000-RB dated 3rd May 2000.
(iii) A startup company issuing convertible notes to a person resident outside India shall
receive the amount of consideration by inward remittance through banking channels
or by debit to the NRE / FCNR (B) / Escrow account maintained by the person
concerned in accordance with the Foreign Exchange Management (Deposit)
Regulations, 2016, as amended from time to time.
Provided that an escrow account for the above purpose shall be closed immediately
after the requirements are completed or within a period of six months, whichever is
earlier. However, in no case continuance of such escrow account shall be permitted
beyond a period of six months.
(iv) NRIs may acquire convertible notes on non-repatriation basis in accordance with
Schedule 4 of the Notification No.FEMA.20/2000-RB dated 3rd May 2000.
(v) A person resident outside India may acquire or transfer, by way of sale, convertible
notes, from or to, a person resident in or outside India, provided the transfer takes
place in accordance with the pricing guidelines as prescribed by RBI. Prior approval

14

<!-- page 16 -->

from the Government shall be obtained for such transfers in case the startup
company is engaged in a sector which requires Government approval.
(vi) The startup company issuing convertible notes shall be required to furnish reports as
prescribed by Reserve Bank of India.
3.2.7

Other Entities
FDI in resident entities other than those mentioned above is not permitted.

3.3

Instruments of investments, issue/transfer of shares etc.
Types of instruments for investment and provisions relating to issue/ transfer of shares
are given at Annexure 2 & Annexure 3 respectively. Further, specific conditions of
compliance for certain cases are given in Annexure-4.

3.4

Entry Routes for Investment

3.4.1

Investments can be made by non-residents in the equity shares/fully, compulsorily and
mandatorily convertible debentures/fully, compulsorily and mandatorily convertible
preference shares of an Indian company, through the Automatic Route or the
Government Route. Under the Automatic Route, the non-resident investor or the Indian
company does not require any approval from Government of India for the investment.
Under the Government Route, prior approval of the Government of India is required.
Proposals for foreign investment under Government route, are considered by
respective Administrative Ministry/Department.

3.4.2

Foreign investment in sectors/activities under government approval route will be
subject to government approval where:
(i)

An Indian company is being established with foreign investment and is not owned
by a resident entity or

(ii) An Indian company is being established with foreign investment and is not
controlled by a resident entity or
(iii) The control of an existing Indian company, currently owned or controlled by
resident Indian citizens and Indian companies, which are owned or controlled by
resident Indian citizens, will be/is being transferred/passed on to a non-resident
entity as a consequence of transfer of shares and/or fresh issue of shares to nonresident entities through amalgamation, merger/demerger, acquisition etc. or
(iv) The ownership of an existing Indian company, currently owned or controlled by
resident Indian citizens and Indian companies, which are owned or controlled by
resident Indian citizens, will be/is being transferred/passed on to a non-resident
entity as a consequence of transfer of shares and/or fresh issue of shares to nonresident entities through amalgamation, merger/demerger, acquisition etc.

15

<!-- page 17 -->

(v) It is clarified that Foreign investment shall include all types of foreign investments,
direct and indirect, regardless of whether the said investments have been made
under Schedule 1 (FDI), 2 (FII), 2A (FPI), 3 (NRI), 6 (FVCI), 9 (LLPs), 10 (DRs)
and 11(Investment Vehicles) of FEMA (Transfer or Issue of Security by Persons
Resident Outside India) Regulations. FCCBs and DRs having underlying of
instruments which can be issued under Schedule 5, being in the nature of debt,
shall not be treated as foreign investment. However, any equity holding by a
person resident outside India resulting from conversion of any debt instrument
under any arrangement shall be reckoned as foreign investment.
(vi) Investment by NRIs under Schedule 4 of FEMA (Transfer or Issue of Security by
Persons Resident Outside India) Regulations will be deemed to be domestic
investment at par with the investment made by residents.
(vii) A company, trust and partnership firm incorporated outside India and owned and
controlled by non-resident Indians will be eligible for investments under Schedule
4 of FEMA (Transfer or issue of Security by Persons Resident Outside India)
Regulations and such investment will also be deemed domestic investment at par
with the investment made by residents.
3.5

Caps on Investments

3.5.1

Investments can be made by non-residents in the capital of a resident entity only to the
extent of the percentage of the total capital as specified in the FDI policy. The caps in
various sector(s) are detailed in Chapter 5 of this Circular.

3.6

Entry Conditions on Investment

3.6.1

Investments by non-residents can be permitted in the capital of a resident entity in
certain sectors/activity with entry conditions. Such conditions may include norms for
minimum capitalization, lock-in period, etc. The entry conditions in various
sectors/activities are detailed in Chapter 5 of this Circular.

3.7

Other Conditions on Investment besides Entry Conditions

3.7.1

Besides the entry conditions on foreign investment, the investment/investors are
required to comply with all relevant sectoral laws, regulations, rules, security conditions,
and state/local laws/regulations.

3.7.2

For establishment of branch office, liaison office or project office or any other place of
business in India if the principal business of the applicant is Defence, Telecom, Private
Security or Information and Broadcasting, approval of Reserve Bank of India is not
required in cases where Government approval or license/permission by the concerned
Ministry/Regulator has already been granted.

16

<!-- page 18 -->

3.8

Foreign Investment into/downstream Investment by eligible Indian entities

3.8.1

The Guidelines for calculation of total foreign investment, both direct and indirect in
an Indian company/LLP, at every stage of investment, including downstream
investment, have been detailed in Annexure-5.

3.8.2

For the purpose of this chapter,
(i)

‘Downstream investment’ means indirect foreign investment, by an eligible
Indian entity, into another Indian company/LLP, by way of subscription or
acquisition. Annexure-5 provides the guidelines for calculation of indirect
foreign investment, with conditions specified in paragraph 1.2 (v).

(ii)

‘Foreign Investment’ would have the same meaning as in Annexure-5.

3.8.3

Foreign investment into an Indian company engaged only in the activity of
investing in the capital of other Indian company/ies (regardless of its
ownership or control):

3.8.3.1

Foreign investment into an Indian company, engaged only in the activity of investing
in the capital of other Indian company/ies/ LLP, will require prior Government
approval, regardless of the amount or extent of foreign investment.

3.8.3.2

Those companies, which are Core Investment Companies (CICs), will have to
additionally follow RBI’s Regulatory Framework for CICs.

3.8.3.3

For undertaking activities which are under automatic route and without foreign
investment linked performance conditions, Indian company which does not have any
operations and also does not have any downstream investments, will be permitted to
have infusion of foreign investment under automatic route. However approval of the
Government will be required for such companies for infusion of foreign investment
for undertaking activities which are under Government route, regardless of the
amount or extent of foreign investment. Further, as and when such a company
commences business(s) or makes downstream investment, it will have to comply
with the relevant sectoral conditions on entry route, conditionalities and caps.

Note:

Foreign investment into other Indian companies/LLPs would be in accordance/
compliance with the relevant sectoral conditions on entry route, conditionalities and
caps.

3.8.4

Downstream investment by an eligible Indian entity which is not owned and/or
controlled by resident entity/ies

3.8.4.1

Downstream investment by an eligible Indian entity, which is not owned and/or
controlled by resident entity/ies, into another Indian company, would be in
accordance/compliance with the relevant sectoral conditions on entry route,
conditionalities and caps, with regard to the sectors in which the latter Indian
company is operating.

17

<!-- page 19 -->

Note:

Downstream investment/s made by a banking company, as defined in clause(c) of
Section 5 of the Banking Regulation Act, 1949, incorporated in India, which is owned
and/or controlled by non-residents/a non-resident entity/non-resident entities, under
Corporate Debt Restructuring (CDR), or other loan restructuring mechanism, or in
trading books, or for acquisition of shares due to defaults in loans, shall not count
towards indirect foreign investment. However, their 'strategic downstream
investment' shall count towards indirect foreign investment. For this purpose,
'strategic downstream investments' would mean investment by these banking
companies in their subsidiaries, joint ventures and associates.

3.8.4.2

Downstream investments by eligible Indian entities/LLPs will be subject to the
following conditions:
(i)

Such an entity is to notify RBI and Foreign Investment Facilitation Portal of its
downstream investment in the form available at www.fifp.gov.in within 30 days
of such investment, even if capital instruments have not been allotted along
with the modality of investment in new/existing ventures (with/without expansion
programme);

(ii) Downstream investment by way of induction of foreign investment in an existing
Indian Company to be duly supported by a resolution of the Board of Directors
as also a share-holders agreement, if any;
(iii) Issue/transfer/pricing/valuation of capital shall be in accordance with applicable
SEBI/RBI guidelines;
(iv) For the purpose of downstream investment, the eligible Indian entities making
the downstream investments would have to bring in requisite funds from abroad
and not leverage funds from the domestic market. This would, however, not
preclude downstream companies/LLPs, with operations, from raising debt in the
domestic market. Downstream investments through internal accruals are
permissible, subject to the provisions of paragraphs 3.8.3 and 3.8.4.1. For the
purposes of foreign investment policy, internal accruals will mean as profits
transferred to reserve account after payment of taxes.
3.9
3.9.1

Remittance, Reporting and Violation
The Government has provided elaborated scheme for remittance, reporting and
violation of FDI policy. These are available at Annexure-6.

18

<!-- page 20 -->

Chapter 4: Procedure for Government Approval
4.1 Competent Authority
4.1.1 Following are the Competent Authorities for grant of approval for foreign investment for
sectors/activities requiring Government approval:
S. No. Activity/ sector
Administrative
Ministry/
Department
(i)

Mining

(ii)

Defence

Ministry of Mines

a) Items requiring Industrial Licence under the Department

of

Industries (Development & Regulation) Act, 1951, Production,

Ministry

and/or Arms Act, 1959 for which the powers have

Defence
of

Defence

been delegated by Ministry of Home Affairs to DIPP
b) Manufacturing of Small Arms and Ammunitions Ministry of Home Affairs
covered under Arms Act 1959
(iii)

Broadcasting

Ministry of

Information &

(iv)

Print Media

Broadcasting

(v)

Civil Aviation

Ministry of Civil Aviation

(vi)

Satellites

Department of Space

(vii)

Telecommunication

Department

of

Telecommunications
(viii)

Private Security Agencies

(ix)

Applications involving investments from Countries of Ministry of Home Affairs
Concern which presently include Pakistan and
Bangladesh, requiring security clearance as per the
extant FEMA 20, FDI Policy and security guidelines,
amended from time to time

(x)

Trading (Single brand, Multi brand and Food Product
retail trading)

(xi)

FDI proposals by Non-Resident Indians (NRIs)/
Export Oriented Units requiring approval of the
Department

Government
(xii)

of

Industrial

Applications relating to issue of equity shares under Policy & Promotion
the FDI policy under the Government route for import
of capital goods/machinery/equipment (excluding
second-hand machinery)

(xiii)

Applications relating to issue of equity shares for preoperative/pre-incorporation

expenses

(including

payments of rent etc.)

19

<!-- page 21 -->

(xiv)

Financial services activity which are not regulated by
any Financial Sector Regulator or where only part of
the financial services activity is regulated or where
there is doubt regarding the regulatory oversight

(xv)

Department

of

Economic

of

Financial

Applications for foreign investment into a Core Affairs
Investment Company or an Indian company engaged
only in the activity of investing in the capital of other
India Company/ies

(xvi)

Banking (Public and Private)

Department
Services

(xvii)

Pharmaceuticals

Department

of

Pharmaceuticals
4.1.2

In respect of sectors/activities which are presently under automatic route but required
Government approval earlier as per the extant policy during the relevant period,
concerned administrative Ministry/Department would be the Competent Authorities for the
grant of post-facto approval for foreign investment.

4.1.3

In respect of applications in which there is a doubt about the Administrative
Ministry/Department concerned, DIPP shall identify the Administrative
Ministry/Department where the application will be processed.

4.1.4

Proposals for foreign investment would be examined by Competent Authorities as per the
Standard
Operating
Procedure
laid
down
by
DIPP
(available
at
http://www.fifp.gov.in/Forms/SOP.pdf).

4.1.5

In case of proposals involving total foreign equity inflow of more than Rs 5000 crore,
Competent Authority shall place the same for consideration of Cabinet Committee on
Economic Affairs (CCEA).

4.1.6

The CCEA would also consider the proposals which may be referred to it by the Ministerin-charge of the concerned Competent Authority.

4.1.7

In respect of proposals where the Competent Authority proposes to reject the proposals
or in cases where conditions for approval are stipulated in addition to the conditions laid
down in the FDI policy or sectoral laws/regulations, concurrence of DIPP shall
compulsorily be sought by the Competent Authority.

4.1.8

The monitoring of the compliance of conditions under the FDI approvals, including the
past cases approved by the Government, shall be done by the concerned Administrative
Ministries/Departments.

4.2

Cases which do not require Fresh Approval

4.2.1

Companies may not require fresh prior approval of the Government for bringing in
additional foreign investment into the same entity, in the following cases:

20

<!-- page 22 -->

(i) Entities the activities of which had earlier required prior approval of Government and
which had, accordingly, earlier obtained prior approval of Government for their initial
foreign investment but subsequently such activities/sectors have been placed under
automatic route;
(ii) Entities, the activities of which had sectoral caps earlier and which had, accordingly,
earlier obtained prior approval of Government for their initial foreign investment but
subsequently such caps were removed/increased and the activities placed under the
automatic route; provided that such additional investment along with the
initial/original investment does not exceed the sectoral caps;
(iii) Additional foreign investment into the same entity where prior approval
of
Government had been obtained earlier for the initial/original foreign investment due
to requirements of Press Note 18/1998 or Press Note 1 of 2005 and prior approval
of the Government under the FDI policy is not required for any other
reason/purpose; and
(iv) Additional foreign investment up to cumulative amount of Rs 5000 crore into the
same entity within an approved foreign equity percentage/or into a wholly owned
subsidiary.
4.3

Online Filing of Applications for Government Approval

4.3.1

Guidelines for e-filing of applications, filing of amendment applications and instructions
to applicants are available at the Foreign Investment Facilitation Portal
(www.fifp.gov.in).

21

<!-- page 23 -->

Chapter 5: Sector Specific Conditions on FDI
5.1 Prohibited Sectors
FDI is prohibited in:
a)
Lottery Business including Government/private lottery, online lotteries, etc.
b)

Gambling and Betting including casinos etc.

c)

Chit funds

d)

Nidhi company

e)

Trading in Transferable Development Rights (TDRs)

f)

Real Estate Business or Construction of Farm Houses
‘Real estate business’ shall not include development of townships, construction of
residential /commercial premises, roads or bridges and Real Estate Investment Trusts
(REITs) registered and regulated under the SEBI (REITs) Regulations 2014.

g)

Manufacturing of cigars, cheroots, cigarillos and cigarettes, of tobacco or of tobacco
substitutes

h)

Activities/sectors not open to private sector investment e.g.(I) Atomic Energy and (II)
Railway operations(other than permitted activities mentioned in para 5.2).
Foreign technology collaboration in any form including licensing for franchise,
trademark, brand name, management contract is also prohibited for Lottery Business
and Gambling and Betting activities.

5.2 Permitted Sectors
a)

In the following sectors/activities, FDI up to the limit indicated against each sector/activity is
allowed, subject to applicable laws/regulations; security and other conditionalities. In
sectors/activities not listed below, FDI is permitted up to100% on the automatic route,
subject to applicable laws/regulations; security and other conditionalities. Wherever there is
a requirement of minimum capitalization, it shall include share premium received along with
the face value of the share, only when it is received by the company upon issue of the
shares to the non-resident investor. Amount paid by the transferee during post-issue
transfer of shares beyond the issue price of the share, cannot be taken into account while
calculating minimum capitalization requirement.

b)

Sectoral cap i.e. the maximum amount which can be invested by foreign investors in an
entity, unless provided otherwise, is composite and includes all types of foreign
investments, direct and indirect, regardless of whether the said investments have been
made under Schedule 1 (FDI), 2 (FII), 2A (FPI), 3 (NRI), 6 (FVCI), 9 (LLPs), 10 (DRs) and
11(Investment Vehicle) of FEMA (Transfer or Issue of Security by Persons Resident
Outside India) Regulations. FCCBs and DRs having underlying of instruments which can
be issued under Schedule 5, being in the nature of debt, shall not be treated as foreign

22

<!-- page 24 -->

investment. However, any equity holding by a person resident outside India resulting from
conversion of any debt instrument under any arrangement shall be reckoned as foreign
investment under the composite cap.
c)

Foreign investment in sectors under Government approval route resulting in transfer of
ownership and/or control of Indian entities from resident Indian citizens to non-resident
entities will be subject to Government approval. Foreign investment in sectors under
automatic route but with conditionalities, resulting in transfer of ownership and/or control of
Indian entities from resident Indian citizens to non-resident entities, will be subject to
compliance of such conditionalities.

d)

The sectors which are already under 100% automatic route and are without conditionalities
would not be affected.

e)

Notwithstanding anything contained in paragraphs a) and c) above, portfolio investment, up
to aggregate foreign investment level of 49% or sectoral/statutory cap, whichever is lower,
will not be subject to either Government approval or compliance of sectoral conditions, as
the case may be, if such investment does not result in transfer of ownership and/or control
of Indian entities from resident Indian citizens to non-resident entities. Other foreign
investments will be subject to conditions of Government approval and compliance of
sectoral conditions as laid down in the FDI policy.

f)

Total foreign investment, direct and indirect, in an entity will not exceed the
sectoral/statutory cap.

g)

Any existing foreign investment already made in accordance with the policy in existence
would not require any modification to conform to amendments introduced through Press
Note 8 (2015 Series).

h)

The onus of compliance of above provisions will be on the investee company.

Agriculture
5.2.1 Agriculture & Animal Husbandry
Sector/Activity

% of Equity/
FDI Cap

Entry
Route

a) Floriculture, Horticulture, and Cultivation of Vegetables &

100%

Automatic

Mushrooms under controlled conditions;
b) Development and Production of seeds and planting material;
c) Animal Husbandry (including breeding of dogs), Pisciculture,
Aquaculture, Apiculture; and
d) Services related to agro and allied sectors
Note: Besides the above, FDI is not allowed in any other
agricultural sector/activity

23

<!-- page 25 -->

5.2.1.1 Other Conditions
I.

The term “under controlled conditions” covers the following:
(i) ‘Cultivation under controlled conditions’ for the categories of floriculture, horticulture,
cultivation of vegetables and mushrooms is the practice of cultivation wherein rainfall,
temperature, solar radiation, air humidity and culture medium are controlled artificially.
Control in these parameters may be effected through protected cultivation under green
houses, net houses, poly houses or any other improved infrastructure facilities where
micro-climatic conditions are regulated anthropogenically.

5.2.2 Plantation Sector
Sector/Activity

% of Equity/
FDI Cap

Entry Route

5.2.2.1
(i) Tea sector including tea plantations
(ii) Coffee plantations
(iii) Rubber plantations
(iv) Cardamom plantations
(v) Palm oil tree plantations
(vi) Olive oil tree plantations
Note: Besides the above, FDI is not allowed in any

100%

Automatic

other plantation sector/activity.
5.2.2.2 Other Condition
Prior approval of the State Government concerned is required in case of any future land use
change.
Mining and Petroleum & Natural Gas
5.2.3 Mining
Sector/Activity

% of
Equity/
FDI Cap

Entry Route

5.2.3.1
Mining and Exploration of metal and non-metal ores
including diamond, gold, silver and precious ores but
excluding titanium bearing minerals and its ores; subject to
the Mines and Minerals (Development & Regulation) Act,
1957.

100%

Automatic

5.2.3.2
Coal & Lignite
(1) Coal & Lignite mining for captive consumption by power
projects, iron & steel and cement units and other eligible
activities permitted under and subject to the provisions of

100%

Automatic

24

<!-- page 26 -->

Coal Mines (Nationalization) Act, 1973.
(2) Setting up coal processing plants like washeries subject
to the condition that the company shall not do coal mining and
shall not sell washed coal or sized coal from its coal
processing plants in the open market and shall supply the
washed or sized coal to those parties who are supplying raw
coal to coal processing plants for washing or sizing.
5.2.3.3
Mining and mineral separation of titanium bearing
minerals and ores, its value addition and integrated
activities
5.2.3.3.1
Mining and mineral separation of titanium bearing minerals &
ores, its value addition and integrated activities subject to

100%

Government

sectoral regulations and the Mines and Minerals (Development
and Regulation Act 1957).
5.2.3.3.2 Other Conditions
(i) FDI for separation of titanium bearing minerals & ores will be subject to the following
additional conditions viz.:
(A)

value addition facilities are set up within India along with transfer of technology;

(B) disposal of tailings during the mineral separation shall be carried out in accordance with
regulations framed by the Atomic Energy Regulatory Board such as Atomic Energy
(Radiation Protection) Rules, 2004 and the Atomic Energy (Safe Disposal of Radioactive
Wastes) Rules, 1987.
(ii) FDI will not be allowed in mining of “prescribed substances” listed in the Notification No.
S.O. 61(E), dated 18.1.2006, issued by the Department of Atomic Energy.
Clarification:
(1) For titanium bearing ores such as Ilmenite, Leucoxene and Rutile, manufacture of titanium
dioxide pigment and titanium sponge constitutes value addition. Ilmenite can be processed to
‘produce 'Synthetic Rutile or Titanium Slag as an intermediate value added product.
(2) The objective is to ensure that the raw material available in the country is utilized for setting
up downstream industries and the technology available internationally is also made available
for setting up such industries within the country. Thus, if with the technology transfer, the
objective of the FDI Policy can be achieved, the conditions prescribed at (i) (A) above shall
be deemed to be fulfilled.

25

<!-- page 27 -->

5.2.4 Petroleum & Natural Gas
Sector/Activity

% of
Equity/
FDI Cap

Entry
Route

5.2.4.1
Exploration activities of oil and natural gas fields, infrastructure
related to marketing of petroleum products and natural gas,
marketing of natural gas and petroleum products, petroleum product
pipelines, natural gas/pipelines, LNG Regasification infrastructure,
market study and formulation and Petroleum refining in the private
sector, subject to the existing sectoral policy and regulatory
framework in the oil marketing sector and the policy of the
Government on private participation in exploration of oil and the
discovered fields of national oil companies.

100%

Automatic

5.2.4.2

49%

Automatic

Petroleum refining by the Public Sector Undertakings (PSU), without
any disinvestment or dilution of domestic equity in the existing
PSUs.

Manufacturing
5.2.5 Manufacturing:
5.2.5.1 Subject to the provisions of the FDI policy, foreign investment in ‘manufacturing’ sector is
under automatic route. Further, a manufacturer is permitted to sell its products manufactured in
India through wholesale and/or retail, including through e-commerce, without Government
approval.
5.2.5.2 Notwithstanding the FDI policy provisions on trading sector, 100% FDI under Government
approval route is allowed for retail trading, including through e-commerce, in respect of food
products manufactured and/or produced in India.
5.2.6 Defence
Sector/Activity

5.2.6.1
Defence Industry subject to Industrial
license
under
the
Industries
(Development & Regulation) Act,
1951; and
Manufacturing of small arms and
ammunition under the Arms Act, 1959

% of Equity/
FDI Cap

Entry Route

Automatic up to 49%
100%

Government route beyond 49%
wherever it is likely to result in
access to modern technology or for
other reasons to be recorded

26

<!-- page 28 -->

5.2.6.2 Other Conditions
(i) Infusion of fresh foreign investment within the permitted automatic route level, in a company
not seeking industrial license, resulting in change in the ownership pattern or transfer of
stake by existing investor to new foreign investor, will require Government approval.
(ii) Licence applications will be considered and licences given by the Department of Industrial
Policy & Promotion, Ministry of Commerce & Industry, in consultation with Ministry of
Defence and Ministry of External Affairs.
(iii) Foreign investment in the sector is subject to security clearance and guidelines of the M/o
Defence.
(iv) Investee company should be structured to be self-sufficient in areas of product design and
development. The investee/joint venture company along with manufacturing facility, should
also have maintenance and life cycle support facility of the product being manufactured in
India.
Services Sector
5.2.7 Broadcasting
5.2.7.1 Broadcasting Carriage Services
Sector/Activity

% of
Equity/
FDI Cap

Entry Route

(1)Teleports(setting up of up-linking HUBs/Teleports);

100%

Automatic

100%

Automatic

5.2.7.1.1

(2)Direct to Home (DTH);
(3)Cable Networks (Multi System operators (MSOs)
operating at National or State or District level and
undertaking upgradation of networks towards digitalization
and addressability);
(4)Mobile TV;
(5)Headend-in-the Sky Broadcasting Service(HITS)
5.2.7.1.2
Cable

Networks(Other

MSOs

not

undertaking

upgradation of networks towards digitalization and
addressability and Local Cable Operators (LCOs))

27

<!-- page 29 -->

Note:
Infusion of fresh foreign investment, beyond 49% in a company not seeking license/permission
from sectoral Ministry, resulting in change in the ownership pattern or transfer of stake by
existing investor to new foreign investor, will require Government approval.

5.2.7.2 Broadcasting Content Services
Sector/Activity

% of
Equity/
FDI Cap

Entry Route

5.2.7.2.1 Terrestrial Broadcasting FM(FM Radio),
subject to such terms and conditions, as specified from
time to time, by Ministry of Information & Broadcasting, for
grant of permission for setting up of FM Radio stations

49%

Government

5.2.7.2.2

49%

Government

100%

Automatic

Up-linking of ‘News & Current Affairs’ TV Channels
5.2.7.2.3
Up-linking of Non-‘News & Current Affairs’ TV
Channels/ Down-linking of TV Channels

5.2.7.3 Detailed guidelines on the Broadcasting Sector are given in Annexure-7.
5.2.8 Print Media
Sector/Activity

% of Equity/ FDI Cap

Entry Route

5.2.8.1
Publishing of newspaper and periodicals dealing
with news and current affairs

26%

Government

5.2.8.2
Publication of Indian editions of foreign
magazines dealing with news and current affairs

26%

Government

5.2.8.2.1 Other Conditions
(i) ‘Magazine’, for the purpose of these guidelines, will be defined as a periodical publication,
brought out on non-daily basis, containing public news or comments on public news.

28

<!-- page 30 -->

(ii) Foreign investment would also be subject to the Guidelines for Publication of Indian editions
of foreign magazines dealing with news and current affairs issued by the Ministry of Information
& Broadcasting on 4.12.2008.
Sector/Activity

5.2.8.3

% of Equity/
FDI Cap

Entry
Route

100%

Government

100%

Government

Publishing/printing
of
scientific
and
technical
magazines/specialty journals/ periodicals, subject to
compliance with the legal framework as applicable and
guidelines issued in this regard from time to time by Ministry of
Information and Broadcasting.
5.2.8.4
Publication of facsimile edition of foreign newspapers

5.2.8.4.1 Other Conditions
(i) FDI should be made by the owner of the original foreign newspapers whose facsimile
edition is proposed to be brought out in India.
(ii) Publication of facsimile edition of foreign newspapers can be undertaken only by an entity
incorporated or registered in India under the provisions of the Companies Act, as
applicable.
(iii) Publication of facsimile edition of foreign newspaper would also be subject to the
Guidelines for publication of newspapers and periodicals dealing with news and current
affairs and publication of facsimile edition of foreign newspapers issued by Ministry of
Information & Broadcasting on 31.3.2006, as amended from time to time.

5.2.9 Civil Aviation
5.2.9.1 Airports
Sector/Activity

% of Equity/ FDI Cap

Entry Route

(a) Greenfield projects

100%

Automatic

(b) Existing projects

100%

Automatic

29

<!-- page 31 -->

5.2.9.2 Air Transport Services
Sector/Activity

% of Equity/
FDI Cap

(1) (a) Scheduled Air Transport Service/
Domestic Scheduled Passenger Airline

Entry Route

Automatic up to 49%
100%

(b) Regional Air Transport Service

(Automatic up to 100% for
NRIs)

Government route beyond
49%
(2)Non-Scheduled Air Transport Services

100%

Automatic

(3)Helicopter services/seaplane services
requiring DGCA approval

100%

Automatic

5.2.9.3 Other services under Civil Aviation sector
Sector/Activity

% of Equity/
FDI Cap

Entry Route

(1)Ground Handling Services subject to
sectoral regulations and security clearance

100%

Automatic

(2)Maintenance and Repair organizations;
flying training institutes; and technical
training institutions.

100%

Automatic

Definitions: The Civil Aviation sector includes Airports, Scheduled and Non-Scheduled domestic
passenger airlines, Helicopter services/Seaplane services, Ground Handling Services,
Maintenance and Repair organizations; Flying training institutes; and Technical training
institutions.
For the purposes of the Civil Aviation sector:

(i) “Airport” means a landing and taking off area for aircrafts, usually with runways and aircraft
maintenance and passenger facilities and includes aerodrome as defined in clause (2) of
section 2 of the Aircraft Act, 1934;

(ii) “Aerodrome” means any definite or limited ground or water area intended to be used, either
wholly or in part, for the landing or departure of aircraft, and includes all buildings, sheds,
vessels, piers and other structures thereon or pertaining thereto;

30

<!-- page 32 -->

(iii) “Air transport service” means a service for the transport by air of persons, mails or any other
thing, animate or inanimate, for any kind of remuneration whatsoever, whether such service
consists of a single flight or series of flights;

(iv) “Air Transport Undertaking” means an undertaking whose business includes the carriage by
air of passengers or cargo for hire or reward;

(v) “Aircraft component” means any part, the soundness and correct functioning of which, when
fitted to an aircraft, is essential to the continued airworthiness or safety of the aircraft and
includes any item of equipment;

(vi) “Helicopter” means a heavier-than-air aircraft supported in flight by the reactions of the air
on one or more power driven rotors on substantially vertical axis;

(vii) “Scheduled air transport service” means an air transport service undertaken between the
same two or more places and operated according to a published time table or with flights
so regular or frequent that they constitute a recognizably systematic series, each flight
being open to use by members of the public;

(viii) “Non-Scheduled air transport service” means any service which is not a scheduled air
transport service;

(ix) “Seaplane” means an aeroplane capable normally of taking off from and alighting solely on
water;

(x) “Ground Handling” means (i) ramp handling, (ii) traffic handling both of which shall include
the activities as specified by the Ministry of Civil Aviation through the Aeronautical
Information Circulars from time to time, and (iii) any other activity specified by the Central
Government to be a part of either ramp handling or traffic handling.
Other Conditions
(a) Air Transport Services would include Domestic Scheduled Passenger Airlines; NonScheduled Air Transport Services, helicopter and seaplane services.
(b) Foreign airlines are allowed to participate in the equity of companies operating Cargo
airlines, helicopter and seaplane services, as per the limits and entry routes mentioned
above.
(c) Foreign airlines are also allowed to invest in the capital of Indian companies, operating
scheduled and non-scheduled air transport services, up to the limit of 49% of their paid-up
capital. Such investment would be subject to the following conditions:
(i) It would be made under the Government approval route.
(ii) The 49% limit will subsume FDI and FII/FPI investment.

31

<!-- page 33 -->

(iii) The investments so made would need to comply with the relevant regulations of SEBI,
such as the Issue of Capital and Disclosure Requirements (ICDR)
Regulations/Substantial Acquisition of Shares and Takeovers (SAST) Regulations, as
well as other applicable rules and regulations.
(iv) A Scheduled Operator’s Permit can be granted only to a company:
a) that is registered and has its principal place of business within India;
b) the Chairman and at least two-thirds of the Directors of which
are citizens of India; and
c) the substantial ownership and effective control of which is vested
nationals.

in

Indian

(v) All foreign nationals likely to be associated with Indian scheduled and non-scheduled
air transport services, as a result of such investment shall be cleared from security view
point before deployment; and
(vi) All technical equipment that might be imported into India as a result of such investment
shall require clearance from the relevant authority in the Ministry of Civil Aviation.
Note:(i) The FDI limits/entry routes, mentioned at paragraph 5.2.9.2 (1) and 5.2.9.2 (2) above,
are applicable in the situation where there is no investment by foreign airlines.

(ii) The dispensation for NRIs regarding FDI up to 100% will also continue in respect of the
investment regime specified at para (c)(ii) above.

(iii) The policy mentioned at para (c) above is not applicable to M/s Air India Limited.
5.2.10 Construction Development: Townships, Housing, Built-up Infrastructure
Sector/Activity

5.2.10.1

%% of Equity/
FDI Cap

Entry Route

100%

Automatic

Construction-development projects (which would include
development
of
townships,
construction
of
residential/commercial premises, roads or bridges,
hotels, resorts, hospitals, educational institutions,
recreational facilities, city and regional level
infrastructure, townships)

32

<!-- page 34 -->

5.2.10.2
Each phase of the construction development project would be considered as a separate project
for the purposes of FDI policy. Investment will be subject to the following conditions:
(A) (i) The investor will be permitted to exit on completion of the project or after development of
trunk infrastructure i.e. roads, water supply, street lighting, drainage and sewerage.
(ii) Notwithstanding anything contained at (A) (i) above, a foreign investor will be permitted
to exit and repatriate foreign investment before the completion of project under automatic
route, provided that a lock-in-period of three years, calculated with reference to each
tranche of foreign investment has been completed. Further, transfer of stake from one
non-resident to another non-resident, without repatriation of investment will neither be
subject to any lock-in period nor to any government approval.
(B) The project shall conform to the norms and standards, including land use requirements and
provision of community amenities and common facilities, as laid down in the applicable building
control regulations, bye-laws, rules, and other regulations of the State
Government/Municipal/Local Body concerned.
(C) The Indian investee company will be permitted to sell only developed plots. For the purposes
of this policy “developed plots” will mean plots where trunk infrastructure i.e. roads, water supply,
street lighting, drainage and sewerage, have been made available.
(D) The Indian investee company shall be responsible for obtaining all necessary approvals,
including those of the building/layout plans, developing internal and peripheral areas and other
infrastructure facilities, payment of development, external development and other charges and
complying with all other requirements as prescribed under applicable rules/bye-laws/regulations
of the State Government/Municipal/Local Body concerned.
(E) The State Government/Municipal/Local Body concerned, which approves the
building/development plans, will monitor compliance of the above conditions by the developer.
Note:
(i) It is clarified that FDI is not permitted in an entity which is engaged or proposes to engage in
real estate business, construction of farm houses and trading in transferable development
rights (TDRs).
“Real estate business” means dealing in land and immovable property with a view to
earning profit there from and does not include development of townships, construction of
residential/ commercial premises, roads or bridges, educational institutions, recreational
facilities, city and regional level infrastructure, townships. Further, earning of rent/ income on
lease of the property, not amounting to transfer, will not amount to real estate business.
(ii) Condition of lock-in period at (A) above will not apply to Hotels &Tourist Resorts, Hospitals,
Special Economic Zones (SEZs), Educational Institutions, Old Age Homes and investment by
NRIs.

33

<!-- page 35 -->

(iii) Completion of the project will be determined as per the local bye-laws/rules and other
regulations of State Governments.
(iv) It is clarified that 100% FDI under automatic route is permitted in completed projects for
operation and management of townships, malls/ shopping complexes and business centres.
Consequent to foreign investment, transfer of ownership and/or control of the investee
company from residents to non-residents is also permitted. However, there would be a lockin-period of three years, calculated with reference to each tranche of FDI, and transfer of
immovable property or part thereof is not permitted during this period.
(v) “Transfer", in relation to FDI policy on the sector, includes,—
(a) the sale, exchange or relinquishment of the asset ; or
(b) the extinguishment of any rights therein; or
(c) the compulsory acquisition thereof under any law ; or
(d) any transaction involving the allowing of the possession of any immovable property to
be taken or retained in part performance of a contract of the nature referred to in
section 53A of the Transfer of Property Act, 1882 (4 of 1882) ; or
(e) any transaction, by acquiring shares in a company or by way of any agreement or any
arrangement or in any other manner whatsoever, which has the effect of transferring,
or enabling the enjoyment of, any immovable property.
5.2.11 Industrial Parks
Sector/Activity
Industrial Parks -new and existing

% of Equity/
FDI Cap

Entry Route

100%

Automatic

5.2.11.1 Other conditions for investment in Industrial Parks are at Annexure-8.
5.2.12 Satellites- establishment and operation
Sector/Activity

% of Equity/
FDI Cap

Entry Route

Satellites- establishment and operation, subject to the
sectoral guidelines of Department of Space/ISRO

100%

Government

34

<!-- page 36 -->

5.2.13 Private Security Agencies
Sector/Activity

Private Security Agencies

% of Equity/
FDI Cap

Entry Route

74%

Automatic up to 49%
Government route beyond 49%
and up to 74%

5.2.13.1 Other Conditions
(1) FDI in Private Security Agencies is subject to compliance with Private Security Agencies
(Regulation) (PSAR) Act, 2005, as amended from time to time.
(2) For the purposes of FDI policy on the sector, terms “Private Security Agencies”, “Private
Security” and “Armoured Car Service” will have the same meaning as provided under PSAR
Act, 2005, which is reproduced as under:
"Private Security Agency" means a person or body of persons other than a government
agency, department or organisation engaged in the business of providing private security
services including training to private security guards or their supervisor or providing private
security guards to any industrial or business undertaking or a company or any other person
or property;
"Private Security" means security provided by a person, other than a public servant, to
protect or guard any person or property or both and includes provision of armoured car
service;
"Armoured Car Service" means the service provided by deployment of armed guards along
with armoured car and such other related services which may be notified by the Central
Government or as the case may be, the State Government from time to time.
5.2.14 Telecom Services
Sector/Activity

% of Equity/
FDI Cap

Entry Route

Telecom Services
(including Telecom Infrastructure Providers Category-I)
All telecom services including Telecom Infrastructure
Providers Category-I, viz. Basic, Cellular, United Access
Services, Unified License (Access Services), Unified
License, National/International Long Distance, Commercial
V-Sat, Public Mobile Radio Trunked Services (PMRTS),
Global Mobile Personal Communications Services
(GMPCS), All types of ISP licenses, Voice
Mail/Audiotex/UMS, Resale of IPLC, Mobile Number
Portability Services, Infrastructure Provider Category-I
(providing dark fibre, right of way, duct space, tower) except
Other Service Providers.

100%

Automatic up
to 49%
Government
route beyond
49%

35

<!-- page 37 -->

5.2.14.1 Other Condition
FDI in Telecom sector is subject to observance of licensing and security conditions by licensee
as well as investors as notified by the Department of Telecommunications (DoT) from time to
time, except “Other Service Providers”, which are allowed 100% FDI on the automatic route.
5.2.15 Trading
Sector/Activity

5.2.15.1

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Cash & Carry Wholesale Trading/Wholesale Trading
(including sourcing from MSEs)

5.2.15.1.1Definition: Cash & Carry Wholesale trading/Wholesale trading, would mean sale of
goods/merchandise to retailers, industrial, commercial, institutional or other professional
business users or to other wholesalers and related subordinated service providers. Wholesale
trading would, accordingly, imply sales for the purpose of trade, business and profession, as
opposed to sales for the purpose of personal consumption. The yardstick to determine whether
the sale is wholesale or not would be the type of customers to whom the sale is made and not
the size and volume of sales. Wholesale trading would include resale, processing and thereafter
sale, bulk imports with ex-port/ex-bonded warehouse business sales and B2B e-Commerce.
5.2.15.1.2 Guidelines for Cash & Carry Wholesale Trading/Wholesale Trading (WT):
(a) For undertaking WT, requisite licenses/registration/ permits, as specified under the relevant
Acts/Regulations/Rules/Orders of the State Government/Government Body/Government
Authority/Local Self-Government Body under that State Government should be obtained.
(b) Except in case of sales to Government, sales made by the wholesaler would be considered
as ‘cash & carry wholesale trading/wholesale trading’ with valid business customers, only
when WT are made to the following entities:
(I) Entities holding sales tax/ VAT registration/service tax/excise duty registration; or
(II) Entities holding trade licenses i.e. a license/registration certificate/membership
certificate/registration under Shops and Establishment Act, issued by a Government
Authority/Government Body/Local Self-Government Authority, reflecting that the
entity/person holding the license/ registration certificate/ membership certificate, as the
case may be, is itself/ himself/herself engaged in a business involving commercial activity;
or
(III) Entities holding permits/license etc. for undertaking retail trade (like tehbazari and similar
license for hawkers) from Government Authorities/Local Self Government Bodies; or

36

<!-- page 38 -->

(IV) Institutions having certificate of incorporation or registration as a society or registration as
public trust for their self consumption.
Note: An entity, to whom WT is made, may fulfill any one of the 4 conditions.
(c) Full records indicating all the details of such sales like name of entity, kind of entity,
registration/license/permit etc. number, amount of sale etc. should be maintained on a day to
day basis.
(d) WT of goods would be permitted among companies of the same group. However, such WT
to group companies taken together should not exceed 25% of the total turnover of the
wholesale venture.
(e) WT can be undertaken as per normal business practice, including extending credit facilities
subject to applicable regulations.
(f) A wholesale/cash & carry trader can undertake retail trading, subject to the conditions as
applicable. An entity undertaking wholesale/cash and carry as well as retail business will be
mandated to maintain separate books of accounts for these two arms of the business and duly
audited by the statutory auditors. Conditions of the FDI policy for wholesale/cash and carry
business and for retail business have to be separately complied with by the respective
business arms.
5.2.15.2 E-commerce activities
Sector/Activity
E-commerce activities

% of Equity/FDI Cap

Entry Route

100%

Automatic

5.2.15.2.1 Subject to provisions of FDI Policy, e-commerce entities would engage only in
Business to Business (B2B) e-commerce and not in Business to Consumer (B2C) e-commerce.
5.2.15.2.2 Definitions:
i) E-commerce- E-commerce means buying and selling of goods and services including digital
products over digital & electronic network.
ii) E-commerce entity- E-commerce entity means a company incorporated under the
Companies Act 1956 or the Companies Act 2013 or a foreign company covered under section 2
(42) of the Companies Act, 2013 or an office, branch or agency in India as provided in section 2
(v) (iii) of FEMA 1999, owned or controlled by a person resident outside India and conducting the
e-commerce business.
iii) Inventory based model of e-commerce- Inventory based model of e-commerce means an
e-commerce activity where inventory of goods and services is owned by e-commerce entity and
is sold to the consumers directly.

37

<!-- page 39 -->

iv) Marketplace based model of e-commerce- Marketplace based model of e-commerce
means providing of an information technology platform by an e-commerce entity on a digital &
electronic network to act as a facilitator between buyer and seller.
5.2.15.2.3 Guidelines for Foreign Direct Investment on e-commerce sector
i) 100% FDI under automatic route is permitted in marketplace model of e-commerce.
ii) FDI is not permitted in inventory based model of e-commerce.
5.2.15.2.4 Other Conditions
i) Digital & electronic network will include network of computers, television channels and any
other internet application used in automated manner such as web pages, extranets, mobiles
etc.
ii) Marketplace e-commerce entity will be permitted to enter into transactions with sellers
registered on its platform on B2B basis.
iii) E-commerce marketplace may provide support services to sellers in respect of warehousing,
logistics, order fulfillment, call centre, payment collection and other services.
iv) E-commerce entity providing a marketplace will not exercise ownership over the inventory i.e.
goods purported to be sold. Such an ownership over the inventory will render the business
into inventory based model.
v) An e-commerce entity will not permit more than 25% of the sales value on financial year basis
affected through its marketplace from one vendor or their group companies.
vi) In marketplace model goods/services made available for sale electronically on website should
clearly provide name, address and other contact details of the seller. Post sales, delivery of
goods to the customers and customer satisfaction will be responsibility of the seller.
vii) In marketplace model, payments for sale may be facilitated by the e-commerce entity in
conformity with the guidelines of the Reserve Bank of India.
viii) In marketplace model, any warrantee/ guarantee of goods and services sold will be
responsibility of the seller.
ix) E-commerce entities providing marketplace will not directly or indirectly influence the sale
price of goods or services and shall maintain level playing field.
x) Guidelines on cash and carry wholesale trading as given in para 5.2.15.1.2 above will apply
on B2B e-commerce.
Subject to the conditions of FDI policy on services sector and applicable laws/regulations,
security and other conditionalities, sale of services through e-commerce will be under automatic
route.

38

<!-- page 40 -->

5.2.15.3 Single Brand Product Retail Trading
Sector/Activity

Single Brand product retail trading

% of Equity/
FDI Cap

Entry Route

100%

Automatic up to 49%
Government route
beyond 49%

(1) Foreign Investment in Single Brand product retail trading is aimed at attracting investments
in production and marketing, improving the availability of such goods for the consumer,
encouraging increased sourcing of goods from India, and enhancing competitiveness of Indian
enterprises through access to global designs, technologies and management practices.
(2) FDI in Single Brand product retail trading would be subject to the following conditions:
(a) Products to be sold should be of a ‘Single Brand’ only.
(b) Products should be sold under the same brand internationally i.e. products should
be sold under the same brand in one or more countries other than India.
(c) ‘Single Brand’ product-retail trading would cover only products which are branded
during manufacturing.
(d) A non-resident entity or entities, whether owner of the brand or otherwise, shall be
permitted to undertake ‘single brand’ product retail trading in the country for the
specific brand, directly or through a legally tenable agreement with the brand owner
for undertaking single brand product retail trading. The onus for ensuring
compliance with this condition will rest with the Indian entity carrying out singlebrand product retail trading in India. The investing entity shall provide evidence to
this effect at the time of seeking approval, including a copy of the
licensing/franchise/sub-licence agreement, specifically indicating compliance with
the above condition. The requisite evidence should be filed with the RBI for the
automatic route and to competent authority for cases involving approval.
(e) In respect of proposals involving foreign investment beyond 51%, sourcing of 30%
of the value of goods purchased, will be done from India, preferably from MSMEs,
village and cottage industries, artisans and craftsmen, in all sectors. The quantum
of domestic sourcing will be self-certified by the company, to be subsequently
checked, by statutory auditors, from the duly certified accounts which the company
will be required to maintain. This procurement requirement would have to be met, in
the first instance, as an average of five years’ total value of the goods purchased,
beginning 1st April of the year of the commencement of the business i.e. opening of
the first store. Thereafter, it would have to be met on an annual basis. For the
purpose of ascertaining the sourcing requirement, the relevant entity would be the
company, incorporated in India, which is the recipient of foreign investment for the

39

<!-- page 41 -->

purpose of carrying out single-brand product retail trading.
(f) Subject to the conditions mentioned in this Para, a single brand retail trading entity
operating through brick and mortar stores, is permitted to undertake retail trading
through e-commerce.
(3) Application seeking permission of the Government for FDI exceeding 49% in a company
which proposes to undertake single brand retail trading in India would be made to the
Secretariat for Industrial Assistance (SIA) in the Department of Industrial Policy & Promotion.
The applications would specifically indicate the product/product categories which are proposed
to be sold under a ‘Single Brand’. Any addition to the product/product categories to be sold
under ‘Single Brand’ would require a fresh approval of the Government. In case of FDI up to
49%, the list of products/product categories proposed to be sold except food products would
be provided to the RBI.
Note:
(i) Conditions mentioned at Para 5.2.15.3 (2) (b) & 5.2.15.3 (2) (d) will not be applicable for
undertaking SBRT of Indian brands.
(ii) Indian brands should be owned and controlled by resident Indian citizens and/or companies
which are owned and controlled by resident Indian citizens.
(iii)Sourcing norms will not be applicable up to three years from commencement of the
business i.e. opening of the first store for entities undertaking single brand retail trading of
products having ‘state-of-art’ and ‘cutting-edge’ technology and where local sourcing is not
possible. Thereafter, provisions of Para 5.2.15.3 (2) (e) will be applicable. A Committee under
the Chairmanship of Secretary, DIPP, with representatives from NITI Aayog, concerned
Administrative Ministry and independent technical expert(s) on the subject will examine the
claim of applicants on the issue of the products being in the nature of ‘state-of-art’ and ‘cuttingedge’ technology where local sourcing is not possible and give recommendations for such
relaxation.

5.2.15.4 Multi Brand Retail Trading
Sector/Activity

Multi Brand Retail Trading
(1)

% of Equity/
FDI Cap

Entry Route

51%

Government

FDI in multi brand retail trading, in all products, will be permitted, subject to the following
conditions:
(i) Fresh agricultural produce, including fruits, vegetables, flowers, grains, pulses, fresh
poultry, fishery and meat products, may be unbranded.

40

<!-- page 42 -->

(ii) Minimum amount to be brought in, as FDI, by the foreign investor, would be US $
100 million.
(iii) At least 50% of total FDI brought in the first tranche of US $ 100 million, shall be
invested in 'back-end infrastructure' within three years, where ‘back-end
infrastructure’ will include capital expenditure on all activities, excluding that on frontend units; for instance, back-end infrastructure will include investment made towards
processing, manufacturing, distribution, design improvement, quality control,
packaging, logistics, storage, ware-house, agriculture market produce infrastructure
etc. Expenditure on land cost and rentals, if any, will not be counted for purposes of
backend infrastructure. Subsequent investment in backend infrastructure would be
made by the MBRT retailer as needed, depending upon its business requirements.
(iv) At least 30% of the value of procurement of manufactured/processed products
purchased shall be sourced from Indian micro, small and medium industries, which
have a total investment in plant & machinery not exceeding US $ 2.00 million. This
valuation refers to the value at the time of installation, without providing for
depreciation. The ‘small industry’ status would be reckoned only at the time of first
engagement with the retailer, and such industry shall continue to qualify as a ‘small
industry’ for this purpose, even if it outgrows the said investment of US $ 2.00 million
during the course of its relationship with the said retailer. Sourcing from agricultural
co-operatives and farmers co-operatives would also be considered in this category.
The procurement requirement would have to be met, in the first instance, as an
average of five years’ total value of the manufactured/processed products
purchased, beginning 1st April of the year during which the first tranche of FDI is
received. Thereafter, it would have to be met on an annual basis.
(v) Self-certification by the company, to ensure compliance of the conditions at serial
nos. (ii), (iii) and (iv) above, which could be cross-checked, as and when required.
Accordingly, the investors shall maintain accounts, duly certified by statutory auditors.
(vi) Retail sales outlets may be set up only in cities with a population of more than 10
lakh as per 2011 Census or any other cities as per the decision of the respective
State Governments, and may also cover an area of 10 kms around the
municipal/urban agglomeration limits of such cities; retail locations will be restricted to
conforming areas as per the Master/Zonal Plans of the concerned cities and provision
will be made for requisite facilities such as transport connectivity and parking.
(vii) Government will have the first right to procurement of agricultural products.
(viii) The above policy is an enabling policy only and the State Governments/Union
Territories would be free to take their own decisions in regard to implementation of
the policy. Therefore, retail sales outlets may be set up in those States/Union
Territories which have agreed, or agree in future, to allow FDI in MBRT under this
policy. The list of States/Union Territories which have conveyed their agreement is at
(2) below. Such agreement, in future, to permit establishment of retail outlets under
this policy, would be conveyed to the Government of India through the Department of
Industrial Policy & Promotion and additions would be made to the list at (2) below

41

<!-- page 43 -->

accordingly. The establishment of the retail sales outlets will be in compliance of
applicable State/Union Territory laws/ regulations, such as the Shops and
Establishments Act etc.
(ix) Retail trading, in any form, by means of e-commerce, would not be permissible, for
companies with FDI, engaged in the activity of multi-brand retail trading.
(2) List of States/Union Territories as mentioned in Paragraph 5.2.15.4(1)(viii)
1. Andhra Pradesh
2. Assam
3. Delhi
4. Haryana
5. Himachal Pradesh
6. Jammu & Kashmir
7. Karnataka
8. Maharashtra
9. Manipur
10. Rajasthan
11. Uttarakhand
12. Daman & Diu and Dadra and Nagar Haveli (Union Territories)

5.2.15.5 Duty Free Shops
Sector/Activity

Duty Free Shops

% of Equity/
FDI Cap

Entry Route

100%

Automatic

(i) Duty Free Shops would mean shops set up in custom bonded area at International
Airports/International Seaports and Land Custom Stations where there is transit of
international passengers.
(ii) Foreign investment in Duty Free Shops is subject to compliance of conditions stipulated
under the Customs Act, 1962 and other laws, rules and regulations.
(iii) Duty Free Shop entity shall not engage into any retail trading activity in the Domestic Tariff
Area of the country.

42

<!-- page 44 -->

5.2.16 Railway Infrastructure
Sector/Activity

Railway Infrastructure

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Construction, operation and maintenance of the following:
(i) Suburban corridor projects through PPP, (ii) High speed
train projects, (iii) Dedicated freight lines, (iv) Rolling stock
including train sets, and locomotives/coaches manufacturing
and maintenance facilities, (v) Railway Electrification, (vi)
Signaling systems, (vii) Freight terminals, (viii) Passenger
terminals, (ix) Infrastructure in industrial park pertaining to
railway line/sidings including electrified railway lines and
connectivities to main railway line and (x) Mass Rapid
Transport Systems.
Note:
(i) Foreign Direct Investment in the abovementioned activities open to private sector
participation including FDI is subject to sectoral guidelines of Ministry of Railways.
(ii)Proposals involving FDI beyond 49% in sensitive areas from security point of view, will be
brought by the Ministry of Railways before the Cabinet Committee on Security (CCS) for
consideration on a case to case basis.

Financial Services
Foreign investment in other financial services, other than those indicated below, would require
prior approval of the Government.
5.2.17 Asset Reconstruction Companies
Sector/Activity

% of Equity/
FDI Cap

Entry Route

5.2.17.1‘Asset Reconstruction Company’ (ARC) means a

100%

Automatic

company registered with the Reserve Bank of India
under Section 3 of the Securitisation and Reconstruction
of Financial Assets and Enforcement of Security Interest
Act, 2002 (SARFAESI Act).

43

<!-- page 45 -->

5.2.17.2 Other Conditions
(i) Persons resident outside India can invest in the capital of Asset Reconstruction Companies
(ARCs) registered with Reserve Bank of India, up to 100% on the automatic route.
(ii) Investment limit of a sponsor in the shareholding of an ARC will be governed by the
provisions of Securitisation and Reconstruction of Financial Assets and Enforcement of
Security Interest Act, 2002, as amended from time to time. Similarly, investment by
institutional / non-institutional investors will also be governed by the said Act, as amended
from time to time.
(iii) The total shareholding of an individual FII/FPI shall be below 10% of the total paid-up capital.
(iv) FIIs/FPIs can invest in the Security Receipts (SRs) issued by ARCs. FIIs/FPIs may be
allowed to invest up to 100 per cent of each tranche in SRs issued by ARCs, subject to
directions/guidelines of Reserve Bank of India. Such investment should be within the
relevant regulatory cap as applicable.
(v) All investments would be subject to provisions of the Securitisation and Reconstruction of
Financial Assets and Enforcement of Security Interest Act, 2002, as amended from time to
time.
5.2.18 Banking- Private Sector
Sector/Activity
5.2.18.1
Banking- Private Sector

% of Equity/ FDI Cap

Entry Route

74%

Automatic up to 49%
Government route beyond 49%
and up to 74%.

5.2.18.2 Other Conditions
(1) This 74% limit will include investment under the Portfolio Investment Scheme (PIS) by
FIIs/FPIs, NRIs and shares acquired prior to September 16, 2003 by erstwhile OCBs, and
continue to include IPOs, Private placements, GDR/ADRs and acquisition of shares from
existing shareholders.
(2) The aggregate foreign investment in a private bank from all sources will be allowed up to a
maximum of 74 per cent of the paid up capital of the Bank. At all times, at least 26 per cent
of the paid up capital will have to be held by residents, except in regard to a wholly-owned
subsidiary of a foreign bank.
(3) The stipulations as above will be applicable to all investments in existing private sector
banks also.

44

<!-- page 46 -->

(4) Other conditions in respect of permissible limits under portfolio investment schemes through
stock exchanges for FIIs/FPIs and NRIs, setting-up of a subsidiary by foreign banks and
limits in respect of voting rights are at Annexure-9.
5.2.19 Banking- Public Sector
Sector/Activity

% of Equity/
FDI Cap

Entry Route

5.2.19.1 Banking- Public Sector subject to Banking
Companies (Acquisition & Transfer of Undertakings) Acts
1970/80. This ceiling (20%) is also applicable to the
State Bank of India and its associate Banks.

20%

Government

5.2.20 Credit Information Companies (CIC)
Sector/Activity

% of Equity/ FDI Cap

Entry Route

100%

Automatic

5.2.20.1
Credit Information Companies

5.2.20.2 Other Conditions
(1) Foreign investment in Credit Information Companies is subject to the Credit Information
Companies (Regulation) Act, 2005.
(2) Foreign investment is permitted subject to regulatory clearance from RBI.
(3) Such FII/FPI investment would be permitted subject to the conditions that:
(a) A single entity should directly or indirectly hold below 10% equity.
(b) Any acquisition in excess of 1% will have to be reported to RBI as a mandatory
requirement; and
(c) FIIs/FPIs investing in CICs shall not seek a representation on the Board of Directors
based upon their shareholding.
5.2.21 Infrastructure Company in the Securities Market
Sector/Activity
5.2.21.1Infrastructure

companies

in

% of Equity/ FDI Cap

Entry Route

49%

Automatic

Securities
Markets,
namely,
stock
exchanges,
commodity
exchanges,
depositories and clearing corporations, in
compliance with SEBI Regulations

45

<!-- page 47 -->

5.2.21.2 Other Conditions
(i) Foreign investment, including investment by FPIs, will be subject to the Securities Contracts
(Regulations) (Stock Exchanges and Clearing Corporations) Regulations 2012, and Securities
and Exchange Board of India (Depositories and Participants) Regulations, 1996 as amended
from time to time, and other Guidelines/Regulations issued by the Central Government, SEBI
and the Reserve Bank of India from time to time.
(ii) Words and expressions used herein and not defined in these regulations but defined in the
Companies Act, 2013 (18 of 2013) or the Securities Contracts (Regulation) Act, 1956 (42 of
1956) or the Securities and Exchange Board of India Act, 1992 (15 of 1992) or the Depositories
Act, 1996 (22 of 1996) or in the concerned Regulations issued by SEBI shall have the same
meanings respectively assigned to them in those Acts/ Regulations.
Definitions:
(1) Futures trading in commodities are regulated under the Forward Contracts (Regulation) Act,
1952. Commodity Exchanges, like Stock Exchanges, are infrastructure companies in the
commodity futures market. With a view to infuse globally acceptable best practices, modern
management skills and latest technology, it was decided to allow foreign investment in
Commodity Exchanges.
(2) For the purposes of this chapter,
(i)“Commodity Exchange” is a recognized association under the provisions of the Forward
Contracts (Regulation) Act, 1952, as amended from time to time, to provide exchange
platform for trading in forward contracts in commodities.
(ii) “recognized association” means an association to which recognition for the time being has
been granted by the Central Government under Section 6 of the Forward Contracts
(Regulation) Act, 1952
(iii)“Association” means any-body of individuals, whether incorporated or not, constituted for
the purposes of regulating and controlling the business of the sale or purchase of any
goods and commodity derivative.
(iv)“Forward contract” means a contract for the delivery of goods and which is not a ready
delivery contract.
(v) “Commodity derivative” means-

 a contract for delivery of goods, which is not a ready delivery contract; or
 a contract for differences which derives its value from prices or indices of prices of
such underlying goods or activities, services, rights, interests and events, as may be
notified in consultation with SEBI by the Central Government, but does not include
securities.

46

<!-- page 48 -->

5.2.22 Insurance
Sector/Activity

5.2.22.1

% of Equity/ FDI
Cap

Entry Route

49%

Automatic

(i) Insurance Company
(ii) Insurance Brokers
(iii) Third Party Administrators
(iv) Surveyors and Loss Assessors
(v)Other Insurance Intermediaries appointed under
the provisions of Insurance Regulatory and
Development Authority Act, 1999 (41 of 1999)

5.2.22.2 Other Conditions
(a) No Indian Insurance company shall allow the aggregate holdings by way of total foreign
investment in its equity shares by foreign investors, including portfolio investors, to exceed
forty-nine percent of the paid up equity capital of such Indian Insurance company.
(b) The foreign investment up to forty-nine percent of the total paid-up equity of the Indian
Insurance Company shall be allowed on the automatic route subject to approval/verification
by the Insurance Regulatory and Development Authority of India.
(c) Foreign investment in this sector shall be subject to compliance with the provisions of the
Insurance Act, 1938 and the condition that Companies receiving FDI shall obtain necessary
license /approval from the Insurance Regulatory & Development Authority of India for
undertaking insurance and related activities.
(d) An Indian Insurance company shall ensure that its ownership and control remains at all
times in the hands of resident Indian entities as determined by Department of Financial
Services/ Insurance Regulatory and Development Authority of India as per the
rules/regulation issued by them from time to time.
(e) Foreign portfolio investment in an Indian Insurance company shall be governed by the
provisions contained in sub-regulations (2), (2A), (3) and (8) of Regulation 5 of FEMA
Regulations, 2000 and provisions of the Securities and Exchange Board of India (Foreign
Portfolio Investors) Regulations, 2014.
(f)

Any increase in foreign investment in an Indian Insurance company shall be in accordance
with the pricing guidelines specified by Reserve Bank of India under the FEMA Regulations.

(g) The foreign equity investment cap of 49 percent shall apply on the same terms as above to
Insurance Brokers, Third Party Administrators, Surveyors and Loss Assessors and Other

47

<!-- page 49 -->

Insurance Intermediaries appointed under the provisions of the Insurance Regulatory and
Development Authority Act,1999 (41 of 1999).
(h) Provided that where an entity like a bank, whose primary business is outside the insurance
area, is allowed by the Insurance Regulatory and Development Authority of India to function
as an insurance intermediary, the foreign equity investment caps applicable in that sector
shall continue to apply, subject to the condition that the revenues of such entities from their
primary (i.e., non-insurance related) business must remain above 50 percent of their total
revenues in any financial year.
(i)

The provisions of paragraphs (i) (b) and (d) of Annexure 9 relating to ‘Banking-Private
Sector’, shall be applicable in respect of bank promoted insurance companies.

(j)

Terms ‘Control’, ‘Equity Share Capital’, ‘Foreign Direct Investment’ (FDI), ‘Foreign
Investors’, ‘Foreign Portfolio Investment’, ‘Indian Insurance Company’, ‘Indian Company’,
‘Indian Control of an Indian Insurance Company’, ‘Indian Ownership’, ‘Non-resident Entity’,
‘Public Financial Institution’, ‘Resident Indian Citizen’, ‘Total Foreign Investment’ will have
the same meaning as provided in Notification No. G.S.R 115 (E), dated 19th February, 2015
issued by Department of Financial Services and regulations issued by Insurance Regulatory
and Development Authority of India from time to time.

5.2.23 Pension Sector
Sector/Activity

Pension Sector

% of Equity/ FDI Cap

49%

Entry Route

Automatic

Other Conditions
(i) Foreign investment in the Pension Funds is allowed as per the Pension Fund Regulatory and
Development Authority (PFRDA) Act, 2013.
(ii) Foreign Investment in Pension Funds will be subject to the condition that entities bringing in
foreign equity investment as per Section 24 of the PFRDA Act shall obtain necessary
registration from the Pension Fund Regulatory and Development Authority and comply with
other requirements as per the PFRDA Act, 2013 and Rules and Regulations framed under it
for so participating in Pension Fund Management activities in India.
(iii) An Indian pension fund shall ensure that its ownership and control remains at all times in the
hands of resident Indian entities as determined by the Government of India/PFRDA as per
the rules/regulation issued by them from time to time.

48

<!-- page 50 -->

5.2.24 Power Exchanges
Sector/Activity

5.2.24.1

% of Equity/ FDI Cap

Entry Route

49%

Automatic

Power Exchanges registered under the
Central Electricity Regulatory Commission
(Power Market) Regulations, 2010.

5.2.24.2 Other Conditions
(i) FII/FPI purchases shall be restricted to secondary market only;
(ii) No non-resident investor/entity, including persons acting in concert, will hold more than 5% of
the equity in these companies; and
(iii) The foreign investment would be in compliance with SEBI Regulations; other applicable
laws/regulations; security and other conditionalities.
5.2.25 White Label ATM Operations
Sector/Activity

White Label ATM Operations

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Other Conditions
(i) Any non-bank entity intending to set up WLAs should have a minimum net worth of Rs. 100
crore as per the latest financial year’s audited balance sheet, which is to be maintained at all
times.
(ii) In case the entity is also engaged in any ‘Other Financial Services’ as laid down at Para
5.2.26 below, then the foreign investment in the company setting up WLA, shall also have to
comply with the minimum capitalization norms, if any, for foreign investments in such ‘Other
Financial Services’.
(iii) FDI in the WLAO will be subject to the specific criteria and guidelines issued by RBI vide
Circular No. DPSS.CO.PD.No. 2298/02.10.002/2011-2012, as amended from time to time.

49

<!-- page 51 -->

5.2.26 Other Financial Services
Sector/Activity

5.2.26.1

% of Equity/
FDI Cap

Entry Route

100%

Automatic

Financial Services activities regulated by financial sector
regulators, viz., RBI, SEBI, IRDA, PFRDA, NHB or any
other financial sector regulator as may be notified by the
Government of India.

5.2.26.2 Other Conditions
i.

Foreign investment in 'Other Financial Services' activities shall be subject to conditionalities,
including minimum capitalization norms, as specified by the concerned
Regulator/Government Agency.

ii. ‘Other Financial Services' activities need to be regulated by one of the Financial Sector
Regulators. In all such financial services activity which are not regulated by any Financial
Sector Regulator or where only part of the financial services activity is regulated or where
there is doubt regarding the regulatory oversight, foreign investment up to 100% will be
allowed under Government approval route subject to conditions including minimum
capitalization requirement, as may be decided by the Government.
iiii. Any activity which is specifically regulated by an Act, the foreign investment limits will be
restricted to those levels/limit that may be specified in that Act, if so mentioned.
iv. Downstream investments by any of these entities engaged in "Other Financial Services" will
be subject to the extant sectoral regulations and provisions of Foreign Exchange
Management (Transfer or Issue of Security by a Person Resident outside India)
Regulations, 2000, as amended from time to time.
Others
5.2.27 Pharmaceuticals
Sector/Activity

% of Equity/ FDI Cap

Entry Route

5.2.27.1
Greenfield

100%

Automatic

5.2.27.2
Brownfield

100%

Automatic up to 74%
Government route beyond
74%

50

<!-- page 52 -->

5.2.27.3 Other Conditions
(i) ‘Non-compete’ clause would not be allowed in automatic or government approval route
except in special circumstances with the approval of the Government.
(ii) The prospective investor and the prospective investee are required to provide a certificate
along with the application for foreign investment as per Annexure-10.
(iii) Government may incorporate appropriate conditions for FDI in brownfield cases, at the time
of granting approval.
(iv) FDI in brownfield pharmaceuticals, under both automatic and government approval routes, is
further subject to compliance of following conditions:
(a) The production level of National List of Essential Medicines (NLEM) drugs and/or
consumables and their supply to the domestic market at the time of induction of FDI, being
maintained over the next five years at an absolute quantitative level. The benchmark for this
level would be decided with reference to the level of production of NLEM drugs and/or
consumables in the three financial years, immediately preceding the year of induction of
FDI. Of these, the highest level of production in any of these three years would be taken as
the level.
(b) R&D expenses being maintained in value terms for 5 years at an absolute quantitative level
at the time of induction of FDI. The benchmark for this level would be decided with
reference to the highest level of R&D expenses which has been incurred in any of the three
financial years immediately preceding the year of induction of FDI.
(c) The administrative Ministry will be provided complete information pertaining to the transfer of
technology, if any, along with induction of foreign investment into the investee company.
(d) The administrative Ministry (s) i.e. Ministry of Health and Family Welfare, Department of
Pharmaceuticals or any other regulatory Agency/Development as notified by Central
Government from time to time, will monitor the compliance of conditionalities.
Note:
i. FDI up to 100%, under the automatic route is permitted for manufacturing of medical
devices. The above mentioned conditions will, therefore, not be applicable to greenfield as
well as brownfield projects of this industry.
ii. Medical device meansa. any instrument, apparatus, appliance, implant, material or other article, whether used
alone or in combination, including the software, intended by its manufacturer to be
used specially for human beings or animals for one or more of the specific purposes
of(aa) diagnosis, prevention, monitoring, treatment or alleviation of any disease or
disorder;

51

<!-- page 53 -->

(ab) diagnosis, monitoring, treatment, alleviation of, or assistance for, any injury or
handicap;
(ac) investigation, replacement or modification or support of the anatomy or of a
physiological process;
(ad) supporting or sustaining life;
(ae) disinfection of medical devices;
(af) control of conception,
and which does not achieve its primary intended action in or on the human body or
animals by any pharmacological or immunological or metabolic means, but which
may be assisted in its intended function by such means;
b. an accessory to such an instrument, apparatus, appliance, material or other article;
c. a device which is reagent, reagent product, calibrator, control material, kit, instrument,
apparatus, equipment or system whether used alone or in combination thereof
intended to be used for examination and providing information for medical or
diagnostic purposes by means of in vitro examination of specimens derived from the
human body or animals.
iii.

The definition of medical device at Note (ii) above would be subject to the amendment in
Drugs and Cosmetics Act.

52

<!-- page 54 -->

Annexures
Annexure-1

Form FC-GPR
(To be filed by the company through its Authorised Dealer Category – I bank with the Regional Office
of the RBI under whose jurisdiction the Registered Office of the company making the declaration is
situated as and when shares/convertible debentures / others are issued to the foreign investor, along
with the documents mentioned in item No. 5 of the undertaking enclosed to this form. All fields are
mandatory) .

Permanent Account Number
(PAN) of the investee company
given by the Income Tax
Department

Date of issue of shares /
convertible debentures/others

Particulars

(In Block Letters)

No.
1.

Name of the Investee Company

Address of the Registered Office of
the Investee Company with City,
District and State clearly mentioned
Telephone
Fax
e-mail
State
Registration No. given by Registrar
of Companies and Date of
Incorporation.

Whether existing company or new
company (strike off whichever is not
applicable)

Existing company / New company
(Brownfield)
( Greenfield)

53

<!-- page 55 -->

If existing company, give
registration number allotted by RBI
for FDI, if any

2.

Description of the main business
activity NIC Code
Location of the project and NIC code
for the district where the project is
located
a)Detailed address including Name,
City, District and State
b) Code for District
c) Code for State
Percentage of FDI allowed as per
FDI policy (Sectoral cap under FDI
Policy)
State whether FDI is allowed under Automatic Route / Approval Route
Automatic Route or Approval Route
(strike out whichever is not
applicable) (If under approval route,
give relevant approval No. with
date)

3

Details of the foreign investor / collaborator2 (Details of foreign residence to be
given. Indian address if any should not be given)
Name
Address
Country
Constitution / Nature of the
investing Entity
[Specify whether
1. Individual
2. Company (Please specify if

erstwhile OCB)
3. FII



If there is more than one foreign investor/collaborator, separate Annexure may be included for items 3 and 4 of the
Form.
2 SWF means a Government investment vehicle which is funded by foreign exchange assets, and which manages those assets
separately from the official reserves of the monetary authorities.

54

<!-- page 56 -->

4. FVCI



5. Foreign Trust
6. Private Equity Fund
7. Pension / Provident Fund
8. Sovereign Wealth Fund

(SWF)3
9. Partnership / Proprietorship

Firm
10. Financial Institution
11. NRIs / PIO
12. Others (please specify)]

Date of incorporation:

4

Particulars of Shares / Convertible Debentures /others Issued

(a)

Nature and date of issue
Nature of issue
01

IPO / FPO

02

Preferential allotment /
private placement

03

Rights

04

Bonus

05

Conversion of ECB

06

Conversion of royalty
(including lump sum
payments)

07

Conversion against import of
capital goods by units in SEZ

08

ESOPs

09

Share Swap

10

Others (please specify)

Date of issue

Number of shares/ convertible
debentures/others

Total



The investment/s is/are made by FVCI under FDI Scheme in terms of Schedule I to Notification No. FEMA
20/2000-RB dated May 3, 2000.

55

<!-- page 57 -->

(b)

Type of security issued

No
.

Nature of

01

Equity

02

Compulsoril
y
Convertible
Debentures

03

Compulsoril
y
Convertible
Preference
shares

04

Others
(please
specify)

security

Numbe
r

Maturit
y

Face
value

Premiu
m

Issue
Price
per
security

Amount of
inflow*

Total
i) In case the issue price is greater than the face value please give break up of the premium
received.
ii) * In case the issue is against conversion of ECB or royalty or against import of capital goo’s by
units in SEZ, a Chartered Accountant's Certificate certifying the amount outstanding on the date of
conversion

(c)

Break up of premium

Amount

Control Premium
Non competition fee
Others@
Total
@

Please specify the nature
(d)

Total inflow (in Rupees) on account of issue of
shares / convertible debentures/others to nonresidents (including premium, if any) vide
(i) Remittance through AD:
(ii) Debit to NRE/FCNR/Escrow A/c with
Bank_________
(iii) Others (please specify)

56

<!-- page 58 -->

Date of reporting of (i) and (ii) above to RBI
under Para 9 (1) A of Schedule I to Notification
No. FEMA 20 /2000-RB dated May 3, 2000, as
amended from time to time.

(e)

Disclosure of fair value of shares issued**
We are a listed company and the market value
of a share as on date of the issue is*
We are an un-listed company and the fair
value of a share is*

** before issue of shares

*(Please indicate as applicable)

5. Post issue pattern of shareholding
Equity

Compulsorily
convertible
Preference Shares/
Debentures/others

a)

(Face
Value)
%
Rs.

(Face
Value)
%
Rs.
No.
of
shares
Amount

No.
of
shares
Amount

Investor category

Non-Resident
01

Individuals

02

Companies

03

FIIs

04

FVCIs

05

Foreign Trusts

06

Private Equity Funds

07

Pension/ Provident Funds

08

Sovereign Wealth Funds

09

Partnership/ Proprietorship Firms

10

Financial Institutions

11

NRIs/PIO

12

Others (please specify)
Sub Total



The investment/s is/are made by FVCI under FDI Scheme in terms of Schedule I to Notification No. FEMA
20/2000-RB dated May 3, 2000.

57

<!-- page 59 -->

b)

Resident

Total
DECLARATION TO BE FILED BY THE AUTHORISED REPRESENTATIVE OF THE INDIAN
COMPANY:(Delete whichever is not applicable and authenticate)
We hereby declare that:
1. We comply with the procedure for issue of shares / convertible debentures as laid down under
the FDI scheme as indicated in Notification No. FEMA 20/2000-RB dated 3rd May 2000, as
amended from time to time.
2. The investment is within the sectoral cap / statutory ceiling permissible under the Automatic
Route of RBI and we fulfil all the conditions laid down for investments under the Automatic Route
namely (strike off whichever is not applicable).
a) Shares issued on rights basis to non-residents are in conformity with Regulation 6 of the RBI
Notification No FEMA 20/2000-RB dated 3rd May 2000, as amended from time to time.
OR
b) Shares issued are bonus.
OR
c)Shares have been issued under a scheme of merger and amalgamation of two or more
Indian companies or reconstruction by way of de-merger or otherwise of an Indian company,
duly approved by a court in India.
OR
d)Shares are issued under ESOP and the conditions regarding this issue have been satisfied
3. Shares have been issued in terms of Government approval No.___________________
dated ____________________
4 The foreign investment received and reported now will be utilized in compliance with the provision
of a Prevention of Money Laundering Act 2002 (PMLA) and Unlawful Activities(Prevention) Act,
1967 (UAPA). We confirm that the investment complies with the provisions of all applicable Rules
and Regulations
5. We enclose the following documents in compliance with Paragraph 9 (1) (B) of Schedule 1 to
Notification No. FEMA 20/2000-RB dated May 3, 2000:
(i)

A certificate from our Company Secretary certifying that
(a)

all the requirements of the Companies Act, 1956 have been complied with;

(b)

terms and conditions of the Government approval, if any, have been complied
with;

(c)

the company is eligible to issue shares under these Regulations; and

(d)

the company has all original certificates issued by authorised dealers in India
evidencing receipt of amount of consideration in accordance with paragraph 8
of Schedule 1 to Notification No. FEMA 20/2000-RB dated May 3, 2000.

58

<!-- page 60 -->

(ii)

A certificate from SEBI registered Merchant Banker / Chartered Accountant indicating
the manner of arriving at the price of the shares issued to the persons resident outside
India.

6. Unique Identification Numbers given for all the remittances received as consideration for issue
of shares/ convertible debentures/others (details as above), by Reserve Bank.

R
.
.
.

R

(Signature of the Applicant)* :___________________________________________
(Name in Block Letters)

:___________________________________________

(Designation of the signatory) :___________________________________________
Place:
Date:
(* To be signed by Managing Director/Director/Secretary of the Company)

CERTIFICATE TO BE FILED BY THE COMPANY SECRETARY 4 OF THE INDIAN COMPANY
ACCEPTING THE INVESTMENT:
(As per Para 9 (1) (B) (i) of Schedule 1 to Notification No. FEMA 20/2000-RB dated May 3,
2000)
In respect of the abovementioned details, we certify the following :
1. All the requirements of the Companies Act, 1956 have been complied with.
2. Terms and conditions of the Government approval, if any, have been complied with.
3. The company is eligible to issue shares / convertible debentures/others under these Regulations.
4. The company has all original certificates issued by AD Category – I banks in India, evidencing
receipt of amount of consideration in accordance with paragraph 8 of Schedule 1 to Notification No.
FEMA 20/2000-RB dated May 3, 2000.

(Name & Signature of the Company Secretary) (Seal)

4

If the company doesn’t have full time Company Secretary, a certificate from practicing Company Secretary may be
submitted

59

<!-- page 61 -->

FOR USE OF THE RESERVE BANK ONLY:
Registration Number for the FC-GPR:
Unique Identification Number allotted to the
Company at the time of reporting receipt of
remittance

60

<!-- page 62 -->

Annexure-2
Types of Instruments
1.

Indian companies can issue equity shares, fully, compulsorily and mandatorily convertible
debentures and fully, compulsorily and mandatorily convertible preference shares subject to
pricing guidelines/valuation norms prescribed under FEMA Regulations. The price/conversion
formula of convertible capital instruments should be determined upfront at the time of issue of
the instruments. The price at the time of conversion should not in any case be lower than the
fair value worked out, at the time of issuance of such instruments, in accordance with the
extant FEMA regulations [as per any internationally accepted pricing methodology on arm’s
length basis for the unlisted companies and valuation in terms of SEBI (ICDR) Regulations, for
the listed companies].

1.1 Optionality clauses are allowed in equity shares, fully, compulsorily and mandatorily
convertible debentures and fully, compulsorily and mandatorily convertible preference shares
under FDI scheme, subject to the following conditions:
(a) There is a minimum lock-in period of one year which shall be effective from the date of
allotment of such capital instruments.
(b) After the lock-in period and subject to FDI Policy provisions, if any, the non-resident
investor exercising option/right shall be eligible to exit without any assured return, as per
pricing/valuation guidelines issued by RBI from time to time.
2.

Other types of Preference shares/Debentures i.e. non-convertible, optionally convertible or
partially convertible for issue of which funds have been received on or after May 1, 2007 are
considered as debt. Accordingly all norms applicable for ECBs relating to eligible borrowers,
recognized lenders, amount and maturity, end-use stipulations, etc. shall apply. Since these
instruments would be denominated in rupees, the rupee interest rate will be based on the
swap equivalent of London Interbank Offered Rate (LIBOR) plus the spread as permissible for
ECBs of corresponding maturity.

3.

The inward remittance received by the Indian company vide issuance of DRs and FCCBs are
treated as FDI and counted towards FDI.

4.

Acquisition of Warrants and Partly Paid Shares - An Indian company may issue warrants
and partly paid shares to a person resident outside India subject to terms and conditions as
stipulated by the Reserve Bank of India in this behalf, from time to time.

5.

Issue of Foreign Currency Convertible Bonds (FCCBs) and Depository Receipts(DRs)
a)FCCBs/DRs may be issued in accordance with the Scheme for issue of Foreign Currency
Convertible Bonds and Ordinary Shares (Through Depository Receipt Mechanism)
Scheme, 1993 and DR Scheme 2014 respectively, as per the guidelines issued by the
Government of India there under from time to time.
b)DRs are foreign currency denominated instruments issued by a foreign Depository in a
permissible jurisdiction against a pool of permissible securities issued or transferred to
that foreign depository and deposited with a domestic custodian.

61

<!-- page 63 -->

c) In terms of Notification No. FEMA.20/2000-RB dated May 3, 2000 as amended from time to
time, a person will be eligible to issue or transfer eligible securities to a foreign depository,
for the purpose of converting the securities so purchased into depository receipts in terms
of Depository Receipts Scheme, 2014 and guidelines issued by the Government of India
thereunder from time to time.
d)A person can issue DRs, if it is eligible to issue eligible instruments to person resident
outside India under Schedules 1, 2, 2A, 3, 5 and 8 of Notification No. FEMA 20/2000-RB
dated May 3, 2000, as amended from time to time.
e)The aggregate of eligible securities which may be issued or transferred to foreign
depositories, along with eligible securities already held by persons resident outside India,
shall not exceed the limit on foreign holding of such eligible securities under the relevant
regulations framed under FEMA, 1999.
f) The pricing of eligible securities to be issued or transferred to a foreign depository for the
purpose of issuing depository receipts should not be at a price less than the price
applicable to a corresponding mode of issue or transfer of such securities to domestic
investors under the relevant regulations framed under FEMA, 1999.
g)The issue of depository receipts as per DR Scheme 2014 shall be reported to the Reserve
Bank by the domestic custodian as per the reporting guidelines for DR Scheme 2014.
6. (i) Two-way Fungibility Scheme: A limited two-way Fungibility scheme has been put in place
by the Government of India for ADRs/GDRs. Under this Scheme, a stock broker in India,
registered with SEBI, can purchase shares of an Indian company from the market for
conversion into ADRs/GDRs based on instructions received from overseas investors. Reissuance of ADRs/GDRs would be permitted to the extent of ADRs/GDRs which have been
redeemed into underlying shares and sold in the Indian market.
(ii) Sponsored ADR/GDR issue: An Indian company can also sponsor an issue of ADR/GDR.
Under this mechanism, the company offers its resident shareholders a choice to submit their
shares back to the company so that on the basis of such shares, ADRs/GDRs can be issued
abroad. The proceeds of the ADR/GDR issue are remitted back to India and distributed
among the resident investors who had offered their Rupee denominated shares for
conversion. These proceeds can be kept in Resident Foreign Currency (Domestic) accounts
in India by the resident shareholders who have tendered such shares for conversion into
ADRs/GDRs.

62

<!-- page 64 -->

Annexure-3
Provisions Relating to Issue/ Transfer of Shares
1.

The capital instruments should be issued within 180 days from the date of receipt of the
inward remittance received through normal banking channels including escrow account
opened and maintained for the purpose or by debit to the NRE/FCNR (B) account of the
non-resident investor. In case, the capital instruments are not issued within 180 days from
the date of receipt of the inward remittance or date of debit to the NRE/FCNR (B) account,
the amount of consideration so received should be refunded immediately to the nonresident investor by outward remittance through normal banking channels or by credit to
the NRE/FCNR (B) account, as the case may be. Non-compliance with the above
provision would be reckoned as a contravention under FEMA and would attract penal
provisions. In exceptional cases, refund of the amount of consideration outstanding
beyond a period of 180 days from the date of receipt may be considered by the RBI, on
the merits of the case.

2.

Issue price of shares
Price of shares issued to persons resident outside India under the FDI Policy, shall not be
less than –
a. the price worked out in accordance with the SEBI guidelines, as applicable, where the
shares of the company are listed on any recognised stock exchange in India;
b. the fair valuation of shares done by a SEBI registered Merchant Banker or a Chartered
Accountant as per any internationally accepted pricing methodology on arm’s length basis,
where the shares of the company are not listed on any recognised stock exchange in
India; and
c. the price as applicable to transfer of shares from resident to non-resident as per the
pricing guidelines laid down by the Reserve Bank from time to time, where the issue of
shares is on preferential allotment.
However, where non-residents (including NRIs) are making investments in an Indian
company in compliance with the provisions of the Companies Act, as applicable, by way of
subscription to its Memorandum of Association, such investments may be made at face
value subject to their eligibility to invest under the FDI scheme.

3.

Foreign Currency Account
Indian companies which are eligible to issue shares to persons resident outside India
under the FDI Policy may be allowed to retain the share subscription amount in a Foreign
Currency Account, with the prior approval of RBI.

4.
(i)

Transfer of shares and convertible debentures
Subject to FDI sectoral policy (relating to sectoral caps and entry routes), applicable laws
and other conditionalities including security conditions, non-resident investors can also
invest in Indian companies by purchasing/acquiring existing shares from Indian
shareholders or from other non-resident shareholders. General permission has been
granted to non-residents/NRIs for acquisition of shares by way of transfer subject to the
following:

63

<!-- page 65 -->

(ii)

(a)

A person resident outside India (other than NRI and erstwhile OCB) may transfer by
way of sale or gift, the shares or convertible debentures to any person resident
outside India (including NRIs). Government approval is not required for transfer of
shares in the investee company from one non-resident to another non-resident in
sectors which are under automatic route. In addition, approval of Government will be
required for transfer of stake from one non-resident to another non-resident in
sectors which are under Government approval route.

(b)

NRIs may transfer by way of sale or gift the shares or convertible debentures held
by them to another NRI.

(c)

A person resident outside India can transfer any security to a person resident in
India by way of gift.

(d)

A person resident outside India can sell the shares and convertible debentures of an
Indian company on a recognized Stock Exchange in India through a stock broker
registered with stock exchange or a merchant banker registered with SEBI.

(e)

A person resident in India can transfer by way of sale, shares/ convertible
debentures (including transfer of subscriber’s shares), of an Indian company under
private arrangement to a person resident outside India, subject to the guidelines
given in para 5.2 and Section 1 of this Annexure.

(f)

General permission is also available for transfer of shares/convertible debentures,
by way of sale under private arrangement by a person resident outside India to a
person resident in India, subject to the guidelines given in para 5.2 and Section 1 of
this Annexure.

(g)

The above General Permission also covers transfer by a resident to a non-resident
of shares/convertible debentures of an Indian company, engaged in an activity
earlier covered under the Government Route but now falling under Automatic Route,
as well as transfer of shares by a non-resident to an Indian company under buyback
and/or capital reduction scheme of the company.

(h)

The Form FC-TRS should be submitted to the AD Category-I Bank, within 60 days
from the date of receipt of the amount of consideration. The onus of submission of
the Form FC-TRS within the given timeframe would be on the transferor/transferee,
resident in India. However, in cases where the NR investor, including an NRI,
acquires shares on the stock exchanges under the FDI scheme, the investee
company would have to file form FC-TRS with the AD Category-I bank.
The sale consideration in respect of equity instruments purchased by a person resident
outside India, remitted into India through normal banking channels, shall be subjected
to a Know Your Customer (KYC) check by the remittance receiving AD Category-I bank
at the time of receipt of funds. In case, the remittance receiving AD Category-I bank is
different from the AD Category-I bank handling the transfer transaction, the KYC check
should be carried out by the remittance receiving bank and the KYC report be
submitted by the customer to the AD Category-I bank carrying out the transaction along
with the Form FC-TRS.

(iii) A person resident outside India including a Non-Resident Indian investor who has already
acquired and continues to hold the control in accordance with the SEBI (Substantial

64

<!-- page 66 -->

Acquisition of Shares and Takeover) Regulations can acquire shares of a listed Indian
company on the stock exchange through a registered broker under FDI scheme
provided that the original and resultant investments are in line with the extant FDI policy
and FEMA regulations in respect of sectoral cap, entry route,mode of payment,
reporting requirement, documentation, etc.
(iv)

Escrow: AD Category-I banks have been given general permission to open Escrow
account and Special account of non-resident corporate for open offers/exit offers and
delisting of shares. The relevant SEBI (Substantial Acquisition of Shares and
Takeovers) Regulations, 2011 (SAST) Regulations or any other applicable SEBI
Regulations/provisions of the Companies Act, as applicable will be applicable. AD
Category-I banks have also been permitted to open and maintain, without prior
approval of RBI, non-interest bearing Escrow accounts in Indian Rupees in India on
behalf of residents and/or non-residents, towards payment of share purchase
consideration and/or provide Escrow facilities for keeping securities to facilitate FDI
transactions subject to the65terms and conditions specified by RBI. SEBI authorised
Depository Participants have also been permitted to open and maintain, without prior
approval of RBI, Escrow accounts for securities subject to the terms and conditions as
specified by RBI. In both cases, the Escrow agent shall 65necessarily be an AD
Category-I bank or SEBI authorised Depository Participant (in case of securities’
accounts). These facilities will be applicable for both issue of fresh shares to the nonresidents as well as transfer of shares from/to the non- residents.

(v)

In case of transfer of shares between a resident buyer and a non-resident seller or
vice-versa, not more than twenty five per cent of the total consideration can be paid by
the buyer on a deferred basis within a period not exceeding eighteen months from the
date of the transfer agreement. For this purpose, if so agreed between the buyer and
the seller, an escrow arrangement may be made between the buyer and the seller for
an amount not more than twenty five per cent of the total consideration for a period not
exceeding eighteen months from the date of the transfer agreement or if the total
consideration is paid by the buyer to the seller, the seller may furnish an indemnity for
an amount not more than twenty five per cent of the total consideration for a period not
exceeding eighteen months from the date of the payment of the full consideration.
Provided the total consideration finally paid for the shares must be compliant with the
applicable pricing guidelines.

5. Prior permission of RBI in certain cases for transfer of capital instruments
5.1

Except cases mentioned in paragraph 5.2 below, the following cases require prior
approval of RBI:
(i)

Transfer of capital instruments from resident to non-residents by way of sale where:
(a) Transfer is at a price which falls outside the pricing guidelines specified by the
Reserve Bank from time to time and the transaction does not fall under the
exception given in para 5.2.

65

<!-- page 67 -->

(b) Transfer of capital instruments by the non-resident acquirer involving deferment
of payment of the amount of consideration. Further, in case approval is granted
for a transaction, the same should be reported in Form FC-TRS, to an AD
Category-I bank for necessary due diligence, within 60 days from the date of
receipt of the full and final amount of consideration.
(ii) Transfer of any capital instrument, by way of gift by a person resident in India to a
person resident outside India. While forwarding applications to Reserve Bank for
approval for transfer of capital instruments by way of gift, the documents mentioned
in Section 2 of this Annexure should be enclosed. Reserve Bank considers the
following factors while processing such applications:
(a) The proposed transferee (donee) is eligible to hold such capital instruments under
Schedules 1, 4 and 5 of Notification No. FEMA 20/2000-RB dated May 3, 2000, as
amended from time to time.
(b) The gift does not exceed 5 per cent of the paid-up capital of the Indian
company/each series of debentures/each mutual fund scheme.
(c) The applicable sectoral cap limit in the Indian company is not breached.
(d) The transferor (donor) and the proposed transferee (donee) are close relatives as
defined in Section 2 (77) of Companies Act, 2013, as amended from time to time.
The current list is reproduced in Section 3 of this Annexure.
(e) The value of capital instruments to be transferred together with any capital
instruments already transferred by the transferor, as gift, to any person residing
outside India does not exceed the rupee equivalent of USD 50,000 during the
financial year.
(f)

Such other conditions as stipulated by Reserve Bank in public interest from time to
time.

(iii) Transfer of shares from NRI to non-resident.
5.2

In the following cases, approval of RBI is not required:
A.

Transfer of shares from a Non-Resident to Resident under the FDI scheme
where the pricing guidelines under FEMA, 1999 are not met provided that:
i. The original and resultant investment are in line with the extant FDI policy and
FEMA regulations in terms of sectoral caps, conditionalities (such as minimum
capitalization, etc.), reporting requirements, documentation, etc.;
ii. The pricing for the transaction is compliant with the specific/explicit, extant and
relevant SEBI regulations/guidelines (such as IPO, Book building, block deals,
delisting, exit, open offer/substantial acquisition/SEBI SAST, buy back); and
iii. Chartered Accountants Certificate to the effect that compliance with the relevant
SEBI regulations/guidelines as indicated above is attached to the form FC-TRS to
be filed with the AD bank.

B.

Transfer of shares from Resident to Non-Resident:

66

<!-- page 68 -->

i) where the transfer of shares requires the prior approval of the Government as
per the extant FDI policy provided that:
a) the requisite approval of the Government has been obtained; and
b) the transfer of shares adheres with the pricing guidelines and documentation
requirements as specified by the Reserve Bank of India from time to time.
ii) where the transfer of shares attract SEBI (SAST) Regulations subject to the
adherence with the pricing guidelines and documentation requirements as specified
by Reserve Bank of India from time to time.
iii) where the transfer of shares does not meet the pricing guidelines under the
FEMA, 1999 provided that:
a) The resultant FDI is in compliance with the extant FDI policy and FEMA regulations
in terms of sectoral caps, conditionalities (such as minimum capitalization, etc.),
reporting requirements, documentation etc.;
b) The pricing for the transaction is compliant with the specific/explicit, extant and
relevant SEBI regulations/guidelines (such as IPO, Book building, block deals,
delisting, exit, open offer/substantial acquisition/SEBI SAST); and
c) Chartered Accountants Certificate to the effect that compliance with the relevant
SEBI regulations/guidelines as indicated above is attached to the form FC-TRS to
be filed with the AD bank.
iv) where the investee company is in the financial sector provided that:
a) Any ‘fit and proper/due diligence’ requirements as regards the non-resident investor
as stipulated by the respective financial sector regulator, from time to time, have
been complied with; and
b) The FDI policy and FEMA regulations in terms of sectoral caps, conditionalities
(such as minimum capitalization, pricing, etc.), reporting requirements,
documentation etc., are complied with.
6.
(i)

Conversion of ECB/Lump sum Fee/Royalty etc. into Equity
Indian companies have been granted general permission for conversion of External
Commercial Borrowings (ECB) (excluding those deemed as ECB) in convertible foreign
currency into equity shares/fully compulsorily and mandatorily convertible preference
shares, subject to the following conditions and reporting requirements:
(a) The activity of the company is covered under the Automatic Route for FDI or
the company has obtained Government approval for foreign equity in the
company;
(b) The foreign equity after conversion of ECB into equity is within the sectoral cap,
if any;
(c) Pricing of shares is as per the provision of para 2 above;
(d) Compliance with the requirements prescribed under any other statute and
regulation in force; and

67

<!-- page 69 -->

(e) The conversion facility is available for ECBs availed under the Automatic or
Government Route and is applicable to ECBs, due for payment or not, as well
as secured/unsecured loans availed from non-resident collaborators.
(ii)

General permission is also available for issue of shares/preference shares against
lump sum technical know-how fee, royalty due for payment, subject to entry route,
sectoral cap and pricing guidelines (as per the provision of para 2 above)and
compliance with applicable tax laws. Further, issue of equity shares against any other
funds payable by the investee company, remittance of which does not require prior
permission of the Government of India or Reserve Bank of India under FEMA, 1999 or
any rules/ regulations framed or directions issued thereunder, or has been permitted by
the Reserve Bank under the Act or the rules and regulations framed or directions
issued thereunder is permitted, provided that:
(I) The equity shares shall be issued in accordance with the extant FDI guidelines on
sectoral caps, pricing guidelines etc. as amended by Reserve bank of India, from
time to time;
Explanation: Issue of shares/convertible debentures that require Government
approval in terms of paragraph 3 of Schedule 1 of FEMA 20 or import dues deemed
as ECB or trade credit or payable against import of second hand machinery shall
continue to be dealt in accordance with extant guidelines;
(II)The issue of equity shares under this provision shall be subject to tax laws as
applicable to the funds payable and the conversion to equity should be net of
applicable taxes.

(iii) A wholly owned subsidiary set up in India by a non-resident entity, operating in a sector
where 100 percent foreign investment is allowed in the automatic route and there are
no FDI linked conditionalities, may issue equity shares or preference shares or
convertible debentures or warrants to the said non-resident entity against preincorporation/ pre-operative expenses incurred by the said non-resident entity up to a
limit of five percent of its capital or USD 500,000 whichever is less, subject to the
conditions laid down below.
a. Within thirty days from the date of issue of equity shares or preference shares or
convertible debentures or warrants but not later than one year from the date of
incorporation or such time as Reserve Bank of India or Government of India permits,
the Indian company shall report the transaction in the Form FC-GPR to the Reserve
Bank.
b. The valuation of the equity shares or preference shares or convertible debentures or
warrants shall be subject to the provisions of Paragraph 5 of Schedule 1 of these
Regulations.
c. A certificate issued by the statutory auditor of the Indian company that the amount of
pre-incorporation/pre-operative expenses against which equity shares or preference
shares or convertible debentures or warrants have been issued has been utilized for
the purpose for which it was received should be submitted with the FC-GPR form.
Explanation: Pre-incorporation/pre-operative expenses shall include amounts
remitted to Investee Company’s account, to the investor’s account in India if it exists,

68

<!-- page 70 -->

to any consultant, attorney or to any other material/service provider for expenditure
relating to incorporation or necessary for commencement of operations.
(iv) Issue of equity shares under the FDI policy is allowed under the Government route for
the following:
(I) import of capital goods/ machinery/ equipment (excluding second-hand
machinery), subject to compliance with the following conditions:
(a)Any import of capital goods/machinery etc., made by a resident in India, has to
be in accordance with the Export/Import Policy issued by Government of
India/as defined by DGFT/FEMA provisions relating to imports.
(b)The application clearly indicating the beneficial ownership and identity of the
Importer Company as well as overseas entity.
(c) Applications complete in all respects, for conversions of import payables for
capital goods into FDI being made within 180 days from the date of shipment
of goods.
(II)
pre-operative/pre-incorporation expenses (including payments of rent etc.),
subject to compliance with the following conditions:
(a) Submission of FIRC for remittance of funds by the overseas promoters for
the expenditure incurred.
(b) Verification and certification of the pre-incorporation/pre-operative expenses
by the statutory auditor.
(c) Payments should be made by the foreign investor to the company directly
or through the bank account opened by the foreign investor as provided
under FEMA Regulations.
(d) The applications, complete in all respects, for capitalization being made
within the period of 180 days from the date of incorporation of the
company.
General conditions:
(i) All requests for conversion should be accompanied by a special resolution of the
company.
(ii) Government’s approval would be subject to pricing guidelines of RBI and
appropriate tax clearance.
SECTION 1
Terms and conditions for Transfer of Shares/Convertible Debentures, by way of Sale, from
a Person Resident in India to a Person Resident Outside India and from a Person Resident
Outside India to a Person Resident in India
1.1In order to address the concerns relating to pricing, documentation, payment/ receipt and
remittance in respect of the shares/convertible debentures of an Indian company, in all sectors,
transferred by way of sale, the parties involved in the transaction shall comply with the guidelines
set out below.
1.2Parties involved in the transaction are(a) seller (resident/non-resident), (b) buyer
(resident/non-resident), (c) duly authorized agent/s of the seller and/or buyer, (d) Authorised Dealer
bank (AD) branch and (e) Indian company, for recording the transfer of ownership in its books.
2. Pricing Guidelines
2.1 The under noted pricing guidelines are applicable to the following types of transactions:

69

<!-- page 71 -->

i.
Transfer of shares by way of sale under private arrangement by a person resident in India to a
person resident outside India.
ii. Transfer of shares by way of sale under private arrangement by a person resident outside India
to a person resident in India.
iii. Exit by non-resident investor on exercising option/right in shares or compulsorily & mandatorily
convertible preference shares or fully, compulsorily & mandatorily convertible debentures.
2.2 Transfer by Resident to Non-resident (i.e. to foreign national, NRI, FII, FPI and incorporated
non-resident entity other than erstwhile OCB) Price of shares transferred by way of sale by resident
to a non-resident where the shares of an Indian company are:
(a) listed on a recognized stock exchange in India ,shall not be less than the price at which the
preferential allotment of shares can be made under the SEBI guidelines , as applicable,
provided the same is determined for such duration as specified therein, preceding the relevant
date, which shall be the date of purchase or sale of shares,
(b) not listed on a recognized stock exchange in India, shall not be less than the fair value to be
determined by a SEBI registered Merchant Banker or a Chartered Accountant as per any
internationally accepted pricing methodology on arm’s length basis. The price per share arrived
at should be certified by a SEBI registered Merchant Banker or a Chartered Accountant.
2.3 Transfer by Non-resident(i.e. by incorporated non-resident entity, erstwhile OCB, foreign
national, NRI, FII, FPI)to Resident
Sale of shares by a non-resident to resident shall be in accordance with Regulation 10 B (2) of
Notification No. FEMA 20/2000-RB dated May 3, 2000 which shall not be more than the minimum
price at which the transfer of shares can be made from a resident to a non-resident as given at para
2.2 above.
2.4 After the lock-in period, as applicable above, and subject to FDI Policy provisions, if any, in this
regard, the non-resident investor exercising option/right in shares or convertible debentures issued
under FDI Scheme shall be eligible to exit without any assured return, as per pricing/valuation
guidelines issued by RBI from time to time.
3. Responsibilities / Obligations of the parties
All the parties involved in the transaction would have the responsibility to ensure that the relevant
regulations under FEMA are complied with and consequent on transfer of shares, the relevant
individual limit/sectoral caps/foreign equity participation ceilings as fixed by Government are not
breached. Settlement of transactions will be subject to payment of applicable taxes, if any.
4. Method of payment and remittance/credit of sale proceeds
4.1The sale consideration in respect of the shares purchased by a person resident outside India
shall be remitted to India through normal banking channels. In case the buyer is a FII,FPI, payment
should be made by debit to its Special Non-Resident Rupee Account. In case the buyer is a NRI,
the payment may be made by way of debit to his NRE/FCNR (B) accounts. However, if the shares
are acquired on non-repatriation basis by NRI, the consideration shall be remitted to India through
normal banking channel or paid out of funds held in NRE/FCNR (B)/NRO accounts.
4.2. The sale proceeds of shares (net of taxes) sold by a person resident outside India may be
remitted outside India. In case of FII/FPI, the sale proceeds may be credited to its special NonResident Rupee Account. In case of NRI, if the shares sold were held on repatriation basis, the sale

70

<!-- page 72 -->

proceeds (net of taxes) may be credited to his NRE /FCNR(B) accounts and if the shares sold were
held on non repatriation basis, the sale proceeds may be credited to his NRO account subject to
payment of taxes.
4.3 The sale proceeds of shares (net of taxes) sold by an OCB may be remitted outside India
directly if the shares were held on repatriation basis and if the shares sold were held on nonrepatriation basis, the sale proceeds may be credited to its NRO (Current) Account subject to
payment of taxes, except in the case of OCBs whose accounts have been blocked by Reserve
Bank.
5. Documentation
Besides obtaining a declaration in the enclosed Form FC-TRS (in quadruplicate), the AD branch
should arrange to obtain and keep on record the following documents:
5.1 For sale of shares by a person resident in India
i.
Consent Letter duly signed by the seller and buyer or their duly appointed agent indicating
the details of transfer i.e. number of shares to be transferred, the name of the investee
company whose shares are being transferred and the price at which shares are being
transferred. In case there is no formal Sale Agreement, letters exchanged to this effect may
be kept on record.
ii.
Where Consent Letter has been signed by their duly appointed agent, the Power of
Attorney Document executed by the seller/buyer authorizing the agent to purchase/sell
shares.
iii.
The shareholding pattern of the investee company after the acquisition of shares by a
person resident outside India showing equity participation of residents and non-residents
category-wise (i.e. NRIs/OCBs/foreign nationals/incorporated non-resident entities/FIIs,
FPIs) and its percentage of paid up capital obtained by the seller/buyer or their duly
appointed agent from the company, where the sectoral cap/limits have been prescribed.
iv.
Certificate indicating fair value of shares from a Chartered Accountant.
v.
Copy of Broker’s note if sale is made on Stock Exchange
vi.
Undertaking from the buyer to the effect that he is eligible to acquire shares/convertible
debentures under FDI policy and the existing sectoral limits and Pricing Guidelines have
been complied with.
vii.
Undertaking from the FII/sub account to the effect that the individual FII/ Sub account
ceiling as prescribed by SEBI has not been breached, till it gets registered as FPI.
5.2.
i.

ii.

iii.

For sale of shares by a person resident outside India
Consent Letter duly signed by the seller and buyer or their duly appointed agent indicating
the details of transfer i.e. number of shares to be transferred, the name of the investee
company whose shares are being transferred and the price at which shares are being
transferred.
Where the Consent Letter has been signed by their duly appointed agent the Power of
Attorney Document authorizing the agent to purchase/sell shares by the seller/buyer. In
case there is no formal Sale Agreement, letters exchanged to this effect may be kept on
record.
If the sellers are NRIs/OCBs, the copies of RBI approvals evidencing the shares held by
them on repatriation/non-repatriation basis. The sale proceeds shall be credited NRE/NRO
account, as applicable.

71

<!-- page 73 -->

iv.
v.
vi.

Certificate indicating fair value of shares from a Chartered Accountant.
No Objection / Tax Clearance Certificate from Income Tax authority/Chartered Account.
Undertaking from the buyer to the effect that the Pricing Guidelines have been adhered to.

6. Reporting requirements
6.1 Reporting of transfer of shares between residents and non-residents and vice versa is to be
done in Form FC-TRS. The Form FC-TRS should be submitted to the AD Category-I bank, within 60
days from the date of receipt of the amount of consideration. The onus of submission of the Form
FC-TRS within the given timeframe would be on the transferor / transferee, resident in India. The
AD Category-I bank, would forward the same to its link office. The link office would consolidate the
Forms and submit a monthly report to the Reserve Bank5.
For the purpose the Authorized Dealers may designate branches to specifically handle such
transactions. These branches could be staffed with adequately trained staff for this purpose to
ensure that the transactions are put through smoothly. The ADs may also designate a nodal office
to coordinate the work at these branches and also ensure the reporting of these transactions to the
Reserve Bank.
6.2When the transfer is on private arrangement basis, on settlement of the transactions, the
transferee/his duly appointed agent should approach the investee company to record the transfer in
their books along with the certificate in the Form FC-TRS from the AD branch that the remittances
have been received by the transferor/payment has been made by the transferee. On receipt of the
certificate from the AD, the company may record the transfer in its books.
6.3The actual inflows and outflows on account of such transfer of shares shall be reported by the
AD branch in the R-returns in the normal course.
6.4 In addition the AD branch should submit two copies of the Form FC-TRS received from their
constituents/customers together with the statement of inflows/outflows on account of remittances
received/made in connection with transfer of shares, by way of sale, to IBD/FED/or the nodal office
designated for the purpose by the bank in the enclosed proforma (which is to be prepared in MSExcel format). The IBD/FED or the nodal office of the bank will in turn submit a consolidated
monthly statement in respect of all the transactions reported by their branches together with copies
of the FC-TRS Forms received from their branches to Foreign Exchange Department, Reserve
Bank, Foreign Investment Division, Central Office, Mumbai in soft copy (in MS- Excel) by e-mail to
fdidata@rbi.org.in
6.5 Shares purchased / sold by FIIs/FPIs under private arrangement will be by debit /credit to their
Special Non-Resident Rupee Account. Therefore, the transaction should also be reported in Form
LEC by the designated bank of the FII/FPI concerned.
6.6 Shares/convertible debentures of Indian companies purchased under Portfolio Investment
Scheme by NRIs, OCBs cannot be transferred, by way of sale under private arrangement.

5

To the Chief General Manager-in-Charge, Reserve Bank of India, Foreign Exchange Department, Foreign
Investment Division, Central Office, Mumbai

72

<!-- page 74 -->

6.7 On receipt of statements from the AD, the Reserve Bank may call for such additional details or
give such directions as required from the transferor/transferee or their agents, if need be.
SECTION 2
Documents to be submitted by a person resident in India for transfer of shares to a person
resident outside India by way of gift
i. Name and address of the transferor (donor) and the transferee (donee).
ii. Relationship between the transferor and the transferee.
iii. Reasons for making the gift.
iv. In case of Government dated securities and treasury bills and bonds, a certificate issued by a
Chartered Accountant on the market value of such security.
v. In case of units of domestic mutual funds and units of Money Market Mutual Funds, a
certificate from the issuer on the Net Asset Value of such security.
vi. In case of shares and convertible debentures, a certificate from a Chartered Accountant on
the value of such securities according to the guidelines issued by Securities & Exchange
Board of India or as per any internationally accepted pricing methodology on arm’s length
basis for listed companies and unlisted companies, respectively.
vii. Certificate from the concerned Indian company certifying that the proposed transfer of
shares/convertible debentures by way of gift from resident to the non-resident shall not
breach the applicable sectoral cap/ FDI limit in the company and that the proposed number of
shares/convertible debentures to be held by the non-resident transferee shall not exceed 5
per cent of the paid up capital of the company.
viii. An undertaking from the resident transferor that the value of security to be transferred
together with any security already transferred by the transferor, as gift, to any person residing
outside India does not exceed the rupee equivalent of USD 50,000during a financial year*.
*RBI’s A.P. (DIR Series) Circular No. 14 Dated 15.09.2011
ix. A declaration from the donee accepting partly paid shares or warrants that donee is aware of
the liability as regards calls in arrear and consequences thereof.
SECTION 3
Definition of "relative" as given in Section 2 (77) of Companies Act, 2013
“Relative”, with reference to any person, means any one who is related to another, if(a) they are members of a Hindu undivided family ;
(b) they are husband and wife ; or
(c) one person is related to the other in such manner as may be prescribed.

73

<!-- page 75 -->

Annexure-4
Specific Conditions in Certain Cases
1.

Issue of Rights/Bonus Shares
FEMA provisions allow Indian companies to freely issue Rights/Bonus shares to existing
non-resident shareholders, subject to adherence to sectoral cap, if any. However, such
issue of bonus/rights shares has to be in accordance with other laws/statutes like the
Companies Act, as applicable, SEBI (Issue of Capital and Disclosure Requirements)
Regulations, 2009 (in case of listed companies), etc. The offer on right basis to the
persons resident outside India shall be:
(a)
in the case of shares of a company listed on a recognized stock exchange in
India, at a price as determined by the company;
(b)
in the case of shares of a company not listed on a recognized stock exchange
in India, at a price which is not less than the price at which the offer on right
basis is made to resident shareholders.

2.

Prior permission of RBI for Rights issue to erstwhile OCBs
OCBs have been de-recognised as a class of investors from September 16, 2003.
Therefore companies desiring to issue rights share to such erstwhile OCBs will have to
take specific prior permission from RBI. As such, entitlement of rights share is not
automatically available to erstwhile OCBs. However bonus shares can be issued to
erstwhile OCBs without the approval of RBI.

3.

Additional allocation of rights share by residents to non-residents
Existing non-resident shareholders are allowed to apply for issue of additional shares/fully,
compulsorily and mandatorily convertible debentures/fully, compulsorily and mandatorily
convertible preference shares over and above their rights share entitlements. The
investee company can allot the additional rights share out of unsubscribed portion, subject
to the condition that the overall issue of shares to non-residents in the total paid-up capital
of the company does not exceed the sectoral cap.

4.

Acquisition of shares under Scheme of Merger/Demerger/Amalgamation
Mergers/demergers/ amalgamations of companies in India are usually governed by an
order issued by a competent Court on the basis of the Scheme submitted by the
companies undergoing merger/demerger/amalgamation. Once the scheme of merger or
demerger or amalgamation of two or more Indian companies has been approved by a
Court in India, the transferee company or new company is allowed to issue shares to the
shareholders of the transferor company resident outside India, subject to the conditions
that:
(i) the percentage of shareholding of persons resident outside India in the transferee or
new company does not exceed the sectoral cap, and
(ii) the transferor company or the transferee or the new company is not engaged in
activities which are prohibited under the FDI policy.
Note: Government approval would not be required in case of mergers and acquisitions
taking place in sectors under automatic route.

74

<!-- page 76 -->

4.1 Issue of Non convertible/redeemable bonus preference shares or debentures
Indian companies are allowed to issue non-convertible/redeemable preference shares or
debentures to non-resident shareholders, including the depositories that act as trustees
for the ADR/GDR holders, by way of distribution as bonus from its general reserves under
a Scheme of Arrangement approved by a Court in India under the provisions of the
Companies Act, as applicable, subject to no-objection from the Income Tax Authorities.
5.

Issue of Employees Stock Option Scheme (ESOPs) / Sweat Equity
An Indian company may issue “employees’ stock option” and/or “sweat equity shares” to
its employees/directors or employees/directors of its holding company or joint venture or
wholly owned overseas subsidiary/subsidiaries who are resident outside India, provided
that :
a.

b.

c.

d.

e.

The scheme has been drawn either in terms of regulations issued under the
Securities Exchange Board of India Act, 1992 or the Companies (Share Capital
and Debentures) Rules, 2014 notified by the Central Government under the
Companies Act 2013, as the case may be.
The “employee’s stock option”/ “sweat equity shares” issued to non-resident
employees/directors under the applicable rules/regulations are in compliance with
the sectoral cap applicable to the said company.
Issue of “employee’s stock option”/ “sweat equity shares” by a company where
foreign investment is under the approval route shall require prior approval of
Government of India.
Issue of “employee’s stock option”/ “sweat equity shares” under the applicable
rules/regulations to an employee/director who is a citizen of Bangladesh/Pakistan
shall require prior approval of the Government of India.
The issuing company shall furnish to the Regional Office concerned of the
Reserve Bank of India under whose jurisdiction the registered office of the
company operates, within 30 days from the date of issue of employees’ stock
option or sweat equity shares, a return as per the Form-ESOP.

6. Share Swap
In cases of investment by way of swap of shares, irrespective of the amount, valuation
of the shares will have to be made by a Merchant Banker registered with SEBI or an
Investment Banker outside India registered with the appropriate regulatory authority in
the host country. Approval of the Government will also be a prerequisite for investment
by swap of shares for sector under Government approval route. No approval of the
Government is required for investment in automatic route sectors by way of swap of
shares.
7. Pledge of Shares
(A)
A person being a promoter of a company registered in India (borrowing company),
which has raised external commercial borrowings, may pledge the shares of the
borrowing company or that of its associate resident companies for the purpose of
securing the ECB raised by the borrowing company, provided that a no objection for
the same is obtained from a bank which is an authorised dealer. The authorized dealer,

75

<!-- page 77 -->

shall issue the no objection for such a pledge after having satisfied itself that the
external commercial borrowing is in line with the extant FEMA regulations for ECBs and
that:
i)
ii)
iii)

(B)

(C)

the loan agreement has been signed by both the lender and the borrower,
there exists a security clause in the Loan Agreement requiring the borrower to
create charge on financial securities, and
the borrower has obtained Loan Registration Number (LRN) from the Reserve
Bank:

and the said pledge would be subject to the following conditions:
a) the period of such pledge shall be co-terminus with the maturity of the
underlying ECB;
b) in case of invocation of pledge, transfer shall be in accordance with the
extant FDI Policy and directions issued by the Reserve Bank;
c) the Statutory Auditor has certified that the borrowing company will
utilized/has utilized the proceeds of the ECB for the permitted end use/s
only.
Non-residents holding shares of an Indian company, can pledge these shares in favour
of the AD bank in India to secure credit facilities being extended to the resident
investee company for bonafide business purpose, subject to the following conditions:
(i) in case of invocation of pledge, transfer of shares should be in accordance with the
FDI policy in vogue at the time of creation of pledge;
(ii) submission of a declaration/ annual certificate from the statutory auditor of the
investee company that the loan proceeds will be / have been utilized for the
declared purpose;
(iii) the Indian company has to follow the relevant SEBI disclosure norms; and
(iv) pledge of shares in favour of the lender (bank) would be subject to Section 19 of
the Banking Regulation Act, 1949.
Non-residents holding shares of an Indian company, can pledge these shares in favour
of an overseas bank to secure the credit facilities being extended to the non-resident
investor/non-resident promoter of the Indian company or its overseas group company,
subject to the following:
(i) loan is availed of only from an overseas bank;
(ii) loan is utilized for genuine business purposes overseas and not for any
investments either directly or indirectly in India;
(iii) overseas investment should not result in any capital inflow into India;
(iv) in case of invocation of pledge, transfer should be in accordance with the FDI
policy in vogue at the time of creation of pledge; and
(v) submission of a declaration/annual certificate from a Chartered Accountant/
Certified Public Accountant of the non-resident borrower that the loan proceeds
will be / have been utilized for the declared purpose.

76

<!-- page 78 -->

Annexure-5
Total Foreign Investment i.e. Direct and Indirect Foreign Investment in eligible Indian
entities
1.

Investment in an eligible Indian entity can be made both by non-resident as well as
resident Indian entities. Any non-resident investment in an Indian company is direct
foreign investment. Investment by resident Indian entities could again comprise of both
resident and non-resident investment. Thus, such an Indian company would have
indirect foreign investment if the Indian investing company has foreign investment in it.
The indirect investment can also be a cascading investment i.e. through multi-layered
structure.

1.1

For the purpose of computation of indirect foreign investment in an Indian company,
foreign investment in an Indian company shall include all types of foreign investments
i.e. FDI; investment by FIIs (holding as on March 31), FPIs (holding as on March 31);
NRIs; ADRs; GDRs; Foreign Currency Convertible Debentures (FCCBs); Investment
Vehicles fully, compulsorily and mandatorily convertible preference shares and fully,
compulsorily and mandatorily convertible Debentures or units of an Investment Vehicle,
regardless of whether the said investments have been made under Schedule 1, 2, 2A,
3, 6, 9, 10 and 11 of FEMA (Transfer or Issue of Security by Persons Resident Outside
India) Regulations, 2000.

1.2

Guidelines for calculation of total foreign investment i.e. direct and indirect
foreign investment
(i) Counting of direct foreign investment
All investment directly by a non-resident entity into the Indian company/ LLP would
be counted towards foreign investment.
(ii) Counting of indirect foreign investment
(a) The foreign investment through the investing Indian company/LLP would not
be considered for calculation of the indirect foreign investment in case of
Indian companies/LLPs which are ‘owned and controlled’ by resident Indian
citizens and/or Indian Companies/LLPs which are owned and controlled by
resident Indian citizens .
(aa) Downstream investment by an Investment Vehicle shall be regarded as foreign
investment if either the Sponsor or the Manager or the Investment Manager is
not Indian ‘owned and controlled’ as defined in Regulation 14 of the principal
Regulations as defined in RBI Notification No.362/2015-RB dated February 15,
2016.
Provided that for sponsors or managers or investment managers organized in
a form other than companies or LLPs, SEBI shall determine whether the
sponsor or manager or investment manager is foreign owned and controlled.
(b) For cases where condition (a) above is not satisfied or if the investing
company is owned or controlled by ‘non-resident entities’, the entire
investment by the investing company/LLP into the subject Indian Company
would be considered as indirect foreign investment, provided that, as an

77

<!-- page 79 -->

exception, the indirect foreign investment in only the 100% owned subsidiaries
of operating-cum-investing/investing companies, will be limited to the foreign
investment in the operating-cum-investing/ investing company. This exception
is made since the downstream investment of a 100% owned subsidiary of the
holding company is akin to investment made by the holding company and the
downstream investment should be a mirror image of the holding company.
This exception, however, is strictly for those cases where the entire capital of
the downstream subsidiary is owned by the holding company.
Illustration
To illustrate, if the indirect foreign investment is being calculated for Company X which has
investment through an investing Company Y having foreign investment, the following would be
the method of calculation:
(A)
where Company Y has foreign investment less than 50%- Company X would not be
taken as having any indirect foreign investment through Company Y.
(B)
where Company Y has foreign investment of say 75% and:
(I) invests 26% in Company X, the entire 26% investment by Company Y would be
treated as indirect foreign investment in Company X;
(II) invests 80% in Company X, the indirect foreign investment in Company X would
be taken as 80%;
(III) where Company X is a wholly owned subsidiary of Company Y (i.e. Company Y
owns 100% shares of Company X), then only 75% would be treated as indirect
foreign equity and the balance 25% would be treated as resident held equity. The
indirect foreign equity in Company X would be computed in the ratio of 75:25 in
the total investment of Company Y in Company X.
(iii) The total foreign investment would be the sum total of direct and indirect foreign
investment.
(iv) The above methodology of calculation would apply at every stage of investment in
Indian companies and thus to each and every Indian company.
(v) Additional conditions
(a) The full details about the foreign investment including ownership details etc. in
Indian company(s) and information about the control of the company(s) would
be furnished by the Company(s) to the Government of India at the time of
seeking approval.
(b) In any sector/activity, where Government approval is required for foreign
investment and in cases where there are any inter-se agreements
between/amongst shareholders which have an effect on the appointment of the
Board of Directors or on the exercise of voting rights or of creating voting rights
disproportionate to shareholding or any incidental matter thereof, such
agreements will have to be informed to the approving authority. The approving
authority will consider such inter-se agreements for determining ownership and
control when considering the case for approval of foreign investment.
(c) In all sectors attracting sectoral caps, the balance equity i.e. beyond the
sectoral foreign investment cap, would specifically be beneficially owned
by/held with/in the hands of resident Indian citizens and Indian companies,
owned and controlled by resident Indian citizens.

78

<!-- page 80 -->

(d) In the I& B sector where the sectoral cap is up to 49%, the company would
need to be ‘owned and controlled’ by resident Indian citizens and Indian
companies, which are owned and controlled by resident Indian citizens.
(A)For this purpose, the equity held by the largest Indian shareholder would have to
be at least 51% of the total equity, excluding the equity held by Public Sector
Banks and Public Financial Institutions, as defined in Section 4A of the
Companies Act, 1956 or Section 2 (72) of the Companies Act, 2013, as the
case may be. The term ‘largest Indian shareholder’, used in this clause, will
include any or a combination of the following:
(I) In the case of an individual shareholder,
(aa)The individual shareholder,
(bb) A relative of the shareholder within the meaning of Section 2 (77) of
Companies Act, 2013.
(cc) A company/group of companies in which the individual
shareholder/HUF to which he belongs has management and controlling
interest.
(II)In the case of an Indian company,
(aa)The Indian company
(bb)A group of Indian companies under the same management and
ownership control.
(B)For the purpose of this Clause, “Indian company” shall be a company which must
have a resident Indian or a relative as defined under Section 2 (77) of Companies
Act, 2013/ HUF, either singly or in combination holding at least 51% of the
shares.
(C)Provided that, in case of a combination of all or any of the entities mentioned in
Sub-Clauses (I) and (II) of clause 1.2(v)(d)(A) above, each of the parties shall
have entered into a legally binding agreement to act as a single unit in managing
the matters of the applicant company.
(e) If a declaration is made by persons as per section 187C of the Companies
Act,1956 or section 89 of the Companies Act, 2013, as the case may be about
a beneficial interest being held by a non-resident entity, then even though the
investment may be made by a resident Indian citizen, the same shall be
counted as foreign investment.
1.3

The above mentioned policy and methodology would be applicable for determining the
total foreign investment in all sectors, except in sectors where it is specified in a statute
or rule there under. The above methodology of determining direct and indirect foreign
investment therefore does not apply to the Insurance Sector which will continue to be
governed by the relevant Regulation. Similarly, above methodology will also not apply
to downstream investments by an Investment Vehicle. Relevant conditions of
downstream investment by Investment Vehicles are as under:
(i) Downstream investment by an Investment Vehicle shall be regarded as foreign
investment if either the Sponsor or the Manager or the Investment Manager is not Indian
‘owned and controlled’ as defined in Regulation 14 of the principal Regulations as
defined in RBI Notification No. 362/2015-RB dated February 15, 2016.

79
