---
doc_id: "9fbe2a2af6d4ff52"
source_url: "https://www.dot.gov.in/static/uploads/2026/02/0bb052eb6aaac0799b73fddec2fdadbd.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Appointment of Shri Dharmesh Makwana, ITS, Staff No. 21075, as Joint Advisor, TRAI HQ on deputation basis - reg."
date: "2025-09-23"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "59bc71a59c8d4803"
---

<!-- page 1 -->

391-04/2025-STG-Ill-Part(3) 1/3317560/2025,
No. 391-04/2025-STG-III (Pt.3)
Government of India
Ministry of Communications
Department of Telecommunications
Room No. 419, Sanchar Bhawan
20 Ashoka Road, New Delhi 110001.
Dated: 22.09.2025
Office Memorandum
Subject: Appointment of Shri Dharmesh Makwana, ITS (Staff No. 21075) as
Joint Advisor, TRAI HQ on deputation basis - reg.

The undersigned is directed to refer to TRAI letters No. 1-04/2025-A&P
dated 19.08.2025 on the subject mentioned above and to convey the approval of
the Competent Authority for appointment of Shri Dharmesh Makwana, ITS (Staff
No. 21075), presently working as Director (T) DoT HQ., New Delhi, as Joint Advisor
in TRAI HQ initially for a period of three years from the date of assumption of
charge for the post or until further orders whichever earlier.

2. The terms and conditions as laid down in the DoP&T OM No. 2/6/2016-Estt.
(Pay-ll) dated 17.02.2016 and OM No. 14017/30/2006-Estt.(RR) dated 29.11.2006
as mentioned from time to time are applicable in the case of deputation of
aforesaid officer to the post of Joint Advisor in TRA] HQ. Anything not covered in
these OMs will be decided as per the policy of borrowing organization.
3. The officer is hereby relived w.e.f. 25.09.2025 (A/N) with instructions to take
up his new assignment as Joint Advisor in TRAI HQ, New Delhi
Digitally signed by
Sunil Kumar
Date: 22-09-2025
(ScrMiFAiA Br)
Under Secretary to the Govt. of India
Tele No. 23036226
To

Shri Dharmesh Makwana, ITS

Director (T) DoT HQ.,

New Delhi
Copy to:

1. PS to Hon'ble MoC/ PS to Hon'ble MoS(C)

2. PS to Secretary (T)/Member(S)

3. The Joint Secretary (T) DoT HQ., New Delhi

4. Shri Vinay Kumar Goel, Dy. Advisor, TRAI, New Delhi.

5. Officers concerned.

6. AO, STG-I/ADG(APAR)/SO (Pay Bill).

7. PA to US(STG-III) for uploading on website.

8. Order Bundle/ Spare Copy.
