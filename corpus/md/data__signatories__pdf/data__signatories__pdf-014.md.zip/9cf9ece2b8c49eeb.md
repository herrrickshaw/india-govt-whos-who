---
doc_id: "9cf9ece2b8c49eeb"
source_url: "https://mnre.gov.in/static/uploads/2025/08/d2963172ac671ead461566e9d11a6ca4.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Corrigendum to Advertisement No. 348-21/1/2025-ADMIN – Online Applications Invited for Visiting Fellows at Sardar Swaran Singh National Institute of Bio-Energy, Kapurthala"
date: "2025-02-28"
pages: 1
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1c42e78bb34a04b5"
---

<!-- page 1 -->

348-21/1/2025-ADMIN 145351/2025,
' सरदार Fact fe useda sta ऊर्जी संस्थान
(नवीन और नवीकरणीय ऊर्जा मंत्रालय, भारत सरकार का एक स्वायत्त संस्थान) G2 &
s) 12 कि.मी. स्टोन, जालंधर-कपूरथला रोड, वडाला कलां, कपूरथला (पंजाब) 144603 Sega
t& |r: 01822-507406, $41: sss.nibe@nibe.res.in , A#atse: https://nibe.res.in —
[ & Sardar Swaran Singh National Institute of Bio-Energy 77s
{An Autonomous Institute of Ministry of New and Renewable Energy, Government of India) भा
12 K.M. Stone, Jalandhar-Kapurthala Road, Wadala Kelan, Kapurthala (Punjab) 144603 wees
Phone: 011822-507406, email: sss nibe@nibe,res.in, Website: hitps:/ /nibe.res.in.
Ref, No.: 348-21/1/2025-ADMIN Dated: 28.02.2025
qeftraa_/ Corrigendum
सरदार स्वर्ण सिंह राष्ट्रीय जैव ऊर्जा संस्थान, कपूरथला में विजिटिंग फेलो के दो (02) पर्दों को भरने
के लिए ऑनल्राइन आवेदन आमंत्रित करने हेतु विज्ञापन संख्या 348-21/1/2025-800भाध के क्रम में,
आवेदक अपना भरा हुआ आवेदन पत्र ईमेल पते: 555.11926॥॥09९,125५॥ पर या लिफाफे पर शीर्षक
“विजिटिंग फेलो के पद के लिए आवेदन” का उल्लेख करते हुए निम्नलिखित पते पर भेज सकते हैं।
यह सक्षम प्राधिकारी के अनुमोदन से जारी किया जाता है।
In continuation to the advertisement No. 348-21/1/2025-ADMIN for inviting online
applications for filling up two (02) posts of Visiting Fellows at Sardar Swaran Singh National
Institute of Bio-Energy, Kapurthala, the applicants may send their filled application form, at
email address: sss,nibe@nibe.res.in or at following address mentioning title on envelop as
“Application for the post of Visiting Fellow”:
Director General
Sardar Swaran Singh National Institute of Bio-Energy,
12 K.M. Stone, Jalandhar — Kapurthala Road,
Wadala Kalan, Kapurthala (Pb.) — 144603.
This is issued with the approval of the Competent Authority.
Reet Cine
(Dr. Rawel Singh)
Admin (HR)
cc:
1. PA to DG, NIBE, Kapurthala
2. IT Section: for displaying over the Institute's website
