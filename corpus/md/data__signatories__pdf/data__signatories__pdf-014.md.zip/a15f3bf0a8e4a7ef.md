---
doc_id: "a15f3bf0a8e4a7ef"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/04/6e84856df143c61ac67b4c281e78d6b7.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction Order dt 09.02.2026 CCIIAC, IDS 2017 JKDFC 2025-26 Rs 10181550 Only"
date: "2026-04-21"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "70e88c0758bbef5d"
---

<!-- page 1 -->

No. 1(14)/2022-SSS (E-173373)
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade
(Special Scheme Section)
Udyog Bhawan, New Delhi
Dated: 09" February, 2026
To
The Accounts Officer,
Pay & Accounts Office,
Department for Promotion of Industry & Internal Trade,
Udyog Bhawan,
New Delhi.
Sub: Release of an amount of Rs. 1,01,81,550/- (Rs. One Crore One Lakh Eighty One
Thousand Five Hundred Fifty Only) as Central Capital Investment Incentive for access
to credit (CCIIAC) Subsidy during the year, 2025-26 in favour of JKDFC.
Sir,
| am directed to convey sanction of the President for release of an amount of Rs.
1,01,81,550/- (Rs. One Crore One Lakh Eighty One Thousand Five Hundred Fifty Only)
for payment of Central Capital Investment Incentive for access to credit (CCIIAC) under
Industrial Development Scheme (IDS) 2017 for the financial year 2025-26 in respect of 01
beneficiary unit of UT of J&K (as per list enclosed at Annexure), on the basis of
recommendations of the State Level Committee concerned and as per existing terms and
conditions of the scheme.
2m As per the Notification No.2(2)/2018-SPS dated 23rd April,2018, JKDFC has been
notified as the nodal agency for disbursal of central incentives in the UT of Jammu &
Kashmir and UT of Ladakh under IDS 2017.
3. The sanctioned amount may be released in favour of The Jammu & Kashmir
Development Finance Corporation Ltd. (JKDFC) to their Bank Account A/c No.
33121405575, State Bank of India, Branch Railway Station, Jammu RTGS/MICR
No.180002006 IFSC Code SBIN0006894.
4. No Utilization Certificate (UC) is pending at level of JKDFC under the said
component of the Scheme. The due date for submission of UC in respect of this release is
within twelve months of the closure of the financial year.
5. This the Third release for Jammu & Kashmir during the current year as CCIIAC under
Industrial Development Scheme (IDS) 2017. The total release under this object Head,
including the present sanction would be of Rs. 4,91,00,000/- during the current financial year
2025-26 as against the Budget provision of Rs. 4.91 crore in this object head in RE-2025-26.
6. The sanction is noted at SI. No. 08 in the expenditure control register for the FY 2025-
26.
ie The expenditure is debit to the following Head of Account: -
2885- Other Outlay on Industries & Minerals (Major Head)
02- Development of Backward Areas (Sub Major Head) jut ~
02.101- Subsidies (Minor Head) 10/५0/४८४५
डाटिजिक दत्त /281115115816 puTT
ee gene let Under Seeretsry 31
afore qe gar Haier /Ministty OF SO
उद्योग संबर्धन आए लि Sot, ot Inst
वाणिज्य #उद्योग भवन, गई (1
Vanijya/Udyog Bhawens NS

<!-- page 2 -->

17.01 - Industrial Development Scheme (IDS) 2017 for Jammu
& Kashmir and Ladakh.
17.01.33 Subsidies
Under Demand No.11 for the year, 2025-26.
8. Release of the above mentioned amount to JKDFC is subject to the following terms
and conditions:
i.

i.  JKDFC will maintain a separate account of the funds released by this
Department towards “Central Capital Investment Incentive for access to credit
(CCIIAC) under Industrial Development Scheme (IDS) 2017” for disbursal of
subsidy to the beneficiary units as per details enclosed.

ii. | JKDFC shall verify each & every claim before disbursement and shall
disburse the incentive to the eligible units immediately on receipt funds from
DPIIT.

iii. | The expenditure incurred shall be open to inspection by the sanctioning
authority/CAG/Internal Audit Party of the Chief Controller of Account, Ministry
of Commerce & Industry, Department for Promotion of Industry & Internal
Trade.

iv. After disbursement of incentive for the purpose for which it has been
sanctioned, JKDFC, shall submit to the Department for Promotion of Industry
& Internal Trade, New Delhi the Utilization certificate within twelve months of
the closure of the financial year as per GFR and no further funds will be
released unless the entire amount previously released is fully utilized and
utilization certificates are furnished. The Utilization Certificate will be signed
by the General Manager, JKDFC.

v. A quarterly statement of the subsidies disbursed indicating also the names of
the beneficiaries, the amount of subsidy released to each unit, the date of
their application, the date of approval of the SLC, the date of disbursal of
subsidy etc. shall be furnished by JKDFC to this Department by the 10" day
of the month following the end of each quarter.

vi. | JKDFC would devise a suitable mechanism to ensure adequate transparency
and fairness in the disbursal of subsidy. JKDFC shall furnish an undertaking
that they have been following the provision of Rule-4 (I)(a) and (b) of RTI Act,
2005.

vii. | JKDFC would furnish a performance-cum-achievement report at the end of
each financial year highlighting the number of units set up in the UT,
investment made and the employment generated etc., and the quantitative
vis-a-vis qualitative outcome achieved out of Central Capital Investment
Incentive for access to credit (CCIIAC) under IDS 2017 Scheme including
suggestions/policy reform initiatives for further refinement of the Scheme.

viii. | JKDFC to ensure that amount is released to individual unit(s) only after
verifying that these units have not been paid earlier.

ix. | JKDFC to ensure that payment to beneficiaries’ units should be made through
PFMS directly to their account.

9. Abhishek Dutt, Under Secretary will act as DDO for purpose of this sanction.
10. This issues with the concurrence of SS&FA vide Note No. 399 dated 06.02.2026 of
File No.1(14)/2022-SSS(E-173373).
(60७21९३/५०/३/ DUTT
gmat wWaad/Under Seeretary
aurea ad Seer ia Mistry OF C&L
उद्योग संबर्धन और आंतरिफ ब्यापा- 1 7D PUT
भरत सरकार/ठ0४1 ७०४
बाणिज्य /उद्योग भवन, * 1
Vanijya/Udyog Bhawen. i+ vit

<!-- page 3 -->

Yours faithfully,
Roi dcr
<; लोक ex ABHISHEK F
(Abhishek Dutt riot
Under Secretary. 16167 960 8100९ व
E-mail dutt.abhishek@niceity 24)...
BAAS LY, 1S .
Vanijya/Udyog Bhawan, Now Dos
Copy to:-
1. The Principal Director of Audit, Economic and Services Ministries, A.G.C.R. Building,
Indraprastha Estate, New Delhi.
2. Director of Industries (Kashmir), Directorate of Industries, Govt. of Jammu &
Kashmir.
3. Finance-ll Section, Integrated Finance Wing, Department for Promotion of Industry &
Internal Trade.
4. CCA, DPIIT-with the request to audit 10% cases after disbursement by JKDFC.
5. The Managing Director, JKDFC
6. Budget & Accounts Section, DPIIT
7. Guard File.

<!-- page 4 -->

Annexure
No. 1(14)/2022-SSS (E-173373)
01 claims of Central Capital Investment Incentive for access to credit (CCIIAC)
IDS registrationIDOCP {Claim [Amount |Amount Final
INo. and date received japproved |recommendedijamount
ion Portal|by SLC [by IPAI audit japproved by
(Rs. In Cr)iteam (Rs. In |DPIIT (Rs. In
Cr) Cr)
'2024/:
4 Mis IDS/JK/; ‘350
Grand |dated 24-12- 01-12- |08-04-
Mumtazi2024 2020 2025 _—‘[1,01,81,816]1,01,88,816 —_{1,01,81,550*
Total
1,01,88,816/1,01,88,816 1,01,81,550
“For M/s Grand Mumtaz, the amount released in this Sanction is Rs 1,01,81,550/- as against
the total approved amount of Rs. 1,01,88,816/-. The remaining amount for the unit will be
sanctioned in the next Release under CCIIAC after availability of funds under the Object
Head.
अभिषेक ST/ABHISHE!S ¢
'अयर राचिब/एकतल Sects
याणिज्य एवं उद्योग मंबालय शा वा 1
Se eh ता
बाणिज्य/उद्योग भवन, न i
Vanijya/Udyog Bhawan, hive (thi
