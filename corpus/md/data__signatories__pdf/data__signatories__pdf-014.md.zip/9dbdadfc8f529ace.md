---
doc_id: "9dbdadfc8f529ace"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/3b980f8df02f4ed265c17f5c6186f08e.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to UL(AS) License Agreement in respect of definition of Networth."
date: "2014-01-08"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c9cb87d252f4e9e2"
---

<!-- page 1 -->

Government oflndia
Department of Telecommunications
AS-I Cell
No.20-405/2013-AS.I

Dated the 08-Jan, 2014

To,
All UL(AS) Licensees
Subject: Amendment to UL(AS) License Agreement in respect of definition ofNetworth.
In exercise of the powers conferred in pursuance of Condition 5 of the UL(AS)
Agreement the LICENSOR hereby amends following definition of Net worth in the UL(AS)
agreement.
S.No.

Existin2 clause

I.

1.6 (i)

" .....
The networth shall mean as the sum total in
Indian Rupees of paid up equity capital and
free reserves & surplus net of accumulated
losses. The networth ofpromoters shall not be
counted for determining the networth of the
company.

Amended clause
1.6 (i)

" ......

Net worth shall be as defined in the Companies Act
2013 and as amended from time to time.The
networth of promoters shall not be counted for
determining the networth of the company.

.....,,

....,,

2

"NETWORTH" shall mean the sum 44. Net worth shall be as defined in the Companies
44.
total, in Indian rupees, of paid up equity Act 2013 and as amended from time to time.
capital and free reserves and surplus net of
accumulated losses converted at the prevalent
conversion rate indicated by the Reserve Bank
ofIndia on the date ofthe application.

2.
All other terms and conditions of the UL(AS) agreement including amendments and
instructions issued from time to time shall remain unchanged.
3.

Please acknowledge receipt.

al~
...---s I 1\1•1

(R.K.SONI)
Director (AS.I)
Ph.N o.23036284.
Copy to:
1. Administrator USOF/Wireless Advisor/Sr. DDG(TEC)
2. Sr DDG(WPF)/Sr DDG(Security-Term)/JS(T)/ DDG(CS)/DDG(DS)/ DDG(LF-1)/
DDG(LF-Il)/DDG (AC)
3. Secretary TRAI
4. Director (IT) may kindly arrange to upload this letter on the website ofDoT.
