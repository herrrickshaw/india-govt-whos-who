---
doc_id: "a0eadcefa2f08906"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/5d4375e16860ae6028fa04af62dd1648.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Online Lifecycle management and submission of reports through Saral Sanchar"
date: "2022-08-30"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9fd2c3e9de0ca1bb"
---

<!-- page 1 -->

DS-28/1/2020-DS-III
I/3057477/2022

File No: DS-11/28/1/2020-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20-Ashoka Road, New Delhi-110001
(DS Cell)

New Delhi, dated the 30-08-2022
OFFICE MEMORANDUM

Subject:

Online Lifecycle management and submission of reports through Saral

Sanchar
Saral Sanchar portal enables application for new License / authorization in online
mode. Phase-2 of Saral sanchar is ready and will allow applicants / licensees to carry out
various activities involved in lifecycle of the License in online mode. The upgraded system
will also allow you to send online reports and compliances. In this regard you have to
register and create USER ID and password on the Saral Sanchar Portal
(https://saralsanchar.gov.in/admin/olmRegistration_add.php ) as new user. In case you
already have your userId and password then you can start using various post license
activities, i.e application of surrender / name change / change in authorized signatory etc.,
submission of all kind of reports etc by logging in the portal
(https://saralsanchar.gov.in/LoginHome.php ).
2.

As a first step, all licensees have to mandatorily update / confirm the information of

their existing Licenses / authorizations. Further, licensees are mandatorily required to send /
fill the online reports through reporting module of Saral Sanchar. Manual for using the
portal for migration of license / authorizations is enclosed for ready reference as AnnexureI
and
is
also
available
at
https://saralsanchar.gov.in/user_manual/ul/UL_Migration_Applicant.pdf
.
List
of
documents required for migration of existing licenses / authorizations is enclosed as
Annexure-II.
3.
All licensees are hereby requested to immediately confirm / migrate details latest by
15-9-2022 of your all existing licenses / authorizations issued before November-2018 and

<!-- page 2 -->

DS-28/1/2020-DS-III
I/3057477/2022

start sending the online reports. All such licensees who have been issued license through
Saral Sanchar only (i.e. after November-2018) can straight away start using the Report
module of upgraded Saral Sanchar. It is further requested that till the time the new system
is stabilized; licensees are also required to continue sending the reports as per the current
procedure. Once the system is stabilized the department will discontinue Offline Reports
and will accept reports in online mode only. Licensees are requested to fill the status of
various reports for the current year w.e.f. 1-4-2022.
4.

This is issued with the approval of Member (Technology).

VINEET
MALIK

Digitally signed
by VINEET MALIK
Date: 2022.08.30
16:25:43 -07'00'

(Vineet Malik)
ADG (DS)
Encl: As above

To
All Licensees
Copy to
1. DG(Telecom)
2. All LSA Heads

3. DDG(AS)/DDG(Satellite)/DDG(CS)/DDG(NT)
4. Director (IT-II) for uploading on DOT website
5. ITPC Pune for sending along with mails to licensees
6. ISPAI / COAI

<!-- page 3 -->

DS-28/1/2020-DS-III
I/3057477/2022

Annexure – II
List of Documents required for Migration of Existing License / Authorization

1. Following digitally signed (by authorized signatory) documents are required;

Certificate of Incorporation
License Agreement
Board Resolution authorizing the authorized signatory
2. The authorized signatory who is applying for migration must have a digital signature
3. The authorized signatory mentioned in the License need not be the same for the

process of migration.
4. The board resolution authorizing the authorized signatory must be same who is
signing all the documents for migration.
5. In case the Licensee has multiple authorizations under single Unified License, he is
required to upload only the digitally signed copy of latest authorization which should
have names of all prior authorizations under the same license number.
6. For any queries, please raise ticket on
helpdesk. (https://saralsanchar.gov.in/ticket/tktadd.php?var=1)

<!-- page 4 -->

User Manual
(Version 1.0)

For
Applicant

Migration and related workflows of UL/UL VNO licenses
in
SARALSANCHAR

Department of Telecommunications
Government of India

18th June, 2022

1|Page

<!-- page 5 -->

TABLE OF CONTENTS

Content

Sr No

2|Page

Page No.

1

Introduction

3

2

Migration Request

4

3

Application form

5

4

Addition/ Modification of data

7

5

Upload Signed Application

8

6

Modification after reversion

9

<!-- page 6 -->

1) Introduction:Government has issued the guidelines for shifting telecom service providers to
the new Unified Licenses regime, wherein the spectrum is not given along with the
permits as has been done in the past.
After coming into force of the Unified License, all the existing licenses issued
under Section 4 of the Indian Telegraph Act 1885 shall stand automatically
converted to the Unified License. This will be the Unified License.
On conversion, the validity of the Unified License shall be same as the validity of
existing license. The conditions of Unified License shall be the same as existing
license.
The services under such a license will be restricted to the service(s) that the
Licensee could offer and to the service area(s) permitted under the existing license.
In case an existing licensee after conversion to Unified License wishes to provide
services permitted within the scope of service under Unified License but which are
not covered under its old license, then it will have to apply for Unified License.
For conversion to the Unified License, there shall be no additional entry fee to
be paid by the licensee.
A holder of Unified License shall have the option to apply for and migrate to a
Unified License.
In the event a holder of Unified License desires to expand/alter the service(s)
offered or service area(s) of operations, it shall be required to migrate to Unified
License and pay the prescribed entry fee.

3|Page

<!-- page 7 -->

2) Migration Request:In order to migrate the existing UL, UL VNO and Pre-UL licenses a new Migrate
button is provided on the main dashboard for the applicant user.

4|Page

<!-- page 8 -->

3) Application form:- Once the migrate button is pressed the user is redirected to
the Application form page where all the user and services data already present is
populated which can be edited.

5|Page

<!-- page 9 -->

The existing services data is populated which can be edited and new services data
also can be added. Also the user has to upload 3 documents mentioned in the form.

The application form can be Saved and Validated before the final Submit.
Also Application form can be previewed in PDF format.

6|Page

<!-- page 10 -->

4) Addition/ Modification of license and services data:Applicant can modify the existing license and service details.
Applicant can also add new entries of license details using the + (plus) menu on
the grid table.

7|Page

<!-- page 11 -->

5) Upload Signed Application:The applicant has to upload the digitally signed form after submitting the
application form. It can be downloaded from the same page.

Once the signed application is uploaded and submitted using Final Submit button
the application will be forwarded to the respective nodal office for scrutiny.

8|Page

<!-- page 12 -->

6) Modification after reversion: In case the nodal officer reverts the application
for corrections, the reverted application will appear in the user dashboard with
Modify button.

Migration application form will be opened for editing again for user. After submission
of the form same flow of scrutiny will be followed as for the new migration application.

9|Page

<!-- page 13 -->

10 | P a g e

<!-- page 14 -->

11 | P a g e
