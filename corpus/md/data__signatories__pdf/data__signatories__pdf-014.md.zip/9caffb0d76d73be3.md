---
doc_id: "9caffb0d76d73be3"
source_url: "https://www.dahd.gov.in/static/uploads/2026/06/6dcd48794189f7affa7a6dfd24cb9b35.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Recruitment to the posts of Deputy Commissioner (02) & Assistant Commissioner (02), General Central Service, Group 'A' Gazetted in the Department of Animal Husbandry and Dairying on Deputation (ISTC) basis."
date: "2026-05-07"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "de8ae8e37b1f9057"
---

<!-- page 1 -->

F.No A-12O17 I t I 2O26-Adain_1/lE-41 139f

Gi,overnn€rt of Indie
Ministry of Fisheries, Animd Husbandry and Dairying
Depertnent of Aairaal
and Dairying
*Husbandty

Krishi Bhawan, New Delhi - 1 10001
Dated, the O7e May,2026
VACANCY CIRCULAR

Subject: Recruitment to the posts of Deputy Commissioner (O2f &
Assistaat Commissioner (O21, General Central Serrrice, Group
'A' Gazetted in the Department of Animal Husbandry and
DairJrhg, Mlaistry of Fisheries, Aaimal Husbandry and Dairying
on Deputation lltrcluding short-term cootractl basis - reg.
It is proposed to fdl up the posts of Deputy Commissioner (02) &
Assistant Commissioner (02) in the General Central Service, Group 'A'
Gazetted on Deputation (including short-term contract) basis, in the
Department of Animal Husbandry and Dairying, Ministry of Fisheries, Animal
Husbandry ald Dairying, Government of India.

2. The Department of Animal Husbandry and Dairying intends to fill the
following posts at its Headquarters, Delhi or field/ subordinate oflices, as per
the functional requirement, from amongst ollicers under the Central
Government or State Governments or Union Territory Administration or
public sector undertakings or Universities or recognized research institutions
or autonomous bodies or statutory organizations: Post

Number of Scale of Eligibility
Posts and Pay
Name of the
Station lZone-

Deputy
Commissioner

wisef
Two (O2l

l-evel-12

Oflicers under the Central

Government or State
78,800Governments or Union
2,O9,200) Territory Administration or
in the Pay Public Sector Undertakings
Matrix
or Universities or recogrrized
research institutions or
autonomous bodies or
statutory organizations: (a)(i) Holding analogous posts
on regular basis in the parent
cadre or department; or
(ii) With five years' regular
service in grade rendered
after appointment thereto on
(Rs.

a regular basis in Level-ll
(Rs. 67,7OO-2,08,7OO) in the

Pay Matrix or equivalent, in
tJle parent cadre or
department; and
d*c rqerqr{,/ s^xira
{inblty oi FEh..is. Anin l

cgqa.{ 3it{ iqo Elrr,r
o.e.rh.nl olAnrfi.l NutD.ndh e o.'d'no
F& rc< rJ Edu nmn,s""".n ri", ourri'.riooot

<!-- page 2 -->

(b) Possessing the following

educational qualifrcations
and experience: -

Essential: -

(i) Bachelor's Degree in
Veterinary Science and

Animal HusbaldrY as listed
in the First Schedule and
Second Schedule of the
Indian Veterinar5r Council
Act, 1984 (52 of 1984);
(ii) Eight years' exPerience in

and livestock
development or Poultry or
catfle

alimal health or meat and
meat products from the

Assistalt

Two (O2l

Level- 1 1
(Rs.

Commissioner

Central Government or State
Government or Union
Territory Administration or
statutory organization or
autonomous bodies or
institutes recognized bY the
Government.
Desirable: Post Graduate degree in anY
bralch of the VeterinarY
Science and Animal
Husbandry from a recogrrized
University or Institute.
OIficers under the Central

Government or
Governments or

State
Union

67,7002,O8,700\ Territory Administration or
in the Pay Public Sector Undertakings
or Universities or recognized
Matrix
research institutions or
autonomous bodies or
statutory organizations: (a)(i) Holding analogous Posts
on regular basis in the Parent
cadre or department; or
(ii) With four Years' regrrlar
service in grade rendered
aJter appointment thereto on

a regular basis in Level- 1O

qFd aritra,/Goramfi 6nl o,

R

qlF{. c{crfi dtr t{8

lgqrda ii\r iqt R{m

Tn. {i Q-S

I O.n h!
0.nyint
Oelhi-l10001

(Rs. 56,1OO- 1,77,5OO) in the
Pay Matrix or equivalent, in
the parent cadre or
department; and

<!-- page 3 -->

(b) Possessing the following

educational qualiEcations
and experience: -

Egseatid: -

(0 Bachelor's Degree in

Veterinary Science and

Animal Husbandry as listed
in the First Schedule and
Second Schedule of the
Indian Veterinar5z Council
Act, 1984 (52 of 1984);

(ii) Registration in the
Veterinar5r Council of India or
Veterinary Council of States;
(iii) Five years' experience in
cattle and livestock
development or poultry or
animal health or meat and
meat products.
Deslrable: -

Doctorate degree in any
branch of the Veterinary

Science ald Animal
Husbandry from a recognized
Universit5i or Institute.

Notel: The period of deputation and other terms and conditions shall be
governed by Department of Personnel and Training's Oftce Memorandum No.
6/8/2OO9-Estt.(Pay II) dated 17.06.2010 and the guidelines of DoP&T issued
on the subject from time to time.
Note2: The maximum age limit for appointment by deputation sha-1l not be
exceeding fift5r-slx years as on the closing date of receipt of applications.
3. The post carries all India tranefer liabiltty. Accordingly, an officer
selected, if so required, may be posted in any ottice of the Department
i.e. Headquarter, Delhl or field/ subordinate otlicea, at the titne of

completion of selection proccss or at the time of appointment ot
thereafter, as per the fuactional requirement of the Department.

4.

For eligibility criteria, i.e. educational qualification, experience and biodata proforma etc., the applicants are advised to refer to the ollicial website
of this Department htto: / /dahd.nic.in.

5. Applications (in duplicate), only in the prescribed Bio-Data and C.V.
Proforma (Annexure-I/Aanexure-IV) of the eligible candidates whose services
can be spared immediately on selection, together with the certificate from the
forwarding authority (Aanexure-Il/Aanexure-V) may be forwarded along
with the following documents:
(i) IntegrityCertilicate,
(ii) List of Major/ minor penalties imposed if any, on the oIlicial during the

last 1O years; (if no penalty has been imposed a .IYIL, certificate shouid
be enclosed).
rrff{ Tqznr{,/ sANJTB
s! i&a,/

{rr iiqi I'rrdq

lorrr.|

uri'3r.y ol Fl3ltlmratu*i.r r,hdrtt
qrlqr a alfr ac{t
-, -, .i Ai,q.r xur!.idry a O.lrylii

hql

c. .5r Ne,0.h!lr000l

<!-- page 4 -->

(iii) Vigilance Clearance Certifrcate.
ACRs/ ApAR dossiers for the last five years w.e.f.
ii"j at-t*t"a copies of the (attested
on each page by an olficer not below the
2O2O-21 to 2024-25\
rank of an Under Secretary to ttre Govt' of India)
In case the applicant belongs to an organization which is not following
the Central Government pay scales, a Pay equivalency Certificate (4t3""Y:'
ifverro"t rt"-vll issued by the organization may also be forwarded to this
Department.

The require{ documents mentioned at the end of Annexure' may be
Room-No'
forwarded to strri eanta.l Kumar sinha, under secretary (Admin.I),
iiZ-A, o.p"tt-ent of Animal Husbandry and Dairying, Xrlstti !!t- w15ta!9y
THROUGH PROPER
o"firi'- itOOOt [Email ID: pk.sinlia88@gov'in],
or from the
CHANNEL within six weeks from the date of issue of this letter
ggfqR'
date of publication of the vac€rncy in the Employment News/ ftd-rfn
those
whichever is iater. Application not forwarded tlrrough proper channel-or
will not be
received without ."qri.it" certificates and necessar5/ documents
particulars
of
the
entertained. While forwarding the application, the veracity
furnished by the caldidate may be verifred and certihed'

6.

Encl. : As above.

Yours faithfullY,

ib Bha
Deputy Secretar5i (Admin. )
Tel. 01 1-23389606

Copy for information/necessary actlon to:
'eU
(through e-HRMS
frait i"t.ies/Departments oi the Government of India
f.
2.O1.

2. The Secretary, ICAR, Krishi Bhawan, New Delhi - 110001'
S"&"trri"" of State Governments/ Union Territories, Recognized
5. il&"l
Research Institutions/ Cadre Controlling Authorities of Universities/

with
Public Sector Undertai<ings/ Autonomous/ Statutory Organizations'
circular'
to this
a request to give wide publicity
-subordinate
-vacancy
Department of Animal
the
of
olfices
+. eU ti." attaJred and
Husbandry and Dairying.
e5. Nrc, for u-ploading tle lame to the Department,s oflicial website and
offrce Notice Borad.
of
6. The General Malager-cum-chief Editor, Employm,ent News, Ministry
u't:'\'j'
Information ald Broadcasting, 7s Floor, Soochna lJhavan'
as per the
Complex, New Delhi - with a rJquest to publish this Circular'
1ttr'l11
format of ANNEIKIIRE in the ensuing issue of Emplo5rment News/

SIEIE, at the earliest.
7. Guard frle/ Spare copies (Twenty (20))'
(Sanjib Bhattac
Depu ty Secretary (Admin.)
Tel.011-23389606

<!-- page 5 -->

ANNAXURE-I

BI O.DATA/

of the Post:

vITAE PRO
ONER

Number of posts = Two l02l
1. Name & Address (in Block Letters

2. Date of Birth (in Christiar Er a)
3(i) Date of entry in service

(ii) Date of retirement under
Central/ State Government Rules

4. Educational Qualifications

Qualilicatlons I

nzperience Quallllcatioas/ Experieace
possessed by the olflcer
advertisement / vacancy circular
A. Essentlal Qualiflcatioa: A. Essential Quallllcation: (i) Bachelor's Degree in Veterinary
Science ald Animal Husbandry
as listed in the First Schedule
arld Second Schedule of the
Indian Veterinary Council Act,
L984 (52 of 1984).
(ii) Registration in the Veterinar5r
Council of India or Veterinar5r B. Desirable Qualilicatioas: Council of States; and
B. Desirable Quallfications: Post Graduate degree in any
branch of the Veterinaqr Science
and Animal Husbaldry from the
recognized University or Institute.
C, Drperience: C. Experience: Eight (O8) years' experience in
cattle ald livestock development
or poultry or animal health or
meat and meat products from the
Central Government or State
Govemment or Union Territory
Administration or statutory

required as mentioned in the

organization or

autonomous
bodies or institutes recogrrized by
the Government.
Note: In the c as o f D egre e ald Po S t G rad uat e Qu a,lifi catio n S Eiective mann
S u bj ects arrd SU bsidiary S u bj ect S may be indicat
d by the candida te Th e
app 1i an ts AJ e al S required to encl ose self- attes ted co p 1e S of re eva_n
t
Sl.1 pp orting documents ln r
pec t o f their qualificatio n S ald exp enen c e
5. Please state clearly whether in the
light of entries made by you above,
you meet the re site Essential
**q {q?rsr{,/ s^NJrB

3C ift {/ Dairt, S.ararart
qRn ,n/@r.mo..i ol
iR $fl qlcl<r *
cTr{i lfn
o.!.rlr!.nl ol Anfi.l Hu.!.n!r, a o.ir.t
rrr.
it
ftdl
,/ i.'tlr, lltt'l . x.r o.ststloll
Ffr

<!-- page 6 -->

expenence
Qualifrcations and work
of the Post.

cal order. Enclose a separate sheet
chronologi
in
ent,
EmPloYm
of
6. Details
if the space below is insuflicient'
duly auttrenticated bY Your signature,
Office/
Institution

Post held on
regular basis

From

To

of
"Pay Band Nature (in
Duties
and Grade
Pay lPaY

detail)

Scale of ttre highlighting
post held on experience
regular basis required for

the

Post

applied for

ACP/MACP are
*ImPortant: PaY Level/ Scale & Grade PaY granted under
should not be mentioned. OnlY PaY
p ersonal to the offrcer and therefore,
regular basis to be mentioned'
l*vel/ Scale & Grade PaY of the P ost held on
LeveU Scale where such benelits
Details of ACP/MACP rith Prese nt PaY
as below: have been drawn bY the Candidate
Office/ Institution

may be indicated

Pay, PaY Level/ Scale &
Grade PaY drawn under
ACP/ MACP Scheme

To

From

7. Nature of Present emP loSrment i'e.
Ad-hoc or TemPorary or QuasiPermanent or Permanent'
8. ln case the Pres ent employment is
held on dePutatio n/ conttact basls,
please state: of (c) Name of the
(a) The date of (b) Period on
parent office/
initial appointment. appointment
to
deputation/ contract' organization

which

applicant
belongs.

the

(d) Name of the
post and PaY of
the Post held in

E"E

substantive

.E! Ei

parent.
Organization.

iEitii:

capacity in the

i Er ir:5

{ € Ets: =:

EEEiE:i
FE-- !Y
EE T-

of Such
on d eputation th e applications
aiready
o
ffrcers
of
case
In
ote
wLth
8. 1 N
th e parent cadre D epartmen t along
olfrcers should be fo rwarde d by
ce and In te cnty certilicate
Cadre Clearance Vigilalce Clearan

<!-- page 7 -->

8 2 N ote Info rln ation un d er Co umn 8(c) O6 (d) a b ove mu S t be glven tn
all
cases where a pers on
holding a pos t o n depu ta ti on ou ts de th e
cadre orgarl]z'ation bu t S ti11 IrIEI]N taining a lien 1n his paren t cadre

organization.

9. If arry post held on Deputation in the

past by the applicant, date of return
from the last deputation and other
details.
10. Additioaal details about present

employment: Please state whether working under
(indicate the name of your employer
against the relevant column):
a. Central Govemment

b. State Government
c. Autonomous Organization
d. Government Undertaking
e. Universities

f. Others
l l . Please state whether you €rre

working in the same Department and
are in the feeder grade or feeder to
feeder grade.
12. Are you in Revised Scale of pay? If
yes, glve the date from which the
revision took place and also indicate

the pre-revised scale.
13. Total emoluments per month now drawn.

Basic Pay in the Pay

Pay Level

Tota-l Emoluments

Level/ Scale

I 4 In CASC the app Iican t b longs to an o rgaitzatio n which 1S no t following
the C en tral Governm en t Pay sca-les th e 1ates t salary s1i p 1S s ued by th e
o rganva tion sh owlng the following d e tails may be enclosed.
Basic Pay
with Dearness Pay/interim
Total Emoluments
Level/ Scale of Pay and relief /other Allowances
rate of increment
etc., (with break-up
details)

16. Whether belongs to SC /sT/oBC

17. Email ID:
18. Mobile No.:

i*{ qErsr{/s xJrB Bxlrr c
Bq

rfr,/o.F,t, s.c[t ry

ira?l ili6R/G&.6a.nl ol ln li.

m v=ct vgcrea * &i

qljqllri Jr{ &a A{Fr'
o.DUh.nr ol

^Iir.l Bh.m. Ld O.{lrl0lf,l
fn r.'r. d Rdl,/ri'sti

<!-- page 8 -->

circular/advertisement and
I have carefrrlly gone througtr the vacancy the Curriculum Vitae duly
furnished in
I am well aware that tt" itflil"tio"
of Essential Qualihcation/ work
tespect
;
docum;;
the
by
supported
assessed by tJee serection committee
Exoerience submitted by rie *;I "i""1"
p"". Tt" informarion/ details provided.bv
T'
having
fact
material
no
and
rov rirrowredge
are correct and true to tt" t""ior
withheld'
selection has been suppressed/

;iffffi ilil;;i.r,r,"
li"Jg."

my

(Signature of tl.e candidate)
Address

Date

q-drs {{ersr{ ,/ sAxJlB BtTATTActcRYA
sr {&q/Dar{I, s'rcro'_'
qnn Wan/G.t'ltrnttnl ol lttdi'

6 !rF{ qalr<r dtr a.Hl {'_d!

rrd;t."l#:i-Ht#ffirro'""t

$HH'*$X*'i"'SfI.1"ffi*'

<!-- page 9 -->

ANNEXURE.II

Name of the Post: DEPUTY COMMISSIOIER

t%1:"J" application bY
and he/she
in the
tioned
qualifica tions and expenen ce men

Certified that the particulars tumishedin

possesses edu cational
e will be relieved immediatelY.
rracancY Circular . If selected, he/sh

2.
(i)

Also certifled that;
case pending/ contemplated
There is no vigilance or disciplinary

(ii) His/ Her integrity is certified'
for the last 5 years (for the
(iiil The photocopies of the ACRs /APAR dossiers
of t]le rank of Under
u"ar korn 2o2o-zt to zozilZsil"iJ' tti*i"a by.an oflicer
'S;irJ*y of the Govt' of India or above are enclosec'

(i9

*No major/ minor penalt5r has been imposed on him/ her during

the

Iast 1O Years.
the last
*A list of major/ minor penalties imposed on him / her during
(")
10 years is enclosed.

Signature

:

FaxNo.
OItrce Seal

:

Name & Designation :
:
Telephone No.
:

Place:

Dated:

List of Enclosures (In the prescribed order):
1. IntegritY CertiJicate '
last ten years'

z. ii" fitl6.lvrinor Penalt5z Certificate for

3. Vieilance'Clearance Certificate'
+. p"TBq"f"rf ency Certificate (if applicable)'

and exoerience'

5. Supporting documents i'r'o.' qualifrcations
s vears (w.e.f. 2020-21 to
6. Attested copies of ACR")#'rHil#;;;J;
2024-251.

z. 6tt ..i"rant documents, if applicable'
"t
fstrike Out which is not applicable')

ffim
"s. eTYHji",ffi"'^"Y^

<!-- page 10 -->

ANNEXURE-III

Pay Equivalency Certifrcate for

Deputv Commissloner
1s

Certilied that Shri/Smt'lDr'-,--..."r
oresentlv holding
"'@
i'ever-l2 (Rs' 7a'8oo'
ia
',,'o*o'-i""''o'"f
d;;;'"""pin-Cq
iinancial upgradation
central Pav commiselon ot

76

2,os,zool in the P"v ;;;t';;;or Department'
t" the parint cadre
;;;;;t'
OR

has

'
Certifred that Shri/Smt'/Dr'
completed frve (05)
financial
Uasis (and n-ot on [re grant of
aDoointment thereto or, . .""-g,rii67'70o'2'08'70o) in the
L"tr'r
lRs'
atiili"
rtaacp)
through
1
uo-eradation
or equivalent' in the parent
pa! matrix as per 7tr c""ili"P"y Eommission

*t"

,"'"'ii'lJfr''ffi

cadre or Department'

lPlease strlke-ofI

completely shichever is not appllcablel

Signature

:

FaxNo.
Office Seal

:

Name & Desiguation :
:
Telephone No.
:

Place:

Dated:

*ff{ {(asrrl,/slxJtB BHlrrlcltanya
Bt rfta/ or.riry s.ctta.r,

ltnt *r/cot.r|r..t C lidi.

R lltq, q$F ll! tdt
cqqa" dtl kt toql|rol Antfill tlr!.ndrv I oidlm
^ o.r.,lr!.!l
Fl c'r'i { Rin,/r,ct !h.,m. ir. ourl.iimor
rllilt, C tihraralet HEn .lrrtrrR
r Drrfi

<!-- page 11 -->

ANNA)TI'RE.IV

BIO-DATA/ CI'RRICI'LUM VITAI PROFORIIA
Name of

Post:

co

ssr

Number of posts = Two (O2)
1. Name & Address (in Block Letters

2. Date of Birth (in Christian Era)
3(i) Date of entry in service

(i1) Date of retirement under
Central/ State Government Rules

4. Educational Qualifications

Qualifications/ E:rperience Qualifi catlons/ Erperience
required as meationed in the possessed by the ofllcer

advertisement / vaconcy circular
A. Essentlal Quallficafion: A. Esseatlal Qudillca$on: (i) Bachelor's Degree in Veterinary
Science and Anima-l Husbandry
as listed in the First Schedule
and Second Schedule of the
Indian Veterinar5r Council Act,
1984 (52 of 1984).
(ii) Registration in the Veterinary
Council of India or Veterinary B. Desirable Qualifications: Council of States; and
B. Desirable Quettfi6gtl.r.. Doctorate degree in any branch of
the Veterinary Science and
Animal Husbardry from the
recognized Universit5r or Institute.
C. hperieace: C. Elperleace: Five (05) years' experience in
cattle and livestock development
or poultry or animal health or
meat and meat products.
N ote In th cas e of D e gree and Pos t G raduate
Qualifica tions |1, e ctive maln
su bj e cts an d s u b S idiary S u bj ects may be indicated by the candidate.
The
a pp li can t S aJe aIs o requ ire d to enclose self-attested copies
of relevant
supporting documents in re S p ect o f their qu a]i-fications and experience.
5. Please state clearly whether in the
light of entries made by you above,
you meet the requisite Essential
Q ualifrcations and work experience
of the post.

6. Details of Employment, in chronological order. Enclose a separate sheet
duly authenticated by your signature, if the space below is insufficient.
rdf4

I tl
tl[.fi. clqrr dlr dt

ol ri!hrr1.r. Ar*nd H{rh.idn

qql.la !t{ *{t Ecrq'

r

O.D.,lrlnl ol An'D.t tiu.brnd,r I O.ln'n.
fR nn. d Htl r".r" sr.-.i. i.r oRr;. rioo0l

<!-- page 12 -->

Oflice/
Institution

Post held on
regular basis

From

To

of
'Pay Band Nature (in
Duties
Grade
and
detail)

Pay lPaY

Scale of the highlighting
post held on experience
regular basis required for

the

Post

applied for

ACP/ MACP are
*Imp ortant: PaY l*vel/ Scale & Grade PaY gran ted under
should not be mentioned. OnlY PaY
perso nal to the oflicer and therefore,
t held on regular basis to be mentioned'
l-evel I Scale & Grade PaY of the Pos
Pay Level/Scale where such benefits
Details of ACP/MACP rith Present
may be indicated as below: have been drawn by ttre Candidate
OfEce/ Institution

Pay, PaY levet/Scale &
Grade PaY drawn under
AcPl MACP Scheme

To

From

7. Nature of Present employment i.e.
Ad-hoc or TemPorarY or QuasiPermanent or Permanent'
is
8. ln case the present employment
basis,
held on dePutation/cotrttact
please state: the
of (c) Name of the (d) Name of
(a) The date of (b) Period on
of
PaY
and
post
parent oflice/
initial aPPointment. appointment
in
held
post
to the
deputation/contract' organization
substantive
the
which
capacitY in the
applicant
parent.
belongs.
Organization

S o f such
o n depu ta tion th e application
8 1 N ote3 In case of o fficers alreadY
with
along
t
en
b the parent cadr e D ep artm
o ffrcers Should be forward ed v
Integn ty certificate.
c adre Clearance igdance C learan ce and
1n all
8 (c & (d) above mu st be glven
Column
der
un
rmation
Info
ote
82 N
tion outside the
IS holding
CASES where a
sq aft !,/ Oar{ty S..r.tr,

lr{{l ora/Gor.nm o{ lnt i
R q<i qlcrfi iF tq{i
sg{l.ll

D..dn.nl ol A.ir.l

f'fi qi d nd,/&!t,

I 0.iryleg

0.5&l!000t

<!-- page 13 -->

cadre

/ orgarization but still maintaining a lien in his parent cadre/

organization.

9. If aly post held on Deputation in the

past by the applicant, date of return
from the last deputation and other
details.
10. Addtttond detalls about preseat
emplo5rment: Please state whether working under
(indicate the name of your employer
against the relevant column):
g. Central Government
h. State Government
i. Autonomous Orgarrization
j. Government Undertaking
k. Universities
I. Others

11. Please state whether you are
working in the same Departrnent and
are in the feeder grade or feeder to
feeder grade.

12. Are you in Revised Scale of pay? If
yes, glve the date from which the
revision took place and also indicate
the pre-revised scale.
13. Total emoluments per month now drawn.

Basic Pay in the Pay

Pay Level

Level/ Scale

Total Emoluments

4. In C as e the ap pli c an t belongs t o an o fganaa ti on which 1S no t fo 11 owmg
th e Centra-l Governmen t Pay-scales, th e 1at e s t S a-lary S lip S u e d by the
Or ganizatio n showing the following d etails may be enclo S ed
Pay
udth Deamess Pay/interim
Total Emoluments
Level/ Scale of Pay and relief /other Allowances
rate of increment
(with break-up
1

Basic

etc.,

details)

16. Whether belongs to SC/ST/OBC
17. Emai.l ID:
18. Mobile No.:

d*{ r<rsd

I

wlqlr dtr ta{t 'irrm

tu*tr.t Nur!.nr,r I or,t

c{qfi 3ih &r, Af,'
oltrir.l liur!.nd?r I O.itu*
Fff i...{. d Ht/ xJi.ru BrBr.n. i., olr,+iioool
nt

<!-- page 14 -->

and
vacancy circular/advertisement
I have carefully gone through the
duly
furnished-in the Curriculum Vitae
I am well aware that tt'" i"f"'trn"t?t"
t""p"ct of Essential Qualification/ Work
supported by the docum"''io--1"
selection committee
Exoerience submitted uy -.

;iff#;;;i;t;;"

*iu

ie assessedby the

"r".rt'" information/ details provided bv me
i';ii" p'"t
ani no material fact having

knowledge
are correct and true tt th";;"i;i;y
withheid'
selection has been suppressed/
;;";;;;-v

(Signature of the candidate)
Address

Da

<!-- page 15 -->

ANNEXURE.V

r
of

in the above aPPlication bY
correct and he/she
experren ce mentioned in the

Certifred that the particulars furnished are
possesse

relieved immediatelY'

vacancy

2.
(i)

Also certilied that;
case pending/ contemplated
There is no vigilance or disciprinar5r

(il) His/ Her integrity is certifred'
(for the
dossiers for the last 5 years
(iiil The photocopies of the ACRs/APAR
of
*t""tta uv "tt offrcer of the rank Under
vear from 2o2o-2rtt 2o24:';;;;;ii
'altJiil ;iil.bo"t'1r r"ai^ ot abo"" are enclosed'
her during the
(1v) *No major/ minor penalty has been imposed

on him/

last 10 Years.

*A list of major/ minor penalties imposed on him/ her
(")
10 years rs enclosed

during the last

Signature
Name & Designation
Telephone No.
Fax No.
Oflice Seal
P1ace:

Dated:

List of Enclosures (In the prescribed

otder):

I . IntegritY Certificate'

i. iii. rf"ii.l rurinor Penalty Certificate for last ten years'
'
i. vleilrrr". clearance Certificate
(if
applicable)'
certificate
;. P;? Eq;t"d;ncv
i'r'o" qu"llncations and exoerience'

5. Supporting documents
s v".." lw'e'f ' 2o2o -21 to
f;J"t
cn")'#aHffi;#
n
or
o. ettested "opi"s
2024-251.

z. 6-tt., ."i""ant documents' if applicable'
("Strike out which is not applicable')

<!-- page 16 -->

ANNEXI'RE-VI

Pay Eouivalency Certificate for

Assistaat Commlssioner
IS

Certifred that Shri/Smt'/Dr'
regulaj basis (and not on the grant of
pre sently holding analogous Post on
CP/ACP) ia Level-l1 (Rs. 67,7OOfinancial upgradation through MA r 7th Central PaY Commlssion or

as

Pe
2,O8,7OO) ia the PaY matrix
DePartment'
or
cadre
t
equivalent, in tJle Paren

OR

Certitied that Stri/Smt'/Dr'

has

-

compIetedfour(04}y"*J;;:;i-.",,,i""i,,lhegraderenderedafter
(and not on tle grant of frnancial
aooointment thereto o. " ,"g"# basis
in the
l""t'f'ro (Rs' 56'1o0'1'77'5oo) parent
.rt'cradation through MAcPifdilt"
in the
;#'ff'ffi;:;:;ilc;"tlJ pJv c'--rssioa or equivalent'
cadre or Department'

lPlease strike'oIf completely

whichever ls not applicable)

Signature
Name & Desigrration
Telephone No.
Fax No.
OIIice Seal
Place:

Dated:

ffi
