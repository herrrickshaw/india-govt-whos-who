---
doc_id: "a0ac3bd1dd4c26af"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/823864a5a4f20fd092d904591a60063d.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment for AFT, Kolkata Bench: Order dated 13.04.2017"
date: "2017-05-04"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8a71e4c20c29b6be"
---

<!-- page 1 -->

.
F. No. J-11017/4/2017-JUDICIAL
Government of India
Minstry of Law & Justice
Department of Legal Affairs
Judicial Section
wena
Shastri Bhawan, New Delhi,
Dated 13" April, 2017
ORDER
The President of India is pleased to engage following Advocates as Sr. Panel Counsel/Central
Govt. Counsel for conducting the litigation of Army, Navy and Air Force before the Armed Forces
Tribunal, Bench at Kolkata as mentioned below, for a period of three years with effect from the date of
this order or until further orders, whichever is earlier:
ARMED FORCES TRIBUNAL, KOLKATA BENCH
SENIOR PANEL COUNSEL
baa
1. Tapas Kumar Khardah, Goswami Para, Rath Bati, PO- WB/1250/1981
Chatterjee Khardah, District-North 24 Parganas, West
Bengal-700117
Mob: 09831064595
Phone: 033-22483169/3190
10, Princep Streep, Kolkata-700012 WB/1579-A/1999
Mob: 09830034882
3. Partha Ghosh 88/33, Dhrmatolla Road, Bally (Near Bellur | F/2382/2002
Railway Station), Howrah,
Mob: 09830385437
Email: parth. gsh35@yahoo.com
Ajay Chaubey 27/1B, Nimu Goswami Lane, Kolkata- F/1863/1848/1995
700005.
Mob: 09433139119
Phone: 033-22109518
Email: hotmail.com
[| Indrajeet Dasgupta | 11, Old Post Office, Kolkata-700001.
Mob: 09830162992
Daya Shankar Flat No. 201 C, ‘Mangaldeep’, 506, G. T. WB/586A/1966
Mishra Road (South), Howrah-711101.
Mob: 09830137199
7. Mukesh Gupta 12/2, Old Post Office Street, Kolkata- F/542/542/1988
700001
Mob: 09830028619
Satyendra ‘Laxmi Sadan’, 112, Girish Ghosh Road, | WB/664/2005
Agrawal PO Liluah, District Howrah-7 11204.
Mob: 09433020160
Email: satyendra_2000in@yahoo.co.in
Hema Mukherjee | Akash Apartment, Flat No. 2/2, 76, P. WB/1983/2009
(Parasnaik) Majumdar Road, Kotkata-700078.
Mob: 09748186663
1 a xy

<!-- page 2 -->

* 181, Dharamtala Road, Saikia, Howrah-
711106.
Mob, 09831214514
Mob: 09163834299
9, K. 8. Roy Road, Kolkata-700001 WB/1345-A/2000
Mob; 09681052546
13: Ashish Kumar 25/1, Bhattacharya Para Lane, Kolkata- WB/489/1986
Chatterjee 700036
Mob: 09433946533
3/2, Netaji Nagar, Kolkata-700040 WB/1764/2000
Chatterjee Mob: 09830652510
2. The engagement and professional fee of the aforesaid advocates will be governed by the terms
and conditions contained in this Department's O.M. No. 22(02)/2001-Judl. dated 14.05.2001 read with
OM No. 26(1)/2014/Judi. dated 01.10.2015 {table ‘8’ for Sr. Panel Counsel & table ‘D' for Central
Govt. Counsel} & instructions issued subsequently through OMs. The aforesaid OMs are available on
ce the official website of this Department i.e. www.legalaffairs,cov.in under the tab ‘Judicial Section’ & in the
link ‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow. Noe .
Brae
(R. K. Srivastava)
Deputy Legal Adviser
Copy to:-
1. PS to ML&J/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to ail JS&LA in the Main Sectt.
2. Sh. Kaushik Chanda, ASG, Calcutta High Court, 10, Kiron Shankar Road, 1* Floor, Kolkata-700001.
3. The Registrar, Armed Forces Tribunal, Bench at Kolkata (West Bengal).
4. The Incharge, Branch Secretariat Kolkata.
5. The Counsel as mentioned above.
6. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
7. NIC cell, Department of Legal Affairs with the request to upload this order on the website of this
Department.
8. Guard File/Judicial Section with 5 spare copies.
aD: A
TT
(D. Srinivas)
Section Officer (Judicial)
Tal. 011-23384945
2
