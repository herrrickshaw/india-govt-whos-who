---
doc_id: "9fffdd3ca62717db"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/93cb6458be58b8bc5d5fac2a8d40d976.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Orissa-Order of panel counsels of Orissa H.C & CAT Cuttack Bench"
date: "2016-10-04"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a1855f3b33c3509d"
---

<!-- page 1 -->

F.No.36(16)/2015-Judl.
: Ministry of Law & Justice
Department of Legal Affairs
Judicial Section
On
Shastri Bhavan, New Delhi
03" March, 2015
ORDER
In supersession of all earlier orders relating to Senior Panel Counsel and Central Government
Counsel for High Court of Orissa, the President is pleased to engage the following Advocates as Senior
Panel Counsel and Central Government Counsel for conducting the Central Government cases with
immediate effect for a period of three years or until further orders, whichever is earlier.
HIGH COURT OF ORISSA oO OF ORISS
SENIOR PANEL COUNSEL P L
SLNO Name & Address Contact No Enrolment No
with Date
Gopal Kumar Aggrawal 09437068279 ऊग्ाग 7
Banka bazaar, PO Chandini Chowk,
Distt. Cuttack-]
2 Siva Mohanty, 09338156379 0-283/1988
Bidanasi Baulachhak, PO-Bidanasi,
Cuttack, Orissa
3 Ranjeeta Pattanaik 08895300901 D/1723/1999
HIG-141, Phase 7, Sailsree Vihar,
Bubneshwar
CENTRAL GOVT. COUNSEL हा
ु 51, 1९०0 | १२७16 & Address Contact No Enrolment No
with Date
GYNALOKA MOHANTY At- 09437311986 2786/1999
Mansinghpatna, Malia Sahi, पड
Cuttack-753008, Odisha
2 DIPTI RANJAN SWAIN 09437385634 0661/93
At-Town Hall Road, Po-Telenga
Bazar, Cuttack, Odisha
3 ARABINDA MOHANTY 09437717080 1276/1999
At-7D/1161, Sector-9, C.D.A.,
Cuttack, Odisha
4 RADHEY SHYAM CHIMANKA 09437008008 139/1980
At-Plot No- C-16, Sector-6, Markat
Nagar. Po-Bidanasi , Cuttack, Odisha
5 BIJOY LAXMI TRIPATHY 09437450048 559/1988
At-Plot No- F/505, Sector-6,
we, 5 C.D.A.,Po-Bidanasi ,Cuttack-14,
a Cy Odisha

<!-- page 2 -->

KAILASH CH. KAR 09337267692 342/1978
At-Kine House Lane, Upar Telenga
Bazar,Cuttack-753009, Odisha
7 DEBENDRA KUMAR SAHOO 09338121159 205/1981
At-Plot No-D/24, Sector-7, C.D.A.,
Cuttack-14, Odisha
PRAVAT KUMAR PADHI 09238588067 707/1992
At-Keonjhar Colony, Po-Tulasipur
Cuttack-753008, Odisha
SANJUKATABALA DAS 09437450505 O-379/1987
C/o-Dr. Bichitrananda Mohanty, At-
Nirmal Kutira, Po-Telenga
Bazar,Cuttack-9, Odisha
DAYANIDHI LENKA 09861066273 O0-350/1994
At-Plot No- D/602, Sector-6,
C.D.A., Po-Bidanasi ,Cuttack-
BIBEKANAND&A NAYAK 09337268091 O-522/1984
C.D.A., Po-Bidanasi ,Cuttack-
7530014, Odisha
12 MILAN KUMAR BADU 09437027369 O-135/1988
AvPo-Telenga Bazar, Purighat,
Cuttack-9, Odisha
*
oI 5
At-Plot No-1262/C, Sector-6,
C.D.A., Po-Bidanasi, Cuttack, a
Odisha
At-Qtr.No-1C/16, Sector-9 C.D.A., nee
Cuttack , Odisha
DULAL SATYANARAYAN JETHI 09437385409 O-894/1988
At-Matha Sahi, Po-Tulasipur, Cuttack,
Odisha,
7 a
At: C/O-Giridhari Kar
At/Po: Chandini Chowk
Near Prajatantra Office, a
Cuttack-753002 है
17 Mahendra Kumar Pradhan 08018609615 D/445/2000
MN Building, Ravi Talkies Road,
Bhubneshwar-2 Distt. Khurda Orissa
2 The engagement of above advocates will be governed by the terms and conditions
contained in this Department’s OM No.26(1)/99-Judl. dated 24" September,1999 read with OM
No.26(1)/2005-Judl. dated 31" January, 2008 and 26(1)/2011-Judl. dated 01.09.2011.
3. Hindi version of this order will follow. eck) an
(Suresh Chandra) |
Joint Secretary & Legal Adviser | |
= |

<!-- page 3 -->

2.
To
All the above advocates.
Copy to:-

1. Shri Anup Kumar Bose, Assistant Solicitor General, GOPALJEW LANE,
CHOUDHURY BAZAR, CUTTACK-753001 (ODISHA) E-mail
advanupbose54(@gmail.com (M) 09438615773

2. The Register, High Court of Orissa, Cutttak.

3. The Accountant General, Orissa, Cutttack,

4. The Pay & Accounts Officer, Department of Legal Affairs, New Delhi
5. PS to ML&J/PS to Law Secretary/PS to Legislative Secretary.
6. Cash (LA) Section.
7. Hindi unit for Hindi version of this order.
8. Guard File/Judicial Section with 5 s/copies.
( B.S. Sharma )
Superintendent (Legal)
f

<!-- page 4 -->

F.No.36(16)/2015-Judl.
Ministry of Law & Justice
Department of Legal Affairs
Judicial Section
कक के s
Shastri Bhavan, New Delhi
03 March, 2015
ORDER
In supersession of all earlier orders relating to Senior Central Government Standing Counsel
and Additional Central Government Standing for CAT, Cuttack Bench, the President is pleased to
engage the following Advocates for conducting the Central Government cases with immediate effect
for a period of three years or until further orders, whichever is earlier.
CENTRAL ADMINISTRATIVE TRIBUNAL, CUTTACK BENCH LAD STRAT UNAL, CUTTACK BENCH
SENIOR PANEL COUNSEL
SARBESWAR BEHERA 09437016384 324/1992
At-Khatbin Sahi, Po-Tulasipur, Po-
Buxibazar, Cuttack-753001, Odisha
ADDITIONAL CENTRAL GOVT. STANDING COUNSEL CENTRAL GOVT. STANDING COUNSEL
BIBHU PRASAD NAYAK 09437596653 O-303/1998
At-Jyoti Bihar, Po-Bidanasi, Cuttack, -
Odisha
2 SATYA BRATA MOHANTY At- 09437311100 1131/1995
Plot No-E/1, Sector-6, C.D.A.., Po-Bidanasi,
Cuttack, Odisha
3 ANANTA KUMAR MOHAPATR At- 09437028055 O-175/1982
Sutahat, Maniguha Lane (Near ie
U.P.School), Po-Buxibazar, Cuttack,
Odisha
4 GHASIRAM VERMA At- | 09238617110 O-188/1977
Plot No-7D/1233, Sector-9, C.D.A, Po-
Bidanasi, Cuttack-14, Odisha
5 BISWA RANJAN SWAIN 09337355619 1449/2005
At-Netaji Nagar, Po-
Madhupanta, Cuttack-753010, Odisha
MANAS MOHANTY At- 09437167163 O-2909/99
Sriram Nagar, Near-Ruchi Spices, Po-
Madhupatna, Cuttack-753010, Odisha
०७५

<!-- page 5 -->

7 BANI DUTTA RAY MOHAPATR At-Sekh | 09437274866 0-1222/1994
Bazar, New Colony, Po-Tulasipur,
: Cuttack-753008, Odisha
PREM KUMAR MOHANTY C/o- 09937566353 O-1279/94
D.P. Mohanty (Sr. Advocate) At-Purighat,
a
SATYABRATA PANDA At- 09861038735 O-1701/2003
Plot No-1077/D, Sector-6, Po-
Bidanasi, Cuttack, Odisha
AMITAB PRADHAN 09437302026 O0-597/2003
C/o-Jishnu Ray, At-Kaligali, Po-Chandni
Chowk, Cuttack, Odisha
DILLIP KUMAR MALLICK 09938640075 O-191 1/1997
At-Plot No-82/F, Sector-7, C.D.A, Po-
oo hae
12 AVIN CHANDRA DEO At- 09439715292 0-394/1994
Kamalpur, Po-Arunadaya Market, Cuttack-
753012, Odisha,,
13 CHANDRA MADHAV SINGH C/o- 0986343583 O-317/2003
Ashok Kumar Sahoo, (Srikrushna Bhawan)
At-P.C.Sarkar Lane, Po-Arunodaya
Market, Cuttack-753012, Odisha
JITENDRA KUMAR NAYAK 09437070166 O-1387/1994
At-Nayak Bhawan, Cuttack Road,
Bhubaneswar -6, Dist: Khurda. Odisha
15 Sangram Kumar Singh 09937375079 0/1393/1999
Sector 6, CDA, Plot No. C/1565/12,
Plot No, B/887, At CDA, Sector 6, Cuttack- eed
14
2. __ The engagement of above advocates will be governed by the terms and conditions
contained in this Department’s OM No.26(1)/99-Judl, dated 24” September, 1999 read with OM
No.26(1)/2005-Judl. dated 31" January, 2008 and 26(1)/2011-Judl. dated 01 09.2011.
3.Hindi version of this order will follow. b)
-- Qerealec hace we—
(Suresh Chandra)
Joint Secretary & Legal Adviser
To tom
All the above advocates,

<!-- page 6 -->

| Seat
‘2 2.
१
Copy to:-
| 1. Shri Anup Kumar Bose, Assistant Solicitor General, GOPALJEW LANE, CHOUDHURY
BAZAR, CUTTACK-753001 (ODISHA) E-mail
advanupbose54@gmail.com (M) 09438615773
2. The Register, Orissa High Court, Cutttak.
3. The Register, Central Administrative Tribunal, Cutttack.
4. Cash (LA) Section w.r.t. payment of retainer fee.
5. PS to ML&J/PS to Law Secretary/PS to Legislative Secretary.
6. Hindi unit for Hindi version of this order.
7. Guard File/Judicial Section with 5 s/copies.
(B.S, Sharma)
Superintendent(L)
ee
*
