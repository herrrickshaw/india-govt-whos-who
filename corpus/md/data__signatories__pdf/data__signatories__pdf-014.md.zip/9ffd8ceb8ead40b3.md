---
doc_id: "9ffd8ceb8ead40b3"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/5ee9031434f8828d0f5dfee523e425f1.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of UL(VNO) ISP Category 'B' for MAHARASHTRA Service Area bearing license no. DS-11/413/2021-DS-III, Dated 06/01/2022 of M/s IPNET BROADBAND PRIVATE LIMITED"
date: "2025-09-23"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c40cee98a63a4063"
---

<!-- page 1 -->

DS-11/413/2021-DS-III(Vol.III)

I/3318009/2025

WITHOUT PREJUDICE
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Data Services Cell)
DS-11/413/2021-DS-III(Vol.III)

Dated: 23-09-2025

To,
M/s IPNET BROADBAND PRIVATE LIMITED
Address:House No.4, Patel Galli, Harsul,
Aurangabad, Maharashtra-431001
Email Id: ipnetbroadbandpl@gmail.com ,

naimpatel.np.np@gmail.com

Subject: - Termination/Revocation/Cancellation of UL(VNO) ISP Category 'B'
for MAHARASHTRA Service Area bearing license no. DS-11/413/2021-DS-III,
Dated
06/01/2022 of M/s IPNET BROADBAND PRIVATE LIMITED, under
condition of clause 10.2 (i) of Chapter-1 (Part-I) of the said License
Agreement.

Whereas, Department of Telecommunication, Government of India (“the
Licensor”) has granted an UL(VNO) license no. DS-11/413/2021-DS-III, Dated
06/01/2022 ( “the License”) to M/s IPNET BROADBAND PRIVATE LIMITED (“the
Licensee”).
2.
WHEREAS, the LICENSEE is required to provide the services under the
terms and conditions of the License and instructions issued by the LICENSOR from
time to time.
3.
That for alleged violation of Conditions No. 18.2.1, 20.3, 20.5, 20.9, 21.2 &
21.3 of the License, a Show Cause Notice No. DS-11/286/2023-DS-II dated
15.02.2025 (“SCN”) was issued to the Licensee on the address provided in the
License and on the address as obtained from Ministry of Corporate Aﬀairs website,
in the event, the two addresses were different. The aforesaid SCN was sent by way
of speed post bearing ID No ED719274031IN as well as by an email on the
registered email ID(s) of the Licensee on 19.02.2025.

<!-- page 2 -->

DS-11/413/2021-DS-III(Vol.III)

I/3318009/2025

4.
That the aforementioned SCN was issued to the Licensee to submit its
reply, within 21 days, as to why the License granted to it should not be terminated,
in terms of the Condition No 10.2(i) under Chapter 1 of the Part-I of the License.

5.
That with respect to reply received via emails dated 20.02.2025 and
27.02.2025 from the Licensee and further status received from O/o CCA
Maharashtra in this regard, it is seen that the Licensee is still in violation of the
terms and conditions of the license as mentioned in the SCN.
6.
That the Licensee has failed to comply with the conditions of the License
and therefore, has violated the conditions of the License as alleged in the SCN.
7.
Therefore, the competent Authority has now decided to terminate/ revoke/
cancel the UL(VNO) ISP Category 'B' for MAHARASHTRA Service Area
bearing license no. DS-11/413/2021-DS-III, Dated 06/01/2022 of M/s IPNET
BROADBAND PRIVATE LIMITED , in terms of clause 10.2 (i) under Chapter I of
Part-I of the License and that the said license is terminated/ revoked/ cancelled
effective from 61st calendar day from the date of issue of this letter.

8.
That the Licensee is further directed to terminate and stop all
interconnections with all service providers eﬀective from the date of termination of
the License.
9.
That the Licensee is further directed to issue a notice of at least 30
calendar days to all its customers within 30 days from today in terms of the
condition 10.2(i) of the License Agreement reproduced as under:
“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order”.
10.
That the Licensee shall take note of the clause 11.2 of Chapter I of Part-I of
the License, which is reproduced as under:
“On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank
Guarantee(s) shall be released to the Licensee only after ensuring clearance of all
dues, which the Licensee is liable to pay to Licensor. In case of failure of the
Licensee to pay the amounts due to the Licensor, the outstanding amounts shall be
realized through encashment of the Bank Guarantees without prejudice to any
other action(s) for recovery of the amounts due to the Licensor without any further
communication to the Licensee”.
11.

That the Licensee shall also take note that in case, it comes to the notice of

<!-- page 3 -->

DS-11/413/2021-DS-III(Vol.III)

I/3318009/2025

the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.
12.
That the Bank Guarantee(s) submitted by the Licensee against the said
license will be released under clause 11.2 Part-I of the License after ensuring
clearance of dues, including dues/ penalty arising, if any, as a consequence of the
aforesaid violation.
13.

That the Licensee may acknowledge the receipt.

Director (DS-II)
Email: dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to:1. DG Telecom, DoT, New Delhi with a request to instruct the concerned LSA(s)

to intimate all Licensees / Infrastructure Providers in their area to discontinue
to provide /
obtain any “telecom resources” to/ from M/s IPNET
BROADBAND PRIVATE LIMITED.
2. Additional DGT, Maharashtra LSA.
3. Sr. Joint CGCA(Revenue), Oﬃce of CGCA with a request to Release the

Bank Guarantees of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of DS wing is concerned, the same will be intimated to O/o CGCA in
due course of time.
4. Secretary, TRAI.
5. Wireless Advisor, for issue of Dues/ No Dues Certiﬁcate till the eﬀective date

of termination of License and convey to office of CGCA.
6. Dy. CCA, O/o Pr CCA, Maharashtra Circle.
7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/

DDG(WPF), DoT HQ.
8. Director (IT), DOT HQ for uploading this order on DoT website for information

to all Service Providers.

9. File No. DS-11/413/2021-DS-III(Vol.III)
