---
doc_id: "a037ae6ea8e9a8ba"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/4cc24f703f8a8860c0ae40b57b2bb484.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "V-Belt (Quality Control) Amendment Order, 2024"
date: "2025-07-02"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6e21283f6709f8a0"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-12112024-258590
xxxGIDHxxx
CG-DL-E-12112024-258590
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 4499]
No. 4499]

नई ददल्ली, मंगलवार, नवम्बर 12, 2024/कार्तधक 21, 1946
NEW DELHI, TUESDAY, NOVEMBER 12, 2024/KARTIKA 21, 1946

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)

आदेि
नई ददल्ली, 24 अक्तूबर, 2024
का.आ. 4880(अ).—भारतीय मानक ब्यूरो अजधजनयम, 2016 (2016 का 11) की धारा 16 द्वारा प्रदत्त िजियों
का प्रयोग करते हुए, के न्द्र सरकार का, भारतीय मानक ब्यूरो से परामिध करने के बाद, यह मत है दक यह िनजहत में
आवश्यक अथवा जहतकर है, एतद्द्वारा वी-बेल्ट (गुणवत्ता जनयंत्रण) आदेि, 2024 को संिोजधत करने के जलए जनम्नजलजखत
आदेि करती है, नामत:1. (1) इस आदेि को वी-बेल्ट (गुणवत्ता जनयंत्रण) संिोधन आदेि, 2024 कहा िाएगा।
(2) यह आजधकाररक रािपत्र में इसके प्रकािन की तारीख से लागू होगा।
2. वी-बेल्ट (गुणवत्ता जनयंत्रण) आदेि, 2024 के , पैराग्राफ 2 में, तीसरे परं तुक के बाद, जनम्नजलजखत परं तुक अंतस्ट्थाधजपत
दकया िाएगा, अथाधत:् -

‘बिते दक इस आदेि में कु छ भी प्रासंजगक सामानों या वस्ट्तुओं के जलए इस आदेि के प्रारं भ की तारीख से पहले ब्यूरो द्वारा
प्रमाजणत जवजनमाधता या जवजनमाधता जिसने प्रमाणन के जलए ब्यूरो को आवेदन दकया है अथवा आयातक द्वारा घरे लू रूप से
जवजनर्मधत या आयाजतत सामानों या वस्ट्तुओं पर लागू नहीं होगा तथा ऐसे जवजनमाधता या आयातक को ऐसे घोजित स्ट्टॉक को
वी-बेल्ट (गुणवत्ता जनयंत्रण) संिोधन आदेि, 2024 की अजधसूचना की तारीख से छह महीने तक बेचने या प्रदर्िधत करने
या बेचने का प्रस्ट्ताव करने की अनुमजत होगी, िो इस ितध के अध्यधीन है दक ऐसे आयातक या जवजनमाधता ने ब्यूरो के समक्ष
चाटधडध अकाउं टेंट द्वारा प्रमाजणत इस आिय की घोिणा की हो।
7283 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

बिते दक इस आदेि में से कु छ भी वी-बेल्ट के जवजनमाधताओं द्वारा अनुसंधान और जवकास के प्रयोिन से प्रजत विध आयाजतत
दो सौ सामानों या वस्ट्तुओं पर लागू नहीं होगी िो इस ितध के अध्यधीन है दक ऐसे आयाजतत सामानों और वस्ट्तुओं की
वाजणजज्यक जबक्री नहीं की िाएगी और उन्द्हें स्ट्क्रैप के रूप में जनपटाया िा सकता है तथा जवजनमाधता ऐसे सामानों या वस्ट्तुओं
का जवत्त विधवार ररकाडध रखेंगे और अपने लेटर हेड पर अजधकृ त हस्ट्ताक्षरकताध द्वारा हस्ट्ताक्षररत प्रजत संबंजधत सरकारी
अजधकाररयों को प्रस्ट्तुत करें ग।े "
[फा. सं. पी-39012/8/2023-एल एण्ड आर]
संिीव, संयक्
ु त सजचव
नोट : मूल आदेि भारत के रािपत्र, असाधारण, भाग II, खंड 3, उप खंड (ii) के अंतगधत अजधसूचना संख्या
का .आ. 1252 (अ) ददनांक 6 माचध, 2024 द्वारा प्रकाजित दकया गया था।
MINISTRY OF COMMERCE AND INDUSTRY
(Department For Promotion of Industry And Internal Trade)
ORDER
New Delhi, the 24th October, 2024
S.O. 4880(E).—In exercise of the powers conferred by section 16 of the Bureau of Indian Standards
Act, 2016 (11 of 2016), the Central Government, after consulting the Bureau of Indian Standards is of the opinion that
it is necessary or expedient so to do in the public interest, hereby makes the following Order to amend the V-Belt
(Quality Control) Order, 2024, namely: 1. (1) This Order may be called the V-Belt (Quality Control) Amendment Order, 2024.
(2) It shall come into force on the date of its publication in the Official Gazette.
2. In the V-Belt (Quality Control) Order, 2024, in paragraph 2, after the third proviso, the following provisos shall be
inserted, namely: “Provided also that nothing in this Order shall apply to goods or articles domestically manufactured or imported
before the date of commencement of this Order by the manufacturer certified by the Bureau or manufacturer who has
applied to the Bureau for certification or by the importer for the relevant goods and articles and such manufacturer or
importer shall be permitted to sell or display or offer to sell such declared stock up to six months from the date of
commencement of the V-Belt (Quality Control) Amendment Order, 2024 subject to the condition that such
manufacturer or importer shall make a declaration to this effect certified by a Chartered Accountant to the Bureau:
Provided also that nothing in this Order shall apply for two hundred numbers of goods or articles imported for the
purpose of research and development by manufacturers of V-Belt per year subject to the condition that such imported
goods and articles shall not be sold commercially and can be disposed of as a scrap and also the manufacturer shall
maintain financial year-wise record of such goods or articles and furnish to the Government authorities concerned in
its letter head signed by its authorised signatory”.
[F. No. P-39012/8/2023-L AND R]
SANJIV, Jt. Secy.
Note. -The principal Order was published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section (ii)
vide notification number S.O. 1252(E), dated the 6th March, 2024.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2024.11.12 20:02:52
+05'30'
