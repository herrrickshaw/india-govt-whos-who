---
doc_id: "9f7ae1ebb9c87afc"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/ab01566e368db5f5fba775eeb012b72f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Government Finalizes Framework for Transfer of M2M SIM Ownership"
date: "2025-10-29"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "727937ab43501189"
---

<!-- page 1 -->

Ministry of Communications

Government Finalizes Framework for Transfer of
M2M SIM Ownership
Framework Enables Smooth Transition of M2M SIM
Ownership without Service Disruption
Posted On: 29 OCT 2025 11:51AM by PIB Delhi

The Department of Telecommunications (DoT), Ministry of Communications, has issued an Office
Memorandum (O.M.) notifying the Framework for Transfer of M2M SIM Ownership from one M2M
Service Provider (M2M SP)/Licensee to another M2M Service Provider (M2M SP)/Licensee. Currently,
there is no provision for change in name of the owner of M2M SIMs under the prevailing guidelines.
Therefore, M2M services for the affected end consumers may get disrupted whenever there is a situation
which necessitates change of M2MSP.
The new framework establishes a formal procedure for M2M SIM ownership transfer to ensure a smooth,
compliant transition without service discontinuity. This is applicable to all M2M Service Providers
(M2MSPs)/ Licensees.
Streamlined Process for M2M SIM Ownership Transfer
The process will include the following key steps:
1. Transfer request to be raised by M2M Service User/Third Party: The user of the M2M service must
submit a formal written request to the existing M2M SP/Licensee (the 'transferor'), detailing the M2M
SIMs and specifying the intended transferee M2M SP/Licensee.
2. No Objection Certificate (NOC) by Transferor (Existing M2MSP/Licensee): Within 15 days of
receiving the user’s request, the transferor must issue a No Objection Certificate (NOC) to the
concerned Access Service Provider(s), provided there are no outstanding dues from the M2M Service
user.
3. Undertaking by Transferee (New M2MSP/Licensee): The transferee M2MSP/Licensee must submit a
formal Undertaking/Declaration to the Access Service Provider(s) mentioning that it accepts all
responsibilities, liabilities, and duties, including compliance with KYC and related guidelines, for the
transferred M2M SIMs.
4. Verification, KYC, and Update by Access Service Provider (ASP): ASP to scrutinise the request of
transfer raised by M2M Service user followed by verification of NOC from the transferor and the
undertaking from the transferee. Upon successful verification, the ASP(s) must carry out KYC again
and update subscriber records to reflect the new ownership.
Importantly, each M2M SIM must at all times remain mapped to an M2M SP/Licensee, and there shall
be no discontinuation of M2M service to the user.
The complete Office Memorandum and formats for the User-Initiated Request, the Transferor's NOC, and the
Transferee's Undertaking are available at https://dot.gov.in/all-circulars?tid=3197 .
The introduction of this framework underscores DoT’s sustained efforts to safeguard end-user interests while
supporting the operational flexibility of service providers, ensuring that India’s M2M and IoT services remain
reliable and future-ready.

<!-- page 2 -->

<><><<>
Follow DoT Handles for more: X - https://x.com/DoT_India
Instahttps://www.instagram.com/department_of_telecom?igsh=MXUxbHFjd3llZTU0YQ==
Fb - https://www.facebook.com/DoTIndia
Youtube: https://youtube.com/@departmentoftelecom?si=DALnhYkt89U5jAaa

****
Samrat/Allen

(Release ID: 2183636)
