---
doc_id: "9db6bbb3a9ff06d3"
source_url: "https://www.dahd.gov.in/static/uploads/2025/08/a4af3d3f5a3024078787fcfb41c5969e.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Filling up of one vacant. post of Assistant, General Central Service, Group 'B', Non- Gazetted, Non-Ministerial in Level 6 of CCS (RP) Rules 2016 in the office of Regional Fodder Station, Suratgarh (Rajasthan) on Deputation (ISTC) basis."
date: "2025-05-01"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "78e089c761fb272d"
---

<!-- page 1 -->

'Bffi'f fficf>R

q~qJ('j.-j 3ITT" ~ ~
q~qJ('j.-j 3lR ~ ~

'1ct-ll41C1'1,

~ T . f f f i ~·

~ - 3 3 5 804 ( ~ )

Government of India
Ministry of Fisheries,Anima·I Husbandry and Dairying

Department of Animal Husbandry and Dairying

REGIONAL FODDER ST ATION
SURATGARH-335804 (RAJASTHAN)

No.3- 1/2012/Estt./FS/

~ 01 .05.2025

VA CANCY CIRCULAR
Applications are invited for filling up of one vacant. post of Assistant, General Central Service, Group 'B', NonGazetted, Non-Ministerial in Level 6 of CCS (RP) Rules 2016 in the office of Regional Fodder Station, Suratgarh
(Rajasthan) on Deputation (ISTC) basis
Name of the
Post:
C lassificatio

Assistant
General Cen_tral Service, Group ' B ', Non- Gaz·e tted, Non-Ministeria l

n:

Pay leve l &
Sca le of Pai:
Method of
recru itm ent:
E li g ibi lity:

Pay Band -2 (9300-34800+Grade pay 4200/-)
Level - 6 ofCCS (RP2 Rules, 2016 (Rs. 35 ,400-1 , 12,400/-)
Deputation (Including short-term contract):
Officers of the Central Government or State Government or Union Territory Admini strati on or
Universities or Public Sector Undertakings or Recognized Research Institutions or Semi-Governm ent or
Statutory or Autonomous Organizations: (A)
(i)
Holding analogou s posts on regul ar bas is in th.e parent cadre or D e2artment; or
With six years of service in the grade rendered after appointm ent th ereto on a regul ar bas is
(ii)
in pay band 1, Rs. 5200-20200 with Grade Pay of Rs. 2800 [Level- 5 of CCS (RP) Rul es,
2016 Rs. 29,200 - 92,300/.-] or eguivalent in the 2arent cadre or De2artment: and
Possessing the following educational qualifications and experience: (B)
Bachelor' s degree from a recognized University or Institute.
(i)
(ii)
Two years ' experience in Administration, Establ ishment and Accounts matters.
The Departmental officers in the feeder category who are in the direct lin e of promoti on w ill not be j
e ligible for c;onsideration for appointment on deputation. Similarly, deputati oni sts shall not be e li gible for ,
consideration for appointment by promotion.
(Period of deputation including short-ten~1 contract includin g period of deputati on including sho11-te rm
contract in another ex-cadre post held immediate ly preceding this appointment in the sa me or some other
Organization or Department of the Central Government shall ordinarily not to ex ceed three years. T he
maximum age limit for appointment by Deputation Iiicluding Short Term Contract shall not be exceeding
56 years, as on the c losing date of receipt of applications)
i

Note: For the purpose of appointment on aeputation basis, the service rende red on a regu lar basis by an
officer prior to JS1 January 2006, the date from which the revi sed pay structure based on the s ixth Central
Pay commission recommendation has been extended, shal I be deemed to be service rendered in th e
corresponding grade pay or pay scale extended based on the recommendations of the Pay Com mi ss ion
except where there has been merger of more than one pre-revised scale of pay into one grade "v/th a
common grade pay or pay scale and where this benefit will extend only for the post(s) for w hich that
grade pay or pay scale is the normal re2lacement grade without any UQ gradation.
-- - -- -----·
App lication of only such candidates \Viii be considered which are routed through proper channe l and are accompanied by :
(i) Duly filled application in prescribed format. (ii) Photo copies of ACRs for last five years duly attested on each page.
Applications of eligible candidates can be spared immediately in the event of selection may be sent to The Director, Regional F odd er
Station, Suratga rh -335804 (Rajasthan) within a period of 60 days from the date of publication ofti1i s adverti'sement.
Direc tor ·

<!-- page 2 -->

PROFORMA~
1. G1Tcff /Name (Block letter)

2. ~ ~/Date of Birth :-

3. mcfiT'fr 'BclT ~ i;:rc)-~r cfi'l- ~ / Date of entry in Government service :-

4.·cki ~ $ ~ $' ~ flq lfc.lc[fct cfi'l- mtruJ :
Date of retirement under Central Goverriment Rules :

Educational qualification and training, if any :-

6. 'BclT c:fiT fclcRur; Details of service :

qc;- c:fiT c=rm

"fl"

Hc:fi

~~~~

Name of post

From

To

~ ~ }ITT ~

~cfi'l-~i
Jr~ fc.l-4 ff! a ;

fc:Bvan:r~

*'" ~ (~aw

"fc'R/ '

rl'c;& Nature of

~)

Basic pay and pay level
in the new pay matrix

appointment is i.e.
regular/Adhoc

Nature of duties
performed (in bri ef)

7.-a) cf~1;.J.Tfc'l Qc; c:fiT c-ITJf/ ·Nam e of Prese nt Post.held
b) 3-R=~/ cRf_; tfr.~~~
Whet her Temporary/Q.P/Permanent

. 8. ~ ~ 3ITT ~ c=rrt'mf "fl° ~ ~ 0lT lEJ

i

Present Pay and the date from which it are being draw
(8 ri c-l J-l ki ~ ~ fcnm 0lTcIT

i)

(Scal e of pay also to be indicated)

9. ~ V~R:flf(!fl°tT I 3-ITTfRfr c:fiT 'tr
Whether belongs to SC/ST/OBC

10. R:cqfal-41, m?; ~ tJ/ Remarks, if any

f=~/Station:

~/Date:

Signature of Candidate

<!-- page 3 -->

-

3-l<jJ.l)~c-1/ENDORSEMENT BY THE EMPLOYER

1,.1JJ1fu'la fcn<TT ~ E>" fu:> ~;~ ....... ...... ....... ...... ........... .. .. ...

oo ~ ;rrt:! ~ fucRUT

fl ,<-I 1fil <i fcn<TT ~ E>" }tR ~ mm .~ ~ I ~ :J.fr QJi Ifo1 c-l fcn<TT ~ ~ fu:> ~ furc>rrq:; ~
fl i:i Jic-1 I ~ ~ <TI ~ ~ fcn<TT "JT"ilT E," }tR ~ $Ji kl c:', Ifl

........... ... ................ .

Certifi ed that the above particu lars given by Shri/Smt. .. ...... ... .. .. .... ....... .. ...... . .. have been verifi ed and
fou nd to be correct. It is a·lso certified that no vigilance·case is pending or contemplated against him/her and that
hi s/her integrity is ..... .. .. .... ....... ...... . .... .

f~/Station:
~/Date:
~ ~ m~ ~1.tR'/ Signature with Seal
cfil<.l1i;>!<.1 ~/Head of Office
