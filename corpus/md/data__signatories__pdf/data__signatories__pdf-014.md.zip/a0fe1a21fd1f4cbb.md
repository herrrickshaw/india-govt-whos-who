---
doc_id: "a0fe1a21fd1f4cbb"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_68949256cf5db7.16716545.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order (II) - Transfer/posting of Shri Ravi Horo, IFS(AGMUT:1996) in the grade of APCCF to Mizoram segment in the Joint AGMUT Cadre, order dated 07.08.2025"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f88959ef06b663a0"
---

<!-- page 1 -->

C.No.134335
F.No. 46011/1/2019-IFS-1 (AGMUT)
Government of India
Ministry of Environment, Forest and Climate Change
Indira Paryavaran Bhawan, 6" Floor, Prithvi Wing,
Jor Bagh Road, Aliganj, New Delhi— 110 003.
Dated: August, 2025
छा

OFFICE ORDER (II)

The following transfer/posting in the grade of APCCF (Level-15 in the Pay Matrix
of Rs. 1,82,200 — Rs. 2,24,100/-) in AGMUT Gadre are hereby ordered with immediate
effect:

lame “an atch of the  officerPosi e in|
(Shri/Smt/Ms.) cadre
2. The above mentioned officer is requested to join his new place of posting
and submit his joining report with a copy to this ministry. »
2 ma Sh 7
3: This issues with the approval of the competent authority. (240०
3
(Prem (OX.
Under Secretary to the Government of India
Tele: 011-20819192
E-mail: ifs@nic.in
Distribution :
1. PS to Hon'ble Minister, Environment, Forests & Climate Change, New Delhi
2. PS to Hon'ble Minister of State, EF&CC, New Delhi
3. PPS to Secretary, (EF&CC), New Delhi /PPS to DGF & SS, MoEF&CC, New Delhi.
4. The Chief Secretary, A&N Islands Administration, Port Blair.
5. The Chief Secretary, Government of Goa, Panjim
6. The Chief Secretary, Government of Mizoram, Aizawl
7. The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
8. The Chief Secretary, Government of NCT of Delhi, Delhi
9. The Chief Secretary, Government of Puducherry, Puducherry.
10. The Chief Secretary, Govt. of UT of J&K, Srinagar.
11. The Adviser to LG, UT of Ladakh
12. The Administrator, Administration of Daman & Diu and Dadra & Nagar Haveli,
Daman.
13. The Administrator, Administration of Lakshadweep, Kavaratti.
14, The Administrator, Administration of UT of Chandigarh, Chandigarh
15. The Principal Chief Conservator of Forests and HoFF, Govt. of Arunachal Pradesh,
Itanagar.

<!-- page 2 -->

16. The Principal Chief Conservator of Forests and HoFF, Govt. of UT of J&K, Srinagar.
17. The Principal Chief Conservator of Forests, Government of Mizoram, Aizawl
18. The Principal Chief Conservator of Forests, A&N Islands Administration, Port Blair.
19. The Principal Chief Conservator of Forests, Government of Goa, Panaji
20. The Principal Chief Conservator of Forests, Government of NCT of Delhi, Delhi
21. The Deputy Conservator of Forests, UT of Ladakh
22. The Chiet Conservator of Forests, Administration of Daman & Diu and Dadra &
Nagar Haveli, Daman.
23. The Conservator of Forests, Puducherry, Puducherry.
24. The Deputy Conservator of Forests, Administration of Lakshadweep, Kavaratti.
25. The Chief Conservator of Forests, Administration of the UT of Ghandigarh,
Chandigarh.
26. Concerned officers/departments as mentioned above through \FS website.
27. AS (Admn.)/IGF (IFS), MoEF&CC.
28. Civil List (US, IFS-Il)/US (Vigilance Section)/ Guard File.
29. NIC Cell (Shri Irshad)- for placing on the IFS website. “
30. IT Division, MoEF&CC- for placing on the Ministry's website. (२222 A ) a
(Prem Prakash Maurya)
Under Secretary to the Government of India
Tele: 011-20819192
E-mail: ifs@nic.in
