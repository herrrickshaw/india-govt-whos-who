---
doc_id: "9f2fe7a79edc8c7e"
source_url: "https://doj.gov.in/static/uploads/2025/09/c90102201947470bc920604d68f29453.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of transfer of Shri Justice Ms. Anu Sivaraman, Judge, Kerala High Court as Judge of Karnataka High Court (18.03.24)"
date: "2024-03-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "009981bf76ee3ef3"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K. 11019/05/2024-US. I/II (ii)
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011.
Dated: 181 March, 2024.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 222 of the
Constitution of India, the President, after consultation with the Chief Justice of
India, is pleased to transfer Smt. Justice Anu Sivaraman, Judge, High Court of
Kerala, as a Judge of Karnataka High Court and to direct her to assume charge of
her office in the Karnataka High Court.

tla

44 el-

(Naraan Prasad)18.163)v°
Deputy Secretary to the Government of India
Tele: 23072149

To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2
No. K-11019/05/2024-US. I/II (ii)

Dated: 18.03.2024.

Copy to:1.

Smt. Justice Mu Sivaraman, Judge, High Court of Kerala through the
Registrar General, High Court of Kerala, Ernakulam.
2. The Secretary to the Governor, Karnataka, Bengaluru.
3. The Secretary to the Governor, Kerala, Thiruvananthapuram.
4. The Secretary to the Chief Minister, Karnataka, Bengaluru.
5. The Secretary to the Chief Minister, Kerala, 'Thiruvananthapuram.
6. The Secretary to the Chief Justice, Karnataka High Court, Bengaluru.
7. The Secretary to the Chief Justice, Kerala High Court, Ernakulam.
8. The Chief Secretary, Government of Karnataka, Bengaluru.
9. The Chief Secretary, Government of Kerala, Thiruvananthapuram.
10. The Registrar General, Karnataka High Court, Bengaluru.
11. The Registrar General, Kerala High Court, Ernakulam.
12. The Accountant General, Karnataka, Bengaluru.
13. The Accountant General, Kerala, Thiruvananthapuram.
14. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.
15. PS to the Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
16. Registrar (Conf.), o/o the Chief Justice of India, 07, Krishna Menon Marg,
New Delhi.
17. PS to the MoS, L&J wcy PPS to Secretary (Justice).
18. Sr. Technical Director, NIC, Department of Justice, with a request to
upload the notification on the website of the Department
(wvvw.doj.gov.in).

WIA

(Prem Chand)
Under Secretary (Appointments-I)
Tele: 2338 2978
