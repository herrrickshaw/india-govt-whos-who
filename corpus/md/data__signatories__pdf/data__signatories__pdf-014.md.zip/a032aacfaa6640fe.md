---
doc_id: "a032aacfaa6640fe"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/5c7bc2d002c16f611d7f081a597e5e2e.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification 19-07-1995"
date: "2025-07-04"
pages: 4
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7716ef5c2103de36"
---

<!-- page 1 -->

रजिस्ट्री सं. डी. एल .-33004/95 REGD. NO, D.L.--33004/95
2 25
és हु
Ms
Ge az =a CTsSGqA है
= Fe ers eT मबने
ee gs |.
0 हा है. गे Ge ;
CP 2 G tt te J é 1
wre bazete of India):
tat FS Dy flat ye
छः
असाधारण
EXTRAORDINARY
भाग 1--रूण्ड 3--उप-छण्ड (1)
PART H—Section 3—Sub-Section (ii)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
सं, 414] नई दिल्‍ली, बुधवार, जुताई कक 8/आषाद 28, 1917
No. 414] NEW DELHI, WEDNESDAY, JOLY 19, 1995/ASADHA 28, 1917
उद्योग मंत्रालय 2. परिभाषाएं :--इस aaa में, जब तक कि संदर्भ
(औद्योगिक नीति और प्रोन्नति विभाग) से सन्यता अपेक्षित न हो--
आदेश (क) समुचित प्राधिकारी” से अभिप्नेत है कोई ऐसा
$ दिल्‍ली अधिकारी, जो भारत सरकार के अबर सौ
नई दिल्‍ली, 19 जुलाई, 1995 आल गर्म मे ale ae ऐ ~~
* के रैंक से नीचे का न हो, या कोई ऐसा अधि-
का .झ्रा. 641(अञ्र).--केन्द्रीय सरकार, आवश्यक वस्तु कारी, जो किसी राज्य सरकार के जिला उद्योग
अधिनियम, 1955 (1955 का 10) की धारा 3 द्वारा केन्द्र के महाप्रबन्धक के रैंक से नीचे का न हो
प्रदत्त शक्तियों का प्रयोग करते हुए और भारत सरकार के और जिसे केन्द्रीय सरकार या राज्य सरकार
इस्पात ओर भारी उद्योग मंत्रालय (भारी उद्योग विभाग) द्वारा राजपक्न में प्रकाशित अधिसूचना द्वारा इस
के आदेश सं, का.आ. 3595/ईसी ए|2|62, तारीख 24 आदेश के उपबन्धों को कार्यान्वित करने के लिए
नवम्बर, 1962 को उन बातों के सिवाय अधिक्रांत करते नियुक्‍त किया जाए;
हुए जिन्हें ऐसे अधिक्रमण के पहले किया गया है था करने पा . हे fair
“ a ns “ x ख ब्यूयों से भारतीय मानक ब्यूरों ३ है,
का लोप किया गया है, निम्नलिखित आदेश करती है, व) ह॥ शत मत है
अर्थात्‌ :-- न (ग) “सीमेंट” से अभिप्रेत है भारत में विनिभित सीमेंट
हे हि an की कोई किस्म और इसमें वात्या भट्ठी धातुमल
जी 1. संक्षिप्त ti और बे an 1) ae आदेश का सीमेंट, पोर्टलेंड पात्सालाना सीमेंट, क्षिप्र कठोरन
कः आदेश 5 wide dic, Ba पोर्टलैंड सीमें:
anes नाम सी (क्वालिः नियंत्रण ) देश 1995 पोर्टलैंड , श्वेत पोर्टलैंड सीमेंट, जलविरोधी
al पोर्टलैंड सीमेंट, साधारण पोर्टलैंड सीमेंट, अल्प
(2) यह राजपत्न में प्रकाशन की तारीख को प्रव॒त्त ताप पोर्टलैंड सीमेंट, उच्च शक्ति साधारण पोर्ट-
होगा । लैंड सीमेंट, रेल-स्लीपरों के विनिर्माण के लिए
1722 GI/95 (1)

<!-- page 2 -->

eee राम परफकनन जनम कसम न+ नाना नमन सं नुसिमामम नम मकर
2 THE GAZETTE OF INDIA : EXTRAORDINARY (Part Ti—Sec. 3(ii)]

प्रयुतत सीमेंट, चिनाई सीमेंट, तेल कूप सीमेंट, समाधानानुसार है और भारतीय मानकों न की तत्संबंधी अपेक्षाओं

अति सल्फंटिक सीमेंट या सीमेंट की कोई अन्य से मेल नहीं खाता ॥

किस्म जो केन्द्रीय Sears See में अधिसूचना (2) ऐसा सीमेंट जो विहित मानक के अनुरूप नहीं है

हारा, इस प्रादेश के प्रयोजनार्थ विनिदिष्ट करे; तुरंत नष्ठ कर दिया जाएगा और उसकी समुचित प्राधिकारी

(घ) “विहित मानक” से अभिप्रेत है, भारतीय मानक की रिपोर्ट की जाएगी ।
नर कक Pes welt a aii _. 4. विनिर्माताओं का प्रमाणन :--(1) सीमेंट के विनि-

(=) “व्यौहारी” से अभिप्नेत है कोई व्यक्ति या कोई माता, ब्यूरो को, मानक चिह्त का प्रयोग करने के संबंध में
फर्म या कोई हिंदू अविभकत कुटुंब, जो, प्रत्यक्ष अनुअ्प्ति अ्रभिप्राप्त करने के लिए आवेदन करेंगे ।
रूप में या ग्रन्यधा सीमेंट का, चाहे नकद रूप ~ . है . .
में या आस्थगित संदाय के लिए अथवा कमीशन, (2) ब्यूरो द्वारा मानक चिह्न का प्रयोग करने es
aifestis at अन्य उचित प्रतिफल के लिए, अनुज्ञप्ति का दिया जाना भारतीय मानक ब्यूरो अधिनियम,
क्रय, विक्रय, प्रदाश था वितरण का कारबार 1986 के और उसके अधीन बनाए गए नियमों भ्रौर
went gam विनिथमों के उपबंधों के अनुसार होगा ।

(=) ote fas sn 4 _ विनिर्माता हि feat व्यक्ति, स्वयं या अपनी ओर से किसी व्यक्त की मार्फत,
है कोई व्यक्ति या कोई फर्म या कोई हिंदू सीमेंट का विनिर्माण करने के लिए प्रस्थापना करता
अविभकत बूटुंब, जो सीमेंट उत्पादित करता है, है तो वह ब्यूरो को उत्पादन के प्रारंभ से पूर्व आवेदन करेगा ।
बनाता है, सा विनिरमित करता है और इसके - s .
अन्तगंत ऐसा व्यक्ति या फर्म या हिंदू अविभकत (4) एक या अधिक सीमेंट के विनिर्माण के लिए
कुटृंब भी है, जो बथास्थिति, ऐसे व्यक्ति, फर्म किसी अनुज्ञप्ति के व्यपगत हो जाने या रद्द किए जाने या
या हिंदू अविभवत्त कुटुंव द्वारा सीमेंट उत्पादित या ब्यूरो द्वारा आवेदन के बंद किए जाने संबंधी सूचना
किए जाने, या विनिभित किए जाने, बनाए जाने प्राधिकारी को तुरंत भेजी जाएगी ।
का दावा करता है, . -

. oo . 5. भंडारण, विक्रय और वितरण का प्रतिपेध् :--कोई

(छ) “मानक चिक्ल से भारतीय मानक ब्यूरो भ्रधि- भी व्यक्ति स्वयं या उसके निमित कार्य करने वाले किसी
नियम, 1986 (1986 के 63) में इसे दिया गया व्यक्ति की मार्फत, ऐसे सीमेंट का, जिन पर ब्यूरो का मानक
अर्थ अभिप्नेत है, चिह्न तहीं है और जो किसी ऐसे व्यक्ति द्वारा जिसने इस

(ज) “राज्य सरकार” से संघ राज्य क्षेत्र के संबंध प्रयोजन के लिए पैरा 4 के अधीन यथाविनिदिष्ट अनुक्षप्ति
में, संविधान के अनुच्छेद 239 के ग्रधीन राष्ट्रपति प्राप्त की है, विनिभित नहीं किया गया है, विक्रय के लिए
द्वारा नियुक्‍तत संघ राज्य क्षेत्र का भ्रशासक है । संग्रह, विक्रय या वितरण नहीं करेगा ।

3. ऐसे सीमेंट के विनिर्माण, विक्रम और भंडारण के 6. जानकारी मांगने की शक्ति :--समुचित प्राधिकारी,
के संबंध में प्रतिषेध जो बिहित मानक का न हो--(1) इस आदेश का अनुपालन सुनिश्चित करने की दृष्टि से॥-+-
कोई भी व्यक्ति, स्वयं या अपनी ओर से किसी व्यक्ति
की मार्फत, ऐसे सीमेंट का, जो विहित मानकों के अनुरूप नहीं है (क) सीमेंट के विनिर्माण, विक्रय के लिए भंडारकरण,
aie far qe ad at ama faa a हो, विनिर्माण या विक्रम या वितरण में लगे किसी व्यक्ति से ऐसी
विक्रय के लिए भंडारण, विक्रय या वितरण नहीं करेगा : जानकारी, जो वह इस आदेश को. कार्यान्वित

परंतु केन्द्रीय सरकार, आवेदन किए जाने पर, किसी करने के लिए सीमेंट के विनिर्माण, विक्रय के लिए
व्यक्ति को, मानक चिह्न रहित सीमेंट के विनिर्माण या भंडारकरण, विक्रय या वितरण के संबंध में
विक्रय के लिए भंडारण या विक्रय या वितरण के लिए, आवश्यक समझे, देने की अपेक्षा कर सकेगा या
एक सौ बीस दिन से अ्नधिक के लिए अनुज्ञात कर सकेगी, किसी ऐसे व्यक्ति से उसे ऐसे सीमेंट के नमूने
यदि उसका समझ्ल्‍र्धात हो जाए कि विनियमित मानक चिह्न - देने की अपेक्षा कर सकेगा ।
का . अनुदान भारतीय मानक ब्यूरो अधिनियम, 1986 के (ख) ऐसे सीमेंट के विनिर्माण, विक्रम के लिए भंडार-
अधीन प्राविकारियों के पास लंबित है । करण, विज्नय या वितरण में लगे किसी व्यक्ति

परन्तु यह और कि केन्द्रीय सरकार, आवेदन किए जाने द्वारा रखी गई या उसकी था उसके कब्जे में
पर, मानक चिह्न से छूट दे सकती है यदि उसका समाधान की या नियंतक्रणाधीन किन्‍्हीं बहियों या अन्य दस्ता-
हो जाएं कि विनिभित और प्रेषित सीमेंट निर्यात के प्रयोज- वेजों या अन्य सीमेंट का सिरीक्षण कर सकेगा
नार्य है और विदेशी मानकों के अनुसार है या क्रेता के या करा सकेगा ।

<!-- page 3 -->

{art 11—eve 3(ii)] भारत का राजपत्न : असाधारण a
(व) पैरा $ के अधीन सम्यकत: प्राधिकृत किसी अधि- ? 13. अपील-- (1) समुचित प्राधिकारी के किसी
कारी को ऐसे परिसरों में प्रविष्ट करा सकेगा विनिश्चय से व्यथित कोई भी निर्माता या व्यौहारी, ऐसा
ओर उसकी तलाशी करवा सकेगा जिनकी बाबत विनिश्चय संसूचित करने वाले श्रादेश की प्रति की उसके
यह विश्वास करने का कारण है कि इस आदेश द्वारा प्राप्ति की तारीख से तीस दिन के भीतर लिखित रूप
का उल्लंघन किया गया है या उक्त सीमेंट विहित में केन्द्रीय सरकार को अपील कर सकेगा :
मानक की नहीं है, उस सीमेंट का अभिग्रहण — ~
ae ’ “ we Sele qo, war अवधि की समाप्ति
करा सकेगा, और — 7 alii a
7 पश्चातू कोई अपील उस दशा में ग्रहण कर सकेगा! जब उसका
(घ) दंड ilar 1973 (1974 का 2) यह समाधान हो जाता है कि अपीलार्थी नियत समय पर
oF mre अभिग्रहण से संबंधित धारा 100 अपील फाइल करने से पर्याप्त कारणों से निवारित हो गया
के उपबंध, om तक दम सके, किक पैरा के att
जधीन तलाशी और अधिग्रहण को लागू होंगे । ete a ps
पर. नमूनों का परीक्षण--मानक चिह्न वाले और समुचित (2) नेल्द्रीय सरकार, उपपैरा (1) वे! अधीन अपील
प्रांध्कारी * लिए feck सीमेंट LNs की प्राप्ति पर, अपीलार्थी को सुनवाई का अवसर देने के
गरी द्वारा लिए गए किन्दीं सीमेंट के नमूनों का यह पश्चात्‌ ऐसा आदेश पारित कर सकेगा जो वह ठीक समझे।
अभिनिश्चित करने के लिए कि क्‍या वे विहित मानक के ==
हैं, ब्यूरो द्वारा अनुमोदित प्रयोगशाला में और ब्यूरो द्वारा फिा. सं. 1(4)|94-सीमेंट]
अवधारित रीति से परीक्षण किया जाएगा । प्रतिभा करत, संयुक्त सचिव
8. शक्तियों का प्रत्यायोजन--समुचित प्राधिकारी, 7
कि eves gee TA मे विशेष 3 हे लिखित MINISTRY OF INDUSTRY
में किए गए साधारण या विज्ञेष आदेश द्वारा किसी भी . . .
मरे उसकी ओरो आदेश के ही रे {Department of Industrial Policy and Promotion)
अधिकारी को उसकीओर से इस आदेश के अधीन अपने सभी ORDER
या किनन्‍्हीं कृत्यों का पालन करने के लिए प्राधिकृत कर Ree ean है एयर पड़
सकेगा New Delhi, ihe 19th July, 1995
केगा
— 7 a . fi S.0. 641(E}—In exercise of the powers conferred by Section
परंतु ऐसा अधिकारी को जो राजपक्वित रैंक का नहीं 3 of the een Capoten Act, 1955 (10 of 1985) and in
है; c धकारी 5. 6 के खंड > oh supersession of the Order of the Government of India in the
हैं; समुचित प्राधिकारी द्वारा पैरा 6 के खंड ग के अधीन Ministry ot Sie and Heavy Industries (Department of Heavy
तलाशी और अधिग्रहण की शक्तियों का प्रयोग करने के लिए industries) No. S.O. 3595/ECA|2|62 dated the 24th November,
तलाशी और अ्भिम्रहण की शक्तियों का प्रयोग करने के लिए 1962, except as respects things done or omitted to be done
प्राधिकत किया जाएगा | before such supersession, the Central Government hereby makes
the foliowins Order. namely :—
9. विनिर्माताओं और व्यौहारियों को निदेश देने की 1. Short tile and commencement.--(1) This Order may be
झक्ति : समृषित प्राधिकारी, विनिर्माताओं और व्यौहारियों called the Cement (Quality Control) Order, 1995.
को ऐसे निदेश दे सकेगा जो इस आदेश के उपबंधों से संगत (2) It shall come into force on the date of its publication in
हों और इस आदेश के उपब्रंधों को कार्यास्वित करने के लिए ee
प्रौर इस आदेश के उप गर्यान्वित करने के
आवश्यक हों । Fen शान this Order, unless the context otherwise
10. निदेशों का अत पालन--किसी सीमेंट के विनिर्मा (a) “Appropriate Authority” means an officer_not below
कर का et अनूपालेन---किंसी सीमेंट के विनिर्माण; the rank of an Under Secretary to the Government
विक्रय के लिए भंडारकरण, विक्रय या वितरण में लगा of India or an officer not below the rank of a General
प्रत्येक व्यक्ति se 5 न्‍्वीन कोई निदेश Manager, District Industries Centre of a State Gov-
त्येक व्यक्ति, जिसे पैरा 9 के अधीन कोई * दिया गया ernment as may be appoined by the Ceniral Govern-
है, ऐसे निदेश का अनपालन करेगा ment or the State Govermments by a notification
, ऐसे निदेश का अनुपालन करेगा । published in the Official, Gazette to implement the
11. जानकारी देने की बराध्यता--कोई भी विनिर्माता Provisions of, this Order;
या व्यौहारी, इस आदेश के उपबंधों से बचने के आशय से, (b) “Bureau” means the Bureau of Indian Standards;
हारी, इ दे ४ i ,
a 2 न ape aE (c) “cement”? means any variety of cement manufactured
पैरा 6 के अधीन उससे मांगी गई कोई जानकारी देने से in Tia and includes blast furnace slag cement, port:
कार कर ही ऐसे हर के and pozzolana cement, rapid hardening —portlan
न तो इंकार करेगा, न ही ऐसे व्यवित द्वारा रखी गई या cement, white portland cement, hydrophobic portland
उसके कब्जे में की या नियंत्रण में की किन्‍्हीं बहियों या cement, ordinary portland cement, low heat portland
a किस सीमे . ue cement. high strength ordinary portland cement,
aeqrast at fea} Ae को छपाएगा, नप्ट करेगा, विकृत cement used for the manufacture of railway sleepers,
था विरूएत करेगा। masonry cement, oil well cement, super sulphated
at elas FUT cement or any other variety of cement which — the
लंघन के लिए शा anf Central Government may, by notification in the Offi-
12. उल्लंघन के लिए शास्ति--वह व्यव्रित, जो इस cia! Gazette. specify for the purposes of this Order;
आदेश के उपबंधों में से किसी का उल्लंघन करेगा या उसके {d) “prescribed standard” means the Indian Standard Spe-
ae - कार्यान्वित ification of cen ctibed by th -
anita fem am किसी निदेश या अध्यपेक्षा को कार्यानि हज 71 prescribed कं
करने में असफल होगा, दंडनीय होगा, और वह संपत्ति, fe) “dealer” means a person who, or a Sim or Hindu Un-
जितकी वाबत आदेश का उल्लंन किया गया है, आवश्यक divided Family which carries on directly or otherwise
हे की the business of buying, selling. supp!ving or d’siribyt
बस्तु अधिनियम, 1955 (1955 का 10) की धारा 7 ‘ng cement, whether in cash or for deferred paymen:
के भ्रधीन समपहरण किए जाने' के दायित्वाधीन होगी । of for commission, remuneration of otber valuable

<!-- page 4 -->

4 THE GAZETTE OF INDIA : EXTRAORDINARY [Parr li—Szc. 3(ii)]
(D “manufacturer” in relation to cement, means a person (b) inspect or cause to be inspected any books or other
who or a firm or Hindu Undivided Family which, documents or cement kept by or belonging to of in
produces, makes or manufacturers cement and inclu- possession or under the control of any persan eagaved
cies a persn who, or a firm or Hindu Undivided Family in the manufacture, storage for sale, sale or dietriou
which, claims Fa cement to be produced, made or, tion of such cements
manufactured by any such person or firm or Hindu _ i
Undivided Family, as the case may be; © cause an oficer duly authorised under paragraph 8 to
us है है enier and search any premises and seize cetnent in
) न a : has. ae > meaning assigned to it in the respect of pia it has reason to believe that a conira-
ureau of Indian Standard Act, 1986 (63 of 1986): vention of this Order has been made or the said
(h) “State Gvernment” in relation to a Union territory Sr ed ee lee a
means the Administrator of that Union iertitory ap- (d) the provisions of section 100 of the Code of Criminal
pointed by the President under Article 239 of the Procedure, 1973 (2 of 1974) relating to search and
Constitution, peice shall, so far as may be. applied to searches
आप hig manufacture, sale and store of cement किए जग पदक 38 नी की
which is not of the prescribed standard—(1) No person shall 7. Testing of Samples——Samples of ८ cis
himself of by any’ pereon on his behalf, manufacture or sore Standard Mask and raven by ihe Appropriate Aurore, for
pal sale necit or. go out which does not conform to ascertaining whether they are of the prescribed standard, shall
th ‘preserited standard and which do not bear the standard be (ested in the laboratory approved by the Bureau and in

‘ark t the manner as may be determined by the Bureau.

Provided that the Central Gi ica 8. Delegai न नि
a _ Delgaion of powers—the ety nay
अधि: या dell or dittclbute cement wi = by general or special order in writing authorise any officer

¢, or sell or distribute cement without Standard Mark for a io exorcise on ils behalf all fits oti J
period of not exceeding one hundred and twenty days, if it is Cae eae ee Fanchions ‘wader’ ihe
satisfied that the grant of regular Standard Mark is pending mers
With the uthorities under the Bureau of Indian Standards Act, Provided that no officer who is not of a Gazetted rank, shall

86: be authorized by the Appropriate Authority to exercise the

Provided fupriiier that the Centrat Government aay, on an owers of search and seizure under Clause (c) of paragraph 6.

lication made, #1 xempti m fark, i j ‘recti
application made, grant exemption i a Standard Mark, if it 9. Power to issue direction to manufacturer and dealer —
is satisfied that the cement manufactured and despatched is The A; ji ‘i a Reacts
| मन हे i i The Appropriate Authority may issue such directions to manu-
lot export, purpose and is ai per the Overseas Standards or as facturer and dealer, consistent with the provisions of — thi
per Buyer's Speci" cations and do not coincide with the corres- iden lastmiay bel anccksanyetor cares isis Of
ponding. रत ct the Indias Standards Cider. as may be necessary for carrying out the provisions of

(2) The cement which do not conform to ihe prescribed stand- : er हे
ard sho!l be destroyed immediately with a report to the Appro- 10. Compliance of direction—Every person engaged in the
priate Authority. manufaciure, storage for sale, sale or distribution of any

im cement, to whom any direction is issued under paragraph 9

4. का तार of Mamafacturers.—(1) the manufacturer of shall comply with such directions. पु
cement shall make an application to the Bureau for obtaining
Ce EE ee ornare Maa pig onal nak produce the 11. Obligation to furnish information.——No manufacturer

‘ _ = or dealer shall, with intent to evade the provisions of this

(2) The grant of licence by the Bureau for use of the Stand- Order, refuse to give any information called from him under
ard Mark shall be as per provisions of the Bureau of Indian paragraph 6 conceal, destroy, amtilate or defies anv Fooks
Standards Act, 1986 and the rules and regulations made there- or documents or any cement kept by, or in the possession
under. or conrol of such person.

_@) When any person by hinwelf or through any person va 12, Penalty for contravention—Any person who contraven-
his behalf proposes to manufacture cement, he shall make es any of the provisions of this Order or fails to carry out
an application to the Bureau before the commencement of any direction or requisition made thereunder shall be punish-
production, able, and the property in respect of which the order bas been

4) Information relati 1 anecinion wfeny licen. contravened shall be liable to forefeiture under section 7 of
colt) formation rating eae of caneelovon of oy Keen; fhe seal" Commodities Act 1985 00 of 1958)
one or more of the cement shall be sent to the Appropriate a
Authority immediately. 13. Appeal—(1) Any manufacturer or dealer aggrieved by

पु है | any decision of the Approviate Authority may prefer an anneal

5. Prohibition of storage. sale and distribution —No person in writing to the Central Government within thirty days from
by himself or throug any person acting on fie, हक shall the date ot Tees by him of the copy of the Order communi-
store for sale. sell or distribute any cement which does not cating such decision.
bear the Standard Mark and which has not been manufactured
by a person who has obtained a licence for the purpose as Provided that the Central Goveernment may entertain an
specified under paragraph 4, eppeal after the expiry of the said period of thirty days if it

| : i . 7 sate is satisfied that the appellant had sufficient cause for not pre-

Aa Power io all for intormation—The Appropriate Aatho- fering the appeal within the period of thirty days.
rity may. with a view to secure compliance w/ is Order:—

a) i i facture, sI (2) On receipt of the appeal under sub-paragraph (1), the
0 ee engaged in the खा व के storie Central Government may, after giving the appellant an oppor-
nina ae te deces TRGeeiay th Tn velation to the tunity of being heard, pass such order as it may deem fit
manufacture, storage for sale, sale or distribution of
cement for the implementation of this Order or re- LF. No. 1(4)/94-Cement.|
quire any such person to furnish to it samples of such
cement; हि है PRATIBHA KARAN, It. Secy.
Printed by the Manager, Govt. of India Press, Ring Road, Maya Puri, New Delbi-110064
and Published by the Controller of Publications, Delhi-110054. 1995 .
