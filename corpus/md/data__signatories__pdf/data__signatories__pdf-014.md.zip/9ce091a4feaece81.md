---
doc_id: "9ce091a4feaece81"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/6a529f9bba596fafb6ea6eb80cc17558.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 10.02.2025: Extension of terms of Counsels appearing in the Order dated 03.03.2022 for various Courts in the State of Maharashtra"
date: "2025-02-10"
pages: 24
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8243507189317ae6"
---

<!-- page 1 -->

F. No. J-11017/5/2025-Judicial (2)
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
oR
Shastri Bhawan, New Delhi,
Dated the 10" February, 2025
ORDER
With reference to this Department's Order No. J-11017/5/2022-Judicial dated
03.03.2022, regarding engagement of Advocates for High Court of Bombay (PB) at
Mumbai and its Bench at Aurangabad, Central Administrative Tribunal, Mumbai Bench &
it’s Circuit Bench at Nagpur, National Green Tribunal (Western Zone) at Pune and various
District & Subordinate Courts in the state of Maharashtra, the President is pleased to
extend the terms of all the panel counsel whose names are figuring under Lists ‘A’, ‘B’,
‘C’, ‘D’, ‘E’ &‘F’ in the aforesaid order dated 03.03.2022, except the Advocates who have
already been removed/ resigned/ expired as the case may be, for a further period of six
months with effect from 03.03.2025 or until further orders, whichever is earlier.
2. The engagement and professional fee of the aforesaid counsel will be governed by
the terms and conditions contained in this Department’s O.M. No. 23(2)/2001-Judl. dated
14.05.2001, No. 26(1)/99-Judl. dated 24.09.1999 and No. 27(11)/99-Judl. dated
24.09.1999 all to be read separately with OM No. 26(1)/2014/Judl. dated 01.10.2015 &
instructions issued subsequently through OMs specially the OM No. J-16/11/2017-Judicial
dated 08.02.2018 imposing certain restrictions on panel counsel. The aforesaid OMs are
available on the official website of this Department i.e. www.|legalaffairs.gov.in in the tab
‘Judicial Section’ under heading ‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow. ee,
@< Ss
10 vod
(Madhab Charan Prusty)
Senior Government Advocate
Copy (through email) to:-
1. PS to Hon‘ble MoS (I/C)L8J.
2. PSO to Law Secretary/ Additional Secretaries in the main secretariat of Department of Legal
3. The Incharge, Branch Secretariat at Mumbai.
4. Sh. Nandesh S. Deshpande, Deputy SGI, High Court of Bombay, Bench at Nagpur.
5. Sh. Ajay Gajanan Talhar, Deputy SGI, High Court of Bombay, Bench at Aurangabad.
6. Sh. Pravin Nilkanth Faldessai, Deputy SGI, High Court of Bombay, Bench at Goa.
7. The Registrar, High Court of Bombay, (PB) at Mumbai and Bench at Aurnagabad.
8. The Registrar, CAT, Mumbai Bench & its Circuit Bench at Nagpur.
9. The Registrar, NGT, Western Zone Bench at Pune.
10. LIMBS Section for information and necessary action.
11. To upload on the website of this Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial
Section’ under the link ‘Orders related to empanelment of Advocates for Union of India’.
12. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
13. Office/Spare copies.
lezen
1527:
(Kumar Gaurva)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic,in

<!-- page 2 -->

F. No. J-11017/5/2022-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated 3% March, 2022
ORDER
With reference to this Department's earlier Order No. J-11017/21/2018-
Judicial dated 17.08.2018 regarding engagement of Advocates for High Court of
Bombay (PB) at Mumbai and its Bench at Aurangabad, Central Administrative
Tribunal Mumbai Bench & its Circuit Bench at Nagpur, National Green Tribunal
(Western Zone) at Pune and various District & Subordinate Courts in the state of
Maharashtra, the President is pleased to extend the terms of all the counsel
figuring in the aforesaid order dated 17.08.2018 with effect from the date of
expiry of their terms i.e. 17.08.2021 upto 02.03.2022.
2 The President is also pleased to engage following Advocates for
conducting Central Government litigations (except Taxation matters) before the
High Court of Bombay (PB) at Mumbai and its Bench at Aurangabad, the Central
Administrative Tribunal Mumbai Bench and its Circuit Bench at Nagpur, National
Green Tribunal (Western Zone) at Pune and various District & Subordinate Courts
in the state of Maharashtra, as mentioned under List ‘A’ to ‘F’ below, for a period
of three years with effect from the date of this order or until further orders,
whichever is earlier:
List ‘A’
HIGH COURT OF BOMBAY (PB) AT MUMBAI
5. [Name of Contact details खा
No | Advocate (S/Shri pO 2
Senior Counsel Group - I
14, Harbour View, Mather Pakhadi Road,
हि Mazgaon, Mumbai — 400010.
Avinash J. Rana Mob: 9820131410 MAH/104/1953
Tel. 022-23731270, 23750237
Sanawala Building, 2" floor, 19, Bank
2, Beni M. Chatterjee | Street, Fort, Mumbai- 400023. MAH/1042-A/1977
Mob: 9820298615
Dr. Poornima 73/63, Mehrdad, Cuffe Parade, Mumbai —
12, 277 FLOOR, Western India House,
6 17, Sir P.M. Road, Fort, Mumbai —
4, .R. Sharma 400001.Mob.9819234064 MAH/851 /1983
email: doctorlaw.india@gmail.com
iia em peat Cabin No. 12, 2" House, Examiner Cross
cole किला लि Building, Ballard Street, Fort, Mumbai- MAH/1082/1994
400001 Mob.9820061601
; Bes

<!-- page 3 -->

Sheel Chambers, 2 floor, 10, Cawasji
Patel Street, Fort, Mumbai — 400001
Pradeep S. Jetly Mob.9820089868 MAH/890/1986
email: pradeepjetly@hotmail.com
Oval house, 7" floor, British Hotel Lane,
Prasad Nagindas Master Road, Opp. Commerce H/

Is Dakhephalkar House, Fort, Mumbai. MAB कि 6 0

Mob:9820043405

Rajendra B. 1502/B, “Sukhada’, Sir Ponchkhawala

Raghuvanshi Road, Worli, Mumbai-400030 MAH/1138/1981
Mob:9422293000
Sai Prasad building, Flat 802, Service

“

— 400051. Mob:9821062438
Apte Rughnalaya, Ram Maruti Road,

Ramchandra Cross Lane No.1, Naupada, Thane (W) — ta पा

Shantaram Apte 400602 Mob: 9869005795 Advocate)
Tel:022-25337270
6, Owners Court, ogal Lane, Mahim,

7 Behind Mahim Bazar Post Office, Mahim,

Sarai Mumbai-400016. MAH/170/1962
Mob,9820006728 Tel: 24379078,
24212357
Flat # 503, 5" floor, ‘A’ Wing, Mahavir

Rui Adellino Towers, Off Dr. E. Moses Road, D.S.

12. | Rodrigues Marg, Worli, Mumbai - 400018. MAH 57/1990
Mob.9821266054
5A, Sindhu House, 3/5 Nanabhai Lane,

13, | Shyam Mehta Fort, Mumbai-400001. MAH/954/1999
Mob. 9820038287
10A, Tamrind House, Tamrind Lane,

Fort, Mumbai-400001.

enue Mob. 9869033847, 9820146525 Tel. 022- | _MAH/1301/1990
22664215, 22695097
401,Godavari sadan, kashinath Dhuru
Mumbai-400028, Mobile-9869286838
204/402, 2" & 4" Floor, Rehman House,

Abhay Sadanand Nadirsha Sukhia Street, Fort, Mumbai-

Khandeparkar 400001. Mob:9820144734 शीट व नि
Tel: 022-22874589/90
Dhun Apartment, 13" floor, 66, Worli

: Hill Road, Mumbai-400018 Mob: H/

17. | Advait M. Sethna 9892462945 MAH/1805/2000
email: advaitsethna@gmail.com
15, Mayur, 377, VP Road, Girgaum,

Mrs. Anjali Neel 38 10000
Hélekar Email:anjalihelekar@yahoo.com (M)- MAH/1871/1995
9869044978
Tel: 022-238886778
D2/201, Krishna Kaveri, Lokmanya Tilak
Marg, Yamuna Nagar, Andheri (W),

19. कक Mumbai — 400053. MAH/1445/1981
Mob:9821246902 Tel:022-26327432
email:Sharma.bbs@gmail.com

Sy

<!-- page 4 -->

Balkrishna 4/5, Samadhan Lokmanya Tilak Road,
20; Dattaraya Joshi Mulund (West), Mumbai. ele
Chitalia House, 1* floor, Near Paris
Bakery, 274, Dr. Cawasji Hormasji Street,
21. | Bharat H. Mehta Behind Parsi Dairy, Princess Street, MAH/988/1978
Mumbai — 400032. Mob: 9819063301
Tel: 022-22071328
18, Anand Bhawan, Subhash Nagar,
Asalpha Ghatkopar (W), Mumbai —
22. | D.N. Mishra 400084 Mob:9869066199, Tel:022- MAH/1176/1982
25168521
email: mishradeepnarayan@hotmail.com
New MHADA Colony, 25E, Flat No. 101,
; | Opp. NNP-1, Film City Road, Goregaon
23, tig Avadhraj | (&), Mumbai — Mob:9819167539 MAH/1872/1991
Tel:022-28413755
email:dashrathdube@gmail.com
मय वाया
24. | Deepak Thakre —7, Kharghar, Navi Mumbai MAH/1269/1987
Mob: 9820056926
1-4, Shree-Nalanda, Ghantali Devi Path,
Ganesh Krishnaji Naupada, Thane-400602
25. | Sovani ”* | Mob:9820928507, Tel:022-25336043 MAHL pa/iobe
Email: ganeshsovani@hotmail.com
Flats 210/211, Sangeet Complex Building
Gulabchandra R. No. 10/C, Jesal Park, BhaYANDER (e),
26. | Dwivedi Dist. Thane - 401105 कक 2712]
Mob:9322764235 Tel:022-69533479
Sameer Building, Opp. Maruti Temple
Road, #16, Sion (E), Mumbai — 400022
27. | Hasmukh V. Mehta | Mob: 9867385520 Tel: 022-24075944 MAH/135/1964
Email: hasmukhmehta80@gmail.com
Mittar Sain Mob: 26249859, 9322182172 HI
be Se PRT a
Orchid Residency, Tower 10 (Teak), Flat
No. 1404, Next R.City Mall, L.B.S. Marg,
29. baie Madubala K. | Ghatkopar (W), Mumbai — 400086. Mob: | MAH/1013/1982
9820091301, 9323901723
email madhubalakajle@yahoo.com
Flat No. # 401, Building A-1, Shichhaya,
Gilbert Hill Road, Andheri (E), Mumbai —
90:-| ee 058 MAH/2332/1998
Mob. : 9870419389
Tel No. 022-26209477
ace 15, Mayur, 377, VP Road, Girgaum,,
Mob: 9820378297 Tel: 022-238886778
Shriniketan CHS Ltd. Ground Floor, Flat
#2, 14 MLK. Road, Marine Lines, Cross
Road, # 2, Behind Commissioner of
Mrs. Neeta V. Central Excise Building, Churchgate,
oe: Masurkar Mumbai-400020 : . MAH/1137/1982
Mob: 9869005744 Tel: 022-22071361
email; adv.neeta.masurkar@gmail.com
: ae

<!-- page 5 -->

3, Esperance, ‘D’ Monte Lane, Orlem,
Nirmechkant R. Malad (W), Mumbai — 400064. Mob:
33. | prajapati i 9324154853 Tel: 022-28813320 MAH/970/1989
rajapati te gens ma हर
email: nirmeshkantp@gmail.com
ee Off 323, Shramjivan, B-5, Wadala Truck ra ae
terminus, Opp. New Cuffe Parade,
Wadala (E), Mumbai — 400037.
34, | P.M. Palshikar Mob: 9820085036 Tel: 022-65063566, MAH/S569/1983
24046794
email: pmpalshikar@gmail.com
Shop No. 12 & 13, Ground Floor,
Diamond Mansion, Dr. Viegas Street,
35. | Parag Vyas Corner of Kalbadevi Road, Mumbai — MAH/3829/2003
400002.
Mob: 9820152279, 7738616787
1/C/19, Silver Valley, Chatrapati Shivaji
; डर Marg, Vakola, Santacruz (E), Mumbai —
36. a ent 400055 Mob: 9821580635 MAH/085/1985
Tel: 022-26680211 email:
urniawasthi@gmail.com
104-Sea View Palace, 48-Pali Hill,
Rajesh Ghanshyam | Bandra (W), Mumbai — 400050. Mob: H/
37. | Singh 9820061970 022-26482362, 26442942 MATIES2 6/1995
email: legalliaisons06@yahoo.in
402, Sitaram Apartment, Charkop, Sector
~II, Plot # 120, Kandivali (W), Mumbai — H/
38. | Rutuja A. Ambekar | 400067. Mob: 9324088995 MAH/1360/1994
Tel. : 022-28695812
Flat No. 403, Building No. 29, Sanskruti,
90 ft. Road, Thakur Complex, Kandivili
39, | Sajan Oommen (E), Mumbai -400101 MAH/1374/1988
Mob: 9819806809 Tel: 022-28546409
email: sajanoommen@hotmail.com
Sandesh Dadasaheb | 215, Commerce House, Nagindas, Master
Road, Fort, Mumbai 022-66666648 MAHIA250,1999)
301, J.P. Residency, Chincholi Bunder
. ‘ Road, Near Kingston Complex, Malad
41. oa (WW), Mumbai - 400064 MAH/3197/2001
e Tel: 022-28775118 email:
adv.sanjeev@yahoo.co.in
Flat #1, Mez Floor, 56, Pedder Road,
Shenaz Vipsy Mumbai — 400026
42. | Bharucha Mob:9821332584 Tel: 022-24031655 MSHS IHOEE
email: svbharucha@gmail.com
4/51, Sardar Nagar-4, Sion-Koliwada,
Mumbai — 400037. H/
लत कम १०७: 9323972486 1७:022-24031655 जि 23119317
email: skthakur2@yahoo.com
63, Podar Chambers, SA Brelvi Road,
हु Fort, Mumbai — 400001. Mob:
age | ou 7666787766 MAH/1026/1991
Halwasia के बन i
email: halwasiaco@gmail.com
aS

<!-- page 6 -->

5/18, Ahmed Sailer Building, S.J. Marg,
Vaishali Mukund Near Hind Mata Cinema, Dadar, Mumbai
45. | Choudhari — 400014 Mane
Mob: 9821932716 Tel: 022-24124640
“Nawab Building”, 2" floor, D.N. Road,
= न Opp. Thomas Cook, Mumbai — 400001

46. | Vijay H. Kantharia | sob, 9332201919 Tel: 022-22042006 pee?
email: vijaykantharia@rediffmail.com
Mistry Mansion, First Floor, 107, M.G.

Rajshekhar Road, Hutatma Chowk, Fort, Mumbai- .

47. Vinayak Govilkar 400023 Mob : 9820151202 MAH/648/1975
Tel:022-22670173
email:contact@govilkarandassociates.in

161/A, Topiwala Building, Dr. Ambedkar
Yogendraprasad R. Road, Parel, Mumbai — 400012. Mob:

48. | Mishra 9892123507 MAH/1641/1987

Tel:022-24115193 email:
rmishra@hotmail.com

OM Dnyanesh Coop. Housing Society
Ltd. Flat # 17, Third floor, $.G, Bharve

Yogeshwar Marg, Kurla (W), Mumbai — 400070

Shivnath Bhate | Mob: 9920473770, 9869073770 Tel:022- | MAH/955/1989
26500508
email: yogeshbhate@yahoo.co.in
58, Shanti Sadan, Shivaji Park, Dadar,

; Mumbai — 400028

50. | Aditya Thakkar | fon: 9821534225Tel: 022-22821427 BSH? 2Upl2 000
email:aat273@gmail.com
4/34, Tardeo A/C Market, Tardeo Road,

Mumbai-400034.

51. | Ashok D, Shetty Mob:9821039980, 9820137387 Tel: 022- MAH/1454/1982
23520472, 23521890
email:adshetty5 1 @yahoo.com
L-4/54, Prinita Housing Society, Near

Narendra i
Cc Shahu College, Laxminagar, Pune-411009
‘alimbe १ ni ‘
email:ncwalimbe@gmail.com
21, 2" floor, Gitanjali Building, Near
; Radio Club, Colaba, Mumbai — 400005.

54, | Naveena Kumai Mob:9702058819, 9322358819 MAH/1016-B/2003
email:advnaveena@hotmail.com
105, Bhiwandiwala Building, Next to
Dist. Court, above Axis Bank, Court

Prakash Gajanan Naka, Thane (W), Maharashtra, PIN —

55. | Hartalkar 400601. MAH Cra]
Mob:9869005671
email:prakashhartalkar@yahoo.com

Ravindranath R, B-4-28, M.I.G. Colony, Gandhi Naar,
Bungalow No. 18A, Miniland Bungalows,
gate No. 4, Tank Road, Bhandup (W),

57. | Shardul Singh Mumbai — 400078. MAH/2795/2008
Mob:9619140001 Tel:022-22657354
email:shardulsingh@hotmail.com

=

<!-- page 7 -->

Dr. Birendra Saraf_| Mob: 98310087982 MAH/259/1996
C-103, Chamunda CHS Ltd. Talkalwadi,
Uma Kshirsagar Mahim, Mumbai — 400016
% | Wagle Mob:9820057325 Tel:022-24373438 अं मन
email:uklegal@rediffmail.com
Smt. Shuchi Mob:7666587778 MAH/1103/1991
Halwasia
C/3/30-Saifee Mazil, Kennedy Bridge,
G Opera House, Girgaon, Mumbai- 400004
61. | Vasant S. Gokhale | 1154, 9769323663, 9821863675 MAH/599/1975
email:vasant.gokhale1952@gmail.com
0141, Kohinoor City, Kirol Road, Off.
L.T. Satelkar L.B.S. Marg, Kurla West, Mumbai —
62, 400070 Mob:9821012726 MABHLTT/L987
1501, Deep Tower, Lokhandwala
Complex, Opp. Greenpark, Off.
099 Agee batieskah— |) uate andnes CW): Mumbal— MAHV/3082/2007
Mob: 9820333484
1, Nanji N iwas, 7" Kasturba Road,
Borivli (E), Mumbai — 400066 Tel:022-
64. | Amrendra J. Mishra | 28058579, 28614889 MAH/2564/2003
email:ajmishra009@gmail.com
B-402, Yogmudra Parag Nagar, Near
New Link Road, Dahisar (E), Mumbai —
65. | Anil D. Yadav 400068 Mob:9833185577, 9022677666 MAH/815/2005
email:anildyadav5680@yahoo.co.in
A-11/17/18, Mayursadan, Nenewadi,
Aniruddha Arun Waldhuni, Kalyan — 421301
Garge Mob:9820244123 Tel: 022-22625356 MAHI?
Off No. 75/76, 4" floor, Laxmi Insurance
Building, Sir P.M. Road, Fort, Mumbai —
Anjani Kumar so
67. | gin sft Mob: 9869036589 Tel: 022-65108299, MAH/1908-C/1994
28553633
Email:aks1703@gmail.com
Villa Berry Building, 1“ floor, Room No.
27, Oamar Park, Warden Road, Mumbai —
Ashok R. Verma 400036 Mob: 9892215396 MAH/1995/1995
email:ashokvermal962@gmail.com
Flat No. 5, Prajakta Co-op Housing
Society, Brahmin Society, Naupada,
Ashutosh Ravindra | Thane (W)— 400602 Mob:9819598173
Gole Tel:022-25337270, 25421736 MAH/3152/2004
email:ashutoshrgole@gmail.com
6 ae

<!-- page 8 -->

15/16, S.P. Business Centre, Prakash
Chambers, 77, Nagindas Master Road,
५ के Fort, Mumbai- 400023
70. | Bhavin R. Bhatia Mob: 9324991191 Tel: 022-28765803 MAH/3629/2005
email:bhatiabhavin@gmail,com
118/120, Vithoba Lane, Shri Vithal
Mandir Building, 2" floor, Vithalwadi,
Chandrakant Kalbadevi Road, Mumbai-400002 MAH/
ue Narayan Chavan Mob:93228841 14 Tel:022-22401241 1OSHL994
email:chandrakantchavan09@gmail.com
Flat No.10, 4" floor, Yash Co.Op.
Housing Society, 649 Ranade Road
72. | Jaydeep Deo Extension, Shivaji Park, Dadar, Mumbai — MAH/1702/2001
400028. Mob:9820876593
2, Dhanashree CHS Opp. Godbole
Hospital, M.G. Road, Naupada, Thane —
73, | Mandar Vasant | 499602 Mob:9820401315 MAH/2702/1999
Limaye Mt A
email:limayemv@yahoo.co.in
Plot No. 79, Office No. 501, 5" floor,
M.B. House, Janmabhoomi Marg, Fort,
Manisha S. Jagtap | Mumbai-400001.
74. | (Khandangale) Mob:9892099833 Ma Fite s2000
email:manisha@shekhar.com
Mavutesh Surendis: Block No. 2, Yamuna Niwas, G.B. Road,
75, हि Charai, Thane-400601 MAH/733/2001
Gulmarg Apartment, 6" floor, Flat No.
Mohd. Ali MS 601, 6" floor, YMCA Road, Morland
76. Chinawala Road, Above Bank of Baroda, Mumbai — MAH/1329/1988
400008. Mob:9821099019
A/S01, Nilambari Sector 19, Airoli, Dist.
Narayan Ramratan | Thane- 400708
71. eee Mob:9821259697 Tel:022-41235095 MAH/2139/1999
Bubna ‘i 7
email:nrbubna@gmail.com.
Room No.36, AAWI, High Court, Fort,
है न Mumbai-400032. H/
78. | Nisha N. Valani Mob-9323926258 MAH/4587/1993
3" floor, Empire House, 214, A.K. Nayak
«3 Marg, Fort, Mumbai — 400001
79. | Prasenjit Khosla Mob:9867734759 MAH/2820-B/2005
email:khoslaprasenjit@rediffmail.com
Rakesh Naresh 154, Mittal Towers, ‘A’ Wing, Nariman
20. | Redd Point, Mumbai-400021 Mob:9833311086 | _MAH/4213/2009
2003,Neelkanth Heights, B.P.S. Cross
Road, Mulund (West), Mumbai — 400080
Shahaji R. Shinde | Mob:9870046999 Tel:022-25623306 MAH/121/1990
email:advshahaji09@gmail.com
Bee

<!-- page 9 -->

101-A, Vaitarna Buildings, Sir
82. | Shrinivas Bobde Pochkhanwalla Road, Worli, Mumbai — MAH/6340/2011
400030 Mob:9619846066
Ground floor, Hamam House, Ambalal
5 Doshi Marg, Fort, Mumbai
83. | Siddharth Shah Mob:932228663 MAH/4227/1999
email:lawyersidd@gmail.com
C/o Shri Vijaysingh Thorat, Sr. Advocate,
4" floor, Ambalal Doshi Marg, Above
84. | Vaibhav Sugdare Stock Market, Stock Exchange Post MAH/1534/2000
Office, Fort, Mumbai — 400001
Mob: 9892040944
G-3, Commerce House, Nagindas Master
a के Road, Mumbai — 400001 Mob: H/
85. | Vijay Killedar 9819356999, 9321365999 MAH/1694/2002
Tel: 022-22704534
501/A Wing, Dosti Florentine, Dosti
Na Shiamika Ajkars, Wadala (E), Mumbai — 400037
Mathotra Mob:9820698770, 9820923977 MAH/2567/1990
Tel : 022-24031072
email:malhoraanamika20@yahoo.in
14, 2™ floor, Cama Chambers, Above
Welcome Restaurant, Flora Fountain,
87. | Devesh Tripathi Fort, Mumbai — 400023. D/2136/2011
Mob: 09004524359
email:dtadvocate@gmail.com
Building No. 35, 2" floor, Ambalal Doshi
Marg, Opp. Hamam House, Fort, Mumbai
88. | Dhanesh R. Shah — 400023 MAH/729/1999
Mob:9820779804 Tel:022-28882708
email:danraj2032@gmail.com
Nand-Dham, B.S.P. Road, Near Dahisar
‘ : Bridge, Dahisar (West), Mumbai —
Dhirendra P. Singh 400068 Mob: 9323176664 MAH/4370/2007
email:dpsingh0O007@yahoo.com
12, 2" floor, Parekh Vora Chambers,
Pranil K. Sonawane | N.M. Road, Fort, MAH/1441/2008
MumbaiMob:96 19646233
11, Air View Apartment, Vakola Bridge,
| Santa Cruz (E), Mumbai — 400055 MAH/4726/2004
Mob:9322833314
No.16, Ground Floor, Shrinivas Building,
Shailendra Shrikant | D.B. Deshpande Road, Shivaji Park, Road
92. | Kanetkar No. 4, Dadar (W), Mumbai — 400028 MAH/1519/2003
Mob: 9821265257
A-1902, Videocon Towers, Thakur
r Complex, Kandivli (E), Mumbai —
93. | Anil S.Kadam | 490101 Mob: 9969636399, 8652814269 | MAH/1384/1985
email:anilkadam55@yahoo.com
7, Madhusagar, Kemps Corner, Pedder
Road, Mumbai — 400026
94, | Gauraj Shah Mob:9820920330 MAH/4497/2010
email:gaurajs@gmail.com
oi

<!-- page 10 -->

Sareeta Complex Building No. 7, C/09,
Jesai Park, Bhayander (E), Dist. Thane

. Jitendra B. Mishra | Mob : 9819231067 MAH/2404/2000
Tel:022-40061574
email:jitendramishra647@gmail.com
6, Bhagyoday, Ground Floor, 79,

Nagindas Master Road, Fort, Mumbai —
a 4

97. | Karan Dilip Bhosle बा, Tel:022-22675858, MAH/1612/2006
22675859
email:karan.d.bhosale@gmail.com
B-504, Raigad, Building No. 87,

eas | Kannamwar Nagar 2, Vikhroli (E),

Niranjan P. Shimpi | Vfumbai— 400083 Mob: 9820035783, MAHat e028
9004024026
R/2, Chandrakant Bhavan, Marol Naka,

Chimmatpada, A.K. Road, Andheri (E),

Rajendra Prasad Mumbai — 400059

Krishnadutt Ojha | Mob:9821163586, 9869987076 Tel:022- | MAH/1207/1989
28501383
email:advpojha@yahoo.com
Off No. 11, 2™ floor, Building No. 22,

Rajabahadur Mansion (Opp. SBI Main

Rakesh Deviprasad | Branch), Mumbai Samachar Marg, Fort,

Kumar Mumbai- 400023 MAHISSUID?
Mob:9820385297 Tel:022-65343033
email:counsel.kumar@gmail.com
Off. SSL Law, 1* floor, 46 Islam
Building, V.N. Road, Fort, Mumbai —

Sandeep S. Ladda 400001 Mob: 9960202300 Tel:022- MAH/2657/2005
40029111, 20842300
email:ssllaw9@gmail.com
Pitru Chaya, 10, Society Road,

Shailesh Sharad Jogeshwari (E), Mumbai — 400060

102.1 pathak Mob:9820845969 Tel:022-28246940 pee lee
email:advocatepathak@gmail.com
302, 3 floor, Fort, Foundation Building,

Bake House Lane, N.M. Street Extension,

103. | Shilpa Kapil Fort, Mumbai — 400023 MAH/3756/2001
Mob:9892672147 Tel:022-22829121
email:shilpackapil@gmail.com
19, Meher-Abad, Bhulabhai Desai Road,

Mumbai — 400026

104. ] Shruti Digant Vyas | Mob:9820687809 Tel:022-23635097, G/2458/2001
22831666
email:shrutitrivedi99@gmail.com
Off.102, 1* floor, Natwar Chambers,

Nagindas Master Road, Fort, Mumbai —

105. | Swapnil Bangur 400023 MAH/3319/2001
Mob: 9820001453
email:swapnil_bangur@yahoo.com
A-802-603, Akshardham CHS Ltd., Off

; Link Road, Rajanpada, Malad (W),

ips Arvidray | Mumbai-400064 MAH/1250/1994
Mob:9930303 144
email:trusharbhavsar@rediffmail.com

कट
