---
doc_id: "a13f9e6cf4dd1dc1"
source_url: "https://www.darpg.gov.in/static/uploads/2025/10/360a6a9bdc27d7b674c00b21bc9e425b.pdf"
ministry: "Department of Administrative Reforms and Public Grievances (DARPG)"
title: "31.1.2024 Developing and implementation of SDG Dashboard and CSR Portal , Govt. of Mizoram 2nd Installment"
date: "2024-01-31"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "26b17c402d12e1ea"
---

<!-- page 1 -->

=
Government of India
Ministry of Personnel, Public Grievances & Pensions
Department of Administrative Reforms & Public Grievances
6" Floor, Jawahar Vyapar Bhawan,
New Delhi-110001
Dated the3).01.2024
To,
The Pay & Accounts Officer
Ministry of Personnel, PG and Pensions
Lok Nayak Bhavan,
New Delhi
Sub: Project “Developing and Implementation of SDG Dashboard and CSR Portal for Planning & Program
Implementation Department, Govt. of Mizoram” under State Collaborative Initiative (SCI) Scheme
-regarding
Sir,
| am directed to convey the sanction of the President of India for the release of an amount Rs. 13.75
lakh (Thirteen Lakh Seventy Five Thousand) as second installment, which is 25% of approved cost of 55 lakh
for the aforesaid project under State Collaborative Initiative Scheme.
Bs The payment of Rs. 13.75 lakh (Thirteen Lakh Seventy Five Thousand} is hereby transferred in the
Central Nodal Account of National Centre for Good Governance (NCGG), Central Nodal Agency (CNA) of this
Department as per following details:-
Bank :_ |State Bank of India
Account Name |. |National Centre for Good Governance
Central Nodal Account (CNA)
[|
LI
3. The payment of Rs. 13.75 lakh (Thirteen Lakh Seventy Five Thousand) may be released through NEFT/RTGS
by NCGG in the accounts of M/s Planning & Program Implementation Department (RDB), Govt. of Mizoram
as per following details:
Oe Le
4 \
61८ अं

<!-- page 2 -->

4. The above release is subject to the following 5 है
i, The host department shall submit quarterly monitoring report to DARPG.
ii, | Procurement, if any. to be done as per provision of GFR.
ui Timeline for completion of the project may be strictly adhered to and also deliverables be
achieved.
iv. The host Department shall duly submit Utilization Certificate in Form 12C of GFR 2017,
component-wise expenditure statement and progress report of the Project.
5 NCGG may comply with the procedures laid down in Department of Expenditure’s O.M. No. 1
(18)/PFMS/FCD/2021 dated 9% March, 2022
6. The expenditure is debitable to Major Head 2070-Other Administrative Services, Minor Head
2070.00.800.42.01 — Scheme for Administrative Reforms, Object head 42.01.31 Grant-in-Aid General (31)
Under State Collaborative Initiative under Grant No. 74 for the year 2023-24. |
vl This issues with the concurrence of Integrated Finance Division (H) vide Note No #10 dated
23.01.2024 on P-15014/01/2024-D&D-DARPG(8574)
Yours faithfully,
\ 6 ni |
Naver ye"
(Vandana Nangia)
Under Secretary to the Government of India
011-23440389
Copy to:
1. DDO/Cash Section, Dio AR&PG
2. Dr. Gazala Hassan. Assistant Professor, NCGG, Block TV Old JNU Campus. New Mehrauli
Road, New Delhi-110 067
3. Planning & Program Implementation (P&PI) Department, Government of Mizoram (Kind
Atin Dr. Lalrinchhana, Principal Adviser-cum-Additional Secretary), Planning & Program
Implementation Department, Upper Khatla, Aizawal Mizoram Email:
marinchhana@ gmail.com, mizoplan@gmail.com
4. Sh. N.K. Meena Director (Admn.) for Information
5. Sanetion Folder/Guard File |
9
&) 6
~/
GZ: # 4771 #/९ 2
/
Fj / go AY
pes u Ee 5
