---
doc_id: "9ef47cc47be1ffb6"
source_url: "https://www.dst.gov.in/static/uploads/2025/11/169ab8599636b3f2c715d4a567fad944.pdf"
ministry: "Department of Science and Technology (DST)"
title: "DST releases Draft 5th National Science, Technology, and Innovation Policy for public consultation"
date: "2020-12-31"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95a1bac58139d364"
---

<!-- page 1 -->

Ministry of Science and Technology
Department of Science & Technology

DST releases Draft 5th National Science, Technology, and
Innovation Policy for public consultation
The draft of the 5th National Science Technology and Innovation Policy has been finalized and is now
available for public consultation. The policy drafted through a 4 track process of consultations during
last 6 months aims to bring about profound changes through short, medium and long-term mission
mode projects by building a nurtured ecosystem that promotes research and innovation on the part of
both individuals and organizations.
It aims to foster, develop, and nurture a robust system for evidence and stakeholder-driven STI
planning, information, evaluation, and policy research in India. The objective of the policy is to identify
and address strengths and weaknesses of the Indian STI ecosystem to catalyse socio-economic
development of the country and also make the Indian STI ecosystem globally competitive.
As India and the world reorient in the present context of the COVID-19 crisis, a new Science,
Technology, and Innovation Policy (STIP) was initiated at this crucial juncture during mid-2020. For
India to march ahead on a sustainable development pathway to include economic development, social
inclusion and environmental sustainability for achieving an “Atmanirbhar Bharat'', a greater emphasis
may be needed on promoting traditional knowledge systems, developing indigenous technologies and
encouraging grassroots innovations. The emergence of disruptive and impactful technologies poses
new challenges and simultaneously greater opportunities. The COVID-19 pandemic provided a
compelling opportunity for R&D institutions, academia and industry to work in unison for sharing of
purpose, synergy, collaboration and cooperation.
The STIP will be guided by its broad vision of achieving technological self-reliance and position India
among the top three scientific superpowers in the decade to come, to attract, nurture, strengthen and
retain critical human capital through a ‘people centric’ science, technology and innovation (STI)
ecosystem, to double the number of Full-Time Equivalent (FTE) researchers, Gross Domestic
Expenditure on R&D (GERD) and private sector contribution to the GERD every 5 years and to build
individual and institutional excellence in STI with the aspiration to achieve the highest level of global
recognitions and awards in the coming decade.

<!-- page 2 -->

The new policy, STIP, revolves around the core principles of being decentralized, evidence-informed,
bottom-up, experts-driven, and inclusive. Also, it aims to bring in the concept of ‘dynamic policy’ with
a robust policy governance mechanism incorporating features such as implementation strategy,
periodic review, policy evaluation, feedback, and adaptation, and most importantly, a timely exit
strategy for various policy instruments.
The process so far involved nearly 300 rounds of consultations with more than 40,000 stakeholders
well distributed in terms of region, age, gender, education, economic status, etc. The STIP Secretariat
was coordinated, supported, and guided by the Office of PSA, NITI Aayog, and DST. The formulation
process, by design, envisioned as a very inclusive and participative model with intense
interconnectedness among different tracks of activities.
The draft is placed for public consulation on DST’s website.
Suggestions, comments and inputs on the draft Policy may be shared by Monday the
25th January,2021 on email: india[dot]stip[at]gmail[dot]com .
The

policy

draft

is

available

on https://dst.gov.in/draft-5th-national-science-technology-and-

innovation-policy-public-consultation

Follow us on social media:
IndiaDST /

IndiaDST

IndiaDST /

IndiaDST /

IndiaDST /

IndiaDST /
