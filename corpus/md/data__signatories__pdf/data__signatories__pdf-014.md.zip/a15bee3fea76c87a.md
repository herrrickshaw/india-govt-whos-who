---
doc_id: "a15bee3fea76c87a"
source_url: "https://www.dahd.gov.in/static/uploads/2026/06/3cb1a48f8dd7d5d27ac41bf4061d2413.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "The Breeding of and Experiments on animals (Control and Supervision) Amendment Rules, 2001."
date: "2026-06-05"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4cba07c782d6a25b"
---

<!-- page 1 -->

MINISTRY OF SOCIAL JUSTICE AND EMPOWERMENT
NOTIFICATION
New Delhi, the 15th February, 2001
S.O. 134(E).—Whereas -certain draft rules to amend the Breeding of and Experiments on
Animals (Control and Supervision) Rules, 1998 were published, as required by sub-section
(1) of section 17 of the Prevention of Cruelty to Animals Act, 1960 (59 of 1960) under the
notification of the Government of India in the Ministry of Social Justice and Empowerment
th
number S.O. 168(E) dated the 18 February, 2000 inviting objections and suggestions from
all the persons likely to be affected thereby, before the expiry of the period of thirty days
from the date on which copies the Gazette containing the said notification are made available
to the public;
th

And whereas the said Gazette was made available to the public on 24 February, 2000;
And whereas the objections/suggestions received in respect of the said draft rules, have been
duly considered by the Committee for control, and supervision of experiments on animals;
Now, therefore, in exercise of the powers conferred by sub-sections (1), (1A) and (2) of
section 17 of the Prevention of Cruelty to Animals Act, 1960 (59 of 1960), the Committee for
control am supervision of experiments on animals hereby makes the following rules to amend
the Breeding of and Experiments on Animals (Control and Supervision) rules, 1998, namely:1. (1) These rules may be called the Breeding of and Experiments on animals (Control and
Supervision) Amendment Rules, 2001.
(2) They shall come Into force on the date of their publication in the Official Gazette.
2. In the Breeding of and Experiments on Animals (Control and Supervision) Rules,
1998 (hereinafter referred to as the sold rules), In rule 2, for the existing clause (e), the
following clause shall be substituted, namely:
(e) "experiment" means any programme/project Involving use of an animal/animals for
the acquisition of knowledge of a biological, psychological, ethological, physical or
chemical nature; and Includes ,the use of animal In the production of reagents and
products such as ,antigens and antibodies, routine diagnostics, testing activity and
establishment of transgenic stocks, for the purpose of, saving or prolonging life or
alleviating suffering or for combating any disease whether on human beings or animals.
3. In the said rules, in rule 5, for sub-rule (c the following sub-rules shall be substituted,
namely:"(c) A breeder or the establishment on registration for the purpose of performing
experiments on animals shall comply with the conditions as may be specified at the time
of registration by the Committee.
(d) The Committee or any other-officer authorized In this regard by the Committee
shall take decision on the registration within three months of making the application.

<!-- page 2 -->

(e) if any modification of facilities are required before registration, the details needed
shall be communicated by the Committee."
(4) In the said rules, for rule 6, the following rule shall be substituted, namely:"6. Detail; of the experiments conducted:- (a) Every registered establishment shallmaintain a register of particulars about the animals used from: day to day for
conducting experiments, with the number of animals, the species, the age, gender and
other relevant particulars
"(b) "The Committee or any other officer authorized by the Committee may examine
the register so maintained and if the Committee is not satisfied even after opportunities
given for Improvement, It may take such action as may be appropriate under these
rules".
(5) In the said rules, in rule 7, after the existing condition (f), the following conditions shall
be inserted, namely:"(g) - detailed specifications for housing, feeding and maintenance of various species to
be used In animal experimentation as notified by the Committee, shall be adhered to by
the registered establishment.
(h) In the Interim period fill such detailed specifications are notified, the breeders and
establishments shall comply with the Indian National Science Academy Guidelines."
(6) In the said rules, in rule 9, - (i) for the existing condition (a), the following condition shall
be substituted, namely:"(a) experiments shall be performed in every case by or under the supervision of a person
duly qualified in that behalf, that is, Degree holders In Medicine or
Veterinary Science, Post Graduate and above in life Sciences/Pharmaceutical Sciences
or any other natural sciences, Degree or Diploma holders in Pharmacy, Diploma or
Certificate In Laboratory Animal Techniques Sciences from a recognized Institution as
Identified by Committee for the Purpose of Control and Supervision of Experiments on
Animals for the purpose and under the responsibility of the person performing the
experiment,";
(ii) for the -existing, condition (g), the following condition shall be substituted, namely:
(g) the experiments shall not be performed for the sole purpose of attaining or retaining
manual skill except In schools, colleges and programmes duly scrutinized and permitted
in registered establishments by the Committee;";
(iii) in the existing condition for the words, "the substance known as urari or curare or any
such paralysan shall not be used", the words "no paralyzing agent, Including but not
limited to curare, shall be used" shall be substituted.

<!-- page 3 -->

7. In the said rules, in rule 10,(i) for sub-rule (b), the following sub-rules shall be substituted, namely:"(b) A breeder or establishment shall not acquire -any animal by sale or otherwise
except from a registered breeder or establishment.
(bb) For the acquisition of laboratory bred experimental rats and mice species of
genetically defined strains not available within the country, the registered breeders or
establishments shall apply for permission to the Institutional Animal Ethics Committee
recognized by the Committee for the Purpose of Control and Supervision of
Experiments on Animals."
(ii) for sub-rule (e), the following-sub-rule shall be substituted, namely:"(e) No animal shall be Imported by a registered breeder or establishment, except
genetically defined or laboratory bred experimental rats an! d mice of genetically
defined strains, which is available in the country."
8. In the said rules, for rule 12, the following rule shall be substituted, namely:"12. Contract animal experiments. - No establishment shall contract or undertake to perform
contract research or
experiments on contract basis on behalf of any other establishment or research or
educational Institution, except with prior permission of the committee:
Provided that no such restriction shall apply to collaborative research between
academic Institutions."

[F. No. 7-5/98-AW (Vol. II)]
A. K. JOSHI, Member Secy.
(Committee for the Purpose of Control and Supervision of Experiments on Animals)

Note:—The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3,
Sub-section (ii) vide S.O. No. 809, dated l5th December, 1998.
