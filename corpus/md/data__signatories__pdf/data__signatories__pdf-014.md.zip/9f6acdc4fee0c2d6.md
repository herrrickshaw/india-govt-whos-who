---
doc_id: "9f6acdc4fee0c2d6"
source_url: "https://shipmin.gov.in/sites/default/files/Corrgendul%20No.2%20with%20Vacancy%20Circular%20No.11-2023%20for%20the%20post%20of%20Director%20%28Transportation%20%26%20BD%29.pdf"
ministry: "Ports, Shipping and Waterways (MoPSW)"
title: "Corrgendul No.2 with Vacancy Circular No.11-2023 for the post of Director (Transportation & BD).pdf"
date: ""
pages: 13
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "dbf0e442c288166b"
---

<!-- page 1 -->

rca इंडियन पोर्ट रेल एंड रोपवे कॉर्पोरेशन लिमिटेड
gy 2 (पत्तन, पोत परिवहन एवं जलमार्ग मंत्रालय, भारत सरकार के अधीन संयुक्त उद्यम ) Yay
4 2 Indian Port Rail & Ropeway Corporation Ltd. ~ ee"
vail __{) (A JV Company under Ministry of Port, Shipping & Waterways, Government of India)
aa CIN No: U60300DL2015PLC282703 SAGARMALA
ata rae संयोजनम्‌ (An ISO 9001, 14001 & 45001 Certified Company)
No. IPRCL/MUM/HR/REC.05/2022/ \\0%9 Date: 30.12.2023
है CORRIGENDUM-2
Advertisement No. IPRCL/MUM/HR/REC.02/2023 for the post of Director (Finance) and
Director (Transportation & Business Development) was published on 05.07.2023 in Times of India.
Detailed vacancy circular for the aforesaid posts were posted on IPRCL and IPA website
respectively wherein the last date for receiving of applications in IPRCL’s office was mentioned as 30
days from the date of advertisement i.e. up to 03.08.2023. The last date of receiving the applications
along with enclosures in IPRCL’s office was extended up to 02.09.2023.
Now the last date of receiving applications along with enclosures in IPRCL’s office is further
extended up to 14.02.2024.
{Authority Comp No. 214, File No. HR/23/2023-HR, Note # 24 dated 29.12.2023)
bie [2-202
Dal Veer Sheh डर
CS/IPRCL
Corporate Office: 4** Floor, Nirman Bhavan, Mumbai Port Trust Suilding, M. P. Road, Mazgaon (E), Mumbai - 400010 ae
Ph. No. : 022 — 6656 6343; Fax No. : 022 - 6656 6336;Email: cs@iprcl.in, website: www.iprcl.in_ A he Si
nee: Regd. Office: 1* Floor, NBCC Place, Bhishma Pitamah Marg, Lodhi Road, New Dethi-1100001 i
कल

<!-- page 2 -->

Ga इंडियन पोर्ट रेल एंड रोपवे कॉर्पोरेशन लिमिटेड
का a (पत्तन, पोत परिवहन एवं जलमार्ग मंत्रालय, भारत सरकार के अधीन संयुक्त उद्यम ) be
| iB Indian Port Rail & Ropeway Corporation Ltd. ogo
a £2) (A SV Company under Ministry of Port, Shipping & Waterways, Government of India)
Ss CIN No: U60300DL2015PLC282703 SAGARMALA
ia PU संयोजनम्‌ (An ISO 9001, 14001 & 45001 Certified Company) oo
VACANCY CIRCULAR NO. 11/2023 dated 04.07.2023
कंपनी का नाम
Name of the company Indian Port Rail & Ropeway Corporation Ltd
पद का नाम
Name of the post Director (Transportation & Business Development)
विज्ञापन की तिथि
Date of Advertisement 04.07.2023
कंपनी की अनुसूची
Schedule of the company Schedule B (Equivalent)
पद का वेतनमान
Scale of the post Rs. 160000-290000 (IDA)
L COMPANY PROFILE
Indian Port Rail & Ropeway Corporation Limited (IPRCL) was incorporated under the Indian Companies
Act, 2013 10.07.2015 with the main objective to undertake last mile rail connectivity project to Major ports,
modernisation of rail infra in ports and manage internal port Railway system services and consultancy services
in India and abroad in mainly in the fields of railway, ROBs, Roads, Ropeway other multi-modal transports
infra. IPRCL is a schedule ‘B’ equivalent JV company under Ministry of Ports, Shipping and Waterways.
The company employed 181 employees as on 31.03.2023.
It’s Registered Office is at New Delhi and Corporate Office is at Mumbai.
The authorised share and paid-up capital of the company are Rs.500 Crore and 100 Crores respectively as on
31.03.2023.
The indirect shareholding of the Ministry of Ports, Shipping & Waterways through Major ports in the
Company is 90% as on 31.03.2023.
IL JOB DESCRIPTION AND RESPONSIBILITIES:
Director (Transportation & Business Development) is a member of the Board of Directors and reports to
Managing Director with following responsibilities:
© She/He has the overall responsibility of planning and modemisation of rail related infrastructure for
Major Ports, Non-Major Ports and other industries with a view to enhance their handling capacity,
efficiency and throughput.
e Responsible for Company to operate and manage the internal Port Railway System.
e Should be well conversant with Port’s logistics, rail transportation and supply chain management to
assess intermodal gaps and developing suitable solutions.
© Should be well conversant with traffic study and evaluation of financial modelling of infrastructure
projects.
¢ Should be knowledgeable of extant participative models of Indian Railways and other suitable models
for leveraging in enhancing last mile and hinterland connectivity.
© Responsible for liaison with Indian Railways, Stakeholders to obtain necessary approvals, clearances,
etc.
© Would be overall in-charge of Business Development. Responsible to create and implement Business
Development strategies and thereby enhancing Company’s revenue.
Il. ELIGIBILITY:
1. AGE: On the date of advertisement हे

<!-- page 3 -->

Age of superannuation 60 years
40 2 years residual service as on | 40 3 years residual services
the date of advertisement as on the date of
w.r.t. the date of advertisement w.r.t. the
perannuation. date of superannuation.
2. EMPLOYMENT STATUS:

The applicant must, on the date of application, as well as on the date of interview, be employed in a

regular / contractual (with minimum 3 years duration) capacity — not in an ad-hoc capacity — in one of

the followings.

(a) Central Public Sector Enterprises (CPSE) / Major Ports / Special Purpose Vehicles (SPV)/Joint
Venture (JV) Companies promoted by Government and/or Government Organizations (including
a full-time functional Director in the Board of a CPSE/SPV and/or JV company promoted by
Government and/or Government Organisation).

(b) Central Government including the Armed Forces of the Union and All India Services:

(© State Public Sector Enterprises (SPSE) where the annual turnover is *Rs. 250 crore or more.

(d) Private Sector in company where the annual turnover is *Rs.250 crore or more.

Preference would be given to candidates from listed companies.

(* The average audited annual turnover of three financial years preceding the calendar year in which

the post is advertised shall be considered for applying the approved limits.)

3. QUALIFICATION:

The applicant should be a Graduate with good academic record from a recognised

University/Institution.

Applicants with MBA/PGDM qualifications will have added advantage.

4. EXPERIENCE:

The applicant should have adequate experience/exposure at a senior level in an organisation of repute,

out of which at least 5 years during the last 10 years should have been in operations/business

development/marketing/planning in Transport/ Logistic sector.

Experience in Railway sector will have added advantage.

5. PAY SCALE:
(a) Public Sector Executives. Major Ports or SPV/JV Company Promoted _by Government/
Government Organization
Executives holding posts in the pay scale of:

0) Rs. 51300-73000/- (post 01.01.2007 scale) with Industrial DA

Gi) Rs. 120000- 280000/- (post 01.01.2017 scale) with Industrial DA

(iii) Rs. 18400-22400 with Central DA (pre-revised) post 01.01.1996

(iv) Rs. 37400-67000 with Grade Pay of Rs.10,000/- Central DA post 01.01.2006

(v) Rs. 144200-218200 (Level 14) CDA post 01.01.2016

The minimum length of service required in the eligible scale will be one year for internal candidates,

and two years for others as on the date of advertisement.

(b)

i) Applicants from Central Government / All India Services should be holding a post of the
level of Director in Government of India or carrying equivalent scale of pay for minimum 2
years on the date of application.

ii) Applicants from Armed Forces of the Union should be holding a post of the level of
Brigadier in the Army or equivalent rank in Navy/Air Force for minimum 2 years on the date
of application.

(b) Applicants from State Public Sector Enterprises / Private Sector should be working / worked
for minimum 2 years at Board level position or holding a post immediately below the Board level
for at least 2 years on the date of application.

6. IMMEDIATE ABSORPTION/DEPUTATION FOR CENTRAL GOVERNMENT OFFICERS:
Central Government officers, including those of the Armed Forces of the Union and the All India
रे Services, will be eligible for consideration on immediate absorption basis or on deputation.

<!-- page 4 -->

Deputation from CPSEs, Major Ports, SPV/JV Company promoted by Government/Government
Organization is also permitted provided the candidate furnishes his/her willingness and permission
from his parent organisation to be appointed on deputation along with the application.

IV. DURATION OF APPOINTMENT:
The appointment shall be for a period of five years from the date of joining or upto the date of
superannuation or until further orders, whichever is earlier.

V. SUBMISSION OF APPLICATIONS

Prospective candidates from Public Sector Companies/ Major Ports/ SPSE/ SPV or JV companies

promoted by Government or Government Organizations and Government officers shall submit their

applications, through proper channel within due date as prescribed in Para-V above failing which their
applications shall be rejected, in the format at Annexure-I.
1. The applications for various categories of the officers are routed through proper channels follows:

a) Government Officers, including those of the Armed Forces of the Union and All India Services:
through Cadre Controlling authority;

b) CMDs/MDs/Functional Directors in CPSE/SPV or JV companies promoted by Government
Organization: through the concerned Administrative Ministry;

c) Below Board level in CPSE/ Major Port/ SPV or JV companies promoted by Government and/or
Government Organisation: through the concerned CPSE/ Major Port/ SPV or JV;

9) CMDs/ MDs/ Functional Directors in State PSE: through the concerned Administrative Secretary
and Cadre Controlling Authority, if any, of the State Government;

०) Below Board level in SPSE: through the concerned SPSE;

f) Forwarding of application through deputation shall be clearly mentioned on the forwarding letter
and application that in case of selection of the candidate the organisation is willing to relieve the
candidate;

g) Private Sector: directly to IPRCL.

2. Applicants from Private Sector must submit the following documents along with the application form
in Annexure-II:

(a) Annual Report of the Company in which currently working for preceding financial year in which
the post is advertised (please provide URL or attach/enclose copies;

(b) Whether the company is listed or not; if yes, the documentary proof (please provide URL or
attach/enclose copies);

(c) Evidence of working at Board level or at least a post of the level immediately below the Board
level;

(d) Relevant Jobs handled in the past with details.

VI. UNDERTAKING BY THE CANDIDATE

An applicant has to give an undertaking as part of the application that he/she will join the post, if

selected. If an applicant does not give such undertaking, the application would be rejected.

For candidates from Central Government/Armed Forces of the Union/ All India Services/Major

Port/CPSE/SPSE/SPV or JV company promoted by Government/ Government Oraganisation/Private

Sector:

(a) If a candidate conveys his/her unwillingness to join after interview is held, he/she would be
debarred for a period of two years from the date of interview, for being considered for a Board
level post in IPRCL

(b) Further, if'a candidate conveys his/her unwillingness to join after issue of offer of appointment,
he/she would be debarred for a period of two years from the date of offer appointment for
being considered for a Board level post in IPRCL.

VII. GENERAL CONDITIONS
i. All qualification should be recognized by UGC/AICTE/AIU(GOI).
ii. Additional weightage may be given to candidates having additional relevant or higher oon
|

<!-- page 5 -->

iii, _ Candidates, who are presently employed in SPSEs/Private Sector, must spell out clearly that his/her
designation and scale in his Present Organization is equivalent to or above of that mentioned herein
above. These candidates are required to submit a copy of the Organization Structure and Pay Scale of
the present employment (duly signed by the candidate) to justify their eligibility for a particular post,
in the absence of which the application shall not be considered.

iv. Appointment shall be subject to Service and Conduct Rules of the company.

v. The company takes no responsibility for any delay in receipt or loss in postal transit of any application
or communication. Candidates in their own interest are advised to submit applications well in time
before the last date to avoid possible delay in postal transit.

vi. In case it is detected at any stage of recruitment that a candidate does not fulfil the eligibility norms
and/or that he/she has furnished any incorrect / false information / certificate / documents or has
suppressed any material fact(s), his/her candidature will stand cancelled. If any of these shortcomings
is/are detected even after appointment, his/her services are liable to be terminated.

vii. | Any request for change of address / change of centre for group discussion and / or interview shall not
be entertained.

viii. | The company has the right to reject any application/ candidature at any stage without assigning any
reason and the decision of company shall be final.

ix. The company has the right to reject entirely or partially the selection/advertisement at any stage
without assigning any reason and the decision of company shall be final in this regard.

x. Any resulting dispute arising out of this advertisement shall be subject to the sole jurisdiction of the
Courts situated at Mumbai only.

xi. Canvassing in any form will be a disqualification.

xii. | Communication shall be sent at the Present Address mentioned by the Candidate in the application
form.

xiii. Any changes /modifications / Corrigendum / Addendum etc. in the advertisement will be placed on the
website of the Company (www.iprel.in) and IPA ( www.ipa.nic.in) only. Candidates applying for the post
are advised to visit the websites regularly for updates.

xiv. IPRCL reserves the right to seek clarifications/documents, if required. Further Screening
Committee/Selection Committee reserves the right to accept/ reject the application which is not complete
or is deficient based on the extent/nature of deficiency.

xv.  Self-Attested Photocopies of all certificates /testimonials are to be provided with the application form
including:-

a. Proof of date of Birth (Class 10 Board Certificates or Birth Certificate)

b. Educational/ Professional Certificates of qualifying criteria (for Private Sector candidates
only).

c. Experience Certificates (including Appointment & Relieving letters of all employers during
last 10 years) (for Private Sector candidates only).

d. Self-Certified Copies of Last 05 years APARs / ACRs. (only applicable to candidates from
Central Government/Armed Forces of the Union/ All India Services/Major
Port/CPSE/SPSE/SPV or JV company promoted by Government/ Government Oraganisation).

e. Copy of last drawn Salary Slip.

No certificate in original is required to be attached with the application. IPRCL shall not be responsible for

misplacement of such certificates.

SELECTION PROCESS

After scrutinizing all the applications received for the post, only short-listed candidates will be called for

interview by the Selection Committee constituted by the Board of IPRCL.

The decision of the Selection Committee will be final and no correspondence on the decision of the Committee
0०० entertained in this regard. |

<!-- page 6 -->

Last date of receipt of applications by post / courier in Indian Port Rail & Ropeway Corporation Limited is
30 days from publishing of Advertisement in Newspaper. No application shall be entertained under any
circumstances after the stipulated date. Incomplete applications and application not in prescribed format are
liable to be REJECTED.
Company reserves the right to shortlist candidates for interview.
Applications are to be addressed to:
Company Secretary
Indian Port Rail & Ropeway Corporation Limited
4" Floor, Nirman Bhavan,
M.P. Road, Mazgaon (East),
Mumbai — 400010.
ALL CORRESPONDENCE WITH THE INDIAN PORT RAIL & ROPEWAY CORPORATION
LIMITED SHOULD BE ADDRESSED TO COMPANY SECRETARY ONLY. 4०
छः कारन आन नमन कनमकन उमे कननकन+ न कम_ा-+ब सका ० +- कल ताक ++-नकाइनून कल समर
Corporate Office: 4* oor, Nirman Bhavan, Mumbai Te iki 'M. P. Road, Mazgaon (E), Mumbai - 400010 की 2
a) लता उन 6340; Fax ० मय Gan 632 ma Bie im, wehsite: woww.iorcl.in G2
wot, Regd. Office: 1* Floor, NBCC Place, Bhishma Pitamah Marg, Lodhi Road, New Dethi-1100001 “=
—

<!-- page 7 -->

ANNEXURE I
APPLICATION FORM FOR CANDIDATES FROM PUBLIC SECTOR COMPANIES/ MAJOR
PORTS/ SPSE/ SPV OR JV COMPANIES PROMOTED BY GOVERNMENT OR GOVERNMENT
ORGANIZATIONS
[THROUGH PROPER CHANNEL]

(Note: Any column left blank will make the application incomplete and liable for rejection.)
1. Name of the post applied for :
2. (a) Name (in full) :

(b) Father’s / Husband’s Name (in full) :

(c) Designation of the Applicant (in full) :

(d) Office Address:
3. Present Address:
4. Permanent Address:
5. Telephone No: Office : Residence : FAX No.:

Mobile No.: E-Mail address :
6. Date of Birth and Age as on date of advertisement
7. _ Eligibility criteria:

As per job description Possessed by the Whether eligible or not
officer

Educational/
professional
qualifications (along
with the name of
Institutions)
Pay Scale
Length of service
in eligible pay
scale
Vw

<!-- page 8 -->

8.  Positios held during the preceding ten years:-
SLNo. Designation and Organization From To Pay scale
place of posting
8(a). Details of experience relevant for the advertised post and job description, out of 8 above::
Sl.No. Designation and Organization From To Pay scale Nature of
place of posting experience
Note: You may attach write up. If you wish, not exceeding two pages, in support of your candidature”.
9. Do youhold lien in any other organization? Yes/No
Iifyes:
(a) name of the organization in which the lien is held.
(b) the date from which the lien is held
Are you on deputation? Yes/No
If yes:
Date from which you have been on deputation.
10. (a) Whether any punishment awarded to the applicant during the last 10 years. Yes/No
Ifyes, the details thereof
(b) Whether any action or inquiry is going on against him as far as his knowledge goes. Yes/No If yes, the
details thereof
11. Icertify that self-certified documentary proofs are attached for:
(i) Proof of date of Birth (Class 10 Board Certificates or Birth Certificate).
(ii) Copies of Last 05 years APARs / ACRs.
Gii) Copy of last drawn Salary Slip.
(iv) Annual Report for the last audited financial year, or annual turnover figures duly certified by the Comp:

<!-- page 9 -->

Secretary/CFO. (Only applicable for candidates working in SPSEs)

(v) Candidates, who are presently employed in SPSEs, must spell out clearly that his/her designation and scale
in his Present Organization is equivalent to or above of that mentioned in sub-clause 5 of Clause-III-
Eligibility Criteria. These candidates are required to submit a copy of the Organization Structure and Pay
Scale of the present employment.

DECLARATION REGARDING EMPLOYMENT STATUS
L , do hereby declare on the date of application, as well as on the date of
interview, I am employed in a regular / contractual (with minimum 3 years duration) capacity — not in an ad-
hoc capacity in CPSEs/Govt./Major Ports/JV and SPV promoted by Government/SPSEs.
(Name and Signature of the applicant)
DECLARATION REGARDING HOLDING CURRENT POSITION
(Applicable for candidates working in SPSEs)
1s , do hereby declare that I am working/worked for minimum 2 years at Board
level position or holding a post immediately below the Board level for at least 2 years on the date of
application.
(Name and Signature of the applicant)
UNDERTAKING TO JOIN
L > 10 hereby undertake that I will join the company, if selected.
(Name and Signature of the applicant)
DECLARATION
Thereby declare that all the statements made in this application form are true, complete and correct to
the best of the knowledge and belief. I understand that in the event of any information being found false or
incorrect at any stage or my not satisfying the eligible criteria according to the requirements, my candidature/
appointment is liable to be cancelled/ terminated.
Date:
Place: (Name and Signature of the applicant)
(To be filled by the PSU/Ministry /Department concerned)
It is Certified that the particulars furnished above have been scrutinized and found to be correct as per official
records.
Signature & Designation
of the Competent Forwarding Authority
with Telephone no. & office Seal.

<!-- page 10 -->

ANNEXURE IT
APPLICATION FORM FOR PRIVATE SECTOR EXECUTIVES
(Note: Assy column left blank will make the application incomplete and liable for rejection.)
1. Name of the post applied for:
2. (a) Name (in full) :
(b) Father’s / Husband’s Name (in full) :
(०0 Designation of the Applicant (in full) :
(@ Office Address;  /$- ७ ७$&- | फतह
3. Present Address:
4. Permanent Address:
5. Telephone No: Office ; Residence FAX No.
Mobile No. E-Mail address
6. Date of Birth and Age as on date of advertisement
7. Eligibility criteria: लि
As per job description Possessed by the Whether eligible or not
officer
Educational/
professional
qualifications (along
with the name of
Institutions)
Pay Scale
Length of
service in
eligible pay
scale
8. Positions held during the preceding ten years:-
SL. No. Designation Organization From To Pay scale
and place of
posting
8(a). Details of experience relevant for the advertised post and job description, out of 8 above:
SLNo. Designation Organization From 10 Pay scale [०० ofexperience
and place of
posting
