---
doc_id: "9d7aeb4618af7ecb"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6a86cbc3c90cc0.96365232.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Notification - Inter Cadre transfer of Shri Prem Kumar R, an officer belonging to 2016 batch of Indian Forest Service from AGMUT Cadre to Rajasthan cadre, on grounds of marriage, notification dated 20-08-2026"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "da61e78cf5f37b80"
---

<!-- page 1 -->

(TO BE PUBLISHED IN PART-1 SECTION (Il) OF THE GAZETTE OF INDIA)
No. 17016/07/2026-IFS-I. [E. 304856]
Government of India
Ministry of Environment, Forest and Climate Change
6 Floor, Prithvi Wing,
Indira Paryavaran Bhawan, Jor Bagh Road,
New Delhi-110003.
Date 20%" August, 2026
NOTIFICATION
In exercise of the powers conferred under sub-rule (2) of Rule 5 of the Indian
Forest Service (Cadre) Rules, 1966, the Central Government, with the concurrence
of the Government of Rajasthan, hereby transfers Shri Prem Kumar R., an officer
of the 2016 batch of the Indian Forest Service, from the AGMUT Cadre to the
Rajasthan Cadre, with immediate effect, on the ground of his marriage to Smt.
Kaaviya B., IFS (RJ: 2022).
pielyts
2700१
(Phalguni Banerjee)
Under Secretary to the Government of India.
To
The Manager,
Government of India Press,
Minto Road, New Delhi-110002 (with a copy of Hindi version).
Distribution:
1. The Chief Secretary, Government of Arunachal Pradesh, Itanagar.
2. The Chief Secretary, Government of Rajasthan, Jaipur.
3. The Principal Secretary (Forests), Government of Arunachal Pradesh,
Itanagar.
4. The Principal Secretary (Forests), Government of Rajasthan, Jaipur.
5. The PCCF & HoFF, Government of Arunachal Pradesh, Itanagar.
6. The PCCF & HoFF, Government of Rajasthan, Jaipur.
7. The Accountant General, Arunachal Pradesh, Itanagar.
8. The Accountant General, Rajasthan, Jaipur.
9. PS to IGF (IFS) for information.
10. The Under Secretary (AGMUT) for information and necessary action.
41. The Under Secretary (IFS-Il) for information and necessary action.
12. Shri Prem Kumar R., IFS (AGMUT: 2016), Director, Arunachal Pradesh State
Forest Training Institute, Roing.
13. Hindi Section for translation.
14. NIC/ IT Cell for uploading on the website.
15. Guard file/ Spare copies.
