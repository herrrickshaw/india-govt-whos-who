---
doc_id: "9cedb950b6e8b3dd"
source_url: "https://financialservices.gov.in/sites/default/files/vacancy/Appointment-to-the-post-of-Chief-Vigilance-Officer-in-State-Bank-of-India-Mumbai_0.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Appointment-to-the-post-of-Chief-Vigilance-Officer-in-State-Bank-of-India-Mumbai_0.pdf"
date: ""
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "3f7e13e13e601cf1"
---

<!-- page 1 -->

& F. No. 15/5/97-Vig/AA
Government of India
Ministry of Finance
Department of Financial Services
Vigilance Section
fetes
3rd floor, Jeevan Deep Building
Sansad Marg, New Delhi - 110001
Dated u'* February, 2019
To,
Chairman, State Bank of India
MD&CEO of the Public Sector Banks
MD&CEO, IDBI Bank
Subject: Appointment to the post of Chief Vigilance Officer in State Bank of
India, Mumbai
Sir/Madam,
It is proposed to fill up the post of Chief Vigilance Officer (CVO) in State
Bank of India (SBI), Mumbai. Applications are invited in the form(s) annexed (as
applicable), from the officers of the following designations at present, who are
desirous of consideration for appointment to the post of CVO, SBI
»- a) Serving EDs of the Public Sector Banks (PSBs) and DMDs of IDBI Bank with
at least 2 years of residual service;
«
b) Serving CGMs of the State Bank of India with at least 2 years of service as
CGM, with residual service of 2 years having a strong banking
background/experience of vigilance matters.
2. A copy of the Scheme which contains, inter-alia, provisions regarding
eligibility and entitlement of pay and perquisites, admissible to the incumbent of
this post, is annexed.
3. Other conditions
a) Executive Directors of the PSBs may send their applications in the
applicable form, under intimation to the MD&CEO/Chairman of the
ह concerned Bank.
| b) Chief General Managers of SBI who, in terms of the provisions of the
ते scheme, consider themselves eligible for the post of CVO in SBI, may route
their applications through the HR Department of SBI. Their applications, to
be made in the applicable forms for this purpose, may be forwarded by the
HR Deptt. along with complete bio-data of the candidate along with attested
copies of Annual Performance Assessment Reports (APARs) for the last five
years (complete in all respects), to this Department on or before 26%
™~ February, 2019. While forwarding the applications of the GMs the HR
Department is advised to ensure that:
i the services of the willing candidates can be spared for at least 02
years for taking up this assignment; and
~
ct ep = wae ae ian

<!-- page 2 -->

ii. they are clear from vigilance angle; and
iii. the officers are not undergoing period of any debarment.

4. The names of candidates once forwarded for the post are not allowed to be
withdrawn. Therefore, while submitting the applications for consideration, each
applicant is required to give an undertaking (in the Form - annexed) to the effect
that they would not withdrawn their candidature once a decision is taken to
appoint him for the post of CVO, SBI, Mumbai. This undertaking shall be enclosed
with other requisite documents sought with the application.

5. The selection of candidates for appointment to the post of CVO, SBI shall be

made by the Government in consultation with CVC and, if applicable, DOPT, on the

basis of their record of service and on the recommendations of the Selection

Committee.

6. The applicant (both EDs of PSBs and CGMs of SBI) must have a minimum

02 years of service remaining as on the last date of receiving of application i.e.

26.02.2019 and for CGMs, the applicant must have completed 02 years of service

as on the last date of receiving of application i.e. 26.02.2019.

te In the event of event of selection of the officer for this post, the concerned

officer shall be given three weeks time to join new post/assignment of CVO, from

the date of receipt of the order. If no response is received after three weeks, and /
or if the officer fails to report for the assignment at designated place by given date,
हि the process of his/her debarment for deputation in any organisation for a period of

05 years shall be initiated by his/her parent organisation after issuing a notice to

that effect to the officer concerned.

8. The applicants may send advance copy of their application in this regard to

DFS for information by email at vigilance-dfs@nic.in. However, their candidature

shall be considered only after receipt of the hard copies of the application forms in

the prescribed manner.

9. Hindi version will follow.

Yours sincerely,

Encls: a) Copy of the Scheme A
b) Forms (02 Nos.) LT wot

(Manish 6०)
Director (Vigilance)
६ Tel: 011- 23362422

Copy to:

a) Sh. P K Mohanty, Under Secretary, Central Vigilance Commission, Satarkata
Bhawan, INA, New Delhi with reference to OM No.3S-CVO-23/405307 dated
03.01.2019.

४ by™ Director/NIC, DFS, Jeevan Deep Building with request to upload this
circular on DFS website.
~~
ee <n 34205 #- ५ अल सन

<!-- page 3 -->

SCHEME FOR FILLING UP THE POST OF CVO, SBI

F CVC has observed that SBI is the largest bank with a very large
branch network in the country and abroad. After merger of the Associate
Banks with SBI, the combined entity has grown to an enormous entity
necessitating reconstitution of the Vigilance set up commensurate with the
expected increase in vigilance functions. With this background, CVC has
advised that as the status of the incumbent CVO matters a lot in dealing
with the cases of top executives, the post of CVO has to be a level higher
than the GM, to enable him to function effectively.
9. (a) As such, an officer currently working as Executive Director (ED)
in one of the PSBs, Deputy Managing Director (DMD) in IDBI Bank, or

(b) Chief General Manager (CGM) in SBI India with at least 2 years

of service as CGM, with residual service of 2 years having a strong banking
background/ experience of vigilance matters.
3. Initially, CVO will be appointed for a period of two years, extendable
for a further period of upto 1 year or up to the date of superannuation
whichever is earlier.
4. The incymbent of the post of CVO, SBI shall report directly to
Chairman, SBI to discharge function/responsibilities of CVO. However, the
incumbent shall not be a Member of the Board of Directors of SBI.
5. Whenever the post of CVO, SBI is likely to fall vacant, the same will be
circulated simultaneously amongst the EDs of PSBs, Deputy Managing
Director (DMD) in IDBI Bank and Chief General Manager (CGM) in SBI for
calling applications from willing candidates.
6. The post of CVO, SBI shall be over and above the normal strength of
officers in SBI.
7. For EDs of PSBs and DMDs in IDBI Bank for appointment to the post

; of CVO, SBI

i
(i) | The ED of a PSBs/DMD of IDBI who is appointed as CVO in SBI shall
be entitled to pay and perquisites as admissible to an MD in SBI.
(ii) If the officer being positioned as CVO, SBI would be taken from the
éxisting position of ED in a PSB / DMD in IDBI Bank who are governed by
the Nationalized Banks (Management and Miscellaneous Provisions)
Scheme, 1970/1980 of PSBs, therefore, for the period he/she serves as
CVO, SBI, his/her service shall continue to be governed by the aforesaid

~~
nant rinse कई aa

<!-- page 4 -->

Scheme which was applicable to him/her as ED / DMD of the concerned
bank, except for provisions relating to Pay and Perquisites for that period.
(iii) In the case of selection of an ED of PSBs or DMD of IDBI Bank to the
post of CVO in SBI, the proposal would be processed for seeking approval of
ACC for withdrawing the existing ED/DMD of IDBI Bank (a Board level
officer) to take up the assignment of CVO in SBI. DFS will then issue orders
of appointment of the concerned officer to the post of CVO, SBI.
(iv) | The selected officer shall have to give up the existing post of ED in the
PSB/DMD in IDBI Bank, to take up the assignment of CVO, SBI.
8. For CGM of SBI for appointment to the post of CVO, SBI

In case a CGM of SBI is selected, he/she shall be entitled for pay and
perquisites of DMD, SBI for the period that he functions as CVO, SBI.
9. The selection of candidates for appointment to the post of CVO, SBI
shall be made by the Government in consultation with CVC, on the basis of
their record of service and interaction with the Selection Committee. The
panel of shortlisted candidates will be sent to CVC for recommending an

; officer for the post of CVO, SBI.
™ss
~~.
on |;

<!-- page 5 -->

के Form I
Appointment to the post of Chie gilance Officer, State Bank of India (SBI) I 9६
Application Form
oe Name of the Applicant
[2._| Date of Birth |
[3._[ Age as on the last date of application 6 Oe
4._| Date of Superannuation Tanne. OS
5.__| Present Post held a क - जा
6. | Name of the Organisation where posted a
Present Pay and Scale of Pay Sak ea ee
Details of Educational & Professional | Please add Annexure
Qualification (in chronological order)
Year From Year To Course Name | Board / College /
University /
Institute
[9._| No. of Years of regular service oh Sas पान ्जजा
10. | Work Experience of last ten years (Pl add Annexure) |
| S. No. | Post held on | From Nature of duties Experience in Vigilance /
regular basis To Disciplinary matters
11. | Postal Address | Permanent:
Present:
12. | Certificate & Undertaking from the applicant: I certify that the details furnished by me in the
| application form are correct to the best of my knowledge and belief and that I am eligible for the post
of CVO, SBI. I also submit the undertaking that I shall not withdraw my application for candidature
after my nomination/ selection for appointment to the said post.
Date: Place: Signature of the applicant
Contact Details:
Landline No. (with STD Code) Mobile Phone No. Email ID |
13. | Certificate From Employer (Applicable for candidates other than EDs of PSBs/DMDs of IDBI Bank):

7 Certified that the particulars furnished by Shri/Smt/MS.............0....:.::0:s000010000shave been verified
and found to be correct and that no disciplinary proceedings are either pending or being
contemplated against him/her. The integrity of the candidate is certified.

Signature & Designation of the competent forwarding authority
Date>—_ Telephone No: Office Seal
$ Email ID:
~~.
SSS te es a ee rere Nai i on

<!-- page 6 -->

* Form I
(Only for candidates other than EDs of PSBs/DMDs of IDBI Bank)
Appointment to the post of Chief Vigilance Officer, State Bank of India (SBI) Mumbai
Details to Be Furnished By Cadre Controlling Authority / Appointing Authority / Parent
Office
| 15 ae
2. | Whether any disciplinary proceedings have been initiated
against the officer during his career so far. If Yes, details
a
3. | Whether any complaint including that of corruption against
the officer which, in view of the State Government / Cadre
Controlling Authority may have a direct bearing/relevance
on the vigilance status/Integrity of the officer as on date, is
pending against the officer. If so, details thereof.
Whether any preliminary inquiry or any other vigilance
related matter is pending against the officer. If so, full facts
ea न नी |
5. | Whether any criminal proceedings were registered against
| the officer during his career so far. If so, details/present
status and the final outcome thereof.
- Whether the name of the officer appears in the Agreed List
or List of Officers of doubtful Integrity. If yes, full details
12 we
7. eee 7 ज
ee ee ae
Whether the officer has ever been debarred from
|. licpeaton? iyen pamdtatamer” ||
=
=
[७]
Yes 7 No
Pi =a नया
a) | APARs
grading of the a
ee ee तन लक कप
i pied Oe eC ee ee Pe ee
a. ee ee eae
pale sa 3
List of
‘@
Signatures of the Officer certifying this proforma
“ss
With Official Seal containing Name & Designation
~~
कं कि कि ast ee es 9. eee अं a de
