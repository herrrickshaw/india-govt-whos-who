---
doc_id: "9cff4ae7552edce0"
source_url: "https://powermin.gov.in/static/uploads/2025/07/133e7724c5a12e0a6b2214a4ca9f8c72.pdf"
ministry: "Power"
title: "Vacancy circular for the post of Chairperson, JERC for Goa and UTs dated 14th October 2020"
date: "2020-10-14"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d551b268c7de4962"
---

<!-- page 1 -->

No. 47/5/2020-R&R
Government of India
Ministry of Power
Shram Shakti Bhavan, Rafi Marg
New Delhi, 14th October, 2020

VACANCY CIRCULAR
The Joint Electricity Regulatory Commission (JERC) for Goa & UTs was set
up by the Government of India under the provisions of the Electricity Act, 2003. The
Commission is located at Gurgaon (Haryana). The Commission consists of a
Chairperson and another Member. The post of Chairperson in the above JERC is
due to fall vacant on 17.9.2021. It is proposed to fill up the anticipated vacancy.
2.
Appointment to the post of Chairperson, JERC for Goa & UTs is governed by
the relevant provisions of the Electricity Act and the Joint Electricity Regulatory
Commission for Union Territories except Delhi (Salary, Allowances and other
Conditions of Service of Chairperson and Member) Rules, 2007. The pay of the
Chairperson has since been revised to Rs.80, 000/- (fixed) p.m in accordance with
6th CPC recommendations. Further, revision of pay subsequent to the 7th Central
Pay Commission recommendation is being undertaken.
3.
Section 84 (1) of the Electricity Act prescribes the qualification for
appointment of a Member (including Chairperson) i.e. “….the Members of the State
Commission shall be persons of ability, integrity and standing who have adequate
knowledge of, and have shown in, dealing with, problems relating to engineering,
finance, commerce, economics, law, or management.”
4.
In view of the Supreme Court Judgment dated 12.4.2018, the selection
process for the vacant post of Member in this JERC from field of law is
underway. Hence, the anticipated vacancy of Chairperson, JERC for Goa and
UTs is required to be filled up from the fields of engineering, finance,
commerce, economics or management.
5.
The Chairperson of JERC for Goa & UTs shall hold office for a term of five
years from the date on which he/ she enters upon his/ her office or till he/ she attains
the age of sixty-five years, whichever is earlier. The candidate will have to give a
declaration that he/she does not have any financial or other interest, which is likely to
affect prejudicially his/her function as Chairperson of the above JERC.
6.
Relevant extracts of the Electricity Act, 2003 relating to the requirement of
qualification, experience, etc. for Member, JERC for Goa & UTs and a copy of Joint
Electricity Regulatory Commission (Salaries, Allowances and other Conditions of

<!-- page 2 -->

Service of Chairperson and Members) Rules, 2007 are attached in the vacancy
circular dated 14.10.2020 available at the website of Ministry of Power i.e.
https://powermin.nic.in/ .
7.
Applications/ nominations are invited in the proforma enclosed at Annexure,
from suitable persons having qualification and experience as mentioned above for
appointment as Chairperson, JERC for Goa & UTs so as to reach this Ministry latest
by 5.30 p.m. on 25.11.2020, addressed to the Director (R&R), Ministry of Power,
2nd Floor (Room No.223), Shram Shakti Bhavan, Rafi Marg, New Delhi – 110001.
The same may also be emailed at sandeep.naik68@gov.in and
debranjan.chattopadhyay@nic.in. The applications/nominations after the last date
shall not be entertained.

Encl: as above
Sd/(D.Chattopadhyay)
Under Secretary to the Government of India
Tel : 23730265

<!-- page 3 -->

Annexure

Application to the post of Chairperson, Joint Electricity Regulatory
Commission (JERC) for Goa and UTs
1. Name of Post

:

Chairperson, JERC for Goa and UTs

2. Date of Vacancy

:

17.09.2021

3. Name of Applicant

:

4. Father’s Name

:

5. Present post held (since……..)

:

6. Date of Birth of Applicant (DD/MM/YYYY)
7. Age of Applicant on date of Vacancy:

:
…Years ……Months……..Days

8. Correspondence Address :
9. Phone Number

:

10. Mobile Number

:

11. Email ID

:

12. Educational Qualification(s) [ In reverse chronological order]

Sl. No. Name of
University/
equivalent
institution

Degree

Year of passing

Subject/specialization

13. Experience ( last 15 years) :
Sl. No.

From

To

(Date)

( Date)

Department/Organization/
Institute

Designation

Experience

<!-- page 4 -->

Any other relevant facts the Applicant may like to share (limited to 500 words):

Note:- copies of certificates and ACRs/APARs should not be enclosed at this stage.
Declaration
1. I …………………. hereby declare that I do not have any financial or other interest,
which is likely to affect prejudicially my function as Chairperson, Joint Electricity
Regulatory Commission (JERC) for Goa and UTs, in the event of my selection.

2. The information furnished above is correct is to the best of my knowledge and belief

and nothing has been suppressed. I understand that in the event of my selection, if it
is found at a later stage that any information furnished above is false or
misrepresented, or any information or fact is suppressed, my selection is liable to be
cancelled.

Place:

Signature:

Date:

Name:

<!-- page 5 -->

Draft No. DFA/52904

Attachment:Service rules 2007.pdf

<!-- page 6 -->

Draft No. DFA/52904

Attachment:Service rules 2007.pdf

<!-- page 7 -->

Draft No. DFA/52904

Attachment:Service rules 2007.pdf

<!-- page 8 -->

Draft No. DFA/52904

Attachment:Service rules 2007.pdf

<!-- page 9 -->

Draft No. DFA/52904

Attachment:Service rules 2007.pdf

<!-- page 10 -->

Draft No. DFA/52904

Attachment:Extract of Act 2003.pdf

Extracts from the Electricity Act 2003
Section 2(64) "State Commission" means the State Electricity Regulatory
Commission constituted under sub-section (1) of section 82 and includes a Joint
Commission constituted under sub-section (1) of section 83;
Section 78. (1) The Central Government shall, for the purposes of selecting the
Members of the Appellate Tribunal and the Chairperson and Members of the Central
Commission, constitute a Selection Committee consisting of –
(a) Member of the Planning Commission
in-charge of the energy sector
…………Chairperson;
(b) Secretary-in-charge of the Ministry of the Central
Government dealing with the Department of
the Legal Affairs
…………. Member;
(c) Chairperson of the Public Enterprises Selection Board
…….. Member;
(d) a person to be nominated by the Central Government
in accordance with sub-section (2)
….. .… Member;
(e) a person to be nominated by the Central Government
in accordance with sub-section (3)
……… Member ;
(f) Secretary-in-charge of the Ministry of the Central
Government dealing with power
.…….. Member.
(2) For the purposes of clause (d) of sub-section (1), the Central Government shall
nominate from amongst persons holding the post of chairperson or managing
director, by whatever name called, of any public financial institution specified in
section 4A of the Companies Act, 1956.
(3) For the purposes of clause (e) of sub-section (1), the Central Government shall,
by notification, nominate from amongst persons holding the post of director or the
head of the institution, by whatever name called, of any research, technical or
management institution for this purpose.
(4) Secretary-in-charge of the Ministry of the Central Government dealing with Power
shall be the Convenor of the Selection Committee.
(5) The Central Government shall, within one month from the date of occurrence of
any vacancy by reason of death, resignation or removal of a Member of the
Appellate Tribunal or the Chairperson or a Member of the Central Commission and
six months before the superannuation or end of tenure of the Member of the
Appellate Tribunal or Member of the Central Commission, make a reference to the
Selection Committee for filling up of the vacancy. the Appellate Tribunal or Member
of the Central Commission, make a reference to the Selection Committee for filling
up of the vacancy.
(6) The Selection Committee shall finalise the selection of the Chairperson and
Members referred to in sub-section (5) within three month from the date on which the
reference is made to it.
(7) The Selection Committee shall recommend a panel of two names for every
vacancy referred to it.
(8) Before recommending any person for appointment as Member of the Appellate
Tribunal or the Chairperson or other Member of the Central Commission, the
Selection Committee shall satisfy itself that such person does not have any financial

<!-- page 11 -->

Draft No. DFA/52904

Attachment:Extract of Act 2003.pdf

or other interest which is likely to affect prejudicially his functions as the Chairperson
or Member.
(9) No appointment of the Chairperson or other Member shall be invalid merely by
reason of any vacancy in the Selection Committee:
Provided that nothing contained in this section shall apply to the appointment of a
person as the Chairperson of the Central Commission where such person is, or has
been , a Judge of the Supreme Court or the Chief Justice of a High Court.
Section 82. (1) Every State Government shall, within six months from the appointed
date, by notification, constitute for the purposes of this Act, a Commission for the
State to be known as the (name of the State) Electricity Regulatory Commission:
Provided that the State Electricity Regulatory Commission, established by a
State Government under section 17 of the Electricity Regulatory Commissions Act,
1998 and the enactments specified in the Schedule, and functioning as such
immediately before the appointed date shall be the State Commission for the
purposes of this Act and the Chairperson, Members, Secretary, and other officers
and other employees thereof shall continue to hold office, on the same terms and
conditions on which they were appointed under those Acts.
Provided further that the Chairperson and other Members of the State
Commission appointed before the commencement of this Act under the Electricity
Regulatory Commissions Act, 1998 or under the enactments specified in the
Schedule, may on the recommendations of the Selection Committee constituted
under sub-section (1) of Section 85 be allowed to opt for the terms and conditions
under this Act by the concerned State Government.
(2) The State Commission shall be a body corporate by the name aforesaid, having
perpetual succession and a common seal, with power to acquire, hold and dispose
of property, both movable and immovable, and to contract and shall, by the said
name, sue or be sued.
(3) The head office of the State Commission shall be at such place as the State
Government may, by notification, specify.
(4) The State Commission shall consist of not more than three Members, including
the Chairperson.
(5) The Chairperson and Members of the State Commission shall be appointed by
the State Government on the recommendation of a Selection Committee referred to
in section 85.
Section 83. (1) Notwithstanding anything to the contrary contained in section 82, a
Joint Commission may be constituted by an agreement to be entered into (a) by two or more Governments of States; or
(b) by the Central Government, in respect of one or more Union territories, and one
or more Governments of States, and shall be in force for such period and shall be
subject to renewal for each further period, if any, as may be stipulated in the
agreement:
Provided that the Joint Commission, constituted under section 21 A of Electricity
Regulatory Commissions Act, 1998 and functioning as such immediately before the
appointed day, shall be the Joint Commission for the purposes of this Act and the
Chairperson, members, Secretary and other officers and employees thereof shall be
deemed to have been appointed as such under this Act and they shall continue to

<!-- page 12 -->

Draft No. DFA/52904

Attachment:Extract of Act 2003.pdf

hold office, on the same terms and conditions on which they were appointed under
the Electricity Regulatory Commissions Act, 1998.
(2) The Joint Commission shall consists of 1 Member from each of the participating
States and Union Territories and the Chairperson shall be appointed from amongst
the Members by consensus, failing which by rotation.
(3) An agreement under sub-section (1) shall contain provisions as to the name of
the Joint Commission, the manner in which the participating States may be
associated in the selection of the Chairperson and Members of the Joint
Commission, manner of appointment of Members and appointment of Chairperson
by rotation or consensus, places at which the Commission shall sit, apportionment
among the participating States of the expenditure in connection with the Joint
Commission, manner in which the differences of opinion between the
Joint Commission and the State Government concerned would be resolved and may
also contain such other supplemental, incidental and consequential provisions not
inconsistent with this Act as may be deemed necessary or expedient for giving effect
to the agreement.
(4) The Joint Commission shall determine tariff in respect of the participating States
or Union Territories separately and independently.
(5) Notwithstanding anything contained in this section, the Central Government may,
if so authorised by all the participating States, constitute a Joint Commission and
may exercise the powers in respect of all or any of the matters specified under subsection (3) and specifically so authorized by the participating States.
Section 84. (1) The Chairperson and the Members of the State Commission shall be
persons of ability, integrity and standing who have adequate knowledge of, and have
shown capacity in, dealing with problems relating to engineering, finance, commerce,
economics, law or management.
(2) Notwithstanding anything contained in sub-section (1), the State Government
may appoint any person as the Chairperson from amongst persons who is, or has
been, a Judge of a High Court:
Provided that no appointment under this sub-section shall be made except
after consultation with the Chief Justice of that High Court.
(3) The Chairperson or any other Member of the State Commission shall not hold
any other office.
(4) The Chairperson shall be the Chief Executive of the State Commission.
Section 85. (1) The State Government shall, for the purposes of selecting the
Members of the State Commission, constitute a Selection Committee consisting of –
(a) a person who has been a Judge of the High Court…. Chairperson;
(b) the Chief Secretary of the concerned State… … … … . ….Member;
(c) the Chairperson of the Authority or
the Chairperson of the Central Commission … … … … .. Member:
Provided that nothing contained in this section shall apply to the appointment of a
person as the Chairperson who is or has been a Judge of the High Court.
(2) The State Government shall, within one month from the date of occurrence of any
vacancy by reason of death, resignation or removal of the Chairperson or a Member
and six months before the superannuation or end of tenure of the Chairperson or
Member, make a reference to the Selection Committee for filling up of the vacancy.

<!-- page 13 -->

Draft No. DFA/52904

Attachment:Extract of Act 2003.pdf

(3) The Selection Committee shall finalise the selection of the Chairperson and
Members within three month from the date on which the reference is made to it.
(4) The Selection Committee shall recommend a panel of two names for every
vacancy referred to it.
(5) Before recommending any person for appointment as the Chairperson or other
Member of the State Commission, the Selection Committee shall satisfy itself that
such person does not have any financial or other interest which is likely to affect
prejudicially his functions as Chairperson or Member, as the case may be.
(6) No appointment of Chairperson or other Member shall be invalid merely by
reason of any vacancy in the Selection Committee.
86. (1) The State Commission shall discharge the following functions, namely: (a) determine the tariff for generation, supply, transmission and wheeling of
electricity, wholesale, bulk or retail, as the case may be, within the State:
Providing that where open access has been permitted to a category of consumers
under section 42, the State Commission shall determine only the wheeling charges
and surcharge thereon, if any, for the said category of
consumers;
(b) regulate electricity purchase and procurement process of distribution licensees
including the price at which electricity shall be procured from the generating
companies or licensees or from other sources through agreements for purchase of
power for distribution and supply within the State;
(c) facilitate intra-state transmission and wheeling of electricity;
(d) issue licences to persons seeking to act as transmission licensees, distribution
licensees and electricity traders with respect to their operations within the State;
(e) promote congenration and generation of electricity from renewable sources of
energy by providing suitable measures for connectivity with the grid and sale of
electricity to any person, and also specify, for purchase of
electricity from such sources, a percentage of the total consumption of electricity in
the area of a distribution licence;
(f) adjudicate upon the disputes between the licensees, and generating companies
and to refer any dispute for arbitration;
(g) levy fee for the purposes of this Act;
(h) specify State Grid Code consistent with the Grid Code specified under clause (h)
of sub-section (1) of section 79;
(i) specify or enforce standards with respect to quality, continuity and reliability of
service by licensees;
(j) fix the trading margin in the intra-State trading of electricity, if considered,
necessary; and
(k) discharge such other functions as may be assigned to it under this Act.
(2) The State Commission shall advise the State Government on all or any of the
following matters, namely :-.
(i) promotion of competition, efficiency and economy in activities of the electricity
industry;
(ii) promotion of investment in electricity industry;
(iii) reorganization and restructuring of electricity industry in the State;
(iv) matters concerning generation, transmission , distribution and trading of
electricity or any other matter referred to the State Commission by that Government.
(3) The State Commission shall ensure transparency while exercising its powers and
discharging its functions.

<!-- page 14 -->

Draft No. DFA/52904

Attachment:Extract of Act 2003.pdf

(4) In discharge of its functions the State Commission shall be guided by the
National Electricity Policy, National Electricity Plan and tariff policy published under
section 3.
Appropriate Commission – Other Provisions
Section 89. (1) The Chairperson or other Member shall hold office for a term of five
years from the date he enters upon his office;
Provided that the Chairperson or other Member in the Central Commission or the
State Commission shall not be eligible for re-appointment in the same capacity as
the Chairperson or a Member in that Commission in which he had earlier held office
as such :
Provided further that no Chairperson or Member shall hold office as such after he
has attained the age of sixty-five years.
(2) The salary, allowances and other terms and conditions of service of the
Chairperson and Members shall be such as may be prescribed by the Appropriate
Government.
Provided that the salary, allowances and other terms and conditions of service of the
Members, shall not be varied to their disadvantage after appointment.
(3) Every Member shall, before entering upon his office, make and subscribe to an
oath of office and secrecy in such form and in such manner and before such
authority as may be prescribed.
(4) Notwithstanding anything contained in sub-section (1), a Member may(a) Relinquish his office by giving in writing to the Appropriate Government a notice
of not less than three months; or
(b) be removed from his office in accordance with the provisions of section 90.
(5) Any member ceasing to hold office as such shall –
(a) not accept any commercial employment for a period of two years from the date
he ceases to hold such office; and
(b) not represent any person before the Central Commission or any State
Commission in any manner.
Explanation. - For the purposes of this sub-section "commercial employment” means
employment in any capacity in any organisation which has been a party to the
proceedings before the Appropriate Commission or employment in any capacity
under, or agency of, a person engaged in trading, commercial, industrial or financial
business in electricity industry and includes a director of a company or partner of a
firm or setting up practice either independently or as partner of a firm or as an
advisor or a consultant.
*****
