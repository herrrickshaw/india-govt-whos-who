---
doc_id: "9db5fe8caa94fc72"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/02e348eb0091fb0f85501bcb71e59c61.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "DoE OM dated 27.06.2024 for Exemption of Railways critical item for train operation under GTE"
date: "2025-07-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3f5eb6dee3aa5a2c"
---

<!-- page 1 -->

No.
F.4/1/2024-PPD
No.F.4/1/2024-PPD
Government
Government of
of India
India
Ministry
Ministry of
of Finance
Finance
Department
Department of
of Expenditure
Expenditure
Procurement
Procurement Policy
Policy Division
Division
*****
*****

OFFICE
OFFICE MEMORANDUM
MEMORANDUM
Subject:
Subject: --

515,
515, Lok
Lok Nayak
Nayak Bhavan,
Bhavan,
Khan Market, New Delhi,
Khan
27.06.2024
27.06.2024

Relaxation
Relaxation under
under Rule
Rule 161(iv)
161(iv) of
of General
General Financial
Financial Rules
Rules 2017
2017 for
for
issuance
issuance of
of Global
Global Tender
Tender Enquiry
Enquiry (GTE)
(GTE) by
by Ministry
Ministry of
of Railways.
Railways.

The
undersigned is
is directed
directed to
to refer
refer Ministry
Ministry of
of Railways
Railways (MoR)
(MoR) 0
D.O.
No.
.0. No.
The undersigned
2020/RS(L)/779/1
2020/RS(L)/779/1 dated
dated 10.06.2024
10.06.2024 regarding
regarding issuance
issuance of
of GTE
GTE under
under Rule
Rule 161(iv}
161(iv)
of GFRs,
GFRs, 2017.
2017.
of
2.
The
2.
The request
request of
of MoR
MoR has
has been
been examined
examined and
and itit has
has been
been decided
decided to
to delegate
delegate
powers
powers to
to approve
approve issuance
issuance of
of GTEs
GTEs for
for the
the tenders
tenders having
having estimated
estimated value
value of
of less
less
than
than Rs
Rs 200
200 crore
crore to
to the
the concerned
concerned Members
Members of
of the
the Railway
Railway Board/
Board/ Chairman
Chairman of
of the
the
Railway
Railway Board
Board only
only with
with respect
respect to
to procurement
procurement of
of Safety
Safety items
items and
and for
for the
the
procurement
which are
procurement of
of items,
items, which
are critical
critical for
for train
train operations.
operations.

3.
3.

This
This issues
issues with
with the
the approval
approval of
of Finance
Finance Secretary.
Secretary.

7%

(SherBahadur)
(SherBahadur)
Under
Under Secretary
Secretary (Procurement
(Procurement Policy)
Policy)
Tel.
Tel. No.
No. 24621304
24621304
Email: sher.bahadur@nic.in

To,
To,
Railway
Railway Board,
Board,
{Kind attention:
attention: Ms.
Ms. Jaya Varma Sinha, Chairman}
{Kind
Ministry
Ministry of
of Railways,
Railways,
New
New Delhi.
Delhi.
Tel.:
Tel.: 23384010,
23384010,
email:
email: crb@rb.railnet.gov.in
crb@rb.railnet.gov.in
Copy
Copy to:
to:
Secretary
(Coordination), Cabinet
Secretary (Coordination),
Cabinet Secretariat,
Secretariat, Rashtrapati
Rashtrapati Bhawan,
Bhawan, New
New Delhi.
Delhi.
