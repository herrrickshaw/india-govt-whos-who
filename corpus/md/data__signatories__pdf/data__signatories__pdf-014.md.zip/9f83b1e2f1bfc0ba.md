---
doc_id: "9f83b1e2f1bfc0ba"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/b8d3f1d6d315ec8b78a1a8d59625f7d4.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment(s) of UAS/ CMTS/ Basic Service Licence Agreement(s) with respect to Annual Licence Fee- Regarding"
date: "2012-06-25"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "df5c88904065d749"
---

<!-- page 1 -->

No.20-281/2010-AS-I (Vol-ID} (Pt.)
Government of India
Ministry of Communications & IT
Department of Telecommunications
(Access Services-I Division)
1203, Sanchar Bhavan, Ashok Road, New Delhi-110001
June 25, 2012
To

All Unified Access Services (UAS) Licensees,

All Cellular Mobile Telephone Service (CMTS) Licensees,

M/s Bharat Sanchar Nigam Limited and

M/s Mahanagar Telephone Nigam Limited
Subject: Amendment(s) of UAS/ CMTS/ Basic Service Licence Agreement(s) with

respect to Annual Licence Fee- Regarding.

In pursuance of the right of Licensor to modify at any time the terms and conditions
of the UAS/ CMTS/ Basic Service LICENCE, in public interest or for the proper conduct
of the SER VICE, the LICENSOR hereby intimate that:

G) A uniform annual licence fee rate of 8% of “Adjusied Gross Revenue (AGR)* shall
be adopted across all categories of service areas (ie. ‘Metro’, “A’, “B’ and °C”
categories) of UAS/ CMTS/ Basic Service licences in two steps starting from
01.07.2012 as follows

| Category of UASL/CMTS/ | Annual Licence Fee rateas %‘AGR’ |

i BASIC Service Licence | es een

| For period from For year 2013-14

| | G1.07.2012 to 31.03.2613 | and onwards

हे व en eee

_Metro/Category *A’ : 4 | b% है

[Category Rr 8% | 8% |

[Category ५ - eine ne ee

(ii) Further. +v.e-f. 01.07.2012, the annual licence fee and annual spectrum usage chia: 2es
payable vy each UAS/ CMTS/ Basic Service licensee shall be on actual ‘AG’,
subject to a minimum presumptive AGR, which shall be announced by the Licensor
every year separately after considering the recommendations of the TRAI which
shall review the figure of minimum presumptive AGR every year.

2. Necessary amendment(s) of respective UAS/ CMTS/ Basic Service Licence
Agreement(s) to above effect will be issued in due course of time.
3 ए / i \ |
3. Please acknowledge receipt. Wade
00:42
(Manish Jain)
ADG (AS-I)
For and on behalf of the President of India
Ph: 2303-6574

<!-- page 2 -->

Copy to:
1, DDG(CS)/ DDG(DS)/ DDG(Security-Term)/DDG(LF-1l)/DDG(LF-ID), DoT
2. Secretary, TRAI
3. Director General (Audit), P&T
4. Secretary, Ministry of Finance
. 5, Director (IT), DoT (to kindly arrange to upload this letter on DoT’s website)
Od
a
nny
“~ lw
ial
