---
doc_id: "a16f6bb47fc3dc6b"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/dd42dc46f336e1acb0b372229f25357d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm 566 of 2025 in Honble High Court of Delhi - 6th Addl. List: DoT instructions dated 06.07.2025 to ISPs"
date: "2025-07-06"
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4fb349221f198a69"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3293305/2025

By Email/DoT Website

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)

No. 813-7/25/2024-DS

Dated: 06-07-2025

To,
All Licensees with Internet Service Authorization

Subject:
CS(COMM) 566/2025: JIOSTAR INDIA PVT. LTD. FORMERLY
KNOWN AS STAR INDIA PVT. LTD. versus HTTPS//CRICLK.COM & ORS. in
the High Court of Delhi.

Please ﬁnd enclosed the Hon’ble
dated 29.05.2025 in the captioned suit.

High

Court

of

Delhi

order

2. Please refer to para 37 (f, g & h) of the said Court order in respect of blocking
access to the websites/domains [ 9 nos.] enumerated in 6th Additional list of
websites received from the plaintiff.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said websites/domains, as above, in compliance with the said Court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i.) Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in); Requested to take action as per the said Court
order/ enclosed Annexure pl.
ii.) Sh. Priyansh Kohli (priyansh@saikrishnaassociates.com), Plaintiﬀ's Counsel for
kind information and requested to take action as per the enclosed Annexure pl.

<!-- page 2 -->

6th List of Additional Websites CS COMM 566/2025]
Websites
https://goalietrend.com/
https://livesport.su/
https://premiertv.live/
https://premiertv.watch/
https://qatarstreams.vip/
https://scorebiz.xyz/
https://soliv.online/
https://live.incableinternet.com
https://userr2338aaaab.cloudycx.net

<!-- page 3 -->

URGENT | DOT and MEITY | Sixth List of Additional Websites for Real – Time Blocking of in Compliance of the Order dated
29.05.2025 passed by the Hon’ble Delhi High Court in JioStar India Private Limited Formerly known as Star India Private
Limited vs. https//criclk.com & Ors. CS(COMM)- 566/2025
14 emails

Priyansh Kohli < priyansh@saikrishnaassociates.com >
Sun, 06 Jul 2025 12:55:48 PM +0530

To "secy-dot"<secy-dot@nic.in>,"Ram Meena"<dirds2-dot@nic.in>,"Abhinesh Meena"<jto2ds2-dot@gov.in>,"Cyber Law
Legal"<cyberlaw-legal@meity.gov.in>,"Dr. Sandip Chatterjee"<gccyberlaw@meity.gov.in>,"Prafulla Kumar"
<pkumar@meity.gov.in>,"sathya.s"<sathya.s@meity.gov.in>
Cc "Yatinder Garg"<yatinder@saikrishnaassociates.com>,"ashok.yadav1@jiostar.com"<Ashok.Yadav1@jiostar.com>

Dear Sir,
We act on behalf of JioStar India Private Limited (‘Star’) (hereinafter referred to as “Our Client”). Our Client is the Plaintiff in
the above-captioned suit.
Our Client has acquired inter alia, the Exclusive Rights in the India Tour of England 2025 for term commencing from May
2025 through December 2026. These Rights include but are not limited to the live, delayed, highlights, clips and repeat
exhibition of various sporting events, over which the Plaintiff has Exclusive Rights, through various platforms for viewing on
various devices such as computers, laptops, mobile phones, tablets etc.
Our Client has instituted the above-captioned Suit against various ‘rogue’ websites inter alia the Defendant Nos. 1 to 4 before
the Hon’ble High Court of Delhi, inter alia, seeking permanent and ex-parte ad-interim and temporary injunction restraining
infringement of their Broadcast Reproduction rights arising on account of illegal communication of the sporting events by
Plaintiff without any permission as well as for other reliefs.
Our Client has also arrayed various Domain Name Registrars (Defendant No.5 - 7), Internet and Telecom Service Providers
(ISPs / TSPs), (Defendant No. 8 – 16), as well as the concerned Government departments i.e. Department of
Telecommunication (DoT) (Defendant No.17) and the Ministry of Information and Technology (MEITY) (Defendant No.18),
to ensure effective compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Mr. Justice Saurabh Banerjee, Delhi High Court on 29.05.2025, on
which date, the Hon’ble Court was pleased to issue notice to you and was also pleased to pass an ex-parte ad-interim order in
terms of Prayer Clause 13 in terms of application under Order XXXIX Rules 1 and 2. The relevant para of the Order dated
29.05.2025 is extracted herein below:
37. Accordingly, in view of the aforesaid, as also keeping in mind the existing position of law, as also to keep pace with the
changing times coupled with the changing technology, till the next date of hearing:
a.
Any person/ entity including, but not limited to, the defendant nos.1 to 4 being “rogue websites”, as also their
owners, partners, officers, and all others in capacity of principal or agent acting for and on their behalf, or anyone
claiming through, by or under them, are restrained from communicating, streaming, and / making available for
viewing and downloading, any part of the India Tour of England 2025 matches on any electronic or digital
platform in any manner whatsoever without authorization, so as to infringe the plaintiff’s intellectual property
rights qua India Tour of England 2025;
b.
Defendant no.5 being DNR namely Namecheap,Inc. is directed to block and suspend the websites
https://criclk.com and https://hesgoaled.com within 72 hours, after being supplied with a copy of this order by the
learned counsel for the plaintiff;
c.
Defendant no.6 being DNR namely Sav.com, LLC is directed to block and suspend the website
https://vod.mafiatv.live within 72 hours, after being supplied with a copy of this order by the learned counsel for the
plaintiff;
d.
Defendant no.7 being DNR namely Tucows Domains INC. is directed to block and suspend the website
https://s19.24cwc.com within 72 hours, after being supplied with a copy of this order by the learned counsel for the
plaintiff;
e. Defendant nos.5 to 7 being the DNRs are also directed to provide details of the registrants of the “rogue websites”
such as their names and contact details upon being requested by the learned counsel for the plaintiff;

<!-- page 4 -->

f.
Defendant nos.8 to 16 being the ISPs are also directed to block access to the abovenamed “rogue websites” as
mentioned in para 26 above, within 72 hours, after being supplied with a copy of this order by the learned counsel for
the plaintiff;
g.
‘Dynamic+’ injunction is granted in favour of the plaintiff to protect its copyrighted works as soon as they are
infringed/ created. Consequently, during the streaming of the ITE 2025 if, any further websites, such as mirror/
redirect/ alphanumeric variations of the “rogue websites” are discovered which are illegally streaming and
communicating content over which the plaintiff has rights, the plaintiff will be at liberty to communicate the details
of these websites to their concerned DNRs, if available, or in the alternative to the defendant nos.8 to 16 being the
ISPs for blocking the said websites. As such, upon receiving the said intimation from the plaintiff, the concerned
ISP(s) shall take steps to immediately block the said “rogue websites” on real time basis;
h.
Defendant nos.17 and 18 shall take steps to ensure that defendant nos.8 to 16, being the ISPs, comply with the
aforesaid directions, through appropriate communications and notices sent to the said ISPs which are registered
with them;
i.
However, after communicating the details of the “rogue websites” in terms of the above, the plaintiff shall
continue to file affidavits with this Court in order to ensure that this Court is informed of the said “rogue websites”.
In light of the above, the list of additional rogue websites discovered till date during the India Tour of England 2025 is
attached herewith. These websites are illegally streaming and communicating the India Tour of England 2025 over which Our
Client has exclusive rights.
You are hereby requested to comply with the order dated 29th May 2025 by immediately issuing notification to all the ISPs to
block access to the identified rogue websites during the course of the match, on a real-time basis so that there is no delay.
For your convenience, the Order dated 29th May 2025 is re-attached herewith.
List of the additional websites is also enclosed herewith and the evidence against the websites is available in the link below:
https://drive.google.com/drive/folders/152mbo7h6Vj7Tv80YjK3BiKdDzD3Ug3Hj?usp=sharing
You are hereby requested to confirm immediate compliance of the Order by issuing notification to all the ISPs.
If you have any queries regarding
priyansh@saikrishnaassociates.com

this

matter,

please

feel

free

to

reach

out

to

the

following:

Please acknowledge a safe receipt.
Sincerely,
Priyansh Kohli
Saikrishna & Associates
Counsels for JioStar India Private Limited
Priyansh Kohli | Associate | Saikrishna & Associates, 57, Jorbagh, New Delhi - 110003, India | Tel: +91-1140244360 | Handphone: +91-7987503554 | Enrolment Number - D/2514/2022
The Information contained in this e-mail and/or in any of the attached files is confidential and proprietary information of
Saikrishna & Associates and also the subject of legal professional privilege. This privilege is not waived or lost by mistaken
transmission or receipt. If you are not the intended recipient, any use, disclosure or copying of this mail is unauthorised. If
you have received this mail in error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original.

2 Attachment(s)
Order dated 29.05.2025.pdf

6th Addl List.xlsx

251.5 KB

13 KB

Cyber Law Legal < cyberlaw-legal@meity.gov.in >
Fri, 04 Jul 2025 11:36:17 AM +0530

<!-- page 5 -->

$~50
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 566/2025
JIOSTAR INDIA PVT. LTD. FORMERLY KNOWN
AS STAR INDIA PVT. LTD.
.....Plaintiff
Through: Mr. Sidharth Chopra, Mr. Yatinder
Garg and Mr. Priyansh Kohli,
Advocates
Versus
HTTPS//CRICLK.COM & ORS.
.....Defendants
Through: None.
CORAM:
HON'BLE MR. JUSTICE SAURABH BANERJEE

ORDER
%
29.05.2025
I.A. 14086/2025 (Exemption from pre-litigation mediation)
1.

Vide the present application under Section 12A of the Commercial

Courts Act, 2015, read with Section 151 of the Code of Civil Procedure,
1908 (CPC), the plaintiff seeks exemption from pre-litigation mediation.
2.

Considering the averments made in the present application, as also

since the plaintiff is seeking ex parte ad interim injunction in an
accompanying application, and in view of the judgment passed by the
Hon’ble Supreme Court in Yamini Manohar v. T.K.D. Krithi 2024 (5)
SCC 815, which has been followed by a Division Bench this Court in
Chandra Kishore Chaurasia v. R. A. Perfumery Works Private Limited
2022:DHC:4454-DB, the plaintiff is exempted from instituting prelitigation mediation.
3.

Accordingly, the present application stands disposed of.

CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 1 of 13

<!-- page 6 -->

I.A. 14084/2025 (Exemption from advance service to defendants)
4.

Vide the present application under Section 151 of the CPC, the

plaintiff seeks exemption from advance service upon the defendant nos.9,
12, 17 and 18.
5.

Vide the present application filed under Section 80, read with

Section 151 of the CPC, the plaintiff seeks exemption from the
requirement of advance service upon the defendant nos.9 and 12, namely
Bharat Sanchar Nigam Ltd. (‘BSNL’) and Mahanagar Telephone Nigam
Ltd. (‘MTNL’) respectively and defendant nos.17 and 18, namely
Department of Telecommunications (‘DoT’) and Ministry of Electronics
and Information Technology (‘MEITY’) respectively, on the ground that
no formal remedy/ relief as prescribed under the Copyright Act, 1957
(‘Act of 1957’), is being claimed against them, as also since they are only
being arrayed to ensure compliance with any orders that may be passed by
this Court.
6.

For the reasons stated in the present application, as also taking into

account the aforesaid factors, and since it would be in the interest of
justice, the plaintiff is granted exemption from effecting advance service
upon the aforesaid defendant nos.9, 12, 17 and 18.
7.

Accordingly, the present application stands disposed of.

I.A. 14085/2025 (Additional documents)
8.

Vide the present application under Order XI Rule 1(4) read with

Section 151 of the CPC, the plaintiff seeks leave of this Court to file
additional documents.
9.

The plaintiff will be at liberty to file additional documents at a later

stage, albeit, after initiating appropriate steps, strictly as per the provisions
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 2 of 13

<!-- page 7 -->

of the Commercial Courts Act, 2015 read with Section 151 of the CPC and
the Delhi High Court (Original Side) Rules, 2018.
10.

Accordingly, the present application stands disposed of.

CS(COMM) 566/2025
11.

The plaintiff, by way of the present plaint, seeks permanent

injunction, rendition of account, damages for infringement of copyright
under the Act of 1957, as also appropriate directions to the arrayed
authorities.
12.

Let the plaint be registered as a suit.

13.

Upon filing of the process fee, issue summons of the suit to the

defendants through all permissible modes returnable before the learned
Joint Registrar on 01.09.2025.
14.

The summons shall state that the written statement(s) be filed by the

defendants within a period of thirty days from the date of the receipt of the
summons. Written statement(s) be filed by the defendants along with
affidavit of admission/ denial of documents of the plaintiff, without which
the written statement(s) shall not be taken on record.
15.

Replication(s) thereto, if any, be filed by the plaintiff within a

period of fifteen days from the date of receipt of written statement(s). The
said replication(s), if any, shall be accompanied by with affidavit of
admission/ denial of documents filed by the defendants, without which the
replication(s) shall not be taken on record within the aforesaid period of
fifteen days.
16.

If any of the parties wish to seek inspection of any document(s), the

same shall be sought and given within the requisite timelines.
17.

List before the learned Joint Registrar for marking exhibits of

CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 3 of 13

<!-- page 8 -->

documents on 01.09.2025. It is made clear that if any party unjustifiably
denies any document(s), then it would be liable to be burdened with costs.
I.A. 14083/2025 (Order XXXIX Rule1 and 2 CPC)
18.

The present application under Order XXXIX, Rules 1 and 2 of the

CPC has been filed by the plaintiff seeking the following reliefs:
i.
Pass an order of temporary injunction restraining the
Defendant Nos. 1 to 4 (and such other websites which are discovered
during the course of the proceedings and notified on Affidavit by the
Plaintiff to have been infringing the Plaintiff’s exclusive Media Rights
and broadcasting rights), their owners, partners, officers, and all
others in capacity of principal or agent acting for and on their behalf,
or anyone claiming through, by or under it, from in any manner
communicating, hosting, streaming, and/or making available for
viewing and downloading, without authorization, on their websites or
other platforms, through the internet in any manner whatsoever, the
Plaintiff’s content related to India Tour of England 2025, so as to
infringe the Plaintiff’s exclusive Media Rights;
ii.
Pass an order directing Defendant Nos. 5 to 7, its directors,
partners, officers, affiliates, and all others in capacity of principal or
agent acting for and, on their behalf, or anyone claiming through, by or
under it, to suspend the domain name registration of the Defendant
Nos. 1 – 4, as well as any additional infringing websites discovered
during the course of the India Tour of England 2025 matches and
notified by the Plaintiff on Affidavit on real time basis. Specific Domain
Name Registrars for each website are disclosed under para 44 of the
Plaint.
iii.
Pass an order interim injunction directing the Defendant Nos.
5- 7 to disclose the following information of the Defendant Nos. 1 – 4
(and such other websites which are discovered during the course of the
proceedings and notified on Affidavit by the Plaintiff to have been
infringing the Plaintiff’s exclusive Media Rights and broadcast
reproduction rights):
a)
Complete details such as name, address, email address,
phone number, IP address etc.
b) Mode of payment along with payment details used for
registration of domain name by the registrant(s).
iv.

Pass a temporary order directing the Defendant Nos. 8 to 16,

CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 4 of 13

<!-- page 9 -->

their directors, partners, proprietors, officers, affiliates, servants,
employees, and all others in capacity of principal or agent acting for
and on their behalf, or anyone claiming through, by or under it, to
block access to the various websites identified by the Plaintiff in the
instant suit (at S. No. 1 of the Documents), as well as any additional
infringing websites discovered during the course of the India Tour of
England 2025 matches and notified by the Plaintiff on Affidavit on
real time basis.
v.
Pass an order directing the Defendant Nos. 17 and 18 to issue a
notification calling upon the various internet service providers
registered under it to block access to the various websites identified
by the Plaintiff in the instant suit (at S. No. 1 of the Documents), as
well as any additional infringing websites discovered during the
course of the India Tour of England 2025 matches and notified by the
Plaintiff on Affidavit on real time basis;

19.

As per pleading, the plaintiff/ JioStar India Private Limited

(formerly known as Star India Private Limited) is a company incorporated
under the Companies Act, 1956, having its registered office at Star House,
Urmi Estate, 95, Ganpatrao Kadam Marg, Lower Parel (West) Mumbai
400013 and also has a local office at Vatika Business Centre, Thapar
House, Gate No.1, Eastern & Central Wing, 3rd Floor, 124 Janpath, New
Delhi 110001.
20.

The plaintiff is a leading entertainment and media company in India

engaged, inter alia, in the production of popular content broadcasted on its
channels. The plaintiff is also an exclusive right owner for several work
broadcasted on its channels. The plaintiff, along with its affiliates, is also
an exclusive right owner for several works broadcasted on its channels,
such as, Star Sports 1, Star Sports 2, Star Sports HD 1, Star Sports Select
1, Star Sports 2 HD, Star Sports Select HD 1, Star Sports Khel, Star
Movies, Colors Infinity, Star Bharat, Star Gold, Jalsha Movies, Maa
Movies, Star Plus, Colors, Colors Rishtey, VH1, MTV, Disney Channel,
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 5 of 13

<!-- page 10 -->

National Geographic, etc., and many of such channels broadcast sporting
events in the fields of Cricket, Football, Formula1, Badminton, amongst
others.
21.

The plaintiff, vide Sub-Licensing Agreement dated 25.05.2025, has

acquired exclusive digital media rights with respect to the India Tour of
England 2025 (‘ITE 2025’), for a period of two years, commencing from
2025, from Culver Max Entertainment Pvt Ltd (‘Sony’/‘Licensor’), who
had originally acquired exclusive television and digital broadcasting rights
for all England cricket properties organised by the England Cricket Board
(‘ECB’) for the territories of India, Sri Lanka, Afghanistan, Maldives and
Nepal for the eight-year period starting from 2024 to 2031.
22.

By virtue of the aforesaid arrangement between the plaintiff and

Sony, it has been agreed that the ITE 2025 matches will be made available
for digital streaming on the plaintiff’s OTT platform, i.e., ‘JioHotstar’.
23.

In light of the above, the plaintiff, being a right holder of “original

works” as envisaged under Section 37 of the Act of 1957, is entitled to the
protection available therein.
24.

The cause of action first arose on 26.05.2025, when defendant nos.1

to 4 being “rogue websites” unlawfully streamed sporting events in which
the plaintiff had exclusive rights, without the authorisation from the
plaintiff or the owner of rights of the said sporting events, such as the
Indian Premier League, 2025 (‘IPL’). Moreover, the cause of action is a
continuous one as, seeing the precedent of unlawful activity and also that
their very business model appears to be illegally streaming content in
which third-parties have exclusive rights, the plaintiff has full conviction
that the said “rogue websites” will once again indulge in illegal streaming
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 6 of 13

<!-- page 11 -->

of the upcoming ITE 2025 matches which are scheduled between June
and August 2025, wherein the Indian National Cricket Team will tour
England to play a five-match Test series against the England National
Cricket Team and apprehends that irreparable harm will be caused to the
plaintiff, if it is not granted an ex parte ad interim injunction against the
said “rogue websites” and their aids at the earliest.
25.

The defendant nos.5 to 7 being Domain Name Registrars (DNRs)

with respect to the said “rogue websites” are entities which are engaged in
the business of registering and hosting domain names. The plaintiff has
arrayed these DNRs to ensure effective implementation of any reliefs that
may be granted, including suspension of domain names and disclosure of
information of registrants of the “rogue websites”. For ease of reference,
the list of such rogue websites and respective DNRs are as follows:

26.

Since defendant nos. 8 to 16 are Internet Service Providers (ISPs)

and, hence are instrumental in the functioning of the said “rogue
websites”, being responsible for provision of internet services across India,
they have been arrayed as such. The said defendants have the
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 7 of 13

<!-- page 12 -->

responsibility to ensure that no violation of third-party intellectual
property rights takes place through their networks. The DoT and the
MEITY have also been arrayed as defendant nos.17 and 18 respectively,
for the purposes of assistance and ensuring compliance with any orders
that may be passed by this Court.
27.

John Doe has also been arrayed as Defendant No.19 in the form of a

generic identity, to safeguard the plaintiff’s right against infringement by
any unidentified or “rogue websites” that may be discovered at a later
stage, or that may emerge suddenly even during the live telecast of the
India Tour of England 2025 matches, with the intent to unlawfully make
available the plaintiff’s content.
28.

The learned counsel for the plaintiff submits that in cases of live

sporting events such as the present ITE 2025 is concerned, these “rogue
websites” activates new domains/ websites and URLs just minutes before
a match and later deactivate them as soon as it ends. The same was the
modus operandi followed by these websites during IPL 2025. Considering
this, if the blocking of the domains does not occur within minutes of
notification, the exclusive rights of the plaintiff as also their remedies get
diluted, eroded, and effectively rendered redundant.
29.

This Court has heard the submissions advanced by the learned

counsel for the plaintiff and perused the documents filed along with the
plaint.
30.

In effect, the plaintiff is seeking a ‘dynamic+’ injunction, a form of

injunctive relief which is being granted by Court(s) in similar matters in
the recent years, primarily with a view to protect parties like the plaintiff
herein against rapidly developing online infringement platforms. For
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 8 of 13

<!-- page 13 -->

instance, the Bombay High Court, in a case bearing no.I.A. (Lodging)
10257/2023 entitled Applause Entertainment Private Limited v. Meta
Platforms Inc. & Ors., which was a case involving audio-visual extracts
of certain “web-series” being streamed illegally on multiple platforms,
granted real time relief in the form of a ‘dynamic+’ injunction to the
plaintiff therein. Similarly, a Coordinate Bench of this Court in Universal
City Studios LLC v. Dotmovies.baby 2023:DHC:5842 has, also while
granting such a ‘dynamic+’ injunction, observed that any injunction
granted by this Court ought to be effective in nature.
31.

Therefore, the position of law apparent therefrom, which has since

developed with the passage of time, clearly reflects that the rights of a
plaintiff, who is an intellectual property right holder, cannot be rendered
otiose in this world of rapidly developing technology and for that,
enforcement of intellectual property rights on any social platform,
including but not limited to, the internet as well alongwith the real world,
ought to be visible and effective.
32.

The upcoming technology and the technological advances

association

therewith,

have

their

own

implication(s)

and/

or

ramification(s), which are not only reachable far and wide, but are also
unpredictable. With the immense degree of freedom enjoyed by
developers and innovators globally today, all and sundry, especially those
intellectual property right holders like the plaintiff herein, are prone to/
may be exposed and/ or vulnerable to the actions of the “rogue websites”
herein, more so, if such right holders like the plaintiff herein, are not
accorded proper protection from them. On one hand, though such
intellectual property right holders like the plaintiff herein, can proceed in
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 9 of 13

<!-- page 14 -->

the normal manner, however, on the other hand, without any proper
channelization, their intellectual property rights are prone to get effected
by such “rogue websites”, who have no right, title and/ or interest therein.
This would lead them and their facilitators to freely and blatantly exploit
the rights of the right holders like the plaintiff herein, causing irreparable
loss, damage and injury to them as also leaving them struggling on the
fence exposed dangerous edge of technology.
33.

This so-called dangerous edge has become even sharper with the

fast-paced evolution of certain “hydra-headed” websites, which, even if
blocked/ deleted, have the incredulous potential to resurface in multitudes
as alphanumeric or mirror websites, with only minor, mechanical changes
within seconds. Such “hydra-headed” websites, under the garb of privacy,
are able to mask their registration/ contact details perfectly, making it
virtually impossible to locate and contact their operators to, if necessary,
demand cessation of infringing conduct.
34.

In essence, as per the case set up by the plaintiff, the “rogue

websites” are in flagrant infringement/ facilitation of infringement as is
evident from the unabashed streaming of the copyrighted content on such
“rogue websites”, of which the plaintiff herein, is the right holder.
Moreover, the systematic, organised and intentional nature of the
infringement, and the regularity and consistency with which the said
content is being updated/ uploaded on the said “rogue websites” shows
the extent of the violation of the rights of the plaintiff in real time. The
said “rogue websites” are also employing the URL-redirection and
identity masking methods as noted above, putting the plaintiff in an even
more precarious condition to defend itself against their infringing actions.
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 10 of 13

<!-- page 15 -->

In these circumstances, the present case appears, prima facie, to be a clear
example of copyright infringement by entities such as defendant Nos.1 to
4, who are using modern technology to hide their identities while
unlawfully benefiting from the plaintiff’s copyrighted works.
35.

Thus, in light of the violations already committed by the “rogue

websites” by unauthorized streaming of the plaintiff’s copyrighted works
during the ongoing ‘IPL’, this Court sees every likelihood that such
“rogue websites” will continue to stream copyrighted works to the public
during the ITE 2025 without authorization or license from the plaintiff.
36.

Therefore, the plaintiff has been able to make out a prima facie case

in its favour and against the defendants and the balance of convenience is
also tilting towards grant of relief in favour of the plaintiff. If an ex parte
ad interim injunction in favour of the plaintiff is not granted, the plaintiff
will likely suffer irreparable loss and injury.
37.

Accordingly, in view of the aforesaid, as also keeping in mind the

existing position of law, as also to keep pace with the changing times
coupled with the changing technology, till the next date of hearing:
a.

Any person/ entity including, but not limited to, the defendant

nos.1 to 4 being “rogue websites”, as also their owners, partners,
officers, and all others in capacity of principal or agent acting for
and on their behalf, or anyone claiming through, by or under them,
are restrained from communicating, streaming, and / making
available for viewing and downloading, any part of the India Tour
of England 2025 matches on any electronic or digital platform in
any manner whatsoever without authorization, so as to infringe the

CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 11 of 13

<!-- page 16 -->

plaintiff’s intellectual property rights qua India Tour of England
2025;
b.

Defendant no.5 being DNR namely Namecheap,Inc. is

directed to block and suspend the websites https://criclk.com and
https://hesgoaled.com within 72 hours, after being supplied with a
copy of this order by the learned counsel for the plaintiff;
c.

Defendant no.6 being DNR namely Sav.com, LLC is directed

to block and suspend the website https://vod.mafiatv.live within 72
hours, after being supplied with a copy of this order by the learned
counsel for the plaintiff;
d.

Defendant no.7 being DNR namely Tucows Domains INC. is

directed to block and suspend the website https://s19.24cwc.com
within 72 hours, after being supplied with a copy of this order by
the learned counsel for the plaintiff;
e.

Defendant nos.5 to 7 being the DNRs are also directed to

provide details of the registrants of the “rogue websites” such as
their names and contact details upon being requested by the learned
counsel for the plaintiff;
f.

Defendant nos.8 to 16 being the ISPs are also directed to

block access to the abovenamed “rogue websites” as mentioned in
para 26 above, within 72 hours, after being supplied with a copy of
this order by the learned counsel for the plaintiff;
g.

‘Dynamic+’ injunction is granted in favour of the plaintiff to

protect its copyrighted works as soon as they are infringed/ created.
Consequently, during the streaming of the ITE 2025 if, any further
websites, such as mirror/ redirect/ alphanumeric variations of the
“rogue websites” are discovered which are illegally streaming and
communicating content over which the plaintiff has rights, the
CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 12 of 13

<!-- page 17 -->

plaintiff will be at liberty to communicate the details of these
websites to their concerned DNRs, if available, or in the alternative
to the defendant nos.8 to 16 being the ISPs for blocking the said
websites. As such, upon receiving the said intimation from the
plaintiff, the concerned ISP(s) shall take steps to immediately block
the said “rogue websites” on real time basis;
h.

Defendant nos.17 and 18 shall take steps to ensure that

defendant nos.8 to 16, being the ISPs, comply with the aforesaid
directions, through appropriate communications and notices sent to
the said ISPs which are registered with them;
i.

However, after communicating the details of the “rogue

websites” in terms of the above, the plaintiff shall continue to file
affidavits with this Court in order to ensure that this Court is
informed of the said “rogue websites”.
38.

Upon filing of process fee, issue notice to the defendant nos.1 to 8,

10, 11, 13 to 16, and 19 through all permissible modes, including through
email, returnable before the Court on 13.10.2025.
39.

Reply be filed within four weeks. Rejoinder thereto, if any, be filed

within two weeks thereafter.
40.

The provisions of Order XXXIX Rule 3 of the CPC be complied

with within one week.
41.

List before Court on 13.10.2025.

SAURABH BANERJEE, J
MAY 29, 2025/So

CS(COMM) 566/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 31/05/2025 at 21:00:47

Page 13 of 13

<!-- page 18 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
