---
doc_id: "9daad0bbe6beacdb"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_6956408c2236b7.41344331.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Notification - Shri Enyiwekha Wezah, '01 (One)' officer of the State Forest Service of Nagaland appoint to the Indian Forest Service and to allocate them to Nagaland Cadre of Indian Forest Service, notification dated 31-12-2025"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "1c46bb8fc4d76dc8"
---

<!-- page 1 -->

|
|
To be published in Part I Section 2 of the Gazette of India)
F. No. 17013/11/2024-IFS-IT . :
Government of India :
Ministry of Environment, Forest & Climate Change
Indira Paryavaran Bhawan,
6th floor, Prithvi Block,
Jor Bagh Road, Ali Ganj, New Delhi-110003
Dated: 315 December, 2025.
Notification
In exercise of the provisions conferred by Rule 8 of the Indian Forest Service (Recruitment)
Rules, 1966, read with sub-regulations (1) of Regulation 9 of the Indian Forest Service (Appointment
by Promotion) Regulation,1966, the President is pleased to appoint with immediate effect the
following ‘01(One)' officer of the State Forest Service of Nagland to the Indian Forest Service on the
basis of inclusion of their name in the Select List 2023 by the Selection Committee in its meeting
held on 19.09.2025, and to allocate them to Nagaland Cadre of Indian Forest Service under sub-rule
(1) of Rule 5 of the Indian Forest Service (Cadre) Rules, 1966:
Select List 2023
|
Yours faithfully,
Ce ~ ~ ie yn
See
AO o क
(Prem Ptakash Maurya’
Under Secretary to the Government of India
Tel:011-20819192
To,
The Manager,
Government of India Press,
Minto Road, New Delhi.
Copy to:
1.The Chief Secretary, Government of Nagaland, Kohima.
2. The Principal Secretary (Forests), Government of Nagaland, Kohima. The proposal for year of
allotment of the officer may be sent to this Ministry for further necessary action in prescribed
proforma (Enclosed).
3. The Principal Chief Conservator of Forests (HoFF), Nagaland, Kohima .
4. The Secretary, Union Public Service Commission, New Delhi.
5. Officer concerned (through the Government of Nagaland, Kohima)
6. Hindi Section for Hindi translation of Notification.
7. Guard file/Website copy.
rio.

<!-- page 2 -->

Proforma for Determination of Year of Allotment
S.N.|Name of Officer [Date of Completed |Total [Proposed |Placement in the
\(Shri/Smt) & jappointment| years of |Weightagelyear ofjSeniority List
(Select List) in SFS as an | service as allotment
\Assistant on 31st day las per]
\Conservator of weightage
lof Forest December
of the year
for which
meeting of
selection
committee
was held.
|
|
————————— a eee
Po फछ£$७ छ / |
न eee
[रु Ee
Pee |
Pop ७ ७€ल्‍_्ऊ्[_/ ७  उऑऑ्ऊ<_+/#/ ्र्1ऊ+/+/$ [- |
[कई छ/_/  (_ रऑ#छ£$£#ऋऑऊऑ/#॒ऊझऑ1झऊ+/ |
शि््फ्किररषत एफ न
(कर नि ् टलईल ७ उईझऋ£/# ऑ/़/£/#$ऋ ऑक्‍फउऑऋ$_€/#/#$ऊ3/3खऊ।
A ई(ईर् #़ऋ्ऋ्#़़््च़+ फईफ्फ्रप|[_ [_ ६ |
[तक कई रऊढठिद$$झऊ/ऋ ऊऋऋऋ  ्  क/
