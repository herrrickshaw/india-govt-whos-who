---
doc_id: "9eb0d5cade7d655f"
source_url: "https://powermin.gov.in/static/uploads/2025/07/6707002ce4d43a15e45bfa8ed6699865.pdf"
ministry: "Power"
title: "Adequate Safeguards regarding para 2.1(b) of the approval of the Govt. on the recommendations of Group of Ministers (GoM)"
date: "2019-09-03"
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8e6e1e0636d0a2c6"
---

<!-- page 1 -->

ce
i
OD
सत्वमेव जयते
No. L-2/2018-IPC(Part-4)
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg,
New Delhi, dated 30.08.2019
OFFICE MEMORANDUM
Sub: Approval of the Government on the recommendations of Group of Ministers
(GoM) constituted to examine the specific recommendations of High Level Empowered
Committee (HLEC) constituted to address the issues of Stressed Thermal Power
Projects.
The undersigned is directed to refer to para no. 2.1(b) of OM no. L-2/2018-IPC(Part-
4) dated 08.03.2019 of this Ministry (copy enclosed) on the ‘Approval of the Government on
the recommendations of Group of Ministers (GoM) constituted to examine the specific
recommendations of High Level Empowered Committee (HLEC) constituted to address the
issues of Stressed Thermal Power Projects’ which is as follows:
“2.1(b): A generator which terminates PPA in case of default in payment by the
DISCOM, may be allowed to use existing linkage coal for sale of power through short-
term PPAs using DEEP portal or power exchange for a period of maximum 2 years or
until they find another buyer of power under long/medium term PPA whichever is
earlier. Adequate safeguards to be put in place.”
2. Based on the deliberations held in the meeting chaired by Secretary (Power) on
28.08.2019 with Ministry of Coal, Railway Board, Central Electricity Authority, Coal India
Limited and NTPC, it has been decided that the following “Adequate Safeguards” shall be
taken by all the concerned:

i. The reason for cancellation of the Power Purchase Agreement (PPA) shall be
“default in payment” by the DISCOM as per the provisions of the PPA.

ii. A generator which terminates PPA in case of default in payment by the
DISCOM, shall not be allowed to sale power bilaterally but only through DEEP
portal or power exchange at market determined price for a period of maximum
two years.

iii. The existing Letter of Assurance (LOA)/ Fuel supply Agreement (FSA)
conditions shall continue for further period of maximum 2 years. If required,
necessary modifications shall be made in the existing LOA/FSA.

iv. Linkage after the period of maximum 2 years shall be cancelled in case generator
is not able to secure a long/medium term PPA during that period.

<!-- page 2 -->

v. In case of Long term PPA such provision shall not be applicable during the
terminal 2 years of PPA.
3. This issues with the approval of the Competent Authority.
Encl: as stated Vex
(5. )
Under Secretary to the Govt. of India
Tel: 2335 6938
To,
1. Secretary, Ministry of Coal
2. Chairperson, Central Electricity Authority
3. Chairman, Railway Board
4. CMD, NTPC
5. Chairman, DVC
6. CMD, PFC
7. CMD, REC
8. CMD, PGCIL
9. CMD, CIL
10. Director General, APP
Copy to: Additional Chief Secretaries/Principal Secretary/Secretary (Energy) of State Govt.
(As per list)
Copy to: Technical Director NIC for posting on website of MoP

<!-- page 3 -->

List_of Additional Chief Secretary (Energy)/ Principal Secretary (Energy)/ Secretary

(Energy) of all States/ UTs

1. Shri Ajay Jain, Principal Secretary (Power), Room No. 147, Ground floor, 2nd -Block,
AP. Secretariat, Velagapudi, Guntur, Andhra Pradesh-522503

2. Shri P. Ravi Kumar, Addl. Chief Secretary(Energy) Government of Karnataka, Vikasa
Soudha, Bangalore-560001

3. Md Nasimuddin, Pr. Secretary(Energy), Government of Tamil Nadu, Fort St. George,
Sectt., Chennai-600009

4. Shri. Ajay Mishra, Special Chief Secretary (Energy), R. No. 433, D-Block, 3rdFloor,
Telangana Secretariat, Hyderabad-500022

5. Shri NeerajVerma, Principal Secretary (Power) Government of Assam, Assam
Sachivalaya, Block-C, 3rd Floor, Dispur-781006

6. Sh. Pratyaya Amrit, Pr. Secretary(Energy), Government of Bihar, 8, Darogaroy
Path,Patna-800001

7. Shri Sunil Kumar Gupta, Principal Secretary, D/o Power & NCES, Government of West
Bengal, Bidyut Unnayan Bhawan, Sth Floor, 3/C LA Block-III, Saltlake City, Kolkata-
700098.

8. Sh. Alok Kumar, Principal Secretary (Power), Government of Uttar Pradesh, Babu
Bhawan, R. No. 104, Lucknow-226001

9. Sh. Arvind Singh, Principal Secretary (Energy), Government of Maharasthra,
Mantralaya, Madam Cama Road, Hutatma Rajguru Square, Mumbai-400032

10. Shri Gaurav Dwibedi, Secretary (Energy), Govt. of Chhattisgarh, Energy Department,
R.No.S-2/10, Mahanadi Bhawan, Mantralaya, Naya Raipur, Chhattisgarh

11. Sh. Pankaj Joshi, Principal Secretary (Energy), Energy Deptt, Block-5, SthFloor,
Government of Gujarat, Sachivalaya, Gandhinagar-382010

12. Smt Vandana Dadel, Secretary(Energy) Government of Jharkhand, MDI Campus,
Project Bhawan, Dhruwa, Ranchi-834004 ,

13. Sh. LC.P. Keshari, Additional Chief Secretary (Energy), Government of Madhya
Pradesh, Mantralaya, Room No. 312, Bhopal-462004

14. Sh. Hemant Sharma, Commissioner —cum- Secretary (Energy), Department of Energy
Government of Odisha, Bhubaneswar-751001

15. Shri Naresh Pal Gangwar, Pr. Secretay (Energy), Government of Rajasthan, R.No.104,
VidyutBhawan, Janpath, Jaipur-302005.

16. Shri KalingTayeng, Commissioner cum Secretary (Power), Government of Arunachal
Pradesh, Civil Secretariat, Block-2, 3rd Floor, Room No. 316, Itanagar-791111.

<!-- page 4 -->

17. Sh. Sanjay Goel, Secretary(Power), Government of Goa, Secretariat, Porvorim —Goa,
Porvorim.

18. Sh. T.C. Gupta, Additional Chief Secretary(Power), Government of Haryana, Power
Department, 37, 7th Floor, Sector-1, Chandigarh-160001

19. Sh. Tarun Sridhar, Add. Chief Secretary(Power), Government of Himachal Pradesh,
Shimla-171002

20. Sh. Paul Antony, Addl. Chief Secretary (Power), Government of Kerala, Secretariat,
Thiruvananthapuram-695001

21. Sh. R. R. Rashmi, Ch. Secretary (Power), Deptt. of Power, Government of Manipur,
Manipur Secretariat,Imphal-795001

22. Sh. M. S. Rao, Pr. Secretary (Energy), Govt. of Meghalaya, Shillong (Mehalaya)

23. Shri H. Lal Engmawia, Secretary, Power & Electricity Deptt., Government of Mizoram,
Mizoram Sectt., Axxexe-II, Treasury Square, Aizwal-796001

24. Sh. K. D. Bizo, Secretary(Power), Power Deptt., Government of Nagaland, Nagaland
Sectt. Complex, Kohima-797001

25. Sh. A. Venu Prasad, Pr. Chief Secretary (Power), Government of Punjab, Punjab Mini
Sectt., R.No.523, Sector-9,Chandigarh

26. Sh. N.T.Bhutia, Secretary (Power), Government of Sikkim, Power Department, Kazi
Road, Gangtok-737101

27. Shri Lalit Kumar Gupta, Principal Secretary(Power), Government of Tripura, New Sectt.
Complex, Power Department, Agartala-799006

28. Smt. Radhika Jha, Secretary(Power), Government of Uttarakhand, Sectt. Dehradun-
248001

29. Sh. Dheeraj Gupta, Principal Secretary (Power), Government of Jammu & Kashmir,
Civil Secretariat, Jammu/Srinagar.

30. Shri Sanjeev Khirwar, Secretary (Power), Andaman & Nicobar Admn, Port Blair-744101

31. Shri Anurag Aggarwal, Secretary (Home cum Fin), UT of Chandigarh, 4th floor, UT
Secretariat, Sector-9, Chandigarh-160009

32. Sh. S. S. Yadav, Secretary(Power) & Development Commissioner, UTs of Dadra, Nagar
Haveli, Daman & Diu, Sectt., Silvassa-396230.

33. Smt. Varsha Joshi, Secretary (Power), Government of NCT of Delhi, I. P. Estate, Room
no 803 , B wing , Power Dept., New Delhi-110002

34. Shri Vivek Pandey, Secretary(Energy) & Adviser to the Administrator, Union Territory
of Lakshadweep, Lakshadweep

35. Dr. S. Sundaravadivelu, IAS, Secretary (Power), Chief Secretariat, Government of
Puducherry, Goubert Avenue, Puducherry-605001

<!-- page 5 -->

| 2
dt a) .
सत्वधव जबते
No. L-2/2018-IPC(Part-4)
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg,
New Delhi, dated 08.03.2019
OFFICE MEMORANDUM
Sub: Approval of the Government on the recommendations of Group of Ministers (GoM)
constituted to examine the specific recommendations of High Level Empowered Committee
(ALEC) constituted to address the issues of Stressed Thermal Power Projects.

In reference to communication received from Cabinet Secretariat vide D.O. No.
CCEA/07/2019(ix) dated 07.03.2019, the undersigned is directed to inform that Government has
approved the following:

2. Amendments to be made in the SHAKTI Policy issued vide MoC letter no.

23011/15/2016-CPD/CLD dated 22.05.2017:

2.1 The following clause is to be added after clause B(vii) of SHAKTI policy:

“B(viii): Notwithstanding anything in the foregoing paras, it is further provided as

follows:

a) All such power plants including private generators which do not have PPAs, shall be
allowed Coal linkage under B(iii) and B(iv) of Shakti Policy for a period of minimum 3
months upto a maximum of I year, provided further that the power generated through
that linkage is sold in Day Ahead Market (DAM) through power exchanges or in short
term through a transparent bidding process through Discovery of Efficient Energy
Price (DEEP) portal. A methodology in this regard shall be formulated by Ministry of
Power in consultation with Ministry of Coal.

b) A generator which terminates PPA in case of default in payment by the DISCOM, may
be allowed to use existing linkage coal for sale of power through short-term PPAs
using DEEP portal or power exchange for a period of maximum 2 years or until they
find another buyer of power under long/medium term PPA whichever is earlier.
Adequate safeguards to be put in place.

C) The provision of para B(v) of Shakti Policy above shall also be applicable in cases
where the nodal agency designated by Ministry of Power aggregates/ procures the
power requirement for a group of states even without requisition from such states.

d) Central and State generating companies can act as an aggregator of power of such
stressed power assets and procure it through transparent bidding process and offer that
power to the DISCOM against their existing PPAs to such DISCOMS, till such time
their own plants get commissioned. It is proposed that Central and State generating
companies may be allowed to use the existing unutilized Bridge Linkages for such

<!-- page 6 -->

: stressed power assets provided they meet other parameters of tolling guidelines
हे including competitive bidding.

e) In all cases where provisions of B(viti)(a)(b)(c)and (d) above are utilized, net surplus
after meeting operating expenses generated in this manner shall be entirely used for
servicing debt in the first place. MoP will work out in consultation with DFS - a
mechanism to ensure this.”

2.2 Following is to be added at the end of first para of B(ii) of Shakti Policy, after the words
“with PPAs”:

(i) ‘The power plants which were having valid already concluded Long Term PPA, based
on domestic coal on or before 17.05.2017 and who could not participate in the linkage
auctions under SHAKTI B(ii) due to any reason, may be allowed to participate in the
B(ii) auctions of SHAKTI scheme. हर

(ii) Bidders who have already participated in SHAKTI B(ii) auctions and could not secure
linkage for the full ACQ, may obtain the linkage for the balance quantity also by
participating in future auctions at a later stage under B(ii) after benchmarking
discount.

2.3 Following is to be added at the end of para B(iii) of Shakti Policy, after the words
“auction process”: “Such auctions/ bids shall be held at regular intervals”.

3 Other Approvals:

Bel, Approval with regard to increase in quantity of coal for e-Auction for power
sector: Ministry of Coal may earmark more coal for power sector under special forward
e-auction by reducing the equivalent quantity from the spot ¢ auction. The Coal India Ltd.
may earmark at least 50 percent of the total coal meant for e-auction (including spot
auction and special forward e-auction) for power. The increase in supply of coal for
forward e-auction will be in addition to regular requirement of linkage coal for the power
sector and the requirements of other sectors.

3.2 Approval with regard to non-lapsing of short supplies of coal: If the power plant
fulfills its obligations limited to making advance payments as due to coal companies,
payments to Indian Railways as due and making arrangements for unloading of the rakes
at its plants, then, any short supply for that month of coal, either on account of short
supply of coal in the coal company or on account of unavailability of rakes, may not lapse
and be carried over (without current limitations of 5% or same quarter) to the subsequent
months upto a maximum period of 3 months. In this regard, a suitable methodology shall
be evolved for implementation.

3.3. Approval with regard to ACQ based on efficiency: ACQ per MW entitlements for all
thermal power plants, irrespective of their age or technical parameters, shall be calculated
based on Normative Station Heat Rate with upper ceiling of 2600 kcal/kwh.

3.4 Approval with regard to mandatory payment of Late Payment Surcharge (LPS):
Ministry of Power may engage with the Regulators to ensure that LPS is paid in case of
delay in payment by DISCOMs as per the provisions of PPA. Appropriate Regulatory
Commissions may ensure compliance.

<!-- page 7 -->

3.5. Approval — with regard to cancellation of |§PPA/FSA/Transmission
: connectivity/EC/FC/Water ete.: DISCOMS, CIL, PGCIL, Ministry of Environment and
Forests, and appropriate Governments may be advised not to cancel PPA, FSA,
transmission connectivity, EC/FC, and all other approvals including water, even if the
project is referred to NCLT or is acquired by another entity subject to the provisions of
the contracted PPA and/ or applicable rules. All clearances may be linked to the plant and
not to the promoter.

3.6 Approval with regard to cancellation of PPA for non-compliance of COD: If there is
any delay in the commissioning of a project for reasons not attributable to the generator,
the DISCOMs may be advised not to cancel those PPAs. The PPA may be kept on hold
for a certain period, so as to enable removal of impediments in the execution of the
project. In the meantime, power can be procured through the mechanism suggested in
previous proposals.

4. It is requested to take necessary action to implement the above decisions of the
Government. Action taken may be intimated to this Ministry.

Yours faithfully,
Yeo
(S. Majumdar)
Under Secretary to the Govt. of India
Tel: 2335 6938
To,
1. Secretary, Ministry of Coal
2. Secretary, Dept. of Financial services, Ministry of Finance
3. Secretary, Ministry of Environment, Forestry and Climate Change
4. Secretary, Ministry of Corporate Affairs
5. Chairperson, Central Electricity Authority
6. Chairman, Railway Board
7. Secretary, Central Electricity Regulatory Commission
8. CE, R&R (Ministry of Power)
9. CMD, NTPC
10. Chairman, DVC
11. CMD, PFC
12. CMD, REC
13. CMD, PGCIL
14. CMD, CIL
Copy to: Additional Chief Secretaries/Principal Secretary/Secretary (Energy) of State Govt. (As
per list)
Copy to: Technical Director NIC for posting on website of MoP

<!-- page 8 -->

Additional Chief Secretaries/Principal Secretary/Secretary(Energy) of State Govt.
1. Shri Ajay Jain, Principal Secretary (Power), Room No. 147, Ground floor, 2nd -
Block, A.P. Secretariat, Velagapudi, Guntur, Andhra Pradesh-522503
2. Shri P. Ravi Kumar, Addl. Chief Secretary(Energy) Government of Karnataka,
Vikasa Soudha, Bangalore-560001
3. Md Nasimuddin, Pr. Secretary(Energy), Government of Tamil Nadu, Fort St.
George, Sectt., Chennai-600009
4. Shri. Ajay Mishra, Special Chief Secretary (Energy), R. No. 433, D-Block,
3 Floor, Telangana Secretariat, Hyderabad-500022
5. Shri NeerajVerma, Principal Secretary (Power) Government of Assam, Assam
Sachivalaya, Block-C, 3 Floor, Dispur-781006
6. Sh. Pratyaya Amrit, Pr. Secretary(Energy), Government of Bihar, 8, Darogaroy
Path,Patna-800001
7. Shri Sunil Kumar Gupta, Principal Secretary, D/o Power & NCES, Government
of West Bengal, Bidyut Unnayan Bhawan, 5" Floor, 3/C LA Block-lll, Saltlake
City, Kolkata- 700098.
8. Sh. Alok Kumar, Principal Secretary (Power), Government of Uttar Pradesh,
Babu Bhawan, R. No. 104, Lucknow-226001
9. Sh. Arvind Singh, Principal Secretary (Energy), Government of Maharasthra,
Mantralaya, Madam Cama Road, Hutatma Rajguru Square, Mumbai-400032
10. Shri Gaurav Dwibedi, Secretary (Energy), Govt. of Chhattisgarh, Energy
Department, R.No.S-2/10, Mahanadi Bhawan, Mantralaya, Naya Raipur,
Chhattisgarh
11. Sh. Pankaj Joshi, Principal Secretary (Energy), Energy Deptt, Block-5,
S“Floor, Government of Gujarat, Sachivalaya, Gandhinagar-382010
12. Smt Vandana Dadel, Secretary(Energy) Government of Jharkhand, MDI
Campus, Project Bhawan, Dhruwa, Ranchi-834004
13. Sh. I.C.P. Keshari, Additional Chief Secretary (Energy), Government of
Madhya Pradesh, Mantralaya, Room No. 312, Bhopal-462004
14. Sh. Hemant Sharma, Commissioner -cum- Secretary (Energy),
Department of Energy Government of Odisha, Bhubaneswar-751001
15. Shri Naresh Pal Gangwar, Pr. Secretay (Energy), Government of
Rajasthan, R.No.104, VidyutBhawan, Janpath, Jaipur-302005
