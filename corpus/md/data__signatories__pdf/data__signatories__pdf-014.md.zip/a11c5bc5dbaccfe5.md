---
doc_id: "a11c5bc5dbaccfe5"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/626976b2de16546cf3444c3a2f6ddea1.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RTI - Departments of Health and Family Welfare - Chs II - Promotion order dated 27.07.2018"
date: "2018-07-27"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dd2d8e3e8acbdbdd"
---

<!-- page 1 -->

No. A.3201 210212017 -CHS-l !

qTr{ {G'R/Government of lndia
EflTzq'qs cfrs-t.( 6-€zlTur tTrel-{
Ministry of Health & Family Welfare

ftq.flTrrfi,+{ffi_1.t0011
ORDER

Nirman Bhawan, New Delhi - 110 011
Dated the 27th July, 201 8

The President is pleased to promote the following Senior Medical Officers of General
Duty Medical Officer sub-cadre of the Central Health Service to the Chief Medical Officer Grade
under Dynamic Assured Career Progression (DACP) Scheme in the scale of pay of Rs. 1560039100 in Pay Band-3 with grade pay of Rs. 7600 plus NPA at the prescribed rates, of the same
sub-cadre and service with effect from the date shown against their names:
S.No.

Name and Date of Birth of the officer

Place of Posting

Date of
Promotion

1.

Dr. B.V. Shravan Kumar I 26.01.1974
Dr. Ashok K Thakur I 19.01.1972
Dr Shubhla Bansal I 15.09.1977
Dr. Ravi Shankar Sinqh / 04.05.1969
Dr. Akhilesh Kumar / 08.01 .1973
Dr. Narain Prasad I 17.07.1978
Dr. Syed Rashid Anwar I 02.04.1972
Dr. M. Nithin 124.05.1978
Dr. Punitha M / 30.04.'1978
Dr. Pradeep Kumar I 12j21973
Dr. P. Senthil Kumar 131.03.1976
Dr. Nagendra Kumar I 18.12.1972
Dr. Monica Bishnoi I 16.08.1971
Dr. Vinay Kumar Sukhiia I 11.01.1978
Dr. Vivek Prakash Ghate I 27.05.1979
Dr. Pawan Kumar / 05.'10.1968
Dr. Kamran Faisal / 01 .03.1978
Dr. Sunil Kumar Pandey I 15.11.1972
Dr. Mukul Kumar Mangla I 24.07.1977
Dr. Preeti Madan I 04.02.1977
Dr. Vikas Chauhan / 08.03.1980
Dr. Bharti Uppal I 30.12.1978
Dr. Hari Shankar Niranian / 30.10.1978
Dr. Dipankar Das Gupta I 23.11.1977
Dr. Sandeep Sharma I 10.11.1981
Dr. Sanjay Kumar / 05.02.1925
Dr. tr'ar Rai Sinqh I 19.12 i 981
Dr. Anuras / 15.01.1981
Dr. Prem Kumar Choudhrv / 05.06.1975
Dr. Aiita Gm 123.10.1976
Dr. Gouri Shankar Jhankar I 06.07.1977
Dr. Yoqesh I 18.02.1982
Dr. Geetaniali I 16.08.1981

CGFIS. Hvderabad

30.1 1 .2009

CGHS, Patna
CGHS, Delhi
RoHFW, Patna
CGHS, Kanpur
CGHS, Delhi
CGHS, Patna
CGHS, Trivandrum
CLTRI, Chenqalpattu
CGHS, Patna
CGHS, Trivandrum
CGHS, Delhi
CGHS, Lucknow
ABQ, Amritsar
CGHS, Naqpur
Dr. RML Hospital
CGHS Delhi
CGHS, Delhi
Safdariunq Hospital
Dr. RML Hospital
Safdariunq Hospital
Dr. RML Hospital
Safdariunq Hospital
CGHS, Delhi
Safdariunq Hospital
CGHS, Delhi

04.04.2014
04.04.2014
04.04.2014
04.04.2014
08.04.2014
16.06.2014
16.06 2014
22.02.2015
01 .03.2015
22.02.2015
15.A2.2015
09.06.2014
15.02.2016
19.02.2016
11.08.2015
09.03.2016
24.10 2015
09.09.2015
16.10.2015
1 8.10.2015
23.10.2015
25.10.2015
31,01.2016
31 .01.2016
31.01 .2016
31.01.2016
31.01.2016
31.01.2016
31.01.2016
31.01.2016
01.02.2016
05.03.2016

2.
3.

4.
5.

b.
7.
8.

9
10
11

12
13
14
15.
16
17.
'18

19.

20.
21.
22.
23.
24.
25.
26
-!

28.
29.
30.

31.
32.
33.

coHs, oetiii
CGHS, Delhi
CGHS, Delhi
CGHS, Delhi
CGHS, Delhi
CGHS, Delhi
Dr. RML Hospital

2. ln the event of any officer, who is being promoted to the said post is on leave of any kind,
except Study leave/foreign assignment/deputation, etc. on the date of promotion, this order will
take actual effect from the date he/she returns from such leave and assumes charge of the post.

q

-1
\

<!-- page 2 -->

3.

On promotion io the post of Chief Medical Officer Grade, the pay of the officers shall be
fixed in the scale of pay of Rs. 15600-39100 in Pay Band-3 with grade pay of Rs. 7600 plus NPA
at the prescribed rates under Rule 13 of CCS (RP) Rules, 2008 as amended from time to time.

4.

The seniority of the officers wrll be regulated on the basis of the inter-se seniority in the
grade of Medical Officer of the Central Health Service or as may be determined by the
Government in accordance with the relevant rules.

5.

The promotion to the grade of Chief Medical Officer does not involve change in the
present place of posting.

6.

The charge relinquishment report as Senior Medical Officer and charge assumption
repoft as Chief Medical Officer (in duplicate) in respect of the officers may be obtained and

forwarded to this Ministry.

-{t

<,\

u nder secreta rv

"

*"

(S.M. Routray)

fl", J%'lT-t#r"J [13

To
1)

2)

J)

4)
5)
6)
7)
8)

s)
10)

11)
12)
13)

14)
15)
16)

17)
18)

Director General of Health Services, Nirman Bhawan, New Delhi.
Director (CGHS), Ministry of Health & Family Welfare
Additional Director (HQ), CGHS, R.K. Puram, New Delhi
Medical Superintendent, Dr. RML Hospital, New Delhi
Medical Superintendent, Safdarjung Hospital, New Delhi
Additional Director, CGHS, Hyderabad
Additional Director, CGHS, Patna
Additional Director, CGHS, Trivandrum
Additional Director, CGHS, Lucknow
Additional Director, CGHS, Nagpur
Additional Director, CGHS, Kanpur
Regional Director, Regional Office for Health & Family Welfare, 05rh Floor, lndira Bhawan,
R.C. Singh Path, Patna-800001
Attari Border Quarantine, Government of India, 7-A Courl Road, Amritsar
Director, Central Leprosy Teaching & Research lnstitute, Chengalpattu - 603 00'1, Tamil
Nadu
All Officers concerned through their units.
CHS-I / APAR Cell / CGHS-I / lV Sections
ln charge NIC.
Order folder.
