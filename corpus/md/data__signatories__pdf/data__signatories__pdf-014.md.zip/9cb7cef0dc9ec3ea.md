---
doc_id: "9cb7cef0dc9ec3ea"
source_url: "https://dof.gov.in/static/uploads/2025/12/2a3c6beffc41d02c52818dbbc566b167.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Guidelines for Fisheries and Aquaculture Infrastructure Development Fund on ( 10-07-2019)"
date: "2025-12-08"
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "080e5094e3dcce50"
---

<!-- page 1 -->

Guidelines for

Fisheries and Aquaculture
Infrastructure Development Fund (FIDF)

Ministry of Fisheries, Animal Husbandry and Dairying
Government of India

<!-- page 2 -->

Contents
Sl.No
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19

Item
Introduction
Area of Operation
Objectives
Nodal Loaning Entities (NLE’s)
Eligible Entities (EE’s)
Nodal Implementing Agency (NIA)
Eligible Investment Activities
Quantum of Loan and Margin Money/Beneficiary
Contribution
Interest Subvention and Lending Rate of Interest
Funding Mechanism
Loan Disbursement
Repayment
Availability of Land, Water Bodies and Statutory Clearance
Formulation Detailed Project Report (DPR)
Submission of the Project Proposal
Project Evaluation and Sanction
Implementation Mechanism
Project Monitoring and Evaluation
Addendum

Page No.
1-2
2
2
3
3
3
4
4-5
5-6
6-7
7
7-9
9-10
10
11
11-12
12-13
13-14
15-17

<!-- page 3 -->

GUIDELINES

Fisheries and Aquaculture Infrastructure
Development Fund (FIDF)

Department of Fisheries
Ministry of Fisheries, Animal Husbandry and Dairying
Government of India

<!-- page 4 -->

Fisheries and Aquaculture Infrastructure Development Fund
(FIDF)

1.

INTRODUCTION

1.1

Contributing about 1% to the National GDP, 5.23% to the Agricultural GDP(201516) and exports earning of about 45,107 crore in 2017-18 (US$ 7.08 billion), the
fisheries sector has been playing significant role in the national economy. The
Country is bestowed with varied and huge potential resources in the form of
rivers and canals (1.95 lakh km); floodplain lakes (7.98 lakh hectare); ponds and
tanks (24.33 lakh hectare); reservoirs (31.50 lakh hectare) and brackish water
(14.10 lakh hectare). In addition, the marine fisheries activities spread along the
country’s long coastline of 8118 km with an EEZ of 2.02 million square km.
Foreseeing the greater scope for development of fisheries, the Government of
India has called for “a revolution” in the fisheries sector and has named it as “Blue
Revolution”.

1.2

The Mission Blue Revolution envisioned by the Government primarily focuses to
enhance fish productivity, fish production at a growth rate of 6% to 8% and
creation of need based infrastructure facilities for fisheries.

Through the

concerted efforts put in by the Central and State Governments in implementation
of various programmes and policies, the country’s fish production has increased
from 0.75 million tonnes in 1950-51 to 12.61 million tonnes (P) during 2017-18,
contributing to the economic development together with food and nutritional
security.
1.3

Keeping in view that (i) there is limited availability of funds through the normal
budgetary process and even these are mostly grant based without the ability to
leverage them for credit based finance, (ii) there is conspicuous lack of credit
funding in fisheries sector and (iii)

to fill the large gaps in fisheries

infrastructure, the Department of Fisheries, Ministry of Fisheries, Animal
Husbandry and Dairying has set up a dedicated Fisheries and Aquaculture

1

<!-- page 5 -->

Infrastructure Development Fund(FIDF). FIDF envisages creation of fisheries
infrastructure facilities both in marine and inland fisheries sectors and augment
the fish production to achieve the target of 15 million tonnes by 2020 set under
the Blue Revolution. Besides, the FIDF aims to achieve a sustainable growth of 89 per cent, in a move to augment the country’s fish production to the level of
about 20 million tonnes by 2022-23.
1.4

In the Union Budget 2018, the Hon’ble Finance Minister has announced to set
aside a corpus of Rs. 10,000crores for setting up of a Fisheries and Aquaculture
Infrastructure Development Fund (FIDF) for fisheries sector and an Animal
Husbandry

Infrastructure

Development

Fund

(AHIDF)

for

financing

infrastructure requirement of animal husbandry sector.
1.5

The proposed Fisheries and Aquaculture Infrastructure Development Fund
entails an estimated fund size of Rs 7522.48 Crore comprising of Rs 5266.40
crore to be raised by the Nodal Loaning Entities (NLEs), Rs 1316.60 crore
beneficiaries’ contribution and Rs 939.48 crore budgetary support from
Government of India.

2.

AREA OF OPERATION

2.1

The Fisheries and Aquaculture Infrastructure Development Fund (FIDF) as
detailed in the ensuing paragraphs is implemented in all the States and Union
Territories of India.

3.

OBJECTIVES

3.1

Creation and modernization of capture & culture fisheries infrastructure

3.2

Creation of Marine Aquaculture Infrastructure

3.3

Creation and modernization of Inland Fisheries Infrastructure

3.4

Reduce post-harvest losses and improve domestic marketing facilities through
infrastructure support.

3.5

To bridge the resource gap and facilitate completion of ongoing infrastructure
projects.
2

<!-- page 6 -->

4.

NODAL LOANING ENTITIES (NLEs)

4.1

National Bank for Agriculture and Rural Development (NABARD),

4.2

National Cooperatives Development Corporation (NCDC),

4.3

All scheduled Banks

5.

ELIGIBLE ENTITIES (EEs)

5.1

State Governments / Union Territories,

5.2

State Owned Corporations/State Govt. Undertakings/ Govt. Sponsored /
Supported Organizations

5.3

Fisheries Cooperative Federations (including FISHCOPFED etc.)

5.4

Cooperatives, collective groups of fish farmers & fish produce groups etc.

5.5

Panchayat Raj Institutions/Self Help Groups (SHGs)/ NGOs

5.6

SCs/STs/Marginal Farmers, Women & entrepreneurs, Self Help Groups and
cooperatives of these etc.

5.7

Private companies/entrepreneurs

5.8

Physically disabled

5.9

Any other institution/entity to be decided by the Government

6.

Nodal Implementing Agency(NIA)

6.1

Composition

6.1.1 National Fisheries Development Board, Hyderabad
6.2

Terms of Reference (ToR)

6.2.1

The Nodal Implementing Agency(NIA) shall scrutinize, evaluate, apprise the
proposal submitted by EE’s and place before CAMC for approval.

3

<!-- page 7 -->

7.

ELIGIBLE INVESTMENT ACTIVITIES

7.1

Establishment of Fishing Harbours,

7.2

Establishment of Fish Landing Centres

7.3

Infrastructure for Mariculture and Advanced Inland Fisheries (Ocean farming,
Cage Culture etc.)

7.4

Construction of Ice Plants (both for marine and inland fisheries)

7.5

Development of Cold Storages (both for marine and inland fisheries)

7.6

Fish Transport and Cold Chain Network Infrastructure

7.7

Development of Modern Fish Markets

7.8

Setting up of Brood Banks

7.9

Development of Hatcheries

7.10

Development of Aquaculture

7.11

Modernization of State Fish Seed Farms

7.12

Establishment of state of art Fisheries Training Centres

7.13

Fish Processing Units

7.14

Fish Feed Mills/Plants

7.15

Establishment of Cage culture in Reservoirs

7.16

Introduction of Deep Sea Fishing Vessels

7.17

Establishment of Disease Diagnostic Laboratories

7.18

Development of Mariculture

7.19

Establishment of Aquatic Quarantine Facilities

7.20

Any

other

innovative

projects/activities

designed

to

enhance

fish

production/productivity/value
8.

QUANTUM OF LOAN AND MARGIN MONEY/BENEFICIARY CONTRIBUTION

8.1

The project under the FIDF shall be eligible for loan up to 80% of the
estimated/actual project cost. Beneficiaries are required to contribute at least
20% of the project cost as margin money.

4

<!-- page 8 -->

8.2

Contribution of margin money in case of States/UTs, State Entities implemented
projects shall not be mandatory. However, the concerned States/UTs, State
entities, may decide contribution and size of the margin money preferably on
lines of RIDF, depending upon availability of budget in their respective
states/UTs.

8.3

Cost escalation of the approved project, if any occurred during the course of
project implementation on account of genuine reasons like natural calamity,
technical compulsions, change in the SoRs and any other unavoidable
circumstances shall be considered for enhancement of loan amount, within in the
reasonable time and not more than two years from the date of approval of the
particular project.

9.

INTEREST SUBVENTION AND LENDING RATE OF INTEREST

9.1

Interest subvention :

Up to 3% per annum for all EEs for development of

identified fisheries based infrastructure facilities.
9.2

Lending Rate of interest :

Not lower than 5% per annum for all EEs for

development of identified fisheries based infrastructure facilities.
9.3

The interest subvention as at 9.1 above also includes cost of reduction of interest
rate and uniform margin of 0.6% towards funds management charge and risk
coverage costs to the NLEs.

9.4

The Department of Fisheries, Ministry of Fisheries, Animal Husbandry and
Dairying shall pay the interest subvention amount to NABARD/ NLEs till due
outstanding loan and interests are fully paid off. Subject to provisions of FIDF, the
interest subvention shall be the difference between (a) costs of barrowing

by

NABARD/ NLE (inclusive of interest, taxes, fees, charges, etc.) plus fund
management cost of 0.6% per annum, and (b) the rate of interest charged on
loans to EEs by NABARD/ NLEs.

5

<!-- page 9 -->

9.5

Department of Fisheries, Ministry of Fisheries, Animal Husbandry and Dairying
shall make adequate annual budget provision for interest subvention to
NABARD/NLEs for 12 years covering the entire repayment period of loan by the
EEs under FIDF based on annual plan submitted by NABARD.

9.6

NABARD will submit quarterly claims of interest subvention of all NLEs.
Department of Fisheries subject to the availability of funds, may place in advance,
the quarterly interest subvention amount with NABARD. Interest accrued on the
Government of India fund placed as advance at the disposal of NABARD by
Department of Fisheries towards meeting the interest subvention liability of
NLEs would form part of corpus funds of FIDF. Such accrued interest shall be
suitably accounted for by NABARD and informed to Department of Fisheries from
time to time so as to ensure that it is suitably adjusted in subsequent releases to
NABARD by Department of Fisheries.

10.

FUNDING MECHANISM

10.1

NABARD being one of the NLEs will raise the funds from the market or utilize its
own financial resources for funding under the FIDF, the cost of which shall be
informed to Department of Fisheries on a quarterly basis.

10.2

NABARD would fund the public infrastructure components through the State
Governments/State Entities. Besides, NABARD, if required would also provide
refinance to the other NLEs namely NCDC and scheduled Banks as per its
refinance policy for implementation of FIDF.

10.3

NCDC will lend the loan to the Eligible Entities (EEs) in cooperative sector either
through the State Governments/UTs or directly to the Eligible Cooperative
Societies & Federation etc. in accordance with its financial terms and conditions
at the specified rate of interest with ceiling on interest subvention specified
under the FIDF.

6

<!-- page 10 -->

10.4

NCDC will source the required funds from the market borrowing, or utilise own
financial resources or avail refinancing from NABARD for lending the loan in
cooperative sector for implementation of the FIDF.

10.5

Similarly, the scheduled Banks as NLEs will also raise own funds or utilise their
available financial resources to lend to the Eligible Entities (EEs). In respect of
individual entrepreneurs, cooperatives and commercial investments, lending will
be through the scheduled Banks operating in any particular district for
implementation of the FIDF.

10.6

The banks may also avail re-finance from NABARD, if required for lending to the
EEs for implementation of the FIDF.

11.

LOAN DISBURSEMENT

11.1

Loan Lending period under FIDF : 5 years from 2018-19 to 2022-23.

11.2

Projects wherein the first installment of loan is released before March 2023, will
be eligible for release of the remaining installments, within 2 year period i.e.
before 31st March 2025 and all such releases are eligible for interest subventions
under FIDF, subject to the provision of para 12 of these guidelines. However,
efforts will be made to complete the implementation and release of loan amount
at the earliest.

12.

REPAYMENT

12.1

Maximum Repayment period : 12 years inclusive of moratorium of 2 years on
repayment of principal.

12.2

NLEs should ensure that the maximum repayment period should not exceed 12
years from the date of first disbursement inclusive of a moratorium of 2 years on
repayment of principal.

7

<!-- page 11 -->

12.3

However, the financing NLEs, at their discretion, may curtail the repayment
period depending on the project magnitude, size of the financial investment,
repayment capacity of the project proponents (EEs) etc.

12.4

Banks and NABARD being independent commercial institutions would be at
liberty to sanction/ release the loans as per their commercial norms/ policies and
in compliance with the regulatory guidelines as notified by RBI from time to time.
The operational and credit related decisions like process of repayment, rate of
interest , penal interest, security and extent of finance will be decided by NLE’s.

12.5

Subject to provisions of FIDF, NCDC being a independent commercial institution
would be at liberty to sanction or release the loans as per its commercial norms
or policies and in compliance with the decisions of the competent authority
including the Board of Management of NCDC and Government of India broadly in
line with the guidelines issued by RBI for banks and NBFCs. Further, subject to
provisions of FIDF, the operational and credit related decisions like process of
repayment, penal interest, security and extent of finance will be decided by
NCDC.

12.6 Subject to provisions of FIDF, NLEs to fix the lending rates in consonance with
broad regulatory guidelines of RBI taking into account their cost of funds and the
risk perception of the loan.
12.7

The State Governments will get a mandate registered with RBI / Principal Banker
on their current account, in favour of NABARD/ NLEs to the effect that, in the
event of default by the concerned State Government in repaying the principal and
interest on loans taken, NABARD/ NLEs shall have the first charge on the all
receipts of the concerned State Government in their current account including
from out of the Central Divisible Pool.

12.8

Subject to provisions of FIDF,

NLEs may consider providing additional loan

against justified cost escalations of the approved projects, subject to approval of
CAMC.
8

<!-- page 12 -->

12.9

A project will be considered non- starter, if no drawals are made within six
months from the date of sanction by NLE. Further, the sanction would lapse if the
EE, fails to ground the project within a period of 12 months, from the date of
sanction by NLE. This is a broad guideline; however NLEs will take final decision
on case to case basis.

12.10

NLEs may consider withdrawal of projects by EEs on account of genuine
constraints and difficulties. EEs may be levied interest to the extent of loan
withdrawal, even if withdrawal of project is during the period of moratorium,
and commitment/ pre-payment charges, if any unless otherwise decided by
NLEs.

12.11 NLEs may consider stopping further disbursements of loans and advances
sanctioned for the project, until such amount in default are paid in full by EEs. In
such cases, neither the lending agency, Department of Fisheries, GoI, NIA, (Nodal
Implementing Agency) shall be liable for any loss, damage or expenses that may
be caused in the completion of aforesaid projects.
13.

AVAILABILITY OF LAND, WATER BODIES AND STATUTORY CLEARANCE

13.1

Loan under the FIDF shall not be provided for acquisition of land and water
bodies in any manner such as purchase, transfer, lease, accession/addition etc.
required for implementation of the identified project activities.

13.2

The project proponents (EEs) are required to acquire necessary land and water
bodies (in case of non-availability of land with them) at their own cost and
complete all processes associated with land acquisition, before submission of the
proposal for concessional finance under the FIDF.

13.3 The projects having land and water bodies on long term lease may also be
considered for financing under FIDF. However, the lease period/ agreement
should be of sufficient duration to secure the loan. In case of lease, requisite No
Objection Certificate from the competent authority for mortgage to NLEs may be
obtained.

9

<!-- page 13 -->

13.4

The project proponent (EEs) may not be allowed to terminate the lease
agreement intermediately (earlier that the agreed lease period) and sell out the
land and water bodies as well as facilities created with the loan availed under the
FIDF. However, in case EEs are under compulsion to do so due to unavoidable
circumstances whatsoever then they shall obtain permission from the concerned
NLEs after return of the entire loan availed till that time, with applicable interest
and prepayment penalty, if any, to the NLEs, in single installment.

13.5

Confirmation with necessary documentary evidence on availability of land and
water bodies and statutory clearances (wherever necessary) shall be clearly
indicated in the DPR/Self Contained Proposal.

13.6

The EEs shall provide documentary evidence/certificate of availability of
requisite land and water bodies free from all encroachment and encumbrances.

13.7

The EEs are required to obtain necessary statutory clearances, permits and
licenses, whatsoever and wherever required for implementation of the intended
project under the FIDF. The expenditure, if any involved in this processes shall be
met by the applicants/beneficiaries.

14.

FORMULATION OF DETAILED PROJECT REPORT (DPR)

14.1

Concessional financing under the FIDF is based on Detailed Project Reports
(DPRs) / Self Contained Proposals.

14.2

Detailed projects especially for infrastructure and large magnitude projects shall
be formulated based on;

14.3

(i)

Identification of suitable site,

(ii)

Necessary engineering and socio-economic investigations and surveys,

(iii)

Planning and designing of the facilities and

(iv)

Model studies wherever required etc.

The EEs shall submit the DPR/self Contained Proposal in triplicate copies.
10

<!-- page 14 -->

15.

SUBMISSION OF THE PROJECT PROPOSAL

15.1

The complete DPRs/self-contained proposals for seeking concessional financing
under the FIDF shall be submitted by the EEs at the following address:
To
Joint Secretary(Fisheries)
Department of Fisheries,
Ministry of Fisheries, Animal Husbandry and Dairying,
Krishi Bhawan, New Delhi-110001

15.2

A copy of the proposal shall also be submitted to the Nodal Implementing
Agency(NIA) at the following address:
The Chief Executive,
National Fisheries Development Board,
Department of Fisheries,
Ministry of Fisheries, Animal Husbandry and Dairying, GoI,
Pillar No:235, PVNR Expressway, SVPNPA Post,
Hyderabad-500052.

15.3

NIA would receive the proposals from the concerned State Governments/UTs in
respect of State/UT owned/implemented projects and directly from the other
EEs (wherever the State/UT financial contribution is not involved in
implementation of the intended project under the FIDF).

15.4

Except Private Entrepreneurs/Companies all the other EEs shall route their
applications through Nodal Departments of their respective State/UTs.

16.

PROJECT EVALUATION AND SANCTION

16.1

NFDB, being the Nodal Implementing Agency (NIA), shall scrutinize, evaluate,
appraise the proposal submitted by EEs and place before CAMC for approval.

16.2

CAMC will meet as often as necessary, and consider the proposals placed before it
and accord in principle approval to projects signifying approval for grant of
interest subvention and recommend such approved proposals to the NLEs for
11

<!-- page 15 -->

considering sanction of loans. Lending decision would be left to the Banks and
NABARD as per their policy and regulatory guidelines.
16.3

NLEs to send a copy of the loan sanction to CAMC and NIA for information.

17.

IMPLEMENTATION MECHANISM

17.1

Committees have been constituted by Ministry of Fisheries, Animal Husbandry
and Dairying for implementation of the FIDF;

17.2. Central Apex Committee (CAC)
17.2.1 Composition
(i)

Secretary, Department of Fisheries , GoI - Chairperson

(ii)

Chairperson, NABARD or his nominee

(iii)

Managing Director, NCDC or his nominee

(iv)

Additional Secretary & Financial Advisor, Department of Fisheries, GoI

(v)

Joint Secretary, Department of Financial Services, Ministry of Finance

(vi)

Joint Secretary, Department of Expenditure, Ministry of Finance

(vii) Joint Secretary (Fisheries), Department of Fisheries, Government of India
(viii) A nominee of NITI Aayog
(ix)

Chief Executive, NFDB, Hyderabad

(x)

Representatives of any of two participating banks namely SBI & BoB

(xi)

Joint Commissioner (Fisheries), Department of Fisheries, GoI – Member
Convener

17.2.2

Terms of Reference (ToR)
CAC will take decisions on approval/amending of FIDF guidelines, to approve
annual action plans and fund drawal plans etc.

12

<!-- page 16 -->

17.3 Central Approval and Monitoring Committee (CAMC)
17.3.1 Composition
(i)

Joint Secretary (Fisheries), Department of Fisheries – in Chairperson

(ii)

A nominee of NITI Aayog

(iii)

Fisheries Development Commissioner, Department of Fisheries

(iv)

A nominee of NFDB

(v)

A nominee of NABARD

(vi)

A nominee of NCDC

(vii) A nominee of concerned scheduled banks
(viii) A nominee of ICAR
(ix)

Secretary-in-Charge

of

Fisheries

of

the

concerned

State/UT

or

his

nominee/representative
(x)

Joint Commissioner(Fisheries), Department of Fisheries – Member Convener

17. 3.2 Terms of Reference (ToR)
17.3.2.1 CAMC will consider the proposals placed before it by NIA and accord inprinciple approval and recommend such proposals to NLEs’.
18.

PROJECT MONITORING AND EVALUATION

18.1

The CAMC constituted in the Department of Fisheries will review and monitor the
projects approved under the FIDF. The monitoring meetings of CAMC shall be
held on a quarterly basis to review the progress of the project taken up under the
FIDF.

18.2

The concerned project proponent/EEs shall submit the progress report to
Department of Fisheries regularly on a quarterly basis clearly indicating physical
and financial achievements. EEs also will submit project completion report to
Department of Fisheries, after the intended projects are completed.
13

<!-- page 17 -->

18.3

NIA will undertake Desk & Field monitoring, and identifying critical issues and
bottlenecks such as non-starter projects, slow progressing projects, geographical
distribution of projects, compilation of project-wise progress report, outcomes
etc., NIA, will design a monitoring mechanism, if any required, and place it before
the CAMC/CAC for approval.

18.4

NIA will assist the CAMC in all the matters relating to monitoring and evaluation
of the projects and place its report, before CAMC.

18.5

CAMC will carry out project-wise mid-term corrections, if any required due to
technical administrative compulsions. The Mid-term corrections shall include,
increase/decrease of the project scope, re-arrangement of the project
components, re-appropriation of funds from one item to other item within the
overall approved project cost.
*****

14

<!-- page 18 -->

No. 33015-3/2017-Fy(H) Vol.I
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Fisheries

Krishi Bhawan, New Delhi
Dated the 10th July, 2019
ADDENDUM
Subject: Guidelines on implementation of Fisheries and Aquaculture
Infrastructure Development Fund (FIDF) - Addendum to the Notified FIDF
Guidelines
The undersigned is directed to refer to this Department’s letter of even number
dated 12th February, 2019 on the above subject through which detailed guidelines on
Fisheries and Aquaculture Infrastructure Development Fund (FIDF) have been notified
and issued to all concerned. These guidelines have also been uploaded in the DADF’s
website (http://www.dof.gov.in).
2.

The Guidelines of the FIDF notified vide this Department’s letter of even number

dated 12th February, 2019 contains a total of 18 main paragraphs (1 to 18).

In

continuation, two paragraphs as detailed below are added to the Notified FIDF
Guidelines after para-18 with approval of Competent Authority. The additional two
paragraphs are accordingly inscribed as Para 19 and Para 20 of the FIDF guidelines and
their text may be read as below:
“19.

UNIT COST OF INVESTMENT ACTIVITIES

19.1

FIDF envisages preparation/formulation and notification of detailed guidelines on
implementation of FIDF including component-wise unit costs, sanctioning of loan,
approval processes, repayment of loan and interest, monitoring, evaluation,
resource allocation etc.

19.2

The unit cost details of the various activities under FIDF are given at Annexure-I.

19.3

With regards to unit cost it is clarified that, the projects with higher unit cost will
also be considered under the FIDF. However, the interest subvention is limited to
the unit cost content in the Annexure-I and balance liability over and above the
sealing set under the Annexure-I will be met by the concerned Eligible Entities.

15

<!-- page 19 -->

No. 33015-3/2017-Fy(H) Vol.I
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Fisheries

20.

Detailed Cost Estimate

20.1

The Central Apex Committee (CAC) of the FIDF in its 3 rd meeting held on 5th March,
2019 decided that the Detailed Cost Estimate of the projects for the purpose of
assessing their unit cost will be worked out by the concerned Eligible Entities based
on the following aspects:
(a)

The project cost estimate shall be formulated based on the approved
Schedule of Rates of the concerned state Government which are applicable
in the intended project locality.

(b)

In case, no approved Schedule of Rates are available for civil works under
the intended project, the unit rates in respect of such items are arrived at
after detailed rate analysis which will be endorsed by the local engineering
Department of the concerned State/ UT Government.

(c)

In case of plant and machineries, where approved schedule of rates are not
available, the estimate for such activities shall be prepared based on the
rates quoted by authorised suppliers (authorised dealers).

(d)

A certificate to the effect that the project cost estimate has been formulated
based on the prevailing Schedule of Rates, prevailing market rates and cost
is reasonable shall be provided by the concerned Eligible Entities.”

3.

It is requested that the State Governments/UT Administrations, other Eligible

Entities(EEs), Nodal Loaning Entities and all others concerned may please note the
aforementioned two additional paras for the purpose of implementation of the FIDF.
4.

This issues with the approval of the Competent Authority.

(Shankar L)
Joint Commissioner(Fisheries)
Tele-fax : 011-23389212

16

<!-- page 20 -->

No. 33015-3/2017-Fy(H) Vol.I
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Fisheries

Annexure-I
Component-wise unit cost of the investment activities under the Fisheries Infrastructure
Development Fund (FIDF)
Sl
Components
No.
(i)
(ii)
1
Establishment of Fishing Harbours
2
Establishment of Fish Landing Centers
3
Construction of Ice Plants (both Marine and Inland
Fisheries Sectors)
4
Construction of Cold storage (both Marine and Inland
Fisheries Sectors)
5
Fish Transport Facilities (Marine & Inland Fisheries
Sector)
6
Integrated Cold Chain (Marine & Inland Sector)

Unit
(iii)
No.
No.
No.

Unit Cost
(Rs. in lakhs)
(iv)
15000.00
1000.00
100.00

No.

100.00

No.

20.00

No.

500.00

7
8
9
10
11
12

No.
No
No
Ha
No.
No.

100.00
1000.00
50.00
7.00
500.00
500.00

No.

4674.00

No

10.00

No

650.00

15

Development of Modern Fish Markets
Setting up of Brood Banks
Development of Hatcheries
Development of Aquaculture
Modernization State Fish Seed Farms
Establishment of state of art of Fisheries Training
Centres
Fish Processing Units
Fish Feed Mills/Plants
(a) Feed mills of minimum 4 to 5 tonne per day
capacity
(b) Feed mills/plants of minimum 10 tonne per day
capacity
Establishment of Cage culture in Reservoir

No.

3.00

16

Introduction of Deep Sea Fishing Vessels

No.

80.00

17

Establishment of Disease Diagnostic Laboratories

No.

150.00

18

Development of Mariculture
(a) Sea cage culture
(b) Hatcheries
(c) Nursery Area
(d) Sea weed/Bivalve/Pearl cultures

No
No
Ha

5.00
50.00
6.00

13
14

19

Establishment of Aquatic Quarantine Facilities

20

Any other innovative projects/activities designed to
enhance fish production/productivity/value.
*****

With a total lump sum amount of
Rs.4225.00 lakh

No.

2500.00
Lump sum

17
