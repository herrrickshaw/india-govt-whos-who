---
doc_id: "9eeaeff4488c4aa5"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/ba8afb7ede1882c6a8bab98c1b421e87.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 937 of 2024 in Honble High Court of Delhi- 19th Addl List DoT instructions dated 23.05.2025 to ISPs"
date: "2025-12-24"
pages: 52
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d208a63d19c5a28f"
---

<!-- page 1 -->

813-7/25/2024-DS-II

I/3279769/2025

By Email/DoT Website

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)

No. 813-7/25/2024-DS-II

Dated: 23-05-2025

To,
All Licensees with Internet Service Authorization

Subject: CS(COMM) 937 of 2024: Zee Entertainment Enterprises Limited
versus Bollyzone.tv & Ors. In the High Court of Delhi.

Please ﬁnd enclosed the Hon’ble High Court of Delhi order dated
24.10.2024 in the captioned suit.
2. Please refer to para para 41(vi, vii & viii) of the said Court order in respect of
blocking access to the websites/domains [31 nos.] enumerated in the 19th
additional list of websites, received from the plaintiff.
3. In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said websites/domains, as above, in compliance with the said court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i.) Sh. V. Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY), New Delhi for
kind information and with request to take action as per the enclosed Annexure pl.
ii.) Sh. Rishabh Rao (rishabh@saikrishnaassociates.com), Plaintiﬀ's Counsel for
kind information and requested to take action as per the enclosed Annexure pl.

<!-- page 2 -->

19th Additional List

#
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29

Domain
moviehax.love
vegamovie.party
movies2watch.app
novamovie.net
movierulz.my
moviesjoy.icu
moviehub.pw
my-flixerz.to
tvids.tv
europixhd.stream
watchtoday.stream
1hd.watch
hollymoviehd.cc
allmovieland.watch
hdtodaytv.tv
5movierulz.at
m4uhd.nl
m4uhd.ws
m4uhd.onl
yomovies.cash
vegamovvies.cc
hdmovie2.rehab
5movierulz.live
123mkv.esq
hdmovie2.mn
1tamilmv.fi
hdmovies23.auction
hdmovies4u.la
hdhub.gay

<!-- page 3 -->

30
31

vegamovies-nl.uk
hdmovie2.giving

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

$~56
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 937/2024 & I.A. 43185/2024, I.A. 43186/2024, I.A.
43187/2024, I.A. 43188/2024, I.A. 43189/2024
ZEE ENTERTAINMENT ENTERPRISES LIMITED
Through:

.....Plaintiff

Mr. Sidharth Chopra, Mr. Vivek
Ayyagari, Mr. Angad S. Makkar, Mr.
Rishabh Rao, and Ms. Chanda
Shashikant, Advocates.
Mob: 7676612211
Email:
rishabh@saikrishnaassociates.com

versus
BOLLYZONE.TV & ORS.
Through:

.....Defendants
Mr. Neel Mason, Advocate with Mr.
Vihan Dang, Mr. Ujjawal Bhargava
and Mr. Aditya Mathur, Advocates
for D-82
Mob: 9399304251
Email:
ujjawal.bhargava@mason.co.in

CORAM:
HON'BLE MS. JUSTICE MINI PUSHKARNA
ORDER
24.10.2024

%

I.A. 43188/2024 ((Exemption from filing certified clearer/ typed copies
of documents)
1.

The present is an application under Section 151 of the Code of Civil

Procedure, 1908 (“CPC”), on behalf of the plaintiff, seeking exemption from

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 1 of 27

<!-- page 8 -->

filing certified clearer/typed or translated copies of documents.
2.

Exemption is granted, subject to all just exceptions.

3.

Plaintiff shall file original, clearer, and translated copies of the

documents, on which the plaintiff may seek to place reliance, before the next
date of hearing.
4.

Accordingly, the present application is disposed of.

I.A. 43189/2024 (Exemption from instituting Pre-Institution Mediation)
5.
The present is an application under Section 12A of the Commercial
Courts Act, 2015, read with Section 151 of CPC, seeking exemption from
undergoing Pre-Institution Mediation.
6.

Having regard to the facts of the present case and in the light of the

judgment of Supreme Court in the case of Yamini Manohar Versus T.K.D.
Keerthi, 2023 SCC OnLine SC 1382, and Division Bench of this Court in
Chandra Kishore Chaurasia Versus RA Perfumery Works Private Ltd.,
2022 SCC OnLine Del 3529, exemption from attempting Pre-Institution
Mediation, is granted.
7.

Accordingly, the application stands disposed of.

I.A. 43186/2024 (Exemption from advance service to the defendant nos.
84, 89, 92 and 93)
8.

The present is an application under Rule 22 of Delhi High Court

Intellectual Property Rights Division Rules, 2022, read with Section 151
CPC, seeking exemption from advance service to defendant nos. 84, 89, 92
and 93.
9.

The plaintiff seeks urgent interim relief. Therefore, in the peculiar

facts and circumstances of this case, exemption from effecting advance
service upon the defendant nos. 84, 89, 92 and 93, is granted.

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 2 of 27

<!-- page 9 -->

10.

For the reasons stated in the application, the same is allowed and

disposed of.
I.A. 43187/2024 (Application seeking leave to file additional documents)
11.

This is an application under Order XI Rule 1(4) read with Section 151

CPC as amended by the Commercial Courts Act, 2015, seeking leave to file
additional documents.
12.

The plaintiff, if it wishes to file additional documents at a later stage,

shall do so strictly as per the provisions of Commercial Courts Act, 2015
and the Delhi High Court (Original Side) Rules, 2018.
13.

The application is disposed of, with the aforesaid directions.

CS(COMM) 937/2024
14.

Let the plaint be registered as suit.

15.

Issue summons.

16.

Summons is accepted by learned counsel appearing for defendant no.

82.
17.

Upon filing of the process fee, issue summons to the other defendants

by all permissible modes. Summons shall state that the written statement be
filed by the defendants within thirty days from the date of receipt of
summons. Along with the written statement, the defendants shall also file
affidavit of admission/denial of the plaintiff’s documents, without which, the
written statement shall not be taken on record.
18.

Liberty is given to the plaintiff to file replication within thirty days

from the date of receipt of the written statement. Further, along with the
replication, if any, filed by the plaintiff, an affidavit of admission/denial of
documents of the defendants, be filed by the plaintiff, without which, the
replication shall not be taken on record. If any of the parties wish to seek

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 3 of 27

<!-- page 10 -->

inspection of the documents, the same shall be sought and given within the
timelines.
19.

List before the Joint Registrar (Judicial) for marking of exhibits, on

17th December, 2024.
20.

List before the Court on 07th March, 2025.

I.A. 43185/2024 (Under Order XXXIX Rules 1 and 2 CPC)
21.

The instant suit is being filed for permanent injunction, rendition of

accounts and damages, on account of blatant piracy of the plaintiff’s works
and infringement of copyright and broadcast reproduction rights of the
plaintiff. The plaintiff, a reputed broadcaster, production house and film
studio, owns and operates the Zee Channels and the digital entertainment
platform/streaming service called ‘Zee5’ respectively.
22.

It is submitted that the plaintiff has the exclusive distribution rights to

publicly exhibit and communicate through any medium or mode, the content
on Zee5 and the Zee Channels produced by the plaintiff or exclusively
licensed/assigned to the plaintiff (“plaintiff’s works”). The plaintiff’s works
are protected as “Cinematograph Films” under Section 2(f) read with
Section 13 of the Copyright Act, 1957 (“the Act”). The plaintiff has the
exclusive right to make the plaintiff’s works available for being seen or
heard, or otherwise enjoyed by the public, as enumerated under Section
14(d) of the Act, and further, is also entitled to broadcast reproduction rights
in respect of its broadcasts, under Section 37 of the Act.
23.

It is submitted that the plaintiff has observed the rampant and large-

scale infringement of the plaintiff’s works by the defendant nos. 1 to 60
arrayed in the present suit, which are rogue websites engaged in
communicating to the public, hosting, streaming and/or making available to

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 4 of 27

<!-- page 11 -->

the public the plaintiff’s works without authorization, and/or facilitating the
same. The plaintiff has come across its original content/television shows/
series, such as Bastar - The Naxal Story, Kakuda, Rautu ka Raaz, Silence 2 The Night Owl Bar Shootout, Kumkum Bhagya, Bhagya Laxmi, Appi
Amchi Collector, Khundali Bhagya, Saatvya Mulichi Saatvi Mulgi,
Idhayam, Sunflower, Ayali, Rangbaaz Season 3, Thalamai Seiyalagam,
Broken News, Paruvu, Murshid, Karenjit Kaur, and Sitara being hosted and /
or streamed on the defendant websites, without any authorisation by the
plaintiff.
24.

It is submitted that defendant nos. 1 to 60 are essentially, ‘rogue

websites’ which are engaged in displaying pirated content in order to obtain
certain financial benefits. The defendant websites are anonymous in nature,
the owners of which are virtually impossible to locate, as the information
provided in the public domain is either, incomplete, incorrect and/or
protected behind a veil of secrecy. The defendant websites’ mala fides are
evident from the vast volume of third-party content available on its websites;
the systematic, organised and intentional nature of the infringement; and
also the regularity and consistency with which content is updated/uploaded
on the websites, as is evident from the documents filed along with the plaint.
Such voluminous evidence of copyright infringement by the said defendants
clearly establishes that the defendant websites are ‘rogue’ in terms of the
judgment of the Hon’ble High Court of Delhi in UTV Software
Communications Ltd. & Anr. v. 1337x.to and Ors. (2019 SCC OnLine Del
8002).
25.

It is submitted that the defendant nos. 61 to 81 are Domain Name

Registrars which have been arrayed for the purpose of blocking access to/

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 5 of 27

<!-- page 12 -->

locking/suspending the defendant websites and to disclose information
related to the registrants of the said websites, such as name, address, email
address, mobile number, payment details etc.
26.

It is submitted that the plaintiff has arrayed Google LLC as defendant

no. 82 for the purpose of de-indexing/delisting of the domain names/
websites of such rogue defendant websites from the search results produced
on the search engine, ‘Google’, owned/operated by the defendant no. 82.
27.

It is submitted that the defendant nos. 83 to 91 are Internet Service

Providers which are being arrayed for the limited purpose of blocking/
restricting access to the rogue websites identified in the present suit or any
other website subsequently identified by the plaintiff on affidavit.
28.

It is submitted that the plaintiff has arrayed defendant no. 92,

Department of Telecommunications, and defendant No. 93, Ministry of
Electronics and Information Technology for the issuance of a notification to
the internet and telecom service providers to disable access to the defendant
websites identified in the present suit and such other websites subsequently
discovered and identified by the plaintiff to be infringing the rights of the
plaintiff. The defendant no. 94 is ‘Ashok Kumar’. No formal relief is sought
against the defendant nos. 61 to 94.
29.

It is submitted that defendant nos. 1-60 are mostly anonymous

websites. Details of their owners are either hidden or are forged/inaccurate.
These websites are vehicles of infringement and engage in flagrant violation
of the intellectual property rights of the plaintiff. Due to the nature of the
internet, which offers anonymity, these websites in a systematic manner,
engage in violation of the intellectual property rights of the plaintiff. The
websites of defendant nos. 1-60 are predominantly engaged in violating third

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 6 of 27

<!-- page 13 -->

party rights.
30.

It is submitted that in view of the aforesaid, the plaintiff has filed the

present suit seeking protection of its exclusive rights under the Act. On
account of being the producer, exclusive licensee and exclusive assignee
having adequate right, and the fact that defendant nos. 1–60 have been
violating the rights of the plaintiff, the plaintiff has established a prima facie
case in its favour. The plaintiff would suffer irreparable harm and injury if
an order of injunction is not passed. The balance of convenience is in favour
of the plaintiff on account of it being the rights-owner and having legitimate
interest which needs protection.
31.

Learned counsel appearing for the plaintiff has drawn the attention of

this Court to the various infringing content which is available on these rogue
sites. The list of the defendant websites, and the corresponding pages of the
documents filed along with the present plaint, is attached as Annexure-A to
the present order.
32.

It is submitted that as the plaintiff’s works enjoy protection as a

‘cinematograph films’ under the Act, the making available and/or
communication to the public of the plaintiff’s works, without their
authorisation, by the defendant websites would amount to a violation of the
plaintiff’s exclusive rights under the Act. The balance of convenience is
clearly against the defendant websites, which do not have authorisation with
respect to the plaintiff’s works, including, inter alia, to host, stream,
reproduce, permit download of/distribute, make available to the public
and/or communicate the plaintiff’s motion pictures, original content
television shows, web-series and other cinematographic works, or facilitate
the same. It is submitted that if the illegal activities of the defendant

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 7 of 27

<!-- page 14 -->

websites are not restrained during the pendency of the present proceedings,
plaintiff shall suffer irreparable harm since it is submitted that the defendant
websites intend to continue to exploit the plaintiff’s property with impunity,
thereby, diminishing and diluting the value of the plaintiff’s rights.
33.

Further, it is submitted that this Court in Zee Entertainment

Enterprises Limited versus Jbomma.Bar and Ors. (CS(COMM) 650/2022),
vide order dated 19th September, 2022, had restrained certain rogue websites
therein from communicating, hosting, streaming and/or making available for
viewing and downloading, without authorization on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works. Further, vide its order 27th February, 2024, inter alia, directed the
Domain Name Registrars therein to revoke domain name registrations of
such rogue websites and to furnish complete details of such rogue websites.
Further, this Court in Zee Entertainment Enterprises Limited versus All
Rounder Tv and Ors., (CS(COMM) 921/2023), vide its order dated 12th
January, 2024, guided by the principles laid down in and in furtherance of
the UTV Judgment, restrained third-party mobile applications arrayed as
defendants therein from communicating to the public, hosting, storing,
reproducing, streaming, broadcasting, re-broadcasting, causing, to be seen or
heard by public on payment of charge and/or making available for viewing
the plaintiff’s Works through their websites or apps.
34.

It is submitted that the plaintiff’s entire business depends on the

protection of its invaluable intellectual property and in case the same are
infringed, the entire business model of the plaintiff will be at great risk and
will be adversely affected. The plaintiff has invested huge sums in the
production, promotion, distribution and exploitation of the plaintiff’s works.

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 8 of 27

<!-- page 15 -->

It is submitted that if the infringement thereof is not prevented, it would
result in threatening the very future and existence of respective original
shows/ television shows/original content since production houses would be
unable to raise funds for future works.
35.

At this stage, learned counsel appearing for defendant no. 82, i.e.,

Google, submits that the address of the Google has been incorrectly
reflected in the Memo of Parties.
36.

Let correct address be provided by learned counsel appearing for

defendant no. 82-Google to the plaintiff.
37.

Amended memo of parties shall be filed within a period of one week

from today.
38.

Learned counsel appearing for defendant no. 82 further submits that at

this stage no directions be given to defendant no. 82 for de-indexing/delisting the defendant websites, as the defendant no. 82 being a search engine,
any website which is suspended, is not shown as part of the index published
in the search engine.
39.

He further submits that this may take some time in view of the

technological issues.
40.

In the above circumstances, the plaintiff has demonstrated a prima

facie case for grant of injunction and, in case, no ex parte ad interim
injunction is granted, the plaintiff will suffer an irreparable loss. Further,
balance of convenience also lies in favour of the plaintiff, and against the
defendants.
41.

Accordingly, till the next date of hearing, the following directions are

issued:
I.

The defendant nos. 1 to 60, their owners, partners, officers and all

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 9 of 27

<!-- page 16 -->

others in capacity of principal or agent acting for and on their behalf, or
anyone claiming through, by or under it, are restrained from in any manner
communicating, hosting, streaming, and/or making available for viewing
and downloading, without authorization, on their websites or other
platforms, through the internet in any manner whatsoever, the plaintiff’s
works so as to infringe the plaintiff’s exclusive rights and broadcast
reproduction rights.
II.

The defendant nos. 61 to 81 and its directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and, on their behalf, or anyone claiming
through, by or under it, are directed to suspend the domain name registration
of the defendant nos. 1 to 60, as per the details as given in Annexure-B to the
present order.
III.

The defendant nos. 61 to 81, are directed to disclose the following

information of defendant nos. 1 to 60:
a.

Complete details such as name, address, email address, phone

number, IP address, etc.
b.

Mode of payment along with payment details used for registration of

domain name by the registrant(s).
IV.

The defendant nos. 83 to 91, their directors, partners, proprietors,

officers, affiliates, servants, employees, and all others in capacity of
principal or agent acting for and on their behalf, or anyone claiming through,
by or under it, are directed to block access to the various websites identified
by the plaintiff, details of which are given as Annexure C.
V.

The defendant nos. 92 and 93 are directed to issue a notification

calling upon the various internet service providers registered under it to

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 10 of 27

<!-- page 17 -->

block access to the various websites identified by the plaintiff in the instant
suit, details of which are given as Annexure-C.
VI.

If during the pendency of the present suit, any further websites are

discovered by the plaintiff, which are illegally streaming the infringing
content, copyright of which is owned by the plaintiff, the plaintiff is granted
liberty to communicate the details of such websites to defendant no. 92
(Department of Telecommunications) and defendant no. 93 (Ministry of
Electronics and Information Technology), for issuance of blocking orders
and simultaneously to the Internet Service Providers (“ISPs”) for blocking
the said websites.
VII. Upon receiving the said intimation from the plaintiff, the ISPs shall
take steps to immediately block the rogue websites in question.
VIII. The DOT and MEITY shall also issue necessary blocking orders
immediately upon the plaintiff, communicating the details of the websites,
which are illegally streaming the content, over which the plaintiff has rights.
IX.

After communication of details of the rogue websites to the concerned

authorities, the plaintiff shall continue to file affidavits with the Court, in
order to ensure that the Court is fully informed of the websites in respect of
which blocking orders are sought.
X.

If any website, which is not primarily an infringing site, is blocked

pursuant to the present order, they shall be permitted to approach this Court
by giving an undertaking that it does not intend to engage in any
unauthorized streaming of any content, over which the plaintiff has rights.
XI.

As and when new further websites are discovered by the plaintiff, the

plaintiff shall be at liberty to file an application for their impleadment, which
shall be taken up before the Joint Registrar (Judicial), and the order passed

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 11 of 27

<!-- page 18 -->

today shall be extended to the said newly impleaded website as well.
42.

Issue notice to the defendants by all permissible modes, upon filing of

process fee, returnable on the next date of hearing.
43.

Notice is accepted by learned counsel appearing for defendant no. 82.

44.

Let notice be issued to the other defendants.

45.

Let reply be filed within a period of four weeks.

46.

Rejoinder thereto, if any, be filed within two weeks, thereafter.

47.

Compliance of Order XXXIX Rule 3 CPC, be done, within a period

of one week from today.
48.

List before the Court on 7th March, 2025.

MINI PUSHKARNA, J
OCTOBER 24, 2024
ak

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 12 of 27

<!-- page 19 -->

Annexure-A

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 13 of 27

<!-- page 20 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 14 of 27

<!-- page 21 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 15 of 27

<!-- page 22 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 16 of 27

<!-- page 23 -->

Annexure-B

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 17 of 27

<!-- page 24 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 18 of 27

<!-- page 25 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 19 of 27

<!-- page 26 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 20 of 27

<!-- page 27 -->

Annexure-C

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 21 of 27

<!-- page 28 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 22 of 27

<!-- page 29 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 23 of 27

<!-- page 30 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 24 of 27

<!-- page 31 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 25 of 27

<!-- page 32 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 26 of 27

<!-- page 33 -->

CS(COMM) 937/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 28/10/2024 at 09:59:14

Page 27 of 27

<!-- page 34 -->

Code 50000.01
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM) NO. 937 OF 2024
IN THE MATTER OF:
…Plaintiff

Zee Entertainment Enterprises Ltd.
Versus

…Defendants

bollyzone.tv & Ors.
INDEX
S. No.
1.

2.

Particulars
Amended Memo of Parties reflecting
amended address of Defendant No 82,
Google LLC

Pg. No.
1 - 17

Proof of Service

Place: New Delhi
Date: 25th October 2024

Vivek Ayyagari (MAH/4861/2016),
Angad Singh Makkar (D/3579/2021),
Rishabh Rao (KAR/3753/2023)
Saikrishna & Associates
Advocates for the Plaintiff
57, Jor Bagh, New Delhi
+91 9897896284
angad@saikrishnaassociates.com

<!-- page 35 -->

1

Code 50000.01
IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM) NO. 937 OF 2024

IN THE MATTER OF:
Zee Entertainment Enterprises Limited
18th Floor, A Wing, Marathon Futurex,
N.M. Joshi Marg, Lower Parel,
Mumbai – 400 013
Email: Girish.kaul@zee.com
Mobile No.: 09711133934

Also at:

FC-19, Sector 16-A, Noida - 201301

Versus

1)

bollyzone.tv
Email: abuse@namecheap.com

2)

hdmovie2.farm
Also at: hdmoviehub.directory
Email: hdmoviehubforall@gmail.com

3)

hdhub4u.observer
Email: domainabuse@tucows.com

… Plaintiff

<!-- page 36 -->

2

4)

bollyflix.beer
Email: bollyflix@protonmail.com
Also at:
bollyflix.hair
Email: abuse@namecheap.com
bollymod.tech
Email: abuse@hostinger.com
topmovies.mov
Email: domainabuse@tucows.com
bollyflix.li

5)

ssrmovies.contact
Email: abuse@namesilo.com

6)

filmyzilla.com.sl
Email: abuse@101domain.com
Also at: gigerfilm.com
Email: support@hostingconcept.net

7)

movies4u.sydney
Email: abuse@namecheap.com

8)

7starhd.clinic
Email: abuse@namecheap.com
Also at:
7starhd.click
Email: abuse@spaceship.com
7starhd.vote
Email: abuse@godaddy.com

9)

banglaplex.art
Email: abuse@hostinger.com

<!-- page 37 -->

3

10)

full4movies.forum
Email: abuse@namecheap.com

11)

mkvcinemas.cat
Email: domainabuse@tucows.com

12)

1cinevood.pics
Email: abuse@namecheap.com

13)

skymovieshd.surf
Email: abuse@dynadot.com
Also at: skymovieshd.chat
Email: abuse@namecheap.com

14)

vegamovies4u.com.in
Email: contact@vegamovies.com.in
Also, at:
vegamovies.beer
Email: abuse@key-systems.net
vegamovies3.com.co
Email: abuse@namecheap.com

15)

downloadhub.mov
Email: abuse@namecheap.com

16)

1tamilblasters.dad
Email: domainabuse@tucows.com

17)

prmovies.day
Also at: uwatchfree.hair
Email: abuse@namecheap.com

<!-- page 38 -->

4

18)

dotmovies.beer
Email: abuse@key-systems.net
Also at:
dotmovies.fashion
Email: abuse@spaceship.com

19)

7hitmovies.zip
Email: abuse@namecheap.com
Also at:
10hitmovies.com
Email: abuse@dynadot.com
9xmovies.dating
Email: abuse@namecheap.com
m.9xflix.fashion
Email: myteam0006@gmail.com

20)

hdking.fit
Email: abuse@namecheap.com

21)

filmyfly.contact
Email: admin@Filmyfly.net
Also at:
filmyhit.gold
Email: abuse@namecheap.com
filmywap.pm
Email: terve@sarek.fi

22)

desiremovies.cymru
Email: domainabuse@tucows.com
Also at:
desiremovies.cam
Email: abuse@namecheap.com

<!-- page 39 -->

5

desiremovies.icu
Email: abuse@namecheap.com

23)

movierulz.dev
Email: abuse@namesilo.com
Also at:
movierulzfree.blog
Email: abuse@dynadot.com
5movierulz.cx
Email: registry@key-systems.net
movierulz.nl
Email: abuse@namecheap.com
7movierulz.so
Email: abuse@key-systems.net
5movierulz.mom
Email: abuse@nicenic.net
watchmovierulz.re
Email: terve@sarek.fi
ww6.4movierulz.to
5movierulz.limo
Email: abuse@namesilo.com

24)

thenextplanet.me
Email: TheNextPlanet@protonmail.com

25)

extramovies.foo
Email: abuse@namecheap.com

26)

1tamilmv.tf
Email: abuse@name.com

27)

luxmovies.shop

<!-- page 40 -->

6

Email: moviescontact@protonmail.com
Also at
luxmovies.co.in
Email: abuse@publicdomainregistry.com
28)

todaypk.llc
Email: abuse@namesilo.com

29)

ibomma.icu
Email: abuse@dynadot.com
Also at:
ibommamovies.shop
Email: abuse@namecheap.com

30)

undekhaserial.com
Email: abuse@namecheap.com

31)

khatrimaza.me.in
Email: abuse@dynadot.com
Also at: khatrimaza.forum, khatrimazaful.cyou
Email: abuse@namecheap.com

32)

apnetv.to
Also at:
serialbaba.to
apnetv.uk
apnetv.io
Email: abuse@namecheap.com

33)

1337x.to
Also at:
1337xhd.vip
Email: abuse@dynadot.com

<!-- page 41 -->

7

1337x.proxyninja.org
Email: domainabuse@tucows.com
34)

filmyhunk.com.ro
Also at: filmyhunk.club
Email: abuse@spaceship.com

35)

gillitv.live
Email: abuse@godaddy.com

36)

ofilmywap.org.vc
Email: abuse@dynadot.com
Also at
3filmywap.com
Email: abuse@spaceship.com

37)

ww1.pogolinks.digital
Email: abuse@namecheap.com

38)

parineetiserial.net
Email: abuse@namecheap.com

39)

dekhodramatv.live
Email: abuse@dynadot.com

40)

desitellybox.me
Email: abuse@spaceship.com

41)

yodesitv.info
Email: abuse@namecheap.com
Also at:
yodesiserials.su
Email: support@ardis.ru
yodesiserials.net

<!-- page 42 -->

8

Email: abuse@dynadot.com
42)

desirulez.co
Email: abuse@namecheap.com

43)

0gomovies.cam
Email: abuse@namecheap.com
Also at:
ww2.0gomovies.com.pk

44)

oldserials.co
Email: abuse@namecheap.com

45)

nowmelive.com
Email: abuse@enom.com

46)

movieplex.my
Email: abuse@namecheap.com

47)

apnaalo.net
Email: abuse@dynadot.com

48)

wwv.dhruvtara.su
Email: support@ardis.ru

49)

ziddidil.asia
Email: abuse@dynadot.com

50)

gogoserials.net
Email: abuse@dynadot.com
Also at:
wwv.gogodramas.su
Email: id@nic.ru ; sales@register.su

51)

madamsir.net

<!-- page 43 -->

9

Email: abuse@porkbun.com
52)

udariyaanserial.net
Email: abuse@namecheap.com

53)

anupama.blog
Email: abuse@enom.com

54)

wwu.herogayab.me/apnetv4
Email: abuse@dynadot.com

55)

ghumhaipyarmein.com
Email: domain-abuse@dreamhost.com

56)

afilmyhit.firm.in
Email: abuse@dynadot.com

57)

cinevez.shop
Email: abuse@dynadot.com

58)

worldfree4u.pm
Email: terve@sarek.fi

59)

bolly2tolly.art
Email: abuse@porkbun.com

60)

bdmusicboss.shop
Email: abuse@dynadot.com

61)

Godaddy.com, LLC
Email: grievanceofficer@godaddy.com
4th Floor, Statesman House, Barakhamba Road
Connaught Place, New Delhi,
Central Delhi, Delhi.

<!-- page 44 -->

10

Also at:
14455 North Hayden Road,
Suite 219 Scottsdale,
AZ, 85260, United States
62)

Namecheap LLC
Email: support@namecheap.com ;
grievance.officer@namecheap.com
4600 East Washington Street Suite 300,
Phoenix, Arizona 85034, US

63)

Porkbun LLC
21370 SW Langer Farms Parkway, Suite-142-429
Sherwood, OR 97140, US
Email: support@porkbun.com; abusegrievance-officerin@porkbun.com

64)

Spaceship, Inc.
4600 East Washington Street, Suite 300,
Phoenix, AZ 85034, USA
Email: support@spaceship.com

65)

Sarek Oy
Email: terve@sarek.fi
Urho Kekkosen Katu 4-6 E, 00100 Helsinki, Finland

66)

Hostinger
Email: support@hostinger.com
Hostinger, UAB. Jonavos str. 60C, 44192

67)

Namesilo LLP
Email: internaldomains@namesilo.com

<!-- page 45 -->

11

1300 E. Missouri Avenue Suite A-110
68)

Active- SU
Email: id@nic.ru ; sales@register.su
2/1, 3d Khoroshevskaya str., Moscow, 123308, Russian
Federation

69)

Tucows Inc.
96 Mowat Avenue
Toronto, ON M6K 3M1
Canada
Email: info@tucows.com; compliance@tucows.com

70)

Hosting Concepts B.V. d/b/a Registrar.eu,
Kipstraat 3c-5c Rotterdam 3
011 RR Netherlands
+ 31 104482296
Email: support@openprovider.com,
support@hostingconcept.net

71)

Endurance Digital Domain Technology Private Limited
HD 016 WeEork Bldg 4 Nesc,
Western Exp Highway, Goregaon East,
Mumbai, Maharashtra, India, 400063
Email: deepak.dalwani@newfold.com

72)

101domain GRS Limited,
Level 2, Plaza 3 Custom House Plaza
Harbourmaster Place, Dublin
D01 VY76, Ireland
Email: abuse@101domain.com

73)

Dynadot Inc.

<!-- page 46 -->

12

210 S Ellsworth Ave
#345 San Mateo,
CA 94401 USA
Email:

info@dynadot.com,

abuse@dynodot.com;

nixi.grievance.officer@dynadot.com
74)

Key-Systems GmbH
Kaiserstraße 172-174
66386 St. Ingbert
E-Mail: abuse@key-systems.net,
complaints@keysystems.net

75)

CentralNic Ltd.
4th Floor, Saddlers House,
44 Gutter Lane, London,
EC2V 6BR
Email: info@centralnic.com, abuse@centralnic.com

76)

Nicenic International Group Company Limited
NiceNIC.NET, Room 1704,
Hang Lung Center Paterson Street,
Causeway Bay, Hong Kong.
Email: email@nicenic.net

77)

Name.com, Inc.
414 14th Street #200
Denver, Colorado 80202
Email: abuse@name.com

78)

Netim
264 Avenue, Arthur Notebart,
59160, Lille, France

<!-- page 47 -->

13

Email: grievance-officier@netim.net
79)

LLC "Ardis"
236010, Kaliningrad,
Tenistaya Alley Str., 18, Russia
Email: support@ardis.ru

80)

Enom LLC
10400 NE 4th Street Floor 5,
Suite 121 Bellevue, WA 98004 USA
Email: legal@enom.com, abuse@enom.com

81)

DreamHost LLC
PMB #257 417,
Associated Rd. Brea,
CA 92821 USA
Email: abuse@dreamhost.com

82)

Google LLC,
1600 Amphitheatre Parkway,
Mountain View, California,
94043, United States of America.

83)

Atria Convergence Technologies Private Limited
99A/113A, Manorayana Palya
R.T. Nagar Bangalore – 560032

Also at:
2nd and 3rd Floor, No. 1,
Indian Express Building, Queen’s Road,
Bangalore – 560001, Karnataka

<!-- page 48 -->

14

Email: nodal.term@actcorp.in;
nodalofficer.ncr@actcorp.in, jitesh.chathambil@actcorp.in
84)

Mahanagar Telephone Nigam Ltd.
5th Floor, Mahanagar Doorsanchar Sadan
9, CGO Complex, Lodhi Road
New Delhi – 110003
E-mail: raco.mtnl@gmail.com; mtnlcsco@gmail.com;
gmracomtnl@gmail.com

85)

Reliance Jio Infocomm Limited
RCP 14 (TC 23), Phase 4,
B-Block, 3rd Floor,
C 4 130 Twane- belapur Road,
Gansoli, Navi Mumbai- 400701
E-mail: care@jio.com; Hitesh.marthak@relianceada.com;
Kapoor.guliani@ril.com; mahipal.singh@ril.com;
sunil.kr.gupta@ril.com; shilpi.kant@ril.com;
jyoti.jain@ril.com; rudraksha.sinha@ril.com;
neelakantan.an@ril.com

86)

Shyam Spectra Pvt. Ltd.
Plot No. 258,
Okhla Industrial Estate, Phase III,
New Delhi – 110020

Also at:
Plot No. 21-22, 3rd Floor,
Udyog Vihar, Phase IV,
Gurugram -122015
E-mail: info@spectra.co; compliance@spectra.co

<!-- page 49 -->

15

87)

Tata Teleservices Ltd.
A, E & F Blocks Voltas Premises - T. B. Kadam Marg
Chinchpokli, Mumbai – 400033
E-mail: pravin.jogani@tatatel.co.in;
anand.dalal@tatatel.co.in;
satya.yadav@tatatel.co.in

88)

Vodafone Idea Limited
Vodafone House,
Peninsula Corporate Park,
Ganpatrao Kadam Marg,
Lower Parel, Mumbai - 400 013 India

Also at:
Birla Centurion,
10th Floor, Plot no.794,
B Wing, Pandurang Budhkar Marg,
Worli, Mumbai - 400 030 India
E-mail: smitha.menon@vodafoneidea.com;
pankaj.kapdeo@vodafoneidea.com
Radhika.gokhale@vodafoneidea.com
sheena.thukral@vodafoneidea.com;
lavati.sairam@vodafoneidea.com
89)

Bharat Sanchar Nigam Ltd
Bharat Sanchar Bhawan, Regulation Cell
5th floor, Harish Chandra Mathur Lane
Janpath, New Delhi -110001
E-mail: ddg_reg@bsnl.co.in; sbkhare@bsnl.co.in;
averma@bsnl.co.in; sushmamishra71@gmail.com

<!-- page 50 -->

16

90)

Bharti Airtel Ltd.
Airtel Centre, Tower-A, 6th Floor
‘A’Wing, Plot No.16, Udyog Vihar
Ph - IV, Gurgaon – 122016
E-mail: amit.bhatia@airtel.com

91)

Hathway Cable & Datacom Pvt. Ltd.
‘Rahejas',4 floor, Main Avenue
Santacruz (W), Mumbai-40054
E-mail: ajay.singh@hathway.net; dulal@hathway.net;
sudhir.shetye@hathway.net

92)

Department of Telecommunications
Through Secretary,
Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi – 110001
E-mail: secy-dot@nic.in, dirds2-dot@nic.in

93)

Ministry of Electronics and Information Technology
Through the Director General (DIT) Cyber Laws & esecurity),
Electronics Niketan, 6, CGO Complex,
Lodi Road, New Delhi – 110003
E-mail: cyberlaw-legal@meity.gov.in;
gccyberlaw@meity.gov.in;
pkumar@meity.gov.in, sathya.s@meity.gov.in

94)

Ashok Kumar

… Defendants

<!-- page 51 -->

17

Place: New Delhi
Date: 25th October 2024

Vivek Ayyagari (MAH/4861/2016),
Angad Singh Makkar (D/3579/2021),
Rishabh Rao (KAR/3753/2023)
Saikrishna & Associates
Advocates for the Plaintiff
57, Jor Bagh, New Delhi
+91 9897896284
angad@saikrishnaassociates.com

Note: Defendant No. 1 along with Defendant Nos. 2 – 60 are the
main contesting Defendants.

<!-- page 52 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
