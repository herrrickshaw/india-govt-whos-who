---
doc_id: "a06fb38eefde68df"
source_url: "https://pharma-dept.gov.in/sites/default/files/DoP%20Corrigendum%20dated%2013.08.2021.pdf"
ministry: "Department of Pharmaceuticals (DoPs)"
title: "Corrigendum (Dated 13th August, 2021) (1.81 MB)"
date: ""
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a85a6bce810eabda"
---

<!-- page 1 -->

AO / No. 31026/92/2020-Policy
HN ALAR / Government of India
रसायन एवं उर्वरक मंत्रालय / Ministry of Chemicals and Fertilizers
3itver fast / Department of Pharmaceuticals
के मर मर ak
शास्त्री भवन, नई दिल्‍ली
Shastri Bhawan, New Delhi
Dated the 13" August, 2021
wyfeeaa / ufefrg/CORRIGENDUM / ADDENDUM द्धेपत्र /प ‘(CORRIGENDUM / ADDENDUM
Subject:- _ Operational Guidelines for the Production Linked Incentive (PLI)
Scheme for Pharmaceuticals — reg.

In continuation to corrigenda of even number dated 30.06.2021 and 22.07.2021
issued by this Department on the above-mentioned subject, the undersigned is directed
to convey the following corrigendum/addendum w.r.t. the operational guidelines of the
PLI Scheme for Pharmaceuticals:

2. Corrigendum/Addendum dated 224 July, 2021 stands withdrawn.
35 The revised clause 2.6 shall be read as follows:
Application Window: Time period allowed for filing of applications. The application
window shall be from 2" June, 2021 to 31% August, 2021 (inclusive).
4. A new sub-clause 4.6.4 under existing Clause 4.6 is added as follows:
4.6.4. Only one applicant, on behalf of its Group Companies (as defined in Clause No.
2.13), shall be eligible for selection under the Scheme. The applicant and its Group
Companies where the eligible products get manufactured will be considered collectively
for the purpose of ascertaining = Threshold/Committed —_ Investments,
Threshold/Incremental sales and Incentives under the scheme.
3: The revised clause 4.1 shall read as follows:
4.1 The selection of applicants in each group (except invitro Diagnostic medical
devices) will be governed by following parameters:
Sr. [Group | Selection parameter Weightage|
INo.
Gross manufacturing investment of applicant/group
1 A/B_ | company in India in 10 years during FY 2010-11 to FY 30%
2019-20

<!-- page 2 -->

Number of ANDA/NDA/DMF/CEP, as the case may be,
of applicant/ group company from either USFDA/
EDQM/ EMA/ Swissmedic/ UK MHRA/ PDMA/ 30%
Health Canada/ TGA/ ANVISA / Regulatory agency of
any country which is a member of PICS / Number of
WHO-PQ pharmaceutical products as on 01.04.2021
R&D expenditure of applicant/group company as a % of
GMR from pharmaceutical goods in FY 2017-18 to FY 40%
2019-2020.
Gross manufacturing investment of applicant/group 7
company in India in 10 years during FY 2010-11 to FY 30%
2019-20
Number of ANDA/NDA/DMF/CEP, as the case may be,
of applicant/ group company from either USFDA/
2 c EDQM/ EMA/ Swissmedic/ UK MHRA/ PDMA/ 30%
Health Canada/ TGA/ ANVISA / Regulatory agency of
any country which is a member of PICS / Number of
WHO-PQ pharmaceutical products as on 01.04.2021
Number of manufacturing plants in India owned by
applicant/group company and approved by either
USFDA/ EDQM/ EMA/ UK MHRA/ PMDA/ Health
c Canada/ TGA/ ANVISA/ Regulatory agency of any 50%
3 (MSME) country which is a member of PICS or having WHO-
“~"“) GMP compliance certification from a State Licensing
Authority as on 01.04.2021
=
50%
scheme
Note 1: For an applicant manufacturing special empty capsules like HPMC,
Pullulan, enteric etc. or complex excipients, the NDA/ANDA containing details (name
of manufacturer/address of the plant) of special empty capsule/ complex excipient
manufactured by the applicant will also be counted for such an applicant.
Note 2: As per above mentioned changes in clause 4.1, there will be
corresponding changes in the Appendix K and Appendix I of the Operational Guidelines
of the scheme.
—-27

<!-- page 3 -->

6. The revised table in clause 7.2.3 of the Operational Guidelines, shall read as
follows:
(Figures are in Rs crore)
Name of Group | Incentive Ceiling Ceiling of Total Incentive
Additional Ceiling
Incentive, if an
1000 1200
Group C (MSME)|Committed Investment20% of Committed/120% of Committed}
r Rs 50 croreJ[nvestment or Rs 1Qinvestment or Rs 6
hichever is minimum{crore, whichever iscrore, whichever is
inimum inimum
ds This issues with the approval of the Competent Authority.
eee.
(Dr. Sumit Garg)
Deputy Secretary
Tel- 23389840
To
1. NIC, Department of Pharmaceuticals with the request to upload the same on
the website of the Department.
2. Shri. Ravi Tyagi, CGM, SIDBI (PMA)
3. Members of the Technical Committee
4. All Pharmaceutical/IVD associations
5. PS to Minister, Chemicals and Fertilizers
6. PS to MoS, Chemicals and Fertilizers
7. Invest India
~3-
