---
doc_id: "9da3cbe43d04cbd4"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/f0d90f7635eba88068979e1339544275.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendmet in Recruitment Rules for the post of '' Nurisng Officer in Nursing Cadre ' in Safdarjung Hospital,New Delhi."
date: "2020-07-26"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e0820dc242f8b3ce"
---

<!-- page 1 -->

GOVERNMENT OF

MtNtsTRy oF HEATTH nr\ro reir/lr-iv
'NDIA

wer-rnne

Public Notice on draft Recruitment
Rules for the post of ,,Nursing
Officer,,in Safdarjung Hospital, New Delhi.

ln comptiance with DopT,s OM. No. AB_14017161/2008_Estt.(RR)

dated 13.'10.15, the draft Recruitr
for post of "Nursing officer"
safdarjuns Hospitar, New ,",n, ,.lJnt"xll""
The stakeholders, interested in making
any objections/comments or
suggestions on the draft Recruitment
Rules may Oo so in writing, w,tt in
period of 30 days from the date
of publication ot Or"f, n""rrnr,"n, nrf"."
to Section Officer (MH_I), Room No.4O5A,
Oirectorate Cenlrai'"or Heatttr
Services, Nirman Bhawan, Maulana
Azad Road, New Delhi-l10108 or at
e-mail address: medicathospitat6.l
@gmait.com.

Director (Hospsital)
Tele fax No. 23061334
New Dethi
Dated:

<!-- page 2 -->

[ro BE puBLtsHEt

ill,Ji:,'#E!f,?['r;,l+[if,flt8?1i?Ns,suB.sEc,oNo]
NOTIFICATION

New Delhi, the

ii {lt, i^:;I"'i'f"
;,'

;J,.,

$:. i "ffi

rs co n re rre d b y *

,2020.

ruu#I.Nl*f,g:;til,r,;;;:S:*i"#ili,ffi t;};d;,111"s1,ffi tilry:s
,r,. .. (1) These rules may be called
Hospitai, tv"* ol*,i,n,;Jil;4ffi':,.:8,.:l[i:#;:51";ff;lfll;*,Xffi,1il?,:)iiil::,

t

(2)They shall come

into force on the date

of their pubrication in

theofficiar Gazette.

2.

:iiy, :"d';;:i

Nursins orricer
g^ Hosoita r, New
:' #B?j$ i:ffiffi1|-Y,:'l',?o,s-ardarjans
Der h i,
Derhi,
fJ*,[ffi
-y,:,:,'?^,.",,1, ?,^ l Hospitar,,-N_"y
;ll
relating 11,'931
reratinstonumbeioip!,t,lr-;#ffi
to number".:yo
or postslfor irr" L.'ii",
p11;g;19,
rn
cotumn
(2)
the iorrowin,,

JJfr:1lffiTd3,il:.,:;!i;".*l:rr,:,,:*#3#
.",.*.,ljlt

*Subject

to variation dependent onworktoad.

(A. 1 1 0 1 8/0 st2O2O_MH_il)

Under secretary to the cor"r[P,.,fEl]

]riti3

Note: The Ministry,?f^!",rlS and Famiry
werfare, safdarjang Hospitar, New Derhi,
officer , Group - 1B' post n"*itr"ri'fui;;
Nursing
,;0i;;;rJ'pubrished in the Gazette of rndia,
sub-sectio, rij, vroe notiric.tior,-i,iroer
G.s.R 4T

ffii[ ??11:n ''

, dated the

30rh
