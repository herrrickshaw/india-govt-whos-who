---
doc_id: "9dc3d9ddfbd69e73"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_68ee182b45ee45.20171304.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "The additional charge of ADGF (PT&E) & MS (NTCA), MoEFCC, New Delhi is hereby extended for a futher period of three (03) months, order dated 14-10-2025"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c86e2dfb5e84458d"
---

<!-- page 1 -->

Computer No: 148698
No. 12016/05/2021-IFS.I
Government of India
Ministry of Environment, Forest and Climate Change
ao OR

6" Floor, Prithvi Wing,

Indira Paryavaran Bhawan, Jor Bagh Road,

Ali Ganj, New Delhi-110003.
Dated Ue MOetober, 2025. ।
|
OFFICE ORDER 1
. The additional charge of ADGF (PT&E) & MS (NTCA), MoEFCC, New Delhi, |
which was earlier assigned to Shri Sanjayan Kumar, IGF(NTCA), New Delhi w.e.f. |
14.07.2025 for a period of 03 months is hereby extended for a futher period of three (03) |
months with immediate effect or until further orders or posting of regular officer, whichever |
is earlier |
i
This has the approval of competent authority. |
(res |
|
ic ० |
(Pret rakash Maurya) |
Under Secretary to the Govt. of India |
Ph - 011-20819192 |
Distribution : |
i
i. PS to Hon’ble Minister of Environment, Forests and Climate Change; |
ii. PS to Hon’ble Minister of State Environment, Forests and Climate Change; |
iii. PPS to Secretary, MoEF& CC; |
iv. PPSs to DGF & SS/ADGF(WL)/ ADGF(FC)/ ADGF(PT)/CEO (CAMPA); |
v. PSs to All IGFs/JSs/Jt. CEO(CAMPA) |
vi. | JS(Admin), MoEFCC, New Delhi; i
vii. All DIGFs/AIGFs; i
viii. | Concerned officers; !
ix. All Regional Offices/RO(HQ); i
x. NIC cell for uploading on website; |

xi. Reference Folder.

i
i
|
|
|
I
|
|
