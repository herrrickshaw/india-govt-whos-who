---
doc_id: "a09dcb8ea66bfcd6"
source_url: "https://www.dpiit.gov.in/static/uploads/2026/06/77aa34c13a1f959328d64d442669688c.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Extension of Date for Vacancy Circular of Young Professionals (YPs) in SCO"
date: "2026-06-17"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4664bb928759d59c"
---

<!-- page 1 -->

SCO-11012(24)/1/2026-Estt. (€-227133) ~ o
1s
Government of India
Office of the Salt Commissioner,
2-A, Lavan Bhawan, Lavan Marg, Jhalana Doongri- Jaipur 302004
e-mail- lavan-rj@nic.in
Website: www. saltcomindia.gov.in
TOO. vin ata tea
Date:
Subject- Inviting applications for engagement of Young Professionals in SCO -
Extension of date- reg.

The undersigned is directed to refer to the vacancy circular SCO-
11012(24)/1/2026-Estt./(E-2271 33)/823 dated 22.05.2026 (copy enclosed) on the above-
mentioned subject and to Say that the last date of submitting online application has been
extended till 30.06.2026 (till 11.59 PM).

2. Interested eligible Candidates may submit their application online at the following
links: - “https://saltcomindia.gov.in/" & “https:/www.dpiit.gov.in/"
3. Rest of the contents in circular dated 22.05.2026 remains same.
Digitally signed by
Encls.As above, Bate ns Gene Tanw
18:50:42
(Dr. T C Tanwar)
Deputy Salt Commissioner
Copy to:
1. The Under Secretary, with reference to letter no. P-34023(11)/1/2020-Salt/(E-43555)
dated 26.02.2026.
2. Regional Office Mumbai & Chennai for vide circulation.
3. SCO Delhi, for information. हि
ve ‘Computer Section, with a request to make provisions and arrangements with NIC, to
upload this Circular on the website of the SCO & DPIIT.

<!-- page 2 -->

है a ५०» >ननरणनानन 3. “० .
i
f
File No,: \
sco 321012(24)/1/2026-Estt. (8-227133) 2
overnment of India 3
Depart Ministry of Commerce & Industry 7
men of Promotion of Industry and internal Trade
——_____ Salt Commissioner Organization (5८0)
Lavan Bhawan, jaipur
Dated:
VACANCY CIRCULAR a "4
३. का , 42 ॥॥॥ 207
» Applications are invited for engaging thirteen (13) Young Prof.
basis for one year (extendable up to three years) in the headquarter गा पिया हे,
Of SCO on consolidated remuneration of 70,000/- per month, हु
2. SCO functions through Regional Offices Circle Offices & Fact i
ati ‘ ‘ory Offices. Its major
functions are management of SCO land, leasing of salt pan land for salt manufacture,
leasing/licensing of salt pan land for public Purposes, collection of Assignment Fee &
Ground Rent, defending land related litigation, prevention of encroachments, execution of
development and welfare works.
3. Applications are invited for Posting at following locations:-
Office Total Category of YPs
| एल
Headquarters jaipur [05 fs : हट
Regional Office, Mumbail 03 02]
Regional Office, Chennai 6 [| ____o4 | 01]
TOTAL [asa oe
4. Complete details regarding Essential Qualifications & Experience, age limit.
consolidated monthly remuneration is given in the attached guidelines. Candidates are
advised to read the guidelines before applying online and fill up the complete and correct
Particulars. If any of the information/documents furnished by the candidate in his/her
application form found to be incorrect during documents verification or any stage, the |
candidature/appointment of the candidate shall be liable to be cancelled without
assigning any reason and action will be taken as per rules.
5. Interested and eligible candidates can apply online on the website of SCO
(https://saltcomindia.gov.in/) or DPIIT (https://www.dpiit.gov.in/).
6. The Department reserves right to reject any application without assigning any reason
for it.
7, Last date for submission of the application Is 20.06.2026 (11:59 P.M,),
Digitally slaned by
Qr, Tara Chand Tanwar
Date: 22-QS-2026
2As29:32
. (Or, T C Tanwar)
Deputy Salt Commissioner
1
File No. SCO-11012(24)/1/2026-ESTABLISHMENT SECTION (Computer No. 227133)
\
