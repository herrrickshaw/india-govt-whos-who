---
doc_id: "9fe8f7b85af48cfe"
source_url: "https://www.dhr.gov.in/static/uploads/2025/10/2b7ba4bb462f328b53fe59d4645e546e.pdf"
ministry: "Department of Health Research (DHR)"
title: "Evidence-based Guidelines for the use of Stem Cell Therapy in Neurological Conditions : Supplement"
date: "2025-07-01"
pages: 172
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2496e66866cc7a5e"
---

<!-- page 1 -->

Evidence-based Guidelines
for the use of
Stem Cell Therapy
Neurological Conditions
Supplement

January 2026

Department of Health Research
Directorate General of Health Services

Ministry of Health & Family Welfare
Government of India

<!-- page 2 -->

<!-- page 3 -->

CONTENTS
Abbreviations

v

1. STROKE

01

2. SPINAL CORD INJURY

45

3. AMYOTROPHIC LATERAL SCLEROSIS

85

4. MULTIPLE SCLEROSIS

107

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page iii

<!-- page 4 -->

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page iv

<!-- page 5 -->

ABBREVIATIONS
AIS
ADL
ALD
ADMSCs
AEs
AHSCT
ALS
ALSFRS-R

:
:
:
:
:
:
:
:

ASIA
BI
BM
BMA
BMAC
BM-MNCs
BM-MSCs
BMSCs
CBSCs
CD
CI
CoI
CSF
DMT
EDSS
ERG
EPCs
EQ-5D
ESCs
F/U
FVC
GDG
GRADE

:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:

haMPCs

:

hESCs
HHD
HIV
HMSC
HSCs
hUC
HuCNS-SCs
IA
ICA
ICH
IM

:
:
:
:
:
:
:
:
:
:
:

ASIA Impairment Scale
Activities of Daily Living
Aldehyde Dehydrogenase
Adipose tissue-Derived Mesenchymal Stem Cells
Adverse Events
Autologous Hematopoietic Stem Cell Transplantation
Amyotrophic Lateral Sclerosis
Amyotrophic Lateral Sclerosis Functional Rating Scale
Revised
American Spinal Injury Association
Barthel Index
Bone Marrow
Bone Marrow Aspiration
Bone Marrow Aspirate Concentrate
Bone Marrow Mononuclear Cells
Bone marrow derived Mesenchymal Stem/Stromal Cells
Bone Marrow Stromal Cells
Cord Blood Stem Cells
Cluster of Differentiation
Confidence Interval
Conflict of Interest
Cerebrospinal Fluid
Disease Modifying Therapy
Expanded Disability Status Scale
External Review Group
Epithelial Progenitor Cells
Euro-QoL- 5D
Embryonic Stem Cells
Follow-Up
Forced Vital Capacity
Guideline Development Group
Grading of Recommendations Assessment, Development and
Evaluation
Human Autologous Adipose-Derived Mesenchymal
Progenitor Cells
Human Embryonic Stem Cells
Hand-Held Dynamometry
Human Immunodeficiency Virus
Human Mesenchymal Stem Cell
Hematopoietic Stem Cells
Human Umbilical Cord
Human Central Nervous System Neural Stem Cells
Intra Arterial
Internal Carotid Artery
Intracerebral Haemorrhage
Intramuscular

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page v

<!-- page 6 -->

iPSCs
IS
IT
IV
MCA
MCID
MD
Med
MNCs
MPCs
mRS
MS
MSC
MSC-NTFs

:
:
:
:
:
:
:
:
:
:
:
:
:
:

MSCs
MSFC
MTX
NIHSS
NR
NSAID
NSCs
PBSCs
PET
PRISMA

:
:
:
:
:
:
:
:
:
:

PT
RCT
RoB 2
RPMS
RR
RRMS
SAEs
SCI
SCIM
SCLs
SD
SE
SF-36
SMD
SPMS
SR/MA
SVC
TEAEs
UCMSCs
VC

:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:
:

Induced Pluripotent Stem Cells
Ischemic Stroke
Intrathecal
Intravenous
Middle Cerebral Artery
Minimal Clinical Important Difference
Mean Difference
Median
Mononuclear Cells
Mesenchymal Progenitor Cells
Modified Rankin scale
Multiple Sclerosis
Mesenchymal Stem Cell
Mesenchymal Stem Cell Induced to Secrete High Levels of
Neurotrophic Factors
Mesenchymal Stem/Stromal Cells
Multiple Sclerosis Functional Composite
Methotrexate
National Institute of Health Stroke Scale
Not Reported
Non-Steroid Anti-Inflammatory Drug
Neural Stem Cells
Peripheral Hematopoietic Stem Cells
Positron Emission Tomography
Preferred Reporting Items for Systematic Reviews and MetaAnalysis
Physical Therapy
Randomized Controlled Trial
Risk of Bias 2
Rapidly Progressive Multiple Sclerosis
Relative Risk
Relapsing Remitting Multiple Sclerosis
Severe Adverse Events
Spinal Cord Injury
Spinal Cord Independence Measure
Spinal Cord Lesions
Standard Deviation
Standard Error
36-Item Short-form Health Survey
Standardized Mean Difference
Secondary Progressive Multiple Sclerosis
Systematic Review/Meta-Analysis
Slow Vital Capacity
Treatment Emergent Adverse Events
Umbilical Cord Mesenchymal Stem Cells
Vital Capacity

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page vi

<!-- page 7 -->

1. STROKE
i.

Key question in PICO format

ii.

Search strategy

iii.

PRISMA flow diagram

iv.

Summary of included studies

v.

Classification of studies based on level of stem cell manipulation

vi.

Evidence to decision framework

vii.

Data extraction

viii.

Publication bias

ix.

List of excluded studies

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 1

<!-- page 8 -->

i.
Key Question in PICO format:
In patients with stroke, what is the efficacy and safety of stem cell therapy as compared to usual
care?
Population: Patients with Ischemic stroke/ Hemorrhagic stroke
Subgroup analysis: Acute vs chronic; First/recurrent stroke
Intervention: Any Stem cell and product derived from stem cells
Comparator: Usual Care/ Conventional Care
Critical Outcomes: Efficacy: any measure of Disability and Handicap;
Safety outcomes: mortality, serious adverse events, any tumour formation;
Important: quality of life, other adverse events

ii.

Search Strategy
Search 1: Medline:
Line #
1
2
3
4
5
6
7
8
9
10

11
12
13

14
15
16
17
18

Query terms
Exp Cerebrovascular disease/
Exp Ischemic stroke/
Exp hemorrhagic stroke/
Cerebral hemorrhage/or exp stroke/or Hemorrhagic stroke/
Stroke/ or Brain Ischemia/
Brain infarction/
Cerebral arterial diseases/
Brain ischemia/
Intracranial bleed/
(Stroke* or Ischemic stroke* or Ischaemic stroke* or Intracranial hemorrhage* or
Intracranial haemorrhage* or Cerebrovascular disorders* or Brain infarct or cerebral
arterial disease or Intracranial embolism or Intracranial thrombosis or CVA or
CVD).m_titl.
Limit 10 to abstracts
(isch?emi$ adj5 (stroke$ or apoplex$ or cerebrovasc$ or cerebrovasc$ or cva$ or
attack$)).tw.
((Brain or cerebr$ or cerebell$ or vertebrobasil$ or hemisphere$ or intracra$ or
basal gang$ or putami$ or intracerebral or infratentorial or supratentorial or middle
cerebr$ or mca$ or anterior circulation) adj5 (isch?emi$ or infract$ or thrombo$ or
emboli$ or occlus$ or hypoxi$ or h?emorrhag$ )).tw.
Or/1-13
Exp stem cell transplantation/
Cell transplantation/
Stem cell therapy.mp.
Cord blood stem cell transplantation/

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 2

<!-- page 9 -->

19
20
21
22

23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52

Hematopoietic stem cell transplantation/
Mesenchymal stem cell transplantation/
Peripheral blood stem cell transplantation/
(Stem cell* or adult stem cell* or mesenchymal stem cell* or embryonic stem cell* or
fetal stem cell* or hematopietic stem cell* or peripheral blood stem cell* or
fibroblasts or myeloid progenitor cell or erythroid progenitor cell or multipotent
stem cell or myoblast or pluripotent stem cell or totipotent stem cells or tumor stem
cells).m_titl.
limit 22 to abstracts
((stem or progenitor or embry$ or fetal or foetal or umbilical or bone marrow or cord
blood adj5 cell or cells)).tw.
(cell adj5 (transplant$ or graft$)).tw.
(fibroblast$ or myoblast$).tw.
(fibroblast$ or myoblast$).tw.
Or 15-27
Randomized controlled trial/
Random allocation/
Controlled clinical Trial/
Control groups/
Clinical trials as topic/or clinical trials, phase I as topic/ or clinical trials, phase II as
topic/ or clinical trials., phase III as topic/ or clinical trials, phase IV as topic/
Double-blind method/
Single-blind method/
Placebos/
Placebo effect/
Drug evaluation/
Research design/
Randomized controlled trial.pt
Controlled clinical trial.pt
(clinical trial or clinical trial Phase I or clinical trial phase II or clinical trial phase III
or clinical trial phase IV).pt
(random$ or RCT or RCTs).tw.
(Controlled adj5 (trial$ or stud$)).tw.
(Clinical$ adj5 trial$).tw.
((Control or treatment or experiment$ or intervention)adj5 (group$ or subjects$ or
patients$).tw.
(quasi-random$ or quasi random$ or pseudo-random$ or pseud or random$).tw.
((Singl$ or doubl$ or tripl$ or trebl$) adj5 (blind$ or mask$)).tw.
Placebo$.tw.
Controls.tw.
Or/29-50
Exp animals/not humans.sh

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 3

<!-- page 10 -->

53
54

12 and 25 and 49
50 not 49

Search 2: Pubmed:
Line #
Query terms
1
Exp Cerebrovascular disease/
2
Exp Ischemic stroke/
3
Exp hemorrhagic stroke/
4
Cerebral hemorrhage /or exp stroke/or Hemorrhagic stroke/
5
Stroke/ or Brain Ischemia/
6
Brain infarction/
7
Cerebral arterial diseases/
8
Brain ischemia/
9
Intracranial bleed/
10
(Stroke* or Ischemic stroke* or Ischaemic stroke* or Intracranial hemorrhage* or
Intracranial haemorrhage* or Cerebrovascular disorders* or Brain infarct or cerebral
arterial disease or Intracranial embolisim or Intracranial thrombosis or CVA or
CVD).m_titl.
11
12
13

14
15
16
17
18
19
20
21
22

23
24
25

Limit 10 to abstracts
(isch?emi$ adj5 (stroke$ or apoplex$ or cerebrovasc$ or cerebrovasc$ or cva$ or
attack$)).tw.
((Brain or cerebr$ or cerebell$ or vertebrobasil$ or hemisphere$ or intracra$ or basal
gang$ or putami$ or intracerebral or infratentorial or supratentorial or middle
cerebr$ or mca$ or anterior circulation) adj5 (isch?emi$ or infract$ or thrombo$ or
emboli$ or occlus$ or hypoxi$ or h?emorrhag$ )).tw.
Or/1-13
Exp stem cell transplantation/
Cell transplantation/
Stem cell therapy.mp.
Cord blood stem cell transplantation/
Hematopoietic stem cell transplantation/
Mesenchymal stem cell transplantation/
Peripheral blood stem cell transplantation/
(Stem cell* or adult stem cell* or mesenchymal stem cell* or embryonic stem cell* or
fetal stem cell* or hematopietic stem cell* or peripheral blood stem cell* or fibroblasts
or myeloid progenitor cell or erythroid progenitor cell or multipotent stem cell or
myoblast or pluripotent stem cell or totipotent stem cells or tumor stem cells).m_titl.
limit 22 to abstracts
((stem or progenitor or embry$ or fetal or foetal or umbilical or bone marrow or cord
blood) adj5(cell or cells)).tw.
(cell adj5 (transplant$ or graft$)).tw.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 4

<!-- page 11 -->

26
28
29
30
31
32
33

47
48

(fibroblast$ or myoblast$).tw.
Or 15-27
Randomized controlled trial/
Random allocation/
Controlled clinical Trial/
Control groups/
Clinical trials as topic/or clinical trials, phase I as topic/ or clinical trials, phase II as
topic/ or clinical trials., phase III as topic/ or clinical trials, phase IV as topic/
Double-blind method/
Single-blind method/
Placebos/
Placebo effect/
Drug evaluation/
Research design/
Randomized controlled trial.pt
Controlled clinical trial.pt
(clinical trial or clinical trial Phase I or clinical trial phase II or clinical trial phase III or
clinical trial phase IV).pt
(random$ or RCT or RCTs).tw.
(Controlled adj5 (trial$ or stud$)).tw.
(Clinical$ adj5 trial$).tw.
((Control or treatment or experiment$ or intervention)adj5 (group$ or subjects$ or
patients$).tw.
(quasi-random$ or quasi random$ or pseudo-random$ or pseud or random$).tw.
((Singl$ or doubl$ or tripl$ or trebl$) adj5 (blind$ or mask$)).tw.

49
50
51
52
53
54

Placebo$.tw.
Controls.tw.
Or/29-50
Exp animals/not humans.sh
12 and 25 and 49
50 not 49

34
35
36
37
38
39
40
41
42
43
44
45
46

Search 3: Cochrane central:
Search Hits
#1
MeSH descriptor: [Ischemic Stroke] explode all trees: 994
#2
MeSH descriptor: [Cerebrovascular Disorders] explode all trees and with qualifier(s): [drug
therapy- DT, mortality - MO] 5167
#3
MeSH descriptor: [Hemorrhagic Stroke] explode all trees
40
#4
MeSH descriptor: [Stroke] 1 tree(s) exploded 15152
#5
(Brain ischemia):ab 1059
#6
(Intracranial bleed):ab 95

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 5

<!-- page 12 -->

#7 (Stroke* or Ischemic stroke* or Ischaemic stroke* or Intracranial hemorrhage* or
Intracranial haemorrhage* or Cerebrovascular disorders* or Brain infarct or cerebral arterial
disease or Intracranial embolism or Intracranial thrombosis or CVA or CVD):kw 30036
#8
#1 or #2 or #3 or #4 or #5 or #6 or #7
33122
#9
(stem cell transplantation):ti,ab,kw (Word variations have been searched) 11284
#10
(Stem cell therapy):ti,ab,kw 9841
#11
(Cord blood stem cell transplantation):ti,ab,kw (Word variations have been searched)
386
#12
("hematopoietic stem cell transplantation"):ti,ab,kw (Word variations have been searched)
4630
#13
(Mesenchymal stem cell transplantation):ti,ab,kw (Word variations have been searched)
972
#14
(Peripheral blood stem cell transplantation):ti,ab,kw (Word variations have been searched)
1977
#15 (Stem cell* or adult stem cell* or mesenchymal stem cell* or embryonic stem cell* or fetal
stem cell* or hematopietic stem cell* or peripheral blood stem cell* or fibroblasts or myeloid
progenitor cell or erythroid progenitor cell or multipotent stem cell or myoblast or pluripotent
stem cell or totipotent stem cells or tumor stem cells):kw (Word variations have been searched)
10372
#16
(stem or progenitor or embry$ or fetal or foetal or umbilical or bone marrow or cord blood
adj5 cell or cells):ab (Word variations have been searched) 139685
#17
(fibroblast$ or myoblast$):ti,ab,kw (Word variations have been searched) 3474
#18
#9 #11 or #12 or #13 or #14 or #15 or #16 or #17 143419
#19 ("randomized controlled trial"):ti,ab,kw (Word variations have been searched)
660973
#20
("random allocation"):ab (Word variations have been searched)
49593
#21
("controlled clinical trial"):ti (Word variations have been searched) 14165
#22 (Control groups):ab (Word variations have been searched) 555759
#23 (Clinical trials as topic or clinical trials, phase I as topic or clinical trials, phase II as topic or
clinical trials, phase III as topic or clinical trials, phase IV as topic):ab (Word variations have been
searched) 5754
#24
("double blind method"):ti,ab,kw (Word variations have been searched)
155836
#25
("single blind method"):ti,ab,kw (Word variations have been searched)
24786
#26
("placebo"):ab (Word variations have been searched) 339632
#27
("placebo effect"):ti,ab,kw (Word variations have been searched)
5570
#28
(Drug evaluation):ab (Word variations have been searched) 76217
#29
("research design"):ab (Word variations have been searched)6733
#30
#19 or #20 or #21 or #22 or #23 or #24 or #25 or #26 or #27 or #28 or #29
1194911
#31
#8 AND #18 AND #30 974

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 6

<!-- page 13 -->

iii.

PRISMA Flow Diagram

Out of a total of 15 RCTs in ischemic stroke, 11 trials met the inclusion criteria as specified by the
GDG and were used for synthesizing evidence.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 7

<!-- page 14 -->

iv. Summary of included studies:
Study

Population

Intervention

Comparator

Outcome

Comments

Bang et
al.
20051

30 participants with cerebral
infarction in the MCA
territory and severe
neurological deficit
Treatment 10, Control 20
After randomization 5
patients refused and were
considered under control
Treated between 32 and 61
days from stroke onset
Twenty participants with
subacute ischemic stroke in
the MCA territory and NIHSS
>7
10 Intervention and 10
control
Treated between 8 and 15
days from stroke onset
Nineteen participants with
acute or subacute ischemic
stroke, and NIHSS between 8
and 20.
Nine participants randomized
to Intervention arm 9 and 10
to placebo arm.
Five
participants
in
intervention arm and 1 in
placebo excluded prior to

Intravenous infusion of 2
boosts of 50 million
culture-expanded
autologous bone marrow
mesenchymal stem cells

Standard care
(Detail not
specified)

NIHSS score as an index of
neurological deficit and BI
and mRS as indices of
functional recovery at the
end of the 12-month
follow-up

Trial
excluded
after loss of 30%
post
randomization in
treatment arm
(as per terms of
reference given
by committee)

Intra-arterial infusion of
bone marrow–derived
mononuclear cells (mean
6.1 million) into the
ipsilateral MCA

Not specified

Primary safety outcomes
and secondary efficacy
endpoints as combined
mRS, BI, and NIHSS score
at the end of the 6-month
follow-up

Intravenous
administrationof
allogeneic mesenchymal
stem cells from adipose
tissue (1 million/kg)
within the first 2 weeks
after the onset of stroke
symptoms.

Placebo
(composition not
specified):0.1 ml
per kilogram of
patient’s weight
administered IV

Safety
and
efficacy
analysis (mRS, NIHSS, size
of
infarct,
and
biochemical markers)

Bhatia
et al.
20182

CelisRuiz et
al.
20223

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Trial
excluded
after loss of 30%
post
randomization in
treatment arm
(as per terms of
reference given
by committee)

Page 8

<!-- page 15 -->

Chen et
al.
20144

Fang et
al.
20185

treatment administration
Median time for treatment
administered was 12 days in
interventional arm and 13
days in placebo arm
Thirty
participants
with
chronic MCA infarction and
neurological
deficits
of
intermediate severity.
Treatment arm 15, Control
arm 15
Treated between 6 months to
5 years of stroke onset

Adult (18-80 years) with
acute ischemic stroke within
7 days from onset of
symptoms, with NIHSS >7 at
days 7 after onset.
Three
arm
study.
6
randomised to Epithelial
progenitor cell (EPC) arm, 6
to Bone marrow stromal cell
(BMSCs) arm and 6
to
placebo arm
One in EPC and 2 in BMSCs
arm did not receive the
intervention

Subcutaneous
granulocyte-colony
stimulating
factor
injections
(15
μg/kg/day)
for
5
consecutive
days,
followed by stereotaxic
implantation
of
autologous 3 to 8 million
CD34+
immunosorted
peripheral blood stem
cells
Two cycles 2.5 million
cells/kg of autologous
EPCs or BMSCs were
transplanted
intravenously, 1 week
apart

Conventional
treatment
with
antiplatelet
and
antihypertensive

Improvements in stroke
scales (NIHSS, European
Stroke
Scale,
and
European Stroke Scale
Motor sub scale) and
functional
outcomes
measure (mRS) from
baseline to the end of the
12-month follow-up

Underwent a bone
marrow aspiration
with
saline
infusion

Safety (adverse events,
neurological detoriation,
mortality) and efficacy by
NIHSS,
Scandinavian
stroke scale, functional
scales, Barthel Index and
mRS at 48 months

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

The
bone
marrow arm of
the study was
excluded
as
there was >30%
loss
post
randomization in
treatment arm

Page 9

<!-- page 16 -->

Hess et
al.
20176

Houkin
et al.
20247

Jaillard
et al.
20208

Participants
with
acute
ischemic stroke involving
MCA territory, with NIHSS
score 8 to 20, and infarct size
between 5 and 100 cc3, were
enrolled
Treatment arm 67, Control
arm 62
Treated between 24-48 hours
of stroke
Ischemic stroke with NIHSS
8-20, between 20-84 years.
Treatment arm 105, Control
102
Treated within 18-36 hours
of stroke onset

Intravenous infusion of
1200 million multipotent
progenitor cells (in a
solution
containing
PlasmaLyte-A, dimethyl
sulfoxide, and human
serum albumin)

Placebo solution
(containing
PlasmaLyte-A,
dimethyl sulfoxide,
and human serum
albumin, without
the
progenitor
cell)

The primary efficacy
endpoint combined the
mRS, the BI, and change in
NIHSS
score
from
baseline,
and
was
evaluated at day 90, and
at the end of the 12month follow-up

Single
intravenous
infusion of Multi Stem
over 30 to 60 min within
18- 36 hours of stroke
onset

Placebo
(Contained
only
cryopreservation
medium)

Ischemic stroke within 2
weeks of onset of stroke with
NIHSS >7.
Treatment arm 20, Control 11
Four patients did not receive
the intervention after
randomization as were
included in control. Median
days to receive the treatment
was 32 days (IQR 28-40)

Two different doses via
Intravenous infusion. The
first ten patients assigned
to treatment received
low-dose MSCs (100
million) and the next ten
patients received highdose MSCs (300 million)

Not specified
(Except for
rehabilitation
which was
provided in both
groups)

Primary: Proportion of
patients with excellent
outcome at 90 days. (mRS
≤1, NIHSS ≤1, BI ≥95).
Secondary:
Excellent
outcome at 365 days.,
distribution of mRS at 90
and 365, Proportion of
patients with mRS ≤ 1 and
≤ 2 at 90 days. Safety
outcomes
Safety outcome (Adverse
events) and efficacy
outcomes (NIHSS, mRS
and Barthel index) at 6
months and 24 months

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 10

<!-- page 17 -->

Jin et al.
20179

Law et
al.
202110

Lee et
al.
201011

Monich
e et al.
202312

Participants with subacute
cerebral infarction and NIHSS
score between 5 and 30.
Treatment arm 10, Control
arm 10
Treated between 3 weeks to 3
months of stroke onset
Participants with sub-acute
infarct (within 2 months)
with NIHSS between 10 and
35.
Treatment arm 9, Control arm
8
Median days to intervention
was 63 (IQR 61-122)
Participants
with
MCA
territory infarct and severe
neurological deficit
(modified NIHSS >7)
Treatment 16, Control 36
Treated between 4 and 9
weeks of stroke onset

Subarachnoid infusion of
a
cell
suspension
containing 10 million
autologous bone marrow
mononuclear cells

Routine medical
management
including
antiplatelet
and
statin

MCA territory stroke within
7days with NIHSS scale 6-20.
Treatment:39 (Low dose
BMMNCs 20, High dose
BMMNCs 19), Control 38
Median time for intervention
6 (IQR 5-7)

Autologous Bone marrow Standard
mononuclear
cells treatment
transfused
via
intraarterial route in two
different dose
(2million cells/kg and 5
million cells/kg)

Autologous bone marrow Standard medical
derived
mesenchymal care
stem cells administered
intravenously at a mean
dosage of 2.05 million
cells per kg

Intravenous infusion of 2
boosts of 50 million
culture-expanded
autologous bone marrow
mesenchymal stem cells

Not specified

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

stroke

Various
safety
and
efficacy
outcomes
(Barthel Index, mRS,
Functional measure and
Fugl-Meyer motor score)
through a 7-year followup
Efficacy outcomes by
NIHSS, mRS and BI scores
at 12 months

Functional
outcome Trial
excluded
(mRS) at the end of the after loss of 30%
last follow up
post
randomization in
treatment arm
(as per terms of
reference given
by committee)
Efficacy (mRS, NIHSS, and
Barthel Index) and safety
at 6 months

Page 11

<!-- page 18 -->

Niizum
a et al.
202313

Prasad
et al.
201414

Savitz
et al.
201915

Ischemic stroke patients with
NIHSS ≥6 and mRS ≥3 within
14-28 days of onset stroke
Treatment 27, Control 10
Treated between 14-28 days
of stroke
Participants with anterior
circulation ischemic stroke,
onset within 7-30 days NIHSS
≥7
Treatment 60, Control 60
Treated within 7-30 days of
stroke onset

First time MCA territory
stroke with mRS>/3
Treatment 29, Placebo 19
Treated between 14-20 days

Allogenic muse cell-based
product (CL2020), 15
million cells/15 ml were
administered
intravenously

In control arm 15
ml of placebo was
administered.
Placebo was of
same composition
without the cells
Intravenous infusion of a Conventional
mean of 280 million treatment
autologous bone marrow
mononuclear stem cells

Safety and efficacy (mRS,
NIHSS, Barthel Index, EU5D-5L) at 52 weeks

Primary
efficacy
measures e.g. mRS and BI
at
6
months
and
Secondary outcome of
NIHSS at 1 year. Safety
outcome included death,
adverse
events,
epileptiform discharges
and any new growth in
PET scan
Single internal carotid Sham
infusion Safety of delivery of ALDin
the 401 cells and efficacy as
infusion of 3.08 million given
autologous Bone-marrow placebo arm
measured
by
mRS,
derived ALD-401 cells
Secondary outcomes were
NIHSS, Barthel Index and
EQ-5D at 3month sand 12
months

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 12

<!-- page 19 -->

v. Classification of studies on the basis of level of manipulation of the stem cell/ Stem cell derived product used (interpreted by the
Secretariat as defined by CDSCO* and the information provided in the trial itself):
S. No.
1.

Trial
Details
Bang et
al.
2005

2.

Bhatia
et al.
2018

3.

Chen et
al.
2014

4.

Fang et
al.
2018

5.

Hess et
al.
2017

Intervention

Level of
Information extracted from trial
manipulation
Autologous
MSCsIntravenous More
“Culture expanded MSCs… Cells checked for SH-2 and SH-4
infusion of 2 boosts of 50 million
using flow cytometry”
culture-expanded autologous bone
marrow mesenchymal stem cells
Autologous BMMNC- Intra-arterial Less
“The BMMNC were separated using a ficoll density gradient
infusion of bone marrow–derived
centrifugation procedure… Quality control of the final cell
mononuclear cells (mean 6.1
product was performed to determine the total number of
million) into the ipsilateral MCA
cells, total BMMNC, total CD34+ cells, CD34+ cell percentage,
sterility, and viability.”
Autologous PBSCs- Subcutaneous Less
“Collected through leukapheresis, Immune sorting using
granulocyte-colony
stimulating
CD34 antibody conjugated with nano-iron beads (CD34factor injections (15μg/kg/day) for 5
nano-iron complex); percentage of CD34+ cells by flow
consecutive days, followed by
cytometry using CD34+ antibody”
stereotaxic
implantation
of
autologous 3 to 8 million CD34+
immune-sorted peripheral blood
stem cells
Autologous ex vivo expanded More
“BMMNC isolated and cultured; EPC identified using UEA-1
endothelial progenitor cells (EPCs)/
letin and endocytosis of Dil-Ac-LDL.”
bone marrow stromal cells (BMSCs)Two cycles of 2.5 million cells/kg of
culture-expanded autologous EPCs
or BMSCs were transplanted
intravenously, 1 week apart
Multipotent adult progenitor cells More
“MultiStem multipotent adult progenitor cells (Lonza,
(MAPC)- Intravenous infusion of
Walkersville, MD, USA; under contract with Athersys,
1200 million multipotent progenitor
Inc) were provided to the clinical sites in standard units;
cells (in a solution containing
commercially available MAPC provided; thawed and
PlasmaLyte-A, dimethyl sulfoxide,
combined to reach appropriate dose”
and human serum albumin)

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 13

<!-- page 20 -->

6.

Houkin
et al.
2024

7.

Jaillard
et al.
2020

8.

Jin et al.
2017

9.

Law et
al.
2021

10.

Lee et
al.
2010

11.

Moniche et al.
2023

Allogeneic
multipotent
adult
progenitor cells- Single intravenous
infusion of Multi Stem (HLCM051)
of 1.2 billion cells
Autologous mesenchymal stem cells
(MSCs)- Two different doses via
Intravenous infusion. The first ten
patients assigned to treatment
received low-dose MSCs (100
million) and the next ten patients
received high-dose MSCs (300
million)
Autologous bone marrow
mononuclear cells- Subarachnoid
infusion of a cell suspension
containing 10 million BMMNCs
Autologous BM-MSCs- cultureexpanded bone marrow derived
mesenchymal
stromal
cells
administered intravenously at a
mean dosage of 2 million cells per
kg
Autologous Mesenchymal Stem
Cell- Intravenous infusion of 2
boosts of 50 million cultureexpanded autologous bone marrow
mesenchymal stem cells
Autologous BMMNC- Autologous
Bone marrow mononuclear cells
transfused via intraarterial route in
two different doses (2 million
cells/kg and 5 million cells/kg)
The transplantation procedure was
done within 1–7 days of stroke
onset, as previously described.

More

“Bone
marrow
derived;
cryopreserved product”

More

“Autologous cell expansion done for 3–4 weeks”

Less

“Bone marrow mononuclear cells were collected the
treatment group using the density gradient method. A cell
suspension containing 1×107 bone marrow mononuclear
cells was then injected into the subarachnoid space,”
“BMMSCs were isolated based on density gradient
centrifugation and adherence to a plastic surface… BMMSCs
were cultured with proprietary BMMSC culture medium and
maintained in a 5% carbon dioxide incubator at 37°C.”

more

More

Less

commercially

available

“Bone marrow mononuclear cells were separated by Ficoll
density centrifugation. Mononuclear cells were cultured in a
175
cm2
flask
(Falcon,
Franklin
Lakes,
NJ,
http://www.bd.com) with low-glucose Dulbecco’s modified
Eagle’s medium.”
“The harvested bone marrow was centrifuged on a Ficoll
density gradient to isolate the mononuclear cells and obtain
the low and high doses (2×106 BMMNCs/kg or 5×106
BMMNCs/kg), which were washed and resuspended in 20
mL of Ringer lactate solution supplemented with 1%
heparin and 2·5% glucose and packaged in two sterile
syringes, with 10 mL each, for infusion into the patient.”

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 14

<!-- page 21 -->

12.

Niizuma et al.
2023

13.

Prasad
et al.
2014

14.

Savitz
et al.
2019

More
Allogenic muse cell-based product
(CL2020)- 15 million cells/15 ml
were administered intravenously
administered intravenously over
10–15 minutes.
Autologous BMMNC- Intravenous Less
infusion of a mean of 280 million
autologous
bone
marrow
mononuclear stem cells
Autologous Bone-marrow derived Less
ALD-401 cells- Single internal
carotid infusion of 3.08 million

“Clinical-grade CL2020 (1.5x107 cells/15 mL) was
manufactured from human (allogenic) MSC by Life Science,
Institute, Inc, Japan. Commercially available; derived from
mesenchymal stem cells”
“BMSCs were separated by ficoll density separation method.
Immunophenotyping to count CD34+ cells was done using
flow cytometry. The cells suspended in phosphate-buffered
saline were infused into antecubital vein of the patients in
BMSC arm.”
“Cell isolation and manufacturing of ALD-401 cells. ALD-401
is an enriched population of aldehyde dehydrogenase- bright
stem cells… Cells were administered a mean and median of 2
days, and in no case >3 days from harvest.”

* as defined by CDSCO in Annexure- I of the guideline document.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 15

<!-- page 22 -->

vi. Evidence to Decision Framework:
QUESTION
In patients with Ischemic stroke, what is the efficacy and safety of stem cell therapy compared to usual care?
POPULATION:

Ischemic stroke

INTERVENTION:

Stem cell transplantation

COMPARISON:

Usual Care

MAIN
OUTCOMES:

Disability, Dependency, All-cause mortality, Serious Adverse Events

SETTING:

Hospital

PERSPECTIVE:

Health Systems/Population

BACKGROUND:

CONFLICT OF
INTERESTS:

Stroke is a leading cause of morbidity and mortality worldwide, with very large healthcare and social costs resulting in
a major economic burden on the patient, family and society. The Global Burden of Disease study found that globally,
stroke remained the second-leading cause of death (11·6% [10·8–12·2] of total deaths) and the third-leading cause of
death and disability combined (5·7% [5·1–6·2] of total DALYs) in 2019. Despite the availability of numerous medical
innovations, interventions and therapeutic approaches, it continues to be one of the leading causes of disability
worldwide.16-18
None

ASSESSMENT
Problem
Is the problem a priority?
JUDGEMENT

RESEARCH EVIDENCE

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

ADDITIONAL
CONSIDERATIONS

Page 16

<!-- page 23 -->

○ No
○ Probably no
○ Probably yes
● Yes
○ Varies
○ Don't know

Stroke is a leading cause of morbidity and mortality worldwide, with very large
healthcare and social costs. Majority of the strokes are ischemic in nature caused by
interruption of blood flow leading to irreversible damage to the brain. The use of
therapeutic options like thrombolysis and thrombectomy is limited due to narrow
time window and strict selection criteria for patients. Therefore, there is a strong
demand for alternative therapeutic approaches.16,18

Desirable Effects
How substantial are the desirable anticipated effects?
JUDGEMENT
● Trivial
○ Small
○ Moderate
○ Large
○ Varies
○ Don't know

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

Disability: Eleven trials, with a total of 697 participants, reported the Modified The GDG decided
Rankin Scale (mRS) score at the end of follow up (ranged from 6 months to 7 years). the following MCID
The mean difference of mRS was -0.35 (95% CI: -0.51 to -0.19) in the stem cell arm for
the
critical
as comparison to usual care. There seems to be a trivial reduction in the disability outcomes.
with the use of stem cell therapy i.e. less than half of the MCID of one (dotted line). MCID
of
mRS
Therefore, the effect observed is statistically significant but unimportant clinically. SCALE:
1
level
Dependency: Five trials, with a total of 197 participants, reported the Barthel Index change
is
(BI) score as a continuous variable at the end of follow up. (Follow-up period considered
ranged from 1 year to 7 years) The mean difference in BI was 12.1 (95% CI: -2.19 to clinically important.
26.38) in stem cell arm compared to usual care. The difference was statistically non- MCID of Barthel
significant in pooled analysis.
Index: The most
All-cause mortality: Twelve studies with a total of 745 participants and 67 events conservative
reported mortality. Pooled analysis yielded a risk ratio of 0.83 (95% CI: 0.54 to estimate of the
1.28) in the stem cell armas compared to usual care, which was statistically non- MCID is 10 points.
significant.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 17

<!-- page 24 -->

Undesirable Effects
How substantial are the undesirable anticipated effects?
JUDGEMENT
○ Trivial
○ Small
○ Moderate
○ Large
● Varies
○ Don't know

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

Serious Adverse Events: Below is a tabulated description of the serious
adverse events reported by the trials:
Outcomes

No of studies
reporting

Total
events in
convention
al arm
35
7
43
7
5

Risk ratio (95 % CI)

12
7
7
5
4

Total
events in
stem cell
arm
32
11
52
11
11

Any cause mortality
Recurrent stroke
Infection
Seizure
Worsening of neurological
deficits
Development of any
neoplasm
Recurrent vascular events

5

0

4

0.20 (0.03 to 1.11)

4

13

4

1.85 (0.67 to 5.08)

0.83 (0.54 to 1.28)
0.95 (0.42 to 2.14)
0.89 (0.64 to 1.24)
0.84 (0.39 to 1.81)
2.09 (0.80 to 5.46)

Certainty of evidence
What is the overall certainty of the evidence of effects?
JUDGEMENT
● Very low

○ Low
○ Moderate
○ High
○ No included studies

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

The evidence in this review is of very low certainty due to high risk of bias,
inconsistency and imprecision in the effect shown by stem cell therapy.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 18

<!-- page 25 -->

Values
Is there important uncertainty about or variability in how much people value the main outcomes?
JUDGEMENT

RESEARCH EVIDENCE

○ Important uncertainty or
variability
○ Possibly important
uncertainty or variability
● Probably no important
uncertainty or variability
○ No important uncertainty or
variability

Main outcome is clinical improvement in the form of increased activity of daily living
and decreased disability which is likely to be highly valued by most persons.19

ADDITIONAL
CONSIDERATIONS

Balance of effects
Does the balance between desirable and undesirable effects favor the intervention or the comparison?
JUDGEMENT

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

○ Favors the comparison
It is less clear if benefits of stem cell intervention outweigh the harms, based on
○ Probably favors the
limited evidence.
comparison
● Does not favor either the
intervention or the comparison
○ Probably favors the
intervention
○ Favors the intervention
○ Varies
○ Don't know

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 19

<!-- page 26 -->

Resources required
How large are the resource requirements (costs)?
JUDGEMENT
● Large costs
○ Moderate costs
○ Negligible costs and savings
○ Moderate savings
○ Large savings
○ Varies
○ Don't know

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

No direct evidence of the resources required in stem cell transplantation in patients
with stroke was identified. The information provided by the websites of Insurance
Agencies and third party agencies is as follows:20,21,22
● 3.2-4.8 lacs (Medaccess)
● 5000-50,000 USD
However, indirect evidence shows that the median cost of hematopoietic stem cell
transplantation for hematological diseases was USD, $ 12,500 (range $ 10,331–
39,367) - Rs. 10,00,000.23

Certainty of evidence of required resources
What is the certainty of the evidence of resource requirements (costs)?
JUDGEMENT
○ Very low
○ Low
● Moderate
○ High
○ No included studies

RESEARCH EVIDENCE
No research evidence was identified.

ADDITIONAL
CONSIDERATIONS
The GDG members
were fairly certain
that
stem
cell
therapy
requires
large
resources.

Cost effectiveness
Does the cost-effectiveness of the intervention favor the intervention or the comparison?
JUDGEMENT

RESEARCH EVIDENCE

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

ADDITIONAL
CONSIDERATIONS

Page 20

<!-- page 27 -->

○ Favors the comparison
● Probably favors the
comparison
○ Does not favor either the
intervention or the comparison
○ Probably favors the
intervention
○ Favors the intervention
○ Varies
○ No included studies

Despite significant progress in clinical research in the use of SCT in neurological
diseases, economic evaluation of these therapies is still at a nascent stage.24

The
intervention
was not found to be
effective and hence
the
committee
deferred
to
comment on cost
effectiveness.

Equity
What would be the impact on health equity?
JUDGEMENT
○ Reduced
● Probably reduced
○ Probably no impact
○ Probably increased
○ Increased
○ Varies
○ Don't know

RESEARCH EVIDENCE
No research evidence was identified.

ADDITIONAL
CONSIDERATIONS
As stem cell therapy
is an expensive
treatment offered
only at tertiary
centers, it is likely
to reduce equity.

Acceptability
Is the intervention acceptable to key stakeholders?
JUDGEMENT

RESEARCH EVIDENCE

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

ADDITIONAL
CONSIDERATIONS

Page 21

<!-- page 28 -->

○ No
○ Probably no
● Probably yes
○ Yes
○ Varies
○ Don't know

Despite uncertainty regarding the medical risks and benefits associated with stem
cell injections, stroke survivors may still consider undergoing treatment in private,
unregulated clinics.25

Feasibility
Is the intervention feasible to implement?
JUDGEMENT
○ No

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS
Feasible to
implement in
tertiary
care centers.

No research evidence was identified.

○ Probably no
● Probably yes
○ Yes
○ Varies
○ Don't know

SUMMARY OF JUDGEMENTS
JUDGEMENT
PROBLEM

No

Probably no

Probably yes

Yes

Varies

Don't know

DESIRABLE EFFECTS

Trivial

Small

Moderate

Large

Varies

Don't know

UNDESIRABLE EFFECTS

Trivial

Small

Moderate

Large

Varies

Don't know

CERTAINTY OF EVIDENCE

Very low

Low

Moderate

High

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

No included
studies

Page 22

<!-- page 29 -->

VALUES

BALANCE OF EFFECTS

RESOURCES REQUIRED
CERTAINTY OF EVIDENCE
OF REQUIRED RESOURCES

Important
Possibly
uncertainty or important
variability
uncertainty or
variability
Favors the
comparison

Large
costs
Very low

Probably no No important
important uncertainty or
uncertainty or variability
variability

Does not favor
Probably
either the
Probably
Favors the
favors
the intervention favors the intervention
comparison
or the
intervention
comparison

Varies

Don't know

Moderate
costs

Negligible costs
and savings

Moderate
savings

Varies

Don't know

Low

Moderate

High

Large
savings

No included
studies

Does not favor
Probably
Probably
Favors the
either the
favors
the
favors the intervention
intervention or
comparison
intervention
the comparison

Varies

No included
studies

Varies

Don't know

COST EFFECTIVENESS

Favors the
comparison

EQUITY

Reduced

Probably
reduced

Probably no
impact

Probably
increased

ACCEPTABILITY

No

Probably no

Probably yes

Yes

Varies

Don't know

FEASIBILITY

No

Probably no

Probably yes

Yes

Varies

Don't know

TYPE OF RECOMMENDATION
Strong
Conditional
recommendation
recommendation
against the
against the
intervention
intervention
○

○

Use only in the context of
Conditional
rigorously conducted recommendation for
RCTs
either the
intervention or the
comparison
○
○

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Increased

Conditional
Strong
recommendation for recommendation for
the intervention
the intervention
○

○
Page 23

<!-- page 30 -->

CONCLUSIONS
Recommendation
Stem cell therapy is not recommended in routine clinical practice for the treatment of stroke*. It may be used only in the context of
rigorously conducted randomized controlled trials.
* The evidence comes from RCTs that included patients with ischemic stroke only. Whether stem cell therapy can be used in patients with haemorrhagic stroke is not known

as there are no RCTs in patients with haemorrhagic stroke.

Justification
Overall justification
This recommendation has been made as there is very low certainty evidence of trivial reduction in mortality and trivial improvement in
functional and disability scale. The undesirable effects are variable and heterogenous. In addition, there is uncertainty on the long-term
safety of stem cell therapy in patients with stroke. Results should be interpreted with caution, in view of various study limitations like high
risk of bias, small number of participants and/or events in the included studies and different sources of stem cell use.

Detailed justification
Desirable Effects
This judgment was made as there is very low certainty evidence of trivial reduction in mortality and trivial improvement in function and
disability.
Undesirable Effects
This judgment was made as the undesirable effects are variable and heterogenous. Also, the follow up period of one year is too small to
comment on the side effect profile and long-term safety is not known.
Certainty of evidence
Very Low certainty of Evidence
Resources required
The committee opined that stem cell treatment is associated with large costs.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 24

<!-- page 31 -->

vii. Data Extraction:
To ensure accuracy in data extraction, a standardized data extraction sheet was developed using Microsoft Excel. This sheet captured the
essential information from each eligible study, including the first author's name, year of publication, study site, study design, study
population, sample size, participant characteristics (age, gender), type of stroke, type of stem cell, route of stem cell administration, the
dose of stem cell, time for stem cell administration (Post-stroke), follow up duration, outcomes related to neurological function, and safety
profile. For the continuous variable, mean and standard deviation was extracted. In case, the data is provided in the standard error, the
same was converted to standard deviation using the formula SD= SE x √n. For the SD was calculated from confidence interval (CI) using
the formula SD = √N x (Upper limit- lower limit)/ 3.92. Data from graphs were extracted using Plot digitizer. For the modified Rankin
scale (mRS), the data were extracted from the shift analysis figures of mRS outcomes in relevant studies. The values were analyzed with
Microsoft excel to calculate the mean and SD. Two authors independently extracted the data from the included studies. In cases of
disagreement, a consensus was reached through discussion. For incomplete data, the corresponding authors of the articles were
contacted.
For continuous outcomes, the mean difference (MD) and 95% confidence interval (CI) were calculated for studies using same scales and
the standardized mean difference (SMD) with 95% CI was used if different scales were used. For dichotomous outcomes, RR and 95% CI
was calculated. The unit of analysis was the participants. I2 statistics was used to measure the heterogeneity. Fixed effect model was used
if heterogeneity was less than 50%, otherwise random effects model was used. Meta-regression and sub-group analysis were conducted
to examine the source of heterogeneity. For the primary outcomes, the pre specified subgroup analysis considered were: 1) phase of the
disease: acute (within 7 days of onset of stroke), subacute (between 7-30 days) or chronic (more than 30 days of onset of stroke), 2)
Types of treatment (types of stem cells) and 3) route of administration (Intravenous, intrarterial, intracerebral). Sensitivity analysis was
planned to assess the robustness of the pooled effects of the included studies. Additionally, funnel plot was applied to evaluate potential
publication bias of the main results of the included studies. All statistical analyses were conducted using RevMan Version 5.4 with a
significance level set at p < 0.05 (two-sided).
Study
Study type

1- Bang et al. 20051

Singleblind,
randomized,
controlled Phase I/II
clinical trial
Number of participants 30
Countries and setting:
Korea, Hospital

2-Bhatia et al. 20182

3-Celis-Ruiz
et
al.
3
2022
Prospective, randomized, Phase
IIa,
pilot,
double
open-label,
blinded–end prospective,
blind, placebo controlled
point study
RCT
20
19
India, Hospital
Spain, Hospital

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

4-Chen et al. 20144
randomized, single
controlled
phase II clinical trial

blind

30
Taiwan, Hospital
Page 25

<!-- page 32 -->

Duration of study 12 months
Follow
up
(post
intervention):
Method of assessment Diffusion
of disease condition:
imaging

weighted

Subgroup
analysis No
within study
Inclusion criteria:
• Observed within 7
days of the onset of
symptoms;
• Relevant
lesions
within the MCA
territory
as
assessed
using
DWI and
• NIHSS score of 7 or
more points after 7
days of admission

6 Months

24 months

12 months

Clinically and on imaging
conforming tothe MCA
territory stroke
No

CT/MRI

Ischemic stroke confirmed
by MRI

No

No

•
•

•

•
•
•

•

Exclusion criteria:

•

Lacunar syndrome,
hematological
causes of stroke,
malignant
diseases,
severe
comorbidity,
hepatic or renal
dysfunction,
or
unwillingness
toparticipate.

•

Age 20 to 80 years
Symptoms and signs of
clinically definite MCA
stroke (0 –14 days
postictus),
NIHSS score >7,
MCA territory stroke,
Recanalization/patency
of
the
involved
M1segment of the MCA
on imaging,
Patency of the carotid
arteries for intraarterial
access
of
cerebral circulation.
Cerebral hemorrhage
on CT/MR imaging,
imaging evidence of M1
MCA segment complete
occlusion,
hemodynamic
instability,
known
defect of clotting or
platelet
function,
severe
comorbidity
precluding
intra-

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

•
•

•
•

Moderate to severe •
ischemic
stroke •
(NIHSS 8-20)
Presenting within 24 •
hours
Ct/MRI compatible
with ischemic stroke
in MCA

Comatose patient,
evidence of brain
tumor,
primary
intraventricular,
intracerebral,
or
subarachnoid
hemorrhage
on
neuroimaging;cerebr
al
edema
with
midline shift; or
cerebellar
or

Age 35 to 75,
Onset of stroke between
6 months to 5 years,
NIHSs 9-20 with motor
deficits stable for 3
months

Patients
with
cancer,
infection,
increased
bleeding
tendency,
leukopenia,
thrombocytopenia,
hepatic/renal dysfunction,
or pregnancy

Page 26

<!-- page 33 -->

arterial intervention,
hepatic
dysfunction, •
renal
dysfunction,
pregnancy,
patients
likely to be unavailable
for follow-up, patients
with
evidence
of
chronic
illness
or
advanced
cancer,
patients
already
dependent in activities
of daily living before
the
present
acute
stroke (i.e., prestrike
mRS of >3), and refusal
to
give
informed
consent.

brainstem infarction,
Clinical or laboratory
signs suggestive of
active
infection,
including
human
immunodeficiency
virus and hepatitis B
and C, were also
considered exclusion
criteria, along with a
previous diagnosis of
dementia or any
health condition that
could
preclude
appropriate
diagnosis, treatment,
or follow-up

Recruitment/selection
of patients:

Random allocation by
randomization table

Randomization done, but
details not available

Computer-generated,
simple randomization

Intervention: Type of
stem cells with method
of
their
characterization, Route
of administration, Dose

Intravenous infusion
of 2 boosts of 50
million
cultureexpanded autologous
bone
marrow
mesenchymal
stem
cells. Cells had high
expression
of
SH
antigens

Intra-arterial infusion of
bone
marrow–derived
mononuclear cells (mean
6.1 million) into the
ipsilateral MCA

Intravenous
administration
of
allogeneic mesenchymal
stem cells from adipose
tissue (1 million / kg)
within the first 2 weeks
after the onset of stroke
symptoms

Outcomes
reported Functional
outcome The primary safety end
with time points
assessed at 7 days, 3, 6 point was clinically severe
Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Primary
safety

Participants were assigned
randomly (1:1) via SAS
software
Subcutaneous granulocytecolony stimulating factor
injections (15 μg/kg/day)
for 5 consecutive days,
followed by stereotaxic
implantation of autologous
3 to 8 million CD34+
immunosorted peripheral
blood stem cells

outcomes: Improvements in stroke
parameters. scales (NIHSS, European
Page 27

<!-- page 34 -->

and 12 months
Imaging (MRI): at 12
months

procedural complications
(increase in the NIHSS
score of >4 points),
symptomatic intracerebral
hemorrhage, new ischemic
lesions on imaging in the
intervened territory, or
death.
Secondary end
point
(good
clinical
outcome) was defined as
an mRS score of 0 –1 in
patients with an NIHSS
score of 8 –14 at admission
and an mRS score of
0 –2 in patients with an
NIHSS score of >14 at
admission
Not available

Secondary
outcomes:
efficacy analysis mRS,
NIHSS, size of infarct,
and
biochemical
markers. Time points:
Day 7, 3, 6, 12, 18 and 24
months

Stroke Scale, and European
Stroke Scale Motor sub
scale)
and
functional
outcomes measure (mRS)
from baseline

Spanish ministry of
Health and social policy

RoB2
Assessment: D1-High Risk
Specify separately for D2-High risk
D3- Some concerns
each domain
D4-Low risk
D5-Some concerns
Overall-High risk

D1-Some concerns
D2-Low risk
D3-Low risk
D4-Low risk
D5-Some concerns
Overall-Some concerns

D1- Low risk
D2-High risk
D3-Low risk
D4-Low risk
D5-High Risk
Overall-High risk

Taiwan department of
health clinical trial center of
excellence and Taiwan
national science council
D1-Low risk
D2-Low risk
D3-Low risk
D4-Low risk
D5-Low risk
Overall-Low risk

Study
Study type

Hess et al. 20176
Double-blind, randomized,
placebo-controlled, phase II

Houkin et al. 20247
Jaillard et al. 20208
Multicenter,
double- Single center, Open label
blind, parallel group, randomised control trial

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 28

Funding

Korea
Research
Foundation and
Korea Health 21 R&D

Fang et al. 20185
Single-blinded,
randomized, parallel,

Timepoints: 6-month sand
12 months

<!-- page 35 -->

placebo-controlled
trial
Number of participants 18
Countries and setting:
China, Hospital
Duration of study 24 months
Follow
up
(post
intervention):
Method of assessment Ischemic
stroke
of disease condition:
assessed with diffusion
weighted imaging

multicenter dose-escalation
clinical trial
129
UK and USA, Hospital
12 months

placebo controlled RCT
(Phase 2/3)
207
Japan, Hospital
12 months

with blinded
evaluation
31
France, Hospital
24 months

outcome

Hemispheric cortical infarct Acute
infarct MRI (DWI and FLAIR)
determined by DW-MRI
in the
anterior circulation with
brain
MRI
including
diffusion weighted imaging
No
No
Yes (Low dose and high
dose)- for safety outcomes)
• Age 18-83 years, with • Age >20 ye, 2- NIHSS • Age 18-70 years, 2NIHSS score 8-20 at
8-20 at baseline, 3NIHSS >7, 3- Ischemic
stroke of less than 2
baseline, 2-hemispheric
acute
infract
cortical infarct in the
involving
cerebral
weeks, 4- mRS score of
anterior
circulation
cortex
and
0-1 before stroke onset,
5- Wiling and able to
with
brain
MRI
measuring
more
including
diffusion
than 2 cm, 4-mRS
follow a rehabilitation
programe.
weighted
imaging
score of 0-1 before
showing an acute lesion
stroke onset.
measuring more than 5
mL and less than 100
mL.,
3-Treatemnt
window within 24-48
hours

Subgroup
analysis No
within study
Inclusion criteria
• Patients aged 18–
80 years, within 7
days of onset of
symptoms;
• Ischemic
lesion
withinthe middle
cerebral artery
territory
as
assessed
usingdiffusionweighted imaging;
3- NIHSS score ≥7
at day 7 after
onset;
and
4signed
informed
consent
Exclusion criteria:
• Lacunar syndrome; •
• Diagnosis
other
than
ischemic

If there was a change in
NIHSS score of four or
more points during at

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

•

Lacunar
brainstem
infarction,

or •
•

Very severe stroke with
possible fatal outcome,
NIHSS>24,
Page 29

<!-- page 36 -->

•
•

stroke
(e.g.,
intracranial
hemorrhage
or
intracranial
tumor);
Hematological
causes of stroke;
Severe respiratory,

•
•

hepatic,
or
renal
disorders;
• presence of severe
febrile illness or •
viral diseases;
• Malignant
•
diseases;
• Presence of
autoimmune diseases;
• Positive response
of penicillin skin
test, or multiple
drug allergies; and
• Breast-feeding or
pregnant women
Recruitment/selection Randomization
was
of patients:
done using layered
segment
randomization.
Intervention: Type of Two cycles 2.5 million
stem cells with method cells/kg of autologous
of
their EPCs or BMSCs were
characterization, Route transplanted
of administration, Dose intravenously, 1 week

least a 6 h period •
between screening and
randomization
Brainstem or lacunar
infarct;
Substantial comorbid
disease such as severe
congestive
heart •
failure,
chronic
obstructive pulmonary
disease, or renal or
hepatic failure;
An inability to undergo
an MRI scan, and
With a history of
splenectomy

Computer-generated
randomization, interactive
voice and web-response
system
Intravenous infusion of
1200 million multipotent
progenitor cells (in a
solution
containing
PlasmaLyte-A,
dimethyl

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Change in NIHSS
score of 4 or greater
during a minimum
period of 6 hours
between screening
and randomization,
and
Patients
who
received combined
reperfusion therapy
(intravenous
thrombolysis plus
mechanical
thrombectomy)

•
•
•
•

•
•

Baseline mRS>2,
History of myocardial
infract in less than 3
months,
Severe
psychiatric
illness,
History of malignant
diseases,
chemotherapy,
thromboembolic
disorder
within
6
months, severe kidney
and liver disease,
Contraindication
to
MRI,
Life expectancy less
than 3 months

Computer-generated
randomization process

Randomization done with
'Clininfo' program

Single
intravenous
infusion of MultiStem
over 30 to 60 min within
18- 36 hours of stroke
onset.

Two different doses via
Intravenous infusion. The
first ten patients assigned
to treatment received lowdose MSCs (100 million)
Page 30

<!-- page 37 -->

apart

Outcomes
reported
with time points

Funding

sulfoxide,
and
human Single unit (6ml vials) of
serum albumin) over 1 MultiStem contained 1.2
hour
billion cells (±20%),
cryopreserved
in
a
medium of Plasma-Lyte
A, dimethylsulfoxide and
human albumin.
Safety (adverse events, The
primary
efficacy Primary: Proportion of
neurological
endpoint combined the patients with excellent
detoriation, mortality) mRS, the BI, and change in
outcome at 90 days.
and efficacy by NIHSS, NIHSS score from baseline. (mRS ≤1, NIHSS ≤1, BI
Scandinavian
stroke Time points: Day 7, 30, 90
≥95)
Secondary:
Excellent
scale, functional scales, and 12 months
Barthel Index and mRS
outcome at 365 days,
Time points: 3,6,12
distribution of mRS at
and 24 months
90 and 365, Proportion
of patients with mRS ≤ 1
and ≤ 2 at 90 days.
And Safety outcomes
Timepoints: 3 and 12
months
Special Foundation for Athersys, Inc (Cleveland,
Healios
KK.
Science
and OH, USA)
Investigational products
Technology Key Plan of
were
provided
by
Guangdong
Athersys Inc
Province,
Special
Foundation for
Science
and
Technology Key Plan of
Guangzhou
City;
Clinical
Research

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

and the next ten patients
received high-dose MSCs
(300 million)

Safety outcome (Adverse
events)
and
efficacy
outcomes (NIHSS, mRS and
Barthel index)

Time points: 6 months and
24 months

French health Ministry.
Data analysis by RESSTORE
project,
funded
by
European
commission
under H2020 program.

Page 31

<!-- page 38 -->

Project of Southern
Medical
University,
Project of Outstanding
Young Talent Pool of
Zhujiang Hospital.
RoB2
Assessment: D1-Low risk
Specify separately for
D2-Some concerns
each domain
D3-Low risk
D4-Low risk
D5-High risk
Overall- High risk

D1-Low risk
D2-Low risk
D3-Low risk
D4-Low risk
D5-High risk
Overall- High risk

D1-Low risk
D2-Low risk
D3-Low risk
D4-Low risk
D5-Low risk
Overall- Low risk

D1-Low risk
D2-Some concerns
D3-Low risk
D4-Low risk
D5-High risk
Overall- High risk

Study
Study type

Jin et al. 20179
Randomized controlled
clinical trial

Law et al. 202110
Single center, assessorblinded
randomized
controlled, Phase 2 trial

Lee et al. 201011
Single-blind,
randomized, controlled
clinical trial

Moniche et al. 202312
Multicenter,
open-label,
phase
2
randomized
controlled trial

Number
of
participants
Countries and setting:
Duration of study
Follow
up
(post
intervention):
Method of assessment
of disease condition:
Subgroup
analysis
within study
Inclusion criteria:

20

17

85

77

China, Hospital
7 years

Malaysia, Hospital
12 months

South Korea, Hospital
5 years

Spain, Hospital
6 months

MRI

Infarct on MRI or CT scan

No

No

MRI-DWI
(Diffusion MRI-DWI
(Diffusion
weighted Imaging )
weighted Imaging )
No
No

•

Diagnosed ischemic •
stroke between 3 •
weeks and 3

Age 30-75years,
Stroke onset within2
months,

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

•
•

Age 30-75 years,
Observed within 7
days of the onset of

•
•

Age 18–80 years,
NIHSS score of 6–20 at
inclusion with at least 2
Page 32

<!-- page 39 -->

•

months prior,
NIHSS
score
between 5 and 30

•
•
•

Did not receive or failed
intravenous
thrombolytic therapy,
NIHSS score between
10-35.
Evidence of unilateral
MCA infarct

•

•

•

Exclusion criteria:

•

History
of
malignancy, serious
cardiopulmonary
insufficiency,
or
liver or kidney
dysfunction,
2patients who refuse
to be treated

•

•
•
•

•

Patients who were
medically unfit, with
worsening
consciousness;
Brain tumor or other
space-occupying lesion
on brain MRI;
Transient
ischemic
attacks
or
lacunar
infarct;
Suffered
from
infections, malignancy
and/or
primary
hematological
disorders;
Renal impairment, with
serum creatinine >200
µmol/L or creatinine

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

•
•
•
•
•
•
•
•

symptoms,
Lesions within the
middle
cerebral
artery territory as
assessed
using
diffusion-weighted
imaging (DWI);
Modified NIH Stroke
Scale [mNIHSS]≥ 7
pointson
the
seventh admission
day with stable
course; and
No
hematologic
disorders or bone
marrow
suppression
Lacunar infarction,
Premorbid
dependence;
Hematologic cause
of stroke;
Presence of severe
medical illness;
Presence of severe
febrile illness;
Hepatic or renal
dysfunction;
Positive response of
penicillin skin test;
and
Unwillingness
to
participate

•

•
•
•
•
•
•
•

•

points on motor items
in the NIHSS or aphasia,
and
Treatment
window
within 7 days of stroke
onset.

Patients with lacunar or
haemorrhagic stroke,
Pregnancy,
Childbearing potential,
Malignant
disease
during the past 5 years,
Life-threatening illness,
Stroke
of
haematological cause,
Significant
previous
disability
(prestroke
modified Rankin scale
[mRS] score ≥3), and
Severe comorbidity that
would prevent followup

Page 33

<!-- page 40 -->

clearance<30 ml/min,
• Liver impairment, with
serum
aspartate
transaminase
and
alanine
transaminase
four times greater than
the normal upper limit;
• Other
comorbidities
that would be deemed
contraindications
to
BMMSC transplantation
therapy
or
bone
marrow
aspiration
(BMA),
• Comorbidities
that
affected the ability to
obtain adequate stem
cells, such as chronic
debilitating
diseases,
frailty
or
known
osteoporosis; or
• Had contraindications
to brain MRI.
Recruitment/selection Patients
were Permuted
block Participants
were
of patients:
randomized but the randomization
randomly allocated by a
method mentioned
blinded,
independent
coordinator, using a
randomization table
Intervention: Type of
Subarachnoid infusion Autologous bone marrow Intravenous infusion of
stem
cells
with of a cell suspension derived mesenchymal stem 2 boosts of 50 million
method
of
their containing 10 million cells
administered culture-expanded
characterization,
autologous
bone intravenously at a mean autologous
bone
Route
of marrow mononuclear
dosage of 2.05 million cells marrow mesenchymal
stem cells
administration, Dose
cells
per kg
Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Randomization done by a
central
computerbased
procedure

Autologous Bone marrow
mononuclear
cells
transfused via intra-arterial
route in two different dose
(2 million cells/kg and 5
million cells/kg)
Page 34

<!-- page 41 -->

Outcomes
reported
with time points

Various safety and
efficacy
outcomes
(Barthel Index, mRS,
Functional
measure
and Fugl-Meyer motor
score) Time points: 3, 6,
12 months, 2, 3, 4, 5, 6,
7th year

Funding

Not available

RoB2
Assessment: D1-Some concerns
Specify separately for D2-Low risk
each domain
D3-Low risk
D4-Some concerns
D5-High risk
Overall- High risk

Study
Study type

Number of participants
Countries and setting:

Efficacy
outcomes
by
NIHSS, mRS and BI scores.
Timepoints: 45 days, 90
days, 6, 9 and 12 months

Primary: Long term
safety
outcome,
mortality and serious
adverse effects.
Secondary: Functional
outcome (mRS) at last
visit
Time points: Till last
visit (Median 3.5 year,
IQR 2.9-4.6 years)
National
University
of Korea Health 21 R&D
Malaysia and Cytopeutics Project, Ministry of
Sdn Bhd.
Health and Welfare,
Republic of Korea and
SBRI C-A9-216-1

D1- Some concerns
D2-Low risk
D3-Low risk
D4- Low risk
D5-Some concerns
Overall- Some concerns

Niizuma et al. 202313
Single
center,
Phase
2,
randomized,
double
blind
controlled trial
37
Japan, Hospital

D1-High risk
D2-Some concerns
D3-Low risk
D4- Low risk
D5-Some concerns
Overall- High risk

Prasad et al. 201414
Single-blind,
randomized,
controlled clinical trial
60
India, Hospital

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Efficacy (mRS, NIHSS, and
Barthel Index) and safety
outcomes
Time points: 3 and 6
months

Instituto de Salud Carlos III
co-funded by the European
Regional
Development
Fund/European
Social
Fund, Mutua Madrileña, and
the Regional Ministry of
Health of Andalusia
D1-Low risk
D2-Low risk
D3-Low risk
D4- Low risk
D5-Low risk
Overall- Low risk

Savitz et al. 201915
Randomized, sham controlled,
Parallel group, multicenter
Phase 2 trial
48
USA, Hospital
Page 35

<!-- page 42 -->

Duration of study Follow up
(post intervention):
Method of assessment of disease
condition:
Subgroup analysis within study
Inclusion criteria:

52 weeks

1 year

1 year

MRI

CT or MRI

CT or MRI

No
• Age 20-80 years,
• NIHSS scale >6,
• mRS score ≥ 3 at enrollment,
• An mRS score of 0 or 1
before
ischemic
stroke
(patient/family-reported),
and
• Who could receive study
treatment 14–28 days after
stroke onset

Yes
• Age 18-75 years,
• CT or MRI scan showing
relevant infarct within the
middle cerebral artery or
anterior cerebral artery
territory and excluding a
hematoma,
• Onset of stroke between 7
and 8,
• BI score of ≤50, 5-NIHSS
score of ≥7 and inability to
walk unaided or raise upper
limb by 90° and
• Clinically stable condition
≥48 hours

No
• Age 30-83 years,
• First time MCA ischemic
stroke,
• Persistent
neurological
deficits and mRS ≥3 at
randomization,
which
occurred between 9 and 15
days after the stroke.
• Demonstrated
vessel
patency with flow in the
ipsilateral carotid artery
(proximal internal carotid
artery [ICA]<50% stenosis
or proximal MCA occlusions
if there was collateral
circulation to the injured
area

Exclusion criteria:

•
•

•
•
•
•

•

•
•
•

Decreased consciousness,
Clinically
important
hemorrhagic transformation
by CT or MRI;
Cognitive impairment that
might
interfere
with
evaluation;
History
of
thromboembolism
(excluding previous stroke),
Systolic blood pressure
>200 mm Hg or diastolic

•
•
•
•

Lacunar syndrome,
Intubation, 3
Posterior circulation stroke,
Co-morbidity likely to limit
survival to less than 3 years,
Pre-stroke disability leading
to dependence on others for
activity of daily living,
In accessibility for follow up,
Allergy to local anaesthetic,
Unwillingness to provide

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

•
•
•
•

Patients unable to undergo
the bone marrow harvest,
return
Days after harvest for
intracarotid infusion,
Unable
to
undergo
angiography
Patients
with
clinically
significant
intracranial
hemorrhage,
Patients
with
previous
disability with mRS ≥1
Page 36

<!-- page 43 -->

blood pressure >120 mm Hg,
• Current
or
previous
malignancy,
• Collagen disease or related
diseases,
• Diabetes
with
glycated
hemoglobin A1c >10%,
• Active infections requiring
treatment,
• Severe complications,
• Current use of systemic
steroids
or
immunosuppressants,
• Positive for hepatitis B virus
surface antigen, hepatitis C
virus
antibody,
human
immunodeficiency
virus
antibody,
human
Tcell
leukemia virus type 1
antibody, or syphilis;
• Pregnant or breastfeeding;
or
• History of hypersensitivity
to
aminoglycoside
antibiotics, human serum
albumin preparations, or
proteins of bovine or
porcine origin
Recruitment/selection
of Patients were randomized by
patients:
Web response system was used
for sequence allocation method
by minimization method.
Intervention: Type of stem cells Allogenic
muse
cell-based
with
method
of
their product (CL2020), 15 million

•
•
•
•
•

written informed consent,
Symptoms suggestive of
acute cardiac,
Hepatic or renal disease,
Pregnancy,
HIV positivity, or
Participation in any other
trial.

Participants were randomly
assigned by a central computer,
using
permuted
block
randomization
Intravenous infusion of a mean
of 280 million autologous bone

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

•

before stroke.
Patients who could not be
temporally
discontinued
from
systemic
anticoagulation for the bone
marrow harvest

Central randomization scheme
conducted by PharPoint Inc

Single internal carotid infusion
of 3.08 million of autologous
Page 37

<!-- page 44 -->

characterization,
Route
of
administration, Dose
Outcomes reported with time
points

cells/15 ml were administered
intravenously
Safety and efficacy (mRS, NIHSS,
Barthel Index, EU- 5D-5L)
Time points: Outcomes assessed
every 4 weeks till 52 weeks

Funding

Life Science Institute,
(manufacturer of CL2020)

RoB2
Assessment:
Specify
separately for each domain

D1-Low risk
D2-Some concerns
D3-Low risk
D4-Low risk
D5-Low risk
Overall-Some concerns

Inc.,

marrow mononuclear stem cells
Primary
efficacy
measurese.gmRS and BI at 6
months and Secondary outcome
of NIHSS at 1 year. Safety
outcome
included
death,
adverse events, epileptiform
discharges and any new growth
in PET scan.
Time points: 6 months and 1
year
Department of Biotechnology,
Ministry
of
Science
and
Technology, Government of
India
D1-Low risk
D2-Low risk
D3-Low risk
D4-Low risk
D5-Low risk
Overall-Low risk

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Bone-marrow derived ALD-401
cells.
Safety of delivery of ALD-401
cells and efficacy as measured
by mRS, Secondary outcomes
were NIHSS, Barthel Index and
EQ-5D at 3 months

Aldagen, Inc, a wholly owned
subsidiary of Cytomedix, Inc.
Partial Funding by a grant from
the Robertson Foundation to
Duke University.
D1-Low risk
D2-Low risk
D3-Low risk
D4-Low risk
D5-High risk
Overall-High risk

Page 38

<!-- page 45 -->

viii. Publication bias
Funnel plot: Modified Rankin Scale

Funnel plot: Barthel Index

Funnel plot: All-cause mortality

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 39

<!-- page 46 -->

ix. List of Excluded Studies:
Reference
No

Study ID

Brief summary

Reason for exclusion

Studies on Intracerebral haemorrhage (ICH)
1

Sobrino et al.
2011

CD341 progenitor cells in the
outcome
of
intracerebral
haemorrhage at 3 months
2
Li et al. 2013
Efficacy of mesenchymal stem cell
(MSCs)
in
patients
with
intracerebral
haemorrhage.
Outcomes assessed at 6 months
3
Zhu et al. Surgery Combined with autologous
2015
Bone
Marrow
Stromal
Cell
Transplantation in Intracerebral
Hemorrhage. Efficacy outcomes
assessed at 12 months
4
Tsang et al. Autologous
BM
derived
2017
mesenchymal stem cell in chronic
stroke (ICH), phase I/II RCT.
Outcome assessed at 60 weeks
5
Khalil et al. Intravenous mesenchymal stem
2023
cell in chronic ICH patients. RCT.
Outcome assessed at 2 years.
Studies with both intracerebral haemorrhage and Ischemic stroke

Not RCT

6

Separate
results
for
ischemic
and
haemorrhagic
patients
not available.

Kondoziolka
et al. 2005

Stereotactic
implantation
of
cultured neuronal cells in chronic
ischemic and haemorrhagic stroke.
Outcome assessed at 6 months
Phase 2 RCT.

Not RCT

Not RCT

Efficacy parameters of
two groups not published.

Outcomes of control arm
not published.

Studies in Ischemic stroke
7

8

9

Meng et al. Autologous marrow mesenchymal
2009
cell transplantation in ischemic
stroke. RCT
Battistella et Intra-arterial transplantation of
al. 2011
autologous BM mononuclear cells
in subacute stroke. Outcome
assessed at 6months
Prasad et al.
Intravenous
autologous
BM
mononuclear cell in ischemic
2012
stroke. Phase 1 study

Full test not available.
Article in Chinese
Not RCT

Not RCT

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 40

<!-- page 47 -->

10

Intra-Arterial
Bone
Marrow
Mononuclear Cells in Ischemic
Stroke. Efficacy outcome assessed
at 6 months
Bhasin et al.
Autologous
intravenous
2012
mononuclear stem cell in chronic
ischemic stroke. Outcome assessed
at 6 months
Jiang et al. Mesenchymal stem cell delivery via
2013
catheter in MCA territory stroke.
Outcome assessed at 6 months
Qiao et al. Co-transplantation With Neural
2014
Stem/Progenitor
Cells
and
Mesenchymal Stromal Cells in
Ischemic Stroke Patients, outcome
assessed at 2 years.
Liu et al. 2014 Autologous mesenchymal nerve
stem cells in subacute stroke. RCT.
Outcomes assessed at 3 months.
Banerjee et al. Intra-arterial Immunoselected CD
2014
34 + stem cells in acute ischemic
stroke.
Wang et al. Intravenous autologous marrow
2014
mesenchymal cells in stroke. RCT

Not RCT

17

Wanamaker
et al. 2015

Not RCT,
outcome

18

Taguchi et al.
2015

19

Nakazaki
al. 2015

20

Ghali
2016

11

12

13

14

15

16

21

Moniche et al.
2012

et

Surgical mesenchymal stem cell
implantation in patients with MCA
stroke. Outcomes asses at 1 year.
Intravenous BM Mononuclear stem
cell transplantation in acute stroke.
Phase 1.2b trial
Mesenchymal stem cell in cerebral
ischemia. Phase 3 study

Not RCT

Not RCT

Not RCT

Outcomes assessed at less
than 6 months (3
months)
Not RCT

Full text not available.
Article in Chinese.
Radiological

Not RCT

Full test not available.
Article in Japanese.

et

al. Intra-arterial
infusion
of Not RCT
autologous BM Mononuclear stem
cells in subacute stroke. Outcomes
assessed at 12 months.
Bhasin et al.
Intravenous
BM
derived Outcome assessed at less
2016
mononuclear stem cells in chronic than 6 months. (8 weeks)
ischemic stroke. Single blind RCT.
Outcome assessed at 8 weeks.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 41

<!-- page 48 -->

22

23

24

25

26
27

28

29

30

31

32

Kalladka et al.
2016

Human neural stem cell line
product CTX-DP, in chronic
ischemic stroke. Phase 1 study.
Honmou et al. Intravenous
autologous
mesenchymal cells in subacute
2016
stroke patients.
Bhasin et al.
Autologous mesenchymal stem cell
in chronic stroke. Outcome at 4
2017
years.
Steinberg et Modified BM derived mesenchymal
stem cells (SB 623) in chronic
al. 2018
stroke. Phase 1/2a study.
Laskowitz et Allogenic umbilical cord blood in
al. 2018
ischemic stroke, Phase 1 study

Not RCT

Levy et
2019

Not RCT

al. Intravenous
allogenic
mesenchymal stem cell in chronic
stroke, Phase I/II study.
Zhang et al. Intracerebral transplantation of
neural stem cell in chronic stroke.
2019
Outcome assessed at 12 months.
Vahidy et al.
Intravenous BM mononuclear cell
in acute ischemic stroke. Phase 1
2019
trial
Muir et al. Intracerebral
implantation
of
2020
human neural stem cells in chronic
stroke. Outcomes assessed at 12
months.
Chung et al. Intravenous Mesenchymal stem
2021
cells in chronic stroke. Open
labelled RCT. Outcomes assessed at
3 months
Lee et al. Intravenous mesenchymal stem
2021
cells in subacute ischemic stroke.
Open labelled RCT. Outcome
assessed at 3 months.

Full test not available.
Article in Japanese
Not RCT

Not RCT

Not RCT

Not RCT

Not RCT

Not RCT

Outcomes assessed at less
than
6
months
(3
months)
Outcomes assessed at less
than
6
months
(3
months)

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 42

<!-- page 49 -->

REFERENCES:
1. Bang OY, Lee JS, Lee PH, Lee G. Autologous mesenchymal stem cell transplantation in stroke
patients. Ann Neurol. 2005 Jun; 57(6):874-82. doi: 10.1002/ana.20501. PMID: 15929052.
2. Bhatia V, Gupta V, Khurana D, et al. Randomized Assessment of the Safety and Efficacy of IntraArterial Infusion of Autologous Stem Cells in Subacute Ischemic Stroke. Am J Neuroradiol. 2018
May; 39(5):899-904. doi: 10.3174/ajnr.A5586.
3. de Celis-Ruiz E, Fuentes B, Alonso de Leciñana M, et al. Final Results of Allogeneic Adipose
Tissue-Derived Mesenchymal Stem Cells in Acute Ischemic Stroke (AMASCIS): A Phase II,
Randomized, Double-Blind, Placebo-Controlled, Single-Center, Pilot Clinical Trial. Cell
Transplant. 2022 Jan-Dec; 31:9636897221083863. doi: 10.1177/09636897221083863.
4. Chen DC, Lin SZ, Fan JR et al. Intracerebral implantation of autologous peripheral blood stem
cells in stroke patients: a randomized phase II study. Cell Transplant. 2014;23(12):1599-612.
doi: 10.3727/096368914X678562.
5. Fang J, Guo Y, Tan S et al Autologous Endothelial Progenitor Cells Transplantation for Acute
Ischemic Stroke: A 4-Year Follow-Up Study. Stem Cells Transl Med. 2019 Jan; 8(1):14-21. doi:
10.1002/sctm.18-0012. Epub 2018 Aug 29. PMID: 30156755; PMCID: PMC6312444.
6. Hess DC, Wechsler LR, Clark WM et al. Safety and efficacy of multipotent adult progenitor cells in
acute ischaemic stroke (MASTERS): a randomised, double-blind, placebo-controlled, phase 2
trial. Lancet Neurol. 2017 May; 16(5):360-368. doi: 10.1016/S1474-4422(17)30046-7.
7. Houkin K, Osanai T, Uchiyama S, Minematsu K, Taguchi A, Maruichi K, Niiya Y, Asaoka K, Kuga Y,
Takizawa K, Haraguchi K, Yoshimura S, Kimura K, Tokunaga K, Aoyama A, Ikawa F, Inenaga C,
Abe T, Tominaga A, Takahashi S, Kudo K, Fujimura M, Sugiyama T, Ito M, Kawabori M, Hess DC,
Savitz SI, Hirano T; TREASURE Study Investigators. Allogeneic Stem Cell Therapy for Acute
Ischemic Stroke: The Phase 2/3 TREASURE Randomized Clinical Trial. JAMA Neurol. 2024 Feb 1;
81(2):154-162. doi: 10.1001/jamaneurol.2023.5200. PMID: 38227308; PMCID: PMC10792497.
8. Jaillard 2020: Jaillard A, Hommel M, Moisan A, et al (for the ISIS-HERMES Study Group).
Autologous Mesenchymal Stem Cells Improve Motor Recovery in Subacute Ischemic Stroke: a
Randomized Clinical Trial. Transl Stroke Res. 2020 Oct; 11(5):910-923. doi: 10.1007/s12975020-00787-z.
9. Jin Y, Ying L, Yu G, Nan G. Analysis of the long-term eJect of bone marrow mononuclear cell
transplantation for the treatment of cerebral infarction. International Journal of Clinical and
Experimental Medicine 2017; 10(2):3059-68.
10. Law ZK, Tan HJ, Chin SP et al The effects of intravenous infusion of autologous mesenchymal
stromal cells in patients with subacute middle cerebral artery infarct: a phase 2 randomized
controlled trial on safety, tolerability and efficacy. Cytotherapy. 2021 Sep; 23(9):833-840. doi:
10.1016/j.jcyt.2021.03.005.
11. Lee JS, Hong JM, Moon GJ et al. STARTING collaborators. A long-term follow-up study of
intravenous autologous mesenchymal stem cell transplantation in patients with ischemic stroke.
Stem Cells. 2010 Jun; 28(6):1099-106. doi: 10.1002/stem.430.
12. Moniche 2023: Moniche F, Cabezas-Rodriguez JA, Valverde R et al Safety and efficacy of intraarterial bone marrow mononuclear cell transplantation in patients with acute ischaemic stroke

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 43

<!-- page 50 -->

in Spain (IBIS trial): a phase 2, randomised, open-label, standard-of-care controlled, multicentre
trial. Lancet Neurol. 2023 Feb; 22(2):137-146. doi: 10.1016/S1474-4422(22)00526-9.
13. Niizuma K, Osawa SI, Endo H et al. Randomized placebo-controlled trial of CL2020, an allogenic
muse cell-based product, in subacute ischemic stroke. J Cereb Blood Flow Metab. 2023 Dec;
43(12):2029-2039. doi: 10.1177/0271678X231202594.
14. Prasad K, Sharma A, Garg A et al InveST Study Group. Intravenous autologous bone marrow
mononuclear stem cell therapy for ischemic stroke: a multicentric, randomized trial. Stroke.
2014 Dec; 45(12):3618-24. doi: 10.1161/STROKEAHA.114.007028.
15. Savitz 2019: Savitz SI, Yavagal D, RappardG, et al A Phase 2 Randomized, Sham-Controlled Trial
of Internal Carotid Artery Infusion of Autologous Bone Marrow-Derived ALD-401 Cells in
Patients with Recent Stable Ischemic Stroke (RECOVER-Stroke). Circulation. 2019 Jan 8;
139(2):192-205. doi: 10.1161/CIRCULATIONAHA.117.030659.
16. Dalal, P.M., Bhattacharjee, M. Burden of Stroke: Indian Perspective. In: Preedy, V.R., Watson, R.R.
(eds) Handbook of Disease Burdens and Quality of Life Measures. Springer, New York, NY. 2010;
https://doi.org/10.1007/978-0-387-78665-0_56.
17. GBD 2019 Stroke Collaborators. Global, regional, and national burden of stroke and its risk
factors, 1990-2019: a systematic analysis for the Global Burden of Disease Study 2019. Lancet
Neurol. 2021 Oct; 20(10):795-820. doi: 10.1016/S1474-4422(21)00252-0. Epub 2021 Sep 3.
PMID: 34487721; PMCID: PMC8443449.
18. Boncoraglio, GB, Ranieri, M, Bersano, A, Parati, EA and Del Giovane, C. Stem cell transplantation
for ischemic stroke. Cochrane Database of Systematic Reviews, 2019; (5).
19. Glimmerveen A, Holewijn S, Vermeer S. Association between clinician reported outcome and
patient reported outcome measures one year after stroke. J Stroke Cerebrovasc Dis. 2023 Aug;
32(8):107156. doi: 10.1016/j.jstrokecerebrovasdis.2023.107156. Epub 2023 May 11. PMID:
37178516.
20. https://www.medacess.com/treatments/stem-cell-therapy-forstroke.html#:~:text=Stem%20Cell%20Treatment%20for%20Stroke%20in%20India%20can%
20cost%20you,to%204.8%20lakh%20(%245%2C500).
21. https://www.dvcstem.com/post/stem-cell-therapy-cost-2020.
22. https://www.tataaig.com/knowledge-center/health-insurance/stem-cell-transplantation-costin-india.
23. Sharma SK, Choudhary D, Gupta N, Dhamija M, Khandelwal V, Kharya G, Handoo A, Setia R, Arora
A. Cost of hematopoietic stem cell transplantation in India. Mediterr J Hematol Infect Dis. 2014
Jul 1; 6(1):e2014046. doi: 10.4084/MJHID.2014.046. PMID: 25045454; PMCID: PMC4103507.
24. Nagpal A, Milte R, Kim, SW, Hillier, S, Hamilton-Bruce, MA, Ratcliffe, J and Koblar, SA. Economic
evaluation of stem cell therapies in neurological diseases: a systematic review. Value in Health,
2019; 22(2), pp.254-262.
25. Unsworth DJ, Mathias JL, Dorstyn DS, Koblar SA. Stroke survivor attitudes toward, and
motivations for, considering experimental stem cell treatments. DisabilRehabil. 2020 Apr;
42(8):1122-1130. doi: 10.1080/09638288.2018.1517193. Epub 2019 Feb 1. PMID: 30707643
https://digital.library.adelaide.edu.au/dspace/bitstream/2440/127002/1/Unsworth2020_PhD.
pdf

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 44

<!-- page 51 -->

2. SPINAL CORD INJURY

i.

Key question in PICO format

ii.

Search Strategy

iii.

PRISMA Flow Diagram

iv.

Summary of included studies

v.

Classification of studies based on level of stem cell manipulation

vi.

Evidence to Decision Framework

vii.

Data Extraction

viii.

List of excluded studies

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 45

<!-- page 52 -->

i.

Key Question in PICO format:

In patients with Spinal cord injury, what is the efficacy and safety of stem cell therapy as compared
to usual care?
Population: Patients with spinal cord injury- subgroups-acute/subacute/chronic
Intervention: Any Stem cell and product derived from stem cells
Comparator: Usual Care/ Conventional Care
Critical Outcomes: Efficacy: Any measure of Disability or Handicap, Quality of life, Bladder and
bowel function;
Safety outcomes: mortality, serious adverse events, Any Tumour formation;
Important: other adverse events

ii.

Search Strategy
PubMed
No.
Query
#6
((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem
cells':lnk OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow
stem cell' OR 'stem cell transplantation') AND 'chronic spinal cord injury' OR 'chronic
spinal cord injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py
AND [embase]/lim AND [humans]/lim AND [abstracts]/lim AND [clinical study]/lim AND
[01-01-1900]/sd NOT [18-11-2023]/sd
#5
((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem
cells':lnk OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow
stem cell' OR 'stem cell transplantation') AND 'acute spinal cord injury' OR 'acute spinal
cord injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py AND
[embase]/lim AND [humans]/lim AND [abstracts]/lim AND [clinical study]/lim AND [0101-1900]/sd NOT [18-11-2023]/sd
#4
((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem
cells':lnk OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow
stem cell' OR 'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord
injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py AND
[embase]/lim AND [humans]/lim AND [abstracts]/lim AND [clinical study]/lim AND [0101-1900]/sd NOT [18-11-2023]/sd
#3
((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem
cells':lnk OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow
stem cell' OR 'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord
injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py AND
[embase]/lim AND [humans]/lim AND [abstracts]/lim AND [clinical study]/lim
#2
((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem
cells':lnk OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow
Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 46

<!-- page 53 -->

#1

stem cell' OR 'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord
injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py AND
[embase]/lim
((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem
cells':lnk OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow
stem cell' OR 'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord
injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py

Embase
No Query
#6 ((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem cells':lnk
OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow stem cell' OR
'stem cell transplantation') AND 'chronic spinal cord injury' OR 'chronic spinal cord
injury'/exp) AND [randomized controlled trial]/lim AND [<1966-2023]/py AND
[embase]/lim AND [humans]/lim AND [abstracts]/lim AND [clinical study]/lim AND [01-011900]/sd NOT [18-11-2023]/sd
#5 ((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem cells':lnk
OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow stem cell' OR
'stem cell transplantation') AND 'acute spinal cord injury' OR 'acute spinal cord injury'/exp)
AND [randomized controlled trial]/lim AND [<1966-2023]/py AND [embase]/lim AND
[humans]/lim AND [abstracts]/lim AND [clinical study]/lim AND [01-01-1900]/sd NOT [1811-2023]/sd
#4 ((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem cells':lnk
OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow stem cell' OR
'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord injury'/exp) AND
[randomized controlled trial]/lim AND [<1966-2023]/py AND [embase]/lim AND
[humans]/lim AND [abstracts]/lim AND [clinical study]/lim AND [01-01-1900]/sd NOT [1811-2023]/sd
#3 ((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem cells':lnk
OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow stem cell' OR
'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord injury'/exp) AND
[randomized controlled trial]/lim AND [<1966-2023]/py AND [embase]/lim AND
[humans]/lim AND [abstracts]/lim AND [clinical study]/lim
#2 ((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem cells':lnk
OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow stem cell' OR
'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord injury'/exp) AND
[randomized controlled trial]/lim AND [<1966-2023]/py AND [embase]/lim
#1 ((stem AND cell AND therapy OR 'stem cell therapy'/exp/mj OR 'mesenchymal stem cells':lnk
OR 'bone marrow stem cells':lnk OR 'mesenchymal stem cell' OR 'bone marrow stem cell' OR
'stem cell transplantation') AND 'spinal cord injury' OR 'spinal cord injury'/exp) AND
[randomized controlled trial]/lim AND [<1966-2023]/py

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 47

<!-- page 54 -->

Web of Science
#
Search Query
1
(((((TS=(Stem cell therapy)) OR TS=(Mesenchymal stem cell)) OR TS=(Bone marrow stem
cell)) AND TS=(Spinal Cord Injury)) OR TS=(Acute spinal cord injury)) OR TS=(Chronic spinal
cord injury) and Preprint Citation Index (Exclude – Database) Timespan: 1900-01-01 to 202311-17
2
((((((TS=(Stem cell therapy)) OR TS=(Mesenchymal stem cell)) OR TS=(Bone marrow stem
cell)) AND TS=(Spinal Cord Injury)) OR TS=(Acute spinal cord injury)) OR TS=(Chronic spinal
cord injury)) Timespan: 1900-01-01 to 2023-11-17
3
(((((((TS=(Stem cell therapy)) OR TS=(Mesenchymal stem cell)) OR TS=(Bone marrow stem
cell)) AND TS=(Spinal Cord Injury)) OR TS=(Acute spinal cord injury)) OR TS=(Chronic spinal
cord injury))) AND TS=(randomized controlled trial) and Preprint Citation Index (Exclude –
Database) Timespan: 1900-01-01 to 2023-11-17
4
(((((((TS=(Stem cell therapy)) OR TS=(Mesenchymal stem cell)) OR TS=(Bone marrow stem
cell)) AND TS=(Spinal Cord Injury)) OR TS=(Acute spinal cord injury)) OR TS=(Chronic spinal
cord injury))) AND TS=(randomized controlled trial) and Preprint Citation Index (Exclude –
Database) and Clinical Trial (Document Types) Timespan: 1900-01-01 to 2023-11-17
Cochrane
ID Search
#1 (Stem Cell Therapy) OR (Mesenchymal Stem Cell) OR (Bone Marrow Stem Cell) AND (Spinal
Cord Injury) with Publication Year from 1900 to 2023, in Trials
#2 MeSH descriptor: [Stem Cell Transplantation] explode all trees
#3 MeSH descriptor: [Mesenchymal Stem Cell Transplantation] explode all trees
#4 MeSH descriptor: [Spinal Cord Injuries] explode all trees
#5 ((Stem cell therapy) AND (Spinal cord injury)):ti,ab,kw (Word variations have been searched)
with Publication Year from 1900 to 2023, in Trials
#6 ((Stem cell therapy)) OR ("mesenchymal stem cell") OR ("bone marrow stem cell") AND
("spinal cord injury") OR (Acute Spinal Cord Injury):ti,ab,kw with Publication Year from 1900
to 2023, in Trials
#7 ((Stem cell therapy)) OR ("mesenchymal stem cell") OR ("bone marrow stem cell") AND
("spinal cord injury") OR (Chronic Spinal Cord Injury) (Word variations have been searched)
with Publication Year from 1900 to 2023, in Trials

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 48

<!-- page 55 -->

Identification

PRISMA Flow Diagram

Records identified through database
searching (PubMed, Medline, Google
scholar, Embase) upto 17 November 2023

Additional records identified through
other sources viz references of metaanalyses

(N=162)

(N=2)

Eligibility

Screening

Records obtained after Screening
(N=164)

Included

iii.

Records excluded (N=150)
•
Duplicates = 34
•
Not an RCT = 43
•
Non usage of stem cells = 48
•
Animal studies = 9
•
Case Report, Case Series,
Review article, Protocol = 5
•
Non-availability of full text = 10
•
Different disease = 1

Full-text articles assessed for
eligibility
(N=14)

Full-text articles excluded
•
Data Duplications = 1
•
Uncertainty about RCT = 1

Studies included in
qualitative synthesis
(N =12)

Full-text articles excluded
•
No quantitative data = 1

Studies included in
quantitative synthesis (metaanalysis)
(N=11)

Out of a total of 11 RCTs, 5 trials met the inclusion criteria as specified by the GDG and were used
for synthesizing evidence.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 49

<!-- page 56 -->

iv.

Summary of included studies
Abdelaziz
et al.1

Albu
al.2

et

Cheng et
al.3

Dai et al.4

Population
Patients having chronic
traumatic dorsal spinal
cord
injury
with
durations of at least 6
months were included in
the study

Participants were 10
patients (7 males, 3
females, age range, 25-47
years)
with
chronic
complete SCI (American
Spinal Injury Association
A) at dorsal level (T3-11)

Intervention
20 - They received autologous
adult bone marrow stem cells
transplantation through open
surgical intraparenchymal and
intralesional injection into the site
of cord injury. The treatment was
continued
with
monthly
intrathecal injection of stem cells
through lumbar or cisternal
punctures
Patients were randomly assigned
to receive a single dose of
intrathecal ex vivo-expanded WJMSCs (10 X 106 cells) from human
umbilical cord or placebo and
were then switched to the other
arm at 6 months.

Comparison
Outcomes
AIS
Grade
10 - Patients with
Improvement
complete or
incomplete spinal injury
who will not have stem
cell transplantation

Patients were randomly
assigned to receive a
single
dose
of
intrathecal ex vivoexpanded WJ-MSCs (10X
106cells) from human
umbilical
cord
or
placebo and were then
switched to the other
arm at 6 months.
Patients of thoracolumbar 10 - The stem cell transplantation 10 - Patients were left at
spinal cord injury that group was given CT-guided UCMSC home for self healing
were graded ‘A’ by the transplantation twice
with
no
specific
AIS grading system
treatment.

Comments
No
proper
mention of stem
cell
characterization

AIS Motor, AIS
Sensory, SCIM

AIS Motor, AIS
Sensory,
Barthel Index

No
proper
mention of stem
cell
characterization

Patients with complete Bone marrow mesenchymal stem control group was not AIS Motor, AIS
and chronic cervical SCI. cells (BMMSC)transplantation to treated
with
cell Sensory
The treatment group the area surrounding injury
transplantation
consisted of 20 patients,
14 males and six females
with average age of
34.77±8.9 years (range:
22–54 years) and the

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 50

<!-- page 57 -->

El-Kheir
et al.5

Ghobrial
et al.6

Levi et al.7

Saini
al.8

et

average time interval
between the injury and
stem cell therapy was
51.97±18.3
months
(range: 18–74 months).
Patients with traumatic
chronic SCI of 10–36
months in duration with
completion of at least 6
months of physiotherapy
postinjury
with
no
spontaneous recovery or
neurological
improvement.
Baseline
assessment of American
Spinal Injury Association
(ASIA) Impairment Scale
(AIS) A and B.
Subjects with traumatic,
nonpenetrating SCI were
enrolled
and
given
intramedullary injections
of HuCNS-SC R (Stem
cells, Inc) rostral and
caudal to the C5-C7 injury
level with AIS grade A or
B.
Participants enrolled had
a sequential investigation
involving transplantation
of allogeneic HuCNS-SC
cells into three cohorts
with chronic SCI. With C57 and AIS A, B or C.
Patients aged 18–50
years presenting with the

15 AIS A and 35 AIS B chronic SCI
patients for physiotherapy and
Autologous Bone Marrow-Derived
Cell Therapy

9 AIS A and 11 AIS B AIS
Grade
Chronic SCI patients improvement,
only
treated
with AIS Motor
physiotherapy

It consisted of two cohorts. Cohort Not mentioned
1 consisted of an open label, doseescalation protocol (15, 30, and 40
million cells), while cohort 2 was
randomized, controlled, single
blinded, with a treatment dose of
40 million cells.

GRASSP
Scoring

6 - It consisted of participants with 4 - Randomized, single
C5-7 motor complete (AIS A or B) blinded, did not receive
SCI, randomized, single blinded transplant.
and received the transplant of
HuCNS-SC.

Baseline Upper
Extremity
Motor
Score,
GRASSP
Scoring

Bone marrow derived stem cells
(BMSCs) (intramedullary route)

SCIM,
motor,

Placebo (intramedullary
route) intraoperatively

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

There are two
intervention
groups in study
El-Kheir et al. on
the basis of AIS
Grade (A and B).
Therefore,
the
data has been
incorporated
separately.

Insufficient data
not included in
any analysis

AIS More than 30%
AIS of patients in
Page 51

<!-- page 58 -->

Song
al.9

et

complete motor (ASIA
grade A) spinal cord
injury
(quadriplegia/paraplegia)
requiring
surgical
intervention 21 days of
injury were included in
the study.
Enrolled=Thirty-six
patients with acute spinal
cord injury

intraoperatively

Eighteen
control
group’s
treatment + autologous bone
marrow mesenchymal stem cells
injection in the subarachnoid
space
ASCI participants managed by
posterior
instrumentation
(titanium pedicle screw and rod
devices) followed by infusion of
autologous BM-derived stem cells
as an adjuvant

Srivastava Participants
of
ASCI
et al.10
having complete lesion
(ASIA Impairment Scale
[AIS]-A
grade)
with
thoracolumbar
injury
severity
score
(≥4)
(unstable injury requiring
stabilization by surgery).
Thoracolumbar
spine
injury level between T4
and L2 vertebra with age
between 18 and 65 years
of
either
gender.
Duration of injury<6
weeks.
Yang et Sixty SCI patients were Autologous BMSCs transplantation
al.11
included in the study with therapy
chronic SCI

sensory

each arm died.
Their data was
incorporated in
the
analysis
assuming
the
worst outcome.

Eighteen treated with
decompression+
internalfixation+
conventional
medical
treatments
ASCI
participants
managed
nonoperatively.

ASIA Sensory
Score,
ASIA
Exercise Score,
Botsford Score,
SCIM Total
AIS
Grade
Improvement,
AIS Motor, AIS
sensory

No
proper
mention of stem
cell
characterization

Standard rehabilitation
therapy

AIS
Grade
improvement

No
proper
mention of stem
cell
characterization

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 52

<!-- page 59 -->

v. Classification of studies on the basis of level of manipulation of the stem cell/ Stem cell derived product used (interpreted by the
Secretariat as defined by CDSCO* and the information provided in the trial itself):
S. No.

Trial Details

Intervention

Level of
manipulation
Wharton Jelly mesenchymal stromal More
cells (WJ-MSCs)- single dose of
intrathecal ex vivo-expanded WJMSCs from human umbilical cord

1.

Albu et al.
2021

2.

Dai et al. 2013

Bone marrow mesenchymal stem More
cells (BMMSC)- transplantation to
the area surrounding injury;
intrathecally

3.

El-Kheir et al.
2014

4.

Levi et al.
2019

Autologous Bone Marrow-Derived Less
Stem
Cell
(ABMC)
TherapyIntrathecal transplantation through
lumbar puncture
Allogenic Human neural stem cell More
transplantation (HuCNS-SC)

5.

Saini R et al.
2022

Mononuclear Bone marrow derived Less
stem cells (BMSCs)- intramedullary
route, intraoperatively

Information extracted from trial
“WJ-MSCs were derived following current Good
Manufacturing Practice-compliant procedures using donated
umbilical cord with appropriate donor informed consent
approved by the local ethics committee and the competent
tissue and organ donation authority.”
“A volume of 90 ml bone marrow was collected from
unilateral or bilateral posterior iliac spine. The BMMSC was
separated, allowed for adhesion and proliferation in GMP
laboratory. After passaging every 5–7 days, the fourth
generation cells were collected for transplantation.”
“autologous BMCs are allowed to adhere for 72 h to form
“minimally manipulated” adherent BMCs (ABMCs)”

“HuCNS-SC cells were prepared and released by Stem Cells Inc.
according to product manufacturing specifications and
regulatory standards established with the FDA.”
“Mononuclear BMSCs were separated under good laboratory
practice conditions by SmartPReP2 Bone Marrow Aspirate
Concentrate (BMACTM) System (Harvest Technologies GmbH,
Munich, Germany) in the sterile zone at Operation theater.”

* as defined by CDSCO in Annexure- I of the guideline document

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 53

<!-- page 60 -->

vi.

Evidence to Decision Framework:

QUESTION
In patients with spinal cord injury, what is the efficacy and safety of stem cell therapy compared to usual care?
POPULATION:
INTERVENTION:
COMPARISON:
MAIN OUTCOMES:
SETTING:
PERSPECTIVE:
BACKGROUND:

CONFLICT OF
INTERESTS:

Spinal Cord Injury
Stem cell transplantation
Usual care
Independence and Disability Scales - Spinal Cord Independence Measure Scale, ASIA Motor Score, AIS Grade
Improvement
Hospital
Health Systems/Population
Spinal cord injury (SCI) is a chronic condition leading to physical and psychological problems along with
numerous economic burdens for patients. SCI interrupts the neural connections between the upper center and
the spinal cord, leading to devastating and permanent neurological impairment, including sensory and motor
disability, abnormal reflexes, and autonomic disorders. SCI not only seriously affects the quality of life and life
span of patients, but it also leads to psychological and emotional disorders and social phobia, with enormous
impact and heavy economic burden on the family as well as the social health care system. Therefore, effective
treatments are urgently needed to cure individuals with SCI.12,13
None

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 54

<!-- page 61 -->

ASSESSMENT
Problem
Is the problem a priority?
JUDGEMENT
○ No
○ Probably no
○ Probably yes
● Yes
○ Varies
○ Don't know

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

Incidence of SCI in India is estimated to be around 20 per million with 2500 fresh
cases added every year. In addition to physical, social and psychological suffering
for these patients, taking care of these patients creates a significant burden for the
healthcare system. The current clinical treatment for SCI mainly includes early
surgical decompression and stabilization, augmentation of spinal cord perfusion,
intravenous administration of high-dose corticosteroids, anti-inflammatory therapy
in the acute phase, and neurological rehabilitation training during the chronic
phase. Unfortunately, the clinical benefit achieved using current approaches is
limited and there are no effective strategies currently existing to repair SCI, thus
patients suffer long-term dysfunction and lifelong disability.12,13

Desirable Effects
How substantial are the desirable anticipated effects?
JUDGEMENT
○ Trivial
○ Small
○ Moderate
○ Large
○ Varies
● Don't know

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS
There is insufficient evidence to draw firm conclusions regarding the desirable
The GDG considered
effects of stem cell therapy in patients with spinal cord injury.
an MCID of 10 for the
SCIM scale.
Dependency: Evidence from one RCT with 21 participants of acute complete spinal A change in Wexner
cord injury reported a mean difference of 9.76 (95% CI: -2.14 to 21.66) in the SCIM score by 2 points was
Score in the stem cell therapy arm (intramedullary route) as compared to usual care considered as MCID.
at the end of six months. The difference was statistically non-significant.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 55

<!-- page 62 -->

Bowel Function: Evidence from one RCT with 10 participants of chronic complete
spinal cord injury reported a reduction in the Wexner Score with a mean difference
of -1.87 (95% CI: -3.50 to - 0.24) in the stem cell therapy arm (intrathecal route) as
compared to usual care at the end of six months. The difference was statistically
significant but unimportant clinically as it was less than the MCID of 2.
Bladder Function: Evidence from one RCT with 10 participants of chronic
complete spinal cord injury reporting the Qualiven questionnaire (subscalespecific impact of urinary symptoms on quality of life) observed a mean difference
of 0.30 (95% CI: -0.45 to 1.05) in the stem cell arm (intrathecal route) as compared
to usual care at the end of six months. The difference was statistically non-significant.
Quality of Life: Evidence from one RCT with 10 participants of chronic complete
spinal cord injury reporting WHOQOL-BREF observed a mean difference of 0.70
(95% CI: -22.06 to 23.46) in the stem cell therapy arm (intrathecal route) as
compared to usual care at the end of six months. The difference was statistically nonsignificant.
Undesirable Effects
How substantial are the undesirable anticipated effects?
JUDGEMENT
RESEARCH EVIDENCE
○ Trivial
○ Small
○ Moderate
○ Large
● Varies
○ Don't know

ADDITIONAL
CONSIDERATIONS

Serious Adverse Events: Albu et al2, Dai et al4 and El Kheir et al5 did not report any
SAEs in either of the arms. The SAEs reported by Levi et al7 included sepsis,
posterior reversible encephalopathy syndrome, seizure, wound hematoma and
autonomic dysreflexia in the stem cell arm and urinary tract infection in the usual
care arm.
All-cause mortality: Saini et al8 reported all-cause mortality, 5 patients in the
usual care arm and 3 patients in the stem cell arm expired during the follow up
period due to ventilation associated pneumonia. This difference was statistically
not significant (p = 0.31).

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 56

<!-- page 63 -->

Certainty of evidence
What is the overall certainty of the evidence of effects?
JUDGEMENT
● Very low
○ Low
○ Moderate
○ High
○ No included studies
Values

RESEARCH EVIDENCE

The evidence in this review is of very low quality due to high risk of bias,
inconsistency and imprecision in the effect shown by stem cell therapy.

Is there important uncertainty about or variability in how much people value the main outcomes?
JUDGEMENT
RESEARCH EVIDENCE
○ Important uncertainty
or variability
○ Possibly important
uncertainty or
variability
● Probably no
important uncertainty
or variability
○ No important
uncertainty or
variability
Balance of effects

ADDITIONAL
CONSIDERATIONS

ADDITIONAL
CONSIDERATIONS

Main outcome is clinical improvement in the form of increased independence and
increase in motor activity which is likely to be highly valued by most persons.13,14

Does the balance between desirable and undesirable effects favor the intervention or the comparison?
JUDGEMENT
RESEARCH EVIDENCE

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

ADDITIONAL
CONSIDERATIONS
Page 57

<!-- page 64 -->

○ Favors the comparison
○ Probably favors the
comparison
● Does not favor either
the intervention or the
comparison
○ Probably favors the
intervention
○ Favors the
intervention
○Varies
○ Don't know
Resources required

It is less clear if benefits of stem cell intervention outweigh the harms due to small
to trivial benefit, based on limited evidence.

How large are the resource requirements (costs)?
JUDGEMENT
● Large costs
○ Moderate costs
○ Negligible costs and
savings
○ Moderate savings
○ Large savings
○ Varies
○ Don't know

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

No direct evidence of the resources required in stem cell transplantation in patients
with stroke was identified.
The information provided by the websites of Insurance Agencies and third party
agencies is as follows15:
●
●

5.0-5.5 lacs (TATA AIG)
5000-50,000 USD

However, indirect evidence shows that the median cost of hematopoietic stem cell
transplantation for hematological diseases were USD, $ 12,500 (range $ 10,331–
39,367) - Rs. 10,00,000.17
Certainty of evidence of required resources
What is the certainty of the evidence of resource requirements (costs)?
Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 58

<!-- page 65 -->

JUDGEMENT
○ Very low
○ Low
● Moderate
○ High
○ No included studies

RESEARCH EVIDENCE
No research evidence was identified.

ADDITIONAL
CONSIDERATIONS
The GDG members
were fairly certain
that stem cell therapy
requires
large
resources.

Cost effectiveness
Does the cost-effectiveness of the intervention favor the intervention or the comparison?
JUDGEMENT
RESEARCH EVIDENCE
○ Favors the comparison
● Probably favors the
comparison
○ Does not favor either
the intervention or the
comparison
○ Probably favors the
intervention
○ Favors the
intervention
○ Varies
○ No included studies

No research evidence for stem cell therapy was identified.

ADDITIONAL
CONSIDERATIONS
The intervention was
not found to be
effective and hence
the
committee
deferred to comment
on cost effectiveness.

Equity
What would be the impact on health equity?
JUDGEMENT

RESEARCH EVIDENCE

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

ADDITIONAL
CONSIDERATIONS

Page 59

<!-- page 66 -->

○ Reduced
● Probably reduced
○ Probably no impact
○ Probably increased
○ Increased
○ Varies
○ Don't know

No research evidence was identified.

As stem cell therapy
is an expensive
treatment offered
only at tertiary care
centers, it is likely to
increase inequity as it
would not be
affordable by all.

Acceptability
Is the intervention acceptable to key stakeholders?
JUDGEMENT
○ No
○ Probably no
● Probably yes
○ Yes
○ Varies
○ Don't know
Feasibility

RESEARCH EVIDENCE

ADDITIONAL
CONSIDERATIONS

Despite uncertainty regarding the medical risks and benefits associated with stem
cell injections, patients with spinal cord injury have very high expectations from
stem, cell therapy.17

Is the intervention feasible to implement?
JUDGEMENT

RESEARCH EVIDENCE

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

ADDITIONAL
CONSIDERATIONS

Page 60

<!-- page 67 -->

○ No
○ Probably no
● Probably yes
○ Yes
○ Varies
○ Don't know

No research evidence was identified.

Stem Cell
transplantation can
be performed only in
tertiary care centers
so feasibility in lesser
equipped hospitals
and clinics is not
possible

SUMMARY OF JUDGEMENTS
JUDGEMENT
PROBLEM

No

Probably no

Probably yes

Yes

Varies

Don't know

DESIRABLE
EFFECTS

Trivial

Small

Moderate

Large

Varies

Don't know

UNDESIRABLE
EFFECTS

Trivial

Small

Moderate

Large

Varies

Don't know

CERTAINTY OF
EVIDENCE

Very low

Low

Moderate

High

VALUES

BALANCE OF
EFFECTS

Important
Possibly
Probably no
uncertainty important
important
or
uncertainty uncertainty or
variability or variability
variability

No important
uncertainty or
variability

Does not favor
either the
intervention or
the
comparison

Probably
favors the
intervention

Favors the
comparison

Probably
favors the
comparison

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

No included
studies

Favors the
intervention

Varies

Don't know

Page 61

<!-- page 68 -->

RESOURCES
REQUIRED

Large costs

Moderate
costs

Negligible costs
and savings

Moderate
savings

CERTAINTY OF
EVIDENCE OF
REQUIRED
RESOURCES

Very low

Low

Moderate

High

COST
EFFECTIVENESS

Probably
Favors the
favors the
comparison
comparison

Does not favor
either the
intervention or
the comparison

Probably
favors the
intervention

Favors the
intervention

Varies

No included
studies

Increased

Varies

Don't know

Large savings

Varies

Don't know

No included
studies

EQUITY

Reduced

Probably
reduced

Probably no
impact

Probably
increased

ACCEPTABILITY

No

Probably no

Probably yes

Yes

Varies

Don't know

FEASIBILITY

No

Probably no

Probably yes

Yes

Varies

Don't know

TYPE OF RECOMMENDATION
Strong recommendation
against the intervention

Conditional
recommendation
against the
intervention

○

○

Use only in the context
Conditional
Conditional
of rigorously
recommendation for recommendation
conducted RCTs
either the
for the
intervention or the
intervention
comparison
●
○
○

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Strong
recommendation
for the
intervention
○

Page 62

<!-- page 69 -->

CONCLUSIONS
Recommendation
Stem Cell Therapy is not recommended in routine clinical practice for the treatment of spinal cord injury. It may be used only in the
context of rigorously conducted RCTs.

Justification
Overall justification
This recommendation has been made as the evidence is inadequate in quantity and quality to determine the efficacy of stem cell
therapy in patients with spinal cord injury. The incidence of undesirable effects including mortality are variable. In addition, the
reported follow up period is too small to comment on the side effect profile and long-term safety is not known.
Detailed justification
Desirable Effects
This judgment was made as the evidence is inadequate in quantity and quality to determine the efficacy of stem cell therapy in
patients with spinal cord injury.
Undesirable Effects
This judgment was made as the incidence of undesirable effects including mortality are variable. Also, the follow up period of one
year is too small to comment on the side effect profile and long-term safety is not known.
Certainty of evidence
Very low certainty of Evidence
Resources required
The committee opined that stem cell treatment is associated with large costs.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 63

<!-- page 70 -->

vii. Data Extraction:
Two reviewers independently extracted the data from the electronic databases mentioned above. Data for the following variables were
extracted: author name, study year, country, study setting, study duration, phase of study, sample size at beginning, sample size at
analysis, treatment and control groups, sex, age, injury type, stem cell type, cell count, volume, dosage, follow-up duration, ASIA motor
score, sensory score, pin prick score, light touch score, AIS grade and Spinal Cord Independence Measure (SCIM) scale, adverse events and
safety outcomes. Disagreements were resolved through the consensus among all the authors. Analysis was carried out using Review
Manager version 5.4.1, (Cochrane Collaboration, Syracuse, NY, USA). Dichotomous values were assessed using Odds Ratios (ORs) with
95% confidence intervals while, continuous variables were measured using standard mean deviations of the represented cumulative data
(Mean + Standard Deviation). Cochrane’s I2 statistic was used for assessing the heterogeneity. Studies with I2 values exceeding 50% had
higher heterogeneity, while those with I2<50% had lower heterogeneity. For value of I2 <50% fixed effects model was used and for I2>50%
random effects model was used. Risk of Bias for the included studies was performed using Cochrane’s risk of bias tool in RevMan
software. The following parameters were used for assessing the risk of bias: random sequence generation, allocation concealment,
blinding of participants and personnel, blinding of outcome assessment, incomplete outcome data, selective reporting and other bias. The
quality of evidence was graded as high, some concerns and low risk of bias. Publication bias was assessed using Begg’s funnel plot.

Study-Efficacy and outcome of bone marrow derived
stem cells transplanted via intramedullary route in
acute complete spinal cord injury – A randomized
placebo-controlled trial
Study type:
Number of participants:
Countries and setting:
Duration of study Follow up (post intervention):
Method of assessment of disease condition:
Subgroup analysis within study:
Inclusion criteria:

Exclusion criteria:

Saini et al. 20228

RCT
13
India, Hospital
6 months
Patients of spinal cord injury (quadriplegia/paraplegia) with AIS grade A.
Patients aged 18–50 years presenting with the complete motor (ASIA grade
A) spinal cord injury (quadriplegia/paraplegia) requiring surgical
intervention 21 days of injury were included in the study.
Patients were excluded if there was anatomical transaction of the cord

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 64

<!-- page 71 -->

Recruitment/selection of patients:

Intervention: Type of stem cells with method of their
characterization, Route of administration, Dose
Outcomes reported with time points
Funding
RoB2 Assessment: Specify separately for each domain

Study-Transplantation of autologous bone marrow
mesenchymal stem cells in the treatment of complete
and chronic cervical spinal cord injury
Study type:
Number of participants:
Countries and setting:
Duration of study Follow up (post intervention):
Method of assessment of disease condition:
Subgroup analysis within study:
Inclusion criteria:

visualized by on MRI; history of myocardial infarction and coronary artery
disease; chronic infections: HIV, HbSAg; history of liver & renal insufficiency
or of any malignancy; pregnant or nursing women; inability to communicate
effectively with neurological examiner and active participation in another
experimental procedure/intervention
180 patients were eligible out of which 27 randomized, 11 patients were
lost to follow up. In total, there were 6 patients in the placebo group and 7
in stem cell group.
Bone Marrow Mesenchymal Stem Cells, flow cytometry, intramedullary,
1.8mL
SCIM (3 months and 6 months), AIS Motor (3 months and 6 months), AIS
Sensory (3 months and 6 months)
None.
Randomization Process– Low risk
Deviation from intended intervention– Low risk
Missing outcome data– High risk
Measurement of the outcome– Low risk
Selection of the reported result– High risk

Dai et al. 20134

RCT
40
China, Hospital
6 months
Through physical examination and cervical spinal cord magnetic resonance
imaging (MRI), the patients diagnosed with cervical SCI were selected.
• Complete cervical SCI with post-operative or post-traumatic period

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 65

<!-- page 72 -->

•
Exclusion criteria:

•
•
•
•
•
•
•

Recruitment/selection of patients:

Intervention: Type of stem cells with method of their
characterization, Route of administration, Dose
Outcomes reported with time points
Funding
RoB2 Assessment: Specify separately for each domain

more than one year and
The site of injury within the cervical spinal cord C3–C7 excluding C3 and
C7.
Incomplete spinal cord injury;
Neurological function with tendency to recover;
Adhesion, syringomyelia,dural vascular malformations or significant
compression in spinal cord, requiring surgical intervention;
Unexplained nerve dysfunction;
Intended surgical site with inflammation or skin ulceration;
With bleeding tendency or coagulation disorders;
Poor general condition or other organ dysfunction intolerant of surgery
and Disagreement with the research protocol.

Forty patients with complete and chronic cervical SCI were selected and
randomly assigned to one of the two experimental groups, treatment group
and control group.
Bone Marrow Mesenchymal Stem Cells, flow cytometry, intrathecally, 25L
AIS Motor (6 months), AIS Sensory (6 months)
Not mentioned
Randomization Process– High risk
Deviation from intended intervention– High risk
Missing outcome data– Low risk
Measurement of the outcome– Low risk
Selection of the reported result– High risk

Study: Autologous Bone Marrow-Derived Cell Therapy El-Kheir et al. 20145
Combined with Physical Therapy Induces Functional
Improvement in Chronic Spinal Cord Injury Patients
Study type:
Randomized Controlled Trial
Number of participants:
70
Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 66

<!-- page 73 -->

Countries and setting:
Duration of study Follow up (post intervention):
Method of assessment of disease condition:
Subgroup analysis within study:
Inclusion criteria:

Egypt, University Setting
18 months
Patients with traumatic chronic SCI of 10–36 months in duration were
taken into consideration
• Traumatic chronic SCI of 10–36 months in duration.
• Completion of at least 6 months of physiotherapy postinjury with no
spontaneous recovery or neurological improvement
• No concomitant systemic disease.
• Baseline assessment of American Spinal Injury Association (ASIA)
Impairment Scale (AIS) A and B.

Exclusion criteria:

•
•
•
•
•

Recruitment/selection of patients:

Intervention: Type of stem cells with method of their
characterization, Route of administration, Dose

Nontraumatic SCI, including patients with either transverse myelitis or
demyelination, or lumbar SCI.
Acute SCI or duration of injury less than 10 months or more than 36
months.
Evidence for clinical and/or electrophysiological improvement in spinal
cord functions over the previous 6 months. 4. Baseline assessment of
AIS C or D.
Major impairment of respiratory, cardiac, hepatic, or other systemic
functions.
Unfitness for physical therapy, such as patients with muscle fibrosis.

Patients were recruited from the outpatient clinics of Physical Medicine at
Al-Azhar, Cairo, and Alexandria University Hospitals. During the enrollment
period, 159 patients were evaluated, and 70 patients were enrolled.
Human Autologous Bone Marrow-Derived Stem Cell (ABMCs) were isolated
from Bone marrow aspirates from SCI patients.
ABMCs were analyzed by flow cytometry with cell surface markers: cluster
of differentiation 13-phycoerythrin-cyanine 7 (CD13-PC7), CD29-PC7,
CD34-phycoerythrin (PE), CD44-fluorescein isothiocyanate (FITC), CD45PC7, CD73-PE, CD90-PE, CD105-PE, CD166-PE, CD271-PE, and c-kit-PE.
Intrathecal transplantation through lumbar puncture.

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 67

<!-- page 74 -->

Outcomes reported with time points
Funding
RoB2 Assessment: Specify separately for each domain

Study: Effectiveness of bone marrow-derived
mononuclear stem cells for neurological recovery in
participants with spinal cord injury: A randomized
controlled trial
Study type:
Number of participants:
Countries and setting:
Duration of study Follow up (post intervention):
Method of assessment of disease condition:
Subgroup analysis within study:
Inclusion criteria:

Exclusion criteria:

2×106 cells/kg
AIS Grade Improvement (18 months), Total Motor Score (18 months)
New Jersey Health Foundation
Randomization Process– High risk
Deviation from intended intervention– Low risk
Missing outcome data– Low risk
Measurement of the outcome– Low risk
Selection of the reported result– High risk

Srivastava et al. 201910

Randomized Controlled Trial
138
India, King George’s Medical University
One year (12 months)
Participants of ASCI having complete lesion (ASIA Impairment Scale [AIS]-A
grade) with thoracolumbar injury severity score (≥4)
•Participants of ASCI having complete lesion (ASIA Impairment Scale [AIS]A grade) with thoracolumbar injury severity score (≥4) (unstable injury
requiring stabilization by surgery)
• Thoracolumbar spine injury level between T4 and L2 vertebra
• Age between 18 and 65 years of either gender
• Duration of injury
• Polytrauma patients with injury spine and associated thoraco-abdominal
injuries and/or head injury
• Medically unfit patients not suitable for surgery
• Patients with other comorbid conditions such as osteoporosis, pressure
sores (Grade III–IV), psychiatric illness and those on steroids or other

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 68

<!-- page 75 -->

Recruitment/selection of patients:

Intervention: Type of stem cells with method of their
characterization, Route of administration, Dose

Outcomes reported with time points
Funding
RoB2 Assessment: Specify separately for each domain

immune suppressants
• Patients who did not give their consent for participating in the study.
Group 1 had 70 participants who underwent conventional surgery along
with BM-MNSCs as an adjuvant.
In Group 2, there were 68 participants who were treated by conventional
surgery
Bone marrow-derived mono-nuclear stem cells (BM-MNSCs)
Flowcytometry (MNCs and CD34+ count)
Intrathecal
10 ml of precipitate was used for infusion
AIS Grade Improvement (12 months), Total Motor Score (12 months), Total
Sensory Score (12 months)
No external source of funding
Randomization Process – High risk
Deviation from intended intervention – Low risk
Missing outcome data – Low risk
Measurement of the outcome – High risk
Selection of the reported result – High risk

Study: Clinical effects of intrathecal administration of Albu et al. 20212
expanded Wharton jelly mesenchymal stromal cells in
patients with chronic complete spinal cord injury: a
randomized controlled study
Study type:
phase 1/2a clinical trial with a randomized, double-blind, crossover,
placebo-controlled design
Number of participants:
10
Countries and setting:
Spain, Hospital
Duration of study Follow up (post intervention):
6 months
Method of assessment of disease condition:
Patients with spinal cord injury of traumatic etiology, with complete SCI
(American Spinal Injury Association [ASIA] A), thoracic injury level (T1-12)
Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 69

<!-- page 76 -->

Subgroup analysis within study
Inclusion criteria:

Exclusion criteria:

and chronic evolution (1-5 years after injury)
• spinal cord injury of traumatic etiology
• adults (18-65 years old) with complete SCI (American Spinal Injury
Association [ASIA] A)
• thoracic injury level (T1-12)
• chronic evolution (1-5 years after injury)
•
•
•
•
•
•

Recruitment/selection of patients:

Intervention: Type of stem cells with method of their
characterization, Route of administration, Dose
Outcomes reported with time points

Funding
RoB2 Assessment: Specify separately for each domain

Patients who presented non-traumatic SCI
Cord lesion at the cervical or lumbosacral segments, extended (>3
segments) or multiple lesioned segments
Associated brain injury or peripheral nerve injuries
Currently enrolled in other clinical trials or had scheduled surgery
within the subsequent 24 months after entering the trial
Received intrathecal medication or immunosuppressive drugs 2 months
before the trial
Pregnant or breastfeeding

Patients were enrolled by health professionals from the Guttmann Institute.
After signing informed consent, participants were randomly assigned to WJMSC or placebo infusion using simple randomization and admitted to the
hospital.
Wharton Jelly mesenchymal stromal cells (WJ-MSCs)
Intrathecal
4±1 mL, resulting in approximately 2.5x106 live WJ-MSCs/mL
AIS Grade Improvement (6 months), ASIA Sensory Light Touch Score (6
months), ASIA Sensory Pin Prick Score (6 months), Total Motor Score (6
months), Total Sensory Score (6 months), SCIM Total
FundacioMarato TV3 (grant no. 616/ 2012), AES 2019 ISCIII (PI19/01680)
Randomization Process– Low risk
Deviation from intended intervention– Low risk
Missing outcome data– Low risk
Measurement of the outcome– Low risk

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 70

<!-- page 77 -->

Selection of the reported result– High risk

Study: Clinical Outcomes from a Multi-Center Study of
Human Neural Stem Cell Transplantation in Chronic
Cervical Spinal Cord Injury
Study type:
Number of participants:
Countries and setting:
Duration of study Follow up (post intervention):
Method of assessment of disease condition:

Subgroup analysis within study
Inclusion criteria:

Levi et al. 20197

Randomized controlled trial
10
USA, Hospital
3, 6 and 9 months
Participants should be 4–24 months post-injury with C5-C7 ISNCSCI motor
levels, with a single traumatic and non-penetrating SCI, based on magnetic
resonance imaging (MRI)
• Participants were 4–24 months post-injury
• C5-C7 ISNCSCI motor levels
• Male and female
• 18–60 years of age
• With a single traumatic and non-penetrating SCI
• Based on magnetic resonance imaging (MRI)
• AIS Grade A or B

Exclusion criteria:

•
•

Recruitment/selection of patients:

Patients were enrolled by health professionals from the Guttmann Institute.
After signing informed consent, participants were randomly assigned to WJMSC or placebo infusion using simple randomization and admitted to the
hospital.
Human neural stem cell transplantation (HuCNS-SC)
Intramedullary

Intervention: Type of stem cells with method of their
characterization, Route of administration, Dose

Patients not in generally good medical condition other than their injury
Patients to have no contraindications for systemic immunosuppression,
MRIs, or safe surgical exposure of the lesion area

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 71

<!-- page 78 -->

Outcomes reported with time points
Funding

RoB2 Assessment: Specify separately for each domain

40x106 cells
GRASSP strength (3 months), Upper Motor Extremity Score (3 months)
The work was supported by StemCells, Inc. and the respective Academic
Institutions. Bright Oceans Corporation (BOCO) provided funds for posttermination data collection.
Randomization Process –High risk
Deviation from intended intervention –Low risk
Missing outcome data –Low risk
Measurement of the outcome –Low risk
Selection of the reported result –High risk

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Page 72

<!-- page 79 -->

viii. List of Excluded studies:
1

Associations Between Insufficient Sleep Syndrome and
Health Outcomes for Care Partners

2

The development of lived experience-centered word Davies BM
clouds to support research uncertainty gathering in
degenerative cervical myelopathy: results from an
engagement process and protocol for their evaluation,
via a nested randomized controlled trial
Safety, tolerability, and activity of mesenchymal stem
Uccelli A
cells versus placebo in multiple sclerosis (MESEMS): a
phase 2, randomised, double-blind crossover trial
Randomized, Placebo-Controlled Analysis of the Knee Tucker JD
Synovial Environment Following Platelet-Rich Plasma
Treatment for Knee Osteoarthritis

2021

Spine Treatment Appraisal Report (STAR): Bone
Dettori JR
Marrow-Derived Stem Cells Improve Neurological
Recovery in Participants with Spinal Cord Injury
Denosumab Versus Zoledronic Acid in Bone Disease Huang S-Y
Treatment of Newly Diagnosed Multiple Myeloma: An
International, Double-Blind, Randomized Controlled
Phase 3 Study—Asian Subgroup Analysis
Two year follow up of acute complete spinal cord Rani R
injury patients receiving autologous bone marrowderived mononuclear stem cell therapy

2021

2020

Only
the
abstract
is
published

Intrathecal enzyme replacement for cognitive decline
in mucopolysaccharidosis type I, a randomized, openlabel, controlled pilot study
Human umbilical cord mesenchymal stem cells to treat
spinal cord injury in the early chronic phase: Study
protocol for a prospective, multicenter, randomized,
placebo-controlled, single-blinded clinical trial
Pain inhibition through transplantation of fetal
neuronal progenitors into the injured spinal cord in
rats
Clinical trial for spinal cord injury with neural lineage
stem cell

Chen AH

2020

Yang Y

2020

No use of stem
cells in spinal
cord injury
Only
study
protocol

Batista CM

2019

Animal study

Kim K-N

2019

Therapeutic application of autologous bone marrow Saini R
mononuclear stem cell in complete spinal cord injury
in human

2018

Not
a
randomised
controlled trial
Only abstract
available

3

4

5

6

7

8

9

10

11

12

Li C-Y

2022

2021

2021

2020

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

No use of stem
cells in spinal
cord injury
No use of stem
cells in spinal
cord injury

Stem cells used
in
Multiple
Sclerosis
No use of stem
cells in spinal
cord injury
Full text not
available, only
abstract
No use of stem
cells in spinal
cord injury

Page 73

<!-- page 80 -->

13

Global Spine Congress 2018, GSC 2018

14

Safety of Autologous Human Schwann Cell Anderson
Transplantation in Subacute Thoracic Spinal Cord KD
Injury

2017

15

Effects of single-agent bortezomib as post-transplant
Sezer O
consolidation therapy on multiple myeloma-related
bone disease: a randomized phase II study
Dendritic cell vaccination in combination with Kongsted P
docetaxel for patients with metastatic castrationresistant prostate cancer: A randomized phase II study
Autologous mesenchymal stromal cell transplantation Satti HS
for spinal cord injury: A phase I pilot study

2017

Daratumumab monotherapy in patients with
treatment-refractory multiple myeloma (SIRIUS): An
open-label, randomised, phase 2 trial
Core decompression and autologous bone marrow
concentrate for treatment of femoral head
osteonecrosis: A randomized prospective study
Developing clinical-grade cell therapy for spinal cord
regeneration

Lonial S

2016

Pepke W

2016

Sabaawy H

2016

Impact of chemokines on the properties of spinal cordderived neural progenitor cells in a rat spinal cord
lesion model
Phase I, multicentre, dose-escalation trial of
monotherapy with milatuzumab (humanized antiCD74 monoclonal antibody) in relapsed or refractory
multiple myeloma
Tracking induced pluripotent stem cells-derived
neural stem cells in the central nervous system of rats
and monkeys
Safety profile, feasibility, and early clinical outcome of
co-transplantation of olfactory mucosa and bone
marrow stem cells in spinal cord injury-a novel
implantation with two-year follow-up

KnerlichLukoschus F

2015

Kaufman JL

2013

No use of stem
cells in spinal
cord injury

Tang H

2013

Animal study

Kantharajan
na SB

2013

Prospective
case series

16

17

18

19

20

21

22

23

24

Global Spine
Journal

2018

2017

2017

Evidence-based Guidelines for the use of Stem Cell Therapy: Neurological Conditions (supplement)

Conference
abstract,
no
use of stem
cells in spinal
cord injury
Nonrandomised
trial
No use of stem
cells in spinal
cord injury
No use of stem
cells in spinal
cord injury
Nonrandomised
trial
No use of stem
cells in spinal
cord injury
No use of stem
cells in spinal
cord injury
Review
of
trials
conducted,
only abstract
available
Animal study

Page 74
