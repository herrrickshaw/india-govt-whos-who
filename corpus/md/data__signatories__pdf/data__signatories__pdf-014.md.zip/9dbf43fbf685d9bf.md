---
doc_id: "9dbf43fbf685d9bf"
source_url: "https://www.dst.gov.in/static/uploads/2026/03/e55b4c27346bdf4585a806870273284a.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Identification of gazetted posts of Gr. A and Gr. B for reservation to disabled person under RPWD Act., 2016"
date: "2019-10-15"
pages: 10
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "92e3ff31c74f7895"
---

<!-- page 1 -->

No. A-13019/01/17-E.1 (2 pre
Government of India कि
Ministry of Science & Technology
Department of Science & Technology
Technology Bhavan
New Mehrauli Road
New Delhi-110016
iste
Dated the October, 2019
OFFICE ORDER
Subject: Identification of Gazetted Posts of Group ‘A’ & ‘B’ for reservation
to disabled persons under Rights of Persons with disabilities
(RPWD) Act, 2016.
The undersigned is directed to refer to M/o Social Justice and Empowerment's O.M.
No. 29-02/2019-D.III dated 21.05.2019 on the subject mentioned above.
2. It is informed thet, the Expert Committee constituted for identification of Gazetted
Posts suitable fer person with benchmark disabilities in terms of the provisions contained in
the RPwD Act, 2073 in the meeting held on 05.09.2019 at 3.30 PM identified 07 Gazetted
posts suitable for cesoris with cisabilities. A copy of the minutes of the meeting is enclosed
for ready reference.
E As above
Ape we
(V. Muralitharan)
Under Secretary to the Govt. of India
Tel. 011-26590501
oO
To: /¢
Shri K.V.S Rao, Director,
Department of Empowerment of Persons with Disabilities
M/o Social Justice and Empowerment,
Pi. Deendayal Antyodaya Bhawan,
C.G.O Complex, New Delhi-110003
Copy to:
efi 11 Ke
1. J.S (A), DST. — agefrr| ast Ah
2. Director (Estt-ll), DST._~ “ne e
Seep Ansa

<!-- page 2 -->

DEPARTMENT OF SCIENCE & RANI MENT OF SCIENCE & TECHNOLOGY
EL ARIMENT OF SCIENCE & TECHNOLOGY
MINUTES OF THE MEETING OF THE EXPERT COMMITTEE CONSTITUTED
FOR IDENTIFICATION OF GAZETTED POSTS OF GROUP ‘A’ & ‘B’ FOR
RESERVATION TO DISABLED PERSONS UNDER RIGHTS OF PERSONS
WITH DISABILITIES (RPWD) ACT, 2016
A meeting of the Expert Committee for identification of Gazetted Posts suitable for
person with benchmark disabilities in terms of the provision contained in the RPwD Act,
2016 was held on 05.09.2019 at 3.30 PM under the chairpersonship of the Ms. Anju
Bhalla, Joint Secretary (Admn.), Department of Science & Technology with the following
members:
1. Dr. M. Mohanty, Sc. ‘F’, DST - Member
2. Shri S.K. Sinha, Director (Admn.) - Member
3. Shri Rakesh Kataria, DS (E. 1) - Member
4. Shri V. Muralitharan, US (E.1) - Member
5. US, Parliament and Official Language —- *Member
6. Representative from
Ministry of Social Justice & Empowerment
(Shri K.C. Behera, Consultant) - Member
* The officer could not attend the meeting as he has been relieved from this Department
under RTP.
2.The Department of Science & Technology recruits for the following posts on direct
recruitment basis:
| 1. Junior Analyst (Technical), Gp. ‘B’ Gazetted (Non -
| । PB-2 Rs. 9300-34800 + GP Rs. 4600 Ministerial,Scientific and
| (pre-revised)/ Level-7, = 44900-1,42,400/- Technical), General Central
है ene Service
हट Scientist ‘B’ ool ‘A’ Gazetted (Non -
(PB-3, Rs. 15600-39100 + GP Rs, 5400) | Ministerial, Scientific
| revised) Technical), General Central
Level-10 % 56,100-1,77,500/- (Revised) Service ;
<
ye” / es -

<!-- page 3 -->

| 3. Scientist ‘C’ -do-
(PB-3, Rs. 15600-39100 + GP Rs. 6600)
Level-11 _% 67,700-2,08,700/- (Revised)
4. Scientist ‘D’
(PB-3, Rs. 15600-39100 + GP Rs. 7600)
Level-12 _% 78,800-2,09,200/-(Revised)
5. Scientist ‘E’ (No post exists in this grade.
(PB-4, Rs. 37400-67000 + GP Rs. 8700) Only promotion under
Level-13, % 123,100-2,15,900/-(Revised) Modified Flexible
Complementing Scheme is
granted in the grade)
6. Scientist ‘F’
(PB-4, Rs. 37400-67000 + GP Rs. 8900)
| Level-13A € 131,100-2,16,600/-
7. Scientist ‘G’
(PB-4, Rs. 37400-67000 + GP Rs. 10000)
Level-14, &% 144,200-2,18,200/-
Senior Adviser (Level-15)
% 1,82,200-2,24,200/-
3. The committee deliberated on the physical requirement and the functional
classification of the above posts and recommended post wise identification as under:
SL. No. | Name of | Physical Identified Nature of | Remarks / Working
post Requirement | suitable for | duties condition
(1) (2) (3) (4) Performed | (6)
(5)
\ ee L

<!-- page 4 -->

Group-A
Scientist |S, ST, W,| (a) The work |(a) The officials
‘B’ RW, = MF, | Locomotor usually usually work alone
SE, H Disability involves in a_ well-lighted
(OA, OL) | evolving, room having fully
including managing and | computerized
leprosy cured, | developing system without any
cerebral programs in | hazards.
palsy, the areas of
dwarfism, Science & | (b) Officials have to
acid attack | Technology, _| perform super-
victims and | inter- vision and
muscular departmental | coordination work.
dystrophy. inter- It frequently
institutional requires traveling
(0) Hard of) coordination | and
hearing. and communication.
cooperation in
(c) Multiple | Science. The post involves
disabilities Promotion of] scientific nature of
"| from amongst | basic Research | duties which
(a) to (b)/ and requires logical and
excluding development | analytical thinking
deaf- and Human | as such the
blindness Resource categories of
development. | autism, intellectual
disability etc. stated
in clause (d) of
34(1) of the RPWD
Act, 2016 has not
been identified as
suitable for the
post.
2. Scientist |S, ST, W,]| (a) The work | (a) The officials
‘¢ RW, MF, | Locomotor usually usually work alone
SE, H Disability involves in a_ well-lighted
(OA, OL) | evolving, room having fully
including managing and | computerized
leprosy cured, | developin,
ao =
fae 5

<!-- page 5 -->

a 5)
( ह।
cerebral programs in| system without
palsy, the areas of any hazards.
dwarfism, Science & | (b) Officials have to
acid attack | Technology, | perform super-
victims and | inter- vision and
muscular departmental, | coordination work.
dystrophy. inter- It frequently
institutional requires traveling
(b) Hard of| coordination | and
hearing. and communication.
cooperation in
(c) Multiple | Science. The post involves
disabilities Promotion of scientific nature of
from amongst | basic Research | duties which
(a) to (b)| and requires logical and
| excluding development | analytical thinking
deaf- and Human | as such the
blindness Resource categories of
development. | autism, intellectual
disability etc. stated
पे in clause (d) of
34(1) of the RPWD
Act, 2016 has not
been identified as
suitable for the
post.
3. Scientist |S, ST, W,/(a)  Locom | The work |(a) The officials
‘D’ RW, MF, | otor usually usually work alone
SE, H Disability involves in a well-lighted
(OA, OL) | evolving, room having fully
including managing and | computerized
leprosy cured, | developing system without any
cerebral programs in| hazards.
palsy, the areas of | (b) Officials have to
dwarfism, Science & | perform super-
acid attack | Technology, _| vision and
victims and | inter- coordination work.
muscular departmental, | It frequently
dystrophy. inter- requires traveling
institutional

<!-- page 6 -->

(b) Hard of | coordination | and
hearing. and communication.
cooperation in
(c) Multiple | Science. The post involves
disabilities Promotion of | scientific nature of
from amongst | basic Research | duties which
(a) to (b)| and requires logical and
excluding development | analytical thinking
deaf- and Human | as such the
blindness Resource categories of
development. | autism, intellectual
disability etc. stated
in clause (d) of
34(1) of the RPWD
Act, 2016 has not
been identified as
| suitable for the
ost.
4. Scientist |S, ST, W,/ (a) The work | (a) The officials
i RW, = MEF, | Locomotor usually usually work alone
SE, H Disability involves in a_ well-lighted
(OA, OL) | evolving, room having fully
including managing and | computerized
leprosy cured, | developing system without any
cerebral programs in | hazards.
palsy, the areas of | (b) Officials have to
dwarfism, Science & | perform super-
acid attack | Technology, | vision and
victims and | inter- coordination work.
muscular departmental, | It frequently
dystrophy. inter- requires traveling
institutional and
(b) Hard of} coordination | communication.
hearing. and
(c) Multiple | cooperation in} The post involves
disabilities Science. scientific nature of
from amongst | Promotion of | duties which
(a) to  (b)| basic Research | requires logical and
excluding and analytical thinking
| development | as such the
_ le —
A
ye” )

<!-- page 7 -->

é
> ७2४
deaf- and Human | categories of
blindness Resource autism, intellectual
development. | disability etc. stated
in clause (d) of
34(1) of the RPWD
Act, 2016 has not
been identified as
suitable for the
| post.

Sc.-G S, ST, W, | (a) The work} (a) The officials
RW, = MF, | Locomotor usually usually work alone
SE, H Disability involves in a_ well-lighted

(OA, OL) | evolving, room having fully
including managing and | computerized
leprosy cured, | developing system without any
cerebral programs in| hazards.
palsy, the areas of'| (b) Officials have to
dwarfism, Science & | perform super-
acid attack | Technology, _| vision and
victims and | inter- coordination work.
muscular departmental, | It frequently
dystrophy. inter- requires traveling
(b) Hard of} institutional and
hearing. coordination | communication.
(d) Multiple | and
disabilities cooperation in| The post involves
from amongst | Science. scientific nature of
(a) to (b)| Promotion of} duties which
excluding basic Research | requires logical and
deaf- and analytical thinking
blindness development | as such the
and Human | categories of
Resource autism, intellectual
development. | disability etc. stated
in clause (d) of
34(1) of the RPWD
Act, 2016 has not
been identified as
suitable for the
post.
(ae a
6

<!-- page 8 -->

6. Senior S, ST, W,| (a) Responsible (a) The officials
Adviser |RW, MEF, | Locomotor for policy | usually work alone
SE, H Disability formulation, |in a well-lighted
(OA, OL) | programme room having fully
including development | computerized
leprosy cured, | and system without any
cerebral implementatio | hazards.
palsy, n of, | (b) Officials have to
dwarfism, monitoring perform super-
acid attack | various vision and
victims and | projects, coordination work.
muscular represent the | It frequently
dystrophy. Department on | requires _ traveling
(0) Hard of | various and
hearing. committees, communication.
(c) Multiple | coordination
disabilities evaluating, The post involves
from amongst | organizing, scientific nature of
(a) to (b) cataloguing, duties which
excluding classifying, requires logical and
deaf- managing and | analytical thinking
blindness distributing as such the
information in | categories of
variety of | autism, intellectual
formats disability etc. stated
in clause (d) of
34(1) of the RPWD
Act, 2016 has not
been identified as
suitable for the
ost.
ye a
A

<!-- page 9 -->

Cc ue
NL
Group-B
7. Junior S, ST, | (a) Locomotor | Officials have to (a) The officials
Analyst W, Disability (OA, | perform usually work alone
(Technical) |RW, | OL) including | coordination in a well-lighted
MF, | leprosy cured, | work and requires | room having fully
SE, H | cerebral __ palsy, | communication. computerized
dwarfism, acid | The work usually | system involve
attack victims and | involve providing | without any
muscular technical and | hazards.
dystrophy. Scientific (b) Officials have
(b)Low Vision. assistance 10 [10 perform super-
(c) Hard of | scientists in the | vision and
| hearing and deaf. | department and coordination work.
(d) Specific | helps in evolving, | It frequently
| | in disability | managing and | requires traveling
and mental | developing and communicat-
| Ee programme in the | ion.
(e) Multiple | areas of Science
disabilities from | and technology
amongst (a) to (d) | and promotion of
except deaf- | basic research and
blindness development
Abbreviations used: S=standing, W=walking, BN=bending, L=lifting, KC= kneeling and
crouching, RW= reading and writing, MF=manipulation by fingers, SE= seeing,
C=communication, H=hearing, PP=pulling and pushing, OA=one arm, BA= both arm, OAL=
one arm and one leg, OL= one leg, BL= both leg.
ae

<!-- page 10 -->

C 923
3. The incumbent should be considered with aids and appliances wherever necessary.
aS YW
-C. Behera ) (V. Muralitharan)
Special Consultant, M/o SJ&E Under Secretary, Estt. I,
Member Member
print, - ao Wes al C4
NA
(Rakesh Kataria) (M Cash (S.K. Sinha)
Deputy Secretary, Estt. I, Sc. ‘F’, Director (Admn.)
Member Member Member
ber :
( Anju Bhalla )
Joint Secretary (Admn.)
Chairperson
-+ "0 --
