---
doc_id: "9db9f0f8ca9ee4e5"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6a9002faeda714.11668911.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Offer of appointment - Offer of appointment to the Indian Forest Service on the basis of the result of Indian Forest Service Examination, 2025 (Batch-2026)- 22 candidates, dated 27-08-2026"
date: ""
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b817d151720d5860"
---

<!-- page 1 -->

No.17012/01/2026-IFS-II
Government of India
Ministry of Environment, Forest & Climate Change
Indira Paryavaran Bhawan,
6th Floor, Prithvi Block,
Jor Bagh, Ali Ganj, New Delhi-1 10003
Dated: 27 August, 2026.
To,
The 22 number of candidates of IFS Exam, 2025
(as per list annexed).
Subject: Offer of appointment to the Indian Forest Service on the basis of the result of
Indian Forest Service Examination, 2025 (Batch-2026)-reg.
Sir/Madam,
Lam directed to offer you appointment to the Indian Forest Service (hereinafter referred
to as IFS) in the Junior Scale: Level 10 in the Pay Matrix of 7" CPC (Pay Band-3 of Rs. 15600-
39100 plus Grade Pay Rs. 5400/-) on the basis of the results of the IFS Examination conducted
by the Union Public Service Commission in 2025.
2 The terms and conditions of the service are laid down in the Rules and Regulations
framed from time to time under the All India Service Act, 1951 (hereinafter referred to as AIS).
You will be governed by those Rules and Regulations. Some of these terms and conditions are
summarized below for your guidance:-
I. ALLOCATION:
Under the rules of the Service you will be allocated to the State/Joint Cadres of the IFS and
will mostly be required to serve under the concerned State Government or the Central
Government. The Government, however, retains the right to require you to serve anywhere in
India or abroad; whether under the Central Government, any State Government or Public
Enterprise or a local body substantially owned or controlled by the Central or a State
Government.
Il. PROBATION:
You will be on probation for a period of two years from the date of joining and will be required
to undergo such training and pass such examination(s) as may be prescribed. The Central
Government may, however, extend the period of probation further. Failure to pass the
prescribed examinations, or to complete the period of probation to the satisfaction of the
Central Government will, on the other hand, render you liable to discharge from the service as
prescribed in the rules and only if you are already in Government service to reversion to your
substantive post, if any, under the Central or State Government on which you may be holding
a lien.
Ill. OTHER CONDITIONS:
You will be subjected to such further conditions of service or to modifications in the existing
conditions of service as may be made applicable to officers of the IFS, from time to time. Your
attention is also invited to the guidelines issued by the Ministry vide Office Memorandum

<!-- page 2 -->

No.17012/01/2021-IFS-II dated 15-07-2022 regarding acceptance of offer of appointment,
extension to join IFS, Year of allotment etc. as may be applicable.

IV(1) AGREEMENT :

On appointment, you will be required to execute an agreement in the prescribed form binding
yourself and one surety, jointly and severally, to refund, in the event of your failing to complete
probation to the satisfaction of the Central Government, all money paid to you consequent upon
your appointment as a Probationer. In the event of your accepting this offer of appointment and
joining Lal Bahadur Shastri National Academy of Administration (LBSNAA), Mussoorie /
Indira Gandhi National Forest Academy (IGNFA), Dehradun you will have to execute the
Agreement and deliver the same to the Director of the Academy for onward transmission to
this Ministry.

IV (2) DECLARATION ABOUT MARRIAGE:

Under Rule 5 of the IFS (Recruitment) Rules, 1966, a person having more than one spouse
living is not eligible for appointment to the IFS. The Central Government may, however, if
satisfied that such marriage is permissible under the personal law applicable to him/her or the
other party to the marriage, and there are other grounds for so doing, exempt any person from
the operation of this provision. This offer is, therefore, conditional on your signing a declaration
in the prescribed form and submitting to the Director, IGNFA, Dehradun, at the time of your
joining the Academy for training. In case you have more than one spouse living and you wish
to be exempted from the operation of the said provisions, you may furnish the full particulars
of your case to this Ministry immediately to enable the Government of India to take a decision
in the matter.

IV (3) DECLARATION ABOUT CLOSE RELATIONS:

On appointment, you will be required to furnish information about your close relations in the
prescribed form in duplicate and deliver the same to the Director, IGNFA, Dehradun at the
time of joining the Academy for training.
IV(4) DECLARATION ABOUT MOVABLE, IMMOVABLE AND VALUABLE
PROPERTY:

’ You shall also furnish information within forty-five days in respect of movable, immovable
and valuable property in accordance with the provision of Rule 16(1) of AIS (Conduct) Rules,
1968 (in duplicate) and deliver the same to the Director of the Academy.

3. Matters relating to conditions of service for which there is no provision in the Rules and
Regulations referred to above shall be regulated in the case of an officer serving under the
Central Government, by the Rules and Regulations applicable to officer of the Central Civil
Service Group ‘A’ and in the case of an officer working under the State Government, by the
Rules and Regulations applicable to the officers of the State Service Class-I under the State
Government concerned.

4. The information provided in this letter for guidance to the prospective new entrants to the
service cannot be made the basis of any tights by the appointee and all matters relating to the
various conditions of service referred to above shall be governed by the statutory rules and
regulations on the subject and the orders of the Central or the State Government, as the case
may be.

<!-- page 3 -->

5. PLEASE NOTE FURTHER THAT:
1. In accordance with Rule 13 of IFS (Appointment by Competitive Examination) Regulations,
1967, the offer of appointment is subject to the satisfaction of Central Government with regard
to:
(a) Verification of Character & Antecedents by the competent authority.
(b) Verification of original degree/post graduate degree certificates, Caste Certificate (if
applicable) if not already done by the UPSC.
2. In case, at any stage, it is found that any Certificate/Document/Testimonial etc. as furnished
by you having a bearing on your eligibility is not in order, then your appointment is liable to
be cancelled forthwith without prejudice to any punitive action under the relevant rules.
3. "The appointment is provisional and is subject to the Income and asset certificate being
verified through the proper channels and if the verification reveals that the claim to belong to
EWS is fake/false the services will be terminated forthwith without assigning any further
reasons and without prejudice to such further action as may be taken under the provisions of
the Bharatiya Nyaya Sanhita for production of fake/false certificate."
4. The provisions of Rule 8 of IFS (Probation) Rules, 1968, as amended from time to time may
also be noted that “no probationer in the service shall, during the period of training at the Indira
Gandhi National Forest Academy, Dehradun, appear in either the Civil Services Examination,
or in any other examination for appointment to the Central or State Service by open competitive
examination.”
6. Attention is drawn to proviso to Rule 3(3)(i) of IFS Seniority Rules, 1997 which is extracted
below:
“3(3). The year of allotment of an officer appointed to the Service after the commencement of
tules shall be as follows:
i. the year of allotment of a direct recruit officer shall be the year following the year in which
the competitive examination was held:
Provided that if direct recruit officer is permitted to join probationary training under
Sub-rule (1) of Rule 6 of the IFS (Probation) Rules, 1968 with the direct recruit officers
of subsequent year of allotment, then he/she shall be assigned that subsequent year as the
year of allotment.”
7. The candidate who fail to join in the designated Academy on time, he/she will not be
permitted to join the Course at a later date. Such candidates will, however, if permitted to join
along with the candidates of the next batch, i.e. 2026 Examinees (batch- 2027), his/her year of
allotment will be in accordance with details at para 6 above.
8. Please convey through a single e-mail about your acceptance to this offer of appointment.
Your are also required to clearly indicate your decision regarding whether you will be joining
the service with the current batch and attend the 101% Combined Foundation Course (FC) or
seek exemption for attending the 101‘ Combined Foundation Course (FC). Alternatively, you
are required to inform whether you seek one year extension to join the service with the
: subsequent batch. You are required to intimate your decision regarding joining the Service
latest by 04-09-2026 failing which no request will be considered thereafter. In all
correspondence (at the e-mail address: ifs@nic.in) with the Ministry you are required to

<!-- page 4 -->

indicate the "Subject" as "IFS Examination, 2025" and also indicate your Roll Number,
Rank, Name, before the text of the letter, to ensure’ promptness in dealing with the
matter.
9 . You must report for joining the service/training at training institutes assigned by the Lal
Bahadur Shastri National Academy of Administration (LBSNAA) on the day designated by
LBSNAA as per their training schedule. Detailed instructions with regard to joining Foundation
Course / Professional Course will be issued separately by LBSNAA / IGNFA. You are directed
to keep checking your e-mail / official website of this ministry (Environment, Forest and
Climate Change) i.e. http://moef.gov.in and LBSNAA www.lbsnaa.gov.in and IGNFA
http://www.ignfa.gov.in for further updates in this regard. Further, you are also directed to
contact and the Director, LBSNAA/IGNFA regarding the scheduling of the 101 Combined
Foundation Course (FC).
10. This issues with the approval of Competent Authority.
Yours faithfully शक
(७०५१४ en 0% Wd
Or
(Phalguni Banerjee)
Under Secretary to the Government of India
Tel. No. 011-20819360
e-mail: ifs@nic.in.
Copy for information to: -
1. The Director, Indira Gandhi National Forest Academy (IGNFA), P.O. New Forest, Dehradun
with the request to nominate them for attending 101% FC.
2. The Secretary, Union Public Service Commission, Dholpur House, Shahjahan Road, New
Delhi-110003 for information & further n.a.
3. The Director, Lal Bahadur Shastri National Academy of Administration
(LBSNAA),Mussoorie, with the request to allow them to join the 101% FC.
4. The Director (AIS), DoPT, North Block, New Delhi.
5. NIC, MoEF&CC, New Delhi — for uploading on the IFS website www. ifs.nic.in and also for
e-mailing to concerned candidates/offices

<!-- page 5 -->

ANNEXURE

List of twenty two_number of Candidates of IFS Exam, 2025 as under:
IRANK NO]

| |

|
|

—_
|e
| |
|

| |
|

|

|
|
||

pe
IRAJAN SHARMA
