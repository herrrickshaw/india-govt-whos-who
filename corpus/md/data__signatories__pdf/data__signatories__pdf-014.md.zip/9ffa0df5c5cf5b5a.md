---
doc_id: "9ffa0df5c5cf5b5a"
source_url: "https://doj.gov.in/static/uploads/2025/12/31a8e9ebbbde4e1221034b2a5eba90f7.pdf"
ministry: "Department of Justice (DoJ)"
title: "DAKSH, Bengaluru"
date: "2023-09-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6af5fe29dac7cb18"
---

<!-- page 1 -->

File No. N-9/13/2020-NM (E-S230)
Government of India
Ministry Of Law and Justice
(Department of Justice)
Jaisalmer House,26, Mansingh Road,
.
New Delhi-11 0011
Dated: 06.09.2023
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded to the payment of RS.6,60,0001(Rupees Six Lakhs Sixty Thousand Only) to DAKSH, Bengaluru towards of Third Instalment (being
30% of total project cost of Rs. 22,00,0001-(Rupees Twenty two lakh only) for undertaking research
project titled "Ideation and Implementation of the Phase III of the eCourts Mission Mode Project"
under the "Scheme of Action Research and Studies on Judicial Reforms" as per the terms of the
agreement signed by DAKSH and Department of Justice on 25th November, 2020. 15t instalment and
2nd instalment of Rs.4,40,0001- and Rs. B,BO,OOOI- has been released to the Implementing Agency
vide Order dated 09.12.2020 and 25.02.2022 respectively.
2.
The expenditure involved is debitable to Demand nO.65 during 2023-24 (Non-Scheme) Major
Head 2052-Secretariat General Services-00.090-Secretariat, OB-Department of Justice, OB.00.31Grant-in-Aid (General).

3.

This has been entered in the Register of Grants 1 Expenditure at SLNo. 3 at page no.179-1BO.

4.
This issues with the approval of IFD (Law) vide Note nO.204 Dated Q5.09.2023 & Secretary (J)
approval vide Note nO.20B dated 06.09.2023 in eOffice IComputer File No. e-5230.

"I11",,.,,-

(Yashasvi Kumar)
Director
Tel./Fax No. 011- 23072135
E-mail: dir-nm-doj@gov.in

To,
Pay & Account Officer,
.Ministry of Law & Justice, Department of Legal Affairs
Janpath Bhawan, Janpath
New Delhi.
Copy to:1. Cash section, Department of Justice with one spare copy and copy of Agreement. It is requested
that payment may be made through e-payment to "DAKSH, Bengaluru".
2. DDO & Under Secretary (Admin.II), Department of Justice, Jaisalmer House, New Delhi.
3. IFD/Budget division, Ministry of Law & Justice, Legislative Department, Shastri Bhawan, New
_/Delhi.
-vY. NIC, Jaisalmer House, New Delhi for uploading on the Department of Justice website.
5, Shri Harish Narasappa (Head) DAKSH, No.63, Palace Road, Abshot Layout, Vasanth Nagar,
I Benqaluru=- 560001.
.
6\ Prihcipal Accounts Office, 4th Floor, Ministry of Law & justice, Lok Nayak Shawan, Khan Market,
New Delhi.
7. Guard File.
