---
doc_id: "a18d5e0ba9ceeea0"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/30d7f283fd843670c37577af0d7ea1a5.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 02.05.2025: Engagement of Advocates for High Court of Himachal Pradesh at Shimla, CAT at Chandigarh Bench, AFT (RB) Chandigarh"
date: "2025-05-02"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e0dddfd7ab9c130b"
---

<!-- page 1 -->

F. No. J-11017/16/2025-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
aR ROK
Shastri Bhawan, New Delhi
Dated the 2" May, 2025
ORDER
The President is pleased to engage following Advocates for conducting Central
Government litigation before the High court of Himachal Pradesh at Shimla, Central
Administrative Tribunal at Chandigarh Bench, Armed Forces Tribunal (RB)
Chandigarh, as shown in the List-'A’, List-'B' and List-"C’ below, with effect from the
date of this order for a period of three years or until further orders, whichever is
earlier:
List ‘A’
High Court of Himachal Pradesh at Shimia
Name of Advocate Contact Details Enrol. No.
51.
No (S/Shri)}
SENIOR PANEL COUNSEL
1, Ms, Reeta Thakur Chamber No. 101, Lawyer's Chambers, HIM/150/1999
District Court Complex, Chakkar Shimla-5
Mob: 9418031267
Email: Reetathakur581@gmail.com
2. Harish Sharma Hotel Tashkent Annexe, The Mall-Shimla HIM/84/2000
Email: sharma.harishS9@gmail.com
3. Bharat Bhushan Village Dalgaon, P.O Kutara, Tehsil Rohru, | HIM/353/2008
District Shimla, H.P
Mob: 8894239310 :
Email: bharatbhushan.bharatS@gmail.com
Avinash Jaryal Chamber No. 408, Vidhi Nikunj, Near HP HIM/138/2004
High Court Simla-1
Mob: 9418184997, 8628084997
Email: Jaryal.avinash@gmail.com
Page 1 of 4

<!-- page 2 -->

CENTRAL GOVERNMENT COUNSEL
Email: advchauhan385@gmail.com
Anshul Attri Chamber No, 450, H.P High Court HIM/97 /2011
Advocates’ Chambers, Near Hon’‘ble High
Court, H.P, Shimla-171001
Mob: 9736045425
Email: advanshulattri@qmail.com
7. Ajay Kumar Vidhi Kunj, Lawyers’ Chambers, Chamber | 14/75/2014
Chauhan No. 430, H.P High Court Shimla, H.P
Mob: 9459100047
Email: cajay404@gmail.com
Janak Raj Chamber No, 211, Vidhi Nikunj, Advocates | HIM /315/2019
Chamber Complex, Near H.P High Court,
Shimla
Mob: 9418313266
Email: janakchauhan@gmail.com
Narender Thakur Chamber No. 262, Advocate Chamber H.P | HIM/233/2010
High Court Shimla
Mob: 09418202405, 09817016789
Email: narender.84adv@gmail.com
|
Vyas
Bhatti High Court Shimla-1
Mob: 9418027666
12. Kunal Thakur Verma Apartments Block-A, Khalini, HIM/ 207/2007
Beerkhana, Flat No. 8
Mob: 7018159082
Email: kunalthakuradvocate@gmail.com
LIST ‘B‘
CENTRAL ADMINISTRATIVE TRIBUNAL, CHANDIGARH BENCH
(For all cases of Himachal Pradesh irrespective of place of filing)
Sl. Name of Advocate Enrol. No.
No. | (S/Shri)
1. Ms. Suchitra C/o Rajiv Bhawan, VPO Chailly, Summer Hiil,| HIM/447/1999
Thakur Shimla, Himanchal Pradesh-171005
Mob: 9418074510
__ Email: advsuchitra040675@gmail.com
Page 2 of 4

<!-- page 3 -->

2. Vinod Thakur Village Jhanikar Post Office Barara Tehsil HIM/122/2000
Tauni Devi (Bamson) District Hamirpur,
Himanchal Pradesh
3 Surinder Dinesh Niwas, Ram Nagar, Shimla-171004 | HIM /280/2002
Sharma Mob: 9816490609, 9418190609
Email: surindersharma31loct@gmail.com
Nimish Gupta B-4, 2nd Floor, M.C Parking Complex Near | D/1915/2005
High Court, Shimla-01
Mob: 9805410825
Email: advnimish@gmail.com
5. Veer Bahadur Chamber No, 130, HP High Court Advocates, | HIM/263/2002
Verma Chambers
Mob: 9418063140, 7018942502
Email: advocatevirverma@gmail.com
ADDITIONAL CENTRAL GOVERNMENT STANDING COUNSEL
Naresh Chamber No. 122, H.P High court Advocates | HIM/138/2009
Kumar Sharma Chambers, Shimla-170001
Mob: 9817208755, 8628808755
Email: nksadvocate@gmail.com
7. Vinod Kumar Chamber No. 452, Lawyers Chamber Welfare] HIM/106/2013
Chauhan Society, Near H.P High Court Shimla
Mob: 9418118082
Email: vinodchauhanadvocate@gmail.com
Ankit Chamber No, 127, Adocate’s Chamber, Vidhi} HIM/355/2023
Chandel Kunj, Highcourt of Himanchal Pradesh,
Shimla-171001
Mob: 8219517924
Email: chandelankit69@gmail.com
List *C’
ARMED FORCE TRIBUNAL (RB) CHANDIGARH
(For all Cases of Himanchal Pradesh)
Sl. | Name of Advocate | Contact Details Enrol. No.
No. Shri
SENIOR PANEL COUNSEL
1. Vivek Sharma Shashi Niwas, 2nd floor, Near District, | HIM/215/2007
Solan, H.P
Mob: 9418080330, 9882034000
Email: ysadv07 @gmail.com
Page 3 of 4

<!-- page 4 -->

|Z. Aditya Singh Block-5, B-1, Sector-6, Parwanoo, HIM/375/2011
| Mandyal Tehsil Kasauli, Distrtict Solan, H.P-
173200
Mob: 9459641847
Email:adityasinghmandyal@gmail.com
| Ajay Sipahiya Lawtime, Basal, Solan,H.P HIM/85/2013
Mob: 9418061113, 8219431893
Email: ajaysipahiya@qmail.com
4. Ishant Sharma Chamber No. 116, Advocates HIM/304/2017
Chamber Complex, Judicial Court
Complex Chakkar, Shimla-1
Mob: 8091490000
a Email: ishant_jbl@yahoo.com i
De The engagement and professional fee of the aforesaid advocates will be governed by
the terms and conditions contained in this Department's OM No. 26(I)/99-Judl. dated
24,09.1999 read with OM No, 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through OMs especially the OM No. J-16/11/2017-Judicial dated 08.02.2018
imposing certain restrictions-on panel counsel. The aforesaid OMs are available on the website
of this Department i.e. www.legalaffairs.gov.in in the tab ‘Judicial Section’ under heading
‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow. Qa
s!
(Madhab Charan Prusty)
Senior Government Advocate
Copy (through email) to:

1. PS to Hon‘ble MoS (I/C) L&J.

2. PSO to Law Secretary/All Additional Secretaries and Joint Secretaries in the main Secretariat of
Department of Legal Affairs

3. Ld. Addl. SGI, Punjab & Haryana High Court at Chandigarh.

4. Shri Balram Sharma, Deputy SGI for High Court of Himachal Pradesh at Shimla.

5. Shri Jagjot Singh Lalli, Deputy SGI, Punjab & Haryana High Court, Chandigarh.

6. The Registrar, High Court of Himachal Pradesh at Shimla.

7. The Registrar CAT, Chandigarh.

8. Ther Registrar, AFT, Chandigarh.

9. The Judge Advocate General, AFT (RB) at Chandigarh.

10. Shri Sanjay Goyal, Sr. CGSC, CAT, Chandigarh Bench.

11. LIMBS Section for necessary section.

12. One copy of this order is uploaded on website of this Department i.e. www.legalaffairs.goy.in under
tab ‘Judicial Section’ in the link ‘Orders related to empanelment of Advocates for Union of India’
for the information of all concerned.

13. Hindi unit, Department of Legal Affairs for Hindi translation of the order. af

14. Office copies. wre ०५. ¥

. wre
(Kumar Gaurva)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
Page 4 of 4
