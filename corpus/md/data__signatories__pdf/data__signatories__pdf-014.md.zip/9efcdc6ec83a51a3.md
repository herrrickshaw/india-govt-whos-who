---
doc_id: "9efcdc6ec83a51a3"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/e05f2ca820e7442080c9502ec2733ebd.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Seeking comments from the stakeholders on draft recruitment rules for the post of Estate Officer in DST"
date: "2025-05-24"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8003d0485c2de94d"
---

<!-- page 1 -->

I

taWffit
ffintkfidf,tdmmq

mffi*rittrtr*nqn
tq{dd qq{,{qtqdfrqrf
qttffil-rro ilo
,-li,. : ''

OOWAilIIIHTOTHDN

flWi , Tel

Sflj,lar

?fi$fi?819, I$SII?3,

IiI}II$TRY OT $CEFIEE Al\lO TEC||FIOTOEY

:n$rj21 34, Ifi$$?l1? tfP$AX)

DIPARTil{TNT OI $OT|{CE Ar{O TEC|"|i{OLOGY

rri5fis00, I$515037,

ltcl{l'i0"0sY BLA\IAN, l\l$! fuU{ttL,tj ROAn

lfififrifidir,2$$fi141$

l,i[ln, D[tt1l.ll0 01fi

r,lr-ifliircit$rlr : uww.dsi,gov,in

Date: 24-05-2024

A-1 20 1 91212024-Estt. I I I

.i.

Subject: Seeking comments from the stakeholders on draft
recriritment rules- for the post of Estate Officer in Department of

Science and Technology (DST) - reg.
This Department is in the process of framing recruitment rules
for 01 (one) pcjst of Estate Officer (Level 08) in this Department. ln
this regard, the draft RFls (copy enclosed) for the aforementioned post
is being put up on this Department's website lor 30 days for inviting
comments from the stakeholders.
All stakeholders are, therefore, requested to peruse the draft
RRs and give their inputs preferably in a tabular form (in a word file)
by specificaliy indicaiing the para number, original content _and the
w.r.t the original content latest by 23.06-2024. The
change suggested
comments may be sent preferably via email to recruitmentcell'

2.

dst@nic.in.

G.n

t,

At oJ>'re
"l

W-'

,

@+Eg;wt en.fy

{ta:

Grqt qlilq, qr{d giSFn
{tHN: 01 1-26590515
n ic. i n
itnibntcell-dst@
recru

c-qs"*J- .Y}2

<!-- page 2 -->

*2To:

shri Rabindra K. Panigraphy, scientist 'E' & wlM, DST - with a
request to upload the draft RRs on recruitment cell webpage

and what's new tab of the DST website.

0&r1al$0 tom ui ofi

tnda0$T or urutsqfrukedldq0$I

ffi
ffi lndio0$T m wru.h{k;corrglnrriflsl

<!-- page 3 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART II, SECTION 3, SUBSECTION (i)]
Government of India
Ministry of Science and Technology
Department of Science and Technology
NOTIFICATION
New Delhi, the
G.S.R……………– In exercise of the powers conferred by the proviso to article
309 of the Constitution, the President hereby makes the following rules regulating
the method of recruitment to the post of Estate Oﬃcer in the Department of
Science and Technology under the Ministry of Science and Technology, namely: –
1. Short title and commencement. - (1) These rules may be called the

Ministry of Science and Technology, Department of Science and Technology,
Estate Officer (Group ‘B’ post) Recruitment Rules, 2024.
(2) They shall come into force on the date of their publication in the Official
Gazette.
2. Number of post, classiﬁcation and level in the pay matrix -The number

of the said post, its classiﬁcation and level in the pay matrix attached thereto
shall be as speciﬁed in columns (2) to (4) of the Schedule annexed to these
rules.
3. Method of recruitment, age-limit, qualiﬁcations, etc. - The method of
recruitment, age-limit, qualiﬁcations and other matters relating to the said
post shall be as specified in columns (5) to (13) of the said Schedule.
4. Disqualification – No person, a. who has entered into or contracted a marriage with a person having a spouse

living; or
b. who having a spouse living, has entered into or contracted a marriage with
any person, shall be eligible for appointment to the said post:
Provided that the Central Government may, if satisﬁed that such marriage is
permissible under the personal law applicable to such person and the other party to
the marriage and that there are other grounds for so doing, exempt any person
from the operation of this rule.
5. Power to relax. - Where the Central Government is of the opinion that it is

<!-- page 4 -->

necessary or expedient, so to do, it may, by order and for reasons to be
recorded in writing and in consultation with the Union Public Service
Commission, relax any of the provisions of these rules with respect to any
class or category of persons.
6. Saving. - Nothing in these rules shall aﬀect reservations, relaxation of agelimit and other concessions required to be provided for the Scheduled
Castes, the Scheduled Tribes, Ex-servicemen and other special categories of
persons, in accordance with the orders issued by the Central Government
from time to time in this regard.
SCHEDULE
(1)

(2)

Name of post.

Number of post.

Estate Officer

(3)
Classification.

1 (2024) *Subject to variation General
dependent on workload.

Central

Service,
Group ‘B’, Gazetted,
Non-Ministerial.

(4)

(5)

(6)

Level in pay matrix.

Whether selection post or

Age-limit for direct

non-selection post.

recruits.

Non-Selection.

Not applicable.

(7)

(8)

(9)

Educational and other

Whether age and

Period of probation

qualification required

educational qualification

if any.

for direct recruits.

prescribed for direct

Level 8 in the pay matrix
(Rs. 47600-151100).

recruitment will apply in the
case of promotees.
Not applicable.

Not applicable.

Not applicable.

<!-- page 5 -->

(10)
Method of

(11)
In case of recruitment by promotion or

recruitment, whether

deputation or absorption grades from which

by direct recruitment

promotion or deputation or absorption to be

or by promotion or by

made.

deputation or
absorption and
percentage of the
vacancies to be filled
by various methods.
Promotion failing which

I. Promotion: The Departmental Estate

by deputation (including

Supervisor in level 6 (Rs. 35400-112400) in the

short term contract).

pay matrix with six years of regular service in
the grade.
II. Deputation (including short term contract):
Oﬃcers under the Central Government or State
Government or Union territories or Universities or
recognised research institute or public sector
undertakings

or

statutory

or

autonomous

organization,(a) (i) holding analogous post on a regular basis in
the parent cadre or department; or
(ii) with two years’ service in the grade rendered
after appointment thereto on a regular basis in posts
in level 7 (Rs. 44900-142400) in the pay matrix or
equivalent in the parent cadre or department; or
(iii) with six years’ service in the grade rendered after

<!-- page 6 -->

appointment thereto on a regular basis in posts in
level-6 (Rs 35400-112400) in the pay matrix or
equivalent in the parent cadre or department;
and
(b)

possessing

the

following

educational

qualifications and experience:
(i) Degree/Diploma in Civil or Mechanical or
Electrical

or

Engineering

Electronics
from

a

or

Public

recognised

Health

University

or

Institute; and
(ii) two years’ experience in the upkeep and
maintenance of office buildings.
Note 1: The Departmental oﬃcers in the feeder
category who are in direct line of promotion shall not
be eligible for consideration for appointment on
deputation. Similarly, deputationists shall not be
eligible

for

consideration

for

appointment

by

promotion.
Note 2: The period of deputation (including shortterm

contract)

including

period

of

deputation

(including short-term contract) in another ex-cadre
post held immediately preceding this appointment in
the same or some other Organisation or Department
of the Central Government shall ordinarily not
exceed three years. The maximum age-limit for
appointment by deputation (including short-term
contract) shall be not exceeding ﬁfty-six years as on
the closing date of the receipt of applications.

<!-- page 7 -->

(12)
If Departmental Promotion Committee exists, what

(13)
Circumstances in

is its composition.

which Union Public
Service
Commission is to
be consulted in
making
recruitment.

Group ‘B’ Departmental Promotion Committee (for Consultation
considering promotion) consisting of:

with

Union Public Service

Commission is not
1. Joint Secretary (In charge of Administration),
Department of Science and Technology –
necessary.
Chairperson;
2. Director/Deputy Secretary (In charge of General
Administration), Department of Science &
Technology – Member;
3. Director/Deputy Secretary (In charge of any other
Branch/Division), Department of Science &
Technology – Member;
