---
doc_id: "9ccaa0bf05d19da8"
source_url: "http://www.moef.gov.in/uploads/2022/01/5th-amedment.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "S.O. 5487(E)-दिनांक-[31/12/2021]-पर्यावरण (संरक्षण) पाँचवाँ संशोधन नियम, 2021"
date: "2022-01"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "79a3b896fe68d408"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-31122021-232289
xxxGIDHxxx
CG-DL-E-31122021-232289
xxxGIDExxx
ऄसाधारण
EXTRAORDINARY
भाग II—खण्ड 3—ईप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 5081]
No. 5081]

नइ ददल्ली, िुक्रवार, ददसम्बर 31, 2021/पौष 10, 1943
NEW DELHI, FRIDAY, DECEMBER 31, 2021/PAUSA 10, 1943

पयाावरण, वन और िलवायु पररवतान मंत्रालय
ऄजधसूचना
नइ ददल्ली, 31 ददसम्बर, 2021
का.अ. 5487(ऄ).—के न्द्रीय सरकार, पयाावरण (संरक्षण) ऄजधजनयम, 1986 (1986 का 29) की धारा 6 और
धारा 25 द्वारा प्रदत्त िजियों का प्रयोग करते हुए, पयाावरण (संरक्षण) जनयम, 1986 का और संिोधन करने के
जनम्नजलजखत जनयम बनाती है, ऄथाात् :1. संजक्षप्त नाम और प्रारं भ.(1) आन जनयमों का संजक्षप्त नाम पयाावरण (संरक्षण) पांचवां संिोधन जनयम, 2021 है।
(2) ये रािपत्र में ईनके प्रकािन की तारीख को प्रवृत्त होंगे।
2.
पयाावरण (संरक्षण) जनयम, 1986 के जनयम 5 के , ईप-जनयम (3) के , खंड (घ) में, "31 ददसंबर, 2021 िब्दों,
ऄक्षरों और ऄंकों के स्ट्थान पर, 30 िून, 2022 िब्दों, ऄक्षरों और ऄंकों को रखा िाएगा "।
[फा. सं. 25/03/2010-इएसिेड]
डॉ. सतीि चन्द्र गढ़कोटी, वैज्ञाजनक ‘िी’
रटप्पणः मूल जनयम ऄजधसूचना संखयांक का.अ. 844(ऄ), तारीख 19 नवंबर, 1986 द्वारा प्रकाजित दकया गया था और
ऄंजतम बार संिोधन ऄजधसूचना संखयांक का.अ. 2346(ऄ), तारीख 16 िून, 2021 को दकया गया था।

7711 GI/2021

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 31st December, 2021
S.O. 5487(E).—In exercise of the powers conferred by section 6 and section 25 of the Environment
(Protection) Act, 1986 (29 of 1986), the Central Government hereby makes the following further
amendment in the Environment (Protection) Rules, 1986, namely: —
1. Short title and commencement.(1) These rules may be called the Environment (Protection) Fifth Amendment Rules, 2021.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Environment (Protection) Rules, 1986, in rule 5, in sub-rule (3), in clause (d), “for the words,
letters and figures 31st December, 2021, the words, letters and figures 30th June, 2022 shall be
substituted”.
[F. No. 25/03/2010-ESZ]
Dr. SATISH C. GARKOTI, Scientist ‘G’
Note : The principal rules were published vide S.O. 844 (E), dated the 19th November, 1986 and was last
amended vide notification number S.O. 2346 (E), dated the 16th June, 2021.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

Digitally signed by MANOJ
KUMAR VERMA
Date: 2021.12.31 19:29:00
+05'30'
