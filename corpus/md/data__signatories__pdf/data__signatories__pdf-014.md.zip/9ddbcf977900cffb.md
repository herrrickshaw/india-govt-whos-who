---
doc_id: "9ddbcf977900cffb"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/a6a8229d03552a0c045615e706e8a9b5.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment of RRs of Group-C posts of Laboratory Assistant in RDTL, Chandigarh"
date: "2022-09-15"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6d8f98c8133b636f"
---

<!-- page 1 -->

A.12018/2/2020-DRS(PART-Vm)
Government of India

Ministry of Health and Family Welfare
Department of Health and Family Welfare
(Drugs Regulation Section)
Dated:It August, 2022
NOTICE

This Ministry is examining a proposal for amendment of Recruitment Rules for the
post Laboratory Assistant at Regional Drugs Testing Laboratory (RDTL), Chandigarh,
Central Drugs Standard Control Organization (CDSCO), Directorate General of Health
Services, Ministry of Health & Family Welfare. In this regard, draft Recruitment Rules have
been prepared, a copy of which is attached.

2.
Before finalizing the same, comments, if any, are invited fi*om all stakeholders in the
matter within a period of thirty days from the date of this notification on the website of the
Ministry of Health and Family Welfare. The comments/objections/suggestions received from
the stakeholders within the specified period shall be considered by the Ministry as per
rules/requirement before finalizing the Recruitment Rules.
3.
The comments may be furnished to undersigned room no.407-A,'A' Wing,Nirman
Bhavan, New Delhi-110011 or may kindly be sent to drugsdiv-mohfw@gov.in.

Enci:A/a.

(Dr. Kir^ Kumar Karlapu)
Deputy Secretary to the Government of India
Tele:-011-23062928

<!-- page 2 -->

Schedule

Name of post.

Number of

Classification.

post.

Level in pay
matrix or pay

selection post

scale.

or non-

Whether

Age-limit for direct recruits.

selection

post.

(2)

(1)
Laboratory

(3)

02*(2022)

Assistant

♦subject
variation

to

(5)

(4)

General

Central

Service

Group

"C"

Non-

Gazetted,

Non-

Pay Level 3 in
pay matrix (Rs.
21700-69100)

Not

(6)

Between 18 and 25 years

Applicable

dependent on Ministerial
workload.

Educational and other qualifications required for Whether age and educational Period of probation, if any.
direct recruits.
qualifications
prescribed
for
direct recruits will apply in the
case of promotees.

■

(7)

Intermediate with science

(8)
Applicable

(9)

2 years for direct recruitment

Desirable: Graduation in science with chemistry as
one of the subject
Method
of In case of recruitment by If a Departmental Promotion Circumstances in which Union Public
recruitment whether promotion/
deputation/ Committee exists, what is its Service Commission is to be consulted in
by direct recruitment transfer, grades from which composition.
making recruitment.
or by promotion or promotion/
deputation/
by
deputation/ transfer to be made.
transfer

percentage

and

of

the

vacancies to be filled

by various methods.
(10)

(11)

(12)

(13)

s.

<!-- page 3 -->

50%

Direct Promotion:

Recruitment

50% Promotion

and

Laboratory Attendant in
PB-l(Rs.5200-20200)
+
Grade Pay 1800/Pay Level1 with 6 years regular
service shall be eligible for
promotion

Group
'C
Departmental
Promotion
Committee
(for

considering

Not Applicable

confirmation/

promotion) consisting of:
1. Director, Regional Drugs
Testing Laboratory Chandigarh
—Chairman

2. Deputy Director (Admn)
Central Drug Standard Control
Organisation (HQ),New Delhi
~ Member

3. Any group *A'
Regional
Drugs
Laboratory Chandigarh

Officer,
Testing

— Member

[F.No.A.12018/02/2020-DRS-Part(Vn)]

(Dr. Kiran Kumar Karlapu)
Deputy Secretary to the Govemment ofIndia
