---
doc_id: "a1673fc8c3bfaa1d"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/079a52ab832af6dae30bfe189e8fcc1a.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Proposed New Recruitment Rules for the post of LDC in Lady Reading Health School, New Delhi -Notification"
date: "2024-09-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2e821cdbd69cb240"
---

<!-- page 1 -->

ITO BE PUBLISHED IN THE GAZATTE OF INDIA, PART II,
sEcTloN 3, suB sEcrloN 3(i)l
GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE

Notilication
New Delhi,

the 2024

G.S.R.-l407. ln exercise ol the powers conferred by the proviso to
article 3Og ol the Constitution, and in supersession ol the Lady Reading

'1962, in so far as they relate to the
Health School. Delhi Recruitment Rules
post of Lowel Division Clerk, except as respects things done or omitted to
be done before such supersession the President hereby makes the
following rules regulating the method of recruitmenl of the Lower Division
Clerk in the Lady Reading Health School. Delha namely:-

1- Short titl6 and commencement- (1)These rules may be called Ministry of
Health and Family Welfare, the Lady Reading Health School, Oelhi
Recruitment Rules. 2024

(2) They shall come inlo fo,ce on the date ol their publication in the Otficial
Gazette.

2. Number ol post, classilication and level in the pay malrix- The number
ol the said post, its classilication and the level in the pay matrix attached
thereto shall be as specilied in columns (2) to (4) of the Schedule annexed to
these rules.
3. ilethod ol recrultment, age'limit, qualiticalions, elc-The meihod ol
post
recruilmenl, age-limit, qualilication and other matters relating to the said
shall be as specilied in columns (5) to {13) ol the said Schedule'
4- Disqualilication.- No person'
a. who has entered inlo or contracted a marriage with a person having a spouse
living, or
b. Who, having a spouse living, has entered into or contracted a marriage with
post:
any person, shail be eligible lor appointment to the said

Provided that the Central Government may, it sat'sfied that such
person
marriage is permissible under the personal law applicable to such
grounds lor so
and th! other party to the marriage and thal there are other
doing, exempt any person from the operation ol this rule'
5. Powor to retax- Where the Central Government is ol the opinion that

it is

<!-- page 2 -->

necessary or expedienl to do, it may, by order. tor reasons lo be recorded in
wriling in consultation with Union Public Service Commission, relax any ol the
provisions ol these rules with respect to any class or category of persons.

Saving- Nothing in these rules shall atlecl reservalion, relaxalion ol age limit and
olher concessions required to be provided for the Scheduled Castes, lhe
Scheduled Tribes, Other Backward Class, ex-Servicemen and other special
categories ol persons in accordance with the orders issued by the Central
Government from lime to time in this regard.
