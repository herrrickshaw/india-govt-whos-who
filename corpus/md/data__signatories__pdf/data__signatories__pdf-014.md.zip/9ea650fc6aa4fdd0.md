---
doc_id: "9ea650fc6aa4fdd0"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/115a90a7ee6994762249bbea26108be0.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Public Notice on Amendment of Recruitment Rules to the post of Library & Information Officer (LIO) in National Medical Library, Dte.GHS"
date: "2022-11-03"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "6a849df24f5fa47e"
---

<!-- page 1 -->

No.A.12018/02/2022-Estt.III
Government of India
Ministry of Health & Family Welfare
(Department of Health & Family Welfare)
Establishment - III Section
Nirman Bhawan, New Delhi
एलन. +.
NOTIFICATION
This Ministry is examining a proposal for amendment to the Recruitment Rules
for the existing 01 post of Library & Information Officer in National Medical Library,
Directorate General of Health Services, New Delhi. In this regard, draft Recruitment
Rules have been prepared and approved by the Competent Authority.
2. Before taking up the proposal for amendment of the Recruitment Rules with the
Nodal Agencies for finalizing the same, comments, if any are invited from all
stakeholders in the matter within a period of thirty (30) days from the date of
notification in the website of the Ministry of Health & Family Welfare. The
objections/ suggestions received from the stakeholders within the specified period shall
be considered by the Ministry as per rules/requirements.
3: The comments may be furnished to the undersigned in Room No.360-C, Nirman
Bhawan, Maulana Azad Road, New Delhi or at jaiswal.r72@nic.in
cag
(Raj al)
Under Secretary to the Government of India
Tel. No. (911) 2361323
h

<!-- page 2 -->

: {To be published in the Gazette of India}
Part-II-Sec-3, Sub-Section-(i)
Government of India
MINISTRY OF HEALTH AND FAMILIY WELFARE
(Department of Health and Family Welfare)
New Delhi, the .........2022
Notification
G.S.Revsuw-In exercise of the powers conferred by the proviso to article 309 of the
Constitution and in supersession of the Ministry of Health and Family Welfare, Directorate
General of Health Services, National Medical Library, Recruitment Rules, 2016, except as
respects things done or omitted to be done before such supersession, the President hereby
makes the following rules regulating the method of recruitment to the post of Library &
Information Officer in the Ministry of Health and Family welfare, Directorate General of
Health Services, National Medical Library, namely:-
1. Short title and commencement.- (1) These rules may be called the Ministry of Health
and Family Welfare, Directorate General of Health Services, National Medical Library,
Recruitment Rules, 2022. 7
|
(2) They shall come into force on the date of their publication in the official Gazette. |
2. Number of post, classification and pay band and grade pay or pay scale.- The number
of the said post, their classification and pay band and grade pay or pay scale attached thereto
shall be as specified in columns (2) to (4) of the said Schedule.
3. Method of recruitment, age limit, qualification, ete..- The method of recruitment, age
limit, qualifications and other matters relating thereto shall be as specified in columns (5) to
(13) of the aforesaid Schedule.
4, Disqualification. - No person, 4
a who has entered into or contracted a marriage with a person having a spouse living; or
b who, having a spouse living, has entered into or contracted a marriage with any
person; shall be eligible for appointment to the said posts:

Provided that Central Government may, if satisfied that such marriage is permissible
under the personal law applicable to such person and the other party to the marriage and that
there are other grounds for so doing, exempt any person from the operation of this rule.

5. Power to relax- Where the Central Government is of the opinion that it is necessary or
expedient so to do, it may, by order, for reasons to be recorded in writing and in consultation

<!-- page 3 -->

. with the Union Public Service Commission, relax any of the provisions of these rules with
respect to any class or category of persons.
6. Saving- Nothing in these rules shall affect reservation, relaxation of the age limit and other
concessions required to be provided for the Scheduled Castes, the Scheduled Tribes, Ex-
servicemen and other special categories of persons in accordance with the order issued by the
Central Government from time to time in this regard.

<!-- page 4 -->

SCHEDULErd
चल Number of Post. Classification. Pay band and grade | Whether Age limit for Educational and other
pay or pay scale. selection post | direct recruits. qualifications required
or non for
selection post. direct recruits
@ / GB) G6) (6) 0)

Library & | *01(2022) *Subject to variation | General Central Service, Group | Pay Matrix Level - 11 | Selection Not applicable Not applicable

Information Officer dependent on work load. “A? Gazetted Non-Ministerial. of Rs. 67700-208700

Whether age | Period of | Method of | In case of recruitment by promotion or deputation or absorption, grades from | If a Circumstances

and probation, | recruitment which promotion or deputation or absorption is to be made. Departmental in

educational if any whether by Promotion which एकांगा

qualifications direct Committee Public

prescribed for recruitment or exists, what is Service

direct recruits by promotion its composition Commission

shall apply in or by to be consulted

the case of deputation or in

promotes absorption and making
percentage recruitment.
of the vacancies
to be filled
by __ various
methods

a) (2) (3)

Not applicable | Two years Promotion, Promotion: Group *A* Departmental | Consultation
failing which by | Assistant Library and Information Officer in Level-7(Rs.44900-142400/-) of the Pay Promotion Committee | with the Union
deputation Matrix or equivalent with seven years of regular service in the grade and possessing (for considering | Public Service
(including Bachelor's Degree in Library Science or Library and Information Science from a promotion) consisting of | Commission is
short-term recognized university or institute and successful completed training of two weeks in the | 7 . necessary = on
contract) field of library and library science from an institute or organisation prescribed. (1) teen each occasion.

Note 1: When juniors who have completed their qualifying or eligibility service are Chairman. 5
being considered for promotion, their seniors would also be considered provided they | (2) Joint Secretary
are not short of the requisite qualifying or eligibility service by more than half of such (concemed),
qualifying or eligibility service or two years, whichever is less, and have successfully Ministry of Health
completed probation period area romotion to the next higher grade along with their and Family Welfare
juniors who have already compreted¥ich qualifying or eligibility service. ~Member.
Note 2: For the purpose of computing minimum qualifying service for promotion. the | G) Deputy Director
service rendered on a regular basis by an officer prior to 1* January, 2006 or the date General of Health
from which the revised pay structure based on the Sixth Central Pay Commission Services
recommendations has been extended. shall be deemed to be service rendered in the (concerned)

po | (__ tt i et _=Member, | ०7

<!-- page 5 -->

| ढ़
ह a | grade pay or pay scale extended based on the recommendations | (4) Director -
Commission. Administration
(concerned).
Deputation (including short term contract): Directorate General
Officers under the Central Government or State Government or Union territories of Health Services
or universities or recognized research institution or public sector undertakings or — Member
autonomous or statutory organizations :~
i. holding analogous posts on a regular basis in’ the __ parent
cadre/department: or
ii. with five years’ service in the grade rendered after appointment thereto on
a regular basis in Level — 10(Rs.56100-177500/-) of the Pay Matrix or
equivalent in the parent cadre or department: or
iii. with six years service in the grade rendered after appointment thereto on a
regular basis in Level — 8(Rs.47600-151100/-) of the Pay Matrix or equivalent
in the parent cadre or department; or
iv. with seven years service in the grade rendered after appointment thereto
on a regular basis in Level — 7(Rs.44900-142400/-) of the Pay Matrix or
equivalent in the parent cadre or department: and
(B) possessing following educational qualifications and experience:-
Essential:
1... Master's Degree in Library Science or Library and Information Science
from a recognized university or institute;
ii. five years professional experience in a library under Central Government or
State Government or, autonomous or statutory organisation or public sector
undertaking or university or recognized research institute or educational
institutes.
| Desirable:
i. One year experience of Computerizing library activities in a library
under Central or State Governments or — Union territories छा
universities or recognized research institutions ण public sector
मी na । सकल 2००५ esp asec undastakings/statutory or autonomous organizations: .
~ “ लए एन ii? “One year professional experience in indexing work of health services
literature:
| iii. Diploma in Computer Applications from a recognized university or institute. | | i
| Note te 1: The Departmental officers in the feeder category who are in direct line a | _ _

<!-- page 6 -->

.
?

If हु — : shall not be eligible for =i for appointment on deputation. at
Similarly, deputationist” shall not be eligible for consideration for appointment by
promotion.

Note 2: Period of deputation (including short-term contract) including the period of
deputation (including short-term contract) in another ex-cadre post held immediately
preceding this appointment in the same or some other organisation or department of the
Central Government shall ordinarily not to exceed four years. The maximum age limit
for appointment by deputation (including short-term contract) shall be not exceeding
fifty-six years as on the closing date of receipt of applications.

Note 3: For purposes of appointment on deputation(including short-term
contract) basis, the service rendered on a regular basis by an officer prior to 14
January, 2006 or the date
from which the revised pay structure based on the sixth Central Pay
Commission recommendations has been extended, shall be deemed to be service
rendered in the corresponding grade pay or pay scale extended based
‘on the recommendations of the Commission except where there has been
merger of more than one pre-revised scale of pay into one grade with a
common grade pay or pay scale, and where the benefit will extend only for the post(s)
for which that grade pay or pay scale is the normal replacement grade without any
upgradation
