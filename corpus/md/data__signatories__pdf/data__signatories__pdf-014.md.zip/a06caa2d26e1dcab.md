---
doc_id: "a06caa2d26e1dcab"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/09/f459e8b27f8a9fbf1c51e2f7a3ee35fb.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "OM regarding Work Allocation to Assistant Secretaries"
date: "2022-06-01"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "6db99844f7fe4974"
---

<!-- page 1 -->

F. No.27011/17/2022-Trg.(Asstt. Secy)
Government of India
Ministry of Personnel, Public Grievances and Pension
Department of Personnel & Training
Training Division
sete
Old JNU Campus, Block IV, 3" Floor,
New Mehrauli Road, New Delhi-110067
Dated: 10.05.2022
OFFICE MEMORANDUM

Subject: Posting of IAS officers of 2020 Batch as Assistant Secretaries in various

Ministries/Departments of Government of India — Work allocation — regarding
The IAS officers of 2020 batch will be deputed to various Ministries/Departments in
Government of India from 11" July 2022 to 7 October, 2022. The work allocation to

Assistant Secretaries during their deputation period may include the following activities:-

i. The Assistant Secretaries may give their inputs for improvement of flagship
programmes of various Ministries/Departments as per the priorities of the
Government which can be useful in implementation of schemes and programmes at
district level in States/UTs, quickly and effectively. This will be an individual
project work.

ii. Secretary of the Ministry/Department concerned will give a Project work pertaining to
the Ministry/Department which will be a Group Activity.

iii. | Assistant Secretaries have to review the implementation of projects/initiatives of
Assistant Secretaries of 2017 batch undertaken in 2019 and take them to a logical
conclusion. This will also be a Group activity for all Assistant Secretaries posted in
cach Ministry/Department.

2, It is requested that the Secretaries/Nodal Officers may take necessary action in this
regard well in time, before the Assistant Secretaries join their posting.
ies
51
(Rashi i Chowdharyy.
Additional Secretary to the G ent of India
To
All Secretaries of Government of India where Assistant Secretaries will be posted
(as per list attached)
Copy for information to:
1. SO to Cabinet Secretary, Rashtrapati Bhawan, New Delhi
2. EO& AS, DoP&T, North Block, New Delhi
3. PSO to Secretary (P), DoP&T, North Block, New Delhi
4. NIC, DoP&T, North Block, New Delhi
