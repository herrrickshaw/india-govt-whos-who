---
doc_id: "87228cce30caebec"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/6728312e45377b3aa197037ad81b021a.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Request for Proposal for Appointment of System Integrator for MHRD – SWAYAM MOOCS Project (Vol-1)"
date: "2015-11-21"
pages: 88
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5ff3fbf00af9ed33"
---

<!-- page 1 -->

Request for Proposal (RFP)
for
Appointment of System Integrator for
MHRD - SWAYAM MOOCs Project

Volume – 1

Ministry of Human Resource
Development
Government of India
Ref: No. 8-26/2014-TEL

21st November 2015

Ministry of Human Resource Development (MHRD)

Page 1 of 88

<!-- page 2 -->

Request for Proposal (RFP) Volume – 1

Table of Contents
Important Dates ............................................................................................................................................... 4
Invitation for Proposal .................................................................................................................................... 5
1

2

Introduction ............................................................................................................................................... 7
1.1

Introduction to MHRD........................................................................................................................ 7

1.2

Introduction to the SWAYAM Project ................................................................................................ 7

1.3

RFP Format....................................................................................................................................... 9

1.4

Fact Sheet ......................................................................................................................................... 9

1.5

Definitions/Acronyms ...................................................................................................................... 11

Instruction to Bidders ............................................................................................................................ 16
2.1

General ........................................................................................................................................... 16

2.2

Eligible Bidders ............................................................................................................................... 16

2.3

Bidder to inform ............................................................................................................................... 17

2.4

Compliant Proposals/Completeness of Response ......................................................................... 17

2.5

Proposal Preparation Costs ............................................................................................................ 18

2.6

Pre-Bid Meeting & Clarifications ..................................................................................................... 18
2.6.1

Bidders Queries ................................................................................................................. 18

2.6.2

Responses to Pre-Bid Queries and Issue of Corrigendum ................................................ 18

2.7

RFP Document Fee ........................................................................................................................ 19

2.8

Earnest Money Deposit (EMD) ....................................................................................................... 19

2.9

Bid Validity Period ........................................................................................................................... 19

2.10 Contents of Bid................................................................................................................................ 20
2.11 Bid Format....................................................................................................................................... 20
2.11.1 Pre-Qualification Bid Format .............................................................................................. 21
2.11.2 Technical Bid Format ......................................................................................................... 21
2.11.3 Commercial Bid Format ..................................................................................................... 24
2.12 Commercial Bid ............................................................................................................................... 24
2.13 Language ........................................................................................................................................ 24
2.14 Authentication of Bids ..................................................................................................................... 24
2.15 Amendment of Request for Proposal .............................................................................................. 25
2.16 Bid Price .......................................................................................................................................... 25
2.17 Deviations and Exclusions .............................................................................................................. 25
2.18 Total Responsibility ......................................................................................................................... 25
2.19 Late Bids ......................................................................................................................................... 25
2.20 Right to Terminate the Process ...................................................................................................... 26
2.21 Non-Conforming Proposals ............................................................................................................. 26
2.22 Acceptance/Rejection of Bids ......................................................................................................... 26
2.23 Confidentiality.................................................................................................................................. 27
2.24 Disqualification ................................................................................................................................ 27
2.25 Key Personnel ................................................................................................................................. 27
Ministry of Human Resource Development (MHRD)

Page 2 of 88

<!-- page 3 -->

Request for Proposal (RFP) Volume – 1

2.25.1 Initial Composition; Full Time Obligation; Continuity of Personnel .................................... 28
2.25.2 Evaluations ......................................................................................................................... 28
2.25.3 Replacement ...................................................................................................................... 28
2.25.4 High Attrition....................................................................................................................... 29
2.26 Fraud and Corrupt Practices ........................................................................................................... 29
2.27 Conflict of Interest ........................................................................................................................... 30
3

4

Selection Process for Bidder ................................................................................................................. 34
3.1

Opening of Bids ............................................................................................................................... 34

3.2

Preliminary Examination of Bids ..................................................................................................... 34

3.3

Clarification on Bids ........................................................................................................................ 35

3.4

Evaluation Process ......................................................................................................................... 35
3.4.1

Stage 1: Pre-Qualification .................................................................................................. 35

3.4.2

Stage 2: Technical Evaluation ........................................................................................... 35

3.4.3

Stage 3: Commercial Evaluation........................................................................................ 36

3.5

Pre-Qualification Criteria ................................................................................................................. 38

3.6

Technical Evaluation Framework .................................................................................................... 40
3.6.1

Consortium Member(s) Credentials ................................................................................... 40

3.6.2

Bidder’s Experience ........................................................................................................... 41

3.6.3

Proposed Solution .............................................................................................................. 43

3.6.4

Approach & Methodology................................................................................................... 43

3.6.5

Resource Planning ............................................................................................................. 45

3.6.6

Demonstration & Presentation ........................................................................................... 46

Award of Contract ................................................................................................................................... 48
4.1

Notification of Award ....................................................................................................................... 48

4.2

Signing of Contract.......................................................................................................................... 48

4.3

Performance Bank Guarantee (PBG) ............................................................................................. 48

4.4

Warranty & Maintenance ................................................................................................................ 49

4.5

Failure to agree with the Terms & Conditions of the RFP .............................................................. 50

5

Annexure 1 – Template for Pre-Bid Queries ........................................................................................ 52

6

Annexure 2 – Formats for Submission of the Pre-Qualification Bid ................................................. 53

7

6.1

Pre-Qualification Bid Covering Letter .............................................................................................. 53

6.2

Pre-Qualification Citations .............................................................................................................. 54

6.3

No Deviation Certificate .................................................................................................................. 55

6.4

Total Responsibility ......................................................................................................................... 56

Annexure 3 – Formats for Submission of the Technical Bid ............................................................. 57
7.1

Technical Bid Covering Letter ......................................................................................................... 57

7.2

Checklist .......................................................................................................................................... 58

7.3

Bidder’s General Information .......................................................................................................... 59

7.4

Bidder’s Experience - Client Citations............................................................................................. 61

7.5

Resource Deployment Plan ............................................................................................................ 62

7.6

Curriculum Vitae (CV) of Team Members ....................................................................................... 63

7.7

Project Plan ..................................................................................................................................... 64

Ministry of Human Resource Development (MHRD)

Page 3 of 88

<!-- page 4 -->

Request for Proposal (RFP) Volume – 1

8

7.8

Bill of Material (BOM) for the Solution............................................................................................. 65

7.9

Manufacturers'/Producers’ Authorization Form ............................................................................... 67

Annexure 4 – Formats for Submission of the Commercial Bid ......................................................... 69
8.1

Commercial Bid Covering Letter ..................................................................................................... 69

8.2

Total Cost of Ownership ................................................................................................................. 71

8.3

8.4

8.5

8.2.1

Total Cost of Ownership with taxes ................................................................................... 71

8.2.2

Total Cost of Ownership without taxes .............................................................................. 72

Capital Cost/One time cost ............................................................................................................. 73
8.3.1

Total Application Cost ........................................................................................................ 73

8.3.2

Cloud hosting and System Software Cost ......................................................................... 74

Operating Cost/Recurring cost ........................................................................................................ 78
8.4.1

Annual Support Cost for System Software ........................................................................ 78

8.4.2

Annual Support Cost for Applications ................................................................................ 81

8.4.3

Call Centre Cost ................................................................................................................. 82

8.4.4

Capacity Building Cost ....................................................................................................... 83

Additional Cost ................................................................................................................................ 83
8.5.1

9

Additional Manpower cost .................................................................................................. 84

Annexure 5 – Template for PBG ............................................................................................................ 85
9.1

Performance Bank Guarantee ........................................................................................................ 85

9.2

Bank Guarantee for Earnest Money Deposit .................................................................................. 87

Important Dates
Sr. No.

Activity

Date

1

Release of RFP

21.11.2015

2

Last date for receipt of queries on RFP

28.11.2015

3

Pre-bid Conference/Meeting

02.12.2015

4

Posting of responses to queries

04.12.2015

5

Last Date for submission of Bids & Opening
of Technical Bids

15.12.2015 and 18.12.2015

Ministry of Human Resource Development (MHRD)

Page 4 of 88

<!-- page 5 -->

Request for Proposal (RFP) Volume – 1

Invitation for Proposal
Date: 21.11.2015
Ministry of Human Resource Development, Government of India (hereinafter referred to as
MHRD), having its Corporate Office at Shastri Bhawan, Dr. Rajendra Prasad Road, New Delhi110001, invites responses (“Proposals”/“Bids”) to this Request for Proposal (“RFP”) from eligible
Bidders to be appointed as Service Provider for the SWAYAM Project.
Interested bidders are advised to study this RFP document carefully before submitting their
proposals in response to the RFP Document. Submission of a proposal in response to this RFP
shall be deemed to have been done after careful study and examination of this document with full
understanding of its terms, conditions and implications.
Interested bidders to download the RFP document from the website URL mentioned in the fact
sheet
Any subsequent corrigenda/clarifications will be made available on the website URL mentioned in
the fact sheet.
Proposals must be received not later than time, date and venue mentioned in the Fact Sheet.
Proposals that are received after the deadline WILL NOT be considered in this procurement
process. All documents that form a part of proposal response submitted by bidders, should be
uploaded on the eProcurement portal. No hard-copies should be sent to the department.
A firm will be selected under L1 method and procedures described in this RFP.
To obtain first-hand information on the assignment, Bidders are encouraged to attend a pre-bid
meeting. Attending the pre-bid meeting is optional.

Shri R Srinivasan
Director, Department of Higher Education
Ministry of Human Resource Development, Government of India
Room No. 205, C Wing, Shastri Bhawan, Dr. Rajendra Prasad Road,
New Delhi-110001
Email ID: rajusrini@hotmail.com
Phone number: 011 2307 0989

Ministry of Human Resource Development (MHRD)

Page 5 of 88

<!-- page 6 -->

Request for Proposal (RFP) Volume – 1

Section 1:
Introduction

Ministry of Human Resource Development (MHRD)

Page 6 of 88

<!-- page 7 -->

Request for Proposal (RFP) Volume – 1

1 Introduction
1.1

Introduction to MHRD

The essence of Human Resource Development is education, which plays a significant and
remedial role in balancing the socio-economic fabric of the Country. Education is recognized as
one of the critical elements of the national development effort and Higher education, in particular,
is of vital importance for the nation, as it is a powerful tool to build knowledge-based society of the
21st century. In pursuance of this mission, the Ministry of Human Resource Development (MHRD)
was created on September 26, 1985, through the 174th amendment to the Government of India
(Allocation of Business) Rules, 1961. Currently, the MHRD works through two departments:


Department of School Education & Literacy



Department of Higher Education

While the Department of School Education & Literacy is responsible for development of school
education and literacy in the country, the Department of Higher Education takes care of what is
one of the largest Higher Education systems of the world, just after the United States and China.
The activities of Department of Higher Education, in Ministry of Human Resource Development,
are focused towards developing India as a knowledge society. The Department’s constant
endeavour is to improve and expand education in all sectors, with a view to eliminate disparities in
access and lay greater emphasis on the improvement in the quality and relevance of education at
all levels. The role of Department, therefore, includes policy formulation, programme
implementation, coordination with other stakeholders, knowledge management, research and
innovation, creation of intellectual property, training and capacity building, reaching out to
disadvantaged sections, women and minorities, in the higher education sector.
Further the Technical Education plays a vital role in human resource development of the country
by creating skilled manpower, enhancing industrial productivity and improving the quality of life of
its people. Technical Education covers programmes in engineering, technology, management,
architecture, town planning, pharmacy, applied arts & crafts, hotel management and catering
technology.

1.2

Introduction to the SWAYAM Project

SWAYAM aims at creating a comprehensive and integrated system for enhancing the efficiency
and effective education at all levels and especially a transformational change in the mode,
pedagogy and style of learning for students.
SWAYAM (Study Webs of Active –Learning for Young Aspiring Minds) PROGRAMME was
conceptualized by the Ministry of Human Resource Development (MHRD) in detailed consultation
with all stakeholders, including the professors from Central universities, the State universities, the
Department of Information Technology (DIT), Government of India and the National Informatics
Centre (NIC) etc. It will be implemented as a “Mission Mode Project (MMP)” and will adopt the
guidelines of the National e-Governance Plan (NeGP).

Ministry of Human Resource Development (MHRD)

Page 7 of 88

<!-- page 8 -->

Request for Proposal (RFP) Volume – 1

MHRD envisages setting up a holistic MOOCs Platform to enable course takers to enroll for a
course online and for free of cost, giving increased focus on self-learning initiative as a key activity
for our aspiring youths to pursue the right career choice or the learning capabilities so that they
join the workforce with better skills for enhancing growth and development. Also the convenience
of studying online will provide more opportunities for remote students due to the reach and
accessibility of the online platform. SWAYAM is expected to have in excess of 2000 courses from
various streams of education disciplines.
The decision to design the web portal to establish a strong online presence providing an industry
best user experience to all the stakeholders like course takers, course providers in a single
platform and encourage and facilitate an open learning environment. The portal development will
adopt the principles of e-Governance, and creation of a nationwide networked infrastructure for
evolution of IT-enabled state-of-the-art system for students or course takers. The scope of
SWAYAM spans all the territory of India.
MHRD is planning to select a System Integrator (SI) through tendering process that would design,
develop, implement and maintain the SWAYAM for a period of three years after Go Live date.
With this background, SWAYAM has been conceptualized as a comprehensive, multi-pronged,
transformational project. Key aspects of this project include:
1. Collaborative multi-stakeholder platform.
2. Self-assisted pedagogy and learning methodologies.
3. National framework for education credit exchange based on certified curricula.
4. Helping students developed learning path for skill development.
5. Availability of pedagogy in multiple Indian languages.
6. Industry demand driven availability of the courses.
7. Ensuring a robust and inclusive governance mechanism.
Governance Structure: Considering the project complexity, a robust yet flexible project
governance structure is envisaged. For effective implementation and monitoring of SWAYAM,
MHRD will form a separate entity to oversee project operations and provide necessary approvals
Purpose of this RFP
Purpose of this RFP is to select a Service Provider for designing, developing, and maintaining the
SWAYAM portal. The requirements of the SWAYAM and the scope of work of the Bidder are
mentioned in RFP Vol. 2.

Ministry of Human Resource Development (MHRD)

Page 8 of 88

<!-- page 9 -->

Request for Proposal (RFP) Volume – 1

1.3

RFP Format

The intent of this RFP is to invite proposals from the Bidders for implementation of an integrated
solution for the MHRD.
The Request for Proposal (RFP) consists of three volumes viz.


RFP Volume 1: Structure of Proposal & Bid Process Specifications

Volume 1 details the instructions with respect to the bid process management, technical evaluation
framework, and the technical & financial forms.


RFP Volume 2: Scope of work including Functional & Technical Specifications

Volume 2 of the RFP provides information regarding the Project Implementation Plan, Business
requirements/applications to be covered and corresponding process related documentation, scope
of work for the selected bidder and functional requirements.


RFP Volume 3: Legal Specifications

Volume 3 contains the contractual, legal terms & conditions applicable for the proposed
engagement.

1.4

Fact Sheet

Item

Description

Method of Selection

The method of selection is L1. The Contract will be awarded to the
bidder having lowest Total Cost of Ownership for the Ministry (to be
calculated using Net Present Value, with a discount rate of 10%).
Prices exclusive of taxes will be considered for arriving at L1.

Availability of RFP
Documents

Download from Central eProcurement portal
http://www.eprocure.gov.in/

Date of RFP issuance

21.11.2015

Tender Document fee
(Non-Refundable and
Not Exempted)

INR 15,000 (INR Fifteen Thousand only) by DD in favour of Pay and
Account Officer (Education), payable at New Delhi

Bid Security/Earnest
Money Deposit (EMD)

INR 1,00,00,000 (INR One Crore only) by DD in favour of Pay and
Account Officer (Education), payable at New Delhi or by Bank
Guarantee (as per format attached in Section 9.2)
28.11.2015

Last date for
Submission of Pre-Bid
Queries

All the queries should be received on or before the prescribed date
& time, via email with a subject line as follows:
“Pre-Bid queries -<Bidder’s Name>”.
The queries should be submitted as per the format prescribed in
Section 5.
Email: rajusrini@hotmail.com

Ministry of Human Resource Development (MHRD)

Page 9 of 88

<!-- page 10 -->

Request for Proposal (RFP) Volume – 1

Item

Description

Pre-Bid Conference

Date & Time: 02.12.2015, 11 AM

Time, Date, & Venue

Venue: Conference room, C Wing, Shastri Bhawan

Posting of responses
to queries by MHRD
(on website)

04.12.2015

Last date and time for
Bid/Proposal
submission (on or
before)

15.12.2015, 2 PM

Date and time for
Opening of PreQualification Bids.

15.12.2015, 3 PM

Language

Proposals should be submitted in English only.

Bid Validity

Proposals must remain valid up to 180 (One Hundred & Eighty) days
from the actual date of submission of the Bid.

Currency

Currency in which the Bidders may quote the price and will receive
payment is INR only.
Shri R Srinivasan
Director, Department of Higher Education

Name and Address for
Communication,
seeking clarifications &
submission of
Proposal

Ministry of Human Resource Development, Government of India
Room No. 205, C Wing, Shastri Bhawan, Dr. Rajendra Prasad
Road,
New Delhi-110001
Email ID: rajusrini@hotmail.com
Phone number: 011 2307 0989

Ministry of Human Resource Development (MHRD)

Page 10 of 88

<!-- page 11 -->

Request for Proposal (RFP) Volume – 1

1.5

Definitions/Acronyms

S. No.
1.

Term

Definition

Additional
Cost

Additional Cost is the cost asked by MHRD for any resources
which might be utilized by MHRD project.
The utilization of the cost during the project is the sole discretion of
MHRD but the cost will be used for evaluation purpose.

2.

Adverse
Effect

Material adverse effect on
a) the ability of the Bidder to exercise any of its rights or
perform/discharge any of its duties/obligations under and in
accordance with the provisions of the Agreement for this RFP
and/or
b) the legal validity, binding nature or enforceability of Agreement
for this RFP

3.

Agreement

Master Services Agreement, Service Level Agreement and NonDisclosure Agreement together with all Articles, Annexure,
Schedules and the contents and specifications of the RFP

4.

Applicable
Law(s)

Any statute, law, ordinance, notification, rule, regulation, judgment,
order, decree, bye-law, approval, directive, guideline, policy,
requirement or other governmental restriction or any similar form
of decision applicable to the relevant party and as may be in effect
on the date of the execution of this Agreement and during the
subsistence thereof, applicable to the Project

5.

ATS

Annual Technical Support

6.

Bidder

The use of the term “Bidder” in the RFP means the Single Service
Provider or the consortium of firms.

7.

Bid/Proposal

Offer by the Bidder to fulfil the requirement of the MHRD for an
agreed price. It shall be a comprehensive technical and commercial
response to the RFP

8.

BOM

Bill of Materials

9.

Business
critical
services GoLive

As defined in RFP Vol 2

10.

Capital Cost

Capital Cost is the cost incurred by MHRD before the Go-Live of
the SWAYAM Portal.

Ministry of Human Resource Development (MHRD)

Page 11 of 88

<!-- page 12 -->

Request for Proposal (RFP) Volume – 1

S. No.
11.

Term

Definition

Confidential
Information

All information including MHRD Data (whether in written, oral,
electronic or other format) which relates to the technical, financial
and business affairs, dealers, suppliers, products, developments,
operations, processes, data, trade secrets, design rights, knowhow, plans, budgets and personnel of each Party and its affiliates
which is disclosed to or otherwise learned by the other Party in the
course of or in connection with this Agreement (including without
limitation such information received during negotiations, location
visits and meetings in connection with this Agreement);

12.

Consortium

The consortium consist of multiple members (not more than 3
parties) entering into a Consortium Agreement for a common
objective of satisfying the MHRD requirements & represented by
Lead member of the consortium

13.

Control

In relation to any business entity, the power of a person to secure
a) by means of the holding of shares or the possession of voting
power in or in relation to that or any other business entity, or
b) by virtue of any powers conferred by the articles of association
or other document regulating that or any other business entity,
that the affairs of the first mentioned business entity are
conducted in accordance with that person’s wishes and in
relation to a partnership, means the right to a share of more
than one half of the assets, or of more than one half of the
income, of the partnership;

14.

Deliverables

Products, infrastructure and services agreed to be delivered by the
Bidder in pursuance of the agreement as defined more elaborately
in the RFP, Implementation and the Maintenance phases and
includes all documents related to the user manual, technical
manual, design, process and operating manuals, service
mechanisms, policies and guidelines (such as security related,
data migration related), inter alia payment and/or process related
etc., source code and all its modifications;

15.

Effective
Date

The date on which the Agreement for this RFP comes into effect;

16.

EMI

Equated Monthly Instalment

17.

EMD

Earnest Money Deposit

18.

FTE

Full Time Equivalent

19.

GoI

Government of India

Ministry of Human Resource Development (MHRD)

Page 12 of 88

<!-- page 13 -->

Request for Proposal (RFP) Volume – 1

S. No.
20.

Term
Insurance
Cover

Definition
a) Public liability insurance for an insured amount of [INR insert
amount] per occurrence and not less than [INR insert amount] in
aggregate
b) Either professional indemnity or errors and omissions insurance
for an insured amount of [INR insert amount] per occurrence and
not less than [INR insert amount] in aggregate.
c) Product liability for an insured amount of [INR insert amount] per
occurrence and not less than [INR insert amount] in aggregate.
d) Workers compensation as required by law

21.

Integrated
Solution

Software product & services required to satisfy the MHRD
requirements

22.

Intellectual
Property
Rights

All rights in written designs and copyrights, moral rights, rights in
databases Pre-existing work including its up-gradation systems and
compilation rights (whether or not any of these are registered and
including application for registration);

23.

LOI

Letter of Intent

24.

LOA

Letter of Agreement

25.

Material
Breach

A breach by either Party (MHRD or Bidder) of any of its obligations
under this Agreement which has or is likely to have an Adverse
Effect on the Project which such Party shall have failed to cure;

26.

MHRD

Ministry of Human Resource Development

27.

MOOC

Massive Open Online Courses

28.

Month/Week

The Month shall mean calendar month & Week shall mean calendar
week

29.

NDA

Non-Disclosure Agreement

30.

OEM

Original Equipment Manufacturer

31.

Operating
Cost

Operating Cost is the cost incurred by MHRD after the Go-Live of
the Quarterly/Monthly basis.

32.

Parties

MHRD and Bidder for the purposes of this Agreement and “Party”
shall be interpreted accordingly;

33.

Performance
Guarantee
(PBG)

Guarantee provided by a Nationalized Bank in favour of the
Bidder. (Performance Bank Guarantee)

34.

PO

Purchase Order

35.

Project

Project Implementation and Operations and Maintenance in terms
of the Agreement;

Ministry of Human Resource Development (MHRD)

Page 13 of 88

<!-- page 14 -->

Request for Proposal (RFP) Volume – 1

S. No.
36.

Term

Definition

Project
Implementati
on

Project Implementation as per the testing standards and
acceptance criteria prescribed by MHRD or its nominated
agencies;

37.

Replacement
Bidder

Any third party that MHRD or its nominated agencies appoint to
replace Bidder upon expiry of the Term or termination of this
Agreement to undertake the Services or part thereof;

38.

Request for
Proposal
(RFP)/Tender
Document

Written solicitation that conveys to the Bidder, requirements for
products/services that the MHRD intends to buy and implement

39.

Required
Consents

The consents, waivers, clearances and licenses to use MHRD
Intellectual Property Rights, rights and other authorizations as may
be required to be obtained for the software and other items that
MHRD or their nominated agencies are required to make available
to Bidder pursuant to this Agreement;

40.

Service Level The level of service and other performance criteria which will apply
to the Services delivered by the Bidder;

41.

SLA

Performance and Maintenance SLA executed as part of this
Master Service Agreement;

42.

Software

Software designed, developed/customized, tested and deployed
by the Bidder for the purposes of the Project and includes the
source code along with associated documentation, which is the
work product of the development efforts involved in the Project
and the improvements and enhancements effected during the term
of the Project, but does not include the third party software
products (including the COTS products used for the product),
proprietary software components and tools deployed by the
Bidder;

43.

SP/SI/SDA

Service Provider or System Implementer or Software Development
Agency, used interchangeably

44.

Successful
Bidder

The bidder who is qualified & successful in the bidding process and is
given the award of Work.

45.

SWAYAM

Study Webs of Active –Learning for Young Aspiring Minds

46.

Third Party
Systems

Systems (or any part thereof) in which the Intellectual Property
Rights are not owned by Bidder and to which Bidder has been
granted a license to use and which are used in the provision of
Services;

47.

UAT

User Acceptance Testing

Ministry of Human Resource Development (MHRD)

Page 14 of 88

<!-- page 15 -->

Request for Proposal (RFP) Volume – 1

Section 2:
Instruction to Bidders

Ministry of Human Resource Development (MHRD)

Page 15 of 88

<!-- page 16 -->

Request for Proposal (RFP) Volume – 1

2 Instruction to Bidders
2.1

General

a) While every effort has been made to provide comprehensive and accurate background
information and requirements and specifications, Bidders must form their own conclusions
about the solution needed to meet the requirements. Bidders and recipients of this RFP may
wish to consult their own legal advisers in relation to this RFP.
b) All information supplied by Bidders may be treated as contractually binding on the Bidders, on
successful award of the assignment by the MHRD on the basis of this RFP
c) No commitment of any kind, contractual or otherwise shall exist unless and until a formal
written contract has been executed by or on behalf of MHRD. Any notification of preferred
bidder status by MHRD shall not give rise to any enforceable rights by the Bidder. MHRD may
cancel this public procurement at any time prior to a formal written contract being executed by
or on behalf of MHRD.
d) This RFP supersedes and replaces any previous public documentation & communications, and
Bidders should place no reliance on such communications.

2.2

Eligible Bidders

Bids may be submitted by either of the following categories of bidders only:
The Bidder can be either a Single System Implementer (SI) or a Consortium of
companies/corporations as described below.
Sole Bidder
The Sole Bidder must be a System Integrator company which has the capabilities to deliver the
entire scope as mentioned in the RFP. The Sole Bidder cannot be a part of any consortium for this
RFP.
Consortium of Firms
Bids can be submitted by a consortium of firms. A consortium should not consist of more than
three parties. One of the Firms would be designated as a "Lead Bidder". The Lead Bidder would
have the sole responsibility of ensuring the delivery of products and services mentioned in all
volumes of this RFP. The Lead Bidder would also be responsible for ensuring the successful
execution of integrated solution including meeting the SLAs. The list of Consortium Members
needs to be declared in the bid which cannot be changed by the bidder later on. Any change in the
consortium will lead to disqualification of the Consortium.
The Lead Bidder will be responsible for:
a) The management of all Consortium Members who are part of the proposal and for the delivery
of all products and services in accordance with the contracts; and
b) The supply, delivery and installation of all products and services submitted in their proposal.
c) Operating and maintaining the SWAYAM for the time mentioned in the RFP.
Ministry of Human Resource Development (MHRD)

Page 16 of 88

<!-- page 17 -->

Request for Proposal (RFP) Volume – 1

Bids submitted by a consortium should comply with the following requirements also:
a) The Lead Bidder shall be authorized to incur liabilities and receive instructions for and on
behalf of any and all consortium members, and the entire execution of the Contract, including
payment, shall be done exclusively with the Lead Bidder;
b) If an application OEM is bidding against the RFP as a Lead Bidder, then another bidder cannot
propose the product of that application OEM.
c) If the application OEM is not bidding against the RFP as a Lead Bidder, then any number of
bidders can propose the product of that application OEM.
d) Any firm which is not a Lead Bidder to this RFP can be a partner in any number of bids
submitted against this RFP.
e) Any of the Lead Bidder cannot also be a Consortium Member with another bidder
f)

Internal arrangement between the Consortium members is left to the bidders. It is the
responsibility of the lead Bidder to ensure that all the other Consortium Members in the bid are
compliant to all the clauses as mentioned in the bid, failing which bid can be disqualified.

2.3

Bidder to inform

The Bidder shall be deemed to have carefully examined the Terms & Conditions, Scope, Service
Levels, Specifications, and Schedules of this RFP. If bidder shall have any doubt as to the
meaning of any portion of these Conditions or of the specifications he shall, before the last date for
Submission of Pre-Bid Queries, set forth the particulars thereof, and submit them to MHRD in
writing in order that such doubt may be removed.

2.4

Compliant Proposals/Completeness of Response

a) Bidders are advised to study all instructions, forms, terms, requirements and other information
in the RFP documents carefully. Submission of the bid shall be deemed to have been done
after careful study and examination of the RFP document with full understanding of its
implications.
b) Failure to comply with the requirements of this paragraph may render the Proposal noncompliant and the Proposal may be rejected. Bidders must:
i. Include all documentation specified in this RFP;
ii. Follow the format of this RFP and respond to each element in the order as set out in this
RFP
iii. Comply with all requirements as set out within this RFP.

Ministry of Human Resource Development (MHRD)

Page 17 of 88

<!-- page 18 -->

Request for Proposal (RFP) Volume – 1

2.5

Proposal Preparation Costs

The Bidder shall be responsible for all costs incurred in connection with participation in the RFP
process, including, but not limited to, costs incurred in conduct of informative and other diligence
activities, participation in meetings/discussions/presentations, preparation of proposal, in providing
any additional information required by MHRD facilitate the evaluation process, and in negotiating a
definitive contract or all such activities related to the bid process.
MHRD will in no case be responsible or liable for those costs, regardless of the conduct or
outcome of the bidding process.

2.6

Pre-Bid Meeting & Clarifications

2.6.1 Bidders Queries
Any clarification regarding the RFP document and any other item related to this project can be
submitted to MHRD as per the submission mode and timelines mentioned in the Fact Sheet. It is
necessary that the pre-bid queries should be limited to maximum of 50 distinct queries, and must
be submitted in excel sheet format, along with name and details of the organisation submitting the
queries.
MHRD shall not be responsible for ensuring that the bidders’ queries have been received by them.
Any requests for clarifications post the indicated date and time shall not be entertained by MHRD.
Further MHRD will reserve the right to issue clarifications.
Bidders must submit their queries as per the format mentioned in Section 5

2.6.2 Responses to Pre-Bid Queries and Issue of Corrigendum
MHRD will organize a pre-bid conference and will respond to any request for clarification or
modification of the bidding documents. MHRD will formally respond to the pre-bid queries after the
pre-bid conference. No clarification will be entertained after the pre-bid conference.
MHRD will endeavour to provide timely response to all queries. However, MHRD makes no
representation or warranty as to the completeness or accuracy of any response made in good
faith, nor does MHRD undertake to answer all the queries that have been posed by the bidders.
Any modifications of the Bidding Documents, which may become necessary as a result of the PreBid Conference, shall be made by MHRD exclusively through a corrigendum. Any such
corrigendum shall be deemed to be incorporated into this RFP. However, in case of any such
amendment, the bid submission date may be extended at the discretion of MHRD.
Any corrigendum/notification issued by MHRD, subsequent to issue of RFP, shall only be
available/hosted on the website URL mentioned in the fact sheet. Any such corrigendum shall be
deemed to be incorporated into this RFP.

Ministry of Human Resource Development (MHRD)

Page 18 of 88

<!-- page 19 -->

Request for Proposal (RFP) Volume – 1

2.7

RFP Document Fee

RFP can be downloaded from the website URL mentioned in the fact sheet.
Bidders are required to submit the RFP Document Fee (Non-Refundable and Not Exempted) as
per the details mentioned in the fact sheet, along with the Proposal.
Proposals received without RFP Document Fee or with inadequate RFP Document fees shall be
rejected.

2.8

Earnest Money Deposit (EMD)

Bidders shall submit, along with their Bids, Bid Security (EMD) as per the details mentioned in the
fact sheet. Bid security in any other form will not be entertained.
For Unsuccessful bidders: The bid security of all unsuccessful bidders would be refunded without
interest by MHRD on finalization of the bid in all respects by the successful bidder.
For Successful bidders: The bid security, for the amount mentioned above, of successful bidder
would be returned without interest upon submission of Performance Bank Guarantee by the
successful bidder.
The above mentioned refund would be completed within 3 months of the release of the RFP
In case bid is submitted without the bid security then MHRD reserves the right to reject the bid
without providing opportunity for any further correspondence to the bidder concerned.
The EMD may be forfeited in any of the following circumstances:
a) If a bidder withdraws its bid during the period of bid validity.
b) In case of a successful bidder, if the bidder fails to sign the contract in accordance with
this RFP.

2.9

Bid Validity Period

Bid shall remain valid for the time mentioned in the Fact Sheet.
On completion of the validity period, unless the Bidder withdraws his bid in writing, it will be
deemed to be valid until such time that the Bidder formally (in writing) withdraws his bid.

Ministry of Human Resource Development (MHRD)

Page 19 of 88

<!-- page 20 -->

Request for Proposal (RFP) Volume – 1

2.10 Contents of Bid
The bidder shall submit the following documents.
Document
Set

Marked As

Content of Set

One

RFP Document fee &
Bid Security/Earnest
Money Deposit (EMD)

a)
b)
c)
d)

Pre-Qualification
bid/proposal

a) Pre-Qualification bid/Proposal as per Section 6.1
and 6.2 along with the required supporting
documents.
b) No Deviation Certificate as per Section 6.3
c) Total Responsibility declaration as per Section
6.4

Three

Technical bid/proposal

a) Technical Bid/Proposal
b) Response to FRS & TRS
c) Masked Commercial bid

Four

Commercial
bid/proposal

Commercial Bid/Proposal

Two

RFP Document Fee
Bid Security/Earnest Money Deposit (EMD)
Signed RFP Document
Signed RFP corrigendum, if any

All documents must be uploaded on the EProcurement portal.
Please note that Prices should not be indicated in the Pre-Qualification Bid or Technical Bid but
should only be indicated in the Commercial Bid.
All the pages of the bid must be sequentially numbered and must contain the list of contents with
page numbers. Any deficiency in the documentation may result in the rejection of the Bid.
The original proposal/bid shall be prepared in indelible ink. It shall contain no interlineations or
overwriting, except as necessary to correct errors made by the bidder itself. Any such corrections
must be initialled by the person (or persons) who sign(s) the proposals.
All pages of the bid shall be initialled and stamped by the person or persons who sign the bid.
Failure to submit bid on time could cause a proposal to be rejected.
MHRD will not accept delivery of bid by fax, e-mail or in person.

2.11 Bid Format
Bidder shall submit their bids in the format mentioned in the following sub-sections. Bids not in the
prescribed formats will be liable for rejection.

Ministry of Human Resource Development (MHRD)

Page 20 of 88

<!-- page 21 -->

Request for Proposal (RFP) Volume – 1

2.11.1 Pre-Qualification Bid Format
Section No.

Section Heading

Details

Section 1

Pre-Qualification Bid
Covering Letter

As per format provided in Section 6.1

Section 2

Pre-Qualification
Criteria

Pre-Qualification criteria table as mentioned in Section
3.5 with response and reference against each criteria

Section 3

Consortium
Agreement

Copy of the Consortium Agreement with clear roles &
responsibilities (only in case of a consortium)

Section 4

Legal Entity

Copy of Certificate of Incorporation
Copy of Registration Certificates

Section 5

Sales Turnover

Details of turnover with Documentary Evidence

Section 6

Profitability

Details of profitability with Documentary Evidence

Section 7

Experience in
Education/eLearning
related Services

Citation detail as per format provided in Section 6.2 with
Documentary Evidence

Section 8

Experience in
development and
maintenance of
Portal

Citation detail as per format provided in Section 6.2 with
Documentary Evidence

Section 9

Experience in
development and
maintenance of
Contact Centre

Citation detail as per format provided in Section 6.2 with
Documentary Evidence

Section 10

CMMi certificate

Valid CMMi certificate

Section 11

Self-certificate for
non-blacklisting
clause

Documentary Evidence

Section 12

Power of Attorney

Special written power of attorney on a stamp paper
authorizing the representative of the bid to sign the bid
against this RFP

Section 13

No Deviation
Certificate

As per format provided in Section 6.3

Section 14

Total Responsibility
Certificate

As per format provided in Section 6.4

2.11.2 Technical Bid Format
Section No.

Section Heading

Details

Section 1

Technical Bid Covering Letter

As per format provided in Section 7.1

Section 2

Checklist

As per format provided in Section 7.2

Ministry of Human Resource Development (MHRD)

Page 21 of 88

<!-- page 22 -->

Request for Proposal (RFP) Volume – 1

Section No.

Section Heading

Details


Details about bidder (whether solo or
consortium)
Bidder’s General Information as per format
provided in Section 7.3

Section 3

About Bidder



Section 4

Understanding of MHRD
business and Scope of Work

Understanding of MHRD business and Scope
of Work



Section 5

Proposed Solution Solution/Product Experience




Envisaged Solution Architecture
Approach for addressing scalability,
performance, availability and security etc.
Bill of Material as per format provided in
Section 7.8
Solution/Product Experience

(Bidder can include more sub-sections as
seems relevant/fit)

Section 6

Approach and Methodology







Methodology adopted
Project Implementation Approach
Integration Approach
Approach for ensuring SLA compliance
Project Plan as per format provided in
Section 7.7

(Bidder can include more sub-sections as
seems relevant/fit)

Ministry of Human Resource Development (MHRD)

Page 22 of 88

<!-- page 23 -->

Request for Proposal (RFP) Volume – 1

Section No.

Section Heading

Details
Experience in development and maintenance
of eLearning/MOOC Portal
 Citation 1/2/3 and so on as per format
provided in Section 7.4
Experience in development and maintenance
of large scale Portals in India
 Citation 1/2/3 and so on as per format
provided in Section 7.4

Section 7

Bidder’s Experience

Experience in Government/PSU
 Citation 1/2/3 and so on as per format
provided in Section 7.4
Experience in development and maintenance
of Contact Centre
 Citation 1/2/3 and so on as per format
provided in Section 7.4
Experience in Business Intelligence/Analytics
 Citation 1/2/3 and so on as per format
provided in Section 7.4

Section 8

Project Governance





Governance structure
Resource Deployment Plan as per format
provided in Section 7.5
CVs as per format provided in Section 7.6

Consortium Member 1
 Documentary Evidence for turnover
 Documentary Evidence for net worth
 Certificate of Incorporation
Annexure I

Consortium Member’s Financial
Documents

Consortium Member 2
 Documentary Evidence for turnover
 Documentary Evidence for net worth
 Certificate of Incorporation
(For all consortium members)

Annexure II

Documentary Evidence for
Solution/Product Experience

Annexure III

Documentary Evidence for
Bidder’s experience

Annexure IV

Manufacturers’/Producers’
Authorization Form

As per format provided in Section 7.9

Annexure VI

Masked Commercial Bid

Masked Commercial Bid as per formats
provided in Section 8 and its sub sections

Ministry of Human Resource Development (MHRD)

Page 23 of 88

<!-- page 24 -->

Request for Proposal (RFP) Volume – 1

2.11.3 Commercial Bid Format
Section No.

Section Heading

Details

Section 1

Commercial Bid Covering Letter

As per format provided in Section 8.1

Section 2

Total Cost of Ownership (TCO)

Total Cost of Ownership (TCO) form as per
format provided in Section 8.2

Section 3

Capital Cost

Capital Cost form as per format provided in
Section 8.3 along with all the related
forms/tables

Section 4

Operating Cost

Operating Cost form as per format provided in
Section 8.4 along with all the related
forms/tables

Section 5

Additional Cost

Additional Cost form as per format provided in
Section 8.5 along with all the related
forms/tables

2.12 Commercial Bid
The Bidder must submit the Commercial Bid is the formats specified in Section 8.
Commercial Bids that are less than 30% of the average bid price (excluding all applicable taxes)
will be disqualified (the average bid price is computed by adding all Financial Bid values of ALL the
qualified bidders and dividing the same by the number of bidders).
Capital cost components of price quoted for this proposal should not exceed 40% of total price
quoted (excluding all applicable taxes).

2.13 Language
The Proposal should be filled by the bidders in English language only. If any supporting
documents submitted are in any language other than English, translation of the same in English
language is to be duly attested by the Bidders. For purposes of interpretation of the documents,
the English translation shall govern.

2.14 Authentication of Bids
An authorized representative of the Bidder shall initial all pages of the Pre-Qualification, Technical
and Commercial Bids.
Bid should be accompanied by an authorization in the name of the signatory of the Bid. The
authorization shall be in the form of a written power of attorney accompanying the Bid or in any
other form demonstrating that the representative has been duly authorized to sign.

Ministry of Human Resource Development (MHRD)

Page 24 of 88

<!-- page 25 -->

Request for Proposal (RFP) Volume – 1

2.15 Amendment of Request for Proposal
At any time prior to the deadline for submission of proposals, MHRD, for any reason, may modify
the RFP by amendment notified in writing or by fax or email to all bidders who have received this
RFP and such amendment shall be binding on them. MHRD, at its discretion, may extend the
deadline for the submission of proposals.
MHRD may change the scope after the submission of technical bids by the Bidders. In this case,
MHRD will release a corrigendum/clarification and ask the Bidders to resubmit their commercial
bids.

2.16 Bid Price
Commercial Bid shall be as per the format provided in Section 8. Bidders shall give the required
details of all applicable taxes, duties, other levies and charges etc. in respect of direct transaction
between MHRD and the Bidder.
Bidders shall quote for the entire scope of contract on a “overall responsibility” basis such that the
total bid price covers all the Bidder’s obligations mentioned in or to be reasonably inferred from the
bidding documents in respect of providing the product/services.
Prices quoted by the Bidder shall remain firm during the entire contract period and not subject to
variation on any account. A bid submitted with an adjustable price quotation will be treated as nonresponsive and rejected.

2.17 Deviations and Exclusions
Bids shall be submitted strictly in accordance with the requirements and terms & conditions of the
RFP. The Bidder shall submit a No Deviation Certificate as per the format mentioned in Section
6.3. The bids with deviation(s) are liable for rejection.

2.18 Total Responsibility
Bidder should issue a statement undertaking total responsibility for the defect free operation of the
proposed solution as per the format mentioned in Section 6.4.

2.19 Late Bids
Bids received after the due date and the specified time (including the extended period if any) for
any reason whatsoever, shall not be entertained and shall be returned unopened.
The bids submitted by telex/telegram/fax/e-mail etc. shall not be considered. No correspondence
will be entertained on this matter.
MHRD shall not be responsible for any postal delay or non-receipt/non-delivery of the documents.
No further correspondence on the subject will be entertained.
MHRD reserves the right to modify and amend any of the above-stipulated condition/criterion
depending upon project priorities vis-à-vis urgent commitments.

Ministry of Human Resource Development (MHRD)

Page 25 of 88

<!-- page 26 -->

Request for Proposal (RFP) Volume – 1

2.20 Right to Terminate the Process
MHRD may terminate the RFP process at any time and without assigning any reason. MHRD
makes no commitments, express or implied, that this process will result in a business transaction
with anyone. This RFP does not constitute an offer by MHRD. The bidder's participation in this
process may result MHRD selecting the bidder to engage towards execution of the contract.

2.21 Non-Conforming Proposals
A proposal may be construed as a non-conforming proposal and ineligible for consideration
a)

If it does not comply with the requirements of this RFP.

b)

If a proposal appears to be “canned” presentations of promotional materials that do not follow
the format requested in this RFP or do not appear to address the particular requirements of
the solution, any such bidders may also be disqualified.

2.22 Acceptance/Rejection of Bids
MHRD reserves the right to reject in full or part, any or all bids without assigning any reason
thereof. MHRD reserves the right to assess the Bidder’s capabilities and capacity. The decision of
MHRD shall be final and binding.
Bid should be free of over writing. All erasures, correction or addition must be clearly written both
in words and figures and attested.
Offers not submitted in prescribed manner or submitted after due date and time are liable to
rejection.
Both delayed as well as late bids are liable for rejection. Hence, offers reaching within the due date
& time in the bid box only will be accepted.
In the event of any assumptions, presumptions, key points of discussion, recommendation or any
points of similar nature submitted along with the Bid, MHRD reserves the right to reject the Bid and
forfeit the EMD.
If there is any discrepancy in the commercial bid, it will be dealt as per the following:
a) If, in the price structure quoted for the required goods/services/works, there is discrepancy
between the unit price and total price (which is obtained by multiplying the unit price by the
quantity), the unit price shall prevail and the total price corrected accordingly.
b) If there is an error in a total corresponding to the addition or subtraction of subtotals, the
subtotals shall prevail and the total shall be corrected.
c) If there is a discrepancy between words and figures, the amount in words shall prevail.
d) If there is such discrepancy in an offer, the same shall be conveyed to the bidder with target
date up to which the bidder has to send his acceptance on the above lines and if the bidder
does not agree to the decision of MHRD, the bid is liable to be ignored.
If the Lead Bidder does not meet even one of the Pre-Qualification criteria separately mentioned in
Section 0, the Bidder shall be disqualified & the entire Bid shall be rejected.
Ministry of Human Resource Development (MHRD)

Page 26 of 88

<!-- page 27 -->

Request for Proposal (RFP) Volume – 1

2.23 Confidentiality
All the material/information sent to the Bidder shall be treated as confidential and should not be
disclosed in any manner to any unauthorized person under any circumstances. The employees of
the successful Lead bidder and Consortium members who were deployed on the project have to
furnish a Non-Disclosure Agreement (NDA) as per RFP Vol 3.

2.24 Disqualification
The proposal is liable to be disqualified in the following cases or in case bidder fails to meet the
bidding requirements as indicated in this RFP:
a) Proposal not submitted in accordance with the procedure and formats prescribed in this
document or treated as non-conforming proposal.
b) During validity of the proposal, or its extended period, if any, the bidder increases its quoted
prices.
c) The bidder’s proposal is conditional and has deviations from the terms and conditions of RFP.
d) Proposal is received in incomplete form.
e) Proposal is received after due date and time.
f)

Proposal is not accompanied by all the requisite documents.

g) Information submitted in technical bid is found to be misrepresented, incorrect or false,
accidentally, unwittingly or otherwise, at any time during the processing of the contract (no
matter at what stage) or during the tenure of the contract including the extension period if any.
h) Financial bid is enclosed with the same document as technical bid.
i)

Bidder tries to influence the proposal evaluation process by unlawful/corrupt/fraudulent means
at any point of time during the bid process.

j)

In case any one party submits multiple proposals or if common interests are found in two or
more bidders, the bidders are likely to be disqualified, unless additional proposals/bidders are
withdrawn upon notice immediately.

k) If any of the Lead Partner is also partner in any other bid, then all the affected bids will be
disqualified
l)

If an application OEM is bidding as Lead Partner and the product of that OEM is also proposed
in some other bid (s), then all the affected bids will be disqualified

2.25 Key Personnel
MHRD has identified certain key positions and minimum qualifications for each of these positions
that should be part of project team of the bidder (hereby referred to as “key personnel”). Details of
these key positions are provided in Section 3.6.5.

Ministry of Human Resource Development (MHRD)

Page 27 of 88

<!-- page 28 -->

Request for Proposal (RFP) Volume – 1

2.25.1 Initial Composition; Full Time Obligation; Continuity of Personnel
Bidder shall ensure that each member of the Key Personnel devotes substantial working time to
perform the services to which that person has been assigned as per the proposal.
Bidder shall not make any changes to the composition of the Key Personnel and not require or
request any member of the Key Personnel to cease or reduce his or her involvement in the
provision of the Services during the Term:
i.

unless that person resigns, is terminated for cause, dies, is long-term disabled, is on
permitted mandatory leave under Applicable Law or retires; or

ii.

without MHRD's prior written consent

2.25.2 Evaluations
Bidder shall carry out an evaluation of the performance of each member of the Key Personnel in
connection with the Services at least once in each Contract Year. Bidder shall provide reasonable
written notice to MHRD of the date of each evaluation of each member of the Key Personnel and
MHRD shall be entitled to provide Bidder with input for each such evaluation. Bidder shall promptly
provide the results of each evaluation to MHRD, subject to Applicable Law.

2.25.3 Replacement
In case the resource has resigned then the Bidder has to inform MHRD within one week of such
resignation.
Bidder shall promptly initiate a search for a replacement to ensure that the role of any member of
the Key Personnel is not vacant at any point in time during the contract period, subject to
reasonable extensions requested by Bidder of MHRD.
Before assigning any replacement member of the Key Personnel to the provision of the Services,
Bidder shall provide MHRD with:
i.

a resume, curriculum vitae and any other information about the candidate that is reasonably
requested by MHRD ; and

ii.

an opportunity to interview the candidate.

The bidder has to provide replacement resource of equal or better qualification and experience.
If MHRD objects to the appointment, Bidder shall not assign the individual to that position and shall
seek an alternative candidate in accordance with this Section.
The bidder has to ensure at least 4 weeks of overlap period in such replacements. MHRD will not
be responsible for any knowledge transition to the replacement resource and any
impact/escalation of cost because of replacement has to be incurred by the Bidder only.

Ministry of Human Resource Development (MHRD)

Page 28 of 88

<!-- page 29 -->

Request for Proposal (RFP) Volume – 1

2.25.4 High Attrition
If in the first 6 month period from the Contract Effective Date or in any rolling 12 months period
during the Term, 15 percent or more of the members of the Key Personnel cease or reduce their
involvement in the Services for any reason other than with MHRD prior written consent, Bidder
shall:
i.

provide MHRD with a reasonably detailed explanation as to the reasons for such change,
including, where applicable and permitted, notes from any exit interviews conducted by
Bidder with any departing member of the Key Personnel; and

ii.

if such change to Key Personnel has or is likely to have any material adverse impact on the
provision of the Services or any substantial part thereof, undertake, at its own costs, such
remediation acts as are reasonably necessary in order to improve the retention of the Key
Personnel including making reasonable changes to the human resources policies and
procedures applicable to the Key Personnel (including those related to compensation,
benefits and other conditions so that they are competitive with the market) as may be
necessary to ensure that such policies and procedures comply with Good Industry Practice.

2.26 Fraud and Corrupt Practices
a) The Bidders and their respective officers, employees, agents and advisers shall observe the
highest standard of ethics during the Selection Process. Notwithstanding anything to the
contrary contained in this RFP, MHRD shall reject a Proposal without being liable in any
manner whatsoever to the Bidder, if it determines that the Bidder has, directly or indirectly or
through an agent, engaged in corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice (collectively the “Prohibited Practices”) in the
Selection Process. In such an event, MHRD shall, without prejudice to its any other rights or
remedies, forfeit and appropriate the EMD or PBG, as the case may be, as mutually agreed
genuine pre-estimated compensation and damages payable to MHRD for, inter alia, time, cost
and effort of MHRD, in regard to the RFP, including consideration and evaluation of such
Bidder’s Proposal.
b) Without prejudice to the rights of MHRD under Clause above and the rights and remedies
which MHRD may have under the LOI or the Agreement, if a Bidder is found by MHRD to have
directly or indirectly or through an agent, engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive practice during the
Selection Process, or after the issue of the LOI or the execution of the Agreement, such Bidder
shall not be eligible to participate in any tender or RFP issued by MHRD during a period of 3
years from the date such Bidder is found by MHRD to have directly or through an agent,
engaged or indulged in any corrupt practice, fraudulent practice, coercive practice, undesirable
practice or restrictive practice, as the case may be.

Ministry of Human Resource Development (MHRD)

Page 29 of 88

<!-- page 30 -->

Request for Proposal (RFP) Volume – 1

c) For the purposes of this Section, the following terms shall have the meaning hereinafter
respectively assigned to them:
(i) “corrupt practice” means (i) the offering, giving, receiving, or soliciting, directly or
indirectly, of anything of value to influence the action of any person connected with the
Selection Process (for avoidance of doubt, offering of employment to or employing or
engaging in any manner whatsoever, directly or indirectly, any official of MHRD who is
or has been associated in any manner, directly or indirectly with the Selection Process
or the LOI or has dealt with matters concerning the Agreement or arising there from,
before or after the execution thereof, at any time prior to the expiry of one year from the
date such official resigns or retires from or otherwise ceases to be in the service of
MHRD, shall be deemed to constitute influencing the actions of a person connected
with the Selection Process); or (ii) save as provided herein, engaging in any manner
whatsoever, whether during the Selection Process or after the issue of the LOA or after
the execution of the Agreement, as the case may be, any person in respect of any
matter relating to the Project or the Award or the Agreement, who at any time has been
or is a legal, financial or technical consultant/adviser of MHRD in relation to any matter
concerning the Project;
(ii) “fraudulent practice” means a misrepresentation or omission of facts or disclosure of
incomplete facts, in order to influence the Selection Process;
(iii) “coercive practice” means impairing or harming or threatening to impair or harm,
directly or indirectly, any persons or property to influence any person’s participation or
action in the Selection Process;
(iv) “undesirable practice” means (i) establishing contact with any person connected with or
employed or engaged by MHRD with the objective of canvassing, lobbying or in any
manner influencing or attempting to influence the Selection Process; or (ii) having a
Conflict of Interest; and
(v) “restrictive practice” means forming a cartel or arriving at any understanding or
arrangement among Bidders with the objective of restricting or manipulating a full and
fair competition in the Selection Process.

2.27 Conflict of Interest
a) A bidder shall not have a conflict of interest that may affect the Selection Process or the
Solution delivery (the “Conflict of Interest”). Any Bidder found to have a Conflict of Interest shall
be disqualified. In the event of disqualification, MHRD shall forfeit and appropriate the EMD, if
available, as mutually agreed genuine pre-estimated compensation and damages payable to
MHRD for, inter alia, the time, cost and effort of MHRD including consideration of such
Bidder’s Proposal, without prejudice to any other right or remedy that may be available to
MHRD hereunder or otherwise.
b) MHRD requires that the bidder provides solutions which at all times hold MHRD’s interests
paramount, avoid conflicts with other assignments or its own interests, and act without any
consideration for future work. The bidder shall not accept or engage in any assignment that
would be in conflict with its prior or current obligations to other clients, or that may place it in a
position of not being able to carry out the assignment in the best interests of MHRD.

Ministry of Human Resource Development (MHRD)

Page 30 of 88

<!-- page 31 -->

Request for Proposal (RFP) Volume – 1

c) Without limiting the generality of the above, an Bidder shall be deemed to have a Conflict of
Interest affecting the Selection Process, if:
i. the Bidder, its consortium member (the “Member”) or Associates (or any constituent
thereof) and any other Bidder, its consortium member or Associate (or any constituent
thereof) have common controlling shareholders or other ownership interest; provided that
this disqualification shall not apply in cases where the direct or indirect shareholding or
ownership interest of an Bidder, its Member or Associate (or any shareholder thereof
having a shareholding of more than 5 per cent of the paid up and subscribed share capital
of such Bidder, Member or Associate, as the case may be) in the other Bidder, its
consortium member or Associate is less than 5% (five per cent) of the subscribed and paid
up equity share capital thereof. For the purposes of this Clause, indirect shareholding held
through one or more intermediate persons shall be computed as follows:
o

where any intermediary controlled by a person through management control or
otherwise, the entire shareholding held by such controlled intermediary in any other
person (the “Subject Person”) shall be taken into account for computing the
shareholding of such controlling person in the Subject Person; where a person does
not exercise control over an intermediary, which has shareholding in the Subject
Person, the computation of indirect shareholding of such person in the Subject Person
shall be undertaken on

o

a proportionate basis; provided, however, that no such shareholding shall be reckoned
under this Sub-clause if the shareholding of such person in the intermediary is less
than 26% (twenty six per cent) of the subscribed and paid up equity shareholding of
such intermediary; or

ii. a constituent of such Bidder is also a constituent of another Bidder; or
iii. such Bidder or its Associate receives or has received any direct or indirect subsidy or grant
from any other Bidder or its Associate; or
iv. such Bidder has the same legal representative for purposes of this Application as any other
Bidder; or
v. such Bidder has a relationship with another Bidder, directly or through common third
parties, that puts them in a position to have access to each other’s’ information about, or to
influence the Application of either or each of the other Bidder; or
vi. there is a conflict among this and other Systems Implementation/Turnkey solution
assignments of the Bidder (including its personnel and other members, if any) and any
subsidiaries or entities controlled by such Bidder or having common controlling
shareholders. The duties of the bidder will depend on the circumstances of each case.
While providing software implementation and related solutions to MHRD for this particular
assignment, the bidder shall not take up any assignment that by its nature will result in
conflict with the present assignment; or
vii. A firm hired to provide System Integration/Turnkey solutions for the implementation of a
project, and its Members or Associates, will be disqualified from subsequently providing
goods or works or services related to the same project;

Ministry of Human Resource Development (MHRD)

Page 31 of 88

<!-- page 32 -->

Request for Proposal (RFP) Volume – 1

d) An Bidder eventually appointed to implement software solutions for this Project, its Associates,
affiliates and the Financial Expert, shall be disqualified from subsequently providing goods or
works or services related to the construction and operation of the same Project and any breach
of this obligation shall be construed as Conflict of Interest; provided that the restriction herein
shall not apply after a period of 12 months from the completion of this assignment; provided
further that this restriction shall not apply to software solutions delivered to MHRD in
continuation of this systems implementation or to any subsequent systems implementation
executed for MHRD in accordance with the rules of MHRD.

Ministry of Human Resource Development (MHRD)

Page 32 of 88

<!-- page 33 -->

Section 3:
Selection Process
for Bidder

<!-- page 34 -->

Request for Proposal (RFP) Volume – 1

3 Selection Process for Bidder
3.1

Opening of Bids

The Proposals will be opened by MHRD in the presence of such of those Bidders or their
representatives who may be present at the time of opening.
The representatives of the bidders should be advised to carry the identity card or a letter of
authority from the bidder firms to identify their bonafide for attending the opening of the proposal.
There will be three bid-opening events
a) Set 1 (RFP Document fee & Bid Security/EMD) and Set 2 (Pre-Qualification bid)
b) Set 3 (Technical bid)
c)

Set 4 (Commercial bid)

The venue, date and time for opening the Pre-qualification bid are mentioned in the Fact sheet.
The date and time for opening of Technical & Commercial bid would be communicated to the
qualified bidders.
All the bids will be opened before the bidders’ representatives who choose to be present at the
specified date, time and location.
The Technical Bids of only those bidders will be opened who clears the Pre-qualification stage.
The Commercial Bids of only those bidders will be opened who score equal to or more than
qualifying marks in Technical Bid.

3.2

Preliminary Examination of Bids

MHRD will examine the bids to determine whether they are complete, whether the documents
have been properly signed and whether the bids are generally in order. Any bids found to be nonresponsive for any reason or not meeting any criteria specified in the RFP, will be rejected by
MHRD and shall not be included for further consideration.
Initial Bid scrutiny will be held and bids will be treated as non-responsive, if bids are:


Not submitted in format as specified in the RFP document



Received without the Letter of Authorization (Power of Attorney)



Found with suppression of details



With incomplete information, subjective, conditional offers and partial offers submitted



Submitted without the documents requested



Non-compliant to any of the clauses mentioned in the RFP



With lesser validity period

Ministry of Human Resource Development (MHRD)

Page 34 of 88

<!-- page 35 -->

Request for Proposal (RFP) Volume – 1

3.3

Clarification on Bids

During the bid evaluation, MHRD may, at its discretion, ask the Bidder for a clarification of its bid.
The request for clarification and the response shall be in writing, and no change in the price or
substance of the bid shall be sought, offered, or permitted.

3.4

Evaluation Process

MHRD will constitute a Proposal Evaluation Committee to evaluate the responses of the bidders.
The Proposal Evaluation Committee constituted by MHRD shall evaluate the responses to the
RFP and all supporting documents/documentary evidence. Inability to submit requisite supporting
documents/documentary evidence, may lead to rejection.
The decision of the Proposal Evaluation Committee in the evaluation of proposals shall be final.
No correspondence will be entertained outside the process of evaluation with the Committee. The
Proposal Evaluation Committee may ask for meetings with the Bidders to seek clarifications or
conformations on their proposals.
The Proposal Evaluation Committee reserves the right to reject any or all proposals. Each of the
responses shall be evaluated as per the criteria and requirements specified in this RFP.
The steps for evaluation are as follows:

3.4.1 Stage 1: Pre-Qualification
1. MHRD shall validate the Set 1 “RFP Document fee & Bid Security/Earnest Money
Deposit (EMD)”.
2. If the contents of the Set 1 are as per requirements, MHRD shall open the “PreQualification Bid”. Each of the Pre-Qualification condition mentioned in Section 0 is
MANDATORY. In case the Bidder does not meet any one of the conditions, the bidder
will be disqualified.
3. Bidders would be informed of their qualification/disqualification based on the PreQualification criteria through Email and Phone. The Bid Security amount and the
Unopened Technical & Commercial Bids will be returned to the respective disqualified
Bidders after the submission of Bank Guarantee by the successful Bidder.

3.4.2 Stage 2: Technical Evaluation
1. Set 3 “Technical bid” will be evaluated only for the bidders who succeed in Stage 1.
2. MHRD will review the technical bids of the short-listed bidders to determine whether the
technical bids are substantially responsive. Bids that are not substantially responsive are
liable to be disqualified at MHRD’s discretion.
3. The bidders' technical solutions proposed in the bid document will be evaluated as per the
requirements specified in the RFP and technical evaluation framework as mentioned in
Section 3.6.
4. Bidders will be asked to give demonstration of the envisaged solution to MHRD as per the
demo scripts which will be shared with the Bidders who qualify the Pre-Qualification Stage.

Ministry of Human Resource Development (MHRD)

Page 35 of 88

<!-- page 36 -->

Request for Proposal (RFP) Volume – 1

5. Bidders shall present the proposal to MHRD as per the agenda mentioned in Section 3.6.6
6. Each Technical Bid will be assigned a technical score out of a maximum of 1000 marks.
Only the bidders who get a Technical score of 70% or more (prior to normalization) will
qualify for commercial evaluation stage. Failing to secure minimum marks shall lead to
technical rejection of the Bid and Bidder.
7. Bidder should also score at least 60% in individual sections of Technical Evaluation as
mentioned in Technical Evaluation Framework.
8. The Final Normalized technical score of the Bidder shall be calculated as follows:
Normalized Technical Score of a Bidder = {Technical Score of that Bidder/Score of the Bidder with
the highest technical score} X 1000 (adjusted to 2 decimals)

Example:
Bidders

Technical Score

Calculation

Normalized Technical Score

Bidder-1

880

(880/950)*1000

926.3

Bidder-2

900

(900/950)*1000

947.3

Bidder-3

800

(800/950)*1000

842.1

Bidder-4

950

(950/950)*1000

1000

3.4.3 Stage 3: Commercial Evaluation
1. All the technically qualified bidders will be notified to participate in Commercial Bid opening
process.
2. The commercial bids for the technically qualified bidders will then be opened on the notified
date and time and reviewed to determine whether the commercial bids are substantially
responsive. Bids that are not substantially responsive are liable to be disqualified at
MHRD’s discretion.
3. Commercial Bids that are not meeting the condition mentioned in Section 2.12 shall be
liable for rejection.
4. The bidder that has the lowest Total Cost of Ownership (TCO) for MHRD will be awarded
the contract. TCO shall be calculated by arriving on the Net Present Value of total cash
outflow for contract period using a discount rate of 10%. For the purpose of arriving at L1,
prices exclusive of taxes considered.
5. The bid price will include all taxes and levies and shall be in Indian Rupees and mentioned
separately.
6. Any conditional bid would be rejected
7. Errors & Rectification: Arithmetical errors will be rectified on the following basis:
a. If there is a discrepancy between the unit price and the total price that is obtained
by multiplying the unit price and quantity, the unit price shall prevail and the total
price shall be corrected.

Ministry of Human Resource Development (MHRD)

Page 36 of 88

<!-- page 37 -->

Request for Proposal (RFP) Volume – 1

b. If there is a discrepancy between words and figures, the amount in words will
prevail.

Ministry of Human Resource Development (MHRD)

Page 37 of 88

<!-- page 38 -->

Request for Proposal (RFP) Volume – 1

3.5

Pre-Qualification Criteria

The Bidder's pre-qualification bid will be evaluated as per the following criteria:
#

1.

2.

3.

4.

Parameter

Pre-qualification criteria Description

Evidence required
Copy of the Consortium Agreement with clear
roles & responsibilities (in case of a consortium)

Consortiums

The Bidder can be either a Single entity or a Consortium of
companies/corporations
In case of a consortium, one of the companies/corporations would be
designated as a "Lead Bidder". The consortium should not consist of
more than Three parties (Lead Bidder + 2 Consortium members).

Legal

Sole Bidder/Lead Bidder should be
Copy of Certificate of Incorporation
 A company incorporated in India under the Companies Act, 1956 Copy of Registration Certificates
and subsequent amendments thereto or a partnership firm
registered under LLP Act, 2008.
 Registered with the Service Tax Authorities
 Should have been operating for the last three years.

Sales
Turnover

Sole Bidder/Lead Bidder should have had a turnover of at least INR
300 Crores in each of the last 3 financial years (FY 2012-13, 2013-14,
2014-15) from system integration services, software development &
implementation (not including sales of software licenses or hardware)
For the purpose of this criterion, turnover of only the bidding entity will
be considered. Turnover of any parent, subsidiary, associated or
other related entity will not be considered.

Audited financial statements for the last three
financial years.
Or
Certificate from the Statutory Auditor

Profitability

Sole Bidder/Lead Bidder should be profit making as per the audited
consolidated financial statements in the last 3 financial years (FY
2012-13, 2013-14, 2014-15).
For the purpose of this criterion, profitability of only the bidding entity
will be considered. Profitability of any parent, subsidiary, associated
or other related entity will not be considered.

Audited financial statements for the last three
financial years.
Or
Certificate from the Statutory Auditor

Ministry of Human Resource Development (MHRD)

Page 38 of 88

<!-- page 39 -->

Request for Proposal (RFP) Volume – 1

#

Parameter

Pre-qualification criteria Description

Evidence required

Experience in
Education/Lea
rning related
Service

The Bidder should have experience of implementing/operating a
eLearning platform in India or abroad, having at least 20 lakh web
visits during the last three (3) years from the date of submission of bid

Completion Certificates from the client; OR
Work Order + Self Certificate of Completion
(Certified by the Statutory Auditor); OR
Work Order + Phase Completion Certificate from
the client

5.

6.

Experience in
development
and
maintenance
of Portal

The Lead Bidder should have the experience of development, system
integration, and maintenance of a web based ICT application/portal
implemented in a duration of 3 months, either nation-wide or statewide in the last 5 years:
At least one (1) such project of value more than INR 50 Cr
OR
At least two (2) such projects of value more than INR 25 Cr each

Completion Certificates from the client; OR
Work Order + Self Certificate of Completion
(Certified by the Statutory Auditor); OR
Work Order + Phase Completion Certificate from
the client

7.

Experience in
development
and
maintenance
of Contact
Centre

The Bidder should have experience of managing & operating Contact
Centre (either owned or 3rd party) in India having the following
capabilities during the last five (5) years from the date of submission
of bid:
 Handing at least 3 languages, excluding English
 Handling 12x7 helpline operations

Completion Certificates from the client; OR
Work Order + Self Certificate of Completion
(Certified by the Statutory Auditor); OR
Work Order + Phase Completion Certificate from
the client

8.

Certifications

Sole Bidder/Lead Bidder should have valid CMMi certification at the
time of submission of bid

Valid CMMi certificate

9.

Blacklisting

Sole Bidder/All Consortium Members should not have been
blacklisted by Govt. of India/Central PSU in the last 5 years preceding
the date of submission of the bid.

10.

Power of
Attorney

Special written power of attorney on a stamp paper authorizing the
representative of the bid to sign the bid against this RFP

Self-certificate letter undertaking to this effect on
company's letter head signed by company’s
authorized signatory.
Sole Bidder/All Consortium Members must
disclose any blacklisting. MHRD reserves the
right to select or reject the Bidder.
Special written power of attorney on a stamp
paper

All the citations that have to be provided for pre-qualification criteria shall be as per the format provided in Section 6.2.
Ministry of Human Resource Development (MHRD)

Page 39 of 88

<!-- page 40 -->

Request for Proposal (RFP) Volume – 1

3.6

Technical Evaluation Framework

The Bidder's technical solution proposed in the Technical Evaluation bid document will be evaluated as per
the evaluation criteria mentioned in the following table.

#

Evaluation Criteria

Total Marks

Minimum Qualifying Marks
(Cut-off)

1.

Consortium Member(s) Credentials

100

>=60 (60%)

2.

Bidder’s Experience

300

>=180 (60%)

3.

Proposed Solution

200

>=120 (60%)

4.

Approach & Methodology

100

>=60 (60%)

5.

Resource Planning

100

>=60 (60%)

6.

Demonstration & Presentation

200

>=120 (60%)

1000

>= 700 (70%)

Total

MHRD (or a nominated party) reserves the right to check/validate the authenticity of the
information provided in the Pre-qualification and Technical Evaluation criteria and the requisite
support must be provided by the Bidder.
The following sections explain how the Bidders will be evaluated on each of the evaluation criteria.

3.6.1 Consortium Member(s) Credentials
#

Criteria

Sales
1. Turnover of
consortium
members

Criteria Details

Marks Allotted

If the Turnover of all consortium members is greater than INR
100 Crores per annum as per the audited consolidated
financial statements for the last 3 financial years preceding
the date of submission of bid
 Above condition fulfilled for all Consortium Partners = 100

100

 Above condition fulfilled for 2 Consortium Partners = 60
 Above condition fulfilled for 1 Consortium Partner = 0
(Zero)

TOTAL

Ministry of Human Resource Development (MHRD)

100

Page 40 of 88

<!-- page 41 -->

Request for Proposal (RFP) Volume – 1

3.6.2 Bidder’s Experience
#

1.

Citation

Experience in
development
and
maintenance of
MOOC/
elearning
Portal

Citation Details
Experience of
implementing/operating
MOOC/elearning Portal with
similar functionalities as
required in SWAYAM in India
serving students across
segments during the last five
(5) years from the date of
submission of bid.
Number of registered users:
>=5 Lakh: 90
>=2.5 Lakh & <5 Lakh:60

Documentary
Evidence

Marks
Allotted

Completion/Implementat
ion certificate from the
Customer mandatorily
including: clear
reference of broad
scope of work
undertaken by bidder &
date of
implementation/goLive/completion date.

90

Completion/Implementat
ion certificate from the
Customer mandatorily
including: clear
reference of broad
scope of work
undertaken by bidder &
date of
implementation/goLive/completion date.

60

Completion/Implementat
ion certificate from the
Customer mandatorily
including: clear
reference of broad
scope of work
undertaken by bidder &
date of
implementation/goLive/completion date.

60

>=1 Lakh & <2.5 Lakh:40
<1 Lakh:20

2.

Experience in
development
and
maintenance of
large scale
Portals in India

Experience in development &
maintenance of large
transaction Portals of
comparable scope and
magnitude in India
 citations (atleast 1 should
be successfully completed)
= 60,
 2 citations (atleast 1 should
be successfully completed)
= 40,
 1 citation (successfully
completed) = 20
Experience in System
Integration projects with a
contract value of at least INR
50 Cr in Government/PSU
Organization in India.

3.

Experience in
Government/
PSU

 3 citations (atleast 1 should
be successfully completed)
= 60,
 2 citations (atleast 1
should be successfully
completed) = 40,
 1 citation (successfully
completed) = 20

Ministry of Human Resource Development (MHRD)

Page 41 of 88

<!-- page 42 -->

Request for Proposal (RFP) Volume – 1

#

Citation

Citation Details

Documentary
Evidence

Marks
Allotted

Experience of managing &
operating Call Centre (either
owned or 3rd party) having the
following capabilities in India:
- Minimum of 30 seats

4.

Experience in
development
and
maintenance of
Contact Centre

- Handing at least 3
languages, excluding
English
- Handling 12x7 operations
 3 citations (atleast 1 should
be successfully completed)
= 60,
 2 citations (atleast 1 should
be successfully completed)
= 40,
 1 citation (successfully
completed) = 20

Completion/Implementat
ion certificate from the
Customer mandatorily
including: clear
reference of broad
scope of work
undertaken by bidder &
date of
implementation/goLive/completion date.

60

Completion/
Implementation
certificate from the
Customer mandatorily
including: clear
reference of broad
scope of work
undertaken by bidder &
date of implementation/
go-Live/completion date.

30

Experience of at least one
project in HR analytics domain

5.

Experience in
Business
Intelligence/
Analytics

 3 citations (atleast 1 should
be successfully completed)
= 15,
 2 citations (atleast 1 should
be successfully completed)
= 10,
 1 citation (successfully
completed) = 5
Experience in Business
Intelligence/Analytics projects
in India
 3 citations (atleast 1 should
be successfully completed)
= 15,
 2 citations (atleast 1 should
be successfully completed)
= 10,
 1 citation (successfully
completed) = 5

TOTAL

Ministry of Human Resource Development (MHRD)

300

Page 42 of 88

<!-- page 43 -->

Request for Proposal (RFP) Volume – 1

3.6.3 Proposed Solution
#

Citation

1. Solution/
Product
Experience

Citation Details

Documentary Evidence

Whether the proposed
MOOC/eLearning Portal
framework/product is deployed
and operational

Completion/Implementati
on certificate from the
Customer mandatorily
including: clear reference
of broad scope of work
undertaken by bidder &
date of
implementation/goLive/completion date.

Number of registered users:
>=5 Lakh: 60
>=2.5 Lakh & <5 Lakh: 45
>=1 Lakh & <2.5 Lakh: 30

Marks
Allotted
60

<1 Lakh: 15
2. Solution
Architecture

Solution Architecture (including
functional architecture,
application architecture,
integration architecture,
security architecture, &
Infrastructure architecture)

100

3. Tools &
Technologies

Tools & Technologies proposed
in the solution

40

Total

200

3.6.4 Approach & Methodology
#

Criteria

1.

Understanding
of Business &
Scope of work
and all aspect
of the Project

2.

Criteria Details

Demonstrated level of understanding of the MHRD
business processes, the project purpose and scope of
work.
Average
3
Good
6
Very Good
8
Excellent
10
Approach for
Approach for project implementation and bidder's plan for
Implementation performing the required services as detailed in scope of
work in the RFP
Average
3
Good
6
Very Good
8
Excellent
10

Ministry of Human Resource Development (MHRD)

Marks
Allotted
10

10

Page 43 of 88

<!-- page 44 -->

Request for Proposal (RFP) Volume – 1

#

Criteria

Criteria Details

3.

Proposed
Project
Governance

Proposed Governance Structure, clearly defined roles and
responsibilities, escalation matrix, risk mitigation and
interface between multiple stakeholders
Average
3
Good
6
Very Good
8
Excellent
10

10

4.

Integrating
with other
platforms

20

5.

Incorporating
Best practices

6.

Setting up &
running the
Contact Centre

7.

SLA
compliance

Approach for Integrating with other MOOC/eLearning
platforms
Average
6
Good
12
Very Good
18
Excellent
20
Approach for embedding industry accepted best practices
in MHRD solution
Average
6
Good
12
Very Good
18
Excellent
20
Approach for Setting up & running the Contact Centre,
scaling up and down and disaster management
Average
3
Good
6
Very Good
8
Excellent
10
Approach for ensuring SLA compliance and also for
improving SLAs on a continuous basis
Average
3
Good
6
Very Good
8
Excellent
10

8.

Value addition

How will the bidder add value to MHRD operations and
continuously help in improving the operations through the
solution
Average
3
Good
6
Very Good
8
Excellent
10

10

TOTAL

Ministry of Human Resource Development (MHRD)

Marks
Allotted

20

10

10

100

Page 44 of 88

<!-- page 45 -->

Request for Proposal (RFP) Volume – 1

3.6.5 Resource Planning
#

Criteria

Criteria Details

Marks Allotted

Bidder would be evaluated for
Resource Deployment Plan
1.

2.

Resource Deployment Plan

Average

15

Good

20

Very Good

30

Excellent

40

Project Manager

10

6.

Subject Matter Expert – Should fulfil basic minimum
qualification as mentioned in
Education/eLearning/MOOCs
subsequent table in terms of
Solution Architect
 Qualification & Certification
 Total experience
Infrastructure Expert
 Experience
in
similar
Database Expert
assignments

7.

Analytics Expert

3.
4.
5.

40

10
10
10
10
10

TOTAL

100

Following table specifies the minimum qualification required for Key Positions identified for this project.

#

Position

Minimum Qualifications

1.

Project
Manager

 Education: Full Time MBA/MCA/M. Tech & B. Tech/B.E. from a reputed
institute
 Total Experience: At least 10 years in IT domain
 Should have more than 5 years of experience of handling such large
projects as a project manager
 Languages known (Read, Write and Speak): Hindi, English
 Excellent writing, communication, time management and multi-tasking
skills

2.

Subject Matter
Expert –
Education/
eLearning/MO
OC

 Education: Full time MBA/PGDM
 Total Experience: At least 5 years
 Should have experience of more than 1 large project of similar nature in
Education/eLearning/MOOC domain

Solution
Architect

 Education: Full time MCA/M. Tech/B. Tech/B.E. from a reputed institute
 Total Experience: At least 5 years in IT domain
 Should have experience of more than 3 years as Solution Architecture in
large projects of similar nature

Infrastructure
Expert

 Education: Full time MCA/M. Tech/B. Tech/B.E. from a reputed institute
 Total Experience: At least 5 years in IT domain
 Should have experience of more than 3 years as Infrastructure Expert in
large projects of similar nature

3.

4.

Ministry of Human Resource Development (MHRD)

Page 45 of 88

<!-- page 46 -->

Request for Proposal (RFP) Volume – 1

#

Position

Minimum Qualifications

5.

Database
Expert

 Education: Full time MCA/M. Tech/B. Tech/B.E./Certified DBA
 Total Experience: At least 5 years in IT domain
 Should have experience of more than 3 years as a Database
Administrator in large projects of similar nature with experience in
database activities like instance tuning, schema management, space
management, backup and recovery, disaster recovery, data replication,
database refresh etc.

6.

Analytics
Expert

 Education: Full time MCA/M. Tech/B. Tech/BE
 Total Experience: At least 7 years in IT domain
 Should have experience of more than 5 years in Data Analytics domain

3.6.6 Demonstration & Presentation
#

Criteria

Criteria Details

1.

Demonstration of business
processes

Demonstartion of business proceses
as specifed by MHRD

2.

Presentation

TOTAL

Ministry of Human Resource Development (MHRD)

Marks Allotted
150
50
200

Page 46 of 88

<!-- page 47 -->

Section 4:
Award of Contract

<!-- page 48 -->

Request for Proposal (RFP) Volume – 1

4 Award of Contract
4.1

Notification of Award

MHRD will notify the successful Bidder in writing by e-mail followed by courier, to be confirmed by
the Bidder in writing by email followed by courier.

4.2

Signing of Contract

After the notification of award, MHRD will issue Purchase Order (PO)/Letter of Intent (LOI). The
Bidder shall sign and return back to MHRD duplicate copy of the Purchase Order as an
acceptance of the PO/LOI within 15 working days from the date of issuance of PO/LOI along with
a Performance Bank Guarantee.
On receipt of the Performance Bank Guarantee MHRD shall enter into a contract. The Master
Service Agreement is provided in RFP Vol 3.

4.3

Performance Bank Guarantee (PBG)

The successful Bidder shall at his own expense deposit with MHRD, within fifteen (15) working
days from the date of issuance of PO, an unconditional and irrevocable Performance Bank
Guarantee (PBG) from a bank acceptable to MHRD, in the format prescribed in Section 9.1,
payable on demand, for the due performance and fulfilment of the contract by the bidder.
This Performance Bank Guarantee will be for an amount equivalent to 10% of total contract value.
PBG shall be invoked by MHRD in the event the Bidder:
i.

fails to meet the overall penalty condition as mentioned in RFP Vol 2 Section 6 or any
changes agreed between the parties,

ii.

fails to perform the responsibilities and obligations as set out in the RFP to the complete
satisfaction of MHRD,

iii.

Misrepresentations of facts/information submitted to MHRD.

The performance bank guarantee shall be valid till satisfactory completion of Post Implementation
Support.
The performance bank guarantee may be discharged/returned by MHRD upon being satisfied that
there has been due performance of the obligations of the bidder under the contract. However, no
interest shall be payable on the performance bank guarantee.
In the event of the Bidder being unable to service the contract for whatever reason, MHRD would
invoke the PBG. Notwithstanding and without prejudice to any rights whatsoever of MHRD under
the contract in the matter, the proceeds of the PBG shall be payable to MHRD as compensation
for any loss resulting from the bidder’s failure to perform/comply its obligations under the contract.
MHRD shall notify the bidder in writing of the exercise of its right to receive such compensation
within 40 days, indicating the contractual obligation(s) for which the bidder is in default.
MHRD shall also be entitled to make recoveries from the bidder’s bills, performance bank
guarantee, or from any other amount due to him, an equivalent value of any payment made to him
due to inadvertence, error, collusion, misconstruction or misstatement.
Ministry of Human Resource Development (MHRD)

Page 48 of 88

<!-- page 49 -->

Request for Proposal (RFP) Volume – 1

In case the project is delayed beyond the project schedule as mentioned in RFP Vol 2, the
performance bank guarantee shall be accordingly extended by the Bidder till completion of scope
of work as mentioned in RFP Vol 2.
This Performance Bank Guarantee shall be valid only up to the completion of the period of ‘GoLive’ + 36 months for the Solution.
On satisfactory performance and completion of the order in all respects and duly certified to this
effect by the Project Coordinator, Contract Completion Certificate will be issued and the PBG will
be returned to the Bidder.

4.4

Warranty & Maintenance

Bidder shall also provide complete maintenance support for all the proposed integrated solution as
outlined in this RFP for a period of Thirty six months from the date of go-live i.e. “Go-Live” + 36
months. “Go-live” is the date on which the proposed solution is completely operational as per the
requirements provided in this RFP and all the acceptance tests are successfully concluded to the
satisfaction of MHRD.
During the warranty period, the bidder shall warrant that the goods supplied under the contract are
new, unused, of the most recent version/models and incorporate all recent improvements in design
and materials unless provided otherwise in the contract. The bidder further warrants that the goods
supplied under this contract shall have no defects arising from design, materials or workmanship.
MHRD or designated representatives of the bidder shall promptly notify successful bidder in writing
of any claims arising under this warranty. Upon receipt of such notice, the bidder shall, within the
warranty period and with all reasonable speed, repair or replace the defective systems, without
costs to MHRD and within time specified and acceptable to MHRD.
If the successful bidder, having been notified, fails to remedy the defect(s) within the period
specified in the contract, MHRD may proceed to take such reasonable remedial action as may be
necessary, at the successful bidder’s risk and expense and without prejudice to any other rights,
which MHRD may have against the bidder under the contract.
During the comprehensive warranty period, the successful bidder will provide all product(s) and
documentation updates, patches/fixes, and version upgrades within 15 days of their availability
and should carry out installation and make operational the same at no additional cost to MHRD.
The successful bidder hereby warrants MHRD that:
i.

The implemented integrated solution represents a complete, integrated solution meeting all the
requirements as outlined in the RFP and further amendments if any, and provides the functionality and
performance, as per the terms and conditions specified in the contract.

ii.

The proposed integrated
specification/requirement.

iii.

The successful bidder will be responsible for warranty services from licensers of products included in
the systems.

iv.

The successful bidder undertakes to ensure the maintenance of the acceptance criterion/standards in
respect of the systems during the warranty period.

solution

Ministry of Human Resource Development (MHRD)

will

achieve

parameters

delineated

in

the

technical

Page 49 of 88

<!-- page 50 -->

Request for Proposal (RFP) Volume – 1

4.5

Failure to agree with the Terms & Conditions of the RFP

Failure of the successful bidder to agree with the Terms & Conditions of the RFP shall constitute
sufficient grounds for the annulment of the award, in which event MHRD may award the contract to
the next best value bidder or call for new proposals.
In such a case, MHRD shall invoke the PBG and/or forfeit the EMD.

Ministry of Human Resource Development (MHRD)

Page 50 of 88

<!-- page 51 -->

Annexures

<!-- page 52 -->

Request for Proposal (RFP) Volume – 1

5 Annexure 1 – Template for Pre-Bid Queries
Bidder shall submit all pre-bid queries in excel in the following format.
#

RFP
Page No

RFP Section
(Name & No.)

Statement as per RFP
document

Query by
bidder

Reason for
Query

1
2
3
4
5

Ministry of Human Resource Development (MHRD)

Page 52 of 88

<!-- page 53 -->

Request for Proposal (RFP) Volume – 1

6 Annexure 2 – Formats for Submission of the PreQualification Bid
6.1

Pre-Qualification Bid Covering Letter

To,
<Location, Date>
To be filled up
Subject: Submission of the Pre-Qualification bid for SWAYAM Project
Dear Sir,
We, the undersigned, offer to provide Systems Integrator services to MHRD with reference to your
Request for Proposal dated <insert date> and our Proposal. We are hereby submitting our Prequalification bid.
We hereby declare that all the information and statements made in this Pre-qualification bid are
true and accept that any misinterpretation contained in it may lead to our disqualification.
We agree to abide by all the terms and conditions of all the volumes of this RFP document. We
would hold the terms of our proposal valid for the number of days as stipulated in the RFP
document.
Yours sincerely,
(Authorised Signatory)
Signature:
Name:
Designation:
Address:
Seal:
Date:

Ministry of Human Resource Development (MHRD)

Page 53 of 88

<!-- page 54 -->

Request for Proposal (RFP) Volume – 1

6.2

Pre-Qualification Citations

S. No.

Item

Bidder’s Response

Proposed Product/Solution
(for which the citation has been provided)
Name of Bidder entity
(Lead bidder/consortium member with bidder name)
Assignment Name
Name of Client
Country
Contact Details
(Contact Name, Address, Telephone Number)
Approximate Value of the Contract
Duration of Assignment (months)
Award Date (month/year)
Completion Date (month/year)
Narrative description of the project
Details of Work that defines the scope relevant to the
requirement
Documentary Evidence attached

Ministry of Human Resource Development (MHRD)

Page 54 of 88

<!-- page 55 -->

Request for Proposal (RFP) Volume – 1

6.3

No Deviation Certificate

This is to certify that our offer is exactly in line with your tender enquiry/RFP (including
amendments) no. _________ dated __________. This is to expressly certify that our offer contains
no deviation either Technical (including but not limited to Scope of Work, Business Requirements
Specification, Functional Requirements Specification, Hardware Specification and Technical
Requirements Specification) or Commercial in either direct or indirect form.

(Authorised Signatory)

Signature:
Name:
Designation:
Address:
Seal:
Date:

Ministry of Human Resource Development (MHRD)

Page 55 of 88

<!-- page 56 -->

Request for Proposal (RFP) Volume – 1

6.4

Total Responsibility

This is to certify that I undertake the total responsibility for the defect free operation of the
proposed solution as per the requirement of the RFP for the duration mentioned in all the volumes
of the RFP.
(Authorised Signatory)
Signature:
Name:
Designation:
Address:
Seal:
Date:

Ministry of Human Resource Development (MHRD)

Page 56 of 88

<!-- page 57 -->

Request for Proposal (RFP) Volume – 1

7 Annexure 3 – Formats for Submission of the Technical Bid
7.1

Technical Bid Covering Letter

To,
<Location, Date>

Subject: Submission of the Technical bid for SWAYAM Project
Dear Sir,
We, the undersigned, offer to provide System Integrator services to MHRD with reference to your
Request for Proposal dated <insert date> and our Proposal. We are hereby submitting our
Proposal, which includes Pre-qualification bid, Technical bid and the Commercial Bid in separate
documents.
We hereby declare that all the information and statements made in this Technical bid are true and
accept that any misinterpretation contained in it may lead to our disqualification.
We agree to abide by all the terms and conditions of all the volumes of this RFP document. We
would hold the terms of our bid valid for the number of days as stipulated in the RFP document.
We understand you are not bound to accept any Proposal you receive.
Yours sincerely,

(Authorised Signatory)

Signature:
Name:
Designation:
Address:
Seal:
Date:

Ministry of Human Resource Development (MHRD)

Page 57 of 88

<!-- page 58 -->

Request for Proposal (RFP) Volume – 1

7.2

Checklist

S. No.

Checklist Items

1.

RFP Document Fees

2.

Earnest Money Deposit (EMD)

3.

Non-blacklisting undertaking

4.

No Deviation Certificate

5.

Total Responsibility Certificate

6.

Manufacturers’/Producers’ Authorization Form

7.

Power of Attorney

8.

Pre-Qualification Bid

9.

Technical Bid

10.

Commercial Bid

Ministry of Human Resource Development (MHRD)

Bidder’s Response (Yes/No)

Page 58 of 88

<!-- page 59 -->

Request for Proposal (RFP) Volume – 1

Bidder’s General Information

7.3
I.

Lead Bidder

Following table shall be filled with the details of Lead Bidder.
S. No.

Item

1.

Company Name

2.

Year Established

3.

Incorporated in India (Yes or No)

4.

Role in the Consortium

5.

Contact Name

6.

Position

7.

Address

8.

Mobile

9.

Telephone

10.

Fax Number

11.

Email Address

Ministry of Human Resource Development (MHRD)

Bidder’s Response

<Scope of Work to be handled>

Page 59 of 88

<!-- page 60 -->

Request for Proposal (RFP) Volume – 1

II.

Consortium Member(s)

The Bidder should fill the following table for all the Consortium Members separately.

S. No.

Item

1.

Company Name

2.

Year Established

3.

Incorporated in
India (Yes or No)

4.

Role in the
Consortium

5.

Turnover (INR
Crore)

Bidder’s Response

2014-15:
2013-14:
2012-13:

6.

Net Profit (INR
Crore)

2014-15:
2013-14:
2012-13:

7.

Contact Name

8.

Position

9.

Address

10.

Mobile

11.

Telephone

12.

Fax Number

13.

Email Address

Ministry of Human Resource Development (MHRD)

Page 60 of 88

<!-- page 61 -->

Request for Proposal (RFP) Volume – 1

7.4

Bidder’s Experience - Client Citations

S. No.

Item

1.

Proposed Product/Solution
(for which the citation has been provided)

2.

Name of Bidder entity
(Lead bidder/consortium member with bidder name)

3.

Assignment Name

4.

Name of Client

5.

Country

6.

Bidder’s Response

Contact Details
(Contact Name, Address, Telephone Number)

7.

Approximate Value of the Contract

8.

Duration of Assignment (months)

9.

Award Date (month/year)

10.

Completion Date (month/year)

11.

Narrative description of the project

12.

Details of Work that defines the scope relevant to the
requirement

13.

Documentary Evidence attached

Ministry of Human Resource Development (MHRD)

Page 61 of 88

<!-- page 62 -->

Request for Proposal (RFP) Volume – 1

7.5

Resource Deployment Plan

I.

Before Go-Live (Implementation)

1.

Project Manager

2.

Subject Matter Expert –
Education/eLearning/
MOOC

3.

Solution Architect

4.

Infrastructure Expert

5.

Database Expert

6.

Analytics Expert

7.

Deputy Project Manager

8.

Programmer 1

9.

Programmer 2

10.

<Add more rows>

Ministry of Human Resource Development (MHRD)

W 18

W 17

W 16

W 15

W 14

W 13

W 12

W 11

W9

W8

W7

W6

W5

W4

W3

Name
W2

Role

W1

#

W 10

Weeks

Total Staff
person month
proposed

Distribution of
Total
Onsite

Offshore

Page 62 of 88

<!-- page 63 -->

Request for Proposal (RFP) Volume – 1

II.

After Go-Live (Support – IT Helpdesk, Application Support, IT Infrastructure Support)

#

Role

Years

Name

1

2

3

Total

1.
2.
3.
4.
5.

7.6

Curriculum Vitae (CV) of Team Members
Bidder’s Response

S. No.

Item

1.

Name

2.

Specify role to be played in
the project

3.

Name of Organization

4.

Number of years with the
Current Organization

5.

Total Experience (in Years)

6.

Experience in yrs. (Provide details regarding name of organizations worked for,
Designation, responsibilities, tenure etc.)
Name of
Organization

From

To

Designation/
Responsibilities

6.1.
6.2.
7.

Summarized professional experience (Relevant to the Current Project) in reverse
chronological order
From

To

Company/Project/Position/Relevant Functional,
Technical and Managerial experience

7.1.
7.2.
8.

Educational Background, Training/Certification including institutions, % of
marks, specialization areas etc.
Degree

Year of Award
of Degree

University

% of marks

8.1.
8.2.

Ministry of Human Resource Development (MHRD)

Page 63 of 88

<!-- page 64 -->

Request for Proposal (RFP) Volume – 1

7.7

Project Plan

1.
2.
3.
4.
5.
6.
7.

<add
more
rows,
if
necessary>

Ministry of Human Resource Development (MHRD)

Page 64 of 88

W 18

W 17

W 16

W 15

W 14

W 13

W 12

W 11

W 10

W9

W8

W7

W6

W5

W4

W3

Activity

W2

S. no.

W1

Weeks

<!-- page 65 -->

Request for Proposal (RFP) Volume – 1

7.8

Bill of Material (BOM) for the Solution

1.

Solution Proposed

#

Proposed
Solution (Provide
the Product Name
or fill Custom
Built, in case of a
new development)

Version &
Year of
Release

Ministry of Human Resource Development (MHRD)

OEM

Features
&
Function
alities

O&M Support
(Warranty/ATS
/: as required
as per RFP)

Reference in the
Submitted
Proposal (Please
provide page
number/section
number/volume)

Page 65 of 88

<!-- page 66 -->

Request for Proposal (RFP) Volume – 1

2.

Bill of Material (Software)

#

Item

Proposed Solution
(Provide the Product Name
or fill Custom Built, in case
of a new development)

3.

Bill of Material (Infrastructure)

Unit of
Measurement

Number of
Licenses
(Development
Environment)

Number of
Licenses
(UAT)

Number of
Licenses
(Training)

MHRD will procure infrastructure based on bidder's recommendations.

Ministry of Human Resource Development (MHRD)

Page 66 of 88

Number of
Licenses (Data
Center
Production)

Number of
Licenses
(DR Site)

<!-- page 67 -->

Request for Proposal (RFP) Volume – 1

7.9

Manufacturers'/Producers’ Authorization Form

(This form has to be provided by the OEMs of the products proposed)

No.
To,

Date:

Shri R Srinivasan
Director, Department of Higher Education
Ministry of Human Resource Development, Government of India
Room No. 205, C Wing, Shastri Bhawan, Dr. Rajendra Prasad Road,
New Delhi-110001
Email ID: rajusrini@hotmail.com
Phone number: 011 2307 0989
Dear Sir,
Ref: Your RFP Ref: [*] dated [*]
We who are established and reputable manufacturers/producers of ________________________
having factories/development facilities at (address of factory/facility) do hereby authorize M/s
___________________ (Name and address of Agent) to submit a Bid, and sign the contract with
you against the above Bid Invitation.
We hereby extend our full guarantee and warranty for the Solution, Products and services offered
by the above firm against this Bid Invitation.
We also undertake to provide any or all of the following materials, notifications, and information
pertaining to the Products manufactured or distributed by the Supplier:
a) Such Products as the Bank may opt to purchase from the Supplier, provided, that this option
shall not relieve the Supplier of any warranty obligations under the Contract; and
b) in the event of termination of production of such Products:
(i) advance notification to the Bank of the pending termination, in sufficient time to permit the
Bank to procure needed requirements; and
(ii) Following such termination, furnishing at no cost to the Bank, the blueprints, design
documents, operations manuals, standards, source codes and specifications of the
Products, if requested.
We duly authorize the said firm to act on our behalf in fulfilling all installations, Technical support
and maintenance obligations required by the contract.
Yours faithfully,

Ministry of Human Resource Development (MHRD)

Page 67 of 88

<!-- page 68 -->

Request for Proposal (RFP) Volume – 1

(Name)
(Name of Producers)

Note: This letter of authority should be on the letterhead of the manufacturer and should be signed by a
person competent and having the power of attorney to bind the manufacturer. The Bidder in its Bid should
include it.

Ministry of Human Resource Development (MHRD)

Page 68 of 88

<!-- page 69 -->

Request for Proposal (RFP) Volume – 1

8 Annexure 4 – Formats for Submission of the Commercial
Bid
8.1

Commercial Bid Covering Letter

To:

Shri R Srinivasan
Director, Department of Higher Education
Ministry of Human Resource Development, Government of India
Room No. 205, C Wing, Shastri Bhawan, Dr. Rajendra Prasad Road,
New Delhi-110001
Email ID: rajusrini@hotmail.com
Phone number: 011 2307 0989
Subject: Submission of the Commercial bid for SWAYAM Project
Dear Sir/Madam,
We, the undersigned, offer to provide the System Integrator Services for SWAYAM Project in
accordance with your Request for Proposal dated <<Date>> and our Proposal. Our attached
Commercial Bid is for the amount of <<Amount in words and figures>>. This amount is inclusive
of all the taxes.
1. Price and Validity


All the prices mentioned in our bid are in accordance with the terms as specified in the RFP
documents. All the prices and other terms and conditions of this Bid are valid for a period of
<days> calendar days from the date of opening of the Bid.



We hereby confirm that our prices include all taxes. However, all the taxes are quoted
separately under relevant sections.



We understand that the actual payment would be made as per the existing indirect tax
rates during the time of payment.

2. Unit Rates
We have indicated in the relevant forms enclosed the unit rates for the purpose of on account of
payment.
3. RFP Pricing
We further confirm that the prices stated in our bid are in accordance with your Instruction to
Bidders included in RFP documents.
4. Qualifying Data

Ministry of Human Resource Development (MHRD)

Page 69 of 88

<!-- page 70 -->

Request for Proposal (RFP) Volume – 1

We confirm having submitted the information as required by you in your Instruction to Bidders. In
case you require any other further information/documentary proof in this regard before evaluation
of our bid, we agree to furnish the same in time to your satisfaction.
5. Bid Price
We declare that our Bid Price is for the entire scope of the work as specified in all the Volumes of
this RFP and Annexure thereto. Our bid prices are mentioned in the submitted Commercial Bid.
6. Performance Bank Guarantee
We hereby declare that in case the contract is awarded to us, we shall submit the Performance
Bank Guarantee as specified in the Section 9.1 of this RFP document.
Our Commercial Bid shall be binding upon us subject up to expiration of the validity period of the
Proposal, i.e., [Date].
We understand you are not bound to accept any Proposal you receive.
We hereby declare that our bid is made in good faith, without collusion or fraud and the information
contained in the bid is true and correct to the best of our knowledge and belief.
Thanking you,

(Authorised Signatory)

Signature:
Name:
Designation:
Address:
Seal:
Date:

Ministry of Human Resource Development (MHRD)

Page 70 of 88

<!-- page 71 -->

Request for Proposal (RFP) Volume – 1

8.2

Total Cost of Ownership

The bidder must submit BOQ with costing details as required for Section 8.2.2.
In addition. the bidder is required to upload all the tables given below in the eProcurement portal

8.2.1 Total Cost of Ownership with taxes
S. No.

Commercial Bid Line Item

1.

Application License cost
(From Section 8.3.1.1)

2.

Application Implementation
Cost (From Section 8.3.1.2)

3.

Cloud Hosting and System
Software Base Cost (From
Section 8.3.2.1)

4.

Base Cost for System
Software Support (From
Section 8.4.1.1)

5.

Annual Support Cost for
Applications (From Section
8.4.2)

6.

Call Centre Cost (From
Section 8.4.3)

7.

Capacity Building Cost (From
Section 8.4.4)

8.

Additional Manpower cost
(From Section 8.5.1)

Base price
in INR

Excise Duty
%

Amount

VAT
%

Amount

%

CST

Service Tax

Amount

%

Amount

Total cost in
INR

Total amount
in words

TOTAL COST (X)
Ministry of Human Resource Development (MHRD)

Page 71 of 88

<!-- page 72 -->

Request for Proposal (RFP) Volume – 1

Base price
in INR

Excise Duty

VAT

S. No.

Commercial Bid Line Item

8.A

Minimum guaranteed CENVAT credit on account of Service Tax

8.B

Input Tax credit on account of VAT

%

Amount

%

Amount

%

CST

Service Tax

Amount

%

Amount

Total cost in
INR

Total amount
in words

TOTAL Y (8.A + 8.B)
CONTRACT PRICE (X-Y)
Note:
 Any existing tax/duty not mentioned here will not be entertained at a later date
 All expenses related to travelling, lodging, boarding and other expenses have to be borne by the Bidder.

8.2.2 Total Cost of Ownership without taxes
This section should match with the price mentioned in the BoQ uploaded on eProcurement portal.

S. No.

Commercial Bid Line Item

1.

Application License cost (From Section 8.3.1.1)

2.

Application Implementation Cost (From Section 8.3.1.2)

3.

Cloud Hosting and System Software Base Cost (From Section
8.3.2.1)

4.

Base Cost for System Software Support (From Section 8.4.1.1)

5.

Annual Support Cost for Applications (From Section 8.4.2)

6.

Call Centre Cost (From Section 8.4.3)

7.

Capacity Building Cost (From Section 8.4.4)

8.

Additional Manpower cost (From Section 8.5.1)

Base price in INR

Total amount in words

TOTAL COST without taxes
Ministry of Human Resource Development (MHRD)

Page 72 of 88

<!-- page 73 -->

Request for Proposal (RFP) Volume – 1

8.3

Capital Cost/One time cost

S. No.

Item

1

Total Application Cost (From Section 8.3.1)

Price in INR (A)

Total Amount in Words (B)

Price in INR (A)

Total Amount in Words (B)

Capital Cost

8.3.1 Total Application Cost
S. No.

Item

1

Application License Cost (From Section 8.3.1.1)

2

Application Implementation Cost (From Section 8.3.1.2)

Total Application Cost
8.3.1.1

S. No.

Application License Cost

Software Item/Component

A

B

C

Cost Per Unit

No. of
Units/Licenses

Capital Cost per Software Item
(A * B)

Type of License

Portal Licenses
1

<Item 1>

2

<Item 2>

Ministry of Human Resource Development (MHRD)

Page 73 of 88

<!-- page 74 -->

Request for Proposal (RFP) Volume – 1

S. No.

Software Item/Component

A

B

C

Cost Per Unit

No. of
Units/Licenses

Capital Cost per Software Item
(A * B)

Type of License

Engine Licenses
3

<Item 3>

4

<Item 4>

Others
5

<Item 5>

6

<Item 6>

Application License Cost
8.3.1.2

Application Implementation Cost

S. No.

Item

1

Application Implementation Cost

Price in INR (A)

Total Amount in Words (B)

8.3.2 Cloud hosting and System Software Cost
8.3.2.1

Cloud hosting and System Software Base cost

Please note that the bidder will only be paid the System Software License cost component as MHRD will provide the VMs. However, the total cost in
this section shall be added to Total cost of Ownership for MHRD for evaluation purposes.

Ministry of Human Resource Development (MHRD)

Page 74 of 88

<!-- page 75 -->

Request for Proposal (RFP) Volume – 1

S.
No.

Layer

No. of
VMs
(A)

Upto 25 lakh users
Data Centre
1
App layer
2
DB layer
3
<add more rows>
Data Recovery
4
App layer
5
DB layer
6
<add more rows>

Price per
VM
(B)
INR
4,50,000

VM
Cost
(C=A*B)

No. of
licenses
(D)

Cost per
license
(E)

System
Software
License Cost
(F=D*E)

4,50,000
4,50,000
4,50,000
4,50,000
4,50,000
4,50,000

Sub Total Cost for Year 1
(Total C and Total F)

Total for Year 1 (Total C +
Total F)

8.3.2.2

Type of
System
Software
License

Total F
<to be paid
with Capex>

<to be added
to TCO for L1
calculation>

Cloud hosting and System Software Incremental Cost

Bidder has to mention the number of VMs and licenses that will be required to support every additional 5 lakh users in the system. Please note that
the bidder will only be paid the license cost component as MHRD will provide the VMs. The cost of additional licenses will be paid to the bidder on
actuals. The figures mentioned in this section will not be considered for TCO calculations.

Ministry of Human Resource Development (MHRD)

Page 75 of 88

<!-- page 76 -->

Request for Proposal (RFP) Volume – 1

Price per
VM
VM
S.
Layer
(B)
Cost
No.
INR
(c=A*B)
4,50,000
Incremental cost for 5 lakh users, from 25 lakh upto 50 lakh
Data Centre
7
App layer
4,50,000
8
DB layer
4,50,000
9
<add more rows>
4,50,000
Data Recovery
10
App layer
4,50,000
11
DB layer
4,50,000
12
<add more rows>
4,50,000
No. of
VMs
(A)

Type of
System
Software
License

No. of
licenses
(D)

Cost per
license
(E)

System
Software
License Cost
(F=D*E)

Incremental cost for 5 lakh users, from 50 lakh upto 1.5 crore
Data Centre
13
App layer
4,50,000
14
DB layer
4,50,000
15
<add more rows>
4,50,000
Data Recovery
16
App layer
4,50,000
17
DB layer
4,50,000
18
<add more rows>
4,50,000
Incremental cost for 5 lakh users, from 1.5 crore and above
Data Centre
19
App layer
4,50,000
20
DB layer
4,50,000
21
<add more rows>
4,50,000
Data Recovery
22
App layer
4,50,000
23
DB layer
4,50,000
24
<add more rows>
4,50,000

Ministry of Human Resource Development (MHRD)

Page 76 of 88

<!-- page 77 -->

Request for Proposal (RFP) Volume – 1

Important Note:
1.
2.
3.
4.
5.

No. of users = no. of users registered for at least 1 course.
For the purpose of estimation, the configuration of VMs may be taken as: 16vCPU, 64GB RAM, 60GB Storage.
Out of the total cost calculated in Section 8.3.2.1, bidder will only be paid Total F. This component will be paid as part of Capital Cost.
The total cost discovered in Section 8.3.2.1 will be used for calculation of TCO for discovering L1 cost. The cost of Total C will not be paid to
the bidder.
.
The Cost discovered in Section 8.3.2.2 will be used as and when user load on the SWAYAM system reaches the specified threshold level.

Ministry of Human Resource Development (MHRD)

Page 77 of 88

<!-- page 78 -->

Request for Proposal (RFP) Volume – 1

8.4

Operating Cost/Recurring cost

S. No.

Item

Price in INR (A)

1

Annual Support Cost for System Software (From Section 8.4.1)

2

Annual Support Cost for Applications (From Section 8.4.2)

3

Call Centre Cost (From Section 8.4.3)

4

Capacity Building Cost (From Section 8.4.4)

Total Amount in Words (B)

Operating Cost

8.4.1 Annual Support Cost for System Software
The cost mentioned by the bidder in Section 8.4.1.1 will be paid to the bidder. The cost in Section 8.4.1.2 will only be paid based on actual number of
users in the system as per details mentioned in Section 8.3.2.2.
8.4.1.1

Base Cost for System Software Support

S.
No.

Software Item/Component

AMC for Year I
(A)

AMC for Year II
(B)

AMC for Year III
(C)

Total (A+B+C)

Upto 25 lakh users
Data Centre (DC)
Operating System
Performance Monitoring System
Database Management System
<Please list all proposed System
Software and license details for Data
Ministry of Human Resource Development (MHRD)

Page 78 of 88

<!-- page 79 -->

Request for Proposal (RFP) Volume – 1

S.
No.

Software Item/Component

AMC for Year I
(A)

AMC for Year II
(B)

AMC for Year III
(C)

Total (A+B+C)

AMC for Year II
(B)

AMC for Year III
(C)

Total (A+B+C)

Centre (DC)>
Disaster Recovery (DR)
Operating System
Performance Monitoring System
Database Management System
<Please list all proposed System
Software and license details for
Disaster Recovery (DR)>
Annual Support Cost for System Software

8.4.1.2

Incremental Cost for System Software Support

S.
No.

Software Item/Component

AMC for Year I
(A)

Incremental cost for 5 lakh users, from 25 lakh upto 50 lakh
Data Centre (DC)
Operating System
Performance Monitoring System
Database Management System
<Please list all proposed System
Software and license details for Data
Centre (DC)>
Disaster Recovery (DR)
Operating System

Ministry of Human Resource Development (MHRD)

Page 79 of 88

<!-- page 80 -->

Request for Proposal (RFP) Volume – 1

S.
No.

Software Item/Component

AMC for Year I
(A)

AMC for Year II
(B)

AMC for Year III
(C)

Total (A+B+C)

AMC for Year I
(A)

AMC for Year II
(B)

AMC for Year III
(C)

Total (A+B+C)

Performance Monitoring System
Database Management System
<Please list all proposed System
Software and license details for
Disaster Recovery (DR)>
Annual Support Cost for System Software

S.
No.

Software Item/Component

Incremental cost for 5 lakh users, from 50 lakh upto 1.5 crore
Data Centre (DC)
Operating System
Performance Monitoring System
Database Management System
<Please list all proposed System
Software and license details for Data
Centre (DC)>
Disaster Recovery (DR)
Operating System
Performance Monitoring System
Database Management System
<Please list all proposed System
Software and license details for
Disaster Recovery (DR)>
Annual Support Cost for System Software
Ministry of Human Resource Development (MHRD)

Page 80 of 88
