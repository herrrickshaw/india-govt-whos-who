---
doc_id: "88cddfeeaca6d872"
source_url: "https://mohua.gov.in/static/uploads/2025/11/a3e7dbc9eb637c14b3d2f746411fd8d0.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of *1,58,40,000/- as 2nd installment of Central Assistance to the State Government of Uttarakhand for 15 BLC (New) projects approved in 30th CSMC meeting held on 07.02.2018 under Pradhan Mantri Awas Yojana (Urban) [PMAY (U)] Mission for the f"
date: "2021-03-05"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b2926a16270a112c"
---

<!-- page 1 -->

https://pfins.nic. in/Sanction/Te emplate dvice.aspx?AdviceNum=0B
६५5
PAO(Sectt.)/HUA/ Admin /Advice/2020-21/4/9-/ 7
GOVERNMENT OF INDIA
PAO(Sectt.), Ministry of Housing and Urban Affairs
: 507-c Wing, Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664
To, .
The General Manager,
Reserve Bank of India, [707 ]]
Central Accounts Section, 729
Additional Office Building, 08/03/2021
East High Court Road,
NAGPUR - 440 001
Sir,
Please debit Our account with Rs.1,58,40,000/- (One Crore Fifty Eight Lakh Forty Thousand
Only.) by contra credit to the following accounts Of the Governments with the amounts mentioned
against each:
Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
Name of the State Scheme Code | १००००] Sanction No. and Date
State Code
1 UTTARAKHAND 126 1989-STATE AND UT 1,58,40,000 N-11011/108/2019-
GRANTS UNDER PMAY HFA-I-UD (FTS 9080749)
(URBAN) dated 05/03/2021
Signature of the authorized official
&E. bbe 3}4
(Arfthony, fur’
Sr. Accounts Officer
1. O/o Accountant General (Audit & Accounts), Uttarkhand, Oberoi Motors Building, Sharanpur Road,
2 jra, Dehradun - 248171,
2/Sh. Jagdish Prasad, US (8-1) , M/o Housing and Urban Affairs, New Delhi-110011
Anthony Kujur
Sr. Accounts Officer
a
00 #0-क
D dS
1००: ७9%
(A Mor oho W
pr
HE It
2 fis- |
Ajo
ANH
Mae
1 08-Mar-21 3:01 PM

<!-- page 2 -->

- ae, Ws}
-
(eh
eet seat
हु N-11011/108/2019-HFA-i-UD (FTS: 9080749)
Govemment of india
Ministry of Housing and Urban Affairs
HFA Mission Directorate
(HFA4I Division)
see
Nirman Bhawan, New Delhi.
Dated: es March, 2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan, New Delhi -11
Sub: Release of €1,58,40,000/- as 24 installment of Central Assistance to the State
Government of Uttarakhand for 15 BLC (New) projects approved in 30 CSMC
meeting held on 07.02.2018 under Pradhan Mantri Awas Yojana (Urban)
[PMAY (U)] Mission for the financial year 2020-21 — reg.

Sir,

! am directed to convey the Sanction of the President of India to release of
€1,58,40,000/- (Rupees One Crore Fifty-Eight Lakh and Forty Thousand only) to the
State Government of Uttarakhand as 2™ installment of Central Assistance for 15
BLC (New) projects approved in 30 CSMC meeting held on 07.02.2018 held under
Pradhan Mantri Awas Yojana (PMAY)- Housing for All (Urban) Mission (for
beneficiaries under SC Category) under Allocation for the FY 2020-21.

2. The State Government of Uttarakhand has fumished requisite «utilization
certificate, physical progress of the projects and Action Taken Report on the Third Party
Quality Monitoring report and other necessary compliances as per scheme guidelines for
release of 2" instalment. The fund being released is based on the data entered in MIS
{as on 15.08.2020) out of the list of beneficiaries approved in 30" meeting of CSMC.
Details of the projects are as under:

_ oe , ee _ है ॥1 301

E f Total No. of | Total Total No of | Amount of 1*

Projects Amount of | beneficiaries | instailment of nt of 2

approved by | Central (SC) entered Central शा of

cSMc Assistance | in MIS as on Assistance for

sanctioned | 15-08-2020 teleased for ee ‘ask
beneficiaries
under SC under SC Category
I a | छूछ |

# Project-wise details are annexed.
3. Based on decision of CSMC meeting under Pradhan Mantri Awas Yojana (PMAY) -
Housing for All (HFA) (Urban) Mission and on the recommendations made by MoHUA,
the amount of central grant is being released subject to following conditions alongwith
observations of CSMC:

i. Necessary sanctions/ approvals! compliances required under the statutory or other
regulatory regime as applicable would be obtained by the authority(ies) concemed
with the project(s).

Contd...2/

<!-- page 3 -->

> .
ह ii. The State Government and implementing agency shall put in place a monitoring
system to ensure that the project(s) achieve scheduled milestone and envisaged हि
outcomes including implementation of reforms and other conditionalities required
under the scheme.

ili, Utilize the grant in accordance with the approved guidelines for the implementation of
the Scheme of Pradhan Mantri Awas Yojana (PMAY) - Housing for All (HFA) (Urban)
Mission.

iv. The expenditure on the implementation of the scheme/projects will be shared
between the Centre and the State/ULB/Implementing Agency(IA) as committed. The
committed State share should also be released within 15 days from the date of
receipt of Central Assistance in the SLNA account. In case of shortfall of
State/ULB/IA share, corresponding amount of Central share will be deducted from
the subsequent instalment(s).

v. Furnish the Utilization certificates of the Grant released in the prescribed format as
per GFR — 2017 as provided in the scheme guidelines.

vi. The funds may be utilized for the purpose and within selected categorised
beneficiary for which these are given. Otherwise these will have to be refunded along
with interest as per provisions for GFR-2017.

vil. The State must ensure geo-tagging of photographs to monitor progress of the house
construction before release of each instalment to beneficiaries.

viii. The agencies responsible for implementation of PMAY(U) should get themselves
registered on PFMS portal.

ix. The State Government should validate the demand assessment data and remove the
ineligible beneficiaries in order to make the housing requirement realistic.

x. State to ensure that adequate infrastructure is ensured including individual water,
sanitation and electric connection.

xi. State Government to ensure that there is no duplication / change in the identified
beneficiaries.

xii. Transfer of funds to different entities may be made through PFMS, as applicable; and
where there is an element of cash transfers to individual beneficiaries, the same may
be made through PFMS/DBT mode, as applicable.

xiii. The State Government shall submit the Action Taken Report(ATR) on the
observations/ recommendations of Third Party Quality Monitoring Agency selected
by State for quality monitoring purpose before release of subsequent instalment.

xiv. State Government should ensure that there is no violation of Model Code of Conduct
while releasing funds to Implementing Agencies/ULBs/Beneficiaries.

4. Payment may kindly be made to the State Government immediately. The funds

may thereafter be released to the implementing agencies without any delay failing which

the amounts would be recovered from the State Government with interest for the period
of default.
१...
Contd...3/

<!-- page 4 -->

77 rr थी ख डचच--नञू-बइॉइझआ--टोफि नस न.» मामा,
-3-
us 5. The expenditure involved amount will be debited from the account of the Central
Goverment in the books under the following Head of Account under Demand No. 57
. Ministry of Housing and Urban Affairs for the year 2021-21:
| 3601 __| Grants-in-aid to State Govemments
Sub-MajorHead | 06 Centrally Sponsored Schemes
| 101 |
| 31 |
Detailed Head [| 01 _| Assistance to State Govemments for PMAY(U
31.01.35 | Grants for Creation of Capital Assets
6. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organization(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Auditor General of India under the provision of CAG
(DPC) Act 1971 and intemal audit by the Principal Accounts Office of the Ministry or है
Department, whenever the Institution or Organization is called upon to do so.
है 7. The amount will be credited to the State Government's account in RBI as per
procedure laid down by Ministry of Finance, Department of Expenditure in this regard.
8. This issues with the concurrence of the Finance Division vide their
Note#102 dated 24.02.2021.
9. This sanction has been registered at S.No. HSH 5 '%_ in the Sanction Register of
HFA Mission Directorate (HFA.III Section) of the Ministry of HUA for the year 2020-21.
10. This being the 2" instalment of the grant under PMAY-HFA (U) Mission for these
projects, requisite UCs have been received from the State Government of Uttarakhand.
Yours faithfully,
oned
pret
(Jagdish Prasad)
Under Secretary to the Govemment of India
Tele No. 011-2306 3029
Copy to:-
1. Secretary (Urban Development), Government of Uttarakhand.
2. Director, UD & SUDA, Directorate of Urban Development, Govemment of
Uttarakhand.
३. Accountant General (A&E), Uttarakhand.
4. NITI Aayog, SP Divn. / DR Divn. New Delhi
5. Ofo CGA, Mahalekha Niyantrak Bhawan, New Delhi.
6. CGM, RBI, CAS, Nagpur
7. CCA, MoHUA
8. Budget Division M/o HUA न
9. Director/Deputy Secretary, IFD, Mio HUA
10. Director (HFA-3), MoHUA.
11.. PMU (MIS), HFA Directorate
12. Dy. Chief MIS, HFA Directorate to place this sanction at appropriate place on the
Website of the Ministry. ‘
13. Sanction folder
hang
(Jagdish Prasad)
Under Secretary to the Government of India

<!-- page 5 -->

Hip |i
की 111 है 1118 8 8 8188 |
: Hy a
3/2) all न 7
हर ड ®
Halal
aye] 11 हि है | 8 $ 8 111 ॥$
a AE ry PEEPLES
i 3
ili
FLED EEL EEEEEEE LEE |
aH,
2/3 $3 cle
HL 1111
iil
1 \
ie . ५8 |
डे %
डर 2
TH
SIE =
g| 4 8
(11111 81
é
sli] He (alelalalelalelalalal ali
iL aU LULU UU
HE PE He
ili पर न
3 डे हि | 3 2} 3/8 3
A) eae a aga
5 :
af a ॥ बी बढ
ढे
| ई ee ee)
