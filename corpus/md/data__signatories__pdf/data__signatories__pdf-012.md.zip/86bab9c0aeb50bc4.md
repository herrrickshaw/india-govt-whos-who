---
doc_id: "86bab9c0aeb50bc4"
source_url: "https://mohua.gov.in/static/uploads/2025/10/67e459d2415b6e61d56ed731627c288f.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "THENATIONAL CAPITAL TERRITORY OF DELHI LAWS (SPECIAL PROVISIONS SECOND (AMENDMENT) ACT, 2021)"
date: "2021-03-12"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2224a9004426ca66"
---

<!-- page 1 -->

7fat ie zt u(U+ )04/0007/2003-21

RE GIST E RE D NO. DL (N)04/0007/2003 21

311EI 5 T31971
@he Gazette of 3dia
~.-;,!'t-.-tf".'Qc>[.-3-f.-12032021-225854
CG-DL-E-12032021-225854
37q711UT

EXTRAORDINARY
~ II- ~ 1

PART II Section I

"llTT'tfcfiR "G ~
PUBLISHED BY AUTHORITY
i 6]

z fee+t, paan , mra 12, 2021/9TIT 21, 1942

No. 6]

NEW DELHI, FRIDAY, MARCH 12, 2021/PHALGUNA 21, 1942 (SAKA)

ya

t

(r+ )

a

zq mm j fr
ien sat ? fa fs za srn iaea qi a m r#
Separate paging is given to this Part in order that it may be tiled as a separate compilation.
MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 12th March, 2021/Phalguna 21, 1942 (Saka)
The following Act of Parliament received the assent of the President on the
12th March, 2021, and is hereby published for general information:-

THE NATIONAL CAPITAL TERRITORY OF DELHI LAWS (SPECIAL
PROVISIONS) SECOND (AMENDMENT) ACT, 2021
No. 4 OF 2021
[12h March, 2021.]

An Act further to amend the National Capital Territory ofDelhi Laws (Special
Provisions) Second Act, 2011.
BE it enacted by Parliament in the Seventy-second Year of the Republic of India as
follows:1. (1) This Act may be called the National Capital Territory of Delhi Laws (Special
Provisions) Second (Amendment) Act, 2021.

Short title and
commencement.

(2) It shall be deemed to have been come into force on the 29th day of December, 2020.
20 of 2011.

2. In the National Capital Territory of Delhi Laws (Special Provisions) Second
Act, 2011 (hereinafter referred to as the principal Act), in the long title, for the words, figures
and letters "for a further period up to the 31st day of December, 2020", the words, figures
and letters "for a further period up to the 31st day of December, 2023" shall be substituted.

Amendment
of long title.
