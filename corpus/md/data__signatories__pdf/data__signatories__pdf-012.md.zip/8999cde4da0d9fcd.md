---
doc_id: "8999cde4da0d9fcd"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/a7a41106c6b4cd103cfb240ba067bb2d.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Additional charge of the post of CLC(C) Shri Remis Tiru Additional Chief Labour Commissioner(Central) (1 Aug 2022) (Office Order- 15/2022)"
date: "2022-08-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "92a8a662bcb284a2"
---

<!-- page 1 -->

F. No. A-31011/04/2021 -CLS.I
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan, Rafi Marg,
New Delhi, dated the l 5 t August, 2022
OFFICE ORDER No. 15 /2022

Shri Rem is Tiru , Add itiona l Chief Labour Commissioner( Central) is assigned
th e additional charge of the post of Chief Labour Commissioner(Central) in addition
to his existing duties w ith immediate effect or till the post is filled up on regular
basis or unti l further orders, whichever earlier.

2.

This issues with the approval of Competent Autho rity.

~~ ·

(Satish Chander)
Deputy Secretary to the Government of India

To
1. Shri Remis Tiru, Additio nal Chief Labour Commissioner(Central), New Delhi
2. PS to Hon'ble Union Labour & Employment Minister/PS to MaS (L&E)/PPS to
Secretary (L&E).
3. PPS/PS t o AS/AS&FA/SLEA/DG(Stat)/JS(VB)/JS(KR)/DG( LW)/DDG(E)/ DDG(NKS).
4 . 0/o CLC(C), M/o L&E.
5. CLS -II(Vig)/Vigilance Section (MS).
6. Office Order folder/ Personal fi le of the officer
