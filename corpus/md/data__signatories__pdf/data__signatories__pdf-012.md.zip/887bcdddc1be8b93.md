---
doc_id: "887bcdddc1be8b93"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/de6c15a2f3d7cd85a4781ddcba150eae.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Proposal of MEA for circulation of vacancy notification for the expert positions on the Panel of Experts pursuant to UNSC Resolution 2745-2024"
date: "2025-06-06"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f2ffea483caa0024"
---

<!-- page 1 -->

No.12/I 0/2023-FA(UN)
Government of India
Ministry of Personnel, Public grievances and Pension
Department of personnel & Training
North Block, New Delhi
Dated,the O4uute, 2025
To
1.

Secretaries,
All Ministries/ Department of the Government of India

2.

The Chief Secretaries! Administrators,
All State I UT Governments

Subject: Proposal of MEA for circulation of vacancy notification for the expert positions on the
Panel of Experts pursuant to UNSC Resolution 2745(2024) -reg.
Sir/Madam,
Ministry of External Affairs vide their l.D. Note No. QIPA-l!551108!2025 dated 02.06.2025
(copy enclosed) has informed this Department that United Nations is calling for nomination of
candidates for the expert positions on the Panel of Experts pursuant to UNSC Resolution
2745(2024).
Vacancy notice for the expert positions on the Panel of Experts pursuant to UNSC
2.
Resolution 2745(2024), containing the details, scope, principal functions, skills and expertise for
the post etc. is enclosed. The last date to apply for the above position is 20.06.2025. The
United Nations has requested the member states to request their nominated candidates to apply
online for the above position by 20.06.2025 at the Links duly provided in their enclosed vacancy
notification dated 20.05.2025.
This post may be circulated amongst officers of the level of Joint Secretary, Director
3.
and Deputy Secretary rank (with minimum of 10 years of service) in the Government of India!
State Government, so as to make suitable nominations for the expert positions on the Panel of
Experts pursuant to UNSC Resolution 2745(2024) by following the due procedure duly laid down
in United Nations Vacancy notification dated 20.05.2025 [Copy enclosed]. As the role of DoP&T
in the matter is restricted only upto circulation of vacancy, no further reference with regard to
submission of application need to be sent by the applicants to this Department.
Yours faithfully,

(Sakshi Mittal)
Director(SM)
Emai l-d irsm@nic.in
Copy for information to:
Ms. Risha Oberal, Under Secretary (FSP & Cadre), Ministry of External Affairs, South Block, New
Delhi w.r.t. l.D. Note No. Q/PA-l/551!08/2025, dated 02.06.2025.

<!-- page 2 -->

No. Q/PA-I/551/08/ 2025
Ministry of External Affairs
(Administration Division)
Subject: Deputation of candidates for the expert positions on the Panel of Experts pursuant
to LJNSC ResolutIon 2745 (2024).
The United Nations Secretariat is calling for nomination of candidates for the expert
positions on the Panel of Experts pursuant to UNSC Resolution 2745 (2024).
2.
United Nations has invited member states to recommend candidates for the expert
positions on the Panel of Experts pursuant to UNSC ResolutIon 2745 (2024). The job
positions are anticipated to become available in September 2025 for an initial period of 13
months.
Skills and Expertise:
3.
Candidates should possess a minimum of 10 years of progressively responsible experience,
a)
with a minimum of three years of field experience, in the areas of expertise and competence:
•
Arms
•
Armed groups
•
Natural resources/Finance
•
Humanitarian affairs
•
Regional affairs.
b)

Candidates must be fluent in English and French.

The responsibilities for the post and further requirement! qualifying experience for the
4.
same may be seen atAnnexure A.
Interested candidates are required to apply online. The last date for submission of
5.
nominations and online applications is 20 June 2025.
DoPT is requested to disseminate the above mentioned vacancy circular for the expert
6.
positions on the Panel of Experts pursuant to UNSC Resolution 2745 (2024) amongst the officers
of Joint Secretary, Director and Deputy Secretary rank (with minimum of 10 years of service).

(Risha Oberal)
Under Secretary (FSP & Cadre)
Room No. 37, South Block, New Dcliii
Tel No. 011-23011650
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel and Training
Kind Attn: Director (SM)
Room No. 20, North Block. New Dcliii.
MEA ID Note No. Q/PA-I/55 1/08/2025 dated 02 June 2025

<!-- page 3 -->

t

4.

United Nations

Nations Unies

HEADQUARTERS SIEGE NEW YORK. NY 10017

REFERENCE:

DI'PAISCAD/SCSOB/2025/sCA/ 1/25/(01)

The Secretariat of the United Nations presents its compliments to the Permanent Missions of
Member States to the United Nations and invites Member States to recommend qualified individuals to
serve on the Panel of Experts pursuant to resolution 2745 (2024), subject to the extension of the Panel
mandate by the Security Council in July 2025.
Nominations are sought for expert positions on the Panel of Experts pursuant to resolution 2745
(2024) that will become vacant in September 2025. Recommended candidates should possess a minimum
of ten years of progressively responsible experience, vith a minimum of three years of field experience,
in the following areas of expertise and competence:
•
•
•
•
•

Arms
Armed groups
Natural resources/Finance
Humanitarian affairs
Regional affairs

The selection process will include an interview and other assessment methods to evaluate
candidates' suitability. Sanctions experts are selected on the basis of demonstrated expertise in the
relevant area of work, experience and educational background, with due regard to equitable geographic
representation and gender balance. English and French are the working languages of tile United Nations
Secretariat. For these positions, fluency in English and French is required; knowledge of another UN
official language is an advantage.
Appointment duration is in accordance with the mandate of the expert panel established by the
Security Council. Experts are hired as consultants in line with the United Nations' administrative
instruction concerning consultants and individual contractors (ST/A!/2013/4/Rev.1). For further
information on the Panel of Experts pursuant to resolution 2745 (2024), please
visit: https://main.un.org/securitvcouncil/en/sanctions/2745/pancl-of-experts/work mandate
Member States arc invited to subniit the names and curricula vitae (CVs) of their nominated
candidates, with contact information for three references, to the Security Council Affairs Division in the
Department of Political and Peacebuilding Affairs, United Nations, no later than 20 June 2025, through
the following e-mail address: sc-2745-cominittee@un.ore.
In addition, Member States should request their nominated candidates to apply online by 20
June 2025 at:
•
•
•
•
•

https://careers.un.or/jobSearchDescription/253ô8?lanuaue=en (Arms)
https://careers.un.ori/johSearchDescriplion/258366?langtiatze=en (Armed Groups)
https://careers.un.org/jobSearchDescription/25837 I ?language=en (Humanitarian Affairs)
https://careers.un.orJiobSearchDescription/258369?languaee=fr (Natural Resources / Finance)
Iiitps://careers.un.ore/jobSearchDescription/258372'!languwze=en (Regional Affairs)

<!-- page 4 -->

.4

Only applications received through the online platform will be considered.
In addition to the specific positions above. Member States should also encourage qualified
individuals to apply online to the Security Council Affairs Division Pool of Experts at:
hups://careers. un.ore/jobSearchDescription/ 191928
The Pool of Experts was developed to facilitate the recruitment of qualified individuals, on short
notice, to serve on sanctions monitoring groups, teams and panels established by the Security Council.
Applying to the Pool of Experts will not result in Jirect employment. Similarly, acceptance into the Pool
of Experts does not constitute any guarantee or offer of employment. Enquires about joining the Pool of
Experts may be directed to SCAD-poolofexperts@un.ort.

20 May 2025

UNITED NATIONS

NATIONS UNIES

PACE 2
