---
doc_id: "87fb11acccbb7c76"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/d171157842fef5ece3c2abf5bb385bb2.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Medical Colleges-Reasoned order dated 30.08.2017 - Rohilkhand NEdical College & Hospital Bareilly"
date: "2017-10-31"
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "37d0adf8d908bba0"
---

<!-- page 1 -->

eee Bs tn stall
| ;
| ‘ BY SPEED POST
No.U.12012/134/2015-ME - I [3114018]
: Government of India
ह Ministry of Health & Family Welfare “
(Department of Health& Family Welfare)
Nirman Bhawan, New Delhi-11
Dated the go"August, 2017.
ORDER
Subject: Conditional permission for admission of 5 batch in MBBS course (100 to 150
* seats) for the academic year 2016-17 in respect of Rohilkhand Medical College
& Hospital, Bareilly-Decision of the Central Government.
Whereas the Rohilkhand Medical College & Hospital, Bareilly made application
to the Medical Council of India for renewal of permission for admission of 5‘ batch (100-
150) in MBBS Course for the academic year 2016-17;
2. Whereas the Medical Council of India (MCI) conducted assessment of the college on
49th 8 20th November, 2015 and the assessment report was considered by the Executive
Committee of MCI in its meeting held on 28.12.2015 and following was noted:-
५ ल्‍
1, Deficiency of faculty is 8.78 % as detailed in report.
2. Shortage of Residents is 7.14 % as detailed in report.
3. Data of OPD attendance provided by institute at 1,610 are inflated. Actual
OPD is around 1,000 which is inadequate against requirement of 1,200.
4, Bed occupancy as observed by assessors is 38.75 % (i.e. 279/720) on 1st
day of assessment. Data of 80 % provided by institute are inflated.
5. Total number of actual Major operations on day of'assessment are only 04.
Data of 25 Major operations provided by institute are inflated.
6. Total number of actual Minor operations on day of assessment are only 10.
Data of 70 Minor operations provided by institute are inflated.

7. There was NIL Normal Delivery & NIL Caesarean Section on day of
assessment. There was no woman in Labour room.

8. Data of Radiological & Laboratory investigations as provided by institute
are inflated.

9. Emergency 0.T. is non-functional for last 1 year.

10. Facilities in Central Research laboratory are inadequate.

11 Wards: There is no Demonstration room in male medical ward. In Tb & Chest
ward, distance between 2 beds is < 1.5 m. RHTC: Family folders are not
maintained. Temperature chart is not maintained in cold chain equipment. 2 MSW
& 1 PHN do not have required qualification.

13.UHC: Family folders are not maintained. 2 MSW & 1 PHN do not have required
qualification.

14.Most of the beds in the wards appeara vacant and the bed occupancy is grossly
inadequate.

15. The nursing stations in most of the wards are not in proper place. Staff nurses are
not visible in most of the wards. ‘

<!-- page 2 -->

Ceeee cere ee nc ccc c ccc ccc c ccc ccc ccc cccccccccccccccccccc ccc eas
e
“De

16. The faculty chambers are inadequate for the number of faculty in most
departments.

17.Most of the patients in medical wards are projected as being of dengue fever with
temperature charts revealing normal body temperature. .

18. Most of the patients in medical wards are admitted on account of trivial
complaints which did not warrant admission and are not useful for teaching
purposes.

19.In surgical wards, most of the patients are of vague, mild and occasional pain
abdomen which has not been investigated with any test at all and the patients
does not appear to be in need of admission.

20.Many individuals occupying the beds in surgical wards were presented as patients
but no medical record was available for them and on enquiring from the
individuals, they confirmed that they are not patients but only attendants.

21.Almost all the medical files of admitted patients have similar wordings in the
Nursing notes for three times a day.

22.Some medical files were shown as’patient files but the patients were not traceable
in the ward and were then depicted as having left against medical advise (LAMA)
prior to the inspection. It appears that record of already discharged patients was

a presented as that of currently admitted patients. However, this was not supported
by the physical presence of these patients.

23.Most of the patients in the OT lists of different surgical departments for the day of
inspection were not present in the Operation theatre or in the wards

24.None of the patients of the previous days surgery OT list were present in the
ward/surgical ICU.

25.The PAC room appears uninhabited and has no doctor, register or any equipment.
26.In Ophthalmology ward, none of the patients of OT list of previous two days (26%
and 27th October, 2015) are available in the ward nor were any of them
discharged as per the discharge register.
27.1n TB and Chest, there are 3 postgraduate seats. However, there are no Professors
or Associate Professors which grossly affects undergraduate and postgraduate
teaching.
28,In the Deptt. of Radiodiagnosis, the yearly PG intake is 2 and there is no Professor.
This adversely affects PG teaching & UG teaching.
29.In Dermatology, the PG intake is three while there are only two Professors. This
adversely affects PG teaching & UG teaching.
3. Whereas, based on the above, the MCI vide letter dated 31.12.2015 recommended
to the Central Govt. not to renew permission for admission of 5 batch (100-150 seats) in
MBBS course at Rohilkhand Medical College & Hospital, Bareilly for the academic
session 2016-17;
4. Whereas, u/s 10 A (4) of IMC, Act, 1956, the Ministry afforded an opportunity of
hearing to the college before a personal hearing committee on 19.01.2016 and the matter
was referred back to the MCI for review;
हे 5. Whereas the compliance verification assessment of the College was carried out by
Council’s assessors on 30.03.2016 and the compliance verification assessment report was
‘considered by the Executive Committee of MCI in its meeting held on 13.05.2016 and
छा following was noted:- v

<!-- page 3 -->

OOO OL EO 335 लक.
e Be

1. Shortage of Residents is 9.30 % as detailed in the report.

2. On random verification, it was observed that at least 4 Senior Residents are not
staying in the campus. Many other Senior Residents who are above 60 y of age
are also not staying in the campus.

3. OPD data provided by institute are highly inflated. Assessors visited OPD at 10
a.m., 12 noon & 1 p.m. and very few patients were seen in OPD during all 3
visits. Actual OPD attendance on day of assessment was around 750 on day of
assessment against requirement of 1,200.

4. Bed occupancy was 45 % on day of assessment.

5. Many patients were admitted on 28/03/2016 & 29/03/2016 as verified from case
sheets. In many patients who were admitted day before assessment, complaints

did not match with treatment mentioned on case paper. In General Surgery
ward, 20 patients were admitted the day before with trivial complaints and had
not received even oral drugs and post admission investigations were not carried
out.

6. Total number of Major operations on day assessment is only 06 which is
inadequate. .

7. Total number of Minor Operations as verified by assessors was only 01; however,
the register showed 05 Minor operations.

8. There was NIL Normal Delivery & NIL Caesarean Section on day of assessment.

9. Data of Clinical Material, Radiological & Laboratory investigations as provided by
institute are inflated.

10. Emergency O.T. is non-functional.

‘ 11. Facilities in Central Research Laboratory are inadequate.
12, Patients in Paediatrics ward were of adult age and case sheets did not match with
complaints & treatment.

13. Nursing stations are not in proper places in many wards.

14. Medical files of many admitted patients have similar wordings in the Nursing
notes. One such file is of patient named Jyoti.

15. Workload of Special investigations like Ba, IVP was NIL on day of assessment.

16. Other deficiencies as pointed out in the assessment report.

In view of the above, the Executive Committee of the Council decided to
recommend to the Central Govt. not to renew the permission for admission of
5th Batch of MBBS students against the increased intake i.e. from 100-150 in
respect of Rohilkhand Medical College & Hospital, Bareilly under M.J.P
Rohilkhand University, Bareilly u/s 10A of the IMC Act, 1956 for the academic
year 2016-2017.

The Executive Committee of the Council further decided to apply clause
8(3)(1)(c) of Establishment of Medical College Regulation
(Amendment),2010(Part II), dated 16th April, 2010 and amended on 18th
March, 2016,

6. | Whereas MCI vide letter dated 15.5.2016 recommended to the Central Government
not to renew the permission for admission of 5th batch against increased intake from
100-150 in MBBS course at Rohilkhand Medical College & Hospital, Bareilly for the
academic session 2016-17 u/s 10A of the IMC Act, 1956 for the academic year 2016-
2017. LV

<!-- page 4 -->

‘
wile
7. Whereas the Ministry accepted the recommendation of MCI issued letter dati
10.06.2016 directing the College not to take admission of 5 batch against increas:
intake from 100-150 in MBBS course at Rohilkhand Medical College & Hospiti
Bareilly for the academic session 2016-17.
8. | Whereas on Oversight Committee (OC) directive, the Ministry obtained complian
from the college afresh and forwarded it to MCI. MCI returned the compliance citi)
various reasons. Ministry forwarded the reply of MCI to OC.
9. Whereas the OC vide its letter dated 12.08.2016 approved the renewal
permission for admission of 5th batch against increased intake from 100-150 in MB]
. course at Rohilkhand Medical College & Hospital, Bareilly for the academic sessi:
2016-17 with certain conditions;
10. Whereas the Central Government on the approval of the OC issued necessary lett
for renewal of permission on 20.08.2016 for admission of 5th batch (100-150 seats)
« MBBS course at Rohilkhand Medical College & Hospital, Bareilly for the academic ye
2016-17 with conditions imposed by the OC;
11 Whereas the Executive Committee of the Council in its meeting held on 21.03.20
noted that upon receipt of the request through the Central Govt. u/s 11(2) of the IMC A
1956, the assessments to assess the standard of examination held by Mahatma Jyoti
Phule Rohilkhand University, Bareilly and to assess the physical and the other teachi
facilities available for recognition/approval of Rohilkhand Medical College & Hospit
Bareillyfor the award of MBBS degree granted by Mahatma Jyotiba Phule Rohilkha)
# University, Bareilly against the increased intake i.e. from 100 to 150 seats u/s 11(2) of t
IMC Act, 1956 and Compliance Verification Assessment for renewal of permission f
admission of 5th batch of MBBS students against the increased intake i.e. from 100
150 seats u/s 10A of the IMC Act, 1956 for the academic year 2016-17 with reference
the conditional approval accorded by Oversight Committee have been carried out by t
Council assessors on (23.02.2017) and (16th & 17th March, 2017) and noted ti
following:-
1. Deficiency of faculty is 10.7% as detailed in the report.
2. Shortage of residents is 6.97% as detailed in the report.
3. Bed Occupancy was 36.62% at 10 a.m. on day of assessment.
4. ICUs: There were only 1 patient in SICU, PICU & only 2 patients in ICCU. PICU
not well equipped.
5. There were only 12 Major Operations for the whole hospital on day
assessment.
6. There was NIL woman in the Labour room at time of taking round at 11.30 a.m
5 7. Wards : Nursing stations are not properly placed and are non-functional in sor
wards. Teaching rooms are common for 203 wards in a few departments.
12. Whereas, the MCI vide letter dated 24.03.2017 has informed and recommended
the Ministry as under:- (५

<!-- page 5 -->

¢ dBi.

In view of the above, the college has failed to abide by the undertaking it had given
to the Central Govt. that there are no deficiencies as per clause 3.2(i) of the directions
passed by the Supreme Court mandated Oversight Committee vide communication
dated 13/08/2016. The Executive Committee, after due deliberation and discussion, has
decided that the college has failed to comply with the stipulation laid down by the
Oversight Committee. Accordingly, the Executive Committee recommends that as per
the directions passed by Oversight Committee in para 3.2(b) vide communication dated
13/08/2016 the college should be debarred from admitting students in the above course
for a period of two academic years i.e. 2017-18 & 2018-19 as even after giving an
undertaking that they have fulfilled the entire infrastructure for Rohilkhand Medical
College & Hospital, Bareilly for the award of MBBS degree granted by Mahatma Jyotiba
Phule Rohilkhand University, Bareilly against the increased intake i.e. from 100 to 150

' seats u/s 11(2) of the IMC Act, 1956 and Compliance Verification Assessment for
renewal of permission for admission of 5th batch of MBBS students against the
increased intake i.e. from 100 to 150 seats u/s 10 A of the IMC Act, 1956 for the
academic year 2016-17.,the college was found to be grossly deficient. It has also been
decided by the Executive Committee that the Bank Guarantee furnished by the college in
pursuance of the directives passed by the Oversight Committee as well as GOI letter
dated 20/08/2016 is liable to be encashed.

13. Whereas the Ministry granted personal hearing to the College on 11.04.2017 by the

Hearing Committee in DGHS. The Hearing Committee after considering the oral and

written submission of the College submitted its report to the Ministry. In its report, the
¢ Hearing Committee observed as under:

(s. ]
Deficiency of faculty is 10.7% as | Reply not satisfactory. Deficiency persists
detailed in the report.

Shortage of residents is 6.97% as | Reply not satisfactory. Deficiency persists
detailed in the report.
Bed Occupancy was 36.62% at 10 | Reply not satisfactory. Deficiency persists
a.m. on day of assessment.
A IV. | ICUs : There were only 1 patient in | Reply not satisfactory. Deficiency persists
SICU, PICU & only 2 patients in ICCU.
PICU is not well equipped.
V. | There were only 12 Major Operations | Reply not satisfactory. Deficiency persists
for the whole hospital on day of
assessment.
VI. | There was NIL woman in the Labour | Reply not satisfactory. Deficiency persists
room at time of taking round at 11.30
a.m.
VII. | Wards : Nursing stations are not Reply not satisfactory. Deficiency persists
properly placed and are non-
functional in some wards. Teaching “
rooms are common for 203 wards ina
few departments

<!-- page 6 -->

¢
-6- ‘
14, Whereas the Ministry after considering the recommendation of MCI and Hearing
report, decided to debar the College for admitting students for two academic years ie
2017-18 & 2018-19 and also to authorize the MCI to encash the Bank Guarantee of Rs. 2.00
Crore. Accordingly, the decision was communicated to the College vide Ministry's letter
dated 31.05.2017. ~
15. Whereas the college filed WRIT (C) No. 30074 of 2017 in the Hon’ble Allahabad
High Court and the Court gave the following direction on 19.08.2017:-
We adjourn the matter for a period of three weeks allowing the counsel for the
Union of India and Medical Council of India to file counter affidavit to the writ
petition as well as to the miscellaneous application. However, we are to the
opinion that the petitioner is entitled for further interim relief as given by the
Supreme Court in the case of Glocal Medical College & Super Specialty Hospital &
Research Centre Vs. Union of India & Another dated 15t August, 2017 relevant
paragraph 25 is extracted herein under:-
“25.In the above persuasive premise, the Central Government is hereby
t ordered to consider afresh the materials on record pertaining to the issue of
confirmation or otherwise of the letter of permission granted to the
petitioner colleges/institutions, We make it clear that in undertaking this
exercise, the Central Government would re-evaluate the
recommendations/views of the MCI, Hearing Committee, DGHS and the
Oversight Committee, as available on records. It would also afford an
opportunity of hearing to the petitioner colleges/institutions to the extent
necessary. The process of hearing and final reasoned decision thereon, as
ordered, would be completed 21 peremptorily within a period of 10 days from
today. The parties would unfailingly co-operate in compliance of this
direction to meet the time frame fixed”
In the light of the aforesaid direction of the Supreme Court, this Court directs
the Central Government to re-evaluate the recommendations/Views of the
MCI, Hearing Committee, DGHS and the Oversight Committee within two
weeks from the date of production of certified copy of this order.
16. Now, therefore, in compliance with the above direction of Hon’ble High Court, the
Ministry granted hearing to the college on 24.8.2017. The Hearing Committee submitted
its report to the Ministry with the following conclusion:-
“The request of the college was that they are recognized for 100 seats and
have also become due for recognition for increased intake from 100 to 150. The college
further claimed that MCI has sought compliance after inspection on 24.04.2017 and in
the meanwhile, the college has been debarred for 2 years vide order dated 31.05.2017
without affording them a chance for submitting compliance. Debarring the college for
2 years for 50 additional seats and encashment of bank guarantee is harsh.
Vv

<!-- page 7 -->

as 2
- The Committee has noted that compliance verification of the college was
carried out by MCI on,17-18 March, 2017. MCI has conducted another compliance
inspection on 24.04.2017 wherein the deficiencies pointed out in 17-18 March
inspection have been verified.

On perusal of both the reports the Committee notices that the deficiency of
residents, ICU, number of patients and nursing station in wards have been rectified.
While bed occupancy is recorded at 82.36%, the assessors have also noted that a large
number of patients did not seem to require admission.

The main deficiency regarding faculty has increased from 10.7% to 14.46%
which includes 5 faculty and 18 tutors. The contention of the college was that PG
students in pre and para clinical subjects may be counted as tutors. However, the
Committee is not agreeable since PG students get stipend as residents while tutor
being a faculty gets salary. The Committee further noted college document dated
18.05.2017 issued to the OBC Branch, Bareilly which indicates stipend being paid to PG
students in non clinical subjects.

हे In view of the continued deficiency of faculty, the Committee agrees with the
Ministry order dated 31.05.2017. However, it may be added that compliance
¢ inspections under Section 11(2) of the IMC Act, 1956 have been conducted by MCI and
हे compliance has been sought. In the given facts, MCI may expedite recognition process
for the increased intake but till that time debarment on 50 additional admissions may
continue.”
17. Accepting the recommendations of the Hearing Committee, the Ministry (s+
reiterates its earlier decision dated 31.05.2017 to debar the Rohilkhand Medical
College & Hospital, Bareilly from admitting students against increased intake from 100-
150 for two academic years i.e. 2017-18 & 2018-19 and authorizes MCI to encash Bank
Guarantee of Rs. 2.00 Crore.
QN 1
(D VK Rao)
Under Secretary to the Govt. of India
Telefax: 011-23062959
To
The Principal/Dean,
Rohilkhand Medical College & Hospital,
Pilibhit Bypass Road, Opp-Suresh Sharma Nagar,
Bichpuri Rao,
Bareilly-243006,
Uttar Pradesh

<!-- page 8 -->

कटा मम मी कील लक कलम E——————————————————EEE>_——
‘
-8-
: Copy to:
1. The Principal Secretary,(Health & FW), Department of Health & Famliy Welfare, Govt. of
Uttar Pradesh, 5th Floor, Room No:516, Vikas Bhawan, Lucknow-226001 (Uttar Pradesh).
2. The Secretary, Medical Council of India, Pocket-14, Sector-8, Dwarka, New Delhi-75.
3. The Registrar, Mahatna Jyotiba Phule Rohilkhand University, Bareilly, Uttar Pradesh .
4. The Director General, Medical Education, Government of Uttar Pradesh, Lucknow, U.P.
5. The ADG (ME), Dte.GHS, Nirman Bhawan, New Delhi
«
