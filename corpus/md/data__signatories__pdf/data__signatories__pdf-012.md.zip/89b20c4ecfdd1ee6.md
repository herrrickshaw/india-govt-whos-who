---
doc_id: "89b20c4ecfdd1ee6"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/3e6ec6a952a678bdc4bf8d5dfb331f05.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Toys (Quality Control) Second Amendment Order, 2020"
date: "2025-07-14"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ab6ae337c38c4f44"
---

<!-- page 1 -->

637
276670/2020/LEI
रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-11122020-223659
xxxGIDHxxx
CG-DL-E-11122020-223659
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3967]
No. 3967]

नई ददल्ली, िुक्रवार, ददसम्बर 11, 2020/अग्रहायण 20, 1942
NEW DELHI, FRIDAY, DECEMBER 11, 2020/AGRAHAYANA 20, 1942

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)
आदेि
नई ददल्ली, 11 ददसम्बर, 2020
का.आ. 4514(अ).—भारतीय मानक ब्यूरो अजधजनयम, 2016 (2016 का 11) की धारा 25 की उप-धारा (3) के
साथ परित धारा 16 की उप-धाराओं (1) और (2) द्वारा प्रदत्त िजियों का प्रयोग करते हुए, ब्यूरो से परामिध करने के बाद
कें द्र सरकार की राय है दक ऐसा करना िनजहत में आवश्यक है, अत: एतद्द्वारा जखलौना (गुणवत्ता जनयंत्रण) आदेि, 2020 में
संिोधन के जलए जनम्नजलजखत आदेि करती है, नामत: 1.

संजिप्त िीर्धक और प्रारं भ - (1) इस आदेि को जखलौना (गुणवत्ता जनयंत्रण) जद्वतीय संिोधन आदेि,

2020 कहा िाएगा।
(2) यह सरकारी रािपत्र में प्रकािन की तारीख से प्रभावी होगा।
2. जखलौना (गुणवत्ता जनयंत्रण) आदेि, 2020 के पैरा 3 में, परं तुक के पश्चात, जनम्नजलजखत परं तुक को िोडा
िाएगा, नामतः –

6078 GI/2020

(1)

<!-- page 2 -->

638
276670/2020/LEI
2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

“बिते दक इस आदेि से कु छ भी, वस्त्र मंत्रालय, भारत सरकार के अंतगधत जवकास आयुि (हस्ट्तजिल्प) कायाधलय में
पंिीकृ त कलाकार द्वारा जवजनर्मधत और बेचे िाने वाली वस्ट्तु या सामान पर लागू नहीं होगा:
बिते दक इस आदेि से कु छ भी, उद्योग संवधधन और आंतररक व्यापार जवभाग, वाजणज्य और उद्योग मंत्रालय,
भारत सरकार के अंतगधत भौगोजलक संकेतक पंिीयक, पेटेंट, जडिाइन और रेडमाकध महाजनयंत्रक (सीिीपीडीटीएम)
कायाधलय द्वारा भौगोजलक संकेतक के रुप में पंिीकृ त उत्पाद के पंिीकृ त स्ट्वामी और प्राजधकृ त उपयोगकताध द्वारा जवजनर्मधत
और बेचे िाने वाली वस्ट्तु या सामान पर लागू नही होगा”।
[फा. सं. पी-11(4)/2017-सी.आई]
अजनल अग्रवाल, संयुक्त सजचव
नोटः मुख्य आदेि को ददनांक 25 फरवरी, 2020 के सां. आ. 853 (अ) द्वारा भारत के रािपत्र असाधारण, भाग II,
खंड 3, उपखंड (ii) में प्रकाजित दकया गया था और इसे अंजतम बार ददनांक 15 जसतंबर, 2020 की अजधसूचना
संख्या सां. आ. 3146 (अ) द्वारा संिोजधत दकया गया था।

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry & Internal Trade)
ORDER
New Delhi, the 11th December, 2020
S.O. 4514(E).—In exercise of the powers conferred by sub-sections (1) and (2) of section 16 read with subsection (3) of section 25 of the Bureau of Indian Standards Act, 2016 (11 of 2016), the Central Government, after
consulting the Bureau, is of the opinion that it is necessary so to do in the public interest, hereby makes the following
Order further to amend the Toys (Quality Control) Order, 2020, namely:1. Short title and commencement.– (1) This Order may be called the Toys (Quality Control) Second Amendment
Order, 2020.
(2) It shall come into force on the date of its publication in the Official Gazette.
2. In the Toys (Quality Control) Order, 2020, in Paragraph 3, after the proviso, the following proviso shall be
inserted, namely:“Provided further that nothing in this Order shall apply to goods or articles manufactured and sold by Artisans
registered with Office of the Development Commissioner (Handicrafts), under Ministry of Textiles, Government of
India:
Provided further that nothing in this Order shall apply to goods or articles manufactured and sold by Registered
proprietor and Authorised user of a product registered as Geographical Indication by the Registrar of Geographical
Indications, Office of Controller General of Patents, Designs and Trademarks (CGPDTM), under Department for
Promotion of Industry and Internal Trade, Ministry of Commerce and Industry, Government of India.
[F.No. P-11(4)/2017-C.I]
ANIL AGRAWAL, Jt. Secy.
Note: The principal order was published in the Gazette of India, Extraordinary under Part II, Section 3, sub-section
(ii) vide number S.O. 853(E), dated the 25 th February, 2020 and last amended vide notification number S.O.
3146(E), dated the 15th September, 2020.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
