---
doc_id: "89dbdc8bd8f0f5b5"
source_url: "https://www.mdoner.gov.in/static/uploads/2025/08/28a829444c8662c93599296906947bcb.pdf"
ministry: "Development of North Eastern Region (MDONER)"
title: "SCHEMES OF NEC Guidelines (3rd-January-2024)"
date: "2024-01-03"
pages: 36
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "540311b0bf0e6b5a"
---

<!-- page 1 -->

No. NEC-11/2/2023-UNDER SECRETARY(A)
Government of India
Ministry of Development of North Eastern Region
ROR AK
Vigyan Bhawan Annexe,
Maulana Azad Road,
New Delhi-110 011.
se
Dated: thed/.August, 2023
To
The Chief Secretaries,
All the North Eastern States
Subject: Guidelines for administration of the Schemes of North
Eastern Council (NEC) of the Ministry of Development of
North Eastern Region.
Madam/ Sir,

I am to refer to the subject cited above and to forward herewith for
information and necessary action the newly-formulated Guidelines, duly
approved by the Competent Authority, for administration of the Schemes
of NEC of the Ministry of Development of the North Eastern Region.

Encl: As above.
Yours faithfully,
sae Dey)
Joint Secretary to the Government of India
Copy to:
(i) Chief Executive Officer, NITI Aayog.
(ii) Home Secretary.
(iii) Finance Secretary.
(iv) Foreign Secretary.
(v) Secretary, Department for Promotion of Industry and Internal
Trade.
(vi) Secretary, North Eastern Council.

<!-- page 2 -->

Copy also to:
1. PS to Hon’ble Minister, MDoNER.
2. APS to Hon‘ble MoS, MDoNER.
3. PPS to Secretary, MDoNER.
4. PPS to AS&FA, MDoNER
5. PSs to Sr, EA, JS(AD), JS(HS), JS(AC)
6. All Directors/ Deputy Secretaries/ Joint Director in MDoNER.
7. Technical Wing, MDoNER
8. Sr. Director, NIC for uploading on the website of the Ministry
wl Dey)
Joint Secretary to the Government of India

<!-- page 3 -->

५५
GUIDELINES FOR ADMINISTRATION OF “SCHEMES OF NORTH EASTERN
COUNCIL(NEC)”

1. Background
1.1 A Central Sector scheme named “Schemes of North Eastern Council (NEC),
fully funded by the Government of India, has been under implementation since
10° Finance Commission period and was continued till 31.03.2022 to fill up gaps
in overall development of the Region.
1.2 The approval for extension of “Schemes of NEC” Scheme w.e.f. 01.04.2022
till 31.03.2026 has duly been considered and accorded. During the process of
extension of the “Schemes of NEC” w.e.f. 01.04.2022, no major change in the
scope/coverage of the scheme has been conveyed.
1.3 The extant guidelines for the “Schemes of NEC” were first formulated in 2010
as NEC General Guidelines, which were revised subsequently in 2015, 2017 and
2020. Although, no major change in the scope/coverage of the scheme has been
conveyed by the EFC except few general guidelines for making all the MDoNER
Schemes more effective and rational, revision of guidelines for the scheme is
necessitated, which are detailed in the subsequent paras.
1.4 The guidelines hereafter will take effect from 01.04.2022; while the existing
“NEC General Guidelines - 2020” shall ipso facto continue to apply for the ongoing
projects sanctioned till 31-03-2023; subject further to the removal of difficulties,
if any, with the approval of the Competent Authority.
1.5 Saving Clause for ongoing projects / committed liabilities

Projects that were sanctioned when the “NEC General Guidelines - 2020” were
in effect, will continue to be administered as per those guidelines. The
prioritization/ selection/appraisal and recommendation by Standing Finance
Committee (SFC!!!) and approval of SFC recommendation by the competent
authority during 2022-23 in accordance with the recommendations of EFC for
2022-23 to 2025-26 shall be deemed to have been made under the Scheme
mentioned in the sanction/ approval letter; and such prioritization/ selection/
selection for sanction/ approval of the Project made in 2022-23 will be
accommodated under the Guidelines applicable at that time.
2. Administration of “Schemes of NEC”
2.1°Schemes of NEC” will cover all the eight states of the North Eastern Region
of India, viz. Arunachal Pradesh, Assam, Manipur, Meghalaya, Mizoram,
Nagaland, Sikkim and Tripura.
2.2 The “Schemes of NEC” will be over and above the existing schemes of
Government of India and State Governments of the NE Region. However, only
those projects would be considered for financial assistance under the scheme

(hy
Page 1 of 34

<!-- page 4 -->

which are not covered/ taken up under any other scheme of Central Government
or State Government.
2.3 MDoNER/NEC within their delegated powers will administer the “Schemes
of NEC” towards selection, sanction and monitoring of projects under the scheme,
in consultation with the State Governments concerned. The steps for planning,
implementation will be taken through the Implementing Agencies (IA) of the
respective North Eastern State Government/Central Agencies.
2.4 The following guidelines detail the process to be followed for projects to be
covered under “Schemes of NEC” scheme component covering, inter alia,
(a) Components under “Schemes of NEC” and inter se allocations
(b) The Normative allocation for each of the States where ever
applicable
(c) Identification and prioritization of project proposals by the State
with the approval of State Level Empowered Committee (SLEC) chaired
by Chief Secretary or by central agencies and submission of project
proposals (for selection) to NEC
(d) Selection of the candidate projects by NEC through Sectoral
Empowered Committee (SEC)
(e) Preparation of DPRs by the States/ Central Agencies and
submission to NEC for techno-economic appraisal, and approval of the
DPRs by the NEC
(f) | Sanction of projects by the Ministry/NEC as per their delegated
Financial powers
(g) Award of works by Implementing Agencies
(h) Release of funds under the scheme
(i) | Monitoring and Evaluation Mechanism
(j) Completion and operationalization of projects
2.5 The Hon'ble Minister, MDoNER will be the ‘Competent Authority’ for the
scheme, unless specified otherwise.
3. Objectives
In keeping with the overall vision of the Ministry of DoNER i.e. “Transforming the
North Eastern Region through Development, in an Accelerated yet Sustainable
manner, affording access to ease of living to all its citizens”, the broad objective
of “Schemes of NEC” is to support overall development in identified sectors of
importance to the North Eastern States, as specified in Annexure - I of these
guidelines.
4, Institutional and Administrative Arrangements
Following committees will be constituted under the scheme:
os
Page 2 of 34

<!-- page 5 -->

a. State Level Empowered Committee (SLEC) - for
prioritization of projects by States and recommending them
to NEC/MDoNER

b. Sectoral Empowered Committee (SEC) at NEC Level, chaired
by concerned Member(NEC), for prioritization/selection of
projects, as indicated at Annexure-IT.

c. Empowered Inter-Ministerial Committee (EIMC) at NEC Level,
chaired by Secretary, NEC, for sanction/approval of
projects between Rs.5 crore to Rs.15 crore

d. Empowered Inter-Ministerial Committee (EIMC) at Central
Level, chaired by Secretary, DoNER for the following:

i.  sanction/approval of projects beyond 15 crores and up
to Rs. 100 crores;
ii. recommending to the Approving Authority, projects
exceeding Rs.100 crores and up to Rs.500 crores"!
Note:

1. Projects under ‘Schemes of NEC’ are not expected to exceed the
above thresholds. However, if projects above Rs.500 crore are
posed under the scheme, an Expenditure Finance Committee (EFC)
will need to be convened, as per the delegation of powers detailed
at Annexure-II.

2. For projects less than Rs.5 crore, the projects will be appraised by
Financial Advisor of NEC and approved by Secretary, NEC.

4.1 State Level Empowered Committee (SLEC)

4.1.1. The State Governments will constitute a State Level Empowered
Committee (SLEC) chaired by Chief Secretary of the State with members as
under:

i. Chief Secretary - Chairperson

ii. Secretary Planning, State Govt. - Member Secretary

iii. Secretary, Finance, State Govt.

iv. Secretaries of the concerned department in State
Government

y. Technical members as deemed necessary by the State

Government
The NEC may also depute its representatives for the SLEC meetings, generally
not below the rank of DS/Director, including one from FA, NEC, as special invitees.
4.1.2 Functions of the SLEC
The functions of SLEC shall be as under:

i. To consider and prioritise the project proposals submitted by
the State Departments and make suitable recommendations
to NEC for Selection/prioritization of the projects.

0 - Page 3 of 34

<!-- page 6 -->

ii. | Regular review and monitoring of projects sanctioned under
“Schemes of NEC” and other schemes of the MDoNER/NEC,
resolving bottlenecks, if any, in timely completion of these
projects sending regular/periodic reports in this regard to
MDOoNER/NEC.

iii. Improving/ strengthening project management system with a
view to avoid cost and time overruns.

iv. Such other miscellaneous matters connected with the
implementation of “Schemes of NEC” and other schemes of
the MDoNER, as considered necessary.

4.1.3 Meetings of SLEC
SLEC will meet as frequently as needed, but at least once in three
months. SLEC can meet physically, virtually or in hybrid mode.
4.2 Sectoral Empowered Committee (SEC) at NEC Level
4.2.1 All projects posed under “Schemes of NEC” that fall within the purview of
the concerned Member (NEC) will be posed before a Sectoral Empowered
Committee (SEC) headed by the respective Member(NEC). The SEC will be
constituted at NEC, which shall be headed by the concerned Member (NEC), as
per the notification with respect to the subject allotted to them. The members of
the SEC would be as under:

i. Concerned Member (NEC) - Chairperson

ii, Secretary, NEC

iii. Financial Adviser, NEC

iv. Economic Adviser, NEC

vy. Concerned Sectoral Head, NEC

vi. Planning Adviser, NEC - Member Convenor

Note: Representatives from the concerned Technical Wing of NEC may also be
specially invited to the respective meetings of the SEC.

4.2.2 Functions of the SEC

The functions of SEC shall, inter alia, be as under:

i. SEC will review the project proposals placed before it by the
Concerned sector of NEC duly scrutinized after submission by the
States duly prioritized by the SLEC and select the proposal for
preparation of DPR and further processing for sanction as per
scheme guidelines and upto the funds available for new sanction
under the Scheme.

ii. To consider the preliminary project proposals received under
‘Schemes of NEC’, in terms of their quality, viability and tangible
socio-economic impact together with the representatives of
concerned line departments of Government of India and State

ch ¥ Page 4 of 34

<!-- page 7 -->

Governments; and make suitable recommendations for selection
from amongst the candidate projects
iii. To consider the final project proposals received from the
SLECs/Sectoral teams at NEC, together with the comments of the
concerned central line departments and make suitable
recommendations for approval of the Competent Authority
iv. To recommend effective means for Monitoring and Evaluation
through field inspection inter alia through suitable third-party
agencies
y. To review the progress of project implementation under “Schemes
of NEC”, through the North Eastern Council (NEC) as well as the
SLEC
vi. To suggest suitable mechanisms for Operation and Maintenance
(O&M) of the projects undertaken under ‘Schemes of NEC’
4.2.3 Meetings of SEC
SEC will meet as frequently as needed, but at least once in three months. SEC
can meet physically, virtually or in hybrid mode, at New Delhi or at any other
place in the NER.
4.3. Empowered Inter-Ministerial Committee (EIMC) at NEC Level
4.3.1 There will be an Empowered Inter-Ministerial Committee (EIMC), chaired
by the Secretary, NEC, with member representative from concerned NE States
and relevant line Ministries, as indicated below:

i. Secretary, NEC - Chairperson;

ii. Concerned State Representative not below the Rank of
Secretary - Member;

iii. Representative of NITI Aayog - Member;

iv. Representative, D/o Gati shakti, Department for
Promotion of Industry and Internal Trade - Member;

v. Representative(s) of line Ministries/
Departments/organizations concerned with the project/
subject - Member;

vi. Advisor (Planning), NEC - Member;

vii. Financial Adviser, NEC - Member;
viii. Economic Advisor, NEC - Member;

ix. Representative of Ministry of Development of North
Eastern Region not below the rank of Director/ DS -
Member

4.3.2 Functions of the EIMC at NEC Level
The functions of EIMC at NEC Level shall, inter alia, be as under:
0 >
Page 5 of 34

<!-- page 8 -->

i To appraise/sanction the project proposals received from concerned
sectors of NEC along with all the requisite certificates and documents,
duly recommended.
ii. To consider any issue concerned with implementation of “Schemes of
NEC” and/or projects sanctioned under it and make suitable
recommendations,
iii. To review the progress of implementation of the projects under
“Schemes of NEC”
iv. Such other miscellaneous matters connected with the implementation
of “Schemes of NEC”, as considered necessary
4.3.3 Meetings of EIMC at NEC Level
EIMC will meet as frequently as needed, but at least once in three months.
EIMC can meet physically, virtually or in hybrid mode, at Shillong or at any
other place in the NER.
4.4 Empowered Inter-Ministerial Committee (EIMC) at Central Level
4.4.1 There will be an Empowered Inter-Ministerial Committee (EIMC), chaired
by the Secretary, Ministry of Development of North Eastern Region, with member
representative from concerned NE States and relevant line Ministries, as indicated
below:

i. Secretary, Ministry of Development of North Eastern Region —

Chairperson;

ii. Chief Secretary of concerned North Eastern State or his
representative not below the Rank of Principal Secretary in the
State - Member;

iii. Chief Executive Officer of NITI Aayog or his/her representative
not below the rank of Joint Secretary - Member;

iv. Home Secretary or his/ her representative not below the rank
of Joint Secretary - Member;

v. Secretary, Logistics, DPIIT or his representative not below the
rank of Joint Secretary- Member;

vi. Representative(s) of line Ministries/ Departments/organizations
concerned with the project/ subject in question not below the
rank of Joint Secretary - Member;

vii. Secretary, North Eastern Council - Member;

viii. Financial Adviser, Ministry of Development of North Eastern
Region - Member;

ix. Joint Secretary in-Charge of NEC in the Ministry of Development

of North Eastern Region - Member Secretary.
Note: Representatives of the State Government(s), Central Ministries / NEC, etc.
may be co-opted by the EIMC as and when felt necessary.
0५
Page 6 of 34

<!-- page 9 -->

4.4.2 Functions of the EIMC at Central Level
The functions of EIMC at Central Level shall, inter alia, be as under:

i. To consider the preliminary project proposals received under ‘Schemes
of NEC’, in terms of their quality, viability and tangible socio-economic
impact together with the representatives of concerned line
Ministries/Departments of Government of India and _ State
Governments; and make suitable recommendations for selection from
amongst the candidate projects

ii. To consider the final project proposals received from the SLECs/SEC
together with the comments of the concerned central line
Ministries/Departments and make suitable recommendations — for
approval of the Competent Authority

iii. To recommend effective means for Monitoring and Evaluation through
field inspection inter alia through suitable third-party agencies

iv. To review the progress of project implementation under “Schemes of
NEC”, through the North Eastern Council (NEC) as well as the SLEC

v. To suggest suitable mechanisms for Operation and Maintenance (O&M)
of the projects undertaken under ‘Schemes of NEC’

vi. To consider any other issue as may be received from the NEC or SLEC
or SEC seeking removal of any difficulty in the implementation of
‘Schemes of NEC’ projects or clarification on guidelines; and make
suitable recommendations, including for relaxation/minor modifications,
if any, to the provisions of the Scheme.

4.4.3 Meetings of EIMC at Central level
EIMC will meet as frequently as needed, but at least once in three months. EIMC
can meet physically, virtually or in hybrid mode, at New Delhi or at any other
place in NER.
Ss Financial Outlays
5.1 The total approved expenditure outlay for the “Schemes of NEC” scheme for
the period from 2022-23 to 2025-26 shall be calculated as per the principles laid
down in the EFC meeting dated 29-09-2022 read with the clarification dated 10-
11-2022.The outlay so calculated shall be separately circulated to all concerned
by the Ministry, after due approval by the Competent Authority.
5.2 The total approved expenditure outlay shall account for the fund requirement
for:

(i) meeting the committed liabilities of the projects sanctioned till 2021-22

under “Schemes of NEC”

(ii) sanctioning of new projects w.e.f. 01.04.2022 onwards

(iii) catering to the administrative expenditure for the scheme

NI = Page 7 of 34

<!-- page 10 -->

6. Components under “Schemes of NEC” and their inter se
allocations:
The three components under the scheme and their allocations, as per approval
of the Competent Authority, are as under:
Central Agency | State Normative Focused
Component Component (SNC) Development
(CAC) (60% of 70% Component (FDC)
(40% of 70% component ) (30% Component)
component
Focus Bamboo, Piggery, Regional Tourism, Afforestation of
Areas Higher Education, Tertiary Healthcare |denuded hills, organic
(including Health Education) & special farming, studies into
interventions in backward areas, problems of ethnic
livelihood, science and technology groups in NER,
interventions, surveys and documentation of
investigations and promotion of NER. _ |disputes, study of
Detailed at Annexure-I. various
languages/scripts, to
revive the lost
languages/script, and
lother such other
rojects of importance.
State-wise
normative |No Yes No
allocation as per Annexure
Who will Central Agencies State govt will State/Central
pose may pose projects pose projects Agencies/NEC may
projects to NEC (after approval pose projects to NEC
from CS) to NEC
Flexibility States may
Clause propose projects,
N/A upto 25% of their N/A
State-specific
normative
allocation, for
sectors not
specified in
a, | Annexure-1
foo The el ae
a. Central Agency Component (CAC)-to support overall
development in the sectors of importance identified for the North
Eastern States, as indicated at Annexure-I. Project projects that
benefit multiple States in the region will be considered under this
component.
Note: 28%) of the annual outlay for new sanction under the Scheme
will be earmarked for CAC component. There will be no state-wise
| Page 8 of 34
