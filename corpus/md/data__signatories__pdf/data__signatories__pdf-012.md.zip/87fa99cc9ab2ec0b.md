---
doc_id: "87fa99cc9ab2ec0b"
source_url: "https://doj.gov.in/static/uploads/2025/09/8c2b5a9864318ef0dab50d3a78c20a1a.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of transfer of Shri Justice Annireddy Abhishek Reddy, Judge, Telangana High Court as a Judge of Patna High Court (04.05.2023)"
date: "2023-05-04"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "666b7cfd7ab308d9"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-11019/16/2023-USNII (ii)
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, dated 4th May, 2023.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 222 of the
Constitution of India, the President, after consultation with the Chief Justice of
India, is pleased to transfer Shri Justice Annireddy Abhishek Reddy, Judge,
Telangana High Court, as a Judge of Patna High Court and to direct him to
assume charge of his office in the Patna High Court.
frter-k_
(Narayp4 Prasad)
Deputy Secretary to the G rnment of
Tele: 2338 2149

To
The Manager,
Government of India Press,
Minto Road, New Delhi.

<!-- page 2 -->

: 2 :
No. K-11019/16/2023-US.I/II (ii)

Dated: 04.05.2023

Copy to:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.

Shri Justice Aimireddy Abhishek Reddy, Judge, Telangana High Court
through the Registrar General, Telangana High Court, Hyderabad.
The Secretary to Governor, Bihar, Patna.
The Secretary to the Governor, Telangana, Hyderabad
The Secretary to Chief Minister, Bihar, Patna.
The Secretary to the Chief Minister, Telangana, Hyderabad.
The Secretary to the Chief Justice, Patna High Court, Patna.
The Secretary to the Chief Justice, Telangana High Court, Hyderabad.
The Chief Secretary, Government of Bihar, Patna.
The Chief Secretary, Government of Telangana, Hyderabad.
The Registrar General, Patna High Court, Patna.
The Registrar General, Telangana High Court, Hyderabad.
The Accountant General, Bihar, Patna.
The Accountant General, Telangana, Hyderabad.
PS to Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
Registrar (Conf.), o/o Chief Justice of India, 07, Krishna Menon Marg,
New Delhi.
PS to ML&J/Sr. PPS to MoS (L&J)/ PPS to Secretary (J).
Technical Director, MC, Department of Justice, with a request to upload
on the Website of the Department (www.dokovin).
?PIA
01-1 09 701-3
(Prem Chand)
Under Secretary (Appointments-I)
Tele: 23382978
