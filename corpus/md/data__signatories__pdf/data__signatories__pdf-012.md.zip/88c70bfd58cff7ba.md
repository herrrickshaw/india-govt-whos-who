---
doc_id: "88c70bfd58cff7ba"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/6656216f8d88d9bd5d1adabb8499def8.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Vacancy circular for the post of 'PLIO & Dir'"
date: "2025-07-09"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1b84ed5b3036df33"
---

<!-- page 1 -->

<!-- page 2 -->

ANNEXURE-I
1. Name of the post

:

2. Classification

:

3. Pay Band and Grade Pay/Pay Scale :
4. Number of posts
:
5. Eligibility Conditions

:

Principal Library and Information Officer and
Director.
General Central Service, Group
‘A’ Gazetted, Non-Ministerial
Level 13 in the pay matrix (Rs. 123100-215900/-).
One *
(* Subject to variation dependent on requirement)
Deputation (including short-term
contract).

“Officers under the Central Government or State Governments or Union Territories or
Public Sector Undertakings or Universities or recognised research institutions or semiGovernment or autonomous or statutory organisation:(A)

(i) holding analogous post on regular basis in the parent cadre or Department; OR
(ii) with five years’ service in the grade rendered after appointment thereto on a regular
basis in posts in Level-12 (Rs. 78800-209200/-) in the Pay Matrix or equivalent in the
parent cadre or department; OR
(iii) with ten years’ service in the grade rendered after appointment thereto on a regular
basis in posts in Level-11 (Rs. 67700-208700/-) in the Pay Matrix or equivalent in the
parent cadre or department ; and

(B)
possessing the following educational qualifications and experience:
Essential:
(i) Master’s Degree in Library Science or Information Science or Documentation
Science of a recognised University;
(ii) Master’s Degree in Economics or Commerce or Statistics of a recognised
University; and
(iii) twelve years’ experience (including administrative experience) of working in a
public or institutional library including experience in computerisation of the library.
Desirable:
Doctoral degree in Library Science or Information Science or Documentation Science of
a recognised University.
Note 1 .— Qualifications are relaxable at the discretion of the Union Public Service Commission for
reasons to be recorded in writing, in case of candidates otherwise well qualified.
Note 2.— Period of deputation(including short-term contract) including period of deputation(including
short-term contract) in another ex-cadre post held immediately preceding this appointment in the same
or some other Organisation or Department of the Central Government, shall ordinarily not to exceed
five years. The maximum age limit for appointment by deputation (including short-term contract)
shall not be exceeding fifty six years as on the closing date of the receipt of applications.
--0--

<!-- page 3 -->

ANNEXURE-II
BIO-DATA/ CURRICULUM VITAE PERFORMA
1. Name and Address
(in Block Letters)
2. Date of Birth
(in Christian era)
3. i) Date of entry into Service.
ii) Date of retirement under
Central/State Govt. Rules.
4. Educational Qualifications

5. Whether Educational and other
qualifications required for the post
are satisfied. (If any qualification
has been treated as equivalent to
the one prescribed in the Rules,
state the authority for the same).
Qualifications/
mentioned in
circular.

Experience required as Qualifications/experience possessed by the officer
the advertisement/vacancy

Essential :
A. Qualification
B. Qualification
C. Experience

Essential:
A. Qualification
B. Qualification
C. Experience

Desirable:Desirable:Qualification
Qualification
5.1 Note:- In the case of Degree and Post Graduate Qualification Elective/main subjects and subsidiary
subjects may be indicated by the candidate.
6. Please state clearly whether in the light of the
entries made by you above, you meet the
requisite Essential Qualifications and work
experience of the post.

6.1 Note: Borrowing Department are to provide their specific comments/views confirming the relevant
Essential Qualification/work experience possessed by the Candidate (as indicated in the Bio- Data) with
reference to the post applied.

Contd…

<!-- page 4 -->

-27. Details of Employment, in chronological order. Enclose a separate sheet duly authenticated by
your signature, if the space below is insufficient.
Office/
Post held on From
To
* level in the Nature
of
Institute
regular basis
Pay Matrix of Duties
(in
the post held detail)
on
regular highlighting
basis.
experience
required for
the
post
applied for.

* Important: financial upgradations granted under ACP/MACP are personal to the officer and
therefore, should not be mentioned. Only Level in the pay matrix of the post held on regular basis to
be mentioned. Details of ACP/MACP with present Level in the pay matrix where such benefits have
been drawn by the Candidate, may be indicated as below:
Office/Institute
Level in the Pay
From
To
Matrix drawn under
ACP/MACP Scheme.

8. Nature of present employment i.e. Ad-hoc or
Temporary or Quasi-Permanent or Permanent
9. In case the present employment is held on
deputation/contract basis, please statea) The date of initial b)
Period
of c) Name of the parent
appointment
appointment
on office/organisation to
deputation/contract
which the applicant
belongs.

d) Name of the post
and Pay of the post
held in substantive
capacity in the parent
organisation.

9.1 Note: In case Officers already on deputation, the application of
such officers should be forwarded by the parent cadre/ Department
along with Cadre Clearance, Vigilance Clearance and Integrity
Certificate.
9.2 Note: Information under Column 9(c) & (d) above must be given in
all cases where a person is holding a post on deputation outside the
cadre/organisation but still maintaining a lien in his parent
cadre/organisation.
Contd…

<!-- page 5 -->

-310. If any post held on Deputation in the
past by the applicant, date of return from
the last deputation and other details.
11. Additional details about present employment:
Please state whether working under (indicate the name of your employer against the relevant
column
a) Central Government
b) State Government
c) Autonomous Organisation
d) Government Undertaking
e) Universities
f) Others

12. Please state whether you are working
in the same Department and are in the
feeder grade of feeder to the feeder grade.

13. Are you in the Revised Scale of pay
(7th CPC)? If yes, give the date from which
the revision took place and also indicate
the pre-revised scale.

14. Total emoluments per month now drawn
Level in the Pay Matirx (7th CPC) Index Number in the level

Basic Pay

15. In case the applicant belongs to an Organisation which is not following the Central
Government Pay-scales, the latest salary slip issued by the Organisation showing the following
details may be enclosed.
Basic Pay with the Scale of Dearness pay/Interim relief / other Total Emoluments
Pay and rate of Increment
Allowances etc., (with break-up details)

16.A Additional Information, if any,
relevant to the post you applied for in
support of your suitability for the post.
(This among other things may provide
information with regard to (i) additional
academic qualification (ii) professional
training and (iii) work experience over
and above prescribed in the vacancy
circular/advertisement)
(Note: enclose a separate sheet, if the
space is insufficient.)
Contd…

<!-- page 6 -->

-416.B Achievements:
The candidates are required to indicate
information with regard to;
(i) Research publications and reports and
special projects ,
(ii)
Awards/Scholarships/
Official
Appreciation,
(iii) Affiliation with the professional
bodies/institutions/societies and;
(iv) Patents registered in own name or
achieved for the organisation,
(v) any research/innovative measure involving
official recognition
(vi) any other information.
(Note: Enclose a separate sheet if the space
is insufficient)
17. Please state whether you are applying for
Deputation/ Deputation(ISTC)
(Candidates
of
the
non-Government
Organisations are eligible only for Short Term
Contract).
18. Whether belongs to SC/ST
I have carefully gone through the vacancy circular/advertisement and I am well aware that the
information furnished in the Curriculum Vitae duly supported by the documents in respect of Essential
Qualification/Work Experience submitted by me will also be assessed by the Selection Committee at
the time of selection for the post. The information/details provided by me are correct and true to the
best of my knowledge and no material fact having a bearing on my selection has been
suppressed/withheld.

(Signature of the candidate)
Address _____________________________
____________________________________
Mobile/Contact No. _________________________
E-mail ID._________________________________
Date:

<!-- page 7 -->

-5Certificate by the Employer/Cadre Controlling Authority
The information/details provided in the above application by the applicant are true and correct
as per the facts available on records. He/she possesses educational qualifications and experience
mentioned in the vacancy Circular. If selected, he/she will be relieved immediately.
2.

Also certified that;
i)
ii)
iii)

iv)

There is no Vigilance or disciplinary case pending/contemplated against Shri/Smt.
________________.
His/ Her integrity is certified.
His /Her CR Dossier in original is enclosed/photocopies of the ACRs for the last 5 years
duly attested by an officer of the rank of Under Secretary of the Govt. of India or above
are enclosed.
No major/minor penalty has been imposed on him/her during the last 10 year Or A list of
major/minor penalties imposed on him/her during the last 10 years is enclosed (as the case
may be).

Countersigned
_____________________________________________________________________________

(Employer/Cadre Controlling Authority with Seal)

Applications/CV not accompanied by supporting certificates/ documents in support of
Qualification and Experience claimed by the candidates would not be processed for
determining the eligibility of the candidates for the selection.
