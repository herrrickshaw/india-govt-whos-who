---
doc_id: "87ade3e6cc5c0d4d"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/64328ea9f97ffec1a85067a0cdb946b7.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction Order for the FY 2019-20"
date: "2020-03-20"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f99ca36332bf8a7b"
---

<!-- page 1 -->

46
213862/2020/IPR-VII
5 NO. P-24029/47/20| 8-IPR-VII
ura uver/Government of India
aiftisa uaa seit Harea/Ministry of Commerce & Industry
औद्योग संवर्धन और आंतरिक व्यपार frm/Department for Promotion of Industry and Internal Trade
(आई०पी०आर-प्रतिलिपि अधिका।॥॥?२-००७५9॥/ Section)
sat wan, ag faeet-110011 /Udyog Bhavan, New Delhi-110 011,
fare: 20 March, 2020
To,
The Accounts Officer
Pay & Accounts Office,
Department for Promotion of Industry and Internal Trade
Ministry of Commerce and Industry
Udyog Bhawan New Delhi.
Subject: Release of grant-in-aid of Rs. 1,33,334/- (One Lakh Thirty Three
Thousand Three Hundred Thirty Four Only) to NALSAR University of Law for
incurring expenditure under IPR Chair activities under the Scheme for Pedagogy and
Research in IPRs for Holistic Education and Academia (SPRIHA) FY 2019-20.
Sir,
| am directed to convey the sanction of the President to the payment of grant-
in-aid of 1,33,334/- (One Lakh Thirty Three Thousand Three Hundred Thirty Four
Only) to NALSAR University of Law for FY 2019-20 to for incurring expenditure for
the approved activities of IPR Chair and the conditions for Grant as provided in the
norms of the Scheme for Pedagogy and Research in IPRs for Holistic Education and
Academia (SPRIHA).
pS The grantee does not have any pending UC and audited accounts under the
Scheme.
3. The grant is subject to the following conditions:

i. The grant will be utilized only for the approved items of expenditure in
accordance with Norms of the Scheme for Pedagogy and Research in IPRs for
Holistic Education and Academia (SPRIHA) issued by the Department of
Industrial Policy & Promotion vide their O.M. No. F. 17-2/2016-IPR-VII dated
28.02.2018.

ii, The accounts and records shall be maintained in accordance with the
procedure prescribed by the Government of India. न

iii. | The assets acquired by the grantee out of the grants sanctioned shall be subject
to the rules and conditions prescribed by the Government of India from time to
time in this regard.

<!-- page 2 -->

47
213862/2020/IPR-VII
है iv. A register of the permanent and semi-permanent assets acquired wholly or
partly out of the Government grant shall be maintained in the prescribed form
and a copy thereof is furnished to this Ministry. No item of the assets shall be
transferred or otherwise disposed of without the concurrence of the Ministry.

v. Before the amount is paid, a bond shall be executed by the
Institute/Organization in respect of the grant, if necessary under Rules. The
organization receiving the grant shall have to give an undertaking that no grant-
in-aid has been received from any other authorities of the Central or State
Governments and that a grant-in-aid for the same purpose has not been applied
for by the organization to any of those authorities.

vi. The account of all grantee Institutions or Organization shall be opened to
inspection by the sanctioning authority and audit, both by the Comptroller and
Auditor General of India under the provision of CAG (DPC) Act 1971 and
Internal Audit by the Principal Accounts Office of the Ministry or Department
whenever the institution or organization is called upon to do so.

vii. The organization shall have to give an undertaking that the grant shall be
utilized for the purpose, and only for the purpose, for which it is sanctioned.
Failure to do so shall render the organization liable to refund to the Government
the grant in full with such interest thereon as the Central Government may
decide.

viii. | Separate accounts for the grant will be maintained and any information sought
by the Government of India will be furnished within the stipulated time.

ix. The assets acquired through government grant except those declared obsolete
shall not be disposed of without prior approval of the authority which sanctioned
the grant.

x. The grant received under this scheme shall not be utilized for meeting the
previous liabilities or debt.

xi. A Utilization Certificate, certifying that the amount has been utilized for the
purpose for which it has been sanctioned duly supported by a statement of
audited accounts from concerned Chartered Accountant or authorized auditor
of the University/Institution as the case may be and countersigned by the head
of the organization, shall be furnished immediately after the close of current
financial year 2019-20 within one year from the date of issue of the
sanction. No previous UC is pending in respect of scheme for which this
sanction relates.

xii. | TA/DA should be paid as per Government of India Rules.

xiii. The decision of the Secretary to the Government of India in the Ministry of
Commerce and Industry (Department for Promotion of Industry and Internal
Trade) on the question whether there has been breach or violation of any of the
terms and conditions appended to the grant shall be final and binding on the
grantee.

xiv. Institution receiving grant should irrespective of the amount involved, be
required to maintain subsidiary accounts of the Government grant and furnish

<!-- page 3 -->

48
213862/2020/IPR-VII
i to the accounts officer a set of audited statement of accounts. These audited
statement of accounts should be furnished after utilization of the grants-in-aid
or whenever called for. The accounts of all grantee institutions shall be open
for inspection by the sanctioning authority and audit.

xv. _ If the Grantee fails to utilise the Grant for the pupose for which the same has
been sanctioned or does not adhere to the terms & conditions of Grants and
GFRs provisions, the Grantee Institution shall be required to refund the Grants
with interest @ 10% per annum.

xvi. The Grantee Institution shall not utilise the interest earned on the recurring/
non-recurring Grants-in-Aid released to the Institution for any purpose. the
Interest earned shall be indicated in UCs which can be either adjusted in next
release or to be refunded to Gol after Grants-in-Aid is utilised.

4. The grant of 1,33,334/- (One Lakh Thirty Three Thousand Three Hundred
Thirty Four Only) to NALSAR University is debatable to Demand No. 11 -
Department for Promotion of Industry and Internal Trade; Head of Accounts:
3475.00.102.11.11 “Scheme for Pedagogy and Research in IPRs for Holistic
Education and Academia(Promotion of Copyright and IPR) 3475.00.102.11.11.31 —
“Grant-in-Aid General” 2019-20 and will be drawn by Shri Rajender Kumar Punia,
Drawing & Disbursing Officer of the Department for Promotion of Industry and Internal
Trade and paid to Registrar, NALSAR — IPR Chair through Demand Draft/ Cheque/
Electronic/Telegraphic transfer of funds as per bank details of the Grantee institution
for making payment as below:-

Name of the Name of |Address/Code A/C Name and |MICR Code

beneficiary  |Bank Bank Branch No. land IFSC
pin े Code
Registrar, Indian Bank |Nalsar University Registrar, IFSC Code
INALSAR — of Law, Justice INALSAR — IPR /IDIB000S166
IPR Chair City, Shameerpet, |Chair
Hyderabad, Saving Account |MICR Code
Ranga Reddy |No. 6690481568 [500019029
Distt. — 500101,
Telengana
5. The total release under this Object Head, including the present sanction would
be Rs. $1, 69,241 4 241 /-during the current financial year as against the R.E. of Rs.
2,13,00,000/-.
6. Shri. R. K. Punia(Under Secretary, Cash, DPIIT) will act as Drawing &
Disbursing Officer for the purpose of Grants-in-aid Bill in r/o this sanction.

<!-- page 4 -->

49
213862/2020/IPR-VII
: ¥ The pattern of grant/expenditure has been approved by the Ministry of
Finance. This sanction is being issued in conformity with the rules and principles of
the scheme as approved by the Ministry of Finance.
8. This issues with the concurrence ८22 1021 the Integrated Finance Wing vide their
Dy.NO._DAI22 _ dated the24 | 02-/ 2020.
॥,- ५). .
गा Dutta)
Deputy Director
23062327
Copy to:
1. The Dean, NALSAR, Hyderabad
2. The Registrar, NALSAR, Hyderabad
3. Drawing and Disbursing Officer, Department for Promotion of Industry and Internal
Trade with two spare copies and bill in duplicate.
Ni eUbs |
(Nayonika Dutta)
Deputy Director
23062327
Copy also forwarded to :
1. Accountant General, New Delhi.
2. A.G.C.R. (Spl. Cell), New Delhi.
3. Director General of Audit, Central Revenue, IP Estate, New Delhi.
4. Finance-Il Division/B&A Section, DIPP Sanction Folder/Guard File
॥ - be.
Rislorika Dutta )
Deputy Director
है 23062327
