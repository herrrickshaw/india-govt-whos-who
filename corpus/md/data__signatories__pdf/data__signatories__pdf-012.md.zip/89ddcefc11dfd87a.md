---
doc_id: "89ddcefc11dfd87a"
source_url: "https://steel.gov.in/sites/default/files/2026-10/Compassionate%20Appointment%20Result%202026_0.pdf"
ministry: "Steel (MoS)"
title: "Compassionate Appointment Result 2026_0.pdf"
date: "2026-10"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "74b1d67565006e06"
---

<!-- page 1 -->

No.A-12/1/2020-ESTT
Government of India
Ministry of Steel
(E-II & RTI Division)
2202,GPOA-03
Netaji Nagar, New Delhi-110023
Date: 13/10/2026
NOTICE
Itis hereby conveyed for information of all concerned that Shri Prateek Joshi S/o Late
Shri Satya Prakash Joshi, Ex-Daftry has been recruited on the post of MTS in Ministry of
Steel on compassionate grounds. The reports of the duly constituted committee are annexed
herewith.
K taal at
(Thangminlal Kipgen)
Under Secretary to the Government of India

<!-- page 2 -->

ma
हु Minutes of the Meeting of the Committee for appointment on Compassionate
Ground in M/o Steel held on 09/03/2026 at 11:00 AM. .
The case is related to appointment on compassionate ground in M/o Steel. The
: objective of scheme for compassionate appointment is to grant appointment to a
: dependent family member of a government servant dying in harness or who is retire on
medical grounds, thereby leaving his family in penury and without any means of
livelihood, to relieve the family of the govt. servant from financial destitution.
: 2. This committee consisting of the following members, constituted vide OM
No.A/12/1/2020-Estt. dated 11.12.2025, met on 09.03.2026 at 11:00 AM in the chamber
of Shri Ramesh Kumar, DS to examine the applications of eligible applicants and _
recommend the most suitable candidate for appointment against the One(01) Post of
MTS in the ministry :
i. Shri Ramesh Kumar, DS -Chairperson :
ii, Shri Raj Kumar, JD -Member :
iii, Shri G.Sarathy Raja, DS -~Member -
3. The committee was informed that against the One (01) vacant post of MTS, ।
there are 10 applications from.the dependent family members of .the deceased |
employees of M/o Steel. Out of the Ten (10) applicants, One (01) applicant, namely, Ms.
Devanshi Mittal D/o Late Ms. Jyoti Singhal, DS, has withdrawn her application in writing.
Resultantly, now there are Nine (09) eligible applications against the said One (01) post. |
Details are mentioned below: |
ISI.No. [Name of Deceased Govt. servant & pplicant Name and Relationship with the 1
Designation; date of demise __(deceased Govt. servant i 3
Shri Satya Prakash, Daftry; 02/04/2012 Sh, Prateek Joshi, Son i
(Shri Dharam Pai Gehlot, LDC; 09/05/2013 |
Shri P.P. Singh, 'SO;.07/03/2014 Shri Brijesh Kumar, Son
[Shri Rajinder Prasad, MTS; 17/10/2014 Shri Mohit Kumar, Son _. :
Shri Manish ~Baijal, Dy. Secretary; — [Shri Prateek Baijal, Son i
14/02/2015 है |
Zz =e
19/08/2015 :
Shri Raj Singh, MTS; 06/02/2020 [Shri Deepank, Son :
Mrs Jyoti Singhal, Dy. Secretary; (Ms. Devanshi Mittal, Daughter
9/04/2021 (Application withdrawn) |
ठप Keshar Singh Rawat, ASO, 06/07/2021 _ [Shri Sanjay Singh, Son
IShri Srichand, MTS; 20/04/2022 IShri Sandeep Kumar, Son .
.
4. The committee was provided with the duly filled applications forms, of the Nine
(09) applicants, as per DoPT guidelines dated 02.08.2022. {
5. To examine the Nine (09) applications and to recommend the most suitable '
candidate on merit and with complete transparency, the. committee adopted the :
“Scheme for compassionate appointment- Relative merit point & and revised i
procedure” issued by Central Board of indirect Taxes and customs, Department of :
Revenue, M/o Finance vide letter no.A.12012/52/2018-Ad III.B dated 15.05.2019,
|
1

<!-- page 3 -->

6. As per allocation of points to various attributes based on a 100 point-scale in the
letter mentioned above, Ten (10) points each have been assigned to (i) Annual Income
of earning members & Income from Property and (ii) Movable/Immovable Property. The
details provided by the applicants regarding these Two Parameters in the duly filled
applications forms were only self -certified and were not supported by any documentary
evidence.

1 Accordingly, the committee directed the division to obtain the applications from
the candidates complete in all respects duly supported by documentary evidence to
ensure correctness of information/ date, verify with available official records, document
submitted and present in statement duly certified by the Establishment Division.
For ascertaining the Annual Income of earning members & Income from Property, the
copies of PAN Numbers, ITRs filed, Form AS26, Bank Statements of the applicant and
family members may be obtained. Further, if applicant is paying any EMI then such EMI
amount should be considered as part of Income and such property should be included
in the list of property owned by applicant. In connection with Movable/Immovable
Property, the copies of Electricity Bills, Loan Statements, Rent Receipts, etc. may be
obtained. If so desired, a personal visit to applicants’ residences may also be made to
verify the details provided in the applications are correct.

(Raj Kumar, JD) (G. Sarathy Raja, DS)
Member ~ ; Member
४0 N i
WO अलग
(Ramesh Kumar, DS)
Chairperson

<!-- page 4 -->

i Minutes of the Meeting of the Committee for appointment on Compassionate Ground in M/o Steel of the Meeting of the Committee for appointment on Compassionate Ground in M/o Steel
i held on 06/08/2026 at 03:00 PM.
The case is related to appointment on compassionate ground in M/o Steel. The objective of
scheme for compassionate appointment is to grant appointment to a dependent family member of a
government servant dying in harness or who is retired on medical grounds, thereby leaving his family in
penury and without any means of livelihood, to relieve the family of the govt. servant from financial
destitution.
2. The committee consisting of the following members, constituted vide OM No. A/12/1/2020-Estt,
dated 11,12.2025, held its second meeting on 06/08/2026 at 03:00 PM in the mini conference hall to
further examine the applications and relevant documents of eligible applicants and recommend the most
suitable candidate for appointment against the One(01) Post of MTS in the ministry :
i, Sbri Ramesh Kumar, DS - Chairperson
ii, Shri Raj Kumar, JD - Member
iii, Shri G,Sarathy Raja, DS - Member
3. The committee was informed that against the One (01) vacancy for post of MTS, there are 10
applications from the dependent family members of the deceased employees of M/o Steel. Out of the Ten !
(10) applicants, Two (02) applicants, namely, Ms. Devanshi Mittal, D/o Late Ms. Jyoti Singhal, DS, and :
Shri Anurag Dholpuria, S/o Shri Kailash Chander, Assistant, have withdrawn their application. One !
applicant, Shri Sandeep Kumar S/o Shri Srichand, MTS, has been found ineligible due to failing to meet i
minimum educational requirements for the post of MTS. Resultantly, the committee was informed that |
there are Seven (07) eligible applicants against the said One (01) post to be filled on compassionate
grounds as tabled below:
Applicant name and relationship with
date of demise the deceased govt. Servant |
Shri Satya Prakash, Daftry; 02/04/2012
3._| Shri P.P. Singh, SO; 07/03/2014 Shri Brijesh Kumar, Son |
chee |
5._| Shri Manish Baijal, Dy. Secretary; 04/02/2015 _ :
1 *] Shri Kailash Chander, Assistant; 19/08/2015 :
(Application withdrawn, :
.
a
(Application withdrawn)
Shri Keshar Singh Rawat, ASO; 06/07/2031
10.) Shri Stichand, MTS; 20/04/2022
(Dees not meet minimum educational
requiremeni
4. As directed by the committee in its first meeting, duly filled applications forms of the seven (07) - :
eligible applicants, as per DoPT guidelines dated 02.08.2022 along with all the relevant Sanction i
Orders/PBR entries determining the payment of terminal benefits to the lamily of the deceased were ;
I
1

<!-- page 5 -->

presented in front of the committee. The committee was also informed that, as per their directions, visits
were also made to the residences of the Seven (07) applicants to verify the details provided by the
applicants in the application. Further, documents like Bank Statements of the applicant and family
members; residence proof e.g. electricity bills, rent agreements and aadhar cards; educational
qualification documents were also obtained from the applicants and placed before the committee.
5, The Committee adopted the "Scheme for compassionate appointment- Relative merit point &
and revised procedure" issued by Central Board of Indirect Taxes and Customs, Department of Revenue,
M/o Finance vide letter no.A.12012/52/2018-Ad.IILB dated 15.05.2019 for assessing the most suitable
candidate. Details of points scored by the 07 applicants are as follows:
| 5. Name of deceased govt. Servant Applicant name and
No. | & designation; date of demise relationship with the candidate
लि deceased govt. Servant
1.) Shri Satya Prakash, — Datfiry; 46
02/04/2012
2. | Shri Raj Singh, MTS; 06/02/2020 _| Shri Deepank, Son
3.| Shri Rajinder Prasad, MTS; | Shri Mohit Kumar, Son
17/10/2014
:
09/05/2013
5. | Shri Manish Baijal, Dy. Secretary; | Shri Prateet Baijal, Son
04/02/2015
|__ 6. Shri Brijesh Kumar, Son
|__| 06/07/2021 -
6. On the basis of extant rules and instructions issued by DoPT from time to time and assessment of
the applications on 100 point scale as per procedure adopted, the Screening Committee recommends the
name of Shri Prateek Joshi S/o Late Shri Satya Prakash for appointment against 01 post in the grade of
MTS in the Ministry on compassionate ground.
Liber 5 per
(Raj ade sls (G, Sarathy Raja, DS)
Member abel Member
(Ramesh Kumar, DS)
Chairperson
