---
doc_id: "85ef57fab5db2e7d"
source_url: "https://financialservices.gov.in/sites/default/files/Act-Policies/2026-01/1.-GSR-341-342-343_1.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "The Actuaries Tribunal (Salaries, Allowances & Other terms and conditions of Presiding officers and members) Rules, 2008"
date: "2026-01"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "10b6e030200740fc"
---

<!-- page 1 -->

r -33004/99 REGD.
NO. D. L.-33004/99
f 1fi * 'fi
tk
xq^

%mew
aatra G["

ct-al *41Z4401
'The 5ct t ette
a o f India
murm
EXTRAORDINARY

WPi I1 -Wn 3-3IT-79U' (i)
PART 11-Section 3-Sub-section (i)

T7Tf14 g 1 ira+ufiia
PUBLISHED BY AUTHORITY
?i. 2471 t, !VW, TO 7, 2008/ h1149 17, 1930
No. 2471 NEW DELHI, WEDNESDAY, MAY 7, 2008/VAISAKHA 17, 1930
f^m A'lg
(fwta 13-d1 f49Tm )

3TRTTEM
f ?, 7 , 2008
T,cTT
,,1 k . 341 (30,-c'' 1 *i i , q# 3iM^Mg, 2006 ( 2006 W 35) 'd+ft *NAT 12 ft 3q-- Wm (2) * -^71qvf3d
9M 55 q,3 TT-*TW (2) * T ( T) Ri TF T* M N4M TTa ER, 1 Hk1fl fiwi a-u t *, w4

1. die -qIM 3MYt V&-(l ) -0 fl t aM T#fkM 11R afMiq,41 (ifgz. * 7<r1 1 ii'iMYv) fvi , 2008 * I
(2) - d > x t 1 alTh l l aft i
2. 4f1l^.-(1 -0 f-M4 -4, T4 UT, fT+ 34 -4 3T;1w1 3Tdf$Td vI et,OF) "3Tf9f-PR -f) 41#4,-h 3]fgf-7 i, 2006 (2006 i 35) 3Tfs*d * I

W' -A -0 ffiral * 3TSI Ri2FR lira qft , 74 alift fsId 1 3Tf+TTMd
(iq) " VTc
gfrulf^a f q^ f 31f*IfigM gft^Trfga 1T yi 3T^t q^Y a ?
fagal rgaa f"'1C 3T^t
(2)
3i^f ', 3Tf*iFf4M'rT Tff* ^ I
3. aiMf 4t

^, fFR {$'2tt W 40.-Z+- i TMM, 3if4f-4M -+T qi(I 12 4^ 3q-*TRi (2 ) * 15t M

3q -rte ( iii) * 3T%T1q Tftt a
zzff^ f

(F)

r d i t 1IMF sr1 ^2m qi r i 1lfzM
gRT 'dq *m gI TTt mT tm ate, " -OhFfFIfw Tff 3T^t A f**T *i q',9t 74 3P4

7m fLm ira*f ciq if --Nr#Iq 3Tj%T4 *,
(a) lt4 zqf^ f
if f ^ gi fags,
('r) 3 T , f a f +r t C U,-O 4
t atc,Tt gftqe, 4, f
(^r) f4; t 3P1 fav I II>MI -A wl^ fO)nF tffA

qic^

f^

A-Fv g1af1Nla ZqN^ T, #m w

3giIgfl 7rro

TTY q€'1 t m I
[W.'a 97/ 11/2003 -31T k- III (i) 1

aui 77,iM , #Taa TiPaa
1672 G1/2008

(1)

<!-- page 2 -->

THE GAZETTE OF INDIA : EXTRAORDINARY [

2

PART u-SFc. 36)1

MINISTRY OF FINANCE
(Department of Financial Services)
NOTIFICATION
New Delhi , the 7th May, 2008

C.S.R.3a1 (E).-In exercise of the powers conferred by

clause (a) of sub-

section (2) of section 55, read with sub-section' (2) of Section 12 of the Actuaries
Act, 2006 (35 of 2006), the Central Government hereby makes the following rules.

namely:
1. Short title and commencement .- (1) These rules may be called the
Actuaries (Nomination of Member to the Council) Rules, 2008.
(2) They shall come into force on the date of their publication in the
Official Gazette.
2. Definitions .- (1) In these rules, unless the context otherwise
requires,(a) "Act" means the Actuaries Act, 2006 (35 of 2006).
(h) "Member" means a person nominated to the Council by the Central
Government under these rules.
(2) All other words and expressions used herein and not defined in these
rules but defined in the Act shall have the same meanings respectively
assigned to them in the Act.
.- The Central Government
3. Field of consideration for nominations
shall make nominations of Members to the Council under sub-clause (iii) of
clause (b) of sub-section (2) of section 12 of the Act from amongst,(a) persons having working knowledge in the fields of life insurance or
general insurance and who should not be working with any insurance
company,
(b) persons having experience of working in the field of Finance,
(c) academicians or experts in the field of economics, law and accountancy,
(d) an expert from any other discipline which the Central Government may
consider useful to the Council:
Provided that the persons so nominated shall not be a member of the
Institute.

[F. No. 97/ 11/2003-ins. III (i)]
TARUN BAJAJ, it. Secy.'

k

<!-- page 3 -->

[iwiII-,aus3(i)] q" EFT 'T:7"

MWT-M
f rr1, 7 TTt, 2008
i fl 45 3f1i T(Tir
i.Pl. 342(3T).- z t TTY Ti410 3 t 2lTr, 2006 (2006 )T 35) 3`1
M.^T
46 WW T TTfbii 9R1 55 41 'd 4U I'Tr (2) C t U7 (A) 3f}T T (U) 9rTr W% Z1 ZM Rt 4RA

f i $riff *, 3T

f tr f3

1. T^[LIiFi ^TTi 31}T Nff 'N,- (1) . f'-RTrr1 -,bl #0 7 ART 4,41 clt > fl (k r t
A ft ZIT, 3M 37A&T clM WqR4 ci ^3t Z' PK^ 3M 71A UM '+I-i) Pf4ff 2008 * I

(2) T1 TtOfTF-51 A s1 hI T9if M tT di AV Wt I
2. Vp'+l(Qiq - (1)

(^)

f-ux1 4, "
31

?W f

Tfq-Tf T1 3T--I`AT 3Tk%a

f, 2006 (2006 45T 35) 31si * I

i atuTTi (1) i 3Ttff9 TI%tf < c Cl ' 't 648
3T^ q,t TinT 43 c1
3Tfd *,

(TT) "3rt7{ET" T1 fl cif 31FAEi 3T?tS?RT * ;
(A) "TTf ^°' T1 3 " 1 W 12 ci^ 31ti
(3) " 'Iii'

TfT -TF I T

tN-4 3Ti# a *

3Tf'tt 6 4 tint 3 * 31 7ftU ITT 4t iitci, ZTfi'tl"d 3T ^ * ;

i Tt2 l 3Tt SRI * ;
(A) "Trice" $T

(2) 4;1 f tl A 7qo f TR 3M A TTttTif*d a fie
Tat Af1\ TTi1 et qgt 3TO f U13Ti^ A 3 i* 1
3.

Trq

f 3&f-rzm A Ttf3'urf t wt

t T^Irc 11 A T;1T I I
4 -i *3'M t i&14h (1) f 3+9 WIf1 AUlt '(1Id7°rd lI ff 1T9

(2) RFt

u

t t ifft 30 m i 3 4 m F T 9M f T u d f W74

qzq iF 'ice td f^fYadc `^T115f T131-^ fTO TT-1t 3T izm 31ifhft 30
T1 3N7 wRr " Z Alf i f 3T--;I

i it 7([`t :
i tZt 4s d' 31--q wq;R4 3'1

qtq AR ft 31TAET, 3Tf c cT f'^57 v'0 3fc -,f f t fiTt 34T T4-` taiEff TO

uRq t pf f4 f 4 ca t to > t 3T r mqym io TM ^1 I
Tx1 -1 ?Tt 3N
(3) f ft arearT WUT46'1T * fTe 4tt ;R f4R 4M ll^ TrDrgfd -CtM
f A T1 3Tt T1 fi"Tr 7EF TTi t Z1 3TfF

T4^f
i MT 43 i

39TTTi'f (3) d? NtfM l1-ft TTTcl5R

9M

91N f*uT ^T=1T 4 1
(4) 3TEW, it iTt tdT^ f 31TAEicIT ^Vm :

qu f 3Twie 4
c'ff 7TAUM T* f
TT

3T^4f^4f f T1 3uft^rr TTiT=r1 A T1 f Tft TriTT.r r
f'-,Tff'4d W'TA I

(5) t Wt AYd, -1 d19 zr;1 %Rff 4W 7t TMET 3TT *, 3TI 3TfT TT-^ TTiTt11
Trd1 - ZFW *4 Tf w A, 3TM&i 74T Zu 3T Tfc A
3m PF7 WrS
vi TM $ um f f f

3t?

TfYm#m TTiTTr cm fothT ur f^^ Trd *m I
4 Tf T'IFTT f ut 7T^TIT 1
4. WRIT 4551 iicAH$t't- 4t T#I1W air, Trt=TFzRT: 4r '1
f 1- (1) fl 1 f T ^r 3TRIET -9r' i f sou
5. #4 Z *M
fTt WTTrr I
a 1}^1
5 ur lif ^lTr l fora f^aa , TiT Tmu Tarr
(2) i u TT 1T
f^ 4 , a1 aR aR ^TZf TAT A Tlfrfd fA urTtr I
T^

<!-- page 4 -->

4 THE GAZETTE OF INDIA : EXTRAORDINARY [PART II-SEC. 3(i)]
(3) 3TF T , 3 q T ^ci T T T > T c > ^ + 14 4 4 - " l%'iw 34 @T4f4cr Tf+l-"T-J , 4R4 10-i 3m
415 ik 2r zt *1a q(i'cicT 45 TU :
q^t TTfGtt c>t T3Tf4o5 TT63TT*4A f if4 A A3=(; fib taTA 3 d
f^5TTT 7T", ^ft 3TEZJ41, trguI-q 4 #IIQM \A T HT c lm clWT usq -'r dT 1 4 3T? 7TI T

(4) 0,1NTv7-11i it 4P-41,1+ i 9NI four TRTT

i

't f

'*fda

Pm 7TVq

c f4 W vWM I
3t^ 4)4 fig 3T- t 4ocT 4 3TfIflc/RT

6. ali KM3T 3 Ti

r tf 4,-

WA WA VWUR -- 4)l 3M

(m) a44 uT wTra 3TEfS wrfda Wt f

R d ZZJ414TT t TTIEZT=T wZ19 t '14

WQT f Trq

- Rf 3T 3TcT^u - TTt dTaTf ''f TT TFc^*J Fff 4}Q c jet tffc 4 cuT ^Td ,

f fs4ucm urre;

gm agci 7T 1 ff Pf^ *4TiT * J riq, a 4R 3rr uT 4 t1

(a) NRPTrg
& 3T%T WT

cN^Tlf 3T 1 ^p i 44R U T iTR * uff 1 aft' $Tf i i c 4' f

ft ZF r 4)7 Tc^M 4 Mf*s a 1 uIrR ;

(T)
3ffia 4

ru) TTr 4Traa1 -0 tt Vi
q flm Rio , -ff^, 1c
7y,4 i dT 3T7 ;4
A v f% RIM 11T
f ad $ vr7 a2TT 3^ 74T4 47 3T4NZ +f1 't. wcY`+TT ;

T a, gR

TTT

f)
wT FAZ?f fs)goc
(A) f* ,a q WaT TTr zmuTMzOtTuT f TTn Tq-k
TTa 3> ^T41:A1 j:;TZi M c,Ifcd 4jT4 3f)i *3T3T -o TcTlf 4>T P Al or
, ,^1
amtf T cb7
;
ZR u4Yg7 ct f t-Tpm 'TL
-iiaMT 30 *Mat, cf;4 aR 4arfei& um

(a) T i a^ \r 4,7 m4,4:4-1 WiA t R47, aaaR r

*JT3f A 3gErr1 cl ti pu f4frp 3T s 3rtr fi ar=TgT AL4Taif twit u ei^
u7cTf1a
c
ft" ThT gT-CT9 3i fe'TST gf

7. afi zer l5ruar, -

2Trd,

fla 3T^

ZF^ f3Tww5fM 4R ffciMT I

zt f f ; a^.i ';5 4R

f4 ifbd 4T) 3^

(chi) 3T T d6RrdI 3gc &I 4i r, vuh i4t fi'r UW$* fife * f A 3Taf m -bA

4;xrzT agaQT TT4 aT3> r 4?1 FTTfIZ1 Cr 'tea 4 'hA qq ffgMd I 4'9T 1
(iU) 4h

a.

arml a& WgRcdr tt 4MT *fitava 3

(1) 411

3TMa 30 WZR4 A T4TA cfH 4q

srt-

(2) 41 .S c i WW 30 W4-TA 3TYIQ7>Tf H'T Ti

ft-#t WcN4 4Yi, f T 10 34Ef

zr2rTaq f4a it f3ar4 TZRTT 4T 4rgtf 9f

s. 'NM -- (1 ) 3TEAww 3TZ 3TT7 uq;m ZvT gr-.aT ATi W m

RT^ it r;qT47 Lft vA 3t 1 3Ri4^A

(3) W ct 3TE

ZTr

f74T slTSTTTT I
s
1 fir
TAT O4T^ TT€f t a1 4g uml TTr^iT 38e trfti
tt7a 4 3T u t 3fZ uft x4xr cb^t
*
Th
#
4TOff
YTf
WT
u
i''
&M -,A) ZiR m ct Tj rl if 4Ys aR taa'i if agfom eA f
it Laura 4TH fft 74 aTr 2rr^w zff^ 4TH fft 3Tf4EFr`^1 4T) 3rT 9, TTf4 uffc^ f44m ag ^Ta
ITT-T*i ii4 ft Fwf 9 l

<!-- page 5 -->

f' ' II-ice'

3

i

]

°

w

3l

'

3IF11VI

f f^ar^t a r a^R ? ^1 fly r f rrl t, aT i
A it wM art- hr ErrxrA f a wo Err lim zwm -vPT mfr i
i
tT4 -$ iW
(2) Z T 3 r _,W Err Z04 a l te r R1 T ; l ,

(3) alb Zi 3TUM aflz 31;4 ziaf<r, 3 uz 9, zgtaa q1 f1 fi^ 3f1z tftcff fo 1 1
10. fRMrf, azrm Wrar a& mmfor i a" t um r - (1) 4tt aFr alFff A;Z x
fz-s'lrfr ur TeR VA 4R Zsrr 4 'WW E1T ZT fist *4 i
74;m3f
fedu gafr KM 'Tuft
(2) itt 411 awry' Err $Tu ^ A ;"'Ma au r;
u-q MM S` ii it ut ^ fl a ifrff tlfr 1
(3) 4 ) ^ W^WK f f f r 4 3TEW ur Wq;M Et 4q;l 15zr 8, Er(, (-IT) aZ fzrrf^rf, 31lff 111 f ffi^r d f !Zl Err fry fir t arffo
rtfar* ;Err
(z^)a3T^vf^)^f^fralTarmsRrl^13a^€f^an ;ur
( f ) U;RA , ^A -;FEW t. rag ITM t 3rf tit aft 40 tail^ v it t ; ur
(A) a9 itf=r ff z aR 77u A 3r> Trl a; f f1 3r ^ 4 3rf m2i 9 ; Err
(* 30 twt fat( Err arr^ rrrr^u gm f it armor 45 f ; Q > ITM -A A f 'AT-A ct
4iR # -z-'44m f. it f3i r 'nn t I

(4) iA WA 3T > > taa ter, E Er FF 9M UU T444f l

F44'Xt

1f 1Ti1

7TTM I

11. ataA>ce 39ift, - *9 t arhZ1 T 3& 3F I wqq^it aR ft f^[FF* 30 wal -am u^ 4 tf44d
ails it ti twot 4 ai^ ai 7A fl ADM, f R) aw r f^fErfl A lz^rt
flu t t
fo f rr far t fr^ 4 it* fiwF cl uua^ f^Mzizl * fcm fWqEz^ f Err
'4r4'rr 3* of uz *a-,rz T f 1Saf f 3rE T 1 3M 3TRr Wgft t az 3T r4 i<FZ PIT I
[Tu. 4. 97/11/2003-3 8. 111001

NOTIFICATION
New Delhi, the 7th May, 2008

G.S.R342 (E).-In exercise of the powers conferred by clauses'(f) and (g) of subsection (2) of section 55, read with section 45 and section 46 of the Actuaries Act, 2006
(35 of 2006), the Central Government hereby makes the following rules, namely:1. Short title and commencement :- (1) These rules may be called the Actuaries
Quality Review Board (Procedure for Meetings, and the Terms and Conditions of service
and Allowances of the Chairperson and Members) Rules, 2008.
(2) They shall come into fore on the date of their publication in the official Gazette.

5

<!-- page 6 -->

6 THE GAZETTE OF INDIA : EXTRAORDINARY [ PART II-Sec. 3(i)]

2. Definitions :- (1) In these rules, unless the context otherwise requires, (a) "Act" means the Actuaries Act. 2006 (35 of 2006);
(h) "Board" means the Quality Review Board constituted under sub-section
(1) of section 43 of the Act;
(c) "Chairperson" means the Chairperson of the Board;
(d) "Council" means the Council of the Institute composed under section 12
of the Act:
(d) "Institute" means the Institute of Actuaries of India constituted under
section 3 of the Act;
(c) "member" means member of the Board.
(2) Words and expressions used herein and not defined in these rules but defined
in the Act shall have the same meaning respectively assigned to them in the
Act.
3. Procedure for the meetings of the Board.- (1) All meetings of the Board shall,
ordinarily, be held at the headquarters of the Institute.

(2) The date and time of any meeting shall be fixed by the Chairperson:
Provided that a notice of not less than fifteen days before the scheduled date of
every such meeting shall be given by the Chairperson. or any person so authorised by him
on that behalf: to the other members of the Board:
Provided further that the Chairperson. for reasons to be recorded in writing, may
call for a meeting at a shorter notice:
Provided also that not more than six months shall elapse between any two
meetings.

(3) The quorum for transaction of any business at a meeting of the Board shall
be of three members. of which at least one must he nominated by the Central Government
under sub-section (3) of section 43 of the Act.
(4) fhe Chairperson shall preside all the meetings of the Board:

Provided that in the absence of Chairperson, the members shall elect any of the
members present on the day of the meeting to chair the meeting.
(5) All questions which come up before any meeting of the Board shall be
decided by a majority of the members present and voting, and in the event of an equality
of votes. the Chairperson or in his absence, the member presiding, shall have a second or
casting vote.

4. Transaction of Business .- The business of the Board shall ordinarily be
transacted at a meeting of the Board.
5. Agenda for the Board meeting .- (1) The agenda for a meeting of the Board
shall be decided by the Chairperson.
(2) Any matter referred to it by the Central Government or the Council shall be included
in the agenda for the meeting of the Board within the time limits as may be specified in
such a reference.
(3) The Chairperson may, in appropriate cases, circulate the agenda note and related.
papers on any issue among members of the Board for resolution by circulation:
Provided that if two or more members of the Board require that any question be
decided at a meeting, the Chairperson shall withdraw the papers from circulation and
have the question determined at a meeting of the Board.

<!-- page 7 -->

[%ImII-r
(4) A decision taken by the circulation of the papers shall be communicated to all the
members and shall be noted at the next meeting of the Board.
6. Procedures to be followed by the Board .- In the discharge of its functions, the
Board may,(a) on its own or through any specialized arrangement set up under the Institute,
evaluate and review the quality of work and services provided by the members
of the Institute in such manner as it may decide;
(b) lay down the procedure or evaluation criteria to evaluate various services
being provided by the members of the Institute and to select, in such manner,
as it may decide, the individuals and firm rendering such services for review;
(c) call for information from the Institute, the Council or its Committees,
members, Clients of members or other persons or organisations in such form
and manner as it may decide, and may also give a hearing to them;
(d) invite experts to provide expert/technical advice or opinion or analysis or any
matter or issue which the Board may feel relevant for the purpose of assessing
the quality of work and services offered by the members of the Institute;
(e) make recommendations to the Council to guide the members of the Institute to
improve their professional competence and qualifications, quality of work and
services offered and adherence to various statutory and other regulatory
requirements and other matters related thereto.
7. Assistance to the Board.- The Institute shall set up a specialised technical unit
to-

(a) provide secretarial assistance, as required, to the Board in the discharge of
its functions;
(b) to assist the Board in carrying out review of quality of services provided
by the Members.
8. Terms and conditions of service of Chairperson and Members of the Board.(1) The tenure of the Chairperson and Members of the Board shall be three years.
(2) The Chairperson and other Members of the Board shall be part-time members.
(3) Chairperson or any Member of the Board shall not be removed or withdrawn except
as provided under rule 10.
9. Allowances .- (1) The Chairperson and other Members shall be entitled to
travelling and daily allowances as admissible to them in their official capacity, and in
case, the Member is not a Government Servant, he shall be entitled to the travelling and
daily allowances as admissible to an officer holding a post carrying a scale of pay of a
Joint Secretary to the Government of India for attending meetings of the Board at the
headquarters of the Institute, if their place of residence is different from the headquarters
of the Institute.
(2) The Chairperson or any other Members of the Board whose place of residence is
the same as the venue of the Board shall be provided local conveyance or allowance for
the local journeys to be performed in connection with the meetings of the Board.
(3) The Chairperson and other Members of the Board, while on tour, shall be entitled
to travelling and daily allowances at the above rates.

<!-- page 8 -->

8 THE GAZETTE OF INDIA: EXTRAORDINARY [PART II-SEC. 3(i)]

10. Resignation , removal and filling up of casual vacancy.- (1) The Chairperson
and each Member of the Board shall cease to remain the Chairperson or Member, as the
case may be, in case of his resignation or removal.
(2) The Chairperson or a Member of the Board may resign from his office by a notice in
writing under his hand addressed to the Central Government which shall be effective
from the date of resignation.
(3) The Central Government may remove a person from the post of Chairperson or
Member, if(a) he has become physically or mentally incapable of acting as the
Chairperson or a Member, as the case may be; or
(b) he has not attended three consecutive meetings of the Board, without leave
of absence; or
(c) he, being the Chairperson, has not called a meeting of the Board for more
than six months: or
(d) he, in the opinion of the Central Government, is unable to discharge or
perform his duties; or
(e) he has been held guilty by any civil or criminal court for an offence which
is punishable with imprisonment for a term exceeding six months.
(4) A casual vacancy in the Board shall be filled by the Central Government, from
out of the category in which such vacancy occurs.
it. Residuary provision .- Matters relating to the terms and conditions of services
and allowances of the Chairperson and other Members of the Board, the place of
meetings and the procedure to be adopted in meetings of the Board, with respect to which
no express provision has been made in these rules shall he referred in each case to the
Central Government for its decision and the decision of the Central Government thereon
shall be binding on the Board, the Chairperson and the other Members.
[F. No. 97/11/2003-Ins. III (ii)]
TARUN BAJAJ, A. Secy.
3Tp^
9 fat, 7 , 2008
W.7+T,f , 343(3T).- it

^r^

' 3T^, 2006 (2006 fir 35) ZF^ QTT 16

of

a wZr (3) * ^FWT uftt vrer 55 aR i i (2) * a3 (a) i;Nf ~I W w m Wl^ _V, a
l uu cRA t, 3Tnr, :1. 31 ME T,- (1) ,tom f'-f^T>T^ ThT 71f8 1B 4f'1k'c5 3TftTh T (41ar4R 3Tf'tFd a
1 -c^ , TTc 311 3T-44 f AR 3Ti) f T, 2008 * 1

(2) 4 WAq^ A Visa Z6f fa m' ;Fr eM 1
2. Vf 11WtT , - (1) f rnA1 4, vTN cT45 fi'i 3T TT 33^ f
(ni) "3Tf 1fkzi=T" t 'd}=TiWT 3TffIfkZN. 2006 (2006 TT 35) aft d * I

(a) "tea wfhi"

t- T uffc^d 3Tf &ti t,, ft U^i Vf3g4 q5r f ftara -,ua

(n) " fear " -A f ft uWP^T
t T -6m E T9 mt uf3w * u t aarzrt
* ;
rrar Bare 3Tf
i 3VArQI (2) 3i 7^3 (45)
(FT) " PfcTimi9 0 3T^ 4 ft ATU 12 cf

c}i
' 37Eff^T PIT

uf3^ air f= aiun 3i-^ t ;
(3) "4Ydrzfli 31f 451W' ;Brill 'T t JHI 16 1+ 39W;U (2) aU (-4;) t
t T T^ Ti4 fir q c ` T 3Tf1f ti ;
amThi f 3Tf '^i"gr<ui ct "4f3Rfr-i aifFt

<!-- page 9 -->

[ WT+T II-^3 3 (i)] %T1TiT 3if TT^lY^ : a1wng r
( ) " 1914 mqq41 "

AV ^ff

0 w;&114 4fC9V u P4,C11 fiQft 41[Y4 14

ut ;Erw *if tiT &il* 311ut

aR ffM 1 6 f 39ARf (2) ct TTST: U3 (U) 3N -aZ (Tr)

(T) " ' -0 3TRff

i t ;
WfiTd 3Tf s

q, 3TTIm ftTt 31fti'tW c i ^Md Z' t^A 14 {

i 3'TTIRf (1) *, 3TgM wrft 3TR, f
(ni) "31ff,t'W„ 3T(4f 4 t UM 16 3`1
3Tf cT t I

(2) M ft44t 4 R ' d ' TR A - qNTf4U 9 f4^q TTS` "'. 3T^F{(^A^i * c1 i TT^d N Yf 3
7t it dt W4 t v 3Tft[ 4 3-4 t 1

3. 3Tl' Fi f * ' i 34IfiT4I 3M ^ zc *M * P4,m 3M
3Tfjr 3M 3T^ Td^ 31YT3,Tfid3 ff TT 44 3M aif' c u1 q4l c, f tt f T fx t 1
(2) 3 T f,ZW , 4 l T i f f T 3Tf iR 31•--^i tT. i c i4 'tRWR Tf M 3M4 5' du 1 wf^d
fwd ip-m gm 3TT-TT 4-4 1TT 3 'TT 1

(3) 3Tft4,Uf 4i,

41csNTI

31(44n

Zr271f^oTR t& ft T 3Tf4w% -ZIT N t i

3ft Am, Yi^RT, f a f f ^,Tt'Wl Ta

i t 45RU1

f t* n

(^) c`Ii'i'^^T >

(Tf) zr^ 4tur t9 3iI ' tr iii f 45t t1 T it i A iw^ 4A *, f C ww 7T Trm i
3T^ Tel c, T 1T t ;
TT T it f C wF TF um t
(A) -d-g, TI ?T11*RI MA-1 3TRTdlt'f -OT Brit 34'!

IT ZR45 >xR1 T CRTT 3T9i I

(4) 31f u 4 3TT45i( C f i 3 , a; lir t^iZ3,1'T ^Rr 3Zi

Ad

f' >}

f3f i T t, '+TZf

;+IT 1

4. TM -- (1) 3T T iE^ ftli 3TfkcT5 T A7 31-4 W4Tir f, T+^ f aR
f ad 7d iTT 451 RI-4m f IT 1 T, 3T
(co fYsT 3Tf 500 7D
(U) tTi - 400 7;0 1
(2) ^ Y1qTr5l 4 3T"F'1" T $R1 ZTATr - ZTTTLT YT '^d^i fi^N X71 TTT^'421 $,1 ' %ETW 3i Tt
^f1 1

(3) ut4 Eftl t-l 3Tfd 1 ZIT u it- Yu RT^ uT Rr^
cT,T
^'TT

^'IT f ,c 3Tf +^of c, 3T f

F foul 4 t a1 a RFt 4T,15

i thy to Tit` WT' * VZF 7

TTlm1 'T 351 >;4 4I

I

C, ZMEff 4MZ 3T;;1 'RT, ;TR 4Ttt̀ W T , 39 WT A'T t 4
5. V M AT tfkWi '"TT - 3TfF i1Qf
+ t c
, R TA it 3'F -,T Y1 4 tRM A 3T^ t 3 '; ;Uft ZTM 44EF f
4, Ti'dZ
T m *i ^dimm dTA
4 39 1IT^ 30 4'f e5 %rct -4)1 T+ct,c j 'r;^i11 c+ ''iwa wgwR *, f ft T Td l
f4mT 'T4 cm AT °T W-A 40 RF t 3TftagRl A 4r t I

6. 3Tft C "'Nu i

-- (1) 3Tf49W 4 Wt to ; tQ Fl *i ffZZ wT 4 1

lltfi
v% of 3T^ 4T TTE W7 t f lj^ * ftf^f f fft 3T--q -iwm
zh1 WT-1wqm fu T4 wsf Yat li ftWR w 4m cR T1 I

1 C-72- 4 -^I,g - 3

<!-- page 10 -->

to THE GAZETTE OF INDIA: EXTRAORDINARY [PART I1-SEC. 3(i)]

(2) 4a

3T

uq i T A

era 3Tf4W^W iil 3T,-;4 awl at >

^t 4 a ft f=rf Td aTS t

a4 Th5T% $RT 3Tf Ur 3'> 3T=4 wqi4t, #mm it

t

tURht 3T r% TT ftua P W

1 f T 31R 10 4R 17 r lartff^t

s Q&.-TM z -,
r d 3 w4i

v wi I

cf WA ft ZFr r
i5 Try' a1 ^Y ft
(3) 3ff,7M
t
(4) URf -f 3TfT , 3T1*45 or cf $ 37F2IL'i T 5 M :
q 3Tfxf=PM $ UM 16 $f -,3J

(2) * U7 (TI) * 3Tt f T tcw f

3Tf 5r , a^

cf^ 3r-Tf 4 4dzF aR aTEZTeTaT 455rT I

(5) J Raft TR-T, l 3TfdRRT aft f M 4dT ct zt 31M f, auf ra 3& ff r- IfT^ ark aa7a1 a;r
41
gm f o f T71 AT TO I 47w it gtrr a'f, flur^fm m T
I
3r34f^ f^ ^ ' ^ a u air f^ifa ur furfaq, ar a g1-ii

7.3Tf i °1 gm 3TqMt wk m AM -- (1) sttifilw, "NO flz^ * f , ;"zi -7M I
f
T r u'taf ra TTT 3f i 3rfflkz T a; 3T^T a ravl a21T fkzr it 3T T ^€ , 3rf3fi r 3T9ftf

a

21T T
7aR <n2 545

err

r ft f
u^ ag f45 AigT r, ZT 45r Aafa
I
^PaT^ 3fY7 flu flf'41 'il TM
virw -Ifl ffftN -,4 W era T? t
(2) 3Tfha^i *i auei 3Vf7^Tii et4

fk zR Tffit bra f4,7

i STw&'q&f iT7 $if ff7ft f ffi araarifl I

if a t 3r r z f eft al-;q WP^a gm Aft t

wr 34^ * R=IFT

3Ttd^r7 ^1 rr I

(3) a&;-qR t 37^ WIM,
(cF) 3T1 .T li ^ffftoT qi

a +II

daft ;41 f4,7ft f aFf a 3T^ ci^ f4aF-47 a'r V-^T gfta -,Ti7 TcOu
ar f
c1 7-q A;z 3Tr
(r) aaff err 1 f ff T 3T^41 4" fkaf
artT^i T

31^

3Ta2T2ff El

f^{cd d ^T7 a*Tii: 3f}r

(TT) wffzhl m

7r'r ft ^m 3TT4v q a w a Trr ^l ag of a TPT3 I

(4) 3#F T * 71aft 3T h aM Tafk w 3Tf wr it ' dT M 3Tf

3ff7 3T^Q 7 WT 3T^

f S-f^ 1
8. 3T i of i YIF^"fc ^T - - (1} ait f' f1 f"I i ^,f fail ^i A27 ^ fc'fr
34ft °T aR at 2r iuf *Tft fhrfWhd ftqu1 1 7T4FT ft fftcof of r 7if^UT 1908 1 3T f 8

f3if 'c ITT 4 f a t, 312Iiq :-

(4T) f 7ft 0 a>?a TT-TT 30 T;rf 7 3 NI M fl u7 Z f SS it 9T

(ia) f^,

qTTiA Zr qm -r r um -Z-^ ' f femur of T

(IT) 3T44 ui u7 a 4cw 7 r ; 3M

<!-- page 11 -->

s W, ZPM: 31> ;1

[%111TII-?1° ]

WM

11

i -ST 59T I
(A) 3R ZT=TCT W T @iif ct" Ala

9. 3t i of il 3T4* - 3TUT c1 3Ta, f' w* j $di2. VTi '-iw$i f T1z4 * 3 °fl * Ul
Z0 15 f^ff d' *R *t I

10. aTqffm 3RaFt , - 3T1 ^ it -i 34Ptf3 3N 3T-ZT WqRnz^ 3;i 4M -$ fhi* AZ ff,tdco

a; 3T uth ffa i R Wqff " ftral A At w6d 3 T f TMT t 9^
fii wn A-z wu w ii^ hr 5R wr
P*Am t f f
rz 4 3
q^A A
1 biY>Ti 3Tf grm, >fl'd11 -i 3Tf 3t^i 3T%v tlv 3T 44WZ *m I
[ml.1 f. 97/ 1112003 - 31T1l,^. III (iii) ]

NOTIFICATION
New Delhi, the 7th May, 2008

G.S.R.343 (E).-[n exercise of the powers conferred by clause (b) of sub-section
(2) of section 55, read with sub-section (3) of section 16 of the Actuaries Act, 2006 (35
of 2006), the Central Government hereby makes the following rules, namely:-

1. Short title and commencement : (1) These rules may be called the Actuaries
Tribunal (Salaries, Allowances and Other Terms and Conditions of Presiding Officer
and Members ) Rules, 2008.

(2) They shall come into fore on the date of their publication in the Official Gazette.
2. Definitions :- (1) In these Rules, unless the context otherwise requires. (a) "Act" means the Actuaries Act, 2006 (35 of 2006);
(b) "aggrieved person" means a person who contested the election to the
Council to which the dispute pertains;
(c) "dispute" means a dispute raised by an aggrieved person- arising out of
the election to the Council of the Institute;
(d) "election" means election to the Council held under sub-section (a) of
section 12 of the Act;

(c) "Presiding Officer" means a person appointed as Presiding Officer of a
Tribunal under clause (a) of sub-section (2) of section 16 of the Act,
(f) "legal practitioner" means a person registered with the Bar Council of
India or any of the State Bar Council and is eligible to appear before the
Court of law;

<!-- page 12 -->

12 THE GAZETTE OF INDIA : EXTRAORDINARY [PART II-SK. 3(i)]
(g) "Member" means a person appointed as a Member of a Tribunal under
clauses (h) and (c) of sub-section (2) of section 16 of the Act,
respectively,
(h) "Tribunal" means the Tribunal established under sub-section (1) of
section 16 of the Act.
(2) All other words and expressions used herein and not defined in these rules but
defined in the Act shall have the same meanings respectively assigned to them in the
Act.
3. Terms and conditions of service of the Presiding Officer and Members of
the Tribunal : (1) The Presiding Officer and other members of the Tribunal shall be
part-time members and shall be appointed for the term of the Tribunal.

(2) The Presiding Officer or a member of the Tribunal may resign his office by a
notice in writing under his hand addressed to the Central Government.
O The Presiding Officer and each member of the Tribunal may cease to remain
the Presiding Officer or member, as the case may be, due to any of the following
reasons.-

(a) death; or
(h) resignation; or

(c) becoming physically or mentally incapable of acting as the Presiding
Officer or a Member, as the case may be ; or
(d) his being no long being eligible to be the Presiding Officer or a Member,
as the case may he; or
(c) removal by the Central Government.
(4) A casual vacancy in the Tribunal shall be filled by the Central Government, by a
notification, from out of the categories in which such vacancy occurs.
4. Allowances :- (1) The Presiding Officer and other members of the Tribunal
shal I he paid the following amount as allowance for each day of sitting, namely,:(a)

Presiding Officer -

Rs.500;

(h)

Members -

Rs.400.

(2) I he Central Government may revise the sitting fee or honorarium from time to
Limo. through notification in the Official Gazette.

(3) If the Presiding Officer or Member is in employment with the Central
Government or State Government, he shall not be eligible for any sitting fees but shall
be eligible for a lump sum honorarium of Rs. 5000/- for the term of the Tribunal.

<!-- page 13 -->

[9IFTII-&i^3 ( i)]

giRd -IFT M • M MM

5. Travelling and daily Allowance .- The Presiding Officer and other Members
of the Tribunal, while on tour, shall be entitled to the travelling allowance and daily
allowances as admissible to them in their official capacity and in case the Member is
not a Government servant, he shall be entitled to the travelling allowance and daily
allowances as admissible to an officer holding a post carrying a scale of pay of a Joint
Secretary to the Government of India.

6. Meetings of Tribunal :- (1) All meetings of the Tribunal shall be held at
the headquarters of the Institute:
Provided that, if the Tribunal is of the opinion that in the interest of justice it is
expedient to hold a meeting at any other place than the headquarters of the Institute, it
may hold a meeting at such a place.

(2) The date and time of the meetings shall be fixed by the Presiding Officer in
consultation with other Members of the Tribunal: 0
Provided that, a notice of not less than fifteen days before the scheduled date of
every such meeting shall be given by the Presiding Officer to the other Members of the
Tribunal, Secretary of the Institute and the parties involved.

(3) The quorum for transaction of business at a meeting of the Tribunal shall be
two.

(4) The Presiding Officer shall preside at all the meetings of the Tribunal:
Provided that in the absence of Presiding Officer, the member appointed under
clause (c) of sub-section (2) of section 1.6 of the Act shall chair the meeting.
(5) All questions which come up before any meeting of the Tribunal shall be
decided by a majority of the members present and voting, and in the event of an
equality of votes, the Presiding Officer or in his absence, the member presiding, shall
have a second or casting vote.

7. Procedure to be adopted by the Tribunal :- (1) In the discharge of its
functions, the Tribunal shall be guided by the principles of natural justice and, subject
to the other provisions of the Act and these rules, the Tribunal shall regulate its own
procedure:

13

<!-- page 14 -->

14 THE GAZETTE OF INDIA : EXTRAORDINARY [PART II-She. 3(i)]
Provided that, as far as practicable, the Tribunal shall try to ensure that a dispute
is heard and decided by it within six months from the date of its constitution.

(2) Lven party appearing before the Tribunal shall have the right to be represented
before it by a legal practitioner or, with the permission of the Tribunal , by any other
person.

(3) At the time of giving its decision, the Tribunal may,(a) dismiss the application;
(h) declare the election of all or any of the elected candidates to be void
(c) declare the election of all or any of the elected candidates to be void and
the applicant or any other candidate to have been duly elected; and
(d) may pass such order as to costs as it may consider appropriate.

(4) All orders and decisions of the Tribunal shall be authenticated by the Presiding
Officer and other members of the Tribunal.
8. Powers of the Tribunal :- (1) For the purpose of deciding a dispute under
these rules. the Tribunal shall have the same powers as are vested in a Civil Court under
the Code of Civil Procedure. 1908 in respect of the following matters, namely:(a) summoning and enforcing the attendance of any person and examining him
on oath:

(b) the discovery and production of any document:
(c) receiving evidence on affidavit: and
(d) cross-examining the witnesses produced before it.
9. Duration of the Tribunal :- The term of the Tribunal shall be over within 15
days from the date of announcement of its decision on the dispute under reference.
10. Residuary provision :- Matters relating to the terms and conditions of
services of the Presiding Officer and other members of the Tribunal, the place of
meetings and allowances, with respect to which no express provision has been made in
these rules shall be referred in each case to the Central Government for its decision and
the decision of the Central Government thereon shall be binding on the Tribunal, the
Presiding Officer and other members.

[F. No. 97/11/2003-Ins. III (iii).
TARUN BAJAJ, It. Secy.

, Govt. Of India Press, Ring Road, Mayapuri, New Delhi-110064
Printed by the Manager
, Delhi-110054.
and Published by the Controller of Publications
