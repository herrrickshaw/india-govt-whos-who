---
doc_id: "89aaa50c28ffd9ac"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/950eb28d06344984444f288a4059bddf.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Correction / updattion of personal details of seven Panel Counsel: Order dated 26.09.2019"
date: "2019-10-01"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "112fade687c8c8fb"
---

<!-- page 1 -->

| F. No. J-11017/2/2019-Judicial(Part-4)
| Government of India
Ministry of Law and Justice |
Department of Legal Affairs
(Judicial Section)
KEKK *
Shastri Bhawan, New Delhi, | |
| Dated 26" September, 2019
ORDER
| With reference to this Departments earlier Orders, as mentioned under column-lV in
the table ‘A’ below, the personal details of the panel counsel whose names occur under
column-ll and who were empanelled for the courts mentioned under column-lll, stand
corrected / up-dated as shown under column-V in the same table ‘A’ below:
| Table ‘A’
Si. | Name of the | Name of | Details of | Corrections / up-dations
No. | Counsel Court/tribunal and | concerned Order | to be made in the order as
(as per office | category of panel | and serial number | mentioned under column :
records empanelled for WW = ba! |
ee जा ए1॒1ए्ए V
1. Venkata Raghu | Supreme Court of | J-11016/1/2019- Address:
Vamsy Dasika India, Group ‘B’ | Judicial (Part-1) | B-21, (2"° Floor),
Panel dated 08.03.2019, | Kakateeya Apartments,
(Under Gr. ‘B’ | I.P. Extension,
| Panel at SI. No. | Patparganj, New Delhi- |
| 1S) 110092
| Email: raghu@dasika.net |
. Enrl. No. AP/1957/2011
| 22. Punit Garg District & J-11015/2/2019- Name: PUNEET GARG |
Subordinate Judicial dated | Mob: 9214966952 |
) Courts, Bharatpur 09.03.2019, |
(Rajasthan), Addl. (Under Bharatpur |
| Standing Govt. at SI. No. 4) |
| Counsel |
3) Ms. Baskaran | High Court of | J-11017/20/2018- | Name: Ms. B. DEEPA
Deepa Madras, Madurai | Judicial dated |
Bench, Central | 06.08.2018
: Govt. Counsel
' (at SI. No. 121)
4. 3008 Dipa | District & | J-11015/6/201 7- Name: SOUMYA DIPTA
| Saha | Subordinate Judicial dated SAHA :
Courts, Hooghly | 10.07.2017
(VV.B.), Addl. | (Under Dist.
Standing Govt. | Hooghly at SI. No.
| Counsel 13)
Ne ae

<!-- page 2 -->

2. Sanjay Kumar | Supreme Court of J-11016/1/2019- Name: SANJAY OMAR
Yadavs India, Group ‘B’ Judicial (Part-1) | YADAV
Panel Dated 08.03.2019 © |
(Under = B |
Panel at SI. No. |
mL i 132) a रा ह॥
Madhu Varrier District & | J-11015/1/2015- Name: M. -
Subordinate Jud. dated WARRIER
Courts, Alapuzha | 07.12.2015 read
(Kerala) with Order with
same No. dated
08.03.2019,
(Under Dist.
Alapuzha at Sl.
| No. 5)
7. Ms. Neeta High Court of | J-11017/13/2018- | Name: Ms. NEETA
Verma Jharkhand at | Judicial dated KRISHNA
Ranchi, Central | 07.03.2019,
Govt. Counsel (at SI. No. 5)
2. Hindi Version of this order will follow.
Ewe _
(S. R. Mishra)
Additional Secretary
Copy for information to:-
1. PS to ML&J/PS to Law Secreta’y/PS to Legislative Secretary/All Additional Secretaries/PS to all
JS&LA in the Main Sectt.
2. The lncharge, Central Agency Section, Supreme Court of India, New Delhi.
3. The Incharge, Branch Secretariat at Mumbai, Kolkata, Chennai & Bengaluru.
4. Shri Rajdeepak Rastogi, ASGI for the High Court of Rajasthan.
5. Shri P. Vijay Kumar, Asst. SGI, High Court of Kerala.
6. Shri Rajiv Sinha, Asst. SGI, High Court of Jnarkhand, Ranchi.
7. Shri V. Kathirvelu, Asst. SGI, Madurai Bench of Madras High Court.
8. Shri Dinesh Chand Sharma, Standing Govt. Counsel District Bharatpur, Rajasthan.
9. Shri Ajay Kumar Das, Standing Govt Counsel, District Hooghly, Chandannagor Court, Hooghly,
West Bengal.
10. Ms. P. S. Geetahkumari, Standing Govt. Counsel, District Alapuzha, Kerala.
11. All the Panel Counsel as mentioned in table ‘A’ above.
12. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
13. For uploading on website of this Department |.e. www.legalaffairs.gov.in for the information of
all concerned.
14. Guard File/Judicial Section with 5 spare copies.
LN, "=
Section Officer (Judicial)
Tel.011-23384945
Email: judicial-dla@nic.in
