---
doc_id: "85d0d5ed5a7eb5ce"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/ExtensionC0220C03545556_20082026_60e82.pdf"
ministry: "Department of Space"
title: "Corrigendum: VSSC/CMG/C03/54/2026-27 Dated: 04.08.2026      806.38 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "528daf9fa42247f4"
---

<!-- page 1 -->

भारत सरकार/GOVERNMENT OF INDIA
अं त र िवभाग/DEPARTMENT OF SPACE
िव म साराभाई अंत र क /VIKRAM SARABHAI SPACE CENTRE
िनमाण एवं अनुर ण ु प/CONSTRUCTION AND MAINTENANCE GROUP
िनमाण एवं अनुर ण भाग-सं िवदाएं /CONSTRUCTION AND MAINTENANCE DIVISION-CONTRACTS
ित वनं तपुरम/THIRUVANANTHAPURAM – 22/ (फोननं./Ph. No.0471 – 2565669 / 2564622/2565117).

ई-िनिवदा की अविध बढ़ाना/EXTENSION OF E-TENDER
िदनां क/Dt.20.08.2026
.स
Sl.No
1.

ौरे /Details

िववरण/Description

(1)

काय का शीषक/Title of
work

हाउिसंग कॉलनी वीएसएससी म नौ महीने के िलए

वीआरसी, वीएसएससी के सीएमडी-िवद् युत तथा एसी

वीआरसी की बगल म नाइटोजन जनरे टर के

लघु/अनु र ण िसिवल तथा पीएच काय

कायालय भवन म रसाव अवरोधक काय

सं थापन के िलए शेड का िनमाण

काया यन

Construction of shed for installation of

contract

Nitrogen Generator by the side of

minor/maintenance Civil &PH works for

Polymer

nine months at Housing Colony VSSC

लक कॉ

े

(2)

(वी-20 भवन),वीएसएससी,

Complex

(V-20

Building),

हे तु
for

(3)

साविधक

के

संिवदा

/Term

execution

of

Leak arresting works in CMD- Electrical and
AC office Building at VRC, VSSC.

VRC,VSSC
2.

3.

4.

ई-िनिवदा सूचना सं./ ETender Notice No.
िनिवदा म दी गई अनु मािनत
लागत/ Estimate cost
put to tender
काय पूरा होने की ितिथ
Period of completion

वीएसएससी/सीएमजी/C02/20/2026-27
VSSC/CMG/C02/20/2026-27
Dt: 04.08.2026

वीएसएससी/सीएमजी/C03/54/2026-27
VSSC/CMG/C03/54/2026-27
04.08.2026

वीएसएससी/सीएमजी/C03/56/2026-27
VSSC/CMG/C03/56/2026-27
Dt: 04.08.2026

./Rs. 6.59 लाख/Lakhs

./Rs. 25.00 लाख/Lakhs

./Rs.8.43 लाख/Lakhs

(03) तीन महीने / Three Months

(09) नौ महीने /Nine Months

(03) तीन महीने / Three Months

बयाना जमा रािश (ईएमडी)
./Rs.13,180/./Rs.50,000/./Rs.16,860/Earnest money deposit
(EMD
डाउनलोड करने की अविध/Period for
बोली
ीकरण/ Bid clarifications: िदनांक
िनिवदाओं की ा /Receipt of tenders:
िनिवदाओं को खोलना/Opening of tenders:
downloading: िदनांक 05.08.2026, 15.00
06.08.2026, 9.00 बजे /hrs से/to िदनांक
िदनांक 18.08.2026 को 23.00 बजे/hrs
िदनां क 20.08.2026 को 15.00 बजे/hrs
Extended Upto 03.09.2026, 23.00
Extended Upto 07.09.2026, 15.00
बजे /hrs से/ to िदनांक 16.08.2026, 23.00
17.08.2026,12.00 बजे/hrs
बजे/hrs
बजे /hrs
Extended Upto 02.09.2026, 12.00 बजे/hrs बजे/hrs
Extended Upto 01.09.2026, 23.00
बजे/hrs
5.

Sd/-

उप भाग

धान / सीएमडी – संिवदाएं

Deputy Div.Head / CMD – Contracts
