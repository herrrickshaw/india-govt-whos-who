---
doc_id: "892ff2f0eea90aff"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/d88862316afe563a8375c373ecc1530c.pdf"
ministry: "Tourism"
title: "Corrigendum--- Request for Proposal (RFP) for Selection of Brand Strategy and Design Agency for Incredible India Digital Platform."
date: "2022-02-25"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0e40281ad70c2d23"
---

<!-- page 1 -->

= No: IT-5/1/2019 Date: 20.01.2022
CORRIGENDUM
Request for Proposal [RFP]
for
Selection of Brand Strategy and Design Agency for Incredible India Digital Platform
Ministry of Tourism
Government of India
. Date of Issue: 25'" February 2022
|. Corrigendum to Tender Reference Number IT-5/1/2019 and Corrigenda dated 4" & 17"
February 2022
This is for information of all the bidders that the Tender Document (Tender Reference
Number IT-5/1/2019 dated January 20, 2022) for “Selection of Brand Strategy and Design
Agency for Incredible India Digital Platform” has been amended, as under.
e Last date and time of Bid submission: 07.03.2022 (Monday) 16:00 Hrs
e Technical Bid Opening: 08.03.2022 (Tuesday) 16:00 Hrs
Bidders are requested to submit their bids accordingly: Po.
a
ie umar Devrani
Under Secretary to the Government of India
Ministry of Tourism
