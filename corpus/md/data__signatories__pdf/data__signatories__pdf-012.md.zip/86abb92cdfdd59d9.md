---
doc_id: "86abb92cdfdd59d9"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/3635135dd8a2ccd5d5ea16597917d640.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Strengthen the Ecosystem for MSE regarding."
date: "2018-10-17"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "22beaf50ae45453c"
---

<!-- page 1 -->

DPE/7(4)/2017-Fin.
Government of India
Ministry of Heavy Industries& Public Enterprises
Department of Public Enterprises
आज ले जे के
Public Enterprises Bhawan |
* Block No.14, CGO Complex |
Lodhi Road, NewDelhi-110003 |
Date: 17.10.2018 |
OFFICE MEMORANDUM
Sub.: Strengthen the Ecosystem for MSEs—regarding,
The undersigned is directed to invite reference to this Office OM of even number
dated 17.11.2017 regarding registration of CPSEs on the “TReDS” platform of D/o Financial
Services and use of an online Portal “MSME-SAMADHAAN™ of M/o MSME. for resolution
of grievance of MSEs, especially regarding delayed payments and OM of even number
dated 29.1.2018 regarding uploading the procurement related details of CPSEs on the “MSME
SAMBANDH"” Portal of M/o MSME.
z= It may be ensured that all MSE Vendors registered with CPSEs are also registered on
“TReDS” platform(www.rxil.in) and “MSME-SAMADHAAN” Portal by 25" October, 2018.
In this regard, it is reiterated that all CPSEs are mandatorily required to be onboard on
“TReDS” and “SAMBANDH” Portal and regularly review the “SAMADHAAN” Portal for
timely resolution of grievance of MSEs.
3. All administrative Ministries’ Departments of CPSEs are requested to direct all the
CPSEs under their control to take necessary steps for strict compliance of the Ld directions,
4, This issues with the approval of competent Authority.
e eK. Goyal)
Adviser ¢¢
Tel. 24365841
To
Secretaries to the Ministries/Departments of Government of India
Copy tox
CMD’s/ CEO’s of all CPSEs
