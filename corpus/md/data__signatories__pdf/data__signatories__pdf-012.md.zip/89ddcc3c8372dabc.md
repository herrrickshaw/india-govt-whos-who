---
doc_id: "89ddcc3c8372dabc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/1a486c5c8e199abd10a3078d12dd61e6.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Circular 1 of 2011 - Consolidated FDI Policy"
date: "2025-07-02"
pages: 121
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6dc0263c039766bd"
---

<!-- page 1 -->

Department of Industrial Policy and
Promotion
Ministry of Commerce and Industry
Government of India

CONSOLIDATED FDI POLICY
(EFFECTIVE FROM APRIL 1, 2011)

<!-- page 2 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
(FC Section)

CIRCULAR 1 OF 2011
SUBJECT:

CONSOLIDATED FDI POLICY.

The “Consolidated FDI Policy” is attached.
2. This circular will take effect from April 1, 2011.

(V.Bhaskar)
Joint Secretary to the Government of India
D/o IPP F. No. 5(1)/2011-FC Dated 31.03.2011
Copy forwarded to:
1.
2.
3.
4.

Press Information Officer, Press Information Bureau- for giving wide publicity to the
above circular.
BE Section for uploading the circular on DIPP's website.
Department of Economic Affairs, Ministry of Finance, New Delhi
Reserve Bank of India, Mumbai

1

<!-- page 3 -->

INDEX
DESCRIPTION

PAGE
NUMBER

CHAPTER-1 INTENT AND OBJECTIVE

5

CHAPTER-2 DEFINITIONS

8

CHAPTER-3 ORIGIN, TYPE, ELIGIBILITY,
CONDITIONS AND ISSUE/TRANSFER OF
INVESTMENT

14

3.1 Who can invest in India?
3.2. Types of Instruments
3.3 Entities into which FDI can be made
3.4 Conditions on Issue/Transfer of Shares
3.5 Issue of Instruments

14
15
18
19
25

CHAPTER-4 CALCULATION, ENTRY ROUTE, CAPS,
ENTRY CONDITIONS ETC. OF INVESTMENT

28

4.1

28

1.1 Intent And Objective

2.1 Definitions

Calculation of Total Foreign Investment i.e. Direct and Indirect Foreign
Investment in Indian Companies
4.2 Entry Routes for Investment
4.3 Caps on Investments
4.4 Entry conditions on Investment
4.5 Other conditions on Investment besides entry conditions
4.6 Downstream Investment by Indian Companies
4.7 Guidelines for consideration of FDI Proposals by FIPB
4.8 Constitution of FIPB
4.9 Approval Levels for cases under Government Route
4.10 Cases which do not require fresh Approval
4.11 Online filing of applications for FIPB/Government’s approval

5
8

31
33
33
33
34
36
38
38
39
39

CHAPTER-5 POLICY ON ROUTE, CAPS AND ENTRY
CONDITIONS

40

5.1 PROHIBITION ON INVESTMENT IN INDIA

40

5.2 SECTOR-SPECIFIC POLICY FOR FDI

40

AGRICULTURE

40

5.2.1 Agriculture & Animal Husbandry
5.2.2 Tea plantation

40
42

2

<!-- page 4 -->

INDUSTRY
MINING

43
43

MANUFACTURING

45

5.2.4 Manufacture of items reserved for production in Micro and Small
Enterprises (MSEs)
5.2.5 Defence

45

POWER

48

5.2.6 Electric Generation, Transmission, Distribution and Trading

48

SERVICES SECTOR

49

5.2.7 Civil Aviation Sector
5.2.8 Asset Reconstruction Companies
5.2.9 Banking –Private sector
5.2.10 Banking- Public Sector
5.2.11 Broadcasting
5.2.12 Commodity Exchanges
5.2.13 Development of Townships, Housing, Built-up infrastructure and
Construction-development projects
5.2.14 Credit Information Companies (CIC)
5.2.15 Industrial Parks both setting up and in established Industrial Parks
5.2.16 Insurance
5.2.17 Infrastructure Company in the Securities Market
5.2.18 Non-Banking Finance Companies (NBFC)
5.2.19 Petroleum & Natural Gas Sector
5.2.20 Print Media
5.2.21 Security Agencies in Private sector
5.2.22 Satellites – Establishment and operation
5.2.23 Telecommunication
5.2.24 Trading
5.2.25 Courier services for carrying packages, parcels and other items which do
not come within the ambit of the Indian Post Office Act, 1898
NOTE

49
52
53
55
56
57
58

5.2.3 Mining

CHAPTER-6 REMITTANCE, REPORTING AND
VIOLATION
6.1 Remittance and Repatriation
6.2 Reporting of FDI
6.3 Adherence to Guidelines/Orders and Consequences of Violation
Penalties
Adjudication and Appeals
Compounding Proceedings

43

46

61
61
63
63
63
66
66
67
68
68
73
76
77

78
78
79
82
82
82
83

3

<!-- page 5 -->

ANNEXURES
Annex-1-A Form FC-GPR

84

Annex-1-B Form Annual Return on Foreign Liabilities and Assets

91

Annex-2 Terms and conditions for transfer of capital instruments from resident to
non-resident and vice-versa

104

Annex-3 Documents to be submitted by a person resident in India for transfer of
shares to a person resident outside India by way of gift

108

Annex-4 Definition of "relative" as given in Section 6 of Companies Act, 1956

109

Annex-5 Report by the Indian company receiving amount of consideration for
issue of shares / convertible debentures under the FDI scheme

110

Annex-6 Know Your Customer (KYC) Form in respect of the non-resident
investor

112

Annex-7 Form FC-TRS

113

Annex-8 Form DR

118

Annex-9 Form DR - Quarterly

120

4

<!-- page 6 -->

CHAPTER 1: INTENT AND OBJECTIVE
1.1

INTENT AND OBJECTIVE

1.1.1

It is the intent and objective of the Government to promote foreign direct investment

through a policy framework which is transparent, predictable, simple and clear and reduces
regulatory burden. The system of periodic consolidation and updation is introduced as an
investor friendly measure.
1.1.2

‘Investment’ is usually understood as financial contribution to the capital of an enterprise

or purchase of shares in the enterprise. ‘Foreign investment’ is investment in an enterprise by a
Non-Resident irrespective of whether this involves new capital or re-investment of earnings.
Foreign investment is of two kinds – (i) Foreign Direct Investment (FDI) and (ii) Foreign
Portfolio Investment.
1.1.3

International Monetary Fund (IMF) and Organization for Economic Cooperation and

Development(OECD) define FDI similarly as a category of cross border investment made by a
resident in one economy (the direct investor) with the objective of establishing a ‘lasting interest’
in an enterprise (the direct investment enterprise) that is resident in an economy other than that of
the direct investor. The motivation of the direct investor is a strategic long term relationship
with the direct investment enterprise to ensure the significant degree of influence by the direct
investor in the management of the direct investment enterprise. Direct investment allows the
direct investor to gain access to the direct investment enterprise which it might otherwise be
unable to do. The objectives of direct investment are different from those of portfolio investment
whereby investors do not generally expect to influence the management of the enterprise. In the
Indian context, FDI is defined in Para 2.1.12 of this Circular.
1.1.4 It is the policy of the Government of India to attract and promote productive FDI in
activities which significantly contribute to industrialization and socio-economic development.
FDI supplements domestic capital and technology.

5

<!-- page 7 -->

1.1.5

The Legal basis: Foreign Direct Investment by non-resident in resident entities through

transfer or issue of security to person resident outside India is a ‘Capital account transaction’ and
is regulated under FEMA, 1999 and its regulations. Keeping in view the current requirements,
the Government from time to time comes up with new regulations and amendments/changes in
the existing ones through order/allied rules, Press Notes, etc. The Department of Industrial
Policy and Promotion (DIPP), Ministry of Commerce & Industry, Government of India makes
policy pronouncements on FDI through Press Notes/ Press Releases which are notified by the
Reserve Bank of India as amendment to the Foreign Exchange Management (Transfer or Issue of
Security by Persons Resident Outside India) Regulations, 2000 (notification No.FEMA 20/2000RB dated May 3, 2000). These notifications take effect from the date of issue of Press Notes/
Press Releases, unless specified otherwise therein. The procedural instructions are issued by the
Reserve Bank of India vide A.P.Dir. (series) Circulars. The regulatory framework over a period
of time thus consists of Acts, Regulations, Press Notes, Press Releases, Clarifications, etc.
1.1.6 The Circular 1 of 2010 and Circular 2 of 2010 issued by this Department on 31st March
2010 and 30th September 2010 respectively, consolidated into one document all the prior
policies/regulations on FDI which are contained in FEMA, 1999, RBI Regulations under FEMA,
1999 and Press Notes/Press Releases/Clarifications issued by DIPP and reflected the current
policy framework on FDI.

The present consolidation subsumes and supersedes all Press

Notes/Press Releases/Clarifications/ Circulars issued by DIPP, which were in force as on March
31, 2011, and reflects the FDI Policy as on April 1, 2011. This Circular accordingly will take
effect from April 1, 2011. Its next revision will be published on 30.09.2011.
1.1.7

Notwithstanding

the

rescission

of

earlier

Press

Notes/Press

Releases/Clarifications/Circulars, anything done or any action taken or purported to have been
done or taken under the rescinded Press Notes/Press Releases/Clarifications/Circulars prior to
April 1, 2011, shall, in so far as it is not inconsistent with those Press Notes/Press
Releases/Clarifications/Circulars, be deemed to have been done or taken under the corresponding
provisions of this circular and shall be valid and effective.
1.1.8

While this circular consolidates FDI Policy Framework, the legal edifice is built on

notifications issued by RBI under FEMA. Therefore, any changes notified by RBI from time to

6

<!-- page 8 -->

time would have to be complied with and where there is a need / scope of interpretation, the
relevant FEMA notification will prevail.

1.1.9

Reference to any statute or legislation made in this Circular shall include

reference to any modifications, amendments or re-enactments thereof.
______________________________________________________________________

7

<!-- page 9 -->

CHAPTER 2: DEFINITIONS
2.1
2.1.1

DEFINITIONS: The definitions of terms used in this circular are as follows:‘AD Category-I Bank’ means a bank( Scheduled Commercial, State or Urban
Cooperative) which is authorized under Section 10(1) of FEMA to undertake all
current and capital account transactions according to the directions issued by the RBI
from time to time.

2.1.2

‘Authorized Bank’ means a bank including a co-operative bank (other than an
authorized dealer) authorized by the Reserve Bank to maintain an account of a person
resident outside India

2.1.3

‘Authorized Dealer’ means a person authorized as an authorized dealer under subsection (1) of section 10 of FEMA.

2.1.4

‘Authorized Person’ means an authorized dealer, money changer, offshore banking
unit or any other person for the time being authorized under Sub-section (a) of
Section 10 of FEMA to deal in foreign exchange or foreign securities.

2.1.5

‘Capital’ means equity shares; fully, compulsorily & mandatorily convertible
preference shares; fully, compulsorily & mandatorily convertible debentures.
Note : Warrants and partly paid shares can be issued to person/ (s) resident outside
India only after approval through the Government route 1.

2.1.6

‘Capital account transaction’ means a transaction which alters the assets or liabilities,
including contingent liabilities, outside India of persons resident in India or assets or
liabilities in India of persons resident outside India, and includes transactions referred
to in sub-section (3) of section 6 of FEMA.

2.1.7

A company is considered as “Controlled” by resident Indian citizens if the resident
Indian citizens and Indian companies, which are owned and controlled by resident
Indian citizens, have the power to appoint a majority of its directors in that company .

1

Review of FDI policy to include warrants and partly-paid shares is under consideration of the Government.

8

<!-- page 10 -->

2.1.8

An entity is considered as ‘Controlled’ by ‘non resident entities’, if non-residents
have the power to appoint a majority of its directors

2.1.9

‘Depository Receipt’ (DR) means a negotiable security issued outside India by a
Depository bank, on behalf of an Indian company, which represent the local Rupee
denominated equity shares of the company held as deposit by a Custodian bank in
India. DRs are traded on Stock Exchanges in the US, Singapore, Luxembourg, etc.
DRs listed and traded in the US markets are known as American Depository Receipts
(ADRs) and those listed and traded anywhere/elsewhere are known as Global
Depository Receipts (GDRs).

2.1.10

‘Erstwhile Overseas Corporate Body’ (OCB) means a company, partnership firm,
society and other corporate body owned directly or indirectly to the extent of at least
sixty percent by non-resident Indian and includes overseas trust in which not less than
sixty percent beneficial interest is held by non-resident Indian directly or indirectly
but irrevocably and which was in existence on the date of commencement of the
Foreign Exchange Management (Withdrawal of General Permission to Overseas
Corporate Bodies (OCBs) ) Regulations, 2003 (the Regulations) and immediately
prior to such commencement was eligible to undertake transactions pursuant to the
general permission granted under the Regulations.

2.1.11

‘Foreign Currency Convertible Bond’(FCCB) means a bond issued by an Indian
company expressed in foreign currency, the principal and interest of which is payable
in foreign currency. FCCBs are issued in accordance with the Foreign Currency
Convertible Bonds and ordinary shares (through depository receipt mechanism)
Scheme 1993 and subscribed by a non-resident entity in foreign currency and
convertible into ordinary shares of the issuing company in any manner, either in
whole, or in part.

2.1.12

‘FDI’ means investment by non-resident entity/person resident outside India in the
capital of the Indian company under Schedule 1 of FEM(Transfer or Issue of Security
by a Person Resident Outside India) Regulations 2000.

2.1.13

‘FEMA’ means the Foreign Exchange Management Act 1999 (42 of 1999).

9

<!-- page 11 -->

2.1.14

‘FIPB’ means the Foreign Investment Promotion Board constituted by the
Government of India.

2.1.15

‘Foreign Institutional Investor’(FII) means an entity established or incorporated
outside India which proposes to make investment in India and which is registered as a
FII in accordance with the SEBI (FII) Regulations 1995.

2.1.16

‘Foreign Venture Capital Investor’ (FVCI) means an investor incorporated and
established outside India, which is registered under the Securities and Exchange
Board of India (Foreign Venture Capital Investor) Regulations, 2000 {SEBI(FVCI)
Regulations} and proposes to make investment in accordance with these Regulations

2.1.17

‘Government route’ means that investment in the capital of resident entities by nonresident entities can be made only with the prior approval from FIPB, Ministry of
Finance or SIA, DIPP as the case may be.

2.1.18

‘Holding Company’ would have the same meaning as defined in Companies Act
1956.

2.1.19

‘Indian Company’ means a company incorporated in India under the Companies Act,
1956.

2.1.20

‘Indian Venture Capital Undertaking’ (IVCU) means an Indian company:─
(i) whose shares are not listed in a recognised stock exchange in India;
(ii) which is engaged in the business of providing services, production or manufacture
of articles or things, but does not include such activities or sectors which are specified
in the negative list by the SEBI, with approval of Central Government, by notification
in the Official Gazette in this behalf.

2.1.21

‘Investing Company’ means an Indian Company holding only investments in other
Indian company/ (ies), directly or indirectly, other than for trading of such
holdings/securities.

2.1.22

‘Investment on repatriable basis’ means investment, the sale proceeds of which, net
of taxes, are eligible to be repatriated out of India and the expression ‘investment on
non-repatriable basis’ shall be construed accordingly.

10

<!-- page 12 -->

2.1.23

‘Joint Venture’ (JV) means an Indian entity incorporated in accordance with the laws
and regulations in India in whose capital a non-resident entity makes an investment.

2.1.24

‘Non resident entity’ means a ‘person resident outside India’ as defined under FEMA.

2.1.25

‘Non Resident Indian’ (NRI) means an individual resident outside India who is a
citizen of India or is a person of Indian origin.

2.1.26

A company is considered as 'Owned’ by resident Indian citizens if more than 50% of
the capital in it is beneficially owned by resident Indian citizens and / or Indian
companies, which are ultimately owned and controlled by resident Indian citizens;

2.1.27

An entity is considered as ‘Owned’ by ‘non resident entities’, if more than 50% of the
capital in it is beneficially owned by non-residents.

2.1.28

‘PAB’ means Project Approval Board in DIPP, Ministry of Commerce & Industry,
Government of India.

2.1.29

‘Person’ includes
(i) an individual
(ii) a Hindu undivided family,
(iii) a company
(iv) a firm
(v) an association of persons or a body of individuals whether incorporated or
not,
(vi) every artificial juridical person, not falling within any of the preceding subclauses, and
(vii) any agency, office, or branch owned or controlled by such person.

2.1.30

‘Person of Indian Origin’ (PIO) means a citizen of any country other than Bangladesh
or Pakistan, if
(i) he at any time held Indian Passport
(ii) he or either of his parents or any of his grandparents was a citizen of India by

11

<!-- page 13 -->

virtue of the Constitution of India or the Citizenship Act, 1955 (57 of 1955);
or
(iii) the person is a spouse of an Indian citizen or a person referred to in subclause (i) or (ii).
2.1.31

‘Person resident in India’ means (i) a person residing in India for more than one hundred and eighty-two days
during the course of the preceding financial year but does not include –
(A) A person who has gone out of India or who stays outside India, in either
case(a) for or on taking up employment outside India, or
(b) for carrying on outside India a business or vocation outside India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay outside India for an uncertain period;
(B) A person who has come to or stays in India, in either case, otherwise than(a) for or on taking up employment in India; or
(b) for carrying on in India a business or vocation in India, or
(c) for any other purpose, in such circumstances as would indicate his
intention to stay in India for an uncertain period;
(ii) any person or body corporate registered or incorporated in India,
(iii) an office, branch or agency in India owned or controlled by a person resident
outside India,
(iv)an office, branch or agency outside India owned or controlled by a person
resident in India.

2.1.32

‘Person resident outside India’ means a person who is not a Person resident in India.

2.1.33

‘RBI’ means the Reserve Bank of India established under the Reserve Bank of India
Act, 1934.

2.1.34

‘Resident Entity’ means ‘Person resident in India’ excluding an individual.

2.1.35

‘Resident Indian Citizen’ shall be interpreted in line with the definition of ‘person
resident in India’ as per FEMA, 1999, read in conjunction with the Indian Citizenship

12

<!-- page 14 -->

Act, 1955.
2.1.36

‘SEBI’ means the Securities and Exchange Board of India established under the
Securities and Exchange Board of India Act, 1992.

2.1.37

‘SEZ’ means a Special Economic Zone as defined in Special Economic Zone Act,
2005.

2.1.38

‘SIA’ means Secretariat of Industrial Assistance in DIPP, Ministry of Commerce &
Industry, Government of India.

2.1.39

‘Transferable Development Rights’ (TDR) means certificates issued in respect of
category of land acquired for public purposes either by the Central or State
Government in consideration of surrender of land by the owner without monetary
compensation, which are transferable in part or whole.

2.1.40

‘Venture Capital Fund’ (VCF) means a Fund established in the form of a Trust, a
company including a body corporate and registered under Securities and Exchange
Board of India (Venture Capital Fund) Regulations, 1996, which
(i) has a dedicated pool of capital;
(ii) raised in the manner specified under the Regulations; and
(iii) invests in accordance with the Regulations.

13

<!-- page 15 -->

CHAPTER 3: ORIGIN, TYPE, ELIGIBILITY, CONDITIONS
AND ISSUE/TRANSFER OF INVESTMENT
3.1

WHO CAN INVEST IN INDIA?

3.1.1 A non-resident entity (other than a citizen of Pakistan or an entity incorporated in Pakistan)
can invest in India, subject to the FDI Policy. A citizen of Bangladesh or an entity incorporated
in Bangladesh can invest in India under the FDI Policy, only under the Government route.
3.1.2 NRIs resident in Nepal and Bhutan as well as citizens of Nepal and Bhutan are permitted
to invest in the capital of Indian companies on repatriation basis, subject to the condition that the
amount of consideration for such investment shall be paid only by way of inward remittance in
free foreign exchange through normal banking channels.
3.1.3 OCBs have been derecognized as a class of Investors in India with effect from September
16, 2003. Erstwhile OCBs which are incorporated outside India and are not under the adverse
notice of RBI can make fresh investments under FDI Policy as incorporated non-resident entities,
with the prior approval of Government of India if the investment is through Government route;
and with the prior approval of RBI if the investment is through Automatic route.
3.1.4 (i) An FII may invest in the capital of an Indian Company under the Portfolio Investment
Scheme which limits the individual holding of an FII to 10% of the capital of the
company and the aggregate limit for FII investment to 24% of the capital of the company.
This aggregate limit of 24% can be increased to the sectoral cap/statutory ceiling, as
applicable, by the Indian Company concerned by passing a resolution by its Board of
Directors followed by passing of a special resolution to that effect by its General Body.
The aggregate FII investment, in the FDI and Portfolio Investment Scheme, should be
within the above caps.
(ii) The Indian company which has issued shares to FIIs under the FDI Policy for which the
payment has been received directly into company’s account should report these figures
separately under item no. 5 of Form FC-GPR (Annex-1-A) (Post-issue pattern of
shareholding) so that the details could be suitably reconciled for statistical/monitoring
purposes.

14

<!-- page 16 -->

(iii) A daily statement in respect of all transactions (except derivative trade) have to be
submitted by the custodian bank in floppy / soft copy in the prescribed format directly to
RBI to monitor the overall ceiling/sectoral cap/statutory ceiling.
3.1.5

No person other than registered FII/NRI as per Schedules II and III of Foreign Exchange

Management (Transfer or Issue of Security by a Person Resident Outside India) Regulations of
FEMA 1999, can invest/trade in capital of Indian Companies in the Indian Stock Exchanges
directly i.e. through brokers like a Person Resident in India.
3.1.6

A SEBI registered Foreign Venture Capital Investor (FVCI) may contribute up to 100%

of the capital of an Indian Venture Capital Undertaking (IVCU) and may also set up a domestic
asset management company to manage the fund. All such investments can be made under the
automatic route in terms of Schedule 6 to Notification No. FEMA 20. A SEBI registered FVCI
can also invest in a domestic venture capital fund registered under the SEBI (Venture Capital
Fund) Regulations, 1996.

Such investments would also be subject to the extant FEMA

regulations and extant FDI policy including sectoral caps, etc. SEBI registered FVCIs are also
allowed to invest under the FDI Scheme, as non-resident entities, in other companies, subject to
FDI Policy and FEMA regulations.
3.2

TYPES OF INSTRUMENTS.

3.2.1

Indian companies can issue equity shares, fully, compulsorily and mandatorily

convertible debentures and fully, compulsorily and mandatorily convertible preference shares
subject to pricing guidelines/valuation norms prescribed under FEMA Regulations. The price/
conversion formula of convertible capital instruments should be determined upfront at the time
of issue of the instruments. The price at the time of conversion should not in any case be lower
than the fair value worked out, at the time of issuance of such instruments, in accordance with
the extant FEMA regulations [the DCF method of valuation for the unlisted companies and
valuation in terms of SEBI (ICDR) Regulations, for the listed companies].
3.2.2 Other types of Preference shares/Debentures i.e. non-convertible, optionally convertible or
partially convertible for issue of which funds have been received on or after May 1, 2007 are
considered as debt. Accordingly all norms applicable for ECBs relating to eligible borrowers,

15

<!-- page 17 -->

recognized lenders, amount and maturity, end-use stipulations, etc. shall apply. Since these
instruments would be denominated in rupees, the rupee interest rate will be based on the swap
equivalent of London Interbank Offered Rate (LIBOR) plus the spread as permissible for ECBs
of corresponding maturity.
3.2.3 The inward remittance received by the Indian company vide issuance of DRs and FCCBs
are treated as FDI and counted towards FDI.
3.2.4

Issue of shares by Indian Companies under FCCB/ADR/GDR

(i) Indian companies can raise foreign currency resources abroad through the issue of
FCCB/DR (ADRs/GDRs), in accordance with the Scheme for issue of Foreign Currency
Convertible Bonds and Ordinary Shares (Through Depository Receipt Mechanism)
Scheme, 1993 and guidelines issued by the Government of India there under from time to
time.
(ii) A company can issue ADRs / GDRs if it is eligible to issue shares to persons resident
outside India under the FDI Policy. However, an Indian listed company, which is not
eligible to raise funds from the Indian Capital Market including a company which has
been restrained from accessing the securities market by the Securities and Exchange
Board of India (SEBI) will not be eligible to issue ADRs/GDRs.
(iii) Unlisted companies, which have not yet accessed the ADR/GDR route for raising capital
in the international market, would require prior or simultaneous listing in the domestic
market, while seeking to issue such overseas instruments. Unlisted companies, which
have already issued ADRs/GDRs in the international market, have to list in the domestic
market on making profit or within three years of such issue of ADRs/GDRs, whichever is
earlier. ADRs / GDRs are issued on the basis of the ratio worked out by the Indian
company in consultation with the Lead Manager to the issue. The proceeds so raised have
to be kept abroad till actually required in India. Pending repatriation or utilization of the
proceeds, the Indian company can invest the funds in:(a) Deposits, Certificate of Deposits or other instruments offered by banks rated by
Standard and Poor, Fitch, IBCA ,Moody's, etc. with rating not below the rating
stipulated by Reserve Bank from time to time for the purpose;
(b) Deposits with branch/es of Indian Authorized Dealers outside India; and

16

<!-- page 18 -->

(c) Treasury bills and other monetary instruments with a maturity or unexpired maturity
of one year or less.
(iv) There are no end-use restrictions except for a ban on deployment / investment of such
funds in real estate or the stock market. There is no monetary limit up to which an Indian
company can raise ADRs / GDRs.
(v) The ADR / GDR proceeds can be utilized for first stage acquisition of shares in the
disinvestment process of Public Sector Undertakings / Enterprises and also in the
mandatory second stage offer to the public in view of their strategic importance.
(vi) Voting rights on shares issued under the Scheme shall be as per the provisions of
Companies Act, 1956 and in a manner in which restrictions on voting rights imposed on
ADR/GDR issues shall be consistent with the Company Law provisions. Voting rights in
the case of banking companies will continue to be in terms of the provisions of the
Banking Regulation Act, 1949 and the instructions issued by the Reserve Bank from time
to time, as applicable to all shareholders exercising voting rights.
(vii) Erstwhile OCBs who are not eligible to invest in India and entities prohibited from
buying, selling or dealing in securities by SEBI will not be eligible to subscribe to ADRs/
GDRs issued by Indian companies.
(viii)The pricing of ADR / GDR issues should be made at a price determined under the
provisions of the Scheme of issue of Foreign Currency Convertible Bonds and Ordinary
Shares (through Depository Receipt Mechanism) Scheme, 1993 and guidelines issued by
the Government of India and directions issued by the Reserve Bank, from time to time.
(ix) The pricing of sponsored ADRs/GDRs would be determined under the provisions of the
Scheme of issue of Foreign Currency Convertible Bonds and Ordinary Shares (Through
Depository Receipt Mechanism) Scheme, 1993 and guidelines issued by the Government
of India and directions issued by the Reserve Bank, from time to time.
3.2.5 (i)

Two-way Fungibility Scheme: A limited two-way Fungibility scheme has been put

in place by the Government of India for ADRs / GDRs. Under this Scheme, a stock broker in
India, registered with SEBI, can purchase shares of an Indian company from the market for
conversion into ADRs/GDRs based on instructions received from overseas investors.

Re-

17

<!-- page 19 -->

issuance of ADRs / GDRs would be permitted to the extent of ADRs / GDRs which have been
redeemed into underlying shares and sold in the Indian market.
(ii) Sponsored ADR/GDR issue: An Indian company can also sponsor an issue of ADR / GDR.
Under this mechanism, the company offers its resident shareholders a choice to submit their
shares back to the company so that on the basis of such shares, ADRs / GDRs can be issued
abroad. The proceeds of the ADR / GDR issue are remitted back to India and distributed among
the resident investors who had offered their Rupee denominated shares for conversion. These
proceeds can be kept in Resident Foreign Currency (Domestic) accounts in India by the resident
shareholders who have tendered such shares for conversion into ADRs / GDRs.
3.3 ENTITIES INTO WHICH FDI CAN BE MADE
3.3.1

FDI in an Indian Company

(i)

Indian companies including those which are micro and small enterprises (MSEs) can

issue capital against FDI.
3.3.2

FDI in Partnership Firm / Proprietary Concern:

(i) A Non-Resident Indian (NRI) or a Person of Indian Origin (PIO) resident outside India
can invest by way of contribution to the capital of a firm or a proprietary concern in India
on non-repatriation basis provided;
(a) Amount is invested by inward remittance or out of NRE/FCNR(B)/NRO account
maintained with Authorized Dealers / Authorized banks.
(b) The firm or proprietary concern is not engaged in any agricultural/plantation or real
estate business or print media sector.
(c) Amount invested shall not be eligible for repatriation outside India.
(ii) Investments with repatriation benefits: NRIs/PIO may seek prior permission of Reserve
Bank for investment in sole proprietorship concerns/partnership firms with repatriation
benefits. The application will be decided in consultation with the Government of India.
(iii)Investment by non-residents other than NRIs/PIO: A person resident outside India other
than NRIs/PIO may make an application and seek prior approval of Reserve Bank for
making investment by way of contribution to the capital of a firm or a proprietorship
concern or any association of persons in India. The application will be decided in
consultation with the Government of India.

18

<!-- page 20 -->

(iv)Restrictions: An NRI or PIO is not allowed to invest in a firm or proprietorship concern
engaged in any agricultural/plantation activity or real estate business (i.e. dealing in land
and immovable property with a view to earning profit or earning income there from) or
engaged in Print Media.
3.3.3

FDI in Venture Capital Fund (VCF):

FVCIs are allowed to invest in Indian

Venture Capital Undertakings (IVCUs) /Venture Capital Funds (VCFs) /other companies, as
stated in paragraph 3.1.6 of this Circular. If a domestic VCF is set up as a trust, a person resident
outside India (non-resident entity/individual including an NRI) cannot invest in such domestic
VCF under the automatic route of the FDI scheme and would be allowed subject to approval of
the FIPB. However, if a domestic VCF is set-up as an incorporated company under the
Companies Act, 1956, then a person resident outside India (non-resident entity/individual
including an NRI) can invest in such domestic VCF under the automatic route of FDI Scheme,
subject to the pricing guidelines, reporting requirements, mode of payment, minimum
capitalization norms, etc.
3.3.4

FDI in Trusts: FDI in Trusts other than VCF is not permitted.

3.3.5

FDI in other Entities 2: FDI in resident entities other than those mentioned above is not

permitted.
3.4

CONDITIONS ON ISSUE/TRANSFER OF SHARES

3.4.1 The capital instruments should be issued within 180 days from the date of receipt of the
inward remittance or by debit to the NRE/FCNR (B) account of the non-resident investor. In
case, the capital instruments are not issued within 180 days from the date of receipt of the inward
remittance or date of debit to the NRE/FCNR (B) account, the amount of consideration so
received should be refunded immediately to the non-resident investor by outward remittance
through normal banking channels or by credit to the NRE/FCNR (B) account, as the case may
be. Non-compliance with the above provision would be reckoned as a contravention under
FEMA and would attract penal provisions. In exceptional cases, refund of the amount of
2

Review of FDI policy to allow FDI in LLPs is under consideration of the Government.

19

<!-- page 21 -->

consideration outstanding beyond a period of 180 days from the date of receipt may be
considered by the RBI, on the merits of the case.
3.4.2 Issue price of shares – Price of shares issued to persons resident outside India under the
FDI Policy, shall not be less than a. the price worked out in accordance with the SEBI guidelines, as applicable, where the
shares of the company is listed on any recognised stock exchange in India;
b. the fair valuation of shares done by a SEBI registered Category - I Merchant Banker or a
Chartered Accountant as per the discounted free cash flow method, where the shares of
the company is not listed on any recognised stock exchange in India ; and
c. the price as applicable to transfer of shares from resident to non-resident as per the
pricing guidelines laid down by the Reserve Bank from time to time, where the issue of
shares is on preferential allotment.
3.4.3 Foreign Currency Account – Indian companies which are eligible to issue shares to
persons resident outside India under the FDI Policy may be allowed to retain the share
subscription amount in a Foreign Currency Account, with the prior approval of RBI.
3.4.4 Transfer of shares and convertible debentures –
(i) Subject to FDI sectoral policy, non-resident investors can also invest in Indian companies
by purchasing/acquiring existing shares from Indian shareholders or from other nonresident shareholders. General permission has been granted to non-residents/NRIs for
acquisition of shares by way of transfer subject to the following:
(a) A person resident outside India (other than NRI and erstwhile OCB) may transfer by
way of sale or gift, the shares or convertible debentures to any person resident outside
India (including NRIs).
(b) NRIs may transfer by way of sale or gift the shares or convertible debentures held by
them to another NRI.
(c) A person resident outside India can transfer any security to a person resident in India
by way of gift.

20

<!-- page 22 -->

(d) A person resident outside India can sell the shares and convertible debentures of an
Indian company on a recognized Stock Exchange in India through a stock broker
registered with stock exchange or a merchant banker registered with SEBI.
(e) A person resident in India can transfer by way of sale, shares/convertible debentures
(including transfer of subscriber’s shares), of an Indian company in sectors other than
financial services sectors (i.e. Banks, NBFC, Insurance, Asset Reconstruction
Companies (ARCs), Credit Information Companies (CICs), infrastructure companies
in the securities market viz. Stock Exchanges, Clearing Corporations, and
Depositories, Commodity Exchanges, etc.) under private arrangement to a person
resident outside India, subject to the guidelines given in Annex-2.
(f) General permission is also available for transfer of shares/convertible debentures, by
way of sale under private arrangement by a person resident outside India to a person
resident in India, subject to the guidelines given in Annex-2.
(g) The above General Permission also covers transfer by a resident to a non-resident of
shares/convertible debentures of an Indian company, engaged in an activity earlier
covered under the Government Route but now falling under Automatic Route, as well
as transfer of shares by a non-resident to an Indian company under buyback and/or
capital reduction scheme of the company. However, this General Permission is not
available in case of transfer of shares / debentures, from a Resident to a NonResident/Non-Resident Indian, of an entity engaged in any activity in the financial
services sector (i.e. Banks, NBFCs, Asset Reconstruction Companies (ARCs), Credit
Information Companies (CICs), Insurance, infrastructure companies in the securities
market such as Stock Exchanges, Clearing Corporations, and Depositories,
Commodity Exchanges, etc.).
(h) The Form FC-TRS should be submitted to the AD Category-I Bank, within 60 days
from the date of receipt of the amount of consideration. The onus of submission of
the Form FC-TRS within the given timeframe would be on the transferor/transferee,
resident in India.
(ii) The sale consideration in respect of equity instruments purchased by a person resident
outside India, remitted into India through normal banking channels, shall be subjected to
a Know Your Customer (KYC) check by the remittance receiving AD Category – I bank

21

<!-- page 23 -->

at the time of receipt of funds. In case, the remittance receiving AD Category – I bank is
different from the AD Category – I bank handling the transfer transaction, the KYC
check should be carried out by the remittance receiving bank and the KYC report be
submitted by the customer to the AD Category – I bank carrying out the transaction along
with the Form FC-TRS.
(iii) Escrow: AD Category – I banks have been given general permission to open Escrow
account and Special account of non-resident corporate for open offers / exit offers and
delisting of shares. The relevant SEBI (SAST) Regulations or any other applicable SEBI
Regulations/ provisions of the Companies Act, 1956 will be applicable.
3.4.5

Prior permission of RBI in certain cases for transfer of capital instruments –

(i) The following instances of transfer of capital instruments from resident to non-residents
by way of sale require prior approval of RBI:
(a) Transfer of capital instruments of an Indian company engaged in financial services
sector (i.e. Banks, NBFCs, Asset Reconstruction Companies (ARCs), Credit
Information Companies (CICs), Insurance companies, infrastructure companies in
the securities market such as Stock Exchanges, Clearing Corporations, and
Depositories, Commodity Exchanges, etc.).
(b) Transactions which attract the provisions of SEBI (Substantial Acquisition of Shares
& Takeovers) Regulations, 1997.
(c) The activity of the Indian company whose capital instruments are being transferred
falls outside the automatic route and the approval of the Government has been
obtained for the said transfer.
(d) The transfer is to take place at a price which falls outside the pricing guidelines
specified by the Reserve Bank from time to time.
(e) Transfer of capital instruments where the non-resident acquirer proposes deferment of
payment of the amount of consideration, prior approval of the Reserve Bank would be
required, as hitherto. Further, in case approval is granted for a transaction, the same
should be reported in Form FC-TRS, to an AD Category – I bank for necessary due
diligence , within 60 days from the date of receipt of the full and final amount of
consideration.

22

<!-- page 24 -->

(ii) The transfer of capital instruments of companies engaged in sectors falling under the
Government Route from residents to non-residents by way of sale or otherwise requires
Government approval followed by permission from RBI.
(iii) A person resident in India, who intends to transfer any capital instrument, by way of gift
to a person resident outside India, has to obtain prior approval from Reserve Bank. While
forwarding applications to Reserve Bank for approval for transfer of capital instruments
by way of gift, the documents mentioned in Annex-3 should be enclosed. Reserve Bank
considers the following factors while processing such applications:
(a) The proposed transferee (donee) is eligible to hold such capital instruments under
Schedules 1, 4 and 5 of Notification No. FEMA 20/2000-RB dated May 3, 2000, as
amended from time to time.
(b) The gift does not exceed 5 per cent of the paid-up capital of the Indian company/each
series of debentures/each mutual fund scheme.
(c) The applicable sectoral cap limit in the Indian company is not breached.
(d) The transferor (donor) and the proposed transferee (donee) are close relatives as
defined in Section 6 of the Companies Act, 1956, as amended from time to time. The
current list is reproduced in Annex-4.
(e) The value of capital instruments to be transferred together with any capital
instruments already transferred by the transferor, as gift, to any person residing
outside India does not exceed the rupee equivalent of USD 25,000 during the calendar
year.
(f) Such other conditions as stipulated by Reserve Bank in public interest from time to
time.
3.4.6

Conversion of ECB/Lumpsum Fee/Royalty into Equity

(i) Indian companies have been granted general permission for conversion of External
Commercial Borrowings (ECB) (excluding those deemed as ECB) in convertible foreign
currency into equity shares/fully compulsorily and mandatorily convertible preference
shares, subject to the following conditions and reporting requirements.
(a) The activity of the company is covered under the Automatic Route for FDI or the
company has obtained Government approval for foreign equity in the company;

23

<!-- page 25 -->

(b) The foreign equity after conversion of ECB into equity is within the sectoral cap, if
any;
(c) Pricing of shares is as per the provision of para 3.4.2 above;
(d) Compliance with the requirements prescribed under any other statute and regulation
in force; and
(e) The conversion facility is available for ECBs availed under the Automatic or
Government Route and is applicable to ECBs, due for payment or not, as well as
secured/unsecured loans availed from non-resident collaborators.
(ii) General permission is also available for issue of shares/preference shares against lump
sum technical know-how fee, royalty, subject to entry route, sectoral cap and pricing
guidelines (as per the provision of para 3.4.2 above) and compliance with applicable tax
laws.
(iii) Issue of equity shares under the FDI policy is allowed under the Government route for
the following categories:
(I)

import of capital goods/ machinery/ equipment (including second-hand
subject to compliance with the following conditions:

machinery),

(a) Any import of capital goods/machinery etc., made by a resident in India, has to be
in accordance with the Export/ Import Policy issued by Government of India/as
defined by DGFT/FEMA provisions relating to imports.
(b) There is an independent valuation of the capital goods/machinery/equipments
(including second-hand machinery) by a third party entity, preferably by an
independent valuer from the country of import alongwith production of copies of
documents/certificates issued by the customs authorities towards assessment of the
fair-value of such imports.
(c) The application clearly indicating the beneficial ownership and identity of the
Importer Company as well as overseas entity.
(d) All such conversions of import payables for capital goods into FDI being done
within 180 days from the date of shipment of goods.
(II)

pre-operative/ pre-incorporation expenses (including payments of rent etc.), subject to
compliance with the following conditions:
(a) Submission of FIRC for remittance of funds by the overseas
promoters for the
expenditure incurred.
(b) Verification and certification of the pre-incorporation/pre-operative expenses by
the statutory auditor.

24

<!-- page 26 -->

(c) Payments being made directly by the foreign investor to the company. Payments
made through third parties citing the absence of a bank account or similar such
reasons will not be allowed.
(d) The capitalization being done within the stipulated period of 180 days permitted for
retention of advance against equity under the extant FDI policy.
General conditions:
(i)
(ii)

All requests for conversion should be accompanied by a special resolution of the
company.
Government’s approval would be subject to pricing guidelines of RBI and
appropriate tax clearance.

3.5 ISSUE OF INSTRUMENTS
3.5.1

Issue of Rights/Bonus Shares – FEMA provisions allow Indian companies to freely

issue Rights/Bonus shares to existing non-resident shareholders, subject to adherence to sectoral
cap, if any. However, such issue of bonus / rights shares has to be in accordance with other
laws/statutes like the Companies Act, 1956, SEBI (Issue of Capital and Disclosure
Requirements) Regulations, 2009 (in case of listed companies), etc. The offer on right basis to
the persons resident outside India shall be:
(a) in the case of shares of a company listed on a recognized stock exchange in India, at a price
as determined by the company;
(b) in the case of shares of a company not listed on a recognized stock exchange in India, at a
price which is not less than the price at which the offer on right basis is made to resident
shareholders.

3.5.2

Prior permission of RBI for Rights issue to erstwhile OCBs- OCBs have been de-

recognised as a class of investors from September 16, 2003. Therefore companies desiring to
issue rights share to such erstwhile OCBs will have to take specific prior permission from RBI.
As such, entitlement of rights share is not automatically available to erstwhile OCBs. However
bonus shares can be issued to erstwhile OCBs without the approval of RBI.

25

<!-- page 27 -->

3.5.3

Additional allocation of rights share by residents to non-residents – Existing non-

resident shareholders are allowed to apply for issue of additional shares/ fully, compulsorily and
mandatorily convertible debentures/ fully, compulsorily and mandatorily convertible preference
shares over and above their rights share entitlements. The investee company can allot the
additional rights share out of unsubscribed portion, subject to the condition that the overall issue
of shares to non-residents in the total paid-up capital of the company does not exceed the
sectoral cap.
3.5.4

Acquisition of shares under Scheme of Merger/Demerger/Amalgamation –

Mergers/demergers/ amalgamations of companies in India are usually governed by an order
issued by a competent Court on the basis of the Scheme submitted by the companies undergoing
merger/demerger/amalgamation. Once the scheme of merger or demerger or amalgamation of
two or more Indian companies has been approved by a Court in India, the transferee company or
new company is allowed to issue shares to the shareholders of the transferor company resident
outside India, subject to the conditions that:
(i) the percentage of shareholding of persons resident outside India in the transferee or new
company does not exceed the sectoral cap, and
(ii) the transferor company or the transferee or the new company is not engaged in activities
which are prohibited under the FDI policy .
3.5.5

Issue of shares under Employees Stock Option Scheme (ESOPs) –

(i) Listed Indian companies are allowed to issue shares under the Employees Stock Option
Scheme (ESOPs), to its employees or employees of its joint venture or wholly owned
subsidiary abroad who are resident outside India, other than to the citizens of Pakistan.
ESOPs can be issued to citizens of Bangladesh with the prior approval of FIPB. Shares
under ESOPs can be issued directly or through a Trust subject to the condition that:
(a) The scheme has been drawn in terms of relevant regulations issued by the SEBI, and
(b) The face value of the shares to be allotted under the scheme to the non-resident
employees does not exceed 5 per cent of the paid-up capital of the issuing company.
(ii) Unlisted companies have to follow the provisions of the Companies Act, 1956. The
Indian company can issue ESOPs to employees who are resident outside India, other than
to the citizens of Pakistan. ESOPs can be issued to the citizens of Bangladesh with the
prior approval of the FIPB.

26

<!-- page 28 -->

(iii)The issuing company is required to report (plain paper reporting) the details of granting
of stock options under the scheme to non-resident employees to the Regional Office
concerned of the Reserve Bank and thereafter the details of issue of shares subsequent to
the exercise of such stock options within 30 days from the date of issue of shares in Form
FC-GPR.
3.5.6

Share Swap: In cases of investment by way of swap of shares, irrespective of the

amount, valuation of the shares will have to be made by a Category I Merchant Banker registered
with SEBI or an Investment Banker outside India registered with the appropriate regulatory
authority in the host country. Approval of the Foreign Investment Promotion Board (FIPB) will
also be a prerequisite for investment by swap of shares.

27

<!-- page 29 -->

CHAPTER 4: CALCULATION, ENTRY ROUTE, CAPS, ENTRY
CONDITIONS, ETC. OF INVESTMENT
4.1 CALCULATION OF TOTAL FOREIGN INVESTMENT I.E. DIRECT

AND

INDIRECT FOREIGN INVESTMENT IN INDIAN COMPANIES.
4.1.1

Investment in Indian companies can be made both by non-resident as well as resident

Indian entities. Any non-resident investment in an Indian company is direct foreign investment.
Investment by resident Indian entities could again comprise of both resident and non-resident
investment. Thus, such an Indian company would have indirect foreign investment if the Indian
investing company has foreign investment in it. The indirect investment can also be a cascading
investment i.e. through multi-layered structure.
4.1.2

For the purpose of computation of indirect Foreign investment, Foreign Investment in

Indian company shall include all types of foreign investments i.e. FDI; investment by
FIIs(holding as on March 31); NRIs; ADRs; GDRs; Foreign Currency Convertible Bonds
(FCCB);

fully,

compulsorily

and

mandatorily

convertible

preference

shares

and

fully,compulsorily and mandatorily convertible Debentures regardless of whether the said
investments have been made under Schedule 1, 2, 3 and 6 of FEM (Transfer or Issue of Security
by Persons Resident Outside India) Regulations, 2000.
4.1.3

Guidelines for calculation of total foreign investment i.e. direct and indirect foreign

investment in an Indian company.
(i) Counting the Direct Foreign Investment: All investment directly by a non-resident
entity into the Indian company would be counted towards foreign investment.
(ii) Counting of indirect foreign Investment:
(a) The foreign investment through the investing Indian company would not be
considered for calculation of the indirect foreign investment in case of Indian
companies which are ‘owned and controlled’ by resident Indian citizens and/or
Indian Companies which are owned and controlled by resident Indian citizens .

28

<!-- page 30 -->

(b) For cases where condition (a) above is not satisfied or if the investing company is
owned or controlled by ‘non resident entities’, the entire investment by the investing
company into the subject Indian Company would be considered as indirect foreign
investment,
Provided that, as an exception, the indirect foreign investment in only the 100% owned
subsidiaries of operating-cum-investing/investing companies, will be limited to the
foreign investment in the operating-cum-investing/ investing company. This exception is
made since the downstream investment of a 100% owned subsidiary of the holding
company is akin to investment made by the holding company and the downstream
investment should be a mirror image of the holding company. This exception, however,
is strictly for those cases where the entire capital of the downstream subsidy is owned by
the holding company.
Illustration
To illustrate, if the indirect foreign investment is being calculated for Company X which
has investment through an investing Company Y having foreign investment, the
following would be the method of calculation:
(A) where Company Y has foreign investment less than 50%- Company X would not be
taken as having any indirect foreign investment through Company Y.
(B) where Company Y has foreign investment of say 75% and:
(I) invests 26% in Company X, the entire 26% investment by Company Y would be
treated as indirect foreign investment in Company X;
(II) Invests 80% in Company X, the indirect foreign investment in Company X would
be taken as 80%
(III) where Company X is a wholly owned subsidiary of Company Y (i.e. Company Y
owns 100% shares of Company X), then only 75% would be treated as indirect
foreign equity and the balance 25% would be treated as resident held equity. The
indirect foreign equity in Company X would be computed in the ratio of 75: 25 in
the total investment of Company Y in Company X.
(iii)The total foreign investment would be the sum total of direct and indirect foreign
investment.

29

<!-- page 31 -->

(iv) The above methodology of calculation would apply at every stage of investment in
Indian

Companies and thus to each and every Indian Company.

(v) Additional conditions:
(a) The full details about the foreign investment including ownership details etc. in Indian
company(s) and information about the control of the company(s) would be furnished by
the Company(s) to the Government of India at the time of seeking approval.
(b) In any sector/activity, where Government approval is required for foreign investment and
in cases where there are any inter-se agreements between/amongst share-holders which
have an effect on the appointment of the Board of Directors or on the exercise of voting
rights or of creating voting rights disproportionate to shareholding or any incidental
matter thereof, such agreements will have to be informed to the approving authority. The
approving authority will consider such inter-se agreements for determining ownership
and control when considering the case for granting approval for foreign investment.
(c) In all sectors attracting sectoral caps, the balance equity i.e. beyond the sectoral foreign
investment cap, would specifically be beneficially owned by/held with/in the hands of
resident Indian citizens and Indian companies, owned and controlled by resident Indian
citizens.
(d) In the I& B and Defence sectors where the sectoral cap is less than 49%, the company
would need to be ‘owned and controlled’ by resident Indian citizens and Indian
companies, which are owned and controlled by resident Indian citizens.
(A) For this purpose, the equity held by the largest Indian shareholder would have to be
at least 51% of the total equity, excluding the equity held by Public Sector Banks and
Public Financial Institutions, as defined in Section 4A of the Companies Act, 1956.
The term ‘largest Indian shareholder’, used in this clause, will include any or a
combination of the following:
(I) In the case of an individual shareholder,
(aa) The individual shareholder,
(bb) A relative of the shareholder within the meaning of Section 6 of the
Companies Act, 1956.
(cc) A company/ group of companies in which the individual shareholder/HUF to
which he belongs has management and controlling interest.

30

<!-- page 32 -->

(II) In the case of an Indian company,
(aa) The Indian company
(bb) A group of Indian companies under the same management and ownership
control.
(B) For the purpose of this Clause, “Indian company” shall be a company which must
have a resident Indian or a relative as defined under Section 6 of the Companies Act,
1956/ HUF, either singly or in combination holding at least 51% of the shares.
(C) Provided that, in case of a combination of all or any of the entities mentioned in SubClauses (i) and (ii) of clause 4.1.3(v)(d)(1) above, each of the parties shall have
entered into a legally binding agreement to act as a single unit in managing the
matters of the applicant company.
(e) If a declaration is made by persons as per section 187C of the Indian Companies Act
about a beneficial interest being held by a non resident entity, then even though the
investment may be made by a resident Indian citizen, the same shall be counted as
foreign investment.
4.1.4 The above mentioned policy and the methodology would be applicable for determining the
total foreign investment in all sectors, excepting in sectors where it is governed specifically
under any statutes or rules there under. The above methodology of determining direct and
indirect foreign investment therefore does not apply to the Insurance Sector which will continue
to be governed by the relevant Regulation.
4.1.5 Any foreign investment already made in accordance with the guidelines in existence prior
to February 13, 2009 (date of issue of Press Note 2 of 2009) would not require any modification
to conform to these guidelines. All other investments, past and future, would come under the
ambit of these new guidelines.
4.2

ENTRY ROUTES FOR INVESTMENT:

4.2.1

Investments can be made by non-residents in the equity shares/fully, compulsorily and

mandatorily convertible debentures/ fully, compulsorily and mandatorily convertible preference
shares of an Indian company, through two routes; the Automatic Route and the Government

31

<!-- page 33 -->

Route. Under the Automatic Route, the non-resident investor or the Indian company does not
require any approval from the RBI or Government of India for the investment. Under the
Government Route, prior approval of the Government of India through Foreign Investment
Promotion Board (FIPB) is required. Proposals for foreign investment under Government route
as laid down in the FDI policy from time to time, are considered by the Foreign Investment
Promotion Board (FIPB) in Department of Economic Affairs (DEA), Ministry of Finance.

4.2.2

Guidelines for establishment of Indian companies/ transfer of ownership or control

of Indian companies, from resident Indian citizens to non-resident entities, in sectors with
caps:
In sectors/activities with caps, including inter-alia defence production, air transport services,
ground handling services, asset reconstruction companies, private sector banking, broadcasting,
commodity

exchanges,

credit

information

companies,

insurance,

print

media,

telecommunications and satellites, Government approval/FIPB approval would be required in all
cases where:
(i) An Indian company is being established with foreign investment and is owned by a nonresident entity or
(ii) An Indian company is being established with foreign investment and is controlled by a nonresident entity or
(iii) The control of an existing Indian company, currently owned or controlled by resident Indian
citizens and Indian companies, which are owned or controlled by resident Indian citizens, will
be/is being transferred/passed on to a non-resident entity as a consequence of transfer of shares
and/or fresh issue of shares to non-resident entities through amalgamation, merger/demerger,
acquisition etc. or
(iv) The ownership of an existing Indian company, currently owned or controlled by resident
Indian citizens and Indian companies, which are owned or controlled by resident Indian citizens,
will be/is being transferred/passed on to a non-resident entity as a consequence of transfer of
shares and/or fresh issue of shares to non-resident entities through amalgamation,
merger/demerger, acquisition etc.
(v) It is clarified that these guidelines will not apply for sectors/activities where there are no
foreign investment caps, that is, 100% foreign investment is permitted under the automatic route.
32

<!-- page 34 -->

(vi) It is also clarified that Foreign investment shall include all types of foreign investments i.e.
FDI, investment by FIIs, NRIs, ADRs, GDRs, Foreign Currency Convertible Bonds (FCCB) and
fully, mandatorily & compulsorily convertible preference shares/debentures, regardless of
whether the said investments have been made under Schedule 1, 2, 3 and 6 of FEMA (Transfer
or Issue of Security by Persons Resident Outside India) Regulations.
4.3 CAPS ON INVESTMENTS
4.3.1

Investments can be made by non-residents in the capital of a resident entity only to the

extent of the percentage of the total capital as provided/permitted in the FDI policy. Thus while
investment are prohibited in some sectors/activities, there are restrictions/conditions/caps on the
investment in certain other sector/activities. The caps in various sector(s)/activity are detailed out
in Chapter 5 of this circular.
4.4 ENTRY CONDITIONS ON INVESTMENT
4.4.1

Investments can be permitted to be made by non-residents in the capital of a resident

entity in certain sectors/activity with entry conditions. These entry conditions would be
applicable for investment only by non-resident entities. Such conditions may include norms for
minimum capitalization, lock-in period, etc. The entry conditions in various sectors/activities are
detailed in Chapter 5 of this circular.
4.5

OTHER CONDITIONS ON INVESTMENT BESIDES ENTRY CONDITIONS

4.5.1

Besides the entry conditions on foreign investment, the investment/investors need to

conform to all relevant sectoral laws, regulations, rules etc.
4.5.2

The national security/internal security related conditions as contained in relevant statutes

or notifications of the Government will also have to be complied with.
4.5.3

The State Governments/Union Territories have regulations in relation to the subjects in

their legislative domain. These regulations also have to be met/complied with.

33

<!-- page 35 -->

4.6

FOREIGN INVESTMENT INTO/ DOWNSTREAM INVESTMENT BY INDIAN

COMPANIES
4.6.1 The Guidelines for calculation of total foreign investment, both direct and indirect in an
Indian company, at every stage of investment, including downstream investment, have been
detailed in Paragraph 4.1, which enables determination of total foreign investment in any/all
Indian Companies.
4.6.2 For the purpose of this chapter,
(i) ‘Downstream investment’ means indirect foreign investment, by one Indian company,
into another Indian company, by way of subscription or acquisition, in terms of
Paragraph 4.1. Paragraph 4.1.3 provides the guidelines for calculation of indirect foreign
investment, with conditions specified in paragraph 4.1.3 (v).
(ii) ‘Foreign Investment’ would have the same meaning as in Paragraph 4.1
4.6.3

Foreign investment into an Indian company engaged only in the activity of investing
in the capital of other Indian company/ies (regardless of its ownership or control):

4.6.3.1 Foreign investment into an Indian company, engaged only in the activity of investing in
the capital of other Indian company/ies, will require prior Government/FIPB approval, regardless
of the amount or extent of foreign investment. Foreign investment into Non-Banking Finance
Companies (NBFCs), carrying on activities approved for FDI, will be subject to the conditions
specified in paragraph 5.2.18 of this Circular. Those companies, which are Core Investment
Companies (CICs), will have to additionally follow RBI’s Regulatory Framework for CICs.
4.6.3.2 For infusion of foreign investment into an Indian company which does not have any
operations and also does not have any downstream investments, Government/FIPB approval
would be required, regardless of the amount or extent of foreign investment. Further, as and
when such a company commences business(s) or makes downstream investment, it will have to
comply with the relevant sectoral conditions on entry route, conditionalities and caps.

34

<!-- page 36 -->

Note: Foreign investment into other Indian companies would be in accordance/ compliance with
the relevant sectoral conditions on entry route, conditionalities and caps, with regard to the
sectors in which such companies are operating.
4.6.4

Downstream investment by an Indian company which is owned and/or controlled by
non resident entity/ies:

4.6.4.1 Downstream investment by an Indian company, which is owned and/ or controlled by
non-resident entity/ies, into another Indian company, would be in accordance/compliance with the
relevant sectoral conditions on entry route, conditionalities and caps, with regard to the sectors in
which the Indian company into which the downstream investment is being made, is operating.
4.6.4.2 Downstream investments by Indian companies will be subject to the following
conditions:
(i) Such a company is to notify SIA, DIPP and FIPB of its downstream investment in the form
available at

http://www.fipbindia.com within 30 days of such investment, even if capital

instruments have not been allotted along with the modality of investment in new/existing ventures
(with/without expansion programme);
(ii) downstream investment by way of induction of foreign equity in an existing Indian Company
to be duly supported by a resolution of the Board of Directors supporting the said induction as
also a shareholders Agreement, if any;
(iii) issue/transfer/pricing/valuation of shares shall be in accordance with applicable SEBI/RBI
guidelines;
(iv) For the purpose of downstream investment, the Indian companies making the downstream
investments would have to bring in requisite funds from abroad and not leverage funds from
domestic market for such investments. This would, however, not preclude downstream
companies, with operations, from raising debt in the domestic market. Downstream investments
through internal accruals are permissible, subject to the provisions of paragraphs 4.6.3 and 4.6.4.1.

35

<!-- page 37 -->

4.7

GUIDELINES FOR CONSIDERATION OF FDI PROPOSALS BY FIPB:

4.7.1

The following guidelines are laid down to enable the FIPB to consider the proposals for

FDI and formulate its recommendations.
4.7.2

All applications should be put up before the FIPB by its Secretariat within 15 days and it

should be ensured that comments of the administrative ministries are placed before the Board
either prior to/or in the meeting of the Board.
4.7.3 Proposals should be considered by the Board keeping in view the time frame of thirty
(30) days for communicating Government decision.
4.7.4

In cases in which either the proposal is not cleared or further information is required in

order to obviate delays presentation by applicant in the meeting of the FIPB should be resorted
to.
4.7.5

While considering cases and making recommendations, FIPB should keep in mind the

sectoral requirements and the sectoral policies vis-à-vis the proposal (s).
4.7.6

FIPB would consider each proposal in its totality.

4.7.7

The Board should examine the following while considering proposals submitted to it for

consideration:
(i) whether the items of activity involve industrial licence or not and if so the considerations
for grant of industrial licence must be gone into;
(ii) whether the proposal involves any export projection and if so the items of export and the
projected destinations;
(iii)Whether the proposal has any strategic or defence related considerations.
4.7.8

While considering proposals the following may be prioritized:

(i) Items falling in infrastructure sector;
(ii) Items which have an export potential;
(iii)Items which have large scale employment potential and especially for rural people;
(iv)Items which have a direct or backward linkage with agro business/farm sector;
(v) Items which have greater social relevance such as hospitals, human resource
development, life saving drugs and equipment;
(vi)Proposals which result in induction of technology or infusion of capital.

36

<!-- page 38 -->

4.7.9 The following should be especially considered during the scrutiny and consideration of
proposals.
(i) The extent of foreign equity proposed to be held (keeping in view sectoral caps if any;
(ii) Extent of equity from the point of view whether the proposed project would amount to a
holding company/wholly owned subsidiary/a company with dominant foreign investment
(i.e. 76% or more) joint venture;
(iii)Whether the proposed foreign equity is for setting up a new project (joint venture or
otherwise) or whether it is for enlargement of foreign/NRI equity or whether it is for
fresh induction of foreign equity/NRI equity in an existing Indian company;
(iv)In the case of fresh induction offerings/NRI equity and/or in cases of enlargement of
foreign/NRI equity, in existing Indian companies whether there is a resolution of the
Board of Directors supporting the said induction/enlargement of foreign/NRI equity and
whether there is a shareholders agreement or not;
(v) In the case of induction of fresh equity in the existing Indian companies and/or
enlargement of foreign equity in existing Indian companies, the reason why the proposal
has been made and the modality for induction/enhancement (i.e. whether by increase of
paid up capital/authorized capital, transfer of shares (hostile or otherwise) whether by
rights issue, or by what modality;
(vi)Issue/transfer/pricing of shares will be as per SEBI/RBI guidelines;
(vii) Whether the activity is an industrial or a service activity or a combination of both;
(viii) Whether the items of activity involves any restriction by way of reservation for the
Micro & Small Enterprises sector;
(ix)Whether there are any sectoral restrictions on the activity;
(x) Whether the proposal involves import of items which are either hazardous/banned or
detrimental to environment (e.g. import of plastic scrap or recycled plastics).
4.7.10 No condition specific to the letter of approval issued to a non-resident investor would be
changed or additional condition imposed subsequent to the issue of a letter of approval. This
would not prohibit changes in general policies and, regulations applicable to the industrial sector.

37

<!-- page 39 -->

4.8

CONSTITUTION OF FIPB :

4.8.1 FIPB comprises of the following Core Group of Secretaries to the Government of
India:
(i) Secretary to Government, Department of Economic Affairs, Ministry of Finance
–
Chairperson
(ii) Secretary to Government, Department of Industrial Policy & Promotion, Ministry
of Commerce &
Industry
(iii)Secretary to Government, Department of Commerce, Ministry of Commerce &
Industry
(iv)Secretary to Government, Economic Relations, Ministry of External Affairs
(v) Secretary to Government, Ministry of Overseas Indian Affairs.
4.8.2

The Board would be able to co-opt other Secretaries to the Central Government

and top officials of financial institutions, banks and professional experts of Industry and
Commerce, as and when necessary.
4.9

APPROVAL LEVELS FOR CASES UNDER GOVERNMENT ROUTE

4.9.1

The following approval levels shall operate for proposals involving FDI under the

Government route i.e. requiring prior Government approval:
(i) The Minister of Finance who is in-charge of FIPB would consider the recommendations
of FIPB on proposals with total foreign equity inflow of and below Rs.1200 crore.
(ii) The recommendations of FIPB on proposals with total foreign equity inflow of more than
Rs. 1200 crore would be placed for consideration of CCEA. The FIPB Secretariat in DEA
will process the recommendations of FIPB to obtain the approval of Minister of Finance and
CCEA.
( iii)

The CCEA would also consider the proposals which may be referred to it by the

FIPB/ the Minister of Finance (in-charge of FIPB).

38

<!-- page 40 -->

4.10

CASES WHICH DO NOT REQUIRE FRESH APPROVAL

4.10.1 Companies may not require fresh prior approval of the Government i.e. Minister incharge of FIPB/CCEA for bringing in additional foreign investment into the same entity, in the
following cases:
(i)

Cases

of

FIPB/CCFI/CCEA

entities
and

whose

who

activities

had,

had

earlier

required

prior

approval

of

accordingly,

earlier

obtained

prior

approval

of

FIPB/CCFI/CCEA for their initial foreign investment but subsequently such activities/sectors
have been placed under automatic route;
(ii)

Cases of entities whose activities had sectoral caps earlier and who had, accordingly,

earlier obtained prior approval of FIPB/CCFI/CCEA for their initial foreign investment but
subsequently such caps were removed/increased and the activities placed under the automatic
route; provided that such additional investment alongwith the initial/original investment does not
exceed the sectoral caps; and
(iii)

The cases of additional foreign investment into the same entity where prior approval of

FIPB/CCFI/CCEA had been obtained earlier for the initial/original foreign investment due to
requirements of Press Note 18/1998 or Press Note 1 of 2005 and prior approval of the
Government under the FDI policy is not required for any other reason/purpose.
4.11

ONLINE

FILING

OF

APPLICATIONS

FOR

FIPB

/GOVERNMENT’S

APPROVAL
4.11.1 Guidelines for e-filing of applications, filing of amendment applications and instructions
to

applicants

are

available

at

FIPB’s

website

(http://finmin.nic.in/)

and

(http://www.fipbindia.com).

39

<!-- page 41 -->

CHAPTER 5:

POLICY ON ROUTE, CAPS AND ENTRY

CONDITIONS:
5.1

PROHIBITION ON INVESTMENT IN INDIA.

FDI is prohibited in the following activities/sectors:
(a) Retail Trading (except single brand product retailing)
(b) Lottery Business including Government /private lottery, online lotteries,etc.
(c) Gambling and Betting including casinos etc.
(d) Business of chit fund
(e) Nidhi company
(f) Trading in Transferable Development Rights (TDRs)
(g) Real Estate Business or Construction of Farm Houses
(h) Manufacturing of Cigars, cheroots, cigarillos and cigarettes, of tobacco or of tobacco
substitutes
(i) Activities / sectors not opened to private sector investment including Atomic Energy
and Railway Transport (other than Mass Rapid Transport Systems).
Besides foreign investment in any form, foreign technology collaboration in any form
including licensing for franchise, trademark, brand name, management contract is also
completely prohibited for Lottery Business and Gambling and Betting activities.

5.2

SECTOR-SPECIFIC POLICY FOR FDI

In the following sectors/activities, FDI up to the limit indicated against each sector/activity is
allowed/permitted subject to other conditions indicated & security conditions where applicable.
In sectors/activities not listed below, FDI is permitted upto 100% on the automatic route, subject
to applicable laws/sectoral rules/regulations/security conditions.
Sl.No.

I

Sector/Activity

%
of
Cap/Equity
I

AGRICULTURE
5.2.1
I Agriculture & Animal Husbandry I
I a) Floriculture, Horticulture, and I 100%

FDI Entry Route

I

I
I Automatic
40

<!-- page 42 -->

Sl.No.

Sector/Activity
Cultivation
Mushrooms
conditions;

of
Vegetables
&
under
controlled

%
of
Cap/Equity

FDI Entry Route

b) Development and production of
Seeds and planting material;
c) Animal Husbandry (including of
breeding of dogs), Pisciculture,
Aquaculture
under
controlled
conditions; and
d) services related to agro and allied
sectors

5.2.1.1

Note: Besides the above, FDI is not
allowed in any other agricultural
sector/activity
Other conditions:
For companies dealing with development of transgenic seeds/vegetables, the
following conditions apply:
(i)

When dealing with genetically modified seeds or planting material the

company shall comply with safety requirements in accordance with laws
enacted under the Environment (Protection) Act on the genetically modified
organisms.
(ii)

Any import of genetically modified materials if required shall be

subject to the conditions laid down vide Notifications issued under Foreign
Trade (Development and Regulation) Act, 1992.
(iii)

The company shall comply with any other Law, Regulation or Policy

governing genetically modified material in force from time to time.
(iv)

Undertaking of business activities involving the use of genetically

engineered cells and material shall be subject to the receipt of approvals from
Genetic Engineering Approval Committee (GEAC) and Review Committee
on Genetic Manipulation (RCGM).
(v)

Import of materials shall be in accordance with National Seeds Policy.

41

<!-- page 43 -->

Sl.No.

Sector/Activity
(vi)

%
of
FDI Entry Route
Cap/Equity
The term “under controlled conditions” covers the following:

• ‘Cultivation under controlled conditions’ for the categories of
Floriculture,

Horticulture,

Cultivation

of

vegetables

and

Mushrooms is the practice of cultivation wherein rainfall,
temperature, solar radiation, air humidity and culture medium are
controlled artificially. Control in these parameters may be effected
through protected cultivation under green houses, net houses, poly
houses or any other improved infrastructure facilities where microclimatic conditions are regulated anthropogenically.
• In case of Animal Husbandry, scope of the term ‘under controlled
conditions’ includes –
•

Rearing of animals under intensive farming systems
with stall-feeding.
require

Intensive farming system will

climate

systems

(ventilation,

temperature/humidity management), health care and
nutrition, herd registering/pedigree recording, use of
machinery, waste management systems.
•

Poultry breeding farms and hatcheries where microclimate is controlled through advanced technologies
like incubators, ventilation systems etc.

• In the case of pisciculture and aquaculture, ‘under controlled
conditions’ includes –
•

Aquariums

•

Hatcheries where eggs are artificially fertilized and fry
are hatched and incubated in an enclosed environment
with artificial climate control.

5.2.2
5.2.2.1

Tea Plantation
Tea sector including tea plantations

100%

Government

Note: Besides the above, FDI is not
allowed in any other plantation
42

<!-- page 44 -->

Sl.No.

Sector/Activity

5.2.2.2

sector/activity
Other conditions:
(i)

%
of
Cap/Equity

FDI Entry Route

Compulsory divestment of 26% equity of the company in favour of an

Indian partner/Indian public within a period of 5 years
(ii)

Prior approval of the State Government concerned in case of any

future land use change.

INDUSTRY
5.2.3
5.2.3.1

5.2.3.2

5.2.3.3

5.2.3.3.1

MINING

MINING
Mining and Exploration of metal and
non-metal ores including diamond,
gold, silver and precious ores but
excluding titanium bearing minerals
and its ores; subject to the Mines and
Minerals(
Development
&
Regulation) Act, 1957.
Coal and Lignite
(1) Coal & Lignite mining for captive
consumption by power projects, iron
& steel and cement units and other
eligible activities permitted under
and subject to the provisions of Coal
Mines (Nationalization) Act, 1973
(2) Setting up coal processing plants
like washeries subject to the
condition that the company shall not
do coal mining and shall not sell
washed coal or sized coal from its
coal processing plants in the open
market and shall supply the washed
or sized coal to those parties who are
supplying raw coal to coal processing
plants for washing or sizing.
Mining and mineral separation of
titanium bearing minerals and
ores, its value addition and
integrated activities
Mining and mineral separation of
titanium bearing minerals & ores, its
value addition and integrated
activities
subject
to
sectoral

100%

Automatic

100%

Automatic

100%

Automatic

100%

Government

43

<!-- page 45 -->

Sl.No.

Sector/Activity

5.2.3.3.2

regulations and the Mines
Minerals
(Development
Regulation Act 1957)
Other conditions:

and
and

%
of
Cap/Equity

FDI Entry Route

India has large reserves of beach sand minerals in the coastal stretches
around the country.

Titanium bearing minerals viz. Ilmenite, rutile and

leucoxene, and Zirconium bearing minerals including zircon are some of the
beach sand minerals which have been classified as “prescribed substances”
under the Atomic Energy Act, 1962.
Under the Industrial Policy Statement 1991, mining and production of
minerals classified as “prescribed substances” and specified in the Schedule to
the Atomic Energy (Control of Production and Use) Order, 1953 were
included in the list of industries reserved for the public sector. Vide
Resolution No. 8/1(1)/97-PSU/1422 dated 6th October 1998 issued by the
Department of Atomic Energy laying down the policy for exploitation of
beach sand minerals, private participation including Foreign Direct
Investment (FDI), was permitted in mining and production of Titanium ores
(Ilmenite, Rutile and Leucoxene) and Zirconium minerals (Zircon).
Vide Notification No. S.O.61(E) dated 18.1.2006, the Department of
Atomic Energy re-notified the list of “prescribed substances” under the
Atomic Energy Act 1962. Titanium bearing ores and concentrates (Ilmenite,
Rutile and Leucoxene) and Zirconium, its alloys and compounds and
minerals/concentrates including Zircon, were removed from the list of
“prescribed substances”.
(i) FDI for separation of titanium bearing minerals & ores will be subject to
the following additional conditions viz.:
(A) value addition facilities are set up within India along with transfer of
technology;
(B) disposal of tailings during the mineral separation shall be carried out

44

<!-- page 46 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
in accordance with regulations framed by the Atomic Energy Regulatory
Board such as Atomic Energy (Radiation Protection) Rules, 2004 and the
Atomic Energy (Safe Disposal of Radioactive Wastes) Rules, 1987.

(ii)

FDI will not be allowed in mining of “prescribed substances” listed in

the Notification No. S.O. 61(E) dated 18.1.2006 issued by the Department of
Atomic Energy.
Clarification: (1) For titanium bearing ores such as Ilmenite, Leucoxene and
Rutile, manufacture of titanium dioxide pigment and titanium sponge
constitutes value addition. Ilmenite can be processed to produce 'Synthetic
Rutile or Titanium Slag as an intermediate value added product.
(2) The objective is to ensure that the raw material available in the country is
utilized \ for setting up downstream industries and the technology available
internationally is available for setting up such industries within the country.
Thus, if with the technology transfer, the objective of the FDI Policy can be
achieved, the conditions prescribed at (i) (A) above shall be deemed to be
fulfilled.

MANUFACTURING
5.2.4
5.2.4.1

Manufacture of items reserved for
production in Micro and Small
Enterprises (MSEs)
FDI in MSEs will be subject to the sectoral caps, entry routes and other
relevant sectoral regulations.

Any industrial undertaking which is not a

Micro or Small Scale Enterprise, but manufactures items reserved for the
MSE sector would require Government route where foreign investment is
more than 24% in the capital. Such an undertaking would also require an
Industrial License under the Industries (Development & Regulation) Act
1951, for such manufacture. The issue of Industrial License is subject to a few
general conditions and the specific condition that the Industrial Undertaking
shall undertake to export a minimum of 50% of the new or additional annual
production of the MSE reserved items to be achieved within a maximum
period of three years. The export obligation would be applicable from the date
of commencement of commercial production and in accordance with the

45

<!-- page 47 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
provisions of section 11 of the Industries (Development & Regulation) Act
1951.

5.2.5

DEFENCE

5.2.5.1

Defence Industry subject to Industrial 26%
license
under
the
Industries
(Development & Regulation) Act
1951 3
Other conditions:

5.2.5.2

Government

(i) Licence applications will be considered and licences given by the
Department of Industrial Policy & Promotion, Ministry of Commerce
& Industry, in consultation with Ministry of Defence.
(ii) The applicant should be an Indian company / partnership firm.
(iii)The management of the applicant company / partnership should be in
Indian hands with majority representation on the Board as well as the
Chief Executives of the company / partnership firm being resident
Indians.
(iv) Full particulars of the Directors and the Chief Executives should be
furnished along with the applications.
(v) The Government reserves the right to verify the antecedents of the
foreign collaborators and domestic promoters including their financial
standing and credentials in the world market. Preference would be
given to original equipment manufacturers or design establishments,
and companies having a good track record of past supplies to Armed
Forces, Space and Atomic energy sections and having an established R
& D base.
(vi) There would be no minimum capitalization for the FDI. A proper
assessment, however, needs to be done by the management of the

3

DIPP had recently released a Discussion paper calling for views/suggestions from the stakeholders to review the
extant policy on FDI in Defence sector

46

<!-- page 48 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
applicant company depending upon the product and the technology.
The licensing authority would satisfy itself about the adequacy of the
net worth of the non-resident investor taking into account the category
of weapons and equipment that are proposed to be manufactured.

(vii) There would be a three-year lock-in period for transfer of equity from
one non-resident investor to another non-resident investor (including
NRIs & erstwhile OCBs with 60% or more NRI stake) and such
transfer would be subject to prior approval of the FIPB and the
Government.
(viii) The Ministry of Defence is not in a position to give purchase
guarantee for products to be manufactured. However, the planned
acquisition programme for such equipment and overall requirements
would be made available to the extent possible.
(ix) The capacity norms for production will be provided in the licence
based on the application as well as the recommendations of the
Ministry of Defence, which will look into existing capacities of similar
and allied products.
(x) Import of equipment for pre-production activity including development
of prototype by the applicant company would be permitted.
(xi) Adequate safety and security procedures would need to be put in place
by the licensee once the licence is granted and production commences.
These would be subject to verification by authorized Government
agencies.
(xii) The standards and testing procedures for equipment to be produced
under licence from foreign collaborators or from indigenous R & D
will have to be provided by the licensee to the Government nominated
quality assurance agency under appropriate confidentiality clause. The
nominated quality assurance agency would inspect the finished
product and would conduct surveillance and audit of the Quality

47

<!-- page 49 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
Assurance Procedures of the licensee. Self-certification would be
permitted by the Ministry of Defence on case to case basis, which may
involve either individual items, or group of items manufactured by the
licensee. Such permission would be for a fixed period and subject to
renewals.

(xiii) Purchase preference and price preference may be given to the Public
Sector organizations as per guidelines of the Department of Public
Enterprises.
(xiv) Arms and ammunition produced by the private manufacturers will be
primarily sold to the Ministry of Defence. These items may also be
sold to other Government entities under the control of the Ministry of
Home Affairs and State Governments with the prior approval of the
Ministry of Defence. No such item should be sold within the country
to any other person or entity. The export of manufactured items would
be subject to policy and guidelines as applicable to Ordnance Factories
and Defence Public Sector Undertakings. Non-lethal items would be
permitted for sale to persons / entities other than the Central of State
Governments with the prior approval of the Ministry of Defence.
Licensee would also need to institute a verifiable system of removal of
all goods out of their factories. Violation of these provisions may lead
to cancellation of the licence.
(xv) Government decision on applications to FIPB for FDI in defence
industry sector will be normally communicated within a time frame of
10 weeks from the date of acknowledgement.
POWER
5.2.6
5.2.6.1

Electric Generation, Transmission,
Distribution and Trading
i)
Generation and transmission 100%

Automatic

of electric energy produced in-hydro
electric, coal/lignite based thermal,

48

<!-- page 50 -->

Sl.No.

Sector/Activity
oil based thermal and gas based

%
of
Cap/Equity

FDI Entry Route

thermal power plants.
ii)

Non-Conventional

Energy

Generation and Distribution.
iii)

Distribution

of

electric

energy to households, industrial,
commercial and other users and
iv)

Power Trading

Note 1:
All the above would
be subject to the provisions of the
Electricity Act 2003.
Note 2: (i) to (iii) above do not
include generation, transmission
and distribution of electricity
produced
in
atomic
power
plant/atomic energy since private
investment in this sector/activity is
prohibited and is reserved for
public sector.

SERVICES SECTOR
5.2.7
5.2.7.1

Civil Aviation Sector
The Civil Aviation sector includes Airports, Scheduled and Non-Scheduled
domestic passenger airlines, Helicopter services / Seaplane services, Ground
Handling Services, Maintenance and Repair organizations; Flying training
institutes; and Technical training institutions.
For the purposes of the Civil Aviation sector:
(i) “Airport” means a landing and taking off area for aircrafts, usually with
runways and aircraft maintenance and passenger facilities and includes
aerodrome as defined in clause (2) of section 2 of the Aircraft Act, 1934;
(ii) "Aerodrome" means any definite or limited ground or water area

49

<!-- page 51 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
intended to be used, either wholly or in part, for the landing or departure

of aircraft, and includes all buildings, sheds, vessels, piers and other
structures thereon or pertaining thereto;
(iii)"Air transport service" means a service for the transport by air of
persons, mails or any other thing, animate or inanimate, for any kind of
remuneration whatsoever, whether such service consists of a single
flight or series of flights;
(iv)"Air Transport Undertaking" means an undertaking whose business
includes the carriage by air of passengers or cargo for hire or reward;
(v) "Aircraft component" means any part, the soundness and correct
functioning of which, when fitted to an aircraft, is essential to the
continued airworthiness or safety of the aircraft and includes any item of
equipment;
(vi)"Helicopter" means a heavier-than -air aircraft supported in flight by the
reactions of the air on one or more power driven rotors on substantially
vertical axis;
(vii) "Scheduled air transport service", means an air transport service
undertaken between the same two or more places and operated
according to a published time table or with flights so regular or frequent
that they constitute a recognizably systematic series, each flight being
open to use by members of the public;
(viii) “Non-Scheduled Air Transport service” means any service which is
not a scheduled air transport service and will include Cargo airlines;
(ix)“Cargo” airlines would mean such airlines which meet the conditions as
given in the Civil Aviation Requirements issued by the Ministry of Civil
Aviation;
(x) "Seaplane" means an aeroplane capable normally of taking off from and
alighting solely on water;
(xi)“Ground Handling” means (i) ramp handling , (ii) traffic handling both

50

<!-- page 52 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
of which shall include the activities as specified by the Ministry of Civil
Aviation through the Aeronautical Information Circulars from time to
time, and (iii) any other activity specified by the Central Government to
be a part of either ramp handling or traffic handling.

5.2.7.2

5.2.7.2.1

Policy for FDI in Civil Aviation sector
The policy for FDI in the Civil Aviation Sector would be subject to the
Aircraft Rules, 1934 as amended from time to time, Civil Aviation
Requirements, and Aeronautical Information Circulars as notified by the
Ministry of Civil Aviation.
Airports
(a) Greenfield projects
100%
Automatic
(b) Existing projects

100%

Automatic up
to 74%
Government
route beyond
74%

5.2.7.2.2

Air Transport Services
(a) Air Transport Services would include Domestic Scheduled Passenger
Airlines; Non-Scheduled Air Transport Services, helicopter and
seaplane services.
(b) No foreign airlines would be allowed to participate directly or indirectly
in the equity of an Air Transport Undertaking engaged in operating
Scheduled and Non-Scheduled Air Transport Services except Cargo
airlines.
(c) Foreign airlines are allowed to participate in the equity of companies
operating Cargo airlines, helicopter and seaplane services.
(1) Scheduled Air Transport Service/
Domestic
Scheduled
Passenger
Airline
(2) Non-Scheduled Air Transport
Service

49% FDI
(100% for NRIs)

Automatic

74% FDI
(100% for NRIs)

Automatic up
to 49%
Government
route beyond
49% and up to
51

<!-- page 53 -->

Sl.No.

5.2.7.2.3

Sector/Activity

%
of
Cap/Equity

FDI Entry Route

(3) Helicopter services/seaplane 100%
services requiring DGCA approval
Other
services
under
Civil
Aviation sector
(1) Ground Handling Services 74% FDI
subject to sectoral regulations and (100% for NRIs)
security clearance

74%
Automatic

Automatic up
to 49%
Government
route beyond
49% and up to
74%
Automatic

5.2.8
5.2.8.1

5.2.8.2
5.2.8.3

(2)
Maintenance
and
Repair 100%
organizations;
flying
training
institutes; and technical training
institutions
Asset Reconstruction Companies
‘Asset Reconstruction Company’ (ARC) means a company registered with the
Reserve Bank of India under Section 3 of the Securitisation and
Reconstruction of Financial Assets and Enforcement of Security Interest Act,
2002 (SARFAESI Act).
49% of paid-up Government
FDI limit
capital of ARC
Other conditions:
(i) Persons resident outside India, other than Foreign Institutional Investors
(FIIs), can invest in the capital of Asset Reconstruction Companies (ARCs)
registered with Reserve Bank only under the Government Route.

Such

investments have to be strictly in the nature of FDI. Investments by FIIs are
not permitted in the equity capital of ARCs.
(ii) However, FIIs registered with SEBI can invest in the Security Receipts
(SRs) issued by ARCs registered with Reserve Bank. FIIs can invest upto 49
per cent of each tranche of scheme of SRs, subject to the condition that
investment by a single FII in each tranche of SRs shall not exceed 10 per cent
of the issue.
(iii)Any individual investment of more than 10% would be subject to
provisions of section 3(3) (f) of Securitization and Reconstruction of Financial

52

<!-- page 54 -->

Sl.No.

Sector/Activity

5.2.9
5.2.9.1

Banking –Private sector
Banking –Private sector

5.2.9.2

%
of
FDI Entry Route
Cap/Equity
Assets and Enforcement of Security Interest Act, 2002.

74%
including Automatic up
investment by FIIs
to 49%

Other conditions:

Government
route beyond
49% and up to
74%

(1) This 74% limit will include investment under the Portfolio Investment
Scheme (PIS) by FIIs, NRIs and shares acquired prior to September 16, 2003
by erstwhile OCBs, and continue to include IPOs, Private placements,
GDR/ADRs and acquisition of shares from existing shareholders.
(2) The aggregate foreign investment in a private bank from all sources will
be allowed up to a maximum of 74 per cent of the paid up capital of the Bank.
At all times, at least 26 per cent of the paid up capital will have to be held by
residents, except in regard to a wholly-owned subsidiary of a foreign bank.
(3) The stipulations as above will be applicable to all investments in existing
private sector banks also.
(4) The permissible limits under portfolio investment schemes through stock
exchanges for FIIs and NRIs will be as follows:
(i) In the case of FIIs, as hitherto, individual FII holding is restricted to 10
per cent of the total paid-up capital, aggregate limit for all FIIs cannot
exceed 24 per cent of the total paid-up capital, which can be raised to
49 per cent of the total paid-up capital by the bank concerned through
a resolution by its Board of Directors followed by a special resolution
to that effect by its General Body.
(a) Thus, the FII investment limit will continue to be within 49 per
cent of the total paid-up capital.
(b) In the case of NRIs, as hitherto, individual holding is restricted to 5

53

<!-- page 55 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
per cent of the total paid-up capital both on repatriation and nonrepatriation basis and aggregate limit cannot exceed 10 per cent of
the total paid-up capital both on repatriation and non-repatriation
basis. However, NRI holding can be allowed up to 24 per cent of
the total paid-up capital both on repatriation and non-repatriation
basis provided the banking company passes a special resolution to
that effect in the General Body.

(c) Applications for foreign direct investment (FDI route) in private
banks having joint venture/subsidiary in insurance sector may be
addressed to the Reserve Bank of India (RBI) for consideration in
consultation with the Insurance Regulatory and Development
Authority (IRDA) in order to ensure that the 26 per cent limit of
foreign shareholding applicable for the insurance sector is not
being breached.
(d) Transfer of shares under FDI from residents to non-residents will
continue to require approval of RBI and Government as per para
4.2.2 above as applicable.
(e) The policies and procedures prescribed from time to time by RBI
and other institutions such as SEBI, D/o Company Affairs and
IRDA on these matters will continue to apply.
(f) RBI guidelines relating to acquisition by purchase or otherwise of
shares of a private bank, if such acquisition results in any person
owning or controlling 5 per cent or more of the paid up capital of
the private bank will apply to non-resident investors as well.
(ii) Setting up of a subsidiary by foreign banks
(a) Foreign banks will be permitted to either have branches or
subsidiaries but not both.
(b) Foreign banks regulated by banking supervisory authority in the

54

<!-- page 56 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
home country and meeting Reserve Bank’s licensing criteria will
be allowed to hold 100 per cent paid up capital to enable them to
set up a wholly-owned subsidiary in India.

(c) A foreign bank may operate in India through only one of the three
channels viz., (i) branches (ii) a wholly-owned subsidiary and (iii)
a subsidiary with aggregate foreign investment up to a maximum
of 74 per cent in a private bank.
(d) A foreign bank will be permitted to establish a wholly-owned
subsidiary either through conversion of existing branches into a
subsidiary or through a fresh banking license. A foreign bank will
be permitted to establish a subsidiary through acquisition of shares
of an existing private sector bank provided at least 26 per cent of
the paid capital of the private sector bank is held by residents at all
times consistent with para (i) (b) above.
(e) A subsidiary of a foreign bank will be subject to the licensing
requirements and conditions broadly consistent with those for new
private sector banks.
(f) Guidelines for setting up a wholly-owned subsidiary of a foreign
bank will be issued separately by RBI
(g) All applications by a foreign bank for setting up a subsidiary or for
conversion of their existing branches to subsidiary in India will
have to be made to the RBI.
(iii) At present there is a limit of ten per cent on voting rights in respect of
banking companies, and this should be noted by potential investor.
Any change in the ceiling can be brought about only after final policy
decisions and appropriate Parliamentary approvals.
5.2.10
5.2.10.1

Banking- Public Sector
Banking- Public Sector subject to 20%
(FDI
Banking Companies (Acquisition & Portfolio
Transfer of Undertakings) Acts Investment)
1970/80. This ceiling (20%) is also

and Government

55

<!-- page 57 -->

Sl.No.

Sector/Activity
applicable to the State Bank of India
and its associate Banks.

%
of
Cap/Equity

FDI Entry Route

5.2.11
5.2.11.1

Broadcasting
Terrestrial Broadcasting FM (FM
Radio) subject to such terms and
conditions as specified from time to
time by Ministry of Information and
Broadcasting for grant of permission
for setting up of FM Radio Stations

20% (FDI, NRI & Government
PIO investments and
portfolio
investment)

5.2.11.2

Cable Network subject to Cable
Television Network Rules, 1994 and
other conditions as specified from
time to time by Ministry of
Information and Broadcasting

49% (FDI, NRI & Government
PIO investments and
portfolio
investment)

5.2.11.3

Direct –to-Home subject to such
guidelines/terms and conditions as
specified from time to time by
Ministry
of
Information
and
Broadcasting

5.2.11.4

5.2.11.4.1

5.2.11.5

49% (FDI, NRI & Government
PIO investments and
portfolio
investment)
Within this limit,
FDI component not
to exceed
20%
Headend-In-The-Sky (HITS) Broadcasting Service refers to the
multichannel downlinking and distribution of television programme in CBand or Ku Band wherein all the pay channels are downlinked at a central
facility (Hub/teleport) and again uplinked to a satellite after encryption of
channel. At the cable headend these encrypted pay channels are downlinked
using a single satellite antenna, transmodulated and sent to the subscribers by
using a land based transmission system comprising of infrastructure of
cable/optical fibres network.
FDI limit in (HITS) Broadcasting 74% (total direct and Automatic up
Service is subject to such indirect
foreign to 49%
guidelines/terms and conditions as investment including
specified from time to time by portfolio and FDI)
Government
Ministry
of
Information
and
route beyond
Broadcasting.
49% and up to
74%
Setting up hardware facilities such
as up-linking, HUB etc.
(1) Setting up of Up-linking HUB/ 49% (FDI & FII)
Government
Teleports

56

<!-- page 58 -->

Sl.No.

5.2.11.5.1

Sector/Activity

%
of
Cap/Equity
& 100%

FDI Entry Route

(2) Up-linking a Non-News
Government
Current Affairs TV Channel
(3) Up-linking a News & Current 26% (FDI & FII)
Government
Affairs TV Channel subject to the
condition
that
the
portfolio
investment from FII/ NRI shall not
be “persons acting in concert” with
FDI investors, as defined in the
SEBI(Substantial Acquisition of
Shares and Takeovers) Regulations,
1997
Other conditions:
(i) All the activities at (1), (2) and (3) above will be further subject to the
condition that the Company permitted to uplink the channel shall
certify the continued compliance of this requirement through the
Company Secretary at the end of each financial year.
(ii) FDI for Up-linking TV Channels will be subject to compliance with
the Up-linking Policy notified by the Ministry of Information &
Broadcasting from time to time.

5.2.12
5.2.12.1

Commodity Exchanges
1 Futures trading in commodities are regulated under the Forward Contracts
(Regulation) Act, 1952. Commodity Exchanges, like Stock Exchanges, are
infrastructure companies in the commodity futures market. With a view to
infuse globally acceptable best practices, modern management skills and latest
technology, it was decided to allow foreign investment in Commodity
Exchanges.
2

For the purposes of this chapter,
(i) “Commodity Exchange” is a recognized association under the
provisions of the Forward Contracts (Regulation) Act, 1952, as
amended from time to time, to provide exchange platform for trading
in forward contracts in commodities.
(ii) “recognized association” means an association to which recognition
for the time being has been granted by the Central Government under
Section 6 of the Forward Contracts (Regulation) Act, 1952

57

<!-- page 59 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
(iii) “Association” means any body of individuals, whether incorporated or
not, constituted for the purposes of regulating and controlling the
business of the sale or purchase of any goods and commodity
derivative.
(iv) “Forward contract” means a contract for the delivery of goods and
which is not a ready delivery contract.

(v) “Commodity derivative” means•

a contract for delivery of goods, which is not a ready delivery contract;
or

•

a contract for differences which derives its value from prices or indices
of prices of such underlying goods or activities, services, rights,
interests and events, as may be notified in consultation with the
Forward Markets Commission by the Central Government, but does
not include securities.

5.2.12.2

5.2.12.3

Policy for FDI in Commodity 49% (FDI & FII) Government
Exchange
[Investment
by
Registered FII under
Portfolio Investment
Scheme (PIS) will
be limited to 23%
and
Investment
under FDI Scheme
limited to 26% ]
Other conditions:
(i)
FII purchases shall be restricted to secondary market only and
(ii)

No non-resident investor/ entity, including persons acting in
concert, will hold more than 5% of the equity in these
companies.

5.2.13

5.2.13.1

Development
of
Townships,
Housing, Built-up infrastructure
and
Construction-development
projects
Townships,
housing,
built-up 100%
infrastructure
and
constructiondevelopment projects (which would

Automatic

58

<!-- page 60 -->

Sl.No.

Sector/Activity
include, but not be restricted to,
housing,
commercial
premises,
hotels, resorts, hospitals, educational
institutions, recreational facilities,
city and regional level infrastructure)

5.2.13.2

%
of
Cap/Equity

FDI Entry Route

Investment to be made will be subject to the following conditions:
(1) Minimum area to be developed under each project would be as under:
(i) In case of development of serviced housing plots, a minimum land
area of 10 hectares
(ii) In case of construction-development projects, a minimum built-up area
of 50,000 sq.mts
(iii)In case of a combination project, any one of the above two conditions
would suffice
(2) Minimum capitalization of US$10 million for wholly owned subsidiaries
and US$ 5 million for joint ventures with Indian partners. The funds would
have to be brought in within six months of commencement of business of the
Company.
(3) Original investment cannot be repatriated before a period of three years
from completion of minimum capitalization. Original investment means the
entire amount brought in as FDI. The lock-in period of three years will be
applied from the date of receipt of each installment/tranche of FDI or from the
date of completion of minimum capitalization, whichever is later. However,
the investor may be permitted to exit earlier with prior approval of the
Government through the FIPB.
(4) At least 50% of the project must be developed within a period of five years
from the date of obtaining all statutory clearances. The investor/investee
company would not be permitted to sell undeveloped plots. For the purpose of
these guidelines, “undeveloped plots” will mean where roads, water supply,
street lighting, drainage, sewerage, and other conveniences, as applicable

59

<!-- page 61 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
under prescribed regulations, have not been made available. It will be
necessary that the investor provides this infrastructure and obtains the
completion certificate from the concerned local body/service agency before he
would be allowed to dispose of serviced housing plots.
(5) The project shall conform to the norms and standards, including land use
requirements and provision of community amenities and common facilities, as
laid down in the applicable building control regulations, bye-laws, rules, and
other regulations of the State Government/Municipal/Local Body concerned.
(6) The investor/investee company shall be responsible for obtaining all
necessary approvals, including those of the building/layout plans, developing
internal and peripheral areas and other infrastructure facilities, payment of
development, external development and other charges and complying with all
other requirements as prescribed under applicable rules/bye-laws/regulations
of the State Government/ Municipal/Local Body concerned.
(7) The State Government/ Municipal/ Local Body concerned, which approves
the building / development plans, would monitor compliance of the above
conditions by the developer.
Note:
(i) The conditions at (1) to (4) above would not apply to Hotels & Tourism,
Hospitals and SEZ’s.
(ii) For investment by NRIs, the conditions at (1) to (4) above would not
apply.
(iii) 100% FDI is allowed under the automatic route in development of Special
Economic Zones (SEZ) without the conditionalities at (1) to (4) above. This

60

<!-- page 62 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
will be subject to the provisions of Special Economic Zones Act 2005 and the
SEZ Policy of the Department of Commerce.
(iv) FDI is not allowed in Real Estate Business.

5.2.14
5.2.14.1
5.2.14.2

Credit Information Companies
(CIC)
Credit Information Companies
49% (FDI & FII)
Government
Other Conditions:
(1) Foreign investment in Credit Information Companies is subject to the
Credit Information Companies (Regulation) Act, 2005.
(2) Foreign investment is permitted under the Government route, subject to
regulatory clearance from RBI.
(3) Investment by a registered FII under the Portfolio Investment Scheme
would be permitted up to 24% only in the CICs listed at the Stock Exchanges,
within the overall limit of 49% for foreign investment.
(4) Such FII investment would be permitted subject to the conditions that:
(a)

No single entity should directly or indirectly hold more than 10%
equity.

(b) Any acquisition in excess of 1% will have to be reported to RBI as a
mandatory requirement; and
(c) FIIs investing in CICs shall not seek a representation on the Board
of Directors based upon their shareholding.
5.2.15
5.2.15.1

Industrial Parks - both setting up 100%
Automatic
and already established Industrial
Parks
(i) “Industrial Park” is a project in which quality infrastructure in the
form of plots of developed land or built up space or a combination
with common facilities, is developed and made available to all the
allottee units for the purposes of industrial activity.
(ii) “Infrastructure” refers to facilities required for functioning of units

61

<!-- page 63 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
located in the Industrial Park and includes roads (including approach
roads), water supply and sewerage, common effluent treatment
facility, telecom network, generation and distribution of power, air
conditioning.

(iii)“Common Facilities” refer to the facilities available for all the units
located in the industrial park, and include facilities of power, roads
(including approach roads), water supply and sewerage, common
effluent treatment, common testing, telecom services, air conditioning,
common facility buildings, industrial canteens, convention/conference
halls, parking, travel desks, security service, first aid center,
ambulance and other safety services, training facilities and such other
facilities meant for common use of the units located in the Industrial
Park.
(iv) “Allocable area” in the Industrial Park means(a) in the case of plots of developed land- the net site area available for
allocation to the units, excluding the area for common facilities.
(b) in the case of built up space- the floor area and built up space
utilized for providing common facilities.
(c) in the case of a combination of developed land and built-up spacethe net site and floor area available for allocation to the units
excluding the site area and built up space utilized for providing
common facilities.
(v) “Industrial Activity” means manufacturing, electricity, gas and water
supply,

post

and

telecommunications,

software

publishing,

consultancy and supply, data processing, database activities and
distribution of electronic content, other computer related activities,

62

<!-- page 64 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
Research and experimental development on natural sciences and
engineering, Business and management consultancy activities and
Architectural, engineering and other technical activities.

5.2.15.2

FDI in Industrial Parks would not be subject to the conditionalities applicable
for construction development projects etc. spelt out in para 5.2.13 above,
provided the Industrial Parks meet with the under-mentioned conditions:
(i) it would comprise of a minimum of 10 units and no single unit shall
occupy more than 50% of the allocable area;
(ii) the minimum percentage of the area to be allocated for industrial
activity shall not be less than 66% of the total allocable area.

5.2.16
5.2.16.1

Insurance
Insurance

5.2.16.2

Other Conditions:
(1) FDI in the Insurance sector, as prescribed in the Insurance Act, 1999, is

26%

Automatic

allowed under the automatic route.
(2) This will be subject to the condition that Companies bringing in FDI shall
obtain necessary license from the Insurance Regulatory & Development
Authority for undertaking insurance activities.
5.2.17
5.2.17.1

Infrastructure Company in the
Securities Market
Infrastructure
companies
in
Securities Markets, namely, stock
exchanges, depositories and clearing
corporations, in compliance with
SEBI Regulations

49% (FDI & FII) Government
[FDI limit of 26 per
cent and an FII limit
of 23 per cent of the
paid-up capital ]

5.2.17.2
5.2.17.2.1

Other Conditions:
FII can invest only through purchases in the secondary market

5.2.18
5.2.18.1

Non-Banking Finance Companies (NBFC)
Foreign investment in NBFC is 100%

Automatic

allowed under the automatic route in

63

<!-- page 65 -->

Sl.No.

Sector/Activity
only the following activities:

%
of
Cap/Equity

FDI Entry Route

(i) Merchant Banking
(ii) Under Writing
(iii) Portfolio Management
Services
(iv)Investment Advisory Services
(v) Financial Consultancy
(vi)Stock Broking
(vii) Asset Management
(viii) Venture Capital
(ix) Custodian Services
(x) Factoring
(xi) Credit Rating Agencies
(xii) Leasing & Finance
(xiii) Housing Finance
(xiv) Forex Broking
(xv) Credit Card Business
(xvi) Money Changing Business
(xvii) Micro Credit
(xviii) Rural Credit
5.2.18.2

Other Conditions:
(1) Investment would be subject to the following minimum capitalisation
norms:
(i) US $0.5 million for foreign capital upto 51% to be brought upfront
(ii) US $ 5 million for foreign capital more than 51% and upto 75% to be

64

<!-- page 66 -->

Sl.No.

Sector/Activity
brought upfront

%
of
I Cap/Equity

FDI Entry Route

I

(iii)US $ 50 million for foreign capital more than 75% out of which US$
7.5 million to be brought upfront and the balance in 24 months.
(iv)100% foreign owned NBFCs with a minimum capitalisation of US$ 50
million can set up step down subsidiaries for specific NBFC activities,
without any restriction on the number of operating subsidiaries and
without bringing in additional capital. The minimum capitalization
condition as mandated by para 4.6.4.1, therefore, shall not apply
to downstream subsidiaries.
(v) Joint Venture operating NBFCs that have 75% or less than 75%
foreign investment can also set up subsidiaries for undertaking other
NBFC activities, subject to the subsidiaries also complying with the
applicable minimum capitalisation norm mentioned in (i), (ii) and (iii)
above and (vi) below.
(vi)Non- Fund based activities : US $0.5 million to be brought upfront for
all permitted non-fund based NBFCs irrespective of the level of
foreign investment subject to the following condition:
It would not be permissible for such a company to set up any
subsidiary for any other activity, nor it can participate in any equity
of an NBFC holding/operating company.
Note: The following activities would be classified as Non-Fund Based
activities:
(a) Investment Advisory Services
(b) Financial Consultancy
(c) Forex Broking

65

<!-- page 67 -->

Sl.No.

Sector/Activity
(d) Money Changing Business

%
of
Cap/Equity

FDI Entry Route

(e) Credit Rating Agencies
(vii) This will be subject to compliance with the guidelines of RBI.
Note: Credit Card business includes issuance, sales, marketing & design of
various payment products such as credit cards, charge cards, debit cards,
stored value cards, smart card, value added cards etc.
(2) The NBFC will have to comply with the guidelines of the relevant
regulator/ s, as applicable
5.2.19
5.2.19.1

5.2.19.2

5.2.20
5.2.20.1
5.2.20.2

Petroleum & Natural Gas Sector
Exploration activities of oil and
natural gas fields, infrastructure
related to marketing of petroleum
products and natural gas, marketing
of natural gas and petroleum
products,
petroleum
product
pipelines, natural gas/pipelines, LNG
Regasification infrastructure, market
study and formulation and Petroleum
refining in the private sector, subject
to the existing sectoral policy and
regulatory framework in the oil
marketing sector and the policy of
the
Government
on
private
participation in exploration of oil and
the discovered fields of national oil
companies
Petroleum refining by the Public
Sector Undertakings (PSU), without
any disinvestment or dilution of
domestic equity in the existing PSUs.
Print Media
Publishing of Newspaper and
periodicals dealing with news and
current affairs
Publication of Indian editions of
foreign magazines dealing with news
and current affairs

100%

Automatic

49%

Government

26%
(FDI
and Government
investment
by
NRIs/PIOs/FII)
26%
(FDI
and Government
investment
by
NRIs/PIOs/FII)

66

<!-- page 68 -->

Sl.No.

Sector/Activity

%
of
Cap/Equity

FDI Entry Route

5.2.20.2.1

Other Conditions:
(i) ‘Magazine’, for the purpose of these guidelines, will be defined as a
periodical publication, brought out on non-daily basis, containing
public news or comments on public news.
(ii) Foreign investment would also be subject to the Guidelines for
Publication of Indian editions of foreign magazines dealing with news
and current affairs issued by the Ministry of Information &
Broadcasting on 4.12.2008.

5.2.20.3

Publishing/printing of Scientific and 100%
Technical
Magazines/specialty
journals/ periodicals, subject to
compliance with the legal framework
as applicable and guidelines issued in
this regard from time to time by
Ministry
of
Information
and
Broadcasting.

Government

5.2.20.4

Publication of facsimile edition of 100%
foreign newspapers

Government

5.2.20.4.1

Other Conditions:
(i) FDI should be made by the owner of the original foreign newspapers
whose facsimile edition is proposed to be brought out in India.
(ii) Publication of facsimile edition of foreign newspapers can be
undertaken only by an entity incorporated or registered in India under
the provisions of the Companies Act, 1956.
(iii) Publication of facsimile edition of foreign newspaper would also be
subject to the Guidelines for publication of newspapers and periodicals
dealing with news and current affairs and publication of facsimile
edition of foreign newspapers issued by Ministry of Information &
Broadcasting on 31.3.2006, as amended from time to time.

5.2.21
5.2.21.1

Security Agencies in Private sector
The ‘Private Security Agencies (Regulation) Act, 2005’ regulates the
operations of private security agencies. Under Section 6(2) of the above Act,

67

<!-- page 69 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
Cap/Equity
“A company, firm or an association of persons shall not be considered for
issue of a licence under this Act, if, it is not registered in India, or is having a
proprietor or a majority shareholder, partner or director, who is not a citizen of
India”. As such, under the provisions of this Act:
•

a foreign company cannot be considered for a license under the Act

•

only a firm registered in India can be eligible for a license

•

to be eligible for a license under the Act, a firm cannot have a foreign
director/partner

•

majority shareholder cannot be a foreigner-i.e. foreign shareholding
would be restricted to a maximum of 49% under the Government route

5.2.22
5.2.22.1

Satellites – Establishment and operation
Satellites – Establishment and 74%
operation, subject to the sectoral
guidelines
of
Department
of
Space/ISRO

5.2.23

Telecommunication
Investment caps and other conditions for specified services are given below.

Government

However, licensing and security requirements notified by the Department of
Telecommunications will need to be complied with for all services.
5.2.23.1

5.2.23.1.1

(i) Telecom services

Other conditions:

74%

Automatic up
to 49%
Government
route beyond
49% and up to
74%

(1) General Conditions:
(i) This is applicable in case of Basic, Cellular, Unified Access Services,
National/ International Long Distance, V-Sat, Public Mobile Radio
Trunked Services (PMRTS), Global Mobile Personal Communications

68

<!-- page 70 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
Services (GMPCS) and other value added Services.

(ii) Both direct and indirect foreign investment in the licensee company
shall be counted for the purpose of FDI ceiling. Foreign Investment
shall include investment by Foreign Institutional Investors (FIIs), Nonresident Indians (NRIs), Foreign Currency Convertible Bonds
(FCCBs), American Depository Receipts (ADRs), Global Depository
Receipts (GDRs) and convertible preference shares held by foreign
entity. In any case, the `Indian’ shareholding will not be less than 26
percent.
(iii) FDI in the licensee company/Indian promoters/investment companies
including their holding companies shall require approval of the
Foreign Investment Promotion Board (FIPB) if it has a bearing on the
overall ceiling of 74 percent. While approving the investment
proposals, FIPB shall take note that investment is not coming from
countries of concern and/or unfriendly entities.
(iv) The investment approval by FIPB shall envisage the conditionality
that Company would adhere to licence Agreement.
(v) FDI shall be subject to laws of India and not the laws of the foreign
country/countries.
(2) Security Conditions:
(i) The Chief Officer In-charge of technical network operations and the
Chief Security Officer should be a resident Indian citizen.
(ii) Details of infrastructure/network diagram (technical details of the
network) could be provided on a need basis only to telecom equipment
suppliers/manufacturers and the affiliate/parents of the licensee
company.

Clearance

from

the

licensor

(Department

of

Telecommunications) would be required if such information is to be

69

<!-- page 71 -->

Sl.No.

Sector/Activity
provided to anybody else.

%
of
I Cap/Equity

FDI Entry Route

I

(iii)For security reasons, domestic traffic of such entities as may be
identified /specified by the licensor shall not be hauled/routed to any
place outside India.
(iv)The licensee company shall take adequate and timely measures to
ensure that the information transacted through a network by the
subscribers is secure and protected.
(v) The officers/officials of the licensee companies dealing with the lawful
interception of messages will be resident Indian citizens.
(vi)The majority Directors on the Board of the company shall be Indian
citizens.
(vii) The positions of the Chairman, Managing Director, Chief Executive
Officer (CEO) and/or Chief Financial Officer (CFO), if held by
foreign nationals, would require to be security vetted by Ministry of
Home Affairs (MHA). Security vetting shall be required periodically
on yearly basis. In case something adverse is found during the
security vetting, the direction of MHA shall be binding on the
licensee.
(viii) The Company shall not transfer the following to any person/place
outside India:(a) Any accounting information relating to subscriber (except for
international roaming/billing) (Note: it does not restrict a
statutorily required disclosure of financial nature) ; and
(b) User information (except pertaining to foreign subscribers
using Indian Operator’s network while roaming).
(ix) The Company must provide traceable identity of their subscribers.
However, in case of providing service to roaming subscriber of foreign

70

<!-- page 72 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
Companies, the Indian Company shall endeavour to obtain traceable
identity of roaming subscribers from the foreign company as a part of
its roaming agreement.

(x) On request of the licensor or any other agency authorised by the
licensor, the telecom service provider should be able to provide the
geographical location of any subscriber (BTS location) at a given point
of time.
(xi)The Remote Access (RA) to Network would be provided only to
approved location(s) abroad through approved location(s) in India.
The approval for location(s) would be given by the Licensor (DOT)
in consultation with the Ministry of Home Affairs.
(xii) Under

no

circumstances,

should

any

RA

to

the

suppliers/manufacturers and affiliate(s) be enabled to access Lawful
Interception System(LIS), Lawful Interception Monitoring(LIM),
Call contents of the traffic and any such sensitive sector/data, which
the licensor may notify from time to time.
(xiii) The licensee company is not allowed to use remote access facility for
monitoring of content.
(xiv) Suitable technical device should be made available at Indian end to
the designated security agency /licensor in which a mirror image of
the remote access information is available on line for monitoring
purposes.
(xv) Complete audit trail of the remote access activities pertaining to the
network operated in India should be maintained for a period of six
months and provided on request to the licensor or any other agency
authorised by the licensor.
(xvi) The telecom service providers should ensure that necessary

71

<!-- page 73 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
provision (hardware/software) is available in their equipment for
doing the Lawful interception and monitoring from a centralized
location.

(xvii)The telecom service providers should familiarize/train Vigilance
Technical Monitoring (VTM)/security agency officers/officials in
respect of relevant operations/features of their systems.
(xviii) It shall be open to the licensor to restrict the Licensee Company
from operating in any sensitive area from the National Security angle.
(xix) In order to maintain the privacy of voice and data, monitoring shall
only be upon authorisation by the Union Home Secretary or Home
Secretaries of the States/Union Territories.
(xx) For monitoring traffic, the licensee company shall provide access of
their network and other facilities as well as to books of accounts to
the security agencies.
(xxi) The aforesaid Security Conditions shall be applicable to all the
licensee companies operating telecom services covered under this
circular irrespective of the level of FDI.
(xxii)Other Service Providers (OSPs), providing services like Call
Centres, Business Process Outsourcing (BPO), tele-marketing, teleeducation, etc, and are registered with DoT as OSP. Such OSPs
operate the service using the telecom infrastructure provided by
licensed telecom service providers and 100% FDI is permitted for
OSPs.

As the security conditions are applicable to all licensed

telecom service providers, the security conditions mentioned above
shall not be separately enforced on OSPs.
(3) The above General Conditions and Security Conditions shall also be
applicable to the companies operating telecom service(s) with the FDI cap of

72

<!-- page 74 -->

Sl.No.

Sector/Activity

%
of
Cap/Equity

49%.
(4)

FDI Entry Route

All the telecom service providers shall submit a compliance report on

the aforesaid conditions to the licensor on 1st day of July and January on six
monthly basis.
5.2.23.2

(a)

ISP with gateways

74%

(b) ISP’s not providing gateways i.e
without gate-ways (both for satellite
and marine cables)

Automatic up
to 49%
Government
route beyond
49% and up to
74%

Note: The new guidelines of
August 24, 2007 Department of
Telecommunications provide for
new ISP licenses with FDI upto
74%.
(c) Radio paging
(d) End-to-End bandwidth
5.2.23.3

(a)

Infrastructure

provider 100%

providing dark fibre, right of way,
duct space, tower (IP Category I)
(b)Electronic Mail

Automatic up
to 49%
Government
route beyond
49%

(c) Voice Mail
Note: Investment in all the above
activities is subject to the conditions
that such companies will divest 26%
of their equity in favour of Indian
public in 5 years, if these companies
are listed in other parts of the world.
5.2.24
5.2.24.1
5.2.24.1.1

Trading
Automatic
(i) Cash & Carry Wholesale 100%
Trading/
Wholesale
Trading
(including sourcing from MSEs)
Definition: Cash & Carry Wholesale trading/Wholesale trading, would mean
sale of goods/merchandise to retailers, industrial, commercial, institutional or
73

<!-- page 75 -->

Sl.No.

Sector/Activity

%
of
FDI Entry Route
I Cap/Equity
I
other professional business users or to other wholesalers and related
subordinated service providers. Wholesale trading would, accordingly, be
sales for the purpose of trade, business and profession, as opposed to sales for
the purpose of personal consumption. The yardstick to determine whether the
sale is wholesale or not would be the type of customers to whom the sale is
made and not the size and volume of sales. Wholesale trading would include
resale, processing and thereafter sale, bulk imports with ex-port/ex-bonded
warehouse business sales and B2B e-Commerce.

5.2.24.1.2

Guidelines for Cash & Carry Wholesale Trading/Wholesale Trading
(WT):
(a)

For undertaking WT, requisite licenses/registration/ permits, as
specified under the relevant Acts/Regulations/Rules/Orders of the
State Government/Government Body/Government Authority/Local
Self-Government Body under that State Government should be
obtained.

(b)

Except in case of sales to Government, sales made by the wholesaler
would be considered as ‘cash & carry wholesale trading/wholesale
trading’ with valid business customers, only when WT are made to
the following entities:
(I)

Entities holding sales tax/ VAT registration/service

tax/excise duty registration; or
(II)

Entities holding trade licenses i.e. a license/registration

certificate/membership

certificate/registration

under

Shops

and

Establishment Act, issued by a Government Authority/ Government
Body/

Local

Self-Government

Authority,

reflecting

that

the

entity/person holding the license/ registration certificate/ membership
certificate, as the case may be, is itself/ himself/herself engaged in a
business involving commercial activity; or
(III) Entities holding permits/license etc. for undertaking retail
trade (like tehbazari and similar license for hawkers) from
Government Authorities/Local Self Government Bodies; or

74

<!-- page 76 -->

Sl.No.

Sector/Activity
(IV)

%
of
FDI Entry Route
Cap/Equity
Institutions having certificate of incorporation or

registration as a society or registration as public trust for their self
consumption.
Note: An Entity to whom WT is made, may fulfill any one of
the 4 conditions.
( c)

Full records indicating all the details of such sales like name of entity,
kind of entity, registration/license/permit etc. number, amount of sale
etc. should be maintained on a day to day basis.

(d)

WT of goods would be permitted among companies of the same group.
However, such WT to group companies taken together should not
exceed 25% of the total turnover of the wholesale venture

(e)

WT can be undertaken as per normal business practice, including
extending credit facilities subject to applicable regulations.

(f)

A Wholesale/Cash & carry trader cannot open retail shops to sell to the
consumer directly.

5.2.24.2
5.2.24.2.1

100%
Automatic
E-commerce activities
E-commerce activities refer to the activity of buying and selling by a company
through the e-commerce platform. Such companies would engage only in
Business to Business (B2B) e-commerce and not in retail trading, inter-alia
implying that existing restrictions on FDI in domestic trading would be
applicable to e-commerce as well.

5.2.24.3

Test marketing of such items for 100%
which a company has approval for
manufacture, provided such test
marketing facility will be for a period
of two years, and investment in
setting up manufacturing facility
commences simultaneously with test
marketing.

Government

75

<!-- page 77 -->

Sl.No.

Sector/Activity

%
of
Cap/Equity

5.2.24.4

Single Brand product trading 4

51%

FDI Entry Route
Government

(1) Foreign Investment in Single Brand product trading is aimed at
attracting investments in production and marketing, improving the availability
of such goods for the consumer, encouraging increased sourcing of goods
from India, and enhancing competitiveness of Indian enterprises through
access to global designs, technologies and management practices.
(2) FDI in Single Brand products retail trade would be subject to the following
conditions:
(a) Products to be sold should be of a ‘Single Brand’ only.
(b) Products should be sold under the same brand internationally i.e.
products should be sold under the same brand in one or more countries
other than India.
(c) ‘Single Brand’ product-retailing would cover only products which are
branded during manufacturing.
(3) Application seeking permission of the Government for FDI in retail trade
of ‘Single Brand’ products would be made to the Secretariat for Industrial
Assistance (SIA) in the Department of Industrial Policy & Promotion. The
application would specifically indicate the product/ product categories which
are proposed to be sold under a ‘Single Brand’. Any addition to the product/
product categories to be sold under ‘Single Brand’ would require a fresh
approval of the Government.
(4) Applications would be processed in the Department of Industrial Policy &
Promotion, to determine whether the products proposed to be sold satisfy the
notified guidelines, before being considered by the FIPB for Government
approval.
5.2.25

Courier services for carrying packages, parcels and other items which do
not come within the ambit of the Indian Post Office Act, 1898.

4

DIPP had recently released a Discussion paper calling for views/suggestions from the stakeholders to review the
extant policy on FDI in Multi-brand Retail

76

<!-- page 78 -->

Sl.No.

Sector/Activity

5.2.25.1

%
of
I Cap/Equity
100% FDI is allowed under the Government route.

FDI Entry Route

5.2.25.2

This will be subject to existing Law i.e Indian Post Office Act 1898 and

I

exclusion of activity relating to the distribution of letters.

Note:
Minimum capitalization includes share premium received alongwith the face value of the share,
only when it is received by the company upon issue of the shares to the non-resident investor.
Amount paid by the transferee during post-issue transfer of shares beyond the issue price of the
share, cannot be taken into account while calculating minimum capitalization requirement;

77

<!-- page 79 -->

CHAPTER 6: REMITTANCE, REPORTING AND VIOLATION
6.1 REMITTANCE AND REPATRIATION
6.1.1 Remittance of sale proceeds/Remittance on winding up/Liquidation of Companies:
(i) Sale proceeds of shares and securities and their remittance is ‘remittance of asset’
governed by The Foreign Exchange Management (Remittance of Assets) Regulations
2000 under FEMA.
(ii) AD Category – I bank can allow the remittance of sale proceeds of a security (net of
applicable taxes) to the seller of shares resident outside India, provided the security has
been held on repatriation basis, the sale of security has been made in accordance with the
prescribed guidelines and NOC / tax clearance certificate from the Income Tax
Department has been produced.
(iii) Remittance on winding up/liquidation of Companies
AD Category – I banks have been allowed to remit winding up proceeds of companies in
India, which are under liquidation, subject to payment of applicable taxes. Liquidation
may be subject to any order issued by the court winding up the company or the
official liquidator in case of voluntary winding up under the provisions of the
Companies Act, 1956. AD Category – I banks shall allow the remittance provided the
applicant submits:
a.

No objection or Tax clearance certificate from Income Tax Department for
the remittance.

b.

Auditor's certificate confirming that all liabilities in India have been either fully
paid or adequately provided for.

c.

Auditor's certificate to the effect that the winding up is in accordance with
the provisions of the Companies Act, 1956.

d.

In case of winding up otherwise than by a court, an auditor's certificate to the
effect that there are no legal proceedings pending in any court in India against the
applicant or the company under liquidation and there is no legal impediment in
permitting the remittance.

78

<!-- page 80 -->

6.1.2

Repatriation of Dividend: Dividends are freely repatriable without any restrictions (net

after Tax deduction at source or Dividend Distribution Tax, if any, as the case may be). The
repatriation is governed by the provisions of the Foreign Exchange Management (Current
Account Transactions) Rules, 2000, as amended from time to time.
6.1.3

Repatriation of Interest: Interest on fully, mandatorily & compulsorily convertible

debentures is also freely repatriable without any restrictions (net of applicable taxes). The
repatriation is governed by the provisions of the Foreign Exchange Management (Current
Account Transactions) Rules, 2000, as amended from time to time.
6.2.

REPORTING OF FDI

6.2.1 Reporting of Inflow
(i) An Indian company receiving investment from outside India for issuing shares /
convertible debentures / preference shares under the FDI Scheme, should report the
details of the amount of consideration to the Regional Office concerned of the Reserve
Bank not later than 30 days from the date of receipt in the Advance Reporting Form
enclosed as Annex-5.
(ii) Indian companies are required to report the details of the receipt of the amount of
consideration for issue of shares / convertible debentures, through an AD Category – I
bank, together with a copy/ies of the FIRC/s evidencing the receipt of the remittance
along with the KYC report (enclosed as Annex-6) on the non-resident investor from the
overseas bank remitting the amount. The report would be acknowledged by the Regional
Office concerned, which will allot a Unique Identification Number (UIN) for the amount
reported.
6.2.2

Reporting of issue of shares

(i) After issue of shares (including bonus and shares issued on rights basis and shares issued
under ESOP)/fully, mandatorily & compulsorily convertible debentures / fully,
mandatorily & compulsorily convertible preference shares, the Indian company has to file
Form FC-GPR, enclosed in Annex-1-A, not later than 30 days from the date of issue of
shares.
(ii) Form

FC-GPR

has

to

be

duly

filled

up

and

signed

by

Managing

Director/Director/Secretary of the Company and submitted to the Authorized Dealer of

79
