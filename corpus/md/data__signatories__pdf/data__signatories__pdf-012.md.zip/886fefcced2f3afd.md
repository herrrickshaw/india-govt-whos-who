---
doc_id: "886fefcced2f3afd"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/e9f41e43cc812406ba5016f6c3b35ed4.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification for continuation of minimum pension under EPS, 1995 beyond 31.03.2015. - 16.06.2016"
date: "2025-06-26"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "36180075f7b078cd"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 415]

ubZ fnYyh] c`gLifrokj] twu 16] 2016@T;s"B 26] 1938

No. 415]

NEW DELHI, THURSDAY, JUNE 16, 2016/ JYAISTHA 26, 1938

म और रोजगार मं ालय
अिधसूचना
नई दली, 16 जून, 2016

सा.
सा.का.
का.िन.
िन. 603(
603(अ).—
).—के ीय सरकार कमचारी भिवय िनिध और कण उपबंध अिधिनयम
,

, 1952 (1952 का 19)

क धारा

क उपधारा (1) के साथ प#ठत धारा 6क &ारा द' शि)य* का योग करते -ए, कमचारी प/शन 0कम, 1995 का और संशोधन
करने के िलए िन1िलिखत 0कम बनाती है, अथात् :-

7

1. (1)

इन 0कम का संि78 नाम कमचारी प/शन (चतुथ संशोधन) 0कम, 2016 है।

(2) ये 1
2.

अैल, 2015 से वृ' -आ समझा जाएगा ।

कमचारी प/शन 0कम, 1955 (िजसे इसम/ इसके प?ात् मूल 0कम कहा गया है) के पैरा 12 म/, (क) उप पैरा (7क)

(i) "

(ii)

"

म/,-

िव'ीय वष 2014-15 के संबंध म/" शBद* और अंक* का लोप कया जाए ;

िन1िलिखत परं तुक अंतः0थािपत कया जाए, अथात् :-

परं तु इस उप पैरा के अधीन एक हजार Dपए क यूनतम प/शन 1 िसतंबर,

2014

से ही िन1िलिखत के अEयधीन संदये होगा

–

से पहले इस 0कम के िव0ता#रत उपबंध* के अधीन सद0य* &ारा िलए गए संराशीकरण के फायदे और
पूंजी के ितलाभ के मGे कटौितयां ; और

(i) 26 िसतंबर, 2008

(ii) उप पैरा (7)

3.

के अधीन ारं िभक प/शन के मGे कटौितयां ।"।

मूल 0कम के पैरा 16 म/,-

(अ) उप पैरा (2)

म/ खंड (क) के उपखंड (v) म/ "िव'ीय वष 2014-15 के संबंध म/" शBद* और अंक* का लोप कर/ ;

(आ) उप पैरा (3)

म/ खंड (ख) के परं तुक म/ "िव'ीय वष 2014-15 के संबंध म/ "शBद* और अंक* का लोप कर/ ;

3061 GI/2016

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY
(इ) उप पैरा (3)

[PART II—SEC. 3(i)]

म/ खंड (ख) के परं तुक म/ "िव'ीय वष 2014-15 के संबंध म/ "शBद* और अंक* का लोप कर/ ।
[फा. सं. आर-15025/3/2007-एसएस-II (

िजद-II)(भाग-II)]

मनीष गु8ा, संयु) सिचव

: कमचारी प/शन 0कम

के राजपK, असाधारण, भाग 2, खंड 3, उपखंड (i) म/ अिधसूचना
सं. सा.का.िन. 748(अ), तारीख 16 नवंबर, 1995 &ारा कािशत कया गया था और अिधसूचना सं. सा.का.िन. 533(अ) तारीख 19 ebZ,
2016 &ारा अंितम संशोधन कया गया था ।

टपण

,

1995

भारत

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 16th June, 2016.
G.S.R. 603(E).—In exercise of the powers conferred by section 6A read with sub-section (1) of section 7 of the
Employees' Provident Funds and Miscellaneous Provisions Act, 1952 (19 of 1952), the Central Government hereby
makes the following Scheme further to amend the Employees’ Pension Scheme, 1995, namely :1.

2.

(1)

This Scheme may be called the Employees' Pension (Fourth Amendment) Scheme, 2016.

(2)

It shall come into force with effect from the 1st day of April, 2015.

In the Employees' Pension Scheme, 1995 (hereinafter referred to as the principal scheme), in paragraph 12,(a)
(i)
(ii)

in sub-paragraph (7A),the words and figures “for the financial year 2014-15” occurring at

the end shall be omitted;

the following proviso shall be inserted, namely:-

“Provided that, on and from the 1st day of September, 2014, the minimum pension of one thousand rupees
payable under this sub-paragraph shall be subject to-

3.

(i)

deductions on account of benefits of commutation and return of capital taken by members under the
extant provisions of this scheme prior to 26th September, 2008; and

(ii)

deductions on account of early pension under sub-paragraph (7).”.

In the principal scheme, in paragraph 16,(A)

in sub-paragraph (2), in clause (a), in sub-clause (v), the words and
2014-15” shall be omitted;

figures “for the financial year

(B)

in sub-paragraph (3), in the proviso to clause (b), the words and
shall be omitted;

figures “for the financial year 2014-15”

(C)

in sub-paragraph (4), in the proviso to clause (a), the words and
shall be omitted.

figures “for the financial year 2014-15”

[No. R-15025/3/2007-SS-II (Vol-II)(Pt.II)]
MANISH GUPTA, Jt. Secy.
Note : The Employees’ Pension Scheme, 1995 was published in the Gazette of India, Extraordinary, Part II, section 3,
sub-section(i) vide notification number G.S.R. 748(E) dated 16th November, 1995 and was lastly amended vide
notification No. G.S.R. 533(E) dated the 19th May, 2016.
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
