---
doc_id: "61a46bcf30dfa6cd"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/22b85bca08149410c7e8fce9b78b3233.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Disposal of waste paper material lying in temporary tin shed near gate No. 11 (Rajpath facing side), and gate No. 7 - Corrigendum"
date: "2025-06-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9611d1e4f9750b0c"
---

<!-- page 1 -->

Most-Immediate
Most-Immediate

No.D-27017/1/2014-SEO(Pt.)
No.D-27017
/ l/2014-SEO(Pt.)
Government
Government of
of India
India
Ministry
Ministry of
of Commerce
Commerce and
and Industry
Industry
Department
Promotion
Department of
of Industrial
Industrial Policy
Policy and
and Promotion
****
****
Udyog
Udyog Bhawan,
Bhawan, New
New Delhi
Delhi
April, 2015
2015
Dated
Dated the
the 13
13th� April,
CORRIGENDUM
CORRIGENDUM

Subject: Disposal
Disposal of
of waste
waste paper
material lying
lying in
in temporary
temporary tin
tin shed
shed near
near
Subject:
paper material
Gate
side), Gate
No. 77 &
Gate No.
No. 11
11 (Rajpath
(Rajpath facing
facing side),
Gate No.
8s 88 of
of Udyog
Udyog Bhawan,
Bhawan,
New Delhi.
New
Delhi.
Dear
Dear Sir,
Sir,
In
In continuation
continuation of
of this
this Department's
Department's tender
tender notice
notice of
of even
even number
number
dated 31
31st� March,
dated
q.nd to
March, 2015
2015 on
on the
the subject
subject mentioned
mentioned above
above and
to say
say that
that the
the
date
been extended
date for
for submission
submission of
of the
the Bids
Bids has
has been
extended from
from 14.04.2015
14.04.2015 ~to
to
th April,
15.04.2015
April, 2015
2015 is
is declared
declared holiday
holiday on
on account
account
15.04.2015 at
at 3.00
3.00 P.M.
P.M. as
as 14
14t
of the
of
birthday of
the birthday
of Dr.
Dr. B.R.
B.R. Ambedkar.
Ambedkar. The
The terms
terms and
and conditions
conditions of
of the
the
st
�
tender
be remain
be the
tender notice
notice dated
dated 31
31 March,
March, 2015
2015 will
will be
remain be
the same.
same.

II ..�

Copy
to:Copy to:-

r"1 ­
--=-=====::_.,,
FM
(Rajesh
(Rajesh Kumar)
Kumar)
Under
Under Secretary
Secretary to
to the
the Govt.
Govt. of
of India.
India.
Tel. No.
No. 23061256
23061256
Tel.

1.
~ NIC, with the request to upload the above tender enquiry in the website
of DIPP and remove the same on 15 April, 2015 (4.00 PM).
NIC, with the request to upload the above tender enquiry in the website
of DIPP and remove the same on 15 th April, 2015 (4.00 PM).

Copy
Copy for
for information
information to:
to:

1. Reception
Reception Officer,
Officer, Department
Department of
of Indistrial
Indistrial Policy
Policy and
and Promotion,
Promotion, Gate
Gate
1.
No. 12,
Udyog Bhawan,
New Delhi.
No.
12, Udyog
Bhawan, New
Delhi.
2.
New Delhi.
2. CISF,Udyog
CISF,Udyog Bhawan,
Bhawan, New
Delhi.
