---
doc_id: "61dd2871ec4cdaec"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/df60adac7ac69eba309160be811dccf2.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "NFU(HAG) Order"
date: "2017-11-17"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "710b2e11aaa4e403"
---

<!-- page 1 -->

o

lrt l,\'

A \,[
U )\

-5
a

No.A.450 1 1 / 04 / 2OL6-CliS-II
Government of India
Nlinistry of Hea.lth & Family Welfare
CHS-Division
****

Nirman Bhaw-an, New Delhi
Dated the
July,2017

(-nn tmt

LAIT

ORDER
ident is pleased to grant Non-Functional up-gradation to Higher
Administrative Grade to 49 Ofiicers of General Duty Med.ical Cjffiler sub-cadre of the
Central Hea-lth Service in the Pay Sca-Ie of Rs. 67}O}--(arrnual increment
@ 3yr) - Z7OOO
(pre-revised) with effect from the date indicated against their names in-Anner.rre,
as
per provisions of this Order and after complying wittr tne procedural
requirement as in
Para 4 hereunder.

2' The Non-Functional Up-gradation is being granted to the offi.cers under Rule 13
oICCS (Revised) Pay Rules, 2A08.
3'

In case any officer remained unauthorisedly absent from duty during the last
five years prior to the date of Non-Functional iJp-gradation, he/she m6}
t.
granted Non-Functiona-l Up-gradation tili a decision regarding regular
izatton"ot
of
the
period of unauthorized absence is taken. The details of slch ca-ses
iray ue reported to
this Ministry.

1' For implementation of these orders (including attendant benefits/payfixation, etc.), the Units are tequested to ensure that the officers are clear
vigilance angle, including the currency period of penalty, if any, asfrom
instructions issued by the Dopr from time to time foi the purposeper
of
l-tot9_tioT/up-gradation. Vigilance clearancefstatus, as and whei conveyed by
the CVo / Vigilance Division of the Ministry of Health & Famity Welfare,
need be
considered for this purpose.
5'

A copy of this order may be made available to the ofjicers concerned.

i

Under Secretary to the Govt. of Ihdia
Tel:2306 1875
To,

30 ?67/?.1/ The Establishment officer, Dopr, North Biock with reference to oM
2,

J.
A

't.

No.AB. 14A17 / 6412008-Estt. (RR) dated Ot.OZ ,2Arc
Director General of Health serrzices, Nirman Bharvan, *.* r.rht.
-Director, Admin. (HQ), DGHS, Nirman Bhawan, Ne,,v behi.
Director (CGHS), Dte. Genera-l of,cGHS, r\irman Bharvan, r\ew Delhi.

cl(

/3{q € 64ry,ln

I

<!-- page 2 -->

A li::xur:e
.-__.-'--.---:

Name of the Officer
Dr. N.C. Das
2.
Dr. Arvind Thergaonkar
3.
Dr. Anbazagan C.
Dr. Mangi Lal Rathod
Dr. Rakesh Kumar Gupta
5.
6.
Dr.{Mrs) Nirmal Baliea
7.
Dr. lMrs) Bina R. Sarvhney
Dr. (Mrs) Nutan Mehta
Dr. Prahlad Ranian Biswas
9.
10.
Dr. Dilip D. Tikas
11.
Dr. Devendra Singh
Dr. (Mrs) Sudha Sethi
12.
i3.
Dr. Anil P. Dhoke
Dr. (Mrsl Sarita Punia
14.
Dr. Rai Kuma-r Asganval
15.
16.
Dr. A.K. Sikdar
Dr. Naresh Goel
17.
Dr. Ramchandra G, Kathale
18.
Dr. Viiav K. Jharia
19.
20.
Dr. Itishna E. Gonnade |
2t.
Dr. Hemant M. Nimie
22.
Dr. Kashinath G. Kuhikar
Dr. S.K. Sikdar
Dr. Dioak Kuma-r Biswas
25.
Dr. (Mrs) Sarita Dhavra;i
26.
Dr. (Mrs) Roshini Arthur
27.
Dr. Shailendra Khare
28.
Dr. Sanieev Bhalla
29.
Dr. G.M Ramanna
30. I Dr. Aiav Kumar Goila
il.
I Dr. Devesh Gupta
32. 'l Dr. Mukesh Cheliali
a?
Dr. Anurag Jain
Dr. Suman Kathuria
34.
Dr. (Mrs) Punam Kapoor
35.
Dr. Satya Pal Singh
36.
Dr. S. Lakshmi Naraya:ra
37.
Dr. Yashwant Sinsh
38.
Dr. Mohan Lal
39.
Dr. {Mrs) M. Revathy
+0,
+1.
Dr. lMrs) D. Swarna Kumari
Dr. lMrs) Rumi. Devi
+2.
Dr. Deben Chaldra Deori
+3.
+4,
Dr. Paban Kumar Das
45.
Dr. Saliib Chaldra Das
Dr. Ram Dayal Maduli
+6.
Dr. Chardra Pra-kash
+7.
Dr. K.S. Rana
+9.
Dr. (Ms) Leeia B. Pendam
S. No.
1

Date of Birth
01.04.1950
26.03.1953
06.09.1952

NFU IiIAG) w.e.i,
07.10.2008
03.12.2409
03.12.2009
26.10.2010
07.08.2012

01.09. 195 I

14.07.1956
04.08.1957
20.08.1958
25.Qt.1957
02.01.1956
26.08.1956
10.06,1958
13.07 .1957

07.08.20t2
02.07.20t3
02.07.2013

02.o7.2At3
02.o7 .2013

02.07.2013
02,07 .20t3
02.07 .20!3

07.06.t956
15.11.1953

02.07.2013

06.05.19s7
01.01.1959
31.08.1956

29.07 .2015
29 ,07 .2015
29.07 .2015
29.07 .20t5

18.06.1956
t6.07 .1959

29.O7.2415

27.08.L936
15.07.1956

29.07 .2015
29.07 .2015

03.11.1955 I

29.07.2015

27.04.1958
27.08.1957

29 .07 ,2015
29.07 .20t5

17 .t0.1956

14.07 .2016
14.07 .2016

t7 .04,1960

26.t0.1957

14.O7.2016

30.07 .1957

14.07.2016

i. 1 i, i958

14.07 .2016

02.04.1957
08.02.1957

t4.07 .20t6
t4,07 .2A16
14.07.2016

1

12.03.L957

22.A6.1958
14.11.1956

t4.07.2016
r+,47.2015

I
I

13.09.1958

14.07 .20t6

20.0t.1960

t+.07.2016

03.04.1959
05.03.1959

1.4.07 .2016

I

14.07 .2016

i

2r.02.1958
21.07.1961

14.07.2016
14.07.2016
14.07 .2016
t4.07 .2016
14.07.2416
14.07.2016
14.07.2016

16,05, t 958

10.02.).957

04.06.1958
26.06.1958
01.10.1957

.

16.09. i958

14.07.201.6

28.01.1958

t4.07.2016

2A.05.t960
06.08,1958

14.07 .2016

14.07.2016

I

I

i

"l

I
I

I
I

I
i
I

l

I
I
I

il
I

!
rl
