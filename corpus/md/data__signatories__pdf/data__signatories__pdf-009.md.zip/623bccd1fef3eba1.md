---
doc_id: "623bccd1fef3eba1"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/d8124270f46eb0259be5264f88dab4d9.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Corrigendum for filling up of one post of senior advisor"
date: "2024-01-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "37b888723c166a08"
---

<!-- page 1 -->

A-12039 / 04 / 2022-Estt.ilt
I

/12453 / 2024
N o.A- 1 2039 I 04 12022- Estt. I I I

Government of lndia
Ministry of Science and Technology
Department of Science and Technology
Technology Bhavan,
New Mehrauli Road,

NewDelhi-110016.
Dated: 18-01-2024
CORRIGENDUM

Subiect: Filling up of '01' (One) post of Senior Adviser in the Department of
Science & Technology on deputation (including short-term contract) basis- reg.

Reference: Advertisement No. DST/06/2023-Estt.lll

With reference to the Advertisement No. DST/06/2023-Estt.lll published in
Web
Advertisement Section of the Employment News website on 05 January,
the
2024, Employment News dated 13-19 January, 2024, and detailed advertisement
of the same number published on this Department's website, the following
amendments are made in the last sentence of para-S of the advertisement:
For

Read

AGE LIMIT: Upper age limit shall not AGE LIMIT: The maximum age-limit for
exceed 58 years as on the closing date appointment by deputation (including
for receipt of applications.
short-term contract) shall be fifty-eighl
years.

NOTE: The crucial date for determining
eligibllity will be the date on which the

vacancy is expected to arise i.e.
01.06.2024.

(Vinod Kuhilar Sharma)
Under Secretary to Government of lndia
Tel: 01 1 -2659051 5
recruitmentcell.dst@gov. in
To:

Recruitment Cellwebpage of DST Website/ Employment News

<!-- page 2 -->

v-1 2039/0 4t2022-T{rt{ar. I I I

TIt{iT Uf'fiIT

funrd sik ffiffit
ffrilrd 3itr ffiffi

drwq
F{firrr

tq+aYfr srq;r
rqr qatlfr Fnf
a€ kd -110016

,

,

fraiq-: 18.01 .2024
qrafuqil

frsq : furr+ :+fr @ffir
Barra fr dl{s6 q6rifi11 +' '01' (('fi) qq
+t qFG:qFd (:ravraB €ffir HFO 3nrrr w art fl-i +'+ie.tr fr
I

dEat : kflrqfl €EqT ffir/06/2023-€qT.ilt

Ffrr+' 13-19 ffiT{t, 2024 + ffrrr Tr#nqm fr tffrr Hqrdr aqsrTc * nil
kflrrf, EiE fr os r++ft,2024 6) eq.rf,eId BfrrErdT d-€qr ffiloot2o23-T'ax.ilt 3lk
g-S fuan r 6t n{srFc w qqrf,ela sad&Tfi fufrrrf, + Bflur * Fqe+ it, frxrfrfua
sefrtrfr fs k;nqa * +{r s * 3ifra dr+q fr fuqr arar t :-

ffifua
lry *", : 3;v-ft ry S-ar srnfi * qT'a
iotA

fiqr:rya

(:revr+fr

qT;rf,r freffrd +,ri

fr ftqtTfi

sfeO 3rretrq q fraBa
3rfu'ficrff ry fiar 5s E{'dzfrr

a sftn ftlt a-o s8 qq t 3TE6

lotfr

tr6r .rilTq

r

T6 drfr Bs Ftu 6t nGa d-dr

&n :+efa 01.06.2024t

W,

1Fafra g;Tr{ arqt)

3rq:r Tfuq, firttr :st?Ftlr
tfr:O1 1-2659Os15
re c ru itm e n tce ll-d st@ g ov. in

+{r fr,

ffi

aq_flrilc

* s1ff (rc5-s-Nf,/d.frqr Hfrt=rr{
