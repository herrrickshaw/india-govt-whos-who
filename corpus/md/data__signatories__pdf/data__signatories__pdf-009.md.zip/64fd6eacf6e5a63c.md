---
doc_id: "64fd6eacf6e5a63c"
source_url: "https://doj.gov.in/static/uploads/2025/11/ca5c5afc4239bbfc607021701c8dab64.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of transfer of Shri Justice Subhendu Samanta, Judge of the Calcutta High Court to Andhra Pradesh High Court (14.10.2025)"
date: "2025-10-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a0e9aa1664c576bb"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K. 11017112/2025-US.I/II
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-1 10 OIl.
Dated 14th October, 2025.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 222 of the
Constitution of India, the President, after consultation with the Chief Justice of
India, is pleased to transfer Shri Justice Subhendu Samanta, Judge, Calcutta High
Court, to be a Judge of Andhra Pradesh High Court and to direct him to assume
charge of his office in the Andhra Pradesh High Court.

1

I ~ 11611--5
(Jagannat
Srinivasan)
Joint Secretary to the Government of India
Tele: 2338 3037
To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

- 2-

No. K-11017112/2025-US.I/II

Dated: 14.10.2025.

Copy to:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.

Shri Justice Subhendu Samanta, Judge, Calcutta High Court through the
Registrar General, Calcutta High Court, Ko1kata.
The Secretary to Governor, Andhra Pradesh, Amaravati.
The Secretary to Governor, West Bengal, Kolkata.
The Secretary to Chief Minister, Andhra Pradesh, Amaravati.
The Secretary to Chief Minister, West Bengal, Kolkata.
The Secretary to the Chief Justice, Andhra Pradesh High Court,
Amaravati.
The Secretary to the Chief Justice, Calcutta High Court, Kolkata.
The Chief Secretary, Government of Andhra Pradesh, Amaravati.
The Chief Secretary, Government of West Bengal, Kolkata.
The Registrar General, Andhra Pradesh High Court, Amaravati.
The Registrar General, Calcutta High Court, Kolkata.
The Accountant General, Andhra Pradesh, Amaravati.
The Accountant General, West Bengal, Kolkata.
The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.
PS to the Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
Registrar (Conf.), 010 the Chief Justice of India, Room Nos. GF 1, 2
and 3, Ground Floor, Supreme Court Main Building, New Delhi.
PS to the MoS (I/C) L&J I PPS to the Secretary (Justice).
Sr. Technical Director, NIC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doj.gov.in).
