---
doc_id: "65bfb5ce0a59e3aa"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/ceaaba53f499bebe1e0507d904ce163b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "32 2019_04_16 HoD ESTT"
date: "2019-04-12"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "240812cbf195315b"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY
Hkkx I—[k.M 1
PART I—Section 1
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY
la- 120]

ubZ fnYyh] 'kqØokj] vizSy 12] 2019@pS=k 22] 1941

No. 120]

NEW DELHI, FRIDAY, APRIL 12, 2019/CHAITRA 22, 1941

संचार मंालय
(दूरसंचार िवभाग)
िवभाग)

(थापना कंध)

अिधसूचना

नई दली, 12 अ ल
ै , 2019
िवषय:
िवषय:

दूरसंचार िवभाग क ेीय इकाइय म ‘िवभाग के मुख’ क घोषणा करना ।
"था.—िवभाग के मुख क अिधसूचना, अिधसूचना सं. 1-50(13)/2017-था., दनांक

फा.
फा. सं. 1-50(13)/201750(13)/2017-

06/11/2017 एवं 07/06/2018 'ारा जारी कया गया है।

2.

2 को व1र2 उप-महािनदेशक (रा3ीय संचार सुर4ा क56) को िवभाग
‘…LSAs/ TEC/ NTIPRIT...’ को
‘…LSAs/ TEC/ NTIPRIT/ NCCS…’ से बदला जाता है।

के

3.

दनांक 06/11/2017 क उ. अिधसूचना के पैरा

मुख के 8प म5 शािमल करने के िलए संशोिधत कया गया है। इसिलए, इन श<द

ये राजप= म5

काशन क तारीख को

वृत होगी

|
एस. के . जैन, उप महािनदेशक (थापना)

%ट'पण: दूरसंचार िवभाग क 4े=ीय इकाइय म5 ‘िवभाग के मुख’ क घोषणा भारत के राजप=, असाधारण, भाग I, खंड 1,
म5

:

कािशत क गई थी

(क)

अिधसूचना संDया

287 दनांक 07/11/2017.

(ख)

अिधसूचना संDया

203 दनांक 08/06/2018.

2137 GI/2019

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)
(ESTABLISHMENT WING)
NOTIFICATION
New Delhi, the 12th April, 2019
Subject: Declaration of Head of Department in the Field Units of Department of Telecommunications
F. No. 1-50(13)/2017-Estt.—Heads of Department in the Field Units of Department of
Telecommunications were notified vide No. 1-50(13)/2017-Estt. dated 06/11/2017 and 07/06/2018.
2. Para 2 of the said notification dated 06/11/2017 has been amended to include Sr DDG ( National Centre
for Communication Security) as Head of Department. Hence, the words ‘…LSAs/ TEC/ NTIPRIT...’ stand
replaced with ‘…LSAs/ TEC/ NTIPRIT/ NCCS…’.
3.

It shall come into effect from the date of its publication in the Official Gazette.
S. K. JAIN, Dy. Director General (Establishment)

Note : The Declaration of Head of Department in the Field Units of Department of Telecommunications were
published in the Gazette of India, Extraordinary, Part I, Section 1:
(i) Notification number 287 dated 07/11/2017.
(ii) Notification number 203 dated 08/06/2018.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by

MANOJ KUMAR MANOJ KUMAR VERMA
Date: 2019.04.12
VERMA
22:27:58 +05'30'
