---
doc_id: "625cbbcd374ad8ac"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/5f1b8904667cc79d67e36bf1ec3c3896.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "IDS 2017-CCIIAC-SIIDCUL-sanction letter dt.26.03.2025-Rs.375115096/-"
date: "2025-07-14"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6d42ce92be4ce6f0"
---

<!-- page 1 -->

No. 3(2)/2021-SSS (E-55244)
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade
(Special Scheme Section)
Udyog Bhawan, New Delhi
Dated: 2601 March, 2025
To
The Accounts Officer,
Pay & Accounts Office,
Department for Promotion of Industry & Internal Trade,
Udyog Bhawan, New Delhi.

Sub:

Release of an amount of Rs. 37,51,15,096/- (Thirty Seven Crore Fifty One

Lakh Fifteen Thousand and Ninety Six only) as Central Capital Investment
Incentive for access to credit (CCIIAC) Subsidy during the year, 2024H25 in favour
of SIIDCUL-reg.
Sir

The undersigned is directed to convey sanction of the President for release of an
amount of Rs. 37,51,15,096/- (Thirty Seven Crore Fifty One Lakh Fifteen Thousand
and Ninety Six only) for payment of Central Capital Investment Incentive for Access to
Credit (CCIIAC) under Industrial Development Scheme (IDS) 2017 for the financial year
2024-25 in respect of 17 eligible beneficiary units of Uttarakhand (as per list enclosed at
Annexure), on the basis of recommendations of the State Level Committee concerned
and as per existing terms and conditions of the scheme.
2.

As per the Notification No.2(2)/2018-SPS dated 23rd April,2018, SIIDCUL has
been notified as the nodal agency for disbursal of central incentives in the state of
Uttarakhand under IDS, 2017.

3.

Vide mail dated 10.09.2024, SIIDCUL informed that no unspent amount is

pending for disbursement under the IDS, 2017.

4.

The sanctioned amount may be released in favour of State Infrastructure &

Industrial Development Corporation of Uttarakhand Ltd.(SIIDCUL), Dehradun to their
Bank Account No.705020110000513, Name of Account SIIDCUL (IDS), Bank of India,
Main Branch, Dehradun MICR Code: 248013002. IFSC/RTGS Code BKIDOO07050.
5. The due date for submission of UC in respect of this release is within twelve months
of the closure of the financial year.
6. This is the Sixth release for Uttarakhand during the current year as Central Capital
Investment Incentive for access to credit (CCIIAC) under Industrial Development Scheme
(IDS) 2017. The total release under this object Head, including the present sanction
would be of Rs.297,55,11,930/- during the current financial year 2024-25 as against the
Revised Budget of Rs. 401.39 Cr.

<!-- page 2 -->

7. The sanction is noted at SI. No.19 in the expenditure control register for the FY 202425
8.

The expenditure is debit to the following Head of Account:2885 Other Outlay on Industries & Minerals (Major Head)
02
Development of Backward Areas (Sub Major Head)
02.101 Subsidies (Minor Head)
18.01 Industrial Development Scheme for the States of Himachal Pradesh
and Uttarakhand, 2017
18.01.33
Subsidies
Under Demand No.11 for the year, 2024-25.

9.
Release of the above-mentioned amount to SIIDCUL is subject to the following
terms and conditions:

i.

SIIDCUL will maintain a separate account of the funds released by this
Department towards “Central Capital Investment Incentive for access to credit
(CCIIAC) under Industrial Development Scheme (IDS) 2017" for disbursal of
subsidy to the beneficiary units as per details enclosed.
SIIDCUL shall verify each & every claim before disbursement and shall disburse
the incentive to the eligible units immediately on receipt funds from DPlIT.

iii.

The expenditure incurred shall be open to inspection by the sanctioning
authority/CAG/Internal Audit Party of the Chief Controller of Account, Ministry of
Commerce & Industry, Department for Promotion of Industry & Internal Trade.

iv.

After disbursement of incentive for the purpose for which it has been sanctioned,
SIIDCUL, shall submit to the Department for Promotion of Industry & Internal
Trade, New Delhi the Utilization certificate within twelve months of the closure of
the financial year as per GFFI,2017 and no further funds will be released unless
the entire amount previously released is fully utilized and utilization certificates are
furnished. The Utilization Certificate will be signed by the Managing Director,
SIIDCUL

V.

A quarterly statement of the subsidies disbursed indicating also the names of the
beneficiaries, the amount of subsidy released to each unit, the date of their
application, the date of approval of the SLC, the date of disbursal of subsidy etc.
shall be furnished by SIIDCUL to this Department by the 10th day of the month
following the end of each quarter.

vi.

SIIDCUL would devise a suitable mechanism to ensure adequate transparency
and fairness in the disbursal of subsidy. SIIDCUL shall furnish an undertaking that
they have been following the provision of Ruled (1)(a) and (b) of RTI Act, 2005.

vii.

SIIDCUL would furnish a performance-cum-achievement report at the end of each
financial year highlighting the number of units set up in the State, investment
made and the employment generated etc., and the quantitative vis-a-vis
qualitative outcome achieved out of Central Capital Investment Incentive for
access to credit (CCIIAC) under Industrial Development Scheme (IDS) 2017
Scheme including suggestions/policy reforMiM9s
for further refinement of the

c eme'

..’ :.

B+M

atFr,T :geT,; ii
C

l

in

<!-- page 3 -->

Viii.

SIIDCUL to ensure that amount is released to individual unit(s) only after verifying
that these units have not been paid earlier.

ix.

SIIDCUL to ensure that payment to beneficiaries units should be made through
PFMS directly to their account within 10 days from receipt of funds from DPlIT.
The undersigned will act as DDO for purpose of this sanction.

10.
11 .

This issues with the concurrence of AS&FA vide Note#322 dated 25.03.2025, File
no. 3(2)/2021-SSS (E-55244)

Yours faithfully,

(Manbir Singh)

P;:MgFg
::jai;I?feI
:;;01: ;T
!?Bi
1
1
i:;" ;:.'E;fhgil:.$$s.-dpiit@gov.in

Copy to:1. The Principal Director of Audit, Economic and Services Ministries, A.G.C.R.
Building, Indraprastha Estate, New Delhi.
2.

Director of Industries, Directorate of Industries, Govt. of Uttarakhand.

3. Finance-II Section, Integrated Finance Wing, Department for Promotion of
Industry & Internal Trade.
4. CCA, DPlIT-with the request to audit 10% cases after disbursement by SIIDCUL.

5. The Managing Director, SIIDCUL
6. Budget & Accounts Section, DPlIT

<!-- page 4 -->

Annexure
No.3{2)/2021-SSS (E.55244)

List of 17 Units

bmount
S 1•N o :adnS :t ::

1u n it

IIDS Registration
INo. and date

:;:::T:*g::::::L'=:==:
Kin Rs.)

Ec
1

Dated 13.12.2024

Mor
1 ,33,72,5161

1 ,13,21 ,134

IIDS/UK/2020/744
!dated 29-09-2020

38,38,6951

38,03,597

IIDS/UK/2019/0021
Idated 27-02-2019

37, 32,6581

37, 32,658

52,58,141

50,66,141

5.00,00,0001

5,00,00,000

IIDS/UK/2020/338
lated 13-01-2020

1 ,01 , 15,5871

99,00,087

M/s Balaji Action IIDS/UK/2019/222
IBuildwell
Idated 06-1 1-2019

5,00,00,0001

5,00,00,000

5,oo,oo,0001

5,00,00.000

IStone Crusher Idated 22-12-2023

ms

12 IPrecision
jproducts
Ec

Dated 13.02.2025
s

13

IPrintopack Pvt.
ILtd .*

ms r
Rubber products ldated 29-08-2019
ms
15
I

IFlexipack Limited ldated 27-02-2019

ms
16

17

,utc)mobile

Itndustries
Limited

s

18

IIDS/UK/201 9/812
Idated 30-08-2019

jcorporation
ILimited

I

)

V

;) ; : .t:1.
! in•:+: =

If \'i

:: :i

= =' J, i
ieP

W • rH

e

<!-- page 5 -->

19

83, 56,891

83,56,891

65 ,36, 9791

65,36,979

59,91 ,3881

59,91 ,388

IIDS/UK/2021 /1234
lated 26-03-2021

2,56,41 , 1921

2,56,41 , 192

Idated 18-12-2020

4,34,26,4201

4,29, 1 3,420

2,79, 17, 3621

2,79, 17,362

73,18.6851

73, 18,685

IControl Pvt. Ltd. hated 22-12-2023

5,oo,oo,0001

5.00,00,000

'

1 ,66,74,7521

1 ,66, 15,562

M1/ s R K P 1W o o d ::f::

ms
1lo

!Polyplast Pvt.
ILtd.

11

13

IIDS/UK/201 9/o033
Idated 18-03-2019

s

I

IMetals

Idated 29-09-2020

Fs
12

1:: ? 1 ?{ 1: b

IPsychotropics
Itndia Limited

ms r
llndia Pvt. Ltd.

ms
14

}Shardanand

IIDS/UK/2023/1531

IFood Processing Idated 28-12-2023
kPrivate Limited
15

16

17

s

I

llnternational

Idated 28-12-2023

ms s
Limited

Hi?A

'otal

3

*SlIDCUL is requested to release
submission of a valid Pollution Control Certificate (PCC) .

<=

=:?::W§Pl-:;I..:!!:.
nTh.jT ljl IT;. q'::

37,51 ,15,096
