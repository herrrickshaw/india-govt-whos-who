---
doc_id: "625a3cdefa38aef9"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/Notification%2520Doraiswamy%252C%2520MD.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Notification%20Doraiswamy%2C%20MD.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f7bb9f16a6b82c4f"
---

<!-- page 1 -->

tTo BE PUBUSHED rN TFtr, GAZETTE OF rNDr& PART II, SECTION 3, SLIBSECTION (01
Government of India
Ministry of Finance
(Department of Financial Services)
New Delhi

lqAug*t,

zozl

NOTIFICATION

O.

In exercise of the powers conferred by seaion 4 of the life Insurance C-orporation of
India Acg 1956 Al of llSO),the Gntral Govemrnent herebyappoints Shri R Doraiswamy (date of
binh: 29.08 .1966) Executive Director, (ITISD) Li[e Insurance C-oryontio" (I-Iq of India, Crntral
Office, Mumbai as Adanaging Director, LIC of India, in the payscale of Rs. 2,05,400/- to Rs.
2,24,400/ - dcelyk.Ipe Mini with effect from the date of assumption of charge of office on or after
1.9.2023 and upto the date of his superannr:ation (i.e. 31..08.2026), or until further orders,
S.

whichever is eariier.
(F. No. A- 1 10 1 1/0 a / 2023-Ins.I)

\,

h^P

fiinodKurnar)
Under Secrearyto the Goverunent of India

<!-- page 2 -->

tr+rm

* rrcr{ rrrr-n, Gis 3, sc-Eis liiy ii s-wvnreil
qlfdgfsR

fuf,qTrdq

ffiqfuftrrFr
+$ftc'd,r,{}T'rs, zoz:
3TRq-d{r

6r.3{T. qrcdqfr-fimqrftrq}TErfrqq, 1956 (l956sr:t;ff enu+aras-{f,yrffit

ffi

*

or vfr,r *.til gu, t=fu sc*n, qd1gr{r, g* sTriE fi-fr * *Brr+ c{ e{r
tsq
-q
qrte,qs-eri,
lrffi +fi frcr fo m f f-o+ni$), +Ffl q
ft FI : 2 9. 8. I 9 6 o l, andqre-+ fi kr* f
flsieq, gef 6] fr{is 1.9.202: +} qi sst csrd q-< +r *idrnr reor *d fi dftq
gTPntr-drffdrfte. lerula:r.s.zol6) d-s s+pr+r srrr-d sTraTiiirm, S mc-{4fr, 2,05,400

t

wq t z, z +, + oo wq * +fr{qrq t qR-frq

fifi frqr ft rc ii lrTtl fr kr+ *

q-< c{ fi Tm

s.rfr

tr
$r.{i. q- t g 1 79a72923-frcr-r;
1

1

@>
6ffigen;

erfisfud, qrrdqrsn
