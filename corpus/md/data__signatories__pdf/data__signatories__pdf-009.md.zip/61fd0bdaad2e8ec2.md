---
doc_id: "61fd0bdaad2e8ec2"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/915e97e55c8255ecc2d8b3992f310bc9.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "DoE OM dated 27.06.2024 for Exemption of Railways critical item for train operation under GTE"
date: "2025-07-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9e3c9fac58c8f2e1"
---

<!-- page 1 -->

No.F.4/1/2024-PPD
Government of India
Ministry of Finance
Department of Expenditure
Procurement Policy Division
*****

OFFICE MEMORANDUM
Subject: -

515, Lok Nayak Bhavan,
Khan Market, New Delhi,
27.06.2024

Relaxation under Rule 161(iv) of General Financial Rules 2017 for
issuance of Global Tender Enquiry (GTE) by Ministry of Railways.

The undersigned is directed to refer Ministry of Railways (MoR) 0.0. No.
2020/RS(L)/779/1 dated 10.06.2024 regarding issuance of GTE under Rule 161(iv}
of GFRs, 2017.
2.
The request of MoR has been examined and it has been decided to delegate
powers to approve issuance of GTEs for the tenders having estimated value of less
than Rs 200 crore to the concerned Members of the Railway Board/ Chairman of the
Railway Board only with respect to procurement of Safety items and for the
procurement of items, which are critical for train operations.

3.

This issues with the approval of Finance Secretary.
(SherBahadur)
Under Secretary (Procurement Policy)
Tel. No. 24621304
Email: sher.bahadur@nic.in

To,
Railway Board,
{Kind attention: Ms. Jaya Varma Sinha, Chairman}
Ministry of Railways,
New Delhi.
Tel.: 23384010,
email: crb@rb.railnet.gov.in
Copy to:
Secretary (Coordination), Cabinet Secretariat, Rashtrapati Bhawan, New Delhi.
