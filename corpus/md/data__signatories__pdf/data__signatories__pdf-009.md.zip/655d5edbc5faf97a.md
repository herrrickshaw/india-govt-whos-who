---
doc_id: "655d5edbc5faf97a"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/4d018ac74c2a109f068629363f37b1c0.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Shri Pankaj Kumar Sinha, Under Secretary is assigned the charge of Admin l and Cash Section with immediate effect and until further orders."
date: "2025-06-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e70786c6fea91bad"
---

<!-- page 1 -->

No. A-1 901 1 /1 1 t2024'Admin-1 lE-29259)

Government of lndia
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Animal Husbandry and Dairying
Krishi Bhawan, New Delhi-1 10001 .
15th JulY,2o24
Dated,

the

o FFICE ORDER
ConsequentuponhispostinginthisDepartmentvideDepartmentofPersonnel
relieving vide
& Training Oider No. S1O12O24-CS.l(U) dated 28.06.2024 andKumar
Sinha is
Departmerit of Commerce's office order dated 11.07.2024, Shri Pankaj
of
forenoon
rrerJy taren on the rolls of this Department as Under Secretary w.e.f. the
12.07.2024 in the Level-1 1 (Rs. 67700-208700).

Shri Pankaj Kumar Sinha, Under Secreiary is assigned the charge of Admin'l
and Cash Section with immediate effect and until further orders'

2.

This issues with the approval of the Competent Authority'

u4ft_,i{
(Vikash Kumar VikrosY)
Under Secretary to the Government of lndia
Tele 011-23382779

Distribution:

1. Shri Pankaj Kumar Sinha, Under Secretary

z. in" unO"r'Secretary (rsit.tt), Departmeni of Commerce' Room No' 229 C Wing'
NirmanBhawan,NewDelhi-witharequestthatLPCandservicebookofShriat
punklj Xr.ur- Sinhu, Und"r" Secretary may be forwarded to this Department
the earliest.

Floor,

2nd
3.
- The Under secretary (cs.l(u)), Department of Personnel and Training,
No. 511012024-

order

r_ot N"vrx Brrawan, Khan rvriix"t, itew Delhi-1'10003 w.r.t.
CS. l(U) dated 28.06.2024'
4. ihe bAO (Secft.l), D/o Animal Husbandry and Dairying, Krishi Bhawan'
5. SO (Cash)/DDO, D/o AH&D
6. US(NLMYUS(C&DDYUS(AOCSYUS(LH), DAHD ..

7. c"n"rrrAinoinrutrncii"rtiamlnuianrigitance/APAR Section, DAHD, Krishi
Bhawan.
8. Service Book/Personal File/Guard File'
