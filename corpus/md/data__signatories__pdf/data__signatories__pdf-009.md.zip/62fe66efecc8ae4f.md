---
doc_id: "62fe66efecc8ae4f"
source_url: "https://moef.gov.in/uploads/pdf-uploads/pdf_68bea54aca4839.04646880.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order Shri Anjan Kumar Mohanty, IFS(SK 1992) presently working as ADGF, MoEFCC, New Delhi under CSS-MoEFCC is hereby allowed to prematurely repatriate to his parent cadre"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "3973d7296392f96d"
---

<!-- page 1 -->

i
|
on /oa/zozeirs-1are) मन |
Computer No: 238313
No. 1901 1/03/2024-IFS-I(Part) :
Government of India
Ministry of Environment, Forest and Climate Change
6 Floor, Prithvi Wing,
Indira Paryavaran Bhawan, Jor Bagh Road,
Ali Ganj, New Delhi-110003. i
Dated they June, 2025
|
With the approval of thecompetent authority, Shri Anjan Kumar Mohanty, |
IFS(SK:1992) presently working as ADGF, MoEFCC, New Delhi under CSS- |
MoEFCC is hereby allowed to prematurely repatriate to his parent cadrei.e. Sikkim |
cadre in accordance with para 14.9 of Central Staffing Scheme of this Ministry |
issued vide OM No.A-12011/1/2013-IFS.1 dated 06.05.2011. |
2. Shri Anjan Kumar Mohanty, IFS(SK:1992), therefore, stands relieved from ५ i
his duties w.e.f. 30.06.2025 with request to report to his parent cadre. ye _ i
yey i
me 0% ws ।
(रे Noy a ot i
we
(Prem P Maurya) i
Under Secretary to the Govt. of India !
Ph - 011-20819192 :
Distribution: :
i. PS to Hon'ble Minister of E,F& CC. :
ii. PS to Hon’ble MoS (E,F&CC). 1
iii, PPS to Secretary, M/o EF & CC. i
iv. PPS to DGF & SS/ All ADGFs/ All AS/ All IGFs/All JS. i
v. The Chief Secretary, Government of Sikkim, Gangtok. E

vi. The PCCF & HoFF, Government of Sikkim, Gangtok. i
vii. Shri Anjan Kumar Mohanty, IFS(SK:1992), ADGF, MoEFCC, New Delhi.

viii. JS (Admin), MoEFCC, New Delhi. §
ix. DDO (Cash), MoEFCC, New Delhi. |
x, PAO, MoEFCC, New Delhi. :

Ai. NIC for uploading in the IFS website and IT Gell for uploading for Ministry's ३

Website. :

xii. Guard File /Personal File/Spare Copies. ;
