---
doc_id: "61ac003bfccc8ca2"
source_url: "https://mohua.gov.in/static/uploads/2025/10/cbf6a394f69db6acdcd7e78350533b8d.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "The Requisitioning and Acquisition of Immovable property Rules"
date: "2025-10-14"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "af78642c3c48381d"
---

<!-- page 1 -->

-

THE REQUISITIONING AND ACQUISITION OF
IMMOVABLE PROPERTYRULES, !9531
In exerciseof the_?o?ersconferredby section22 of the Requisitioningand
Acquisitionof ImmoaablePropertyAct, Lg52 GA of LgS2i, the Ceniral Gouer\tment
herebymakesthefollowing rules,aiz:1. Short title.-These rules may be called the Requisitioningand Acquisition
of Immovable Properfi Rules, 1953.
2. Definitions.-In theserules(a) "Act" means the Requisitioning
- and Acquisition of Immovable
'
Properry Act, I9S2 (30 bf I9S2).
2[(aa) "Cortrt" means a principal Civil Court
of original jurisdiction in the
district in which the property requisitioned oi acquired is situated;l
(b) "Form" means a Form appended to these rules;
(c) "seetion" "sub-section"mean respectivelya sectionor sub-sectionof
the Act.
3. Frocedureto be followed by competentauthority for pu{posesof section
3(1).-A notice under clause (a) of sub-section(t) and brder-under clause (b) of
sub-section(1) of section 3 of the Act shall be in Form ,A,.
4. Order of requisitioning.-The order of requisition under sub-section(2) of
section3 of the ,A.ctand the notice under sub-section(1) of section 4 of the Act
shall be issued in Form 'E'.
_ 5. Breaking oPen of locks on requisitioned property.-Where the possession
of a requisitioned property is not handed over in compliance with^.an order
issued under sub-section(1) of section4 of the Act and the premises are found
1o*9d:4" -.9*petent authority or any other person authorGed by it in writing
in this behalf may break open the lock in the presenceof two wibressesand tak[
possessionof the property:
Provided that(i) before_any-suchaction is taken the competentauthority shall satisfy
itself that the order under sub-section(1) of section4 has been dulv
served- on thg- p-utty concerned and that the parry is evading
compliance with the order;
(ii) the powers under this rule shall not be exercisedat any time after
sunset or before sunrise; and
(iii) where
is taken in pursuance of the powers conferred by
_possession
this rule, an inventory of the articles found in the premises shall be
made in the pt"sen.b of two wiuressbsand such articles shall be
stored in safe custody.
6. Replirs to requisitioned premises.-A notice under sub-sectionQ) ot
section5 of the Act shall be in Form 'F'. The time for execution of repairs to be
specified in the notice shall be such as the competent authority may deem
1. Vide 5.R.O.948, dated 18th May, 1.953,published in *re Gazette of India L953,Pt. il, Sec.3, p.
733.
Ins. by c.S.R. 654, dated 23rd July, 1958.

<!-- page 2 -->

18

PropertyRutes,1953
of tmmovable
andAcquisition
The Requisitioning

[Rule6

reasonablehaving regard to the nafure of repairs and other circumstancesof the
case.
7. Procedureto be followed in releasing the property.-(1) For the purPose
of sub-section (2) of section 6 of the Act the competent authority may, if it
considers it necessary so to do, make or cause to be made by * officer
empowered in this behatlby it, an enquiry to obtain information in respectof the
following matters, namely:(i) the name and address of the person from whom the property was
requisitioned;
,
(iil the name and addressof the person in possessionof the property at
the time the property was requisitioned;
(iii) the name of the person who has been receiving compensation;
(iv) whether any alternative acconunodation was provided to the
occupant when the property was requisitioned or whether any
compensationwas paid to him for vacating the property or whether
the occupants,if any, relinquished their claims for re-occupation of
the property;
(") whether the occupantwas abonafidetenant of the property or was an
unauthorised occupantor has no claim in law for the restitution of the
properFy;
(ri) whether the owner of the property on whom the requisitioning order
was first served, had sold the properfy and if so to whom;
(vii) in case the properly has been sold whether the owner has sold all
rights in respectof the propertY;
(viii) whether there is any objectionto the property being de-requisitioned
in favour of the owner from whom the property was requisitioned;
(ix) the state of repairs of properf at the time of enquiry;
(x) whether any strucfure or articles belonging to Government have been
erected or installed in the property and their value;
(xi) the condition of the property at the time of requisition and whether
the property is in as good a condition as it was when possession
thereof was taken subjectto changecausedby reasonablewear and
tear or irresistible force;
(xii) the estimated cost of restoration;and
(xiii) any other matter that the competent authority may consider
necessary for the purpose sf specifying the Person to whom
possessionof the property may be given.
(2) Beforeissuing an order of releaseunder sub-section(1) of section6 of the
Act, the authority to whorn the powers of the Central Govemment have been
delegatedfor this purpose, shall obtain the approval of the Central Government
in the administrative ministry concemed.
'G'.
(3) An order under sub-section(2) of section 6 shall be issued in Form
(4),A notice under sub-section(a) of section 6 shall be in Form 'FI'.
.
8. Acquisition of requisitioned property.-A noticeunder sub-section(1) of
section 7 of the Act calling upon the owner or any other person interested in a

<!-- page 3 -->

-

Rule 9l

I

The Requisitioningand Acquisitionof lmmovablepropetty Rules, lgsS

,

19

requisitioned property to
*o* causewhy the property should be acquired,shall
be in Form 'r'. A notice of
actual acquisitions'halibe'in Form,J,.
9. Compensation.-(1) An authority to whom the powers of the Central
Govemment have be_en
delegatedshall, is far as may be, associatewith itself the
local officer of the Cenfral Govemment concemed'with the properfy in fixing
compensationunder clause (a) of sub-section(1) of sectionb, ir,a oUt"in tf,!
of the Central Govemment in the administrative ministry.or,..*ud
lPProval
1[or of any officer authorised
by that Govemment in this behalf.]
(2) Compensationfor requisitioned property, other than agricuhural land,
shall g. pqig by
Fu competent authorily quarterty in arrears. In the case of
agriculfural land, the cou-rpensation
shall lie paid either arurually or on releaseof
the land whichever is earliir. The compensationshall be paid eiiher i"."rf, oiUy
cheque at the discretion of the competent authorify
2[(3) The competent authority
shall, as soon as may
'a be practicable after the
making of a requisitioning order or the service of
notice of acquisition,
communicate to gach person interested an offer of what, in the opinion of the
competent authority, is a fair
1ryoun_tof compensationpayable to such person in
re.fpectof the property requisitioned
or acquired.
(4) If the owner of the properly is not readily traceableor if there
be no
competent
to
alienate
tfe
property
or
if
the-ownership
of the property is
Per99n
in dispute or if there be any dispute as [o the title to receivi the compensation
or as to the apportionrnentof theimount offered,ascornpensuti"ruthe competent
authority shall deposit in court the amount of the
as determined
by hirn under clause(a) of sub-section(1) of section
"o*i"*ution
S. fhe competent authorify
shall at the sametime submit to the Central-Goverrunenta report setting forth the
full facts of the casewith all connectedpapers and apply foi Ureappointment
of
an arbitrator' Where the compensafion ii re.utrirg, th" .o*peient authorify
shall, in casecovered by this sub-rule, deposit the arilount in court from time
to
time in arrear as it falls due.
(5) (i) Every person interested to whom an offer is made under sub-rule (3)
shall, within fi{tee1dlls of the receipt q" offer, communicatein writing to
tiie
cornpetent authority his acceptanceor"fotherwise of the offer. If he
tfr"
offer, the cornpetentauthority shall enter into an agreementwith him".."!tr
on
behalf
of the Central Government in Forrn ,K,.
(ii) In the, following
competent authority rrraq..,r
at his
:lt-.,"*stances the,o1
discretioru make, to 3-l{} eligible
claimantsJ
aicount, payment up to g0 per
cent' of the amount which, in hi9 opiniory is likely to be assisJedas compensation
or recurring compensationas the casemay be_
(a) when there is likely to be delay in assessingcompensation;
(b) where the competent authorily has made an assessmentbut
there is
delay in reaching€il:Iagreementthough there is a reasonableprospect
of agreernentbeing reached;or
(c) where it is clear that an agreement cannot be reached.
1 . Added by S.R.O. 3272, dated 19th October, L954.
2. Ins. by S.R.O.32 2, dated 30th September,!957.
J.

Subs.by G.S.R.502, dated 23rd Aprtl,1960.

<!-- page 4 -->

-

2A

The Requisitioningand Acquisitionof lmmovableProperty Rules, 1953

[Rule I

(ii1) If the competent authority makes an 'on account' payment under
clause(ii), he shall enter into an atreement with the person to whom payment is
made on behalf of the Central Government,in Form 'L' with such modification
as the nafure of the casemay require.
(6) If any person to whom an offer is made trnder sub-rule (3) doesnot accept
the offer or does not within fifteen days bf the receipt of the offer communicate
in writing to the competent authority his acceptanceor otherwise of the offer, the
competentauthority shall, as soon as may be, submit to the Central Govemment
a report setting forth the full facts of the case,particularly as regards the nature
and.extent of disagreementbetweenhimself on the one hand and the said person
on the other hand and he shall also forward with the report all connectedpapers.
The competent authority shall at the same time deposit in court the amount
offered by him to the said person under sub-rule (3).1
10. Arbitration.-11(1) An arbitrator appointed under clause (b) of subsection (1) of section8 shall ordinarily complete the arbitration proceedingsand
give his award within four months. If for any reason he is unable to give his
award within that period, 2[theCentral Govemment or the authority to which the
power of the Central Govemment under clause (b) of sub-section(1) of section
8 has been delegated,rrralt if it thinks fit whether the time for making the award,
has expired or not and whether the award has been made or not, enlarge,from
time to time,'the time for making the awardl.l
(2) An arbitrator shall take down the evidenceof eachwitness,not ordinarily
in the form of question and answer, but in that of a narrative and shatl sign it.
(3) Where before an arbitrator is able to finish the arbitration proceedings
and make his award, a new arbifrator is appointed, the new arbitrator rhay deal
with the evidence taken down by his predecessoras if such evidencehad been
taken down by him and may proceedwith the arbitration proceedingsfrom the
stage at which his predecessorleft it.
(a) The costs of arbitration and award shall be in the discretion of the
arbitrator who may direct to, and by whom,'and in what manner, they or any
part thereof shall be paid, and in casean appeal is preferred to the High Court,
such costsand the costsof the appealshall be in the discretion of the High Court,
who may direct to, and by whom and in what manner, they or any part thereof
3[(5) I4fhen arbitrator has made his award he shall sign it and shall give
notice in writing to the parties to the referenceof the making and signing thereof.
He shall also send to the competentauthority as well as to the person or persons
to be compensateda copy of the award with a note appended thereto setting
forth the grounds on which the award is based and a[shall also forward the
award in original together with the records of the proceedings(a) to the proper court if an appeal is preferred againstthe award within
the period of limitation prescribed for preferring such appeal;
1. Subs. by S.R.O. 3224, dated 4th October, 1954.
2. Subs. by S.R.O. 708, dated 25th March, 1955.
3. Ins. by S.R.O. 3252, dated 30th September, t957.
4. Subs. by C.S.R. 1212, dated L0th December, 1.958.

<!-- page 5 -->

l

-,

';
:,

FormAJ

The Requisitioningand Acguisitionof tmmovableproperty Rutes,

rgss

(b) to.the competent authority if no such appeal is
preferred

:.!f'
,
:[i:

. iIE
.

,'ft:

:*

'r!,

within the
said periodJJ.
(6) On lsssipt,of copl of the award, the cornpetglt authority_shall
pay
' the
amount awarded by lthe arbitrator to the personsintitled thereto tJx-**y.'
2[toA' Moneys d."p^tt-tt-"{
in court.-If any money is deposited in court
under rule 9(4) z[or_rule9(6)1,the eourt shall deaf with it in the mdnner
laid down
in sections32 and 33 of the Land Acquisition Act, 1g94(1
of 1g94).1
11'' Appeals.-(L) Appeals under section 10 shall be addressed
to the
Se.cretaryto the Govemment of India in the administrative ministry
concemed
with the requisitioned properfy. 3[where the appgal relate.s
to a property
requisitioned in the Union teriitory, the appeal shall be
addressed to the
Administrator or if there is no n{nitriflrufir,
to the Chief s";r;;;;
;; ,h;
territory concerned or if there is no Chief Secreiary, to the C."tt"f
Government.
If, however/ a Party addresses
in
respeiigr
;t
ilh
f,roperty to the
Central Govemment, the centralllappeal
covbrnment miy,if it thii* fit, tear the appeal
itself and.disposeit of or may direct the parfy to"file it before
theAdministrator
or the chief secretary or may send tne appei to the Administratu;;A;ehi;;
Secretary,as the casemay be, for disposJl.
@ EY"ly- appeal shall contain the grounds of appeal and shall be
accomPaniedby a copy of-the order against-which the apiiar
is preferred.
12' Summoning of persons and witnesses and production of
documents.An order under sectiorL2 of the Act summoning uta
the attendance
of any person and examining him on oath or'reg.uing
"tf*"ir,g
thJ disc;;;t;J
production of any document straltbe issued in Form'b'. A;order
requisitioning
public reiords from any court or office shall be issuedin Form'Cfwrrite
an order
issuing commissions for examination of wihresses shall
be in Form ,D,.
L3. Inspection.-of premises:-Tlt: c.ompetent authority or
any officer,
empowered in this,behalf by such authority, by general or
Jpuci"t or'a"t, rn"fi
not, in exerciseof the poweis conferred Uyi".tioi 14 enter
rloo*y
properfy
after sunset or before, sunrise.

Whereast................

FORM'A'
(Seerule 3)
NOTICE AND ORDER
...,beingthe competent
authority

(name and designation)
under the Requisifi:fug and Acquisition of Immovable proper[r
Act, 1952 (30 of
r952)',."f
o-pinign tnut-tf,e-ptopoiy describeJ in trr" schedule hereto annexed
9J
is
needed/or likelv to be.neededfor a,p"-ult purpose,*. *ii rr_-.j;G-u"p.,rpor"
of
the
Union and thar"the said prope"ty snfura ul uiq"i"itioned.
Now, therefore, in exerciseof the p9*qrs conferred by sub-section(1)
the said Act, I as the competentauthority, hereby,.uii"po.........---]o\*". of section 3 of
of the said
property........................name
of personbeing fhe.............................p;;;
in possessionto
1. Omitted by G.S.R.dS4,dated 23rd
fulp 1958.
2. Subs.by S.R.O.3252,dared 30th Septembe+1957.
3. Subs.by G.S.R.75& dated t5th April, 1968.

;.

<!-- page 6 -->

22

The Requisitioning
and Acquisitionof lmmovableProperty Rules,lgSS

[FormA

show causewithin
days of the.dateof serviceof this instrument upon him why the
fifteel
said property should
not be requisitionedand I turther direct th"t;;fi;;
the owner of
the said.property- nor.
other
person
shall
without
my
permission
dispose
of or
?ny
structurally alter the said'Prgqerty
or let it out to a tenantt rrtil'th" expiry of two months
from the date of serviceof tliis instrument upon him.
SCHEDULE
Competent Authority,

Signature
Designation..
Seal
1. Here mention the pulposes for which the property shall be requisitioned.
2. Shike off the irrelevant words.

To,

FORM ' B'
(Seerule 12)
SUMMONS TO WTTNESS
CaseNo. ..........................of
20.
In the office.........
Proposed requisition /acquisition/fixation
To,

of cort'rpensationin respect of.....

. {heleas -your attendance is required to give evidence/produce the doctrments
described in the list enclosed in the a6ove
are hereby""q"ii"a-lpersonally)
to
"ur","yo1,
appearbefore the undersignedon the.......................aay...................of..........
..........20...............
in the forenoon/afternoon ind to bring with you (or to send to
""".'....at.............-.O'clock
his office) the said documents
In case you fail to cgmply with this order without lawful excuse, you will be
subject
'
to consequence of non-attendance laid down in Rule 12 of Order XVi of the
C.p.C.
Given under my hand and seal of this office this..................duy
of............20

Competent Authority/Arbitrator

r,ORM,c'
(Sei rule 12)
REQUTSmoN FOR PUBLTCRECORD
.......of
20....................................

CaseNo.
In the office.........
_Proposedrequisition/acquisitionf fixation of compensationof
To,

<!-- page 7 -->

rI

FormEl

The Requisitioning
and Acquisition
ot lmmovableproperty Rutes,l9S3

29

Please
public record(s)
3tan8l to sendper bearer/throughyour clerk on..............the
mentioned below for my examinationin coineition with the propor*J
acquisition/fixationof cornpensation
in respectof........,......
""q.tiritioningi
Given under my hand and sealof this officethis.............-....day
of............20
Details of record.
1
2...
Competent Authority/Arbitrator
ORM'D,
(Seerule t2)
FORM OF COMPENSATION
IN THE MATTEROF.............
It is ordered as follows:
1' A Commissionmay issuedirected1o..............of.................for
the examinationupon
interrogatoriesor aiaa aoaebefore the aforesaidCommissionerof the following:- r
(1 )
(2)
(3)
2' In the event of any witness on his examination, cross-examinationor reexaminationproducitSbo9k, do.cumenfletter, paqer or writing, and refusing for
good causeto be.sfate{ ?tI
in his deposition,topart with ihe original tfiereot tf,en a iopy
thereof,or extracttherefrom certifled by the Commissionerto 5e a true urd
t
or extract ghall be annexedto the witnlss,s deposition.
"orru. "opy
3' Each witness to be examinedunder the Commissionshall be exarninedon oath,
affirmation or otherwise in accordance with his religion by o. before the
said
Commissioner.
, 4..fh: depositionsto be taken under and by virtue of the said commissionshall be
subscribedby the witness or witnessesand by ihe commissioner.
5;'-The interrogatories, cross-interrogatoriesand deposition, together with any
documentsreferred to therein or certified-copiesthereof .it
tlierefrom shall be
sentto the competentauthority/arbitratoron or beforethe................
"*to"t"...........day
of......"........
or such further or other day is may be ordered by registeredpost.
Datedthis...,....dayof..........20..........
Competent Authority/Arbitrator
FORM 'E'

oRDEf'1,19",1t
,.,

notice issued or deemed to be issued under sub-section (1) of section
P{.3
_.tp":uut
J^ or
the l(equisitioning.and Acquisition of Immovable Property Act, LSSZ'(30
of lgSZ)
.......wascalled upon to show cause.................(enteirr"*"of the person).
WilhT theperiod specified therein why the property specified in- the
S"h"d.rl" hereto
I
annexed should not be requisitioned.
:
And, whereas the said period has elpired and no cause has been shown
against the
said notice or the cause shown against the said notice has been considered
Now, therefore, in exercise of the powers conferred by sub-section (2)
of section 3
1.d by section 4 of the said Act t..........;..beinga competeni authority ,....:..:.....,......(name
designation)......,..........
expedient so to do, do hereby requisition the said propeity and I hereby
;rJ";-th":ui;

ii

<!-- page 8 -->

-

24'

The Requisitioningand Acquisitionof tmmovableProperty Rutes, l9S3

[Foim E

'.to surrenderor deliver possession
thereofto................(enter
the name)
within thirty days of the serviceof ihis notice, (enter designationof officer)
If the said""....................refuses
-or -fails to comply with the (enter the name)
that purpose to use such force as may be.necessary.
SCHEDULE
Signature.
Designation.

To,

FORM T'
(See rule 6)
ORDER
Whereas, the premises known as....................have
been requisitioned under section 3
of the Requisitioning and Acquisition of Immovable Property Act,'!.952(30
of l912)or are
deemed to have b1e1 requiJitioned under ihat sectio" ui
ih; provisions of
section 24 of the said Act.
"irt";-;i
And whereas, the said premises are in need of repairs specified
in the Schedule
hereto appended.
Now, therefore, in exercise of the powers conferred by sub-section (2)
of section 5 of
the said Act, I.........
(enter-name) (enter designatiol)lej1e the competent authority
under the said Act do
.
hereby o1d9r.r....*..-...-.....the
[ndloid, of tlie said premises to execljte the repairs, specified
in the schedule, being repairs which are necessary and are usually
*"a" f{y hnaiords in
the locality
whig!
the
premises
are
situated
*ithit
a
period
in
the
date of service of this notice.
"r.......................from
If the said landlord fails to execute the repairs in this order within
the aforesaid
period, it shall cause the same to be executed at his expense and the
cost thereof shall
without prejudice to any other mode of recovery be dlducted
from the compensation
payable to him.
SCHEDULE
Signature
Designatioh..:........,...........

To,

FORM'G'
(See rule Z)
ORDER
the order of the.-.......,.......,
No. ................dated..............with
effect from the.............unti1
further orders of the Central Government.
And, whereas, the Central Government have now decided that the
said property
shall be released from requisition with effect from..........
Now, therefore, in exercise of the powers conferred by sub-section (2)
of section 6 of
the Requisitioning and Acquisition of Immovable Property Act,
1.952 (30 of tg12l,

<!-- page 9 -->

rForm ll

The Requisitioningand Acquisition of Immovable Propefi Rules, 1953

25

the competent authority hereby enter name and designation)
I, .......................being
specifyMr. /Messrs.......;.........
as the person/persons to whom possession of the said property shall be given.

SCHEDULE

To,

r,|
I

I
I

FORM'H'
[See ruIe 7(4)l
NOTICE
Whereas, the property specified in the Schedule hereto annexed was requisitioned by
further
effect from................until
order
of the.............No..................dated............with
the
orders of the Central Government.
And, whereas, the Central Government have decided that the said property shall be
released from requisition.
And, whereas, in exercise of the powers conferred by sub-section (2) of section 6 of
the Requisitioning and Acquisition of Immovable Property Act, 1952 (30 of L952),
a competentauthority............................
I.,................being
...................
(namedesignation)...............
under the said Act have specified Shri..............asthe person to whom possession of the
said property shall be given.
found and has no agent or other
And, whereas the said Shri......:...........cannot.be
person empowered to accept delivery on his behalf.
Now, therefore, in exercise of the powers conferred by sub-section (4) of section 6 of
and
hereby declare that the said.........................(name
the said Act, I,......................do
is releasedfrom requisition.
............:..........property
designation)..............

SCHEDULE

To,

FORM 'I'
(Seerule 8)
NOTICE
Whereas, the Central Government is of opinion that the property described in the
Schedule hereto annexed which is subject to requisition should be acquired for a public
purpose, namely:Now, therelore, in exercise of powers conferred by sub-section (1) of section 7 of the
said Act, the Central Government do hereby call upon Shri...."....beingthe owner of the
said property to show cause within fifteen days of the date'of service of his notice uPon
him why the said property should not be acquired.

<!-- page 10 -->

-

26

The Requisitioningand Acquisitionof lmmovable Property Rules, 1gS3

[Form I

SCHEDULE

To,

FORM J'
(Seerule 8)
NOTICE
Whereas, a notice under the proviso to sub-section (L) of section 7 of the
Requisitioningand Acquisition of ImmovabieProperty Act, L952(30 of 1952),was issued
by the CentralGovernmentto Shri..................being
the owner of the said.propertycalling
upon him to show causewithin the period specifiedthereinwhy the said property should
,

not be acquiredAnd, whereas, the said period has expired and no cause has been shown against the
said notice/the cause shown against the said notice has been considered
Now, therefore, in exercise of the powers of sub-section (L) of section 7 of the said
Act, the Central Government having been satisfied that it is necessary so to do, hereby
acquire the said property.
SCHEDI]LE
Signature..
Designation..
1IFORM 'K'
[See rule 9(5)]
FORM OF AGREEMEhIT TO BE MADE ON BEHALF OF THE CENTRAL
GOVERNMENT WITH OWNERS OF IMMOVABLE PROPERTY
REQUISITIONED WI{EN PAYMENT IS MADE IN FULI
Memorandum of agreementmade this.....................duy
of one thousand nine hundred
and seventy.............,..".........between................son
of............,....by
occupation"..............;.......at
'the
present residing at.........."............hereinafter
referred to as
owner',/owners (which
expression shall unless excluded by or repugnant to the context be deemed to include his
heirs their respective executors, administrators and assigns) of the one part and the
President of India (hereinafter referred to as 'the Government' which expression shall
mean and include his successors-in-officeand assigns) of the other part.
Whereas, the immovable property particulars whereof are set out in the Schedule
hereunder written (hereinafter called 'the said property') has been requisitioned under
lhe Rgqlisitioning and Acquisition of Immovable Property Act, L952, and the tules
framed thereunder and on the
... duy of............20
...............taken
possessionof by
or on behalf of or under the authority of the Government.
And, whereas the owner has/owners have represented and stated to the Governrnent
that the owner/owners alone'is/are entitled to all compensation payable in respect of the
said property and no other person has any right to. such compensation or any part
thereof.
And, Whereas, the said property consists,'inter alia, of land struciures and the
Government has dismantled the said structures"
1. Ins. by S.R.O.3252, dated 30th Septembet L957.

<!-- page 11 -->

Form Kl

v

The Requisltioning
and Acquisition
of tmmovabte
PropertyRutes,t9s3

zz

And whereasthe owner/owners and the Govemment have mutually agreed to settle
the amount of compensationpayable in respectof the said property and no other person
has any right to such compensationor any part thereof.
And, whereas, the said property consists, inter alia, of the land structu.resand the
Governmenthas dismantledlhe saiil structures.''
And whereas, the owner/owners and the Government have mutually agreed to
settle the amount of compensationpayable by the Government to the o*nei/oilners in
connection with the said requisition in the manner hereinafter appearing.
Now it is hereby agreedby and betweenthe parties as follows:(1) The Governmentshall pay and the owner/owners shall acceptand receivea
sum of Rs. .............in full settlementof the compensationfor the structures,
(omit if the owner has no structures.)
(2) The Government shall pay and the owner/owners shall accept and receive a
paymelt of f-{r. ...............
per month/quarter year in arrear for the said property
with effect from the said day of
20..........so long as the Government
shall remain in possessionthereof and the requisition continues.
(3) The owner/owners shall not claim or be entitled to any other compensation
whatsoeverin'connection with the said requisition:
,
l[Provided that the owner/owners may claim variation of compensation
if the
'
rent of the premises considered as on leaseto the Government is variable by
reasonof any statutory provision.I
(a) The owner/owners.shall-meetand pay the revenue,rent, municipal taxesand
all other outgoing relating to the said property whether payable by the owner/
owners or the occupier thereof.
(5) If it hereafter transfers that the owner/owners islare not entitled or exclusively
en'titled to th9 compensationpayable in respect of the said property or if th;
Govemment have to pay any compensationto any other person the owner/
owners shall refund to the Government the compensation paid or such part
thereof as the owner/owners is/are not entitGd to and shall otherwise
indemni$r the Govemment against any loss or damage suffered by the
Government by reason of any fault or defect in title as represented by the
owner/owners, without prejudice to any other remediesfor the enforcernentof
such refund a1d indemnity the Government may recover any sum payable by
way of refund and /or indemnity as affears of land revenue.
(6) Should any dispute or difference arise out of or concerning the subject-matter
of these predents or any covenant clause or thing herein contained 6r otherwise

arising out of the requisition aforesaid the same shall be referred to an
arbitrator to be appointed by the Government and the decision of such
arbitrator shall be conclusiveand binding on the parties hereto. The provisions
of .the Arbitration Act, 1940,shall apply to such arbitration.
SCHEDULE
(Above referred to)
(Particularsand Descriptionof Property Requisitioned)
In witness whereof thesepresentshave been executedthe day and year first above
written.

Signed and delivered by the above named owner/owners in presence of
Signed and delivered for and on behalf of the President in the presence of
1. Ins. ly C.S.n.359,dated 25th Marclr, L960.

1

<!-- page 12 -->

-'

I

The Requisitioningand Acquisitionof. Immovable Propefi Rules, 1953

[Form L

FORM 'L'

fseeruleg(sxiii)l
FORMOF AGREEMENT
TO BE MADE ON:BEHALF
OF rHn CnxrnAr
GOVERNMENT WITH OWNERS OF IMMOVABLE PROPERTY
REQUTSITTONEDWHEN THE PERSONSTO BE COMPENSATED
ARE KNOWN BUT FOR WANT OF AGREEMENT AS TO THE
AMOUNT OF COMPENSATION CERTAIN SUMS ARE
PAID ON ACCOUNT
Memorandum. of agreement made this..........-..-..............days
of..........................two
thousand.............between...................son
of,..................by
occupation...................at
present
residing at ..............hereinafterreferred to as the owner/owners (which expression shall
unless excluded by or repugnant to the context be deemed to include his/their respective
heirs executors, administrators and assigns) of the one part and the President of brdia
(hereinafter referred to as the Government'which expression shall mean and include his
successor in office and assigns of the other part.
Whereas the immovable property particulars whereof are set out in the schedule
hereinunder written (hereinafter called the said property has been requisitioned under
the Requisitioning and Acquisition of Immovable Property Act, 1952and the rules framed
thereunder and on the.............duyo1......,...20........taken
possessionof by or on behalf of or
under the authority of the Central Government.
And, whereas, the said owner/owners has/have represented and stated to the
Govemment that the ownerlowners alone b/are entitled to all compensation payable in
respect of the said property and no other person has any right to such compensitiotr ot
any part thereof.
And whereas, no agreement having been arrived at between the parties as to the
amount of compensation payable to the owner/owners and the.Govemmept has at the
request of the owner/owners agreed to make payment to the owner/owners on account
pending an agreement between the parties as to the amount of compensation payable or
the final determination of such amount under the law. Now this agreement witnesses as
follows:(1) The Governrnent shall pay and the owner/owners shall accept and receive
payment of Rs.
per month quarter/year for the said property with effect
from the said duy of........,......20................pending
agreement as to or
determination of the amount payable as compensation to the owner/owners.
(2) Upon such agreement or determination of the amount payable as
compensation as aforesaid on account shall be prepared crediting the
Govefiunent
with the payments made by the Government as aforesaid and
.
debiting the Government with the amouni payable as compensation. If no such
account being prepared there is a balance in favour of the Government the
amount of such balance shall be forthwith refunded by the owner/owners to
the Government. If there is a balance payable to ihe owner/owners the
Government shall pay the amount thereof to the owner/owners.
(3) If it hereafter transpires that the owner/owners is/are not entitled or
exclusively entitled to the compensation payable in respect of the said property
or if the Government have to pay any compensation to any other person the
owner/owners shall refund to the Government the payments made hereunder
and shall otherwise indemnify the Govemment against any loss or damage
.
suffered by the Government by reason of any fault-or defecf in his /their titfe
as represented by him,/them without prejudice to any other remedies for the
enforcement of any refund and/or indemnity, the Government may recover

<!-- page 13 -->

FormLl

The Requlsitioning
and Acquisitlonof lrnmovablePropertyRutes,1959

29

any sum payable by way of refund and/or indemnity as arrears of land
revenue.
, (4) Should any dispute or differencearise out of or concerningthe subject-matter
or thesepresentsor any covenan!clauseor thing herein containedor otherwise
arising out of the requisition aforesaid the same shall be .referred to an
.
arbitrator to be appointedby the Central Government and the decision of strch
arbitrator shall be conclusiveand binding on th'eparties hereto. The provisions
of the Arbitrator Act, L940shall apply to such arbitrations.
'

SCHEDULE
(Above referred to)
witness whereof these preserrtshave been executedthe day, and year first above
In witr
written
ten.
Signed end delivered by the above named .owner/owners in the presence
of
Signed and delivered lar and on behalf of the President in the presen:e
of.......

t:

tt

ii
ii

.ii

iii l

iiii

ti
ii
' " ! t
;i
:ii

:.ji

ii
i:
L.-_
