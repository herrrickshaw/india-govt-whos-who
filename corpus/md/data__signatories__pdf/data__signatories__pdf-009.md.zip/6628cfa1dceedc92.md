---
doc_id: "6628cfa1dceedc92"
source_url: "https://www.dot.gov.in/static/uploads/2026/09/2e52030038ba015e586059767f63dd8a.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of Unified License (UL), bearing no. 821-206/2014-DS dated 16.10.2015, for Category ‘B’ ISP Authorization for Delhi Service Area, granted to M/s Airnat IT Solutions Pvt. Ltd.,"
date: "2026-09-14"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "956f81f17d839203"
---

<!-- page 1 -->

821-206/2014-DS

I/3443097/2026

WITHOUT PREJUDICE
F. No. 821-206/2014-DS
Government of India
Ministry of Communications
Department of Telecommunications
(Data Services Cell)
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 14-09-2026
To,
M/s Airnat IT Solutions Pvt. Ltd.
257, Second Floor, Shubham Tower, Near Escorts Hospital,
NIT Faridabad, Haryana – 121001
Email Id: yash@airnat.com, amit.puniani@gmail.com

Subject:- Termination/Revocation/Cancellation of Uniﬁed License (UL),
bearing
no. 821-206/2014-DS dated 16.10.2015, for Category ‘B’ ISP
Authorization for Delhi Service Area, granted to M/s Airnat IT Solutions Pvt.
Ltd., in terms of clause 10.2 (i) under Chapter-I of Part-I of the said License
Agreement.

Whereas, Department of Telecommunications, Government of India (“the
Licensor”) has granted a Unified License (UL), bearing no. 821-206/2014-DS dated
16.10.2015 (“the License”), for Category ‘B’ ISP Authorization for Delhi Service
Area, to M/s Airnat IT Solutions Pvt. Ltd. ("the Licensee").
2.
Whereas, the Licensee is required to provide the services under the terms
and conditions of the License and instructions issued by the LICENSOR from time
to time.
3.
Whereas, as per National Security Directive on Telecommunication Sector
(NSDTS), the licensees are required to connect only Trusted Products in its
network with eﬀect from 15th June 2021. Condition 39.7.1 of the Security
Conditions (Chapter-VI) of the Uniﬁed License (UL) Agreement further stipulates
that, with eﬀect from 15th June 2021, the licensee, shall only connect Trusted
Products in its network and also seek permission from Designated Authority for
upgradation or expansion of existing Network utilizing the Telecommunication
Equipment not designated as Trusted Products. Instructions to all the Licensees by
the Licensor have been issued in the past vide letters dated 30.03.2021,
16.06.2021 and 10.06.2022, requesting compliance related to trusted telecom
products and registration on Trusted Telecom Portal. Pursuance with the licensee
through various communication have also been done by the concerned LSA ﬁeld
unit of the department in this regard.

<!-- page 2 -->

821-206/2014-DS

I/3443097/2026

4.
That for non-registration on the Trusted Telecom Portal, a Show Cause
Notice, bearing no. DS/1/2025-DIR(DS-II), dated 16.01.2025 (“SCN”), was issued
to the Licensee on the address provided in the License. The aforesaid SCN was
sent by way of speed post as well as by an email on the registered email ID(s) of
the Licensee on 20.01.2025.
5.
That the aforesaid SCN was issued to the Licensee to submit its reply, within
21 days, as to why the License granted to it should not be terminated, in terms of
the clause 10.2(i) under Chapter-I of the Part-I of the License.
6.
That despite having given enough time and opportunity to the Licensee to
show cause and explain the alleged violation of terms and conditions of the
License mentioned in the SCN, the Licensee has failed to submit any reply
whatsoever to the Licensor. Further, concerned LSA ﬁeld unit, vide its email dated
07.09.2026 has informed that the licensee is still not registered on the Trusted
Telecom Portal.
7.
That the failure of the Licensee to either comply the stated non-compliance
or submit any reply or explanation to alleged violation of terms and conditions of
the license mentioned in the SCN implies that the Licensee has nothing to say in
this regard and that the Licensee has failed to comply with the conditions of the
License and therefore, has violated the conditions of the License as stated in the
SCN.
8.
Therefore, the competent Authority has now decided to terminate/ revoke/
cancel
the Uniﬁed License (UL), bearing no. 821-206/2014-DS dated
16.10.2015, for Category ‘B’ ISP Authorization for Delhi Service Area, granted
to M/s Airnat IT Solutions Pvt. Ltd., in terms of clause 10.2 (i) under Chapter-I of
Part-I of the License and that the said License is terminated/ revoked/ cancelled
w.e.f. 61st calendar day from the date of issue of this letter.
9.
That the Licensee is further directed to terminate and stop all
interconnections with all service providers eﬀective from the date of termination of
the License.
10.
That the Licensee is further directed to issue a notice of at least 30
calendar days to all its customers within 30 days from today in terms of the
condition 10.2(i) under Chapter-I of Part-I of the License Agreement reproduced as
under:
“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order”.
11.
That the Licensee shall take note of the clause 10.7 under Chapter-I of
Part-I of the License, which is reproduced as under:
“It shall be the responsibility of the Licensee to maintain the Quality of Service,
even during the period when the notice for surrender/revocation of License is
pending and if the Quality of Service is not maintained, during the said notice
period, it shall be liable to pay damages. The quantum of damages and to whom
payable shall be determined by the TRAI. Further, it shall also be treated as

<!-- page 3 -->

821-206/2014-DS

I/3443097/2026

material breach liable for action under Clause 10.1 and 10.2 of the License. The
Licensee shall also be liable to pay the License Fee till the end of the notice period
and more speciﬁcally till the date on which the surrender/revocation becomes
effective.”
12.
That the Licensee shall take note of the clause 11.2 under Chapter-I of
Part-I of the License, which is reproduced as under:
“On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank
Guarantee(s) shall be released to the Licensee only after ensuring clearance of all
dues, which the Licensee is liable to pay to Licensor. In case of failure of the
Licensee to pay the amounts due to the Licensor, the outstanding amounts shall be
realized through encashment of the Bank Guarantees without prejudice to any
other action(s) for recovery of the amounts due to the Licensor without any further
communication to the Licensee”.
13.
That the Licensee shall also take note that in case, it comes to the notice of
the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.
14.
That the Bank Guarantee(s) submitted by the Licensee against the said
license will be released in terms of clause 11.2 under Chapter-I of Part-I of the
License after ensuring clearance of dues, including dues/ penalty arising, if any, as
a consequence of the aforesaid violation.
15.

That the Licensee may acknowledge the receipt.

Director (DS-II)
Email: dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to: 1. DG Telecom, DoT, New Delhi, with a request to instruct the concerned
LSA(s) to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any “telecom resources” to/from M/s Airnat IT
Solutions Pvt. Ltd.
2. Special DGT, Delhi LSA, DoT.
3. Sr. Joint CGCA(Revenue), O/o CGCA, DoT with a request to release the
Bank Guarantees of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of Data Service Cell is concerned, the same will be intimated to O/o
CGCA in due course of time.

<!-- page 4 -->

821-206/2014-DS

I/3443097/2026

4. Secretary, TRAI.
5. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective date
of termination of License and convey to office of CGCA.
6. Pr CCA, Delhi Circle, DoT.
7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/
DDG(WPF), DoT HQ.
8. Director (IT), DOT HQ for uploading this order on DoT website for information
to all Service Providers.
9. File No.: 821-206/2014-DS
