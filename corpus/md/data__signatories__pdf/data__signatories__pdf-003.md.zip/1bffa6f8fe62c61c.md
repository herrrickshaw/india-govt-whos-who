---
doc_id: "1bffa6f8fe62c61c"
source_url: "https://www.dot.gov.in/static/uploads/2026/10/fbc9111af020bb9e7b352cf1718ded67.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of Unified License (UL), bearing no. DS-11/400/2022-DS-III Dated 04.01.2023, for Category 'C ISP Authorization for Pune SSA in Maharashtra Service Area, granted to M/s Advik Infocom Private Limited,"
date: "2026-10-06"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "32de12b4bd8b584e"
---

<!-- page 1 -->

DS-11/400/2022-DS-III 1/3450624/2026
WITHOUT PREJUDICE
F. No. DS-11/400/2022-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
(Data Services Cell)
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 06-10-2026
To,
M/s Advik Infocom Private Limited

Flat No A-204, Tribkeshwar Heights, Sect-3, Plot-668,

Indrayaninagar, Bhosari, Pune, Maharashtra-41 1039
Email Id: advikinfocom@gmail.com
Subject:- Termination/Revocation/Cancellation of Unified License (UL),
bearing no. DS-11/400/2022-DS-Ill Dated 04.01.2023, for Category ‘C’ ISP
Authorization for Pune SSA in Maharashtra Service Area, granted to M/s
Advik Infocom Private Limited, in terms of clause 10.2 (i) under Chapter-I of
Part-I of the said License Agreement.

Whereas, Department of Telecommunications, Government of India (“the

Licensor”) has granted a Unified License (UL), bearing no. DS-11/400/2022-DS-III
Dated 04.01.2023 (“the License”), for Category ‘C’ ISP Authorization forPune
SSA in Maharashtra Service Area, to M/s Advik Infocom Private Limited ("the
Licensee").

2. WHEREAS, the LICENSEE is required to provide the services under the
terms and conditions of the License and instructions issued by the LICENSOR from
time to time.

3. That for alleged violation of Conditions No. 18.2.1, 20.4, 20.6, 20.9, 21.1,
21.2, 21.3 & 21.4 of Chapter-lll of Part-I of the License, a Show Cause Notice,
bearing no. DS-11/287/2023-DS-ll, dated 10.08.2026 (“SCN”), was issued to the

Licensee on the address provided in the License. The aforesaid SCN was sent by
way of speed post ID no. ED982200411IN as well as by an email on the registered
email ID(s) of the Licensee on 11.08.2026.

4. That the aforesaid SCN was issued to the Licensee to submit its reply,
within 21 days, as to why the License granted to it should not be terminated, in
terms of the clause 10.2(i) under Chapter-I of the Part-I of the License.

5. That despite having given enough time and opportunity to the Licensee to
show cause and explain the alleged violation of terms and conditions of the

License mentioned in the SCN, the Licensee has failed to submit any reply
whatsoever to the Licensor within the time frame allowed to the Licensee.

<!-- page 2 -->

DS-11/400/2022-DS-III 1/3450624/2026
6. That the failure of the Licensee to submit any reply or explanation to alleged
violation of terms and conditions of the license mentioned in the SCN implies that
the Licensee has nothing to say in this regard and that the Licensee has failed to
comply with the conditions of the License and therefore, has violated the conditions
of the License as stated in the SCN.

7. Therefore, the competent Authority has now decided to terminate/ revoke/
cancel the Unified License (UL), bearing no. DS-11/400/2022-DS-IIl Dated
04.01.2023, for Category ‘C’ ISP Authorization for Pune SSA in Maharashtra
Service Area, granted to M/s Advik Infocom Private Limited, in terms of clause
10.2 (i) under Chapter-l of Part-I of the License and that the said License is
terminated/ revoked/ cancelled w.e.f. 61 St calendar day from the date of issue of
this letter.

8. That the Licensee is further directed to terminate and stop all
interconnections with all service providers effective from the date of termination of
the License.

9. That the Licensee is further directed to issue a notice of at least 30 calendar
days to all its customers within 30 days from today in terms of the condition 10.2(i)
under Chapter-| of Part-I of the License Agreement reproduced as under:

“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order’.

10. That the Licensee shall take note of the clause 11.7 under Chapter-| of
Part-I of the License, which is reproduced as under:

"It shall be the responsibility of the Licensee to maintain the Quality of Service,
even during the period when the notice for surrender/revocation of License is
pending and if the Quality of Service is not maintained, during the said notice
period, it shall be liable to pay damages. The quantum of damages and to whom
payable shall be determined by the TRAI. Further, it shall also be treated as
material breach liable for action under Clause 10.1 and 10.2 of the License. The
Licensee shall also be liable to pay the License Fee till the end of the notice period
and more specifically till the date on which the surrender/revocation becomes
effective."

11. That the Licensee shall take note of the clause 11.2 under Chapter-| of
Part-I of the License, which is reproduced as under:

“On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank
Guarantee(s) shall be released to the Licensee only after ensuring clearance of all
dues, which the Licensee is liable to pay to Licensor. In case of failure of the
Licensee to pay the amounts due to the Licensor, the outstanding amounts shall be
realized through encashment of the Bank Guarantees without prejudice to any
other action(s) for recovery of the amounts due to the Licensor without any further
communication to the Licensee’.

12. That the Licensee shall also take note that in case, it comes to the notice of

<!-- page 3 -->

DS-11/400/2022-DS-III 1/3450624/2026
the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.

13. That the Bank Guarantee(s) submitted by the Licensee against the said
license will be released in terms of clause 11.2 under Chapter-I of Part-I of the
License after ensuring clearance of dues, including dues/ penalty arising, if any, as
a consequence of the aforesaid violation.
14. That the Licensee may acknowledge the receipt.
Digitally signed by
SHASHI KUMAR
Date: 06-10-2026
10:02:12
Director (DS-II)
Email: dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to: -

1. DG Telecom, DoT, New Delhi, with a request to instruct the concerned
LSA(s) to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any “telecom resources” to/from M/s Advik
Infocom Private Limited.

2. Special DGT, Maharashtra LSA, DoT.

3. Sr. Joint CGCA(Revenue), O/o CGCA, DoT with a request to release the
Bank Guarantee(s) of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of Data Service Cell is concerned, the same will be intimated to O/o
CGCA in due course of time.

4. Secretary, TRAI.

5. Wireless Advisor, for issue of Dues/No Dues Certificate till the effective date
of termination of License and convey to office of CGCA.

6. CCA, Maharashtra Circle, DoT.

7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/
DDG(WPF), DoT HQ.

8. Director (IT), DOT HQ for uploading this order on DoT website for information
to all Service Providers.

9. File No.: DS-11/400/2022-DS-III
