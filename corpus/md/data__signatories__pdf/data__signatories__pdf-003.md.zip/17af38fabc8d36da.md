---
doc_id: "17af38fabc8d36da"
source_url: "https://mnre.gov.in/static/uploads/2025/08/25749a5815de9d5dde8cda2210ebb3c6.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Comments of stakeholders on draft Recruitment Rules 2025 in r/o Scientists at MNRE"
date: "2025-01-02"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4f7c96f5abd772aa"
---

<!-- page 1 -->

<!-- page 2 -->

MINISTRY OF NEW AND RENEWABLE ENERGY
NOTIFICATION
New Delhi, the, __________, 2025
G.S.R. _____. — In exercise of the powers conferred by the provisio to Article 309 of the Constitution and
in supersession of the Ministry of New and Renewable Energy, Scientists, Group ‘A’ Posts Recruitment Rules,
2015, except as respects things done or omitted to be done before such supersession, the President makes the
following rules regulating the method of recruitment to the posts of Scientists in Ministry of New and Renewable
Energy, namely:Short title and commencement – (1) These rules may be called the Ministry of New and Renewable
Energy, Scientists, Group ‘A’ Gazetted Posts Recruitment Rules, 2025.

1.

(2) They shall come into force on the date of their publication in the official Gazette.
Definitions : In these rules unless the context otherwise requires;

2.

(a) “Central Government” means Government of India, Ministry of New and Renewable Energy;
(b) “field experience” means and includes the following for the purpose of Flexible Complementing promotions:(i)

Working experience in Scientific laboratories or institutes (like National Institute for Wind Energy
(NIWE), Sardar Swaran Singh National Institute of Bio-Energy (SSS-NIBE) {formerly known as
National Institute of Renewable Energy (NIRE), or National Institute of Solar Energy (NISE)
{formerly known as Solar Energy Centre –(SEC)} under the Ministry of New and Renewable
Energy or any other such scientific institute including its regional offices), period spent on doctoral
degree in basic or applied research or post doctorate research after joining an organization;

(ii)

working experience in experimental development for application of scientific knowledge directed
towards producing new or subsequently improved materials, devices, products, processes, systems
or services which involves application of scientific knowledge in the field of new and renewable
energy; and

(iii)

working experience at research and development laboratories or institutes, scientific projects being
operated in mission mode and also working and assisting research and development projects or
scientific work at national and international level;

(c) “managerial capacity” means ability to manage and co-ordinate science and technology related activities at a senior
level with clear understanding of issues involved in putting together quality science and technology programmes and
ability to provide directions and guidance to subordinates and ability to groom them to take up higher level of
responsibility;
(d) “research and development experience” means and includes the following for the purpose of direct recruitment or
deputation:
i.
ii.
iii.

iv.
v.

working experience in scientific laboratories or institutes, period spent on doctoral or post-doctoral
degree in basic research concerning new and renewable energy;
work experience in scientific laboratories or institutes, period spent on doctoral or post-doctoral degree
in applied research;
working experience in experimental development for application of scientific knowledge directed
towards producing new or substantially improved materials, devices, products, processes, systems or
services concerning new and renewable energy provided such work is not of routine use of scientific
knowledge but in application of scientific knowledge for creation of new innovative systems, practices
and models;
working experience in research and development laboratories and institutions, scientific projects being
operated in mission mode, working on international collaboration research and development projects;
full time working experience in scientific research and development projects or doing any post-doctoral
research project in any institute or University as evidenced by certification by such institute or University
and publication of research work in journals of repute;

(e) “Revised Flexible Complementing Scheme” (RFCS) means Scheme as notified by the Department of Personnel
and Training vide No. AB-14017/41/2013-PP(RR) dated the 13th March, 2024;
(f) “Scientists or Engineer” means persons who:(a) Are recruited as such and continue to hold a scientific post as defined below; and

Page 1 of 15

<!-- page 3 -->

(b) Possess academic qualification of at least Master’s Degree in Physical/ Chemical/ Biological/ Earthatmospheric/ Environmental/ Mathematical/ Computational and Information/ Agricultural Sciences from a
recognized University or Institute;
OR
Bachelor’s Degree in Engineering/ Technology/ Biotechnology/ Medicine or Veterinary Sciences or
Pharmaceutical Sciences (minimum 4 year degree course) from a recognized University or Institute
(g) “scientific post” means a post in which the incumbent is a Scientist or Engineer, working in a scientific institution
or organisation declared as Scientific Department or organization and who is engaged in creating new scientific
knowledge or innovative engineering, technological or medical techniques or which is involved predominantly in
professional research work and development;
(h) “scientific activities or services” means and includes the following namely:(i) fundamental or basic research, which means original investigation to gain new scientific knowledge, not

necessarily directed towards any specific practical aim or application or working in scientific laboratories
or institute and period spent on doctoral or post-doctoral degree in basic research;

(ii) applied research, which means original investigation to gain new scientific or technical knowledge directed

towards a specific practical aim or objective or working in scientific laboratories or institutes, period spent
on doctoral or post-doctoral degree in applied research;

(iii) experimental development, which means application of scientific knowledge directed towards producing

new or substantially improved materials, devices, products, processes, systems or services or field
experience that depends on the work profile of the Department.
Explanation.- For the purpose of this clause, it is clarified that the work relating to experimental
development shall not be routine use of scientific knowledge but shall involve application of scientific
knowledge for creation of new innovative systems, practices and models;

(iv) scientific and technical activities which are directly linked to research and development in terms of promoting

the scientific activities and services, such as working in research and development laboratories and institutions,
scientific projects being operated in mission mode, working on international collaboration research and
development projects;

(i) “Schedule” means Schedules annexed to these rules.
3.
Number of posts, classification, pay level as per 7th CPC pay matrix. – (1) The number of posts, their classification,
pay level as per 7th CPC pay matrix attached thereto shall be specified as under:
S. No

Name of post

Classification

1

Scientist ‘G’

2

Scientist ‘F’

3

Scientist ‘E’

4

Scientist ‘D’

5

Scientist ‘C’

6

Scientist ‘B’

General Central Service, Group ‘A’
Gazetted, (Non-Ministerial, Scientific
and Technical)
General Central Service, Group ‘A’
Gazetted, (Non-Ministerial, Scientific
and Technical)
General Central Service, Group ‘A’
Gazetted, (Non-Ministerial, Scientific
and Technical)
General Central Service, Group ‘A’
Gazetted, (Non-Ministerial, Scientific
and Technical)
General Central Service, Group ‘A’
Gazetted, (Non-Ministerial, Scientific
and Technical)
General Central Service, Group ‘A’
Gazetted, (Non-Ministerial, Scientific
and Technical)

* Subject to variation dependent on workload.
Page 2 of 15

Number of
posts
06 (2025)*

Pay level as per 7th CPC
pay matrix
Level 14 of the 7th CPC
pay matrix

11 (2025)*

Level 13A of the 7th CPC
pay matrix

15 (2025)*

Level 13 of the 7th CPC
pay matrix

16 (2025)*

Level 12 of the 7th CPC
pay matrix

20 (2025)*

Level 11 of the 7th CPC
pay matrix

20 (2025)*

Level 10 of the 7th CPC
pay matrix

<!-- page 4 -->

(2) Total number of sanctioned posts from Scientist ‘G’ to ‘B’ shall be 88:

Provided that if the number of Scientists recommended for consideration of promotion to the next grade under the
scheme are more than the number of vacancies available in the promotion grade, then to that extent the number of
posts be automatically upgraded to the promotion grade subject to the condition that the combined sanctioned
strength of all the grades shall remain the same.
(3) Vacancies arising due to attrition shall normally revert to the entry level grade of the respective
Scientific/Technical category.

4.

Method of recruitment. - (1) The posts of Scientist ‘G’ to ‘B’ shall be selection posts.
(2)

The posts shall be exempted from the purview of the Union Public Service Commission for the
purpose of consultation for appointments to be made thereto by recruitment, deputation, promotion
at different level of Scientists in the Ministry of New and Renewable Energy.

(3)

Recruitment for the post of Scientist ‘B’ shall be made by direct recruitment as specified in Schedule
1.

(4)

Recruitment for the post of Scientists ‘C’ to ‘G’ shall be made either by promotion under RFCS
(rule 5) or by direct recruitment or deputation (including short–term contract) or absorption as
specificied in Schedule-II.

(5)

The method of recruitment for each post or each case shall be decided by the Central Government
from time to time.

(6)

Particular discipline or field of essential educational qualifications and experience for each post or in each
case shall be decided by the Central Government, keeping in view the availability of Scientists in different
fields and further requirement of Scientists in a particular field.

Ex-serviceman may be recruited on re-employment basis in accordance with the orders issued by
the Central Government from time to time.
Promotion. – Promotion of Scientist shall be governed by the provision of the RFCS as specified in Schedule
(7)

5.
III.

6.
Annual Confidential Reports / Annual Performance Appraisal Reports and Annual Work Reports.- Annual
Confidential Reports or Annual Performance Appraisal Reports along with Annual Work Reports of Scientists shall be recorded
in accordance with the instructions, time schedules and the formats prescribed by the Central Government or the Department of
Personnel and Training from time to time. Both AWR and APAR would be filled mandatorily on an annual basis.
7.
Probation.- (1) Every Scientist appointed to the service by direct recruitment shall be on probation for a period
of two years:
Provided that the Cadre Controlling Authority may extend the period of probation in accordance with the instructions
issued by Central Government from time to time in this regard:
Provided further that any decision for extension of a probation period shall be taken ordinarily within eight weeks
after the expiry of the previous probation period and communicated in writing to the concerned officer together with
the reasons for so doing within the said period.
(2)
On completion of the period of probation or any extension thereof Scientists shall, if considered fit for
permanent appointment, be retained in their appointments on regular basis and be confirmed against the available
substantive vacancies.
(3)
If, during the period of probation or any extension thereof, as the case may be, the Central Government is of the
opinion that a Scientist is not fit for permanent appointment, the Central Government may discharge or revert the Scientist
to the post held by him prior to his appointment in the service, as the case may be.
(4)
During the period of probation, or any extension thereof, Scientists may be required by Government to undergo
such courses of training and instruction and to pass examinations and tests (including examination in Hindi) as Government
may deem fit, as a condition to the satisfactory completion of the probation period.
(5)
As regards other matters relating to probation, the members of the services shall be governed by the
instructions issued by the Central Government in this regard from time to time.
8.
Confirmation: Confirmation of Scientists appointed through direct recruitment shall be done by the Central
Government on the recommendations of Departmental Confirmation Committee, the composition of which shall be as
follows:

Page 3 of 15

<!-- page 5 -->

I.

For Scientists ‘B’, ‘C’, ‘D’, ‘E’and ‘F’

1
2
3

II.

Secretary, Ministry of New & Renewable Energy
- Chairman
Joint Secretary (Administration)
- Member
Group Head /Head of Division in which Scientist concerned is - Member
working or have worked (in case of Scientist ‘E’ and ‘F’ - Joint
Secretary and above level).
For Scientist ‘G’
1.
2.

Secretary, Ministry of New and Renewable Energy
Two Members of the level of Additional Secretary in Government of India

- Chairman
- Members

Appointing Authority. In the case of Scientist ‘B’, ‘C’, ‘D’, ‘E’, ‘F’ and ‘G’, the appointing authority will be Minister-in-Charge. (The
approval of Appointment Committee of Cabinet (ACC) is mandatory in case of appointment/promotion to the post
carrying pay in Level 14 or above, as on date).
9.

10.

Disqualification. - No person,
(a) who has entered into or contracted a marriage with a person having a spouse living, or;
(b) who, having a spouse living, has entered into or contracted a marriage with any person,

shall be eligible for appointment to the said posts:
Provided that the Central Government may, if satisfied that such a marriage is permissible under the
personal law applicable to such person and the other party to the marriage and that there are other grounds for so
doing, exempt any person from the operation of these rules.
11. Liability to serve in the Defence Services. - Any person appointed to any of the said posts shall, if so required,
be liable to serve in any of the Defence Services or posts connected with the defence of India, for a period not more
than four years including the period spent on training, if any:
Provided that services of such person shall not be required;
(a) after the expiry of ten years from the date of appointment;
(b) ordinarily to serve after attaining the age of forty years.

12.
Liability of Scientists to serve in India and outside.- Scientists appointed to any of the said posts under these
rules shall be liable to serve anywhere in India and outside.
13.
Training courses.- (1) Scientists appointed shall be liable to undergo such training, as be detailed on courses
of instruction in India or abroad as the Central Government may decide from time to time.
The course shall include acquiring working knowledge of Hindi, as per standards prescribed by the Central
Government from time to time.
(2)

Successful completion of certain training courses like Induction Course of no less than two weeks for newly
recruited Scientists, as prescribed by Central Government, would be mandatory for completion of probation period
and consideration for RFCS promotions.
(3)

An officer detailed for training on course, the duration of which is six months or more or an officer detailed
for training outside India or with private firms or factories in India, irrespective of the duration of the training, shall
be liable to refund in full, the cost of training, if, for any reason, during the training or within a period of three years
after the completion of such training, the officer chooses to discontinue the service.
(4)

14.
Classification of posts for the purpose of medical standards.- All posts under these rules shall be deemed to
be non-technical posts for purpose of medical standards as specified in the medical regulation and medical report for
the Indian Administrative Service, Indian Foreign Service and the Central Services.
15.
Power to relax. - Where the Central Government is of the opinion that it is necessary or expedient to do so, it
may, by order, for reasons to be recorded in writing and in consultation with the Department of Personnel and Training
and in matters where consultation with Union Public Service Commission is necessary, relax any of the provision of
these rules with respect to any class or category of persons.
Page 4 of 15

<!-- page 6 -->

16.
Saving. -Nothing in these rules shall affect reservation, relaxation of age-limit and other concessions required to be
provided for the Scheduled Castes, the Scheduled Tribes, ex-servicemen and other special categories of persons in
accordance with the orders issued by the Central Government from time to time in this regard.
SCHEDULE I
[See sub-rule (3) of rule 4]
Recruitment for the post of Scientist ‘B’
1.

Educational and other qualifications required for direct recruits.-

(a) Essential:

Master’s Degree in Physical/Chemical/Biological/Earth-atmospheric/Environmental/Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Bachelor’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or
Veterinary Sciences or Pharmaceutical Sciences (minimum 4 year degree course) from a recognised
University or Institute
(b) Desirable:
(i) Specialized experience in research and development or industrial or academic institutions or science
and technology organisations. This experience shall be of a specific nature relevant to the job
requirements of the post;
(ii) Doctorate Degree in Physical/ Chemical/ Biological/ Earth-atmospheric/ Environmental/
Mathematical/ Computational and Information/Agricultural Sciences from a recognised University or
Institute
OR
Master’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences from a recognised University or Institute
Note 1: The specific educational qualifications and areas of experience according to the requirements of the post shall
be specified at the time of recruitment by the Government.
Note 2: The period spent to acquire essential qualifications including doctorate degree before joining an organisation
shall not be counted as field experience.
2.

Age-limit for direct recruits.The upper age-limit for direct recruitment shall not exceed thirty-five years.
(Relaxable for Government servants’ upto five years in accordance with the instructions or orders issued by the
Central Government).

Note: The crucial date for determining the age-limit shall be the closing date for receipt of applications from candidates
in India (and not the closing date prescribed for those in Assam, Meghalaya, Arunachal Pradesh, Mizoram,
Manipur, Nagaland, Tripura, Sikkim, Union Territory of Ladakh, Lahaul and Spiti District and Pangi SubDivision of Chamba District of Himachal Pradeshandaman and Nicobar Islands or Lakshadweep).
(In case of recruitment by promotion or deputation (including short-term contract) / absorption, grades from
which deputation (including short-term contract) / absorption to be made. - Not applicable.
3.
Screening and selection process for direct recruitment. – The screening and selection process shall be as
prescribed by the Central Government. The composition of the Eligibility Committee, Screening cum Short Listing
Committee and Interview Board shall be prescribed by Central Government. However, majority of the members in the
Screening-cum Short Listing Committee and Interview Board, excluding the Chairman shall be from outside the
Ministry of New Renewable Energy. If considered necessary, the screening process shall include a written test to be
conducted by the Central Government directly or through any Central Government agency or organization having
experience and expertise in the area.
Page 5 of 15

<!-- page 7 -->

4.

Departmental Promotion Committee (for consideration of promotion).- Not applicable

5.

Consultation with Union Public Service Commission. - Not applicable.
SCHEDULE II
[See sub-rule (4) of rule 4]
Recruitment for the posts of Scientists ‘C’ to Scientist ‘G’

1. (A) Educational and other qualifications required for direct recruits (Scientist C)
(a) Essential:

(i)

Master’s Degree in Physical/Chemical/Biological/Earth-atmospheric/Environmental/Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Bachelor’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences (minimum 4 year degree course) from a recognised University or
Institute

(ii)

four years’ specialised experience in research and development or Industrial or academic institutions or science
and technology organisations. The experience shall be of a specific nature relevant to the job requirements
of the post.

(b) Desirable:
(i)
Doctorate Degree in Physical/Chemical/Biological/Earth-atmospheric/Environmental/Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Master’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences from a recognised University or Institute

(ii)

experience in coordination, policy planning and project development in the area of new and renewable
sources of energy.

Note 1: The educational qualifications and areas of experience according to the requirements of the post shall
be specified at the time of recruitment by the Government.
Note 2: The period spent to acquire essential qualifications including doctorate degree before joining an organisation
shall not be counted as field experience.
(B) Grades from which deputation (including short-term contract)/ absorption to be made (Scientist ‘C’)
Scientists or Technologists working in the Central Government or State Governments or universities or recognised research
institutions or semi-Government or statutory or autonomous organisations in India or abroad:
(a) (i) holding analogous post on regular basis; OR

(ii) With five years’ service in the grade rendered after appointment thereto on regular basis in Level 10 of the 7 th
CPC pay matrix or equivalent; AND
(b) possessing the educational qualifications and experience prescribed for direct recruits under serial number 1(A)(a)
above.
Note 1: The period of deputation (including short-term contract) including period of deputation (including short-term
contract) in another ex-cadre post held immediately preceding this appointment in same or some other
organisation or department of the Central Government shall not ordinarily exceed three years, which may be
extended further on year to year basis, subject to a maximum of seven years with the approval of the
competent authority and in terms of extant guidelines.
Note 2: Departmental candidates in the feeder category, who are in the direct line of promotion under RFCS shall not
be eligible for consideration for appointment on deputation except for the ex-cadre post for which they are
not the feeder grade officers. Similarly, deputationists shall not be eligible for consideration for promotion
under RFCS.
Note 3: The maximum age-limit for appointment by deputation (including short-term contract) shall not exceed fiftysix years or as prescribed by Government from time to time, as on the closing date of receipt of applications.
Page 6 of 15

<!-- page 8 -->

Note 4: Scientists from Central Government or State Governments or Union territory Administration shall be eligible
for absorption.
2. (A) Educational and other qualifications required for direct recruits (Scientist ‘D’)
(a) Essential:
(i)

Master’s Degree in Physical/Chemical/Biological/Earth-atmospheric/Environmental/Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Bachelor’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences (minimum 4 year degree course) from a recognised University or
Institute.

(ii)

eight years’ specialised experience in research and development or industrial or academic institutions and or science
and technology organizations out of which four years should be in science and technology programmes, planning
development and coordination. The experience shall be of a specific nature relevant to the job requirements of the
post.

(b) Desirable:
(i)
Doctorate Degree in Physical/Chemical/ Biological/Earth-atmospheric/Environmental/ Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Master’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences from a recognised University or Institute.
(ii)

experience in coordination, policy planning, project development in the area of new and renewable sources
of energy including field assignment of original nature in the field of new and renewable energy at scientific
or technical laboratories, institutes, industry, university or associations.

Note 1: The educational qualifications and areas of experience according to the requirements of the post shall
be specified at the time of recruitment by the Government.
Note 2: The period spent to acquire essential qualifications including doctorate degree before joining an organisation
shall not be counted as field experience.
(B)

Grades from which deputation (including short-term contract) / absorption to be made (Scientist ‘D’)

Scientists or technologists working in the Central Government or State Governments or universities or recognised
research institutions or semi-Government or statutory or autonomous organisations in India or abroad:
(a)

(i) holding analogous post on regular basis; OR
(ii) With five years’ service in the grade rendered after appointment thereto on regular basis in Level 11 of the
7th CPC pay matrix or equivalent; AND

(b) possessing the educational qualifications and experience prescribed for direct recruits under serial number 2(A)(a)
above.
Note 1: The period of deputation (including short-term contract) including period of deputation (including short-term
contract) in another ex-cadre post held immediately preceding this appointment in same or some other
organisation or department of the Central Government shall not ordinarily exceed three years, which may be
extended further on year to year basis, subject to a maximum of seven years with the approval of the
competent authority and in terms of extant guidelines.
Note 2: Departmental candidates in the feeder category, who are in the direct line of promotion under RFCS shall not
be eligible for consideration for appointment on deputation except for the ex-cadre post for which they are
not the feeder grade officers. Similarly, deputationists shall not be eligible for consideration for promotion
under RFCS.
Note 3: The maximum age-limit for appointment by deputation (including short-term contract) shall not exceed fiftysix years or as prescribed by Government from time to time, as on the closing date of receipt of applications.
Note 4: Scientists from Central Government or State Governments or Union territory Administration shall be eligible
for absorption.
Page 7 of 15

<!-- page 9 -->

3 (A) Educational and other qualifications required for direct recruits (Scientist ‘E’)
(a) Essential:
(i) Doctorate Degree in all disciplines of Physical/Chemical/ Biological/Earth-atmospheric/ Environmental/
Mathematical/ Computational and Information/Agricultural Sciences from a recognised University or
Institute
OR
Master’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences from a recognised University or Institute.
(ii) ten years’ specialised experience in research or development or design or construction in industrial or academic
or Government institutions or organisations (the experience shall be of a special nature relevant to the job
requirement of the post).
(b) Desirable:
(i)

Experience of handling national and international programmes, with special reference to new and
renewable sources of energy. The experience should cover innovation or research and development or
management or assessment or application or extension or research and development including field
assignment of original nature in the field of new and renewable energy at scientific or technical
laboratories, institutes, industry, university or associations

(ii)

knowledge about overall perspective of national energy problems and policies and ability to direct large
integrated programmes.

Note 1: The educational qualifications and areas of experience according to the requirements of the post shall
be specified at the time of recruitment by the Government.
Note 2: The period spent to acquire essential qualifications including doctorate degree before joining an organisation
shall not be counted as field experience.
(B) Grades from which deputation (including short-term contract) / absorption to be made (Scientist ‘E’)
Scientists or Technologists working in the Central Government or State Governments or universities or
recognised research institutions or semi-Government or statutory or autonomous organisation in India or abroad:
(a) (i) holding analogous post on regular basis; OR
(ii) With five years’ service in the grade rendered after appointment thereto on regular basis in Level 12 of the
7th CPC pay matrix or equivalent; AND
(b) possessing the educational qualifications and experience prescribed for direct recruits under serial number 3(A)(a)
above.
Note 1: The period of deputation (including short-term contract) including period of deputation (including short-term
contract) in another ex-cadre post held immediately preceding this appointment in same or some other
organisation or department of the Central Government shall not ordinarily exceed three years, which may be
extended further on year to year basis, subject to a maximum of seven years with the approval of the
competent authority and in terms of extant guidelines
Note 2: Departmental candidates in the feeder category, who are in the direct line of promotion under RFCS shall not
be eligible for consideration for appointment on deputation except for the ex-cadre post for which they are
not the feeder grade officers. Similarly, deputationists shall not be eligible for consideration for promotion
under RFCS.
Note 3: The maximum age-limit for appointment by deputation (including short-term contract) shall not exceed fiftysix years or as prescribed by Government from time to time, as on the closing date of receipt of applications.
Note 4: Scientists from Central Government or State Governments or Union territory Administration shall be eligible
for absorption.
Page 8 of 15

<!-- page 10 -->

4. (A) Educational and other qualifications required for direct recruits (Scientist ‘F’)
(a) Essential:
(i) Doctorate Degree in Physical/Chemical/Biological/Earth-atmospheric/ Environmental/ Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Master’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences from a recognised University or Institute.
(ii) twelve years’ specialised experience in research or development or design or construction in industrial or
academic or Government institutions or organisations (the experience shall be of a special nature relevant to
the job requirement of the post).
(b) Desirable:
(i)

Experience of handling national and international programmes, with special reference to new and
renewable sources of energy. The experience should cover innovation or research and development or
management or assessment or application or extension or research and development including field
assignment of original nature in the field of new and renewable energy at scientific or technical
laboratories, institutes, industry, university or associations

(ii)

knowledge about overall perspective of national energy problems and policies and ability to direct large
integrated programmes.

Note 1: The educational qualifications and areas of experience according to the requirements of the post shall
be specified at the time of recruitment by the Government.
Note 2: The period spent to acquire essential qualifications including doctorate degree before joining an organisation
shall not be counted as field experience.
(B) Grades from which deputation (including short-term contract) to be made (Scientist ‘F’)
Scientists or Technologists working in the Central Government or State Governments or universities or
recognised research institutions or semi-Government or statutory or autonomous organisation in India or abroad:
(a) (i) holding analogous post on regular basis; OR
(ii) With five years’ service in the grade rendered after appointment thereto on regular basis in Level 13 of the
7th CPC pay matrix or equivalent; AND
(b) possessing the educational qualifications and experience prescribed for direct recruits under serial number
4(A)(a) above.
Note 1: The period of deputation (including short-term contract) including period of deputation (including short-term
contract) in another ex-cadre post held immediately preceding this appointment in same or some other
organisation or department of the Central Government shall not ordinarily exceed three years, which may be
extended further on year to year basis, subject to a maximum of seven years with the approval of the
competent authority and in terms of extant guidelines
Note 2: Departmental candidates in the feeder category, who are in the direct line of promotion under RFCS shall not
be eligible for consideration for appointment on deputation except for the ex-cadre post for which they are
not the feeder grade officers. Similarly, deputationists shall not be eligible for consideration for promotion
under RFCS.
Note 3: The maximum age-limit for appointment by deputation (including short-term contract) shall not exceed fiftysix years or as prescribed by Government from time to time, as on the closing date of receipt of applications.
5. (A) Educational and other qualifications required for direct recruit (Scientist ‘G’)
(a) Essential:
(i) Doctorate Degree in Physical/ Chemical/ Biological/ Earth-atmospheric/ Environmental/ Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute
OR
Page 9 of 15

<!-- page 11 -->

Master’s Degree in all disciplines of Engineering/Technology/ Biotechnology/Medicine or Veterinary
Sciences or Pharmaceutical Sciences from a recognised University or Institute.
(ii) fifteen years’ specialised experience in research or development or design or construction in industrial or
academic or Government institutions or organisations (the experience shall be of a special nature relevant to
the job requirement of the post).
(b) Desirable:
(i)
Experience of handling national and international programmes, with special reference to new and
renewable sources of energy. The experience should cover innovation or research and development or
management or assessment or application or extension or research and development including field
assignment of original nature in the field of new and renewable energy at scientific or technical
laboratories, institutes, industry, university or associations
(ii)

knowledge about overall perspective of national energy problems and policies and ability to direct large
integrated programmes.

Note 1: The educational qualifications and areas of experience according to the requirements of the post shall
be specified at the time of recruitment by the Government.
Note 2: The period spent to acquire essential qualifications including doctorate degree before joining an organisation
shall not be counted as field experience.
(B) Grades from which deputation (including short-term contract) to be made (Scientist ‘G’)
Scientists or Technologists working in the Central Government or State Governments or universities or
recognised research institutions or semi-Government or statutory or autonomous organisation in India or abroad:
(a) (i) holding analogous post on regular basis; OR

(ii) With two years’ service in the grade rendered after appointment thereto on regular basis in Level 13A of the
7th CPC pay matrix or equivalent; and
(b) possessing the educational qualifications and experience prescribed for direct recruits under serial number 5(A)(a)
above.
Note 1: The period of deputation (including short-term contract) including period of deputation (including short-term
contract) in another ex-cadre post held immediately preceding this appointment in same or some other
organisation or department of the Central Government shall not ordinarily exceed three years, which may be
extended further on year to year basis, subject to a maximum of seven years with the approval of the
competent authority and in terms of extant guidelines
Note 2: Departmental candidates in the feeder category, who are in the direct line of promotion under RFCS shall not
be eligible for consideration for appointment on deputation except for the ex-cadre post for which they are
not the feeder grade officers. Similarly, deputationists shall not be eligible for consideration for promotion
under RFCS.
Note 3: The maximum age-limit for appointment by deputation (including short-term contract) shall not exceed fiftyeight years or as prescribed by Government from time to time, as on the closing date of receipt of applications.
6.

Age-limit for direct recruits.-

The upper age-limit for direct recruits in each category of posts shall be as under:Serial
Age limit
Name of the post
number
1.
Scientist ‘C’
35 years
2.

Scientist ‘D’

40 years

3.

Scientist ‘E’

45 years

4.

Scientist ‘F’

50 years

5.

Scientist ‘G’

50 years

(Relaxable for Government servants upto five years in accordance with the instructions or orders issued by the Central
Government from time to time.)
Page 10 of 15

<!-- page 12 -->

Note 1: The crucial date for determining the age-limit shall be the closing date for receipt of applications from
candidates in India (and not the closing date prescribed for those in Assam, Meghalaya, Arunachal Pradesh,
Mizoram, Manipur, Nagaland, Tripura, Sikkim, Union Territory of Ladakh, Lahaul and Spiti District and
Pangi Sub-Division of Chamba District of Himachal Pradeshandaman and Nicobar Islands or Lakshadweep).
7.
Screening and selection process (applicable for direct recruitment and deputation) – The screening and
selection process shall be as prescribed by Central Government. The composition of the Eligibility Committee, Screeningcum-Short Listing Committee and Interview Board shall be as prescribed by the Central Government. However, majority
of the members in the Screening-cum-Short listing Committee and Interview Board, excluding the Chairman shall be
from outside the Ministry of New and Renewable Energy. If considered necessary, the screening process shall include a
written test to be conducted to by the Central Government directly or through any other Central Government agency or
organization having experience and expertise in the area.
8.
The Composition of Screening Committee and Assessment Boards and Approving Authorities of their
recommendations for considering promotions under RFCS shall be as specified in the corresponding entries in the Table
given below:Grade to Composition
Approving
S.
Composition of Level II Approving
of Screening Authority
for
No which
Committee
/Assessment Authority for
promotions Committee
Screening
Board/
DPRC
for Assessment of
shall
be
Committee’s
promotions under Revised Board’s
made
recommendations
Flexible Complementing recommendations
Scheme
(1)
(2)
(3)
(4)
(5)
(6)
The
approving 1. Secretary,
Minister-in-charge,
1
Scientist ‘G’ Screening
authority for the,
Ministry of New and
Committee,
Ministry of New and
Renewable Energy*
shall consist of a recommendations
Renewable Energy
of
the
Screening
Chairman and
- Chairman;
Committee shall be
at least three
the
Secretary,
2.Two Secretaries
of
expert members
Ministry of New
other Scientific Ministries or
to be nominated and
Renewable
Departments
by the
Energy.
The
Secretary,
- Members;
Screening
Ministry of
Committee
will
3.Three eminent
also act as Internal
New and
Scientists at least one
Peer Review Group /
Renewable
level above Scientist ‘G’
Committee.
Energy.
specialising in the field of
Provided that
scientific activity.
at least one
- Members;
Member shall
4. The nominee of the
be from
Department of Personnel
Department of
and Training as per extant
Science and
instructions.
Technology or
- Member
Department of
Space or
Defence
The Level II Committee
Research and
/Assessment Board/ DPRC
Development
shall also function as Special
Organisation.
Peer Review Committee and
shall specifically certify that
the Scientists recommended,
meet all the criteria for
promotion under RFCS.

Note: * The approval of Appointment Committee of Cabinet (ACC) is mandatory in case of appointment /
promotion to the post carrying Level 14 of the 7th CPC pay matrix or above, as on date.
Page 11 of 15

<!-- page 13 -->

2

Scientist ‘F’

Screening
Committee,
shall consist of a
Chairman and at
least three expert
members to be
nominated by
the Secretary,
Ministry of
New
and
Renewable
Energy.
Provided that at
least
one
Member shall be
from
Department of
Science and
Technology or
Department of
Space or
Defence
Research and
Development
Organisation.

3

Scientist ‘C’, Screening
Committee,
‘D’ and ‘E’
shall consist of a
Chairman and at
least three expert
members to be
nominated by
the Secretary,
Ministry of
New
and
Renewable
Energy.
Provided that
At least one
Member shall
Be from
Department of
Science and
Technology or
Department of
Space or
Defence
Research and
Development
Organisation.

The
approving
authority for the,
recommendations
of the Screening
Committee shall be
the
Secretary,
Ministry of New
and
Renewable
Energy.
The
Screening
Committee
will
also act as Internal
Peer Review Group /
Committee.

1. Secretary,
Ministry of New and
Renewable Energy
- Chairman;

Minister-in-charge,
Ministry of New and
Renewable Energy

2. Two Secretaries
of
other Scientific Ministries or
Departments
- Members;
3. Three eminent
Scientists at least one
level above Scientist ‘F’
specialising in the field of
scientific activity.
- Members;
4. The nominee of the
Department of Personnel
and Training as per extant
instructions.
- Member

The Level II Committee
/Assessment Board/ DPRC
shall also function as Special
Peer Review Committee and
shall specifically certify that
the Scientists recommended,
meet all the criteria for
promotion under RFCS.
The
approving 1. Secretary,
Ministry of New and
authority for the,
Renewable Energy or his
recommendations
nominee not below the
of the Screening
rank
of
Additional
Committee shall be
Secretary
the
Secretary,
Ministry of New
- Chairman;
and
Renewable
Energy.
The
Screening
2. Two
Group Heads in
Committee
will
Ministry of New and
also act as Internal
Renewable Energy.
Peer Review Group /
- Members;
Committee.
3. Three experts not below
the level of Scientist ‘G’
from outside the
Department including at
least one
from
Department
of Science
and
Technology
or
Department of Space or
Defence Research
Development
Organisations
-Members;
Page 12 of 15

Minister-in-charge,
Ministry of New and
Renewable Energy

<!-- page 14 -->

SCHEDULE III
[See rule 5]
(Revised Flexible Complementing Scheme)
1. The Revised Flexible Complementing Scheme (RFCS) is a promotion scheme for Scientists for which criteria
shall be proven merit and records of research. The assessment norms for promotion under RFCS shall be rigorous. Due
emphasis shall be laid on evaluation of professional contribution and technical knowledge to ensure that only Scientist
having to their credit, demonstrable achievements, higher level of technical merit are recommended. Scientists
recommended shall not only possess the requisite qualifications, but, should also be engaged in scientific and innovative
activities as distinct from mere application to technical knowledge and further, the function discharged by them are relatable
or identifiable to their academic specialization.
2. Scientists or technical experts doing management or administrative work in the Ministries shall not be
considered for promotion under RFCS. However, they shall be given benefit of upgradation under the Modified
Assured Career Progression Scheme.
3. Scientific Activities and Services would be as defined in Annexure I of the RFCS.
4. The Scientists appointed on deputation (including short-term contract) shall not be eligible for promotions
under Revised Flexible Complementing Scheme (RFCS). Only regular Scientists of the Ministry of New and
Renewable Energy shall be eligible for RFCS promotion.
5. There shall be no retrospective promotion/upgradation under RFCS. The promotion/upgradation under RFCS
shall be effective from the date these are approved by the Competent Authority. Officers on leave or on deputation
outside the organisation can be given promotion only with effect from the date they rejoin or return to the parent
cadre.
6. The promotions under RFCS shall be limited for making promotions to scientific posts in Level 11 to Level 14 in the
Pay Matrix.
7. The promotion under RFCS shall be applicable only to those Scientists and Technologists who hold scientific posts
and are engaged in scientific and technical activities as defined by RFCS. For promotions under RFCS, the Scientists
shall possess the following academic qualification; namely:Master’s
Degree
in
Physical/Chemical/Biological/Earth-atmospheric/Environmental/Mathematical/
Computational and Information/Agricultural Sciences from a recognised University or Institute;
OR
Bachelor’s Degree in Engineering/ Technology/Biotechnology/Medicine or Veterinary Sciences or
Pharmaceutical Sciences (minimum 4 year degree course) from a recognised University or Institute.

8. All the posts covered under RFCS shall carry the following uniform levels in the pay matrix, designation and
the minimum residency period linked to performance as follows:—
Serial
number
1.
2.
3.
4.
5.
6.

Level in pay matrix
Level 10
Level 11
Level 12
Level 13
Level 13A
Level 14

Designation
Scientist ‘B’
Scientist ‘C’
Scientist ‘D’
Scientist ‘E’
Scientist ‘F’
Scientist ‘G’

Page 13 of 15

Minimum residency period
linked to performance
3 years as Scientist - B
4 years as Scientist - C
4 years as Scientist - D
5 years as Scientist - E
5 years as Scientist - F

<!-- page 15 -->

9. The following types of leave availed by an eligible scientist/period spent on deputation shall be counted towards
minimum residency period required to be put in by the Scientists in the lower grade for consideration of
promotion/upgradation under the Scheme:
(a)The period spent on deputation/Foreign Service to another scientific post, which helps a Scientist to acquire
scientific experience in a diverse set up.
(b) Period of Study Leave/any other Leave taken for academic accomplishments to improve scientific
knowledge.
(c) Maternity Leave sanctioned as per Leave Rules.
(d) Leave of a maximum period of one year sanctioned in continuation of maternity leave as per Leave Rules.
(e) Earned Leave for a total period not exceeding 180 days (for 3 year residency period), 210 days (for 4 year
residency period), 240 days (for 5 year residency period) sanctioned as per Leave Rules.
(f) Child Care Leave sanctioned as per Rules.
10. The period spent on deputation/foreign service to a non-scientific post and the period of leave including leave on
medical grounds, EOL etc. availed on personal grounds shall not count towards the minimum residency period.
11. Exceptionally Meritorious Category- Based on assessment parameters and the recommendation by the Internal
Screening Committee [refer to point ix(A) of RFCS], not more than 10 per cent of the Scientists may be granted
relaxation in the residency period by the Departmental Peer Review Committee [refer to point ix(B) of RFCS] for all
levels, the relaxation being not more than one year on any single occasion, limited to a maximum of two occasions in
their entire career
12. The assessment process under the Scheme for promotion/ Upgradation to the next grade would be conducted only
thrice and thereafter, the scientist would be covered under Modified ACP scheme (MACP) as approved for Central
government civilian employees. The Scientist who has been granted any grade under MACP can be Considered for
next grade according to the eligibility and other provisions of the Scheme. This is expected to provide an alternate
channel for development for development for scientist and I s expected to maintain the rigors of assessment required
for assessment under the Scheme.
13. The Revised Annual Work Report (AWR) format to capture scientific content of work performed has been
designed and enclosed as Annexure III to the RFCS. The revised AWR (part A) would be filled up by the officer
reported upon along with the revised Annual Performance Appraisal Report (APAR) format enclosed as Annexure
IV to the RFCS. Both AWR and APAR would be filled mandatorily on an annual basis.
14. The assessment process of the Board shall be as under:
The assessment would be done twice in a year. Cases of those Scientists who have completed or will
complete the minimum residency period as on the cut-off dates of assessment viz. 1st January or 1st July,
as the case may be and have earned or will earn number of annual ACRs/APARs equal to or more than
the number of years of minimum residency period for the period preceding the cut off dates of
assessment, shall be considered for assessment under the Scheme.
15.
There shall be two level of assessment for RFCS. The assessment procedure shall be as under:
(A) Level I Screening (Internal Screening Committee)
(a)
An internal Screening Committee shall be constituted by the Central Government for evaluation of annual work
report vis a vis the criteria for promotion/upgradation under RFCS. An external member, from the Departments of
Atomic Energy, Space or DRDO, shall be co-opted in the selection process. The Internal Screening Committee
would report on the scientific content of work done by the scientists/engineers who meet the benchmark of ‘Good’
for Scientist C and ‘Very Good’ for Sci. ‘D’ and above. The Internal Screening Committee would submit their
recommendation in Part C of the Revised AWR reporting format, alongwith comparable parameters for
consideration in Level 2 Screening.
Page 14 of 15

<!-- page 16 -->

(B) Level 2 Screening (Assessment Board / Departmental Peer Review Committee).(a)

(b)

(c)
(d)

(e)

The assessment boards constituted in each scientific Ministry/Department shall undertake Level-2 screening for
assessment of scientists and furnish their recommendation for promotion/upgradation from Scientist ‘C’ upto
Scientist E. The assessment board would also have a majority of external members possessing expertise in the field.
The assessment board would have the characteristic of independent peer group for the assessment of the scientific
content of the work. Greater emphasis is to be placed on achievement as evaluated by an independent peer group
rather than on seniority only. The assessment board shall document specifically through one page summary, the
specific content of the work done.
The Departmental Peer Review Committee (DPRC) constituted in each scientific Department/ Ministry shall
undertake level 2 screening for assessment of scientists and furnish their recommendation for promotion/upgradation
for Scientist ‘F’/ Scientist ‘G’. The proposals involving relaxation/assessment in residency period in respect of
exceptionally meritorious Scientists for consideration of promotion/upgradation from Scientist C upto Scientist G
shall also be considered by DPRC. The DPRC shall document specifically through one page summary, the specific
content of the work done.
The Assessment Board/DPRC should specifically certify that the Scientists recommended met with all the criteria
for promotion/upgradation under the Scheme.
Field experience in research and development and/or experience in implementation of such scientific projects is
compulsory for promotion/upgradation of scientists recruited to the posts in the Secretariat of the Scientific
Ministries/Departments to higher grades under the Scheme. Field experience of at least two years and five years
respectively will be essential for promotion/upgradation to Scientist F and Scientist G grades respectively.
The criteria for field experience for different scientific activities have been elaborated under Scientific Activities and
Services in Annexure I of RFCS.

16. Candidates who do not qualify either in Level-I screening or Level-2 screening shall be re-assessed only after one
year when they earn at least one more APAR and AWR. Such re-assessment would again entail Level-I and Level-2
Screening and not commence from the stage where the Scientist failed to qualify.

Page 15 of 15
