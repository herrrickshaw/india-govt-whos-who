---
doc_id: "1b7b8cc8befa73a8"
source_url: "https://powermin.gov.in/static/uploads/2025/07/8ea07542c917ed7c66f604092efd2b08.pdf"
ministry: "Power"
title: "Electricity (Third Amendment) Rules, 2024"
date: "2025-07-01"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "6039798c2ac83d4c"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-13032024-252954
xxxGIDHxxx
CG-DL-E-13032024-252954
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 169]

नई दिल्ली, मंगलिार, माचच 12, 2024/फाल्गुन 22, 1945
NEW DELHI, TUESDAY, MARCH 12, 2024/PHALGUNA 22, 1945

No. 169]

जिद्युत मंत्रालय
अजधसूचना
नई दिल्ली, 12 माचच, 2024
सा.का.जन. 181(अ).—के न्द्रीय सरकार, जिद्युत अजधजनयम, 2003 (2003 का 36) की धारा 176 द्वारा प्रित्त िज‍तयों का
प्रयोग करते हुए, जिद्युत जनयम, 2005 का और संिोधन करने के जलए जनम्नजलजखत जनयम बनाती है, अर्ाचत्:
1.

2.

(1)

इन जनयमों का संजिप्त नाम जिद्युत (तीसरा संिोधन) जनयम, 2024 है।

(2)

ये रािपत्र में इनके प्रकािन की तारीख से प्रिृत्त होंगे।

जिद्युत जनयम, 2005 के , जनयम 19 के , उप-जनयम (1) में, खंड (क) के स्ट्र्ान पर जनम्नजलजखत खंड रखा िाएगा, अर्ाचत्:
“(क) कें रीय सरकार आिेि द्वारा ऐसे आिेि में उपबंजधत तारीख से तीन िर्च की अिजध के जलए निीकरणीय ऊिाच
श्रोतों की जिजभन्न श्रेजणयों के जलए अलग-अलग कें रीय पूल गठित कर सके गी।”
[फा. सं. 23/18/2022-आरएंडआर]
श्रीकांत नागुलापल्ली, अपर सजचि

ठिप्पण: मूल जनयम भारत के रािपत्र, भाग-II, खंड 3, उप-खंड (i) में संखयांक सा.का.जन. 379 (अ), तारीख 8 िून, 2005 द्वारा
प्रकाजित दकए गए र्े और अंजतम बार सा.का.जन. 45 (अ), तारीख 17 िनिरी, 2024 द्वारा संिोजधत दकए गए र्े।

1860 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF POWER
NOTIFICATION
New Delhi, the 12th March, 2024
G.S.R. 181(E).—In exercise of the powers conferred by section 176 of the Electricity Act, 2003 (36 of
2003), the Central Government hereby makes the following rules further to amend the Electricity Rules, 2005,
namely:1.

(1) These rules may be called the Electricity (Third Amendment) Rules, 2024.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.
In the Electricity Rules, 2005, in rule 19, in sub-rule (1), for clause (a), the following clause shall be
substituted, namely:“(a) the Central Government may, by order form distinct central pools for different categories of
Renewable Energy Sources for a period of three years from the date provided in such order.

[F. No. 23/18/2022-R&R]
SRIKANT NAGULAPALLI,Addl. Secy.

Note: The principal Rules were published in the Gazette of India, Part-II, Section 3, Sub- section (i) vide number
G.S.R 379 (E), dated the 8th June, 2005 and was last amended vide G.S.R 45 (E), dated the 17th January, 2024.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by

AMIT KUMAR AMIT KUMAR JAISWAL
Date: 2024.03.13
JAISWAL
20:05:19 +05'30'
