---
doc_id: "1ccaf74e87ed08fe"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/d0f1b53140c8932c4b26ff9918e854c9.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "TransferPosting in the Junior Time Scale of Indian P&T Accounts & Finance Service Group A in DoT HQ"
date: "2025-12-25"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d19ec17052201ed4"
---

<!-- page 1 -->

den 04-04/2025-SEA-I
ana ear / Government of India
tan darera / Ministry of Communications
gute feat / Department of Telecommunications
wan war, 20, aeite ws / Sanchar Bhawan, 20, Ashoka Road
नई दिल्‍ली-110 001 / 1४९७ Delhi-110 001
दिनांक : 21.08.2025
ORDER
Subject: Transfer/ Posting in the Junior Time Scale (JTS) of Indian P&T Accounts &
Finance Service Group ‘A’ in DoT HQ.
कक के
The following transfer/posting in Junior Time Scale (JTS) of Indian P&T Accounts &
Finance Service, Group ‘A’ in DoT HQ is ordered with immediate effect: -
Staff / Name of the officer Present posting
No.
1 83514 | Ms. Chinchkhede ACAO (WPF), DoT HQ: | ACAO, O/o DDG
Pallavi Devidas (Media), DoT HQ*
* Against overall strength.
2. Charge Report may be sent to all concerned.
This is issued with the approval of the Competent Authority. doy
i
(ज्योति नेगी)
(Jyoti Negi)
अवर सचिव (एस ई ए )
Under Secretary (SEA)
Ph : 23036126
Copy to: -
1. PSO to Secretary (T), DoT.
2. PSO to Member (F), DCC.
3. PSO/CS to Advisor (F).
4. Sr. DDG (LFA), DoT HQ.
5. CVO, DoT.
6. All DDGs of Accounts & Finance Wings/ DDG (Media), DoT HQ.
7. Officer Concerned.
8. ACAO (SEA-II), DoT HQ for uploading on website.
9. Sr. AO (CS & Protocol), DoT HQ.
10. SO (Pay Bill/G-I/G-II/Library/PHP/Cash Section), DoT HQ, New Delhi.
11. Guard File/P.F.
