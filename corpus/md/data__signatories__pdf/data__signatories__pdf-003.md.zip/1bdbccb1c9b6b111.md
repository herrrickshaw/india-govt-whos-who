---
doc_id: "1bdbccb1c9b6b111"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/9f0c5fdacc9d438fbfb9cf9870c9ddb6.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Circulation of OM regarding Nomination of Officers for Liaison Duty during Kailash Manasarovar Yatra (KMY) 2025-reg."
date: "2025-05-05"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f9d5f4e25908bf1f"
---

<!-- page 1 -->

A.19011/30/2019-Estt.(Hqrs.)/(E-17818)
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
(Department of Animal Husbandry and Dairying)
Krishi Bhawan, New Delhi,
Dated, the 5! May, 2025
OFFICE MEMORANDUM

Subject: Circulation of OM regarding Nomination of Officers for Liaison Duty

during Kailash Manasarovar Yatra (KMY) 2025-reg.

The undersigned is directed to refer to the Ministry of External Affairs’ OM No.
E/122/12017-KMY dated 30.04.2024 (copy enclosed) on the above mentioned subject
regarding the nomination of officers for Liaison Duty during Kailash Manasarovar Yatra
(KMY) 2025, the same is being circulated for information and necessary action among
all the eligible officers of the Department.

Ds Further, all Divisions are requested to disseminate this OM among the officers
within their respective administrative offices, encouraging eligible officers to apply by
the specified deadline of 13 May 2025.
Encl: As above
222
dbp 5
oes!
(Pankaj Kumar Sinha)
Under Secretary to the Government of India
Tel: 011-23382779
To
1. All the officers of DAHD through e-office Notice Board.
2. US(C&DD)/US(LH)/US(NLM)/US(AQCS/CEAH)
Copy for information to:-
PPS to JS(Admin & Coord), DAHD
i ee

<!-- page 2 -->

Ministry of External Affairs
(East Asia Division)
OFFICE MEMORANDUM
No, E/122/1/2017-KMY Date : 30.04.2025
Subject : Liaison Officers for Kailash Manasarovar Yatra-2025.

The Ministry of External Affairs (MEA), Government of India, will be organising the Kailash
Manasarovar Yatra (KMY) during June to August 2025. The Yatra is a pilgrimage to Mount
Kailash and Lake Manasarovar in the Tibet Autonomous Region of the People’s Republic of
China. The Ministry of External Affairs appoints two Liaison Officers to accompany each batch
of pilgrims. Detailed information about the Yatra, duration, itinerary for each batch is available
on the website https://kmy.gov.in
2. Applications are invited from serving officials equivalent to the rank of Under Secretary
and above in Ministries/Departments of the Government of India, State Governments, etc.
Interested officers may register online at the website https://kmy.gov.in before last date which
is 13.05.2025. :

3. The terms and conditions for LO duty are as under :-
i; The LOs who are serving Government servants, would be on Government duty during the
Yatra and are required to extend all possible assistance to his /her batch during the Yatra.
ii. LOs are required to do the Yatra with the assigned batch only. Request for change of
batch will not be normally entertained by the Ministry of External Affairs. Request for change of
batch on personal grounds will be rejected. No mutual exchange of batch among LOs is
permissible. However, the Ministry of External Affairs reserves the right to change the batch of
LOs on functional grounds, administrative exigency or in public interest.
iii. The Kailash Manasarovar Yatra is arduous and involves trekking at high altitudes of up to
19,500 feet, under inhospitable conditions. Therefore, applicant must be physically fit and
healthy, and should not suffer from any medical condition like high-blood pressure, diabetes,
asthma, heart disease, epilepsy etc.
iv. Officer applicants may also note that there are two routes for the Yatra, viz., Lipulekh
Pass in Uttarakhand and Nathu La in Sikkim. LOs are not at liberty to choose the route. The
Ministry of External Affairs will allot routes on public interest and functional grounds.
v. Officers who have performed the duty of LOs in any previous year(s) are eligible to apply.
They may clearly mention the year and the route (Lipulekh/Nathu La) on which they had
undertaken the Yatra. However, selection of such officers is subject to availability of slots.
vi. All admissible expenditure on travel, board and lodging of the Liaison Officer as given in
the table “Fees & Expenditure of Liaison Officer”, would be borne by the Department concerned.
No amount is payable to MEA, or reimbursed by MEA to the applicant/selected LO.
vii. The Kailash Mansarovar Yatra has been recognised as a trekking expedition by the Indian
Mountaineering Foundation and may involve high risk to the person or property caused by any
natural calamity or due to any other reason. The Government of India shall not be responsible
for any loss or damage to the person or property of the Liaison Officer, except as admissible
under the Government of India rules. Therefore, the official selected as Liaison Officer will be
required to submit an Indemnity Bond before proceeding for the Yatra, in the prescribed format,
on a non-judicial stamp-paper of the value prescribed by the State Government concerned, and
attested by first class Magistrate or Notary Public.
ra कम घर Conte! a
rrr

<!-- page 3 -->

2

viii. Applicants may note that expenditures incurred by them for their medical examination is

not refundable, irrespective of whether or not they are allotted batch or actually perform the

Yatra.

ix, Since LO duty is strictly an official duty, all officer Applicants are advised to refrain from

bringing or attempting to bring any political or other outside influence to bear upon any superior

authority to further his/her interests. All such cases would be treated as per the provisions of

the relevant conduct rules.

x. It is the responsibility of the Liaison Officer(s) to reconfirm to MEA 14 days before

assembly of his/her batch in Delhi that all the requisite administrative and financial approvals

and official passports are in place. Failure to do so would result in cancellation of his/her LO

duty without any further notice. Further, LOs may please ensure that their office is aware of the

period of absence. Officers who fail to proceed on the Yatra on any ground whatsoever without

sufficient notice to MEA will be debarred from undertaking the Yatra in future as LO.

xi, LOs may also note that mobile/telephone connectivity may not be available at various

stretches of the Yatra due to difficult and mountain terrain. :

xii. The Ministry of External Affairs reserve the right to prescribe/amend terms and conditions

of the LO duty in public interest.

4. Duties for LO duty are as under

i, LOs are also responsible for ensuring the well-being and safety of the group.

ii. The LOs will liaise with Indian, and Chinese authorities on behalf of the pilgrims in all

respects, including communication, medical requirements, air-evacuation in case of emergency

etc.

iii. Each Liaison Officer is required to submit a report on the Yatra within seven days of

return from the Yatra and to share his/her experience with the next outgoing Batch. It will also

be the responsibility of the Liaison Officer to ensure delivery of Yatra Completion Certificates

from the Ministry to the Yatris on completion of the Yatra. Further, if LOs of any Batch decide to

withhold Certificate from any Yatri, full facts of the matter must be communicated to MEA, in

writing,

iv. LOs may also note that they would be required to manage a diverse group of persons from

different linguistic, regional and professional backgrounds.

v. LOs would take appropriate steps in case of medical emergency/death of any Yatri in

his/her batch. They may also note that the first point of contact in such cases is the District

Administration/service provider (KMVN on Lipulekh/STDC on Nathu La route) when the batch

is in India and the Embassy of India, Beijing, when the Batch is in China. MEA also may be kept

informed.

vi. Further instructions on duties and responsibilities will be communicated to the selected

LOs who have been allocated a batch.

How to apply:

5. Print out of the signed application must be forwarded in original with requisite

verification/approval mentioned in para 6 & 7 by the Competent Authority in the respective

Ministry/Department well in advance and before last date, and sent only by post, with the

envelope being superscribed “Application for Liaison Officer”, to:

The Attache (China)

Ministry of External Affairs

Room 255A, South Block,

New Delhi - 110011. Tel: 23014900

FF 2025 Laon OFour Core) Q 3 /-
a

<!-- page 4 -->

- 3-
Incomplete applications or those received after the last date will be summarily rejected. No
request/correspondence will be entertained by the Ministry in this regard. The last date for
receipt of physical application, complete in all respects, at MEA is 13.05.2025.
6. The competent authority forwarding the application for Liaison Officer must certify the
following :
i. Name and details of the applicant is correct and complete as per records.
ii, Applicant is equivalent in rank to Under Secretary or above in Govt. of India.
iii. Administrative approval has been accorded by Head of Office/cadre controlling authority |
for this duty.
iv. The official will be available for duty any time during the period June to September.
v. Inability to perform this duty for any reason will be conveyed in writing in advance to
MEA.
vi. Admissible expenditure for the duty as LO will be borne by the department forwarding the
application. :
vii. Financial sanction would be issued after confirmation of selection by MEA for this duty.
viii. TA claim of the official will be settled on the basis of Yatra Completion Certificate issued
by MEA.
8 The forwarding letter of the competent authority must also contain the name, complete
office address, office telephone, fax number, official email ID etc. of the administrative
head/cadre controlling authority in the respective Department for facilitating correspondence.
Applications forwarded without the above certification, or details of competent authority will be
treated as incomplete and would not be considered for the selection process.
8. Selection of LOs :
ds Schedule for the medical tests and interview would be communicated to the email ID of
the applicant as given in the application. Applicant must ensure that the coordinates are
accurately filled in during on-line registration.
ii. LOs would be selected on the basis of medical fitness test conducted at designated
hospital in Delhi, and the personal interaction with a panel of senior officers, who will, inter alia,
judge, social skills, temperament, previous experience, high altitude trekking/first aid
experience, ability to manage the batch under stressful situations in a foreign country and
situations arising in emergencies, medical, natural or otherwise. The Interaction Panel’s decision
in this regard is final and no requests/correspondence in this regard will be entertained.
iii. Applicant officers may further note that MEA reserves the right to reject, shortlist, call for
interview/medical tests of all or any of the applicant officers. It also reserves the right to allot
any batch or any route, change batch/route allocation at short notice, in public interest. No
request in this regard from LOs would be entertained.
‘lle
(Shafiur Rabbi) =
Under Secretary (East Asia)
Tel: 011-23012847
To:
1. Officers of the rank of Under Secretary and above in the Ministry of External Affairs, New
Delhi.
2. Joint Secretaries (Administration/Personnel) in Ministries / Departments of the Government
of India, with a request to circulate this in the respective Ministries/Departments.
3. All Joint Secretaries (Administration/Personnel) in State Governments with a request to
circulate this appropriately.
ate 2025-- Liason Offoor
Cod. P- 4):
I न नाना 99999 99999 999५७ 00...

<!-- page 5 -->

4. All Resident Commissioners of State Governments in Delhi.
5.All RPOs.
: |
|
sete 2025 tion Ooo

<!-- page 6 -->

aaa e So Wega महा त 1 3 1
बा [URGE ROUTE | 0 DETAILS लि नि लि बल
|1_ |Rs.5,000 Confirmation Amount payable according to route for the Yatra Rs.5,000
| to KMVN ( Non-refundable if confirmed in any batch ) to STDC ।
i SEs: 0 02102240:2-15: 0 «2 2 :
ee Balance Amount Payable (in advance / before departure) |
t ee eee
a | Kumaon Mandal Vikas Nigam Ltd. (KMVN) | |
| | A/c No :917020011800582 Axis Bank Ltd, Mallital, Nainital are

| Rs.51, y A |

| 000 IFSC : UTIBOO03012 MICR ; 263211302 | AS
| be Sikkim Tourism Development Corporation Ltd. eas |
13 | KB A/c No: 915020028840818 AXIS BANK,GANGTOK Rs.35,000 |
{ | 15९ : UTIBOOO0112__ NEFT :UTIBO000112 1
4 Return Air fare Delhi - Baghdogra — Delhi sectors |
{ @ ( bookings arranged by, and payable to STDC in advance ) | Rs5.20,000 | |

i (Airfare & Cancellation refund as per airline policy ) | |
| 1
न किला an eres 2228
15 |Rs.5,500 Medical tests — payable to Delhi Heart & Lung Institute (DHL!) Rs.5,500
16 | Rs.2,500 Stress Echo Test, ( if required and advised by DHL! ) Rs.2,500 |
ee | a m2a00 [chinese Vise fee(tobecollededincashatOM) 77 he
8 Pony/porter and pony handler charges | ]
| (Yet to be fixed by Uttarakhand Government) |

|

ne Expenses |

z |

19 Contribution to Poo! Money for group activities. Rs.4,000 |

10 | Actuals Wages for Hiring cooks for the batch, common food purchases, etc. Actuals |

11 |@25%for3days | DA(US$150/-) as applicable to the grade of the officer on the Chinese side. | @ 25% for 6 days

(@100% for 5 days _|DA (US$150/-) for the remaining period. @ 100% for 5 days

|

| Payable in Tibet Autonomous Region (TAR) |

/13. | US$:1200 For lodging, transport, entry tickets etc. USS: 2,400 |

It includes US $1 towards immigration fee. |
+ ANY AMOUNT PAID AT ANY STAGE IS NOT REFUNDABLE
1 AMOUNT PAID CANNOT BE TRANSFERRED TO ANY OTHER PERSON
« ** These expenditures are subject to change.
YA — Lanon OFeat
