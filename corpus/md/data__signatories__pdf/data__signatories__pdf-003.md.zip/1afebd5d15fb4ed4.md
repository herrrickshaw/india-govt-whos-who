---
doc_id: "1afebd5d15fb4ed4"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/8e8d9e824cdf3ecb6584c89f8aad3c36.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code ‘155276’ to Department of Mission Shakti, Government of Odisha"
date: "2023-10-10"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "34a991c23f796225"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No. 16-212023-ASIShortCodes/)7. Dated: 10.10.2023
To,
All Access Service Providers.

Subject:- Allocation of short code ‘155276’ to Department of Mission Shakti,

Government of Odisha - reg.

The undersigned is directed to convey the allocation of Short code ‘155276’

to Department of Mission Shakti, Government of Odisha for addressing of ‘Self Help

Group’ queries and grievances with following features:

i. Category-I: Service (i.e. mandatory service to be provided by all the
Access service providers).
ii. Accessibility: Restricted i.e. within state only
iii. Metered Service: It may be taken as Called Party Pays
iv. The short code shall be terminated on Toll free number 1800-345-7670
2. All are requested to take necessary action.
3. This is issued with the approval of DDG (AS).
~AS >
ae
(Trilok Chandra)
Director (AS-IIT)

Copy forwarded for information and necessary action, if any, to:

1. Secretary, TRAI.

2. CMD MTNL/ BSNL.

3. Smt. Sujata R. Karthikeyan, IAS, Commissioner cum Secretary,

Department of Mission Shakti, Lokaseva Bhawan, Bhubaneswar- 751001 w.r.t.
letter dated 17.08.2023. The Nodal officer details are Mr. Sujit Kumar Lala, with
e-mail pmumissionshakti@gmail.com with office number as 0674 - 2974093 may
contact Sr. DDG (LSA), LSA unit for concerned States/UTs.

4. Director (T), DoT HQ, (respective LSA field may be asked to co-ordinate with
respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).

5. A copy for upload on DoT Website.
