---
doc_id: "1a974fc69bbbba9a"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_68b5682bcf5506.51438098.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Order- UPSC has approved the Select Lists for promotion from SFS of Madhya Pradesh Cadre to the Indian Forest Service of the name of Dr. Shailendra Kumar Gupta, order dated 26-08-2025"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f15b2a6f8f148d8f"
---

<!-- page 1 -->

No.17013/12/2025-IFS.I1
Government of India
Ministry of Environment, Forest and Climate Change
Indira Paryavaran Bhawan,
6th Floor, Prithvi Block,
Jor Bagh, Ali Ganj, New Delhi-110003
Dated: the 26August, 2025
Order
In exercise of the provisions contained in Sub-Regulation 3 of Regulation 7
of the Indian Forest Service (Appointment by Promotion) Regulations, 1966, Union
Public Service Commission has approved the Select Lists for promotion from State
Forest Service of Madhya Pradesh Cadre to the Indian Forest Service for the
Select List Year 2008-A containing the name of Dr. Shailendra Kumar Gupta
of the State. Forest Service of Madhya Pradesh Cadre, towards filling up of
promotion’ quota vacancies available in Madhya Pradesh Cadre, of the Indian
Forest Service. |
ach (OB ore
(Pradip Kumar)
. fee eee oe Under Secretary to the Government of India
Tel:01 1-20819360
Copy to:
1. The Chief Secretary, Govt. of Madhya Pradesh, Bhopal- It is requested that the
officer may please be informed of the aforesaid Select List under intimation to this
Ministry. The State Government is further requested to forward necessary proposal
for promotion of the eligible officer to the Indian Forest Service along with the
following documents to this Ministry immediately:
i. A declaration as to singular marital status.
ii, Written consent for termination of lien in the State Forest Service on
confirmation in the Indian Forest Service. है
ii. A certificate by the State Government that there is no stay order of any court
prohibiting the appointment of State Forest Service officers by promotion to
the Indian Forest Service, Tamil Nadu.
iv. A certificate by the State Government, that there is no disciplinary/Vigilance
case pending/contemplated against the officers recommended for promotion.
v. A Certificate by the state Government that the officers are in service as on
date.
2. The Principal Secretary (Forests), Govt. of Madhya Pradesh, Bhopal.
3. The Principal Chief Conservator of Forests & HoFF, Govt. of Madhya Pradesh,
Bhopal.
4. The Secretary, Union Public Service Commission, New Delhi.
5. Guard File/website copy.
