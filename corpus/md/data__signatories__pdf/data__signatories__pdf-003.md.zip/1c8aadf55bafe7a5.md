---
doc_id: "1c8aadf55bafe7a5"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/792e4fb23a13914926076983e233c900.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Restriction on political activities of employees of PSUs."
date: "1984-07-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "97801457d18e88b1"
---

<!-- page 1 -->

CHAPTER-II
PERSONNEL POLICIES
(f) Conduct, Discipline & Appeal Rules
7. Restriction on political activities of employees of PSUs.
The Committee of Secretaries in their meeting held on 30.10.81 had suggested that an
exercise may be undertaken by the Bureau of Public Enterprises/Department of Personnel in
consultation with other Ministries/ Departments to identify the undertakings, irrespective of
the manner of their incorporation, which are performing sovereign functions of the
Government and other essential services such as security, defence etc., so as to consider the
question of placing reasonable restrictions on political activities by their employees in the
public interest.
2. The opinion of the Law Ministry who were consulted by the Ministry of Home Affairs in
this regard was that it was open to the employer to evolve executive policy in order to restrict
the activities of his employees, regulating the discipline amongst them according to the
compulsions of the circumstances so long as such restrictions were reasonable, fair and not
grossly unjust.
3. Any measure whereby political activities of the employees of the Public Enterprises are
sought to be restricted in the above manner could not be regarded as unreasonable or unjust
and, therefore, the view of the Law Ministry is that there appeared to be no legal objection to
imposing the aforesaid restrictions.
4. An exercise has been carried out by the Ministry of Home Affairs in consultation with us
and the following public enterprises under your administrative control have been identified as
sensitive for this purpose.
5. The following kinds of activities of the employees could be prohibited by amending the
Certified Standing Orders or the CDA rules, as the case may be:
(i) to be an office-bearer of a political party or an organization which takes part in politics ;
(ii) to take part in or assist in any manner in any movement/agitation or demonstration of a
political nature ;
(iii) to take part in an election to any legislature or local authority ;
(iv) to canvass in any election to any legislature or local authority.
6. If you have any reservation in this regard or if there are any other enterprises under your
administrative control in which you would like to place similar restrictions, kindly get in
touch with the Ministry of Home Affairs (I.S. Division) under intimation to the BPE.
(BPE D.O. No. 15(7)/83-GM dated 21st July, 1984

<!-- page 2 -->

ANNEXURE-I
Name of the
addressees

Companies involved

1. Shri. Thomas Kora, Indian Telephone Industries
Secretary, Ministry of
Communication
2. Sh. M.C Sarin, Bharat Dynamics Ltd., Bharat Electronics Ltd., Garden Reach
Secretary,
Defence Shipbuilders & Engineers Ltd., Goa Shipyard Ltd., Hindustan
Production
Aeronautics Ltd., Mazagon Dock Ltd., Mishra Dhatu Niagam Ltd.,
and Praga Tools Ltd. (Total 8)
3. Shri S. B.
Secretary,
Deptt. of Coal

Lal, Bharat Coking Coal Ltd., Central Coal-Fields Ltd., Coal India Ltd.,
Eastern Coal-Fields Ltd., Neyveli Lignite Corpn. Ltd., and
Western Coalfields Ltd. (Total 6)

4. Shri A. S Gill Bharat
Petroleum
Corpn.
Ltd,
Secretary
Bongaigaon Refineries & Petrochemicals ltd., Cochin Refinereis
Deptt. of Petroleum
Ltd., Hindustan Petroleum Corp. Ltd., Madras Refineries Ltd., Oil
& Natural Gas Commission, Oil India Ltd. (Total 9)
5. Shri Prakash Narain Cochin Shipyard Ltd. and Hindustan Shipyard Ltd. (Total 2)
Secretary,
Ministry of Shipping &
Trasnport
6. Shri Lovraj Kumar Steel Authority of India Ltd.
Secretary,
Deptt. of Steel
7.Dr.
R.
Secretary,
Deptt.
of
Energy

Ramanna Electronics Corp of India Ltd., Indian Rare Earth Ltde., Uranium
Corp. of India Ltd. (Total 3)
Atomic

8. Shri S. R. Vijayakar Semi Conductors Complex Ltd.
Secretary
Deptt. of Electronics
9. Dr. S. Vardarajan Central Electronics Ltd.
Secretary
Deptt. of Science &
Technology
***************
