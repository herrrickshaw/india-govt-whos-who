---
doc_id: "1aee1dfc83bde781"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/11/58b6c8ac302aeaf16ace39b0ced98fcc.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Gazette Notification dated 29.09.2025 appoint of Shri Sunil Jain, Senior Advocate as Additional Solicitor General for India for the High Court of Madhya Pradesh w.e.f. 29.09.2025."
date: "2025-09-30"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1d049ccf48f570b3"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-29092025-266532
xxxGIDHxxx
CG-DL-E-29092025-266532
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग I—खण्ड 2
PART I—Section 2
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 43]
No. 43]

नई दिल्ली, सोमिार, जसतम्बर 29, 2025/आज‍िन 7, 1947
NEW DELHI, MONDAY, SEPTEMBER 29, 2025/ASVINA 7, 1947

जिजध और न्याय मंत्रालय
(जिजध कायय जिभाग)
अजधसूचना
नई दिल्ली, 29 जसतम्बर, 2025
फा. सं. िे-11013/8/2025-न्याजयक.—राष्‍टरपजत, श्री सुनील िैन, िररष्ठ अजधिक्ता को मध्य प्रिेि उच्च न्यायालय
के भारत के अपर महासाजलजसटर के पि पर दिनांक 29.09.2025 से तीन िर्य की अिजध या अगले आिेिों तक, िो भी
पहले हो, जनयुक्त करते हैं ।
माधब चरण प्रुस्ट्ती, िररष्ठ सरकारी अजधिक्ता

6522 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 2]

MINISTRY OF LAW AND JUSTICE
(Department of Legal Affairs)
NOTIFICATION
New Delhi, the 29th September, 2025
F. No. J-11013/8/2025-Judicial.— The President is pleased to appoint Shri Sunil Jain, Senior
Advocate as Additional Solicitor General for India for the High Court of Madhya Pradesh for a
period of three years with effect from 29.09.2025 or until further orders, whichever is earlier.

MADHAB CHARAN PRUSTY, Senior Government Advocate

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2025.09.29 22:16:06
+05'30'
