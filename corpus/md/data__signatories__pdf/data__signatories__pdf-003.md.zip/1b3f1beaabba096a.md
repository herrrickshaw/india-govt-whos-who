---
doc_id: "1b3f1beaabba096a"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/507759559caa5e035c2e3f62de6a743a.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification 30-07-2010"
date: "2025-07-14"
pages: 1
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b38ae120e99c2452"
---

<!-- page 1 -->

-. SS ”~—O™””C—OF :
eS
8
200 te oS रे
> oe
fe Se REGD. NO.D.1.-3300099
Egat ee we wen 3300899 ge
6
० ४ 2 ate a 4 I i :
177 12 कक 2 5 1
12 ५ tte o HAIG. 2)
ee oe 0:00.» असाहरिण ae
5 336: % Gs ६ __ भाग ए- 3--उप-खण्ड (6) आओ
के oe Bi Git = aie —e Sab-section (ii ne
: ont ae ५226 Sie ? ai) 3 2 pe
5 पक ०272 2: aries eee te amet
: PUBLISHED By AUTHORITY _ eae
ee ——- oe गा का ey
nt een = Be orn et og
रा eS fa Ai Toe - :
eae Pes she mv कट 2320 7307 MINISTRY COMMERCE aa coe |
Se 4 cst Eee eee -— Ses “Oxparmet Pony OF COMM के ae
o ee SES Seca aaa nt of Industrial Policy a asin हक
ot देश हे ae 1 5 पाए 167 8 |
2 हक आह a New Det, e290 July, 2010 ee
420 6 tm — sj, 30 Fate = © SO. 1862(6)—In exeroize of the powers’
ee ae rans 6 ae t 18G of the Industries (Developmen Hand ibe
a प्रयोग करते ye, patie नियंत्रण आदेश, 2004 का... Revtltlon) Act, 1951 (65 of 1951), the Central Government ee
है का के 5 Psa सम रेल ai ak we; Sok rear oat
Ve ee a
2601 “आग आओ eae eee s ic 210 h cae a ear a
j ५ pO aetna cs Oe yes ae es ee re op * 0600 0
5203 मय और यम ee bie
e Pie te ge ae fee ae oe es ano be 3 Teo, eh लि
ee ee emo, eo
i sit 33630 ge Ta 252 ae ieee tc ei New iC ee PUR HE SCRE Pe bk
ea : नियंत्रण आदेश; 2004 की हि मे ms ६487 8 41020. SE om
oe Ge ae लि ie ee eT hn mi. nee ee
oe ee an stercan ae ate. 5 Mee NOD og Ce eee
: न कहे साशापशकिकर बी कल 1 260. ae Mi Be ite Gt ees
....ओरबायाल गौंव, कराईकुदी, जिला सिंगर, तमिलनाडु सर रा Socavnal Vilage, Kaci Sepia
2 “वा सजी 2006 कक eae peep NA a
a का. सं 40702008- o.oo हि
oe आदेश पाल ' sea मे र me 1105), oe तल के अत oo
1... ज्ञोतीख 11 अक्तूबर, 2001 के वह प्रकाशित किया गया... ०४४३ 00025 0्व॑श ५०३ published 06 08200० of st
ee A a oc serie 25 ar, पी व पर dé Cerin 080,
oS pac ecu ce : Fees eat t Gah Aba 010 publishes ce
aananatee wares: od ४ करा ० a 5
दा fea 3 Sa een oo ee 82 oe
PR ee Sr Wh SOR a ee re Po nee 2
i ee ee ae ee
ee Ea "Printed by the Manager, Gaverument of india Pres, Ring Road, Mayapu OE ee ae Meat ae a
ee ० A : ce ae oe 2 ae ae
Ce या es
st Meee oI te 500५ 20605 02:65 180 1 i हा ० rt a Suey
oe 0 a ee ee 35 ae.
