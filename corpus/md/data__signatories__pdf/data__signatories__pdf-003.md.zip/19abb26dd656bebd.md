---
doc_id: "19abb26dd656bebd"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/Notification_2.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Notification_2.pdf"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2cf60976905743f8"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99 REGD. No. D. L.-33004/99
SREY
yt
Leta
Ck di
¢ Gazette of India
सी.जी.-डी.एल.-अ.-04072022-237049
CG-DL-E-04072022-237049
असाधारण
EXTRAORDINARY
भाग 1--खण्ड 3---उप-खण्ड (1)
PART II—Section 3—Sub-section (ii)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
सं. 2895] नई दिल्‍ली, सोमबार, जुलाई 4, 2022/आषाढ़ 13, 1944
No. 2895] NEW DELHI, MONDAY, JULY 4, 2022/ASHADHA 13, 1944
वित्त मंत्रालय
(वित्तीय सेवाएं विभाग)
अधिसूचना
नई दिल्‍ली, 4 जुलाई, 2022
का.आ. 3043(अ).--केन्द्रीय सरकार, राष्ट्रीय अवसंरचना वित्तपोषण और विकास बैंक अधिनियम,
2021 (2021 का 17) (जिसे इसमें इसके पश्चात अधिनियम कहा गया है) की धारा 2 की उपधारा (1) के
खंड (ग) द्वारा प्रदत्त शक्तियों का प्रयोग करते हुए तथा अधिसूचना संख्या का.आ.1658(अ), तारीख 19 अप्रैल,
2021 के अधिक्रमण में, वित्तीय सेवा संस्था ब्यूरो (1 जुलाई 2022 के भारत के राजपत्र, असाधारण, भाग-,
खंड 1 में प्रकाशित 1 जुलाई 2022 के संकल्प फा.सं. 14/1/2022 बी ओ.1 के माध्यम से गठित) को अधिनियम
की धारा 6 की उपधारा (1) के अधीन प्रबंध निदेशक और उप-प्रबंध निदेशक को नियुक्त करने तथा अधिनियम
की धारा 11 की उपधारा (1) के खंड (1) के अधीन निदेशक को पद से हटाए जाने की सिफारिश करने के
प्रयोजनार्थ ब्यूरो के रूप में अधिसूचित करती है।
[फा. सं. 15/10/2021 -ए-]
सौरभ मिश्रा, संयुक्त सचिव
4479 01/2022 (1)

<!-- page 2 -->

2: THE GAZETTE OF INDIA : EXTRAORDINARY [PART II—SEC. 3(ii)]
MINISTRY OF FINANCE
(Department of Financial Services)
NOTIFICATION
New Delhi, the 4th July, 2022
S.O. 3043(F).—In exercise of the powers conferred by clause (c) of sub-section (1) of section 2 of
the National Bank for Financing Infrastructure and Development Act, 2021( 17 of 2021) (hereinafter
referred to as the Act) and in supersession of the notification number S.O. 1658(E), dated the 19" April,
2021, the Central Governmenthereby notifies the Financial Services Institutions Bureau (constituted vide
Resolution F.No. 14/1/2022-BO-I, dated the 1“ July, 2022, published in the Gazette of India, Extraordinary,
Part I, Section 1, dated the 1“ July, 2022), as the Bureau for the purpose of recommending candidates for
appointment of Managing Director and Deputy Managing Directors under sub-section (1) of section 6 of
theAct and the removal of a director under clause (ii) of sub-section (1) of section 11 of the Act.
[F. No. 15/10/2021-IF-I]
SAURABH MISHRA, Jt. Secy.
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. 222) 22==
