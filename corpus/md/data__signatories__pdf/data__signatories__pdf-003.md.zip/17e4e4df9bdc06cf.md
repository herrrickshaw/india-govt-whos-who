---
doc_id: "17e4e4df9bdc06cf"
source_url: "https://doj.gov.in/static/uploads/2026/09/596ad2c394fad9d9f1eb933e26a01af5.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Mahesh Chandra Tripathi, Judge, Allahabad High Court as Chief Justice of Bombay High Court(05.09.2026)"
date: "2026-09-05"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a83749df671eb879"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K-13014/04/2026-US JAIL
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, Dated: 05" September, 2026.
NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint Shri Justice Mahesh
Chandra Tripathi, Judge of the Allahabad High Court, to be Chief Justice of the
Bombay High Court with effect from the date he assumes charge of his office.
(' matt
(Jagannafh Srinivasan)
Joint Secretary to the Government of India
Tele: 2338 3037
_ To
The Manager,
Government of India Press,
Minto Road,
New Dethi.

<!-- page 2 -->

-2-
No. K-13014/04/2026-US.IAL Dated: 05.09.2026
Copy to:~
1. Shri Justice Mahesh Chandra Tripathi, Judge of the Allahabad High Court
through the Registrar General, Allahabad High Court, Prayagraj.
2. The Secretary to the Governor, Maharashtra, Mumbai.
3. The Secretary to the Governor, Goa, Panaji.
4. The Secretary to the Governor of Uttar Pradesh.
5. The Secretary to the Chief Minister, Maharashtra, Mumbai.
6. The Secretary to the Chief Minister, Goa, Panaji.
7. The Secretary to the Chief Minister, Uttar Pradesh.
8. The Secretary to the Acting Chief Justice, Bombay High Court, Mumbai.
9. The Secretary to the Chief Justice, Allahabad High Court.
10. The Chief Secretary, Government of Maharashtra, Mumbai.
ll. The Chief Secretary, Government of Goa, Panaji.
12. The Chief Secretary, Government of Uttar Pradesh
13. The Registrar General, Bombay High Court, Mumbai.
14. The Registrar General, Allahabad High Court, Prayagraj.
15. The Accountant General, Maharashtra, Mumbai.
16. The Accountant General, Goa, Panaji.
17. The Accountant General, Uttar Pradesh.
18. The President*s Secretariat, (CA.I. Section), Rashtrapati Bhawan, New
Delhi.
19. PS to the Principal Secretary to the Prime Minister, Prime Minister’s Office,
Seva Teerth, New Delhi.
20. Registrar (Conf.), Supreme Court of India, Room Nos. 1, 2 and 3, Ground
Floor, Supreme Court Main Building, New Delhi - 110001.
21. PS to the MoS (I/C), L&J, / PPS to Secretary (J).
22. Technical Director, NIC, Department of Justice, with a request to upload
the notification on the website of the Department (www.doj.gov.in).
oe
(2000
(Prem Chand)
Under Secretary (Appointments-I)
Tele: 011-23382978
