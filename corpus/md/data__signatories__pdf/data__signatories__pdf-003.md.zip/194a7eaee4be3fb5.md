---
doc_id: "194a7eaee4be3fb5"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/Extension_7266E_18092026.pdf"
ministry: "Department of Space"
title: "Corrigendum:LPSC- V/CMD/CS/03/7266/ELE/TE-021/ 2026-27 Dated:03.09.2026      940.56 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fd22a916d2f9e180"
---

<!-- page 1 -->

भारत सरकार/GOVERNMENT OF INDIA
अंत र िवभाग/DEPARTMENT OF SPACE
एलपीएससी – विलयमला/LPSC–VALIAMALA
िनमाण व अनुर ण भाग/CONSTRUCTION AND MAINTENANCE DIVISION

टे िल/Tel: 0471-2567445/7326/7577
ई-िनिवदा का िव

ई-मेल/e-mail: contracts_cmg@lpsc.gov.in
ार /EXTENSION OF E-TENDER-1
Dated 18.09.2026

ई-िनिवदा सूचना सं./ e-Tender Notice No : एलपीएससी-वी/ LPSC- V/सीएमडी/ CMD/ सीएस/ CS/ 03/
7266/ ईएलई/ ELE/ टीई/ TE-021/ 2026-27 िदनांक/dated 03.09.2026

म.सं.
Sl. No.

अ

ौरा/ Details

िववरण/Description

एल पी एस सी, विलयमला म 33kV तथा 11kV सबे शन तथा एचटी/एलटी सं थापनों का चालन एवं
अनु र ण काय।/ Operation and Maintenance of
33kV & 11kV sub-stations and HT/LT
installations at LPSC, Valiamala

1.

काय का शीषक।/ Title of work

2.

िनिवदा म दी गई अनुमािनत लागत/Estimated
cost put to tender

45.46 लाख/lakh

3.

काय पूरा होने की अविध, िजसे काय आदे श जारी
होने की ितिथ के 15व िदन से िगना जाए।/
Period of completion reckoned from the
15th day of date of issue of work order.

12 महीना/Months

4.1

अविध, िजसके दौरान िनिवदा द ावेज़ के िलए
अनु रोध िकया जा सके।/ Period during which
the tender document can be requested

Extended up to: 23:30 Hrs on 27.09.2026

4.2

िनिवदा द ावेज़ डाउनलोड करने की
अविध/Period during which the tender
document can be downloaded.

Extended up to: 23:59 Hrs on 27.09.2026

5.1

बोली

ीकरण/ Bid clarifications

Extended up to: 12:00 Hrs on 28.09.2026

5.2

बोली
ीकरण के िलए उ र/ Reply to Bid
clarifications

Extended up to: 17:30 Hrs on 28.09.2026

6.

िनिवदा पाने की अं ितम ितिथ एवं समय/ Last
date and time for receipt of tenders.

Extended up to: 11:00 Hrs on 29.09.2026

7.

िनिवदा खुलने की अंितम ितिथ एवं समय/ Due
date and time of opening of tenders.

Extended up to: 11:30 Hrs on 29.09.2026
(तकनीकी बोली/Technical bid)

सभी िनयम एवं शत अप रवितत रहगे/ All other terms and conditions remain unaltered. अिधक जानकारी के

िलए कृपया https://www.tenderwizard.com/isro वेबसाइट दे ख / For further details please visit
https://www.tenderwizard.com/isro website.

Sd/धान, सीएमडी /एलपीएससी (वी)/ Head, CMD/LPSC (V)
