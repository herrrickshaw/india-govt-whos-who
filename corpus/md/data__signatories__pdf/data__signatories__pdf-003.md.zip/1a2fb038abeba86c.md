---
doc_id: "1a2fb038abeba86c"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/d06de87bb4de0a39fb2e561c4a8d34ec.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Notification : Shri Anuj Singh is appointed as Deputy Director w.e.f 25.11.2019 (FN) in Dept. of Animal Husbandry and Dairying"
date: "2019-11-07"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e45e5de8b72bd5f8"
---

<!-- page 1 -->

-2-

Distribution:1.

Officer concerned.

2.
3.

PS to JS (GN s).

Deputy Director iSS
Division, MoS&pI,

Delhi.

4.

6.

Sardar patel Bhawan,

Sansad Marg, New
P&AO (Sectt. Department
)
of Animal Husbandry and
New Delhi.
Dalrying, Krishi Bhawan,
Cash Section/ DDO.
He will draw sal ary from
this Department for 23,11,2019
2 11,2019 bei ng
the closed holida ys.
and
indi Section for providing
Hindi version.
NIC-, DAHD for upda
ting the website of the Depatment.
Service Book/ Guard
File/ Spare Copies

<!-- page 2 -->

(To be published in Part-I Section-II of the Gazette of India)

Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Animal Husbandry and Dairying

******

Krishi Bhawan, New Delhi

NOTIFICATION

- 110001.

Date: .11.2019
>/,-/ts
'/

No, A-19011/ 31/ 2019-Admn,I In pursuance of tvlinistry of Statistics and Programme
Implementation's Orders No. 12015/0212019-lSS dated 03.10.2019 and 18.11.2019,
Shri Anuj Singh is appointed as Deputy Director in the Level 11 of Pay Matrix w'e.f.
25.11.2019 (FN) in the Department of Animal Husbandry and Dairying.

Under Secretary to the Government of Indla
Telephone No. : 23382779

To

The Manager,
Government of India Press,
Faridabad (alongwith Hindi Version)
