---
doc_id: "1c2f8ac2e34f4bbf"
source_url: "http://consumeraffairs.gov.in/public/upload/files/IILM%20and%20LM%20Recruitment%20(Amendment)%20Rules%202017_1732872918.pdf"
ministry: "Department of Consumer Affairs (DoCA)"
title: "Download The Indian Institute of Legal Metrology, Ranchi (Group ‘A’ posts) Recruitment (Amendment) Rules, 2017"
date: ""
pages: 19
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "c03f4285603885fb"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

jftLVªh laö Mhö ,yö&33004@99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 171]

ubZ fnYyh] c`gLifrokj] ekpZ 9] 2017@iQkYxqu 18] 1938

No. 171]

NEW DELHI, THURSDAY, MARCH 9, 2017/PHALGUNA 18, 1938
उपभोक्ता मामले, खा

और सावर्जिनक िवतरण मं ालय

(उपभोक्ता मामले िवभाग)

अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 214(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए भारतीय
िविधक माप िवज्ञान संस्थान, रांची (समूह ‘क’ पद) भत िनयम, 2010 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह,
अथार्त्:—
1.

(1) इन िनयम का संिक्षप्त नाम भारतीय िविधक माप िवज्ञान संस्थान, रांची (समूह ‘क’ पद) भत (संशोधन) िनयम, 2017 है ।
(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे ।

2. भारतीय िविधक माप िवज्ञान संस्थान, रांची (समूह ‘क’ पद) भत िनयम, 2010 म,
(क) िनयम 3 म, “वेतन बड और ड
े वेतन या वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे
जाएंगे ।
(ख) अनुसूची म,
(i) िनदेशक (भारतीय िविधक माप िवज्ञान संस्थान) के पद से संबंिधत म संख्या 1 के सामने,—
(अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:—
“वेतन मैि क्स म स्तर
(4)
स्तर- 12 (78800-209200/- रु.)”;
(आ)

स्तंभ (6) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (7) से स्तंभ (14) को मश: स्तंभ (6) से स्तंभ (13) के
रूप म पुन:संख्यािकत िकया जाएगा;

(इ)

पुन:संख्यािकत िकया गया स्तंभ (11) म,—

1316 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY
(I)

[PART II—SEC. 3(i)]

“ ोन्नित” शीषर्क के अधीन “वेतन बड-3 (15600-39100 रु) और ड
े वेतन 6600 रुपये” शब्द , कोष्टक और अंक के
स्थान पर “स्तर-11 (67700-208700/-रु.)” शब्द, कोष्टक और अंक रखे जाएंग;े

(II) “ ितिनयुि ” शीषर्क के अधीन, मद (क) के उपमद (i) म “वेतन बड-3, (15600-39100 रु.) और ड
े वेतन 6600 रुपये”
शब्द , कोष्टक और अंक के स्थान “स्तर-11 (67700-208700/- रु.)” शब्द, कोष्टक और अंक रखे जाएंगे ;
(ii) आचायर् के पद से संबंिधत म संख्या 2 के सामने,—
(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएंगी, अथार्त्:—
“स्तर-11 (67700-208700/-रु.)”;
(आ) पुन:संख्यािकत िकया गया स्तंभ (11) म,—
(I)

“ ोन्नित” शीषर्क के अधीन, “वेतन बड-3 (15600-39100 रु.) और ड
े वेतन 5400 रु.” शब्द , कोष्टक और अंक के
स्थान पर “स्तर-10 (56100-177500 रु.)” शब्द, कोष्टक और अंक रखे जाएंग;े

(II)

“ ितिनयुि ” शीषर्क के अधीन, मद (क) के उपमद (i) म “वेतन बड-3 (15600-39100 रु.) और ड
े वेतन 5400 रु.”
शब्द , कोष्टक और अंक के स्थान पर “स्तर-10 (56100-177500 रु.)” शब्द कोष्टक और अंक रखे जाएंग;े

(iii)

सहायक आचायर् के पद से संबिं धत म संख्या 3 के सामने,—

(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त्:—
“स्तर-10 (56100-177500 रु.)”;
(आ) पुन: संख्यािकत िकया गया स्तंभ (11) म, “ ितिनयुि ” शीषर्क के अधीन,—
(I)

मद (क) के उपमद (ii) म, “वेतन बड-2 (9300-34800 रु.) और ड
े वेतन 4600 रु.” शब्द , कोष्टक और अंक के
स्थान पर “स्तर-7 (44900-142400 रु.)” शब्द, कोष्टक और अंक रखे जाएंगे;

(II)

मद (क) के उपमद (iii) म, “वेतन बड-2 (9300-34800 रु.) और ड
े वेतन 4200 रु. ” शब्द , कोष्टक और अंक के
स्थान पर “स्तर-6 (35400-112400 रु.)” शब्द, कोष्टक और अंक रखे जाएंगे।

(III)

िटप्पण का लोप िकया जाएगा ।
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव

िटप्पण : मूल िनयम भारत के राजप भाग II, खंड 3 उप-खंड (i) म सा.का.िन. सं. 130, तारीख 7 अगस्त, 2010
गए थे और तत्पश्चात् सा.का.िन. सं. 843(अ), तारीख 1 िसतम्बर, 2016 ारा संशोिधत िकए गए।

ारा कािशत िकए

MINISTRY OF CONSUMER AFFAIRS, FOOD AND PUBLIC DISTRIBUTION
(Department of Consumer Affairs)
NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 214(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Indian Institute of Legal Metrology, Ranchi (Group ‘A’
posts) Recruitment Rules, 2010, namely:—
1. (1) These rules may be called the Indian Institute of Legal Metrology, Ranchi (Group ‘A’ posts) Recruitment
(Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Indian Institute of Legal Metrology, Ranchi (Group ‘A’ posts) Recruitment Rules, 2010,—
(a) in rule 3, for the words “Pay Band and Grade Pay/Pay Scale” at both the places, the words “level in the pay
matrix” shall be substituted;
(b) in the Schedule,—
(i) against serial number 1 relating to the post of Director (Indian Institute of Legal Metrology),—

<!-- page 3 -->

¹Hkkx IIμ[k.M 3(i)º

3

Hkkjr dk jkti=k % vlk/kj.k

(A) for column (4) and the entries relating thereto the following shall be substituted, namely:—
“Level in the pay matrix
(4)
Level-12 (Rs.78800-209200/-)”;

(B) column (6) and the entries relating thereto, shall be omitted and columns 7 to 14 shall be renumbered as
columns 6 to 13 respectively;
(C) in column (11) as so renumbered,—
(I)

under heading “Promotion”, for the words and figures “Pay Band 3( Rs. 15600-39100) plus grade pay
Rs.6600/-”, the words and figures “Level-11 (Rs.67700-208700/-)” shall be substituted;

(II)

under heading “Deputation”, in item (a) sub-item(ii), for the words and figures “Pay Band 3
(Rs. 15600-39100) plus grade pay Rs. 6600/-”, the words and figures “Level-11 (Rs. 67700-208700)”
shall be substituted;

(ii) against serial number 2 relating to the post of Professor,—
(A) for the entries under column (4), the following entries shall be substituted, namely:—
“Level-11 (Rs. 67700-208700/-)”;
(B) in column (11) as so renumbered,—
(I) under heading “Promotion”, for the words and figures “Pay Band 3( Rs. 15600-39100) plus grade pay
Rs.5400/-”, the words and figures “Level-10 (Rs. 56100-177500/-)” shall be substituted;
(II) under heading “Deputation”, in item (a) sub-item (ii), for the words and figures “Pay Band 3 ( Rs. 1560039100) plus grade pay Rs. 5400/-”, the words and figures “Level-10 (Rs. 56100-177500/-)” shall be
substituted;
(iii) against serial number 3 relating to the post of Assistant Professor,—
(A) for the entries under column (4), the following entries shall be substituted, namely:—
“Level-10 (Rs. 56100-177500/-)”;
(B) in column (11) as so renumbered, under heading “Deputation”,—
(I)

in item (a) sub-item (ii), for the words and figures “Pay Band 2 ( Rs. 9300-34800) plus grade pay
Rs.4600/-”, the words and figures “Level-7 (Rs. 44900-142400/-)” shall be substituted;

(II)

in item (a) sub-item (ii), for the words and figures “Pay Band 2 ( Rs. 9300-34800) plus grade pay
Rs.4200/-”, the words and figures “Level-6 (Rs. 35400-112400/-)” shall be substituted;

(III)

Note shall be omitted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.

Note: The principal rules were published in the Gazette of India, Part II, Section 3, sub-Section (i) vide notification
number G.S.R. 130, dated the 7th August, 2010 and subsequently amended vide notification number
G.S.R. 843(E) 1st September, 2016.
अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 215(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, भारतीय िविधक माप िवज्ञान संस्थान, रांची म समूह ‘ग’ पद
भत िनयम, 2011 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह, अथार्त्:—
1. (1) इन िनयम का संिक्षप्त नाम उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, भारतीय
िविधक माप िवज्ञान संस्थान, रांची म समूह ‘ग’ पद, भत (संशोधन) िनयम, 2017 है ।
(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे ।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

2. उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, भारतीय िविधक माप िवज्ञान संस्थान, रांची म
समूह ‘ग’, पद भत िनयम, 2011 म,
(क) िनयम 3 म, “वेतन बड और ड
े वेतन या वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे
जाएंगे।
(ख) अनुसूची म,—
(i) धान िलिपक-सह-लेखाकार के पद से संबंिधत म संख्या 1 के सामने,—
(अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:—
“वेतन मैि क्स म स्तर
(4)
स्तर- 6 (35400-112400/- रु.)”;
(आ)

स्तंभ (6) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (7) से स्तंभ (14) को मश: स्तंभ (6) से स्तंभ (13) के
रूप म पुन:संख्यािकत िकया जाएगा;

(इ)

पुन:संख्यािकत िकया गया स्तंभ (11) म, “ ोन्नित” शीषर्क के अधीन,—
(I) “वेतन बड-1 (5200-20200 रु) + ड
े वेतन 2400 रुपये” ‘शब्द , कोष्टक और अंक के स्थान पर “स्तर-4 (2550081100/- रु.)” शब्द और अंक रखे जाएंग;े
(II) िटप्पण 2 का लोप िकया जाएगा ;

(ii) उच्च ण
े ी िलिपक के पद से संबंिधत म संख्या 2 के सामने,—
(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त्:—
“स्तर-4 (25500-81100/- रु.)”;
(आ) पुन:संख्यािकत िकया गया स्तंभ (11) म,—
(I) “ ोन्नित” शीषर्क के अधीन,—
(i) “वेतन बड-1 (5200-20200 रु.) + ड
े वेतन 1900 रु.” शब्द और अंक के स्थान पर “स्तर-2 (1990063200/- रु.)” शब्द और अंक रखे जाएंग;े
(ii) िटप्पण 2 का लोप िकया जाएगा;
(II)

“ ितिनयुि ” शीषर्क के अधीन,—
(i) मद (ii) म “वेतन बड-1 (5200-20200 रु.) + ड
े वेतन 1900 रु.” शब्द और अंक के स्थान पर “स्तर-2
(19900-63200/- रु.)” शब्द और अंक रखे जाएंग;े
(ii) िटप्पण 3 का लोप िकया जाएगा;

(iii) आशुिलिपक ेणी-1 के पद से संबंिधत म संख्या 3 के सामने,—
(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त,—
“स्तर-6 (35400-112400/- रु.)”;
(आ) पुन: संख्यािकत िकया गया स्तंभ (11) म,
(I) “ ितिनयुि ” शीषर्क के अधीन,—
(i) “वेतन बड-1 (5200-20200 रु.) + ड
े वेतन 2400 रु ” शब्द और अंक के स्थान पर “स्तर-4 (25500-81100 रु.)”
शब्द और अंक रखे जाएंग;े
(ii) िटप्पण 2 का लोप िकया जाएगा;
(II) “ ितिनयुि ” शीषर्क के अधीन,—

<!-- page 5 -->

¹Hkkx IIμ[k.M 3(i)º

5

Hkkjr dk jkti=k % vlk/kj.k

(i) मद (क) उप-मद (ii) म “वेतन बड-1 (5200-20200 रु.) + ड
े वेतन 2400 रु ” शब्द और अंक के स्थान पर
“स्तर-4 (25500-81100/- रु.)” शब्द और अंक रखे जाएंग;े
(ii) िटप्पण 3 का लोप िकया जाएगा;
(iv) आशुिलिपक ण
े ी-II के पद से संबंिधत
िवि यां रखी जाएगी, अथार्त् :—

म संख्या 4 के सामने, स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत
“स्तर-4 (25500-81100/- रु.)”

(v) अवर ेणी िलिपक के पद से संबंिधत
िवि यां रखी जाएगी, अथार्त:् —

म संख्या 5 के सामने, स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत
“स्तर-2 (19900-63200/- रु.)”

(vi) भंडारी के पद से संबंिधत म संख्या 6 के सामने, स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी
जाएगी, अथार्त:् —
“स्तर-2 (19900-63200/- रु.)”
(vii) स्टाफ कार चालक (सामान्य ेणी) के पद से संबंिधत म संख्या 7 के सामने,
(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त्:—
“स्तर-2 (19900-63200/- रु.)”
(आ) पुन:संख्यािकत िकया गया स्तंभ (11) मे, “ ितिनयुि ” शीषर्क के अधीन,—
(i) मद (क) उपमद (ii) म “वेतन बड-1 (5200-20200 रु.) + ड
े वेतन 1900 रु.” शब्द और अंक के स्थान पर
“स्तर-2 (19900-63200/- रु.)” शब्द और अंक रखे जाएंग;े
(ii) िटप्पण का लोप िकया जाएगा;
(viii) बहु कायर् कमर्चारीवृंद के पद से संबंिधत म संख्या 8 के सामने, स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत
िवि यां रखी जाएगी, अथार्त:् —
“स्तर-1 (18000-56900/- रु.)”
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग II, खंड 3 उपखंड (i) म सा.का.िन. सं. 203, तारीख 2 जुलाई, 2011 ारा कािशत िकए गए थे।
NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 215(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules to amend the Ministry of Consumer Affairs, Food and Public Distribution,
Department of Consumer Affairs, Group ‘C’ posts in the Indian Institute of Legal Metrology, Ranchi, Recruitment Rules,
2011, namely:—
1. (1) These rules may be called the Ministry of Consumer Affairs, Food and Public Distribution, Department of
Consumer Affairs, Group ‘C’ posts in the Indian Institute of Legal Metrology, Ranchi, Recruitment
(Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Ministry of Consumer Affairs, Food and Public Distribution, Department of Consumer Affairs, Group ‘C’
posts in the Indian Institute of Legal Metrology, Ranchi, Recruitment Rules, 2011,—
(a)

in rule 3, for the words “pay band, grade pay or scale of pay” at both the places, the words “level in the pay
matrix” shall be substituted;

(b)

in the Schedule,—
(i) against serial number 1 relating to the post of Head Clerk-cum-Accountant,—

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(A) for column (4) and the entries relating thereto the following shall be substituted, namely:—
“Level in the pay matrix
(4)
Level-6 (Rs. 35400-112400/-)”;
(B) column (6) and the entries relating thereto, shall be omitted and columns 7 to 14 shall be renumbered as
columns 6 to 13 respectively;—
(C) in column (11) as so renumbered, under heading “Promotion”,—
(I)

for the words and figures “Pay Band-1(Rs. 5200-20200) plus grade pay Rs. 2400/-”, the words and figures
“Level-4 (Rs. 25500-81100/-)” shall be substituted;

(II)

Note 2 shall be omitted;

(ii) against serial number 2 relating to the post of Upper Division Clerk,—
(A) for the entries under column (4), the following entries shall be substituted, namely:—
“Level-4 (Rs. 25500-81100/-)”;
(B) in column (11) as so renumbered,—
(I) under heading “Promotion”,—
(i)

for the words and figures “Pay Band-1( Rs. 5200-20200) plus grade pay Rs.1900/-”, the words and
figures “Level-2 (Rs. 19900-63200/-)” shall be substituted;

(ii) Note 2 shall be omitted;
(II) under heading “Deputation”,—
(i)

in item (ii), for the words and figures “Pay Band-1( Rs. 5200-20200) plus grade pay Rs. 1900/-”, the
words and figures “Level-2 (Rs. 19900-63200/-)” shall be substituted;

(ii)

Note III shall be omitted;

(iii) against serial number 3 relating to the post of Stenographer Grade-I,—
(A) for the entries under column (4), the following entries shall be substituted, namely:—
“Level-6 (Rs. 35400-112400/-)”;
(B) in column (11) as so renumbered,—
(I) under heading “Promotion”,—
(i) for the words and figures “Pay Band-1 ( Rs. 5200-20200) plus grade pay Rs. 2400/-”,the words and
figures “Level-4 (Rs. 25500-81100/-)” shall be substituted;
(ii) Note 2 shall be omitted;
(II) under heading “Deputation”,—
(i)

in item (a) sub-item (ii), for the words and figures “Pay Band-1 ( Rs. 5200-20200) plus grade pay
Rs. 2400/-”, the words and figures “Level-4 (Rs. 25500-81100/-)” shall be substituted;

(ii)

Note III shall be omitted;

(iv) against serial number 4 relating to the post of Stenographer Grade-II, for the entries under column (4), the
following entries shall be substituted, namely:—
“Level-4 (Rs. 25500-81100/-)”;
(v) against serial number 5 relating to the post of Lower Division Clerk,for the entries under column (4), the
following entries shall be substituted, namely:—
“Level-2 (Rs. 19900-63200/-)”;
(vi) against serial number 6 relating to the post of Storekeeper, for the entries under column (4), the following
entries shall be substituted, namely:—
“Level-2 (Rs. 19900-63200/-)”;
(vii) against serial number 7 relating to the post of Staff Car Driver(Ordinary Grade),—

<!-- page 7 -->

¹Hkkx IIμ[k.M 3(i)º

7

Hkkjr dk jkti=k % vlk/kj.k

(A) for the entries under column (4), the following entries shall be substituted, namely:—
“Level-2 (Rs. 19900-63200/-)”;
(B) in column (11) as so renumbered, under heading “Deputation”,—
(i)

in item (a) sub-item (ii), for the words and figures “Pay Band-1 ( Rs. 5200-20200) plus Grade Pay
Rs. 1900/-”, the words and figures “Level-2 (Rs. 19900-63200/-)” shall be substituted;

(ii)

Note shall be omitted;

(viii) against serial number 8 relating to the post of Multi-Tasking Staff, for the entries under column (4), the
following entries shall be substituted, namely:—
“Level-1 (Rs. 18000-56900/-)”.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.
Note: -The principal rules were published in the Gazette of India, Part II, Section 3, sub-section (i) vide notification
number G.S.R. 203, dated the 2nd July, 2011.

अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 216(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले िवभाग [िनदेशक (िविधक माप िवज्ञान)] भत िनयम, 2003 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह,
अथार्त्:—
1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले िवभाग [िनदेशक (िविधक माप िवज्ञान)] भत (संशोधन) िनयम, 2017 है ।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे ।
2. उपभोक्ता मामले िवभाग [िनदेशक (िविधक माप िवज्ञान)] भत िनयम, 2005 म,
(क) िनयम 3 म, “वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे जाएंगे।
(ख) अनुसूची म,
(अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:—
“वेतन मैि क्स म स्तर
(4)
स्तर-12 (78800-209200/- रु.)”;
(आ) स्तंभ (7) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (8) से स्तंभ (14) को
स्तंभ (13) के रूप म पुन: संख्यािकत िकया जाएगा ;
(इ)

मश: स्तंभ (7) से

पुन:संख्यािकत िकया गया स्तंभ (11) म,—
(I) “ ोन्नित” शीषर्क के अधीन, “10,000-15,200 रुपए के वेतनमान” शब्द और अंक के स्थान पर “स्तर -11
(67700-208700/- रु.)” शब्द और अंक रखे जाएंगे;
(II) “ ितिनयुि ” शीषर्क के अधीन,मद (क) के उपमद (ii) म “10,000-15,200 रुपए वेतनमान” शब्द और अंक के
स्थान पर “स्तर -11 (67700-208700/- रु.)” शब्द और अंक रखे जाएंग;े
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव

िटप्पण: मूल िनयम भारत के राजप भाग II, खंड 3 उप-खंड (i) म सा.का.िन. सं. 293, तारीख 3 िसतंबर, 2005 ारा कािशत िकए
गए थे और तत्पश्चात् सा.का.िन. सं. 176, तारीख 19 िदसम्बर, 2009 और सा.का.िन. 712 (अ) तारीख 21 जुलाई, 2016
ारा संशोिधत िकए गए।

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 216(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Department of Consumer Affairs [Director (Legal
Metrology)] Recruitment Rules, 2005, namely:—
1. (1) These rules may be called the Department of Consumer Affairs [Director (Legal Metrology)] Recruitment
(Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Department of Consumer Affairs [Director (Legal Metrology)] Recruitment Rules, 2005,—
(a) in rule 3, for the words “Scale of pay” at both the places, the words “level in the pay matrix” shall be substituted;
(b) in the Schedule,—
(i) for column 4 and the entries relating thereto the following shall be substituted, namely:—
“Level in the pay matrix
4
Level-12 (Rs. 78800-209200/-)”;
(ii) column (7) and the entries relating thereto, shall be omitted and columns 8 to 14 shall be renumbered as
columns 7 to 13 respectively;
(iii) in column (11) as so renumbered,—
(I) under heading “Promotion”, for the words and figures “Pay Sclae of ( Rs. 10000-15200)”, the words and
figures “Level-11 (Rs. 67700-208700/-)” shall be substituted;
(II) under heading “Deputation”, in item (a) sub-item (ii), for the words and figures “Pay Sclae of ( Rs. 1000015200)”, the words and figures “Level-11 (Rs. 67700-208700/-)” shall be substituted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.
Note:

The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 293, dated the 3rd September, 2005 and subsequently amended vide notification numbers
G.S.R 176, dated the 19th December, 2009 and G.S.R. 712(E) dated the 21st July, 2016.
अिधसूचना
नई िदल्ली, 7 माचर्, 2017

सा.का.िन. 217(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले िवभाग, उपिनदेशक (िविधक माप िवज्ञान) और सहायक िनदेशक (िविधक माप िवज्ञान) भत िनयम, 2008 का और संशोधन करने
के िलए िनम्निलिखत िनयम बनाते ह, अथार्त्:—
1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले िवभाग, उपिनदेशक (िविधक माप िवज्ञान) और सहायक िनदेशक (िविधक माप
िवज्ञान) भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. उपभोक्ता मामले िवभाग, उपिनदेशक (िविधक माप िवज्ञान) और सहायक िनदेशक (िविधक माप िवज्ञान) भत िनयम, 2008 म,
(क) िनयम 3 म, “वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे जाएंगे।
(ख) अनुसूची म,
(i) उप िनदेशक (िविधक माप िवज्ञान) के पद से संबिं धत म संख्या 1 के सामने,—
(अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:—
“वेतन मैि क्स म स्तर
(4)
स्तर- 11 (67700-208700/- रु.)”;

<!-- page 9 -->

¹Hkkx IIμ[k.M 3(i)º

9

Hkkjr dk jkti=k % vlk/kj.k

(आ) स्तंभ (7) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (8) से स्तंभ (14) को
स्तंभ (13) के रूप म पुन:संख्यािकत िकया जाएगा;

मश: स्तंभ (7) से

(इ) पुन:संख्यािकत िकया गया स्तंभ (11) म,
(I)

“ ोन्नित” शीषर्क के अधीन, “8000-13500/- रुपये के वेतनमान” शब्द और अंक के स्थान पर “स्तर-10 (56100177500/- रु.)” शब्द और अंक रखे जाएंग;े

(II)

“ ितिनयुि ” शीषर्क के अधीन, मद (क) के उपमद (ii) म “8000-13500 रुपये वेतनमान” शब्द और अंक के स्थान
“स्तर-10 (56100-177500/- रु.)” शब्द और अंक रखे जाएंग;े

(ii) सहायक िनदेशक (िविधक माप िवज्ञान) के पद से संबंिधत म संख्या 2 के सामने (अ) स्तंभ (4) के अधीन िवि य के स्थान
पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त:् —
“स्तर-10 (56100-177500/- रु.)”;
(आ) पुन:संख्यािकत िकया गया स्तंभ (11) म,—
(I) “ ोन्नित” शीषर्क के अधीन, “5500-175-9000/- रुपये के वेतनमान” शब्द और अंक के स्थान पर “स्तर-6 (35400112400/- रु.)” शब्द और अंक रखे जाएंग;े
(II) “ ितिनयुि ” शीषर्क के अधीन, मद (क) के उपमद (i) म “5000-9000 रुपये वेतनमान” शब्द और अंक के स्थान “स्तर-6
(35400-112400/- रु.)” शब्द और अंक रखे जाएंगे;
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग-II, खंड 3 उपखंड (i) म सा.का.िन. सं. 157, तारीख 23 अगस्त, 2008 ारा कािशत िकए
गए थे और तत्पश्चात् सा.का.िन. सं. 277(अ), तारीख 1 अ ल
ै , 2010, सा.का.िन. सं. 81, तारीख 1 मई, 2010 और
सा.का.िन. सं. 713(अ), तारीख 20 जुलाई, 2016 ारा संशोिधत िकए गए।

NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 217(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Department of Consumer Affairs Deputy Director
(Legal Metrology) and Assistant Director (Legal Metrology) Recruitment Rules, 2008, namely:1. (1) These rules may be called the Department of Consumer Affairs Deputy Director (Legal Metrology) and Assistant
Director (Legal Metrology) Recruitment (Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Department of Consumer Affairs Deputy Director (Legal Metrology) and Assistant Director (Legal Metrology)
Recruitment Rules, 2008,(a) in rule 3, for the words “scale of pay” at both the places, the words “level in the pay matrix” shall be substituted;
(b) in the Schedule,(i) against serial number 1 relating to the post of Deputy Director (Legal Metrology),(A)

for column (4) and the entries relating thereto the following shall be substituted, namely:“Level in the pay matrix
(4)
Level-11 (Rs. 67700-208700/-)”;

(B) column (7) and the entries relating thereto, shall be omitted and columns 8 to 14 shall be renumbered as
columns 7 to 13 respectively;
(C)

in column (11) as so renumbered, -

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(I) under heading “Promotion”, for the words and figures “Pay Sclae of ( Rs. 8000-13500)”, the words and
figures “Level-10 (Rs. 56100-177500/-)” shall be substituted;
(II) under heading “Deputation”, in item (a) sub-item (ii), for the words and figures “Pay Sclae of (Rs. 800013500)”,the words and figures “Level-10 (Rs. 56100-177500/-)” shall be substituted;
(ii) against serial number 2 relating to the post of Assistant Director (Legal Metrology),(A) for the entries under column (4), the following entries shall be substituted, namely:“Level-10 (Rs. 56100-177500/-)”;
(B) in column (11) as so renumbered,(I) under heading “Promotion”, for the words and figures “Pay Sclae of ( Rs. 5500-175-9000)”, the words and
figures “Level-6 (Rs. 35400-112400/-)” shall be substituted;
(II) under heading “Deputation”, in item (a) sub-item (ii), for the words and figures “Pay Sclae of (Rs. 55009000)”,the words and figures “Level-6 (Rs. 35400-112400/-)” shall be substituted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN Under Secy.
Note: - The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 157, dated the 23rd August, 2008 and subsequently amended vide notification numbers G.S.R
277(E) dated the 1st April, 2010, G.S.R 81 dated the 1st May, 2010 and G.S.R 713 (E) dated the 20th July, 2016.
अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 218(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले िवभाग, (माप िवज्ञान सहायक) भत िनयम, 2002 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह, अथार्त:् —
1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले िवभाग, (माप िवज्ञान सहायक) भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. उपभोक्ता मामले िवभाग, (माप िवज्ञान सहायक) भत िनयम, 2002 म,
(क) िनयम 2 म, “वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे जाएंग।े
(ख) अनुसूची म,
(i) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:“वेतन मैि क्स म स्तर
(4)
स्तर-6 (35400-112400/- रु.)”;
(ii) स्तंभ (7) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (8) से स्तंभ (14) को
स्तंभ (13) के रूप म पुन: संख्यािकत िकया जाएगा ;

मश: स्तंभ (7) से

(ii) “सीधी भत ” शीषर्क के अधीन, पुन:संख्यािकत िकया गया स्तंभ (10) म, (I) मद (क) के उपमद (ii) म, “5000-8000/-रु. के वेतनमान” शब्द और अंक के स्थान पर “स्तर -6 (35400112400/- रु.)” शब्द और अंक रखे जाएंग;े
(II) मद (क) के उपमद (iii) म “4500-125-7000-रु. के वेतनमान” शब्द और अंक के स्थान पर “स्तर -5 (2920092300/- रु.) या समतुल्य” शब्द और अंक रखे जाएंगे;
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग- II, खंड 3 उपखंड (i) म सा.का.िन. सं. 327, तारीख 17 अगस्त, 2002 ारा कािशत िकए
गए थे और तत्पश्चात् सा.का.िन. सं. 59, तारीख 27 माचर्, 2010, ारा संशोिधत िकए गए।

<!-- page 11 -->

¹Hkkx IIμ[k.M 3(i)º

11

Hkkjr dk jkti=k % vlk/kj.k
NOTIFICATION
New Delhi, the 7th March, 2017

G.S.R.218(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Department of Consumer Affairs (Metrological
Assistant) Recruitment Rules, 2002, namely:—
1. (1) These rules may be called the Department of Consumer Affairs (Metrological Assistant) Recruitment
(Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Department of Consumer Affairs (Metrological Assistant) Recruitment Rules, 2002,—
(a) in rule 2, for the words “Scale of pay” at both the places, the words “level in the pay matrix” shall be substituted;
(b) in the Schedule,—
(i) for column 4 and the entries relating thereto the following shall be substituted, namely:—
“Level in the pay matrix
4
Level-6 (Rs. 35400-112400/-)”;
(ii) column (7) and the entries relating thereto, shall be omitted and columns 8 to 14 shall be renumbered as
columns 7 to 13 respectively;
(iii) in column (10) as so renumbered, under heading “Direct recruitment”,—
(I) in item (a) sub-item (ii), for the words and figures “Scale of Pay of Rs. 5000-8000)”, the words and figures
“Level-6 (Rs. 35400-112400/-)” shall be substituted;
(II)

in item (a) sub-item (iii), for the words and figures “Scale of Pay of Rs. 4500-125-7000)”, the words
and figures “Level-5 (Rs. 29200-92300/-)” shall be substituted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.

Note: The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 327, dated the 17th August, 2002 and subsequently amended vide notification numbers G.S.R 59
dated the 27th March, 2010.

अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 219(अ). —राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, क्षे ीय िनदश मानक योगशाला, समूह “ग” पद, भत िनयम,
2016 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह, अथार्त:् —
1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, क्षे ीय िनदश
मानक योगशाला, समूह “ग” पद, भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, क्षे ीय िनदश मानक योगशाला, समूह “ग” पद,
भत िनयम, 2016 म,
(ग)

िनयम 3 म, “वेतन बड और ड
े वेतन या वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द
रखे जाएंगे।

(घ) अनुसूची म,
(i) उच्च ेणी िलिपक के पद से संबंिधत म संख्या 1 के सामने, (इ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:-

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

“वेतन मैि क्स म स्तर
(4)
स्तर- (25500-81100/- रु.)”;
(आ) स्तंभ (11) म, (I) “ ोन्नित” शीषर्क के अधीन, -(i) “वेतन बड-1, 5200-20200 रुपये और ड
े वेतन 1900 रुपये” शब्द और अंक के स्थान पर “स्तर-2 (1990063200/- रु.)” शब्द और अंक रखे जाएंग;े
(ii) िटप्पण 2 का लोप िकया जाएगा;
(II) “ ितिनयुि ” शीषर्क के अधीन,-(i) “वेतन बड-1, 5200-20200 रुपये और ड
े वेतन 1900 रुपये” शब्द और अंक के स्थान “स्तर-2 (1990063200/- रु.)” शब्द और अंक रखे जाएंगे ;
(ii) िटप्पण 4 का लाप िकया जाएगा;
(ii) आशुिलिपक ड
े -2 के पद से संबंिधत म संख्या 2 के सामने, स्तंभ (4) के अधीन
िनम्निलिखत िवि यां रखी जाएगी, अथार्त,् :-

िवि य के स्थान पर

“स्तर-4 (25500-81100/-रु.)”;
(iii) अवर ण
े ी िलिपक के पद से संबंिधत म संख्या 3 के सामने,(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त्:“स्तर-2 (19900-63200/- रु.)”;
(आ) स्तंभ (10) म,
(i) मद (ii) म “वेतन बड-1, 5200-20200 रुपये और 1800 रुपये ड
े वेतन” शब्द और अंक के
स्थान पर “स्तर-1 (18000-56900/- रु.)” शब्द और अंक रखे जाएंगे;
(ii) िटप्पण 2, मद (ii) म “1800 रुपये ड
े वेतन” शब्द और अंक के स्थान पर “स्तर-1 (1800056900/- रु.)” शब्द और अंक रखे जाएंग;े
(iv) स्टाफ कार चालक (साधारण ण
े ी) के पद से संबंिधत म संख्या 4 के सामने,
(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त्:“स्तर-2 (19900-63200/- रु.)”;
(आ) स्तंभ (11) म, “ ितिनयुि /आमेलन” शीषर्क के अधीन “वेतन बड-1, 5200-20200 रु. के साथ
1800 रुपये ड
े वेतन” शब्द और अंक के स्थान पर “स्तर-1 (18000-56900 रु.)” शब्द और अंक
रखे जाएंग;े
(v) बहु कायर् कमर्चारीवृंद के पद से संबंिधत म संख्या 5 के सामने, स्तंभ (4) के अधीन िवि य के स्थान पर
िनम्निलिखत िवि यां रखी जाएगी, अथार्त् :“स्तर-1 (18000-56900/- रु.)”।
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग II, खंड 3, उपखंड (i) म सा.का.िन. सं. 347(अ), तारीख 29 माचर्, 2016 ारा कािशत िकए
गए थे।

<!-- page 13 -->

¹Hkkx IIμ[k.M 3(i)º

13

Hkkjr dk jkti=k % vlk/kj.k
NOTIFICATION
New Delhi, the 7th March, 2017

G.S.R. 219(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules to amend the Ministry of Consumer Affairs, Food and Public Distribution,
Department of Consumer Affairs, Regional Reference Standards Laboratories, Group ‘C’ posts, Recruitment Rules,
2016, namely:1. (1) These rules may be called the Ministry of Consumer Affairs, Food and Public Distribution, Department of
Consumer Affairs, Regional Reference Standards Laboratories, Group ‘C’ posts, Recruitment (Amendment) Rules,
2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Ministry of Consumer Affairs, Food and Public Distribution, Department of Consumer Affairs, Regional
Reference Standards Laboratories, Group ‘C’ posts, Recruitment Rules, 2016,(a) in rule 3, for the words “pay band and grade pay or pay scale” at both the places, the words “level in the pay
matrix” shall be substituted;
(b) in the Schedule,(i) against serial number 1 relating to the post of Upper Division Clerk,(A) for column (4) and the entries relating thereto the following shall be substituted, namely:“Level in the pay matrix
(4)
Level-4 (Rs.25500-81100/-)”;
(B) in column (11),(I) under heading “Promotion”,(i) for the words and figures “Pay Band-1(Rs.5200-20200) with grade pay Rs.1900/-”,the words and
figures “Level-2 (Rs.19900-63200/-)” shall be substituted;
(ii) Note 2 shall be omitted;
(II) under heading “Deputation”,(i) for the words and figures “Pay Band-1(Rs.5200-20200) with grade pay Rs.1900/-”,the words and
figures “Level-2 (Rs. 19900-63200/-)” shall be substituted;
(ii) Note 4 shall be omitted;
(ii) against serial number 2 relating to the post of Stenographer Grade II, for the entries under column (4), the
following entries shall be substituted, namely:“Level-4 (Rs. 25500-81100/-)”;
(iii) against serial number 3 relating to the post of Lower Division Clerk,(A) for the entries under column (4), the following entries shall be substituted, namely:“Level-2 (Rs. 19900-63200/-)”;
(B) in column (10),(I)

in item (ii), for the words and figures “Pay Band-1 (Rs. 5200-20200) with grade pay Rs. 1800/-”, the
words and figures “Level-1 (Rs. 18000-56900/-)” shall be substituted;

(II)

Note 2, in item (iii), for the words and figures “grade pay of Rs.1800/-”, the words and figures “Level-1
(Rs. 18000-56900/-)” shall be substituted;

(iv) against serial number 4 relating to the post of Staff Car Driver (Ordinary Grade),(A) for the entries under column (4), the following entries shall be substituted, namely:“Level-2 (Rs. 19900-63200/-)”;

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(B) in column (11),under heading “Deputation/absorption”, for the words and figures “pay band -1, Rs. 520020200 with grade pay of Rs. 1800/-”, at both the places, the words and figures “Level-1(Rs. 18000-56900/-)”
shall be substituted;
(v)

against serial number 5 relating to the post of Multi-Tasking Staff, for the entries under column (4), the
following entries shall be substituted, namely:“Level-1 (Rs. 18000-56900/-)”.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.

Note: The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 347(E), dated the 29th March, 2016.
अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 220(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले िवभाग [िनदेशक (सहकािरता)] भत िनयम, 2003 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह, अथार्त:् 1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले िवभाग [िनदेशक (सहकािरता)] भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. उपभोक्ता मामले िवभाग [िनदेशक (सहकािरता)] भत िनयम, 2003 म,
(क) िनयम 2 म, “वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे जाएंग।े
(ख) अनुसूची म,
(अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:“वेतन मैि क्स म स्तर
(4)
स्तर-12 (78800-209200/- रु.)”;
(आ) स्तंभ (7) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (8) से स्तंभ (14) को मश: स्तंभ (7) से स्तंभ
(13) के रूप म पुन: संख्यािकत िकया जाएगा ;
(इ) पुन:संख्यािकत िकया गया स्तंभ (11) म, (I) “ ोन्नित” शीषर्क के अधीन, “10,000-15,200 रुपए के वेतनमान” शब्द और अंक के स्थान पर “स्तर -11
(67700-208700/- रु.)” शब्द और अंक रखे जाएंगे;
(II) “ ितिनयुि ” शीषर्क के अधीन,मद (क) के उपमद (ii) म “10,000-15,200 रुपए वेतनमान” शब्द और अंक के
स्थान पर “स्तर -11 (67700-208700/- रु.)” शब्द और अंक रखे जाएंग;े
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण : मूल िनयम भारत के राजप भाग-II, खंड 3 उपखंड (i) म सा.का.िन. सं. 337, तारीख 20 िसतंबर, 2003
गए थे और तत्पश्चात् सा.का.िन. सं. 158, तारीख 21 मई, 2011 ारा संशोिधत िकए गए।

ारा कािशत िकए

NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 220(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Department of Consumer Affairs [Director
(Cooperation)] Recruitment Rules, 2003, namely:-

<!-- page 15 -->

¹Hkkx IIμ[k.M 3(i)º

15

Hkkjr dk jkti=k % vlk/kj.k

1. (1) These rules may be called the Department of Consumer Affairs [Director (Cooperation)] Recruitment
(Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Department of Consumer Affairs [Director (Cooperation)] Recruitment Rules, 2003,(a) in rule 2, for the words “Scale of pay” at both the places, the words “level in the pay matrix” shall be substituted;
(b) in the Schedule,(A) for column 4 and the entries relating thereto the following shall be substituted, namely:“Level in the pay matrix
4
Level-12 (Rs. 78800-209200/-)”;
(B) column (7) and the entries relating thereto, shall be omitted and columns 8 to 14 shall be renumbered as
columns 7 to 13 respectively;
(C) in column (11) as so renumbered,(I) under heading “Promotion”, for the words and figures “Scale of Pay of Rs. 10000-15200”, the words and
figures “Level-11 (Rs.67700-208700/-)” shall be substituted;
(II) under heading “Deputation”, in item (a) sub-item (ii), for the words and figures “Scale of Pay of Rs. 1000015200”, the words and figures “Level-11 (Rs. 67700-208700/-)” shall be substituted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.
Note: - The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 337, dated the 20th September, 2003 and subsequently amended vide notification number
G.S.R 158 dated the 21st May, 2011.
अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 221(अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, उपिनदेशक (सहकािरता) और ज्येष्ठ तकनीकी सहायक ण
े ी-II
के भत िनयम, 2005 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते ह, अथार्त:् 1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, उपिनदेशक
(सहकािरता), सहायक िनदेशक (सहकािरता) और ज्येष्ठ तकनीकी सहायक ेणी-II भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, उपिनदेशक (सहकािरता), सहायक िनदेशक
े ी-II के भत िनयम, 2005 म,
(सहकािरता) और ज्येष्ठ तकनीकी सहायक ण
(क) िनयम 3 म, “वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे जाएंगे।
(ख) अनुसूची म,
(i) उप िनदेशक (सहकािरता) के पद से संबंिधत म संख्या 1 के सामने, (अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:—
“वेतन मैि क्स म स्तर
(4)
स्तर- 11 (67700-208700/- रु.)”;
(आ) स्तंभ (7) और उससे संबंिधत िवि य का लोप िकया जाएगा और स्तंभ (8) से स्तंभ (14) को मश: स्तंभ (7) से स्तंभ
(13) के रूप म पुन:संख्यािकत िकया जाएगा;
(इ) पुन:संख्यािकत िकया गया स्तंभ (11) म,-(I) “ ोन्नित” शीषर्क के अधीन,“8000-13500 रु. के वेतनमान”शब्द और अंक के स्थान पर “स्तर-10(56100-177500/-रु.)”
शब्द और अंक रखे जाएंग;े

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(II) “ ितिनयुि ” शीषर्क के अधीन, मद (क) के उपमद (ii) म “8000-275-13500 रुपए वेतनमान” शब्द और अंक के स्थान
“स्तर-10 (56100-177500/- रु.)” शब्द और अंक रखे जाएंगे ;
(ii) सहायक िनदेशक (सहकािरता) के पद से संबंिधत म संख्या 2 के सामने,(अ) स्तंभ (4) के अधीन िवि य के स्थान पर िनम्निलिखत िवि यां रखी जाएगी, अथार्त्,:“स्तर-10 (56100-177500/- रु.)”;
(आ) पुन:संख्यािकत िकया गया स्तंभ (11) म, -(I) “ ोन्नित” शीषर्क के अधीन,
(i) “6500-10,500/- रुपए के वेतनमान” दोन स्थान पर, शब्द और अंक के स्थान पर “स्तर-7 (44900142400/- रु.)” शब्द और अंक रखे जाएंग;े
(ii) “5500-9000/- रुपए के वेतनमान” शब्द और अंक के स्थान पर “स्तर-6 (35400-112400/- रु.)” शब्द
और अंक रखे जाएंगे।
(II)“ ितिनयुि ” शीषर्क के अधीन,
(i) मद (क) के उपमद (ii) म “6500-200-10,500 रुपए के वेतनमान” शब्द और अंक के स्थान पर “स्तर-7
(44900-142400/-रु.)” शब्द और अंक रखे जाएंगे;
(ii) मद (क) के उपमद (iii) म “5500-175-9000/- रुपए के वेतनमान” शब्द और अंक के स्थान पर “स्तर-6
(35400-112400/- रु.)” शब्द और अंक रखे जाएंगे;
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग-2, खंड 3 उपखंड (i) म सा.का.िन. सं. 318, तारीख 17 िसतंबर, 2005
गए थे और तत्पश्चात् सा.का.िन. सं. 157, तारीख 21 मई, 2011 ारा संशोिधत िकए गए ।

ारा कािशत िकए

NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 221(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Ministry of Consumer Affairs, Food and Public
Distribution, Department of Consumer Affairs, Deputy Director(Co-operation), Assistant Director (Co-operation) and
Senior Technical Assistant Grade II Recruitment Rules, 2005, namely:1. (1) These rules may be called the Ministry of Consumer Affairs, Food and Public Distribution, Department of
Consumer Affairs, Deputy Director (Co-operation), Assistant Director (Co-operation) and Senior Technical
Assistant Grade II, Recruitment (Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Ministry of Consumer Affairs, Food and Public Distribution, Department of Consumer Affairs, Deputy
Director(Co-operation), Assistant Director (Co-operation) and Senior Technical Assistant Grade II Recruitment
Rules, 2005,(a) in rule 2, for the words “scale of pay” at both the places, the words “level in the pay matrix” shall be substituted;
(b) in the Schedule,(i) against serial number 1 relating to the post of Deputy Director (Co-operation),(A) for column 4 and the entries relating thereto the following shall be substituted, namely:“Level in the pay matrix
4
Level-11 (Rs. 67700-208700/-)”;

<!-- page 17 -->

¹Hkkx IIμ[k.M 3(i)º

17

Hkkjr dk jkti=k % vlk/kj.k

(B) column (7) and the entries relating thereto, shall be omitted and columns 8 to 14 shall be renumbered as
columns 7 to 13 respectively;
(C) in column (11) as so renumbered,(I) under heading “Promotion”, for the words and figures “Pay Band-1(Rs.8000-13500)”, the words and figures
“Level-10 (Rs.56100-177500/-)” shall be substituted;
(II) under heading “Deputation”, in item (a) sub-item (ii), for the words and figures “pay scale of Rs.8000-27513500”,the words and figures “Level-10 (Rs.56100-177500/-)” shall be substituted;
(ii)

against serial number 2 relating to the post of Assistant Director (Co-operation),-

(A) for the entries under column (4), the following entries shall be substituted, namely:“Level-10 (Rs.56100-177500/-)”;
(B) in column (11) as so renumbered,(I) under heading “Promotion”,(i) for the words and figures “pay scale of Rs.6500-10500”, at both the places, the words and figures “Level-7
(Rs.44900-142400/-)” shall be substituted;
(ii) for the words and figures “pay scale of Rs.5500-9000”,the words and figures
112400/-)” shall be substituted;

“Level-6 (Rs.35400-

(II) under heading “Deputation”,(i) in item (a) sub-item (ii), for the words and figures “pay scale of Rs. 6500-200-10500”,the words and figures
“Level-7 (Rs.44900-142400/-)” shall be substituted;
(ii) in item (a) sub-item (iii), for the words and figures “pay scale of Rs. 5500-175-9000”,the words and figures
“Level-6 (Rs.35400-112400/-)” shall be substituted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.
Note: The principal rules were published in the Gazette of India, Part II, Section 3, sub-Section (i) vide notification
number G.S.R. 318, dated the 17th September, 2005 and subsequently amended vide notification number G.S.R.
157, dated the 21st May, 2011.
अिधसूचना
नई िदल्ली, 7 माचर्, 2017
सा.का.िन. 222(अ).— राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए राष् ीय
उपभोक्ता िववाद िततोष आयोग (रिजस् ार) भत िनयम, 2014 का और संशोधन करने के िलए िनम्निलिखत िनयम बनाते है, अथार्त:् 1. (1)

इन िनयम का संिक्षप्त नाम राष् ीय उपभोक्ता िववाद िततोष आयोग (रिजस् ार) भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. राष् ीय उपभोक्ता िववाद िततोष आयोग (रिजस् ार) भत िनयम, 2014 म,
(क) िनयम 3 म, “वेतन बड तथा ड
े वेतन या वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे
जाएंगे।
(ख) अनुसूची म,
(अ) स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त्:“वेतन मैि क्स म स्तर
(4)
स्तर-14 (144200-218200/- रु.)”;
(आ) स्तंभ (11) म, “ ितिनयुि ” शीषर्क के अधीन;

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY
(i)

[PART II—SEC. 3(i)]

मद (क) के ,
(अ)

उपमद (ii) म, “वेतन बड-4, 37,400-67,00 रु. + ड
े वेतन 8,900 रु.” शब्द और अंक के स्थान पर
“स्तर-13क (131100-216600/- रु.) ” शब्द और अंक रखे जाएंग;े

(आ)

उपमद (iii) म,“वेतन बड-4, 37,400-67,000 रु.+ ड
े वेतन 8,700 रु.” शब्द और अंक के स्थान पर
“स्तर-13 (118500-214100/- रु.)” शब्द और अंक रखे जाएंग;े

(ii)

िटप्पण 1 म, “37,400-67,000 रु. के वेतन बड और 8,700 रु. के
“स्तर-13 (118500-214100/-रु.)” शब्द और अंक रखे जाएंगे।

(iii)

िटप्पण 3 का लोप िकया जाएगा।

ड
े वेतन” शब्द और अंक के स्थान पर

[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन, अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग II, खंड 3 उप-खंड (i) म सा.का.िन. सं. 177(अ), तारीख 11 माचर्, 2014
िकए गए थे।

ारा कािशत

NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 222(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules to amend the National Consumer Disputes Redressal Commission
(Registrar) Recruitment Rules, 2014, namely:—
1. (1) These rules may be called the National Consumer Disputes Redressal Commission (Registrar), Recruitment
(Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the National Consumer Disputes Redressal Commission (Registrar) Recruitment Rules, 2014,—
(a) in rule 3, for the words “Pay Band and Grade Pay or scale of pay” at both the places, the words “level in the pay
matrix” shall be substituted;
(b) in the Schedule,—
(A) for column (4) and the entries relating thereto the following shall be substituted, namely:—
“Level in the pay matrix
(4)
Level-14 (Rs.144200-218200/-)”;

(B) in column (11), under heading “Deputation”,–
(i)

in item (A),(a) sub-item (II), for the words and figures “Pay Band-4, Rs. 37400-67000 plus grade pay of
Rs. 8900/-”, the words and figures “Level-13A (Rs. 131100-216600/-)” shall be substituted;
(b) sub-item (III), for the words and figures “Pay Band-4, Rs. 37400-67000 plus grade pay of
Rs.8700/-“, the words and figures “Level-13(Rs. 118500-214100/-)” shall be substituted;

(ii)
(iii)

in Note 1, for the words and figures “Pay Band of Rs. 37400-67000 plus grade pay of Rs. 8700/-”, the
words and figures “Level-13 (Rs. 118500-214100/-)” shall be substituted;
Note 3 shall be omitted.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.

Note: The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 177(E), dated the 11th March, 2014.

<!-- page 19 -->

¹Hkkx IIμ[k.M 3(i)º

19

Hkkjr dk jkti=k % vlk/kj.k
अिधसूचना
नई िदल्ली, 7 माचर्, 2017

सा.का.िन. 223 (अ).—राष् पित, संिवधान के अनुच्छेद 309 के परन्तुक ारा द शि य का योग करते हुए उपभोक्ता
मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, बहु कायर् कमर्चारीवृंद (समूह “ग”) पद, भत िनयम, 2012 का
और संशोधन करने के िलए िनम्निलिखत िनयम बनाते है, अथार्त:् 1. (1)

इन िनयम का संिक्षप्त नाम उपभोक्ता मामले, खा और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, बहु कायर्
कमर्चारीवृंद (समूह “ग”) पद, भत (संशोधन) िनयम, 2017 है।

(2) ये राजप म उनके काशन की तारीख को वृत्त ह गे।
2. उपभोक्ता मामले, खा
िनयम, 2012 म,

और सावर्जिनक िवतरण मं ालय, उपभोक्ता मामले िवभाग, बहु कायर् कमर्चारीवृंद (समूह “ग”) पद, भत

(क) िनयम 2 म, “वेतन बड तथा ड
े वेतन या वेतनमान” दोन स्थान पर, शब्द के स्थान पर “वेतन मैि क्स म स्तर” शब्द रखे
जाएंगे।
(ख) अनुसूची म, स्तंभ (4) और उससे संबंिधत िवि य के स्थान पर िनम्निलिखत रखा जाएगा, अथार्त:् “वेतन मैि क्स म स्तर
(4)
स्तर-1 (18000-56900/- रु.)”;
[फा. सं. ए-12018/4/2016-स्था.]
जय ी नारायणन,अवर सिचव
िटप्पण: मूल िनयम भारत के राजप भाग II, खंड 3 उपखंड (i) म सा.का.िन. सं. 252, तारीख 13 अक्टू बर, 2012
गए थे।

ारा कािशत िकए

NOTIFICATION
New Delhi, the 7th March, 2017
G.S.R. 223(E).—In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules to amend the Ministry of Consumer Affairs, Food and Public
Distribution,(Department of Consumer Affairs) Multi-Tasking Staff (Group ‘C’) posts Recruitment Rules, 2012,
namely:—
1. (1) These rules may be called the Ministry of Consumer Affairs, Food and Public Distribution,(Department of
Consumer Affairs) Multi-Tasking Staff (Group ‘C’) posts, Recruitment (Amendment) Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Ministry of Consumer Affairs, Food and Public Distribution,(Department of Consumer Affairs) Multi-Tasking
Staff (Group ‘C’) posts Recruitment Rules, 2012,—
(a) in rule 2, for the words “pay band and grade pay /scale of pay” at both the places, the words “level in the pay
matrix” shall be substituted;
(b) in the Schedule, for column (4) and the entries relating thereto the following shall be substituted, namely:—
“Level in the pay matrix
(4)
Level-1 (Rs. 18000-56900/-)”.
[F. No. A-12018/4/2016-Estt.]
JAYASHREE NARAYANAN, Under Secy.
Note: The principal rules were published in the Gazette of India, Part II, Section 3, Sub-section (i) vide notification
number G.S.R. 252, dated the 13th October, 2012.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed
by ALOK KUMAR
Date: 2017.03.15
15:14:28 +05'30'

ALOK
KUMAR
