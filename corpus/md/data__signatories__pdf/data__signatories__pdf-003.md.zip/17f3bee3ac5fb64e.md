---
doc_id: "17f3bee3ac5fb64e"
source_url: "https://mohua.gov.in/static/uploads/2025/11/620db786916deebd11b7193b6a108a5c.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 179.21 lakh (including 0&M charges) to State of Mizoram as 3rd and final installment of Central Assistance for construction of 142 DUs at Zuangtui, Aizawl, Mizoram under RAY subsumed in PMAY-U Mission - reg."
date: "2021-03-26"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "dcfa8582ee691a38"
---

<!-- page 1 -->

https://pfms.nic.in/Sanction/TemplateA dvice.aspx?AdviceNum=i2...
द्रव
. PAO(Sectt.)/HUA/Admin/Advice/2020-21/ 2५789 - 74
GOVERNMENT OF INDIA a
PAO(Sectt.), Ministry of Housing and Urban Affairs
507-C Wing, Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664

To,
The General Manager,
Reserve Bank of India,
Central Accounts Section, |Advice No:
Additional Office Building, Advicé Date:/26/03/2021|
East High Court Road,
NAGPUR - 440 001
Sir,

Please debit our account with Rs.1,79,21,000/- (One Crore Seventy Nine Lakh Twenty One
Thousand Only.) by contra credit to the following accounts of the Governments with the amounts
mentioned against each:

Month and Year of Accounts: March,2021 है The Amount to be Settled: March,2021
Name of State Scheme Code Amount | Sanction No. and Date
the State Code
1 MIZORAM 121 1989-STATE AND UT 1,79,21,000 | N-11018/11/2018-HFA-V-D
GRANTS UNDER PMAY (FTS-9046189) dated
(URBAN) 26/03/2021
Signature of the authorized official
(Pawan Kumar Bhatnagar)
Sr. Accounts Officer
1. O/o the Accountant General (A&E), Mizoram, Izawl-796001
2/Sh. B.K. Mandal, US (HFA-V) , M/o Housing and Urban Affairs, New Delhi-110011.
Pawan Kumar Bhatnagar
Sr. Accounts Officer
OB Ms: HFA
ae Ww,
\ oS
fl ४ 26-03-2021 16:54

<!-- page 2 -->

है . eG N-11018/11/2018-HFA-V-D (FTS-9046189)
2 Ministry of Housing and Urban Affairs
ee (HFA-V Division)
ee Room No. 03, Technical Cell, Gate No. 7,
oe Nirman Bhawan, New Delhi.
é i Dated: 26.03.2021
TOs. i
: The Pay and Accounts Officer (Sectt.),
: Ministry of Housing and Urban Affairs,
Nirman Bhawan, eles
: New Delhi-11 :
: Subject: Release of Rs. 179.21: lakh (including O&M charges) to State of
z alos Mizoram. as 3% and final installment of Central Assistance for
a construction of 142 DUs at Zuangtui, Aizawl, Mizoram under RAY
. ® subsumed in PMAY-U Mission - reg.
Sir, i
«OE | am directed to-convey the sanction of Competent Authority to the release of
se Rs, 1,79,21,000/- (Rupees One Crore Seventy Nine Lakh and Twenty One
ees » - Thousand Only) (including O&M charges) to State Goverment of Mizoram as
3” and final installment of Central Assistance for construction of 142 DUs at
Zuangtui, Aizawl, Mizoram under Rajiv Awas Yojana (RAY) subsumed in Pradhan
मी Mantri Awas Yojana — Urban (PMAY-U) Mission for the FY 2020-21.
* 2. The statement showing details of the projects against which the above
: 6 amounts stand sanctioned to the State is enclosed at Annexure.
SE 3. Based on compliance to the conditions for release of 3" and final instalment
A of Central Assistance for RAY project, the amount of ACA is being released subject
to the following conditions:
i. Necessary sanctions/approvals/compliances required under the Statutory
= or other regulatory regime as applicable would be obtained by the

; authority (ies) concerned with the project (s).

5 ii. The State Government.and implementing agency shall put in place a
monitoring system to ensure that the project(s) achieve its scheduled
milestone and envisaged outcomes including implementation of reforms

i and other conditionalities required under the scheme.
ili. These project(s) shall be completed within the period of PMAY-U (RAY
liabilities) for implementation of projects.
iv. The State shall utilize the grant in accordance with the approved
guidelines for the implementation of the scheme.
Vv. The State shall fumish the Utilization Certificates (UCs) of the Grant
released for the RAY project (s) in the prescribed format as per GFR 2017.
vi. The funds may be utilized for the purpose for which they are given
otherwise they will have to be refunded along with interest as per
provisions for GFR 2017.
vii. | Where there is an element of cash transfer, the same may be made
through PFMS/DBT mode as applicable.
4. Payment may kindly be made to the State Government immediately. The
funds may thereafter be. released to the implementing agencies without any delay
failing which the amounts would be recovered from the State Government with
interest for the period of default.
wet

<!-- page 3 -->

: 2 5
हू 5. The amount is debitable from the account of the Central Government in the books — -
under the following Head of Accounts under Demand No. 57 of the Ministry of Housing and i
Urban Affairs for the year 2020-21: हे
[3601 _[Grants-in-aid to State Governments
, Sub-Major Head | 06 _|Centrally Sponsored Schemes
entral Assistance/Share
radhan Maniri Awas Yojana (Urban)
Detailed Head | 01 _|Assistance to State Govt. for PMAY-U
Object Head | 31.01.35 _|Grants for Creation of Capital Assets
6. The amount will be credited to the State Government's account at RBI
as per procedure laid down by Ministry of Finance, Department of Expenditure in
this regard.
7. State Govt. of Mizoram has submitted the UCs of Rs. 316.34 lakh for
4 instalment of Central Assistance and UC of Rs. 434.52 lakh for 2° instalment of
Central Assistance already released for the project, which are enclosed herewith.
8. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority
and audit, both by the Comptroller and Auditor General of India under the provision
of CAG (DPC) Act 1971 and internal audit by the Principal Accounts Office of the
Ministry or Department, whenever the Institution or Organisation is called upon to do
so.
9. This issues with the concurrence of the Finance Division vide Note #86 of
even number dated 25.11.2020.
10. This sanction has been registered at S. No.4 of the Grants-in-Aid Register
of the HFA Division for the year 2020-21.
Yours re lly,
(B.K. Mandal)
Under Secretary to the Government of India
Tele: 011-23063285
Copy to:
1. Secretary, Urban Development & Poverty Alleviation Deptt., Government of
Mizoram, Aizawl
2. Accountant General (A&E), Mizoram
3. Niti Ayog, SP Division, FR Division, New Delhi
4. CGM, RBI, CAS, Nagpur
5. Dir. (1FD), MoHUA
6. Dir. (HFA-3), MoHUA
7. DS (Budget), MoHUA
8. DDO/Section Officer (Admn-il), MoHUA, Nirman Bhawan, New Deihi
9. PMU(MIS), HFA Directorate may place this sanction at appropriate place on
the Website of the Ministry
10. Dy. Chief (MiS), HFA Directorate
11, Sanction folder at 2.
(B.K. Mandal)
Under Secretary to the Government of India

<!-- page 4 -->

- : 8.०
७956 | |
4 11015
é Bess
85:57
vas
2g
Um we
goes
883
22
~ 8
mse =
8 | 1856 Ik |
& 5526 :
| BE bg
= | gees
= Sosy
4 “aga
: a
ae & |
g | #83 als a
& हक
हू e Pe
3 Bae
< 295
5, ae
4
3 ~ 444६
2 g Ne
§ 53 =
8 | 8o%
ae
3
eee
EC
<
५2
o &
Dp oe
Eg ieee
- 8 “व
ह Bele
है... है
५
गर्व

<!-- page 5 -->

er et ee a ea a a ee a ee ee eee eee eee
7 2170६
५ 110086/2018॥17&-५ 5६९110104 Form GFR 19-A ५
[See Rule 212 (1)] eek
Form of Utilization Certificate :
Certified that out of Rs. 316.34 lakhs Grants-in-aid sanctioned during the year 2012 - 2013 ia
favour of RAY Pilot Project at Zuangtui, Aizawl under this Ministry/ Department Letter no
given in the margin and Rs. Nil On account of unspent balance of the year, a sum of Rs. 316.34
lakh has been utilized for the purpose of RAY Pilot Project at Zuangtui, Aizawl for which it was
sanctioned and that the balance of Rs. Nil remaining utilized at the end of the year has been
surrendered to Government (Vide NO... ated nee) will be
adjusted towards the grant-in-aid payable during the next year.
In lakh:
= Lace kat ame
No. >>
रे F. No. 59(8)PF-1/2012-1092 dt. 19.12.2012 Rs. 316.34
fe ee
2. Certified that I have satisfied myself that the conditions on which the grant-in-aid was
sanctioned have been duly fulfilled/ are being fulfilled and that | have exercised the following
checks to see that the money was actually utilized for the purpose for which it was sanctioned.
Kinds of checks exercised
1. Works executed till date have been verified
2. Concurrence of State’s Finance Department obtained for expenditure sanction
3. Value of works done calculated by Technical Wing & RAY Technical Cell of UD&PA
Department has been verified
4. Payments made have been verified from cash books and vouchers/APRs
lg = न
te (ZORAMMUANA) ale Ne (0०५ ie MSANGA) बह
Director ls hy = ry to the Govt. of Mizoram
Urban Dev. & Poverty Alleviation ptt. es /shan Dev. & Poverty Alleviation Deptt.
ey % OERTY BN ४. erly Alteviation Deptt.
Dav. & Poverty Ateviation, SS"
i vee Govt of Mexoram Gow. of Mizoram

<!-- page 6 -->

————— मन नमन मन न न न न मन न नमन ननन न न न नमन मनन न न_ न न नमन न न न कनननक नमन न न नं _ल नननननीनन न नीन न न न न न न नननननननननन न न न न» +नननननननननननननन न1नान1न ना नीनीनननननननभ न नननननन न नीनननननीनननननननननत न न ननननभनतनत 6
7 ; r oe oe
| Gs
हु Form GFR 19-A
; 5 z [See Rule 212 (1)] दे
f Form of Utilization Certificate }
ny | |
| Certified that out of Rs, 434.52 lakhs Grants-in-aid sanctioned during the year 2015 - 2016 in :
: favour of RAY Pilot Project at Zuangtul, Aizawl under this Ministry/ Department Letter no 4
i 1 given in the margin and Rs. Nil On account of unspent balance of the year, asum of Rs. 434.52
| ‘ _. Jakh has been utilized for the purpose of RAY Pilot Project at Zuangtui, Aizawl for which it was
i i sanctioned and that the balance of Rs. Nil remaining utilized at the end of the year has been
i surrendered to Government (शंप्रल 1१०....................--०-०--- पंगशत॑...........................)/ will be
E हे adjusted towards the grant-in-aid payable during the next year. i
| : In lakh
कब : ४ 1... |F.No. G-20011/9/2014/BSUP(RAY)/JNNURM Vol. Rs. 434.52 .
7 2 VI/HFA-2(FTS-10830) dt. 11th August, 2015
i (2nd Installment of Central Share)
'
é 2, Certified that |. have satisfied myself that the conditions on which the grant-in-aid was 4
sanctioned have been duly fulfilled/ are being fulfilled and that 1 have exercised the following ;
checks to see that the money was actually utilized for the purpose for which it was sanctioned.
: |
Kinds of checks exercised
1. Works executed till date have been verified
2. Concurrence of State's Finance Department obtained for expenditure sanction
3..Value of works done calculated by Technical Wing & RAY Technical Cell of UD&PA
Department has been verified
4. Payments made have been verified from cash books and vouchers/APRs
५४ % Q
‘s ०2
! pz LZARZOENGA) [3 we A r. eee nee VANI MSANGA) l
5 Joint Director 5 ‘ 3 tary to the Govt. of Mizoram -
Urban Dev. & Poverty Alleviation Lox yy, Dev. & Poverty Alleviation Deptt. &
: Govt. of Mizoram © a >“ LS हु Govt.of Mizoram .

<!-- page 7 -->
