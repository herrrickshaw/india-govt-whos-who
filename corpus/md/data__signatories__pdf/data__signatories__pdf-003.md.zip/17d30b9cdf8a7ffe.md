---
doc_id: "17d30b9cdf8a7ffe"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/381b66da612ca392c0f20b983f0f27b1.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Inviting E-tender for lifting of torn bits / waste paper etc. in Udyog Bhawan"
date: "2025-06-30"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "581a50b03b13bda8"
---

<!-- page 1 -->

-1-

No. D-27017/01/2022-SEO
Government of India
Ministry of Commerce and Industry
Department for Promotion oflndustry ,and Internal Trade
(SEO Section)
Udyog Bhawan, New Delhi
Dated, the c,i"March, 2023
OFFICE MEMORANDUM
Subject: Inviting E-tender for lifting of torn bits I waste paper etc. in Udyog Bhawan­
regarding.

Online bids are hereby invited for e-Tender on the subject mentioned above under Single­
Bid-Systcm from the reputed services ,iroviders to enter into an annual contract for lifting of
tom bits/waste paper etc. from Udyog Bhawan, New Delhi.
2.

The Schedule of Invitation of E-Tender Notice is as under:-

S. No.
Date
Activity
06.03-2023 (Monday)
I. Date of Invitation of Tender:
06.03.2023 (by 4:00 PM) [Monday]
2. ...ast date of submission EMD etc.:
3. L.ast date and time for online 17.03.2023 [Friday]
(upto 5:00 P.M).
submi�sion of Tender document
20.03.2023 (Monday) at 04:00 PM
4. Opening of online Bid
3. The interested agencies/firms may submit their bids as per schedule mentioned in the
aforesaid Table and inspect the office premises before submission of tender at any time behYeen
1 t.00 A.M. to 3.00 P.M. on any working day from 06-03-2023 to 16-03-2023 to assess the job.
Shri Rajender Prasad, Section Officer (SEO Section) may be contacted in Room No.28, Udyog
Bhawan, New Delhi (Tel. No. 011-23063448). The tender documents can be downloaded
through CPP portal from the date of its publication i.e. 06.03.2023 on the CPP portal. Online
bids, complete in all respects, should be submitted through CPP portal
http://eproc11re.gov.i11/eprocurelapp only on or before the last date and time as mentioned
above.
4. In case, any holiday is declared by the Government on the day of opening of tenders, it will
be opened on the next working day at the same time. The Department reserves the right to
accept or reject any tender without assigning any reason therefor.

<!-- page 2 -->

-25.
NlC, DPIIT is requested to upload the e-Tender Notice on the CPP portal
"http://eproc11re.gov.inleproc11re/app" for its wide publicity among the interested bidders.

�\�vil,
;_,....-_-.--:i'
n,\o�r 'I,>
),f

( Ram Nar1esh)
Under Secretary to the Government oflndia
Tel. No. 23038894
To
Shri Yatinder Saxena, HOD, NIC-DPllT,
Room No. 352, 3rd Floor, Udyog Bhawan,
New Delhi-110011.

<!-- page 3 -->

.3.

No. D-27017/01/2022-SEO
Government of India
Ministry of Commerce and Industry
Department for Promotion of Industry and Internal Trade
(SEO Section)

E-TENDER NOTICE

Udyog Bha�, New Delhi
Dated1the 6 March, 2023

FOR LIFTING OF TORN BITS/WASTE PAPER ETC.
Online bids are invited by the Department for Promotion of Industry and Internal Trade,
Udyog Bhawan from the reputed service providers to enter into an annual contract for lifting of
torn bits/waste paper etc. from Udyog Bhawan, New Delhi. The tender documents can be
downloaded from the CPP portal i.e. "http://eprocure.gov.in/eprocure/app" from the date
of its publication i.e. 06.03.2023 on the CPP portal.
2.
The detailed Terms and Conditions (T&C) of the contract are given at Annexure-1.
Proforma for Technical Bid is at A1111exure-JJ andProfom1a for Financial Bid is at A1111exure­
JTJ. Initially, the contract will be valid for a period of one year only, however, it may be
extended on mutual consent and subject to "Satisfactory Services", for a period of not more than
one year at a time (up to a maximum of two years) on review of performance, depending upon
the requirements and administrative conveniences of the Department. The approximate annual
value of the contract would be Rs. 9.00 Lakh.
3. All the documents in support of eligibility criteria etc. are to be scanned and uploaded
along with the Tender Documents. Tenders/Bides must be submitted through online mode
only. Tenders/Bids submitted by any other mode or incomplete tenders will not be
accepted. No tender documents will be accepted after the expiry of stipulated date and time
for the purpose under any circumstances whatsoever.
4.
The Earnest Money Deposit (EMO) of Rs. 45,000/· (Rupees Forty thousand only) i.e. 5%
of the annual value of the contract, in the form of Account Payee Demand Draft/Bankers Cheque
drawn in favour of DDO(Cash}, Department for Promotion of Industry and Internal Trade,
Udyog Bhawan, New Deihl. EMD can be submitted to the Section Officer (SEO), Room No.
28, Udyog Bbawan, New Delhi-110011 on anv working day from 06.03.2023 <Monday) to
17.03.2023 (Fridav) (up to 4:00 PM) . Bids received after the prescribed date and time will
not be considered. Late receipt of EMO or bids received without EMD will not be considered
and be disqualification/rejected. Department will not be responsible for later receipt of any bid
document or EMO thereof.
5.

Tenderers who are registered with NSIC/MSME authorities for tendered service/item are

exempted from payment of EMO on production of attested copy of certificate issued by

NSIC/MSME. However, the successful bidder awarded the contract will be required to pay
performance security in the form of an Account Payee Demand Draft, Fixed Deposit Receipt
from a Commercial bank, Bank Guarantee from a Commercial bank.

<!-- page 4 -->

-46.
The Online Bids will be opened by a Committee of Officers, constituted for the purpose
in the Department, on 2 0.03.2023 (Monday) at 4.00 PM in Room No.47 Udyog Bhawan, New
Delhi. After scrutiny of all the bids received, the contract will be awarded to the quaJified
and highest quoted bidder.
7.
The competent authority in the Department for Promotion of Industry and Internal Trade
reserves the right to cancel the tender at any time or amend / withdraw any of the terms and
conditions contained in the Tender Document, without assigning any reason, thereof.
�o ?-)

( Ram !lfa�ih
Under Secretary to the Government of India
Tel. No. 23038894
Copy for information and necessary action to:
I. General Administration Sections of aU Ministries/Departments, located at Udyog
Bhawan.
2. Reception Officer, Department for Promotion of Industry and Internal Trade, Gate No.
12, Udyog Bhawan, New Delhi.
3. NIC for placing this e-Tender Notice on the website of DPIIT for its wide publicity.
4. Notice Board of DPllT at Udyog Bbawan and Vanijya Bhawan, New Delhi.
5. CISF, Udyog Bhawan.

<!-- page 5 -->

.5.

ANNEXURE-1

The tendering agency/firm must fulfil the following General Terms and Conditions:•
a.

The office of the service providers should be located in Delhi / New Delhi. The
copy of proof of address is to be scanned and uploaded with the bid documents.

b. The interested firms/bidders should be registered with GST. The said document is
to be scanned and uploaded with bid documents.
c. The firm should have a PAN Number. Self-attested copy of the PAN card of the
bidding firms shall be scanned and uploaded with the bid documents.
d. The firms/bidders should not have been blacklisted by any Ministty/Department
of the Government of India. The tendering firms/bidders shall have to give a self­
declaration certificate that they have not been blacklisted or banned their business
dealings with the Ministries/Departments of the Government. The declaration
should be scanned and uploaded with the documents.
e. Io case it is found that the information/certificates furnished by the participating
firm are incorrect/wrong or bogus, the firm shalJ be blacklisted. Its bid will be
rejected and EMO/Performance security Deposit will be forfeited.
f.

After scrutiny of all the bids received, the contract will be awarded to the qualified
and highest quoted bidder.

g. The work of collecting of torn bits/waste paper etc. will start at 8.00 A.M. and will
continue till 5.00 P.M. on all working days. If the waste papers are not collected
between the hours mentioned above or not collected at all, a monetary penalty of
Rs. 1,000/- per day shall be imposed and recovered from the contractor.
h.

The contractor shall depute at least two labourers on all working days (i.e. Monday
to Saturday); the wages of the labourers shall be borne by the contractor.

i.

The person deputed shall not be below the age of 18 years and they shaU not
interfere in the duties and responsibilities of the employees of the Department.

J.

The Contractor shall ensure proper conduct of his personnel in office premises, and
enforce prohibition of conswnption of alcoholic drinks, paan, smoking, loitering
without work.

k. The contractor's personnel shall not enter or tty to enter the rooms. They will also
not divulge/disclose any details of office, operational process, technical know-how,
security arrangements, administrative /organizational matters, to any person.
I.

The contractor will strictly adhere to minimum wages for their employees
prescribed by Govt. of NCT of Delhi as revised from ti.me 10 time. They will also
adhere to Government rules relating to ESI/EPF, etc., whichever is applicable.

m. No sorting of the tom bit/waste paper material, collected from the building, would
be permitted in the office premises.

<!-- page 6 -->

-6-

n. The Department reserves the right to impose any other conditions for regulating the
contract in public interest.
o. Udyog Bbawan is a restricted area where movements and routes are restricted. The
Contractor shall have to apply for passes in respect of deployed workers, well in
advance for carrying out the work.
p.

The contractor shall not appoint any sub-contractor for the work or sub-let the
contract under any circumstances.

q. All disputes are subject to the jurisdiction of courts in the National Capital
Territory of Delhi and Agreement will be governed by and be construed in
accordance with the laws of the country.
r.

Incomplete bids in any manner shall not be accepted and are liable to be rejected
summarily.

s.

The tender of tenderer, who do not fulfil any of the above conditions and
incomplete tenders are liable to be summarily rejected at the risk and cost of the
tenderer only and any further correspondence in this regard will not be entertained.

t.

Conditional tenders are summarily liable to be rejected

2. Duration of Contract:
lnitially, the contract will be valid for a period of one year (12 months) only,
however, it may be extended on mutual consent and subject to "Satisfactory Services",
for a period of not more than one year at a lime (up to a maximum of two years) on
review of performance, depending upon the requirements and administrative
conveniences of the Department. 1n case the services of the contractor are not found
satisfactory or contractor fails to comply with any of the terms and conditions of this
contract or commits any breach of contract, the Department may terminate the contract
at any time. In such an eventuality, the performance security deposit submitted to the
Department by the contractor will be forfeited.
3.

Performance Security:

3% of the tendered amount will be the "Performance Security Deposit" in the case of
successful bidder, which may be furrlished in the form of Fixed Deposit Receipt from a
Commercial Bank or Bank Guarantee from a Commercial Bank. The Perfoanance
Security should be valid for a period of sixty days beyond the date of completion of all
contractual obligations of the contractor. Earnest Money will be refunded to the
successful bidder on receipt of Performance Security.

<!-- page 7 -->

4. Penalty:

-7-

4.1
In case the successful bidder does not accept the contract offered by this
Department for whatsoever reason(s) the EMD submitted by him ,vi.ll be forfeited.
4.2 The Storage (Godown) facilities would be provided only for a maximum period of
one mouth only. The tom bit/waste paper material stocked in the Godown of the
Department beyond one month will be seized and auctioned. All expenses incurred in
connection with the auction process will be recovered fr o m the contractor. The contractor
will also be charged rent of the godown @ Rs. 1,000/- per day for every day beyond the
authorized period of one month tiIJ the auction takes place. It will be contractor's
responsibility to keep the surrounding of the waste paper Godown neat and clean in all
respect, otherwise necessary action, as deem appropriate will be taken by the Department
with the approval of the competent authority. The contractor will make his own
arrangements for removal ofstored waste paper, etc., from the godown.
5. Mode of Payment:
Payment shall be made in monthly instalment, i.e., J/12 of total contract value is
required to be deposited by contractor in advance by 7th of each month in the form of
Demand Draft or Banker's Cheque drawn in favour ofDDO (Cash), DPIJT. In case of
any delay in payment of monthly instalment, a penalty of Rs. 1, 000/- per day plus
penal interest @ 2% per month on the due monthly instalment, will be charged from
the contractor. Penalty and penal interest will be calculated on daily basis. The
contract can be cancelled for any delay. Contract can also be cancelled if services
provided by firm/contractor are not found satisfactory. Department's decision in this
regard will be final In that case performance security will be forfeited and stock
seized.
6.

FlNANCIAL BID:

The details ofdocuments/contents to be submitted with financial bid on line:a. The bidder is required to quote the consolidated rate for lifting of tom bit/waste
paper etc. from Udyog Bhawan.
b. The rate must be written in figure as well as in words. Erasing and overwriting in
the rates quoted will make the tender void. All alteration in the rates should be
signed in ink otherwise the quotation/tender will not be considered.
c. The firm should not quote any fake price/unrealistic price rate for lifting oftom
bit/waste paper etc. from Udyog Bhawan. If any fake price/unrealistic price is
quoted, it shall not be treated as valid quote and shall result in summary dismissal
ofthe financial bid even though the firm is otherwise technically qualified.
d. The tender document must be filled in neatly and clearly. Incomplete or
conditional tenders will not be entertained.

<!-- page 8 -->

-8-

e. Complementary service by the firm is not acceptable. The finn must quote a
reasonable amount as per details of work/job to be provided as indicated in the
financial bid.
7. Inspection of Premises
The interested agencies/firms can inspect the office premises at any time between
11 :00 A.M. to 3:00 P.M. on any working day from 06-03-2023 (Monday) to 16-032023 (Thursday) to assess the job. For the purpose, Shri Rajender Prasad, Section
Officer, SEO Section, DPllT may be contacted on Telephone No. 2306-3448 during
office hours on any working day from the date of publishing of e-tender till 16-032023 up to 3.00 P.M. After inspecting the premises and going by the terms and
conditions mentioned in the tender documents, the interested bidders should submit
the bids online.
Note: All the supporting documents should be scanned and Uploaded with the
bid documents.

�&�
Nl�lfh

( Ram
)
Under Secretary to the Government of India.
Tel. No. 23038894

'.L��}

<!-- page 9 -->

..

-9ANNEXURE-II
PROFORMA FOR TECHNICAL BID

8.
St.

No.

Item Head

To be Filled by the Agency/firm

I. Name ofAgency/firm

2. �ull address ofReg. Office
Telephone No.
Fax No.
E-Mail Address.

3. Details ofEMD

D.D.No.

Date
(Tenderers who are registered withAmount
NSJC/MSME
authorities
for
endered service/item are exemptedName of the Bank
from payment of EMD on Branch
oroduction of attested copy 01
!certificate issued by NSIC/MSME).
(upload scanned copy alongwith the (EMD in original to be submitted in Room No. 28,
Udyog Bhawan, New Delhi)
bid)

4. PAN ofthe Agency/Finn
5. OST

Registration
Agency/Firm

No.

Upload scanned self attested copy
of thiUpload scanned self attested copy

6. Selfdeclaration by the firm that it isUpload scanned copy
not blacklisted.

Signature of authorized person.
Name:
Seal:
New Delhi:
Dated:

<!-- page 10 -->

-I 0Annexure-ill

Proforma For Financial Bid
Rate Quoted for:
Lifting of tom bits / waste paper etc. from Udyog Bhawan, New Delhi.
SI. No. Service Provided for :
I.

Consolidated Rate Quoted by the
firm/bidder (Annual) ( In Rs.)

Annual Rate Contract for lifting of tom
bits/waste paper etc. from Udyog Bhawan
for a period of one year from the date o,
award of contract.

Total:

Note: Over writing or cutting on rates quoted will be not be accepted and liable fo1
�ancellation of tender.

Signature of authorized person.

New Delhi:
Dated

Name:
Seal:
