---
doc_id: "1c367aeadfff47fe"
source_url: "https://powermin.gov.in/static/uploads/2025/07/4bc7496189c49e7c4e268050d95497c4.pdf"
ministry: "Power"
title: "Clarification on Orders related to Renewable Purchase Obligation"
date: "2019-10-07"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9d01cfae8a43f79e"
---

<!-- page 1 -->

No. 30/04/2018-R&R
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg,
New Delhi, 1° October, 2019
To
1. Chairperson, CEA, Sewa Bhawan, R.K. Puram, New Delhi.
2. Secretary (Energy/Power), All State Govts/UTs.
3. Secretary, CERC/FOR, Chanderlok Building, Janpath, New Delhi
4, Secretary, All SERCs
5. CMD, All CPSUs under the administrative control of Ministry of Power.
6. President, FICCI, Tansen Marg, New Delhi.
7. President, ASSOCHAM, New Delhi
8. Indian Captive Power Producers Association
9 DG, APP, New Delhi.
Subject: Clarification on Orders related to Renewable Purchase Obligation.
Sir,
| am directed to refer to the Ministry of Power's Order of even number dated 22" July, 2016 and
14th June, 2018 regarding long term growth trajectory of Renewable Purchase Obligation (RPO) for
Solar and Non-solar for the period 2016-19 and 2019-22 respectively.
2. A clarification was issued by Ministry of Power vide letter dated 1“ February, 2019 regarding
capping of RPO for Captive Power Plants (CPP) (copy enclosed).
3. Based on the concern raised by various stakeholders and after due consultation with MNRE,
CEA and CERC itis further clarified that:

i) | ForCPPs commissioned before 1.04.2016, RPO should be at the level as mandated by the
appropriate Commission for the year 2015-16. For CPPs commissioned from 1.04.2016
onwards, the RPO level as mandated by the appropriate Commission or Ministry of Power,
whichever is higher, for the year of commissioning of the CPP shall be applicable.

ii) In case of any augmentation in the capacity, the RPO for augmented capacity shall be the RPO
applicable for the year in which the CPP has been augmented.

iii) In case, for meeting the RPO obligation, CPP has surplus power than its consumption
requirement, such a CPP may sell its surplus power to the DISCOMs under the prevailing
arrangements or in the power exchange.

4, This issues with the approval of Hon'ble MoS(I/C) for Power and NRE.
Yours faithfully,
Encl: As above BREA
(D. Chattopadhyay)
Under Secretary to the Govt. of India
Tel: 2373 0265
Copy to: Shri P.C. Maithani, Adviser, MNRE, New Delhi.

<!-- page 2 -->

No. 30/04/2018-R&R
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg,
New Delhi, 1° February, 2019
To
1 Chairperson, CEA, Sewa Bhawan, R.K. Puram, New Delhi.
2. Secretary (Energy/Power), All State Govts/UTs.
3 Secretary, CERC/FOR, Chanderlok Building, Janpath, New Delhi.
4 Secretary, All SERCs
5. CMD, All CPSUs under the administrative control of Ministry of Power.
5. President, FICCI, Tansen Marg, New Delhi
6. President, ASSOCHAM, New Delhi
7 Indian Captive Power Producers Association
8. DG, APP, New Delhi
Subject: Clarification on Orders related to Renewable Purchase Obligation .
Sir,
| am directed to refer to the Ministry of Power's Order of even number dated 22"¢ July,
2016 and 14th June, 2018 regarding long term growth trajectory of Renewable Purchase
Obligation (RPO) for Solar and Non-solar for the period 2016-19 and 2019-22 respectively.
2: The request of various stakeholders regarding capping of RPO for Captive Power
Plants (CPP) has been examined in consultation with Ministry of New and Renewable Energy
and it is clarified that RPO of the CPP may be pegged at the RPO level applicable in the year
in which the CPP was commissioned. As and when the company adds to the capacity of the
CPP, it will have to provide for additional RPO as obligated in the year in which new capacity
is commissioned. There should not be an increase in RPO of CPP without any additional
fossil fuel capacity being added.
3. This issues with the approval of Hon'ble MoS(I/C) for Power and NRE.
Yours faithfully,
DRC. |
(D. Chattopadhyay) |
Under Secretary to the Govt. of India
Tel: 2373 0265
Copy to: Shri P.C. Maithani, Adviser, MNRE, New Delhi. |
