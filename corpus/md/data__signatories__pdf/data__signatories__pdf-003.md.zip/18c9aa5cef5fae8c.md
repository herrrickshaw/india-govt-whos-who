---
doc_id: "18c9aa5cef5fae8c"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/14895e8635d46efcd3d4e1d0006adc95.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 10.02.2025: Extension of terms of Counsels appearing in the Order dated 22.02.2022 for various Courts in Hyderabad, Telangana"
date: "2025-02-10"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a22d5e093e211b65"
---

<!-- page 1 -->

<!-- page 2 -->

F. No. J-1 1 01 7/412022-Judicial
Government of lndia
Ministry of Law & Justice
Department of Legal Affairs
(Judicial
_Section)

Shastri Bhawan, New Delhi
Daled 22^d February, 2022

ORDER

The President is pleased to engage following Advocates for conducting
Central Government litigations (except taxation matters) before the High Court for
the State of Telangana at Hyderabad, the Central Administrative Tribunal Hyderabad
Bench, the Armed Forces Tribunal (Circuit Bench) at Hyderabad and the National
Company Law Tribunal at Hyderabad, as shown in the Lists 'A', 'B', 'C' & 'D' below,
for a period of three years with effect from the date of this order or until further
orders, whichever is earlier:

List'A'
HIGH COURT FOR THE STATE OF TELANGANA
st.

Name of Advocate Contact details

No.

(S/Shri)

Enrollment No.

Senior Panel Counsel
1

Bommineni
Narayana Reddy

vtjav

H. No. 2-2-25lPl4lA, Durgabhai
Deshmukh Colony, Bagh Amberpet,
Hyderabad-500013
Mob: 9848039951
Tel: 040-27425867
Email: bnreddy45@gmail.com
1-5-11771301, Royal
Residence Apartments, Near
Mahalakshmi Theater, Kothapet,
Hyderabad-60
Mob: 9246185049
Email: manikondaadv@gmail.com
H. No. 18-45/3, MES Colony, PO
Tirmulgherry, Secunderabad-50001 5
Mob: 9246185049
Sowdamini
Apartments, Near Ganga Hospital,
Chaitanyapuri, Hyderabad-500060
Mob: 9849070620
Email: vasumadiraju2l @gmail.com
Plot # 354A, MLA Colony, Road

D. No.

2

Manikonda
Kumar

J

Karoor Mohan

4

M. Srinivasa rao Flat No. 508,
(Vasu)

E

A. Kranti Kumar
Reddy

6

K. V. Rama Rao

Number 12, Banjara Hills,
Hyderabad-500034
Mob: 9989500567
Email: akranthireddy@gmail.com
6-1-65211, Kairtabad, Hyderabad500004Mob: 9848478416

L

AP/506/'1981

495/1989

APi 13/1983

TS/1532/1991

TS/873/2003

A.Pt1652t2001

Fr2
<\I
'--v>

<!-- page 3 -->

7

Flat No. 305, Kala Sannidhi
Colony, R. K. Puram Kothapet,

Sunkari Janardhan

TS,t238012004

Apartments, Road No. 10, Vasavi

Goud

Saroor Nagar, Hyderabad
Mob: 9848535626, 9059098138
Email: sunkari3l 05@gmail.com
8

Flat No. 1008, Jubilee Ball Park
Apartments, Road No. 2, Jubilee

L. Pranathi Reddy

APt108t2001

Hills Hyderabad-500045
Mob: 99480331 1 8, 7780612412
Email:
pranathireddyiulakanti@gmail.com
o

Flat No. 109, lst Floor, S. R.

N. Bhujanga Rao

AP/537/1998

Complex, Opp. CCMB, Habsiguda,
Hyderabad
Mob: 939'1055998
Email: advo.nbrao@gmail.com
10.

Mohan Padamati

2-2311

,

Peddamangalaram (V), TS/343/2000

Moinabad (M), Ranga Reddy
Dishict-SO1504

Mob: 9849926400
11.

12

13

Gadi
Kumar

Praveen

Karmanghat, Hyderabad-7'l
Mob: 9849620900
Email: praveengadi't 2@gmail.com
Haveli,
Hyderabad
Mudheerabad,
Secunderabad
Mob: 9885874488
Villa 38, Maple Town Villas, Near
Bundlaguda Jagir,
Rajendranagar Mandal, Hyderabad,
R. R. District-500086
Mob: 9440466775
Email:
bnsarmaadvocate@gmail.com

Petlabuz, Purana
&

Mrs. T. Suhaseni

B.

H. No. 8-5-32133, Srinidhi Colony,

Narasimha

Sharma

Suncity,

A.Pt1219t1999

AP1355t2001

TS,t625t1982

Central Government Counsel
14.

H. No.2-211164126, Sai Satya Plaza,

B. Jithender

Street No. 17, New Nallkunta,

4Pt2330t2008

Hyderabad-44
Mob: 9866663528
Email: iithenderS0@gmail.com
15.

16

Nomula
Reddy

Sridhar

Sanjeev Gillella

H. No. 9-97119. Plot No. 99, AP/1595/1999
Lakshminagar Colony (HUOA),

Boduppal, Hyderabad-92
Mob: 9440490186
Email: nomulasri2@gmail.com
Flat No. 404, Siri Lotus GrandE,
Guttala Begumpet, Kakatiya Hills
Madhapur, Hyderabad-500081
Mob: 9642233311
Email: sanjai.reddy@gmail.com

2

APt2273t2008

,FY
*-

<!-- page 4 -->

17

Flat No. 43082,4th Block, B-Wing, AP/3389/1995

K. L. N.
Raghavendra
Reddy

Janapriya Utopia, Hyderaguda,
Attapur, Hyderabad-500048
Mob: 9440317766,79891 61 731
Email:

18.

Mrs.

Sampada

Gajre

H. No. 4-5-7651766, Near Health
League, Badichowdi, lnside
Vegetable Market, Hyderabad-

APt2114t1999

500027
Mob: 9398 621 260, 98857 321 31
19.

V. Ramesh Reddy

20

Venkateshwarlu
Gummadavelly

21

Ravinder
Ananthula

22

K. Arvind Kumar
Kata

I,

23

P. Devender

24.

Ms. Sarala Annadi

25.

N. Vishnu Murthy

26.

Mrs.

Ganta

Rukmini

27

AP/579/1998
H. No. 3-4-631191232,
Sreeramanapuram, Ramanthapur,
Uppal (Post), Hyderabad-500039
Mob:9849032540
Tel: 040-27036187
Flat No. 406, Sumadhura Eligance APt2104t1999
Apartments, S.B.H.C Colony,
Saidabad, Hyderabad-059
Mob: 9948066377
Email: gvenkatadv@qmail. com
H. No. 2-1-40012, Street No. 3, AP/596/1998
Nallakunta, Hyderabad-44
Mob:9440335709
Email:
ravinderananthula@gmail. com
H. No. 14-2681D, Sri Santhoshi T5t2324t2005
Dayaswarupa Nilayam, lst Floor,
Road No.
New Maruthi Nagar
(East), Kothapet, Hyderabad-500060
Mob:9989684313
Email: aravindkata@gmail.com
H. No. 1-8-111N1, Ravindranagar TS/2409/2005
Colony, Habsiguda, Hyderabad
Mob:9346455593
Flat No. 114, Saverign Shelter APt2384t1993
Apartments, Beside Ganga Jamuna
Hotel, Lakadikapool, Hyderabad500004
Mob: 9490683352
Tel: 040-24144554
Email: a.sarala@qmail.com
H. No. 1-8-21512, Venkateshwara AP/634/1989
Street, Rajendra Nagar, Hyderabad500030
Mob: 9866 4407 07, 94407 42623
Email: nvmhl. nedanoori@gmail.com
13-4-56112518, New p.Pt1654t1994
Ganganagar, Jiyaguda, Hyderabad500006
Mob:9246508671
Email: rukminigantaT@gmail.com
# 15-2-372, Siddambazar, Mehboob 4Pt772t2004
Ganj, Hyderabad-12
Mob:9848728605
Email: anjaliaganrualadv@gmail.com

Mrs. AnjaliAgarwal

H. No.

3

k
-,

<!-- page 5 -->

28

M. Harihara Rao

29.

T. Srujan Kumar
Reddy

30.

Mrs. Thakur Roopa
Singh

31.

Mrs. Mani Deepika
Kommineni

Kishore

32

Krishna
Kovvuri

33

Sanjeev Kalvala

34.

Ramavath
Mangulal

H. No. 3-4-46611, Flat No. 101, First

APt644t1982
Residency,
Narayanguda, Hyderabad-500027
Mob: 9440257387
Tel: 040-27 555545
Email: hariharraomangu@gmail.com
H. No. 6-122, Magadha Village, TS/796/2008
Kokapet, Ranga Reddy District,
Hyderabad-500075
Mob:9160001435
Email: srujan35@gmail.com
1-8-7471116, Om Nivas Nallakunta, AP/100/2000
Hyderabad-44
Mob: 9177365747
Email: singh. roopa@rocketmail.com
Flat No. 504, Vasavi Homes, APt117811992
Dilsukhnagar, Hyderabad-500060
Mob:9441015764
Email:
deepikakommineni@gmail.com
16-11-7411C1N42, Opp. Tennis APt5787t1999
Moosarambagh,
Dilshuknagar, Hyderabad-36
Mob:9849978199
Email: kishorekovvuri6@gmail. com
H. No. 1-9-278-3-6, Plot No. 117, TS/1617t2011
Adikmet, Lalithanagar, Hyderabad500044
Mob:9505529998
Email: sanjaylawyerhyd@gmail.com

Floor,

Hema

#
Court,

#49-403131N51101, Vinayaka

A.Pt1835t2012

Residency, Padma Nagar Phase ll,

Quthubullapur, Hyderabad,
Telangana
Mob:9912366891

35.

Ms.

Priyanka

Sonkamble

Anand Law Chambers, Flat No. 9,

3'd Floor, Manasa Enclaves

APt197712011

Apartments, Near Sundariah Park,

Bagh Lingampalli, Hyderabad,

Telangana-500020
Mob: 9704079900
Email:
priyalawchambers@g mai l. com
36.

Y.

Jhansi Laxmi

Bai

37

K. Ajay Kumar

H. No. 3-3-8251514, Srinagar Colony,
Near lndian Bank, Hyderabad,
Telangana
Mob: 8886212089
Email : iylaws@gmail. com
16-2-752121150, Triveninagar
Colony, Gaddiannaram, Hyderabad60
Mob: 9959796666
Email: ajayreddy3l 1 @gmail.com
4

APt1322t2008

APt218111999

s-.

<!-- page 6 -->

2a

Thodupunuri Arjun
Goud

20

40.

41

42.

43

Plot No. 16, Dandamudi Enclave,

Beside zee Dhaba, Kampally,

Ranga Reddy Diskict-500067
Mob: 9703943507
Email: arjungoudST@gmail.com
Narendar
Naik
20'l , Nirmitee's Landmark, Road No.
D.
12, MLA Colony, Banjara Hills500034, Hyderabad
Mob: 9849387366
Email: d.narendar. naik@gmail.com
H. No. 3-14-16, Srinivasapuram,
Ogirala Ramesh
Ramanthapur, Hyderabad-50001 3
Mob: 9246153206
FCI
Radha #7-35, Mye Villas,
Dadi
Godowns, IDA Mallapur, Nacharam,
Krishna
Hyderabad-76 Mob: 9848060327
Email: radhakrishnalawyer@gmail.com
Aavula Praveen H. No. 16-11-47716/A,/5, Shalivahan
Colony, Dilsukhnagar,
Kumar Yadav
Hyderabad-500036
Mob: 9246571 788, 90001 67891
Flat No. 318, 3'd Floor, Surya
M. Vijayakanth
Splendour Apartments, Block-F,
Nacharam,
Hyderabad Mob:9246573431
Email: viiaylawyerTS@gmail.com
(SP), Phase-ll,
T.
Jashwanth
Vijayanagar Colony, Kuntloor Road,
Kumar
Hayathnagar, RR District - 50,l505
Mob: 94401 13468
Email: jashwanththota@gmail.com
#101 , Plot No. C-6, Haritha Enclave,
Pulimamidi
Chitra Lay-out, Besides R. R. District
Shashidhar Reddy
Court, L. B. Nagar, Hyderabad-74
Mob: 8019812868
Flat No. 101, Lahari Homes, Street
N. Avaneesh
No.
Tarnaka, Secunderabad,
Hyderabad-S000'17
Mob: 9848972564
Email: avaneesh.naraparaju@gmail.com
B
Kavita H. No. 17-1-383/A,/9, Vinay Nagar
Yadav
Colony, Saidabad, Hyderabad,
Telangana-500059
Mob: 984899247 4, 901 44467 24
Email: kavitaya4S@gmail.com
K.V.V. Vedantha G2, Om Sai Krupa Apartments,
Charya
Bhagyalaxmi Nagar, Padmashali
Colony, Kavadiguda, Hyderabad500080 Mob: 9848022749
Email: charyakwv@hotmail.com
V.T. Kalyan
Flat No. Ag 19, Av lnfo Pride,
Kamala Nagar Coloncy, Opp.
Sampoorna
Warangal
Highway, Medipalli500098
Mob: 9833273937
Email: vtkalyan@gmail.com

Opp

Nagar

APt244412010

T5/610/2008

AP/768/1986

AP/766/1999

AP/3610i2001

4Pt3431t2001

Shantigardens,

44

45

46

47

48

49

Plot No. 27

1,

Mrs.

T5t2421t1999

TS/3268/'1999

TS/1553/2015

AP/2568/1999

AP/396/2016

TS/138-A/2016

Hotel,

5

g

<!-- page 7 -->

50

H. No. 17-1-388172, Flat No. 103,

N. Ravi

Lakshmi Nagar, Saidabad,

51

Angothu Nehru

52.

N. Hari Prasad

53.

Annampalli
Gangadhar

54

B. Raghavendra

55

G. Srikanth Goud

56

S. Srinivasa Chary

57

Kuyya Srikrishna

58.

P. Suraj Yadav

59.

Mrs.

Marreddy

Bhagyasri

60.

Jasthi Suresh Babu

Hyderabad, Telangana
Mob: 9703071 000, 984806001 0
Email: ravi40896@gmail.com
#601, Vl Floor, 1-7-7021354, Vindsor
Shankar Mutt,
Plaza,
Nallakunta, Hyderabad-500044
Mob:9014412233
Email: nehrunyayavadi@gmail. com
3-5-9261B,11, Himayath
Nagar, Hyderabad-29, Telangana
Mob: 9394847966, 9885066049
Email:
hariprasadnalumachu@gmail. com
Flat No. 44, 4tn Floor, Sai Jayanthi
Towers, Opp. Srinivasa Theatre, Old
Bazat, Ka ri m nag ar-50500 1
Mob:7386624856
# Plot '. 172, Flat G-1, "Spandana
Apartments", Kalyan Nagar Phase-|,
Hyderabad-500038
Mob: 9849077046
Email : raqhavendrabZl @qmail. com
H. No. 12-1-53, Vijaya Gardens,
Nagole, Bandlaguda, Hyderabad068, Telangana
Mob: 9848457668
Email: gundrati. legal@gmail.com
H. No. 4-2-365, Motisingh Lane,
Sultanbazar, Hyderabad-500095
Mob:996682878
Email: advocate.srini@omail.com
H. No. 2-119, Sainagar Colony,
Chaitanyapuri, Dilsukhnagar,
Hydera bad -957 357 3447,
8328252180
Email: srikrishnaS6T3@gmail. com
H. No. 10-3-94, lst Floor, Shilpa
Apartments, East
Marredpally, Secunderabad-025
Mob: 9395555044, 8688868783
Email: surajyadav.adv@gmail.com
13-14-1141103F,
Manikantaclassics,
Kodandaramnagar, P&T Colony,
Dilsukhnagar, Hyderabad-500060
Mob: 9391 130085, 8801164274
Email: m. bhagyasri9@gmail.com

Near

H. No.

Sadan
H.

No.

Flat No. G-01, Rivera Gated

Community

APt958t2015

APt110512015

AP/256/1996

APt2153t2000

APt114711995

TS/851/2004

T5t732t1999

TS/537/2000

T5/2390/2015

T5/4062/1999

TS/790/1988

Apartments,
Manchirevula, K. V. Ranga Reddy
District, Hyderabad-500089
Mob: 9490933273
Email : iasthib@yahoo.co. in
6

P

<!-- page 8 -->

61.

Ms.

Sribala

Kamarsu

Flat No. 102, Block N. A-38,

APt224712016

Samskruthi Township, Pocharam

Village, Ghatkesar Mandal,
Medchal-Malkajgiri District Ranga
Reddy, Hyderabad-Telangana500088
Mob: 901 3749604, 6281688206
Email:
advocate.sribalakamarsu@gmail.com

62

Ms. Baddam Laxmi
Prasuna

63

Chindam
Anjaneyulu

64

Akkaram Sampath
Vasudevan

65

K. Rajesh Reddy

bb.

P. Pallavi

67

Gummalla Bhasker
Reddy

Flat # 502, Shilpi Brindavan, 17-1- AP/3361/1995

383/5, Vinaynagar Colony,

Saidabad, Hyderabad-59
Mob: 9391027413
Email: prasunabl@yahoomail.com
17-1-383151, Surya
103,
Apartments,
Vinaynagar Colony, Saidabad,
Hyderabad-500059
Mob: 9440519520
Email: chindamanianeyulu@qmail.com
#7 -2-1669, Lodha Casa Paradiso,
Utopia C-505, Sanath Nagar,
Hyderabad-50001 8
Mob: 9000911812
Email: vasudevanakkaram@gmail.com
HPS,
4-119,
Ramanthapur, Hyderabad-5000'l 3
Mob: 9989890808
Flat No. 603, H. No. 3-5-1002&1003,
Happy Homes, Himayathnagar,
Hyderabad-29, Telangana
Mob: 9492206789
Email: pallavipl 7433@gmail.com
H. No. 13-3-690/4/1,
Ranganathnagar, Jiyaguda,
Hyderabad-500006
Mob: 7034647896
Email:

H. No.

Flat No.

H. No.

Opp

TS/440l1995

4P1767t2009

T5t457t2001

APt1430t2014

4Pt1287t2014

gummallabhaskerreddy@gmail.com

68

69.

M. Mohan Kumar

H. No.8-2-272131, Shoukat Nagar,

4Pt1869t2011

Anjani Lakshmi

Hyderabad-500034
Mob: 9985558081
Email: mohan.maredu@gmail.com
SNC 211, Street No.7, Santoshi Ma
Nagar Colony, Rama Krishna Puram
PO, Secunderabad-500056
Mob:9492842185

APt1782t2008

#403 & 404, Legend Commercial
Complex, Above Keshav Medicals,

APt1681t2007

Bharadwajini

70

P. Shashi Kiran

Road No. 2, Baryara Hills,

Barkatpura, Hyderabad, Telangana
Mob: 9848925467

7

g

<!-- page 9 -->

List 'B'
Gentral Adm inistrative Tribunal. Hvde
st.
No

Name of Advocate

Bench
Enrollment No.

Contact details

(S/Shri)

Senior Gentral Government Standing Counsel
1

Mrs.
B. Gayatri Varma

H. No. H-5-101, HIG-5, Chitrapuri
Hills, Kazaguda, Manikonda,

APt16411997

Hyderabad-5001 04

Mob: 9963706616
Email: ackka.gayatri@gmail.com

Senior Panel Counsel
2

Vinod Kumar Vasi H. No. 6-3-609/1/9/1, Anandnagar AP/ 1358/1989
Reddy
Colony, Khairatabad, Hyderabad500004
Mob: 9866655500
Email:
vinodkumarvasireddy@gmail.com

3

4

Mrs. Kompally
Rajitha

Gandyadapu
Rajesham

T.

Hanumantha

Reddy

6

R. V. Mallikarjuna
Rao

7

Atmakuri
Radhakrishna

H. No. A-33, Flat No. 103, AP/1810/1991
Balkrishan Nilayam, DD Colony,

Bagh

Amberpet, Hyderabad500013
Mob: 9848243514
Tel: 040-27425751
Email: rajithagk66@gmail.com
Plot No.21lA, Road No. 11, APt171011999
Kakateeya
Madhapur,
Hyderabad-500081
Mob: 9849796008
Email: g.raieshamT4@gmail.com
Flat No. 4-206, 2nd Floor, H. No. 6- T5/6'13/1985
1-72, Mahalakshmi Meadows,
Lakdikapool, Hyderabad-500004
Mob: 9966226324
Tel: 040-23245868
Email: threddy23@gmail.com
H. No. 58, Om Nagar Colony, Post AP/753/1983
Office Golconda, Opp. Crystal
House,
Rajendranagar,
Road,
Hyderabad-500008
Mob: 9849299538
Email: rvm.legal@gmail.com
Annapurna Shopping T5t217t1991
Dilsukhnagar,
Hyderabad-60, Telangana
Mob: 9848086058
Tel: 040-24151366
Email:

Hills,

Garden, Langer
Ring
G-17,
Complex,

atmakuriradhakrishna@yahoo.co. in

8

g

<!-- page 10 -->

8

Maddirala Brahma
Reddi

#107, Renuka Shakti Apartments,
3-5-797, King Koti Road, Opp.

Bharatiya Vidya Bhavan,
Basheerbagh, Hyderbad-29,

^.Pt207t1982

Telangana

I

Nareddy
Parameswara
Reddy

Mob: 9440518266 Tel: 04023242559
Email: mbradvocate@gmail.com
13-6-45812, Gayatri Nagar, Shiv
Bagh, Hyderabad-500006
Mob: 9440057335

4Pt396t1982

Email:

10.

B. Madhusudhan
Reddy

11

Ale

Hyderabad-500013

Nageshwar

Rao

12.

Bascle Rajeshwar
Rao

13.

Paravastu Krishna

14

A. Surender Reddy

15

M. Mohan Rao

16.

Mrs. Megha Rani
Agarwal

17.

parameswarareddy. advocate@gma
il.com
H. No. 3-9-94, S.V. Residency, APt2015t2002
Sharadanagar, Ramanthpur,
Mob:
90003'19345
Email: bmsradvocate@gmail.com
1"t Floor, AP/l311/1988
3-5-107,
Hyderabad,
Narayanaguda,
Telangana-500029
Mob: 9393300900
H. No. 15-6-328, Kolsawadi, Begum AP/949/1999
Bazar, Behind Osmania Hospital,
Hyderabad-50001 2
Mob: 98491 2888 4, 949187 1299
Email: brraoadvocatel @gmail.com
#201, TNR VAishnavi, H. No. 11-4- APt48511997
64912&3, Lakdikapul, Hyderabad500004
Telangana
Mob: 9849504030
Email:
paravastuadvocate@gmail. com
Flat No. 1/303, Old Malhar, Sahara AP/529/1980
States, Mansoorabad, Hyderabad500068
Mob:9246877270
Email: surenderreddya@gmail.com
No. 16-11-161L13, Behind RTA AP/994/1985
Office, Beside West Prashanth
Nagar Park, Moosa-Rambagh,
Malakpet, Hyderabad-500036
Mob: 93930088'19
H. No. 21-7-91, Brij Kunj, Ghansi 4Pt791t2004
Bazar, Hyderabad-500002
Mob: 924655001'1, 9885401 908
Email: advmegha@gmail.com

M. Venkata Swamy

H. No.

H. No. 3-10-41D, First Floor,

APt2787t2001

Gokhale Nagar, B/S B.P. Pump,
Ramanthapur, Hyderabad-1 3
Mob: 9000555928, 852208217
Email: venkatswamy45@gmail.com

I

9

B

<!-- page 11 -->

18.

K. Rajeeva Reddy

Flat No. 204, MJK Apartments,

Barkatpura, Hyderabad-27,

APt10711992

Telangana
Mob: 9848655663
Tel: 040-27568800
19.

V. Venumadhva
Swamy

20.

A. Ram Mohan

21.

Bokka Siva Sankar

22

D. Satyaveer

23.

Tingrikar
Vaidyanath

24

Devulapally Laxmi
Narayana Rao

H. No. 2-7-1202, Kanaka Durga
Colony, Subedari, Hanamkonda,
Warangal, Telangana
Mob:7702374337
Email:venulawchambers.v@gmail.com
ft. Nlo t e-O-t OO2, 2nd Floor, Mathru
Laldarwaza,
Hyderabad-500053
Mob: 9704111463
Tel: 040-40032637
Email: adityalegal3@gmail.com
#16-11-741|C|N42, Opp. Tennis
Court, Moosarambagh, Dilsukh
Nagar, Hyderabd-500036
Mob: 9849929481
No. 18-5-865, Laldarwaza,
Hyderabad-s3, Telangana State
Mob: 9000966069
Email: d.satyaveer@gmail.com
H. No. 6-3-1247/361, Raj Nagar,
Raj Bhavan, Khairtabad,
Hyderabad, Telangana State
lvlob: 9848015289
Email: ting rikar0T @g m ail. com
H. No. 2-10l7, Plot No. 51, Sri
Colony,

Sri

Towers,

H.

Opp

Ramanujanagar
Munaganuru, Street No. '10,

AP/5930/1999

APi 1880/'1991

A.Pt623t2002

AP/3't6/2000

4Pt1537t2002

APt164612000

Abdullahpurmet Mandal, Ranga

1F

P. Narayana

26.

Govardhanam
Raghunadh

Reddy District, Telangana
Mob:9347230472
Email: llbdvln@gmail.com
#3-9-3871E1206, SNR Sri Sri Kala
Kuteers, Saraswathi Nagar,
Chintalkunta, Hyderabad-500074,
Telangana State
Mob: 9676064788, 9949495982
Email: narayanap9949@gmail.com
11-12-1071104,
Classica
Apartments, R. K. Puram, Kothapet,
Hyderabad, Telangana State
Mob: 9440895023
Email: q raghunadh9S@gmail. com

Elite

T5t3072t2001

4Pt2108t2000

Additional Central Government Standing Counsel
27.

Bharathi
Kalavagunta

Flat No. 223, 2nd Floor, Alekhya Villa,
Colony,
Punjagutta
Punjagutta-500082
Mob: 9346225558
Email:
bharathikalavagunta@gmail.com

Officers

10

APt2623t2007

9_

<!-- page 12 -->

28

M. Swarna Methu

H. No. 8-11-3, Flat No. G3, rS/1404t2011
Venkateshwara, L. B. Nagar,
Hyderabad-500074
Mob: 9440367862
Email: colswarna@gmail.com

zv

A. Vijaya Bhaskar Flat No. 102, 1"t Floor, Emerald
Babu
Arcade, 2-2-11301'19-D, Prasanth

30

Ankusham
Sreenivas

31

Kondapally
Krishnakanth

32

P. Naveen Kumar

Ravi

N. Naga Prasanthi

Nagar, New Nallakunta, Hyderabad,
Telangana
Mob: 939114959
H. No. 2-3-64lDl2lN1, Amberpet,
Hyderabad, Telangana
Mob: 92900'18925
Email: ankushamvasu@qmail.com
3-1 15, Plot No. 3, Opp. Sai Function
Hall, Shivapuri Colony, L. B. Nagar,
Hyderabad, Telangana
Mob: 9'133901092
Email: krishnakanth20l4@gmail.com

16-5-313, Dabeerpura Daruvaza,
Hyderabad, Telangana-500024
Mob: 8790754753
No. 2-20-132, Chilkanagar,
Uppal, Hyderabad-500039
Mob: 9948726597

TSt1222t2009

rst2110t2006

TSt1632t2014

AP/1659/2015

H.

Email:nagaprasanthi@yahoomail.com

34

Padma
Lakkaraju

Rao

151H, Flat # 2501, LANCO Hills,
Manikonda, Hyderabad-500089
Mob: 9052407111
Email: prosecutorrao@gmail.com

AP/83i2008

List'C'
ARMED FORCES TRIBUNAL, CIRCUIT BENCH AT HYD ERABAD
CENTRAL GOVERNMENT COUNSEL
sr.

Name of Advocate

No.

(S/Shri)
Pitta
Chandrasekhar
Reddy

1

2

A. Alavender Goud

Contact details

Enrollment No.

H. No. 2-5, lnjapur Village,

APt109711987

Hayathnagar, Mandal, Ranga
Reddy District-70, Telangana
Mob: 9490748389

Plot No. 59, Syndicate Bank

Colony, West Marredpally,

AP/190/2000

Securnderabad-26, Telangana
Mob: 9848049216
Email: aagoud@gmail.com
3

4

S. Ajay Kumar

P. Devender

H. No. 1-4-945 to 950, Flat No.
354, Block-V, Jana Priya Abodes,
Gandhi Nagar, Hyderabad-08
Mob: 9290438'16'l
H. No. 1-8-1 'llA/1 , Ravindranagar
Colony, Habsiguda, Hyderabad,
Telangana Mob:9346455593
77

APnMt2000

TS/2409/2005

'h

+-

<!-- page 13 -->

List'D'
NATIONAL COMPANY LAW TRIBUNAL, HYDERABAD
CENTRAL GOVERNMENT COUNSEL
st.
No
1

2

Name of Advocate Contact details

Enrollment No.

(S/Shri)
M. Ramesh Reddy

APt294t1993

K. Harish Reddy

205, Arundathi Apa(ments,

chaitanyapuri, Hyderabad-500060
Mob: 9848440574, f el. 040-24220416
H. No. 3-"12-74116, Plot No. 16, AP/1896/1993
Behind Surekha Motors, GSI Post,

Mansoorabad, L.
3

4

Peetam
Pradeepkumar

T. Srujan Kumar
Reddy

q

B. Jithender

B.

Nagar,
Hyderabad-500068
Mob: 9849296949, 9963973888
Plot No. 29, Uday Nagar Colony, A.Pt2854t2003
Hyderabad,
Telangana Mob:9848174787
Email: peetampradeepkumar@gmail.com
H. No. 6-122, Magadha Village, TS/796/2008
Kokapet, Ranga Reddy District,
Hyderabad-500075
Mob: 9160001435
Email: srujan35@gmail.com
H. No. 2-2-1164126, Sai Satya 4Pt2330t2008
New
Plaza, Street
Hyderabd-44,
Telangana Mob: 9866663528
Email: iithenderS0@gmail.com
H. No. 1-16, Flat No. 401, Ravi APt1446t2011
Te,ja Harika Residency, Prabath
Nagar, Chaitanyapuri, Hyderabad500060
Mob: 92907'1 2633, 9 154659666
Tel: 040-24149666
Kundanika APt1157t2014
Residency, H. No. 2-2-3l3/tu'1 & 33/A, C-66, DD Colony, Hyderabad500013 Mob: 9949999600
Email: pallavi0003@gmail.com
1-5-23713, New Maruthi Nagar, APt234t2014
Kothapet, Hyderabad-500060
Mob: 9963101017
Email: ramanadvl 806@9mail.com
3-4-366/1, Hema 4Pt1621t2014

Karmanghat,

No. 17,

Nallakunta,

6

[\/rs. D

Shobha

Rani

7.

Ms. Pallavi Daggu

K. V. Raman

o

M. S.

Achyuth

Bharthwaj

10

Bom mineni
Vivekananda

Flat No. 402,

H. No.

Residency, Flat No.

101 ,

Narayanguda, YMCA, Hyderabad500027 Mob: 9440177798
Email: m.saiachyuth@qmail.com
H. No. 2-2-25lPl4lA, Durgabai
Deshmukh Colony, Bagh
Amberpet, Hyderabad-50001 3
Mob: 9848039951
ret 040-27425867
Email: vivenda2T@omail.com
L2

T5t922t2016

<!-- page 14 -->

11.

Mrs. Sushma
Nellutla

12

Ravindra Ankam

Plot No. 16-1 1-405/98, SBI Officers
Moosarambagh,
Hyderabad-500036
Mob: 9393283939
Email: sushmanellutla@gmail.com
12-2-417 1N15, Jayanagar Colony,
Mehidipatnam, Hyderabad-500028
Mob: 9440683736, 901 0777509
ret 040-23534444

Colony,

AP/1958/2016

APi 1933/1995

Email : ravindra_ankam@yahoo.com

3.

The engagement and professional fee of the aforesaid advocate will be
governed by the terms and conditions contained in this Department's OM No.
26(1)/99-Judl. dated 24.09.1999 read with OM No.26(1)/2014lJudl. dated
.10.2015 & instructions issued subsequently through OMs. The aforesaid OMs are
available on the website of this Department i.e. www.lesalaffairs.qov.in in the tab
'Judicial Section' under heading'Circulars pertaining to litigations'.
O'1

4.

Hindi version of this order will follow
t

H

(R. K. Srivastava)
Joint Secretary & Legal Adviser
Copy to:1.

PS to ML&J/PS to MSLJ/PS to Law Secretary/Ps to Legislative Secretary/All Additional Secretaries/PS

0

to all JS&LA in the Main Sectt.
Shri T. Surya Karan Reddy, Additional Solicitor General of lndia (Souhem Zone).
Shri Namavarapu Rajeshwar Rao, Asst. SGl, High Court for the state of Telangana at Hyderabad.
The Registrar, High Court for the state of Telangana at Hyderabad.
The Registrar, Central Administrative Tribunal, Hyderabad Bench at Hyderabad.
The Registrar, Armed Forces Tribunal (Circuit Bench) at Hyderabad.

7

The Registrar, National Company Law Tribunal at Hyderabad.

2

J
4
E

The Cash (LA) Section w.r.t. payment of retainership fee to Mrs. B. Gayatri Varma, Sr. CGSC w.e.f.
the date of this order.
The Pay & Accounts Office, Department of Legal Affairs, New Delhi.
10. One copy of this order is uploaded on website of this Department i.e. www,leoalaffairs.oov,in under tab
'Judicial Section' in the link 'List of empanelled Advocates" for the information of all concemed.

8

I

11. Office/spare copies

/..9

(1. C. Dabaria)
(Judicial
Section)
Assistant Legal Adviser

Tel. 011-23384945
Email: judicial{la@nic.in

13
