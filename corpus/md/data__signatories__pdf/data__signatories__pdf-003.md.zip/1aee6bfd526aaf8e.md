---
doc_id: "1aee6bfd526aaf8e"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/456f37fd419cb044df24f941e3020acb.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RTI - Departments of Health and Family Welfare - Immunization - Operational Guidelines - AEFI Reports - COVID-19 Vaccination - Causality assessment of 385 reported Serious CASES of COVID.19, APPROVED BY NATIONAL AEFI COMMITTEE"
date: "2022-09-12"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dd1e025ef965fccb"
---

<!-- page 1 -->

Z.16025/02/2018-IMM-Part(1)
Government of India
Ministry of Health & Family Welfare
Immunization Division
Nirman Bhawan, New Delhi
Date: 12th September 2022
Causality assessment results of 385 reported Serious Adverse Events Following
Immunization (AEFI) cases following COVID-19 vaccination approved by National AEFI
Committee on 17th- 18th August 2022.
The Immunization Division, MoHFW has taken several steps to strengthen the national
AEFI surveillance system for COVID-19 vaccinations. Considering the importance and critical
nature of the task, steps were taken to include medical specialists, cardiologists, neurologists,
pulmonary medicine specialists, and obstetrician-gynaecologist as members of the causality
assessment sub-committee at the national level. A Special Group has been framed to conduct a
causality assessment of AEFIs following COVID-19 vaccination. The results of the causality
assessment done by this Special Group is discussed in the national AEFI committee meeting
for final approval.
The results of the causality assessment for 385 cases completed on 17th- 18th August
2022 after a thorough review, deliberation, and approval by the National AEFI Committee is
given in the annexure (anonymized line list of the causality assessment done by the National
AEFI Committee).
85 out of 385 cases for which Causality assessment has been done were found to have a
consistent causal association to immunization. Of these 85 cases, 44 cases were vaccine
product-related reaction including 04 deaths, 05 cases were immunization error related
reaction including 02 deaths, and 36 cases were anxiety-related reaction. 199 cases have an
inconsistent causal association to immunization (coincidental - not linked to vaccination),
including 111 death cases. There are 65 cases in the indeterminate category including 11
death cases. A total of 36 cases were in the unclassifiable category (all death cases)
Vaccine product-related reactions are expected reactions that can be attributed to
vaccination based on current scientific evidence. Examples of such reactions are allergic
reactions and anaphylaxis, etc.
Indeterminate reactions are reactions that have occurred soon after vaccination but
there is no definitive evidence in current literature or clinical trial data that this event could
have been caused due to the vaccine. Further observations, analysis, and studies are required.
Unclassifiable events are events that have been investigated but there is not enough
evidence for assigning a diagnosis due to missing crucial information. When this relevant
information becomes available, the case may be reconsidered for causality assessment.
Coincidental events are events that are reported following immunization but for which a
clear cause other than vaccination is found on investigation.
Overall, the benefits of vaccination are overwhelmingly greater than the small risk of
harm. However, as a measure of utmost precaution, all emerging signals of harm are being
constantly tracked and reviewed periodically.
