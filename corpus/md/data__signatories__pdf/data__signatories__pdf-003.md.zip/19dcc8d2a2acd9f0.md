---
doc_id: "19dcc8d2a2acd9f0"
source_url: "https://www.dahd.gov.in/static/uploads/2025/07/673c947f7591c5e5adceda8e15d8ad92.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "E-tendering for purchase of 200 MT White Butter by DMS"
date: "2022-06-16"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a0aa725cfd044aad"
---

<!-- page 1 -->

* है Speed-post/ e-mail
SHORT E-TENDER ENQUIRY a
है No. A-12003/01/2022-23/Proc/DMS/WB/02
Government of India

Delhi Milk Scheme
West Patel Nagar
New Delhi-110008

Date: 15.06:2022

= All State Dairy Federations, NDDB/ Mother Dairy and Government sources only.

Subject: ‘E’ tendering for purchase of 200 MT White Butter by Delhi Milk Scheme.

Delhi Milk Scheme is Central Government Organization under Department of Animal
Husbandry & Dairying, Ministry of Fisheries, Animal Husbandry & Dairying, Gol engaged in
supplying high quality milk and milk products to the citizens of National Capital and intends to
purchase the following material from State Dairy Federations, NDDB, Mother Dairy & Govt.
5211-3० ५ की या Fee he Se ee ee हि. नीमीय बह 114 प्री
S.No. Description of Material Quantity required
4. White Butter manufactured not before 200 MT

February, 2022 & as per FSSAI standards made

from mixed milk.

2. On Line Rates/ Offer : Your online rates / offer indicating the quantity of White Butter
for supply to this office, price payable per kg (for 82% Fat on pro — rata basis) F.O.R.
DMS Godown (including taxes, transportation, insurance, loading/unloading etc) along
with delivery schedule should be uploaded well before the closing date of e-tender.
Manual offer shall not be accepted.

3. Offer Validity : Your offer / rate should be valid upto 30.06.2022.

4. Product Quality : White Butter should be as per FSSAI Standards made from mixed
milk and manufactured not before February,2022. The white butter consignment
dispatched to DMS must ensure following quality norms:

(a) Consignment of white butter at the time of sampling of white butter at DMS should be
in the order of standards laid down under FSSAI. The products should preferably be
brought to DMS under refrigerated condition maintaining cold chain throughout the
transportation period. This manner of transportation should enable butter to be found
at Sub-Zero temperature at least, at the time of sampling at DMS.

(b) Butter cartons stained with butter will not be accepted. i

(c) As regards testing for details analysis of above White Butter DMS may send sample
to notified third party laboratory as per DMS order no. 3-2/2020-SPH dated
15.01.2021, In such events test results shall be intimated to the successful bidders.
Successful bidder may opt to witness the analysis procedure, : |

Pee te laspection: Pre delivery inspection may be carried out by DMS Quality Control Team

caiiad ou व 001 as per DMS requirements. However, final inspection shall be

1... fiaal In cise of rajection, = heme and/ or notified third party laboratory which shall be considered
charge, | Nn, party is required to replace the rejected consignment without any extra
contd-2/...

<!-- page 2 -->

‘ -2- 7
6. Quantity ; DMS shall have the option to increase/ decrease the above quantity upto
50% at the same rates, terms & conditions. However, it is compulsory for bidders to
offer the complete quantity of White Butter as per tendered quantity, failing which, their
bid shall be treated unresponsive and will be rejected summarily. Quantity in each

batch manufactured should not less than 2 MT. ड़
; ‘7, Delivery Perlod : Delhi Milk Scheme being Central Govt. Organization is supplying milk
'& milk products to the Parliament of India, Hospitals, Defence Installation, institutions
etc. Hence Delivery Period is the essence of the contract / purchase order which must

to be adhered to.

8. Tender Opening : Tender Enquiry containing terms & conditions can be downloaded
from Central Public Procurement — Portal website i.e. eprocure.gov.in/eprocure/app
from 15.06.2022 to 22.06.2022 (upto 14:30 PM). Your online tender offer alongwith
terms & condition shall be accepted upto 14:30 PM till 22.06.2022 and shall be opened
on 23.06.2022 at 14:30 PM. No manual rates offer shall be accepted. Scan copy of your
Tender Offer alongwith terms & conditions (.pdf) as per this tender and financial bid (.xls)
may be uploaded/ placed appropriately on aforesaid CPP-Portal before due date & time.
You may also visit DAHD website i.e. www.dahd.nic.in

न Kindly acknowledge the receipt.
see (Jitendra Kumar)
Manager (Proc)
Telephone/Fax: 011-20838134
* Copy to:
1. I/c EDP may ensure publication of above said notice on DAHD/ DMS web : my
: site.http://dahd.nic.in है

2. Mgr. (Processing) है

3. Dy. Mgr (QCL)

4, General Section

- 5. Hindi section for Hindi version
Copy forwarded to General Manager.
| ; contd-3/...

<!-- page 3 -->

हि; मा
1, The Managing Director 13. The Managing Director,M/s.Parag Dairy |
Rajasthan Co-operative Dairy Federation Ltd. Saras Noida, B-219, Phase-II,
Sankul J.L.N. Marg, Jaipur-302017 Noida-201305(UP,
2. The Managing Director, 14. General Manager (Procurement),
The Punjab State Co-operative Milk Producers’ Mother Dairy Fruit & Vegetable
Federation Ltd., Private Limited,
SCO No.153-155, Sector 34-A Chandigarh-160022 | Mother Dairy, Patparganj,
Delhi- 110 092 |
3. The Managing Director 15. M/s National Dairy Development Board
Haryana Dairy Development Co-operative (NDDB), Anand, Gujarat-388001
Federation (HDDCF), Haryana Bay No.21-22,
Sahkarita Bhawan, Sector -2,
Panchkula-132102 (Haryana:
4, The Managing Director, 16. The Managing Director,
The Pradeshik Cooperative Dairy Fed. Ltd., 29, Park | Karnataka Co-operative Milk Producer Fed,
RoadLucknow-226001 (U.P) KMF Complex, Dr. M.H. Marigowda Road,
Bangalore-560029
5. The Managing Director, 17. The Chief Executive Officer,
M.P. State Co-operative Fed.Ltd., Indore Sahakari Dudgh Sangh Maryadit, Indore,
Dugdh Bhawan, Dugdh Marg, (MP), - 453771
Habib Ganj, Bhopal-24 (M.P) |
6. The Managing Director, 18. The Managing Director
Raja Ram Bapu Patil Sahakari Dugdh Sangh Ltd.- | Rajya Sahakari Dudh Mahasangh Maryadit
A-16-19, M.I.D.C.,-Islampur, Tal.-Walwa, Distt. — (MRSDMM), Mahanand Dairy,
Sangli ,Mahrastra- 415409 Western Express highway, Goregaon (East), |
Mumba400065 |
7. The Managing Director 19. The Chief Executive Officer
HLP. State Co-operative Milk Producers Federation Gwalior Sahakari Dugdh Sangh Maryadit |
Ltd Toty, Shimla, Himachal Pradesh-171011 Gola ka Mandir, Gwalior |
Madhya Pradesh- 474 005
8. The Managing Director, 20. The Managing Director |
_| Ludhiana District Co-operative Milk Producers Bhilwara Zila Dugdh Utpadak Sahakari Sangh |
Union Ltd. Ltd, 5,K.M. Ajmer Road, Post Box No. 46,
Verka Milk Plant, Firozepur Road, Bhilwara, Rajasthan- 311001
Ludhiana, Punjab — 141004
9. The Chief Executive Officer 21. The Managing Director
Ujjain Sahakari Dugdh Sangh Maryadit Ajmer Zila Dugdh Utpadak Sahakari Sangh Ltd.,
Mixi Road, Ujjain Opp. HMT Beawar Road, Ajmer,
Madhya Pradesh- 456 010 Rajasthan- 305001
10. The Managing Director 22. The Managing Director |
Tamilnadu Co-operative Milk Producers Federation | Gujarat Co-operative Milk Marketing Federation |
Ltd., Aavin IIlam Ltd., Amul Dairy Road, है
No: 3A, Pasumpon, Muthuramalingam Salai, Anand-388001 (Gujarat)
(Chamiers Road) Nandanam,Chennai-600035
11. The Managing Director 23. The Managing Director
Bihar State Co-operative Milk Producers Federation Office of the Dairy Development Commissioner, |
Dairy Dev. Complex, P.O, Bihar Veterinary College, | Maharashtra State, New Administrative Building, i
Patna (Bihar) - 801505 Abdul Gafar Khan Road, Worli Seaface, Mumbai- |
400018
12, The Managing Director, 24. The Managing Director |
Andhra Pradesh Dairy Development Uttari Rajasthan Sahakari Dugdh Utpadak SAngh |
Cooperative Federation Ltd, Ltd, Bikaner NH-15, Sri Ganganagar Road, '
Lalapet, Hyderabad.500017 Bikaner, Rajasthan-334002 |
।
