---
doc_id: "1b850dcc90b5bedc"
source_url: "https://mohua.gov.in/static/uploads/2025/10/6e4c56f67f4f2c25904e5005b7538b57.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Uploading of vacncy circular on the website of ministry of Housing and urban affairs-reg"
date: "2024-07-30"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "779a889624f39373"
---

<!-- page 1 -->

ee
No. 3(02)/2024-DUAC
Delhi Urban Art Commission
VACANCY CIRCULAR
Applications are invited for filling up of one post of Architectural |

Assistant Level 6 in Pay Matrix (Group B) in the Delhi Urban Art

Commission, a statutory body under Ministry of Housing and Urban Affairs |

| on deputation basis as per following criteria:

1. Pay & Allowances : The selected person shall be entitled to |
his/her basic pay drawn in his/her parent
organization and deputation (duty) |
allowance as determined by the |
Government of India from time to time |
or the basic pay attached to the post of |
Architectural Assistant in DUAC as per
the option of the selected person in
terms of instructions issued by the
Department of Personnel and Training |

| time to time. |
| 2. Eligibility condition : Deputation- Persons holding analogous

| posts in the State/Central Government/ |
| Govt of NCT of Delhi.

3. Period of deputation : Period of deputation including period of
deputation in another ex-cadre post held
immediately preceding this appointment |
in the same or some other organisation
or Department of the Central |
government/State Government _ shall
ordinarily not exceed three years. |

4. Age : Not exceeding 56 Years as on closing |
date of receipt of applications.

The post carries Dearness Allowance, HRA and other benefits like LTC, |
medical reimbursement etc as stipulated in the Delhi Urban Art Commission |

(Employees Terms and Conditions of Service) Regulations as amended from

time to time. The person selected shall be entitled for CGHS facilities in

case he/she is CGHS beneficiary in his/her parent organisation.

i
peer fe ०० |

<!-- page 2 -->

dee
Applications of only such candidates will be considered which are
routed through proper channel and are accompanied with (i) Bio-data (in
quadruplicate) in the proforma as given in Annexure-I, (ii) Cadre Clearance,
(iii) Vigilance Clearance & (iv) copies of APARs/ACRs of last five years
ma by an officer not below the rank of Under Secretary or equivalent.
Incomplete applications will be summarily rejected. The candidates
applying will not be permitted to withdraw subsequently.
Applications (in quadruplicate) of suitable and eligible persons who can
be spared immediately in the event of selection may be sent to the
Secretary, Delhi Urban Art Commission, Core-6 A, UG Floor, India Habitat
Centre, Lodhi Road, New Delhi-110003 within a period of 60 days from the
date of publication of this circular in the Employment News.
The Commission reserves the right to cancel the selection process at |
any point of time without assigning any reasons thereof. |
|
सचिव

<!-- page 3 -->

Annexure-1
|
Affix recent
Passport size
photograph
APPLICATION FOR THE POST OF Architectural Assistant IN THE DELHI URBAN ART
COMMISSION.
Name, Designation, Name of | |
Organization with complete Address (In |
Block Letters) |
=
कि गाव तिलक गत उबाल छत
5. | Date of Retirement under Central/State
Govt. Rules. |
| 6. [Addressfor communication | SSSCSC~—~SCS
Permanent Address
8. | Phone No. /Mobile No.
Details of Educational and other
Qualifications
Board/University/Institution Marks % of | Year of
Passed obtained | Marks/Class/Division | Passing |
1: | |
10. Details of Employment, in chronological order. (Enclose a separate sheet duly
authenticated by your signature, if the space below is insufficient)
Ministry/ Post held on | Duration of Service | *Level in the | Nature of
Department/ | Regular basis Pay duties in
Office/ From To Matrix/Pay details. |
Institution/ Band/Grade Highlighting
Organisation | Pay of the | experience
| | post held on/ required for
regular basis | the post
applied for.
नि ee ee ee 7]
*Level/Pay Band/Grade Pay granted in the MACPS/ACP are personal to the officers and
therefore should not be mentioned.

<!-- page 4 -->

ही मिस मा सा मगर Nature of present employment i.e. Ad-hoc or temporary |
or Quasi-Permanent or Permanent.
12. In case the present employment is held on deputation/contract basis, please state
a) The date of | b) Period of|c) Name of the | d) Nameofthe post
| | initial appointment on | parent and pay of the post
| | appointment | deputation/Contract | office/Organization | held in substantive
। to which the capacity in the
| applicant belongs | parent
organization. |
Pe eee: |
Note.: In case of Officer already on deputation, the application of such officer should be
forwarded by the parent cadre / department alongwith cadre clearance vigilance clearance
and integrity certificate.
जा विलयिल जद पवार 13. | If any post held on Deputation in the past by the
| | applicant, date of return from the last deputation
| and other details.
14. | Please state whether working under (indicate the
name of the employer against the relevant column)
a) Central Government
| b) State Government | 11
c) Autonomous Organizations |
| d) Government Undertaking |
e) Others
15. | Are you in Revised Scale of Pay? If yes, give the date
| from which the revision took place and also indicate
the pre-revised scale.
16. | Total emoluments per month now drawn.
eae ee al |
17. | In case the applicant belongs to an Organization which is not following the Central |
Government Pay-Scales, the latest salary slip issued by the Organization showing the
following details may be enclosed.
Basic Pay with Scale | Dearness Pay/Interim relief/other | Total Emoluments
of Pay and rate of | allowances etc. (with break-up
increment details)
ee el

<!-- page 5 -->

18. DECLARATION
| have carefully gone through the vacancy circular/advertisement and | am well aware that
the information furnished above duly supported by the documents in respect of Essential
Qualification/Work Experience submitted by me will also be assessed by the Selection
Committee at the time of selection for the post. The information/details provided by me are |
correct and true to the best of my knowledge and no material fact having a bearing on my
selection has been suppressed/withheld.
|
PLACES. .ecssssrssseseeccasvonsceee |
(Signature of Applicant)
Date Date.
+५01॥९255............... ००० «०«नन्‍>--
Email-ID........cccsesseeeeeesee
Contact Number |
|
|
|
|
|
* |
ea >> आल 293 5. 54 ५४ “लश्कर अ व ।

<!-- page 6 -->

Be
कई .

CERTIFICATION BY THE EMPLOYER/CADRE CONTROLLING AUTHORITY
The information/details provided in the above application by the applicant are true
and correct as per the facts available on records. He/she possesses educational
qualifications and experience mentioned in the vacancy Circular. If selected,
he/she will be relieved immediately.
2. Also certified that: |
i) There is no vigilance or disciplinary case pending/contemplated against

SHES isssssvssiscetscsssces
ii) | His/Her integrity is certified.
iii) His/her CR Dossier in original is enclosed / photocopies of the APARs/ACRs

for the last 5 years duly attested by an officer of the rank of Under Secretary

of the Govt. of India or above are enclosed.
iv) No major/minor penalty has been imposed on him/her during the last 10

years or A list of major/minor penalties imposed on him/her during the last

10 years is enclosed. (as the case may be)

Countersigned |
(Employer/Cadre Controlling Authority with seal) |
|
|
EE bee oilers sh ml |
