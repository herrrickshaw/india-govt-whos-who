---
doc_id: "1a38efb9ba1ace39"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/70b9343b87d36ea24704df97416000f4.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "National Programme for Prevention and Control of Fluorosis (NPPCF)   Guidelines for NPPCF"
date: "2025-11-27"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "38bfcf5de6102f0c"
---

<!-- page 1 -->

. है (2
Major Events & Achievements =
(April-July 2016)

1... Mass/Media Campaign / E-initiatives

1.1. New audio visual mass media campaign entitled ‘Zimmedari Nibhao, Plan Banao’
with Shri Amitabh Bhachchan as the brand ambassador launched. New Family
Planning logo unveiled on 5" April, 2016.

1.2 Quarterly Magazine “Healthy India Initiative” launched on 22"° June, 2016 by Hon'ble
Union Minister for Health & Family Welfare.

1.3. To access the authenticated health information by the citizens of India, three mobile
applications have been launched namely:

> “India Fights Dengue” launched on World Health Day 07" April, 2016.
> “NHP Swasth Bharat” also launched on World Health Day.
> “NHP Indradhanush Immunization” launched on 06" April, 2016.

1.4. e-Hospital modules at AIIMS, New Delhi was launched by Cabinet Secretary on 19"
July, 2016.

2. Tertiary Care

2.1. Affordable Medicines and Reliable Implants for Treatment (AMRIT) Outlets have
been opened at RML Hospital, Lady Harding Medical College, AIIMS Raipur &
Rishikesh, PGIMER, Chandigarh and JIPMER, Puducherry. These will provide
Cancer and Cardio Vascular drugs and implants at discounted prices to the patients
with valid prescription. 07 AMRIT outlets including one at AIIMS, New Delhi are now
functional.

3. Medical Education & Nursing

3.1. With the promulgation of IMC (Amendment) Ordinance, 2016 and The Dentists
(Amendment) Ordinance, 2016 on 24.5.2016, a national level common entrance
exam by the name National Eligibility Entrance Test (NEET) for MBBS/BDS has
been ushered. More than of lakh students have taken NEET 2016.

3.2 The age of superannuation in respect of GDMOs and Specialists of Non-Teaching
and Public Health sub-cadres of Central Health Services (CHS) has been increased
to sixty-five (65) years.

3.3. Renewal permission granted to the 51 Medical Colleges for 3810 MBBS seats for the
academic year 2016-17.

1,

<!-- page 2 -->

(2

3.4. 17 new Medical Colleges for the academic year 2016-17 have been approved so far. ~~
13 in Government and 4 in Private sector with additional seats capacity of 2150.

3.5 595 MBBS seats were also added in 9 existing Medical Colleges. 540 PG seats were
increased in the academic year 2016-17.

3.6 47 proposals for establishment of new medical colleges have been approved in 17
States/UTs under the CSS for ‘establishment of new medical colleges attached with
district/referral hospitals’ and total fund of Rs. 1104.73 crore released to States/UTs
till date, including Rs 445 crore released in 2016-17. Five medical colleges at Port
Blair (A&N Islands), Rajnandgaon & Ambikapur [Sarjuga] (Chhattisgarh), Gondia
(Maharashtra) and Nahan [Sirmour] (Himachal Pradesh) have become functional.
Work on 42 Medical Colleges is in progress.

3.7. 32 DNB/FNB courses were included in Schedule-l of IMC Act, 1956 for medical
practice and teaching purpose in their respective speciality.

3.8 Rs. 448.59 Crore, Rs. 136.75 Crore and Rs. 452.09 Crore released under Plan head
to JIPMER, Puducherry; PGIMER, Chandigarh and AIIMS, New Delhi respectively
for upgradation/expansion of the Institutes.

3.9 A Nurse Practitioner's Course in Critical Care Curriculum (Post Graduate —
Residency Programme) was launched by Hon’ble HFM.

4. Pradhan Mantri Swasthya Suraksha Yojana (PMSSY)

4.1 Contract was awarded for upgradation of super specialities services under PMSSY for

08 Government Medical Colleges.

4.2 Cabinet approved the setting up of a new AIIMS at Gorakhpur in Uttar Pradesh and a
new AIIMS at Bhathinda in Punjab under Pradhan Mantri Swasthya Suraksha
Yojana(PMSSyY).

2
