---
doc_id: "1932abfa9d8c5baf"
source_url: "https://mohua.gov.in/static/uploads/2025/10/4aea73ee010df845db37f92c7f786e60.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Sanction Order No.K-14011/4/2009-MRTS dated 26.09.2011- regarding Stations"
date: "2011-09-26"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "2bbd97c74a6933c5"
---

<!-- page 1 -->

No K-14011/4/2009-MRTS
Government of India
Ministry of Urban Developraent
(M.R.VS, Cell)
Nirman Bhawan, New Delhi.
Dated, the 26" September, 2011.
ORDER
In continuation 9! this. Ministry's sanction order No. K-14011/4/2009-MRTS dated
26.9.2011 relating to iriplementation of Delhi MRTS Phase Ill, the approved corridors
will comprise of the folowing stalions as per the Detailed Project Report (DPR):-
i) Mukundpar to Yaruna Vihar (35 stations): Mukundpur, Azadpur,
Shalimar Bagh, Netaji Subash Place, Shakurpur, Punjabi Bagh West, ESI
Hospital, Rajourl Cranden, Maya Furi, Naraina 2, Naraina 1, Delhi Cantt.,
Dhaula Kuan, Moti Bagh, Bhikaji Cama Place, Sarojini Nagar, INA, South
extn. Lajpat Nager, Srinivaspuri, Ashram, Hazrat Nizamuddin, Mayur
Vihar, Mayur Vihar Pkt-l, Trilokpuri, Vinod Nagar, | P Extension, Anand
Vihar, Jagaipur, Arun Nagar, Bhola Nath Nagar, Welcome, Jaffrabad,
Maujpur and ‘varnuna Vihar.
ii) Janakpuri West to Kalindikunj (22 stations): Janak Puri West, Janak
Puri 0-26, Dabri Mor, Dhasrath Puri, Palam. |.G.D. Airport, Vasant Vihar,
Munirka, ®.K. Purana, HT, Hauz Khas, Panchsheel Park, Chirag Delhi,
GLK. Enclave-l, Nehru Place, Kalkaji, Okhla Ph-lll, Ishwar Nagar, Jamia
Nagar, Okhla Vihar. Jasola Vihar and Kalindikunj.
iii) Central Secretariat to Kashmere Gate (7 stations): Janpath, Mandi
House, ITO, Delhi Gate, Jama Masjid, Lal Quila and Kashmere Gate.
iv) Jahangirpuri to Badli (3 stations): Shalimar Place, Rohini 98००8 and
Badli ’ हु
Mwave or
ae
(Wk. Lehigh”
Officer on Special Duty (UT) &
Ex- officio Joint Secretary |
To
Pay & Accounts Officer (Sectt.) :
Ministry of Urban Development '
Nirman Bhawan | i
New Delhi. | |
Copy forwarded to’: | |
| i
i) Cabinet Secretariat, Rasatrapati Bhawan, New Delhi.
ii) Principal Secretary to Prime Minister, South Block, New Delhi.
iii) OSD to Minister of Finance, North Block, New Delhi.
iv) Secretary to Li. Governor of Delhi, Ral Niwas, Delhi.
v) Secretary td Chief Minister of NCT if Delhi, Delhi Secretariat, Delhi
4 i
|
iy ‘
i Ho

<!-- page 2 -->

vi) Member Secratavy, Planning Commission, Yojana Bhawan, New Delhi.
vii) Chairman, Railway Board, Ministry of Railways, Rail Bhawan, New Delhi.
viii) Secretary, Ministry of Horne Affairs, North Block, New Delhi.
ix) Secretary, Deptt of {consmic Affairs, North Block, New Delhi
x) Secretary, Deptt of Expediture North Block, New Delhi.
xi) Secretary, Deptt of Revenue, North Block, New Dethi.
xii) Secretary, M/o Fload Transport & Highways, Parivahan Bhawan, New Delhi.
xiii) Secretary, M/o Environmiont & Forests, Pariyavaran Bhawan, CGO Complex,
New Delhi
xiv) Secretary, Dept, of Programme Implementation, Sardar Patel Bhawan, Sansad
Marg, New Delhi.
xv) Ghief Secretary, Gevi. of NCT of Delhi, Delhi Sachivalaya, |.P. Estate, New
Delhi.
xvi) Vice-Chairman, Delhi Oevclopment Authority, Vikas Sadan, INA Colony, New
Delhi -- 110020.
xvii) Managing Director, Delhi Metro Rail Corporation Ltd., Metro Bhawan, Fire
Brigade Lane, &arakhamea Road, New Delhi-119001.
Copy to :-
1. PS to UDM/PS tp MoS(UD)
2. Secretary (UD), MoUID, Mirman Bhawan, New Delhi.
3. Chief Controller of Accounts, MoUD, Nirman Bhawan, New Delhi.
4, Director (Media & Communications - Urban Development) (Ms. Anupama
Chandra), Press Information Bureau, 702 ‘A’ Wing, Shastri Bhavan, New Delhi.
5. Finance Division, MoLID, Nirman Bhawan, New Delhi.
6. Budget Section, MoUD, Nirman Bhawan, New Delhi. }
7. Guard file of Dethi MRTE: Project. (
wil Masher)
: ye \"
(S.K. Lohia)
Officer on Special Duty (UT) &
Ex- officio Joint Secretary
|
: |
‘ |
i
| i
|
' i
\
i
। :
|
: i 2 हि
|
