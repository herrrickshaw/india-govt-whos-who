---
doc_id: "1a4e1aba9be36dd8"
source_url: "https://powermin.gov.in/static/uploads/2025/06/526768c3f14d503172e8524718292901.pdf"
ministry: "Power"
title: "tender 53"
date: "2012-08-17"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ad56a2be772c209b"
---

<!-- page 1 -->

= F.No. 9/10/2012-Adm.III Q
Government of India
a Ministry of Power
(Adm. III- Section)
आफ
Shram Shakti Bhawan, Rafi Marg,
New Delhi, the 17th August, 2012
To,

As per list
Sub: - Tender for automated House Keeping service contract.

I am directed to invite sealed Tenders from reputed firms for complete
cleanliness, maintenance and plumbing work including manpower
{Supervisor-I & Housekeepers 17Jand materials by the Ministry of Power for
cleaning of toilets, maintenance of plumbing work/drainage lines,
corridors, staircases, common areas and rooms of Officers in the premises
occupied by the Ministry of Power in Shram Shakti Bhawan and Nirman
Bhawan as per details given in the enclosed terms and conditions.
Interested firms may send tender along with an earnest money of Rs.
25,000/- (Rupees Twenty Five Thousand Only) in the form of Demand Draft
from any of the nationalized bank in favour of Pay & Accounts Officer,
Ministry of Power, Government of India. The earnest money of all firms

. other than the successful tenderer will be returned after the contract is
finalized. The earnest money of the successful tenderer would be returned
. only after all other formalities regarding award of contract are completed
Performance Security equivalent to 5-10% of the yearly contract value is
deposited by the successful firm.
2: The firms should have sufficient prior experience in the field. They
should have also undertaken identical works in at least” two Government
Departments. The firm should also be registered with ESI, PF, Service Tax,
Labour Licence, PAN with the concerned authorities.
3. The quotations may contain company profile, documents to prove the
eligibility of all conditions as mentioned in para 2 above, earnest money as
mentioned at para 1 above and any additional documents to show the
गे competence of the firm. The firm should also mention their ESI and PF
code numbers and also enclose the copy of income tax clearance certificate.
er

<!-- page 2 -->

श्र 2 @
J - 4. The interested parties can inspect the premises on any working day
4A between 03:00 PM to 05:00 to assess the job requirement/quantum of
work involved. For the purpose, Section Officer (Adm.III) may be contacted
during office hours on any working day till 06.09.2012. After inspecting the
हे premises and going by the terms and conditions as enclosed in the
‘ continuing sheets, the firms should submit the quotations. The quotations
should be addressed to the Under Secretary (GA), Ministry of Power, Govt.
of India, Shram Shakti Bhawan, New Delhi:110 001 and dropped in the
/ ‘TERNDER BOX’ pertaining to the Ministry of Power kept at Gate No. 05 of
’ Shram Shakti Bhawan by 03:00 PM on 07.09.2012. The quotations
received after the stipulated date and time will be rejected. The quotations
will be opened at 03:30 PM on the same day i.e. 07.09.2012 in Room No.
22, Shram Shakti Bhawan, Rafi Marg, New Delhi. The authorized
representatives of the firms can remain present at the time of opening of
quotations.
5. The firms should take special care to prepare the bids. Omission -of
any of the demanded documents would result in the rejection of their entire
| tender. They should go through the tender advertisement thoroughly and
submit their quotations only if they meet all the conditions and are capable
of undertaking the proposed job satisfactorily at the conditions of the
Ministry of Power.
6. The Ministry of Power reserves the right to cancel any OF all of the
Tenders without assigning any reason.
Encl: Detailed job required and terms and conditions.
है Yours faithfully,
. / as
do
(P.K. SINGH)
: । ; Section Office: "
Copy to: NIC Cell, Ministry of Power with the request to put this quotation
. letter on the website of the Ministry of Power.
