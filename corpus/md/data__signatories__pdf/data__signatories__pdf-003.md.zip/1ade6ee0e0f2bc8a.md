---
doc_id: "1ade6ee0e0f2bc8a"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/8a6688ad002c1144c361903676b85e27.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "List of amendments carried out in LOIs/Registrations"
date: "2025-07-23"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c77aa65449580583"
---

<!-- page 1 -->

LIST OF AMENDMENTS CARRIED OUT IN LETTERS OF INTENT DURING MARCH, 2002
S.NO

NAME OF THE
COMPANY

LI.NO.&DATE

AMENDMENT CARRIED
OUT

NO.&DATE

1.

M/s.Supreme Yarns Ltd

LI:41(99)
dt.13.5.99

Change of name in the
Industrial Licence from M/s
Supreme Woollen Mills Ltd
to M/s.Supreme Yarns Ltd

CIL:.21(99)/2002
dt.06.03.2002.

2.

M/s. IBPCo Ltd

LI:120(98)
dt.14.9.98

Permission to shift the
capacity for mfr. of Site
mixed slurry explosives etc
covered under LI.No.120(98)
to Manuguru, Khammam
District, A.P

LI:120(98)/2002Amendment
dated 5.3.2002

3.

Jindal Cotex Ltd

63(98)
dt.26.5.98

Amendment in the item of
mfr and capacity

LI:63(98)/2002amendment dated
5.3.2002
