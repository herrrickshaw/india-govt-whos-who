---
doc_id: "1a4abce85aee7c0a"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/a55223e05a815bd52f18f594590afe6a.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Notification 13 February, 2019"
date: "2019-02-13"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a06dee53e2caf8c1"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA PART-I SECTION.I)
i

No.F. 9-28l2000-U.3 [Pt.1)

Government oflndia
Ministry of Human Resource Development
Department of Higher Education
ICR Division
Shastri Bhawan, New Delhi
Dated: 13th February, 2019

NOTIFICATION

'

Whereas, the Ccntral Government is empowercd under Section 3 of the
r'-University Grants Commission (UGC) Act, 1956 to declare, on the advice ofthe UGC, an
institution of higher Iearning as a deemed-to-be-university.

2.

And whereas, in exercise of the powers conferred by Section 3 of the UGC Act,

1956, the Central covernmcnt vide its Notification No.9-28/2000-U.3 dated 07.05.2002,

on the advice of UGC, had declared 'Rashtriya Sanskrit Sansthan', New Delhi consisting

of its eight multi-campuses located at Lucknow, Allahabad, Jaipur, Sringeri, Trichur,
Puri, lammu & Garil {Kangra, Himachal Pradesh) as an "lnstitution Deemed to be
University'', subiect to a review after five years.

3.

And whereas, the Central covernment vide Notification No. 9-28/2000-U.3
dated 01.01.2009, on the advice of thc UGC, extended the status of Dccmed to bc
University of'Rashtriya Sanskrit Sansthan', New Delhi for a further period of five years
i.e. upto 05.05.2012.

4.

And whereas, in exercise of the powers conferred by Section 3 of the UGC Act,
1956, the Central Government, vide Notification No. 9-28l2000-U.3 dated 30.06.2009,

on the advice of the UGC, permitted 'Rashtriya Sanskrit Sansthan', New Delhi to bring
the Bhopal and Mumbai Campus undcr its ambit as constituent teaching units.

5.

And further whereas, the functioning ofRashtriya Sanskrit Sansthan, New Delhi
was reviewed by UGC through its Expert Committee during 28-30th lanuary, 2077. The
Report of the Committee was considered by the Commission in its 521st meeting (ltem
No.2.03) held on 22nd February,2017 and the following resolution was passed:
"Considered ond approved with the condition that the deficiencies pointed
out" iI any, would be rectified and suggestions given by Expert Committee would be
implemented within a period of six months and the compliance report would be
submitted alongwith documentary prool to UGC."

6.

And whereas, Rashtriya Sanskrit Sansthan, New Delhi submitted its compliance
report which was again considered by the Commission in its 537'h meeting (ltem

Page 1of 2

<!-- page 2 -->

No.2,04) held on 10th December, 2018 and recommended for extension ofDeemed to be
University status to Rashtriya Sanskrit Sansthan, New Delhi from 07.05.2012 onwards.

7.

Now, therefore, in exercise of the powers conferred by Section 3 of the UGC Act,

1956, the Central Government, on the advice of the UGC, do hereby extend the Deemed
to be University status to Rashtriya Sanskrit Sansthan, New Delhi from 07.05.2012

onwards with the condition that the Institution Deemed to be University shall comply
with the suggestions given by the UGC Expcrt Committee, from time to time. This
extension is further to condition that all the terms and conditions that were stipulated
in the earlier Notifications of this Ministry shall continue to be adhered by the Rashtriya
Sanskrit Sansthan, New Delhi.

.?

(tshita RoyJ
Ioint Secretary to the Government of India
Tel:2338\721
The Manager,

Government of India Prcss,
Minto Road, New Delhi - 1100F.2Copv forwarded to: -

1. The Secretary, University Grants Commission, Bahadurshah Zafar Marg, New
Delhi - 110002.

2. The Member Secretary, All India Council for Technical Education, 1, Nelson
Mandela Marg, Pocket-10, Sector-8, Vasant Kuni, New Delhi-110070.

3. The Vice-Chancellor, Rashtriya Sanskrit Sansthan, 56-57, Institutional area,
Janakpuri, New Dclhi-1 10058.

4. Press Information Bureau, Shastri Bhawan, New Delhi-110001.
5. The Secretary-General, Association of Indian Universities, A.l.U. House, 16, Kotla
Marg, New Delhi - 110002.

6. Web Master, Department of Higher Education, Shastri Bhawan, New Delhi with
the request to issue necessary instructions to the CMIS Unit to display this
notification on the website of Department of tligher Education.

7. Guard file / Notification file.

,/E q, h-t$,

fsubrat Kumar PfaAEfif
Deputy Secretary

Page 2 of 2
