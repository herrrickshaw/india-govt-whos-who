---
doc_id: "1ba0a6731ced6fbb"
source_url: "https://www.darpg.gov.in/static/uploads/2025/10/52047385265904c4b364d9e47b1cd94a.pdf"
ministry: "Department of Administrative Reforms and Public Grievances (DARPG)"
title: "1st Sanction of Rs. 26 Lakh AI Power Virtual Assistant wokha, nagaland"
date: "2025-01-22"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1bb28eb959a25ac4"
---

<!-- page 1 -->

P -20 t 1 t 2023.D &D.DAR PG (8s02)

Government o, lndia
Ministry of Personnel, Public Grievances & Pensions
Department of Administrative Reforms & Public Grievances
6th Floor, Jawahar Vyapar Bhawan,
New Delhi-110001

Date* 2201.2025

To,

The Pay & Accounts Officer
Ministry ol Personnel, PG and Pensions
Lok Nayak Bhavan
New Delhi

Sub: Development of AI Powered Virtual Assistant Over Multiple Channels to
Act as Single Point Hub for Delivery ol Government Services and
Schemes at District Level" ol the District Wokha, Nagaland under State
Collaboration lnitiative (SCl) Scheme.
Sir,
I am directed to convey the sanction of the President of lndia lor the release

of an amount ol Rs. 26,00,000/- ( Rs. Twenty six Lakh only)as lst instalment,
which is 25yo ol lhe approved cost of Rs. 104 Lakhs (Rupees one crore four Lakhs
Only) for the aloresaid project under State Collaboration lnitiative Scheme. The
Project is sanctioned for the period of l2 months.

2.

The payment of Rs. 26,00,000/- ( Rs. Twenty six Lakh only) is hereby
lranslerred in the Central Nodal Account of National Centre for Good Governance
(NCGG), Central Nodal Agency (CNA) of this department as per following details.
Bank
Account
Name
Account Type
Account No.
IFSC
Branch Name

State Bank ol lndia
National Centre for Good Governance

Central Nodal Account (CNA)
42199275748
s8tN0000691
Main Branch, Parliament Street, New Delhi (Branch Code:
000691)

3.

The payment olRs. 26,00,000/- ( Rs. Twenty six Lakh only) may be
released through NEFT/RTGS by NCGG to beneficiary as per following details:
Accounl Name Deputy Commissioner
Bank
State Bank of lndia, Wokha Main Branch
Account
1 17 665 073 04
Number
IFSC Code
sBrN0003613

4.

The above release is subject to the following conditions: -

<!-- page 2 -->

i. The host department shall submit quarterly monitoring report to DARPG.

ii. Procurement, i, any, to be done as per provision of GFR.
iii. Timeline lor completion of the Proiect may be strictly adhered to and also
deliverables be achieved.
iv. The host Department shall duly submit Utilization Certiricate in GFR 12C'
componenl-wise expenditure statement and Progress report of the Project
alongwith pictures of work done with Geo coordinates.

5.

NCGG may comply with the procedures laid down in Department ol
Expenditure's O.M. No. 1 (18yPFMS/FCDl2O21 daled 9th March 2022.

6.

The expenditure is debitable to Major Head 2070-Other Administrative
Scheme for Administrative Reforms,
Services. Minor Head 2070.00.800.42.01
Obiect head 42.01.31 Grant-in-Aid General (31) under State Collaboration lnitiative
under Grant No. 74 for the year 2024-25.

-

7.

This issues with concurrence ol lntegrated Finance Division (H) vide eJile
P-201112023-D&D-DABPG (8502) Note No. #215 dated 15.01.2025.
Yours Failhfully,

\aJo"J-t'
(Vandana Nangia)
Under Secretary to the Governmenl oJ lndia
Copy to:

V

1.DDO/ Cash Section, D/o AR&PG.
2. Dr. Gazala Hassan, Assistant Professor, NCGG, gth Floor, NDCC - ll
Building, Jai Singh Road, New Delhi, Delhi - 110 001
3. Shri. Ajit Kumar Ranjan lAS, Deputy Commissioner, Wokha, Oflice of
the Deputy Commissioner, Wokha,Tsumang Colony, Wokha Nagaland797111
(Admn) , DARPG for information.
4. O.
5. Sanction Folder/Guard File.

S.

,)

\

,/
.7Y

O\V

/\ I

1S S

o

))

<!-- page 3 -->

Sanction Details

htps;//pfms.nic.in/Sanction/SanctionD€tails.aspx?sid=qV0Mibsl(

Public Financial Management System-PFMS

Wetome: t.6bl SlrCh

0/o Csntroller General 0l Accounts, Mrnrstry 0{ tinance

Financbl Ye.r: 2O2!F2O25

r',-h( rs\r\l

EnC,irh

Hel

sanction D.teils

s.h.o.m..contr.tarct !.
o34,PERSONNEI- P.G. & p,

P-20l1/2023-OaDOARPG (a502)

z2l0Ll2025

Tahsrer (DoO 6lID

2600000

P-20lr/2023-O&D-oaRPG

(8502)

L5/O712025

417s-SCHEME FOR ADI.I$IEIRA-IIVE REfORMS

t5a

049429-PAO{OP

& AR)

DDOi 249a3r-DEPARTMENT OF PERSONTIEL AND ADMINISTRATNE
RETORMS WING,S, PAIELBI-IAWAN,NEW

DEL},II 1 TOOOl

Ll ttom tast expeoatorc
ONDM

cE.ted onr

ONOM

iao.lrLd O.: 22101/2025 03,22:09

22101/2025 03:20:40

Slndbn Clrtom abtsr

EmDbr.. lllrio. St.t m

A!e!!!-ge.E-E

Departmcrt (For
UT Gr.nts only)

Grant

Obrect Catcgory Amount

Function Head

Hcad
207000a00rr201,
SCHEHE FOR
ADi.IIIIISTRATTVE

R.elt r/ lr.ct t .uG
t

tblbn Canlk tG

N AID
NEFORT'IS

Avall.bl.
PAO

5 . VOTEO

Budgct

2600000

GENERAL

Asglgy-geEitsi

Sr.No

A0enc,
llamc

Clty Dlstrlct State Country Gross Oeductton
Iet
Amount Amount Anount
souTtl

DELHI

2,600,000

0

PayGe R€marka

Account
lteed

2,600,000

OLD I'C
DrirDo0003098

san.tbn Approvc., suca5stuiy
Print S.nction der

I of 2

2210t2025, t:

<!-- page 4 -->

2ll
,'Dcl,clopnant ol ll l,ov'cred |.irtut.lssistunt (h.cr
Tlre release of lurld tbr the prcriect
Servict,v trtrd
Mtltiila Channtls ttt .tt,t qr Singit I.oint t lulh ./itr De.liy:r.y of Oot,ennnartt
rvas kept on irold duc to
Sr,iErrrer ,t Distri.t l.eyel" ttl thc l)istrict Woiha. Nagalancl
has
r.pr"*rt,i"" nradc h1, Shri l(ohit Singh. DC" I'seminl'u. Nagaland. Norv SN,ll)
"as per the ot iginal rc'comnlenclalion'
1rrup,,*..l to sanction the project

Note #

of Ils
ol'tlic, \\,e nlav convel our concurence tbr release tll'the 1 st installment
In
'ieu,
authoritv.and conlpli;rnce
:O lnttr. tt" corlcurrcncc of il,D is subjcct ro approval ofcompctent
rvithin the approvccl
of cotlal fonnalitics. SN,ID nra1, "ns,,re that ihe proiect is conrpctccl
timelinc

2.

l4l01/2025 05:0J PNI

1{,T :;z{E 3rq{EralNlADAN KUIVIAR JAISWAL
rfi qfu{tiq MIIA
Note # 214

Grantofconcurrence.aSsuggestedthroughprecedingnotes#211.213'maybeconsidered.
FC]
[endered Advice Category as per FAs' Charter:
l5/01/2025 l0: l4 ANI
RAVI vAZIRANI
DLPI.]TY SECRETARY. NIt{A
Note fl 215

l5/01/2025 l0:25 Al\t

lR-q fuqnurlnoER SINGH
3TT{

sft'{ 3ik frdfq € r(6TqAs&FA. MHA

Note # 216

l5/01/2025 l0:29 ANI
R"dVI VAZIRANI

DEPUTY SECRETARY' MHA
Note # 217

l5/01/:025 llrl0 tll

e-{a i5"fiR qr{rsaTq \r.\ l)A \ Kt lllAR.lAls\lAl:rrt sfra1tts, nt u.r
\ole # I l!i
15/01/2025 I l:30 ANI

iraft{ 6rrl-,{sH ISll x uluAR

r.am nffilsncrloN ol'FlclER' lllllA
Note H 219
15/01/2025 0l:53 P t

P r' "

: '; rr*d qr({iPt \til't \,\l)\\

:rqt qfral r lttr.s l:<-\ (l) \ ltP(; )
