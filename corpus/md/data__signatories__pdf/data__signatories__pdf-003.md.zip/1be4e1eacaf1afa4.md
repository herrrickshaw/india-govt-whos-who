---
doc_id: "1be4e1eacaf1afa4"
source_url: "https://www.niti.gov.in/sites/default/files/2026-05/Manual-34-Communication.pdf"
ministry: "Planning (MoP)"
title: "Manual 34: Guidelines for Indian Government Websites (GIGW) is followed (released in February, 2009 and included in the Central Secretariat Manual of Office Procedures (CSMOP) by Department of Administrative Reforms and Public Grievances, Ministry of Personnel, Public Grievance and Pensions, Govt. o"
date: "2026-05"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f892dae04c79c63b"
---

<!-- page 1 -->

: fee 110 | ही| i
i WEBSITE QUALITY CERTIFICATION SCHEME :
3 STQC Directorate 7
: Ministry of Electronics and Information Technology 7
: Electronics Niketan, 6, CGO Complex, Lodi Road, New Delhi — 110003 प्र
: CERTIFICATE OF APPROVAL :
: Approval Number: STQC/CQW/2025/62 :
: It is hereby certified that the website of :
i NITI Aayog i
z NITI Aayog, Patel Chowk, Parliament Street, :
i New Delhi :
: URL of Website: https: //niti.gov.in ;
i Fulfills the requirements of the i
i Website Quality Certification Scheme i
: It is verified that the website meets the requirements of the ;
7 Guidelines for Indian Government Websites, Ver 3.0 |
: This Certificate is valid upto: 27/04/2029 Date of Issue: 28/04/2026 ;
: Note 1:With 12 exemptions as per ‘Annexure —I attached. ४
5 Note 2: Subject to compliance during the surveillance audit. ‘
i Note 3: Visit https://stgc.gov.in/website-quality-certification-0 for details of the scheme. :
i (०) (A.K. UPADHYAYA) Aah +
i J HEAD - WQCS & Si eet ae i
i Co") 4 SCIENTIST ‘G’ fal A :

<!-- page 2 -->

ANNEXURE -I to Website Quality Certificate
STOQC/COW/2025/62 Dated 28.04.2026
Details of Exemptions sought from GIGW ver.3.0 requirements

Name: NITI Aayog

URL: https://niti.gov.in

ee GIGW 3.0 Requirement ae

| | Quality Guidelines | |

22 80? integration with key government platforms (India Portal, 5.1.22
DigiLocker, Aadhaar, Single-Sign-On, MyGov, Data Platform,
MyScheme) and similar websites of the government organization must |
be enabled for seamless exchange of Information and data.

|Accessibility Guidelines |

02 |For pre-recorded audio-only and pre-recorded video-only media, the] 5.2.2
following are true, except when the audio or video is a media
alternative for text and is clearly labelled as such:

(a) Pre-recorded Audio-only: An alternative for time-based media is
provided that presents equivalent information for pre-recorded
audio-only content.

(b) Pre-recorded Video-only: Either an alternative for time-based media
or an audio track is provided that presents equivalent information
for pre-recorded video-only content.

03 |Captions are provided for all pre-recorded audio content in| 5.2.3
synchronized media, except when the media is a media alternative for
text and is clearly labelled as such.

04 |An alternative for time-based media or audio description of the pre-| 5.2.4
recorded video content is provided for synchronized media, except
when the media is a media alternative for text and is clearly labelled as
such.

Captions are provided for all live audio content in synchronized media.
Audio description is provided for all pre-recorded video content in| 5.2.6
synchronized media.

13 |If any audio on a Web page plays automatically for more than 3] 5.2.13
seconds, either a mechanism is available to pause or stop the audio, or
a mechanism is available to control audio volume independently from
the overall system volume level.

23 \If a keyboard shortcut is implemented in content using only letter} 5.2.23
(including upper- and lower-case letters), punctuation, number, or *
symbol characters, then at least one of the following is true:

(a) Turn off: A mechanism is available to turn the shortcut off.

(b) Remap: A mechanism is available to remap the shortcut to include}

lone or more non-printable keyboard keys (e.g., Ctrl, Alt).

(c) Active only on focus: The keyboard shortcut for a user interface

component is only active when that component has focus.

<!-- page 3 -->

24 |For each time limit that is set by the content, at least one of the} 5.2.24
following is true:
(a) Turn off: The user is allowed to turn off the time limit before
encountering it; or Adjust: The user is allowed to adjust the time
limit before encountering it over a wide range that is at least ten
times the length of the default setting; or
(b) Extend: The user is warned before time expires and given at least
20 seconds to extend the time limit with a simple action (for!
example, "press the spacebar") and the user is allowed to extend the
time limit at least ten times; or
(०) Real-time Exception: The time limit is a required part of a real-time!
event (for example, an auction) and no alternative to the time limit)
is possible; or
(d) Essential Exception: The time limit is essential and extending it '
would invalidate the activity; or
e) 20 Hour Exception: The time limit is longer than 20 hours.
26 |Web pages do not contain anything that flashes more than three times} 5.2.26
in any one second period, or the flash is below the general flash and
red flash thresholds.
37 |Functionality that can be operated by device motion or user motion can] 5.2.37
also be operated by user interface components and responding to the
motion can be disabled to prevent accidental actuation, except when:
(a) Supported Interface: The motion is used to operate functionality
through an accessibility supported interface.
(b) Essential: The motion is essential for the function and doing so
would invalidate the activity.
(c) Functionality that can be operated by device motion or user motion| 4
must also be operable by user interface components and responding
to the motion can be disabled to prevent accidental actuation,
except when:
(d) Supported Interface: The motion is used to operate functionality
through an accessibility supported interface.
(e) Essential: The motion is essential for the function and doing so
would invalidate the activity.
47 |For Web pages that cause legal commitments or financial transactions} 5.2.47
for the user to occur, that modify or delete user-controllable data in
data storage systems, or that submit user test responses, at least one!
of the following is true:
a) Reversible: Submissions are reversible.
b) Checked: Data entered by the user is checked for input errors and
the user is provided an opportunity to correct them.
Confirmed: A mechanism is available for reviewing, confirming and
correcting information before finalizing the submission.
Disclaimer: at
The accessibility related exemptions given above are valid till no content requiring
compliance to these points are uploaded to the website. jolt
>
(A.K. \WpADHYAvA)
HEAD - WQCS & SCIENTIST ‘G’
