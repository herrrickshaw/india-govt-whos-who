---
doc_id: "1acf0f9f8c7ca3f3"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/db9cd831821012fbdfe3322b1875c378.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Recruitment rules amended for ED"
date: "2025-07-03"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0900a967a3955f00"
---

<!-- page 1 -->

187
44481 8/2022/LEATHER
444818/2022/LEA
THE R
<feet i. ~-~-i.q.- 33004/99
33004/99
~-«-

REGO.
REGO. No.
No. D.
D. L.-33004/99
L.-33004/99

�
~
l<cl cihl
JI 2T

([he
@ke '5a-:t.ette
Gazette of
of Jndia
India
~
.;;fr.-~-~- -3,. -0704202 2-2 34947
i.afi.-1.ul.-31.-07042022-234947
CG-DL-E-07042022-234947
CG-DL-E-07042022-234947
aHm11<01
314T4Tc°1
EXTRAORDINARY
EXTRAORDINARY

T III-qg
3-3q-qg (ii)
(ii)
mlf
I - ~ 3-~-~
PART
PART II-Section
II-Section 3-Sub-section
3-Sub-section (ii)
(ii)
4if+ic
~t~
4 1aifgla
PUBLISHED
PUBLISHED BY
BY AUTHORITY
AUTHORITY
1616]
t•. 1616)
No.
No. 1616)
1616]

7, 2022~
2022/a4 11,
17, 1944
1944
E fefi, aeenfdaic,
'ff~.
"l&ifil"m, aaa
~ 7,
NEW
2022/CHAITRA 17,
NEW DELHI,
DELHI, THURSDAY,
THURSDAY, APRIL
APRIL 7,
7, 2022/CHAITRA
17, 1944
1944
~~~~
aifois4
siic gear ialqq

(3el+r ~
iada *
sic sriafla
fd4in)
<~
~ 4Tic mm)
oQTqT(

sfeuaar
~
;,{
. 4~
. 2022
as ~
efi,
319m,
2022

41 20)
T.s4I. 1699(31").~
1699(M).ai4 4*417
sir fqai4
qfafq44,
2017 (2017
(2017 efiT
efiT.3lT.
~ Fed4'.fc.Fcl'-1( feaied
~"11~'1 ~
~ ie4in
~~
. 2017
20)

41 4aT
i mu
*T 18
18 <ft"
i ~-mu
4Ba a1YT 35
35 <ft"
fi ~-mu
3H-41*T (2)
(2) ~
ie
() 2I*T
ilai efiT
4-a
<ft"
~~~mu
~ {cfi)
~ 4<rd
~ !?~
~m
34-41*T (1)
(1) 4T4
, ai@is4
siir fqaiq
irin,. i4aifi
fa+
4di f.:t;n:r,
fq44, 2018
2018 efiT
1
"[Q:,
i:llful>j'-1 sir 3elm
~ i4144, t<fd4+
'.fc.Fcl'-1( feaTsa
~"11~'1 ditt
~~
<hlzf<hlD f.Rl
?Tcfi ~
+-a fu
fqa4 aaifi
a, 31"%!":a4la:"ffl
?ITTR m
~ IB"Q, famlalaa
f..lklRIRla f.:t;n:r
~ ~.
ivnaa

*

~ .

*

~.

1. (1)
(1) a
fa4ii efiT
+i ifai
4TM ai@is4
sii* sen
ii44,. tcfq41.
~ R<llIT
~ °'1Tl1
i:llful>j'-1 3TTl:
~ ~
'.fc.Fcl'-1( feared
~"11~'1 sir fdaim
~ ie4id, ii4ii
<hlzf<hlD
fqa+
(ivtan)
fq44, 2022
f.Rl
?Tcfi 4ii
~ ("ffl
?TT&-7) f.:t;n:r,
2022 ~iI
fi aifia 4
(2)
t - ~ it4a
ffl ,;(efil"l
44Tim
?R <fr"~
~~~I
ail ii
(2) i1a9*

JR~*~.

2.
i:llful >j'-1 sii*
~ sen
~~
ia144,
. tefq4+
'.fc.Fcl'-1( feared
~"11~'1 sii* fqai4 ir4id, +i4aifi
<hlzf<hlD f.Rl
fqen+
?Tcfi ~
4di f.:t;n:r,
fa44, 2018
2018 (
(a4
~
2. if@is4
4 i,z4H
TY4TA
fd4H +eT
14T ), it
A f.:t;n:ifd44 4
~ z44
~ i:rl
?~ 34d
~ f.:t;n:r
~ <PTT

m.

t-

i:l I fu1 >j<1 fa4i"
~ " vi-ai
!?~
~ "f~
W
I ~ 3fJl:
"i4Ta ~49a,. aifmisa
a
<4id ~
4* "~
siir ~
aid?# OlfT9TT
4MY
"sen
iaan

(i) ~-f.:t;n:r
34-fa44 (2)
(2) it,
(i)
, "~

*

4q4,. ~
4*4TY,. HST
fq4T
4441 44+4
4Pd ~
H41f1"
vi-ii ef;l"
ii
fct°'
lWT i tq4*
~44
~ ar~
~~
~ silt tad4r
'.fc.Fcl<1< 44T
sr'lTTlT ~ ~
, , !?~
~~
qT
qT;;

(ii)
~
" l?~
"f~~
(ii) ~-f.:t;n:r
4-fa44 (4)
(4) it,
N, ''i:llful>j'-1
"aifoisa fa4i"
4* "~Wf~*~olTrm:~'
ieai~<qi1
"sejlm iaaa sir qia?a -4191r fd4i" !?~
vi-aT
ef;l"~~;
i
*4T °MT;
2508 Gl/2022
GI/2022

(I)
(I)

<!-- page 2 -->

188
444818/2022/LEA
THE R
44481 8/2022/LEATHE
2

[PART IIII-SEC.
SEC. 3(ii)]

THE GAZETTE OF INDIA :: EXTRAORDINARY

(iii)
~ fcn:n.T"
t fl>TR
sir ~
"aif@is
fa4i" !/~
vi-ai
rqiq ~
, "
4* "~"fief~
"seim iaaa 3ih::
iq?a "ixfT9n:
49i- fcr'+frlT"
fd4m"
(iii) '311-f.:ppr
-fa44 (6)
(6) it,
44MT;
a1
*qT7
vr-ai
!/~<Fl°~~;
~ f.:pp:ff
sifclf241 ta ma
~ "~ fqmfafaa
Ril-1Rl~a yaf@ii
sifclf241 ii
cFl" -qi
~
sad
fqani cf;tad4ii if,
rfia ufal@ii
fi ~
i, fa"'+!"
<«i4 12
12 t� 61"eft.r
~
; : -I+TT,:

3.
3.

.."fa4nfia
~~~iff.il-1Rl~a
~fTIJRla ~:a44 44la ii fqalafaa afrufaa
:(+)
(cfi)

* :pc.fclll (

i fq4r
4q4 61"ircfl
4441 44+d
sen
iaaa siir 3lfdTTcfi
aia?a "ixfT9n:
Mir fcr'+frlT
fq4i i
4Rd
4q4, '+fffif
~ "fief~
~ fficf
~ fficf,

~
. q4ST
~ an-'
'>f'+frlT tH4If]
"Sl"W -- 61"~7fef;
3IlT(_ tcfd4r H4I
4241;
4*4I7,
("€1")
()

:pc:fclll<: fearsm
~;,i1~.-i 3ih::
~ ~
Sefq4r
sir fctcfirn
fdain m:l>TR
ir4in t� "Sl".f~
yia ITT!ilcfi
fde+ 61"ircrr
q4ar zqfi
qq\laid if
i
:pc.fcl ll ( feaieq
~ "11 ~'1 3ih::
~ t fficf
~
tefq4fdaim iii1
4qa -- 4<N
sir fctcfirn

(11")
(T)

4IM f.:tffihr
4sis
in4um4<- fa4 aaia 4*47 filU
a*T .,pf
fdcf@la fdT
4<4;
~~"ft"~~~~~
~ MT4MT
~ -- ~
;

(er)
(T)

ala
~ qHsT
~ 3l¥ITTrr
MdH4IM 4HIM
~ 61"ircTT
~ tll!iR
4Id 4leiilifi
Sil £-tI r'I 4i1 m:i-r-R
iMIM 61"ircTT
444T ~
4*fia
q4di *1Ila
ieilmaii
si1 £-t"'1r'I 4i1 ire?4in
~ 61"ircTT
~ feared
~;,i 1~.-i 4ruin
~ aa
~ 444
~ i4zmi
~ it
4 said4rd
&-11 fB si I ca aisfi
~
q4al *4Gia
fcr~,
~ aaia
~~
~~
I"
arqa, faa
4-47 filU
arT .fP:r
4lH f.:tffihr
fqafvia faT
MT -- ~
421"

■

• 27011/1/2022-~]
27011/1/2022-44s1]
[. ff.
[1liT.
~ fie
~ ofF,
sfla
z147 , ~
44* fficf
49a

~
~ f.:ppr
. 3fffiITT(lJf,
~ 3,
.
3, '311-~
34-is (i)
(i) m.cfiT.f.'f.
4T.T.fd. 842(61"),
842(4), arw
fd44 llRa
4TA t4 ~
71494,
M4T4RN, '+TTlT
44I IIII,,is
aifia 55 ~
fqda-,
feqr:: 49
2018IDU~~~\itl
2018 21*T 3+if@a fu u qi

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
Trade)
NOTIFICATION

New Delhi, the 4th April, 2022
S.O. 1699(E).-In exercise of the powers conferred by clause (a) of sub-section (2) of section 35
read with sub-section (1) of section 18
18 of the Footwear Design and Development Institute Act, 2017 (20 of
2017),
2017), the Central Government hereby makes the following rules to amend the Ministry of Commerce and
Industry, Footwear Design and Development Institute, Executive Director Recruitment Rules, 2018,
2018,
namely:1.
1. (1) These rules may be called the Ministry of Commerce and Industry, Footwear Design and

Development Institute, Executive Director Recruitment (Amendment) Rules, 2022.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

In the Ministry of Commerce and Industry, Footwear Design and Development Institute, Executive
Director Recruitment Rules,
Rules, 2018 (hereinafter referred to as the said rules),
rules), in rule 4,(i)

in sub-rule (2),
(2), for the words "Joint Secretary, Department of Commerce", the words "Additional
Secretary or Joint Secretary to the Government of India in the Department for
for Promotion of
Industry and Internal Trade, in-charge of Leather and Footwear Division" shall be substituted;

(ii)

in sub-rule (4), for the words "Department of
of Commerce", the words "Department for
for Promotion
oflndustiy
of Industry and Internal Trade" shall be substituted;

(iii) in sub-rule (6),
(6), for the words "Department of
of Commerce", the words "Department for
for Promotion of
Industry and Internal Trade" shall be substituted.

<!-- page 3 -->

189
444818/2022/LEA
THE R
44481 8/2022/LEATHE
[4TM IIII-qvg
['lTTlf
~
3(ii)]

3.

����

3

entries shall be
In the Schedule to the said rules, for the entries
entries under column 12, the following entries
substituted, namely:namely: "Departmental Selection
Selection Committee consisting of:Department for
(a) Additional Secretary or Joint Secretary to the Government of India in the Department
Promotion of Industry and Internal Trade, in-charge of Leather and Footwear Division -Chairperson;
(b) Managing Director of the Footwear Design and Development Institute or in his absence Secretary
of the Footwear Design and Development Institute -- Member;
((c)
c) One member from Leather Industry to be nominated by the Central Government -- Member; and
(d)
d) One outside expert of eminence from prominent organizations
organizations like Central Leather Research
Institute or National Institute of Fashion Technology or Indian Institute of Technology or National
Institute of Design to be nominated by the Central Government -- Member."

27011/1/2022-Leather]
[F. No. 27011
/1/2022-Leather]
RAJEEV SINGH
SINGH THAKUR, Addl. Secy.
Secy.

Note :: The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, SubNote
Sub­
section (i) , vide number G.S.R. 842 (E),dated the 5th September, 2018.

Uploaded by Dte. of
of Printing at Government oflndia Press, Ring Road, Mayapuri, New Delhi-I
Delhi-110064
10064
and Published by the Controller of
of Publications, Delhi-I
Delhi-110054.
10054.
