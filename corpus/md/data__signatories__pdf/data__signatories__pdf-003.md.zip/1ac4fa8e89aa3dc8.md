---
doc_id: "1ac4fa8e89aa3dc8"
source_url: "https://financialservices.gov.in/sites/default/files/Act-Policies/2026-01/1-to-7-National-Housing-Bank-rules-gazette-notification.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Housing Finance Institutions Debt Recovery, Appellate Tribunal (Financial and administrative Power) Rules, 2002"
date: "2026-01"
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d31fcb5090169a46"
---

<!-- page 1 -->

REGD NO D L -33004/99

The Gazette of India
EXTRAORDINARY
PART II—Section 3—Sub-section (i)
PUBLISHED BY AUTHORITY

No. 215]

1489 GI 2002-1

NEWDELH1, WEDNESDAY, MAY8, 2002/VAISAKHA 18,1924

(I )

<!-- page 2 -->

2

THE GAZbi'lh OF INDIA EXTRAORDINARY

[PART II—SEC 3 (Qj

MINISTRY OF FINANCE
(Departmentof Economic Affairs)
(Banking Division)
NOTIFICATION
New Delhi the 7th May 2002
C.S.R. 335(E).—In exercise of the pow ers conferred b> section 54A of the National Housing Bank Act. 1987 (53
of 1987). ihc Central Go\ ernmeni hereb\ makes the follow ing rules, namch —
1, Short Title and commencement.—(1) These rules maj be called the Housing Finance Institutions Debt
Rcco\ er\ Appellate Tribunal (Financial and Administrate e Pow er) Rules. 2002
(2) Thej shall come into force on the date of their publication in the Official Gazette
2 Definitions.—In these rules, unless the context otherw isc requires.—
(a) "Acl" means the National Housing Bank Act. 1987 (53 of 1987).
(b) "Appellate Tribunal" means the Appellate Tribunal established under section 36-1 of the Act.
(c) "Presiding Officer" means a person appointed as Presiding Officer of an Appellate Tribunal under section
36JofthcAct.
(d) all other words and expressions used and not defined in these rules but defined in the Act shall ha\ c the
meanings respectively assigned to them in the Act
3. Powers of the Presiding Officer of the Appellate Tribunal.—The Presiding Officer shall hn\ c the same powers
as arc conferred on a Head of Department in respect of (he General Financial Rules. 1%3 the Delegation of the Financial
Powers Rules. 1978. the Fundamental Rules, the Supplemental} Rules the Central Ci\ ll Sen ices (Lc:n c) Rules. 1972. the
Central Ci\il Sen ices (Joining Time) Rules. 1979. UicCiul Scniccs (Pension) Rules. 1972. i he Central Cnil Sen ices
(Conduct) Rules. 1964. the Central Civil Sen ices (Classification. Control and Appeal) Rules. 1965 and the General Provident
Fund (Central Sen ices) Rules. 1960 as amended from time to time
Pro\ ided that the exercise of powers b\ the Presiding Officer under these rules shall be subject to such instructions as ma\ be issued from time to time by the Central Government
|F No 7(3)/2001-CPl
AJITM SHARAN.Jt Scc\ (B&I)

<!-- page 3 -->

3

<!-- page 4 -->

4

.

THE GAZETTE OF INDIA. EXTRAORDINARY

(PAR r II—Stc 3 (i)]

WT-I1

""4"

(°i<^ci1 sTftrord^T^), "3tt I ^ M I 3rf»-j3fnft % ^ ? " ^ Pnyw ^STTT£ *Tf7ftMT^ yftwH ^rm i f / ^ n : ^ t

NOTIFICATION
New Delhi, llic 7lh May 2002
G.S.R. 336(E).—In exercise of the powers conferred by section 54A of the National Housing Bank Act. 1987 (53
of 1987). the Central Government hereby makes the follow ing rules, nameh .—
1. Short Title and Commencement.—(1) These rules maj be called the Housing Finance Institute Recovery
Officers' (Qualifications and Conditions of Service) Rules. 2002.
(2) Thcv shall come into force on the date of their publication in the Official Gazette.
2. Qualifications for appointment as recovery officer.—A person shall not be qualified for appointment as
recovery officer, unless he.—
(a) is enrolled or is qualified to be enrolled as an ad\ ancc under the Advocates Act. 1961 (25 of 1961);
(b) is in the regular service oi an approved institution as an officer: and
(c) has experience as an officer of one or more approved institutions for at least five > ears or has practiced as
an advocate for at least three years.
3. Term of office of recovery officer.—The recover* officer shall hold office for such term, not exceeding three
years as the Central Government may specify and shall be eligible for rc-appointment:
Provided that the recovers officer shall, notu ithstanding the expiration of his term, continue to hold office
until his successor enters upon his office.
4. Resignation by a recovery officer.—A rccoven officer may. bv w riting under his hand addressed to the Central
Government, resign at any time
Provided that the recoven officer shall, unless he is permitted by the Central Government to relinquish
office sooner, continue lo hold office until the c\pir\ of three months from the date of receipt of such notice
or until a person duly appointed as a successor enters upon his office, which ever is earliest.
5. Removal of rccoven officer from office in certain circumstances.—The Central Government in consultation
with National Housing Bank ma\ remove from office any recoven officer, who^—
(a) has been adjudged an insolvent: or
(b) lias been convicted of an offense which, in the opinion of the Central Government, involves moral turpitude;
or
(c) has become physically or mentally incapable of acting as such recovery officer: or
(d) has acquired such financial or other interest as is likely lo affect prcjudicialh his functions as a Recovery
Officer; or
(c) has so abused his position as to render his continuance in office prejudicial to the public interest: or
(f) has resigned or. for any reason. rcmo\ cd or dismissed from the service of the approved institution of which
he is an employee;
Provided that where a recovery officer is proposed to be removed on any of the grounds specified in
clauses (b) to (c). the recovery officer shall be informed of the charges against him and given reasonable
opportunity of being heard in respect of those charges.
t
6. Oath of office and recover}.—Every person appointed as recovery officer shall, before entering upon his office,
make and subscribe an oath of office and secrecy in Form I and Form 11 annexed hereto
7. Other conditions of service.—The salary and allowances and other terms and conditions of service of a
recoven officer in respect of matters for which no pro\ ision is made in these rules shall be the same as may for the time
being be applicable toother employees of Ihe approved institution of a corresponding status and shall continue to be
paid the approved institution of which he is an employee

<!-- page 5 -->

__5
8. Interpretation —Ifany question arises relating to the interpretation of these rules, the same shall be referred
to the Central Government for its decision.
|F.No.7(3)/2(K)l-CP]
AJITM SHARAN. Jt. Secy. (B&l)
ANNEXURE
FORM-I

(Sec rule 6)
Form of oath of office for a recover* officer
"I
(Name of the recovery officer) having been appointed as recovery officer do solemnly affirm/do swear in
the name of God that I will faithfully and consciously discharge nn duties as recovery officer to the best of my ability,
knowledge and judgment, without fear or favour, affection or ill-\\ ill "

(NAME OFTHE RECOVERY OFFICER)

FORM-H

(Sec ink' 6)
Form of oath of secrecy for rcco\ cry officer
"I
(Name of the recovery officer) having been appointed as recovery officer do solemnly affirm/do swear in the
name of God that I will not directly communicate or reveal to any person or persons any matter w hich shall be brought
under my consideration or shall become know n to me as recovery officer except as may be required for the due discharge
of my duties as the recovery officer."

(NAME OFTHE RECOVERY OFFICER)

<!-- page 6 -->

6

THE GAZETTEOFINDIA EXTRAORDINARY

|?ART II—SEC. 3 (i)j

• NOTIFICATION
New Delhi. Ihc 7lh May, 2002
G.S.R. J37(E).—In exercise ofthc powers confci red b\ seclion 54AoflhcN;ilion;il Housing Bank Acl. 1987(51
of 1987) (he Central Gen crnincnl herein in.'ikcs Ilic follow ni|* rules, naniclv —
1. Short Title and Conmicncement—(1) These rules may be called ihc Housing Finance Insiilulions Debt Rcco\ cry
Appellate Tribunal (Salaries. Allowances and olhcr Conditions of Sen ice of Ihc Officers and Employees) Rules. 2002
(2) They shall come into force on the dateof Ihcir publication m LhcOfficial Ga/ctlc
2. Definitions.—In these rules, unless the coiilcxl olhcmisc requires.—
(,i) "Act' means the National Housing Bank Act. 1987(51 of 1987).
(b) all olhcr words and expressions used and not defined in Ihosc nilcs b»t defined in the Act shall ha\c the
meanings respectively assigned to (hem in ihc Acl
3. Salary of officers and employees trf the Appellate Tribunal. ^ T h c nature and categories of officers and
employees of an Appellate Tribunal and the scales of piw thereof shall be as specified in the Schedule appended hereto
4. Conditions of sen ice.—The conditions of scr\ ice ofllic officers and, employees of an Appcllalc Tribunal in the
matter of pay. allowances, leave, joining time, joining lime pay. prowdcitl fund, age of superannuation, pension and
retirement benefits, medical facilities, and other conditions ofscr\ ice. shall be regulated in accordance with such other
rules and regulations as arc. from time to lime, applicable to officers and employees of the Central Government belonging
to Group A'. Group "B\ Group 'C and Group "D" as the case ma\ be. and drawing the corresponding scales ofpay

SCHEDULE
S No Name of Post
1
Presiding Officer
2

Scale of Pay
12750—I65(X)

Secretary/Registrar

KXXK)—15200

Assistant Registrar

<>5<X>—I0SX)

4
5

Pi I\ ate Secretary to Presiding Officer

•65<X>—10500

Section Officer

5-S(H)—9<XX>

6
7

Assistant/Research Assistant
Accounts Assistant/Cashier

5^X1—9<XK)
4<XX>-6<XX)

<!-- page 7 -->

_7
8.
9.
10.
11
12.
13
14
15

Steno Grade-C
Steno Grade D'
UDC/Care Taker

3050^4590

LDC/TVpist

2610-^3540 •

Staff Car Driver
Jamadar/Daftry-cum-Record Keeper'
Gestetner Oper&tor-ium-PhotOoopier

2550—3200
2610—3540

Peon/Farash/Sweepftr .• <

2550—3200 '

•)()5()—J59(>

2610—3540
[F No 7(3)/2001-CP]
AJ1T M SHARAN. Jt Sec\ (B&I)

<!-- page 8 -->

8

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC. 3 (i)]

<!-- page 9 -->

9

1489^/0.1.-2.

<!-- page 10 -->

10

THE GAZETTE OF INDIA EXTRAORDINARY

[PAR r II—SEC. 3 (i)]

NOTIFICATION

New Delhi, the 7th Ma\. 2002
G.S.R. 338(E),—In exercise of the powers conferred b> Secnon 54A of the National Housing Bank Act. 1987 (53
of 1987). the Central Government hereb\ makes the following rules, namelv —
CHAPTER I
Preliminary
1. Short Title and Commencement—(I) These rules mav be called the Housing Finance Institutions Debt Recov en
Appellate Tribunal (Procedure) Rules. 2002
(2) They shall come into force on the date of their publication m the Official Gazette
2. Definitions.—In these rules, unless there is anything repugnant to the sublet or context.—
(a) "Act" means the National Housing Bank Act. 1987 (53 of 1987).

<!-- page 11 -->

11
(b) "agent" means a person duly authorised by a party to present application or to give reply on its behalf to
the Appellate Tribunal.
(c) "appeal" means an appeal made to the Appellate Tribunal under section 36S of the Act:
(d) "appellant" means a person or an approved institution making an appeal to the Appellate Tribunal under
section 36S of the Act.
(c) "Appellate Tribunal" means an Appellate Tribunal established by Central Government under section
36-1 of the Act:
(f) "legal practitioner" shall have the same meaning as assigned to it in the Advocates Act 1 % 1 (25 of 1961);
(g) "Presiding Officer" means the Presiding Officer of an Appellate Tribunal:
(h) "recovery officer" means an officer appointed by the Central Government under section 36D of the Act;
(i) '"Registrar" means the registrar of an Appellate Tribunal and includes an olTiccr of such Appellate Tribunal
who is authorised by the Presiding Officer to function as Registrar;
(j) "Registry" means the Registry of the Appellate Tribunal;
(k) all other words and expressions used and not defined in these rules bui defined in the Act shall have the
meanings respectively assigned to them in the Act
3. Sittings of Appellate Tribunal.—An Appellate Tribunal shall hold its sitlings-cithcr at headquarters or at such
other place falling within its jurisdiction as it may consider convenient.
4. Language of Appellate Tribunal.—(I) the proccdings of the Appellate Tribunal shall be conducted in English
or Hindi
(2) No appeal, reference, application, representation, documcnl or olhcr matters contained in any language other
than English or Hindi, shall be accepted by the Appellate Tribunal, unless the same is accompanied by a true copy of
translation thcrcofin Englishoi Hindi.
5. Procedure for filing appeals.—(1) A memorandum of appeal shall be presented in the prescribed Form by the
appcllent cither in person to the Registrar of the Appellate Tribunal within w hose jurisdiction his case falls or shall be sent
by registered post addressed to such Registrar.
(2) Where the apcIlaiH is an approved institution, a memorandum of appeal may be preferred.—

(3)
(4)
(5)

(a)

by one or moire legal practitioners authorised b\ such approved institution; or

(b)

b\ any of the officers of such appro\cd institution to act as Presenting Officers,

and every person so authorised may present the appeal before the Appellate Tribunal.
Where the appellant is olhcr than an approved institution, he may prefer an appeal in person or by his agent
or b> a duly authorised legal practioncr
An appeal sent by post under sub-rule (1) shall be deemed to have been presented to the Registrar on the
da\ on which it is rccci\cd in the office of the Registrar
The appeal under sub-rule (I) shall be presented in four sets in a paper book along w ith an empty file size
cmclopc bearing full address of the respondent and where the number of respondents arc more than one.
then sufficient number of extra paper book toghclhcr w uli cmpl> file si/c cm elopes bearing full addresses
of each respondents shall be furnished by the appellant.

6. Presentation and scrutinj of memoirandum of appeal.—(I) The Rcgistrai shall endorse on everv appeal the
date on which it is presented under rule 5 or deemed to have been presented under that mlcand shall sign endorsement.
(2)

If, on scrutiny, the appeal is found to be in order, it shall be du(\ registered and gi\cn a serial number.

0)

1 fan appeal on scrutiny is found to be defective and the defect noticed is formal in nature, the Registrar may
allow the appellant to rectify the same m his presence and if the said defect is not formal in nature, the
Registrar, may allow the appellant such lime to rectify the defect as he may deem fit
(4) I fthc concerned appellant fails to rectify the defect w ilhin the lime allowed in sub-rule (1). the Registrar may
by order and for reasons to be recorded in w ritilng, decline too register such memorandum of appeal
(5) An appeal against the order of the Registrar under sub-rule (4) shall be made w ilhin fifteen days ofmaking
order to the Presiding Officer concerned in his chamber, whose decisions, shall be final
7.
Place of filinj; memorandum of appeal.—The memorandum ofappcal shall be filed by the appellant with the
Registrar of the Appellate Tnbubnal having jurisdiction in the matter.
8.
Payment of Fee—Every memorandum ofappcal under section 36S of the Act shall be accompanied with a
prescribed fee and such fee ma\ be remitted cither in the form of crossed demand draft drawn on a nationalised bank in

<!-- page 12 -->

12

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC. 3 (i)]

favour of the Registrar. Housing Finance Institutions Debt Recovery Appellate Tribunal
(Place) and payable at the
station where the Registrar's office is situated or remitted through a crossed Indian Postal Order drawn in favour of the
Registrar Housing Finance Institutions Debt Recovery Appellate Tribunal
(Place) and payable in Central Post Office
of the station where the Appellate Tribunal is located.
9.
Deposit of amount of debt due.—Where an appeal is preferred by a borrower, such appeal shall not be
entertained by the Appellate Tribunal unless such person has deposited with the Appellate Tribunal scventyfive per cent
of the amount of debt so due from him as determined by the rcco\ cry officer under section 36F of the Act. provided that the
Appellate Tribunal may. for reasons to be recorded in writing, wan e or reduce the amount to be deposited under section
3'T of the Act.
10. Contents of memorandum of appeal.—(1) E\ ery memorandum of appeal filed under rule 5 shall set forth
concisely under distinct heads, the grounds of such appeal w ithout am argument or narrative, and such grounds shall be
numbered consecutively and shall be typed in double line space on one side of the paper
(2) It shall not be necessary to present separate memorandum of appeal to seek interim order or direction if in
memorandum of appeal, the same is pray ed for.
11. Documents to accompany memorandum of appeal.—(1) Every memorandum of appeal shall be in
quardiplicatc and shall be accompanied with two copies (at least one of w hich shall be certified copy) of the order of the
recovery officer against which the appeal is filed.
(2) Where the parties to the appeal arc being represented by an agent, documents authorising him to act such
agent shall also be appended to the appeal:
Pro\ ided that w here an appeal is filed by a legal practitioner, it shall be accompanied by a duly executed MikaJatnama.
(3) Where an approved institution is being represented by any of its officers to act as Presenting Officer before
the Appellate Tribunal the document authorising him to act as Presenting Officer shall be appended to the memorandum of
appeal
12. Plural remedies.—A memoranum of appeal shall not seek relief or reliefs based on more than a single cause
of action in one single memorandum of appeal unless the reliefs prayed for are consequential to one another or arising from
the same order of the recovery officer.
13. Endorsing copy of appeal to the respondents.—A copy of ihc memorandum of appeal and paper book shall
be served on each of the respondents, as soon as they are filed, by the Registrar by registered post.
14. Filinj> of reply to the appeal and other documents by the respondent.—(1) The respondent may file four
complete sets containing the reply to the appeal alongwith documents in a paper book form with the Registry within one
month of the service of the notice on him of the filing of the memorandum ofappcal
(2) The respondent shall also endorse one copy of the reply to the appeal along with documents as mentioned
in sub-rule (1). to the applicant
0)
The Appellate Tribunal may. in its discretion on application by the respondent, allow the filing of reply
referred to in sub-rule (1). after the expiry of the period referred to therein.
15. Whoma> be joined as respondent.—(1) In an appeal by a person other than an appro\ed institution, the
approved institution u ho has to recover any debt from the person under section 16E of the Act. before the recovery officer
against whose order the appeal has been preferred, shall be made the respondent to the appeal.
(2) In an appeal by an appro\ cd institution the other party shall be made the respondent to the appeal.
1 rt. Date and place of hearing to be notified.—The Appellate Tribunal shall notify the parties the date and place
of hearing ofthc appeal in such a manner as the Presiding Officer may by general or special order direct.
1
17. Dress Rules for the Presiding Officer and for the Representatives of the Parties.—(1) Summer dress for
Ihc Prcsidui" Officer shall be while pani with black coat and a black licorabultoncd-upblackcoat. In winter, striped or
black tion 1 1 i may be worn in place of w lute trousers. In the case of female Presiding Officers, however, the dress shall be
black coal ON cr w lute sarce.
(2) The dress for the agent of the parties (other Hum a rclal IVC or regular employee of Ihc appellant or respondent)
appearing before the Appellate Tribunal shall be the follow ing, namely —
(a) In the case of a male, a suit with a tic or buUoncd-up coal over a pant or national dress that is a long
bultoncd-up coat on dhoti or chundar pyjama The colour of the coat shall, preferably, be black
(b) In the case of female, black coat o\ cr white or any other sober coloured sarcc
(c) Where, howexcr. the agent belong to a profession like that of lawyers or a chartered accountants and
they \\a\ c been prescribed a dress for appearing m their professional capacity before any court, appellate
tribunal, tribunal or other such authority, they may at their option, appear in that dress, in hen of the dress
mentioned above.

<!-- page 13 -->

13
(3)

All other persons appearing before the Appellate Tribunal shall be properly dressed.

18. Order to be signed and dated.—(1) Every order of the Appellate Tribunal shall be in w nting and shall be
signed and dated by the Presiding Officer of the Appellate Tribunal.
(2)

The order shall be pronounced in open court.

V). Publication of orders.—The orders of the Appellate Tribunal as are deemed fit for publication in any
aulhorilatnc report or the press may be released for such publication on such terms and conditions as the Appellate
Tribunal may lay down.
2(1, Communication of orders.—Even order passed on an appeal shall be communicated to the appellant and
to the respondent and to the recovery officer concerned cither in person or by registered post free of cost.
21. Fee for inspection of records and obtaining copies thereof.—(1) A fee of rupees t\\ cniy for every hour or
part thereof of inspection subject to a minimum of rupees one hundred shall be charged for inspecting the records of a
pending appeal by a party thereto.
(2) A fee of rupees fi\ c for a folio or part thereof not imolving t\ ping and a fee of rupees ten for a folio or part
thereof in\ ol\ ing is ping ofstatcment and figures shall be charged
22. Orders and directions in certain cases*.—The Appellate Tribunal ma> make such orders or give such
directions as ma> be necessary or expedient to gi\c effect to Us orders or to prevent abuse of its process or to secure the
ends of justice
23. Working hours of the Appellate Tribunal.—(I) Except on Saturdays. Sundays and other public holidays,
the officers of the Appellate Tribunal shall, subject to any other order made b> the Presiding Officer, remain open daily from
10a m. lo (> (H)p.m but no work, unless ofan urgent nature, shall be admitted after 4.30 p m. on any working day.
(2) The sitting hours of the Appellate Tribunal shall ordinanh be from 10 30 a.m. to 1.00 p.m and 2.00 p.m. to
5 00 p.m subject lo am order made by the Presiding Officer.
24. Effect of holiday—Where the last day for doing am act falls on a day on which the office of the Appellate
Tribunal is closed and by reason thereof the act cannot be done oiilhat day. it may be done on the next day on which that
office opens.
25. Powers and functions of the Registrar.—(1) The Registrar shall have the custody of the records of the
Appellate Tribunal and shall exercise such other functions as arc assigned to him under these rules or by the Presiding
Officer by a separate order in w riling.
(2)

The official seal shall be kept in the custody of the Registrar

(3) Subject to any general or special direction by (he Presiding Officer, the seal of the Appellate Tribunal shall
not bcalfi\ed loam order, summons or olhcr process, sa\c under | he authority in writing from the Registrar.
(4) The seal of the Appellate Tribunal shall no! be affixed lo am certified copy issued b> the Tribunal save
under ihc authority in w riling of llic Registrar
26. Additional poncrs and duties of Registrar.—In addition to Ihc powers conferredclscwhere in these rules,
ihc Registrar shall have the following powers and duties subject to am general or special orders of the Presiding Officer,
namely • (1)

to rccci\c all appeals and olhcr documents .

(2)

to decide all question arising out of the scrutiny of Ihc appeals before they arc registered ;

(3)

lo require any appeal prcscnicd lo ihc Appcllaic Tribunal lo be amended in accordance with the rules;

(4) subject lo the directions of ihc Presiding Officer lo fix dale of hearing of the appeals or olhcr proceedings
and issue nonces llicrcof.
(5)

direct any formal amendment of records .

(h)

lo order grant of copies of documents to parties lo proceedings ;

(7)

lo uant leave lo inspect Ihc record of Appellate Tribun-'

(X, dispose of nil mailers relating lo Ihc sen ice of nonces or omcr processes, application for the issue of fresh
nonce or for extending the time lor or ordering a particular method of scrucc on a respondent including a substituted
aerucc b\ publication of the notices b\ way of advertisements in the newspapers :
('•>)

lo requisition iccords fiom ihc custody of any court or other authority.

<!-- page 14 -->

14

THE GAZETTE OF INDIA EXTRAORDINARY

|Pu<i II—SH 3 ( I ) ]

27. Seal and emblem.—The official seal and emblem of the Appellate Tribunal shall be such as the Central
Government may specify
|F No 7(3)/2001-CP]
AJ1TM SHARAN.Jl Scc> (B&I)

<!-- page 15 -->

15

NOTmCATTON
New Delhi, the 7th May. 2002
G.S.R. 339(E).—In exercise of the powers conferred by Section 54A of the National Housing Bank Act. 1987 (53
of 1987). the Central Government hereby makes the following rules, namely —
1. Short title and commencement.—(1) These rules may be called the Housing Finance Institutions Debt
Recovery Appellate Tribunal (Salaries. Allowances and other Terms and Conditions of Sen ice of the Presiding Officer)
Rules, 2002
(2) They shall come into force on the date of their publication in the Official Gazette
2. Definitions.—In these rules, unless the context oiheru isc requires.—
(a)

"Act" means the National Housing Bank Act. 1987 (53 of 1987).

(b)

"Presiding Officer" means a person appointed as Presiding Officer of an Appellate Tribunal under Section
36J of the Act.

(c)

AH other words and expressions used and not defined in these rules but defined in the Act shall hav e the
meanings respectively assigned to them in the Act

3. Salary.—The Presiding Officer of an Appellate Tribunal shall be paid a salary m the scale of pay of Rs 18.400—22.400
Provided that in the case of an appointment of a person as a Presiding Officer, w ho has retired as a District Judge.
or who has retired from service, under the Central Government or a State Go\ ernment and w ho is in receipt of or has receiv ed
or has become entitled to receive any retirement benefit by way of pension, gratuity, employ e r s contribution to the
Contributory Provident Fund or other forms of retirement benefits, the pay of such Presiding Officer shall be reduced by the
gross amount of pension or employer's contribution to the Contributory Pro\ ident Fund or any other form of retirement
benefit, if any. draw n or to be drawn by him
4. Deputation duty allowance.—If a person holding the post on a regular basis in the scale of pay of
Rs 18,400—22,400 is appointed as Presiding Officer of a Appellate Tribunal on tenure basis and holds hen in his parent
cadre, he shall be paid a salary in the scale of pay specified in rule 3 plus a deputation duty allow ance at a rate as are
applicable to Group A' officers of the Central Gov ernment draw ing an equi\ alent pay

<!-- page 16 -->

16

THE GAZETTE OF INDIA. EXTRAORDINARY

IPARTII—SEP. 3(i)l

5. Dearness allowance and city com|>cnsatory allowance—The Presiding Officer of an Appellate Tribunal shall be
entitled to drawn dearness allowance and city compensatory allowance at the rate admissible to Group 'A' officers of the
Central Government drawing an equivalent pay.
6. Leave,—The Presiding Officer of an Appellate Tribunal shall be governed in matters relating to his rights in
respeef of leave by the Central Civil Services (Leave) Rules. 1972
7. Leave sanctioning authority.—The President of India shall be the authority competent to sanction leave to the
Presiding Officer of the Appellate Tribunal.
8. Pension/Provident Fund.—In case a serving Judge or an Officer of the Central Government or Slate Government
is holding the post of Presiding Officer, the service rendered in the Appellate Tribunal will count for pension to be drawn in
accordance with the rules of the service to which he belongs. He shall also be governed by the Provisions of the General
Provident Fund (Central Services) Rules. 1960. In all other cases, a person shall be entitled to Contributory' Pro\ident Fund
(India) Rules. 1962.
9. Travelling allowances.—The Presiding Officer of an Appellate Tribunal while on lour or on transfer (including
the journey undertaken to join the Appellate Tribunal or on the expiry of his terms with the Appellate Tribunal to proceed
to his home town) shall be entitled to the travelling allowances, daily allowances, transportation of personal effects and
other similar matters at the same scales and at the same rates as arc applicable to Group "A" officers of the Central
Government drawing an equivalent pay.
10. Leave travel concession.—The Presiding Officer of an Appellate Tribunal shall be entitled to leave travel
concession at the same rates and at the same scale as are applicable to Group 'A' officers of the Central Government
drawing an equivalent pay.
11. Facility of conveyance.—The Presiding Officer of an Appellate Tribunal shall be entitled to a staff car and one
hundred and fifty litres of petrol every month or actual consumption of petrol per month, whichever is less.
12. Accommodation.—(I) Every person appointed as a Presiding Officer of an Appellate Tribunal shall be eligible,
subject to availability, to the use of official residence from the general pool accommodation of the t> pe admissible to a
Group 'A' officer of the Central Government, who is working at the place uhcrc such Appellate Tribunal is located and
drawing an equivalent pay on payment of the licence fee at the rates specified by the Central Government from time to time.
(2) Where the Presiding Officer of an Appellate Tribunal occupies an official residence bc\ond permissible period,
he shall be liable to pay additional licence fee or penal rent, as the case may be. and he shall be liable to eviction in
accordance with the rules applicable to Central Government sen ants.
(3) Where the Presiding Officer of an Appellate Tribunal does not avail of facility of official residence under subrule (1). he shall be entitled to House Rent Allowance as admissible to Group A" officers of the Central Government
drawing equivalent pay.
13. Facilities for medical treatment.—The Presiding Officer of an Appellate Tribunal shall be entitled to medical
treatment and hospital facilities as provided in the Contributor) Health Sen ice Schemes Rules. 1954 and in places where the
Central Health Services Scheme is not in operation, the said Presiding Officer shall be entitled to the facilities as provided
in the Central Services Medical Attendance Rules. 1994.
14. Residuary provision,—Matters relating to the conditions of services of the Presiding Officer of an Appellate
Tribunal with respect to which no express provision has been made in these rules shall be referred in each case to the
Central Government for its decision and the decision of the Central Government thereon shall be binding on the said
Presiding Officer.
15. Power to relax.—Subject to the provisions of Section 36N. ihe Central Government shall have power to relax
the provisions of any of these rules in respect of any class or categories of persons.
[F No. 7(3)/2OOl-CP]
AJ1T M. SHARAN. Jt Secy. (B & I)

<!-- page 17 -->

17

<!-- page 18 -->

18

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC. 3 (i)]

NOTIFICATION
New Delhi the 7lh M:i\ 2002
(J.S.R. 340(E).—I ii cNcrcLseofllic powers conferred b\ Scclion S4A oflhc Naliuiiiil Housing &mk Act, 1987(53
of I'J87). the Central Government hereby mnkes the follow ing rules, namely —
1. Short Title and commencement.—(I) These rules may be called the Housing Finance Institutions Debt
Recover} Appellate Tribunal (Procedure for Appointment as Presiding Officer ofthc Appellate Tribunal) Rules. 2002.
(2) They shall come into forcccon (hcdalcof thcirpublication in the Official Ga/.ctlc.
2 Definitions.—In these rules, unless the contest otherwise requires.—
(a)

Act" means the National Housing Bank Act I W n l of IW7).

(b) "Appellate Tribunal" means the Appellate Tiibimal established under section 3(>-l oflhc Act:
(c)

Presiding Officer" mcajis a pci son appointed as Presiding Officer of an Appellate Tribunal under section
V>Jol the Act.

(d) all other w ords and expressions used and not defined in these rules but defined in the Act sahll have the
meanings iespecli\elv assigned to (hem in the Ac!

<!-- page 19 -->

19
3. Method of appointment under section J6J of the Act.—(1) For the purpose of appointment to ihe post of a
Presiding Officer, there shall be a Selection Committee consisting of—
(i)

the Chief Justice of India or a Judge of the Supreme Court of India as nominated by the Chief Justice of India:

(ii)

the Secretary to the Government of India in the Ministry of Finance (Department of Economic Affairs);

(iii)

the Secretary to the Government of India in the Ministry of Law and Justice.

(iv)

Special/Additional Secretary to the Government of India in the Ministry of Finance. Department of Economic Affairs (Banking Division), or an officer not below the rank of Joint Secretary in the Banking Division
nominated by the Special/Additional Secretary in the Banking Division, who shall also be the convenor of
the Selection Committee.

(v)

Chairman. National Housing Bank.

(2) The Chief Justice of India or the Judge of (lie Supreme Court shall be the chairman of the Selection Committee.
(3) Am three members of the Committee including the Chairman shall form a quorum for meeting of the Committee.
(4) The Selection Committee may devise its own procedure for selecting a candidate for appointment as Presiding
Officer.
(5) The Selection Committee shall recommend persons for appointment as Presiding Officxer from amongst the
persons on the list of candidates prepared by the Ministry of Finance after inviting applications therefor by advertisement.
(6) The Central Government shall on the basis of the recommendations of the Selection Committee make a list of
persons selected for appointment as Presiding Officer and the said list shall be \alid for a period of two years. The
appointment of a Presiding Officer shall be made from the list so prepared
4. Medical Fitness.—No person shall be appointed as a Presiding Officer unless he is declared medically fit by a
Medical Board to be constituted by ihe Central Government-for the purpose unless he has already been declared fit by an
equivalent authority.
5. Interpretation.—If any question arises relating to the interpretation of these rules the same shall be referred to
the Central Government for its decision
6. Saving.—Nothing in these rules shall affect reservations, relaxation of age limit and other concessions required
to be provided for the Scheduled Castes, Scheduled Tribes, other Backward Classes. Ex-serviceman and other special
categories of persons', in accordance w ilh the orders issued by the Central Government from time to time in this regard.
7. Oaths of office and secrecy—E\ cry person appointed to be Presiding Officer under section 36J of the Act shall,
before entering upon his office, make and subscribe an oath of office and secrecy in the Forms annexed hereto.
|F No. 7(3)/2(«)l—CP]
AJ1T M SHARAN. Jl. Secy. (B&I)
ANNEXURE
FORM-f
(Sec rule 7)
Form of oath ofoffkc for Presiding Officer of the Housing Finance Institutions Debt Recovery Appellate Tribunal
"1
(Name of the Presiding Officer) having been appointed as Presiding Officer do solemnly affirm/do swear in
the name of God Unit I will faithfully and consciously discharge my duties as Presiding Officer to the best of my ability,
knowledge and judgment, w ilhoiit fear or fa\ or. affection or ill-will."
(N AME OF THE PRESIDING OFFICER)
Housing Finance Institutions Debt
Recovery • tppetlate Tribunal
FORM-U
(See rule 7)
Form of oath of sccrcc\ for Presiding Officer of the Housing Finance Institutions Debt Recovery Appellate Tribunal
'I

(Name of the Presiding Officer) having been appointed as Presiding Officer do solemnly affirm/do swear in

<!-- page 20 -->

20

THE GAZETTE OF INDIA; EXTRAORDINARY

[PART II—SET. 3 (i)]

the name of God that I will not directly or indirectly communicate or reveal to any person or persons any malter which shall
be brought under my consideration or shall become known to me as Presiding Officer of said Debts Recovery Appellate
Tribunal except as may be required for the due discliarge of my duties as the Presiding Officer."
(NAMEOFTHEPRESIDINGOFFICER)
Housing Finance Institutions Debt
Recovery Appellate Tribunal

<!-- page 21 -->

21

<!-- page 22 -->

22

THE GAZETTE OF INDIA: EXTRAORDINARY

[Pun II—SF.r.3(i)]

<!-- page 23 -->

23

NOTIFICATION
New Delhi, the 7th May, 2002
G.S.R. 341(E).—In exercise of the powers conferred by Section 54A of Ihc National Housing Bank Act. 1987 (53
of 1987), the Central Government hereby makes the following rules, namely : T CHAPTERI
Preliminary
1. Short Title and commencement—(1) These rules may be called the Housing Finance Institutions (Procedure
for Recovery of Dues) Rules, 2002.
(2) They shall coiuc into forcce on the date of thcirpublication In the Official Gazette,
2 Definitions.—In these rules,.onlcss the context otherwise requires,—
(n) "Act" means the National Housing Bank Act, I Wl (53 of 1 lMl):
(b) "agent" means a person duly authorised by a party to present application or to give reply on its behalf to
the recovery officer:
(c) "applicant" means an approved institution or a person making an application to the recovery officer under
Section 3 6E:
(d) "application" means ;in application made to the recovery officer under Section 36E:
(d) all other words and expressions used and not defined in these rules but defined in the Act sahll have the
meanings respectively assigned to them in the Act.
CHAPTER II
Procedure of filing unification before the recovery officer
3. Lan^ua^e.—(I) The proceeding by the recovery officer shall be conducted in Hindi or English.
(2) No reference, application, representations, documents or other matters contained in any language other than
Hindi or English shall be accepted by the recover*' officer, unless Ihc same is accompanied by a true translation llicrcofin
Hindi or English.
4. Procedure for filing implication.—(1) An application shall be presented in prescribed form by the applicant in
person or by his agent or shall beseni by registered post, to the recovery officer within whose jurisdiction his case falls,
(2) An application sent by post under sub-rule (1) shall be deemed lo have been presented the day on which it is
received by the recovery officer.
(3) The application under snb-nilc (I) shall be presented in two scis. in a paper book along with an empty file size
envelop bearing full address of the respondent and where Ihc number of respondents is more Ihan one. then sufficient
number of c\lra paper books logelher with empty file size envelops bearing full address of each respondent shall be
furnished by Ihc applicant.
5. Scrutiny of applications.—<l) Recovery Officer shall endorse on every application the dale on which it is
presented or deemed to have been presented under rule 4 and shall sign endorsement.
(2) If. on scrutiny. Ihc application is found to be in order; it shall be duly registered and given a serial number.
(3) If Ihc application, on scrutiny, is found lo be defective and the defect noticed is formal in nature, the recovery
officer may allow Ihc applicant filing it lo rectify the defect in his presence and if the said defect is not formal in nature, the
recovery officer may allow the applicant such lime lo rectify Ihc defect as he may deem fit.
(4) If Ihc concerned applicant fails lo rectify Ihc defcel within Ihc lime allowed in sub-rule (3). the recovery officer
may be order and for reasons lo be recorded in writing, decline lo register Ihc application.

<!-- page 24 -->

24

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC.3(Q]

6. Place of filing applications.—The application shall be filed by the applicant with the recovery officer within
whose jurisdiction the borrower actually and voluntarily resides, or carries on business, or personally works for gain, or the
cause of action wholly or in part arises
7. Contents of application.—(1) Every application filed under rule 4 shall set forth concisely under distinct heads,
the grounds for such application and such grounds shall be numbered consecutively and shall be typed in double space on
one side of the paper
(2) It shall not be necessary to present separate application to seek interim or ad-intenm order or direction if in the
original application the same is pra> ed for
(3) Documents accompam ing the application shall be neath i\ ped in double space on one side of the paper or
legible photocopies thereof, duly attested bv an officer of the appnn ed institution, and numbered accordingly The
Recovery Officer may summon the original of the documents as and w hen it is considered necessary
8. Notice to the borrower.—(1) The notice u hich is required to be served on the borrower under Sub-section (1) of
Section 36F sliall be in the prescribed form
(2) Ev ery such notice shall be accompanied bv a cop\ of the application and paper book filed bv the applicant
under rule 4
(3) Tlie notice shall be sen ed by delivering a copv to each of the respondent or to his authorised agent, or when
such service cannot be so effected b> affi\ing a cop\ of the notice on some conspicuous part of his residence or bv
registered post or bv such other mode as ma\ be decided b\ the rcco\ er\ officer
9. Filing of reply and other documents by the respondent—(1) On receipt of the notice, the respondent ma> pay
the amount specified in the notice or file two complete sets containing the reph to the application as to w h\ the relief prayed
for should not be granted along with documents in a paper book form w ith the recovery officer w ith in a period of ninety
days from the date of service of the notice on him
(2) The respondent shall also serve one copv of the reph along w ith documents as mentioned in sub-rule (1) to the
applicant
(1) The rccov er\ officer ma\ at am time for sufficient reason order that am particular fact or facts m<n be proved
by affidavit or that the affidavit of am witness may be read at the hearing on such conditions as the rcco\ en officer thinks
reasonable
Prov ided that w here it appears to the recoven officer that cither applicant or defendant desires the production of
a witness for cross-examination, and that such witness can be produced an order shall not be made authorising the
evidence of such witness to be given by affidavit
(4) If the respondent denies lus liability to pay the claim made by the applicant the rcco\ enr officer may act upon
the affidavit ofthe applicant who is acquainted with the facts of the case or who has on verification oflhcrccord sworn the
affidavit in respect ofthe contents of application and die documents as c\ idencc
(5) If the respondent fails to filethe reply under sub-rule (1) of on the date fi\ed for hearing of Uie application, the
rccoven' officer may proceed forthw ith to pass such order on the application as he thinks fit
CHAPTER ID
Proceedings of R c u n c n Officer
1(1. Diitc and place of hearing to be notified.—(1) The rcco\ en officer shall notif\ the parlies the date and place of
hearing ofthc application in such a manner as he may b\ general or special order direct
(2) The recoven' officer shall endcavorto hear Ihe application at the place from where the loan was disbursed to
Hie borrower
11. Onlcr to be signed and dated.—E\ cry order of the recov en officer shall be m w rituig ,uid shall contain the date
when the order was signed and pronounced
12. Communication of orders to parties.—E\ en order passed on an application shall be communicated to the
applicant and to Ihc respondent cilhcr in person or b\ registered posl Ircc ol cost
13. Orders and directions in certain cases.—Thereon en olficcrmav make such orders or give such directions
as may be ncccssan or expedient lo give clfect to his orders or to prc\ cut abuse of its process or to secure the ends of
I ust ice

<!-- page 25 -->

25
CHAFTERIV
Review of orders by Recovery Officer
14. Review.—(1) Any party considering itself aggrieved by an order made by the recover*' officer on account of
some mistake or error apparent on the face of the record desires to obtain a review of the order made against him, may apply
for a review of the order to the recovery officer which had made the order.
(2) No application for review shall be made after the expiry of a period of thirty days from Die date of communication
of Uie order and no such application shall be entertained unless ii is accompanied by an affidavit verifying the application.
(3) Where it appears to the recovery officer that there is no sufficient ground for a review, he shall reject the
application but where the recovery officer is of opinion that the application for review shall be granted, he shall grant the
same:
Provided that no such application shall be granted without previous notice to the opposite party to enable him to
appear and to be heard in support of the order, a review of which is applied for.
CHAPTERV
Miscellaneous
15. Fee for ins|H-ction of records und obtaining copies thereof.—(1) No fee shall be charged for inspecting the
records of pending application by a party.
(2) All costs to be incurred in obtaining copies of the document desired by a party shall be recovered from such
party by the recovery officer.
16. Working hours of the office of Recovery Officer.—(I) Except on Saturdays. Sundays and other public
holidays, the office of the recovery officer shall, subject to any order made by him. remain opcti daily from 10 a.m. to 6.00 p.m.
but no work, unless, of an urgent nature, shall be admitted af(cr4._1() p.m. on any working day.
(2) The working hours of the office of the recovery officer shall be displayed at prominent place in his office.
17. Sitting hours of the Recovery Officer.—(1) The recovery officer shall regulate Ills own sitting hours.
(2) The sitting hours of the recovery officer shall be displayed at prominent place in his office.
18. Effect of Holiday.—Where the last day for doing any act falls on a day on which the office ofthc recovery
officer is closed and by reason thereof ihe act cannot be done on that day. it may be done on the next day on which that
office opens.
\9. Staff ofthc Recovery Officer.—(1) The approved institution, the officer of which is appointed as the recovery
officer, shall provide the recovery officer with such of its other officers and employees as that institution may think fit.
(2) Such other officers and employees shall discharge their fund ions under the general superintendence ofthc
recovery officer.
20. Seal and emblem.—The official seal and emblem ofthc recovery officer shall be such as the Central Government may specify.
|F.No.7pV2001—CP|
AJ1T M. SHARAN. Ji. Secy. (B&l)
3rfiJtJ9HI

M fcwi, 7 M, 2002
m^T.f*T. 3 4 2 ( 3 T ) . — T r ^ 3 n ^ r a t ^ , T I ^ 3 1 T ^ r a ^ 3 # # n ^ , 1987 ( 1987 ^T 53) qft *m 55 BTCT-STC^njlfrBiqi'

i. Tffijtmtin ^ftnutT—(1)
^ItTTPTfaPiMH,2002 % I
MtyGil/ai-Lj

^faf¥r^^^Tf^^Tn^3mm^(3Tgq^

<!-- page 26 -->

26

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC 3 (i)]

<!-- page 27 -->

27

<!-- page 28 -->

28

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC. 3 (i)]

<!-- page 29 -->

29

<!-- page 30 -->

30

THEGAZETTEOFINDIA: EXTRAORDINARY

[PART II—SEC. 3 (i)]

<!-- page 31 -->

31

<!-- page 32 -->

32

THE GAZfcTltt OF INDIA: EXTRAORDINARY

[PART II—SEC. 3 (i)]

<!-- page 33 -->

33

NATIONAL HOUSING BAN K
NOTIFICATION
New Delhi 7th May. 2(M)2.
G.S.R. 342.—In exercise of the powers conferred by section 55 of the National Housing Bank Act, 1987 (53 of
1987). the National Housing Bank, with Uic previous approval of the Reserve Bank of India and in consultation with the
Central Government, hereby makes the following regulations, nanicly>
1. Short Title anil Commencement.—(1) These regulations may be called the National Housing Bank
(Recovery of Dues of the Approved Institutions) General Regulations. 2002.
(2) They shall come into force on (he date of theirpublication in the Official Gazelle.
2. Definition*.—In these regulations, unless Uic context otherwise requires,^
(a) " A c l " means the National Housing Bank Act, 1987;
(b) "agent" means a person duly authorised by a parly to present application or to give reply on its behalf
to the recovery officer or to the Appellate Tribunal at the case may be:
(c)

"appeal" means an appeal made lo the Appellate Tribunal under section 36S of the Act.

(d)

"appellant"1 means a person or an approved institution making an appeal to Uic Appellate Tribunal under
Section 36S of Uic Act:

(c)

"applicant" means mi approved institution or a person making an application to the recovery officer under
section 3(>E:

(f)

"application" means an application made to the recovery officer under section 3(>E.

(g)

"Registrar" means the Registrar of an appellate Tribunal and includes an officer of such Applellate
Tribunal who is authorised by (he Presiding Officer to function as Registrar.

(h)
(i)
|H!WGj|/Oi-_5

"Registry" means the Registry of the Appellate Tribunal:
all over words and expressions used and not defined in these regulations but defined in the Act shall have
the meanings respectively assigned to them in the Act.

<!-- page 34 -->

34

THE GAZBTIEOFINDIA: EXTRAORDINARY

3.

(PART II—SBC. 3(1)1

Form of application.—Every application to the recovery officer for recovery of dues under section 36E of the
Act shall be in Form No. 1.

4. Documents to accompany the application.—Every application under regulation 3 shall be accompanied by a
paper book containing—
(i)

a statement showing details of the assistance due from a respondent and the circumstances under which
such an assistance has become due;

(ii) all documents relied upon by the applicant and those mentioned in the application:
(Ui) Index of documents: and
(iv) where the parties to the suit orprocecdings are being represented by an agent, documents authorising him
to act as such agent.
5. Form of Notice to the borrower.—A notice of demand to be served on the borrower under sub-section (1) of
section 36F riiall be in Form No. 2.
6. Form of appeal.—Every memorandum of appeal to the Appellate Tribunal under section 36S of the Act shall
be in Form 3.
7. Fee.—The amount of fee payable in respect of appeal under section 36S shall be 1% of the amount due subject
to a minimum of Rs. 2,500/- and a maximum of Rs. 30,000/-.
Procedure in Salex of Immovable Properties
8. Sale and proclamation of Hale.—(1) The recovery officer may direct that any immovable property mortgaged or
assigned to the approved institution as security for any assistance in respect of which default has been made or such
portion thereof as may seem necessary to satisfy the dues of the approved institution together with all costs, charges and
expenses incurred by the recovery officer, shall be sold.
(2) Where any immovable property is ordered to be sold, the recovery officer shall cause a proclamation of the intended
sale to be made in the language of the district where the property is situate.
9. Contents of proclamation.—(1) A proclamation of sale of immovable property shall be drawn up after notice to the
defaulter, and shall specify the time and place of sale, and shall also specify, as fairly and accurately as possible.—
(a) complete description of the property to be sold:
(b) the revenue, if any. assessed upon the property or any part thereof:
(c) any incumbrance, grant or contract to which the property is known to be liable:
(d) the amount for the recovery of which the sale is ordered:
(e) the reserve price, if any. fixed by die recovery officer below which the property may not be sold: and
(f) any other thing which the recovery officer considers it material for a purchaser to know, in order to judge the nature and
value of the property.
(2) .The place of sale specified under sub-regulation (1), shall be cither the office of the recovery officer or some other place
appointed by him in this behalf and situate on or near the property to be sold.
10. Mode of making proclamation.—(1) Every proclamation for the sale of immovable property shall be made at some
place on or near such property by beat of drum or other customary method and a copy of the proclamation shall be affixed
on a conspicuous part of the property and also upon a conspicuous part of the office of the recovery officer,
(2) Where the recover)' officer so directs, such proclamation shall also be published in such other manner including
publication in the local newspaper and the cost of such publication shall be deemed to be the cost of the sale.
11. Time and comduct of Hale;—(1) The sale shall not take place on a Sunday or other holiday, or till after the expiration of
at least thirty days from the date on which the copy of the proclamation was affixed in the office of the recovery officer or
affixed on the property, whichever is later.

<!-- page 35 -->

35
(2) The sale shall be by public auction and shall be conducted either by the recovery officer in person or by a person
specially appointed by him In this behalf, if the recovery officer Is of the opinion that it will be more advantageous to appoint
a person to sell a property.
(3) Where the recovery officer has appointed a person to sell a property, he shall also fix the remuneration of such peron
for such services and the remuneration payable to such person shall be deemed to be costs of the sale.
12. Power to postpone sale.—The recovery officer may from time to time postpone the sale.
13. Stay of sale.—If at any time before the bidding at the auction is completed, the borrower pays, the dues of die approved
institution together with all costs, charges and expenses incurred by the recovery officer in respect of the property which
has been proclaimed for sale, to the Recovery officer or to the person appointed by him for conducting the sale, or proves
to the satisfaction of such person that he has already paid the same to the approved institution . the sale shall be stayed.
14. Payment of deposit by hlghetrt bidder.—When the highest bid at (lie uuction has been ascertained, the person who
made that bid shall, on the requisition of the recovery officer or the person uppoinled by him. al the case may be. conducting
the sale, deposit twenty five per cent, on the amount of his bid. and shall, on deposit thereof, be declared to be the pruchaier
subject to the provisions hereinafter contained:
Provided that no sale under this rule shall be made if the amount of bid by the highest bidder is less than the reserve price,
if any specified under clause (e) of sub regulation (1) of regulation 9.
15. Consequence! of failure to pay deposit—If the person who made the highest bid fails to pay the deposit ai required
by regulation 14. the property shall forthwith be put up again and sold, and all expenses attending the first tale, and the
deficiency of price, if any, which may happen on resale, may be recovered from him by the recovery officer.
16. Time for payment in full.—The full amount of the purchase money shall be paid by the purchaser within fifteen days
of the bid.
17. Procedure in default of payment.—In default of payment of the full amount of the purchase money within the period
mentioned in regulation 16. the deposit referred to in regulation 14 sluill after defraying the expenses of the stile, be forfeited
and be applied in reduction of the dues, and the property shall be resold, and the defaulting purchaser sluill liavo no claim
to the property or to any part of the sum for wheh it may subsequently be sold.
18. Application to set aside Male;—(1) At any time within thirty days from (lie date of the sale, application may bo made to
the Housing Finance Institutions Debt Recovery Appellate Tribunal to set aside the sale on (he ground of some material
irregularity or mistake in publishing or conducting it:
Provided that a sale shall be aside only on the ground that the appellant has sustained injury by reason of such material
irregularity or mistake in non-service of notice requiring the borrower to pay (he dues or in publishing the proclamation or
in the conduct of the sale.
19. Order confirming or netting axlde (talc—(1) After the expiration of thirty days from the dale of the sale, if no
application under regulation 18 has been made, or if such application has been made ;md rejected, the recovery officer shall
make an order confirming the sale. and. if such application has been made and allowed, the recovery officer shall make nn
order setting aside the sale.
(2) An order made under tills regulation shall be final.
20. Refund of purchuxc money on netting aside of Hale—Whenever the sale of any property is sot aside, the purchaser
shall be entitled to receive back his purchase money.
21. Proclamation after poNtponcmcnt or on rctwle—A sale made after a postponement under regulation 12, and a resale
consequent on a purthascr's default under regulation 17 or on the setting aside of a sale under regulation 19. shall be made
after the issue of a fresh proclamation In Uic manner hereinbefore prescribed for the sale.
22. On confirmation of wile ponKciwion und certificate to he granted to purchuMcr—(I) After the sale has been confirmed
in manner aforesaid the recovery officer shall put the person declared lo be the certified purchaser Into possession oflho
property sold, and sluill grant him a certificate to the effect that he has purchased that property.
(2) The certificate shall slate that the property was told for the recovery' of the amount due to an approved institution and
shall set forth the encumbrances, grants, contracts and right of occupany. if any. specified in the proclamation of the wile.
(3) Every certificate granted under sub-regulation (1) sluill bo deemed lo be a document rogistrablo as a conveyance under
the provisions of the Registration Act, 1908 (16 of 1908).
(4) The certified purchaser of any immovable properly sluill be entitled lo all rents and profits falling due In respect of the
property after die date of the confirmation of the sale and be liable for all dues, cess and taxes falling due in respect lujpKof
after that date.

<!-- page 36 -->

36

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART D—SEC. 3 (i)]

Procedure for sale ofA46vahle Property
23. Sale of Moveable Property.—The recovery officer may direct that an moveable propety mortgaged, pledged,
hypothecated or assigned to the approved institution as security for any assistance In respect of which default has been
made or such portion thereof as may seem necessary to satisfy the dues of the approved institution together with all costs,
charges and expenses incurred by the recovery officer, shall be sold.
(2) Where any moveable property is order to be sold, the rcovery officer shall conduct the sale as nearly as may b e , in
accordance with the law for the time being in force for the sale of moveable property for the recovery of arrears of income
tax under the Income tax Act, 1961 (43 of 1961).
24. Proceeds of Sale.—When a sale of immovable or moveable property under these regulations has been confirmed, the
proceeds of the sale shall be applied by the recovery officer in accordance with the provision of section 36G of the National
Housing Bank Act, 1987 (53 of 1987).
25. Save and except the provisions of the regulations herein contained, the recovery officer shall be guided by the
provisions of the Second and Third Schedules to the Income-tax Act, 1961 and the Income-Tax (Certificate Proceedings)
Rules, 1962, as in force from time to time in the matter of sale of the immovable and moveable property.
FORM No. 1
(See Regulation 3)
Application under .lection 36E of the National Housinjj Bank Act, 1!>87.
BEFORETHERECOVERYOFHCER
(Place)
Application No

of.

BETWEEN
(Name ofthe approved institution)

APPLICANT
AND

(Bonuwcr)

RESPONDENT

DETAILS OF APPLICATION:
1 .Particulars of the applicant:—
(i) Name of the applicant:
(il) Address of-Registered Office:
(iii) Address for service of all notices:
2. Particulars of the respondent:—
(i) Name of the respondent:
(ii) Address for service of all notices:
3. Jurisdiction of the Recovery Officer.
The applicant declares that the subject matter of the recover)' of dues falls within the jurisdiction of the Recovery
v officer.
applicant further declares that the application is within the limitation prescribed under the Limitation Act,
1963.
5. Facts of the case:—
(i) The facts of the case are given below:—
(Give here a concise statement of facts in the chronological order, each paragraph containing as nearly as possible a
separate issue, fact or otherwise.)
(ii) Details of security:—
(Giver here description of the property pledged, mortgaged, hypothecated or assigned to the approved institution as
security for the dues.)

<!-- page 37 -->

.17
6. Relief(s) sought:—
In view of the facts mentioned in paragraph 5 above, the applicant pmys that the amount due to it be recovered and
be paid to the applicant by the sale of the property hereinbefore mentioned.
7.

Interim and ad-interiin order, if prayed for:—
Pending fianl decision on the application, the applicant seeks issue of the following order:—
(Give here the nature of the interim and/or ad-interim order prayed for with reasons).

8.

Matter not pending with any other court, etc.:—

The applicant further declares that the matter regarding which thi s application has been made is not pending before
any court of law or any other authority.
9. Details of Index:—
An index in duplicate containing the details of the documents to be relied upon is enclosed.
10. U$t of Enclosures:—
Dated:

(Authorised Official/Agent)
(Approved Institution)
VERIFICATION
Verified that the contents of paras. 1 to 10 arc true to my personal knowledge and belief and that I have not suppressed
any material facts.
Verified at

on this day of.

(Authorised Oflicial/Agent)
For use in Recovery Officer's Office
Date of filling.
Date of receipt by post
or
Registration No

Signature of Recovery Officer

FORM No. 2
(See Regulation 5)
Notice under Section 36F of the National Hnwtinf; Bunk Atf, 1987
To,
(Respondent)
Whereas,
one of the approved institutions under the National Housing Bank Act, 1987 has filed an
application before the undersigned under section 36E( 1) of the said Acl stating that Mr/Ms
borrower, along with
Mr/Ms
as co-borrower, and Mr./Ms
As guarantor borrowed form it a sum of Rs
as assistance on the
basis of security by way of pledge/mortgage/hypothecation/assignment of the property specified below.
And Whereas the above said borrower/s who are under a liablillty to the said approved institution have made default
in repayment and/or otherwise failed to comply with the terms of the agreement and the amount due to the said approved
institution has not yet been paid and accordingly prayed or an order for the sale of the property specified below.

<!-- page 38 -->

38

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC. 3(1)]

Now, therefore, in exercise of the powers undo Section 3 6F of the National Housing Bank Act, 1987 (53 of 1987), you
are hereby cal led upon to pay the amount due to the said approved institution, within a period of ninety days form the date
of service of this notice or to show cause why the relief prayed should not be granted.
Please take notice that in the case of default, necessary order for the sale of the property shall be issued in accordance
with the provisions of the Act and the regulations/rules made thereunder;
A copy of the application filed by the approved institution and paper book are sent herewith.

Description of the property pledged, mortgaged, hypothecated or assigned as security for the d u e s -

Dated:
Seal
(Recovery Officer)
FORM No. 3
(See Regulation 6)
Mcmnnindum of uppad under weetinn 36S of the NutfonuJ Houriag Bunk Act,
1987(53ofl9S7).
For use in the Appellate Tribunal's Office
Date of filing
Date of receipt by post
Registration No
Signature of Registrar
IN THE HOUSING FINANCE INSTITUTION DEBT RECOVERY TRIBUNAL,
(Place)
APPEAL NO.

OF

BETWEEN
APPELLANT
AND
RESPONDENT/S
DETAILS OF APPEAL:
1. Particulars oflhcuppcllant;—

2.

(i)

Nnmcoflhcuppcllanl:

00

Address:

fill)

Address for service of nil notices:

Parliculnrs of the rcspondcnl/s:—
(i)

Niimcofthcrespondent/s:

<!-- page 39 -->

39

01)
3.

Address for service of alt notices:

Jurisdiction of the Appellate Tribunal.
The appellant declares that the subject-matter of the appeal falls within the jurisdiction of the Appellate Tribunal.

4.

Limitation:—
The appeal is against the order of the Recovery Officer dated
and the appellant declares that the appeal is
within the limitation prescribed in Sub-section (2) of section 36S of the National Housing Bank Act, 1987 (53 of 1987).

5.

Facts of the case and the orders passed by the recovery officer:—
The facts of the case are given below :—
(Give here a concise statement of facts and
grounds of appeal against the specific order of
the Recovery Officer in a chronological order, each
paragraph containing as nearly as possible a
separate issue, fact or otherwise.)

6.

Relief(s) sought :—
In view of the facts mentioned hi paragraph 3 above, the appellant prays for the following relief(s):—
[specifiy below the relief(s) sought explaining the grounds for relief(s) and the legal provisions (if any) relied
upon.]

7.

Interim and/or ad-intcrim order, if prayed for:—
Pending hearing and final decision on the appeal, the appellant seeks issue of the following order:—
(Give here the nature of the interim and/or ad-interim order prayed for with reasons).

8.

Matter not pending with any other court, Tribunal etc.:—
The appellant further declares that the matter regarding which this appeal has been made is not pending before
any court of law or any other authority or any other Tribunal.

9.

10.

Particulars of bank draft in respect of the deposit of amount due in terms of section 36T of the Act:
(a)

Name of the bank on which drawn

(b)

Demand draft number.

Particulars of bank draft/postal order in respect of the fee paid in terms of regulation 7 of these Regulations:—
(a)

Name of the bank on which drawn

(b)

Demand draft number
OR

11.

(a)

Number of Indian Postal Order(s)

(b)

Name of the issuing Post Office

(c)

Date of issue of Postal Orders)

(d)

Post Office at which payable

Details of Index:—
An index in duplicate containing the details of the documents to be relied upon is enclosed.

12.

List of Enclosures:—

Dated:

(Appellant)

<!-- page 40 -->

40

THE GAZETTE OF INDIA: EXTRAORDINARY

[PART II—SEC, 3 (i)]

VERIFICATION
Verified that the contents of paras 1 to 11 are true to my personal knowledge and belief and that I have not
suppressed any materials facts.
Verified at

on this day of

(Appellant)
To,
The Registrar.

[FlIeNo. NHB/LD/2A/2OO1]
By the Orders of the Board
SHEKHAR AGARW AL,
Chairman & Managing Director
National Housing Bank

Printed by the Manager, Ctovl, of Indin Pri!nu. Iting Roiid. Muyiipuri. New Dtlhi-110064
and Puhltihed hy the Controller nl' Publication*. Delhi-1 10054.
