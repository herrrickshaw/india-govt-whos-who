---
doc_id: "1a90b66ecdcabd16"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/35f3e2267ae4c27ed18d28ab2624d051.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction Order dated 28th December 2023 Release of an amount of Rs 21,02,68,386/"
date: "2025-07-14"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8b119299a0b8ffc2"
---

<!-- page 1 -->

No. 3(2)/2021-SSS (E.55244)
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade
(Special Scheme Section)
Udyog Bhawan, New Delhi

Dated: 28" December, 2023
To
The Accounts Officer,

Pay & Accounts Office,
Department for Promotion of Industry & Internal Trade,
Udyog Bhawan,
New Delhi.
Sub:

Release of an amount of Rs. 21,02,68,386/-

Sixty Eight

(Rs. Twenty

One

Thousand

Three

Hundred

Eighty

Six only) as Central

to

credit

(CCIIAC)

Subsidy

during

Incentive for access
SIIDCUL-reg.

the

year,

Crores Two

Capital

2023-24

Lakhs

Investment
in

favour

of

Sir,

The undersigned is directed to convey sanction of the President to the release of an
amount of Rs. 21,02,68,386/- (Rs. Twenty

One Crores Two

Lakhs

Sixty Eight Thousand

Three Hundred Eighty Six only) for payment of Central Capital Investment Incentive for
access to credit (CCIIAC) under Industrial Development Scheme (IDS) 2017 for the financial
year 2023-24 in respect of 14 eligible beneficiary units of Uttarakhand (as per list enclosed at
Annexure),

on the basis of recommendations of the State Level Committee concerned and as

per existing terms and conditions of the scheme.

As per the Notification No.2(2)/2018-SPS dated 23" April,2018, SIIDCUL has been
2%
notified as the nodal agency for disbursal of central incentives in the state of Uttarakhand
under IDS, 2017.

33

Vide mail dated 02.08.2023, SIIDCUL informed that no unspent amount is pending of

disbursement under the IDS, 2017.

The sanctioned amount may be released in favour of State Infrastructure & Industrial
4.
Development Corporation of Uttarakhand Ltd.(SIIDCUL), Dehradun to their Bank Account
No0.705020110000513,

Name

of Account

SIIDCUL

(IDS),

Bank

of India,

Main

Branch,

Dehradun MICR Code: 248013002. IFSC/RTGS Code BKID0007050.

5.

The due date for submission of UC in respect of this release is within twelve months of the

closure of the financial year.

6.

The total release under this object head would be Rs. 266,02,68,386/- including present

sanction during the current financial year 2023-24.

e

PIISID KA Ay

T
site g ¥
F / Director
Y
Slln vai aﬁi;?;"f;'galm.msnry oy"%o/mén ALK

R ey
el<Pl
vy
i /GO of- 11 el

Vanuya

hawan, Ney
Delhr??%ﬂm

<!-- page 2 -->

2The expenditure is debit to the following Head of Account:2885
02
02.101 18.01 —

Other Outlay on Industries & Minerals (Major Head)
Development of Backward Areas (Sub Major Head)
Subsidies (Minor Head)
Industrial Development Scheme for the States of Himachal Pradesh and

Uttarakhand, 2017
18.01.33
Subsidies
Under Demand No.11 for the year, 2023-24.

Release of the above-mentioned amount to SIIDCUL is subject to the following terms
8.
and conditions:
SIIDCUL
towards

will maintain a separate account of the funds released by this Department
“Central

Capital

Investment

Incentive

for access

to credit (CCIIAC)

under

Industrial Development Scheme (IDS) 2017” for disbursal of subsidy to the beneficiary
units as per details enclosed.

ii.

SIIDCUL shall verify each & every claim before disbursement and shall disburse the
incentive to the eligible units immediately on receipt funds from DPIIT.

iii.

The disbursal made by SIHIDCUL from the Grant shall be open to inspection and audit by
the sanctioning authority.
After disbursement of incentive for the purpose for which

it has been

sanctioned,

SIIDCUL, shall submit to the Department for Promotion of Industry & Internal Trade,

New Delhi the Utilization certificate within twelve months of the closure of the
financial year as per GFR,2017 and no further funds will be released unless the entire
amount previously released is fully utilized and utilization certificates are furnished. The
Utilization Certificate will be signed by the Managing Director, SIIDCUL.
A quarterly statement of the subsidies disbursed indicating also the names of the
beneficiaries, the amount of subsidy released to each unit, the date of their application,
the date of approval of the SLC, the date of disbursal of subsidy etc, shall be furnished

by SIIDCUL to this Department by the 10" day of the month following the end of each

quarter.
Vi

SIIDCUL would devise a suitable mechanism to ensure adequate transparency and
fairness in the disbursal of subsidy. SIIDCUL shall furnish an undertaking that they have
been following the provision of Rule-4 (I)(a) and (b) of RTI Act, 2005.

vii.

SIIDCUL

would

furnish a performance-cum-achievement

report at the end of each

financial year highlighting the number of units set up in the State, investment made and

the

employment

generated

etc., and

the quantitative

vis-a-vis

qualitative

outcome

achieved out of Central Capital Investment Incentive for access to credit (CCIIAC)
under Industrial Development Scheme (IDS) 2017 Scheme including suggestions/policy

reform initiatives for further refinement of the Scheme.

viii.

SIIDCUL

that
to ensure that amount is released to individual unit(s) only after verifying

these units have not been paid earlier.

e

i, Prre [ Dr. KAJAL
G
Pl lDlrec‘\uCV 8 i
P Beptt for
afR S A [ MinistryO

iR AR
Gow. of ndz
A
o N
i
-

110001

St

<!-- page 3 -->

&
SIIDCUL to ensure that payment to beneficiaries units should be made through PFMS
directly to their account within 10 days from receipt of funds from DPIIT.

ix.

Shri Arun Kumar Vishwakarma, Under Secretary will act as DDO for purpose of this
O
sanction.
This issues with the concurrence of AS&FA vide Note# 105 dated 07.12.2023.
10.

Yours faithfully,

Copy to:-.

1.

The Principal Director of Audit, Economic and Services Ministries, A.G.C.R. Building,
Indraprastha Estate, New Delhi.

2.

Director of Industries, Directorate of Industries, Govt. of Uttarakhand.

3.

Finance-II Section, Integrated Finance Wing, Department for Promotion of Industry &
Internal Trade.

4.

CCA, DIPP-with the request to audit 10% cases after disbursement by SIIDCUL.

5.

The Managing Director, SIIDCUL

6.

Budget & Accounts Section.

<!-- page 4 -->

4Annexure

No. 3(2)/2021-SSS (E.55244)

Dated: 28.12.2023

List of 14 Units
SI. | Name
of the Unit
NO.

1
1

| Claim registration | Amount | Amount | Amount
No.
Approved | objected | Approved

by SLC
3
4
IDS/UK/2019/0071 | 6269934
dated 18.03.2019
| IDS/UK/2019/313 | 3759369
dated 06.11.2019
AUTO | IDS/UK/2020/644 | 8290358

2

2
WELKIN
OVERSEAS
DHANIRESORT

8

VEGA

| by IPAI
5
| NIL

6
6269934

| NIL

3759369

| NIL

8290358

ACCESSORIES
PVTLTD

dated 30.09.2020

4

TRIKUTA
ENTERPRISES

IDS/UK/2020/177 | 5931950
dated 30.09.2020

| NIL

5931950

5)

KUNSTOPLAST
INDIA LIMITED

IDS/UK/2020/906
dated 18.12.2020

| 6491530

| NIL

6491530

6

TULBROS

IDS/UK/2020/717

| 3304963

| NIL

3304963

7

FORMULATIONS
PASHUPATI

| dated 29.09.2020
IDS/UK/2019/0075 | 50000000

| NIL

50000000

| NIL

34244684

8

POLYTEX

dated 26.03.2019

PRIVATE
LIMITED
RAJLAKSHMI

IDS/UK/2020/903

PAPER

| 34244684

AND | dated 29.09.2020

BOARD PRIVATE
LIMITED

9

KASHI
IDS/UK/2019/107 | 7025095 | NIL
ENTERPRISES
dated 29.08.2019
10 | HSN
IDS/UK/2020/302 | 11396941 | 330003
INTERNATIONAL | dated 18.12.2020
11 | Hotel Maplewood | IDS/UK/2019/0019 | 3271647 | NIL
dated 27.02.2019

12

13

14

| PASHUPATI

IDS/UK/2019/0052 | 16126702

| 11066938
3271647

| NIL

16126702

| NIL

4485216

IDS/UK/2020/294 | 50000000 | NIL

50000000

LAMINATORS

dated 18.03.2019

PRIVATE
LIMITED
| CHARMINAR
POLYMERS

IDS/UK/2020/456
dated 29.09.2020

| KATYAYINI
PAPER
PRIVATE
LIMITED

7025095

| 4485216

MILLS | dated 29.09.2020

Total

210268386
Hokkokokok

e, 7 (ee-110001
T

Kiew Delhi- 110001
