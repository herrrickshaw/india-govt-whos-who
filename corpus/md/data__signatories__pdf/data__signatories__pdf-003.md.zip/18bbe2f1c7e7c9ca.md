---
doc_id: "18bbe2f1c7e7c9ca"
source_url: "https://morth.gov.in/backend/documents/uploaded/1732-36.pdf"
ministry: "Road Transport and Highways (MoRTH)"
title: "Construction of 4 lane with paved shoulder of Gurugram-Alwar road (NH-248A) section from Nuh to Ferozepur Jhirka upto Rajasthan Border [From Km. 46.95 to 95.97(Design Ch.96.980) excluding km.50.900 to 54.46 & 61.900 to 65.18] and strengthening / improvement of existing road in 6.84 km length in Mala"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "400cb0f2748604b0"
---

<!-- page 1 -->

-

0172-2743228, 2740376

freT: rochandigarh2010@gmail.com
/Govt. of India
of Road Transport & Highways

Regional Office, Kendriya Sadan, 6th Floor, Sector-9 A, Chandigarh-160009
No.

(+32-36

Dated:

20.11.2025

Meeting Notice
Subject: Construction of 4 lane with paved shoulder of Gurugram - Alwar road (NH-248A)

section from Nuh to Ferozepur Jhirka upto Rajasthan Border [From Km. 46.95 to
95.97(Design Ch.96.980) excluding km.50.900 to 54.46 & 61.900 to 65.18] and
strengthening / improvement of existing road in 6.84 km length in Malab
village(km.50.900 to km.54.46) and Bhadas village(km.61.900 to 65.18 ) in Nuh District
of Haryana State on EPC mode.
This is to inform that second meeting of Evaluation Committee will be held on
28.11.2025 at 04:30 PM in the Room No. 136, 1st Floor, Transport Bhawan, New Delhi 110001 for the evaluation of Technical Bids of prospective bidders for the subject work. The
bid documents and draft evaluation sheet is also enclosed.
2.

It is requested to kindly make it convenient to attend the above meeting.

Executive

ngineer

For RO-M0RT&H Jaipur

To:
(i) Shri Rananjay Singh, Chief Engineer (N-l)

: Chairman
(ii) Shri Praveen Choudhry, Chief Engineer (NH), Haryana PWD : Member
(iii) Shri L. Behera, SE (NER), MoRTH
Member
(iv) Representative of IFD
: Member
(v) Shri Gargi Singh, Executive Engineer, RO CHD
Member secretary
•
