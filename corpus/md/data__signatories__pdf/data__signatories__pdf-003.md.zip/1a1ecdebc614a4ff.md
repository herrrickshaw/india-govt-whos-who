---
doc_id: "1a1ecdebc614a4ff"
source_url: "https://mohua.gov.in/static/uploads/2025/10/fffe3c4572ac6dd491b96f60c3043da0.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Guidelines on Branding"
date: "2025-10-29"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "978d13d69ce6d275"
---

<!-- page 1 -->

Branding and Communication Guidelines

PM Street Vendor’s AtmaNirbhar Nidhi
(PM SVANidhi)

A Special Micro-Credit Facility for Street Vendors

<!-- page 2 -->

PM Street Vendor’s
AtmaNirbhar Nidhi

(PM SVANidhi)
A Special Micro-Credit Facility
Scheme for Street Vendors

1. Introduction
PM SVANidhi, A Special Micro-Credit
Facility launched by Ministry of Housing
and Urban Affairs, for providing affordable
loan to street vendors, targets to benefit
over 50 lakh Street Vendors.

2. P
 urpose of Branding and
Communication Guidelines
The purpose of these guidelines is to ensure
standardisation in the overall messaging of
the Scheme and effective engagement with
the target beneficiaries.

3. K
 ey Messaging of the Scheme
a. For the first time:
i. Street vendors belonging to the
surrounding peri-urban/ rural areas are
being included as beneficiaries
ii. MFIs/ NBFCs/ SHG Banks have been
allowed for the first time due to their
ground level presence and proximity
to the urban poor including the street
vendors.
b. Working capital loan of up to `10,000/to resume livelihoods post COVID-19
lockdown
c. Incentivizing timely repayments by
providing
i. 7% interest subsidy
ii. Eligibility for higher loan in next cycle

d. Incentivising digital transactions
through cash back (Up to `1,200 cash
back for conducting digital transactions
in a year)
e. P
 rovision of Free QR code and
handholding at the Vending Stall
f. M
 obile App/web based loan application
process
g. Wider Base of lending Institutions
including Commercial and other Banks,
MFIs, NBFCs and SHG Banks
h. G
 raded Credit Guarantee for lending
institutions under CGTMSE

4. Target Audience of
the Branding and
Communication campaign
Street Vendors, ULBs, TVCs, SHGs and
their Federations, Financial Institutions
(including Lending Institutions and
Payment Aggregators), Policy Makers and
General Public.

<!-- page 3 -->

5. V
 ehicles of Communication:
A) O
 utdoor Media
A standard creative
(Annexure-I) of the hoardings
and Standees (in Hindi) has
been shared with the States/UTs who, in
turn, will place these at strategic locations.
The hoardings and standees may be
translated into the regional language,
wherever required. A high resolution file
of the creatives will be shared with the
States/UTs.
B) Standard Capacity Building Modules
(PPT) for Capacity Building of ULB
functionaries and other stakeholders
Power Point Presentations
with voice-over (English and
Hindi) will be shared that
can be used for the capacity
building of various stakeholders. These will
be very helpful in the kick-start meetings.
One of the PPTs will be a generic
presentation on the overall scheme and
others will highlight the specific roles and
responsibilities of different stakeholders.
The PPTs including voice-overs may
be translated into regional languages
for easier understanding and wider
dissemination.
C) Films
Two films also will be shared
for sensitisation of ULB
functionaries and capacity
building of the street vendors. These films
are also available on websites of MoHUA,
PM SVANidhi and DAY-NULM.

D) W
 ebsite
A dedicated website
(pmsvanidhi.mohua.gov.
in) along with a mobile App
for the Scheme has been
developed. It will serve as the central
repository of all the relevant information
including communications sent to the
States/ UTs, branding materials, capacity
building modules and other relevant
materials.
A special section on demo tutorials
and capacity building modules on
loan application processes and role of
various stakeholders has been created
in the website, to provide for an easy to
understand and interactive content for the
users.
E) Social Media
The social media handle
of MoHUA will be used
for popularising PM
SVANidhi. States and
ULBs may, however,
develop their own handles for sharing of
success stories, events and best practices.
While posting from respective State/ ULB
handles, it is encouraged to use the #
PMSVANidhi and also tag MoHUA_India
and other handles of the Ministry of
Housing and Urban Affairs.

<!-- page 4 -->

F) Digital Advertisements
Innovative and engaging
digital advertisements on
websites of Street Vendors
Associations, SIDBI, Udyami
Mitra Portal etc. and other relevant
websites will be undertaken at National
Level. States/ UTs may also advertise
information related to PM SVANidhi on
their respective websites.
G) Newspaper advertisements
Periodic advertisements
in newspapers at national
and regional level will be
undertaken.
H) Printed Collaterals
Printed collaterals included
scheme guidelines, Frequently
Asked Questions (FAQs),
leaflets etc. have been shared
with the States/ UTs for wider
consumption. These are also
shared on MoHUA website. The states are
encouraged to translate the same in local
languages, wherever required.
I) Radio Jingles
A Pan India radio campaign
on PM SVANidhi will be run
by the MoHUA. The radio jingles, in Hindi
and regional languages will also be shared
with the States/ UTs so that they can
promote the same through various local
media, wherever required.
J) Success Stories
Besides sharing details of
the regular events, States are
requested to share quality

success stories as per the format given
at Annexure II once in every 15 days (3
stories per state along with high resolution
photos). Collating and promoting these
success stories through various platforms
including YouTube, social media etc. will
be undertaken and compiled as a Coffee
Table Book at the national level.
A webinar may be organised with States/
UTs on standardisation of branding
and communication guidelines. Similar
webinars with ULBs may be undertaken
the States/ UTs. Specific Dos and Don’ts
are at Annexure-III.
6. Role of States/UTs and ULBs:
It is expected that States/ UTs would
adopt/ use the best possible mediums
of communications addressing aspects
such as cost effectiveness, innovativeness
and engagement of the target group. The
indicative roles of the State/ UTs/ ULBs are
given below:
I. Translation in of IEC material into
regional languages and wide
dissemination.
II. P
 lacing the hoardings at strategic
locations.
III. Standees to be placed at the most
popular office premises, City Livelihood
Centres, Common Service Centres and
offices of Lending Institutions etc.
IV. Effective use of local media like
community radio, advertisements,
regional news networks and others
platforms.
V. U
 LBs will facilitate organisation
of various programmes to enable
direct interaction of the Banking
Correspondents and Agents of
the lending institutions with the
beneficiaries.

<!-- page 5 -->

Annexure I

Options for Hoardings and Standees

<!-- page 6 -->

Annexure II

Format for Documenting Success Stories
1. Name
2. Address and contact number
3. Situation Before the Intervention
4. Situation after the Intervention
5. Key Message from the Beneficiary (exact words to be quoted)

States/UTs to share only two -three selected stories with Ministry on fortnightly basis.

<!-- page 7 -->

Annexure III

Specific DOs and DON’Ts
1. Colour scheme:
a) T
 o ensure uniformity in the branding across different mediums, the colour scheme as
that of hoardings and guideline may be followed.
2. Photographs:
a) It is intended to have a rich repository of high resolution photographs. A mechanism
will be institutionalised where States/ UTs can share high resolution photos. The
process for this will be communicated in due course.
b) S
 tates can also organise youth engagement programmes involving local media.
c) A
 capacity building session specifically on photo and video documentation will be
organised to ensure quality outputs.
d) D
 Os and DON’T’s for beneficiary testimonies and photographs are given below:

DOs
•T
 he beneficiary should introduce herself/ himself, specify the name of the City and State that
s/he belongs to.
•T
 he beneficiary should mention about how s/he came to know about PM SVANidhi.

Beneficiary Video
Testimonies

•T
 he beneficiary should explain about her/ his life transforming experience. Some of the key
factors to be elaborated by the beneficiary may include freedom from usurious interest burden of loan from informal sources, dignified living, increased self-esteem, sense of pride and
dignity, and improved social status
• The Video file must be of HD quality.
DON’Ts
• The audio and video quality should not have blur effects or background sounds.
• The video should be recorded professionally giving a complete frame of the beneficiary. Half
frame should be avoided.
DOs

Photo Documentation

• Photographs should be captured with a Full Frame Camera / DSLR and the picture should
be of high resolution (minimum 2 MB file size).
DON’T’s
• A Half Frame photograph should not be captured.
• Pictures should not be photographed when exposure of light is low.

<!-- page 8 -->

Website: mohua.gov.in • Email: dir-nulm@gov.in
