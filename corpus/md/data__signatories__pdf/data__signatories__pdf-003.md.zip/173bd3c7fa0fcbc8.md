---
doc_id: "173bd3c7fa0fcbc8"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/3ccac7b325d2242add2630001edb1274.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Personal Protective Equipment Footwear (Quality Control) Amendment Order, 2021"
date: "2025-07-04"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "dd0bbd5a72a2b4bb"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-30062021-228024
xxxGIDExxx
CG-DL-E-30062021-228024

ऄसाधारण
EXTRAORDINARY
भाग II—खण्ड 3—ईप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 2456]
No. 2456]

नइ ददल्ली, बुधवार, िून 30, 2021/अर्ाढ़ 9, 1943
NEW DELHI, WEDNESDAY, JUNE 30, 2021/ASHADHA 9, 1943

वाजणज्य और ईद्योग मंत्रालय
(ईद्योग संवधधन और अंतररक व्यापार जवभाग)

अदेि
नइ ददल्ली, 30 िून, 2021
का.अ. 2647(ऄ).—भारतीय मानक ब्यूरो ऄजधजनयम, 2016 (2016 का 11) की धारा 25 की ईप-धारा (3) के
साथ परित धारा 16 की ईप-धारा (1) और (2) द्वारा प्रदत्त िजियों का ईपयोग करते हुए, भारतीय मानक ब्यूरो से
परामिध करने के पश्चात कें द्र सरकार की राय है दक ऐसा करना लोकजहत में अवश्यक ऄथवा समीचीन है, ऄत: एतद्द्वारा
वैयजिक सुरक्षा ईपकरण - फु टजवयर (गुणवत्ता जनयंत्रण) अदेि, 2020 में संिोधन करने के जलए जनम्नजलजखत अदेि
करती है, नामतः 1. संजक्षप्त िीर्धक और प्रारंभ- (1) आस अदेि को वैयजिक सुरक्षा ईपकरण - फु टजवयर (गुणवत्ता जनयंत्रण) संिोधन अदेि,
2021 कहा िायेगा ।
(2) यह रािपत्र में प्रकािन की तारीख से प्रभावी होगा।
2. वैयजिक सुरक्षा ईपकरण - फु टजवयर (गुणवत्ता जनयंत्रण) अदेि, 2020 में पैरा 1 के ईप-पैरा (2) को जनम्नजलजखत
ईप-पैरा से प्रजतस्ट्थाजपत दकया िायेगा:“(2) यह अदेि ददनांक 1 िनवरी, 2022 से प्रभावी होगा।”
[फा. सं. पी-27025/4/2020-चमड़ा]
वंदना कु मार, संयुक्त सजचव
नोट : यह प्रमुख अदेि का. अ. 3857(ऄ), ददनांक 27 ऄक्टू बर 2020 तथा संिोजधत का.अ. 4377 (ऄ), ददनांक
4 ददसंबर 2020 के िररये ददनांक 28 ऄक्टू बर, 2020 को भारत के रािपत्र, ऄसाधारण, भाग-II, खंड-3,
ईप-खंड (ii) में प्रकाजित हुअ था।
3633 GI/2021

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 30th June, 2021
S.O. 2647(E).—In exercise of the powers conferred by sub-sections (1) and (2) of section 16 read
with sub-section (3) of section 25 of the Bureau of Indian Standards Act, 2016 (11 of 2016), the Central
Government, after Consulting the Bureau, is of the opinion that it is necessary or expedient so to do in the
public interest, hereby makes the following Order further to amend the Personal Protective EquipmentFootwear (Quality Control) Order, 2020, namely: 1. Short title and commencement– (1) This Order may be called Personal Protective Equipment-Footwear
(Quality Control) Amendment Order, 2021.
(2) It shall come into force from the date of its publication in the Official Gazette.
2. In the Personal Protective Equipment-Footwear (Quality Control) Order, 2020, in Paragraph 1, for subparagraph (2), the following sub-paragraph shall be substituted, namely: ―(2) It shall come into force with effect from 1st January, 2022.‖
[F. No. P-27025/4/2020 - Leather]
VANDANA KUMAR, Jt. Secy.
Note: The Principal order was published in the Gazette of India, Extraordinary, Part II, Section 3, Subsection (ii) dated the 28 October, 2020 vide number S.O. 3857 (E), dated the 27th October, 2020 and
amended vide number S.O. 4377 (E) dated the 4th December, 2020.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by ALOK KUMAR
and Published by the Controller of Publications, Delhi-110054.
ALOK KUMAR Digitally
Date: 2021.06.30 22:04:32 +05'30'
