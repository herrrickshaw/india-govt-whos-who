---
doc_id: "179aac6dbbf8cd99"
source_url: "https://mnre.gov.in/static/uploads/2025/07/b4a44ab1600515ea461e5d25a3eb3ad2.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "ALMM Order : Amendment – reg."
date: "2024-03-22"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f2d2483d2478272"
---

<!-- page 1 -->

F. No. 283/28/2023 - GRID SOLAR/ Pt
tfTttT TRqTTt / Government of India

_

HINT 3a{qdtTWfh

aaf H3Tdq/Ministry of New & Renewable Energy
f#S©T3igf gym / Grid Solar Power Division
Atal Akshay Urja Bhawan,
Lodhi Road, New Delhi – 110003
Dated: 22nd March, 2024
OFFICE MEMORANDUM

Sub: Approved Models and Manufacturers of Solar Photovoltaic Modules (Requirements for Compulsory
Registration) Order, 2019: Amendment - reg.
1.

With reference to the Approved Models and Manufacturers of Solar Photovoltaic Modules (Requirements
For Compulsory Registration) Order, 2019 dated 02.01.2019 and subsequent amendments & clarifications

thereto and Guidelines for enlistment under the said Order, the undersigned is directed to convey that on
10.05.2023, MNRE had issued certain reforms in Approved List of Models and Manufacturers (ALNIM) in
which sub-clause 1.5.1 under clause 1.5, inter-alia included introduction of following end-use categorywise rninimum module efficiency thresholds for enlistment in ALMh4:
Utility / Grid Scale Power Plants

20.00 %

Rooftop and Solar Pumping

19.50 %
19.00 %

Solar Lighting

2. W.r.t. above, the undersigned is directed to convey that the sub-clause 1.5.1 under clause 1.5 of the reforms
issued by MNRE on 10.05.2023, regarding the end-use category-wise minimum module efficiency
thresholds for enlistment in ALMM, hereby stands modified as follows:
1.5.1 Only such models of Solar PV Module Manufacturers, will be eligible for enlistment under ALMM,
which comply with the BIS Standards and are having the following minimum module efficiauy:

Application/ Use

Module Efficiency required to be eligible for

enlistment in ALMM for solar PV modules
For

c

technology based Solar PV I Thin
Modules

3.

/

Grid

Film

technology

based solar PV modules
19,00%

Categoly-I

Utility

Scale

Category-II

Rooftop and
Pumping

19,5%

18,50%

Category-III

Solar Lighting

19.0%

18,00%

Power Plants

This issues with the approval of Hon’ble Minister (Power & NRE).

-;W

(Sanjay G. Karndhar)
Scientist-E
Email: karndhar.sg@nic.in
To: All concerned

Copy to: Director (Technical), NIC, MNRE, for uploading on MNRE Website
