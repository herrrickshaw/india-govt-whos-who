---
doc_id: "1bcabe2d0cebb280"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/b60d1450f4444c72f90b142d8f1994b0.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Minutes of the 12th Standing Committee Meeting held on 03.09.2021"
date: "2025-07-03"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a2c52c264556286e"
---

<!-- page 1 -->

594
594

366883/2021/BE-II
366883/2021/BE-II

No. P-45021/66/2021-BE-II
P-45021/66/2021-BE-II (E-56091)
India
Government of India
Ministry of Commerce and
and Industry
Department for Promotion
Promotion of Industry and Internal
Internal Trade
(Public Procurement Division)

OFFICE
MEMORANDUM
OFFICE MEMORANDUM

Udyog Bhawan
Bhawan,, New Delhi
Dated
Dated:: September 10, 2021
2021

Subject: Minutes
Minutes of
12th Meeting
Subject:
of 12th
Meeting of
of Standing
Standing Committee
on 03.09.2021
03.09.2021 at
Committee held
held on
at
3.00
the chairmanship
3.00 PM
PM under
under the
chairmanship of
of Secretary,
Secretary, DPIIT
DPIIT to
the implementation
implementation
to review
review the
of Public
(Preference to
to Make
of
Public Procurement
Procurement (Preference
Make in
in India)
India) Order,
Order, 2017-reg.
2017-reg.

The undersigned
undersigned is directed to forward minutes of 1
12
ih Meeting of Standing
Committee through Video Conference held
held under the chairmanship
chairmanship of Secretary, DPIIT
at 3:00PM on 03
.09 .2021 for necessary action and
03.09.2021
and sending action taken report to this
Department
(Email
IDs
pps-dipp@gov.in,,
rajesh.gupta66@gov.in,
pps-dipp@gov.in
rajesh
.gupta66@gov.in ,
ra
kesh .kumar72@gov.in) on priority.
rakesh.kumar72@gov.in)
priority.

2.

This issues with the approval of the Competent Authority.
Authority.

Encl:
SCM..
Encl: Minutes of 1ih
12� SCM

1--1/.
2se
iERI.

(Prrt:fm/~l% ar)
Under Secretary to Government of India
India
Email
pritam .k@gov.in
Email :: pritam.k@gov.in
011-23061306

<!-- page 2 -->

366883/2021/BE-II
366883/2021 /B E-11

To :
To:
New Delhi
Marg , New
Rafi Marg,
Rail Bhawan
Railway
Delhi [email:
[email:
Board,, Rail
Bhawan,, Rafi
Railway Board
.railnet.gov.in]
crb@rb
crb@rb.railnet.gov.in]
New Delhi
Shastri Bhawan
of Pharmaceuticals,
Secretary, Department
Bhawan,, New
Pharmaceuticals, Shastri
Department of
2. Secretary,
Delhi secy-pharma@nic.in]
{email : secy-pharma@nic.in]
110001
110001.. {email:
Nikatan ,
Electronics Nikatan,
Information Technology,
Technology, Electronics
& Information
of Electronics
Ministry of
Secretary, Ministry
3.
Electronics &
3. Secretary,
secretary@meity.gov.in]
[email: secretary@meity.gov.in]
New Delhi
Road New
CGO Complex,
6
Complex, Lodhi
Lodhi Road
Delhi [email:
6 CGO
Sanchar
210 , Sanchar
ications , Room
of Telecommun
4. Secretary,
Department of
Telecommunications,
Room No.
Secretary, Department
No. 210,
4.
[email:secy-dot@nic.in]
- 110001
110001,, [email:secy-dot@nic.in]
Bhawan
Bhawan,, Rafi
Delhi Rafi Marg
New Delhi
Marg,, New
[email :
of Heavy
Secretary, Ministry
5. Secretary,
Heavy Industries,
Industries, Udyog
Ministry of
Udyog Bhawan
Bhawan,, New
Delhi,, [email:
New Delhi
shioff@nic.in]
shioff@nic.in]
Dr.Rajendra
Bhawan . Dr.Rajendra
Shastri Bhawan.
Ministry of
Secretary, Ministry
6. Secretary,
Petroleum and
and Natural
Natural Gas,
of Petroleum
Gas, Shastri
[email : sec.png@nic.in]
Road, New
Prasad
sec.png@nic.in]
Delhi [email:
Prasad Road,
New Delhi
Shastri Bhawan
New
Bhawan,, New
Petrochemicals,, Shastri
&
& Petrochemicals
Chemicals
of
Department
Department
of
Chemicals
7. Secretary,
Secretary,
Delhi
sec.cpc@nic.in]
Delhi,, [email:
[email: sec.cpc@nic.in]
Delhi
New Delhi
Bhawan , New
Nirman Bhawan,
Affairs , Nirman
& Urban
Urban Affairs,
of Housing
Secretary, Ministry
Housing &
Ministry of
8. Secretary,
secyurban@nic.in]
[email:
[email : secyurban@nic.in]
secy[email: secy­
Bhawan , New
Textiles , Udyog
of Textiles,
Ministry of
9. Secretary,
New Delhi
Delhi [email:
Udyog Bhawan,
Secretary, Ministry
textiles@nic.in]
texti les@n ic.in]
Delhi
New Delhi
Street, New
Parliament Street,
Transport Bhawan
Shipping , Transport
of Shipping,
Ministry of
Bhawan,, Parliament
Secretary, Ministry
10. Secretary,
secyship@nic.in]
[email:
[email : secyship@nic.in]
defsecy@nic.in,,
Email :: defsecy@nic.in
Delhi. Email
New Delhi.
Block, New
-A, South
Defence Staff,
Chief of
11.
Staff, 101
11. Chief
South Block,
101-A,
of Defence
cds.sectt@gov.in;;
cds.sectt@gov.in
South Block,
of Defence
Secretary, Department
12.
Department of
Defence Production
12. Secretary,
Production,, 136,
136, South
Block, New
New Delhi
Delhi sdpns@nic.in]
[email :: sdpns@nic.in]
110001 [email
110001
secy[email : secy­
Delhi [email:
New Delhi
Bhawan , New
of Power,
Secretary, Ministry
13.
Ministry of
Power, Shram
Shram Shakti
13. Secretary,
Shakti Bhawan,
power@nic.in]
power@nic.in]
Road ,
Lodhi Road,
Energy, CGO
Renewable Energy,
and Renewable
of New
Ministry of
14.
Secretary, Ministry
14. Secretary,
Complex, Lodhi
New and
CGO Complex,
secy-mnre@nic.in]
[email: secy-mnre@nic.in]
Delhi [email:
New Delhi
New
Airport,
Safdarganj Airport,
Bhawan , Safdarganj
Gandhi Bhawan,
Aviation, Rajiv
Civil Aviation,
Rajiv Gandhi
Ministry of
of Civil
15. Secretary,
Secretary, Ministry
15.
Delh i [email
secy.moca@nic.in]
[email:: secy.moca@nic.in]
New Delhi
New
Delhi
New Delhi
Road New
Azad Road
Maulana Azad
Dr. Maulana
Steel , Udyog
Ministry of
Secretary, Ministry
Udyog Bhawan
Bhawan,, Dr.
of Steel,
16. Secretary,
:secy-steel@nic.in]
[email:secy-steel@nic.in]
[email
secyShastri Bhawan
of Mines,
Secretary, Ministry
17.
Ministry of
Mines, Shastri
New Delhi
Delhi [email
17. Secretary,
Bhawan,, New
[email:: secy­
mines@nic.in
mines@nic.in
Raj
&Fertilizers , Dr.
Chemicals &Fertilizers,
of Chemicals
Ministry of
Fertilizers , Ministry
of Fertilizers,
Secretary, Department
18. Secretary,
Department of
Dr. Raj
fertsec@nic.in]
[email: fertsec@nic.in]
Delhi [email:
New Delhi
endra
Road,, New
Prasad Road
endra Prasad
New
Bhawan , New
Technology Bhawan,
Technology, Technology
&
Technology,
&
Science
of Science
Secretary, Department
19. Secretary,
Department of
dstsec@nic.in]
Delhi.
[email: dstsec@nic.in]
Delhi . [email:
Chairman,
1.
1. Chairman,

595
595

<!-- page 3 -->

596
596

1/BE-II
366883/2021/BE-II
366883/202

of Expenditure,
Department
Department of
Expenditure, North
North Block,
Block, New
New Delhi
Delhi [email:
[email:
secyexp@nic.in]
secyexp@nic.in ]
Welfare, Nirman
and Family
of Health
21.
Ministry of
Health and
Family Welfare,
Nirman Bhawan
Bhawan,, New
New Delhi
Delhi
Secretary, Ministry
21. Secretary,
DPIIT, Udyog
Udyog Bhawan,
Bhawan, New
New Delhi.
Delhi.
Secretary, DPIIT,
22.
Agrawal,, Additional
Additional Secretary,
Anil Agrawal
Sh . Anil
22. Sh.
[email:
agrawal.anil@gov.in]
[email: agrawal.anil@gov.in]
23.
Nodal Officers
concerned Ministries/
Ministries/ Departments
Departments
of concerned
Officers of
All Nodal
23. All
24. Secretary,
Deptt of
Commerce,, Udyog
Udyog Bhawan
Bhawan New
New Delhi-110011
Delhi-110011 [email
[email :
of Commerce
Secretary, Deptt
csoffice@nic.in ]
csoffice@nic.in]
ceo-gem@gov.in]
[email: ceo-gem@gov.in]
Building , Delhi,
Tara Building,
/Jeevan Tara
Bharti /Jeevan
Jeevan Bharti
GeM , Jeevan
2s.
25. CEO,
CEO, GeM,
Delhi, [email:
26. Concerned
26.
Concerned procuring
procuring entities
entities

20. Secretary,
Secretary,
20.

to:
Copy
Copy to:

to SIIT
1.
1. PPS
PPS to
SIIT
JS(MKN)
to JS(MKN)
PS to
2. PS
2.
3. Dir.(RG)/Dir(RK)/Dir(AK)/Consultant
Dir.(RG)/Dir(RK)/Dir(AK)/Consultant (KC)/
(KC)/ Consultant
Consultant (VPV)
(VPV),, Consultant
Consultant (AB)/
(AB)/
DPIIT
DPIIT

<!-- page 4 -->

597
597
-II
366883/2021 /BE-II
366883/2021/BE

of
implementation of
the implementation
review the
to review
Standing Committee
of Standing
of 12th
Minutes
Minutes of
12th Meeting
Meeting of
Committee to
03.09.2021
on 03.09.2021
2017 held
Order, 2017
to Make
(Preference to
Make in
Public
in India)
India) Order,
Procurement (Preference
held on
Public Procurement
Conferencing
at 3.00
PM through
3.00 PM
through Video
at
Video Conferencing
annexed.
participants is
of participants
List of
List
is annexed.
points
Various points
pai1icipants. Various
the participants.
welcomed the
Chairman welcomed
the Chairman
discussion, the
the discussion,
Initiating
2.
2.
Initiating the
paragraphs.
the succeeding
in the
are detailed
meeting are
the meeting
discussed
succeeding paragraphs.
in the
detailed below
discussed in
below in
Agenda Point
Agenda
No. 11
Point No.
necessity
the necessity
dated 16.09.2020
Order dated
the PPP-MII
in the
introduced in
changes introduced
The changes
3.1
and the
The
3.1
16.09.2020 and
PPP-MIi Order
noted
also noted
was also
It was
deliberated. It
was deliberated.
Order was
the Order
notification under
ministry notification
nodal ministry
revised nodal
of revised
under the
of
Textiles,
of Textiles,
Ministry of
Mines, Ministry
of Mines,
of Shipping,
Ministry of
MoCA, Ministry
MeitY, MoCA,
that MeitY,
that
Shipping, Ministry
Ministry of
and
Science and
of Science
Department of
Fertilisers. Department
of Fertilisers,
Affairs, Department
Military Affairs,
of Military
Department of
Department of
Department
Order.
revised Order.
the revised
per the
as per
the notification
issue the
to issue
yet to
are yet
Technology
notification as
Technology are
to
Departments to
Committee directed
Standing Committee
The Standing
3.2
Ministries/ Departments
nodal Ministries/
aforesaid nodal
directed aforesaid
The
3.2
dated
Order dated
per Order
as per
these as
re-notify these
and re-notify
Order and
PPP-Mll Order
under PPP-MIJ
notifications under
their notifications
review their
review
days.
,vithin 15
16.09.2020
15 days.
16.09.2020 within
Departments)
Ministries/ Departments)
nodal Ministries/
(Action: Concerned
Concerned nodal
(Action:
No. 22
Point No.
Agenda Point
Agenda
system,
security system,
camera, security
for "CCTV
Nodal Ministry
as Nodal
DoT as
of DoT
nomination of
The nomination
Ministry for
The
"CCTV camera,
4.1
4.1
and
Committee and
Standing Committee
by 11th
related appliances''
all related
and all
system and
video surveillance
11th Standing
appliances" by
surveillance system
video
deliberated.
were deliberated.
the subject
on the
of DoT
request letters
matter were
subject matter
DoT on
letters of
request
the
be the
will be
MeitY will
that MeitY
directed that
Committee directed
detailed deliberations,
After detailed
Standing Committee
After
deliberations, Standing
4.2
4.2
all
and all
system and
video surveillance
camera, security
for "CCTV
Nodal Ministry
Nodal
Ministry for
surveillance system
system. video
security system,
"CCTV camera,
related
appliances".
related appliances".

4.3
4.3

same.
the same.
of the
acceptance of
confirmed acceptance
MeitY confirmed
from MeitY
Representative
Representative from

(Action:
DPIIT)
(Action: DPIIT)

<!-- page 5 -->

598
598
366883/2021/BE-III
366883/2021/BE-I

Agenda Point
Point No.
No. 33
Agenda
granted
Welfare granted
Family Welfare
and Family
of Health
Ministry of
5.
Standing
Committee noted
noted that
Health and
that Ministry
Standing Committee
5.
under Para
20% under
requirement of
content requirement
local content
minimum local
from minimum
exemption from
one
of 20%
Para 14
14 of
of
time exemption
one time
lakh doses
procurement of
in procurement
of 180
180 lakh
doses of
of
Minister-in-charge in
of Minister-in-charge
approval of
the approval
the
with the
Order with
the Order
universal
under universal
Crore under
of Rs.
cost of
estimated cost
an estimated
Inactivated Polio
Polio Vaccine
Rs. 171.93
171.93 Crore
at an
Vaccine at
Inactivated
immunization
program.
immunization program.

Agenda
Point No.
No. 44
Agenda Point
No. I)
(Public Procurement
Order (Public
notification vide
6.1
Department of
of Expenditure
Expenditure notification
vide Order
Procurement No.
I)
Department
6.1
beneficial
having beneficial
bidders having
the bidders
of the
registration of
mandatory registration
dated 23rd
July, 2020
regarding mandatory
2020 regarding
23rd July,
dated
public
participation in
with India
border with
ownership from
from countries
countries sharing
land border
India for
for participation
in public
sharing land
ownership
were deliberated.
procurement and
and formalities
formalities of
deliberated.
process were
registration process
of registration
procurement

6.2
It was
that as
per recommendations
recommendations of
of Committee
Committee of
of Secretaries
Secretaries (CoS)
(CoS)
as per
noted that
was noted
It
6.2
security
for security
are processed
applications are
registration applications
those registration
only those
meeting
processed for
23.02.2021 , only
dated 23.02.2021,
meeting dated
perspective
demand-supply perspective
considered essential
are considered
and
clearance, which
which are
essential from
from demand-supply
political clearance,
and political
sent to
only sent
are only
instance are
the first
at the
applications at
such, applications
by
ministries. As
As such,
first instance
to
nodal/procuring ministries.
by nodal/procuring
political
and political
security and
are processed
nodal/ procuring
Ministries. The
processed for
for security
applications are
The applications
procuring Ministries.
nodal/
grant
explicitly recommends
clearance
only if
if nodal/
Ministry/ Department
Department explicitly
recommends for
for grant
procuring Ministry/
nodal/ procuring
clearance only
grant
recommended for
explicitly recommended
not explicitly
are not
of registration.
applications, which
for grant
which are
the applications,
such, the
As such,
registration. As
of
further.
not processed
nodal Ministry/
concerned nodal
of
Ministry/ Department,
Department, are
are not
processed further.
the concerned
by the
registration by
of registration
give
to give
Departments to
Ministries/ Departments
concerned Ministries/
the concerned
all the
directed all
6.3
Standing Committee
Committee directed
Standing
6.3
or
applicant or
the applicant
to the
registration to
of registration
grant of
their
recommendations regarding
regarding grant
explicit recommendations
their explicit
otherwise.
otherwise.
Ministries/Departments)
Concerned Ministries/Departments)
(Action:
(Action: Concerned

Agenda
Point No.
No. 55
Agenda Point
non-compliance with
regarding non-compliance
by stakeholders
7 .1I
The concerns
The
concerns expressed
expressed by
stakeholders regarding
with
7.
issued
Financial Rules
General Financial
provisions
of PPP-Mil
PPP-Mil Order,
Order, General
Rules 2017
2017 and
and other
other guidelines
guidelines issued
provisions of
deliberated.
were deliberated.
portal were
GeM portal
through GeM
procurement through
by
Government oflndia
in procurement
of India in
by Government

<!-- page 6 -->

599
599

366883/2021/BE-II
366883/2021/BE-II

introduce
to introduce
propose to
they propose
that they
the Standing
apprised the
CEO,
.2
77.2
Standing Committee
GeM apprised
Committee that
CEO, GeM
concerns
the concerns
address the
GeM portal
in the
facilities in
additional features/
following additional
features/ facilities
following
the GeM
portal to
to address
stakeholders:
by stakeholders:
expressed by
expressed
portal through
the portal
on the
products on
Chinese products
of Chinese
selling of
To
a)
prevent indirect
To prevent
indirect selling
through
a)
the
to the
addition to
in addition
be introduced
will be
level verification
agents, product
Indian
product level
Indian agents,
verification will
introduced in
at present.
verification, at
bidder level
present.
bidder
level verification,
to
required to
be required
will be
procuring entity
product, procuring
imported product,
any imported
For
b)
For procuring
b)
procuring any
entity will
the procurement
with whose
authority, with
of the
enter
is being
being
procurement is
whose approval
approval the
the authority,
details of
the details
enter the
portal.
on the
made,
the portal.
made, on
resolve.
should resolve.
concerns should
the concerns
of the
changes, most
above changes,
with above
He
He opined
opined that
that with
most of
portal
its portal
of facility
version of
demo version
tested the
has tested
also informed
was also
It
77 .3
the demo
informed that
in its
facility in
that GeM
GeM has
It was
.3
are
procuring entities
where procuring
cases where
monitor all
help it
to help
to DPllT
access to
to provide
to
provide access
DPIIT to
all such
such cases
entities are
it monitor
been
has been
Order has
relaxation from
that (a)
saying that
by saying
imported stuff
procuring imported
PPP-MII Order
from PPP-Mil
(a) relaxation
procuring
stuff by
been
has been
tender enquiry
global tender
and (b)
authority and
by competent
granted by
permission for
for global
(b) permission
enquiry has
competent authority
granted
by
shortly by
operational shortly
be made
facility shall
The live
granted by
live facility
shall be
made operational
authority. The
by competent
competent authority.
granted
week.
next
next week.
Taken
Action Taken
with Action
along with
reply along
send its
to send
GeM to
requested GeM
Committee requested
Standing Committee
7.4
Standing
its reply
7.4
subject.
the subject.
DPIIT on
to DPIIT
Report
Report to
on the

Commerce)
of Commerce)
(Action:
(Action: GeM/
GeM/ Department
Department of

Agenda
No. 66
Agenda Point
Point No.
violation of
alleged violation
received for
grievances received
overview of
Brief
8.1
Order,
for alleged
PPP-MII Order,
Brief overview
of grievances
of PPP-MIi
8.1
grievances, including
of grievances,
break-up of
wise break-up
the participants.
with the
were shared
2017 were
including
shared with
Ministry wise
participants. Ministry
2017
received
grievances received
of 1516
total of
1516 grievances
of aa total
out of
that out
noted that
was noted
was reviewed.
their
It was
their pendency
reviewed. It
pendency was
were
Concerns were
date. Concerns
till date.
resolved till
be resolved
only be
could only
across Ministries/
across
Ministries/ Departments,
Departments, 1135
1135 could
months.
six months.
more than
are pending
grievances are
as 154
as many
expressed
for more
than six
pending for
that as
expressed that
many as
154 grievances
those
particularly those
directed that
Committee directed
The Standing
8.2
grievances, particularly
outstanding grievances,
Standing Committee
that outstanding
The
8.2
priority.
resolved on
be resolved
should be
months, should
06 months,
than 06
more than
pending for
are pending
which are
on priority.
which
for more

(Action: All
(Action:
Ministries/Departments)
concerned Ministries/Departments)
All concerned

<!-- page 7 -->

600
600

366883/2021/BE-II
366883/2021/BE-II

Agenda
Agenda No.
No. 77

9 .1
The grievance
grievance of
of Mis
M/s Accurate
Gauging Private
Private Limited
Limited against
Mis Hindustan
Hindustan
9.1
The
Accurate Gauging
against Mis
Aeronautics Limited
Aeronautics
Limited (M/s
(M/s HAL)
HAL) tender
tender for
for supply
of 3D
3D Coordinate
Coordinate Measuring
Measuring Machine
Machine
supply of
(CMM) was
was discussed
(CMM)
discussed..
9.2
M/s
Accurate Gauging
that the
the technical
technical specifications
9.2
M/s Accurate
Gauging alleged
alleged that
specifications indicate
indicate
requirement of
of 22 probing
probing systems
the aforesaid
technical specification
requirement
systems and
and the
aforesaid technical
specification is
is proprietary
proprietary
foreign CMM
CMM manufacturers.
Representative from
from M/s
Mis HAL
HAL stated
product of
only 22 foreign
product
of only
manufacturers. Representative
stated that
that
the
specifications are
are broad
generalised and
and based
their functional
functional
the specifications
broad based,
based, generalised
based upon
upon their
requirements.
requirements.
9.3
Standing Committee
the committee,
committee. headed
by JS(MKN)
9.3
Standing
Committee directed
directed that
that the
headed by
JS(MKN) with
with
representatives
from M/s
M/s HAL,
HAL, DoDP,
DoDP, M/s
Mis Accurate
Accurate Gauging
Gauging and
technical experts
experts from
representatives from
and technical
from
DRDO,
be constituted
grievance. Pending
recommendations of
DRDO, may
may be
constituted to
to examine
examine the
the grievance.
Pending recommendations
of the
the
Committee,
procurement may
be put
on hold.
Committee, the
the procurement
may be
put on
hold.
(Action: DPJJT)
(Action:
DPIIT)

Agenda No.
Agenda
No. 88
10.1
The grievance
of Mis
(M/s EPHL)
against
10.1 The
grievance of
M/s Electo
Electo Pneumatic
Pneumatic Hydraulic
Hydraulic Limited
Limited (M/s
EPHL) against
Ordnance
tender for
for supply
Ordnance Factory,
Factory, Kanpur
Kanpur tender
supply of
of Integrated
Integrated Hot
Hot Forging
Forging Press
Press was
was
deliberated.
deliberated.
10.2
they meet
meet the
pre-qualification norms
norms prescribed
prescribed in
10.2 Mis
Mis EPHL
EPHL alleged
alleged that
that they
the pre-qualification
in the
the
tender.
is un-necessarily
tender. However,
However, Ordnance
Ordnance Factory
Factory Kanpur
Kanpur is
un-necessarily insisting
insisting that
that the
criteria
the criteria
to eliminate
must be
be satisfied
in aa single
single supply
supply just
just to
eliminate otherwise
must
satisfied simultaneously
simultaneously in
otherwise qualified
qualified
and
vendors.
and capable
capable vendors.

Representatives from
Kanpur stated
that intended
Vertical
I10.3
0.3 Representatives
from Ordnance
Ordnance Factory
Factory Kanpur
stated that
intended Vertical
Hydraulic
for hot
forging of
of tubular
components is
high value,
Hydraulic Press
Press for
hot forging
tubular components
is of
of high
complex
value, complex
integrated
and special
special nature
adequate experience
experience and
integrated and
nature P&M.
P&M. The
The bidder
bidder needs
needs to
to have
have adequate
and
expertise
operation of
with induction
expertise in
in integrated
integrated operation
of press
press with
induction heating
heating system,
system, material
material
handling
of hot
of the
the components.
components. The
handling of
hot pat1s,
parts, differential
differential heating
heating and
and pressing
pressing of
The process
process
involves special
special technical
about die
and punch
design and
and very
very critical
critical
involves
technical know-how
know-how about
die and
punch design
combination of
of parameters
like heating
die, lubrication
input component,
component, its
combination
parameters like
heating of
of die,
lubrication of
of the
the input
its
heating, commensurate
to be
be applied
applied to
punch etc.
commensurate ram
ram speed,
speed, pressure
pressure to
to the
the punch
etc. so
so as
as to
to
heating,
achieve
profile of
of the
The design
achieve the
the desired
desired outside/inside
outside/inside profile
the output
output component.
component. The
design of
of
induction
furnace for
for differential
differential heating/heating/soaking
speed of
of conveyor
conveyor is
induction furnace
heating/heating/soaking and
and speed
is very
very

<!-- page 8 -->

601
601

366883/2021/BE-II
366883/2021/BE-II

very essential
is very
heating and
of heating
important
combination of
and pressing
pressing is
essential
complex combination
The complex
aspect. The
important aspect.
components. This
factor for
for achieving
achieving product
product profile
profile and
and physical
physical properties
properties of
This
the components.
of the
factor
may
criteria may
these PQ
in these
any relaxation
and any
necessitates
past experience
experience on
process and
relaxation in
PQ criteria
the process
on the
necessitates past
huge public
of huge
and wastage
the project
of the
lead to
failure of
project and
wastage of
public money.
money.
to failure
lead
with
JS(MKN) with
by JS(MKN)
headed by
committee, headed
that the
directed that
Standing Committee
the committee,
Committee directed
I 0.4 Standing
10.4
and technical
EPHL and
representatives from
from Ordnance
Ordnance Factory,
Factory, Kanpur,
Kanpur, DoDP,
DoDP, M/s
M/s EPHL
technical experts
experts
representatives
recommendations of
DRDO, may
grievance. Pending
Pending recommendations
of
the grievance.
from DRDO,
examine the
to examine
constituted to
be constituted
may be
from
hold .
on hold.
the Committee,
procurement may
may be
be put
put on
the procurement
Committee, the
the
DPIIT)
(Action: DPIIT)
(Action:

Agenda
No. 99
Agenda No.
AIIMS,
against AIIMS,
11.1 The
The grievance
M/s Prognosys
Prognosys Medical
Medical Systems
Pvt Limited
Limited against
Systems Pvt
of M/s
grievance of
11.1
deliberated.
was deliberated.
System was
Bhubaneswar tender
for supply
supply of
Portable Digital
Radiography System
Digital Radiography
of Portable
tender for
Bhubaneswar
restrictive
has restrictive
the tender
that the
11.2 M/s
M/s Prognosys
Prognosys Medical
Medical Systems
alleged that
tender has
Systems alleged
11.2
be
should be
parts should
least 22 parts
at least
specification that
"Out of
detector/tube/generator, at
of detector/tube/generator,
that "Out
specification
local
prohibits local
criterion prohibits
above criterion
manufactured by
quoting vendor
vendor themselves".
themselves". The
The above
by quoting
manufactured
and
(FPD) and
Panel Detectors
Flat Panel
since Flat
manufacturer
from participating
participating in
the said
said tender
Detectors (FPD)
tender since
in the
manufacturer from
and
manufacturer and
domestic manufacturer
any domestic
by any
X-Ray tube
are not
manufactured in
India by
in India
being manufactured
not being
tube are
X-Ray
eligibility
the eligibility
meet the
to meet
able to
not able
majorly being
imported. Hence,
Hence, local
local manufacturer
is not
manufacturer is
being imported.
majorly
the
have supplied
they have
that they
stated that
criteria. M/s
Systems Pvt
Pvt Limited
supplied the
Limited stated
Medical Systems
Prognosys Medical
Mis Prognosys
criteria.
reputed institutes.
similar equipment
equipment to
AIIMS, New
New Delhi
Delhi and
and other
other reputed
institutes.
to AIIMS,
similar
been
have been
criteria have
the criteria
that the
11.3 AIIMS
AIIMS,, Bhubaneswar
Bhubaneswar informed
informed the
committee that
the committee
11.3
and
operational performance
better operational
incorporated to
to ensure
performance and
equipment, better
integrated equipment,
fully integrated
ensure fully
incorporated
is
practice is
similar practice
also stated
process. They
eliminate
They also
stated that
that similar
bidding process.
the bidding
from the
assemblers from
eliminate assemblers
equipment.
of equipment.
type of
this type
of this
adopted
in other
of repute
procurement of
for procurement
repute for
hospitals of
other hospitals
adopted in
same
the same
may adopt
11.4
Standing Committee
Committee directed
directed that
AIIMS, Bhubaneswar
Bhubaneswar may
adopt the
that AIIMS,
.4 Standing
11
of said
procurement of
for procurement
New Delhi
by AIIMS,
technical
specifications as
used by
AIIMS, New
Delhi for
said
were used
as were
technical specifications
all
to provide
equipment.
directed M/s
M/s Prognosys
Prognosys Medical
Medical Systems
Systems to
provide all
also directed
Committee also
equipment. Committee
enquiry and
tender enquiry
last tender
New Delhi
AllMS, New
Delhi last
and
of AIIMS.
supporting documents
including aa copy
copy of
documents including
supporting
purchase Order
AIIMS, Bhubaneswar.
Bhubaneswar.
to AIIMS,
Order to
purchase

(Action: AIIMS,
Bhubaneswar)
AIIMS, Bhubaneswar)
(Action:

<!-- page 9 -->

602
602

366883/2021/BE-II
366883/2021/BE-II

10
No. 10
Agenda No.
Agenda

g Private
Limited against
Gun Factory,
Factory,
Private Limited
against Gun
Gauging
Accurate Gaugin
of M/s
12.1
Mis Accurate
grievance of
The grievance
The
12.1
3D-Coordinate Measuring
CNC 3D-Coordinate
of CNC
Kanpur tender
for supply
tender for
Measuring Machine
supply of
(CMM) was
Machine (CMM)
was
Kanpur
deliberated.
deliberated.
Z
and Z
X and
that X
that technical
alleged that
specifications indicate
indicate that
technical specifications
Gauging alleged
Accurate Gauging
12.2 Mis
Mis Accurate
12.2
been
have been
ceramic. Mis
or ceramic.
aluminium alloy
made of
be made
should be
ways should
guide
of aluminium
alloy or
Mis Accurate
Accurate have
guide ways
Granite
Z) of
and Z)
of Granite
Y and
(X. Y
Axis (X.
three Axis
with all
standard design
all three
producing the
of standard
design with
CMM of
the CMM
producing
maintenance. Mis
high precision
thermal stability,
better thermal
which has
has better
materials,
stability, high
and easy
easy maintenance.
precision and
Mis
materials, which
various
by various
preferred by
have been
Technology CMMs
Granite Technology
the Granite
that the
stated that
been preferred
Accurate also
CMMs have
also stated
Accurate
Korwa,
Factory, Korwa,
Ordnance Factory,
Khamaria, Ordnance
Factory, Khamaria,
Ordnance Factory.
including Ordnance
entities including
procuring entities
procuring
was
aluminium/ceramic. It
to aluminium/ceramic.
compared to
etc. as
LRDE etc.
TBRL, LRDE
as they
HVF, TBRL,
they are
superior as
as compared
are superior
It was
HVF,
made of
of aluminium
or ceramic
are
alloy or
aluminium alloy
ceramic are
ways made
X and
guide ways
Z guide
and Z
with X
CMM with
alleged that
also alleged
that CMM
also
the
manufacturers from
all local
eliminates all
global MNCs.
It eliminates
MNCs. It
few global
from the
local manufacturers
supplied only
by aa few
only by
supplied
Gun Factory,
Factory, Kanpur
bidding
Representative from
Kanpur stated
stated that
from Gun
specifications
the specifications
that the
process. Representative
bidding process.
their functional
based upon
requirements.
functional requirements.
generalised and
and based
upon their
based, generalised
are broad
broad based,
are
by JS(MKN)
Committee directed
JS(MKN) with
headed by
that the
with
12.3 Standing
the committee,
committee, headed
Standing Committee
directed that
12.3
Accurate Gauging
and technical
technical
Gun Factory,
Gauging and
Factory, Kanpur,
Mis Accurate
Kanpur, DoDP,
DoDP, Mis
representatives from
from Gun
representatives
grievance. Pending
the grievance.
examine the
may be
be constituted
to examine
constituted to
Pending
DRDO, may
from DRDO,
experts from
experts
hold.
on hold.
be put
may be
procurement may
the procurement
Committee, the
the Committee,
of the
recommendations of
put on
recommendations

(Action: DPIJT)
DPIIT)
(Action:
11
No. 11
Agenda No.
Agenda
M/s Intellismart
Grid against
Infrastructure Private
Intellismart Infrastructure
Private
against Mis
of M/s
The grievance
Fluent Grid
Mis Fluent
13.1
grievance of
The
.1
13
2020/007
no. (a)
tenders for
for Smart
System; Tenders
Limited tenders
Smart Metering
Metering System;
Tenders no.
(a) IntelliSmart/FY
IntelliSmart/FY -- 2020/007
Limited
for HES
deliberated.
2020/001 for
HES were
were deliberated.
(b) IntelliSmart/FY
IntelliSmart/FY -- 2020/001
& (b)
for MDM
MDM &
for
tenders have
both the
that both
alleged that
Grid alleged
the tenders
eligibility criteria
restrictive eligibility
as
have restrictive
13.2
Fluent Grid
criteria as
M/s Fluent
.2 M/s
13
System in
in at
they
solution/ HES
require that
at ]east
bidder should
HES System
have deployed
should have
that bidder
MDM solution/
least
deployed MDM
they require
meters. Mis
25 ,00,000 smart
utilities for
two power
Grid stated
M/s Fluent
for at
Fluent Grid
stated
least 50,00,000/
50,00,000/ 25,00.000
smart meters.
at least
power utilities
two
the Indian
none of
country, none
meters in
proliferation of
of smart
smart meters
in the
given the
that given
the country,
Indian Supplier
of the
Supplier
the proliferation
that
eligibility/
of eligibility/
for review
requested for
requirements. They
eligibility requirements.
can
meet the
the eligibility
review of
They requested
can meet
enable local
Representative from
from Mis
participate. Representative
to participate.
M/s
local suppliers
criteria to
suppliers to
qualification criteria
to enable
qualification

<!-- page 10 -->

603
603

366883/2021/BE-II
366883/2021/BE-II

Intellismart
Infrastructure Private
Private Limited
informed that
Intellismart Infrastructure
Limited informed
smce issued
that they
they have
have since
issued aa
corrigendum
mandating requirement
requirement for
having supplied
MDM solution/
HES System
System for
corrigendum mandating
for having
supplied MDM
solution/ HES
for
only 15
,00,000 smart
smart meters.
the representative
of Mis
Mis Fluent
Grid stated
stated that
that
only
15,00,000
meters. However,
However, the
representative of
Fluent Grid
aforesaid
not resolve
resolve their
concerns.
aforesaid corrigendum
corrigendum does
does not
their concerns.
13.3
13.3 Standing
Standing Committee
Committee directed
that the
Ministry of
Power may
directed that
the Ministry
of Power
may get
get the
the grievance
grievance
examined by
committee of
of technical
technical experts
with representatives
experts along
along with
representatives
examined
by constituting
constituting aa committee
from
and M/s
Mis Intellismart
Intellismart and
M/s Fluent
Fluent Grid.
Grid. Mis
Mis Fluent
Fluent Grid
furnish all
Grid shall
shall furnish
all supporting
supporting
from Mis
documents
of Power
to get
get the
the grievance
documents to
to Ministry
Ministry of
Power to
grievance examined.
examined. Ministry
of Power
Power may
Ministry of
may
send
recommendation on
on the
the grievance
grievance within
within next
next 21
21 days.
send its
its recommendation
Pending
days. Pending
recommendations of
of Ministry
of Power,
procurement may
recommendations
Ministry of
Power, the
the procurement
hold.
may be
be put
put on
on hold.
(Action: Ministry
of Power)
(Action:
Ministry of
Power)
Agenda No.
Agenda
No. 12
12
14.1
The grievance
grievance of
M/s Encardio-Rite
Electronics Pvt.
Pvt. Ltd
Ltd against
against Mis
Mis RITES
14.1
The
of M/s
Encardio-Rite Electronics
RITES
tender for
"Engagement of
Integrator for
for supply,
tender
for "Engagement
of System
System Integrator
supply, installation,
installation, testing,
testing,
commissioning and
and maintenance
system for
Structural Health
Health Monitoring
Monitoring
commissioning
maintenance of
of Monitoring
Monitoring system
for Structural
System (SHMS)
(SHMS) for
for Bogibeel
Bogibeel Rail
Rail cum
System
cum Road
Road Bridge
Bridge across
across river
river Brahmaputra
Brahmaputra near
near
Dibrugarh,
Dibrugarh, Assam"
Assam" was
was deliberated.
deliberated.
14.2
Mis Encardio-Rite
Encardio-Rite alleged
that L-1
L-1 bidder
bidder (JV
(JV of
14.2 Mis
alleged that
M/s Radise
ofM/s
Radise (Foreign
(Foreign company)
company) 51 %;
%; M/s
M/s Applied
51
Testing LLC
LLC (Foreign
(Foreign Company)
Company) -- 22
Applied Foundation
Foundation Testing
22 %
Mis
% and
and Mis
Essconinfratech Pvt.
Pvt. Ltd27 %
% (domestic
(domestic company))
bid has
has indicated
indicated that
that 21
Essconinfratech
Ltd- 27
21 out
company)) in
in its
its bid
out
of
23 items
items mentioned
mentioned in
in the
BOQ shall
shall be
be sourced
sourced from
from outside
outside India.
of 23
the BOQ
India. These
These 23
23 items
items
constitute around
around 80%
80% of
cost of
of project.
project. Yet,
constitute
of cost
Yet, L-1
L-1 bidder
has given
bidder has
given aa certification
certification that
that it
it
qualifies as
Class-I local
local supplier
supplier with
qualifies
as Class-I
with 56%
56% LC.
LC. Mis
Mis Encardio
Encardio Rite
Rite alleged
alleged it
it is
is aa false
false
certificate.
The price
difference between
between L-1
and L-2
bidder is
certificate. The
price difference
L-1 and
L-2 bidder
is 0.07%.
Rite
0.07%. Mis
Mis Encardio
Encardio Rite
claims
to be
Class-I local
local supplier
supplier and
and requested
claims itself
itself to
be Class-I
requested for
for purchase
purchase preference
L-1
preference over
over L-1
bidder.
bidder.
14.3
Standing Committee
Committee noted
noted that
that M/s
Mis Encardio-Rite
14.3 Standing
Encardio-Rite has
has submitted
submitted their
their grievance
grievance with
with
all supporting
documents to
to DPIIT.
was also
also noted
noted that
that M/s
all
supporting documents
DPIIT. It
It was
Mis RITES
RITES has
has also
also given
given its
its
comments/ reply
reply on
on the
the grievance
to DPIIT.
Committee directed
comments/
grievance to
DPIIT. Standing
Standing Committee
directed that
that DPIIT
DPIIT

<!-- page 11 -->

604
604

366883/2021/BE-II
366883/2021/BE-II

holders. Pending
to all
convey its
and convey
on file
its findings
all stake
findings to
stake holders.
Pending
file and
grievance on
examine the
the grievance
may
may examine
hold.
put on
be put
may be
the procurement
the grievance,
on the
decision
grievance, the
procurement may
on hold.
decision on

(Action: DPIIT)
(Action:
DPIIT)
No. 13
Agenda No.
13
Agenda

Mis 12V
M/s Vehant,
Mis Bharat
The
5.1
I15.1
grievances from
The grievances
from Mis
Electronics Limited,
Limited, M/s
Bharat Electronics
I2V
Vehant, M/s
Cities
Six Smart
against Six
Technology Pvt.
Mis Videonetics
M/s Envoys
Systems,
Systems, M/s
Envoys and
Pvt. Ltd.
Videonetics Technology
and M/s
Smart Cities
Ltd. against
&
Project
namely Meerut,
UP namely
Meerut, Ayodhya
of UP
Ayodhya Mathura-Vrindavan,
Project of
Mathura-Vrindavan, Sahajahanpur.
Sahajahanpur, Firozabad
Firozabad &
of
implementation of
System Integrator
for ·'Master
Gorakhpur in
"Master System
tender for
Integrator (MSI)
(MSI) for
Gorakhpur
their tender
for implementation
in their
deliberated.
were deliberated.
up·, were
of UP"
in 66 cities
cities of
(ITMS) in
Intelligent
Intelligent Traffic
System (ITMS)
Management System
Traffic Management
those OEMs
criteria allow
(a) eligibility
that (a)
alleged that
OEMs
only those
allow only
15.2 The
firms alleged
eligibility criteria
complainant firms
The complainant
15.2
requires
the project
detectors globally
vehicle detectors
minimum 2000
who
globally whereas
whereas the
project requires
2000 vehicle
supplied minimum
who have
have supplied
criteria require
eligibility criteria
(b) eligibility
detectors ; (b)
vehicle detectors;
of vehicle
quantity of
70-80 quantity
maximum 70-80
require Supply/
Supply/
maximum
of
requirement of
tender requirement
maximum tender
against maximum
globally against
2000 lanes
of 2000
experience of
Installation experience
Installation
lanes globally
technical
brands, foreign
foreign brands,
specifications indicate
technical specifications
foreign technical
indicate foreign
c) technical
ANPR cameras
152
cameras;; ((c)
152 ANPR
particular set
are favouring
tenders are
specifications/
(d) tenders
and (d)
specifications/ certifications;
certifications; and
of OEM
OEM
favouring particular
set of
companies.
companies.
infonned
Government infonned
and Special
15.3 Representatives
from MoHUA
MoHUA and
Special Secretary,
Secretary, UP
UP Government
Representatives from
15.3
such,
As such,
of UP.
Government of
by Government
funded by
entirely funded
is entirely
project is
that the
the committee
the
committee that
the project
UP. As
apply on
' t apply
Order don
of PPP-Mll
provisions of
PPP-MII Order
provisions
don't
on subject
procurement.
subject procurement.
Order
of PPP-MIi
while acknowledging
that "provisions
"provisions of
acknowledging that
PPP-Mil Order
Committee while
Standing Committee
15.4
15.4 Standing
technical
the technical
review the
to review
requested UP
on subject
don't
Government to
procurement" requested
UP Government
don't apply
apply on
subject procurement"
the
in the
participate in
to participate
manufacturers to
to allow
specifications
local manufacturers
allow local
specifications and
and eligibility
eligibility criteria
criteria to

bidding
process.
bidding process.
Government)
(Action:
UP Government)
(Action: UP
Agenda No.
No. 14
14
Agenda
Vehere Interactive
Network, M/s
The
I 6.1
M/s Vehere
from Mis
M/s HFCL.
HFCL, M/s
M/s Tejas
Interactive
grievances from
Tejas Network,
The grievances
16.1
for
tender for
CPWD tender
against CPWD
Pvt. Ltd.
Pvt.
and M/s
Tuli and
M/s Xtreme
Xtreme Media
Rajesh Tuli
Shri Rajesh
Media Pvt.
Pvt. Ltd,
Ltd, Shri
Ltd. against
7, New
no- 13
Plot noNew
137,
in Plot
and 33 in
Central Secretariat
Secretariat Integrated
"Common Central
Integrated Buildings
Buildings 1,
1, 22 and
·'Common
Delhi" were
were deliberated.
deliberated.
Delhi"

<!-- page 12 -->

605
605

366883/2021/BE-II
366883/2021/BE-II

has indicated
16.2 The
The complainant
complainant firms
firms alleged
alleged that
that tender
tender has
indicated foreign
foreign makes
makes of
of
16.2
foreign OEMs
OEMs namely,
Cisco,
equipment
(a) Network
Network Management
System -- foreign
namely, Cisco,
Management System
viz. (a)
equipment viz.
Extreme Networks
Networks and
HPE (Aruba);
(Aruba); (b)
(b) Wireless
Wireless Controllers
OEMs namely,
foreign OEMs
namely,
Controllers -- foreign
and HPE
Extreme
OEMs namely,
foreign OEMs
namely,
Cisco, Extreme
Extreme Networks
Networks and
and HPE
HPE (Aruba);
(Aruba); (c)
(c) PABX
PABX System
System -- foreign
Cisco,
local manufacturers
can't participate
participate in
in
Cisco,
Avaya and
and Mi
Mite!
so on.
manufacturers can't
result, local
As aa result,
on. As
and so
tel and
Cisco, Avaya

the bidding
process.
bidding process.
the
16.3 Representatives
Representatives from
from CPWD
CPWD and
MoHUA infonned
informed the
the Standing
Standing Committee
that
Committee that
and MoHUA
16.3
the
Committee has
has been
been fanned
formed by
by MoHUA
MoHUA with
technical experts
experts from
from IITs
IITs to
to review
review the
with technical
aa Committee
technical
specification part
part of
procured/ installed
vide subject
subject
installed vide
being procured/
equipment being
the equipment
of the
technical specification
tender.
All the
the equipment
equipment listed
listed in
in these
these grievances
falls within
within the
the scope/ambit
scope/ambit of
of
grievances falls
tender. All
MoHUA committee
committee on
on the
the subject
subject matter.
matter. It
It was
further informed
informed that
that pending
pending outcome
outcome
was further
MoHUA
on
been put
procurement of
of
of subject
subject committee
committee recommendations,
recommendations, the
the procurement
of equipment
equipment has
has been
put on
hold.
hold.
16.4 Standing
Standing Committee
Committee directed
directed CPWD/MoHUA
CPWD/MoHUA to
to place
all these
these grievances
grievances before
before
place all
16.4
MoHUA constituted
constituted committee.
committee. It
It was
was also
also directed
directed that
that local
local suppliers
suppliers should
should be
be
MoHUA
engaged while
while reviewing
reviewing the
the specifications
specifications of
of these
these equipment
equipment by
the Committee.
Committee.
by the
engaged

(Action: CPWD/MoHUA)
CPWD/MoHUA)
(Action:

17.
17.

vote of
of thanks
Chair.
The meeting
meeting concluded
concluded with
the Chair.
to the
thanks to
with aa vote
The
