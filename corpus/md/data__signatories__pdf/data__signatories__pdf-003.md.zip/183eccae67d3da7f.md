---
doc_id: "183eccae67d3da7f"
source_url: "https://www.dot.gov.in/static/uploads/2026/04/5df5092aeb916aaca9e101b435b481fa.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Nomination of Officers for drawing up the panel for appointment at the level of Secretary/Addl. Secretary in Government of India"
date: "2026-04-08"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e8540ba69b3d2048"
---

<!-- page 1 -->

391-01/2025-ADG-STG-III

I/3385900/2026

No: 391-01/2025-ADG-STG-III
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 08.04.2026
OFFICE MEMORANDUM
Subject: Nomination of Oﬃcers for drawing up the panel for appointment at
the level of Secretary/Addl. Secretary in Government of India.
Please refer to the aforementioned subject communicated to this oﬃce vide
DO Letter No 01/03/2026-CS(A) dated 19.03.2026.
2. The eligibility conditions for empanelment at the level of Secretary and
Additional Secretary in the Government of India are as under:
"(A) For Secretary level:
i.
Minimum of 30 years' service in Group "A"; and
ii.
Minimum of 2 years' service in a post in Level 15 of the Pay
Matrix or more .
(B)
For Additional Secretary level:
i.
Minimum of 25 years' service in Group A"; and
ii. Minimum of 7 years' service in a post in Level 14 of the Pay Matrix in
the parent cadre or service.
3. In addition, oﬃcers fulﬁlling the following criteria only would be considered for
empanelment:
i. Year of examination is not later than 1992 (i.e. 1993 batch) for Secretary
level and 1998 (i.e. 1999 batch) for Additional Secretary level;
ii. Oﬃcer should have been empaneled at Additional Secretary level
(for empanelment at Secretary Level) and at Joint Secretary level (for
empanelment at Additional Secretary level)
iii. Oﬃcer should have at least 3 years' experience under Central staﬃng
Scheme at the level of Deputy Secretary & above; and
iv. Officer should have at least one-year's residual service as on 01.01.2026.
The reference date for determining the eligibility shall be 01.01.2026.
4. The willing oﬃcers are requested to check their eligibility as per the above and
are requested to send the following data/details: a) Format - I (for empanelment at the level of Secretary), Format-II (for
empanelment at the level of Additional Secretary)

<!-- page 2 -->

391-01/2025-ADG-STG-III

I/3385900/2026

b) Contact details of Secretary, Additional Secretary level oﬃcers, Peers and
Subordinate officers with whom the officers have worked during last 15 years.
5. Eligible Indian Telecommunications Service (ITS) oﬃcers may forward their
application/willingness along with the requisite information, through proper channel
to the undersigned latest by 20.04.2026.
Enclosure: - Format -I & Format-II
(Vivek Krishna Verma)
ADG (STG-III)
Ph: 011-23372286
Email Id: adgstaff-dot@gov.in
To,
All eligible ITS officers (Through DoT Website)

<!-- page 3 -->

Annexure-I
NOMINATIONS FOR SECRETARY LEVEL EMPANELMENT

Name of the Service: _______________
Name of the Cadre Controlling Authority _________________________

S.
No.

Name
of the
officer
(Shri/M
s.)

DoB

Year of
Examination

Year of
allotment
(Batch)

Date of
entry into
service
(Group-A)

Whether
SC /ST
/OBC
/Gen

Date from
which
drawing pay
in a post in a
post in Level
15 of the
Pay Matrix
in the
parent
cadre/servic
e on regular
basis* (copy
of order to
be attached)

*Non-Functional Upgradation (NFU) will not be considered.
**Experience of working in the posts in cadre need not be indicated

Present
post held
with date
of
appointme
nt

Posts held under Central
Staffing Scheme of DoPT at
the level of Deputy Secretary
and above (Copy of Executive
Record
Sheets
to
be
attached)**
Post
Duration
From
To

Vigilance Status

CVC
clearance

Cadre VC
Status

Date
of
filing
of IPR
2026

Present
grade of
the
officer in
the
Cadre/se
rvice
(regular/
ad-hoc)
(copy of
order to
be
attached
)

<!-- page 4 -->

Annexure-II
NOMINATIONS FOR ADDITIONAL SECRETARY LEVEL EMPANELMENT

Name of the Service: _______________
Name of the Cadre Controlling Authority _________________________
S.
No.

Name
of the
officer
(Shri/M
s.)

DoB

Year of
Examination

Year of
allotment
(Batch)

Date of
entry into
service
(Group-A)

Whether
SC /ST
/OBC
/Gen

Date from
which
drawing
pay in a
post in a
post in
Level 14 of
the Pay
Matrix in
the parent
cadre/serv
ice on
regular
basis*
(copy of
order to be
attached)

*Non-Functional Upgradation (NFU) will not be considered.
**Experience of working in the posts in cadre need not be indicated

Present post
held with
date of
appointment

Posts held under Central
Staffing Scheme of DoPT at
the level of Deputy Secretary
and above (Copy of Executive
Record
Sheets
to be
attached)**
Post
Duration
From
To

Vigilance Status

CVC
clearance

Cadre VC
Status

Date
of
filing
of IPR
2026

Present
grade of
the
officer in
the
Cadre/se
rvice
(regular/
ad-hoc)
(copy of
order to
be
attached
)

<!-- page 5 -->

Annexure-III
Contact details of Secretary, Additional Secretary level officers, Peers and
Subordinates officers with whom the officers have worked during last 15 years
Secretary/Additional Secretary
Sr No
Name
Designation Ministry/Organisation
Contact No Email ID

Sr No

Sr No

Name

Designation

Peers
Ministry/Organisation

Contact No Email ID

Name

Subordinates
Designation Ministry/Organisation

Contact No Email ID
