---
doc_id: "b5dffce7a70c4f69"
source_url: "https://pharma-dept.gov.in/sites/default/files/Gazette%20notification%20of%20Medical%20Device%20schemes.pdf"
ministry: "Department of Pharmaceuticals (DoPs)"
title: "Gazettee Notification (Dated- 21st July, 2020) (1.6 MB)"
date: ""
pages: 10
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1fc6172c3b3de3af"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. NO. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-21072020-220617
xxxGIDExxx
CG-DL-E-21072020-220617
असाधारण
EXTRAORDINARY
भाग I—खण्ड 1
PART I—Section 1
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 173]
No. 173]

नई ददल्ली, मंगलवार, िुलाई 21, 2020/आषाढ़ 30, 1942
NEW DELHI, TUESDAY, JULY 21, 2020/ASHADHA 30, 1942

रसायन एवं उववरक मंत्रालय
(औषध जवभाग)
अजधसूचना
नई ददल्ली, 21 िुलाई, 2020
जवषय: जचदकत्सा उपकरण पाकों के संवधवन संबध
ं ी योिना।
संख्या 31026/08/2020-एमडी.—
1.

पृष्ठभूजम

1.1.

जचदकत्सा उपकरण उद्योग एक लंबी अवजध का अत्यजधक पूंिी गहन उद्योग है और इसके जलए नई
प्रौद्योजगदकयों के जवकास/प्रेरण की आवश्यकता होती है। अजधकांि हाई-टेक नवोन्मेषी उत्पाद और प्रौद्योजगकी
एक सुजवकजसत इको-जसस्ट्टम और नवोन्मेषी चक्र से उत्पन्न होती है, जिसे अभी भारत में पूरी तरह से जवकजसत
दकया िाना है।

1.2.

चूंदक परीक्षण और प्रयोगिाला सुजवधाओं के जनमावण में भारी जनवेि की आवश्यकता होती है, इसजलए भारत
सरकार द्वारा 20 माचव 2020 को "जचदकत्सा उपकरण पाकों का संवधवन" नामक एक योिना को मंिूरी दी गई
है। ये पाकव एक ही स्ट्थान पर साझी परीक्षण और प्रयोगिाला सुजवधाएं / कें द्र प्रदान करें गे जिससे जवजनमावण
लागत में काफी कमी होगी और देि में जचदकत्सा उपकरण जवजनमावण के जलए एक मिबूत इकोप्रणाली सृजित
करने में मदद जमलेगी।

2.

उद्देश्य:

3220 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

2.1

जवकजसत प्रजतस्ट्पधाव के जलए जवश्व स्ट्तरीय साझी अवसंरचनात्मक सुजवधाओं के सृिन के माध्यम से मानक
परीक्षण एवं अवसंरचना सुजवधाओं तक सरल पहंच जिसके पररणामस्ट्वरूप जचदकत्सा उपकरणों के उत्पादन की
लागत में उल्लेखनीय कमी होगी जिससे घरे लू बािार में जचदकत्सा उपकरणों की बेहतर उपलब्धता और
वहनीयता सुजनजित होगी।

2.2

संसाधनों के अनुकूलन और पैमाने की अथवव्यवस्ट्था से उत्पन्न होने वाले लाभों को प्राप्त करना।

3.

व्यापकता: राज्य सरकारों द्वारा प्रस्ट्ताजवत और इस योिना के अन्तगवत चयजनत चार जचदकत्सा उपकरण पाकों में
साझी बुजनयादी सुजवधाओं के सृिन के जलए इस योिना के तहत जवत्तीय सहायता प्रदान की िाएगी।

4.

जवत्तीय सहायता: चयजनत जचदकत्सा उपकरण पाकव के जलए जवत्तीय सहायता साझी बुजनयादी सुजवधाओं की
पररयोिना लागत की 70% होगी। पूवोत्तर राज्यों और पहाडी राज्यों (जहमाचल प्रदेि, उत्तराखंड, िम्मू और
कश्मीर कें द्र िाजसत प्रदेि और लद्दाख कें द्र िाजसत प्रदेि) के मामले में यह जवत्तीय सहायता पररयोिना लागत
की 90% होगी। एक जचदकत्सा उपकरण पाकव के जलए योिना के तहत अजधकतम सहायता 100 करोड रुपये
तक सीजमत होगी।

5.

साझी अवसंरचनात्मक सुजवधाएं:
जचदकत्सा उपकरण पाकव में अलग-अलग जचदकत्सा उपकरण इकाइयों को
कॉम्पोनेंट टेस्स्ट्टग सैंटर/ईएसडीएम/पीसीबी/ सैंससव फै जसजलटी, इलेक्ट्रो-मैग्नेरटक इं टरफे रें स सब्क्ट्स इलेक्ट्रोमैग्नेरटक कम्पैटेजबजलटी सैंटर, बायोमैरटररयल/बायोकं पैरटजबजलटी/ एक्ट्सलेरेरटड एस्िग टेस्स्ट्टग सैंटर, मेजडकल
ग्रेड मोस्ल्डग/जमस्लग/इन्िेक्ट्िन मोस्ल्डग/मिीस्नग/टू स्लग सैंटर, जचदकत्सा ग्रेड उत्पादों के जलए 3डी जडिाइस्नग
और स्प्रटटग, स्ट्टैरीलाइिेिन/ईटीओ/गामा सैंटर, एजनमल लैब और टॉजक्ट्सजसटी टेस्स्ट्टग सैंटर, रै डीऐिन टेस्स्ट्टग
सैंटर, आदद िैसी साझी सुजवधाएं प्रदान की िानी हैं।

6.

जवत्तीय पररव्यय: इस योिना का कु ल जवत्तीय पररव्यय 400 करोड रुपए है।

7.

योिना की अवजध: इस योिना की अवजध वषव 2020-21 से 2024-25 तक की होगी।

8.

राज्य कायावन्वयन एिेन्सी:

8.1

इस योिना के अन्तगवत चयजनत एक जचदकत्सा उपकरण पाकव पररयोिना को राज्य कायावन्वयन एिेन्सी
(एसआईए) द्वारा कायावजन्वत दकया िाएगा।

8.2

एसआईए जचदकत्सा उपकरण पाकव पररयोिना के कायावन्वयन के प्रयोिन के जलए संबंजधत राज्य सरकार द्वारा
गरित एक कानूनी एिेन्सी होगी।

9.

योिना संचालन सजमजत

9.1

इस योिना के अन्तगवत प्रस्ट्तावों को औषध जवभाग द्वारा गरित योिना संचालन सजमजत (एसएससी) द्वारा
मंिूरी प्रदान की िाएगी।

9.2

एसएससी की संरचना इस प्रकार होगी:
सजचव, औषध जवभाग

- अध्यक्ष

जवत्तीय सलाहकार, औषध जवभाग

- सदस्ट्य

संयुक्त सजचव, पयाववरण, वन और िलवायु पररवतवन

- सदस्ट्य

संयुक्त सजचव, उद्योग संवधवन जवभाग और आंतररक व्यापार

- सदस्ट्य

संयुक्त सजचव, स्ट्वास्ट््य और पररवार कल्याण जवभाग

- सदस्ट्य

डीसीिीआई, के न्द्रीय औषजध मानक जनयंत्रण संगिन

- सदस्ट्य

संयुक्त सजचव (नीजत), औषध जवभाग

- संयोिक

एसएससी, समय-समय पर यथावश्यक रूप से उद्योग संघों, आरएंडडी संस्ट्थानों और अन्य सरकारी / जनिी क्षेत्र
के जविेषज्ञ संगिनों के प्रजतजनजधयों को जविेष रूप से आमंजत्रत कर सकती है।
9.3

एसएससी योिना के सफल कायावन्वयन के जलए संिोधन सजहत, यदद कोई हो, आवश्यक सभी जनणवय लेगा।

<!-- page 3 -->

[भाग I—खण्ड 1]

भारत का रािपत्र : असाधारण

3

10.

योिना के जवस्ट्तृत ददिाजनदेि जवभाग की वेबसाइट पर अपलोड दकए िाएंगे।

11.

यह अजधसूचना इस जवषय पर औषध जवभाग की ददनांक 28 मई, 2020 की पूवववती अजधसूचना संख्या
31026/08/2020-एमडी का अजधक्रमण करती है।
नवदीप ररनवा, संयुक्त सजचव
MINISTRY OF CHEMICALS AND FERTILIZERS
(Department of Pharmaceuticals)

NOTIFICATION
New Delhi, the 21st July, 2020
Subject:—Scheme for Promotion of Medical Device Parks.
No. 31026/08/2020-MD.—
1.

Background

1.1

The medical device industry is highly capital intensive with a long gestation period and requires
development and induction of new technologies. It also requires continuous training of health providers to
adapt to new technologies. Most of the hi-tech innovative products originate from a well-developed ecosystem and innovation cycle which is yet to be fully developed in India.

1.2

Since the creation of testing and laboratory facilities requires huge investment, a scheme called “Promotion
of Medical Device Parks” has been approved by the Government of India on 20 th March 2020. The parks
will provide common testing and laboratory facilities / centre at one place reducing the manufacturing cost
significantly and will help in creating a robust ecosystem for medical device manufacturing in the country.

2.

Objective

2.1

Easy access to standard testing and infrastructure facilities through creation of world class common
infrastructure facilities for increased competitiveness will result into significant reduction of the cost of
production of medical devices leading to better availability and affordability of medical devices in the
domestic market.

2.2

Reaping the benefits arising due to optimization of resources and economies of scale.

3.

Scope: Financial assistance under the Scheme will be provided for creation of common infrastructure
facilities in four Medical Device Parks proposed by State Governments and selected under the scheme.

4.

Financial Assistance: Financial assistance to a selected Medical Device Park would be 70% of the project
cost of common infrastructure facilities. In case of North Eastern States and Hilly States (Himachal
Pradesh, Uttarakhand, Union Territory of Jammu & Kashmir and Union Territory of Ladakh) financial
assistance would be 90% of the project cost. Maximum assistance under the scheme for one Medical Device
Park would be limited to Rs. 100 crore.

5.

Common Infrastructure Facilities: The common facilities provided to individual medical device units in
the Medical Device Park such as component testing centre/ESDM/PCB/sensors facility, electro-magnetic
interference & electromagnetic compatibility centre, biomaterial/biocompatibility /accelerated aging testing
centre, medical grade moulding/milling/injection moulding/machining/tooling centre, 3D designing and
printing for medical grade products, sterilization/ETO/gamma centre, animal lab and toxicity testing centre,
radiation testing centre etc.

6.

Financial Outlay: The total financial outlay of the scheme is Rs. 400 crore.

7.

Tenure of the Scheme: The tenure of the scheme is from FY 2020-2021 to FY 2024-2025.

8.

State Implementing Agency

8.1.

A Medical Device Park project selected under the Scheme will be implemented by a State Implementing
Agency (SIA).

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

8.2.

SIA shall be a legal entity set up by the concerned State government for the purpose of implementing the
Medical Device Park project.

9.

Scheme Steering Committee

9.1.

The proposals under the scheme will be approved by the Scheme Steering Committee (SSC) constituted by
Department of Pharmaceuticals (DoP).

9.2.

The composition of the SSC is as follows:
Secretary, DoP

- Chairperson

Financial Adviser, DoP

- Member

Joint Secretary, Ministry of Environment, Forest and
Climate Change

- Member

Joint Secretary, Department for Promotion of Industry
and Internal Trade

- Member

Joint Secretary, Department of Health and Family Welfare

- Member

DCGI, Central Drugs Standard Control Organisation

- Member

Joint Secretary (Policy), DoP

- Convenor

The SSC may invite representatives of Industry Associations, R&D Institutions and other Government /
Private sector expert organizations as special invitees as may be necessary from time to time.
9.3.

The SSC shall take all decisions required for successful implementation of the scheme, including any
modifications if required.

10.

The detailed guidelines of the scheme will be uploaded on the website of the Department.

11.

This Notification supersedes the earlier Notification of the Department of Pharmaceuticals issued on this
subject vide no 31026/08/2020-MD dated 28th May, 2020.
NAVDEEP RINWA, Jt. Secy.

अजधसूचना
नई ददल्ली, 21 िुलाई, 2020
जवषय: जचदकत्सा उपकरणों के घरेलू जवजनमावण को बढ़ावा देने के जलए उत्पादन स्लक्ट्ड प्रोत्साहन योिना।
संख्या 31026/08/2020-एमडी.—
1.

पृष्ठभूजम

1.1.

भारत में घरे लू जचदकत्सा उपकरणों का बािार आयात पर बहत अजधक जनभवर है िो बािार के 85% से अजधक
में योगदान देता है।

1.2.

भारत में जचदकत्सा उपकरण जवजनमावण क्षेत्र अथवव्यवस्ट्थाओं की प्रजतस्ट्पधाव के मद्देनिर सभी को समान अवसर
ददए िाने की कमी का सामना कर रहा है। जचदकत्सा उपकरण जवजनमावण क्षेत्र अन्य बातों के अलावा,
जवजनमावण में अक्षमता की जवचारणीय लागत से िूझ रहा है जिसके कारण जनम्न हैं:
क)

पयावप्त बुजनयादी ढांच,े घरे लू आपूर्तत श्ृंखला और संभारतंत्र की कमी,

ख)

उच्च जवत्तीय लागत,

ग)

गुणवत्ता िजक्त की अपयावप्त उपलब्धता,

घ)

सीजमत जडिाइन क्षमताएं,

ङ)

अनुसंधान एवं जवकास और कौिल जवकास पर कम ध्यान संकेंद्रण।

<!-- page 5 -->

[भाग I—खण्ड 1]

भारत का रािपत्र : असाधारण

5

1.3.

इस समय भारत में अन्य प्रमुख जवजनमावण अथवव्यवस्ट्थाओं की तुलना में जचदकत्सा उपकरणों के जवजनमावण में
अक्षमता को दूर करने के जलए, “जचदकत्सा उपकरणो के घरे लू जवजनमावण के संवधवन के जलए उत्पादन स्लकड
प्रोत्साहन योिना” नामक योिना भारत सरकार द्वारा ददनांक 20 माचव, 2020 को अनुमोददत की गई है।

2.

उद्देश्य: योिना का उद्देश्य घरे लू जवजनमावण को बढ़ावा देना और जचदकत्सा उपकरण क्षेत्र में बडे जनवेि को
आकर्तषत करना है।

3.

व्यापकता: योिना के अंतगवत, लजक्षत खंडों में िाजमल जचदकत्सा उपकरणों की सीमा जनवेि और वृजििील
जबक्री (आधार वषव) के आधार पर चयजनत कं पजनयों को जवत्तीय प्रोत्साहन ददया िाएगा।

4.

प्रोत्साहन की मात्रा: योिना के अंतगवत भारत में जवजनर्तमत वस्ट्तुओं और लक्ष्य क्षेत्रों में कवर दकए गए वस्ट्तुओं
की वृजििील जबक्री (आधार वषव के बाद) पर चयजनत कं पजनयों को पांच वषव (5) वषव की अवजध के जलए अथावत्
जवत्तीय वषव 2021-22 से जवत्तीय वषव 2025-26 तक 5% की दर से जवत्तीय प्रोत्साहन प्रदान दकया िाएगा।

5.

लक्ष्य क्षेत्र: यह योिना के वल जचदकत्सा उपकरणों के लक्ष्य क्षेत्रों के जलए लागू होगी िैसा दक अनुलग्नक-क में
जववरण ददया गया है।

6.

अनुप्रयोज्यता: यह योिना के वल ग्रीन फील्ड पररयोिनाओं के जलए लागू हैं।

7.

पात्रता

7.1

इस योिना के अंतगवत के वल भारत में लक्ष्य क्षेत्र के अंतगवत कवर की गई वस्ट्तुओं के जवजनमावण में लगी हई
कं पजनयों को जवत्तीय सहायता प्रदान की िाएगी।

7.2

पात्रता जनवेि और जवजनर्तमत वस्ट्तुओं की वृजििील जबक्री (लक्ष्य क्षेत्रों के अंतगवत कवर) की सीमाओं के
अध्यधीन होगी।

7.3

एक आवेदक को प्रोत्साहन के संजवतरण के जलए पात्र होने के जलए सभी सीमा ितों को पूरा करना होगा।
पात्रता सीमा मानदंडों का जववरण अनुलग्नक-ख में ददया गया है।

7.4

उत्पादन स्लक्ट्ड प्रोत्साहन योिना के तहत पात्रता दकसी अन्य योिना के तहत और इसके जवपरीत पात्रता को
प्रभाजवत नहीं करे गी।

8.

योिना का कायवकाल: योिना का कायवकाल जवत्तीय वषव 2020-21 से जवत्तीय वषव 2026-27 तक है।

9.

आवेदन जखडकी: आवेदन प्राप्त करने के जलए आवेदन जखडकी 120 ददन के जलए खोली िाएगी।

10.

आधार वषव: जवत्तीय वषव 2019-20 को जनवेि और जवजनर्तमत वस्ट्तुओं की जबक्री की गणना के जलए आधार वषव
के रूप में माना िाएगा।

11.

जवत्तीय पररव्यय: योिना का कु ल जवत्तीय पररव्यय 3420 करोड रुपए है।

12.

प्रोत्साहन प्रजत कं पनी: प्रजत कम्पनी प्रोत्साहन आधार वषव के बाद जवजनर्तमत वस्ट्तुओं की वृजििील जबक्री (िोदक
व्यापाररक वस्ट्तुओं से अलग है) पर लागू होगा िो अजधकारप्राप्त सजमजत द्वारा यथाजनधावररत अजधकतम सीमा
के अध्यधीन होगा।

13.

संगणना का आधार: जवजनर्तमत वस्ट्तुओं की जनवेि सीमा और वृजििील जबक्री का आकलन जवभागों / मंत्रालयों
/ एिेंजसयों और सांजवजधक लेखा परीक्षक प्रमाणपत्रों से प्रस्ट्तुत जववरणों पर आधाररत होगा।

14.

अनुमोदन और संजवतरण प्रदक्रया

14.1

योिना के तहत आवेदन भारत में पंिीकृ त दकसी भी कं पनी द्वारा दकया िा सकता है।

14.2

जवजधवत रूप से पूण,व एक प्रारं जभक आवेदन, आवेदव जखडकी पर िमा करना होगा।

14.3

उपयुक्त आवेदनों का मूल्यांकन दकया िाएगा और चयन के जलए जवचार दकया िाएगा।

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

14.4

प्रोत्साहन आवश्यक सीमा मानदंडों को पूरा करने वाले चयजनत आवेदकों और जिनके जवतरण के दावे क्रम में
पाए िाएंगे, को िारी दकया िाएगा।

14.5

इस योिना के तहत सहायता पांच (5) वषव अथावत् जवत्तीय वषव 2021-22 से जवत्तीय वषव 2025-26 तक की
अवजध के जलए प्रदान की िाएगी।

15.

पररयोिना प्रबंधन एिेंसी

15.1

इस योिना को एक नोडल एिेंसी के माध्यम से लागू दकया िाएगा।

15.2

ऐसी नोडल एिेंसी पररयोिना प्रबंधन एिेंसी (पीएमए) के रूप में कायव करे गी और सजचवीय, प्रबंधकीय और
कायावन्वयन सहायता प्रदान करने के जलए उत्तरदायी होगी और समय-समय पर जवभाग द्वारा सौंपी गई अन्य
जिम्मेदाररयों को पूरा करे गी। पीएमए की जवस्ट्तृत स्ट्थापना, कामकाि और उत्तरदाजयत्वों का जववरण योिना
ददिाजनदेिों में ददया िाएगा।

15.3

योिना के दक्रयान्वयन से संबंजधत कायवकलापों को पूरा करने के जलए, अन्यों के साथ-साथ, पीएमए
जनम्नजलजखत के जलए भी उत्तरदायी होगी:
15.3.1. योिना के तहत सहायता देने के जलए आवेदनों का मूल्यांकन और पात्रता का सत्यापन,
15.3.2. योिना के तहत प्रोत्साहन के संजवतरण के जलए पात्र दावों की िांच,
15.3.3. योिना के अंतगवत कं पजनयों के जलए सीमा जनवेि और जवजनर्तमत वस्ट्तुओं की वृजििील जबक्री सजहत
योिना की प्रगजत और कायवजनष्पादन से संबंजधत आंकडों का संकलन।

16.

अजधकार प्राप्त सजमजत (ईसी)

16.1

औषध जवभाग द्वारा जनम्नजलजखत संयोिनों वाली एक अजधकार प्राप्त सजमजत (ईसी) का गिन दकया िाएगासीईओ, नीजत आयोग, (अध्यक्ष)
सजचव, औषध जवभाग
सजचव, स्ट्वास्ट््य और पररवार कल्याण जवभाग
सजचव, वाजणज्य जवभाग
सजचव, उद्योग और आंतररक व्यापार संवधवन जवभाग
सजचव, पयाववरण, वन और िलवायु पररवतवन जवभाग
महाजनदेिक, जवदेि व्यापार
समय-समय पर यदद आवश्यक समझा िाए तो जविेषज्ञ जविेष अजतजथ के रूप में आमंजत्रत दकए िा सकते हैं।

16.2

यह ईसी, योिना के अंतगवत पीएमए द्वारा उपयुक्त पाए गए आवेदनों पर अनुमोदन के जलए जवचार करे गी।

16.3

यह ईसी, पीएमए द्वारा िांच दकए गए और अनुिंजसत दकए गए दावों पर, जनधावररत प्रदक्रया तथा ददिाजनदेिों
के अनुसार संजवतरण के जलए जवचार करे गी।

16.4

यह ईसी योिना के अंतगवत पात्र कं पजनयों के अपने जनवेि, रोिगार सृिन और योिना के अंतगवत उत्पादन की
आवजधक समीक्षा करे गी।

16.5

ईसी को इस योिना तथा योिना ददिाजनदेिों में भी संिोधन करने का प्राजधकार होगा।

16.6

ईसी की व्यापक स्ट्थापना, कायवप्रणाली और उत्तरदाजयत्वों का जववरण योिना ददिाजनदेिों में ददया िाएगा।

17.

इस योिना के जवस्ट्तृत ददिाजनदेि जवभाग की वेबसाइट पर अपलोड कर ददए िाएंगे।

<!-- page 7 -->

[भाग I—खण्ड 1]

18.

भारत का रािपत्र : असाधारण

7

यह अजधसूचना ददनांक 28.05.2020 की अजधसूचना सं. 31026/08/2020-एमडी के अंतगवत औषध जवभाग
की पूवव अजधसूचना का अजधक्रमण करती है।
नवदीप ररनवा, संयुक्त सजचव
अनुलग्नक-क

योिना के अंतगवत उपयुक्त जचदकत्सा उपकरणों के लक्ष्य क्षेत्र
लक्ष्य क्षेत्र क्र.सं.

लक्ष्य क्षे त्र के अं त गव त जचदकत्सा उपकरणों का वणव न

लक्ष्य क्षेत्र 1

कैं सर के यर/ उपकरण जचदकत्सा रे जडयोथे रे पी

लक्ष्य क्षेत्र 2

रे जडयोलॉिी और इमे स्िग जचदकत्सा उपकरण (आयनीकरण एवं गै र-आयनीकरण रे जडएिन
उत्पाद दोनों) और न्यू जक्ट्लयर इमेस्िग उपकरण

लक्ष्य क्षेत्र 3

एनेस्ट्थे रटक्ट्स और कार्तड यो-रे स्ट्पीरे ट री जचदकत्सा उपकरण जिनमें कार्तड यों रे स्ट्पीरे ट री श्ेणी
के कै थे टसव और रीनल के यर जचदकत्सा उपकरण िाजमल हैं।

लक्ष्य क्षेत्र 4

सभी इम्पलां ट्स जिनमें इम्पलां टे ब ल इले क्ट्रॉजनक जडवाइस िै से कोक्ट्ले यर इम्पलां ट्स और
पे स मे क र िाजमल हैं

रटपपणी: एक प्रमुख घटक िो तैयार जचदकत्सा उपकरण (िैसे रोटेटटग एनोड ट्यूब, स्ट्टेिनरी एनोड ट्यूब, एमआरआई
मैग्नेट, फ्लैट पैनल जडटेक्ट्टर और इसी तरह के घटक) के प्रमुख भाग का गिन करता है, और इसके जलए एक
अलग एचएस कोड होता है, संबंजधत लक्ष्य क्षेत्र में िाजमल माना िाएगा।
अनुलग्नक-ख
पात्रता जनधावररत सीमा मानदंड
क्षेत्र

प्रोत्साहन दर
(जवजनर्तमत वस्ट्तओं
ु की
वृजििील जबक्री पर)

न्यूनतम सीमा जनवेि

जवजनर्तमत वस्ट्तओं
ु की
वृजििील जबक्री न्यूनतम सीमा

जचदकत्सा उपकरण
के सभी चार क्षेत्र
(अनुलग्नक-क में
जववरण ददया गया
है)

वषव 1: 5%
वषव 2: 5%
वषव 3: 5%
वषव 4: 5%
वषव 5: 5%

3 वषों में 180 करोड रुपए

वषव 1: 120 करोड रुपए
वषव 2: 240 करोड रुपए
वषव 3: 360 करोड रुपए
वषव 4: 460 करोड रुपए
वषव 5: 560 करोड रुपए

न्यूनतम संचयी: (करोड) वषव
1 : 60
वषव 2 : 120
वषव 3 : 180

रटपपणीीः वषव 1 से अजभप्राय जवत्तीय वषव 2021-22 है।

NOTIFICATION
New Delhi, the 21st July, 2020
Subject:— Production Linked Incentive Scheme for Promoting Domestic Manufacturing of Medical
Devices.
No. 31026/08/2020-MD.—
1.

Background

1.1.

Domestic medical devices market in India is heavily dependent on imports which contribute to more than
85% of the market.

<!-- page 8 -->

8
1.2.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]

The medical devices manufacturing sector faces in India lack of a level playing field vis-à-vis competing
economies. The medical devices manufacturing sector suffers from a considerable cost of manufacturing
disability, among other things, on account of:
a.

lack of adequate infrastructure, domestic supply chain and logistics,

b.

high cost of finance,

c.

inadequate availability of quality power,

d.

limited design capabilities,

e.

low focus on R&D and skill development

1.3.

With a view to address the disability in manufacturing of medical devices in India vis-à-vis other major
manufacturing economies, a scheme called “Production Linked Incentive Scheme for Promoting Domestic
Manufacturing of Medical Devices” has been approved by the Government of India on 20 th March, 2020.

2.

Objective: The Scheme intends to boost domestic manufacturing and attract large investments in the
Medical Devices Sector.

3.

Scope: Under the Scheme, financial incentives shall be given to selected companies based on threshold
investment and incremental sales (over Base Year) of medical devices covered under target segments.

4.

Quantum of Incentive: Under the Scheme, financial incentive shall be given to selected companies at the
rate of 5% of incremental sales (over Base Year) of goods manufactured in India and covered under Target
segments, for a period of five (5) years i.e. from FY 2021-22 to FY 2025-26.

5.

Target Segments: The Scheme is applicable only for target segments of medical devices as detailed in
Annexure A.

6.

Applicability: The Scheme is applicable only for greenfield projects.

7.

Eligibility

7.1.

Financial incentive under the scheme shall be provided only to companies engaged in manufacturing of
goods covered under target segments in India.

7.2.

Eligibility shall be subject to thresholds of investment and incremental sales of manufactured goods
(covered under Target Segments) over Base Year.

7.3.

An applicant must meet all the threshold conditions to be eligible for disbursement of incentive. Eligibility
threshold criteria is detailed in Annexure B.

7.4.

Eligibility under Production Linked Incentive scheme shall not affect eligibility under any other Scheme
and vice-versa.

8.

Tenure of the Scheme: The tenure of the scheme is from FY 2020-21 to FY 2026-27.

9.

Application Window: The application window for receiving the applications shall be 120 days.

10.

Base Year: Financial Year 2019-20 shall be treated as the base year for computation of incremental sales
of manufactured goods.

11.

Financial Outlay: Total financial outlay of the Scheme is Rs. 3,420 crore.

12.

Incentive Per Company: The incentive per company will be applicable on incremental sales of
manufactured goods over Base Year subject to ceilings as decided by the Empowered Committee.

13.

Basis of Computation: Assessment of threshold investment and incremental sales of manufactured goods
shall be based on details furnished to the Departments / Ministries / Agencies and Statutory Auditor
certificates.

14.

Approval and Disbursement Process

14.1. Application under the Scheme can be made by any company registered in India.
14.2. An initial application, complete in all aspects, will have to be submitted within the application window.

<!-- page 9 -->

[भाग I—खण्ड 1]

भारत का रािपत्र : असाधारण

9

14.3. Eligible applications will be appraised and considered for selection.
14.4. Incentive shall be released to selected applicants meeting the required thresholds and whose disbursement
claims are found to be in order.
14.5. Support under the scheme shall be provided for a period of five (5) years i.e. from FY 2021-22 to FY
2025-26.
15.

Project Management Agency

15.1. The Scheme shall be implemented through a Nodal Agency.
15.2. Such Nodal Agency shall act as a Project Management Agency (PMA) and be responsible for providing
secretarial, managerial and implementation support and carrying out other responsibilities. Detailed
constitution, functioning and responsibilities of the PMA will be elaborated in the scheme guidelines.
15.3. For carrying out activities related to the implementation of the scheme, PMA would, inter alia, be
responsible for:
15.3.1. Appraisal of applications and verification of eligibility for support under the Scheme,
15.3.2. Examination of claims eligible for disbursement of incentive under the Scheme,
15.3.3. Compilation of data regarding progress and performance of the scheme including threshold
investment and incremental sales of manufactured goods for companies under the scheme.
16.

Empowered Committee (EC):

16.1. An Empowered Committee (EC) shall be constituted by DoP with following composition:
CEO, NITI Aayog

(Chairman)

Secretary, Department of Pharmaceuticals
Secretary, Department of Health & Family Welfare
Secretary, Department of Commerce
Secretary, Department for Promotion of Industry & Internal Trade
Secretary, Ministry of Environment, Forest and Climate Change
Director General of Foreign Trade
Experts may be invited as special invitees, as may be felt necessary, from time to time.
16.2. The EC will consider applications, as found eligible by the PMA, for approval under the Scheme.
16.3. The EC will consider claims, as examined and recommended by the PMA, for disbursement as per the laid
down procedure and guidelines.
16.4. The EC will conduct a periodic review of eligible companies with respect to their investments, employment
generation and production under the Scheme.
16.5. The EC will be authorized to carry out any amendments in the Scheme and the scheme guidelines.
16.6. Detailed constitution, functioning and responsibilities of the EC will be elaborated in the Scheme
guidelines.
17.

The detailed guidelines of the scheme will be uploaded on the website of the Department.

18.

This Notification supersedes the earlier Notification of Department of Pharmaceuticals issued on this
subject vide no. 31026/08/2020-MD dated 28.05.2020.
NAVDEEP RINWA, Jt. Secy.

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART I—SEC. 1]
Annexure A

Target Segments of Medical Devices Eligible under the Scheme
Target Segment No.

Description of Medical Devices covered under Target Segment

Target Segment 1

Cancer care/Radiotherapy medical devices

Target Segment 2
Target Segment 3
Target Segment 4

Radiology & Imaging medical devices (both ionizing & non-ionizing
radiation products) and Nuclear Imaging Devices
Anaesthetics & Cardio-Respiratory medical devices including Catheters of
Cardio Respiratory Category & Renal Care Medical Devices
All Implants including implantable electronic devices like Cochlear
Implants and Pacemakers

Note: A key component which constitutes major part of a finished medical device (such as Rotating Anode Tube,
Stationary Anode Tube, MRI Magnet, Flat Panel Detector and similar components), and has a distinct HS
code for itself, will be considered as included in the corresponding target segment.
Annexure B
Eligibility Threshold Criteria
Segment

All four segments
of medical
devices (detailed
in Annexure A)

Incentive Rate
(on Incremental Sales
of Manufactured
Goods)
Year 1: 5%
Year 2: 5%
Year 3: 5%
Year 4: 5%
Year 5: 5%

Threshold Minimum
Investment

Threshold Minimum
Incremental Sales of
Manufactured Goods

INR 180 Crore over 3 Years

Year 1: INR 120 Crore
Year 2: INR 240 Crore
Year 3: INR 360 Crore
Year 4: INR 460 Crore
Year 5: INR 560 Crore

Cumulative Minimum
(Crore):
Year 1: 60
Year 2: 120
Year 3: 180

Note: Year 1 means Financial Year 2021-22

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR Digitally
MANOJ KUMAR VERMA
VERMA

Date: 2020.07.21 21:23:14
+05'30'
