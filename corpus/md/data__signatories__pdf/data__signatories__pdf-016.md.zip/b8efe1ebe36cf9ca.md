---
doc_id: "b8efe1ebe36cf9ca"
source_url: "https://mpa.gov.in/static/uploads/2025/07/9eb854c2ad43424a9448ec57188b6220.pdf"
ministry: "Parliamentary Affairs (MPA)"
title: "THE SALARY, ALLOWANCES AND PENSION OF MEMBERS OF PARLIAMENT ACT, 1954 AND RULES MADE THEREUNDER (As amended up to 11th May, 2022)"
date: "2022-05-11"
pages: 92
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bc018fb5a2ff69e6"
---

<!-- page 1 -->

THE
SALARY, ALLOWANCES AND PENSION
OF
MEMBERS OF PARLIAMENT ACT, 1954
AND
RULES MADE THEREUNDER

(As amended up to 11th May, 2022)

Ministry of Parliamentary Affairs
Government of India

<!-- page 2 -->

The Salary, Allowances and Pension of Members of Parliament
Act, 1954 and Rules Made Thereunder
(As amended upto 11th May, 2022)
CONTENTS
1.

The Salary, Allowances and Pension of Members of Parliament Act,
1954 (As amended )

2.

The Members of Parliament (Travelling and Daily Allowances) Rules,
1957

3.

The Housing and Telephone Facilities (Members of Parliament) Rules,
1956

4.

The Medical Facilities (Members of Parliament) Rules, 1959

5.

The Members of Parliament (Allowances for Journeys Abroad) Rules,
1960

6.

The Members of Parliament (Constituency Allowance) Rules 1986

7.

The Members of Parliament (Advance for the Purchase of
Conveyance) Rules, 1986

8.

The Members of Parliament (Office Expense Allowance) Rules, 1988

9.

The Payment of Family Pension (Submission of Documents) Rules,
2021

10.

Explanatory Memoranda

<!-- page 3 -->

Chapter 1
THE SALARY, ALLOWANCES AND PENSION OF MEMBERS OF
PARLIAMENT ACT, 1954
(No. 30 of 1954)
[As Amended by Acts Nos. 9 of 1955, 55 of 1958, 26 of 1964, 25 of 1969, 29 of 1972, 65 of
1974, 48 of 1975, 105 of 1976, 33 of 1977, 27 of 1979, 21 of 1981, 35 of 1982, 61 of 1982,
22 of 1983, 74 of 1985, 60 of 1988, 30 of 1989, 3 of 1993, 48 of 1993, 18 of 1995, 28 of
1998, 16 of 1999, 17 of 2000, 46 of 2001, 34 of 2002, 9 of 2004, 40 of 2006, 37 of 2010, 13
of 2018 (The Finance Act, 2018) and 19 of 2020 ].
[22nd May, 1954]
An Act to provide for the 1[Salary, Allowances and Pension]
of Members of Parliament
Be it enacted by Parliament in the Fifth Year of the Republic of India as follows:—
1. Short title and commencement.—(1) This Act may be called the 1a[Salary, Allowances
and Pension] of Members of Parliament Act, 1954.
(2) It shall come into force on the first day of June, 1954.
2. Definition.—In this Act,—
(a) 'Committee' means a Committee of either House of Parliament, and includes a Joint
Committee of both Houses;
2

[(aa) "Dependent" means any of the following relatives of a deceased member, namely:(i)

a minor legitimate son, and an unmarried legitimate daughter and a widowed
mother; or

(ii)

if wholly dependent on the earnings of the member at the time of his death, a
son or a daughter who has attained the age of eighteen years and who is
infirm; or

(iii)

if wholly or in part dependent on the earnings of the member at the time of his
death, -(a) a parent; or
(b) a minor brother or an unmarried sister; or
(c) a widowed daughter-in-law; or
(d) a minor child of a pre-deceased son; or
(e) a minor child of a pre-deceased daughter where no parent of the child is
alive; or
(f) the paternal grandparent if no parent of the member is alive; or
(g) such other person as may be specified by the rules made under section 9
by the Joint Committee.]

1

Substituted by Act 105 of 1976 – effective from 9.9.1976.
Substituted by Act 105 of 1976 – effective from 9.9.1976

1a
2

Ins. by Act 9 of 2004 effective from 9-1-2004.

<!-- page 4 -->

(b) 'Member' means a member of either House of Parliament 2a[But, save as otherwise
expressly provided in this Act, does not include]—
(i) a Minister as defined in the Salaries and Allowances of Ministers Act, 1952 (58 of
1952); 2b***
2c

(ii) [a Leader of the Opposition as defined in the Salary and Allowances of Leaders of
Opposition in Parliament Act, 1977]; and

2d

(iii) an Officer of Parliament as defined in the Salaries and Allowances of Officers of
Parliament Act, 1953 (20 of 1953);

(c) 'New member' means a member who takes his seat in either House of Parliament
after the commencement of this Act and includes a member who is re-elected or
re-nominated;
(d) 'period of residence on duty' means the period during which a member resides at a
place where a session of a House of Parliament or a sitting of a Committee is held or
where any other business connected with his duties as such member is transacted, for
the purpose of attending such session or sitting or for the purpose of attending to such
other business, and includes—
(i) in the case of a session of a House of Parliament, a period of such
residence not exceeding three days, immediately preceding the commencement of
the session and a period of such residence, not exceeding three days, immediately
succeeding the 2e[date on which the House of Parliament is adjourned sine die or
for a period exceeding seven days]; and
(ii) in the case of sitting of a Committee or any other business a period of
such residence, not exceeding two days, immediately preceding the commencement
of the business of the Committee or other business and a period of such residence,
not exceeding two days immediately succeeding the conclusion of the business of
the Committee or other business;
Explanation.— A member who ordinarily resides at a place where a session of a House of
Parliament or a sitting of a Committee is held or where any other business connected with
his duties as such member is transacted shall, for the duration of the session or sitting or
the time occupied for the transaction of other business (including the three or two days
immediately preceding or succeeding), be deemed to reside at such place for the purpose
of attending such session or sitting or, as the case may be, for the purpose of attending to
such other business;
(e) 'term of office' means,—
(a) in relation to a person who is a member at the commencement' of this Act, the
period beginning with such commencement and ending with the date on which his
seat becomes vacant;
2f

2a

[(b) in relation to a new member,—

Substituted by Act 55 of 1958 – effective from 30-12-1958.
2b Omitted by Act33 of 1977 – effective from 01-11-1977
2c
inserted by Act 33 of 1977 – effective from 01-11-1977.
2d
inserted by Act 33 of 1977 – effective from 01-11-1977
2e
Substituted by Act 55 of 1958 – effective from 01-06-1954
2f
Substituted by Act 105 of 1976 – effective from 9.9.1970

<!-- page 5 -->

(i) where such new member is a member of the Council of States elected in
a biennial election, or nominated, to that House, the period beginning with the date
of publication of the notification in the Official Gazette notifying his name under
section 71 of the Representation of the People Act, 1951; or
(ii) where such new member is a member of the House of the People elected
in a general election held for the purpose of constituting a new House of the People,
the period beginning with the date of publication of the notification of the Election
Commission under section 73 of the said Act; or
(iii) where such new member is a member of either House of Parliament
elected in a by-election to that House or a member nominated to the House of the
People, the period beginning with the date of his election referred to in section 67A
of the said Act, or as the case may be, the date of his nomination;
and ending with, in each case, the date on which his seat becomes vacant.]
3. Salaries and Daily Allowances.— 3(1) A member shall be entitled to receive 3a[a
salary, at the rate of 3b [one lakh rupees] per mensem] during the whole of his term of office
3c
[and subject to any rules made under this Act]. 3d[an allowance at the rate of two thousand
rupees for each day] during any period of residence on duty.
3e

[(1A) Notwithstanding anything contained in the sub-section (1), the salary payable to
Members of Parliament under sub-section (1) shall be reduced by thirty per cent. for a period
of one year commencing from the 1st April, 2020, to meet the exigencies arising out of
Corona Virus (COVID-19) pandemic.]
3f
[Provided that no member shall be entitled to the aforesaid allowance unless he signs the
register, maintained for this purpose by the Secretariat of the House of the People or, as the
case may be, Council of States, on all the days (except intervening holidays for which no
such signing is required) of the session of the House for which the allowance is claimed.]
3g

[Provided further that the rates of salary and allowance specified in this section shall be
applicable from the 18th day of May, 2009]
3h

[(2) The salary and daily allowance of members shall be increased after every five years
commencing from 1st April, 2023 on the basis of Cost Inflation Index provided under clause
(v) of Explanation to section 48 of the Income-tax Act, 1961.]
4. Travelling Allowance.—(1) There shall be paid to each member in respect of every
journey performed by him 4[in India] for the purpose of attending a session of a House of
Parliament or a meeting of a Committee or for the purpose of attending to any other business
connected with his duties as a member, from his usual place of residence to the place where
the session or the meeting is to be held or the other business is to be transacted and for the
return journey from such place to his usual place of residence—
3
3a
3b
3c
3d
3e
3f
3g
3h
4

Inserted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018
Substituted by Act 37 of 2010 – effective from 01-10-2010.
Substituted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018
Substituted by Act 55 of 1958 – effective from 01-06-1954.
Substituted by Act 37 of 2010 – effective from 01-10-2010.
Inserted by Act 19 of 2020 - effective from 01-04-2020.
Inserted by Act 48 of 1993 – effective from 09-06-1993.
Substituted by Act 37 of 2010 – effective from 01-10-2010.
Inserted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
Inserted by Act 55 of 1958 – effective from 01-04-1955.

<!-- page 6 -->

(a) 4a[*

*

*]
4b

(b) if the journey is performed by air, an amount equal to one [* * *] of the air fare
for each such journey;
(c) if the journey or any part thereof cannot be performed by rail or air—
4c

[(i)

where the journey or any part thereof is performed by steamer, an amount
equal to one 4d[* * *] fare (without diet) for the highest class in the steamer
for each such journey or part thereof, or, if there is not regular steamer service,
such amount for each such journey or part thereof as may be prescribed by
rules made under section 9];

(ii)

where the journey or any part thereof is performed by road, 4e[a road mileage
at the rate of sixteen rupees per kilometer] for each such journey or part
thereof;

4f

[Provided that when Parliament is in session and the spouse of member, if any, performs
such journey or part thereof by road, accompanied by such Member, in respect of which such
spouse has been allowed to travel by air or partly by air and partly by rail from the usual
place of residence of the Member to Delhi or back under sub-section (2) of section 6(B), the
road mileage prescribed under this sub-clause shall be allowed to such Member for such
journey or part thereof, subject to the condition that the total number of such journeys shall
not exceed eight in a year;];
4g

[Provided further that where a member performs journey by road in Delhi from and to an
aerodrome, he shall be paid a minimum amount of one hundred and twenty rupees for each
such journey.]
4h

[*

*

*

*].

Explanation.—For the purposes of sub-clause (ii) of clause (c) of this sub-section the
expression 'journey' shall include the journey from and to railway station, port or aerodrome
to and from the usual place of residence of the member or as the case may be, the residence
of the member at the place where the session of the House of Parliament or a meeting of the
Committee is to be held or where any other business is to be transacted.
(2) Notwithstanding anything contained in sub-section (1), a member who performs a
journey by road between places connected by rail or steamer, either wholly or in part, may
draw the mileage allowance referred to in sub-clause (ii) of clause (c) of sub-section (1) in
place of the travelling allowance which would have been admissible to him if he had
travelled by rail or steamer, as the case may be:
4i

[Provided that the total amount of travelling allowance drawn by such Member for the
entire journey shall not exceed the amount which would have been admissible to him had he
performed such journey by rail or by steamer, as the case may be:
4a
4b
4c
4d
4e
4f
4g
4h
4i

Omitted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
Omitted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
Substituted by Act 55 of 1958 – effective from 01-06-1954.
Omitted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
Substituted by Act 37 of 2010 – effective from 01-10-2010.
Substituted by Act 37 of 2010 – effective from 01-10-2010.
Inserted by Act 48 of 1993 – effective from 09-06-1993.
Omitted by Act 37 of 2010 – effective from 01-10-2010.
Inserted by Act 17 of 2000 – effective from 07-06-2000.

<!-- page 7 -->

Provided further that the first proviso shall be applicable to such journey only where the
places of the journey are connected by express, mail or superfast train.]
4j

[Provided also that the first proviso shall not be applicable to a member who, in the
opinion of the Chairman of the Council of States or, as the case may be, the Speaker of the
House of the People, is so incapacitated physically and cannot travel by air or train.]
4k

[Provided also that in case a member resides within a distance of three hundred
kilometers from Delhi, he or his spouse, for the journey performed by him by road, may draw
the mileage allowance referred to in sub-clause (ii) of clause (c) of sub-section (1) in place of
the travelling allowance which would have been admissible to him had he performed such
journey by rail or by road, as the case may be:
Provided also that in case a member resides in the States of Arunachal Pradesh,
Assam, Manipur, Meghalaya, Mizoram, Nagaland, Sikkim or Tripura, he or his spouse may
draw the mileage allowance referred to in sub-clause (ii) of clause (c) of sub–section (1) for
journey perfomed by him by road from his residence in any of the said States to the nearest
airport.]
4l

[(3) There shall be paid to a member in respect of a journey performed by him in the
course of a tour outside India undertaken in the discharge of his duties as such member, such
travelling and daily allowances as may be prescribed by rules made under section 9].
4m

[(4) There shall be paid to a person—
(a)

who has been elected in a biennial election as a member of the Council of
States but the notification in the Official Gazette notifying his name under
section 71 of the Representation of the People Act, 1951 has not been
published in the Official Gazette; or

(b)

who has been elected as a member of the House of the People in a general
election held for the purpose of constituting a new House of the People but the
notification in the Official Gazette notifying his name under section 73 of the
Representation of the People Act, 1951 has not been published in the Official
Gazette; or

(c)

who has been elected in a bye-election as a member of either House of
Parliament or nominated as a member to either House of Parliament, an
amount equivalent to the fare in respect of every journey performed by him for
coming to Delhi before the publication of notification referred to in clause (a)
or clause (b), or election or nomination under clause (c);

Provided that in case the journey is performed by rail or steamer or road, he shall be
entitled to the reimbursement of the fare or road mileage to which a member is entitled:
Provided further that in case he performs the journey by air, such journey shall be
included for the purpose of counting thirty-four journeys referred to in the first proviso to
sub-section (2) of section 5].
5. Travelling allowances for intermediate journeys.— 5[(1) Where a member absents
himself for less than fifteen days during a session of a House of Parliament or a sitting of a
Committee for visiting any place in India he shall be entitled to receive travelling allowances
in respect of such journey to such place and for the return journey—
4j
4k
4l
4m
5

Inserted by Act 40 of 2006 – effective from 15-9-2006.
Inserted by Act 9 of 2004 – effective from 9-1-2004.
Inserted by Act 55 of 1958 – effective from 30-12-1958.
Inserted by Act 9 of 2004 – effective from 9-1-2004.
Re-numbered by Act 105 of 1976-effective from 01-04-1995

<!-- page 8 -->

(a)

if the journey is performed by rail equal to 5a [one First class fare] for each such
journey irrespective of the class in which the member actually travels;

(b)

5b

[if the journey, being a journey during a sitting of the Committee] is performed
by air, equal to one fare by air for each such journey:

Provided that such travelling allowances shall not exceed the total amount of daily
allowances which would have been admissible to such member under section 3 for the days
of absence if he had not remained absent:
5c

[Provided further that nothing in the first proviso shall apply, if the member performs
the journey by air for visiting any place in India not more than once during a sitting of the
Committee.]
5d

[(1A) Notwithstanding anything contained in sub-section (1), a member shall be
entitled to receive travelling allowances in respect of every journey performed by air for
visiting any place in India during the interval not exceeding 5e[five days] between two sittings
of a Departmentally related Standing Committee when a House of Parliament is adjourned
for a fixed period during the Budget Session:
Provided that such travelling allowances, excluding the air fare, shall not exceed the
total amount of daily allowances which would have been admissible to such member under
section 3 for the days of absence if he had not remained absent.]
5f

[(2) Every member shall be entitled to an amount equal to the fare by air for each single
journey by air (other than a journey referred to in section 4 or the second proviso to subsection (1) of this section or section 6C) performed by him 5g[either alone or alongwith
spouse or any number of companions or relatives] from any place in India to any other place
in India during his term of office as such member:]
5h

[Provided that the total number of such journeys under this sub-section shall be thirtyfour journeys per year:]
5i

[Provided further that where the number of journeys performed by any member by air is
[less than thirty-four] then, such number of journeys not performed by him shall be carried
over to the following year:]
5j

5k

[Provided also that the spouse or companion of a member, as the case may be, may alone
perform maximum eight journeys by air from any place of India to the place in India for the
purpose of visiting such member and such journey shall be included for the purpose of
counting 5l[thirty-four journeys] referred to in the first proviso to sub-section (2):]
5m

[Provided also that in case any member avails a total number of journeys by air more
than thirty-four, such journeys permissible to him, in the year, he may be allowed to adjust
not exceeding eight such journeys from the entitled number of journeys which may accrue in
his credit in the next following year.]
5a
5b
5c
5d
5e
5f
5g
5h
5i
5j
5k
5l
5m

Substituted by Act 9 of 1955-effective from 1-4-1955
Substituted by Act 74 of 1985-effective from 26-12-1985
Substituted by Act 74 of 1985-effective from 26-12-1985
Substituted by Act 18 of 1995-effective from 01-04-1995
Substituted by Act 40 of 2006-effective from 15-9-2006
Substituted by Act 74 of 1985-effective from 26-12-1985
Substituted by Act 16 of 1999-effective from 18-3-1999
Substituted by Act 40 of 2006-effective from 15-9-2006
Substituted by Act 28 of 1998-effective from 20-8-1998
Substituted by Act 40 of 2006-effective from 15-9-2006
Substituted by Act 9 of 2004-effective from 9-1-2004
Substituted by Act 40 of 2006-effective from 15-9-2006
Inserted by Act 40 of 2006-effective from 15-9-2006

<!-- page 9 -->

5n

[(3) Notwithstanding anything contained in sub-section (2), there shall be paid to a
member who, in the opinion of the Chairman of the Council of States or, as the case may be,
the Speaker of the House of the People, is so incapacitated physically and therefore cannot
perform air or train journey, road mileage for the entire road journey.]
Explanation I.—The provisions of clause (c) of sub-section (1) and of sub-section (2) of
section 4 shall, so far as may be, apply to travelling allowances payable under this section as
they apply to travelling allowances payable under that section.
Explanation II.—For the purposes of this section. "year" means,—
(i) in the case of a person who is a member at the commencement of the
Salary, Allowances and Pension of Members of Parliament (Amendment) Act
1985, the year beginning with such commencement and each of the subsequent
years;
(ii) in the case of a person who becomes a member after such commencement,
the year beginning with the date on which his term of office as such member
commences and each of the subsequent year.]
5o

[Explanation III.—For the purpose of sub-section (2) any journey performed by the
{spouse, companions or relatives shall be added in computing the limit of 5q[thirty-four
journeys] specified in the proviso to that sub-section.}]
5p

5A

[5A.Transit Accommodation.- Where a person referred to in sub-section (4) of section 4
comes to Delhi, he shall be entitled to such transit accommodation for such period as may be
specified by the rules made under clause (ccc) of sub-section (3) of section 9 by the Joint
Committee.]
6. Free transit by Railway.— 6[(1) Every member shall be provided with one free nontransferable 6a[first class air-conditioned or executive class of any train] pass which shall
entitle him to travel at any time by any railway in India.]
Explanation.— 6b[for the purposes of this sub-section and section 6A and 6B], a member
shall include a Minister as defined in the Salaries and Allowances of Ministers Act, 1952 6c[A
Leader of the Opposition as defined in the Salary and Allowances of Leaders of Opposition
in Parliament Act, 1977] and an Officer of Parliament as defined in the Salaries and
Allowances of Officers of Parliament Act, 1953, other than the Chairman of the Council of
States.
(2) A free railway pass issued to a member under sub-section (1) shall be valid for the term
of his office and on the expiration of such term, the pass shall be surrendered to the
Secretary-General of the House of the People or the Council of States as the case may be:

5n
5o
5p
5q
5A
6
6a
6b
6c

Inserted by Act 40 of 2006-effective from 15-9-2006
Inserted by Act 3 of 1993-effective from 5-1-1993
Substituted by Act 16 of 1999-effective from 18-3-1999
Substituted by Act 40 of 2006-effective from 15-9-2006
Inserted by Act 9 of 2004-effective from 9-1-2004
Substituted by Act 55 of 1958-effective from 30-12-1958
Substituted by Act 16 of 1999-effective from 18-3-1999
Substituted by Act 29 of 1972-effective from 9-6-1972
Inserted by Act 33 of 1977-effective from 01-11-1977

<!-- page 10 -->

Provided that where any such pass is issued to a new member before he takes his seat in
either House of Parliament, he shall be entitled to use the pass for attending a session of that
House for taking his seat therein.
(3) Until a member is provided with a free railway pass under sub-section (1), he shall be,
and shall be deemed always to have been, entitled to an amount equal to one 6d[first class airconditioned or executive class of any train] fare for any journey of the nature referred to in
sub-section (1) of section 4 performed by him by rail.
(4) A member who on ceasing to be a member surrenders his pass shall, if he performs any
return journey by rail of the nature referred to in sub-section (1) of section 4, be entitled and
be deemed always to have been entitled in respect of that journey to an amount equal to one
6e
[first class air-conditioned or executive class of any train] fare.
(5) Nothing in this section shall be construed as disentitling a member to any travelling
allowances to which he is otherwise entitled under the provisions of this Act.
6A

[6A. 6Aa{Free transit by Steamer:-(1) Without prejudice to provisions of section 6,
every member representing the Union territory of the Andaman and Nicobar Islands or the
Union territory of Lakshadweep shall—
(a) be provided with one free non-transferable pass which shall entitle him to travel
at any time by the highest class by steamer to and fro any part of his constituency and
any other part of his constituency or the nearest port in the mainland of India; and
(b) be entitled to an amount equal to the fare by air from his usual place of residence to
the nearest airport in the mainland of India} 6Ab{and back}:
Provided that nothing in this sub-section shall be construed as absolving the member from
payment of any diet charges payable by him during such travel.
(2) A free steamer pass issued to a member under sub-section (1) shall be valid for the term
of his office and on the expiration of his term the pass shall be surrendered to the
Secretary-General of the House of the People:
Provided that where any such pass is issued to a new member before he takes his seat in
the House of the People, he shall be entitled to use the pass for attending a session of that
House for taking his seat therein.
(3) Until a member is provided with a free steamer pass under sub-section (1), he shall be
entitled to an amount equal to one fare (without diet) for the highest class for any journey of
the nature referred to in sub-section (1) of section 4 performed by him by steamer.
(4) A member who on ceasing to be a member surrenders the steamer pass issued to him
under sub-section (1) shall, if he performs any return journey by steamer of the nature
referred to in sub-section (1) of section 4, be entitled in respect of that journey to an amount
equal to one fare (without diet) for the highest class.
(5) Nothing in this section shall be construed as disentitling a member to any travelling
allowances to which he is otherwise entitled under the provisions of this Act.
(6) In addition to 6Ac[the facilities provided to a member] under sub-section (1), he shall
also be entitled—

6d
6e
6A
6Aa
6Ab

Substituted by Act 16 of 1999-effective from 18-3-1999
Substituted by Act 16 of 1999-effective from 18-3-1999
Inserted by Act 29 of 1972-effective from 9-6-1972
Substituted by Act 60 of 1988-effective from 1-4-1988
Inserted by Act 30 of 1989-effective from 28-8-1989

<!-- page 11 -->

(i) to one free pass for one person to accompany the member and travel by the
[highest class] by steamer to and fro any part of the constituency of the member and any
other part of his constituency or the nearest port in the mainland of India; 6Ae[or]
6Ad

(ii) to one free non-transferable pass for the spouse, if any, of the member to travel by
the highest class by steamer to and fro the usual place of residence of the member in his
constituency and the nearest port in the mainland of India, 6Af[at any time between the Island
and the mainland of India; and]
6Ag

[(iii) to an amount equal to the fare by air either for the spouse, if any, of the member or
for one person to accompany the member from the usual place of residence in the Island to
the nearest airport of the mainland of India 6Ah[and back]:
Provided that nothing in this sub-section shall be construed as absolving the person
accompanying the member or the spouse of the member from payment of any diet charges
payable by such person or spouse during such travel.]
[6AA. Special facilities to Members from Ladakh.—(1) Without prejudice to the
provisions of section 6, every member who has his ordinary place of residence in the Ladakh
6AA

6Ac

Substituted by Act 60 of 1988-effective from 1-4-1988
Substituted by Act 60 of 1988-effective from 1-4-1988
6Ae
Substituted by Act 60 of 1988-effective from 1-4-1988
6Af
Substituted by Act 60 of 1988-effective from 1-4-1988
6Ag
Inserted by Act 60 of 1988-effective from 1-4-1988
6Ad

6Ah

Inserted by Act 30 of 1989 –effective from 28-08-1989

6AA

Inserted by Act 60 of 1988-effective from 1-4-1988

<!-- page 12 -->

area of the State of Jammu and Kashmir  shall be entitled to an amount equal to the fare by
air for each single journey by air performed by him from any airport in Ladakh to the airport
in Delhi and back at any time.
(2) In addition to the air travel provided to a member under sub-section (1), he shall also be
entitled to an amount equal to the fare by air for each single journey by air performed by the
spouse, if any, of the member or one person to accompany such member, from any airport in
Ladakh area to the airport in Delhi and back at any time].
[6B. Travel facilities to Members.-- 6Ba[(1)] Without prejudice to the other provisions of
this Act, every member shall be entitled to—
6B

(i)

one free air-conditioned two-tier class railway pass for one person to accompany
the member when he travels by rail; and

(ii) free travel by any railway in India in first class air-conditioned or executive class in
any train with the spouse, if any, of the member from any place in India to any other place in
India and if such journey or part thereof is performed by air, from any place other than usual
place of residence of the member, to Delhi and back, to an amount equal to the fare by air for
such journey or part thereof or the amount equal to the journey performed by air from the
usual place of the residence of the member to Delhi and back, whichever is less.]
[Provided that where a Member has no spouse, such Member may be accompanied by any
person in place of the spouse, and notwithstanding anything containing in clause (i), the
person so accompanying shall be entitled to every facility available to the spouse.
6Bb

6Bc

[(2) Notwithstanding anything contained in clause (ii) of sub-section (1), the spouse of a
Member shall be entitled to travel,-



Vide Notification No. S. O. 3912(E), dated 30th October, 2019, this Act is made applicable to the Union
Territory of Jammu & Kashmir and the Union Territory of Ladakh.
6B

Substituted by Act 16 of 1999-effective from 22-3-1999
Re-numbered by Act 17 of 2000-effective from 7-6-2000
6Bb
Inserted by Act 17 of 2000-effective from 7-6-2000
6Bc
Substituted by Act 37 of 2010-effective from 01-10-2010
6Ba

<!-- page 13 -->

(a) any number of times, by railway in first class air-conditioned or executive class in
any train from the usual place of residence of the Member to Delhi and back; and
(b) when Parliament is in session, by air or partly by air and partly by rail, from the
usual place of residence of the Member to Delhi or back, subject to the condition that the total
number of such air journeys shall not exceed eight in a year:
Provided that where any such journey or part thereof is performed by air from any
place other than the usual place of residence of the member to Delhi and back, then, such
spouse shall be entitled to an amount equal to the fare by air for such journey or part thereof,
as the case may be, or to the amount equal to the journey performed by air from the usual
place of residence of the member to Delhi and back, whichever is less.]
6C

[6C. Air travel facilities in certain circumstances.-- Without prejudice to the other
provisions of this Act, where during any part of a year the usual place of residence of a
member in his constituency is inaccessible to or from any place outside his constituency by
road, rail or steamer due to climatic conditions, but there is air service between any place in
his constituency, and the nearest place, having rail service, outside his constituency, such
member shall be entitled to travel to and fro by air from the nearest place in his constituency
where there is air service to such place having rail service:
Provided that where the nearest place having air service is outside his constituency, such
member shall be entitled to travel to and fro by air only from such place to the nearest place
having rail service.].
6D

[6D. Special Facility to Blind and Physically Incapacitated Members.– A Member
who is blind or who is, in the opinion of the Chairman of the Council of States or, as the case
may be, the Speaker of the House of the People, so incapacitated physically as to require the
facility of an attendant shall, with respect to each such journey—
(i)

(ii)

by air as is referred to in clause (b) of sub-section (1) of section 4 or clause (b) of
sub-section (1) or sub-section (2) of section 5 or section 6C which he performs
along with an attendant be entitled (in addition to the allowances which he is
entitled under section 4 or section 5 or, as the case may be, section 6C) to an
amount equal to one fare by air for such journey;
by rail as is referred to in section 4, section 5, section 6 or section 6B be allowed
the facility of one free railway pass for an attendant, to attend such Member, in the
same class in which such Member travels in lieu of one free air-conditioned twotier class railway pass under clause (i) of sub-section (1) of section 6B.]

6Da

[(iii) by road as is referred to in section 4 or section 5, be entitled to an amount equal to
one road mileage.]
7. Allowances during short intervals between the termination of one session and the
commencement of another session etc.—7[Where the interval between the adjournment of a
6C
6D

Inserted by Act 105 of 1976 – effective from 9-9-1976
Substituted by Act 17 of 2000-effective from 7-6-2000

6Da
7

Inserted by Act 40 of 2006-effective from 17-05-2004
Substituted by Act 55 of 1958-effective from 30-12-1958

<!-- page 14 -->

House of Parliament or as the case may be, one sitting of a Committee and the re-assembly of
that House or the next sitting of the Committee at same place] does not exceed 7a[five days]
and the member concerned elects to remain at such place during the interval, he shall be
entitled to draw for each day of residence at such place a daily allowance at the rate specified
in section 3:
Provided that if the member leaves such place during the interval, his absence from the place
shall be treated as absence during a session of a House of Parliament or a sitting of the
Committee, as the case may be, and the provisions of section 5 shall apply accordingly.
8

[(8) Constituency Allowance and Amenities.—A member shall be entitled to such
constituency allowance 8a[Office Expense Allowance] and to such medical facilities for
himself and for members of his family and to such housing, telephone, water, electricity
facilities or such amount in case in lieu of all or any of such facilities, as may be prescribed
by rules under section 9.]

7a

8

Substituted by Act 40 of 2006-effective from 15-9-2006

Substituted by Act 74 of 1985-effective from 26-12-1985

8a

Inserted by Act 60 of 1988-effective from 1-4-1988

<!-- page 15 -->

8b

[Provided that where the House of the People is sooner dissolved before completing five
years from the date appointed for its first meeting, the Member of such House may be
allowed without payment, to such extent of the quota of free telephone calls or free units of
electricity or free units in kilolitres of water, available to him for a year in which such
dissolution of such House takes place, as remains unutilised on the date of such dissolution,
to avail during the period commencing on and from the date of such dissolution and ending
on the date immediately preceding the date on which the notification under section 73 of the
Representation of the People Act, 1951 has been issued for the constitution of subsequent
House of the People subject to the condition that such Member shall be liable to pay for any
telephone calls, in excess of the calls so allowed to be made during such period on the
telephone provided to him by the Government for such purpose, and units of electricity or
kilolitres of water consumed in excess of the free electricity or kilolitres of water allowed:
Provided further that where the Member referred to in the first proviso becomes Member of
the subsequent House of the People as referred to be constituted in that proviso, then, he shall
be entitled for the adjustment of the excess telephone calls, units of electricity, kilolitres of
water for the payment of which he is liable under the first proviso against the quota of free
telephone calls, units of electricity and kilolitres of water for which he is entitled during the
first year of the duration of such subsequent House of the People.]
[8A. Pension.-- 8Aa[‘(1) With effect from 18th day of May, 2009, there shall be paid a
pension of 8Ab[twenty-five thousand rupees] per mensem to every person who has served for
any period as a member of the Provisional Parliament or either House of Parliament:
8A

Provided that where a person has served as a member of the Provisional Parliament or
either House of Parliament for a period exceeding five years, there shall be paid to him an
additional pension of 8Ac[two thousand rupees] per mensem for every year served in excess of
five years.”
8Ad

[(1A) The pension and additional pension to every person shall be increased after every
five years commencing from 1st April, 2023 on the basis of Cost Inflation Index provided
under clause (v) of Explanation to section 48 of the Income-tax Act, 1961.]
Explanation.—For the purpose of this sub-section, "Provisional Parliament" shall
include the body which functioned as the constituent Assembly of the Dominion of India
immediately before the commencement of the Constitution.’]
8b

Inserted by Act 17 of 2000-effective retrospectively from 26-4-1999

8A

Inserted by Act 105 of 1976-effective from 09-09-1976.
Substituted by Act 37 of 2010-effective from 01-10-2010.
8Ab
Substituted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
8Ac
Substituted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
8Ad
Inserted by Act 13 of 2018 (The Finance Act, 2018) – effective from 01-04-2018.
8Aa

<!-- page 16 -->

8Ae

[*

*

*

*]

(2) Where any person entitled to pension under sub-section (1),—
(i)

is elected to the office of the President or Vice-President or is appointed to the office
of the Governor of any State or the Administrator of any Union territory; or

(ii)

(iii)

becomes a member of the Council of States or the House of the People or any
Legislative Assembly of a State or Union territory or any Legislative Council of a
State or the Metropolitan Council of Delhi constituted under section 3 of the Delhi
Administration Act, 1966; or
is employed on a salary under the Central Government or any State Government
or any corporation owned or controlled by the Central Government or any State
Government, or any local authority or becomes otherwise entitled to any
remuneration from such Government, corporation or local authority.

such person shall not be entitled to any pension under sub-section (1) for the period during
which he continues to hold such office or as such member, or is so employed or continued to
be entitled to such remuneration:
Provided that where the salary payable to such person for holding such office or being such
member or so employed, or where the remuneration referred to in clause (iii) payable to such
person, is, in either case, less than the pension payable to him under sub-section (1), such
person shall be entitled only to receive the balance as pension under that sub-section.
8Af

[(3) Where any person entitled to pension under sub-section (1) is also entitled to any
other pension, such person shall be entitled to receive the pension under sub-section (1) in
addition to such other pension.]
(4) In computing the number of years, for the purposes of sub-section (1), the period
during which a person has served as a Minister as defined in Salaries and Allowances of
Ministers Act, 1952 or 8Ag[as an Officer of Parliament] as defined in the Salaries and
Allowances of Officers of Parliament Act, 1953, (other than the Chairman of the Council of
States) 8Ah[or as a Leader of the Opposition as defined in the Salary and Allowances of
Leader of Opposition in Parliament Act, 1977, or has served in all or any two of such
capacities by virtue of his membership in the House of the People or in the Council of States
shall also be taken into account.]
[8AA 8AAa[(1)]. Travel facilities to ex-members.-- Every person who is not a sitting

8AA

member but has served for any period as a member of either House of Parliament shall be,-

8Ae
8Af

Omitted by Act 40 of 2006-effective from 15-9-2006
Substituted by Act 48 of 1993-effective from 9-6-1993.

8Ag

Substituted by Act 33 of 1977-effective from 01-11-1977

8Ah

Substituted by Act 33 of 1977-effective from 01-11-1977

8AA

Substituted by Act 9 of 2004-effective from 09-01-2004..
Substituted by Act 40 of 2006-effective from 15-09-2006.

8AAa

<!-- page 17 -->

(a)

with effect from the 18th day of January, 1999, entitled along with a companion
to travel in any train by any railway in India in air-conditioned two-tier class; or

(b)

entitled to travel alone in any train by any railway in India in air-conditioned
first class,

without payment of any charges on the basis of an authorisation issued for this purpose by the
Secretariat of either House of Parliament as the case may be.]
8AAb

[(2) Every person who is not a sitting member but has served for any period as a
member from the Andaman and Nicobar Islands or the Lakshadweep, shall be entitled to
travel by the highest class of accommodation in any steamer sailing between the Andaman
and Nicobar Islands or, as the case may be, the Lakshadweep and the main land territory of
India in addition to the facilities available to such member under sub-section (1), without
payment of any charges on the basis of an authorization issued for this purpose by the
Secretariat of either House of Parliament.]
8AB

[8AB. Rounding off period of pension.-- Where the period for which the pension is
payable under this Act contains a part of a year, then, if such part is nine months or more, it
shall be reckoned equivalent to complete one year for the purpose of payment of additional
pension under sub-section (1) of section 8A and if such part is less than nine months, it shall
be ignored.]
8AC

[8AC (1) On the death of a member of either House of Parliament during his term of
office, his spouse, if any, or dependent of such member shall be paid during the remaining
period of life of such spouse or, as the case may be, such dependent so long as such
dependent continues to be a dependent within the meaning of clause (aa) of section 2, family
pension equivalent to one-half of the pension which such member of Parliament would have
received had he retired.
Provided that no such family pension shall be payable to a dependent if such dependent is a
sitting member of Parliament or is drawing pension under section 8A.
(2) The family pension payable under sub-section (1) shall also be payable to the spouse or
dependent of a person who was a member of either House of Parliament or the Provisional
Parliament at any time 8ACa[* * *] and died after serving as such member:
Provided that such spouse or dependent is not drawing any pension under this Act or is not
entitled to draw family pension under the proviso to sub-section (1).
Provided further that no person shall be entitled to claim arrears of any family pension
under this sub-section in respect of a period before the commencement of the Salary,
Allowances and Pension of Members of Parliament (Amendment) Act, 2006.
Explanation.- For the purpose of this section, “Provisional Parliament” shall include the
body which functioned as the Constituent Assembly of the Dominion of India immediately
before the commencement of the Constitution.]
8B

[8B. Advance for purchase of conveyance.—There may be paid to member by
way of a repayable advance such sum of money not exceeding 8Ba[four lakh rupees] as
8AAb
8AB
8AC
8ACa
8B
8Ba

Inserted by Act 40 of 2006-effective from 15-9-2006.
Inserted by Act 9 of 2004-effective from 09-01-2004.
Inserted by Act 40 of 2006-effective from 15-9-2006.
Omitted by Act 13 of 2018 (The Finance Act, 2018) – effective from 15-09-2006.
Inserted by Act 74 of 1985-effective from 26-12-1985.
Substituted by Act 37 of 2010-effective from 1-10-2010.

<!-- page 18 -->

may be determined by rules made in this behalf under section 9 for the purchase of a
conveyance].
9. Power to make rules.—(1) For the purposes of making rules under this section, there
shall be constituted a Joint Committee of both Houses of Parliament consisting of five
members from the Council of States nominated by the Chairman and ten members from the
House of the People nominated by the Speaker.
(2) The Joint Committee constituted under sub-section (1) shall elect its Chairman and shall
have power to regulate its procedure.
9

[(2A) A member of the Joint Committee shall hold office as such member for one year from
the date of his nomination and any casual vacancy in the Joint Committee may be filled by
nomination by the Chairman of the Council of States, or the Speaker of the House of the
People, as the case may be.
Explanation.—In the case of member of a Joint Committee holding office as such
immediately before the commencement of the Salary and Allowances of Members of
Parliament (Amendment) Act, 1958, the period of one year shall be computed from the date
of such commencement.]
(3) The Joint Committee constituted under sub-section (1) may 9a[after consultation with
the Central Government] makes rules to provide for all or any of the following matters,
namely-—
(a) the routes for the performance of any journey;
9b

{(aa) the person who may be specified as dependent under sub-clause (g) of clause
(aa) of section 2};
(b) the manner in which fractions of a day shall be dealt with for the purpose of
determining the daily allowance admissible for that day;
(c) the travelling allowance admissible where a member is provided with free transit for
the whole or any part of a journey 9c[and the reduction of the daily allowance where
a member is provided with free board or lodging at the expenses of the Government
or a local authority];

9

Inserted by Act 55 of 1958-effective from 30-12-1958
Inserted by Act 55 of 1958-effective from 30-12-1958

9a

9b

Inserted by Act 9 of 2004-effective from 09-01-2004
9c Inserted by Act 55 of 1958-effective from 30-12-1958

<!-- page 19 -->

9d

[(cc) the rate at which road mileage shall be paid under sub-clause (ii) of clause (c) of
sub-section (1) of section 4};

9e

(ccc) the transit accommodation and the period for which such accommodation may be
provided under section 5A};
(d) the travelling allowance admissible where the place from which a member
commences his journey or to which he returns is not his usual place of residence;

9f

[(dd) the travelling allowance admissible in respect of journeys performed by any vessel
where there is no regular steamer service;

(ddd) the travelling and daily allowances admissible for journeys performed by a member
in the course of a tour outside India undertaken in connection with his duties as such
member];
(e) the form in which certificates if any, shall be furnished by a member for the purpose
of claiming any allowance under this Act;
9g

[(ee) the form in which certificates, if any, shall be furnished by any person for the
purpose of claiming any pension under this Act];

9h

[(f) the constituency allowance and medical and other facilities mentioned in
section 8 and the amount to be paid in cash in lieu of such facilities];
(ff) the amount which may be paid by way of repayable advance for the purchase of
conveyance; the rate of interest thereon and the mode of recovery of such amount
and interest thereon;] and

9i

{ (fff) to provide for carry forward of unutilised free telephone calls pertaining to any
year beginning on or after the 1st day of April, 2002 to any subsequent year};
(g) generally for regulating payment of the 9j[daily and travelling allowances and
pension] under this Act.

9d Inserted by Act 61 of 1982 –effective from 06-11-1982
9e
Inserted by Act 9 of 2004-effective from 09-01-2004.
9f
Inserted by Act 55 of 1958-effective from 30-12-1958
9g Inserted by Act 105 of 1976-effective from 09-09-1976
9h Substituted by Act 74 of 1985-effective from 26-12-1985
9i Inserted by Act 9 of 2004-effective from 09-01-2004
9j Substituted by Act 105 of 1976-effective from 09-09-1976

<!-- page 20 -->

(4) Any rules made under sub-section (3) shall not take effect until they are approved and
confirmed by the Chairman of the Council of States and the Speaker of the House of the
People and are published in the Official Gazette and such publication of the rules shall be
conclusive proof that they have been duly made.
*

10. Validation of payment of certain travelling allowance.

*

Repealed by the Repealing and Amending Act, 1960 (58 of 1960) S. 2 and Schedule 1.

<!-- page 21 -->

Chapter 2
THE MEMBERS OF PARLIAMENT (TRAVELLING AND DAILY
ALLOWANCES) RULES, 1957
New Delhi, the 4th April, 1957
S.R.O. 1148. -- The following Rules made by the Joint Committee constituted under subsection (1) of Section 9 of the Salaries and Allowances of Members of Parliament Act, 1954
(No. 30 of 1954), in exercise of the powers conferred on it by sub-section (3) of the said
section, which have been approved and confirmed by the Chairman of the Council of States
and the Speaker of the House of the People as required by sub-section (4) of that section, are
published for general information:-THE MEMBERS OF PARLIAMENT (TRAVELLING AND DAILY ALLOWANCES )
RULES, 1957*
(As amended upto 11th May, 2022)

PRELIMINARY
1. Short Title. -- (1) these rules may be called the Members of Parliament (Travelling and
Daily Allowances) Rules, 1957.
(2) They shall be deemed to have come into force on the 1stday of June, 1954, provided that
any claim already settled before the publication of these rules in the Official Gazette shall not
be reopened by virtue of any provision contained in these rules.
2. Definitions. -- In these rules, unless the context otherwise requires ,-a. "the Act’’ means the Salaries and Allowances of Members of Parliament
Act,1954 (30 of 1954), as amended (9 of 1955);
b. “Controlling Officer’’ means an officer of the Lok Sabha Secretariat
empowered by the Secretary to the Lok Sabha or an Officer of the Rajya
Sabha Secretariat empowered by the Secretary to the Rajya Sabha, to
countersign the traveling and daily allowances bills of Members of the Lok
Sabha or the Rajya Sabha as the case may be;
c. “Day’’ means a period of twenty-four hours beginning at midnight;
d. “Form’’ means a form appended to these rules;
e. “Joint Committee’’ means the Joint Committee constituted under subsection(1) of section 9;
f. “Section’’ means a section of the Act.

*

Published in the Gazette of India, Extraordinary, Part I, Section 3, dated the 6 th April, 1957.

<!-- page 22 -->

ROUTES FOR THE PERFORMANCE OF ANY JOURNEY
3. (i) Subject to the other provisions of these rules, the railway fare referred to in clause (a) of
sub-section (1) of section 4 of the Act shall be calculated by the shortest route, i.e., the route
by which a Members may most speedily reach his destination. When more routes than one
are equally short, the fare shall be calculated by the cheapest route.
(ii) Where the shortest route is temporarily closed, the extra fare may be allowed by the next
quickest route.
1

[(iii) Where it is not convenient for a Member to travel by the shortest route, he may travel
by any route more convenient to him, and in such a case the railway fare shall be calculated
by the route by which he actually travelled:
Provided that where the difference between the fare by the shortest route and the fare by the
route by which he actually travelled exceeds sixty rupees, the difference in fare payable to the
Member shall be limited to sixty rupees.]
[(iv)The ‘second class fare’ referred to in clause (a) of sub-section (1) of section 4 of the Act
shall be calculated at the rates prescribed for journeys by mail trains irrespective of the train
in which the Member actually travels.]
2

3

[3A. 3a{(1) The Member is entitled to receive travelling allowances in respect of journey
performed by air in any airlines.
(IA) The air fare referred to in clause (b) of sub-section (1) of section 4, or in clause (b) of
sub-section (1), and sub-section (2) of section 5 shall be calculated by the direct route:
Provided that where there are more routes than one, the airfare shall be calculated by
the route by which a Member may reach his destination at the earliest.}
(2) Where the direct route is temporarily closed, or there is no service on a particular day,
and the journey is performed by the Member by the next cheapest route, the airfare shall be
allowed by that route.
(3) Where it is not convenient for a Member to travel by the direct route, he may travel by
any route more convenient to him and in such a case, he shall be allowed an amount which is
equal to --

1

Inserted by S.R.O. 342, published in the Gazette of India, Extraordinary, Part II, Section 3,
dated the 25th January, 1958.
2

Inserted by G.S.R. 1285, published in the Gazette of India, Extraordinary Part II, Section 3
sub-section (i), dated the 24th November, 1959.
3

Inserted by G.S.R. 338(E), published in the Gazette of India, Extraordinary, Part II Section
3, sub-section (i), dated the 2nd July, 1973.
3a

Inserted by G.S.R. 702 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 26th October, 2004.

<!-- page 23 -->

(i)

the air fare by the route by which he had actually travelled, or

(ii)
the air fare by the direct route plus a sum of rupees 3b[two hundred and fifty],
whichever is less.
3c

[ Provided that a Member of Parliament shall be entitled to travel by any other route to
avoid inconvenience to reach his destination on the same day when connected flights are not
available by the shortest route, subject to the permission of the Speaker, Lok Sabha or
Chairman, Rajya Sabha as the case may be.]
(4) Where a Member travels by a circuitous air-cum-rail route he shall be allowed travelling
allowance under section 4 for the journey actually performed air-cum-rail or the travelling
allowance by air by the direct route, whichever is less:
Provided that where the air portion of the journey performed is less than half the total
distance by the direct route, the travelling allowance by air shall be allowed for the distance
actually travelled by air and for the remainder of the journey, travelling allowance by rail
shall be allowed by working out the total rail mileage by the direct route from the starting
point to the destination and reducing there from the rail mileage from the starting point upto
the place a Member travelled by air.
3d

(5) (a)

Where the journey by air is performed by(i) a member under section 4, section 5 or section 6C;
(ii) the spouse of the member under section 6B; or
(iii) an attendant of the member under section 6D,
the member shall submit self attested travelling allowance claim
alongwith air journey tickets and boarding passes, online.
(b) Submission of online boarding passes shall be allowed both for
official journeys as well as for personal air journeys of members.
(c) If a member misplaces boarding passes, etc., a self-declaration
certificate may be submitted alongwith travelling allowance bills for
having performed the journey.
(d) If online submission is not feasible, member may submit travelling
allowance bills alongwith all requisite documents in physical form.
(e) All documents submitted online or in physical form shall be verified
from the concerned airlines.”.

3b

Substituted by G.S.R. 1091 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 25th November, 1988.
3c

Inserted by G.S.R. 539 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section
(i), dated the 31st August, 1998.
3d

Substituted by G.S.R. 348 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 11th May, 2022.

<!-- page 24 -->

MANNER IN WHICH FRACTIONS OF A DAY SHOULD BE DEALT WITH FOR THE PURPOSE OF
DETERMINING THE DAILY ALLOWANCE ADMISSIBLE FOR THE DAY.
4. Daily allowance shall be admissible to a Member for each day of residence on duty
irrespective of the time of arrival or departure.
3e

[4A. Every Member shall be entitled to receive road mileage allowance at the rate of
{rupees sixteen per kilometer} for the journey or any part thereof performed by road for the
purpose of sub-clause (ii) of clause (c) of sub-section (1) of section 4 of the Act:
3f

Provided that in respect of journey from the usual place of residence in Delhi to the
Delhi airport and vice-versa the minimum amount shall be Rs. 120].
ADMISSIBILITY OF TRAVELLING ALLOWANCE WHERE A MEMBER IS
PROVIDED WITH FREE TRANSIT FOR THE WHOLE OR ANY PART OF A
JOURNEY.
5. No travelling allowance under section 4 shall be claimed by a Member in respect of any
journey or part thereof performed by him in a conveyance provided at the expense of the
Government of India or a State Government or a local Fund but he shall be entitled to draw
an allowance at the rate or Rs. 5.25 (Rupees five and paise twenty-five) only per diem, where
the duration of such journey lasts for not less than six hours on any day:
Provided that the provisions of the rule shall not apply to a journey performed on any
railway.
Note -- The amount of Rs. 5.25 is granted to the Member to cover his incidental expenses
during such journeys or parts thereof, and is in lieu of the extra air or steamer fares or road
mileage when he performs the journey by a conveyance supplied without charge. This
allowance is not an alternative to the daily allowance of 4(two thousand rupees per diem)
which is allowed to him for each day of residence on duty.
ADMISSIBILITY OR TRAVELLING ALLOWANCE WHERE THE PLACE FROM WHICH A MEMBER
COMMENCES HIS JOURNEY OR TO WHICH HE RETURNS IS NOT HIS USUAL PLACE OF
RESIDENCE

6. Where a Member performs a journey for the purpose of attending a session of a House of
Parliament or a meeting of a Committee or for the purpose of attending to any other business
connected with his duties as a Member from a place, other than his usual place of residence
or returns to such place, he may draw travelling allowance for the actual journey performed
or the journey from or to his usual place of residence whichever is less.
3e

Substituted by G.S.R. 572 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 25th August, 1993
3f

Substituted by G.S.R. 968 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 13th December, 2010
4

Substituted by G.S.R. 968 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 13th December, 2010.

<!-- page 25 -->

5

[6A. Where during a Session of a House of Parliament or a sitting of a committee a Member
performs a journey from the place where such session or sitting is held to any other place for
the purpose of attending to any business connected with his duties as a Member, he shall be
entitled to receive–
a. travelling allowance, in respect of such journey to such other place and for the
return journey, at the rates specified in section 4, and
b. daily allowance for each day during any period of residence on duty at the
other place at the rate specified in section 3.]
6

[*

*

*

*]

GENERAL RULES REGULATING THE PAYMENT OF DAILY AND TRAVELLING
ALLOWANCES UNDER THE ACT

8. Every Member shall, as soon as possible after he is elected or nominated, declare his usual
place of residence to the Controlling Officer, and any subsequent change in the usual place of
residence so declared shall be notified to the Controlling Officer in Form ‘A’ as early as
possible.
9. Notwithstanding that a Member has not taken his seat in a House of Parliament to which he
is elected or nominated, he shall be entitled to receive travelling allowance for the journey
performed by him for the purpose of taking his seat in the House.
10. (1) For absence for a period of 15 days or more during a session of a House of Parliament
or a meeting of a Committee for visiting any place in India, no travelling or daily allowance
will be admissible. The period of absence of a Member shall be reckoned in terms of days
beginning and ending at midnight.
Explanation -- If a Member comes back on the 15th day, whether in the forenoon or in the
afternoon, his absence shall be treated as being less than 15 days.
(2) The term ‘during a session’ or ‘a sitting of a Committee’ occurring in section 5 and subrule (1) of this rule does not include a period of three days immediately preceding the
commencement of and three days immediately succeeding the end of the session or two days
immediately preceding the commencement of the business and two days immediately
succeeding the conclusion of the business of the Committee:

5

Inserted by G.S.R. 1179, published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section
(i), dated the 15th September, 1961.
6

Omitted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section
(i), dated the 19th April, 1971.

<!-- page 26 -->

7

[Provided that nothing in this rule shall apply to availing of 7a(thirty four) single air journey
during any year from any place in India to any other place in India in terms of the provision
of sub-section (2) of section 5 of the Act].
7b

[*

*

*

*

*]

12. If a Member leaves the place where a session of a House of Parliament or a sitting of a
Committee is held before the commencement of the interval between the adjournment of the
session or the sitting of a Committee sine die and the Commencement of another session or
sitting, such interval not exceeding a period of seven days, his absence from that place shall
be treated as intermediate absence during a session of a House or a sitting of a Committee, as
the case may be and the provisions of section 5 shall apply accordingly.
13. Travelling allowance for a return journey to the usual place of residence shall be
admissible to a Member who leaves the place of a session of a House of Parliament or a
sitting of a Committee during the continuance of such session or sitting and returns to the
place of the session or sitting after the conclusion of the business of the session or the sitting,
as the case may be, before finally returning to his usual place of residence.
14. All cases regarding the admissibility of travelling allowance to a Member whom arrives
at the place where a session of a House of Parliament or a sitting of a Committee is held,
without knowledge of the postponement of the session or the Sitting, including cases of such
Members as arrive after the session or the sitting is adjourned suddenly shall be determined
by the Speaker of the House of the People or the Chairman of the Council of States, as the
case may be, having regard to the circumstances of each case.
15. Where a Member is provided with free board and lodging at the expense of the
Government of India or a State Government or a Local Fund, he shall be entitled to receive
only one-half of the daily allowance admissible to him under section 3. If only board or
lodging is allowed free to a Member, he shall be entitled to receive three-fourths of the daily
allowances admissible to him under that section.
16. (1) Where a Member loses his 8[Identity Card-cum-Railway Pass or Spouse’s Railway
Pass ] and a duplicate thereof is required to be issued to him, he shall make an application to
the Speaker of the House of the People or the Chairman of the Council of States, as the case
may be, explaining the circumstances under which the loss occurred and if the Speaker or the

7

Inserted by G.S.R. 520 (E), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 21st May, 1987.
7a

Substituted by G.S.R. 745 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 12th December, 2006 effective from 15.9.2006.
7b
Rule 11 shall be omitted by G.S.R. 1280, published in the Gazette of India, Extraordinary,
Part II, Section 3, sub-section (i), dated the 31st October, 1960.
8
Substituted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section (i), dated the 19th April, 1971.

<!-- page 27 -->

Chairman, as the case may be, is satisfied, a duplicate 9[Identity Card-cum-Railway Pass or
Spouse’s Railway Pass] shall be issued to the Member.
(2) 10[Where a Member/Spouse travels by rail without his (Identity Card-cum-Railway
Pass /Spouse’s Railway Pass) he shall be governed by the ordinary railway rules in regard to
such travel.]
11

[16A. (1) Where a Member loses his Steamer Pass or the Spouse's Steamer Pass and a
duplicate thereof is required to be issued to him, he shall make an application to the Speaker
of the House of the People or the Chairman of the Council of States, as the case may be,
explaining the circumstances under which the loss occurred and if the Speaker or the
Chairman, as the case may be, is satisfied a duplicate Steamer Pass or the Spouse's Steamer
Pass , shall be issued to the Member.
(2) Where a Member or his Spouse travels by steamer without the Steamer Pass, he
shall be governed by the ordinary rules in regard to such travel.]
17.
(1) Whenever a Member undertakes a journey by using the railway pass provided
under section 6, he shall fill in a Member’s Railway Journey Form as set out in Form ‘B’
before the commencement of the journey and hand over the form to the railway ticket,
collecting stall on the termination of the journey at the detraining station. For this purpose, a
booklet containing twenty-five machine-numbered copies of Form ‘B’ shall be supplied to
each Member.
(2) Whenever a Member wants to reserve accommodation on the railway, he shall fill
a form as set out in Form ‘C’.
12

[17-A. Whenever the spouse of a Member undertakes a journey by using the railway pass
provided under 13[Section 6B], a railway journey form as set out in Form B-I shall be filled in
by the Member before the commencement of the journey. The form so filled shall be handed
over to the railway ticket-collecting staff on the termination of the journey at the detraining
station. For this purpose, a booklet containing machine numbered copies of Form B-I to be
used by the spouse of the Member, shall be supplied to a Member, on request].

9

Substituted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section (i), dated the 19th April, 1971.
10
Substituted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section (i), dated the 19th April, 1971.
11

Inserted by G.S.R. 243(E), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section(i), dated the 10th May, 1973.

12

Inserted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i), dated the 19th April, 1971, effective from 21.8.1969.
13
Substituted by G.S.R. 243(E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 10th May, 1973.

<!-- page 28 -->

14

[17-B. Whenever a person accompanies the Member, when he travels by rail, by using the
railway pass provided under 15[Section 6B], a railway journey form as set out in Form B-II
shall be filled in by the Member before the commencement of the journey. The form so filled
shall be handed over to the railway ticket-collecting staff on the termination of the journey at
the detraining station. For this purpose, a booklet containing twenty-five machine-numbered
copies of Form B-II shall be supplied to each Member.]
16

[17-C.Whenever a Member undertakes a journey by using the Steamer Pass provided under
Section 6A, he shall fill in a Member’s Steamer Journey Form as set out in Form B-III before
the commencement of the journey and hand over the form to the Master of the Vessel on the
completion of the voyage. For this purpose, a booklet containing twenty-five machinenumbered copies of Form B-III shall be supplied to the Member concerned.
17-D. Whenever the spouse of a Member undertakes a journey by using the Steamer Pass
provided under section 6A, a Steamer Journey Form as set out in Form B-IV shall be filled in
by the Member before the commencement of the journey. The form so filled shall be handed
over to the Master of the Vessel on the completion of the voyage. For this purpose, a booklet
containing twenty-five machine-numbered copies of Form B-IV to be used by the spouse of
the Member, shall be supplied to the Member, on request.
17-E. Whenever a person accompanies a Member, when he travels by steamer by using the
Steamer Pass provided under section 6-A, a Steamer Journey Form as set out in Form B-V
shall be filled in by the Member before the commencement of the journey. The form so filled
shall be handed over to the Master of the Vessel on the completion of the voyage. For this
purpose, a booklet containing twenty-five machine-numbered copies of Form B-V shall be
supplied to the Member.]
16a

[17-F.(1) A member who is so physically incapacitated as to require an attendant to
accompany him by air shall, along with his application addressed to the Chairman of the
Council of States or the Speaker of the House of the People, as the case may be, append
therewith a certificate from a panel of doctors of Dr. Ram Manohar Lohia Hospital, New
Delhi, certifying the nature of incapacity whether permanent or temporary.
(2) If the nature of the incapacity is temporary, the period of such in capacity shall be
specified and shall not initially exceed six months.
(3) If the Member feels that an attendant is required for travel by air along with him
even after the period referred to in sub-rule (2), the Member shall appear again before the

14

Inserted by G.S.R. 1785, published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section (i), dated the 29th November, 1971.
15
Substituted by G.S.R. 243(E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 10th May, 1973.
16
Inserted by G.S.R. 243(E), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section (i), dated the 10th May, 1973.

16a

Inserted by G.S.R. 611(E), published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section (i),
dated the 2nd November, 1979.

<!-- page 29 -->

panel of doctors referred to in sub-rule(1) for obtaining a certificate to which the provisions
of sub-rule (2) shall apply.]
17

[18. (1) Travelling Allowance Bill for any return journey of the nature referred to in subsection (1) of section 4 of the Act may be paid to a Member not more than seven days in
advance of the date on which the journey is to be performed by him:
Provided that in case the Member does no subsequently perform the journey on such
date, the amount of the travelling allowance taken in advance shall be refunded forthwith.
(2) A bill on account of daily allowance is payable only up to the date of the
presentation of the bill.]
18

[18A. Where the journey or any part thereof is performed by a casual steamer, the member
may be allowed to draw an amount equal to one and three-fifths of the fare(without diet) for
the highest class in the steamer for each such journey or part thereof. Where the journey or
part thereof is performed by sea or river in a steam launch or in any vessel other than a
steamer, mileage at the rate of 19(0.32 paise per kilometer) may be paid to the Member for
each such journey or part thereof.]
19a

[18B. (1) Every Member shall, as soon as he is elected or nominated to either House of
Parliament, lodge with the Secretariat of the concerned House of Parliament a nomination in
Form ‘E’ stating the particulars of the nominee who shall in the event of such Member’s
death be entitled to receive the salary, additional facilities, allowances, travelling allowance,
daily allowance, medical reimbursement claims and any other allowances and claims
whatsoever payable to such Member, under the provisions of the Act and the rules framed
thereunder for the time being in force, and which remain unpaid to him at the time of his
death.
(2) Every nominee under sub-rule (1) shall, before claiming payment, furnish a bond
in Form ‘F’ to the Secretariat of the House to which the deceased Member was elected or
nominated.]

FORM OF CERTIFICATES TO BE FURNISHED BY MEMBER FOR THE PURPOSE OF CLAIMING
ALLOWANCES UNDER THE ACT
19. A Member who claims any travelling or other allowances under these rules shall support
his claim by a Certificate in the following form, namely:-

17

Substituted by S.R.O. 342, published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section
(i),dated the 24th January, 1958.
18

Inserted by G.S.R. 1286, published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section (i),
dated the 24th November, 1959.
19

Substituted by G.S.R. 243(E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 10th May, 1973.
19a
Inserted by G.S.R. 239(E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 1st March, 1982.

<!-- page 30 -->

20

[I certify that the information given by me is true to the best of my knowledge. I have
not claimed the TA/DA from any other official source for the period mentioned in this
Bill.]
21
[ *
*
*
* ]
23. (1) Whenever any Government dues, such as house rent, telephones dues, are reported to
be outstanding against a Member and appropriate claims or bills in support thereof are
received from the authority concerned, an amount equivalent to such dues shall be deducted
from the next salary, or travelling and daily allowances bills to be prepared for and on behalf
of the Member and the balance shall be paid to him.
(2) Ordinarily any non-Governmental dues outstanding against a Member shall not be
recovered from his salary or allowances but where such dues are on account of certain
services rendered to him in the course of his parliamentary duties such as, when he is on tour
with a Parliamentary Committee and the arrangements for such services have been made by
or at the instance of semi-Government institutions or private parties at the request of officers
of the Lok Sabha or the Rajya Sabha Secretariat and where such Member in spite of repeated
requests had failed to make payment of such dues, recovery thereof may be effected from the
salary or travelling or daily allowance bills of such Member.
24. If any question arises as to the interpretation of these rules, the question shall be referred
to the Joint Committee and its decision thereon shall be final.
[F-14-MSA/56]

20

Substituted by G.S.R. 383(E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section (i), dated the 30th August, 1996.
21
Rules 20, 21 and 22 shall be omitted by G.S.R. 383 (E), published in the Gazette of India,
Extraordinary, Part II, Section 3, sub-section (i), dated the 30th August, 1996.

<!-- page 31 -->

Form ‘A’
[ See Rule 8 ]
I have changed my usual place of residence from………………………………………………
…………………………..………………to……………………………………………………
with effect from………………………………due to ………………………………………….
(Here state the reasons)

I may hence forward be allowed travelling allowances
from…………………………………………………………………

(Signature)…………………………….
(Division No.)…………………………
(Date)…………………………………..

<!-- page 32 -->

[Form ‘B’]
[See Rule 17 (1)]
22

No.

No.

Lok Sabha Secretariat
Rajya Sabha Secretariat

Lok Sabha Secretariat
Rajya Sabha Secretariat

MEMBER‘S RAILWAY
JOURNEY FORM
______________

MEMBER’S RAILWAY
JOURNEY FORM
______________

BOOK FOIL

FOIL

I am travelling by class*……………………

I am travelling by class*……………………

From…………………………………………

From…………………………………………

Station to…………………………………….

Station to…………………………………….

Station via……………………………………

Station via……………………………………

23

and have commenced my journey
on…………………………………………..

23

accompanied/unaccompanied by one person
in first class.

accompanied/unaccompanied by one person
in first class.

My identity Card-cum-Railway
Pass No. is…………………………………...

My identity Card-cum-Railway
Pass No. is…………………………………...

Div. No………………………………….

Div. No………………………………….

Member,

Lok Sabha
Rajya Sabha

and have commenced my journey
on…………………………………………..

Member,

Lok Sabha
Rajya Sabha

22

Substituted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 19th April, 1971, effective from the 21st August, 1969.
23

Substituted by G.S.R. 1785, published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section
(i), dated the 29th November, 1971.

<!-- page 33 -->

*I/II/III AC III/Sleeper coach, etc.
[To be retained by Member]

*I/II/III AC III/Sleeper coach, etc.
[To be handed over to the Railway ticket
collecting staff on the termination of the
journey]

<!-- page 34 -->

[Form ‘B-1']
[See Rule 17-A]
24

No. ……………………………..

No. ……………………………..

Lok Sabha Secretariat
Rajya Sabha Secretariat

Lok Sabha Secretariat
Rajya Sabha Secretariat

SPOUSES RAILWAY
JOURNEY FORM

SPOUSES RAILWAY
JOURNEY FORM

BOOK FOIL

FOIL

My wife/husband, Shrimati / Shri …………..
……………………..…………..is travelling
by………………………………...*class from
……………………………..(usual place of
residence ) to Delhi/New Delhi & from
Delhi/New Delhi to …………………
…………………………………………(usual
place of residence) via………………………
commencing the journey on………………..
in respect of ………………………..Session,
Lok Sabha/Rajya Sabha.
My Identity Card-cum-Railway Pass no.
is……….……………………………………
My spouse’s Railway Pass No.
is………………... ………………………….
Div. No. …………..

My wife/husband, Shrimati / Shri …………..
……………………..…………..is travelling
by………………………………...*class from
……………………………..(usual place of
residence ) to Delhi/New Delhi & from
Delhi/New Delhi to …………………
…………………………………………(usual
place of residence) via………………………
commencing the journey on………………..
in respect of ………………………..Session,
Lok Sabha/Rajya Sabha.
My Identity Card-cum-Railway Pass no.
is……….……………………………………
My spouse’s Railway Pass No.
is………………... ………………………….
Div. No. …………..

Member,

Member,

Lok Sabha
Rajya Sabha

Lok Sabha
Rajya Sabha

[To be retained by Member and returned to
Lok Sabha/Rajya Sabha Secretariat]

[To be handed over to the Railway ticket
collecting staff on the termination of the
journey]

*I/II/III AC III/Sleeper coach, etc.

*I/II/III AC III/Sleeper coach, etc.

24

Inserted by G.S.R. 573, published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section
(i), dated the 19th April, 1971 effective from the 21st August, 1969.

<!-- page 35 -->

[Form ‘B-II’]
[See Rule 17-B]
25

No. ………………………………………..

No…………………………………..

Lok Sabha Secretariat
Rajya Sabha Secretariat

Lok Sabha Secretariat
Rajya Sabha Secretariat

RAILWAY JOURNEY FORM FOR
THE USE OF ONE PERSON TO
ACCOMPANY THE MEMBER OF
PARLIAMENT

RAILWAY JOURNEY FORM FOR THE
USE OF ONE PERSON TO
ACCOMPANY THE MEMBER OF
PARLIAMENT

BOOK FOIL

FOIL

Certified that Shri/Shrimati………………
………………………………………who
is accompanying me has travelled
from…….
……………………..
(Station)
to
………………………………..
(Station)…...
in
I
class,
via
………………………………..
Commencing
the
Journey
on
………20…….

Certified that Shri/Shrimati………………
………………………………………….who
is accompanying me has travelled
from…….
…………………….. (Station) to
…………… ………………………………..
(Station)…... in I class, via
………………………………..
Commencing the Journey on
………20…….

My Identity Card-cum-Railway Pass
No. is……………………………………

My Identity Card-cum-Railway Pass
No. is ………………………………………

Div. No. …………….

Div. No. …………….

Member,

Member,

Lok Sabha
Rajya Sabha

[To be retained by Member and returned to
Lok Sabha/Rajya Sabha Secretariat after
use.]

25

Lok Sabha
Rajya Sabha

[To be handed over to the Railway ticket
collecting staff on the termination of the
journey]

Inserted by G.S.R. 1785, published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 29th November, 1971.

<!-- page 36 -->

<!-- page 37 -->

[Form ‘B-III’]
[See Rule 17-C ]
26

No. ………………………………………..

No…………………………………..

Lok Sabha Secretariat
Rajya Sabha Secretariat

Lok Sabha Secretariat
Rajya Sabha Secretariat

MEMBER’S STEAMER JOURNEY
FORM

MEMBER’S STEAMER JOURNEY
FORM

BOOK FOIL

FOIL

I am travelling by………………………...class
(without diet) from …………………………...
…………………………………………(Port)
to ….…………………………………... (Port)
and have commenced my journey on…………
…………20………….
My Steamer Pass No. is ………………..……

I am travelling by………………………...class
(without diet) from …………………………...
…………………………………………(Port)
to ….…………………………………... (Port)
and have commenced my journey on…………
…………20………….
My Steamer Pass No. is ………………..……

Div. No. …………….

Div. No. …………….

Member,

Lok Sabha
Rajya Sabha

[To be retained by Member and returned to
Lok Sabha/Rajya Sabha Secretariat after use.]

26

Member,

Lok Sabha
Rajya Sabha

[To be handed over to the Master of the vessel
on the completion of the voyage.]

Inserted by G.S.R. 243 (e), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 10th May, 1973.

<!-- page 38 -->

[Form ‘B-IV’]
[ See Rule 17-D]
27

No. ………………………………………..

No…………………………………..

Lok Sabha Secretariat
Rajya Sabha Secretariat

Lok Sabha Secretariat
Rajya Sabha Secretariat

SPOUSE’S STEAMER JOURNEY
FORM

SPOUSE’S STEAMER JOURNEY
FORM

BOOK FOIL

FOIL

My wife/husband, Shrimati/Shri……………
……………………………………………is
travelling by ……………...class (without diet)
from…………………………………………...
(usual place of residence of Member/nearest
port in the mainland of India) to ……………..
…………………………(nearest port in the
mainland of India/ usual place of residence of
Member commencing the Journey on…………
in respect of…………………Session.
My Steamer Pass No. is ………………..……
My Spouse's Steamer Pass No. is …………...

My wife/husband, Shrimati/Shri……………
……………………………………………is
travelling by ……………...class (without diet)
from…………………………………………...
(usual place of residence of Member/nearest
port in the mainland of India) to ……………..
…………………………(nearest port in the
mainland of India/ usual place of residence of
Member commencing the Journey on…………
in respect of…………………Session.
My Steamer Pass No. is ………………..……
My Spouse's Steamer Pass No. is …………

Div. No. …………….

Div. No. …………….

Member,

Member,

Lok Sabha
Rajya Sabha

[To be retained by Member and returned to
Lok Sabha/Rajya Sabha Secretariat after use.]

27

Lok Sabha
Rajya Sabha

[To be handed over to the Master of the vessel
on the completion of the voyage.]

Inserted by G.S.R. 243 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section
(i), dated the 10th May, 1973.

<!-- page 39 -->

[Form ‘B-V’]
[See Rule 17—E]
28

No. ………………………………………..

No…………………………………..

Lok Sabha Secretariat
Rajya Sabha Secretariat

Lok Sabha Secretariat
Rajya Sabha Secretariat

STEAMER JOURNEY FORM FOR
THE USE OF ONE PERSON TO
ACCOMPANY THE MEMBER OF
PARLIAMENT

STEAMER JOURNEY FORM FOR
THE USE OF ONE PERSON TO
ACCOMPANY THE MEMBER OF
PARLIAMENT

BOOK FOIL

FOIL

Certified that Shri/Shrimati………………
………………………………………who
is accompanying me has travelled from
……. …………………………….(Port)
to ………………………………...(Port) in
the lowest class (without diet) commencing
the Journey on ………20…….
My Steamer Pass No. is …………………
Div. No. …………….

Certified that Shri/Shrimati………………
………………………………………who
is accompanying me has travelled from
……………………………………….(Port)
to ………………………………...(Port) in
the lowest class (without diet) commencing
the Journey on ………20…….
My Steamer Pass No. is …………………
Div. No. …………….

Member,

Member,

Lok Sabha
Rajya Sabha

[To be retained by Member and returned to
Lok Sabha/Rajya Sabha Secretariat after
use.]

28

Lok Sabha
Rajya Sabha

[To be handed over to the Master of the
Vessel on the completion of the voyage]

Inserted by G.S.R. 243 (E), published in the Gazette of India, Extraordinary, Part II,
Section 3, sub-section
(i), dated the 10th May, 1973.

<!-- page 40 -->

[Form ‘C’]
[See Rule 17 (2)]
LOK SABHA
RAJYA SABHA
To
The Station Superintendent/Master,
……………………………………

Please reserve one --------------------class berth for my journey ex..………..…..
to…………… by train No. ………………………………on…………………………

Signature…………….
Lok Sabha
Member ------------------Rajya Sabha
Identity Card-cum-Rly. Pass No……………………………….
Division No………………………………
Address…………………………….....
…………………………….....
……………………………….

<!-- page 41 -->

[Form ‘D’]
Departure and Return Journey Certificate
I certify that the information given by me is true to the best of my knowledge. I have
not claimed the TA/DA from any other official source for the period mentioned in this Bill
29

Signature…………………………..
Name…………………………..
Member: Rajya Sabha/Lok Sabha…………………………..
I.C. No……………………….......

29

Inserted by G.S.R. 383(E), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 30th August, 1996.

<!-- page 42 -->

*

[FORM‘E’]
[See Rule 18B (1)]
NOMINATION FORM
(To be filled in duplicate)
I,……………………………………Member of Lok Sabha/Rajya Sabha hereby nominate the
person(s) mentioned below who is/are member(s) of my family and confer on him/them the
right
to
receive
Salary/ **[Additional
Facilities,
Allowance/Travelling/Daily
Allowance/Medical Reimbursement Claims and any other allowances and claims whatsoever
which becomes due to me from the Lok Sabha/Rajya Sabha Secretariat and remain unpaid to
me in the event of my death.
ORIGINAL NOMINEE
ALTERNATIVE NOMINEE
Name and
Relationship
Age
Name and
Relationship
Age
Address of
with Member
address of
with member
nominee
nominee

Dated this ……………………… day of…………………. 20………….. at……….…
Witness to signature:
1……………………………..
Name…………………………
Address…………………………
2…………………………………
Name……………………………
Address………………………..

Signature of Member
Name………………….………
Serial No………………………
DIVISION NO………………..

Note: The member is advised that it would be in the interest of his nominee of copies of the
nominations and related notices and acknowledgements are kept in safe custody so that they
may come into the possession of the beneficiaries in the event of his death.
*

Inserted by G.S.R. 239 (E), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 1st March, 1982.
**

Now Constituency Allowance.

<!-- page 43 -->

*

[FORM‘F’]
[See Rule 18B (2)]
FORM OF BOND OF INDEMNITY FOR DRAWING ARREARS OF SALARY,
**
ADDITIONAL FACILITIES ALLOWANCE, TRAVELLING AND DAILY
ALLOWANCES, MEDICAL REIMBURSEMENTCLAIM AND ANY OTHER
ALLOWANCES AND CLAIMS WHATSOEVER DUE TO A DECEASED
MEMBER OF LOK SABHA/RAJYA SABHA.

WHEREAS …………………………………………………………………was at the time of
his death a Member of Lok Sabha/Rajya Sabha (name of deceased) and there was due to him
a sum of Rupees……………………(for Salary, **Additional Facilities Allowance, Travelling
and Daily Allowances and Medical Reimbursement Claim in respect of his said office)
AND WHEREAS the above bounder…………………………………………………………..
(name of claimants)
(Hereinafter called the Claimant) claims to be entitled to the said sum as heir/heiress of the
said………………………………………………………………..(Name of deceased)
but has not obtained letters of administration or of a succession certificate to the property
and effects of the said …………………………………………(name of deceased) including
the said sum of Rs………………………Rupees……………………………………………
AND WHEREAS the claimant has satisfied the Lok Sabha/Rajya Sabha Secretariat that
he/she is entitled to the aforesaid sum and that it would cause undue delay and hardship if the
claimant were required to produce letters of administration or of a succession certificate to
the property and effects of the said…………………………………………(name of
deceased)
including
the
said
sum
of
Rs……………………………….
Rupees……………………….......................
AND WHEREAS the Lok Sabha/Rajya Sabha Secretariat desire to pay the sum of
Rs…………………………….Rupees…………………….. to the claimant but require the
claimant first to execute a bond with one surety/two sureties to indemnity and keep
indemnified and harmless the Lok Sabha/Rajya Sabha Secretariat against all claims to the
sum of Rs……………….(Rupees…………….) due as aforesaid to the said
………………………(name of deceased) before the said sum can be paid to the claimant.
KNOW ALL MEN by these presents that I…………………………………………………….
*

Inserted by G.S.R. 239 (E), published in the Gazette of India, Extraordinary, Part II, Section
3, sub-section
(i), dated the 1st March, 1982.
**

Now Constituency Allowance.

<!-- page 44 -->

(Full name of claimant with place or residence) (State relationship to the deceased)and I/We
……………………………..(Full name of claimant) with sureties for him/her are held firmly
bound
to
the
President
of
India
in
the
sum
of
Rs…………..
……….Rupees……………………………………… to be paid to the President, FOR
WHICH Payment to be well and truly made each of us jointly and severally binds himself
and his heirs, executors, administrators and assigns firmly by these presents;
PROVIDED
that
if
after
payment
of
the
said
sum
of
Rs……………………Rupees…………………………………………..has been made to the
Claimant, the Claimant or the surety/sureties shall, in the event of a claim being made by any
other person(s) against the Lok Sabha/Rajya Sabha Secretariat with respect of the aforesaid
sum of Rs………..……………….Rupees…………………………………… or any party
thereof pay, or cause to be paid, the said sum or such party thereof as may be the subject of
claim by third person(s) or shall otherwise indemnify and save the Lok Sabha/Rajya Sabha
Secretariat harmless from all liability in respect of the aforesaid sum and all cost and
expenses incurred in consequence of any such claim thereto THEN the above written bond or
obligation shall be void BUT OTHERWISE the same shall remain in full force and virtue.
IN WITNESS WHEREOF WE
WITNESS (1)…………………………………………………..(Claimant above named)
WITNESS (2)…………………………………………………..(Surety above named)
WITNESS (3)…………………………………………………..(Surety above named)
have hereunto set our hands this ………day of………………………….20……………..
[F.11/3/MSA/80]

<!-- page 45 -->

Chapter 3
THE HOUSING AND TELEPHONE FACILITIES (MEMBERS OF
PARLIAMENT) RULES, 1956
S.R.O. 1973.—In exercise of the powers conferred by clause (f) of sub-section (3) of
section 9 of the Salary and Allowances of Members of Parliament Act, 1954 (No. 30 of
1954), the Joint Committee constituted under sub-section (1) of that section hereby makes the
following rules, the same having been approved and confirmed by the Chairman of the
Council of States and the Speaker of the House of the People, as required by sub-section (4),
of the said section, namely:—
THE HOUSING AND TELEPHONE FACILITIES (MEMBERS OF PARLIAMENT)
RULES, 1956
(As amended upto 1st April, 2018)
1. Short title and commencement.—(1) These Rules may be called the Housing and
Telephone Facilities (Members of Parliament) Rules, 1956.
(2) These rules shall be deemed to have come into force on the 1st day of April, 1955.
2. 1[Facilities of Housing etc. to Members.—(1) Each Member shall be entitled without
payment of 1a[licence fee] to housing accommodation in the form of a flat throughout his
term of office:
1b

[Provided that where a member is allotted housing accommodation in the form of
bungalow at his request, he shall pay full normal licence fee if he is entitled to such
accommodation.]
1c

[Provided further that in case a member comes to Delhi immediately after he is declared
elected by the returning officer, prior to the notification in the Official Gazette for such
declaration under the provisions of the Representation of Peoples Act, 1951 (43 of 1951), he
shall be provided transit accommodation from the date of his arrival at Delhi till he is allotted
a Government accommodation in the form of flat or bungalow as the case may be.]
Explanation.—For the purposes of this sub-rule "Flat" includes hostel accommodation.
1d

[(2) Every Member shall in respect of any accommodation allotted to him under sub-rule
(1) or in respect of any private accommodation in Delhi in which he is residing also be
entitled without payment of charges to the supply of water and electricity upto a maximum of
1e
{50,000}
units
of
electricity
per
annum
[1f{25,000} units each of light/power meters or pooled together] and 1g[4000 kilolitres of
water per annum free of charge beginning first January of every year:


Published in the Gazette of India, Extraordinary, Part III, Section 3, dated the 8th May, 1956 (S.R.O. 1973).
Substituted by G.S.R. 13(E), published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section
(i) dated the 3rd January, 1986.
1a
Substituted by G.S.R. 1169(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 28th October, 1986.
1b
Substituted by G.S.R. 453(E), published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section
(i) dated the 13th May, 2000.
1c
Inserted by G.S.R. 701(E), published in the Gazette of India, Extraordinary, Part II, Section 3, sub- Section
(i) dated the 26th October, 2004.
1d
Substituted by G.S.R. 508 (E), published in the Gazette of India, Extraordinary, Part-II, Section 3, subsection (i), dated the 30th August, 1997.
1e
Substituted by G.S.R. 806 (E), published in the Gazette of India, Extraordinary, Part-II, Section 3,
sub-section (i), dated the 25th October, 2001.
1f
Substituted by G.S.R. 806 (E), published in the Gazette of India, Extraordinary, Part-II, Section 3,
1

<!-- page 46 -->

Provided that electricity may be supplied without payment of charge upto 1h(50,000) units
measured on light meter per annum, only to those Members of Parliament whose residence
have no power meters installed].
“Provided further that the electricity in units and water in kilolitres as admissible under
this sub-rule shall be calculated separately, if both husband and wife are members of either or
the same House of Parliament and are residing in the same accommodation:
1ha

Provided also that where a member does not consume the units of electricity and water in
kilolitres as admissible under this sub-rule in any year, the balance units of electricity and
water in kilolitres shall be carried over to the subsequent years till his seat becomes vacant:
Provided also that where a member consumes more than his entitled units of electricity
and water in kilolitres in a particular year, the excess units of electricity and water in
kiloliters so consumed by him shall be adjusted from units of electricity and water in
kilolitres available for the next year:
Provided also that in case the seat of a member becomes vacant due to resignation or
completion of terms, he shall be entitled to consume the balance units of electricity and water
in kilolitres as available for that year under this sub-rule within a maximum period of one
month from the date on which his seat becomes vacant.
(3) Where in respect of any accommodation referred to in sub-rule (1) 1i(licence fee) is
payable on account of any improvement or addition made to it or any additional service
provided thereto, it shall be twenty-five per cent less than the normal rent payable in respect
of such improvement, addition or additional service.
1j

[Provided that furniture shall be made available free of charge to the Members within the
existing monetary ceiling of rupees eighty thousand in respect of durable furniture and rupees
twenty thousand for non-durable furniture respectively, which shall be increased every five
years commencing from the 1st April, 2023, on the basis of Cost Inflation Index provided
under clause (v) of Explanation to section 48 of the Income-tax Act, 1961 (43 of 1961):
Provided further that where an additional provision such as tiles in bathroom and kitchen
as demanded and the facility of washing of sofa covers and curtains after every three months
the same shall be provided free of cost to the Members.]
1k

Provided that the rent for additional items of furniture shall be charged on the depreciated
value of the furniture so made available at the residence of a member.
Explanation I.—For the purposes of this sub-rule "improvement or addition" means the
provision of additional accommodation, furniture, table and pedestal fans, table lamps, floor
standard lamps, boilers, refrigerators, desert coolers and air-conditioning units.

sub-section (i), dated the 25th October, 2001.
Substituted by G.S.R. 806 (E), published in the Gazette of India, Extraordinary, Part-II, Section 3,
sub-section (i), dated the 25th October, 2001.
1h
Substituted by G.S.R. 806 (E), published in the Gazette of India, Extraordinary, Part-II, Section 3,
sub-section (i), dated the 25th October, 2001.
1ha
Inserted by G.S.R. 744(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 12th December, 2006.
1i
Substituted by G.S.R. 1169(E), published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i) dated the 28th October, 1986.
1j
Substituted by G.S.R. 301 (E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 28th March, 2018.
1k
Inserted by G.S.R. 744(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 12th December, 2006.
1g

<!-- page 47 -->

Explanation II.—"Furniture" means such items of furniture as are admissible to a member
for a residence allotted to him and includes any additional items taken on rent by a member in
his residence.
Explanation III.—"Additional service" means
(a) the provisions of Sweepers, Jamadars and the staff attached to members residences with
dusters and brooms;
(b) the supply of electric bulbs at the residences of members;
(c) the maintenance of flower beds;
(d) the maintenance of any place (like an Enquiry Office) intended for the common benefit
of members; and
(e) any other service provided for the common benefit of members.

<!-- page 48 -->

EXPLANATORY MEMORANDUM
AMENDMENT OF RULE 2 OF THE HOUSING AND TELEPHONE FACILITIES
(MEMBERS OF PARLIAMENT) RULES, 1956
Some difficulties had been experienced in the assessment of rent of residences allotted to
Members of Parliament as it was felt that Rule 2 of the Housing and Telephone Facilities
(Members of Parliament) Rules, 1956 did not cover the residences constructed for Members
of Parliament or added in the M.Ps. pool or resided after the 1st April, 1955. In practice,
however, the concession admissible to Members of Parliament regarding rent of residences as
envisaged in Rule 2 was also being allowed to Members who were allotted residences
constructed or added to the M.Ps. pool after the 1st April, 1955. With a view to overcoming
the difficulties experienced it was felt that the existing Rule 2 be suitably amended to cover
residences added to the M.Ps. pool or constructed for the M.Ps. pool after the 1st April,
1955. The amendment as notified is designed to meet the requirement. As the amendment is
to cover the residence for the purpose of allowing certain concessions to Members of
Parliament, no Member of Parliament is likely to be adversely affected by the issue of the
said amendment and giving it retrospective effect.
[No. F. 4/MSA/72-Vol. I]
2

[2.A. Retention of Government accommodation after the death of a Member.—In
the case of death of a member during the term of his office, the members of his family shall
be entitled to retain the accommodation on the 2a[same terms as were applicable to] the
member immediately before his death for a maximum period of 2aa[six months] after which
the allotment shall be deemed to be cancelled.]
2b

[Provided that the family of a deceased member shall be entitled to consume the balance
units of electricity and water in kilolitres available to such member for that particular year at
the residence allotted to him during his term of office within a period of one month from the
date of his death.”]
3. Remission in respect of transport charges. —The charges, if any, on account of the
transport of any items of furniture to/or from the residence of a Member made at his request
shall also be 25 per cent less than the actual charges otherwise payable in respect thereof
under the rules for the time being in force.
4. Exemption in respect of telephone charges.— 3[(1) No charges shall be payable by a
Member in respect of the installation and rental of one telephone installed either at his
residence or at his office in Delhi or New Delhi, and no Member shall be liable to make any
payment in respect of the first 4[Fifty thousand] local calls made from the telephone during
any year.].

2

2a

2aa

2b

3

4

Inserted by G.S.R. 299(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 29th May, 1972.
Substituted by G.S.R. 10(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 3rd January, 1986.
Substituted by G.S.R. 744 (E), published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i) dated the 12th December, 2006.
Inserted by G.S.R. 744 (E), published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i) dated the 12th December, 2006.
Re-numbered as sub-rule (1) of rule 4 by G.S.R. 1526, published in the Gazette of India, Extraordinary,
Part II, Section 3, sub-section (i), dated the 23rd December, 1960
Substituted by G.S.R. 508(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 30th August, 1997.

<!-- page 49 -->

5

[(2) In addition to the exemption in respect of telephone charges admissible under the
provisions of sub-rule (1), a Chairman of a Parliamentary Committee shall be exempted from
payment of any charges for calls made from the telephone installed at his residence in Delhi
or New Delhi.
Explanation.—In this sub-rule, a "Parliamentary Committee does not include a Select or
Joint Committee on a Bill or any other ad hoc Committee."]
6

[(3) Without prejudice to the provisions contained in sub-rule (1), no charges shall be
payable by a Member in respect of the installation and rental of one telephone installed either
at his usual place of residence, or at a place selected by him, being a place—
(i) situated within the State which he represents 7[or within the State in which he resides]
in the case of a member of the Council of States, other than a member nominated to
that House;
(ii) situated within the State in which his Constituency is 7a[or within the State in which he
resides] in the case of a member of the House of the People, other than a member
nominated to that House;
(iii) approved by the Chairman of the Council of States or the Speaker of the House of the
People, as the case may be in the case of nominated members; and
no Member shall be liable to make any payment in respect of the first 8[fifty thousand] local
calls made from that telephone during any year:
Provided that the place selected by the Member or approved by the Chairman or the
Speaker, as the case may be, shall be within the area of operation of an existing telephone
exchange.]
8a

[*

*

*

*

*

*

*

*

*

*

*

*]

8b

[(4) No charges shall be payable by a Member for an additional cord not exceeding ten
metres in length or a plug and socket added to a telephone installed under sub-rule (i) or subrule (3).]
8C

[(5) In addition to the exemption in respect of telephone charges admissible under the
provisions of sub-rule (1) and sub-rule (3), no charges shall be payable by a member in
respect of the installation and rental of one telephone installed,—
(a) at his office situated at his residence in Delhi or New Delhi; or
(b) at his usual place of residence; or
(c) at a place selected by him, within his constituency or State; or
5

6

7

7a

8

8a

8b

8c

Inserted by G.S.R. 1526, published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 23rd December, 1960
Inserted by G.S.R. 1842, published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 5th August, 1964.
Inserted by G.S.R. 830, published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section
(i) dated the 8th May, 1970.
Inserted by G.S.R. 830, published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section
(i) dated the 8th May, 1970.
Substituted by G.S.R. 508(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 30th August, 1997.
Omitted by G.S.R. 744(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 12th December, 2006.
Inserted by G.S.R. 1036, published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 12th July, 1971.
Inserted by G.S.R. 454 (E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 13th May, 2000.

<!-- page 50 -->

(d) within the State in which he resides for Internet connectivity purposes;
and no member shall be liable to make any payment in respect of the first fifty thousand
local calls from the telephone during a year.]
8d

[(6) A member, on his request, is entitled to avail one mobile phone connection of
Mahanagar Telephone Nigam Limited with national roaming facility and another mobile
phone connection of Mahanagar Telephone Nigam Limited or Bharat Sanchar Nigam
Limited with national roaming facility for utilisation in his constituency and no charges shall
be payable by him in respect of the registration and rental of such mobile phone connections:
Provided that the calls made by a member from such mobile phone connections shall be
adjusted from the total free local calls available to him under sub-rule (1), sub-rule (3) and
sub-rule(5):
Provided further that where services of Mahanagar Telephone Nigam Limited or Bharat
Sanchar Nigam Limited are not available for utilizing total free local calls available to him
under sub-rule (1), sub-rule (3) and sub-rule (5), he may avail such facility from any other
private mobile operator subject to the condition that the registration and rental charges for the
private mobile phone connection shall be borne by the member himself.
(7) A member may avail broadband facility from Mahangar Telephone Nigam Limited or
Bharat Sanchar Nigam Limited on any one telephone available to him under sub-rule (1),
sub-rule (3) or sub-rule (5), and shall not be liable to make payment upto a maximum of one
thousand five hundred rupees per mensem which shall be paid directly to Mahangar
Telephone Nigam Limited or Bharat Sanchar Nigam Limited, as the case may be, towards
charges for this facility.]
8e

[(8) With effect from the 1st August, 2006, a Member may avail broadband internet facility
with option either to have a maximum of hundred gigabyte (100 GB) data download at the
rate of 512 kilobits per second (kbps) speed against ten thousand surrendered call units per
annum with Rs. 0.50 paise per megabyte (MB) on every additional megabyte (MB)
consumed or unlimited data download at the rate of 256 kilobits per second (kbps) speed
against ten thousand surrendered call units per annum.
Explanation.- For the purpose of this sub-rule, the “broadband internet facility” shall
apply separately to each point where the Member would like to have a connection and
modality for provisioning of broadband connectivity on the existing landline connections of
Members shall be akin to the existing practice of provisioning of public switched telephone
network (PSTN) connections to them and the broadband connection shall be construed as
value added service on the existing public switched telephone line.]
8f

[(9) With effect from the 1st September, 2015, to the 31st December, 2016, a Member may
avail high speed broadband on the Fibre to the Home (FTTH) with wi-fi services at his
residence in Delhi from the Mahanagar Telephone Nigam Limited and shall not be liable to
make payment up to a maximum of rupees one thousand seven hundred per mensem, which

8d

8e

8f

Substituted by GSR 744(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i), dated the 12th December, 2006.
Inserted by G.S.R. 301(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 28th March, 2018.
Inserted by G.S.R. 301(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 28th March, 2018.

<!-- page 51 -->

shall be paid directly to the Mahanagar Telephone Nigam Limited towards charges for this
facility.]
8g

[(10) With effect from the 1st January, 2017, a Member may avail high speed broadband on
the Fibre to the Home (FTTH) with wi-fi services at his residence in Delhi from the
Mahanagar Telephone Nigam Limited and shall not be liable to make payment up to a
maximum of rupees two thousand two hundred per mensem, which shall be paid directly to
the Mahanagar Telephone Nigam Limited towards charges for this facility.]
.9[4A. Other exemptions in respect of telephone charges.– (1) Where metering facility

in respect of the telephone installed under sub-rule (3) of rule 4 is available, local calls made
from that telephone and local calls made from the telephone installed under sub-rule (1) and
sub-rule (5) of rule 4 shall be pooled together and a member shall not be liable to make any
payment in respect of one lakh and fifty thousand calls made from the three telephones
during any year.
(2) Where metering facility in respect of a telephone installed under sub-rule (3) of rule 4
is not available, no member shall be liable to make any payment in respect of the local calls
made from that telephone and in respect of another fifty thousand local calls, in addition to
the fifty thousand local calls made from each of the telephones installed under sub-rule (1)
and sub-rule (5) of the rule 4 and the total number of such free local calls shall not exceed
one lakh fifty thousand local calls during any year.
(3) Where a member has either not been provided with a telephone or does not desire to
be provided with a telephone under sub-rule (3) of rule 4, he shall not be liable to make any
payment in respect of the additional fifty thousand local calls made from each of the
telephones installed under sub-rule (1) and sub-rule (5) of rule 4 and the total number of such
free local calls shall not exceed one lakh fifty thousand local calls during any year.
9a

{(3A) A member is entitled to use any number of telephones for utilising total free
local calls available to him under sub-rule (1), sub-rule (3) and sub-rule (5) of rule 4 subject
to the condition that the telephone should be in his name at the places specified in that rule
and installation and rental charges of telephones other than the three telephones provided to
him under sub-rule (1), sub-rule (3) and sub-rule (5) of rule 4 shall be borne by the member
himself.}
(4) The trunk calls bills of the members may be adjusted within the monetary equivalent
of the ceiling of one lakh and fifty thousand local calls per annum as aforesaid.
9b

{(4A) Where a member does not utilise the free telephone calls available to him on
the three telephones provided under sub-rule (1), sub-rule (3) and sub-rule (5) of rule 4, in
any year beginning on or after the 1st day of April, 2002, the balance unutilised telephone
calls shall be carried forward to the subsequent years till his seat becomes vacant.}

8g

Inserted by G.S.R. 301(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 28th March, 2018.

9

Substituted by G.S.R. 718(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i), dated the 23rd October, 2002.
Inserted by G.S.R. 701(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 26th October 2004.
Inserted by G.S.R. 701(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 26th October 2004.

9a

9b

<!-- page 52 -->

(5) Excess telephone calls made, over and above the pooled total of one lakh fifty
thousand free local calls per annum in respect of the three telephones installed under sub-rule
(1), sub-rule (3) and sub-rule (5) of rule 4, may be adjusted against the one lakh fifty
thousand free local calls allowed on the three telephones for the next year.
9bb

[*

*

*

*

*

*

*

*

*

*

*

*]

9c

{(7) A member is liable to make payment in respect of charges of local calls made
in excess of total local calls available to him under sub-rule (1), sub-rule (3) and sub-rule (5)
of rule 4.}
4B. Retention of Telephone by Family in case of Death of Members.--Where a Member
dies during the term of his office, his family shall, for a period not exceeding two months
from the death of the Member, be entitled to retain the telephone and avail of such facilities
as were available to the said Member immediately before his death under the provisions of
rules 4 and 4-A.
5. Rules not to apply in certain cases.—Nothing contained in these Rules shall apply in
the case of any accommodation allotted to a Member, whether temporarily or permanently, in
excess of the accommodation to which he is entitled as a Member:
10

[Provided that a Member shall, on being given a change of residence, be entitled to retain
the residence to be vacated and the residence to be occupied by him, for a period not
exceeding three days on payment, for the period during which both the residences are
occupied by him of 10a[licence fee] 10b[for one of the residences] at the rate specified in rule
2.]

9bb

9c

10

10a

10b

Omitted by G.S.R. No.744(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 12th December 2006.
Inserted by G.S.R. No.701(E), published in the Gazette of India, Extraordinary, Part II, Section 3, subsection (i) dated the 26th October 2004.
Substituted by G.S.R. No.1227, published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i), dated the 7th August, 1967.
Substituted by G.S.R. No.1169(E), published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i), dated the 28th October, 1986.
Substituted by G.S.R. No.13(E), published in the Gazette of India, Extraordinary, Part II, Section 3,
sub-section (i), dated the 3rd January, 1986.

<!-- page 53 -->

Chapter 4
THE MEDICAL FACILITIES (MEMBERS OF PARLIAMENT) RULES,
1959
New Delhi, the 16th November, 1959
G.S.R. 1253. -- The following rules which have been made by the Joint Committee
constituted under sub-section (1) of Section 9 of the Salary and Allowances of Members of
Parliament Act, 1954 (30 of 1954), after consultation with the Central Government, in
exercise of the powers conferred on it by clause (ddd) of sub-section (3) of the said section
and have been approved and confirmed by the Chairman of the Council of States and the
Speaker of the House of the People, as required by sub-section (4) of that section are
published for general information -THE MEDICAL FACILITIES (MEMBERS OF PARLIAMENT) RULES, 1959
(As Amended upto 30 August, 1997)
1. Short title and commencement. -- (1) These rules may be called the Medical Facilities
(Members of Parliament) Rules, 1959.
(2) They shall come into force on the 16th November, 1959.
2. Medical facilities admissible. -- Members of Parliament shall 1[during their term of
office] be entitled to the same medical facilities as are available to officers of the Central
Civil Service, Class I, having their headquarters in Delhi or New Delhi, under the
Contributory Health Services Scheme for Central Government employees contained in the
Ministry of Health Memorandum No. F6(1)-1.54-Hosp. dated the 1st May, 1954 2[as inforce
from time to time.]
3

[3. Contribution. -- A compulsory monthly contribution shall be levied from every Member
of Parliament at the same rate as would be payable by the highest Civil Servant and such
contribution shall be recoverable from the Monthly Salary Bill of the Member.]
[No.F.130-MSA/59 III]

1

Inserted by G.S.R. No. 431, published in the Gazette of India, Extraordinary, Part- II, Section 3, Sub-section(i)
, dated the 14th April, 1960.
2
Substituted by G.S.R. No. 1888, published in the Gazette of India, Extraordinary, Part- II, Section 3, Subsection (i), dated the 12th December, 1966.
3
Substituted by G.S.R. No. 509 (E), published in the Gazette of India, Extraordinary, Part- II, Section 3, Subsection (i) dated the 30th August, 1997.

<!-- page 54 -->

Chapter 5
THE MEMBERS OF PARLIAMENT (ALLOWANCES FOR JOURNEYS
ABROAD) RULES, 1960
New Delhi, the 25th July, 1960
G.S.R. 830 -- The following rules which have been made by the Joint Committee constituted
under sub-section (1) of section 9 of the Salary and Allowances of Members of Parliament
Act, 1954 (30 of 1954), after consultation with the Central Government in exercise of the
powers conferred on it by clause (ddd) of sub-section (3) of the said section and have been
approved and confirmed by the Chairman of the Council of States and the Speaker of the
House of the People, as required by sub-section (4) of that section are published for general
information :-THE MEMBERS OF PARLIAMENT (ALLOWANCES FOR JOURNEYS ABROAD)
RULES, 1960.
1. Short title and commencement -- (1) These rules may be called the Members of
Parliament (Allowances for Journeys Abroad) Rules, 1960.
(2) They shall be deemed to have come into force with effect from the 30th December, 1958,
provided that any claim already settled before the publication of these rules in the official
gazette shall not be re-opened by virtue of any provision contained in these rules.
2. Allowances in respect of journeys abroad -- Where a member performs a journey
outside India in the discharge of his duties as such Member, he shall be entitled to the
following travelling and other allowances in respect of such journey, namely :I.

(i) Travelling Allowance -- For that part of the journey which a Member
undertakes in India, travelling allowance will be regulated in accordance with
section 4 of the Salary and Allowances of Members of Parliament Act, 1954
and the rules made under section 9 thereof.
(ii) Passage -- For the journey undertaken outside India free return air-cumrail-cum-sea passage by the shortest route will be provided by the First Class
in air and rail journeys and First Class- C grade passage in journey by sea or
by any lower class by which the Member actually travels from the last port of
the emplanement or embarkation in India to the place visited in the foreign
country and back. Rail travel will include sleeping berth during nights.
(iii) Luggage -- A member can carry with him not exceeding 1[40] kilograms
of luggage including the free allowance allowed by the Air Transport
Companies.

II.

Daily Allowance -- (i) Daily Allowance as admissible to a grade I Officer of
the Central Government will be paid on the basis of nights spent at the place
of business in connection with his work in the foreign country in accordance
with the rates prescribed by the Ministry of External Affairs, from time to
time.

1 Substituted by G.S.R. No.1889, published in the Gazette of India, Extraordinary, Part II, Section, 3, Subsection (i) dated the 12th December, 1966.

<!-- page 55 -->

(ii) Two-thirds of the daily allowance will also be paid during the period of
journey by rail provided the cost of food is not included in the rail fare paid.
(iii) Members will not be entitled to any daily allowance admissible under any
other rules, for the period of deputation outside India.
III.

Other Expenses – A Member is entitled to :

(i)

free board and lodging expressed at enforced halts en route where the Air
Companies do not provide the same subject to the maximum Daily Allowance
admissible at the place of halt;

(ii)

actual expenses incurred on passport fees and vaccination and inoculation
certificates subject to the production of receipts;

(iii)

incidental expenses such as tips, taxi-hire and cab fare incurred on duty on
production of the necessary vouchers:

Provided that where the receipts or vouchers for actual or incidental expenses incurred
are not available the expenditure shall be reimbursable on the basis of the certificate of the
Member that it was actually incurred.
3. A Member who claims the actual or incidental expenses under rule 2 (III), shall support his
claim by the certificates in the following form namely:(i) Certified that expenses incurred on passport fees, vaccination and inoculation certificates
were in the interest of the work of the Delegation and that the rates of taxi-hire, etc. are in
accordance with the prevailing rates and the expenditure on these items was reasonable.
(ii) Certified that the expenditure on account of tips included in the bills is not more than what
has been actually incurred.
[No.61-MSA/59]

<!-- page 56 -->

Chapter 6
THE MEMBERS OF PARLIAMENT (CONSTITUENCY ALLOWANCE)
RULES, 1986
New Delhi, the 3rd January, 1986
1

G.S.R. 11(E).—The following rules which have been made by the Joint Committee
constituted under sub-section (1) of section 9 of the Salary, Allowances and Pension of
Members of Parliament Act, 1954 (30 of 1954), after consultation with the Central
Government, in exercise of the powers conferred on it by clause (f) of sub-section (3) of the
said section, and have been approved and confirmed by the Chairman of the Council of States
and the Speaker of the House of the People, as required by sub-section (4) of that section, are
published for general information:—
THE MEMBERS OF PARLIAMENT (CONSTITUENCY ALLOWANCE)
RULES, 1986
(As amended upto 1st April, 2020)
1. Short title and commencement.—(1) These rules may be called the Members of
Parliament (Constituency Allowance) Rules, 1986.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Amount of Constituency allowance.—A member shall be entitled to receive the
constituency allowance under section 8 of the Salary, Allowances and Pension of Members of
Parliament Act, 1954 (30 of 1954), at the rate of 2(“rupees seventy thousand per mensem,
which shall be increased in every five years commencing from the 1st April, 2023 on the
basis of Cost Inflation Index provided under clause (v) of Explanation to section 48 of the
Income-tax Act, 1961(43 of 1961).
3

"2A. Notwithstanding anything contained in the rule 2, a Member shall be entitled to receive
the constituency allowance under section 8 of the Salary, Allowances and Pension of Member
of Parliament Act, 1954 (30 of 1954), at the rate of rupees forty nine thousand per mensem
for the period from 1st April, 2020 to the 31st March, 2021.".
3. Constituency allowance to be in addition to other allowances, etc.—For the
avoidance of doubts, it is hereby declared that the constituency allowance admissible under
these rules shall be in addition to, and not in derogation of, any other allowances or facilities
admissible (whether in cash or in kind) under any other rules for the time being in force.
1

2

3

Published in the Gazette of India, Extraordinary, Part II, section 3, sub-section (i), dated the
3rd January, 1986.
Substituted by G.S.R. 302 (E), published in the Gazette of India, Extraordinary, Part-II,
section-3, sub-section (i), dated the 28th March, 2018.
Inserted by G.S.R. 240 (E), published in the Gazette of India, Extraordinary, Part-II, section3, sub-section (i), dated the 7th April, 2020

<!-- page 57 -->

4. Repeal.—The Members of Parliament (Additional Facilities) Rules, 1975 are hereby
repealed.
[F. No. 2/1/MSA/85]

<!-- page 58 -->

Chapter 7

THE MEMBERS OF PARLIAMENT (ADVANCE
FOR THE PURCHASE OF CONVEYANCE) RULES, 1986
New Delhi, the 3rd January, 1986
1

G.S.R. 12(E). -- The following rules which have been made by the Joint Committee
constituted under sub-section (1) of section 9 of the Salary, Allowances and Pension of
Members of Parliament Act, 1954 (30 of 1954), after consultation with the Central
Government, in exercise of the powers conferred on it by clause (ff) of sub-section (3) of the
said section, and have been approved and confirmed by the Chairman of the Council of States
and the Speaker of the House of the People, as required by sub-section (4) of that section, are
published for general information :-THE MEMBERS OF PARLIAMENT (ADVANCE FOR THE PURCHASE OF CONVEYANCE) RULES,
1986
(As amended upto 13th December, 2010)
1. Short title and commencement. – (1) These rules may be called the Members of
Parliament (Advance for the Purchase of Conveyance) Rules, 1986.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Maximum amount of advance .-- (1) The maximum amount which may be advanced to a
member for the purchase of conveyance 2(shall not exceed rupees four lakhs) or the actual
price of the conveyance, which is intended to be purchased, whichever is less:
Provided that no advance shall be admissible when a conveyance has already been
purchased and paid for in full:
Provided further that where such payment has been made in part, the amount of
advance shall be limited to the balance to be paid as certified by the member.
(2) The amount of advance under sub-rule (1) shall be sanctioned in the name of the President
and authenticated in accordance with the provisions of the Authentication (Orders and other
Instruments) Rules, 1958.
3. Repayment of Advance. - (1) Recovery of the advance granted under rule 2, together with
interest thereon, shall be made from the salary bill of the member concerned in not more than
sixty equal monthly installments, which shall not extend beyond the tenure of his
membership:

1

2

Published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i) dated the 3rd
January, 1986.
Substituted by G.S.R. No.967(E), published in the Gazette of India, Extraordinary, Part II, Section 3,
Sub-section (i) dated the 13th December, 2010.

<!-- page 59 -->

Provided that where the member receiving the advance so desires, the Chairman of
the Council of States or the Speaker of the House of the People, as the case may be, may
permit recovery of the advance to be made in lesser number of installments.
Explanation. -- The amount of the advance to be recovered monthly shall be fixed in whole
rupees, except in the case of last installment when the remaining balance including any
fraction of a rupee shall be recovered.
(2) The recovery of advance shall commence with the first issue of salary after the advance is
drawn.
(3) Simple interest at the rate fixed by the Central Government in relation to advance for
purchase of conveyance by Government servants shall be charged on the said advance.
(4) Where a member ceases to be such a member before the full repayment of the advance,
the outstanding balance, together with interest thereon, shall be paid to the Central
Government immediately in one lump-sum.
4. Sale of Conveyance. -- (1) Except when a member ceases to be such a member, previous
sanction of the Central Government shall be obtained for the sale by the member of the
conveyance purchased with the aid of an advance, if such advance, together with the interest
accrued thereon, has not been fully repaid.
(2) Where a member wishes to transfer the said conveyance to another member, he may be
permitted under the orders of the Central Government, to transfer the liability attaching to
that conveyance to the latter member provided that the member purchasing the conveyance
records a declaration that he is aware that the conveyance transferred to him remains subject
to the mortgage bond and that he is bound by its terms and provisions.
(3) In all cases where a conveyance is sold before the advance received for its purchase,
together with interest thereon, has been fully repaid, the sale-proceeds must be applied, so far
as may be necessary, towards the repayment of such outstanding balance:
Provided that when the conveyance is sold only in order that another conveyance may
be purchased, the Central Government may permit the member to apply the sale proceeds
towards such purchase, subject to the following conditions, namely :-(a) the amount outstanding shall not be permitted to exceed the cost of the new
conveyance;
(b) the amount outstanding shall continue to be repaid at the rate previously fixed;
and
(c) the new conveyance shall also be insured and mortgaged to the Central
Government.
5. Period within which negotiations for purchase of conveyance may be completed. – A
member who draws an advance for the purchase of a conveyance shall complete his
negotiations for the purchase of and pay finally for, the conveyance within one month of the
date on which he draws the advance and failing such completion of negotiations and final
payment, the full amount of the advance drawn, together with the interest thereon for one
month, shall be refunded by the member to the Central Government.

<!-- page 60 -->

6. Execution of agreement. -- (1) At the time of drawing the advance, the member shall
execute an agreement in Form I and on completing the purchase, he shall further execute a
mortgage bond in Form II hypothecating the conveyance to the Central Government as
security for the advance.
(2) The cost price of the conveyance shall be entered in the schedule of specifications
attached to the mortgage bond in Form II.
7. Certificate to the Pay and Accounts Officer. -- (1) When an advance is drawn, the
sanctioning authority shall furnish to the Pay and Accounts Officers of the Council of States
or, as the case may be, of the House of the People, a certificate that the Agreement in Form I
has been signed by the member drawing the advance and that it has been found to be in order.
(2) The sanctioning authority shall see that the conveyance is purchased within one month
from the date on which the advance is drawn and shall submit the mortgage bond, duly
executed by the member, promptly to the Pay and Accounts Officer of the Council of States,
or, as the case may be, of the House of the People for examination before final record.
8. Safe custody and cancellation of mortgage bond. – (1) The mortgage bond shall be kept
in the safe custody of the sanctioning authority.
(2) When the advance has been fully repaid, the bond shall be returned to the member
concerned, duly cancelled, after obtaining a certificate from the Pay and Accounts Officer of
the Council of States or, as the case may be, of the House of the People, as to the complete
repayment of the advance and interest.
9. Insurance of conveyance.– The conveyance purchased from the advance shall be insured
against full loss by fire, theft and accident and the insurance policy shall contain a clause (as
in Form III) by which the insurance company agrees to pay to the Central Government
instead of the owner, any sums payable in respect of loss or damage to the conveyance, which
is not made good by repair, re-instatement or replacement.

<!-- page 61 -->

*

FORM I
(See rule 6)
FORM OF AGREEMENT TO BE EXECUTED AT THE TIME OF DRAWING AN
ADVANCE FOR THE PURCHASE OF A CONVEYANCE
An agreement made this __________________________day of
_______________two thousand and ____________________________________ between
Shri_______________________________________________________________________
a Member of Parliament (hereinafter called the Borrower, which expression shall include his
heirs, administrators, executors, legal representatives and assignees) of the one part and the
President of India (hereinafter called the Central Government) of the other Part.
WHEREAS the Borrower has under the provisions of the Rules regulating the grant
of advances to Members of Parliament for purchase of conveyance made under the Salary,
Allowances and Pension of Members of Parliament Act, 1954 applied to the Central
Government for a loan of Rs.____________ (Rupees ______________only) for the purchase
of a conveyance and the Central Government have agreed to lend the said amount of the
Borrower on the terms and conditions herein after contained;
NOW it is hereby agreed between the parties hereto that in consideration of the sum
of Rs.________________ paid by the Central Government to Borrower (the receipt of which
the Borrower hereby acknowledge (s)], the Borrower hereby agrees with the Central
Government (1) to pay to the Central Government the said amount with interest calculated
according to the said rules by monthly deductions from his salary as provided for by the said
rules and hereby authorises the Central Government to make such deductions and (2)to
expend within one month from the date of these presents, the full amount of the said loan in
the purchase of a conveyance or if the actual price paid is less than the loan to repay the
difference to the Central Government forthwith and to execute a document hypothecating the
said conveyance to the Central Government as security for the amount lent to the Borrower as
aforesaid and interest thereon in the form provided by the said rules. And it is hereby lastly
agreed and declared that if the conveyance has not been purchased and hypothecated as
aforesaid with one month from the date of theses presents or if the Borrower with that period
becomes insolvent or ceases to be a member or dies, the whole amount of the loan and
interest accrued thereon shall become due and payable.
In witness whereof the Borrower has hereunto set his hand the day and year first
before written.
Signed by the said Shri________________________________
In the presence of____________________________________

*

Inserted by G.S.R. 12 (E), Published in the Gazette of India, Extraordinary, Part II, Section
3, Sub-section (i), dated the 3rd January, 1986.

<!-- page 62 -->

*

FORM II

(See rule 6)
FORM OF MORTGAGE BOND FOR CONVEYANCE

THIS INDENTURE made this ______________________________ day of
______________two thousand and _________between Shri _____________________
(hereinafter called "the Borrower", which expression shall include his heirs, administrators,
executors, legal representatives and assignees) of the one part and the President of India
(herein after called, Central Government) of the other part, WHEREAS the Borrower has
applied for and has been granted and advance of Rupees___________________ to purchase a
conveyance in terms of Rules regarding the grant of advances to Members of Parliament for
the purchase of conveyance made under the Salary, Allowances and Pension of Members of
Parliament Act, 1954 (hereinafter referred to as "the said Rules") And WHEREAS, one of the
conditions upon which the said advance has been/ was granted to the Borrower is/was that the
Borrower will/would hypothecate the said conveyance to the Central Government as security
for the amount lent to the Borrower and WHEREAS the Borrower has purchased with, or
partly with, the amount so advanced as aforesaid the conveyance particulars whereof are set
out in Schedule hereunder written.
NOW THIS INDENTURE WITNESSETH that in pursuance of the said agreement
and for the consideration aforesaid the Borrower doth hereby convenient to pay to the Central
Government the sum of Rs.______________________ aforesaid or the balance thereof
remaining unpaid at the date of these presents by equal payment of Rs.__________________
each on the first day of every month and will pay interest on the sum for the time being
remaining due and owing, calculated according to the said Rules and the Borrower doth agree
that such payments may be recovered by monthly deductions from his salary in the manner
provided by the said rules, and in further pursuance of the said agreement the Borrower doth
hereby assign and transfer unto the Central Government the conveyance the particulars
whereof are set out in the Schedule here under written by way of security for the said advance
and the interest thereon as required by the said Rules.
And the Borrower doth hereby agree and declare that he has paid in full the purchase
price of the said conveyance and that the same is his absolute property and that he has not
pledged and, so long as any money remains payable to the Central Government in respect of
the said advance, will not sell, pledge or part with the property in, or possession of the said
conveyance. Provided always and it is hereby agreed and declared that if any of the said
installments of principal or interest shall not be paid or recovered in manner aforesaid within
ten days after the same are due or if the Borrower shall die or at any time ceases to be a
Member or if the Borrower shall sell or pledge or part with the property in or possession of
the said conveyance or become insolvent or make any composition or arrangement with his
creditors or if any person shall take proceedings in execution of any decree or judgement
against the Borrower, the whole of the said principal sum which shall then be remaining due
*

Inserted by G.S.R. 12 (E), published in the Gazette of India, Extraordinary, Part II, Section
3, Sub-section(i), dated the 3rd January, 1986.

<!-- page 63 -->

and unpaid, together with interest thereon, calculated as aforesaid shall forthwith become
payable AND IT IS HEREBY AGREED and declared that the Central Government may on
the happening of any of the events herein before mentioned seize and take possession of the
said conveyance and either remain in position thereof without removing the same or else may
remove and sell the said conveyance either by public auction or private contract and may out
of the sale money retain the balance of the said advance then remaining unpaid and any
interest due thereon, calculated as aforesaid and all costs, charges, expenses and payments
properly incurred or made in maintaining, defending or realizing its rights hereunder and
shall pay over the surplus, if any to the Borrower his executors, administrators or personal
representatives; PROVIDED FURTHER that the aforesaid power of taking possession or
selling of said conveyance shall not prejudice the right of the Central Government to sue the
Borrower or his personal representatives for the said balance remaining due and interest or in
the case of the conveyance being sold the amount by which the net sale proceeds fall short of
the amount owing: AND the Borrower hereby further agrees that so long as any moneys are
remaining due and owing to the Central Government he, the Borrower will insure and keep
insured the said conveyance against loss or damage by fire, theft, and accident with an
Insurance Company to be approved by the Accountant General concerned and will produce
evidence to the satisfaction of the Accountant General that the Motor Insurance Company
with whom the said motor vehicle is insured have received notice that the Central
Government (President of India) is interested in the Policy AND the Borrower hereby further
agrees that he will not permit or suffer the said conveyance to be destroyed or damaged or to
deteriorate in a greater degree than it would deteriorate by reasonable wear and tear thereof
and further that in the event of any damage or accident happening to the said conveyance, the
Borrower will forthwith have the same repaired and made good.

<!-- page 64 -->

SCHEDULE
Description of Conveyance
Maker’s name
Description
No. of cylinders
Engine Number
Chasis No.
Cost Price
IN WITNESS Whereof the said___________________Borrower’s name
and_________________ for and on behalf of the President of India have hereunto set their
respective hands the day and year first above, written.
Signed by the said in the presence of:
1. _________________________________________
2. _________________________________________
(Signature of Witnesses)
……………………………………………………
(Signature and Designation of the Borrower)

Signed by (Name and Designation)
………………………………...
for and on behalf of the President of India
in the presence of :
1. ___________________________
2. ___________________________
(Signature of Witnesses)
…………………………………………….
(Signature and Designation of the Officer).
Name and designation of the Borrower…………………………………………………………

<!-- page 65 -->

*FORM III
(See rule 9)
FORM OF THE CLAUSE TO BE INSERTED IN INSURANCE POLICIES

1.
It is hereby declared and agreed that Shri___________________________(the owner
of the conveyance hereinafter referred to as the insured in the Schedule to this policy) has
hypothecated the conveyance to the Central Government (President of India) as security for
advance for the purchase of the conveyance and it is further declared and agreed that the said
Government (President) are interested in any moneys which but for this endorsement be
payable to the said Shri_______________________________________ (the insured under
this policy) in respect of the loss or damage to the said conveyance (which loss or damage is
not made good by repair, reinstatement or replacement) and such moneys shall be paid to the
said Government (President ) as long as they are the mortgages of the conveyance and their
receipt shall be full and final discharge to the company in respect of such loss or damage.

2.
Save as by this endorsement expressly agreed, nothing herein shall modify or affect
the rights or liabilities of the insured or the company respectively under or in connections
with this policy or any term, provision or condition thereof.

[F.No.2/1/MSA/85]

Secretary-General.

* Inserted by G.S.R. 12 (E) Published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i)
dated the 3rd January, 1986.

<!-- page 66 -->

Chapter 8
THE MEMBERS OF PARLIAMENT (OFFICE EXPENSE
ALLOWANCE) RULES, 1988
G.S.R. 1093 (E). – The following rules which have been made by the Joint
Committee constituted under sub-section (1) of Section 9 of the Salary, Allowances and
Pension of Members of Parliament Act, 1954 (30 of 1954), after consultation with the Central
Government, in exercise of the powers conferred on it by Clouse (f) of sub-section (3) of the
said section and have been approved and confirmed by the Chairman of the Council of State
and the Speaker of the House of the People, as required by sub-section (4) of that section, are
published for general informationTHE MEMBERS OF PARLIAMENT
(OFFICE EXPENSE ALLOWANCE) RULES, 19881
(As amended upto 1st April, 2020)
1. Short Title and Commencement. – (1) These rules may be called the Members of
Parliament (Office Expense Allowance) Rules, 1988.
(2) They shall be deemed to have come into force on 1 st day of April, 1988.
2. Definitions. – In these rules, unless the context otherwise requires:(a) “Act” means the Salary, Allowances and Pension of Members of Parliament Act, 1954.
(b) “Office expense” means expenses on stationery, postage and Secretarial help as are not
covered by other rules.
3. Amount of Office Expense Allowance. - 2[(1) A member shall be entitled to
receive the office expense allowance under section 8 of the Act at the rate of rupees sixty
thousand per mensem, out of which(a) rupees twenty thousand shall be for meeting expenses on stationery items and
postage; and
(b) the Lok Sabha or the Rajya Sabha Secretariat may pay up to rupees forty thousand to
the person(s) as may be engaged by a Member for obtaining secretarial assistance and
one such person shall be computer literate duly certified by the Member.
(2) The Office Expense Allowance under sub-rule (1) shall be increased every five years
commencing from the 1st April, 2023, on the basis of Cost Inflation Index provided
under clause (v) of Explanation to section 48 of the Income-tax Act, 1961 (43 of
1961).]

1

Published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section (i), dated the 25th November, 1988
effective from 1st April, 1988.
2
Substituted by G.S.R. No. 303 (E), published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section
(i),dated the 28th March, 2018.

<!-- page 67 -->

3

"3A. Notwithstanding anything contained in rule 3, a Member shall be entitled to receive the
Office Expense under section 8 of the Act, at the rate of rupees fifty four thousand per mensem,
out of which(a) rupees fourteen thousand shall be for meeting expenses on stationery items and postage;
and
(b) the Lok Sabha or the Rajya Sabha Secretariat may pay up to rupees forty thousand to the
person(s) as may be engaged by a Member for obtaining secretarial assistance and one such
person shall be computer literate duly certified by the Member,
for the period from the 1st April, 2020 to the 31st March, 2021.".

4. Office Expense Allowances to be in Addition to other Allowances etc. – For the
removal of doubts, it is hereby declared that the office expense allowance admissible under
these rules shall be in addition to, and not in derogation of, any other allowances or facilities
admissible (whether in cash or in kind) under any other rules for the time being in force.
[F. No. 25/1/MSA/88]

3

Inserted by G.S.R. No. 241 (E), published in the Gazette of India, Extraordinary, Part II, Section 3, sub-section (i),dated
the 7th April, 2020

<!-- page 68 -->

Chapter 9
THE PAYMENT OF FAMILY PENSION (SUBMISSION OF DOCUMENTS) RULES, 2021
New Delhi, the 11th May, 2022

G.S.R. 349(E).—The following rules which have been made by the Joint Committee constituted under subsection (1) of section 9 of the Salary, Allowances and Pension of Members of Parliament Act, 1954 (30 of 1954),
after consultation with the Central Government, in exercise of the powers conferred on it by clauses (ee) and (g) of
sub-section (3) of the said section, and have been approved and confirmed by the Chairman of the Council of States
and the Speaker of the House of the People, as required by sub-section (4) of that section, are published for general
information:—
THE PAYMENT OF FAMILY PENSION (SUBMISSION OF DOCUMENTS) RULES, 2021
1. Short title and commencement.—(1) These rules may be called the Payment of Family Pension (Submission of
Documents) Rules, 2021.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions.-In these rules, unless the context otherwise requires,(a) “Act” means the Salary, Allowances and Pension of Members of Parliament Act, 1954 (30 of 1954);
(b) “family pension” means the amount payable, if claimed, to the spouse or dependents of a deceased
member or ex-member of Parliament under the Act;
(c) “section” means a section of the Act;
(d)
words and expressions used in these rules and not defined but defined in the Act shall have the
meanings, respectively assigned to them in the Act.
3.
Submission of documents by sitting members.- (1) Sitting members immediately after taking their seat in
the respective Houses of Parliament shall also submit the following documents, duly attested by them, to facilitate
expeditious processing of family pension cases, as and when applied for, as per the provisions of sub-section (1) of
section 8AC:(a) four photographs and four specimen signatures or thumb impression of the spouse or dependent, as the
case may be, as per the Annexure A to these rules;
(b) details of family members may be given in the proforma annexed as Annexure B to these rules.

(2) Members shall also intimate immediately the Lok Sabha or Rajya Sabha Secretariat, as the case may be, about
any change in the status of the person referred to in clause (a) of sub-rule(1).
4.
Submission of documents by ex-members.- (1) Ex-members shall, while submitting application for
pension, also submit details of family members and dependents in the proforma annexed as Annexure B to these
rules along with four photographs and four specimen signatures or thumb impression, duly attested by ex-member
himself or herself, of the spouse or dependent, as the case may be, who may be eligible for family pension, if applied
for, as per the provisions of sub-section (2) of section 8AC.
(2) The application for pension, four photographs and four specimen signatures or thumb impression
referred to in sub-rule (1) shall be submitted in Form A annexed to these rules.
(3) Ex-members shall also intimate immediately the Lok Sahba Secretariat or Rajya Sabha Secretariat, as
the case may be, about any change in the status of the person referred to in sub-rule (1).

<!-- page 69 -->

5.
Submission of documents by spouse of member.- (1) The spouse of member shall, while applying for
family pension, in addition to Death Certificate issued by the Municipal Authority or the local Panchayat of the area,
also submit:(a)

(b)

ex-member’s Identity Card (in original) issued by the Lok Sahba or Rajya Sabha Secretariat, as the
case may be, and in case the original Identity Card is lost or not found or untraceable, an affidavit shall
be submitted by the claimant regarding loss or misplace of Identity Card of ex-member;
affidavit showing reasons for dependency on the sitting member or ex-member;

(c) Indemnity Bond duly certified by First or Second Class Magistrate; and
(d)
the marriage certificate and if the same is not available, succession certificate issued by First or
Second Class Magistrate, in case of any variation in the information furnished by the sitting member or exmember, as required under clause (b) of sub-rule (1) of rule 3 or sub-rule (1) of rule 4.
(2) The application for family pension referred to in sub-rule (1) shall be submitted in Form B annexed to
these rules.
6.
Submission of documents by dependents of member.- (1) Dependent while applying for family pension, in
addition to Death Certificate issued by the Municipal Authority or the local Panchayat of the area, shall
also submit:(a) by the 31st March of every year an affidavit that he or she still continues to be a dependent, failing
which their family pension shall be discontinued or stopped;
(b) Succession Certificate issued by First or Second Class Magistrate;
(c) ex-member’s Identity Card (in original) issued by the Lok Sahba or Rajya Sabha Secretariat, as the
case may be, and in case the original Identity Card is lost or not found or untraceable, an affidavit
shall be submitted by the claimant regarding loss or misplace of Identity Card of ex-member; and
(d) Indemnity Bond duly certified by First/Second Class Magistrate.
(2) The application for family pension referred to in sub-rule (1) shall be submitted in Form B annexed to
these rules.

<!-- page 70 -->

Annexure A
[Rule 3 (1) (a)]
Specimen Signature/Thumb Impression of Spouse or dependents
1. Name...............................

Signature of spouse/dependent

----------------------------------

(Tick whichever is applicable)

Thumb impression

PHOTO

Attested by MP

2. Name...............................

Signature of spouse/dependent

----------------------------------

(Tick whichever is applicable)

Thumb impression

PHOTO

Attested by MP

3. Name...............................

Signature of spouse/dependent

----------------------------------

(Tick whichever is applicable)

Thumb impression

PHOTO

Attested by MP

4. Name...............................
Signature of spouse/dependent

----------------------------------

<!-- page 71 -->

(Tick whichever is applicable)

Thumb impression

PHOTO

Attested by MP

Annexure B
[Rule 3 (1) (b) and 4(1)]
Details of Family Members
(to be filled in duplicate)
I, Smt./Shri/Dr. ______________________________________________________,
Member/Ex-Member of Rajya Sabha/Lok Sabha hereby furnish the details of my spouse/dependant family
members who are eligible to receive parliamentary family pension in terms of the Salary, Allowances and
Pension of Members of Parliament Act, 1954 in the event of my death:
Sl. No.

Name and complete address
of family members

Relationship with
members

Date of birth

Whether
physically
handicapped*

01.

02.

03.

*If the dependant family member is handicapped/infirm, appropriate medical certificate should be attached.
Signed this_________________ (day) of _________________(Month) of 20 _____(year).

Signature of the Member/Ex-Member
Name of the Member/Ex-Member:___________________________

<!-- page 72 -->

Address:___________________________
___________________________
___________________________
_______________ PIN_________
Phone/Mobile:___________________________
Email Id---------------------------------------------Note: All the above information is mandatory.

Form A
[See rule 4(2)]
APPLICATION FOR PENSION
(See Section 8A of the Salary, Allowances and Pension of Members of Parliament Act, 1954, as amended)
(to be submitted in duplicate by the Ex-Member of Parliament)

From
Dr./Smt/Shri/Km. .........................................................................
Ex-Member of LOK SABHA/RAJYA SABHA/PROVISIONAL PARLIAMENT
(here mention the House last served)
.................................................................................................

To
The Secretary-General
Rajya Sabha /Lok Sabha
Parliament House
New Delhi.

Subject: Sanction of Pension under the Salary, Allowances and Pension of Members of Parliament Act,
1954 as amended.

Sir,
In terms of Section 8A of the above-mentioned Act, I am entitled to Pension in respect of the
following periods served by me as a Member of..................................................
(i)
Member of Provisional Parliament including membership
of the body which functioned as Constituent Assembly of
the Dominion of India immediately before the

From

To

<!-- page 73 -->

commencement of the Constitution.
(ii)
Member of Council of States (Rajya Sabha)
(iii)
Member of House of People (Lok Sabha)
2.

It is requested that steps may kindly be taken to sanction Pension to me. I desire to draw my Pension
from
..................................................Bank
(name
of
any
nationalised
Bank)....................................................Branch at....................................................(Address of Bank) and
my Bank Account Number is...........................................................BSR code...................................IFSC
Code......................................

3.
I enclose herewith the following documents duly attested by a Ist Class/ 2 nd Class Magistrate, Class I
Officer belonging to the Central Government or a State government/a sitting Member of Parliament:
(i)
(ii)

3A.

4.

Four specimen signatures.
Four copies of latest photographs in Passport size (attestation on the front of the
Photograph).

I also enclose herewith the following documents duly attested by the undersigned:Details of Family members/Dependents in prescribed proforma, Four photographs and Four
specimen signatures or thumb impression, of the spouse or dependent (as per Section 2 (aa) of the
Salary, Allowances and Pension of Members of Parliament Act, 1954) as the case may be, who may
be eligible for family pension, if applied for, as per the provisions of Section 8AC (2) of MSA Act,
1954.

My present address is
............................................................................................................................................................................
............................................................................................................................................................................
........................
My permanent address is
............................................................................................................................................................................
.......
Phone no......................................Mobile no..................................................Email ID................................

5.

I hereby *declare that:(i)

I am not holding the elected office of the President or the Vice-President or the office of
the Governor of any State or the Administrator of any Union Territory;

(ii)

I am not a member of Rajya Sabha or Lok Sabha or any Legislative Assembly of a State
or Union Territory or any Legislative Council of a State;

(iii)

I am not employed on a salary under the Central government or any State Government or
any Corporation owned or controlled by the Central Government or any State
Government or any Local Authority or I am not otherwise entitled to any remuneration
from such Government or Corporation or Local Authority;

<!-- page 74 -->

(iv)
I
am
holding
the
office
of
…………………………………………………………………………………………………………………
………………….or Member of ………………………………………………………………….or
employed as………………………………………………………………………………..or
in ………………………………………………………………………………….and the total
remuneration received by me is Rs. …………………………………………………………..per month.
(v)
I was holding the office of ...................or Member of ...........or employed as..............in............and the
total remuneration received by me was Rs.......p.m. from the date..........to...........(to be filled up if there is a
gap between end of term and submission of application for pension)
(vi)
In case of any change in the status of spouse/dependent, I shall intimate immediately to Lok
Sabha/ Rajya Sabha Secretariat.


The declarations which are not applicable may be scored out in ink.
Yours faithfully,
.............................................
Signature of Ex-MP

NAME IN BLOCK LETTERS:
.......................................................
STATION:......................................
DATE:..............................................

For the use in the Lok Sabha/Rajya Sabha Secretariat

MSA Branch, Lok Sabha Secretariat
MSA Branch, Rajya Sabha Secretariat
Forwarded to the Under Secretary (Table Office), Lok Sabha Secretariat/ Under Secretary (Table
Office), Rajya Sabha Secretariat, for further necessary action.

Under Secretary

Table Office, Lok Sabha Secretariat

Certified that Shri/Smt./Km/Dr........................................................................(in block letters) served as
a Member of Lok Sabha during the following period:
From ............................................to ........................................................

From ............................................to ........................................................

<!-- page 75 -->

From ............................................to ........................................................

From ............................................to ........................................................

Under Secretary, Lok Sabha Secretariat

Table Office, Rajya Sabha Secretariat

Certified that Shri/Smt./Km/Dr.........................................................................(in block letters) served as a
Member of Rajya Sabha during the following period:
From ............................................to ........................................................
From ............................................to ........................................................
From ............................................to ........................................................
From ............................................to ........................................................

Under Secretary, Rajya Sabha Secretariat
MSA Branch, Lok Sabha Secretariat
MSA Branch, Rajya Sabha Secretariat
MSA Branch, Lok Sabha Secretariat
MSA Branch, Rajya Sabha Secretariat
P.F No. . ........................................................

Dated the..............................

A Pension of ................................................................................
(Rupees.......................................................................only) per mensem is sanctioned to
Shri/Smt./Km/Dr...............................................................with effect from................................. .
Forwarded to Pay and Accounts Officer, Lok Sabha Secretariat/Rajya Sabha Secretariat for further
necessary action.
Signature.............................
Sanction Authority........................
Designation................................

<!-- page 76 -->

SPECIMEN SIGNATURE
(1) NAME ......................................EX-MP, RAJYA SABHA/LOKSABHA

SIGNATURE

Attested

Name and Seal of Attesting Authority

(2) NAME ......................................EX-MP, RAJYA SABHA/LOKSABHA

SIGNATURE

Attested

Name and Seal of Attesting Authority

(3)NAME ......................................EX-MP, RAJYA SABHA/LOKSABHA

SIGNATURE

Attested

Name and Seal of Attesting Authority

(4) NAME ......................................EX-MP, RAJYA SABHA/LOKSABHA

SIGNATURE

Attested

Name and Seal of Attesting Authority

<!-- page 77 -->

(Application to be filled-in by ex-MP for the purpose of revision of pension in Lok Sabha Secretariat/ Rajya
Sabha Secretariat)
From……………………..
……………………………
……………………………
(Name and address of ex-MP)
Contact No. (Mob. No.) & email I.D.…………………………….
To,
The Deputy Secretary (MSA),
Lok Sabha Secretariat/Rajya Sabha Secretariat,
Parliament House Annexe,
New Delhi-110001
Subject: Revision of Pension.

Sir/Madam,
I was a Member of Rajya Sabha/Lok Sabha representing……………………….Constituency and was
sanctioned
ex-MP
pension
from
Rajya
Sabha/Lok
Sabha
Secretariat
through
………………………………………..(Name and address of Bank)…………………………(BSR Code of the bank)
....................................(IFSC Code) and my Aadhar No. is ………………………. and PAN is
……………………….(copies enclosed).
My pension may now be revised as per the latest amendment made in the Salary, Allowances and
Pension of Members of Parliament Act, 1954.

Yours faithfully,
(……………………………………….)
Name and Signature of ex-MP
Date:………………………
Place:………………………………………

<!-- page 78 -->

DECLARATION
I declare that:

(i)

I am not elected to the office of the President/Vice President or appointed to the office of
the Governor of any State or Administrator of any Union Territory; or
I am not a member of House of the People (Lok Sabha) or Council of States (Rajya
Sabha), any Legislative Assembly or Legislative Council of a State or Metropolitan
Council of Delhi constituted under Section 3 of Delhi Administration Act, 1966, or
I am not employed on Salary under the Central Government or any State Government or
any corporation owned or controlled by the Central Government or any State
Government or any Local Authority or I am not otherwise entitled to any remuneration
from such Government or Corporation or Local Authority; or
I am not in receipt of any pension from Central Government/State Government/any
Local Authority/Corporation owned or controlled by the Central Government or any
State Government;
I have not been holding any of the offices, as mentioned in sl. Nos. (i) to (iii) above, since
my pension was last revised/sanctioned.

(ii)

(iii)

(iv)

(v)

OR
(a)

I

am/was

holding

the

office

of

………………………………………of

of…………………………………………………………………or

Member
employed

as………………………………………in*…………………………………………w.e.f…………
…………..and the total salary/remuneration received by me is Rs……………………….per
month.
(b)

I

am

in receipt

of

Rs.

…………………..per month

as

ex-MP

pension/family

pension/…………………………pension drawing from*……………………..

(_______________________________)
Pensioner’s Signature
Name (in capital letter)………………………………….
STATION___________________

ADDRESS________________

DATE___________________

_________________________
____________________________
-----------------------------------------------

*Here

mention

the

name

of

office

of

the

Central

Government/State

Government/Local

Authority/Corporation owned or controlled by the Central Government or State Government.

<!-- page 79 -->

[Rule 3 (1) (a)]
Specimen Signature/Thumb Impression of Spouse or dependents
1.Name...............................

Signature of spouse/dependent

----------------------------------

(Tick whichever is applicable)
Thumb impression

PHOTO
Attested by MP/Ex-MP
2. Name...............................

Signature of spouse/dependent

----------------------------------

( Tick whichever is applicable)
Thumb impression

PHOTO
Attested by MP/Ex-MP
3. Name...............................
Signature of spouse/dependent

----------------------------------

(Tick whichever is applicable)
Thumb impression

PHOTO
Attested by MP/Ex-MP
4. Name...............................

Signature of spouse/dependent

----------------------------------

( Tick whichever is applicable)
Thumb impression

PHOTO
Attested by MP/Ex-MP

<!-- page 80 -->

Form B
(See rules 5(2) and 6(2))
LOK SABHA/ RAJYA SABHA SECRETARIAT
APPLICATION FOR FAMILY PENSION
(See Section 8AC of the Salary, Allowances and Pension of Members of Parliament Act, 1954, as amended)
(to be submitted in duplicate by the Spouse/Dependant of deceased member of parliament/former member of
parliament*)
From
Shri/Smt/ Km./Dr. ______________________________
_______________________________________________________
_______________________________________________________
To
The Secretary-General
Lok Sabha/Rajya Sabha
Parliament House
New Delhi

Subject: Sanction of family pension under the Salary, Allowances and Pension of Members of Parliament
Act, 1954.
Sir,
I am to state that Shri/Smt./Km./Dr. _________________________________ (Name of deceased
MP/Ex-MP) was a member of Provisional Parliament/Lok Sabha/Rajya Sabha as per details furnished
below:
Sl.
No.

(i)

Provisional Parliament

(ii)

Member of the Council of
States (Rajya Sabha)
Member of the House of
People (Lok Sabha)

(iii)

2.

3.

Period of membership

Name of
Constituency

State

From

To

Where the deceased Member of Parliament/former Member of Parliament last served?
..................................................................................................................
(Provisional Parliament/Lok Sabha/Rajya Sabha)
* includes ex-Member of Parliament of Provisional Parliament
Shri/Smt./Km./Dr.............................................................
(name of deceased member/former member)
had expired on dated.............................................
(Date of death of MP/Ex-MP)

4.
The details of surviving widow/widower and children and dependants of the deceased Member of
Parliament/ex-Member of Parliament are as under:
