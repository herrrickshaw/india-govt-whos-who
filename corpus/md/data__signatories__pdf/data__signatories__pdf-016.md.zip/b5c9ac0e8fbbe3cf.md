---
doc_id: "b5c9ac0e8fbbe3cf"
source_url: "https://dof.gov.in/static/uploads/2025/12/c1850c551ff2f64b67f4ea27e56c5a79.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Pre Bid Responses under the section “ RFB for Hiring a Communication Agency under PM-MKSSY”"
date: "2025-12-04"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "20810134ebd2cdea"
---

<!-- page 1 -->

TT
’
Minutes of the Pre-Proposal Meeting in respect of REB for Hiring of Communication AgencY of the Pre-Proposal Meeting in respect of REB for Hirin, of Communication Agenc’
under PM-MKSSY, issued vide Tender Ref No/RFB Ref No. IN-DOF-503128-NC-RFB B Ref No. IN-DOF-503128-NC-RFB

The Pre Proposal Meeting regarding the tender titled RFB for Hiring of Communication Agency
under PM-MKSSY, issued vide Tender Ref No/RFB Ref No. IN-DOF-503128-NC-RFBwas held
on the 13" November, 2025 under Chairmanship of Shri V. Srinivasa Rao, Director,Department of
Fisheries in Conference Room, at Chander Lok Building New Delhi-110001,

The meeting was attended by following officers from Department of Fisheries (@oF):

1. Dr. Traun Kumar Singh, Assistant Commissioner, DoF

2. Shri Intisar Anees Siddiqui, Team Lead -PMU, DoF

3. Ms. Anupam Sharma, Senior Technical Officer, DoF

4. Shri Gaurav Sharma, PMU-Procurement Specialist

5S. Shri Ayub Alam, PMU-Finance & Procurement Assistant, DoF

6. Shri Pawan Agarwal, PMU-Finance & Procurement Assistant, DoF

7. Shri. Lokesh Gulyani, PMU-Head Communication Specialist

8. Shri Rishi Kumar, PMU- Communication Specialist

Following firms attended as Prospective Bidders:

1. Shri. Vishal Tyagi, Beewax Media Private Limited,

2. Shri. Vivek, Expression 360 Services India Limited,

3. Shri. Shanker - trident exhibitors

4. Shri. Yash Purohit- Span Communications

5. Shri. Saurav from Crayons Advertising Ltd.

6. Shri. Surbhi, Global Media

Ast the outset, the Chair welcomed all participants and explained that the Pre-Proposal Meeting was
convened to clarify queries/doubts of bidders regarding the aforesaid tender.

Thereafter, queries from the prospective bidders were responded to from DoF side and finally the
following was agreed:

1. The gist of queries of the prospective bidders and the clarifications provided by the
Department is given as  Annexure-I (Pre-Bid Responses) and Annexure-II
(Amendment/Corrigendum).

2. The minutes of the Pre-Proposal meeting shall form part of the revised bid document/
amendment.

3. All other terms and conditions of the RFBand subsequent version shall remain unchanged.

4. The amendments/clarifications shall be uploaded on the CPPP portal and the Department’s
website for information of all intended bidders.

5. Submission of bids by the bidders shall be in conformity with the RFB document including
the amendments/clarifications issued.

The Chair thanked all participants for their interest and active involvement assured that all
suggestions and clarifications raised during the meeting shall be taken into consideration, and any
formal changes will be issued appropriately.
The meeting ended with vote of thanks to the Chair. \ 4
केक के के
a --. ९ बह एज ान्नयाइ मनन आस...

<!-- page 2 -->

Pre Proposal Response , Department of Fisheries
P/RFB No.:- IN-DOF-503128-NC-RFB
Pre Proposal Meeting date: 13 November, 2025
IRFB Name: Hiring a Communication Agency for the Designing and Implementation of a Comprehensive Communication and Outreach Strategy,
| Sr.No. |
Section IV — Form Fin-3 — Breakdown of ‘Can we quote rates higher than the ceiling Bidders must quote prices within the
Bidding Forms, Cost (Ceiling Amounts for price in cases where costs may vary based on _|approved ceiling figures. Quoting rates
Pg. 82-113 Deliverables) specific requirements or execution timelines - |higher than the ceiling price is not
for example, for influencers, podcasts, etc.? —_| permitted.
Refer to the Note for Financial
Evaluation.
Section IV — Bidding] Form Fin-3 — Financial Please clarify whether the 9% commission 9% Service Charge/Management Fee
Forms Pg. 114 Proposal should be included within the quoted rates or | will be paid in addition to the quoted
Note for Financial Evaluation —_| will it be calculated additionally over the total |price or the actual cost incurred
monthly amount. (whichever is lower for each activity).
Agencies will be eligible to receive this
Service Charge/Management Fee based
2 on the actual cost incurred under Part A
and Part B, subject to submission of
valid supporting documents and
invoices, submission of manpower salary)
statements and approval by the internal
committee of the Department of
Fisheries.
‘Section IV — Bidding}Part B — Deliverables In Part B (Deliverables), are the mentioned In part B's "Fixed Indicative
Forms, Fixed Indicative Deliverables _| quantities final and to be executed as stated, or |Deliverables” the quantity is fixed but in
3 [Pg. 83-100 they are the indicative and subject to the "Variable Indicative Deliverables"
Ministry’s specific requirements? quantity may vary and are subject to the
client's (DoF) requirement.
\\w

<!-- page 3 -->

Section IV - Social Media Videos (Ceiling |Does the social media video cost include [As per RFB Terms & Conditions
Bidding Forms, —_|%20,000 per video) shoot/production, or will the Ministry be
Pg. 84-85 providing
footage for these videos?
Section IV — Digital Marketing — SEO for |How many keywords will be required for |This Head is kept for any technological
Bidding Forms, _|all Platforms SEO optimization on Google, and who willJinterventions that may be required
Pg. 87 be responsible for providing the content - [elated to software, apps including SEO
such as blogs and articles - for this etc.
purpose?
Section IV — Print Media Advertisements _ [Is the rate mentioned for magazine It includes Design, Translation,
Bidding Forms, advertisements applicable only to the
Pg. 88-89 design, or
Section IV — Variable Indicative For influencer partnerships, could you Local and socially active influencers,
Bidding Forms, _| Deliverables — Influencer specify the type or category of influencers having strong and cordial relations with
7 |Pg. 100-101 Partnerships expected, along with the approximate the fisheries communities in the marine
number of followers or subscribers and inland States.
required?
Section IV — Digital Banner Ads & Display |Under display banner ads and display (a) This refers to the digital
Bidding Forms, |Campaigns campaigns, please clarify: (a) On how ads/posters/creatives which may be
| Pg. 101 many posted online as well as on digital
platforms will the campaigns be executed? |S°TenS- () Approx 360 in numbers. (c)
|(b) How many creatives are expected? (c) [In ‘call to action ads' also primarily static
[Does this scope cover only static creatives, Ads are Pre! fered, however, agency may
के provide video ads as well.
lor does it include video ads on Meta and
ह YouTube as well?
‘Section IV — INFDP Mobile Application _| Please provide clarity regarding the NFDP |Social Media + Digital promotions
Bidding Forms, —_| Promotion mobile app promotion activity - what is the |(Paid as well as organic)
Pg. 110 scope and expected deliverables?
\W

<!-- page 4 -->

Section III — Part A: Pre-Qualification/ — |Sir, please consider including the COVID- |Please check Amendment
Qualification, Pg. |Mandatory Qualification 19 affected financial years (FY 2020-21
35 Criteria, Point 4 and FY 2021-22) while evaluating the five:
year experience period mentioned for
creative advisory, campaign, and outreach
work experience, as some of the agencies
have worked hard during that period in
even in the hazardous conditions.
Section II — Part B: Technical Proposal Sir, instead of calculating the average INo Change, As per RFB
Qualification, Pg. |Scoring Methodology, Point 2 |annual turnover for the last three financial
37 — Minimum Average Annual |years (FY 2022-23, FY 2023-24, and FY
Turnover 2024-25), may we suggest considering a
cumulative turnover of 200 crore or
average %70 crore , as this will allow fair
participation from MSMEs and agencies
with large-scale project experience but non:
uniform annual billing cycles.
Section 1 - Part B: Technical Proposal _|Sir, kindly incorporate the inclusion of Please check Amendment
Qualification, Pg. |Scoring Methodology, Point 3 |COVID-19 affected financial years (FY
37 | Experience in Development |2020-21 and FY 2021-22) while
‘Communication Strategy evaluating experience for development
12 communication, campaign, and outreach
projects, considering some of the agencies
have worked hard during that period in
even in the hazardous conditions.
General Bid Security / EMD Sir, please confirm whether MSME- INo exemption for MSME
registered agencies are eligible for
13 exemption from submission of the Earnest
Money Deposit (EMD) under this tender.
\W
पर

<!-- page 5 -->

Section I - Part A: Pre-Qualification / Sir, instead of the current thresholds INo change, As per RFB
Qualification, Pg. |Mandatory Qualification (Single Project — %5 crore, Two Projects —
35 Criteria, Point 4 — %8 crore, Three Projects — 710 crore), may
Single/Multiple Project we request to consider revised values of 73
Experience crore, %5 crore, and %8 crore respectively.
Government departments generally do not
issue single work orders of such large
amounts for communication assignments.
The proposed revision would ensure wider
and fair participation while maintaining
quality and experience criteria.
‘Section IV- Broadcast & Publishing cost |Please confirm whether the advertisement |The print, TV & Radio commercials and
Bidding Forms _|for print advertisements, campaigns related to Print Media, Broad _|Magazine Ads are to be published at
Page no 113 Radio Spots & Jingle, TVC, _|casting, Electronics media and Magazines |DAVP rates. The editions, frequency of
Documentaries, Videos, to be published on DAVP approved rates? |SP0tS and number of days will be based
Interviews, Cinema ‘You have not mentioned the details of तिल 1 कि डक काट डक.
Advertising etc. Quarter, प्रा [००1०१5, ४26, 590 एश' day, regions of the bills. For further details, please
and Full Page advertisements [durations etc.. And what will be the agency] .¢.- RFR document.
in Rural and Urban commission on advertisement releases?
established Indian And payment terms with duration of
newspapers, Radio release of payment after submission of
spots/jingles/RJ mentions, Media Bills.
TVC commercial & other Also we have to pay the media within the
programmes (documentary, [60 days can you clarify the average time
‘Sponsored programme, DOF
interviews etc) Newspaper _| will take for payment clearance after
Advertisements, Radio, TV _ {submission of the bills.
and Cable TV, Cinema etc.
Ww

<!-- page 6 -->

Point No. 4, Page |The agency must have proven _|Kindly confirm whether it is mandatory to Preference will be given to agency
No. 41 experience in Creative Advisory |demonstrate experience specifically in website {having experience in Central and State
services / Campaigns / Social management, or if experience limited to Government IEC Campaigns, ATL/BTL,
Media and Website Management |creative and campaign execution will be Social Media Campaigns, Branding, On-
for developing and implementing}acceptable. ground promotions etc. Website
communication and outreach Management may also be considered as
strategies during FY 2018-19 to an additional advantage.
FY 2024-25 (excluding FY
2020-21 and FY 2021-22)
Point No. 3, Page | Experience in development Kindly clarify whether ongoing projects (that |No Change, As per RFB
INo. 44 communication strategy, have reached an advanced stage of
designing, and implementation implementation) will be considered for
of comprehensive eligibility evaluation.
communication and outreach
17 strategy for Central/State
Government entities or projects
funded by World
Bank/AFD/other multilateral
agencies, with minimum contract
value not less than %3 crore per
Point No. 5, Page |Submission of a brief statement |Kindly confirm whether we are required to The version submitted with the proposal
INo. 44 not exceeding 20 pages. submit the final strategy document along with |should only be presented.
the proposal, or if. draft version can be
refined and presented during the presentation
stage.
Form Fin -2 1. Part-A Total Manpower Cost |1. Part-A Total Manpower Cost It is clarified that Agencies/Bidders are
[Summary of Cost required to quote Total Manpower cost
(Page No. -81) for 24 Months (2 years) for all 7 nos.
Manpower positions.
wv
