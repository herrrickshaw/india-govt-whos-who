---
doc_id: "b8a3baf4f7754ceb"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/11c9159481d0bfe38a5f02f804bf2740.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Draft dental posts Recruitment Rules Notification, 2015"
date: "2025-12-08"
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e8734a8e39c79cf0"
---

<!-- page 1 -->

<!-- page 2 -->

DRAFT

DENTAL POSTS RECRUITMENT
RULES NOTIFICATION, 2015

MINISTRY OF HEALTH & FAMILY WELFARE

<!-- page 3 -->

MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health & Family Welfare)
NOTIFICATION
New Delhi, the

G.S.R. ……… – In exercise of the power conferred by the proviso to article 309 of the Constitution and in supersession of Dental Posts
Recruitment Rules, 1997, Directorate General of Health Services (Maxillofacial Surgeon), Recruitment Rules, 1985 and amendments
made therein, except in respect of things done or omitted to be done before such supersession, the President hereby makes the
following rules regulating the terms and conditions of Dental Posts Recruitment Rules, namely:-

1.

Short title and commencement : --(i)
(ii)

2.

These rules may be called the Dental Posts Recruitment Rules, 2015.
They shall come into force on the date of their publication in the Official Gazette except the provisions relating to promotion in
various Grades under the Dynamic Assured Career Progression Scheme which is effective from 29.10.2008.

Application –-- These rules shall apply to the posts specified in column 1 of the Schedule annexed to these rules.

3.
Classification and the scale of pay---- The number of posts, their classification and the scale of pay attached thereto, shall be as
specified in Colum (2) to (4) of the Schedule annexed to these rules.
4. Method of recruitment age-limit and other qualification etc.---- the method of recruitment, age limit, qualifications and other
matters relating to the said posts shall be as specified in columns (5) to (13) of the said Schedule.

<!-- page 4 -->

5. Disqualification:

No person, ---

(a) Who has entered into or contracted a marriage with a person having a spouse living, or
(b) Who, having a spouse living, has entered into or contracted a marriage with any person
shall be eligible for appointment to any of the said posts
Provided that the Government may, if satisfied that such marriage is permissible under the personal law applicable to such
person and other party to the marriage and that there are other grounds for so doing, exempt any person from the operation of
this rule.
6. Power to relax:
Where the Government is of the opinion that it is necessary or expedient so to do, it may, by order, for reasons to be
recorded in writing, and in consultation with the Union Public Service Commission, relax any of the provisions of these rules
with respect to any class or category of persons.
7. Saving
Nothing in these rules shall affect reservations, relaxation of age-limit and other concessions required to be provided for
the Scheduled Castes, the Scheduled Tribes the other backward classes, the ex-servicemen and special categories of persons in
accordance with the orders issued by the Government from time to time in this regard.

<!-- page 5 -->

SCHEDULE
1. Dental Surgeon
Name of
post
1
Dental
Surgeon

Number of post

Classification

2

3
General Central service
Group ‘A’ Gazetted NonMinisterial

32*(2015)
(1)
(2)
(3)
(i)
(ii)
(iii)

Subject to variation dependent on workload.
To be operated at the level of Dental Surgeon/Junior Staff Surgeon, Staff Surgeon (Dental), Staff Surgeon (Dental)(NFSG),
Consultant in Dental Surgery put together.
Institution wise allocation of posts will be as under:---Central Govt. Health Scheme - 25
Dr. Ram Manohar Lohia Hospital - 4
Safdarjung Hospital–3

Pay Band and Grade Pay/Pay Scale

4
Pay Band-3 (Rs.15600-39100) with Grade Pay Rs.5400/- + Non- Practicing allowance at the rates prescribed
by Government of India from time to time.

Whether
Selection Post
or non-Selection
Post
5
Not applicable

Age limit for direct recruits

6
Not Exceeding 35 years
(Relaxable for Government servants upto 5 years
in accordance with the instructions or orders issued
by the Central Government )
Note: The crucial date for determining the agelimit, shall be as advertised by UPSC.

<!-- page 6 -->

Educational and other qualifications required for direct recruits

Whether age and Educational
qualification prescribed for direct recruits
will apply in the case of promotees.
8
Not applicable

7
Essential:
(i) A qualification included in part.I or part.II of the Schedule to the Dentists Act, 1948 (16 of 1948).
(ii)Should be registered with a Dental Council.
Note:- Qualifications are relaxable at the discretion of the Union Public Services Commission in case of candidates otherwise well qualified.

Period of Probation if any Method of Recruitment whether by direct recruitment or by promotion or by
deputation/ absorption and percentage of vacancies to be filled by various methods.
9
1 year

10
Direct recruitment
Note: Vacancies caused by the incumbent being away on transfer or deputation or long
illness or on study leave or under other circumstances for a duration of one year or more
may be filled by the appointing authority on transfer on deputation basis from officers of
Central Government or State Governments or Union Territories.
(a) (i) Holding analogous posts on regular basis, in the parent cadre or department; or
(ii) with 3 years’ regular service in Pay Band-2 (Rs. 9300-34800) with Grade Pay Rs.
4800/-.
(b) Possessing the educational qualifications and experience prescribed for direct
recruits under column 7.
(The maximum age limit for appointment on deputation shall be not exceeding 56 years
as on the closing date of receipt of applications by the Ministry).

If Departmental Promotion Committee exists, what is its composition
12
Group A Departmental Confirmation Committee:
1. Joint Secretary, Ministry of Health and Family Welfare---- Chairman
2. Director, Central Government Health Scheme---- Member
3. Deputy Secretary, Ministry of Health and Family Welfare ----Member

In case of recruitment by promotion/deputation/absorption
grades from which promotion/deputation/absorption to be
made.
11
Not applicable

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.
13
Consultation with Union Public Services Commission is necessary.

<!-- page 7 -->

2. Junior Staff Surgeon (Dental)

Name of post

Number of Post

Classification

1

2

3

Junior Staff Surgeon
(Dental)

As indicated in column (2) of the Schedule for the post of Dental
Surgeon.

General Central Service Group ‘A’ Gazetted Non- Ministerial

Pay Band and Grade Pay/Pay Scale

Whether
Selection Post
or non-Selection
Post
5

4
Pay Band-3 (Rs.15600-39100) with Grade Pay Rs.6600/- + Non- Practicing allowance at the rates prescribed by Government of India
from time to time.

Non-Selection
Post

Age limit for direct
recruits
6
Not Applicable

Educational and other qualifications required for direct recruits

Whether age and Educational qualification prescribed for direct recruits will apply in the case of
promotees.

7

8

Not Applicable

Not Applicable

<!-- page 8 -->

Period of Probation if any

9
Nil

Method of Recruitment whether by direct recruitment or by promotion or by deputation/
absorption and percentage of vacancies to be filled by various methods.
10
By Promotion on in-situ basis without linkage to vacancies.

In case of recruitment by
promotion/deputation/absorption grades
from which promotion/deputation/absorption
to be made.
11
Promotion
Dental Surgeon with four years regular service
in the grade with Grade Pay of Rs.5400/- in Pay
Band-3 (Rs.15600-39100).

If Departmental Promotion Committee exists, what is its composition

12
Group A Departmental/Promotion Committee (for in-situ promotion):--1. Additional Secretary Ministry of Health and Family Welfare --- Chairman.
2. Deputy Director General (DDG) of Health Services in Dte.GHS. – Member.
3. Joint Secretary, Ministry of Health and family welfare---- Member

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.
13
Not Necessary

3. Staff Surgeon (Dental)
Name of post

Number of Post

Classification

1

2

3

Staff Surgeon
(Dental)

As indicated in column (2) of the Schedule for the post of Dental Surgeon.

General Central Service Group A Gazetted Non- Ministerial

<!-- page 9 -->

Pay Band and Grade Pay/Pay Scale
4
Pay Band-3 (Rs.15600-39100) with Grade Pay Rs.7600/- + Non- Practicing
allowance at the rates prescribed by Government of India from time to time.

Whether
Selection Post
or non-Selection Post
5
Selection Post

Educational and other qualifications required for direct recruits
7
Not Applicable

Period of
Method of Recruitment whether by direct recruitment or by promotion or by
Probation if deputation/ absorption and percentage of vacancies to be filled by various
any
methods.
9
Nil

10
By Promotion on in-situ basis without linkage to vacancies.

Age limit for direct recruits
6
Not Applicable

Whether age and Educational qualification prescribed for direct recruits will apply
in the case of promotees.
8
Not Applicable

In case of recruitment by promotion/deputation/absorption grades from which
promotion/deputation/absorption to be made.
11
Promotion
Junior Staff Surgeon (Dental) with five years regular service in the grade with Grade
Pay of Rs.6600/- in Pay Band-3 (Rs. 15600-39100).

<!-- page 10 -->

If Departmental Promotion Committee exists, what is its composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
Group A Departmental/Promotion Committee (for in-situ promotion):--1
Additional Secretary Ministry of Health and Family Welfare --- Chairman.
2
Deputy Director General (DDG) of Health Services in Dte.GHS. – Member.
3 Joint Secretary, Ministry of Health and family welfare---- Member

13
Not Necessary

*3. Staff Surgeon (NFSG)

[ new post to be included in amended RR]
Name of post
1
Staff Surgeon(Dental) (NFSG)

Number of Post
2
As indicated in column (2) of the Schedule for the post of Dental
Surgeon.

Classification
3
General Central Service Group A Gazetted Non- Ministerial

Pay Band and Grade Pay/Pay Scale

4
Pay Band-4 (Rs.37400-67000) with Grade Pay Rs.8700/- + Non- Practicing allowance at the rates prescribed by Government of India
from time to time.

Whether
Selection
Post
or nonSelection
Post
5
Selection

Age limit for direct recruits

6
Not Applicable

<!-- page 11 -->

Educational and other qualifications required for direct recruits
7
Not Applicable

Period of Probation if any

9
Nil

Whether age and Educational qualification prescribed for direct recruits will apply in the case of
promotees.
8
Not Applicable

Method of Recruitment whether by direct recruitment or by
promotion or by deputation/ absorption and percentage of vacancies
to be filled by various methods.
10
By Promotion on in-situ basis without linkage to vacancies.

In case of recruitment by promotion/deputation/absorption
grades from which promotion/deputation/absorption to be
made.
11
Promotion
Staff Surgeon with four years regular service in the grade with
Grade Pay of Rs.7600/- in Pay Band-3 (Rs. 15600-39100).

If Departmental Promotion Committee exists, what is its composition

12
Group ‘ A’ Departmental Promotion Committee for considering In-situ promotion:1
2
3

Circumstances in which Union Public
Service Commission is to be consulted in making
recruitment.
13
Not Necessary

Additional Secretary, Ministry of Health and Family Welfare -- Chairman.
Deputy Director General (DDG) of Health Services in Dte.GHS. – Member.
Joint Secretary, Ministry of Health and Family Welfare--- Member

4. Consultant in Dental Surgery.
Name of post
1
Consultant in Dental
Surgery.

Number of Post
2
As indicated in column (2) of the Schedule for the post of Dental
Surgeon.

Classification
3
General Central Service Group A Gazetted Non- Ministerial

<!-- page 12 -->

Pay Band and Grade Pay/Pay Scale

4
Pay Band-4 (Rs.37400-67000) with Grade Pay Rs.10,000/- + Non- Practicing allowance at the rates prescribed by Government of
India from time to time.

Educational and other qualifications required for direct recruits
7
Not- Applicable

Whether
Selection Post
or nonSelection Post
5
Selection

Age limit for direct recruits

6
Not- Applicable

Whether age and Educational qualification prescribed for direct recruits will apply in the
case of promotees.
8
Not applicable

Period of
Method of Recruitment whether by direct recruitment or by promotion or by In case of recruitment by promotion/deputation/absorption grades from
Probation if
deputation/ absorption and percentage of vacancies to be filled by various methods.
which promotion/deputation/absorption to be made.
any
9
10
11
Not- Applicable By Promotion on in-situ basis without linkage to vacancies.
Promotion
Staff Surgeon (Dental) (NFSG) with seven years regular service in the
grade with Grade Pay of Rs.8700/- in Pay Band-4 or 20 years of regular
service in the stream.

If Departmental Promotion Committee exists, what is its composition

12
GROUP A DEPARTMENTAL PROMOTION COMMITTEE (FOR IN-SITU PROMOTION)1. Secretary Ministry of Health and Family Welfare --- Chairman
2. Director General of Health Services or Additional Director General of Health Services--- Member
3. Any Additional Secretary in Ministry of Health and Family Welfare --- Member

Circumstances
in
which
Union
Public
Service Commission is to be consulted in making
recruitment.
13
Not Necessary

<!-- page 13 -->

5. Assistant Professor:
Name of post
1
Assistant Professor

Number of Post
2
4(2015)

Classification
3
General Central service Group-‘A’ Gazetted Non- Ministerial

Pay Band and Grade Pay/Pay Scale

Whether
Selection Post
or non-Selection Post
5
Not applicable

4
Pay Band-3 (Rs.15600-39100) with Grade Pay Rs.6600/- +
Non- Practicing allowance at the rates prescribed by
Government of India from time to time.

Age limit for direct recruits
6
Not exceeding 40 years.
Note:- (relaxable for Government servants upto 5 years in accordance
with the instructions or orders issued by the Central Government )
Note:- The crucial date for determining the age limit shall be as
advertised by UPSC.

Educational and other qualification required for direct recruits

7
Essential :
(i)
(ii)
(iii)
(iv)

A qualification included on part I or Part II of the Schedule to the Dentists Act, 1948 ( 16 of 1948).
A post- graduate degree in Dental Surgery from a recognised University/ Institution.
Should be registered with a Dental Council.
3 years’ teaching experience in the specialty as Tutor/Demonstrator/ Registrar/ Senior Resident/ Lecturer after requisite post Graduate
qualification from a recognised teaching institution.
Note. 1- Qualifications are relaxable at the discretion of the Union Public Service Commission in case of candidates otherwise well
qualified.
Note. 2.- The qualification(s) regarding experience is/are relaxable at the discretion of the Union Public Service Commission in the case of
candidates belonging to Scheduled Castes or Scheduled Tribes if at any stage of selection the Union Public Service Commission is of the
opinion that sufficient number of candidates from these Communities possessing the requisite experience are not likely to be available to
fill up the vacancies reserved for them.

Whether age and Educational
qualification prescribed for direct
recruits will apply in the case of
promotees.
8
Not applicable

<!-- page 14 -->

Period of Probation if any

Method of Recruitment whether by direct recruitment or by promotion or by deputation/ absorption
and percentage of vacancies to be filled by various methods.

9
1 year

10
Direct recruitment :
Note: Vacancies caused by the incumbent being away on transfer on deputation or long illness or on study
leave or under other circumstances for a duration of one year or more may be filled by the appointing authority
on transfer on deputation basis from officers of Central Government or State Governments or Union
Territories.
(a) (i) Holding analogous posts on regular basis, in the parent cadre or department; or
(ii) with 3 years’ regular service in Pay Band-3 (Rs. 15600-39100) with Grade Pay Rs. 5400/-.
(b) Possessing the educational qualifications and experience prescribed for direct recruits under column 7.
Note: The maximum age limit for appointment on deputation shall be not exceeding 56 years as on the
closing date of receipt of applications by the Ministry.

If Departmental Promotion Committee exists, what is its composition
12
Group ‘A’ Departmental Confirmation Committee (for Confirmation):1. Additional Secretary Ministry of Health and Family welfare.--- Chairman
2. Deputy Director General (DDG) of Health Services in Dte.GHS. – Member.
3. Joint Secretary Ministry of Health and Family Welfare. --- Member.

In case of recruitment by
promotion/deputation/absorption
grades from which
promotion/deputation/absorption to be
made.
11
Not applicable

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.
13
Consultation with Union Public Services commission is necessary.

<!-- page 15 -->

6. Associate Professor:
Name of post
1
Associate Professor

Number of Post
2
As indicated in column (2) of the Schedule for the post of Assistant
Professor.

Classification
3
General Central service Group ‘A’ Gazetted Non- Ministerial

Pay Band and Grade Pay/Pay Scale
4
Pay Band-3 (Rs.15600-39100) with Grade Pay Rs.7600/- + Non- Practicing allowance at the rates prescribed by Govt. of India
from time to time .

Educational and other qualification required for direct recruits
7
Not Applicable

Period of Probation if
any
9
Nil

Whether
Selection Post
or non-Selection Post
5
Selection

Age limit for direct recruits
6
Not Applicable

Whether age and Educational qualification prescribed for direct recruits will apply in the case of promotees.
8
Not Applicable

Method of Recruitment whether by direct recruitment or by
promotion or by deputation/ absorption and percentage of
vacancies to be filled by various methods.
10
By Promotion on In-situ basis without linkage to vacancies.

In case of recruitment by promotion/deputation/absorption grades from which
promotion/deputation/absorption to be made.
11
Promotion
Assistant Professor with two years regular service in the grade with Grade Pay of
Rs.6600/- in Pay Band-3 (Rs.15600-39100).

<!-- page 16 -->

If Departmental Promotion Committee exists, what is its composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
Group ‘ A’ Departmental Promotion Committee for Considering In-stiu Promotion:1. Additional Secretary ---Ministry of Health and family Welfare.--- Chairman
2. Deputy Director General (DDG) of Health Services in Dte.GHS. – Member.
3. Joint Secretary, Ministry of Health and Family welfare--- Member

13
Not Necessary

7. Professor:
Name of post
1
Professor

Number of Post
2
As indicated in column (2) of the Schedule for the post of Assistant Professor.

Scale of Pay
4
Pay Band-4 (Rs.37400-67000) with Grade Pay of Rs.8700/- + Non- Practicing allowance at the rates
prescribed by Government of India from time to time.

Educational and other qualification required for direct recruits
7
Not Applicable

Classification
3
General Central service Group ‘A’ Gazetted Non- Ministerial

Whether
Selection Post
or non-Selection Post
5
Selection

Age limit for direct recruits
6
Not Applicable

Whether age and Educational qualification prescribed for direct recruits will apply in the case of
promotees.
8
Not Applicable

<!-- page 17 -->

Period of
Probation
if any

Method of Recruitment whether by direct recruitment or
by promotion or by deputation/ absorption and percentage
of vacancies to be filled by various methods.

In case of recruitment by promotion/deputation/absorption grades from which
promotion/deputation/absorption to be made.

9
Nil

10
By Promotion on In-situ basis without linkage to vacancies.

11
Associate Professor with 4 years regular service in the Grade with Grde pay of Rs. 7600/- in
PB-3 (Rs.15600-39100).

If Departmental Promotion Committee exists, what is its composition
12
Proposed
Group ‘ A’ Departmental Promotion Committee for Considering In-situ
Promotion:-

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.
13
Existing
Not Necessary

1 Additional Secretary, Ministry of Health and Family Welfare.--Chairman.
2 Deputy Director General (DDG) of Health Services in Dte.GHS. –
Member.
3. Joint Secretary, Ministry of Health and Family Welfare--- Member

8. Professor (SAG).
Name of post
1
Professor
(SAG).

Number of Post
2
As indicated in column (2) of the Schedule for the post of Assistant
Professor.

Classification
3
General Central Service Group A Gazetted Non- Ministerial

<!-- page 18 -->

Pay Band and Grade Pay/Pay Scale

4
Pay Band-4 (Rs.37400-67000) with Grade Pay Rs.10,000/- + Non- Practicing allowance at the rates prescribed by Government of
India from time to time.

Educational and other qualifications
required for direct recruits
7
Not- Applicable

Period of
Probation if
any
9
NotApplicable

Whether
Selection
Post
or nonSelection
Post
5
Selection

Age limit for direct recruits

6
Not- Applicable

Whether age and Educational qualification prescribed for direct recruits will apply in the case of promotees.
8
Not applicable

Method of Recruitment whether by direct recruitment or by
promotion or by deputation/ absorption and percentage of
vacancies to be filled by various methods.
10
By Promotion on In-situ basis without linkage to vacancies.

In case of recruitment by promotion/deputation/absorption grades from which
promotion/deputation/absorption to be made.
11
Promotion
Professor with seven years regular service in the grade with Grade Pay of Rs.8700/- in Pay
Band-4 (Rs.37400-67000).

<!-- page 19 -->

If Departmental Promotion Committee exists, what is its composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
GROUP A DEPARTMENTAL PROMOTION COMMITTEE (FOR CONSIDERING
IN-SITU PROMOTION)1. Secretary, Ministry of health and Family Welfare ---- Chairman
2. Director General of Health Services/ Additional Director General of Health
Services- Member
3. Any Additional Secretary in the Ministry of health and Family Welfare- Member.

13
Not Necessary

1. Maxillofacial Surgeon:
Name of post
1
Maxillofacial
Surgeon

Scale of Pay
4
Pay Band-3 (Rs.15600-39100) with Grade Pay
Rs.6600/- in + Non- Practicing allowance at the
rates prescribed by Government of India from
time to time.

No. of post
2

Classification
3
General Central service Group-‘A’ Gazetted Non- Ministerial.

1 (2015)*
*subject to variation dependent upon workload

Whether
Selection Post
or non-Selection Post
5
Not applicable.

Age limit for direct recruits
6
Not exceeding 40 years.
Note:- (Relaxable for Government servants upto 5 years in accordance with the
instructions or orders issued by the Central Government)
Note:- The crucial date for determining the age limit shall be as advertised by UPSC.)

<!-- page 20 -->

Educational and other qualification required for direct recruits

7
Essential :
(i)
A qualification included on part I or Part II of the Schedule to the Dentists Act, 1948 ( 16 of 1948).
(ii)
A post- graduate qualification in Dentistry i.e. M.D.S. in Oral Surgery/Prosthodontics from a recognised University or equivalent.
(iii)
7 years’ experience in Dental work in a hospital which should include a minimum of 3 years’ experience in a plastic & Maxillofacial Surgery
unit after Post-Graduation; and
(iv)
Should be registered with a Dental Council.
Note. 1- Qualifications are relaxable at the discretion of the Union Public Service Commission in case of candidates otherwise well qualified.
Note. 2.- The qualification(s) regarding experience is/are relaxable at the discretion of the Union Public Service Commission in the case of
candidates belonging to Scheduled Castes or Scheduled Tribes if at any stage of selection the Union Public Service Commission is of the opinion
that sufficient number of candidates from these Communities possessing the requisite experience are not likely to be available to fill up the
vacancies reserved for them.

Whether age and
Educational qualification
prescribed for direct recruits
will apply in the case of
promotees.
8
Not applicable

<!-- page 21 -->

Period of Method of Recruitment whether by direct recruitment or by promotion or by deputation/ transfer and percentage of vacancies to
Probation be filled by various methods.
if any
9
1 year

10
Direct Recruitment.
Note: Vacancies caused by the incumbent being away on transfer on deputation or long illness or on study leave or under other
circumstances for a duration of one year or more may be filled by the appointing authority on transfer on deputation basis from officers of
Central Government or State Governments or Union Territories.
((a) (i) Holding analogous posts on regular basis, in the parent cadre or department; or
(ii) with 3 years’ regular service in Pay Band-3 (Rs. 15600-39100) with Grade Pay Rs. 5400/-.
(b) Possessing the educational qualifications and experience prescribed for direct recruits under column 7.
Note: The maximum age limit for appointment on deputation shall be not exceeding 56 years as on the closing date of receipt of
applications by the Ministry.

In case of Rectt. By
promotion/deputation/transfer,
grades from which
promotion/deputation/transfer
to be made.
11
Not applicable

If Departmental Promotion Committee/ Exists, what is its
composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
Group ‘A’ Departmental Confirmation Committee (for Confirmation):1. Additional Secretary Ministry of Health and Family welfare.-- Chairman
2. Deputy Director General (DDG) of Health Services in
Dte.GHS. – Member.
3. Joint Secretary Ministry of Health and Family Welfare. --Member.

13
Consultation with Union Public Services commission is necessary.

<!-- page 22 -->

2. Maxillofacial Surgeon(Senior Scale)
Name of post
1
Maxillofacial
Surgeon (Senior Scale)

No. of post
2
As indicated in column 2 of the schedule for the post
of Maxillofacial Surgeon.

Classification
3
General Central service Group-‘A’ Gazetted Non- Ministerial.

Scale of Pay

Whether
Selection Post
or non-Selection Post
5
Selection.

Age limit for direct recruits

4
Pay Band-3 (Rs.15600-39100) with Grade Pay
Rs.7600/- in + Non- Practicing allowance at the
rates prescribed by Government of India from
time to time.

6
Not applicable.

<!-- page 23 -->

Educational and other qualification required for direct recruits

Whether age and Educational qualification prescribed for direct recruits will apply in the case of promotees.

7
Not applicable.

8
Not applicable

Period of Method of Recruitment whether by direct recruitment or by promotion or by deputation/ transfer and percentage of vacancies
Probation to be filled by various methods.
if any
9
Nil

10

In case of Rectt. By
promotion/deputation/transfer,
grades from which
promotion/deputation/transfer to be
made.
11

By Promotion on In-situ basis without linkage to vacancies.
Promotion
Maxillofacial Surgeon with 2 years
regular service in the grade with Grade
Pay of Rs. 6600/- in PayBand-3 (Rs.
15600-39100).

<!-- page 24 -->

If Departmental Promotion Committee/ Exists, what is its
composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
GROUP A DEPARTMENTAL PROMOTION COMMITTEE (FOR
CONSIDERING IN-SITU PROMOTION)1. Additional Secretary Ministry of Health and Family welfare.-- Chairman
2. Deputy Director General (DDG) of Health Services in
Dte.GHS. – Member.
3. Joint Secretary Ministry of Health and Family Welfare. --Member.

13
Not Necessary

3. Maxillofacial Surgeon (NFSG)
Name of post
1
Maxillofacial
Surgeon (NFSG)

No. of post
2
As indicated in column 2 of the schedule for the post
of Maxillofacial Surgeon.

Classification
3
General Central service Group-‘A’ Gazetted Non- Ministerial.

Scale of Pay

Whether
Selection Post
or non-Selection Post
5
Selection.

Age limit for direct recruits

4
Pay Band-4 (Rs.37400-67000) with Grade Pay
Rs.8700/- in + Non- Practicing allowance at the
rates prescribed by Government of India from
time to time.

6
Not applicable.

<!-- page 25 -->

Educational and other qualification required for direct recruits

Whether age and Educational qualification prescribed for direct recruits will apply in the case of
promotees.

7
Not applicable.

8
Not applicable

Period of Method of Recruitment whether by direct recruitment or by promotion or by deputation/ transfer and percentage of vacancies
Probation to be filled by various methods.
if any
9
Nil

10

In case of Rectt. By
promotion/deputation/transfer,
grades from which
promotion/deputation/transfer to be
made.
11

By Promotion on In-situ basis without linkage to vacancies.
Promotion
Maxillofacial Surgeon (Sr. Scale) with
4 years regular service in the grade
with Grade Pay of Rs. 7600/- in
PayBand-3 (Rs.15600-39100).

<!-- page 26 -->

If Departmental Promotion Committee/ Exists, what is its
composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
GROUP A DEPARTMENTAL PROMOTION COMMITTEE (FOR
CONSIDERING IN-SITU PROMOTION)1. Additional Secretary Ministry of Health and Family welfare.-- Chairman
2. Deputy Director General (DDG) of Health Services in
Dte.GHS. – Member.
3. Joint Secretary Ministry of Health and Family Welfare. --Member.

13
Not Necessary

4. Maxillofacial Surgeon (SAG)
Name of post
1
Maxillofacial
Surgeon (SAG)

No. of post
2
As indicated in column 2 of the schedule for the post
of Maxillofacial Surgeon.

Classification
3
General Central service Group-‘A’ Gazetted Non- Ministerial.

Scale of Pay

Whether
Selection Post
or non-Selection Post
5
Selection.

Age limit for direct recruits

4
Pay Band-4 (Rs.37400-67000) with Grade Pay
Rs.10000/- in + Non- Practicing allowance at
the rates prescribed by Government of India
from time to time.

6
Not applicable.

<!-- page 27 -->

Educational and other qualification required for direct recruits

Whether age and Educational qualification prescribed for direct recruits will apply in the case of promotees.

7
Not applicable.

8
Not applicable

Period of Method of Recruitment whether by direct recruitment or by promotion or by deputation/ transfer and
Probation percentage of vacancies to be filled by various methods.
if any
9
Nil

In case of Rectt. By promotion/deputation/transfer,
grades from which promotion/deputation/transfer
to be made.

10
By Promotion on In-situ basis without linkage to vacancies.

11
Promotion
Maxillofacial Surgeon (NFSG) with 7 years regular
service in the grade with Grade Pay of Rs. 8700/- in
PayBand-4 (Rs.37400-67000).

If Departmental Promotion Committee/ Exists, what is its composition

Circumstances in which Union Public
Service Commission is to be consulted in making recruitment.

12
GROUP A DEPARTMENTAL PROMOTION COMMITTEE (FOR
CONSIDERING IN-SITU PROMOTION)1. Secretary Ministry of Health and Family welfare.--- Chairman
2. Director General of Health Services/Additional Director
General of Health Services – Member.
3. Any Additional Secretary in the Ministry of Health and Family
Welfare. --- Member.

13
Not Necessary

.
