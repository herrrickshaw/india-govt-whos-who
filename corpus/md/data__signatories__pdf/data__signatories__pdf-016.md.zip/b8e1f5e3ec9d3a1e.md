---
doc_id: "b8e1f5e3ec9d3a1e"
source_url: "https://mnre.gov.in/static/uploads/2026/10/14220987ac8f7f7d5885acfa9027aa85.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "BRESE Quiz Results- Young Professionals"
date: "2026-10-21"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "478e924c1950f5d4"
---

<!-- page 1 -->

Ministry of New & Renewable Energy
Atal Akshay Urja Bhawan
Lodhi Road 110003
Subject: - BRESE QUIZ RESULT
The following result is declared for Young Professionals.
Team | Participant 1 | Participant 2 woe
Fal ID P41 P2 Organization Name
College of Dairy &
4 Northern | 1424 Shailesh Kr. | Manisha Food Technology,
Meena Kumar Bassi, Jaipur,
Rajasthan
Indian Sugar &
Nishant age Bioenergy
2 Northern | 1295 Yadav Sukriti Sharma Manufacturing
Association, Delhi
. हि Idam Infrastructure
3 | Northern | 1330 | “ai Kumar | Shiva Prasath | A vicory Pvt. Ltd.,
Dhawal SR श्र
Delhi
Navyashree | Yogeshwaran | Mercom India,
4 Southern | 1337 CP. M. Karnataka
Subhradeep Bosch & Hulas,
$ Delhi Public School,
Eastern 1325 wey Anjali Kumari | Bokaro Steel City,
Jharkhand
Md. Affan Baishali CSIR-IMMT
Muktade . . Madrasa Falahul
Joseph Remote Software
Western 1394 Aayush Jonathan Solutions Pvt. Ltd.,
Jhadav
Fernandes Goa
Paulami CSIR-National
10 Western | 1351 Sadhukhan Sumit Dey Chemical
Laboratory, Pune
Signed
pie
fit all
Shri Sujit Pillai
Scientist +' MNRE
