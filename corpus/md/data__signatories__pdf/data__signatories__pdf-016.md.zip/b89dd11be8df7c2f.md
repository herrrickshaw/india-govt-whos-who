---
doc_id: "b89dd11be8df7c2f"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/0d8088e3f3d8c91a7158fb29ee1d6594.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Action Taken Notes On The Issues Raised In The 60th Central Advisory Board Of Education (Cabe) Meeting Held On 8th November, 2012"
date: "2012-11-08"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "65c5f2cb097cb0ec"
---

<!-- page 1 -->

Action Taken Notes on the Issues raised in the 60th Central Advisory Board of Education (CABE)
Meeting held on 8th November, 2012 at Taj Palace Hotel, New Delhi
S.No.
1.

Name of Hon’ble
Suggestion(s)
Action Taken
Minister/Member
Sh. K. Rahman Khan Minster of CABE may like to constitute a SubThere is already a National Monitoring Committee
Minority Affairs
Committee to look into educational for Minorities’ Education (NMCME) with representation
empowerment of Minorities’
of eminent educationists, Members of Parliament,
representatives of State Governments and representatives
of Minority Communities, educational Institutions and
other stakeholders.
There is also a Standing Committee of the National
Monitoring Committee for Minorities’ Education
(NMCME) to monitor the minority related schemes /
programmes being implemented by Ministry of Human
Resource Development. The report of the Standing
Committee is being finalised.
A separate agenda item 11 on elimination of Gender
& Social Gaps is also placed in 61st meeting of CABE.

2.

Presentation on High Powered The Commission has made the following
Commission headed by Justice broad recommendations :
J.S. Verma
 The first recommendations is to have
pre-service test for entry into teacher
education
institutions.
The
Commission said that in view of a
large number of TET tests where
majority of the teachers were failing
(in CBSE 92% teachers failed, in

The Ministry has decided to constitute an expert
body to develop a comprehensive policy on in-service
teacher education, so that it is more in line with the needs
of the teachers, and the students.
Government of India has already approved Rs. 6300
crores for the teacher education project and had requested
UGC to start Schools of Education (SOEs) in all the
central universities. For those state universities which

<!-- page 2 -->

3.

Gujarat 97% of teachers failed) it
would be better to give TET –like tests
before entry into the teacher education
institutions.
 The second recommendation is
regarding the need for enhancing
teacher education capacity in the
eastern part of the country and in the
North Easter region.
 The third major recommendation is
that given that present day teacher
education institution are stand-alone
institutions, and that there is very
limited interaction with other subjects,
teacher education institutions should
be set up in a multi and inter
disciplinary academic environment.
 The fourth recommendation is that
teacher education should be a part of
higher education. Further, teacher
education programmes should be
redesigned and aligned with NCFTEnational Curriculum Framework for
Teacher Education
Dr. Mithu Alur, Founder A structural shift is necessary that special
Chairperson, Spastics Society of inclusive education comes under MHRD and
India
universities should have disability coordinator
or an inclusive Ed module. These could be
short modules of actually how to bring in all
marginalised children and not just children
with disability.

still do not have Schools of Education, the states could
take up this aspect alongwith the development of a
framework on school audit and teacher performance and
strengthen the BRCs, and CRCs and their institutional
linkage with the DIETs.

(i)
NCTE teacher qualification guidelines provide that
a diploma/degree course in Teacher Education recognised
by the NCTE only shall be considered. In case of
Diploma in Education (Special Education) and B.Ed
(Special Education) a course recognised by the
Rehabilitation Council of India (RCI) only shall be
considered. The guidelines further provide that a person
with D.Ed (Special Education) or B.Ed (Special
Education) qualification shall undergo, after appointment,
an NCTE recognised 6-month special programme in

<!-- page 3 -->

Elementary Education.

4.

5.

Shri Mantri Prasad Naithani,
Hon’ble Education Minister
School, Uttrakhand

Dr. Vinod Raina, Educationist



Given the economic state of
Uttrakhand, the fund sharing pattern in
case of Uttrakhand should be 90:10



He also requested that CABE should
made yoga compulsory as it will
reduce the unemployment of diploma
holders in Physical Education.



He also stated that the TET and
mentioned that thousands of boys and
girls who did B.Ed prior to 2009 are
unemployed. Now it is very difficult
for them to qualify TET for getting
basic employment. He stressed the
need for grant of relaxation in such pre
2009 cases so that they may be
considered for employment against the
vacant posts in Schools.



The issue of pupil teacher ratio under
RTE, should not be gauged at the
Block or District level but at the level
of schools. Data is also required not
just about sanctioned facilities, but
also functionality.

(ii)
XII Plan document, as approved by NDC on 27th
December 2012, also proposes to launch a National
Initiative on Inclusion of Persons with Disabilities under
Higher Education
 The fund sharing pattern between Centre and
States under SSA is as per decision of the Cabinet.
The ratio of 90:10 is applicable only to the north
eastern states as per the Cabinet decision.
 Physical Education is already part of the
curriculum at the school level.



To ensure the availability of quality teachers, the
National Council for Teacher Education (NCTE)
has laid down the teacher qualifications under
section 23 of the RTE Act. One of the essential
conditions for a person to be eligible for
appointment as a teacher is that he/she should pass
the Teacher Eligibility Test (TET) to be conducted
by the appropriate Government. Parting the TET
is mandatory for appointment as teacher even if a
person has done B.Ed prior to the notification.

There is no dispute on the fact that PTRs under RTE
are related to each school as the DISE data is provided for
each school. The states need to take up
rationalisation/redeployment in addition to recruitments
so that PTR gets evenly distributed across states.

<!-- page 4 -->

6.

7.

8.

9.

Shri P.K. Shahi,
Minister (Bihar)

Education He stated that State did not get any funding
Relaxation in the ratio of funding pattern under SSA
last year under RMSA. He then made a is only available to the North-Eastern states
request to consider special funding ratio for
States like Bihar.
Shri Ram Govind Chaudhary, He made request to raise the funding for UP
Relaxation in the ratio of funding pattern under SSA
Education
Minister
(Uttar in the ratio of 80:20 given the size of the is only available to the North-Eastern states.
Pradesh)
State.
Ms. Kiran Walia, Hon’ble She called for the need for evaluative
As per the resolution adopted in the 59th meeting of
Education Minister, NCT of examinations for certain primary level.
the CABE held on 6th June, 2012, a Sub Committee of
Delhi
CABE headed by Smt. Geeta Bhukkal, Hon’ble Minister
of Education, Government of Haryana was constituted for
Assessment and Implementation of Continuous and
Comprehensive Education (CCE) in the context of the
non detention provision in the RTE Act.

Shri Rabi Narayan Nanda,
Hon’ble Minister of School and
Mass Education, Odisha



The Sub Committee has so far met twice, first on
06.08.2012 and for the second time on 19.10.2012. As
per the decision of the Sub Committee, comments of all
States/UTs are being collected on the progress made by
them in the implementation of CCE and in the
enforcement of the no-detention provision as well as
regarding the problems faced by them in attaining the
progress. The Sub Committee is likely to meet again very
shortly.
He emphasized on students who were
 SSA norm on uniforms provide as under:yet to received uniforms and that
discrimination should not be done on
(a) Two sets of uniforms for all girls, and children
the basis of BPL/APL for the same.
belonging to SC/ST/BPL families in Government
schools within a ceiling of Rs. 400/- per child per
annum.
(b) Wherever States are providing uniforms as per
their 2009-10 budgets, they shall continue to do
so from their State budgets.
(c) In case any State is partially subsidizing the cost

<!-- page 5 -->

of uniforms provided to children in elementary
classes, assistance under SSA would be restricted
to the remaining portion of the unit cost.


10. Dr. S. Sailajanath,
Education Minister,
Pradesh

He also called for the provision of
funds under the RMSA and SSA for
private schools started in states like
Odisha and West Bengal 30-40 years
back when the governments were
unable to provide schools to allow to
undertake building renovations etc.
Hon’ble He pointed out that while availability of
Andhra teachers was not an issue in Andhra Pradesh,
provision of uniforms was and asked for
flexibility on the matter. He also asked for
the provision of compound walls for KGBVs.
For children in tribal areas, he sought
permission for satellite or branch schools to
be established as in certain cases where there
are only 3-4 children.



SSA and RMSA norms do not provide for funding
of private schools for undertaking building
renovations etc.



SSA norm on uniforms provide as under:-

a) Two sets of uniforms for all girls, and children
belonging to SC/ST/BPL families in Government
schools within a ceiling of Rs. 400/- per child per
annum.
b) Wherever States are providing uniforms as per
their 2009-10 budgets, they shall continue to do so
from their State budgets.
c) In case any State is partially subsidizing the cost
of uniforms provided to children in elementary
classes, assistance under SSA would be restricted
to the remaining portion of the unit cost.

11. Shri Arun Kapur, Member He emphasised upon the need to put in place a
CABE & Director, Vasant deadline for ensuring that all children are put
Valley Foundation
in schools, as opposed to only ensuring RTEcompliance by schools. He also pointed out
that the society was becoming over-schooled
yet under-educated, so emphasis on quality is
also crucial.

Since the launch of Sarva Siksha Abhiyan in 2001,
the number of out of school children has come down from
3.2 crore in 2002-3 to 81.5 lakh in 2009-10 as per an
independent study commissioned by MHRD. Another
study is being commissioned to further assess the number
of children who are still out of school. Under SSA-RTE,
now the focus is on quality education.

<!-- page 6 -->

12. Shri Bosiram Siram, Hon’ble He pointed to the problem of training the
Government is aware of the large number of
Education Minister, Arunachal teachers who were appointed before the untrained teachers. Training of untrained teachers has
Pradesh
enforcement of RTE and who lack the been undertaken in a mission mode under SSA. Funds
requisite qualification.
are being sanctioned to states for this purpose .
13. Shri Himanta Biswa Sarms, Hon’ble Education Minister, Shri Himanta
Hon’ble Education Minster, Biswa Sarma pointed to the issues faced by
Assam
Assam with regard to the requirement of faceto-face transmission of the first professional
degree as the state lacked the requisite
teaching institutes. He also called for a
mechanism for the accreditation and audit of
schools at the secondary and elementary level
under the RMSA, especially given the fact
that after the introduction of the CEE, no
board level examination is taking place upto
class VIII. So the state government has no
mechanism to assess the health of an institute
because from class I to VIII there is no
examination by board and suddenly at class
X, the students appear in the board exam and
the blame goes to the secondary stream, there
being no accounting or audit for the
elementary level.
14. Shri Rajendra S. Pawar, He suggested looking at a blended model of
Chairman, NIIT
taking what we have in real estate and faculty
and using technology innovative to leverage it
to reach out to more students with better
quality.
15. Shri Prem Narain, Secretary,
 Shri Prem Narain, Secretary, WCD,
Ministry of Women & Child
Government of India, raised the issue
Development
of review of curriculum at all level
and particularly at the primary and
secondary level; especially with

Notification to this effect was issued in the light of
provisions of RTE-Act 2009.

An agenda item is being introduced in 61st Meeting
of CABE on leveraging ICT for education.

Curriculum renewal has been undertaken and done
by a large number of states. Only a few states are left
which are yet to carry out curriculum renewal. However,
work in this regard is in progress.

<!-- page 7 -->

regards to gender sensitisation, good
habits and practices, importance of
nutrition, etc. and called for an expert
committee to be appointed to look into
this.


He also discussed the issues of proper
infrastructure particularly in the
primary and secondary levels,
especially keeping in mind how girls
‘education has been affected due to
shortage of sanitation facilities in
schools. He also emphasised upon the
need for ensuring the security of
children, especially girls.



Under Sarva Shiksha Abhiyan all new school
buildings are sanctioned as composite buildings
which include toilets for girls and boys; and
drinking water facilities etc. For existing rural
schools drinking water and toilet facilities are
constructed in convergence with schemes of the
Ministry of drinking water and sanitation. As per
DISE 2011-12 (provisional), 94.3% Government
elementary schools have drinking water facilities
& 87.9% schools have toilets. The RTE Act,
2009 provides a time frame of three years from
the commencement of the Act for completion of
school infrastructure. Under SSA, 3.04 lakh
school buildings, 17.92 lakh Additional Class
Rooms(ACR), 8.53 lakh toilets and 2.29 lakh
drinking water facilities have been sanctioned till
2012-13.



In order to fill the gap between the requirement
and the existing infrastructure in the Government
Secondary
Schools,
34,311Government
Secondary School have been approved for
strengthening of infrastructure under Rashtriya
Madhyamik Siksha Abhiyan since its inception in
2009. The infrastructure sanctioned for these
schools include Additional Class Rooms (49,356),
Science Labs (23,407), Lab Equipment(23,961),
Computer Rooms (19,641), Art/Craft/Culture

<!-- page 8 -->

Rooms (28,969), Libraries (25,869), Toilets
(19,401), Drinking Water facilities (12,370) &
major repairs (9,228).
16. Dr. Krishan
INSA

Lal,

President, He suggested undertaking a study on the
The suggestion will be incorporated in the National
magnitude of problem of vacancies in all Mission on Teacher’s and Teaching.
teaching institutions.
