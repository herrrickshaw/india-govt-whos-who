---
doc_id: "b7dadf3a5a1394ac"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/f7aa7234e77da1956e4a8a553c178cfb.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "List of amendments carried out in Letters of Intent"
date: "2025-07-23"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b2ae8c0f9621849b"
---

<!-- page 1 -->

List of Amendments carried out in Letters of Intent
During June 2001
S.NO

NAME OF THE
COMPANY

LOINO. &
DATE

AMENDMENT CARRIED
OUT

NO.&DATE

1.

M/s.Camellia Clothing Ltd

126(2000)
dated
21.6.2000

Change of name of the
Company from M/s.Camellia
Silks Pvt Ltd to M/s Camellia
clothing Ltd

126(2000)/2001Amendment
dated 21.6.2001

2.

M/s.Adwith Textiles
Limited

94(96) dated
19.3.1996

Change of name of the
Company from M/s. Adwaith
Textiles Pvt Ltd to Adwaith
Textiles Limited

94(96)/2001Amendment
dated 26.6.2001

3.

M/s.Indian Explosives
Limited

93(99)

Inclusion of new locations
namely Sohapur Area, in
Shahdol, Madhya Pradesh and
kathara Area, in Bokaro, Bihar
in the letters of intent

93(99)/2001Amendment
dated 26.6.2001

M/s.machino-Basell India
Ltd

63(1996)

Change of the name of the Co.
from M/s.Machino Montell
India Ltd to M/s. Machino
Basell India Ltd in the LOI

63(96)/2001Amendment
dated 21.6.2001.

4.

dated
21.9.1999

dated
16.2.96
