---
doc_id: "b9ec7d0f5bf8ce5f"
source_url: "https://www.dahd.gov.in/static/uploads/2025/08/4461366d099b0a75c1a5ea421dbca982.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "In continuation of the Office Order dated 01.08.2025, it is hereby ordered that Shri R.P.S. Rathore, Director, shall hold the additional charge of the Animal Welfare Division with immediate effect and until further orders."
date: "2025-08-04"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "033d051b74ba12d5"
---

<!-- page 1 -->

A-22012/01/2019-Admn.1/(E-16297)
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Animal Husbandry and Dairying
Krishi Bhawan, New Delhi
Dated, the 4th August, 2025
OFFICE ORDER
In continuation of the Office Order dated 01.08.2028, it is hereby ordered that
Shri R.P.S. Rathore, Director, shall hold the additional charge of the Animal
Welfare Division with immediate effect and until further orders.
2, He shall discharge the duties and responsibilities pertaining to the Animal
Welfare Division in addition to his existing responsibilities.
This issues with the approval of the Competent Authority.
८८०
(Pankaj Kumar Sinha)
Under Secretary to the Government of India
Tele: 011-23382779
To
1. Shri R.P.S. Rathore, Director
2. Sr. PPS/PPS to AS(C&DD)AS(LH)/AHC/JS(Admin)/JS(NLM)/Adv.(Stats.)
3. DDO/Cash/Vigilance/GA/APAR/RTI/IC/Hindi/IT/Parliament/R&| Section
4. Personal File/Order Bundle/Guard File
5. NIC for uploading on the website/e-office of the Department.
Copy for information to:-
Sr. PPS to Secretary, AHD
