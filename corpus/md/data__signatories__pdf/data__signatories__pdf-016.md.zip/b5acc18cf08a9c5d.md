---
doc_id: "b5acc18cf08a9c5d"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/6fe933bdfec5530c5ad7400ed7fc5c31.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Vice Chancellor of Tripura University"
date: "2017-10-18"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f77397fa5a66309b"
---

<!-- page 1 -->

Government of India
Ministry of Human Resource Development
Department of Higher Education
Appointment of Vice-Chancellor of Tripura University

(A Central University)
Tripura University is a Central University established by Tripura University
Act, 2006.
The Vice-Chancellor, being the academic as well as administrative head, Is
expected to be:
•A visionary with proven leadership qualities, administrative capabilities as
well as teaching and research credentials.
•Having outstanding academic record throughout and a minimum of 10
years' experience as a Professor in a University system or in an equivalent
position in a reputed research and/ or academic administrative organization.
•Not more than 65 years of age as on the closing date of receipt of
applications of this advertisement.
Salary and Service Conditions
•The post carries a pay of Rs. 75,000/- (Fixed) per month with Special
Allowance of Rs. 5000/- and other usual allowances.
•The terms and conditions of the services will be those as set forth in the Act,
Statutes and Ordinances of the University.
Procedure for appointment
•Appointment will be made from a panel of names recommended by a
Committee constituted under the provisions of the Tripura University Act.
•The advertisement and the format of application are available on the
websites http://*T|^ir*l.gov.in and www.tripurauniv.in
•The applications in the prescribed proforma should reach within 30 days
from the date of the publication of this advertisement, by Registered/Speed
Post to:
Shri Surat Singh, Deputy Secretary,
Department of Higher Education, Ministry of HRD,
Room No.325, C* Wing, Shastri Bhawan, New Delhi-110115
'Application for the post of Vice Chancellor, Tripura University",
should be super-scribed on the envelope.
This Department is not res^onsible for postal delay.

<!-- page 2 -->

1R1 7T7TR7

ift Ri^ftn
y ft^^ft^id^ ar^^^^RrH, 2006' eTttt Tuft^ tj^ ^fti R?eiftEj)ci^j

f ^^^^ ^ ^^t ai^ TT^Fnf^ sR^^it ^ ^^^T tj^ ^-i cj^f ^ ^nai f^ian 3f^
5RTI

IT^cT ^ ^^14H t^f^T 17 65

^^T H 17 75,000/— ^ (^lR^cT) if^RT^ ^ 7TTST 5,000/—
3RT 7TRRT ^^^t H gicTR ^ttTT tl

15 Pi^^ti ^rg^T t^yciR^iM^ 3^PiiR ^ ira^Rf ^ ^i^^fcT i^^cT i^ Tr^^fcr etttt

•

15 ^^^i1^^i 3^7 3)ft^ n m ^1715^ http://mhrd.gov.in 3it7 www, tripurauniv.in

H>Rf ^f 3TT^H 5^ ft5114^1 ^ 1H7R 1t

5T7T RFT 1^ 17 ifi^ Ilft^':

^tBTT ft"*iMl, 1R1 7RH1 ft* 17^
^RTT 7T0 325, 7ft fcfi, TTTT^it HI, 1^ f^^^ft- 110 115
> 17 '<^dHft ^ h ^^ anftn - 1^51 ft^ftar^i" vJi^ftiR^^ 5tn
15 R'hmi, ^11^ ftcii ^^^ f

<!-- page 3 -->

Format of Application for the post of Vice chancellor
Affix the latest passport
size Photo

(Applicant is requested to type the information in the following format, and can add more lines in the
format wherever required.)
1. General Information of Applicant
Name
(In Capital Letters)
Date of Birth
(Day/Month/Year)
Correspondence
Address

Mobile No. :
Phone No.
Landline No. :
Email

2. Present Position
a.

Designation

b.

Organization

c.
d.

Pay Scale
Date of
appointment to
the present post
Total Experience
(In Years and
Months)

e.

3. Details of experience possessed as per eligibility criteria:
(10 years’ Professorship or equivalent as per UGC Regulations on Minimum Qualifications for
Appointment of Teachers and other Academic Staff in Universities and Colleges and Measures
for Maintenance of Standards in Higher Education 2010 and subsequent modifications)
S.No.

Post held

Pay Scale

Organisation

Nature of duties

Experience
(In Years and
Months)

<!-- page 4 -->

4. Educational Qualification (In chronological order from latest to Graduation level)
S.No.

Qualification

University

Year

Subject(s) /
Topic(s)

%
Achieved

Distinctions
etc.

5. Administrative Experience/Post(s) & responsibilities held
S.
No.

Post

1.
2.

Head of the Department
Chairman, Board of
Studies
Member, Board of
Studies
Dean of Faculty
Member of Academic
Council
Member of Executive
Council
Member of Professional/
Academic Bodies
Others (Specify)

3
4.
5.
6.
7.
8.

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years and
Months)

6. (a) Academic/Teaching Experience & responsibilities (In chronological order from latest to oldest)
S. No.

Post

Organization/
University

Duration
From
To
(Date)
(Date)

Experience
(In Years
and Months)

(b) Participation and contribution in relevant areas in higher education
Organisation

Area of specialisation

Visiting Professor
Resource Person
Others (Specify)
(c) Involvement with formulation of academic programmes:
S.No.

Nomenclature of Innovative Academic
Programmes formulated

Date of approval by
Academic Council

Year of
Introduction

<!-- page 5 -->

(d) Important MoUs formulated for academic collaborations:
S.
No.

MoUs formulated

Name of Agencies/Departments
involved

Year of MoU

Name of Agencies/Departments
involved

Period of holding
the Chair

(e) Position of Chairs:
S. No. Name of Chair

7. International academic Exposure, if any
S. No.

Post/
Assignment

Organization/
University

Area of Assignment
From

Duration
To
In Years &
Months

8. Scholarly achievements:

A. Contribution to Journals and Books:
Details
Books authored
Editor in Chief
Editorships
Peer reviewer for
Member of the International Advisory
Board
Others (Specify)
B. Publication:
B.I Kindly provide list of scholarly publications in recognised professional and/or academic journals:

Total Publications: ………….
S.No.

Date

Title

Name of journal

Refereed
journal or
not

Number of
Citations
(where possible)

<!-- page 6 -->

B.II List of articles in popular magazines or newspapers

Total Articles: ………..
S.No.

Date

Title

Name of Magazine/
Newspaper

C. Participation and scholarly presentations in conferences:
C.I National
S.No.

Date

Title of Conference or Institution

Title/Subject of presentation (if made)

Title of Conference or Institution

Title/Subject of presentation (if made)

C.II International
S.No.

Date

D. Participation and contribution in National/International Fora in the area of your academic and
professional expertise
Number(s)
Plenary Lectures/Invited Talks
Congresses attended
Examinership etc.
Others (Specify)

International
National
International
National
International
National
International
National

9. Research Projects:
S.No. Client/Organisation’s
name

Nature of project

Duration of
project

10. Consulting experience:

List key consulting assignments undertaken:
S.No. Client/ Organisation’s
name

Nature of assignment

Duration of
assignment

Amount
of grant
(Rupees)

<!-- page 7 -->

11.

Honours /Awards & Fellowships for Outstanding Work:

Sr.
No.

12.

Name of
Award/Fellowship
etc.

Awarded by

Year of Award

No. of Research Scholars successfully guided :

Name of Programme

13.

Elected/Honorary
Fellow

Awarded (No.) (Under-progress not to be included)

Strengths (in 100 words)

14. Your Vision for the University (upto 500 Words)

15. Details of Referees, if any
S. No.

Name of the
Referee

Post Held by
Referee

Email

Phone No.

Mobile

I, hereby, declare that all the statements/ particulars made/furnished in this application are true, complete and
correct to the best of my knowledge and belief. I also declare and fully understand that in the event of any
information furnished being found false or incorrect at any stage, my application/candidature is liable to be
summarily rejected at any stage and if I am already appointed, my services are liable to be terminated
without any notice from the post of Vice-Chancellor as per Act/ Statutes etc. and other applicable rules.

Place:
Date:

(Signature of the Applicant)

Note: Total No. of pages (A-4 size) of the application should not exceed 10 pages.
