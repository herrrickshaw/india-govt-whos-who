---
doc_id: "ba1ec1de0bd8894e"
source_url: "https://dsel-education.gov.in/static/uploads/2025/09/28511367a06bd3afdbcbc53b06f5be56.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "Third party Audit Exercise for the year 2024-25 in pursuance of DoPT's OM No.I/6/2011-IR dated 7th November, 2019"
date: "2025-07-23"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e9ff9a97c5974b7f"
---

<!-- page 1 -->

F.No.33-l/2019-IFI)
Ministry of Education
Department of Higher Education
(Integrated Finance Division)

***

Dated 23.7 .2025

Subject:

Third party Audit Exercise for the year 2024-25 in pursuance of DoPT's
OM No.V6l201 l-lR dated 7th November, 2019 - reg.

Please refer to your letter No. I-l l0l4/'12021-RTl dated 22.7.2025, on the subject

cited above.

2.

ln this regard, reference of Sl.No.2.l.1, the Scheme-wise Budget Estimates, Revised
Estimates and Actual Expenditure in respect of Department of Higher Education from 202425 and 2025-26 (Exp. as on 21.7 .2025) are enclosed.

r* LJ

(ud aya

K.v.)

Under Secretary (lFD)
To,
Sh. Nishant Upadhyaya

Under Secretary (RTI)

RTI Section, Gate No.6 (GF)
Department of Higher Education
Ministry of Education

cPro (lro)

<!-- page 2 -->

Deporlmenl ot Hlgher Educotlon
slolcmenl indlcotlng BE, fG ond Acluols lor tY 2024-25 & 2025-26
Rs. ln Crore

2025-26

2024-25
s.N

Nome ol lhe Scheme/Aulonomous Body

BE 2024.25

Acluols os
on

tG 2024-25

Be 2025-26

21 .07.2025

31 .03.2025

Lr
2

3

llshinenf'Il
llure ol lhe centre
Secretoriol- Sociol Services
Direclorote of Hindi
Commission for Scientific ond Technicol
Terminology

@onguoges.
a
I lo.d Reg,onol ronguoge cenlers
5

162.50

1654

Mysore

2

3
4

17.11

46.07

43.9 4

Educolionol lnstituiions Abrood'
l- Esloblishmenl Expendilure of lhe cenhe I

7

8
9

t0

tl
12

t3
)4

t5

133.28
19.35

I

43.8l

172.28

zs.zsl s.6z

[ ,;il ,;,T
37.10

' ' 2i2.17

34e

48.60

9 .98

z.oa

275.071 64.97

,5r I

24?"761'

4.27
2.00
r 0.00

0.27
r000.00
2.00
8.35

0.27
r 000.00
2.00
8.35

.00

r .00

0.00

'l8 t 3.27

'l0I I .62

r558.00
350.00
1908.00

r 205.00

480.00

1575.00

) 563.22

0.00

2.86

9.00
1594.00

9.00
1575.08

I 6.00

0.r3

68I.00

I t6.84

7 .78

4.9 5

I 0.00

0.r1

4.00

5.00

4.50

r .00

4.00
r .00

0.85

I .00

0.05

0.00

2.50

00.00

25.00

25.00

s0.00

0.00

30.00

0.00

40.00

0.00

200.00

2.O0

0.00

220.04

0.00

355.00

42.28

37.30

327.O0

4.66

r00.00

35.39

22.97

70.00

18.16

r0.00

0.00
758.00

5.00

I I 78.00

13.00

0.00
758.00
r 3.00

2.21

2.21

2.52

3.63
290.00
3.50
0.00

r04.00

88.98

77.44

CoES tn Ariif iciol ntelligence (Al)

255.00

| .00

l] .00

Totol- Cenhol Seclor Schemes / Proiecls

5672.i3

47 61 .48

Cenkol Seclor Schemes/ Projecls
Hlqhet Educdtlon
Nolionol Reseorch Professors
Wodd Closs lnsiiluiions
Prime Minisleis Girls' Hostel

r800.00

lndion Knowledoe Syslem
Glue Gronl for Higher Educotion lnstiiu'fions
f olol - H I ah et Ed u c dllo n

6

,1-3?

15.05

I

I

r56.93

Acluols os
on

Sludent Flndnclol Ald
Prodhon Montri Uchchotor Shiksho Protsohon
(PM-USP)

PM Reseorch Fellowship

folol-Sludent fhoncidl Aid
Dlqltol lndlo- e-Leomlnq
Nolionol Mission in Educotion throuoh ICT
Higher Educolion Stotistics And Public
lnformotion System (HESPIS)
Acodemic Eonk of Credits
Totol- DlEltol lndio- e - Leorninq
Reseorch & lnnoYotion
Notionol lnitio'live for Design lnnovotion
Ll nnoi Bhorot Abhiyon
Swochoto Action Plon (SAP)
lmplementotion of lhe IMPRINT Reseorch
lnitlotive (lMPocting Reseorch lNnovotion &
Technology)
Scheme for Promoiion ot Acodemic ond

Reseorch Colloborotion(5PARC)
Scheme for Tronsformo'lionol ond Advonced
t6
Reseorch in Sciences (STARS)
Mullidisciplinory Educolion ond Reseorch
17 lmprovement in Technicol Educotion-EAP

1

r

5.00

r

0.00

505.00
r

r

r

0.00
4.00

0.06

a.24
47 5.12

0.00

2.Aa

2.00

50.00

0.00

.00

0.00

'1010.62

528.36

2.06

r000.00

998.95

r560.00

369 .47

205.00

204.69
'1203.64

500.00

149 .86

2160.00

519.33

655.00

r I 6.07

0.00

0.64

r

1

r

0^ ER rTE)

folol-Reseorch & lnnov olion

t8

Moloviyo Mission Teochers Troining Progromme
(MMITP)

r9 Globol lniliotive for Acodemic Network
Notionol A pprenticeship Troining Scheme
2) Sludy in lndio
22 ASEAN Fellowship
Chqmpion Services Seclor Scheme-Educotion
23 Services-lnlernotionolizotion of Higher
2A

600.00
20.00
2.66

r

14.00

Educolion
24

Estoblishment of 3 Centres of Excellence

4711.22

200.00
5175.88

50.00
't

008.'17

<!-- page 3 -->

s.N
o.

Nome o, lhe Scheme/Aulonomous Body

BE 2024-25

tG 2024-25

Acluols os
on

Acluols os
sE 2025-26

on
21.O7.2025

31.03.2025

I

Tronslers lo Sloles/UTs

tl

sehini.a
25

Prodhon Montri Uchchotor Shisho Abhiyon

=

E

I8r4.94

E

532.40

I

357.83

r8r5.00

79.27

I

III

8odi6i

I
I

t,
r

Supporl to University Gronts Commission (UGC)
All lndio Council for Technicol Educotion
{ArcTE)

Iotdl-Slolulory ond Reourororv Sodles

|

,roo oo

3691 .25

367 8.47

3335.97

833.99

|

,oo oo

"r{

"r-

200.00

50.00

3535.97

883.tt

2900.00

3828.7 5

Ill

3815.97

<!-- page 4 -->

s.N
o

Acluols os
Nome of the Scheme/Aulonomous Body

3(o) Gronts lo Centrol Universitles (CUs)
3ib) Gronls 10 IMS BHU
Tolol- Cenlrol Universilies
Deemed Universilies Promoled by Cenkol
4

5

Government
lndion lnstllules of fechnoloqy
Supporl lo lndion lnstituies of Technolooy
llT, Hyderobod(EAP)

BE 2024-25

FG 2024-25

Acluqls os
on

on
3r.03.2025

BE 2025-26

4268.53
r50.91

21.O7.2025
4I 88.34

5558.00
370.00
15928.00

15684.00
37 4.89

15667.64

r 6058.89

16042.45

16324.17
367 .14
1669 t .3',t

596.00

5 r 5.89

5 r 4.36

604.00
0.00

0.00

0202.50

10321 .34

I 0187.46

1 1349.00

4193.27

030t.30

I 1349.00

4193.27

219 .40

25r.89

86.21

r

r

37 4.81

80. r8

122.00

122.04

r 0324.s0

212.21

10443.34
235.42

5040.00

5425.48

5393.2 r

5687.47

1367 .57

I 540.00

1493.70

1 459 .29

r353.33

333. r 7

87 5.77

822.85

817.07

856.50

215.42

42.50

42.54

42.50

43.50

10.88

Technology (Allohobod, Gwolior, Jobolpur &
Konchipurom)
Set'ting up lndion lnstitutes of lnformolion
l2
Technology in PPP mode
Gronts lo Councils/lnstitutes for Excellence in
t3

3 I 5.91

363.46

362.46

407.00

200.00

58.r0

5r.06

I I 5.20

0.00

3r5.00

321 .70

309 .24

332.80

81.61

14

3r0.r0

290.84

289 .40

347 .03

74.45

37.45

38.85

38.85

0.00

0.00

185.87

144.00

143.77

r 69.00

39. t8

I 10.00

188.45

186.45

r 59.00

39.51

38.7 6

44.15

43.00

6.41

140.00

t3r.t4

147 .00

40.66

r00.00

0.00

25.00

0.00

of lechnoloov
Support to lndion lnstilules of Monogement
Supporf to Nolionol lnslitutes of Technology
I olol-lndlon,nsrirures

6
7
B

9

t0

ll

t6

(N lTs) ond IIEST

Supporl to lndion lnstilules of Science for
Educotion & Reseorch (llSERs)
Suppori to lndion lnstitute of Science {llsc)
Centrol for Nono-Science ond Engineering
{ceNsE)
Support lo lndion lnstitutes of lnformolion

Humonities ond Sociol Sciences
Gronls to lnstilules for Promotion of lndion

Longuoges
Notionol lnslilule of lnduslriol Engineerjng,

Mumboi

l7 Schools of Plonnino & Archilecture
Nolionol lnslilules of lechnicol Teochers
t8
Troining & Reseorch

19

Boord of Apprenticeship Troining, Bomboy,
Colculto , Modros ond Konpur
ndiro Gondhi Notionol Open University
(rGNOUl

12t .84
't

131.r4

r

00.00

21

Nolionol Digitol Universiiy

22

Assrsldnce lo Olhet lnslilutions

{i)

Associotion of lndion Universities

2.O0

2.Oa

2.00

69.30

69.1 3

69.12

2.ao
70.70

0.50

Nollonol Book lrust
Gronts for Book Promotion Activilies ond
Volunlory Agencies
Notionql University of Educotionol Plonning
ond Adminisirolion (NUEPA)/Notionol lnstitule
of Educotion Plonning ond Administrotion

0.03

0.03

0.02

0.03

o.a2

73.00

63.97

50.15

7

4.00

.03

59.00

r .00

r r.00

60.00

3.00

7 .40

8.00

7.78

7 .00

355.00

392.07

389.4l

4ao.27

)01.27

565.33
39777.40

546.20

529.48
406?6.42

6 r 4.00

40r93.71

42732.O0

r 32.80
12024.56

{ii)
(iri)

(iu )

(NTEPA)

Auroville Monogement
Notionol Commission for Minority Educotionol
(vi)
lnslitutions
Assistonce to Other lnsliluf es including SLIEI,
(vii)
NERIST, NIFFT & CIT Kokrojhor
(v)

Assislonce to Othet lnslilulions-folol
Total- Autonomous Bodies
Olher C e,nhol.Ex peadilure {OCE):QIher lhan
I

2

(ii)

Noiionol lnstiiulionol Ronking Fromework
Planning, Administration & Global
Engagement
nitiotives for Globol Engogemen 1
Expenditure on Seminors, Commillees
Meetings elc. lIAIDA to Non-Officiol Members

I

I

75

I

s.00

2.50

2.50

5.00

0.00

5r.00

29.84

29.41

36.7 5

o.24

U,OU

0.60

0.00

0.50

0.00

<!-- page 5 -->

s.N

o
(iii)

Nome ol lhe Scheme/Aulonomous Body

sE 2024.25

Shostri lndo- Conodion lnstitute

Conkibution to UNESCO

Depulolion ond Delegolion to UNESCO
(vi)
Conferences etc.
(vii) Visil of Foreiqn Delegolion to lndio
Holding of meelings of Commitlees/
Conference ond orgonisolions of exhibition in
(viii)
furtheronce of UNESCO's oims ond objectives
{ix)

Asion lnsiitule of Technoloqy, Bonqkok
Commonweollh of Leorninq
Olher Cenhol Expendilure (OCE)-Olher thdn

I

lTotol'gtn.r

I

Grond Tolol ""nlrol

(x)

Acluols os
on

BE 2025-26

31.03.2025

Refund of lncome lox ond Customs Duty to
(ivl United Stotes Educotion Foundotion in lndio
(v)

tG 2024-25

Seclor

I

r .00

0.00

l 64

t.43

30.00

30.00

0.80

Aclugls os
on
21.O7.2025

50

0.00

30.00

30.00

30.00

0.50

0.04

0.80

0.00

0.r5

0.1 5

0.00

0.r5

0.00

0.30

0.30

0.00

0.30

0.00

0.50
r 2.00

0.50
r2.00

o.24
12.00

5.00

102.jj

77.78

7

5.62

80.00

I

43

I

T-

0.00
30.24

3188039 'i., ,,41071.49 ,. ;,40774.04 :' .42812.00 . ,12054
47619.77

46615.13

46055.46

50077.95

13207.21
