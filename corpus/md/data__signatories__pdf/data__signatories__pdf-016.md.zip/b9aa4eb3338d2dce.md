---
doc_id: "b9aa4eb3338d2dce"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/09/a9209c382b5042f3a6fb2cbfba4c0f53.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Hunjan Hospital Ludhiana Punjab"
date: "2024-11-18"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f89a2c01c5a556e3"
---

<!-- page 1 -->

No. S. 1402114112024-EHS
Government of India
Ministry of Health & Family Welfare
Nirman Bhawan, New Delhi
Dated the l8'h November,2024

OFFICE MEMORANDUM
Subject: Empanelment of 'oHunjan Hospital, Ludhiana Punjab" under CS (MA) Rules, 1944.

The undersigned is directed to say that the proposal received for empanelment of "Hunjan Hospital, Ludhiana Punjab"
for treatment of Central Govemment Employees and their family members under Central Services (Medical Attendance)
Rules, 1944 has been examined in this Ministry and it has been decided to empanel the Hospital under CS (MA) Rules,
1944.

The Schedule of charges for the treatment of Central Government Employees and the members of their family
under the CS (MA) Rules, 1944, will be the rates fixed for CGHS (Non-NABH), or hospital's own rates, whichever is less.
The approved rates are available on the website of CCHS and may be downloaded/ printed.

2.

3.

The undersigned is further directed to clarify as under: -

(a)

,,package Rate" shall mean and include lump sum cost of in-patient treatmentllday care/diagnostic procedure for

*hi.h u CS(MA| beneficiary has been permitted by the competent authority or for treatment under emergency from the

time of admission to the time of discharge, including (but not limited to)-(i) Registration charges, (ii) Admission charges,
(iii) Accommodation charges including patient's diet, (iv) Operation charges, (v) Injection charges, (vi) Dressing charges,
(uli; oo"tor/consultant viiit charges,lviii) ICU/ICCU charges, (ix) Monitoring charges, (x) Transfusion charges, (xi)
surgical
Anesthesia charges, (xii) Operation theatre charges, (xiii) Procedural charges / Surgeon's fee, (xiv) Cost of
essential
(xvi)
routine
and
Related
medicines,
(xv)
of
Cost
disposables andltt sund.ies used during hospitalization,
investigations, (xvii) Physiotherapy charges etc, (xviii) Nursing care and charges for its services.

(b)

Cost of Implants is reimbursable in addition to package rates as per CGHS ceiling rates for implants.

(c)

.,Hunjan Hospital, Ludhiana Punjab" shall not charge more than the package rates fixed for CGHS (Non-NABH)

rates.

(d) Expenses on toiletries, cosmetics, telephone bills etc. are not reimbursable and are not included in package rates.
4.

Package rates envisage duration of indoor treatment as follows:

Up to 12 days: for Specialized (Super Specialties) treatment
Up to 7 days: for other Major Surgeries
Up to 3 days: for Laparoscopic surgeries/normal Deliveries
for day care/Minor (OPD) surgeries'
I day:

No additional charge on account of extended period of stay shall be allowed if that extension is due to
consequences ofsuigical procedure or due to any improper procedure and is notjustified'

infection on the

Continued...2/

<!-- page 2 -->

_)_

are no AIIMS

ln case, there are no CGHS prescribed rates for any test/procedure, then AIIMS rates are applicable. If there
(e.g. room rent, investigations,
rates, then reimbursement ii to be arrived at by calculating admissible amount item-wise
investigations'
cost of medicines, procedure charges etc.) as per approved rates/actually, in case of

5. (a) CS (MA) beneficiaries are entitled to facilities of private, semi-private or general ward depending

on their basic pay.

The entitlement is as follows: S.No.

3"""rp"rd,"g Basic Pay drawn by the officer in 7'n CPC Ward Entitlement
oer month

1.

Jpto Rs. 36,5001R.s. 36,501/- to 50,500/-

General Ward

Rs. 50,501/- and above

Private Ward

lemi-Private Ward

(b) The package rates given in rate list of cGHS are for semi-private ward.
is entitled for general ward there will
(c) The package rates prescribed are for semi-private ward. If the beneficiary
there will be an increase of l'oh. However, the rates shall
be a decrease of 10% in the rates; for private ward eniitlement
the patient is admitted or not and the test, per-se, does not
be same for investigation irrespective of entitlement, whether
require admission.

The hospital shall charge from the beneficiary as per the CGHS Q''lon-NABH),
list whichever is lower.

6.

7.

(a) The maximum room rent admissible for different categories would
General ward
Semi-Private ward
Private ward
Day care (6 to 8 Hrs.)

prescribed rates or its own rate

be:

Rs. 1500/- PerdaY
Rs. 3000/- Per daY
Rs. 4500/- Per daY
Rs. 500/- (same for all categories)

(b) Room rent mentioned above at (a) above is applicable only for

treatment procedures for which there is no

CGHS prescribed Package rate.
Room rent will include charges for occupation of bed, diet
charges. nursing charges and routine up keeping'

forthe patient, charges for water and electricity supply, linen

(c) During the treatment in ICCU/ICU, no separate room rent will be

admissible'

patient is accommodated and which has an attached
(d) private ward is defined as a hospital room.where.single
dressing table, bed-side table, sofa set' etc' as
(lavatory and bath). The room should liare furnishings likeivardrobe,

toilet
well as a bed ior attendant. The room has to be air-conditioned.

(e) Semi private ward is defined as a hospital room where two to

three patients are accommodated and which has

attached toilet facilities and necessary fumishings'

(0 General ward is defined as hall that accommodates four to ten patients'
Continue...3

<!-- page 3 -->

-3-

(g) Normally the treatment in higher category of accommodation than the entitled category is not permissible.
However,ln case of in emergency when the entitled category accommodation is not available, admission in the immediate
higher category may be allowed till the entitled category accommodation becomes available. However, if a particular
per entitlement of the
ho"spital does not have the ward as per entitlement of beneficiary, then the hospital can only bill as
ward.
of
type
given
in
higher
was
beneficiary even though the treatment

If, on the request of the beneficiary, treatment is provided in a higher category of ward, then the expenditure over
and above entitlement will have to be borne by the beneficiary'

g.

[n case of non-emergencies, the beneficiary shall have the option of availing specific treatment/investigation
treatment
from any of the empanelled hospitals of his/her choice (provided the hospital is recognized for that
and on
Attendant
Medical
Authorized
procedure/test), after ihe specific treatment/investigation has been advised by
production of valid ID card and permission letter from his/her concerned Ministry/Department'

g.

provide treatment/investigation
The hospital shall honour permission letter issued by competent authority and
facilities as specified in the permission letter.
and their eligible
The hospital shall also provide trearment/investigation facilities to the CGHS beneficiaries
hospital shall
The
lower.
is
whichever
(MA)
Rules,
cs
under
dependent family members at its own rates or rates approveJ
Cards'
CGHS
valid
of
verification
through
to pensioner cGHS beneficiaries after authentication

10.

provide treatment

treatment at approved rates as
However, pensioner CGHS beneficiaries would make payment for the medical
Director, CGHS through the cMo i/c of the
mentioned above and submit the medical reimbursement claim to the Addl.
cGHS Wellness centre, where the cGHS Card of the beneficiary is registered.

ll.

lz.

ln case of emergencies, the beneficiary shall have the option of availing specific treatment/investigation

any of the empanelled

from

procedure/test), on
hos[itals oihir/h.. choice (provided the trospitat is recognized for that treatment

production of valid [D card, issued by competent authority'

not ask the beneficiary or his
or accessories from outside and will provide the
attendant to purchase sJparatety the medicines/sundiies/equipment
cost of all the items'
the
witirin the package rate, fixed by the CGHS which includes

13.

During the in-patient treatment of the cs (MA) beneficiary, the Hospital ^will

treatment

reimbursement shall be

14.

In case of treatment taken in emergency in any non-recognized private hospitals,

15.

If one or more minor procedures form part of a major treatment procedure, then package

considered by competent authority at CGHS prescribed Package/rates

permissible for major procedure ind only 50% of charges for minor

only'

charges would be

procedure.

etc' of the central civil
The Hospital shall agree for conducting all investigation/diagnostic tests/consultations
.,A,, Officers of age of 40 years and above and other categories of CGHS/CS (MA) beneficiaries as
Services Group
protocol as per Annexure, subject to the condition that the
specified by government from time to time as per prescribed
presoribed medical examination of the male officers and
hospital shall not charge more than Rs. 20001 for conducting the
to the hospital/institution with the requisite permission letter
Rs. 2200 for female officers of central Government who come
for medical examination are valid until such time
from their Ministry/Department/competent authority. The above rates

16.

when the above rates are revised by the Central Government'

Continue...4/

<!-- page 4 -->

-+

17.

Any legal liability arising out of such services shall be the sole responsibility and shall be dealt with by the

concerned empanelled hospital. Services will be provided by the Hospital as per the terms given above.

18.

Ministry of Health & Family Welfare reserves the right to withdraw/cancel the above recognition without

assigning any reason.

The order takes effect from the date of issue of the O.M. The hospital stands recognized under CS (MA) Rules,
1944 for a period of 4 (four) years from the date of issue of this O.M.

19.

,.Hunjan Hospital, Ludhiana Punjab" will have to enter into an agreement (copy enclosed) withthe Govemment
of India to the effect that the Hospital will charge from the Central Covernment employees at the rates fixed by the
Government and they will have to sign a Memorandum of Understanding (MoU) within a period of 3 months from the date
of issue of the above mentioned Olffailing which the Hospital will be derecognized (Two original copies of MoU printed
the
on the stamp paper and duly signed by the Hospital to be sent to this Ministry for necessary action). Subject to above,

ZO.

Hospital can sta-rt treating Central Govemment employees covered under CS (MA) Rules, 1944.

Zl.

A communication in acceptance of the Para 20 above may be sent to the undersigned within a week from the

receipt of this Office Memorandum.

\,r'yq
Under Secretary to ttr$bov$lfin$

"*t"g-#[[''n
# 4{."$"'-*''
$['P**&t*
-G

To,

1. Hunjan Hospital, lll South Model Gram, Kochar Market Road, Ludhiana, Punjab-141002
2. All Ministries/Departments of Govt. of India as per distribution list.
3. Directorate General of Health Services (MG-ll Section)
4. Estt.l/Estt.ll/Estt.lll/Estt.lV Sections, Ministry of Health & Family Welfare'
5. Admn.l/Admn.ll Sections of Directorate General Health Services
6. Office of the Comptroller and Auditor General of India, Bahadur ShahZafar Marg, New Delhi.
7. Finance Division of Ministry of Health & Family Welfare, Nirman Bhawan, New Delhi
8. All staff side members of National Council (JCM).
9. NIC, Nirman Bhawan, with the request that the O.M. be uploaded in the website of the Ministry.
10. Hindi Section for Hindi version.
1 1. Guard file of EHS Section.

<!-- page 5 -->

MOU
No. S. 1402114112024-EHS

Memorandum of Understanding between The Central Government and "Hunjan Hospital, Ludhiana Punjab" for
recognition under CS (MA) Rules, 1944.
Whereas, this Memorandum of Understanding is made

on.....

(Date) between the president of India

who shall be the 1't party and "Hunjan Hospital, Ludhiana Punjab" who shall be 2"d party under which the
Hospital/lnstitution shall undertake for the treatment of Central GoW. employees.
Whereas, the o'Hunjan Hospital, Ludhiana Punjab" had applied for recognition under CS (MA) Rules, 1944 for

treatment of Central Government Employees;

And whereas the Central Government in the Ministry of Health and Family Welfare vide its O.M. No
...(Recognition Date) had recognized "Hunjan Hospital' Ludhiana
5.1402114112024-EHS dated...18.l I .2024.
Punjab,, under CS(MA) Rules, 1944 for treatment of Central Government Employees and Members of their families
subject to the condition that the schedule of charges for treatment of Central Government Employees and members of their
family under CS(MA) Rules, 1944 shall be regulated as per the schedule of approved charges of CGHS rates and also
subject to the condition that the "Hunjan Hospital, Ludhiana Punjab" would enter into an agreement with the
Government of lndia within a period of 3 months fiom date of issue of O.M., to the effect that the hospital will charge
Central Government employees at the rate fixed by the Government" failing which the hospital would be derecognized.

The hospitat shall charge CCHS (NonNABH) rates or its own rates, whichever is less. lf the hospital gets NABH
accreditation, then it will charge CGHS- NABH rates or its own rates, whichever is less, till the expiry of its accreditation.

Now, therefore, the Central Government and the "Hunjan Hospital, Ludhiana Punjab" hereby enter into an
agreement to be mutually adhered to by both the parties whose terms, conditions and applications are as below:-

l.

o.Hunjan Hospital, Ludhiana Punjab" is recognized under CS (MA) Rules, 1944 for treatment of Central

Govemment Employees and Members of their family subject to the conditions that:i. ,.Hunjan Hospital, Ludhiana Punjab" will charge all the Central Government Employees as per the schedule of
approved charges of CGHS, which are available on the website of CGHS.
ii. ..Hunjan Hospital, Ludhiana Punjab" shall, in no circumstance, charge an amount more than that agreed to as
para 1(i) above from any Central Government employee for a period of 4 years from the date of issue of the O.M.
or until such time that the rates are revised by the Central Government;

iii.

,,Hunjan Hospital, Ludhiana Punjab" shall not discriminate in any way against the Central Govemment

iv.

Employees receiving treatment in the hospital as compared to any other patient;
The hospital shall provide access to the financial and medical records for review by medical and financial auditors

v.

of the Central Government, as and when necessary;
The Hospital will pay damages to the beneficiaries, if any injury, loss of part or death occurs due to gross
negligence, or due to transfusion of improperly checked blood, if such injuries occur in consequence of treatment

vi.

Any legal liability coming out of such services shall be dealt with by the hospital/diagnostic Centre and it shall

in the hospital/diagnostic centre.
alone be responsible.

vii.

In case of any complaint of overcharging/ deficiency in services the Central Government may, after due enquiry,
reserve the right to derecognize "Hunjan Hospital, Ludhiana Punjab" without any notice, and without any
prejudice to any other action to be taken as per law.

<!-- page 6 -->

-2-

2.

Further, "Hunjan Hospital, Ludhiana Punjab" shall undertake investigatiorVdiagnostic tests/consultations etc.
of the Central Civil Services Group "A" Officers of age of 40 years and above and other categories of CGHS/CS (MA)

beneficiaries as specified by government from time to time as per prescribed protocol as per Annexure, subject to the
condition that:

"Hunjan Hospital, Ludhiana Punjab" shall not charge more than Rs. 2000/- for conducting the prescribed
medical examination of the male officers and Rs. 2200 for female officers of Central Govemment who come to
the hospital/institution with the requisite permission letter from their Ministry/Department/Competent authority.
The above rates shall be valid until such time when the rates are revised by the Central Govemment;

"Hunjan Hospital, Ludhiana Punjab" shall not discriminate in any way against the Central Govemment
otficers/employees for conducting the investigations/diagnostic tests/consultations/examinations etc in the hospital
as compared to any other patient:
Any legal liability arising out of such services shall be dealt with by the hospital/institution and it shall alone be

v.

responsible.

The Central Government reserves the right to derecognize "Hunjan Hospital, Ludhiana Punjab" after due
enquiry, in the case of any complaint of overcharging/deficiency in service, without any notice, and without
prejudice to any other action to be taken as per law.

3.

None of the parties could change any provision contained in this MoU without the written consent of the other
party. The laws of the Government of lndia shall govern the construction and interpretation of this MoU.

4.

If any provision of this MoU or any provision of any document incorporated by reference shall be hold invalid,
such invalidity shall not affect other provisions of this MoU. This MoU can be given effect without the invalid provision
and to this end, its other provisions are declared severable.

5.

This MoU contains the entire Agreement between the two parties and no statement, promise or inducement made
by either party, its authorized parties or expert groirps that are not contained in this MoU shall be valid and binding. This
MoU can be modified or altered only on written agreement signed by both the parties.

6.

The original copy of this Memorandum of Understanding (MoU) shall be kept at the office of First Party and a

true copy shall be retained in the office of Second Party.

Signed on

For the Hospital

day of ----------------- 2024

For Central Govemment.
