---
doc_id: "b8e02a2c1ce7a4ff"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_6abe4916528b89.71671556.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order - Re-allocation of work among Inspectors General of Forests (IGFs) in the Ministry of Environment, Forest and Climate Change, New Delhi, order dated 01-10-2026"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "76e4fffd2c03b150"
---

<!-- page 1 -->

No: 12016/05/2021-IFS.|-Part(1)(E-285832)
Government of India
Ministry of Environment, Forest and Climate Change
60 Floor, Prithvi Wing,
Indira Paryavaran Bhavan,
Jor Bagh Road, New Delhi- 110003.
Dated, the 018! October, 2026.
OFFICE ORDER
Subject: Re-allocation of work among Inspectors General of Forests (IGFs) in the
Ministry — regarding.

With the approval of the Competent Authority, the following re-allocation of work is
ordered among Shri Priya Ranjan, IFS (RJ:1998) and Shri Sanjayan Kumar, IFS (KR:2002),
Inspectors General of Forests, posted in the Ministry:

Name of the Officer Existing work [Work allocation after this order
allocation
1. Shri Priya Ranjan, IFS IFS, NAEB IFS, NAEB and RT Division
RJ:1998 (additional work)
2. | Shri Sanjayan Kumar, IFS | NTCA, CITES, RT NTCA, CITES
(KR:2002) Division
2 The work of RT Division, presently allocated to Shri Sanjayan Kumar, IFS (KR:2002),
shall be looked after by Shri Priya Ranjan, IFS (RJ:1998), as additional work, in addition to
his existing responsibilities. Shri Sanjayan Kumar, IFS (KR:2002), will continue to look after
the work of NTCA and CITES.
3. This order takes effect immediately.
Yours faithfully,
yi
1००
(Phalguni Banerjee)
Under Secretary to the Govt. of India
Tele: 20819192
To
1. Shri Priya Ranjan, IFS (RJ:1998), IGF, MoEF&CC.
2. Shri Sanjayan Kumar, IFS (KR:2002), IGF, MoEF&CC.
Copy to:
1. PS to Hon’ble Minister (EF&CC) / MoS (EF&CC).
2. PS to Secretary (EF&CC) / PPS to DGF&SS.
3; All ADGFs / IGFs / Joint Secretaries in the Ministry.
4. Heads of Divisions concerned — RT Division, NTCA, CITES, IFS Division, NAEB.
5. NIC, for uploading on the Ministry's website / intranet.
6. Guard file / Office copy.
