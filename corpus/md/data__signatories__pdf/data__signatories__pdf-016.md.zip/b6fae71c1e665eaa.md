---
doc_id: "b6fae71c1e665eaa"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/ab3befecd630b4905be279065b1e7f67.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Acceptance of resignation of Shri Ram Lal Gupta, Sr. PC for CAT, Chandigarh Bench: Order dated 26.09.2019"
date: "2019-09-26"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4cff5d7e3345b13b"
---

<!-- page 1 -->

F. No. J-16/1/2019-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
ated 26“ september, 2019
ORDER
The President is pleased to accept the resignation of Shri Ram Lal Gupta, Advocate
who figure as Senior Panel Counsel, as mentioned under cdlumn-ll in table ‘A’ below, with
effect from the date as mentioned under column-lV, consequently, his name occurring in
this Department's Order as mentioned under column-lll in table ‘A’, stands deleted:
Table ‘A’
Name of Name of Court & Detail of concerned Date of
Advocate Category of Panel order of empanelment | acceptance of
(S/Shri) _ resignation
| _(w.e.f.
po ४ _- || IV
Ram Lal Gupta | Senior Panel Counsel for | J-11017/25/2018-Judicial | 25.02.2019
Central Administrative | dated 22.11.2018
| Tribunal, Chandigarh
| Bench
2. Hindi version of this order will follow.
Swe
————
(S. R. Mishra)
Additional Secretary
Copy for information to:
1. PS to MLJ/ PS to Law Secretary/PS to Legislative Secretary/PS to all Addl.
Secretary/Joint Secretary of Department of Legal Afffairs.
2. Shri Chetan Mittal, Asst. SGI, Punjab & Haryana High Court at Chandigarh.
3. Shri Sanjay Goyal, Sr. CGSC for CAT, Chandigarh |Bench, R/o # 11, Sector-10 A.
Chandigarh.
4. Shri Ram Lal Gupta, Advocate, R/o #1290, Sector-44 B, Chandigarh.
5. To be uploaded on website of this Department i.e. www._legalaffairs gov.in under tab
‘Judicial Section’ in the lirk ‘List of empanelled Counsel’.
6. Hindi Section, Departmert of Legal Affairs, for translation of this order.
7. Guard File with 5 spare copies
2> A
a लमममकम करन... ;7527:9% महू का
(D. Srinivas)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
