---
doc_id: "b793cc78f5bcbf1b"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/6d14765f6285b7d8c147e3b67ade618b.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Result of the Interview for appointment as Notary for the State of Karnataka"
date: "2016-08-24"
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "edac8dda33797605"
---

<!-- page 1 -->

F.No. N-11013/1/2016-NC
Government of India
Ministry of Law and Justice
Department of Legal Affairs
Notary Cell
*****
Notary Cell, Department of Legal Affairs had conducted Interviews for
appointment as notaries for the State of Karnataka from 20.06.2016 to 28.06.2016 at
Bangalore. The candidates were assessed keeping in view their competency, legal
knowledge and other relevant factors related to the selection of Notary as per
requirement of the Notaries Act, 1952, the Notaries Rules, 1956 and the relevant
guidelines by the Interview Board constituted for the purpose by the Central
Government. On the basis of the performance of the candidates before the Interview
Board, the Interview Board has recommended names of the following candidates for
appointment as notaries for the State of Karnataka.
2.
All the successful candidates, whose names appear in the below mentioned table,
will be issued Appointment Letters by Speed Post within 60 days from the date of
declaration of result. The candidates who may not receive Appointment Letters through
post may enquire with Notary Cell on Tel. No. 011-23383221. The candidates are
strictly advised not to visit this Office personally. Candidates can also obtain
information regarding their result by accessing official website of this department OR
on Tel. No. 011-23383221.
3.
All the recommended candidates are required to submit No Objection Certificate
from Bar Council of Karnataka and a Bank Demand Draft of Rs.2,000/- in favour of
Pay & Accounts Officer, Department of Legal Affairs, New Delhi by Speed Post OR
Registered Post only within a period of 30 days’ of issues of this letter. Besides this, the
candidates are also required to submit any other document which has not been
submitted by the candidate at the time of Interview and asked him/her to submit
afterwards.

(Poonam Suri)
Deputy Legal Advisor & Competent Authority
Notary Cell
01.07.2016

<!-- page 2 -->

S.NO.

S.No.

Name

Area of Practice
Applied for

File No.

1

1

Mahadeva

Nagamangala

N11013/1341/2016NC

2

2

Ms. A.C.
Mamatha

Tumkur Distt.

N11013/1342/2016NC

3

Mallikarjuna
C.

Tumkur Distt.

N11013/1343/2016NC

4

4

Gopala Gowda
H.K.

Bangalore
Courts

N11013/1344/2016NC

5

8

Vishakanta
B.M.

Mysore Distt.

N11013/1348/2016NC

6

10

Ms. C.R.
Nirmala

Chamarajanaga
r Dist.

N11013/1350/2016NC

7

11

P. Pundarika

Madikeri Distt.

N11013/1351/2016NC

8

12

Ms.
Sandhyalaxmi

D.K. Distt.

N11013/1352/2016NC

9

14

Ms. Nandini

Karkala

N11013/1354/2016NC

3

Father Name

Address

B.D.Halli, Honakere (H)
Nagamangala
Javaregowda
Tq.Mandya Distt.
Karnataka-571432
Sridevi Nilaya Jagajyothi
A.M.Channamal
Basaveswara Road,
likarjunaswamy Shanthinagara Tumkur
Distt.Karnataka-572102
Chikkathimmanhatti,
Nyayadagunte Post,
Chithaiah G.
Pavagada Taluk, Tumkur
Distt.Karnataka-572102
Haniyuru Village Dodda
Tumakur Post,
Lt.H.N.Kempaia
Hesaraghatta Hobli
h
Bangalore Karnataka561203
#275, Mahadeshwara
Lt.B.K.Marigow
Extension,
da
Kumbarakoppal,
Mysore, Karnataka
#7-241 'C', Southern
Ext., Nr. Prashanthi
G.Madhusudha
Lodge Kollegal,
n
Chamaraja Nagar Dist.,
Karnataka-571440
Laxmi Nilaya, Kaveri
Layout, Mekeri Vill.,
Appayya
Madikeri Tal., Kodagu
Distt., Karnataka571201
Nr. Saraswathi Bhajana
Umashankar.A. Mandir Urlandy Puttur,
D.K. Distt., Karnataka
Neelakutira H.No. V133/1, Hendibettu,
Karunakar
Marne Vill., Yennehole
Shetty
Post, Karkala Tal., Udupi
Dist.-574101, Karnataka

Enrollment
no.
KAR/1481/1
998
Dt.14.08.98
KAR/1265/1
999
Dt.26.03.99
KAR/278/20
00
Dt.04.02.200
0
KAR/720/20
05
Dt.01.04.05
KAR/2456/2
001
Dt.07.09.01
KAR/4771A/1999
Dt.12.11.99
KAR/1333/1
998
Dt.04.09.98
KAR/1955/2
001
Dt.11.08.01
KAR/3688/1
999
Dt.06.08.99

<!-- page 3 -->

10

17

N. Nagappa

Bangalore

N11013/1357/2016NC

11

18

H.M. Umesh

Bangalore Distt.

N11013/1358/2016NC

12

21

T. Hanmanth
Rao

Bangalore
Urban & Rural

N11013/1361/2016NC

13

22

Ms. V.C.
Kavitha

Mysore

N11013/1362/2016NC

14

23

Khadme
Umesh
Sharnappa

Bidar, Kannada
Distt.

N11013/1363/2016NC

15

25

B. Suresh
Kumar

Madikeri Distt.

N11013/1365/2016NC

16

29

H.S. Dharma
Prasad

Bangalore City

N11013/1369/2016NC

17

31

Dharani P.

Bangalore Met.
Area

N11013/1371/2016NC

No.135, 4th Main Road,
6th Block, Banashankari, KAR/1225/2
Lt.Narayanappa
3rd Stage, 3rd Phase,
005 Dt.
Bangalore-560085,
01.07.2005
Karnataka
No.24, Sri Sai Ashirwad,
Jayaram Layout, Opp. KAR/545/19
Lt.H.M.Muruges
V.D. College,
88
haiah
Banneragatta, Bangalore, Dt.13.07.88
Karnataka-560083
No.219, 8th 'D' Main,
1st Block, H.R.B.R.
KAR/1319/2
Lt.T.R.Venkatas
Kalyan Nagar Post,
005
wamy
Kalyan Nagar,
Dt.08.07.05
Bangalore-560043,
Karnataka
No.1089,
Vishnuvardhana Road, KAR/2871/2
Gangarajendra
Chamarajapuram,
001
Guru Prakash
Mysore-570005,
Dt.12.10.01
Karnataka
H.No.1-3-190, Near
KAR/124/97
Shanrappa
Bartan Bazar, Main Road
Dt.06.06.199
khadme
Bidar, Kannada Distt.,
7
Karnataka
VPO Mullusoge,
KAR/2965/2
Kushalnagar Hobli,
001
P.B. Basappa
Somwarpet Tal, Kodagu Dt.12.10.200
Dist., Karnataka-571234
1
No.1440, 37-C Cross,
14th Main Road, 4th T KAR/4781/9
H.D. Subbe
Block, Jayanagar,
9 Dt.
Gowda
Bangalore-560041,
19.11.1999
Karnataka
No.38, 'Shafiulla Manzil',
15th Main, 2nd Cross, KAR/1034/2
Muneshwara Nagar, Old
002
Panchanna
Mangammanapalya
Dt.02.07.200
Main Road, Bangalore2
560068

<!-- page 4 -->

32

Siddaroodha
Dhanna

Gulbarga Distt.
Court

N11013/1372/2016NC

19

33

Chandreshekh
ara Gouda
Banappagouda
r

Koppal

N11013/1373/2016NC

20

35

Pujar Raju
Govindappa

Jamkhandi

N11013/1375/2016NC

21

36

Henry
Castelino

D.K. Distt.

N11013/1376/2016NC

22

38

Praveen
Kumar

D.K. Distt.

N11013/1378/2016NC

23

39

Ms. Vani K.

Udupi

N11013/1379/2016NC

24

44

Raghavendra
B.

Kundapura Tal.

N11013/1384/2016NC

25

49

Ms. Jayasheela
C.G.

Mysore Distt.

N11013/1389/2016NC

18

26

50

Ramesh H.

Mysore Distt.

N11013/1390/2016NC

27

52

K.B. Nagesha

Mysore Distt.

N11013/1392/2016NC

Plot No.31, N.G.O.
KAR/320/01
Colony, Beh. University,
Laxman
Dt.17.02.200
Gulbarga-585106,
1
Karnataka
KAR/585/19
Siddanagouda
College Road, Yelburga,
80
Banappagouda Distt. Koppal, Karnataka Dt.21.11.198
0
Nr. K.B. School, At. Post
KAR/243/95
Govindappa
Hulyal, Tq. Jamkhandi,
Dt.24.02.199
Pujar
Distt. Bagalkot,
5
Karnataka-587301
Near Ashoknagar Senior
Higher Elementary
KAR/887/95
Martin
School, Ashoknagar,
Dt.02.06.199
Castelino
Mangalore-575006,
5
Karnataka
Sri Durga Prasad',
KAR/163/20
Polytechnic Road,
02
A. Vasudeva Rao
Paduperar Vill. & Post, Dt.01.02.200
Mangalore, Karnataka
2
KAR/4204/9
Near Kadiyali Temple,
K. Damodar
9
Kunjibettu Post, UdupiAithal
Dt.27.08.199
576102, Karnataka
9
Prema' Kattabelthur Post,
KAR/2579/1
Via. Tallur, Kundapura
B.L.N.Navada
999
Tal., Udupi Distt.Dt.21.03.99
576230, Karnataka
#71, II Stage,
KAR/2974/2
Jagadeesha
Gayathripuram, 2nd
000
Rao.A.
Cross, Mysore,
Dt.24.11.200
Karnataka-570015
0
Lakshmipura,
KAR/2124/2
Naganahalli Post,
Honnegawda
001
Mysore Tal.-570003,
Dt.23.02.01
Karnataka
#463, 2nd Main , 11th
Cross, B.M Shree
KAR/15850/
Basave Gowda
Nagara, Metagalli,
2002
Mysore-570016,
Dt.31.08.02
Karnataka

<!-- page 5 -->

28

56

Bhausaheb
Babasaheb
Patil

Chikodi Tal.

N11013/1396/2016NC

29

58

Udaya Kumar
K.M.

Mysore Distt.

N11013/1398/2016NC

30

60

Ms. Sujatha C.

Bhadravathi

N11013/1400/2016NC

31

62

Murthy

Chamarajanaga
r Dt.

N11013/1402/2016NC

32

66

Wilson
Shiromanie

Bidar

N11013/1406/2016NC

33

70

Shashidhara
Murthy H.C.

Mandya Distt.

N11013/1410/2016NC

34

71

James P.V.

D.K. Distt.

N11013/1411/2016NC

35

74

Laxmikant
Gurav

Belgaum

N11013/1414/2016NC

36

75

Harish P.V.

D.K. Distt.

N11013/1415/2016NC

A/p. Akkol, Tal. Chikodi, KAR/582/19
Dist. Belgaum-591211,
91
Karnataka
Dt.19.07.91
Kodagahalli Vill.,
Bannur Hobli, T.
KAR/2421/2
Lt.Marigowda
Narasipura Tal, Mysore
002
Distt.-571101,
Dt.25.10.02
Karnataka
Megha Sandesh Nilaya,
1st Main, 2nd Cross,
KAR/92/200
M.Channabasav
Keshavapura Extn.,
1
ayya
Bhadravathi-577301,
Dt.19.01.01
Karnataka
Hunasinapura Vill.,
Somahalli Post, Begur KAR/1259/2
Basavaiah
Hobli, Gundlupet,
002
Chamarajanagar,
Dt.02.08.02
Karnataka-571109
H.No.10-1-189, Bethany
KAR/1888/1
Colony, Besides PWD
S.Shiromanie
999
Office, Bidar, KarnatakaDt.07.04.99
585401
Hosahalli Vill., B.G. Pura KAR/724/20
Hobli, Malavalli Tal.,
00
Channabasappa
Mandya Distt.,
Dt.03.03.200
Karnataka-571417
0
Pudumana House,
KAR/474/19
Nellyady Vill., Puttur
P.C.Varghese
99
Tal., D.K. Distt.,
Dt.6.03.99
Karnataka-574229
4370/A1 Chavatgalli, KAR/423/19
Kadappa Gurav
Belgaum, Karnataka82
590001
Dt.30.07.82
1st Floor, Maliga
Complex Car Street,
Sullia, Sullia Tal., D.K.
KAR/
Distt.-574239,
Karnataka
Babasaheb
Bhauso Patil

<!-- page 6 -->

37

76

K.
Rangaswamy

Hiriyur Rev. Tal.

N11013/1416/2016NC

G.Kalappa

38

85

G. Dayananda

Bangalore Met.
Area

N11013/1425/2016NC

Lt.Giriyappa

39

86

Ms. Veena M.
Hadagali

Bangalore

N11013/1426/2016NC

Muralidhar.V.

40

89

Yogesh L.

Hassan Distt.

N11013/1429/2016NC

Lakkegowda

41

90

Ms.
Muthamma
P.S.

Mysore Distt.

N11013/1430/2016NC

Poonacha.K.M

92

Ms. Babitha
Rani B.M.

D.K. Distt.

N11013/1432/2016NC

Vinaya Kumar

43

94

Chikka
Mayige Gowda
K.M.

Bangalore Met.
Area

N11013/1434/2016NC

Lt.Mayige
Gowda

44

97

Ramachandra
Gowda D.B.

D.K. Distt.

N11013/1437/2016NC

Lt.Babu Gowda

99

Kodi
Nagappaya

Bangalore

N11013/1439/2016NC

42

45

Kodi Janayya

Amruthesh Nilaya, Beh.
APMC Compound,
Vedavathi Nagar,
Hiriyur Tal., Chitradurga
Dist., Karnataka
No.61, 2nd Floor, 7th
Cross, Malleshwaram,
Bangalore-560003,
Karnataka
No.61, Savi Mane, 7th
Main, Nandakumar
Layout, Arehalli,
Chikkalsandra,
Bangalore, Karnataka
Lakkegowda Santhasa
Nilaya Govt. School,
Backside Road,
Udayagirig, Hassan573201, Karnataka
H.No.160, H.I.G.
HUDCO, Bannimantap
Extn., Mysore,
Karnataka-570015
Site No.29, 1st Block,
Katipalla, Mangalore 30, D.K. Distt.,
Karnataka
No.88/1, 3rd 'A' Cross,
Beh. Vinayaka Temple,
Iyyanna Shetty Layout,
Mysore Road,
Bangalore-560026
Deraje House, Ballya
Vill. & Post, Puttur Tal.,
D.K. Distt., Karnataka
No.469, Nr. Soundarya
School, Havanur Extn.,
Nagasandra Post,
Bangalore-560073,
Karnataka

KAR/1056/2
001
Dt.23.04.01
KAR/4640/1
999
Dt.15.10.99
KAR/3269/
1999
Dt.09.07.99
KAR/2193/
2001
Dt.24.08.01
KAR/92/19
94
Dt.21.01.94
KAR/1354/
2002
Dt.09.08.02
KAR/1462/
2000
Dt.11.08.20
00
KAR/3006/
2001
Dt.20.10.01
KAR/2108/
2001
Dt.24.08.01

<!-- page 7 -->

46

103

Paranjyothi

Mysore Distt.

N11013/1443/2016NC

47

108

T.
Mallikarjuna

Gandhinagar,Ba
ngalore

N11013/1448/2016NC

48

111

R.
Shivannachari

Bangalore

N11013/1451/2016NC

49

113

Gangaraju
B.N.

Bangalore City

N11013/1453/2016NC

50

121

R. Gunashekar

Cubbonpet

N11013/1461/2016NC

51

123

Rajendra
Vamanrao
Kulkarni

Belgaum Rev.
Tal.

N11013/1463/2016NC

52

124

Ms. Keshavi
Girish

Naricombu

N11013/1464/2016NC

125

Sadashiva
Naik

D.K. Distt.

N11013/1465/2016NC

53

New Kukkur Village &
Post Talakad Hobil,
Lt.K.M.Siddanan
T.Narasipura Taluk,
jaiah
Mysore Distt.Karnataka571122
No.9, 8th Block, Anand
Rao Circle, Police
Kenchappa.T
Quarters, Gandhi Nagar,
Bangalore Karnataka560009
No.6/11, 7th Main,
15th Cross,
Lt.B.Rangachar
Bhuvaneshwari Nagar,
Magadi Road, Bangalore
Karnataka-560023
No.8,Opp.
N.P.Factory,Behind
Navaneeth Wines,
Narasimhappa
Kavalbyrasandra
R.T.Nagar,Bangalore
Karnataka-560032
#16, Sree Shakthi
Lt.V.Ramaswam
Nilayam 18th Cross,
y
Cubbonpet,Bengaluru
Karnataka-560002
H.No.3,Swamy
Vamanrao
Vivekanand Road,
Anantrao
Chidambar
Kulkarni
Nagar,Tilakwadi,Belgau
m Karnataka-590006
Apeksha Basra
House,Naricombu
Girish Poojary
Village & Post,Bantwal
Taluk,D.K.Dist.
Karnaaka-574219
Kampadakody House,
Sajipa Padu Village &
Lt.Vaman Naik
Post,Bantwal
Taluk.D.K.Dist.
Karnataka-

KAR/1594/
2004
Dt.23.07.04
KAR/1609/
1998
Dt.13.10.98
KAR/1789/
1998
Dt.11.12.98

KAR/2859/
2004
Dt.10.09.04
KAR/198/1
982
Dt.02.04.82
KAR/65/19
86
Dt.07.02.86
KAR/8/199
7
Dt.22.05.97
KAR/470/2
000
Dt.18.02.20
00

<!-- page 8 -->

54

128

K.R. Umesh

Tiptur Town

N11013/1468/2016NC

Lt.K.H.Ramaiah

55

131

Deviprasad
Alva S.

Sullia Town

N11013/1471/2016NC

Guddappa Alva
S.

56

132

Ms. Kavitha K.

D.K. Distt.

N11013/1472/2016NC

M.V. Seetharam

57

134

Shashi Prasad
Gandhi

Devanahalli
Town

N11013/1474/2016NC

Lt.Narayanappa

135

Prabhakar
Nayak

Udupi

N11013/1475/2016NC

Lt.S.Padmanabh
a Nayak

59

136

Sudheer
Shivagouda
Godigoudar

Gokak,
(Belgaum)

N11013/1476/2016NC

Shivagouda
Goudappa
Godigoudar

60

137

Ms. Kalapana
Vasant
Torangatti

Belgaum Rev.
Tal.

N11013/1477/2016NC

Vasant.V.Toran
gatti

61

138

Uday Shiva
Naik

Honavar

N11013/1478/2016NC

Shiva Narayan
Naik

62

141

Motilal
Angadageri

Bilagi

N11013/1481/2016NC

Rajaksab
Angadageri

58

Nanda Jyothi Nilaya
D.No.603 1st Cross
Shankarappa layout
Tiptur Tumkur
Distt.Karnataka-572202
Sri Nidhi Sonangeri
Sonangeri Post Jasloor
Village Sullia D.K.
Karnataka
Highland manor Flat no44, Opp. Vrandavana
Fast Food, Highland
Falnir. Mangalore Taluk,
Karnataka-575002
Taluk Office Road,
Devanahalli Town &
Taluk Bangalore Rural
Distt.Karnataka-562110
Kalmargi Shiriyara
Village & Post UdupiKarnataka-576210
Santosh Nilay,Laxmi
Nagar,Mudalagi, Taluk
Gokak,Dist.Belgaum
Karnatakak-591312
Plot No.29,Laxmi
Road,Bharat Nagar,
Shahapur, Belgaum
Karnataka
Royalkeri Madival Halla
Honavar Taluk
Uttarkannada Distt.
Karnataka
Basaveshwar Nagar Post.
Bilagi Tq.Bilagi Dist.
Bagalkot Karnataka587116

KAR/575/1
985
Dt.25.07.85
KAR/378/1
999
Dt.19.02.99
KAR/192/2
002
Dt.02.02.02
KAR/495/1
989
Dt.14.06.89
KAR/1045/
2000
Dt.28.07.20
00
KAR/78/20
03
Dt.10.01.03
KAR/1448/
1998
Dt.18.09.98
KAR/1228/
2002
Dt.27.07.02
KAR/544/2
004
Dt.19.03.04

<!-- page 9 -->

63

145

Ms. B.J.G.
Sathyashree

Bangalore
Urban Rural

N11013/1485/2016NC

U.Sankappa

B.J.K.Jayadevak
umar

64

149

U. Dharmadas

D.K. Distt.

N11013/1489/2016NC

65

155

Umesh .N.R

Mysore Distt.

N11013/1495/2016NC

Late.B.Ramakris
hnaiah

66

158

Ramachandra
Krishna Hegde

Uttar Kannada
Distt.

N11013/1498/2016NC

Krishna
Ramayya Hegde

67

159

Madhuri.T.D

Bangalore

N11013/1499/2016NC

Diwakar

68

161

Tensingh

Gulbarga Distt.

N11013/1501/2016NC

Hasanappa

N11013/1502/2016NC

G.Krishna
Reddy

N11013/1503/2016NC

Late.
Venkataiah

69

162

K.Ramegowda

Kodigehalli
Area

70

163

K.V.Nanjaiah

Bangalore Met.
Area

No.38, Sumukha Nilaya
1st Floor 7th Main 4th
Cross,Maruthinagar,Cha
ndra Layout
Extn.Nagarabhavi
Village Main Road,
Bangalore Karnataka560072
M.D.Temple Road,I
Bridge,Marnamikatta,
Mangalore Karnataka575001
D.NO.888, 1st Cross,
Near Dr.Charan Clinic,
Bank Colony
Road,Bogadi, Mysore
,Karnataka-570006
Sannidhi Guru Nagara
behind L.I.C.of India,
Court Road, Sirsi(Uttar
Kannada) Karnataka581401
Madhuri.T.D.Advocate
No.612, 2nd floor
Chandra Building
Avenue Road, Bangalore
Karnataka-560222
At & Post habal (T)
Tq.Sedam Dist.Gulbarga
Karnataka-585320
R/at No.22/1, 5th Cross,
S.R.K.Indian School
Road, Hanumaiah
Layout, Kodigehalli,
Bangalore Karnataka560053
No.1829, Sanjeevini
Nagar, Sahakarnagar
Post,Bangalore
Karnataka-560092

KAR/222/1
993
Dt.26.02.93

KAR/3859/
2003
Dt.19.12.03
KAR/866/2
003
Dt.30.05.03
KAR/1136/
91
Dt.20.12.91
KAR/1000/
2005
Dt.22.05.05
KAR/1395/
03
Dt.18.07.03
KAR/264/2
000
Dt.04.02.20
00
KAR/559/1
998
Dt.17.04.98

<!-- page 10 -->

71

164

S. Nova
Bethania

Bangalore City

N11013/1504/2016NC

V.
Selvanayagam

72

167

Kamala S.

Mysore

N11013/1507/2016NC

Lt.Siddegowda

73

170

H.L.Anantha
Swamy

Civil Court
Bangalore

N11013/1510/2016NC

H.Lakkappa
Nayaka

K.G.Venkappa

74

171

Indira.S.S.

Bangalore

N11013/1511/2016NC

75

172

K.L.Bhojraj

Shimoga Distt.

N11013/1512/2016NC

M.K.Lokappa

76

173

K.B.Thirtha
Prasad

Chamarajanaga
r Dt.

N11013/1513/2016NC

Lt.Basavalingap
pa

77

174

Shivarama

Udupi Distt.

N11013/1514/2016NC

Kariya
Marakala

78

176

D.Rajanna

Bangalore East

N11013/1516/2016NC

Doddabhyanna

Noah's Ark, No.228,
16th Cross,9th Main
HSR Lay Out & Post.
Bangalore Karnataka560102
#A-04-02, AIISh Layout,
Bogadi 2nd Stage
Mysore Karnataka570006
No.187,4th
Cross,Veerabhadra
Nagara,Hosakerehalli
Extn. BSK 3rd Stage
Bangalore Karnataka560085
H.No.3,1st Floor,Site No57/58,4th Main,1st
Cross,Hemanth Nagar,
Marathahalli, Bangalore
Karnataka-560037
Nagaransabha Complex,
Main Bus Stand,Room
No-9, Sagar,Shimoga
Distt.Karnataka-577401
Kamaravadi,Banahally
Post, Santhemara Hally
Hobli,Chamarajnagar
Taluk, Chamarajnagar
Distt.Karnataka-571124
Nishika Airody Village &
Post,Udupi Taluk & Distt.
Karnataka-576226
No.29/3,1st Main 1st
Cross, Near Navajyothi
Study House,
K,Narayanapura,K.R.Pur
am Hobli, Bangalore East
Taluk Bangalore
Karnataka-56007

KAR/663/2
003
Dt.11.04.03
KAR/2420/
2003
Dt.05.09.03
KAR/1132/
1992
Dt.23.10.92

KAR/885/2
002
Dt.14.06.02
KAR/959/1
999
Dt.25.03.99
KAR/990/2
002
Dt.28.06.02
KAR/3345/
2001
Dt.21.12.01
KAR/1799/
1995
Dt.01.09.95

<!-- page 11 -->

79

180

Radhakrishna
Shetty K.

Udupi Distt.

N11013/1520/2016NC

Lt.A.Sheenapp
Shetta Y

80

181

Smt.Daya D.B

Madikeri

N11013/1521/2016NC

Deranna B.P.

N11013/1526/2016NC

Ibrahim.N

81

186

Ismail.N

Dakshina
Kannada Distt.

82

187

Purushothama
.D

Dakshina
Kannada Distt.

N11013/1527/2016NC

Puttuanna
Gowda

83

190

Suresh
Halasur

Haveri Distt.

N11013/1530/2016NC

Basavantappa
Halasur

84

196

Manjunatha

Mysore Distt.

N11013/1536/2016NC

Rajannna

85

197

M.Vimala

Mysore Distt.

N11013/1537/2016NC

Sri
M.Basavaraju

86

199

Dhananjaya
K.G.

Sagar

N11013/1539/2016NC

Ganapathi K.

87

200

A.M.Sreedhara

Shivamoga
Distt.

N11013/1540/2016NC

A.Mayappa

D.No.1-139,
Nisarga,N.H.66,
KAR/1473/
Gopady,Post.Koteshwara,
2001
Kundapura Taluk, Udupi Dt.06.07.01
Dist.Karnataka-576222
Amruthamshu Opp.to
Raghavendra temple
KAR/2972/
Mann's Compound Road
2005
Madikeri,Kodagu
Dt.23.09.05
Karnataka-571201
Priyadarshini Compound
Nellyadi-Post &
KAR/4135/1
village,Puttur999
Taluk,Dakshina Kannada Dt.28.08.99
Karnataka-574229
Skanda Complex Near
KAR/494/20
Bus stand Panja
06
Post.Panja Sullia Taluk,
Dt.28.06.06
D.K.Karnataka-574232
Udaynagar, Malapur
KAR/3641/1
Road, Haveri,
999
Karnataka-581110
Dt.06.08.99
No.5,1st Main Road,
KAR/838/20
Kumbarakoppal,Metagal
02
li Post,Mysore
Dt.07.06.02
Karnataka-570016
# 73/2,7th Cross,
Goutham Block,
KAR/1527/2
(A.J.Block),
005
N.R.Mohalla,Mysore
Dt.22.07.05
Karnataka-570007
Mathrusri Nilaya,1st
KAR/2988/2
Cross, Sridhara
000
Nagar,Sagar Karnataka- Dt.24.11.200
577401
0
No.32.1st Cross, Kanaka KAR/1774/2
Nagara,Vinobhanagara
000
Extension Shimoga
Dt.18.08.200
Karnataka-577204
0

<!-- page 12 -->

88

202

Arun Kumar

Dakshina
Kannada Distt.

N11013/1542/2016NC

89

204

Kumaresh
P.Kotigoudar

Gadag Distt.

N11013/1544/2016NC

Prabhugouda

90

205

Steevan Victor
Lewis

Udupi Distt.

N11013/1545/2016NC

Isidor Lewis

91

206

Sundara
Achary J.

Udupi Distt.

N11013/1546/2016NC

Lt.Janu Acharya

92

207

Ramesh
Kumar .K

Bangalore Met.
Area

N11013/1547/2016NC

K.Gopala
Krishna Bhat

93

208

Sundara
Gowda K.

Dakshina
Kannada Distt.

N11013/1548/2016NC

Podiya Gowda

94

209

Ganesh
Narasimha
Hegde

Sirsi Taluk

N11013/1549/2016NC

Narasimha
Shantaram
Hegde

95

211

Vishwas
Hegde

Kumta

N11013/1551/2016NC

Gajanan Hegde

Lt.Raghuram
Shetty

Arya House Amtady
KAR/542/20
Village Modankap Post,
00
Bantwal Taluk, South Dt.18.02.200
Kanara Distt. Karnataka0
H.No.3101,
KAR/1241/
Rachoteshwar nagar
1995
Vakkalgeri Gadag
Dt.14.07.95
Karnataka-582103
Shwetha Opp.
Abhinethri
Complex,Nethaji Nagara KAR/103/2
Chanthar Village, Kunjal
001
Road Brahmavara Post, Dt.19.01.01
Udupi Taluk &
Distt.Karnataka-576213
Vignesh Nilaya Achada
Cross, Yenagudde Post, KAR/79/19
Katpady Udupi Taluk
94
Udupi Distt. Karanataka- Dt.15.01.94
574105
No.55, Sri. Durga
Nilaya, Kadappu
Farms,1st Cross,
KAR/434/1
Amaravathi Layout,
989
Nagasandra Post
Dt.19.04.89
Bangalore Karnataka560073
1st Floor, Radhika Plaza,
Court Road, (M.S.Rao
KAR/2001/
Road), Puttur Taluk
2002
D.k.Distt. Karanataka- Dt.06.09.02
574201
Lingadkon, postKAR/277/2
Nilekani Sirsi
003
N.K.Karnataka-581403 Dt.14.02.03
H.No.171, Achyut EBlock, Near Varada
KAR/1297/
Vittal Temple,
1995
Haleherawatta, Kumta
Dt.21.07.95
(N.K.) Karnataka581343

<!-- page 13 -->

96

213

S.Sanjeeva
Gowda

Mysore Distt.

N11013/1553/2016NC

97

214

Yamunavathi.
H.P.

Mysore Distt.

N11013/1554/2016NC

Lakshmikantha
Raju.N.

98

215

S.Vijayalaksh
mi

Bangalore Distt.

N11013/1555/2016NC

A.S.Mohana
Krishnan

99

217

T.R.Avanish

Shivamogga
Distt.

N11013/1557/2016NC

Lt.Sh.T.S.Ramac
handraiah

100

219

Vasanth
Kumar

Kannada Distt.

N11013/1559/2016NC

H.Manjappa

101

220

N.Shivashanka
ra

Mandya Distt.

N11013/1560/2016NC

M.S.Nanjundaia
h

102

221

Shambulingaia
h Hiremath

Shimoga Distt.

N11013/1561/2016NC

Channabasaiah.
M.

103

222

A.Kumar

Mandya Distt.

N11013/1562/2016NC

Ananthe Gowda

S.Ramanna
Gowda

No.645, Hebbal 1st
Stage, 7th Main, F Cross
Metagally Post, Mysore
Karnataka-570016
# 686, 5th Cross,
Paparam Street,
Nazarbad, Mysore
Karnataka-570010
Brindavan Pride
Apartments,188,2nd
Cross, 4th Main, Vivek
Nagar Bangalore
Karnataka-560047
Sharada Shankara
Nilaya, Tudur, Tudur
Post, Thirthahalli Taluk,
Shivamogga Distt.
Karnataka-577226
10-160/6, 4th Cross,
prashanthi Road, Padavu
Village, Mangalore
Talukm Dakshina
Kannada Distt.
KaranatakaKadathanalu,K.Settahalli
Hobli, Srirangapatna
Taluk, Mandya Distt.
Karnataka-571435
C/o Gururenuka,
Subhas Nagar,
R.M.C.East Road, Sagar
Shimoga
Distt.Karnataka-577401
Opp.Hotel Hariprasad,
Main Road,
Srirangapatna, Mandya
Distt. Karnataka571438

KAR/1025/
2000
Dt.28.07.20
00
KAR/1514/
1999
Dt.31.03.99
KAR/269/1
999
Dt.12.02.99
KAR/570/1
993
Dt.25.06.93

KAR/641/1
990
Dt.27.07.90
KAR/841/1
995
Dt.21.04.95
KAR/459/1
987
Dt.24.06.87
KAR/1555/
2001
Dt.13.07.01

<!-- page 14 -->

104

223

B.M.Mahadev
Swamy

Chamarajanaga
r Dt.

N11013/1563/2016NC

Marimallappa

105

224

Arif Ali Khan

Shimoga Distt.

N11013/1564/2016NC

A.Sadulla Khan

106

225

Mayappa
Laxman Pol

Bangalore

N11013/1565/2016NC

Lt.Laxman S.Pol

N11013/1566/2016NC

T.N.Muralidhar
a

107

226

M.Radhamma

Bangalore Rural
Distt.&
Metroplolitan
Area

108

227

Syed Ameer

Mysore City &
Distt.

N11013/1567/2016NC

Syed Ismail

228

Sridhara
Yenmakaje

Dakshina
Kannada Distt.

N11013/1568/2016NC

Lt.Ammu
Poojary

N11013/1569/2016NC

Lt.N.Narasappa

109

110

229

P.N.Nagesha

Civil Court
Bangalore

111

234

Yallappa
Mhataru
Khokalekar

Belgaum City &
Belgaum Distt.

N11013/1574/2016NC

Mhataru

A.R.Nagendra

Channapatna
Taluk
Ramanagara
Distt.

N11013/1575/2016NC

A.S.Rajagopal
Rao

112

235

No.35, Basavatti,
Santhemarahally Post,
Chamarajnagar Taluk &
Distt. Karnataka571115
Nehru Nagar, II Cross,
Post Sagar, Shimoga
Distt. Karnataka577401
# 8, Pillanna Garden, 1
Main.II Stage, Nagawara
Main Road, Bangalore
Karnataka-560045
No.2315,
Thyagarajanagar
Doddaballapur,
Bangalore Rural Distt.
Karnataka-561203
D.No.336, C.C.Block 1st
Stage Hudco Colony
bannimantap Extn.
Mysore Karnataka570015
Flat No.203, Vrindavana
Apartments Arya Samaja
Road, Mangalore Taluk
Karnataka-575003
No.10/5, 1Floor 8th
Cross, Vittal Nagara, Gef
Post, Mysore Road,
Bangalore-26
KarnatakaS.no.280/2, Main Road,
Basawan-Kudachi,
Belgaum Karnataka591124
Kodamballi Village
Virupakshipura Hobli
Channapatna Taluk
Ramanagara Distt.
Karnataka

KAR/2017/
1995
Dt.13.10.95
KAR/982/1
990
Dt.14.12.90
KAR/924/2
002
Dt.21.06.02
KAR/1490/
1994
Dt.02.12.94
KAR/374/2
006
Dt.17.02.06
KAR/2563/
1999
Dt.16.04.99
KAR/760/2
000
Dt.10.03.20
00
KAR/214A/1981
Dt.07.04.81
KAR/2399/
2002
Dt.25.10.02

<!-- page 15 -->

113

236

A.Manjula

Bangalore

N11013/1576/2016NC

S.N.Shekar

114

237

K.Vijayalaksh
mi

Bangalore
Urban & Rural
Dist.

N11013/1577/2016NC

Ambaji Rao K

115

238

Ramesha.P

Bangalore Distt.

N11013/1578/2016NC

Nemu Bangera

116

240

Kartik Shankar
Poojari

Belgaum Rev.
Tal.

N11013/1580/2016NC

Shankar
Balappa Poojari

117

243

K.Satish

Bangalore
Metropolitan
City

N11013/1583/2016NC

Lt.Sh.K.S.Krishn
e Gowde

N11013/1588/2016NC

Padmappa
Poojary

118

248

Meenakshi K.

Bangalore
Urban Distt.

119

249

N.Mahesha

Bangalore
Urban & Rural
Area

N11013/1589/2016NC

N.Nanjundaiah

120

250

S.R.Ravikumar

Bangalore
Urban & Rural
Area

N11013/1590/2016NC

S.B.Ramegowda

No.794, 1st Main 6th
Cross, L.N.Colony,
Yeshwanthpur
Bangalore Karnataka560020
No.15, 1st Cross, 1st
Main, Chinnappa
Layout, Kempapura ,
Hebbal, Bangalore-24
No.6,1st Main Road,
Kaveri Layout Opp.
Ashwini Store
Nagarbhavi Road,
Vijayanagar Bangalore
Karnataka-560040
3998/A, Opp. Modern
Complex Near City
Clinic lab, Kakatives,
Galli Tq/Dist. Belgaum
No.16/1, 1st Cross,
Banaswadi Main Road,
M.S.Nagar Bangalore
Karnataka-560033
No.112/73, 9th Cross
2nd Main Road,
Chamarajpet Bangalore
Karnataka-560018
No.12/13, Scholars
Enclave, Kamath Layout,
2nd Floor
Chennanayakanapalya,
Chikkabidarakallu,
Nagasandra Post
Tumkur Road, Bangalore
Karnataka-560073
No.49/A, 5th A Cross
Subbanna Garden
Vijayanagar Bangalore
Karnataka

KAR/1286/
1996
Dt.29.03.96
KAR/4028/
2006
Dt.24.11.06
KAR/2247/
2003
Dt.29.08.03
MAH/3695
/2003
Dt.17.11.03
KAR/2152/
2001
Dt.24.08.01
KAR/936/2
002
Dt.21.06.02

KAR/2762/
1999
Dt.28.05.99

KAR/188/1
994
Dt.04.02.94

<!-- page 16 -->

121

251

C.K.Narasimha
iah

Bangalore
Urban & Rural
Area

N11013/1591/2016NC

Kadaraiah H.

122

252

Yallappa
Mahadevappa
Mannur

Bangalore

N11013/1592/2016NC

Lt.M.Y.Mannur

123

253

B.N.Venugopal

Bangalore
Urban & Rural
Area

N11013/1593/2016NC

Lt.B.Nanjappa

124

259

Murahari.K

Udupi

N11013/1599/2016NC

K.Anantha
Padmanabha
Bhat

125

261

H.R.Karunakar
a

Bangalore Distt.

N11013/1601/2016NC

Lt.H.G.Ramaiah

126

265

S.Jayanth

N11013/1605/2016NC

Lt.L.Srinivas
Reddy

127

266

Halliboregowd
a

Mandya Distt.

N11013/1606/2016NC

Boregowda

128

268

B.S.Geetha

Bangalore
Metropolitan
City

N11013/1608/2016NC

Lokesh.M.K.

No.43, 8th Cross, Fair
Price Shop Building,
Door No.5,2nd Floor,
Opp. Appollo Public
School, Gajanananagara
Hegganahalli Cross,
Vishwaneedam Post,
Bangalore Karnataka560091
No.MF-43A/10, Nandini
Layout Bangalore
Karnataka-560096
No.19, Amruth Mahal, I
Main, I Cross, M.L.A.
Layout R.T.Nagar
Bangalore-32
Near Bharathi Kalyana
Mantap, Adi-Udupi, Post
Ambalpady, Udupi Taluk
& Distt. Karnataka
No.19/A,2nd Floor,9th
Main Shivanagar,
Rajajinagar, Bangalore
Karnataka-560010
No.132/53, 7th Cross,
Wilson Garden,
Bangalore Karnataka560027
6th Cross, Moulyashree
Nilaya,
Chamundeshwara
Nagar, Mandya City
Mandya Distt.
Karnataka-571401
Dwarakamaayi, No.77,
4th A Cross, 4th Main,
JBKI Workers, Layout
Shankarnagar
Mahalakshmipuram
Bangalore Karnataka560096

KAR/4281/
2006
Dt.22.12.06

KAR/1621/
1999
Dt.03.04.99
KAR/470/1
977
Dt.18.11.77
KAR/177/1
991
Dt.15.02.91
KAR/407/1
996
Dt.02.03.96
KAR/174/1
990
Dt.09.02.90
KAR/1073/
2000
Dt.28.07.20
00

KAR/1478/
1994
Dt.02.12.94

<!-- page 17 -->

Mysore Distt.

N11013/1609/2016NC

272

Shrishail
Hiremath

Bijapur

N11013/1612/2016NC

131

273

Ajit Bansode

Bijapur

132

274

Shridhar.Sinn
ur

Bijapur

133

277

Sumithra.N.

Bangalore
Urban Distt.

N11013/1617/2016NC

134

280

M.S.Jayachand
ra

Kodagu Distt.

N11013/1620/2016NC

135

283

Venkategowda
.T

Bangalore

N11013/1623/2016NC

136

284

Shantha

H D Kote
Mysore Distt.

N11013/1624/2016NC

137

286

Sreedharan
Nair P.N

Bangalore

N11013/1626/2016NC

129

269

G.V. Sudha

130

N11013/1613/2016NC
N11013/1614/2016NC

M.V.Ramesha

D.No.1703,9th Cross, E
& F Block, Ramakrishna
Nagar, Mysore
Karnataka-570022

KAR/2795/
2004
Dt.10.09.04

KAR/19/20
Hiremath Street, Bijapur
00
Road, B, BagewadiDt.07.01.20
586203
00
Asar Street J.M.Road
KAR/3732/
Hoovappa
Bijapur Karnataka1999
Bansode
586104
Dt.13.08.99
Indira Nagar
KAR/1734/
Sangappa.S.Sinn
Muddebihal Dist.Bijapur
2003
ur
Karnataka-586212
Dt.08.08.03
Sir M.V.Nilaya, No.22/3,
Gavipuram 17th 'A'
KAR/2213/
Main, Maruthi Block,
Basavaraj.R
2001
Opp. Govt.Gutte School,
Dt.24.08.01
Srinagar Bangalore
Karnataka-560050
Uggappa Building,
KAR/832/1
Kohinoor Road,
M.M.Somanna
996
Madikeri KarnatakaDt.22.03.96
571201
# 18/1, 7th Cross, 13th
Main, Srinivasanagar, KAR/2405/
Doddathimmaia
Banashankari 1st Stage,
2003/
h
Bangalore Karnataka- Dt.05.09.03
560050
Nanjanayakanahalli
Village, Kasaba Hobli
KAR/98/20
Lt.Siddegowda
K.Yedathore Post,
02
H.D.Kote Taluk Mysore Dt.18.01.02
Dist.Karnataka-571114
No.208,Ampadi, 4th
KAR/896/2
Lt.Parameswan
Cross, Jagadish Nagar,
003
Nair
Bangalore KarnatakaDt.06.06.03
560075
Sangya
Hiremath

<!-- page 18 -->

138

290

K.V.Jagannath
Reddy

Bangalore
Metropolitan
Area

N11013/1630/2016NC

139

292

Subhash
Basavaraj
Yadal

Belguam Distt.

N11013/1632/2016NC

140

296

Aboobakar J.N.

Dakshina
Kannada Distt.

N11013/1636/2016NC

306

Mohan Kumar
N.

Sampangiraman
agar

N11013/1646/2016NC

142

308

N.L.Srinivasa
Prasad

Kolar Distt.

N11013/1648/2016NC

143

311

Jalandhara

Bangalore
Met.Area

N11013/1651/2016NC

144

316

Shashikala

Mysore Distt.

N11013/1656/2016NC

145

322

Sangayya
Vastrad

Bilagi Revenue
Taluka

N11013/1662/2016NC

146

328

Nirupama
Patil

Bangalore

N11013/1668/2016NC

141

No.326, 1st Floor,2nd
Cross, Behind Tulsi
Venkatarama
Threatre, Marath Halli,
Reddy
Bangalore Karnataka560037
Plot No.2564, Sector-12,
basavaraj
Guru Prasad, Mahantesh
Basavanneppa
Nagar, Belgaum
Yadal
Karnataka-590016
Baqir Compound Near
G.H.P.School Adkar
Lt.Mahammad
Jalsoor Village Sullia
Beary J.N
Taluk D.K.Karnataka574239
No.8, 6th Cross, 1st
Main Road,
Lt.Sh.Narayanas
Sampangiramanagar
wamy.S.
Bangalore Karnataka560027
No.1, Lakshmi Nivas
Nukkanahalli (Post &
N.L.Narayana
Village) Kolar Taluk &
Rao
Distt. Karnataka563126
# 26, Guru Shree Nilaya
Shakthi Farm Road, 4th
Cross, Bhoopasandra
Kala Poojary
R.M.V.2nd Stage,
Bangalore Karnataka560094
# 830, 4th Main, 26th
H.P.Sathyanaray
Cross, Vidyaranyapuam
ana
Mysore-8 KarnatakaNear Hanuman Temple
Gurubasayya
Sulibavi Galli, Bilagi
Vastrad
Dist.Bagalkot Karnataka587116
1B Sree Sreevarinkayam,
Appanah
4th Cross Basaveshwara
Sooriah
Layouk Nagashetty Halli
Sanjaynagar Banglore

KAR/3559/
2003
Dt.14.11.03
KAR/614/1
994
Dt.01.07.94
KAR/94/20
02
Dt.18.01.02
KAR/950/2
002Dt.22.0
6.02
KAR/1088/
1999
Dt.26.03.99

KAR/820/2
005
Dt.15.04.05
KAR/2067/
1999
Dt.13.04.99
KAR/1710/
2003
Dt.08.08.03
KAR/1805/
01 Dt.
04.08.01

<!-- page 19 -->

147

329

Vedavathi T.D

Channapatna
Taluk

N11013/1669/2016NC

Govindegowda

148

331

M.Krishnaraja

Vittal of
Bantwal T.Q,
D.K, Distt.

N11013/1671/2016NC

M. Shivarama
Bhat

Manjunath . P

149

332

C.K.Anupama

Bangalore Distt.

N11013/1672/2016NC

150

333

Vijayakumari

Bangalore Distt.

N11013/1673/2016NC

H.L.
Sridharamurthy
K.B.
Bhaskarachar

151

334

Mohan.K.B

Mandikeri Distt.

N11013/1674/2016NC

152

338

Leelavathi.S

Ramanagara
Distt.

N11013/1678/2016NC

B.Shivanna

153

340

Cheluvambika
M.B.

Maysore

N11013/1680/2016NC

Krishnegowda
I.N.

154

342

Parashivamurt
hy M

Mysore Distt.

N11013/1682/2016NC

Lt.
Mahadevaiah

155

345

M.P. Vijaya

Mysore Distt.

N11013/1685/2016NC

Lt. Papashetty

156

347

K.V.Vasu

Mysore Distt.

N11013/1687/2016NC

R.S.Varadachar

Thittamaranahali Village
Mailanaikayana Halli
Post Kasaba Hobli
Channapatna Taluk
Ramanagara Dist.
Door No. 3-14,
Periyappady House,
S.S.Vihar Post, Alike
Village, Bantwal T.Q,
D.K, Karnataka 574235
No. 206/A-6th Main,
1st Stage, 6th Phase,
Mahaganapathi Nagar,
Banglore, Karnataka, Pin
- 560044
47/1, Mount Joy Road,
Hunumantha Nagar,
Banglore, Pin - 560019
Kudige Village, Kushal
Nagar Hobli, Madikeri
District, Karnataka State
- 571232
1485, Opp. Ijoor Police
Station B.M.Road,
Gandhinagar, 4th Main
Road, Ramanagar Distt.
Karnataka - 562159
263, Old Bandikeri 4th
Cross, K.R.Mohalla
Mysore - 5700024
# 59, Bose Nilaya
Behind Nirmithi Kendra,
Bogadi 2nd Stage,
Mysore - 570026
No. 664/3, Vinayaka
Baavane, Panchyath
Layout, Yelwala Mysore
Taluka And Distt. 571130
#1407, Vivekanda
Nagara, Mysore,
Karnataka - 57023

1119/06
Dt.
21.04.06
KAR1127/0
2 Dt.
12.07.02
KAR/1954/
02 Dt.
31.08.02
KAR/155/8
9 Dt.
08.02.89
KAR/2322/
99 Dt.
05.12.98
KAR/2321/
01 Dt.
31.08.01
KAR/75/91
Dt.
25.01.91
KAR/2112/
06 Dt.
04.08.06
KAR/197/9
8 Dt.
06.02.98
KAR/36/04
Dt.
09.01.04

<!-- page 20 -->

N11013/1688/2016NC
N11013/1690/2016NC

B.Nagendra
Prasad

157

348

P.Geetha

Mysore Distt.

158

350

L.N. Rejendran

Mysore Distt.

159

352

Ramesh
Kumar

Bangalore

N11013/1692/2016NC

Lt.Ramakrishan

160

353

Sayeesh.C.R.

Davangeae

N11013/1693/2016NC

Ramappa.S.

161

354

Soumya

Dakshina
Kannada Distt.

N11013/1694/2016NC

Devi Prakash
Hegde

N11013/1695/2016NC

B.D.Joyappa

L.Nanjappa

162

355

B.J.Deepak

In And Around
Somwarpet
Taluk And,
Kodagu Distt.

163

358

H.S. Yashoda

Mysore Distt.

N11013/1698/2016NC

N.Nagendra

164

360

Sanganagouda
M.Marigoudra

Gadag Tq.Distt.

N11013/1700/2016NC

Maribasana
Gouda
Marigouda

362

Mahesh.S.Kum
mar

Avalahalli Area
Bangalore

N11013/1702/2016NC

165

Lt.Shankarappa

# 233, "C" Block, K.R.
Mills Colony, Mysore 570003
No. 235, EWS, Citb,
Hudco House, Udayagiri,
Mysore - 570019
Yogi Nivas, No.117/1,
3rd Cross, Maheshwari
Nagar, T.Dasarahalli,
Bangalore Karnataka560057
Door No-611/A, College
Road, Nittuvalli New
Extension, Davangere
Karnataka-577004
Shree Devi Kripa,
Pejavara Post- Kenjaru
Village, Via Bajpe,
Mangalore Taluk.
D.K.Distt. Karnataka
Thalthar Shettalli Village
Hanagal Post Somwarpet
Taluk N-Coorg
Karnataka-571236
# 546, 4th Main, 19th
Cross,
Vidyaranyapuram,
Mysore Karnataka
Virabhadreshwar Nilaya,
Nagasamudra Village,
Tq/Distt. Gadag
Karnataka-582102
No.1565/J, 18th Main,
9th Cross, Muneshwara
Block, Near Arogya
Kendra, Avalahalli,
bangalore Karnataka560026

KAR/4245/
06 Dt.
15.12.06
KAR/1542/
02 Dt.
23.08.02
KAR/441/1
988
Dt.15.06.88
KAR/2124/
2001
Dt.24.08.01
KAR/3979/
2006
Dt.17.11.06
KAR/787/1
999
Dt.24.03.99
KAR/3193/
2001
Dt.23.11.01
KAR/1614/
2006
Dt.14.07.06
KAR/3511/
2003
Dt.14.11.03

<!-- page 21 -->

166

368

Lavanya.A.Shet
ty

Mangalore
Dakshina
Kannada Distt.

N11013/1708/2016NC

Lt.T.Sasashiva
Shetty

167

369

Hegde Ganpati
Venkatraman

Bangalore

N11013/1709/2016NC

Lt.Hegde
Venkatraman
Narasinha

N11013/1711/2016NC

Shekharappa
Mittalakod
Mallayya
Vastrad

168

371

Sarvamangala

Karnataka State
of Bagalkot
Distt.

169

372

Gangayya
Vstrad

Hunagund

N11013/1712/2016NC

N.R.Siddaraju

170

375

Smt.C.P.Padma

Mysore Distt.

N11013/1715/2016NC

171

376

Sheela
N.V.Nee
Sheela Sagar

Dakshina
Kannada Distt.

N11013/1716/2016NC

L.N.Sagar

172

377

Udaykariyapp
a B.G.

Laksmidevi
Nagar
Bangalore

N11013/1717/2016NC

Gopalappa

173

380

Shidilingappa
Barahanpur

Guledgudd in
Badami Taluka

N11013/1720/2016NC

Rachappa
Barahanpur

Shimoga City

N11013/1722/2016NC

174

382

Vageesha.M.S.

M.Shadaksharai
ah

C/o Smt.Shalini,
Manupriya, Flat No.101,
Devi Darshan Apartment
Chambers Garden, Bolar
Mangalore Karnataka575001
No.180, B.C.M.C.Layout,
Raghuvanahalli,
Kanakpura Road,
Bangalore Karnataka560062
At Post-Kerur House
No.1619 Tq Badami
Distt.Agalkot
At.Post.Amingad
Tq.Hunagund
Distt.Bagalkot
KarnatakaNilasoga Village,
Mugoor Hobli,
T.Narasipura Taluk,
Mysore Distt.KarnatakaDoor No.23-11-916/3,
Shiva Prasad, Amar Alva
Road, Monkey Stand,
Mangalore Karnataka575001
No.277, 5th Main Road,
Lakshmidevi Nagar,
Nandini Layout Post,
Bangalore Karnataka560096
Main Road Kabra Street
Ward No-3 Guledgudd
Tq.Badami Dist.Bagalkot
Karnataka-587203
Near NGO Hall, KEB
Circle, Mehdi Nagar
Shimoga Karnataka577201

KAR/753/1
990
Dt.17.08.90

KAR/344/1
983
Dt.24.06.83
KAR/321/1
999
Dt.12.02.99
KAR/1224/
1995
Dt.14.07.95
KAR/2452/
2003
Dt.05.09.03
KAR/1189/
1993
Dt.03.09.93
KAR/3432/
2003
Dt.07.11.03
KAR/245/1
974
Dt.16.08.74
KAR/2985/
2000
Dt.24.11.20
00

<!-- page 22 -->

175

384

Sumithra.B

Mysore Distt.

N11013/1724/2016NC

176

385

S.V.Sudhamani

Tumkur

N11013/1725/2016NC

Ramesh.T

177

390

Vijaykumar S
Gunjal

Belgaum Distt.

N11013/1730/2016NC

Shridhar S
Gunjal

178

391

Goroshi
Shankar

Gokak Taluka

N11013/1731/2016NC

179

393

Bidaralli
Nagaraj
Basappa

Hubli Dharwad
Distt.

N11013/1733/2016NC

180

394

C.M.Kaveendr
a

Madikeri City of
Kodagu Distt.

N11013/1734/2016NC

181

396

Ruby.K.Jose

Whole of India

N11013/1736/2016NC

182

397

Prasad Kumar
Rai P.

Dakshina
Kannada Distt.

N11013/1737/2016NC

399

T.V.Govindapp
a

Civil Court,
High Court,
mag. Court
Bangalore City

N11013/1739/2016NC

183

G.Manju

No.1663/29,
A.K.Colony, K.N.Pura,
Udayagiri, Mysore Distt.
Karnataka
Maruti Nilaya,
Nagannana Palya, Sira
Gate, Tumkur
KarnatakaFlat No.6, Green Castle
Apartment Angol Road,
Near Gadgil Bus Stop,
Belgaum Karnataka590006

KAR/1511/
2005
Dt.22.07.05
KAR/975/1
999
Dt.25.03.99

KAR/

KAR/2787/
At/Post.Kalloli Tal.Gokak
2000
Basappa
Distt.Belgaum
Dt.03.11.20
Karnataka-591224
00
No.318 Bhavani Arcade
Basappa
KAR/3225/
Ncm hubli
Veerabhadrapp
1999
Distt.Dharwad
a Bidaralli
Dt.02.07.99
Karnataka-580020
Rakshan Nilaya, Block
KAR/160/1
Lt.C.S.Mandann
No-14, Rifile Range,
997
a
Madikeri Town, Kodagu
Dt.13.06.97
Distt.Karantaka-571201
No.15, 1st 'A' Cross, 2nd
K/1044/20
Block Vishwapriya
Biju George
03
Nagara begur Bangalore
Dt.31.08.03
Karnataka-560068
Manushree House,
Ajjbettu, Bantwal Mooda KAR/393/1
Monappa Rai
Village, Jodumarga Post,
998
Bantwal Taluk
Dt.06.03.98
D.K.Distt.Karnataka# 85/3, 3rd Main Road,
17th Cross, Bank of
KAR/601/2
Lt.Venkataswam
Borada Colony, J.P.Nagar
014
y
7th Phase, Bangalore
Dt.20.06.14
Karnataka-560078

<!-- page 23 -->

184

401

Mallika G.V.

Dakshina
Kannada

N11013/1741/2016NC

Gundappa

185

402

L.B.Anasuyam
ma

Bangalore
Met.Area

N11013/1742/2016NC

Lt.L.N.Basappa

186

403

R.Raghunath
Rao

Bangalore
Met.Area

N11013/1743/2016NC

K.Y.Rama Rao

187

405

K.Peethambara
n

Gokula
Bangalore

N11013/1745/2016NC

A.Krishnan

188

410

Ganesh Kumar
.K

Udupi

N11013/1750/2016NC

G.Gopal Shetty

189

411

S.R.Thulasikris
hna

Bangalore
Distt.

N11013/1751/2016NC

S.P.Ramaiah

190

413

M.S.Kashiappa

Coorg Distt.

N11013/1753/2016NC

M.A.Somaiah

191

415

Nadagoundar
Basavraj

Muddelbihal
Taluka Bijapur
Distt.

N11013/1755/2016NC

Nadagoundar
Amarappa

Inchara H.No.109-C,
6th Cross Girinagar,
land Links Township,
Derebail-Konchady,
Mangalore Karnataka575008
No.Old.224/4, New B48/5, Bahubalinagar,
Jalahalli, Bangalore
Karnataka-560013
No.297, 4th Main, 2nd
Cross, 1st Stage, 1st
Phase,
Manjunathanagar,
Rajajinagar Bangalore
Karnataka-560010
201, F2, No.56
Harmony, Sundar Nagar
2nd Cross, Opp.to
Ramaiah Kalyana
Mantapa, Gokula
Bangalore Karnataka560054
Sowrabha Kote-Kandiga
Kote Village Katapady
Post Udupi Taluk & Distt.
Karantaka-574105
# 835, Rashmi Nilaya
Ground Floor, 8th Main
4th Stage, bemal Layout,
Rajarajeshwar Nagar,
Bangalore Karnataka560098
Lavi Law Chamber,
Panchayath Building,
Market Road,
Gonikoppal, Coorg Distt.
Karnataka-571213
House No.162, 9th
Cross, KHB Colony,
Muddebihal, Tq. Distt.
Bijapur Karantaka-

KAR/1107/
2007
Dt.08.06.07
KAR/575/1
999
Dt.23.03.99
KAR/181/1
984
Dt.04.04.84

KAR/1019/
2000
Dt.28.07.20
00
KAR/846/2
001
Dt.23.03.01
KAR/202/1
986
Dt.05.03.86

KAR/402/1
998
Dt.06.03.98
KAR/2007/
2003
Dt.22.08.03

<!-- page 24 -->

192

416

Shivappa
Lotageri

Muddelbihal
Taluka Bijapur
Distt.

N11013/1756/2016NC

Halleppa
Lotageri

193

417

Meti Laxman

Muddelbihal
Taluka Bijapur
Distt.

N11013/1757/2016NC

Meti.Sanganaba
sappa

194

419

Sajjan
Mallappa

Koppal Distt.

N11013/1759/2016NC

Basappa Sajjan

195

420

Saraswathi.J

Mysore Distt.

N11013/1760/2016NC

Krishnamurthy

196

421

Amrutha
Sindhu.S

Bangalore

N11013/1761/2016NC

Srinidhi.C.R.

197

422

Rajashree K.

Dakshina
Kannada Distt.

N11013/1762/2016NC

Lt.Udayachandr
a D.K.

198

428

Shyama
Sundara B.

Kundapur

N11013/1768/2016NC

Darayya Nairy

Mallikarjun Krupa,
Vidya Nagar Behand
J.C.School Muddebihal
Distt.Bijapur Karnataka586212
Sangameshwar Nagar
Near Revansiddeshwar
High School Muddebihal
Tq.Muddebihal
Distt.Bijapur KarnatakaVeerabhadreshawar
Nilaya Shanti Colony,
Opp.Rural Police Station
Koppal Distt.Karnataka583231
Hura Village & Post
Hullahalli Hobli,
Nanjanagud Taluk
Mysore Distt.Karnataka
Flat No.206, Soundarya
Link Apartments, No.1,
link Road,
Sheshadripuram
Bangalore Karnataka560020
D.No.2-89/1, Rajashree
Behind Karnataka Bank
Derebail Konchady
Mangalore
D.K.Distt.Karanataka575008
Khusi Near
Aghoreshwara Temple,
Chithrapady Village,
Saligrama Post Udupi
Taluk & Distt.Karnataka576225

KAR/2519/
2005
Dt.26.08.05
KAR/3942/
1999
Dt.20.08.99
KAR/488/1
987
Dt.02.07.87
KAR/836/2
006
Dt.17.03.06
KAR/1570/
2007
Dt.27.07.07

KAR/4580/
1999
Dt.01.10.99

KAR/313/1
999
Dt.12.02.99

<!-- page 25 -->

199

429

Kushalappa K.

Dakshina
Kannada Distt.

N11013/1769/2016NC

200

431

Ramakrishna
A.

Dakshina
Kannada Distt.

N11013/1771/2016NC

201

433

Chandrashekh
ar R.Kuri

Athani State
Court

N11013/1773/2016NC

202

434

P.Rajamohan

Civil Court
Gauribidanur

N11013/1774/2016NC

203

437

Prasad.P.Suvar
na

Karkala Taluk
Udupi Distt.

N11013/1777/2016NC

204

438

Ananda
Ramakrishnar
ao.K

Udupi

N11013/1778/2016NC

205

439

Sharitha

Kundapura
Taluk

N11013/1779/2016NC

206

441

Mahendrakum
ar

Gulbarga
Distt.Court

N11013/1781/2016NC

207

443

G.B.Chandra

Mandya Distt.

N11013/1783/2016NC

Room No.2, 1st Floor,
nasik B.H.Bangera Sabha
Lt.Angara
Bhavan, Old Kent Road,
Moolya
Via Police Line, Behind
RTO Mangalore
KarnatakaAmai house Ubaradka
Mithoor Village & Post
A.Honnappa
Sullia Taluk
D.K.Distt.KarnatakaGirish Sadan,Siddeshwar
Rayappa
Colony Kagwad
Basapppa Kuri Tq.Athani, Dist.Belgaum
Karantaka-591223
No.236, 6th Cross,
Bashyam Nagar,
Pooswamy
Srirampura Bangalore
Karnataka-560021
Doolabettu House,
Pervaje, Karkala Kasba
Prakash.V.Suvar
Village, Karkala Taluk
na
Udupi Distt.Karnataka574104
1-54, Paniyadi Post
Lt.Ramakrishna
Kunjibettu Udupi
Rao
Karnataka-576102
Pranathi Nilaya, Beejady
Village, Koteshwara Post,
Lt.Sh.Pandurang
Kundapura Taluk Udupi
a Shettigar
Distt. Karnataka576222
Plot No.55, Bhagyavanti
Veerbhadrappa
Nagar, New Jewargi
Molagi
Road, Gulbarga
Karnataka-585102
No.381, 1st Cross,
Lt.Boraiah
Kuvempunagara
Mandya City Karnataka-

KAR/2942/
2001
Dt.12.10.01
KAR/885/1
989
Dt.20.09.89
KAR/3938/
2005
Dt.09.12.05
KAR/2278/
2007
Dt.24.08.07
KAR/1117/
2002
Dt.12.07.02
KAR/1327/
2003
Dt.14.07.03
KAR/565/2
001
Dt.02.03.01
KAR/580/1
990
Dt.20.07.90
KAR/4592/
1999
Dt.08.10.99

<!-- page 26 -->

Mudalagi &
Gokak Taluk

N11013/1784/2016NC

Prabhu
Yamanappa
Gudaj

208

444

Dayanad
Prabhu Gudaj

209

446

Ravindra
Gowda .K.S.

Mysore Distt.

N11013/1786/2016NC

Lt.K.G.Shanmuk
happa Gowda

210

447

V.M.Byraredd
y

Shidlagatta

N11013/1787/2016NC

Muddappa

211

452

Ashok Kumar
Anvekar

Hubli

N11013/1792/2016NC

Venkataramana

212

453

Gudageri
Manunath

Hubli

N11013/1793/2016NC

Shivappa
Gudageri

213

454

Chidanand
Murigeppa
Sambhoji

Athani

N11013/1794/2016NC

Murigeppa
Shivappa
Sambhoji

Lt.Singaravelu

Lt.Sh.M.Balakris
hnan

214

455

Abiramavalli.S

Bangalore
Urban & Rural

N11013/1795/2016NC

215

456

B.Seshagiri

Bangalore
Met.City Area

N11013/1796/2016NC

H.No.122, Bright Home,
Mallapur.P.G.Ghataprab
ha Taluk Gokak
Distt.Belgaum
Karnataka-591306
No.222, 4th Main 11th
Cross Bank Colony
Bogadi Mysore
Karnataka-570026
Vontoor Village
Bashettahalli hobli &
Post Shidlagatta Taluk
Chikkaballapur Distt.
Karnataka-562105
Yallapur Oni, Kulkarni
Galli, Hubli
Dist.Dharwad
Karnataka-580020
No.46, Akshaya Colony,
1st Phase, Vidyanagar
Hubli Dist.Dharwad
Karnataka-580021
Kumbar Galli, Athani
Ta.Athani Distt.Belgaum
Karnataka-591304
No.210, 2nd C Cross,
Ramaiah Layout,
Kacharakanahalli, St.
Thomas Town Post
Bangalore Karnataka560084
No.9, 1st Cross
Obalreddy Layout,
Ramurthy Nagar Main
Road, Dodda
Banasawadi, Bangalore
Karnataka-560043

KAR/1176/
2000
Dt.28.07.20
00
KAR/359/1
983
Dt.29.06.83
KAR/1372/
2001
Dt.15.06.01
KAR/1011/
1998
Dt.31.07.98
KAR/920/1
998
Dt.24.07.98
KAR/2597/
1999
Dt.23.01.99
KAR/2834/
2000
Dt.10.10.20
00

KAR/285/1
995
Dt.24.02.95

<!-- page 27 -->

216

457

Onkarappa
N.R.

Bangalore

N11013/1797/2016NC

Revappa

217

458

R.Pramila

Bangalore
Met.City Area

N11013/1798/2016NC

Lt.M.Rangaswa
my

218

461

Devika
Kumari A.

Bangalore City
Civil Court &
Other Courts

N11013/1801/2016NC

Sadashiva
Bhat.A.

219

462

C.B.Gangaraja

Bangalore
Courts

N11013/1802/2016NC

Chikkayelappa

220

464

H.M.Gururaja

Tumkur Distt.

N11013/1804/2016NC

H.S.Malleshiah

221

465

Anand
Marthand
Jakanpur

Bijapur

N11013/1805/2016NC

Marthand
G.Jakanur

222

468

Arshad
Ahamed Balur

Hangal Taluk
Distt.Haveri

N11013/1808/2016NC

Mahammed
Swaleha Balur

223

469

Swathi Kiran
M.D.

Dakshina
Kannada Distt.

N11013/1809/2016NC

Dasappa Gowda
M

No.3586/C 1st Cross,
1st Main Gayathri
Nagar, Near Rama
Mandira Bangalore
Karnataka-560021
Shop No.27, 8th Cross,
6th Main Rudra
Muniyappa Road
Sampangirama Nagar
Bangalore Karnataka560027
No.F-5, 1st Floor 5th
Cross Sai Madhura
Swarnima, Venkatadri
Layout
Panduranganagar
KarnatakaBasavanahalli
Nelamangala Taluk
Bangalore Rural
Distt.Karnataka-562123
Basaveshwara Nagar,
Huliyur, Chikkanaykana
Halli Taluk , Tumkur
Distt.Karnataka-572218
T.B.Hospital Quarters
No.3, Near Dist. Civil
Hospital Bijapur
Karnataka-586101
Kumbar Street, At.AkkiAlur Tq.Hangal
Distt.Haveri Karnataka581102
Jayaram K.T. Kayara,
Kavinamoole House
Bellare Post & Village
Sullia Taluk
D.K.Distt.Karnataka574212

KAR/1856/
1995
Dt.08.09.95

KAR/116/1
996
Dt.05.02.96

KAR/1381/
2003
Dt.14.07.03
KAR/901/2
007
Dt.01.06.07
KAR/1265/
1994
Dt.07.10.94
KAR/
KAR/2469/
2001
Dt.07.09.01
KAR/699/2
007
Dt.30.03.07

<!-- page 28 -->

224

472

H.G.Padmanab
ha Rao

Padmanabhana
gar Bangalore

N11013/1812/2016NC

225

474

S.N.Hemalatha

Mysore

N11013/1814/2016NC

226

476

Rajshree S.Patil

Gulbarga

N11013/1816/2016NC

227

477

Nadagouda
Madhulingaraj
Sadashivrao

Lingasugar
Taluka Raichur
Distt.

N11013/1817/2016NC

228

479

Shivarama
Maniyani M

Dakshina
Kannada Distt.

N11013/1819/2016NC

229

482

Gangadhara
K.M.

Dakshina
Kannada Distt.

N11013/1822/2016NC

230

484

Renuka.C

Bangalore

N11013/1824/2016NC

231

487

Veena.G.

Mysore Distt.

N11013/1827/2016NC

Apt. F-2, Rashmi
Enclave, No.61/5, 22
Main, Raghavendra
Lt.H.N.Gururaja
Layout,
Rao
Padmanabhanagar
Bangalore Karnataka560070
# 36, 1st Main Road,
D.Siddaramego
Kumbara Koppal,
wda
Mysore Karnataka570016
H.No.34, Shiva- Shakti
Shvangouda.L.P Nilay Near KEB Counter,
atil
Shanti Nagar Gulbarga
Karntaka-585103
Laxmi Nagar Near Petrol
Sadashivrao
Pump, Raichur Road
Nadagouda
Linga Road Lingasugar
Karnataka-584124
Door No.7-104/3 (3)
Chinmay Dhama Near
Guthu, Kankanady
Lt.Narayan
Mahalingeshwara
Maniyani
Temple, Ujjody,
Kankanady, Mangalore
KarnatakaShantha Nivas Karmar,
Lt.K.R.Mahaling
Padil, Mangalore
a Acharya
D.K.Distt. Karnataka575007
# 211, 5th Main Road,
Hampinagara
Sachidananda.S.
R.P.C.Layout Bangalore
Karnataka-560104
# 101, MIG-1, 1st Cors,
Group-IV,
Mahesha.J.
K.H.B.Hootagalli, Mysore
Karntaka-570018

KAR/981/2
001
Dt.12.04.01

KAR/3828/
1999
Dt.13.08.99
KAR/824/1
984
Dt.12.12.84
KAR/4806/
1999
Dt.19.11.99

KAR/622/1
998
Dt.29.05.98

KAR/782/1
995
Dt.07.04.95
KAR/739/1
997
Dt.14.11.97
KAR/1413/
2001
Dt.22.06.01

<!-- page 29 -->

488

Mahabala
Shetty K.

Dakshina
Kannada Distt.

N11013/1828/2016NC

233

489

Sowmini
Unnkikrishna
n

Lalbaugh Road,
Sudhama Nagar
J.C. Road &
Sorrounding
Areas

N11013/1829/2016NC

Unnikrishnan

234

490

Vinodhara
Poojary

Dakshina
Kannada Distt.

N11013/1830/2016NC

Lt.Somayya
Poojary

235

494

Bharathi.A.

Dakshina
Kannada Distt.

N11013/1834/2016NC

Annu Poojary

236

495

B.Hanumantha
raju

Nelamangala
Bangalore Rural
Distt.

N11013/1835/2016NC

Bylanjanappa

237

496

Sangamesh
Houde

Vijaypur Taluk
& Distt.

N11013/1836/2016NC

Shivalingappa
Houde

238

497

Tamlin Rani

Chamarnagar
Distt.

N11013/1837/2016NC

S.Basavanna

239

498

V.K.Swarupa

Mandya Distt.

N11013/1838/2016NC

A.S.Venkatesh

232

Vishwanatha
Shetty K.B.

Opp.Traffic Police
Station Main Road,
Puttur
D.K.Distt.KarnatakaNo.46/1, 1st Cross,
Marappa Garden,
Benson Town Post,
Bangalore Karntaka560046
Archana Kripa, Thallada
Bail Kolambe Post &
Village Mangalore Taluk
D.K.Distt.Karnataka574142
Thota House Padnoor
Village Padnoor Post
Puttur Taluk D.K.Distt.
Karnataka-574201
Kengal Kempohalli
Billanakote Post,
Sompura Hobli,
Nelamangala Taluk
Bangalore Rural Distt.
Karnataka-562111
At.Post Gacchinkatti
Colony, Blde Road,
Vijaypur, Distt. Vijaypur
Karnataka-586103
D.No.66, Mangala
Nilaya, Behind
Varthakar Bhavan, Pillai
layout, Chamarnagar
Distt.Karnataka-571313
Door No.101, 5th Ward,
Subhash Nagar, K.R.Pet
Town, K.R.Pet Taluk,
Mandya
Distt.Karnataka-571426

KAR/4266/
2006
Dt.22.12.06
KAR/3854/
1999
Dt.20.08.99
KAR/1719/
2003
Dt.08.08.03
KAR/1038/
20069
Dt.07.04.06
KAR/892/1
999
Dt.25.03.99
KAR/370/2
003
Dt.28.02.03
KAR/724/1
995
Dt.24.03.95
KAR/1661/
2001
Dt.21.07.01

<!-- page 30 -->

240

499

Rajanna.S.M.

Bengaluru Distt.

N11013/1839/2016NC

Lt.Muniswamy

N11013/1840/2016NC

Lt.S.Batyappa
Gowda

241

500

Ambika.S.

Mathikere of
Yeshwanthpur
Jurisdiction
Bangalore Distt.

242

501

Siva
Kumara.M.N.

Bengaluru
Met.City Area

N11013/1841/2016NC

Nandeeshwarap
pa.B.P.

243

502

Narasimha
Bhat.K

D.K.Distt.

N11013/1842/2016NC

Lt.K.Venkatram
ana Bhat

244

504

Surendra D.S.

Mudigere
Chikmagalur
Distt.

N11013/1844/2016NC

D.Some Gowda

245

505

Tanvashi
Shidaray
Paragonda

JMFC Athani

N11013/1845/2016NC

Tanvashi
Paragonda
Shivamurti

N11013/1848/2016NC

U.M.Kunhi

246

508

Zahid Hussain

Dakshina
Kannada Distt.

247

509

A.Krishna

Bangalore

N11013/1849/2016NC

A.Rosaiah

248

510

Biradar
Vijayalaxmi
Ramango

Vijayapur Distt.

N11013/1850/2016NC

Sanjeev Mane

Sai Nilaya, # 13/16, 3rd
Main Road, Muniyappa
Garden layout,
K.R.Puram, Bengaluru
Karnataka-560036
No.234/51, 6th Main
4th Cross, Gokula,
Bangalore Karnataka560054
No.18, Ground Floor 7th
Main KHM Block
Ganganagar R.T.Nagar
Post Bengaluru
Karnataka-560021
Kaje House Manchi Post,
Banteal Taluk
Karnataka-574323
Nischith Nilaya
Mahanthina Mutt Road,
Megalapet Mudigere
Chikmagalur
Distt.Karnataka-577132
Sadashiv Krupa Building
Vikrampur, Athani
Distt.Belagavi
Karnataka-591304
2nd Floor, Pioneer
Complex, Nellikai Road,
Mangalore KarnatakaNo.17,1 & 3rd Block
East, KHB of Jamnagar
Bangalore Karnataka560011
C/o.S.K.Dyavanal,
Opp.Raghavendra Math,
Near New Distt.Court
Bagalkot Road,
Vijayapur Karnataka586109

KAR/120/1
984
Dt.14.03.84
KAR/516/1
999
Dt.13.03.99
KAR/739/1
985
Dt.07.12.85
KAR/850/1
989
Dt.13.09.89
KAR/127/1
992
Dt.31.01.92
KAR/2227/
1999
Dt.12.04.99
KAR/1171/
2007
Dt.15.06.07
KAR/2147/
1995
Dt.18.11.95
KAR/1294/
2008
Dt.11.07.08

<!-- page 31 -->

511

Rajshekhar
S.Shilpi

Jewargi

N11013/1851/2016NC

250

513

Suresh
Karkera Ullal

Dakshina
Kannada Distt.

N11013/1853/2016NC

251

514

D.A.Anil
lakshmi
Narayan

Bangalore

N11013/1854/2016NC

252

515

Harisha G.

Bangalore
Met.Area

N11013/1855/2016NC

253

516

Sanjeeva
Siddappa
Naganuri

Belagavi Distt.

N11013/1856/2016NC

254

517

Kishwar
Hussain M.S.

Bangalore City
& Distt.

N11013/1857/2016NC

255

521

C.Sasikala

Bangalore
Met.Area

N11013/1861/2016NC

249

256

522

K.Pradeep
Kumar Shetty

Kundapura
Taluk Udupi

N11013/1862/2016NC

257

523

Vidyalaxmi

Udupi Taluk

N11013/1863/2016NC

Lumbini Niwas, Butnal,
Shankreppa
Post Kattisangavi Tq.
Shilpi
Jewargi Dist.Gulbarga
Karnataka-585310
Flat No.C-3, 3rd Floor
Vaishali Apartment, 5th
Sanjeeva
Cross, Gandhi Nagar
Suvarna
Mannagudda Mangalore
Karnataka-575003
C-23, 19th Cross, 7th
Main Opp.to Church
Arasappa
BTH 2nd Stage,
Bangalore Karnataka560076
No.58, 1st Main 2nd
Cross, Raghava Nagar
Lt.Giri Gowda
NTY Layout, Mysore
Road Bangalore
Karnataka-560026
Near Laxmi Temple,
Siddappa
Shiragaon Tq. Hukkeri
Kadappa
Distt.Belagavi
Naganuri
Karnataka-591309
No.31/1, Cockburn
Subhan Saheb
Road, Bangalore
Karnataka-560051
No.2/2 Sreerama Nilaya,
Justice Bheemaiah layout
Subramani.V
Diesel Shed Road
K.R.Puram Bangalore
Karnataka-560036
Shivani Salvady Post
Kalavara village
K.Rajeeva Shetty
Kundapura Taluk Udupi
Distt.Karnataka
Ashrith Kajaraguthu
Anjar Village Hiriadka
Eshwar Suvarna
Post Udupi Taluk & Distt.
Karnataka

KAR/2683/
2007
Dt.31.08.07
KAR/691/1
985
Dt.22.08.85
KAR/174/2
005
Dt.04.02.05
KAR/1501/
2004
Dt.16.07.04
KAR/1576/
2000
Dt.11.08.20
00
KAR/215/1
992
Dt.14.02.92
KAR/4260A/2006
Dt.21.12.06
KAR/1178/
2000
Dt.28.07.20
00
KAR/2515/
2007
Dt.24.08.07

<!-- page 32 -->

258

525

H.J.Vijayalak
Shmamma

Tumkur

N11013/1865/2016NC

259

526

Mahagundapp
a. Danappa
Kiragi

Bagalkot Distt.

N11013/1866/2016NC

260

528

Rupesh Kumar
N.

Mathikere

N11013/1868/2016NC

261

529

Ramanna
Gowda B.

Dakshina
Kannada Distt.

N11013/1869/2016NC

262

532

M.Deepa

Begaluru Distt.

N11013/1872/2016NC

263

533

Chandrakala

Begaluru Distt.

N11013/1873/2016NC

Shimoga Distt.

N11013/1877/2016NC

Bengaluru

N11013/1879/2016NC

264

265

537

B.K.Narayana

539

Vani.G.K

266

540

Mallikarjunay
ya
M.Hiremath

Gadag

267

541

Shailaja

Belgaum
Revenue Taluka

N11013/1880/2016NC
N11013/1881/2016NC

Anugraha Valmiki
Nagara 6th Cross
Kemparaju S.D.
Tumkur Karnataka572103
H.No.225 Killaoni Kerur,
Danappa.Gunda
Taluk Badami Distt.
ppa Kiragi
Bagalkot Distt.
Karnataka-5872006
# 23, Shiva Krupa Near
M.S.R. College
Nagaraja.K.
Mathikere Bangalore
Karntaka-560054
II nd Floor, Laxshmi
Complex, Main Road
Yelyanna
Uppinangady Puttur
Gowda
Taluk D.K.Distt.
Karnataka-574241
# 198/A, I Main,
nandini Nilaya II Floor
M.Mallikarjuna
Bapuji Nagar, Mysuru
Road Bengaluru
Karnataka-560026
No.293, 6th Cross
Indiranagar Rajajinagar
P.Hanumaiah
West of Chord Road,
Bengaluru Karntaka560010
Bommanakatte muncipal
Ward No.1,
C.S.Krishnamurt
Vinobanagara Post,
hy
Shimoga City/
Distt.karnataka-577204
No.23 F-2, 4th Model
G.S.Keshava
House Street
Murthy
Basavanagudi Bengaluru
Karnataka-560004
Marulayya
Irappa
Ningappa
Tigadi

KAR/478/1
998
Dt.20.03.98
KAR/2112/
2004
Dt.13.08.04
KAR/1174/
2006
Dt.21.04.06
KAR/2239/
2006
Dt.11.08.06
KAR/1273/
2005
Dt.01.07.05
KAR/1832/
2007
Dt.10.08.07
KAR/345/2
000
Dt.12.02.20
00

KAR/2573/
2000
Dt.30.09.20
00
KAR/13/19
Okkalegeri Gadag
90
karnataka-582101
Dt.06.01.90
H.No.LIG 78, Mahantesh KAR/73/19
Nagar, Belgaum
93
Karnataka-590016
Dt.22.01.93

<!-- page 33 -->

N11013/1882/2016NC

U.Nonayya
Amin

268

542

Manjula N.A.

Dakshina
Kannada Distt.

269

543

Chingappa.O.S
.

Distt.& Session
Judge Madikere

N11013/1883/2016NC

Subbaiah.O.G

270

544

Shanthi Prasad
Jain

Shimoga Distt
Court

N11013/1884/2016NC

Dharmapal Jain

271

546

Prasad.Shetty.
K.B

Bangalore

N11013/1886/2016NC

K.Balakrishna
Shetty

272

551

K.S.Manjula

Mysore Distt.

N11013/1891/2016NC

Sidde Gowda

273

554

Maranabasari
Shreekanth
Basavraju

Ron

N11013/1894/2016NC

Maranabasari
Basavraj

274

558

Balakrishna
Shetty K

Kundapur

N11013/1898/2016NC

Thejappa Shetty

275

559

Archana B.K.

Dakshina
Kannada Distt.

N11013/1899/2016NC

Dayananda
Gowda T.

276

562

Kenchappa

Bangalore
Met.Area

N11013/1902/2016NC

Nanjappa

Bhramarambika Urwa
Kampa Mangalore
Karnataka-575006
Vigneshwara karthik
Road Subramanyanagar
Modikeri Kodagu
Distt.Karnataka-571201
C/o Vardhaman
Vidyarthi Nilaya 5th
Parallel Road, JPN Road
Near Ganesh Temple,
Durgigudi Shimoga
Karnataka-577201
No.5/7, Anna Swamy
Mudliear Road,
Bangalore Karnataka560047
# 22, Kanchanahalli
Village, Bannur Post
Sosale Hobli,
T.Narasipura Taluk
Mysore Distt.KarnatakaAt.Post Sudi,Tq.Ron
Distt.Gadag Karnataka582211
Kangibettu House
Kaluvalli Post & Village
Udupi Taluk &
Distt.Karnataka-576215
Puttur Centre Building
1st Floor Taluk Office
Road Puttur
D.K.Distt.Karnataka574201
No.181, 1st Main
(Nanjundeshwara Flour
Mill Road)
Bhavaninagara
Chennanayakanapalya
Nagasandra (P)
Bangalore Karnataka560073

KAR/1919/
1995
Dt.15.09.95
KAR/3861/
2003
Dt.19.12.03
KAR/1194/
1999
Dt.26.09.99
KAR/981/1
992
Dt.04.09.92
KAR/694/2
001
Dt.16.03.01
KAR/2340/
2003
Dt.29.08.03
KAR/2361/
1999
Dt.13.04.99
KAR/3223/
2006
Dt.15.09.06

KAR/1548/
1999
Dt.01.04.99

<!-- page 34 -->

277

564

Akshaya
Thukaram Rao

Dakshina
Kannada Distt.

N11013/1904/2016NC

278

566

Mrs.Vrishali
Purnapradna
Kulkarni

Belgaum Distt.

N11013/1906/2016NC

279

567

Smt.Rekha
D.Hegde

Karkala

N11013/1907/2016NC

280

569

A.Manjunatha

Bangalore

N11013/1909/2016NC

281

570

Mahamadmub
arak Shirahatti

Mudhol Taluka
Distt.Bagalkot

N11013/1910/2016NC

575

Dilshad
Begum

Distt.& Session
Judge Bengalur

N11013/1915/2016NC

Asharani
Mada

Gurupara
Kaikamba
Kinnikambla
Dakshina
Kannada Distt.

N11013/1917/2016NC

Dakshina
Kannada Distt.

N11013/1918/2016NC

282

283

284

577

578

Deepika

Laxmi Kripa Opp.Bus
Stand Belthangady
H.Thukaram
Kasaba & Village
Rao
Belthanfady Tq
D.K.Distt.Karantaka222/C2, Sh.Ganesh
Purnapradna
Building Near II Railway
Ranjan Kulkarni Gate Tilakwadi Belgaum
Karnataka-590006
Sumadeepa Attur
Church Road Karkala
Lt.Dinesh Hegde
Kasaba Village Karkala
Karnataka-574104
924, 28th Main 9th
Lt.A.S.Venkataja
Block Jayanagar
yappa
Bangalore Karantaka560069
A.P.M.C.Road, Behind
SBI Bank, At.Post
Davalmaliksahe
Mahalingpur Tq.Mudhol
b Shirahatti
Distt.Bagalkot
Karnataka-587312
No.104, LIG No.2,
Building no.9,
Suryanagar,
Abdul Rasool
K.H.B.Chandapur
Bangalore Karnataka560081

KAR/244/2
005
Dt.04.02.05

KAR/
KAR/211/1
994
Dt.05.02.94
KAR/630/1
998
Dt.13.03.98
KAR/552/1
992
Dt.11.07.92

KAR/220/2
006
Dt.27.01.06

Ananad Naik

Ram B.R.Lane Gurupura
KAR/1742/
Kaikmaba Kinnikambla
1998
Post Mangalore
Dt.27.11.98
Karnataka-574151

Umesh S.Shetty

D.No.8-8/4 (6) Udipana
Lord Krishna Estate,
KAR/480/2
Katla Cross Road
006
Surathkal Mangaluru
Dt.18.02.06
Karnataka-575014

<!-- page 35 -->

285

582

Y.V.Shankar

Kanakanagara

N11013/1922/2016NC

286

584

Geetha.S.

Mysore Distt.

N11013/1924/2016NC

588

Mrs.Vyshali.K.

Bengaluru Distt.

N11013/1928/2016NC

288

593

Ms.G.R.Bhava
ni

Bangalore
Urban & Rural
Distt.Area

N11013/1933/2016NC

289

594

A.M.Balaji

Bangalore

N11013/1934/2016NC

290

595

Malaveeka.P.N

Dakshina
Kannada Distt.

N11013/1935/2016NC

291

596

Sreedevi.S

Chinthamani

N11013/1936/2016NC

287

# 28, Rudramma Nilaya
3td Floor, 13th Cross,
Y.R.Venkataram
Kanakanagara,
na Reddy
R.T.Nagar Post Bangalore
Karnataka-560032
# 128, Arepura Village,
Thodavadi Post,
Sannaiah
Gundlupet Tq.,
Chamarajanagar
Distt.Karnataka-571111
No.16, Lakshmi Ranga
2nd D Cross Ramaiah
L.Ravindra
Layout Kacharakana
Halli Bengaluru
Karnataka-560084
No.19, Amruth Mahal
1st Cross, 1st Main
Lt.G.N.Ramaiah M.L.A.Layout R.T.Nagar
Bangalore Karnataka560032
No.169, 6th Cross,
Chikkaramaiah Layout
Vanasi @
Jinkethimmanahalli
A.R.Manjunath
Near Indane Gas
Gowdown Vanasi Main
Road K.R.Pura Bangalore
Karnataka-560036
H.No.1, Fern Alpha 1
Appartment, Near I Gate,
Manjunath.S.S
7th Corss Jakkasandra
Koramangala Bangalore
Karnataka-560034
Kagathi Village & Post
Chintamani
Seenappa
Tq.Chickballapur
Karnataka-563125

KAR/3096/
2005
Dt.23.09.05
KAR/400/2
007
Dt.09.03.07
KAR/85/19
96
Dt.02.02.96
KAR/53/19
96
Dt.02.02.96

KAR/2743/
2003
Dt.12.09.03

KAR/1015/
2006
Dt.07.04.06
KAR/4089/
2006
Dt.01.12.06

<!-- page 36 -->

292

597

Sanjeev Kumar

Kalaburagi

N11013/1937/2016NC

Shantappa Jog

293

599

Ravi
Ranganath Rao
Saraf

Kalaburagi

N11013/1939/2016NC

Ranganath Rao
Saraf

H.Basavaiah

294

601

Sudha .H.B.

Bangalore

N11013/1941/2016NC

295

603

Suresh
Laxman Kalal

Distt.Court
Bijapur City

N11013/1943/2016NC

Laxman
Annappa Kalal

296

604

P.I.Abdul
Rahman

Dakshina
Kannada Distt.

N11013/1944/2016NC

Hajee Ismail.P

297

608

Nayak Sanjay
Ramchandra

Ankola Uttara
Kannada Distt.

N11013/1948/2016NC

Nayak
Ramchandra
Vasudev

298

610

Vinoda

Bantwal,
Dakshina
Kannada Distt.

N11013/1950/2016NC

Parameshwara
Madivala

299

611

Ms.K.Gayathri

Mysore Distt.

N11013/1951/2016NC

Lt.Kalaiah

H.No.1-891/89/4-B/18
Vardha Nagar Behind
Sun International Hotel,
New Jewargi Road
Kalaburagi Karantaka585102
H.No.1-891/30/12/1,
Manik Nilay Srinagar
Colony Jewargi Road,
Behind Chittari Saw
Millm Kalaburagi
Karnataka-585102
No.302, 7th Main
Sapathagir Residencial
Appartment-IV
Kathrigupe Kathrigupe
Bangalore Karnataka560085
Kanakdas Bad wane 2nd
Stage Rambapur Near
Telephone Exchange
Office H.No.76, Bijapur
Karnataka-586101
Door No.21-7, Aladka
Po.Panemangalore
Bantwal Taluk
D.K.Distt.KarnatakaAt. Soorve Po.Basgod
Ankola Uttara Kannada
Distt. Karnataka581314
Vridhi Nivas, Ajekala
House Amtady Village &
Bantwal Post Bantwal
Taluk
D.K.Distt.Karnataka574211
# 23, 19th Cross, 1st
Main Pampapathi Road
Jayanagar Mysore
Karnataka-14

KAR/1701/
2006
Dt.07.08.06

KAR/804/1
998
Dt.11.07.98

KAR/1636/
1998
Dt.06.11.98

KAR/704/1
993
Dt.24.07.93
KAR/300/1
989
Dt.08.03.89
KAR/3656/
2004
Dt.03.12.04
KAR/4384/
1999
Dt.14.09.99
KAR/1627/
2005
Dt.29.07.05

<!-- page 37 -->

300

613

Mahabala
Gowda.A

Dakshina
Kannada Distt.

N11013/1953/2016NC

301

614

Manjunatha
N.S.

Dakshina
Kannada Distt.

N11013/1954/2016NC

302

617

Ms.Pushpa
Vathi.B.S.

Bengaluru &
Anekal Taluk

N11013/1957/2016NC

303

618

Ms.Veeka.K.

Bangalore

N11013/1958/2016NC

304

623

K.Mallikarjun
appa

Chitradurga
Distt.

N11013/1963/2016NC

305

624

Lokesh.M

Kalidasa Layout
Bangalore

N11013/1964/2016NC

306

626

Mrs.Akshhath
a Adarssh

Dakshina
Kannada Distt.

N11013/1966/2016NC

Moodbidri

N11013/1967/2016NC

307

627

Ranjan.N.

Addali House, Vittal
Kasba Village, Mangilal
Giriyappa
Padavu Post Bantwal
Gowda
Taluk Dakshina Kannada
Distt.karnataka-574243
Uppalige House,
Bettampady Village &
N.Suba Naik
Post Puttur Taluk
D.K.Distt.Karnataka574259
No.263, VIP Street
R.Krishna
Gottigere Bannerughatta
Murthy
Road Bengaluru
Karnataka-560083
Hasuruvani # 187-5-1,
14th Cross, Vyalikaval
K.Shrikrishna
bangalore Karnataka560003
Mahadimane Nilaya,
Mahalakshmi Extn,
Behind Civil Judge &
M.E.Karisidappa
JMFC Court Hosadurga
Chirtadurga
Distt.Karnataka-577527
# 57/35, Shivaparvathi
Nilaya 3rd Cross, Kalidas
Mohan Raju
Layout Sri Nagar
Bangalore Karnataka560050
Falicity 2nd Apartment
Door No.705, Bejai New
Adarsh M
Road Mangalore
Karnataka-575004
Hema Chandra House
Near Badaga Basodi
Marpady Village
Chandrashekha
Mudbidri Hobli
r.N
Mangalore Taluka
D.K.Distt.Karnataka574227

KAR/1238/
2003
Dt.04.07.03
KAR/2390/
2002
Dt.25.10.02
KAR/757/1
986
Dt.16.10.86
KAR/2020/
2004
Dt.06.08.04
KAR/564/1
999
Dt.22.03.99

KAR/2243/
2007
Dt.17.08.07
KAR/2249/
2008
Dt.22.08.08
KAR/344/2
000
Dt.11.02.20
00

<!-- page 38 -->

308

629

G.Ramesh

Mysuru Distt.

N11013/1969/2016NC

L.Ganagdhar

309

630

G.M.Shivapras
ad

Mysuru Distt.

N11013/1970/2016NC

Mahadevu

310

632

Chandrashekh
ar.M.

Bengaluru Distt.

N11013/1972/2016NC

Muniyappa.G.

311

635

Hosarayappan
avar Rayappa

Hirekerur Taluk

N11013/1975/2016NC

Padmappa

312

636

Ms.Aruna.V.

Bengaluru Distt.

N11013/1976/2016NC

Mohan.S.

N11013/1978/2016NC

B.Mohammed
Iqbal Hussain

313

638

Asifa Banu

Davanagere
Distt.Court

314

639

Ravikumar
Allundi

Devadurga
Taluka Raichur
Distt.

N11013/1979/2016NC

Ranganna Patil
Allundi

315

645

Ms.Malathi.U

Kawasa of
Mudigere Tq.

N11013/1985/2016NC

U.T.Venkat Rao

8th Cross, R.P.Road,
Srikantapuri Extension,
Nanjangud Town,
Mysuru Distt.
Karnataka-571301
# 2583, Omkara Nilaya,
3rd Cross, R.P.Road,
Nanjangud Town,
Mysuru
Distt.Karanataka571301
No.35/1, 2nd Cross,
A.K.Colony, Near Sri
Mallikarjun High
School, D.J.Halli, Frazer
Town Post, Bengaluru
Karnataka-560005
Vidya Nagar Hirekerur
Tq.Hirekerur
Distt.Haveri Karantaka581111
No.81, 18th Cross, 1st
Block Rajajinagar
Bengaluru Karnataka560010
# 3993/33, 20th Main,
Khan Manzil, Kuvempu
Nagar MCC B Block
Davanagere Karnataka577004
H.No.1-2-63, Ravi
Nilaya, Patil Street,
Devadurga Distt.Raichur
Karnataka-584111
Hosathota K.Kelaguru
Village Kalasa Mudigere
Taluku Chikkamagaluru
Distt.Karantaka-577179

KAR/519/2
001
Dt.02.03.01

KAR/1728/
2004
Dt.23.07.04

KAR/1096/
2007
Dt.08.06.07
KAR/3132/
2006
Dt.13.09.06
KAR/383/1
995
Dt.24.02.95
KAR/1959/
1995
Dt.22.09.95
KAR/1965/
2006
Dt.28.07.06
KAR/979/1
994
Dt.12.08.94

<!-- page 39 -->

316

646

Ravi.S

Bangalore
Met.Area

N11013/1986/2016NC

Subramani.G.

317

647

Ms.C.Sharada

Bangalore City

N11013/1987/2016NC

K.N.Keerthy

H.G.Lokesh

Shivamogga

N11013/1988/2016NC

Lt.H.G.Govinda
ppa

649

Ms. Mala.D

Bangalore
Met.Area

N11013/1989/2016NC

Dharma Naik

320

650

Ms.Lekhashree
.B

Dakshina
Kannnada Distt.

N11013/1990/2016NC

Dugganna
Gowda.K

321

651

Ms.Dhanavant
hi

Dakshina
Kannnada Distt.

N11013/1991/2016NC

Jaya Melanta

322

653

Ms.Shashirekh
a.V

Mysore Distt.

N11013/1993/2016NC

G.Mahadeva
Swamy

323

654

Ramesh

Lingasugar
Distt.Raichur

N11013/1994/2016NC

Saranayak

318

319

648

No.792, Sri
Venkateshwara Nilaya,
9th B Cross Triveni Road
Yeshwanthapura
Bangalore Karnataka560022
3C-727, 8th Main,
HRBR Layout, 1st Block
Kalyannagar Bangalore
Karnataka-560043
Sree Gayathri Nivasa,
Nisarga Layout, by-Pass
Road Vidya Nagar Post
Shivamogga Karnataka577203
Flat No.J-235, J-Block,
Brigade Court Yard
Apartment, HMT Factory
Main Road Jalahalli
Karnataka-560013
Near K.H.B.Colony,
Samethadka House
Puttur Post, Puttur
Kasaba Puttur Taluk
D.K.Karnataka
Shetty Mahal Kailash
nagar House
Someshwara Village
Kotekar Post, Mangalore
Taluk Dakshina Kannada
Distt.Karnataka-5
No.74, EWS, 2nd Cross,
Beside Church E & F
Block Ramakrishanagara
Mysore KarnatakaNear Kalasadagudi
At.Post Gurgunta
Tq.Lingasugar
Distt.Raichur Karnataka584139

KAR/3439/
2003
Dt.07.11.03
KAR/457/1
992
Dt.20.06.92
KAR/207/19
96
Dt.16.02.96
KAR/3931/
2007
Dt.16.11.07
KAR/2963/
2004
Dt.03.09.04

KAR/1970/
2008
Dt.08.08.08
KAR/2562/
2001
Dt.07.09.01
KAR/1201/
2006
Dt.05.05.06

<!-- page 40 -->

Bellary

N11013/1996/2016NC

657

Ayoub
Bagalkot

Vijayapur

N11013/1997/2016NC

Mahiboobsab

326

660

Ramesh
D.Shah

Mayohalli
Bangalore

N11013/2000/2016NC

Y.Devidas

327

662

Sadanand Bhat

Sirsi

N11013/2002/2016NC

Raghupati

328

664

Santhosh
Kumar S.S.

Narasimharajap
ura

N11013/2004/2016NC

Shivanna S.S

329

665

Netramurthy
MN

Bangalore
North

N11013/2005/2016NC

NEELAKANTAC
HAR M V

324

656

B.K.Prasanna

325

Lt.B.K.Narayana
Sastry

Bhagya Nilaya House
No.28 Anthapur Colony
3rd Link Road S N Pet
2nd Cross Ballari
Karnataka-583101
A.M.Bagalkot Gulam
Husain Street, Vijayapur
Karnataka-586101
No.3, 3rd Cross
Ashirwad Atmanand
Colony Sultanpalya
R.T.Nagar Post
Bangalore Karnataka560032
Nidgod Post Targod Sirsi
Uttar Kannada
Karnataka-581402
Behind Junior College
Betagere
Narasimharajapura
Chikamagalur
Karnataka-577134
NO
12.CHAMARAJESHWAR
A NIVASA KATERAMMA
TEMPLE STREET.FIRST
BLOCK
DODDABOMMASANDR
A.VIDYARANYAPURA
POST Bangalore urban
Karnataka-560097

KAR/1092/
1995
Dt.30.06.95
KAR/2168/
1995
Dt.25.11.95
KAR/340/1
986
Dt.28.05.86
KAR/742/1
998
Dt.03.07.98
KAR/1738/
1998
Dt.28.11.98

KAR/714/1
991
Dt.17.08.91
