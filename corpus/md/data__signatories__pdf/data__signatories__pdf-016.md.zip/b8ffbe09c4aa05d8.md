---
doc_id: "b8ffbe09c4aa05d8"
source_url: "https://powermin.gov.in/static/uploads/2025/06/07d962c68a7ed527a908e578bd8b1bd9.pdf"
ministry: "Power"
title: "tender 19"
date: "2015-03-27"
pages: 44
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cfa8a16e8b00da21"
---

<!-- page 1 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

e-BID RLNG SALES AGREEMENT (eRSA)
BETWEEN

GAIL (INDIA) LIMITED
(AS SELLER)

AND

[●]
(AS BUYER)

FOR SALE OF e-BID RLNG
Date: [●]

Page 1 of 44

<!-- page 2 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

e-BID RLNG SALES AGREEMENT
This e-Bid RLNG Sale Agreement (eRSA) hereinafter referred to as the “Agreement” is made on [●] at
[●] by and between:
GAIL (INDIA) LIMITED, (GAIL) formerly known as Gas Authority of India Limited, a Government
Company incorporated under the Companies Act, 1956 having its Registered Office at 16, Bhikaiji Cama
Place, New Delhi – 110 066, (hereinafter called “Seller” which expression shall include its successors or
permitted assigns) of the one part.
AND

[●] a company/firm/proprietary concern/Society constituted under the Companies Act, 1956
/Partnership Act/ Societies Registration Act/Cooperative Societies Act/ Statute having its Registered
Office at [●] in the state of [●] hereinafter called “Buyer” which expression shall include its
successors, legal representatives or permitted assigns) of the other part
Each of the above, also individually referred to as the ‘Party’ and collectively referred to as the ‘Parties’.
WHEREAS:
A.

Ministry of Power, Government of India, vide Office Memorandum No. 4/2/2015-Th-I dated
27.03.2015 has notified the scheme for utilization of Gas based power generation capacity
for the years 2015-16 and 2016-17 (“Scheme”).

B.

The Seller is a Government Company primarily engaged in the distribution and marketing of
gas in India and is also engaged in other aspects of gas value chain including exploration,
production, transmission, extraction, processing of natural gas and its related process,
products and services;

C.

The Buyer is primarily engaged in the business of generation of electricity / power.

D.

The Parties wish to enter into this Agreement to record the terms and conditions on which
the Seller shall sell and deliver at the Delivery Point, and the Buyer shall purchase the e-Bid
RLNG.

NOW, THEREFORE, IN CONSIDERATION OF THE MUTUAL COVENANTS HEREIN, THE PARTIES AGREE TO
THE FOLLOWING:

Page 2 of 44

<!-- page 3 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ARTICLE 1 - DEFINITION AND INTERPRETATION
1.1

Definitions
In this Agreement, unless the context otherwise requires, the following terms and expressions
shall have the meanings assigned to them herein:“Affiliates”
with respect to any Person shall mean any other Person which,
directly or indirectly: (1) Controls such Person; or (2) is controlled by
such Person; or (3) is Controlled by the same Person who, directly or
indirectly, Controls such Person; or (4) is an associate company of
such Person. In such context, "associate company", in relation to
another company, means a company in which that other company has
a significant influence, but which is not a subsidiary company of the
company having such influence and includes a joint venture company.
For the purposes of this definition, "significant influence" means
control of at least twenty per cent of total share capital, or of business
decisions under an agreement.
“Agreement”

means this Agreement as may be amended from time to time,
including the Recitals and Annexures.

“Billing
and has the meaning ascribed thereto in Article 9 of this Agreement.
Payment”
“BTU
or
British means “the quantity of heat required to raise the temperature of one
Thermal Unit”
(1) pound of pure water from fifty-nine (59) degrees Fahrenheit to
sixty degrees Fahrenheit (60 degrees F) at an absolute pressure of
fourteen point six nine six (14.696) pounds per square inch”.
“Business Day”

shall mean the days on which banks are open for business in the state
where Delivery Point is located.

“Buyer’s Facilities”

means all plant, machinery, pipelines and other equipment from the
downstream of measurement facility in Buyer’s plant premises.

“Contract Quantity”

means the total quantity of e-Bid RLNG as specified in the eSPN.

“Daily
Contract means the daily quantity of e-Bid RLNG as specified in the eSPN.
Quantity” or “DCQ”
“Day”
means a period of 24 consecutive hours beginning at 0600 hours on
each day and ending at 0600 hours on the following day at the
Delivery Point and the date of any day shall be the date at its
beginning as here defined, and the term Daily shall mean from day to
day.
“Delivery Point”

means the downstream flange at the outlet of the Seller’s metering
station located at ……….., as described in Annexure-2.

“Due Date”

has the meaning ascribed thereto in Article 9.2.

“e-Bid RLNG”

means Liquefied Natural Gas imported by Seller and re-gasified at
regasification terminal(s) for supply to the Buyer.
means e-Bid RLNG Sales and Purchase Notice entered into between

“eSPN”

Page 3 of 44

<!-- page 4 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

the Seller and the Buyer in the format set out in Annexure 5 of this
Agreement.
“Force Majeure”

has the meaning ascribed thereto in Article 13.1.

“Fortnight”

means a period commencing at 0600 hours on first day of month and
ending on 0600 hours on sixteenth day of the month and from
0600 hours on sixteenth day of the month to 0600 hours on the first
day of the succeeding calendar month.

“Gas” or “Natural Gas or Natural Gas means any hydrocarbon or mixture of
Gas”
hydrocarbons consisting essentially of methane, other hydrocarbons
and non-combustible gases in a gaseous state.
“GHV
or
Gross shall mean the quantity of heat, expressed and measured in Kcal or
Heating Value”
MMBTU, produced by the complete combustion at constant pressure
of one (1) Standard Cubic meter of anhydrous Gas, with the air at the
same temperature and pressure as the Gas, after cooling the products
of the combustion to the initial temperature and condensation of the
water formed by combustion.
“GOI”

means Government of India.

“Government
Agency”

means the Government of India and/or the State Government(s), or
any regional or municipal authority thereof, or other central, state or
local government or any legislature, ministry, department,
commission, board, authority, instrumentality, agency, political
subdivision, corporation or commission under the direct or indirect
control of the GOI and/or the State Government(s) or any political
subdivision of either of them owned or controlled by the GOI and/or
the State Government(s) or any of their subdivisions.

“Highest Priced Gas”

means the price of Gas as notified by the Seller in terms of Article 6.6
of this agreement.

“LC”

has the meaning ascribed thereto in Article 9.5 of this Agreement.

“Liquidated
Damages”
“MMBTU”

has the meaning ascribed thereto in Article 6.3 of this Agreement.

“MMSCMD”

means million metric standard cubic meter per day.

“Office
Memorandum”

means Office Memorandum No.4/2/2015-Th-I dated 27th March 2015
issued by Ministry of Power, Government of India, for the Scheme i.e.
the scheme for utilisation of Gas based power generation capacity for
the financial years (April-March) 2015-16 and 2016-17.

“Parties”
“Party”

means the parties to this Agreement and their successors and
permitted assigns and “Party” means any one of them.

“Payment

means the statement referred to in Article 9.1.

means million BTU.

Page 4 of 44

<!-- page 5 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Statement”
“Invoice”
“PNDCQ”

Confidential

or
has the meaning as in Article 6.5.

“PNGRB”

means Petroleum and Natural Gas Regulatory Board.

“Price”

means the price payable by the Buyer for e-Bid RLNG calculated from
time to time in accordance with Article 8 and determined in
accordance with this Agreement.

“RGTIL”

means Reliance Gas Transportation Infrastructure Limited.

“RLNG”

means regassified liquefied natural gas.

"Reasonable
and means a person seeking in good faith to perform its contractual
Prudent Operator"
obligations hereunder and, in the process of doing so and in the
overall conduct of its whole undertaking exercising that degree of
diligence, prudence and foresight which can reasonably and ordinarily
be expected from a skilled and experienced operator engaged in the
same type of undertaking under the same or similar circumstances,
and any reference to the standard of a Reasonable and Prudent
Operator shall mean such degree of diligence, prudence and foresight
as aforesaid.
“Seller’s Facilities”

means the Gas metering facilities and other equipment necessary for
flow control and the gas production, liquefaction, shipping including
LNG Tankers , regasification, processing, compression, transportation,
measuring and testing of Gas and any facility required for swapping of
gas to enable delivery of e-Bid RLNG to the Buyer at the Delivery
Point.

"Seller’s Operational means, with respect to Buyer’s request for e-Bid RLNG, Seller, in its
Flexibility"
sole judgment, having sufficient capacity in the Seller’s Facilities and
e-Bid RLNG available, to meet all or any portion of Buyer’s request,
taking into account, inter alia, any requests made by the other
consumers/ buyers of e-Bid RLNG of the Seller provided however, that
the Seller shall treat the Buyer and other e-Bid RLNG buyers in a fair
and equitable manner in allocating e-Bid RLNG to the Buyer. It being
clarified that in no event, shall the Seller be obligated to install or
modify or cause to be installed or modified any aspect to or of the
Seller’s Facilities to accommodate such request;
“Shortfall Quantity”
has the meaning as in Article 6.3.
“Specification”

means the specifications set out in Annexure 1.

“Standard
Cubic means one standard cubic meter of Gas being the amount of Gas
Meter or SCM”
required to fill a space of one standard cubic meter with an absolute
pressure of one thousand and thirteen decimal two five millibars
(1013.25 m bar) at Standard Temperature.
“Standard Pressure” Means the pressure of 14.696 pounds force per square inch (14.696
psi) (1013.25 millibar).
Page 5 of 44

<!-- page 6 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

Means the base temperature of fifteen degrees Celsius (15○C).

“Standard
Temperature”

Seller is in process of changing the base temperature from 15.56○C to
15○C. Till such time, standard temperature is changes to 15○C, existing
system of base temperature of 15.56 ○C and corresponding calorific
value calculation standard will be used for measurement of e-Bid
RLNG quantity.
“Standard Meter”

“Take
or
Quantity”

1.2

A flow meter used for custody transfer conforming to AGA/ISO/other
International Standards.

Pay means the quantity of e-Bid RLNG calculated in accordance with
Article 6.1.

“Term”

has the meaning as in Article 2.1.

“Unauthorised
Overdrawl Charges”
“Unauthorized
Overdrawl”

has the meaning as mentioned in Article 6.6.2
has the meaning ascribed thereto in Article 6.6 of this Agreement.

Interpretation
(a)

Unless the context otherwise requires, a reference to the singular shall include a
reference to the plural and vice-versa, and a reference to any gender shall include a
reference to all other genders.

(b)

Unless the context otherwise requires, a reference to any Article or Annexure shall be a
reference to an article of or annexure to this Agreement.

(d)

The headings of the Articles in this Agreement are inserted for convenience of
reference only and shall not affect the meaning of construction of this Agreement.

(c)

A reference to a volume of e-Bid RLNG is a reference to the volume at Standard
Pressure and Standard Temperature.

(d)

Any reference to a document (including this Agreement) or law shall be deemed a
reference to such document or law as it may be amended, supplemented, revised or
modified from time to time;

(e)

Any reference to a time of day refers to Indian Standard Time;

(f)

Any reference to any Person shall be deemed a reference to such Person's successors
and permitted assigns;

(g)

The terms and provisions of this Agreement, and the respective rights and obligations
of the Parties under this Agreement, shall be binding upon, and inure to the benefit of,
their respective successors and permitted assigns.

(h)

"Year" "Month" and "Day" wherever used in this Agreement imply that of English
calendar.

(i)

Any reference to e-Bid RLNG under this Agreement shall be on Gross Heating Value
Page 6 of 44

<!-- page 7 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

unless and otherwise specified contrary.
(j)

This Agreement shall be interpreted solely in reference to the terms and conditions
contained herein.

ARTICLE 2- TERM
2.1

This Agreement shall come into force on the date it is signed and shall remain in force till
_________ (Term), unless terminated earlier in accordance with this Agreement.

2.2

Each eSPN shall become effective upon execution by the Parties and remain in full force and
effect for the Supply Period set out in the relevant eSPN.

2.3

This Agreement shall stand terminated only at the instance of the Seller in accordance with the
provisions of this Agreement.

ARTICLE 3 - e-BID RLNG SALE AND PURCHASE
3.1

e-Bid RLNG Sale and Purchase
Upon execution of the relevant eSPN and during the Supply Period under such eSPN, the Buyer
shall Take and Pay for, or pay for if not taken e-Bid RLNG in such quantities, at such time and in
such manner as established under such eSPN and this Agreement, and the Seller shall sell and
make available for delivery e-Bid RLNG at the Delivery Point in such quantities, at such time and
in such manner as established under such eSPN and this Agreement.

ARTICLE 4- DELIVERY AND PRESSURE
4.1

Delivery
e-Bid RLNG sold to the Buyer pursuant to this Agreement shall be delivered by the Seller at the
Delivery Point and sale of e-Bid RLNG under this Agreement shall be deemed to be completed
on such delivery at Delivery Point.

4.2

Title and Risk
i.

The facilities as defined in Article 7 up to the Delivery Point shall be or cause to be
constructed, operated and maintained by the Seller at its own risk and cost. The facilities
from the Delivery Point onwards shall be or cause to be constructed, operated and
maintained by the Buyer at its own risk and cost.

ii.

The title, control and risk in respect of the e-Bid RLNG shall pass from the Seller to the
Buyer at the Delivery Point.

iii. If required, the Buyer shall make necessary arrangements for transportation of e-Bid RLNG
from Delivery Point to its plant by entering into necessary commercial arrangements with
the concerned gas transporter.

Page 7 of 44

<!-- page 8 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

4.3

Confidential

Delivery Pressure and Temperature
The Seller shall maintain the ability to supply e-Bid RLNG to the Buyer at the Delivery Point at a
pressure of not more than/ in the range of….…Kg/cm² (g).
The Seller shall maintain the ability to supply e-Bid RLNG to the Buyer at the Delivery Point at a
temperature at ambient temperature / range of ..…degree Celsius.

ARTICLE 5 - e-BID RLNG QUALITY
5.1

Specification
The Seller shall ensure that the e-Bid RLNG delivered shall meet the Specification. The Seller
shall undertake all testing of e-Bid RLNG for quality using the procedures in Annexure 4 and
verified in accordance with Article 7.

5.2

Non-Specification e-Bid RLNG
(a) Subject to the provisions of this Article, the Seller may offer and the Buyer may accept eBid RLNG which does not meet the Specification.
(b) Notwithstanding the deficiencies above, if the Buyer agrees to take, Seller will have no
further liability and the e-Bid RLNG so sold would be paid by the Buyer at the prevailing
price as per the provisions of Article 8.

5.3

Delivery of Non-Specification e-Bid RLNG
(i)

If, without prior agreement, as provided in Clause 5.2, any e-Bid RLNG which does not
comply with the Specification is delivered to the Buyer, the Seller shall notify to the Buyer
immediately but in any case within 24 hour of the Seller first detecting that fact. Seller, at
Buyer’s request may suspend the supplies forthwith and, after rectification of the problem,
the Seller shall resume supply to the Buyer.

(ii) Buyer shall notify the Seller immediately but, in any case, no later than 24 hours of
becoming first aware of the Quality deficiency.

ARTICLE 6 - DELIVERY OBLIGATIONS
6.1

TAKE OR PAY

6.1.1

Seller shall deliver and the Buyer shall receive e-Bid RLNG in accordance with this Agreement
and the terms as may be set out in the eSPN. Seller and Buyer are aware that e-Bid RLNG under
this Agreement shall be supplied through the Seller’s Facilities in a commingled form and after
stripping off higher hydrocarbons, wherever applicable.

6.1.2

In respect of the Supply Period under the relevant eSPN, the Buyer shall be obliged to take and
pay for or pay for if not taken, a quantity of e-Bid RLNG (expressed and measured in MMBTU)
equal to the Take or Pay Quantity.

Page 8 of 44

<!-- page 9 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

6.1.3

Confidential

The “Take or Pay Quantity” in respect of a eSPN shall equal the Contract Quantity (CQ) under
such eSPN minus:
A.

B.

C.

The aggregate of all quantities of e-Bid RLNG that the Buyer refuses to take delivery
of/rejects, owing to such quantities not meeting the Specification, during the Supply Period
under eSPN; and
The aggregate of lower of PNDCQ or DCQ of e-Bid RLNG (except as may be included in
clause above, or part thereof), that the Seller could not tender for delivery at the Delivery
Point during the Supply Period under such eSPN for reasons other than which are
attributable to the actions of the Buyer or due to Force Majeure; and
The aggregate of all quantities of e-Bid RLNG that the Buyer could not take delivery of at
the Delivery Point during the Supply Period under such eSPN due to Force Majeure.

6.2

Take or Pay Payments

6.2.1

If in respect of the Supply Period under any eSPN, the aggregate quantity of e-Bid RLNG
(expressed and measured in MMBTUs) taken by the Buyer at the Delivery Point in accordance
with this Agreement is less than the Take or Pay Quantity for such eSPN determined in
accordance with Clause 6.1 (such shortfall being the “ToP Deficiency Quantity”), then the Buyer
shall pay to the Seller the take or pay payment (“ToP Payment”) in respect of the Deficiency
Quantity which Take or Pay Payment shall be calculated as follows:
TPPt = DQ x Price (for the purpose of ToP Payment the Price shall be the weighted
average Price of e-Bid RLNG for the Supply Period including any taxes and duties and
penalties thereon)
Where
TPPt = the Take or Pay Payment
DQ = the ToP Deficiency Quantity (expressed and measured in MMBTUs)

6.2.2

The Take or Pay Statement issued under the relevant eSPN after the end of Supply Period shall
contain the details of the ToP Deficiency Quantity, and the ToP Payment calculated in
accordance with Clause 6.2.1.

6.3

SHORTFALL QUANTITY

6.3.1

If the Seller, for reasons other than of Force Majeure or for reasons attributable to the Buyer,
fails to make available for delivery at the Delivery Point at least 80% of aggregate of the lower
of PNDCQ or DCQ during any consecutive period of 15 (fifteen) Days under the Supply Period
relating to eSPN then the difference between (a) 15 multiplied by lower of PNDCQ/DCQ
multiplied by 0.8 ; and (b) quantities of e-Bid RLNG actually tendered for delivery by the Seller
during such consecutive period of 15(fifteen) Days (expressed in MMBtu) in respect of such
eSPN shall be called the “Shortfall Quantity”). However, this Article shall not apply in respect of
supply of e-Bid RLNG in excess of DCQ under any rostering mechanism requested by the Buyer.
In the case of Shortfall Quantity in respect of any eSPN, the Buyer shall receive, as Liquidated
Damages for such failure to deliver, a credit to be applied (LD Credit) against the payment to be
made by the Buyer to the Seller in respect of the invoice raised by the Seller for the last Billing
Period of the Supply Period and/or in respect of the Take or Pay Statement relating to such
eSPN. Such Liquidated Damages shall be an amount equal to the Shortfall Quantity multiplied
by 5 (five) per cent of the Price under such eSPN. For the purpose of Liquidated Damages, the
Price shall be the weighted average foreign currency component of e-Bid RLNG, as mentioned in
eSPN, for the Supply Period.

Page 9 of 44

<!-- page 10 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

6.4

Confidential

Emergency
Only in an emergency, the Seller and Buyer may request each other changes to the DCQ of e-Bid
RLNG delivery without prior notice. The Seller and the Buyer shall use reasonable endeavours to
comply with such request.

6.5

PNDCQ
Not later than ten (10) o’clock a.m. on the Day immediately preceding Day of e-Bid RLNG
delivery, the Buyer shall nominate to the Seller the e-Bid RLNG quantities required in respect of
subsequent Day and each such nomination shall be made within the following limitations and,
to the extent, that such nomination is so made, it shall be the “Properly Nominated Daily
Contract Quantity” for that day which quantity the Seller shall deliver.
Each Properly Nominated DCQ shall be an amount which is neither greater than one hundred
and five (105) percent nor less than ninety five (95) percent of the DCQ as per relevant eSPN.
Notwithstanding the above, the Seller may accept at its sole discretion nominations from Buyer
outside the above range (i.e. less than 95% of DCQ and more than 105% of DCQ) subject to
Seller’s Operational Flexibility.
The request of the Buyer to the extent agreed by the Seller shall be considered the PNDCQ for
the purposes of Article 6.1, 6.3, 6.6 and 8.

6.6

Unauthorized Overdrawl

6.6.1

The Seller shall deliver and Buyer shall take e-Bid RLNG in accordance with this Agreement and
relevant eSPN limited to PNDCQ.

6.6.2

If on any Day, the Buyer draws or takes a quantity of e-Bid RLNG in excess of PNDCQ and such
excess drawl exceeds 3% of PNDCQ, then the quantity of e-Bid RLNG drawn in excess of 3% of
PNDCQ shall be termed as “Unauthorized Overdrawl” and shall be charged at 120% of the
Highest Priced Gas as declared by the Seller from time to time plus all other charges including
Taxes and Duties as applicable. Further, in case the cumulative drawl in a Fortnight is more than
the aggregate of PNDCQ for such Fortnight, excluding Days where the drawl of e-Bid RLNG is in
excess of 3% of PNDCQ, then such excess quantity drawn shall also be charged at 120% of the
Highest Priced Gas.

ARTICLE 7 - FACILITIES AND MEASUREMENTS
7.1

Installation, Operation and Maintenance of Facilities
7.1.1

The Seller and the Buyer shall provide or cause to provide the Seller’s Facilities and the
Buyer’s Facilities respectively, as may from time to time be necessary to enable each
Party to perform its obligations under this Agreement and the Seller and the Buyer shall
operate, repair and maintain, the Seller’s Facilities and the Buyer’s Facilities
respectively, and all replacements in good working order and condition throughout the
duration of the Agreement and operate the same in accordance with Reasonable and
Prudent Operator.

7.1.2

The volume of e-Bid RLNG supplied under this Agreement shall be measured by flow
meter (Standard Meter) installed at the gas metering station of the Seller. The volume
Page 10 of 44

<!-- page 11 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

measured would be converted to standard cubic meters by applying pressure and
temperature corrections. The measurement shall include all corrections in installations
practices recommended for accurate metering of Gas by the AGA Gas Measurement
Committee Report No.3/7/8/9 by American Gas Association (AGA) or any other AGA
report, as applicable, and shall be binding on the Parties hereto. The Gas composition
and calorific value of Gas shall be as measured by a chromatograph of the Seller. The
calibration of the chromatograph shall be established by the certified calibration gas.
Heating value shall be computed as per ISO 6976 (latest edition) and the same shall be
applicable for this Agreement. The Seller and the Buyer shall jointly sign a statement
(hereinafter referred to as “Joint Ticket”) on each Day indicating meter reading for the
purpose of Billing and Payment as provided in Article 9 hereinafter. If the Buyer’s
representative is not present on any day, the Seller’s reading shall be considered for
this Article. Alternatively, the Seller shall send electronically e-Bid RLNG supply
statement (hereinafter referred to as “e-joint Ticket”) on each day indicting the
information as above. The Buyer, to indicate discrepancies, if any, or accept the same
electronically within 6 hours, however if no response comes within 6 hours’ time, it will
be deemed accepted for the purpose of Billing and Payment as provided in Article 9.
7.1.3

In case the Buyer has contracted for some gas which is different from e-Bid RLNG under
this Agreement to be delivered at the Delivery Point, then the allocation principles and
priority of supply shall be such that the e-Bid RLNG supplied under this Agreement shall
be accounted on first priority.

7.2

The flow meters at the custody transfer points or Seller's installation shall be proved at a
frequency to be mutually agreed upon between the Buyer and the Seller. e-Bid RLNG is to be
measured by a flow meter with an accuracy of ± 1% above 20% of rated flow and ± 2% below 20%
of rated flow as provided for in Annexure 3.

7.3

The Buyer may install its check flow meter and check chromatograph so as not to interfere with
the instruments of the Seller. In case the Buyer has any doubt on the proper working of the flow
meter of the Seller, Buyer shall inform the same to the Seller in writing and may request for
checking/calibration of the flow meter. AGA-8 or relevant latest standard shall be used for gas
deviation factor. The cost of such special test shall be borne by the Seller if the percentage of
inaccuracy is found to be beyond as stated under Article 7.2 above, but the cost of such special
test shall be borne by the Buyer if the percentage of inaccuracy is within limits of as stated under
Article 7.2 above.

7.4

If on calibration, the Seller's meter registers a variation of more than as stated under Article 7.2
above or if the Seller's meter is out of service, the following procedure in order of priority
whichever is feasible for arriving at the computation of e-Bid RLNG during the period between
the last calibration and the present one, shall be followed:

i)

By using the recording by the check meter of the Buyer if installed identical to the Seller’s
Meter or a Standard Meter and accurately registering; or

ii)

if 7.4 (i) is not possible by correcting the error if the percentage of error is ascertainable
by calibration, test or mathematical calculation; or

ii)

if 7.4 (i) & (ii) both are not possible by estimating the volume of e-Bid RLNG delivered by
comparison with deliveries during period under similar conditions when the Seller's
meter was registering accurately.

Page 11 of 44

<!-- page 12 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

7.5

Confidential

The period to which the above mentioned corrections will apply will be as under;
i)

If any period during which the Seller's meter has gone wrong is known or agreed upon, that
will be the period to which the correction is to be applied.

ii)

If the period is not known, the correction shall be made for a period equal to half of the
time elapsed since the date of the preceding calibration test or joint checking of meter,
provided the correction period does not exceed sixteen (16) days.

7.6

In any case, if at the time of calibration, the meter error exceeds ±0.5 % (point five) efforts will be
made to re-calibrate & bring down the error within ±0.5 %, if possible, it will be recalibrated.

7.7

Upon the written request of the Buyer, the Seller shall permit the Buyer to examine relevant
records, charts and calculations from its metering and measuring equipment. The Seller shall
preserve all such charts, records and calculations till such time the payment covered by the
invoice of the Seller has been paid by the Buyer. The Buyer shall preserve all such charts, records
and calculations for a minimum period of thirty days from the date of presentation of invoice by
the Seller. Provided in the event of dispute regarding billing/payment such records shall be
preserved by the Buyer, till the dispute is finally settled.

7.8

Inspection of Facilities
The Seller and the Buyer shall have the right to inspect each other’s facilities upon giving at least
seven (7) days prior notice. Such inspection will be at the risk and cost of the party doing the
inspection. In addition, the Buyer shall be entitled to be present during the meter reading taken
by the Seller.

7.9

Sole Expert
If the Parties cannot agree on any matter in this Article 7 within ten (10) days from the date on
which the Party notifies the other Party that a dispute exists with respect to that matter, the
dispute shall be referred to a Sole Expert appointed in accordance with Article 11.3 for
determination of dispute in accordance with Article 11.

7.10 For effecting deliveries of e-Bid RLNG, the Seller shall or cause to install and maintain at its own
risk and cost, the piping control and regulation and metering equipment in the Gas metering
station and all other accessories. The said equipment so installed by the Seller shall remain the
property of the Seller and the Seller shall have the right to remove such equipment at any time
within twelve (12) months after the expiry of this Agreement. The Seller shall have the right to
use the Buyer's land and utilities essentially required for installation, operation and maintenance
of e-Bid RLNG metering station and allied equipments required for supply of e-Bid RLNG. These
facilities as required and used by the Seller at the terminal shall be free of cost for the Buyer.
7.11 Notwithstanding Article 6.6, the Seller reserves the right to regulate the flow of Gas by installing
appropriate control devices. Unless and otherwise agreed between the Seller and the Buyer in
writing, if the Buyer draws/take e-Bid RLNG beyond the PNDCQ it shall be at the sole risk of the
Buyer including resultant disruption/stoppage of e-Bid RLNG supply either total or partial to the
Buyer. Buyer shall be liable for all cost, expenses, damages or losses arising out of or resulting
from or incidental to such overdrawl of e-Bid RLNG. Provided further the Buyer shall not be
entitled to any claim.
7.12 STEPS FOR METER INSPECTION & HANDLING SUSPECTED METER TAMPERING (For customers
having unmanned terminals)
Page 12 of 44

<!-- page 13 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

1.

Seller’s representative shall have the unrestricted access to the meter skid for inspection
and its working, at any time.

2.

As the e-Bid RLNG is supplied uninterrupted and the Buyer is to draw e-Bid RLNG on
continuous basis, the Buyer shall make available an authorized representative responsible
for the safety and security of the Gas pipeline and the metering skid. Names of such
authorized representatives shall be given to Seller in writing in advance; and whenever
there is any change, the same should also be intimated in writing. The representative of
the Buyer shall be responsible for associating with Seller’s representative during any kind
of work on metering skid and signing of inspection / reading formats / joint tickets etc.

3.

The metering skid shall be surrounded by a fencing and gate. The gate shall be locked and
the key shall be in the custody of the Buyer. Metering skid door shall be locked and the key
shall be available with the Seller. Tamper proof security seals shall be put across all the
doors with signature of Seller’s representative. Safety of the seal shall be the responsibility
of the Buyer. The meter installed in the skid shall be pre-calibrated meter for which
calibration records shall be available in Seller’s office. A copy of the same can be issued at
the Buyer’s request. On the meter, following type of seals shall be provided by the Seller.
(a) Manufacturer seal
(b) Calibration lab seal.
(c) GAIL holographic seal.
(d) GAIL security seal.
The type, no. of seals and condition of seals on the meter shall be recorded on the 4 stage
inspection format at the time of installation / change of the meter.

4.

For each inspection / visit, other than that for joint ticket reading, where the metering skid
is to be opened, the four stage inspection format shall be duly filled by Seller’s
representative recording all the observations. The same has to be signed stage wise by
Buyer’s representative. In the event of refusal of Buyer’s representative to sign the format,
the Seller’s representative will record that the Buyer’s representative has refused to sign
the format; and further record his observations in the format, which will then be pasted
and/or delivered to the Buyer’s unit. A copy of the format along with the observations
recorded therein by the Seller’s representative will be sent to the Buyer through post. It
shall be the responsibility of the Buyer to ensure the presence of its representative during
such inspection.

5.

Any abnormality observed during the inspection shall be recorded on the 4 stage
inspection format.

6.

In case of suspected tampering, the meter shall be replaced with another meter in
presence of the Buyer’s representative and sealed in a box with joint signature of Buyer &
Seller’s representatives. No advance notice shall be served to the Buyer for replacing the
meter in case of suspected tampering. Buyer shall be required to provide a short shutdown
for replacement of the meter as and when informed by Seller. At all the times of removal
of meter, the Seller shall inform in writing to the Buyer about the reasons of meter
removal. In case the Buyer’s representative at any stage is absent and/or refuses to sign, it
shall be presumed that the meter has been tampered with and the meter without the
signature of the Buyer’s representative will be sent for further inspection and/or
Page 13 of 44

<!-- page 14 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

calibration as provided hereinafter, by the Seller and the Buyer shall accept the actions
taken by the Seller as final.
7.

The meter so taken out shall be sent for third party inspection and calibration at a
calibration lab recognized at national level. The date & place of calibration shall be
informed to the Buyer in advance & the Buyer may depute authorized representative to
the lab. The meter shall be taken out from the sealed box in presence of the Buyer’s and
Seller’s representative; and taken for inspection & calibration and the condition of the
seals on the box shall be recorded and signed jointly by the Seller’s and Buyer’s
representative. Entry in the inspection and calibration room of the lab shall not be allowed.
Reports given by the lab shall be duly signed by the Seller & Buyer representative,. In case
the representative of either Party is not available, the lab will be free to open the sealed
box and proceed for further examination, inspection and calibration and thereafter send
the report to the Seller by post.

8.

Meter shall be considered as tampered, if any of the seals on the meter is found disturbed
/ broken or missing and / or any of the settings parts inside the meter are found disturbed
or changed irrespective of the calibration results. However, if all the seals and parts are
found to be okay and only calibration results are found to be having deviation from usual,
the meter will not be considered tampered and only calibration error will be taken into
account, as per the provisions of this Agreement.

9.

In case the meter is found tampered, penal action shall be initiated as below –
a.
Within 10 days of the receipt of inspection & calibration report, confirming
tampering, report, a show cause notice shall be issued by Seller to the Buyer to
explain why the penal action should not be initiated.
b.
The replies, if submitted, shall be reviewed by the Seller.
c.
If the replies are not found satisfactory and/or tenable & tampering is established,
then the gas supply shall be discontinued and the Seller may proceed further for
termination of the Agreement and the period of tampering for which Meter
Tampering Charges are to be imposed will be determined. Resumption of gas
supply will be regulated as mentioned hereinafter.
d.
For ascertaining the period of tampering, the gas drawl data / data from EVC shall
be reviewed along with the history of previous meter calibrations. The
consumption data shall also be compared with consumption recorded just after
replacement of meter. The day or time from where gas drawl has gone below the
normal gas drawl by the consumer (without any shutdown or otherwise
explainable reasons) to the day of replacement of meter shall be considered as the
period of tampering. However –
(i)
If the meter has been changed in between for any reasons and the meter
taken out was found not tampered then the tampering period shall be from
the date of replacement of last meter to date of change of present meter.
(ii)
If in between a four stage inspection has been carried out and nothing
abnormal has been found on that day, then tampering period shall be from
that day to the date of replacement of present meter.
Four stage inspection of all the metering skid shall be carried out every
quarter. Once this is done, the total tampering period in any case shall not
be more than 3 months whereby maximum period for which Meter
Tampering Charges can be imposed shall be 3 months.
e.

Once the tampering period is established, than peak flow recorded during 3
months prior to tampering period shall be taken and that will be treated as
quantity of gas actually consumed by the consumer during the tampering period.
Page 14 of 44

<!-- page 15 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

f.

g.

h.

i.

Confidential

The difference between this peak quantity and the actual billed quantity in this
period, shall be difference quantity or the short fall quantity to be charged from
the consumer as per Article 7.12. An invoice shall be raised towards actual gas
supplied during tampered period.
Meter Tampering Charges which shall be over and above the shortfall quantity will
be equivalent to the peak flow quantity charged at Unauthorized Overdrawl
Charges for the entire tampered period.
In case the tampering is repeated for the second time, the amount of penal
amount calculated as above, shall be charged at a rate which is double of
Unauthorized Overdrawl Charges, apart from isolation of gas supply and/or
termination of the Agreement.
A notice shall be issued to the consumer conveying the differential invoice amount
and the penal amount to be paid by the consumer within a period of 15 days,
failing which gas supply will not be restored.
In case tampering is repeated for the third time, apart from isolation of gas supply
without any further notice, action shall be initiated for termination of Agreement.
The Buyer shall pay the penal amount and other charges as communicated by the
Seller, failing which the Seller shall have unrestricted right to recover the amount
of penal amount together with the cost of pipeline laying and other associated
infrastructure from the Buyer as per law of the land.

10.

Once gas supply is stopped because of meter tampering, supply will be restored only
when the Buyer pays the full penal amount calculated as above and gives a written
apology and undertaking that such an event shall not be repeated in future. Further,
before restoration of the supply of gas in addition to liquidation of all the dues, the Buyer
shall be liable to pay an amount of Rs. 50,000/- (fifty thousand only) as restoration of gas
supply.

11.

In case the Buyer takes legal recourse, the Buyer shall be required to first deposit with
the Seller an interest free deposit by way of electronic transfer in the designated
SBI/ICICI/HDFC Bank account of Seller of the value equivalent to the penal amount
arrived at as hereinabove. Further, the restoration charges of Rs. 50,000 shall also be
liable to be paid by the Buyer in case of decision of commencement of supply pending
final outcome of the proceedings.

ARTICLE 8 - PRICE
8.1

The Price payable by the Buyer for the quantity of e-Bid RLNG delivered at the Delivery Point
pursuant to this Agreement shall be as per the eSPN. Further, the Price indicated in the eSPN
shall be provisional and shall be reconciled on monthly basis by the Seller depending upon the
actual cost of cargos sourced for supply of e-bid RLNG under the Scheme and exchange rate
variation.

8.2

The above total price is exclusive of taxes, duties, service charges, statutory levies, etc. by
whatever name called and levied by either Governments Agency or local bodies or both shall be
payable extra, if applicable, from time to time.
The Buyer shall be liable for any of above taxes, duties, service charges, statutory levies, etc., if
applicable, with respect to the sale, transfer, transport or importation of the e-Bid RLNG. Any
taxes, duties, service charges, statutory levies, etc. for which the Buyer is liable under this
article but which may have been paid by the Seller shall be reimbursed by the Buyer together
with applicable interest, if any, within 15 days after written request by the Seller. If the
Page 15 of 44

<!-- page 16 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

payment is made by Buyer after 15 days, the interest on delayed payment shall be applicable as
mentioned in Article 9.4. For avoidance of doubt, the Buyer shall indemnify the Seller against
any taxes, duties, service charges, statutory levies, etc. which the Seller as a result of any law,
rule or policy, is or becomes obliged to pay directly or indirectly on sale, transfer, transport,
importation, treatment or handling of e-Bid RLNG sold as per the terms of this Agreement.
8.3

In case of e-Bid RLNG supply to the Buyer through swapping mechanism, the supply shall be
governed by the guidelines on swapping issued by Ministry of Petroleum and Natural Gas (No.
L-12011/10/2011-GP dated 15.03.2012) and Office Memorandum. Further, the Buyer shall
submit an indemnity bond to the Seller in the format provided at Annexure 9.

8.4

Rostering of e-bid RLNG may be mutually decided between the Seller and the Buyer and shall
always be subject to Seller’s Operational Flexibility. The entire cost of such rostering of the e-bid
RLNG shall be borne and payable by the Buyer to the Seller. Further, Article 14.1 shall not be
applicable in case of rostering.

8.5

If at any time due to change of law or change in policy of Government Agency / statutory
authority or formation of Regulatory authority, any revision in Price is necessitated; the revision
in the various price elements shall be effected.

8.6

Foreign Currency Component shall be included in the Invoice in equivalent Indian Rupees
converted at the prevailing TT selling rate as per State Bank of India (SBI) Card rate applicable
on the last Day of the Fortnight. In case the rate is not available on the last Day of the Fortnight,
then the SBI TT selling rate of the immediately preceding Banking Day shall apply.

8.6

Payment Currencies
The total price shall be invoiced and paid in Indian Rupees.

ARTICLE 9 - BILLING AND PAYMENT
9.1

Payment Statement or Invoice
Within two days following the end of the Fortnight or end of Supply Period in event the supply
of e-Bid RLNG is for a period less than a Fortnight, the Seller shall render to the Buyer a
statement (“Payment Statement” or “Invoice”) including the following details for the previous
Fortnight which shall show in respect of the previous Fortnight.
(a) PNDCQ for each Day of such Fortnight expressed in MMBTU.
(b) The actual daily quantity of total e-Bid RLNG taken in MMBTU at the Delivery Point, on a
daily basis;
(c) The applicable price for the each element of delivered price as indicated in the Article 8.
(d) The applicable VAT/CST, entry tax/service charges and other taxes & duties which are to be
reimbursed by the Buyer on the e-Bid RLNG delivered during such Fortnight.
(e) The payment amount receivable by the Seller and included in the Payment Statement shall
be based on statement jointly signed by the Seller and the Buyer under Article 7.
The Seller may raise debit /credit note in the event of any adjustment that may be required in
respect of e-Bid RLNG supplied and payments made hereunder.

9.2

Payment
Within 4 (four) business days, after the receipt of the Fortnightly Payment Statement, debit
note or credit note, Take or Pay Statement being the “Due Date”, the Buyer shall pay to the
Page 16 of 44

<!-- page 17 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

Seller the sum due in the Payment Statement, reconciliation Statement/debit note or credit
note, Take or Pay Statement including any amount referable as a Disputed item (as defined in
Article 9.3). The amount receivable by the Seller shall be paid to the account of the Seller as
indicated in the Statement. Mode of Payment shall be by electronic transfer of funds to the
designated SBI/ICICI/HDFC Bank account of Seller on or before the due date as advised by Seller.
9.3

Disputed Amount
If the Buyer disputes any amount, quantity, value or sum in the Payment Statement, debit note
or credit note, Take or Pay Statement (“the Disputed item”), the Buyer shall notify the Seller
within seven (7) days of receiving either of the Statements. The notice shall specify the
Disputed item and the reasons why the Buyer disputes that item.
The Seller and the Buyer shall resolve the dispute relating to the disputed item as provided for
in Article 11. The amount agreed or determined to be due in relation to the Disputed item shall
be paid to or paid by the Buyer.
(a) Within three (3) days from the date the dispute is resolved:
(i)
By the Parties under Article 11.1
(ii)
By the sole expert under Article 11.2
In addition, interest shall be payable at the rate of SBI Base Rate plus 6.25% on the amount
agreed or determined to be due in relation to the Disputed item from the date that amount was
due until the date the whole of that amount is paid. Such interest shall compound annually.
or
(b) As provided for in the decision in Article 11.6 (unresolved dispute)
as the case may be.

9.4

Interest on Delayed Payments
Should Buyer fail to make payment of any sum due, simple interest on that sum shall accrue
from the Due Date, until the date payments is made, on a day to day basis at SBI Base Rate
applicable on the Due Date of payment plus 6.25%. Such interest shall compound annually.

9.5

Buyer to Provide and Maintain Revolving Letter of Credit
i)

Buyer shall provide irrevocable Standby Revolving unconditional letter of credit (“LC”) in
favour of the Seller. The face value of the LC shall be equal to 110% of the value of e-Bid
RLNG supply for three fortnights or actual supply period whichever is lower, where
value of one fortnight is 16 days multiplied by DCQ multiplied by Price (including
Transportation Charges, Customs Duty, etc.). The exchange rate for calculation of value
of LC shall be the prevailing RBI reference rate on the date of opening of LC.
Provided further that LC shall be valid for Supply Period and 15 days thereafter. The LC
should be opened 5 days prior to Supply Period as per eSPN. In case LC is not provided
by the Buyer prior to Supply Period then the Seller shall not be obligated to supply e-Bid
RLNG under this Agreement and Buyer shall be liable for Take or Pay Payment.

ii)

the LC shall be issued by a nationalized/scheduled bank (issuing bank with an office in
New Delhi/Zonal office…………..), and in a form acceptable to the Seller.
Page 17 of 44

<!-- page 18 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

9.6

Confidential

iii)

in the event that any payment due to the Seller is not paid within the time for payment
stipulated in this Agreement by the Buyer (Due Date) the Seller may make demand
under the Letter of Credit in an amount equal to the Payment Amount together with
any interest payable thereon calculated in accordance with Article 9.5. Further, Seller
may also make demand under the LC for any claim on account of customs duty, penal
interest, penalty etc. by any government authority for supply of e-Bid RLNG under this
Agreement, in case it is not paid by Buyer within the Due Date.

iv)

the Buyer shall make such arrangements as are necessary with the issuing bank such
that the amount available under the letter of credit shall always be an amount equal to
the sum and duration referred to in Article 9.5(i) in question notwithstanding any
demand by the Seller pursuant to 9.5 (iii).

v)

All bank charges, interest or other payment related to letter of credit will be on Buyer’s
Account.

vi)

In absence of any valid LC as required in 9.5, the Seller shall have unrestricted right to
withhold commencement of supply of e-Bid RLNG till opening of such LC and the Buyer
shall be liable for Take or Pay Payment.

vii)

The format of LC is provided at Annexure-6.

Buyer to provide Undertaking and Indemnity to Seller for availing Customs Duty waiver on
imported LNG
The Buyer undertakes to provide all necessary documents, certificates, etc. as may be required
and informed by the Seller to the Buyer in writing including the documents mentioned in but
not limited to Office Memorandum, for claiming exemption from Customs Duty and indemnify
the Seller towards any duty, interest or penalty levied, if any, by Customs authorities on this
account. The Buyer shall provide undertaking to the Seller to this effect in the format provided
at Annexure-7.
The Buyer shall submit an indemnity bond to the Seller in the format provided at Annexure-8.

9.7

Buyer to provide necessary documents and certificates for availing various exemptions and
waivers
The Buyer undertakes to provide all necessary documents, certificates and assistance and
cooperation as may be required and informed by the Seller to the Buyer for claiming various
exemption and waivers from all taxes, duties and levies including (but not limited to) value
added tax, sales tax, central sales tax, goods and service tax, octroi, entry tax, service tax and
other local levies as set out in (but not limited to) the Office Memorandum.
In the event, any of these duties, taxes and levies are payable by the Seller due to the Buyer’s
failure to provide necessary documents, certificates, assistance or cooperation, such duties and
taxes including penalties thereto will be solely to the account of and recoverable from the
Buyer.

ARTICLE 10 - GENERAL INDEMNITY
10.1

Indemnity as to Seller’s Title to e-Bid RLNG
Except as otherwise expressly provided herein, Seller shall indemnify and hold the Buyer and
employees and agents harmless and indemnify it against all losses, damages and expenses of
every kind on account of adverse claims to the Seller’s title to the e-Bid RLNG delivered to the
Page 18 of 44

<!-- page 19 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

Buyer except to the extent such claims or damages are caused by negligence or willful
misconduct.
10.2

Indemnity as to Buyer’s Title to e-Bid RLNG
Except as otherwise expressly provided herein, Buyer shall indemnify and hold the Seller and
each of its Affiliates, employees and agents harmless and indemnify it against all losses,
damages and expenses of every kind on account of adverse claims to the Buyer’s title to the eBid RLNG received from the Seller except to the extent such claims or damages are caused by
negligence or willful misconduct.

ARTICLE 11 -DISPUTE RESOLUTION
11.1

Amicable Settlement
The Parties shall use their respective reasonable endeavors to settle any Dispute amicably
through negotiations. If a Dispute is not resolved within sixty (60) Days after written notice of a
Dispute by one Party to the other Party then the provisions of Article 11.6 shall apply unless the
subject matter of such Dispute is required to be referred to a Sole Expert under Article 11.2 in
which case the provisions of Article 11.2 shall apply.

11.2

Determination by Sole Expert
Any Dispute arising out of matters relating to Article 5 or Article 7 shall be referred only to a
Sole Expert who shall be appointed in accordance with Article 11.3.

11.3

Appointment of Sole Expert
The procedure for the appointment of an expert shall be as follows:
(a) The party wishing the appointment to be made shall give notice to that effect to the other
and such notice shall give details of the matter which it is proposed shall be resolved by the
expert.
(b) The parties shall meet in an endeavour to agree upon an expert to whom the matter in
dispute shall be referred for determination.
(c) If within twenty-one (21) days from the service of the said notice the parties have either
failed to meet or failed to agree upon an expert then the parties shall attempt to agree
upon a person (“Appointing Authority”) who shall be requested to make the appointment
of an expert and in the event of failure to so agree within fourteen (14) days thereafter, the
matter shall be referred for arbitration as per Article 11.6.
(d) Having selected the Sole Expert, the parties shall forthwith jointly notify such expert of his
selection and request him within fourteen (14) days to confirm whether or not he is willing
and able to accept the appointment. If such expert is either unwilling or unable to accept
such appointment or has not confirmed his willingness and ability to accept such
appointment within the said period of fourteen (14) days, the Parties shall further attempt
to mutually select sole expert fails the dispute shall be referred for arbitration in
accordance with Article 11.6.

Page 19 of 44

<!-- page 20 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

11.4

Confidential

Qualifications of Sole Expert
(a) No person shall be appointed to act as the Sole Expert unless he is technically qualified by
education, experience and training to determine the Dispute.
(b) If a Party becomes aware of a possible conflict of interest or duty of a proposed or
appointed Sole Expert and such Party considers that there is a material risk of such conflict
of interest or duty prejudicing the Sole Expert’s decision, then such Party may object to the
Sole Expert’s appointment. After such objection, either Party may apply to the Appointing
Authority who shall decide if such Sole Expert shall be appointed as or shall continue as the
Sole Expert or if necessary, appoint a replacement Sole Expert.
(c) No person shall be appointed a Sole Expert who at the time of appointment is (or has been
within the preceding twelve (12) months) a director, office holder or an employee of, or
directly or indirectly retained as consultant to, a Party or any Affiliate of a Party.
(d) All information, data or documentation disclosed or delivered to the Sole Expert by a Party,
pursuant to his appointment as Sole Expert hereunder, shall be treated as confidential and,
except as provided in paragraph 11.4(e) below, the Sole Expert shall not disclose to any
person any such information, data or documentation. All such information, data and
documentation shall remain the property of the Party disclosing or delivering the same and
all copies thereof shall be returned on completion of the Sole Expert’s work.
(e) The Sole Expert may disclose any confidential information, data or documentation,
described in paragraph (d) above, to any staff assisting the Sole Expert or to the
professional advisers to the Sole Expert; provided that such staff assisting the Sole Expert
or professional advisers shall, prior to such disclosure, enter into specific obligations with
the Sole Expert to maintain the confidentiality of such information, data and
documentation.
(f)

11.5

The terms of appointment of the Sole Expert shall contain an obligation on the Sole Expert
to comply with the obligations set out above.

Terms of Reference and determination of Sole Expert
(a) The terms of reference of the Sole Expert shall contain, among other things, provisions
that:
(i) the Parties shall be entitled to supply data and information and make submissions to
the Sole Expert during a period of thirty (30) Days commencing the date of the
appointment of the Sole Expert. The Sole Expert shall ignore any data, information and
submissions supplied and made after such thirty (30) Days period unless it is furnished
in response to a specific request from the Sole Expert or in response, in accordance
with paragraph 11.5(a)(iii), to a submission by the other Party;
(ii) the Sole Expert shall be entitled to obtain such independent professional and/or
technical advice as he may reasonably require and to obtain such secretarial
assistance as is reasonably necessary;
(iii) copies of all written data, information and submissions supplied or made by any Party
to the Sole Expert shall be provided simultaneously to the other Party which shall,
within fourteen (14) Days of receipt of such data, information or submissions have the
right to comment in writing on it to the Sole Expert. Copies of any such comments
shall be supplied promptly to the other Party;
Page 20 of 44

<!-- page 21 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

(iv) no meeting between the Sole Expert and a Party shall take place unless both Parties
have a reasonable opportunity to attend any such meeting and being heard; and
(v) the Sole Expert shall give full written reasons for his determination and shall furnish
the Parties with a draft of his proposed determination in respect of which the Parties
shall be entitled to make representations to the Sole Expert within thirty (30) Days
after receipt of the same.
(b) Within a reasonable period (which shall not, without the prior written consent of the
Parties, exceed sixty (60) Days after the acceptance of his appointment), the Sole Expert
shall make a determination regarding the Dispute submitted to him and if he has not
rendered such determination within such sixty (60) Days period then, at the request of
either Party, another Sole Expert shall be appointed. Upon acceptance of such
appointment, the appointment of the previous Sole Expert shall cease, unless prior to the
date on which the new Sole Expert accepts his appointment, the existing Sole Expert shall
have rendered his determination in which case such determination shall be binding on the
Parties and the instructions of the new Sole Expert shall be withdrawn.
(c) The determination of the Sole Expert shall be final and binding upon the Parties in relation
to the Dispute referred to him, save in the event of fraud or mistake as to material fact.
(d) Each Party shall bear their own costs in providing all data, information and submissions
given by it and the costs and expenses of all lawyers, advisers, witnesses, employees and
other persons retained by it.
11.6

Conciliation and Arbitration

Any Dispute arising in connection with this Agreement which is not resolved by the Parties pursuant to
Article 11.1 within sixty (60) Days of the notice of the Dispute or Article 11.3(c) and Article 11.3(d), shall
first be referred to Conciliation as under:
(i)

The Seller has framed the Conciliation Rules 2010 in conformity with supplementary to part – III
of the Indian Arbitration and Conciliation Act 1996 for speedier, cost effective and amicable
settlement of disputes through conciliation. A copy of the said rules made available on GAIL’s
website www.gailonline.com for reference. Unless otherwise specified all the issues / disputes
which cannot be mutually resolved within a reasonable time shall be settled in accordance with
the Conciliation Rules 2010.

(ii)

Any dispute(s) / difference(s) / issue(s) of any kind whatsoever between / amongst the Parties
arising under / out of / in connection with this contract shall be settled in accordance with the
aforesaid rules.

(iii)

In case of any dispute(s) / difference(s) / issue(s), a Party shall notify the other Party(ies) in
writing about such a dispute(s) / difference(s) / issue(s) between / amongst the Parties and that
such a Party wishes to refer the dispute(s) / difference(s) / issue(s) to Conciliation. Such invitation
for Conciliation shall contain sufficient information as to the dispute(s) / difference(s) / issue(s) to
enable the other Party(ies) to be fully informed as to the nature of the dispute(s) / difference(s) /
issue(s), the amount of monetary claim, if any, and apparent cause(s) of action.

(iv)

Conciliation proceedings commence when the other Party(ies) accept(s) the invitation to
conciliate and confirmed in writing. If the other Party(ies) reject(s) the invitation, there will be no
conciliation proceedings.
Page 21 of 44

<!-- page 22 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

(v)

If the Party initiating the conciliation does not receive a reply within thirty days from the date on
which he/she sends the invitation, or within such other period of time as specified in the
invitation, he/she may elect to treat this as a rejection of the invitation to conciliate. If he/she so
elects, he/she shall inform the other Party(ies) accordingly.

(vi)

Where invitation for Conciliation has been furnished, the Parties shall attempt to settle such
dispute(s) amicably under part – III of the Indian Arbitration and Conciliation Act, 1996 and GAIL
(India) Limited Conciliation Rules, 2010. It would be only after exhausting the option of
Conciliation as an alternate dispute resolution mechanism that the Parties hereto shall go for
Arbitration. For the purpose of this clause, the option of ‘Conciliation’ shall be deemed to have
been exhausted, even in case of rejection of ‘Conciliation’ by any of the Parties.

(vii)

The cost of Conciliation proceedings including but not limited to fees for conciliator(s), airfare,
local transport, accommodation, cost towards conference facility etc. shall be borne by the
Parties equally.

(viii) The Parties shall freeze claim(s) of interest, if any, and shall not claim the same during the
pendency of Conciliation proceedings. The settlement agreement, as and when reached / agreed
upon, shall be signed between the Parties and Conciliation proceedings shall stand terminated on
the date of the settlement agreement.
In the event, the Parties are unable to resolve the Dispute pursuant to the Conciliation Rules 2010, then
the Dispute shall be referred for Arbitration:
Alternative 1-Where both the Parties are Government Company
(a)

in the event of any dispute or difference relating to the interpretation and application of the
provisions of this Agreement, such dispute or difference shall be referred by either party for
arbitration to the sole arbitrator in the Department of Public Enterprises to be nominated by the
Secretary to the Government of India in charge of the Department of Public Enterprises. The
Arbitration and Conciliation Act, 1996 shall not be applicable to arbitration under this Article. The
award of the arbitrator shall be binding upon the parties to the dispute, provided, however, any
party aggrieved by such award may make further reference for setting aside or revision of the
award to the Law Secretary, Department of Legal Affairs, Ministry of Law and Justice,
Government of India at New Delhi. Upon such reference the dispute shall be decided by the Law
Secretary or the Special Secretary/Additional Secretary authorized by the Law Secretary, whose
decision shall bind the Parties finally and conclusively. The Parties to the dispute will share
equally the cost of arbitration as intimated by the arbitrator.

(b)

in the event either Party ceases to be a Government Company, due to privatization or
disinvestment or otherwise, the dispute or differences relating to the interpretation and
application of the provisions of this Agreement between the Parties shall still be referred to the
arbitration proceedings provided above in Article 11.6(a), as per office memorandum No.
DPE/4(10)/2001- PMA G 21, dated 22 January, 2004 of the Department of Public Enterprises,
Ministry of Heavy Industries and Public Enterprises, Government of India;

Alternative 2- where one Party to the Agreement is not a Government Company
(a)

be finally settled by arbitration in accordance with the Indian Arbitration and Conciliation Act,
1996 and rules made there under, from time to time. The procedure for appointment of
arbitrators shall be as follows:
Page 22 of 44

<!-- page 23 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

(i)

Confidential

After the sixty 60 Days period described in Article 11.1, either Party may submit the Dispute
to a single arbitrator (the "Sole Arbitrator"). The Buyer shall select the Sole Arbitrator within
thirty [30] Days of the expiration of such sixty 60 Days period from a panel of three (3)
distinguished persons nominated by the Seller.

(ii) The decision(s) of the Sole Arbitrator, supported by reasons for such decision, shall be final
and binding on the Parties.
(iii) The venue of arbitration shall be New Delhi.
This Article 11.6 shall survive the termination or expiry of this Agreement.
11.7

Continue performance
While any Dispute under this Agreement is pending, including the commencement and
pendency of any Dispute referred to the Sole Expert or arbitration, the Parties shall continue to
perform all of their respective obligations under this Agreement without prejudice to the final
determination in accordance with the provisions under this Article 11.

ARTICLE 12
(Not used)

ARTICLE 13 - FORCE MAJEURE
13.1

Events of Force Majeure
No failure, delay or omission by either Party to fulfill any of its obligations under this
Agreement (other than the obligation to make payments when due) shall give rise to any claim
against such Party or be deemed to be a breach of this Agreement if and to the extent such
failure, delay or omission continues from any of the following events not within the
reasonable control of such Party (each an event of "Force Majeure"):

(a) As to Seller’s Facilities:
(i)

fire, flood, atmospheric disturbance, lightning, storm, typhoon, tornado, earthquake,
landslide, soil erosion, subsidence, washout or epidemic or other acts of God;

(ii) war (whether declared or undeclared), riot, civil war, blockade, insurrection, acts of
public enemies or civil disturbance;
(iii) Lawful strike, lockout, or other industrial disturbance, affecting Seller’s Facilities;
(iv) loss of or damage to or failure of any of LNG supplier’s facilities or Seller’s Facilities,
except to the extent such loss, damage or failure is caused by the Willful Misconduct of
supervisory or management personnel of LNG supplier (in the case of LNG supplier’s
facilities) or the Seller (in the case of Seller’s Facilities); or
(v) any acts of Government Agency (except as provided in Article 8.4), or compliance with
such acts, which directly affect LNG supplier’s or Seller’s ability to perform its obligations
hereunder;
(vi) Loss or damage to or failure of an LNG tanker.
Page 23 of 44

<!-- page 24 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

(b) As to Buyer’s Facilities:
(i)

fire, flood, atmospheric disturbance, lightning, storm, typhoon, tornado, earthquake,
landslide, soil erosion, subsidence, washout or epidemic or other acts of God;

(ii) war (whether declared or undeclared), riot, civil war, blockade, insurrection, acts of
public enemies or civil disturbance;
(iii) lawful strike, lockout, or other industrial disturbance, affecting Buyer’s Facilities;
Provided however that any of the above events (set out in sub-Articles (a) and (b) above), shall
qualify as an event of Force Majeure only if the impact of such an event continues for atleast three
(3) consecutive days.
13.2

Non-performance not excused for either Party
Notwithstanding the provisions of this Article 13, neither Party shall be entitled to claim relief
by reason of Force Majeure for:
(a) obligations of such Party that are required to be completely performed prior to the
occurrence of the event of Force Majeure;
(b) the failure of such Party to maintain its facilities or equipment in accordance with the
standards of a Reasonable and Prudent Operator; or
(c) late performance caused by failure of such Party or its contractors or subcontractors to
engage qualified contractors and suppliers or to hire an
adequate
number
of
personnel, except where such failure is due to Force Majeure.

13.3

Party to Notify Force Majeure Events
Where a Party claiming suspension of its obligations on account of Force Majeure Event, shall
promptly, but in no case later than seven (7) days after the occurrence of the event of Force
Majeure, notify the other Party in writing giving full particulars of the Force Majeure Event, the
estimated duration thereof, the obligations affected and the reasons for its suspension.

13.4

Duty to Mitigate Effects of Force Majeure
A Party claiming Force Majeure shall exercise reasonable diligence to seek to overcome the
Force Majeure event and to mitigate the effects thereof on the performance of its obligations
under this Agreement. The Party affected shall promptly notify the other Parties as soon as the
Force Majeure event has been removed and no longer prevents it from complying with the
obligations which have been suspended and shall thereafter resume compliance with such
obligations as soon as possible.

13.5

Onus on Party Claiming Force Majeure
The Party asserting the claim of Force Majeure shall have the burden of proving that the
circumstances constitute valid grounds of Force Majeure under this Article and that such Party
has exercised reasonable diligence and efforts to remedy the cause of any alleged Force
Majeure.
Page 24 of 44

<!-- page 25 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

13.6

Confidential

Force Majeure Event Exceeds 30 Days
Notwithstanding anything contained herein above, if an event of Force Majeure occurs and is
likely to continue for a period in excess of thirty (30) days, the Parties shall meet to discuss the
consequences of the Force Majeure and the course of action to be taken to mitigate the effects
thereof or to be adopted in the circumstances.

ARTICLE 14 – SUSPENSION AND TERMINATION
14.1

Seller’s Failure to Deliver e-Bid RLNG
If the Seller fails (other than as a consequence of the Buyer’s default or failure due to Force
Majeure) to tender for delivery 50% or more of the cumulative PNDCQ of e-Bid RLNG for a
period of sixty (60) continuous Days, then without prejudice to any other rights or remedies
that the Buyer may have under this Agreement or by Law, the Buyer may terminate this
Agreement in consultation with the Seller, upon not less than thirty (30) Days prior written
notice to the Seller.

14.2

Buyer’s Failure to Pay

(a)

If the Buyer fails to make any payment due to the Seller under this Agreement for whatsoever
reason for a period of seven (7) Business Days after Buyer's Due Date of such payment, then,
upon not less than three (3) Days prior written notice by the Seller to the Buyer, the Seller shall
be entitled to suspend deliveries of e-Bid RLNG to the Buyer until such defaulted payments with
interest (under Article 9) shall have been paid to the Seller.

(b)

Notwithstanding anything to the contrary in this Agreement, such suspension of deliveries by
the Seller shall not constitute a default by the Seller to deliver e-Bid RLNG to the Buyer and shall
not constitute Seller’s Shortfall (and shall not result in any liability to the Seller under this
Agreement) and the Buyer shall remain liable for all of its Take or Pay obligations under this
Agreement.

(c)

If Buyer fails to make any payment within a period of fifteen (15) Business Days from Buyer's
Due Date of such payment, then without prejudice to any other rights or remedies that the
Seller may have under this Agreement or under Law, the Seller may, at its sole option,
terminate this Agreement upon not less than six (6) Days prior written notice to the Buyer.

14.3

Buyer’s failure to submit certificates and documents to the Seller for availing exemptions and
waivers
If the Buyer fails to provide all necessary documents, certificates and assistance and
cooperation in accordance with the provisions of Clauses 9.6 and 9.7 for claiming various
exemptions and waivers for whatsoever reason within the time prescribed by the Seller, then,
upon not less than three (3) Days prior written notice by the Seller to the Buyer, the Seller shall
be entitled to suspend deliveries of e-Bid RLNG to the Buyer until the Buyer fulfills its
obligations under the said Clauses.

14.4

Buyer’s Failure to take e-Bid RLNG
If the Buyer fails (other than as a consequence of Force Majeure or the Seller’s default) to take
50% or more of the cumulative PNDCQ during a period of sixty (60) consecutive Days, then
Page 25 of 44

<!-- page 26 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

without prejudice to any other rights or remedies that the Seller may have under this
Agreement or Law, the Seller may, at its sole option, terminate this Agreement upon not less
than thirty (30) Days prior written notice to the Buyer.
14.4

Buyer’s Failure to Provide and Maintain the Letter of Credit

(a)

If the Buyer breaches any of its obligations under Article 9.5, including the obligation to issue,
maintain, renew, replenish, restore and reinstate the Letter of Credit, the Seller may, upon not
less than 7 (seven) Days prior written notice by the Seller to the Buyer, suspend deliveries of eBid RLNG to the Buyer, until such breach is cured or terminate pursuant to this Article 14.4(b) to
the satisfaction of the Seller. Any such suspension shall apply with effect from the last Day on
which the notice is received (or deemed to have received) by the Buyer under this Agreement.
As a matter of illustration, if the Seller gives a 7-Day notice then the 7th Day following receipt
(or deemed to have received) by the Buyer of the notice shall be the Day from which
suspension shall commence, unless the breach which is the subject matter of the notice is cured
to the satisfaction of the Seller.

(b)

Notwithstanding the right of the Seller under Article 14.4 (a), if the Buyer breaches any of its
obligations under Article 9.5, the Seller may without prejudice to any other rights or remedies
that it may have under this Agreement or under Law, at its sole option, terminate this
Agreement upon not less than fourteen (14) Days prior written notice to the Buyer.

14.5

Other grounds for termination
If:
(a)

an order is made for the winding-up of either Party; or

(b)

creditors of either Party or other third parties initiate(s) any legal proceedings (save as
in the case of amalgamation or reconstruction, a notice of which has been given to the
other Party) for the winding-up or dissolution of such Party and such legal proceedings
are admitted by a competent court and continue without being dismissed or without
any injunction being granted over such proceedings for a period of 120 (one hundred
and twenty) Days by such court or the relevant appellant court; or

(c)

either Party or its shareholders approve in a duly convened shareholders or board
meeting (save as in the case of amalgamation or reconstruction, a notice of which has
been given to the other Party) the winding-up or dissolution of such Party; or

(d)

a liquidator, receiver, or similar officer is appointed for the whole or a material part of
the assets of either Party; or

(e)

either Party fails to remedy any material breach of this Agreement and, if that breach is
capable of remedy, fails to remedy that breach within 45 (forty five) Days of notice it
receives from the other Party of that breach;

then the other Party may, without prejudice to any of its claim, remedy, suit or right of action,
terminate this Agreement by notice in writing.
Page 26 of 44

<!-- page 27 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

14.6

Effect of Expiry or Termination

(a)

Upon termination of this Agreement, the respective rights and obligations of the Parties shall
cease to have any effect, subject to Article 14.6(b) below;

(b)

Termination of this Agreement for any reason shall not relieve or affect the rights or remedies
of either Party in relation to any accrued rights or unperformed obligations including Take or
Pay obligation under this Agreement, arising prior to or upon the date of such termination. The
provisions of this Agreement relating to such rights and remedies, and the exercise thereof,
shall survive the termination of this Agreement;

(c)

The Contract Year in which this Agreement terminates shall be deemed to end on the date of
such termination;

(d)

The Seller shall have the right to invoke the Letter of Credit and appropriate the proceeds
thereof, for any outstanding amounts due from the Buyer till the date of termination including
any payments due with respect to its Take or Pay obligations, except where this Agreement is
terminated by the Buyer in accordance with Article 14.1.

ARTICLE 15 - GENERAL PROVISIONS
15.1

Waiver
No waiver of any provision by any Party on any default by the other Party in performance of this
Agreement shall operate as a waiver of such default of that Party unless the same is in writing
and signed by duly authorized representatives or those Parties. No delay by either Party in
exercising its rights hereunder shall be treated as waiver thereof

15.2

Governing Law
This Agreement shall be governed by the laws of India, including, without limitation, of the
relevant Central/State Acts and the Rules, Regulations and Notifications issued and amended
from time to time there under. The courts at Delhi shall have sole and exclusive jurisdiction for
the purposes of this Agreement.

15.3

Consequential Damages
Except as otherwise specifically provided herein, neither Party shall be liable for any indirect,
incidental or consequential loss or damage or loss of opportunity or profits.

15.4

Confidentiality
Each Party agrees and undertakes that at all times such Party and its respective employees and
representatives shall keep in strict confidence all information and data furnished or obtained
pursuant to this Agreement, including the terms and conditions of this Agreement, except as
and to the extent that all the other Parties consent in writing to the disclosure of such data,
information or terms. This Article shall not apply to, data or information;
(a)

Which, at the time of its disclosure, is in the public domain as evidenced by printed
publication or otherwise;
Page 27 of 44

<!-- page 28 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

(b)

After it disclosure becomes part of the public domain by publication or otherwise
except through common fault of any Party or its respective employees or
representatives;

(c)

Which is required to be produced by law or before any governmental authority or the
Government Agency or any court or judicial authority of competent jurisdiction or the
rules of the stock exchanges on which the shares and other securities of a party are
listed;

(d)

Which is obtained by a party from a third party who is lawfully in possession of such
information or data and not subject to any contractual or fiduciary relationship which
would preclude its disclosure;

(e)

Where required by a bank or other financial institutions hereinafter referred to as
financier (which expression shall include the employees, agents and consultants of such
bank or other financial institutions) which is providing finance to the Party wishing to
disclose such information or data in whole or part on the security of a charge or other
encumbrance or other such disclosing Party’s interest in this Agreement, provided that
the financier has entered into a written Agreement with the disclosing Party agreeing to
keep such information secretly confidential; and

(f)

To bona fide consultants of the party provided that such consultants have entered into
a written Agreement/undertaking with the disclosing Party agreeing to keep the
information secretly confidential.

The provisions hereof shall survive for a period of three (3) years after the termination /expiry
of this Agreement.
15.5

Notices
(a)

Any notice, request, demand or other statement, document or communication required
or permitted to be given or provided for under this Agreement shall be in writing and in
English language and sent or delivered by hand or by registered airmail, postage prepaid, facsimile (confirmed by a copy sent by registered mail or courier) or e-mail and
shall be addressed to the Party to whom it is to be sent or delivered at the address of
such Party set out in this Article or such other address of such Party as such Party may
from time to time notify in writing to the other Parties and
(i)

The Seller
Zonal Head
GAIL (India) Limited
Fax:
Email:

(ii)

The Buyer:
……………
Fax:
Email:
Page 28 of 44

<!-- page 29 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

(b)

15.6

Confidential

All such Notices and communications shall, when telefaxed, couriered, hand delivered
or mailed shall be effective when received and when sent by email when confirmation
of its transmission has been recorded by the sender’s e-mail server. Except where
specifically and specially provided for otherwise in this Agreement, any consent
permitted by this Agreement shall be in writing and delivered by hand or sent by
facsimile transmission or courier or registered mail, return receipt requested.

Amendment
Any amendment to this Agreement or any of its provisions shall be valid and binding only if all
the Parties of this Agreement approve of it in writing and agree to its incorporation in this
Agreement under the signature and seal of person or persons duly authorized and empowered
by the Parties for that purpose or in the case of a waiver by the Party whose rights are waived.

15.7

Entire Agreement
This Agreement shall constitute the full Agreement between the Parties and shall supersede all
prior negotiations, representations, proposals and Agreement, whether oral or written,
regarding the subject matter of this Agreement.

15.8

Severability
If any portion or clause of this Agreement is deemed invalid or unenforceable, the remainder of
this Agreement shall survive and remain in full force and effect; provided however that if a
provision is held to be invalid or unenforceable, the Parties shall negotiate in good faith to
adopt a replacement provision to carry out, in effect, the Parties original intention to the extent
permitted by applicable laws.

15.9

Resale of e-Bid RLNG.
The Buyer shall not be entitled to sell this e-Bid RLNG to any third party including its Affiliates.

15.10 Consent
The Buyer and Seller hereby expressly declare and admit that the above provisions have been
read and understood to their satisfaction and are executing this Agreement out of their free will
and consent.

ARTICLE 16 - WARRANTIES AND INDEMNITIES
16.1

Seller’s representations and warranties
The Seller represents and warrants to the Buyer that, (i) as of the Supply Period, the Seller has
obtained all licenses, permissions, consents and authorizations from any Government Agency
and all management and shareholder approvals necessary to enable the Seller to perform its
obligations under this Agreement and all such necessary approvals, licenses, permissions,
consents and authorizations are valid and effective, and (ii) the performance of the obligations
hereunder by the Seller shall not violate or breach any contract or arrangement to which the
Seller is a party.

Page 29 of 44

<!-- page 30 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

16.2

Confidential

Seller’s tax indemnity
Provided that the Buyer is in compliance with each of its obligations under this Agreement that
are necessary to enable the Seller to pay when due any duties, taxes or service charges, etc.
payable by the Seller in accordance with the terms hereof, in the event that the Seller fails to
pay when due any such duties, taxes or service charges, etc. the Seller shall indemnify and hold
harmless the Buyer against and from any loss, damages, expenses and claims incurred by the
Buyer as a direct result of the Seller’s failure to pay such taxes, duties or service charges, etc. or
the late payment thereof.

16.3

Seller’s Covenants
The Seller shall ensure that all approvals, licenses, permissions, consents and authorizations
that are necessary to enable it to perform its obligations under this Agreement remain valid and
effective through the Term of this Agreement and shall obtain any additional approvals,
licenses, permissions, consents and authorization that are required to enable the Seller to
perform its obligations under this Agreement.

16.4

Buyer’s representations and warranties
The Buyer represents and warrants to the Seller that, as of the Supply Period, (i) the Buyer has
obtained all governmental licenses, permissions, consents and authorizations from any
Government Agency and all management and shareholder approvals as necessary to enable the
Buyer to perform its obligations under this Agreement and all such necessary approvals,
licenses, permissions, consents and authorizations are valid and effective and (ii) the
performance of the obligations hereunder by the Buyer shall not violate or breach any contract
or arrangement to which the Buyer is a party.

16.5

Buyer’s indemnity
The Buyer shall pay all applicable duties and taxes, services charges, etc. subsequent to the
purchase of e-Bid RLNG under this Agreement and shall indemnify and hold harmless the Seller,
the Seller's employees and agents against and from any and all loss, damages, expenses and
claims relating to e-Bid RLNG delivered by the Seller, under this Agreement, or for royalties,
taxes and duties, service charges, etc. or other direct charges thereon applicable on receipt or
after delivery of e-Bid RLNG at the Delivery Point.

16.6

Buyer’s Covenants
The Buyer shall ensure that all approvals, licenses, permissions, consents and authorizations
that are necessary to enable it to perform its obligations under this Agreement remain valid and
effective through the Term of this Agreement and shall obtain any additional approvals,
licenses, permissions, consents and authorization that are required to enable the Buyer to
perform its obligations under this Agreement.

16.7

Indemnities
(a)

The Buyer shall defend, indemnify and hold harmless Seller, its employees, directors
including thirty party, against any and all liability for death, injury or illness (arising out
of the operation of this Agreement) caused to or suffered by any employee of the Seller
or its Affiliates including thirty party, howsoever caused or arising (including the
negligent act or omission of the Seller, its servants or agents) and shall indemnify and
hold harmless the Seller against any and all costs, damages or expenses whatsoever
Page 30 of 44

<!-- page 31 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

incurred by the Seller in respect of any claims, demands, proceedings or cause of action
arising in connection with any such death, injury or illness caused or suffered by any
employee of the Seller or its Affiliates including thirty party.
(b)

the Seller shall defend, indemnify and hold harmless the Buyer, its employees, directors
including thirty party, against any and all liability for death, injury or illness (arising out
of the operation of this Agreement) caused to or suffered by any employee of the Buyer
or its Affiliates including thirty party, howsoever caused or arising (including the
negligent act or omission of the Buyer, its servants or agents) and shall indemnify and
hold harmless the Buyer against any and all costs, damages or expenses whatsoever
incurred by the Buyer in respect of any claims, demands, proceedings or causes of
action arising in connection with any such death, injury or illness caused of suffered by
any employee of the Buyer or its Affiliates including thirty party.

IN WITNESS WHEREOF, the representatives of the Parties to this Agreement being duly authorized have
hereunto set their hands and have executed these presents this …………….
Signed for an on behalf of
GAIL (India) Limited

Signed for an on behalf of
…………………..

By:

By: ………………

In the presence of:

In the presence of:

Page 31 of 44

<!-- page 32 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ANNEXURE 1 - SPECIFICATION OF E-BID RLNG
Typical Range of e-Bid RLNG Composition
S. No
1
2
3
4
5
6
7
8
9
10

Component
Range(Mole %)
Methane C1
Not less than 77%
Ethane C2
9-0.69%
Propane C3
4.5-0.03%
Butane C4
2.5-0%
Pentane C5
0.35-0%
Hexane C6
0.15-0%
Carbon Dioxide CO2
5%-0%
Nitrogen N2
1.5-0.51%
Total Non-Hydrocarbon- not more than 8.0 mole %
Total Sulphur including H2S – Not more than 10 PPM by weight (H2S content not more
than 4PPM by volume)

e-Bid RLNG shall, upon delivery, meet the following specifications:
(i)

Be reasonably free from dust (max. size 5 micron but which could be 10 micron during
commissioning period), gum, gum forming constituents;

(ii)

No free water will be present.

(iii)

Gross Heating Value of not less than 8500 Kcal/SCM.

Page 32 of 44

<!-- page 33 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

ANNEXURE 2

Confidential

- DELIVERY POINT

Delivery Point

Metering
facilities, etc.
by Seller

Facilities
owned /
arranged by
Buyer.

Plot Location:
Seller metering terminal:
Buyer:

Page 33 of 44

<!-- page 34 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ANNEXURE 3 - TEST PROCEDURES FOR METERING EQUIPMENT
1. The gas chromatograph used for the determination of e-Bid RLNG composition shall have make
& model approval for custody transfer by International Reputed Agency. Calibration gas used
should have traceability certificate to international standards and should meet requirement of
ISO-6142 or 6143.
2. Pressure, temperature, differential pressure transmitters etc. should be of accuracy of at least
+/- 0.25%.
3. The flow computers used should have make & model approval for custody transfer by
international reputed agency with audit trail facility.
4. Calibration of all primary and secondary instruments shall be as per requirement of relevant
standard.
5. Upon calibration :
A
If on calibration, the Seller's meter registers a variation of more than as stated above
or if the Seller's meter is out of service, the following procedure in order of priority
whichever is feasible for arriving at the computation of e-Bid RLNG during the period between
the last calibration and the present one shall be followed:

B

i)

By using the recording by the check meter of the Buyer if installed identical to
the Seller’s Meter or a Standard Meter and accurately registering; or

ii)

if A (i) is not possible by correcting the error if the percentage of error is
ascertainable by calibration, test or mathematical calculation; or

iiI)

if A (i) & (ii) both are not possible by estimating the volume of e-Bid RLNG /
Gas delivered by comparison with deliveries during period under similar
conditions when the Seller's meter was registering accurately.

The period to which the above corrections will apply will be as under;

i) If any period during which the Seller's meter has gone wrong is known or agreed upon that
will be the period to which the correction is to be applied.
ii) If the period is not known the correction shall be made for a period equal to half of the time
elapsed since the date of the preceding calibration test joint checking of meter, provided the
correction period does not exceed sixteen (16) days.

Page 34 of 44

<!-- page 35 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

ANNEXURE 4

Confidential

- TEST PROCEDURES FOR e-BID RLNG QUALITY MEASUREMENT

1.

Following standards may be referred for definition of terminology:
a) ISO 4006-Measurement of fluid flow in closed conduits-Vocabulary and symbols;
b) ISO 7504-Gas analysis-vocabulary.

2.

The methods for testing of the e-Bid RLNG being supplied at the point of measurement are as
following:
1. ISO 6974: Part 4- Natural Gas-Determination of composition with defined uncertainty by
gas chromatography
2. ISO 6975: Natural Gas- Extended analysis- Gas Chromatographic method;
3. ISO 10715- Natural Gas-Sampling guidelines;
4. ISO-6976 /ASTM 3588-D ( in conjunction with GPA 2145 (SI section) and GPA 2172)Determination of Net Heating Value, Gross Heating Value and specific gravity of Natural
Gas on the basis of gas composition.
5. ISO 12213/ AGA-8- For determination of compressibility of Natural Gas on the basis of gas
composition.
6. Determination of H2S, H2O and S contents in PPM at base measurement conditions is to be
done by valid methods defined by ISO standard to be notified by GAIL (I) Ltd from time to
time.

3.

The latest edition of all standards are to be used for carrying out the jobs. The no. of standard
may be changed to BIS standards as and when they are issued and if notified by Director of
Legal Metrology, Govt. of India, New Delhi.

Page 35 of 44

<!-- page 36 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

ANNEXURE 5

Confidential

- e-BID RLNG SALES AND PURCHASE NOTICE

Parties:
(1)
(2)

GAIL (INDIA) LIMITED (“Seller”)
_______________________ (“Buyer”)

1.

Agreement
This e-Bid RLNG Sales and Purchase Notice (eSPN) is issued pursuant to the terms and
conditions of the e-Bid RLNG Sales Agreement dated _______ executed between the Seller and
the Buyer (the “Agreement”).
Terms not defined in this eSPN shall have the meaning given in the Agreement.
The execution of this eSPN by the Parties shall form a valid and several obligations whereby the
Seller agrees to sell and deliver e-Bid RLNG to Buyer and Buyer agrees to purchase and take
delivery of and pay to Seller for such e-Bid RLNG, all in accordance with the Agreement and the
terms set out in this eSPN.

2.

Contract Quantity:
Total quantity of e-Bid RLNG agreed to be sold / purchased: ______ MMBtu.
In the event, the Buyer’s plant is located in Andhra Pradesh / Telangana, the above quantity
shall be subject to Seller’s Operational Flexibility including availability of equivalent quantity (in
MMBTU) of KGD6 gas and pipeline capacity in East West Pipeline for swapping under the
swapping mechanism. Further, reduction in availability of KGD6 gas would result in reduction in
e-bid RLNG Contract Quantity. Buyer agrees that the Seller shall be free from any obligations
including provisions of Article 6.3, direct and/or indirect losses arising out of such reduction in
e-Bid RLNG Contract Quantity.

3.

Daily Contract Quantity:
The Daily Contract Quantity (DCQ) to be made available for delivery by the Seller to the Buyer in
respect of each Day of the Supply Period shall be ____________ MMBtu.

4.

Price:
The Price payable by the Buyer to the Seller under the Agreement shall consist of the following
elements/components:
(a) Foreign currency component; and
(b) INR component.
Each of these elements/components is as follows:
(i) Foreign currency component (expressed in USD/MMBtu):
(a) LNG price including other charges paid by the Seller
Foreign currency component shall be indicative and shall vary on monthly basis depending upon
the actual cargo purchase price, other charges, etc. paid by the Seller, cost of swapping and/or
exchange rate variation. The Price, as finalized by the Seller on monthly basis, will be binding on
the Buyer.
Page 36 of 44

<!-- page 37 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

Any such change in the foreign exchange component shall be reflected in the relevant Invoice
and, if not already recovered under any prior Invoice, such amount shall be recovered as a debit
or credit, as the case may be, in the immediately succeeding Invoice.
(ii)

The INR component of the Price shall consist of:
a) Regasification charges: ____ Rs./MMBtu;
b) Marketing margin: ______ Rs./MMBtu;
c) Trunkline transmission charges: _____ Rs./MMBtu; and
d) Swapping cost _______ Rs./MMBtu (in case of swapping).
The trunkline transmission charges as indicated above shall be subject to change in Law
(including directives from Government Agency, any change in judicial/quasi-judicial
interpretation or application of any Law) and shall be binding on the Buyer.
Seller shall reconcile the regasification charges, trunkline transmission charges and other
charges on monthly basis based on actuals and terminal used for regasification of e-Bid
RLNG.
Taxes at actual, if applicable shall be charged on Transmission Charges.
Any change in the Transmission Charges shall be reflected in the relevant Invoice and, if not
already recovered under any prior Invoice, such amount shall be recovered as a debit or
credit, as the case may be, in the immediately succeeding Invoice. INR Component

The Price excludes all applicable taxes, duties and statutory levies.
5.

Supply Period:
From ………. To ………

6.

Start Date:

7.

In case the Buyer has multiple gas supplies at the Delivery Point the allocation of the same shall
be in the following order of nominations/ contracted quantity:
Priority
(1) _______
(2) _______

8.

Special Conditions to the Agreement:
(i)

Any disruption in KG D6 gas supplies shall be considered as a Force Majeure Condition.

This Sales and Purchase Notice agreed by:
GAIL (India) Limited as the SELLER

Authorised signatory

……………………….. as the BUYER

Authorised signatory

Page 37 of 44

<!-- page 38 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ANNEXURE 6 – FORMAT OF LETTER OF CREDIT
STANDARD TERMS & CONDITIONS OF LETTER OF CREDIT
1) Seller-GAIL, Buyer………………………………………………….…(to be mentioned in the Letter of Credit L/C)
2) This is a STANDBY IRREVOCABLE REVOLVING LETTER OF CREDIT (L/C) which revolves automatically for
the L/C amount for the next set of documents as soon as the negotiation of present set of document is
over and is valid up to ……………………………..for submission of documents for negotiation to the bank.
3) This Letter of Credit (L/C) is issued under the Gas Supply Contract (GSC)/Gas Transmission Agreement
(GTA)/Gas sales and transportation contract (GSTC)/ Spot Gas sales agreement dated ………………and will
be valid for all invoices/provisional invoices/debit notes etc. raised under the aforesaid agreement as
well as supplementary agreements, amendments and other addenda thereof.
4) This Letter of Credit (L/C) covers Supply / Transmission of Natural Gas (NG), Regassified Liquefied
Natural Gas (RLNG), Natural Gas Panna Mukta Tapti (NG PMT/PMT Gail Gas), Ravva and any other gas
supply / transmitted by GAIL to the buyer through pipeline as well as Minimum Guaranteed Off take
(MGO), Take or Pay Amount, Ship of Pay charges, Interest on delayed Payment, Penalty, Over drawl,
Overrun and Imbalance Charges, Taxes, duties and charges therein, Difference in price, transportation
charges, marketing margin etc.
5) Debit notes shall include payment against Minimum Guaranteed Off take (MGO), Take or Pay Amount,
Ship of Pay charges, Interest on delayed payment, Penalty, Over drawl, Overrun and Imbalance Charges,
Taxes, duties and charges therein, difference in gas price, transportation charges, marketing margin etc.
6) All bank charges including negotiation, handling and interest charges will be borne by the opener of
Letter of Credit (L/C) i.e. by the buyer.
7) Documents can be presented at any time after raising of invoices/ provisional invoices/ debit notes etc.
but within the validity period of the Letter of Credit (L/C).
8) Payment against the Letter of Credit (L/C)shall be released immediately on presentation of certified
copies of invoices/provisional invoices/debit notes along with draft/hundi in duplicate by GAIL (India)
Limited. Letter of Credit (L/C) shall cover requests against part payments.
9) If the payment to our banker is not made at sight of documents, interest @ SBI Base Rate+6.25% p.a.
would be payable.
10) Draft / Hundi drawn under the Letter of Credit (L/C) would be marked the L/C no. …………………
……..dated…………………
11) This Standby Irrevocable Letter of Credit (L/C) is available for negotiation directly with the issuing
Bank/Branch or through GAIL’s Banker without recourse to drawers.
12) The Issuing Bank undertakes not to amend any of the above standard terms and conditions without
prior consent of beneficiary (GAIL) during the validity of Letter of Credit (L/C).
Page 38 of 44

<!-- page 39 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

13) The face value of this Letter of credit( L/C)shall be equal to 110% value of :
Gas supply during three fortnights, where value of one fortnight is 16 days supply of gas at maximum
contracted quantity plus transmission charges, any other charges and taxes & duties thereon, etc.
14) Exchange Rate for calculation of Value of Letter of Credit (L/C) will be prevalent RBI reference rate on
the date of opening of LC.
15) The Letter of Credit (L/C) will automatically be reinstated after invocation i.e. Issuing Bank shall
unconditionally and irrevocably undertake to the beneficiary that, following any payment pursuant to a
demand against the LC, Issuing Bank shall automatically and immediately thereafter reinstate the value
of this Letter of Credit (L/C) by the amount paid in order to restore this letter of credit to the face value.
The Issuing bank shall notify the beneficiary immediately after any reinstatement of this Letter of Credit
(L/C) to the face value.
16) The validity of letter of credit (L/C) will be for a period of one year and Issuing Bank shall renew this
letter of credit not later than 30 days before the expiry of this Letter of Credit (L/C).

Page 39 of 44

<!-- page 40 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ANNEXURE 7 – FORMAT OF UNDERTAKING
We, ______________________ (Name of Company), _________________ (Location of Plant), hereby
undertake that:
1. ___________________________ *Name of the Power Plant/Project+ is a Generating Company” as
defined in section 2(28) of the Electricity Act, 2003, engaged in the business of supplying electrical
energy;
2. ___________________________ *Name of the Power Plant/Project+ is not a “Captive Generating
Plant” as defined in section 2(8) of the Electricity Act, 2003;
Further, we undertake that:
1. The e-Bid RLNG being sold and supplied to us by GAIL (India) Limited will be utilized for generating
and supplying electrical energy.
2. We will obtain and provide to GAIL (India) Limited (“GAIL”), the End Use Certificate in terms of
Annexure III of Office Memorandum.
In case, gas from more than one such cargo is supplied in any fortnight then separate certificates
pertaining to each imported LNG cargo (as informed by GAIL) shall be obtained and provided to
GAIL.
3. Further, we acknowledge that in the event we fail to provide to GAIL, End Use Certificate within the
stipulated period, GAIL shall be entitled to recover customs duty payable on the quantity of e-Bid
RLNG consumed / supplied to us during the given period by invoking bank guarantee.

For _______________________ [Name of Company}
___________________________[Name of Power Plant/Project]

Authorised Signatory
Date: [******]

Page 40 of 44

<!-- page 41 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ANNEXURE 8 - FORMAT OF INDEMNITY BOND
We, ______________________ (Name of Company), _________________ (Location of Plant), hereby
certify that:
1

_________________ *Name of the Power Plant/Project+ is a “Generating Company” as defined in
section 2(28) of the Electricity Act, 2003, engaged in the business of supplying electrical energy;

2

_________________ [Name of the Power Plant/Project+ is not a “Captive Generating Plant” as
defined in section 2(8) of the Electricity Act, 2003;

We, further, undertake that we shall comply with all the provisions, as applicable, of Govt. of India
Notification No. 12/2012-Customs dated 17.03.2012 (as amended vide Notification No. 25/2013Customs dated 08.05.2013, vide Notification No. 36/2013-Customs dated 22.07.2013 and vide
Notification No. ________ dated ______) and undertake to indemnify GAIL (India) Limited from any
penal action / demand of duty, interest & penalty, etc. for this transaction of import and supply of
LNG/RLNG to us.

For _______________________ [Name of Company}
___________________________[Name of Power Plant/Project]

Authorised Signatory
Date: [******]

Page 41 of 44

<!-- page 42 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

ANNEXURE 9 - FORMAT OF INDEMNITY BOND
(To be furnished by customers receiving e-Bid RLNG through swapping mechanism)
INDEMNITY BOND
(To be furnished in Stamp paper as per Stamp Act)
This deed of Indemnity executed by ______________________________ hereinafter referred to as
'Indemnifier' which expression shall, unless repugnant to the context or meaning thereof, include its
successors, administrators, representative and assignees in favour of M/s GAIL (India) Limited,
hereinafter referred to as the ‘Indemnified’ which expression shall unless repugnant to the context of
meaning thereof, include its successors and assignees witnesses us to.
Whereas the Indemnified herein has entered into a Spot Gas Sale Agreement with the Indemnifier
herein a contract for the supply of e-Bid RLNG on terms and conditions set out, inter alia, in the e-Bid
RLNG Sales Agreement dated _________.
Whereas
(a) Independent Power Producers having their plants located in Andhra Pradesh / Telaangana
(hereinafter APIPPs) including the Indemnifier have requested the Seller for supply of e-Bid
RLNG. However, physical flow of e-Bid RLNG from LNG terminals located on West Coast of India
to Oduru (in Andhra Pradesh) through M/s RGTIL’s East West Pipeline network is not feasible
due to technical constraints.
(b) The KG D6 gas allocated to __________________ (Name of Fertilizer Unit) is being transported
by M/s RGTIL from Gadimoga (in Andhra Pradesh) and is fed into Indemnified’s pipeline system
at Mhaskal/Ankot (as applicable) for further delivery at ________ plant at __________.
(c) In order to supply RLNG to APIPPs, Indemnified in terms of guidelines issued by MOPNG for
swapping of natural gas vide MOPNG’s letter No L-12011/10/2011-GP dated 15.03.2012,
MOPNG letter no. L-12011/5/2012-GP dated 31.05.2013 and letter no. L-12011/5/2012-GP
dated 23.10.2013 has worked out a supply scheme. Under the aforesaid scheme, the following
is envisaged and terms are agreed by the Indemnifier that :
(i) The current KG D-6 gas supply quantity of __________________ (Name of Fertilizer
Unit) shall be purchased by Indemnified from __________________ (Name of Fertilizer
Unit) at Gadimoga.
(ii) Indemnified shall swap this gas (delivered at Gadimoga for supply to APIPPs) with the
__________________ (Name of Fertilizer Unit) and supply equivalent quantity of RLNG
in energy terms (MMBTU) to RCF in lieu of __________________ (Name of Fertilizer
Unit) KG D6 quota of gas.
(iii) The net delivered price of gas to __________________ (Name of Fertilizer Unit) shall
remain same as the price being paid by __________________ (Name of Fertilizer Unit)
presently, to maintain cost neutrality.
(iv) This arrangement is a temporary and shall be applicable only during the existence of
the e-Bid RLNG requirement by APIPPs and validity of the commercial agreements
entered between __________________ (Name of Fertilizer Unit) and Indemnified to
effect the supplies to APIPPs and any other directions of the Government

Page 42 of 44

<!-- page 43 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

Whereas, clauses of the above mentioned e-Bid RLNG Sales Agreement dated _________ provides for
indemnification by the Indemnifier to the Indemnified against any liability like increased incidence of tax
/ any statutory tax claims etc / transportation tariff incurred directly or indirectly arising out of the swap
transaction as mentioned above and supply of e-Bid RLNG by Indemnified to Indemnifier pursuant to
above mentioned e-Bid RLNG Gas Sales Agreement and the eSPN(s) executed thereunder. Further,
clause no. 8.3 of the above referred e-Bid RLNG Sales Agreement provides for guidelines on swapping
issued by MoPNG ref. No. L-10111/10/2011-GP dated 15.3.2012.
In view of the above consideration, the Indemnifier hereby irrevocably agrees to indemnify the
Indemnified that in the event of any Liability like increased incidence of tax / statutory tax claims etc./
transportation tariff incurred by the Indemnified arising out of the swap transaction agreed between
them and supply of e-Bid RLNG by Indemnified to Indemnifier pursuant to above mentioned e-Bid RLNG
Gas Sales Agreement and the eSPN(s) executed thereunder, the Indemnifier shall pay for such amount
to the Indemnified, within the time specified by the Indemnified or reimburse such amount paid by the
Indemnified in respect of his contractual obligations emanated from the already referred e-Bid RLNG
Gas Sales Agreement immediately thereafter without any demand and dispute.
This indemnity shall be in force from the date of signing of this Indemnity Bond upto …….years from the
expiry of the e-Bid RLNG Gas Sales Agreement.
In Witness whereof the Indemnifier hereto acting through its properly constituted representative have
signed and executed this Indemnity Bond for and on behalf of Indemnifier on this _____day of
__________ 2015 at ______________.

Name :
Designation :

WITNESSES:
1.
2.

Page 43 of 44

<!-- page 44 -->

Draft
Disclaimer: This draft eRSA is for reference purpose only and the final eRSA document may vary.

Confidential

TABLE OF CONTENTS
ARTICLE 1
ARTICLE 2
ARTICLE 3
ARTICLE 4
ARTICLE 5
ARTICLE 6
ARTICLE 7
ARTICLE 8
ARTICLE 9
ARTICLE 10
ARTICLE 11
ARTICLE 12
ARTICLE 13
ARTICLE 14
ARTICLE 15
ARTICLE 16
ANNEXURE 1
ANNEXURE 2
ANNEXURE 3
ANNEXURE 4
ANNEXURE 5
ANNEXURE 6
ANNEXURE 7
ANNEXURE 8
ANNEXURE 9

DEFINITION AND INTERPRETATION
TERM
e-BID RLNG SALE AND PURCHASE
DELIVERY AND PRESSURE
e-BID RLNG QUALITY
DELIVERY OBLIGATIONS
FACILITIES AND MEASUREMENTS
PRICE
BILLING AND PAYMENT
GENERAL INDEMNITY
SOLE EXPERT AND DISPUTE RESOLUTION
NOT USED
FORCE MAJEURE
SUSPENSION AND TERMINATION
GENERAL PROVISIONS
WARRANTIES AND INDEMNITIES
SPECIFICATION OF e-BID RLNG
DELIVERY POINT
TEST PROCEDURES FOR METERING EQUIPMENT
TEST PROCEDURES FOR E-BID RLNG / GAS QUALITY MEASUREMENT
e-BID RLNG SALES AND PURCHASE NOTICE
FORMAT OF LETTER OF CREDIT
FORMAT OF UNDERTAKING
FORMAT OF INDEMNITY BOND
FORMAT OF INDEMNITY BOND (FOR SWAPPING)
TABLE OF CONTENTS

3
7
7
7
8
8
10
15
16
18
19
23
23
25
27
29
32
33
34
35
36
38
40
41
42
44

Page 44 of 44
