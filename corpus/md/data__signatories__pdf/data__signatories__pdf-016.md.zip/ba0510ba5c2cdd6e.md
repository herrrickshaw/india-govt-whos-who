---
doc_id: "ba0510ba5c2cdd6e"
source_url: "https://mnre.gov.in/static/uploads/2026/10/3351d0198855bad0fbbaee7a512500d6.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "FAQs on MNRE’s O.M. dated 28.07.2025 regarding ALMM for Solar PV cells"
date: "2026-07-28"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7fe7a5f9dfaec77b"
---

<!-- page 1 -->

No. 283/64/2025-GRID SOLAR
भारत सरकार / Government of India
नवीन और नवीकरणीय ऊजा मं ालय / Ministry of New & Renewable Energy (MNRE)
ि ड और ऊजा िवभाग / Grid Solar Power Division
Atal Akshay Urja Bhawan,

Lodi Road, New Delhi – 110003
Date: 23rd September 2025
OFFICE MEMORANDUM

Sub: FAQs on MNRE’s O.M. dated 28.07.2025 regarding ALMM for Solar PV cells

1. Para 5, 6 & 8 of MNRE’s O.M. No. 283/59/2024-GRID SOLAR dated 28.07.2025
regarding Implementation of ALMM for Solar PV cells, states as follows:
Para 5:
“For all projects (including the projects bid out following the Guidelines issued by
the Central Government under Section 63 of the Electricity Act 2003) which
are mandated to use solar PV modules from ALMM List-I (for solar PV modules),
if the last date of bid submission is on or before the cut-off date, such projects
shall be mandated to use solar PV modules from ALMM List-I (for solar PV
modules) but will stand exempted from the requirement of using solar PV cells
from ALMM List-II (for solar PV cells), irrespective of their date

of

commissioning, i.e. such projects will be exempt from the requirement of using
solar PV cells from ALMM List-II, even if their date of commissioning is beyond
1st June 2026.
There shall be no relaxation in Domestic Content Requirement (DCR)
provisions, wherever applicable in respect of MNRE’s Schemes/ Programs
like Components B&C of PM-KUSUM, PM Surya Ghar: Muft Bijli Yojana and
CPSU Scheme Phase-II.
Explanation: "Cut-oﬀ date" for this purpose is the date, which falls exactly
after 1 month of the publication of ALMM List-II for solar PV cells. For
instance, If the ALMM List for Solar Cells is published on Aug 1st 2025, then
the cut-off date shall be Sep 1st 2025.”

<!-- page 2 -->

Para 6:
“All projects (including the projects bid out following the Guidelines issued by the
Central Government under Section 63 of the Electricity Act 2003) that are
covered under ALMM and where the last date of bid submission falls after the
cut-oﬀ date as mentioned above, shall have a clause in their tender documents
/ Request for Selection (RfS) documents that the solar PV modules and solar
PV cells used in such projects shall be from the models and manufacturers
included in ALMM List-I (for solar PV modules) and ALMM List-II (for solar PV
cells) and this condition will have to be followed

irrespective of the date of

commissioning, i.e. even if such projects get commissioned prior to 1st June
2026. In case of such tenders which have been issued prior to the date of
issuance of this order, but the last date of bid submission falls after the cut-oﬀ
date as mentioned above, the concerned bidding agency would issue an
amendment to the tender document to include provisions stating that bidders
shall take into account the provisions of ALMM for solar PV cells while submitting
their bids.”
Para 8:
Net-Metering Projects and Open Access RE Power Projects are mandated to
use solar PV modules enlisted in ALMM, unless such projects are exempt
from ALMM in accordance with provisions of MNRE’s O.M. No. 283/54/2018GRID SOLAR-Part(5) dated 07.10.2022, clarified and reiterated by MNRE’s
O.M. No. 283/54/2018-GRID SOLAR-Part(2) dated 14.10.2024, MNRE's
O.M. 1/74/2023-NT dated 27.05.2024, or any other O.M./Order/Instruction from
MNRE for exemption from ALMM. These Net-Metering and Open Access RE
Power Projects which are mandated to use ALMM enlisted modules, will stand
exempted from the requirement of using solar PV cells from ALMM List-II if
such projects get commissioned prior to 1st June 2026. All the Net-Metering
Projects and Open Access RE Power Projects which get commissioned on or
after 1st June 2026, shall have to mandatorily source their solar PV modules
from ALMM List-I and solar PV cells from ALMM List- II.

2. The first version of the ALMM List-II for solar PV cells was issued on 31st July 2025,
thereby fixing the aforesaid “Cut-off date” as 31st August 2025.

<!-- page 3 -->

3. In order to clarify on various queries being raised by various stakeholders w.r.t. aforesaid
and

associated

provisions w.r.t. ALMM for solar PV cells,

few Frequently Asked

Questions (FAQS) and responses thereto are hereby being issued, as per Annexure.

4. This issues with the approval of Secretary, MNRE.

Saiss
(Priya)

Scientist-D
Email: priya.mnre@gov.in
To: All Stakeholders

Copy to: Director (Technical), NIC, MNRE, for uploading on MNRE's website

<!-- page 4 -->

Annexure
Sl.
Question
Answer
No.
1. Which projects are covered under Only models and manufacturers, of solar PV
ALMM for solar PV modules?

modules, enlisted in ALMM (Approved List
of Models &

Manufacturers) List-I, are

eligible for use in Government Projects/
Government assisted Projects/ Projects
under Government Schemes

&

Programmes, Open Access/ Net- Metering
Projects, installed in the country, including
Projects set up for sale of electricity to
Government under the Guidelines issued
by Central Government under section 63 of
Electricity

Act,

2003

and

amendment

thereof. The word "Government" shall
include

Central

Governments,

Government,

Central

Enterprises, State

State

Public

Public

Sector

Sector

Enterprises and, Central and State
Organizations / Autonomous bodies.

2.

Which

projects

are

covered

under ALMM for solar PV cells?

All projects covered under ALMM for solar
modules are covered under ALMM for solar
cells, subject to conditions specified in
MNRE’s

O.M.

SOLAR

No.

283/59/2024-GRID

dated

28.07.2025 which has been issued as
modification

to

283/59/2024-GRID

MNRE’s
SOLAR

O.M.

No.

dated

09.12.2024.
The major provisions/ conditions already
stated above, are re-iterated below in
simplified form:

<!-- page 5 -->

a. For projects awarded through bidding,
if last date of bidding is on or before the
cut-oﬀ date of 31st August 2025, the
projects are exempt from ALMM for solar
cells, else not. Thus, the applicability of
this provision is to bids which were live as
on 28.7.2025.

b. For Net-Metering & Open Access
Projects,

if

commissioned

prior

to

Eﬀective Date of 1st June 2026, the
projects are exempt from ALMM for solar
cells, else not.
3.

What

are

Domestic

Content In MNRE’s Schemes of CPSU Scheme

Requirement (DCR) provisions in Phase-II. Components-B&C of PM KUSUM
respect of solar PV cells and modules and PM Surya Ghar: Muft Bijli Yojana, there
under certain Schemes of MNRE?

are Domestic Content Requirement (DCR)
provisions in respect of solar PV cells and
modules wherein it is mandated to use
domestically manufactured solar PV cells
and modules.
The Domestic Content Requirement (DCR)
provisions in respective Schemes are
governed by the Scheme Guidelines of the
respective

Schemes

including

various

clarifications / amendments issued thereto
and not by the orders / O.M.s pertaining
to ALMM.
4.

If the last date of bid submission

MNRE’s O.M. No. 283/59/2024-GRID

was after 09.12.2024 but prior to

SOLAR dated 28.07.2025, which modified

28.07.2025 will the exemption from

the MNRE’s O.M. No. 283/59/2024-GRID

ALMM List-II (for solar PV cells) be

SOLAR

applicable?

issuance of first list of ALMM for solar PV

dated

09.12.2024,

and

the

<!-- page 6 -->

cells on 31.07.2025, has eﬀectively shifted
the cut-oﬀ date for applicability of ALMM for
solar PV cells on projects awarded through
bidding, from 09.12.2024 to 31.08.2025.
However, the aforesaid MNRE’s O.M. of
28.07.2025

does

NOT

directly

/

automatically relax the bid conditions in
tenders wherein the last date of bid
submission was between 09.12.2024 and
28.07.2025. Thus, if the bid conditions in
tenders

where

the

last

date

of

bid

submission was on or after 09.12.2024 and
prior to 28.07.2025, provided for usage of
solar PV cells from ALMM list-II for solar PV
cells, such conditions will remain valid.
In case, last date of bid submission was
after 09.12.2024 but before 28.07.2025 and
Letter of Award (LoA) has been issued prior
to 31.08.2025, the bid inviting entity who
has issued the Letter of Award(s) shall
clarify

the

above position to the LoA

awardees explicitly stating that the bid
conditions prevalent at the time of bid
submission shall remain valid and issuance
of MNRE’s aforesaid O.M. of 28.07.2025
shall not be construed as a relaxation in bid
conditions for such tenders.
Similarly,

in

case,

last

date

of

bid

submission was prior to 28.07.2025 but
reverse-auction is after 28.07.2025, the bid
inviting/ reverse-auction conducting entity
shall clarify the above position to the bidders
and shall conduct the reverse auction with
the original bid conditions.

<!-- page 7 -->

5.

Where can one find ALMM List-I

ALMM List-I (for solar PV modules) and

(for solar PV modules) and ALMM

ALMM List-II (for solar PV cells) can be

List-II (for solar PV cells)?

found

on

MNRE’s

website

(https://mnre.gov.in) through following
path:
Home > Programmes & Divisions >
Solar > Manufacturing > Approved List of
Models & Manufacturers (ALMM)
6.

MNRE’s

Any order of ALMM, including MNRE’s

Schemes, which were covered

O.M. No. 283/59/2024-GRID SOLAR

under

dated

Are

projects

under

Domestic

Content

09.12.2024,

modified

vide

Requirement (DCR) provisions as

MNRE’s O.M.

per MNRE’s Schemes and were

GRID SOLAR

thus mandated to use domestically

respect of ALMM for solar PV cells, do

manufactured solar PV cells and

not relax any provisions pertaining to

modules,

exempt

No.
dated

283/59/202428.07.2025,

in

from

using

usage of domestically manufactured

domestically manufactured

solar

solar PV modules and domestically

PV cells if the last date of bid
submission is prior to 09.12.2024 or
if the last date of bid submission is
prior to 31.08.2025?

manufactured solar PV cells in any of
MNRE’s Schemes

including

CPSU

Scheme Phase-II, PM Surya-Ghar Muft
Bijli Yojana and Components B&C of PMKUSUM. However, under component C
of PM-KUSUM, the relaxation from using
domestically manufactured solar PV cells
was available for those projects where
Letter of Award was issued on or before
31.03.2024 and this exemption will
continue to remain valid but those
projects in component-C of PM-KUSUM,
where Letter of Award was issued after
31.03.2024, irrespective of the date of
bid submission, will continue to be
mandated

to

use

domestically

manufactured solar PV modules and
domestically manufactured solar PV

<!-- page 8 -->

cells.

7.

Whether ALMM for solar PV cells is

Yes. ALMM for solar PV cells, is

also applicable for projects which

applicable for ALL the projects which are

are

under any Scheme / Programme of

under

any

Scheme

/

Programme of State Government

Central

/ UT Administration but are not

Government

availing any financial assistance

irrespective of whether or not they are

from the Central Government?

availing any financial assistance from the
Central

Government
/

UT

provisions of MNRE’s
09.12.2024,

State

Administration,

Government,

283/59/2024-GRID

/

subject

to

O.M.

No.

SOLAR

dated

modified

vide

MNRE’s

O . M . No. 283/59/2024-GRID SOLAR
dated 28.07.2025 and any clarifications /
amendments thereto.
8.

Is ALMM for cells applicable for

Yes, ALMM for cells is applicable to

project

projects selling electricity to Government

selling

electricity

to

Government under Section 62 of

under Section 62 of the Electricity Act.

the Electricity Act?
9.

Whether ALMM for Solar PV Cells

For all Net-Metering/Open Access, RE

is applicable for transfer of existing

power projects, commissioned before the

Captive Solar Projects under Open

cut-oﬀ date of 1st June 2026, and

Access where the project was

compliant with ALMM List-I (for solar

commissioned before 01.06.2026

modules), as on such Cut-oﬀ date, their

with

ALMM

List-I

compliant

modules, but fresh open access
permission is sought by the new
owner

after

the

notification date?

ALMM

List-II

original ALMM-I compliance will remain
valid in case ownership transfer occurs
on or after 01.06.2026.
Such projects shall not be mandated for
compliance to ALMM List-II (for solar
cells).
However,

in

modifications/additions,

case

any

in

the

commissioned capacity are undertaken

<!-- page 9 -->

post the cut-off date, the Projects shall be
mandated to follow ALMM List-II (for
solar cells) for such modification/addition
in capacity of the project.
10.

Based

For projects where the last date of bid

Competitive Bidding Process for

submission is after the cut-oﬀ date of

Procurement of:

31.08.2025, the projects are covered

Guidelines

for

Tariﬀ

under ALMM for solar cells, however, if
 Power from Grid Connected
Solar PV Power Projects /

already

 Power from Grid Connected
 Power from Grid Connected
 Firm and Dispatchable Power
Renewable

Connected

Energy

Power

Projects with Energy Storage
Systems;
issued under Section 63 of the
Electricity Act, 2003, provide that
developers

who

have

already

commissioned their plants or are in
process of constructing such plants
and have untied capacity may also
participate in the bid.
Is ALMM for solar cells applicable
for such projects if they have been
commissioned

with

solar

PV

modules which are not compliant to
ALMM for solar cells?

project

with

commissioning achieved on or prior to
project shall be exempt from the purview
of ALMM for solar cells.

Wind Solar Hybrid Projects /
Grid

commissioned

the cut-oﬀ date of 31.08.2025, such

Wind Power Projects /

from

the project is participating in the bid as an
