---
doc_id: "b9f4a5b13cfcbc1b"
source_url: "https://powermin.gov.in/static/uploads/2025/07/ce019c9f6d1d121e2b36bffe9bc94ab7.pdf"
ministry: "Power"
title: "MBDs  for procurement of power under long term from thermal stations set up on Design, Build, Finance, Operate and Transfer (DBFOT) basis issued on 20th Sep 2013 -RFQ, RFP, Overview of the Model Power Purchase Agreement"
date: "2013-09-20"
pages: 142
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "630a738838d82f06"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

Overview of the Model Power Purchase
Agreement
To meet the infrastructure deficit, the Twelfth Five Year Plan envisages aPrivate investment
renewed thrust on investment in infrastructure, with greater participation from to play a key role
the private sector. Of the projected investment in infrastructure, about 29 per
cent is envisaged in the power sector, of which about 47 per cent is expected
from the private sector. Bulk of the private investment in power sector will be in
the generation segment.
Power projects have been witnessing a significant interest from both domestic as A comprehensive
well as foreign investors following the policy initiatives taken by the framework is a preGovernment of India. However, the actual inflow of investment has been slowerrequisite for PPP in
electricity generation
than expected, and future prospects would depend on adoption of a
comprehensive policy and regulatory framework necessary for addressing the
complexities of Public Private Partnerships (PPP) while balancing the interests of
Utilities and investors. To this end, a precise policy and regulatory framework is
being spelt out in this Model Power Purchase Agreement (MPPA).
The framework contained in the MPPA addresses the issues which are important
for investors as well as for limited recourse financing of debt. These issues
include mitigation and unbundling of risks; allocation of risks and rewards;
symmetry of obligations between the principal parties; precision and
predictability of costs and obligations; reduction of transaction costs; force
majeure; and termination. It also addresses other important concerns such as
consumer protection, independent monitoring and dispute resolution.
The MPPA provides the basis for optimal utilisation of resources on the one
hand and adoption of international best practices on the other. The objective is to
secure value for public money while providing reliable and cost-effective
electricity to the consumers.
Elements of financial viability
The three critical elements that determine the financial viability of generation Need to reduce
projects are the concession period, fuel costs and capital costs. The concession capital costs
period for a generation project should be fixed keeping in view the expected life
of the generating plant. It could be fixed for a period of about 30 years, including
the construction period, with a provision for extension of 15 years at the option
of either the Concessionaire or the Utility. Yet another extension of upto 15 years
can be undertaken if both the parties so agree. This timeframe should enable a
robust project structure. So far as the Fuel Charge is concerned, the MPPA
makes it a pass through, subject to appropriate safeguards, which would address
a major risk faced by power producers due to uncertainty relating to fuel prices
over the medium and long term. Since two of the three parameters stated above
would be virtually pre-determined, capital cost is the variable that will determine
the financial viability of a Power Station. Adoption of cost-effective

<!-- page 5 -->

specifications would, therefore, be essential for reducing capital costs that would
ensure a competitive Fixed Charge.
Fixed Charge
The Utility shall pay to the Concessionaire a Fixed Charge, determined through Fixed Charge to be
competitive bidding, for availability of the Power Station. The Fixed Charge competitive
determined for each accounting year shall be revised annually to reflect 30 per
cent of the variation in a composite index comprising WPI and CPI. Since
repayment of debt would be substantially neutral to inflation, the said indexation
of 30 per cent is considered adequate. A higher level of indexation is not
favoured, as that would impose an unjustified burden on the consumers. Such
higher indexation would also add to uncertainties in the projections relating to
returns on investment. Further, an annual reduction of 2 per cent in Fixed Charge
is being stipulated so that the benefit of a depreciated asset is passed on to the
consumers.
Fuel Charge
Fuel Charge is the amount payable by the Utility to the Concessionaire for theFuel Charge to be a
fuel utilised in generation of electricity. Since the risk of variation in fuel pricepass through
cannot normally be managed by the Concessionaire, it must be passed on to the
Utility, which, in turn, will have to reflect it in the distribution tariff. Since pass
through of Fuel Charge affords full protection to the Concessionaire against
potential losses on account of a rise in fuel prices, it follows that the benefit of
reduced or concessional fuel prices cannot be retained by the Concessionaire. As
a result, Fuel Charge cannot be a profit centre for the Concessionaire and the
principles for determination of Fuel Charge must ensure that costs are recovered
on the basis of actuals, assuming that the Concessionaire would function with the
efficiency expected of a prudent and diligent operator.
The framework contained in the MPPA provides alternative formulations for
determination of fuel costs depending on the source and pricing of fuel supplies.
While coal supplies from Coal India will carry a regulated price, other supplies
would have to be procured either from captive mines or from the open market.
Each category of supply is, therefore, covered through respective formulations.
In case where fuel is to be procured from captive mines to be allocated by or on
behalf of the Utility as a part of the Power Station, the cost of fuel may be fixed
upfront with reference to the price charged by Coal India. Assuming a
comparatively higher level of efficiency, the fuel cost payable to the
Concessionaire may be fixed between say, 75 and 100 per cent of the Coal India
price prevailing at the time of bidding, with appropriate indexation over the
concession period.
Where captive mines have been allocated independently, a similar formulation,
as indicated in the foregoing paragraph, may be adopted with an added option of
allowing the bidders to quote an even lower fuel cost which may be further
limited to the costs determined by the Appropriate Commission.

<!-- page 6 -->

When imported fuel is to be used, reliance should be placed on pre-selected coal
indices used widely in international supplies of coal, but always subject to the
actual cost incurred by the Concessionaire. However, if bids are invited from
producers having captive mines abroad, a ceiling equivalent to upto 90 per cent
of the price of Fuel computed with reference to a pre-specified coal index could
be prescribed with appropriate indexation over the concession period. In all cases
of imported fuel, the foreign exchange risk would have to be borne by the Utility
as the Concessionaire would have no means to hedge such risk on a long-term
basis.
Owing to some uncertainty in the prospects, extent and nature of coal supply by
Coal India Limited, the provisions relating to coal to be procured through linkage
from Coal India have been kept in square brackets as they may need further
deliberations.
Station Heat Rate
Conversion of fuel into electricity shall be computed on the basis of the Station Incentive for improved
Heat Rate (SHR) which must conform to pre-determined specifications. As the Station Heat Rate
fuel charge would be a pass through, adhering to the prescribed SHR would be
necessary in order to safeguard the interests of the Utility. The MPPA also
provides for incentives in the form of an enhanced Fixed Charge if the
Concessionaire is able to improve on the pre-specified Station Heat Rate.
Incentivising an improved SHR would be a signal for achieving greater
efficiency in the interest of saving fuel.
Fuel Supply Agreement
As a condition precedent, the Concessionaire shall execute a Fuel Supply FSA to be a condition
Agreement (FSA) containing the key elements specified in the MPPA, thereby precedent
aligning the principal provisions of these two contracts. The FSA shall provide
the requisite assurance to the Utility for supply of fuel sufficient to generate a
pre-determined quantum of electricity.
Additional Fuel Supply
In the event of inadequate fuel supply under a Fuel Supply Agreement (FSA), the
Concessionaire shall make best efforts to identify additional sources of fuel
supply to meet such fuel shortage. The Concessionaire shall notify the Utility of
the landed cost of such additional fuel and shall demonstrate that it will be
procured at the best prices available. If the proposed landed cost is acceptable to
the Utility and the Appropriate Commission, the Concessionaire shall procure
such additional fuel for the agreed price and quantity.
Minimum Fuel Stock
The Concessionaire shall maintain a minimum stock of fuel, which is sufficient
for production of electricity and supply thereof to the Utility for a continuous
period of 10 days. In the event of fuel shortage, an amount equal to 70 per cent
of the Fixed Charge shall be payable in respect of the non-availability arising out

<!-- page 7 -->

of such fuel shortage. In other words, the Concessionaire’s risk of fuel supply
will be mitigated to the extent of 70 per cent.
Concessional Fuel
Fuel which is procured by the Concessionaire through any form of concessional, Pre-emptive rights
preferential or captive allocation or sale by a Governmental Instrumentality shall on Concessional Fuel
be deemed as Concessional Fuel and earmarked for the benefit of the Utility.
This will not include any fuel which is procured on the basis of market
determined prices. If any Concessional Fuel, which is surplus to the requirement
of the Utility, is utilised for production of electricity for sale to other buyers, the
Concessionaire shall, in lieu of the use of such Concessional Fuel, pay to the
Utility for each unit of electricity sold, a revenue share equal to the higher of: (a)
Fixed Charge, and (b) 30 per cent of the gross sale revenue accrued from such
buyers.
Availability and Despatch of Power Station
The Concessionaire shall operate the Power Station such that it is available
for
Deilit
Fixed Charge to be
generation to the extent of at least 90 per cent of the Installed Capacity whichpaid for Availability
shall be deemed to be the Normative Availability for each accounting year. Anyof Power Station
shortfall in the Normative Availability will attract penalties. The Concessionaire
shall declare the availability of the Power Station at frequent intervals and the
Utility shall be free to direct the Concessionaire to produce and despatch
electricity in accordance with the despatch instructions given by it from time to
time. Payment of Fixed Charge shall be computed on the basis of availability of
the Power Station while the Fuel Charge shall be payable only for the electricity
actually produced and despatched.
Normally, the Power Station shall be deemed as available to the full extent. InPenalties for misthe event of any defect or deficiency, the Concessionaire must declare the actual declaration
availability so that its Fixed Charge is computed accordingly. The MPPA
stipulates stiff penalties in case of mis-declaration by the Concessionaire.
Dedicated Capacity
Eighty per cent of the Installed Capacity of the Power Station (85 per cent inDedicated Capacity
for the Utility
case of UMPPs or where fuel is procured from captive mines) shall at all times
be dedicated for production and supply of electricity to the Utility and shall be
utilized only in accordance with the instructions of the Utility. In the event such
capacity is not utilised on account of shortage of fuel, the Concessionaire will be
free to procure fuel from the market and sell the electricity to third parties in
order to recover its Fixed Charge. In the event any Dedicated Capacity remains
idle, the Utility shall pay to the Concessionaire 70 per cent of the Fixed Charge
as explained above. This entire arrangement would help mitigate the risk of the
Concessionaire on account of the current fuel shortage as well as a possible
backing down of the Power Station due to high costs of additional fuel supply.
Since idle capacity would hurt the Concessionaire as well as the Utility, it is
expected that both parties will have sufficient incentive to ensure optimum
utilization of the Dedicated Capacity.

<!-- page 8 -->

Open Capacity
Twenty per cent of the Installed Capacity (15 per cent in case of UMPPs orOpen Capacity for
where fuel is procured from captive mines) shall be available to themarket sales
Concessionaire for production of electricity and supply thereof to any buyer on
the terms determined mutually between the Concessionaire and such buyer. Such
buyers may include bulk consumers within the supply area of the Utility. This
would not only facilitate the development of a power market, but also enable the
Concessionaire to procure fuel at market prices and produce electricity for sale to
bulk consumers at unregulated prices. Such an arrangement will help improve
the financial viability of the Power Station, enhance power production and
promote competition in generation and supply of electricity.
Additional Capacity
The Concessionaire may, with prior consent of the Utility and in accordance withAdditional capacity for
applicable laws, create additional capacity in accordance with the provisions ofimproving viability
the agreement. Eighty per cent of the additional capacity shall be deemed to be
Dedicated Capacity and the balance shall be Open Capacity. The Concessionaire
may also set up additional capacity based on fuel supplies to be procured at
market rates and sell its production to other buyers at mutually determined
tariffs, provided it pays the specified revenue share to the Utility.
Technical parameters
Unlike the normal practice of focusing on construction specifications, the
technical parameters proposed in the MPPA are based mainly on outputTechnical parameters for
level of service
specifications, as these have a direct bearing on the level of power generation.
Only the core requirements of design, construction, operation and maintenance
of the generation system have been specified, leaving enough room for the
Concessionaire to innovate and add value. In sum, the framework focuses on the
'what' rather than the 'how' in relation to the production and supply of power by
the Concessionaire. This would also provide the requisite flexibility to the
Concessionaire to innovate and optimise on designs in a way normally denied
under conventional input-based procurement specifications.
Performance standards
The efficiency of the Concessionaire would normally be reflected in the qualityPerformance standards
and reliability of power supply. The MPPA, therefore, identifies the keyto be enforced
performance indicators relating to operation of the generation system and
stipulates penalties for failure to achieve the requisite levels of performance. In
particular, the Concessionaire shall be required to ensure the availability of
Installed Capacity at pre-determined normative levels, which will make
sufficient allowance for scheduled maintenance.
For monitoring the key performance indicators, monthly status reports and
periodic inspections of the Independent Engineer have been prescribed. The
Concessionaire is also required to maintain the requisite ISO certification for the
Power Station.

<!-- page 9 -->

Selection of Concessionaire
Selection of the Concessionaire will be based on a two-stage process ofCompetitive bidding on
competitive bidding. All project parameters such as the concession period,Fixed Charge will be the
technical parameters and performance standards are to be clearly stated upfront.norm
Based on these terms, the short-listed bidders will be required to specify their
financial offer in terms of a unit Fixed Charge, without any qualifications. In
some cases, the financial offer may also have to include the Fuel Charge. The
bidder who seeks the lowest unit charge should win the contract. The financial
offer for the unit charge shall be made only for the initial year and the actual
tariff payable to the Concessionaire will be revised annually based on predetermined indexation.
Risk allocation
As an underlying principle, risks have been allocated to the parties that are bestRisk allocation and
suited to manage them. Project risks have, therefore, been assigned to the privatemitigation are critical
sector to the extent it is capable of managing them. These risks have also been
mitigated to the extent possible. The transfer of these risks and responsibilities to
the private sector would increase the scope of innovation leading to efficiencies
in costs and services.
The commercial and technical risks relating to construction, operation andCommercial risks to be
maintenance are being allocated to the Concessionaire, as it would be best suitedborne by Concessionaire
to manage them. On the other hand, all direct and indirect political risks are
being assigned to the Utility.
Financial Close
Unlike other agreements for private infrastructure projects which neither define a Financial close to be
time-frame for achieving financial close, nor specify the penal consequences for time bound
failure to do so, the MPPA stipulates a time limit of 180 days for achieving
financial close (extendable for upto 185 days on payment of a penalty), failing
which the bid security shall be forfeited. By prevalent standards, this is a tight
schedule, which is achievable only if all the parameters are well defined and the
requisite preparatory work has been undertaken.
The MPPA represents the comprehensive framework necessary for enablingFulfillment of
financial close within the stipulated period. Adherence to such time schedulescondtions precedent
will usher in a significant reduction in costs besides ensuring timely provision of
the needed infrastructure. This approach would also address the typical problem
of infrastructure projects not achieving financial close for long periods.
Construction of the Power Station
Handing over possession of 80 percent of the land required for construction of Scope of the Project to
power station and obtaining of environmental clearances are being proposed as be precise
conditions precedent to be satisfied by the Utility before financial close.
Execution of a Fuel Supply Agreement and procurement of applicable permits

<!-- page 10 -->

have been proposed as conditions precedent to be satisfied by the
Concessionaire. The Utility would provide reasonable support and assistance to
the Concessionaire in procuring the FSA and applicable permits. Damages have
been prescribed for delay in fulfilling the conditions precedent by the Utility as
well as the Concessionaire.
The MPPA also defines the scope of the project with a fair degree of precision in
order to enable the Concessionaire to determine its costs and obligations.
Additional works may be specified by the Utility but only within a predetermined limit, provided the entire cost thereof is borne by the Utility. Project
Milestones have also been incorporated in the MPPA.
Before commencing the commercial operation of the generation system, theTests prior to
Concessionaire will be required to subject it to specified tests for ensuringcommissioning
compliance with the specifications relating to safety and quality of supply. The
option of phased completion has also been provided.
Operation and maintenance
Service quality and
Operation and maintenance of the Power Station is proposed to be governed by
safety must be ensured
strict standards with a view to ensuring a high level of reliability and availability.
Any violations of these standards would attract stiff penalties. In sum,
operational performance would be the most important test of service delivery.

The MPPA provides for an elaborate and dynamic mechanism to evaluate and
upgrade the safety requirements on a continuing basis in conformity with Good
Industry Practice. It includes safety certification by the designated Electrical
Inspector prior to COD and provides for reviews at regular intervals by qualified
experts.
Right of substitution
Lenders will have the

The project assets may not constitute adequate security for lenders. It is the
right of substitution
project revenue streams that constitute the mainstay of their security. Lenders
would, therefore, require assignment and substitution rights so that the
concession can be transferred to another company in the event of failure of the
Concessionaire to operate the project successfully. The MPPA accordingly
provides for such substitution rights.
Consortium of Utilities

will be protected against
In case the Power Station is procured by more than one Utility, the individual
political actions
Utilities, acting as a consortium, will execute the Utilities Consortium
Agreement, through which they would sub-divide and allocate the installed
capacity among themselves and also agree to bear individual, joint and several
rights, obligations and liabilities.

Each individual Utility shall have the right to offer, transfer or assign, in whole
or in part, its allocated capacity to any participating Utility or other distribution
licensee. In the event an individual Utility commits a default specified in the

<!-- page 11 -->

PPA, it shall either substitute itself by a participating Utility or other distribution
licensee, or make the specified termination payment to the Concessionaire.
Force majeure
The MPPA contains the requisite provisions for dealing with force majeure
events. In particular, it affords protection to the Concessionaire against political
actions that may have a material adverse effect on the project.
Termination
In the event of termination, the MPPA provides for a compulsory buy-out by thePre-determined
Utility, as neither the Concessionaire nor the lenders can use the Power Stationtermination payments
on their own for recovering their investments. This arrangement also providesshould provide
predictability
the requisite protection of public resources like fuel, land and water which would
revert to the Utility in the event of termination.
Termination payments have been quantified precisely as compared to the
complex formulations in most concession agreements relating to infrastructure
projects. Political force majeure and defaults by the Utility would qualify for
adequate compensatory payments to the Concessionaire and will thus guard
against any discriminatory or arbitrary action by the Utility. Further, the project
debt would be fully protected by the Utility in the event of termination, except
for three situations, namely, (a) when termination occurs as a result of default by
the Concessionaire, 90 per cent of the debt will be protected, (b) in the event of
non-political force majeure such as Act of God (normally covered by insurance),
90 per cent of the debt not covered by insurance will be protected, and (c) when
termination occurs on account of Concessionaire Default during construction
period, 90 per cent of the debt in excess of 40 per cent of Total Project Cost will
be paid subject to certain conditions.
Upon expiry of the specified concession period, the Concessionaire would be
entitled to a termination payment which will be a pre-determined multiple of
monthly Fixed Charge. However, either Party would have the right to seek an
extension of 15 years in the concession period and in such an event, no
termination payment shall be due and payable after expiry of the extended
period.
Monitoring and supervision
Monitoring through
Day-to-day interaction between the Utility and the Concessionaire has been kept
an Independent
to the bare minimum by following a 'hands-off' approach, and the Utility shall be
Engineer
entitled to intervene only in the event of a material default. Checks and balances
have, however, been provided for ensuring full accountability of the
Concessionaire.

Monitoring and supervision of construction, operation and maintenance is
proposed to be undertaken through an Independent Engineer (a qualified firm)
that will be selected by the Utility through a transparent process. Its

<!-- page 12 -->

independence would provide added comfort to all stakeholders, besides
improving the efficiency of project implementation.
The MPPA provides for a transparent procedure to ensure selection of well- Selection of
reputed statutory auditors, as they would play a critical role in ensuring financial auditors
discipline. As a safeguard, the MPPA also provides for appointment of additional
or concurrent auditors.
To provide enhanced security to the lenders and greater stability to the project
operations, all financial inflows and outflows of the project are proposed to be
routed through an escrow account.
Revenue shortfall loan
By way of comfort to the lenders, loan assistance from the Utility has been
stipulated for supporting debt service obligations in the event of a revenue
shortfall resulting from political force majeure or default by the Utility.
Specifications & Standards
The accountability for providing a safe and reliable Power Station ultimatelyOutput
rests with the Government and the MPPA therefore refers to Specification andspecifications to be
emphasised
Standards that the Concessionaire must conform to. These specifications rely
mainly on the extant rules and regulations applicable to power stations. These
rules, by reference, form an integral part of the Power Purchase Agreement for a
specific project and shall be binding on the Concessionaire. The MPPA stipulates
that only the basic requirements of design and construction shall be laid down in
the PPA with reference to the Grid Code and applicable laws, and greater
emphasis shall be placed on specifying the output specifications that have a
direct bearing on the reliability and quality of power supply.
Land acquisition
Land would have to be acquired by the Utility as the Concessionaire may face
serious difficulties in acquiring land on its own. The Utility will have the option
of indicating the lump-sum cost that it would recover from the Concessionaire on
this account. This amount may even be a token sum as the ownership of land will
rest with the Utility and the Concessionaire will only be a licensee. In case the
Utility proposes to set up a Power Station in another State, it may require the
Concessionaire to procure land on its own.
The Concessionaire may, upon expiry of the Concession Period by efflux of
time, require the Utility to transfer the possession and title of the Site and Project
Assets, excluding any captive coal mines or right to the Concessional Fuel, for a
specified period.
To provide greater comfort and security to the lenders, the Utility and the
Concessionaire may jointly execute a mortgage deed in favour of the Senior
Lenders for and in respect of the Site and Project Assets excluding any captive
coal mines or right to the Concessional Fuel.

<!-- page 13 -->

Miscellaneous
The MPPA addresses other important issues such as dispute resolution,An effective
suspension of rights, change in law, insurance, defects liability, indemnity,dispute resolution
mechanism is
redressal of public grievances and disclosure of project documents. Itcritical
incorporates the best practices that would enable a fair and transparent
framework for private participation.
Conclusion
Together with the Schedules, the proposed contractual framework addresses the
issues that are likely to arise in financing of generation projects on DBFOT basis.
The proposed policy and regulatory framework contained in the MPPA is critical
for attracting private investment with the concomitant efficiencies and lower
costs, necessary for accelerating growth and making electricity affordable.

<!-- page 14 -->

For official use

Model

Request For Qualification
For
Power Purchase Agreement

Government of India

mrfq/ppa/19.09.2013

i

<!-- page 15 -->

For official use

GLOSSARY
Applicant(s)
Application
Application Due Date
Associate
Bids
Bid Due Date
Bid Security
Bidders
Bidding Documents
Bidding Process
Bid Stage
[BOT]
[CIL
Concessionaire
Conflict of Interest
Consortium
DBFOT
Eligible Experience
Eligible Projects
Estimated Project Cost
Experience Score
Financial Capacity
Government
Jt. Bidding Agreement
Lead Member
LOA
Lowest Bidder
Member
Net Worth
O&M
PPA
PPP
Project
Qualification
Qualification Stage
Re. or Rs. or INR
RFP or Request for Proposals
RFQ
SPV
Tariff
Technical Capacity
Threshold Technical Capacity
Utility

As defined in Clause 1.2.1
As defined in the Disclaimer
As defined in Clause 1.1.5
As defined in Clause 2.2.9
As defined in Clause 1.2.3
As defined in Clause 1.2.3
As defined in Clause 1.2.4
As defined in Clause 1.1.1
As defined in Clause 1.2.3
As defined in Clause 1.2.1
As defined in Clause 1.2.1
Build, Operate and Transfer
As defined in Clause 1.2.8]
As defined in Clause 1.1.2
As defined in Clause 2.2.1(c)
As defined in Clause 2.2.1(a)
As defined in Clause 1.1.1
As defined in Clause 3.2.1
As defined in Clause 3.2.1
As defined in Clause 1.1.4
As defined in Clause 3.2.6
As defined in Clause 2.2.2 (B)
Government of *****
As defined in Clause 2.2.6(g)
As defined in Clause 2.2.6 (c)
Letter of Award
As defined in Clause 1.2.8
Member of a Consortium
As defined in Clause 2.2.4 (ii)
Operation and Maintenance
As defined in Clause 1.1.2
Public Private Partnership
As defined in Clause 1.1.1
As defined in Clause 1.2.1
As defined in Clause 1.2.1
Indian Rupee
As defined in Clause 1.2.1
As defined in the Disclaimer
As defined in Clause 2.2.6
As defined in Clause 1.2.8
As defined in Clause 2.2.2 (A)
As defined in Clause 2.2.2 (A) (iii)
As defined in Clause 1.1.1

The words and expressions beginning with capital letters and defined in this document
shall, unless repugnant to the context, have the meaning ascribed thereto herein.

mrfq/ppa/19.09.2013

ii

<!-- page 16 -->

For official use

TABLE OF CONTENTS
Sl. No.

1

2

Contents

Page
No.

Glossary

ii

Disclaimer

vi

Introduction
1.1
Background
1.2
Brief description of Bidding Process
1.3
Schedule of Bidding Process

1

Instructions to Applicants

1
2
5
7

2A
2.1
2.2
2.3
2.4

General
Scope of Application
Eligibility of Applicants
Change in composition of the Consortium
Number of Applications and costs thereof

7
7
7
14
14

2.5
2.6

Site visit and verification of information
Acknowledgement by Applicant

15
15

2.7

Right to accept or reject any or all Applications/ Bids

15

2B
2.8
2.9
2.10

Documents
Contents of the RFQ
Clarifications
Amendment of RFQ

16
16
17
17

2C
2.11
2.12
2.13
2.14
2.15
2.16

Preparation and Submission of Application
Language
Format and signing of Application
Sealing and marking of Applications
Application Due Date
Late Applications
Modifications/ substitution/ withdrawal of Applications

18

2D
2.17
2.18

Evaluation Process
Opening and Evaluation of Applications
Confidentiality

20
20
21

2.19

Tests of responsiveness

21

mrfq/ppa/19.09.2013

18
18
18
20
20
20

iii

<!-- page 17 -->

For official use

3

2.20

Clarifications

22

2E
2.21
2.22
2.23
2.24

Qualification and Bidding
Short-listing and notification
Submission of Bids
Proprietary data
Correspondence with the Applicant

23
23
23
23
23

Criteria for Evaluation
3.1
Evaluation parameters
3.2
Technical Capacity for purposes of evaluation

24
24
24

3.3
3.4
3.5

Details of Experience
Financial information for purposes of evaluation
Short-listing of Applicants

26
26
27

[3.5

Pre-qualification and scoring]

27

4

Fraud and Corrupt Practices

28

5

Pre-Application Conference

30

6

Miscellaneous

31

Appendices
I

Format for Application
Annex – I
Annex – II
Annex – III
Annex – IV
Annex – V

Details of Applicant
Technical Capacity of Applicant
Financial Capacity of Applicant
Details of Eligible Projects
Statement of Legal Capacity

32
35
37
39
41
46

II

Format for Power of Attorney for signing of Application

47

III

Format for Power of Attorney for Lead Member of Consortium

49

IV

Format for Joint Bidding Agreement for Consortium

52

V

[Guidelines of the Department of Disinvestment]

59

VI

Information Memorandum

61

VII

List of Bid-specific Clauses

62

VIII List of Project-specific Clauses

64

mrfq/ppa/19.09.2013

iv

<!-- page 18 -->

For official use

mrfq/ppa/19.09.2013

v

<!-- page 19 -->

For official use

DISCLAIMER
The information contained in this Request for Qualification document (the “RFQ”) or
subsequently provided to Applicant(s), whether verbally or in documentary or any
other form, by or on behalf of the Utility or any of its employees or advisors, is
provided to Applicant(s) on the terms and conditions set out in this RFQ and such
other terms and conditions subject to which such information is provided.
This RFQ is not an agreement and is neither an offer nor invitation by the Utility to
the prospective Applicants or any other person. The purpose of this RFQ is to provide
interested parties with information that may be useful to them in the formulation of
their application for qualification pursuant to this RFQ (the “Application”). This RFQ
includes statements, which reflect various assumptions and assessments arrived at by
the Utility in relation to the Project. Such assumptions, assessments and statements do
not purport to contain all the information that each Applicant may require. This RFQ
may not be appropriate for all persons, and it is not possible for the Utility, its
employees or advisors to consider the investment objectives, financial situation and
particular needs of each party who reads or uses this RFQ. The assumptions,
assessments, statements and information contained in this RFQ may not be complete,
accurate, adequate or correct. Each Applicant should therefore, conduct its own
investigations and analysis and should check the accuracy, adequacy, correctness,
reliability and completeness of the assumptions, assessments, statements and
information contained in this RFQ and obtain independent advice from appropriate
sources.
Information provided in this RFQ to the Applicant(s) is on a wide range of matters,
some of which may depend upon interpretation of law. The information given is not
intended to be an exhaustive account of statutory requirements and should not be
regarded as a complete or authoritative statement of law. The Utility accepts no
responsibility for the accuracy or otherwise for any interpretation or opinion on law
expressed herein.
The Utility, its employees and advisors make no representation or warranty and shall
have no liability to any person, including any Applicant or Bidder, under any law,
statute, rules or regulations or tort, principles of restitution or unjust enrichment or
otherwise for any loss, damages, cost or expense which may arise from or be incurred
or suffered on account of anything contained in this RFQ or otherwise, including the
accuracy, adequacy, correctness, completeness or reliability of the RFQ and any
assessment, assumption, statement or information contained therein or deemed to
form part of this RFQ or arising in any way with pre-qualification of Applicants for
participation in the Bidding Process.
The Utility also accepts no liability of any nature whether resulting from negligence
or otherwise howsoever caused arising from reliance of any Applicant upon the
statements contained in this RFQ.
The Utility may, in its absolute discretion but without being under any obligation to
do so, update, amend or supplement the information, assessment or assumptions
contained in this RFQ.
mrfq/ppa/19.09.2013

vi

<!-- page 20 -->

For official use

The issue of this RFQ does not imply that the Utility is bound to select and short-list
pre-qualified Applications for Bid Stage or to appoint the selected Bidder or
Concessionaire, as the case may be, for the Project and the Utility reserves the right to
reject all or any of the Applications or Bids without assigning any reasons
whatsoever.
The Applicant shall bear all its costs associated with or relating to the preparation and
submission of its Application including but not limited to preparation, copying,
postage, delivery fees, expenses associated with any demonstrations or presentations
which may be required by the Utility or any other costs incurred in connection with or
relating to its Application. All such costs and expenses will remain with the Applicant
and the Utility shall not be liable in any manner whatsoever for the same or for any
other costs or other expenses incurred by an Applicant in preparation or submission of
the Application, regardless of the conduct or outcome of the Bidding Process.

mrfq/ppa/19.09.2013

vii

<!-- page 21 -->

For official use

***
[Name of Utility]

1. INTRODUCTION
1.1

Background1

1.1.1 The [ ***Distribution Company]2 (the “Utility”)3 is engaged in the distribution of
electricity and as part of this endeavour, the Utility has decided to undertake
development and operation of the *****4 Project (the “Project”) through PublicPrivate Partnership (the “PPP”) on Design, Build, Finance, Operate and Transfer
(the "DBFOT") basis, and has decided to carry out the bidding process for
selection of a corporate entity as the bidder to whom the Project may be awarded.
A brief description of the project may be seen in the Information Memorandum of
the Project at the Appendix VI. Brief particulars of the Project are as follows:
Location of the Plant

Capacity
(in MW)

Indicative Project Cost
(In Rs. cr)5

[ *** in the state of ***

***

[500]

The Utility intends to pre-qualify and short-list suitable Applicants (the
“Bidders”) who will be eligible for participation in the Bid Stage, for awarding
the Project through an open competitive bidding process in accordance with the
procedure set out herein.
1.1.2 The selected Bidder, who is either a company incorporated under the Companies
Act, 1956 or undertakes to incorporate as such prior to execution of the Power
Purchase Agreement (the “Concessionaire”) shall be responsible for designing,
engineering, financing, procurement, construction, operation and maintenance of
the Project under and in accordance with the provisions of a long term agreement
for purchase of power (the “Power Purchase Agreement” or the “PPA”) to be
entered into between the Concessionaire and the Utility in the form provided by
1

Serially numbered footnotes are for guidance of the Utility and should be omitted prior to issue of RFQ.
Footnotes marked in non-numerical characters shall be retained in the RFQ.
2
All project-specific provisions in this document have been enclosed in square parenthesis and may be
modified, as necessary, before issuing the RFQ for the Project. The square parenthesis should be removed
after carrying out the required modifications. The curly parenthesis including the provisions contained
therein and all the blank spaces may be retained in the RFQ document to be issued to prospective
Applicants. They should be suitably modified/ filled up subsequently by the respective Applicants or the
Utility, as the case may be, to reflect the particulars relating to the Project or the Applicants.
3
The Utility may be a single entity or multiple entities represented by the Lead Utility.
4
Wherever asterisk is used, it should be substituted by project-specific details prior to issue of RFQ.
5
This amount should normally include the likely construction cost plus 25% thereof by way of financing
costs, physical and price contingencies etc.

mrfq/ppa/19.09.2013

1

<!-- page 22 -->

For official use

the Utility as part of the Bidding Documents pursuant hereto. The concession
period shall be pre-determined, and will be indicated in the draft PPA.
1.1.3 The scope of work will broadly include designing, financing, operation and
maintenance of the Power Station and supply of power in accordance with the
terms of the PPA.
1.1.4 Indicative capital cost of the Project (the “Estimated Project Cost”) will be
revised and specified in the Bidding Documents of the Project. The assessment of
actual costs, however, will have to be made by the Bidders.
1.1.5 The Utility shall receive Applications pursuant to this RFQ in accordance with the
terms set forth herein as modified, altered, amended and clarified from time to
time by the Utility, and all Applications shall be prepared and submitted in
accordance with such terms on or before the date specified in Clause 1.3 for
submission of Applications (the “Application Due Date”).
1.2

Brief description of Bidding Process

1.2.1 The Utility has adopted a two-stage process (collectively referred to as the
"Bidding Process") for selection of the bidder for award of the Project. The first
stage (the "Qualification Stage") of the process involves qualification (the
“Qualification”) of interested parties/ consortia who make an Application in
accordance with the provisions of this RFQ (the "Applicant", which expression
shall, unless repugnant to the context, include the Members of the Consortium).
Prior to making an Application, the Applicant shall pay to the Utility a sum of Rs.
10, 000 (Rupees ten thousand) as the cost of the RFQ process. 6 At the end of this
stage, the Utility expects to announce a short-list of up to 7 (seven)7 suitable prequalified Applicants who shall be eligible for participation in the second stage of
the Bidding Process (the "Bid Stage") comprising Request for Proposals (the
“Request for Proposals” or “RFP”).
Government of India has issued guidelines (see Appendix-V) for qualification of
bidders seeking to acquire stakes in any public sector enterprise through the
process of disinvestment. These guidelines shall apply mutatis mutandis to this
Bidding Process. The Utility shall be entitled to disqualify an Applicant in
accordance with the aforesaid guidelines at any stage of the Bidding Process.
Applicants must satisfy themselves that they are qualified to bid, and should give
an undertaking to this effect in the form at Appendix-I.
1.2.2 In the Qualification Stage, Applicants would be required to furnish all the
information specified in this RFQ. Only those Applicants that are pre-qualified
and short-listed by the Utility shall be invited to submit their Bids for the Project.
6

The cost of RFQ may be determined at the rate of Rs. 5,000 for every Rs. 100 crore or part thereof
comprising the Estimated Project Cost. Thus the cost of an RFQ document for a project of Rs. 1,000 crore
shall be Rs.50,000.
7

In the case of a UMPP, the words “a short-list of up to 7 (seven) suitable” shall be omitted and the word
“the” shall be added.

mrfq/ppa/19.09.2013

2

<!-- page 23 -->

For official use

The Utility is likely to provide a comparatively short time span for submission of
the Bids for the Project. The Applicants are, therefore, advised to visit the site and
familiarise themselves with the Project.
1.2.3 In the Bid Stage, the Bidders will be called upon to submit their financial offers
(the "Bids") in accordance with the RFP and other documents to be provided by
the Utility (collectively the "Bidding Documents"). The Bidding Documents for
the Project will be provided to every Bidder on payment of {Rs. 100,000 (Rs. one
lakh only)}$.The Bid shall be valid for a period of not less than 120 days from the
date specified in Clause 1.3 for submission of bids (the “Bid Due Date”).
1.2.4 In terms of the RFP, a Bidder will be required to deposit, along with its Bid, a bid
security [equivalent to about 1% (one per cent)8of the Estimated Project Cost] (the
"Bid Security"), refundable no later than [60 (sixty) days] from the Bid Due
Date, except in the case of the selected Bidder whose Bid Security shall be
retained till it has provided a Performance Security under the PPA. The Bidders
will have an option to provide Bid Security in the form of a demand draft or a
bank guarantee acceptable to the Utility9and in such event, the validity period of
the demand draft or bank guarantee, as the case may be, shall not be less than 180
(one hundred and eighty) days from the Bid Due Date, inclusive of a claim period
of 60 (sixty) days, and may be extended as may be mutually agreed between the
Utility and the Bidder from time to time. The Bid shall be summarily rejected if it
is not accompanied by the Bid Security.
1.2.5 Generally, the Lowest Bidder shall be the selected Bidder. The remaining Bidders
shall be kept in reserve and may, in accordance with the process specified in the
RFP, be invited to match the Bid submitted by the Lowest Bidder in case such
Lowest Bidder withdraws or is not selected for any reason. In the event that none
of the other Bidders match the Bid of the Lowest Bidder, the Utility may, in its
discretion, invite fresh Bids from the remaining Bidders or annul the Bidding
Process, as the case may be.
1.2.6 During the Bid Stage, Bidders are invited to examine the Project in greater detail,
and to carry out, at their cost, such studies as may be required for submitting their
respective Bids for award of the concession including implementation of the
Project.
1.2.7 As part of the Bidding Documents, the Utility will provide a draft PPA and
feasibility report prepared by the Utility /its consultants and other information
pertaining/ relevant to the Project available with it.
1.2.8 Bids will be invited for the Project on the basis of a tariff to be offered by a
Bidder for production and supply of electricity in accordance with the terms of the
draft PPA forming part of the Bidding Documents. For the purposes of biding
$

The actual amount will be indicated in the RFP.
The Utility may, if deemed necessary, prescribe a higher bid security not exceeding 2% of the Estimated
Project Cost. In case of a project having an Estimated Project Cost of Rs. 2,000 cr. or above, the Utility
may reduce the bid security, but not less than 0.5% of the Estimated Project Cost in any case.
9
The format for the bank guarantee has been published as part of the Model RFP document.
8

mrfq/ppa/19.09.2013

3

<!-- page 24 -->

For official use

hereunder, the Fixed Charge [and Fuel Charge] will constitute the tariff for the
Power Station (the “Tariff”).
Explanation10
[(a) Since the Bidder is expected to source concessional fuel from Coal India
Limited or a subsidiary thereof (the “CIL”), the Fuel Charge shall be a ‘pass
through’ in accordance with the terms of the PPA. However, the element of coal
transportation and transmission losses may vary from case to case and shall also
form part of the Fuel Charge. The Bid for the Project shall, therefore, only
comprise the Fixed Charge to be offered by the Bidder and the Bidder seeking the
lowest Fixed Charge shall be the selected Bidder.]
[(b) Since the Bidder is expected to source fuel from captive mines separately
allotted to it by a Governmental Instrumentality, the Bid for the Project shall be
the Tariff comprising the Fixed Charge and Fuel Charge which shall be specified
separately. As a condition of bidding, the Fuel Charge to be offered by the Bidder
shall not exceed Rs. *** per KWh and shall not be lower than Rs. *** per KWh
11
. The Bidder seeking the lowest Tariff shall be the selected Bidder.]
[(c) Since the Bidder is expected to source fuel from captive mines allotted by or
on behalf of the Utility as part of the Project, the Utility has determined that the
Fuel Charge payable to the Concessionaire shall be Rs*** per KWh in accordance
with the provisions of Clause 26.2.2 of the draft PPA. The Bid for the Project
shall, therefore, only comprise the Fixed Charge to be offered by the Bidder and
the Bidder seeking the lowest Fixed Charge shall be the selected Bidder.]
[(d) Since the Bidder is expected to source all or part of the fuel through imports
at market prices, the Fuel Charge shall be a ‘pass through’ in accordance with the
terms of the PPA. The Bid shall, therefore, only comprise the Fixed Charge to be
offered by the Bidder and the Bidder seeking the lowest Fixed Charge shall be the
selected Bidder.]
[(e) Since the Bidder is expected to source fuel through imports from captive
mines situated outside India or from a long term fuel supply contract in respect
thereof, the Bid for the Project shall be the Tariff comprising the Fixed Charge
and the Fuel Charge which shall be specified separately. As a condition of
bidding, the Fuel Charge to be offered by the Bidder shall not exceed an amount
that reflects [80%/85%/90%] of the price of Fuel computed with reference to the
average API 4 Index (South Africa) for a period of 180 (one hundred and eighty)
days immediately preceding the date of Bid in accordance with Clause 26.2.2 of
the draft PPA forming part of the Bidding Documents. Further, the Fuel Charge
shall not be lower than an amount that reflects ***% (*** per cent) of the price of

10

Depending upon the choice of Fuel source, only the applicable Sub-clause may be retained and the
remaining Sub-clauses should be omitted. However, in case the Fuel to be procured under Sub-clause (a) is
to be supplemented by imported Fuel, the Utility may retain both Sub-clause (a) and Sub-clause (d).
11
The Utility shall specify the ceiling, but it may, in its discretion, also specify the floor for the Fuel
Charge.

mrfq/ppa/19.09.2013

4

<!-- page 25 -->

For official use

Fuel computed with reference to the aforesaid index12. The Fuel Charge to be
offered by the bidder shall be quoted in US cents per KWh. For the purposes of
evaluation of the Bid, the exchange rate to be used for conversion into Indian
Rupees shall be the mean of the buying and selling rate quoted by the State Bank
of India on the closing of the working day that precedes the date of Bid. As
specified in the PPA, the freight and transportation charges shall be payable
separately in accordance with the provisions of Clause 26.2.4 thereof. The Bidder
seeking the lowest Tariff shall be the selected Bidder.]
In this RFQ, the term “Lowest Bidder” shall mean the Bidder who is offering the
lowest Tariff$.
1.2.9

Further and other details of the process to be followed at the Bid Stage and the
terms thereof will be spelt out in the Bidding Documents.

1.2.10 Any queries or request for additional information concerning this RFQ shall be
submitted in writing or by fax and e-mail to the officer designated in Clause
2.13.3 below. The envelopes/ communications shall clearly bear the following
identification/ title:
"Queries/ Request for Additional Information: RFQ for ***** Project”.
1.3

Schedule of Bidding Process
The Utility shall endeavour to adhere to the following schedule:
Event Description

Date

Qualification Stage
1.

Last date for receiving queries

[25 days from date of RFQ]

2.

Pre-Application Conference

[30 days from date of RFQ]

3.

Utility response to queries latest by

[35 days from date of RFQ]

4.

Application Due Date

[45 days from date of RFQ]

5.

Announcement of short-list

Within 15 days of
Application Due Date

Bid Stage

Estimated Date

1.

Sale of Bid Documents

[To be specified]

2.

Last date for receiving queries

[To be specified]

12

The Utility shall specify the ceiling, but it may, in its discretion, also specify the floor for the Fuel
Charge.
$
Where the bidders are not asked to offer a Fuel Charge as part of their bid, the evaluation of bids shall be
restricted to Fixed Charge.

mrfq/ppa/19.09.2013

5

<!-- page 26 -->

For official use

3.

Pre-Bid meeting - 1

[To be specified]

4.

Utility response to queries latest by

[To be specified]

5.

Pre-Bid meeting - 2

[To be specified]13

6.

Bid Due Date

[To be specified]

7.

Opening of Bids

On Bid Due Date

8.

Letter of Award (LOA)

Within 30 days of Bid Due
Date

9.

Validity of Bids

120 days of Bid Due Date

10.

Signing of PPA

Within 30 days of award of
LOA

13

In case of complex projects, the number of pre-bid meetings could be two or more.

mrfq/ppa/19.09.2013

6

<!-- page 27 -->

For official use

2. INSTRUCTIONS TO APPLICANTS
A.

GENERAL

2.1

Scope of Application

2.1.1 The Utility wishes to receive Applications for Qualification in order to short-list
experienced and capable Applicants for the Bid Stage.
2.1.2 Short-listed Applicants may be subsequently invited to submit the Bids for the
Project.
2.2

Eligibility of Applicants

2.2.1 For determining the eligibility of Applicants for their pre-qualification hereunder,
the following shall apply:
(a) The Applicant for pre-qualification may be a single entity or a group of
entities (the “Consortium”), coming together to implement the Project. However,
no applicant applying individually or as a member of a Consortium, as the case
may be, can be member of another Applicant. The term Applicant used herein
would apply to both a single entity and a Consortium.
(b) An Applicant may be a natural person, private entity, [government-owned
entity] or any combination of them with a formal intent to enter into an agreement
or under an existing agreement to form a Consortium. A Consortium shall be
eligible for consideration subject to the conditions set out in Clause 2.2.6 below.
(c) An Applicant shall not have a conflict of interest (the “Conflict of Interest”)
that affects the Bidding Process. Any Applicant found to have a Conflict of
Interest shall be disqualified$. An Applicant shall be deemed to have a Conflict of
Interest affecting the Bidding Process, if:
(i)

$

the Applicant, its Member or Associate (or any constituent thereof) and
any other Applicant, its Member or any Associate thereof (or any
constituent thereof) have common controlling shareholders or other
ownership interest; provided that this disqualification shall not apply in
cases where the direct or indirect shareholding of an Applicant, its
Member or an Associate thereof (or any shareholder thereof having a
shareholding of more than 5 per cent of the paid up and subscribed share
capital of such Applicant, Member or Associate, as the case may be) in the
other Applicant, its Member or Associate is less than 5 per cent of the
subscribed and paid up equity share capital thereof; provided further that
this disqualification shall not apply to any ownership by a bank, insurance
company, pension fund or a public financial institution referred to in
section 4A of the Companies Act, 1956. For the purposes of this Clause
2.2.1(c), indirect shareholding held through one or more intermediate

The provisions of sub-clauses (i), (iii) and (v) shall not apply to government companies.

mrfq/ppa/19.09.2013

7

<!-- page 28 -->

For official use

persons shall be computed as follows: (aa) where any intermediary is
controlled by a person through management control or otherwise, the
entire shareholding held by such controlled intermediary in any other
person (the “Subject Person”) shall be taken into account for computing
the shareholding of such controlling person in the Subject Person; and (bb)
subject always to sub-clause (aa) above, where a person does not exercise
control over an intermediary, which has shareholding in the Subject
Person, the computation of indirect shareholding of such person in the
Subject Person shall be undertaken on a proportionate basis; provided,
however, that no such shareholding shall be reckoned under this subclause (bb) if the shareholding of such person in the intermediary is less
than 26% of the subscribed and paid up equity shareholding of such
intermediary; or
(ii)

a constituent of such Applicant is also a constituent of another Applicant;
or

(iii)

such Applicant, or any Associate thereof receives or has received any
direct or indirect subsidy, grant, concessional loan or subordinated debt
from any other Applicant, or any Associate thereof or has provided any
such subsidy, grant, concessional loan or subordinated debt to any other
Applicant, its Member or any Associate thereof; or

(iv)

such Applicant has the same legal representative for purposes of this
Application as any other Applicant; or

(v)

such Applicant, or any Associate thereof has a relationship with another
Applicant, or any Associate thereof, directly or through common third
party/ parties, that puts either or both of them in a position to have access
to each other’s information about, or to influence the Application of either
or each other; or

(vi)

such Applicant, or any Associate thereof has participated as a consultant to
the Utility in the preparation of any documents, design or technical
specifications of the Project.

(d) An Applicant shall be liable for disqualification if any legal, financial or
technical adviser of the Utility in relation to the Project is engaged by the
Applicant, its Member or any Associate thereof, as the case may be, in any
manner for matters related to or incidental to the Project. For the avoidance of
doubt, this disqualification shall not apply where such adviser was engaged by the
Applicant, its Member or Associate in the past but its assignment expired or was
terminated prior to the Application Due Date. Nor will this disqualification apply
where such adviser is engaged after a period of 3 (three) years from the date of
commercial operation of the Project.
Explanation: In case an Applicant is a Consortium, then the term Applicant as
used in this Clause 2.2.1, shall include each Member of such Consortium.

mrfq/ppa/19.09.2013

8

<!-- page 29 -->

For official use

[(e) Other eligibility conditions shall include: 14]
[(i) To be eligible for pre-qualification in respect of a Power Station
having an installed capacity of 2,000 MW or more, the Applicant, its
Members or Associate (or any constituent thereof) shall not have 3 (three)
or more Ultra Mega Power Stations in the construction stage on the
Application Due Date; and
(ii) Only Applicants who agree and undertake to procure the boilers,
turbines, and generators of their Projects from manufacturing facilities
situate in India and owned and operated in India by an Indian company, a
foreign company or a joint venture between an Indian and foreign
company shall be eligible hereunder.]15
2.2.2

To be eligible for pre-qualification and short-listing, an Applicant shall fulfil the
following conditions of eligibility:

(A)

Technical Capacity: For demonstrating technical capacity and experience (the
“Technical Capacity”), the Applicant shall, over the past 5 (five) financial years
preceding the Application Due Date, have:
(i)

paid for, or received payments for, construction of Eligible Project(s); and/
or

(ii)

paid for development of Eligible Project(s) in Category 1 and/or Category
2 specified in Clause 3.2.1; and/ or

(iii)

collected and appropriated revenues from Eligible Project(s) in Category 1
and/or Category 2 specified in Clause 3.2.1,
such that the sum total of the above is more than [Rs.1000 crore (Rs. one
thousand crore)] (the “Threshold Technical Capacity”).16
[Provided that at least one fourth of the Threshold Technical Capacity
shall be from the Eligible Projects in Category 1 and/ or Category 3
specified in Clause 3.2.1.]

(B)

Financial Capacity: The Applicant shall have a minimum Net Worth (the
“Financial Capacity”) of [Rs. 125 crore (Rs. one hundred and twenty five
crore)]17 at the close of the preceding financial year.

14

Other project-specific conditions of eligibility or restrictions, if any, may be stated here, such as a limit on
the number of projects that may be awarded to an entity, including its Associates.
15
This clause will apply only for UMPPs.
16
This amount should be equivalent to one and half times the Estimated Project Cost in case of Eligible
Projects from all sectors specified in Clause 3.2 and may be further reduced to an amount equivalent to the
Estimated Project Cost in case Technical Capacity comprises solely of Eligible Projects in Category 1
and/or Category 3 specified in Clause 3.2.
17
This amount should be 25% (twenty five per cent) of the Estimated Project Cost of the project for which
bids are being invited. The Utility may, if deemed necessary, prescribe a lower amount not less than 15% in
case the Estimated Project Cost exceeds Rs.10,000 cr.

mrfq/ppa/19.09.2013

9

<!-- page 30 -->

For official use

In case of a Consortium, the combined technical capacity and net worth of those
Members, who have and shall continue to have an equity share of at least 26%
(twenty six per cent) each in the SPV, should satisfy the above conditions of
eligibility; provided that each such Member shall, for a period of 2 (two) years
from the date of commercial operation of the Project, hold equity share capital not
less than: (i) 26% (twenty six per cent) of the subscribed and paid up equity of the
SPV; and (ii) 5% (five per cent) of the Total Project Cost specified in the PPA£.
2.2.3

O&M Experience: The Applicant shall either enter into an agreement for
entrusting its operation & maintenance (O&M) obligations to an entity having the
requisite experience or undertake O&M through qualified and experienced staff of
its own.

2.2.4 The Applicants shall enclose with its Application, to be submitted as per the
format at Appendix-I, complete with its Annexes, the following:
(i)

Certificate(s) from its statutory auditors$ or the concerned client(s) stating
the payments made/ received or works commissioned, as the case may be,
during the past 5 years in respect of the projects specified in paragraph
2.2.2 (A) above. In case a particular job/ contract has been jointly executed
by the Applicant (as part of a consortium), it should further support its
claim for the share in work done for that particular job/ contract by
producing a certificate from its statutory auditor or the client; and

(ii)

certificate(s) from its statutory auditors specifying the net worth of the
Applicant, as at the close of the preceding financial year, and also
specifying that the methodology adopted for calculating such net worth
conforms to the provisions of this Clause 2.2.4 (ii). For the purposes of
this RFQ, net worth (the “Net Worth”) shall mean the sum of subscribed
and paid up equity and reserves from which shall be deducted the sum of
revaluation reserves, miscellaneous expenditure not written off and
reserves not available for distribution to equity share holders.

2.2.5 The Applicant should submit a Power of Attorney as per the format at AppendixII, authorising the signatory of the Application to commit the Applicant. In the
case of a Consortium, the Members should submit a Power of Attorney in favour
of the Lead Member as per format at Appendix-III.
2.2.6 Where the Applicant is a single entity, it may be required to form an appropriate
Special Purpose Vehicle, incorporated under the Indian Companies Act, 1956 (the
“SPV”), to execute the PPA and implement the Project. In case the Applicant is a
£

The Utility may, in its discretion, impose further obligations in the PPA, but such obligations should
provide sufficient mobility for partial divestment of equity without compromising the interests of the
Project.
$
In case duly certified audited annual financial statements containing explicitly the requisite details are
provided, a separate certification by statutory auditors would not be necessary in respect of Clause 2.2.4 (i).
In jurisdictions that do not have statutory auditors, the firm of auditors which audits the annual accounts of
the Applicant may provide the certificates required under this RFQ.

mrfq/ppa/19.09.2013

10

<!-- page 31 -->

For official use

Consortium, it shall, in addition to forming an SPV, comply with the following
additional requirements:
(a)

Number of members in a consortium shall not exceed 6 (six), but
information sought in the Application may be restricted to 4 (four)
members in the order of their equity contribution;

(b)

subject to the provisions of sub-clause (a) above, the Application should
contain the information required for each member of the Consortium;

(c)

members of the Consortium shall nominate one member as the lead
member (the “Lead Member”), who shall have an equity share holding of
at least 26% (twenty six per cent) of the paid up and subscribed equity of
the SPV. The nomination(s) shall be supported by a Power of Attorney, as
per the format at Appendix-III, signed by all the other members of the
Consortium;

(d)

the Application should include a brief description of the roles and
responsibilities of individual members, particularly with reference to
financial, technical and O&M obligations;

(e)

an individual Applicant cannot at the same time be member of a
Consortium applying for pre-qualification. Further, a member of a
particular Applicant Consortium cannot be member of any other Applicant
Consortium applying for pre-qualification;

(f)

the members of a Consortium shall form an appropriate SPV to execute
the Project, if awarded to the Consortium;

(g)

members of the Consortium shall enter into a binding Joint Bidding
Agreement, substantially in the form specified at Appendix-IV (the “Jt.
Bidding Agreement”), for the purpose of making the Application and
submitting a Bid in the event of being short-listed. The Jt. Bidding
Agreement, to be submitted along with the Application, shall, inter alia:
(i)

convey the intent to form an SPV with shareholding/ ownership
equity commitment(s) in accordance with this RFQ, which would
enter into the PPA and subsequently perform all the obligations of
the Concessionaire in terms of the PPA, in case the concession to
undertake the Project is awarded to the Consortium;

(ii)

clearly outline the proposed roles and responsibilities, if any, of
each member;

(iii)

commit the minimum equity stake to be held by each member;

(iv)

commit that each of the members, whose experience will be
evaluated for the purposes of this RFQ, shall subscribe to 26%
(twenty six per cent) or more of the paid up and subscribed equity
of the SPV and shall further commit that each such member shall,

mrfq/ppa/19.09.2013

11

<!-- page 32 -->

For official use

for a period of 2 (two) years from the date of commercial operation
of the Project, hold equity share capital not less than: (i) 26%
(twenty six per cent) of the subscribed and paid up equity share
capital of the SPV; and (ii) 5% (five per cent) of the Total Project
Cost specified in the PPA.

(h)

(v)

members of the Consortium undertake that they shall collectively
hold at least 51% (fifty one per cent) of the subscribed and paid up
equity of the SPV at all times until the second anniversary of the
commercial operation date of the Project; and

(vi)

include a statement to the effect that all members of the
Consortium shall be liable jointly and severally for all obligations
of the Concessionaire in relation to the Project until the Financial
Close of the Project is achieved in accordance with the PPA; and

except as provided under this RFQ and the Bidding Documents, there shall
not be any amendment to the Jt. Bidding Agreement without the prior
written consent of the Utility.

2.2.7 Any entity which has been barred by the Central/ State Government, or any entity
controlled by it, from participating in any project (BOT or otherwise), and the bar
subsists as on the date of Application, would not be eligible to submit an
Application, either individually or as member of a Consortium.
2.2.8 An Applicant including any Consortium Member or Associate should, in the last
3 (three) years, have neither failed to perform on any contract, as evidenced by
imposition of a penalty by an arbitral or judicial authority or a judicial
pronouncement or arbitration award against the Applicant, Consortium Member
or Associate, as the case may be, nor has been expelled from any project or
contract by any public entity nor have had any contract terminated by any public
entity for breach by such Applicant, Consortium Member or Associate. Provided,
however, that where an Applicant claims that its disqualification arising on
account of any cause or event specified in this Clause_2.2.8 is such that it does
not reflect (a) any malfeasance on its part in relation to such cause or event; (b)
any wilful default or patent breach of the material terms of the relevant contract;
(c) any fraud, deceit or misrepresentation in relation to such contract; or (d) any
rescinding or abandoning of such contract, it may make a representation to this
affect to the Utility for seeking a waiver from the disqualification hereunder and
the Utility may, in its sole discretion and for reasons to be recorded in writing,
grant such waiver if it is satisfied with the grounds of such representation and is
further satisfied that such waiver is not in any manner likely to cause a material
adverse impact on the Bidding Process or on the implementation of the Project.
2.2.9 In computing the Technical Capacity and Net Worth of the Applicant/
Consortium Members under Clauses 2.2.2, 2.2.4 and 3.2, the Technical Capacity
and Net Worth of their respective Associates would also be eligible hereunder.
For purposes of this RFQ, Associate means, in relation to the Applicant/
Consortium Member, a person who controls, is controlled by, or is under the
mrfq/ppa/19.09.2013

12

<!-- page 33 -->

For official use

common control with such Applicant/ Consortium Member (the “Associate”). As
used in this definition, the expression “control” means, with respect to a person
which is a company or corporation, the ownership, directly or indirectly, of more
than 50% (fifty per cent) of the voting shares of such person, and with respect to a
person which is not a company or corporation, the power to direct the
management and policies of such person by operation of law.
2.2.10 The following conditions shall be adhered to while submitting an Application:
(a)

Applicants should attach clearly marked and referenced continuation
sheets in the event that the space provided in the prescribed forms in the
Annexes is insufficient. Alternatively, Applicants may format the
prescribed forms making due provision for incorporation of the requested
information;

(b)

information supplied by an Applicant (or other constituent Member if the
Applicant is a Consortium) must apply to the Applicant, Member or
Associate named in the Application and not, unless specifically requested,
to other associated companies or firms. Invitation to submit Bids will be
issued only to Applicants whose identity and/ or constitution is identical to
that at pre-qualification;

(c)

in responding to the pre-qualification submissions, Applicants should
demonstrate their capabilities in accordance with Clause 3.1 below; and

(d)

in case the Applicant is a Consortium, each Member should substantially
satisfy the pre-qualification requirements to the extent specified herein.

2.2.11 [While Qualification is open to persons from any country, the following provisions
shall apply:]
[(a)

Where, on the date of the Application, not less than 15% (fifteen per cent)
of the aggregate issued, subscribed and paid up equity share capital in an
Applicant or its Member is held by persons resident outside India or where
an Applicant or its Member is controlled by persons resident outside India;
or]

[(b)

if at any subsequent stage after the date of the Application, there is an
acquisition of not less than 15% (fifteen per cent) of the aggregate issued,
subscribed and paid up equity share capital or control, by persons resident
outside India, in or of the Applicant or its Member;]

[then the Qualification of such Applicant or in the event described in sub clause
(b) above, the continued Qualification of the Applicant shall be subject to
approval of the Utility from national security and public interest perspective. The
decision of the Utility in this behalf shall be final and conclusive and binding on
the Applicant.]
[The holding or acquisition of equity or control, as above, shall include direct or
indirect holding/ acquisition, including by transfer, of the direct or indirect legal
mrfq/ppa/19.09.2013

13

<!-- page 34 -->

For official use

or beneficial ownership or control, by persons acting for themselves or in concert
and in determining such holding or acquisition, the Utility shall be guided by the
principles, precedents and definitions contained in the Securities and Exchange
Board of India (Substantial Acquisition of Shares and Takeovers) Regulations,
1997, or any substitute thereof, as in force on the date of such acquisition.]18
The Applicant shall promptly inform the Utility of any change in the
shareholding, as above, and failure to do so shall render the Applicant liable for
disqualification from the Bidding Process.
2.2.12 Notwithstanding anything to the contrary contained herein, in the event that the
Application Due Date falls within three months of the closing of the latest
financial year of an Applicant, it shall ignore such financial year for the purposes
of its Application and furnish all its information and certification with reference to
the 5 (five) years or 1 (one) year, as the case may be, preceding its latest financial
year. For the avoidance of doubt, financial year shall, for the purposes of an
Application hereunder, mean the accounting year followed by the Applicant in the
course of its normal business.
2.3

Change in composition of the Consortium

2.3.1 Change in the composition of a Consortium will not be permitted by the Utility
during the Qualification Stage.
2.3.2 Where the Bidder is a Consortium, change in the composition of a Consortium
may be permitted by the Utility during the Bid Stage, only where:
(a)

the application for such change is made no later than 15 (fifteen) days
prior to the Bid Due Date;

(b)

the Lead Member continues to be the Lead Member of the Consortium;

(c)

the substitute is at least equal, in terms of Technical Capacity, to the
Consortium Member who is sought to be substituted and the modified
Consortium shall continue to meet the pre-qualification and short-listing
criteria for Applicants; and

(d)

the new Member(s) expressly adopt(s) the Application already made on
behalf of the Consortium as if it were a party to it originally, and is not an
Applicant/Member/Associate of any other Consortium bidding for this
Project.

2.3.3 Approval for change in the composition of a Consortium shall be at the sole
discretion of the Utility and must be approved by the Utility in writing.
2.3.4 The modified/ reconstituted Consortium shall submit a revised Jt. Bidding
Agreement before the Bid Due Date.
18

The provisions of this Clause 2.2.11 may be modified from time to time in accordance with the extant
instructions of the Government.

mrfq/ppa/19.09.2013

14

<!-- page 35 -->

For official use

2.3.5 Notwithstanding anything to the contrary contained in sub-clause (c) (i) of Clause
2.2.1, an Applicant may, within 10 (ten) days after the Application Due Date,
remove from its Consortium any Member who suffers from a Conflict of Interest,
and such removal shall be deemed to cure the Conflict of Interest arising in
respect thereof.
2.4

Number of Applications and costs thereof

2.4.1 No Applicant shall submit more than one Application for the Project. An
applicant applying individually or as a member of a Consortium shall not be
entitled to submit another application either individually or as a member of any
Consortium, as the case may be.
2.4.2 The Applicants shall be responsible for all of the costs associated with the
preparation of their Applications and their participation in the Bidding Process.
The Utility will not be responsible or in any way liable for such costs, regardless
of the conduct or outcome of the Bidding Process.
2.5

Site visit and verification of information
Applicants are encouraged to submit their respective Applications after visiting
the Project site and ascertaining for themselves the site conditions, location,
surroundings, climate, availability of power, water and other utilities for
construction, access to site, handling and storage of materials, weather data,
applicable laws and regulations, and any other matter considered relevant by
them.

2.6

Acknowledgement by Applicant

2.6.1 It shall be deemed that by submitting the Application, the Applicant has:
(a)

made a complete and careful examination of the RFQ;

(b)

received all relevant information requested from the Utility;

(c)

accepted the risk of inadequacy, error or mistake in the information
provided in the RFQ or furnished by or on behalf of the Utility relating to
any of the matters referred to in Clause 2.5 above; and

(d)

agreed to be bound by the undertakings provided by it under and in terms
hereof.

2.6.2 The Utility shall not be liable for any omission, mistake or error in respect of any
of the above or on account of any matter or thing arising out of or concerning or
relating to the RFQ or the Bidding Process, including any error or mistake therein
or in any information or data given by the Utility.
2.7

Right to accept or reject any or all Applications/ Bids

mrfq/ppa/19.09.2013

15

<!-- page 36 -->

For official use

2.7.1 Notwithstanding anything contained in this RFQ, the Utility reserves the right to
accept or reject any Application and to annul the Bidding Process and reject all
Applications/ Bids, at any time without any liability or any obligation for such
acceptance, rejection or annulment, and without assigning any reasons therefor. In
the event that the Utility rejects or annuls all the Bids, it may, in its discretion,
invite all eligible Bidders to submit fresh Bids hereunder.
2.7.2 The Utility reserves the right to reject any Application and/ or Bid if:
(a)

at any time, a material misrepresentation is made or uncovered, or

(b)

the Applicant does not provide, within the time specified by the Utility,
the supplemental information sought by the Utility for evaluation of the
Application.

If the Applicant/Bidder is a Consortium, then the entire Consortium may be
disqualified/ rejected. If such disqualification/ rejection occurs after the Bids have
been opened and the Lowest Bidder gets disqualified/ rejected, then the Utility
reserves the right to:
(i)

invite the remaining Bidders to match the Lowest Bidder/ submit their
Bids in accordance with the RFP; or

(ii)

take any such measure as may be deemed fit in the sole discretion of the
Utility, including annulment of the Bidding Process.

2.7.3 In case it is found during the evaluation or at any time before signing of the PPA
or after its execution and during the period of subsistence thereof, including the
concession thereby granted by the Utility, that one or more of the prequalification conditions have not been met by the Applicant, or the Applicant has
made material misrepresentation or has given any materially incorrect or false
information, the Applicant shall be disqualified forthwith if not yet appointed as
the Concessionaire either by issue of the LOA or entering into of the PPA, and if
the Applicant/SPV has already been issued the LOA or has entered into the PPA,
as the case may be, the same shall, notwithstanding anything to the contrary
contained therein or in this RFQ, be liable to be terminated, by a communication
in writing by the Utility to the Applicant, without the Utility being liable in any
manner whatsoever to the Applicant and without prejudice to any other right or
remedy which the Utility may have under this RFQ, the Bidding Documents, the
PPA or under applicable law.
2.7.4 The Utility reserves the right to verify all statements, information and documents
submitted by the Applicant in response to the RFQ. Any such verification or lack
of such verification by the Utility shall not relieve the Applicant of its obligations
or liabilities hereunder nor will it affect any rights of the Utility thereunder.
B.

DOCUMENTS

2.8

Contents of the RFQ

mrfq/ppa/19.09.2013

16

<!-- page 37 -->

For official use

This RFQ comprises the disclaimer set forth hereinabove, the contents as listed
below, and will additionally include any Addenda issued in accordance with
Clause 2.10.
Invitation for Qualification
Section 1.
Section 2.
Section 3.
Section 4.
Section 5.
Section 6.

Introduction
Instructions to Applicants
Criteria for Evaluation
Fraud & Corrupt Practices
Pre Application Conference
Miscellaneous

Appendices
I.
II.
III.
IV.
V.
2.9

Letter comprising the Application
Power of Attorney for signing of Application
Power of Attorney for Lead Member of Consortium
Joint Bidding Agreement for Consortium
Guidelines of the Department of Disinvestment

Clarifications

2.9.1 Applicants requiring any clarification on the RFQ may notify the Utility in
writing or by fax and e-mail in accordance with Clause 1.2.10. They should send
in their queries before the date specified in the schedule of Bidding Process
contained in Clause 1.3. The Utility shall endeavour to respond to the queries
within the period specified therein, but no later than 10 (ten) days prior to the
Application Due Date. The responses will be sent by fax and/or e-mail. The
Utility will forward all the queries and its responses thereto, to all purchasers of
the RFQ without identifying the source of queries.
2.9.2 The Utility shall endeavour to respond to the questions raised or clarifications
sought by the Applicants. However, the Utility reserves the right not to respond to
any question or provide any clarification, in its sole discretion, and nothing in this
Clause shall be taken or read as compelling or requiring the Utility to respond to
any question or to provide any clarification.
2.9.3 The Utility may also on its own motion, if deemed necessary, issue
interpretations and clarifications to all Applicants. All clarifications and
interpretations issued by the Utility shall be deemed to be part of the RFQ. Verbal
clarifications and information given by Utility or its employees or representatives
shall not in any way or manner be binding on the Utility.
2.10

Amendment of RFQ

2.10.1 At any time prior to the deadline for submission of Application, the Utility may,
for any reason, whether at its own initiative or in response to clarifications
requested by an Applicant, modify the RFQ by the issuance of Addenda.

mrfq/ppa/19.09.2013

17

<!-- page 38 -->

For official use

2.10.2 Any Addendum thus issued will be sent in writing to all those who have
purchased the RFQ.
2.10.3 In order to afford the Applicants a reasonable time for taking an Addendum into
account, or for any other reason, the Utility may, in its sole discretion, extend the
Application Due Date.$
C.

PREPARATION AND SUBMISSION OF APPLICATION

2.11

Language
The Application and all related correspondence and documents in relation to the
Bidding Process shall be in English language. Supporting documents and printed
literature furnished by the Applicant with the Application may be in any other
language provided that they are accompanied by translations of all the pertinent
passages in the English language, duly authenticated and certified by the
Applicant. Supporting materials, which are not translated into English, may not be
considered. For the purpose of interpretation and evaluation of the Application,
the English language translation shall prevail.

2.12

Format and signing of Application

2.12.1 The Applicant shall provide all the information sought under this RFQ. The
Utility will evaluate only those Applications that are received in the required
formats and complete in all respects. Incomplete and /or conditional Applications
shall be liable to rejection.
2.12.2 The Applicant shall prepare 1 (one) original set of the Application (together with
originals/ copies of documents required to be submitted along therewith pursuant
to this RFQ) and clearly marked “ORIGINAL”. In addition, the Applicant shall
submit 1 (one) copy of the Application, along with documents required to be
submitted along therewith pursuant to this RFQ, marked “COPY”. The Applicant
shall also provide 2 (two) soft copies on Compact Disc (CD). In the event of any
discrepancy between the original and the copy, the original shall prevail.
2.12.3 The Application and its copy shall be typed or written in indelible ink and signed
by the authorised signatory of the Applicant who shall also initial each page in
blue ink. In case of printed and published documents, only the cover shall be
initialled. All the alterations, omissions, additions or any other amendments made
to the Application shall be initialled by the person(s) signing the Application. The
Application shall contain page numbers and shall be bound together in hard cover.
2.13

Sealing and Marking of Applications

$

While extending the Application Due Date on account of an addendum, the Utility shall have due regard
for the time required by bidders to address the amendments specified therein. In the case of significant
amendments, at least 15 (fifteen) days shall be provided between the date of amendment and the
Application Due Date, and in the case of minor amendments, at least 7 (seven) days shall be provided.

mrfq/ppa/19.09.2013

18

<!-- page 39 -->

For official use

2.13.1 The Applicant shall submit the Application in the format specified at Appendix-I,
together with the documents specified in Clause 2.13.2, and seal it in an envelope
and mark the envelope as “APPLICATION”. The Applicant shall seal the original
and the copy of the Application, together with their respective enclosures, in
separate envelopes duly marking the envelopes as “ORIGINAL” and “COPY”.
The envelopes shall then be sealed in an outer envelope which shall also be
marked in accordance with Clauses 2.13.2 and 2.13.3.
2.13.2 Each envelope shall contain:
(i)

Application in the prescribed format (Appendix-I) along with Annexes
and supporting documents;

(ii)

Power of Attorney for signing the Application as per the format at
Appendix-II;

(iii)

if applicable, the Power of Attorney for Lead Member of Consortium as
per the format at Appendix-III;

(iv)

copy of the Jt. Bidding Agreement, in case of a Consortium, substantially
in the format at Appendix-IV;

(v)

copy of Memorandum and Articles of Association, if the Applicant is a
body corporate, and if a partnership then a copy of its partnership deed;

(vi)

copies of Applicant’s duly audited balance sheet and profit and loss
account for the preceding five years.; and

[(vii) any other project-specific requirement that may be specified by the
Utility].
Each of the envelopes shall clearly bear the following identification:
“Application for Qualification: **** Project”
and shall clearly indicate the name and address of the Applicant. In addition, the
Application Due Date should be indicated on the right hand corner of each of the
envelopes.
2.13.3 Each of the envelopes shall be addressed to:
ATTN. OF:
DESIGNATION:
ADDRESS:
FAX NO:
E-MAIL ADDRESS:

Mr *******
*******
*******
*******
*******

2.13.4 If the envelopes are not sealed and marked as instructed above, the Utility
assumes no responsibility for the misplacement or premature opening of the
contents of the Application and consequent losses, if any, suffered by the
Applicant.
mrfq/ppa/19.09.2013

19

<!-- page 40 -->

For official use

2.13.5 Applications submitted by fax, telex, telegram or e-mail shall not be entertained
and shall be rejected.
2.14

Application Due Date

2.14.1 Applications should be submitted before 1100 hours IST on the Application Due
Date, at the address provided in Clause 2.13.3 in the manner and form as detailed
in this RFQ. A receipt thereof should be obtained from the person specified in
Clause 2.13.3.
2.14.2 The Utility may, in its sole discretion, extend the Application Due Date by issuing
an Addendum in accordance with Clause 2.10 uniformly for all Applicants.
2.15

Late Applications
Applications received by the Utility after the specified time on the Application
Due Date shall not be eligible for consideration and shall be summarily rejected.

2.16

Modifications/ substitution/ withdrawal of Applications

2.16.1 The Applicant may modify, substitute or withdraw its Application after
submission, provided that written notice of the modification, substitution or
withdrawal is received by the Utility prior to the Application Due Date. No
Application shall be modified, substituted or withdrawn by the Applicant on or
after the Application Due Date.
2.16.2 The modification, substitution or withdrawal notice shall be prepared, sealed,
marked, and delivered in accordance with Clause 2.13, with the envelopes being
additionally
marked
“MODIFICATION”,
“SUBSTITUTION”
or
“WITHDRAWAL”, as appropriate.
2.16.3 Any alteration/ modification in the Application or additional information supplied
subsequent to the Application Due Date, unless the same has been expressly
sought for by the Utility, shall be disregarded.
D.

EVALUATION PROCESS

2.17

Opening and Evaluation of Applications

2.17.1 The Utility shall open the Applications at 1130 hours IST on the Application Due
Date, at the place specified in Clause 2.13.3 and in the presence of the Applicants
who choose to attend.
2.17.2 Applications for which a notice of withdrawal has been submitted in accordance
with Clause 2.16 shall not be opened.
2.17.3 The Utility will subsequently examine and evaluate Applications in accordance
with the provisions set out in Section 3.

mrfq/ppa/19.09.2013

20

<!-- page 41 -->

For official use

2.17.4 Applicants are advised that pre-qualification of Applicants will be entirely at the
discretion of the Utility. Applicants will be deemed to have understood and
agreed that no explanation or justification on any aspect of the Bidding Process or
selection will be given.
2.17.5 Any information contained in the Application shall not in any way be construed
as binding on the Utility, its agents, successors or assigns, but shall be binding
against the Applicant if the Project is subsequently awarded to it on the basis of
such information.
2.17.6 The Utility reserves the right not to proceed with the Bidding Process at any time
without notice or liability and to reject any or all Application(s) without assigning
any reasons.
2.17.7 If any information furnished by the Applicant is found to be incomplete, or
contained in formats other than those specified herein, the Utility may, in its sole
discretion, exclude the relevant project from computation of the Eligible Score of
the Applicant.
2.17.8 In the event that an Applicant claims credit for an Eligible Project, and such claim
is determined by the Utility as incorrect or erroneous, the Utility shall reject such
claim and exclude the same from computation of the Eligible Score, and may
also, while computing the aggregate Experience Score of the Applicant, make a
further deduction equivalent to the claim rejected hereunder. Where any
information is found to be patently false or amounting to a material
misrepresentation, the Utility reserves the right to reject the Application and/ or
Bid in accordance with the provisions of Clauses 2.7.2 and 2.7.3.
2.18

Confidentiality
Information relating to the examination, clarification, evaluation, and
recommendation for the short-listed pre-qualified Applicants shall not be
disclosed to any person who is not officially concerned with the process or is not
a retained professional advisor advising the Utility in relation to, or matters
arising out of, or concerning the Bidding Process. The Utility will treat all
information, submitted as part of Application, in confidence and will require all
those who have access to such material to treat the same in confidence. The
Utility may not divulge any such information unless it is directed to do so by any
statutory entity that has the power under law to require its disclosure or is to
enforce or assert any right or privilege of the statutory entity and/ or the Utility or
as may be required by law or in connection with any legal process.

2.19

Tests of responsiveness

2.19.1 Prior to evaluation of Applications, the Utility shall determine whether each
Application is responsive to the requirements of the RFQ. An Application shall be
considered responsive only if:
(a)

it is received as per format at Appendix-I.

mrfq/ppa/19.09.2013

21

<!-- page 42 -->

For official use

(b)

it is received by the Application Due Date including any extension thereof
pursuant to Clause 2.14.2;

(c)

it is signed, sealed, bound together in hard cover, and marked as stipulated
in Clauses 2.12 and 2.13;

(d)

it is accompanied by the Power of Attorney as specified in Clause 2.2.5,
and in the case of a Consortium, the Power of Attorney as specified in
Clause 2.2.6 (c);

(e)

it contains all the information and documents (complete in all respects) as
requested in this RFQ;

(f)

it contains information in formats same as those specified in this RFQ;

(g)

it contains certificates from its statutory auditors$ in the formats specified
at Appendix-I of the RFQ for each Eligible Project;

(h)

it contains an attested copy of the receipt for payment of [Rs. 50,000
(Rupees fifty thousand only)] to Utility towards the cost of the RFQ
document;

(i)

it is accompanied by the Jt. Bidding Agreement (for Consortium), specific
to the Project, as stipulated in Clause 2.2.6(g);

(j)

it does not contain any condition or qualification; and

(k)

it is not non-responsive in terms hereof.

2.19.2 The Utility reserves the right to reject any Application which is non-responsive
and no request for alteration, modification, substitution or withdrawal shall be
entertained by the Utility in respect of such Application.
2.20

Clarifications

2.20.1 To facilitate evaluation of Applications, the Utility may, at its sole discretion,
seek clarifications from any Applicant regarding its Application. Such
clarification(s) shall be provided within the time specified by the Utility for this
purpose. Any request for clarification(s) and all clarification(s) in response thereto
shall be in writing.
2.20.2 If an Applicant does not provide clarifications sought under Clause 2.20.1 above
within the prescribed time, its Application shall be liable to be rejected. In case
the Application is not rejected, the Utility may proceed to evaluate the
Application by construing the particulars requiring clarification to the best of its
$

In case duly certified audited annual financial statements containing the requisite details are provided, a
separate certification by statutory auditors would not be necessary in respect of Clause 2.19.1 (g). In
jurisdictions that do not have statutory auditors, the firm of auditors which audits the annual accounts of the
Applicant may provide the certificates required under this RFQ.

mrfq/ppa/19.09.2013

22

<!-- page 43 -->

For official use

understanding, and the Applicant shall be barred from subsequently questioning
such interpretation of the Utility.
E.

QUALIFICATION AND BIDDING

2.21

Short-listing and notification
After the evaluation of Applications, the Utility would announce a list of shortlisted pre-qualified Applicants (Bidders) who will be eligible for participation in
the Bid Stage. At the same time, the Utility would notify the other Applicants that
they have not been short-listed. The Utility will not entertain any query or
clarification from Applicants who fail to qualify.

2.22

Submission of Bids
The Bidders will be requested to submit a Bid in the form and manner to be set
out in the Bidding Documents.
Only pre-qualified Applicants shall be invited by the Utility to submit their Bids
for the Project. The Utility is likely to provide a comparatively short time span for
submission of the Bids for the Project. The Applicants are therefore advised to
visit the site and familiarise themselves with the Project by the time of submission
of the Application. No extension of time is likely to be considered for submission
of Bids pursuant to invitation that may be issued by the Utility.

2.23

Proprietary data
All documents and other information supplied by the Utility or submitted by an
Applicant to the Utility shall remain or become the property of the Utility.
Applicants are to treat all information as strictly confidential and shall not use it
for any purpose other than for preparation and submission of their Application.
The Utility will not return any Application or any information provided along
therewith.

2.24

Correspondence with the Applicant
Save and except as provided in this RFQ, the Utility shall not entertain any
correspondence with any Applicant in relation to the acceptance or rejection of
any Application.

mrfq/ppa/19.09.2013

23

<!-- page 44 -->

For official use

3. CRITERIA FOR EVALUATION
3.1

Evaluation parameters

3.1.1 Only those Applicants who meet the eligibility criteria specified in Clause 2.2.2
above shall qualify for evaluation under this Section 3. Applications of firms/
consortia who do not meet these criteria shall be rejected.
3.1.2 The Applicant’s competence and capability is proposed to be established by the
following parameters:

3.2

(a)

Technical Capacity; and

(b)

Financial Capacity

Technical Capacity for purposes of evaluation

3.2.1 Subject to the provisions of Clause 2.2, the following categories of experience
would qualify as Technical Capacity and eligible experience (the "Eligible
Experience") in relation to eligible projects as stipulated in Clauses 3.2.3 and
3.2.4 (the "Eligible Projects"):
Category 1:
Category 2:
Category 3:
Category 4:

Project experience on Eligible Projects in power sector that qualify
under Clause 3.2.3
Project experience on Eligible Projects in core sector that qualify
under Clause 3.2.3
Construction experience on Eligible Projects in power sector that
qualify under Clause 3.2.4
Construction experience on Eligible Projects in core sector that
qualify under Clause 3.2.4

For the purpose of this RFQ:
(i)

power sector would be deemed to include generation, transmission and
distribution of electricity; and

(ii)

core sector would be deemed to include, telecom, ports, airports, railways,
metro rail, highways and bridges, industrial parks/ estates, logistic parks,
pipelines, irrigation, water supply, sewerage and real estate development.$

3.2.2 Eligible Experience in respect of each category shall be measured only for
Eligible Projects.
3.2.3 For a project to qualify as an Eligible Project under Categories 1 and 2:

$

Real estate development shall not include residential flats unless they form part of a real estate complex or
township which has been built by the Applicant.

mrfq/ppa/19.09.2013

24

<!-- page 45 -->

For official use

(a)

It should have been undertaken as a project on BOT, BOLT, BOO, BOOT
or other similar basis for providing its output or services to a public sector
entity or for providing non-discriminatory access to users in pursuance of
its charter, concession or contract, as the case may be. For the avoidance
of doubt, a project which constitutes a natural monopoly such as an airport
or port should normally be included in this category even if it is not based
on a long-term agreement with a public entity;

(b)

the entity claiming experience should have held, in the company owing the
Eligible Project, a minimum of 26% (twenty six per cent) equity during
the entire year for which Eligible Experience is being claimed;

(c)

the capital cost of the project should be more than [Rs. 100 crore (Rs. one
hundred crore)]19; and

(d)

the entity claiming experience shall, during the last 5 (five) financial years
preceding the Application Due Date, have (i) paid for development of the
project (excluding the cost of land), (ii) collected and appropriated the
revenues from users availing of non-discriminatory access to or use of
fixed project assets, such as revenues from transmission/distribution
systems, highways, airports, ports and railway infrastructure, and/or (iii)
collected and appropriated the revenues from sale of electricity produced
by it, but shall not include revenues from sale or provision of goods or
services such as, gas, petroleum products, telecommunications or
fare/freight revenues and other incomes of the company owning the
Project or revenues from sale of electricity by a distribution company.

3.2.4 For a project to qualify as an Eligible Project under Categories 3 and 4, the
Applicant should have paid for execution of its construction works or received
payments from its client(s) for construction works executed, fully or partially,
during the 5 (five) financial years immediately preceding the Application Due
Date, and only the payments (gross) actually made or received, as the case may
be, during such 5 (five) financial years shall qualify for purposes of computing the
Experience Score. However, payments/receipts of less than [Rs. 100 crore (Rs.
one hundred crore)]20 shall not be reckoned as payments/receipts for Eligible
Projects. For the avoidance of doubt, construction works shall not include supply
of goods or equipment except when such goods or equipment form part of a turnkey construction contract/ EPC contract for the project. Further, the cost of land
shall not be included hereunder.
3.2.5 The Applicant shall quote experience in respect of a particular Eligible Project
under any one category only, even though the Applicant (either individually or
along with a member of the Consortium) may have played multiple roles in the
cited project. Double counting for a particular Eligible Project shall not be
permitted in any form.
19

This amount should not be less than 20% of the Estimated Project Cost. In case of projects with an
Estimated Project Cost of Rs 1,000 cr or above, this amount may be suitably reduced but not less than 10%
in any case.
20
This amount should be determined as per footnote15 above.

mrfq/ppa/19.09.2013

25

<!-- page 46 -->

For official use

3.2.6 Subject to the provisions of Clause 3.2.7, an Applicant’s experience shall be
measured and stated in terms of a score (the "Experience Score"). The
Experience Score for an Eligible Project in a given category would be the eligible
payments and/or receipts specified in Clause 2.2.2 (A), divided by one crore and
then multiplied by the applicable factor in Table 3.2.6 below. In case the
Applicant has experience across different categories, the score for each category
would be computed as above and then aggregated to arrive at its Experience
Score.
Table 3.2.6: Factors for Experience across categories21
Categories

Factor

Category 1

1.25

Category 2

1.00

Category 3

0.75

Category 4

0.50

3.2.7 The Experience Score determined in accordance with Clause 3.2.6 in respect of an
Eligible Project situated in a developed country which is a member of OECD
shall be further multiplied by a factor of 0.5 (zero point five) and the product
thereof shall be the Experience Score for such Eligible Project.
3.2.8 Experience for any activity relating to an Eligible Project shall not be claimed by
two or more Members of the Consortium. In other words, no double counting by a
Consortium in respect of the same experience shall be permitted in any manner
whatsoever.
3.3

Details of Experience

3.3.1 The Applicant should furnish the details of Eligible Experience for the last 5
(five) financial years immediately preceding the Application Due Date.
3.3.2 The Applicants must provide the necessary information relating to Technical
Capacity as per format at Annex-II of Appendix-I.
3.3.3 The Applicant should furnish the required Project-specific information and
evidence in support of its claim of Technical Capacity, as per format at Annex-IV
of Appendix-I.
3.4

Financial information for purposes of evaluation

3.4.1 The Application must be accompanied by the Audited Annual Reports of the
Applicant (of each Member in case of a Consortium) for the last 5 (five) financial
years, preceding the year in which the Application is made.

21

These factors may be modified by the Utility by up to 15% thereof in each category.

mrfq/ppa/19.09.2013

26

<!-- page 47 -->

For official use

3.4.2 In case the annual accounts for the latest financial year are not audited and
therefore the Applicant cannot make it available, the Applicant shall give an
undertaking to this effect and the statutory auditor shall certify the same. In such a
case, the Applicant shall provide the Audited Annual Reports for 5 (five) years
preceding the year for which the Audited Annual Report is not being provided.
3.4.3 The Applicant must establish the minimum Net Worth specified in Clause 2.2.2
(B), and provide details as per format at Annex-III of Appendix-I.
3.5

Short-listing of Applicants22

3.5.1 The credentials of eligible Applicants shall be measured in terms of their
Experience Score. The sum total of the Experience Scores for all Eligible Projects
shall be the ‘Aggregate Experience Score’ of a particular Applicant. In case of a
Consortium, the Aggregate Experience Score of each of its Members, who have
an equity share of at least 26% in such Consortium, shall be summed up for
arriving at the combined Aggregate Experience Score of the Consortium.
3.5.2 The Applicants shall then be ranked on the basis of their respective Aggregate
Experience Scores and short-listed for submission of Bids. The Utility expects to
short-list upto 7 (seven)23 pre-qualified Applicants for participation in the Bid
Stage. The Utility, however, reserves the right to increase the number of shortlisted pre-qualified Applicants by adding additional Applicant.
3.5.3 The Utility may, in its discretion, maintain a reserve list of pre-qualified
Applicants who may be invited to substitute the short-listed Applicants in the
event of their withdrawal from the Bidding Process or upon their failure to
conform to the conditions specified herein; provided that a substituted Applicant
shall be given at least 30 (thirty) days to submit its Bid.
[3.5

Pre-qualification and scoring

3.5.1 In the case of this Ultra Mega Power Project (UMPP), the application of factors
specified in Table 3.2.6 contained in Clause 3.2.6 as shall be dispensed with and
the Experience Scores shall be determined without application of the factors
specified therein. All other references to such factors in this RFQ shall also be
deemed to be void.
3.5.2 All pre-qualified Applicants shall be eligible for participating in the Bid stage of
this UMPP and references to short-listing in this RFQ shall be deemed to be
void.]

22

Clause 3.5 shall be omitted in the case of a UMPP and substituted by Clause 3.5 as in italics.
In case there are no obligations or liabilities for buy-out of project assets or any similar obligations, the
Utility may suitably increase the number of short-listed bidders.
23

mrfq/ppa/19.09.2013

27

<!-- page 48 -->

For official use

4.

FRAUD AND CORRUPT PRACTICES

4.1

The Applicants and their respective officers, employees, agents and advisers shall
observe the highest standard of ethics during the Bidding Process.
Notwithstanding anything to the contrary contained herein, the Utility may reject
an Application without being liable in any manner whatsoever to the Applicant if
it determines that the Applicant has, directly or indirectly or through an agent,
engaged in corrupt practice, fraudulent practice, coercive practice, undesirable
practice or restrictive practice in the Bidding Process.

4.2

Without prejudice to the rights of the Utility under Clause 4.1 hereinabove, if an
Applicant is found by the Utility to have directly or indirectly or through an
agent, engaged or indulged in any corrupt practice, fraudulent practice, coercive
practice, undesirable practice or restrictive practice during the Bidding Process,
such Applicant shall not be eligible to participate in any tender or RFQ issued by
the Utility during a period of 2 (two) years from the date such Applicant is found
by the Utility to have directly or indirectly or through an agent, engaged or
indulged in any corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice, as the case may be.

4.3

For the purposes of this Clause 4, the following terms shall have the meaning
hereinafter respectively assigned to them:
(a)

“corrupt practice” means (i) the offering, giving, receiving, or soliciting,
directly or indirectly, of anything of value to influence the actions of any
person connected with the Bidding Process (for avoidance of doubt,
offering of employment to, or employing, or engaging in any manner
whatsoever, directly or indirectly, any official of the Utility who is or has
been associated in any manner, directly or indirectly, with the Bidding
Process or the LOA or has dealt with matters concerning the PPA or
arising therefrom, before or after the execution thereof, at any time prior
to the expiry of one year from the date such official resigns or retires from
or otherwise ceases to be in the service of the Utility, shall be deemed to
constitute influencing the actions of a person connected with the Bidding
Process); or (ii) save and except as permitted under sub clause (d) of
Clause 2.2.1, engaging in any manner whatsoever, whether during the
Bidding Process or after the issue of the LOA or after the execution of the
PPA, as the case may be, any person in respect of any matter relating to
the Project or the LOA or the PPA, who at any time has been or is a legal,
financial or technical adviser of the Utility in relation to any matter
concerning the Project;

(b)

“fraudulent practice” means a misrepresentation or omission of facts or
suppression of facts or disclosure of incomplete facts, in order to influence
the Bidding Process;

(c)

“coercive practice” means impairing or harming or threatening to impair
or harm, directly or indirectly, any person or property to influence any
person’s participation or action in the Bidding Process;

mrfq/ppa/19.09.2013

28

<!-- page 49 -->

For official use

(d)

“undesirable practice” means (i) establishing contact with any person
connected with or employed or engaged by the Utility with the objective
of canvassing, lobbying or in any manner influencing or attempting to
influence the Bidding Process; or (ii) having a Conflict of Interest; and

(e)

“restrictive practice” means forming a cartel or arriving at any
understanding or arrangement among Applicants with the objective of
restricting or manipulating a full and fair competition in the Bidding
Process.

mrfq/ppa/19.09.2013

29

<!-- page 50 -->

For official use

5.

PRE-APPLICATION CONFERENCE

5.1

A Pre-Application conference of the interested parties shall be convened at the
designated date, time and place. Only those persons who have purchased the RFQ
document shall be allowed to participate in the Pre-Application conference.
Applicants who have downloaded the RFQ document from the Utility’s website
(www.*****) should submit a Demand Draft of [Rs. 50,000 (Rupees fifty
thousand only)] towards the cost of document, through their representative
attending the conference. A maximum of three representatives of each Applicant
shall be allowed to participate on production of authority letter from the
Applicant.

5.2

During the course of Pre-Application conference, the Applicants will be free to
seek clarifications and make suggestions for consideration of the Utility. The
Utility shall endeavour to provide clarifications and such further information as it
may, in its sole discretion, consider appropriate for facilitating a fair, transparent
and competitive Bidding Process.

mrfq/ppa/19.09.2013

30

<!-- page 51 -->

For official use

6.

MISCELLANEOUS

6.1

The Bidding Process shall be governed by, and construed in accordance with, the
laws of India and the Courts at [New Delhi] shall have exclusive jurisdiction over
all disputes arising under, pursuant to and/ or in connection with the Bidding
Process.

6.2

The Utility, in its sole discretion and without incurring any obligation or liability,
reserves the right, at any time, to;

6.3

(a)

suspend and/ or cancel the Bidding Process and/ or amend and/ or
supplement the Bidding Process or modify the dates or other terms and
conditions relating thereto;

(b)

consult with any Applicant in order to receive clarification or further
information;

(c)

pre-qualify or not to pre-qualify any Applicant and/ or to consult with any
Applicant in order to receive clarification or further information;

(d)

retain any information and/ or evidence submitted to the Utility by, on
behalf of, and/ or in relation to any Applicant; and/ or

(e)

independently verify, disqualify, reject and/ or accept any and all
submissions or other information and/ or evidence submitted by or on behalf
of any Applicant.

It shall be deemed that by submitting the Application, the Applicant agrees and
releases the Utility, its employees, agents and advisers, irrevocably,
unconditionally, fully and finally from any and all liability for claims, losses,
damages, costs, expenses or liabilities in any way related to or arising from the
exercise of any rights and/ or performance of any obligations hereunder and the
Bidding Documents, pursuant hereto, and/ or in connection with the Bidding
Process, to the fullest extent permitted by applicable law, and waives any and all
rights and/ or claims it may have in this respect, whether actual or contingent,
whether present or in future.

mrfq/ppa/19.09.2013

31

<!-- page 52 -->

For official use

APPENDIX I

Letter Comprising the Application for Pre-Qualification
(Refer Clause 2.13.2)
Dated:
To,
[The *******,
***********
***********]
Sub: Application for pre-qualification for ***** Project
Dear Sir,
With reference to your RFQ document dated ………..$, I/we, having examined
the RFQ document and understood its contents, hereby submit my/our Application for
Qualification for the aforesaid project. The Application is unconditional and unqualified.
2.
I/ We acknowledge that the Utility will be relying on the information provided in
the Application and the documents accompanying such Application for pre-qualification
of the Applicants for the aforesaid project, and we certify that all information provided in
the Application and in Annexes I to IV is true and correct; nothing has been omitted
which renders such information misleading; and all documents accompanying such
Application are true copies of their respective originals.
3.
This statement is made for the express purpose of qualifying as a Bidder for the
development, construction, operation and maintenance of the aforesaid Project and for
sale of power to the Utility.
4.
I/ We shall make available to the Utility any additional information it may find
necessary or require to supplement or authenticate the Qualification statement.
5.
I/ We acknowledge the right of the Utility to reject our Application without
assigning any reason or otherwise and hereby waive, to the fullest extent permitted by
applicable law, our right to challenge the same on any account whatsoever.
6.
I/ We certify that in the last three years, we/ any of the Consortium Members or
our/ their Associates have neither failed to perform on any contract, as evidenced by
imposition of a penalty by an arbitral or judicial authority or a judicial pronouncement or
arbitration award, nor been expelled from any project or contract by any public authority
nor have had any contract terminated by any public authority for breach on our part.
7.

I/ We declare that:
(a)

I/ We have examined and have no reservations to the RFQ document,
including any Addendum issued by the Utility;

$

All blank spaces shall be suitably filled up by the Applicant to reflect the particulars relating to such
Applicant.

mrfq/ppa/19.09.2013

32

<!-- page 53 -->

For official use

(b)

I/ We do not have any conflict of interest in accordance with Clauses
2.2.1(c) and 2.2.1(d) of the RFQ document;

(c)

I/We have not directly or indirectly or through an agent engaged or
indulged in any corrupt practice, fraudulent practice, coercive practice,
undesirable practice or restrictive practice, as defined in Clause 4.3 of the
RFQ document, in respect of any tender or request for proposal issued by
or any agreement entered into with the Utility or any other public sector
enterprise or any government, Central or State; and

(d)

I/ We hereby certify that we have taken steps to ensure that in conformity
with the provisions of Section 4 of the RFQ document, no person acting
for us or on our behalf has engaged or will engage in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice or restrictive
practice.

8.
I/ We understand that you may cancel the Bidding Process at any time and that
you are neither bound to accept any Application that you may receive nor to invite the
Applicants to Bid for the Project, without incurring any liability to the Applicants, in
accordance with Clause 2.17.6 of the RFQ document.
9.
I/ We believe that we/ our Consortium/ proposed Consortium satisfy(s) the Net
Worth criteria and meet(s) all the requirements as specified in the RFQ document and
are/ is qualified to submit a Bid.
10.
I/ We declare that we/ any Member of the Consortium, or our/ its Associates are
not a Member of a/ any other Consortium applying for pre-qualification.
11.
I/ We certify that in regard to matters other than security and integrity of the
country, we/ any Member of the Consortium or any of our/ their Associates have not been
convicted by a Court of Law or indicted or adverse orders passed by a regulatory
authority which could cast a doubt on our ability to undertake the Project or which relates
to a grave offence that outrages the moral sense of the community.
12.
I/ We further certify that in regard to matters relating to security and integrity of
the country, we/ any Member of the Consortium or any of our/ their Associates have not
been charge-sheeted by any agency of the Government or convicted by a Court of Law.
13.
I/ We further certify that no investigation by a regulatory authority is pending
either against us/ any Member of the Consortium or against our/ their Associates or
against our CEO or any of our directors/ managers/ employees.


In case the Applicant is unable to provide the certification specified in paragraphs 6 or 13, it may precede
the paragraph by the words, viz. “Except as specified in Schedule **** hereto”. The exceptions to the
certification or any disclosures relating thereto may be clearly stated in a Schedule to be attached to the
Application. The Utility will consider the contents of such Schedule and determine whether or not the
exceptions/disclosures are of a nature that could cast a doubt on the ability or suitability of the Applicant to
undertake the Project.

mrfq/ppa/19.09.2013

33

<!-- page 54 -->

For official use

14.
[I/ We further certify that we are qualified to submit a Bid in accordance with the
guidelines for qualification of bidders seeking to acquire stakes in Public Sector
Enterprises through the process of disinvestment issued by the GOI vide Department of
Disinvestment OM No. 6/4/2001-DD-II dated 13th July, 2001 which guidelines apply
mutatis mutandis to the Bidding Process. A copy of the aforesaid guidelines form part of
the RFQ at Appendix-V thereof.]
15.
I/ We undertake that in case due to any change in facts or circumstances during
the Bidding Process, we are attracted by the provisions of disqualification in terms of the
provisions of this RFQ, we shall intimate the Utility of the same immediately.
16.
The Statement of Legal Capacity as per format provided at Annex-V in
Appendix-I of the RFQ document, and duly signed, is enclosed. The power of attorney
for signing of application and the power of attorney for Lead Member of consortium, as
per format provided at Appendix II and III respectively of the RFQ, are also enclosed.
17.
I/ We understand that the selected Bidder shall either be an existing Company
incorporated under the Indian Companies Act, 1956, or shall incorporate as such prior to
execution of the PPA. In cases where the Utility has already established an SPV for the
Project, the selected Bidder shall acquire the equity thereof.
18.
I/ We hereby confirm that we [are in compliance of/ shall comply with] the O&M
requirements specified in Clause 2.2.3.
19.
I/ We hereby irrevocably waive any right or remedy which we may have at any
stage at law or howsoever otherwise arising to challenge or question any decision taken
by the Utility in connection with the selection of Applicants, selection of the Bidder, or
in connection with the selection/ Bidding Process itself, in respect of the above
mentioned Project and the terms and implementation thereof.
20.
I/ We agree and undertake to abide by all the terms and conditions of the RFQ
document.
21.
I/ We certify that in terms of the RFQ, my/our Networth is Rs. ………………..
(Rs. in words) and the Aggregate Experience Score is ……………… (number in words).
{22. We agree and undertake to be jointly and severally liable for all the obligations of
the Concessionaire under the PPA till occurrence of Financial Close in accordance with
the PPA.}$
In witness thereof, I/ we submit this application under and in accordance with the terms
of the RFQ document.
Yours faithfully,

Date:

(Signature, name and designation of the Authorised Signatory)

Place:
Name and seal of the Applicant/ Lead Member
Note: Paragraphs in square parenthesis may be omitted, if not applicable, or modified as
necessary.
$

Omit if the Applicant is not a Consortium.

mrfq/ppa/19.09.2013

34

<!-- page 55 -->

For official use

Appendix I
Annex-I
ANNEX-I

Details of Applicant
1.

(a)

Name:

(b)

Country of incorporation:

(c)

Address of the corporate headquarters and its branch office(s), if any,
in India:

(d)

Date of incorporation and/ or commencement of business:

2.

Brief description of the Company including details of its main lines of
business and proposed role and responsibilities in this Project:

3.

Details of individual(s) who will serve as the point of contact/ communication
for the Utility:

4.

5.

(a)

Name:

(b)

Designation:

(c)

Company:

(d)

Address:

(e)

Telephone Number:

(f)

E-Mail Address:

(g)

Fax Number:

Particulars of the Authorised Signatory of the Applicant:
(a)

Name:

(b)

Designation:

(c)

Address:

(d)

Phone Number:

(e)

Fax Number:

In case of a Consortium:
(a)

The information above (1-4) should be provided for all the Members of
the Consortium.

(b)

A copy of the Jt. Bidding Agreement, as envisaged in Clause 2.2.6(g)
should be attached to the Application.

(c)

Information regarding the role of each Member should be provided as
per table below:

mrfq/ppa/19.09.2013

35

<!-- page 56 -->

For official use

Appendix I
Annex-I

Sl.
No.

Name of Member

Role*
Percentage of equity in the
{Refer Clause Consortium{Refer Clauses
2.2.6(d)}$
2.2.6(a), (c) & (g)}

1.
2.
3.
4.
*

The role of each Member, as may be determined by the Applicant,
should be indicated in accordance with instruction 4 at Annex-IV.

(d)

The following information shall also be provided for each Member of
the Consortium:

Name of Applicant/ member of Consortium:

6.

No.

Criteria

1.

Has the Applicant/ constituent of the Consortium
been barred by the [Central/ State] Government, or
any entity controlled by it, from participating in any
project (BOT or otherwise)?

2.

If the answer to 1 is yes, does the bar subsist as on
the date of Application?

3.

Has the Applicant/ constituent of the Consortium
paid liquidated damages of more than 5% of the
contract value in a contract due to delay or has been
penalised due to any other reason in relation to
execution of a contract, in the last three years?

Yes

No

A statement by the Applicant and each of the Members of its Consortium
(where applicable) or any of their Associates disclosing material nonperformance or contractual non-compliance in past projects, contractual
disputes and litigation/ arbitration in the recent past is given below (Attach
extra sheets, if necessary):

$

All provisions contained in curly parenthesis shall be suitably modified by the Applicant to reflect the
particulars relating to such Applicant.

mrfq/ppa/19.09.2013

36

<!-- page 57 -->

For official use

Appendix I
Annex-II
ANNEX-II

Technical Capacity of the Applicant @
(Refer to Clauses 2.2.2(A), 3.2 and 3.3 of the RFQ)
Applicant
type #

Member Project CateCode* Code** gory$

Experience¥
(Equivalent Rs. crore)$$

Experience
Score£

Payments Payments Revenues
made/
made for appropriated
received for developme
from
construction
nt of
Eligible
of Eligible Eligible Projects in
Projects in Projects in Categories 1
Categories 3 Categories
and 2
and 4
1 and 2
(1)

(2)

Single
entity
Applicant

(3)

(4)

(5)

(6)

(7)

(8)

a
b
c
d

Consortium
Member 1

1a
1b
1c
1d

Consortium
Member 2

2a
2b
2c
2d

Consortium
Member 3

3a
3b
3c
3d

Consortium
Member 4

4a
4b
4c
4d
Aggregate Experience Score =

mrfq/ppa/19.09.2013

37

<!-- page 58 -->

For official use

Appendix I
Annex-II
@

Provide details of only those projects that have been undertaken by the Applicant
under its own name and/ or by an Associate specified in Clause 2.2.9 and/ or by a
project company eligible under Clause 3.2.3(b). In case of Categories 1 and 2,
include only those projects which have an estimated capital cost exceeding the
amount specified in Clause 3.2.3(c) and for Categories 3 and 4, include only those
projects where the payments made/received exceed the amount specified in Clause
3.2.4. In case the Application Due Date falls within 3 (three) months of the close of
the latest financial year, refer to Clause 2.2.12.
#

An Applicant consisting of a single entity should fill in details as per the row titled
Single entity Applicant and ignore the rows titled Consortium Member. In case of a
Consortium, the row titled Single entity Applicant may be ignored. In case credit is
claimed for an Associate, necessary evidence to establish the relationship of the
Applicant with such Associate, in terms of Clause 2.2.9, shall be provided.
* Member Code shall indicate NA for Not Applicable in case of a single entity
Applicant. For other Members, the following abbreviations are suggested viz. LM
means Lead Member, TM means Technical Member, FM means Financial Member,
OMM means Operation & Maintenance Member, OM means Other Member.
**Refer Annex-IV of this Appendix-I. Add more rows if necessary.
$

Refer Clause 3.2.1.

¥ In the case of Eligible Projects in Categories 1 and 2, the figures in columns 6 and 7

may be added for computing the Experience Score of the respective projects. In the
case of Categories 3 and 4, construction shall not include supply of goods or
equipment except when such goods or equipment form part of a turn-key construction
contract/ EPC contract for the project. In no case shall the cost of land be included
while computing the Experience Score of an Eligible Project.
$$

For conversion of US Dollars to Rupees, the rate of conversion shall be Rupees [50
(fifty)] to a US Dollar. In case of any other currency, the same shall first be converted
to US Dollars as on the date 60 (sixty) days prior to the Application Due Date, and
the amount so derived in US Dollars shall be converted into Rupees at the aforesaid
rate. The conversion rate of such currencies shall be the daily representative
exchange rates published by the International Monetary Fund for the relevant date.
£

Divide the amount in the Experience column by one crore and [then multiply the
result thereof by the applicable factor set out in Table 3.2.6 to]24 arrive at the
Experience Score for each Eligible Project. In the case of an Eligible Projecst
situated in an OECD country, the Experience Score so arrived at shall be further
multiplied by 0.5, in accordance with the provisions of Clause 3.2.7, and the product
thereof shall be the Experience Score for such Eligible Projects.

24

The words in square parenthesis may be omitted in case of a UMPP.

mrfq/ppa/19.09.2013

38

<!-- page 59 -->

For official use

Appendix I
Annex-III
ANNEX-III

Financial Capacity of the Applicant
(Refer to Clauses 2.2.2(B), 2.2.4 (ii) and 3.4 of the RFQ)
(In Rs. crore$$)
Applicant
type $

(1)

Member
Code£

(2)

Net Cash Accruals

Net
Worth€

Year

Year

Year

Year

Year

Year

1

2

3

4

5

1

(3)

(4)

(5)

(6)

(7)

(8)

Single entity
Applicant
Consortium
Member 1
Consortium
Member 2
Consortium
Member 3
Consortium
Member 4
TOTAL

Name & address of Applicant’s Bankers:
$

An Applicant consisting of a single entity should fill in details as per the row titled Single entity
Applicant and ignore the rows titled Consortium Members. In case of a Consortium, row titled Single
entity Applicant may be ignored.
£

For Member Code, see instruction 4 at Annex-IV of this Appendix-I.
The Applicant should provide details of its own Financial Capacity or of an Associate specified in
Clause 2.2.9.
€

$$

For conversion of other currencies into rupees, see note below Annex-II of Appendix-I.

mrfq/ppa/19.09.2013

39

<!-- page 60 -->

For official use

Appendix I
Annex-III
Instructions:
1.

The Applicant/ its constituent Consortium Members shall attach copies of the
balance sheets, financial statements and Annual Reports for 5 (five) years
preceding the Application Due Date. The financial statements shall:
(a)

reflect the financial situation of the Applicant or Consortium Members
and its/ their Associates where the Applicant is relying on its
Associate’s financials;

(b)

be audited by a statutory auditor;

(c)

be complete, including all notes to the financial statements; and

(d)

correspond to accounting periods already completed and audited (no
statements for partial periods shall be requested or accepted).

2.

Net Cash Accruals shall mean Profit After Tax + Depreciation.

3.

Net Worth shall mean (Subscribed and Paid-up Equity + Reserves) less
(Revaluation reserves + miscellaneous expenditure not written off + reserves
not available for distribution to equity shareholders).

4.

Year 1 will be the latest completed financial year, preceding the bidding. Year
2 shall be the year immediately preceding Year 1 and so on. In case the
Application Due Date falls within 3 (three) months of the close of the latest
financial year, refer to Clause 2.2.12.

5.

In the case of a Consortium, a copy of the Jt. Bidding Agreement shall be
submitted in accordance with Clause 2.2.6 (g) of the RFQ document.

6.

The applicant shall also provide the name and address of the Bankers to the
Applicant.

7.

The Applicant shall provide an Auditor’s Certificate specifying the net worth
of the Applicant and also specifying the methodology adopted for calculating
such net worth in accordance with Clause 2.2.4 (ii) of the RFQ document.

mrfq/ppa/19.09.2013

40

<!-- page 61 -->

For official use

Appendix I
Annex-IV
ANNEX-IV

Details of Eligible Projects
(Refer to Clauses 2.2.2(A), 3.2 and 3.3 of the RFQ)
Project Code:

Member Code:

Item

Refer
Instruction

Particulars of the Project

(1)

(2)

(3)

Title & nature of the project
Category
Year-wise (a) payments
received/ made for
construction, (b) payments
made for development of
BOT, BOLT, BOO, BOOT
or projects undertaken on
similar basis and/ or (c)
revenues appropriated
Entity for which the project
was constructed/ developed
Location
Project cost
Date of commencement of
project/ contract
Date of completion/
commissioning
Equity shareholding
(with period during which
equity was held)
Whether credit is being taken
for the Eligible Experience of
an Associate (Yes/ No)

5
6

7

8

9
10

15

Instructions:Applicants are expected to provide information in respect of each
Eligible Project in this Annex. The projects cited must comply with the eligibility
criteria specified in Clause 3.2.3 and 3.2.4 of the RFQ, as the case may be.
Information provided in this section is intended to serve as a back up for information
provided in the Application. Applicants should also refer to the Instructions below.

mrfq/ppa/19.09.2013

41

<!-- page 62 -->

For official use

Appendix I
Annex-IV
1.

For a single entity Applicant, the Project Codes would be a, b, c, d etc. In case
the Applicant is a Consortium then for Member 1, the Project Codes would be
1a, 1b, 1c, 1d etc., for Member 2 the Project Codes shall be 2a, 2b, 2c, 2d etc.,
and so on.

2.

A separate sheet should be filled for each Eligible Project.

3.

Member Code shall indicate NA for Not Applicable in case of a single entity
Applicant. For other Members, the following abbreviations are suggested viz.
LM means Lead Member, TM means Technical Member, FM means Financial
Member, OMM means Operation & Maintenance Member; and OM means
Other Member. In case the Eligible Project relates to an Associate of the
Applicant or its Member, write “Associate” along with Member Code.

4.

Refer to Clause 3.2.1 of the RFQ for category number.

5.

The total payments received/ made and/or revenues appropriated for each
Eligible Project are to be stated in Annex-II of this Appendix-I. The figures to
be provided here should indicate the break-up for the past 5 (five) financial
years. Year 1 refers to the financial year immediately preceding the
Application Due Date; Year 2 refers to the year before Year 1, Year 3 refers to
the year before Year 2, and so on (Refer Clause 2.2.12). For Categories 1 and
2, expenditure on development of the project and/or revenues appropriated, as
the case may be, should be provided, but only in respect of projects having an
estimated capital cost exceeding the amount specified in Clause 3.2.3(c). In
case of Categories 3 and 4, payments made/ received only in respect of
construction should be provided, but only if the amount paid/received exceeds
the minimum specified in Clause 3.2.4. Payment for construction works
should only include capital expenditure, and should not include expenditure on
repairs and maintenance.

6.

In case of projects in Categories 1 and 2, particulars such as name, address and
contact details of owner/ Utility/ Agency (i.e. concession grantor, counter
party to PPA, etc.) may be provided. In case of projects in Categories 3 and 4,
similar particulars of the client need to be provided.

7.

Provide the estimated capital cost of Eligible Project. Refer to Clauses 3.2.3
and 3.2.4

8.

For Categories 1 and 2, the date of commissioning of the project, upon
completion, should be indicated. In case of Categories 3 and 4, date of
completion of construction should be indicated. In the case of projects under
construction, the likely date of completion or commissioning, as the case may
be, shall be indicated.

9.

For Categories 1 and 2, the equity shareholding of the Applicant, in the
company owning the Eligible Project, held continuously during the period for
which Eligible Experience is claimed, needs to be given (Refer Clause 3.2.3).

10.

Experience for any activity relating to an Eligible Project shall not be claimed
by two or more Members of the Consortium. In other words, no double

mrfq/ppa/19.09.2013

42

<!-- page 63 -->

For official use

Appendix I
Annex-IV
counting by a consortium in respect of the same experience shall be permitted
in any manner whatsoever.
11.

Certificate from the Applicant’s statutory auditor$ or its respective clients must
be furnished as per formats below for each Eligible Project. In jurisdictions
that do not have statutory auditors, the auditors who audit the annual accounts
of the Applicant/ Member/Associate may provide the requisite certification.

13.

If the Applicant is claiming experience under Categories 1 & 2£, it should
provide a certificate from its statutory auditor in the format below:

Certificate from the Statutory Auditor regarding BOT, BOLT, BOO, BOOT or
projects undertaken on similar basis
Based on its books of accounts and other published information authenticated by it,
this is to certify that …………………….. (name of the Applicant/Member/Associate)
is/ was an equity shareholder in ……………….. (title of the project company) and
holds/ held Rs. ……… cr. (Rupees ………………………….. crore) of equity (which
constitutes ……..%€ of the total paid up and subscribed equity capital) of the project
company from …………... (date) to …………….. (date)¥. The project was/is likely to
be commissioned on ……………. (date of commissioning of the project).
We further certify that the total estimated capital cost of the project is Rs. ……… cr.
(Rupees …………………crore), of which Rs. ……… cr. (Rupees …………… crore)
of capital expenditure was incurred during the past five financial years as per yearwise details noted below:
………………………
………………………
We also certify that the eligible annual revenues collected and appropriated by the
aforesaid project company in terms of Clauses 3.2.1 and 3.2.3 (d) of the RFQ during
the past five financial years were Rs. ……… cr. as per year-wise details noted below:
………………………
………………………
Name of the audit firm:
Seal of the audit firm: (Signature, name and designation of the authorised signatory)
Date:
$

In case duly certified audited annual financial statements containing the requisite details are provided,
a separate certification by statutory auditors would not be necessary.
£
Refer Clause 3.2.1 of the RFQ.
 Provide Certificate as per this format only. Attach Explanatory Notes to the Certificate, if necessary.
Statutory auditor means the entity that audits and certifies the annual accounts of the company.
€
Refer instruction no. 10 in this Annex-IV.
¥
In case the project is owned by the Applicant company, this language may be suitably modified to
read: “It is certified that …………….. (name of Applicant) constructed and/ or owned the …………..
(name of project) from ……………….. (date) to ………………… (date).”

mrfq/ppa/19.09.2013

43

<!-- page 64 -->

For official use

Appendix I
Annex-IV
14.

If the Applicant is claiming experience under Category 3 & 4, it should
provide a certificate from its statutory auditors or the client in the format
below:

Certificate from the Statutory Auditor/ Client regarding construction works
Based on its books of accounts and other published information authenticated by it,
{this
is
to
certify
that
……………………..
(name
of
the
Applicant/Member/Associate) was engaged by ……………….. (title of the project
company) to execute ……………… (name of project) for …………………. (nature
of project)}. The construction of the project commenced on ………….. (date) and
the project was/ is likely to be commissioned on …………… (date, if any). It is
certified that ……………. (name of the Applicant/ Member/ Associate) received/paid
Rs. ……….. cr. (Rupees …………………………… crore) by way of payment for the
aforesaid construction works.
We further certify that the total estimated capital cost of the project is Rs. …… cr.
(Rupees …………………crore), of which the Applicant/Member/Associate
received/paid Rs. ……… cr. (Rupees ……………………… crore), in terms of
Clauses 3.2.1 and 3.2.4 of the RFQ, during the past five financial years as per yearwise details noted below:
………………………
………………………
{It is further certified that the payments/ receipts indicated above are restricted to the
share of the Applicant who undertook these works as a partner or a member of joint
venture/ consortium.}
Name of the audit firm:
Seal of the audit firm: (Signature, name and designation of the authorised signatory).
Date:



Refer Clauses 3.2.1 and 3.2.4 of the RFQ.
 Provide Certificate as per this format only. Attach Explanatory Notes to the Certificate, if necessary.
Statutory auditor means the entity that audits and certifies the annual accounts of the company.

In case the Applicant owned the Eligible Project and engaged a contractor for undertaking the
construction works, this language may be modified to read: “ this is to certify that …………… (name
of Applicant/ Member/ Associate) held 26% or more of the paid up and subscribed share capital in
the……………. (name of Project company) when it undertook construction of the ……………….
(name of Project) through ………………… (name of the contractor).


This certification should only be provided in case of jobs/ contracts, which are executed as part of a
partnership/ joint venture/ consortium. The payments indicated in the certificate should be restricted to
the share of Applicant in such partnership/ joint venture/ consortium. This portion may be omitted if the
contract did not involve a partnership/ joint venture/ consortium. In case where work is not executed by
partnership/ joint venture/ consortium, this paragraph may be deleted.

mrfq/ppa/19.09.2013

44

<!-- page 65 -->

For official use

Appendix I
Annex-IV
15.

In the event that credit is being taken for the Eligible Experience of an
Associate, as defined in Clause 2.2.9, the Applicant should also provide a
certificate in the format below:

Certificate from Statutory Auditor/ Company Secretary regarding Associate$
Based on the authenticated record of the Company, this is to certify that more than
50% (fifty per cent) of the subscribed and paid up voting equity of ………………
(name of the Applicant/ Consortium Member/ Associate) is held, directly or
indirectly£, by ……………….. (name of Associate/ Applicant/ Consortium
Member). By virtue of the aforesaid share-holding, the latter exercises control over
the former, who is an Associate in terms of Clause 2.2.9 of the RFQ.
A brief description of the said equity held, directly or indirectly, is given below:
{Describe the share-holding of the Applicant/ Consortium Member and the
Associate. In the event the Associate is under common control with the Applicant/
Consortium Member, the relationship may be suitably described and similarly
certified herein }

Name of the audit firm:
Seal of the audit firm:
Date:

(Signature, name and designation of
the authorised signatory).

$

In the event that the Applicant/ Consortium Member exercises control over an Associate by operation
of law, this certificate may be suitably modified and copies of the relevant law may be enclosed and
referred to.
£

In the case of indirect share-holding, the intervening companies in the chain of ownership should also
be Associates i.e., the share-holding in each such company should be more than 50% in order to
establish that the chain of “control” is not broken.

16.



It may be noted that in the absence of any detail in the above certificates, the
information would be considered inadequate and could lead to exclusion of the
relevant project in computation of Experience Score.

Refer Clause 3.2.6 of the RFQ.

mrfq/ppa/19.09.2013

45

<!-- page 66 -->

For official use

ANNEX-V

Statement of Legal Capacity
(To be forwarded on the letterhead of the Applicant/ Lead Member of Consortium)

Ref. Date:

To,
***********
***********
Dear Sir,
We hereby confirm that we/ our members in the Consortium (constitution of which
has been described in the application) satisfy the terms and conditions laid out in the
RFQ document.
We have agreed that …………………… (insert member’s name) will act as the Lead
Member of our consortium.*
We have agreed that ………………….. (insert individual’s name) will act as our
representative/ will act as the representative of the consortium on its behalf* and has
been duly authorized to submit the RFQ. Further, the authorised signatory is vested
with requisite powers to furnish such letter and authenticate the same.
Thanking you,

Yours faithfully,
(Signature, name and designation of the authorised signatory)
For and on behalf of……………………………..
*Please strike out whichever is not applicable.

mrfq/ppa/19.09.2013

46

<!-- page 67 -->

For official use

APPENDIX II

Power of Attorney for signing of Application
(Refer Clause 2.2.5)
Know all men by these presents, We……………………………………………..
(name of the firm and address of the registered office) do hereby irrevocably
constitute, nominate, appoint and authorise Mr/ Ms (name), ……………………
son/daughter/wife of ……………………………… and presently residing at
…………………., who is presently employed with us/ the Lead Member of our
Consortium and holding the position of ……………………………. , as our true and
lawful attorney (hereinafter referred to as the “Attorney”) to do in our name and on
our behalf, all such acts, deeds and things as are necessary or required in connection
with or incidental to submission of our application for pre-qualification and
submission of our bid for the ***** Project proposed or being developed by the
***** (the “Utility”) including but not limited to signing and submission of all
applications, bids and other documents and writings, participate in Pre-Applications
and other conferences and providing information/ responses to the Utility,
representing us in all matters before the Utility, signing and execution of all contracts
including the Power Purchase Agreement and undertakings consequent to acceptance
of our bid, and generally dealing with the Utility in all matters in connection with or
relating to or arising out of our bid for the said Project and/ or upon award thereof to
us and/or till the entering into of the Power Purchase Agreement with the Utility.
AND we hereby agree to ratify and confirm and do hereby ratify and confirm all acts,
deeds and things done or caused to be done by our said Attorney pursuant to and in
exercise of the powers conferred by this Power of Attorney and that all acts, deeds
and things done by our said Attorney in exercise of the powers hereby conferred shall
and shall always be deemed to have been done by us.
IN WITNESS WHEREOF WE, …………………………., THE ABOVE NAMED
PRINCIPAL HAVE EXECUTED THIS POWER OF ATTORNEY ON THIS ………
DAY OF …………. 2…..
For
…………………………..
(Signature, name, designation and address)
Witnesses:
1.
(Notarised)
2.

mrfq/ppa/19.09.2013

47

<!-- page 68 -->

For official use

Appendix II
Page 2
Accepted
……………………………
(Signature)
(Name, Title and Address of the Attorney)

Notes:


The mode of execution of the Power of Attorney should be in accordance with the
procedure, if any, laid down by the applicable law and the charter documents of
the executant(s) and when it is so required, the same should be under common
seal affixed in accordance with the required procedure.



Wherever required, the Applicant should submit for verification the extract of the
charter documents and documents such as a board or shareholders’ resolution/
power of attorney in favour of the person executing this Power of Attorney for the
delegation of power hereunder on behalf of the Applicant.



For a Power of Attorney executed and issued overseas, the document will also
have to be legalised by the Indian Embassy and notarised in the jurisdiction where
the Power of Attorney is being issued. However, the Power of Attorney provided
by Applicants from countries that have signed the Hague Legislation Convention
1961 are not required to be legalised by the Indian Embassy if it carries a
conforming Appostille certificate.

mrfq/ppa/19.09.2013

48

<!-- page 69 -->

For official use

APPENDIX III

Power of Attorney for Lead Member of Consortium
(Refer Clause 2.2.5)
Whereas the ***** (“the Utility”) has invited applications from interested parties for
the ***** Project (the “Project”).
Whereas, …………………….., …………………….., …………………….. and
…………………….. (collectively the “Consortium”) being Members of the
Consortium are interested in bidding for the Project in accordance with the terms and
conditions of the Request for Qualification document (RFQ), Request for Proposal
(RFP) and other connected documents in respect of the Project, and
Whereas, it is necessary for the Members of the Consortium to designate one of them
as the Lead Member with all necessary power and authority to do for and on behalf of
the Consortium, all acts, deeds and things as may be necessary in connection with the
Consortium’s bid for the Project and its execution.
NOW THEREFORE KNOW ALL MEN BY THESE PRESENTS
We, …………………….. having our registered office at …………………….., M/s.
…………………….. having our registered office at …………………….., M/s.
…………………….. having our registered office at …………………….., and
…………………….. having our registered office at ……………………..,
(hereinafter collectively referred to as the “Principals”) do hereby irrevocably
designate, nominate, constitute, appoint and authorise M/S ……………………..
having its registered office at …………………….., being one of the Members of the
Consortium, as the Lead Member and true and lawful attorney of the Consortium
(hereinafter referred to as the “Attorney”). We hereby irrevocably authorise the
Attorney (with power to sub-delegate) to conduct all business for and on behalf of the
Consortium and any one of us during the bidding process and, in the event the
Consortium is awarded the concession/contract, during the execution of the Project
and in this regard, to do on our behalf and on behalf of the Consortium, all or any of
such acts, deeds or things as are necessary or required or incidental to the prequalification of the Consortium and submission of its bid for the Project, including but
not limited to signing and submission of all applications, bids and other documents
and writings, participate in bidders and other conferences, respond to queries, submit
information/ documents, sign and execute contracts and undertakings consequent to
acceptance of the bid of the Consortium and generally to represent the Consortium in
all its dealings with the Utility, and/ or any other Government Agency or any person,
in all matters in connection with or relating to or arising out of the Consortium’s bid
for the Project and/ or upon award thereof till the Power Purchase Agreement is
entered into with the Utility.
AND hereby agree to ratify and confirm and do hereby ratify and confirm all acts,
deeds and things done or caused to be done by our said Attorney pursuant to and in
exercise of the powers conferred by this Power of Attorney and that all acts,

mrfq/ppa/19.09.2013

49

<!-- page 70 -->

For official use

Appendix III
Page 2
deeds and things done by our said Attorney in exercise of the powers hereby
conferred shall and shall always be deemed to have been done by us/ Consortium.
IN WITNESS WHEREOF WE THE PRINCIPALS ABOVE NAMED HAVE
EXECUTED THIS POWER OF ATTORNEY ON THIS …………………. DAY OF
………. 2..…
For ……………………..
(Signature)
……………………..
(Name & Title)
For ……………………..
(Signature)
……………………..
(Name & Title)
For ……………………..
(Signature)
……………………..
(Name & Title)

mrfq/ppa/19.09.2013

50

<!-- page 71 -->

For official use

Appendix III
Page 3
Witnesses:
1.
2.
………………………………………
(Executants)
(To be executed by all the Members of the Consortium)
Notes:


The mode of execution of the Power of Attorney should be in accordance with the
procedure, if any, laid down by the applicable law and the charter documents of
the executant(s) and when it is so required, the same should be under common
seal affixed in accordance with the required procedure.



Also, wherever required, the Applicant should submit for verification the extract
of the charter documents and documents such as a board or shareholders’
resolution/ power of attorney in favour of the person executing this Power of
Attorney for the delegation of power hereunder on behalf of the Applicant.



For a Power of Attorney executed and issued overseas, the document will also
have to be legalised by the Indian Embassy and notarised in the jurisdiction where
the Power of Attorney is being issued. However, the Power of Attorney provided
by Applicants from countries that have signed the Hague Legislation Convention
1961 are not required to be legalised by the Indian Embassy if it carries a
conforming Appostille certificate.

mrfq/ppa/19.09.2013

51

<!-- page 72 -->

For official use

APPENDIX IV

Joint Bidding Agreement
(Refer Clause 2.13.2)
(To be executed on Stamp paper of appropriate value)
THIS JOINT BIDDING AGREEMENT is entered into on this the ………… day of
………… 20…
AMONGST
1.

{………… Limited, a company incorporated under the Companies Act,
1956} and having its registered office at ………… (hereinafter referred to as
the “First Part” which expression shall, unless repugnant to the context
include its successors and permitted assigns)

AND
2.

{………… Limited, a company incorporated under the Companies Act, 1956}
and having its registered office at ………… (hereinafter referred to as the
“Second Part” which expression shall, unless repugnant to the context include
its successors and permitted assigns)

AND
3.

{………… Limited, a company incorporated under the Companies Act, 1956
and having its registered office at ………… (hereinafter referred to as the
“Third Part” which expression shall, unless repugnant to the context include
its successors and permitted assigns)}

AND
4.

{………… Limited, a company incorporated under the Companies Act, 1956
and having its registered office at ………… (hereinafter referred to as the
“Fourth Part” which expression shall, unless repugnant to the context include
its successors and permitted assigns)}$
The above mentioned parties of the FIRST, SECOND, {THIRD and
FOURTH} PART are collectively referred to as the “Parties” and each is
individually referred to as a “Party”

WHEREAS,



A Bidder who is registered abroad may substitute the words, viz. “a company registered under the
Companies Act, 1956” by the words, viz. “a company duly organized and validly existing under the
laws of the jurisdiction of its incorporation”.
$
The number of Parties will be shown here, as applicable, subject however to a maximum of 6 (six).

mrfq/ppa/19.09.2013

52

<!-- page 73 -->

For official use

Appendix IV
Page 2
(A)

*****, established/incorporated under the Indian Companies Act, 1956,
represented by its [Chairman] and having its principal offices at *****
(hereinafter referred to as the “Utility” which expression shall, unless
repugnant to the context or meaning thereof, include its administrators,
successors and assigns) has invited applications (the Applications”) by its
Request for Qualification No. ………… dated ………… (the “RFQ”) for prequalification and short-listing of bidders for development and operation of
***** Project (the “Project”) through public private partnership.

(B)

The Parties are interested in jointly bidding for the Project as members of a
Consortium and in accordance with the terms and conditions of the RFQ
document and other bid documents in respect of the Project, and

(C)

It is a necessary condition under the RFQ document that the members of the
Consortium shall enter into a Joint Bidding Agreement and furnish a copy
thereof with the Application.

NOW IT IS HEREBY AGREED as follows:
1.

Definitions and Interpretations
In this Agreement, the capitalised terms shall, unless the context otherwise
requires, have the meaning ascribed thereto under the RFQ.

2.

Consortium

2.1

The Parties do hereby irrevocably constitute a consortium (the “Consortium”)
for the purposes of jointly participating in the Bidding Process for the Project.

2.2

The Parties hereby undertake to participate in the Bidding Process only
through this Consortium and not individually and/ or through any other
consortium constituted for this Project, either directly or indirectly or through
any of their Associates.

3.

Covenants
The Parties hereby undertake that in the event the Consortium is declared the
selected Bidder and awarded the Project, it shall incorporate a special purpose
vehicle (the “SPV”) under the Indian Companies Act, 1956 for entering into a
Power Purchase Agreement (the “PPA”) with the Utility and for performing
all its obligations as the Concessionaire in terms of the PPA. If an SPV has
been incorporated by the Utility prior to the Bid Due Date, the Parties
undertake to transfer all shares of the SPV through a share purchase
agreement.

mrfq/ppa/19.09.2013

53

<!-- page 74 -->

For official use

Appendix IV
Page 3
4.

Role of the Parties
The Parties hereby undertake to perform the roles and responsibilities as
described below:

5.

(a)

Party of the First Part shall be the Lead member of the Consortium and
shall have the power of attorney from all Parties for conducting all
business for and on behalf of the Consortium during the Bidding
Process and until the Appointed Date under the PPA when all the
obligations of the SPV shall become effective;

(b)

Party of the Second Part shall be {the Technical Member of the
Consortium;}

{(c)

Party of the Third Part shall be the Financial Member of the
Consortium; and}

{(d)

Party of the Fourth Part shall be the Operation and Maintenance
Member/ Other Member of the Consortium.}

Joint and Several Liability
The Parties do hereby undertake to be jointly and severally responsible for all
obligations and liabilities relating to the Project and in accordance with the
terms of the RFQ, RFP and the PPA, till such time as the Financial Close for
the Project is achieved under and in accordance with the PPA.

6.

Shareholding in the SPV

6.1

The Parties agree that the proportion of shareholding among the Parties in the
SPV shall be as follows:
First Party:
Second Party:
{Third Party:}
{Fourth Party:}

6.2

The Parties undertake that a minimum of 26% (twenty six per cent) of the
subscribed and paid up equity share capital of the SPV shall, at all times till
the second anniversary of the date of commercial operation of the Project, be
held by the Parties of the First, {Second and Third} Part whose experience and
net worth have been reckoned for the purposes of qualification and shortlisting of Applicants for the Project in terms of the RFQ.

mrfq/ppa/19.09.2013

54

<!-- page 75 -->

For official use

Appendix IV
Page 4
6.3

The Parties undertake that each of the Parties specified in Clause 6.2 above
shall, at all times between the commercial operation date of the Project and the
second anniversary thereof, hold subscribed and paid up equity share capital of
SPV equivalent to at least 5% (five per cent) of the Total Project Cost.

6.4

The Parties undertake that they shall collectively hold at least 51% (fifty one
per cent) of the subscribed and paid up equity share capital of the SPV at all
times until the second anniversary of the commercial operation date of the
Project.

6.5

The Parties undertake that they shall comply with all equity lock-in
requirements set forth in the PPA.

[6.6

The Parties undertake that the O&M Member shall subscribe and hold at least
10% (ten per cent) of the subscribed and paid up equity shares in the SPV25in
terms of the Power Purchase Agreement.]

7.

Representation of the Parties
Each Party represents to the other Parties as of the date of this Agreement that:

25

(a)

Such Party is duly organised, validly existing and in good standing
under the laws of its incorporation and has all requisite power and
authority to enter into this Agreement;

(b)

The execution, delivery and performance by such Party of this
Agreement has been authorised by all necessary and appropriate
corporate or governmental action and a copy of the extract of the
charter documents and board resolution/ power of attorney in favour of
the person executing this Agreement for the delegation of power and
authority to execute this Agreement on behalf of the Consortium
Member is annexed to this Agreement, and will not, to the best of its
knowledge:
(i)

require any consent or approval not already obtained;

(ii)

violate any Applicable Law presently in effect and having
applicability to it;

(iii)

violate the memorandum and articles of association, by-laws or
other applicable organisational documents thereof;

Add further conditions relating to the O&M Member, if any.

mrfq/ppa/19.09.2013

55

<!-- page 76 -->

For official use

Appendix IV
Page 5

8.

(iv)

violate any clearance, permit, concession, grant, license or
other governmental authorisation, approval, judgement, order
or decree or any mortgage agreement, indenture or any other
instrument to which such Party is a party or by which such
Party or any of its properties or assets are bound or that is
otherwise applicable to such Party; or

(v)

create or impose any liens, mortgages, pledges, claims, security
interests, charges or Encumbrances or obligations to create a
lien, charge, pledge, security interest, encumbrances or
mortgage in or on the property of such Party, except for
encumbrances that would not, individually or in the aggregate,
have a material adverse effect on the financial condition or
prospects or business of such Party so as to prevent such Party
from fulfilling its obligations under this Agreement;

(c)

this Agreement is the legal and binding obligation of such Party,
enforceable in accordance with its terms against it; and

(d)

there is no litigation pending or, to the best of such Party's knowledge,
threatened to which it or any of its Affiliates is a party that presently
affects or which would have a material adverse effect on the financial
condition or prospects or business of such Party in the fulfillment of its
obligations under this Agreement.

Termination
This Agreement shall be effective from the date hereof and shall continue in
full force and effect until the Financial Close of the Project is achieved under
and in accordance with the PPA, in case the Project is awarded to the
Consortium. However, in case the Consortium is either not pre-qualified for
the Project or does not get selected for award of the Project, the Agreement
will stand terminated in case the Applicant is not pre-qualified or upon return
of the Bid Security by the Utility to the Bidder, as the case may be.

9.

Miscellaneous

9.1

This Joint Bidding Agreement shall be governed by laws of {India}.

9.2

The Parties acknowledge and accept that this Agreement shall not be amended
by the Parties without the prior written consent of the Utility.

mrfq/ppa/19.09.2013

56

<!-- page 77 -->

For official use

Appendix IV
Page 6
IN WITNESS WHEREOF THE PARTIES ABOVE NAMED HAVE EXECUTED
AND DELIVERED THIS AGREEMENT AS OF THE DATE FIRST ABOVE
WRITTEN.
SIGNED, SEALED AND DELIVERED

SIGNED, SEALED AND DELIVERED

For and on behalf of
LEAD MEMBER by:

SECOND PART
(Signature)
(Name)
(Designation)
(Address)

(Signature)
(Name)
(Designation)
(Address)

SIGNED, SEALED AND DELIVERED

SIGNED, SEALED AND DELIVERED

For and on behalf of
THIRD PART

For and on behalf of
FOURTH PART
(Signature)
(Name)
(Designation)
(Address)

In the presence of:
1.

mrfq/ppa/19.09.2013

(Signature)
(Name)
(Designation)
(Address)

2.

57

<!-- page 78 -->

For official use

Appendix IV
Page 7

Notes:
1.

The mode of the execution of the Joint Bidding Agreement should be in
accordance with the procedure, if any, laid down by the Applicable Law
and the charter documents of the executant(s) and when it is so required,
the same should be under common seal affixed in accordance with the
required procedure.

2.

Each Joint Bidding Agreement should attach a copy of the extract of the
charter documents and documents such as resolution / power of attorney
in favour of the person executing this Agreement for the delegation of
power and authority to execute this Agreement on behalf of the
Consortium Member.

3.

For a Joint Bidding Agreement executed and issued overseas, the
document shall be legalised by the Indian Embassy and notarized in the
jurisdiction where the Power of Attorney has been executed.

mrfq/ppa/19.09.2013

58

<!-- page 79 -->

For official use

APPENDIX V26

Guidelines of the Department of Disinvestment
(Refer Clause1.2.1)
No. 6/4/2001-DD-II
Government of India
Department of Disinvestment
Block 14, CGO Complex
New Delhi.
th
Dated 13 July, 2001.
OFFICE MEMORANDUM
Sub: Guidelines for qualification of Bidders seeking to acquire stakes in Public Sector
Enterprises through the process of disinvestment
Government has examined the issue of framing comprehensive and transparent
guidelines defining the criteria for bidders interested in PSE-disinvestment so that the
parties selected through competitive bidding could inspire public confidence. Earlier,
criteria like net worth, experience etc. used to be prescribed. Based on experience and
in consultation with concerned departments, Government has decided to prescribe the
following additional criteria for the qualification/ disqualification of the parties
seeking to acquire stakes in public sector enterprises through disinvestment:

26

(a)

In regard to matters other than the security and integrity of the country,
any conviction by a Court of Law or indictment/ adverse order by a
regulatory authority that casts a doubt on the ability of the bidder to
manage the public sector unit when it is disinvested, or which relates to a
grave offence would constitute disqualification. Grave offence is defined
to be of such a nature that it outrages the moral sense of the community.
The decision in regard to the nature of the offence would be taken on case
to case basis after considering the facts of the case and relevant legal
principles, by the Government of India.

(b)

In regard to matters relating to the security and integrity of the country,
any charge-sheet by an agency of the Government/ conviction by a Court
of Law for an offence committed by the bidding party or by any sister
concern of the bidding party would result in disqualification. The decision
in regard to the relationship between the sister concerns would be taken,
based on the relevant facts and after examining whether the two concerns
are substantially controlled by the same person/ persons.

(c)

In both (a) and (b), disqualification shall continue for a period that
Government deems appropriate.

These guidelines may be modified or substituted by the Government from time to time.

mrfq/ppa/19.09.2013

59

<!-- page 80 -->

For official use

Appendix V
Page-2
(d)

Any entity, which is disqualified from participating in the disinvestment
process, would not be allowed to remain associated with it or get
associated merely because it has preferred an appeal against the order
based on which it has been disqualified. The mere pendency of appeal will
have no effect on the disqualification.

(e)

The disqualification criteria would come into effect immediately and
would apply to all bidders for various disinvestment transactions, which
have not been completed as yet.

(f)

Before disqualifying a concern, a Show Cause Notice why it should not be
disqualified would be issued to it and it would be given an opportunity to
explain its position.

(g)

Henceforth, these criteria will be prescribed in the advertisements seeking
Expression of Interest (EOI) from the interested parties. The interested
parties would be required to provide the information on the above criteria,
along with their Expressions of Interest (EOI). The bidders shall be
required to provide with their EOI an undertaking to the effect that no
investigation by a regulatory authority is pending against them. In case any
investigation is pending against the concern or its sister concern or against
its CEO or any of its Directors/ Managers/ employees, full details of such
investigation including the name of the investigating agency, the charge/
offence for which the investigation has been launched, name and
designation of persons against whom the investigation has been launched
and other relevant information should be disclosed, to the satisfaction of
the Government. For other criteria also, a similar undertaking shall be
obtained along with EOI.
sd/(A.K. Tewari)
Under Secretary to the Government of India

mrfq/ppa/19.09.2013

60
