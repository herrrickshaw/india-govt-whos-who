---
doc_id: "b8aeeac32df510ff"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/07/4c8468211dee941cc7ab88e33412de07.pdf"
ministry: "Tourism"
title: "Corrigendum -II, Amendment and reply to Pre-Bid Queries w.r.t RFP for Selection of High-Level Strategy Consultant for Developing Comprehensive Strategies for 3 Trillion USD Indian Tourism Economy by 2047."
date: "2024-03-13"
pages: 33
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "94bcb8ecd74a5c48"
---

<!-- page 1 -->

<!-- page 2 -->

Corrigendum II
Amendments in respect of Vol 1 and Vol 2 of the RFP SD-8/41/2023-SD dated 20.02.2024 regarding
‘Selection of High Level Strategy Consultant for Developing Comprehensive Strategies for 3 Trillion USD
Indian Tourism Economy by 2047’ is as under:
Vol. I
1.

Ref. Appendix 1 Form 9
The document for proposed Approach and Methodology including Work Plan should not be
of more than 25 pages.

2.

Clause 3.1 pertaining to ‘Eligible Assignments’ shall read as under:For the purpose of evaluation, the experience of undertaking assignment of developing
comprehensive strategy at the international, national or state level in the field of tourism sector
for a Government authority covering any of the following areas, shall be deemed as eligible
assignments (the “Eligible Assignments”):
(i).

Consultancy for preparing Strategy / Roadmap for tourism development at national /
state level

(ii).

Consultancy for investment promotion in tourism sector (national / state level)

(iii).

Consultancy for tourism sub-sectors such as Rural Tourism, Adventure Tourism, Eco, MICE
etc. for national / State level

Provided further that

3.

(i).

The assignment must have commenced in the last 10 (Ten) years preceding the Proposal
Due Date (PDD)

(ii).

The fee received for the assignment must be Rs. 50 Lakh or more. In case of ongoing
assignments, Rs. 50 Lakh should have been received as project fees by PDD and

(iii).

The duration of the assignment must be six month or more

Clause 2.3.2 row 2 regarding ‘Technical Capacity’ may be read as under:2.

Technical Capacity

The Applicant shall have, undertaken a
minimum of 1 (one) eligible assignments
defined in Clause 3.1 – Criteria for
Evaluation

The details of assignment submitted for
meeting the Technical Capacity to be
provided as per Appendix 1, Form 5 and 6.

Page 1 of 6

<!-- page 3 -->

4.

Clause 3.2.2 pertaining to Applicant’s relevant experience and case studies would read as
under
Applicant’s relevant experience and case studies will be evaluated as follows:
Sno

Sub-Criteria

Marks to be given

1

Relevant Experience
in developing
strategies for the
Government in
tourism sector

2.

Two Case studies
demonstrating
development of
strategies for
tourism sector at
national/ state level
in India or
internationally

Maximum of two eligible
assignments will be evaluated
covering the following, in each
category:
1. Consultancy for preparing
Strategy/ roadmap for tourism
development at national /state
level (max 2.5 marks per
project)
2. Consultancy for investment
promotion in tourism sector
(national / state level) (max 2.5
marks per project)
3. Consultancy for tourism subsectors such as Rural Tourism,
Adventure Tourism, Eco, MICE
etc. for national / State level
etc. (max 2.5 marks per project)
Same projects should not be
submitted under different
categories
The Applicant shall present case
studies showcasing their work in
previous assignments:
● The case studies will be assessed
for its relevance to the scope of
work outlined in the RFP and will
be evaluated on:
o Approach adopted for
designing the strategy and
action plan
o Implementation Support, if
extended
o Impact of the program

Max
Marks
15

15

Page 2 of 6

<!-- page 4 -->

Sno

Sub-Criteria

Max
Marks

Marks to be given

Sub-total (a)

5.

Clause 3.2.4 titled as ‘Competence of Experts for the Assignment’ shall read as follows:Sno.
1

Sub-Criteria

Team Leader cum
Governance
Expert
2
Economic Expert
3
Tourism Expert/
Destination
Marketing Expert
4
PPP/Investment
promotion Expert
5
Sustainability
Expert
6
Digital Expert
7
Quality Assurance
and Regulatory
Expert
8
Project Manager
(full time on site)
Sub-total I

6.

30

Marking Criteria

Max Marks

●

8

●

Relevance of profile,
experience, and fitment to
role: 50% marks
Participation and contribution
to the technical presentation:
50% marks

4
4

4
4
4
4

3
35

Reference Schedule I ‘Terms of Reference’ – Para 6.2 pertaining to Subject Matter Experts
would read as under:The minimum qualification and experience of the SMEs are briefly described herein below. The
Consultant shall provide the CVs of the SMEs in their Technical Proposal which would be
considered for the purpose of evaluation. The CVs of the proposed SMEs must be submitted
along with a signed declaration by the proposed expert confirming availability for the
Assignment. The CVs submitted without such declaration shall not be considered for technical
evaluation.
Sno
1.

Subject Matter Experts
Project Leader cum Governance
Expert

Qualifications and Experience
• Should be a post-graduate from a reputed
institution within/ outside India
• Should have minimum 15 years of
professional experience

Page 3 of 6

<!-- page 5 -->

Sno

Subject Matter Experts

2.

Economic Expert

3.

Tourism Expert/ Destination
Marketing Expert

4.

PPP/Investment promotion Expert

5.

Sustainability Expert

6.

Digital Expert

Qualifications and Experience
• Should have undertaken at least 3 projects
with Central/ State Government
departments/ agencies in India
• Should have experience of managing long
term programs/ projects (project duration of
6 months or more) in leadership capacity
with accountability and responsibility for
performance including quality, budget,
schedule, client, and stakeholder
management
• Should be a post-graduate from a reputed
institution from within/ outside India
• Should have minimum 10 years of
professional experience
• Should have undertaken at least 3 projects in
economic strategy, forecasts and
consultancy for Central/ State Government
departments/ agencies.
• Should be a post-graduate from a reputed
institution from within/outside India.
• Should have minimum 10 years of
professional experience
• Should have undertaken at least 2 projects in
the tourism sector
• Should be a post-graduate from a reputed
institution from within/ outside India
• Should have minimum 10 years of
professional experience
• Should have undertaken at least 3 projects
involving financing or PPP advisory or
Investment Promotion with Central/ State
Government departments/ agencies
• Should be a post-graduate from a reputed
institution from within/ outside India
• Should have minimum 10 years of
professional experience
• Should have an experience in developing
sustainability strategies for Central/ State
Government departments/ agencies
• Should be a post-graduate from a reputed
institution from within/ outside India
• Should have minimum 10 years of
professional experience

Page 4 of 6

<!-- page 6 -->

7.

Sno

Subject Matter Experts

7.

Quality Assurance and Regulatory
Expert

Qualifications and Experience
• Should have undertaken at least 2 projects
involving development of digital/ technology
enabled strategies for Central/ State
Government departments/ agencies
• Should be a post-graduate from a reputed
institution from within/ outside India
• Should have minimum 10 years of
professional experience.
• Should have undertaken at least 2 projects
involving Quality Accreditation
and
Regulation for Central/ State Government
departments/ agencies

Reference Appendix I, Form 6 for Eligible Assignments of Applicants may read as under:
(Refer Chapter 3 – CRITERIA for Evaluation of RFP)
1
2
3
4
5

Name of the Applicant
Name of the Project/ Assignment
Name of the Location
Name of the Client and Address
Name and telephone number of client’s
representatives
6
Approximate value of the Contract (in Rs.
Crore)
7
Duration of the Assignment
8
Start Date of the services (month/ year)
9
End Date of the services (month/ year)
10
Description of the project
11
Description of the services performed by
the Applicant and how they are relevant
to present Scope as defined in the TOR.
Map the activities performed on various
modules as defined in the scope of work
in TOR for clarity
It is certified that the aforesaid information is true and correct to the best of my
knowledge and belief
(Signature, name and designation of the authorized signatory)
Notes: Use separate sheet for each eligible assignment.
Additional rows may be added as required
Page 5 of 6

<!-- page 7 -->

Vol. 2 (Agreement)
8.

Clause 3.4.4 under the title ‘Liability of the Consultant’ shall read as under:This limitation of liability specified in Clause 3.4.3 shall not affect the Consultant’s liability, if any,
for damage to Third Parties caused by the Consultant or any person or firm acting on behalf of
the Consultant in carrying out the Services subject, however, to a limit equal to 1 (one) time the
Agreement Value.

9.

Clause 4.4.2 under the title ‘Substitution of Key Personnel’ shall read as under:The Authority will not consider substitution of Key Personnel except for reasons of any
incapacity, death, health grounds, resignation by personnel etc. Such substitution shall except
for the reasons cited above and initiated by the applicants would be limited to one Key Personnel
subject to equally or better qualified and experienced personnel being provided to the
satisfaction of the Authority. As a condition, a sum equal to Rs. 2 Lakh shall be deducted from
the payments on first substitution. In the case of a second substitution and thereafter, a sum
equal to Rs. 5 Lakh shall be deducted for each substitution from the due payments. Repeated
substitution may lead to termination of the Agreement.

10.

In respect of clause 7.3.2 of Vol 2 (Agreement), it is clarified that penalty on account of delay
shall be imposed on the amount due for the milestone under consideration.

11.

Reference Annexure -4, Payment Schedule para 1 will be read as -The consultant will raise its invoice in respect of each milestone on its completion along with
the details of work done in respect of the said milestone.

12.

The Ministry of Tourism has decided to extend the Proposal Due Date (PDD) till 27.03.2024
(17.00 Hrs.). All the prospective applicants are advised to keep on checking the CPP portal
and the official website of the Ministry of Tourism (www.tourism.gov.in) for any other
communication/ update etc.
*****

Page 6 of 6

<!-- page 8 -->

Ministry of Tourism’s RFP no. SD-8/41/2023-SD dated 20.02.2024 regarding ‘Selection of High Level Strategy Consultant for
Developing Comprehensive Strategies for 3 Trillion USD Indian Tourism Economy by 2047’
Pre-Bid Queries and clarification to the Pre-Bid Queries

S.N
o.

Relevant
Clause of

1

Appendix 1 Form 9

2

Appendix 1 Form 9

4

5

6
7

Clause 2.6

Query
What are the restrictions on number of slides
if approach document is submitted in PPT
format?
In addition to the main slides (which would be
restricted as per form 9), can we add appendix
slides to provide further details?
Do we need to submit the power of attorney
if proposal is signed by the partner of LLP?

Clarification of MOT
Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024.

No change in RFP
Please refer to the instructions given in the
RFP. The date of technical presentations will
be communicated separately.
Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024.

Please clarify the tentative date and format
Clause 3.2.4
for technical presentation
We kindly request to extend the deadline for
1.8.1
Bid Submission by a period of two weeks from
Schedule of Selection response to queries. Request to kindly
Process
consider.
3.1
Provided further that :Please refer to the corrigendum(s) issued in
Provided further that
respect of RFP no. SD-8/41/2023-SD dated
(i) The assignment must have commenced in 20.02.2024.
(i) The assignment must the last 10 (ten) years preceding the Proposal
have commenced in the Due Date (PDD)
last 7 (five) years preceding
Page 1 of 26

<!-- page 9 -->

the Proposal Due Date (ii) The fee received for the assignment must
(PDD)
be Rs. 1 Crores or more and
(ii) The fee received for the (iii) The duration of the assignment must be
assignment must be Rs. 1 six month or more
Crores or more and
(iii) The duration of the
assignment must be six
month or more
8

3.2.2
(1)
Relevant
Experience in developing
strategies
for
the
Government in tourism
sector

Relevant Experience in developing strategies Please refer to the corrigendum(s) issued in
for the Government in tourism sector
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024.
(2) The same project will further be marked
based on project fee:

(2) 2. The same project will Project fee received from Consultancy >=5
further be marked based Crore =2.5 mark
on project fee:
3 Crore >= Project fee = <5 Crore = 1.5
Project fee received from
Consultancy >=5 Crore =2.5 1 Crore >=Project fee<3 Crore=1
mark
3 Crore >= Project fee <5
Crore = 1.5
1 Crore >=Project fee<3
Crore=1

Page 2 of 26

<!-- page 10 -->

9.

10.

3.4.4
This limitation of liability
specified in Clause 3.4.3
shall not affect the
Consultant’s liability, if any,
for damage to Third Parties
caused by the Consultant or
any person or firm acting
on behalf of the Consultant
in carrying out the Services
subject, however, to a limit
equal to 3 (three) times the
Agreement Value.
4.4.2
of
the
Draft
Agreement
The Authority will not
consider substitution of Key
Personnel
except
for
reasons of any incapacity,
death, health grounds,
resignation by personnel
etc. Such substitution shall
except for the reasons cited
above and initiated by the
bidder would be limited to
one Key Personnel subject
to equally or better
qualified and experienced
personnel being provided
to the satisfaction of the
Authority. As a condition to

Modify the clause as below:

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
This limitation of liability specified in Clause 20.02.2024.
3.4.3 shall not affect the Consultant’s liability,
if any, for damage to Third Parties caused by
the Consultant or any person or firm acting on
behalf of the Consultant in carrying out the
Services subject, however, to a limit equal to
1 (one) time the Agreement Value.

We request you to kindly replace the specified Please refer to the corrigendum(s) issued in
clause with below: The Authority will not respect of RFP no. SD-8/41/2023-SD dated
consider substitution of Key Personnel except 20.02.2024.
for reasons of any incapacity, death, health
grounds, resignation by personnel etc. Such
substitution shall except for the reasons cited
above and initiated by the bidder would be
limited to one Key Personnel subject to
equally or better qualified and experienced
personnel being provided to the satisfaction
of the Authority. As a condition to such
substitution, a sum equal to 5% (five per cent)
of the remuneration specified for the original
Key Personnel shall be deducted from the
payments due to the Consultant for one time.
In the case of a second substitution
hereunder, such deduction shall be 10% (ten
per cent) of the remuneration specified for
Page 3 of 26

<!-- page 11 -->

11.

such substitution, a sum
equal to 20% (twenty per
cent) of the remuneration
specified for the original
Key Personnel shall be
deducted
from
the
payments due to the
Consultant for one time. In
the case of a second
substitution
hereunder,
such deduction shall be
50% (fifty per cent) of the
remuneration specified for
the original Key Personnel
for one time. Repeated
substitution may lead to
termination
of
the
Agreement.
4.4.2
of
the
Draft
Agreement

the original Key Personnel for one time.
Repeated substitution may lead to
termination of the Agreement.

We understand that substitution except for Please refer to the corrigendum(s) issued in
reasons of any incapacity, death, health respect of RFP no. SD-8/41/2023-SD dated
grounds, resignation by personnel etc. shall 20.02.2024.
The Authority will not attract deductions.
consider substitution of Key
Personnel
except
for We understand that the % specified in the
reasons of any incapacity, clause refer to the monthly fee for the
death, health grounds, personnel. Kindly confirm.
resignation by personnel
etc. Such substitution shall As the remuneration for Key Personnel is not
except for the reasons cited specified in the bid or the agreement, kindly
above and initiated by the clarify the modality of verification of the Key
bidder would be limited to Personnel remuneration. Kindly confirm.
Page 4 of 26

<!-- page 12 -->

12.

one Key Personnel subject
to equally or better
qualified and experienced
personnel being provided
to the satisfaction of the
Authority. As a condition to
such substitution, a sum
equal to 20% (twenty per
cent) of the remuneration
specified for the original
Key Personnel shall be
deducted
from
the
payments due to the
Consultant for one time. In
the case of a second
substitution
hereunder,
such deduction shall be
50% (fifty per cent) of the
remuneration specified for
the original Key Personnel
for one time. Repeated
substitution may lead to
termination
of
the
Agreement.
6.2 of the Draft Agreement We understand that the Pay Level 12 is No change in the RFP
considered as per the Pay Matrix as provided
Any
Air-travel
& in Annexure to Ministry of Finance,
accommodation for the Department of Expenditure, O.M. No.
consultant’s personnel for 19030/1/2017-E.IV dated 10th July 2017.
site visit etc. will be with
the approval of the
Page 5 of 26

<!-- page 13 -->

13.

14.

15.

Authority. The Air Travel/
daily allowance/ food
charges and any other
expenses would be as per
the entitlement of an
Under Secretary level
officer of the Government
of India.
7 of the Draft Agreement
We request to kindly consider a cap of 10% of
Liquidated Damages and the agreement value for the Liquidated
Penalties
Damages and Penalties under the
engagement. Kindly consider
7.3.2
of
the
Draft We understand that the penalty is charged as
Agreement
% of the amount due for the milestone under
consideration and not the agreement value.
(b). Impose penalty to the Kindly consider
extent of 5% for delay upto
1 month per milestone 10%
for delay upto 2 months per
milestone 20% for delay
upto 3 months per
milestone
Annex-4 Payment Schedule As per the payment schedule, the payments
of the Draft Agreement
are milestone or deliverable based, and not
The Consultant will be raise monthly payment. We kindly request to clarify
its invoice on monthly basis whether the consultant shall raise a monthly
along with the details of the invoice of upon submission of deliverables.
work done during that
period.

No change in the RFP

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

Page 6 of 26

<!-- page 14 -->

16.

17.

18.

Section 3 Criteria for
Evaluation
3.1. Eligible Assignments
(i) The assignment must
have commenced in the
last 7 (five) years preceding
the Proposal Due Date
(PDD)
3
CRITERIA
FOR
EVALUATION
3.1. Eligible Assignments
(ii) The fee received for the
assignment must be Rs. 1
Crores or more and
3
CRITERIA
FOR
EVALUATION
3.1. Eligible Assignments
(iii) The duration of the
assignment must be six
month or more
3.2.2. Applicant’s relevant
experience and cases
studies
Relevant Experience in
developing strategies for
the Government in tourism
sector

Bidder requests confirmation on the clause"(i) Please refer to the corrigendum(s) issued in
The assignment must have commenced in the respect of RFP no. SD-8/41/2023-SD dated
last 7 (Seven) years preceding the Proposal 20.02.2024
Due Date (PDD)"

Bidders request to change the clause to Please refer to the corrigendum(s) issued in
"(ii) The fee received for the assignment must respect of RFP no. SD-8/41/2023-SD dated
be Rs. 50 Lakh or more and"
20.02.202

Bidders request to change the clause to No change in the RFP
(iii) The duration of the assignment must be
Five months or more

Request to change the clause as follows: Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
2. The same project will further be marked 20.02.2024
based
on
project
fee:
- Project fee received from Consultancy
>=3
Crore
=2.5
marks
- 1 Crore >= Project fee <3 Crore =1.5 marks
- 0.5 Crore>=Project fee<1 Crore = 1 mark

2. The same project will
further be marked based
on
project
fee:
Page 7 of 26

<!-- page 15 -->

19

20

- Project fee received from
Consultancy
>=5 Crore =2.5 marks
- 3 Crore >= Project fee <5
Crore
=1.5
marks
- 1 Crore>=Project fee<3
Crore = 1 mark
4. Detailed Scope of Work
4.1. Module 1: Current
State
Assessment
&
Benchmarking
(iii). Key Tourism States of
India
Tourism is substantially
developed by the State
Governments.
An
assessment of current
policies and initiatives of
Key Tourism States of India
needs ot be carried out"

6.2. Subject Matter Experts
Sustainability
Expert
• Should be a postgraduate from a reputed
institution from within/
outside
India
• Should have minimum 10
years
of
professional

Bidder requests the following information:
1. Please share the list of the Key Tourism
States
of
India.
2. How many of the Key Tourism States have
to be considered for this assessment?

Request to change the clause as follows:
"Sustainability
Expert:
• Should be a post-graduate from a reputed
institution from within/ outside India
• Should have minimum 8 years of
professional
experience
• Should have an experience in developing

"Key tourism states" typically refers to states
that play a significant role in attracting tourists
due to their natural beauty, cultural heritage,
historical
significance,
technological
advancement, spiritual value etc. These states
often boast popular tourist destinations,
pristine beaches, vibrant villages, and
renowned cultural sites etc., which draw
visitors from around the world. These key
tourism states contribute significantly to the
overall tourism industry of a country, play a
vital role in promoting economic growth, job
creation, and cultural exchange through
tourism activities and some of them have
developed their policies and frameworks for
development of tourism.
Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

Page 8 of 26

<!-- page 16 -->

21

22

experience
•
Should
have
an
experience in developing
sustainability strategies for
Central/ State Government
departments/ agencies
4.2. Module 2: Develop
Vision, Mission, Goals and
Targets(ii).
Develop
aspirational targets for
2047 and intermediate
milestones

6.
Consulting
Team
6.1. The Consultant shall
form a multi-disciplinary
team (the “Consulting
Team” i.e. combination of
Subject Matter Experts
(SMEs) and on-site team for
undertaking
the
Assignment. The experts
nominated
by
the
Consultant
must
be
confirmed as available for
the Assignment to do the
scheduled
tasks.
The
Consulting Team must
comprise of highly qualified

sustainability strategies for Central/ State
Government departments/ agencies"

Considering the scope of work of the RFP, the
bidder proposes that the following role should
be added to the list of required subject matter
experts: Economic expert: with experience of
1 project in tourism sector/tourism strategy
project Role: Provide valuable insights into
market trends and economic forecasts for
developing
aspirational
targets
and
intermediate milestones
We understand that all of the Subject Matter
Experts will not be required onsite full-time
and the bidder may plan their involvement in
the project keeping in view the work tracks
and
timelines
of
the
project.
Also, the bidder understands that additional
profiles other than the SME may me proposed
other than the ones given in the RFP

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

It is clarified that On-Site full time team will
have to be stationed in Delhi and if require
report to the Ministry of Tourism person.
Project Leader cum Governance expert and
SMEs can be stationed outside Delhi however
they will necessarily have to participate in the
meetings, discussions, presentations etc. to
give their insight and elaborate their
contribution.

Page 9 of 26

<!-- page 17 -->

23

24

25

26

27

28

and experienced experts,
best suited for the
Assignment
6.2. Subject Matter Experts We suggest that the following role should be Please refer to the corrigendum(s) issued in
added to the list of required subject matter respect of RFP no. SD-8/41/2023-SD dated
experts:
20.02.2024
Quality Assurance and Regulatory Expert:
Role: Developing strategies for quality
accreditation and regulation across the
tourism value chain
4.6. Module 6: Institutional 1. Request more information on DMO along No change in RFP
Governance
with
some
examples.
(i). Strategy for Destination 2. Will the DMO be created for each
Management
including destination?
DMOs
Section 1.8.1 Schedule of Bidder requests that the Proposal Due date to Ref. clause 1.8.2 of the RFP and also refer to
Selection
Process
- be extended by atleast two weeks from the the corrigendum(s) issued in respect of RFP
Proposal Due Date
date of publishing of the Response to the Pre no. SD-8/41/2023-SD dated 20.02.2024
Bid Queries and Corrigendum.
Earnest Money Deposit
Bidder understands that a EMD (Earnest No change in RFP
Money Deposit) is not required to be
submitted along with the proposal.
Section 3.2.2 Relevant Bidders seeks clarification that if the work Work done by the Applicant (bidding agency)
Experience in developing executed by our network firms would comply can only be submitted for consideration.
strategies
for
the to be submitted as citations
Government in tourism
sector
Section 3.4 - Evaluation of Bidders proposes that keeping in view the No change in the RFP
Financial Proposal
scope of work and eligibility the selection

Page 10 of 26

<!-- page 18 -->

29

30

31

32

33

criteria should be modified keeping
weightages as 70:30 (Technical: Financial)
2.
Technical
Capacity The bidder understands that the eligible Please refer to the corrigendum(s) issued in
The Applicant shall have, assignment referred to here is 3.1. Eligible respect of RFP no. SD-8/41/2023-SD dated
undertaken a minimum of 1 Assignments
20.02.2024
(one) eligible assignment as
defined in Clause 2.3.2 (2) –
Criteria for Evaluation
2. Consultancy Fee for the Providing details of consultancy fee for each No change in the RFP
Project:
project is not feasible for each proposed
resource . The bidder suggests to change this
to "Project Cost"
Form-7
Providing details of the name and contact No change in the RFP
4. Name and contact number of client's representatives is not
number
of
Client’s feasible for each proposed resource. The
representatives
bidder requests to remove this.
(Reference):
Form-6
The bidder understands that the estimated Please refer to the corrigendum(s) issued in
6. Estimated Cost of the cost of the project and the value of the respect of RFP no. SD-8/41/2023-SD dated
Project (in Rs. Crore) contract will be the same. Also it will be highly 20.02.2024
7. Approximate value of the infeasible to provide the details of the
Contract (in Rs. Crore) payment received for each project. Request
8. Payment/Project fee you to remove (7) and (8)
received as Consultancy
Fee by PDD (in Rs. Crore)
Form-5
The bidder understands that the signature Signature and name of the authorized
Signature,
name
and and name of the authorized signatory alone signatory alone will suffice
designation of the Firms will suffice for Form-5.
authorized
signatory/
Statutory Auditor/ CA

Page 11 of 26

<!-- page 19 -->

34

35

36

37

Form-3 Power of Attorney

Kindly confirm if the Board of Resolution
would be acceptable mentioning the name of
the authorized signatory in place of Power of
attorney
1.8 Schedule of Selection As a general practice, the time allowed
Process
between the date on which the responses to
The Proposal Due Date or queries are published and the bid submission
PDD is 13.03.2024
date is three weeks.

No change in the RFP

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

We, therefore, request you to kindly extend
the last date for submission of bids to 22nd
March 2024.
2.7 Conflict of Interest
We wish to highlight that we are a large No change in RFP
Several conflict-of-interest- organization providing various services to
related obligations on us.
various state and central government
departments,
PSUs,
international
organizations, and private clients. We wish
you to note that while we have a mechanism
in place to identify patent and direct conflict
of interests, it may not always be possible to
identify any or all indirect or remote conflict
of interests. Kindly appreciate that our no
conflict confirmations will be subject to the
foregoing
4.4 Substitution of Key We request the authority to kindly waive off Please refer to the corrigendum(s) issued in
Personnel
the penalty clause or modify it.
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024
As a condition to such
substitution, a sum equal to
20% (twenty per cent) of
the remuneration specified
Page 12 of 26

<!-- page 20 -->

38

39

for the original Key
Personnel
shall
be
deducted
from
the
payments due to the
Consultant for one time. In
the case of a second
substitution
hereunder,
such deduction shall be
50% (fifty per cent) of the
remuneration specified for
the original Key Personnel
for one time. Repeated
substitution may lead to
termination
of
the
Agreement.
2.28.3 Appointment of
Consultant
The Authority may examine
the credentials of all SubConsultants/ Consortium
Members proposed for this
Consultancy and those not
found suitable shall be
replaced by the Selected
Applicant
to
the
satisfaction
of
the
Authority.
3.2.2 Applicant’s relevant
experience and cases
studies

Request the authority to kindly clarify No sub-consultants/consortium is allowed
whether sub-consulting is allowed.
and hence para 2.28.3 of RFP may be ignored

We understand that Relevant Experience in Please refer to the corrigendum(s) issued in
developing strategies for the Government in respect of RFP no. SD-8/41/2023-SD dated
the tourism sector would also include
20.02.2024

Page 13 of 26

<!-- page 21 -->

Projects that may have had multi -lateral
agencies support though the end client was
central or state government departments
We kindly request the authority to clarify
whether multiple projects under the same
contract can be considered separately or will
they be considered as same.
We request the authority to kindly clarify and
specify the expected number of man-days
required for the part-time involvement of the
Key personnel (team leader) and respective
Personnel (subject matter experts) to avoid
any conflicts and confusion at a later stage.

40

6.2 Subject Matter Experts

41

6.3 Other SMES as may be
required All SMEs would be
deployed on an as-needed
basis for specific tasks/
activities/ module and
devote sufficient time as
may be required for
comprehensive, in-depth
and quality inputs for the
Strategy.
6.5 On-Site Full-time team We kindly request clarification regarding the
location where the Subject Matter Experts
The
SMEs
shall
be (SMEs) will be stationed. Will they be based at
supported by on site team the Ministry office.
comprising of one project
manager
and
three
consultants who will be
deployed on full time basis
Pre-bid Queries
Please allow the consultants to submit more
Submission of Pre-Bid queries, if any, after the receipt of responses
Queries
to queries
Payment Terms
Kindly elaborate on the mechanism for a
Clarification on payment scenario where the Transaction Advisory is
terms
not successful in the first attempt. Please

42

43

44

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024
Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

No change in the RFP

No change in RFP

Page 14 of 26

<!-- page 22 -->

45

46

specify if that would impact the payment
terms in any way
Indemnity
We agree to indemnify to the extent the No change in the RFP
Indemnities are not subject damages/losses are finally determined by a
to final determination by competent court or arbitration. Please make
the court/arbitrator.
indemnities subject to final determination by
the court/arbitrator. This is also the industry
standard and prescribed by MeitY in its
guidelines
Indemnity
The indemnities set out in this agreement No change in the RFP
shall be subject to the following conditions: (i)
No process for indemnity
the Indemnified Party as promptly as
practicable informs the Indemnifying Party in
writing of the claim or proceedings and
provides all relevant evidence, documentary
or otherwise; (ii) the Indemnified Party shall,
at the cost of the Indemnifying Party, give the
Indemnifying Party all reasonable assistance
in the Defense of such claim including
reasonable access to all relevant information,
documentation and personnel provided that
the Indemnified Party may, at its sole cost and
expense, reasonably participate, through its
attorneys or otherwise, in such Defense; (iii) if
the Indemnifying Party does not assume full
control over the Defense of a claim as
provided in this clause, the Indemnified Party
may participate in such defense at its sole cost
and expense, and the Indemnified Party will
have the right to defend the claim in such
manner as it may deem appropriate, and the
Page 15 of 26

<!-- page 23 -->

cost and expense of the Indemnified Party will
be included in losses; (iv) the Indemnified
Party shall not prejudice, pay or accept any
proceedings or claim, or compromise 8any
proceedings or claim, without the written
consent of the Indemnifying Party; (v) all
settlements
of
claims
subject
to
indemnification under this Clause will: a) be
entered into only with the consent of the
Indemnified Party, which consent will not be
unreasonably withheld and include an
unconditional release to the Indemnified
Party from the claimant or plaintiff for all
liability in respect of such claim; and b) include
any appropriate confidentiality agreement
prohibiting disclosure of the terms of such
settlement; (vi) the Indemnified Party shall
account to the Indemnifying Party for all
awards, settlements, damages and costs (if
any) finally awarded in favour of the
Indemnified Party which are to be paid to it in
connection with any such claim or
proceedings; (vii) the Indemnified Party shall
take steps that the Indemnifying Party may
reasonably require to mitigate or reduce its
loss as a result of such a claim or proceedings;
(viii) in the event that the Indemnifying Party
is obligated to indemnify an Indemnified Party
pursuant to this clause, the Indemnifying
Party will, upon payment of such indemnity in
full, be subrogated to all rights and defenses
Page 16 of 26

<!-- page 24 -->

47

We request the Authority
to include a clause to state
that we will not be liable for
any
indirect
and
consequential losses or
damages

of the Indemnified Party with respect to the
claims to which such indemnification relates;
and (ix) if a Party makes a claim under the
indemnity set out under Clause above in
respect of any particular loss or losses, then
that Party shall not be entitled to make any
further claim in respect of that loss or losses
(including any claim for damages). We will be
providing services and deliverables to you
under the contract. We accept no liability to
anyone, other than you, in connection with
our services, unless otherwise agreed by us in
writing. You agree to reimburse us for any
liability (including legal costs) that we incur in
connection with any claim by anyone else in
relation to the services. We request you to
confirm that our understanding is correct.
We would like to request the authority to No change in the RFP
include a clause to state that we will not be
liable for any indirect and consequential
losses or damages. This is as per GFR and
MeitY guidelines and also the industry
standard. Even the Contract Act, stipulates
and remote and consequential damages are
not payable. We request the client to include
the below clause:
"Purchase/Client agrees that Consultant will
not be liable for (i) loss or corruption of data
from your systems, (ii) loss of profit, goodwill,

Page 17 of 26

<!-- page 25 -->

48

We request the Authority
to kindly to confirm that
our
understanding
is
correct

49

2.2. Consortium of firms
Consortium of firms is not
permitted

50

51

business opportunity, anticipated savings or
benefits or (iii) indirect or consequential loss."
We will be providing services and deliverables
to you under the contract. We accept no
liability to anyone, other than you, in
connection with our services, unless
otherwise agreed by us in writing. You agree
to reimburse us for any liability (including
legal costs) that we incur in connection with
any claim by anyone else in relation to the
services. We request you to confirm that our
understanding is correct.
We request you to kindly allow the shortlisted
firms to partner with a non-shortlisted firm to
offer our joint expertise as a consortium. Also,
we would like to confirm if we can participate
as a consortium in partnership with our
network firms from countries
We request you to kindly consider strategy
projects which include tourism and other
infrastructure areas as well

3.1. Eligible Assignments
For the purpose of
evaluation, the experience
of undertaking assignment
of
developing
comprehensive strategy at
the international, national
or state level in the field of
tourism sector for a
Government authority
-An extension of more than 2 weeks be granted
from the publishing of the pre-bid queries.

No change in the RFP

As per clause 2.2 of the RFP, consortium is
not permitted

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024.

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024.
Page 18 of 26

<!-- page 26 -->

Joint Venture / Consortium be allowed in the
RFP.
Joint Venture / Consortium is not allowed.

52

--

With respect to the captioned RFP, we would Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
like to request for some relaxation in the
20.02.2024.
eligibility criteria for past assignment to allow
for the following:
 Assignments done for any government
agency or PSU for developing
a strategy at national, state or
international level across any sector
 Assignment must have been carried
out in past 10 years – this allows us to
showcase our length of experience in
engaging with govt agencies across
sectors

53

54

1.8. Schedule of Selection We would request you to kindly consider the
Process
extension the proposal submission timeline by
5. Proposal Due Date or 21 days post issue of pre-bid queries by the
PDD 13.03.2024, 17.00 Hrs. client.
2.2. Consortium of firms is Considering the strategic nature of the
not permitted.
engagement with multidisciplinary modules
and resource requirement we understand
relevant international experience on national
level tourism strategy would be essential.

Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024.

No change in the RFP

Page 19 of 26

<!-- page 27 -->

Also, similar engagements has been limited in
India.
Hence, we request the Authority to allow
Consortium of firms to participate.
55

56

2.3.2
3. Financial Capacity
The Applicant shall have
minimum annual revenue
of Rs. 250 crores (Rupees
Two Hundred Fifty crores
only) from consultancy
assignments during each of
the last three financial ears
(i.e. 2020-21, 2021-22 and
2022-23) preceding the
PDD. For the avoidance of
doubt, professional fees
hereunder refer to fees
received by the Applicant
for providing advisory or
consultancy services to its
clients.
3.4. Liability of the
Consultant

Requesting below mentioned modification to No change in the RFP
the required profile: The bidder should have a
minimum of INR 500 Cr. average turnover in
the last 3 financial years (2020-2021, 20212022, 2022-2023)

Requesting following
incorporated:

clause

to

be Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
20.02.2024

3.4.4. This limitation of 3.4.4. This limitation of liability specified in
liability specified in Clause
Clause 3.4.3 shall not affect the Consultant’s
3.4.3 shall not affect the
Consultant’s liability, if any, liability, if any, for damage to Third Parties
for damage to Third Parties caused by the Consultant or any person or
Page 20 of 26

<!-- page 28 -->

57

58

caused by the Consultant or
any person or firm acting
on behalf of the Consultant
in carrying out the Services
subject, however, to a limit
equal to 3 (three) times the
Agreement Value.
4.2
Deployment
of
Personnel

firm acting on behalf of the Consultant in
carrying out the Services subject, however, to
a limit equal to 1 (one) times the Agreement
Value.

We request the Authority to allow at least 60 No change in the RFP

days’ notice in writing decrease / increase the
4.2.2. The Authority, may number of personnel.
by giving 30 days’ notice in
writing decrease / increase
the number of personnel
depending on workload
and the payment to be
made to the Consultant
would accordingly be
adjusted as per actual
deployment of personnel.
4.4. Substitution of Key Considering the engagement is deliverable Please refer to the corrigendum(s) issued in
Personnel
based on remuneration of core personnel is respect of RFP no. SD-8/41/2023-SD dated
not applicable, requesting the authority to 20.02.202
4.4.2. The Authority will not consider following change in the clause:
consider substitution of Key
Personnel
except
for 4.4.2. The Authority will not consider
reasons of any incapacity,
substitution of Key Personnel except for
death, health grounds,
resignation by personnel reasons of any incapacity, death, health
etc. Such substitution shall grounds, resignation by personnel etc. Such
except for the reasons cited substitution shall except for the reasons cited
Page 21 of 26

<!-- page 29 -->

59

above and initiated by the
bidder would be limited to
one Key Personnel subject
to equally or better
qualified and experienced
personnel being provided
to the satisfaction of the
Authority. As a condition to
such substitution, a sum
equal to 20% (twenty per
cent) of the remuneration
specified for the original
Key Personnel shall be
deducted
from
the
payments due to the
Consultant for one time. In
the case of a second
substitution
hereunder,
such deduction shall be
50% (fifty per cent) of the
remuneration specified for
the original Key Personnel
for one time. Repeated
substitution may lead to
termination
of
the
Agreement.
4.4. Substitution of Key
Personnel

above and initiated by the bidder would be
subject to equally or better qualified and
experienced personnel being provided to the
satisfaction of the Authority. Repeated
substitution may lead to termination of the
Agreement.

We understand that in the course of the Please refer to the corrigendum(s) issued in
Project's implementation, if the performance respect of RFP no. SD-8/41/2023-SD dated
of any key person is found unsatisfactory, the 20.02.2024
4.4.4 In case the Authority Authority may initiate a request for
is not satisfied with the substitution.
Page 22 of 26

<!-- page 30 -->

60

performance of any Key
Personnel, the Authority
may initiate a request for
substitution of such Key
Personnel.
This
substitution will also be
subject
to
payment
deductions as described in
Clause 4.4.2.
3.1 Eligible Assignments
….Provided further that

61

(i) The assignment must
have commenced in the
last 7 (five) years preceding
the Proposal Due Date
(PDD)
3.2.2. Applicant’s relevant
experience and cases
studies

We request that substitutions requested on
such accounts should not be placed for
payment deductions

Considering limited strategy engagements in Please refer to the corrigendum(s) issued in
the tourism sector, requesting authority to respect of RFP no. SD-8/41/2023-SD dated
consider following change:
20.02.2024
(i) The assignment must have commenced in
the last 10 (ten) years preceding the Proposal
Due Date (PDD).

Considering strategy engagement name & Please refer to the corrigendum(s) issued in
scope may not clearly define required respect of RFP no. SD-8/41/2023-SD dated
modules and limited nos of strategy 20.02.2024
engagement in tourism sector, we hereby
1. Relevant Experience in requesting the authority to consider following
developing strategies for change:
the Government in tourism
sector
Category 1. Relevant Experience in
developing strategies for the Government for
2. Two Case studies any sector at national/ state level in India or
demonstrating
internationally with project Fee of at least 1
development of strategies Crore.
for tourism sector at (Maximum of three eligible assignments)
Page 23 of 26

<!-- page 31 -->

national/ state level in India
or internationally
Category 2: Relevant Case studies
demonstrating development of strategies for
tourism sector at national/ state level in India
or internationally with project Fee of at least
50 lacs.
The case studies will be assessed for its
relevance to the scope of work outlined in the
RFP and be evaluated on:
• Approach adopted for designing the strategy
and action plan
• Implementation Support, if extended
• Impact of the program
(Maximum of two eligible assignments)
62

6.2 Subject Matter Expert
1. Project Leader
Governance Expert

63

We request the authority to allow inclusion of Please refer to the corrigendum(s) issued in
respect of RFP no. SD-8/41/2023-SD dated
Chartered Accountancy (CA) along with Post
cum
20.02.2024
Graduate degree.

• Should be a postgraduate from a reputed
institution within/ outside
India …..
Form 2: Financial Proposal The consultancy fee to be quoted must be a
lump sum amount. However, in the event of
the project extending beyond 18 months, the
payment for the resources deployed at the

The total period of assignment is envisaged
as 18 months and hence no additional
payment for resources deployed at the
Ministry will be made in case of project
extending beyond 18 months.
Page 24 of 26

<!-- page 32 -->

64

Additional
Clause
Termination

Ministry (1 project manager and 3
consultants) has not been defined. We
request the Authority to consider a manmonth rate for the resources stationed at the
Ministry.
on Requesting below mentioned clause to be No change in the RFP
incorporated.
“Either Party may terminate this Contract in
whole or in part in the event of a default by
the other Party as per the terms and
conditions in the contract; provided however,
that the non-defaulting Party notifies the
defaulting party in writing of the alleged
default and that the defaulting Party does not
cure the alleged default within sixty (60)

65

calendar days of receipt of written notice
thereof”
Form of Agreement
In the event of a delay in the approval of the In the event of delay in the approval of
report or milestone by the client no penalty report or milestone by the client, no penalty
7.3. Penalty for deficiency should be imposed on the consultant.
would be imposed. Otherwise no change in
in Services
the RFP.
Furthermore, any delay in any of the
(b) Impose penalty to the milestones shall impact the timeline of other
extent of 5% for delay upto modules, and as such, the timeline shall have
1 month per milestone 10% to be revised accordingly for the submission of
for delay upto 2 months per future milestones or reports.

Page 25 of 26

<!-- page 33 -->

milestone 20% for delay up Additionally, if the project duration exceeds
to 3 months per milestone
18 months, the consultant's team deployed
full time at the client location will be subject
to additional payments.
******

Page 26 of 26
