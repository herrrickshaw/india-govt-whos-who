---
doc_id: "b82cbd00bacfef7d"
source_url: "https://powermin.gov.in/static/uploads/2025/07/c7f4ff6aaac7392eef191248fc11a003.pdf"
ministry: "Power"
title: "Electricity (Rights of Consumers) Amendment Rules, 2024"
date: "2024-02-22"
pages: 6
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "231a57365bf48118"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-22022024-252303
xxxGIDHxxx
CG-DL-E-22022024-252303
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 114]

नई दिल्ली, बतहस्ट्पजतिार, फरिरी 22, 2024/फाल्गुन 3, 1945
NEW DELHI, THURSDAY, FEBRUARY 22, 2024/PHALGUNA 3, 1945

No. 114]

जिद्युत मंत्रालय
अजधसूचना
नई दिल्ली, 22 फरिरी, 2024
सा.का.जन. 125(अ).—कें द्रीय सरकार, जिद्युत अजधजनयम, 2003 (2003 का 36) की धारा 176 की
उप धारा (1), उपधारा (2) के खंड (य) द्वारा प्रित्त िजियों का प्रयोग करते हुए, जिद्युत (उपभोिा अजधकार)
जनयम, 2020 का, और संिोधन करने के जलए जनम्नजलजखत जनयम बनाती है, अर्ाात-्
1.

(1) इन जनयमों का संजिप्त नाम जिद्युत (उपभोिा अजधकार) संिोधन जनयम, 2024 है।
(2) ये रािपत्र में इनके प्रकािन की तारीख से प्रितत्त होंगे।

2.

जिद्युत (उपभोिा अजधकार) जनयम, 2020 (जिसे इसमें इसके पश्चात मूल जनयम कहा गया है),के जनयम 2 के ,

उपजनयम (1) में,(i) खंड (ट) के पश्चात, जनम्नजलजखत खंड अंत:स्ट्र्ाजपत दकया िाएगा, अर्ाात्: '(टक) "स्ट्िामी" से िह व्यजि अजभप्रेत है जिसके पास संपजत्त पर पूणा अजधकार है और पि स्ट्िामी के अंतगात जिजधक
िाररस आता है;
(ii) खंड (डख) के पश्चात,जनम्नजलजखत खंड अंत:स्ट्र्ाजपतदकया िाएगा, अर्ाात:् 1212 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

"(डग) 'रे जिडेंट िेलफे यर एसोजसएिन' (जिसे इसमें इसके पश्चात एसोजसएिन कहा गया है) से सहकारी समूह
आिासीय सोसायटी, बहुमंजिला इमारत, आिासीय कॉलोनी या राज्य सरकार के सार् रजिस्ट्रीकत त समान जनकाय
में आने िाले सभी संपजत्त के स्ट्िाजमयों का एक एसोजसएिन, अजभप्रेत है।"
3.

मूल जनयम के , जनयम 4 में,-

(i) उप-जनयम (11) के स्ट्र्ान पर जनम्नजलजखत उप-जनयम रखा िाएगा, अर्ाात:् "(11) सभी प्रकार से पूणा आिेिन को िमा करने के पश्चात, जितरण अनुज्ञजप्तधारी द्वारा नए कनेक्िन उपलब्ध
कराने या मौिूिा कनेक्िन में संिोधन की अजधकतम अिजध आयोग द्वारा जिजनर्िाष्ट की िाएगी िो मेरोपोजलटन
िेत्रों में तीन दिन, अन्य नगरपाजलका िेत्रों में सात दिन और ग्रामीण िेत्रों में पन्द्रह दिन से अजधक नहीं होगी:
परं तु यह दक पहाडी इलाकों िाले राज्यों और संघ राज्य िेत्रों के ग्रामीण िेत्रों के जलए, सभी प्रकार से पूणा आिेिन
प्रस्ट्तुत करने के पश्चात्, नए कनेक्िन याजिद्यमान कनेक्िन के संिोधन के जलए अजधकतम समय अिजध तीस दिन
से अजधक नहीं होगी:
परं तु यह और दक िहां ऐसी आपूर्ता के जलए जितरण मेन के जिस्ट्तार, या नए उप-स्ट्टेिनों को िुरू करने की
आिश्यकता हो, जितरण अनुज्ञजप्तधारी ऐसे जिस्ट्तार या िुरुआत के तुरंत पश्चात् नब्बे दिनों की अिजध के भीतर
ऐसे पररसरों में जिद्युत की आपूर्ता करे गा।

स्ट्पष्टीकरण: इस जनयम के प्रयोिनों के जलए, 'पहाडी इलाके िाले राज्य और संघ राज्य िेत्रों' से अरुणाचल प्रिेि,
जहमाचल प्रिेि, मजणपुर, मेघालय, जमिोरम, नागालैंड, जसदिम, जत्रपुरा, उत्तराखंड, िम्मू-कश्मीर संघ राज्य िेत्र
और लद्दाख संघ राज्य िेत्र’अजभप्रेत है।''
(ii) उप-जनयम 13 के पश्चाजिम्नजलजखत उप-जनयम अंत:स्ट्र्ाजपत दकए िाएंग,े अर्ाात्:“(14) एसोजसएिन के अधीन आने िाले िेत्र के भीतर:
(क) जितरण अनुज्ञजप्तधारी ऐसे एसोजसएिन में अजधकांि घर या फ्लैट के स्ट्िाजमयों की पसंि के आधार पर या तो
एसोजसएिन के जलए एकल बबंि ु कनेक्िन या प्रत्येक स्ट्िामी के जलए अलग कनेक्िन िेगा तर्ा जिकल्प का
अजभजनश्चय जितरण अनुज्ञजप्तधारी द्वारा आयोजित दकए िाने िाले पारििी मतिान के माध्यम से दकया िाएगा;
परं तु यह दक यदि पचास प्रजतित से अजधक स्ट्िामीव्यजिगत कनेक्िन पसंि करते हैं तो प्रत्येक स्ट्िामी को
व्यजिगत कनेक्िन दिया िाएगा।
(ख) मीटररं ग, जबबलंग और संग्रहण जनम्न के जलए पतर्क रूप से की िाएगी:(i) जितरण अनुज्ञजप्तधारी से प्राप्त व्यजिगत जिद्युत की खपत,
(ii) एसोजसएिन द्वारा आपूर्ता की गई बैकअप जिद्युत की व्यजिगत खपत; और
(iii) ऐसे एसोजसएिन के सामान्य िेत्र के जलए जिद्युत की खपत िो जितरण अनुज्ञजप्तधारी से प्राप्त होती है।
(ग) एकल बबंि ु कनेक्िन की ििा में मीटररं ग,जबबलंग और संग्रहण के जलए एसोजसएिन उत्तरिायी होगा तर्ा
व्यजिगत कनेक्िनों के जलए, ये उत्तरिाजयत्ि जितरण अनुज्ञजप्तधारी को जनजहत होंगे।
(घ) एकल बबंि ु कनेक्िन की ििा में:
(i)

व्यजिगत जिद्युत की खपत के जलए एसोजसएिन द्वारा प्री-पेमेंट मीटर के माध्यम से काटे गए प्रभार या
बनाए गए जबल, जबना लाभ-हाजन के आधार पर होंगे।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

(ii)

भारत का रािपत्र : असाधारण

3

एसोजसएिन को एकल बबंि ु कनेक्िन िेने के जलए जितरण अनुज्ञजप्तधारी का टैररफ, लो टेंिन घरे लू प्रिगा
हेतु औसत जबबलंग िर से अजधक नहीं होगा।

(iii)

जितरण अनुज्ञजप्तधारी द्वारा आपूर्ता की गई जिद्युत के जलए एसोजसएिन द्वारा की गई कु ल जबबलंग
जितरण अनुज्ञजप्तधारी को संित्त कु ल टैररफ से अजधक नहीं होगी।

(iv)

व्यजिगत उपभोिा के पररसर तक जिद्युत उपलब्ध कराने के जलए उपगत उप-जितरण नेटिका लागत हेतु
समुजचत आयोग द्वारा जिजहत अजतररि रकम प्रभाररत की िा सकती है।

(15) दकसी एसोजसएिन या दकसी एसोजसएिन में फ्लैट या घर के स्ट्िामी या दकसी अन्य उपभोिा के अनुरोध पर,
जितरण अनुज्ञजप्तधारी इलेजक्रक िाहन चार्ििंग प्रणाली के जलए जिद्युत की आपूर्ता हेतु एक अलग कनेक्िन प्रिान
करे गा;
स्ट्पष्टीकरण.- इस उप-जनयम के प्रयोिनों के जलए, यह स्ट्पष्ट दकया िाता है दक इस कनेक्िन को प्रिान करने की समय-सीमा
जनयम 4 के उप-जनयम 11 के अनुसरण में होगी।
4.

मूल जनयमों के , जनयम 5 में उप-जनयम (7) के स्ट्र्ान पर जनम्नजलजखत उप-जनयम रखा िाएगा, अर्ाात्:“(7) जितरण अनुज्ञजप्तधारी द्वारा मीटरों का परीिण, उपभोिा से उसकी मीटर रीबडंग जिद्युत की खपत के अनुरूप
नहीं होने, मीटर के रुकने, सील के िजतग्रस्ट्त होने, मीटर के िलने या िजतग्रस्ट्त होने और ऐसी दकसी घटनाओं के
बारे में जिकायत प्राप्त होने के तीस दिनों के भीतर दकया िाएगा:
परं तु यह दक दकसी उपभोिा द्वारा मीटर रीबडंग उसकी जिद्युत की खपत के अनुरूप नहीं होने के संबंध में जिकायत
की ििा में, जितरण अनुज्ञजप्तधारी जिकायत प्राप्त होने की तारीख से पांच दिनों के भीतर, खपत को सत्याजपत
करने के जलए, तीन महीने की न्यूनतम अिजध हेतु एक अजतररि मीटर संस्ट्र्ाजपत करे गा।"

5.

मूल जनयमों के ,जनयम 11 में,(।) उप-जनयम (7) के स्ट्र्ान पर जनम्नजलजखत उप-जनयम रखा िाएगा, अर्ाात्:“(7)रूफटॉप सोलर फोटो िोजल्टक प्रणाली की संस्ट्र्ापना के जलए, तकनीकी व्यिहायाता का अध्ययन पंद्रह दिन की
अिजध के भीतर पूरा दकया िाएगा और अध्ययन का पररणाम आिेिक को सूजचत दकया िाएगा, ऐसा न हो सकने
पर यह माना िाएगा दक प्रस्ट्ताि तकनीकी रूप से व्यिहाया है।
(7 क)10 दकलोिाट िमता तक की रूफटॉप सोलर फोटो िोजल्टकप्रणाजलयों के जलए सभी प्रकार से पूणा आिेिनों
को तकनीकी व्यिहायाता अध्ययन की आिश्यकता के जबना स्ट्िीकार दकया गया माना िाएगा और उपभोिा के
स्ट्िीकत त भार में कोई भी आनुपाजतक ितजि, िो भी आिश्यक हो, जितरण अनुज्ञजप्तधारी द्वारा की िाएगी।";
(ii) उप-जनयम (8) के स्ट्र्ान पर जनम्नजलजखत उप-जनयम प्रजतस्ट्र्ाजपत दकया िाएगा,अर्ाात्:(8) उप-जनयम (7क) के अध्यधीन, व्यिहायाता संबंधी अध्ययन या आिेिन की माजनत स्ट्िीकत जत से लेकर संस्ट्र्ापना
के पूरा होने तक की समय अिजध के िौरान,यदिसोलर फोटो िोजल्टक प्रणाली की आिश्यक िमता की संस्ट्र्ापना
के जलए जितरण अिसंरचना के उन्नयन, िैस,े सेिा लाइन, जितरण रांसफामार िमता और इस प्रकार की
अिसंरचना में यदि ितजि की कोई आिश्यकता हैतो,यर्ाजस्ट्र्जत, इसे जितरण अनुज्ञजप्तधारी या उपभोिा द्वारा
दकया िाएगा:
परं तु यह दक 5 दकलोिाट की िमता तक या राज्य आयोग द्वारा जिजहत उच्चतर िमता तक रूफटॉप
सोलर फोटो िोजल्टक प्रणाजलयों की संस्ट्र्ापना को सुकर बनाने के जलए आिश्यकतानुसार, जितरण रांसफामार
सजहत, जितरण अिसंरचना को सुिढ़त करने की लागत,जितरण अनुज्ञजप्तधारी की रािस्ट्ि आिश्यकता में िाजमल
की िाएगी।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(iii) उप-जनयम (9) के स्ट्र्ान पर जनम्नजलजखत उप-जनयम रखा िाएगा,अर्ाात्:“(9) सोलर फोटो िोजल्टक प्रणाली की संस्ट्र्ापना के पश्चात, उपभोिा ऐसे जितरण अनुज्ञजप्तधारी को संस्ट्र्ापना
प्रमाण पत्र िमा करे गा और ऐसा जितरण अनुज्ञजप्तधारीसंस्ट्र्ापना प्रमाणपत्र िमा होने की तारीख से पंद्रह दिनों के
भीतर कनेक्िन करार पर हस्ट्तािर, मीटर की संस्ट्र्ापना और रूफटॉप सोलर फोटो िोजल्टक प्रणाली की सफल
िुरुआत को पूरा करे गा।
(9क) कनेक्िन करार और संस्ट्र्ापना प्रमाण पत्र के प्रारूपों को जितरण अनुज्ञजप्तधारी के िेब-पोटाल पर रखा
िाएगा।
[फा. सं. 23/05/2020-आरएंडआर]
श्रीकांत नागुलापल्ली, अपर सजचि
रटप्पणी : मूल जनयम भारत के रािपत्र, असाधारण, भाग II, खंड 3, उप-खंड (i) में संख्याक सा.का.जन. 818(अ),
तारीख 31 दिसंबर, 2020 द्वारा प्रकाजित दकए गए र्े तर्ा संख्याक सा.का.जन. 437 (अ), तारीख14 िून,
2023 द्वारा अंजतम बार संिोजधत दकए गए र्े।

MINISTRY OF POWER
NOTIFICATION
New Delhi, the 22nd February, 2024
G.S.R. 125(E)..—In exercise of the powers conferred by sub-section (1), clause (z) of sub-section (2) of
section 176 of the Electricity Act, 2003 (36 of 2003), the Central Government hereby makes the following rules,
further to amend the Electricity (Rights of Consumers) Rules, 2020, namely:1.

(1) These rules may be called the Electricity (Rights of Consumers) Amendment Rules, 2024.

(2) They shall come into force on the date of their publication in the Official Gazette.
2.
In the Electricity (Rights of Consumers) rules, 2020 (here in after referred to as the principal rules), in rule 2, in
sub-rule (1),(i) after clause (k), the following clause shall be inserted, namely:'(ka) "owner" means the person who is having absolute right over the property and the expression owner includes the
legal heirs';
(ii) after clause (mb), the following clause shall be inserted, namely:“(mc) 'Resident Welfare Association' (here in after referred to as the Association) means an association comprising all
the property owners within a Co-operative Group Housing Society, Multi storied Building,Residential Colony, or a
similar body registered with the State Government.”
3.

In the principal rules, in rule 4,-

(i)

for sub-rule (11), the following sub-rule shall be substituted, namely:-

“(11)The Commission shall specify the maximum time period, after submission of application complete
in all respects, not exceeding three days in metropolitan areas, seven days in other municipal areas and fifteen days in
rural areas, within which the distribution licensee shall provide new connection or modify an existing connection:
Provided that for rural areas of States and Union Territories having hilly terrain, the maximum time
period for new connection or modification of an existing connection, after submission of application, complete in all
respects, shall not exceed thirty days:
Provided further that where such supply requires extension of distribution mains, or commissioning of new substations, the distribution licensee shall supply the electricity to such premises immediately after such extension or
commissioning within a period not exceeding ninety days.

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

Explanation: For the purposes of this rule, the term ‘States and Union Territories having hilly terrain’ means the
States of Arunachal Pradesh, Himachal Pradesh, Manipur, Meghalaya, Mizoram, Nagaland, Sikkim,
Tripura,Uttarakhand,Union Territory of Jammu & Kashmir and Union Territory of Ladakh.”
(ii) after sub-rule 13, the following sub-rules shall be inserted, namely:“(14) Within the area covered under an Association:
(a) The distribution licensee shall provide either a single point connection for the Association or individual
connections for each and every owner, on the basis of choice of the majority of the houseor flat owners in such
Association and the choice shall be ascertained by means of a transparent ballot to be held by the distribution
licensee;
Provided that if more than fifty percent of the owners prefer individual connection then individual connection shall be
given to each owner.
(b) the metering, billing, and collection shall be done separately for
(i) individual electricity consumption sourced from the distribution licensee;
(ii) individual consumption of back up power supplied by the Association; and
(iii) electricity consumption for common area of such Association sourced from the distribution licensee.
(c) In the case of a single point connection, the Association shall be responsible for metering, billing, and collection
and for individual connections, these responsibilities shall vest with the distribution licensee.
(d) In the case of a single point connection:
(i) the charges deducted through pre-payment meters or bills raised by theAssociation for individual electricity
consumption shall be on no-profit-no-loss basis.
(ii) the distribution licensee’s tariff for single point connection to Associations shall not exceed the average billing
rate for low tension domestic category.
(iii) the total billing done by Association for the electricity supplied by the distribution licensee shall not exceed the
overall tariff paid to the distribution licensee.
(iv) an additional amount as prescribed by the Appropriate Commission may be charged towards the sub-distribution
network cost incurred for providing electricity up to the premises of the individual consumer.”
(15)
On the request of an Association or an owner of the flat or house in an Association or any other consumer,
the distribution licensee shall provide a separate connection for supply of electricity for Electric Vehicle charging
system;
Explanation.- For the purposes of this sub-rule, it is clarified that the time line for providing this connection shall be
in accordance with the sub-rule 11 of Rule 4.”.
4.

In the principal rules, in rule 5, for sub-rule (7), the following sub-rule shall be substituted, namely:-

“(7) The testing of meters shall be done by the distribution licensee within thirty days of receipt of the complaint
from the consumer about their meter readings not being commensurate with his consumption of electricity, stoppage
of meter, damage to the seal, burning or damage of the meter, and the like:
Provided that in case of complaint by a consumer regarding meter reading not being commensurate with his
consumption of electricity, distribution licensee shall install an additional meter within five days from the date of
receipt of the complaint, to verify the consumption, for a minimum period of three months.”
5.
(i)

In the principal rules, in rule 11,for sub-rule (7), the following sub-rule shall be substituted, namely:-

“(7) For installation of roof top solar photo voltaic systems, the technical feasibility study shall be completed within a
period of fifteen days and the outcome of the study shall be intimated to the applicant, failing which it shall be
presumed that the proposal is technically feasible.
(7A) The applications for roof top solar photo voltaic systems upto 10 kW capacity, complete in all respects shall be
deemed to have been accepted without requiring technical feasibility study and any commensurate enhancement of
the sanctioned load of the consumer, as may be required, shall be carried out by the distribution licensee.”;
(ii) for sub-rule (8), the following sub-rule shall be substituted, namely:(8) subject to sub-rule (7A), during the time period from the feasibility study or deemed acceptance of the application
till the completion of installation, in case, there is any requirement of upgradation of distribution in frastructure like

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

augmentation of service line, distribution transformer capacity, and the like for installation of the required capacity of
roof top solar photo voltaic system, the same shall be carried out by the distribution licensee or consumer, as the case
may be:
Provided that the cost of strengthening the distribution infrastructure, including distribution transformer, as
necessary, to facilitate the installation of roof top solar photovoltaic systemsup to a capacity of 5 kW or a higher
capacity as prescribed by the State Commission, shall be included in the revenue requirement of the distribution
licensee.
(iii) for sub-rule (9), the following sub-rule shall be substituted, namely:“(9) After installation of roof top solar photovoltaic system, the consumer shall submit the installation certificate to
such distribution licensee and such distribution licensee shall complete signing of connection agreement, installation
of meter and successful commissioning of the roof top solar photovoltaic system within fifteendays from the date of
submission of the installation certificate.
(9A)The Formats of connection agreement and installation certificate shall be placed on web-portal of the distribution
licensee.”
[F. No. 23/05/2020-R&R]
SRIKANT NAGULAPALLI, Addl. Secy.
Note : The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i)
vide number G.S.R. 818(E), dated the 31st December, 2020 and was last amended vide number G.S.R. 437(E),
dated 14thJune, 2023.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
MANOJ
KUMAR
VERMA

Digitally signed by MANOJ
KUMAR VERMA
Date: 2024.02.22 21:44:37
+05'30'
