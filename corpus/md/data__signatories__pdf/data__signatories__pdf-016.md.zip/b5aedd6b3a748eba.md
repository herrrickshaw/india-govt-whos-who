---
doc_id: "b5aedd6b3a748eba"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/28acf6914b1ba010c8c870d77be4b4a6.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment of Mrs. Amrita Shrivastva as ASGC for District Jamshedpur: Order dated 26.06.2018"
date: "2018-06-27"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e506b85436db6593"
---

<!-- page 1 -->

F. No. J-11015/8/2018-Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated 26" June, 2018
ORDER
The President is pleased to engage Mrs. Amrita Shrivastva, Advocate as Additional
Standing Government Counsel for conducting Central Govt. litigation (except cases of
Railways & Taxation) before the District & Subordinate Courts, Jamshedpur (Jharkhand), as
mentioned below, for a period of three years from the date of this order or until further orders.
whichever is earlier:
District & Subordinate Courts, Jamshedpur (Jharkhand)
Additional Standing Government Counsel
number
Mrs. Amrita A-5, 2™ Floor, Brindaban Gardens, | JH/4439-A/2010
Shrivastva Sonari, Jamshedpur-831011
Mob: 8789425742, 9801524000
Email: amyyshriv@gmail.com
2. The engagement and professional fee of the aforesaid advocate will be governed by
the terms and conditions contained in this Department's OM No. 27(11)/99-Judl. dated
24.09.1999 read with OM No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued
subsequently through OMs. The aforesaid OMs are available on the website of this
Department i.e. www.legalaffairs.gov.in inside the tab ‘Judicial Section’ under heading
‘Circulars pertaining to litigations’.
3. Hindi version of this order will follow.
DHE,
WF 6-8 Lé
(Inder Kumar)
Additional Secretary
Copy for information to:-
1. PS to ML&J/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.
2. Shri Rajiv Sinha, Asstt. SGI, High Court of Jnarkhand at Ranchi.
3. The District Judge, Jamshedpur, Jharkhand.
4. Mrs. Amrita Shrivastva, Addl. SGC as above.
5. To be uploaded on the website of this Department i.e. www.legalaffairs.gov.in under the tab
‘Judicial Section’ in the link ‘List of empanelled Counsel’ for the information of all concerned.
6. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
7. Guard File/Judicial Section with 5 spare copies.
2S ५ > * + “८
— Dp Sinvds)
(D. Srinivas)
Section Officer (Judicial)
Phone: 011-23384945
Email: Judicial-dla@nic.in
