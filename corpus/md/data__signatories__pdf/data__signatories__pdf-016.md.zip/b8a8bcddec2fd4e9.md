---
doc_id: "b8a8bcddec2fd4e9"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/39f21e039a864b25e8a6bcdc75e0ed66.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "FCA - Comparative Figures (Post Policy Period)"
date: "2025-07-19"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a3a91879452ca890"
---

<!-- page 1 -->

Foreign Colloboration Approvals (Route wise) - Comparative Figures (Post Policy Period)
-----------------------------------------------------------------------------Post-Policy Period
<------------------------------------------------------->
(1st to 11th Years)
12th Year
Total
(August '1991-July '2002)
(Aug'2002 - Sep'2002)
(Aug'91-Sep'2002)
-----------------------------------------------------------------------------1. Total No. of Foreign
Collaboration approvals i) SIA
3983
90
4073
ii) RBI
7958
141
8099
iii) FIPB
10350
144
10494
TOTAL
2. No. of FC approvals
(Technical) approvals i) SIA
ii) RBI
iii) FIPB
TOTAL
3. No. of FC approvals
involving Foreign
investment i) SIA
ii) RBI
iii) FIPB
TOTAL
3. Total Amount of
Foreign Investment
involved (Rs in Billions)
---------------i) SIA
ii) RBI
iii) FIPB

22291

375

22666 *

2601
4288
209

35
22
0

2636
4310
209

7098

57

7155

1382
3670
10141

55
119
144

1437
3789
10285

15193

318

15511

55.9
203.7
2556.7

0.7
1.9
8.5

56.6
205.6
2565.2

TOTAL (In Indian Rupees)
2816.3
11.1
2827.4 *
-----------------------------------------------------------------------------Note : (i) 1 Billion = 100 Crores
(ii) "*" -- includes 93 proposals approved by FIPB
for Global Depositary Receipts(GDR)/Foreign Currency
Convertable Bonds (FCCBs) involving investment of
483.72 Billion
SIA

- Secretariat for Industrial Assistance

RBI

- Reserve Bank of India

FIPB - Foreign Investment Promotion Board
------------------------------------------------------------------------------------------------------------------------
