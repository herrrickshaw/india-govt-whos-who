---
doc_id: "b80ba7ccc238aba6"
source_url: "https://www.legislative.gov.in/static/uploads/2025/07/0cf16c3f1479074a87011e066396733e.pdf"
ministry: "Legislative Department (LD)"
title: "The Constitution (Eighth Amendment) Act, 1959"
date: "1960-01-05"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eb0c070f5fae0fc9"
---

<!-- page 1 -->

THE CONSTITUTION (EIGHTH AMENDMENT) ACT,
1959
THE

CONSTITUTION

(EIGHTH

AMENDMENT)

ACT,

1959

Statement of Objects and Reasons appended to THE CONSTITUTION (Fourth Amendment)
Bill, 1954 which was enacted as the Constitution (Fourth Amendment) Act, 1954
STATEMENT

OF

OBJECTS

AND

REASONS

This Bill seeks to amend articles 31, 31A and 305 of, and the Ninth Schedule to, the
Constitution.
2.
Recent decisions of the Supreme Court have given a very wide
meaning to clauses (1) and (2) of article 31.
Despite the difference
in the wording of the two clauses, they are regarded as dealing with
the
same subject.
The deprivation of property referred to in
clause
(1)
is
to
be
construed
in
the
widest
sense
as
including
any
curtailment of a right to property. Even where it is caused
by a
purely regulatory provision of law and is not
accompanied
by an
acquisition
or taking possession of that or any other property
right
by the State, the law, in order to be valid according
to these
decisions,
has
to provide for compensation under clause (2)
of
the
article.
It
is
considered
necessary,
therefore,
to
re-state
more
precisely
the
State's
power
of
compulsory
acquisition
and
requisitioning of private property and distinguish it from cases where
the
operation of regulatory or prohibitory laws of the State
results
in "deprivation of property". This is sought to be done in clause
2
of
the
Bill.
3.
It will be recalled that the zamindari abolition laws which came
first
in our programme of social welfare legislation were attacked by
the
interests
affected mainly with reference to articles 14, 19
and
31, and that in order to put an end to the dilatory and
wasteful
litigation
and
place
these
laws above
challenge
in
the
courts,
articles 31A and 31B and the Ninth Schedule were enacted
by the
Constitution
(First
Amendment)
Act.
Subsequent
judicial
decisions
interpreting
articles 14,
19 and 31 have raised serious
difficulties
in the way of the Union and the States putting through other
and

<!-- page 2 -->

equally
e.g.,

important

social

welfare
the

legislation

on

the

desired
lines,
following:-

(i)
While the abolition of zamindaris and the numerous intermediaries
between the State and the tiller of the soil has been achieved for the
most part, our next objectives in land reform are the fixing of limits
to the extent of agricultural land that may be owned or occupied by
any person, the disposal of any land held in excess of the prescribed
maximum and the further modification of the rights of land owners and
tenants
in
agricultural
holdings.
(ii)

The

beneficial
of

proper

planning

utilisation

of

of

vacant

urban
and
slum

and

rural

areas

waste

lands

and

require
the

the

clearance
areas.

(iii)
In the interest of national economy the State should have
full
control
over the mineral and oil resources of the country,
including
in particular, the power to cancel or modify the terms and conditions
of
prospecting
licenses,
mining
leases
and similar
agreements.
This
is
also
necessary in relation to public utility
undertakings
which
supply power, light or water to the public under licenses granted by
the
State.
(iv) It is often necessary to take over under State management
temporary
period
a
commercial or industrial
undertaking
or
property
in
the
public interest or in order to
secure
the

for a
other
better

management
of the
temporary transference
the

undertaking or property.
Laws providing for
such
to State management should be permissible under
Constitution.

(v)

company

The

reforms

in

law

now

under

contemplation,

like

the

progressive
elimination of the managing agency system, provision
for
the compulsory amalgamation of two or more companies in the national
interest, the transfer of an undertaking from one company to another,
etc.,
require
to
be
placed
above
challenge.
It is accordingly
of article
31A
legislation.

proposed in clause 3 of the Bill
so as to cover these categories

to extend the scope
of essential welfare

<!-- page 3 -->

4.
As a corollary to the proposed amendment of article 31A, it is
propsed in clause 5 of the Bill to include in the Ninth Schedule to
the Constitution two more State Acts and four Central Acts which fall
within the scope of sub-clauses (d) and (f) of clause (1) of
the
revised article 31A.
The effect will be their complete, retrospective
validation
under
the
provisions
of
article
31B.
5.
A recent judgment of the Supreme Court in Saghir Ahmed v.
the
State of U.P. has raised the question whether an Act providing for a
State
monopoly
in a particular trade or business conflicts with
the
freedom of trade and commerce guaranteed by article 301, but left the
question undecided.
Clause (6) of article 19 was amended
by the
Constitution
(First
Amendment)
Act
in order
to
take
such
State
monopolies out of the purview of sub-clause (g) of clause (1) of that
article, but no corresponding provision was made in Part XIII of the
Constitution
with reference to the opening words of article 301.
It
apears from the judgment of the Supreme Court that notwithstanding the
clear
authority of Parliament or of a State Legislature to
introduce
State monopoly in a particular sphere of trade or commerce, the law
might have to be justified before the courts as being "in the public
interest"
under
article
301
or
as
amounting
to
a
"reasonable
restriction"
under
article
304(b).
It
is
considered
that
any
such
question
ought
to be left to the final decision of
the
Legislatue.
Clause 4 of the Bill accordingly proposes an amendment of article 305
to
make
this
clear.
NEW

DELHI;

JAWAHARLAL

The

17th

THE

CONSTITUTION

December,

(EIGHTH

AMENDMENT)
[5th

further

NEHRU.

An

Act

to

BE it

enacted by Parliament

amend

the

1954.

ACT,

1959

January,1960.]
Constitution

of

India.

in the Tenth Year of the Republic of India

<!-- page 4 -->

as
1.
Short
Amendment)

follows:--title.-This

Act

may

be

called
Act,

the

Constitution

2.
Amendment of article 334.-In article 334 of the
the words "ten years" the words "twenty years" shall be substituted.

(Eighth
1959.

Constitution,

for
