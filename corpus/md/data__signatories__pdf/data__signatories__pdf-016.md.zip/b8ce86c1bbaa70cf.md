---
doc_id: "b8ce86c1bbaa70cf"
source_url: "https://mohua.gov.in/static/uploads/2025/11/d46a7827d09b956dde60bd367ac09f04.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs.1,42,20,000/- as 1' installment (2nd Release) of Central Assistance for 46 BLC projects sanctioned in 40th CSMC to the State Government of Maharashtra under Pradhan Mantri Yojana -Urban (PMAY-U) for the financial year 2020-21."
date: "2021-03-26"
pages: 9
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "8d63a7a4d7323e40"
---

<!-- page 1 -->

irefox © https://pfms.nic.in/Sanction/TemplateA dvice.aspx?AdviceNum=...
. $30
PAO (Sectt) /HUA/Admn/Advice /2020-21/-24.24 -2587
GOVERNMENT OF INDIA
PAO (Sectt) M/o Housing and Urban Affairs
507-C Nirman Bhawan New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The General Manager,
Reserve Bank of India, 20729 81॥|
Central Accounts Section, jez
Additional Office Building, Advice Date:
East High Court Road,
NAGPUR - 440 001
Sir,
Please debit our account with Rs.1,42,20,000/- (One Crore Forty Two Lakh Twenty Thousand
Only.) by contra credit to the following accounts of the Governments with the amounts mentioned against
each:
Month and Year of Accounts: March,2021 The Amount to be Settled: March,2021
Name of the State Scheme Code Amount | Sanction No. and Date
State Code
1 MAHARASHTRA | 109 1989-STATE AND UT 1,42,20,000 N-11012/83/2018-HFA-IV-UD
GRANTS UNDER PMAY (EFS-9055602) dated
(URBAN) 26/03/2021
Signature of the authorized official
(Pawan Kumar Bhatnagar)
Sr. Accounts Officer
1. O/o the Accountant General (A&E)-I, Maharashtra, Mumbai-440001.
2a Sanjeev Kumar Sharma, US (HFA-IV), M/o Housing and Urban Affairs, New Delhi -110011.
Pawan Kumar Bhatnagar
Sr. Accounts Officer
() pe -HFY
Nee
0) Mor CE Brea
15149
(2) 7 A
¢
3) pis Hl
12%
Ay ae
we
lof 1 } 26-03-2021, |

<!-- page 2 -->

N-11012/83/2018-HFA-IV-UD (EFS-9055602)
है हे ल्‍ छ०एथाराला। णीपतांत
Ministry of Housing & Urban Affairs
¥ HFA-IV Division
के कफ के
i ‘Nirman Bhawan, New Delhi
i १: Dated: 26.03.2021
To
The Pay and Accounts Officer (Sect.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan, New Delhi-110011
Sub: Release of Rs.1,42,20,000/- as 1" installment (2™ Release) of Central Assistance for 46 BLC
projects sanctioned in 40" CSMC to the State Government of Maharashtra under Pradhan
Mantri Yojana -Urban (PMAY-U) for the financial year 2020-21.
Sir,

I am directed to convey the Sanction of the President of India to the release of Rs.1,42,20,000/-
(Rupees one crore forty two lakh twenty thousand only) to the State Government of Maharashtra as "
installment (2% Release): of Central grant for Creation of Capital Assets under Pradhan Mantri Yojana
(PMAY) - Housing for All (Urban) Mission-under allocation (for ST beneficiaries) for the FY 2020-21 for
46 BLC projects sanctioned “in 40" CSMC held ‘on 28.11.2018. Project-wise details are annexed as
Annexure. Brief details are given as under:

CSMC No. INumber of BLC [Number of beneficiaries as per] Installment (Ist) 2
& date projects in MIS MIS Release)
हे | : Rs. In lakhs)
8.112018 143.2
2, Based on decision of CSMCs under Pradhan Mantri Awas Yojana (MAY) - Housing for All (HFA)
(Urban) Mission and on’ the recommendations made by MoHUA, the amount of central grant is being
- released subject to following conditions alongwith observations of CSMC:
i, State should ensure that data entry in PMAY(U)-MIS portal are completed at the earliest. The
said amount is being released on the basis of valid beneficiaries entered in PMAY(U)-MIS.
5 Remaining part of 1* instalment/Subsequent instalment will be released based on valid beneficiaries
: entered in PMAY(U}-MIS and on other compliances as per PMAY-U guidelines.

ii. The agencies responsible for implementation of PMAY(U) should get themselves registered on
PFMS portal.

iii, The funds shall be utilized for the purpose and for the selected categorized beneficiaries only, for
which these are sanctioned. Otherwise, these funds will have to be refunded along with interest as
per provisions for GFR-2017. No deviation from the framework for implementation of PMAY (U) is
penmissible.

iv. State should ensure immediate rollout of EAT all ULBs,

vy. State to ensure immediate utilisation of balance funds lying with State/ULBs/IAs.

vi. The expenditure on the implementation of the scheme/projects will be shared between the Central
and the State/(ULB/Implementing Agency (1A) as committed. The committed State share should
also be released within 15 days from the date of receipt of Central Share in the SLNA account.
In case of shortfall of State/ULB/IA share, corresponding amount of Central share will be deducted
from the subsequent instalment(s).

vii. The funds including Central and State share will thereafter be released by the State/UT
Government to the implementing agencies without any delay failing which the amount would be
recovered from the State/UT Government with interest, as applicable, for the period of default.

bux

<!-- page 3 -->

3.
viii. Necessary sanctions/approvals/compliances Tequired under the Statutory or other regulatory regifne
as applicable would be obtained by the authority (es) concemed with the project(s).

ix. The State Government and implementing agencies shall put in place a monitoring system to ensure
that the project (s) achieve Scheduled milestone and envisaged outcomes including implementation
of reforms and other conditions required under the scheme.

x. The State Government/implementing agencies shall utilize the grant in accomance with the approved
guidelines of PMAY () for the impiementation of the Scheme.

xi. The State Goverament shall farnish Utiliza: ion Certificates of the Grant released in the
Prescribed format 2s per ‘GFR — 2017 to the Ministry of Housing and Urban Affairs as
Provided im the scheme guidelines.

xi. Where there is an clement of cash transfer to individual beneficiaries, the same may be made through
PFMS/DBT mode. as applicable and necessary transaction details may be updated in’ MIS
immediately after the disbursement. The State Government shall submit an authenticated certificate
from the bank showing complete details of disbursement of funds to each beneficiary before release

: of subsequent instalment.

xiii, The State Goverment shall ensure the geo-tageing of all houses approved under BLC component of
: PMAY(U) and subsequent release by the State Government to the beneficiaries should be made in 3-
4 instalments depending on the Progress/stage of construction of the house.

xiv. 8४6 Government shall ensure that the specifications of the houses conform. to NBC/IS Standards
and that requisite infrastructure will be Provided by the State Government / ULB.

xv. State Government _ shall submit the Action Taken Report (ATR) on the
observations/recommendations of Third Party Quality Monitoring Agency (TPQMA) for
quality monitoring purpose before release of subsequent instalment,

xvi. State shall comply with Model Code of Conduct while Teleasing funds to implementing

agencies/beneficiaries.

3. The payment may Kindly be made to the State Government immediately. The funds may thereafter

be released to the implementing agencies without any delay failing which the amounts would be recovered

from the State Government with interest for the period of default.

4. The amount is debitable from the aceount of Central Government in the books under the following

Head of Account under Demand No.57 of M/o Housing and Urban Affairs for the ‘year 2020-21:

[aT

ub-Major Head | ७८ | entrally Sponsored Scheme

[a]

a)

a

Object Head | 31.0135 | ants for creation of Capital Assets

5. The amount will be credited to the State Governments account in RBI as per procedure laid down
by Ministry of Finance, Department of ‘Expenditure vide O.M. No. F- Hl (45/76/SC) dated 22.02.1977.
6. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee institution (s) / Organisation(s)

. shall be open to inspection by the sanctioning authority and audit, both by the Comptroller and Auditor
General of India under the Provision of CAG (DPC) Act 1971 and intemal audit by the Principal Accounts
Office of the Ministry or Department, whenever the Institution or Organisation is called upon to do so,

ham

<!-- page 4 -->

: a
x 7. This issues with the concurrence of the Finance Division vide their Note#52, dated 22.03.2021.
8. This sanction has been registered-at Sl. No. 590 © in the Register of HFA Mission Directorate
(HFA-III Section) of the Ministry of HUA for the year 2020-21.
- Yours faithfully,
: ae (Sanjeev Kumar Sharma)
Le Hae Under Secretary to the Government of India
= heed Tele No. 011-23061285
Copy to:-
1. Principal Secretary (Housing), Government of Maharashtra, 3™ Floor, Main Building Mantrelaya,
Mumbai, Maharashtra-400032. :
. +2. Vice President &CEO, Maharashtra Housing and Area Development Authority, Griha Nirman
Bhavan, 4" Floor, Kalanagar, Bandra (East), Mumbai-400051.
3. Accountant General (A&E), Maharashtra.
4, CCA, MoHUA.
5. Director, IFD, MoHUA-
6. Budget Division, MoHUA.
7. NITI Aayog, SP Divn. / DR Divn. New Delhi.
8. O/o CGA, MahalekhaNiyantrakBhavan, New Delhi.
9. Dir (HFA-3), MoHUA. os
10. DDO/Section Officer (Admin-II), MoHUA. |
11. Dy. Chief (MIS), MoHUA to place this sanction at appropriate place on the Website of the Ministry.
12. PMU (MIS), HFA Directorate.
13. AO (HFA), MoHUA.
14. Sanction folder/File copy.
a
३ (Sanjeev Kumar Sharma)
2 Under Secretary to the Government of India

<!-- page 5 -->

प्र
डा ay <3 8
8 E By é
na > ie
Ee s| ठे
ba ' i g
i 3 g
i ‘
a a Ss
-— :
. ; ;
e =
या
- है | ५
= <= 3
८2 a
< g 3
2
3 ie
“
4 €
3 3
3 ड़ |)
3
g
Tier |
$2 sae
ss |i
82/283 .
a2 s¢
$s 3
So
a3 (fe
ae Bs.
eg =o &
Es ges
28 ees
8 2523
Ee ae gz
Eg ese
gies
9 =
Bz igs f
zfs 8
¢ BeR i
seh 55
Bea ५ 8 8 ५
2 2&8 ; :
s8as मे ‘ |
3
a
toa, 8 । ।
पे 5
दब है. मे ;
£ 835 5 ।
58 8॥6 ge ।
3 =
BR afb as : '
esx el* s 1!
| =| 2 कु
NX ; 3
A : eg 8
$s Ue
i s| &
a है & 2
#Eq | |
23 g | :
IR é 5 2) 18
Gas & 5 ; :
Yeg पु = है | | :
—_ 7 ae ae _ ne [
ge 36g हैं. gee g23 23% 23 Py
sf ~— y Sia es2 see Ss .
न कु 5 डछ ७8750 SE 3 Qs ge
es £2 ae & Zale BSE Bee 3 als 5
<= दे $ 319 2 88 5 3 डक हा
5 छपाई = 3 sie sec Shore eels | हे
e Qee 68 हि. Sat Sf 422 28/6 £2 -
ac aegis 2 SF 5 2S ves B> 8 -] a Seale 8
Es 81725 SE & शाह 855 aS Be a Se a 35
eu e SSeize2 8 28 gla za alg 28a sae ees
i piss 11111 1117 3 oe sees
88 8 ही अछि हे पर
१ ; 28/2 £18 E[E S18 2 = 3/2 za) 2 हैं हद 6 ५
ga 2 a see sSaleeg = ais paces ak
a gjz $ = 31/8 GIES S sis -Ss z ele 8 5
[| ! 11023 68 है हि 5015 205 Bald Bs 28
5 S Eg 5/2 2 5 8|3 3 ces ecaeece Beg Gls 28
3 3859 a s 23 ean ble fe
3s g HEU Bu 8 १8 08 8 8
= 2 fo] 2 3/8 286 न
* : ease = Ag SRS SSIS ESS 5
33 Cg :
3 7 :
es 55599 1 1 glu Sle
a 8528६ 23 035
bE § 3 se 22 3/2 "|
as 8S SIE j
2£¢§ | ' :
2 5 3
z= | . |
हे 111
£8 | हि
ae 1 |
= z J ;
@ z i J,
3 है ० || 4
| «|
° | 2 |

<!-- page 6 -->

. _
2 के तप
: eg
£ 3 E | a ie a a | Sa 4 A * B é
g हर so}. ०6 छ on. 61 6 s| oj os slo
2 |
J 3
2
2
3
a 3
iy 2g
#1 2 ४
3 5
- छ
a &
8 1; “ हे
2 S
s
2
3 =
. — ie
gg > a
a2 suZ
a3 seit
SS | fee] 5
ax 23% E
sg | 25
zu
22 3
So les
2 a 3
fea js2cR
$3 S235
ih coo D
Eo a2%
a ar
Qo. S32 * 8
236 (2.
g2 |ge
हा =
ge [sg
eal Bs
ga 285
ies aso
5 3
gage मे
sade. g :
Se 8 o 5
ER ased है 3
2 >
egaeers
GRE a
gag 7 ry
23s rz a
333 :
ges
gag 3 alg al 3 3
5.0 8| 4 a
ge: | ही ये मे ¥
sis = = 7 z
x 7 3 a
26 2 2 3 3 g a |z a
28 ejese |B जि जिम = विद थे
oe ke a a a a~ x So छठ न
Ea Bi] seis (8 is Ise 6 38 BS 8
a2 ze] 282 2s fe (22 aj jf jaz |
8 < sais ss |S s2 Bi le |FS fe
£2 = 28l2 - [38 3> {26 f& sSis 6 |S2 656
a 2S SRiS- 58 3s [Sg 5 Base 25
ge z aga gs @ [a8 las fz sale jz (5० lz
ae 8 $ ४5 [$2 je 5 le 8 |e anje i182 [8
53 55८1 ६४5 £ 1 5 जा 5 545 # उा5 80 हझाड जा5ि था 5 5 9
ye B38l Sas 2 ४७ 5915 ८ 85 =z 83 के Zis $15 5/95 s/n 8
es हि 6216 2 gle 2 2/8 2 Ss 2 Sle S| & 212 Ale Sls = Sie B
= 5216 8 8५ ४ जि है 35 है z =
5 28 ६5558 4 88 5 8४5४६ | 55 886 Ble | छह है
2s Sal 222285 sale 6 85 है 48 है| § 2/8 5/8 Zs = 3/8 S
£ cle 2 ls ols 2 S| 2 2
pe $8] 2 ae ale 2 ele bale Bis 8) ¥ 3/2 Sls SIE 2 Biz 8
ge 3 2
gs 28] ZH ESES AS PEE ERIE 5) 2 EE Se 52 2 Sle 8
5 ° ६5 8५ 3 हे ४०
a5 ZO) 2 8/2 88s 582 888 6 26 5 8 sls a Sis zs Sia 5
es
ae g
= =
7“ =
3 z el aloe S| 4
हि छ 3 ले बट 6 3
3 = £ 5 BE 3 €| 3
5 5 z| 3 gE & €| 3
2 | UB -&% 3) 8 é s| 3
sg 8 छ = S| 2 2 21 2
&
, ‘ | 2 [aq a ay ef a ef al ॥ ४ ४|

<!-- page 7 -->

Sean
: है रे se a ee g
— Ss “ठ' a A a oa Be
2 = B ie a a HI a 8) 8 3 8 ड़ é
ea gy 56 s| os} 68 3 s| ol ic ey 3 3 L
x 8
a: |
A os
< 2 3
$s
2
8 ig
8 ¢ P| ta 1 १11४० *
3 §
Z °
5 &
के 1 7 =
5
#2 73
©
88 | ae
a See
a3 sgEig
ae l28s
विज वि
हछ् or
og =
2e ty = -
22 Qa
fe [2.38
$8 |S 235
oR jecsoug
६9 S24
a Ses
#3 [32
Sz igs
ae
=
ge )/3 8
©
ESs ESS].
3 8 8 8४४ &
z 2s
a2 = a
ag= में
oS
38 ने
a
ead Fs =
EVSgsoss 3 -
en रत a NA
5888 51 £
gg 2 ८ ७ ह€।
esa ७ ओके
& ¢ a
agg za
2si Be न
fea £8
४5८४ SG
#Ea 7
a
gag 5 8 yA 8 a 8 2
525 है| g a g| 6B] og sf og डे
= 2 a g & 8B] 8 है a
पट हे न a
eid =
$ =
है दर का al. 5
हुं हुं | बे |e |e है हि fe Pie
aad = a ~ < a a |e |®~ fa 2
Eo g बुत |j~ डे रच o 98 lee |S ys
Eq 2 SRP [5 |s oS थे 18 99०9 के बड्ठ
eo #-| BS2# |3 5 2 ही te Ses a
a3 _ 2 § ale 3 5 Sve |32 5 Se
£Sg 8h Ssals ISr jar [ese Ise Joe SesR
£3 E 83) sgagain B= isc jasl6 (32 पट Beas
aN S Be] हे हट हिट 8 688 jzgiz 3 as 2gcg
= 2 $5 BZ 8/5 85 S215 835 £ 3858
xz 25) o8/6 216 8 5 sls |e ne 3238
3 g 868| 5515 55 55 # प5 £ 75 15 7 % 18 > 5 3255
हर Seas 2
as 2 $2) 85 83 els 2 x G2 Sj2 SJB Za/828) Szzs
25 2 es 5 08 SJE Sis = 4s s Sz Sz Sle S §2x] A#SSa
gs « SR 25/5 elo Ble & See 35 ib S/S 8 8 8 || SESE
3& 28) 2 sl6 sl Bo SBS s Sls Sls SS sss Sees
e¢ है § 918 9/8 Sls 2 Bis 2 S18 U8 Sie ez Slee 8] S288
st Si] BSS RE SR ZSERIES SSS EERE ES! BEZS
e*% Cm 8 ele ale S18 & S18 ६ 86 ८हि 815 5 886 8 8 BS as
ef Se Belg ala Sls e dls esis dle sls esis eB BB? Ss
5s <2 oa B u Vu 3 88 6 रे ०७७६ पर SE
a4 ae] 2 did Sz 818 § 8/8 s Sig sis ole § O18 68) SEE E
2
cs
eo
= 5 :
oe = &
3 z डर fo og if
E g s 3 23
2 7 3 3 है € 3 7 #3
2 = £ s| 3 £ 2s
2 g 3 Ss 3| 8 5 58
s 3 = = S| = = Zs
&
© पु रे
s & a हि

<!-- page 8 -->

2 +
ag
: g
2
a :
a
“oO
| करे
. =
) : | Pfs
रू
eo c रा
= ma 3
: 7 Ha 4
@
+ 3 ig
32
2
हे z
z| 3
§ ड़ | :
%
5
a
33 ERS
ह uc चिंड £
Sie sy 2
as $25
है | 23s
Re | 2i8
ax 32
§¢
S &
33 [Bs
2 =
ea |fic
a 2 "
डे e285
ae Ei
8 |gSo3
o2 ($32
yu Ss
26 33
Oz ig
2 _ a ।
ge 28 :
ba 5
i NA
EER 28s
saa2 3 TT
33 | ल्‍
gaz - a | :
ead z 2
ee saad . ,
ae 3
geass t .
Gale?
gee 2 7
Zag a a :
sé Es : tH
a न 2 8 ४ जि
5६5५8 & 5 रू
PEE 3 mE +
sag Bs | हा 2A) 7
- 3 oo 3 a
Z| . 7
a 2 13 fe lz |, ५ s (2 |g (2
Se als |s ez iy 3 $25 | १
ih ee i 2 ges [2 é E
Se 2°18 5 |z |s ges Peli
<3 Ese 2 = 5 Ses ; id
a 5 a= eh =a —
zs 235 |e [5 5 lez (ge [eee ae
a — 2 बज 4 s 8 २15 ड़ 5
Ea Sale 65 an a2 ge 13 2 3 aba ag
= z 2-4 Be 8 a/é ale हे
| Haas Se alsleale 3 5 हब
" : हि sie
2s 11011 eau ia (ied raat :
gs 31111 कि
ay @ai2¢ mening Ss a2 8 £8 eo 8 ble
“5 = OIE x ab ele Flee SIE E aR Ea gals 8 ef
og 11111 है तह 06 41 8
> S328 Bg S/2 Rie gs 5 als 3 नीली Bas
= 8 als a q B RIES RIE BB = bles
3 5 28.2 gis SIP S18 & £ 166 [0
32 18000 0 778 AE By |
DE g als Sig 8s Ste ls & Sls :
we 135 015 8 Bs
& : :
i 5 51 8/2 is i
8 3 516 हा
§ =
zs ' गा
53 : I I |
| 4 a| al & s|.3
qi Bia g i 5
| * 5| 5 5| #
bs = | gf है| 4 i
है 8 2 2 é &
। ला a
५ 3 i
| | | °
o§
है | 2 | +*|

<!-- page 9 -->
