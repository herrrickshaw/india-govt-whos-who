---
doc_id: "b5dafd0b1ea17f93"
source_url: "https://www.dot.gov.in/static/uploads/2025/12/bde028588930096b4a05277a2182c97f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm No. 837 of 2024 in Honble High Court of Delhi- Additional list DoT instructions dated 01.10.2025 to ISPs"
date: "2025-12-24"
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2ca038cb3b2ed8f7"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3311707/2025

By Email/DoT Website

  
  
  
         
  
 

 

To,
All Licensees with Internet Service Authorization

Subject: CS(Comm) 1147 of 2024: Rajat Sharma & Anr. versus Tamara Doc
& Ors. before the High Court of Delhi.

P    ’      
18.12.2024    
 P   para 35(VI))         



 website/domain [ 1 no.]   
 7th affidavit dated 01.09.2025    P
Healthboosters.biz

           
           
            
Encl: A/A

Director (DS-II)
 
Copy to:
       Y  
         
   
     P  
              

<!-- page 2 -->

Re: CS(Comm) 1147/2024 titled "Rajat Sharma & Anr. v Tamara Do...

1 of 59

https://mail.mgovcloud.in/zm/?fromService=wp&wpVersion=b021d7...

Re: CS(Comm) 1147/2024 titled "Rajat Sharma & Anr. v Tamara Doc & Ors.,"
compliance of Order XXXIX Rule 3, Code of Civil Procedure, 1908
11 emails

Disha Sharma < disha@saikrishnaassociates.com >
Mon, 01 Sep 2025 6:05:39 PM +0530

To "Abhinesh Meena"<jto2ds2-dot@gov.in>
Cc "Avneet Toor Gupta"<avneett.g@nic.in>,"Nagarajan
N"<nagarajan.n@meity.gov.in>,"Cyber Law Legal"<cyberlawlegal@meity.gov.in>,"Deepak Goel"<gccyberlaw@meity.gov.in>,"Chinnasamy
Vembadian"<chinnasamy.v@meity.gov.in>,"Deepika
Pokharia"<deepika@saikrishnaassociates.com>,"Snehima
Jauhari"<snehima@saikrishnaassociates.com>,"Shashi Kumar"<dirds2dot@nic.in>

Dear Sir/Ma’am,
We write to you for and on behalf of Our Clients, Mr. Rajat Sharma and Independent News
Service Private Ltd., having its office at B-39, Okhla Industrial Area, Phase I, New Delhi-110065 (“the
Plaintiffs”).
As you are aware, the Plaintiffs instituted the captioned suit, before the Hon'ble High Court of
Delhi, against several known and unknown defendants seeking to restrain them from misusing and
exploiting the name, likeness, image, photos, videos and/or infringing any other personality and
publicity rights of the Plaintiff No. 1; infringing the registered trademarks ‘INDIA TV’,

,

,
etc., of Plaintiff No. 2 along with the Plaintiff No. 2’s copyright in its ‘AAJ KI
BAAT: RAJAT SHARMA KE SAATH’ show footage and from claiming any association and/or connection
with the Plaintiff(s).
The captioned suit was listed for the first time on 18th December 2024 wherein the Hon'ble Court was
pleased to pass an ex-parte ad-interim Injunction Order inter alia restraining the Defendant Nos. 1-8
from infringing the personality and publicity rights of the Plaintiff No. 1 and from infringing the
registered trademarks and the copyright of the Plaintiff No. 2.
In accordance with the Order of Injunction dated 18th December 2024, wherein the Court was pleased to
pass the following additional directions:
"VI. Defendant Nos. 10 and 11 are directed to issue necessary notifications/directions to all telecom and
internet service providers to block/suspend/the websites, telephone numbers, social media accounts,
channels, platforms, etc. that may subsequently be notified on affidavit by the Plaintiffs to be
infringing their exclusive rights, as identified during the course of the present suit, that are found to be
violating the rights of the Plaintiffs.”
The Plaintiffs are filing an Affidavit for additional links/URLs before the Hon'ble Court as attached with
this email. Further, a copy of the Order dated 18th December 2024 is attached herewith. The list of URLs
for takedown have been attached as an excel sheet for convenience - Annexure B (list for URL
takedown through directions of DOT, MEITY).
In view of the above, you are requested to strictly comply with the Order
dated 18th December 2024 passed by the Hon'ble Delhi High Court. Any violation or noncompliance of the said Order by you shall compel the Plaintiffs to initiate appropriate
proceedings, including proceedings for wilful contempt and disobedience of the
directions passed by the Hon'ble Court.

9/2/2025, 2:38 PM

<!-- page 3 -->

Re: CS(Comm) 1147/2024 titled "Rajat Sharma & Anr. v Tamara Do...

2 of 59

https://mail.mgovcloud.in/zm/?fromService=wp&wpVersion=b021d7...

The link to the Suit documents and Affidavits notifying the additional links/ URLs, filed previously, are
accessible at the OneDrive link below:
Rajat Sharma & Anr. v. Tamara Doc & Ors; CS(COMM) 1147 of 2024
For your reference, the next date of hearing in the matter is 16th September, 2025 before the Joint
Registrar and 22nd September, 2025 before Court.
Please feel free to contact us if you have any queries.
Regards,

7th Affidavit of additional links 01092025.pdf

Disha Sharma | Associate Partner | Saikrishna & Associates, 57 Jor Bagh, First Floor,
New Delhi, 110003, India | Tel: +91-11-40244360 | Handphone: +91-9899296222 |
Enrolment No: D/130/2017
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment &
Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes confidential
information of S&A and may also be the subject of legal professional privilege, not being waived or
lost by mistaken transmission or receipt. If you have received this mail in error, please notify us
at info@saikrishnaassociates.com immediately by reply email and destroy the original - any use,
disclosure or copying of this mail is unauthorised.

On Fri, Aug 8, 2025 at 12:52 PM Disha Sharma <disha@saikrishnaassociates.com>
wrote:
Dear Sir,
This is a gentle reminder to comply with the blocking order concerning the URLs shared in our earlier
communication dated 30 July 2025.
As per the directions issued by the Hon’ble Delhi High Court, the said URLs are required to be
blocked without further delay. In light of this, we request you to issue necessary notifications/
directions to all telecom and internet service providers to block/suspend the attached list of URLs/
domains (ANNEXURE A).
We request you to kindly confirm compliance at the earliest and share a brief status update.
Please let us know if any clarification or further information is required.
Sincerely,
Disha Sharma
Counsel for Plaintiffs

On Wed, Jul 30, 2025 at 7:30 PM Disha Sharma
<disha@saikrishnaassociates.com> wrote:
Dear Sir/Ma’am,
We write to you for and on behalf of Our Clients, Mr. Rajat Sharma and Independent News
Service Private Ltd., having its office at B-39, Okhla Industrial Area, Phase I, New
Delhi-110065 (“the Plaintiffs”).

9/2/2025, 2:38 PM

<!-- page 4 -->

Re: CS(Comm) 1147/2024 titled "Rajat Sharma & Anr. v Tamara Do...

3 of 59

https://mail.mgovcloud.in/zm/?fromService=wp&wpVersion=b021d7...

As you are aware, the Plaintiffs instituted the captioned suit, before the Hon'ble High Court of
Delhi, against several known and unknown defendants seeking to restrain them from misusing and
exploiting the name, likeness, image, photos, videos and/or infringing any other personality and
publicity rights of the Plaintiff No. 1; infringing the registered trademarks ‘INDIA TV’,
,
,
etc., of Plaintiff No. 2 along with the Plaintiff No. 2’s
copyright in its ‘AAJ KI BAAT: RAJAT SHARMA KE SAATH’ show footage and from claiming any
association and/or connection with the Plaintiff(s).
The captioned suit was listed for the first time on 18th December 2024 wherein the Hon'ble Court
was pleased to pass an ex-parte ad-interim Injunction Order inter alia restraining the Defendant
Nos. 1-8 from infringing the personality and publicity rights of the Plaintiff No. 1 and from
infringing the registered trademarks and the copyright of the Plaintiff No. 2.
In accordance with the Order of Injunction dated 18th December 2024, wherein the Court was
pleased to pass the following additional directions:
"VI. Defendant Nos. 10 and 11 are directed to issue necessary notifications/directions to all
telecom and internet service providers to block/suspend/the websites, telephone numbers, social
media accounts, channels, platforms, etc. that may subsequently be notified on affidavit by the
Plaintiffs to be infringing their exclusive rights, as identified during the course of the present suit,
that are found to be violating the rights of the Plaintiffs.”
The Plaintiffs have filed the attached Affidavit for additional links/URLs before the Hon'ble Court.
Further, a copy of the Order dated 18th December 2024 is attached herewith. The list of URLs for
takedown have been attached as an excel sheet for convenience - Annexure A (list for URL
takedown through directions of DOT, MEITY).
In view of the above, you are requested to strictly comply with the Order
dated 18th December 2024 passed by the Hon'ble Delhi High Court. Any violation or
non-compliance of the said Order by you shall compel the Plaintiffs to initiate
appropriate proceedings, including proceedings for wilful contempt and
disobedience of the directions passed by the Hon'ble Court.
For your reference, the next date of hearing in the matter is 16th September, 2025 before the Joint
Registrar and 22nd September, 2025 before Court.
Please feel free to contact us if you have any queries.
Regards,

Disha Sharma | Associate Partner | Saikrishna & Associates, 57 Jor Bagh, First Floor,
New Delhi, 110003, India | Tel: +91-11-40244360 | Handphone: +91-9899296222 |
Enrolment No: D/130/2017
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual
Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment
& Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent
Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege, not
being waived or lost by mistaken transmission or receipt. If you have received this mail in error,
please notify us at info@saikrishnaassociates.com immediately by reply email and destroy the
original - any use, disclosure or copying of this mail is unauthorised.

On Wed, Jul 30, 2025 at 4:51 PM Disha Sharma
<disha@saikrishnaassociates.com> wrote:

9/2/2025, 2:38 PM

<!-- page 5 -->

Re: CS(Comm) 1147/2024 titled "Rajat Sharma & Anr. v Tamara Do...

4 of 59

https://mail.mgovcloud.in/zm/?fromService=wp&wpVersion=b021d7...

Dear Sir,
This is further to our email dated 02 July 2025. Please find attached with this mail the
6th Affidavit for additional links/URLs dated 30 July 2025, being filed on behalf of the
Plaintiffs.
The link to the Suit documents and Affidavits notifying the additional links/ URLs, filed
previously, are accessible at the OneDrive link below:
Rajat Sharma & Anr. v. Tamara Doc & Ors; CS(COMM) 1147 of 2024
For your reference, the next date of hearing in the matter is 16th September, 2025 before the
Joint Registrar and 22nd September, 2025 before Court.
Please feel free to contact us if you have any queries.
Regards,
Disha

On Wed, Jul 2, 2025 at 2:20 PM Disha Sharma
<disha@saikrishnaassociates.com> wrote:
Dear Sir,
This is further to our email dated 27th June 2025. Please find attached with this mail
the Affidavit for additional links/URLs.
The link to the Suit documents and Affidavits notifying the additional links/ URLs, filed
previously, are accessible at the OneDrive link below:
Rajat Sharma & Anr. v. Tamara Doc & Ors; CS(COMM) 1147 of 2024
For your reference, the next date of hearing in the matter is 16th September, 2025 before the
Joint Registrar and 22nd September, 2025 before Court.
Please feel free to contact us if you have any queries.
Regards,
Disha

5th Affidavit Additional Links 02072025.pdf

Disha Sharma | Associate Partner | Saikrishna & Associates, 57 Jor Bagh, First
Floor, New Delhi, 110003, India | Tel: +91-11-40244360 | Handphone:
+91-9899296222 | Enrolment No: D/130/2017
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual
Property- 2019 & 2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media,
Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent
Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes
confidential information of S&A and may also be the subject of legal professional privilege,
not being waived or lost by mistaken transmission or receipt. If you have received this mail
in error, please notify us at info@saikrishnaassociates.com immediately by reply email and
destroy the original - any use, disclosure or copying of this mail is unauthorised.

On Fri, Jun 27, 2025 at 2:48 PM Disha Sharma
<disha@saikrishnaassociates.com> wrote:

9/2/2025, 2:38 PM

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(Ordinary Original Commercial Jurisdiction)
CS(Comm) No. 1147 of 2024
IN THE MATTER OF:
RAJAT SHARMA & ANR.
…..PLAINTIFFS
Versus
TAMARA DOC & ORS.
….DEFENDANTS
INDEX
PARTICULARS

S.
PAGE
NO.
NO
1. Affidavit of Mr. Mohit Kumar Hukumchand
dated 29th August 2025 with respect to
1-8
additional list of URLs that are engaged in
infringing the Plaintiff’s trademark and
copyright.
2. Annexure A: Additional list of URLs on
9
Facebook and Instagram.
3. Annexure B: Additional list of URLs/links on
10
the internet.
4. Evidence with respect to additional list of
11-39
URLs that are engaged in infringing the
Plaintiff’s trademark and copyright.
5. Affidavit of Service along with Proof of Service

Place: New Delhi
Date: 01.09.2025

Disha Sharma
(D/130/2017)
Saikrishna and Associates
Advocates for the Plaintiffs
57 Jor Bagh,
New Delhi – 110003

<!-- page 18 -->

1

<!-- page 19 -->

2

<!-- page 20 -->

3

<!-- page 21 -->

4

<!-- page 22 -->

5

<!-- page 23 -->

6

<!-- page 24 -->

7

<!-- page 25 -->

8

<!-- page 26 -->

9

<!-- page 27 -->

10

<!-- page 28 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
