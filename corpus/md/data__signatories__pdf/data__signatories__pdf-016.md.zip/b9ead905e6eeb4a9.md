---
doc_id: "b9ead905e6eeb4a9"
source_url: "https://master-dopt.digifootprint.gov.in/static/uploads/2025/08/3115d54555f8d0f7cb59218a0b798b6a.pdf"
ministry: "Department of Personnel and Training (DoPT)"
title: "Appointment by Promotion to the Andhra Pradesh cadre of IAS from othe Select List of 2023"
date: "2025-08-18"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "06e7972666ca9fc8"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART I, SECTION 2)
Government of India
Ministry of Personnel, Public Grievances and Pensions
Department of Personnel & Training
New Delhi, dated the 19% 06५७, 2025
NOTIFICATION
No. ...........In exercise of the powers conferred by Rule 8(1) of the Indian
Administrative Service (Recruitment) Rules, 1954 read with Regulation 9(1) of the
Indian Administrative Service (Appointment by Promotion) Regulations, 1955 and
Rule 3 of the Indian Administrative Service (Probation) Rules, 1954, the President is
pleased to appoint the following member of the State Civil Service of Andhra
Pradesh to the Indian Administrative Service against the vacancies determined by
Government of India under Regulation 5(1) of the said Regulations in consultation with
the State Government for the Select List of 2023, on probation until further orders
and to allocate him to the Andhra Pradesh Cadre, under Rule 5(1) of the Indian
Administrative Service (Cadre) Rules, 1954:-
Select List of 2023 (SCS)
(Prepared against vacancies arises between 01.01.2023 to 31.12.2023)
[St No.] Name of the officer (Shri/Smt.) | Date of Birth
IM. Venkateswarlu 20.05.1976
No. 14015/01/2024-AlIS.1-B
k
0७ --
(Sanjay Kumar Chaurasia)
Under Secretary to the Government of India
To
The Manager के
Government of India Press
Minto Road, New Delhi
Contd...2/

<!-- page 2 -->

न TE
No. 14015/01/2024-AIS.I-B New Delhi, dated the \3” august, 2025
dr The Chief Secretary, Government of Andhra Pradesh, Velagapudi - for
onward transmission to the officer concerned. It is further requested to
furnish proposal for fixation of seniority/year of allotment i.r.o the officers
concerned in accordance with prescribed proforma laid down under IAS
(Regulation Seniority Rules)
25 The Accountant General, Government of Andhra Pradesh, Velagapudi.
3. The Secretary, Union Public Service Commission, Dholpur House, New
Delhi.”
4. ६.0. & AS to the Government of India, New Delhi.
5: Joint Secretary (Training), DoPT, Old JNU Campus, New Delhi.
6. Diréctor, LBSNAA, Mussoorie.
(Sanjay ie Chaurasia)
Under Secretary to the Government of India
Internal Distribution:
1. DS(AIS)/US(AIS.II)/US(AIS.III)/US(EO-PR)/EO(CM)/US(AVD-1)
2. Hindi Section — with the request to translate and send on email-uss1@nic.in.
