---
doc_id: "b7f21dccefb3f6f1"
source_url: "https://www.darpg.gov.in/static/uploads/2025/11/670b625cc65952df7f41963775b83075.pdf"
ministry: "Department of Administrative Reforms and Public Grievances (DARPG)"
title: "Relevant Acts, Rules, Forms and other documents which are normally accessed by citizens"
date: "2025-05-14"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7195e3a92cbf463f"
---

<!-- page 1 -->

Updated as on 14.05.2025
MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES & PENSIONS
DEPARTMENT OF ADMINISTRATIVE REFORMS & PUBLIC GRIEVANCES
The particulars of its organization, functions and duties:
The Department of Administrative Reforms and Public Grievances (DAR&PG) is the nodal agency of
the Government of India for administrative reforms as well as redress of public grievances relating to
the States in general and grievances pertaining to Central Government agencies in particular. The
Department disseminates information on important activities of the Government relating to
administrative reforms and public grievance redressal through publications and documentation. The
Department also undertakes activities in the field of international exchange and cooperation to promote
public service reforms.
The powers and duties of its officers and employees
The DAR&PG is under the Ministry of Personnel, Public Grievances and Pensions and is headed by
Secretary. Presently, the Department has one Additional Secretary, two Joint Secretaries and
Divisional heads of Deputy Secretary/Director level for each division viz. Administration (Admin);
Administrative Reforms (AR); Administrative Reforms Commission (ARC); Documentation &
Dissemination (D&D); E-Governance (e-Gov); International Exchange & Cooperation (IE&C);
Organization & Methods (O&M); and Public Grievances (PG). The file is submitted through the
divisional heads to Joint Secretary/Additional Secretary to Secretary and finally to Minister of State
for Personnel, Public Grievances and Pensions for major policy decisions in the Department. The
DS/Director (Admin) is designated as Head of the Department (HoD) and Under Secretary
(Admin.II/General Administration) is also designated as Head of Office (HoO) and exercises financ ia l,
administrative powers as per laid down procedures and rules of Government of India.

OFFICERS OF THE DEPARTMENT
Shri V Srinivas, Secretary
Department of Administrative Reforms and Public Grievances,
Room No. 513, Fifth Floor, Sardar Patel Bhavan,
New Delhi - 110 001
Tel. No. 011- 23742133
Shri Puneet Yadav, Additional Secretary
Department of Administrative Reforms and Public Grievances,
Room No. 510 Fifth Floor, Sardar Patel Bhavan,
New Delhi - 110001
Tel.No.011-23741004
Ms. Sarita Chauhan, Joint Secretary
Department of Administrative Reforms and Public Grievances,
Room No.508 Fifth Floor, Sardar Patel Bhavan,
New Delhi – 110001
Tel.No.011-23360331
Ms. Jaya Dubey, Joint Secretary & CVO
Department of Administrative Reforms and Public Grievances,
Room No.507 Fifth Floor, Sardar Patel Bhavan,
New Delhi – 110001
Tel.No.011-23360208

<!-- page 2 -->

DIVISION-WISE OFFICERS AND ALLOCATION OF WORK
1)

ADMINISTRATION DIVISION
DS/Director


US (Admin.I/Estt)
o Section Officer (Admin.I/Estt)
o Section Officer (Cash/DDO)
o Assistant Director (Official Language)



US (Admin.II/GA)
o Section Officer (Admin.II/GA)

WORK ALLOCATION
(a) ADMIN.I/ESTABLISHMENT










All establishment matters of Group A, B &C (excluding MTS, Staff Car Driver, Despatch Rider)
officers and staff of the Department.
All vigilance matters of Group A,B&C (excluding MTS, Staff Car Driver, Despatch Rider) officers
and staff of the Department and Monthly/Quarterly Reports for Vigilance matter
Maintenance of Immovable Property Return of Group A, B, C officers/staff of the Department.
Deputing Group B and C officials for various Training Programmes.
Monitoring of implementation of Official Language through Hindi unit of DARPG.
Finalization and monitoring of Budget/RE of DARPG, Cash & Accounts including audit matters.
Medical Reimbursement.
GPF Advance.
Court Cases on establishment.

(b) ADMIN.II/GENERAL ADMINISTRATION













Coordinating/collating of inputs in respect of DARPG sought for by various Ministries/ Departments
on Cabinet Notes, Policy matters, etc.
Parliamentary Standing Committee - including all Parliament questions and matters raised under
Rule 377 in Lok Sabha and Rajya Sabha pertaining to DARPG.
Responsible for suo motu (proactive) disclosure under RTI Act in respect of CPIOs/Appellate
Authorities and also Nodal CPIO for the Department.
To make schedule and monitoring of Swachhta Action Plan in respect of DARPG.
Procurement, maintenance of office equipment and stationeries.
All establishment matters of Group C viz. MTS, Staff Car Driver, Despatch Rider officials of the
Department.
General Administration (LTC and Leave Encashment, Children Education Allowances, Office
maintenance, etc.).
Advances on HBA, Computer.
Coordinating/collating of inputs in respect of DARPG for Annual Report and Other Reports
Departmental Record Room.
All work related to Azadi Ka Amrit Mahotsav.
Any other subject allocated by the Secretary (AR&PG).

<!-- page 3 -->

2)

ADMINISTRATIVE REFORMS (AR) DIVISION
DS/Director


Under Secretary I



Under Secretary II
o Section Officer (AR I & II)

WORK ALLOCATED







3)

Civil Services Day
Prime Minister’s Award for Excellence in Public Administration
Case Studies on Good Governance
State Collaboration Initiative projects
Administrative Reforms Initiatives
National Centre for Good Governance (NCGG)
Any other subject allocated by the Secretary(AR&PG)

ADMINISTRATIVE REFORMS COMMISSION (ARC) DIVISION
DS/Director


Under Secretary
o Section Officer

WORK ALLOCATED








4)

Follow up action with the Nodal Ministries and the States regarding Institutional Mechanis ms
relating to the implementation of the accepted recommendations of the 2 nd ARC
Parliamentary matters / Standing Committee matters relating to the 2nd ARC
Implementation of e-Office Mission Mode Project (MMP) in Central Governme nt
Ministries/Departments
Release of Funds for Implementation of e-office Mission Mode Project(MMP) in Central
Government Ministries/Departments
Co-ordination in the Implementation of e-office in all the states of the North Eastern Region
Workshops/Conferences/webinars on implementation of e-office in Central Governme nt
Ministries/Departments
Monitoring of compliance of Guidelines for Indian Government Websites (GIGW) in Central
Government Ministries/Departments.
Any other subject allocated by the Secretary(AR&PG)

DOCUMENTATION AND DISSEMINATION (D&D) DIVISION
DS/Director


Under Secretary I



Under Secretary II
o Section Officer (D&D I & II)
o Assistant Editor
o Assistant Library & Information Officer

<!-- page 4 -->

WORK ALLOCATED







5)

Identification, documentation and dissemination of Best Practices.
Publication of Departmental Magazine in e-Book format “Minimum Government – Maximum
Governance (MGMG).
Publication of Coffee Table book on Best Practices.
Production of documentary films on best practices.
Grant of financial assistance to the State Governments for professional documentation of Best
Practices.
Organizing Regional Conference on implementation of Good Governance practice.
Any other subject allocated by the Secretary (AR&PG).

e-GOVERNANCE (e-Gov) DIVISION
DS/Director


Under Secretary I



Under Secretary II
o Section Officer (e-Gov I & II)

WORK ALLOCATED
Coordinating and supporting implementation of National e-Governance Plan through:
 National Conference on e-Governance.
 National awards for e-Governance.
 Matters relating to e-Governance Training Plan
 National e-Governance Services Delivery Assessment (NeSDA)
 Case studies on Awarded e-Governance Projects.
 Internet/DARPG website/e-mail guidelines and related issues/ Cyber Security Policy/IPv6 policy
 Vision India@2047
6)

INTERNATIONAL EXCHANGE & COOPERATION (IE&C) DIVISION
DS/Director


Under Secretary I



Under Secretary II
o Section Officer (IE&C I & II)

WORK ALLOCATED





International exchange and cooperation in the field of Civil Services, Personnel Management, Public
Administration.
Interaction with International Institute of Administrative Sciences, Brussels, Belgium.
UNDP Project: Strengthening Public Administration and Governance.
Any other subject allocated by the Secretary (AR&PG).

<!-- page 5 -->

7)

ORGANIZATION & METHOD (O&M) DIVISION
DS/Director


Under Secretary
o Section Officer

WORK ALLOCATED





8)

Formulation and implementation of common office procedures
Publication and updating of the CSMOP and implementation of its provisions
Aiding and advising on O&M aspects
Allocation of fund for modernization of the Government offices
Any other subject allocated by the Secretary (AR&PG)

PUBLIC GRIEVANCES (PG) DIVISION
DS/Director


Under Secretary I



Under Secretary II
o Section Officer (PG I & II)



Under Secretary III



Under Secretary IV
o Section Officer (PG III &IV)

WORK ALLOCATED












Activities related to updation/review of Citizen’s Charter of all Ministries/Departments of Govt. of
India and uploading of the same onwww.goicharters.nic.in.
Work relating to Centralized Public Grievance Redress and Monitoring (CPGRAM) as developed in
the Division with technical support from NIC athttp://pgportal.gov.in
Training of officers in all Ministries/Departments/Subordinate organisations of Govt. of India on
CPGRAMS.
Monitoring and Review of pendency in redress of grievances in all Central Ministries/Departme nts
through review meetings.
Formulation of guidelines/instructions to improve redress mechanism in GOI.
Reforms to improve online CPGRMS in Central Ministries/Departments and in State Governments
as per their willingness.
Strengthening and Capacity Building of State Administrative Training Institutes for imparting
training in Quality Management System for improving public Service delivery (SEVOTTAM).
OrganizingworkshopsonreformsinpublicservicedeliveryforCentralMinistries/Departments.
One Nation-one Portal
Feedback Call Centre
Any other subject allotted by the Secretary (AR&PG).

<!-- page 6 -->

(i)

The procedure followed in the decision-making process, including channels of supervision and
accountability;
(a) ORGANISATION CHART
(b) CHANNEL OF SUBMISSION AND LEVEL OF FINAL DISPOSAL OF CASES IN RESPECT
OF COMMON ITEMS OF WORK HANDLED BY DEPARTMENT OF ADMINISTRATIVE
REFORMS AND PUBLIC GRIEVANCES OF THE MINISTRY OF PERSONNEL, PUBLIC
GRIEVANCES ANDPENSIONS.
Sl.
No.
1.

Types of Cases
Parliamentary Matters
(i) Replies to Starred Questions
(ii) Replies to Un-starred Questions and
Assurances
(iii) Final replies to recommendations of
Parliamentary Committees
(iv) Final replies to matters raised under Rule 377
in Lok Sabha and Special Mention made in
Rajya Sabha/ Parliament Assurances
(v) Action taken note on the recommendations of
Parliamentary Committee
(vi) Furnishing of replies to Questionnaire and
other references received from Parliamentary
Committee
(vii) Furnishing Input on Parliament question to
other Ministries
(viii) Miscellaneous Parliament Matters

Channel of submission

Level of final
disposal

DS/DirJS/ AS Secy

MOS (PP)

USDS/DirJS/AS

MOS(PP)

DS/DirJS/ASSecy

MOS(PP)

USDS/DirJS/AS/
Secy

MOS(PP)

USDS/DirJS/AS

Secretary

USDS/Dir

JS

USDS/Director
DS/ DirJS
ASSecy

JS

2.

Cabinet Notes

3.

Finalizing Scheme guidelines

USDS/ DirJS/AS

Secretary

4.

Annual Budget

DS/DirJS/AS

Secretary

5.

Selection/ appointment of Agencies / consultants

USDS/ DirJS/AS

Secretary

6.

Para-wise comments for the cases before
CAT/High Court/Supre me Court

US DS/ Director
JS/AS

Secretary

Output Outcome Framework
Receipts received from other Ministries/
Departments/ external agencies for seeking
comments/input etc.
Replies to audit paras
Website updations

US DS/Dir

JS

USDS/ Dir

JS/AS

USDS/ Dir
USDS/ Dir

JS
JS

7.
8.
9.
10.
(ii)

MOS(PP)

The norms set by it for the discharge of its functions:
Any grievance received from the general public shall be acknowledged within three working days of
receipt of the grievance petition.

<!-- page 7 -->

(iii)

The rules, regulations, instructions, manuals and records, held by it or under its control or
used by its employees for discharging its functions:
LIST OF REFERENCE BOOKS
1. Part I – General Rules
2. Part II- T.A. Rules
3. Part III- Central Civil Services (Leave)Rules
4. Part IV- Dearness Allowance, Dearness Relief and Ex Gratia to CPF Beneficiaries
5. Part V-HRA and CCA.
6. Swamy’s Pension Compilation incorporating CCS (Pension)Rules
7. Swamy’s Compilation of CCS (Commutation of Pension)Rules
8. Swamy’s CCS (Extraordinary Pension)Rules
9. Swamy’s Compilation on Central Government Employees’ Group Insurance Scheme
10. Swamy’s Compilation of Staff Car Rules
11. Swamy’s Compilation of Medical Attendance Rules
12. Swamy’s Compilation of CCS (CCA)Rules
13. Swamy’s Compilation of (Conduct) Rules
14. Swamy’s Compilation of General Provident Fund Rules
15. Swamy’s Compilation of Leave Travel Concession Rules
16. Swamy’s Compilation of Children’s Educational Assistance
17. Swamy’s Compilation of General Financial Rules
18. Swamy’s Compilation of Delegation of Financial Powers Rules
19. Swamy’s Compilation of House Building Advance Rules
20. Swamy’s Compilation on Suspension and Reinstatement
21. Swamy’s Compilation of Overtime Allowance Rules
22. Swamy’s CCS (Temporary Service) Rules,1965
23. Swamy’s Compilation of New Pension Scheme
24. Central Secretariat Manual of Office Procedures
25. Central Secretariat e-Manual of Office Procedures.

(iv)

A statement of the categories of documents that are held by it or under its control:
(a) ADMINISTRATION AND COORDINATION
1. Service Book and personal files of all the employees.
2. Files relating to recruitment of Deputation cases.
3. ACRs of all employees below the rank of Under Secretary
4. Property documents of employees who have taken House Building Advance.
5. File relating to Disciplinary Cases.
6. Files relating to Medical Claims made by employees.
7. Files relating to all advances taken by the employees.
8. Files relating to purchase of furniture/ fixtures, stationery items, general office items,
electronic, computer ACs etc.
9. Files relating to Annual Maintenance Contract.
10. Files relating to payment of telephone bills of office and residential telephone of officers who
have been provided office telephones
11. Files relating to General Administration/Coordination/RTI cases/Parliamentary matters
12. Minutes of all the meetings.
(b) O&M DIVISION
1. Central Secretariat Manual of Office Procedure
2. Records Retention Schedule for Records Common to all Departments
3. Records Management in Government.
4. Guidelines for the improvement of the quality of services rendered through the telephone in

<!-- page 8 -->

public offices
5. Policy Guidelines for Website Development, Hosting and Maintenance.
6. Guidelines for Plan Scheme on Modernization of Government Offices.
(c) INTERNATIONAL EXCHANGE & COOPERATION DIVISION
1. Files relating to international exchange and cooperation in the field of Civil Service, Personnel
Management and Public Administration.
2. Files relating to International Institute of Administrative Sciences, Brussels, Belgium.
3. Files relating to Commonwealth Association for Public Administration and Management
(CAPAM), Toronto, Canada
4. Files relating to CAPAM International Innovations Awards Programme in India.
5. Files relating to CAPAM International Innovations Cascading Programme in India.
6. Files relating to MoU between India and Malaysia in the field of Civil Service, Personnel
Management and Public Administration and follow-up action.
7. Files relating to MoU between India and China in the field of Civil Service, Personnel
Management and Public Administration.
8. Files relating to management studies/ Impact studies related to administrative reforms, O&M
aspects etc. in respect of Government organizations
9. Files relates to MoU with UNDP in the field of strengthening Public Administration and
Governance.
(d) D&D DIVISION
1. Files pertaining to grant of financial assistance to State Governments/U.T. Administrations for
professional documentation of Best Practices.
2. Files pertaining to organizing series of best practices and presentation of Best Practices.
3. Files pertaining to quarterly journal “Management in Government” (MIG), monthly newsletter
“Civil Services News” (CSN).
4. Files pertaining to documentation and dissemination of best practices by production of
documentary films.
5. Files pertaining to Research & Evaluation study.
6. Files pertaining to correspondence with persons contributing articles for publication in MIG.
7. Files pertaining to selection of articles for publication in MIG.
8. Files pertaining to collection of material for CSN.
9. Files pertaining to payment of honorarium to contributors of articles.
10. Files pertaining to matters concerning library.
11. Files pertaining to selection of Printers for MIG and CSN
12. Files pertaining to organization of Regional Conferences.
13. Files pertaining to Government Knowledge Centre(GKC)
(e) ARC & AR DIVISIONS
1. One copy each of the 20 reports submitted by the 1 st Administrative Reforms Commiss io n
(1966-1970) and 15 reports submitted by the 2ndAdministrative Reforms Commission. The 15
reports of 2ndARC are listed below.
S. No. – Report – Date of presentation to Government.
2. Right to Information: Master Key to Good Governance09.06.2006
3. Unlocking human capital: Entitlements and Governance – a Case Study31.07.2006
4. Crisis Management: From Despair to Hope31.10.2006
5. Public Order: Justice for each … Peace for all26.06.2007
6. Local Governance27.11.2007
7. Capacity Building for Conflict Resolution – Friction to Fusion17.03.2008
8. Combating Terrorism17.09.2008
9. Social Capital – A Shared Destiny08.10.2008
10. Refurbishing of Personnel Administration – Scaling New Heights27.11.2008

<!-- page 9 -->

11. Promoting e-Governance – The Smart Way Forward20.01.2009
12. Citizen Centric Administration – The Heart of Governance30.03.2009
13. Organizational structure of Government of India19.05.2009
14. Strengthening Financial Management System 26.05.2009
15. State and District Administration29.05.2009
(f) E-GOVERNANCE DIVISION
1. Files relating to implementation of e-Office Mission Mode Project.
2. Files relating to National Conference one-Governance
3. Files relating to National Awards one-Governance.
4. Files relating to Implementation of Master e-Governance Training Plan.
5. Files relating to 11th Report of Second ARC.
(g) PG DIVISION
1. Compilation of guidelines for redress of Public Grievance-2010 that includes guidelines on
Citizens Charter and Information Facilitation Counters.
2. Guidelines for Sevottam Compliance-June2010.
3. Guidelines for Sevottam Compliance-September2011.
4. Our Sevottam Journey-September2011.
5. Service Quality Manual-Procedure as per IS 15700:2005.
6. Sevottam: A continuing journey-write- up 2014 The following are available in digitized form
on website.
7. Citizens Charter of the Department of Administrative Reforms and Public Grievances.
8. Files on policy formulation relating to Citizens‟ charters, IFCs, Public Grievance Redress.
9. Files relating to publication of advertisement on nodal officers for citizens‟ charters, Directors
of Public Grievances and contact officers for IFCs.
10. Monitoring and Review meetings records.
(v)

The particulars of any arrangement that exists for consultation with, or representation by the
member of the public in relation to the formulation of its policy or implementation thereof:
The Department’s website http://darpg.nic.in/ acts as information tool for the general public and thus
facilitates in the implementation of the policies. The Department organizes meetings, seminars and
workshops on Best Practices chaired by Cabinet Secretary where besides state Governments even
NGOs can share/give presentation on innovative ideas /projects. Its purpose is to share the
ideas/innovation and successful experience with rest of the states. There exists a system of consultatio n
with NGOs, Citizens groups, RWAs and members of public while formulating policy relating to
Public Grievances and Citizen’s charters.

(vi)

A statement of the boards, councils, committees and other bodies consisting of two or more
persons constituted as its part or for the purpose of its advice, and as to whether meetings of
those boards, councils, committees and other bodies are open to the public, or the minutes of
such meetings are accessible for public:
1. The First Administrative Reforms Commission (ARC) as a Commission of Inquiry was set up in
January, 1966 under the chairmanship of Shri Morarji R Desai and later on Shri K Hunmantha iya
became its chairman. The Commission submitted 20 reports from January 1966 to June1970
2. The Second Administrative Reforms Commission (ARC) was constituted on 31.08.2005, as a
Commission of Inquiry, under the Chairmanship of Shri Veerappa Moily. The Commiss io n
submitted 15 reports at various stages. Details about ARC is available at https://darpg.gov.in/abo utarc

<!-- page 10 -->

3. Department of Official Language Implementation Committee is headed by Joint Secretary
(Admn.). Not open for public.
4. Screening Committee to examine and clear the proposals received from the Ministries/Departme nts
for allocations of funds under the Plan Scheme of the Department of AR&PG. Modernization of
Government Offices. The Committee is chaired by the Additional Secretary of this
Department and has members drawn from Integrated Finance Division of this Department,
Central Public Works Department, National Informatics Centre and Planning Commission. Its
meetings are not open for public.
5. Evaluation Committee for soliciting and evaluating the books written originally in Hindi on the
subjects of Public Administration and Management Studies is headed by AS (AR&PG).
6. Screening Committee for the Scheme of Administrative Reforms is chaired by the AS (AR&PG).
This Apex Committee is for the purpose. (i) Pilot projects on Administrative Reforms (ii) setting
up of NISG and (iii) World Bank Project on Capacity Building for Good Governance.
7. Internal Complaints Committee for Prevention of sexual harassment of working women in the
workplace. [https://darpg.gov.in/node/7184]
8. Programme Implementation Committee (PIC) chaired by AS (AR&PG) for implementation of the
Capacity Building Poverty Reduction (CBPR) Programme under the DFID Project funded by the
UK Government.
a) Standing Committee in respect of grievances of officers of the level of Joint Secretary and
above.
b) Standing Committee of Secretaries for Public Grievance redress.
c) Core Group on citizen charters and facilitation counters. (Neither of these Committees are open
to public nor the proceedings of the Committees are of any relevance to general public.) (Some
of the above Committees has as its members retired Professors and retired Government
servants.)
d) Steering Committee to oversee production and telecast of documentary series for creating
awareness and dissemination of information on e-governance is headed by AS (AR&PG)
(vii)

A directory of its officers and employees [CLICK HERE]

(viii)

The monthly remuneration received by each of its officers and employees, including the system of
compensation as provided in its regulations. [CLICK HERE]

(ix)

Budget allocated to each of its agency, indicating the particulars of all plans, propose d
expenditures and reports on disbursement made:
Department of Administrative Reforms and Public Grievances
Statement showing B.E., final allocation and Expenditure
under 'Scheme' 'Capital Outlay' and 'NCGG'
Amount in Lakh
Non-Scheme
Object Heads

B.E.

Scheme
OAE(Scheme)
42.01.05-Rewards
42.01.11-D.T.E.
42.01.12-F.T.E.
42.01.13-Office Expenses
42.01.19-Digital Equipment

0.00
1.00
25.00
150.00
1400.00
20.00

0.00
1.00
25.00
25.00
650.00
20.00

0.00
0.00
9.89
0.00
304.24
18.65

126.00

144.04

139.23

746.00

846.00

556.32

42.01.26-Advertising & Pub.
42.01.28-Professional
Services

2024-25
Final
Grant

Exp.

Department of Administrative Reforms and Public
Grievances
Statement showing B.E., final allocation and
Expenditure under 'Non-Scheme'
Amount in thousand
Non-Scheme
Object Heads

B.E.

Salaries
Wages
OTA
Rewards
Medical
Allowances
Leave Travel Expenses
Training Expenses

69100
0
0
900
2000
49400
1700
600

2024-25
Final
Exp.
Grant
74500
0
0
900
2000
62200
1700
600

70137
0
0
333
1543
57037
1627
364

<!-- page 11 -->

42.01.31-GIA General
1700.00
1700.00
1693.16
42.01.40-Awards and Prizes
450.00
201.00
120.00
42.01.49-Other Revenue
20.00
20.00
0.00
Exp.
Total (Scheme)
4638.00
3632.04
2841.49
42.03 Scheme- Comprehensive System for Redressal of
Public Grievances Component
42.03.13-O.E.
0.00
36.00
12.59
42.03.19-Digital Equipment
0.00
50.00
0.00
42.03.26-Advertising & Pub.
200.00
300.00
276.91
42.03.28-Professional
2762.00
2157.96
1038.93
Services
42.03.31-GIA General
300.00
400.00
276.17
42.03.49-Other Revenue
50.00
14.00
13.62
Exp.
Total
3362.00
2907.96
1618.22
PG Div. (Capital OUT LAY)
06.01-71
-Information,
Computer,
0.00
66.00
0.00
Telecommunications (ICT)
equipment
G.Total of PG Component
3362.00
2973.96
1618.22
Total
of
Scheme
8000.00
6606.00
4459.71
(Revenue+Capital)
31.28- Capital Outlay on Other Administrative Services
31.28.51-Motor Vehicles
9.00
8.80
8.80
31.28.52-Machinery
&
40.00
40.00
38.51
Equipment
31.28.74-Furnitures
and
45.00
25.00
19.72
Firxtures
31.26.71-Information,
Computer,
160.00
160.00
141.79
Telecommunications (ICT)
Equipment
Total (Capital Outlay)
254.00
233.80
208.82
Setting up of National Centre for Good Governance-16.02
(2070)
16.02.31 Grant -in -aid520.00
1450.00
1450.00
General
16.02.35- Grant for creation
0.00
0.00
0.00
of Capital assets
16.02.36
Grant-in-aid887.00
450.00
450.00
Salaries
Total (NCGG)
1407.00
1900.00
1900.00

Domestic Travel
Expenses
3000
Foreign Travel
Expenses
3700
Office Expenses
25000
Rent Rate & Taxes
100000
Printing & Publications
2500
Rent for others
10000
O.A.E./NP
0
Digital Equipment (I.T.)
1000
Fuel and Lubricants
1300
Minor Civil & Elec.
Works
500
Professional Service
2500
Repair and Maintenance
2500
Contributions
500
Bank and Agency
Charges
300
Other Revenue Exp.
500
Other Charges
0
S.A.P. (OE)
1000
Total
278000

3000

2775

3700
1708
30000 29374
250000 239259
2500
864
10000
3504
0
0
1000
966
1300
1011
500
2500
2500
500

17
0
2471
322

300
0
500
407
0
0
1000
954
451200 414673

(x)

The manner of execution of subsidy programmes, including the amounts allocated and the
details of beneficiaries of such programmes:
Department does not administer any programme involving subsidy.

(xi)

Particulars of recipients of concessions, permits or authorization granted by it:
-NIL-

<!-- page 12 -->

(xii)

Details in respect of information, available to or held by it, reduced in an electronic form: May
visit Website of DARPG– http://darpg.gov.in/where so many reports/ manuals/ documents/ films on
best practices etc are available.

(xiii)

The particulars of facilities available to citizens for obtaining information, including the working
hours of a library or reading room, if maintained for public use:
Information may be obtained from website of DARPG –http://darpg.gov.in/ The Department has also
fixed a time on every Wednesday 10.00 A.M. to 1.00 P.M. where the Deputy Secretary (Public
Grievances), Room No.517, Fifth Floor, Sardar Patel Bhavan, New Delhi, redresses the grievance of
the public in person.

(xiv)

Names, designations and other particulars of the Public Information Officers [CLIC KHERE]

(xv)

Tour undertaken by Officials of DARPG
(a) Foreign visits/training programmes conducted by the Department from January 2013 till date
[Details]
(b) Domestic visits/training programmes conducted by the Department from January 2013 till date
[Details]

(xvi)

Delegation of Financial Power Rules (DFPR). [CLIC KHERE]

(xvii) Detailed Channel of Submission. [CLIC KHERE]
