---
doc_id: "b63fddb14d1fba3e"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/08/63aac712d6f3b891de1fc5c102cbc93a.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification for operation of the Patents (Amendment) Act, 2002, dated May 20, 2003 (SO 561(E))"
date: "2003-05-20"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5c8573c76782f070"
---

<!-- page 1 -->

~ .lo ii- ~

- 33004/99

REGD.
REGD. NO.
NO. D.
D. L.-33004/99
L.-33004/99

..

'

:lll~cl ciii
~-~Qil
i15I4M
~he
@ke <Ga':tette
Gazette of ~ndia
Jndia
~
31418414uT

EXTRAORDINARY
EXTRAORDINARY
'WTU~3-~-W16(ii)
4TI1-@ug
3-3q-@ug (ii)

PART
PART II-Scctiou
II-Section ~ub-scctiou
3-Sub-section (li)
(ii)
'll1fl.r,,rn
Q<fi l~lil
yif4arr ll
g ya.if@ta
PURI
,ISBED BY AU'IDORITY
PUBLISHED
AUTHORITY

li.
i. 454]
454]

~
~ . Haan,
q11wm, ~
1925
30, 1925
2003/a9I1I 30,
20, 2003~
4# 20,
"fee«fl,

No.
No. 4541
454]

NEW
AJSAKHA 30,
NEW DELf-fi,
DELHI, TUESDAY,
TUESDAY, MAY
MAY 20,
20, 2003N
2003/VAISAKHA
30, 1925
1925
<Tiflrr,;q
~ ~
qifu 3fR
3fir air
ialiq
( afm)flr.i;,ftf;i
;;flt~ftrqpi)
shafta, itfasitdada
fut )

~

31f44HT
~
fu'sfl, 20
efeel,
20 ~, 200:t
2003-

.t.
).- gee (ti:thl1l1)
q;r
•.:m. s61(1
s61(3t).-m
~ 1
41 38) ~
«i
1 ~
(ivia1) ~l?JPl<t,i,
ff444, 2002 (2002 <fil
1

u-qi (2) a
u<d ifibdi
r udm
va ~.
§T, g
4<es« vdqgxi
feHi@
B'tl-~
'&> dgd
~~
~1R1nli <ITT
~ ffl
~ '{'lxcf>I'<
~d'iGl~I ~
20 ~'
~ ~
~
4, 2003 ml'
41 'iITf
a fen
wu ~
Ai f.Mt
fm4a ~
weal � ~
fora 'Q'x
ye Bm
ts srfefmaqa
a ~
Pt..,
R:t f<!I a sqdu
~~
1fnl"IT. "if'@':3nat si 'at,
f+-afemfaa
Md:-

t

m

1.
1.
��

2.
2.
3.
3
4.
4.
5.
5.
6.
6.
7.
7.
8.
8.
9.
9.
10.
10.
11.
11 .
12
12..

w

w

w

( s TT),
) 3llx
() , (TT),
( 4) ,
(1 ) , ("ET),
~
B'tl-m
uni 33 a m
is (<Ii)
(+) sq
is (q;
(@ ~)
ale (<fi
4) , m
is (~).
(~),
ST) W
;Jq- m
(q;)
(). ('ti),
(9), ('iJ),
() , ~
an (iJJ)
(i) -qcj"
qi ('(si)
u-is
(#) 3llx
a« (TT)
() II
8112T 4:
~4;
1INI
�
~5;
4«I 5:
~6;
4«T 6 :
~7;
7RT 7 :
~8;
E4RT 8 �:
~9;
E4TNT 9:�
1

1

~10;
4TNT 10:�
~11·
ye7 11:�
'
~12;
RI 12;
~13;
qg 13:
~14·
«7 14:'�
13.
13. ~
RT 15;
15 :
14.
14 . l!l'RT
4RI 16;
16 ;
,
,
01/2003
l1394,
39fol/2o03
p

(I)
(1)

•

<!-- page 2 -->

22

THEGAZETIE-OFINDIA:ElCTRAORDINARY
THE GAZETTE OF INDIA : EXTRAORDINARY

15.
15.
16.
16.
17.
17.
18
18..
19.
19.
20.
20.
21.
21.
22.
22.
23.
23.
24.
24.
25.
25.
26
26..
27.
28.
28.
29
29..
30..
30
31.
31.
32
32..
33.
34
34..
35.
35.
36.
36.
37.
37.
38.
38.
39.
39.
40
40..
1.
4
41.
42.
43
43..
44.
44.
45.
45 .
46
46..
47.
47.
48.
4~
49.
50.
50 .
51..
51
52..
52
53.
54.
54.

[PA«r n-See. 3(ii)]
3(ii)]
[Pa.RTJ1~llC.

-rr,--

l:lRT
aRi 17;
17.

mx118;
4RI 18;
mx119;
u«i 19;
1:1'
RT 20;
a«i
<ITTT
qRi 21;
21;
l:l'RT
qRI 22;
22;
mTI23;
uni 23;
<Im
4RT 24;
24;
1:1'
RT 25;
RI
25;
4RI 26,
l:TRT26;
1:1'RT
4RT 27;
27,
mTI
RT 28;
l:l'RT
4RI 29;
1:1'RT
qRI 30;
l:lRT
4Rm 31;
1:1'
RT 32:
q«1
32:
1:1'
RT 33;
9Ri
33:
mxr34;
9RI 34;
mxr
qr«i 36
36 <ITT
im
is (<if);
(@);
mxr37;
4xi 37,
<!RT
« 38;
38;
~39;
qRI 39,
tm140;
aRi 40;
EITTT41;
9RI 41;
l:ITTT
4RI 42;
42;
l:ITTT
q«I 43;
43;
<!RT
9RI 44
44;;
mx1
4RI 45;
EITTT
4RI 46;
46;
l:1'RT48;
«i 48,
mxJ
4RI 49;
49,
<Im
4RI 50;
~
RI 51·
51;
<Im
RI 52;
um
1«I 53;
4RT 54;
54;
1:1'RT
4RI 55;
1:1'RT
55;
4RI 56;
56,
l:lRT
1:1'RT
4I 57;
57,
um
4RI 58;
58;
.,

I �

<!-- page 3 -->

I
i

I
I

- r

��������

55.
56.
56.
56.

57.
57.
58
58..
59
59..
60.
60.
61.
61 .
62.
62.

-

qm
«T 59;
59;
-- qm60;
qRI 60;
qm61;
4«T 61 ;
t1R1
9«1 62;
62;
qm
63;
4«T 63;
qm
xi 64
64 'ij;
a is (<1>),
(), (~).
(), (Tf)
(1) ~
ii« <~);
();

m

qm
qi 65;
65; ~
3n«
t1R1
8r«r 66;
66 ;

II
,!
��

/ "

[i. 12n/20031 2/7/2003-4i
ii u"su]
[,i.
'TT'TTll;lll,li\J

'·"

'

91.
Q'.. ~
•-~
1. ',
iwH<, dghaala

MINISTRY OF
OF COMMERCE
COMMERCE AND
AND INDUSTRY
INDUSTRY
MINISlRY
(Department
(Department oflntlustrial
of Industrial Policy
Policy and
andPromotion)
Promotion)
N01IFICAilON
NOTIFICATION
New
New Delhi.
Delhi, the 20th
20th
M May,
ay,2003

if"'s.
..Q.56t(E),_:;,l\'
.0.
561(@) .-Ii exercise of the powers conferred by sub-section (2) of
section _i
1 _,ot
of the P-atents
Patents (Amendment)(Amendment) Act, 2002 (38 of 2002), the Centraf
Central
th
Government hereby appoints the 20
day of May,
20
May, 2003 as the date on which
the following provisions of .the said Act shall come into force, namely:-

.

1. sub-clauses
sub-clauses (ab) and (ac) of clause (a).
(a), clauses (b), (c), (d), (e), (f), (g), (h)
and sub-clauses (A) and (C) of clause (i) of section 3;
2. section 4;
4:
3.
3. section 5;
44.. section 6;
5. section 7;
6.
6, section 8:
7. sectio11.9:
section9;
8. section 110;
O:
9. section 11:
11;
10.section 12;
;
12;
11.
section 13;
11.section
'
12.section 14;
13.section 15;
14.section 16;
15.
section 17;
15.section
16.section 18;
17.
section 19;
17.section
18.section
20;
18.
section 20:
19.sectlon
19.section 21;
20.
section 22;
20.section
22:
21
. section 23;
21.section
22.
section 24;
22.section
23.section
23. section 25;
26;
24. ser;:tion
- section
•µ 27;
25_
section
25.section

,.,

<!-- page 4 -->

44

THE GAZIITI1EOF
INDIA : EXTRAORDINARY
GAZETTE OF INDIA:
iHE
EXTRAORDINARY

Pwsru-swc.300j
(PAATil-$,,,c,
3Qi)! .:•
II

26.secti
28;
26.
section
on 28;
27.section 29;
29;
27.section
28.section
30 ;
section 30;
28.
31 ;
29.sect
29.
section
ion 31;
30.
section
30.sect
32;
ion 32;
31.section 33;
33:
31.section
32.
section
32.sect
34;
ion 34;
( b ) of
33.clause (b)
33.clause
of section
36 ;
section 36;
;
34.secti
37
34. section
on 37;
35.secti
38 ;
35.
section
on 38;
36.section 39;
39;
36.section
37.section 40;
40 ;
37.section
38.
section
38.sect
41 ;
ion 41;
39.section
39.section 42;
42;
40.sect
43;
40.
section
ion 43;
41.
section
41.sect
44;
ion 44;
42.section
42.section 45;
45;
43.section
43. section 46;
46;
44.section 48;
48;
44.section
49;
45.section 49;
45.section
50 ;
46.section 50;
46.section
447.sect
7. section
51;
ion 51;
48.
section
48.sect
52;
ion 52;
49.
section
49.sect
53;
ion 53;
50.secti
50.
section
on 54;
54 ;
51.secti
55;
51.
section
on 55;
52.
section
56;
52.sect
ion 56;
53.
section 57;
53. section
57;
54.section
54.section 58;
58;
55.
55. section
59;
section 59;
56.section 60;
60 ;
56.section
57.secti
61 ;
57.
section
on 61;
58.
section 62;
58. section
62;
59.
59. section
63;
section 63;
( a ) , (b),
( b ) , (c)
( e ) of
( c ) and
60.clauses (a),
60.clauses
and (e)
section 64;
of section
64 ;
65 ; and
61.secti
61.
section
on 65;
and
62.sect
66.
62.
section
ion 66.

12/7/2003-PP&C]
[No, 12/712003-PP&q
[No.

.,

A.
A. E.
E . AHMAD,
AHMAD, Jt
JL Secy
Secy..

Delhi-1 10064
10064
Mayapuri, Now
New Delhl-1
India .Pr~s.
Press, Ring
Road, Maycp~
Ring Roid,
of India
Printed by
by 1he
Govt. of
Manager, Govt
the Manager,
P'l'lnled
ot' Publi<:alion-8,
Controller ot'
Publications, o~thi-I10054
Published by
and PuMitbed
Delhi-l10054..
the CootroUer
hy the
.and

.",
