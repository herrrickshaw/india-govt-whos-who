---
doc_id: "b8deeb9cf53a866d"
source_url: "https://mohua.gov.in/static/uploads/2025/12/a7f5ca47e8437b7eec86efe2cee0f41a.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Municipal Licences"
date: "2016-11-14"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea53c616d917a4d6"
---

<!-- page 1 -->

Chapter XXXVIII
Municipal Licences
Premises not
to be used
for nonresidential
purpose
without
municipal
licence.

369. (1) Except as hereinafter provided in this Act, no person shall use, or permit
to be used, any premises for any of the non-residential purposes
mentioned in the Schedule* without or otherwise than in conformity
with the terms of a licence granted by the Chief Municipal Officer or
the Wards Committee under sub-section (6) of section 30, as the case
may be, so as not to contravene the provisions of sub-section (2) of
this section :
Provided+ that no such licence shall be given in respect of any
non-residential use of a premises, if such use is otherwise than in
conformity with the provisions of this Act, or any other law for the time
being in force, or the rules or the regulations or the orders made
thereunder :
Provided further that except in cases which come under the
provisions of sub-section (2) of this section or section 371 or section
373, the power to issue such licence within its jurisdiction may be
exercised by the Wards Committee, subject to such conditions, and in
such manner, as may be determined by regulations.
(2) In the case of a non-residential use of a premises for a purpose for
which a licence or permission is required from the State Government or
any statutory body under any law for the time being in force, no licence
under this section shall be given until the licence or the permission under
the said law has been produced before the Chief Municipal Officer,
and duly authenticated copies thereof have been submitted to him :
Provided that in the case where the production of a licence
under this Act is a pre-condition for the grant of a licence under any

*

Each State Government may amend the list in the Schedule as per its requirements.

+

Each State Government may make specific provisions to suit its local conditions.
224

<!-- page 2 -->

other law for the time being in force, the Chief Municipal Officer may
grant a provisional licence, which shall be authenticated to be final only
upon the production of a licence or permission under the said law :
Provided further that such provisional licence shall have validity
only for the purpose of fulfilling the preconditions of the grant of a licence
under any other law as aforesaid.
(3) In specifying the terms of a licence granted under this section, the
Chief Municipal Officer may require the licensee to take all or any
of such measures as he may deem fit to guard against danger to
life, health or property or for the abatement of nuisance of any
kind.
(4) The Municipality shall, by regulations, determine the fees to be
paid in respect of a licence granted under sub-section (1), and may
specify different fees for different categories of non-residential uses
in different areas within the municipal area :
Provided that no such fees shall exceed rupees two thousand
and five hundred in any case.
(5) The Municipality may, by regulations, determine (a) as to when the initial licence is to be taken out and the
procedure of annual renewal thereof, and
(b) the matters connected with the display of licence,
inspection of premises, power of inspectors, and such
other matters as may be deemed necessary.
Registers to 370. The Chief Municipal Officer shall maintain in such Form, and in such
be maintained.

manner, as may be prescribed, two separate registers of which -

(a) one shall contain premiseswise information of non-residential
uses, indicating the unique premises number, if any, assigned
under this Act, and
(b) the other shall contain such information, on the basis of different
non-residential user groups for factories, warehouses, medical
225

<!-- page 3 -->

institutions, educational institutions, and such other uses, as may
be provided by regulations.
Municipal
licence for
private
markets.

371. (1) The Chief Municipal Officer may, with the prior approval of the
Municipality, grant to any person a licence to establish or keep
open a private market on payment of such fees as may be determined
by the Municipality by regulations, and may specify such conditions
consistent with this Act as he may deem fit.
(2) When the Chief Municipal Officer refuses to grant any licence, he
shall record a brief statement of the reasons for such refusal.
(3) The Chief Municipal Officer may, with the prior approval of the
Municipality and for reasons to be recorded in writing, by order,
suspend a licence in respect of a private market for such period as
he thinks fit or cancel such licence.
(4) A private market in respect of which the licence has been suspended
or cancelled under sub-section (3) shall be closed with effect from
such date as may be specified in the order of suspension or
cancellation.

Municipal
372.
licence for
sale of flesh,
fish or poultry.

(1) No person shall, without or otherwise than in conformity with a licence
from the Chief Municipal Officer, carry on the trade of a butcher, fishmonger, poulterer or importer of flesh, intended for human food, or use
any place for the sale of flesh, fish or poultry, intended for human food
:
Provided that no person shall sell, or expose for sale, any
flesh obtained from an animal unless the skinned carcass of the
animal is stamped in such manner as the Chief Municipal Officer
may, by general order made in this behalf, require in token of the
fact that the animal has been slaughtered in a municipal or licensed
slaughterhouse :
Provided further that no licence shall be required for any
place used for sale, or storage for sale, of preserved flesh or fish
contained in air-tight or hermetically sealed receptacles.
(2) The Chief Municipal Officer may, by order, and subject to such
226

<!-- page 4 -->

conditions as to supervision and inspection as he may think fit to impose,
grant a licence or may, by order and for reasons to be recorded in
writing, refuse to grant a licence.
(3) The Municipality shall, by regulations, determine the procedure
for the issue of a licence and renewal thereof.
(4) If any place is used for the sale of flesh, fish or poultry intended for
human food in contravention of the provisions of this section, the
Chief Municipal Officer may stop the use of such place in such
manner as he may consider necessary.
Prohibition
of unlicensed
activities.

373. (1) Without or otherwise than in conformity with the terms of a licence
granted by the Chief Municipal Officer in this behalf, no person
shall, within the municipal area, use, or permit to be used, any land
or building (a) for keeping horses, cattle or other quadruped animals or
birds for transportation, sale or hire or for sale of the
produce, or
(b) as a market in respect of which a licence is required under
this Act, or
(c) for carrying out work as an artisan, or
(d) for trade of a butcher, fish-monger, poulterer or importer
of flesh intended for human food or for sale thereof.
(2) If any land or building, public or private, is used, or permitted to
be used, in contravention of the provisions of sub-section (1), the
Chief Municipal Officer may stop the use thereof by such means
as he deems fit, and may confiscate any article in respect of which
such use is being made, prepare an inventory thereof, and, in the
case of perishable items, auction them without notice.

Power to
374. (1) If the Chief Municipal Officer is of the opinion that any premises
stop use of
is being used for a non-residential purpose without a licence under
premises used
in contraventhis Act or otherwise than in conformity with the terms of a licence
tion of licences.

granted in respect thereof, he may stop the use of any such premises
for any such purpose for a specified period by such means as he
227

<!-- page 5 -->

may consider necessary.
(2) If a person continues to use a premises in contravention of the
provisions of sub-section (1), the Chief Municipal Officer may,
notwithstanding any other action that may be taken against such
person under this Act, levy on such person a continuing fine in
accordance with the provisions of sub-section (4) of section 367.
Power to seize 375. (1) The Chief Municipal Officer, or any officer or other employee of
food or drug
the Municipality authorized by him in this behalf, may, at any time
etc.

by day or night, without notice, inspect and examine any food or
drug or any utensil or vessel used for preparing, manufacturing or
storing such food or drug.
(2) If, upon such inspection or examination, any such food or drug is,
in the opinion of the Chief Municipal Officer or the officer or other
employee authorized by him in this behalf, unwholesome or unfit
for human consumption, or is not what it is represented to be, or if
any such utensil or vessel is of such kind, or in such state, as to
render any food or drug prepared, manufactured, or stored therein,
unwholesome or unfit for human consumption, he may seize, seal
or carry away such food or drug or utensil or vessel.
(3) If any food or drug seized under sub-section (2) is, in the opinion of the
Chief Municipal Officer, unfit for human consumption, he shall cause
such food or drug to be forthwith destroyed in such manner as to prevent
its being again exposed for sale or used for human consumption, and
the expenses thereof shall be paid by the person in whose possession
such food or drug was at the time of its seizure.

228
