---
doc_id: "b9278737afbccbee"
source_url: "https://dof.gov.in/static/uploads/2025/08/4d2e38418851fe4441338cdfa0fa5818.pdf"
ministry: "Department of Fisheries (DoF)"
title: "RFP for Consulting Services for Performance Grant Management Consultants (PGMC)"
date: "2025-02-22"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6ebb2c93af9a78a3"
---

<!-- page 1 -->

SELECTION OF CONSULTANTS

REQUEST FOR PROPOSALS
(DIRECT RFP WITHOUT EOI)

STEP/RFP No.:IN-DoF-451728-CS-QCBS

Consulting Services for: Performance Grant Management Consultants (PGMC) for Management and
Monitoring of Performance Grants aimed at improving efficiency in the fisheries value chain and promoting the
adoption of safety and quality assurance measures, under Subcomponents 2 and 3 of the Pradhan Mantri
Matsya Kisan Samridhi Sah-yojana (PM-MKSSY).
Client: Department of Fisheries, Govt. of India
Country: India
Project: Pradhan Mantri Matsya Kisan Samridhi Sah-Yojana (PM-MKSSY)
Issued on: 22nd February 2025
Important Instructions

1.
2.

Department of Fisheries, Govt. of India
Client
:
Availability of Tender : Websites
Documents
https://eprocure.gov.in/eprocure/app

3.

Bid process

: Evaluation shall be made under Quality cum Cost Based
Selection (QCBS)

4.

Mode of Submission

: Part I – Technical Proposal and Part II – Financial Proposal by
the Bidders through e-Procurement System (i.e.
https://eprocure.gov.in/eprocure/app Portal)

Time schedule for various tender related events:
Published Date

22/02/2025

Bid Document Download Start Date

22/02/2025(04:00 PM)

Clarification Start Date

22/02/2025(04:30 PM)

Clarification End Date

03/03/2025 (10:00 AM)

Date of Pre-Bid Meeting

03/03/2025 (11:30 AM) In-Person and Virtual
(Both)
1|P a g e

<!-- page 2 -->

Bid Closing Date

24/03/2025 (11:30 AM)

Technical Bid Opening Date

25/03/2025 (12:00 PM)

Date of Opening of Financial Bid

Will be intimated later

Address For Communication

Department of Fisheries, Govt. of India,
First Floor, Chandra Lok Building, Janpath,
New Delhi-110001
E-mail: srveeragandham@ord.gov.in

Notice inviting tenders which includes instructions for ‘Submission of Proposals’ and all other relevant information is
available on https://eprocure.gov.in/eprocure/app
Note: Any corrigendum(s) to the tender / RFP notice shall be published on the above website only.

V.Srinivasa Rao
Director (Fisheries)

Signature Not Verified
Digitally signed by Tarun Kumar Singh
2|P a g e
Date: 2025.02.22 15:26:05 IST
Location: eProcure-EPROC
