---
doc_id: "b9bff1584cacf6a6"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/57e1ab4fad7a31da2e9c86fab3e0fe01.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Mandatory use of Telecom Tower Standards issued by Telecommunication Engineering Center"
date: "2016-02-24"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1bfd320f0f0a19b4"
---

<!-- page 1 -->

Goverrrmmeirl!U: oif llm1fon
Mn1rnn§t1ry of CO!l111l!l111lil.Illlllllc21U:DO!Jil & rr
][))ejpaJrU:miellUU: of 1fieiliecommu.nll1lk21U:ftollU§
7B, S21Rllcihl21Jr ~ftn21w21nn, 20? A§llrnlka Road, New Diefiiinll--HOOOfi

(Carrier Services Cell)
Dated: 24.02.2016

No. 16-10/2012-CS-III (Pt.-1)
To,
All Telecom Service Providers

§11.Illbject: Mam:fatoiry u.rne of 1fieBiecom 1foweir §fallu:fa11dl§ ftssuedl !by Tellecommumicatiol!Us
lEnginieeJriilllg Oel!lltire.

This has the reference of this office letter of even no. dated 11.12.2012 regarding
mandatory use of Telecom Tower Standards i.e. Generic Requirements (GRs) issued by
Telecom Engineering Centre (TEC) for all telecom towers erected/used by Telecom Service
Providers (TSPs).
This has been further reviewed by the Government and the following decisions . are
hereby conveyed:
1) The guidelines dated Ol.08 ~ 2013 for issue of clearance for ~obile tower installation
issued by Department of Telecommunications (DoT), which were issued at a later date
adequately cover the structural safety aspect of telecom towers and obviates the
requirement of insisting on mandatory use of tower specifications or GRs.
2) Accordingly it has been decided that instead. of mandatory use of Telecom Tower
Standards i.e. Generic Requirements (GRs) issued by TEC for all telecom towers
erected/used by TSPs, it is left to the industry to follow TEC GRs as one of the options for.
design and deployment.
3) All TSPs should ensure that structural safety related provisions as stated in guidelines
~V
~\:z,.0\h
dated 01.08.2013 are adhered to.

CJ ) C

.

N~q\o~

(Rajnan an Kumar)
Under Secretary (CS-III)
Tel. No. 011-23372628
FAX No.011-23372496

Copy to:
.(i) PPS to Secretary (T)
·
)
- .(ii) PPS to Member (T)
Copy for information .
. (iii) PPS to Advisor (T)
(iv) Sr. DDG (TEC), Sr. DOG (TERM), DoT HQ
(v) . DDG (AS-I) - Copy with a request to circulate this letter to all Access Services
Providers.
(vi) Director (IT) - Copy with a request to publish this document on website of DoT.
