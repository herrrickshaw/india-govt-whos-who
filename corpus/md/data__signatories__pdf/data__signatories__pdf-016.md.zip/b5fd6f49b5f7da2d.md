---
doc_id: "b5fd6f49b5f7da2d"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/49ba47080be575e5293f7b8d08c41793.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "O.M. dated 31st March 2023-Veterinary Health Certificate for Import of Milk and Milk Products into India"
date: "2023-03-31"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5b1c96d01bef3f79"
---

<!-- page 1 -->

File No. L-111112019-Trade (E-1 1542)
I.IIfrT TIT'F'R

Government of lndia
qilf,q
qdFr st-f,T, qgqrf,{ silT
Ministry of Fisheries, Animal Husbandry and Dairying

ffi

q{qrf,{ silrt|qfrErnq

Department of Animal Husbandry and Dairying

T{ffi-

110 oo1,
FBqrF[,
Krishi Bhawan, New Delhi-1 10 001,
ETI-.F./ Dated the 31't March ,2023.

OFFICE MEMORANDUM

Subject: Veterinary Health Certificate for lmport of Milk and Milk Products
into lndia - regarding.
The Veterinary Health Certificate for import of Milk and Milk Product into
lndia was made in force vide this Department's O.M. No. L-1 10109(4)11512019Trade (E-1 4537), dated 24th December, 2019. Further, vide this Department's
O.M. No. L-110102(1)t1t2018-Trade (E-7526), dated 1Oth August, 2020, it was
clarified that the said requirement is applicable for import of milk and milk products
into lndia as included under different chapters for human consumption as food in
lndian import policy (whether Sanitary lmport Permit is applicable or not).

2.

Vide Order No. 1829/Heatth Certificate/FSSAI/lmports-2021, dated 3'd

August, 2022, Food Safety and Standards Authority of lndia (FSSAI) also notified
its requirements of "Health Certificate" related to food safety. There was much
confusion among stakeholders including exporting countries as well as food
importers on applicability of requisite "Veterinary Health Certificate" in this regard,
as this Department is regulating import of livestock products including food of
animal origin for human consumption under the Live-stock lmportation Act, 1898
since inception. Forum of lndian Food lmporters also requested to this
Department to align the technical aspects between the two Government of lndia
agencies (DAHD and FSSAI).

3.

ln order to facilitate trade, the integrated Veterinary Health Certificate for
import of Milk and Milk Product into India, encorporating DAHD's sanitary
requirements and FSSAI's food safety requirements is enclosed herewith which
has to be certified by the exporting country along with the consignments to be

exported into lndia.

4.

The exporting country may issue single Veterinary Health Certificate,

certified by Official Veterinarian or certificate with annexure as per its regulations.

The said provision has been kept to facilitate trade considering different
regulations in exporting countries.

Wfu

Contd....

<!-- page 2 -->

-2-

5'

The revised integrated Veterinary Health certificate (VHC)
will be into force
with immediate effect. However, considering the "Eise
or Doing Business,,, it witt
be completely in operation after transition time of 60
days i.e. veterinary Health
certificate by DAHD issued on dated 24th Decemb er, zolg
o, integraied vHC from
exporting country with consignments will be considered
for post-Import ctearance
into lndia during migration time of 60 days.

6'

Any proposal of mutual agreement on the clause (s) retated
to DAHD,s
sanita.ry requirements or FSsAt food safety requirements
shall
be
enrouted
though this Department to avoid ambiguity
future. The food safety related
negotiations and agreements shall be cirrieo out
oy rssAl and will keep DAHD
informed about it. However, the decision on any proposat
of mutual
veterinary Health certificate for export of milk ino ,irirr products agreement on
into lndia will be
taken by this Department as per mandate given by
Government of lndia, as well
as considering holistic approach.

i.

7

'

This n3: th" approval of the Hon'ble Minister for Fisheries,

Husbandry and Dairying,
Encr: As

above.

Distribution,
-

Animal

-/
ll"fu
lr
Mr"zZ
.-I.rqq.rr1

(Dr. Gagan Garg)
Brl-.]ngftT @IqR)
Oeputy Commissioner (Trade)

All Regional officers / Quarantine officers, Animal euarantine

Certification Service, Delhi / Mumbai / Bangaluru /

and
Chennai / Kolk ata tHyderabad.

copy for kind information and necessary action to;
1' The Secretary, Department of Commerce,
Ministry of Commerce &
lndustries, Vanijya Bhawan, New Derhi. Emair:'
csoffice@nrc.in
2' Chairman, Food safety and standllds Authoritv or lndia,
Ministry of Health
& Family welfare, FDA Bhawan, Kofla Road,'New Delhi-1
10002. Email:
chairperson@fssa i. gov. i n

3' Drug Controtler General of lndia, Central Drugs

Standard

Control
organization, Ministry of Health and Family wettare,
Directorate General of
Health services, FDA Bhawan, Kofla Road, New
Delhi -110002. Email:
dci@nic.in
4' Director General, Directorate General of Foreign Trade,
Vanijya Bhawan,
New Delhi. Email: dgft@nic.in
5' Joint Secretary (customs), central Board of lndirect
raxes & customs,
Department of Revenue, North Block, New Delhi.
Emait: ir.r.enic.in

Contd....

<!-- page 3 -->

I

--3-

6. Director (Customs), Department of Revenue (dircus@nic.in)
7. Director, Trade Policy Division (TPD), Department of Commerce, Udyog
Bhawan, New Delhi - I t0 001 . E-mail : d2tpd-doc@nic.in
8. All AQCSs to disseminate the information with all stakeholders including
importers through facilitation channels.
9. NlC, DAHD with a request to upload on the SIP Portal, Departmental and
AQCS's website.
Copy also for kind information to;

1. PS to the Hon'ble Minister for Fisheries, Animal Husbandry and Dairying.
2. PS to the Hon'ble Minister of State for Fisheries, Animal Husbandry and
Dairying (SKB).
3. Sr. PPS to the Secretary, AHD.
4. PPS / PS to the AS (VJ) / AHC / JS (oPC) / JS (cNS).

<!-- page 4 -->

VETERINARY HEALTH CERTIFICATE FOR IMPORT1 OF MILK AND MILK
PRODUCTS INTO INDIA
I.
GENERAL INFORMATION
1. Veterinary Health certificate No:
Date:

3. Invoice No. and Date:
5. Consignor / exporter
Name:

2. Competent Authority
2.1 Ministry:
2.2 Department:
2.3 Contact Details and Email:
4. Quantity:

Address:
Tel. no. and Email:
6. Consignee /importer:
Name:
Address:
Tel. no. and Email:
7. Country of origin:
ISO Code:
8. Place of loading:
9. Country of Destination:
ISO Code:
2
10. Declared Port of Entry
11. Mode of Transport:
12. Identification of the product as described below:
(multiple lines may be used for multiple products)
a) Description of the food along with HS
Intended purpose:
code:

b)

Name and address of Manufacturer /
Establishment

c)

Name
product

d)

Date of Manufacture or Packaging

1

of

the

Approval number/s of establishment /s
(Number /Date / Validity) along with
Name and address of the Registration
/ Accreditation Authority

Lot no. / Batch Type
of Number of Net Weight
no.
packaging
packages
Best before
(if applicable)

Date of Expiry

-----------------------------------------------------------------------------------------------------------------

Import of livestock products into India is subjected to fulfillment of the Live-stock Importation Act,
1898 and the rules / regulations thereunder as notified time to time.
2
Port of Entry as notified by Department of Animal Husbandry and Dairying, Ministry of Fisheries,
Animal Husbandry and Dairying, Government of India considering applicability of Sanitary Import
Permit (SIP) or not, as the case may be.

Page 1 of 4

<!-- page 5 -->

II.

CERTIFICATION*
The undersigned Official Veterinarian certifies that the product(s) described above
satisfies the following requirement:
1. General Conditions:
a) The source animals have never been fed with feeds produced from meat
or bone meal including internal organs, blood meal and tissues of ruminant
origin and porcine origin materials except milk and milk products.
b) The milk product has not been manufactured using animal rennet.
2. Sanitary Conditions:
a) The milk has been processed (including destruction of FMDV3) to make it
fit for human consumption as recommended by World Organization for
Animal Health (WOAH).
b) The milk has been processed to a temperature, which ensures destruction
of organisms causing Tuberculosis, Listeriosis, Para tuberculosis, Q fever
and Brucellosis.
c)

The animals from which the milk has been derived were not exposed to
Bovine Growth Hormones (BGH) / Bovine Somatotropin Hormones (BST).

d) The Source animals were not subjected to estrogenic treatment in last 90
days.
e) Milk / milk products do not contain preformed Bacterial toxins such as
those produced by Bacteria belonging to Staph. aureus, Bacillus cereus,
Clost. perfringes and Clost. botulinum.
3. Food Safety Conditions4:
The attestation from authorized official is annexed.
Official stamp:

3

Signature_____________

Official Veterinarian
Name:
Designation:
Address and Email:
Date:
-----------------------------------------------------------------------------------------------------------------

As recommended under the Article 8.8.25 of Terrestrial Animal Health Code by WOAH, wherever
applicable.
4
As notified by the Food Safety and Standards Authority of India, Ministry of Health & Family
Welfare, Government of India.
*This certificate is valid for 90 days from the date of issue.

Page 2 of 4

<!-- page 6 -->

ANNEXURE
*3.

Attestation for Food Safety conditions**:

The undersigned Official Veterinarian or Authorised Official certifies that the
product(s) described above satisfies the following requirement:
a) Were manufactured at (an) establishment (s) that has / have been approved
by, or otherwise determined to be in good regulatory standing with the
Competent Authority in the exporting country.
b) Does not contain drug/ antibiotics / mycotoxins / pesticides/ heavy metal
residues etc., above the limits prescribed by the Food Safety and Standards
(Contaminants, toxins and Residues) Regulations, 2011.
c) Conforms to the microbiological requirements specified in Appendix ‘B’ of Food
Safety and Standards (Food Products Standards and Food Additives)
Regulations, 2011.
d) Complies with the standards of Milk and Milk products as specified under the
Food Safety and Standards (Food Product Standards and Food Additives)
Regulations, 2011.
e) Contains only those food additives as specified in Appendix ‘A’ of Food Safety
and Standards (Food Products Standards and Food Additives) Regulations,
2011 within the limits specified.
f) Prepared, packed, held and transported prior to export under good hygienic
conditions and an effective food safety control system, implemented within the
context of HACCP systems where appropriate and in accordance with the
requirements specified in Schedule 4, as applicable, of the Food Safety and
Standards (Licensing and Registration of Food Businesses) Regulations, 2011
(India) and such other guidelines as specified from time to time under the
provisions of the Food Safety and Standards Act, 2006.
g) Regular inspection/ monitoring of checks in according with FSS Act, 2006,
rules and regulations made thereunder and as per the criteria specified by
FSSAI.
h) Conditions for transport / storage: Frozen / Chilled / Ambient / __________.
i)

Temperature required during storage and transportation:_______________.

Official stamp:

Signature_____________

Official Veterinarian or Authorised Official
Name:
Designation:
Address and Email:
Date:
----------------------------------------------------------------------------------------------------------------** Where it is not applicable, strikethrough the requirement.
*This certificate is valid for 90 days from the date of issue.

Page 3 of 4

<!-- page 7 -->

Post Import Requirements:
1. On arrival in India, the consignment and the documents shall be
examined by the Regional Officer/ Quarantine Officer, Animal Quarantine
and Certification Services and / or Authorized Officer designated by Food
Safety and Standards Authority of India.
2. Samples may be taken from the milk / milk products for examination, if
applicable.
3. In case the documents do not conform to the requirements and the
product is not as per protocol, the Department of Animal Husbandry and
Dairying, Ministry of Fisheries, Animal Husbandry and Dairying,
Government of India and / or Food Safety and Standards Authority of
India, Ministry of Health & Family Welfare, Government of India,
respectively, will take appropriate action at the cost of importing agency.

-----------------------------------

File No. L-11/1/2019-Trade (E-11542)
Dated 31st March, 2023.
Page 4 of 4
