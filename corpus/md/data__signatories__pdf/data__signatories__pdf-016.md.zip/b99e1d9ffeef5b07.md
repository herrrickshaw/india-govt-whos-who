---
doc_id: "b99e1d9ffeef5b07"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/4d5de28ac5c07258e0da0d30b1c8d1e7.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Telecommunications - Administration of Digital Bharat Nidhi Rules, 2024"
date: "2024-08-30"
pages: 8
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "889830059a77df05"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-31082024-256808
xxxGIDHxxx
CG-DL-E-31082024-256808
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 490]

नई ददल्ली, िुक्रिार, अगस्ट्त 30, 2024/ भार 8, 1946
NEW DELHI, FRIDAY, AUGUST 30, 2024/ BHADRA 8, 1946

No. 490]

संचार मंत्रालय
(दूरसंचार जिभाग)
अजधसूचना
नई ददल्ली, 30 अगस्ट्त, 2024
सा.का.जन. 530 (अ).—के न्द्रीय सरकार दूरसंचार अजधजनयम 2023 (2023 का 44) की धारा 56 की उपधारा
(2) के खंड (x) के साथ पठित धारा 26 द्वारा प्रदत्त िजियों का प्रयोग करते हुए दूरसंचार (जडजिटल भारत जनजध)
जनयम,2024 का प्रारूप बनाने का प्रस्ट्ताि करती है, िो भारत सरकार, संचार मंत्रालय, दूरसंचार जिभाग,
सा.का.जन.365 (अ) तारीख 4 िुलाई, 2024 को भारत के रािपत्र, असाधारण, भाग 2, खंड 3, उप खंड (i), तारीख 4
िुलाई, 2024 के अजधसूचना द्वारा उक्त अजधजनयम की धारा 56 की उप धारा (1) द्वारा यथा अपेक्षानुसार प्रकाजित
दकया था, जिसमें उन सभी व्यजक्तयों से जिनके प्रभाजित होने की संभािना थी, उस तारीख से जिसको उक्त अजधसूचना के
रािपत्र की प्रजतयां िनता को उपलब्ध कराई गई थी, तीस ददनों की अिजध की समाज‍त से पूिव, आपज‍तयां और सुझाि
आमंजत्रत दकए गए थे;
और उक्त रािपत्र की प्रजतयां िनता को 4 िुलाई, 2024 को उपलब्ध करा दी गई थी;
और उक्त प्रारूप जनयमों के संबंध में िनता से प्रा‍त आपज‍तयों और सुझािों पर के न्द्रीय सरकार द्वारा जिचार
दकया गया है;

5572 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

अत: अब, के न्द्रीय सरकार, दूरसंचार अजधजनयम, 2024, (2023 का 44) की धारा 56 की उपधारा (2) के खंड
(x) के साथ पठित धारा 26 द्वारा प्रद‍त िजक्तयों का प्रयोग करते हुए और भारतीय टेलीग्राफ जनयम, 1951 के जनयम,
523 और 527 के अजधक्रमण में उन बातों के जसिाए अजधक्रांत करते हुए जिन्द्हें ऐसे अजधक्रमण के पूिव दकया गया है या
करने का लोप दकया गया है ऐसी व्यिस्ट्था के समाज‍त की तारीख तक उन जनयमों के अधीन जिद्यमान व्यिस्ट्थाओं के
जनबंधन और ितों के अध्यारोही प्रभाि के जबना, जनम्नजलजखत जनयम बनाती है, अथावत:1. संजक्षप्त नाम और प्रारं भ- (1) इन जनयमों का संजक्ष‍त नाम दूरसंचार (जडजिटल भारत जनजध का प्रिासन) जनयम,
2024 है।
(2) ये रािपत्र में उनके प्रकािन की तारीख को प्रिृत होंगे।
2. पठरभाषाएँ.- (1) इन जनयमों में, िब तक दक संदभव से अन्द्यथा अपेजक्षत न हो:(क)

“अजधजनयम” से दूरसंचार अजधजनयम, 2023 (2023 का 44) अजभप्रेत है;

(ख)

“प्रिासक” से जडजिटल भारत जनजध के प्रिासन के जलए रािपत्र में अजधसूचना द्वारा के न्द्रीय सरकार द्वारा
जनयुि जडजिटल भारत जनजध का प्रिासक अजभप्रेत है;

(ग)

“करार” से प्रिासक और जडजिटल भारत जनजध के एक या अजधक कायावन्द्ियनकताव के बीच जडजिटल भारत
जनजध के उद्देश्यों को प्राप्त करने के उद्देश्य से योिनाओं और पठरयोिनाओं को दक्रयाजन्द्ित करने के जलए दकया
गया संजिदा‍मक करार अजभप्रेत है;

(घ)

“बोली” से बोजलयाँ प्राप्त करके माल या सेिाओं की खरीद या कायों का जनष्पादन के जलए कायावन्द्ियनकताव
का चयन करने की एक प्रदक्रया अजभप्रेत है;

(ङ)

“जडजिटल भारत जनजध” से इस अजधजनयम की धारा 24 की उपधारा (1) के अधीन स्ट्थाजपत जडजिटल भारत
जनजध अजभप्रेत है;

(च)

"कायावन्द्ियनकताव" से ऐसे व्यजि जिसके साथ प्रिासक ने कोई समझौता दकया है अजभप्रेत है; और

(ि) "उद्देश्य" से अजधजनयम की धारा 25 के अंतगवत खंड (क) से (घ) में उजल्लजखत कोई भी या सभी उद्देश्य
अजभप्रेत हैं।
(2) उन िब्दों और पदों के , िो इसमें प्रयुक्त हैं और पठरभाजषत नहीं हैं, दकन्द्तु इस अजधजनयम में पठरभाजषत हैं, िही अथव
होंगे, िो अजधजनयम में हैं।
3. प्रिासक की िजियाँ और कायव—(1) जडजिटल भारत जनजध के उद्देश्य को प्राप्त करने के प्रयोिन के जलए
प्रिासक जनयम 7 के उपजनयम (1) में यथा जिजनर्दवष्ट बोली लगाने या पात्र व्यजियों से आिेदन आमंजत्रत करने की प्रदक्रया
के माध्यम से या उक्त जनयम के उप जनयम (2) में यथा जिजनर्दवष्ट नामांकन की प्रदक्रया के माध्यम से कायावन्द्ियनकतावओं
का चयन करेगा।
(2) प्रिासक के पास जनम्नजलजखत िजियाँ और कायव होंगे: (क)

जनबंधनों एिं ितों सजहत बोली लगाने की प्रदक्रयाएँ, आिेदन का प्रारूप, पात्रता मानदंड और ऐसी
बोली के अनुसरण में कायावन्द्ियनकतावओं के चयन के जलए मूल्यांकन मानदंड जिरजचत करना।

(ख)

कायावन्द्ियनकतावओं के चयन के जलए आिेदन आमंजत्रत करने और उनका मूल्यांकन करने के जलए पात्रता
मानदंड और प्रदक्रया जिरजचत करना;

(ग)

कायावन्द्ियनकतावओं के साथ करार करना;

(घ)

दािों का जनपटारा करना तथा जडजिटल भारत जनजध से कायावन्द्ियनकताव को जनजध संजितठरत करना;

(ङ)

समझौते में की गई व्यिस्ट्था के अनुसार मध्यस्ट्थता, मध्यस्ट्थम, सुलह या न्द्याजयक कायविाही के माध्यम
से कायावन्द्ियनकताव के साथ जििादों का जनपटारा करना;

(च)

दकसी तीसरे पक्ष की अजभकरणों सजहत दकसी सक्षम जनकाय के माध्यम से कायावन्द्ियनकताव द्वारा दकए
गए कायव की जनगरानी, मूल्यांकन या स‍यापन करना;

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

(छ)

कायावन्द्ियनकताव द्वारा बनाए रखे िाने तथा प्रस्ट्तुत दकए िाने िाले प्रारूपों सजहत प्रदक्रयाओं और
अजभलेखों को जिजनर्दवष्ट करना;

(ि)

स्ट्कीमों और पठरयोिनाओं की योिना, जिजनमावण, संजिदा प्रबंधन, मध्यािजध पुनर्िवलोकन, स‍यापन,
जनगरानी, जित्तपोषण, मूल्यांकन, प्रभाि आकलन और प्रबंधन के प्रयोिन से परामिवदाता, सलाहकार या
इकाई सजहत कार्मवकों को जनयुि करना;

(झ)

जडजिटल भारत जनजध से जितठरत जनजधयों से जनर्मवत आजस्ट्तयों से संबंजधत जनबंधन एिं ितें जिजनर्दवष्ट
करना;

(ञ)

जडजिटल भारत जनजध के उद्देश्य को प्राप्त करने के जलए पायलट अध्ययन करना;

(ट)

कायावन्द्ियनकतावओं और अन्द्य जहतधारकों को सेिाएं प्रदान करने, संपकव , ठरपोर्टिंग और जनगरानी को
सुजिधािनक बनाने के जलए एक जडजिटल पोटवल बनाना; और

(ि)

कें रीय सरकार द्वारा जडजिटल भारत जनजध के उद्देश्य को प्राप्त करने के प्रयोिन से सौंपे िाने िाले ऐसे
अन्द्य कायव करना।

(3) प्रिासक इन जनयमों के पयाव‍त प्रिासन के जलए भारत सरकार के संयुक्त सजचि की पंजक्त अन्द्यून जलजखत आदेि
द्वारा कें रीय सरकार के दकसी भी अजधकारी को नाजमत कर सकता है।
4. जडजिटल भारत जनजध से जित्तपोषण- (1) अजधजनयम की धारा (25) के अधीन यथा जिजनर्दवष्ट जडजिटल भारत
जनजध के उद्देश्यों को प्राप्त करने के प्रयोिन से स्ट्कीमों और पठरयोिनाओं को कायावजन्द्ित करने के जलए जडजिटल भारत जनजध
कायावन्द्ियनकतावओं को जडजिटल भारत जनजध से जित्तपोषण प्रदान दकया िाएगा।
(2) जडजिटल भारत जनजध के अधीन िार्षवक संग्रह के प्रजतित के रूप में जनजधयों का उपयोग, जिसे रािपत्र में
अजधसूचना द्वारा प्रिासक जिजनर्दवष्ट करेगा, अजधजनयम की धारा (25) के खंड (ख) के अधीन जिजनर्दवष्ट उद्देश्य को प्राप्त
करने के जलए दकया िाएगा।
(3) स्ट्कीमों और पठरयोिनाओं के जलए जडजिटल भारत जनजध से प्रद‍त जित्तपोषण की रूपरे खा प्रिासक द्वारा
मामले के आधार पर अिधाठरत की िा सकती है, जिसमें पूणव जित्तपोषण, आंजिक जित्तपोषण, सह-जित्तपोषण, बािार
िोजखम िमन, िोजखम पूंिी िाजमल है, परंतु इन्द्हीं तक सीजमत नहीं है।
(4) जडजिटल भारत जनजध समाि के अपेक्षा से कम सेिा प्राप्त समूहों िैसे मजहलाओं, ददव्यांग व्यजियों और
आर्थवक और सामाजिक रूप से कमिोर िगों के जलए जनधावठरत दूरसंचार सेिाएँ प्रदान करने के जलए स्ट्कीमों और
पठरयोिनाओं को जनजध उपलब्ध कराएगा।
(5) कायावन्द्ियनकतावओं को करार में जिजनर्दवष्ट अंतरालों और ितों के आधार पर जनजधयां िारी की िाएंगी।
5. जडजिटल भारत जनजध के अधीन स्ट्कीमों और पठरयोिनाओं को िुरू करने के जलए मानदंड –प्रिासक जडजिटल
भारत जनजध के उद्देश्यों को प्राप्त करने के प्रयोिन से स्ट्कीमों और पठरयोिनाओं के जित्तपोषण के जलए जनम्नजलजखत मानदंडों
में से एक या अजधक पर जिचार करेगा: (क) मोबाइल और ब्रॉडबैंड सेिाओं सजहत दूरसंचार सेिाओं का उपबंध और अपेक्षा से कम सेिा प्राप्त ग्रामीण,
दूरस्ट्थ और िहरी क्षेत्रों में दूरसंचार सेिाओं की प्रदायगी के जलए आिश्यक दूरसंचार उपकरण;
(ख) अपेक्षा से कम सेिा प्राप्त ग्रामीण, दूरस्ट्थ और िहरी क्षेत्रों में मोबाइल और ब्रॉडबैंड सेिाओं सजहत
दूरसंचार सेिाओं के उपबंध के जलए दूरसंचार नेटिकव का सृिन;
(ग) अपेक्षा से कम सेिा प्राप्त ग्रामीण, दूरस्ट्थ और िहरी क्षेत्रों में अगली पीढी तक दूरसंचार प्रौद्योजगदकयों की
िुरूआत;
(घ) अपेक्षा से कम सेिा प्राप्त ग्रामीण, दूरस्ट्थ और िहरी क्षेत्रों में उन्नत दूरसंचार सेिाओं तक पहुंच प्रदान
करना या सुधार लाना;
(ङ) अपेक्षा से कम सेिा प्राप्त ग्रामीण, दूरस्ट्थ और िहरी क्षेत्रों में दूरसंचार सेिाओं की िहनीयता में सुधार;

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(च) निाचार, अनुसंधान और जिकास, संिधवन और स्ट्िदेिी प्रौद्योजगकी जिकास और संबद्ध बौजद्धक संपदा के
व्यािसायीकरण को बढािा देने के साथ ही िहां भी आिश्यक हो जनयामक सैंडबॉक्स का सृिन;
(छ) अंतरराष्ट्रीय मानकीकरण जनकायों में राष्ट्रीय अपेक्षाओं और उनके मानकीकरण को पूरा करने के जलए
सुसंगत मानकों को जिकजसत और स्ट्थाजपत करना;
(ि) दूरसंचार क्षेत्र में स्ट्टाटवअप को प्रो‍साजहत करना;
(झ) दूरसंचार ईको-प्रणाली के क्षमता जनमावण और जिकास के जलए जिक्षाजिदों, अनुसंधान संस्ट्थानों, स्ट्टाटवअप और उद्योग के बीच तालमेल बनाना;
(ञ) दूरसंचार सेिाओं के अजभगम में सुधार के जलए नए तकनीकी सॉल्यूिन सृजित करना और नई तकनीकों
को तैनात करना;
(ट) दूरसंचार क्षेत्र में ठटकाऊ और हठरत प्रौद्योजगदकयों को बढािा देना; और
(ि) आ‍मजनभवर भारत के जलए दूरसंचार जिकास, दूरसंचार अनुसध
ं ान और जिकास, स्ट्टावटअप और दूरसंचार
अिसंरचना सुजिधाओं को बढाने हेतु एक व्यजक्त को जनयुक्त कर उसे जि‍त उपलब्ध कराना।
(ड) अजधजनयम के उद्देश्यों को पूरा करने के जलए प्रिासक द्वारा अिधाठरत ऐसे अन्द्य आिश्यक मानदंड।
6. जडजिटल भारत जनजध के अधीन स्ट्थाजपत दूरसंचार नेटिकव का साझाकरण- दूरसंचार नेटिकव की स्ट्थापना,
संचालन, रखरखाि या जिस्ट्तार के जलए जडजिटल भारत जनजध से जनजध प्राप्त करने िाला कोई भी कायावन्द्ियनकताव ऐसे
दूरसंचार नेटिकव को साझा करे गा और उपलब्ध कराएगा और इस दूरसंचार नेटिकव का उपयोग करके िो भी दूरसंचार
सेिाएँ प्रदान की िा रहीं हैं िह पारदिी और जबना दकसी भेदभाि के प्रदान की िाएंगी तथा उनको प्रिासक द्वारा समयसमय पर िारी जनदेिों का अनुसरण भी करना होगा।
7. कायावन्द्ियनकताव की चयन प्रदक्रया – (1) जडजिटल भारत जनजध के उद्देश्यों को प्राप्त करने के प्रयोिनों के जलए
कायावन्द्ियनकतावओं के चयन की प्रदक्रया सारणी-क के अनुसार होगी:
सारणी-क
क्र.सं. जि‍तपोषण के क्षेत्र

चयन
प्रदक्रया

1. अपेक्षा से कम सेिा प्राप्त ग्रामीण, दूरस्ट्थ और िहरी क्षेत्रों में दूरसंचार सेिाओं तक पहुंच और बोली
प्रदायगी को बढािा देने के जलए दूरसंचार सेिाओं को बढािा देना और उनका समथवन करना प्रदक्रया
जिसमें परामिव तथा सलाहकारी सहायता भी िाजमल हैं।
द्वारा चयन
2. अनुसंधान पठरयोिना और पायलट, सह-जि‍तपोषण, व्यिाहायवता अंतराल जि‍तपोषण और आिेदन
िाजणज‍यकरण के जलए िोजखम पूंिी तक सीजमत न रहते हुए इनके माध्यम से नई और उभरती द्वारा चयन
हुई दूरसंचार प्रौद्योजगदकयों या उ‍पादों या सेिाओं के अनुसंधान और जिकास को बढािा देना और
उनका समथवन करना।

स्ट्पष्टीकरण- इस जिजनयम के प्रयोिन के जलए “आिेदन द्वारा चयन” से तकनीकी पैरामीटर के आधार पर, जहत के
प्रस्ट्ताि या प्रस्ट्ताि की मांग के माध्यम से दकसी कायावन्द्ियनकताव के चयन की प्रदक्रया अजभप्रेत है।
(2)
उप-जनयम (1) में अंतर्िवष्ट दकसी बात के होते हुए, प्रिासक, जलजखत रूप में दिव दकए िाने िाले कारणों
के जलए, दकसी जििेष पठरजस्ट्थजतयों को संबोजधत करने के जलए, जडजिटल भारत जनजध के उद्देश्यों को आगे बढाने में
पठरयोिनाओं और स्ट्कीमों के जनष्पादन के जलए नामांकन द्वारा कायावन्द्ियनकताव का चयन कर सकता है।
[फा. सं. डीओटी/यूबीबी/2024-1/दूरसंचार अजधजनयम 2023-जनयम]
देिेंर कु मार राय, संयि
ु सजचि

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

MINISTRY OF COMMUNICATION
(Department of Telecommunication)
NOTIFICATION
New Delhi, the 30th August, 2024.
G.S.R. 530 (E).–– Whereas a draft of the Telecommunications (Digital Bharat Nidhi) Rules, 2024, which the Central
Government proposes to make in exercise of the powers conferred by section 26 read with clause (x) of sub-section (2)
of section 56 of the Telecommunications Act, 2024 (44 of 2023), was published as required by sub-section (1) of the
section 56 of the said Act vide notification of the Government of India in the Ministry of Communication, Department
of Telecommunication number G.S.R. 365(E), dated the 4 th July, 2024, in the Gazette of India, Extraordinary, Part II,
section 3, sub-section (i), dated the 4th July, 2024, inviting objections and suggestions from the persons likely to be
affected thereby, before the expiry of the period of thirty days from the date on which the copies of the Official Gazette
containing the said notification were made available to the public;
And whereas copies of the said Official Gazette were made available to the public on the 4th July, 2024;
And whereas the objections and suggestions received from the public in respect of the said draft rules have been
duly considered by the Central Government;
Now, therefore, in exercise of the powers conferred by section 26 read with clause (x) of sub-section (2) of
section 56 of the Telecommunications Act, 2024 (44 of 2023), and in supersession of rules 523 and 527 of the Indian
Telegraph Rules, 1951, except as respects things done or omitted to be done before such supersession and without
overriding the terms and conditions of existing arrangements under those rules till the date of expiry of such
arrangements, the Central Government hereby makes the following rules, namely:—
1. Short title and commencement.–– (1)
These
(Administration of Digital Bharat Nidhi) Rules, 2024.
(2)

rules

may

be

called

the

Telecommunications

They shall come into force on the date of their publication in the Official Gazette.
2. Definitions. – (1) In these rules, unless the context otherwise requires,––
(a) “Act” means the Telecommunications Act, 2023 (44 of 2023);
(b) “Administrator” means the Administrator of the Digital Bharat Nidhi appointed by the Central
Government, by notification in Official Gazette, for the administration of the Digital Bharat Nidhi;
(c) “agreement” means a contractual agreement made between the Administrator and one or more
Implementers, to implement schemes and projects for the purpose of achieving the objectives of the Digital
Bharat Nidhi;
(d) “bidding” means the process of selecting an Implementer for procurement of goods or services or
execution of works, by calling for bids;
(e) " Digital Bharat Nidhi" means the Digital Bharat Nidhi established under sub-section (1) of section
24 of the Act;
(f) “Implementer" means any person with whom the Administrator has entered into an agreement; and
(g) “objective" means any or all of the objectives mentioned in the clauses (a) to (d) of section 25 of the
Act.

(2) Words and expressions used in these rules and not defined herein but defined in the Act shall have the
meanings assigned to them in the Act.
3. Powers and functions of Administrator.–– (1) The Administrator shall select Implementers through the
process of bidding or inviting applications from eligible persons as specified in sub-rule (1) of rule 7, or through
the process of nomination as specified in sub-rule (2) of the said rule, for the purpose of achieving the objectives of
Digital Bharat Nidhi.

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) The Administrator shall have the following powers and functions, namely:––
(a) to formulate the procedure for bidding including its terms and conditions, format of application,
eligibility criteria and evaluation criteria for selection of Implementers pursuant to such bidding;
(b) to formulate the procedure for inviting and evaluating applications for selection of Implementers;
(c) to enter into agreement with Implementers;
(d) to settle claims and disburse funds from the Digital Bharat Nidhi to Implementers;
(e) to settle disputes with Implementers through mediation, arbitration, conciliation or judicial
proceeding, as may be provided for in the agreement;
(f) to monitor, evaluate or verify the work done by Implementers through any competent body including
any third-party agencies;
(g) to specify procedures and records, along with formats, to be maintained and furnished by
Implementers;
(h) to engage persons including consultants, advisors or an entity for the purpose of planning,
formulation, contract management, midterm review, verification, monitoring, financing, evaluation, impact
assessment and management of schemes and projects;
(i) to specify the terms and conditions relating to the assets created from the funds disbursed from the
Digital Bharat Nidhi;
(j) to undertake pilot study, pursuant to achieving the objectives of the Digital Bharat Nidhi;
(k) to create a digital portal to enable Implementers and other stakeholders to provide services, facilitate
interaction, reporting and monitoring of schemes and projects; and
(l) to perform such other functions as may be assigned by the Central Government for the purposes of
achieving the objectives of the Digital Bharat Nidhi.
(3) The Administrator may, by order in writing, designate any officer of the Central Government not below the
rank of Joint Secretary to the Government of India, for the efficient administration of these rules.
4. Funding from Digital Bharat Nidhi. – (1) Funding from the Digital Bharat Nidhi shall be provided to
Implementers to implement schemes and projects for the purpose of achieving the objectives of the Digital Bharat
Nidhi as specified under section 25 of the Act.
(2) Funds, in terms of a percentage of annual collection under the Digital Bharat Nidhi, as the Administrator
may, by notification in the Official Gazette, specify, shall be utilised for achieving the objectives specified under
clause (b) of the section 25 of the Act.
(3) The modalities for funding provided from the Digital Bharat Nidhi for schemes and projects, may be
determined by the Administrator on a case-to-case basis, including but not limited to full funding, partial funding, cofunding, market risk mitigation or risk capital.
(4) The Digital Bharat Nidhi shall fund schemes and projects for providing targeted access to
telecommunication services for underserved groups of the society, such as, women, persons with disabilities and
economically and socially weaker sections.
(5) The funds shall be released to the Implementers in such manner, at such intervals and subject to such
conditions, as may be specified in the agreement.
5. Criteria for undertaking schemes and projects under Digital Bharat Nidhi.–– The schemes and projects
for the purposes of achieving the objectives of the Digital Bharat Nidhi, shall meet one or more of the following
criteria, namely:––
(a) to provision telecommunication services, including mobile and broadband services and
telecommunication equipment required for delivery of telecommunication services, and enhancing telecom
security in underserved rural, remote and urban areas;

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

(b) to create telecommunication network for provisioning of telecommunications services, including
mobile and broadband services, in underserved rural, remote and urban areas;
(c) to introduce next generation telecommunication technologies in underserved rural, remote and
urban areas;
(d) to provide or improve access to advanced telecommunication services in underserved rural, remote
and urban areas;
(e) to improve affordability of telecommunication services in underserved rural, remote and urban
areas;
(f) to promote innovation, research and development, promotion and commercialisation of
indigenous technology development and associated intellectual property including creation of regulatory
sandboxes, where necessary;
(g) to develop and establish relevant standards to meet national requirements and their standardisation in
international standardisation bodies;
(h) to encourage start-ups in telecommunications sector;
(i) to create bridge between the academia, research institutes, start-ups and industry for capacity
building and development of telecom ecosystem;
(j) to create new technological solutions and deploy new technologies for improving access
to telecommunications services;
(k) to promote sustainable and green technologies in telecommunications sector;
(l) to establish or fund any person to promote telecommunications growth, telecommunications research
and development, standards, start-ups and telecom manufacturing facilities towards Atmanirbhar Bharat;
(m) such other criteria as may be determined by the Administrator as deemed necessary to meet the
objectives of the Act.
6. Sharing of telecommunication networks established under Digital Bharat Nidhi.— Any Implementer,
receiving funding from the Digital Bharat Nidhi for establishing, operating, maintaining or expanding a
telecommunication network, shall share and make available such telecommunication network and telecommunication
services, being delivered using the telecommunication networks on an open and non-discriminatory basis, and in
accordance with the instructions issued by the Administrator from time to time in this behalf.
7. Selection process of Implementer. – (1) The process for selection of Implementers for the purposes of
achieving the objectives of the Digital Bharat Nidhi, shall be in accordance with Table-A:
Table-A
S. No.

Area of funding

Process of selection

1.

Promote and support Telecommunication
services for promoting access to and
delivery of established telecommunication
services in underserved rural, remote and
urban
areas,
including
consultancy
assistance and advisory support

Selection by bidding

2.

Promote and support Research and
development of new or emerging
telecommunication
technologies
or
products or services through, but not
limited to, research projects and pilots, cofunding, viability gap funding, and risk
capital upto to commercialisation.

Selection by application

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Explanation.— For the purposes of this regulation, “selection by application” means the process of selecting an
Implementer through a call for proposal or expression of interest, on the basis of technical parameters.
(2) Notwithstanding anything contained in sub-rule (1), the Administrator may, for reasons to be recorded in
writing, to address any special circumstances and with the approval of the Central Government, select an Implementer by nomination
for the execution of projects and schemes in furtherance of the objectives of Digital Bharat Nidhi .
[F. No. DoT/UBB/2024-1/TelecomAct2023-Rules]
DEVENDRA KUMAR RAI, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
GORAKHA NATH
YADAVA

Digitally signed by GORAKHA NATH
YADAVA
Date: 2024.08.31 10:41:09 +05'30'
