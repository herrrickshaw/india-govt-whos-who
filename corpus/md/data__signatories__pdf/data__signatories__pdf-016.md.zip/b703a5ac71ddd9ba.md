---
doc_id: "b703a5ac71ddd9ba"
source_url: "https://mohua.gov.in/static/uploads/2025/11/7f0a9535b262d48ce251bc72b2611d5a.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of *38,40,000/- as 2nd installment of Central Assistance to the State Government of Madhya Pradesh for 01 BLC (New) project approved in 32nd CSMC meeting held on 26.03.2018 under Pradhan Mantri Awas Yojana (Urban) [PMAY (U)] Mission for the"
date: "2021-02-23"
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "2633adbcc23af586"
---

<!-- page 1 -->

Firefox https://pfms.nic.in/Sanction/TemplateA dvice.aspx?AdviceNum=.
. 92. 339
: PAO (Sectt)/HUA/Admn/Advice /2020-21//79/-

GOVERNMENT OF INDIA
PAO (Sectt) M/o Housing and Urban Affairs
507-C Nirman Bhawan New Delhi
Telephone No: 23062664 Fax No: 23062664

To,

The General Manager, Se | —_—

Reserve Bank of India, [Code No: |707__

Central Accounts Section, Advice No: [594

Additional Office Building, [Advice Date:|24/02/2021

East High Court Road,

NAGPUR - 440 001

Sir,

Please debit our account with Rs.38,40,000/- (Thirty Eight Lakh Forty Thousand Only.) by contra

credit to the following accounts of the Governments with the amounts mentioned against each:

_ ___ Month and Year of Accounts: February,2021 _ __The Amount to be Settled: February,2021
“ Name of the | the | State Scheme Code = Sanction No. and =|

State Code
1 MADHYA कि eae AND UT = N-11012/08/2021-HFA-I-UD
PRADESH GRANTS UNDER PMAY (FTS 9101944) dated
| (URBAN) 23/02/2021
GRAND TOTAL: | 38,40,000
Signature of the authorized official
(Pawan Kumar ee
Sr. Accounts Offic
* 1. O/o the Accountant General (A&E) -I, Madhya Pradesh, Rani Jhansi Road Gwalior-474002.
BAR. Jagdish Prasad, US (HFA-I), M/o Housing and Urban Affairs, New Delhi -110011. On
Pawan Kumar Bhatnagar
Sr. Accounts Officer
|
Hon . Che anvss |
27 (४ 28
QO Ws HFA
wr
lof 24-Feb-21, 11:44 AM

<!-- page 2 -->

: a 339
. था Es
, N-11012/08/2021-HFA-I-UD (FTS: 9101944) FTS: 9101944
Government of India
Ministry of Housing and Urban Affairs
HFA Mission Directorate
(HFA-I Division)
Nirman Bhawan, New Delhi.
Dated:23 February, 2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan, New Delhi -11
Sub: Release of %38,40,000/- as 2nd installment of Central Assistance to the State
Government of Madhya Pradesh for 01 BLC (New) project approved in 32.7 CSMC
meeting held on 26.03.2018 under Pradhan Mantri Awas Yojana (Urban) [PMAY (U)]
Mission for the financial year 2020-21 — reg.
Sir,
| am directed to convey the Sanction of the President of India to release of
%38,40,000/- (Rupees Thirty-Eight Lakh and Forty Thousand only) to the State
Government of Madhya Pradesh as 2nd installment of Central Assistance for 01 BLC
(New) project approved in 32" CSMC meeting held on 26.03.2018 held under Pradhan
Mantri Awas Yojana (PMAY)- Housing for All (Urban) Mission (for Scheduled Tribes
Component) under Allocation for the FY 2020-21.
2. The State Government of Madhya Pradesh has furnished requisite utilization certificate,
physical progress of the projects and Action Taken Report on the Third Party Quality Monitoring
report and other necessary compliances as per scheme guidelines for release of 2" instalment.
The fund being released is based on the data entered in MIS (as on 10.02.2021) out of the list
of beneficiaries approved in 32"4 meeting of CSMC. Details of the projects/release are as under:
@ in lakh
No of Amount of | instalment | beneficiaries instalment released under
Projects Central of Central | (ST) entered already STC Head
approved | Assistance Assistance | in MIS as on | released under
byCSMC | sanctioned | approved in | 10-02-2021 STC Head
csmc
| 1 |
# Project-wise details are annexed.
3. Based on decision of CSMC meeting under Pradhan Mantri Awas Yojana (PMAY) -
Housing for All (HFA) (Urban) Mission and on the recommendations made by MoHUA, the
amount of central grant is being released subject to following conditions alongwith observations
of CSMC:

i. Necessary sanctions/ approvals/ compliances required under the statutory or other
regulatory regime as applicable would be obtained by the authority(ies) concerned with
the project(s).

ii. The State Government and implementing agency shall put in place a monitoring system to
ensure that the project(s) achieve scheduled milestone and envisaged outcomes including
implementation of reforms and other conditionalities required under the scheme.

hao Contd...2/
Le

<!-- page 3 -->

कु -2- .
. iii. Utilize the grant in accordance with the approved guidelines for the implementation of the - है
Scheme of Pradhan Mantri Awas Yojana (PMAY) - Housing for All (HFA) (Urban) Mission.

: iv. The expenditure on the implementation of the scheme/projects will be shared between the
Centre and the State/ULB/Implementing Agency(IA) as committed. The committed State
share should also be released within 15 days from the date of receipt of Central Assistance
in the SLNA account. In case of shortfall of State/ULB/IA share, corresponding amount of
Central share will be deducted from the subsequent instalment(s).

v. Furnish the Utilization certificates of the Grant released in the prescribed format as per GFR
— 2017 as provided in the scheme guidelines.

vi. The funds may be utilized for the purpose and within selected categorised beneficiary for
which these are given. Otherwise these will have to be refunded along with interest as per
provisions for GFR-2017.

vii. The State must ensure geo-tagging of photographs to monitor progress of the house
construction before release of each instalment to beneficiaries.

viii. The agencies responsible for implementation of PMAY(U) should get themselves registered
on PFMS portal.

ix. The State Government should validate the demand assessment data and remove the
ineligible beneficiaries in order to make the housing requirement realistic.

x, State to ensure that adequate infrastructure is ensured including individual water, sanitation
and electric connection.

. xi. State Government to ensure that there is no duplication / change in the identified
beneficiaries.

xii. Transfer of funds to different entities may be made through PFMS, as applicable; and where
there is an element of cash transfers to individual beneficiaries, the same may be made
through PFMS/DBT mode, as applicable.

xiii. The State Government shall submit the Action Taken Report(ATR) on the observations/
recommendations of Third Party Quality Monitoring Agency selected by State for quality
monitoring purpose before release of subsequent instalment.

xiv, State Government should ensure that there is no violation of Model Code of Conduct while
releasing funds to Implementing Agencies/ULBs/Beneficiaries.

4. Payment may kindly be made to the State Government immediately. The funds may

thereafter be released to the implementing agencies without any delay failing which the

amounts would be recovered from the State Government with interest for the period of default.
c
Contd...3/

<!-- page 4 -->

. -3-
ao 5. Additional allocation through 24 supplementary Demand for Grants 2020-21 for PMAY-U
is yet to be received. Therefore, in pursuance to the DEA OM No. 7/41/2019-BA (Pt.l) dated
. 06.01.2021 conveying authorization for incurring excess expenditure of Rs. 6000.00 crore over
and above BE allocation for PMAY(U) by invoking Appendix — 10 under Rule 61 and 69 of GFR
2017, the expenditure involved will be debited from head 3601.06.502.01.03.35 (Scheduled
Tribe Components) under demand No. 57 of Ministry of Housing and Urban Affairs for the year
2020-21 and will be transferred to the following head of account on regularization after receiving
the 2 SDG 2020-21:
| 3601 _| Grants-in-aid to State Governments
Sub-Major Head [06 ~_| Centrally Sponsored Schemes
Scheduled Tribes Component _
Sub Head Urban Housing — Other Grants
Detailed Head [01 _| Pradhan Mantri Awas Yojana (Urban
Object Head 17.01.35 Grants for Creation of Capital Assets
6. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organization(s) shall be open to inspection by the sanctioning authority and audit,
both by the Comptroller and Auditor General of India under the provision of CAG (DPC) Act
1971 and internal audit by the Principal Accounts Office of the Ministry or Department,
whenever the Institution or Organization is called upon to do so.
7. The amount will be credited to the State Government's account in RBI as per procedure
laid down by Ministry of Finance, Department of Expenditure in this regard.
8. This issues with the concurrence of the Finance Division vide their
Note#36 dated 11.02.2021.
9. This sanction has been registered at S.No. 339. 3 q in the Sanction Register of HFA
Mission Directorate (HFA.III Section) of the Ministry of HUA for the year 2020-21.
है 10. This being the 2™ instalment of the grant under PMAY-HFA (U) Mission for these
| projects, requisite UCs have been received from the State Government of Madhya Pradesh.
Yours faithfully,
hw wet
(Jagdish Prasad)
Under Secretary to the Government of India
Tele No. 011-2306 3029
Copy to:-
1. The Principal Secretary/Secretary, Urban Development/Housing Deptt., State Government
of Madhya Pradesh.
2. Accountant General (A&E), Madhya Pradesh.
3. NITI Aayog, SP Divn. / DR Divn. New Delhi
4. CGM, RBI, CAS, Nagpur
5. Budget Division M/o HUA
6. Director/Deputy Secretary, IFD, M/o HUA
7. Director (HFA-3), MoHUA.
8. PMU (MIS), HFA Directorate
9. Dy. Chief MIS, HFA Directorate to place this sanction at appropriate place on the Website
of the Ministry.
10. Sanction folder
लत
(Jagdish Prasad)
Under Secretary to the Government of India

<!-- page 5 -->

‘Anoasure refered to Santon Order No N-11012/8/2021-HFA+-UD (FTS 9101944) dated 15.02.2021 for release of 2nd istalnatat Central Asistance (ST in 1 BLC (New) project approved in 32nd CSMC meeting eld on 26.03.2018
Tout
anion
convene ०००० ०००० on | parton [os [|“।*|
[prt | | [७७४७७]
‘eneicaryted Consracton or 408
[WS touang 0१७ ७ १७५४६ 23200000 84000,
7230221011267)

<!-- page 6 -->

a स्का
y . 1
For stificale
बाय लए शीत et of Ry, 232.20 Lakiny (Ra Tee Crores Taint: Two Lakhs twenty Thousand
(री "के: mat (Through छोर) ९ ४0० ed Jarng the पत्ता 20हिनर an किए of Directorate. Lrbsan
अत कविता ते Development ces dhs miesiry Veparirnens Lemer se gover is the nergy and Bs
Don forse or cuaent ob arepenl bi vanys ub tke vente seat Rs, 194.88 Liukin (Rs. Ore Crore Ninte Mie
adi Buere Thousand Oris tua bees et ceed fe cae 2urpose al "Convtrnctian af PS Dwelling Unity
Ponder BLO vertica of Peadhait VMeaich Aags bajana - Housing For te tlrbany® Cav which owas
पा: पल avcei cg cabrce of Ba RL pokes 19५ Thirty teu dakits Forty baeasund Quiles
sores ur lads at be en of the sear adil be sChinted towards the francis cand sepals deena Gre ast
whe ~~ _— Tener No & Date — सर “Xonar
No _ . _ (ia Lakbt
1 1 1:217/:20/2017 101 120::62:10:04 ८07 ० 135) 1५८) - 221
है ६ 1:३०19/70:7- 181190-262:1 Dated 14. 022-29 ERR TT (ERR) (ST) | 38.20
PSN 19/202 Feta 11909620) Bares 14.02 2219 (८381 (पद! es ee
__ "Total: __ 52 |
वह चछ thay bev wis ec mysell thar dhe cumdinens on which Gig aranttsad von sanetoned hav
been do की लि कर cohag MAITHEstan dvact reve exer choad the Fosow img ot oe ce हिना कीट रन:
seas ee ith utiiesd cor ce purpose Fars Aich 17 ete saesbioned,
Encisergss
Po Peeget Wise Band oles Sears
Lo Paysicel Propross & tordentekirs
GY wee
af Ae ee Bs
५ eet eer
ote a
Esccume t egincer गा Mission Dired ही.)
Crsan aduinisration & Development Vrhak Adisiistration & Development
ff Mathes Pradesh \ Madhava Pradesh
. }
(५ ॥
/
Seerstary 1. ae
Lrka | sebmnnseserazign agi Easehepanentoms
Silva Pradesh 4
3१ 4 oa
ie

<!-- page 7 -->

. 243. -
1.
. :
Form GER 12
Secs Borde 239]
rol Uitzatlon Certificate
«पल tha oat et RO 60.60 Lutte (Rs. give Lakiy Sivty Thousand Onley Granis-in ad
dag deeng te veo 22fa 09 on faves at Directorate, Lehan Adimiuistration and Development
citer ies tivlyy Elguaytmmest Lerer Se git in the margin aad Rs, 6% eras on acooust of carspent
bog. othe ता boot Re. 81.60 Lakin (Rs. Sixty Lithhs Sieg Thousand Only) Was beso utuzed tor
tse purpose of WCecsraathur of BUS Diedings Crit € sreier BLO verneul uf Pradiaat Munter -livds
Parsee Aoanare है एए कह हर हम cer beh swe sae one) aed that “he gobs oF Rs. SU) baka. (Ra,
Wile veauanang ik hive dae there sbet he seas sill oe acousted isteach. the gro sicis d parable Juting ce
testi cd
a | काश फेक 7 rn
No Kon ee (19 Lakhs
1 जिला 0 207 BE ELIS 901087 Deted 35,00 2018 8722-00) 60.60
Toil _ _ 60.60
. Copia aa Paes autintied nyself that cae conditions cp which the urattin-aid was sanctiones aave
hes shes fallilles are Seing Su tiled and पैक विद्वान escreived dhe tolloeng checks to see that he treney
ge actaclly evived “or the portasc for witch il eas sanchoned.
Fuelosurest-
rye se Tard Tlzed Seatus
2 Wy sical uae & Uadertakeas
7 ae
\ SS “y eG
FE कप ros
bvecutie Ragincer व... कण Dit =v)
Urban Administratean & Derelopmeni Lrb\yn Administration & Development
eTp Madina Pradesh \ Madhya Pradesh
A
/ j
é j
Mey .रा
Le
/ secret Commissioner wee
_LrkahereTET Ton and Development >
Madhsa Pradesh
a J g
