---
doc_id: "b84fadd4f7a8d5de"
source_url: "https://msme.gov.in/static/uploads/2025/06/21bc41b6140cd3f9b4b6f148c95ac1e0.pdf"
ministry: "Micro, Small & Medium Enterprises (MSME)"
title: "Letter of Invitation, LoI for assignment under Scheme of Survey, Studies and Policy Research 1"
date: "2020-11-19"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "12d93da191e7d290"
---

<!-- page 1 -->

ADDENDUM

No.22(12)/2019-EDI

Government of India

Ministry of Micro, Small & Medium Enterprises
EDI Section
Udyog Bhawan, New Delhi-— 110011
Dated the 9" December, 2020
To

(As per list enclosed)

Subject: Letter of Invitation (Lol) for assignment under Scheme of Survey, Siudies and
Policy Research — Addendum - regarding.
Sir/Madam,

In continuation to this Ministry's letter of even number dated 19!" Dec, 2020,
Technical and Financial proposals for “Evaluation study of the Ceniral Sector Scheme
of Ministry of MSME viz. ‘Assistance to Training Institutions (ATI)’ Scheme on
Quality and Cost Based Selection (QCBS) has been invited with the last date as
10.12.2020.

2. In this regard, it is hereby informed that the last date and time has now been
extended upto 16.12.2020 at 2:00 PM. Accordingly, the Technical Bids and Financial
Bids will be opened on the same date i.e.16.12.2020 at 3:00 PM in the presence of
representatives of the bidders duly authorized by the respective bidder.
3. It is also hereby informed that the duration of submission of draft report has
been revised to 60 days from the date of award of the Study. Soft copy of this
invitation along with enclosures is available on this Ministry's Website
(https://msme.gov.in/tender). Hindi version will follow.
Yours faithfully,
(Mercy Epao)
Director
@ :011 2306 1431.
Copy for necessary action to:
Sh. Shubhendu Kumar, Sr. Technical Director, NIC for the uploading on the official
website of M/o MSME under the tender notice icon with the heading as:
Letter of Invitation for evaluation of Ministry of MSME’s Scheme: ‘Assistance to
Training Institutions (ATI)’ Scheme under the Scheme of Surveys, Studies and
Policy Research (SS&PR).

<!-- page 2 -->

List
1. Management Development institute (MDI), Gurgaon.
2, National Institute of Financial Management (IIFM), Faridabad.
3. NIESBUD, Noida.
4. National Council of Applied Economic Research (NCAER), Delhi.
5. Institute of Applied Manpower and Research (AMR), Delhi.
6. Institute of Economic Growth (IEG), University of Delhi.
7, Indian Institute of Technology (IIT), Delhi.
8. Council of Science & Industrial Research (CSIR), New Delhi.
9. Tata Energy Research Institute (TERD, New Delhi.
10. National Research Development Corporation of India (NRDCI), New Delhi.
11. Indian Institute of Foreign Trade (LIFT), New Delhi.
12. Indian Institute of Public Administration (IIPA), New Delhi.
13. Nation Productive Council (NPC), New Delhi.
14. NITCON Ltd., Chandigarh.
15. JPS Associate (P) Ltd., New Delhi.
16. Birla Institute of Management Technology (BIMTECH), Greater Noida
17. AH India Management Association (AIMA), New Delhi.
18. Indian Institute of Management (IM), Lucknow (Noida Branch).
19. Asia Pacific Institute of Management (APIM), New Delhi.
RR
