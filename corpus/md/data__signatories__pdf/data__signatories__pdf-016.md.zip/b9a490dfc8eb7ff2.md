---
doc_id: "b9a490dfc8eb7ff2"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/95e6f36b7e0b008ea6e650f6f312f9e2.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Telecommunications Framework to Notify Standards, Conformity Assessment and Certification Rules, 2025"
date: "2025-05-21"
pages: 9
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "1a8068da3090dd70"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-16052025-263155
xxxGIDHxxx
CG-DL-E-16052025-263155
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्‍ड 3—उप-खण्‍ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 272]
No. 272]

नई ददल्ली, िुक्रिार, मई 16, 2025/िैिाख 26, 1947
NEW DELHI, FRIDAY, MAY 16, 2025/VAISAKHA 26, 1947

संचार मंत्रालय
(दूरसंचार जिभाग)
अजधसूचना
नई ददल्ली, 16 मई, 2025
सा.का.नि. 315(अ).— दूरसंचार (मानक, अनुरूपता जनधाारण और प्रमाणन) जनयम, 2025 का प्रारूप जिसे कें द्रीय

सरकार दूरसंचार अजधजनयम, 2023 (2023 का 44) की धारा 56 की उप-धारा (2) के खंड (य ञ) के साथ पठित धारा 19
के अधीन प्रदत्त िजियों का उपयोग करते हुए बनाने का प्रस्ट्ताि करती है, उि अजधजनयम की धारा 56 की उपधारा (1) की
अपेक्षा के अनुसार भारत सरकार के संचार मंत्रालय, दूरसंचार जिभाग की अजधसूचना संख्या सा.का.जन. 82(अ) तारीख 29
िनिरी, 2025 द्वारा भारत के रािपत्र, असाधारण, भाग II, खंड 3, उपखंड (i) में प्रकाजित दकया गया था, जिसमें उि
अजधसूचना अंतर्िाष्‍ट करने िाले रािपत्र की प्रजतयां सिासाधारण को उपलब्ध कराए िाने की तारीख से तीस ददनों की अिजध
की समाजि से पहले, इससे प्रभाजित होने की संभािना िाले सभी व्यजियों से आक्षेप और सुझाि आमंजत्रत दकए गए थे;
और उि रािपत्र की प्रजतयां सिासाधारण को तारीख 29 िनिरी, 2025 को उपलब्ध करा दी गई थीं;
और उि प्रारूप जनयमों के संबध
ं में सिासाधारण से प्राि आक्षेपों और सुझािों पर कें द्रीय सरकार द्वारा सम्‍यक रूप
से जिचार दकया गया है;
अत: अब दूरसंचार अजधजनयम, 2023 (2023 का 44) की धारा 56 की उप-धारा (2) के खंड (य ञ) के साथ पठित
धारा 19 द्वारा प्रदत्त िजियों का उपयोग करते हुए तथा तार के परीक्षण और प्रमाणन से संबंजधत भारतीय तार जनयम,
1951 के जनयम 528 से 537 का अजधक्रमण करते हुए इन जनयमों के लागू होने की तारीख से पूिा कें द्रीय सरकार द्वारा िारी
3222 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

जिद्यमान मानकों, आिश्यक अपेक्षाओं, इं टरफे स अपेक्षाओं, सुरक्षा आश्वासन अपेक्षाओं, जिजनदेिों, परीक्षण अपेक्षाओं या
अनुरूपता जनधाारण, या उनकी छू ट के जनबंधनों और ितों के जसिाय, िो उस समय तक लागू रहेंगे िब तक दक कें द्रीय सरकार
उि अजधजनयम की धारा 19 के अधीन अजधसूचना िारी करके उन्हें अजधक्रमण नहीं कर देती, कें द्रीय सरकार जनम्नजलजखत
जनयम बनाती है, अथाात:1.

संजक्षि नाम और प्रारं भ- (1) इन जनयमों का संजक्षप्‍त नाम दूरसंचार (मानक, अनुरूपता जनधाारण और प्रमाणन को

अजधसूजचत करने की रूपरे खा) जनयम, 2025 है।
(2)

ये रािपत्र में उनके प्रकािन की तारीख से प्रिृत्‍त होंगे।

2.

पठरभाषाएँ- (1) इन जनयमों में, िब तक दक संदभा से अन्यथा अपेजक्षत न हो,(क)

"अजधजनयम" से दूरसंचार अजधजनयम, 2023 (2023 का 44) अजभप्रेत है;

(ख)

"समुजचत प्राजधकारी" से के न्द्रीय सरकार द्वारा जनयम 4 के अधीन अजभजहत प्राजधकारी अजभप्रेत है;

(ग)

"अनुरूपता जनधाारण" से अजधसूजचत मानकों के अनुपालन को प्रदर्िात करने और अिधाठरत करने के जलए
उपयोग की िाने िाली कोई भी प्रदक्रया अजभप्रेत है;

(घ)

"अनुरूपता जनधाारण जनकाय" (सीएबी) से इन जनयमों के अधीन अनुरूपता जनधाारण के प्रयोिन के जलए
जनयम 6 के अधीन समुजचत प्राजधकारी द्वारा मान्यता प्राि व्यजि अजभप्रेत है;

(ङ)

"आिश्यक अपेक्षाओं" से समय-समय पर समुजचत प्राजधकारी द्वारा यथाअजधसूजचत मापदंडों अथिा मानकों
अथिा जिजनदेिों अथिा सुरक्षा अपेक्षाओं का एक समूह अजभप्रेत है;

(च)

"लाइसेंस" से ऐसा कोई लाइसेंस, रजिस्ट्‍रीकरण, या अनुज्ञा, चाहे दकसी भी नाम से ज्ञात हो, अजभप्रेत है िो
दूरसंचार सेिाओं या दूरसंचार नेटिका के उपबंध के जलए भारतीय तार अजधजनयम, 1885 (1885 का 13)
के अधीन िारी की गई है, और "लाइसेंसधारी" िब्द का अथा ऐसे लाइसेंस का धारक माना िाएगा;

(छ)

"पोटाल" से िह पोटाल अजभप्रेत है जिसे कें द्रीय सरकार द्वारा जनयम 13 के अधीन अजधसूजचत दकया िाए;
और

(ि)

"मानक" से समुजचत प्राजधकारी द्वारा िारी ऐसा कोई दस्ट्तािेि अजभप्रेत है िो अजधजनयम की धारा 19 के
अधीन जिजनर्दाष्‍ट दकसी या सभी पहलुओं के संबंध में जििेषताओं, संबंजधत प्रदक्रयाओं, संजहताओं, जिजनदेिों,
आिश्यक अपेक्षाओं, अनुिंजसत व्‍यिहारों, िगीकरण, परीक्षण पद्धजतयों और प्रदक्रयाओं को अजधकजथत करता
है।

(2)

इन जनयमों में प्रयुि िब्दों और पदों के , िो यहां पठरभाजषत नहीं हैं लेदकन अजधजनयम में पठरभाजषत हैं, िही अथा

होंगें िो उनके क्रमि: अजधजनयम में हैं।
3.

उद्देश्य- इन जनयमों का उद्देश्य एक रूपरे खा प्रदान करना है जिसके अंतगात समुजचत प्राजधकारी अजधजनयम की धारा

19 के अधीन जिजनर्दाष्‍ट दकसी या सभी पहलुओं के संबंध में मानक और अनुरूपता जनधाारण उपायों को अजधसूजचत कर
सके गा।
4.

समुजचत प्राजधकारी- (1) दूरसंचार अजभयांजत्रकी के न्‍द्र और राष्ट्रीय संचार सुरक्षा के न्‍द्र, िो दूरसंचार जिभाग, संचार

मंत्रालय, भारत सरकार के कायाालय हैं, इन जनयमों के प्रयोिनाथा समुजचत प्राजधकारी होंगे।

<!-- page 3 -->

[भाग II—खण्‍ड 3(i)]

(2)

भारत का रािपत्र : असाधारण

3

के न्द्रीय सरकार, जिजनर्दाष्‍ट दूरसंचार उपस्ट्कर या धारा 19 के दकसी अन्य पहलू के जलए मानक और अनुरूपता

जनधाारण उपायों की अजधसूचना के प्रयोिन हेतु उसके द्वारा जिजनर्दाष्‍ट दकन्हीं जनबंधनों और ितों के अधीन रहते हुए, दकसी
अन्य कायाालय या प्राजधकरण को भी समुजचत प्राजधकारी के रूप में अजभजहत कर सके गी।
5.

मानकों और अनुरूपता जनधाारण की अजधसूचना और पुनर्िालोकन- (1) समुजचत प्राजधकारी प्रारूप मानकों और

प्रारूप अनुरूपता जनधाारण उपायों का पोटाल पर पूिा प्रकािन सुजनजित करेगा, तादक सभी जहतधारकों को अपनी ठटप्पजणयां
देने के जलए कम से कम साि ददनों की परामिा प्रदक्रया की अनुमजत जमल सके , जिसे ऐसे मानकों या अनुरूपता जनधाारण
उपायों को अंजतम रूप देने से पूिा ध्यान में रखा िाएगा।
(2)

उप-जनयम (1) के अधीन पूिा प्रकािन और जहतधारक परामिा की िता प्रकाजित मानकों या अनुरूपता जनधाारण

उपायों में पुनरीक्षणों या संिोधनों पर लागू होगी:
परं तु उप-जनयम (1) के अधीन पूिा प्रकािन के जलए िता िहां लागू नहीं होगी िहां समुजचत प्राजधकारी दकसी
अजधसूजचत मानक या अनुरूपता जनधाारण उपाय में स्ट्पष्ट मुद्रण संबंधी गलजतयों या त्रुठटयों का सुधार करता है, िो सारिान
प्रकृ जत की नहीं हैं।
(3)

समुजचत प्राजधकारी, उप-जनयम (1) के होते हुए भी, जबना दकसी पूिा परामिा प्रदक्रया के अनंजतम आधार पर दकसी

मानक या अनुरूपता जनधाारण उपाय को अजधसूजचत कर सके गा, िहां जलजखत में अजभलेखबद्ध दकए िाने िाले कारणों से,
यह अिधाठरत करता है(क)

दक ऐसी अजधसूचना दकसी नीजतगत उद्देश्य को िीघ्रता से प्राि करने के जलए आिश्यक है; और

(ख)

दक यदद अनंजतम आधार पर ऐसी अजधसूचना नहीं की िाती है तो ऐसे उद्देश्य की पूर्ता न होने का िोजखम
है:

परं तु समुजचत प्राजधकारी ऐसी अजधसूचना की तारीख से साि ददन की अिजध के भीतर परामिा प्रदक्रया आरं भ करेगा
तथा उपांतरणों के साथ या जबना उपांतरणों के मानकों या अनुरूपता जनधाारण उपायों को अंजतम रूप देने अथिा ऐसे मानकों
या अनुरूपता जनधाारण उपायों को िापस लेने के जलए जहतधारकों की ठटप्पजणयों पर जिचार करे गा।
(4)

समुजचत प्राजधकारी इन जनयमों के अनुसार, ऐसे मानकों के पुनरीक्षण, संिोधन या िापसी की अपेक्षा का अिधारण

करने के जलए, पांच िषा में कम से कम एक बार अजधसूजचत मानकों और अनुरूपता जनधाारण उपायों का पुनर्िालोकन करेगा।
(5)

इन जनयमों के अधीन अजधसूजचत कोई भी मानक उसमें जिजनर्दाष्‍ट तारीख से प्रभािी होगा:
परं तु दकसी जिद्यमान मानक के पुनरीक्षण या संिोधन के जलए अजधसूचना के मामले में, समुजचत प्राजधकारी, आदेि

द्वारा, ऐसे पुनरीजक्षत या संिोजधत मानक को जिद्यमान मानक के साथ-साथ ऐसी अिजध के जलए प्रचाजलत करने की अनुमजत
दे सके गा िो ऐसे आदेि में जिजनर्दाष्‍ट की िाए।
स्ट्पष्टीकरण- इस उप-जनयम में "जिद्यमान मानक" से ऐसा मानक अजभप्रेत है िो पुनरीक्षण या संिोधन की अजधसूचना
की तारीख को प्रभािी है।
6.

अनुरूपता जनधाारण जनकायों की मान्‍यता- (1) समुजचत प्राजधकारी भारत में दकसी प्रयोगिाला को अथिा सािािजनक

जहत में, उन देिों को छोड़कर जिनके साथ भारत की भू-सीमा लगती है, दकसी अन्य देि में दकसी प्रयोगिाला को, िो दक
अंतरााष्ट्रीय प्रयोगिाला प्रत्यायन सहयोग के अंतगात प्रत्याजयत है, अजधजनयम की धारा 19 के अधीन अजधसूजचत मानकों के
अनुरूपता जनधाारण करने के जलए अनुरूपता जनधाारण जनकाय के रूप में मान्यता दे सके गा।
(2)

समुजचत प्राजधकारी समय-समय पर अनुरूपता जनधाारण जनकाय की मान्यता, जनलंबन, िापसी या मान्यता के

निीनीकरण के जलए ददिाजनदेि जिजनर्दाष्‍ट कर सके गा:
परं तु सुसंगत अनुरूपता जनधाारण जनकाय को सुनिाई का उजचत अिसर ददए जबना अनुरूपता जनधाारण जनकाय की
मान्यता जनलंजबत या िापस नहीं ली िाएगी।
(3)

समुजचत प्राजधकारी उसके द्वारा मान्‍यता ददए गए अनुरूपता जनधाारण जनकाय की सूची पोटाल पर प्रकाजित करेगा।

<!-- page 4 -->

4

7.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

अनुरूपता जनधाारण प्रमाणपत्र प्राि करने के जलए आिेदन- (1) अनुरूपता जनधाारण प्रमाणपत्र, समुजचत प्राजधकारी

या के न्द्रीय सरकार द्वारा नामजनर्दाष्‍ट दकसी प्रमाणन जनकाय द्वारा िारी दकया िा सके गा और समुजचत प्राजधकारी ऐसे
प्रमाणन जनकायों की सूची पोटाल पर प्रकाजित करेगा।
(2)

प्रत्येक व्यजि जिस पर अजधसूजचत मानक लागू होता है, अपने स्ट्ियं के खचा पर-:
(क)

लागू मानक के संबंध में अनुरूपता जनधाारण उपायों का अनुपालन सुजनजित करे गा; और

(ख)

सुसंगत मानक के संबंध में यथा अपेजक्षत अनुरूपता जनधाारण प्रमाणपत्र प्राि करने के जलए समुजचत प्राजधकारी
या उप-जनयम (1) के अधीन जिजनर्दाष्‍ट दकसी प्रमाणन जनकाय को, ऐसे प्रारूप और रीजत में तथा समुजचत
प्राजधकारी द्वारा यथा जिजनर्दाष्‍ट फीस के संदाय के अधीन रहते हुए आिेदन करेगा।

(3)

यथाजस्ट्‍थजत, समुजचत प्राजधकारी या प्रमाणन जनकाय-:
(क)

समुजचत प्राजधकारी द्वारा पोटाल पर जिजनर्दाष्‍ट समयसीमा और प्रदक्रया के अनुसार अनुरूपता जनधाारण हेतु
आिेदन का जनधाारण करेगा; और

(ख)

ऐसे जनधाारण के आधार पर, समुजचत प्राजधकारी द्वारा यथा अिधाठरत िैधता अिजध के जलए अनुरूपता
जनधाारण प्रमाणपत्र िारी करेगा।

(4)

अनुरूपता जनधाारण प्रमाणपत्र का निीकरण ऐसी रीजत में तथा प्रदक्रयाओं के अनुपालन के अधीन तथा ऐसी फीस के

संदाय पर दकया िा सके गा, िैसा दक समुजचत प्राजधकारी द्वारा इस संबंध में जिजनर्दाष्‍ट दकया िाए।
8.

अनुपालन बाध्‍यताएं- (1) प्रत्येक व्यजि जिस पर अजधसूजचत मानक लागू होता है, यह सुजनजित करेगा दक अनुरूपता

जनधाारण प्रमाणपत्र सजहत ऐसे मानक के ब्‍यौरे ऐसी रीजत में प्रस्ट्‍तुत दकए िाएं िैसा समुजचत प्राजधकारी द्वारा जिजनर्दाष्‍ट
दकया िाए।
(2)

भारत में कोई भी दूरसंचार उपस्ट्कर, जिस पर कोई मानक लागू होता है, बेचा नहीं िाएगा, या दकसी दूरसंचार

नेटिका में संस्ट्थाजपत नहीं दकया िाएगा, या अन्यथा उपयोग नहीं दकया िाएगा, िब तक दक उसके पास अनुरूपता मूल्यांकन
का िैध प्रमाणपत्र न हो।
9.

अनुरूपता जनधाारण से छू ट- (1) इन जनयमों के अधीन अनुरूपता जनधाारण की अपेक्षा से जनम्नजलजखत को छू ट दी

िाएगी अथाात्:(क)

भारत में अनुसंधान एिं जिकास या प्रदिान या नमूनों के परीक्षण या जिजनयामक सैंडबॉक्स के माध्यम से
भारत में आयात दकए गए दूरसंचार उपस्ट्कर, ऐसे अनुसंधान, प्रदिान या परीक्षण या जिजनयामक सैंडबॉक्स
के जलए सुसंगत जनयमों और प्रदक्रयाओं के अनुपालन के अधीन रहते हुए; और

(ख)

भारत में व्यजिगत उपयोग के जलए दकसी व्यजि द्वारा भारत में लाए गए दूरसंचार उपस्ट्कर और जिनका
अजधजनयम अथिा तत्‍समय प्रिृत्‍त दकसी अन्य जिजध के अधीन आयात करना या उपयोग करना अन्‍यथा
प्रजतबंजधत नहीं है।

(2)

िहां दकसी दूरसंचार उपस्ट्‍कर के संबंध में कोई अजधसूजचत मानक लागू होता है, िहां जनम्नजलजखत मामलों में ऐसे

दूरसंचार उपस्ट्कर का पुनः प्रमाणन अपेजक्षत नहीं होगा अथाात:् (क) िहां ऐसे दूरसंचार उपस्ट्‍कर का मॉडल या ब्ांड दकसी भी रीजत में समुजचत प्राजधकारी द्वारा प्रमाजणत मॉडल
या ब्ांड से जभन्न नहीं है; और
(ख)

िहां ऐसा दूरसंचार उपस्ट्‍कर, समय-समय पर, समुजचत प्राजधकारी द्वारा यथा अजधसूजचत दकसी भी लेबललंग
अपेक्षाओं में पठरितान का अनुपालन करता है।

(3)

के न्द्रीय सरकार, समय-समय पर, उप-जनयम (1) और उप-जनयम (2) के अधीन जिजनर्दाष्ट‍ छू टों के अजतठरि

अनुरूपता जनधाारण की अपेक्षा से छू ट को अजधसूजचत करे गी।

<!-- page 5 -->

[भाग II—खण्‍ड 3(i)]

10.

भारत का रािपत्र : असाधारण

5

िैध अनुरूपता जनधाारण प्रमाणपत्र के जबना दूरसंचार उपस्ट्‍कर के संबध
ं में प्राजधकृ त इकाई या लाइसेंसधारक द्वारा

प्रदक्रया- (1) प्राजधकृ त इकाई या लाइसेंसधारक, यह िानने पर दक उसकी दूरसंचार सेिाओं का कोई प्रयोिा ऐसे दूरसंचार
उपस्ट्‍कर का उपयोग कर रहा है जिसके पास िैध अनुरूपता जनधाारण प्रमाणपत्र नहीं है, ऐसे प्रयोिा को जलजखत में नोठटस
िारी करेगा जिसमें नोठटस िारी करने की तारीख से सात ददनों की अिजध के भीतर ऐसे दूरसंचार उपस्ट्‍कर के प्रयोिा को
उपस्ट्‍कर के उपयोग को बंद करने की िांछा की िाएगी।
(2)

िहां कोई प्रयोिा उप-जनयम (1) के अधीन नोठटस की प्राजप्‍त पर ऐसे नोठटस िारी करने की तारीख से सात ददनों

के भीतर अप्रमाजणत दूरसंचार उपस्ट्‍कर का उपयोग बंद नहीं करता है, प्राजधकृ त इकाई या लाइसेंसधारक, ऐसे प्रयोिा की
दूरसंचार सेिा या दूरसंचार नेटिका से कनेजक्टजिटी को जनलंजबत कर देगा और के न्‍द्रीय सरकार को जलजखत रूप में सेिा बंद
करने की सूचना देगा।
11.

जनरीक्षण और मानीटरी- (1) समुजचत प्राजधकारी या इस प्रयोिन के जलए के न्‍द्रीय सरकार द्वारा प्राजधकृ त कोई

अजधकारी, समय-समय पर, इन जनयमों की अपेक्षाओं के अनुपालन का जनरीक्षण और मानीटरी करेगा।
(2)

कोई व्यजि जिस पर कोई सुसंगत मानक लागू होता है, ऐसे जनरीक्षण और मानीटरी के जलए समुजचत प्राजधकारी या

के न्‍द्रीय सरकार द्वारा प्राजधकृ त दकसी अजधकारी का अपने पठरसर में प्रिेि सुजनजित करे गा और सुसंगत मानक या अनुरूपता
जनधाारण उपाय के संबंध में मांगी गई िानकारी प्रदान करेगा।
12.

दूरसंचार उपस्ट्‍कर से संबजं धत मानकों के उल्लंघन के संबध
ं में प्रदक्रया- (1) इन जनयमों के अधीन जनरीक्षण और

मानीटरी के जलए समुजचत प्राजधकारी या के न्द्रीय सरकार द्वारा प्राजधकृ त कोई अजधकारी यदद जनरीक्षण के दौरान या अन्यथा
यह िानकारी प्राि करता है दक दूरसंचार उपस्ट्‍कर, जिस पर कोई मानक लागू होता है, अनुरूपता जनधाारण का िैध प्रमाणपत्र
नहीं रखता है, तो िह ऐसे उपस्ट्‍कर के कब्िे िाले व्यजि को जलजखत रूप में यह नोठटस िारी करे गा दक िह ऐसे उपस्ट्‍क र की
जबक्री या जितरण या दकसी भी रीजत में उसका उपयोग करना बंद करे और इस नोठटस का प्रािकताा ऐसे नोठटस की प्राजि की
तारीख से सात ददन के भीतर उसका अनुपालन करेगा।
(2)

उप-जनयम (1) के अधीन नोठटस का प्रािकताा, सुसंगत दूरसंचार उपस्ट्‍कर के संबंध में सुसंगत अनुरूपता जनधाारण

उपायों के अनुपालन के अधीन रहते हुए, जनयम 7 के उप-जनयम (2) के अनुसरण में यथा जिजनर्दाष्‍ट फीस का दस गुना संदाय
करने पर, जनयम 7 के अधीन जिजनर्दाष्‍ट रीजत में अनुरूपता जनधाारण प्रमाणपत्र के जलए आिेदन कर सके गा और यदद ऐसा
प्रमाणपत्र उप-जनयम (1) के अधीन नोठटस के एक सौ अस्ट्सी ददन के भीतर प्राि होता है तो िह समुजचत प्राजधकारी को इस
प्रयोिन के जलए समुजचत प्राजधकारी द्वारा जिजनर्दाष्‍ट ऐसे प्ररूप में सूजचत करेगा और ऐसे उपस्ट्‍कर को बेचने, जितठरत करने
या अन्यथा उपयोग करने का हकदार होगा।
(3)

समुजचत प्राजधकारी उप-जनयम (1) या उप-जनयम (2) के उल्लंघन में उपयोग दकए गए उपस्ट्‍कर को अजभग्रजहत करने

या नष्ट करने के जलए जिजधक कायािाही आरं भ कर सके गा।
13.

इन जनयमों का जडजिटल कायाान्ियन- के न्द्रीय सरकार, अजधजनयम की धारा 53 के अनुपालन में, इन जनयमों के

जडजिटल कायाान्ियन के जलए एक या अजधक पोटाल अजधसूजचत करे गी, जिसमें मानकों और अनुरूपता जनधाारण का जिजनदेि,
अनुपालन के जलए प्रदक्रयाएं, फीस और प्रभार, गैर-अनुरूपता संबंधी नोठटस और समुजचत प्राजधकारी द्वारा इन जनयमों के
अधीन ददए गए ककं ही भी आदेिों या जनदेिों का प्रसार करना सजम्‍मजलत हैं।
[फा.सं. 24-13/2024-यूबीबी]
देिेंद्र कु मार राय, संयि
ु सजचि

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)
NOTIFICATION
New Delhi, the 16th May, 2025.
G.S.R. 315(E).— Whereas a draft of the Telecommunications (Standards, Conformity Assessment
and Certification) Rules, 2025, which the Central Government proposes to make in exercise of the powers
conferred by section 19 read with clause (zj) of sub-section (2) of section 56 of the Telecommunications Act,
2023 (44 of 2023), was published as required by sub-section (1) of section 56 of the said Act vide notification
of the Government of India in the Ministry of Communications, Department of Telecommunications number
G.S.R. 82(E), dated the 29th January, 2025, in the Gazette of India, Extraordinary, Part II, section 3, subsection (i), dated the 29th January, 2025 inviting objections and suggestions from the persons likely to be
affected thereby, before the expiry of the period of thirty days from the date on which the copies of the
Official Gazette containing the said notification were made available to the public;
And whereas copies of the said Official Gazette were made available to the public on the 29th
January, 2025;
And whereas the objections and suggestions received from the public in respect of the said draft rules
have been duly considered by the Central Government;
Now, therefore, in exercise of the powers conferred by section 19 read with clause (zj) of sub-section
(2) of section 56 of the Telecommunications Act, 2023 (44 of 2023), and in supersession of rules 528 to 537
of the Indian Telegraph Rules, 1951 relating to testing and certification of telegraph, except as respects the
terms and conditions of existing standards, essential requirements, interface requirements, security assurance
requirements, specifications, testing requirements or conformity assessment, or exemptions thereof, issued
by the Central Government prior to the date of coming into force of these rules, which shall continue to apply
till such time as the Central Government supersedes the same by issuance of a notification under section 19
of the said Act, the Central Government hereby makes the following rules, namely:–
1.
Short title and commencement.– (1) These rules may be called the Telecommunications
(Framework to Notify Standards, Conformity Assessment and Certification) Rules, 2025.
(2)
They shall come into force on the date of their publication in the Official Gazette.
2.
Definitions.– (1) In these rules, unless the context otherwise requires,–
(a) “Act” means the Telecommunications Act, 2023 (44 of 2023);
(b) “Appropriate Authority” means the authority designated by the Central Government under rule
4;
(c) “conformity assessment” means any procedure used to demonstrate and determine compliance
with notified standards;
(d) “Conformity Assessment Body” (CAB) means the person recognised by the Appropriate
Authority under rule 6 for the purpose of conformity assessment under these rules;
(e) “essential requirements” means a set of parameters or standards or specifications or security
requirements as may be notified by the Appropriate Authority from time to time;
(f) “license” means a license, registration or permission, by whatever name called, granted under
the Indian Telegraph Act, 1885 (13 of 1885) for provision of telecommunication services or
telecommunication network, and the term “licensee” shall be construed as the holder of such
license;
(g) “portal” means the portal which may be notified by the Central Government under rule 13;
and
(h) “standard” means a document issued by the Appropriate Authority which lays down the
characteristics, related processes, codes, specifications, essential requirements, recommended
practices, classification, test methods and procedures, in respect of any or all aspects specified
under section 19 of the Act.

<!-- page 7 -->

[भाग II—खण्‍ड 3(i)]

भारत का रािपत्र : असाधारण

7

(2)
Words and expressions used in these rules and not defined herein but defined in the Act shall have
the meanings respectively assigned to them in the Act.
3.
Objective.– The objective of these rules is to provide a framework within which the Appropriate
Authority may notify standards and conformity assessment measures in respect of any or all aspects specified
under section 19 of the Act.
4.
Appropriate Authority.– (1) The Telecommunication Engineering Centre and the National Centre
for Communication Security, under the Department of Telecommunications, Ministry of Communications,
Government of India, shall be the Appropriate Authorities for the purposes of these rules.
(2)
The Central Government may also designate any other office or authority, to be the Appropriate
Authority for the purpose of notification of standards and conformity assessment measures for specified
telecommunication equipment or any other aspect of section 19, subject to any terms and conditions as it may
specify.
5.
Notification and review of standards and conformity assessment.– (1) The Appropriate Authority
shall ensure prior publication of the draft standards and draft conformity assessment measures in the portal,
so as to allow for a consultation process of at least sixty days to enable all stakeholders to provide their
comments, which shall be taken into consideration before finalisation of such standards or conformity
assessment measures.
(2)
The condition for prior publication and stakeholder consultation under sub-rule (1) shall also apply
to revisions or amendments to published standards or conformity assessment measures:
Provided that the condition for prior publication under sub-rule (1) shall not apply where the
Appropriate Authority undertakes rectification of typographical mistakes or errors apparent in any notified
standard or conformity assessment measure, which are not substantive in nature.
(3)
The Appropriate Authority may, notwithstanding sub-rule (1), notify a standard or conformity
assessment measure on a provisional basis without prior consultation process, where it determines, for
reasons to be recorded in writing–
(a) that such notification is necessary to expeditiously achieve a policy objective; or
(b) the risks of non-fulfilment of such objective, if such notification on a provisional basis is not
undertaken:
Provided that the Appropriate Authority shall within a period of sixty days of such notification,
undertake a consultation process, and take into consideration stakeholder comments for either finalising the
standards or conformity assessment measures with or without modifications, or withdrawing such standards
or conformity assessment measures.
(4)
The Appropriate Authority shall review the notified standards and conformity assessment measures,
at least once in five years, to determine the need for revision, amendment or withdrawal of such standards,
in accordance with these rules.
(5)
Any standard notified under these rules shall be effective from the date specified therein:
Provided that in case of a notification for revision or amendment of an existing standard, the
Appropriate Authority may, by order, permit the concurrent operation of such revised or amended standard
along with the existing standard for such period as may be specified in such order.
Explanation.– In this sub-rule, “existing standard” means a standard which is in effect on the date of
notification of revision or amendment to such standard.
6.
Recognition of Conformity Assessment Bodies.– (1) The Appropriate Authority may recognise a
laboratory in India or, in public interest, a laboratory in any other country, other than those with which India
shares a land border, which is accredited under the International Laboratory Accreditation Cooperation, as a
Conformity Assessment Body for carrying out conformity assessment of standards notified under section 19
of the Act.
(2)
The Appropriate Authority may specify, from time to time, guidelines for the recognition,
suspension, withdrawal or renewal of recognition of Conformity Assessment Bodies:
Provided that the recognition of a Conformity Assessment Body shall not be suspended or withdrawn
without giving a reasonable opportunity of being heard to the relevant Conformity Assessment Body.

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(3)
The Appropriate Authority shall publish on the portal, a list of Conformity Assessment Bodies
recognised by it.
7.
Application to obtain Certificate of Conformity Assessment.– (1) The Certificate of Conformity
Assessment may be issued by the Appropriate Authority or any certification body designated by the Central
Government, and the Appropriate Authority shall publish on the portal, a list of such certification bodies.
(2)
Every person to which a notified standard applies shall, at its own cost–
(a) ensure compliance with the conformity assessment measures in respect of an applicable
standard; and
(b) make an application to obtain a certificate of conformity assessment, as may be required in
respect of the relevant standard, to the Appropriate Authority or to any certification body
specified under sub-rule (1), in the form and manner and subject to payment of fees as may be
specified by the Appropriate Authority.
(3)

The Appropriate Authority or the certification body, as the case may be, shall–
(a) undertake assessment of the application for conformity assessment in accordance with the
timelines and procedure as specified on the portal by the Appropriate Authority; and
(b) based on such assessment, issue the certificate of conformity assessment for a validity period
as may be determined by the Appropriate Authority.

(4)
The certificate of conformity assessment may be renewed in the manner and subject to compliance
with the procedures and on payment of such fees as may be specified by the Appropriate Authority in this
behalf.
8.
Compliance obligations.– (1) Every person to which a notified standard applies, shall ensure that
the details of such standard, including the Certificate of Conformity Assessment, is displayed in such
manner as may be specified by the Appropriate Authority.
(2)
No telecommunication equipment to which a standard applies, shall be sold or deployed in any
telecommunication network, or otherwise be used in India, unless it has a valid Certificate of Conformity
Assessment.
9.
Exemptions from conformity assessments.– (1) The following shall be exempt from the
requirement of conformity assessment under these rules, namely:–
(a) telecommunication equipment imported into India for the purpose of carrying out research and
development or demonstration or testing of samples in India or through regulatory sandbox,
subject to compliance with relevant rules and procedures for such research, demonstration or
testing or regulatory sandbox; and
(b) telecommunication equipment brought into India by a person for personal use in India and that
is not otherwise prohibited to be imported or used under the Act or any other law for the time
being in force.
(2)
Where a notified standard applies in respect of a telecommunication equipment, recertification of
such telecommunication equipment shall not be required in the following cases, namely:–
(a) where the model or brand of such telecommunication equipment is not different in any manner
from that certified by the Appropriate Authority; and
(b) where such telecommunication equipment complies with changes to any labelling
requirements as notified by the Appropriate Authority from time to time.
(3)
The Central Government may, from time to time, notify exemptions from the requirement of
conformity assessment, in addition to those specified under sub-rule (1) and sub-rule (2).

<!-- page 9 -->

[भाग II—खण्‍ड 3(i)]

भारत का रािपत्र : असाधारण

9

10.
Procedure by an authorised entity or a licensee in respect of telecommunication equipment
without a valid Certificate of Conformity Assessment.– (1) An authorised entity or a licensee shall, upon
becoming aware that a user of its telecommunication services is using telecommunication equipment that
does not have a valid Certificate of Conformity Assessment, issue a notice in writing to such user seeking
discontinuance by the user of such telecommunication equipment within a period of seven days from the
date of issuance of the notice.
(2)
Where a user, upon receipt of a notice under sub-rule (1), does not discontinue the use of the
uncertified telecommunication equipment within seven days from the date of issuance of such notice, the
authorised entity or licensee, shall suspend the telecommunication service or connectivity to the
telecommunication network of such user and inform the Central Government in writing of such
discontinuance.
11.
Inspection and monitoring.– (1) The Appropriate Authority, or any officer authorised by the
Central Government for this purpose, may from time to time inspect and monitor compliance with the
requirements of these rules.
(2)
Any person to which a relevant standard applies, shall ensure access to the Appropriate Authority,
or any officer authorised by the Central Government, to its premises for the purposes of such inspection
and monitoring and provide information as may be sought in respect of the relevant standard or conformity
assessment measure.
12.
Procedure in relation to contravention of standards relating to telecommunication
equipment.– (1) If the Appropriate Authority, or any officer authorised by the Central Government for
inspection and monitoring under these rules, obtains information during the course of inspection or
otherwise, that telecommunication equipment to which a standard applies is not accompanied by a valid
Certificate of Conformity Assessment, it shall issue a notice in writing to the person in possession of such
equipment to cease from offering for sale or distribution, or using such equipment in any manner, and the
recipient of such notice shall comply with such notice within seven days from the date of receipt of such
notice.
(2)
The recipient of a notice under sub-rule (1), may, subject to compliance with relevant conformity
assessment measures in respect of the relevant telecommunication equipment, apply for Certificate of
Conformity Assessment in the manner specified under rule 7, upon payment of ten times the fees as may
be specified in pursuance of sub-rule (2) of rule 7, and if such certificate is obtained within one hundred
and eighty days of the notice under sub-rule (1), it shall inform the Appropriate Authority in such form as
may be specified by the Appropriate Authority for this purpose, and be entitled to sell, distribute or
otherwise use such equipment.
(3)
The Appropriate Authority may initiate legal proceedings for the seizure or destruction of
equipment that are used in contravention of sub-rule (1) or sub-rule (2).
13.
Digital implementation of these rules.– The Central Government, in furtherance of section 53 of
the Act, may notify one or more portals for the digital implementation of these rules, including for
specification of the standards and conformity assessment, procedures for compliance, fees and charges,
notices of non-conformity, and to disseminate any orders or directions made under these rules by the
Appropriate Authority.
[F.No. 24-13/2024-UBB]
DEVENDRA KUMAR RAI, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH YADAVA

Digitally signed by GORAKHA NATH YADAVA
Date: 2025.05.16 15:21:54 +05'30'
