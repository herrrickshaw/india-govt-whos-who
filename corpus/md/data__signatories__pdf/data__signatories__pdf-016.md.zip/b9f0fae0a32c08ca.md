---
doc_id: "b9f0fae0a32c08ca"
source_url: "https://powermin.gov.in/static/uploads/2025/06/5cca4d27e2074e5b9c33254b10e4a1d9.pdf"
ministry: "Power"
title: "tender 36"
date: "2012-03-03"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "1aaf4f2c5d3c8819"
---

<!-- page 1 -->

Pe  F>= Oe
— ——S——)
. oe
=
° aS
Government of India
Ministry of Power
Operation Monitoring Division
Shram Shakti Bhawan,
New Delhi-110001
No.6/5/20 12-0M £29 3 Dated: 03-03.2012
To
Sub: Quotation for supply of white metal plates with Gold/ Silver
plating and copper plates mounted on oval shaped wooden base.
Sir,
| am directed to refer to this Ministry NIT of even number dated
24.2.2012 on the above subject and to say that as the sufficient number of
quotations have not been received within the stipulated time. With the
approval of the competent authority the last date of receiving the quotations
has been extended up to 10.30 A.M. on 6" March. 2012. The quotations will
be opened at 11 AM on 6" March 2012.
The other terms and condition of the tender document dated 24.2.2012
remains unchanged.
Yours faithfully.
(K.D. Yadav)
Under Secretary to the Govt. of India
“ NIC , Ministry of Power is requested to upload the above extension of
inviting quotations on the website of the Ministry.

<!-- page 2 -->

he = = = - का
—a
* 4
Most Immediate
Time Bound
Government of India
Ministry of Power
Operation Monitoring Division
Shram Shakti Bhawan,

New Delhi-110001
No.6/5/2012-OM Dated: 24.02.2012
Subject: | Quotation for supply of white metal plates with Gold / Silver

plating and copper plates mounted on oval shaped wooden base.

Sir,

Sealed quotations are invited for the Shields for Meritorious Performance
Awards in Power Sector. You are requested to quote your lowest rates for the
shields in three sizes and types with six types of designs to be etched/embossed/
engraved as per details given hereunder:

SI. Description Qty. required Rates
No. in nos. in Rs.
0.) | 15” white metal oval plate with 18 Per shield
gold plating mounted on 18” oval
shaped wooden base of 1”
thickness with folding stand.
(2) 12” white metal oval plate with 17 Per shield
silver plating mounted on 15”
oval shaped wooden base of 1”
thickness with folding stand.
(3) 10” copper oval plate mounted Per shield
on 13” oval shaped wooden base
of 1” thickness with folding stand.
2. The above shields will be with etching/embossing/engraving of name of
award, awardee, year and category, etc, in English & Hindi and symbol of Power
Station / Transmission System/ Distribution System as per sample of designs.
3. The total number of shields will be 51 as mentioned at para-1 above witha
variation of +/ - 6 in total number.

<!-- page 3 -->

= नि eee
eg az en mama
rai
हू
=
4. The sample shield and sample of designs may be seen in this office during
office hours (9.00 a.m. to 5.30 p.m.) on working days (Monday to Friday) in
Room no. 415, Shram Shakti Bhawan, New Delhi (Intercom No.- 277).
* Si The terms and conditions for the above quotation shall be as under:
(1) The rates should be FOR, Shram Shakti Bhawan, Rafi Marg, New
Delhi-110001.
(2) The tender documents should be accompanied by EMD of Rs.5000/-
in the shape of Bank Draft drawn in favour of PAO, Ministry of
Power.
(3) Taxes applicable, if any, should be clearly mentioned in the
quotation.
(4) The prototype of the finished shield of each type has to be got
approved from this Ministry/Central Electricity Authority.
(5) Delivery — The consignment of above items shall be delivered at this
office within 10 days of placement of order.
(6) Payment / Billing - The amount of the bill will be paid within 15
days of the delivery of above items.
(7). Rates — Rates quoted will be valid for 3 months from the closing
date for submission of quotations.
6. The sealed quotation super-scribing the envelope “Quotation for Shields
for Meritorious Performance Awards” addressed to Under Secretary (OM),
Ministry of Power, Shram Shakti Bhawan, New Delhi is required to be dropped in
the drop box kept for the purpose at Gate No.5, Shram Shakti Bhawan from i
March, 2012 to 3™ March, 2012 (upto 11.00 a.m.). The unsealed quotations
and the sealed quotations received after stipulated date and time will not be
considered, The quotations will be opened on 3" March, 2012 at 11:30 a.m. in
Room No. 415, Ministry of Power in presence of interested bidders.
Te The Ministry of Power reserves the right to reject any or all the quotations
without assigning any reasons thereof.
Yours faithfully,
ef
(K.D. Yadav )
Under Secretary (OM)
To: NIC, Ministry of Power for placing the above on the website of the Ministry.
