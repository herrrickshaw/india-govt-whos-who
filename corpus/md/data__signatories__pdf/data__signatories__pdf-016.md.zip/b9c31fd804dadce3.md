---
doc_id: "b9c31fd804dadce3"
source_url: "https://powermin.gov.in/static/uploads/2025/07/1700013b1ea1493f29fe528d1c94ccc1.pdf"
ministry: "Power"
title: "Joint Electricity Regulatory Commission for the States of Manipur and Mizoram (Form of Annual Statement of Accounts and Records) Rules, 2014"
date: "2014-10-16"
pages: 6
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b18a2af7249c8040"
---

<!-- page 1 -->

SS सससक्‍फफफ्न्न्न्न्न्न्_्_्_््६सषषषष््््छ्छ्छ्छ्छ्छ्छ्््म्म्म्न्नन्न्न्न्न्न््न
4000:
/) 10५
ke G r Iudi
Che bazette of India
|
EXTRAORDINARY
ES | C= 0)  ख्तखततञन्‍तन्‍तन्‍त"हत?त“तधधधस यम!
PART II—Section 3—Sub-section (i)
—— |
PUBLISHED BY AUTHORITY
EE SS मम रमन
No. 555] NEW DELHI, TUESDAY, OCTOBER 28, 2014/KARTIKA 6, 1936
विद्युत मंत्रालय
नई दिल्ली, 16 अक्तूबर, 2014
अधिसूचना
सा.का.नि. 754(अ).
अधिनियम कहा गया है) की धारा 83 की उपधारा (1) यह उपबंध करती है कि (क) दो या उससे अधिक राज्यों की
सरकारों; या (ख) एक या उससे अधिक संघ शासित क्षेत्रों के संबंध में केंद्रीय सरकार और एक या उससे अधिक राज्यों
की सरकारों द्वारा किए जाने वाले करार करके एक संयुक्त आयोग का गठन किया जा सकेगा और यह ऐसी अवधि के
लिए प्रवर्तित किया जायेगा और आगे की प्रत्येक अवधि यदि कोई हो, के लिए नवीकरण के अधीन होगा जैसा करार
में अनुबंद्ध किया जाए।
और जब कि केंद्रीय सरकार ने, केंद्रीय सरकार को ऐसा करने के लिए प्राधिकृत करते हुए भागीदार राज्य
सरकारों द्वारा एक समझौता ज्ञापन (जिसे इस अधिसूचना में इसके पश्चात्‌ उक्त करार कहा गया है) हस्ताक्षरित करने
के पश्चात्‌ उक्त अधिनियम की धारा 83 की उपधारा (5) के अधीन तारीख 18 जनवरी, 2005 की अधिसूचना द्वारा
मणिपुर और मिजोरम संयुक्त के लिए विद्युत विनियामक आयोग का गठन किया था ।
और जब कि उक्त अधिनियम की धारा 83 की उपधारा (5) के अधीन, केंद्रीय सरकार, यदि सभी भागीदार
राज्यों द्वारा इस प्रकार से प्राधिकृत किया जाए, कि वह एक संयुक्त आयोग का गठन करे और उक्त अधिनियम की
धारा 83 की उपधारा (3) के अधीन निर्दिष्ट सभी या किसी मामले के संबंध में शक्तियों का प्रयोग करे और जहां
भागीदार राज्यों द्वारा विनिर्दिष्ट रूप से बैसा करने के लिए प्राधिकृत किया गया हो ।
और यह कि उक्त करार के खण्ड (१00) द्वारा मणिपुर और मिजोरम राज्यों ने भारत सरकार को मणिपुर और
मिजोरम राज्यों के लिए संयुक्त विद्युत विनियामक आयोग के गठन और संयुक्त आयोग से संबंधित उक्त अधिनियम के
उपबंधों के अनुपालन के लिए नियम बनाने के लिए प्राधिकृत किया है।
4270 GI/2014 (1)

<!-- page 2 -->

अतः अब विद्युत अधिनियम, 2003 की धारा 104 और धारा 180 की उपधारा (2) के खण्ड (ज) के साथ
पठित धारा 83 की उपधारा (3) और उपधारा (5) द्वारा प्रदत्त शक्तियों का प्रयोग करते हुए केंद्रीय सरकार भारत के
नियंत्रक-महालेखापरीक्षक,के परामर्श से निम्नलिखित नियम बनाती है अर्थात्‌ -
1. संक्षिप्त नाम और प्रारम्भ - (1) इन नियमों का संक्षिप्त नाम मणिपुर और मिजोरम राज्य संयुक्त विद्युत
विनियामक आयोग (निधि का गठन और उपयोजन की रीति और बजट तैयार करने के लिए प्ररूप और समय) नियम,
2014 है।

(2) ये राजपत्र में प्रकाशन की तारीख को प्रवृत्त होंगे।
2. परिभाषाएं -

(1) इन नियमों में जब तक कि संदर्भ में अन्यथा अपेक्षित न हो, -

(क) "लेखा अधिकारी" से ऐसा अधिकारी अभिप्रेत है जो संयुक्त आयोग के अध्यक्ष द्वारा नामनिर्दिशित
किए गए लेखे के अनुरक्षण और वार्षिक लेखे की तैयारी के लिए उत्तरदायी हो ।

(ख) "अधिनियम" से विद्युत अधिनियम, 2003 (2003 का 36) अभिप्रेत है।

(ग) "लेखापरीक्षा अधिकारी" से भारत के नियंत्रक-महालेखापरीक्षक या संयुक्त आयोग के लेखों की
संपरीक्षा के संबंध में उनके द्वारा नियुक्त कोई अधिकारी अभिप्रेत है।

(घ) "अध्यक्ष" से मणिपुर और मिजोरम राज्यों के लिए संयुक्त विद्युत विनियामक आयोग का अध्यक्ष
afr है।

(ड) "वित्तीय वर्ष" से वह अवधि अभिश्रेत है जो वर्ष के 01 अप्रैल से आरंभ होकर अगले वर्ष के 31 मार्च
तक, बारह कैलेण्डर वर्षों से अनाधिक हो ।

(a) "प्ररूप" से इन नियमों के साथ संलग्न प्ररूप अभिप्रेत है।

(छ) "संयुक्त आयोग" से अधिनियम की धारा 83 के अधीन गठित मणिपुर और मिजोरम राज्यों के लिए
संयुक्त विद्युत विनियामक आयोग अभिप्रेत है।

(ज) "सदस्य" से मणिपुर और मिजोरम राज्यों के लिए संयुक्त विद्युत विनियामक आयोग का सदस्य
अभिप्रेत है।

(झ) "भागीदार राज्य" से मणिपुर राज्य और/या मिजोरम राज्य अभिप्रेत है।

(ज) "अनुसूची" से दी गई राशियों के ब्यौरे दर्शाते हुए इन नियमों के साथ संलग्न अनुसूची अभिप्रेत है।

(ट) "सचिव" से मणिपुर और मिजोरम राज्यों के लिए संयुक्त विद्युत विनियामक आयोग का सचिव
अभिप्रेत है।

(2) उन सभी शब्द एवं अभिव्यक्तियों का, जो इन नियमों में प्रयुक्त हैं एवं परिभाषित नहीं की गई हैं,
किन्तु विद्युत अधिनियम, 2003 (2003 का 36) में परिभाषित हैं, का वही अर्थ होगा जो उस
अधिनियम में है।

3. आयोग के लेखे-

<!-- page 3 -->

Th S_—_—___

(1) संयुक्त आयोग 2007-08 से प्रारंभ कर प्रत्येक वित्त वर्ष के लिए वार्षिक लेखा विवरण तैयार
करेगा।

(2) संयुक्त आयोग का सचिव, संयुक्त आयोग के एक अधिकारी को उनकी ओर से लेखा तैयार करने के
लिए प्राधिकृत करेगा।

(3) संयुक्त आयोग का सचिव, संयुक्त आयोग के लेखे के अनुरक्षण, वित्तीय विवरण और विवरणिका के
संकलन का पर्यवेक्षण करेगा तथा सुनिश्चित करेगा कि संयुक्त आयोग के लेखे की लेखा-परीक्षा के उद्देश्य से लेखा
परीक्षा अधिकारी द्वारा अपेक्षित संयुक्त आयोग के सभी लेखे, बही, संबद्ध वाउचर तथा अन्य दस्तावेज और कागजात
उस अधिकारी के निपटान पर रखे जाएं ।

(4) संयुक्त आयोग के सचिव द्वारा, संयुक्त आयोग द्वारा विधिवत अनुमोदित तथा भारत के नियंत्रक-
महालेखापरीक्षक या उनके प्राधिकृत प्रतिनिधि द्वारा प्रमाणित किए जाने के पश्चात्‌ वार्षिक लेखा विवरण, केंद्रीय
सरकार द्वारा यथानिर्धारित तारीख तक केंद्रीय सरकार (संयुक्त आयोग के प्रचालन के प्रथम पांच वर्ष के लिए) तथा
भागीदारी राज्य सरकारों (संयुक्त आयोग के प्रचालन के छठें वर्ष से और उसके आगे से) को प्रस्तुत किया जायेगा ।

(5)

(क) संयुक्त आयोग निम्नलिखित लेखे नीचे वर्णित प्ररूपों में तैयार करेगा -

(i) स्‍ प्ररूप क में प्राप्ति और भुगतान लेखे;

(1) ॒प्ररूप ख में आय और व्यय लेखे;

(1) प्ररूप ग में तुलन-पत्र ।

(ख) संयुक्त आयोग का सचिव "प्राप्ति और भुगतान लेखा", "आय और व्यय लेखा" तथा "तुलन-पत्र" पर

हस्ताक्षर करने तथा अधिप्रमाणित करने के लिए प्राधिकृत हस्ताक्षरकर्ता होगा ।

(ग) वार्षिक लेखा विवरण संपरीक्षा अधिकारी को लेखे से संबंधित वर्ष के अगले वर्ष 30 जून को या
इससे पहले प्रस्तुत किया जाएगा तथा संपरीक्षा अधिकारी संयुक्त आयोग के लेखे की संपरीक्षा करेगा
और उस पर रिपोर्ट देगा।

(घ) संयुक्त आयोग, लेखा परीक्षा रिपोर्ट प्राप्त होने पर, उसमें निर्दिष्ट की गई किसी कमी या
अनियमितता का सुधार करेगा और उस पर की गई कार्रवाई के बारे में केंद्रीय सरकार तथा
संपरीक्षा अधिकारी को सूचित करेगा।

4. आयोग के वार्षिक लेखे की तैयारी का प्ररूप और समय -

(क) संयुक्त आयोग प्रत्येक वित्त वर्ष के लिए वार्षिक लेखा विवरण नीचे दिए गए रीति से तैयार करेगा
और उसमें निम्नलिखित सम्मिलित होंगेः

(0). तुलन-पत्र;

(ii) आय और व्यय लेखा;

(1) उपर्युक्त वित्तीय विवरणों की अनुसूचियां;

(५) अनुदेश और लेखा सिद्धांत;

(v) अनुसूचियों पर टिप्पण और अनुदेश;

(vi) प्राप्ति और भुगतान के विवरण।

<!-- page 4 -->

CAZEFFE—OE-N DE EXFRAGRD RAR ———— Parsee

(ख) संयुक्त आयोग द्वारा वार्षिक लेखा विवरण को लेखा से संबंधित वित्त वर्ष के पश्चात्‌ तीन मास की

अवधि के भीतर अंतिम रूप दिया जाएगा ।

(ग) वार्षिक लेखा विवरण, संसदीय समिति की सिफारिश पर नियुक्त विशेषज्ञ समिति द्वारा तैयार किए

गए रूप विधान के अनुसार तैयार किया जाएगा।
5. वार्षिक लेखा विवरण का अनुमोदन -

(क) वित्त वर्ष की समाप्ति के पश्चात्‌ तीन मास के भीतर, लेखाधिकारी वार्षिक लेखा विवरण तैयार
करेगा और सचिव उसे संयुक्त आयोग को अनुमोदन के लिए प्रस्तुत करेगा तथा संयुक्त आयोग द्वारा अनुमोदन के
पश्चात्‌, वार्षिक लेखा विवरण संपरीक्षा के लिए नियंत्रक-महालेखापरीक्षक को या उनके द्वारा नियुक्त किसी अन्य
व्यक्ति को भेजा जाएगा।

(ख) संयुक्त आयोग के लेखे अध्यक्ष, वित्त से संबंधित कार्य करने वाले एक सदस्य तथा संयुक्त आयोग के
सचिव द्वारा अधिप्रमाणित किए जायेंगे।

6. लेखे के अभिलेखों का परीरक्षण, इत्यादि -

(क) संयुक्त आयोग इन नियमों के अधीन तैयार तुलन-पत्र, आय और व्यय लेखे तथा प्राप्ति और भुगतान
लेखे के अभिलेखों को न्यूनतम दस वर्ष की अवधि के लिए परिरक्षित करेगा ।

(ख) बहीखातों तथा अन्य सुसंगत अभिलेखों को संयुक्त आयोग के कार्यालय में रखा जाएगा और यह
सुनिश्चित करने का दायित्व लेखाधिकारी का होगा कि बहीखातों तथा अन्य संबंधित अभिलेखों का उचित अनुरक्षण
किया जाए तथा सुरक्षित अभिरक्षा में संभाल कर रखा जाए और जब कभी अपेक्षित हो, उसे संपरीक्षा के लिए प्रस्तुत
किया जाए।

7. प्राधिकृत हस्ताक्षरकर्ता -

तुलन-पत्र, आय और व्यय लेखे और प्राप्ति और भुगतान लेखे पर निदेशक (प्रशासन) या संयुक्त आयोग द्वारा
अधिकृत किसी अन्य अशििकारी द्वारा हस्ताक्षर किए जाएंगे ।

[फा. सं. 47/1/2009-आर एण्ड आर]
ज्योति अरोरा, संयुक्त सचिव
MINISTRY OF POWER
New Delhi, the 16th October, 2014
NOTIFICATION

G.S.R 754(E).—Whereas sub-section (1) of section 83 of the Electricity Act, 2003 (hereinafter in this notification
referred to as the said Act) provides that a Joint Commission may be constituted by an agreement to be entered into (a)
by two or more Governments of States; or (b) by the Central Government, in respect of one or more Union territories,
and one or more Governments of States, and shall be enforced for such period and shall be subject to renewal for each

further period, if any, as may be stipulated in the agreement;

And whereas the Central Government had constituted a Joint Electricity Regulatory Commission for Manipur

and Mizoram vide notification dated the 18th January, 2005 under sub-section (5) of section 83 of the said Act, after the
participating State Governments signed a Memorandum of Agreement (hereinafter in this notification referred to as the
said Agreement) authorizing the Central Government to do so;
And whereas sub-section (5) of section 83 of the said Act, the Central Government may, if so authorized by all the
participating States, constitute a Joint Commission and may exercise the powers in respect of all or any of the matters
specified under sub-section (3) of section 83 of the said Act and when so specifically authorized by the participating
States;

<!-- page 5 -->

जया. SSS

And whereas vide clause (xxi) of the said Agreement, the States of Manipur and Mizoram have authorized
Government of India to constitute a Joint Electricity Regulatory Commission for the States of Manipur and Mizoram
and to frame rules to carry out the provisions of the said Act relating to the Joint Commission;

Now, therefore, in exercise of powers conferred by sub-sections (3) and (5) of section 83 read with sections 104
and clause (h) of sub-section (2) of section 180 of the Electricity Act, 2003, the Central Government, in consultation
with the Comptroller and Auditor-General of India, hereby makes the following rules, namely :—

1. Short title and commencement
(1) These rules may be called the Joint Electricity Regulatory Commission for the States of Manipur and Mizoram
(Form of Annual Statement of Accounts and Records) Rules, 2014.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions. -
(1) In these rules unless the context otherwise requires, —
(a) “Accounts Officer” means an officer responsible for maintenance of accounts and preparation of annual
accounts as nominated by the Chairperson of the Joint Commission;
(b) “Act” means the Electricity Act, 2003 (36 of 2003);
© “Audit Officer” means the Comptroller and Auditor-General of India or any officer appointed by him in
connection with the audit of accounts of the Joint Commission;
(d) “Chairperson” means the Chairperson of the Joint Electricity Regulatory Commission for the States of
Manipur and Mizoram;
(०) “Financial year” means a period not exceeding twelve calendar months commencing on the Ist April of a
year and concluding on the 31st March of the subsequent year;
(f) “Form” means a form appended to these rules;
() “Joint Commission” means the Joint Electricity Regulatory Commission for the States of Manipur and
Mizoram constituted under section 83 of the Act;
(h) “Member” means a Member of the Joint Electricity Regulatory Commission for the States of Manipur
and Mizoram;
0) “Participating State” means the State of Manipur and/or the State of Mizoram;
@ “Schedule” means the schedule appended to these rules showing details of the amounts given;
(k) “Secretary” means the Secretary of the Joint Electricity Regulatory Commission for the States of Manipur
and Mizoram.
(2) All the words and expressions used and not defined in these rules but defined in the Electricity Act, 2003 (36 of
2003), shall have the meanings assigned to them in that Act.
3. Accounts of the Commission. -

(1) The Joint Commission shall prepare the annual statement of accounts for every financial year
commencing with 2007-08.

(2) The Secretary of the Joint Commission may authorise an officer of the Joint Commission to prepare the
account on his behalf.

(3) The Secretary of the Joint Commission shall supervise the maintenance of the accounts of the Joint
Commission, the compilation of financial statement and return, and shall ensure that all accounts, books, connected
vouchers and other documents and papers of the Joint Commission required by the audit officer for the purpose of
auditing the accounts of the Joint Commission are placed at the disposal of that officer.

(4) The annual statement of accounts duly approved by the Joint Commission and after certification by the
Comptroller and Auditor-General of India or his authorised representative, shall be submitted by the Secretary of the
Joint Commission to the Central Government (for the first five years of operation of the Joint Commission) and the

<!-- page 6 -->

Participating State Governments (from the sixth year of operation of the Joint Commission onwards) by such date as
may be specified by the Central Government.

(5)

(a) The Joint Commission shall prepare the following accounts in the forms mentioned below -

(i) the Receipt and Payment Accounts in Form A;

(ii) the Income and Expenditure Accounts in Form B;

(iv) the Balance Sheet in Form C.

(b) The authorised signatory to sign and authenticate the “Receipt and Payment Accounts”, “Income and
Expenditure Accounts” and “Balance Sheet” shall be the Secretary of the Joint Commission.

(०) The annual statement of accounts shall be submitted to the Audit Officer on or before the 30" June
following the year to which the accounts relate and the Audit Officer shall audit the accounts of the Joint
Commission and report thereon.

(d) The Joint Commission shall, on receipt of the audit report, correct any defect or irregularity pointed out
therein and report to the Central Government and the Audit Officer about the action taken by it thereon.

4. Form and time of preparation of Annual Accounts of the Commission. -

a) The Joint Commission shall prepare the Annual Statement of Accounts for every financial year in the
manner specified below and shall comprise:

(i) the Balance Sheet;

(Gi) the Income and Expenditure Account;

(iii) the Schedules to the above financial statements;

(iv) the instructions and accounting principles;

(vy) the notes and instruction from the Schedules

(vi) the Statements of Receipts and Payments.

(b) The Annual Statement of Accounts shall be finalised by the Joint Commission within a period of three
months following the financial year to which the accounts relate.

(c) The Annual Statement of Accounts shall be prepared as per the format devised by the Committee of
Experts appointed on the recommendation of the Parliamentary Committee.

5... Approval of the Annual Statement of Accounts. -

(a) Within three months after the end of the financial year, the Accounts Officer shall prepare and the
Secretary shall submit the Annual Statement of Accounts to the Joint Commission for approval and on
approval by the Joint Commission, the Annual Statement of Accounts shall be sent to the Comptroller and
Auditor-General or any other person appointed by him for audit.

(b) The Accounts of the Joint Commission shall be authenticated by the Chairperson, one Member dealing
with the Finance and the Secretary of the Joint Commission.

6. Preservation of records of accounts, ete. -

(a) The Joint Commission shall preserve the records of Balance sheet, Income and Expenditure Accounts and
Receipts and Payments account prepared under these rules for a minimum period of ten years.

(b) The books of accounts and other relevant records shall be kept in the Joint Commission's office and it shall
be the responsibility of the Accounts Officer to ensure that the books of accounts and other relevant
records are properly maintained and securely preserved in safe custody and produced to Audit as and when
required.

7. Authorized signatory. -
The Balance Sheet, the Income and Expenditure Accounts and the Receipts and Payments Account shall be
signed by the Director (Admn) or any other Officer authorised by the Joint Commission.
[F.No. 47/1/2009-R&R]
