---
doc_id: "b82ade8f38cdf1a8"
source_url: "http://www.moef.gov.in/uploads/2021/08/Panchghani29.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "OM [14.03.2017] निगरानी समिति का पुनर्गठन अधिसूचना S.O. संख्या 52 (E) महाबलेश्वर-पंचगणी अधिसूचना के तहत"
date: "2021-08"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5d929c409c245ab7"
---

<!-- page 1 -->

F.No. 2/40/2005—ESZ (RE)-part file
Government of India
Ministry of Environment, Forest & Climate Change
(ESZ Division)
w****
Indira Paryavaran Bhawan,
Jor Bagh Road, Ali Ganj
New Delhi — 110003
Dated: 14th March, 2017
OFFICE MEMORANDUM
Subject: Reconstitution of Monitoring Committee under the Notification S.O. No. 52 (E)
dated the 17th January, 2001 (Mahabaleshwar Panchghani Notification) declaring
Mahabaleshwar Panchghani and surrounding region in the State of Maharashtra
as Eco-sensitive Zone.
In pursuance of the Notification S.O. No. 52 (E) dated the 17th January, 2001
(Mahabaleshwar Panchghani Notification) declaring Mahabaleshwar Panchghani and
surrounding region in the State of Maharashtra as Eco-sensitive Zone, and under the provisions
of sub-section (3) of section 3 of the Environment (Protection) Act, 1986 (29 of 1986) the
Government of India, in the Ministry of Environment & Forest hereby reconstitutes the
Monitoring Committee comprising of the following:-

Name and Designation
SI. No.
Dr.
Ankur
Patwardhan,
Pune.
I
District
Collector,
Satara,
Maharashtra
2
Chief Conservator of Forest, Maharashtra
3
Administration,
Municipal
4
Director,
Government of Maharashtra, Mumbai
5
Deputy Director, Town Planning, Pune
Division, Government of Maharashtra
6
Representative of Maharashtra Pollution
Control Board
Representative of CPCB, Parivesh Bhawan,
7
New Delhi
Director General, All India Institute of Local Self
8
Govt., Mumbai
Dr. Rahul Mungikar, Nagpur.
9
Chief Executive Officer, Satara, Maharashtra
10

Page 1 of 3

Position
Chairman
Member
Member
Member
Member
Member
Member
Member
Member
Member Secretary

<!-- page 2 -->

The terms of reference of the Monitoring Committee are as follows:-

2.

(i) To ensure monitoring of compliance of the provisions of the (Mahabaleshwar Panchghani
Notification) declaring Mahabaleshwar Panchghani and surrounding region in the State of
Maharashtra as Eco-sensitive Zone published in the Gazette of India, Extraordinary Part
II Section (3) Sub-Section (ii), S.O. No. 52 (E) dated the 17th January, 2001.

(ii) To discharge the functions specifically enumerated in the Notification and do all things
incidental thereto (except the functions as are required to be performed by the Central
Government under the provisions of the Environment Impact Assessment (ETA)
Notification of 14th September, 2006 as amended from time to time).

3.

The Committee or any officer or member of the Monitoring Committee authorized by the
Committee shall file complaints under Section 19 of the Environment (Protection) Act,
1986, if offences under the said Act came to the notice of the Committee.

4.

The orders/directions issued by Hon'ble NGT/Supreme Court/ High Court/District Court
as the case may be from time to time w.r.t. Mahabaleshwar Panchghani Eco-sensitive
zone shall be complied with by the State Government and the Monitoring Committee.

5.

The tenure of the Committee is for a period of three years and can be subsequently
extended by the Government of India, if necessary.

6.

The expenditure on the Monitoring Committee shall be met by the Government of
Maharashtra.

7.

The Monitoring Committee shall meet at least once in a month and dispose of its
assignments within a period of 90 days.

8.

The quorum for the Monitoring Committee shall not be less than five members including
the Chairman.

Page 2 of 3

<!-- page 3 -->

9.

TA/DA to the non-official members of the Committee shall be met by the Government of
Maharashtra as per the State Government rules.
I
(Lalit apur)
Advisor
(Email: l.kapur@nic.in)

To,
The Chief Secretary, Government of Maharashtra, Mantralaya, Mumbai.
2.

The Principal Secretary, Department of Environment, Government of Maharashtra,
Mantralaya, Mumbai-400 032.

3.

The Secretary, Department of Forests, Government of Maharashtra, Mantralaya,
Mumbai- 400 032.
The Secretary, Department of Urban Development, Government of Maharashtra,
Mantralaya, Mumbai-400 032.

5.

The Chairman and the Members of the Monitoring Committee.

6.

Guard File.

Copy to:
I . P›-to MOS (I/C), Environment and Forests.
..2.VPPS to Secretary (EF&CC).
3. PPS to AS (AP).

Page 3 of 3
