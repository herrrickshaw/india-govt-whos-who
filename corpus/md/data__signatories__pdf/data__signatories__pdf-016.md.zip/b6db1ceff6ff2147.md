---
doc_id: "b6db1ceff6ff2147"
source_url: "https://mnre.gov.in/static/uploads/2025/08/a97099dfd950574ff29c05bbd7f7eedc.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Guidelines for Offshore Wind Power Assessment Studies and Surveys"
date: "2025-10-23"
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab32354e9f799d4d"
---

<!-- page 1 -->

File No.225/3/2018-Wind-Part(2)

Sub: Guidelines for Offshore Wind Power Assessment Studies and Surveys
Government of India notified National Offshore Wind Energy Policy-2015 on 6
October 2015 for the development of offshore wind power in India. Policy provides for
offshore wind power development up to seaward distance of 200 nautical miles from the base
line i.e. up to the Exclusive Economic Zone (EEZ) of the country. Ministry of New &
Renewable Energy (MNRE) is the Nodal Ministry and National Institute of Wind Energy
(NIWE) is the Nodal Agency for the development of Offshore Wind Energy in India.
2.
The Policy provides for carrying out of preliminary wind resource assessment,
oceanographic and bathymetric surveys, etc., by NIWE for demarcation of offshore wind
power blocks. In addition, interested private players having proven expertise in offshore
studies and surveys may be granted permissions on case to case basis to collect data and have
shared ownership on it with NIWE. Policy also authorizes NIWE to issue detailed Guidelines
in this regard.
3.
Accordingly, with a view to encourage private participation in studies and surveys for
offshore wind power, following guidelines are issued:
(i)

Private surveyors/ developers having proven expertise in offshore studies and
surveys who are desirous of collecting wind resource data together with
oceanographic and bathymetric data at specific locations are required to apply
with the details of the site to be surveyed to Group Head,WRA&O Unit,
NIWE, Chennai. Such application will be registered by NIWE on a nonrefundable payment of Rs.1.0 lakh + GST as applicable per site. In case, the
companies want to outsource the activity through any other agency/body, they
have to furnish necessary documents to establish the credentials of such
agency/body, experience, expertise, etc. NIWE‘s team may visit the site for
verification during the period of measurement.

(ii)

In addition, the above mentioned private surveyors/developer will also have to
apply for in-principle NOCs/clearances from the following Ministries /
Departments:
a. Ministry of Defence (ref. Annexure 1(A) & 1(B))
b. Department of Space
c. Ministry of Home Affairs (ref. Annexure 1(C) & 1(D))
d. Ministry of External Affairs
e. State Maritime Board
f. State Coastal Zone Management Authority / Ministry of Environment &
Forests and Climate Change, as the case may be (ref MoEF&CC website)
g. Any other relevant Ministries / Institutions as required in future and
accordingly notified by NIWE.

4. The applications as per prescribed formats/guidelines of the respective Ministries/
Departments shall be routed through NIWE (Ref: Annexure 1). In case, prescribed formats
are not available, the application will be made through a formal letter to the concerned
Ministry. NIWE will only act as a facilitator for such clearances; however, the decision on
the application will be prerogative of the concerned Ministry/Department.
(i)

NIWE would issue the Letter of Consent (Ref: Annexure 2) to the private
developer after requisite clearances from all concerned Ministries /
Page 1 of 40

<!-- page 2 -->

File No.225/3/2018-Wind-Part(2)

Departments. This 'Letter of Consent' would be valid for a period of six
months and extendable to a maximum of one year. The private developer must
commence the survey activity within this period.
(ii)

Offshore wind energy related data can be collected by any offshore wind
developer only with prior permission of NIWE/MNRE. Interested private
entities will be allowed to collect the wind data only, before finalization of
bids. They will however not be allowed to collect the undersea oceanographic
and bathymetric data before finalization of bids. Only the winning bidder will
be considered to carryout detailed survey for collecting oceanographic and
bathymetry data only after issue of Letter of Award (LoA).

(iii)

A monitoring committee under the chairmanship of DG, NIWE will be
constituted to monitor the progress and recommend necessary action in case of
unsatisfactory progress of a project.

(iv)

NIWE has the rights to refuse permission to an entity on grounds of national
security without giving specific details/reasons. NIWE also has the right to
refuse certain areas for offshore wind power assessment studies and surveys.

(v)

The data/information so collected through the exercise would be shared with
NIWE. The private surveyors/developers will submit an undertaking to NIWE
(Ref: Annexure 3) to the effect that any data/ information collected through
surveys and studies under permission granted by NIWE will not be concealed
or suppressed from NIWE. In addition, they will also give an undertaking that
they will not undertake any other activity which has potential to damage
environment and compromise security of the country within the allocated area.
This undertaking shall be submitted to NIWE before issuance of Letter of
Consent.

(vi)

Procedure, methodology, equipment, height of the mast (Maximum height of
200 m) / LiDAR measurements shall be followed as per standards adopted
(Ref: Annexure 4) and accepted universally for all private developers, for
carrying out wind resource assessment study on their own. The measurement
should be adequate with wind data for a minimum period of one continuous
year (Uninterrupted). Data availability of minimum 90% is to be ensured.

(vii)

The private developer shall inform to NIWE the geo- coordinates, nearest
available port, the name of the coast for the location where it is proposed to
install the Mast / LiDAR.

(viii)

The maximum seabed area allocated for up to 200m mast will be 300m x
300m. The seabed area allocated for LiDAR measurements will be an area
with 20 m radius around the point location. However, the requirement of
additional footprint area will be allowed on case to case basis.

(ix)

The raw wind data as collected, in convertible binary / ASCII formats (Ref:
Annexure 5) shall be submitted by the private surveyors/developers to NIWE.
In case the developer wants the data to be certified, the submitted data on the
wind, oceanographic/bathymetric will be examined and certified by NIWE
Page 2 of 40

<!-- page 3 -->

File No.225/3/2018-Wind-Part(2)

with reference to the details submitted by them on the wind monitoring station
under appropriate agreement (Ref: Annexure 6) between the private
surveyors/developers and NIWE for which NIWE will charge a fee of Rs. 5.0
lakh (plus GST as applicable) to be paid as advance in full.
NIWE will have unconditional rights for the use of survey data and maps for
the purposes of the International Competitive Bidding / other government
purposes. However, NIWE would seek prior approval of MoD for usage of
oceanographic and seabed data for the purpose of International Competitive
Bidding.
(x)

NIWE would retain the option for offering the same area to more than one
company, should an interest be expressed or for expediting the survey. The
allocation of the particular point location will be based on guidelines.

(xi)

The private surveyors/developers shall have no right to allocation of offshore
wind block on account of the surveys and studies carried out by him.
Allocation of offshore wind energy blocks will be done through International
Competitive Bidding (ICB) only.

(xii)

All data of the site will be treated as part of NIWE data bank and can be
utilised by NIWE for development of the offshore wind energy.
NIWE/Ministry would be at liberty to invite bids for setting up wind power
projects in such sites.

(xiii)

The private surveyors/developers will have a right over the data. However,
they will not be permitted to generate revenue by selling data to any third
party. The data shall be treated as confidential and property of Government of
India and shall not be shared with any other entity except the Government of
India. After the bid/after the project is established, the data shall be handed
over to Government of India in toto.

(xiv)

On completion of measurement, any permanent / temporary structures and
floating materials (debris) shall be properly collected and disposed as per the
regulations of CRZ / Maritime operations. NIWE may seek refundable
financial guarantees from the private investor for decommissioning activity.

(xv)

A detailed design and methodology of installation should be submitted to
NIWE before taking up the project and as-built drawings should also be
submitted after completion of work.

(xvi)

In case of any ambiguity in interpretation of any of the provisions of these
Guidelines, the decision of NIWE shall be final.
DG, NIWE

To
All concerned Ministries / Departments.
Annexure 1

Page 3 of 40

<!-- page 4 -->

File No.225/3/2018-Wind-Part(2)

Application Form
(To carry out Non-exclusive Offshore Surveys/studies in Indian territorial
waters/ Exclusive Economic Zone of India)
1. Company details
Name of the company
Registered office
Address
Experience in carrying out Offshore related surveys/similar oceanographic studies
Email
Contact telephone
Fax No.
2. Survey details (Use separate sheet if necessary)
Details of the survey
Area
Location (Proposed Geographical Coordinates)
Proposal
3. The method of measurement (met mast or Remote sensing instrument)

4. List of Major Equipment to be used
Equipment Name:
Make / model:
Sl. No:
Calibration status:
Claibration due :
5. Application fee details
Demand Draft No.
Name of bank
Amount
Date of issue
6. Contact person details
Name
Position
Nationality
Address in India
Email
Contact telephone
Fax No.
Signature

Contd..
Annexure 1 (contd.)
Page 4 of 40

<!-- page 5 -->

File No.225/3/2018-Wind-Part(2)

7. Authorised signatory details
Name
Position of Signatory
Nationality
Email
Address
Contact telephone
Fax No.
Signature

Note:
i.

ii.
iii.

iv.

v.
vi.
vii.

viii.

The full registered name of the company shall be mentioned in the Application
Form precisely as mentioned in its Certificate of Incorporation and the copy of
valid Certificate of Incorporation shall be enclosed. In case the work is
outsourced to a vendor, the 'Company Details' of the vendor should also be
attached separately.
The Application Form shall also enclose the proposal details mentioned at
Survey details (Sl. No 2) with all relevant documents.
The Application Form must be accompanied with a fee of Rs.1,00,000/- (plus
GST as applicable). The payment of the non refundable Application fee should
be payable by crossed A/c Payee‘s Bank Draft / Banker‘s Cheque drawn in
favour of National Institute of Wind Energy, Chennai, payable at par at
Chennai.
The Contact person is an authorized representative of the company in India
and his address must be a valid physical address within India for
correspondences relating to this Application. Letter of Authorization to this
effect shall also be enclosed.
The Application Form must be signed by the authorized signatory of the
company and Letter of Authorization to this effect shall also be enclosed.
By signing the Application Form, the authorized signatory declares that the
information provided in the Application Form is true and correct.
In case the space in this Application Form is insufficient to include all relevant
details, state ―see attached sheet‖ appropriately and attach extra sheets to the
Application Form.
The duly completed Application Form should be forwarded to The Group
Head (WRA&O), National Institute of Wind Energy, 657, Velachery
Tambaram High Road , Pallikaranai - 600 100

Page 5 of 40

<!-- page 6 -->

File No.225/3/2018-Wind-Part(2)

Annexure 1(A)
Guidelines for MoD Clearances in respect of Vessel deployed to conduct Offshore
Wind Power Assessment Studies and Surveys.
1. At least two months clear advance notice of commencement of Study/Survey/
exploration work should be given to MoD through NIWE so that the work does not
clash with any defence exercise in the area. Applications to be submitted to NIWE at
least 2.5 months before for processing by MoD {IHQ MoD (Navy)}
2. NIWE is to forward proposal for deployment of a vessel to MoD {IHQ
MoD(Navy,)/DNJ, at least six weeks in advance, from the scheduled deployment date
of the vessel to facilitate MoD Security Clearance, Naval Security Inspection (NSI) and
Naval Security Clearance (NSC).
3. Indian Companies should preferably be deployed for surveys should foreign companies
be deployed, prior security clearance from Ministry of Home Affairs (MHA) is to be
obtained for the crew by the Licensee.
4. A vessel deployed for conducting Offshore Wind Power Assessment Studies and
Surveys, by the Licensee shall undergo Naval Security Inspection (NSI) under the aegis
of concerned Naval Command/Headquarters Offshore Defence Advisory Group (HQ
ODAG)/ODAG Cell, prior to her deployment.
5. The vessel is to engage in bonafide task only. Data is to be collected under supervision
of appropriate NIWE representatives, who is to ensure security safeguards against
collection of physical oceanographic observations and seabed studies by the vessel. No
physical oceanographic observations or seabed studies will be undertaken by parties,
without specific clearance of Ministry of Defence.
6. Data collected during the survey is to be processed utilising onboard processing
facilities, or other facilities available in India. Raw / Processed data is not to be handed
over to any third party, without prior approval of MoD.
7. Copy of data collected is to be forwarded to the Chief Hydrographer at NHO, Dehradun
and the Directorate of Naval Oceanology and Meteorology (DNOM), IHQ MoD
(Navy), Room No. 4, Ground Floor, Talkatora Stadium Annex, Talkatora Garden Road,
New Delhi-1100 01 free of cost by the Licensee, within one month of the completion of
the processing of the data.
8. The Licensee is to expressly, liaise with Local Naval Authorities/HQ ODAG/ODAG
CELL for issuance of NAVAREA warnings, indicating the following details in respect
of the vessel, with a copy to NIWE:
(a)Area of operation (precise geographical coordinates in WGS 84 format to be
indicated).
(b) Duration of operation.
(c) Safety precautions required to be adhered by the other vessels transiting through the
area.
9. The licensee shall ensure that all foreign personnel onboard vessel have been duly
cleared by Ministry of Home Affairs and Immigration Authorities. Licensee is to
produce clearances documents to the Naval Inspection Authorities, as and when,
required.
10. For the development of new roads and tracks related to survey activity, prior sanction of
the concerned agency will be obtained.

Page 6 of 40

<!-- page 7 -->

File No.225/3/2018-Wind-Part(2)

11. The Surveying Company shall strictly adhere to the relevant provisions and
notifications under Environment Protection Act, 1968 and Forest Conservation Act,
1980 as amended from time to time.
12. The licensee shall take all precautionary measures for safety and security of all vessels
deployed for survey activities as per laid down National and International Laws.

Page 7 of 40

<!-- page 8 -->

File No.225/3/2018-Wind-Part(2)

Annexure-1(B)
List of documents to be submitted for security clearance / naval security inspection to
conduct offshore wind power assessment studies and surveys
SL. NO
1
2
3
4
5
6
7
8
9
10

11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30

Documents/Certificates
REMARKS
RSEE Pro forma duly filled and signed by the Operator.
Enclosure-I
General Trading License/Specified Period License
As applicable
Certificate of Registry.
As applicable
Certificate of Classification
As applicable
Cargo Ship Safety Construction Certificate
As applicable
Safety Equipment Certificate
As applicable
Oil Pollution Prevention Certificate
As applicable
International Load Line Certificate
As applicable
List of equipment / specifications of vessel duly signed by the
As applicable
Master
Crew list giving details of Designation, Nationality, Passport
No. and CDC/Seaman's Book No. and signed by the Master.
MoHA/IB clearance certificate / letter from the operator in
respect of foreign nationals
Area of operation and duration of deployment along with
work schedule
Colour photograph of the vessel
Letter of Consent issued by NIWE
ISPS Compliance Certificate
Where applicable
Concise description of job / work to be undertaken by the vessel.
Area of operation with geographical co-ordinates and duration of
deployment.
Details of job (duration, nature of work etc.) if the vessel has
been deployed in neighboring countries.
IHQ MoD (N) clearance
At the time of NSI
Tonnage Certificate.
Safety Management Certificate.
Document of Compliance (DOC)
Insurance Certificate.
NAVAREA warning issuance letter.
Use of Satellite Phone Certificate to be obtained by NSI Team
Enclosure — II
from Master and Charterer / Agent.
At the time of NSI
Non Possession of Thuraya and Iridium Certificate be obtained by Enclosure - ill At
NSI Team from Master and Charterer / Agent.
the time of NSI
Sealing of equipment / Machinery Certificate be obtained by
Enclosure - IV At
NSI Team from Master and Charterer / Agent.
the time of NSI
Arms / Ammunition and Dangerous Cargo Certificate be obtained Enclosure V At
by NSI Team from Master and Charterer / Agent.
the time of NSI
Format for Undertaking
Enclosure VI
Format for Certificate
Enclosure VII
Certificate to be given by Survey Vessels
Enclosure VIII

Page 8 of 40

<!-- page 9 -->

File No.225/3/2018-Wind-Part(2)

Enclosure-I
Refer to Annexure 1(B)
Part I
(TO BE COMPLETED BY THE OPERATOR)
Proforma for MoD clearance Research, Survey, Exploration, and Exploitation
(RSEE) of Resources in Maritime Zones of India (MZI)
1.

Name and address of the Operator.

2.

Name of the JV Partners / Consortium Members

3.

Contact No.

4.

Sponsoring company registered in India / abroad

5.

Nationality of the Sponsoring Company

6.

The nature & objectives of the project.

7.

The precise geographical areas / blocks in which the
activities are to be conducted.

8.

Type and category of vessel

9.

The proposed ship's track from the time the ship leaves
the last foreign port until it arrives the destination. (Attach
Track Chart)

10.

The expected dates of commencement and termination of
the project. (Attach schedule of activities)

11.

Duration for which MOD security clearance is required.

12.

Particulars of the vessel / platform (Attach details as per
Format A)

13.

Details of the equipment to be used for Project. (Attach
details as per Format B)

14.

Indian personnel / observers, associated with the project to
embark the vessel / platform on a no cost basis. (Attach
nominal roll as per Format C)

15.

Will the Indian personnel be permitted and assisted to
handle the equipment fitted on board, record observations
or gather samples?

16.

Is the organization prepared to accept any temporary
installation of Indian equipment on board the vessel at the
expense of the Govt. of India?

Page 9 of 40

<!-- page 10 -->

File No.225/3/2018-Wind-Part(2)

Undertaking:
I / We hereby undertake:
(a)
(b)
(c)
(d)
(e)
(f)

(g)

(h)
(i)

(j)
(k)
(l)

To engage in only bonafide activities as permitted by the GOI.
To associate Indian Scientists / Observers nominated by GOI with the
activities and afford them all facilities, on a no cost basis.
To provide data to the GOI / authorized agency as specified in the letter of
consent on completion of wind power assessment studies and surveys.
That data collected and analysis thereof, shall not be published or
disseminated to any third party, without prior concurrence of the GOI.
To provide GOI with periodical reports as prescribed on wind power
assessment studies and surveys.
To make no changes or alterations in the programme for wind power
assessment studies and surveys as approved by the GOI without its express
approval.
To present all vessels / platforms for inspection by GOI / Authorized
Agencies prior to their deployment in the coastal/MZI, or at any time,
thereafter as desired by the GOI.
To communicate on channels authorized by the GOI and Transmit /
disseminate real time data only with the prior concurrence of the GOI.
The subject wind power assessment studies and surveys shall not provide or
form any basis (both legal or another) for any claim on the sea area or part
thereof, or its resources (both living and non-living) in the coastal/MZI.
To abide by all terms & conditions stipulated by the GOI and its exclusive
right to terminate the wind power assessment studies and surveys at any time.
To provide GOI with any additional information or details as may be required
from time to time.
That, licensee or the vessels is not undertaking RSEE activities in Pakistan
and China.

Name:
Designation
Place:
Date:

Page 10 of 40

<!-- page 11 -->

File No.225/3/2018-Wind-Part(2)

FORMAT – ‘A’
PARTICULAR OF VESSEL / PLATFORM
1.

Name

2.

Type

3.

Signal letter

4.

Port of Registration / IMO No.

5.

Length

6.

Draught

7.

Gross Tonnage

8.

Speed
(if applicable)

i) Economical
ii) Maximum

9.

Endurance (if applicable)

10.

Means of propulsion
(Diesel, Steam, Nuclear)

11.

Name of Master(s)

12.

Number of Ratings
(Attach nominal roll with details of
designation, nationality, passport, CDC
etc,)

Page 11 of 40

<!-- page 12 -->

File No.225/3/2018-Wind-Part(2)

FORMAT – ‘B’
DETAILS OF EQUIPMENT
1.

2.

Details of Navigational Equipment
(a)

Magnetic compass

(b)

Gyro compass

(c)

Auto pilot

(d)

Radar

(e)

Echo sounder

(f)

GPS navigator

(g)

Direction finder

(h)

Speed log indicator

Details of communication equipment
(a)

Mobile emergency, VHF aircraft

(b)

Emergency auto alarm receiver

(c)

VHF Trans receiver

(d)

MF/HF trans receiver

(e)

SATCOM

(f)

Radio sets including MMB / GMDSS set

(g)

Aerials

(h)

Encryption equipment

(i)

Any other equipment

Page 12 of 40

<!-- page 13 -->

File No.225/3/2018-Wind-Part(2)

3. Details of divings / salvage equipment

4.

5.

(a)

Mixed gas saturation system

(b)

Bell and launching system

(c)

Main compression chamber

(d)

Hyperbaric lifeboat

(e)

Gas reclaim unit

(f)

Decompression chamber

(g)

Gas transfer unit

(h)

Gas compressors

Details of fire-fighting equipment
(a)

Classification and rating

(b)

Fire monitors

(c)

Pumps, Number, Output

Details of Research / Survey equipment
(a)

Bathymetric

(b)

Magnetic

(c)

Gravity

(d)

Geological

(e)

Biological

(f)

Chemical

(g)

Seismic

(h)

Metrological

(i)

Oceanographic

(j)

Physical (Temp, Current, Conductivity)

Page 13 of 40

<!-- page 14 -->

File No.225/3/2018-Wind-Part(2)

6.

Details of submersible equipment
(a)

Name of equipment

(b)

Propulsion

(c)

Manually / Remotely

(d)

Maximum operating depth

(e)

Communication channel

(f)

Purpose of deployment

(g)

Duration of deployment, periodicity, etc.

(h)

Electronic devices

(i)

Processing devices

Page 14 of 40

<!-- page 15 -->

File No.225/3/2018-Wind-Part(2)

FORMAT – ‘C’
NOMINAL ROLL OF THE PERSONNEL

Sl.
Full Name
No.

Designation/
Date of
Nationality
Rank
Birth

CDC
No.

Passport
No.

Expiry of
Passport

Page 15 of 40

<!-- page 16 -->

File No.225/3/2018-Wind-Part(2)

PART – II
(TO BE COMPLETED BY NIWE)

1.

Deficiency of documents – Nil / attached list (if any)

2.

In principle approval accorded / recommended for MoD approval

3.

Deviation List (if any) attached

4.

Name, Address and contact details of the contractor

Name:
Designation:
Place:
Date:

Page 16 of 40

<!-- page 17 -->

File No.225/3/2018-Wind-Part(2)

PART – III
(TO BE COMPLETED BY IHQ, MoD (NAVY))

1.

Deficiency of documents observations - Nil / Attached list (if any)

2.

MoD Approval NI …………………… Dated ……………

3.

Approved Works to be undertaken

4.

Approved Area of Operation

5.

Approved Period of Operation

6.

List of Conditions (Attached)

Name:
Designation:
Place:
Date:

Page 17 of 40

<!-- page 18 -->

File No.225/3/2018-Wind-Part(2)

PART – IV
(To be filled by the operator)
Proforma for naval security clearance for vessels to conduct offshore wind power
assessment studies and surveys

1.

Name of vessel

2.

Code of vessel (As per Data Bank)

3.

previous NSC no.

4.

Operator

5.

Company

6.

Flag

7.

Crew Indian/ Foreign/ Total

8.

MoHA clearance for foreign crew

9.

Agent

10.

Specific Period License/General Trading License no.

11.

Area of operation/co-ordinates

12.

Nature of operation/ activities

13.

Duration of operation/W.E.F

14.

MOD clearance letter no and date

15.

List of documents forwarded on----------------(as per format 1-A)

16.

Proposed date

and place

of inspection

17.

Contact number and N ame of authorized rep.

Page 18 of 40

<!-- page 19 -->

File No.225/3/2018-Wind-Part(2)

PART – V
(For office use only)
(TO BE COMPLETED BY HQ ODAG/ODAG CELL)

DATE, TIME AND PLACE OF NAVAL SECURITY INSPECTION

NAME:
DESIGNATION:
DATE:

Page 19 of 40

<!-- page 20 -->

File No.225/3/2018-Wind-Part(2)

PART-VI
(To be completed by inspection team)
It is to certify that we have jointly carried out naval security clearance inspection
of …………………. on ………………………and established that:
a. the vessel is bonafide after examination of authority letters / permission letter/
certificates issued by concerned ministries/ DG shipping for designated task.
b. The capabilities of the vessel are in consonance with the approved task for
which clearance has been given by IHQ MoD (N).
c. The vessel does not have any capability to undertake surveillance,
unauthorized data collection/oceanographic survey tasks etc.
d. The vessel does not have the capablity to carry out any unauthorized economic
activity within the EEZ.
e. The vessel is not intended/equipped for any illegal/ anti national activity.
f. The vessel does not have any explosives or dangerous cargo, which may be
hazardous whilst in Indian waters.
g. The machinery/equipment fitted on board are as per proforma (Enclosure-I)
h. the essential characteristics of the vessel are as per the
declaration in
proforma (Enclosure-I)
i. Verified identity of foreign crew with passports / identity cards.
j. Verified the details of Indian crew.
k. Examined the track charts, logs, cipher and code.
l. All machinery / equipment fitted on board with type, make, frequencies,
range, performance/ parameters, etc., are checked against the list supplied
by the operator as indicated in proforma (enclosure-I) so as to ensure that no
specialized instrumentation, observation equipment, electronics capable of
recording and monitoring data with
naval implications and
other
sensors are fitted on onboard for clandestine purpose.
m. No EW equipment of any description are fitted on the vessel.
n. No under water sensors other than those included in (enclosure-I) are fitted.
o. Equipment,
which
are
not
considered
essential
for
safe navigation/communication and operations onboard are not fitted.
p. Ministry of Home Affairs (MoHA) clearance of all foreign personnel
employed on board has been obtained by the operator.
q. A representative of the Govt. of India /NIWE is available onboard the
vessel engaged in survey activities.
Date:

Name:

Place:

Designation:

YES

2. The vessel…………. .is/ is not recommended for accord of security clearance to operate in
…………….(area) on …………………….. (task) from ……………..to……………..
Officer-in-Charge
Naval Security Inspection Team
Page 20 of 40

NO

<!-- page 21 -->

File No.225/3/2018-Wind-Part(2)

PART – VII
(TO BE COMPLETED BY HQ ODAG/ODAG CELL)

1. The vessel …………………………………. has been / not been security cleared to
operate in …………………………… area on ………………………………… (task)
…………………….. from …………………………to ………………………..(date).
2. Awarded NSC no. ……………………………………………………..
3. NSC letter / fax no.

(attached)

Date:

Name:

Place

Designation:

Page 21 of 40

<!-- page 22 -->

File No.225/3/2018-Wind-Part(2)

Enclosure - II
(Refer to Annexure-1 ‘B').

CERTIFICATE - USE OF SATELLITE PHONE
1. Name of Vessel
2. Satellite Phone
3. Details of Satellite Communication

(a) Satellite Network (INMARSAT, FBB, Mini-M,
VSAT Iridium, Thuraya, etc.)
(b) ID No.
(c) Make and Serial No.

:
:
:
:
:
:

4.

DoT clearance for Satellite Phones for other than INMARSAT,
FBB & Mini-M (Licence Attached)
:
5. Status of Satellite Communication equipment
:

Charterer / Agent

Master

Page 22 of 40

<!-- page 23 -->

File No.225/3/2018-Wind-Part(2)

Enclosure III
(Refer to Annexure 1 ‘B')

CERTIFICATE
1. Refer to DGS Order no. 02/2012.
2. It is certified that vessel……………… is not fitted with Thuraya, Iridium and any other
such Satellite Phones and the crew onboard are also not in possession of Thuraya, Iridium
and any other such Satellite Phones, which have been banned for use in the Indian Waters.

Charterer / Agent
Master

Page 23 of 40

<!-- page 24 -->

File No.225/3/2018-Wind-Part(2)

Enclosure - IV
(Refer to Annexure 1 ‘B’).

CERTIFICA TE
TO BE SIGNED BY 0i/C NSI TEAM AND MASTER
1. It is certified that equipment (indicate details) ………………………….ID
No………………………… onboard …………………………….was / were sealed by the
Naval Security Inspection Team on…………….
2. The above equipment (VSAT, Iridium, ROV, etc.) would hitherto be unsealed only by
Naval Personnel (after getting license from DoT for VSAT) or after vessel demobilization
and inspection by Naval Personnel.

Master

0i/C NSI Team.

Date:
Place:

Page 24 of 40

<!-- page 25 -->

File No.225/3/2018-Wind-Part(2)

Enclosure - V
(Refer to Annexure 1 ‘B’).

DECLARATION

I,…………………….. Master of ………………………….., do hereby declare that the
vessel or any of the crew are not carrying any Arms, Ammunitions and Dangerous Cargo
onboard.
OR
I……………………….., …………………………….Master of , do hereby declare that the
vessel or any of the crew are carrying following Arms, Ammunitions and Dangerous Cargo
onboard:(Details)
(a)………………………………………
(b)………………………………………
(c) …………………………………………
*Strike out whichever of above is not applicable.

Master
Date:
Place:

Page 25 of 40

<!-- page 26 -->

File No.225/3/2018-Wind-Part(2)

Enclosure - VI
(Refer to Annexure 1 ‘B’)
UNDERTAKING
I, ……………………………………Master of……………………………….. , do hereby
certify the following :(a) Vessel does not have any capability to undertake surveillance/ unauthorised data
collection/oceanographic survey tasks, et al.
(b) Vessel does not have the capability to carry out any unauthorised economic
activity within the Indian EEZ.
(c) Vessel is not intended / equipped for any illegal/ anti-national activity within the
Indian EEZ.
(d) Vessel does not have any explosives or dangerous cargo which may be
hazardous whilst in Indian waters.

Master
Date:
Place:

Page 26 of 40

<!-- page 27 -->

File No.225/3/2018-Wind-Part(2)

Enclosure - VII
(Refer to Annexure 1 ‘B’)

CERTIFICATE
I,
…………………………………………………..Master
of……………………………………………….. ,do hereby certify the following :
(a) No ESM/search receivers for gathering ELINT/ COMINT Data are held onboard.
(b) All equipment/aerials fitted/held onboard are as per list submitted by the operator with
the MoD security clearance pro forma.
(c) Make, type, and frequency ranges in respect of MF/HF Tx/Rx held onboard are as
follows:I.
II.
III.
IV.

……………..
………………
………………….
………………..

(d) Encryption equipment held onboard (Give details) will be utllised for (State Purpose).

Master.

Date:
Place:

Page 27 of 40

<!-- page 28 -->

File No.225/3/2018-Wind-Part(2)

Enclosure - VIII
(Refer to Annexure 1 ‘B’)
CERTIFICATE TO BE GIVEN BY SURVEY VESSELS
1. Chartered By
2. Name of Ship
3. Port of Registration
4. Name of Owner
5. Name of Agent
6. Purpose of Survey
7. Area of Operation (Coordinates in Latitude and Longitude)
8. Observations of the following oceanographic data will not be made except when
specifically authorised by MoD (IHQ MoD (Navy)) (Please indicate against the parameter if
so authorised quoting authority):
(a) Temperature Profile
(b) Salinity
(c) Currents
(d) Ambient Noise
(e) Sound Velocity
(f) Reverberations

(k) Seismic Surveys
(I) Seabed Characteristics
(m) Sediment Characteristics
(n) Nature of Bottom
(p) Density
(q) Conductivity

(g) Transmission Losses
(h) Magnetic Parameters
(I) Gravity Parameters

(r) Ambient Noise and Ship Generated Noise Levels
(s) Acoustic Signal Range Limitations

9. In addition to the above, the following are also not permitted unless specifically authorised
by MoD {IHQ MoD (Navy))
(a) Physical oceanographic observations on grid closer than 30 NM interval viz. vertical
thermal profile, sound profile, salinity profile, sound velocity profile, density, conductivity,
etc. Further the stationary time series observation of any physical oceanographic parameter
except at synoptic hour and for currents for a period not exceeding 48 hrs at a particular
location.
(b) Observation for ambient and ship generated noise levels.
Page 28 of 40

<!-- page 29 -->

File No.225/3/2018-Wind-Part(2)

(c) Reverberation Observations.
(d) Use of submersibles.
(e) Acoustic signal range limitation observation.
(f) Transmission of Oceanographic Regional Telecommunication Hubs in the IGOSS ante
grated Global Data to Ocean Services System,).
10. Embedded raw data processing parameters which can give an indication of average
ambient noise, sound velocity in the water column, reverberation, and transmission loss will
be filtered out when processing.
11. No survey of any nature whatsoever will be conducted outside areas specified.
12. No unauthorised survey shall be carried out within the India's territorial waters.
13. No unauthorised survey and other investigations shall be carried out within the India's
Exclusive Economic Zone.
14. No unauthorised data will be taken out of India for processing or for any other purpose.
Entire survey data collected during the survey will be processed utilizing onboard processing
facilities or other facilities in India. Raw / processed data will not be imparted/Passed on to
any third party without prior approval of MoD.
15. We hereby certify that above vessel during the period of contract will strictly adhere to
the following conditions:(a) The vessel shall be engaged in bonafide activities only at the area designated.
(b) Raw data will be collected and processed under supervision of the designated
representative of the NIWE.
(c) Copies of processed data is to be forwarded to the Chief Hydrographer at NHO, Dehradun
and the Directorate of Naval Oceanology and Meteorology (DNOM), IHQ MoD (Navy),
Room No. 4, Ground Floor, Talkatora Stadium Annex, Talkatora Garden Road, New Delhi110001 free of cost by the Licensee, within one month of the completion of the processing of
the data.
(d) The Licensee will inform lHQ MoD (N) / Command HQ / HQ ODAG / ODAG Cell in
writing on proceeding of the vessel to any port outside India, subsequent to its security
clearance, on completion task and on leaving the deployment area.
(e) The Licensee/Master will intimate IHQ MoD (N) / Command HQ / HQ ODAG/ODAG
Cell immediately in writing of any change in equipment / personnel onboard.

Page 29 of 40

<!-- page 30 -->

File No.225/3/2018-Wind-Part(2)

(f) The vessel will be presented for re-inspection by Indian Naval Authorities on following
occasions:(i) On return from any port outside India.
(ii) On change of any equipment onboard,
(iii) As and when required by Naval Authorities.
(g) The Licensee / Master shall liaise with Local Naval Authorities / HQ ODAG / ODAG
Cell for issue of NAVAREA warnings, indicating details of the task being undertaken by the
vessel, and the safety precautions, required to be adhered by the vessels transiting through the
area.
(h) All personnel onboard as per the list attached have been duly cleared by the Ministry of
Home Affairs and Immigration Authorities in India. No extra persons will be added, without
prior clearance of MHA and Immigration Authorities.
(j) The vessel is not fitted with any data networking/ transmission system.
(k) The data collection will be carried out as per the MoD guidelines.
(l) No undisclosed equipment, arms, ammunition, and dangerous cargo is held on board.
(m) The vessel/licensee will pass its Position, Course, and Speed to MOC ……………by
fax/e-mail daily at,..................
(n) Following unauthorised equipment have been sealed/ offloaded……………………..

Authorised rep of licensee

Master

Date:

COUNTERSIGNED
Officer-in-Charge
Date:

Naval Security Inspection Team

Page 30 of 40

<!-- page 31 -->

File No.225/3/2018-Wind-Part(2)

Annexure 1(C)
(For MoHA clearances)
SECRET

Self Declaration for company and Director(s) for whom security clearance is sought
a. Name and address and registration number of the company
b. Name and address of owners, promoters and directors of the company
1. …………………………………………………..
2. …………………………………………………..
3. ……………………………………………………
4. ……………………………………………………
c. Is the company owners, promoters or directors listed above, the subject of any
1. Preventive detention proceedings (PSA/NSA, etc.)

:

Yes / No

2. Criminal Proceedings

:

Yes / No

d. If Yes, please provide following details:
1. Detention / Case / FIR / Warrant Number
2. Police station / District / Agency
3. Section of law
4. Name and place of the court
e. The above mentioned details are in respect of both India and any other foreign
country.
Note: The above self declaration is required to be filled and signed by the authorized
signatory of the company.

Page 31 of 40

<!-- page 32 -->

File No.225/3/2018-Wind-Part(2)

Annexure 1(D)
(For MoHA clearances)
Application proforma for Security Clearance (others proposals)

I. Details in respect of Company / Firm (Indian / Foreign)
Sl. Full name of the Date
of Address of Head Office, Previous name of the Details of earlier Complete details
No. company and its registration of Regional Offices and company, if any
approvals, if any about the proposed
foreign collaborator, the company
Registered Office
(ref.no & date)
activities.
if any.

II. Details in respect of Directors / Key Executives
Sl. Full name of the Board of Present position Date
No. Directors
and
Key held with date Birth
Executives
(Wherever (since when)
applicable)

of Parentage

Present
Permanent
Address

& Nationality

Passport
Nos.
and
issue date, if
any.

Contact
address
telephone
number.

&

III. Details of Criminal cases, if any, against the Company / Director(s)

Page 32 of 40

<!-- page 33 -->

File No.225/3/2018-Wind-Part(2)

Annexure 2
Letter of Consent

No. NIWE/WRA&O/OWPP/<Proj. Name>/<Year>

Date:

To
<Addressed to applicant>

Sub: Letter of Consent for carrying out Offshore Studies And Surveys at
_______ –reg
Ref: Your application for carrying out the studies and surveys vide no. dated
Dear Sir / Madam,
With reference to your application, approval has been accorded by concerned Ministries /
Departments of Government of India, You have been accorded clearance for carrying out the
following studies at the location (Lat: ____ Long:____ ).
I)
a.
b.
II)
a.
b.
III
a.
b.
c.

Wind Resource Assessment
Metrological Mast
Remote Sensing(LIDAR / SODAR)
Oceanography & Bathymetry
Geophysical Survey
Geotechnical Survey
Met – Ocean Studies
Wave
Tide
Current

Remarks
Timeline for
completion of
the activity
will be
indicated by
NIWE to the
private
developer.

Studies and Surveys------------- for which this consent is given should commence within six
months of issue of this letter, failing which the consent would be treated as withdrawn. In
exceptional circumstances an extension may be granted by DG NIWE.
Further, complete data as collected should be submitted to NIWE on -------(monthly/
quarterly/ annual/ completion of work). Non submission of data or incomplete submission of
data would lead to withdrawal of this consent. The data should not be shared with any other
private agency without specific consent of NIWE.
The letter of consent is subject to the strict adherence of the Guidelines for Offshore Wind
Power Assesment Studies and Surveys and other relevant Regulations imposed by various
ministries such as Ministry of Defence, Ministry of Home Affairs, Ministry of External
Affairs, Department of Space and the Government of India from time to time. Any Deviation

Page 33 of 40

<!-- page 34 -->

File No.225/3/2018-Wind-Part(2)

from the Rules and Regulations at any point of time may lead to the immediate cancellation
of this letter of consent.

Director General
NIWE

Annexure 3

UNDERTAKING
(To be signed by Authorised Signatory)

I, Dr./ Mr./ Ms.…………………………………son/daughter/wife of …………………
resident of ………………………………………………………………………………..
……………………………………………………………...….(full address) and presently
working as ………………………...…….in the……………………………………
…………………………….……………………………………………………………….
having obtained permission from NIWE for carrying out the measurements as detailed below:
………………..
………………
…………………
I/We hereby undertake that:
-

the offshore data collected will be passed on wholly to NIWE, MoD and NHO without
concealing or suppressing any data at no cost in digital form. NIWE will have the right to
use this data for International Competitive Bidding for allocating the offshore zones /
other government purposes.

-

the company will not indulge in any other activity within the allocated area other than the
purpose for which the Letter of Consent issued by NIWE.

-

the company will not undertake any other activity which has potential to damage
environment and compromise security of the country.

Page 34 of 40

<!-- page 35 -->

File No.225/3/2018-Wind-Part(2)

Signature………………………....
Date……………….

Name…………………………….
(Designation and seal of the organization)

Annexure 4
STANDARDS FOR OFFSHORE MEASUREMENTS
A) Meteorological Mast and instruments
1. The met mast should be able to withstand for basic wind speed of 50 m/s (180 kmph)
as per IS-875.
2. Mast should be designed as per IS800:2007.
3. Booms should be designed and installed as per IEC 61400-12-1 and
IS800:2007

as per

4. Cup type anemometer has to be used for the measurements. Along with cup
anemometer the developer may mount ultrasonic anemometer to measure 3D wind
profile at the higher height.
5. Instrumentation should be of the highest accuracy, and have least sensitivity to
changing atmospheric and environmental conditions. Anemometers should be ‗Class
1‘ as per the classification given in the latest edition of IEC 61400-12-1.
6. The primary (top-most) anemometer should be mounted using a vertical mounting
arrangement to ensure lowest possible flow distortion, as recommended in IEC
61400-12-1. The mounting of all instruments must be done as recommended in IEC
61400-12-1.
7. Wind speed measurements at multiple heights on the mast are recommended in order
to characterise the vertical variation of wind speed (wind shear) and add redundancy
to the system.
8. Anemometers should be calibrated at a fully approved MEASNET facility prior to
installation. Calibrations should also be conducted after the measurement campaign.
9. Traceability of the gathered data should be achieved through appropriate
documentation and quality systems
10. The met mast should contain all the weather measuring devices including pressure,
temperature, relative humidity, rain gauge and pyranometer.
B) Platform Mounted LiDAR
1. The existing Standards on measurements using remote sensing technologies do not cover
offshore remote sensing devices. The basic practices listed in IEA RP 15 (covering ground
based vertically profiling remote sensing), can be used as a guide for deployment of offshore
LiDAR on a fixed platform.
Page 35 of 40

<!-- page 36 -->

File No.225/3/2018-Wind-Part(2)

2. A pre- installation factory calibration of the LiDAR should be conducted. The LiDAR
should also be verified against a meteorological mast by an independent testing organisation,
both pre- and post- measurement campaign.
3. Installation of the LiDAR device should be such that no overhead obstructions interfere
with the laser or cause flow distortion in the measurement cone.
4. Calibration, installation and maintenance of the LiDAR device should be documented
throughout the measurement campaign.

Annexure 5
A. Verification of Procedure of Off Shore Wind Monitoring
The following details are to be furnished to National Institute of Wind Energy, Chennai.
1. SITE PLAN.
a. Photographs of the monitoring station from eight azimuth directions.
b. Survey of India map and Google Map on which the exact location of the station is clearly
marked (mention Geo coordinates - latitude & longitude) in WGS format.
c. Scaled site plan with immediate obstacles if any (<100m) clearly marked WGS format.
d. Give the location of nearest NIWE monitoring station /LiDAR location (if any) vis-à-vis
the station under consideration.
2. STATION INSTALLATION REPORT (Should be submitted within 10 days after
installation of wind mast/ LiDAR sub-structure)
a. The report shall contain detailed description of the site.
b. Height of the mast, height of sensors (anemometer, wind vane, temperature, pressure &
humidity sensors).
c. Foundation details both for LiDAR and mast.
d. Anemometer and direction sensor mounting arrangements.
e. Model and serial number of sensors and data-loggers.
f. Method ensured to set up direction sensor.
g. Date of installation and dismantling.
3. DETAILS OF INSTRUMENTATION
a. Manual readings are not acceptable.
b. Fully automatic data loggers shall be used. The data loggers must collect time correlated
time series data for wind speed and direction and other meteorological parametres etc. Details
of the instrumentation employed should be furnished.
c. All sensors used shall possess valid calibration certificates.
d. The calibration certificates shall be produced for verification within one month after the
installation of the mast.
e. In case of any instrument malfunctioning, it will be replaced immediately as per the above
details and the same will be notified to NIWE.
4. DATA COLLECTION, STORAGE AND PROCESSING
a. Data retrieval periodicity.
b. Methods used for data management and security.
Page 36 of 40

<!-- page 37 -->

File No.225/3/2018-Wind-Part(2)

c. Raw data files (Binary & ASCII) for verification. This shall be kept confidential by NIWE.
d. Details of software used for storage and management of data
e. Details of software used for analysis.
f. Monthly report and yearly report of wind data with joint frequency distribution.
5. OCEANOGRAPHIC / BATHYMETRIC DATA
a. Data retrieval periodicity.
b. Methods used for data management and security.
c. Raw data files (Binary & ASCII) .This shall be kept confidential.
d. Details of software used for storage and management of data
e. Details of software used for analysis.

Annexure 6

CONFIDENTIALITY AND NON-DISCLOSURE AGREEMENT
THIS CONFIDENTIALITY AND NON-DISCLOSURE AGREEMENT (―Agreement‖)
made and entered into this
by and between:
---------------------------------------------, (hereinafter referred to as the DISCLOSING
PARTY)
AND
NIWE, having its Office at Velachery – Tambaram Main Road, Pallikaranai,
Chennai – 600 100, Tamil Nadu, India (hereinafter referred to as the
RECEIVING PARTY)
(both the parties collectively hereinafter called as the Parties), shall govern the conditions
under which the Parties shall exchange non-public confidential, trade secret, or proprietary
information relating to the business of Disclosing Party. Confidential Information is defined
as:
(i)

(ii)
(iii)
(iv)
(v)

all non-public, confidential or secret processes, plans, formulae, data (including
cost and performance data), inventions, machinery, drawings, papers,
writings, specifications, manufacturing or design procedures and techniques,
methods, technology, know-how, programs, databases, source codes, devices
and materials related to the business, products, services or activities (either
existing or under development) of the Disclosing Party regardless of whether or
not any or all of the foregoing are, may or can be patented or copy righted;
marketing materials and sales collateral, operating processes, selling procedures,
pricing information, and sales volumes;
any supplier usages and requirements, and any list of clients, prospects,
customers, suppliers or business contacts;
information regarding the Parties‘ technical and professional staff,
including their qualifications and fields of expertise, or
any other information or aspect of or related to any of the trade, business,
finances, products, suppliers, technology, staffing or activities of the Disclosing
Party, which are non-public, confidential, secret or of a proprietary nature.

Page 37 of 40

<!-- page 38 -->

File No.225/3/2018-Wind-Part(2)

1. Purpose for disclosure (hereinafter Purpose): The Receiving Party shall evaluate the
Confidential Information of Disclosing Party. The Receiving party agrees (i) to make
no other use whatsoever of any Confidential Information of the other party provided
hereunder, and (ii) not to disclose the Confidential Information to others (except to such
of the receiving party‘s employees who reasonably require access to the Confidential
Information for the specific Purpose set forth above, and who are bound, in writing by
obligations of confidentiality substantially similar to those set forth in this Agreement).
2. The obligations of Paragraph 1 shall not apply to:
a.

Information that was in the receiving party‘s possession at the time of
disclosure, and which was obtained free from obligation to any third party;

b.

Information which is now, or becomes in the future, public knowledge other
than through acts or omissions of the receiving party;

c.

Information that was lawfully obtained from sources free from obligation to
any third party; and

d.

Information that is developed by the receiving party independently, without
access to the Confidential Information.

No combination of individual items of Confidential Information shall be deemed not
to be confidential, secret, or proprietary and subject to the obligations of Paragraph 1
merely because the individual items are subject to one or more of the above listed
exceptions; a combination shall be deemed not to be confidential only if the entire
combination itself is subject to one of the above listed exceptions.
3.

Upon the disclosing party‘s written request, the receiving party shall return
all Confidential Information in tangible form in its possession or shall
destroy all
Confidential
Information in
machine-readable form in its possession. The
receiving party shall certify in a written, executed document that all tangible
Confidential Information has been returned or that all machine-readable
Confidential Information has been destroyed.

4.

Nothing in this Agreement shall be construed by implication, estoppels, or otherwise
as establishing any type of commitment or right for either party to make any
commitment with, for, or on behalf of the other party.

5.

Nothing in this Agreement shall create, imply, or evidence any partnership or
joint venture between the Parties, or the relationship between them of principal
and agent. The Parties agree that they do not acquire any rights to use, and expressly
agree not to use, in advertising, publicity, or other marketing activities, any
name, trade name, trademark, or other designation of the other party, except
to perform authorized functions.

6.

Nothing in this Agreement shall restrict the Parties from using any ideas,
concepts, know-how, techniques, or information learned or retained by its personnel
from sources other than Confidential Information as part of their general skill,
knowledge, talent and expertise.

Page 38 of 40

<!-- page 39 -->

File No.225/3/2018-Wind-Part(2)

7.

The parties recognize that any breach of this agreement will result in irreparable
injury to the disclosing party and that monetary damages alone will be an
inadequate remedy in such case, and the receiving party therefore agrees that the
disclosing party may, if it so elects, institute and prosecute proceedings in any court
of competent jurisdiction, either in law or in equity, to obtain damages for any breach
of this agreement, or to enforce the specific performance of this agreement by the
receiving party, or to restrain or enjoin the receiving party from all activities in
violation of this agreement.

8.

No change in this Agreement shall be effective unless such change is mutually
agreed upon, in writing, by both Parties.

9.

This Agreement may not be assigned. This Agreement shall continue for the benefit
of, and shall be binding upon, the Parties hereto and their respective successors,
heirs, and legal representatives.

10.

This Agreement shall be deemed executed within, and interpreted in
accordance within the prevailing laws coming under the jurisdiction of the Courts in
Chennai.

11.

The obligations of the Parties under the terms of this Agreement shall remain in
effect for one year from the Effective Date hereof.

12.

Each party warrants to the other party that with respect to each item of Confidential
Information disclosed by such party to the other party pursuant to this Agreement,
such party shall have all rights, permissions, approvals, and authority necessary
for the lawful disclosure of such Confidential Information to the other party
and shall otherwise have full authority to enter into and perform its obligations
under this Agreement.

13.

The Agreement shall be governed by and construed exclusively in accordance
with Laws of India. The parties hereto shall endeavour to resolve all disputes arising
from or in connection with this Agreement, or the breach, amicably between
themselves. If the same remains unresolved within thirty (30) days from the
date of the matter being raised by either party, either party may refer the dispute for
settlement by arbitration.. The arbitration shall be carried out by the Secretary,
Ministry of New and Renewable Energy, Government of India, or his/her nominee.
The award passed by the presiding Arbitrator shall be final and binding on both the
parties. The arbitration proceeding shall be conducted in accordance with this
provisions of the Indian Arbitration & Conciliation Act, 1996. The
arbitration proceedings shall be held either in Chennai.
Courts in Chennai alone shall have the jurisdiction in respect of all matters arising
out of this agreement, which is incidental or consequential to the arbitration clause as
stipulated in this contract.

A person who is not a party to this Agreement has no right under the Contracts (Rights
of Third Parties) Act 1999 to enforce or to enjoy the benefit of any term of this Agreement.
IN WITNESS WHEREOF, the Parties hereto have caused this Agreement to be executed by
their duly authorized representatives effective as of the date and year first above written.
Page 39 of 40

<!-- page 40 -->

File No.225/3/2018-Wind-Part(2)

DISCLOSING PARTY

RECEIVING PARTY

-----------------------------

NIWE

Name: .............................

Name: ..................

Authorized Signatory
(organisation name and seal)
Effective Date:

Head, WRA&O

Page 40 of 40
