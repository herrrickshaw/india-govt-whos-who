---
doc_id: "b8eeee9edaaec85b"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2025/09/5258ed6e4e610c2ac2c625ab378d04d0.pdf"
ministry: "Department of Land Resources (DLR)"
title: "The DoLR invites applications for following posts on contractual/deputation basis for the World Bank Assisted Project (REWARD)"
date: "2025-07-21"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9dab300aceb3df1d"
---

<!-- page 1 -->

D-210161112024-Admn.
Government of lndia
Ministry of Rural Development
Department of land resources

'G'Wing, NBO Building,
NirmanBhawan, New delhi-'l 10001

".d

Dated:dt July,2025
CIRCULAR

The Department of Land Resources invites applications for following posts on
contractual / deputation basis for the World Bank Assisted Project 'Rejuvenating
watersheds for Agricultural Resilience through lnnovative Development' (REWARD):
No. of post

S. No. ame of post
1

2

of

ruitment

lnstitute & Capacity Building Expert
Hydrolog ist / Water Resources ExPert

One
One

ontractual
eputation

For eligibility criteria, i.e. educational qualification, experience, bio-data proforma
etc. athe ap[ticants are advised to refer to the official website of this Department

2.

https://dolr.gov.in.

3.

lnterested candidates may send their application duly signed (scanned/PDF)

throuoh e-mail at recruit.reward-dolr@gov.in only. The last day of receiving
apptic-ation is 15th day from the date of publication of Advertisement'

€.-t""--*;
(Th. Lianboi)
of lndia
Government
to
the
Secretary
Under
TelePhone No. 23044635

Oistribution
1

publicity
All Ministries/Departments of the Central Government with the request that wide
may be given to circular in their Ministry and in their Attached/ Subordinate
offtes/Auionomous organizations/Public Sector Undertakings/Statutory organizations/
Research lnstitutions and Universities

2

The Chief Secretaries of all State Governments and Administrators of Union Territories
with the request that wide publicity may be given

3

Nlc- DoLR, NIC - DoRD and Nlc - DoPT; with the request to upload the same on their

4

Notice Board/ e-Office dashboard/ Circular Folder

respective websites. And also create an email id for this purpose'

<!-- page 2 -->

RE.II'\'T,\-\'1'I\(; \\,\'I'ERSHED }'ORAGRI(]I. UI-I]R,\L RESILIE\CE I'IIROTIGII
I \ \O\"\'l l\' [- t)Ev H l.oP\l t.\'r ( RE\\.{R t))

t'llR\ls ol. Rf l;ERE\('1.
I \S',ilr't't'1()\ & (',\P\( l'l'\' Btr I l.Dl \.-G EXPE RT
BA( K(;ROI \l) ol" rHl: rRo.l}]( T
(;uvct'llntcnt ol' lnd il hus in rt iatcd a \\ii[ld t]lnk strpptrrtc' I
nrulli-Srate prtrjccl nantclv l{r'jurcnatrng \\'atcrshr:d lirr ,\grtcttllttral Rcsilicnet' thtuttgt
Innovutivc. D$,clopnrcnr (REWARD). lt is r,'xpected to Positivt'lv influcncc by prornorin,,r
Stutt' arrd
t.cs()urcc cllicienr gro\\'th in sr'lccted watcrsltetls. investing in htttllu capit:rl at
projcct rvill
Nutiorrul lcrcls. and rlcvcloping ttctu.orks ofscientitlc and tcchnical partllcrs. Thc
(.nhiulcc ltrlxltlcti\ itY ittld ll!'t illcollte ol fitrnlcrs atrd contritrttte significantll- ttt l-ighthouse
ln.liu bv irnPlenrcnling nc\\'scir,'r'ruc;rlltl tiirta-rlrircn upProacltcs lirrelimatc rc'silicnt $alclshcJ
()l'
,,,,,,ui.''rra,,,. litttrl Icsottrcc ttlrctttttrt. littttl Lt"e l)lllllllillg' lttttl preeisttrtl litrnling in il [allsc
aur,,-.'c,,l,,rrtcirlcrnl(lilir)1s rn purtrcipltirtu stltcs. I-ltr Pl()l!'(l \\'lll tlirt'etlr atldrcss ktl stratcgie
a..ti,,1s art,trrrtl irqriculttrylI irrrtl rurll de\ cl()pnlr'nt. inclutling douhling thrnrcrs' ittcotnes. ntore
crop l)sr tlrttll. rrctcr l(l c\,crv plot. stlil hcalth' rrntl plrtgotiott ol'cntrcprcllculship through
r".1.',,i."1 itntl llnaucill :llppot't tbr bcttcr tlclivcry aud itnpacts through iurprtxcd platttting
alrtl
xl)l)rQitfhcs. eupueitt builtling,. cootditlatiott and cotr\,crgcncc. and supportivc rcscarch
\
tl.'r'el,,pnrcrrr. l hc 6trlcgtttcs ilrc pt'!-\'cnti()rI rrl soil rrtn-o11. rcgcncratioll t.rl ttatttral cuctiltion.
lt
t.il1l \itl!'r. ltarrr.'sting itn(l rcclliltsinu ol'rhc grouutl \\ iltL'r tirbtc. lhis cnatllcs nrtt i-croPPillu
iclc stlstitinlblc
arrr.l the introtlttcli(rlt ()l dircrsc ast o-hilsctl lctiritics. u'hich ltclP to pror
I lr,,' D..p1rtnrc1l r.rl' Lturd lir.-spurccs.

lircliltoods to thc pcople rcsiditlg in thc rvatcrsltcd llca.
proposcd us a 6 vcar:'
rvhich
Pro.iecr. l'hc total ullocaliou lbr the Prtlicct is approxrlrlrtelY LISDl50 nrillion of
It tr\\'AI{D is hcing intplcnrcntctl in thrce to lirrrl lndian Statcs. It is

L Sl)1"x.: rnillion is Inr,,'rna( iorrit I [Jank lirr R!'c(rrlstrrlcli()ll antl [)cvtlqrnrcnt

(IBRD) loan

li()llllhc\\i,rlrlt]rrnklrtrtlthclritlttnc.:tslirrrtlcdbvll]f(i()\,crlllncnttrt.lndiitStatc
( ioverrtrt'tcrtts.

PRO.IEC'I' OI]J E\'TI \ ES AND R.ESI ] LTS
'fh,.. l)r.tljtct Dcr r--krltnrcrrl ( )b.iceti\c (PtX)) is l(): ittlnro\c litrtd ltnd \\illcr cr)nscr\iltl()ll illl(l
rcsili,.-ttcc in sclcetctl tlulcLsltctls, itntl rtteltU(ltctt cupacitics ol' natirlnal antl statc

ilirrrirtc

irrslrtuti., , to tlclrYr.-r nlor!. ctllcti\L'seicnc!'-bu:ctl rt'atcrsltr.'tl dclclolllltcttt l]rogrdllls'

KEY RT:SL'l-Ts

l'olcntial PD0 I rrrlic:rto r( s )

PDO Elerncnt
lnrl)rr )\

c(l land

(lulc(,ll)c5

ll'l

0llscrvi.ltl0ll
dcrttotr stfttt iott
e

Fcrccntau,J ,,1'tat -lreted wllt!-rshcd ar!'a sho$'ing an ittcreusc

irt Norntulizcd Ditjerr.'ncc' Vcg!-lillit)ll Indcs (\f)\II)

r elitrtrrte cllc'ets;
Inct,,'rttctttul chttttgc itt atrictrlt urc ltot't icu ll trt c protlLlct ir it1
rutttl ittcrttttt lirr sclr,'elerl ,. ttrlls
e( rflcel ll]g

. itcs

Ittt1,r,, r c.l

rrglic Lt lturl I

(rul(('tl'l!':

(l!'t tl()tl \t f il l i 0 l I

l

sitcs
1

:it€ No. o-?rol5/r/202/r-admn. (comPuter No. lorl757)
jen€rated from eoffi.e bY MEGH5HYAM SHARMA M.S, coNsuLTANr' DoLR on 2tlo7l2o25 ol'o9 om

<!-- page 3 -->

Itnrp,r,,*.t 't, ilt!'r ()tllc(lnlcs i|l I I)cI(ctllilgc rrl'tilt-uclc(l lattrlst trpc arelr sh6rr ine i11 ilCt.cit\e
tle ntr rttrt r:r tio n \tt!\
Ur l.iul(l S0t lite( \\;rler lrrtlcr ( l S\\'l )eorrcctittg lirr\.11111;11.
. c llcel\:

clit:lrtr.' r.\ilicnc\ ( ltrrttues ttt fc.ilt,,.rtt,.'trtrlct uontprrscrl (tl il \ct ol \ilrt;thlc\
In dclll(rn:'ll atl t()n co\ctit]s c\n(xutL'. scrtstlirilr. t{r alinrillt (.\!,nlr . t(l
irrliqrl ir r' e lpire ilr:

lrllPr('\ c(l
(|utcrrnlc\
siles

Strcngthcrrcti

\r illCtshc(l

institulionr

cliscrl prrlicir. lirr urrtcr.rltcti
Phlr:til!I\
R

l-

ttttctionitl tlctrr olks ol'scicnti lie pilt.lnct.:r in pnricet stirler-

llcri:,r:tl \:rtionrrl \\'alcrslrcrl (irritlclirrcs inlirrnreti trr
Ilol(Cl e\l\\'It(tt((.;1;111 1...l'11r 1,,.; 'tt,..tl llt,tl rr rll ,.:trt.l. rt..r,
llilt lrrrlill \\ itlCI\hCrl It'rrqs ;1111..

PROJECT ('O\tP0\t \'t s:
-l'he

llro.iect rrrll tlcphrr instiftrri,rrtirl iIl(l lcchlieitl solrrliorrs kr it(l(lt(\r, thc plX) ilcrr)\: lilul
C(rrnPon!'!ll\. .It(l (t\!.t rit rc.rr.. i|r l llrrrrr;

(-onrpont'nl l.lnrprorcrl \ario al \\arerrhtrl (iorrrn:rmcc
rr (t ln,ilirnrio,lrl (.aPrr.in
Building
This ctrmponcnt rrill slrcncrh,,.rr cap cirrc. irntl st.stcrrrs
Prirnirr.rlr rlr l)rrl.l{. lirr rlclt\c trg
ll:lti()tlal \\ alcrsllr:tl prrr-urirrlts. llte cr.,;11p1ys1g111 rrtll lrc tlclirerr:tl tht.r,uSlt l\\(r ruh_c, r|ll11r )ncI

l\

l.l

lnsrirutional srrengrhening and c pacit! brrirrring. r'hc sutr-crrruPrrncnr \\i
:ltt.-tt-!lltctt htrtltirtt rrr\('lI(u ,r)(l in\litutirrnltl cir|;r1.11i.,,. rtr l)r,l ll t(l
llli[1.
coo11l1;111q. rlcltrst, erirlrrlrlc, )(l IcP(lft (rll ntrrf( elli.ctrre. reicrtcc-h;rrcrl
|lrrlrrrrllrl
\\illcr\hc(l l)[(]gri |lS. lt rrrrttkl \[l]l)rrft \ct.itll
Ir()l((.1 I ( I I I t r.! ;rItl te l.r(}tlrIr.:
basr,-tl rtn corrt'(ltnitcd stxtu\ i||l(l nlr)tt|l(l[in! t.clrrflr lirrtll rt.rlrr
Techn0logl lr nsfrr.'l hc \ h-((rlt.ll)(]llcnl trrll \ pPort l)()l.R lo !(\,1(l1.lilte thc
irrrpror e,,l lrattslL'r rrl'ln.rrr lctltc ltrtl ctlrct.icllccr ;rct.rrss lrrrlilrrr rlalcr;rnd
llrrhl llr
lh11]uSh ttitli()n.tl xn(l inli|.|titlionitl rrrrt.lsllrr[., i (l ctl n lr,r.!,ttcc \. n(l
intcr;itl t(tnit l
Jtt(1 lt:ru(iltitl 5llt(l\ trrllr\ ('\l)o\Ur( \ l\it\
It

1.2

( onll)ollrn I !: lnrprrrrrtl Stalr \\;rlcrrhr.rl (,ortrnarrrt rmrl
tluikling.

, I

I

rrI

.

t

lrtrlitrrliorr;rl ( it l)a(it\

'I'l'tis

contlroncnt \\ill stlcn!.llhctl clrp:rcrlicr:rrtrl st.tcttts pnnlilrih ;rt rtrrtc lcrclr l1r pl rlrrrrr.
rttelhotlrrlos). tcclrnolrruv (l!'\clop )cnt. (lcfl \totr-sul)l.t{ rt.l krrrls. 1111q1 tlclircrr
rrrrxl.,l:.. llrc
c()nlpol')cnl \roul(l cnl\urc clirrrirlc chirn!c (.() si(lr,r.irlron\ itrc tturrillc(l
irrto lrll actir itlcr. llr!.
c(trllP()t)ct1l rr ill h!.(lclircr','(l tlrlorruh l(ln.\ul)-e()nll)rrncDt\:

2.1 lnsrirulional srrcngrhtni H {n(r ('nprcirr lruikrirrg. rr,. rurr-c rrrprrrenr \\t

!.2

strcnulllcn hunt: r rr:s,rUre( itn(l instiluli1lnitl t.irPlrertic: irt r.clcr itnl lirrc
del)atllnents at stitte. distriet rntl Iickl lcvcls to irrrplenrcrrt nlore dllr.(.li\e.ll(l
scicncc-trasctl llto{t;tttls itr rritlcrsltcrls. Iltc srrh-c,,rrtlr,rDcDl \\(rul(l
I)r.o\ i(lc
les()Utcr's t0 brriLl caPlrcitics li,r \tiltc rrnrl licltl lcrsl rirlL.grr rtls rrr!ct\t!ltt.
-Ii'chnical
slrlllrr)rl lr) slnlr.s. l.ollotrilt. lrght It,ttt'..',,t,tt.,',.',,. th( \irh( (rllllrr I n! tll $ tll lirr;rrrtt tlt!
l)itrttcilittt n ol tlrc hirr.ltirlirk,r \\rrtcr':ltctl
|)crcloprrrertl I)c|iutnlctll. tlrctr crIcricrrc,..tl scrcrtlrI ie iut..l tcclttticrrl lcl\\ or[ (rl
.

2
:il€ No. o-2rot6/l/?oz.-admn_ (compute.
No. 3or!757)
;enerated from €Offic€ bv tiEGHSHyAM SHARlllA. M.S,
CONSULTAIIT.

OOLR on zilorl2o25

ol:o9 Dm

<!-- page 4 -->

t()P e.rlrlr(r \(rcnlrtlc p r.tncrr. xlr(l ()tllct llrstlttltiolls a: n('c(lcd tt' hclp nr"$ l.}r'tricct

rtltct irl(l I )r'l.R prcpal,: thc pro;ccl lntl cstablish illltl tl'ilill thcir own Partners.
l.-r

2.J

llt,search :rrttl dt.reloptrrt'nl. lltc stth-eotttponctrt sill linltrec cristiltg scictttilic
irrrrl tcehrric:rl Pirrlrtcls tirrttr Kat'tltlakrt. lttttl ttcs'slatc. ll:llil)tlill antl intenrational
l)ill'lllct\ ir\ lt,;ctlcrl' lo tttttlettltk,. illlPllr(l r(\!''tl'ell ltlttl tler clt'ptttctll lirt ttttIrt'r erl
\\irlcrsllc(l ,.lcr cltr;ltttt'tlt. tttelttrlittr: (rrj.rllllq.ll)(l Pllolillr lllc Prtrle!l\

\lonitoring ald Eraluatiott. Illc 5tlh-c(,lllPotlr'llt \\()tll(l lltlirtlcc -jrtl partl \l&F
,.lircetlr ticd l(r prr)icct uctir iti,.'.'. inclutlirrg lrasclinc sllt\c\s. lllntll ilnd outptll
nl()ntl()Iilll1. l)f(rc!'ss lll(rll il()l iltu. itttP:rel il\\L'5slll!-llt\. ilc(lLlisitir)ll t'l llccc:sltlr
rcnlolc :cr1\in! rllilr..lcs. illl(l cilsc \ltl(lic\ ttr utlidt'prtrlr"cl illll l!'lllclltiltioll.

( rlntponent J: tliglr !nrlxrtt l)rnrorr rt rx t ion \\ntrr\herlr in Rlirrferl \gricrrllrrral \ruts.
lltt. etrtttlortcrtl \\ tll : l)|rr'fl lllc (lt\il\,lt r(|ll ,,1 ttr.rtlcl \\irlct\ll((l\ lll Iilllllr'(l ;ttclts lll clltlt trl'
tltc Pa111c1Pi11111g rtille:r. ( onrp(ri]cr)l -1 \\ ()Ukl |tc tlclir crctl throur.lh tht cc lllltll) \tllr-e olnponcllts:

J.l lnrprnrett integratcd rratershrd pliurs using scicrtc(-bnstd dntit nnd lools.
3.2 Estlhlish \ ludcl \\:ttcrshcds.
J.J Slatr specific innovations xr(l l)ilols. urbart rlil('rshc(ls. 0lc. Thr- stll)-

conllton(tll rrill strpPoll ptl()tin! r,l srrlirll-ic l!j irllt \illi()l)\ ltr ;ttltlrcrs llttttl.
:.rSri!.ulturc. rvutcr.;rnrl clinuttc cltattgc trsucs tllirltlc t() citcll PilftlclPullng stiltc.
li'r cllrrrrllc urhull t)cri-urtriul \\ :llcsllcrl rrlnagcllrellt plitnnitrg ittld in\'e\tmcllts.
tttirtrtsittu luttrlrcrtpcs itt ltt-i,'l t'usi,ttls. hiotlivctsitr nlilllxuctllcllt. nrqitrr gulll
'l
Icllltlrllrt:rtt(rn. rol;.rr;rrrtttP' li'r'.,rrrlrtl-.c:rlc ittigatitu. clr' lte .ul. (rrlnP(tllcllt \\ lll
.rl.(r ll)\tllrlllrrll.rll/e llll,\\ li,lti .rtttl ler.rrtts lglttttttl lt,'ttt llte'c l)1l1r1r l1r1 1111111g
tl|r\( rlrrln rll ::(r\ cl'lllllil)l l)l()!'ritll'l\

( orult(rr(,nl {: l'rojt'et \ litlragctttcrtt :ttttl ( uortliltatitln,
l'toicct nl nilgctncnl irrrrl cr xrlrlirlrtiort s'ill bc strp;rortcd ltt ecttlral tld sliltc levels. Tlrr" suh
c()ntpr)nc11l \\i)ul(l \uHrr)tl irtcrcltt,".ltlal (lll1lni\ttirtion c0sls ilrld spccialistr. lr:l\-cl. lncctillgs.
lirrirrrtill nrJr)J!(ltl(rll. rtttcrtt.tl ett.-rttll ittttlit rttttl l)roctll'rlnelll. ltttl crltriItrtettl.
PRO.IE( l .\Rt..\

l. .{ llcrrhl,,. Jlll}rr}itelt rrrll bc rrtltrPlctl rn PlrrlitiP:rtinu tlirlr\ lr, \\Jlurl \\illcr\hcd\ lirl

rlcrelopirrg rntprorcd datt bases lntl rrlrtcrshcd plills, ih tr r.-ll as a:tth-sel ol'sitcs trt
cshblish lrotlcl rlrt'.-rsheds. Parricipatirrg statcs \\'ould bc conttttittcd to cstablishing an
agree(l nurnhcr ol'ttttrdcl \\'itt!'rshctls. liltclt silc $'ill bc llpll)x iltratcll' 5.00() ha r\tl
il\ctitue t: 'uel ol lll-l5 rrrorlcl \rrlcrrlrrtls l)sr-\lirlc $rrultl hc lltkr.'tl ttP Jt is r'tPr.-etctl
tllirf thc rrt,,,.lcl rr.rlct.ltcil: \\\'tll(l hc\lil(.trl \ .ll liltrl) .lCIL,:r lllc \tillc". \\ llll :()ll'l!- \llltd\
lr..ittg rrhlc trr !..t.rhll.lt [l{rtf \rli\ llritlt r'll]cr.. \s rr lt., thc iJsc lll Kill'llillitklt. lhr: bt'Uatlct'
l[tl rruft lt rl !\itt(t\llrrl pl.rrrrrrrr! Ifrrr(\\ \\r'trl(l lre 'r,.tlerl lill l)(\t'll(l tltr-- ttlrxlcl
rrtlcrslrctls ilt tll( \tirtc\. ll is irnlrerpllctl lllirl !'lell ul tltc ttal,:. uould r,utnplctt'LI{l
l prk. I l{l irrttl ltyltollgt' ttllds!':,. \\'illcr :ccttritv plans. ltl(i illt('grut!'d \\'xtcrshed plnlls
on trr adtlitiortirl t.5(xl to 1.0(10 \r'il(cl'sllc(l:'.
.1. 't'echnicrrl rh.sign: Slirtcs urc lirrlliliirr rr ilh rrrrpluncnting rlflliottill \\'il(crshl''d schcnlcs.
H(,\\r\ct'. l(l \\,\ltl) rrill lre rlillercllt ln,nr "hrrsir)e:s rrs usttal" \\ itl!'r:lle(l Pr(,utilllls
3
:ile No. D-2tor6/l/2ozlr_Admn. (comPuter No. !oll/s/)
jene.at€d from eofll(e bv MEGHSHYAM SHARMA MS CONSULTANT, oOLR on 2llozl2025 o3:o9 om

<!-- page 5 -->

lrt'r:.rttsc tlte trd\\ rt lr'\ \\ ill h!- c\ncijlf(l l(r il(lollt ntoddnl lcchntrltrgrcr iltl(l (litt3_lOCuscrl

larrd rcsorrrcc irtrtttlrrriztrtiott tirt. \\ittersh((l nliunins antl intplcntcnt;rl ion. rr.,11L l..1,1.,
lccllnicill pilllnct\. i l(l c\l).lndi r lltc rrp;.rlreirliort ol'rhta t:a:.es lrntl [)SS trrrrlr t0 hcll
lirrnrers inrpror c pr(xhlcti vity an(l cl i nlirtc r,.'si I iqrrc_v.

Project }lnnagemt.nt sulrport

lltc [\r,lcrt \\(tll(l nrd(lonl lnirnt l\ l'ofus o1 \ltpllottint rr:tlcrshetl plilt)il!:c1lc1t ir(lt\ ilic: 1l lh(
l):tttrlcl St.rt!'s \ t,/..\ll(llitit l,|irtlcrlt. Karrrirl:rl,r.rrrrj (]tli.ltir lk,rrcrcr. r,.cr.l;rirr lreliritir,,r trl.lhc
l'rrrlcct rt.rrltl hir\(.irrr('n \\ r(lc irnl!liailrrr)rt. \\ hrlc Ir.rrt)irrr 1,1..ic. rcttg;rtt.ntcrl \\rrrkl hc \\tll)
llru Slillc-lc\('l \,xlitl \r.:e|lctcr tSI \ \.t l tlrere \l;rlcs cr!,t!clrlcnt .rt tlrr. rlirlttrt irntl
rralelslrcd lercl rs lirrcscen ln cL'rtilin cit\cr.
oB.t !:("1'tvE oF Til E ASStc\ItE\-r.

( ;tIitcltr ltuiltlirr3 ;ts it kcr l,' clli'etirc lrrrrl clllr,ir,rtt rr irtcrslrrtl
nllnil{cnlctlt rrirs tr rr tlc rscr,rr-rl
lll tllc ( r)llllllrrll (itrttlcltllcr lor \\',,a, ,,"., \lrulr::crrtcrtt ['rojcets -lttits {r.cr isetl irt :r) att(l
ir
}
\li.llllllcilt'tl illl(reirtt(,I rrl t0t,ll liln(l] rrtrs rululc,rr.rrlrrhle lo1 fhc
Itr1.nrrs(. I t1r.,11!.11aa..h,r$r thlt
('\cr lltc \cilt'f. cilPil(tl\ hrriltlirrg lras rrol bccrr lrtltlrcsrctl to the r{qllI((l
crtcrrt;rntl rn.r

\\'slcnlalttc lllilnnLrr acr(,tl. u,Jtcrshcd projcctr rcstrltrng in intplementtrl rn (lclit)
rr
s .lt)(l oti!.rt r lr
('ptinlal resulls. Rccrtgnizing its ket'corrtrihution. ltl:\\.ARD prtrcct
lir.rs srrn;tj(i1rl cnrpltlsis
on institutional slruluthcttitls attd citpacitv huikling ol'srakeholtlcrs at rlilll'rcrrr
lcvcls acrt,ss
thc tr;ttct'sh(rl lirrrrl.eir|g ln thtl.i c()ntc:i1. thc l)ol ll is tlrc
ol
rcn iccr rrl.rr
crrg:rgirti:
tltc
[r.occss
( itllil(il\ utttl ltt.titutrrrrr llutlthrrg Lrpcrt r,, lr!
Prrrrttorrcrl \\ithm thc lll:\\,\RD p11rtcet
Ittt Pletttcrtt.rl l, rr r I rtrl l l)rrl ll

r)t I tr:s .\\t) R]_spo\sllilt_t't't1.s

o 5l)cal'hcir(l thc |l]sttlulion building:.rntl cupacrtr.huikling rcquirctncllt\ (]l.thc prqcct antl

tlcvelop a roil(llllnp lirr strcnglhcning ldrrrinirl nrr ir c and rrrirrratcnrcrrt caplihilities li,r
c l'l'eeti r c i rnPlcl1l!.11 r1 1r.,,r ol' lhc prrricet.
. ltlclrtiti rrorIrl rrrrrl \l)(.(.iirli,/c(l lriunnlr r)rr.lni/irlion trl nalirrrt;rl attrl stlrlc-lcrcls lor.tlrc
cll'ectirc iiclircrr rrl t'[l trrputs.
. -{ssrsl rn tl)c (lc\clonlllcnt of t1n111131g cirlcntlarr iIl(l PI!.paritti(rn ()l tril tiltg It;tlcliitl.
e .\lon-g $ ith thc \l&l: tciun in thr' P\tl . prcplrc p.rrirrnetcls ri)r lllc rn()plt(rril( (rl'( B
oLllcon'lcs artrl ittt|irets.
o Etnlorc ilntl irnPlcrrrcnl rrorr-trrdil iorlr l n)ciut\ iln(l nrcthod\ trl-(.ll rlclircr).
. .\s5isl [)rtl J1 ,,, prrr\i(ling supl]r'rt ru(ltrrre(l h\ \l;tlcr l.rcr orrrl tlrc lll,\\r\p1.y,1,,r,,,a,.
\lille\ u illt iln.\ sl)cft,i( ( ll tgllu ctncnl\ t lC(l c\ls.
. Doclullcnl utrrl shirrc (.ll trest pritclicss oll tllcnllttic tn(l
l)t.occ\\ :rrrirs rsl:rtcrl lrr
u lrlcrsltt,rl ntirnilu(nlcnl lt tlte l)ril ll lcr r:l
1

.

Sllellrthcn lltlllirn Icyrrrrec ld In:.titl ion;tI cirPircilics in Drrt,ll tu
l'1r111. a.,.,r,g;nu,a.
Jclircr. r,'r'lrltr;rtc llttl rcporl ()n nl()r'r cllcclrrc. serclcr. l.r:r.,crl rrltrtrrtlrl \rJl(,rih(.(i

progrilms.

o lluildirrg nlrrrr. r,il1tt\l \\\tcnl: illil lr.i.hlrl,krlrcs lrr l) l R lirr. trrtl[orctl
!r}ot ditlillt' rtt. lrll)Slillll ((rl)lltlttttt!alr()r1\ rlulr\jir(lr. lttortilrrrinL:. crtrlulrltorr.,,,r.l

l)rogritnl
,..1rr,ir,,,g

arrd

o Stlcnglhctt thc.rpPlic;rlirrn of'rcnlols scrrsirr,.l. (ilS capahilitr. irrrtl lclcrirnl [)SS rorrlr
rvith thc suppot't 0l'Nati(rnal Rairrlerl .\rrtlrrrritr ol lrlrlia.

4
;il€ No. D.2tol6lt/2024-Admn. (Cornputer
No. Jor3757)
iener.ted from €Office by MEGHSHYAM SHARMA, U.S, CONSULTAIVI,

DOLR on 2llo//ao25 oJ:o9 pm

<!-- page 6 -->

l.\l'l. lalt.\( 1.. \\l) ()l \l.ll. l( \l lo\s
ESSU\1 1 \1. Ql .\l.ll'l( .\'rl()\s
.
.

\lir\tel) (lcgrc( [) it tclc\. ll licltl irre lrrrling rrlrill lllxnirgclrl!'ttt.:trei:tl \\()lk.llgllctllltlrL'
nlJllosclllilll. cte ot cr'[ttrltlcttl lioltt;r rcc0uttizt'tl LJntrt'rsit1
.\t lcJ.l \errrt tcrtt'.,rl \\(,rk c\lltirlellr( ln lh!'tll!lllxlle sna( lilliTittiull

D!.SlR \Bl.t. (ll .\1.!]l( \l'lo\\

.

l,t cl!'rol(c rr ill trc Sir crr lirr tlrc e urtdirlltcs rr lto havc handlcd thc \\brld lllank t)[ olllsr
crtcrrt.rl l r lrirlcrl Pto jcct' (rr ( io\ crlrnlcnt litrltic'tl prcrjr-'cts.

o l{ctcrrctl .|r(cilll/c(l ltiritltrlg trt th!- licl(l ol'('lpucill lltriltlirt,g.
Scnr[tu t)llrtCt. hulotr,-:irt:l to llte ( etttt:tl (.irr\1. ()l (irr\l rrl'stlttcs or t'tlit,n lt'rrilotics or
( crrtlirl St tc (i(]\1. [rulrlic Scelot t'rrtlert krrrgs ..\r.ltonolllutl:, l]orlrc.' hrrhlrrtg lltc |(]it
crlrrrrirlcnt l(r I)(|rut) Suct'ctIr'r, I)irccrol lcrrl at thc (i()lt. ol' ltt.lilt harirtr: rc(ltli\ilc

qultliltc ri(ll iln(l \\()rk C\pcricttcc il\ stJtc(l lttrur,: atc:rlso cligiblc to lrppll. ltl sttch c:tsc rtl
:clccliorr lhc rr'.lc\.ltt ( i()\ ct tltllcttl rules tcgarcling depulati(rll $'ill apPly'lor reguhting thc
tclnl: irlrl ((rll(lilir)ll\ r)l \er\ iec tlttrttlu tlcPttlitlitrtl l(r lhis l)():'lli!rll'
,\( it.l - l.l \l l l:
'l he ttrtirutrrrt tr:le lirr||t lir1 l1p1yll 11. tllc

l\hitio slrull he not tsecctltttg ()5 ]'cxl's;ts trtt tllttc tll'

lrrlr ctl tsgtncttl rrl'lltc porl
tf EE

.

.

,\\ D ,\ l.l.()\\',\N('lis
l ot' \clljelc(l elrrulitlulcs (,lltcr lhiln lhc eanrlidate's \(-lcclcd ()n (l!'lltlllltioll. th!'
rltotlth' its
c, rtnlt{r't\irt iun Pir(kirgt rt ill lrc P;rirl rr ithirt Rs. 1 50 lakh ltl R:. l-(10 lirkh Pcr
(ontntitlcc
l('L( l blrsctl ott tltc
rlteitlcd hr lhd I )cl)l 'tlll(nl:tl ( (nl:rrltJr)eJ Frululttort
cil lltll(lil tc'\ (ltlilll llc:ll loll. c\ncl lullcc iln(l \tlilittlllit\ lo thc n()\t'
I nltilnscnlsnt ol rcrtltttlct'illlrrrl rr llr. lllll(X) - lrtttlttallr i(lhiccl t(t
Sttcr:cs.litl c()llll)hti(ll] t)l'!'xth \cJr ol tctlttl'c;
tlI

(lill.\xlIlill|(}ll(tl.l.}crliIrlllilncctlfthcL-rperts&t.dc()tllnlcn(li'ltitlnlrt,thc
lllll

l)t r t.tt,tllr I I lclttl rttttl:
( ( I I t I I t I t I I ( | | , I l \ar\ lt!' rrr \l'\lt
I .

|

I

RUPOR.I I\(;

lltc p,r',iltptt (lirr(tly rclt()llr ltt lhc ['r(,icel l)ilclJtor - I{l'\\.'\l(l) ()f ht\ hcr tlc.'ir:trilte'

l.()(',tTlo\
Ihc p,,rilrott i,. trrt:erl itt rlre lil \\.\l{l). l'\'lt ()llicc in Nur Dc'lhi'
't 1:RUS ,\\l) ('()\l)t

l'l()\s ()1"'l lIl': ( ()\'IR.\('T

lltc Posilirttl ir c(rlllrileltlill illl(l c(rtcrlllillotls lulrl r|ith lhc dul'iltit)n ol'tlrc lll'\\ \lll) l'roisct'
'l-hc irrilrll c(rtlrilcl is lirr lt
vr"ltf rvitlt pnrvisiotr ol c\tsllsi(tll ttn lttt :rtlltttal lrltsis otl
P,-'t i,rrl ol'I
:.rtislucr.r.r' Icrl(llnatrcc 1l'tlutics. I'hcrr,. n'ill be u probationary pct'io(l ol -l tnonths rltrring
$lrrclr;.rcr.i0rl lllc Cotltnttjt cxn hc ttJnttitliltetl $'ith inrnlediate etTect. Beyrlnrl this Pcrio(1. tht
*.,l)tlr..t \'ill lrr tclrrrirrirlcrl ,tlirt il nllt(( l)er'ro(l (rl (rttc ttlotltll h\ citltcr Pitrtr Thc crpcrl shlrll
5
:ile No. D-2rol5/l/2024-Admn (computer No lol375/)
lenerated from eoffi.e bv MEGHSHYAM SHARMA. M 5. CONSULTANT. DOLR on 2llotl2025

0iio9 0m

<!-- page 7 -->

hc lrrrttrli'trr'ti to llte lolls rrl llrc l)rrr1er.t \ luttirscrrrt ttt ( ortstilllrtt,\-Lttncr (p\l( .\ltrrtce tltc
:irrle r\ (rIl1.Irl!rl rrrtrler lll \\.\l{l) l'.'1er,l. llte tcrttt, rrl'e'rrrliti.tt: rrl'lltc u.nlri.rul \\ ill r(nlir,
thc sarrre in easc ol ruclr lrartrlr..r.

APpt_t( AI'!o\ pRo( t_t)t RE,\\t) Dl:..rDLI\}]
Applieltionr iu'c c\pr:clc(l l(r \ulrnlil rr ('\'tlcttrilirrg their qualilicatitrns and cxPr,ricnee lhrrr
mrrtelr tlrc eligrhilitr crircrix..,\ e()\crilrg lcrrcr highlrghrirrg u.hr the afplic$nr
ii,cls.5c 6c
rr ottltl bc r.:r\xl ( lt(,aee lirt. tltc in(li(.ittc(l
lrrrsrtirrn sltrrrrlrl accotnpanv tllg {.\..

.{ll llplllieattun. lllLl\t be :\uhnltllc(l clcctrollcnll\ {:iUnctl scln6ctl lrt)l.t riu c,lJil l. th(

frrllorvrng itl. r'ceruit.rcs irrtl-tlolr;rr ror..in. I hr. positi()ll applictl tirr shoultl hc
elcurlr sr;rlstl irr
thc sttlr.icct linr'. lhc rlcirtllrrrc lirr..rrlrrrrr..siol ,rl'appli!.111i11n i.. l5th tltri.
li6rrr llt,,, rllrtr. ,,1

l)tlhltCilli(rn llr ne\\ s ltitl)ct.\

6
:ile t{o. O-ztot6/t/?o2a-Admn. (Computer

l{o. Jot:rz5z)

ien€rated from €Oi5€€ bv itEGHSHyAl/l SHARMA. M.S.

CONSULTANL DOLR 6n 2tlo?laoi5 o.r,oe om

<!-- page 8 -->

Rl.,'l \'t.\,\'l'l\(; \\ \l t.Rsll].1) r'oR \(;Rl('l l.'l l R \1. R[.sll. 1t:\( [_ ntRot (;il
r\\()\ \l l\ l. l)1.\ [.l.oP\lt.\'l (Rt:\\.\Rl))
't'1.:R\ls olj REFERE\('[:

ll\'Dri()1,(x;ls'l / \\ \'l ].R RES()t l{( }.S l'.xl't.lt'1'

R

\( K(;ROt \D OF 'rlll: PR().1!:( 'l'

l he I )cp.rr.tntcrrt trl [.irntl lt,,.Irrrrc(\. ( r(,\ ct nnlct)l t,f I ntltii hu: itt t tiatcd rr \\irrltl lllnk supporlc(l

rrrglri-Srurc prpjtrl nulrclr l{.lursurtiug \\rrtcr:hctl litr '\Srieultrtrrrl l{t.ilicncc throush
lrltl(r\illl\L' [)crclo|nl.-ttt (ltl \\.\ltl)i lt i'' .'rptctt't] t(l P(r\lll\cl\ iltllttcttc" lrt prt''l'tttrtitts
tc\(,u[ce cllicicttt s|.]\\tll t .(t((te(l \\ittcr\ltcJ). llr\cilllru ttt ltrttttlttl clll]llxl ilt StrlL' irn(l
Nrrlr.ltirl lc\el\, ir6(l tlcrel.rl,il1g lct\\rl'k: ()l :(l!'llfific irntl tculttticrtl p r{l}dl'5. l'l}c Pl'o.i!'ct \\'ill
eIllirDec Pr,xlucrirtlr llll(l llcl lll((rlllc (ll litttlters itlld e()lllrlhrltc slgllill(illlll) lt] Liqhtlrr]tlsc
llrtlilr 5t rlrplcprcntirru rrcl sclcn(r iul(l rlirlir-tlrivctt altptoitcltcs lirt r:litttirtc l'c\iliclll \\'atcrshr'(l
trl,,,,,',ug..nra,rt. lttt.l resottrcc itl\elll()r\. litnd ttsc plaluling. xlld l)lccisi()t) Iirrnring irl a rallUc
,rrr.,,-..c,, tt,rticu I ctrntlitiotr: rrr plrrticiPlrring statcs. lht'projcel \\'ill (lircell) atltlress key slralcgic
it\.ttp1\:rr()1ll(l asricultprxl rrtrtl rtrLrrl (lc\ cl(lpln!'11t. incltrtling rh,tlhlirrS lrrrtttcr.'ittetrlltes. tttorc
\t.(rp pct..lrrrp. rr11g1 tr) d\ct\ 11l('1. rrril 11g,111',. Jtl(l |1I'rIIIoIIoII ul clllr(l)rcllctll\hi1l th|r'uglt
tcelrrrre;rl irrttl tjnirrtcral sul)Iort lirr hcll,ir (lalr\!'r'\ iln(l llrll)J(lr lhrr'u!h illlpl'o\ ctl [rlanrrittg
\. elrp:reitr hLrilrlrnS. (()r't(litlittltlll rtt'td Cotlrctltll..e. ill)(l \tll)I rli\e rcscareh rttttl
.t ltIt.(
'.1l..lrL
-l
hd (1.1ljp1te\ illc l)tj\cnlion ,rl :utl rltn-rrli. l(rcllclJllt'll ,rl nllLtral \cgctilti()l).
.le r c1,;.,rttLrtt
,,,,,, t,,,,a. ltittrcsrittg xlld rijehllruillg t'l thc gtotttttl \\illcl lxlilc l'ltir ertitl'lcs nttr lti-croppirrg
.rrrrl lltc ir r, rr.htct i(rn (rl ,.li\crse u!ro-hirrcrl lrctiviticr. shrclr hclp lrr Proritle s(tstllillrthlL'
lirrlilr,xxlr 11' thg P!' plc rcsitlitlu ttt lltc rr;ttttrl'tctl itt'cit.

Rl.\\'\l ) is lting irttp lctrrtrr!..r1 rrr lllr(c lo l\rut lrrtlrirrt Slrrk:. ll r\ llIop(t\lj(l ils il 6 \(ilr\
I'rrrjcct. llrr.'trrlul irllrrcltiorr lirl tlrc ['roicct is apprtrr itnlttclv trSl)]5o lnillitrn of uliich
t sl)lrs.5 nriltion is lntcrrral rorrrr l llirnl lirr RccortstrLte liort iltt(l l)c\dl()l][]cnt (IBRD] lolln
lirrrn thc \\i,rLl Bank luttl thc hitlanec ir lilnded bv thc ( i()\ cl'lt! tlcl]l ol lndia Stirt!( ;(t\ .l llll)(lllr.

PRO.I1.( -l' oBJEvTt\'l:s

.\\l) Rl.sl l.r's

llrc l,r.,lC,,t [X-\Clol)!llCIl ( )l)lc!ll\J tl'lX)) rr l(r: ltltl]l('\e lrttt.l .ttl,l \\ lcl (irll\!'r\';ltltrll irll(l
elirrrtrtc rcsilir.,nct in sclc(tctl rr :rl cr,,lt ctlr. ilId rtrcn:ltllctr c lr:tcitic'i t'l rllrtiottltl xnd stiltlj
ittsltltrttrrtts tt, tl,.,lir',.'r pl(rl.c clli'eli\e 5c !'nl;c-l)it\f(l \\ itl!'I:sllc(l (l(\cl{rl'lltlclll pr()glall'l:.
I

h t.

\ lr l..st l rs

l'lX) Ek'tttcrtt
l:)1|r( '\ ( (l llrtt,l
rttlltrrlllC\
\llC\

l

Pottnlial PDO I ttdicllur( s )
!i rl)\Cl \ ill llrt1
(lC t( \l I itl l I I
'

.titticttlltrtrrl

lru ptirr c.l

(lttl(ulll!'\
:llC\

llt

rlctttrttlslritt irrtt

l'(l((

lil.Jr,,1 litl9!'li(l

\\llt(l\ll(\l

ltt.ll rl](lrrlt)g llll lll(fcil\e

llr \,rlllrirll/a(l l)tllctuttr-.' \(l(lrllr]ll
e('rl{ulil)r l,'r elinlillJ dlli'e1..

lrldcr t\l)\'lt

Irrerctttctttltl ilttutgc itt rturiettlttrr!' htrrllctlllure Pr(ldtldli\ it)
:rntl trtcontc lirr st'lcelctl cLrtPs:

7
:ile No. o 2rol6/r/202._Admn. (computer No. $r37s7)
;enerated trom €Office bv MEGHSHYAM SHARMA, M S. CONSULTANT. DOLR on 2llo7l2o25 03'09

pm

<!-- page 9 -->

Itttprrrr ctl \\ittcr oulc(rn]cs tt|
tlettlrnstration sitcs

l'cre cntir-lrc (ll ttrgctc(l lltttl:.e;r;.te Jtcil \lto\\ tng :ln incfei.lrc
in I .irnrl Surlirce \\irtcr Indcr ( I S\\'l ) corrcet rn-u lirr c linlnlq

lllrl)t (r\ ud clrmatc rcsili\.ne\

clli'ets:
( lrarrlcr irt rcsiliencc ilrtlc\ eornposcrl ol ;r sct ol r ariirtr['s

otlle()tnes ln dcm{tnstf1tioD

c(t\ cnn.u

silcs

ikliUrl i\ e ciryircilr:

\lIut-glllcncrI

c\po\utc. rc0sittrrtt kr ,..ltrttirlc c\enlr .ln(l

\\ irlclrltcrl

Irtrretiorr rtl tlelrt,rtls ol st iCrtttlir' pilrtlCr\ 1l
l,rll,lCcl slirlcs:
ittstttttltr rt'ts
Rcviscrl polie icr tirr u;.rter.shctl Rcr irc.l Nurionnl \\atcrihirl ( itrirlclincr

,,rtir,.,l.,,l t*

lll'osritlllr

Pn)iccl c\p!'ricnccs lnd lcssolts lt.irrncrl lhrrt rr ill cuidc rrcri
tt;tlrrrrr;rI rr tttr't slt r,.tl p11gt:rptr.

Pta().,l:( 't ( oIPO\E\I.S:

lltc ptrlctt rrrll rlcplor insttlultoll:tl .tp(l lccllpieitl s6lgti.ttr t() it(l(lt.u\\ tlc

(()lnponet)l\. xn(l ()\cr si\ \silrs. ir: lirllrrrrr:

l,lX) xcross f(r,t

('onrpon('nr t.lnrproverr \ationrl \fatt,rshcrl (iovernance
rnrr tnstirurionlr (. pr..itr
Iluilding
'l

his c.rrrpont'nt \rill srrL-r'rgrh*r cirPlrerrics irr(r s-\'stc*rs pr.irrirr.rrr
rrr r)rrr.r{. rirr.trcriru.rirru
tt;tliott:tl \ltlcr:ltctl pr'rg1;1111s. 111c.,,t1111,11!111 rr tll hc LI:lirc,t(tl tltlotrrlr
trro ..uh,(.rlnll.'!rtlent\:

lnstitutionnl slrenglhorting anrl capar:it1 brrikling. llt( rulr_c( r[nl\]n(,nl
\\rll
strcllgtllcn hrrnli l rrjsotrrcc irntl irr:t ittrt ion:rl ca;tircilic. irr
ll,,l.it

J

trr pl:rrr.

I

eoortlinltc. rlclirur- e r rrltlrtc .rrtrl lcP,rJl (lt) tllrrt.c r,lli.ctire. .,cic
ec-tr;rscrl n.rliott;rl
\\illcr:llc(i ptir!tilnl\ lt ur'rrl,l \lrl!l)rrr.t rr\rtitll ptr)lc(.t ltrllttrrlrrtr
.11(l tcnt,rltr)r
lrasCtl On C(lrrftltttltIr,'tl rlitll\ ,Il(l I I I ) t ( i t r
f!.|)orls lt.rlIl stillcs.
'l'cchnologl lransfcr.
lllc \uh c('t.ppt)ncll 1\rll \ltpp(rrt I),,1 ll l(, etxrrrl,r:rtc tltc
I tnPI 0r crl l ri t\l!'r o l L n( )\\
lctllr: trtttl c,\p(,l.iencds ll(t..ss lnrliatr \tiltc\ i td r:loba l11.
lll()ttgh nllionitl an(l in lct.nill i()nxl rrorkshops arttl cortli.rcnccs, arrtl
irttentltionnl
atttl nati()txtl slu(l\ t()ur\ ctJr,rstrr.r r isit:,.
II

|

|

||

.

t

,

( (lrnl)llltcllt 3: lnr,rorerl Srrrr' \rnrr^h.tr (iorernancr
Iluikling.

Nr(t rn\rir.riorrar ('apacitr

[-hi:! conlnrtncnl \\ill rtlcngllrcrt clrp:tclttC\ ilt)(l \\rtctns

pltnlirril\ rrt.t;rlc lcrcls krr p1.1p11111.
lllcth(xlr rlo!\. leclln0ltrtr (lc\ clr rl.|tn{n t. tlce r!, ron-sttppoft
lrrrls. ;111r1 rlclircn tnrrlcls. Tltc
e()ll)llo,lclll tr(}uld en.,Ltrc elinlirtc chitnl.lc ct)nsirlcrxtiol)s
ilt.(, llctr:lte(l Itl(! itll ilett\ rlrcs. lhc
cott)l't()DcIl rr ill bc ds'ltrcrerl lltrrrrr.ult lirUt suh-(on)l)oncnl\:

2'l

Insritutionrrr strcnglht'ning lnrr caP:rcirr rruikrirrg. Il(. sul)-(( ]nlrn )n(,nl

rllcnglhcrt lltIl'tl l

\\rrl

r,,,s,,rrr.,..t. :rrtrl tDstilttllonitl (itpil(.ttie\ in

rclcvant lirtc
tlepa rncrrl. tt stilrc. (li\t (jl anrl licld lcrcls to itrrllcrrrcrrl nl(,rc
cllL.cti\.c ln(l
rcictrcc-traseti pt.r)gt.illls tn 1\itlcrsheds. Tltc strh-corttP, rnsnl \\(ruld
l)t.()\ i(lc
lcsotlrce\ to httikl c;tpactttcs lirr stute arrd ticld lcr cl srlc'rtrirr.ris ,,r.'r..i-ulrt.

2.2

lcrhnical slrpt)orl tt, sii.tes. l.oll6n.lno a lishthotrse rrpJrruauh. thc suh({}nllrotlLrnl rr ill ljrrance thc p;1n ir. i11.11, ]rt
rrl' tltc K,rrrr;rtrrk.r \\1tr..rshrrl
l)crc1(tn111..111 I)cP;1111n..,11. lltcrr .tPcrtcnccil
:t.tcrtlrlr,. .ulrl ldellltt(.rl nct\\(lIk r)l
8

:ile No, O.2tor6lt/2o24-Admn. (Computer

No. 3or375z)
lene.at€d from eotfi.e by uEGHSHyAi{ SHARiIA, ti,S.

CONSULTANT, OOLR on 2t/o7/2,zs Ot:oa pm

<!-- page 10 -->

tol.r calihct.rcicntilic parnrcrs, and othcr insliluti(rls ar ttcctled tQ ltclp ntu proicct

:tillcs i[r(l I)t'LR prcparc tlrc Plcr.icct anrl estahlish atrd trititr theiro$n Pltrtllcrs.

l,-l

lltsr:arclt itttrl tlt'r cltt;llnt'nl. Thc ,,trh-crrtrlP(,llcnt $ ill littrrnec cristittg "ercrttific
ll (l lcclII(Il l)llflnct.\ llt'nt h:tt rt:rlrrl,:r. illl(l llc\\ \titlc. ttitlitrttlll .tttd itttcrtt;tlitlltitl
lri||'lllct\.r: e!'(l((1. t() ull(l(n,rke .rInlrerl rc.r.'rrrelr urtrl tlcrtl('Ptttcttt [i'l llllnro\e(l
rrutcrsltcrl rlcr,-'lonllrcrrl. irrclLrrlinlt ercirllllq lrtttl Pil0ting thL- l)r(riccts.

2.J

\lonitorirrg itntl l..rlluntiorr. I-ltc rulr-c.rntP, 'ncnl \\(rul(l fitnttec .itd Plrtr \l&l
tIrcctlr ticd t(r l)loicct ueliritrc,,. irrclrrdirrg birselinc surve\rs. ittpttt lttrtl outprtt
Ii
. l)l0ec\s Il(' it() n!. ilrl'tircl ll\ \c islll!'tlt s. ltctlttistli()tl <lt' ttct'cssaLv
I
1c1q11r1g .cn,iI! irrt.rtc..:rrrrl (ir\r \lu(lic\ l(r uui(lL'l)roi!'ct lllnlclllctltill ioll.
I I I ( ) I

it()

IIt:

I

('oltlnln(.nI J: High lnrplct l)rnronslrillion l\:rlershtds irt Rxirtfe(l Agritulturnl Areas.
l-hi. clrlllptrrterl \\ill rul)prirt tlre (lL-\ !'l()n!llcnl rrl'rtrotl.-l \\ illcrilledr irl rainflrl $rcas ill L'ilch ()l'
thc pxrtici|itltnt stiltc5. ( ()ltlp(lncnl -i \\rlul(l hc tlclrrered tllr'otll]h tllrc( I]liiill \llli-colllPrrltctllr
3.1

lnrprovcrl integratcd n atr:rshctl plltlls ttsing scit'nct'-hitsed data and l0ols.

3.:

l.rt:rhlirh \lrxlt'l \\ :rtt'rrltr:d'..

-t.J

State sllccilic ittrtoralitttts antl ;tilots. lll'l)atl rrill('rshe(ls. elc. Iltc stt[r!r)nll)()llcl)l \\ill \lll)PQlt lltlottnu .rl \lllilll-\citlc ln0U\iltiotl\ lo addrcss luntl.
1U;icUlttrrC. \\lrt(r. irtttl Clulliltc ihiullJ( tSS(lCr tttli!ltlC to cle lt pirrlie iltill ing \tAte.
l('t'c\llntl)lc ulbJtr l)ct.l-llIl)iIr rrirtcr:ltc.l Iliurir,gclllclll l)lirnnirls.ttltl itlr csllltcttts.
rttirrt,tgitrg littttl:citlr,:. in rttttl rcr:l,ttls. bto,,ltrelrilr nlJ llilrlclllc n t. Irlillrtr gtlll\
[elur[rilit:rtit'n. srtl r prttrr: l.,r stnirll-scirlc irrigtrtion. cte. l'hc sulr strmpottcttt rvill
rrl.'r, irtrltlttti0naltzc lno\lctl.tc iltt(l l!'\i()ns lcirtttcd liont thc:'c pilot:. lirr lirturc
u[\eitlt lr g rt !(r\ cfllll]dtll Il'(]!l'illllr.

('orrrponenl {: ['rojccl \lanagt'ntenl ltd ('oordinetion.
PIt)lrct lllilllil{clll!'tl I .lll(l co0rtlttt:tl iUtt rrlll lre ''ttPPrrrterl ;tl e'"tlltal 'rtltl :lale Icrt'lr' Iltc t'Lrh
conll)otlut)l \rr)ul(l suPp(,tl inergncrtlirl :rtlttrittislr:tlion c()sl\ iltld sPeeiirlistr. lr-lrrcl. ttrr:ctittgs.
llttirtreral ntutirrcllrcrll. rtlternirl c\lcrl)ul ltttlil ltttl Ploiiurclllcllt..ltltl cqtliPnlcllt.
PR( ).t }t( t .\ l{}..\

l. \ tlcriblc upqlirir!'lr rrill hr,- lrkrPtcd in plrticipatrng stitlu: l(' rclcct \\ lttcrsllc(l\ fbr

tlcrclopinu tttlPtrtrcd tlltllt hitscr irtttl $:ttcl'tltcd plilllr' as rrcll irr it \tlh-{(l ol rites t(l
c\txhltih lll(!dcl \\lllL.tsltc(ls. PtrrlterPltittt \lirle\ \\rr I(l bc ((,tlltllillu(l lrr (\lJl)llslllllg l)
.rstcc(i 1gl)lhar pl 1r.r{cl \\illct\ll!t(l\ lrrrlt ',tlc rrlll hc ultpr,rritllltl(l\ 5.(}0{l lltt. Alr
il\clilqe l$l'u!'l ol l(I-15 ttltrtl'.'l rralcrsltetlr l)cr slllte $r)uld l)c tak!-tl tlp lt i: ':xpcctetl
tlrat tlrc rrrotlcl \\ irtrirslrc(ls \\()ul(l hc \p[c (l \illiillrl\ irerosi lllc \tatr's. \\ilh sol!lc \llltcs
lrcing rrlrlc tir ,i:,1;rlrlish nlrrr(' Jit!'\ lllil|l ()tlr(rs. Ar \\ :i lllc cilsc in Kitt ttalak.t. tlrc hrtrrdcr
Lltl lrrrk lttttl rritlctsltctl Planttittg Proccss u'ortltl bc scal'"tl llr bcyond thc tttodcl
\\ ilt!'f!llc(ls ill lllf slill!'r' ll is ltltticiPill'"tl lllirl L-ilcll trl th!'stillss cotll(l cLrtnPlcl!'LRI
rr rrll. I lll;rttrl ltrtlt'rrlrrt.lr rtllit:a.. rr,tlct \((llrll\ l)lilll\. ill)(l llll\.!.lfill((l \\'llel\llj(l lllilll\
r,n irr it(hlili()llill l..i(Xl lr, 1.0(l(, \\illcl\llc(l\.
l. techniftrl desigrr: Stlrtc.. :Ic lirrrrili r \\ ilh iIrl]lL-n)(nt irlg tlitlit,llill \tIt(r\hc(l \chsln!'s,
ll('\\{\cr'. Ill \\ \l{i) rrill he tlrllclerrt llirll} '1.}tl\lllc\s ll: tlrtl.ll" $ itlerrlretl Plourallls
9
jile No. D 2ro16/r/2024-Admn. (comprrter l!o. lol3/l/)
pm
i€nerared from eotli(e by i,!EGH5HYAM SHARMA. M.S, CoNSULTANT, DoLR on 2llo7l2o25 03:09

<!-- page 11 -->

lrceitttsc llte nL.\\ \litlcs \\ ill hc c\perr,,:(l trr il(lol.rt rll(,(lc l tccltrrolotics

lrrtti tllrtlr - lirc trsctl

liltld rfs(|urCC ll1\cntr]riZittirrn hrr \\itt(t.sll((l Plilnning llnd i,r]lllcnlcn l.tt ir,n. \\0t.k \rllll
tcchttical |lrtnsr\. iuld c\|r.lt)dnlr llrc.rPlrlrr,alirrn rrl rlala b;rsc: iul(l l)SS lrrrrls 1r,;.,.;,.r
lhrnrcrs irlprovc producti\ itt an(l clitnxtc rcsilicrrcl.
Projecl \lanagrinenl {upport
Tltc Proicet \\(ttrl(l prc(lottl;nanl lv lilcus on suppoltintl \vllcrshed ntanilgentell acti\ itics
in lhc
pilt'tnr'l Sl.ttes \ t,,r. An(lhrl Prarl,,'rh. Kanurt:rka artrl Otlislt:r. llorr..,r cr. c!.rtilin itcti\
ittf\ (tl.thc
Itroject rr oultl har c natiolr-rvitle ;tl)plicalion. \\'hilc pr.ilntr.t lrtojcct r,nqilgcn)cnl \\ olll(l hc
\ ith
thc Stirte-lerel \otlal ,,\ucncies {SL\..\s) ol tltrsc Slitlc\. engitu(nlcnl itl thc rlrstr.icr irrrrl
rratetslrctl lctcl r. lirrc,.cr,.rr lt fL'fl:lil .'.it\c\.

oB,rE( "t't\'l: ot.' t'H]: ,\sstc\\tt:\.t.

Ilrtlrolrtlical ttt li rrtttatrort lrtttl tttrrdr.littu t\ rn c:.scl.]liirl ittprrt tirr \\ irl!-r:tlle(l ilsscss,)c1t il,(l

nlunnirr! ,.\ utrle r.tire usctl plilt)nln-!.1 itplr.oilcll bit\c(l (rn \rrun(l h\rll.r)l()!ielrl Ir.incrplcs is a kct
e()nlp(|nctll lirr l(l \\{lll).rnrl rirrrr. litr.lltcr irrr1.',,1.1 ,,,." Ir rhc !(,ntc\t trt \rrtrrrnirl \\:rlcrrheri
ProgratttC \\ tth tls l'rlclts oll thC pnncil)iCr rrl t. nrrr\ inr.:.
l.rt.o\ t\totIttg. U\ t:.: i l(l It)ilnilgtI|Ll
rrater firt ittclcascd oqricullrtral l)t.(xlucli()1. ln ttus c()ntc\1. thc [)rr[_ll prolur".,.
t(, fnsil.tIJ lhc

rcl'\'iec\ l' a llr,drokr:rrsr \\irtrr llrsrru|ec: l.tpert irr thc l)rrIR Rl.\\Alll) [,rolcut
lnrpl:rrrentatiorr I n it.
t)t "t'tl:s .t\t) R!:sPo\stBt !.tTtt:s

o ( irtrrcliltittc \r'lth kcv pirrtllcr\ l cerltrill iu(l \littc lc\.cls irr tlre lPPlit,Jtiorr rrl
h-r

tlt'ttlo{icill antl o1hg1 ltxrls lirr' aitlclltlslll pl,1l1i1g. pllt)tlr!11i' 11f :lr.lirtu trrrtl

!r'ounrlrr att r avuil:rbilitt.rrrrtl rr:,c

t

l:ltsLllc th:rt Ilvtlrolocieirl (lirta rn()(lcl\ :rs toutinclv lpplicd in rhc pllrtrril-u lirr.
rr.rtclslrctl l)r(rlcct\,tn(l il.c rclidetc(l rrr thc I)pRr

o l{csfrousrhlc lirl lrn,,u*,r-u rhe P111ll!'lslrip lith \ationul lcrcl iustitutiorrs irntl slirl,..
lcr,"l ttt'ttltttt,'tt!. \\()fkrtlLt ,rtt r lr lr ,.: rt I irn(l \\lrl(-r nr.rlarLr('Irertl r\\r(.\ un(l(.1
Ir

r

rr

.r

ll [.\\-{ l{ l) prolccr

.

Asscss rlirlc-lr'rel rcqul.cnlcnls li,r \trctulhcnitts citp eil\ ul tcillt.t: irr rrrirrl (ilS;rrttl

I{S applicrrtionr itt satctshecl n)ilr}ilscllr('rt rnd rr.e of (rlS hlsctl I),.'ci..r9rr Supn.r.t
Sr:'tcrn: ( l)SS )
' ,'\sscss itttrl rccottlntcntl tcchni(luc\ for \\illqr usc cllicir:ttc,"* attrl n.irtt-r rcu\(. ill llt(
eonl,luntl\ lcrcl .rrrd PiLrt tlrr.rc itt Illc al)nroprixtu lc\(ls.
' l.tiltsc rr llh tr:stltrelt rtttrl ltr:;trlcrttte inrltllrlton\ ;rrul piutrtr,.I \lllcl. ils Dcc(\sr1.\ l(r
\'{aittstrcr tt hvrltrrlogjcll concct-t)\ rr ithirr thc rrirtCrsltcrl nlit,tit::Cttlctrl ilPPt.oircll
o Jrlcrrtil) sttitalrlc lrrJrrrloqlcitl 11,r(lclr ftrr pillrglp- irrrtl rrpse;rlint.
. finsurr' thtlt etlicicnt $ulcr usc hlsctl crop planning prilcticcs nle (icn.l()tlslnltc(l \\illlll
thc RI:\\.\RD nilot \\ atchhc(l\.
' (lukc il lcad rr.ith tltc'urhitn \\ attcr'\hd(l rnilnxllcnrclr{ c{)nccfl and pilot irpplicatiorrs urrrler
irmPr111 n1 ,l lt' cnslttc lhil irpl)r'( Inriilt( li'arlcrr.rrks rtttxlcls
lirr trrban \r;ttcrshc(l
lll.rtlJielltl.'tll ilr( (iL.\el(rn((l lrrr rlrtr..lrr..\(.(.niI.t(,\ t ((l -cnlct) l\.
r .\rrirt \\ltll cxl)itett\ htrilrllrt-!.:,rl l)rrrleet.,trrkcholtlets lrt rltllirr,,nt lcrcl: il ltr.lrol,rur
\\lter nl:lnilLlcnl(rrt rn etxrr.tlrnltr,rrr rrrtlr thc ( a|r;11111 Burltlrn-:.r ((.llltciuu ,rif lrirr ilrc

P\{t'.

t0
:il€ No. O.2tol6lt/202a-adm.,

(compuG. No. 3ol375r)

l€n€r.ted from eoffi(e by MEGHSfiAl{ SHARuA M.S, CONSULTAM,

DOLR on zrlozl2o25 o3:o9 pfi

<!-- page 12 -->

.

( r)ll(cIlUitll/c l)r0jte t iretrritre. lirrllte rrtrrxltttlr(rn ('l rtl(lc()ro l( )gtc:tl irtttl ltrtltrrlrruieitl
r.!iluLling Jn(l rlrciltll ll(r\\ lllcitstlr(lltclll itt rrlltcr.lrctl lcrcl.
Ililrrt \\'stenls li)r ntottitrrrirtg rtreitttl llorr in r!ittcrshcrl Ploicets
l,lun tucirsufer lilr rrnprovirru srnirll \\irlcrshc(l lclcl hvrlroklgical atttl sr'ditltenlalirrn
rIrl.r.lllcetrrrrr.rrtrl .rrt.rlt,,i, ut tll.'lllill)till! llr'o(t\\.rt(l hr thc \l.tl lc.tttr ltt''tttclh.rl
t)t()nilr,rinlt l)llt'itn'l(lcl': lirr ltrrlrol,rgtcrrl ()(llc(rtllc\ ttrc ittlcr:rll\rtl itttrr tltc orclall \l&l

o
o

o
o

li)r tltc [tI()lccl.
lricrtttl\ prUcc(lur'!'\ lrtr ltt'tlrUlUSical lttodclirtg ol :tltirll \ ltlct':.lt!'d\ tt) c\illtliltL'llllll etr
rrl-\\xlctsllc(l :rtluclurcs (Il \url:lcc llorr. gr,rttntlsalc[ rcchurgc ltntl croJr plirnniltr.l.
( rrnlnl)utc t(r (l()culllcnlilt iol :rntl knon lcdgc slrruing in th!'thclnitlic arclt atttl lircilitatc
,.lrrt.r ar.rilrthilitr (,tl lllc \tlb.lg(t lrt thc I'\lI lcrcl.

t.\1,[ 1{ll.\( [. \\l) (.ll \l-ll l( \ll()\\

]:ssl;\'l l \1,()t .\1.ltl( .\'l'lo\s
ll \l.t:,lc15 (lcgl'!'c r)l c(ltll\ill('lll irr llltlrrrlogl ()r \\'atcr Ilcs()tlr(cs \l itllilr:cnlcllt llunr il
ICCOLlrliZC(l L'll l\ Cl':'ll\.

I I Sc\ cl) r'cirls ol'rcler unt \r'ork c\pct'icllcc in thc llclti ol'Hvtltolt,tv ltttl Wittcr llcsotlrccs.

t)t:slR \!il.1: ()l'.\l.ll.'l( \'I l()\s
I

) lrrcli'r'cnt.c rr ill bc uivcrr lirr thc cirntlitlirtc\ \\ lr(r lllvc lllrntllc'.| thc Wtrrltl lJank ()r olhcr

ll

crtcrttitllt ill(lcd l)r(licctr (rr ( iovcrllltlclll Iirntlctl Prolccts'
sotrrt(l knoslctlgc t,f llrle:t hltlrolo::ieal 3 tlr.!inil t(r()ls lrntl nlrtlcling tcchniqtlc!
rrPPlieuhlc irt tltc $ lrtcrsltctl ltlilllilSctt)clll c(rlllcxl.

iI I rpcricncc ol'rrrrtkittrl \\ith g(|\crlllllclll itlttl rcscarult institt'tlltrtts
-lt \l\pli((l f(\cirI(lr (!r itlll)ll\'itlt('ll\ .ll !!llle l)(Illlil)il1! lr' thc lrrc:r. inrlie:rte.l
it l'trblrr.rrti,rrt. p(Ililll)ill! l(,.llcil\ (rl llll('l!rt lt,t tlte l'tilccl
(rl I \PCrl(ll..r (rl llil\ lltg \\r,llL(l ltl \\trr'lrl ltlrrll tlI ()lhcr d()llol' ltttttlcr'l Pro;ccts'
S!.r\tng ( )lliecr,., hclotrgin!: to thc ( !'nllill (i(,\t. ()I (i()\(.0l'stiltc\ ()r I nl()ll Tulrltt]l'ics of
( r'lrlritl Sl.ttc (r(r\t. l,ulrlic \cct,rr Lrrrlcttirkrngr \ u t(,t l()tllotl s llodic'. lrrrltlttr! thc p(t\l
c(lui\rllcIl t(] Dcl)utv Scct'ctxt\ l)ileelol l,rvcl at lh,.' (;(r\1. r)l' lrrtli haring re(lui\itc
( lillillc lion alltl rrork c\Pcti(.nijc:ts ritiltc(l il[)()\c ilrc lrlso uligible h, Pplv. ln sttclt cllse ot'
\clc(tl(,ll llla rcl(\illll (io\(rlltllcllt rttlt'' rcl;trtltlttl (lcptllilli(llr sill llpplr tirr rt'gtrllrtltt!t thc
tclnl\ :.ur(l crrrt,litiorl. ('l'\cl \.i!!' tlttritlu tlcPtllitltt'll t(r thi\ pr,r''i1i1111.
AGE - l.l\ll'l':
'l'hc rnarirnrrrn 1gc linrit lrrl lpplvilg lhc positiott ..ltall lre ttot c\(!'c(lillS (r5 v!'ilrr ltr ttt) rlitk'ul'
ir(l\ crtisc[lcrll ol'tltc Frst.
F-E]: At\D

tl.l,ow^\( !:s

l or' .,elcclcrl elrrrrlrtlirles rrtlt(r llliIll lltc cirrrrlttlrtlcr sclcclerl ,rtt tlcpttlltttott. tllc
(.onll)(tIsirIl()ll l;rckluc s ill lrc Prrd rr ithin l(s. l .5U lat h l() I{\. ].(rl) llkh P.'r Inollth. .ls
rlceitlctl br thc l)cIitrtntcnldl ( ()lt.ult nc\ l\irluirtior'r (ottttttitlcc {( l( ) [rirsctl on tltc
ertttrlttlittc .' r;trltlilicrrliut r. crpcricttec rrttrl strititbrlitr l(t thc lx)sl
I ttlL rce'lnrJttl rll fctntlttl]tittl(ttl (t l(5.1(x)l)o - itttttttitllr sul),le(l lo
(t) \uccr-s.,litldotllplclioll()l'cilch\cxl'(rl lcllLlrc.
1

te No. o 2ror6/r/202.-admn. (computer No 30ll757)
enerated from eoffic€ bv fEGHsHYAi,t SHARMA. M.5. coNsuLTANT, DoLR on 2llo7l2025 o3:o9 om

<!-- page 13 -->

llll

l.r.tlt*tlt.n ,'l' Pu tli,',t it rtr.t' .l' 111\' l-1n1,11.. & rr,e.r )l lll!.,drrl t., h\ tl|!.

(lii)

('('rltilpati(|l pl scrr rec rrr \l'\lt

Dtvisional l lr,.atl :rnrl:

.

R}:PORI'I\(;
Tltc posrtitrn tlirtcth r.cpor.ts to thc l)roicct [)irr.ctor lU'-\\AIU) or

lris

hr-r (lcsistrx tc

L(X ,t t!o\
'I

ltc pr,xition rs h:rscrl ur rhc Rl.\\'.\l ). l'\lt ( )tlicc rrr \r.,rr
I)clhr

't ERlts

A\D ( O\t)t t'to\s ot Iil[ (.()\ l.R,r(..1.

Thc Positirrn is c.nlracttral anrl cotcrnrilrous iul(l \titlr thc tlUrali,n
ol thc Rl:\\,,\R[) lrnr.;cct.
l hc ilritirrl c()tltritct r\ lbr ir pcri(xl ()t' I vc r rr ith prrr'isi.n or'c\t!.n..i()ll orr
an annulrl lrasir .n
\'rll:lil(l')l\ pctli'tttt.rtte* ,'l',lrrtic. Ilrerc rrill h1';r p1l rlr;1111r11;1n
lrur.rrr(l rrl -l rn(,1llt. (llr11!r
uhtch perirrl thc corrtnrcl ( n hc tculltrrillc,l rrtth inrrrrcrlrlrrc
cllir.l. llcvrrnrl this perrod. Ihc
collllilel c'll lrc ler.nrtrratctl xlicr a ,loticc
(rl
rlllc rnortllt hr cithcr Iirrtr. I-hc rl\I(tl \hitll
l)L,l.to(l
bc trlttrlcrre<l kr thc,',r;;. rrl tlte I'rrricet \ lilliit,.:ert.lcttl (rr11s1111.1111
.\rcnc\ (1,\l( .\)',,r11.. gh.
s tlte is ilpnointcd urrtlcl RL!\ARD Prtr.icct. Ihc lcnrrs of corrtliliort.,
ol'thc c()ntr.ire I \\ ill rc,r;ll,
tltc suntc in citsc rrf strclt frirnsli.r..

,\PPt.t('\ilO\ pt{0( t.l)t RE.\\I) 1)1_ \Dt.t\t.
.\;lPllq'11;,r1t. i ! (\|(..1r(l lrr rrrlrnll .r ( \ rlr,.t.rrlrrtr:
th(l (ltt.tllli(.illt()n\.nl(l d\n(t.r(.r)(c tll.tt
rrrurclr tlr.'clir:ihrlitr cf,lL,ir. (1'\.:arl.r rert.r rrrrrlrr,.lrrtrrrt
rrrrr trre irpnr11.1111 ri.cr..,rr,.. rrr.
$()tlld hc grxrd ch111cg f'crt thc rndtcatctl
.\.
lnr:,tlt()n slloul(l ilce()nlpitn\. thc (

\

All ap;rlications lnu\t bc suhnliltc(l clccfrr)ntcallv (signcrl scanncd,l,l)lj) ria

cntilil (o lh,l
firll.r,.lnt itl. rccrrril.re$artl-tkrlr a {,r.irr. I he p,,riti.,rr-apPlir-tl tirr slroultl
hc clcirr.lr rtarctl ,r
th,.' .'uliiccl lin.' l'lrt tlc,rtllirre fi'r rulrrlissi,rrr',rl'1p1.,lii;j1iq1n
i. t5rh .1,1: ii..r,, ,fi" .irn ,,i
ltublie;rtion l) n(.\\ s llitl)cr\

12
:ile No. o-2tor6/r/2o24,admn.

(computer No. Jor3/57)
;en€rated f.om €Otrice bv tvtEGHSHyAM SHARMA. M.S.

CONSULTA|iJT. DOLR on 2ll07l2o25 o3:oe om
