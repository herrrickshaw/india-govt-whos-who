---
doc_id: "b5c50fb29b85effd"
source_url: "https://heavyindustries.gov.in/sites/default/files/2026-08/allocation_of_business_to_the_ministry_of_heavy_industries.pdf"
ministry: "Heavy Industries (MoHI)"
title: "The Government of India (Allocation of Business Rules)  (Size: 664 KB)"
date: "2026-08"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "919d7a97a2064413"
---

<!-- page 1 -->

Ministry of Heavy Industries

Annexure-II

Allocation of Business to the
Ministry of Heavy Industries
The Ministry of Heavy Industries was previously Ministry of Heavy Industries and Public Enterprises. On 7 July
2021, the Ministry has been renamed as Ministry of Heavy Industries: The Department of Public Enterprises has
become a part of Ministry of Finance. The Ministry of Heavy Industries is looking after the following items of work:
MINISTRY OF HEAVY INDUSTRIES
(BHARI UDYOG MANTRALAYA)
1.

The Heavy Engineering Corporation Limited.

2.

The Mining and Allied Machinery Corporation Limited.

3.

The Engineering Projects (India) Limited.

4.

Bharat Heavy Electricals Limited.

5.

H.M.T. Bearing Limited.

6.

H.M.T. Limited.

7.

H.M.T. International Limited.

8.

Scooters India Limited.

9.

Andrew Yule and Company Limited.

10. Bharat Opthalmic Glass Limited.
11. Bharat Leather Corporation.
12. Cement Corporation of India Limited.
13. Cycle Corporation of India Limited.
14. Hindustan Cables Limited.
15. Hindustan Paper Corporation Limited.
16. Hindustan Photo Films Manufacturing Company Limited.
17. Hindustan Salts Limited.
18. Hooghly Printing Company Limited.

104

Annual Report 2025-26

<!-- page 2 -->

Annexure

19. Instrumentation Limited.
20. The Mandya National Paper Mills Limited.
21. Nagaland Pulp and Paper Company Limited.
22. National Bicycle Corporation of India Limited.
23. The National Industrial Development Corporation Limited.
24. National Instruments Limited.
25. N.E.P.A. Limited.
26. Rajasthan Electronics and Instruments Limited.
27. Hindustan Newsprint Limited.
28. Damodar Cement and Slag Limited.
29. Tannery and Footwear Corporation of India Limited.
30. Tyre Corporation of India.
31. Praga Tools Limited.
32. Rehabilitation Industries Corporation.
33. Sambhar Salts Limited.
34. Fluid Control Research Institute.
35. Bharat Bhari Udyog Nigam Limited
SUBSIDIARIES
(a)

Bharat Brakes and Valves Limited;

(b)

Bharat Process and Mechanical Engineers Limited;

(c)

Bharat Wagon and Engineering Company Limited;

(d)

Braithwaite and Company Limited;

(e)

Burn Standard Company Limited;

(f)

Jessop and Company Limited;

(g)

The Lagan Jute Machinery Company Limited;

(h)

Braithwaite, Burn and Jessop Construction Limited;

(i)

Reyrolle Burn Limited;

(j)

Weighbird (India) Limited.

Annual Report 2025-26

105

<!-- page 3 -->

Ministry of Heavy Industries

36. Bharat Yantra Nigam Limited.
SUBSIDIARIES
(a)

The Triveni Structurals Limited, Allahabad;

(b)

The Tungabhadra Steel Products (India) Limited, Durgapur;

(c)

The Bharat Heavy Plates and Vessels Limited;

(d)

Bharat Pumps and Compressors Limited;

(e)

Richardson and Cruddas (1972) Limited;

(f)

Bridge and Roof Company.

37. Maruti Udyog Limited.
38. Manufacture of heavy engineering equipment for all industries.
39. Heavy electrical engineering industries.
40. Machinery Industries including Machine Tools and Steel Manufactures.
41. Auto Industries, including tractors and earth moving equipment.
42. All types of diesel engines.
43. Automotive Research Association, Pune.
44. National Automative Testing and Research and Development Infrastructure Project (NATRIP) and NATRIP
Implementation Society (NATIS).
45. Coordination for manufacture, sale and adoption of electric vehicles.

106

Annual Report 2025-26

<!-- page 4 -->

Annexure

Annual Report 2025-26

107

<!-- page 5 -->

Ministry of Heavy Industries

108

Annual Report 2025-26
