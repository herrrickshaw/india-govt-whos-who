---
doc_id: "b760afcab562dda9"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/d2afc6ee90d845304164bc019eb89472.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Notes 6"
date: "2012-09-20"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "00583fa1398059b4"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
Press Note No.6 (2012 Series)
Subject: Review of the policy on Foreign Direct Investment in the Civil Aviation sector
1.0

Present Position:

1.1
Paragraph 6.2.9.3 of 'Circular 1 of 20 12-Consolidated FDI Policy', effective from April 10,
2012, relating to air transport services, presently reads as below:
6.2.9.3

2.0

Air Transport Services
(a) Air Transport Services would include Domestic Scheduled Passenger Airlines;
Non-Scheduled Air Transport Services, helicopter and seaplane services.
(b) No foreign airlines would be allowed to participate directly or indirectly in the
equity of an Air Transport Undertaking engaged in operating Scheduled and
Non-Scheduled Air Transport Services except Cargo airlines.
(c) Foreign airlines are allowed to participate in the equity of companies operating
Cargo airlines, helicopter and seaplane services.
Automatic
(l) Scheduled Air Transport Service/ 49%FDI
Domestic Scheduled Passenger (100% for NRIs)
Airline
Automatic up to 49%
Air Transport 74% FDI
(2) Non-Scheduled
(100%
for
NRls)
Service
route
Government
beyond 49% and up to
74%
Automatic
100%
services/seaplane
(3)Helicopter
DGCA
requmng
services
approval

Revised Position:

2.1
The Government of India has reviewed the position in this regard and decided to permit
foreign airlines also to invest, in the capital of Indian companies, operating scheduled and nonscheduled air transport services, up to the limit of 49% of their paid-up capital.
2.2

Such investment would be subject to the following conditions:
(i) It would be made under the Government approval route.
(ii) The 49% limit will subsume FDI and FII investment.
(iii)The investments so made would need to comply with the relevant regulations of SEBI, such
as the Issue of Capital and Disclosure Requirements (ICDR) Regulations/ Substantial
Acquisition of Shares and Takeovers (SAST) Regulations, as well as other applicable rules
and regulations.

<!-- page 2 -->

(iv)A Scheduled Operator's Permit can be granted only to a company:
a)
b)

that is registered and has its principal place of business within India
the Chairman and at least two-thirds of the Directors of which are citizens of India

and
c)

the substantial ownership and effective control of which is vested in Indian nationals

(v) All foreign nationals likely to be associated with Indian scheduled and non-scheduled air
transport services, as a result of such investment shall be cleared from security view point
before deployment; and
(vi)All technical equipment that might be imported into India as a result of such investment shall
require clearance from the relevant authority in the Ministry of Civil Aviation.
2.3 The above revised policy is not applicable to Air India.

3.0

Amendment to paragraph 6.2.9.3:

3.1
Accordingly, paragraph 6.2.9.3 of 'Circular 1 of 2012-Consolidated
from April 10,2012, is amended, as below:
6.2.9.3

6.2.9.3.1

Air Transport Services
(1) Scheduled Air Transport Service/
Domestic Scheduled Passenger
Airline
(2) Non-Scheduled
Air Transport
Service

(3)Helicopter
services/seaplane
DGCA
services
requmng
approval
Other conditions:

FDI Policy', effective

49%FDI
(100% for NRIs)

Automatic

74% FDI
(l00% for NRIs)

Automatic up to 49%

100%

route
Government
beyond 49% and up to
74%
Automatic

(a) Air Transport Services would include Domestic Scheduled Passenger Airlines;
Non-Scheduled Air Transport Services, helicopter and seaplane services.
(b) Foreign airlines are allowed to participate in the equity of companies operating
Cargo airlines, helicopter and seaplane services, as per the limits and entry
routes mentioned above.
(c) Foreign airlines are also, henceforth, allowed to invest, in the capital of Indian
companies, operating scheduled and non-scheduled air transport services, up to
the limit of 49% of their paid-up capital. Such investment would be subject to
the following conditions:

<!-- page 3 -->

(i)
(ii)
(iii)

It would be made under the Government approval route.
The 49% limit will subsume FDI and FII investment.
The investments so made would need to comply with the relevant
regulations of SEBI, such as the Issue of Capital and Disclosure
Requirements (ICDR) Regulations/ Substantial Acquisition of Shares
and Takeovers (SAST) Regulations, as well as other applicable rules
and regulations.

(iv)

A Scheduled Operator's Permit can be granted only to a company:
a)
b)
c)

that is registered and has its principal place of business within
India;
the Chairman and at least two-thirds of the Directors of which
are citizens of India; and
the substantial ownership and effective control of which is
vested in Indian nationals.

(v)

All foreign nationals likely to be associated with Indian scheduled and
non-scheduled air transport services, as a result of such investment
shall be cleared from security view point before deployment; and

(vi)

All technical equipment that might be imported into India as a result of
such investment shall require clearance from the relevant authority in
the Ministry of Civil Aviation.

Note:

The FDI limits/entry routes, mentioned at paragraph 6.2.9.3 (1) and
6.2.9.3 (2) above, are applicable in the situation where there is no
investment by foreign airlines.

(d) The policy mentioned at (c) above is not applicable to M/s Air India Limited.

4.0

The above decision will take immediate effect.

Joint Secretary to the
D/o IPP File No.: No. S/12/2008-FC.! dated: 20 September, 2012
th

Copy forwarded to:
1. Press Information Officer, Press Information Bureau- for giving necessary publicity.
2. BE Section in the Department of Industrial Policy and Promotion- for uploading the Press
Note on DIPP's website.
