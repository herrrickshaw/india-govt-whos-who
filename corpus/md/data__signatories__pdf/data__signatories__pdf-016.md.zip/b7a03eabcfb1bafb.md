---
doc_id: "b7a03eabcfb1bafb"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/2822c4e24b48c74e09d3bdde07b52093.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Settlement of fee bills of Addl. SG of Rajasthan High Court"
date: "2016-09-06"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9883004c69a04758"
---

<!-- page 1 -->

: ge
F. No. J-18/1/2016-JUDICIAL
Government of India
Ministry of Law & Justice
Department of Legal Affairs
Judicial Section
RRR
Shastri Bhawan, New Delhi,
Dated 6'" September 2016
OFFICE MEMORANDU™ MEMORANDUM
Instructions have been issued from time to time by this Ministry with
regard to handling of court cases by the Law Officers as well as the Panel
Counsel.
a Recently this Ministry issued an OM of even number dated 19.04.2016
regarding allocation of cases to the panel counsel before the various High Courts
wherein if was reiterated that wherever there is a Branch Secretariat of this
Ministry i.e. Mumbai, Kolkata, Chennai & Bengaluru, cases are to be allocated to
the Panel Counsel by the In-charge Branch Secretariat of the Ministry. However,
in respect of important cases, the In-charge of the Branch Secretariats are
advised to consult the Additional Solicitor General for proper defence of the
cases.
3. It was also stated that wherever there is no Branch Secretariat, it is
the Additional Solicitor General of India, who will be over all In-charge of the
litigation and is required to allocate cases to the Government Counsel ensuring
that there is proper & fair distribution of cases. He is also required to maintain
records of the cases distributed and forward a status statement to the Main
Secretariat to enable compilation of statistics in this regard.
4. In continuation of the above mentioned OM, It is also clarified that the
Additional Solicitors General will be the over all In-charge of the litigation &
allocate the cases amongst the Panel Counsel for the High Court Bench only
where he is sitting. For rest of the High Courts and Benches, concerned
Assistant Solicitors General/In-charge will allocate cases amongst Panel Counsel
of that Bench of the High Court.
continue on page 2

<!-- page 2 -->

i ge
5; While allocating the cases equal distribution in ¢ fair & transparent
manner be also ensured.
6. A monthly report regarding distribution/allocation of cases amongst the
Panel Counsel highlighting the important/high financial stake in the cases, may be
sent in the first week of the following month.
7 This should be strictly adhered to.
\
a या NJ =y
a decent,
CONE 0.
(SURESH CHANDRA)
LAW SECRETARY
To,
1, The In-charge Central Agency Section.
2. The In-charge Litigation (High Court) Section, CAT (PB) New Delhi, Lower
Court Section.
3, The In-charge. Branch Secretariats Bengaluru, Mumbai, Kolkata and
Chennai. '
4, The Additional Solicitors General in High Court of Rajasthan at Jaipur,
Allahabad, Punjab & Haryana at Chandigarh, Patna & Addl. SG Southern
Zone.
5. The Assistant Solicitors General of All High Courts other than High Court
of Rajasthan at Jaipur, Allahabad, Punjab & Haryana at Chandigarh, Patna.
