---
doc_id: "b5fa8d4b9afaf8b0"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/cc3e9e7dddd5d0c099461a4c1d08ec19.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RTI - Departments of Health and Family Welfare - CHS V - Study Leave - 3. Study leaves to CHS doctors guidelines - Clarification dated 21-June-2023"
date: "2013-06-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "29ff24a7f88db9e3"
---

<!-- page 1 -->

.1?O34/05 /2023-

tl'/ srE€ P'flt

35976rj, ?O:3

t'lc \qq\,t
tri

.) \
f,ur
-{-

.j{

t

)

\

I

No: A. 1 2034/05/2023.Ct-tS V
Government of lndia
Ministry of Health and Family Wetiare
(CHS Division)
Nirnran Bhawan. New Delhi-1 '1001 I
Dated the 21st June. 202_?

i\,"J

.J

rr.

rf 4,

OFFICE MEMORANDUM

nl of Study Leavei permission to pursue Post-Graduate Deoree

DrplomaL/ DNB course by C HS officers- reg.

The undersrgned rs directed to refer to the reterence recerved from Directorale
ot CGHS File bearing FfS No. 8174418 on the sublect mentioned above and 10
say that number ot cHS doctors who may be a|owed study reave at a oarticu ar
pornt ol time
_may be kept limited to the ceiling as prescribed in para_2g of th s
\,'linistry's OM no. A.12034/03/2012-CHS.V dated 02.1 1.2012 ft is further stated
that above referred ceiling is to be determined taking inlo consideration the

sanctioned strength of the concerned sub-cadre of CHS in the
Org anizat ion/ln stitute.

2

This issues with the approval of lhe Compelent Authorily
Signed by

Encl: As above

Vilay Kumar

,\,1,1t\t

\i\>\'

Tc

\-.
., r\ \l
1''

Dare:02fflamffarj4:27
Under Secretary to Govt of lndia

The Director
Cenlral Government Health Scheme.
CGHS HQ, CGHS Building,
Sector13, Fl. K. Puram. New Delhi.

6\ Nr"

Copy for inlormation to: US (CHS-Uil) US (CHS-ilt,tV)

Ct.\
",.. ^f .u
/ --4\A'
'
4> "
/J, \

\

a

>

$rir.rvb. 3\1+1

- (.t) )?

utltt

o lc
\._/

\

<!-- page 2 -->

A.12034/05/2023-CHS.V
I/3597613/2023

No: A.12034/05/2023-CHS.V
Government of India
Ministry of Health and Family Welfare
(CHS Division)
….
Nirman Bhawan, New Delhi-110011
Dated the 21st June, 2023
OFFICE MEMORANDUM
Subject: Grant of Study Leave/ permission to pursue Post-Graduate Degree/
Diploma/ DNB course by CHS officers- reg.
The undersigned is directed to refer to the reference received from Directorate
of CGHS File bearing FTS No. 8174418 on the subject mentioned above and to
say that number of CHS doctors who may be allowed study leave at a particular
point of time may be kept limited to the ceiling as prescribed in para-28 of this
Ministry’s OM no. A.12034/03/2012-CHS.V dated 02.11.2012. It is further stated
that above referred ceiling is to be determined taking into consideration the
sanctioned strength of the concerned sub-cadre of CHS in the
Organization/Institute.
2.

This issues with the approval of the Competent Authority.

Encl: As above
(Vijay Kumar)
Under Secretary to Govt of India
To
The Director
Central Government Health Scheme,
CGHS HQ, CGHS Building,
Sector-13, R. K. Puram, New Delhi.
Copy for information to: US (CHS-I/II), US (CHS-III/IV)
