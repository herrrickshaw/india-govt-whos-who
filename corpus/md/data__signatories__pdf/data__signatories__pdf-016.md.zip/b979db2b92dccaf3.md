---
doc_id: "b979db2b92dccaf3"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/93c33dfcad8bc815d1786d836bf2d7b4.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Draft- Ministry of Health & Family Welfare, Central Government Health Scheme Organisation (Administrative Officer) Recruitment rules,2018 for comment of stakeholders."
date: "2018-05-10"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b5950468ac18f763"
---

<!-- page 1 -->

F.No. A- 12018/06/2018-CGHS-|
Government of India
Ministry of Health and Family Welfare
Department of Health & Family Welfare
CGHS Division
(CGHS-I Section)
ऋऋ कक

Room No. 430, ‘C’ Wing,

Nirman Bhawan, New Delhi

Dated :|/6 - 94-2018.

This Department is examining the proposal for amendment to the Recruitment Rules
for the post of Administrative Officer in the Central Government Health Scheme (CGHS).
Accordingly, a draft Recruitment Rules have been prepared and a copy of the same is
enclosed.

The comments of the stakeholders are invited in the matter. The comments may be
furnished within 30 days from the placing on the website to the Under Secretary {Admn.),
CGHS, Department of Health & Family Welfare, Room No. 430, ‘C’ Wing, Nirman Bhawan, New
Delhi. The soft form may also be furnished on s.dharminder@nic.in.

Encls. : As above. fA Fat
(DHARMINDER SINGH)
Under Secretary to the Govt. of India
To
All concerned.

<!-- page 2 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART II, SECTION 3, SUB-SECTION (i)]
Government of India
Ministry of Health and Family Welfare
(CGHS Division)
New Delhi, dated 2018.
NOTIFICATION
GSR. .........- In exercise of the powers conferred by the proviso to article 309 of the
Constitution and in supersession of the Central Government Health Scheme (Administrative
Officer) Group ‘B’ Gazetted post Recruitment Rules, 2002, except as respect things done or
omitted to be done before such supersession, the President hereby makes the following rules
regulating the method of recruitment to the post of Administrative Officer in the Ministry of
Health and Family Welfare, Central Government Health Scheme, namely:-
1. Short title and commencement. - (1) These rules may be called the Ministry of
Health and Family Welfare, Central Government Health Scheme Organisation (Administrative
Officer) Recruitment Rules, 2018.
(2) They shall come into force on the date of publication in the Official Gazette.
2. Number of post, classification and level in the Pay Matrix. - The number of the said
post, its classification and level in the Pay Matrix attached thereto shall be as specified in columns
(2) to (4) of the Schedule annexed to these rules.
3. Method of recruitment, age limit, qualifications ete. .- The method of recruitment to
the said post, age limit, qualifications and other matters relating thereto shall be as specified in
columns (5) to (13) of the aforesaid Schedule.
4, Disqualification. - No person,-
(a) who has entered into or contracted a marriage with a person having a spouse living; or
(b) who, having a spouse living, has entered into or contracted a marriage with any person,
shall be eligible for appointment to the said post:
Provided that the Central Government may, if satisfied that such marriage is permissible under the
personal law applicable to such person and the other party to the marriage and that there are other
grounds for so doing exempt any person from the operation of this rule.
5. Power to relax. - Where the Central Government is of the opinion that it is necessary or
expedient so to do, it may, by order, for reasons to be recorded in writing and in consultation with
Union Public Service Commission, relax any of the provisions of these rules with respect to any
class or category of persons.
6. Savings. - Nothing in these rules shall affect reservation, relaxation of age limit and other
concession required to be provided for the Scheduled Castes, the Scheduled Tribes, the Other
Backward Classes, the Ex-servicemen and other special categories of persons in accordance with
the orders issued by the Central Government from time to time in this regard.

<!-- page 3 -->

| g
i :
डर co
५,
3
See
nw nN
ig¢  gFERSREaEere: Wl
REE CGSREERSFEGE || ¢
868 मिड Ret Bess ६ 8
BES ots t+Es Bee sl | 3
8 8 ba dh के 21 3
2 - iz
टू
6
B. 7a) Oo
8०2 6 E
geee | हि
BE है.
8 o g
a |
eG
Za
ea
yn
5४8 ४| |
s2| | s| &
Sis &
हि
ला 7
&
@ z
४ =
a a.
a *
So
हे
721०8
है है है
wm) | &
2) |e
g &
| |BE
हि है
es
Z\A3 >
cs en
2) a?
BI PE
Fl | &
Sa
95
a
g

<!-- page 4 -->

8५ om
Se o
z 85 है
3 gs e
3 5538
3 858
gS fog
a
क्र छ.5 5
8.4
बल
Z| 8982 <
5 ge Bee
है | s2geee
= 8,435 8 है ५
Sie Pe = s3 se
85 884 है
| oe sl
22.8 me
ae |
|
3 |
ts 3 |
3 3g,
46 BE
8 हि i
ey
A 8
०
डर
a के
8.४5 81868.
5 esue
=a हैं है 58 6 2 ६,
है हू लि लि तय 2 91
हः हि
ge SET Sas
e° | Bege> *e
5 8.1 1
B Bae
Fe o
é aon
3 ons a op ह8 ७४७५
B29SFES F 44558 5 हिंद 44866 BEF 328
ESBS 8 SS FR RBER EBS S aes कद
है 524 8 10011 Best cell] "EBs
£3 ; :
g'ga5oa के “EEERGE ,SiE2 ai? 28
3 EFS है हर 5 ।
बिल ।। वादा १58 agi
cer be goeinre g*e 8 FE BEE
; gee EM or) ae 3. 2
Be. &Se§ 652 25 Eve: gee Pas
5658 kee “838, ors x2 Be 3 > Be
व अंडा 138 हु te
SEES 5 Ecegeiezse: cae 358
ee a Eo) ZehPs ote हि 88.8 ee
Pees eg 5S a BERS reo ze
@ a SSaREs 8.5 8 8 88 8
68685 8 सह हि वह 58 oe
S45 gee 4422 8 ee z =
Ber si < Saft ie sed 2. हर
cy = = प्र
08. = SaZSS5 FR 888

<!-- page 5 -->

=
हे पे 3
१8885 वेद दिवडे हे है
की निज बह ERE कप GE Gea
१8868 606 886 8 B59 92 era
S8SESSBERES gas “a? हि
Se FEE weezer ECE 5h go Re
Sob oa ae8S¢2 E,8 ga beet
Bobs eo bE ES BS Be oa AE
rareagSekages दे छ. 83
BHoees ee geo ee yes
PeSebe fr eseas ae oe
B&as eae PeS gag gis g ons
Belch ash bee es ge Sky
aI श्र ans ao = 8.
slapetat fergie bf GF
08 3 Bgag east - Be eft
283 ६8146 5 8. a 2 3 Ba a
18211 6168. fot ey fica
5 eo
84567 655£89 458 48, है है;
8, थे as a, 8

<!-- page 6 -->

e SIeS eo es
eyygy 9 9
= = 3
ZE92 Rifai fi| 3
321 84888 @ 5
Eee 98650 #& 5
FEES gao88 & =
Zo 28858 हें 3
a2 Shao 6 g
52 SckED & 2
5 zeSes 8) | 5
<7 geeee fll oo
g 58566 & 2
: g
goose & 2
2989 = 8
taaes 3 8
>o SG g.
Bae 8 é
2. oe &£
Bose e :
erg
8 a
2
5
3
z
5
= = 9
a न ;
q 8
g
e 89४0
5 $6 =
दर प्र ze
a > Bo
छ =
& S Z| 88
ee 3 554
cs
#E 8 हू ले
S 8 aS:
2 छठ = es,
iL: ERE
22 8 Bo 5
Fi a faa} 5 fy
fe L 2 हि
BS eI हटा
