---
doc_id: "b5f79daa3abbce90"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/c59facabd2f2a27c753f680a7fac0a60.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Instructions to migrate Existing license-authorization to Saral Sanchar Portal"
date: "2023-01-20"
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "350b2328045ce965"
---

<!-- page 1 -->

No.DS-28/1/2020-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, New Delhi – 110001
(DS Cell)
New Delhi, dated the 20th January, 2023
To
1.
1. All Licensees with Internet Service Provider (ISP) License
2. All Unified Licensees with ISP Authorization(s)
3. All Unified Licensees (Virtual Network Operator) with ISP Authorization(s)
Subject: Instructions to migrate Existing license / authorization to Saral Sanchar
Portal.
Instructions are hereby issued herein under Clause 15.1 of Internet Service Provider (ISP)
License / Clause 16.1 of the Unified License for mandatory compliance of the following (if not
done already) latest within 30 calendar days of issue of this letter:
Migrate / onboard to Saral Sanchar Portal and seek confirmation of the said migration
from the respective LSA field units of DOT.
2.
In this reference, please refer to this office letter dated 30-08-2022 (copy enclosed as
Annexure – I) vide which procedure for migration to Saral Sanchar Portal was communicated
to you. Further vide this office letter dated 21-09-2022 (copy enclosed as Annexure – II) you
were reminded to migrate to the said portal. Respective LSAs have also been pursuing for the
said migration with you. In case, any assistance is required you may seek the same from
respective LSA where your registered office is located.
3.
Please note that in case you do not migrate to Saral Sanchar portal within the time
frame stated in para 1 above, the same would be considered as your failure to perform
obligation under License condition stated in para 1 above and action will be taken as per
Clause 10 of ISP / Unified License.
signed
VINEET Digitally
by VINEET MALIK
Date: 2023.01.20
MALIK 16:20:49 +05'30'

(Vineet Malik)
ADG (Data Services)
Encl. As Above
Copy to
1. Secretary T for kind information please.
2. DG (T), DoT HQ with a request to direct LSA filed units to get the aforesaid letter
delivered to the Licensees with ISP License / authorization who are yet to migrate.

<!-- page 2 -->

3.
4.
5.
6.
7.

All LSAs for necessary action.
DDG LFP for kind information please.
DDG NT for issue of these instructions to said Licensees via Saral Sanchar portal
DDG IT DOT for uploading on DOT website
Director (DS-II) for kind information please.

<!-- page 3 -->

DS-28/1/2020-DS-III
I/3057477/2022

File No: DS-11/28/1/2020-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20-Ashoka Road, New Delhi-110001
(DS Cell)

New Delhi, dated the 30-08-2022
OFFICE MEMORANDUM

Subject:

Online Lifecycle management and submission of reports through Saral

Sanchar
Saral Sanchar portal enables application for new License / authorization in online
mode. Phase-2 of Saral sanchar is ready and will allow applicants / licensees to carry out
various activities involved in lifecycle of the License in online mode. The upgraded system
will also allow you to send online reports and compliances. In this regard you have to
register and create USER ID and password on the Saral Sanchar Portal
(https://saralsanchar.gov.in/admin/olmRegistration_add.php ) as new user. In case you
already have your userId and password then you can start using various post license
activities, i.e application of surrender / name change / change in authorized signatory etc.,
submission of all kind of reports etc by logging in the portal
(https://saralsanchar.gov.in/LoginHome.php ).
2.

As a first step, all licensees have to mandatorily update / confirm the information of

their existing Licenses / authorizations. Further, licensees are mandatorily required to send /
fill the online reports through reporting module of Saral Sanchar. Manual for using the
portal for migration of license / authorizations is enclosed for ready reference as AnnexureI
and
is
also
available
at
https://saralsanchar.gov.in/user_manual/ul/UL_Migration_Applicant.pdf
.
List
of
documents required for migration of existing licenses / authorizations is enclosed as
Annexure-II.
3.
All licensees are hereby requested to immediately confirm / migrate details latest by
15-9-2022 of your all existing licenses / authorizations issued before November-2018 and

<!-- page 4 -->

DS-28/1/2020-DS-III
I/3057477/2022

start sending the online reports. All such licensees who have been issued license through
Saral Sanchar only (i.e. after November-2018) can straight away start using the Report
module of upgraded Saral Sanchar. It is further requested that till the time the new system
is stabilized; licensees are also required to continue sending the reports as per the current
procedure. Once the system is stabilized the department will discontinue Offline Reports
and will accept reports in online mode only. Licensees are requested to fill the status of
various reports for the current year w.e.f. 1-4-2022.
4.

This is issued with the approval of Member (Technology).

VINEET
MALIK

Digitally signed
by VINEET MALIK
Date: 2022.08.30
16:25:43 -07'00'

(Vineet Malik)
ADG (DS)
Encl: As above

To
All Licensees
Copy to
1. DG(Telecom)
2. All LSA Heads

3. DDG(AS)/DDG(Satellite)/DDG(CS)/DDG(NT)
4. Director (IT-II) for uploading on DOT website
5. ITPC Pune for sending along with mails to licensees
6. ISPAI / COAI

<!-- page 5 -->

DS-28/1/2020-DS-III
I/3057477/2022

Annexure – II
List of Documents required for Migration of Existing License / Authorization

1. Following digitally signed (by authorized signatory) documents are required;

Certificate of Incorporation
License Agreement
Board Resolution authorizing the authorized signatory
2. The authorized signatory who is applying for migration must have a digital signature
3. The authorized signatory mentioned in the License need not be the same for the

process of migration.
4. The board resolution authorizing the authorized signatory must be same who is
signing all the documents for migration.
5. In case the Licensee has multiple authorizations under single Unified License, he is
required to upload only the digitally signed copy of latest authorization which should
have names of all prior authorizations under the same license number.
6. For any queries, please raise ticket on
helpdesk. (https://saralsanchar.gov.in/ticket/tktadd.php?var=1)

<!-- page 6 -->

User Manual
(Version 1.0)

For
Applicant

Migration and related workflows of UL/UL VNO licenses
in
SARALSANCHAR

Department of Telecommunications
Government of India

18th June, 2022

1|Page

<!-- page 7 -->

TABLE OF CONTENTS

Content

Sr No

2|Page

Page No.

1

Introduction

3

2

Migration Request

4

3

Application form

5

4

Addition/ Modification of data

7

5

Upload Signed Application

8

6

Modification after reversion

9

<!-- page 8 -->

1) Introduction:Government has issued the guidelines for shifting telecom service providers to
the new Unified Licenses regime, wherein the spectrum is not given along with the
permits as has been done in the past.
After coming into force of the Unified License, all the existing licenses issued
under Section 4 of the Indian Telegraph Act 1885 shall stand automatically
converted to the Unified License. This will be the Unified License.
On conversion, the validity of the Unified License shall be same as the validity of
existing license. The conditions of Unified License shall be the same as existing
license.
The services under such a license will be restricted to the service(s) that the
Licensee could offer and to the service area(s) permitted under the existing license.
In case an existing licensee after conversion to Unified License wishes to provide
services permitted within the scope of service under Unified License but which are
not covered under its old license, then it will have to apply for Unified License.
For conversion to the Unified License, there shall be no additional entry fee to
be paid by the licensee.
A holder of Unified License shall have the option to apply for and migrate to a
Unified License.
In the event a holder of Unified License desires to expand/alter the service(s)
offered or service area(s) of operations, it shall be required to migrate to Unified
License and pay the prescribed entry fee.

3|Page

<!-- page 9 -->

2) Migration Request:In order to migrate the existing UL, UL VNO and Pre-UL licenses a new Migrate
button is provided on the main dashboard for the applicant user.

4|Page

<!-- page 10 -->

3) Application form:- Once the migrate button is pressed the user is redirected to
the Application form page where all the user and services data already present is
populated which can be edited.

5|Page

<!-- page 11 -->

The existing services data is populated which can be edited and new services data
also can be added. Also the user has to upload 3 documents mentioned in the form.

The application form can be Saved and Validated before the final Submit.
Also Application form can be previewed in PDF format.

6|Page

<!-- page 12 -->

4) Addition/ Modification of license and services data:Applicant can modify the existing license and service details.
Applicant can also add new entries of license details using the + (plus) menu on
the grid table.

7|Page

<!-- page 13 -->

5) Upload Signed Application:The applicant has to upload the digitally signed form after submitting the
application form. It can be downloaded from the same page.

Once the signed application is uploaded and submitted using Final Submit button
the application will be forwarded to the respective nodal office for scrutiny.

8|Page

<!-- page 14 -->

6) Modification after reversion: In case the nodal officer reverts the application
for corrections, the reverted application will appear in the user dashboard with
Modify button.

Migration application form will be opened for editing again for user. After submission
of the form same flow of scrutiny will be followed as for the new migration application.

9|Page

<!-- page 15 -->

10 | P a g e

<!-- page 16 -->

11 | P a g e

<!-- page 17 -->

DS-28/1/2020-DS-III
I/3060907/2022

File No: DS-11/28/1/2020-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhavan, 20 Ashoka Road, New Delhi – 110 001.
(DS Cell)
New Delhi, dated the 21-09-2022
OFFICE MEMORANDUM
Subject: Online Lifecycle management and submission of reports through
Saral Sanchar
In continuation of this oﬃce OM of even number dated 30-08-2022,
licensees are requested to migrate to the portal latest by 31st October, 2022.
signed
VINEET Digitally
by VINEET MALIK
2022.09.21
MALIK Date:
09:52:05 -07'00'

(Vineet Malik)
ADG (DS) / DoT
To
All Licensees
Copy to
1.
2.
3.
4.
5.

DG (Telecom)
All LSA Heads
DDG (AS) / DDG (Satellite) / DDG (CS) / DDG (NT)
ITPC Pune
for sending along with mails toLicensees
ISPAI / COAI / ACTO / VNOAI
