---
doc_id: "b7e5fd5abf66b94b"
source_url: "https://www.dsir.gov.in/static/uploads/2025/10/bf845a12b780f249d1daa9fdfedf72c3.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Tender Notice for hiring of DLY cars (AC & Non-AC) for official use in the Department of Scientific and Industrial Research, New Delhi - calling for quotations"
date: "2025-10-30"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2b29b79838a55137"
---

<!-- page 1 -->

No D 26011/03/2014 GA
Deoa menl olSc'enlfc & lnduslraLReseardr

De
subr Hnis of oLY caF (ac & Non Ac) ror ofiicial use in the- res

Delhi- callins rorquolations

reputed T0!6 &
o"",.

";;;*".".t.," .- ot a :
. i *'l

Trave

A .o dro eds

",-.,,^.''.*"*

,"i,-i..n " .,-.--

"q

".i"..'",-.*"t"o
od",ad
! Op" ro. doe ", o.od".^o
0e o't e \LF6oefe'i

-. ""**"",t"
""*ar
nq sr"
-in" oa" ot te"a*
"oen

one. or rhe uircs dered rrrs

s romn ihd the ooe,ar.^ d" nol o*
(altested pholocopes o, lhe R ca
ejecred
leider shan be

0..ro '1-r';d.e"s

^*

7

n seoarate sea ed .ove6 and thereafie, bolh the coveE should be

o." sLpe5 o"oas ouotanons ro' supolvorDLYcr5 cd

M; .. "*. N"" o"l

oi { 25oool rRrpoos 1'ert/-rv
-G,o. o DDO

E€siighurial fs ol the rat

be nk sg^ed n fur! olheMse the t

rd A aleraions shourd

<!-- page 2 -->

**nifr$$:lFj*****-+;ru*i]llr':'$,ffi
al Ann'xlte'l

10 Th€tenda co^lEcl slunhersubrocltothelems and condioisanached
,r Tnb Tenoe'
"i--d;J;fu 91.1i{:,'"".r;::"*_ir:"";"";::^;"n:1""'"'"'""tr"#"
12

Ouobtiotr should be submlted nrhe

proioda arached as

& rl1

^hnsrure]l

i:"^"",ff;Bi:,i:i';'':J"";?lf:,fi?;i'l i;ffil"';1H,,::::';:'iJ'"'";-'::"j:"!

#;i
"; . r""
;i-","i.i'""";,;",*".*".,

l,"';i"

;-ji,

"-"oros.

'"""""' /riJI+

(KuldPKun.4
or rdia
ofe'on
6ErY
ser
'rae

ilJix-ilzY:s::;;t;

ol oslR
cooy;shivh va,u" scedn F rorlpoadins rhd tender documenl oi rhe websilg,0

4tg-

(KudiP K!mal)
under sec€larY io ihe Goi or Inda

<!-- page 3 -->

4!Ie!!4i!
rheRaeCon ad{a'rb' aloro cosooo o'A }Pc rontc4J'dasrdnose
;"",;.' ;;;".;
;HJ""" JJ"ii,i". i"i;;;:"'"s *oe" 'o r u ra ao'*r"n o

'
"."'"i""

q;"j:":;:;;;

Hu

on

'rlmn
:;;i,;..*
" ; ."."."^.
i:;;i."'d:;,:',;:"q.."
;ii:.; ;-;'.; -*
'e

,ii"lllii,rji

'Pd

no d'vs fror Modav ro

Erda'

",

'rhe tdi hired shall b. lor rhe exclusive use ol this Oepartmed and io shannq wiih anv
olhef user *lll be .llowd under

;"'i"!i:f:n:l:

ll"i"i:;:"'l':"^1i1" :]."."'l;:l i"l T """#:-::;" ii'-i
.,.i;" "jr" *.. -p" r.g t c
Tfi J
:l'i 1"":;:1'#;1""1iX :;1"1,:ii"lliJ":Ahf,1
dd ri obFcron bv tfe "etu'1" Prcnde' rrarbr
d"'J"in"i' .;
'*r', 'r" '*"n

;; ;i;;" "

lh ['sDePaimen

l'"f :

:r"ll;J'{'"H{
;"1i;flliilf ;:#5"":,'.1.f'"rd
-H;"J;" ffi"ir""'fi
'ii;".;;;;
r oc sl*d ro
drLn
+a
* ,i1 r;m d .onmeua ban!
i)rji"i,i ii":ir;ii
l"""nl runiilrl;"''"^:,i."frTff lifr;'J ",f :'i iilii"$3
::,:t

;u"t

lr'nr;1,""1"1*"*mm;"ll:Jiltt'J::lf :L*":f :^g "t'J:li'.ihfi.Tl
ollheDepadmed nthematerwillbefinalandtndins

.h..* o,en,d'i;" "

lo ror 'o' too ka\ d'sla4f @r dav En? \n

v.ri.tion on any.ccoudwin nol b€ admited

d salisladory dfinq rrre cou6e o
Dispute. ir anv a.isiiq our otrhs coniEd shar be
rodeired
i",iiii,i","!ii rr,"r daid
subEci to lhetudsd clon ol lhe Delhl@uns onlv

a iodrnev is @mmened but nol codpleled duero breskdown elc DslRwLl

b" d rkd' b.hi€ idh.' dir--

<!-- page 4 -->

@6 wilhLn hall an hour of reponrno anv
Fim shou[ be in a posit on to pmvide slandbv
b"
Ar sfn
o
,." -,
;;;;;;;
l\
:'-e"top€r @r p€t dav sh'all be
"w\
'".""'
"","'
50Or
p'narv
ol
Rs
a
';
,-*""*.c"-""*r'"r"*pdeo

;.;;;;.;; ;' ;i*'*
ii," ..,ii,," *"""

" -dlro

;4"; ;;; fi;i'. *,"* "

d
rod a va d 'o

Po oP 1trq' "o d_re'^1r er'

r'r r@1e

'
dcv'
opa€t
ns
hdnor'ns
ca'one'

;;;;;;;.;qt",i,;"''',"""
i-.,i"'. i' :,'"' ."- q oi Ina o, !d1 the dnv€r deproved shourd poss'ss a
"
er'nqu6heis equ'pped rhc tsli t6nic
o;d i;;hledo. or "opsahq pondbr. nre
'n
or udb'erra
i. onid orhs burdms*ih rorcri 'r n4n
rn..tr"."iiijiri'"

"il!.

se u {v cF4. venr rror ol

;;";; d**.
o rr" qa" '" *"
i"i""'r""i'. ."""
pan re v'r \' rFcd /e
,.,1'i.'--":' '
s o Fs
'

ordarwa'sbP 1

otovdAd wrh mA no n oone p$ne

;#;";;;;;;;;
. .i.;o ,,"-".
;;:;. ;;; ;;";;";;;. '""*

pu nsrho

"".'*"'"'"i*
"."2m."
of lhe driver'
unsarisraclory seMG

ThednverptovLded shouid be edu€led enouoh lo malnlsin logbmk enties shotmg

ul*ii
*; i;;;",.
i"'"-"..*o o 'r,*.,

ean

",.";'s*

or@.s slan on a day to dav bass

The @sr ol fie. mainlenan@ ol I

Ji in'iiLi" t"'" ov rt'" s""r*

sh'rL be aLrMd bv

,-rut*" or -t..""-0.'"
T uu + 0Ieno"q'ncnr 0
Liv
D'
rfe s'NrP P!r''d' D ,rR
i'.. ,"i" * r, it **,*. o o"rR ,h-r b" haldrpd
aasing oul 01 suci
"
aiv
iabLiies
or
ueF wl not be nvdlved in anv manner.nd
'ls
Prov
setoice
acdidenls wl be rhe rcspoisibilty ot rlre
orcvder sha lbe bound rd render comple{e indemnitv to lhe DSLRTDSLR use6 aoainn anv
cdminal or dv arising on a@unl ol hiring laxis bv DslR
iiabi
dn5n q dlrno

'ty

<!-- page 5 -->

* l?lll1;il'Y"i'*'i"ifrX';i.1iliffilttts1{il'n"ffiHfl.ffffi'*' " "'" "
'l tl r'm6 du'no
rrequr'rlY

n the rsliJe

20
-- An rFran pcp€6 0u v upo

.".f en"i.o ro osin rhe odv€r s\ou d nd oe 'haroed

he

lh€ *toi@ rcndered duino lhe @lendsf monrh
21 SeM€ ooider mav submit their bills ror elendar
moiln
by lhe end ol the f6l week of the ensuino

22 lne rine and didanc
2l

hno ooy BrreMn

r*[

Tempenng ol Knhibase mder/adua d6.n@ orered .

anv found

€ rM ol dutv wil

'n
'l p@'d'rs'lb€
remioaled and
a6'{nolv 6Mc1oi the emnq $toi@

b. r;ken;msly
lhe sedrity dep.sit forfeilad.

4hicleswl ndbre
-24 Pnvse
t"
,il"n-J

Onh v'l'Lles hold'nq @trn'dd*mi'

'"'r i"ip,vr".r ;n oe 56nt ro ihe r€nsport aurhornv. Governmad or De hr'
iiii!i'.p-"i.:ii"i

2!''n.\eM€pu6e'shoU|dnde|F.*oadlvoiEpaid1o|he
vlhener'er. i.e ,,nv damard ror *E vehi'l's ror Depannen
pos ion io poide vehlcls immedial.lv

dn direcl lel6phone (otf@ as rell
26 Tne Mner/setoi@ prcMder should be .vailable on hisentu€
b ateid ells in em€ilencv
as €sidene) and also on mobile phone

e ss lo

<!-- page 6 -->

ANNEXI)RE- II
No.e2601 1/Gr2014-Estt datd

Name ot lhe Fintcofroanv/agencv

,ddress ol Fim/compatrY/As6ncy

Ygar of Re€|n6r'on/ ndQoElion

Number of Emp oy€es as on 1 4

;-nnuarruilNr(alonswihprcof)a5onrl32015
setoi@ T& code No andPAN
ErrrD ol Rr 25 000r. endosed

i-E fm or Bani DratuP.Y ordsr

ner end orfe oaa zaion'
G;;d firs-i rhi-6p"'lion €su'drmmrhrt
b3!s r*rre4inPd
.;qased
,,Ji.- l i"*"L ""t' *.
".
,liached)
and duD iamDed @p'4 or mnrad |€rer be

Ssrrsfactory Sery'6 Cenfi.r* Ircm
DeDanmansPSU/ CorpoEie

tla-rhreeGov€mmenr Mininnd /

oLY Tdis reqisre€d with ihe agencv
5

2

AddE 3nd Telephone Numb.roflheprcpnebr
N-am€,

rde 3@pl th€ l€ms €d
aoree to ab de by the sme.

qkt6d render€nqu/ry and

(sisnatu€ of rheaulho'ized pecon)

<!-- page 7 -->

DS|R render Enquiry No.D 2601 1/032fitEm.d8led

chech Listlor Techniel P.llmteB

Annual tumder ol lhe fm tuthe lasl

Delails ot rhe p*t expenen@ d
providing seNices in the sam€ field in

Govonm€ln Minislries/ D6patunenls/

Psrlv ReMed crrpo€le sedoc,
with @ act peMns aid $.r
salis{adory pedomsnce cedil5cate
DepanmedJ Maj$ PsUs Co.Pomle,
where lhe lE6pon seM6 are
Copies or @rljricales of In@mo6ror

of lim, PAN No 6nd S€ni@ Td
Totar number of DLY

-rdis/ca6

EMD ol tls25,00tv- in lhe rom ot
DO/Pay Ode/ B.nk Gua€nle

<!-- page 8 -->

a!!Ex!EE:.ln
DSIR TdnderEnqulryNo.O26011/03/2014Eslt daled

alaleulglg
Resadinq suppLy orDLYTanson hne basis Re€ularBasis

Anou (in Ps.) ror Ac
smrrcar, 0nfis06 and M.dilm car !n rieu€s
in mdsl (e.q. Tara and i. @rdsl (..s, Tara

Anount {in R$) ror Ac

hdigo /Maruri swift Dzi@
/ sx4 / HYUndal Acc.nt /
Toyd Etios / Ford lkon

4ct
charges ror

veriLde

Per kn charues ror .nra
5.

Nishl sray chaQes (after

2

WVe a@plfte lems and @ndiiionssl pulaled n you.above quoled lenderenquiry and
agtue io abde by the efre

(si€ndfe of rh6 Biddeo

Name or rh€ T*i sknd/im

eamr/sea
with lelephone number

<!-- page 9 -->

@{{'

qono 4

{roqo

'z601r^r/?otr
.]r.a{1I$l{

ftiF 3it diiiFfi tinaq
ffi:i4 rii{ 3tdff6 3rg{iF tdJir

ffii

$qa -{l n<lld aFt.
a+ Rid 110016

Firdlfff{tr'
rcR,
'"- ffitr

,#

'?or6

Hr d {{6rt 5qnFr d 1i!

3n{ 3ltdr'r6 3r{{!,F asrl tir{d F{6R' 45
tt -""e{tfd) aRrda* 6rn 6i EFrd R ae n €dq t al 3mifrd

J

tu_cl rrdrl

i {'6rii rcqFl d ji! fl-d {Fa
fl
tRqi flFd *"e{F" "t& *" ** tt-t E ffi dv h' r'Parr nde43oFraa
kddr/-g ffir
** * * n h! aEo a{ 6ni 4l 3rer4 @ -A d R(?"iF
P ofi?r r ! c
rJ'i.1 q {.e @ -?F' n Jrn
;;.;,e
;'.-',-'*
na r q.a .nrn @ o !6+Frelt 'r:l 7 ffr
+- +,f'etJ i tdr-8l'tA'trr|"fFi4tHf,r
* *
"t-a trfl { q r n iq-4 4fi
Fm a.Ftrt
aR{
$EA zl]I d aa riiifi-d ai.] Er6< tu 6 3rq.q A6
ffi6

3n{ 3ltdfi16 rd+F Rm4 a+ ffir

qFrd !1 ftqr{ ilqr n(ql Bdd
qs tg{ srdi dr FE *l ffi €rd{/{l;q €16r( S qft4'4 ldsnil drl lt iq 'ifi61or
mlr q{ dn rt{ qdr{n .'S d lr€rd o} q{'n fi F_{R d Eq iR.4rl

,

6-ad 5.t So qdFr oFeEi/rdlqelqn vft 6

fll d! a{l
6rd n ff rst.r ]na al t{d +t F4d qrq @ d @ 4Gr) M
-rn R ti6 4Fa6 Rrad dr 1r'4qE tu{ :1@
6J 3rfir .q -a t c6d a("r() fu
jiG€€ {i'4I d dl r6t t al tdA 6{n F{R 6{ a
di-TF m di t 16 {qi.n d q€
qa"i' es{ 6 slq idF Fff
ff(ff ddroro I]@ q". q{ff. d?tr itfl qi 6r Fd1Fd ffi
r.

d{z]i*q 5.q< tam d F$fd atfl qftq 3n' 'sd q€ ls 3i41d dfl +{ 6lg
dr4 {G! rn{ {6 nd n 6r tlrnra 6r .(I Fl
qr
s qr -d46r dS rn{ ft-d{ a)-dr 6 ai 'rFi ti din -d46r d rn{ ffij{i rq rrr4
flq
Fsrh
rm {nqd Fmrsl d iis 3nr rrrlqrd aFt Fmsl oJ so ffi taq<
qt
rir ; q{ "M 6t 61 3q1i 6 liq fll1.' ft@ 3Fl lGq n_.n qrrqr sltrq sltrso
ag
ffid iiF 3l1dFr6 3r$sra rffil @{ no a 3s t6tnldr .Iaa arIfi ''r:J
5r4 6l
ffirroo15 6 arn S ,lir ffi qfi{ d{r.drd3n 6l '?5 ooo/_q (q'a{ 'n{ w( qH
n
n
e.n6{ ni{ 4.nrn. A(q3tr$ffi tddin ,Ic -a eFnfi aFt a€ ffi 11ooi6
eFfi d l{ tus nE/n3ner 6 qr:rs n ri:rdrfd iqf,n d{rfr drn 3J;q$ tt{ w F?r'
a.

,rtN?2

<!-- page 10 -->

tua arq n dt{r a
6. q{ +i ri@ @ ii + Rqq srnF 5lrq#nn 6l irir6{ rlir
lRln] {ftr F{ ifr 6 iii' a tr(ln
iFinr sF tra-rFr al F@IT; qftfii F fi
z B'cra 4+/ t{n dt d 6rd_da to{ 4 :i'{ 6l {< 6{ Qqi sRqrr { i Ffi h cfici?i
l|{ €r€r t 9$ ardrarr i}} qG!. 3Gr_4 €'r !r tufl{ d6t liilr 3lML
-{diF 4d 4) 6sr{ Fi n
s &r ol €rsR :FG 6M1*ql F,xrrir 6 qrs t 3ik li}r|r
jir
tt
6
EierdBn 6 tFS
fa! ardq -6 tL 6{R 6l rrcjt d dtua eii 6 €n)1rd 6
f{$r R hrl{ -ff lb_4l liM rq rd id t_$ 6ff ]Jqft6ln . Rl

Fnt

tumq 6t tu4 dlq -dF Ai$ ft 3nrcr {,n ic{i 6l ii{€ 61" d $tnt tr Frna
d ft$ !n &'T d Xdrn 3lq? tsn rr$ 0n lN 6i dn{ 6.i 6t }i iirqsr1 ?

e.

10. qFt /6m {id.r 'rr{oq ld e! lrq F@ l.d llnl n }"cq_a m d{I
ir '-s{ dRini' A'tr A ndFri. lvv(i,ovin 3 crtdais h;q -l qda F 3r,|cr 3qm4
yEl4it (groqo). 14{ so a-3i. acicns llrd -qr tra 4it ag fidr"11o0r6 d flq
1? at .3r{ziq n q{ II|d lAr l]{ q{q d Frdd 6I ir+ Rcl
rl. {61a< at Aqi6 ,6.0r.1016 d qiq 3 oo d dd 'FidiiJl ri'i|{ i €Frd 6n 6 qrq
€ aeF3lr*m 6 tsr at_€ d afi 3rs6fi tL al5S i?a r'ro di sjq 4) iffid| a'ad
+ ffi fr l3.dF*3n/!i3Rdr 3J@ 'id qftifd ffiFtu. -il 5cRrd Gtir lrFi d. €'

-AhtY
(5dac Taro

3fi{ {fr4 srad srd{

(a]Is: ?6sr34i?

t'EalFrav^vE
Itaztti'u, *;siT / ;/'"4 _@r
#il
i?i#
q ,.a
;'
ziia t=F J' qFRji -Dr ]F d--?- n
rrm sI

"

o7

=-'

-.>. a>-

<!-- page 11 -->

E4t1

EsLq !d

c( .{ @ r! wil-d tu! $i 4r htu ! @ 4d ; ft! i1r dn d4fl! ac (
lft al aH cqn * q.€qltr FFali t t€ .n n Fq aa td F@ ei mt q
c rjlr {{ i ftn :m o {6?r tr ;l|@ 3q {Ftu4 n-dni v@ 4F1i+
+{:!ia 6 dr t 6l* a.*l -ff A d s6al

FxEdd d?4 n rjd4r F €jlr d{ l-{€i q qrt-z ffi trr t43n 6r
R d]
3mrqd;n Fl-fi t tu{ 3n, n {{n lqF 6 FTff xrd Aa rih {Ktc ffii
i*qe @ {d
rdfAi di/ afi_6 ( m S 3€44 *a!@ sdr lii?d q

qt45r1d6tr9Atji(ledfl

'dr

End R A ql tqS dfd W R&F 6 5qqh $ ti{ 6tfi 3n{ 6.iJ ,fr qftRrfi c
nd F{ra sF tF$l 3Gq 5qd/rftt + w sw 6{" 6r sEsF tfi dfir

t4 6 r*! qrF fi rt 4drffi o1.o1ror n c€n d .i+ -fr 6ia nnaoaq
q6 ffi4 rrG i R-A qft{ j@ 6t 46 zE{l q{a q n!t, 6€ 3 qad ni
hfta< w 3i1r \rd nin ?ftlr qA +{qrtF t4dr 6r n+ i21i@ isi'
]f{q{ i4 @-@t d iSq a€i dd t + aHrd.i ffq}rg3lr{ fin ram to!
i,i * h! aG 6 ffic trm F-.! n'i e fts {q dqr aq {it t
9!{3trFft d ed4 rii' .tr 3n +{ !@ .rn 4i ai 6tg * 3srFa @ d
5Ria rm ffi rifr 9q tudrn (R ti *f, qad 6 sr. ( dn + €?m d
3+{ !d q( }qs F.,i? ai fi aft@ n
Fs jm i6q m 6n{ F* ar
Fqr.4 qF{- 6
wF
3r1{ st 6t nFfr qFrtud +6 6J 3ft
(${@ N) Fdrrft_i
6fii drn
&
so@/-$ 4i +6 nn'a
siia & Fft d @
3rd1i fsE Ftj q afiiq fta fl {6rnr FIIF eiiqfa
60 rlai fi 3Fft n iir tr ddl qG! Fqqa toq m 6n{ inm am ftdi 6t*
nf.d e! 3@ ft{ 6tl s@ -d! FF$ .n l@ lr?c 6a n nfd tr airi
F! 5$a1T d 6i* qFqF ifi 6l iq:ir a€ mn iim d Fq_q riFa !n

d{

Fs

i
fl

Nt

il

e t
fr m

i

d{ + !F€ Ecl qFEd r@ ardtie t * fd{ 10 Ea dn 3rFRF i_Fq it
fr#tz. srin d q]rffi rFrffi li! m w 6r arat ; s{R tuq 3M

sF req !E_(l 6r {t 3Rlt i iilG Rr d ero {A $h frE$ tn 6nq n
r4t irJ an m 4dr{ 6 3iq{r1 rsC 6ti aaffi Ffim -fi dn
ffi fi rafo 6 ?tG tu idniffi -fr ft nj *r tuie d qa,rii n din
Fd q dr nqJn 5s @ ri tFa irl dd ftS dr har{ +@ fadr i aEdi
ffi gn ari + a'? qii 4ra e r* ftm qr4 6 qw qit afi d RA t
.i d Flrfi d aq3niF l@ n dd 3R tar|l ffi q< ni + R! l@
,$.r{e c. rym f fto€ da fr (@ J nhJ ?:,i f{r f
al6 $

-,k'
j-

<!-- page 12 -->

ro ttud R i6n 6i tr$ 4rC1 + lm di A {{{ iA q s, 6i is l?e'ia ,
&d qii! 1+ 46 3n1] qt n tfre 3ra ft 5sde dr s6l 5F q 6nn rn ft6
irFa + ]m di fi Fqi n {Jr \@ + &d Fd iF {F $ flin di l@
5@/
frFd E@ hqiqJh q 4 .qd nri t fiF d{ i d qF 4
'o
qFft:d * Fsr n 3rt @ 4qF n:r4

r1 qi tr l@ e
infr to aF ta i fiq rdG tu! N qao aF i {q
.G rliriFa grF{'id4n
rw& afl, B.$ o{ n rifr4r 4r qn F1t * dF iq
qlJi,r nrri! d .qrd n( 4 sa{ srff4€r @ BFe 4 n arilrl
d.t + {hR C cdF @ t qfiYira 6i 466 d Fq Fglid ftR d4rE dC t
th fd & rEdl
r@ iJ, 3f4iaa 5!6€n t ufirfi:ra ri 3ik !@ 61

ffidt d {6 {riiirF q} & 6dt *d rdF'fid
A drfr to 46 ir'{n 6
Fr€4 6 qfa rnd € 50 !t d $ft6 rn1 n grt( €ffi -fr r1,t i_aF f6r'
N srf{ .l t6fr i 3lfArdtua F gBrt n fi-6 5w{!'i 4l mi. 6ri 3n
qrffi FFxt + {rt d rd i@li d, rllJ t .d i6 Ed 3i1i * fi6 -,'n
+ flq c;r4 at ar+R/F @ 6 qq F qriq
r, ffiq @ @ 9ra4 fi $F ffi d xffi +{ qqF rF f64 rrn4 a4lil
mFrim - ftr a r6tu s dtc ft$ tn @ iE4 ; !tu€ xirm 6.ra
h EqFe dmr rr]d ?@ ft aFfl n F i rd * fiF rsniq n a1na d3
Tra a !9 ar nF{ 6i n{ n rq{ {6 n dn oii( 3ft rq+@-i ir Frq

FlazqaiFFdl@4ftll
ir m.q m e na4 6:1.lFlr{N 6t @ + -,4 4ift +{ fi 3Ftu 6 dl{ra
s6a aira'ad iqdar a@ ffi qf$r' ii qd Ra qjFI nlfi cF 1+lfr 6.nd6r
r r 09 4 F flt r* | d n q ..t $l B:
t rHraa +t ,a na + lnft ffieo srr{ .q{4 q@ fm ir5{ dr
Ii.ill-m t4 h at d nfl l@ m 6i6 Ff{. +{ tu_4 n ffi t
i4. ffi,ir qw ry 9rl< rillFd d{ dir dli.r m qi a* siftrt/r3r6 eR
F@nin m + r.+d mr ( o{AE iid.de, 3rFd tFd@ @ a al
{r € C fl 1@, ?i@ €F {G n rA d nin gr d eiitu4 n q6 tt{
iffi sft6t/l@ dr. -FFid aqA Radr d Ri@ n {61
i5 iF q 3tr+ 4d i@,6rn 6 rr{ftrq, eiaE 6id 6 em ds irn{ d ntr
3ni? qiin m o{ {F toa :lM 3ih fflqitm fi{ 3m n 6r+ q,nn +r
fF fi 5qdqd SFfi_rd 6.4 d/ll tqr dgq F q-; srdl -a$I
l:rd h{ am fi {a 4. dr 3rflelF s hr 6il 46r{ rr4 F :qa q{ q6d
* €?@ n ft! qhn d tE{ ffi .ffi -S d'a
r/ 9rq*5F 6t # AA S fis nFr e's5a! S arG €.T afa FE fi sw,
ita rs 6tg nfe rnF rdr di 6J FrF i FTd +{ I@ .( ad @in
{rqv+F rr@ iq} a{tr6€t 6} a+ 4 F i s€t sffie -€ tua :lm
ilt ffi <+@rn n aw FFS da-a + sav t 3ri* ia I@ fi efffi dJn
16 +d I@ -t

tgat d1)

*,r1*>

<!-- page 13 -->

ql

6€t td 4i ati

ni
ara ftrs,{d r.rdr aa$d { rm b{t i6{ri
qze'ri
6r qt
$ oT eqrd3p h

sffi F .r

; f"* -.

'

,s *4 Fdd 6t oF i !,tu c .{ *
5wdr"I {Fr{Td 6{n $.m Fl

*trf + a"' "e' u'no U A" +* *t

H'

,e.

s{ qR 3re i ft! dd }+{ qi' n q{F' rF' rE d'$ a $@ qfta6rssR
a@$€m dr{ ad! ?ii r6s flin n f@6 ird } €q srqsg3lr

{d

,o al.{$r*}n 4i r(l4 6I ffA 4in n4 6
ffi F r@lr .d nGlr ffi ol ir

il sF 4F i €cl wilqd nc.d

a zr !e&Mt Fd raq n n drF @

a5 na b a! M|s di'er

m6

a tuF a '16ldl 6{insil@31Fdl addin m. aC ffi
tFrdiff tqi q{ A rliF R{r

n ed

qqs.qF + 3in tr rq} lid R1.d 611

flrn 3it{

?r n cqA 6 zira fl fi 4 f6_ddrF/

l{a}d{Fwdriq*?itirm
4iF.Rdft43@atneA{F
&. 63r ai+ +i a€ + fis l€3F aA
qf' qt qr€ai 6t A trn ffi {ftll
fid d iiGjtq 4a Ifr iffd{Dr q@
eFdr rifi 6t *s ljl@l

ffdr/4Fff6 (t n €rq dgds dr
r} h n
iri{ FqqF ]ffi

ffir lce + Rs 66 Fdftin

+ F( qs ji'M 6'l *$ vri 4a

n 6rt m fi m, di-dF otu"@

,s rt 6 R Ft {a+ dr ?iqfl {.6
Fr4 { 6j* m erF Fi, F,t dr sr6

{ri&{mtrnoft{l @6ff

!@ 6t $qi Fd n FF t
q 5qd*r ra4 qR! af6 3rFrd ffid

r6Flhp ttr 64r trrt{ ,rEr9n si4
dw F dT{rd d rF laF.{a ir

,6. F*/+{

jqra fla A Fqf d ift qGt

*"'"
r7
6rk

<!-- page 14 -->

.r€@ - rr

Fc/ora/lidr d w w
€@ to{ ni ?rd da@/BlF
r.1.rols 6

dn'rtd:h iq I
ri r,0r5 6 q66 arte (qF i
3r€q

i{ 6. 6is ri. a$ ta {,(

'5
tu
?s.oo^R a @ lrliF{ I

3rh' (n iqr En'6 €fu) 6 nq d qtl

iirBi/i?F]t M 3R inrd ;
4,fF C ar€ ffid/FiRd inq
q :fl Fd: mftd 31tr hfqc<
@ S d ?ri Rdt rirRct/it
M/FDI n $d!G6 td o@,
l{ 6{1{ n {iitud B€ a1ft 6t
t€ <tu d iF. q.4{ ..4 edt

tis i .trg qfird Aaf,d* taEz
6qtr{k)ffgaiq
x'ffr6 d d

,

qafiRmt

,,€ w @ qerd:t fe { Fq @

F.inFdlirrfqFe6

<!-- page 15 -->

{d ]@ < 2601rlorlror -r'oFo

<!-- page 16 -->

$€iilr t
A.q'3tr6irR. A ftai6 .....................dr 6{r{ {q

ffid 3N R ji'@ R @:ftTd

€q A2601 1/o3,/ro1+sroco

*r sqfi

1. fiji63ffiRji!{lrF*R{

@io 1, @ 3 i A{ }€i€
6.io r,? qi 3 6 hr 3-fiii€ la
nh Em etR CFq .f* r.@ 6

,.

t@ F @ {eB t E{ { Fw di rd ra6F 6li t @ ffi qF ffi 6

l
