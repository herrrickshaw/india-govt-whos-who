---
doc_id: "b6cb8cadeef9f62e"
source_url: "https://www.dsir.gov.in/static/uploads/2025/12/50034b5d16f8164a8944e750a02d6b8a.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Global invitation for Expression of Interest for proposed strategic disinvestment of 100.00% Shareholding in Central Electronics Limited (“CEL” or “Company”) by Government of India Corrigendum-5"
date: "2018-12-28"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "624cfb21aa570db1"
---

<!-- page 1 -->

Subject- Global invitation for Expression of Interest for proposed strategic disinvestment of 100.00%
Shareholding in Central Electronics Limited (“CEL” or “Company”) by Government of India
Corrigendum-5

Sr.
No.

1.

2.

3.

Reference Clause/Pg. No.
of Invitation of EOI

Existing clause

EoI shall be submitted physically
by the Interested Bidder on or
Section-1: Advertisement,
before 15.12.2018 (at 1100 hours
Last para.
IST) (“EoI Due Date”) at the
Page-5
address mentioned below.
Clause 3.3.14Biding Schedule
Point no. 5, Last date of
submission of EOI
Clause 3.3.14
Biding Schedule
Point no. 6- Opening of EOI

Shall read as
EOI shall be submitted physically by
the IP on or before 28.12.2018 (at
1100 hours IST) at address
mentioned below.

15.12.2018 at 1100 hours

28.12.2018 at 1100 hours

15.12.2018 at 1500 hours

28.12.2018 at 1500 hours

Sincerely
Resurgent India Limited
Transaction Advisor
Department of Investment & Public Asset Management (DIPAM)
