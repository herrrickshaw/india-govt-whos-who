---
doc_id: "30da682ecfb24abc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/11/73e6a490bfe3b1964e3c3349da4b2858.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Boiler Accident Inquiry Rules, 2021"
date: "2025-11-27"
pages: 5
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d2e0f9f18a9c8348"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-11092025-266075
xxxGIDHxxx
CG-DL-E-11092025-266075
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 572]

नई दिल्ली, बुधवार, जसतम्बर 10, 2025/भाद्र 19, 1947
NEW DELHI, WEDNESDAY, SEPTEMBER 10, 2025/BHADRA 19, 1947

No. 572]

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)
अजधसूचना
नई दिल्ली, 10 जसतम्बर, 2025
सा.का.जन. 616(अ).— कें द्रीय सरकार, बॉयलर अजधजनयम, 2025 (2025 का 12) की धारा 39 की उपधारा
(1) और उपधारा (2) के खंड (छ) द्वारा प्रित्त िजियों का प्रयोग करते हुए और बॉयलर िुर्धटना िांच जनयम, 2021 को
उन बातों के जसवाय अजधक्ांत करते हुए, जिन्हें ऐसे अजधक्मण से पूवध दकया गया है या करने का लोप दकया गया है,
जनम्नजलजखत जनयम बनाती है, अर्ाधत
1. संजिप्त िीर्धक और प्रारं भ – (1) इन जनयमों का संजिप्त नाम बॉयलर िुर्धटना िांच जनयम, 2025 है।
(2) ये रािपत्र में इनके प्रकािन की तारीख को प्रवृत्त होंगे।
2. पररभार्ा – (1) इन जनयमों में, िब तक दक संिभध से अन्यर्ा अपेजित न हो,–
(क) "अजधजनयम" से बॉयलर अजधजनयम, 2025 (2025 का 12) अजभप्रेत है;
(ख) "बोडध" से अजधजनयम की धारा 3 के अधीन गरित कें द्रीय बॉयलर बोडध अजभप्रेत है;
(ग) "मुख्य जनरीिक" से अजधजनयम के अधीन मुख्य जनरीिक के रूप में जनयुि कोई व्यजि अजभप्रेत है; और
6022 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(र्) "तकनीकी सलाहकार" से अजधजनयम की धारा 4 की उपधारा (1) के अधीन जनयुि तकनीकी सलाहकार
अजभप्रेत है।
(2) ऐसे िब्ि और पि िो इन जनयमों में प्रयुि दकये गये है और पररभाजर्त नहीं है, ककं तु अजधजनयम में
पररभाजर्त है, का वही अर्ध होगा िो उस अजधजनयम में क्मिः उनके जलए दिया गया है।
3. िुर्टध नाओं की िांच- अजधजनयम की धारा 23 के अधीन बॉयलर या बॉयलर र्टक की िुर्टध ना की ररपोटध प्राप्त होने पर,
उस संबंजधत राज्य में प्रारं जभक िांच की िाएगी जिसकी अजधकाररता में िुर्धटना हुई है।
4. िुर्टध नाएं जिसके पररणामस्ट्वरूप कोई मृत्यु हो िाए- संबंजधत राज्य का मुख्य जनरीिक, जिसकी अजधकाररता में िुर्धटना
के कारण कोई मृत्यु हुई हो, प्रारं जभक िांच के आधार पर, जबना दकसी जवलंब के प्ररूप 'क' में तकनीकी सलाहकार को ररपोटध
भेिेगा।
5. िुर्टध ना के पररणामस्ट्वरूप कोई मृत्यु होने पर िांच- (1) जनयम 3 पर प्रजतकू ल प्रभाव डाले जबना, िहां िुर्धटना के कारण
कोई मृत्यु हुई हो, वहां कें द्रीय सरकार द्वारा भी िांच की िाएगी।
6. िांच सजमजत का गिन- (1) दकसी िांच सजमजत द्वारा िांच की िाएगी, जिसमें जनम्नजलजखत सजम्मजलत होंगे, अर्ाधत:(i) तकनीकी सलाहकार - अध्यि;
(ii) बॉयलर का मुख्य जनरीिक या जनिेिक - सिस्ट्य;
(iii) बॉयलर और बॉयलर र्टक जवजनमाधता या बॉयलर के उपयोगकताध का प्रजतजनजध या बोडध का कोई अन्य सिस्ट्य - सिस्ट्य
(2) कें द्रीय सरकार दकसी ऐसे अन्य व्यजि को भी,जिसका िुर्धटना से जहतों का कोई टकराव न हो और यदि उसकी
उपजस्ट्र्जत िांच करने में उपयोगी हो तो,िांच सजमजत में िाजमल कर सकती है।
(3) संबंजधत राज्य के मुख्य जनरीिक से दकसी िुर्धटना के पररणामस्ट्वरूप मृत्यु की ररपोटध प्राप्त होने के पंद्रह दिनों
के भीतर िांच सजमजत का गिन दकया िाएगा और मुख्य जनरीिक से िुर्धटना की ररपोटध प्राप्त होने के पैंतालीस दिनों के
भीतर िांच की िाएगी।
7. िांच के िौरान प्रदक्या: - (1) िांच सजमजत िजतग्रस्ट्त भागों की सावधानीपूवधक परीिा करे गी और ररपोटध के प्रयोिनार्ध
ऐसे माप या रे खाजचत्र तर्ा ऐसे फोटो ले सके गी, जिन्हें वह आवश्यक समझे।
(2) िांच सजमजत िुर्धटना की पररजस्ट्र्जतयों, उसकी प्रकृ जत और जवस्ट्तार, व्यजियों की मृत्यु और चोट के कारण
तर्ा संपजत्त को हुए नुकसान की िांच करेगी और िांच ररपोटध कें द्रीय सरकार को प्रस्ट्तुत करेगी।
(3) कें द्रीय सरकार द्वारा ररपोटध स्ट्वीकार दकए िाने के पश्चात, िांच ररपोटध में की गई जसफाररिों के अनुसार
आवश्यक कारध वाई करने के जलए तकनीकी सलाहकार द्वारा संबंजधत राज्य के मुख्य जनरीिक को िांच ररपोटध अग्रेजर्त की
िाएगी।
8. िुर्टध ना के पररणामस्ट्वरूप दकसी की मृत्यु होने के पश्चात बॉयलर का उपयोग- (1) िांच पूरी होने तक बॉयलर का
उपयोग नहीं दकया िाएगा।
(2) िांच पूरी होने के पश्चात, संबंजधत राज्य का मुख्य जनरीिक यह जवजनश्चय करे गा दक क्या बॉयलर को जबना
मरम्मत के या दकसी ऐसी मरम्मत या पररवतधन, जिसका वह आिेि िें, के पूरा होने तक उसी या कम िबाव पर उपयोग
करने की अनुमजत िी िा सकती है।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

3

भारत का रािपत्र : असाधारण

प्ररूप क
(जनयम 4 िेख)ें
बॉयलर संख्या ……………….. की िुर्धटना की प्रारं जभक िांच की ररपोटध

सेवा में,
तकनीकी सलाहकार (बॉयलर)
उद्योग संवधधन और आंतररक व्यापार जवभाग,
वाजणज्य एवं उद्योग मंत्रालय,
भारत सरकार
महोिय/महोिया,
हमने बॉयलर संख्या ……………….. की िुर्धटना की प्रारंजभक िांच कर ली है और अब जनम्नजलजखत ररपोटध
प्रस्ट्तुत है।
1.िुर्धटना की तारीख और स्ट्र्ान
2. िांच की तारीख
3. स्ट्वामी का नाम और पता
4. मारे गये या र्ायल व्यजि
5. बॉयलर (बॉयलरों) का जववरण
(i) बॉयलर जनमाधता(जनमाधताओं) का नाम:
(ii) बॉयलर का प्रकार:
(iii) बॉयलर(बॉयलरों) की भाप उत्पािन िमता:
(iv) कायधिील िाब:
(v) तापन सतह िेत्र:
(vi) प्रयुि ईंधन:
(vii) बॉयलर(बॉयलरों) की आयु:
6. अन्य बॉयलरों के सापेि, बॉयलर(बॉयलरों) की सामान्य जस्ट्र्जत, उसका स्ट्र्ान और उद्देश्य जिसके जलए
उसका उपयोग दकया िाता है।
7. जपछली मरम्मत की तारीख सजहतजववरण
8. …………………. द्वारा तारीख…………………. को बॉयलर का अंजतम बार जनरीिण दकया गया
र्ा।
9. िुर्धटना की प्रकृ जत
10. िुर्धटना का कारण
11. सामान्य रटप्पजणयां
‘’मुख्य जनरीिक बॉयलर’’
[फा. सं. पी-30015/6/2025-बॉयलर]
डॉ. संध्या भुल्लर, संयि
ु सजचव

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

MINISTRY OF COMMERCE AND INDUSTRY
(Department For Promotion Of Industry And Internal Trade)
NOTIFICATION
New Delhi, the 10th September, 2025
G.S.R. 616(E).— In exercise of the powers conferred by sub-section (1) and clause (g) of subsection (2) of section 39 of the Boilers Act, 2025 (12 of 2025) and in supersession of the Boiler Accident
Inquiry Rules, 2021, except as respects things done or omitted to be done before such supersession, the
Central Government hereby makes the following rules, namely:-

1.

Short title and commencement. – (1) These rules may be called the Boiler Accident Inquiry
Rules, 2025.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

Definitions. – (1) In these rules, unless the context otherwise requires,–
(a) "Act" means the Boilers Act, 2025 (12 of 2025);
(b) “Board’ means Central Boilers Board constituted under section 3 of the Act;
(c) "Chief Inspector” means a person appointed to be a Chief Inspector under the Act; and
(d) “Technical Adviser” means the Technical Adviser appointed under sub-section (1) of section
4 of the Act.
(2) Words and expressions used and not defined in these rules, but defined in the Act shall
have the same meanings respectively assigned to them in that Act.
3.

Inquiry of accidents. – On receipt of a report of an accident to a boiler or boiler component
under section 23 of the Act, a preliminary inquiry shall be conducted in the concerned State in
whose jurisdiction the accident has occurred.

4.

Accidents resulting in any death. – The Chief Inspector of the concerned State in whose
jurisdiction any death has resulted due to an accident, based on a preliminary inquiry, shall
forward a report without delay to the Technical Adviser in Form A.

5.

Inquiry of accidents resulting in any death. – (1) Without prejudice to rule 3, where any death
has resulted due to an accident, an inquiry shall also be conducted by the Central Government.

6.

Constitution of inquiry committee. – (1) The inquiry shall be conducted by an inquiry
committee consisting of the following, namely:(i) Technical Adviser –Chairperson;
(ii) a Chief Inspector or Director of Boiler –Member;
(iii) a representative of Boiler and boiler component manufacturer or user of boilers or any
other member in the Board –Member.
(2) The Central Government may also co-opt any other person, who does not have any
conflict of interest with the accident, in the inquiry committee if his or her presence is considered
useful in conducting the inquiry.
(3) The inquiry committee shall be constituted within fifteen days of receipt of report of
accident resulting in any death from the Chief Inspector of the concerned state and inquiry shall
be conducted within forty-five days of receipt of report of accident from the Chief Inspector.

7.

Procedure during inquiry. – (1) The inquiry committee shall make a careful examination of the
damaged parts and shall take such measurements or sketches and may take such photographs for
the purpose of report as they may deem necessary.
(2) The inquiry committee shall inquire into the circumstances of the accident, its nature and
extent, the cause of death and injury to persons and the damage to property and shall submit the
inquiry report to the Central Government.

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

5

भारत का रािपत्र : असाधारण

(3) After acceptance of report by the Central Government, the inquiry report shall be
forwarded by the Technical Adviser to the Chief Inspector of the concerned state for initiating
necessary actions as per the recommendations in the inquiry report.
8.

Use of Boiler after accident resulting in any death. – (1) The boiler shall not be put to use till
the inquiry is completed.
(2) After completion of inquiry, the Chief Inspector of the concerned state shall decide
whether the use of boiler can be permitted at the same or at a lower pressure without repairs or
pending the completion of any repairs or alterations that he may order.
FORM A
(See rule 4)
Report of the preliminary inquiry of the accident to Boiler No………………..

To
Technical Adviser (Boiler)
Department for Promotion of Industry and Internal Trade,
Ministry of Commerce and Industry,
Government of India
Sir/Madam,
We have held a preliminary inquiry into the accident to Boiler No……………………. and now
make the following reports.
1.
2.
3.
4.

Date and Place of accident.
Date of inquiry.
Name and address of owner.
Person(s) killed or injured.

5.

Details of boiler(s).

(i)
Name of Boiler maker(s):
(ii)
Boiler(s) type:
(iii)
Steam generation capacity of boiler(s):
(iv)
Working pressure:
(v)
Heating surface Area:
(vi)
Fuel used:
(vii)
Age of boiler(s):
6. General condition of the boiler(s), its location with respect to other boilers and the purpose for which
it is used.
7.

Particulars of previous repairs with dates.

8.

The boiler was last inspected on ………………….by………………………….

9.
10.
11.

Nature of accident.
Cause of accident.
General remarks.
Chief Inspector of Boilers.”
[F. No. P-30015/6/2025-Boiler]
Dr. SANDHYA BHULLAR, Jt. Secy.
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. GORAKHA NATH
YADAVA

Digitally signed by GORAKHA
NATH YADAVA
Date: 2025.09.11 16:17:47 +05'30'
