---
doc_id: "30fb6aada170cb2d"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/1452ca6f24c7f8c1066632831405f930.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment in Recruitment Rules for the post of Technician X ray/Radiographer, LHMC & SSKH,New Delhi."
date: "2019-06-20"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5438332c6972effd"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
( MINISTRY OF HEALTH AND FAMILY WELFARE
Public Notice on draft Recruitment Rules for the post of Technician X ray/Radiographer
in LHMC & SSKH, New Delhi
In compliance with DoPT's OM No. AB.14017/61/2008-Estt.(RR) dated 13.10.2015,
the draft Recruitment Rules for the post of Technician X ray/Radiographer in LHMC & SSKH, |
New Delhi is annexed.
The stakeholders interested in making any objections/comments or suggestions on the
draft Recruitment Rules may do so in writing, within a period of 30 days from the date of |
publication of draft Recruitment Rules to Sh. Thenkholal Baite, Section Officer (MH-II), |
Room No. 405A, Directorate General of Health Services, Nirman Bhawan, Maulana Azad
Road, New Delhi-110108 or e-mail address: t.baitel2@nic.in
(60110)
Under Secretary to the Govt. of India
Tele: 011-23061521
New Delhi
Dated:
|
|
|
1

<!-- page 2 -->

/ |
( [TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART Il, SECTION 3, SUB-SECTION fil]
MINISTRY OF HEALTH AND FAMILY WELFARE [ |
Notification /
New Delhi, the / ०2019. |
GSR... In exercise of the powers conferred by the proviso to article 309 of the
Constitution and in supersession of the Lady Hardinge Medical College a 7 Shrimati
Sucheta Kriplani Hospital, New Delhi, (Group ‘C' posts) Recruitment Rules, 1981, in so far |
they relate to the post of Technician (X-Ray), in the Lady Hardinge Medical College
and Shrimati Sucheta Kriplani Hospital, except as respects things done or omitted to be
done before such supersession, the President hereby makes the following rules
regulating the method of recruitment to the post of Technician (X-Ray) in the Lady |
Hardinge Medical College and Shrimati Sucheta Kriplani Hospital, New Delhi, namely:- |
1. Short title and commencement. — (1) These rules may be called the Lady Hardinge
Medical College and Shrimati Sucheta Kriplani Hospital, New Delhi (Technician x
ray/Radiographer), Recruitment Rules, 2019.
|
(2) They shall come into force on the date of their publication in the Official Gazette. |
2. Number of post, classification, level in Pay matrix or pay scale. - The number of the |
said post, its classification and level in the pay matrix or pay scale attached thereto |
shall be as specified in columns (2) to (4) of the Schedule annexed to these rules.
3. Method of recruitment, age-limit, qualifications, etc. - The method of recruitment,
age-imit, qualifications and other matters relating to the said post shall be as specified |
in columns (5) to (13) of the said Schedule.
4, Disqualification. - No person, -
(a) who has entered into or contracted a marriage with a person having a spouse |
living; or |
(b) who, having a spouse living, has entered into or contracted a marriage with any |
person,
|
shall be eligible for appointment to the said post: |
Provided that the Central Government may, if satisfied that such marriage is |
permissiole under the personal law applicable to such person and the other party to |
the marriage and that there are other grounds for so doing, exempt any person from |
the operation of this rule. |
5. Power to relax. - Where the Central Government is of the opinion that it is necessary
or expedient so to do, it may, by order, and for reasons to be recorded in writing relax |
any of the provisions of these rules with respect to any class or category of persons.
6. Saving. - Nothing in these rules shall affect reservation, relaxation of age-limit and |
other concessions required to be provided for the Scheduled Castes, the Scheduled
Tribes, the Other Backward Classes. The Ex-servicemen and other special categories of
person in accordance with the orders issued by the Central Government from time to
time in this regard.
|

<!-- page 3 -->

है SCHEDULE
Name of post. Number of post. | Classification Level in pay | Whether selection
matrix or pay] post or non-
scale. selection post
Technician X | 18* (2019) General Level-4 in the pay | Not applicable.
ray/Radiographer ses Central matrix(25500- |
chin 1० | Service, Group | 81100) |
variation 'ट', Map
dependent on Gazetted, Non
workload. Ministerial
Age-limit for direct recruits Educational and other qualifications required
for direct recruits
Between 18 and 25 years. For Direct recruitment :
(Relaxable for Government servants up to | 12! Class pass with Science from a recognised |
forty years in case of general candidates and | Board.
forty-five years in case of candidates . Gah : न ।
belonging to The Schedule Castes and (a) Diploma or Certificate in Radiography |
7 fi 4 (Iwo Year duration) from a recognised
Scheduled Tribes in accordance with the Institute and |
instructions or orders issued by the Central (b) One year experience in Radiography in |
Government from time -to-time). a recognised Hospital or Medical Institute. |
Note : The crucial date for determining the
age limit shall be the closing date for receipt | Note 1: Qualifications are relaxable at the
of applications from candidates (and not the | discretion of the Staff Selection Commission for
closing date prescribed for those in Assam, | the reasons to be recorded in writing in case of |
Meghalaya, Arunachal Pradesh, Mizoram, | Candidates otherwise well qualified. |
Manipur, Nagaland, Tripura, Sikkim, Ladakh Note 2: Qualifications regarding experience
Division of Jammu and Kashmir State, Lahaul | Gre relaxable at the discretion of the Siaff
and Spiti District and Pangi Sub Division of | selection Commission for the reasons to be
Chamba District of Himachal Pradesh.the | recorded in writing in the case of candidates
Union Territory of the Andaman and Nicobar belonging to the Scheduled Castes or the
Islands or the Union Terriory of Lakshadweep). Scheduled Tribes, if, at any stage of selection
the Staff Selection Commission is of the opinion
that sufficient number of candidates
belonging to these communities possessing the |
requisite experience are not likely to be)
available to fill up the vacancies reserved for
them.
है |

<!-- page 4 -->

Whether age and} Period of probation, | Method of recruitment, whether by direct
educational if any recruitment or by promotion or by deputation
qualifications /absorption and percentage of the vacancies
prescribed for direct to be filled by various methods
recruits will apply in the
case of promotes. | |
Not applicable. 2 years for Direct 5% by promotion failing which by deputation
recruiters. and
95% by direct recruitment.
|
|

<!-- page 5 -->

incase of recruitment by| If a Departmental Promotion | Circumstances in which Union
promotion or deputation | Committee exists, what is _ its | Public Services Commission is to
or absorption grade from | Composition @ be consulted in = making
which promotion — or recruitment.
deputation/ absorption
to be made,
Promotion: Group *c Departmental | Not applicable.
Confirmation or promotion |
Dark Room Assistant with Commitee : |
five years regular ServICe | 1 Director, Lady Hardinge Medical
in Lady — Hardinge | college, New Delhi .
Medical College in pay -Chairman:
level-3 (21700-69100) Of | > Head of concemed Department,
the pay matrix. Lady Hardinge Medical College,
Deputation: New Delhi
-Member;
(I) From amongst the | 3. Deputy Director Administration,
Officers working under | Lady Hardinge Medical College,
the Central Government | New Delhi
or State Government or -Member;
Union territories or | 4. Deputy Director Administration, in
autonomous or statutory | charge of Medical Hospital Section,
organisations or Public | Directorate General of Health |
Sector Undertaking or | Services, New Delhi
Universities or recognised -Member.
Research Institutes:
(a) (i) holding analogous
posts on regular basis in
the parent cadre or
department ;
or
(ii) with two years regular
service in the grade
rendered after
appointment thereto on
a regular basis in Level 3
or equivalent in the
parent cadre or
department; हि
and
(b) possessing ° the
ualification and

<!-- page 6 -->

९ =|
prescribed for direct
recruits under column
7.
(the maximum age limit
for appointment 0५
deputation shall be not |
exceeding 56 years as on |
the closing date of
| receipt of applications)
[A.11018/08/2019-MH 11]
(G.P. Samanta)
Under Secretary to the Government of India.
|
