---
doc_id: "358bbdee2cd1ac25"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/423805be4a08d1820c9f96692aa81329.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification 12-08-2008"
date: "2025-07-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "20b9f8f31cb239e8"
---

<!-- page 1 -->

REGD. NO. D. L. -33004/99
fa@ uo <lo u°-33004/99

%
14
3
1
I
�
J�
a
i
d
u
f
o
e
tt
e
z
a
G
@i e
34444UT
EXTRAORDINARY
4FI II@ug 33q-qug (ii)
PART II-Section 3-Sub-section (ii)
yfuak 4 uaifeia
PUBLISHED BY AUTHORITY

1930
12, 2008/mavt 21,
«§ fess , un@an, ma
, 1930
NEW DELHI, TUESDAY, AUGUST 12, 2008/SRAVANA 21

i. 1151]
No. 1 1 51]

MINISTRY OF COMMERCE AND INDUSTRY
(Departmentof Industrial Policy and Promotion)
(PAPER SECTION)
ORDER

anfu-q air sen ianaq
)
(arenfna, {ifa it iadt faun
( a1Tei 3I[MEI)
segt

feet , 11 ant , 2008
sum (fa4ra ii
l.3T. 2029(31).J4 utst,
1 65) 1 4Id 180 gRI
)
44,
faftd41 If4fm
1951 (1951
e fain ei, 2004
3<a ufaaii i yim d Ku, qafu
ma:
i aai
sne
izu1 ti feu fafafaa
ua) snai,
(i
fqiavi
-qafue
a)
t
1. (1) a se
2008 l � I
ail di8a a1 3ad
(2) qe la4a g gad 4eRii

e,

a

1 1qui �
2. fue feiavi met, 2004
ai fna -n sit
(1) ii =gafue fafniansi'
sit ad
� araftea 4 aaf4a « 4 i, au i. 86
lei um,
fmfafaa
eat,
yfafeai
iafua
ea eid :
fefmas, mia ii,
"87. Aud a-i at fies
, ara w4 1"
aee , gfiaa de, ma«qt
[i. i. 4 (3)/2008-Ms]

UH. • y4K,4I Rf4a
H i. .31. 1105 (),
la
4ta
i
Re
feqot : Hi
1
yaifitd fa.qi 4I
iila 11 14a@7, 2004 ded
,
t
28
f<aia
a
m sit ma aava i s+f
.
1866
L.31
gTI
(1)
i<
i.
reg1
2008 �
uvmfa fsqi qi q I

New Delhi, the 11th August, 2008
S.O. 2029(E).-In exercise of the powers conferred
nt
by Section 18 G of the Industries (Developme and Regu­
lation) Act, 1951 (65 0f1951), the Central Government hereby
makes the following Order to amend the Newsprint Control
Order, 2004, namely :-

1. (1) This Order may be called the Newsprint
Control (Amendment) Order, 2008.
(2) It shall come into force on the date of its
publication in the Official Gazette.
2. In the Newsprint Control Order, 2004, in the
Schedule,
name of the Mill and
(1) In item 4 relating to the
Location of the indigenous newsprint manufacturers, after
S. No. 86 and the entries relating thereto, the following
shall be added, namely :
Mills Limited, Village
"87. M/s. Khanna Paper
of
Road, Amrit sar, in the State
Nangli, Fatehgarh Churian
Punjab."
[F. No. 4(3)/2008-Paper]
N. N. PRASAD, Jt. Secy.
tte
was published in the Gaze
Note : The principal order
dated 1 1th October,
(E),
1105
S.O.
No.
vide
of India
amend ed vide Order
2004 , and subs equently
July, 2008 published in
2
8th
dated
(B),
No. S.O. 1866
India.
the Gazette of

3043 GI/2008
New4.Delhi- 110064
Printed by the Manager, Govt. of India Press, Ring Road, Mayapur1i,1005
and Published by the Controller of Publications, Delhi-
