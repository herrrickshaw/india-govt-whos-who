---
doc_id: "31c22d9baea0ceb2"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/b27d530ff1630bc73b1f98c714608b60.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "FAQ Order dated 30-05-05"
date: "2005-05-30"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bcd746706901be27"
---

<!-- page 1 -->

No.A-11013/4/2005-Admn.II/Ab.Cell
Government of India
Ministry of Communications & Information Technology
Department of Telecommunications
(Absorption Cell)
R.No.520, Sanchar Bhawan,
20, Ashoka Road, New Delhi-110001.
Dated May 30, 2005
CLARIFICATION
Ref.: DoT’s OM No.A-11013/1/2005-Admn.II dated 24th March, 2005 regarding
calling of option of absorption of Group A officers of different services
in MTNL/BSNL.
******
After issue of DOT’s OM referred to above, some Associations of Group `A’
Officers, as well as some of the individual officers and MTNL/BSNL had sought
further information and clarification on various issues regarding absorption. Similarly,
some of the officers had also approached the relevant judicial authorities in these
matters.
All the issues raised by the officers and the Associations as well as
MTNL/BSNL have been deliberated by the Allocation Committee referred to in para
15 of the DOT’s OM dated 24.03.2005. Based on its recommendations the
Government is pleased to issue the following clarifications in respect of such issues.
This clarification is also posted on the website for wide dissemination and
information.
Q1. I may please be furnished with the following clarifications so as to enable me
to arrive at a considered decision: i) Promotional Avenues in MTNL, BSNL and in Government
ii) Recruitment Rules, which will govern my career progression in these
organizations
iii) Service Conditions in BSNL/MTNL
iv) Conduct, discipline and Appeal Rules in BSNL/MTNL
v) Job Security in BSNL/MTNL, especially w.r.t. financial viability of the PSUs
vi) Payment of pension from consolidated fund of India or from any other source
of Government and its continuity in the event of BSNL & MTNL getting
disinvested beyond 51%.
A. i) – ii)
The directly recruited officers in the grade of CDA 8000-275-13500/(corresponding IDA Rs.13000-350-18250/- in BSNL and IDA Rs.14500-350-18700 in
MTNL) have the avenues of promotion going upto IDA pay scale of Rs.25000-65030200/- (corresponding to CDA Rs.22400-525-24500/-) depending upon the
company’s business and policies.

<!-- page 2 -->

2

The Board level appointments in MTNL/BSNL are done through PESB and salary
structure and the eligibility conditions of board level officers are separately fixed by
DPE/PESB. Further highest notified scale of Rs.25000-650-30200/- is available for
officers below board level in BSNL/MTNL. So far as the officers opting to continue in
govt. service are concerned, their allocation in the govt. would be done as per the
requirement of this Ministry/other Ministries in the Govt. and as per the provisions of
the scheme for redeployment of the Surplus Staff. Accordingly the promotional
avenues will depend upon the allocation and the policy of the Department/Ministry to
which the officer is allocated.
iii) The service conditions in BSNL/MTNL will be regulated as per the policy of the
respective PSU.
iv) This will be as per the personnel policy of the respective PSUs.
v) The job security with reference to financial viability will depend on the business
strategy and competitive strength of the PSU, leading to their overall profitability.
vi) The pension to the Group A officers upon their absorption in BSNL/MTNL shall be
paid as per the relevant provisions of Rule 37-A of CCS (Pension) Rules, 1972.
Clause 19 and 20 of this Rule provide necessary safeguards against inability of the
MTNL to provide for its contribution. Further in respect of BSNL, clause 21 of Rule
37 A of CCS (Pension) Rules, 1972 provides as under :“Nothing contained in sub-rules (12) to (20) shall apply in the case of
conversion of the Departments of Telecom Services and Telecom Operations into
Bharat Sanchar Nigam Limited, in which case the pensionary benefits including
family pension shall be paid by the Government.”
Further, the provisions available under sub-rule 25 and 26 of Rule 37A of CCS
(Pension) Rules, 1972 as reproduced below shall be applicable:
(25)
“In case the Government disinvests its equity in any Public Sector
Undertaking or Autonomous body to the extent of fifty-one per cent or more, it
shall specify adequate safeguards for protecting the interests of the absorbed
employees of such Public Sector Undertaking or Autonomous Body.”
(26) “The safeguards specified under sub-rule (25) shall include option for
voluntary retirement or continued service in the undertaking or body, as the
case may be , or voluntary retirement benefits on terms applicable to
Government employees or employees of the Public Sector Undertaking or
Autonomous Body as per option of the employees, assured payment of
earned pensionary benefits with relaxation in period of qualifying service, as
may be decided by the Government.”
Q2. As per letter under reference the effective date of absorption is given as
1.10.2000 and it is mentioned that the officers officiating in higher grades on adhoc/local officiating/regular will be absorbed in MTNL/BSNL in the substantive grade
only. In this connection, it may kindly be noted that Govt. of India had issued
promotion orders (both ad-hoc & regular) during the intervening period ie, from
1.10.2000 to 24.3.2005 and absorbing at substantive grade only will leave me getting
absorbed in a lower grade as against my the then adhoc and present higher
substantive grade, which will be demotion of me. I should not be put to loss for the

<!-- page 3 -->

3

delay caused by the Government to conduct DPC or failure to carry out long pending
Cadre Review after year 1988 against the norm of every after 4 years. It is also not
clear in the option calling circular whether PSUs will consider my commensurate
promotions during the period.
A. The effective date of absorption for Group-A officers shall remain as 1.10.2000.
Any adhoc/regular promotion made in the govt. after 1.10.2000 shall be carried
forward by the respective PSUs and the pay fitment will be accordingly allowed. The
inter-se seniority of the respective cadres between officers of Group B stream
promoted to Group A and the Group A officers recruited directly shall be the same as
was prevailing in DOT as on 1.10.2000 (effective date of absorption) subject to any
alteration in the seniority made by DOT after 1.10.2000 till the Presidential Order for
absorption is issued. However, after issue of Presidential Order for absorption any
adhoc / local officiating arrangement shall be at the discretion of respective PSU.
Q3. As per CCS (Pension) Rule 37-A, the date of absorption should be only the
date of acceptance of the option by Government. Calling option for absorption with
retrospective effect does not serve common justice, that too after four and a half
years of formation of BSNL in this particular case of Gr. ‘A’ absorption when there
was a Government decision about an extended period of deemed deputation of 5
years. Even the facility of option which was given to Group ‘B’ officers even after the
completion of their absorption to choose suitable date vide Ltr.1-5/2004-PAT(B)
dated 30/06/2004 is denied to me.
A. In order to have uniformity in the absorption of Group A officers in BSNL/MTNL, a
cut off date of 1.10.2000 has been kept which was also the date of formation of
BSNL. The absorption of Group-B officers in BSNL/MTNL was also accepted by the
Govt. w.e.f. 1.10.2000 and took effect from that date (1.10.2000). Hence there is no
contravention of Rule 37A of CCS (Pension) Rules 1972 as the govt. has decided to
accept the option of Group-A officers for their absorption in MTNL / BSNL w.e.f.
1.10.2000.The provisions of Para 4 of DOP&PW OM No. 4/18/87-P&PW(D) dated
5.7.89 referred in letter dated 30.06.2004 shall also be applicable to Group A
officers.
Q4. It is mentioned that DOT would consider the option given by Group ‘A’ officers
alongwith the availability of posts in MTNL/BSNL and the personnel requirement of
these organizations and make final allocation of officers to BSNL, MTNL. In the
absence of information regarding availability of posts and personnel requirement of
MTNL, BSNL and DOT or Government, giving an option is impossible for me.
A. In view of the provision under item 12 of the general Terms and Conditions given
in the O.M. dated 24.3.2005 “DOT will consider the option exercised by Group A
offices along with the availability of posts in MTNL/BSNL and the personnel
requirement of these organizations and make final allocation of officers to
MTNL/BSNL or retention in DOT/DOP depending on the organizational needs and
public interest. The decision of DOT in this regard shall be final and binding on the
officer. MTNL/BSNL would absorb optees as would be allocated by DOT”, it should
be possible for the Group A officers to exercise their option for absorption in
BSNL/MTNL as per their assessment.

<!-- page 4 -->

4

Q5. It is mentioned in the absorption letter that the inter-se-seniority of officers in
various grades in MTNL/BSNL shall be governed by the date of absorption and the
seniority list maintained by the cadre controlling authority. How the inter-se-seniority
of officers is governed by the date of absorption is not clear.
A. This would imply that the seniority within the respective cadres between officers
of Group B stream promoted to Group A and the Group A officers recruited directly
shall be the same as was prevailing in DOT as on 1.10.2000 (effective date of
absorption) subject to any alteration in the seniority made by DOT after 1.10.2000 till
the Presidential Order for absorption is issued.
Q6. Different pay scales have been offered for MTNL/BSNL. This may not be in
order in view of the common dictum, “Same work, Same Pay”. As the officers have
been recruited against the same Recruitment Rules of Government of India,
(Department of Telecom No. 05-4/65-STA-I dated 14/04/1965 & ITS Group ‘A’
Recruitment Rule 1990) and appointed by the President of India, discrimination of
pay scales is not justifiable to officers in organizations with similar nature of job and
responsibilities. Two persons presently belonging to the same cadre, grade and
year of recruitment in Government Service, if one opts for MTNL and other for BSNL
then the one opting for BSNL would not be eligible for applying for senior positions in
some PSUs while the other will be eligible because of difference in pay-scale being
offered. This is indicative of serious anomaly.
A.
The mapping of existing CDA to corresponding IDA pay scale for MTNL/BSNL
is contained in the OM dated 24.3.2005 calling for the option for absorption from
Group A officers. Based on the assessment of the officer, he can give his option
accordingly.
Q7. Under clause 8 of the Terms and Condition it is stated that “To the extent
possible, the same principles of pay fitment as followed in other categories i.e. Group
‘B’, ‘C’ and ‘D’ employees who already stand absorbed in MTNL/BSNL shall apply in
the case of Group ‘A’ officer, i.e., point-to-point fixation of pay; In cases where the
minimum benefit (Pay + DA) on absorption in MTNL/BSNL on 1.10.2000 falls short of
Rs.2500/-, it will be enhanced to Rs.2500 and the difference will be treated as
personal pay of the officer as on 1.10.2000”. In this regard, I wish to state that the
conditions of I.T.S. Group A officers and Group ‘B’, ‘C’ & ‘D’ employees are not
identical in any manner, your attempt to apply common principle on unequal persons
would result in varying of service conditions /mis-fitment.
A. Point-to-point fixation of pay shall be applied for fitment from the existing CDA
pay scale to the corresponding IDA pay scale. The fitment methodology of point-topoint fixation has been adopted in order to broadly maintain uniformity of pay fixation
from CDA to IDA pay scale with the fitment method applied in case of pay fixation of
Group B, C & D employees. On absorption of Group-A officers in BSNL/MTNL, the
point-to-point fixation of pay shall be applied for fitment from the existing CDA pay
scale to the corresponding IDA pay scale. The basic pay of the executives as on
01.10.2000 in the IDA pay scales would be fixed at the stage corresponding to the
stage which they have reached in CDA pay scale on 30.9.2000 i.e. the pay fixation
will be on point-to-point basis. If the minimum benefit (Pay+DA) on absorption in

<!-- page 5 -->

5

MTNL/BSNL on 1.10.2000 falls short of Rs.2500/-, it will be enhanced to Rs.2500/and the difference will be treated as the personal pay of the officer as on 1.10.2000.
Thus the methodology of fitment from CDA pay scale to IDA pay scale will be similar
to that made applicable in case of absorption of Group-B officers in respective PSUs.
This does not mean varying service conditions.
Q8. The pay scale offered is also not at all attractive as compared to 65%
increase in emoluments as on 1-10-2000 to other executives offered at the time of
absorption. The fitment method is not clearly spelt. It is mentioned that if the
minimum benefit is less than Rs. 2500 as on 1-10-2000, it will be enhanced to
Rs.2500 and the difference will be treated as personal pay of the officer as on
1.10.2000. It is not clear if this benefit would continue even on subsequent fixations
after 1.10.2000. The total emoluments as on date will be less than what I am getting
now. This is also contrary to the principle of ensuring the mandatory differential in
pay of supervisory management cadre Group ‘A’ officers in BSNL/MTNL when
compared to Group ‘B’, ‘C’, ‘D’ employees. For ensuring the same differential pay in
original CDA pay scale of Group ‘B’, ‘C’, ‘D’ w.r.t Group ‘A’, a minimum of Rs.5000 to
Rs.8000 is to be ensured depending on the grade of Group ‘A’ officers by way of
additional increments while fixing pay in BSNL/MTNL rather than the personal pay
offered to insure Rs. 2500/-.
A.
The mapping of existing CDA to corresponding IDA pay scale in case of
absorption of Group A officers in BSNL/MTNL has been prescribed in the OM dated
24.3.2005. The fitment based on point-to-point method from existing CDA scale to
corresponding IDA scale shall be done after absorption of the Group A officers in
respective PSU. If the minimum benefit (Pay+DA) on absorption in MTNL/BSNL on
01.10.2000 falls short of Rs.2500/- it will be enhanced to Rs.2500/- and the
difference will be treated as the personal pay of the officer as on 01.10.2000. The
difference will be at the absorption stage only and would not continue in subsequent
fixations. The difference/rise in the gross salary drawn may vary from person to
person depending on his grade/pay scale/increment stage etc. It is not necessary
that the hike, if any, in emoluments be similar for all categories of employees. The
govt. has given free choice to the Group A officers to exercise their option for
absorption in BSNL/MTNL which they may exercise.
Q9. Recovery of ad hoc payment already made to me, in case I opt for
Government service, is highly irregular as I had already discharged duties as an
employee of the organization under deemed deputation and the remuneration
received is against these services rendered in BSNL under the changed working
pattern of 6 day working etc. It is also against the written assurances given already
by the BSNL management while issuing the ad hoc payment vide letter no.
BSNL/32/SR/2003 dated 17/06/2004. There was no recovery of Rs. 2000 paid to
Group ‘B’ officers even though an undertaking was taken to this effect from those
who opted for Government Service.
Vide letter no. BSNL/11/SR/03 dated
17/06/2004 this amount as ad hoc payment was treated as compensation for
working in BSNL. This particular condition according to me is a coercive measure.
A. Different orders granting adhoc amount do not imply that the recovery would not
be made on absorption. It only prescribes the quantum of adhoc amount, the period

<!-- page 6 -->

6

and the category of persons who are to be paid the amount. Hence, the proposed
recovery is in order.
Q10. The criteria for finalization by the Allocation Committee based on options
submitted by officers is not mentioned, and this can lead to biased allocations. It is
given that the Allocation Committee will deliberate on the options and recommend
allocation of officers to MTNL/BSNL. At least, the basic criteria for allocation may be
made clear since the pay scales offered and the service area of the two
organizations and of DOT (Government service) are different.
A. The allocation of officers for their absorption in BSNL/MTNL shall be based on
factors like (i) the options exercised (ii) the working strength as on the date of
allocation, (iii) seniority and (iv) incumbency in PSU with a view to have minimized
dislocation and facilitate smooth functioning of PSUs in the absorption phase etc.
Q11. The officers opting for MTNL would be covered by the pension scheme of
MTNL and the officers opting for BSNL would be entitled to pension from the
Government. No rule, under which MTNL or BSNL allotees will get the pension, has
been mentioned. The pension scheme of MTNL and BSNL with clear mention of
relevant rule may be provided to me. It is given to understand that BSNL will have to
provide pension contribution to the Government. In the case of BSNL becoming
unable to give pension contribution due to bad financial health, it is not clear whether
government will continue to provide further pension.
A. The pension to the Group A officers upon their absorption in BSNL/MTNL shall
be paid as per the relevant provisions of Rule 37-A of CCS (Pension) Rules, 1972.
Clause 19 and 20 of this Rule provide necessary safeguards against inability of the
MTNL to provide for its contribution. Further in respect of BSNL, clause 21 of Rule
37 A of CCS (Pension) Rules, 1972 provides as under :“Nothing contained in sub-rules (12) to (20) shall apply in the case of conversion of
the Departments of Telecom Services and Telecom Operations into Bharat Sanchar
Nigam Limited, in which case the pensionary benefits including family pension shall
be paid by the Government.”
Q12. Government pension being assured if it is as per CCS (Pension) Rule 37-A
needs to be clarified as there are deviation on this as per rule 37-A of CCS (Pension)
rule by simple administrative orders from BSNL. For example, the benefit of five
years of additional qualifying service for VRS from BSNL after 20 years of service is
not allowed. For absorbed employee of BSNL vide letter no. 31-94/04/Pen (BSNL)
dated 08/10/2004. Hence Government pension assured in the terms and conditions
for Group-A absorption needs clarifications.
A. Rule 37-A of CCS (Pension) Rules, 1972 would govern the case.
Q13. PSU executives holding posts in the pay scale of Rs.18,500-23,900 with IDA
or Rs.14,300-18,300 with CDA or equivalent scale of pay are eligible to apply for
Schedule ‘C’ post in PSUs. In the option letter IDA scale of Rs.17,500-22,500 (E6)
has been proposed as replacement scale for the CDA Scale of Rs.14,300-18,300 in
the BSNL. This would make JAG selection grade level officers ineligible to apply for

<!-- page 7 -->

7

Scheduled ‘C’ post after they take absorption in BSNL. This is a clear instance of
demotion of Group ‘A’ officers if they take absorption in BSNL.
A.
The mapping of existing CDA to corresponding IDA pay scale for MTNL/BSNL
is contained in the OM dated 24.3.2005 calling for the option for absorption from
Group A officers. The officer is free to exercise his option accordingly.
Q14. It has not been intimated in the letter that in case of option is given for
Government Service, then the officers would be posted in which Department of the
Government Service and number of vacancies therein. It is also not clear as which
Recruitment Rules will govern the service conditions. It is also to be clarified if the
government will fill up ex-cadre Group-A posts of central government all over India
with ITS officers opting for government service.
A. The allocation of officers opting to continue in govt. service in the govt. would be
done as per the requirement of the departments of this Ministry / other Ministries in
the Govt. and as per the provisions of the scheme for redeployment of the Surplus
Staff. Accordingly, this will depend upon the allocation and the policy of the
Department / Ministry to which the officer is allocated.
Q15. Number of vacancies in MTNL/ BSNL / govt. service which DOT intends to fill
up through permanent absorption basis have not been mentioned with the option
form.
A. The vacancies cannot be foreseen by the Govt. at this stage and it would depend
upon the requirement from time to time.
Q16. Criteria for allocation of officers to MTNL/BSNL/Government Service have not
been spelt out in the said letter thus leaving the sufficient scope for arbitrary and
non-transparent allocation.
A. The allocation of officers for their absorption in BSNL/MTNL shall be based on
factors like (i) the options exercised (ii) the working strength as on the date of
allocation, (iii) seniority and (iv) incumbency in PSU with a view to have minimized
dislocation and facilitate smooth functioning of PSUs in the absorption phase etc.
Q17. The Criteria for deciding organizational needs and public interest in Para 12 of
the said letter of DOT has not been elaborated and hence it is very vague.
A. “Public interest” is a well understood term and does not require further
clarification. Organisational needs are related to the overall business plan and
working strength.
Q18. Group ‘A’ officers of ITS/TTS and TFS have been asked to opt for
MTNL/BSNL/ Government Service through a common circular. It may be clarified
whether the three cadres would remain separate or would be merged and in case of
latter what would be the criteria for deciding inter se seniority. It would be against
natural justice, public interest and interest of service to merge the said cadres.

<!-- page 8 -->

8

A. Asking for option through a common Circular does not ipso facto mean that the
cadres would be merged. Seniority within the respective cadres shall be the same as
was prevailing in DOT as on 1.10.2000 (effective date of absorption) subject to any
alteration in the seniority made by DOT after 1.10.2000 till the Presidential Order for
absorption is issued. However, after issue of Presidential Order, the cadre
management of executives in PSUs will be governed by personnel policy of
respective PSU.
Q19. Different pay scales and pension policy have been offered for BSNL and
MTNL. The reason for the same is not mentioned. It appears that there would be
different future perspective and service conditions in the two organizations for which
different pay scales and pensions have been offered. The same should be confirmed
so that I can take a considered decision. The future prospects of Group 'A'
employees opting for these organizations, financial viability of BSNL, MTNL in the
long run, future plans of MTNL and BSNL should be intimated in detail for taking a
considered decision.
A. MTNL and BSNL are different organizations. The mapping of existing CDA to
corresponding IDA pay scale for MTNL/BSNL is contained in the OM dated
24.3.2005 calling for the option for absorption from Group ‘A’ officers. The directly
recruited officers in the grade of CDA 8000-275-13500/- (corresponding IDA Rs.
13000-350-18250/- in BSNL and IDA Rs.14500-350-18700 in MTNL) have the
avenues of promotion going upto IDA pay scale of Rs. 25000-650-30200/(corresponding to CDA Rs.22400-525-24500/-) depending upon the company’s
business and policies. The Board level appointments in MTNL/BSNL are done
through PESB and salary structure and the eligibility conditions of board level
officers are separately fixed by DPE/PESB. Further highest notified scale of
Rs.25000-650-30200/- is available for officers below board level in BSNL / MTNL.
Q20. Cadre controlling authority for BSNL, MTNL and officers opting for
Government Service may be clarified. No mention about the cadre management of
Group ‘A’ posts in the PSUs. This ambiguity may be clarified.
A. The cadre structure/cadre controlling authority for BSNL/MTNL shall be as per
the personnel policy of the respective PSU. In so far as the officers opting to
continue in govt. service are concerned, their allocation in the govt. would be done
as per the requirement of the departments of this Ministry / other Ministries in the
Govt. and as per the provisions of the scheme for redeployment of the Surplus Staff.
Accordingly this will depend upon the allocation and the policy of the Department /
Ministry to which the officer is allocated.
Q21. It has been proposed to absorb officers’ w.e.f. 1.10.2000 on the basis of grade
(designation) held by them substantively. It has not been clarified as what grade /
post would be given to the officers who have been regularly promoted by the
Government through UPSC after 30.09.2000 to higher posts.
A. The effective date of absorption for Group-A officers shall remain as 1.10.2000.
Any adhoc / regular promotion made in the govt. after 1.10.2000 shall be carried
forward by the respective PSUs and the pay fitment will be accordingly allowed. The

<!-- page 9 -->

9

Seniority within the respective cadres between officers of Group B stream promoted
to Group A and the Group A officers recruited directly shall be the same as was
prevailing in DOT as on 1.10.2000 (effective date of absorption) subject to any
alteration in the seniority made by DOT after 1.10.2000 till the Presidential Order for
absorption is issued. However, after issue of Presidential Order for absorption any
adhoc / local officiating arrangement shall be at the discretion of respective PSU.
Q22. Para 9 of the terms and conditions stated are contradictory to the letter no.
BSNL/32/SR/ 2003 dated 17/06/2004 of BSNL regarding payment of
compensatory/ad hoc amount etc. to BSNL officers. Increment and pay when the
officer reaches ceiling of the grade, which may also due to fixation of pay from CDA
to IDA has not been intimated.
A.
Different orders granting ad hoc amount do not imply that the recovery would
not be made on absorption. It only prescribes the quantum of ad hoc amount, the
period and the category of persons who are to be paid the amount. Hence, the
proposed recovery is in order. Stagnation increment will be governed by the extant
policy of the respective PSU in force at the relevant time.
Q23. It has not been intimated whether direct recruitment/lateral entry at various
levels would also happen in BSNL/MTNL after absorption of Group ‘A’ officers. As
such, promotional avenues of the Group ‘A’ officers opting for BSNL and MTNL get
affected. This should be clarified.
A. Whether direct recruitment/ lateral entry will take place, will depend upon the
personnel policies and the organizational needs of the respective PSUs
Q24. It has not been specified as to what would happen to the existing contribution
made by the Group 'A' officers for CGEIS on opting for MTNL/BSNL.
A. The treatment of CGEIS contribution will be in terms of G.I., M.F., O.M. No.
F.7(1)-E.V/89 dated 29.9.1989.
Q25. Various rules of the Government/PSUs have been referred to. However, a
copy of the said rules has not been provided so as to know and understand the
rules, which have been referred to.
A. The rules referred to in the O.M. dated 24/03/2005 are available in the public
domain.
Q26. It has not been specified that what are the future organizational plans of
BSNL/MTNL. Whether in future, it is likely to propose further bifurcation of
BSNL/MTNL and thus resulting in giving further options for the respective bifurcated
entities.
A.
The future organisational plans of BSNL/MTNL will be decided from time to
time by the respective managements/government, keeping in view the aspects of
financial viability, business strategy, competitive strength, provision of better services
to consumers and growth of the respective organization.

<!-- page 10 -->

10

Q27. Merger of BSNL and MTNL is also under consideration of the Government as
per newspaper reports. It has also not been intimated as to what would be the status
of officers, their inter-se-seniority and pay anomaly, which would arise.
A. Same as for Q.26.
Q28. Nothing has been mentioned about other perks like LTC etc.
A. The perks including LTC will be available as per the extant policy of the respective
PSU.
Q29. It has also not been intimated whether concurrence for taking the said options
has been taken from Commission (UPSC) as ITS Group ‘A’ is an organized Group
‘A’ service under Government of India, recruited by UPSC through ‘Engineering
Service Exam’ and appointed by the President of India.
A.
The Government has decided to seek option from Group ‘A’ officers of the
department for their absorption in BSNL/MTNL after due consideration at the
appropriate levels.
Q30. It has not been assured that the terms and conditions finalized at the time of
absorption would not be changed subsequently after absorption against the interest
of employees. If these PSUs at any time in future are disinvested by more than 51%,
what will be the status for the terms and conditions, including those for pensions,
being offered at the time of absorption?
A. The absorption of officers will be based on the terms and conditions as notified
in the O.M. dated 24/03/2005, which PSUs cannot alter. Post absorption the
absorbees will be governed in MTNL/BSNL as per the policy of the respective PSUs
in which the officer is absorbed. As regard disinvestment of PSUs by more than
51%, the provisions available under sub-rule 25 and 26 of Rule 37A of CCS
(Pension) Rules, 1972 provide for necessary safe guards.
Q31. Please clarify whether deputation to TCIL shall continue to be there from
DoT/BSNL & MTNL pool.
A. As per DoT O.M. No.11013/2/2005-Admn.II dated 06/05/2005, deputation of
officers to TCIL would be allowed, only from BSNL and MTNL for two years from 30 th
September 2005. Fresh deputation of officials from DoT to TCIL would not be
allowed. This would, however, not affect fresh deputation of officials of Wireless
Planning and Coordination Wing of DoT to TCIL subject to such deputation being
need based and kept to be minimum.
Q32. All the IDA pay scale offered to various grades in Group ‘A’ are not at all
attractive, but instead a huge deterrent. As per the indications given, my pay will be
substantially lower than what I have drawn in the previous months and what I would
have drawn in CDA scale in the months to come. The hike of minimum Rs.2500/(that too with personal pay, which is temporary and is going to be adjusted and

<!-- page 11 -->

11

hence nullified in future increments) is assured only at the point of absorption.
Please clarify.
A.
The mapping of existing CDA to corresponding IDA pay scale in case of
absorption of Group A officers in BSNL/MTNL has been prescribed in the OM dated
24.3.2005. The fitment based on point-to-point method from existing CDA scale to
corresponding IDA scale shall be done after absorption of the Group A officers in
respective PSU. The difference/rise in the gross salary drawn may vary from person
to person depending on his grade/pay scale/increment stage etc. It is not necessary
that the hike, if any, in emoluments be similar for all categories of employees. The
govt. has given free choice to the Group A officers to exercise their option for
absorption in BSNL/MTNL which they may exercise. If the minimum benefit
(Pay+DA) on absorption in MTNL/BSNL on 1.10.2000 falls short of Rs.2500/-, it will
be enhanced to Rs. 2500/- and the difference will be treated as the personal pay of
the officer as on 1.10.2000. Thus the methodology of fitment from CDA pay scale to
IDA pay scale will be similar to that made applicable in case of absorption of GroupB officers in respective PSUs.
Q33. In BSNL board, directors are appointed after taking technical resignation from
present job and on the date of their technical resignation their pension, gratuity,
leave encashment etc. are being paid and they start getting BSNL salary and perks
in addition to monthly pension paid by the Government of India. Our option should
also be asked on similar terms and conditions.
A. The absorption of Group-A officers to BSNL/MTNL will be governed as per Rule
37-A of CCS (Pension) Rules, 1972. These rules do not provide for the option
mentioned above. Position on the Board cannot be equated with officers of the
organizations below the Board level.
Q34. On 01.10.2000 I was working in the SAG as DDG (Trg.) in DoT. Later on in
May 2001, I was promoted as Sr. DDG in HAG. It may kindly be clarified that if I opt
for BSNL/MTNL, I shall be given promotion in the equivalent scale from the date of
my promotion in DoT and I shall be paid arrears of pay and allowances consequent
to fixation of pay in the equivalent scale in BSNL/MTNL.
A. Any promotions after 01/10/2000 (Ad hoc/Regular) made by the Government
(Competent Authority) shall be carried forward in the respective PSUs, hence
consequential benefits, if any would also become available.
Q35. I retired on 30/11/2002 from DoT from the post of Sr. DDG (Vig) and I was
never allocated to BSNL. It may please be clarified whether I shall be paid arrears of
pay and allowances w.e.f 01/10/2000 consequent to fixation of pay if I opt for
BSNL/MTNL even though I never physically joined BSNL before my retirement from
DoT on 30/11/2002.
A. On fitment in IDA scale, all consequential benefits/losses due, if any, would
follow.

<!-- page 12 -->

12

Q36. It is mentioned that DoT will consider the option given by Group ‘A’ officers
along with the availability of posts in MTNL/BSNL and the personnel requirement of
these organization and make the final allocation of officers to MTNL/BSNL/DOT and
the decision of DoT in this regard shall be final and binding on the officer. In the
case of retired officer it may be confirmed that the option exercised by the retired
officer shall be agreed to.
A. Yes, the answer is in affirmative.
Q37. As I have already retired and option is now being called from me, it implies that
all benefits relating to House Rent/Leave Encashment/pension refixation/commutation of pension etc. will have retrospective effect i.e. differential, if
any, between due and drawn will be payable to me in case I opt for MTNL/BSNL
w.e.f 01/10/2000. This may kindly be confirmed.
A. Cases of such nature will be decided as per the extant rules and regulations.
Q38. Since the absorption is proposed w.e.f 01-10-2000, please clarify whether
bonus for the financial year 2004-2005 shall be paid to me on absorption to
MTNL/BSNL?
A. The decision on these issues would be taken by the respective PSUs in respect of
the officers who take absorption in MTNL/BSNL.
Q39. It needs to be clarified that:
a)
Whether pension from Govt. (in case of BSNL) means ‘Consolidated
fund of India’?
b)
Whether pension shall be at the end of service? Some officers have 30
years to retire. If the pension is to be paid at the end of service as
usual, what is the safe-guard/assurance that rules/terms/conditions
shall not be revised for next 30 years?
c)
What is the assurance/guarantee that MTNL shall honour the decision
of DoT regarding absorption based on specified terms and conditions?
What are safe-guard /assurance that the same are not revised
subsequently by MTNL management to my disadvantage? For
example, Govt. specified that Officers shall continue to enjoy
pay/allowances/perks/benefit of Govt. during deemed deputation to
MTNL, but MTNL Board have subsequently decided to disallow joint
secretary level officers to fly J-class on international routes.
Answer.
a-c) It is reiterated that the payment of pension shall be governed by the Rule 37A of the CCS (Pension) Rules, 1972 which have been notified w.e.f. 30/09/2000.
The absorption of officers will be based on the terms and conditions as notified in
the O.M. dated 24/03/2005, which PSUs cannot alter. Post absorption the
absorbees will be governed in MTNL/BSNL as per the policy of the respective
PSUs in which the officer is absorbed.

<!-- page 13 -->

13

Q40. It is mentioned that the officers opting for BSNL would be entitled to pension
from the Government. Does this imply the following?
a)
b)
c)
d)
e)

That the service rendered in BSNL after absorption till superannuation
will be counted for fixation/payment of pension.
That the pension fixation formula will be same as adopted by the
Central Government.
That the pension will be paid in the equivalent IDA pay scale along with
IDA and that there is no maximum limit for pension.
Whether family pension will be given as in the case of government
pensioners.
Whether 40% of the pension will be commutable and whether full
pension will be restored after the prescribed period.

Answer.
a) Yes
b-e) It is clarified that the pensionary benefits would be governed by the Rule 37A of the CCS (Pension) Rules, 1972 and also as per the extant rules and
regulations as applicable.
Q41. A very important issue long pending with DOT for resolution is that of granting
of Batch parity of TFS cadre with ITS cadre. In this regard I would like to add that:
a) Fifth Central Pay Commission has already recommended granting of batch
parity of TFS officers with ITS officers.
b) DOT is yet to take any decision on the recommendation of Fifth Pay
Commissions despite assurances given to the Standing Committee on
Communications (12th Lok Sabha).
A. a-b) As of today, there is no batch parity between TFS and ITS.
Q.42. I was promoted as Adviser in DoT in October, 2000 and again promoted to the
post of Member in February, 2001. I retired on 31.10.2001. Please clarify.
As the absorption is effective from 1st October, 2000, how two promotions
which I got after this date will treated?
At the time of retirement I was an Ex-Officio Secretary to the Govt. of India. I
would like to know if such persons could also opt.
A. (i) On absorption, any ad hoc/regular promotion made by the Government after
01.10.2000 up to the highest level of post available in the cadre of respective Group
A services shall be carried forward in MTNL/BSNL. Fitment in the highest available
IDA scale of Rs.25,000-650-30,200/- shall accordingly be allowed.
ii)
Member, Telecom Commission is an Ex-Cadre Post. An officer of Group A
services, eligible for opting for absorption in MTNL/BSNL as per O.M dated
24.03.2005, having been appointed as Member, Telecom Commission after
01.10.2000 can be absorbed in MTNL/BSNL upto the period he was working against
the cadre post.
Q.43. I retired as Member on 31.10.2002 at basic salary of Rs.26,000/- fixed. In the
general terms and conditions there is no mention of IDA scale against CDA pay of
Rs.26000/- fixed. Kindly clarify.

<!-- page 14 -->

14

A.
Member, Telecom Commission is an Ex-Cadre post and hence is not covered
under the scheme for absorption of Group A officers in MTNL/BSNL. An officer of
Group A service, eligible for opting for absorption in MTNL/BSNL as per O.M dated
24.03.2005, having been appointed as Member, Telecom Commission after
01.10.2000 can be absorbed in MTNL/BSNL upto the period he was working against
the cadre post. Fitment in the corresponding IDA scale shall be accordingly allowed.
Subsequently his appointment/tenure in the cadre of Member, Telecom Commission
shall be treated as per the extant rules of the Government and no fitment in the IDA
scale would be involved. Pensionary benefits on retirement from the post of Member,
Telecom Commission shall be as per the Government rules.
Q.44 I was working in BSNL on 01.10.2000 in CGM Scale. I was promoted to
Adviser scale and joined as Adviser (HRD) on 23.06.2003. I retired on 06.01.2004. I
want to give option to BSNL. The Adviser posts are cadre posts of ITS Group A. In
the option letter there is no mention of Adviser scale and corresponding IDA scale in
MTNL/BSNL. If I opt in BSNL, as on 01.10.2000 what pay and allowance will be fixed
corresponding to Adviser scale at the time when I retired on 06.01.2004? Kindly
clarify this so that I can exercise the option.
A.
The highest notified IDA scale available in MTNL/BSNL is Rs.25,000-65030,200
Q45. In P&T BWS Civil Engineering stream, some of the Group B officers holding
senior position in the seniority list (finalised on 12.04.2004 after protracted court
cases) got absorbed in MTNL/BSNL. Their junior Group A officers have now been
regularised and promoted to JAG level in 12/2004. Seniority of such absorbed Group
B officers after absorption of Group A and their further promotion in PSU w.r.t. their
junior is to be clarified.
A.
The inter-se seniority between officers of Group B stream promoted to Group
A and Group A officers recruited directly shall be the same as was prevailing in DoT
as on 01.10.2000 (effective date of absorption) subject to any alteration in the
seniority made by DoT after 01.10.2000 till the Presidential Order for absorption is
issued. Any ad hoc/local officiating arrangements made by DoT after 01.10.2000
shall be carried forward by PSUs.
Q46. Non-optees occupying MTNL/BSNL Pool quarters as on date should also be
allowed to retain the same for two years.
A.
It is clarified that there can be no reciprocity for non-optees as a policy, PSUs
have their own policies/agreement in this regard which may be followed.
Q47. As per the extant rules the offer for absorption is to be given only to those
officers who have been transferred en-masse to a PSU/autonomous body formed or
constituted on account of conversion of a Government department. I have never
worked in DTS/DTO which got converted in to BSNL. Right since my appointment in
the Indian P&T Accounts and Finance Service on the basis of Civil Services
Examination, conducted by UPSC, I have been working under the Department of

<!-- page 15 -->

15

Telecom. As such, there was no reason for issuance of the above referred letter,
calling for option of absorption into MTNL/BSNL to me.
A.
It is clarified that the offer of absorption has been extended to all those
officers who were on the rolls of DTS/DTO/DOT as on 01.10.2000.
Q.48. Para 10 of the letter No.A-11013/1/2005-Admn.II (P&T AFS) dated
24.03.2005, inter alia states that officers not exercising any option as prescribed will
be deemed to have opted for Government service. It is submitted that I was
appointed by the Government of India vide an offer made for joining the Indian P&T
Accounts & Finance Service, an organised cadre, on the basis of Civil Services
Examination, conducted by UPSC, on certain terms and conditions which was
accepted by me. I do not understand as to how an existing government servant
could opt for the same government service again and also that how I can be deemed
to have opted again for government service when I am, by virtue of the mode and
formalities of appointment, member of an organised cadre of the Central Civil
Services, Group `A’.
A.
It is clarified that the offer of absorption has been extended to all those
officers who were on the rolls of DTS/DTO/DOT as on 01.10.2000.
Q.49. Para 12 of the notification dated 24.03.2005 inter alia states that “DoT will
consider the option exercised by Group A officers along with the availability of the
posts in MTNL/BSNL and the personnel requirement of these organisations and
make final allocation of officers to MTNL/BSNL or retention in DOT/DOP depending
on the organisational needs and public interest. The decision of DOT in this regard
shall be final and binding on the officers”. You would agree sir, that this para is
leading to a very incongruent conclusion that DoT can decide whether I will remain in
DoT/DOP or MTNL/BSNL depending on organisational need and public interest. As
this presumption would be ultra- vires, I presume that this is not the intention of this
para, and it is intended to mean that in case of PSU optees, if the number of options
received for MTNL/BSNL is more than the number of posts available in PSUs,
decision of DOT as to whether the officer will be given MTNL/BSNL/DOT/DOP, will
be final.
A.
It is clarified that allocation of officers for their absorption in MTNL/BSNL shall
be based on factors like (i) the option exercised (ii) working strength (iii) seniority and
(iv) incumbency in PSU.

(Jagdish Kumar)
Deputy Secretary to the Govt. of India
Tel.:011-23372590
To
1.
The Chairman-cum-Managing Director, Bharat Sanchar Nigam Limited,
Statesman House, Barakhamba Road, New Delhi-110001 with the request that the

<!-- page 16 -->

16

clarifications furnished above may be brought to the notice of all concerned officers
working with BSNL including their field formations.
2.
The Chairman-cum-Managing Director, Mahanagar Telephone Nigam
Limited, 12th Floor, Tower-1, Jeevan Bharati Building, 124-Cannaught Circus, New
Delhi-110001. with the request that the clarifications furnished above may be brought
to the notice of all concerned officers working with MTNL including their field
formations.
3.
The Secretary, Department of Posts, Dak Bhawan, Sansad Marg, New Delhi110001.
4.
Shri S.K. Gupta, DDG(SR), BSNL, 6th Floor, Statesman House, Barakhamba
Road, New Delhi-110001.
5.
DDG(FEB)/DDG(Estt)/DDG(Civil)/DDG(Elect) with the request that the
clarifications furnished above may be brought to the notice of all concerned officers.
6.
Controller of Communication Accounts, Department of Telecommunications
(As per standard List) with the request that the Government Counsels who have filed
Caveats and who are defending various Court/CAT cases may be apprised of the
contents of the above order.
7.
DDG(LR), Department of Telecommunications with the request that the
above-mentioned order may kindly be placed on the website of DoT.
Copy for information to:1.
2.
3.

Sr.PPS to Secretary, DOT/Sr.PPS to Additional Secretary(T), DoT
Member (Services)/Member (Finance)/Member(Production)
PS to JS (Admn), DoT

(Jagdish Kumar)
Deputy Secretary to the Govt. of India
Tel.:011-23372590/23036023
