---
doc_id: "35ce7fc2dadeaca8"
source_url: "https://www.dsir.gov.in/static/uploads/2025/10/dec2e509368f4872e595ff37953ad0b9.pdf"
ministry: "Department of Scientific and Industrial Research (DSIR)"
title: "Office Order No. H-12019/01/2005-Admn dated 5th September, 2005"
date: "2025-10-28"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "008ee1ea6729a6b7"
---

<!-- page 1 -->

No. H-12019/01/2005-Admn
Government of India
Ministry of Science and Technology
Department of Scientific and Industrial Research
Technology Bhawan, New Mehrauli Road, New Dethi-110016
New Delhi, the 5" September, 2005
OFFICE ORDER
Subject: Right to_Information Act, 2005 -- Effective Operationalization of mandatory to_Information Act, 2005 -- Effective Operationalization of _mandato:
provisions of the Act.

In exercise of the powers vested in the Right to Information Act 2005, the
Competent Authority in the Department of Scientific and Industrial Research hereby
designates the following officers of the Department to perform the functions as
mentioned against their name, in addition to their normal duties, towards effective
operationalization of the mandatory provisions of the Act.

No. Name & Designation Assignment for the purpose of the Act.
1: Shri Sudhir Kumar Nodal Officer

Joint Secretary-Admn
2. Dr AS Rao Appellate Authority

Scientist ‘G’

3. Shri Vimal Kumar Varun Central Public Information Officer

Scientist ‘E’

4. Dr Prabhat Kumar Dutta, Central Assistant Public Information Officer

Scientist 'D’

5; Dr (Ms) Sujata Chaklonobis Central Assistant Public Information Officer

Scientist ‘D' 4

No
(Srinibas PradNan)
Under Secretary to the Government of India
Phone. 2659 0510 Fax. 2696 0629

<!-- page 2 -->

To

1. Officers concerned

2: PS to Minister of State (S&T and DoD)

3. Sr PPS to Secretary, DSIR / PPS to JS (Admn), DSIR
4. PS to JS & FA, DSIR/ DS (F), DSIR

5 PS to CoA, DSIR

6. PA to Director (Admn), DSIR

is All Officers/ Sections in DSIR

8. MD (NRDC)/ MD (CEL) / DG (CDC)

9 Hindi Section for Hindi version
