---
doc_id: "335deea67fcbda77"
source_url: "https://msme.gov.in/static/uploads/2025/07/c50f3cc4103a3b2e95b5d718d1167436.pdf"
ministry: "Micro, Small & Medium Enterprises (MSME)"
title: "Operational guidelines of NER and Sikkim scheme"
date: "2022-05-26"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "74b3ceb7d2c404e1"
---

<!-- page 1 -->

Guidelines for Central Sector Scheme "Promotion of MSMEs in N.E. Region and Sikkim"

1.

Introduction:
The Ministry of MSME is working for development of MSMEs in the country. With a focus for
development of MSMEs in North Eastern Region & Sikkim a special scheme for'homotion of
MSMEs in North Eastern Region and Sikkim'was approved on 02.08.2016. The scheme was made

a component of new Central Sector Scheme 'Technology and Enterprise Resource Centre3'
formulated on 16.01.2018. The operational guidelines ofthe scheme component were revised and
issued on 15.01.2019. Impact of COVID-19 pandemic on MSME-Sector and various initiatives of

Gort. of India such as'Atma Nirbhar Bharat Abhiyarf,'Vocal for local to Global and'kro effect to

Zero defect' and Act East Policy to boost indigenous manufacturing and service sectors
necessitated revision of the scheme guidelines. Various consultations with MSME-DIs, State

Implementing Agencies and State Governments have suggested bringing simplification in the
scheme guidelines so as to reduce layers of various processes and reduce the time required for

approval of the projects and which can help in better execution. It has also necessitated a greater
involvement of State govemments in project identification, execution and monitoring its impact to
the local industry especially micro enterprises.

2.

Revised Guidelines of the Scheme:
These revised guidelines of Scheme'?romotion

of MSMEs in North Eastem Region and Sikkini'

are issued in supersession of the previous guidelines and encompasses, inter-alia, the procedures

and funding pattems. The guideline would be effective in prospective manner from the date of
issuance. The past liabilities will be addressed as per the previous guidelines of the scheme.

Ministry of MSME may amend guidelines on need basis.

3,

Scheme Components:

The Scheme 'Promotion of MSMEs in North Eastern Region and Sikkim' approved by Govt. of
India has the following components: -

3,01 Setting up of new and modernization of existing Mini Technology Centres:
Objective: The Scheme envisages financial assistance to State Govemments for setting up new and

modemization of existing Tool Room/ Mini Technology Centres. Projects for creation of
common facilities to supplement manufacturing, testing, packaging, R&D, product and process

innovations and training for natural resources such as fruits, spices, agri, forestry, sericulture and

Page 1

Auideline* Promotion ofMSMESin NE Region ond Sikkim

W,T

"rV

<!-- page 2 -->

bamboo etc. available in NER and Sikkim would be given priority. The Geo

tagging ofthe project

is mandatory.

limited to Rs'
Financial Assistance: The maximum assistance from Govemment of India will be
any excess amount to be
13.50 crore or 90% of the project cost, whichever is less, balance and
cost for up-gradation of
contributed by State Government. The Gol assistance towards the building
Gol assistance'
infrastructure would be limited to Rs. L00 crore within the total permissible
the cost ofland'
Govemment of India financial assistance would not be admissible towards

3.02 Devetopment of new and existing Industrial Estates:
of new and
objective: Government of India financial assistance will be provided for development
facilities will include
existing Industrial Estates, Flatted Factory complexes. The infrastructure
control facilities, roads,
power distribution system, water, telecommunication, drainage & pollution
storage and marketing outlets etc' Geo tagging ofthe project is mandatory'

will be limited to Rs'
Financial Assistance: The maximum assistance from Government of India
for development of Existing
13.5 crore for development of New lndustrial Estate or Rs. 9.00 crore
lndustrial Estate or 90% ofthe project cost, whichever, is less balance and

any excess amount to be

contributed bY State Government.

3.03 Development of Tourism Sector:
projects for creation
objective: Looking into immense scope of tourism sector in NER and Sikkim,
and cold storage,
of common services such as kitchen, bakery, laundry & dry cleaning, refrigeration

in a
IT infra, potable water, display centre for local products, centre for cultural activities etc.
projects with local MSEs.
cluster of home stays may be considered. There has to be linkages of
Projects of State Tourism Development Agencies or central/State Autonomous

bodies for Tourism

Development shall be allowed.
The following will be the mandatory requirements-

a. Geo tagging ofthe Project ;
b. The validation of DPR by Ministry of Tourism;
c. Nos. of minimum beneficiaries- l0 MSEs (in tourism services);
d. Beneficiaries should essentially be linked to any renowned e-commerce platform.

Guideline$ Prcmotion oJ MSME' in NE Region ond Sikkim

Page 2

<!-- page 3 -->

to Rs 4'50 crore or
Financial Assistance: The assistance from Government of lndia will be limited
g0% ofthe project cost whichever, is less balance and any excess amount to be contributed by state
Govemment.

4,

Procedure for Processing Proposals and Release ofFunds:

4.01 Mini TechnologY Centre
AsregardsToolRoom/MiniTechnologyCentre,themethodologyofsanctionwillbeasfollows:
would formulate
Govemment, desirous of availing financial assistance under the scheme

4.01.1 The State

aproposalandidentifyanagencypreferablyDepartmentoflndustries&CommerceoranyState

Govt.organizationengagedinpromotionofMSMEstoimplementtheproject'Incase,any
assistanceisneededatthisstage,theymayapproachofficeofDevelopmentCommissioner
(MSME), New Delhi or its field offices viz' MSME-DIs'
(DPR) covering aspects like the
4.01.2 The State Government will prepare a Detailed Project Report
demand analysis of sector
status and potential of the enterprises of the region, proposed location,
capital cost

to be served, objective of the project, services to be offered, organizational structure,
total
(Building, plant & machinery including other infrastructure facilities), operating expenses,

Agency, cash flow
estimated cost of Mini Technology Centre, funding pattem, Implementing
projection on outcome of the
analysis indicating techno-economic viability of the project and
the project and
project on increase in percentage of revenue of MSMEs receiving assistance under

numberofemploymentopportunitiesgenerated.MSME.DIsmayhelpStateGovemmentin

preparationofDPR.TheStatecovemmentwillconstituteaCommitteetospecifyplant&
machinerY required for a Project.

4.01.3 While forwarding the proposal (in the prescribed format in Annexure-lA)
Govemment of India, the State Govemment would confirm that:

along with DPR to

(i)Thebalancecostoverandabovethepermissiblegrantandtherecurringcostwillbeborne

bytheStatecovernment.TheprojectescalationcostifanyshallbebomebytheState
Govt.

(ii) Proposal should be forwarded through concemed MSME-DI including the comments of
stakeholders on the DPR.

of proposal, Office of DC (MSME) will examine the proposal online and the
of
discrepancy, if any, would be communicated to State Govemment within 20 days of receipt

4.01 .4 On receipt

proposal. Thereafter, Office of DC (MSME) would prepare a Note for obtaining the approval of
the'Project Approval and Monitoring Committee'.

Cuidelines; Promotion oI MSMES in NE Region ond Sikkim

Page 3

<!-- page 4 -->

4.01.5 .project Approval and Monitoring Committee'(PAMC) comprising

of following would consider

and approve the ProPosal:
Chairperson

I

Secretary (MSME)

2.

Additional Secretary &Deve,lopment Commissioner (MSME)

Member
Member

9

AS&FA or his/her representative
Representati ve of M/o DoNER
ve of M/o Food
of M/o Rural
ve of M/o Tourism
ve of M/o Textiles
ve of DPIIT

l0

Representative of concerned State

ll
13

edditional Development Commissioner (scheme)
Director ( SFURTI), Director (Cluster Development) and
Director (Tool Room/TCSP/TCEC) MoMSME
Director/FloO concerned MSME-DI

14.

JDC/Director (scheme)

J
4.
5

6.
7
8.

12.

Member
Member
Member
Member
Member
Member
Member

Industries

Member
Member
Member
Member-SecretarY

4.0l.6PAMC,whileconsideringandapprovingtheproposalmay:
the approval of Chairman
Co-opt any eminent person / expert in the Committee with
(PAMC)

4.01.7 After pAMC approves the proposal, formal approval of the Project

will be conveyed to the State

Governments.

a.) central assistance will be released to the State Project Implementing Agency'
released to implementing agency in three installments

approval, depending upon the implementation plan,

Funds will be

in the ratio of 50:40:10 after final

progress made, requirements of funds

the State Govt' in
of
and recommendation of a committee under the chairmanship

etc. Funds will be released only after upfront contribution by
proportionate contribution

of representatives from

Director/HoO MSME-DI of concemed State comprising
engaged in promotion of
Directorate of Industries or any other State Govt. organisation
MSMEs and one from Implementing Agency'
in Public Sector Banks &
b.) The funds will be released to the Project specific Bank Account
Regional Rural Banks of Implementing Agency'

c.) Implementing Agencies have to submit Utilization certificates
l2c (as per annexure-ll) for Gol grants before the release of

(UCs) timely in form GFR-

next installment and final UC

within 6 months of completion of projects'
Guidelinest Promotion of l4SMEs in NE Region

and Sikkim

Page 4

<!-- page 5 -->

d.) The procurement of Plant and Machinery will be done through e-tendering (either through
GeM or Central Public Procurement Portal) as per GFR and cvc guidelines by a
committee constituted by the State Go\.t. Diroctor/HoO MSME-DI and representative from

implementingagencywillbememberofthecommittee.othermembersmaybedecidedby
the State Covt.
4.01 .8 Time Period for completion of the project:

The projects have to be completed within 36 months from the date ofapproval order.

4.01.9 State Government shall keep a provision for including a nominee of central Govemment
Goveming Body of the Mini Technology Centre'

on the

4,02 Development of Industrial Estate
As regards development of Industrial Estate and Flatted Factory complex, the methodology

of

sanction will be as follows:
4.02.1 The state Govemment, desirous of availing financial assistance under

the schemg would formulate

aproposalandidenti!anagency,preferablyDepartmentoflndustries&Commerceoran
organization engaged in promotion of enterprises to implement the project' ln

case, any assistance

isneededatthisstage,theymayapproachoffrceofDevelopmentCommissioner(MSME),New
Delhi.

facilities like
4.02.2 The proposal may include financial assistance towards creation of Infrastructure
Services like
roads; water supply; water harvesting; drainage; power, ETPs and Administrative

oflice building, telecommunication/cyber centre/documentation centre, conference
Aid centre, creche,
Hall/Exhibition centre, Raw material storage facility, Marketing outlets/First
of the project on
Canteen facilities etc. The DPR should also include projections on outcome
increase in percentage ofRevenue of MSMEs receiving assistance

under the project and number of

employment opportunities generated'

4.02.3 While forwarding the proposal (in the prescribed format in AnnexureJB)
Government of India, the State Govemment would confirm that:

along with DPR to

(i) Suitable land of requisite size is available'
(ii)Thebalancecostoverandabovethepermissiblegrantarrdtherecurringcostwillbebome

bytheStateGovernment.TheprojectescalationcostifanyshallbebomebytheState
Govt'

Guidelines t Promotion ol MSMEi in NE Regiott ond Sikkirn

Page 5

<!-- page 6 -->

(iii) Proposal should be forwarded through concemed MSME-DI including

the comments of

stakeholders on the DPR.

4.02.4Onreceiptofproposal,OfficeofDC(MSME)willexaminetheproposalonlineandthe
discrepancy,ifany,thesamewouldbecommunicatedtostateGovemmentwithin20daysof
receiptofproposal.Thereafter,officeofDC(MSME)wouldprepareaNoteforobtainingthe
(PAMC) as detailed in Para
approval of the 'Project Approval and Monitoring Committee'
4.01 .5&6 above.

4.02.5AfterPAMCapprovestheproposal,formalapprovaloftheprojectwillbeconveyedtotheState
Govemments. The financial assistance shall be

released as per following procedure;

a.) central assistance will be released to the state Project Implementing

Agency. Funds will be

releasedtoimplementingagencyinthreeinstallmentsintheratioof50:40:10afterfinal
of funds
implementation plan' progress made' requirements
approval, depending upon the

etc.FundswillbereleasedonlyafterupfrontcontributionbythestateGovt.in
proportionate contribution and recommendation of

a committee under the chairmanship of

of representatives from

Director/HoO MSME-DI of concemed State comprising
organization engaged in promotion of
Directorate of Industries or any other State Govt'
MSMEs and one from Implementing Agency'

b.) The funds will be released to the Project specific Bank
Regional Rural Banks of lA'

Account in Public Sector Banks &

c.)ImplementingAgencieshavetosubmitUtilizationCertificates(UCs)timelyinformGFR.
of next installment and final UC
l2 C (as per annexure-ll) for GoI grants before the release
within 6 months of completion of projects'

d')TheprocurementofPlantandMachinerywillbedonethroughe.tendering(eitherthrough

GeMorCentralPublicProcurementPortal)asperGFRandCVCguidelinesbya
committee constituted by the state Govt- Director/HoO
implementing agency will be member of the committee'

MSME-DI and representative from
Other members may be decided by

the State Govt.

4.02.6 Time Period for completion of the

project:

The projects have to be completed within

30 months from the date of approval order'

Page 6
Guideline* Profiotion oJ MSMES in NE Region

ond Sikkim

<!-- page 7 -->

4.03 Development of Tourism Sector:
AsregardsDevelopmentofTourismSector,themethodologyofsanctionwillbeasfollows:
4.03.lTheStateGovemment,desirousofavailingfinancialassistanceundertheschemewouldformulate
Agencies or
a proposal and identifu an agency preferably State Tourism Development
Central/StateAutonomousbodiesforTourismDevelopment/TourismDevelopmentCorporationor

anyStateGovt.organizationengagedinpromotionofTourismsector.lncase,anyassistanceis
neededatthisstage,theymayapproachofficeofDevelopmentCommissioner(MSME)'New
Delhi.

4'03'2ThestateGovemmentwillprepareaDetailedProjectReport(DPR)coveringaspectslikethe
statusandpotentialofthetourismoftheregion,proposedlocation,demandanalysisofsectortobe

served,objectiveoftheproject,servicestobeoffered,organizationalstructure,capitalcost
(Building,plant&machineryincludingotherinfrastructurefacilities),opgratingexpenses,total
Agency' cash flow analysis indicating
estimated cost of project, funding pafiem' Implementing
techno-economicviabilityoftheproject'TheDPRshouldalsoincludeprojectionsonoutcomeof
theprojectonincreaseinpercentageofRevenueofMSMEsreceivingassistanceundertheproject
andnumberofemploymentopportunitiesgenerated'TheMSME-DIsmayhelpStateGovemment

inpreparationofDPR'TheStateGovemmentwillconstituteaCommitteetospecifyplant&
machinery required for a Project'

4.03.3Whileforwardingtheproposal(intheprescribedformatinAnnexureJC)alongwithDPRto
Govemment of India, the State Govemment

would confirm that:

(i)Thebalancecostoverandabovethepermissiblegrantandtherecurringcostwillbebome
bythestateGovemment.TheprojectescalationcostifanyshallbebornebytheState
Govt'

(ii) Proposal should be forwarded through concerned MSME-DI
stakeholders on the DPR'

4.03.4 On receipt of proposal, Office of

including the comments of

DC (MSME) will examine the proposal online and

the

discrepancy,ifany,thesamewouldbecommunicatedtostateGovemmentwithin20daysof
receiptofproposal'TheDPRshallbeforwardedtol!,I/oTourismfortheirvetting.Aftervettingof
DPRbyIWoTourism,offrceofDC(MSME)wouldprepareaNoteforobtainingtheapprovalof
the 'Project Approval and Monitoring Committee'

as detailed in Para 4'01'5&6 above'

Page 7
Guidelines. Promotion oi MsMEs in

N E Region and Sikkim

<!-- page 8 -->

4.03.5AfterPAMCapprovestheproposal,formalapprovaloftheProjectwillbeconveyedtotheState
Governments'

a.)CentralassistancewillbereleasedtothestateProjectlmplementingAgency.Fundswillbe
of 50:40:10 after final
released to implementing agency in three installments in the ratio
approval, depending upon the implementation plan, progress made'

requirements of funds

etc.FundswillbereleasedonlyafterupfrontcontributionbytheStateGovt.in
chairmanship of
proportionate contribution and recommendation of a committee under the
representatives from
concemed State comprising
MSME-DI

of

Director/HoO

of

Directorate of Industries or any other State Covt. organisation engaged

in promotion of

MSMEs and one from Implementing Agency'

b')ThefundswillbereleasedtotheProjectspecificBankAccountinPubticSectorBanks&
Regional Rural Banks of IA'
c.)lmplementingAgencieshavetosubmitUtilizationCertificates(UCs)timelyinformGFR,l2C(asperannexure-ll)forGolgrantsbeforethereleaseofnextinstallmentandfinalUC
within 6 months of completion of projects'

d.)TheprocurementofPlantandMachinerywillbedonethroughe.tendering(eitherthrough
guidelines by a
GeM or Central public Procurement Portal) as per GFR and CVC
committeeconstitutedbytheStateGovLDirector/HooMSME.DIandrepresentativefrom

implementingagencywillbememberofthecommittee.othermembersmaydecidedby
the State Govt.

4.03.6 Time Period for completion of the project:
The projects have to be completed within I 8 months from the

date of approval order'

4.03.TStateGovernmentshallkeepaprovisionforincludinganomineeofCentralGovernmentonthe
Goveming BodY ofthe Project.
5

0ther administrative exPenses
Upto5%oftotalapprovedbudgetmaybeutilizedtomeetexpenditureundertheBudgetHead
operating ofthe scheme'
impact studies etc. and other administrative expenses for
for

Guldellnes't Prornotion oJ MSMES in NE Reqion

and Sikkim

age 8

<!-- page 9 -->

6.

Time extension for Project

project' However, in special
State governments shall ensure time bound completion of the
on recommendation of the Chief
circumstances time extension may be given by the Ministry
Secretary of the respective State as per the following:

I. Six months from the stipulated date of completion of the project-AS &DC(MSME)
II. Six to twelve months from the stipulated date of completion of the projectSecretarY(MSIlG)

III. More than one year from the stipulated date of completion of the

project- Minister of

MSME/Minister In-charge for MSME'
*!f*****tt!k

Guidelinest Promotion of MSMEs in NE Region

and Sikkim

Page 9

<!-- page 10 -->

ANNEXURE-IA

FORMATToAPPLYFORCENTRALASSISTANCEFORMINITECHNOLoGYCENTREIN
NER / SIKKIM
To
The AS&DC (MSME),

Ministry of MSME,
O/o DC (MSME),
7th Floor, Nirman Bhavan
Maulana Azad Road
NEW DELHI I lO I08

Eastern Region and sikkim' for
Financial Assistance to States/State Agencies in North
Tool Rooms
setting up / up-gradation of Mini Technology centres/lVlini

Subject:
Sir,

Based on the Detailed Project Report prepared by

IWs

State Government of

Technology Centre at
approved a proposal to set up / upgrade a Mini
the estimated cost of
with central assistance under the above mentioned scheme at
have

Rs.

crore as per details given below:

Items

S.No.
1

Land

2

Buildings (----sq.m)

J

Machinery/EquiPment

4

Other Capital ExPenses

5

Pre-operative expenses

6

Contingencies

Rs. (in crore)

Total:

2.

The project will be implemented by

and the funding Pattern will be:-

(Rs. in crore)
(a)

Grant from Govt. of India

(b)

Share of State Government

(including cost of land)
10
Guidelines; Promotion of MSMEs in NE Region

and Sikkim

<!-- page 11 -->

(c)
3

Others (to be sPecified)

NecessaryprovisionofRs.--crorehasbeenmadeinthestateGovemment,sBudgetforthe
Govemment's
for the purpose, and any escalation would be met out of State
year
budget.

4

you are requested to sanction the Central assistance under the scheme' A copy of the Detailed
Project Report is enclosed for perusal'

Yours faithfullY

Secretary/ Director of lndustries /
Competent authority

Guidelinest Promotion ol MSMEi in NE Region

and Sikkim

11

<!-- page 12 -->

ANNEXURE-IB
OF INDUSTRIAL
FORMAT TO APPLY FOR CENTRAL ASSISTANCE FOR DEVELOPMENT
ESTATE IN NER / SIKKIM

To
The AS&DC (MSME),

Ministry of MSME,
O/o DC (MSME),
7ft Floor, Nirman Bhavan,
Maulana Azad Road,
NEW DELHI I IO IO8

Sikkim' for
Financial Assistance to States/State Agencies in North Eastern Region and
Development of Industrial Estate/ Flatted Factory complexes

Subject:
Sir,

State Government of

Based on the Detailed Project Report prepared by IWs
have approved a proposal for development of Industrial Estate

central assistance under the above mentioned scheme at the estimated

with

at

cost of Rs.

crore as per

details given below:
S.No.
1

Land
(i)

Rs.
Indicative ltems
t and Other Overhead Infrastructu re
Cost of land fill ng I leve lng includ ing boundary
fencing /Cost o f construction for Flatted
wal

crore

Fr

lll

Cost of
Road side

(iv)

Water supply including overhead tanks, and PumP

I

roads

& social

houses

2.

v

Water

(vii)

Power ( Sub-Station and distribution network
including street light etc), Generation of non-

vlll

conventional
Conveniences etc.
Others
Sub Total (1):

Administrative and ot her Services
Adm lnl strati ve Office
I
ber Centre/ Documentation
Telecommunication /
I

Guidelinest Promotion of MSMEs in NE Region ond Sikkim

Page 12

<!-- page 13 -->

Centre
Conference Hall / Exhibition Centre

(iii)

outlets
facil
Raw material
Canteen facilities
First aid
Sub Total
Effluent Treatment Facilities

lv

vl

&
Grand Total (1+ 2)

2.

and the funding Pattern will be:-

The Project will be imPlemented

(Rs. in crore)

J

(a)

Grant from Govt. of India

(b)

Share of State Government
(including cost of land)

(c)

Others (to be sPecified)

Necessary provision of
year

Rs.--

crore has been made in the State Government's Budget

for the

for the purpose, and any escalation would be met out of State Government,s

budget.
4.

You are requested to sanction the central assistance under

the scheme' A copy of the Detailed

Project Report is enclosed for perusal

Yours faithfully
Secretary/ Director of lndustries /
ComPetent authoritY

Guidelinesr Promotion ol MSMEs in NE Region and

Sikkim

Page 13

<!-- page 14 -->

AI\NEXURE-I C
FORMAT TO APPLY FOR CENTRAL ASSISTANCE FOR DEVELOPMENT
SECTOR IN NER / SIKKIM

OF TOURISM

To
The AS&DC (MSME),
Ministry of MSME,
O/o DC (MSME),
7ft Floor, Nirman Bhavan
Maulana Azad Road
NEW DELHI I IO 108

Financial Assistance to States/State Agencies in North Eastern
setting up of Centre for tourism development'

Subject:

Region and Sikkim' for

Sir,

State Government of

Based on the Detailed Project Report prepared by IWs
have approved a proposal to set up a Centre for tourism

with central assistance under the above mentioned scheme at the estimated

development at

cost of

Rs.

Rs.

crore

crore as per

details given below:

Items

S.No.

2.

I

Land

2

Buildings (----sq.m)

J

Machinery/EquiPment

4

Other Capital ExPenses

5

Pre-operative expenses

6

Contingencies

Total
The Project will be implemented

and the funding Pattern will be:-

(Rs. in crore)

(a)

Grant from Govt. of India

(b)

Share of State Government

(including cost of land)

(c)

Others (to be sPecified)

Guidelinest Promotion of MSMEs in NE Region and

Sikkim

Page 14

<!-- page 15 -->

)

NecessaryprovisionofRs.--crorehasbeenmadeintheStateGovemment,sBudgetforthe
for the purpose, and any escalation would be met out of State Government's
year
budget.

4

YouarerequestedtosanctiontheCentralassistanceunderthescheme.AcopyoftheDetailed
Project Report is enclosed for perusal'

Yours faithfullY

Secretary/ Director of lndustries /
ComPetent authoritY

Cuideline* Promotion olMSMES in NE Region and Sikkim

Page 15

<!-- page 16 -->

ANNEXURE-II
FORMS

GFR I2_C
[(See Rule 239)]

Form of Utilization Certificate

o.

Sl.No.

Amount

date

Total

2.

Certified that I have satisfied myself that the conditions on which the grants-in-aid was sanctioned

have been duly fulfilled I are being fulfilled and that I have exercised the following checks to see that the
money was actually utilized for the purpose for which it was sanctioned.

Kinds of checks exercised
1.

2

Signature...
Designation

Date.........
Note: The above utilization certificate should be counter signed by the Administrative Secretary of the
Division regulating the Scheme/Finance Secretary.
pS: The UC shall disclose separately the actual expenditure incurred and loans and advances given to
suppliers of stores and assets, to construction agencies and like in accordance with scheme guidelines
and in furtherance to the scheme objectives, which do not constitute expenditure at the stage. These
shall be treated as utilized grants but allowed to be carried forward.

Guidelinest Promotion of MSMEs in NE Region and Sikkim

v
