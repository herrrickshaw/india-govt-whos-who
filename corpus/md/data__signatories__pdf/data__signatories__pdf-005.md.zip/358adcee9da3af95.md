---
doc_id: "358adcee9da3af95"
source_url: "https://mohua.gov.in/static/uploads/2025/11/2f5a88d442c1698cbebf90a731d5c63e.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of 3,12,60,000/- as 1st installment of Central Assistance to the State Government of Uttarakhand for 13 BLC (New) projects approved in 49th CSMC meeting held on 27.11.2019 under Pradhan Mantri Awas Yojana (Urban) [PMAY (U)] Mission for the f"
date: "2021-02-26"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "98b642080d4b7d94"
---

<!-- page 1 -->

. PAO(Sectt.)/UD/Admin/Advice/2020-21//Fos> 6g 59१ 3
GOVERNMENT OF INDIA
है PAO(Sectt.), M/o Housing & Urban Affairs
507-C(wing), Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664

To,

The General Manager,

Reserve Bank of India, 707

Central Accounts Section, 66६6 si

Additional Office Building, Advice Date:|26/02/2021

East High Court Road,

NAGPUR - 440 001

Sir,

Please debit our account with Rs.3,12,60,000/- (Three Crore Twelve Lakh Sixty Thousand Only.)
by contra credit to the following accounts of the Governments with the amounts mentioned against each:
Month and Year of Accounts: February,2021 The Amount to be Settled: February,2021
[sine Name of the | State Scheme Code [Amount] Sanction No. and Date
State Code
1 UTTARAKHAND | 126 1989-STATE AND UT GRANTS | 3,12,60,000 | N-11011/97/2019-HFA-I-UD
{ UNDER PMAY (URBAN) (FTS 9079220) dated
26/02/2021
Signature of the authorized official
(Pawan Kumar Bhatnagar)
Sr.Accounts Officer
1. O/o Accountant General (Audit & Accounts), Uttarkhand, Oberoi Motors Building, Sharanpur Road, Majra,
Dehradun - 248171.
\2-Sh Jagdish Prasad, US (HFA-I), M/o HUA, Nirman Bhawan, New Delhi.
Rew mar Bhatnagar)
Sr. Accounts Officer
0 fpo-HFn
Y
(2) Mon. (Shoe OND 2) ५
ट PF
is HEA
w

<!-- page 2 -->

Ges 393
: (tess
eater we
. N-41011/97/2019-HFA-I-UD (FTS: 9079220)
. Government of India
. Ministry of Housing and Urban Affairs
HFA Mission Directorate
(HFAG Division)
Nirman Bhawan, New Delhi.
Dated:22 February, 2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs,
Nirman Bhawan, New Delhi -14
Sub: Release of %3,12,60,000/- as 1* installment of Central Assistance to the State
Government of Uttarakhand for 13 BLC (New) projects approved in 49% CSMC
meeting held on 27.11.2019 under Pradhan Mantri Awas Yojana (Urban)
[PMAY (U)] Mission for the financial year 2020-21 — reg.
Sir,
| am directed to convey the Sanction of the President of India to release of
%3,12,60,000/- (Rupees Three Crore Twelve Lakh and Sixty Thousand only) to the
State Government of Uttarakhand as 1* installment of Central Assistance for 13
BLC (New) projects approved in 49" CSMC meeting held on 27.11.2019 held under
Pradhan Mantri Awas Yojana (PMAY)- Housing for All (Urban) Mission (for
beneficiaries under SC Category) under Allocation for the FY 2020-21. Details of the
projects/release are as under:
(ता
lakh}
g
of Amount of | — instalmentof | beneficiaries _| installment to be
Projects | Central Central Assistance | (SC) entered in | released for
approved | Assistance released for MIS as on beneficiaries
by CSMC | sanctioned beneficiaries 10.02.2021 under 56
under SC Category
Category
on | eee
# Project-wise details are annexed.
3. Based on decision of CSMC meeting under Pradhan Mantri Awas Yojana (PMAY) -
Housing for All (HFA) (Urban) Mission and on the recommendations made by MoHUA,
the amount of central grant is being released subject to following conditions alongwith
observations of CSMC:

i. Necessary sanctions/ approvals/ compliances required under the statutory or
other regulatory regime as applicable would be obtained by the authority(ies)
concemed with the project(s).

ii. The State Government and implementing agency shall put in place a monitoring
system to ensure that the project(s) achieve scheduled milestone and envisaged
outcomes including implementation of reforms and other conditionalities required
under the scheme.

३
Contd 97

<!-- page 3 -->

-2- .

iii, Utilize the grant in accordance with the approved guidelines for the implementation of .

. the Scheme of Pradhan Mantri Awas Yojana (PMAY) - Housing for All (HFA) (Urban)
Mission.

iv. The expenditure on the implementation of the scheme/projects will be shared
between the Centre and the State/ULB/Implementing Agency(IA) as committed. The
committed State share should also be released within 15 days from the date of
receipt of Central Assistance in the SLNA account. In case of shortfall of
State/ULB/IA share, corresponding amount of Central share will be deducted from
the subsequent instalment(s).

v. Furnish the Utilization certificates of the Grant released in the prescribed format as
per GFR — 2017 as provided in the scheme guidelines.

vi. The funds may be utilized for the purpose and within selected categorised
beneficiary for which these are given. Otherwise these will have to be refunded along
with interest as per provisions for GFR-2017.

vii. The State must ensure geo-tagging of photographs to monitor progress of the house
construction before release of each instalment to beneficiaries.

viii. The agencies responsible for implementation of PMAY(U) should get themselves
tegistered on PFMS portal.

ix. The State Goverment should validate the demand assessment data and remove the
ineligible beneficiaries in order to make the housing requirement realistic.

x. State fo ensure that adequate infrastructure is ensured including individual water,
sanitation and electric connection.

xi. State Government to ensure that there is no duplication / change in the identified
beneficiaries.

xii. Transfer of funds to different entities may be made through PFMS, as applicable; and
where there is an element of cash transfers to individual beneficiaries, the same may
be made through PFMS/DBT mode, as applicable.

xiii. The State Government shall submit the Action Taken Report(ATR) on the
observations/ recommendations of Third Party Quality Monitoring Agency selected
by State for quality monitoring purpose before release of subsequent instalment.

xiv. State Goverment should ensure that there is no violation of Model Code of Conduct
while releasing funds to Implementing Agencies/ULBs/Beneficiaries.

4. Payment may kindly be made to the State Government immediately. The funds

may thereafter be released to the implementing agencies without any delay failing which

the amounts would be recovered from the State Government with interest for the period
of default.
a
Contd...3/

<!-- page 4 -->

———_— eee
7 -3-
. 5. The expenditure involved amount will be debited from the account of the Central
. Goverment in the books under the following Head of Account under Demand No. 57
Ministry of Housing and Urban Affairs for the year 2021-21:
|___3601__| Grants-in-aid to State Govemments
Sub-MajorHead | 06 ~_—_| Cenirally Sponsored Schemes
| 101 |
Sub Head [| __31___| Pradhan Mantri Awas Yojana (Urban
Detailed Head | _ 01 _| Assistance to State Govermments for PMAY(U'
| 31.01.35 __| Grants for Creation of Capital Assets
6. As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(sVOrganization(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Auditor General of India under the provision of CAG
(DPC) Act 1971 and intemal audit by the Principal Accounts Office of the Ministry or
Department, whenever the Institution or Organization is called upon to do so.
7. The amount will be credited to the State Government's account in RBI as per
procedure laid down by Ministry of Finance, Department of Expenditure in this regard.
8. This issues with the concurrence of the Finance Division vide their
Note#22 dated 15.02.2021.
9. This sanction has been registered at S.No. 292 _ 4 in the Sanction Register of
HFA Mission Directorate (HFA.III Section) of the Ministry of HUA for the year. 2020-21.
10. This being the first instalment of the grant under PMAY-HFA (U) Mission for these
projects, no UC is. pending from the State Government of Uttarakhand.
Yours faithfully,
(७००८१
(Jagdish Prasad)
Under Secretary to the Govemment of India
Tele No. 011-2306 3029
Copy to:-
1. Secretary (Urban Development), Government of Uttarakhand.
2. Director, UD & SUDA, Directorate of Urban Development, Goverment of
Uttarakhand.
3. Accountant General (A&E), Uttarakhand.
4. NITI Aayog, SP Divn. / DR Divn. New Delhi
5. (४०0 CGA, Mahalekha Niyantrak Bhawan, New Delhi.
6. CGM, RBI, CAS, Nagpur
7. CCA, MoHUA
8. Budget Division Mfo HUA
9.. Director/Deputy Secretary, IFD, M/o HUA
10. Director (HFA-3), MoHUA.
11. PMU (MIS), HFA Directorate
12. Dy. Chief MIS, HFA Directorate to place this sanction at appropriate place on the
Website of the Ministry.
13. Sanction folder
Poet
(Jagdish Prasad)
: Under Secretary to the Goverment of India

<!-- page 5 -->

7) 1, गा तह] ह है 1 व इज इ इह :

5 न का कि 3

8 S| si ee gq aay 34) as] es | ड़ a

z | 33 Hi “ B

8 zg 3 हू

2 $ < =

PT Te ddd 11]

ed HT

2] & daddddaaye

ils Lb con

| ig 1° है

a

i 3 ge a gy न s

3 & gg a 8] a S|

3 a i

Bal 2 Ba

a8 2 z g 3 Rg 3

tg gl 3

डर 2

a2 8

j gg 8 gg \

z| 2

2] 3

EEE LEEEEEE

TA

e| 2

4 हु है ॥ ॥ 8 8 8 8 8 ॥ ॥ है है है

कि 25 हि हि

ii lala dlalalaigigiatalal tig

< 2 & | sl & हू

' HU
. $ Fs हर & a 4 S| हे! s|

; | 4 | ॥ १

£4 ,

a] Te faded dad sa
