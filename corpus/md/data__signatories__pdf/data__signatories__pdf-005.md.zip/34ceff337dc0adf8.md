---
doc_id: "34ceff337dc0adf8"
source_url: "https://dohe-education.gov.in/static/uploads/2025/12/835997da4748f12bb6129e8cf05de734.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Vacancy Circular for filling up the post of Chairman, CBSE"
date: "2015-12-31"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "56ee79999de297db"
---

<!-- page 1 -->

F.No.1-66/2014-Sch-3
Government of India
Ministry of Human Resource Development
(Department of School Education & Literacy)
School 3-Division
eK
VACANCY CIRCULAR
The Department of School Education & Literacy, Ministry of Human Resource
Development invites application for appointment to the post of Chairman, Central Board of
Secondary Education (CBSE), New Delhi. CBSE is an autonomous organization of the
Department and the post of Chairman carries a pay scale of Rs.37400-67000/- with grade pay
of Rs. 10000/-. The Board currently has over 15,500 schools, both in India and abroad, affiliated
to it. It conducts public examination at class X and XII stage. The Board also conducts
JEE(Mains), AIPMT, NET, CTET and JNV Admission Test.
2. The day to day affairs of the Board are managed by its Chairman. The Secretary to the
Government of India, Ministry of Human Resource Development, Department of School
Education & Literacy is the Controlling Authority of the Board.
3. Method of recruitment: The post is to be filled up by transfer on deputation (including
short term contract).
4, Eligibility: Officers of the Central/State Govts., Semi-Govt./autonomous organizations
are eligible to apply subject to the following:
i) Holding analogous post on regular basis,
or
With 3 years of regular service in the post carrying the scale of pay of Rs. 37400-
67000/- with grade pay of Rs. 8700/- ,
and
(ii) _ Possessing the following experience:
(a) Essential:
3 Years in Educational Administration at a senior level (of grade of
Director to Government of India or above).
(b) Desirable :
5 years in ‘Education’ or ‘Educational Administration’ or both
5. Age: Not more than 56 years as on the closing date of the receipt of application.
6. The appointment shall be made initially for a term of 5 years or till the date of
superannuation, whichever is earlier. /
1
>

<!-- page 2 -->

7. Considering the nature of duties and responsibility assigned to the post, the applicant
should have adequate management skills to run the organization at New Delhi and its current ten
regional offices. CBSE is a growing organization and hence the eligible officer should be ready
to take up new challenges and ensure smooth functioning of the Board, and should have adequate
interest and experience to encourage innovations in the conduct of public examinations, and
curriculum development, etc.
8. The applications, in duplicate as per the prescribed format given below may be submitted
through proper channel, enclosing the following:-

i) Integrity Certificate,

ii) Vigilance Clearance, and

iii) | ACR/APAR dossiers of last 5 years ie upto 2014-15
9. This vacancy circular and format for application can also be downloaded from the
website of the Ministry ic. www.mhrd.gov.in , of CBSE i.e. www.cbse.nic.in and also of
Department of Personnel & Training (DOP&T) i.e. www.persmin.nic.in .
10. The application with al! relevant paper/ documents/ duly recommended by the
Cadre Controlling Authority should reach Shri D K Bhawsar, Dy. Education Advisor,
Department of School Education and Literacy, Room No. 225, ‘C’ Wing, Shastri Bhawan,
Dr. Rajendra Prasad Road, New Delhi-110001 within four weeks of the initial publication
of this notice in news papers.

RAKE
2

<!-- page 3 -->

FORMAT
Application for the post of Chairman in Central Board of Secondary Education (CBSE), an
autonomous organization under the Ministry of Human Resource Development, Department of
School Education and Literacy
=
Affix passport size
photograph
1 | Name and Address
(in Block letters):
2 | Date of Birth
(in Christian era):
3 | Date of retirement
under Central/State
Govt. Rules, as
applicable:
Educational Examination University/ | Year | Subjects/ age of
Qualifications: Passed Board Area Marks/Grade
a
es a
I
| (_ ऋ [| /'
5 | Publication, if any, in
the relevant field, give
brief details.
Details of employment | Office/ Post Held | From j To Scale of Pay | Nature of
in chronological order} Institution and Basic Duties
(use extra sheet if Pay (in detail)
7 Tae
3

<!-- page 4 -->

7 |Nature of the post With effect from

_ “ PF झह
8 | State whether present

employment is held

on deputation/contract

basis along with date

from which the same

is held.

Additional details ee Central Government

employment

employment.

a Semi Government/
Autonomous educational
organization

10 | Professional training

(give details)
11 | Work experience

other than what has

been prescribed in the

Vacancy Circular.
12 | Additional

information, if any.

Date:

Place:

(Signature of the Applicant)
4
