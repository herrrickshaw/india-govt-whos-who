---
doc_id: "32f1ca68e1ba7dec"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/b8d4ced212dfc248752e0e11594bc2b6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Vacancy circular for the posts of Junior Engineer (Telecom) Group ‘B’ Non-Gazzetted posts in MH LSA, Pune and Goa units on deputation basis"
date: "2026-08-04"
pages: 39
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "66d727265c304a85"
---

<!-- page 1 -->

भारत सरकार

Government of India
Ministry of Communications

संचार मंत्रालय

Department of Telecommunications

दरू संचार विभाग

O/o Special Director General (Telecom),

कायाचलय - विशेष महाननदे शक (दरू संचार),

Maharashtra Licensed service Area, Pune

महाराष्ट्र लाइसेन्स सेिा क्षेत्र, पण
ु े

DOT/PUNE/ADMIN-73/Deputation

Date: 04.08.2026

VACANCY CIRCULAR
Subject: Vacancy circular for the posts of Junior Engineer (Telecom) Group ‘B’ Non-Gazzetted posts in
MH LSA, Pune and Goa units on deputation basis – regarding
It is proposed to fill up the posts of Junior Engineer (Telecom) Group ‘B’ Non Gazzetted posts on deputation
basis from among the staff working in Central or State Governments or Union Territories or Public Sector
Undertakings or Universities or Recognized Research Institutions or Statutory and Autonomous Bodies as
per the details given below.
Name of the Post

Scale of Pay
Commission)

(as

per

7th

Pay No. of vacant posts No. of vacant
at Pune
posts at Goa

Junior
Engineer Level 6 of the pay matrix
(Rs. 35,400-1,12,400)
(Telecom)

1

1

2. Eligibility criteria and Job Profile are enclosed at Annexure-A and application form is enclosed at

Annexure-B.
3. Period of deputation: The period of deputation shall be for an initial period of 3 years which may be

further extended on administrative grounds or till regular incumbent joins whichever is earlier. The
deputation can be terminated at any time prior to completion of deputation tenure as per requirement.
4. Regulation of pay and other terms of deputation: The pay and terms and conditions for deputation of

the officials selected shall be regulated as per DoT OM no. 20-01/2023-SEA.II dated 31.10.2023 and its
corrigendum dated 01.11.2023 (Annexure-C), as the case may be, or any other instructions as amended
from time to time.
5. Age limit: The maximum age-limit for appointments on deputation (including short term contract) shall not

exceed 56 years as on the closing date of receipt of applications.
6. Selection Procedure:
a. The selection procedure will be as decided by the Competent authority. The Head of MH LSA reserves the

right to accept or reject in part or in full any or all the responses without assigning reasons whatsoever.
b. Eligible and willing candidates may apply through proper channel in prescribed format: Annexure-D.

सीटीओ कंपाउं ड, जीपीओ के पीछे , चचच रोड, कैं प, पुणे – 411001, महाराष्ट्र
फोन: 020-26134242, ईमेल: advisor.mh-dgt-dot@gov.in

<!-- page 2 -->

भारत सरकार

संचार मंत्रालय

दरू संचार विभाग

कायाचलय - विशेष महाननदे शक (दरू संचार),
महाराष्ट्र लाइसेन्स सेिा क्षेत्र, पण
ु े

Government of India
Ministry of Communications
Department of Telecommunications
O/o Special Director General (Telecom),
Maharashtra Licensed service Area, Pune

7. Cadre Authorities/Head of Departments are requested to forward applications of eligible and willing

candidates whose services can be spared on deputation immediately on their selection. The applications of
only such officials would be considered that are routed through proper channel and are accompanied by the
following documents:
i)
ii)
iii)
iv)
v)
vi)

Application in prescribed proforma-Annexure-B.
Statement giving details of Major/Minor penalties, imposed upon the Officer, if any during the
last ten (10) years.
Vigilance Clearance/Integrity Certificate.
Photocopies of the ACRs/APARs for the last five (5) years duly attested on each page by an officer
not below the level of Under Secretary or equivalent.
Declaration in prescribed proforma. (Annexure-D)
Certificate recorded by Head of Department while forwarding the application (Annexure-E).

The applications of suitable and eligible officers complete in all respects, in the prescribed format, along with
documents listed above may be forwarded to the below address or send email to ada.mh-dgt-dot@gov.in &
jtoa2.mh-dgt-dot@gov.in.
O/o. Special Director General Telecom,
Maharashtra LSA, DoT, CTO Compound,
Church Road, Camp,
Pune-411001
8. The last date for receipt of application is 8 weeks from the date of publication of this circular.
9. Before forwarding the applications, Competent authority of the lending organization must certify that

information furnished by the applicants is verified with their service record and found correct and should also
countersign the application with the office seal.
Applications received after the last date or not forwarded through a proper channel or without prescribed
documents or otherwise found incomplete would be summarily rejected.

10.

For any clarification /query in this regard applicants may contact the Admin. section of the MH LSA on
email: ada.mh-dgt-dot@gov.in.

11.

12.

The selection will be done as per the norms and extant rules on the subject.
Digitally signed by

The decision of Head of MH LSA shall be final and binding.

NITIN NITIN PANCHAL
2026.08.04
PANCHALDate:
10:45:42+05'30'
ADG (Admin.)
O/o Special. DGT,
MH LSA, Pune.

सीटीओ कंपाउं ड, जीपीओ के पीछे , चचच रोड, कैं प, पुणे – 411001, महाराष्ट्र
फोन: 020-26134242, ईमेल: advisor.mh-dgt-dot@gov.in

<!-- page 3 -->

भारत सरकार

संचार मंत्रालय

दरू संचार विभाग

कायाचलय - विशेष महाननदे शक (दरू संचार),
महाराष्ट्र लाइसेन्स सेिा क्षेत्र, पण
ु े

Government of India
Ministry of Communications
Department of Telecommunications
O/o Special Director General (Telecom),
Maharashtra Licensed service Area, Pune

To

1.
2.
3.

All Ministries/ Departments of the GoI request that the vacancy notification may be given wide
publicity in the attached and subordinate offices under them.
All the State Governments and Union Territories with a request that the vacancy notification may be
given wide publicity in their various departments/ offices.
All Public Sector Undertakings/ Recognized Research Institutions/ Statutory and Autonomous
bodies/ Universities.

Copy to for information please:
1)
DDG (Establishment), DoT HQ, New Delhi.
2)
DDG (Admin.), DGT HQ, New Delhi.
3)
Director (IT), DoT HQ, New Delhi with a request to publish the notification DoT Website under
‘Vacancies’.

सीटीओ कंपाउं ड, जीपीओ के पीछे , चचच रोड, कैं प, पुणे – 411001, महाराष्ट्र
फोन: 020-26134242, ईमेल: advisor.mh-dgt-dot@gov.in

<!-- page 4 -->

Annexure-A:
Eligibility criteria:
Junior Engineer (Telecom):
Officers of the Central Government or State Government or Union territories or autonomous bodies or statutory
organisations or public sector undertakings or Universities or recognised research institutions.
a.

Holding analogous posts on regular basis in the parent cadre or department; or with six years’ service rendered
after appointment to the post on a regular basis in level-5 in the pay matrix (Rs.29200-92300) or equivalent in
the parent cadre or department; and

b.

possessing the qualifications and experience prescribed as below.
i. Bachelor’s degree in engineering or technology in Electrical or Electronics or Electrical
Communications or Electronics Communications or Computer Science or Telecommunications or
Information Technology or Instrumentation from a recognized University or Institute.
ii. The candidates, having passed Sections A and B of the Institution Examinations of the Institution of
Engineers (India) or passed Graduate Membership Examination of the Institution of Electronics and
Telecommunication Engineers (India) or passed Associate Membership Examination Parts II and III
or Sections A and B of the Aeronautical Society of India, who were enrolled with these institutions
up to the 31st May, 2013, shall also be eligible.
iii. Service required in the post from which deputation is to be made Officials of the Central Government/
State Government/ Union Territories/ Autonomous Bodies/ Statutory Organization, Public Sector
Undertakings (PSUs)/ University or Recognized Research Institutions.

Note:
1. The period of deputation including the period of deputation in another ex-cadre post held immediately
preceding this appointment in the same or some other organization/department of the Central Government
shall ordinarily not exceed three years.
2. The maximum age-limit for appointments on deputation (including short term contract) shall not be exceeding
56 years as on the closing date of receipt of applications.
Job Profile:
Nature duties for Junior Engineer (Telecom): Duties may be assigned in any of the works being carried out any of the Vertical in MH LSA, DOT:
a. Service Compliance – CAF audit, EMR audit, Service Testing, Roll out obligation, etc.
b. Technology – Secured dedicated telecom network, Time synchronization of Telecom network, Disaster

Technology management, Interconnect Exchanges, Inspection of licensed network, Advocacy & public
awareness, PMWANI, etc.
c. Security – Operation & maintenance of CMS/ IMS, curbing illegal activities, control over clandestine/
illegal operation of telecom networks, Analysis of CDR / SDR and other security activity assigned
from time to time.
d. Rural – Rural connectivity for DBT, verification of USO sites, RF coverage testing, Telecom
connectivity checking, coverage in tribal hamlets, SLBC, etc.
e. Admin – Legal, PG & Vigilance – Admin, DDO works, Personnel grievances, Building, Court cases,
Misc. Admin activities.

<!-- page 5 -->

Annexure-B
APPLICATION FOR DEPUTATION FOR THE POST OF Junior Engineer (Telecom) in
O/o Special. DGT, DoT MH LSA, Pune -411001/ in O/o Spl DGT, MH LSA, Pune.

Personal Details
1. Name of the official (in block
letters)

:

2. Date of Birth/ Age

:

3. Gender (M/F/others)

:

4. Present Address

:

5. Aadhar Number & Mobile
Number & Mail Id
6. Education Qualification
Name of
Examination University/
Board Institute

Subjects taken

Official Details
7. Post held at present with name
of the Dept./Ministry
8. Whether employee of Central
Govt./ State
Govt./PSU/UTs/Autonomous
Body

:
:

9. Present Pay Scale C Pay Drawn

:

10. Post Applied for

:

11. Preference location of Posting
12. Working experience including
extent of working with
computers

:

Year of
Passing

Division

Percentage

<!-- page 6 -->

13. Date from which present post
is held

:

14. Brief service particulars
(enclose a separate sheet if
space is insufficient)

:

15. Nature of appointment i.e.
whether
Adhoc/Deputation/Regular or
else
16. Nature of duties performed
(enclose a separate sheet if
space is insufficient)

:

:

17. Whether belongs to SC/ST/OBC :
18. Whether served in the Dept. of
Telecommunications on
Deputation basis. If so, the
period of deputation and name
of Circle/Station where served

:

19. Remarks, if there are any

:

Signature

<!-- page 7 -->

Misc./2023-E&C

Annexure - C

I/3135927/2023

No. 20-01/2023-SEA II
Government of India
Ministry of communication
Department of Telecommunications.
521, Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
Dated:

October 2023

OFFICE MEMORANDUM

Sub: The terms & conditions for engagement of Group "B" (Gazetted & NonGazetted)/Group "C" staff
on
deputation
in
Department of
Telecommunications.
The undersigned is directed to refer to this office OM No. 34-8/2001-SEA
(Vol.II) dated 24.11.2017 and No. 20-02/2014-SEAII dated 22.12.2017 and
enclose herewith a copy of the revised terms & conditions for engagement of
Group "B" (Gazetted & Non-Gazetted)/Group "C" staff on deputation in
Department of Telecommunications.
This is issued with the approval of Secretary (T).
Encl: As above.

Harshvardhan Singh Khangarot
Director (SEA)
011-23036059
To,
1. CGCA / DG(T)
2. All Heads of CCA offices / LSA field units.
3. DG, NICF
4. CMD, BSNL
Copy To,
1. PSO to Secretary (T)
2. PSO to Member (Finance/Technology/Services)

<!-- page 8 -->

Misc./2023-E&C
I/3135927/2023

Department of Telecommunications
(SEA-II Section)
Terms & Conditions for engagement of Group "B" (Non-Gazetted/ Gazetted) /
Group “C” staff on deputation in DOT and its field offices.
The terms & conditions governing the deputation of Group “B” (Gazetted &
Non-Gazetted) / Group C sta in Department of Telecommunication shall be as
under: Sl. No.

Parameter

1

Period of Deputation

2

Pay

3

Dearness Allowance

Terms and Conditions
The period of deputation shall be as per
the provisions of the RRs of the post or 5
years in case no tenure regulations exist
for the post.
The pay of the employee shall be fixed in
accordance with DoPT instructions issued
on the subject and amendments issued from
time to time.
DA as applicable to Central Government
employees.

4

HRA / Transport Allowance

HRA/ Transport Allowance shall be paid at
the rate admissible under the rules of the
DoT, which are similar to that admissible
under the rules of the Central Government.

5

Children Education Allowance

As per rules notified
Government.

Joining Time Period and Pay

The DoT will pay to the officer his joining time
pay for both ways. The joining time will be
regulated under the Central Government
Rules.

Transfer Travelling Allowance

The expenditure on transfer/ travelling
allowance for joining duty in borrowing
organization and repatriation from borrowing
organization shall be borne by DoT as per
the rules notified by the Central Government
from time to time.

6

7

8

9

by the Central

Admissibility
of
Travelling
The admissibility of travelling allowance on
Allowances during journeys
tour during the period of deputation shall
performed on tour for official
be as per the rules notified by the Central
purpose during the deputation
Government from time to time.
period
The employee will be governed by the
Leave Rules as followed in the parent
department during the deputation period in
Leave
and
Leave
Salary DoT. DoT will pay the Leave Salary
Contribution
Contribution at the rates notified and
communicated by parent office to the extent
of rule contained in Appendix-IV of FR&SR
Part-I.

<!-- page 9 -->

Misc./2023-E&C
I/3135927/2023

10

Provident Fund

11

Pension Contribution

12

Gratuity

13

Insurance Scheme

14

Leave Salary

15

Leave Travel Concession

16

Medical Facilities

17

Residential Accommodation

Monthly EPF Contribution at the rate
applicable from time to time on the basic pay
drawn actually and IDA/CDA as the case
may be, deducted from the salary of the
officer plus matching contribution along with
applicable administrative charge on that
amount is to be remitted to the parent office
within the due date. This will enable to earn
pension and PF accumulation of the officer.
DoT will also be liable to bear the interest
and penalties imposed by the EPF
authorities for the delay on the part of DoT
for remitting the contribution to parent office
The rate applicable is to be communicated
by the parent office to DoT.
Pension contribution in respect of
absorbed employees is normally payable to
GoI by BSNL on account of pension liability
under rule 37 A of CCS (Pension) rules,
1972. Pension contribution in respect of
BSNL employees on deputation to DoT shall
be exempted from payment to GoI during the
period of deputation of the employee in Govt.
A remark to this e ect will be recorded in
the service record of the official during the
period of deputation.
DoT is also liable to pay proportionate
amount to the parent office on demand if any,
on account of Gratuity, for the deputation
period.
During the period of deputation, the officer
will continue to be governed by the insurance
scheme applicable in the parent office. The
DoT will ensure to remit the deductions
towards insurance scheme to the parent
office.
The DoT will pay leave Salary in respect of
disability leave granted on account of
disability, if any, incurred in and through
the period of deputation.
The officer will be governed by the LTC
Rules of the Central Government and cost
thereof will be borne by DoT.
The officer on deputation will be entitled to
medical facilities as per the policy of the
borrowing organization and CGHS card
issued to the officer will be surrendered at
the time of repatriation.
The
officer
will
be
entitled
for
accommodation as per DoT officials and
standard license fee will be regulated

<!-- page 10 -->

<!-- page 11 -->

Misc./2023-E&C
I/3136270/2023

No. 20-01/2023-SEA II
Government of India
Ministry of communication
Department of Telecommunications.
521, Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
Dated:

November 2023

CORRIGENDUM
Reference is invited to this office O.M. of even no. dated 31.10.2023 regarding
the terms & conditions for engagement of Group "B" (Gazetted & Non- Gazetted)
/Group "C" staﬀ on deputation in Department of Telecommunications. Under para 19
of the terms & conditions pertaining to the Superannuation Pension Scheme: "Employer contribution towards Superannuation Pension Scheme at the rate of
5% of Basic pay plus IDA may be borne by DoT with eﬀect from date of start of
deputation in DoT or date of effect of SPS (ie. 05/05/2016), whichever is later"
may be read as follows:
"Employer contribution towards BSNL Superannuation Pension Scheme at the
rate of 5% of Basic pay plus IDA may be borne by DoT with eﬀect from the date of
start of deputation in DoT or the date of issuance of this O.M., whichever is later."
2.

All other contents of the O.M. dated 31.10.2023 shall remain unchanged.

(Harshvardhan Singh Khangarot)
Director (SEA)
011-23036059

To,
1. CGCA / DG(T)
2. All Heads of CCA offices / LSA field units.
3. DG, NICF
4. CMD, BSNL
Copy To,
1. PSO to Secretary (T)
2. PSO to Member (Finance/Technology/Services)

<!-- page 12 -->

Annexure-D

Declaration
I.

I

hereby declare that my posting as Junior Engineer (Telecom) in the

office of the Special Director General Telecom, MH LSA Pune / MH LSA, Goa
Department of Telecommunication, is purely on a temporary basis and shall not have
any right to claim seniority in the said post in respect of services rendered by me on a
Deputation Basis.
II.

I am not entitled to absorption as

in the Department of

Telecommunication and therefore will not resort to lay any claim for the same.
III.

I am liable to be repatriated to my parent department/organization for any inaccuracies in
the details noted above or contravention of any provision in the rules/orders governing
deputation.

Place: …………………
Date: ……/……/……….

Signature of the Official

Countersigned

Signature of the
Controlling Officer with seal

<!-- page 13 -->

Certificate to be recorded bv the Head of Department
Annexure - E

Certificate to be recorded by the Head of Department while forwarding the
application.
Certified that:
1. The particular given by the applicant are true and have been verified from the service record.
2. The applicant, if selected, will be relieved immediately.
3. Copies of ACR/APARs for the last Five years are enclosed.
4. No Disciplinary/Vigilance case is pending or contemplated against him/her. There is nothing against
the candidate which makes him ineligible for consideration of appointment to the post applied for.
5. No major/ minor penalty is in force or current against the official.
6. It is certified that the integrity of the official is beyond doubt.

Signature of the Head of Department
with official seal.

<!-- page 14 -->

No.DOPT-1726140763694
Government of India
Ministry of Personnel, Public Grievances & Pensions
Department of Personnel and Training
ESTT.(Pay-II)
******
Dated 28 March, 2024
OFFICE MEMORANDUM

Subject:- Consolidated guidelines on deputation/foreign service for central government employees
D/o Personnel & Training (DoPT) had vide OM No. AB-14017/2/07-Estt(RR) dated 29.02.2008 issued consolidated guidelines
governing appointments of the Central Government employees to the posts filled on deputation / foreign service.

2.
In so far as Central Government employees are concerned, foreign service has been defined
as service in which a Government servant received his pay with the sanction of Government from
any source other than the Consolidated Fund of India { FR 9(7)}.
3.
Instructions contained in the OM referred above cover cases involving appointments
under following categories:
[DOPT OM No. AB-14017/2/07-Estt(RR) dated 29.02.2008]

(a)

Central Staffing Scheme (CSS)

Central Staffing Scheme (CSS) provides a systematic arrangement for selection and appointment of officers to senior
administrative posts at Centre, excluding posts which are specifically encadred within the Organised Group 'A' Services or
filled by recruitment through the Union Public Service Commission. Instructions governing various aspects of the Central
Staffing Scheme issued from time to time have been consolidated and placed on the official website of DoPT. Matters relating
to appointment under Central Staffing Scheme and other related issues are handled in the Office of the Establishment Officer
(O/o the EO), DoPT.

[DoPT OM No.DOPT-1705650752584 dated 19.01.2024]

(b)

Non-Central Staffing Scheme (Non-CSS)
Appointments to following categories of posts are covered under Non-Central Staffing Scheme:

i.
Posts of Chief Vigilance Officer (CVOs). Guidelines/procedure for appointment of
CVOs in CPSEs and other organizations under Central Government and their service conditions
have

<!-- page 15 -->

been consolidated and placed on DoPT’s official website. Matters relating to appointment of CVOs
and other related issues are handled in O/o the EO, DoPT.[DoPT OM No.40/1/2022-EO(CVO)
dated 18.11.2022]
ii.
Posts in Statutory Bodies and Autonomous Institutions wholly or substantially
funded or controlled by the Central Government. Selection to fill these posts is made through
Search-cum-Selection Committee process as laid down in DoPT’s OM No. AB-14017/11/2004Estt(RR) dated 30.07.2007 OR as per the approved Recruitment Rules OR as per the statutory
provisions for institutions covered by specific statutes (with the approval of ACC for Chief
Executives of Joint Secretary or above level). Tenure of these appointments shall be as prescribed
under Central Staffing Scheme. Instructions on setting up Search Committees /Search-cumSelection Committees and related topics have been placed on DoPT’s official
website.[AB.14017/24/2022-Estt.(RR) dated 31.08.2022]
iii.
Posts in Central Public Sector Understakings. Subject to exemption from
Immediate Absorption Rule, appointment to the posts under this category is made through Public
Enterprises Selection Board (PESB)/ Search Committee (with the approval of ACC for Joint
Secretary and above level posts). Tenure of these appointments shall be as prescribed under
Central Staffing Scheme.
iv.
Further, in partial modification of the existing instructions governing
deputation/foreign service as also para 1.3 of this Department’s OM No.AB-14017/2/2007-Estt
(RR) dated 29.02.2008, instructions have been issued vide DoPT’s OM No.6/8/2023-Pers.Policy
(Deputation/Re-employment) Pt.XV 15.03.2024 regulating the appointment and other terms and
conditions of deputation of Group ‘A’ officers of the Central Government to ex-cadre posts under
a State Government/UT Administration including PSUs/ Autonomous bodies/Statutory
Bodies/ Universities/Local Bodies under the States/UT Administration.
[DoPT’s OM No.6/8/2023-Pers.Policy (Deputation/Re-employment) Pt.XV dated 15.03.2024]
v.
Posts in Constitutional Bodies or Staff Officers of Heads of Constitutional
Bodies. Selection and appointments to the posts under this category is made through Civil Services Board OR on request by
name, subject to vigilance clearance and suitability (with the approval of ACC for Joint Secretary and above level posts). Tenure
of these appointments shall be as prescribed under Central Staffing Scheme.
vi.
Posts in Statutory Bodies set up by an Act of Parliament or Staff Officers of
Heads of such Statutory Bodies. Selection to the posts below Joint Secretary level shall be made
by a Committee under the Chairmanship of Secretary(Personnel) with the approval of

MoS(PP). Appointment to Joint Secretary and above level posts shall be made through Civil Services Board and with the
approval of ACC.
Tenure of these appointments shall be as prescribed under Central Staffing
Scheme.

vii.
Posts in Non-permanent, Non-Statutory Bodies with a specific term set up
through executive orders/notification by the Central Government – like Administrative
Reforms Commissions, Pay Commission, National Manufacturing Competitiveness Commission,
Sachar Committee, Inquiry Commissions etc. Appointment to the posts under this category is
made through

Civil Services Board (with the approval of Appointments Committee of the Cabinet for Joint Secretary and above level posts).
Tenure of these appointments shall be as prescribed under Central Staffing Scheme. If an
officer moves from a Central Staffing Scheme post to Non-Central Staffing Scheme

<!-- page 16 -->

post, or vice versa, he/she shall be eligible for an additional tenure of two years, subject to at least two years on either post.

(c)

Deputation to International Organisations
Appointments to posts in the following organisations are covered under this category:

(i)

UN Organisations

(ii)

International Financial Institutions like World Bank, IMF, ADB etc.

(iii)
Multilateral organisations of which India is a member, like IAEA, WTO,
Commonwealth Organisation, International Court of Justice, SAARC etc.
(iv)
Bilateral Bodies set up under the Vienna Convention i.e. Embassies and Bodies set up
under them, like USAID, DFID, NORAD etc.
(v)
International NGOs or Funding Organisations from which India receives technical /
financial assistance like international Red Cross Society, Action Aid, Aga Khan Foundation, Ford
Foundation etc.
A Committee under the Chairmanship of Cabinet Secretary with Secretary(Personnel), Finance Secretary will screen all
proposals for deputation on foreign service terms of officers of the level of Joint Secretary and above, on a case to case basis,
after the proposals have been approved by the Cadre Controlling Authority. Such screening in the case of officers below the
level of Joint Secretary will be done by a Committee chaired by the Secretary of the Cadre Controlling Ministry/Department
with a member each, not below the level of Joint Secretary from the Department of Personnel & Training and Department of
Expenditure. A final decision on the recommendation of the Screening Committee may be taken at the level of Minister-incharge in the case of officers holding posts below Joint Secretary level and with the approval of the Prime Minister in the case
of officers holding Joint Secretary level posts or above.
For appointments to the posts listed at (iv) above, the Foreign Secretary or the MEA Secretary concerned shall also be a member
of the Committee under the chairmanship of Cabinet Secretary for officers of Joint Secretary and above level. For officers below
Joint Secretary level, a nominee of Foreign Secretary not below the level of Joint Secretary would be included in the Screening
Committee. Further, for appointments to the posts listed at (v) above, concurrence of Ministry of Home Affairs shall be taken.
Maximum tenure of appointments under this category shall be 5 years at a stretch.

(d)

Autonomous body, trust, society etc. not controlled by the Government or a private body
Appointments in the following bodies are covered under this category:

(i)
Registered Societies or Trusts or Foundations or non-profit organisations or NGOs
or cooperatives;
(ii)

Apex bodies of Industries and Commerce.

For appointments to the posts in such autonomous or private bodies, all the conditions of the following criteria need to be
fulfilled:

<!-- page 17 -->

a.

They are functionally autonomous of the Central and State Governments;

b.

They are not substantially funded by the Central and State Governments;

c.

Central or State Governments do not have powers to give them directions; and

d.

They are not companies registered under the Registration of Companies Act.

Procedure for appointment to the posts in these bodies shall be as detailed in para 3(c) above. Maximum tenure
of appointments under this category shall be 5 years at a stretch.

(e)

Ex-Cadre deputation

D/o Personnel & Training has from time to time issued instructions / guidelines regulating appointment, pay, Deputation (Duty)
Allowance, tenure of deputation/ foreign service and other terms and conditions of deputation/foreign service of the Central
Government employees to ex-cadre posts under the Central/State Governments/ Union Territories (UTs) Administration/
Public Sector Undertakings (PSUs)/ Autonomous Bodies/ Statutory Bodies/ Universities/ Local Bodies etc.

and vice-versa. APPLICATION
2. .

These provisions apply to all Central Government employees, who are regularly appointed
on deputation/foreign service in accordance with the provisions of the Recruitment Rules (RRs)
of the ex-cadre posts, under the same or some other Departments of Central Government or under
the State Governments/ UTs Administration/Local Bodies or under Central or State
PSUs/Autonomous Bodies/Statutory Bodies etc. set up or controlled by Central/State
Governments provided the foreign service under such PSUs/Autonomous Bodies/Statutory
Bodies has been permitted in relaxation of appointment on immediate absorption basis. They also
cover the cases of regular appointment on deputation/foreign service of employees of State
Government/Local Bodies etc. as well as PSUs/Autonomous Bodies/Statutory Bodies of
Central/State Governments as per RRs in the Central Government. In short, these instructions
cover cases of deputation/foreign service where Central Government is either lending authority
or borrowing authority or both.
2.1
However, in partial modification of the existing instructions governing
deputation/foreign service as also para 1.3 of this Department’s OM No.AB-14017/2/2007Estt (RR) dated 29.02.2008, appointment and terms and conditions of deputation of
Group ‘A’ officers of the
Central Government to ex-cadre posts under a State Government/UT Administration
including PSUs/ Autonomous bodies/Statutory Bodies/ Universities/Local Bodies under
the States/UT Administration, would be regulated as per the revised instructions issued in this
regard vide DoPT’s OM No. 6/8/2023-Pers.Policy (Deputation/Re-employment) Pt.XV dated
15.03.2024. The terms and conditions governing such appointments, which have not been
spelt out in the said OM shall be regulated by the instructions indicated herein.
[DoPT’s OM No. AB-14017/2/07-Estt.(RR) dated 29.02.2008; DoPT's OM No. 6/8/2009-Estt.(PayII) dated 17.06.2010; DoPT's OM No. 2/9/2018-Estt.(Pay-II) dated 12.4.2021 and DoPT’s OM No. OM No.6/8/2023Pers.Policy (Deputation/Re-employment) Pt.XV dated 15.03.2024]

<!-- page 18 -->

2.2.
However, the following cases are governed by separate set of instructions / guidelines, and they are not covered
by these provisions: -

(a)
Members of the All India Services and those deputed to posts, whose terms are
regulated under specific statutory rules or orders;
(b)
Officers appointed on deputation to posts under the Central Staffing Scheme (CSS)
for whom separate orders issued from time to time continue to apply;
(c)

Deputation to posts operated outside India;

(d)
Appointments of a specific category of employees to a specified class of posts, such as
appointments made in the Personal Staff of Ministers etc., in respect of which special orders are
already in existence. However, the terms and conditions contained herein will apply to those
cases to the extent they are not specifically covered under such special orders.
(e)
Appointments of the nature of deemed deputation or transfers to ex-cadre posts
made in exigencies of service with the specific condition that no Deputation (Duty) Allowance
will be admissible - e.g. (i) interim arrangements in the event of conversion of a Government
office/organization or a portion thereof into a PSU/ Autonomous Body or vice-versa; and (ii)
appointments to the same post in another cadre.

[ Para 2.1 and 2.2 of DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 17.06.2010]

SCOPE OF THE TERM 'DEPUTATION/FOREIGN SERVICE' RESTRICTIONS ON TREATING AN APPOINTMENT AS ON
DEPUTATION/ FOREIGN SERVICE.

3.1
The terms ‘Deputation’/ ‘Foreign Service’ will cover only those appointments that are
made by transfer on a temporary basis provided the transfer is outside the normal field of
deployment and is in public interest. The question whether the transfer is outside the normal field
of deployment or not will be decided by the authority which controls the service or post from which
the employee is transferred.
3.2
The following types of appointments will not be treated as deputation/foreign service
for the purposes of these orders:
(a)
Appointment of serving employees made either by promotion or by direct
recruitment from amongst open market candidates whether on permanent or temporary
basis;
(b)

Permanent appointment made by transfer/absorption;

(c)

Temporary appointment made based on personal requests of employees;

<!-- page 19 -->

(d)
Arrangements necessitated by staff imbalances arising on reorganization of offices on
the same or different stations, subject to the specific condition that no Deputation (Duty)
Allowance will be admissible in such cases.
3.3
A person in a higher Level (in Pay Matrix) shall not be appointed on deputation to a
post in lower Level (in Pay Matrix) if the deputation is from Central Government to Central
Government and also in cases where the scale of pay and Dearness Allowance (DA) in the parent
cadre post and ex-cadre post are similar.
[ Para 3.1-3.3 of DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 17.06.2010]

3.4
However, no appointment on deputation/foreign service shall be made from/to Central
Government/an organization where the scale of pay and DA pattern in the parent cadre post and
ex- cadre post are dissimilar, if the basic pay in the parent cadre increased by one increment plus
Dearness Allowance (s) including interim relief if any, admissible to a person in the parent cadre
post exceeds the basic pay plus Dearness Allowance(s) including interim relief, if any, at the
maximum of the pay Level in the Pay Matrix/pay scale of the ex-cadre post.

Note: In the revised pay structure under 7th CPC, the maximum of the scale would mean the last cell of any Level in the Pay
Matrix.

Illustration:
In case of an appointment on deputation basis, from an organization to an ex-cadre post in the Central Government in Level 7
in the Pay Matrix, where the pay scale and DA pattern of the parent cadre post and ex-cadre post in Central Government are
dissimilar, no appointment can be made to such post, if the basic pay in the parent cadre increased by one increment plus
Dearness Allowance (s) including Interim Relief, if any, admissible in the parent cadre post exceeds the basic pay at the
maximum of the Level 7 of the Pay Matrix i.e. Rs. 1,42,400/- plus Dearness Allowance (s), including Interim Relief, if any.

[DoPT's OM
12.04.2021]

No.

2/9/2018-Estt.(Pay-II)

dated

EXERCISE OF OPTION.

1.1
An employee appointed on deputation/foreign service, may elect to draw either the pay
in the Level (in the Pay Matrix)/Scale of pay of deputation/foreign service post or his/her basic
pay in the parent cadre plus Deputation (Duty) Allowance thereon plus Personal Pay, if any.
However, in case of appointment of Government employees on deputation/ foreign service to
CPSEs, this option will

<!-- page 20 -->

not be allowed, and in such cases their pay will be governed in terms of the orders issued by Department of Public Enterprises
vide OM dated 26.11.2008 and clarifications issued thereafter.

1.2
The borrowing authority shall obtain the option of the employee within one month
from the date of joining the ex-cadre post unless the employee has himself furnished the option.
1.3

The option once exercised shall be final.

1.4
However, the employee may revise the option under the following circumstances
which will be effective from the date of occurrence of the same:

a.
When he/she receives proforma promotion or is appointed to non-functional selection
grade or up-gradation of scale in the parent cadre;
b.

When he/she is reverted to a lower grade in the parent cadre;

c.
When the scale of pay/level (in the Pay Matrix) of the parent cadre post based on which
his emoluments are regulated during deputation/foreign service or of the ex-cadre post held by
the employee on deputation/foreign service is revised either prospectively or from a
retrospective date;
d.
Based on the revised/same option of the employee, in the event of proforma
promotion/appointment to non-functional selection grade/revision/upgradation of scales of
pay/level (in the Pay Matrix) in the parent cadre, his/her pay will be re-fixed with reference to
the revised entitlement of pay in the parent cadre. However, if the initial option was for the pay
scale of the deputation post and no change in option already exercised is envisaged, the pay
already drawn in deputation post will be protected if the pay re-fixed is less.

Note: Revision in the rates of DA, HRA or any other allowance either in the parent or borrowing organization shall not be an
occasion for revision of the earlier option.
4.5.
If the pay of an employee in his cadre post undergoes downward revision, the pay in the ex- cadre post is also liable
to be re-fixed based on revised pay and in accordance with the revised option or existing option if the employee does not revise
his option.

[Para 4 of
17.06.2010]

DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated

PAY FIXATION.

5.1
When an employee on deputation/foreign service elects to draw pay in the Level (in
Pay Matrix) attached to the ex-cadre post, his/her pay may be fixed as under:

<!-- page 21 -->

i)

Deputation from Central Government to Central Government:

If the Level (in Pay Matrix) of the ex-cadre post is higher than that of the parent cadre post, an increment shall be given in the
Level (in Pay Matrix) of parent cadre post and he/she shall be placed at a Cell equal to the figure so arrived at in the Level (in
Pay Matrix) of the excadre post; and if no such Cell is available in the Level (in Pay Matrix) of the ex-cadre post, he/she shall be
placed at the next higher cell in that Level. However, if the cell so arrived at after adding an increment is less than the minimum
of the cell in the Level (in Pay Matrix), the pay will be fixed at the minimum of the cell in the Level (in Pay Matrix).
In case Levels (in Pay matrix) of the ex-cadre post and the parent cadre post of the employee are identical, the employee would
continue to draw his/her basic pay.

(ii)

In case of Foreign Service/Reverse Foreign Service:

(a)
When the Level (in Pay Matrix)/Pay Scale of the post in the parent cadre and that
attached to ex-cadre post are based on the same index level and the DA pattern is also same, the
pay may be fixed as under (i) above.
(b)
If the appointment is made to a post whose pay structure and/or Dearness Allowance
(DA) pattern is dissimilar to that in the parent organization, pay may be fixed by adding one
increment to the basic pay of the substantive post in the parent cadre, (and if he/she was drawing
pay at the maximum of the scale, by the increment last drawn) and equating the pay so raised plus
dearness allowance (and additional or ad-hoc dearness allowance, interim relief etc., if any) with
emoluments comprising of basic pay plus DA, ADA, Interim Relief etc., if any, admissible, in the
borrowing organization and the pay may be fixed at the stage in the Pay Scale/ Level (in Pay
Matrix) of the ex- cadre post at which total emoluments admissible in the ex-cadre post as above
equal the emoluments drawn in the parent cadre and if there is no such stage, pay may be fixed at
the next higher stage.

Illustration:

A person drawing emoluments as Basic Pay - Rs. 34,000/- and Dearness Allowance - Rs.44,200/- (DA @ 130%) with increment
@ 3% per annum on the basic pay, is appointed in Central Govt. in the Level 11 of Pay Matrix (in 7
deputation basis, his pay will be fixed as under:-

th CPC) with DA @ 10% on

<!-- page 22 -->

a.

Adding one increment to the basic pay in the substantive post in parent cadre:

Pay in parent cadre post = Rs. 34,000/-. Increment = 3% of
Rs. 34,000/- = Rs. 1,020/Adding one increment = Rs. 35,020/- [i.e. Rs. 34,000/- + Rs. 1,020/-]

b.

Pay and DA admissible in parent cadre:

DA @ 130% on basic pay = Rs. 45,526/- (130% of Rs. 35,020/-) Total emoluments in the parent cadre
= Rs. 80,546/- (Rs. 35,020/- + Rs. 45,526/-)

c.
Now, fixing pay in ex-cadre post in Level 11 of Pay Matrix (with DA @10%) on the
basis of emoluments drawn in parent cadre:

Pay in ex-cadre i.e. Rs. 80,546/- shall comprise of Rs. 73,224/- (Basic Pay) + Rs. 7,322/-(DA @ 10%)

Pay Matrix

Band Pay
Grade Pay
Level
3
4

15600-39100
6600
11
71800
74000

Since there is no cell in Level 11 of Pay Matrix matching Rs. 73,224/-pay will be fixed at Rs.74,000/i.e. next cell in higher stage. So, the pay in ex-cadre post will be fixed at Rs.74,000/.

In case of reverse foreign service if the appointment is made to post whose pay structure and/or DA pattern is dissimilar to
that in the parent organization, the option for electing to draw the basic pay in the parent cadre [along with the Deputation
(Duty) Allowance thereon and the personal pay, if any] will not be available to such employee.

<!-- page 23 -->

ii)

Deputation from State Government/UTs Administration to Central Government:

(a)
When the Level (in Pay Matrix)/Pay Scale of the post in the parent cadre and that
attached to ex-cadre post are based on the same index level and the DA pattern is also same, the
pay may be fixed as provided under 5.1(i) above.
(b)
If the appointment is made to a post whose pay structure and/or Dearness Allowance
(DA) pattern is dissimilar to that in the parent organization, the pay may be fixed as provided under
5.1(ii)
(b) above.
The basic pay from time to time after pay fixation should not exceed the maximum of the pay in the level of the ex-cadre post.

5.2
In cases of appointment from one ex-cadre post to another ex-cadre post where the
employee opts to draw pay in the Level (in Pay Matrix)/Pay Scale of the ex-cadre post, the pay in
the second or subsequent ex-cadre post should be fixed under the normal rules with reference to
the pay in the cadre post only. However, in respect of appointments to ex-cadre posts carrying Level
(in Pay Matrix)/Pay Scale identical to that of the ex-cadre post(s) held on an earlier occasion(s), it
may be ensured that the pay drawn in subsequent appointment should not be less than the pay
drawn earlier.

5.3
In cases of appointments to a second or subsequent ex-cadre post(s) in a higher Level
(in Pay Matrix)/Pay Scale than that of the previous ex-cadre post, the pay may be fixed with
reference to the pay drawn in the cadre post and if the pay so fixed happens to be less than the
pay drawn in the previous ex-cadre post, the difference may be allowed as Personal Pay to be
absorbed in future increases in pay. This is subject to the condition that on both the occasions, the
employee should have opted to draw pay in the Level (in Pay Matrix)/Pay Scale attached to the
ex-cadre posts.

Note-1:
The term parent post and basic pay means the post held on regular basis in the parent organisation and
pay drawn/ admissible in such a post respectively.

Note-2:
An officer who may be holding a higher post on ad-hoc basis in the cadre at the time of proceeding on
deputation/foreign service would be considered to have vacated the post held on ad-hoc basis and proceeded on
deputation/foreign service from his/her regular post. During the period of deputation/foreign service, he/she shall earn
notional increments in the parent cadre post. On reversion, if he/she is re-appointed to the higher post on regular or ad-hoc
basis his pay will get fixed with reference to the pay admissible in the lower post on the date of such re-appointment. In such
cases, if his/her pay gets fixed at a stage lower than that of his junior(s) who continued to serve in the cadre, no stepping up
will be admissible as per extant rules in so far as Central Government employees are concerned. However, if the pay so fixed
is less than the pay drawn earlier while holding the post on ad-hoc basis the pay earlier drawn will be protected. Therefore,
those Central Government

<!-- page 24 -->

employees who are already holding a higher post on ad-hoc basis or expecting it shortly in the parent cadre may weigh all
relevant considerations before opting for deputation/foreign service. This note of caution will be applicable to employees of
other organizations wishing to apply for posts on deputation in Central Government, if governed by similar rules in parent
organization.

Note-3: Pay of an officer appointed on deputation/foreign service on ad hoc basis pending selection of a regular incumbent
may also be regulated in accordance with provisions of Paras 5.1 & 6.1 of this O.M.

Note-4: The provisions of this Para as well as Para 6 will not apply to appointments on Personal Staff of Ministers. Such
appointments will be regulated by separate specific orders issued by the Government in that behalf.

[ Para 5 of DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 17.06.2010 read with OM No. 2/10/2018- Estt.(Pay-II) dated
2.3.2021]

DEPUTATION (DUTY) ALLOWANCE

6.1

The Deputation (Duty) Allowance admissible shall be at the following rates:

(a)
Within the same station, the allowance will be payable at the rate of 5% of basic
pay subject to a maximum of Rs. 4500/- p.m.;
(b)
In case of change of station, the allowance will be payable at the rate of 10% of basic
pay subject to a maximum of Rs. 9000/- p.m.;
(c)
The ceilings will further rise by 25 percent each time Dearness Allowance increases by
50 percent; and
(d)
Basic Pay, from time to time, plus Deputation (Duty) Allowance shall not exceed the
basic pay in the Apex level i.e. Rs. 2,25,000/-. In the case of Government servants receiving NonPracticing Allowance, their basic pay plus Non-Practicing Allowance plus Deputation (Duty)
Allowance shall not exceed the average of basic pay of the revised scale applicable to the Apex
Level and the Level of the Cabinet Secretary i.e. Rs. 2,37,500/-.

6.1.2 In cases where the basic pay in parent cadre has been upgraded (upto Level 13 A) on
account of Non-Functional Upgradation (NFU), Modified Assured Career Progression Scheme
(MACP), Non-

<!-- page 25 -->

Functional Selection Grade (NFSG) etc., and the officer has opted for such upgraded pay of the parent cadre, in that event, the
upgraded basic pay under such upgradations shall not be taken into account for the purpose of Deputation (Duty) Allowance.
In such cases, the Deputation (Duty) Allowance will be calculated taking the basic pay of the parent cadre which the officer was
getting before such upgradation and the amount of the same would be further regulated every year on the basis of the pay
arrived at by giving annual increments on the presumptive pay.

6.1.3 However, if the upgradation is to Level 14 (in the Pay Matrix) or above, he shall be given
the option to draw the upgraded basic pay under such upgradations without Deputation (Duty)
Allowance or the pay which he was drawing before such upgradation with Deputation (Duty)
Allowance, whichever is more beneficial as per the option of the officer.

6.1.4 In the case of Proforma Promotion under Next Below Rule (NBR), if such a Proforma
Promotion (upto Level 13 A) is in a Level of the Pay Matrix which is higher than that of the ex-cadre
post, and the officer has opted for the upgraded pay of the Proforma Promotion, the basic pay
under such Proforma Promotion shall not be taken into account for the purpose of Deputation
(Duty) Allowance. Deputation (Duty) Allowance will be calculated taking into account the basic
pay which the officer was getting before such Proforma Promotion. The amount of Deputation
(Duty) Allowance would be calculated on the basis of the pre-upgraded presumptive pay that the
officer was drawing prior to Proforma Promotion and the amount of the same would be further
regulated every year on the basis of the pay arrived at by giving annual increments on the
presumptive pay.

6.1.5 However, if such a Proforma Promotion under NBR is in a Level of the pay matrix which
is equal to or below that of the ex-cadre post, Deputation (Duty) Allowance shall be admissible
on the basic pay of the parent cadre post allowed under the Proforma Promotion, if opted by the
deputationist.

6.1.6 However, if the upgradation is to Level 14 or above of the Pay Matrix, he shall be given the
option to draw the upgraded basic pay under such Proforma Promotion without Deputation
(Duty) Allowance or the pay which he was drawing before grant of Proforma Promotion with
Deputation (Duty) Allowance, whichever is more beneficial as per the option of the officer. The
amount of Deputation (Duty) Allowance would be calculated on the basis of pre-upgraded
presumptive pay that the officer was drawing prior to the grant of Proforma Promotion and the
amount of the same would be further regulated every year on the basis of the pay arrived at by
giving annual increments on the presumptive pay.

[DoPT's OM No. 2/11/2017-Estt.(Pay-II) dated 24.11.2017 and DoPT's OM No. 2/11/2017-Estt.

(Pay -II) dated 15.3.2021]

<!-- page 26 -->

Note: Basic Pay in the revised pay structure (the pay structure based on 7th CPC recommendations) means the pay drawn
by the deputationist, from time to time, in the prescribed Level (in Pay Matrix) of the post held by him substantively in the
parent cadre, but does not include any other type of pay like personal pay, etc.

Note: 1 The term 'same station' for the purpose will be determined with reference to the station where the person was on
duty before proceeding on deputation.

Note: 2 Where there is no change in the headquarters with reference to the last post held, the transfer should be treated as
within the same station and when there is change in headquarters it would be treated as not in the same station. So far as
places falling within the same urban agglomeration of the old headquarters are concerned, they would be treated as transfer
within the same station.

6.2
Special rates of Deputation (Duty) Allowance may be admissible under separate orders in
any particular area on account of the condition of living there being particularly arduous or
unattractive. Where special rate is more favourable than that given in Para 6.1 above, employees
deputed to the area will be given the benefit of the special rate.

6.3.1 If an employee with the permission of the competent authority, proceeds on
deputation/foreign service from one ex-cadre post to another ex-cadre post in the same or another
organization without reverting to his parent cadre, and if the second ex-cadre post is at the same
station as the first one, the rate of Deputation (Duty) Allowance would remain unchanged.

6.3.2 In cases where a person on deputation/foreign service is transferred by the borrowing
authority from one station to another without any change in the post held by him. The rate of
Deputation (Duty) Allowance will be refixed as per 6.1 (b).

[Para 6.2 and 6.3 of DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 17.06.2010]

ADMISSIBILITY OF PAY, ALLOWANCES AND BENEFITS WHILE ON DEPUTATION/FOREIGN SERVICE

7.1
Any project allowance admissible in a project area in the borrowing organization may
be drawn in addition to Deputation (Duty) Allowance.

<!-- page 27 -->

7.2
Any special allowance granted to an employee in the parent Department under FR 9(25)
or a corresponding rule of parent organization should not be allowed in addition to Deputation
(Duty) Allowance. However, the borrowing department may allow in addition to Deputation
(Duty) Allowance, under special circumstances, any special allowance attached to the post held by
the employee in his/her parent Department, by suitably restricting the Deputation (Duty)
Allowance. This will require the specific and prior approval of Department of Personnel &Training.

7.3
In case special allowance is attached to the scale of pay of the ex-cadre post and the
employee has opted to draw pay in that scale, then, in addition to the pay in that scale, he will also
be entitled to draw such special allowance. However, such special allowance will not be admissible
if he has opted to draw pay in the parent cadre scale/grade pay plus Deputation (Duty) Allowance.

7.4
Personal pay, if any, drawn by an employee in his parent department will continue to be
admissible on deputation/foreign service if he/she opts to draw pay in the parent cadre plus
Deputation (Duty) Allowance. No Deputation (Duty) Allowance on this personal pay will,
however, be admissible.

7.5
Increments - The employee will draw increment in the parent cadre or in the Level (in the
Pay Matrix) attached to the deputation post as the case may be, depending on whether he has opted
for the parent cadre pay plus Deputation (Duty) Allowance or the pay of the deputation post. If he
has opted for pay of the deputation post, notional increments shall also continue to accrue to him
in the post held on regular basis in the parent cadre/organization for the purpose of regulation of
pay on repatriation to the parent cadre/post at the end of the tenure.

7.6(a) Such allowances as are not admissible to regular employees of corresponding status in the borrowing organisation
shall not be admissible to the officer on deputation/ foreign service, even if they were admissible in the parent organisation.

(b)
Following allowances will be regulated with mutual consent of the lending and
borrowing organization:

a.

HRA/Transport Allowance.

b.

Joining time and Joining Time Pay.

c.

Travelling Allowances and Transfer T.A.

d.

Children Education Allowance.

<!-- page 28 -->

e.

LTC.

(c)
Following allowances/facilities will be regulated in accordance with the rules as
explained against each:

i.
Dearness Allowance - The employee shall be entitled to dearness allowance at the
rates prevailing in the borrowing organization or in the lending organization depending on
whether he has opted to draw pay of the ex-cadre post or the parent cadre post.

ii.
Medical Facilities - This will be regulated in accordance with the rules of the
borrowing organization.

iii.
Leave - An officer on deputation/foreign service shall be regulated by the Leave Rules
of the parent organization. If, however, an employee proceeds from vacation department to nonvacation department, or vice-versa, he shall be governed by Leave Rules of the borrowing
organization. At the time of reversion from the deputation post to the parent cadre, the borrowing
organization may allow him/her leave not exceeding two months. The employee should apply for
further leave to his Cadre Controlling Authority.

[Para 7.1-7.6 of DoPT's OM No. 6/8/2009-Estt. (Pay -II) dated 17.06.2010]

(d)
Military Service Pay (MSP): In case an army officer entitled to Military Service Pay
in parent cadre opts for parent cadre pay on deputation to a civil post, MSP will be admissible as
a separate element, provided Deputation (Duty) Allowance will not be reckoned on MSP but only
on Basic Pay.

[On the basis of clarification dated 16.2.2017 issued by D/o Expenditure]

7.7

Leave Salary/Pension/NPS Contribution

i.
As at present, allocation of leave salary and pension contribution between different
Ministries/Departments of Central Government and between Central and State Government has
been dispensed with. In such cases of deputation from Central Government to State Government
and vice-

<!-- page 29 -->

versa, liability for bearing leave salary vests with the Department from which the officer proceeds on leave or which sanctioned
leave and no contributions are payable to the lending organization. Liability for pension/employee's contribution to CPF will
be borne by the parent department, to which the officer permanently belongs at the time of retirement and no proportionate
contribution will be recovered.

ii.
In case of deputation of Central Government employees on foreign service terms to
Central Public Sector Undertakings/ State Public Sector Undertakings and Autonomous Bodies
etc., leave salary contribution (except for the period of leave availed of on foreign service) and
pension contribution/ Contributory Provident Fund (CPF) (Employer's share) contribution are
required to be paid either by the employee himself or by the borrowing organization to the Central
Government. In cases of reverse deputation from Central Public Sector Undertakings/ State Public
Sector Undertakings/ Autonomous Bodies/local bodies to Central Government, the employer’s
share of CPF for the period of deputation to the Central Government will be borne either by the
employee himself or borrowing organisation i.e. Central Government depending on the terms of
deputation. A clear mention of the stipulation on whether the Central Government or the
employee would bear the liability may be made in the terms of deputation.

[DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 15.2.2012 ]

iii.
In cases of reverse deputation from Central Public Sector Undertakings/ State Public
Sector Undertakings/ Autonomous Bodies/local bodies to Central Government, the question
regarding leave salary and pension contribution will be decided by mutual consent.

iv.
In case of employees covered under New Pension Scheme (NPS), the borrowing
department shall make requisite contribution to the NPS account of the employee.

TENURE OF DEPUTATION/FOREIGN SERVICE

8.1
The period of deputation/ foreign service shall be as per the provisions of the RRs of the
ex- cadre post or 5 years in case no tenure regulations exist for the ex-cadre post.

8.2
In case where the period of deputation/foreign service prescribed in the RRs of the ex-cadre
post is 5 years or less than 5 years, the borrowing Ministry/Department/ Organization may grant
extension upto the 6th year after obtaining orders of their Secretary (in the Central Government)/
Chief Secretary (in the State Government)/ equivalent officer (in respect of other cases) and for the
7t h year with the approval of the Minister of the borrowing Ministry /Department and in respect
of other

<!-- page 30 -->

organizations with the approval of the Minister of the borrowing Ministry/Department with which they are
administratively concerned.

[DoPT's OM No. 2/6/2018-Estt.(Pay-II) dated 18.5.2018 ]

8.3.1 The borrowing Ministries/Departments/Organizations may extend the period of
deputation up to the seventh year where necessary in public interest, subject to the following
conditions:

i.
The extension would be subject to the prior approval of the lending organization,
the consent of the official concerned and wherever necessary, the approval of the UPSC/ State
Public Service Commission and Appointment Committee of Cabinet (ACC).

ii.
If the borrowing Ministry/Department/Organization wishes to retain an officer beyond
the prescribed tenure, it shall initiate action for seeking concurrence of lending organization,
individual concerned etc. six months before the date of expiry of tenure. In no case it should retain
an official beyond the sanctioned term unless prior approval of the competent authority to grant
further extension has been obtained.

iii.

No further extension beyond 7th year shall be granted.

8.3.2 Admissibility of Deputation (Duty) Allowance would be only upto fifth year.

[DoPT's OM No. 2/6/2016-Estt.(Pay-II) dated 23.02.2017 ]

COOLING OFF

9.1
There shall be a mandatory 'cooling off’ period of three years after every period of
deputation/foreign service up to Joint Secretary level posts (i.e. deputation post carrying pay in
Level- 14 of the Pay Matrix) and one year for Additional Secretary level posts (i.e. deputation post
carrying pay in Level-15 of the Pay Matrix).

The Ministries/Departments may not sponsor name of any such officer who is not likely to complete the mandatory ‘cooling
off’ period by the time the officer is likely to be selected. Further, while

<!-- page 31 -->

sponsoring the name of any such officer who has not completed the mandatory cooling off period, the parent cadre authority may
inform the borrowing department that the officer will be relieved only after he/she completes the mandatory cooling off period.

[DoPT's OM No. 2/1/2012-Estt.(Pay-II) dated 4.1.2013 ]

9.2
A Central Government employee shall be eligible for deputation/foreign service to posts
in State Government/State Government Organization/ UT Administration / Government of
UT's Organization/Autonomous Bodies. Trusts, Societies, PSUs etc. not controlled by the
Central Government only after he has completed 9 years of service and is clear from the
vigilance angle.

9.2.1 However, with the approval
Ministry/Department/ Organization:

of

the

Minister-in-charge

of

the

i.
Central Government employee after completion of 7 years of service in his/her cadre,
may be allowed to go on deputation to any State of North-Eastern Region and Union Territories
of Jammu & Kashmir, Ladakh, Andaman & Nicobar and Lakshadweep or on foreign service to any
entity controlled by and located in the afore said States/ Union Territories;

ii.

Central Government employees may be allowed to go on deputation to State Governments

/Union Territories or on foreign service to any entity controlled by and located in the States/ Union Territories on spouse
ground after completion of 6 years of service in the cadre.

[DoPT's OM No. 2/15/2017-Estt.(Pay-II) dated 18.10.2018]

10.
If during the period of deputation/foreign service, on account of Proforma
Promotion in the parent cadre the official concerned becomes entitled to a higher pay in the
Level (in the Pay Matrix) in the parent cadre vis-a-vis that of the ex-cadre post, the official shall
complete his/her normal /extended tenure of deputation already sanctioned with the approval
of the competent authority. The pay shall be regulated as under:

a.
If the Level (in the Pay Matrix) of the officer in the parent cadre becomes higher than that of
the deputation post after getting Proforma Promotion, he may be allowed the pay in the Level (in
the Pay Matrix) of the post to which he is promoted, if he so opts. In such cases, extensions in
deputation after

<!-- page 32 -->

employee has received the Proforma Promotion may be considered as per the instruction in paras 8.1 to 8.3.2.

b.
If he draws the pay in the Level (in the Pay Matrix) attached to the deputation post, on
reversion to his parent cadre, his pay may be fixed by allowing him notional increments in his
regular post in the parent department.

c.
If the Level (in the Pay Matrix) of the officer in the parent cadre becomes higher than that of
the deputation post on getting financial upgradation under the ACP/MACP scheme, the officer may
be allowed to draw the pay in Level (in the Pay Matrix) to which he becomes entitled to under the
ACP/MACPS, if opted for by him, as laid down in Para 27 of Annexure I to the DoPT OM No.
35034/3/2008 -Estt.(D) dated 19th May, 2009.

[DoPT OM No. 35034/3/2008 -Estt.(D) dated 19th May,
2009]

PREMATURE REVERSION OF DEPUTATIONIST TO PARENT CADRE.

11.
Normally, when an employee is appointed on deputation/foreign service, his services
are placed at the disposal of the parent Ministry/ Department/Organization at the end of the
tenure. However, as and when a situation arises for premature reversion to the parent cadre of
the deputationist, his services could be so returned after giving a notice of at least three months
to the lending Ministry/Department/ Organization and the employee concerned.

OVERSTAY ON DEPUTATION

12. The deputationist officer is deemed to have been relieved on the date of expiry of the deputation
period unless the competent authority has with requisite approvals, extended the period of
deputation, in writing, prior to the date of its expiry. It will be the responsibility of the immediate
superior officer to ensure that the deputationist does not overstay. In the event of the officer
overstaying for any reason whatsoever, he/she is liable to disciplinary action and other adverse
Civil/Service consequences which would include the period of unauthorized overstay not being
counted for service for the purpose of pension and that any increment due during the period of
unauthorized overstay being deferred with cumulative effect, till the date on which the officer
rejoins his parent cadre.

[DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 1.3.2011 ]

<!-- page 33 -->

All the Ministries/Departments are to ensure that deputations are strictly monitored by the lending Government
Ministry/Department/Organization. Requests of the borrowing authorities for no objection to extension of deputation
should be closely scrutinized to curb tendency to allow extensions on extraneous ground and overstay.

[DoPT's OM No. 6/8/2009-Estt.(Pay-II) dated 16.5.2013 ]

RELAXATION OF CONDITIONS

13. Any relaxation of these terms and conditions will require the prior concurrence of the
Department of Personnel & training.

DATE OF EFFECT

14.
These orders will take effect from 1.1.2016 and shall be applicable to all officers
who were on deputation on 1.1.2016 or appointed thereafter except for the following:

i.

Revised rates of Deputation (Duty) Allowance shall be applicable from 1.7.2017.

ii.
Provisions of Para 8.1 and 8.2 shall be applicable from 18.05.2018. iii. Provisions of
Para 8.3.1(iii) shall be applicable from 17.02.2016. iv. Provisions of Para 9.2.1 shall be applicable
from 18.10.2018.

iii.
Guidelines issued vide DoPT’s OM No. DOPT-1710841987283 dated 15.03.2024,
referred in para 3(b)(iv) of this OM, shall take effect from the date of issue of the OM i.e.
15.03.2024.

15.
List of the OMs mentioned in this document is annexed. In case, any reference to
the relevant OM is required, the same may be accessed from DoPT’s website.

<!-- page 34 -->

ANNEXURE
List of OMs mentioned in this Document

S.No. O.M. No.
1.
2.

3.
4.
5.
6.

7.

8.

9.

10.

11.

6/8/2009- Estt.(Pay-II)
6/8/2009- Estt.(Pay-II)

O.M. Date Subject

01.03.2011 Overstay while on deputation.
15.02.2012 Clarification regarding regulation of
payment of employer’s share of
contribution to the Contributory Provident
Fund during the period of reserve
deputation.
6/5/2012- Estt.(Pay-II) 30.11.2012 Provisions relating to proforma
promotion.
2/1/2012- Estt.(Pay-II) 04.01.2013 Sponsoring of names of officers for
deputation.
6/8/2009- Estt.(Pay-II) 16.05.2013 Proper Monitoring of deputation by the
lending departments.
2/6/2016- Estt.(Pay-II) 17.02.2016 Delegation of powers to Ministries /
Departments/Borrowing Organizations to
extent deputation tenure upto 7 years in
cases of Deputation covered by DOPT’s
OM No. 6/8/2009-Estt.(Pay-II) dated
17th June, 2010 – regarding.
2/6/2016- Estt.(Pay-II) 23.02.2017 Admissibility of Deputation (Duty)
Allowance while on deputation –
regarding.
2/11/2017- Estt.(Pay-II) 24.11.2017 Grant of Deputation (Duty) Allowance –
Recommendations of the Seventh Central
Pay Commission – regarding.
2/6/2018- Estt.(Pay-II) 18.05.2018 Amendment in Para 8.1 and Para 8.2 of
deputation guidelines issued vide OM
No.6/8/2009-Estt.(Pay-II) dated 17th June,
2010.
2/15/2017- Estt.(Pay-II) 18.10.2018 Transfer of deputation/ foreign service of
Central government Employees to excadre posts under the State Governments/
Union Territories or to any entity
controlled by and located in the
States/UTs – relaxation of para 8.5 of
O.M. dated 17.06.2010.
2/10/2018- Estt.(Pay-II) 02.03.2021 Amendment of Para 5 of consolidated
guidelines on deputation issued vide OM
No. 6/8/2009-Estt.(Pay-II) dated
17.06.2010 according to 7th CPC pay
structure.

<!-- page 35 -->

12.

13.

14.

15.

16.
17.

2/11/2017- Estt.(Pay-II) 15.03.2021 Grant of Deputation (Duty) Allowance in
cases where the basic pay in parent cadre
has been upgraded on account of NFU,
MACP, NFSG, etc. in the 7 th CPC
context – clarification.
2/9/2018- Estt.(Pay-II) 12.04.2021 Amendment in Para 3.4 of deputation
guidelines issued vide OM No.6/8/2009Estt.(Pay-II) dated 17th June, 2010.
AB.14017/24/2022-Estt. 31.08.2022 Consolidated and revised instructions on
(RR)
constitution of Search Committees and
Search-cum-Selection Committees
40/1/2022-EO(CVO)
18.11.2022 Guidelines/procedure for appointment of
CVOs in CPSEs and other organizations
under Central Government and their
service conditions.
1705650752584
19.01.2024 Consolidated instructions governing
Central Staffing Scheme (CSS).
OM No.6/8/202315.03.2024 Instructions governing appointment and
Pers.Policy
terms and conditions of deputation of
(Deputation/ReGroup ‘A’ officers of the Central
Government to ex-cadre posts under a
employment) Pt.XV
State Government/UT Administration
including PSUs/ Autonomous
bodies/Statutory Bodies/ Universities/
Local Bodies under the States/UT
Administration in partial modification of
the instructions governing
deputation/foreign service and para 1.3 of
this Department’s OM No.AB14017/2/2007-Estt(RR) dated 29.02.2008

(Sign of Authority)
Mahesh Kumar Under Secretary
23040489

<!-- page 36 -->

Q.1

Frequently Asked Questions
Applicability of O.M dated 15.03.2024?

Ans.
Cases involving deputation of Group ‘A’ officers of the Central Government to ex-cadre posts under a State
Government/UT Administration including PSUs/ Autonomous bodies/Statutory Bodies/ Universities/Local Bodies under the
States/UT Administration.

Whether applicable to cases involving deputation of Central Govt. officers of Pay level-14 and above who wish
to apply for deputation to posts under Central Govt.?

Q.2

Ans. No. Their deputation shall continue to be governed by the existing deputation guidelines issued vide DoPT’s OM No.
6/8/2009-Estt. (Pay II) dated 17.06.2010, as amended from time to time.

Q3. An officer in Pay Level 13 while on deputation, gets promoted to Pay Level-14 in his parent cadre. In such
a situation can the officer continue his deputation or he/she needs to report back to his/her parent cadre?

Ans.
The officer who gets promoted to Pay Level 14 in the parent Cadre while on deputation may be allowed to
complete already approved deputation tenure.

Q4.
What is the total allowable period of deputation in cases governed by the provisions of DoPT’s OM dated
15.03.2024?

Ans.
Total allowable period of deputation to the posts under State govt. /UT Administration including PSUs/
Autonomous bodies/Statutory Bodies/Universities/Local Bodies under the States/UT Administration would be restricted to
5 years in entire career.

Q5. Who is the Authority competent to send such proposal to obtain requisite approvals as prescribed in DoPT’s
OM dated 15.03.2024 or any relaxation to the provisions thereof, where admissible?

<!-- page 37 -->

Ans. The proposal should be sent by the Cadre Controlling Authority of the officer concerned with the approval of the Minister
in-charge of the administrative ministry/department along with the NOC of the borrowing State/UT government.

Q6.

What would happen if the officer does not repatriate to parent cadre in anticipation of extension?

Ans.
In the event the officer overstays for any reason whatsoever without formal approval of the Competent Authority to
the extension sought, he/she is liable for disciplinary action and other adverse Civil/ Service consequences which would
include the period of overstay not being counted towards service for the purpose of pension and any increment due during
the period of overstay being deferred with cumulative effect, till the date on which the officer re-joins in his parent Cadre.

Q8.

Are the provisions of the OM dated 15.03.2024 applicable to group A officers of the State government?

Ans.

No.

Q9.
Does the deputation period spent in Group B will also count towards the total deputation tenure availed by
an officer of central government in state government /UT Administration including PSUs/ Autonomous
bodies/Statutory Bodies/Universities/Local Bodies under the

States/UT Administration?

Ans.
No. Provisions of DoPT’s OM dated 15.03.2024 are applicable to only the cases involving deputation of Group A
officers of the Central Government.

Q.10
Documents required to be submitted while sending proposal to DoPT for consideration in terms OM dated
15.03.2024.

Ans.

Checklist for submitting the proposal to DoPT is mentioned below:

<!-- page 38 -->

1.

Proposal Text

2.

Name /Service /Cadre
/Batch of the Officer

3.

Updated Executive Record
Sheet/Service profile of
the officer
Home State of the Officer

4.
5(a).
5(b).

6.

7.
(a)

 Attached NA

(Annexure- I)

Vigilance status of the
 Attached NA
officer
Date of filing of Annual
Date:
IPR as filed in the month
of January this year or
otherwise by the officer
Availability of the
 Attached NA
representation/ consent of
the officer
NOC from the Concerned State Governments/CCAs(Cadre Controlling Authority):
State Governments/CCA-1 Parent/ Accepting Cadre: State Govt of

(Annexure- II)

(Annexure- III)

(Annexure- IV)

XYZ
State Governments/CCA-2

 Attached NA
Parent/ Accepting cadre: State Govt of
ABC

(Annexure- V)

(c)

State Governments/CCA-3

 Attached NA
Parent /Accepting cadre: State Govt of
PQR

(Annexure- VI)

9.

Details of Cadre Strength/
In-Position strength of the
Service as on first January
of the year as per Civil List

10(a).

Draft ACC Note

 Attached NA

(AnnexureVIII)

10(b).

Point for consideration of
ACC
Relevant Rules/ Policy

 Attached NA

(Annexure-IX)

(b)

11.

 Attached NA
 Attached NA

(Annexure- VII)

<!-- page 39 -->

12.

Details, if the proposal
involves relaxation of the
policy
Administrative/
functional justification
of the proposal.

13.

14.

Approval of the
Minister- in-charge in
Self contained
Note
9 years of Service in
Group ‘A’

15.

16.


Attached
NA

(Annexure-X)

Details of the Cadre
Clearance
Pay level of the Officer
Details of deputation to
State/UTsGovernments
etc. as indicated in para 3
of DoPT’s OM dated
15.03.2024may

17.
18.

be provided
19.

Period of deputation for
which approval is sought

Signature:
Name:
Designation:( Joint Secretary or equivalent or above)
Stamp/Seal:

Q11.

How to refer the proposal to DoPT?

Ans.
References seeking approval of the designated Committee to the proposal before it is submitted
for approval by the Appointments Committee of the Cabinet (ACC) should be made only on e-file, with details/
self-contained notes, strictly in accordance with the procedure laid down in this Department’s O.M. No.
43011/9/2014-Estt.D dated 28th October, 2015 and Secretary (P), DoPT’s DO letter No. I-28029/30/2021Coord dated 12.09.2022
(Sign of Authority)
Mahesh Kumar Under Secretary

23040489
