---
doc_id: "325fcfba0a16fc6d"
source_url: "https://financialservices.gov.in/sites/default/files/order-notices/NICL%2520Order%2520%25281%2529.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "NICL%20Order%20%281%29.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0a555ab3ccdc8740"
---

<!-- page 1 -->

F. No. A- 150 1 1/0 5 / 2021.-Ins.I

Government of India
Ministry of Finance
Department of Financial Services
Jeevan Deep Building,2d Floor
Sansad l,4arg, New Delhi- 110 001

Dated 28'h Jurrc,2023
To:
Chairman- cum-Iv{anaging Director

NICL
Kolkama

Subiect: Nomination of Shri Debadatta Chand, MD & CEO of Bank of Baroda on the Board

of NICL
Sr,
The undersigned is directed to conveythat the Gntral Govemment, in exercise of its powers

under anicle 111(1) of the Anicles of Association of National Insurance C-ompany limited

[.UCL) , hereby appoints Shri Debadana Chand (DoB 31.1,.197 L) ,MD & CE O, Bank of Baroda
as non-executive independent director on the Board of NICL for a period of three yean wfuh
effect from the date of assumption of office of MD & CEO, Bank of Baroda bythe incumbent on
or after 1.7.2023 or until further orders, whichever is earlier.

2.

In this regard, attention is invited to the fact that the Bank of Baroda being an insurance
intermediary permission of the Insurance Regulatory and Development Authoriry of India is
required under the second proviso of section 48A of the Insurance Act, 1938 for the bank to be on

the Board of the said insurance company.

3.

Accordingly, IRDAI vide its circular ref. no. IRDAI/F&I/CIR/MSC/183/9/2022 dated
2.9.2022 has prescribed that the appointment or continuation of common director representing
insurance"agent, interme diary or insurance intermediary on the board of insurance company shall be
deemed to have been permined subject to the conditions stated under the provision of clause 3(a)
of said circular (copyenclosed).

4.

The date of assumption of office by Shri Debadatta Chand may be communicated to this
Department.

EncL As

above

Youn faithfully

\t1ury
(Vinod Kumar)
Under Secretaryto the Govemment of India
Tele:011 23748788
E mail usins 1-dfs@ nic.in
