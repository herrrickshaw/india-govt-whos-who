---
doc_id: "31bdbf2bbd4bdde7"
source_url: "https://mines.gov.in/admin/imgview?filename=6a47999808e471783077272.pdf"
ministry: "Mines (MoM)"
title: "Circular for seeking comments of stakeholders on draft revision of Recruitment Rules"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4530ce4ea9a00372"
---

<!-- page 1 -->

<!-- page 2 -->

Annexure-III
1. (a) Name of post

: Director General, Geological Survey of India

(b) Name of the Ministry/Department

: Ministry of Mines / Geological Survey of India

2. Reference No. in which the Commission’s advice on

:3/40(6)/2018-RR dated 14.12.2018

Recruitment rules was conveyed/Number and date of
Notification of the existing recruitment rules
Col.
No.
1

Particulars

1

2
Name of the post

2
3.

No. of posts
Classification

4.
5.

Scale of pay
Whether selection post
or non-selection post
Age limit for direct
recruits

6.

Provisions in the
existing
Recruitment Rules
3
Director General
1(one)
General
Central
Services,
Group-A,
Gazetted,
NonMinisterial
Level-17 in pay matrix
Selection
Not exceeding 58 years
(Relaxable
for
Government
servants
upto five years’ in
accordance with the
instructions or orders
issued by the Central
Government.) from
time to time

: Notified in the Gazette of India, Part II, Sec-3(i), dt.
24.12.2018
Revised Provisions Proposed

Reasons for the revision
proposed

4
Chief Executive Officer
1(one)
General Central Service,
Gazetted Non Ministerial

Group

‘A’

5
On the basis of Committee’s
recommendations
-

Level-17 in pay matrix
Selection

Replacement Pay scale as per 7 CPC
No Change

Not exceeding 56 years (Relaxable for
Government servants upto five years’ in
accordance with the instructions or
orders
issued
by
the
Central
Government.) from time to time
Note.-The crucial date for determining
the age limit shall be the closing date for
receipt of applications from candidates in
India (and not the closing date prescribed
for
those
in
Assam,
Meghalaya,

To provide a reasonable tenure
to the head of organization to
carry out purposeful work for
the desire output. One year will
be too short for a leader to
achieve
the
targeted
assignments.

<!-- page 3 -->

7.

Educational and other
qualifications required
for Direct recruits.

Note.-The crucial date
for determining the age
limit shall be the closing
date for receipt of
applications
from
candidates in India (and
not the closing date
prescribed for those in
Assam,
Meghalaya,
Arunachal
Pradesh,
Mizoram,
Manipur,
Nagaland,
Tripura,
Sikkim, Ladakh Division
of Jammu and Kashmir
State, Lahaul and Spiti
District and Pangi SubDivision
of
Chamba
District of Himachal
Pradesh, Andaman and
Nicobar
Islands
or
Lakshdweep).
Essential

Arunachal Pradesh, Mizoram, Manipur,
Nagaland, Tripura, Sikkim, Ladakh
Division of Jammu and Kashmir State,
Lahaul and Spiti District and Pangi SubDivision of Chamba District of Himachal
Pradesh, Andaman and Nicobar Islands
or Lakshdweep).

(A) Essential Qualification:
(I)Master of Science in
Geological Science or
Master
of
Science
(Technology) Geology
or Master of Science in
Geology or Integrated
Master of
Science in
Applied
Geology
or
Master of Technology
(Geo-Exploration)
or
Master of Technology
(Engineering Geology)
or
Master of Science
(Marine Geology) or

Master of Science
in Geological
Science/Master of Science (Technology)
Geology / Master of Science in Geology /
Integrated Master of
Science in
Geology/ Applied Geology/ Master of
Technology (Geo-Exploration) / Master
of Technology (Engineering Geology) /
Master of Science (Marine Geology) /
Master of Science in Earth Science and
Resource Management /
Master of
Science in Oceanography and Coastal
Areas Studies / Master of Science in
Petroleum Geosciences course / Master

<!-- page 4 -->

Master of Science in
Earth
Science
and
Resource Management
or Master of Science in
Oceanography
and
Coastal Areas Studies or
Master of Science
in
Petroleum Geosciences
course or
Master of
Science
in
Geochemistry from a
recognized University
OR
Master of Science in
Physics
or
applied
physics or Master of
Science in Geophysics
or Integrated Master of
Science in Exploration
Geophysics or Master of
Science
in
Marine
Geophysics or Master of
Science
(Tech.)
in
Applied
Geophysics
from
recognized
university and
(II) Having thirty years
of experience in Group A
post
in
mineral
exploration
or
geological mapping or
marine
geology
including research and
development
in
the
fields specified above of
which ten years shall be

of Science in Geochemistry
recognized University.

from

a

OR
Master of Science in Physics / applied
physics / Master of
Science in
Geophysics/
Integrated Master of
Science in Exploration Geophysics /
Master of Science in Marine Geophysics /
Master of Science (Tech.) in Applied
Geophysics from a recognized university.
OR
M.Tech in any Stream/ M.Sc. in
Maths/Chemistry from a recognized
university.
Experience
(i) Having 30 years of experience in
Group A posts in mineral exploration or
geological mapping or marine geology
including research and development in
the fields specified above Out of which at
least ten years should be in planning,
administration,
development
of
organization. OR
Having 30 years of experience group ‘A’
post
in
Geophysical
mapping,
Geophysical Exploration for mineral
targeting, Marine Geophysics, Airborne
Geophysics including Research and
Development activities in the field
specified above, Out of which at least ten

<!-- page 5 -->

in
a
supervisory
capacity.
OR
Having thirty years of
experience group ‘A’
post
in
Geophysical
mapping, Geophysical
Exploration for mineral
targeting,
Marine
Geophysics,
Airborne
Geophysics
including
Research
and
Development activities
in the field specified
above of which ten
years should be in a
supervisory capacity
Note 1- Qualifications
are relaxable at the
discretion of the Union
Public
Service
Commission for reasons
to
be
recorded
in
writing, in the case of
candidates
otherwise
well qualified.
Note
2.The
qualifications regarding
experience
are
relaxable
at
the
discretion of the Union
Public
Service
Commission,
for
reasons to be recorded
in writing, in the case of

years
should
administration,
organization.

be
in
planning,
development
of

OR
Having 30 years of experience group
‘A’ posts or equivalent in central
Government/State
Government/UT/PSUs/autonomous
bodies.
Note 1- Qualifications are relaxable at the
discretion of the Union Public Service
Commission for reasons to be recorded in
writing, in the case of candidates
otherwise well qualified.
Note 2.- The qualifications regarding
experience
are
relaxable at
the
discretion of the Union Public Service
Commission, for reasons to be recorded
in writing, in the case of candidates
belonging to the Scheduled Castes or the
Scheduled Tribes if any at any stage of
selection the Union Public Service
Commission is of the opinion that
sufficient number of candidates from
these communities possessing the
requisite experience are not likely to be
available to fill up the post reserved for
them.

<!-- page 6 -->

candidates belonging to
the Scheduled Castes or
the Scheduled Tribes if
any at any stage of
selection
the
Union
Public
Service
Commission is of the
opinion that sufficient
number of candidates
from these communities
possessing the requisite
experience are not likely
to be available to fill up
the post reserved for
them.
8.

9.
10.

Whether
age
and
educational
qualifications
prescribed for direct
recruits will apply in
the case of promotes.
Period of probation,
if any
Method
of
Rectt.,
whether
by
Direct
Recruitment
or
by
Promotion
or
by
deputation/absorption
and percentage of the
posts to be filled by
various methods.

No

One year for direct
recruits.
Promotion failing which
by
Deputation
(including
Short-term
contract) failing both by
direct recruitment

Not Applicable.

One year for Direct Recruits

No change

Direct Recruitment
(Percentage - 100%)
Note: - The recruitment will be on the
basis of direct recruitment from the
following:
(A) Officers having two years regular
service in level-15 of pay matrix
(Rs.1,82,200-2,24,100)
or

To have the expertise from a
wider pool of officers from the

<!-- page 7 -->

equivalent
in
Government/Autonomous
organizations
possessing
Educational
Qualification
and
experience mentioned in Column No
7
Or
(B)
Group 'A' officers including All
India Services (AIS) with 30-year
service in Central Government/State
Governments/UTs/Autonomous
Bodies. should be holding a post, for
at least 05 years, equivalent to the
level of Joint Secretary in Govt. of
India or carrying equivalent scale of
pay on substantive basis on the date
of application and out of which at
least five years should be in
planning,
administration,
development
of
organization
possessing Educational Qualification
and experience mentioned in Column
No 7
Or
(C) Applicants, from Public Sector
Undertakings working in Geology &
Mining field, should be holding post
at Board level from Schedule-A
CPSEs/CMDs of Schedule-B CPSEs
with at least five years’ experience in
planning,
administration,
development
of
Organization

Central
Government/State
Governments/UTs/Autonomous
bodies/ PSUs beside GSI

<!-- page 8 -->

possessing Educational Qualification
and experience mentioned in Column
No 7
11.

In case of rectt. By
promotion/deputation/
transfer, grade from
which
promotion/deputation
/transfer to be made.

Promotion:
Additional
Director
General (Geology) and
Additional
Director
General
(Geophysics)
with two years’ regular
service in Level-15 of in
pay
matrix
(Rs.1,82,2002,24,100).
Note 1.-Where juniors
who have completed
their
qualifying
or
eligibility service are
being considered for
promotion, their seniors
would
also
be
considered
provided
they are not short of the
requisite qualifying or
eligibility service by
more than half of such
qualifying or eligibility
service or two years,
whichever is less, and
have
successfully
completed
their
probation period for
promotion to the next
higher grade alongwith
their juniors who have

Not applicable

<!-- page 9 -->

already completed such
qualifying or eligibility
service.
Note 2. Promotion to
the grade shall be
considered based on
common eligibility list
prepared with reference
to
the
date
of
completion
by
the
officers
of
the
prescribed
qualifying
service in the respective
grade / post with due
regard to the inter-seseniority of officers in
respective
grades/posts.
Deputation
(Including short term
contract):
Officers
under
the
Central Government or
State Governments or
Union
territories
or
Public
Sector
Undertakings
or
recognized
research
institutions
or
Universities or semiGovernment
or
statutory
or
autonomous
organization;

Not applicable

<!-- page 10 -->

(a)
(i)
holding
analogous
post
on
regular basis in the
parent
cadre
or
Department; or
(ii)
With one-year
service in the grade
rendered
after
appointment thereto on
a regular basis in level16 of the pay matrix, or
equivalent
or
(iii) With two years’
service in the grade
rendered
after
appointment thereto on
a regular basis in the
level-15 of the pay
matrix. and
(b)
Possessing the
educational
qualifications
and
experience prescribed
for direct recruits under
column 7.
Note
1.-The
Departmental officers in
the feeder category who
are in the direct line of
promotion will not be
eligible
for
consideration
for

<!-- page 11 -->

appointment
on
deputation/
absorption.
Similarly
deputationist shall not
be
eligible
for
consideration
for
appointment
by
promotion.

12.

If a DPC exists what is
its composition.

Note
2.-Period
of
deputation
(including
short term contract)
including
period
of
deputation
(including
short term contract) in
another ex-cadre post
held
immediately
preceding
this
appointment
in
the
same or some other
organization
or
Department
of
the
Central
Government
shall ordinarily not to
exceed five years. The
maximum age limit for
appointment
by
deputation
(including
short term contract)
shall not be exceeding
58 years as on the
closing date of the
receipt of applications.
Group ‘A’ Departmental
Promotion
Committee
(for
considering

<!-- page 12 -->

promotion)
of: -

consisting

1. Chairman or Member,
Union Public Service
CommissionChairman;
2. Secretary, Ministry of
Mines- Member.

Selection Committee
recruits): -

(for

Direct

3. Secretary, Ministry of
Earth
SciencesMember.

Composition
of
Departmental
Committee for confirmation of Direct
recruits: -

Group ‘A’ Departmental
Promotion
Committee
(for
consideration
confirmation)
consisting of: -

1.
Secretary,
Chairman;

1. Secretary, Ministry
of Mines- Chairman;

3. Secretary, Ministry of Earth SciencesMember.

Ministry

of

Mines-

2. Secretary, Ministry of Science and
Technology- Member;

2. Secretary, Ministry of
Science
and
Technology- Member;
3. Secretary, Ministry
of
Earth
SciencesMember.
13.

Circumstances
in
which UPSC is to be
consulted in making
recruitment.

Consultation with Union
Public
Service
Commission necessary
while
making
direct
recruitment
and
appointing an officer on

Not applicable

Direct Recruitment is proposed
through
Union
Public
Service
Commission.

<!-- page 13 -->

deputation
(including
short term contract).
