---
doc_id: "3098aabbcbaeb115"
source_url: "https://www.mea.gov.in/images/pdf/minutes-of-meeting-for-appointment2022.pdf"
ministry: "External Affairs (MEA)"
title: "Minutes of the meeting for recommending candidates for appointment on compassionate grounds to the posts of JSA and MTS for the Recruitment Year 2020-21"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "c6f2b10c6284c827"
---

<!-- page 1 -->

@ Minules_of_the meeting for recommending candidates for_appointment on compassionate of the meeting for recommending candidates for appointment on compassionate
grounds to the posts of JSA and MTS for the Recruitment Year 2020-21
In terms of DoP&T’s O.M. No. F.No. 14014/02/2012-Estt. (D) dated 16.01.2013, 5% of the vacancies
falling under DR quota of JSA and MTS posts, are assigned for appointment on compassionate grounds.
2. Cadre Cell of the Ministry had informed that 1 post of JSA and 2 posts of MTS are available to be
filled under this quota for recruitment year 2020-21.
3. The Committee constituted to screen and recommend candidates for compassionate appointment to
the posts of JSA & MTS out of 31 eligible candidates met on 30” December, 2021 at 3:30 pm in Room
No. 70, South Block, New Delhi under the chairmanship of Sh. Kartik Pande, Joint Secretary (IOR). |
4. As per new guidelines of DoP7| (F.No.43019/9/2019-Estt(D) dated 23.08.2021), candidates have not
been called for personal hearing this year. The point based merit system was published on MEA website
and Unique Registration Numbers (URNs) have been communicated to the eligible candidates.
5. The Committee shortlisted the candidates based on the criteria evolved to gauge financial penury
based on the following approved parameters:

(i) Family Pension.

(ii) Terminal Benefits (Gratuity).

(iii) Left-over Service of the Deceased (in years).

(iv) Size of family & additional points.

(v) Monthly Income of all the dependent members of the Deceased’s family (including the applicant)
(includes income from all sources like house property/rental income/commercial property,
agricultural income, salary/wages, bank interest etc. but excludes family pension).

. (vi) Rented/owned property(house).
(vii)Postings done by deceased government employee.
6. The Committee, based on the criteria as explained in para 5 above and within the overall ambit of
financial penury, drew up a list of the following eligible candidates in order of merit for appointment to the
Posts of JSA(1) and MTS(2) based on their suitability/eligibility for such posts:
Sr.No. | Applicants Name Name of the deceased official and Post recommended for
applicant's relation with him/her
Shri Vishal Late Malesher, Mother
Late Bijender Singh, Father
Shri Deepak Rai Late Surender Kumar Rai, Father
7. The Committee also recommended to keep panel as per seniority list, in case selected candidates do
not accept the offer for appointment.
(107 ६०७०५ ५४५
(Chandramouli Kern) (Pranay Sinha) fom Gupta
US (PC, PD & PE) US (Gem-ill) US (FSP & Cadre)
Member Member Member
oe A fe ef Kone le
(S. R. Meena) (L. Ramesh Babu) ०500 ‘ande)
DS (Welfare) Dir (ADP) Joint Sécretary (IOR)
Member & Convener Member Chair
me tata auras

<!-- page 2 -->

Q/Wel/851/2/2021
9 Ministry of External Affairs
(Welfare Division)
2K
Sub: Marks scored by the candidates selected on compassionate grounds - RY 2020-21, Marks scored by the candidates selected on compassionate grounds - RY 2020-21.
St Unique Applicants Name/DOB Name of the deceased Post Scored
No. | Registration official and applicant's recomme
Number relation with him/her nded for
(URN)
851/12/2015 | Shri Vishal, 04.08.1984
851/09/2019 | Shri Bunty, 20.10.1998 | Late Bijender Singh,
Father
(iii) | 851/04/2021 | Shri Deepak Rai, | Late Surender Kumar Rai, MTS 30
24.07.1997 Father
-sd-
(S.R. Meena)
Deputy Secretary to the Government of India
Li
