---
doc_id: "31bd46e6eab0adb6"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/1fdebf28b0eec64dfaf1b401f4f2923f.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Office Order: with the approval of the Competent Authority, postings/transfers are hereby ordered with immediate effect and until further orders."
date: "2025-06-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "264bc73fe0ef6ba3"
---

<!-- page 1 -->

F.No.

- 22012 1512020-Admn-I(Estt'XHqrs)
Hl-{ds{6'R
Govemment of india

qffi sff,{, T{cTdl ek ffi di16q
Ministry of Fisheries, Animal Husbandry and Dairying

q{qrffi 3iRffiBt{FI

Department of Animal Husbandry and Dairying
EB rr+c, T{ftd-rtooot
Krishi Bhawan, New DelhFl10001
g4i6': 14.09.2020
Dated the 14'09.2020
OFFICE ORDER

with the approval of the competent Authority, following postings/transfers are
hereby ordered with immediate effect and until further orders :

(i) Dr. R. G. Bambal, Joint Commissioner is transferred from DAHD, Hqrs and
posted to CPDO, Bhubaneshwar, Odisha.

(ii) shri B. K. Malik, loint commissioner is transferred from cPDo, Bhubaneswar,
Odisha and posted to C&DD Division, DAHD, Hqrs.

(iii) Dr. Vinod Bhatt, Director, cFsP&TI, Bangalore, is transferred from c&DD
Division to LH Division for NADCP Scheme.

U

cqg{{i-{fr.

(Madhusudanan V. K,)

qq-( qHd (qT{ds{+-R)
Under Secretary to the Government of India
({Ulrlfreb : 23382779

Distribution :1.

PS to Honble Minister, FAHD.

2.

PS to Honble MOS (SKB), FAHD.

Sr. PPS to Secretary (AHD).
.+.
Officers concerned.
q
PPS to SS&FA.
6. PPS/PS to AHC/JS (oPcy JS(Vly IS(UByIS(GNS).
7. us (LH)/ US (NLM)
providing Hindi version.
8. Casn/CooralnitionSection/ DDO / Hindi Section for
q Admn.II/ Vigilance/ RTI Sections'
NIC, DAHD for updating the website of the Department'
11. Guard File/ Spare CoPies.
3.

uo

1 \,-
