---
doc_id: "30db3b3bb3b4ee9c"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/b9e84c9299dcc219c104a285aa959a43.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "93 2022-09-13 Roadmap for Web Portal Integration"
date: "2022-08-13"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fdafc34d43022227"
---

<!-- page 1 -->

File No. 8-22/2021-IT-II
Government of India
Ministry of Communications
Department of Telecommunications

** ***
Sanchar Bhawan, New Delhi
Dated the 13.09.2022
Subject: Integration of various Web-Portals of DoT- Roadmap for implementation

The matter regarding Integration of existing Web-Portals (Saral Sanchar, SARAS,
TARANG Sanchar, MTCTE, CEIR, TAFCOP, RFCoverage, etc.) of DoT is being pressed
upon by Secretary DoT from quite sometimes so that databases of these applications can be
linked/updated and availability of real-time reports/information for public or industry
consumption can be made available. This was discussed during the meeting chaired by
Secretary on 10 111 Nov 2021 , 211 d Dec 2021 and 05 111 Jan 2022. During the last meeting, it was
devised that a DOT Dashboard of Dashboards (DoD) may be prepared with feeds from all DOT
portals and there will be two versions of the DoD - a Public DoD for Citizens including
businesses, and other DOD for Internal Users only.
2.
IT Wing, in association with the NIC has created a number of dashboard tiles and
progressing as per data submitted by the various divisions. It is expected that, the new version
of Dashboard Application will be rolled out by NIC during Sept/Oct 2022. The new version
will have the feature to present figures on the basis of License Areas or States. The Drill down
facility till the level of last demographic entity will be available.
3.
IT Wing is also working to introduce a small dashboard on the homepage of the DoT
Website. The Do T Website will host about 16 most imp01iant KP Is of the Depaiiment in its
Native Dashboard. The Dashboard Tiles in the DoT Website will be either linked to DoT
Dashboard or the Individual Web p011als.
4.
As for as the action plan regarding integration of various Web-Portals, DoT Website
with DoT Dashboard and DoT Dashboard with various Web-Portals is concerned the following
is proposed:
a. Integration of various Web-Portals: DoT has many Web-Portals but these have been
developed in standalone mode by various units/wings. At present these portals have an
autonomous authentication system, role management, unique process flow, rigid data
structure, follows very odd color themes, have a nonstandard menu system and hardly
comply to the STQC and GIGW framework. Open access to the dashboard/various kind
of reports which may be useful to the public, students, Government Agencies etc. is
hard to figure out. The absence of native dashboard deprives the Depai1ment to
showcase its achievements. Possibility for integration of the various web-portals,
optimization of datasets, identification of KPis, GIS implementation, integration with
SMS and eMail Gateways, Aadhaar based authentication, Digital Signing Services,
Payment Gateway etc. along with API-based integration with DoT Dashboard needs to
be explored.

<!-- page 2 -->

b. Integration of DoT Website with DoT Dashboard: It has already been decided that
16 imp01iant KPIS will be displayed in a Native Dashboard interface on the home page
of the Depaiiment's Website. The same has already been tested in a development server
and proposed to be made live. Initially, the Dashbomd tiles will be populated manually
and an API-based integration between DoT Website and DoT Dashboard/Web Portals
would be explored.
c. Integration ofDoT Dashboard with various Web-Portals: Initially, DoT Dashboard
had 25 tiles with 92 KPis. Now the count of total tiles has increased to 40 and many
more tiles are still proposed for creation. Out of these tiles, periodic data for only 4 tiles
is received in an automated manner. For the rest of the tiles, periodic data is entered
manually as per the predefined periodicity. Possible integration with various Portal
needs to be explored.
5.
Accordingly, the following instructions/guidelines may be considered for smooth and
early implementation:
a. The look and feel of all web-p01ial should be similar so that users feelings of being at
DoT Domain shall remain.
b. Chatbots and other advanced features may be developed for public-centric applications.
c. On the home page, these po1ials shall have links to various portals ofDoT and important
portals of Gol.
d. For Web-hosting, secure cloud-based servers, including DR sites, and proper software
shall be used. Each Portal should have a proper mechanism for Load Balancing, Data
Backup, Security Audit, and compliance for all its Portals and Dashboards.
e. Integration of these portals with the LGD Data base, data.gov.in, Umang, Sandes, SMS
Gateway, eMail Gateway, Aadhaar based Authentication System, Payment Gateway,
BharatKosh, PFMS, Digi locker integration etc. shall be explored and completed on
priority.
f. Developers of these portals need to be asked to design the process/systems in such a
way to extract customized content through pluggable user interfaces through Web
services.
g. GIS shall be implemented (for Mobile Coverage and Optical Fiber Cable) for
showcasing the progress and to supp01i the decision-making.
h. In view of proposed integration between DoT Website - Web-Portals and DoT
Dashboard - WebPortals; and to project the various initiatives being undertaken by the
Depaiiment; it is required that each individual web-portal i.e. Sarai Sanchar, SARAS,
USOF, PMWANI, DoT Pension Portal," CDIS, PPP-MII, Tarang Sanchar, MTCTE,
CEIR, TAFCOP, RFCoverage, NCCS , etc. sha.11 have a NATIVE DASHBOARD like
GatiShakti Sanchar Portal or . Dashboard of Tribal Affairs Ministry
(https://dashboard.tribal.gov.in/) and shall follow the standards Codes & Protocols and
have proper reporting mechanism, adequate processing capabilities, sufficient storage
capacity, data visualization tools, etc. · Further, these systems shall be hosted in a
reliable, secure networking environment and comply with all the security protocols.
i.
These Dashboards shall be based on common technology and have features to present
the data in various slices and dices useful for decision making. It shall be kept in mind
that the data requirement of an internal user may differ from the public or a researcher
may require information in a different format or granularity and the requirement of a
Media Person may differ from other subgroups.

<!-- page 3 -->

6.
All the Divisions shall submit details of web-p01ials in the following format maintained
by them, like domain name, IP Address of Web-server & Database Server, where is it hoisted,
OS, Web-server, database, Scripting Language, who is the developer with details, etc. where
is the database stored (Main & DR) etc. to IT wing.

Name of Organization:
URL of Web Portal/Website:
Name of Registrant of Website:
Designation:
Email Id:
Contact No. (Mob/LL):
IP Address of Web IP Address of Data
Server
Base Server

Operating System
Stack

Web Server I
Software

Site Status
(Main/DR)

Website Developer
& Hosting details

Data Base Server I
Software

Scripting Language

7. This is issued with the approval of DDG(IT)

To,
Website Registrants in DoT, As per the list

Copy to:
1. PSO to Secretary(T)
2. Sr. PPS to Additional Secretary(T)
3. Sr. PPS to Member(S), Member (T) & Member(F)
4. Sr. PPS to Director General (Telecom)
5. PPS to DDG (Security Assurance)
6. Sr. Technical Director, NIC-DoT

<!-- page 4 -->

Annexure
List of Website Registrants in DoT

SI.
No.

Domain Name

Project Owner
Sh. Virender Prasadd
ddgit-dot@nic.in
Sh. Y.G.S.C. Kishore Babu
Ddg.sri-dot@gov.in
Sh. Rajesh Pathak
ddgic-dot@gov.in
Sh. Tejpal Singh
dirds2-dot@nic.in
Sh. Vijay Agrawal
vijay.agrawal@gov.in
Sh. Dindayal Toshniwal
ddgnt-dot@nic.in
Sh.LB Lal
lb.lal@nic.in
Sh. Bhavesh Anil Sharma
bhavesh.anils@gov.in
Accounts
suwort.pfms-dot@gov.in
Ms.AB Divya
adglf3.hq-dot@nic.in
Ms. Santosh Choudhary
santosh.choudhary90@gov.in
Sh. Sahil Garg
dyadmnfinl.hq-dot@gov.in
Sh. Taranjeet Singh
taranjeet.singh30@gov.in
Sh. Neeraj Kumar
neeraj@gov.in
Sh. Neeraj Kumar
neeraj@gov.in

1

https: ,Udot.gov.inL

2

http://dcis.dot.gov.in/

3

http://india6g.dot.gov.in/

4

https://ocbms.dot.gov.in

5

https://www.ceir.gov.in/

6

https://saralsanchar.gov.in/

7

http://sancharvhr.gov.in

8

https://www.saras.gov.in/

9

https://dotpension.gov.in/

10

https://dotrevenue.gov.in/

11

https://www.cgca.gov.in/

12

http://usof.gov.in/

13

http://esankalan.dot.gov.in

14

http://sugamsanchar.gov.in/

15

http://gatishaktisanchar.gov.in/

16

www.tec.gov.in

srddg.tec@gov.in

17

https:/Lwww.mtcte.tec.gov.in/

18

https://tarangsanchar.gov.in

19
20

https://tafcop.d_gtelecom.gov.in/
https:/_Lrfcovera_ge.dot.gov.in/

21

https://pmwani.gov.in/

22

https://nccs.gov.in

23

http://www.ntiprit.gov.in/

24

http://www.nicf.gov.in/

SrTEC
Sh. Jaipal Singh Tamar
dir_g.hq-dgt-dot@gov.in
DGT
DGT
Sh. Ashok Kumar Jain
dirds3-dot@nic.in
Ms. P Radhika
directorha.nccs-dotCal1rnv.in
Sh. Sandeep Bhardwaj
sandeep.bhardwaj@gov.in
Sh. Devendra Kumar Nim
devendrakumar.nim@gov.in

Designation
DDG(IT)
DDG(SRI)
DDG(IC)
011-23717542
Director(DS-11)
011-23036860
Director(UDS)
DDG(NT)
Director
011-23372722
ACAO(LFA-11)
011-23372193

ACAO
Dy Adminiatrator
Dy. CGCA(BA&IT)
DDG(BBM)
011-237461411
DDG(BBM)
011-23746141
Sr. DDG
011-23320252
Director

Director
Director
Director
