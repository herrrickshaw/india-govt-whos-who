---
doc_id: "0107b4bd28fafedb"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/d608ec14d57445d4b5d2dfcfbe2945a7.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & Posting of officers in JAG of ITS Group A - reg"
date: "2025-01-03"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d33be64cf33dbfb8"
---

<!-- page 1 -->

12-2/2024-STG-I

I/3210952/2024

No. 12-2/2024-STG-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
Dated the 17th September, 2024
OFFICE ORDER
Subject: - Transfer & Posting of officers in JAG of ITS Group ‘A’ - reg.
Approval of the competent authority is hereby conveyed for transfer &
posting of the following oﬃcers in the grade of JAG of ITS Group ‘A’, with
immediate effect:
S.No.

Staff
No.

Name of the Present Place Posting on Transfer
officer (Shri/Ms) of Posting

1.

21026

Gajendra Singh

Under Posting

DGT HQs

2.

21013

Laxmi

DoT HQs

TEC

3.

21164

Ganesh Chandra

Under posting

SE Division, DoT HQ
till
31.10.2024.
Thereafter
in
PG
Division, DoT HQs
w.e.f. 01.11.2024

4.

21277

Robin
Lakhanpal

Kumar DGT Hqs

USOF

2.
The oﬃcer at S. No. 1 i.e., Shri Gajendra Singh has reported to DoT HQs on
27.08.2024(F/N). The period between 27.08.2024 and the date of issuance of this
order may be treated as "compulsory wait" and the pay & allowances for the said
period be paid by DGT HQs.
3.
follow.

The charge report may be furnished to all concerned. Hindi version will

(Bijender Singh)
Under Secretary to the Government of India
Tele 011-2303 6282
Email: bijender.s83@gov.in
Copy to:
1. Chairman, DCC/Member(S)/Member(T)/Member(F)/DG(Telecom), DoT;
2. AS(T)/ Administrator USoF / All Advisors, DoT;

<!-- page 2 -->

12-2/2024-STG-I

I/3210952/2024

3. CMD, BSNL CO.;
4. CVO, DoT HQs;
5. All Sr. DDGs/DDGs DoT HQs;
6. DDG (C&A), DoT HQs;
7. Admn.I-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.I Sec., DoT HQs;
8. Pay Bill Section, DoT HQs;
9. US (SNG)/ADG (APAR)/AD (STG-1)/AAO (STG-I), DoT HQs;
10. The Officer concerned;
11. Official Language Section, DoT for Hindi version of the order;
12. Order Bundle/PA to US(SGT) for uploading this order on DoT website.
