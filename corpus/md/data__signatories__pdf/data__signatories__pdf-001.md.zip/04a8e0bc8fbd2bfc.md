---
doc_id: "04a8e0bc8fbd2bfc"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/6bb73864d4857ae28b9706f0f8c33546.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '105902' to Military Hospital, Jaipur"
date: "2019-12-04"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f3bcbeaa7213977"
---

<!-- page 1 -->

File No.16-1/2017-AS-lll/ShortCodes

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No.16-1/2017/AS-III/Short codes/3011 /93 I

J

Dated.: (J/1­
.;-~ /12/2019

To,
All Access Service Providers.
Subject: Allotment of short code '105902' to Military Hospital, Jaipur.
The undersigned is directed to convey the approval for allocation of short code
'105902' to Military Hospital, Jaipur for emergency contact with features as:

,.

(i) Category-I: Service (i.e. mandatory service to be provided by all the Access
providers.
(ii) Accessibility: Restricted i.e. within Jaipur District service area.
(iii) Metered service: (It may be taken as Called Party Pays or Calling Party Pays
s "
·'
~pending on intimatic;m, to this effect, issued by the agency to which this short
code is allocated in furtherance to this DoT instruction).

t

I, .

! ,.·

I,

\, -

2.

The short code '105902' has to be mapped on 0141-2249199.

3.

All are requested to take necessary action.

4.

This is issued with the approval ofDDG (AS).

1, .­

. \'1---\0'°\'1

f)/J\, ''

(Sane "t mar Garg)
ADG (AS-III)
Tel.:011-23372725
Copy forwarded for information and necessary actio°r, if any, to:
1.
Secretary, TRAI.
2.
CMD MTNL/ CMD BSNL.
3.
Shri Saurabh Singh, Maj, Officer Commanding Communication for Commanding
Officer, South Western Command Signal Regiment, Pin-901252, Clo 56 APO w.r.t. letter
No. 1505/06/Sigs/BSNL dt. 22.11.201,9 with a request to appoint a nodal officer to
implement the helpline. Th·e Nodal officer may contact Sr. DDG (LSA), LSA Unit,
concerned States/UTs.
4.
Director (P&N), DoT (HQ), (respective LSA field unit may be asked to co-ordinate
with respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).
5.
A copy for upload on DoT Website.
