---
doc_id: "03bd02dadad7bd93"
source_url: "https://www.labour.gov.in/static/uploads/2026/02/e4f93224ec345bc1a512f699c24e8843.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Filling up of one post of Manager-cum-Accountant (Group 'B' post, Non- Gazetted, Non-Ministerial) through Composite Method [Deputation (including short- term contract) plus Promotion] at Level-6 in the Pay Matrix (Rs. 35,400–1,12,400) – regarding."
date: "2026-02-06"
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5f25604a0b47fe91"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

F No. 73/09/2014-Admn.I

[E-741]

Government of India

Ministry of Labour and Employment
Labour Bureau

Shram Bureau Bhawan,
Block No.2, Institutional Area,

Sector 38-West, Chandigarh-160036.

CIRCULAR

Dated the 01st January, 2026

Subject: Filling up of one post of Manager-cum-Accountant (Group 'B' post, Non-

Gazetted, Non-Ministerial) through Composite Method [Deputation
(including short-term contract) plus Promotion] at Level-6 in the Pay
Matrix (Rs. 35,400–1,12,400)
regarding.
–

In continuation to Labour Bureau's Circular dated 30.09.2

submission of application has been extended for 60 days.
2.

All other content of the earlier issued circular will remain

025, the last date for

the same.

(Narender Singh)
Under Secretary to the Govt. of India

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->
