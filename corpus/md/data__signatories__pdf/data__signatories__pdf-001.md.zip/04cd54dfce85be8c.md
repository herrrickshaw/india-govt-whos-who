---
doc_id: "04cd54dfce85be8c"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/44c38d0a5c429ad368e48a7a5d53c79f.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Appointment to the post of Chief Executive Officer (CEO) & Managing Director (MD), Delhi Mumbai Industrial Corridor Development Corporation (DMICDC) on deputation basis, through Search-cum-Selection Procedure"
date: "2025-07-01"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4cdbe25569abb80c"
---

<!-- page 1 -->

| No. A-12023/3/2015-E.1
Government of India
Ministry of Commerce & Industry
Department of Industrial Policy and Promotion
— Udyog Bhawan, New Delhi
Dated the 30" April, 2015
To
1. The Chief Secretaries, All the State Governments/UTs
2. The Secretaries, All the Ministries/Departments of the Government of India
Subject : Appointment to the post of Chief Executive Officer(CEO) & Managing Director
(MD), Delhi Mumbai Industrial Corridor Development Corporation (DMICDC)
on deputation basis, through Search-cum-Selection Procedure.
Sir/Madam,

It is proposed to fill up the post of Chief Executive Officer (CEO) & Managing
Director(MD), Delhi Mumbai Industrial Corridor Development Corporation (DMICDC) under the
Department of Industrial Policy & Promotion, Ministry of Commerce and Industry, in the pay band
of Rs.37,400-67,000 (PB-4) and grade pay of Rs.10,000/- on deputation basis, initially for a period
of three years, extendable by another two years, through Search-cum-Selection Committee.

2. DMICDC is a company covered under Section 619B of the erstwhile Companies Act, 1956.
Delhi-Mumbai Industrial Corridor (DMIC) is India's ambitious Infrastructure programme aiming to
develop new industrial cities as ‘Smart Cities' and converging next generation technologies across
infrastructure sectors. The objective is to expand India's manufacturing and service base and develop
DMIC as a "Global Manufacturing and Trading Hub". CEO & MD is the chief executive of
DMICDC having been entrusted with substantial powers of management subject to superintendence,
control and directions of the Government of India and Board of DMICDC. The candidates for the
assignment shall be of Joint Secretary level from All India Services or Central Services with
experience in  Industries/Commerce/Infrastructure Development/Public Private _ partnership/
Management. The term of deputation shall be akin to deputation terms to other Government
organization under Rule 6 (i) of the IAS cadre rules. The selected officer will be allowed requisite
exemptions in the matter of empanelment, cooling off requirement before appointment, housing and
CGHS facilities. The ACRs pertaining to the officer will be written and reviewed by Secretary, DIPP
and accepted by the Minister for Commerce & Industry.

Contd...

<!-- page 2 -->

2.
3. It is Tequested that this may be circulated among all the eligible officers in the
Ministries/Departments, States/UTs and nominations of eligible and willing candidates may be
forwarded in the enclosed proforma to this Department through proper channel and addressed to the
undersigned, within 20 days from the date Of issue of this vacancy circular along with the complete
ACR/APAR dossier, vigilance clearance with the certification that no disciplinary Proceedings or
criminal Proceedings are either pending or being contemplated against the officer concerned, In
addition, Integrity certificate and list of major/minor penalties, if any, imposed on the candidate
during the last ten years/No penalty certificate should also be sent,
Yours faithfully,
Encl: As above, ee
Oy 6 us
(Atul: Singh)
Director(Establishment)
Tel: 23062343

<!-- page 3 -->

Annexure I
APPLICATION FORM FOR THE POST OF CE Se FORM FOR THE POST OF CEO & MD, DMICDC
डे (To be submitted through Proper Channel)
1. (कपश्मा०्ण तप 0ीवथ: 77 कनाायययय/णय//य/या
2, ७9४० णीछी0___ _ न या
3. Qualification :
4. Service and Batch to which belongs: .
(a) Post presently held on regular basis:
(b) Scale of pay:
(c) Date since when holding the post:
(d) Date of expiry of deputation/tenure (If applicable):
5. Office Address +
6. Address for communication.
7. Telephone No: Office Residence. FAX No.
Mobile No. E-Mail address
8. Positions held during the preceding ten years :-
[_ ट टफ$ _फह
_
[}_ $$ नस]
[or
Js यणए
oo
हि पर  ल्‍$&$न्नन [Od
9. Details of experience relevant for the post:
SINo. | Designation, and place of Organization From To Pay scale | Nature of
stin: experience
poe ्ट् फ /एण
[oo विन नल
a [fd
10. (a) Whether any punishment awarded to the applicant during the last 10 years Yes [४० |

<!-- page 4 -->

If yes, the details thereof

10.(b) Whether any action or inquiry is going on against applicant: Yes | vo |
If yes, the details thereof:

11. I certify that the details furnished above are true and I am eligible for the post.

12. I further submit my willingness that I will join the post, if selected.

Date: (Name and Signature of the applicant)
(To be filled by the Cadre Controlling Authority/Ministry/Department/State/UT Government
concerned)

It is certified that the particulars furnished above have been scrutinized and found to be correct as per official
records. In case the officer is selected, he/she will be relieved immediately of his duties in this Department to

join the aforesaid post.
Signature , Name & Designation of the competent Forwarding
Authority with Telephone no. & office Seal.
