---
doc_id: "02cbbd48abd4ba1c"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/2026000888_16072026.pdf"
ministry: "Department of Space"
title: "URSC/PUBLIC-TENDER-NOTICE-NO-D-102/2026 Dated: 16.07.2026      347.29 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "01e39c06b1b66426"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष तवभाग /Government of India, Department of Space
यू.आर. राव उपग्रह केन्द्र (यू.आर.एस.सी.)/ U R Rao Satellite Centre [URSC]
(पूवि में इसरो उपग्रह केन्द्र/ (Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरपोटि रोड, तवमानपुरा पोस्ट,
HAL Airport Road, Vimanapura Post,
बेंगिूरु/Bengaluru - 560 017

यू.आर.एस.सी. URSC/ सार्वजनिक निनर्दा सूचिा सं PUBLIC TENDER NOTICE NO. D-102/2026

16.07.2026

भारत के राष्ट्रपतत की ओर से व. प्रधान, क्रय एवं भंडार, यू.आर. राव उपग्रह केन्द्र(यू.आर.एस.सी.),द्वारा तनम्न तिखित
मद की आपूतति के तिए केवि ई-प्रापण के जररए तनतवदाएं आमंतित हैं
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC]
Invites tenders ONLY through e-procurement for supply of the following.
एकल भाग निनर्दा/ Single Part Tender
क्र.सं.
Sl. No.

01

निनर्दा संदभव
TENDER REFERENCE

URSC/CE/IS202600088801

संनिप्त नर्र्रण
BRIEF DESCRIPTION
लोड कैप्स पर तिार् मापी उपकरणों (स्ट्रे ि गेज) को
जोड़िा और उिका परीिण करिा
BONDING AND TESTING OF STRAIN GAUGES ON
LOAD CAPS

बोिी प्रस्तुत करने की प्रारं तभक ततति/Bid Submission Start Date : 16.07.2026 (16.30 Hrs.)
बोिी स्पष्ट्ीकरण की ततति /Bid Clarification Date up to

: 28.07.2026 (14.00 Hrs.)

बोिी प्रस्तुत करने की तनयत ततति/Bid Submission Due Date

: 06.08.2026 (14.00 Hrs.)

बोिी िुिने की ततति/Bid Opening Date

: 06.08.2026 (14.30 Hrs.)

वैध तडतजटि हस्ताक्षर प्रमाणपि (डी.एस.सी) रिनेवािे इच्छु क तनतवदाकार https://eproc.isro.gov.in पर िॉग-इन
करके अपना प्रस्ताव ऑनिाईन भेज सकते हैं। कोई तनतवदा शुल्क िागू नहीं है ।
Interested Tenderers having valid Digital Signature Certificate [DSC]
https://eproc.isro.gov.in and submit Offers online. No Tender fees applicable.

may

login

to

तनतवदाएँ उपयुिक्त तवतनतदि ष्ट् ततति पर िोिी जाएँ गी। पाि तवक्रेताओं की दर बोिी (दो-भाग तनतवदाओं के मामिे में)
िुिने की समय सूची बाद में सूतचत की जाएगी। बोिी-संबंधी तववरण प्रततभागी तवक्रेताओं द्वारा इसरो ई-प्रापण पोटि ि
पर िॉग-इन करके दे िे जा सकते हैं ।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in case
of Two-Part Tenders) of Qualified Vendors will be intimated later. Bidding details can be seen by
the participated vendors by logging into ISRO e-procurement portal.
उपयुिक्त के संबंध में यतद कोई शुखददपि/अनुशेष होगा, तो उसे हमारे ई-पोटि ि एवं वेबसाइट पर प्रकातशत तकया जाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and Website.

Sd/र्. प्रधाि, क्रय र् भंडार / Sr. Head, Purchase & Stores
