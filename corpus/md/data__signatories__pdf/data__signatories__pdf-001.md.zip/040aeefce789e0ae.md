---
doc_id: "040aeefce789e0ae"
source_url: "https://www.mea.gov.in/images/pdf/Scan_19_10_2020_1513.pdf"
ministry: "External Affairs (MEA)"
title: "Vacancy circular for the post of Director on deputation basis in MEA"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "99afe67992acc915"
---

<!-- page 1 -->

No. Q/PA.III/575/17/2015
Ministry of External Affairs
(Administration Division)
New Delhi, 19 October, 2020
VACANCY CIRCULAR
Subject: Filling up of the post of Director on deputation basis in Ministry of External Affairs.
Applications in the prescribed pro-forma (as per Annexure of the advertisement) are invited from eligible
officers for filling up of the post of Director on deputation basis in the Ministry of External Affairs, New
Delhi as per the details given below:
ame of the post with Pay Level Director — Level 13 of the Pay Matrix
lg
|
2. |Period of Deputation Initially for three years; could be extended as per extant rules
: | prescribed by DoPT on the subject.
3. |Age Limit |: ] The maximum age limit for appointment on deputation shall not
exceed 56 years as on 01.01.2021.
. Job Description | | a) To work in a Division, focussed on Economic issues, at the
| | MEA Headquarters, New Delhi. This may include temporary
| deputation on foreign tours as part of ongoing duties at New
1: | Delhi. |
5. Eligibility/Essential Criteria | | a) Group ‘A’ Officers of Gol preferably belonging to
| |_| IES/TS/IRS
esc]
| b) Officers should have good managerial and interpersonal
| skills. |
| | c) Officers should be able to liaise effectively with other
| | organizations/Department/Ministries/Think Tanks/ Chambers of
| | Commerce & Industry.
\ |
| d) Officers should have good noting and drafting skills and
| communication ability. |
| |
| || |
| | e) Officers should have served as Director or equivalent level in |
| Ministries / Departments / Attached / Subordinate Offices in the |
| Government of India. |
feet |
| | |
| f) Officers belonging to Organized Group ‘A’ Services of the |
| | Government of India, preferably belonging to IES/ITS/IRS of |
| | the rank Of Deputy Secretary, who have completed minimum |
| | Qualifying Service in their respective cadres for promotion to
| the rank of Director may also apply. | |
6. Desirable Criteria | a) Previous experience of handling issues relating to | |
| | | International Cooperation/ Foreign Trade/ Energy Security/ | |
| | ae Multilateral Organizations in GOI/ Chambers of
| Commerce and Industry.
| |
| : | b) Knowledge of Foreign Languages, if any
|

<!-- page 2 -->

c) Degree in Economics, International Relations or in any other
subject which may have a direct bearing on Economic
Diplomacy.
7. |How to apply : | Completed application should be sent through proper channel in
the prescribed pro-forma to Joint Secretary (Administration),
| | | Ministry of External Affairs, Room No.149C, South Block,
| | | New Delhi. The duly completed application should be sent
| | | along with:
| a) Up-to-date copies of ACRs/APARs for the last five years
| duly attested on each page by a Group A Officer.
| | b) Cadre clearance
| |
| | c) Vigilance Clearance
| d) Details of minor/major penalty imposed on the officer by the
| Competent Authority for the last 10 years, if any.
|
|e) Statement of Bio-data in the prescribed pro-forma (as per
| Annexure) in duplicate copy signed by the volunteering officer
| and forwarded through proper channel.
8. [Pay & Allowances | Admissible as per guidelines of Department of Personnel and
| : | Training’s O.M. No. 6/8/2009-Estt. (Pay II) dated 17.06.2010
| | amended from time to time.
9. [Foreign Travel : | The selected officer ee का | be required to travel within India and
abroad.
Note: Jt would be mandatory to serve the deputation term and premature relieving would not be
* considered except in rare or exceptional circumstances.
2s Applications of interested and eligible officers may be forwarded latest by 20 November 2020.
Cadre Controlling Authorities are requested that the applications of only those officers are forwarded
who can be spared on being selected. Any queries regarding the application may be addressed to Ms.
Soumya Gupta, Under Secretary (PA-III) at uscadre@mea.gov.in.
Li 2
(L. RAMESH BABU)
Director (ADP)
Ministry of External Affairs
Room No. 4095, B Wing,
Jawaharlal Nehru Bhawan,
Janpath, New Delhi.
Tel: 49015363
Enclosure: Pro-forma
To:
1६ All Ministries/Departments of Central Government — with a request to circulate the vacancy to
their entire field sources including attached/subordinate offices.
2. All Notice Boards in the Ministry of External Affairs.
35 XP Division (for uploading the circular on MEA website).

<!-- page 3 -->

Annexure
APPLICATION PROFORMA FOR THE POST OF UNDER SECRETARY / DEPUTY
SECRETARY IN THE MINISTRY OF EXTERNAL AFFAIRS (ON DEPUTATION)
1. Name & Designation:
25 Date of Birth:
3: Gender:
4. Educational Qualifications:
Ds Mobile No.:
6. E-mail ID:
ie Service/Batch: <
8. Details of employment in the chronological order. Enclose a separate sheet duly authenticated
by the Department, if space below is insufficient.
मा = Peel From To = Scale of Pay and Nature
Institution/ | | basic therein _ performed
Otganiat one seals! ot eee [eee Se ig यम eka
| |
| | |
| | |
| |
9. Details of current employment;
10... Basic Pay, Pay Scale & Grade Pay:

<!-- page 4 -->

I. Details of courses/training programmes attended, if any:
12. Details of publication, if any:
13. Language known:
| 14. Details of previous ex-cadre deputation, if any:
|
15. Additional information, if any, which you would like to mention in support of your suitability
for the post. Enclose a separate sheet, if need be:
16. Remarks:
(Signature of candidate)
Address:
Date:

It is certified that particulars furnished are correct and no disciplinary case is either pending or
contemplated against the officer and no penalty, major or minor, was imposed on the officer during the
last 10 years and his integrity is beyond doubt. कै

Signature of the Head of Department
(with stamp)
