---
doc_id: "051aaa9cb9dcbca6"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/d57eee900554f776f358e2174083a2de.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer and Posting of P and T BWS Group A Electrical Wing order dated 08 December 2022"
date: "2022-12-08"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "66ef96155d98691c"
---

<!-- page 1 -->

F.No.6-1/2014-EW
Ministry of Communications
Department of Telecommunications
618A, Mahanagar Doorsanchar Bhawan,
J.L.Nehru Marg, New Delhi-110002
10 W'Dec. 2022

ORDER
Subject: Transfer and Posting of Electrical Wing P & T Building Works Group 'A'-reg.

The following transfers and postings of P&T Building Works Group 'A' Service (Electrical)
officers in JAG is hereby ordered with immediate effect and until further orders :­

S.
No.

Name of the officer
(Sh./Mrs)
and staff
no.

Present Posting

Recommended
Posting

Remarks

1

Dinesh Sharma 96510

TEC, New Delhi

UP(W) LSA

Vice Sh. Sanjay Gupta

2

Kuljeet Kaur 96517

Punjab LSA

Haryana LSA

Vice Mr. Amar Relan

3

S.K. Mehra 96525

Delhi LSA

Punjab LSA

Vice Mrs. Kuljeet kaur

4

Amar Relan 96529

Haryana LSA

DoT HQ,
DDG(Estt.)

5

Sanjay Gupta 96532

UP(W), LSA

DoT HQ 0/0 Sr.
DDG(BW)

6

Musaphir Ram96534

DoT HQ

J&K LSA

Against vacant post

7

Arun Dwivedi 96538

MP LSA

Delhi LSA

Vice Mr.SK Mehra

8

Birendra Kumar 96551

Bihar LSA

W est Bengal LSA

Against vacant post

9

Arun Kumar Negi
96557

HP LSA

MP LSA

Vice Mr. Arun Dwivedi

10

A.K. Singh, 96564

Awaiting posting

TEC

Vice Mr. Dinesh Sharma

11

Mukesh Wadhwa
96577

Awaiting posting

Assam LSA

Against vacant post

2.

Charge reports may be furnished to the all concerned.

3.

This issues with the approval of competent authority.

O/o

Against
Sanjay
Shri
Khare already relieved.
Vice Mr. Musaphir Ram

\~~

Sharm~
I

(Dinesh
Director (Electrical)
Ph. 23218925

I')_

<!-- page 2 -->

To,
1.

PPS to Member (S)

2.
3.
4.
5.
6.
7.
8.

LSA head UP(W)/Haryana/Punjab/Delhi/MP/Bihar/HP
PS to DG Telecon/ Sr. DDG(BW)/ Sr. DDG(TEC)/ JA(Admn)/DDG(Elect.)/DDG(Estt.)
CS to Advisor HRD, DoT
Director(EW), DoT with a request to upload this order in DoT website.
OL Section for Hind i version.
Officers concerned.
Order Bundle.
