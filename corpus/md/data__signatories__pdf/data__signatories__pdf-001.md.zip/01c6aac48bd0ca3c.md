---
doc_id: "01c6aac48bd0ca3c"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/5d4c445f4abcb8d845981749ee5ab313.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Modifications / corrections in r/o six Advocates for courts/tribunal at Delhi: Order dated 08.03.2019"
date: "2019-03-08"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4d98b8b6ba601f93"
---

<!-- page 1 -->

F. No. J-11017/22/2018-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
hee
Shastri Bhawan, New Delhi,
Dated 8" March, 2019
ORDER
With reference to this Department's earlier Order No. J-11017/22/2018-
Judicial dated 18.12.2018 regarding panel of counsel for various courts / tribunals in
Delhi, the personal details viz. name etc. stand modified / corrected in respect of the
following six panel counsel who figure in the aforesaid order dated 18.12.2018, as
shown under column ‘V’ in the table below:
SI. | Name of the Name of court / Corresponding Name to be modified
No. | Counsel tribunal and Serial No. in the | / corrected as
(as per said order | category of panel | said Order dated | (with some
dated18.12.2018) | engaged for 18.12.2018 additional details)
‘S/Shri ee a I
| || IV Vv
1. | Vanish Singh High Court of | 181 (List ‘B’) AVNISH SINGH
Delhi
As Senior Panel ( Enrl. No.
Counsel UP/233/2006 &
Mob: 8826437138)
2; Nitesh Anand Patiala House | 41 (List ‘J’) NITESH ANAN
District Courts as
Additional Central (Enrl. No.
Govt. Counsel D/86/2010 &
Mob: 9013226679) |
3. Pushpinder High Court of | 164 (List ‘B’) | PUSHPINDER
Kumar Delhi as Senior KUMAR YADAV |
Panel Counsel |
(Enrl.No. |
D/1070/1991)
4. Rahul Jain High Court of | 57 (List ‘C’) RAJUL JAIN |
Delhi as
Government Enrl. No. |
| | Pleader D/2791/2013) |
=i Lk —

<!-- page 2 -->

5. i) Umeshwar i) High Court of | i) 180 (List ‘B’)
Delhi as Senior UMESHWAR
Panel Counsel SRIVASTAVA |
ii) U. Srivastava | ii) CAT (PB), New | ii) 33 (List ‘D’) (Enrl. No. |
Delhi as Senior D/384-A/1991)
(Both names are | Panel Counsel
of same person)
6. | Aashtha Jain High Court of | 18 (List ‘B’) AASTHA JAIN
| Dehi as Senior
Panel Counsel (Enrl. No.
D/1376/2013)
2 Except the modifications / corrections as shown under column ‘V’ in the table
above, rest of the contents of the aforesaid order dated 18.12.2018 remain same
3. Hindi version of this order will follow.
ae
(S. R. Mishra)
Additional Secretary
Copy for information to:-
1. PS to ML&J/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/All Additional
Secretaries/PS to all JS&LA in the Main Sectt.
2. Ms. Maninder Acharya, the Ld. ASGI, High Court of Delhi, C-390 LGF, Defence Colony, New
Delhi-110024
3. The Registrar, High Court of Delhi
4. The Registrar, CAT (PB), New Delhi
5. The District Judge, Patiala House District Courts.
6. The Incharge, Litigation (High Court) Section, High Court of Delhi, New Delhi
7. The Incharge, Litigation (CAT) Section, CAT (PB), New Delhi.
8. The Incharge, Litigation (Lower Court) Section, Tis Hazari Courts, Delhi. |
9. The Pay & Accounts Officer, Department of Legal Affairs, New Delhi
10. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
11. For uploading on website of this Department i.e. www.legalaffairs.gov.in for the information of |
all concerned
12. Guard File/Judicial Section with 5 spare copies.
>i
——_—_
(D. Srinivas)
Section Officer (Judicial)
Tel.011-23384945
Email: judicial-dla@nic.in
=2=
