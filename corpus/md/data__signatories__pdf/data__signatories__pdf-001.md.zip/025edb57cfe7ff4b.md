---
doc_id: "025edb57cfe7ff4b"
source_url: "http://www.moef.gov.in/uploads/pdf-uploads/pdf_68bea679029229.92134485.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "Office Order - Shri Ramesh Kumar Pandey, IFS, ADGF is assigned the additional charge of NAEB GIM SU FPD EAP Desertification Cell and FC divisions, order dated 02-07-2025"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ff97933a0936281b"
---

<!-- page 1 -->

i
: No. 12026/07/2024-IFS-I [E.253225]
Government of India |
Ministry of Environment, Forest and Climate Change |
“bane
: 6th Floor, Prithivi Wing,
Indira Paryavaran Bhawan,
Jor Bagh Road, New Delhi-110003.
Dated, the 2nd July, 2025 |
OFFICE ORDER |
|
1
Shri Ramesh Kumar Pandey, IFS, ADGF is. assigned the works of NAEB/GIM, SU, i
FPD, EAP, Desertification Cell and Forest Conservation divisions, in addition to the |
existing works assigned to him with immediate effect, until further orders. |
॥
2. This issues with the approval of the Competent Authority. |
|
|
|
ower ae |
(Prem Prakash Maurya) /
Under Secretary to the Government of India '
Tel: 011-20819192 i
Distribution: |
1. PS to Hon'ble Minister of Environment, Forests and Climate Change; |
2. PS to Hon'ble Minister of State Environment, Forests and Climate Change;
3. PPS to Secretary, MoEF& CC; |
4. PPSs to DGF & SS/ADGF(WL)/ ADGF(FC)/ ADGF(PT); गे
5. PSs to All IGFs/JSs/Jt. CEO(CAMPA)/DG(FSI);
6. JS(Admin), MoEFCC, New Delhi;
7. All DIGFs/AIGFs; I
8. Concerned officers; '
9. All Regional Offices/RO(HQ);
10. NIC cell for uploading on IFS website and IT Cell for uploading on MoEF&CC
website; :
11. Reference Folder
|
|
|
|
|
|
|
|
