---
doc_id: "043bdad1cda560ec"
source_url: "https://www.dot.gov.in/static/uploads/2026/04/2976988a2e3661c329fa6d3c73e026f6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Engagement of Consultants for the vacant post of Steno/TA, LDC on temporary contract basis in the office of Special DGT, TN LSA, DoT"
date: "2026-04-13"
pages: 14
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "74d38eee4b504da5"
---

<!-- page 1 -->

‘ey के
ey
ee A
en
GOVERNMENT OF INDIA
MINISTRY OF COMMUNICATION
DEPARTMENT OF TELECOMMUNICATIONS
O/o Special DGT TN-LSA
Ill Floor, TN Telecom Complex
No:60, Ethiraj Salai, Chennai-600008
No. ADV/ TN LSA/ Consultant Notification/2021-22 dated 10.04.2026
Hiring of Consultant VACANCY CIRCULAR-2026- CORRIGENDUM
Sub: Engagement of Consultants for the vacant post of Steno/Telecom Assistant (TA), Lower
Division Clerk (LDC) on temporary contract basis in the office of Special DGT, Tamil Nadu LSA,
Department of Telecommunications. CORRIGENDUM - reg.
Ref: Hiring of Consultant vacancy circular no: ADV/ TN LSA/ Consultant Notification/2021-22
dated 10.04.2026
In continuation of the Consultant vacancy circular cited under reference, the following
corrigendum is hereby issued.
The Level mentioned against the Steno may be read as Level 4 Instead of Level 6.
ite क
Assist ire in-Il)
Olo ial DGT, TNLSA,
+ DoT, Chennai-600/008.
To
1. Sr. DDG (Pers.), DoT HQ, New Delhi.
2. Director (Admin), DGT HQ, New Delhi -It is requested to post the Circular on DoT website.
3. Director (Estt.), DoT HQ, New Delhi.

<!-- page 2 -->

4/10/26, 10:28 AM PDF js viewer
DV/TNLSA/ConsultantNotification/2021-22 1/3386620/20%
के
=
Government of India,
Ministry of Communications,
Department of Telecommunications,
Office of the Special Director General Telecom,
TNLSA, 3rdFloor, TNT Complex, No.60, Ethiraj Salai,
Chennai-600008
No. ADV/ TN LSA/ Consultant Notification/2021-22_____—_ dated 10.04.2026
NOTIFICATION
Subject: Engagement of Consultants for the vacant post of Steno/Telecom
Assistant (TA), Lower Division Clerk (LDC) on temporary contract
basis in the office of Special DGT, Tamil Nadu LSA, Department of
Telecommunications.

Tamil Nadu LSA, Department of Telecommunications (DoT), Ministry of
Communications, having offices at Chennai and Coimbatore proposes to engage
Consultants on purely temporary and on contract basis for a period of six months
or till regular manpower is posted, whichever is earlier as per the vacancy
mentioned below:

TN LSA Chennai & Coimbatore:

Chennai: Number of Vacancies at present: 7 (Seven)

Us Steno (level 6) -4

ii. Telecom Assistant -1

iii. Lower Division clerk (LDC) -2

Coimbatore: Number of Vacancies at present: 2 (Two)

i. Steno (level 6) -1

ii. Lower Division clerk (LDC) -1
Applications are invited from retired Government servants / retired officials of
PSUs/BSNL/MTNL or Research Organizations with adequate computer
knowledge and preferably having knowledge of DoT field unit works pertaining to
Telecom related works/ Administrative functions. The Consultants will be
engaged on short term contract basis initially for a period of six months. Based on
her / his performance and requirement of this office, the contract can be further
extended up to maximum of 6 terms of 6 months each or up to 65 years of age,
whichever is earlier.
The applicants may indicate their willingness and preferences to work at Chennai
office and / Coimbatore Office of Tamil Nadu LSA, for consideration by
appropriate authority and due empanelment with a validity period of 6
months. The engagement of Consultants from the empaneled list will be issued
by this office, for the vacancies / future vacancies of posts arising at Chennai and
Coimbatore unit, are remain valid for 6 months from the date of approval of
Competent Authority.

https://dot.eoffice.qov. in/efile/#/draft/|000D0T0003554324/view?source=F ILE &documentld=FO00D0T0000121303&viewParam=evJkb2N1bWVu. 4/13

<!-- page 3 -->

4/10/26, 10:28 AM PDF js viewer
)V/INLSA/ConsultantNotification 2021-22 1/3386620/20i

O/o the Special Director General Telecom, TN LSA, Department of
Telecommunications, Chennai, reserves the right to accept or reject in part or in
full any or all the responses received vide this notification without assigning
reasons whatsoever.

Application form for the post of consultant on contract basis is as at Annexure-A.
Last date for submission of application is 30.4.2026 Applications received after
due date will not be considered.

1. Nature of Duties of TA: -

> Telecom Assistant: -

Work may be assigned in any of the following verticals of the LSA:

a) Service Compliance- CAF Audit, POS inspections, Bulk customer
inspections, EMR Audit, Service Testing, Roll our Obligations, EMR
Awareness Workshops, MNP complaints etc.

b) Technology- Inspections of Licensee Network, PM WANI Implementation,
Issues of ISP Licenses, Monitoring of FTTH Connections of all Licensees,
Mandatory Testing and certification of Telecom Equipment (MTCTE),
Secured dedicated communication network, Time Synchronization of
Telecom Networks, Trusted Telecom Portal, Disaster Technology
Management, etc.

c) Rural- Rural connectivity for DBT, verification of USO sites, RF coverage
testing/telecom connectivity checking, works related to National
Broadband Mission including interactions with State Govt/UT regarding
RoW clearances/ RoW Portal, Meetings with Public representatives, etc.

d) Admin, Legal, PG & Vigilance- DDO works, Pay and Accounts related
works, Budget related works, PG, RTI, Building, Vigilance, Court cases &
Misc., Handling of all Admin correspondences, social media, Coordination
works, Implementation of Official Language Related works etc.

e) Security-Operation and Maintenance of CMS/ IMS, curbing illegal
activities/ Control over clandestine / illegal operation of telecom networks,
Analysis of CDR/SDR and other security activity assigned from time to
time etc. 5

>» Nature of Duties for Steno: -

Working on a computer, working on both physical and IT related files.
Working on various tools of MS Office suites, drafting/ Noting skills and
general office administration etc.

~ Nature of Duties for Lower Division Clerk (LDC): -

Working on various clerical related works, working on both physical and IT
related files. Working on various tools of MS Office suites, drafting/Noting
skills and general office administration etc.
https://dot.eoffice. qov.in/efile/#/draft/I000D0T0003554324/view?source=FILE&documentld=FO00DOT0000121303&viewParam=eyJkb2N1bWVu. 213

<!-- page 4 -->

4/10/26, 10:28 AM PDF.js viewer
DV/TNLSA/ConsultantNotification/ 2021-22 1/3386620/20

2. Period of Engagement: -
Engagement will be purely on a short-term contract basis. The initial
engagement would be for a period of six months, which may be extended
further up to a maximum of 6(six) terms of 6(six) months each or up to 65
years of age whichever is earlier depending upon the requirement of
O/o Special DGT, TN LSA and the performance of the contract appointee.
The engagement can be cancelled any time by Special DGT, TN LSA
without assigning any reason.

3. Eligibility: -

a. For consultant in TA level - Retired TA or equivalent or above rank from
DoT or any other central/State Govt or Retired from CDA Scale with
minimum substantive grade of Level 5 of the 7th CPC or equivalent IDA
Scale or holding analogous post of Government/PSU/Research
Organizations.

b. For consultant in Steno level - Retired Steno or equivalent or above
tank from DoT or any other central/State Govt or Retired from CDA Scale
with minimum substantive grade of Level 4/level5/Level 6 of the 7th CPC
or equivalent IDA Scale or holding analogous post of
Governmenv/PSU/Research Organizations.

c. For consultant in LDC level - Retired LDC or equivalent or above rank
from DoT or any other central/State Govt or Retired from CDA Scale with
minimum substantive grade of Level 2 of the 7th CPC or equivalent IDA
Scale or holding analogous post of Government/PSU/Research
Organizations.

The applicant should be well aware with the functioning of Central
Government Departments/Ministries and aware of various rules and
regulations of the Central Government. z
Preference will be given to applicants from DoT/BSNL/MTNL background.
4. Age Limit
Candidate should not be more than 64 years of age on the last day of date of
application ‘
5. Remuneration: -
I Fixed monthly remuneration shall be regulated in accordance with the
Department of Expenditure F No.3-25/2020-E. IIIA dated 09.12.2020 and
DoT HQ Letter No. 3-10/2014-SEA-I/Fin. dated 29.03.2022 and as
amended from time to time. The amount of remuneration so fixed shall
remain unchanged for the term of contract. The payment will be made
on monthly basis.
https://dot.eoffice.qov.in/efile/#/draft/|000D0T0003554324/view?source=FILE&documentld=F O00DOT0000121303&viewParam=eyJkb2N 1 bWVu. 3/3

<!-- page 5 -->

4/10/26, 10:28 AM PDF js viewer
09 NLSA/ConsultantNotification/ 2021-22 1/73386620/20;

॥. In case of retired officer from Central Government:

A fixed amount shall be admissible, arrived at by deducting the basic
pension from the pay drawn at the time of retirement. The amount of
remuneration so fixed shall remain unchanged for the terms of the
contract. There will be no annual increment / percentage increase during
the contract period.

Il In case of retired officer from PSUs:

The remuneration shall be arrived by ascertaining equivalent level of
post in the Central Government at which the retired PSU employee is
proposed to be appointed on contract basis. The notional pay of such
post in Central Government may be arrived at by taking the mean of
Cell-1 and Cell-10 of the corresponding pay level of such post. The sum
so arrived may be treated as last basic pay and 50% of such basic pay
may be allowed as remuneration. The amount of remuneration so fixed
shall remain unchanged for the terms of the contract. There will be no
annual increment / percentage increase during the contract period.

IV. Income Tax or any other tax liable to be deducted as per the prevailing
rules will be deducted at source before effecting the payment of
remuneration.

6. Allowances: -

[5 Accommodation/HRA: No accommodation or HRA will be provided by
the Department.

॥. Transportation allowance:

An appropriate and fixed amount as Transport allowance for the purpose
of commuting between the residence and the’ place of work shall be
allowed not exceeding the rate applicable to the appointee at the time of
retirement. The amount so fixed shall remain,unchanged during the term
of appointment. However retired employees engaged as consultant may
be allowed TA/DA on official tour if any as per entitlement at the time of
retirement.

Ml. Leave: - Paid leave of absence will be allowed at the rate of 1.5 days for
each completed month of service. Accumulation of leave beyond a
calendar year shall not be allowed.

7. Working facilities to be provided: -
Only the basic facilities/infrastructure will be provided to the contract
employee. No transport or telephone/internet facility at residence etc.
shall be provided.
8. Working Hours
Working hours shall normally be from 9:30 Am to 6.00 PM during working days
including half an hour lunch break in between. However, depending on the
exigency of work and if required, the contract employees may have to reach office
https://dot.eoffice.qov.in/efile/#/draft/100000T0003554324/view?source=F ILE&documentid=FO00DOT0000121303&viewParam=eyJkb2N 1bWVu. 4/13

<!-- page 6 -->

4/10/26, 10:28 AM PDF js viewer
DV/TNLSA/ConsultantNotification/ 2021-22 1/3386620/202

early or sit late to complete the time bound work or attend office on holidays. No
extra remuneration or fee would be payable if work required late sitting or coming
on holidays.

9. Accident, injury etc. during the period of engagement:
O/o Special DGT, TN LSA shall not be responsible for any loss, accident,
damage, injury suffered by the contract employees whatsoever arising in or out of
the execution of his/her work including travel.

10. Rights of Special DGT, TNLSA
Special DGT, TN LSA reserves the right to cancel and not proceed in the matter
of engagement of contract employees at any stage without giving any reason,
whatsoever. The decision of Special DGT, TN LSA shail be final in all respects.

11. Confidentiality of data and dacuments: -
The data collected / produced as well as deliverables produced for the O/o
Special DGT, Tamil Nadu LSA, shall remain with this office. No one shall utilize or
publish or disclose or part with, to a third party, any part of the data or statistics or
proceeding or information collected for the purpose of this assignment or during
the course of assignment from Tamil Nadu LSA, without the express written
consent of this office as the case may be. The consultants are bound to hand
over the entire set of physical and electronic records of assignment to this office
before the expiry of the contract and before the final payment are released by the
office. The contract employee shall sign an agreement of confidentiality with the
Government of India to this effect which shall contain a clause on Ethics and
Integrity.

12. Conflict of interest: -
The consultants engaged shall in no case represent or give opinion or advice to
others in any matter which is adverse to the interést of the Department of
Government of India. No contract employee would be permitted to take up any
other assignments during the period of engagement.

13. Closing date for submission of applications: Upto 17.00 Hrs of

30- 04- 2026. .

14. Selection Procedure: -
A panel for selecting the consultants shall be constituted for this purpose and it
will be valid for a period of six months. The decision of the selection panel /
department in the matter of selection of consultants shall be final and binding.
Suitable candidates may also be called for interaction/interview.

15. How to Apply:-
As per enclosed format at Annexure-A. The above notification is also available
on the office website www. dcot.gov.in

https://dot.eoffice.qov.in/efile/#/draftvIO00DOT 0003554324 /view?source=F ILE&documentid=FO00DOT0000121303&viewParam=eyJkb2N1bWVu. 5/13

<!-- page 7 -->

4/10/26, 10:28 AM PDF.js viewer
DV/TNLSA/ConsultantNotification/2021-22 1/3386620/20;
16. Special Condition: -
The consultant selected as TA may have to perform outdoor duties all over the
Tamil Nadu LSA Jurisdiction.
17. Application to be forwarded to: -
Assistant Director (Admin-ll), O/o The Special Director General
TelecomN LSA, DoT, TNT Complex, 3rd Floor, 60- Ethiraj Salai,
Egmore, Chennai-600008.
18. Termination of contract: -
The contract may be terminated by either of the parties with prior notice of 30
days.
The above said engagement is purely on temporary and on contract basis. The
selected candidates will be governed by the provision of the guidelines for
engagement of retired person in DoT/ Government of India as amended from time
to time.
Encl: As stated above
बन,
ASSIS! Di dmin-t!),
Special DGT| TN LSA
Chennai - 600008
Copy for kind information to: -
1. Director General Telecom, DoT HQ, New Delhi *
2. DDG (Estt.)/ Director (Est.), DoT HQ, New Delhi. ”
3. Director (IT), DoT HQ, New Delhi with a request to publish on DoT web site
under vacancies.
4, Pr. CCA, TN LSA, Chennai.
5. GM (Pers), BSNL Corporate Office, BSNL, Janpath, New Delhi.
6. CGMT, BSNL, TN Circle and Chennai.Telephones.
7. Notice Board
8. Office copy.
https://dot.eoffice.qov.in/efile/#/draft/I0O0DOT 0003554324/view?source=F ILE &documentid=FO00DOT0000121303&viewParam=eyJkb2N1bWVu. 6/13

<!-- page 8 -->

4/10/26, 10:28 AM PDFjs viewer
DV/TNLSA/ConsultantNotification/ 2021-22 1/3386620/20:
Annexure-A
APPLICATION FORMAT FOR THE POST OF CONSULTANT AT TN LSA
[against existing Vacant post at _O/o Special DGT, TN LSA Chennai
/Coimbatore
Preferred location: Chennai/Coimbatore
Post applied for: Steno/TA/LDC FY
1. Name: Recent
Passport size
2. Father's name: photograph
(Self attested)
3. Present Residential Address:
4. Aadhar Number:
5. Date of Birth (DD/MM/YYYY):
6. E-mail address:
7. Mobile number:
8. Date of entry into Government Service:
9. Date of retirement:
10. Last Month Basic pay drawn (on superannuation):
11. Basic Pension Drawn: ,
12. Educational Qualification:
13. Brief particulars of service with nature of duties performed for10 years before
retirement ‘
Brees j Period es ee ia
| S.No | Name of Ministry/Dept. croak ie Aas) Post Held Nene cL work |
| 10000 00000 7015] गा | BaieelOnern [ibe ee |
|
| |
oe eee : Sd OS | कक ca 10 |
https://dot.eoffice.qov.in/efile/#/draft/|000D0T 0003554324 /view?source=FILE&documentld=FO00DOT0000121303&viewParam=eyJkb2N 1bWVu 713

<!-- page 9 -->

4/10/26, 10:28 AM PDF.js viewer
DV/TNLSA/ConsultantNotification/ 2021-22 1/3386620/20;
14. Brief particulars of service with nature of duties performed, after retirement till
date
1 See । 00/00/0000. | »05 |
रा Name of Ministry/Dept. (pei ) | post Held Sa
eile LOM) 1 छा pee |
ae ne (ane leona Paco aa 00800 0 20/046070000/2///प 67
| Bs की पक pis Ea eS |
15.Knowledge of Computer
गा आज ee ue Fe ee uae
| MS Excel ee a ernie
ween sn Oe | ed on OL J Wa eter 11021
| Any other
(Please specify) ESSA SEES 0 is
16. Willingness to work at TN LSA, Chennai and Coimbatore in case of any vacancy
arising at a later date. Please mention {Yes/No}
17. Additional information, if any, in support of your suitability for the post.
The candidate has to submit a detailed resume on experience, works handled
relative to Telecom sector activities and other official functions (Not more than 2
pages)
18. Following documents must be attached with the application.
1) LPC of last month of service
2) Latest pension amount (Bank/Postal statement of Pension/Saving account)
DECLARATION
This is to certify that no disciplinary proceedings were pending against me on the
date of application and the information given above is true to the best of my
knowledge and belief. The supporting documents would be made available on
demand. In addition, | unequivocally and unconditionally accept all the terms &
conditions of Notification No. ADV/ TN LSA/ Consultant Notification/2021-22
dated 10.04.2026
Yours faithfully
Date: Signature:
Place : Full Name
https://dot.eoffice.qov.in/efile/#/draft/|000D0T0003554324/view?source=FILE&documentld=FOOODOT0000121 303&viewParam=eyJkb2N1bWVu.. 8/13

<!-- page 10 -->

4/10/26, 10:28 AM PDF.js viewer
DV/TNLSA/ConsultantNotification/2021-22 1/3386620/20:
F No. 3-26/2020-E.1A
Govemment of india
Ministy of Finance
Department of Expenditure
Dated the Sth December. 2026
Office Memorandum
Subject: Regulation of Remuneration in case of Contract Appointment of Retired Central
Government Employees.

The undersigned is directed lo say thal Minislries/Departments appoint relired Centra!
Government employees on contrac: basis, including as Consultants on contract basis. However, at
present there are no uniform guidelines for regulztion of remuneration in such cases.

2 The ex'sling instructions of Degartment of Personnel and Training, as contained in their
Central Civii Services (Fixalioreo! Pay of Re-employed Pensioners) Orders, 1986, as amendest
from tme to time. provide for regulation of pay in case of -c-empoymenl. However, the instructions
af Dapartmert of Personnel & Training as contained in thelr OM No. 2607 2/6/2902. Est (A) datec
39.12.2002 provides that re-employment beycnd the age of superannuation ef 60 years shail net be
permissible. Also, es per their OM No. 3(3]/2016-Estl (Pay 1) deted 15.2017, the vay plus gross
pension on re-employment is not te exceed Rs. 2,25.000/,, ie. Pay Level 17 es applicable to an
officer of the fevel of Secretary to the Government o° India.
3. AJorementioned instructions of Department of Personne! & Trainire cn pay fixation in case
of re-employment apply only to persons appointed on re-employment. These are not appisable to
persers employed or contract basis except where the contract provides otherwise, Accordingly ir
cases of appciniment of retired Ceritral Goverment employees on contract basis after the aye of
superannuation at 60 years, the instructions en pay fixation on re-employment will not directly
apply
4 Department of Personne! & Training bas aiso informed that they are in the procass of
drawing a Note for Commiltee of Secretaries (CoS) regarding Guidelines for engagement cf retires
Government servarts as Consultant in Government Ministrieg,and Department. In view of this, till
Department of Personnel and Training finalizes their guillelines, there is a reed to vegulate
remuneration in such cases of contract appointment of retired Central Government employees on a
uniform basis. The matter nas, therefore, bean considered and il has been decided that reaulatior
of remuneration in case of appointment of retired Central Government employees on contract
basis, including 2s consultants, shall be regulated as provided hereinafter.
https://dol.eoffice.aov.in/efile/#/draft/|000D0T0003554324/view?source=FILE&documentid=F000DOT0000121303&viewParam=evJkb2N1bWVu 9/13
