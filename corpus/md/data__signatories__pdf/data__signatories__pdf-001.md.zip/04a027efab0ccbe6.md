---
doc_id: "04a027efab0ccbe6"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/f82e6f3448262c45a7ed01dff833ec61.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Notes (2016) No. 1"
date: "2025-07-02"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f1c8628212a75f29"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
Press NoteNo. 1(2016 Series)
Subject: Review of Foreign Direct Investment Policy (FDI) on Insurance Sector.
The Government of India has liberalized its Foreign Direct Investment policy on Insurance
Sector. Accordingly, Paragraph 6.2.18.7 of 'Consolidated FDI Policy Circular 2015', effective from
12.5.2015, is amended to read as below:
S.No.

Sector/ Activity

6.2.18.7
6.2.18.7.1

Insurance
(i) Insurance Company
49%
(ii) Insurance Brokers
(iii)Third Party Administrators
(iv)Surveyors and Loss Assessors
(v) Other Insurance Intermediaries appointed
under the provisions of Insurance
Regulatory and Development Authority
Act, 1999 (41 of 1999)

6.2.18.7.2

Other conditions
(a) No Indian insurance company shall allow the aggregate holdings by way of total
foreign investment in its equity shares by foreign investors, including portfolio
investors, to exceed forty-nine percent of the paid up equity capital of such Indian
msurance company.

% of Equity/ Entry route
FDI Cap
Automatic

(b) The Foreign Investment proposals up to forty-nine per cent of the total paid up
equity of the Indian Insurance Company shall be allowed on the automatic route
subject to verification by the Insurance Regulatory and Development Authority of
India.
(c) Foreign investment in the sector is subject to compliance of the provisions of the
Insurance Act, 1938 and the condition that Companies bringing in FDI shall obtain
necessary license from the Insurance Regulatory & Development Authority of India
for undertaking insurance activities.
(d) An Indian insurance company shall ensure that its ownership and control remains at
all times in the hands of resident Indian entities referred to in Notification No. G.S.R
115 (E), dated 1 9 February, 2015.
(e) Foreign portfolio investment in an Indian insurance company shall be governed by
the provisions contained in sub-regulations (2), (2A), (3) and (8) of Regulation 5 of
FEMA Regulations, 2000 and provisions of the Securities and Exchange Board of
India (Foreign Portfolio Investors) Regulations.

<!-- page 2 -->

(f) Any increase of foreign investment of an Indian insurance company shall be in
accordance with the pricing guidelines specified by Reserve Bank of India under the
FEMA.
(g) The foreign equity investment cap of 49 percent shall apply on the same terms as
above to Insurance Brokers, Third Party Administrators, Surveyors and Loss
Assessors and Other Insurance Intermediaries appointed under the provisions of the
Insurance Regulatory and Development Authority Act, 1999 (41 of 1999):
(h) Provided that where an entity like a bank, whose primary business is outside the
insurance area, is allowed by the Insurance Regulatory and Development Authority
of India to function as an insurance intermediary, the foreign equity investment caps
applicable in that sector shall continue to apply, subject to the condition that the
revenues of such entities from their primary (i.e. non-insurance related) business
must remain above 50 percent of their total revenues in any financial year.
(i) The provisions of paragraphs 6.2.18.2.2(4) (i) (c) & (e), relating to 'Banking-Private
Sector', shall be applicable in respect of bank promoted insurance companies.
(i) Terms 'Control', 'Equity Share Capital', 'Foreign Direct Investment' (FD),
'Foreign Investors', 'Foreign Portfolio Investment', 'Indian Insurance Company',
'Indian Company', 'Indian Control of an Indian Insurance Company', 'Indian
Ownership', 'Non-resident Entity', 'Public Financial Institution', 'Resident Indian
Citizen', 'Total Foreign Investment' will have the same meaning as provided in
Notification No. G.S.R 115 (E), dated 1 9 February, 2015.
2.0

The above decision will take immediate effect.
�

(Atul Chaturvedi)
Joint Secretary to the Government oflndia
D/o IPP File No.: No. 4/24/2014-FC.I dated:23 .03 .2016
Copy forwarded to:

1. Press Information Officer, Press Information Bureau- for giving wide publicity to the above
Press Note.
Affairs, For suitably incorporating the
policy changes in Foreign
Exchange Management (Transfer
3 . Reserve Bank of India, Foreign Exchange Department, or issue of security by a person
Mumbai
resident
outside
India)
Regulations, 2000 and the
relevant schedules thereof.

2. Joint Secretary(l&C), Department of Economic
North Block, New Delhi

4. NIC Section in the Department of Industrial Policy and Promotion- for uploading the Press
Note on DIPP's website.
5. Hindi Section, DIPP- for providing Hindi version.
