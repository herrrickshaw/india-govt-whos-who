---
doc_id: "0350e0aaec3aba3e"
source_url: "https://www.mea.gov.in/images/pdf/APO_Kolkata_24-04-2018.pdf"
ministry: "External Affairs (MEA)"
title: "Vacancy circular for the post of Assistant Passport Officer in Passport Office Kolkata in Central Passport Organisation on deputation basis"
date: ""
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "944f05a122640d38"
---

<!-- page 1 -->

. No. V.IV/575/14/2018 Part-I
Government of India
Ministry of External Affairs
CPV Division
Patiala House Annexe,
Tilak Marg, New Delhi-110001,
Dated: 23.04.2018
VACANCY CIRCULAR
The Ministry of External Affairs (CPV Division) intends to fill the following posts in Passport
Office at stations indicated below from amongst officers under the Central Government including officers
of All India Services / Central Secretariat Services in the Ministries / Departments of the Government of
India, on deputation basis:-
a
IName of Passport Office
Assistant | 1 (One): Pay Band 3, Officers under the Central Government
Passport | 1 Post — Passport Office, | Rs. 15,600- including officers of All India Services:
Officer | Kolkata (PSLK, 39,100 +
(APO) Agartala) Grade Pay (a) (i) holding analogous Posts on regular
Rs5,400/-. basis in the parent cadre or department; or
(Pre-revised) | (ii)with two years’ service in the Grade
rendered after appointment thereto on a regular
basis in posts in the Pay Band-2(Rs.9300-
34,800 and Grade Pay of Rs. 4800 (Pre-
revised) or equivalent in the parent cadre or
Department; or
(iii) with three years’ service in the Grade
rendered after appointment thereto on a regular
basis in posts in Pay Band-2(Rs. 9300-34800
and Grade Pay of Rs. 4600 (Pre-revised) or
equivalent in the parent cadre or Department;
and
(b) possessing the following educational
qualifications and experience:
(i) Bachelor’s degree from a_ recognized
University in India or Association of Indian
Universities recognized degrees of foreign
Universities;
(ii) One year experience in passport or
Consular or Emigration or Administration or
Finance or Accounts or Vigilance work.
Note 1: The Departmental Officers in the feeder category who are in the direct line of promotion will not
be eligible for consideration for appointment on deputation. Similarly, deputationists shall not be eligible
for consideration for appointment by promotion.
Note 2: Period of deputation including period of deputation in another ex-cadre post held immediately
preceding this appointment in the same or some other organization or department of the Central
Government shall ordinarily not to exceed three years.
Note 3: The maximum age limit for appointment by deputation shall not be exceeding fifty six years as on
the closing date of receipt of applications.
1

<!-- page 2 -->

. Note 4: For the purpose of appointment on deputation basis, the service rendered on a regular basis by an
officer prior to the 1* January, 2006 or the date from which the revised pay structure based on the Sixth
Central Pay Commission recommendations has been extended, shall be deemed to be service rendered in
the corresponding grade pay or pay scale extended based on the recommendations of the Pay Commission
except where there has been merger of more than one pre-revised scale of pay into one grade with a
common grade pay or pay scale, and where this benefit will extend only for the post for which that grade
pay or pay scale is the normal replacement grade without any upgradation
2 The selected officers will be on deputation for a period of three years initially which can be
curtailed or extended further, depending upon the requirement, and with the consent of the officer and
approval of the lending department. The usual deputation terms will apply. The APO can be posted any
of the PSK/PSLK/POPSK falling under the jurisdiction of respective Passport Office.

3: All Ministries/Departments of Government of India are requested to circulate the above posts
among the officers under the Central Government including officers of All India Services/ State
Government, working with them and forward the application (in prescribed pro forma Annexure A) of
eligible and interested officers, along with their dossiers and a certificate to the effect that they are clear
from vigilance angle, to the undersigned by 22" May, 2018.
om
Ohh
($ahib Singh)
Deputy Passport Officer (PVE, PVA & Cadre)
Ph. No. 011-23073259
To,
dl; All Ministries/ Department of Government of India
2 All Chief Secretaries to the State Governments.
Copy to:-
1. Ministry of External A ffairs-[Kind attn. to: Joint Secretary (Admn)).
2. Director (XP), Ministry of External Affairs, Shastri Bhawan, New Delhi- with the request to
upload this circular on the MEA’s website.
3. Director(PSP), Ministry of External Affairs, CPV Division, New Delhi -with the request to
upload this circular on the Passport Seva website
4. Director (CS), DoPT, Lok Nayak Bhawan, Khan Market, New Delhi- with the kind request to
upload this circular on DoPT’s website for wider circulation.
5. All Passport Offices.
6. Branch Secretariat at Chennai, Kolkata, Guwahati, Hyderabad.
7. Olo JS (PSP) & CPO, CPV Division, MEA, New Delhi.
2
