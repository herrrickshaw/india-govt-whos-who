---
doc_id: "014bb7fdabd3b3b3"
source_url: "https://financialservices.gov.in/sites/default/files/Act-Policies/2026-01/4B.-SIDBI2011.pdf"
ministry: "Department of Financial Services (DoFS)"
title: "Small Industries Development Bank of India (Employees' Provident Fund) [Amendment] Regulations, 2011"
date: "2026-01"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab953b05d9679d2a"
---

<!-- page 1 -->

(/ u7*On TO, 33009/99

RI XII). NO. H.L.-33004/99

STREi R*1- itlal gal
Q.Ate Gazette of ;frictia
3TRItT#1#

EXTRAORDINARY

%TM I II-a 4
PART HI—Section 4
Mfirth-ft *
qi d
PUBLISHED BY AUTHORITY
-it 2511

fCRUIR 22, 2011/414 1, 1933
rqc-vil, ri0e4
NEW DELHI, THURSDAY, DECEMBER 22, 201I/PAUSA 1. 1933

No. 2511

IMAIN cit

dil 11

Chi f4

Ch

mfrrit-vffr
Rc\-111, 21 FSTI1R, 2011
911 de! icictof ti
( ct4zi4t

fqffl [ BY111.E4
2011
WF. B. 4IHrr R 3617/fElthIIHI4 ( 2 ),--anf FES .54414 174m-nT
31itli#S4T, 1989 (1989 Th-T 39) 0 %MT 52 0 311-1.TR1 (I)* kaarre ITC? glreiqi
MT 1:147 etPiA KI7,3TR-4'Rr
.5444 Thmi-fr t i saam- +is,/ t 1F4 4 Fig
54.14 it-0R ft (thAtilft nit1574 thif.1) 1-414zisf, 1990
W144lif farm-if-al-ad
**gm
I. 4

ri.N4
efq 5dur Ibm--r-g aiii (tdt1Fgartf
2011 # ..7111
S RP+.4c11 01 qa 2011 I% Mei #41

3411-A7T
otadi 1nr+1 4*W, (q) -or airat4 thii4)
fai-cifarad preamrfto 1r nvor

[-HRBtTal

1990

¶ciqei 13

1racl, £9M Z& rwiiP
cr-F4.ffi 31i5afff
nmr rsrr
CIT 371
.211,7r Mte q4dir,
nr *II
uu 0=11 Q livtie&
RTS fl Z1'11.3.1.1, r4v am iroit
394IIT 37-4 eau", t)fkachia-, zi
F2.11
relit! Irei 3ft reit FAMZII a W4QT # SIM 0 ilea. r.11 c't 1,1 lathe' Th-t JI,cic, VSICI
Nig SCOT 4,4 U-0 1Wirta'
aTKruir, aQTA
6-1.41af
4104 Vet Lrd
uf
MMTB 475 giif 311:ft codhiltr Prat fart
#04- # 313-gin
- c4- faa-rtdi FM.
.544 g

ci

I 4# ,,efiat
q4

St

ourrn

atittardi i

TL'nft 3M 3t1" +Midi- SI Will 3TTUR 11-4- 31 ?lit a2IT 30 1trd0

c1)51 allQd l f l
1618 01/2011

i JII1ct. $q#141 v17 lath

(I)

Wt

<!-- page 2 -->

2

THE GAZETTE OF INDIA EXTRAORDINARY

(PART III—Shc. 4J

.1r4i ft-4ff 3f1' 41F
a err el
r aft, za 144 eit 4 9 544 dr tq
'et MIb IWItr cr+1 trt crf:
d
Itra (yield) 341" tTfTtf WaT
t, 71'
k eta Lra
Al
thm-r-4:r act) *t mfiet
4rarT ITT 4-4T tt cricft .3ittre'a t, at Fig
4* WI f-aa•dW ifisef Z5T #3IjoI1CGIUT %ZIT
I
a 740, aTaRi T

3&fikkrt-

frdi1lTh111/4 /139-7/11-31-Mi]
SMALL INDUSTRIES .DEVELOPMENT BANK OF INDIA
NOTIFICATION
New Delhi, the 21st December, 2011
The Small Industries Development Bank of India
(Employees' Provident Fund) [Amendment] Regulations, 2011
F. No. HRDD No. 3617/Staff General (2).—In exercise of the powers conferred
by sub-section (1) of Section 52 of the Small Industries Development Bank of
India Act, 1989 (39 of 1989), the Board of Directors of the Small Industries
Development Bank of India hereby makes the following amendments to the
Small Industries Development Bank of India (Employees' Provident Fund I
Regulations, 1990, namely :These Regulations may be called the Small Industries Development Bank
of India (Employees' Provident Fund) [Amendment] Regulations, 2011.
These Regulations shall come into force with effect from June 01, 2011.
Regulation 13 of the Small Industries Development Bank of India
(Employees' Provident Fund) Regulations, 1990 shall be substituted with
the following :`The Small Industries Bank shall credit interest on the amount standing to each subscribers credit
at the end of every half-year at a rate which shall be fixed by the Small Industries Bank having
regard to the return which can be obtained on the investment of other provident, charitable,
religious and trust and quasi trust funds in accordance with the regulations, schemes or directions
made, framed or given by the Central Government in this behalf, provided that the rate of interest
shall be not lower than the rate allowed by National Bank for Agriculture and Rural Development
in respect of its Employees' Provident Fund. Such interest shall be calculated to the nearest
rupee on the monthly products of each subscribers account and shall be applied to the accounts
half yearly as at the 31st March and 30th September.
Notwithstanding anything contained hereinabove; if in any year, the yield on the PF corpus of
Small Industries Bank is lower than that required to be paid based on National Bank for
Agriculture and Rural Development's rate of interest, prior approval of the Board shall be obtained
by the Small Industries Bank"
SUSHIL MUHNOT, Chairman & Managing Director
[No. ADVT.: ill/4/139-A/11-Exty.]

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-1.10064
and Published by the Controller of Publications, Delhi-110054.
