---
doc_id: "02f28fbca0ebfb16"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/135ce5528e4717486e96ae1d9fa9a825.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Registration Certificate of M/s Neuman & Esser Engineering (India) Pvt Ltd dated 24.04.2025"
date: "2025-07-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3d35106006c581a8"
---

<!-- page 1 -->

No.
/112/2020-PP (BE-II)/025
No. P-45021
P-45021/112/2020-PP
(BE-II)/025
of
India
Government
Government of India
Ministry
Ministry of
of Commerce
Commerce and
and Industry
Industry
Department
Department for
for Promotion
Promotion of
of Industry
Industry and
and Internal
Internal Trade
Trade
(Public
(Public Procurement
Procurement Section)
Section)
Udyog
Udyog Bhawan,
Bhawan, New
New Delhi
Delhi
th
Apr,
2025
Dated
the
24
Dated the 2 4 Apr, 2025
Registration
(India} Pvt
Registration Certificate
Certificate to
to M/s
M/s Neuman
Neuman &
Esser Engineering
Engineering (India}
Pvt Ltd
Ltd
& Esser

The
The undersigned
undersigned is
is directed
directed to
to refer
refer to
to the
the application
application no.
no. NIL
NIL dated
dated
20.11.2023
& Esser
Esser Engineering
Engineering (India)
(India) Pvt
Pvt Ltd,
Ltd, seeking
seeking renewal
renewal of
of
20.11.2023 of
of M/s
M/s Neuman
Neuman &
registration
registration certificate
certificate dated
dated 01.04.2021
01.04.2021 granted
granted by
by DPIIT
DPIIT in
in accordance
accordance with
with
10/2021-PPD
Department
Department of
of Expenditure
Expenditure Order
Order (Public
(Public Procurement
Procurement No.4)
No.4) No.
No. F.
F. 7/
7/10/2021-PPD
dated
dated 23.02.2023
23.02.2023 and
and to
to convey
convey that
that competent
competent authority
authority has
has approved
approved grant
grant of
of
registration
registration on
on the
the following
following terms
terms and
and conditions
conditions to
to the
the entity
entity mentioned
mentioned below:
below:
Name
Name of
of the
the applicant
applicant entity
entity

Registered
Registered Office/Complete
Office/Complete address
address
of
of the
the applicant
applicant entity
entity

Mis
Mis Neuman
Neuman &
Esser Engineering
Engineering (India)
(India)
& Esser
Pvt
Pvt Ltd
Ltd
T-121
/ 122 MIDC
T-121/122
MIDC Bhosari
Bhosari PunePune- 411026
411026
Maharashtra
Maharashtra

Contact
Contact Person
Person

Contact
Contact person:
person: Shri
Shri Hemant
Hemant Borhade
Borhade

Name
Name &
Telephone number,
number, Email
Email
& Telephone
Id
Id

Contact
Contact No:
No: +91-9665062077
+91-9665062077
Email
id:
Email
id:
esser.co.in
esser.co.in

hemant.borhade@neumanhemant.borhade@neuman-

Address
Address of
of the
the premises
premises from
from where
where
services
services are
are provided
provided

T-121
/ 122 MIDC
T-121/122
MIDC
Maharashtra
Maharashtra

ltem/s
ltem/s for
for
granted
granted

Reciprocating
Reciprocating Gas
Gas Compressor
Compressor Package
Package

which
which

Validity
Validity of
of registration
registration

registration
registration

is
is

Bhosari
Bhosari

Pune-411026
Pune-411026

03
03 years
years from
from the
the date
date of
of issue
issue of
of this
this letter,
letter,
rd
i.e.,23
April,, 2028
2028
i.e.,23 April

2.
The
2.
The Registration
Registration is
is only
only for
for the
the purpose
purpose of
of participation
participation in
in public
public procurement
procurement in
in
India
India in
in accordance
accordance with
with DoE
DoE Order
Order (Public
(Public Procurement
Procurement No.4)
No.4) dated
dated 23.02.2023
23.02.2023 for
for
supply
services) from
from the
the premises
premises mentioned
mentioned above.
above.
supply of
of items
items (goods/
(goods/ works
works // services)
In
3.
In case
than 10%
3.
case of
10%
more than
of appointment
of new
with more
Director(s)/shareholders with
appointment of
new Director(s)/shareholders
shares /change
in controlling
controlling ownership
/change in
ownership interest
or control
interest or
control through
this
means, this
through other
other means,
shares
Registration shall
shall automatically
automatically stand
stand annulled.
annulled.
Registration
~~

'Y\

c-:� a m

V\
/"eu
(Surendra
enaa Singh)
s in
Under
Government of
Under Secretary
Secretary to
to the
the Government
of India
India
E-mail
E-mail:: ssingh.dopt@nic.in
ssingh.dopt@nic.in
To,
To,
M/s
& Esser
Esser Engineering
Engineering (India)
(India) Pvt
Pvt Ltd
Ltd
M/s Neuman
Neuman &
Address:
/ 122, MIDC
Address: T-121
T-121/122,
MIDC Bhosari
Bhosari Pune-411026
Pune-411026 Maharashtra
Maharashtra
