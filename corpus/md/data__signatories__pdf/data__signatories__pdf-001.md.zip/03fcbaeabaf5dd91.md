---
doc_id: "03fcbaeabaf5dd91"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/329ff4c23a0b24d78dcef3169971a450.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Central Civil Service (Conduct) Rules, 1964 - Submission of Immovable Property Returns (IPRs) for the year 2020 (as on 31.12.2020) by all the Officers/Staff of this Department."
date: "2025-06-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "86ff7cce9d1c5171"
---

<!-- page 1 -->

Welcome to eOfrce Solution

https ://dadf.eoffjce. gov. in/eFile/?x=th

I oZSAoN+hMdFTygATsO

No.A-4401 1/ 13l2 02 0_Esrt. (Hqrs.J

Government of India
Ministry of Fisheries, Animal Husbandry and
Dairying
(Department of Animal Husbanary ana
Oai.yingl '
t*,t**

Krishi Bhawan, New Delhi-110001
OFFICE M EMO RANDUM

l;fJanuary,202r

subject:- centrar civir service (conduct) Rures, 1g64
- submission of
Immovable propcrty
(tpRs) for the year ZOiO-fl,
- .^R€turns
31,12.2020)
by all the Officers/Staffof inis O"p".t_"n,-.ug.

",

The undersigne, ,r rlru..:"^l:" refer ro rhe
subjecr cited above and to say rhar the
Immovable properry Return (lpR) ,." ."qri..J-il
be filed every year by all the
Government servants belon_ging to Group ,N,'.8,,,4,
and erstwhite G.;r; ,;, il,t"ims of
Rule 18 [4) ofthe CCS (Conductj Rutes, tSO+.

2'

Therefore, a officers^and staff of this Department
are requested to file their IpR
for the Year 2020 (as on 31,...1,2.2_0201
faf"sfty__fiOfeOZf
through the module
(electronic or physical), as applicable to
it *-i* Jinicers/sraff concerned.

"

3.

A copy of the print out (rpR submitted]
may be- furnished
-to Establishment [Hqrs.)
Section for information, record & n"aarrr.y

,ation.

(Madhusudanan V.K)
Under Secretary to the Government of India

lD:J

Tel. # 23382279

To,

All officers and Staff of DAHD.
copy to NIC, DAHD for uploading the same on
the website of the Department as well as in the
e-Office (Notice Board).

of2
0l-01-2021, 17:29
