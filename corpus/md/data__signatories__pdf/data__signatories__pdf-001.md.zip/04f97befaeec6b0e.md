---
doc_id: "04f97befaeec6b0e"
source_url: "https://doj.gov.in/static/uploads/2025/11/a500baca43e397abee9d0a71b9634de8.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment Shri Jia Lal Bhardwaj and 01 other Advocate as Judges of Himachal Pradesh High Court (26.09.2025)"
date: "2025-09-26"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "44d9e90d6528645f"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13020/01l2024-US-II
Government of India
Ministry of Law & Justice

Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-l 10 011, dated 26th September, 2025.

NOTIFICATION

In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint S/Shri (i) Jiya Lal
Bhardwaj and (ii) Romesh Verma, to be Judges of the Himachal Pradesh High
Court with effect from the date they assume charge of their respective offices.

q
(Jagan ath Srinivasan)
Joint Secretary to the Government of India
Tele:"2338 3037

To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2-

No. K-13020101l2024-US-II

Dated: 26.09.2025.

Copy to:-

1.

S/Shri (i) Jiya Lal Bhardwaj and (ii) Romesh Verma, Advocates
through the Registrar General, Himachal Pradesh High Court, Shimla.
2. The Secretary to the Governor, Himachal Pradesh, Shimla.
3. The Secretary to Chief Minister, Himachal Pradesh, Shimla.
4. The Secretary to the Chief Justice, Himachal Pradesh High Court,
Shimla.
5. The Chief Secretary, Government of Himachal Pradesh, Shimla.
6. The Registrar General, Himachal Pradesh High Court, Shimla.
7. The Accountant General, Himachal Pradesh, Shimla.
8. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan,
New Delhi.
9. PS to Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
10. Registrar (Conf.), 010 Chief Justice of India, 07, Krishna Menon
Marg, New Delhi.
11. PS to MoS (IIC), L&J 1PPS to Secretary (J).
12. Technical Director, NIC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doj.gov.in).

1-£\ fY'I

')I)~

(Prem Chand)

Under Secretary (Appointments-I)
Tele: 011-23382978
