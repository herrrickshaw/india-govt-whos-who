---
doc_id: "04bcfecdb16b3c62"
source_url: "https://rural.gov.in/static/uploads/2024/02/Accessibilty-Guideline_0.pdf"
ministry: "Rural Development (MoRD)"
title: "Accessibility Guidelines"
date: "2024-02-18"
pages: 75
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "beed3446b0ed0b5c"
---

<!-- page 1 -->

763910/2022/NSAP
903230/2023/NSAP

J-11060/01/2021-NSAP

Accessible India Campaign
Draft Accessibility Standards and
Guidelines
Department of Rural Development
Ministry of Rural Development

Government of India

483/1178
1180/126

<!-- page 2 -->

763910/2022/NSAP
903230/2023/NSAP

484/1178
1181/126

J-11060/01/2021-NSAP

Content
S.no.

Title

Page No.

1.

Introduction

1

2.

Definitions

5

3.

Department of Rural Development

7

Provisions for the Persons with Disabilities
under the schemes of Department of Rural
Development

10

5.

Accessibility Features for Roads, Buildings and
Public Facilities in Rural Areas

20

6.

Information Technology and Communication
Ecosystem

27

7.

Bibliography

38

4.

<!-- page 3 -->

485/1178
1182/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

1

INTRODUCTION

Ratification of the United Nations Convention on Rights of Persons with
Disabilities by India makes it incumbent that Persons with Disabilities have access to
physical environment, transportation and information and communication on an equal
basis with others in both urban and rural areas of the country. Taking a first step in this
direction, Hon’ble Prime Minister of India launched the Accessible India Campaign or
the Sugamya Bharat Abhiyan on 3rd December 2015 for creating a barrier free
environment across the three components of build-up environment, the transportation
system and ICT system.
The purpose of Accessible India Campaign is to create tangible assets of
accessible infrastructure, through guided change in the society towards standardized,
organic and intentional development of accessible facilities and services. The Campaign
identifies the core principles to achieve this mission as follows:
i.

Universal design (the design of products, environments, programmes and
services usable by all, to the greatest extent possible, without the need for
adaptation or specialized design, applicable to assistive devices and advanced
technologies);

ii.

Reasonable Accommodation (Necessary and appropriate modifications and
adjustments, without imposing a disproportionate or undue burden in a
particular case, to ensure to PwDs the enjoyment or exercise of rights equally
with others)
Accessible India Campaign also serves as a tool to actualize the provisions of

‘accessibility’ mentioned under the Rights for Persons with Disabilities Act, 2016
(RPwD Act). The RPwD Act, 2016 mandates accessibility through Sections 40 to 46 as
under:
Section 40: The Central Government shall, in consultation with the Chief
Commissioner, formulate rules for persons with disabilities laying down the standards
1|Page

<!-- page 4 -->

486/1178
1183/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

of accessibility for the physical environment, transportation, information and
communication, including appropriate technologies and systems, and other facilities
and services provided to the public in urban and rural areas.
Section 41
(1) The appropriate Government shall take suitable measures to provide
a. Facilities for persons with disabilities at bus stops, railway stations and airports

conforming to the accessibility standards relating to parking spaces, toilets,
ticketing counters and ticketing machines.

b. Access to all modes of transport that conform the design standards, including

retrofitting old modes of transport, wherever technically feasible and safe for
persons with disabilities, economically viable and without entailing major
structural changes in design.

c. Accessible roads to address mobility necessary for persons with disabilities.

(2) The appropriate Government shall develop schemes programmes to promote the
personal mobility of persons with disabilities at affordable cost to provide for, —
a. Incentives and concessions.
b. retrofitting of vehicles; and
c. personal mobility assistance

Section 42: The appropriate Government shall take measures to ensure that a.

All contents available in audio, print and electronic media are in accessible
format;

b. Persons with disabilities have access to electronic media by providing audio

description, sign language interpretation and close captioning.

c. Electronic goods and equipment which are meant for everyday use are available

in universal design.

2|Page

<!-- page 5 -->

487/1178
1184/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

Section 43: The appropriate Government shall take measures to promote
development, production and distribution of universally designed consumer products
and accessories for general use for persons with disabilities.
Section 44:
1. No establishment shall be granted permission to build any structure if the

building plan does not adhere to the rules formulated by the Central
Government under section 40.

2. No establishment shall be issued a certificate of completion or allowed to take

occupation of a building unless it has adhered to the rules formulated by the
Central Government.

Section 45:
(1) All existing public buildings shall be made accessible in accordance with the
rules formulated by the Central Government within a period not exceeding five years
from the date of notification of such rules:
Provided that the Central Government may grant extension of time to the States
on a case to case basis for adherence to this provision depending on their state of
preparedness and other related parameters.
(2) The appropriate Government and the local authorities shall formulate and
publish an action plan based on prioritization, for providing accessibility in all their
buildings and spaces providing essential services such as all primary health centers,
civil hospitals, schools, railway stations and bus stops
Section 46: The service providers whether Government or private shall provide
services in accordance with the rules on accessibility formulated by the Central
Government under section 40 within a period of two years from the date of
notification of such rules:
Provided that the Central Government in consultation with the Chief Commissioner
may grant extension of time for providing certain category of services in accordance
with the said rules.
3|Page

<!-- page 6 -->

488/1178
1185/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

Types of Disabilities
Impairments
regardless
1

Non-Ambulatory

that,

of

manifestation,

cause

or

for

all

practical purposes, confine
individuals to wheel chairs
Impairments

that

cause

individuals to walk with
difficulty

or

insecurity.

Individual using braces or
3

Semi-Ambulatory

crutches,
arthritics,

amputees,
spastics

&those

with pulmonary & cardiac
ills may be semi-ambulatory
Total

blindness

or

impairments affecting sight
to
3

Sight

the

extent

that

the

individual functioning in
public areas is insecure or
exposed to danger
Deafness

or

hearing

handicaps that might make
an individual insecure in
4

Hearing

public areas because he is
unable to communicate or
hear warning signals.

4|Page

<!-- page 7 -->

489/1178
1186/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

02
Definitions
As per the Right to Persons with Disabilities Act, 2016, unless the context otherwise
requires,
i.

‘barrier’ means any factor including communicational, cultural, economic,
environmental, institutional, political, social, attitudinal or structural factors
which hampers the full and effective participation of persons with disabilities in
society.

ii.

“Information

and

services

innovations

and

communication
relating

technology”

includes

all

to information and communication,

including telecom services, web based services, electronic and print services,
digital and virtual services.
iii.

“person with benchmark disability” means a person with not less than forty per
cent of a specified disability, where specified disability has not been defined in
measurable terms and includes a person with disability where specified
disability has been defined in measurable terms, as certified by the certifying
authority.

iv.

“person with disability” means a person with long term physical, mental,
intellectual or sensory impairment which, in interaction with barriers, hinders
his full and effective participation in society equally with others.

v.

“public building” means a Government or private building, used or accessed by
the public at large, including a building used for educational or vocational
purposes, workplace, commercial activities, public utilities, religious, cultural,
leisure or recreational activities, medical or health services, law enforcement
agencies, reformatories or judicial foras, railway stations or platforms, roadways,
bus stands or terminus, airports or waterways.
5|Page

<!-- page 8 -->

763910/2022/NSAP
903230/2023/NSAP

vi.

490/1178
1187/126

J-11060/01/2021-NSAP

“public facilities and services” includes all forms of delivery of services to the
public at large, including housing, educational and vocational trainings,
employment and career advancement, shopping or marketing, religious,
cultural, leisure or recreational, medical, health and rehabilitation, banking,
finance and insurance, communication, postal and information, access to justice,
public utilities, transportation.

vii.

“Universal design” means the design of products, environments, programmes
and services to be usable by all people to the greatest extent possible, without the
need for adaptation or specialized design and shall apply to assistive devices
including advanced technologies for particular group of persons with disabilities.

6|Page

<!-- page 9 -->

491/1178
1188/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

3
Department of Rural Development
Department of Rural Development, Ministry of Rural Development being the nodal
Ministry for most of the development and welfare activities in the rural areas, plays a
pivotal role in the overall development strategy of the country. The vision and mission
of the Ministry is sustainable and inclusive growth of rural India through a
multipronged

strategy

for

eradication

of

poverty

by

increasing

livelihoods

opportunities, providing social safety net and developing infrastructure for growth.
This is expected to improve quality of life in rural India and to correct the
developmental imbalances, aiming in the process, to reach out to most disadvantaged
sections of the society. Broadly, the aims of the Ministry of Rural Development are:


Providing livelihood opportunities and skilling to those in need including
women and other vulnerable sections with focus on poor households.



Providing for the enhancement of livelihood security of households in rural areas
by providing at least 100 days of guaranteed wage employment in every
financial year to every household demanding it.



Provision of all-weather rural connectivity to unconnected rural habitations and
upgradation of existing roads to provide access to market, schools and hospitals.



Providing basic housing and related amenities to BPL household in rural areas.



Providing social assistance to the elderly, widow and disabled persons.



Providing urban amenities in rural areas for improvement of quality of rural life.



Capacity development and training of rural development functionaries.



Promoting involvement of voluntary agencies and individuals for rural
development.

This Department has been acting as a catalyst effecting the change in rural areas
through the implementation of wide spectrum of programmes which are aimed at
7|Page

<!-- page 10 -->

492/1178
1189/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

poverty alleviation, employment generation, infrastructure development and social
security. Over the years, with the experience gained, in the implementation of the
programmes and in response to the felt needs of the poor, several programmes have
been modified and new programmes have been introduced. The Ministry's main
objective is to alleviate rural poverty and ensure improved quality of life for the rural
population especially those below the poverty line. These objectives are achieved
through formulation, development and implementation of programmes relating to
various spheres of rural life and activities, from income generation to environmental
replenishment.
Keeping in view the needs and aspirations of the local people, Panchayati Raj
Institutions(PRIs) have been involved in the programme implementation and these
institutions constitute the core of decentralized development of planning and its
implementation. The following major programmes are being operated by the Ministry
of Rural Development in rural areas:
i.

Rural Employment- Mahatma Gandhi National Rural Employment Guarantee
Act, 2005 (MGNREGA)

ii.

Rural Livelihoods- Deendayal Antyodaya Yojana- National Rural Livelihoods
Mission (DAY-NRLM)

iii.

Deen Dayal Upadhyaya Grameen Kaushalya Yojana (DDU-GKY)

iv.

Rural Connectivity - Pradhan Mantri Gram Sadak Yojana (PMGSY)

v.

Pradhan Mantri Awaas Yojana – Grameen (PMAY-G)

vi.

National Social Assistance Programme (NSAP)

vii.

Sansad Adarsh Gram Yojana (SAGY)

viii.

Shyama Prasad Mukherjee RURBAN Mission (SPMRM)

Autonomous Bodies involved in the implementation/ Research:
i.

National Institute of Rural Development & Panchayati Raj (NIRD&PR)

8|Page

<!-- page 11 -->

493/1178
1190/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

ii.

National Rural Infrastructure Development Agency (NRIDA)

In addition, the Department also has schemes for capacity development of
rural functionaries; Information, Education and Communication; and Monitoring
and Evaluation.

9|Page

<!-- page 12 -->

494/1178
1191/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

4
Provisions for the Persons with Disabilities under the
schemes of Department of Rural Development
1. Mahatma Gandhi -NREGA

“Mahatma Gandhi National Rural Employment Guarantee Act (MGNREGA),
2005 is an Act to provide for the enhancement of livelihood security of the households
in rural areas of the country by providing at least one hundred days of guaranteed
wage employment in every financial year to every household whose adult members
volunteer to do unskilled manual work.”
Core Objectives:
The core objectives of the Mahatma Gandhi National Rural Employment Guarantee
Scheme (MGNREGS) formulated under Mahatma Gandhi National Rural Employment
Guarantee Act (Mahatma Gandhi NREGA), 2005 are:


Guaranteed employment of one hundred days of unskilled manual work in a
financial year to every household in rural areas as per demand



Creation of productive assets of prescribed quality and durability



Strengthening the livelihood resource base of the poor



Proactively ensuring social inclusion; and



Strengthening Panchayat Raj Institutions

As on date, 731 Districts (except Delhi & Chandigarh) and 2.69 lakh GPs are covered
under Mahatma Gandhi NREGA
Salient Features of the Act:
1. Right based Framework


Right to demand work – at least 100 days by a rural household



Right to employment - within 15 days of application, else unemployment
allowance

10 | P a g e

<!-- page 13 -->

763910/2022/NSAP
903230/2023/NSAP



495/1178
1192/126

J-11060/01/2021-NSAP

Right to wages - within 15 days, else delay compensation

2. Labour Intensive Works


60:40 wage and material ratio for works at district level



No contractors or labour displacing machinery allowed

Provisions made under MGNERG Act for persons with disabilities:
a. Mahatma Gandhi National Rural Employment Guarantee Scheme (Mahatma
Gandhi NREGS) is a demand driven wage employment programme which provide
for the enhancement of livelihood security of the households in rural areas of the
country by providing at least one hundred days of guaranteed wage employment in
every financial year to every household whose adult members volunteer to do
unskilled manual work. The provisions for differently abled persons under
Mahatma Gandhi National Rural Employment Guarantee Act (Mahatma Gandhi
NREGA) Operational Guidelines are given as under:-



Para 9.3.1: The disabled or differently abled persons defined under the Persons
with Disabilities (Equal Opportunities, Protection of Rights and Full
Participation) Act, 1995 (1 of 1996) as persons with disabilities, the severity of
which is 40% and above would be considered as special category of vulnerable
persons for the purposes of Mahatma Gandhi NREGA. The disabled persons
as defined in the National Trust for Welfare of Persons with Autism, Cerebral
Palsy, Mental Retardation and Multiple Disabilities Act, 1999 (44 of 1999) are
also to be considered as disabled for the purpose of inclusion in Mahatma
Gandhi NREGA.



Para 9.3.2: Since this category of people are differently abled, special
conditions have to be created to facilitate their inclusion in Mahatma Gandhi
NREGA.
11 | P a g e

<!-- page 14 -->

763910/2022/NSAP
903230/2023/NSAP



496/1178
1193/126

J-11060/01/2021-NSAP

Para 9.3.3: Each State Government will identify specific works, which can be
done by the disabled and vulnerable persons. In a village, different categories
of persons with disabilities will be organized to come together as a fixed group
to accomplish the works proposed for them under the Scheme, in a way that
makes it possible for them to exercise their choice. On no grounds, should the
disabled and vulnerable persons be paid lower wages as compared to other
persons employed in Mahatma Gandhi NREGA works.



List of major works identified for disabilities persons on the basis of
information received from the states under Mahatma Gandhi NREGA is given
as under :
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24

Works identified for Persons with Disabilities
Supplying drinking water
Taking Care of children at site
Plantation work
Excavation in irrigation canal
Earth filling
Laying of excavated earth / laying of earth in trolley
Building Construction –Preparation of Concrete Material
Arranging the construction material
providing cement & bricks
Filling sand in the carriage basket
Curing of newly constructed wall
Well Deepening-Filling soil/silt into the basket
Support in extracting water from the well
Dumping debris in the trolley
Removal of debris in ponds
Filling derbies into the pan(vessel)
Dumping filled pan into trolley
Carriage of stone
Stacking of stones
Land leveling works
Field Bounding works
Excavation of water conservation trench
Removing excavated earth from the trench
Road construction-Cleaning of road with broom
12 | P a g e

<!-- page 15 -->

497/1178
1194/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

25

Filling of water, earth

b. As per the provisions of Para 18, Schedule I of the Mahatma Gandhi NREGA

“a separate Schedule of rates shall be finalized for women, the elderly, people
with disabilities and people with debilitating ailments, so as to improve their
participation through productive work.”
c. Provision of continuous accessible pathways for PWDs throughout the

external/ landscaped areas of the site.

2.

Deendayal Antyodaya Yojana- National Rural Livelihood Mission
(DAY-NRLM)

Deendayal Antyodaya Yojana- National Rural Livelihood Mission (DAYNRLM) has a special focus on priority and early inclusion of the poorest of the poor
and other vulnerable sections of community viz., Households automatically included
by the Socio Economic Caste Census (SECC), Schedule Caste (SC), Schedule Tribe (ST),
Particularly Vulnerable Tribal Groups (PVTGS), women headed families, elderly
persons, People living with different abilities (PwDs), minority groups and people
living in extremist affected areas, hill terrains (hard to reach areas), trafficked women,
people engaged in unhygienic occupations (ex-manual scavengers), transgender,
HIV/AIDS+ persons and their families, families with one or more persons suffering
from chronic illness etc.
Accordingly, NRLM tries and achieves complete inclusion of the entire target
including the poorest and vulnerable communities into their institutional architecture
within a period of initial 18 months of entering an intensive block. NRLM expects the
vulnerable persons to take significant proportion of leadership positions in various
community institutions under NRLM. Further, NRLM facilitates these institutions in
13 | P a g e

<!-- page 16 -->

498/1178
1195/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

achieving their financial and economic/livelihoods inclusion and poverty reduction
goals.

Special provisions for PwDs under DAY-NRLM
All PwD’s (aged one year and above), irrespective of percentage of disability of a
person (even less than 40% of disability) can be a member of PwD SHG (Self Help
Groups) and PwD SHGs are eligible for all funds to communities (RF, VRF, CIF LF)
under NRLM 

1-17 year person with disability, or a person with Mental Disability, Mental
Illness or Mental Retardation, could be represented through his/her legal
guardian/parent/care-giver

as

member

in

the

PwD

SHG.

Legal

guardian/parent/care-giver continues in her own SHG. However, the
members of the concerned group are required to do monitoring to ensure
that the person concerned is getting the benefit.


An individual PwD would be a member of PwD SHG and in case of more
than one PwDs are in a house hold then each PwD would become the
member of PwD SHG as an individual member of PwD SHG.



If a woman with disability is already a member in the existing women SHG
in the village, she would have the liberty to either continue in the same
group or join the PwD SHG. In case she decides to continue in the same
group (non PwD SHG), she should get all other benefit as a PwD.

Key Inclusion Steps for Identification, Mobilization and Institution Building
of PwDs
At Mission level

14 | P a g e

<!-- page 17 -->

499/1178
1196/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

 Sensitize the staff in orientation /refresher workshops, community cadres,

leaders, members and institutions to PwDs and working with them
 Develop Modules and Material.
 PwD SHG Practitioner's Manual (including perceptions on PwD)
 Sensitization/Awareness Building IEC Materials (Print and Digital)
 Training Module for community cadre on Rights and Entitlements of the

PwD
 Resource Module for community cadre on community based social security,

Health & Nutrition (including mental health) and recreational needs of the
PwD
 Resource Module on PwD specific livelihoods
 Train and nurture Community Resource Personal (CRPs) to work with PwD

Agenda

At Village and Cluster levels
 Initiate identification and mobilization of PwDs during the first CRP round

itself.
 Mobilize PwDs into general SHGs or special PwD SHGs. Being a marginalized

group, creating special groups of PwD may be advantageous.
 Mobilize active and assisted PwDs on a saturation mode. A process of self-

selection can be adopted based on ability and agility.
 Mobilize PwDs included in the SECC (auto-included and at least 1

deprivation) and PwDs suffering under multiple vulnerabilities like single
men/women, belonging to SC/ST and minority communities, elderly etc.
 Adopt and strengthen existing PwD SHGs, if any, in the village
 Facilitate Compliance on Panchasutra for each PwDSHG with appropriate

customization

15 | P a g e

<!-- page 18 -->

500/1178
1197/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

 Facilitate community to identify 2-3 Active Women/village to be trained

(including immersion/exposure visits to PwD SHGs and their federal
immersion sites) and deployed as PwD Inclusion Cadres/CRPs
 Mandate

Active

Women,

Inclusion/PwD

CRPs

and

Village

Organizations(VOs) to saturate mobilization; Involve Anganwadi and ASHA
workers in PwD Agenda in the village
 Take up Capacity Building of the PwD SHG members, leaders and cadres as

per the plan. Note that there are three different kinds of PwD’s - Active,
Assisted and Dependent PwDs and their Capacity Building needs and
processes maybe distinctly different.
 Facilitate PwD SHG to access Revolving Fund
 Facilitate PwD SHGs to get federated into VO (federation of women SHG at

the village level). Like other women SHGs, PwD SHGs are entitled to avail
all benefits like CIF, VRF from the VO and higher level federations.
 Facilitate VO to have a sub-committee or a sub-group within Social Action

Committee to regularly monitor and strengthen these PwD groups.
 Facilitate Vulnerability Reduction Plan to include plan for PwDs
 Facilitate Rehabilitation Support to PwDs
 Facilitate PwD centric and/or PwD friendly livelihoods and collectivization

around these activities, where required/feasible
 Facilitate PwD SHGs, for their solidarity, advocacy etc., into a separate

exclusive federation at GP/cluster/block level and at higher levels

3. Rural Connectivity- Pradhan Mantri Gram Sadak Yojana (PMGSY)

The Government of India, as a part of poverty reduction strategy, launched
the Pradhan Mantri Gram Sadak Yojana (PMGSY I) on 25 th December, 2000 as a
Centrally Sponsored Scheme to assist the states, through ‘Rural Roads”. The
16 | P a g e

<!-- page 19 -->

501/1178
1198/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

primary objective of Pradhan Mantri Gram Sadak Yojana (PMGSY) is to provide
connectivity, by way of an all-weather road with necessary culverts and crossdrainage structures, which is operable throughout the year, to eligible unconnected
habitations in rural areas.

As the programme unfolded, a need was felt for consolidation of the existing
Rural Road Network to improve its efficiency not only as a provider of
transportation services, but also as a vehicle of social and economic development.
Accordingly, in the year 2013, PMGSY-II was launched for upgradation of selected
through routes and Major Rural Links (MRLs) with a target to upgrade 50,000 Km
in various states and Union Territories. Subsequently, in 2016, Road Connectivity
Project for Left Wing Extremism Affected Areas (RCPLWEA) for construction/upgradation of strategically important roads was launched as a separate vertical under
PMGSY. In the year 2019, Government launched PMGSY-III for consolidation of
1,25,000 Km Through Routes and Major Rural Links connecting habitations, interalia, to Gramin Agricultural Markets (GrAMs), Higher Secondary Schools and
Hospitals.
All the roads constructed under PMGSY are mapped in GIS- based platforms for
geo-tagging and spatial planning such as GRIMMS, GRISS and Geo-PMGSY and
the data is also made accessible to public and other vendors like Google Maps, etc.
for development of applications which prove to be helpful to physically
challenged/divyang persons.
Since rural roads are generally low traffic volume roads and accident rates are
presently quite low, safety issues relate mainly to universal design and construction
features and road safety consciousness of local residents. As part of the rural road
development and maintenance programmes, guidelines prescribe that the State

17 | P a g e

<!-- page 20 -->

502/1178
1199/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

Government shall ensure road safety audit of PMGSY works along with quality
monitoring. It shall also ensure adequate involvement of Panchayat Raj Institutions.

4. Rural Housing -Pradhan Mantri Awaas Yojana-Gramin (PMAY-G)
The erstwhile rural housing scheme, Indira Awaas Yojana (IAY) had been restructured into Pradhan

Mantri Awaas Yojana – Gramin (PMAY-G) in view of

Government’s commitment to provide “Housing for all” by 2024 and to address the gaps in
the previous housing schemes. The re-structured scheme Pradhan Mantri Awaas Yojana –
Gramin (PMAY-G) came into effect from 1st April 2016. The aim of PMAY-G is to provide a
pucca house with basic amenities to all houseless and households living in
kutcha/dilapidated houses in rural areas of the country.
Under PMAY-G, as per the provisions of the Rights for Persons with Disabilities Act,
2016, as far as possible States/UTs are to ensure that 5% of the beneficiaries are from
among the persons with benchmark disabilities with priority to women with benchmark
disability. Barrier free design should be adopted for the houses constructed under PMAY-G
for the PwDs. Ramp should be constructed for each house allotted to PwD’s. This enables
the PwD’s to have easier movement in and out of the house and this Ramp is to be
constructed by the beneficiary himself/herself within the assistance provided for
construction of house.

5.

National Social Assistance Programme (NSAP)

Article 41 of the Constitution of India directs the State to provide public assistance
to its citizens in case of unemployment, old age, sickness and disablement and in other
cases of undeserved want within the limit of its economic capacity and development.
Directive Principles of State Policy enshrined in the Constitution of India enjoin upon
the State to undertake within its means a number of welfare measures. It is in
accordance with these noble principles that the Government of India introduced
National Social Assistance Programme (NSAP) in 1995 as a Centrally Sponsored
18 | P a g e

<!-- page 21 -->

503/1178
1200/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

Scheme under which 100 per cent Central assistance is extended to the States/UTs to
provide the benefits in accordance with the norms, guidelines and conditions laid
down by the Central Government.
NSAP is a social assistance programme for poor households- for the aged, widows,
and disabled in the case of death of the breadwinner, thereby aiming at ensuring
minimum national standards in addition to the benefits that the States are providing
or might provide in future. The intention in providing hundred per cent central
assistance is to ensure that social protection to the beneficiaries is available throughout
the country. States are free to add on and expand their coverage.
Indira Gandhi National Disability Pension Scheme (IGNDPS) is a sub-scheme of
National Social Assistance Programme (NSAP), under which, central assistance @
Rs.300 per month is provided to persons aged 18-79 years with severe and multiple
disabilities and belonging to family living below poverty line as per the criteria
prescribed by Government of India. After attaining the age of 80 years, the
beneficiaries are shifted to Old Age Pension Scheme for getting pension of Rs. 500/per month.

19 | P a g e

<!-- page 22 -->

504/1178
1201/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

5
*Accessibility Features for Roads, Buildings and Public Facilities in
Rural Areas
A. Rural Roads


Provision of continuous accessible pathways for PWDs throughout the external/
landscaped areas of the work site under MGNREGA.



Provision of gratings on open drains.



Linkages and transitional spaces should not form obstacles to users.



If a pathway leads to a spatial change or a change in level, directional cues such
as signage, kerbs, handrails, fences, hedges, or other continuous elements etc.
should be provided at strategic locations to maintain travel continuity for the
user. This is particularly important for visually impaired users to continue along
the travel path to reach their destination.



Kerb ramps with tactile warning and color contrast to be provided to bridge level
differences less than 150 mm along pathways.



Edges of pathways should be clearly defined by using different colours /
textures. Street furniture, trees, lighting and dustbins should be located on one
side of pathways.



Texture, color and pattern of the change in floor surfaces, as well as the lighting
effect on the floor surface, should not be too sudden as to cause hazard to users.
Junction between the different floor surfaces should be leveled; any gaps or
expansion joints between different materials should not exceed 13 mm wide.

20 | P a g e

<!-- page 23 -->

763910/2022/NSAP
903230/2023/NSAP



505/1178
1202/126

J-11060/01/2021-NSAP

Grating provided if any at the entrance gate should have spaces not greater than
13 mm wide in one direction to avoid trapping of crutches or wheels, and be
placed so that Channel grating slots should not be parallel to the traffic direction.



Tapping rails should be provided for visually impaired visitors where tactile
guiding
iding path cannot be provided.



Paths and routes should be monitored and maintained particularly in the high
season.



Low-level
level bollards are hazardous and should be avoided.



Provide a raised zebra crossing at the same height as that of accessible pathway
to cross the vehicular road.



Alternatives to loose gravel can be sourced for paths and routes into the natural
landscape. Access to rougher / undulating or less firm terrain can be provided
over short distances with different types of board walk or roll able tactile mats.



Boardwalks can be covered in wire mesh to reduce slipping in damp areas.

21 | P a g e

<!-- page 24 -->

763910/2022/NSAP
903230/2023/NSAP



506/1178
1203/126

J-11060/01/2021-NSAP

If carpets or carpet tiles are used on a floor surface, they should be securely
attached to it. Long, thick rugs should not be laid in areas likely to be frequented
by persons with mobility and sight impairments.



Bollards if provided should have a colour or luminance contrast feature and
should have clear distance of 1200mm between them

B. Buildings in Rural Areas

a. Entrance


Every building should have at least one entrance accessible to the handicapped
and shall be indicated by proper signage. This entrance shall be approached
through a ramp together with the stepped entry.



Minimum clear opening of the entrance door shall be 900 mm. and it shall not be
provided with a step that obstructs the passage of a wheel chair user. Threshold
shall not be raised more than 12 mm.

b. Accessible Pathways/ Walkways


Provision of continuous accessible pathways for PWDs throughout the external/
landscaped areas of the site.



Improvements to existing ramps, addition of handrails to long ramps.



The accessible path should preferably lead to all important attractions and
vantage points in the site.



All pathways should be firm and slip-resistant.



Pathways and corridors should be wide enough for wheelchair users. Provision
of Safety kerbs around unguarded fountains.



Provision of gratings on open drains.



Linkages and transitional spaces should not form obstacles to users.



If a pathway leads to a spatial change or a change in level, directional cues such
as signage, kerbs, handrails, fences, hedges, or other continuous elements etc.
should be provided at strategic locations to maintain travel continuity for the

22 | P a g e

<!-- page 25 -->

763910/2022/NSAP
903230/2023/NSAP

507/1178
1204/126

J-11060/01/2021-NSAP

user. This is particularly important for visually impaired users to continue along
the travel path to reach their destination.


Kerb ramps with tactile warning and color contrast to be provided to bridge level
differences less than 150mm along pathways.



Edges of pathways should be clearly defined by using different colours /
textures. Street furniture, trees, lighting and dustbins should be located on one
side of pathways.



Texture, color and pattern of the change in floor surfaces, as well as the lighting
effect on the floor surface, should not be too sudden as to cause hazard to users.
Junction between the different floor surfaces should be leveled; any gaps or
expansion joints between different materials should not exceed 13mm wide.



Continuous tactile guide path should be provided on all the pathways right from
the entrance to all major facilities, information counters, Braille maps/directories,
ramps, steps and lifts, for independent navigation of PwDs.



Grating provided if any at the entrance gate should have spaces not greater than
13 mm wide in one direction to avoid trapping of crutches or wheels, and be
placed so that Channel grating slots should not be parallel to the traffic direction



Provide a raised zebra crossing at the same height as that of accessible pathway
to cross the vehicular road.



Tapping rails should be provided for visually impaired visitors where tactile
guiding path cannot be provided.



Paths and routes should be monitored and maintained particularly in the high
season.



Alternatives to loose gravel can be sourced for paths and routes into the natural
landscape. Access to rougher / undulating or less firm terrain can be provided
over short distances with different types of board walk or rollable tactile mats.



Boardwalks can be covered in wire mesh to reduce slipping in damp areas.



If carpets or carpet tiles are used on a floor surface, they should be securely
attached to it. Long, thick rugs should not be laid in areas likely to be frequented
by persons with mobility and sight impairments.



Low-level bollards are hazardous and should be avoided.



Bollards if provided should have a colour or luminance contrast feature and
should have clear distance of 1200mm between them.

23 | P a g e

<!-- page 26 -->

508/1178
1205/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

C. Accessibility of Public Facilities

a. Toilets


A full range of user
user-friendly
friendly provisions should be made to reach the
toilet blocks including tactile guide path, floor plan with illustrations in
written text and Braille, and large information signs.



Accessible toilets should have the universally adopted symbol for
wheelchair access displayed outside.



Improvement to existing General Public Facili
Facilities.



Location of general/ accessible Public Facilities to be marked on all
tactile pictographic maps.



Unisex accessible toilets are preferable for the caretaker to assist the
wheelchair user. Recommended clear floor space -2000
2000 mm x 2200 mm
minimum.



Where provision of independent unisex accessible toilet blocks is not
feasible, Accessible public facility cubicles should be provided within
the existing ladies and gents toilets by reconfiguring internal layout to
achieve an ideal size of 2000mm x2200mm.

24 | P a g e

<!-- page 27 -->

763910/2022/NSAP
903230/2023/NSAP

509/1178
1206/126

J-11060/01/2021-NSAP



Drinking water fountains of two mounting heights should be provided
and preferably located near the toilet blocks but away from the toilet
entrances.



A step free leveled tactile guiding path to be provided in the floor from
corridors/ walkways leading to the accessible toilet blocks.



The main entrance door/opening to the public facility and internal
cubicles should be minimum 900mm in width.



There should be no level differences inside all toilet blocks. Existing
level differences to be removed or leveled to facilitate easy wheelchair
movement.



Facilities should have wide and level layouts with good colour contrasts
providing enough space for wheelchairs.



Modification of Public Facilities, including changing of damaged
plumbing, sanitary, electrical and water supply fittings and appliances.



There should be signage using the international symbol of accessibility
to identify the accessible public facilities. Signage should be multi
lingual and tactile.



Floor surface material must be non-slippery but should not trap dirt or
water.



Effective floor drainage should be provided to maintain a dry floor
surface.



Floor drain covers should be fixed flat on the floor surface without any
projections to prevent people from tripping over.



WC (Water closet) or toilet compartments should have enough floor
space and 900 mm wide step-free doors for wheelchair users to enter
and exit.



The WC (Water closet) should be preferably wall hung and in a position
as to permit easy approach by wheelchair users.



The seat of the WC should be at the correct height for the wheelchair
users.
25 | P a g e

<!-- page 28 -->

763910/2022/NSAP
903230/2023/NSAP

510/1178
1207/126

J-11060/01/2021-NSAP



WC (Water closet) compartments should have support rails / grab bars
at a position and height suitable for wheelchair users and other persons
with physical disabilities. Upward- folding grab bars are recommended
to allow lateral transfer from the wheelchair.



WC should be mounted at a height between 450mm –480mm.

b. Accessible Drinking Water Facility


Drinking fountains should have spouts positioned at the front of the
unit. The spout shall direct the water flow in a path almost parallel to
the front of the unit.



For wheel chair users, spouts not higher than800mm from the floor are
recommended.



Best practice is to provide a clear floor space at least 750mm
by 1200mm for wheelchair users. Knee space and toe space should be
provided underneath the fountain. A toe space of minimum 230mm
from the floor and knee space of 700mm from the floor to the underside
of fountain are required.



Controls should be front mounted or side mounted near the front edge
and easily operated with one hand.



Flow of water should be at least 100mm high so as to allow the insertion
of a cup or glass under the flow of water.



For drinking fountain having a round or oval bowl, the spout must be
positioned so the flow of water is within 75mm of the front edge of the
fountain

* Guidelines of Centre Public Works Department (CPWD) have also been referred

26 | P a g e

<!-- page 29 -->

511/1178
1208/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

6
Information Technology and Communication Ecosystem

The website of the Department of Rural Development (DoRD) and those relating
to the Schemes being implemented by DoRD outlining the basic features of the schemes,
eligibility, application, status of application, registration, benefits, monitoring,
grievance redressal etc, should be guided by the following:


Web accessibility means that people with disabilities can also perceive,
understand, navigate, and interact with the Web, and that they can contribute to
the Web. It encompasses all disabilities that affect access to the Web, including
visual, auditory, physical, speech, cognitive, and neurological disabilities.



Thus the impact of persons with disabilities is radically changed on the Web
because the Web removes barriers to communication and interaction that many
people face in the physical world. When websites, web technologies, or web tools
are badly designed, they can create barriers that exclude people from using the
web.



The Website and apps should be designed and developed in such way that they
are accessible by all people, whatever may be their hardware, software,
language, culture, location, or physical or mental ability.



Web Content Accessibility Guidelines (WCAG) covers a wide range of
recommendations for making Web content accessible.



The WCAG are organized around the four principles, which lay the foundation
necessary for anyone to access and use Web content. These require the web
content to be;

27 | P a g e

<!-- page 30 -->

763910/2022/NSAP
903230/2023/NSAP

512/1178
1209/126

J-11060/01/2021-NSAP

(a). Perceivable: users must be able to perceive the information being presented
i.e. it can't be invisible to all of their senses.
(b). Operable: users must be able to operate the interface and the interface cannot
require interaction that a user cannot perform.
(c). Understandable: users must be able to understand the information as well as
the operation of the user interface.
(d). Robust: users must be able to access the content as technologies advance.


The page title (the title specified by HTML <title> tag which appears on the top
bar of the browser) MUST describe the topic and purpose of the page. Page title
should be complete with the name of the country included, for instance, instead
of the title being just Department of Rural Development, it should state,
Department of Rural Development, Ministry of Rural Development, Government
of India. Alternatively, in case of a State Government Department, it should state
‘Department of Rural Development, Government of Karnataka, and India’. This
will not only facilitate an easy and unambiguous identification of the website but
would also help in a more relevant and visible presence in the search engine
results. Further, it is important since the screen readers used by the visually
impaired users first read the title of the page and in case the title is not
explanatory enough, it may confuse or mislead them.



The language of complete web page MUST be indicated programmatically by the
use of lang attribute. If there are any changes in the default language of the
document, either in the document’s text or any text equivalents (e.g., captions),
they MUST also be clearly identified.



Components that have the same functionality within a set of Web pages, MUST
be identified consistently. If identical functions have different labels on different
Web pages, the site will be considerably more difficult to use. It may also

28 | P a g e

<!-- page 31 -->

513/1178
1210/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

be confusing and increase the cognitive load for people with cognitive
limitations.


It is imperative that the information and services on the website are well
organised and categorized into relevant modules/sections and sub-sections so
that any information can be located conveniently and is not buried deep inside
WebPages. These sections or categories may be identified with headings or
labels. Headings wherever used MUST correctly describe topic or purpose of
content. Headings must be specified using HTML heading tags (H1 to H6) with
proper hierarchy. When headings are clear and descriptive, users can find the
information they seek more easily, and they can understand the relationships
between different parts of the content more easily. Descriptive labels help users
identify specific components within the content. Labels and headings do not
need to be lengthy. A single word may suffice if it provides an appropriate cue to
finding and navigating content. Sighted users perceive structure and
relationships through various visual cues present on a page (page headings are
in a larger and bold font; list items are preceded by a bullet; form fields may be
positioned as groups that share text labels; a different background color may be
used to indicate related items and so on). However visually challenged users
cannot take advantage of these cues. It must be ensured that these information’s
and relationships are preserved even when the presentation format changes. (For
example when the content is read by a screen reader or CSS is turned off or
replaced). Therefore departments MUST ensure that Information, structure, and
relationships

conveyed

through

presentation

can

be

programmatically

determined or are available in text.


When the sequence in which content is presented affects its meaning, a correct
reading sequence MUST be programmatically determined. This helps people
who rely on assistive technologies like screen readers because the meaning
evident in the sequencing of the information in the visual presentation will be the
29 | P a g e

<!-- page 32 -->

514/1178
1211/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

same when the content is presented in spoken form. This also preserves the
meaning of the page when the CSS is turned off or not supported. It should be
noted that a sequence is meaningful if change of order shall impact its meaning.
Two independent content items like two separate articles in a page may be
placed in any sequence without affecting the meaning. Similarly the navigation
block and the content area may be placed in any sequence without affecting their
meaning.


A consistent page layout with reference to navigation elements MUST be
maintained throughout the site, i.e., placement of navigation elements should be
uniform across the website.



It is author’s responsibility to create Web content that does not prevent the user
agent (e.g. browser) from scaling the content effectively, therefore Except for
captions and images of text, text MUST be resizable without the use of assistive
technology by up to 200% without loss of content or functionality.



Proper contrast between text and background is essential for users who have low
vision. Therefore, the visual presentation of text and images of text MUST have a
contrast ratio of at least 4.5:1except:

 If the text is purely for decorative purpose.
 Is not visible. or Is a part of an inactive user interface.
 Is a part of a logo where it has no minimum contrast requirement
 That are part of a picture that contains significant other visual content.
 If the text is substantially large in size (18 pt or 14 pt bold) it must have a
contrast ratio of 3:1.

 Color is an important asset in presentation of Web content
however, some users have difficulty perceiving color e.g. People with
partial sight or older users who do not see color well. In addition there are

30 | P a g e

<!-- page 33 -->

515/1178
1212/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

people using text-only, limited-color or monochrome displays and
browsers. If a page has information that is conveyed by color differences
like: “required fields are red”, “error is shown in red”, and “January sales
are in red, July are in blue” or indications of an action like using color to
indicate that a link will open in a new window then these users may not
be able to access such information. Therefore


It MUST be ensured that Color is not used as the only visual means of conveying
information, indicating an action, prompting a response, or distinguishing a
visual element.



Use of images for representing text should be limited Though images add life to
a website, they also increase downloading time. Images should only be used
when it adds value to the content. Images should not be used to present text as
those using text only browsers shall not be able to access the information thus
rendering the site inaccessible to many. Therefore, text MUST be used to convey
information rather than images of text except when the image of text can be
customized to the users requirement or when a particular representation of text
is essential for the information being conveyed (such as a text in a logotype): The
use of text, rather than images of text, should be considered for page headings
and website navigation items(Menus).



Images and other non text content MUST be made Accessible. A meaningful
explanatory text equivalent MUST be specified for images and other non text
content e.g. by using the ALT attribute. The ALT text for an image is displayed
before the image is fully downloaded. It is the main source of image information
for users of text-only browsers, users of browsers with graphics turned off, and
users who are sight impaired. The description should summaries the content or
purpose of the image. For example, to use the description ‘Picture’ to explain a
graphic does not serve any purpose.
31 | P a g e

<!-- page 34 -->

763910/2022/NSAP
903230/2023/NSAP



516/1178
1213/126

J-11060/01/2021-NSAP

Text Equivalents for Video and Audio Clips: In order to ensure that content of
video

and

audio

clips

is

accessible

to

all,

including

those

with impaired vision, hearing impaired or those accessing the information on
slow connections:

a.

Government websites MUST provide equivalent information of audio only/
video only clips (e.g. a text description of the audio/video). In case of video
only clips audio description of the video may also be provided in place of
text.

b. When audio (live or pre recorded) is synchronized with other media for
presenting information the audio information MUST be presented as captions for
the benefit of hearing impaired or those who do not have access to audio.
Captions must not only include dialogue, but identify who is speaking and
include non-speech information conveyed through sound, including meaningful
sound effects. In case of video presented in synchronized media audio
descriptions must be provided (if all of the information in the video track is
already provided in the audio track, no audio description is necessary).


The use of animation can be an effective means for drawing attention to key
aspects of a website. However, Government websites should ensure that
animations used on the site do not distract or irritate users or lead to
unacceptable download times. Animation should be used only if it adds value to
a page. File sizes of animated images should be kept small by limiting the
number of frames.



Navigational mechanisms that are repeated on multiple Web pages within a set
of Web pages MUST occur in the same relative order each time they are repeated,
unless a change is initiated by the user.

32 | P a g e

<!-- page 35 -->

763910/2022/NSAP
903230/2023/NSAP



517/1178
1214/126

J-11060/01/2021-NSAP

Web pages and applications often have content that is repeated on other pages or
screens (for example navigation links, heading graphics, banner frames etc). A
sighted user can ignore the repeated material by focusing on the main content
area but it is not possible for a person using a screen reader as the content is read
sequentially. Therefore Web pages MUST provide

a mechanism to bypass

blocks of content that are repeated on multiple Web pages. This may be done by
providing a link at the top of each page that goes to the main content area.


Government websites MUST include either a “Search” box or a link to a “Search”
page from every page of the website. The search box or link must be titled
“Search”, as it is a standard term understood by web surfer’s world over. As per
internationally accepted Usability principles, search boxes are most effective
when placed in the same position on all pages (usually within the upper third
part of the webpage).



Every Indian Government website MUST have a ‘Sitemap’ linked through to
Homepage as well as all important entry pages of the site.



It MUST be ensured that in content implemented using markup languages,
elements have complete start and end tags, elements are nested according to
their specifications, elements do not contain duplicate attributes, and IDs , if any,
are unique, except where the specifications allow these features. This helps to
ensure that user agents, including assistive technologies, can accurately interpret
and parse content. If the content cannot be parsed, then different user agents may
present it differently. Some user agents use “repair techniques” to render poorly
coded content. Since repair techniques vary among user agents, authors cannot
assume that content will be rendered correctly by specialized user agents.



Labels or instructions MUST be provided when content requires user input (for
example in forms). Text instructions that describe the input must be provided at
the beginning of a form or set of fields. Elements associated with input must be
33 | P a g e

<!-- page 36 -->

518/1178
1215/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

labeled to ensure that information about the input field is spoken by screen
readers when the field receives focus.


In situations where web functions are time-dependent, (for example, filling
out online form) it will be difficult for people with disabilities such as blindness,
low vision, dexterity impairments, and cognitive limitation stopper form the
required functions before a time limit occurs. This may render the service
inaccessible to them. It must therefore be ensured that such users are given
adequate time to interact with Web content whenever possible. For each time
limit that is set by the content, the user MUST be allowed to turn off the time
limit, adjust the default setting before encountering it or is warned before time
expires and given option to extend the time limit with a simple action (for
example, “press the spacebar”).



Many users including the visually challenged cannot perceive shape, size or use
information about location or orientation. For such users the content that relies
on knowledge of the shape or position of objects becomes inaccessible (for
example, “round button” or “button to the right”). Hence, It MUST be ensured
that instructions provided for understanding and operating content do not rely
solely on sensory characteristics of components such as shape, size, visual
location, orientation, or sound. Additional information needs to be provided to
clarify anything that is dependent on this kind of information.



If an input error is automatically detected, the error MUST be described to the
user in text.

The error message should be as specific as possible. This will

ensure that users are aware that an error has occurred and can determine what is
wrong. Describing the error in text in addition to highlighting the errors will help
screen reader users, who cannot distinguish colors and users with cognitive
disorders that have difficulty in perceiving the meaning of other visual cues.

34 | P a g e

<!-- page 37 -->

763910/2022/NSAP
903230/2023/NSAP



519/1178
1216/126

J-11060/01/2021-NSAP

All functionality of the content MUST be operable through a keyboard interface
without requiring specific timings for individual keystrokes, except where input
depends on the path of the user’s movement (for example, drawing free hand
curve or using handwriting to write)



Whenever a web page is rendered using plug-ins or embedded applications, it is
possible that functionality of the Web page restricts the keyboard focus to a
subsection of the content, unless the user knows how to leave that state and
“entrap” the focus. This situation may affect navigation for people who rely on a
keyboard or keyboard interface to use the Web, including visually challenged
and people with physical disabilities. Therefore, it MUST be ensured that if focus
can be moved to a component of the page using a keyboard interface, then focus
can be moved away from that component using only a keyboard interface, and,
if



it is not possible the user is advised of the method for moving focus away.

It MUST be ensured that the purpose of each link can be determined from the
link text alone or from the link text along with its programmatically determined
link context e.g. by using

title attribute as a tool tip to clarify the purpose of

link.


When any component receives focus, it MUST not initiate a change of context.
Developers must use “activate” rather than “focus” as a trigger for change of
context. This ensures that functionality is predictable as visitors navigate their
way through a webpage. (Examples of changing context when a component
receives focus include forms being submitted automatically when a component
receives focus or new windows launched when a component receives focus).



Entering data or selecting a form control must have predictable effects. Changing
the setting of any user interface component MUST not automatically cause a
change of context unless the user has been advised of the behavior before using

35 | P a g e

<!-- page 38 -->

520/1178
1217/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

the component. Unexpected changes of context can be disorienting for users with
visual disability so cognitive limitations.


When users navigate sequentially through content, they should encounter
information in an order that is consistent with the meaning of the content and
can be operated from the keyboard. Hence if a Web page can be navigated
sequentially and the navigation sequences affect meaning or operation, focusable
components MUST receive focus in an order that preserves meaning and
operability.



For all user interface components, it is a MUST that the name and role can be
programmatically

determined;

states,

properties,

and

values

can

be

programmatically set; and notification of changes to these items is available to
assistive technologies.


Any keyboard operable user interface MUST have a mode of operation where the
keyboard focus indicator is visible. This helps the user know which element
among the multiple elements present in the page has focus. For e.g., in case of a
button a visual change in the button (e.g. color, size) can indicate that the focus is
on the button.



If an input error is automatically detected and suggestions for correction are
known, then the suggestions MUST be provided to the user, unless it would
jeopardize the security or purpose of the content. Input error occurs if the user
omits certain information that is required by the webpage, or the information
provided by the user is not in the correct format or falls outside the permissible
value. This is to ensure that the users receive appropriate suggestions for
correction of input errors if possible.



For Web pages that cause legal commitments or financial transactions for the
user to occur, that modify or delete user-controllable data in data storage

36 | P a g e

<!-- page 39 -->

521/1178
1218/126

J-11060/01/2021-NSAP

763910/2022/NSAP
903230/2023/NSAP

systems, or submit user test responses, at least one of the following MUST be
true:
1. Reversible: Submissions are reversible.
2. Checked: Data entered by the user is checked for input errors and the user is
provided with an opportunity to correct them.
3. Confirmed: A mechanism is available for reviewing, confirming, and correcting
information before finalizing the submission.

Note: The Guidelines of Web content Accessibility Guidelines (WCAG) 2.0 have been referred to in this
chapter

37 | P a g e

<!-- page 40 -->

763910/2022/NSAP
903230/2023/NSAP

522/1178
1219/126

J-11060/01/2021-NSAP

7

Bibliography


Harmonized Guidelines and Space Standards for Barrier Free Built Environment
for persons with disability and elderly persons, 2016, Ministry of Urban
Development, Government of India.



Guidelines of Centre Public Works Department (CPWD)



Web Content Accessibility Guidelines (WCAG) 2.0.



Guidelines of Ministry of Civil Aviation



Guidelines of Ministry of Road Transport and Highways



Guidelines of Ministry of Culture



Demystifying Accessibility in Built Infrastructure, Department of Persons with
Disabilities, Ministry of Social Justice and Empowerment, Government of India.



Guidelines of Mahatma Gandhi NREGA.



Guidelines of Pradhan Mantri Gram Sadak Yojana (PMGSY).



Guidelines of DAY-NRLM



Guidelines of Rural Connectivity – PMGSY



Guidelines of Rural Housing – PMAY(G)

38 | P a g e

<!-- page 41 -->

1142/117
1220/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP
रजिस्ट्री सं. डी.एल. (एन) 04/0007/2003—05

REGD. NO. D. L. (N) 04/0007/2003—05

xxxGIDHxxx
सी.जी.-डी.एल.-सा.-12072023-247235
xxxGIDExxx
CG-DL-W-12072023-247235

प्राजिकार से प्रकाजित
PUBLISHED BY AUTHORITY
साप्ताजिक
WEEKLY
सं. 25]

नई दिल्ली, िुलाई 2—िुलाई 8, 2023, िजनवार/ आषाढ़ 11—आषाढ़ 17, 1945

No. 25]

NEW DELHI, JULY 2—JULY 8, 2023, SATURDAY/ASHADHA 11—ASHADHA 17, 1945

इस भाग में जभन्न पृष्ठ संख्या िी िाती िै जिससे दक यि पृथक संकलन के रुप में रखा िा सके
Separate Paging is given to this Part in order that it may be filed as a separate compilation
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
भारत सरकार के मंत्रालयों (रक्षा मंत्रालय को छोड़कर) और के न्रीय अजिकाररयों (संघ राज्य क्षेत्र प्रिासनों को छोड़कर) द्वारा जवजि के
अंतगगत बनाए गए और िारी दकए गए सािारण सांजवजिक जनयम (जिनमें सािारण प्रकार के आिेि, उप-जनयम आदि सजममजलत िैं)
General Statutory Rules (Including Orders, Bye-laws etc. of a general character) issued by the Ministries of the
Government of India (other than the Ministry of Defence) and by the Central Authorities (other than the
Administrations of Union Territories)

ग्रामीण जवकास मंत्रालय
(ग्रामीण जवकास जवभाग)
(एन.एस.ए.पी. प्रभाग)
नई दिल्ली, 26 िून, 2023
सा.का.जन. 77.—सक्षम प्राजिकारी द्वारा यथा अनुमोदित, संलग्र ग्रामीण क्षेत्र जवजिष्ट सुसंगत सुगमयता
मानक/दििाजनिेि भारत के रािपत्र में भाग-II, खंड-3, उप खंड (i) के अंतगगत, आवश्यकता अनुसार प्रकाजित दकए िाएं।
[फा.सं. िे-11060/01/2021-एन.एस.ए.पी]
कल्याणी जमश्रा, आर्थगक सलािकार
4035 GI/2023

(433)

<!-- page 42 -->

903230/2023/NSAP
881918/2023/NSAP
434

1143/117
1221/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

संजक्षप्त रूप
क्र.सं.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.
42.

संजक्षप्त रूप
एटीआर
बीपीएल
सीआईएफ
सीआरपी
डीआरपी
एफएम
िीपी
िीआरआईएमएमएस
िीआरआरआईएस
िीएस
आईएपी
आईसीटी
आईईसी
आईिीएनडीपीएस
आईिीएनओएपीएस
आईिीएनडब्‍ल्यूपीएस
एमिीएनआरईिीए
एमआईएस
एमओआरडी
एनएफबीएस
एनिीओ
एनएलएम
एनआरएलएम
एनएसएपी-पीपीएस
एनयूएलएम
पीएमएवाई-िी
पीएमयू
पीओ
पीआरआई
आरएफ
आरएसबीवाई
आरटीआई
एसएयू
एससी
एसईसीसी
एसएचिी
एसटी
यूसी
यूएलबी
वीओ
वीआरएफ
वीआरपी

पूणग प्रपत्र
कारग वाई ररपोटग
गरीबी रे खा से नीचे
सामुिाजयक जनवेि जनजि
सामुिाजयक संसािन कार्मगक
जिला संसािन व्यजि
जवत्तीय िुर्वगजनयोिन
ग्राम पंचायत
िीआईएस सक्षम सड़क सूचना प्रबंिन और जनगरानी प्रणाली
भू-स्ट्थाजनक ग्रामीण सड़क सूचना प्रणाली
ग्राम सभा
एकीकृ त कायग योिना
सूचना और संचार प्रौद्योजगकी
सूचना, जिक्षा और संचार
इं दिरा गांिी राष्ट्रीय जवकलांगता पेंिन योिना
इं दिरा गांिी राष्ट्रीय वृद्धावस्ट्था पेंिन योिना
इं दिरा गांिी राष्ट्रीय जविवा पेंिन योिना
मिात्मा गांिी राष्ट्रीय ग्रामीण रोिगार गारं टी अजिजनयम
प्रबंिन सूचना प्रणाली
ग्रामीण जवकास मंत्रालय
राष्ट्रीय पाररवाररक लाभ योिना
गैर-सरकारी संगठन
राष्ट्रीय स्ट्तरीय जनगरानी
राष्ट्रीय ग्रामीण आिीजवका जमिन
राष्ट्रीय सामाजिक सिायता कायगक्रम- पेंिन भुगतान प्रणाली
राष्ट्रीय ििरी आिीजवका जमिन
प्रिानमंत्री आवास योिना - ग्रामीण
कायगक्रम प्रबंिन इकाई
डाकघर
पंचायती राि संस्ट्थाएं
पररक्रामी जनजि
राष्ट्रीय स्ट्वास्ट््य बीमा योिना
सूचना का अजिकार
सामाजिक लेखा परीक्षा इकाई
अनुसूजचत िाजत
सामाजिक आर्थगक और िाजतगत िनगणना
स्ट्व-सिायता समूि
अनुसूजचत िनिाजत
उपयोजगता प्रमाण पत्र
ििरी स्ट्थानीय जनकाय
ग्राम कायागलय
गरीबी उपिमन जनजि
ग्राम संसािन व्यजि

<!-- page 43 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1144/117
1222/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

435

अध्याय 1
भूजमका
1.1
दिव्यांग जवश्वभर की आबािी का एक बड़ा जिस्ट्सा िै। कु छ क्षेत्रों में बुिुगग आबािी में वृजद्ध तथा उसी के साथ बुिुगों
में बीमार व्यजियों की संख्या बढ़ने के कारण दिव्यांग व्यजियों की संख्या भी बढ़ रिी िै। जवश्व स्ट्वास्ट््य संगठन
(डब्‍ल्यूएचओ) का अनुमान िै दक वषग 2011 में जवश्वभर में दिव्यांग व्यजियों की संख्या लगभग 1 जबजलयन थी, जिसका
अथग यि िै दक जवश्वभर की लगभग 15 प्रजतित आबािी दकसी न दकसी प्रकार की दिव्यांगता से ग्रस्ट्त िै। आने वाले ििकों
में दिव्यांग व्यजियों की आबािी बढ़ने का िी अनुमान िै।
1.2
दिव्यांग व्यजियों के अजिकारों के संबंि में संयुि राष्ट्र अजभसमय का भारत द्वारा अनुसमथगन दकए िाने के
पररणामस्ट्वरूप यि आवश्यक िो गया िै दक िेि के ििरी और ग्रामीण क्षेत्रों में दिव्यांग व्यजियों को भौजतक वातावरण,
पररविन और सूचना एवं संचार सुजविाएं अन्य लोगों के समान िी उपलब्‍ि िों। इस दििा में पिला किम उठाते हुए भारत
के माननीय प्रिान मंत्री ने जनर्मगत भौजतक अवसंरचना, पररविन व्यवस्ट्था तथा सूचना एवं संचार प्रौद्योजगक (आईसीटी)
व्यवस्ट्था के तीनों घटकों में बािाओं से मुि वातावरण तैयार करने के जलए एक्सेजसबल इं जडया कं पेन या सुगमय भारत
अजभयान दिनांक 03 दिसमबर, 2015 को िुरू दकया।
1.3 सुगमय भारत अजभयान (एआईसी) का उद्देश्य सुगमय सुजविाओं एवं सेवाओं के मानकीकृ त, सिि और अंतरराष्ट्रीय
जवकास के जलए समाि में मागगििगन पर आिाररत बिलाव के माध्यम से सुगमय अवसंरचना की भौजतक पररसंपजियों का
जनमागण करना िै। इस अजभयान के उद्देश्य की पूर्तग के जलए जनिागररत दकए गए मूल जसद्धांत इस प्रकार िैं :(i) सावगभौजमक जडिाइन (सिायक उपकरणों और उन्नत प्रौद्योजगदकयों के प्रयोग के जलए अनुकूलन या जविेषीकृ त जडिाइन
तैयार करने की आवश्यकता के जबना यथासंभव सभी के द्वारा प्रयोग दकए िा सकने वाले उत्पािों, पररवेिों, कायगक्रमों और
सेवाओं का जडिाइन)
(ii) युजियुि सुजविा (अन्य लोगों के समान िी दिव्यांग व्यजियों को अजिकारों की प्राजप्त सुजनजित करने के जलए दकसी भी
जवजिष्ट मामले में गैर-आनुपाजतक या अनुजचत बोझ डाले जबना आवश्यक एवं उपयुि आिोिन एवं समायोिन)
1.4 सुगमय भारत अजभयान ‘दिव्यांगिन अजिकार अजिजनयम, 2016 (आरपीडब्‍ल्यूडी अजिजनयम)’ में उजल्लजखत
‘सुगमयता’ के उपबंिों को साकार करने के सािन की भी भूजमका जनभाता िै। आरपीडब्‍ल्यूडी अजिजनयम, 2016 में िारा
40 से िारा 46 में सुगमयता को इस प्रकार अजििेजित दकया गया िै :
1.4.1 िारा 40: के न्रीय सरकार, मुख्य आयुि के परामिग से समुजचत प्रौद्योजगदकयों और प्रणाजलयों तथा ििरी और
ग्रामीण क्षेत्रों में िनता को प्रिान की गई सुजविाओं और सेवाओं सजित भौजतक वातावरण, पररविन, िानकारी और
संसूचना के जलए पहुंच के मानकों को अजिकजथत करते हुए दिव्यांगिनों के जलए जवजनयम जवरजचत करेगा।
1.4.2 िारा 41: (1) समुजचत सरकार, जनम्नजलजखत का उपबंि करने के जलए उपयुि उपाय करे गी,---(क) बस अड्डे और रे लवे स्ट्टेिनों तथा िवाई अड्डों पर दिव्यांगिनों के जलए ऐसी सुजविाएं प्रिान करना िो पार्किं ग स्ट्थलों,
प्रसािनों रटकट जखड़दकयों और रटकट मिीनों से संबंजित पहुंच मानकों के अनुरूप िों।
(ख) पररविन के सभी ढंगों तक पहुंच प्रिान करना िो पररविन के पि दफटटंग पुराने ढंगों सजित जडिाइन मानकों के
अनुरूप िों, ििां कभी वे दिव्यांगिनों के जलए प्रौद्योजगक रूप से संभाव्य और सुरजक्षत िों आर्थगक रूप में व्यविायग िों और
जडिाइन में मुख्य संरचना के पररवतगन में भार डाले जबना िो।
(ग) दिव्यांगिनों के जलए आवश्यक गजतिीलता के समािान के जलए पहुंच योग्य सड़कें ।
(2) समुजचत सरकार, जनम्नजलजखत के जलए उपबंि करने के जलए विन करने योग्य लागत पर दिव्यांगिनों की वैयजिक
गजतिीलता के संविगन के जलए स्ट्कीमों कायगक्रमों को जवकजसत करे गी(क) प्रोत्सािन और ररयायतें;
(ख) वािनों की पि दफटटंग; और

<!-- page 44 -->

903230/2023/NSAP
881918/2023/NSAP
436

1145/117
1223/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

(ग) वैयजिक गजतिीलता सिायता।
1.4.3 िारा 42 : समुजचत सरकार यि सुजनजित करने के जलए उपाय करेगी दक(क) श्रव्य, प्प्रंट और इलैक्राजनक मीजडया में उपलब्‍ि सभी अंतवगस्ट्तुएं पहुंच योग्य फामेट में िैं;
(ख) श्रव्य वणगन, संकेत भाषा जनवगचन और क्लोज्ड के पिप्नंग, उपलब्‍ि कराके दिव्यांगिन की इलैक्राजनक मीजडया तक
पहुंच िै;
(ग) इलैक्राजनक माल और उपस्ट्कर िो प्रजतदिन उपयोग के जलए सवगव्यापी जडिाइन में उपलब्‍ि कराए िाने के जलए
आिजयत िैं।
1.4.4 िारा 43: समुजचत सरकार दिव्यांगिनों के सािारण उपयोग के जलए सवगव्यापी रूप से जडिाइन दकए गए उपभोिा
उत्पािों और उपसािनों के जवकास, उत्पािन और जवतरण के संविगन के जलए उपाय करेगी।
1.4.5 िारा 44: दकसी स्ट्थापन को दकसी संरचना के जनमागण की मंिूरी निीं िी िाएगी यदि भवन योिना में िारा 40 के
अिीन के न्रीय सरकार द्वारा बनाए गए जवजनयमों का पालन निीं दकया िाता िै।
1. दकसी स्ट्थापन को तब तक पूणगता प्रमाणपत्र िारी निीं दकया िाएगा या भवन का अजिभोग करने के जलए अनुज्ञात निीं
दकया िाएगा िब तक वि के न्रीय सरकार द्वारा बनाए गए जवजनयमों का पालन निीं करता िै।
1.4.6 िारा 45: (1) ऐसे जवजनयमों की अजिसूचना की तारीख से पांच वषग से अनजिक अवजि के भीतर के न्रीय सरकार
द्वारा बनाए गए जवजनयमों के अनुसार सभी जवद्यमान सावगिजनक भवन सुगमय बनाए िाएंगे।
परं तु के न्रीय सरकार राज्यों को इस उपबंि के पालन के जलए मामला िर मामला आिार पर उनकी तैयारी की अवस्ट्था और
अन्य संबंजित पैमानों पर जनभगर रिते हुए समय का जवस्ट्तार मंिूर कर सके गी।
(2) समुजचत सरकार और स्ट्थानीय प्राजिकारी उनके सभी भवनों और स्ट्थानों में आवश्यक सेवाएं प्रिान करने वाले िैसे
प्राथजमक स्ट्वास्ट््य के न्र, जसजवल/जिला अस्ट्पताल, जवद्यालय, रे लवे स्ट्टेिन और बस अड्डा िैसी सभी तक पहुंच प्रिान करने
के जलए पूर्वगकता पर आिाररत कायगयोिना बनाएंगे और प्रकाजित करेंगे।
1.4.7 िारा 46: सेवा प्रिाता चािे सरकारी िो या प्राइवेट, के न्रीय सरकार द्वारा िारा 40 के अिीन पहुंच पर बनाए गए
जनयमों के अनुसार ऐसे जनयमों की अजिसूचना की तारीख से िो वषग की कालावजि के भीतर सेवाएं प्रिान करेगा। परंतु
के न्रीय सरकार मुख्य आयुि के परामिग से उि जनयमों के अनुसार कजतपय प्रवगग की सेवाएं प्रिान करने के जलए समय का
जवस्ट्तार मंिूर कर सके गी।

अध्याय – 2
पररभाषाएं
2.1 “रोि" से ऐसा कोई कारक अजभप्रेत िै जिसमें संसूचनात्मक, सांस्ट्कृ जतक, आर्थगक, पयागवरणात्मक, संस्ट्थागत,
रािनैजतक, सामाजिक, भाव संबंिी या अवसंरचनात्मक कारक सजममजलत िै िो समाि में दिव्यांगिनों की पूणग और प्रभावी
भागीिारी को रोकते िैं।
2.2 "सूचना और संचार प्रौद्योजगकी (आईसीटी) " के अंतगगत सूचना और प्रौद्योजगकी से संबंजित सभी सेवा और नव
पररवतगन भी िै जिसके अंतगगत टेलीकाम सेवाएं, वेब आिाररत सेवाएं, इलैक्राजनक और मुरण सेवाएं, जडजिटल और परोक्ष
सेवाएं भी िैं।
2.3 "संिर्भगत दिव्यांगिन" से प्रमाणकताग प्राजिकारी द्वारा यथाप्रमाणीकृ त जवजनर्िगष्ट दिव्यांगता के चालीस प्रजतित से
अन्यून का व्यजि अजभप्रेत िै, ििां जवजनर्िगष्ट दिव्यांगता अध्युपायी जनबंिनों में पररभाजषत निीं की गई िै और इसमें ऐसा
दिव्यांगिन भी सजममजलत िै ििां जवजनर्िगष्ट दिव्यांगता प्रमाणकताग प्राजिकारी द्वारा यथाप्रमाणीकृ त अध्युपायी जनबंिनों में
पररभाजषत की गई िै।

<!-- page 45 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1146/117
1224/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

437

2.4 "दिव्यांगिन" से ऐसी िीघगकाजलक िारीररक, मानजसक, बौजद्धक या संवेिी िाजन वाला व्यजि अजभप्रेत िै जिससे
बािाओं का सामना करने में अन्य व्यजियों के साथ समान रूप से समाि में पूणग और प्रभावी भागीिारी में रुकावट उत्पन्न
िोती िै।
2.5 "सावगिजनक भवन" से कोई सरकारी या जनिी भवन िो अत्यजिक िनता द्वारा उपयोग दकया िाता िै या उनकी पहुंच
में िै, जिसके अंतगगत िैजक्षक या व्यावसाजयक प्रयोिनों के कायग स्ट्थल, वाजणजज्यक दक्रयाकलापों, सावगिजनक सुजविाओं,
िार्मगक, सांस्ट्कृ जतक, अवकाि या मनोरं िन दक्रयाकलापों, जचदकत्सीय या स्ट्वास्ट््य सेवाओं, जवजि प्रवतगन अजभकरणों,
सुिारात्मक या न्याजयक फोरम, रेलवे स्ट्टेिनों या प्लेटफामों, सड़क पररविन बस स्ट्टैंडों या टर्मगनल, जवमानपिनों या
िलमागों के जलए उपयोग दकए िाने वाले भवन भी िैं।
2.6 "सावगिजनक सुजविाओं और सेवाओं" के अंतगगत वृित् स्ट्तर पर िनता को सेवाएं प्रिान करने के सभी रूप आते िैं
जिसके अंतगगत आवास, जिक्षा या वृजिक प्रजिक्षण, जनयोिन और वृजिक उन्नयन, जवक्रय स्ट्थल या जवपणन के न्र, िार्मगक,
सांस्ट्कृ जतक, अवकाि या मनोरंिन, जचदकत्सा, स्ट्वास्ट््य और पुनवागस, बैंककारी, जवि और बीमा, संचार, डाक और सूचना,
न्याय तक पहुंच, सावगिजनक उपयोजगताएं, पररविन भी िै।
2.7 “दिव्यांगताओं की श्रेजणयां” विी िैं िो दिव्यांगिन अजिकार अजिजनयम, 2016, भारत की राष्ट्रीय भवन संजिता,
2016 तथा अन्य संगत जवजनयमों में उजल्लजखत िैं।

2.8 "सवगव्यापी जडिाइन" से सभी लोगों द्वारा अनुकूलन या जवजिष्ट जडिाइन की आवश्यकता के जबना अजिकतम संभव
सीमा तक उपयोग दकए िाने वाले उत्पािों, वातावरणों, कायगक्रमों की जडिाइन और सेवाएं अजभप्रेत िैं और िो
दिव्यांगिनों के जवजिष्ट समूि के जलए उन्नत प्रौद्योजगदकयों सजित सिायक युजियों पर लागू िोंगी।

अध्याय 3
ग्रामीण जवकास मंत्रालय
ग्रामीण जवकास जवभाग
3.1 ग्रामीण क्षेत्रों में जवकास एवं कल्याणकारी कायगकलापों में संलग्न िोने के कारण ग्रामीण जवकास मंत्रालय िेि की समग्र
जवकास कायगनीजत में अिम भूजमका जनभाता िै। आिीजवकाओं के अवसरों को बढ़ावा िेकर, सामाजिक सुरक्षा तंत्र उपलब्‍ि
कराकर तथा उन्नजत के जलए अवसंरचना का जवकास करके गरीबी के उन्मूलन की बहुद्देश्यीय कायगनीजत के माध्यम से
ग्रामीण भारत का स्ट्थायी एवं समावेिी जवकास िी इस मंत्रालय की पररकल्पना और उद्देश्य िै। आिा िै दक इससे ग्रामीण
भारत के िीवनस्ट्तर में सुिार आएगा और समाि के सवागजिक वंजचत लोगों तक पहुंचने की इस प्रदक्रया में जवकासात्मक
असंतुलन िूर दकया िा सके गा। ग्रामीण जवकास मंत्रालय के मुख्य उद्देश्य इस प्रकार िै :i.

गरीब पररवारों पर िोर िेते हुए मजिलाओं तथा अन्य कमिोर वगों सजित िरूरतमंिों को आिीजवकाओं के
अवसर और कौिल प्रजिक्षण उपलब्‍ि कराना।

ii.

प्रत्येक जविीय वषग में रोिगार की मांग करने वाले प्रत्येक पररवार को कम से कम 100 दिनों के मििूरी रोिगार
की गारं टी िेकर ग्रामीण क्षेत्रों में पररवारों की आिीजवका सुरक्षा बढ़ाने का प्राविान करना।

iii.

सड़क संपकग ताजविीन ग्रामीण बजस्ट्तयों के जलए बारिमासी सड़क संपकग ता और बािार, स्ट्कू लों तथा अस्ट्पतालों तक
पहुंच के जलए मौिूिा सड़कों के उन्नयन का प्राविान करना।

iv.

ग्रामीण क्षेत्रों में बीपीएल पररवारों को आिारभूत आवास और संबंजित सुजविाएं उपलब्‍ि कराना।

v.

बुिुगों, जविवाओं और दिव्यांग व्यजियों को सामाजिक सिायता उपलब्‍ि कराना।

vi.

ग्रामीण जवकास कायगकतागओं का क्षमता जवकास और प्रजिक्षण कराना।

vii.

ग्रामीण जवकास में स्ट्वयंसेवी अजभकरणों और व्यजियों की सिभाजगता को बढ़ावा िेना।

<!-- page 46 -->

903230/2023/NSAP
881918/2023/NSAP
438

1147/117
1225/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

3.2 ग्रामीण जवकास जवभाग गरीबी उपिमन, रोिगार सृिन, िीवनस्ट्तर में सुिार, अवसंरचना के जवकास और सामाजिक
सुरक्षा के उद्देश्य से जवजभन्न कायगक्रमों के कायागन्वयन के माध्यम से ग्रामीण क्षेत्रों में बिलाव को बढ़ावा िेता रिा िै। बीते
वषों में कायगक्रमों के कायागन्वयन से प्राप्त अनुभवों और गरीबों की आवश्यकताओं के आिार पर कई कायगक्रमों में आिोिन
दकए गए िैं तथा कई नए कायगक्रम भी िुरू दकए गए।
3.3 स्ट्थानीय लोगों की आवश्यकताओं और आकांक्षाओं को ध्यान में रखते हुए पंचायती राि संस्ट्थाओं (पीआरआई) को
कायगक्रमों के कायागन्वयन में िाजमल दकया गया िै तथा ये संस्ट्थाएं आयोिना के जवकास एवं इसके कायागन्वयन के
जवकें रीकरण का मूल घटक िैं।
3.4 ग्रामीण क्षेत्रों में ग्रामीण जवकास मंत्रालय द्वारा कायागजन्वत दकए िा रिे प्रमुख कायगक्रम इस प्रकार िैं:
i.

ग्रामीण रोिगार – मिात्मा गांिी राष्ट्रीय ग्रामीण रोिगार गारं टी अजिजनयम, 2005 (मनरेगा)

ii.

ग्रामीण आिीजवकाएं- िीनियाल अंत्योिय योिना –राष्ट्रीय ग्रामीण आिीजवका जमिन (डीएवाई-एनआरएलएम)

iii.

िीनियाल उपाध्याय – ग्रामीण कौिल्य योिना (डीडीयू-िीके वाई)

iv.

ग्रामीण संपकग ता – प्रिान मंत्री ग्रामीण सड़क योिना (पीएमिीएसवाई)

v.

प्रिान मंत्री आवास योिना – ग्रामीण (पीएमएवाई-िी)

vi.

राष्ट्रीय सामाजिक सिायता कायगक्रम (एनएसएपी)

vii.

सांसि आििग ग्राम योिना (एसएिीवाई)

कायागन्वयन/अनुसि
ं ान में िाजमल स्ट्वायि जनकाय:
i.

राष्ट्रीय ग्रामीण जवकास एवं पंचायती राि संस्ट्थान (एनआईआरडी एण्ड पीआर)

ii.

राष्ट्रीय ग्रामीण अवसंरचना जवकास एिेंसी (एनआरआईडीए)

3.5
इसके अजतररि इस जवभाग ने ग्रामीण कायगकतागओं के क्षमता जवकास, सूचना, जिक्षा एवं संचार (आईईसी) तथा
जनगरानी एवं मूल्यांकन से संबंजित योिनाएं भी चलाई िैं।
3.6
ग्रामीण जवकास जवभाग में सुगमयता दििा-जनिेिों के कायगक्षेत्र में ग्रामीण जवकास जवभाग द्वारा कायागजन्वत की िा
रिी जवजभन्न योिनाओं के माध्यम से जनर्मगत जवजभन्न पररसंपजियों और िुरू दकए गए कायगकलापों तक दिव्यांग व्यजियों
की पहुंच का प्राविान करने के दििा-जनिेि िाजमल िैं, िैसे दक:
•

मिात्मा गांिी राष्ट्रीय ग्रामीण रोिगार गारं टी योिना (मनरे गा) के अंतगगत कायगक्षेत्र तथा जवजभन्न योिनाओं
के अंतगगत जनर्मगत सामुिाजयक पररसंपजियों को दिव्यांग व्यजियों के जलए सुगम बनाना।

•

दिव्यांग व्यजियों के जलए जनर्मगत पररसंपजियां मानकों के अनुरूप िोनी चाजिए तादक वे पररसंपजियां
बािाओं से मुि िों।

•

ग्रामीण जवकास जवभाग की मनरे गा और पीएमएवाई-िी िैसी जवजभन्न योिनाओं/कायगक्रमों के अंतगगत
जनर्मगत पररसंपजियां सावगभौजमक जडिाइन के अनुरूप िों तथा दिव्यांग व्यजियों के जलए सुगम िों।

•

ग्रामीण कौिल एवं प्रजिक्षण कायगक्रमों में दिव्यांग व्यजियों की सिभाजगता से संबंजित दििा-जनिेि।

•

स्ट्व-सिायता समूिों में दिव्यांग मजिलाओं की सिभाजगता।

•

बुिुगग एवं दिव्यांग लाभार्थगयों के जलए सामाजिक सिायता।

<!-- page 47 -->

1148/117
1226/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

439

अध्याय -4
ग्रामीण जवकास जवभाग की योिनाओं के अंतगगत दिवयांग िनों के जलए प्राविान
4.1

मिात्मा गांिी – नरे गा

4.1.1 मिात्मा गांिी राष्ट्रीय ग्रामीण रोिगार गारं टी अजिजनयम (मनरे गा), 2005 एक ऐसा अजिजनयम िै िो ऐसे
प्रत्येक पररवार को जिनके वयस्ट्क सिस्ट्य अकु िल िारीररक श्रम करने के इच्छु क िैं, उन्िें प्रत्येक जविीय वषग में कम से कम
100 दिनों का गारं टीयुि मििूरी रोिगार प्रिान करके िेि के ग्रामीण क्षेत्रों के पररवारों की आिीजवका सुरक्षा में वृजद्ध
करने का प्राविान करता िै।
4.1.2 मिात्मा गांिी राष्ट्रीय ग्रामीण रोिगार गारं टी अजिजनयम (मिात्मा गांिी नरेगा), 2005 के तित तैयार की गई
मिात्मा गांिी राष्ट्रीय ग्रामीण रोिगार गारं टी योिना (मनरे गा योिना) के मुख्य उद्देश्य िैं:

4.1.3

i.

मांग के अनुसार ग्रामीण क्षेत्रों में प्रत्येक पररवार को एक जविीय वषग में 100 दिनों का अकु िल िारीररक
श्रम का गारं टीयुि रोिगार प्रिान करना।

ii.

जनिागररत गुणविा और स्ट्थाजयत्व वाली उत्पािक पररसंपजियों का जनमागण करना।

iii.

गरीबों के आिीजवका संसािन आिार को सुिढ़ृ बनाना।

iv.

सदक्रय रूप से सामाजिक समावेिन सुजनजित करना; और

v.

पंचायती राि संस्ट्थाओं को सुिढ़ृ बनाना।

मनरे गा अजिजनयम, 2005 की मुख्य जविेषताएं जनम्नानुसार िैं:

(i) अजिकार आिाररत फ्रेमवकग
a. काम की मांग करने का अजिकार – ग्रामीण पररवार द्वारा कम से कम 100 दिन
b. रोिगार का अजिकार - आवेिन करने के 15 दिन के भीतर अन्यथा बेरोिगारी भिा
c. मििूरी का अजिकार – 15 दिनों के भीतर अन्यथा जवलंब के जलए मुआविा
(ii) श्रम प्रिान कायग
a. जिला स्ट्तर पर कायों के जलए 60:40 के अनुपात में मििूरी और सामग्री
b. दकसी ठे केिार या श्रजमक को जवस्ट्थाजपत करने वाली मिीनरी की अनुमजत निीं िै।
4.1.4 मनरे गा के तित दिव्यांगो की जनयुजि मनरेगा अजिजनयम के प्रासंजगक प्राविानों, दििाजनिेिों और उसके तित
बनाए गए जनयमों के अनुसार:
(i) प्रचालनात्मक दििाजनिेिों में यि जनिागररत दकया गया िै दक मनरे गा में दिव्यांगिनों को िाजमल करने के जलए जविेष
ितें बनाई िानी िैं:
“प्रत्येक राज्य सरकार जवजिष्ट कायों की पिचान करे गी, िो दिव्यांग और कमिोर व्यजियों द्वारा दकए िा सकते िैं। एक
गांव में, दिव्यांग व्यजियों की जवजभन्न श्रेजणयों को योिना के तित उनके जलए प्रस्ट्ताजवत कायों को पूरा करने के जलए एक
जनजित समूि में एक साथ आने के जलए इस प्रकार संगरठत दकया िाएगा जिससे वे अपनी पसंि का प्रयोग कर सकें । दकसी
भी जस्ट्थजत में दिव्यांग व्यजियों और कमिोर व्यजियों को मिात्मा गांिी नरेगा कायों में जनयोजित अन्य व्यजियों की तुलना
में कम मििूरी का भुगतान निीं दकया िाना चाजिए।”
(ii) मनरे गा के अंतगगत रोिगार भूजमकाओं की दिव्यांगता-वार पिचान पररचालन दििाजनिेिों के अध्याय-9 में बताई गई
िै। राज्यों से प्राप्त सूचना के आिार पर मिात्मा गांिी नरेगा के अंतगगत दिवयांग िनों के जलए जनिागररत दकये गये प्रमुख
कायों की सूची जनम्नानुसार िै:

<!-- page 48 -->

903230/2023/NSAP
881918/2023/NSAP
440

1149/117
1227/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

क. पेयिल की आपूर्तग
ख. कायग स्ट्थलों पर बच्चों की िेखभाल करना
ग. पौि रोपण कायग
घ. प्संचाई निर में खुिाई
ङ. जमट्टी भरना
च. खोिी गई जमट्टी को जबछाना/रॉली में जमट्टी जबछाना
छ. भवन जनमागण - कं क्रीट सामग्री तैयार करना
ज. जनमागण सामग्री की व्यवस्ट्था करना
झ. सीमेंट और ईंटें िेना
ञ. ढु लाई की िाने वाली टोकरी में रेत भरना
ट. नवजनर्मगत िीवार की तराई करना
ठ. कु आं गिरा करना-टोकरी में जमट्टी/गाि भरना
ड. कु एं से पानी जनकालने में सिायता करना
ढ. राली में मलबा डालना
ण. तालाबों से मलबा िटाना
त. पात्र (बतगन) में मलबा भरना
थ. मलबे से भरे पात्र को राली में डालना
द. पत्थर की ढु लाई
ध. पत्थरों का ढेर बनाना
न. भूजम समतलीकरण कायग
ऩ. फील्ड बाउं प्डंग कायग
प. िल संरक्षण खाई की खुिाई
फ. खाई से खोिी गई जमट्टी को िटाना
ब. सड़क जनमागण-झाड़ू से सड़क की सफाई करना
भ. पानी, जमट्टी भरना
(iii)
मिात्मा गांिी नरे गा के पैरा 18 अनुसूची-I के प्राविानों के अनुसार “मजिलाओं, वृद्धों, दिव्यांगिनों और कमिोर
करने वाली बीमाररयों से पीजडत लोगों के जलए अलग से िरों की सूची जनिागररत की िाएगी तादक उत्पािक कायों के
माध्यम से उनकी भागीिारी बढ़ाई िा सके ।”
(iv) दिव्यांगता-वार कायग भूजमकाओं की पिचान की िाएगी और प्राथजमकता के आिार पर राज्यों/संघ राज्य क्षेत्रों द्वारा
लागू दकया िाएगा।
(v)

कायग स्ट्थल के बािरी/भू-भाग क्षेत्र तक पीडब्‍ल्यूडी के जलए जनरंतर पहुंच मागग का प्राविान।

(vi)
राज्यों/संघ राज्य क्षेत्रों को मनरे गा कायगस्ट्थल में जििुगृि, पेयिल, प्राथजमक जचदकत्सा और छाया आदि िैसी
सुजविाएं दिव्यांगिनों तक पहुंचानी चाजिए।

<!-- page 49 -->

1150/117
1228/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

441

(vii)
सीपीडब्‍ल्यूडी दििाजनिेि (भारत में सावगभौजमक पहुंच के जलए सामंिस्ट्यपूणग दििाजनिेि और मानक 2021) का
पालन नए सामान्य सुजविा कें र, ग्राम पंचायत भवन और मनरे गा के तित दकए गए अन्य प्रस्ट्ताजवत कायों के जनमागण के
जवषयों में दकया िा सकता िै।
4.2. िीनियाल अंत्योिय योिना- राष्ट्रीय ग्रामीण आिीजवका जमिन (डीएवाई-एनआरएलएम)
4.2.1 िीनियाल अंत्योिय योिना- राष्ट्रीय ग्रामीण आिीजवका जमिन (डीएवाई-एनआरएलएम) में अत्यजिक गरीब और
समुिाय के अन्य कमिोर वगों िैसे सामाजिक आर्थगक िाजत आिाररत िनगणना (एसईसीसी), अनुसूजचत िाजत (एससी),
अनुसूजचत िनिाजत (एसटी), जविेष रूप से कमिोर िनिातीय समूिों (पीवीटीिीएएस), मजिला मुजखया पररवारों, बुिुगग
व्यजियों,जवजभन्न क्षमताओं (पीडब्‍ल्यूडी) वाले लोगों, अल्पसंख्यक समूिों और उग्रवाि प्रभाजवत क्षेत्रों में रिने वाले लोग,
पिाड़ी इलाकों (क्षेत्रों तक पहुंचने के जलए करठन), मानव तस्ट्करी की जिकार मजिलाएं, अस्ट्वास्ट््यकर व्यवसायों (पूवग में
िाथ से मैला ढोने वाले), रांसिेंडर, एचआईवी/एड्स पॉजिरटव व्यजियों और उनके पररवार के लोग, गंभीर बीमारी से
पीजड़त एक या एक से अजिक व्यजियों वाले पररवार आदि को प्राथजमकता िेने और उन्िें िीघ्र िाजमल करने पर जविेष
ध्यान दिया गया िै।
4.2.2 एनआरएलएम गिन ब्‍लॉक में कायग िुरु करने के िुरुआती 18 मिीनों की अवजि के भीतर सबसे गरीब और
कमिोर समुिायों के साथ पूणग लक्ष्य को अपने संस्ट्थागत फ्रेमवकग में िाजमल करने का प्रयास करता िै और प्राप्त करता िै।
एनआरएलएम को उममीि िै दक कमिोर व्यजि एनआरएलएम के तित जवजभन्न सामुिाजयक संस्ट्थाओं में नेतृत्व के पिों पर
अच्छे अनुपात में िोंगे। इसके अजतररि, एनआरएलएम इन संस्ट्थाओं को उनके जविीय और आर्थगक/आिीजवका समावेिन
और गरीबी में कमी के लक्ष्यों को प्राप्त करने में सुजविा प्रिान करता िै।
4.2.3 डीएवाई-एनआरएलएम के तित दिव्यांगों के जलए जविेष प्राविान :
(i)
सभी दिव्यांग (एक वषग और उससे अजिक आयु वगग के ), दकसी व्यजि की जवकलांगता के प्रजतित (जवकलांगता के
40% से भी कम) के बाविूि, दिव्यांग एसएचिी (स्ट्वयं सिायता समूि) के सिस्ट्य िो सकते िैं और दिव्यांग एसएचिी
एनआरएलएम के तित समुिायों पररक्रामी जनजि (आरएफ), गरीबी उपिमन जनजि (वीआरएफ), सामुिाजयक जनवेि
जनजि (सीआईएफ) आिीजवका जनजि (एलएफ) के जलए सभी जनजियों के जलए पात्र िैंक. 1-17 वषग के जवकलांग व्यजि, या मानजसक जवकलांगता, मानजसक बीमारी या मानजसक मंिता वाले व्यजि को
अपने कानूनी अजभभावक/माता-जपता/िेखभाल करने वाले के माध्यम से दिव्यांग एसएचिी में सिस्ट्य के रूप में
प्रजतजनजित्व दिया िा सकता िै। कानूनी अजभभावक/माता-जपता/िेखभाल करने वाले अपने स्ट्वयं के एसएचिी के
सिस्ट्य बने रिेंगे। तथाजप, संबंजित समूि के सिस्ट्यों को यि सुजनजित करने के जलए जनगरानी करनी िोती िै दक
संबंजित व्यजि को लाभ जमल रिा िै।
ख. एक दिव्यांग व्यजि दिव्यांग एसएचिी का सिस्ट्य िोगा और यदि एक पररवार में एक से अजिक दिव्यांग व्यजि िैं
तो प्रत्येक दिव्यांग व्यजि दिव्यांग एसएचिी के व्यजिगत सिस्ट्य के रूप में दिव्यांग एसएचिी का सिस्ट्य बन
िाएगा।
ग.

यदि एक दिव्यांग मजिला पिले से िी गांव में मौिूिा मजिला एसएचिी में एक सिस्ट्य िै, तो उसे या तो उसी
समूि में बने रिने की या दिव्यांग एसएचिी में िाजमल िोने की स्ट्वतंत्रता िोगी। यदि वि उसी समूि (गैर दिव्यांग
एसएचिी) में बने रिने का फै सला करती िै, तो उसे दिव्यांग के रूप में अन्य सभी लाभ जमलने चाजिए।

(ii)
जमिन स्ट्तर पर दिव्यांगों की पिचान, उन्िें सदक्रय करना और संस्ट्था जनमागण के जलए जनम्नजलजखत किम उठाये
िाते िैं:
क. अजभजवन्यास / ररफ्रेिर कायगिालाओं, सामुिाजयक कै डरों, नेताओं, सिस्ट्यों और संस्ट्थानों में कमगचाररयों
को दिव्यांगों के प्रजत संवेिनिील बनाना और उनके साथ काम करना
ख. मॉड्यूल और सामग्री का जवकास करना।
ग.

दिव्यांग एसएचिी कायगकताग मैनुअल (दिव्यांगों के प्रजत अविारणाओं सजित)
(http://nirdpr.org.in/nird_docs/nrlm/nrlmhandbookSocialInclusion050716.pdf)

<!-- page 50 -->

903230/2023/NSAP
881918/2023/NSAP
442

1151/117
1229/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

घ. संवेिीकरण/िागरूकता जनमागण आईईसी सामग्री (प्प्रंट और जडजिटल)
ङ. दिव्यांग के अजिकारों और िकिारी पर सामुिाजयक संवगग के जलए प्रजिक्षण मॉड्यूल
च. समुिाय आिाररत सामाजिक सुरक्षा, स्ट्वास्ट््य और पोषण (मानजसक स्ट्वास्ट््य सजित) और दिव्यांग की
मनोरं िक िरूरतों पर सामुिाजयक कै डर के जलए संसािन मॉड्यूल
छ. दिव्यांग जवजिष्ट आिीजवका पर संसािन मॉड्यूल
ज. दिव्यांग एिेंडा के साथ काम करने के जलए सामुिाजयक संसािन व्यजिगत (सीआरपी) का पोषण और
प्रजिक्षण
(iii) गांव और क्लस्ट्टर स्ट्तरों पर दिव्यांगों की पिचान, उन्िें सदक्रय करना और संस्ट्था जनमागण के जलए जनम्नजलजखत
किम उठाये िाते िैं:
क. पिले सीआरपी चक्र के िौरान िी दिव्यांगिनों की पिचान और उन्िे सदक्रय करना।
ख. दिव्यांग को सामान्य एसएचिी या जविेष दिव्यांग एसएचिी में सदक्रय करना। िाजिए पर रिने वाला समूि िोने
के कारण, दिव्यांग के जविेष समूि बनाना फायिेमंि िो सकता िै।
ग.

संतृजप्त मोड पर सदक्रय और सिायता प्राप्त दिव्यांग को िुटाना। क्षमता और फु ती के आिार पर स्ट्व-चयन की
प्रदक्रया को अपनाया िा सकता िै।

घ. एसईसीसी (स्ट्व-िाजमल और कम से कम 1 कमी) में िाजमल दिव्यांगिनों को एकत्र करना और एकल
पुरुषों/मजिलाओं, अनुसूजचत िाजत/अनुसूजचत िनिाजत और अल्पसंख्यक समुिायों, बुिुगों आदि से संबंजित कई
कमिोररयों के तित पीजड़त दिव्यांगों को एकत्र करना।
ङ. गांव में मौिूिा दिव्यांग स्ट्व-सिायता समूिों, यदि कोई िो, को अपनाना और मिबूत करना
च. उजचत अनुकूलन के साथ प्रत्येक दिव्यांग स्ट्व-सिायता समूिों के जलए पंचसूत्र की अनुपालना की सुजविा प्रिान
करना
छ. समुिाय को प्रजिक्षण दिए िाने िेतु 2-3 सदक्रय मजिलाओं/गांव की पिचान करने (दिव्यांग एसएचिी और उनके
संघीय इमिगन स्ट्थलों के जलए इमिगन/एक्सपोिर यात्राओं सजित) और दिव्यांग समावेिन कै डर/सीआरपी के रूप
में तैनात करने की सुजविा प्रिान करना।
ज. सदक्रय मजिलाओं, समावेिन/दिव्यांग सीआरपी और ग्राम संगठनों (वीओ) की एकिुटता के जलए अजििेि;
आंगनवाड़ी और आिा कायगकतागओं को गांव में दिव्यांग एिेंडा में िाजमल करना
झ. योिना के अनुसार दिव्यांग एसएचिी सिस्ट्यों, नेताओं और कै डरों का क्षमता जनमागण िुरू करना। सदक्रय,
सिायता प्राप्त और जनभगर दिव्यांगों की क्षमता जनमागण की िरूरतें और प्रदक्रयाएं स्ट्पष्ट रूप से अलग िो सकती िैं।
ञ. पररक्रामी जनजि को प्राप्त करने के जलए दिव्यांग एसएचिी को सुजविा प्रिान करना
ट.

दिव्यांग एसएचिी को वीओ (ग्रामीण स्ट्तर पर मजिला एसएचिी का संघ) में िाजमल िोने की सुजविा प्रिान
करना। अन्य मजिला एसएचिी की तरि, दिव्यांग स्ट्व-सिायता समूि वीओ और उच्च स्ट्तरीय संघों से सीआईएफ,
वीआरएफ िैसे सभी लाभों को प्राप्त करने के िकिार िैं।

ठ.

वीओ को इन दिव्यांग समूिों की जनयजमत रूप से जनगरानी और मिबूत करने के जलए सामाजिक कारग वाई सजमजत
में एक उप-सजमजत या एक उप-समूि रखने की सुजविा प्रिान करना।

ड.

दिव्यांग के जलए योिना को िाजमल करने िेतु गरीबी उपिमन योिना की सुजविा प्रिान करना

ढ.

दिव्यांगिनों को पुनवागस सिायता की सुजविा प्रिान करना

ण. इन कायगकलापों के जलए दिव्यांग कें दरत और/या दिव्यांग अनुकूल आिीजवका और सामूजिकता की सुजविा प्रिान
करना, ििां भी आवश्यक / व्यविायग िो

<!-- page 51 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]
त.

1152/117
1230/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

443

ग्राम पंचायत/क्लस्ट्टर/ब्‍लॉक स्ट्तर पर और उच्च स्ट्तर पर एक अलग अनन्य संघ में उनकी एकिुटता, पक्ष समथगन
आदि के जलए दिव्यांग एसएचिी को सुजविा प्रिान करना

4.3 ग्रामीण संपकग ता-प्रिानमंत्री ग्राम सड़क योिना (पीएमिीएसवाई)
4.3.1 भारत सरकार ने गरीबी उन्मूलन कायगनीजत के एक भाग के रूप में ग्रामीण सड़कों के माध्यम से राज्यों की
सिायता के जलए एक के न्रीय प्रायोजित योिना के रूप में 25 दिसमबर, 2000 को प्रिान मंत्री ग्राम सड़क योिना
(पीएमिीएसवाई I) िुरू की। प्रिान मंत्री ग्राम सड़क योिना (पीएमिीएसवाई) का प्राथजमक उद्देश्य ग्रामीण क्षेत्रों में संपकग
रजित पात्र बसावटों को आवश्यक पुलों और क्रॉस-ड्रेनेि संरचनाओं, िो पूरे वषग संचाजलत िोते िैं, के साथ एक बारिमासी
सड़क के माध्यम से समपकग ता प्रिान करना िै।
4.3.2 िैस-े िैसे कायगक्रम आगे बढ़ा, मौिूिा ग्रामीण सड़क नेटवकग के समेकन की आवश्यकता मिसूस की गई तादक न
के वल पररविन सेवाओं के प्रिाता के रूप में, बजल्क सामाजिक और आर्थगक जवकास के वािन के रूप में भी इसकी
प्रभाविीलता में सुिार दकया िा सके । तिनुसार, वषग 2013 में, पीएमिीएसवाई-II को जवजभन्न राज्यों और संघ राज्य क्षेत्रों
में 50,000 दकमी के उन्नयन के लक्ष्य के साथ मागों और प्रमुख ग्रामीण संपकों (एमआरएल) के माध्यम से चयजनत मागों
और प्रमुख ग्रामीण संपकों (एमआरएल) के उन्नयन के जलए िुरू दकया गया था। इसके बाि, 2016 में, रणनीजतक रूप से
मित्वपूणग सड़कों के जनमागण/उन्नयन के जलए वामपंथी उग्रवाि प्रभाजवत क्षेत्रों के जलए सड़क संपकग पररयोिना
(आरसीपीएलडब्‍ल्यूईए) पीएमिीएसवाई के तित एक अलग घटक के रूप में िुरू की गई थी। वषग 2019 में, सरकार ने
अन्य के साथ-साथ ग्रामीण कृ जष बािारों (िीआरएएम), उच्चतर माध्यजमक स्ट्कू लों और अस्ट्पतालों से बसावटों को िोड़ने
वाले मागों और प्रमुख ग्रामीण संपकों के माध्यम से 1,25,000 दकमी के समेकन के जलए पीएमिीएसवाई-III िुरू दकया।
4.3.3 पीएमिीएसवाई के अंतगगत जनर्मगत सभी सड़कों को िीआईएस-आिाररत प्लेटफामों में भू-टैप्गंग और स्ट्थाजनक
योिना िैसे दक िीआरआईएमएमएस, िीआरआईएसएस और जियो-पीएमिीएसवाई के जलए मैप दकया िाता िै और डेटा
को एपजलके िन के जवकास के जलए सावगिजनक और अन्य जवक्रेताओं िैसे गूगल मानजचत्र आदि के जलए भी सुलभ बनाया
िाता िै िो िारीररक रूप से अक्षम/दिव्यांग व्यजियों के जलए सिायक साजबत िोते िैं।
4.3.4 चूंदक ग्रामीण सड़कें आम तौर पर कम यातायात वाली सड़कें िोती िैं और िुघगटना िर वतगमान में काफी िैं,
इसजलए सुरक्षा के मुद्दे मुख्य रूप से यूजनवसगल जडिाइन और जनमागण सुजविाओं और स्ट्थानीय जनवाजसयों के सड़क सुरक्षा
ज्ञान से संबंजित िैं। ग्रामीण सड़क जवकास और रखरखाव कायगक्रमों के भाग के अंतगगत दििा-जनिेिों में यि जनिागररत दकया
गया िै दक राज्य सरकार गुणविा जनगरानी के साथ-साथ पीएमिीएसवाई कायों की सड़क सुरक्षा लेखा परीक्षा सुजनजित
करे गी। यि पंचायत राि संस्ट्थाओं की पयागप्त भागीिारी भी सुजनजित करे गा।
4.3.5 संबंजित ग्राम पंचायतों को बारिमासी ग्रामीण सड़क के सावगभौजमक जडिाइन और जनमागण के जलए सडक पर
चलने, अजभजवन्यास, सड़क पार करने आदि की सुजविाओं के साथ सभी किम उठाने चाजिए।
4.3.6 सावगिजनक सड़क के जनमागण के िौरान दिव्यांगों के जलए बािा मुि वातावरण बनाने के जलए सड़क पररविन और
रािमागग मंत्रालय, सीपीडब्‍ल्यूडी और एसपीडब्‍ल्यूडी के प्रासंजगक दििाजनिेिों का पालन दकया िाना चाजिए। "मेरी सड़क"
ऐप ग्रामीण सड़कों में सुजविाओं के उपयोग के जलए सभी दिव्यांगों द्वारा उपयोग के जलए भी उपलब्‍ि िै।
4.4 ग्रामीण आवास -प्रिान मंत्री आवास योिना-ग्रामीण (पीएमएवाई-िी)
4.4.1 पूवगवती ग्रामीण आवास योिना, इं दिरा आवास योिना (आईएवाई) को 2024 तक "सभी के जलए आवास" प्रिान
करने और जपछली आवासीय योिनाओं की कजमयों को िूर करने की सरकार की प्रजतबद्धता के मद्देनिर प्रिान मंत्री आवास
योिना- ग्रामीण (पीएमएवाई-िी) के रूप में पुनगगरठत दकया गया था। पुनसिंरजचत योिना प्रिानमंत्री आवास योिना ग्रामीण (पीएमएवाई-िी) 1 अप्रैल 2016 से प्रभावी हुई। पीएमएवाई-िी का उद्देश्य िेि के ग्रामीण क्षेत्रों में कच्चे/िीणगिीणग मकानों में रिने वाले सभी बेघरों और पररवारों को बुजनयािी सुजविाओं वाला पक्का मकान प्रिान करना िै।
4.4.2 पीएमएवाई-िी के तित, दिव्यांगिन अजिकार अजिजनयम, 2016 के प्राविानों के अनुसार, ििां तक संभव िो
राज्यों/संघ राज्य क्षेत्रों को यि सुजनजित करना िै दक 5% लाभाथी बेंचमाकग जवकलांगता वाले िों जिसमें बेंचमाकग
जवकलांगता वाली मजिलाओं को प्राथजमकता िी िाएगी। दिव्यांगिनों के जलए पीएमएवाई-िी के तित जनर्मगत मकानों के
जलए बािा मुि जडिाइन को अपनाया िाना चाजिए। दिव्यांग को आवंरटत प्रत्येक मकान के जलए रैं प का जनमागण दकया

<!-- page 52 -->

903230/2023/NSAP
881918/2023/NSAP
444

1153/117
1231/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

िाना चाजिए। यि दिव्यांगिनों को मकान के अंिर और बािर सुगम आवािािी करने में सक्षम बनाता िै और इस रैंप का
जनमागण लाभाथी द्वारा मकान के जनमागण के जलए प्रिान की गई सिायता में से िी करना िै।
4.4.3 सावगभौजमक जडिाइन को ग्रामीण आवास में िाजमल दकया िाना िै तादक इसे जबना दकसी बड़ी रे रोदफटटंग
लागत के दिव्यांगों की आवश्यकता के अनुसार अनुकूजलत दकया िा सके । पिल (प्रकृ जत, हुनर, लोकजवद्या) संग्रि के
माध्यम से स्ट्थान/िलवायु/संस्ट्कृ जत उपयुि मकान जडिाइनों का एक संग्रि प्राप्त दकया िा सकता िै िो पीएमएवाई िी
की वेबसाइट पर उपलब्‍ि िै:
(i)

https://pmayg.nic.in/netiay/Document/Pahal.pdf

(ii)

https://pmayg.nic.in/netiay/Document/Pahal-Volume-II.pdf.

राज्यों/संघ राज्य क्षेत्रों को आपिा रोिी जविेषताओं को िाजमल करते हुए लाभार्थगयों को उनके जनवास क्षेत्र के जलए जवजिष्ट
मकानों के जडिाइन के बारे में िागरुक करना चाजिए।
4.4.4 पीएमएवाई-िी के तित, लाभार्थगयों को मकान के जनमागण के जलए सिायता प्रिान की िाती िै और यि माजलक
द्वारा संचाजलत जनमागण िृजष्टकोण का पालन करता िै। लाभाथी अपनी पसंि के अनुसार मकान का जडिाइन चुनने के जलए
स्ट्वतंत्र िैं। दिव्यांगों की सुगमता से संबंजित सुजविाओं को अनुमजत िी िानी चाजिए और प्रोत्साजित दकया िाना चाजिए।
4.4.5 मकानों के गुणविापूणग जनमागण के जलए रािजमस्त्री के प्रजिक्षण िेतु ग्रामीण रािजमस्त्री प्रजिक्षण (आरएमटी) के
अंतगगत दिव्यांग व्यजियों के मकानों को संबद्ध अजभगमयता जविेषताओं के साथ गुणविापूणग जनमागण के जलए जलया िाना िै।
रािजमस्त्री प्रजिक्षण और प्रमाणन में पीएमएवाई-िी में सावगभौजमक जडिाइन आिाररत अजभगमयता पर प्रजिक्षण िाजमल
िोना चाजिए।
4.4.6 पीएमएवाई-िी वेबसाइट (आवाससॉफ्ट सजित), िृजष्टबाजित व्यजियों के जलए स्ट्क्रीन रीडर के उपयोग के अनुरूप
तेिी से उपयोग दकया िाएगा।
4.4.7 पीएमएवाई-िी को ििां तक संभव िो, भारत-2021 में सावगभौजमक पहुंच के जलए सामंिस्ट्यपूणग दििाजनिेिों
और मानकों में पररभाजषत सभी प्रासंजगक जनयमों का पालन करना चाजिए।
4.5

राष्ट्रीय सामाजिक सिायता कायगक्रम (एनएसएपी)

4.5.1 भारतीय संजविान का अनुच्छेि 41 राज्य को अपनी आर्थगक साम्यग और जवकास की सीमाओं के भीतर,
बेरोिगारी, वृद्धावस्ट्था, बीमारी और जनिःििता तथा अन्य अनुपयुि अभाव की ििाओं में अपने नागररकों को लोक
सिायता प्रिान करने का जनिेि िेता िै। भारत के संजविान में जनजित राज्य नीजत के जनिेिक जसद्धांत राज्य को अपने
संसािनों में से िी कई कल्याणकारी उपाय करने का आिेि िेते िैं। इन नैजतक जसद्धांतों के अनुसरण में िी भारत सरकार ने
1995 में एक के न्रीय प्रायोजित योिना के रूप में राष्ट्रीय सामाजिक सिायता कायगक्रम (एनएसएपी) िुरू दकया था जिसके
अंतगगत के न्र सरकार द्वारा जनिागररत मानिंडों, दििा-जनिेिों और ितों के अनुसार लाभ िेने के जलए राज्यों/संघ राज्य क्षेत्रों
को 100 प्रजतित के न्रीय सिायता प्रिान की िाती िै।
4.5.2
एनएसएपी वृद्धों, जविवाओं और जवकलांगों तथा िीजवको पािगक की मृत्यु के मामले में गरीब पररवारों के जलए
एक सामाजिक सिायता कायगक्रम िै- जिसमें उन लाभों, िो राज्य प्रिान कर रिे िैं या भजवष्य में प्रिान कर सकते िैं, के
अलावा न्यूनतम राष्ट्रीय मानकों को सुजनजित करने का लक्ष्य रखा िाता िै । ित-प्रजतित के न्रीय सिायता प्रिान करने का
उद्देश्य यि सुजनजित करना िै दक लाभार्थगयों को सामाजिक सुरक्षा पूरे िेि में उपलब्‍ि िो। एनएसएपी के अंतगगत
लाभार्थगयों की राज्य-वार, उप-योिना-वार अजिकतम सीमा जनिागररत िै। राज्य अपने कवरे ि को बढ़ाने और जवस्ट्तार करने
के जलए स्ट्वतंत्र िैं।
4.5.3 इं दिरा गांिी राष्ट्रीय जवकलांगता पेंिन योिना (आईिीएनडीपीएस) राष्ट्रीय सामाजिक सिायता कायगक्रम
(एनएसएपी) की एक उप-योिना िै, जिसके तित भारत सरकार द्वारा जनिागररत मानिंडों के अनुसार गंभीर और बहुजवकलांगता वाले और गरीबी रेखा से नीचे रिने वाले पररवार से संबंजित 18-79 वषग की आयु के व्यजियों को 300 रुपये
प्रजत माि की िर से कें रीय सिायता प्रिान की िाती िै। 80 वषग की आयु बाि, लाभार्थगयों को 500 /- रुपये प्रजत माि की
पेंिन प्राप्त करने के जलए वृद्धावस्ट्था पेंिन योिना में स्ट्थानांतररत कर दिया िाता िै।

<!-- page 53 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1154/117
1232/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

445

4.5.4 वृद्ध आबािी के जलए, इं दिरा गांिी राष्ट्रीय वृद्धावस्ट्था पेंिन योिना (आईिीएनओएपीएस), राष्ट्रीय सामाजिक
सिायता कायगक्रम (एनएसएपी) की एक उप-योिना के अंतगगत, भारत सरकार द्वारा जनिागररत मानिंडों के अनुसार
60-79 वषग की आयु के व्यजियों और गरीबी रे खा से नीचे िीवन यापन करने वाले पररवार से संबंजित व्यजियों को
200 रुपये प्रजत माि की िर से के न्रीय सिायता प्रिान की िाती िै। 80 वषग की आयु प्राप्त करने के बाि, लाभार्थगयों को
प्रजत माि 500 रुपये की पेंिन जमलती िै।
4.6

िीन ियाल उपाध्याय ग्रामीण कौिल्या योिना (डीडीयू-िीके वाई)

4.6.1 ग्रामीण जवकास मंत्रालय ने दिनांक 25 जसतंबर, 2014 को राष्ट्रीय ग्रामीण आिीजवका जमिन के तित जनयोिन से
िुड़े कौिल जवकास कायगक्रम को िीन ियाल उपाध्याय ग्रामीण कौिल्य योिना (डीडीयू-िीके वाई) के रूप में नया रूप दिया
िै।
4.6.2 डीडीयू-िीके वाई राज्य के नेतत्ृ व वाली योिना िै जिसे मांग आिाररत लक्ष्य स्ट्वीकृ जत प्रदक्रया के आिार पर
सावगिजनक-जनिी भागीिारी (पीपीपी) मोड में कायागजन्वत दकया िा रिा िै। डीडीयू-िीके वाई के तित िो जविेष कायगक्रम
लागू दकए िा रिे िैं अथागत; रोिनी कायगक्रम 9 राज्यों के 27 वामपंथी उग्रवाि प्रभाजवत क्षेत्रों के जलए मजिला उममीिवारों
के जलए 40% कवरे ि के साथ अजनवायग आवासीय पाठ्यक्रम के साथ कायागजन्वत दकया िा रिा िै; और जिमायत- संघ राज्य
क्षेत्र िममू और कश्मीर और लद्दाख के सभी युवाओं को 100% कें रीय जवि पोषण के साथ इस योिना के तित िाजमल
दकया गया िै।
4.6.3

डीडीयू-िीके वाई की मुख्य जविेषताएं इस प्रकार िैं:

(i)
15 से 35 वषग के आयु वगग के गरीब पररवारों के ग्रामीण युवाओं पर ध्यान कें दरत करना: क) मनरेगा श्रजमक का
पररवार, यदि पररवार के दकसी व्यजि ने 15 दिन का काम पूरा कर जलया िै, ख) राष्ट्रीय सुरक्षा बीमा योिना
(आरएसबीवाई) पररवार ग) अंत्योिय अन्न योिना काडग पररवार, घ) गरीबी रे खा से नीचे िीवन यापन (बीपीएल),
सावगिजनक जवतरण प्रणाली (पीडीएस) वाले काडग पररवार ङ) एनआरएलएम-एसएचिी पररवार, च) गरीबों की पिचान
की भागीिारी प्रदक्रया, छ) एसईसीसी 2011 के स्ट्वत: समावेिन मापिंडों के अंतगगत आने वाले पररवार।
(ii)
सामाजिक रूप से वंजचत समूिों, अथागत् अ.िा./अ.ि.िा. के जलए 50%, अल्पसंख्यकों- 15%, और मजिलाओं के
जलए 33% का अजनवायग कवरेि और िाथ से मैला ढोने वाले, दिव्यांग और मजिलाओं के नेतृत्व वाले पररवार पर जविेष
ध्यान िेना।
(iii)
जनयोजित अभ्यर्थगयों को वेतन न्यूनतम मििूरी अथवा अजिक अभ्यर्थगयों को जनयोिन पिात सिायता और
प्रजिक्षण भागीिारों को कै ररयर प्रगजत सिायता के अनुसार िी िाती िै।
(iv)
डीडीयू-िीके वाई दििाजनिेिों ने दिव्यांग उममीिवारों के जलए 5% कवरे ि अजनवायग कर दिया िै (अजिसूचना
संख्या 02/2020 दिनांक 07.02.2020)।
(v) डीडीयू-िीके वाई दिव्यांगिन पररयोिनाओं के जलए एक जविेष फ्रेमवकग भी िुरू दकया गया था, जिसमें अन्य बातों के
साथ-साथ प्रजिक्षण कें रों, आवासीय सुजविाओं, व्यजिगत सिायक सिायता, जिक्षण सिायता आदि तक पहुंच का प्राविान
िाजमल िै। (अजिसूचना संख्या 43/2017 दिनांक 31.07.2017)।
(vi) डीडीयू-िीके वाई और ग्रामीण स्ट्वरोिगार प्रजिक्षण संस्ट्थानों (आरएसईटीआई) के तित अभ्यर्थगयों को िुटाने की
प्रदक्रया में पंचायत स्ट्तर के प्रजतजनजि िाजमल िोते िैं।
(vii) कौिल योिनाओं का प्रबंिन के जलए समर्पगत पोटगल /ऐप (कौिल भारत, कौिल पंिी) िैं।
(viii)

डीडीयू-िीके वाई दििाजनिेि में पिाड़ी क्षेत्रों के जलए जविेष प्राविान िै।

4.7 सांसि आििग ग्राम योिना (एसएिीवाई)
4.7.1 सांसि आििग ग्राम योिना (एसएिीवाई) 2014 में िुरू की गई थी, जिसका उद्देश्य 2016 तक प्रत्येक संसि
सिस्ट्य द्वारा एक गांव को आििग गांव (आििग ग्राम) के रूप में जवकजसत करना और 2019 तक िो और गांवों को जवकजसत
करना था। इसके बाि, 2024 तक ऐसे पांच आििग ग्राम (प्रजत वषग एक) का चयन और जवकास दकया िाना िै। दिनांक

<!-- page 54 -->

903230/2023/NSAP
881918/2023/NSAP
446

1155/117
1233/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

31.12.2022 तक संसि सिस्ट्यों द्वारा कु ल 3,074 ग्राम पंचायतों की पिचान की िा चुकी िै िो अन्य कें रीय और राज्य
योिनाओं के अजभसरण के माध्यम से ग्राम पंचायतों के समग्र जवकास की दििा में ठोस किम उठा रिे िैं। इस योिना के
अंतगगत सभी पात्र पररवारों (वृद्धों, जवकलांगों और जविवाओं) के जलए पेंिन, आम आिमी बीमा योिना और स्ट्वास्ट््य बीमा
िैसी बीमा योिनाएँ िाजमल िैं।
4.7.2 एसएिीवाई ग्राम पंचायतों में पररयोिनाओं को अनुमोदित ग्राम जवकास योिना के अनुसार अजभसरण के माध्यम
से कायागजन्वत दकया िाता िै, िो स्ट्थानीय आवश्यकताओं के अनुसार सामुिाजयक सिभाजगता के माध्यम से तैयार की िाती
िैं। जवकलांगिनों तक पहुंच में सुिार के जलए, पीएमएवाई-िी के तित पररयोिनाओं के कायागन्वयन के िौरान एसएिीवाई
ग्राम पंचायतों को प्राथजमकता िी िानी चाजिए। एसएिीवाई में आवासों की जनगरानी ग्राम स्ट्तरीय सजमजत द्वारा की िानी
िै।
4.8

राष्ट्रीय ग्रामीण जवकास संस्ट्थान और पंचायती राि (एनआईआरडी और पीआर)

4.8.1 एनआईआरडी एवं पीआर कें रीय ग्रामीण जवकास मंत्रालय के तित एक स्ट्वायि संगठन िै, यि ग्रामीण जवकास
और पंचायती राि मंत्रालय के अंतगगत एक प्रमुख उत्कृ ष्टता कें र िै। यूएन-ईएससीएपी उत्कृ ष्टता कें रों में से एक के रूप में
अंतरराष्ट्रीय स्ट्तर पर मान्यता प्राप्त, यि कें र प्रजिक्षण, अनुसि
ं ान और अंतर-संबंजित परामिग गजतजवजियों के माध्यम से
ग्रामीण जवकास पिाजिकाररयों, पंचायती राि संस्ट्थानों के जनवागजचत प्रजतजनजियों, बैंकरों, गैर-सरकारी संगठनों और अन्य
जितिारकों की क्षमता का जनमागण करता िै। संस्ट्थान तेलंगाना राज्य के ऐजतिाजसक ििर िैिराबाि में जस्ट्थत िै।
एनआईआरडी एवं पीआर ने 2008 में अपनी स्ट्थापना का स्ट्वणग ियंती वषग मनाया। िैिराबाि में मुख्य पररसर के अलावा,
पूवोिर क्षेत्रीय आवश्यकताओं को पूरा करने के जलए इस संस्ट्थान का उिर-पूवी क्षेत्रीय कें र गुवािाटी, असम में िै।
4.8.2 एनआईआरडी एवं पीआर का जविन उन नीजतयों और कायगक्रमों पर ध्यान कें दरत करना िै िो ग्रामीण गरीबों को
लाभाजन्वत करते िैं, लोकतांजत्रक जवकें रीकरण प्रदक्रयाओं को सदक्रय बनाते िैं, ग्रामीण जवकास कर्मगयों की कायगक्षमता और
िक्षता में सुिार करते िैं, अपनी सामाजिक प्रयोगिालाओं, प्रौद्योजगकी पाकग के माध्यम से प्रौद्योजगकी िस्ट्तांतरण को बढ़ावा
िेते िैं और पयागवरण संबंिी िागरूकता का प्रसार करते िैं। ग्रामीण जवकास मंत्रालय के जलए एक "प्थंक-टैंक" के रूप में,
एनआईआरडी ग्रामीण जवकास संबंिी ज्ञान संग्रि के रूप में कायग करते हुए मंत्रालय को नीजत जनमागण और ग्रामीण जवकास
में जवकल्पों के चयन में पररवतगनों की िुरूआत करने में सिायता करेगा।
4.8.3

एनआईआरडी एवं पीआर को जनम्नजलजखत अजििेि प्राप्त िै:

क. जवकास कायों से िुड़े वररष्ठ स्ट्तर के प्रबंिकों, जनवागजचत प्रजतजनजियों, बैंकरों, गैर सरकारी संगठनों और अन्य
जितिारकों के जलए प्रजिक्षण कायगक्रम, सममेलन, संगोष्ठी और कायगिालाएं आयोजित करना;
ख. अनुसंिान िेतु सिायता,प्रोत्सािन समन्वय करना और/या राज्य, राष्ट्रीय और अंतरागष्ट्रीय जवकास एिेंजसयों के साथ
सियोग करना;
ग. ग्रामीण जवकास, जवके न्रीकृ त िासन, पंचायती राि और संबंजित कायगक्रमों के कायगक्रमों के जनयोिन और
कायागन्वयन में आने वाली समस्ट्याओं का जवश्लेषण और समािान प्रस्ट्तुत करना;
घ. राज्यों में पंचायती राि संस्ट्थाओं (पीआरआई) और ग्रामीण जवकास कायगक्रमों के कामकाि का अध्ययन;
ङ. ग्रामीण जवकास के जलए कायगक्रमों की योिना बनाने और कायागन्वयन में आने वाली समस्ट्याओं का जवश्लेषण और
समािान प्रस्ट्ताजवत करना; और
च. जवषयवस्ट्तु जनिागरण और सूचनाओं का प्रसार और पजत्रकाओं, ररपोटग, ई-मॉड्यूल और अन्य प्रकािनों के माध्यम से
प्रौद्योजगकी िस्ट्तांतरण।

<!-- page 55 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1156/117
1234/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

447

अध्याय 5
ग्रामीण क्षेत्रों में सड़कों, भवनों और सावगिजनक सुजविाओं तक पहुंच िेतु व्यवस्ट्थाएँ
5.1 ग्रामीण सड़के
i.

ग्रामीण मागग कायग स्ट्थल, बाजार, जनकटवती गाँव, मंदिर, स्ट्कूल, अस्ट्पताल आदि तक पैिल चलने के जलए और
पीएमिीएसवाई के तित जनर्मगत सड़कों से संपकग ता के जलए एक सावगिजनक मागग िै। मनरेगा के तित कायग स्ट्थल
के बािरी/भू-भाग क्षेत्रों में पीडब्‍ल्यूडी के जलए जनरंतर सुलभ मागों का प्राविान दकया िाना चाजिए।

ii.

दिव्यांगिनों के जलए खुली नाजलयों पर िाजलयों का प्राविान दकया िाए। प्रवेि द्वार पर प्रिान की िाने वाली
िाली, यदि कोई िो, एक दििा में 13 जममी से अजिक चौड़ी निीं िोनी चाजिए तादक बैसाजखयों या पजियों के
फं सने से बचा िा सके , और इसे इस तरि से लगाया िाना चाजिए तादक चैनल िाली स्ट्लॉट आवािािी दििा के
समानांतर न िों।

iii.

प्लंकेि और रांजििनल स्ट्पेस उपयोगकतागओं के जलए बािा निीं बनने चाजिए।

iv.

यदि एक मागग में स्ट्थाजनक पररवतगन या लेवल में पररवतगन िोता िै तो उपयोगकताग के जलए यात्रा की जनरं तरता
बनाए रखने के जलए रणनीजतक स्ट्थानों पर चेतावनी संकेतक, कबग, रे प्लंग, बाड़, िेिि
े , या अन्य जनरं तर
मागगििगकों इत्यादि िैसे दििात्मक संकेत दिए िाने चाजिए। िृजष्टबाजित उपयोगकतागओं के जलए यि जविेष रूप से
मित्वपूणग िै दक वे अपने गंतव्य तक पहुंचने के जलए यात्रा पथ पर चलते रिें।

v.

पथों के साथ-साथ 150 जममी से कम के पुल स्ट्तरीय फासले को पाटने के जलए टैक्टाइल चेतावनी और कलर
कं रास्ट्ट के साथ कबग रैं प बनाए िाएंगे।

vi.

जवजभन्न रं गों/बनावटों का उपयोग करके मागों के दकनारों को स्ट्पष्ट रूप से पररभाजषत दकया िाना चाजिए। सड़क
फनीचर, पेड़, प्रकाि व्यवस्ट्था और डस्ट्टजबन मागों के एक तरफ िोने चाजिए।

vii.

फिग की सतिों में पररवतगन के जलए बनावट, रं ग और पैटनग के साथ-साथ फिग की सति पर प्रकाि का प्रभाव इतना
अचानक निीं िोना चाजिए िो उपयोगकतागओं के जलए खतरनाक िो। फिों की सतिों के बीच िुड़ाव वाली सति
को समतल दकया िाना चाजिए; जवजभन्न जनमागण सामजग्रयों के बीच कोई अंतराल या जवस्ट्तार िोड़ 13 जममी से
अजिक चौड़ा निीं िोना चाजिए।

viii.

यदि िृजष्टबाजित आगंतुकों के जलए टैक्टाइल पथ प्रिान निीं दकया िा सकता िै तो टैप्पंग रे ल प्रिान की िानी
चाजिए।

ix.

जविेष रूप से जवकट समय में पथों और मागों की जनगरानी और रखरखाव दकया िाना चाजिए।

x.

जनचले स्ट्तर के बोलाडगस खतरनाक िोते िैं और इनसे बचना चाजिए।

xi.

सड़क को पार करने के जलए सुलभ मागग के समान ऊंचाई तक उठी हुई िेब्रा क्रॉप्संग बनाई िाए।

xii.

प्राकृ जतक पररिृश्य में पथ और मागों के जलए लूि बिरी के जवकल्प को तलािा िा सकता िै। जवजभन्न प्रकार के
बोडग वॉक या रोल करने योग्य टैक्टाइल मैट के साथ कम िूरी पर रफर / अनडु लेटटंग या कम फमग इलाके तक पहुंच
िी िा सकती िै।

xiii.

नमी वाले क्षेत्रों में दफसलन को कम करने के जलए बोडगवॉक को तार की िाली से ढ़का िा सकता िै।

xiv.

यदि फिग की सति पर कापेट या कापेट टाइल का उपयोग दकया िाता िै, तो उन्िें सुरजक्षत तरीके से लगाया िाना
चाजिए। उन क्षेत्रों में लंबे, मोटे कापेट को निीं लगाया िाना चाजिए ििां पैरों मे समस्ट्या और िृजष्ट िोष वाले
व्यजियों की बार-बार आने की संभावना िो।

xv.

प्रिान दकए गए बोलाडग में रंग या ल्यूजमनेंस कं रास्ट्ट की जविेषता िोनी चाजिए और उनके बीच 1200 जममी की
स्ट्पष्ट िूरी िोनी चाजिए।

<!-- page 56 -->

903230/2023/NSAP
881918/2023/NSAP
448

1157/117
1235/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

रटप्पणी: सावगिजनक सड़कों के जनमागण के िौरान दिव्यांगिनों के बािा मुि आवागमन के जलए सड़क पररविन और
रािमागग मंत्रालय/ राज्य/संघ राज्य क्षेत्र के संबंजित जवभाग के दििा-जनिेिों का पालन दकया िाना चाजिए।
5.2

ग्रामीण क्षेत्रों में जनमागण

5.2.1 प्रवेि द्वार
i.

प्रत्येक भवन जिसमे जवद्यालय, मकान, जचदकत्सकीय सुजविाएं और कायगस्ट्थल िाजमल िै, में कम से कम एक प्रवेि
द्वार दिव्यांगिनों के जलए उपलब्‍ि िोना चाजिए और उजचत संकेत द्वारा इं जगत दकया िाना चाजिए। इस प्रवेि
द्वार को सीढ़ीिार प्रवेि के साथ एक रैंप के माध्यम से िोड़ा िाना चजिए।

ii.

प्रवेि द्वार के खुलने के जलए 900 जममी की िगि िोना चाजिए। और इसमें ऐसा कु छ निीं दकया िाएगा िो विील
चेयर उपयोगकताग के मागग में बािा डालता िो। ििलीि 12 जममी से अजिक ऊंची निीं िोना चजिए।

5.2.2 सुलभ मागग /दिव्यांगिनों के जलए पैिल मागग
i.

कायगस्ट्थल के बािरी/भू-भाग वाले क्षेत्रों में दिव्यांगिनों के जलए जनरं तर सुलभ मागों की व्यवस्ट्था ।

ii.

मौिूिा रैं प में सुिार, रे प्लंग को लंबी रैं प से िोड़ना।

iii.

सुलभ पथ कायगस्ट्थल के सभी मित्वपूणग िगिों और सुजविािनक स्ट्थानों तक उपलब्‍ि िोना चाजिए।

iv.

सभी रास्ट्ते मिबूत और दफसलन प्रजतरोिी िोने चाजिए।

v.

विीलचेयर उपयोगकतागओं के जलए रास्ट्ते और गजलयारे पयागप्त चौड़े िोने चाजिए। जबना सुरक्षा वाले वेजसन के
आसपास सुरक्षा प्रजतबंिों की व्यवस्ट्था ।

vi.

खुली नाजलयों पर िाली की व्यवस्ट्था ।

vii.

प्लंकेि और रांजििनल स्ट्पेस उपयोगकतागओं के जलए बािा निीं बनने चाजिए।

viii.

यदि एक मागग में स्ट्थाजनक पररवतगन या लेवल में पररवतगन िोता िै, तो उपयोगकताग के जलए यात्रा जनरं तरता
बनाए रखने के जलए रणनीजतक स्ट्थानों पर चैतावनी संकेतक, कबग, रे प्लंग, बाड़, िेिि
े , या अन्य जनरं तर
मागगििगकों इत्यादि िैसे दििात्मक संकेत दिए िाने चाजिए। िृजष्टबाजित उपयोगकतागओं के जलए यि जविेष रूप से
मित्वपूणग िै दक वे अपने गंतव्य तक पहुंचने के जलए यात्रा पथ पर चलते रिें।

ix.

पथों के साथ-साथ 150 जममी से कम के पुल स्ट्तरीय अंतराल को पाटने के जलए टैक्टाइल चेतावनी और कलर
कं रास्ट्ट के साथ कबग रैं प बनाए िाएंगे।

x.

जवजभन्न रं गों/बनावटों का उपयोग करके मागों के दकनारों को स्ट्पष्ट रूप से पररभाजषत दकया िाना चाजिए। सड़क
फनीचर, पेड़, प्रकाि व्यवस्ट्था और डस्ट्टजबन मागों के एक तरफ िोने चाजिए।

xi.

फिग की सतिों में पररवतगन के जलए बनावट, रं ग और पैटनग के साथ-साथ फिग की सति पर प्रकाि का प्रभाव इतना
आकजस्ट्मक निीं िोना चाजिए िो उपयोगकतागओं के जलए खतरनाक िो। फिों की सतिों के बीच िुड़ाव वाली
सति को समतल दकया िाना चाजिए; जवजभन्न जनमागण सामजग्रयों के बीच कोई फासला या जवस्ट्तार िोड़ 13 जममी
से अजिक चौड़ा निीं िोना चाजिए।

xii.

दिव्यांगिनों के स्ट्वतंत्र आवागमन के जलए प्रवेि द्वार से लेकर सभी प्रमुख सुजविाओं, सूचना काउं टरों, ब्रेल
मानजचत्रों/जनिेजिकाओं, रैं पों, सीदढ़यों और जलफ्टों तक सभी रास्ट्तों पर जनरं तर टैक्टाइल पथ दिया िाना चाजिए।

xiii.

यदि प्रवेि द्वार पर कोई िाली िो तो बैसाखी या पजियों के फं सने से बचने के जलए एक दििा में 13 जममी से
अजिक चौड़ा स्ट्थान निीं िोना चाजिए, और इसे इस प्रकार से िोना चाजिए तादक चैनल िाली स्ट्लॉट यातायात
दििा के समानांतर न िों।

xiv.

वािनों की सड़क को पार करने के जलए सुलभ मागग के समान ऊंचाई पर एक उठा हुआ िेब्रा क्रॉप्संग लगायें।

<!-- page 57 -->

1158/117
1236/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

449

xv.

यदि िृजष्टबाजित आगंतुकों के जलए टैक्टाइल पथ प्रिान निीं दकया िा सकता िै तो टैप्पंग रे ल की व्यवस्ट्था की
िानी चाजिए।

xvi.

जविेष रूप से वयस्ट्त अवजि में पथों और मागों की जनगरानी और रखरखाव दकया िाना चाजिए।

xvii.

प्राकृ जतक पररिृश्य में पथ और मागों के जलए लूि बिरी के जवकल्प को सोसग दकया िा सकता िै। जवजभन्न प्रकार के
बोडग वॉक या रोल करने योग्य टैक्टाइल मैट के साथ कम िूरी पर रफर/अनडु लेटटंग या कम फमग इलाके तक पहुंच
प्रिान की िा सकती िै।

xviii.

नमी वाले क्षेत्रों में दफसलन को कम करने के जलए बोडगवॉक को तार की िाली से ढ़का िा सकता िै।

xix.

यदि फिग की सति पर कालीन या कालीन टाइल का उपयोग दकया िाता िै, तो उन्िें सुरजक्षत तरीके से फिग से
िोड़ा िाना चाजिए। उन क्षेत्रों में लंबे, मोटे कालीन को निीं रखा िाना चाजिए ििां गजतिीलता और िृजष्ट िोष
वाले व्यजियों को बार-बार आने की संभावना िो।

xx.

जनचले स्ट्तर के बोल्डर खतरनाक िोते िैं और इनसे बचना चाजिए।

xxi.

यदि प्रिान दकए गए बोलाडग में रंग या ल्यूजमनेंस कं रास्ट्ट जविेषता िोनी चाजिए और उनके बीच 1200 जममी की
स्ट्पष्ट िूरी िोनी चाजिए।

रटप्पणी: ििां तक संभव िो सावगिजनक भवनों के जनमागण के िौरान दिव्यांगिनों के जलए बािा मुि आवागमन के जलए
सीपीडब्‍ल्यूडी के दििाजनिेिों का पालन दकया िाना चाजिए।
5.2.3 सावगिजनक सुजविाओं तक पहुंच
5.2.3 (क). िौचालय
i.

िौचालय ब्‍लॉक तक पहुंचने के जलए उपयोगकताग के अनुकूल प्राविानों की एक पूरी श्रृंखला बनाई िानी
चाजिए जिसमें टैक्टाइल गाइड पथ, जलजखत लेख और ब्रेल में जचत्रों के साथ फिग योिना, और बड़े सूचना
संकेत िाजमल िैं।

ii.

सुलभ िौचालयों में विीलचेयर के उपयोग के जलए सावगभौजमक रूप से अपनाया गया प्रतीक जचह्न बािर
प्रिर्िगत िोना चाजिए।

iii.

मौिूिा सामान्य सावगिजनक सुजविाओं में सुिार।

iv.

सभी टैक्टाइल जपक्टोग्रादफक मैप पर जचजह्नत की िाने वाली सामान्य/सुलभ सावगिजनक सुजविाओं का
स्ट्थान।

v.

विीलचेयर उपयोगकताग की सिायता के जलए कायगवािक के जलए यूजनसेक्स सुलभ िौचालय बेितर िैं।
अनुिंजसत जक्लयर फिग-2000 जममी x 2200 जममी न्यूनतम।

vi.

ििां स्ट्वतंत्र यूजनसेक्स सुलभ िौचालय ब्‍लॉक की व्यवस्ट्था संभव निीं िै, 2000 जममी x2200 जममी के
आििग आकार िेने के जलए आंतररक लेआउट को पुन: व्यवजस्ट्थत करके मौिूिा मजिला और पुरुषों के
िौचालयों के भीतर सुलभ सावगिजनक सुजविा क्यूजबकल प्रिान दकए िाने चाजिए।

vii.

िो इकाई ऊंचाई पर लगे पेयिल बेजसन उपलब्‍ि कराए िाने चाजिए और अजिमानतिः िौचालय ब्‍लॉक के
पास परं तु िौचालय के प्रवेि द्वार से िूर जस्ट्थत िोना चाजिए।

viii.

सुलभ िौचालय ब्‍लॉकों की ओर िाने वाले गजलयारों / पैिल मागों के फिग को स्ट्टेप-फ्री समतलीय टैक्टाइल
मागगििगक पथ बनाया िाना चाजिए।

ix.

मुख्य प्रवेि द्वार/सावगिजनक सुजविा िेतु द्वार और आंतररक कक्ष कम से कम 900 जममी चौड़ा िोना चाजिए।

x.

सभी िौचालय ब्‍लॉकों के अंिर कोई समतलीय जभन्नता निीं िोना चाजिए। आसान विीलचेयर गमन को
सुजविािनक बनाने के जलए मौिूिा समतलीय जभन्नता को िटाया या समतल दकया िाना चाजिए।

<!-- page 58 -->

903230/2023/NSAP
881918/2023/NSAP
450

1159/117
1237/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

xi.

सुजविाओं में विीलचेयर के जलए पयागप्त िगि प्रिान करने वाले अच्छे कं रास्ट्ट रं ग के साथ जवस्ट्तृत और
समतलीय लेआउट िोना चाजिए।

xii.

सावगिजनक सुजविाओं का उन्नयन, जिसमें क्षजतग्रस्ट्त प्लंप्बंग, सैजनटरी, जबिली और पानी की आपूर्तग दफटटंग
और उपकरणों को बिलना िाजमल िै।

xiii.

सुलभ सावगिजनक सुजविाओं की पिचान के जलए अजभगमयता के अंतरागष्ट्रीय प्रतीक का उपयोग करते हुए
संकेतक लगाएं िाने चाजिए। संकेतक बहुभाषी और टैक्टाइल िोना चाजिए।

xiv.

फिग की सति में लगी सामग्री दफसलन रजित िोनी चाजिए लेदकन गंिगी या पानी इसमें निीं रुकना चाजिए।

xv.

फिग की सूखी सति को बनाए रखने के जलए प्रभावी फिग िल जनकासी प्रिान की िानी चाजिए।

xvi.

फ्लोर ड्रेन कवसग को जबना दकसी प्रोिेक्िन के फिग की सति समतल दकया िाना चाजिए, तादक लोगो को
ठोकरे न लगे।

xvii.

डब्‍ल्यूसी (वाटर क्लोसेट) या िौचालय में पयागप्त फिग और विीलचेयर उपयोगकतागओं के प्रवेि और बािर
जनकलने के जलए 900 जममी चौड़े स्ट्टेप-फ्री िरवािे िोने चाजिए।

xviii.

डब्‍ल्यूसी (वाटर क्लोसेट) को अजिमानतिः िीवार पर लटका दिया िाना चाजिए और विीलचेयर
उपयोगकतागओं के आसान पहुंच में िोना चाजिए।

xix.

विीलचेयर उपयोगकतागओं के जलए डब्‍ल्यूसी (वाटर क्लोसेट) की सीट सिी ऊंचाई पर िोनी चाजिए।

xx.

डब्‍ल्यूसी (वाटर क्लोसेट) कमपाटगमेंट में विीलचेयर उपयोगकतागओं और िारीररक रूप से जवकलांग अन्य
व्यजियों के जलए उपयुि जस्ट्थजत और ऊंचाई पर सपोटग रे ल/ग्रैब बार िोना चाजिए। ऊपर की ओर विीलचेयर से उपर िाने के जलए फोप्ल्डंग ग्रैब बार की अनुमजत िेने की जसफाररि की िाती िै।

xxi.

डब्‍ल्यूसी (वाटर क्लोसेट) को 450 जममी -480 जममी के बीच की ऊंचाई पर लगाया िाना चाजिए।

5.2.3.(ख) सुलभ पेयिल सुजविा
i.

पेयिल के बेजसन में सामने की तरफ टोंटी िोनी चाजिए। टोंटी से पानी बेजसन के सामने लगभग समानांतर पथ में
प्रवाजित िोगी।

ii.

विीलचेयर उपयोगकतागओं के जलए टोंटी की ऊचाई फिग से 800 जममी से अजिक निीं रखी िानी चाजिए।

iii.

सवोिम कायगप्रणाली विीलचेयर उपयोगकतागओं के जलए कम से कम 750 जममी गुणा 1200 जममी का एक जक्लयर
फिग प्रिान करना िै। बेजसन के नीचे घुटने की िगि और पैर की अंगल
ु ी की िगि प्रिान की िानी चाजिए। फिग पर
न्यूनतम 230 जममी की पैर की अंगल
ु ी की िगि और फिग से बेजसन के नीचे तक 700 जममी की घुटने की िगि की
आवश्यकता िोती िै।

iv.

जनयंत्रक सामने लागाया िाना या आगे वाले दकनारे पर लगाया िाना चाजिए और एक िाथ से आसानी से
संचाजलत िोना चाजिए।

v.

िल का प्रवाि कम से कम 100 जममी ऊंचा िोना चाजिए तादक पानी के प्रवाि के नीचे एक कप या जगलास रखा
िा सके ।

vi.

गोल या अंडाकार कटोरे वाले पीने के बेजसन में टोंटी को इस तरि से लगाया िाना चाजिए दक पानी का प्रवाि
बेजसन के सामने वाले दकनारे से 75 जममी के भीतर िो।

रटप्पणी:(i) ििां तक संभव िो पेयिल एवं स्ट्वच्छता जवभाग के दििा-जनिेिों के अनुसार दिव्यांगिनों के जलए ग्रामीण क्षेत्रों में पीने
के पानी और स्ट्वच्छता के मामले में सभी प्रासंजगक जनयमों का पालन दकया िाना चाजिए।

<!-- page 59 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1160/117
1238/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

451

(ii) ििां तक संभव िो, ग्रामीण क्षेत्रों में सड़क, भवन और सावगिजनक सुजविाओं के मामले में सभी प्रासंजगक जनयमों को
दिवयांगिन के जलए बािा मुि जनर्मगत वातावारण िेतु सुमेजलत दििाजनिेि और स्ट्थान मानक-2021 {एचिी-2021}
(एम/ओ एचयूपीए) में पररभाजषत दकया िाना चाजिए।
5.3

जिकायत जनवारण

इन दििाजनिेिों के गैर-कायागन्वयन से संबंजित दकसी भी जिकायत के जनवारण के जलए, कें रीकृ त लोक जिकायत जनवारण
और जनगरानी प्रणाली (CPGRAMS) में प्रिान की गयी प्रणाली का उपयोग दकया िाएगा।
5.4 जनगरानी तंत्र
ग्राम पंचायतों द्वारा गरठत ग्राम स्ट्तरीय सजमजतयों के माध्यम से इन दििाजनिेिों के कायागन्वयन की जनगरानी की िानी
चाजिए।
अध्याय 6
सूचना प्रौद्योजगकी और संचार प्रणाली
6.1.

वेबसाइट तक पहुँच

6.1.1 ग्रामीण जवकास जवभाग की वेबसाइट और जवभाग द्वारा कायागजन्वत की िा रिी योिनाओं से संबंजित वेबसाइट,
जिसमें योिनाओं की मूल जविेषताएं, पात्रता, आवेिन, आवेिन की जस्ट्थजत, पंिीकरण, लाभ, जनगरानी, जिकायत जनवारण
आदि िाजमल िैं, तक पहुंच के जलए इलेक्रॉजनक्स और सूचना प्रौद्योजगकी मंत्रालय की भारत सरकार की वेबसाइटों
(GIGW) के जलए उजल्लजखत दििाजनिेिों का पालन करना चाजिए।
6.1.2 इन दििाजनिेिों का अनुपालन ग्रामीण जवकास जवभाग की वेबसाइटों को जवकलांग व्यजियों के जलए सुलभ बनाएगा
और यि सुजनजित करेगा दक जवकलांग व्यजि आसानी से वेबसाइट का प्रयोग कर सकें ।
6.2

आईसीटी उत्पािों और सेवाओं तक पहुंच के जलए बीआईएस मानक

यि िेखते हुए दक सूचना, पंिीकरण और भुगतान आदि तक पहुँचने के जडजिटल सािन प्रचजलत िो गए िैं, इन जवजियों को
भारतीय मानक ब्‍यूरो द्वारा अजिसूजचत प्रासंजगक वेबसाइटों, ऐप्स, जडजिटल िस्ट्तावेजों और सॉफ़्टवेयर के अनुपालन द्वारा
सुलभ िोना चाजिए। (आईएस 17802 आईसीटी उत्पािों और सेवाओं तक पहुँच भाग I आवश्यकताएँ और भाग 2
अनुरूपता का जनिागरण)।
ग्रंथ-सूची
•

दिवयांगिन के जलए बािा मुि जनर्मगत वातावारण िेतु सुमेजलत दििाजनिेि और स्ट्थान मानक-2021 [एचिी2021] (आवास और ििरी मामलों का मंत्रालय)। (दिव्यांगिनों और बुिुगग व्यजियों के जलए बैररयर मुि
आवागमन 2016 जनर्मगत पयागवरण)।

•

कें रीय लोक जनमागण जवभाग (सीपीडब्‍ल्यूडी) के दििाजनिेि

•

इलेक्रॉजनक्स और सूचना प्रौद्योजगकी मंत्रालय (एमईआईटीवाई) के दििाजनिेि।

•

सड़क पररविन और रािमागग मंत्रालय के दििाजनिेि

•

भारत सरकार के सामाजिक न्याय और अजिकाररता मंत्रालय के दिव्यांगिन सिजिकरण जवभाग द्वारा
जनर्मगत अवसंरचना में अजभगमयता को कम करना।
******

<!-- page 60 -->

903230/2023/NSAP
881918/2023/NSAP
452

1161/117
1239/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

MINISTRY OF RURAL DEVELOPMENT
(Department of Rural Development)
(NSAP-Division)
New Delhi, the 26th June, 2023
G.S.R. 77.—The enclosed Rural Sector Specific Harmonized accessibility Standards/ guidelines as approved
by the competent authority be published, as required, under Part-II, Section-3, Sub Section-(i) in the Gazette of India.
[F. No. J-11060/01/2021-NSAP]
KALYANI MISHRA, Economic Adviser

ABBREVIATIONS
S. No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.
42.

Abbreviation
ATR
BPL
CIF
CRP
DRP
FM
GP
GRIMMS
GRRIS
GS
IAP
ICT
IEC
IGNDPS
IGNOAPS
IGNWPS
MGNREGA
MIS
MoRD
NFBS
NGO
NLM
NRLM
NSAP-PPS
NULM
PMAY-G
PMU
PO
PRI
RF
RSBY
RTI
SAU
SC
SECC
SHG
ST
UC
ULB
VO
VRF
VRP

Full Form
Action Taken Report
Below Poverty Line
Community Investment Fund
Community Resource Personnel
District Resource Person
Financial Misappropriation
Gram Panchayat
GIS enabled Road Information Management & Monitoring System
Geospatial Rual Roads Information System
Gram Sabha
Integrated Action Plan
Information & Communications Technology
Information, Education and Communication
Indira Gandhi National Disability Pension Scheme
Indira Gandhi National Old Age Pension Scheme
Indira Gandhi National Widow Pension Scheme
Mahatma Gandhi National Rural Employment Guarantee Act
Management Information System
Ministry of Rural Development
National Family Benefit Scheme
Non Government Organisation
National Level Monitors
National Rural Livelihoods Mission
National Social Assistance Programme-Pension Payment System
National Urban Livelihoods Mission
Pradhan Mantri Awas Yojana - Grameen
Programme Management Unit
Post Office
Panchayati Raj Institutions
Revolving Fund
Rashtriya Swasthya Bima Yojana
Right to Information Act
Social Audit Unit
Scheduled Caste
Socio Economic and Caste Census
Self Help Group
Scheduled Tribe
Utilisation Certificate
Urban Local Bodies
Village Office
Vulnerability reduction fund
Village Resource Persons

<!-- page 61 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1162/117
1240/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

453

CHAPTER - 1
Introduction
1.1
Persons with disabilities make up a significant part of the world’s population. Their number is on the rise
due to the ageing trend being observed in certain regions and concomitant increase in prevalence of illnesses among
the elderly population. The World Health Organization (WHO) estimated that in 2011 there were approximately one
billion people with disabilities in the world, which means that 15% of the total population live with some form of
disability. This population is expected to increase over the coming decades.
1.2
Ratification of the United Nations Convention on Rights of Persons with Disabilities by India makes it
incumbent that persons with disabilities (PwDs) have access to physical environment, transportation and information
and communication on an equal basis with others in both urban and rural areas of the country. Taking a first step in
this direction, Hon’ble Prime Minister of India launched the Accessible India Campaign or the
Sugamya Bharat Abhiyan on the 3rd December, 2015 for creating a barrier free environment across the three
components of build-up environment, the transportation system and Information & Communications Technology
(ICT) system.
1.3
The purpose of Accessible India Campaign (AIC) is to create tangible assets of accessible infrastructure,
through guided change in the society towards standardized, organic and intentional development of accessible
facilities and services. The Campaign identifies the core principles to achieve this mission as follows:
(i)
Universal design (the design of products, environments, programmes and services usable by all, to
the greatest extent possible, without the need for adaptation or specialized design, applicable to assistive
devices and advanced technologies);
(ii)
Reasonable accommodation (necessary and appropriate modifications and adjustments, without
imposing a disproportionate or undue burden in a particular case, to ensure to PwDs the enjoyment or
exercise of rights equally with others)
1.4 Accessible India Campaign also serves as a tool to actualize the provisions of ‘accessibility’ mentioned under the
Rights for Persons with Disabilities Act, 2016 (RPwD Act). The RPwD Act, 2016 mandates accessibility through
Sections 40 to 46 as under:
1.4.1 Section 40: The Central Government shall, in consultation with the Chief Commissioner, formulate rules for
persons with disabilities laying down the standards of accessibility for the physical environment, transportation,
information and communication, including appropriate technologies and systems, and other facilities and services
provided to the public in urban and rural areas.
1.4.2 Section 41: (1) The appropriate Government shall take suitable measures to provide
a.

Facilities for persons with disabilities at bus stops, railway stations and airports conforming to the
accessibility standards relating to parking spaces, toilets, ticketing counters and ticketing machines.

b.

Access to all modes of transport that conform the design standards, including retrofitting old modes of
transport, wherever technically feasible and safe for persons with disabilities, economically viable and
without entailing major structural changes in design.

c.

Accessible roads to address mobility necessary for persons with disabilities.

(2) The appropriate Government shall develop schemes programmes to promote the personal mobility of persons with
disabilities at affordable cost to provide for, —
a.

Incentives and concessions.

b.

retrofitting of vehicles; and

c.

personal mobility assistance

1.4.3 Section 42: The appropriate Government shall take measures to ensure that a.

All contents available in audio, print and electronic media are in accessible format;

b.

Persons with disabilities have access to electronic media by providing audio description, sign language
interpretation and close captioning.

c.

Electronic goods and equipment which are meant for everyday use are available in universal design.

1.4.4 Section 43: The appropriate Government shall take measures to promote development, production and
distribution of universally designed consumer products and accessories for general use for persons with disabilities.

<!-- page 62 -->

903230/2023/NSAP
881918/2023/NSAP
454

1163/117
1241/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

1.4.5 Section 44: No establishment shall be granted permission to build any structure if the building plan does not
adhere to the rules formulated by the Central Government under section 40.
1.

No establishment shall be issued a certificate of completion or allowed to take occupation of a building
unless it has adhered to the rules formulated by the Central Government.

1.4.6 Section 45: (1) All existing public buildings shall be made accessible in accordance with the rules formulated
by the Central Government within a period not exceeding five years from the date of notification of such rules:
Provided that the Central Government may grant extension of time to the States on a case to case basis for
adherence to this provision depending on their state of preparedness and other related parameters.
(2) The appropriate Government and the local authorities shall formulate and publish an action plan based
on prioritization, for providing accessibility in all their buildings and spaces providing essential services such as all
primary health centers, civil hospitals, schools, railway stations and bus stops
1.4.7 Section 46: The service providers whether Government or private shall provide services in accordance with
the rules on accessibility formulated by the Central Government under section 40 within a period of two years from
the date of notification of such rules. Provided that the Central Government in consultation with the Chief
Commissioner of PwD may grant extension of time for providing certain category of services in accordance with the
said rules.”

CHAPTER-2
Definitions
2.1 ‘Barrier’ means any factor including communicational, cultural, economic, environmental, institutional, political,
social, attitudinal or structural factors which hampers the full and effective participation of persons with disabilities in
society.
2.2 “Information and communication technology (ICT)” includes all services and innovations relating to
information and communication, including telecom services, web based services, electronic and print services,
digital and virtual services.
2.3 “Person with benchmark disability” means a person with not less than forty per cent of a specified disability,
where specified disability has not been defined in measurable terms and includes a person with disability where
specified disability has been defined in measurable terms, as certified by the certifying authority.
2.4 “Person with disability” means a person with long term physical, mental, intellectual or sensory impairment
which, in interaction with barriers, hinders his full and effective participation in society equally with others.
2.5 “Public Building” means a Government or private building, used or accessed by the public at large, including a
building used for educational or vocational purposes, workplace, commercial activities, public utilities, religious,
cultural, leisure or recreational activities, medical or health services, law enforcement agencies, reformatories or
judicial foras, railway stations or platforms, roadways, bus stands or terminus, airports or waterways.
2.6 “Public facilities and services” includes all forms of delivery of services to the public at large, including
housing, educational and vocational trainings, employment and career advancement, shopping or marketing,
religious, cultural, leisure or recreational, medical, health and rehabilitation, banking, finance and insurance,
communication, postal and information, access to justice, public utilities, transportation.
2.7 “Types of Disabilities” are the same as have been mentioned in the RPwD Act, 2016, National Building Code of
India, 2016 and other relevant rules.
2.8 “Universal design” means the design of products, environments, programmes and services to be usable by all
people to the greatest extent possible, without the need for adaptation or specialized design and shall apply to assistive
devices including advanced technologies for particular group of persons with disabilities.

CHAPTER-3
MINISTRY OF RURAL DEVELOPMENT(MoRD)
Department of Rural Development (DoRD)
3.1
Ministry of Rural Development, being engaged with development and welfare activities in the rural areas,
plays a pivotal role in the overall development strategy of the country. The vision and mission of the Ministry is
sustainable and inclusive growth of rural India through a multipronged strategy for eradication of poverty by
increasing livelihoods opportunities, providing social safety net and developing infrastructure for growth. This is

<!-- page 63 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

1164/117
1242/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

455

expected to improve quality of life in rural India and to correct the developmental imbalances, aiming in the process,
to reach out to most disadvantaged sections of the society. Broadly, the aims of the Ministry of Rural Development
are:

i.

Providing livelihood opportunities and skilling to those in need including women and other vulnerable
sections with focus on poor households.

ii.

Providing for the enhancement of livelihood security of households in rural areas by providing at least 100
days of guaranteed wage employment in every financial year to every household demanding it.

iii.

Provision of all-weather rural connectivity to unconnected rural habitations and upgradation of existing roads
to provide access to market, schools and hospitals.

iv.

Providing basic housing and related amenities to BPL household in rural areas.

v.

Providing social assistance to the elderly, widow and disabled persons.

vi.

Capacity development and training of rural development functionaries.

vii.

Promoting involvement of voluntary agencies and individuals for rural development.

3.2
Department of Rural Development has been acting as a catalyst effecting change in rural areas through the
implementation of wide spectrum of programmes which are aimed at poverty alleviation, employment generation,
improvement of living standards, infrastructure development and social security. Over the years, with the experience
gained in the implementation of the programmes and in response to the felt needs of the poor, several programmes
have been modified as well as new programmes have been introduced.
3.3
Keeping in view the needs and aspirations of the local people, Panchayati Raj Institutions (PRIs) have been
involved in the programme implementation and these institutions constitute the core of decentralized development of
planning and its implementation.
3.4

The following major programmes are being implemented by the Ministry of Rural Development in rural areas:

(i)

Rural Employment- Mahatma Gandhi National Rural Employment Guarantee Act, 2005 (MGNREGA)

(ii)

Rural Livelihoods- Deendayal Antyodaya Yojana- National Rural Livelihoods Mission (DAY-NRLM)

(iii)

Deen Dayal Upadhyaya Grameen Kaushalya Yojana (DDU-GKY)

(iv)

Rural Connectivity - Pradhan Mantri Gram Sadak Yojana (PMGSY)

(v)

Pradhan Mantri Awaas Yojana – Grameen (PMAY-G)

(vi)

National Social Assistance Programme (NSAP)

(vii)

Sansad Adarsh Gram Yojana (SAGY)

Autonomous Bodies involved in the implementation/ Research:
(i)

National Institute of Rural Development & Panchayati Raj (NIRD&PR)

(ii)

National Rural Infrastructure Development Agency (NRIDA)

3.5
In addition, the Department also has schemes for capacity development of rural functionaries, Information,
Education and Communication (IEC) and Monitoring and Evaluation.
3.6
Scope of accessibility guidelines in DoRD include provision of guidelines for making various assets created
and activities undertaken through the different schemes being implemented by DoRD, accessible to persons with
disabilities such as:
•

Making the work area under Mahatma Gandhi National Rural Employment Guarantee Scheme (MGNREGS)
and community assets created under various schemes accessible to PwDs.

•

Individual assets created for PwDs adhere to the standards to make them barrier free.

•

Creation of assets under various schemes/ programmes of DoRD like MGNREGA and PMAY-G adhering to
universal design and thereby accessible to PwDs.

•

Guidelines for participation of PwDs in Rural Skills & training programmes.

•

Participation of women with disabilities in Self Help Groups.

•

Social assistance for old and PwD.

<!-- page 64 -->

1165/117
1243/126

J-11060/01/2021-NSAP

903230/2023/NSAP
881918/2023/NSAP
456

THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

CHAPTER-4
Provisions for the Persons With Disabilities under the Schemes of Department of Rural Development
4.1

Mahatma Gandhi -NREGA

4.1.1
Mahatma Gandhi National Rural Employment Guarantee Act (MGNREGA), 2005 is an Act to provide for
the enhancement of livelihood security of the households in rural areas of the country by providing at least one
hundred days of guaranteed wage employment in every financial year to every household whose adult members
volunteer to do unskilled manual work.
4.1.2
The core objectives of the Mahatma Gandhi National Rural Employment Guarantee Scheme (MGNREGS)
formulated under MGNREGA, 2005 are:

4.1.4

i.

Guaranteed employment of one hundred days of unskilled manual work in a financial year to every
household in rural areas as per demand

ii.

Creation of productive assets of prescribed quality and durability

iii.

Strengthening the livelihood resource base of the poor

iv.

Proactively ensuring social inclusion; and

v.

Strengthening Panchayat Raj Institutions

The salient features of the MGNREGA Act, 2005 are as under:
(i)

Right based Framework

d. Right to demand work – at least 100 days by a rural household
e. Right to employment - within 15 days of application, else unemployment allowance
f. Right to wages - within 15 days, else delay compensation
(ii)

Labour Intensive Works

c. 60:40 wage and material ratio for works at district level
d. No contractors or labour displacing machinery allowed
4.1.4
The engagement of PwD under MGNREGS shall be as per the relevant provisions of the MGNREGS Act,
guidelines and Rules made there under:
(i) The Operational Guidelines stipulate that special conditions are to be created for inclusion of PwDs in the
MGNREGS:
“Each State Government will identify specific works, which can be done by the disabled and vulnerable persons. In a
village, different categories of persons with disabilities will be organized to come together as a fixed group to
accomplish the works proposed for them under the Scheme, in a way that makes it possible for them to exercise their
choice. On no grounds, should the persons with disabilities and vulnerable persons be paid lower wages as compared
to other persons employed in Mahatma Gandhi NREGA works.”
(ii) Disability-wise identification of job roles under MGNREGA are explained in chapter-9 of operational guidelines.
List of major works identified for persons with disabilities (PwD) under Mahatma Gandhi NREGA are as under:
(a)

Supply of drinking water

(b)

Taking Care of children at work site

(c)

Plantation works

(d)

Excavation in irrigation canal

(e)

Earth filling

(f)

Laying of excavated earth / laying of earth in trolley

(g)

Building Construction –Preparation of Concrete Material

(h)

Arranging the construction material

(i)

Providing cement & bricks

(j)

Filling sand in the carriage basket

(k)

Curing of newly constructed wall

<!-- page 65 -->

1166/117
1244/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

(l)

Well Deepening-Filling soil/silt into the basket

(m)

Support in extracting water from the well

(n)

Dumping debris in the trolley

(o)

Removal of debris in ponds

(p)

Filling derbies into the pan(vessel)

(q)

Dumping filled pan into trolley

(r)

Carriage of stone

(s)

Stacking of stones

(t)

Land leveling works

(u)

Field Bounding works

(v)

Excavation of water conservation trench

(w)

Removing excavated earth from the trench

(x)

Road construction-Cleaning of road with broom

(y)

Filling of water, earth

457

(iii)
As per the provisions of Para 18, Schedule I of the Mahatma Gandhi NREGA “a separate Schedule of rates
shall be finalized for women, the elderly, people with disabilities and people with debilitating ailments, so as to
improve their participation through productive work.”
(iv) The disability-wise job roles will be identified and implemented by the States/UTs on priority basis.
(v)
There shall be provision of continuous accessible pathways for PwDs throughout the external/ landscaped
areas of the work site.
(vi)
States/UTs should provide accessibility of PwDs to the facilities like creche, drinking water, first aid and
shade etc. in the MGNREGA worksite.
(vii)
CPWD Guidelines (Harmonised Guidelines and Standards for universal accessibilities in India 2021) may be
followed in case of construction/creation of new common facility centre, GP Bhawan & other proposed work taken up
under MGNREGA.
4.2. Deendayal Antyodaya Yojana- National Rural Livelihood Mission (DAY-NRLM)
4.2.1
Deendayal Antyodaya Yojana- National Rural Livelihood Mission (DAY-NRLM) has a special focus on
priority and early inclusion of the poorest of the poor and other vulnerable sections of community viz., Households
automatically included by the Socio Economic Caste Census (SECC), Schedule Caste (SC), Schedule Tribe (ST),
Particularly Vulnerable Tribal Groups (PVTGs), women headed families, elderly persons, People living with different
abilities/ People with Disabilities (PwDs), minority groups and people living in extremist affected areas, hill terrains
(hard to reach areas), trafficked women, people engaged in unhygienic occupations (ex-manual scavengers),
transgender, HIV/AIDS+ persons and their families, families with one or more persons suffering from chronic illness
etc.
4.2.2
NRLM tries and achieves complete inclusion of the entire target including the poorest and vulnerable
communities into their institutional architecture within a period of initial 18 months of entering an intensive block.
NRLM expects the vulnerable persons to take significant proportion of leadership positions in various community
institutions under NRLM. Further, NRLM facilitates these institutions in achieving their financial and
economic/livelihoods inclusion and poverty reduction goals.
4.2.3 For PwDs, the following special provisions exists under DAY-NRLM:
(i)
All PwDs (aged one year and above), irrespective of percentage of disability of a person (even less than
40% of disability) can be a member of PwD SHG (Self Help Groups) and PwD SHGs are eligible for all funds to
communities {Revolving Fund RF, Vulnerability Reduction Fund(VRF), Community Investment Fund(CIF),
Livelihoods Fund(LF)} under NRLM a.

1-17 year person with disability, or a person with Mental Disability, Mental Illness or Mental
Retardation, could be represented through his/her legal guardian/parent/care-giver as member in the
PwD SHG. Legal guardian/parent/care-giver continues in her own SHG. However, the members of the
concerned group are required to do monitoring to ensure that the person concerned is getting the
benefit.

<!-- page 66 -->

1167/117
1245/126

J-11060/01/2021-NSAP

903230/2023/NSAP
881918/2023/NSAP
458

THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

b.

An individual PwD would be a member of PwD SHG and in case of more than one PwDs are in a
household, then each PwD would become the member of PwD SHG as an individual member of PwD
SHG.

c.

If a woman with disability is already a member in the existing women SHG in the village, she would
have the liberty to either continue in the same group or join the PwD SHG. In case she decides to
continue in the same group (non PwD SHG), she should get all other benefit as a PwD.

(ii)
At Mission level, the following steps are taken for identification, mobilization and institution building of
PwDs:
a.

Sensitize the staff in orientation /refresher workshops, community cadres, leaders, members and
institutions to PwDs and working with them.

b.

Develop Modules and Material.

c.

PwD SHG Practitioner's Manual (including perceptions on PwD).
(http://nirdpr.org.in/nird_docs/nrlm/nrlmhandbookSocialInclusion050716.pdf)

d.

Sensitization/Awareness Building IEC Materials (Print and Digital).

e.

Training Module for community cadre on Rights and Entitlements of the PwD.

f.

Resource Module for community cadre on community based social security, Health & Nutrition
(including mental health) and recreational needs of the PwD.

g.

Resource Module on PwD specific livelihoods.

h.

Train and nurture Community Resource Personnel (CRPs) to work with PwD Agenda.

(iii)
At Village and Cluster levels following steps are to be taken for identification, mobilization and institution
building of PwDs:
a.

Identification and mobilization of PwDs during the first CRP round itself.

b.

Mobilization of PwDs into general SHGs or special PwD SHGs. Being a marginalized group,
creating special groups of PwD may be advantageous.

c.

Mobilization of active and assisted PwDs on a saturation mode. A process of self-selection can be
adopted based on ability and agility.

d.

Mobilization of PwDs included in the SECC (auto-included and at least 1 deprivation) and PwDs
suffering under multiple vulnerabilities like single men/women, belonging to SC/ST and minority
communities, elderly etc.

e.

To adopt and strengthen existing PwD SHGs, if any, in the village.

f.

To facilitate compliance on Panchasutra for each PwDS HG with appropriate customization.

g.

To facilitate community to identify 2-3 active women per village to be trained (including
immersion/exposure visits to PwD SHGs and their federal immersion sites) and to be deployed as
PwD Inclusion Cadres/CRPs.

h.

To mandate active women for inclusion of PwD CRPs and to mandate Village Organizations (VOs)
to saturate mobilization and also to involve Anganwadi and ASHA workers in PwD agenda in the
village.

i.

To take up capacity building of the PwD SHG members, leaders and cadres as per the plan. Capacity
building needs and processes may be distinctly different for the Active, Assisted and Dependent
PwDs.

j.

To facilitate PwD SHG to access Revolving Fund.

k.

Facilitate PwD SHGs to get federated into VO (federation of women SHG at the village level). Like
other women SHGs, PwD SHGs are entitled to avail all benefits like CIF, VRF from the VO and
higher level federations.

l.

To facilitate VO to have a sub-committee or a sub-group within Social Action Committee to
regularly monitor and strengthen these PwD groups.

m. To facilitate Vulnerability Reduction Plan to include plan for PwDs.
n.

To facilitate Rehabilitation Support to PwDs.

<!-- page 67 -->

1168/117
1246/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

459

o.

To facilitate PwD centric and/or PwD friendly livelihoods and collectivization around these
activities, where required/feasible.

p.

To facilitate PwD SHGs, for their solidarity, advocacy etc., into a separate exclusive federation at
GP/cluster/block level and at higher levels.

4.3 Rural Connectivity- Pradhan Mantri Gram Sadak Yojana PMGSY)
4.3.1
The Government of India, as a part of poverty reduction strategy, launched the Pradhan Mantri Gram Sadak
Yojana (PMGSY I) on 25th December, 2000 as a Centrally Sponsored Scheme to assist the States through ‘Rural
Roads”. The primary objective of Pradhan Mantri Gram Sadak Yojana (PMGSY) is to provide connectivity, by way
of an all-weather road with necessary culverts and cross-drainage structures, which is operable throughout the year, to
eligible unconnected habitations in rural areas.
4.3.2
As the programme unfolded, a need was felt for consolidation of the existing Rural Road Network to
improve its efficiency not only as a provider of transportation services, but also as a vehicle of social and economic
development. Accordingly, in the year 2013, PMGSY-II was launched for upgradation of selected through routes and
Major Rural Links (MRLs) with a target to upgrade 50,000 Km in various states and Union Territories. Subsequently,
in 2016, Road Connectivity Project for Left Wing Extremism Affected Areas (RCPLWEA) for construction/upgradation of strategically important roads was launched as a separate vertical under PMGSY. In the year 2019,
Government launched PMGSY-III for consolidation of 1,25,000 Km Through Routes and Major Rural Links
connecting habitations, inter-alia, to Gramin Agricultural Markets (GrAMs), Higher Secondary Schools and Hospitals.
4.3.3
All the roads constructed under PMGSY are mapped in GIS- based platforms for geo-tagging and spatial
planning such as GRIMMS, GRISS and Geo-PMGSY and the data is also made accessible to public and other vendors
like Google Maps, etc. for development of applications which also prove to be helpful to persons with disabilities.
4.3.4
Since rural roads are generally low traffic volume roads and accident rates are presently quite low, safety
issues relate mainly to universal design and construction features and road safety consciousness of local residents. As
per the scheme guidelines, as part of the rural road development and maintenance programmes, the concerned State
Government shall ensure road safety audit of PMGSY works along with quality monitoring. It shall also ensure
adequate involvement of Panchayat Raj Institutions.
4.3.5
Respective Gram Panchayats should take all steps for universal design and construction of all weather rural
road with facilities for walk ability, orientation, street crossing etc.
4.3.6
The relevant guidelines of Ministry of Road Transport and Highways, CPWD and SPWD should be followed
to create a barrier free environment for PwDs during the construction of the public road. “Meri Sadak” App is also
available for use by all PwDs for availing facilities in the rural roads.
4.4 Rural Housing -Pradhan Mantri Awaas Yojana-Gramin (PMAY-G)
4.4.1
The erstwhile rural housing scheme, Indira Awaas Yojana (IAY) had been re-structured into Pradhan
Mantri Awaas Yojana – Grameen (PMAY-G) in view of Government’s commitment to provide “Housing for all” by
2024 and to address the gaps in the previous housing schemes. The re-structured scheme Pradhan Mantri Awaas
Yojana – Grameen (PMAY-G) came into effect from 1st April 2016. The aim of PMAY-G is to provide a pucca
house with basic amenities to all houseless and households living in kutcha/dilapidated houses in rural areas of the
country.
4.4.2
Under PMAY-G, as per the provisions of the Rights for Persons with Disabilities Act, 2016, as far as
possible, States/UTs are to ensure that 5% of the beneficiaries are from among the persons with benchmark
disabilities with priority to women with benchmark disability. Barrier free design should be adopted for the houses
constructed under PMAY-G for the PwDs. Ramp should be constructed for each house allotted to PwD’s. This
enables the PwD’s to have easier movement in and out of the house and this Ramp is to be constructed by the
beneficiary himself/herself within the assistance provided for construction of house.
4.4.3
Universal Design is to be incorporated in rural housing so that it can be adapted as per the need of PwDs
without any major retrofitting cost. A bouquet of location/climate/culture appropriate house designs can be accessed
through the PAHAL (Prakriti, Hunar, Lokvidya) Compendium which is available in the website of PMAYG :
(i)

https://pmayg.nic.in/netiay/Document/Pahal.pdf

(ii)

https://pmayg.nic.in/netiay/Document/Pahal-Volume-II.pdf.

The States/UTs should sensitize the beneficiaries regarding the design of houses specific to their region of residence
by incorporating the disaster resilient features.
4.4.4
Under PMAY-G, the beneficiaries are provided assistance for construction of house and it follows an owner
driven construction approach. The beneficiaries are free to choose the design of house as per their choice. The features
related to access of PwD should be allowed and encouraged.

<!-- page 68 -->

903230/2023/NSAP
881918/2023/NSAP
460

1169/117
1247/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

4.4.5
Under Rural Mason Training (RMT) for training of masons for quality construction of houses, the houses of
PwDs are to be taken up for quality construction with associated accessibility features. Mason Training and
certification should include training on universal design based accessibility in PMAY-G.
4.4.6
PMAY-G website (including AwaasSoft), compliant with screen reader access for visually challenged
persons shall be increasingly used.
4.4.7
PMAY-G should follow all relevant rules as defined in Harmonised Guidelines
universal Accessibility in India-2021, as far as possible.
4.5

and Standards for

National Social Assistance Programme (NSAP)

4.5.1
Article 41 of the Constitution of India directs the State to provide public assistance to its citizens in case of
unemployment, old age, sickness and disablement and in other cases of undeserved want within the limit of its
economic capacity and development. Directive Principles of State Policy enshrined in the Constitution of India enjoin
upon the State to undertake within its means a number of welfare measures. It is in accordance with these noble
principles that the Government of India introduced National Social Assistance Programme (NSAP) in 1995 as a
Centrally Sponsored Scheme under which 100 per cent Central assistance is extended to the States/UTs to provide the
benefits in accordance with the norms, guidelines and conditions laid down by the Central Government.
4.5.2
NSAP is a social assistance programme for poor households- for the aged, widows, and disabled in the case
of death of the breadwinner, thereby aiming at ensuring minimum national standards in addition to the benefits that
the States are providing or might provide in future. The intention in providing hundred per cent central assistance is to
ensure that social protection to the beneficiaries is available throughout the country. There is state-wise, sub-schemewise ceilings of beneficiaries under NSAP. States are free to add on and expand their coverage.
4.5.3
Under Indira Gandhi National Disability Pension Scheme (IGNDPS), a sub-scheme of National Social
Assistance Programme (NSAP), central assistance @ Rs.300 per month is provided to persons aged 18-79 years with
severe and multiple disabilities and belonging to family living below poverty line as per the criteria prescribed by
Government of India. After attaining the age of 80 years, the beneficiaries are shifted to Old Age Pension Scheme for
getting pension of Rs. 500/- per month.
4.5.4 For the older population, under Under Indira Gandhi National Old Age Pension Scheme (IGNOAPS), a subscheme of National Social Assistance Programme (NSAP), central assistance @ Rs.200 per month is provided to
persons aged 60-79 years and belonging to family living below poverty line as per the criteria prescribed by
Government of India. After attaining the age of 80 years, the beneficiaries get pension of Rs. 500/- per month.
4.6

Deen Dayal Upadhyaya Grameen Kaushalya Yojana (DDU-GKY)

4.6.1
Ministry of Rural Development (MoRD) revamped the placement linked skill development program under
National Rural Livelihood Mission as Deen Dayal Upadhyaya Grameen Kaushalya Yojana (DDU-GKY) on the
25th September, 2014.
4.6.2
DDU-GKY is a State led scheme being implemented in public-private partnership (PPP) mode, based on
demand driven target sanction process. Under DDU-GKY two special programs are being implemented. i.e; ROSHNI
program is being implemented for 27 left wing extremist affected areas of 9 States with mandatory residential course
with 40% coverage to women candidates; and Himayat- All youth of the UT of Jammu & Kashmir and Ladakh are
covered under this scheme with 100% central funding.
4.6.3

The key features of DDU-GKY are as follows:

(i)
Focus on rural youth from poor families in the age group of 15 to 35 years belonging to: a) MGNREGA
worker household if any person from the household has completed 15 days of work, b) Rashtriya Suraksha Bima
Yojana(RSBY) household, c) Antyodaya Anna Yojana card household, d) Below Povety Line(BPL) Public
Distribution System(PDS) card households, e) NRLM-SHG household, f) Participatory process of Identification of
poor, g) Households covered under auto inclusion parameters of SECC 2011.
(ii)
Mandatory coverage of socially disadvantaged groups, i.e for SC/ST-50%, Minorities- 15%, and Women
33%) & Special focus on Manual Scavengers, PwDs and Women headed household.
(iii)
Salary to the placed candidates is given as per the Minimum wages or above, post-placement support to
candidates & Career progression support to training partners.
(iv)
DDU-GKY guidelines have mandated 5% coverage for PwD Candidates (Notification no. 02/2020 dated
07.02.2020).
(v) A special framework for DDU-GKY PwD projects was also introduced, which includes interalia provision on
accessibility to the training centers, residential facilities, personal assistive aids, teaching aids etc. (Notification no.
43/2017 dated 31.07.2017).

<!-- page 69 -->

1170/117
1248/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

461

(vi)
The process of mobilization of candidates under DDU-GKY and Rural Self Employment Training Institutes
(RSETI) involves the representatives of panchayat level.
(vii)

There are dedicated portals/apps (Kaushal Bharat, Kaushal panjee) to manage the skills schemes.

(viii)

There are special provisions for hilly areas in the DDU-GKY guideline.

4.7

Saansad Adarsh Gram Yojana (SAGY)

4.7.1
Saansad Adarsh Gram Yojana (SAGY) was launched in 2014 with the aim to develop one village by each
Member of Parliament as a model village (Adarsh Gram) by 2016 and two more by 2019. Thereafter, five such
Adarsh Grams (one per year) are to be selected and developed by 2024. A total of 3,074 Gram Panchayats have
already been identified by Members of Parliament as on 31.12.2022 who are taking concrete steps towards their
holistic development through convergence of other Central and State schemes. Pensions for all eligible families (old
age, disability and widow), insurance schemes like Aam Aadmi Bima Yojana & Health insurance (RSBY) are covered
under the scheme.
4.7.2
In SAGY GPs, projects are implemented through convergence as per the approved Village Development
Plan, which are prepared through community participation as per the local requirements. In order to improve the
accessibility to PwDs, priority to SAGY GPs should be given during implementation of projects under PMAY-G.
Houses in SAGY are to be monitored by Village level committee.
4.8

National Institute of Rural Development and Panchayati Raj (NIRD&PR)

4.8.1
NIRD&PR is an autonomous organisation under the Union Ministry of Rural Development, is a premier
national centre of excellence in rural development and Panchayati Raj. Recognized internationally as one of the UNESCAP Centres of Excellence, it builds capacities of rural development functionaries, elected representatives of PRIs,
bankers, NGOs and other stakeholders through inter-related activities of training, research and consultancy. The
Institute is located in the historic city of Hyderabad in Telangana state. The NIRD&PR celebrated its Golden Jubilee
Year of establishment in 2008. In addition to the main campus at Hyderabad, this Institute has North-Eastern Regional
Centre at Guwahati, Assam to meet the NE-regional needs.
4.8.2
The vision of NIRD&PR is to focus on the policies and programmes that benefit the rural poor, strive to
energise the democratic decentralization processes, improve the operation and efficiency of rural development
personnel, promote transfer of technology through its social laboratories, Technology Park and create environmental
awareness. As a “think-tank” for the Ministry of Rural Development, NIRD while acting as a repository of knowledge
on rural development would assist the Ministry in policy formulation and choice of options in rural development to
usher in the changes.
4.8.3

The NIRD&PR is mandated to:

a.

Organise training programmes, conferences, seminars and workshops for senior level development managers,
elected representatives, bankers, NGOs and other stakeholders;

b.

Undertake, aid, promote and coordinate research on its own and / or collaborate with State, national and
international development agencies;

c.

Analyse and offer solutions to problems encountered in planning and implementation of the programmes for
rural development, decentralised governance, panchayati raj and related programmes;

d.

Study the functioning of the Panchayati Raj Institutions (PRIs) and rural development programmes across the
States;

e.

Analyse and propose solutions to problems in planning and implementation of the programmes for rural
development; and

f.

Develop content and disseminate information and transfer technology through periodicals, reports, e-modules
and other publications.

CHAPTER 5
Accessibility Features For Roads, Buildings And Public Facilities In Rural Areas
5.1

Rural Roads

(i)
A village pathway is a public footpath for walking across the land to work, to the market, to the next village,
temple, school, hospital etc. and also for connecting with the roads built under PMGSY. Under MGNREGA,

<!-- page 70 -->

903230/2023/NSAP
881918/2023/NSAP
462

1171/117
1249/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

provision of continuous accessible pathways/ walkways for PwDs throughout the external/ landscaped areas of the
work site should be made.
(ii)
Provision of gratings on open drains for PwDs should be made. Grating, if any, provided at the entrance gate
should have spaces not greater than 13 mm wide in one direction to avoid trapping of crutches or wheels, and be
placed so that Channel grating slots should not be parallel to the traffic direction.
(iii)

Linkages and transitional spaces should not form obstacles to users.

(iv)
If a pathway/ walkway leads to a spatial change or a change in level, directional cues such as signage, kerbs,
handrails, fences, hedges, or other continuous elements etc. should be provided at strategic locations to maintain travel
continuity for the user. This is particularly important for visually impaired users to continue along the travel path to
reach their destination.
(v)
Kerb ramps with tactile warning and color contrast to be provided to bridge level differences less than 150
mm along pathways.
(vi)
Edges of pathways should be clearly defined by using different colours / textures. Street furniture, trees,
lighting and dustbins should be located on one side of pathways.
(vii)
Texture, color and pattern of the change in floor surfaces, as well as the lighting effect on the floor surface,
should not be too sudden as to cause hazard to users. Junction between the different floor surfaces should be leveled;
any gaps or expansion joints between different materials should not exceed 13 mm wide.
(viii)

Tapping rails should be provided for visually impaired visitors where tactile guiding path cannot be provided.

(ix)

Paths and routes should be monitored and maintained particularly in the high season.

(x)

Low-level bollards are hazardous and should be avoided.

(xi)

Provide a raised zebra crossing at the same height as that of accessible pathway to cross the vehicular road.

(xii)
Alternatives to loose gravel can be sourced for paths and routes into the natural landscape. Access to rougher
/ undulating or less firm terrain can be provided over short distances with different types of board walk or tactile mats.
(xiii)

Boardwalks can be covered in wire mesh to reduce slipping in damp areas.

(xiv)
If carpets or carpet tiles are used on a floor surface, they should be securely attached to it. Long, thick rugs
should not be laid in areas likely to be frequented by persons with mobility and sight impairments.
(xv)
Bollards, if provided, should have a colour or luminance contrast feature and should have clear distance of
1200 mm between them.
Note: The guidelines of Ministry of Road Transport and Highways/ concerned Department in the State/UT dealing
with roads should be followed to create a barrier free environment for PwDs during the construction of the public
road.
5.2

Buildings in Rural Areas

5.2.1

Entrance

(i)
Every building including schools, housing, medical facilities, and workplaces should have at least one
entrance accessible to the persons with disabilities and shall be indicated by proper signage. This entrance shall be
approached through a ramp together with the stepped entry.
(ii)
Minimum clear opening of the entrance door shall be 900 mm. and it shall not be provided with a step that
obstructs the passage of a wheel chair user. Threshold shall not be raised more than 12 mm.

5.2.2

Accessible Pathways/ Walkways for PwDs
Following steps should be taken for accessible pathways/walkways for PwDs:

(i)

Provision of continuous accessible pathways for PwDs throughout the external/ landscaped areas of the site.

(ii)

Improvements to existing ramps, addition of handrails to long ramps.

(iii)

The accessible path should preferably lead to all important attractions and vantage points in the site.

(iv)

All pathways should be firm and slip-resistant.

(v)
Pathways and corridors should be wide enough for wheelchair users. Provision of Safety kerbs around
unguarded fountains.
(vi)

Provision of gratings on open drains.

<!-- page 71 -->

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]
(vii)

1172/117
1250/126

J-11060/01/2021-NSAP
भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

463

Linkages and transitional spaces should not form obstacles to users.

(viii)
If a pathway leads to a spatial change or a change in level, directional cues such as signage, kerbs, handrails,
fences, hedges, or other continuous elements etc. should be provided at strategic locations to maintain travel
continuity for the user. This is particularly important for visually impaired users to continue along the travel path to
reach their destination.
(ix)
Kerb ramps with tactile warning and color contrast to be provided to bridge level differences less than
150mm along pathways.
(x)
Edges of pathways should be clearly defined by using different colours / textures. Street furniture, trees,
lighting and dustbins should be located on one side of pathways.
(xi)
Texture, color and pattern of the change in floor surfaces, as well as the lighting effect on the floor surface,
should not be too sudden as to cause hazard to users. Junction between the different floor surfaces should be leveled;
any gaps or expansion joints between different materials should not exceed 13mm wide.
(xii)
Continuous tactile guide path should be provided on all the pathways right from the entrance to all major
facilities, information counters, Braille maps/directories, ramps, steps and lifts, for independent navigation of PwDs.
(xiii)
Grating provided if any at the entrance gate should have spaces not greater than 13 mm wide in one direction
to avoid trapping of crutches or wheels, and be placed so that Channel grating slots should not be parallel to the traffic
direction
(xiv)

Provide a raised zebra crossing at the same height as that of accessible pathway to cross the vehicular road.

(xv)

Tapping rails should be provided for visually impaired visitors where tactile guiding path cannot be provided.

(xvi)

Paths and routes should be monitored and maintained particularly in the high season.

(xvii) Alternatives to loose gravel can be sourced for paths and routes into the natural landscape. Access to rougher
/ undulating or less firm terrain can be provided over short distances with different types of board walk or rollable
tactile mats.
(xviii)

Boardwalks can be covered in wire mesh to reduce slipping in damp areas.

(xix)
If carpets or carpet tiles are used on a floor surface, they should be securely attached to it. Long, thick rugs
should not be laid in areas likely to be frequented by persons with mobility and sight impairments.
(xx)

Low-level bollards are hazardous and should be avoided.

(xxi)
Bollards if provided should have a colour or luminance contrast feature and should have clear distance of
1200mm between them.
Note: The guidelines of CPWD should be followed to create a barrier free environment for PwDs during the
construction of the public buildings as far as possible.

5.2.3

Accessibility of Public Facilities

5.2.3(a) Toilets
(i)
A full range of user-friendly provisions should be made to reach the toilet blocks including tactile guide path,
floor plan with illustrations in written text and Braille, and large information signs.
(ii)

Accessible toilets should have the universally adopted symbol for wheelchair access displayed outside.

(iii)

Improvement to existing General Public Facilities.

(iv)

Location of general/ accessible Public Facilities to be marked on all tactile pictographic maps.

(v)
Unisex accessible toilets are preferable for the caretaker to assist the wheelchair user. Recommended clear
floor space -2000 mm x 2200 mm minimum.
(vi)
Where provision of independent unisex accessible toilet blocks is not feasible, Accessible public facility
cubicles should be provided within the existing ladies and gents toilets by reconfiguring internal layout to achieve an
ideal size of 2000mm x 2200mm.
(vii)
Drinking water fountains of two mounting heights should be provided and preferably located near the toilet
blocks but away from the toilet entrances.
(viii)
A step free leveled tactile guiding path to be provided in the floor from corridors/ walkways leading to the
accessible toilet blocks.

<!-- page 72 -->

903230/2023/NSAP
881918/2023/NSAP
464
(ix)
width.

1173/117
1251/126

J-11060/01/2021-NSAP
THE GAZETTE OF INDIA : JULY 8, 2023/ASHADHA 17, 1945

[PART II—SEC. 3(i)]

The main entrance door/opening to the public facility and internal cubicles should be minimum 900mm in

(x)
There should be no level differences inside all toilet blocks. Existing level differences to be removed or
leveled to facilitate easy wheelchair movement.
(xi)
Facilities should have wide and level layouts with good colour contrasts providing enough space for
wheelchairs.
(xii)
Modification of Public Facilities, including changing of damaged plumbing, sanitary, electrical and water
supply fittings and appliances.
(xiii)
There should be signage using the international symbol of accessibility to identify the accessible public
facilities. Signage should be multi lingual and tactile.
(xiv)

Floor surface material must be non-slippery but should not trap dirt or water.

(xv)

Effective floor drainage should be provided to maintain a dry floor surface.

(xvi)
Floor drain covers should be fixed flat on the floor surface without any projections to prevent people from
tripping over.
(xvii) WC (Water closet) or toilet compartments should have enough floor space and 900 mm wide step-free doors
for wheelchair users to enter and exit.
(xviii) The WC (Water closet) should be preferably wall hung and in a position as to permit easy approach by
wheelchair users.
(xix)

The seat of the WC (Water closet) should be at the correct height for the wheelchair users.

(xx)
WC (Water closet) compartments should have support rails / grab bars at a position and height suitable for
wheelchair users and other persons with physical disabilities. Upward- folding grab bars are recommended to allow
lateral transfer from the wheelchair.
(xxi)

WC (Water closet) should be mounted at a height between 450mm –480mm.

5.2.3.(b)Accessible Drinking Water Facility
(i)
Drinking fountains should have spouts positioned at the front of the unit. The spout shall direct the water
flow in a path almost parallel to the front of the unit.
(ii)

For wheel chair users, spouts not higher than 800mm from the floor are recommended.

(iii)
Best practice is to provide a clear floor space at least 750mm by 1200mm for wheelchair users. Knee space
and toe space should be provided underneath the fountain. A toe space of minimum 230mm from the floor and knee
space of 700mm from the floor to the underside of fountain are required.
(iv)

Controls should be front mounted or side mounted near the front edge and easily operated with one hand.

(v)
water.

Flow of water should be at least 100mm high so as to allow the insertion of a cup or glass under the flow of

(vi)
For drinking fountain having a round or oval bowl, the spout must be positioned so the flow of water is
within 75mm of the front edge of the fountain
Note:(i) All relevant rules in case of drinking water and sanitation in rural areas for PwDs should be followed as per the
guidelines of Department of Drinking water and Sanitation as far as possible.
(ii) All relevant rules in case of Road, building and public facilities in rural areas should follow as defined in
Harmonised Guidelines and Standards for universal Accessibility in India-2021 {HG-2021} (M/o HUPA) as far as
possible.
5.3

Grievance redressal

For redressal of any grievance relating to non-implementation of the these guidelines, the mechanism
provided in Centralised Public Grievance Redressal and Monitoring System (CPGRAMS) may be utilised.
5.4

Monitoring mechanism

The implementation of these guidelines should be monitored through Village level Committees to be formed
by the Gram Panchayats.

<!-- page 73 -->

1174/117
1252/126

J-11060/01/2021-NSAP

881918/2023/NSAP
903230/2023/NSAP

[भाग II—खण्ड 3(i)]

भारत का रािपत्र: िुलाई 8, 2023/आषाढ़ 17, 1945

465

CHAPTER 6
Information Technology and Communication Ecosystem
6.1.

Website accessibility

6.1.1
For accessibility to the website of the Department of Rural Development (DoRD) and those relating to the
Schemes being implemented by DoRD in which the basic features of the schemes, eligibility, application, status of
application, registration, benefits, monitoring, grievance redressal etc. have been outlined should follow the guidelines
for Indian Government Websites (GIGW) of Ministry of Electronics and Information Technology (MeiTy).
6.1.2
Compliance to these guidelines will make the websites of DoRD accessible to persons with disabilities and
ensure that the PwDs can easily navigate the website.
6.2

BIS standard for accessibility of ICT products and services

Considering that digital means of accessing information, registration and payment etc. have become prevalent, these
methods must be accessible by compliance to relevant websites, apps, digital documents and software notified by
Bureau of Indian Standards (IS 17802 Accessibility for the ICT Products and Services Part I Requirements & Part 2
Determination of Conformance).

Bibliography
•

Harmonised Guidelines and Standards for universal Accessibility in India-2021 [HG-2021] (M/o Housing
and Urban Affairs). (Barrier Free 2016 Built Environment for persons with disability and elderly persons,) .

•

Guidelines of Centre Public Works Department (CPWD)

•

Guidelines of Ministry of Electronics and Information Technology (MeiTy).

•

Guidelines of Ministry of Road Transport and Highways

•

Demystifying Accessibility in Built Infrastructure, Department of Persons with Disabilities(PwD), Ministry
of Social Justice and Empowerment.
******

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

<!-- page 74 -->

852911(1)/2023/O/o SECRETARY (RD)
903230/2023/NSAP

J-11060/01/2021-NSAP

1109/117
1253/126

<!-- page 75 -->

852911(1)/2023/O/o SECRETARY (RD)
903230/2023/NSAP

J-11060/01/2021-NSAP

1110/117
1254/126
