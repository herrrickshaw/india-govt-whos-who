---
doc_id: "03bf6ab3dca7c3d3"
source_url: "https://www.moes.gov.in/static/uploads/2025/06/46b7908b3931ac9d63792e13512f4539.pdf"
ministry: "Earth Sciences (MoES)"
title: "Tender For Supplying"
date: "2019-03-21"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6b4555bb802a01db"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF EARTH SCIENCES
Prithvi Bhavan, Lodi Road,
New Delhi

Tender for
SUPPLYING AND FIXING OF
EXTERNAL ELECTRICAL MV CABLES FOR PERIPHERIAL LIGHTING
AT PRITHVI BHAVAN, LODI ROAD, NEW DELHI
Tender No.: MoES/07/01/2019-Genl. Dated: 30-05-2019
Subject: Tender for supplying and fixing of external electrical MV cables and light fitting for
peripheral lightings at PRITHVI BHAVAN, LODI ROAD, NEW DELHI
1. Online bids under Two-Bid System
Technical Bid and Financial Bid are hereby invited on behalf of the President of India from
reputed, experienced and financially sound Companies/Firms for award of supplying and fixing
of external electrical MV cables and light fitting for peripheral lighting at PRITHVI BHAVAN,
LODI ROAD, NEW DELHI
2. Estimated cost of the tender Rs. 600000/- (Rupees Six Lacs only)
3. EMD Rs. 15000/- (Rupees Fifteen Thousand only
4. The bid will be accepted as E-tender only.
5. The tender document contains the following:
Annexure-I -- Instructions for Online Bid Submission and other general conditions
Annexure-II -- Tender acceptance letter
Annexure-III –Performa for Financial Bid
Annexure-IV -- Performa for Technical Bid
Annexure –V -- Performa towards Performance Security
Annexure – VI -- Declaration
Annexure - VII -- Bid Securing Declaration Format

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

ANNEXURE- I
Instructions for Online Bid Submission
The bidders are required to submit soft copies of their bids electronically on the CPP Portal,
using valid
Digital Signature Certificates. The instructions given below are meant to assist the bidders in
registering on the CPP Portal, prepare their bids in accordance with the requirements and
submitting their bids online on the CPP Portal. More information useful for submitting online
bids on the CPP Portal may be obtained at :https://eprocure.gov.in/eprocure/app.
REGISTRATION
1. Bidders are required to enroll on the e-Procurement module of the Central Public Procurement
Portal (URL: https://eprocure.gov.in/eprocure/app.) by clicking on the link “Online Bidder
Enrollment” on the CPP Portal which is free of charge.
2. As part of the enrolment process, the bidders will be required to choose a unique username
and assign a password for their accounts.
3. Bidders are advised to register their valid email address and mobile numbers as part of the
registration process. These would be used for any communication from the CPP Portal.
4. Upon enrolment, the bidders will be required to register their valid Digital Signature
Certificate (Class II or Class III Certificated with signing key usage) issued by any Certifying
Authority recognized by CCA India (e.g.Sify/TCS/nCode/eMudhra etc.), with their profile.
5. Only one valid DSC should be registered by a bidder. Please note that the bidders are
responsible to ensure that they do not lend their DSC’s to other which may lead to misuse.
6. Bidder than log on to the site through the secured long-in by entering their user ID/password
and the password of the DSC/ e-Token.
4. SEARCHING FOR TENDER DOCUMENTS
1. There are various search options built in the CPP Portal, to facilitate bidders to search active
tenders by several parameters. These parameters could include Tender ID, Organization Name,
Location, Date, Value, etc. There is also an option of advanced search for tenders, wherein the
bidders may combine a number of search parameters such as Organization Name, Form of
Contract, Location, Date, Other keywords etc. to search for a tender published on the CPP Portal.
2. Once the bidders have selected the tenders they are interested in, they may download the
requirement documents/ tender schedules. These tenders can be moved to the respective ‘My
Tenders’ folder. This would enable the CPP Portal to intimate the bidders through SMS/e-mail in
case there is any corrigendum issued to the tender document.

<!-- page 5 -->

3. The bidder should make a note of the unique Tender ID assigned to each tender, in case they
want to obtain any clarification/help from the Helpdesk.
5. PREPARATION OF BIDS
1. Bidder should take into account any corrigendum published on the tender document before
submitting their bids.
2. Please go through the tender advertisement and the tender document carefully to understand
the documents required to be submitted as part of the bid. Please note the number of covers in
which the bid documents have to be submitted, the number of documents- including the names
and content of each of the document that need to be submitted. Any deviations from these may
lead to rejection of the bid.
3. Bidder, in advance, should get ready the bid documents to be submitted as indicated in the
tender documents/schedule and generally, they can be in PDF/XLS/RAR/DWF/JPG formats. Bid
documents may be scanned with 100 dpi with black and white option which helps in reducing
size of the scanned document.
4. To avoid the time and effort required in uploading the same set of standard document which
are required to be submitted as part of every bid, a provision of uploading such standard
documents (e.g. PAN card copy, annual reports, auditor certificates etc.) has been provided to the
bidders. Bidders can use “My Space” or “Other important Documents” area available to them to
upload such documents. These documents may be directly submitted from the “My Space” area
while submitting a bid, and need not be uploaded again and again. This will lead to a reduction in
the time required for bid submission process.
6. SUBMISSION OF BIDS
1. Bidder should log into the site well in advance for bid submission so that they can upload the
bid in time i.e. on or before the bid submission time. Bidder will be responsible for any delay due
to other issues.
2. The bidder has to digitally sign and upload the required bid documents one by one as indicated
in the tender documents.
3. Bidder has to select the payment option as “offline” to pay the tender fee/EMD as applicable
and enter details of the instrument.
4. Bidder should prepare the EMD as per the instructions specified in the tender documents. The
original should be posted/couriered/given in person to the concerned official, latest by the last
date of bid submission or as specified in their tender documents. The details of the DD/any other
accepted instrument, physically sent, should tally with the details available in the scanned copy
and the data entered during bid submission time. Otherwise the uploaded bid will be rejected.

<!-- page 6 -->

5. Bidders are requested to note that they should necessarily submit their financial bids in the
format provided and no other format is acceptable. If the price bid has given as a standard BoQ
format with the tender documents, then the same is to be downloaded and to be filled by all the
bidders. Bidders are required to download the BoQ file, open it and complete the white colored
(unprotected) cells with their respective financial quotes and other details (such as name of the
bidder). No other cells should be changed. Once the details have been completed, the bidder
should save it and submit it only online, without changing the filename. If the BoQ file is found
to be modified by the bidder, the bid will be rejected.
6. The server time (which is displayed on the bidder’s dashboard) will be considered as the
standard time for referencing the deadlines for submission of the bids by the bidders, opening of
bids etc.
The bidders should follow this time during bid submission.
7. All the documents being submitted by the bidders would be encrypted using PKI encryption
techniques to ensure the secrecy of the data. The data entered cannot be viewed by unauthorized
persons until the time of bid opening. The confidentially of the bids is maintained using the
secured Socket Layer 128 bit encryption technology. Data storage encryption of sensitive fields
is done. Any bid document that is uploaded to the server is subjected to symmetric encryption
using buyers/bid openers public keys. Overall, the uploaded tender documents become readable
only after the tender opening by the authorized bid openers.
8. Upon the successful and timely submission of bids (i.e. after Clicking “Freeze Bid
Submission” in the portal), the portal will give a successful bid submission message & a bid
summary will be displayed with the bid no. and the date & time of submission of the bid with all
other relevant details.
9. The bid summary has to be printed and kept as an acknowledgement of the submission of the
bid. This acknowledgement may be used as an entry pass for any bid opening meetings.
7. ASSISTANCE TO BIDDERS
1. Any queries relating to the tender documents and the terms and conditions contained therein
should be addressed to the Tender inviting Authority for a tender or the relevant contact person
indicated in the tender.
2. Any queries relating to the process of online bid submission or queries relating to CPP Portal
in general may be directed to the 24×7 CPP Portal Helpdesk. The contact number for the
helpdesk is 180030702232.

8. Test report/ certificate of material
The contractor has to produce and submit detailed test report / certificate of the Cable
mandatorily from the original manufacturer while delivering the cables at site.

<!-- page 7 -->

9. Resolution of Dispute
In the matter of any dispute between the parties regarding the terms and conditions of the
contract and execution thereof, the matter shall be referred to Arbitrator(s) as may be decided by
the Secretary (MoES)/JS(A) for Arbitration under the Arbitration & Conciliation Act, 1986. The
firm or contractor shall not question the decision of arbitrator(s) on the ground that Arbitrator(s)
is/are Government Servant(s). The decision of Arbitrator(s) shall be final and binding on the
parties.
10. Applicable Law
The contract shall be interpreted in accordance with the Laws of the Union of India. Contractor
shall be solely responsible for compliance of all labour laws, payment of fair wages/ salaries and
allowances to his personnel that might become applicable under any new act, law or order of
Government of State / Centre. Ministry shall have no liability whatsoever in any manner. The
Contractor has to show the proof of payment of fair wages to his workers as and when asked for
the same by Ministry. Minimum wages Act to be complied with - The contractor shall comply
with all the provisions of the Minimum Wages Act, 1948, and Contract Labour (Regulation and
Abolition) Act, 1970, amended from time to time and rules framed thereunder and other labour
laws affecting contract labour that may be brought into force from time to time.
11. Force Majeure

Notwithstanding the provisions stated above, the service provider shall not be liable for forfeiture
of its performance security, penalty or termination for default, if and to the extent that, its delay
in performance or other failure to perform its obligations under the contract is the result of an
event of force majeure.
For purposes of this clause, “Force Majeure” means an event beyond the control of the supplier
and not involving the contractor/service provider’s fault or negligence and not foreseeable. Such
events may include, but are not limited to, acts of the service provider either in its sovereign or
contractual capacity, wars or revolutions, fires, floods, epidemics, quarantine restrictions and
freight embargoes.
If a Force Majeure situation arises, the contractor/ service provider shall promptly notify the
Ministry in writing of such conditions and the cause there of.
12. Defect liability
Contractor is bound for one year defect liability period after the date of handing over the
completed works at site.
13. Earnest Money Deposit (EMD) & Contract Performance Security
The tenderers are required to deposit on line or photocopy of the DD to be uploaded along the
tender for Rs. 15,000/- (Rupees Fifteen Thousands only) in favor of the DDO, MoES, payable at
New Delhi as Earnest Money Deposit (EMD). EMD will be returned to the unsuccessful
tenderers after award of the contract to the successful tenderer. No interest shall be payable by

<!-- page 8 -->

Ministry on EMD. Further, on award of the contract, a security deposit of an amount equivalent
to 5% of the total annual contract value in the form of Bank Guarantee with a validity for a
period more than two months over the expiry of contract period from Nationalized Bank
shall be deposited with Ministry as Contract Performance Guarantee which shall be refunded
after two months from the date of expiry/completion of the contract/contractual obligations.
After depositing the amount of the security deposit, the EMD amount would be released to
successful tenderer. In the event of the contractor failing to comply with any provision of the
contract the Contract Performance Guarantee shall stand forfeited.
14. Liquidated Damages:

In the event of the CONTRACTOR’s failure to supply the stores/services and installation of
equipment, etc as specified in this contract, the MoES may, at its discretion, withhold any
payment until the completion of the contract. The MoES may also deduct from the
CONTRACTOR as agreed, liquidated damages to the sum of 0.5% of the contract price of the
delayed/undelivered stores/services mentioned above for every week of delay or part of a week,
subject to the maximum value of the Liquidated Damages being not higher than 5% of the value
of delayed stores/services.

<!-- page 9 -->

ANNEXURE- II
TENDER ACCEPTANCE LETTER

Date:

To,
Director (General Administration)
Ministry of Earth Sciences
Prithvi Bhawan
Lodhi Road, New Delhi-110003
Sub: Acceptance of Terms & Conditions of Tender
Tender Reference No. MoES/07/01/2019-Genl.
Name of Tender/Work: Tender supplying and fixing of external electrical MV cables for
peripheral lighting at PRITHVI BHAVAN, LODI ROAD, NEW DELHI
Dear Sir,
1. I/We have downloaded/ obtained the tender document(s) for the above mentioned
‘Tender/Work’ from the web site(s) namely www.moes.gov.in or central Public Procurement
Portal of Govt. of India i.e. eprocure.gov.in as per your advertisement, given in the above
mentioned website(s).
2. I/We hereby certify that I/ we have read the entire terms and conditions of the tender
documents from page No. 1 to 15 (including all documents like annexure(s). schedule(s) etc.
which form part of the contract agreement and I/We shall abide by the terms /conditions/clauses
contained therein.
3. The corrigendum(s) issued from time to time by your department / organization on the website
too has also been taken into consideration, while submitting this acceptance letter.
4. I/ We hereby unconditionally accept the tender conditions of above mentioned tender
document(s)/ corrigendum(s) in its totality/entirety.
5. In case any provisions of this tender are found violated then your department/ organization
shall without prejudice to any other right or remedy be at liberty to reject this tender/ bid
including the forfeiture of the full said earnest money deposit absolutely.

Yours faithfully,

<!-- page 10 -->

S.
No.

Description of items

ANNEXURE- III
Performa for Financial Bid
Qty. unit
Rate

Supply and laying of armoured
(heavy duty) power cable of 1.1 KV
grade with aluminum conductor,
PVC insulated and PVC sheathed /
XLPE cable and light fitting in the
existing RCC/HUME/METAL Pipe
complete as required. (Make :
Havells/Fionolex)
( i ) 4 x 35 Sq. mm cable
( ii ) 4 X 10 Sq.mm cable
2
Supply and installation of HDPE
conduit pipe with T joints of 63 mm
for aluminum cable including
accessories complete as required
3
Supply and installation of pole boxes
size of 8''x6'' including connection
complete as required.
4
Supply and installation of cable
glands of required size including
connection complete as following.
( i ) 4 x 35 Sq. mm cable
( ii ) 4 X 10 Sq.mm cable
5
Supply
and
installation
of
12x150mm
fasteners
including
drilling and fixing etc. complete as
required.
6
Supply and installation of 32Amp.
DP MCB including connection
complete as required.
7
Civil works for cover of laying of
cable including brickwork, cement,
Mortar, sand, dust, compete as
required.
9
Fixing / fitting of the pole light

Amoun
GST
Total
t
Rate
Amoun amount
with GST
t

1

10

Enamel painting of existing light
pole of height 4.5mt to 8.5 mt as per
required.
Total
Total Rupees (in words)

400
400
400

Meter
Meter
Meter

20

Each

100
100
300

Each
Each
Each

20

Each

5

CUM

01

Each

34

Each

Rate only

<!-- page 11 -->

MoES/07/01/2019-Genl.
Government of India
Ministry of Earth Sciences, Prithvi Bhavan,
Lodi Road, New Delhi – 110003
Dated 30-05-19
Sir,
1. Ministry of Earth Sciences invites Online Bids for award supplying and fixing of External
Electrical MV cables for peripheral lighting at PRITHVI BHAVAN, LODI ROAD, NEW
DELHI .
2. The bid Security (EMD) of Rs.15,000/- in the form of a Demand Draft payable to DDO,
Ministry of Earth Sciences, is required to be submitted. The said earnest money will not bear any
interest. The earnest money of unsuccessful tenders would be returned without any interest after
completion of tender process. In place of bid Security (EMD), the firms can submit a declaration
(as per Annexure VIII) that if they withdraw or modify their Bids during the period of validity,
or if they are awarded the contract and they fail to sign the contract or to submit a performance
security before the deadline defined in the request for bids documents, they will be suspended for
the period of 2 years from being eligible to submit bids for contract with this Ministry.
3. General conditions
• The firm should have minimum three years’ experience of work with the Government /
Public Sector undertaking or companies of reputes. Performance certificate from the
existing Govt. or other Clients must be attached.
• The firm should have Average Annual Turnover of at least Rs. 5 lakhs during the last 3
years (Documentary evidence should be enclosed).
• The firm must be registered under the relevant Act/Rule and it should possess registration
number from the Delhi, Sales Tax Department (Vat No.)/ Service Tax Department
(Photocopies must be attached).
• The earnest money of the successful tenderer shall be returned on submission of
performance security equal to 5% of the contract value for two years in the shape of
Fixed Deposit Receipt (FDR)/Bank Guarantee shall be provided by the firm. The
performance security should be furnished within one week of awarding the contract with
validity beyond 60 days of the expiry of the contract.
• Finally short listed vendor shall be required to enter into a written agreement with MoES
for honoring all tender conditions and adherence to all respects of fair trade practices for
works awarded by MoES.
• All disputes are subject to the jurisdiction of Delhi Courts. The decision of the tender
Committee shall be final in this regard.
Director (General Admn.)
MINISTRY OF EARTH SCIENCES
PRITHVI BHAWAN
New Delhi – 110003
Tel. No. 011- 24669510

<!-- page 12 -->

ANNEXURE- IV
Proforma of Technical Bid (To be filled up by the firm)
To be filled up by the firm
Name of the firm
Address of the firm
Whether the firm attached the EMD of
Rs.15,000/- through a Demand Draft
payable to DDO, Ministry of Earth
Sciences.

Yes/ No

If yes please state the number and date, No.
Amount and Name of the issuing Bank of Date
the Demand Draft
Amount
Issuing date
If No, Whether Declaration submitted
Yes/ No
Whether the firm has minimum three years’ Yes/ No
experience
of
working
with
the
Government/State Govt. Public sector
undertaking the works
Whether the firm has enclosed the Yes/ No
performance certificate from the existing
Clients with the Tender.
Whether the firm has an Average Annual Yes/ No
turnover of more than Rs. 5 lakhs per
annum during the last three years. Whether
the documentary evidence in this regard has
been attached with this Tender.
Whether the firm is registered under Yes/ No
relevant Act or Rules. Please give details.
Please provide the details about registration Registration No.
for TAN No., GST No., and PAN No.
TAN No.
PAN No.
GST No.
(please attach photocopy of the
documents)

Pg. No. of bid document

<!-- page 13 -->

ANNEXURE- V
Performa towards Performance Security
Ref. No. ------------------------------Bank Guarantee No--------------------------- Dated-----------Dear Sir,
1. In consideration of------------------------------ (hereinafter called the “Owner” which expression
shall unless repugnant to the subject or context include its successors and assigns) having entered
into a contract No………………………………………………………………………. Dated-------------------------------------------------------(hereinafter called `the Contract’ which expression
shall include all the amendments thereto) with M/s----------------------------------having its
registered/head office at----------------------------------------(hereinafter referred to as the
`Contractor’) which expression shall, unless repugnant to the context or meaning thereof include
all its successors, administrators, executors and assignees) and…………………having agreed
that the Contractor shall furnish to………………………………….a performance guarantee for
Indian Rupees …………………………….for the faithful performance of the entire contract.
2. We (name of the bank)…………………………………………..registered under the laws
of…………………..having head/registered office at……………………………….(hereinafter
referred to as “the Bank”, which expression shall, unless repugnant to the context or meaning
thereof, include all its successors, administrators, executors and permitted assignees) do hereby
guarantee and undertake to pay immediately on first demand in writing any/all moneys to the
extent
of
Indian
Rs.
(In
figures)
...........................{Indian
Rupees/words)…………………………………………….} (equivalent to one month’s charges quoted in
Annex.3) without any demur, reservation, contest or protest and/or without any reference to the
Contractor. Any such demand made by……………………….on the Bank by saving a written
notice shall be conclusive and binding, without any proof, on the bank as regards the amount due
and payable, notwithstanding any dispute (s) pending before any Court, Tribunal, Arbitrator or
any other authority and /or any other matter or thing whatsoever, as liability under these presents
being absolute and unequivocal. We agree that the guarantee herein contained shall be
Irrevocable and shall continue to be enforceable until it is discharged by…………………..in
writing. This guarantee shall not be determined, discharged or affected by the liquidation,
winding up, dissolution or insolvency of the Contractor and shall remain valid, binding and
operative against the bank.
3. The Bank also agrees that…………………at its option shall be entitled to enforce this
Guarantee against the Bank as a principal debtor, in the first instance, without proceeding against
the Contractor and notwithstanding any security or other guarantee that REC may have in
relation
to
the
Contractor’s
liabilities.
4.
The
Bank
further
agrees
that………………………….shall have the fullest liberty without our consent and without
affecting in any manner our obligations hereunder to vary any of the terms and conditions of the
said contract or to extend time of performance by the said Contractors(s) from time to time or to
postpone for any time or from time to time exercise of any of the powers vested in against the
said Contractor(s) and to forbear or enforce any of the terms and conditions relating to the said
agreement and we shall not be relieved from our liability by reason of any such variation, or
extension being granted to the said Contractor(s) or any such matter or thing whatsoever which
under the law relating to sureties would, but for this provision, have effect of so relieving us.

<!-- page 14 -->

5. The Bank further agrees that the Guarantee herein contained shall remain in full force during
the period that is taken for the performance of the contract and all dues of
…………………..under or by virtue of this contract have been fully paid and its claim satisfied
or discharged or till…………….discharges this guarantee in writing, whichever is earlier.
6. This Guarantee shall not be discharged by any change in our constitution, in the constitution of
……………………………or that of the Contractor.
7. The Bank confirms that this guarantee has been issued with observance of appropriate laws of
the country of issue.
8. The Bank also agrees that this guarantee shall be governed and construed in accordance with
Indian Laws and subject to the exclusive jurisdiction of Indian Courts of the place from where
the purchase order has been placed.
9. Notwithstanding anything contained hereinabove, our liability under this Guarantee is limited
to
Indian
Rs./)in
figures)………………………………..{Indian
Rupees/in
words)……………………………………} and our guarantee shall remain in force
until……………………………, 2019 and atleast 12 months after the date of issue of this
Performance Security. In case of any extension of the contract, the Performance Guarantee will
be suitably extended. Any claim under this Guarantee must be received by us before the expiry
of this Bank Guarantee. If no such claim has been received by us by the said date, the rights
of………………………under this Guarantee will cease. However, if such a claim has been
received by us within the said date, all the rights of……………………………………under this
Guarantee shall be valid and shall not cease until we have satisfied that claim. In witness
whereof, the Bank through its authorized officer has set its hand and stamp on
this…………….day of 20 at…………………
Signature………………….
Full name and designation
Address (in legible letters)
With Bank stamp
Attorney as per Power of Attorney No……………………. Dated………………………………..
WITNESS NO. 1
Signature………………..
Full name and designation
Address (in legible letters)
WITNESS NO.2
Signature…………………….
Full name and designation
Address (in legible letters)

<!-- page 15 -->

ANNEXURE- VI

Declaration Letter on Official Letter head stating the following:
i)
ii)
iii)

We are not involved in any major litigation that may have an impact of affecting or
compromising the delivery of Services as required under this tender.
ii) We are not black-listed by any Central/State Government/ Public Sector
Undertaking in India.

(Signature of the Authorized Person)
With Name, Date & Designation and
Seal

<!-- page 16 -->

ANNEXURE - VII
Bid Securing Declaration Format

To,
The Director, Ministry of Earth Sciences
Prithvi Bhawan, Lodhi Road
New Delhi - 110003
Subject:
Bid
Securing
No.……………………………

Declaration

Format

towards

Tender

Enquiry

Dear Sir,
On behalf of …………………………………………………….., we hereby submit a bid
securing declaration accepting that if we withdraw or modify our Bids during the period of
validity, or if we are awarded the contract and we fail to sign the contract, or to submit a
performance security before the deadline defined in the bid document, we can be suspended for a
period of two years from being eligible to submit Bids for contracts with this Ministry.

For M/s ____________________
Signature
Company seal
Name: _____________________
Designation__________________
Date:______________________
