---
doc_id: "04618b3eeadbc9fa"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/ba5e9c32d2e5b23010481f9a3d6e4ad3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Gazette Notification of Telecom eServices portal under Section 3(1) and 3(6) rules"
date: "2026-06-24"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "9347eff4dbf2811d"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-23062026-273768
xxxGIDHxxx
CG-DL-E-23062026-273768
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3237]
No. 3237]

नई ददल्ली, मंगलिार, िून 23, 2026/आषाढ 2, 1948
NEW DELHI, TUESDAY, JUNE 23, 2026/ASHADHA 2, 1948

संचार मंत्रालय
(दूरसंचार जिभाग)
अजधसूचना
नई ददल्ली, 23 िून, 2026
का.आ. 3370(अ).— दूरसंचार (प्रमुख दूरसंचार सेिाओं के उपबंध के जलए प्राजधकार) जनयम, 2026 के जनयम 82,
दूरसंचार (जिजिध दूरसंचार सेिाओं के उपबंध के जलए प्राजधकार) जनयम, 2026 के जनयम 78, दूरसंचार (कै जटिि दूरसंचार
सेिाओं के जलए प्राजधकार) जनयम, 2026 के जनयम 62 और दूरसंचार (प्रव्रिन के जलए जनबंधन और ितें) जनयम, 2026 के
जनयम 9 के साथ पठित दूरसंचार अजधजनयम, 2023 (2023 का 44) की धारा 53 के अनुसरण में, कें द्रीय सरकार एतद्वारा
अजधजनयम के जडजििल कायाान्ियन को सक्षम बनाने के जलए दूरसंचार जिभाग के ‘दूरसंचार ईसेिा पोिाल’ को पोिाल के तौर
पर अजधसूजचत करती है।
[फा. सं. 24-020/2026-यूबीबी]

देिेन्द्र कु मार राय, संयक्ु त सजचि

4659 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF COMMUNICATIONS
(Department of Telecommunications)

NOTIFICATION
New Delhi, the 23rd June, 2026
S.O. 3370(E).— In pursuance of the provisions of section 53 of the Telecommunications Act, 2023 (44 of
2023) read with rule 82 of the Telecommunications (Authorisation for Provision of Principal Telecommunication
Services) Rules, 2026, rule 78 of the Telecommunications (Authorisation for Provision of Miscellaneous
Telecommunication Services) Rules, 2026, rule 62 of the Telecommunications (Authorisation for Captive
Telecommunication Services) Rules, 2026 and rule 9 of the Telecommunications (Terms and Conditions for
Migration) Rules, 2026, the Central Government hereby notifies the "Telecom eServices Portal" to enable the digital
implementation of the provisions of the said Act.

[F. No. 24-020/2026-UBB]
DEVENDRA KUMAR RAI, Jt. Secy.

\

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
SARVESH KUMAR
and Published by the Controller of Publications, Delhi-110054. SRIVASTAVA
Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2026.06.23 23:07:40 +05'30'
