---
doc_id: "01dc62defce4f0bf"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/23960b9f8c9e50e8be0d168f0977d695.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS Comm No. 411 of 2025 in Honble High Court of Delhi: DoT instructions dated 12.05.2025 to ISPs"
date: "2025-05-12"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d2e06e9b549df456"
---

<!-- page 1 -->

813-7/25/2024-DS-II

I/3276093/2025

By Email/DoT Website

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)

No. 813-7/25/2024-DS-II

Dated: 12-05-2025

To,
All Licensees with Internet Service Authorization

S u b j e c t : CS(COMM) 411 of 2025: EICHER MOTORS LIMITED versus
HTTP//ROYALENFIELDDEALERINDIA.IN/ & ORS. in the High Court of Delhi.

Please ﬁnd enclosed the Hon’ble
dated 06.05.2025 in the captioned suit.

High

Court

of

Delhi

order

2. Please refer to Para 37(c) of the said Court order in respect of blocking
access to the impugned domains [14 nos], enumerated in the
Schedule attached with the said Court order.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said domains, as above, in compliance with the said court order.
Encl: A/A

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i.) Sh. V. Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY), New Delhi for
kind information and with a request to take action as per the enclosed Annexure pl.
ii.) Mr. Krisna Gambhir (Krisna.Gambhir@remfry.com), Plaintiﬀ's Counsel for kind
information and with a request to take action as per the enclosed Annexure pl.

<!-- page 2 -->

$~31
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 411/2025, I.A. 11295/2025-Stay
EICHER MOTORS LIMITED
.....Plaintiff
Through: Mr. Peeyoosh Kalra, Mr. C. A.
Brijesh and Mr. Krishna Gambhir,
Advs.
versus
HTTP//ROYALENFIELDDEALERINDIA.IN/ & ORS.
.....Defendants
Through: None.

%

CORAM:
HON'BLE MR. JUSTICE SAURABH BANERJEE
ORDER
06.05.2025

I.A. 11301/2025-Extension of time for filing Court fees.
1.

Vide the present application under Section 149 read with Section

151 of the Code of Civil Procedure, 1908 (CPC), the plaintiff seeks
extension of time for filing the deficit Court fee.
2.

Learned counsel for the plaintiff submits that since the deficit Court

fee has since been filed, the present application has become infructuous.
3.

Accordingly, the present application is disposed of as infructuous.

I.A. 11298/2025-Exp from pre-institution mediation.
4.

Vide the present application under Section 12A of the Commercial

Courts Act, 2015, read with Section 151 of the CPC, the plaintiff seeks
exemption from pre-litigation mediation.
5.

Considering the averments made in the present application, as also

since the plaintiff is seeking ex-parte ad-interim injunction in an
accompanying application, and in view of the judgment passed by the
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 1 of 11

<!-- page 3 -->

Hon’ble Supreme Court in Yamini Manohar v. T.K.D. Krithi 2024 (5)
SCC 815, which has been followed by a Division Bench this Court in
Chandra Kishore Chaurasia v. R. A. Perfumery Works Private Limited
2022:DHC:4454-DB, the plaintiff is exempted from instituting prelitigation mediation.
6.

Accordingly, the present application stands disposed of.

I.A. 11297/2025-Exp
7.

Exemption allowed, subject to all just exceptions.

8.

The application stands disposed of.

I.A. 11300/2025-Exp from effecting advance notice on D-23 and 24
9.

Vide the present application under Section 151 of the CPC, the

plaintiff seeks exemption from effecting advance service on defendant
nos.23 and 24 in view of the urgent reliefs sought.
10.

Learned counsel for the plaintiff submits that since as per its own

‘Affidavit of Service’ the plaintiff has already served the said defendants,
the present application has become infructuous and the same is not being
pressed.
11.

Accordingly, the present application is disposed of as not pressed.

I.A. 11296/2025-Exp from serving an advance copy to D-1 to 14 and
26
12.

Vide the present application under Section 151 of the CPC, the

plaintiff seeks exemption from advance service upon the defendant nos.1
to 14 and 26.
13.

Learned counsel for the plaintiff submits that the defendant nos.1 to

14 are likely to destroy all evidence of their engaging in the infringing
activities, if advance service is effected, and the apprehensions of the
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 2 of 11

<!-- page 4 -->

plaintiff will become a reality in case advance service is affected
therefore, an exemption from effecting advance service is necessary.
14.

For the reasons stated in the application, as also taking into account

the aforesaid factors and in the interest of justice, the plaintiff is granted
exemption from effecting advance service upon defendant nos.1 to 14 and
26.
15.

Accordingly, the present application is allowed and disposed of.

I.A. 11299/2025-Addl.doc.
16.

Vide the present application under Order XI Rule 1(4) read with

Section 151 of the CPC, the plaintiff seeks leave of this Court to file
additional documents.
17.

The plaintiff will be at liberty to file additional documents at a later

stage, albeit, after initiating appropriate steps, strictly as per the provisions
of the Commercial Courts Act, 2015 read with Section 151 of the CPC and
the Delhi High Court (Original Side) Rules, 2018.
18.

Accordingly, the present application stands disposed of.

CS(COMM) 411/2025
19.

Vide the present plaint, the plaintiff seeks grant of a permanent

injunction restraining the defendants from infringement of trademark/
domain name, passing off, unfair trade competition, rendition of accounts
and damages.
20.

Let the plaint be registered as a suit.

21.

Upon filing of the process fee, issue summons of the suit to the

defendants through all permissible modes returnable before the learned
Joint Registrar on 04.08.2025.
22.

The summons shall state that the written statement be filed by the
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 3 of 11

<!-- page 5 -->

defendants within a period of thirty days from the date of the receipt of the
summons. Written statement be filed by the defendants along with
affidavit of admission/ denial of documents of the plaintiff, without which
the written statement shall not be taken on record.
23.

Replication(s) thereto, if any, be filed by the plaintiff within a

period of fifteen days from the date of receipt of written statement. The
said replication(s), if any, shall be accompanied by with affidavit of
admission/ denial of documents filed by the defendants, without which the
replication(s) shall not be taken on record within the aforesaid period of
fifteen days.
24.

If any of the parties wish to seek inspection of any document(s), the

same shall be sought and given within the requisite timelines.
25.

List before the learned Joint Registrar for marking exhibits of

documents on 04.08.2025. It is made clear that if any party unjustifiably
denies any document(s), then it would be liable to be burdened with costs.
I.A. 11295/2025-Stay
26.

Vide the present application, the plaintiff seeks the following reliefs:
“a. Pass an order of temporary injunction restraining
Defendant Nos. 1 to 14 and 26 (such other websites/entities
which are discovered during the course of the proceedings
to be engaged in infringing the Plaintiff's trade mark Royal
Enfield) their owners, proprietors, employees, partners,
representatives and/or others acting for and on their behalf
from using the trade mark Royal Enfield or any deceptively
similar variant thereof, or in any manner amounting to
infringement;
b. Pass an order of temporary injunction restraining
Defendant Nos. 1 to 14 and 26 (and such other
websites/entities which are discovered during the course of
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 4 of 11

<!-- page 6 -->

the proceedings to be engaged in passing off the Plaintiff's
Royal Enfield trade marks), their owners, proprietor,
employees, partners, representatives and/or others acting
for and on their behalf from using the Royal Enfield
trademarks or any deceptively similar variant thereof, in
any manner thus amounting to passing off their services as
those of the Plaintiff;
c. Pass an order directing Defendant Nos. 15 to 22 to
block access and suspend the impugned domain names
www.royalenfielddealerindia.in; www.royalbikedealers.in;
www.royalonfield.com;
www.royalenfield.org;
www.royalenfieild.com;
www.royalenfield1.com;
www.royal-enfield.com;
www.royalenfiled.com;
www.royalenfeild.com;
www.royalsenfield.com;
www.royalinfield.com;
www.royaleenfield.com;
www.royalenfleid.com to the Plaintiff as also disclose the
contact particulars and KYC details of the registrants;
d. Pass an order directing Defendant No. 23 (DOT) and
Defendant No. 24 (MEITY) to issue a notification calling
upon the various internet and telecom service providers
registered under it to block access to the various impostor
domain names identified by the Plaintiff and such other
domain names that may subsequently be notified by the
Plaintiff to be infringing of its exclusive rights;
e. Pass an order directing Defendant No. 25 (NIXI) not
to permit any domain name to be opened under the ‘co.in’
and ‘in’ extensions consisting of the mark ‘ROYAL
ENFIELD’, where the words ‘ROYAL’ and ‘ENFIELD’
appear together other than that of the Plaintiff;
f.
Grant orders in terms of prayer (a), (b), (c), (d) and (e)
hereinabove ex-parte.”
27.

As per pleadings, the plaintiff is a public limited company

organized under Indian laws and is manufacturing and selling motorcycles
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 5 of 11

<!-- page 7 -->

and other accessories extensively over India, as also exporting to over
sixty countries, under the trademark ROYAL ENFIELD and its variants
since the year 1955 continuously and uninterruptedly.
28.

The plaintiff has obtained registrations for the said ROYAL

ENFIELD trademark and its variants under various Classes of the TM
Act as enumerated in paragraph no.15 of the present application. Further,
the ROYAL ENFIELD trademark has been declared a “well-known”
trademark in the motorcycle industry by the High Court of Madras vide
the order dated 22.11.2023 in C.S. (Comm.Div.) No.77/2023 entitled
Eicher Motors Ltd. v. Nitin Service Point & Automobiles and published
in the Trade Marks Journal No.2146 dated 04.03.2024.
29.

The plaintiff has made significant investments in promotional

activities and generated substantial revenue from its ROYAL ENFIELD
trademarks. The plaintiff has consequently acquired tremendous goodwill
and reputation, and its motorcycles are known for their quality, reliability
and toughness.
30.

The plaintiff also promotes and advertises its products and services

through its website www.royalenfield.com, which was registered on
19.10.1997. The plaintiff has presence on social media platforms as well.
31.

In the second week of April, 2025, the plaintiff, upon conducting

internet enquiries discovered certain domain names on the internet, being
defendant nos.1 to 14 herein, incorporating the plaintiff’s trademark,
thereby infringing the same (impugned domain names), the complete
details whereof have been masked and are not available with the plaintiff.
Defendant nos.15 to 22 are domain name registrars (DNRs) for the
impugned domain names. Defendant nos.23 to 25 are the Department of
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 6 of 11

<!-- page 8 -->

Telecommunications (DoT), the Ministry of Electronics and Information
Technology (MIETY) and the National Internet Exchange of India (NIXI)
respectively who have been impleaded for compliance. Finally, defendant
no.26 is the John Doe defendant for those unknown individuals/ entities
who are found to violate the plaintiff’s trademark rights in future and are
currently unknown. A comprehensive list of the impugned domain names
against their respective DNRs is produced in paragraph no.24 of the
present application and is also annexed with this order as Schedule-I for
ease of reference.
32.

Based thereon, learned counsel for the plaintiff submits that the

adoption of the plaintiff’s long standing and well-known trademarks in the
form of the impugned domain names is in complete bad faith, and is
aimed at taking advantage of the goodwill and reputation of the plaintiff
which is likely to cause confusion and monetary loss to the public at large.
Further, that the said dishonest and fraudulent practices taking place using
the impugned domain names and are causing irreparable harm to the
plaintiff’s intellectual property rights, and the balance of convenience is in
favour of grant of temporary injunction restraining the said impugned
domain names from continuing their infringing activities.
33.

This Court has heard learned counsel for the plaintiff as also gone

through the pleadings and documents on record.
34.

On a bare perusal of the factual matrix involved, this Court is of the

prima facie view that the defendants herein are engaging in carrying out
fraudulent activities to defeat the legitimate intellectual property rights of
the plaintiff by seeking refuge behind closed doors vis-à-vis masked
domain names, making it virtually impossible to get to the real infringers
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 7 of 11

<!-- page 9 -->

behind the infringing activities, which are unfortunately on the rise in
today’s digital age.
35.

Going through the impugned domain names leaves no doubt that the

defendants and their activities are aimed at coming as close as possible to
the plaintiff’s ROYAL ENFIELD trademarks so that a common layperson
can mistake them for the legitimate websites of the plaintiff. The said
websites are also offering motorcycles for sale and are clearly attempting
to pass off their products for those of the plaintiff, which have been
existing in the market for a significant amount of time and have gained
some repute. This not only amounts to infringement and passing off but is
also detrimental to public interest, given the high degree of likelihood of
confusion.
36.

In the aforesaid backdrop, keeping in mind the pronouncements

made by this Court in UTV Software Communication Ltd. & Ors. v.
1337X.to

&

Ors.

[2019:DHC:2047],

Star

India

(P)

Ltd.

v.

https//crichdplayer.org/ [2025 SCC OnLine Del 1968] and order dated
20.11.2023 in CS(COMM) 832/2923 entitled Eicher Motors Limited v.
www.royalenfielddealerships.in & Ors. wherein it has been held that in
issues like the present one, it is of utmost importance that the plaintiff of
the present kind is to be granted protection against the third party
infringers like the defendants herein. Therefore, this Court is of the view
that the impugned domain names fall within the category of rogue
websites, and the balance of convenience tilts in the favour of grant of a
dynamic injunction against the registrants of the impugned domain names,
as well as other infringing domain names that may be discovered in future.
37.

Accordingly, till the next date of hearing:
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 8 of 11

<!-- page 10 -->

a.

Any person including the registrants of the defendant nos.1 to

14, their owners, proprietors, employees, partners, representatives
and/ or others acting for and on their behalf are hereby restrained
from using the trademark ROYAL ENFIELD or any other
deceptively similar variant thereof amounting to infringement and/
or passing off;
b.

Defendant nos.15, defendant no.16, defendant no.17,

defendant no.18, defendant no.19, defendant no.20, defendant no.21
and defendant no.22 are directed to block access to and suspend the
impugned domain names registered by defendant nos.1 to 7,
defendant no.8, defendant no.9, defendant no.10, defendant no.11,
defendant no.12, defendant no.13 and defendant no.14 respectively,
as also to disclose their respective names, contact details and
addresses;
c.

DoT and MEITY are directed to call upon the various internet

and telecom service providers registered under them to block access
to the impugned domain names and other such domain names that
may be subsequently notified by the plaintiff to be infringing its
exclusive rights, as also NIXI is directed not to permit any domain
name to be opened which are consisting of the trademark ROYAL
ENFIELD and its variants;
d.

The plaintiff is given liberty to implead any other websites

and their registrants which may be discovered in the course of the
proceedings to be infringing upon its ROYAL ENFIELD trademark
and its variants.
38.

Upon filing of process fee, issue notice to the defendants through all
CS(COMM) 411/2025

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

Page 9 of 11

<!-- page 11 -->

permissible modes, including through email, returnable before the Court
on 01.09.2025.
39.

Reply be filed within four weeks. Rejoinder thereto, if any, be filed

within two weeks thereafter.
40.

The provisions of Order XXXIX Rule 3 of the CPC be complied

with within one week.
41.

List before Court on 01.09.2025.

SAURABH BANERJEE, J.
MAY 6, 2025/R

CS(COMM) 411/2025

Page 10 of 11

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

<!-- page 12 -->

Schedule
Impugned Domain Name
www.royalenfielddealerindia.in
Defendant No. 1
www.royalbikedealers.in
Defendant No. 2
royalonfield.com
Defendant No. 3
royalenfield.org
Defendant No. 4
royalenfieild.com
Defendant No. 5
royalenfieldl.com
Defendant No. 6
royal-enfield.com
Defendant No. 7
royalenfiled.com
Defendant No. 8
royalenfeild.com
Defendant No. 9
royalsenfield.com
Defendant No. 10
royalinfield.com
Defendant No. 11
royaleenfield.com
Defendant No. 12
royalenfleid.com
Defendant No. 13
royalenfild.com
Defendant No. 14

CS(COMM) 411/2025

Domain Name Registrar
GoDaddy.com, LLC
Defendant No. 15
GoDaddy.com, LLC
Defendant No. 15
GoDaddy.com, LLC
Defendant No. 15
GoDaddy.com, LLC
Defendant No. 15
GoDaddy.com, LLC
Defendant No. 15
GoDaddy.com, LLC
Defendant No. 15
GoDaddy.com, LLC
Defendant No. 15
PDR Ltd. d/b/a
PublicDomainRegistry.com
Defendant No. 16
Above.com Pty Ltd.
Defendant No. 17
Domainshype.com, LLC
Defendant No. 18
Moniker Online Services LLC
Defendant No. 19
Hostinger operations, UAB
Defendant No. 20
NameCheap, Inc.
Defendant No. 21
DropCatch.com
Defendant No. 22

Page 11 of 11

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/05/2025 at 20:06:47

<!-- page 13 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
