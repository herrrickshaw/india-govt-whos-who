---
doc_id: "01aac77e5c18fdef"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/7c029dc5474348ec1275eac5088f98d6.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Corrigendum for Draft Notification regarding changes in rule 11 of COTPA Amendment Rules, 2023-OTT Rules"
date: "2024-10-09"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b87f182e45d2daf"
---

<!-- page 1 -->

[To be published in Part- II Section ] -Sub Section (i) olthe Extrxordinary Gazette oflndial
F. No. P 16012,'08/2017-TC

l\linistr1 oiHealth & Famill Vrtlare
(Depanment olHealth and Family \['ellare)

CORRICE\DL}T
New Delhi. the 23d September. 2024

In the Notificatio[ of the Covemment of Indi4 Ministry of Health
G.S. R-(E).and Family Welfare
, No. G.S.R. 572(E) dated the lith September, 2024, [Cigarctes and
other Tobacco Products (Prohibition of Advertisement and Regulation of Trade and
Commerce, Productioq Supply and Distdbution) draft Amendment Rules' 20241, published
in Part II, Section 3, Sub-section(i) ofthe Gazette of India. Extraordinaryi

For the words "Cigarette and other Tobacco Producs (Prohibition of Advenisement
ard Regulatiod of Trade and Conunerce, Production, Supply and Distribution) Rules, 2024",
wherever they lppear' ercept in Rule l, sub-rule(l) shall be substituted rs, :"Cigarene and other Tobacco Products (Pmhibition of Advertisemeot and Regulation
ofTrade and Cornmerce, Production, Supply and Distdbution) Rules' 2004".

t-, t/

lgt.L1,'
(LATg{

CANAPATHY)
Joint S€cretary to the Govemment of lndia
