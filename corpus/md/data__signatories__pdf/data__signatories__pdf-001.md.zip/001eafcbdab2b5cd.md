---
doc_id: "001eafcbdab2b5cd"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/fb231975646d0c723a89765efce33eeb.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment for High Court of Rajasthan: Order dated 13.12.2016"
date: "2017-08-03"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e580b67e7e1af249"
---

<!-- page 1 -->

F.No. .1.-11017/23/2016-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
Judicial Section
Shastri Bhawan, New Delhi,
Dated 13th December, 2016

ORDER
The President is pleased to engage Shri Anshul Jakhar, Advocate as
Central Government Counsel for conducting Central Government litigation
(except for Railways & Income Tax Department) before Rajasthan High Court,
Jaipur Bench as mentioned below, for a period of three years from the date of
this order or until further orders, whichever is earlier.
Rajasthan High Court, Jaipur Bench
Central Government Counsel
Name

Address & contact

ANSHUL JAKHAR

Plot No. 176, Ram Nagar,
Sirsi Road, Hanuman Nagar
Extension, Jaipur-302012.
Mob: Not provided.

Enrollment
No.
R/353/2009

Email: anshul.jakhar@gmail.com
2.

The engagement and professional fee of the aforesaid advocate will be
governed by the terms and conditions contained in this Department's OM No.
26(1)/1999-Judl. dated 24.09.1999 read with OM No. 26(1)/2014/Judl. dated
01.10.2015 & instructions issued subsequently through OMs. The aforesaid OMs
are available on the official website of this Ministry i. e. www.lawmin.nic.in under
Department of Legal Affairs in the link 'Circulars pertaining to litigations'.
3.

Hindi version of this order will follow.

PV164/1
(R'. K. Srivastava)
Deputy Legal Advisor
Page 1 of 2

<!-- page 2 -->

Dated 13th December, 2016

F.No. J-11017/23/2016-Judicial
Copy to:-

1. PS to ML&J/PS to MSLJ/PS to Law Secretary/PS to Legislative
Secretary/All Additional Secretaries/PS to all JS&LA in the Main Sectt.
2. Shri Rajdeepak Rastogi, Additional Solicitors General of India, Rajasthan
High Court at Jaipur, B-346, 10-B Scheme, Opp. Narayan Niwas, Gopalpura
Road, Jaipur-302018, Rajasthan.
3. Shri Anil Kumar Rajvansy, Assistant Solicitor General of India, Rajasthan
High Court at Jodhpur, House No. Z/6, B-2, Roaad, Patota, Jodhpur342006.
4. The Registrar, Rajasthan High Court, Jaipur Bench at Jaipur, Rajasthan.
5. Shri Anshul Jakhar, as above.
6. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
7. NIC cell, Department of Legal Affairs with the request to upload this order
on the website of this Department.
8. Guard File/Judicial Section with 5 spare copies.

(D. Srinivas)
Section Officer (Judicial Section)

Page 2 of 2
