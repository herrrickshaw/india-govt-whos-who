---
doc_id: "78fcfeafce5536e7"
source_url: "https://mines.gov.in/admin/download/6618d2d4a38271712902868.pdf"
ministry: "Mines (MoM)"
title: "Revised PMKKKY guidelines. (3.11 MB)"
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "71bc65542d832d1f"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

1|Page

<!-- page 4 -->

2|Page

<!-- page 5 -->

INDEX
Introduction

1

Identification of affected areas and people to be
covered under the PMKKKY

2

General guidelines

3

Utilisation of Funds

4

Composition and Functions of DMF

5

Five years perspective planning and yearly plan

6

Restriction on fund transfer from DMF

7

Special provisions for scheduled areas

8

Transparency and Accountability

9

Audit

10

Annual Report

11

State Level Monitoring Committee

12

Grievance Redressal

13

Compliance mechanism

Page | 3

<!-- page 6 -->

Pradhan Mantri Khanij Kshetra Kalyan Yojana (PMKKKY)
Introduction
In 2015, Mines & Minerals (Development & Regulation) Act, 1957 was amended interalia introducing a new section 9B which provides for establishment of District
Mineral Foundation (DMF) in all districts affected by mining operations. The object
of DMF is to work for the interest and benefit of persons, and areas affected by mining
related operations in such manner as may be prescribed by the State Government.
DMFs are funded by statutory contributions from mining lease holders.
In September 2015, the Central Government framed the Pradhan Mantri Khanij
Kshetra Kalyan Yojana (PMKKKY) to be implemented by DMFs and in exercise of
the powers conferred under Section 20A of the MMDR Act, 1957, in the national
interest directed the State Governments concerned to incorporate the PMKKKY into
the rules framed by them for the DMF and to implement the said scheme.
The Pradhan Mantri Khanij Kshetra Kalyan Yojana (PMKKKY) is being
implemented by the District Mineral Foundations (DMFs) of the respective districts
using the funds accruing to the DMF. The overall objective of PMKKKY scheme are
(a) to implement various developmental and welfare projects/programs in mining
affected areas, and these projects/programs will be complementing the existing
ongoing schemes/projects of State and Central Government; (b) to
minimize/mitigate the adverse impacts, during and after mining, on the
environment, health and socio-economics of people in mining districts; and (c) to
ensure long-term sustainable livelihoods for the affected people in mining areas.
The MMDR Amendment Act, 2021 empowers the Central Government to give
directions regarding composition and utilization of funds by DMFs. The Central
Government issued the following directions to the State Governments with respect
to composition and functions of DMF:
a) Order dated 23.04.2021 to include MPs, MLAs and MLCs in the Governing

Council in the larger public interest.
b) Order dated 12.07.2021 to ensure that no funds shall be transferred in any

manner from the District Mineral Foundations to the State exchequer or State
level fund or Chief Minister's Relief Fund or any other funds or schemes and
no sanction or approval of any expenditure out of the fund of the District
Mineral Foundation shall be done at the State level.
c) Order dated 24.06.2022 for the preparation of a five-year Perspective Plan for

Page | 4

<!-- page 7 -->

implementation of works using DMF funds to ensure systemic development
of the mining-affected area and people.
A committee was constituted in June 2022 to revisit/amend the PMKKKY guidelines
for effective utilization of DMF funds. After detailed consultation with State
Governments, Central Government Ministries, NGOs and other stakeholders, the
following revised PMKKKY guidelines are issued under section 9B (3) of MMDR Act
1957.

1. Identification of affected areas and people to be covered under the
PMKKKY
1.1 Affected areas
a. Directly affected areas – Villages and gram panchayats or Urban Local Bodies
(ULBs) within which the mines (other than minor minerals) are situated and
are operational. Such mining areas may extend to neighboring village/town,
block or district or even State.
i.
An area within such radius from a mine or cluster of mines as may be
specified by the State Government.
ii.
Villages/wards in which families displaced by mines have been
resettled/rehabilitated by the project authorities.
iii.
Villages/wards that significantly depend on the mining areas for meeting
their economic needs and have usufruct and traditional rights over the
project areas, for instance, for grazing, collection of minor forest produce
etc. should be considered as directly affected areas.
Provided that directly affected area is an area within such radius from a mine
or cluster of mines as may be specified by the State Government but shall not
extend beyond 15 km from the boundary of the mines of mineral other than
minor minerals.
b. Indirectly affected areas – Those areas where local population is adversely
affected on account of economic, social and environmental consequences due
to mining-related operations of minerals other than minor minerals. The major
negative impacts of mining could be by way of deterioration of water, soil and
air quality, reduction in stream flows and depletion of ground water,
congestion and pollution due to mining operations, transportation of
minerals, increased burden on existing infrastructure and resources.
Indirectly affected area is an area beyond the directly affected area and within
such radius from a mine or cluster of mines as may be specified by the State

Page | 5

<!-- page 8 -->

Government but not more than 25 km from boundary of mines of mineral
other than minor minerals, irrespective of whether this falls within the
district concerned or adjacent district.
c. The DMF shall prepare and maintain an updated list of such directly and
indirectly affected areas.
1.2 Affected people
a. The following shall include directly affected persons:
i.

ii.

iii.

‘Affected family’ as defined under Section 3 (c) of the Right to Fair
Compensation and Transparency in Land Acquisition, Rehabilitation and
Resettlement Act, 2013
‘Displaced family’ as defined under Section 3 (k) of the Right to Fair
Compensation and Transparency in Land Acquisition, Rehabilitation and
Resettlement Act, 2013
Any other as appropriately identified by the concerned gram sabha/ ULB
in directly or indirectly affected area.

b. Persons affected by mining should include people who have legal and
occupational rights over the land being mined, those with usufruct and
traditional rights, and those whose livelihoods have been affected due to
mining.
c. Affected families should be identified, as far as possible, in consultation with
local/elected representatives of gram sabha/Urban Local Body (ULB) in
directly or indirectly affected area.
d. The DMF shall prepare and maintain an updated list of such affected
persons/local communities. The list shall be revisited for updation at least
once every 5 years.

2. General guidelines
a. Convergence of schemes – The developmental and welfare activities to be
taken up under the PMKKKY should be, as far as possible, in the nature of
complementing the ongoing schemes/projects being funded by the State as
well as Central Government. Activities meant to be taken up under the
‘polluter pays principle’ should not be taken up under the PMKKKY.
However, without prejudice to the powers of the Foundation, efforts shall be
made to achieve convergence with the State and the District Plans so that the

Page | 6

<!-- page 9 -->

activities taken up by the Foundation supplement the development and
welfare activities and are treated as extra-budgetary resources for the State
Plan. The DMFs shall focus on convergence with ongoing central and state
schemes for achieving the Sustainable Development Goals (SDGs) in mining
affected areas. While formulating schemes, DMFs will give priority to
achieving targets under Aspirational Districts Programme and Aspirational
Blocks Programme.
b. Project Management Unit – An amount not exceeding 5% of the annual
receipts of the Foundation may be utilised for administrative, supervisory and
overhead costs of the Foundation. As far as possible, no
temporary/permanent posts should be created under the District Mineral
Foundation. Any creation of temporary/permanent posts and purchase of
vehicle by the foundation shall require prior approval of the State
Government. However, minimum required staff can be engaged on
contractual basis. In order to enhance the capacity of the DMFs and for
effective utilization of DMF funds, the DMF with annual collection in the
excess of Rs. 50 crores shall set up a Project Management Unit for planning,
technical, accounting and monitoring support and the cost of such PMU may
be met from administrative expenses. The PMU may engage required
qualified manpower on contractual basis. Engagement of personnel for
projects under the PMKKKY shall be purely contractual for a limited period
only.
c. Endowment fund – A reasonable sum not exceeding 10% of the annual
receipts should be kept as endowment fund for providing sustainable
livelihood. The districts having annual collection of Rs. 10 crore or more shall
maintain an endowment fund. The endowment fund may be invested in
government securities/bonds and FDs of scheduled banks and other
instruments as are permitted by the State Government. The endowment fund
should be used for creating & sustaining livelihoods in areas where mining
activity has stopped due to any reason including exhaustion of mineral.
d. Affected area in more than one district – If the affected area of a mine in one
district also falls in the jurisdiction of another district (even if it is in another
State), such percentage of amount collected from the mine by the Foundation,
in proportion of affected areas, shall be transferred to the Foundation of the
other district concerned for taking up the activities in such areas. A project that
is for benefit of the affected area/ people, but stretches beyond the
geographical boundary of the district should be taken up under the PMKKKY
after obtaining prior approval of the State Government.

Page | 7

<!-- page 10 -->

e. Implementation of Works / Contracts
i.

Works /goods may be procured by the DMF after following due procedure
prescribed by the respective State Governments for such procurements.
Procurement through GeM portal should be preferred.

ii.

Transfer of fund to all executing agencies and beneficiaries shall be
through Direct Benefit Transfer (DBT) only into their bank account.

3. Utilisation of Funds
3.1 Scope of PMKKKY
The PMKKKY may cover the activities listed below:
3.1.1 High priority Sectors – at least 70% of PMKKKY funds to be utilized under
these sectors:
a. Drinking water supply – centralized purification systems, water treatment
plants, permanent/temporary water distribution network including
standalone facilities for drinking water, laying of piped water supply system.
b. Environment preservation and pollution control measures – effluent
treatment plants, prevention of pollution of streams, lakes, ponds, ground
water, other water sources in the region, measure for controlling air and dust
pollution caused by mining operations and dumps, mine drainage system,
mine pollution prevention technologies, and measures for working or
abandoned mines and other air, water & surface pollution control mechanisms
required for environment-friendly and sustainable mine development.
Identification of mineral-specific pollutants and their hazard potential may be
done by involving reputed educational institutes/ research institutions. The
fund may be allocated for the identification of the hazards, setting up air
quality monitors and displays, and undertaking measures for the
implementation of the recommendations of the research.
c. Health care – the focus must be on people whose health is affected due to
mining, creation of primary / secondary health care facilities in the affected
areas. The emphasis should not be only on the creation of the health care
infrastructure,
but
also
on
provision
of
necessary
staffing
(doctors/paramedical/support staff), equipment and supplies required for
making such facilities effective. To that extent, the effort should be to
supplement and work in convergence with the existing health care

Page | 8

<!-- page 11 -->

infrastructure of the local bodies, State and Central government. The expertise
available with the National Institute of Miners’ Health may also be drawn
upon to design special infrastructure needed to take care of mining related
illnesses and diseases, mobile health care units in the mining affected areas.
Group Insurance Scheme for health care may be implemented for mining
affected persons.
d. Education – construction of school/college/vocational training institute
buildings, additional class rooms, laboratories, libraries, art and crafts rooms,
toilet blocks, drinking water provisions, residential schools, residential hostels
for students of affected areas and teachers in remote areas, sports
infrastructure, engagement of teachers/other supporting staff, e-learning
setup, other arrangement of transport facilities (bus/van/cycles/rickshaws
etc.) and nutrition related programs. Financial support to students of affected
areas for pursuing education in government/government aided institutions
of higher education.
e. Welfare of Women and Children – Special programmes for addressing
problems of maternal and child health, malnutrition, infectious diseases, etc.
can be taken up under the PMKKKY.
f. Welfare of aged and differently abled – Special program and medical support
for welfare of aged and differently abled people and financial assistance to
District Disability Rehabilitation Centres (DDRCs).
g. Skill development and Livelihood generation – skill development for
livelihood support, income generation and economic activities for local
eligible persons. The projects / schemes may include training, training kits,
development of skill development center, incubation center, self-employment
schemes, support to Self Help Groups and provision of forward and backward
linkages for such self-employment economic activities, works to improve and
showcase the arts & crafts of the affected people and areas, collection and
processing of minor forest produce.
h. Sanitation – collection, transportation and disposal of waste, cleaning of
public places, provision of proper drainage and Sewage Treatment Plant,
provision for disposal of fecal sludge, provision of toilets and other related
activities.
i. Housing – Provision of pucca housing for mining affected people not covered
under Central or State schemes.

Page | 9

<!-- page 12 -->

j.

Agriculture: Activities related to agriculture, horticulture and agroforestry.
Assistance to farmers through trainings, support to FPOs/
collectives/cooperatives, support for setting up of food processing units,
storage including cold storage, marketing facilities like market yards etc.,
plantation, processing of medicinal herbs.

k. Animal Husbandry: Promotion of livestock, poultry, piggery, fishery, feed
and fodder development and supporting innovation in animal husbandry,
Farmers Producer Organizations (FPOs), Self Help Groups (SHGs), Farmer
Cooperative Organisations (FCOs).
3.1.2 Other priority Sectors – Up to 30% of the PMKKKY funds to be utilized
under these sectors
a. Physical infrastructure – providing required physical infrastructure - roads,
bridges, railways and waterways projects.
b. Irrigation – developing alternate sources of irrigation including check dams
and diversion weirs, adoption of suitable and advanced irrigation techniques,
assistance for micro irrigation facilities including drip irrigation, assistance for
bore wells and pump energization.
c. Energy and Watershed Development – Development of alternate sources of
energy (including micro-hydel, decentralized solar or other renewable
sources) and rainwater harvesting system. Development of orchards,
integrated farming and agroforestry and restoration of catchments.
d. Any other measures for enhancing environmental quality in the mining
affected district.
3.2 Distribution of funds in directly and indirectly affected areas
a. A minimum of 70% of the DMF funds shall be spent only in the directly
affected area as specified in 1. (1.1) (a).

4. Composition and Functions of DMF
The composition and functions of the District Mineral Foundation shall be as may be
prescribed by the State Government in the State DMF rules. The State Government
and Union territories shall incorporate the following in the rules –
i.

The Chairman of Governing Council and Managing Committee shall be the

Page | 10

<!-- page 13 -->

ii.

iii.

iv.

v.

vi.

vii.

viii.

ix.

District Magistrate/ Deputy Commissioner/ Collector of the district. No other
person shall function as Chairman of the Governing Council and/ or
Managing Committee.
In case of one Member of Parliament (MP) in a district, MP, Lok Sabha of the
district shall be a member of the Governing Council. In case, there is more than
one MP of Lok Sabha in a district, all MPs having mining affected areas as part
of their constituency shall be members of the Governing Council.
In case, the constituency of one MP of Lok Sabha falls in more than one
districts, the MP of Lok Sabha shall be member of the Governing Council of
all such districts where mining affected area is a part of his/her constituency.
MP of Rajya Sabha from a State shall be a member of the Governing Council
of one district selected by him/her. (The Rajya Sabha MP shall intimate name
of the district selected by him/her to the Secretary in-charge of Mining
Department of the State who in turn shall inform the District Magistrate/
Deputy Commissioner/ Collector concerned).
The Members of Legislative Assembly (MLAs) of the district having mining
affected area as part of their constituency shall be members of the Governing
Council. In case, the constituency of one MLA falls in more than one districts,
the MLA shall be member of the Governing Council of all such districts where
mining affected area is a part of his/her constituency.
The Members of Legislative Council of the State (MLC) shall be a member of
the Governing Council of one district selected by him/her. (The MLC shall
intimate name of the district selected by him/her to the Secretary in-charge of
Mining Department of the State who in turn shall inform the concerned
District Magistrate/ Deputy Commissioner/ Collector).
The Governing Council shall meet at least twice in a year. The date of meeting
of the Governing Council shall be fixed as per the convenience of the Member
of Parliament who are members of the Governing Council.
The Managing Committee of the DMF shall comprise the District Magistrate/
Deputy Commissioner/ Collector as Chairman and senior officers of the
district responsible for execution of projects as members. The managing
committee shall not have any elected representative or nominated non official
members.
The Managing Committee shall meet at least once every quarter.

5. Five years perspective planning and yearly plan
For complete coverage of all affected people and areas in a systematic and timebound manner, long-term planning is essential. For proper utilization of funds for
the implementation of works using District Mineral Foundation (DMF) funds:

Page | 11

<!-- page 14 -->

i.

ii.

iii.

iv.
v.

vi.

vii.

The Districts shall conduct a baseline survey through Academic Institutions/
Renowned organisations/ agencies for perspective plan formulation. Gram
Sabha/Local Bodies may aid in preparation of need assessment reports. The
DMF may also use the baseline survey undertaken by any Department, if
available. The reference and major findings of the surveys should be included
in the Perspective Plans under PMKKKY for the District.
Based on the findings and gaps as identified through the baseline survey or
any such survey/assessment, the DMF shall prepare a strategy for five years
and the same shall be included in the Perspective Plan. The five year
Perspective Plan shall be prepared taking into account current balance
available and likely accrual to the DMF over a period of five years. The five
year Perspective Plan shall be disaggregated into year-wise action plans.
The five year Perspective Plan shall have separate sections on all priority
sectors like drinking water, health, education, welfare of women and children,
etc and other sectors like roads, irrigation etc
The five year Perspective Plan shall be approved by the Governing Council of
the DMF and displayed on the website of the DMF.
The Annual Plans of the DMF to be approved by Governing Council each year
shall be based upon the five year perspective plan and success achieved in
fulfilling its targets in earlier years. The Annual Plans may include some other
works and expenditures considered urgent in nature although not included in
the perspective plan to a maximum extent of 10% of the annual plan.
The State Government may empanel renowned organisation/ agencies/
universities for conducting the baseline surveys and preparing five year
perspective plans.
The Governing Council shall approve the five years perspective plan and
annual plan comprising of list of projects to be taken up in financial years.

6. Restriction on fund transfer from DMF – In respect to the DMF funds of
the districts:

i.
ii.

iii.

iv.

The provisions of Section 9B of the Act shall be strictly adhered to in respect
of utilisation of funds by the District Mineral Foundations;
No fund shall be transferred in any manner from the District Mineral
Foundations to the State exchequer or State level fund (by whatever name
called) or Chief Minister’s Relief Fund or any other funds or schemes; and
No sanction or approval of any expenditure out of the fund of the District
Mineral Foundation shall be done at the State level by the State Government
or any State level agency.
No fund shall be spent outside directly or indirectly affected areas within a
district or for other than affected people as defined in section 1.1.

Page | 12

<!-- page 15 -->

v.
vi.

No fund shall be transferred in any manner from one district to another district
except as mentioned in section 2 (d).
The approval of expenditure of funds from DMF lies solely with the
Governing Council of DMF. The State Government or State level Committee
(by whatever name called) shall not have overarching authority on sanction of
projects, approval of funds/ expenditure and their function shall be limited to
monitoring effective implementation of projects sanctioned under PMKKKY.

7. Special provisions for scheduled areas
The process to be adopted for utilization of PMKKKY funds in the scheduled areas
shall be guided by the provisions contained in Article 244 read with Schedule V and
Schedule VI to the Constitution relating to administration of the Scheduled Areas and
Tribal Areas and the Provisions of the Panchayats (Extension to the Scheduled Areas)
Act, 1996 and the Scheduled Tribes and Other Traditional Forest Dwellers
(Recognition of Forest Rights) Act, 2006.
In respect of villages affected by mining situated within the scheduled areas:
a. Approval of the Gram Sabha shall be required
i.
ii.

for all plans, programs and projects to be taken up under PMKKKY.
identification of beneficiaries under the existing guidelines of the
Government.

b. Report on the works undertaken under PMKKKY in the respective village
shall be furnished to the Gram Sabha after completion of every financial year.
[Gram Sabha will have same meaning as assigned to it for the purpose of implementation
of the Provisions of the Panchayats (Extension to the Scheduled Areas) Act, 1996 (Act 40
of 1996)]

8. Transparency & Accountability
a. Each Foundation will prepare and maintain a website/ or a specific section on
the website of the District Administration on which, inter-alia, the following
information will be hosted and kept updated: i.

Page | 13

Details of composition of the Governing Council and Managing
Committee of DMF/by whatever name called.

<!-- page 16 -->

ii.
iii.
iv.
v.

vi.

vii.
viii.

List of areas and people affected by mining (including periodic updation).
Quarterly details of all contributions received from lessees and others.
All meeting agenda, minutes and action taken reports (ATRs) of the DMF.
5 years Perspective Plan, details of investment of endowment fund,
Annual Plans and budget, work orders and Annual Report within 30 days
of issuance of the document.
Online status of ongoing works – implementation status/progress of all
the projects/programs being undertaken under PMKKKY should be
made available on the website, including description of work, details of
beneficiaries, estimated cost, name of implementing agencies, expected
date of commencement and completion of work, financial and physical
progress up to the previous quarter etc.
List of beneficiaries under various welfare programs.
Voluntary disclosures under RTI Act.

b. Each Foundation shall display description of the project and amount
sanctioned on a notice board at the project site.
c. Information, Education and Communication (IEC) activities to create
awareness regarding schemes implemented under PMKKKY through social
media, films, videos etc.
d. The District Mineral Foundation (DMF) shall share information pertaining to
performance of DMF including deposit of funds and implementation of works
to the State Government and Ministry of Mines, Government of India as per
the formats prescribed and manner specified.
e.

The Central Government shall develop an online portal for facilitating
administration of DMF including approval of projects, release of funds and
monitoring of implementation of the projects. Each DMF shall compulsorily
sanction, release funds and monitor execution of projects through the online
portal only from the date as may be notified by the Central Government.

9. Audit
a. The accounts of the DMF shall be audited by the Comptroller and Auditor
General (CAG) as per schedule decided by CAG.
b. The accounts of the DMF shall be audited every year by a Chartered
Accountant appointed by the DMF, or in such other manner as the
Government may specify, and the report thereof shall be placed in the public

Page | 14

<!-- page 17 -->

domain alongwith the Annual Report.

10. Annual Report
a. Every year, within three months from the date of closure of the financial year,
the DMF shall cause to prepare an Annual Report on its activities for the
respective financial year and place it before the DMF.
b. The Annual Report will be submitted to the State Government within one
month from the date of its approval by the DMF and will also be hosted on the
website of the Foundation.
c. The Annual Report of each Foundation shall be laid before the State
Legislative Assembly.

11. State Level Monitoring Committee
a. A “State Level Monitoring Committee” shall be constituted at the State level
under the Chairpersonship of the Chief Secretary with Secretaries of executing
Departments, Finance and Planning Department, and one representative of
Ministry of Mines, Government of India as members.
b. The Secretary of Geology and Mining Department or any other Department
entrusted to supervise DMFs in the State shall be the Member Secretary of the
“State Level Monitoring Committee”.
c. The Directorate of Geology and Mining or any Directorate as entrusted by the
State Government shall constitute a cell to be called “State Level Nodal DMF
Cell” for monitoring activities of DMFs in the State and shall act as the
Secretariat to the State Level Monitoring Committee.
d. The State Level Monitoring Committee shall monitor performance of DMFs
and compliance of transparency norms, audit and annual report of DMFs.
e. The State Level Monitoring Committee shall meet at least twice in a year.

12. Grievance Redressal
a. The DMFs shall devise and implement a grievance redressal mechanism so
that each grievance is redressed, and a suitable reply is given to the
complainant within 30 days of making a complaint to the Collector or any
other officer as may be notified.
b. The State Government may, on receipt of any complaint/public grievance
shall ensure each grievance is redressed by DMF and a suitable reply is given
to the complainant within the stipulated timeframe.
c. The Central Government may, on receipt of any complaint/public grievance

Page | 15

<!-- page 18 -->

regarding improper utilization of DMF funds, poor implementation of
projects or violation of PMKKKY guidelines –
i.

ii.

iii.

iv.

Refer the complaint to the State Government for submitting a detailed
Action Taken Report. The State Government shall submit a detailed
Action Taken Report within 2 months from receipt of reference from the
Government of India.
Alternatively, if it considers fit, the Central Government may get an
inquiry conducted by a Central team, or any third party on such
complaint.
On receipt of the Action Taken Report by the State Government or report
of Central Team or the third party, the Central Government shall direct
the State Government to take necessary corrective measures within one
month of receipt of such direction.
The State Government shall submit a report on implementation of
corrective measures.

13. Compliance mechanism
a. In case, a DMF –
i.
fails to maintain an endowment fund as mandated in section 2 (c)
ii.
transfers any fund in violation of section 6
iii.
fails to comply with any of the clauses in section 8
iv.
fails to get the accounts audited as mandated in section 9 (b)
v. fails to prepare and publish annual report as mandated in section 10
vi.
fails to follow directions of State Government or Central Government
in section 12.
the State Government or the Central Government may direct –
b. Suspension of sanction of any or all new works or execution of any or all of
already sanctioned works; and/or suspension of release of funds for any or all
the works by the bank(s) where DMF fund is deposited or the bank account of
the executing agencies where funds have been transferred from DMF.
c. The State Government or the Central Government may, after being satisfied
that necessary corrective measures have been taken, withdraw such
suspension.
d. In case any direction under b. or c. above is given by the Central Government
the withdrawal of such direction shall only be done by the Central
Government.

***

Page | 16

<!-- page 19 -->

Page | 17
