---
doc_id: "7aafe7efe75b3a99"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/27cada39ea4235bc6a2f9200f885353d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment in MNP License Agreement for change in interest rate, penalty and interest on penalty on delayed payment of License Fee or any other dues"
date: "2022-01-19"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "16a9c91d8c10f79d"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110001
(Access Services Wing)
No.20-271/2010-AS-I (Vol-IV)
Dated: 19.01.2022
To
All MNP Licensees
Subject: Amendment in MNP License Agreement for change in interest rate, penalty and
interest on penalty on delayed payment of License Fee or any other dues ­
regarding.
As per the Condition 13.1 of Part-II ofMNP License Agreement, the Licensor reserves
the right to modify at any time the terms and conditions of the License, if in the opinion of the
Licensor it is necessary or expedient to do so in public interest or in the interest of the security
of the State or for the proper conduct of the service. In pursuance of this condition, the
Licensor hereby amends/ appends the following in the MNP License Agreement:
Existing Clause
Amended Clause
PART-ID,
PART-III,
FINANCIAL CONDITIONS
FINANCIAL CONDITIONS
25.5 Any delay in payment of License Fee 25.5 Any delay in payment of License Fee
payable, or any other dues payable under the or any other dues payable under the License,
License beyond the stipulated period will beyond the stipulated period will attract
attract interest at a rate which will be 4% interest at a rate which will be 2 % above ~e
above the one-year Marginal Cost of one year Marginal Cost of Lending Rate
Lending Rate (MCLR) of State Bank of (MCLR) of State Bank of India existing as
India existing as on the beginning of the on the beginning of the Financial Year
Financial Year (namely 1st April) in respect (namely 1st April) in respect of the license
of the License Fees pertaining to the said fees or any other dues pertaining to the said
Financial Year. The interest shall be Financial Year. The interest shall be
compounded monthly and a part of the compounded annuallv. A part of the month
month shall be reckoned as a full month for shall be reckoned as a full month for the
the purposes of calculation of interest. A purpose of calculation of interest. A month
month shall be reckoned as an English shall be reckoned as an English calendar
calendar month.
month.
PART-III,
PART-III,
FINANCIAL CONDITIONS
FINANCIAL CONDITIONS
In
case,
the
total
amount
paid
as
25.8
Stands deleted.
quarterly License Fee for the 4 (four)

<!-- page 2 -->

quarters of the financial year, falls short by
more than 10% of the payable License Fee, it
shall attract a penalty of 50% of the entire
amount of short payment. However, if such
short payment is made good within 60 days
from the last day of the financial year, no
penalty shall be imposed. This amount of
penalty shall be payable within 15 days of
the date of signing the audit report on the
annual accounts, failing which interest shall
be further charged per terms of the
Condition 25.5 above.
2.
This amendment comes into effect from 01.10.2021 and will be applicable to the dues
which arise from the operations of the Licensee after the said date.
3.
This amendment shall be part and parcel of the MNP License Agreement and other
Terms & Conditions shall remain unchanged.

H~

(Anil Kumar Gehlot)
Director (AS-I)
For and on behalf of the President of India
Ph. No. 23036864

Copy to:
1. Secretary (TRAI).
2. DGT, DoT (HQ)/CGCA.
3. Advisor (Economics)/ Wireless Advisor/ Sr. DDG (TEC).
4. DDG(CS)/DDG(DS)/DDG(Satellite)/DDG (LFP)/ DDG (LFA)/ DDG (SPPI)/ DDG(SA)/
DDG(WPF)/ DDG(A/C) for kind information please.
5. All Directors of AS Wing.
6. Director (IT) may kindly arrange to upload this letter on the website ofDoT.
