---
doc_id: "7ba85f4def0cad25"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/7e85e2727568e684b40da8ce1ce2af7d.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Registration Certificate to M/s Shandong Xingfa Carbon Co. Ltd. dated 01.02.2022"
date: "2025-07-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "590ab9d995c8cb62"
---

<!-- page 1 -->

No. P-45021/112/2020-PP (BE-11)/006
Government of India
Ministry of Commerce and Industry
Department for Promotion of Indu stry and Internal Trade
(Public Procurement Section)
Udyog Bhawan , New Delhi
Dated: February 1, 2022
Registration Certificate to M/s Shandong Xingfa Carbon Co. Ltd.

The undersigned is directed to refer to application of M/s Shandong Xingfa
Carbon Co . Ltd. no. NI L dated 12.04.2021 seeking registration in accordance with
Department of Expenditure Order No . F. 6/18/2019-PPD dated 23.07 .2020 and to
convey that competent authority has approved grant of registration on the following
terms and conditions to the entity mentioned below:
Name of the applicant entity

M/s Shandong Xingfa Carbon Co. Ltd.

Registered Office

Linchi Town , Zouping County, Binzhou City,
Shandong Province, Ch ina

ltem/s for which registration is granted Graphite Mould Blanks (Used In the
manufacture of Cast Steel Wheels for
Railway Appl ication)
Val idity of registration

03 years from the date of issue of this letter,
i.e ., 31 51 January 2025

2.
The Registration is only for the purpose of participation in public procurement in
India in accordance with DoE Order (Public Procurement No .1) dated 23 .07 .2020 for
supply of items (goods/ works/ services) from the premises mentioned above .
In case of appointment of new Director(s)/sh areholders with more than 10%
3.
shares /change in contro lling ownership interest or control through other means, this
Reg istration shall automatically stand annulled .

(Pri~r)
Under Secretary to Government of India
E-mail: pritam .k@gov.in
Ph: - 011-23061306
To,
M/s Shandong Xingfa Carbon Co. Ltd.
Address: Linchi Town , Zoup ing County, Binzhou Ci ty, Shandong Province , China
Contact Person: Mr Changru Zhao , +86 13942012 102 , Ema il: 82111285@qq .com
