---
doc_id: "7bffdc6d354cb5a7"
source_url: "https://mines.gov.in/admin/download/652cc26c47f961697432172.pdf"
ministry: "Mines (MoM)"
title: "Minerals (Other than Atomic and Hydro Carbons Energy Mineral) Concession (Amendment) Rules, 2023 (1.11 MB)"
date: ""
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "f3265a2069d6c963"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-12102023-249364
xxxGIDHxxx
CG-DL-E-12102023-249364
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 584]

नई दिल्ली, बृहस्ट्पजतिार, अक्तूबर 12, 2023/आज‍िन 20, 1945
NEW DELHI, THURSDAY, OCTOBER 12, 2023/ASVINA 20, 1945

No. 584]

खान मंत्रालय
अजधसूचना
नई दिल्ली, 12 अक्तूबर, 2023
सा.का.जन.737(अ).— कें द्रीय सरकार, खान और खजनि (जिकास और जिजनयमन) अजधजनयम, 1957 (1957 का
67) की धारा 13 द्वारा प्रित्त िजियों का प्रयोग करते हुए, खजनि (परमाणु और हाइड्रो काबबन ऊिाब खजनिों से जभन्न)
ररयायत जनयम, 2016 का और संिोधन करने के जलए जनम्नजलजखत जनयम बनाती है, अर्ाबत:् —
1. संजिप्त नाम और प्रारं भ:(1) इन जनयमों का संजिप्त नाम खजनि (परमाणु और हाइड्रो काबबन ऊिाब खजनिों से जभन्न)
ररयायत (संिोधन) जनयम, 2023 है।
(2) ये रािपत्र में इनके प्रकािन की तारीख को प्रिृत्त होंगे।
2. खजनि (परमाणु और हाइड्रो काबबन ऊिाब खजनिों से जभन्न) ररयायत जनयम, 2016 में,—
(i) जनयम 44 के , खंड (i) के पश्चात्, जनम्नजलजखत खंड अंतःस्ट्र्ाजपत दकया िाएगा, अर्ाबत्:—
"(iक) जलजर्यम के संबंध में, एक माह में लंिन मेटल एक्सचेंि द्वारा प्रकाजित जलजर्यम हाइड्रॉक्साइड
मोनोहाइड्रेट या जलजर्यम के अन्य उपयुि यौजगक के साप्ताजहक मूल्यों के आधार पर पररकजलत समतुल्य जलजर्यम
धातु मूल्यों को मूल्य प्राप्त होने िाली मुद्रा के जलए भारतीय ररज़िब बैंक या भारतीय ररज़िब बैंक द्वारा प्राजधकृ त
दकसी एिेंसी के प्रकािन के दिन की संिर्भबत िर से गुणा दकया िाएगा।";
6520 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(ii) जनयम 45 के , उप-जनयम (4) के पश्चात्, जनम्नजलजखत उप-जनयम अंतःस्ट्र्ाजपत दकये िाएंग,े अर्ाबत्:—
“(5)(क) भारतीय खान ब्यूरो, िुलबभ मृिा ऑक्साइड के औसत जिक्रय मूल्य को उस माह के जलए मूल्य प्राप्त होने
िाली मुद्रा के जलए संयुि राज्य भूिैज्ञाजनक सिेिण (यूएसिीएस) या अन्य प्रजतजित प्रकािनों द्वारा प्रकाजित मूल्यों के
आधार पर िुलबभ मृिा ऑक्साइड के मूल्य को भारतीय ररज़िब बैंक की औसत संिर्भबत िर से गुणा करके रुपये में प्रकाजित
करे गा और िुलबभ मृिा ऑक्साइड का औसत जिक्रय मूल्य माजसक आधार पर उपलब्ध नहीं होने की ििा में, जपछले उपलब्ध
कै लेंडर िर्ब के जलए िुलबभ मृिा ऑक्साइड के मूल्य के आधार पर औसत जिक्रय मूल्य प्रकाजित दकया िाएगा।
(ख) राज्य सरकार िुलबभ मृिायुि अयस्ट्क के औसत जिक्रय मूल्य जनम्नजलजखत तरीके से जनधाबररत करे गी,
अर्ाबत:् —
िुलबभ मृिा तत्ि युि अयस्ट्क का
औसत जिक्रय मूल्य

=

(अयस्ट्क में अंतर्िबष्ट प्रत्येक िुलबभ मृिा आक्साइड का प्रजतित गुणा
भारतीय खान ब्यूरो द्वारा उस िुलबभ मृिा आक्साइड का औसत प्रजतित)
का योग।

(6) भारतीय खान ब्यूरो, जपछले उपलब्ध कै लेंडर िर्ब के जलए संयुि राज्य भूिैज्ञाजनक सिेिण (यूएसिीएस) या अन्य
प्रजतजित प्रकािनों द्वारा प्रकाजित फे रो-जनओजबयम के ऐसे मूल्यों को जनम्नजलजखत गुणा करके जनओजबयम के औसत जिक्रय
मूल्य को प्रकाजित करे गा, अर्ाबत्:—
(i) उि कै लेंडर िर्ब के जलए भारतीय ररज़िब बैंक की औसत संिर्भबत िर, और
(ii) 1.59 का रूपांतरण गुणक।"।
[फा. सं. एम.VI-16/85/2022-खान VI]
डॉ. िीणा कु मारी डरमल, संयक्
ु त सजचि

रटप्पण:- खजनि (परमाणु और हाइड्रो काबबन ऊिाब खजनि से जभन्न) ररयायत जनयम, 2016 भारत के रािपत्र, भाग-II, खंड
3, उप-खंड (i) में संख्यक सा.का.जन. 279(अ) तारीख 4 माचब, 2016 द्वारा प्रकाजित दकया गया और संख्याक
सा.का.जन. 205(अ) तारीख 15 माचब, 2022 द्वारा अंजतम संिोधन दकया गया।
MINISTRY OF MINES
NOTIFICATION
New Delhi, the 12th October, 2023
G.S.R. 737(E).—In exercise of the powers conferred by section 13 of the Mines and Minerals (Development
and Regulation) Act, 1957 (67 of 1957), the Central Government hereby makes the following rules further to amend
the Minerals (Other than Atomic and Hydro Carbons Energy Mineral) Concession Rules, 2016, namely:—
1.
Short title and commencement.— (1) These rules may be called the Minerals (Other than Atomic and Hydro
Carbons Energy Mineral) Concession (Amendment) Rules, 2023.
(2) They shall come into force on the date of their publication in the Official Gazette.
2.

In the Minerals (Other than Atomic and Hydro Carbons Energy Mineral) Concession Rules, 2016,—
(i) in rule 44, after clause (i), the following clause shall be inserted, namely:—
"(ia) In respect of Lithium, the equivalent lithium metal prices calculated on the basis of the weekly prices of
lithium hydroxide monohydrate or other appropriate compound of lithium published by London Metal
Exchange in a month shall be multiplied by the reference rate for the day of publication of the Reserve Bank of
India or any agency authorised by the Reserve Bank of India, for the currency in which the price is obtained.”;
(ii) in rule 45, after sub-rule (4), the following sub-rule shall be inserted, namely:—

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

“(5)(a) The Indian Bureau of Mines shall publish average sale price of Rare Earth Oxide in Indian Rupees on
the basis of prices published by United States Geological Survey (USGS) or other reputed publications by
multiplying the price of Rare Earth Oxide by average reference rate of Reserve Bank of India for the month for
the currency in which the price is obtained and in case the price of Rare Earth Oxide is not available on
monthly basis, the average sale price shall be published on the basis of price of Rare Earth Oxide for the last
available calendar year.

(b) The State Government shall arrive at average sale price of the ore containing Rare Earth Elements in the
following manner, namely:—

Average sale price of the
ore containing Rare Earth
Elements

=

Sum of (percentage of individual rare earth oxide contained in the ore
multiplied by average sale price of that rare earth oxide published by
Indian Bureau of Mines).

(6) The Indian Bureau of Mines shall publish average sale price of Niobium in Indian Rupees on the basis of
prices published by United States Geological Survey (USGS) or other reputed publications for Ferro-Niobium
for the last available calendar year by multiplying such price with the following, namely:—
(i) average reference rate of Reserve Bank of India for the said calendar year, and
(ii) the conversion factor of 1.59.”.

[F. No. M.VI-16/85/2022-Mines VI]
DR. VEENA KUMARI DERMAL, Jt. Secy.

Note:- The Minerals (Other than Atomic and Hydro Carbons Energy Mineral) Concession Rules, 2016 were published
in the Gazette of India, Part-II, section 3, sub-section (i) vide number G.S.R. 279(E), dated the 4th March, 2016
and lastly amended vide number G.S.R. 205(E), dated the 15th March, 2022.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ
Digitally signed by
MANOJ KUMAR VERMA

2023.10.12 22:22:39
KUMAR VERMA Date:
+05'30'
