---
doc_id: "7a8ff5d0caddf1c7"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/TENDERprematricOBC.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Tender for evaluation study on ''Outcome Based Evaluation of Pre-Matric Scholarship Scheme for Other Backward Classes (OBCs)''"
date: ""
pages: 30
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "10e586e64f639636"
---

<!-- page 1 -->

F.No. 15-3/2018 (Res.) -PD
Government of India
Ministry of Social Justice & Empowerment
Department of Social Justice & Empowerment
Shastri Bhawan, New Delhi
Dated the November 19, 2018
NOTICE INVITING E-TENDER
Online Tender (c-Tender) is invited for conducting an evaluation study on “Outcome
Based Evaluation of Pre-Matric Scholarship Scheme for Other Backward Classes (OBCs)”.
The duration of the study would be 3 months.
2s A demand draft /bank guarantee of %200000/- (Rupees Two Lakh only) as earnest
money in favour of DDO, Department of Social Justice & Empowerment is required to be
deposited (in original) in the office of Tender Issuing Authority at B-2, Ground Floor,
Pt.Deendayal Antyodaya Bhavan, CGO Complex, New Delhi on or before bid submission
closing date and time. The envelop should be super scribed as “EMD for evaluation study on
“Outcome Based Evaluation of Pre Matric Scholarship Scheme for Other Backward Classes
(OBCs)" may be addressed to Under Secretary, D/o Social Justice & Empowerment, B-2, Pandit
Deendayal Antyodaya Bhavan, CGO Complex, New Delhi. Scanned copy of the EMD (Earnest
Money Deposit) should also be uploaded along with the online bids.
3: The tender document contains the following:-
ANNEXURE 1 TENDER DOCUMENT
ANNEXURE 2 PROGRAMME DETAILS
ANNEXURE 3 TERMS OF REFERENCE
ANNEXURE 4 FORMAT FOR TECHNICAL & FINANCIAL BIDS
ANNEXURE 5 GUIDELINES FOR TECHNICAL BID
ANNEXURE 6 TECHNICAL EVALUATION CRITERIA
ANNEXURE 7 FORMAT FOR PERFORMANCE SECURITY
ANNEXURE 8 INSTRUCTIONS FOR ONLINE BIDS SUBMISSION
ANNEXURE 9 TENDER ACCEPTANCE LETTER

<!-- page 2 -->

CRITICAL DATE SHEET
Name of Ministry/ Department Department of Social Justice & Empowerment,
Shastri Bhawan, New Delhi
Pre Bid meeting* 27.11.2018 at 1100 hrs
Venue: D/o Social Justice & Empowerment, B-2,
Ground Floor, Pandit Deendayal Antyodaya
Bhavan, CGO Complex, New Delhi-110003
Date and Time for Opening the Financial Bids | Will be intimated online after finalization of
Technical Bids
Address for Communication Under Secretary (Plan/Evaluation), D/o Social
Justice & Empowerment, B-2, Ground Floor,
Pandit Deendayal Antyodaya Bhawan, CGO
Complex, New Delhi-110003.
Website: https://eprocure.gov.in/eprocure/app
*The organisations willing to participate in the Pre Bid meeting may register on e-mail id:

manojk.jha@nic.in & vijendra.singhS0@nic.in latest by 26.11.2018.

1. The tender form/ bidder documents are available at the Website http://eprocure.goy.in
and www.socialjustice.nic.in. Online bids complete in all respects should be submitted
through CPP Portal https://eprocure.gov.in/eprocure/app only on or before the last date
and time. Information is also available at www.nsfde.nic.in, nbefde.goy.in and
nskfde.nic.in.

2. Manual bids will not be accepted.

3. Tenderers ji Bidders are requested to visit the website
https://eprocure.gov.in/eprocure/app / www.socialjustice.nic.in regularly. Any
changes / modifications in tender enquiry will be intimated by corrigendum through these
websites only.

4. In case, holiday is declared by the Government on the day of opening bids, the bids will
be opened on the next working day at the same time. The Department reserves the right
to accept or reject any or all the tenders without assigning any reason.

(Manoj Kumar Jha)
Under Secretary to the Government of India
2

<!-- page 3 -->

INDEX
|
—_
|
|
|
eee |
|
ae
eT
3

<!-- page 4 -->

ANNEXURE 1
F.No. 15-3/2018 (Res.)-PD
Government of India
Ministry of Social Justice and Empowerment
Department of Social Justice and Empowerment
(Plan Division)
के रू # मर मर मर.
B-2, Ground Floor,
Pt. Deendayal Antyodaya Bhavan
CGO Complex, New Delhi
Dated the November 19, 2018
TENDER DOCUMENT
The Department of Social Justice and Empowerment invites online tender (e-Tender) for
conducting an evaluation study on the “Outcome Based Evaluation of Pre-Matric Scholarship
Scheme for Other Backward Classes (OBCs)”.
The study should be completed within 3 months from the date of acceptance of
Letter of Award (LoA).
1. ELIGIBILITY
i. Bids are invited from Organisations having requisite qualifications to undertake such
studies. (As indicated in Annexure 6)
ii. Non-Governmental Organisations / Voluntary Organisations receiving grant from
Ministry of Social Justice & Empowerment are not eligible to apply.
iii. Blacklisted Organisations are not eligible to apply.
2. IMPORTANT DATES
Name of Ministry/ Department Department of Social Justice & Empowerment,
Shastri Bhawan, New Delhi
Date and Time for Issue/Publishing of Tender | 19.11.2018 at 1500 hrs
Document Download Start Date and Time 20.11.2018 at 1000 hrs
Bid Submission Start Date and Time 20.11.2018 at 1000 hrs
Pre Bid meeting 27.11.2018 at 1100 hrs
Venue: D/o Social Justice & Empowerment, B-2,
Ground Floor, Pandit Deendayal Antyodaya
Bhavan, CGO Complex, New Delhi-110003
Document Download End Date and Time 10.12.2018 at 1500 hrs
Bid Submission End Date and Time 10.12.2018 at 1500 hrs
Date and Time for Opening of Technical Bids | 11.12.2018 at 1500 hrs
Date and Time for Opening the Financial Bids | Will be intimated online after finalization of
Technical Bids
4

<!-- page 5 -->

3. SUBMISSION PROCESS

Willing and interested Organisations desirous of undertaking the evaluation study may
submit their two part bid as technical and financial bids as per extant procedure elaborated in this
document. The procedure for online submission of bids may be seen at Annexure 8.

In order to submit the bid, bidders may first register themselves online at
http://eprocure.gov.in as a one-time activity, in the e-Procurement portal with a valid DSC
before they can file their e-Tender. The registration should be in the name of the bidder, whereas
DSC holder may be either the bidder himself or a duly authorised person. The bidders will have
to accept, unconditionally, the online user portal agreement which contains all the terms and
conditions of Notice Inviting Tender (NIT) including commercial and general terms and
conditions and other conditions, if any, along with an online undertaking in support of the
authenticity of the declarations regarding facts, figures, information and documents furnished by
the bidder online. The bidders need to submit their technical and financial bids online. Online
bids complete in all respects should be submitted through CPP Portal
https://eprocure.gov.in/eprocure/app only on or before the last date and time. No Manual bids
will be accepted.

4, SELECTION PROCESS

D/o Social Justice & Empowerment invites technical and financial bids on open tender
basis from qualified organisations under the two bid system based on Least Cost Selection
process as per procedure indicated in Annexure 8. A Technical Evaluation Committee and a
Financial Evaluation Committee will be constituted to evaluate and finalise the technical and
financial proposals received in response to the Tender Notice. Both the technical and financial
bids would be opened online by the Bid Opening Committee constituted by the Department. Bid
openers would download the bids and the reports/statements and sign them for further
processing. The Technical Evaluation Committee would shortlist the technically qualified bids.
Financial bids of only the technically qualified bids would be opened. The date and time of
opening of financial bids would be uploaded on the portal and shortlisted firms would be
informed after shortlisting of the technically qualified bidders the parameters for qualifying the
technical criterion are given at Annexure 6. Financial bids would be opened for only technically
eligible and responsive offers and ranked. L-1 offer out of the responsive offers would be
selected on price criteria alone, subject to the reasonability of the cost. In case the offer is not
accepted by organisation ranked L-1, the offer will be given to L-2 and so on.

Ss DOCUMENTS TO BE SUBMITTED:
a) Technical Bids
b) Format for Technical Qualification (indicating fulfilment of all the indicated criterion)
i. Scanned copies of Registration Certificate / Memorandum & Articles of
Association and any other documents to certify the nature of the Organisation
ii. Scanned copies of Audited Annual Account of last three years
iii. Scanned copies of last three (3) years Annual Report
5

<!-- page 6 -->

iv. Proof that the organization has an annual average turnover of not less than = 75
Lakh during the last three years (Financial years 2015-16, 2016-17 & 2017-18
towards establishing which audited financial statements to be submitted. In case
of financial statement of FY 2017-18 being under audit, average turnover of the
previous three financial years which have been audited i.e. 2014-15, 2015-16 &
2016-17 will be considered. However, applicant will have to additionally submit
provisional balance sheet of FY 2017-18 to establish that annual turnover of said
year is also above % 75 Lakh)
v. Scanned copy of valid PAN of the Organisation/Tax Account Number (TAN) and
Service tax number (STN)/GST Number
vi. Executive summary of 3 study reports completed in social sector sponsored by the
Central / State Government / Central or State PSU that have also been accepted by
the sponsoring organisation during last five years. Documents of acceptance of
the Reports by sponsoring authority may be submitted.
vii. A declaration that the organization has not been blacklisted from the Authorized
Signatory of the Organisation
viii. An authorization letter from the firm certifying that the person who signed the bid
is an authorized person to sign on behalf of the firm
ix. Earlier engagements/assignments completed by the Project Director (enclose the
copy of certificate / self certified statement)
x. Earlier engagements/assignments completed of at least two post graduate research
professionals involved in the Project (enclose the copy of certificate)
c) Financial Bids
d) Scanned copy of Earnest Money Deposit (EMD).
e) Tender Acceptance Letter
6. EARNEST MONEY DEPOSIT (EMD)

The intending bidders should pay along with bids an Earnest Money Deposit of &
200000/- (Rupees Two Lakh only). The EMD shall be paid by Demand Draft/ Bank Guarantee
from any of the scheduled Banks. Bank Guarantee from any scheduled bank in favor of DDO,
Department of Social Justice & Empowerment, Shastri Bhavan, New Dethi-110001 is required
to be deposited (in original) addressed to Under Secretary (Plan/Evaluation), D/o Social Justice
& Empowerment, B-2, Pandit Deendayal Antyodaya Bhavan, CGO Complex, New Delhi. The
EMD will not carry any interest. Procedure for e-uploading as indicated in Annexure 8 above
may be followed. Government and other organizations exempted from payment of EMD may
attach scanned copy of the document as a proof in this regard.

(A) | The EMD submitted by the bidder will be forfeited if:
e Ifsuccessful bidder fails to accept the Letter of Award (LoA).
e If bidder fails to furnish the required performance security within the specified period.
e The bidder withdraws bid after processing but before acceptance of Letter of Award
(LoA).
6

<!-- page 7 -->

e The bidder violates any of the provisions of the terms and conditions of the tender
document.
e If bidder canvasses in any way for the bid
e If bidder withholds information or submits false information
(B) | The EMD will be refunded to:
e The successful bidder, subject to submission of Performance Security
e The unsuccessful bidders, only after acceptance of award of contract by the selected
bidder or in case of cancellation of Tender
The Earnest Money Deposit will be refunded without any interest under all conditions.
Offers received without EMD will be summarily rejected (other than those exempted). The EMD
will remain valid for a period of forty-five days beyond the final bid validity period. EMD of the
unsuccessful bidders will be returned to them latest on or before the 30 day after the award of
the contract.
Ts PERFORMANCE SECURITY
The successful bidder will be required to submit a Performance Security issued by any
scheduled commercial bank @ 8% of the contract value. Performance Security may be furnished
in the form of an Account Payee Demand Draft or Bank Guarantee from a Commercial bank.
Performance Security would remain valid for a period of sixty days beyond the date of
completion of the contract. The Performance Security may be invoked by the Department in case
of failure of bidder to adhere to the terms & conditions of the contract. In case of delays in
execution of project, the Department may seek extension of the Performance Security which will
require to be acceded to by the Organization. Format at Annexure-7.
8. PENALTY FOR DELAYED SUBMISSION OF REPORT
In case of any delay in submission of report by due date, a penalty @ 0.5% of the cost of
study per week will be levied.
9. NON TRANSFERABLE BID
Neither the contract nor any rights granted under the contract may be sold, leased / sublet,
assigned, or otherwise transferred, in whole or in part, by the bidder, and any such attempted
sale, lease, assignment or otherwise transfer shall be void and of no effect without the advance
written consent of the D/o Social Justice & Empowerment.
10. PRE BID MEETING
The interested bidders/authorized signatories may attend the pre-bid meeting, if desired
by the bidder(s) as per the schedule mentioned at Para 2 above. The clarification if any, to all
queries received from the bidders on or before the pre bid meeting, will be intimated to all
bidders / posted on the Department’s website: www.socialjustice.nic.in.
7

<!-- page 8 -->

11. COMPLETENESS OF BID OFFER

The bidder is expected to examine all instructions, forms, terms & conditions and
specifications in the tender document. Failure to furnish all information required in document or
submission of offer not substantially responsive in every respect to the tender document will be
at the bidder’s risk and may result in the rejection of bid offer. The bid offer is liable to be
rejected outright without any intimation to the bidder if complete information as called in the
tender document is not given therein, or if particulars asked for in the Forms / Proforma in the
tender are not fully furnished.
12. TECHNICAL & FINANCIAL OFFER

(A) The technical offer should comply with all the requisite information. The technical offer
should be complete in all respect. The financial offer should give all relevant price
information and should not contradict the technical offer in any manner. The prices
quoted in the financial bid should be without any conditions. Bidder should quote as per
the format specified in Annexure 4. All prices to be quoted in Indian Rupees only. The
financial bid in the prescribed format may be scanned and uploaded. These would
remain password protected and it would be possible to view them only on the date and
time indicated after the short-listing of the technical bids.

(B) Price quotation accompanied by vague and conditional expressions will be treated as
being at variance and shall be liable for rejection. Omissions, errors, misrepresentations
or inadequate details in the bidder’s financial proposal will be considered as valid
ground for rejection of the bidder’s proposal.

(C) Payment with retrospective effect for the work already done before the submission of the
proposal will not be permissible.

13. TREATMENT OF DISCREPANCIES

Where there is a discrepancy between amounts in figures and in words, the amount in
words will govern. If a Bidder refuses to accept the correction, his Bid will be rejected.
14. CORRUPT AND FRAUDULENT PRACTICES

The Department will reject a proposal for award if it determines that bidder
recommended for award has engaged in corrupt or fraudulent practices in competing for the
contract in question. The bidder is liable to be blacklisted in such an event.
15. LETTER OF AWARD AND CONTRACT AGREEMENT

The department will issue a Letter of Award (LoA) to the successful bidder in duplicate
which will be signed by both the parties across the tables as a token of acceptance and entry into
the contract by both parties. The duly signed LoA along with a contract bond and Performance
security would need to be submitted to the Department within the stipulated time indicated in the
LoA. Non execution of the contract agreement by the organization to whom the study is to be

8

<!-- page 9 -->

awarded would constitute sufficient ground for annulment of the award and forfeiture of Earnest
Money Deposit (EMD).
16. PAYMENT TERMS
Funds will be released by the Ministry in three installments as under:-
1* installment : 20% (after receipt of Performance Security)
2" installment 7 50% (on acceptance of draft report)
3" instalment : 30% (after acceptance of final report by the Department)
17, OWNERSHIP OF DATA
The organisation receiving funds for a project shall make suitable arrangements for the
preservation of data collected during the study, such as filled in schedules, tabulation or working
sheets, reports, photographs etc, relating to the Project, in electronic form and this shall be shared
with the Ministry at the time of submission of Final Report. The ownership of all such data shall
remain with the D/o Social Justice & Empowerment. All raw data compiled during the study
shall be transferred to the Ministry. No data collected in context of the study may be destroyed or
otherwise disposed off or given to any other organization/individual, unless so approved by the
Ministry.
18. SUBCONTRACTING
The bidder shall not subcontract to perform any of the work, service or other performance
required under the contract.
19. ARBITRATION
The Department and the Organization to whom the work order has been given will make
every effort to resolve amicably, by direct negotiation, any disagreement or dispute arising
between them under or in connection with the work order. If any dispute will arise between
parties on aspects not covered by this agreement, or the construction or operation thereof, or the
rights, duties or liabilities under these except as to any matters the decision of which is specially
provided for by the special conditions, such dispute will be referred to arbitrator, to be appointed
by the competent authority appointed by this Ministry and will be final and binding on both the
parties. Such arbitration will be governed in all respect by the provision of the Arbitration and
Conciliation Act, 1996 or later and the rules there under and any statutory modification or re-
enactment, thereof. The arbitration proceedings will be held in New Delhi only, wherein
appropriate Appellate Authority shall also be the Hon’ble High Court of Delhi at New Delhi.
9

<!-- page 10 -->

20. APPLICABLE LAW AND JURISDICTION OF COURT
The contract with the selected Organization shall be governed in accordance with the

Laws of India and will be subject to the exclusive jurisdiction of Courts at Delhi.

21. AGREEMENT

i. The organisation will confirm in writing that the conditions contained in the tender
document are acceptable to it as per Tender Acceptance Letter format in Annexure 9. The
selected bidder will also execute a bond in favour of the President of India to the effect
that it will abide by the terms and conditions attached to the funds and that in case it fails
to abide by the same, it will refund to the Government the total funds sanctioned to it for
the purpose with penal interest of 15% per annum thereon.

ii. The Ministry will have no responsibility for any financial expenditure or liability arising
out of the project except what has been specifically approved by it and conveyed to the
selected bidder through the sanction letter.

ili. The evaluating organisation shall not incur any excess expenditure on the research
project, under any circumstances, over and above the sanctioned amount, without prior
written approval of the Ministry. Ordinarily such request will not be entertained by the
Ministry.

iv. The Project Director will submit to the Ministry progress report of the project. The
organisation would make a presentation before the Ministry at draft stage on its
preliminary findings or as and when required by the Ministry.

v. The organisation should ensure that no durable assets shall be created out of the funds
released to it to conduct the evaluation study.

vi. The Ministry may examine the draft report and in case of any discrepancies observed
therein the Project Director may revise the report as per the observations made by the
Ministry. The organization will submit 8 copies of the final report as approved and
accepted by the Ministry alongwith its Soft copy and 20 copies of the summary reports.

vii. The project report / evaluation study will be strictly in accordance with the Terms of
References of the evaluation study falling which the Ministry reserve the right to
withhold the payment of cost of study till the terms are met.

viii. The Project Director will report to the Ministry changes he makes in the research design,
and no major change will be made therein unless the prior approval of the Ministry has
been obtained. On a request from the Evaluating organisation, the Ministry may in
exceptional cases, permit the appointment of another Project Director. When the Director
of a project takes up an appointment at another organisation before the project is
completed the Ministry may permit, with the consent of both the organisations concerned
the transfer of the project to the other organisation.

ix. If the Ministry is not satisfied with the progress of the project, or if it finds that these
tules are being violated, it reserves the right to terminate agreement & initiate necessary
action as per terms & conditions of the tender document and extant rule of Govt. of India.

22. DEFAULT

i. The selected bidder shall execute a bond in favour of the President of India to the effect
that it would abide by the terms and conditions attached to the study and that in case it

10
