---
doc_id: "7b4bb3aa8fd08a3b"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/c22ce181b8c3d5024a13f3e3228ea766.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment of United Access Services(UAS) Licence Agreement(s) to use spectrum auction through NIA dated 28.09.2012 for provision of telecom access services for West Bangal service  Area"
date: "2013-06-10"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a739bccb7590694a"
---

<!-- page 1 -->

No.20-377(WB)/ 2013-AS-I
Government of India
Ministry of Communication & IT
Department of Telecommunications
(Access Services Division)
1203, Sanchar Bhawan, Ashok Road, New Delhi-110001.
~\j,,\i\.Sl J 1-0
Dated :..Ma\'
, 2013

To,
M/s Vodafone South Ltd.,
C-48, Okhla Industrial Area,
Phase-II, NEW DELHl-1100 20
SubJect:-

Amendment of Unified Access Services {UAS) Licence Agreement(s) to use
spectrum auction through NIA dated 28.09.2012 for provision of telecom
access services for West Bengal service Area.

In pursuance of Condition 5.1 of the UAS licence agreement(s}, Clause 4.7 of the
Notice Inviting Applications (NIA) for "Auction of Spectrum in 1800 and 800 MHz Bands"
vide No. 3-l'fi/2012-Fin/Auction, WPC Wing letter of lntent(Lol) No.L-14004/03/2012-NTG,
dated 19.17.2012 and on the request of the licensee vide letter No.Dal/VSL/ Auction/11­
12/4, dated 23.11.2012 & No.VSL/Auction/LOl/12-12/24, dated 20.12.2012, the LICENSOR
hereby insert follo~ing condition (23.9) in the UAS licence agreement for the West Bengal
service area(s}.

"23.8 Use of Spectrum won in auction of 1800MHz band: The licensee is authorised
to use the spectrum block(s} (as

in the above said Letter of Intent} for provisioning of

Services as defined in the "Scope of the licence" in the Schedule (Condition 2} of the UAS
License agreement, , subject to compliance of following conditions:

.23.8.1 Validity period for the spectrum won through auction mentioned above. The
validity period of the spectrum won in this auction shall be 20 years from the date of issue
of Letter of intent (Loi} (the 'Effective date'}. In case the Licence is cancelled/terminated for
any reason, the spectrum usage rights shall stand withdrawn forthwith. If the period of an
existing License expires before the expiry of right to use the spectrum awarded by means of
the current Auction, then the Licensee will have to obtain UL (Access Services)/Unified
License as may be applicable.

23.8.2 Roll-out obligations for the above mentioned Spectrum : The licensee shall have a
network rollout obligation as detailed below.

The obligation reflects the need both to

ensure the efficient use of spectrum and provide a reasonable level of service to a wide
cross-section of customers.

<!-- page 2 -->

23.8.2.1

The licensee shall make its own arrangements for all infrastructure involved
in rolling out of the network and shall be solely responsible for installation,
networking and operation of necessary equipment and systems.

23.8.2.2

The Licensee shall make its own arrangements for Right of Way (ROW) and
other

necessary

permissions/clearance

required

as

per

relevant

laws/regulations/directions of the respective agencies for rolling out the
network. The Central Government has already issued necessary notification
conferring the requisite powers upon the licensees for the purposes of
placing telegraph lines under Part Ill of the Indian Telegraph Act 1885. Non­
availabilit~ of the ROW or delay in getting permission/clearance from any

agency shall not be construed or taken as a reason for non-fulfil~ent or delay
in compliance of the Roll-out obligations and shall not be taken a valid excuse
for not carrying any obligations imposed by the terms of the NIA.

23.8.2.3

The Licensees shall make arrangements for interconnection with other
networks in that LSA for carrying inter-network local and long distance traffic,
billing of SERVICE and treatment of SUBSCRIBER complaints as part of the
rollout of network.

23.8.2.4

Over and above the roll out obligation mentioned in clause 34 of the licence,
the Licensee will have the following roll out obligations:
i)

At least 10% of the Block Headquarters (BHQs) of the Licensed Service
Area

(LSA) shall be covered by the end of three years from the

effective date of Licences or date of allotment of spectrum won in the
auction process, whichever is later. Additional 10% of the Block
Headquarters of the LSA shall be covered in each of two subsequent
years i.e. at least 20% and 30% coverage of the block headquarters of
the LSA has to be achieved at the end of 4th and 5th year respectively.
The list of Block' Headquarters {BHQs) and its 'to the scale' Map(s) will
have to be obtained by the successful bidder from the
State Governments/Administrations/local bodies.

respective

The boundary of

the Block Headquarters will be as per map/ definition given by the
State Government/Administration/Local Body concerned.

In cases

where District Headquarter/Town (DHQ/town) happens to be BHQ
also, that particular DHQ/town or BHQ would be considered as part of
compliance of any one phase of rollout obllgation only, as per the
choice of licensee.
ii)

Each milestone of the rollout obligations as mentioned in the clause
23.8.2.4(.i) above, would be considered as separate phase of rollout
obligations. Thus there will be three additional phases of rollout
obligations.

iii)

Coverage of Block Headquarters would mean that at least 90% of the
area bounded by the local body limits should get the required street

\fu\ '\1>~~\17

2./'.LO

<!-- page 3 -->

level coverage by mandatorily setting up of Base station(s) (for
e><ample a BTS/node B/ e-node B) in the Block Headquarters.
iv)

The Licensee may offer coverage of Block Headquarters already
achieved in accordance with stipulation in clause 23.8.2.4(iii) above as
a part of compliance towards roll out obligation. However, testing of
the coverage already achieved will be carried out by DoT as per
prescribed test schedule/procedure. The coverage of the BHQs as per
the above mentioned rollout obligations will be over and above the
DHQs/towns covered as part of the existing rollout obligations
mentioned in the UASL.

v)

The choice of Block Headquarters to be covered and further
expansion beyond 30% Block Headquarters shall lie with the Licensee
depending on their business decision.

vi)

The roll out obligation shall be applicable in respect to the network
deployed using the spectrum band acquired through auction.
Accordingly, the roll out already achieved shall be counted the same
. spectrum band. The roll out obligation relates to frequency band in
which the spectrum is acquired through auction.

For this purpose,

900 MHz band and 1800MHz band will be treated as the same band.
vii)

The Licensee will have the flexibility to meet the rollout obligations
.mentioned in clause 23.8.2.4(i) & (iii) through shared infrastructure
to the extent permissible as per guidelines/instructions applicable
from time to time. However, it may be noted that rollout obligations
cannot be complied with using the intra-service area roaming
arrangements.

viii)

In the case of metro service area, there will be no obligation relating
to block headquarters. However, the rollout obligations mentioned in
clause 34 of the licence, will have to be fulfilled.

23.8.2.5

The number of Block Headquarters will be taken as existing on the date of
issue {i.e. 28.9.2012) of the Notice inviting Applications {NIA) for auction of
spectrum.

23.8.2.6

For calculation of number of BHQs to be covered, the fraction which comes
to 0.5 or above shall be rounded off to the ne>ct whole number and if the
fraction is less than 0.5 it shall be ignored.

23.8.2.7

In case of change of technology by the licensee, while rolling out network for
compliance of the rollout obligations, following will be required:
(i)

Continuity of coverage, provisioning, delivery, quality and services in
the network deployed with earlier technology is to be ensured.

<!-- page 4 -->

(ii)

Licensee may be required to submit the test reports as per test
schedule/procedure, in respect of Base Station sites already tested as
part of compliance of rollout obligations, to the licensor who may also
carry out sample verification.

(iii)

Licensee may fulfil the remaining part of rollout obligations with later
technology as per test schedule/procedure for that technology.

(iv)

Change in technology, if any, while rolling out network for compliance
of the rollout obligations, should be informed to the licensor at least
one year before any new technology Base Station site is offered for
testing, so that Test Schedule Test Procedure (TSTP) for that
technology can be finalized.

23.8.2.8

In cases where allocation of spectrum based on this auction is in less number
of BHQs/DHQs (i.e. less than prescribed percentage of the BHQs or DHQs for
any phase) in a particular LSA, rollout obligation shall get limited to rollout of
network in all BHQs/DHQs where spectrum is allocated in the LSA.

23.8.2.9

Allotment of spectrum for individual point-to-point fixed links i.e. Microwave
Backhaul Spectrum would be subject to separate application and the allotment
of the same is not linked to the compliance of rollout obligations.

For

compliance of the rollout obligations, the licensee has to make its own
arrangements for transmission media required for connecting the network
equipments etc. The allotment of backhaul spectrum is subject to the usual
processes, term and conditions and applicable charges. The Government shall
make available spectrum for these purposes under the terms and conditions
specified by the WPC Wing, subject to availability. However, it must be noted
that these frequencies are not part of the Auctions, and the payment of the
Successful Bid Amount does not ensure the allotment of backhaul spectrum.
Separate charges, as prescribed from time to time are payable 1 for backhaul
spectrum.
23.8.2.10

The Licensee shall ensure the rollout of network using the spectrum band
won in this auction process as per the rollout obligations mentioned above.
Rollout coverage testing will be carried out as per test schedule/procedure
(TSTP). Currently TSTP for GSM/WCDMA and CDMA technologies are
available. The same would be updated as per rollout obligations mentioned
here

23.8.2.11

For the purpose of verification of the rollout of the network and coverage
testing as mentioned above, the Licensee shall register with the respective
TERM cells of DoT. While registering with the TERM cell, he will also indicate
the phase number for which the Base Station site is being registered.
,,

The phase numbers of individual phases of rollout obligations are as follows:
Phasel: Coverage of 10% DHQs/Towns.

\\~\~~\,

<!-- page 5 -->

Phase2: Coverage of 50% DHQs/Towns.
Phase3: Coverage of 10% BHQs.
Phase 4: Coverage of additional 10% BHQs (Cumulative 20% BHQs)
Phase 5: Coverage of additional 10% BHQs (Cumulative 30% BHQs).
Date of registration by concerned TERM cell is to be treated as date of
meeting the roll-out obligation in case of successful verification of the rollout
of the network and coverage testing as per TSTP for the purpose of
compliance of rollout obligations and for calculating liquidated damages, if
applicable, in terms of Condition No.23.8.2.12

mentioned below.

If the

verification of the rollout of the network and coverage testing fails as per
TSTP, then the Licensee shall re-register with the respective TERM cells of
DoT and in that case, Date of re-registration by concerned TERM cell is to be
treated as date of meeting the roll-out obligation subject to successful
verification as per TSTP.

23.8.2.12

Liquidated Damages
a)

The time period for roll out of network as per the rollout obligations
mentioned above using the spectrum band won in this auction
process, shall be deemed as the essence of the contract and the
network must be rolled out

not later than such specified time

period(s). No extension in prescribed due date will be granted. If the
network, for a particular phase, is rolled out after the expiry of the
due date and is registered by the licensor for the purpose of testing,
such delay in rollout of network will entail recovery of Liquidated
Damages (LD) under this Condition.

Provided further that if the

rollout of the network, for a particular phase, is effected within 15
calendar days of the expiry of the due date then the Licensor shall
accept the rollout of network without levy of LD charges.
b)

At present, minimum 60 calendar days duration is prescribed for grant
of SACFA clearance.

While examining the compliance of rollout

obligations, the average delay in grant of the SACFA clearance beyond
the above mentioned prescribed duration shall be excluded from the
duration set for each phase of rollout obligations in the clauses
23;9.2.11 above. For the purpose of calculating the delay in grant of
SACFA clearance of individual Base Station site, the date of 'WPC
acceptance number' for SACFA clearance application would be treated
as the 'start date' and the date on which the SACFA clearance is
granted in the online system of WPC would be considered as the 'end
date'. The difference between the 'start date' and 'end date' after

<!-- page 6 -->

excluding

the

above

mentioned

prescribed

period

would

be

considered as the delay in grant of SACFA clearance for that Base
Station site for . the limited purpose of calculating the delay in
compliance of rollout obligation.

If the SACFA clearance for a

particular Base Station site has been granted within prescribed
duration, then for that particular site, delay would be considered as
1

c)

zero' days.

After working out the delay in grant of SACFA clearance as per above
mentioned procedure for each Base Station site offered for coverage
testing, an average of all these delays would be taken for calculating
1

the average SACFA delay' on the part of licensor. For the purpose of
1

average SACFA delay' calculations, delay in grant of SACFA clearance

of only those Base Station sites would be considered which are
registered with TERM cell for coverage testing of that particular phase
of rollout obligations.
e)

In case the Licensee fails to rollout the network or any part thereof,
for a particular phase, within the period prescribed for the same, the
Licensor shall be entitled to recover LO charges for that phase
separately @ Rs. 5 lakhs (Rupees Five Lakhs) per week for first 13
weeks; @ Rs. 10 lakhs for the next 13 weeks and thereafter @ Rs.20
. lakhs for 26 weeks subject to a ma>cimum amount of Rs.7.00 Crores for
each phase. For delay of more than 52 weeks in any phase, in addition
to imposition of maximum amount of LO as mentioned above, the
spectrum assigned based on this auction process may be withdrawn.
The PBG shall be encashed to the extent of LO amount, if the same is
not paid within the time period specified in the notice for recovery of
LO. For the purpose of calculation of delay in compliance of rollout

obligations, the week shall means 7 Calendar days from (from
midnight) Monday to Sunday; both days inclusive and any extra day
shall above counted as full week for the purpose of recovery of
liquidated damages.

23.8.2.13

PBG related to rollout obligation: PBG in prescribed format shall be
submitted for amount equal to Rs.21 crore valid for a minimum period of six
years. The validity period of PBG can be further extended by the licensor
depending upon the requirement for a period not exceeding two years from
the due date of expiry of the earlier PBG.
The PBG may be released only after the complete testing/verification of the
compliance of the rollout obligations by the licensor and recovery of the LD if
any upto the last phase of rollout obligation.

\~~\\b\e>

<!-- page 7 -->

23.8.3 Spectrum Charges:
Financial Bank Guarantees for Deferred payments:
a)

The Licensee shall securitize the annual instalment for the deferred payment

in respect of the November, 2012 spectrum auction amount through a Financial
Bank Guarantee(FBG) of an amount equal to one annual instalment valid for three
years.

On payment of first instalment and each instalment thereafter, the

Financial Bank Guarantee shall be renewed for a further period of one year and
submitted atleast one month prior to the date of e><piry of validity of Financial
Bank Guarantee submitted earlier. In case of the non-renewal, the Financial Bank
Guarantee will be encashed and the amount kept as non interest bearing deposit
with the DoT till such Bank Guarantee is renewed and instalment due is paid.
Payment of due instalments and renewal of Financial Bank Guarantee (FBG), shall
be done by the Licensee as per the schedule as prescribed in Appendi><-1 without
the necessity for the DoT to raise any demand or notice for the same.
b)

In case of overdue payments, penal interest shall be charged on the delayed

amount from the due date at the prime lending rate of the State Bank of India,
applicable on the due date, plus 2% compounded monthly, and a part of the
month shall be reckoned as a full month for the purpose of calculation of interest.
c)

If due payment are not received within· time plus a grace period of 10 days,

the sum shall be recovered by encashing the Financial Bank Guarantee.
d)

In the event of default in payments of instalments, in addition to the action

as provided in the paras above, DoT may terminate the License and Spectrum
allotment/assignment, in which case the allotted/assigned Spectrum will revert
back to DoT. The FBGs in such cases will be encashed. This would be without
prejudice to any other remedy DoT may decide to resort to.
23.8.4

Spectrum Usage Charges for above mentioned Spectrum:

Spectrum usage

Charges shall be payable as per the rates/slabs notified by the Government from
time to time. The present spectrum usage charges are mentioned below:­

Schedule A: Charges for GSM operators (Applicable for 1800MHz band)

~

I

<!-- page 8 -->

Spectrum Slab

%AGR

Up to 4.4 MHz

3%

Up to 6.2 MHz

4%

Up to 8.2 MHz

5%

)

Up to 10.2 MHz

6%

Up to 12.2 MHz

7%

Up to 15.2 MHz

8%

Schedule B: Charges for CDMA operators (Applicable for 800MHz band)
Spectrum Slab

%ofAGR

Up to 5 MHz

3%

Up to 6.25 MHz

4%

Up to 7.5 MHz

5%

Up to 10 MHz

•'

6%

Up to 12.5 MHz

7%

Up to 15 MHz

8%

The following shall be considered while computing the annual spectrum charges:
•

Applicable Adjusted Gross Revenue (AGR) shall be computed in accordance with the
provisions of the relevant service licence;

•

The Annual spectrum charges shall be applicable from the date of allotment of
Spectrum.

•

For the purpose of calculation of spectrum usage charge, there shall be a minimum
AGR which shall be not less than 5% of the bid amount. The calculation of spectrum
usage charges shall be on the basis of minimum AGR or the actual AGR whichever is
higher.

•

Spectrum allocated through November, 2012 auction will be added for determining
the slab for spectrum usage charges.

23.8.5-Merger of spectrum blocks: Mergers and Acquisitions (M&A) guidelines, as prescribed and
amended by DoT from time to time will apply.

<!-- page 9 -->

23.8.6

Breach, revocation and surrender: The spectrum allotment/assignment may be revoked,
withdrawn, varied or surrendered in accordance with applicable licence conditions or any
other applicable laws, rules, regulations or other statutory provisions.
The spectrum allotment/assignment may also be curtailed / revoked if the Government
determines the user of the spectrum to be in serious breach of any of the conditions of the
allotment of the spectrum (including adherence to the Auction Rules) and the consequent
obligations. In case of less serious breaches; the Government may impose penalties at its
discretion. Seriousness of the breach shall be determined by the Government at its sole
discretion.
If at any stage, the spectrum allotment is revoked, withdrawn, varied, surrendered or
curtailed no refund will be made. The Bank Guarantees may also be invoked to recover any
payable dues.

23.8.7 Applicability of the NIA: This amendment of the UAS licence agreement is subject to all the
terms & conditions of the Notice Inviting Applications (NIA) for /1 Auction of 1800 MHz and
800 MHz spectrum" vide No. 3-16/2012-Fin/Auction dated 28.09.2012. The licensee shall
comply with all the terms & conditions of the above said Notice Inviting Applications (NIA)
unless and otherwise amended by the licensor by way of amendment of the UAS licence
agreement from time to time.

2.

All other terms and conditions of the UAS licence agreement including amendments and
instructions issued from time to time shall remain unchanged.

3.

Please acknowledge receipt.

{Para~~~~!ha)

Under Secretary (AS.I)
For and on behalf of the President of India
Ph.No.23036050
Copy to:

1. Administrator USOF/Wireless Advisor/Sr. DDG(Term-Security)/Sr. DDG(WPF)
2.

Secretary TRAI

3.

DDG(Security)/DDG(CS)/DDG(DS)/DDG(LF-l)/DDG(LF-11)/

4.

Director (IT) may kindly arrange to upload this letter on the website of DoT.

<!-- page 10 -->

Appendix-1

Schedule of deferred payments as indicated in NIA

Deferred payment, subject to the following conditions:
(i) An upfront payment; of 33% in the case of 1800MHz band, and 25% in case of 900MHz and
800MHz band; of the final bid amount shall be made within 10 days of declaration of successful
bidders and final price;
(ii) There shall be a moratorium of 2 years for payment of balance amount of one time charges for
the spectrum, which shall be recovered in 10 equal annual instalments.
(iii) The 1st instalment of the balance due shall become due on the third anniversary of the
scheduled date of the first payment. Subsequent instalment shall become due on the same date of
each following year. Prepayment of one ·or more instalments will be allowed on each annual
anniversary date of the first upfront payment, based upon the principle that the Net Present Value
of the payment is protected.
(iv) An indicative schedule of payments is given below:
Full Amount Due
Upfront Payment
Balance to be recovered

Rs. 1000
33%
1000- (1000*33%)= Rs 670

Number of Instalments

10

Interest Rate
Assumed Date of first
payment
Moratorium

9.75%
25-03-2013
2 Years

Schedule of Payments
Instalment

Amount {Rs. Crore}

3rd instalment

Due Date for
payment
25-03-2013
26-03-2016
26-03-2017
26-03-2018

4th instalment
5th instalment
6th instalment

26-03-2019
26-03-2020
26-03-2021

129.93
129.93
129.93

7th instalment

26-03-2022

129.93

8th instalment

26-03-2023

129.93

9th instalment

26-03-2024

129.93

10th instalment

26-03-2025

129.93

Upfront payment
1st instalment
2nd instalment

330.00
129.93
129.93
129.93

1-o/1.D
