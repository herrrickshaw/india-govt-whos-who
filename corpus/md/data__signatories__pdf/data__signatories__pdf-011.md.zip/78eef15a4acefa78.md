---
doc_id: "78eef15a4acefa78"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/ab761bf222777eebdd231ada176d592b.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "NCSS-JKDFC-Admn.Fund-Sanction letter-15.07.2024-Rs.80,34,000/-"
date: "2025-06-25"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "93b2453da427a527"
---

<!-- page 1 -->

ha,ps://dpiit.eofnce.gov.in/efile/assets/Pd6s-2.16.105-dist/web/view

PDF.js viewer

P42018/496/2021-SPECIAL PACKAGE
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry & Internal Trade (DPlIT)
(Special Scheme Section)
Vanijya Bhawan, New Delhi
Dated: 15th July, 2024
To
The Accounts Officer,
Pay & Accounts Office,
Department for Promotion of Industry & Internal Trade (DPlIT)
Udyog Bhawan, New Delhi

Sub: Advance release of an amount of Rs. 80,34,000 (Rs. Eighty Lakh Thirty
Four Thousand Only) as administrative funds under the New Central Sector
Scheme for Industrial Development for infrastructure development of Jammu
& Kashmir Development Finance Corporation Ltd. (JKDFC).
Sir

The undersigned is directed to convey the sanction of the President for
advance release of an amount of Rs. 80,34,000 (Rs. Eighty Lakh Thirty Four
Thousand Only) as an administrative funds under the New Central Sector Scheme
for Industrial Development of UT of J&K scheme for the purpose of infrastructure
development of offices of JKDFC.

2.
As per the Notification F.No.1(1 )/2020-SSS dated 19&1 February 2021, J&K
Development Finance Corporation Ltd (JKDFC) has been notified as the Nodal
Agency to disburse incentives under various scheme components.

3.
The sanctioned administrative fund/amount may be released in favour of the
Jammu & Kashmir Development Finance Corporation Ltd. (JKDFC) to their Bank
Account A/c No. 33121448871, State Bank of India, Branch Railway Station, Jammu
RTGS/MICR No.180002006 1FSC Code SBIN0006894,

4. The detailed guidelines for the expenditure from administrative funds are
enclosed as Annexure.

5. The Expenditure is debitable to Demand No. 11 of the Department for Promotion
of Industry & Internal Trade for the financial year 2024-25 under the
the following head :
28850202.10119.0515.05_13

Other Outlay on Industries & Minerals (Major Head)
Development of Backward Areas (Sub Major Head)
Subsidies (Minor Head)
Project Management
Office Expenses

6.
Release of the above-mentioned amount to JKDFC is subject to the following
terms and conditions:
5;
1

/U{ider Soul

II

/Nlin.
1 000 1

llOOQ

19-03-2025, 11:52
7 of 16

<!-- page 2 -->

hups://dpiit.eofnce.gov.in/enle/assets/PdBs-2.16.105-dist/web/vlew

PDF.js viewer

JKDFC will utilize the funds exclusively for infrastructure development of the
offices of JKDFC (Jammu & Srinagar) as per the proposal submitted by
JKDFC in their proposal no. DFC/DPlIT/ADM/2024-25/207 dated 10-05-2024
of JKDFC. in no case the funds released under this sanction will be utilized for
any purpose other than those indicated in the sanction.
ii.
JKDFC will maintain a register of permanent and semi-permanent assets
acquired wholly or mainly out of the above administrative funds in the
prescribed format and copy thereof should be furnished to this Ministry.
iii
Assets acquired wholly or substantially out of Government funds shall not be
disposed of without obtaining the prior approval of the sanctioning authority of
infrastructure funds
iv.
JKDFC shall adhere to all the relevant provisions of GFFI, 2017 and any other
instruction/guidelines issued by the Government of India from time to time,
while making procurement/purchase of goods and services. All outsourcing of
goods, services and works should be done by following the procedure laid
down in GFR and instructions issued by the Department of Expenditure from
time to time
V.
JKDFC shall submit the Utilization Certificate in the prescribed Form GFFI12A duly signed by the authorized authority by 31-03-2025.
7
The expenditure incurred shall be open for inspection by the sanctioning
authority and audit, both by the Comptroller & Auditor General of India under the
provision of C&AG (DPC) Act, 1971 in accordance with the provisions laid down in
Section 14 of the C&AG (DPC 1971) as amended from time to time and Internal
Audit party of the Principal Accounts Office of the Department for Promotion of
Industry and Internal Trade whenever it is called upon to do so.
8.
Shri Sher Singh Meena, Under Secretary, Department for Promotion of
Industry and Internal Trade, Ministry of Commerce and Industry will act as Drawing
and Disbursing officer for this sanction
9.
This issues with the concurrence of IFW vide Note No. 50 dated 21.06.2024
of File No. P42018/496/2021-SPECIAL PACKAGE (Computer No. 57520).

aegmy

(Shei Singh Meena)
Under Secretary to the Govt. of India
MJF:E:5lik';T;r.Igb ?;Pil$26
HFfa liliaN/Govt.

aPR,q/3cin ljrl

of India

n{ R?$f}-rloo01

Van;jya /Udyog Bhaw3n. New DelhI.110001

Copy to:-

1. The Principal Director of Audit, Economic and Services Ministries, A.G.C.R
Building, Indraprastha Estate, New Delhi.
2.
Finance-II Section, Integrated Finance Wing, Department of Industrial
Policy
& Promotion
3. The Managing Director, J&K Development Finance Corporation Ltd., Ground
Floor, Udyog Bhawan, Jammu (J&K)-180012.
4 Budget & Accounts Section.
5. Guard File

19-03-2025, 11:52

8 of 16

<!-- page 3 -->

https://dpiit.eomce.gov.in/efile/assets/pdQs-2 . 16. 105-dist/web/view. . .

PDF.js viewer

File No. P42018/496/2021-SPECIAL PACKAGE
Annexure

Guidelines for the distribution/allocation of administrative funds and its
expenditure.

S.NO

Amount in lakhs

IParticulars

1

IRenovation & Repairment of offices of JKDFC

41.34

2

IPurchase of furniture & fixture (Chairs, Tables,
FSofa set, Cabinets) & Electrical items ( Servo UPS),
,ir conditioners, LCD . Water Purifiers, for both
ISrinagar & Jammu offices

20.00

3

Purchase of Computer Hardware for staff
I(Desktops, Laptops, Printers, Ipad , Scanners,
LCDs, Video Conferencing Equipments) and other
!tectronic Gadgets as required

20.00

Total (A:

81.34

%P/q

9 of 16

19-03-2025, 11:52
