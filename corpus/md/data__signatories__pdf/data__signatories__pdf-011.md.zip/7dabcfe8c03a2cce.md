---
doc_id: "7dabcfe8c03a2cce"
source_url: "https://rural.gov.in/static/uploads/2024/05/Re-advertisement-for-the-post-of-DC-and-AC-on-deputation_04052023.pdf"
ministry: "Rural Development (MoRD)"
title: "Re-advertisement for the posts of Deputy commissioner(WD) and Assistant Commissioner on deputation including short term contract"
date: "20230504"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "66819e1bc217e3e0"
---

<!-- page 1 -->

A-110111312022-Admn.

Government of lndia
Ministry of Rural Development
Department of land resources

'G' Wing, NBO Building,
Nirman Bhawan. New delhi-'1'10001

oated : {LtttaY, zo2l
VACANCY CIRCULAR

and
subiect: Re-advertisement for the posts of Deputy commissioner(wD)
reg

Assistant

commissioner on deputation including short term contract-

-=.-

Development) in
Applications are invited for the posts of Deputy Commissione(Watershed
the pay
Levelll
in
*trix [Rs 78800-io92oo] and A'sistant Commissioner including of
L"*r- iiSiit
term
short
"-prv
of Land Resources on deputation
i-"tr" iR" ozzcjo-io87oo
l'rn the Department
'under the centrat covernmenu state Governmenu Union
offi""o
Undertakings/ Autonomous or Statutory
i"iiitoi""i unr"oit"s] Research lnstitutions/ Public Sector
in Allglgrg:l'
mentioned
s the qualifications and experience as

;;'i;;;,'i;;'ff-"j,gLtJ
o;;;;;:il;J;ri
term contract) including period oJ deputation (including
2. Period of deputation including shortpost
held immediately preceding this appointment in same
L"tr""t)ln inotner ex-c-aare
ordinarily not exceed four
"n",t-t"i,
ottt"l. org;nization/ Department of the central Government shall
ii
"or"in" rn"ii,im age limit for appointment by Deputation (including. short term contract) shall
,""[.
of the receipt of application'
lot O"

"r"""Olng

SS Veirs as on the ciosing date

3,Theof{icerselectedwillhavetheoptiontodrawhispayplus,deputationallowancein
(partlll) dated
]"-Jrn"" *itn G Department of personnet & Training o.M No. 212l87-Estt. post
as per the

;;;"19s8;" amenoea irom time{o-time or to have his pay fixed in the scale of
prevailing rules/orders on the subject.

Employment News shortly lt is requested that
4. The vacancy circular is being published in theand
who can be spared, immediately' may be
.if irre etigrute an-d willing officers
tn"
"ppl-,Jr"tn" prescrib-ed proforma (,{nnexure-ll) along with up-to-date cR Dossier' Vigilance
il*"iiri,n
staiement showing major/minor penalties'-if

Cr""i"r"" cadre clearance and lnteg;ity Certficaie,

i.oos"d on the otficer dunng th"-l"it t"n years. The appltcations may be forwarded withln 60

"nr.
;ays of the publicahon of the advertisement in the Employment News:

the last date and without
received
5. The advance copy ot the applications and applications lntegrity
-aIter
Certificate statement showing

Cn ol""i"t, vig,l"n"!' clearance, cadre Clearance and

i"i";l"ir"ip""""fte", if any, imposed on the officer during the last ten years, will not be considered'

6

The officials, who have applied for the above post will not be allowed to withdraw their

applications subsequentlY.

&U."**^'
(Th.

Lianboi)
Under Secretary to the Government ot lndia
Telephone No 23044635

Disglls!!.el:

1. All lrinistries/Departments of the Central Govemment with the request that wide publicity

may be given to the vacancy circular in their Ministry and in their Attached/ Subordinate
Offtes/A-utonomous Organirations/Public Sector Undertakings/Statutory Organizations/
Research lnstitutions and Universities
cOntd 2′

<!-- page 2 -->

-z-

The Secretary, University Grants Commission, Bahadur Shah Zatat Ma.g, New Delhi with

the request that wide publicity may be given to the vacancy circular among all the
Universities in the country.
＾
０

The Chief Secretaries of all State Governments and Administrators of Union Territories with
the request that wide publicity may be given to the vacancy to all the eligible Organizations
under their control.

4.

All sections/Desks in the Ministry of Rural Development

5.

NIC- DoLR, NIC - DoRD and NIC - DoPT; with the request to upload the same on their
respective websites.
Notice Board/ e-Office dashboard/ Circular Folder

<!-- page 3 -->

Annexure-l
Government of lndia
Ministry of Rural Development
Department of Land Resources
NBO Building, Nirman Bhawan, New Delhi-110011

Re-Advertisement No. : A-1 1 01 1/3/2022-Admn.
The Department of Land Resources invites application for the following technical posts as
detailed hereunder:

S
No

Name of the Post and Pay Level

Composite Method
- deputation
(including short
term contract) +
promotion
Officers under the Central/ State Governments/Union Territories/ Public
Autonomous
Sector Undertakings/ Semi-GovernmenU Statutory
Organisations/recognized research institutions or Councils/Agricultural
Universities:

Deputy Commissioner (Watershed Development)
Level-12 of the Pay Matrix I Rs 78,800-2,09,200]

Basic
Eligibility

Method of
Recruitment

Number
of
vacancv
One (01)

or

(a) (i) holding analogous posts on regular basis in parent cadre or
department; or
(ii) with five years' service in the grade rendered after appointment
thereto on a regular basis in the scale of pay of Rs 10000-15200 (prerevised) , or equivalent in the parent cadre/ Department; and
(b) possessing the following educational qualifications and experience

;

Essential:
(i) Master's Degree from a recognised University or equivalent in one
of the following subjects: (a) Agriculture, (b) Forestry, (c) Horticulture
Or Bachelor's Degree in Agricultural Engineering from a Recognised
University or equivalent; and
(ii) Ten years' experience in supervisory capacity of planning and
im plementation of Ag riculture/ForestryAl/astelands Developmenti
Watershed DevelopmenURu ral Development prog ram mes.

Desirable:

(i)
(ii)

2

Doctorate Degree in the subject concerned from a recognized
university or equivalent.

Experience in preparation of briefs, memoranda for

conferences/seminars/meetings, and the like
One (01)
Assistant Commissioner,
Level-11 of the Pay Matrix I Rs 67,700-2,08,700]
Basic
Eligibility

Deputation

(including short
term contract)

Officers under the Central/ State Governments/Union Territories/ Public
Sector Undertakings/ Semi-Government/ Autonomous or Statutory
Organisation:
a. (i) holding analogous posts on regular basis ; or

<!-- page 4 -->

(ii) with five years'service in the grade rendered after appointment ttrereto
on a regular basis in Rs 8000-13500 (pre-revised) , or equivalent in the
parent cadre/ Department, or
(iii) with eight years service in the grade rendered after appointment
thereto on a regular basis in Rs 6500-10500 (pre_ievised) or
equivalent in the parent cadre/ Department, and
possessing the following educational qualifications and experience
.b.
;
Master's Degree from a recognised University or equivalent in one of
the followlng subjecls: (a) Agriculture, (b) Forestry, (c) Horticulture Or
Bachelor's Degree in Agrlcultural Engineering fiom
Recognised
University or equivalent; and
Five years' experience in supervisory capacity of formulation and
processing including collection/ compilation/ analysis of data in respect of
Agriculture/ Forestry/ Wastelands DevelopmenU Watershed DevelopmenU
Rural Development Programmes.

I

a

ll.

(the Departmental officers in the feeder category who are rn the direct rine of
promotion will not be erigibre for consideration for appointment on deputation/

contract

Sim‖ arly deputationists sha‖

not be e‖ glble fOr conslderation for

3- Period of deputation (including short term contract) including period of deputation (including

short{erm contract) in another ex-cadre post held immediately pre-ceOlng this appointment in same
or some other organizationi Department of the Central Government shaii ordinarily not exceed four
years. The maximum age limit for appointment by Deputation (including short teim contract)
shall
not be exceeding 56 years as on the closing date of the receipt oi applica'iion.

4. The officer selected will have the option to draw his pay deputation allowance in accordance

with the Department of personnel & Training O.M. No.2/12l87-Estt (part-lll) dated 29-4-19gg as
amended from time to time or to have his pay fixed in the scale of posts as per rules/orders
on the
subject.

5

The method of recruitment to these posts is elicited in the table below. lt is requested that the
application of the eligible, willing officers and who can be spared immediately may be forwarded in
the prescribed proforma (Annexure) alongwith up{o-date ACR/ APAR Dossier, vitilance clearance,
lntegrity certificate and statement indicating major/minor penalty imposed, if any, on the person
during lasl ten years.

6. lnterested candidate(s) may send their application by speed posu ordinary posu By Hand on
the below mentioned address within 60 days of publication of this advertisement in Employment
Newspaper :

The Under Secretary(Admn.)
Department of Land Resources, Ministry of Rural Development,
NBO Building, G-Wing, Nirman Bhawan, New Delhi-11001 1

7.

The advance copy of the applications and applications received after the last date and
without CR Dossier/ Vigilance Clearance/ integrity certificate will not be considered. The officers who
have applied for the above posts will not be allowed to withdraw their application subsequenfly.

&.];.a,-,
(Th.

Lianboi)
Under Secretary to the Govt. of lndia

,

<!-- page 5 -->

ANNEXURE口

::

CURRiCULUM V:TAE FOR THE POST OF
DEPUTY COMMISSiONER(WDソ ASSISTANT COMM:SSiONER
:N THE DEPARTMENT OF LAND RESOURCES
1.Name and Address (in Block Letters)
2.Date of Birth(in ChttStian era)

3. i) Date of entry into service

ii) Date of retirement under Central
Government Rules
4. Educational Qualifications
S.Whether Education and other qualifications
required for the post are satisfied.
Experience required as
Qualifications

/
Qualifications/ experience possessed by
mentioned in the advertisemenUvacancy the officer
circular
Essential
A)QualriCatiOn

Essential
A)Qual「 iCalon

B) Experience

B) Experience
Desirable

Desirable

A)QualrlCaIOn

A)QualriCaJOn

B) Experience

B) Experience

6. Please state clearly whether in the light of
entries made by you above, you meet the
requisite Essential Qualifications and work
experience of the post.

7. Details of Employment, in chronological order. Enclose a separate sheet duly authenticated by
your signature, if the space below is insufficient.
OfficeЛ nsutu価 On

Post held on

From

*Pay Band and Nature of
Grade PaylPay Duties
detail)
Scale of the post (in
held on regular highlighting

丁o

regular basis

experience
required for the
post applied for

basis

* lmportant: Pay-band and Grade Pay granted under ACP/MACP are personal to the officer and
therefore, should not be mentioned. Only Pay Band and Grade PaylPay scale of the post held on
regular basis to be mentioned. Details of ACP/MACP with present Pay Band and Grade Pay where
such benefits have been drawn by the Candidate may be indicated as below;
Office/lnstlution

Pay, Pay band, and

Grade pay drawn
under ACP/ MACP
scheme

From

To

<!-- page 6 -->

8. Nature of present employment i.e. Ad-hoc

or Temporary or Quasi-Permanent or
Permanent

9. ln case the present employment is held on
deputation/contract basis, please state
a) The date of
b) Period of
initial appointment
appointment on
deputation/contract

c)

Name of

the

parent

office/organization to

which the applicant
belonqs

d) Name of the post
and Pay ofthe post
held in substantive
capacity in the
oarent oroanisation

10. lf any post held on Deputation in the past
by the applicant, date of return from the last
deputation and other details.
11. Additiona! details about present

employment:
Please state whether working under (indicate

the name of your employer against the
relevant column)
a) Central Government
b) State Government
c) Autonomous Organization
d) Government Undertaking
e) Universities
f) Others

12. Please state whether you are working in
the same Department and are in the feeder
grade or feeder to feeder orade
13. Are you in Revised Scale of Pay? lf yes,
give the date from which the revision took place
and also indicate the pre revised scale
14. Total emoluments per month now drawn
Basis Pay in the PB

Grade Pay

Total Emoluments

15.lncasetheapplicantbelongstoanorganizationwhich
Government Pay scales, the latest salary slip issued by the Organization showing the following
details may be enclosed
Basic Pay with Scale of Pay and rate of
Dearness Payl Total Emoluments
increment
interim relief/
other
allowances etc.,
(with break-up
details)
16.A Additional lnformation, if any, relevant to the post you
applied for in support of your suitability for the post.
This among other things may provide information with regard
to (i) additional academic qualifications (ii) professional training
and (iii) work experience over and above prescribed in the
Vacancy Ci rcu larlAdvertisement)

<!-- page 7 -->

16.B Achievements:
The candidates are requested to indicate information with
regard to:

(i) Research publications and reports and special
projects
(ii) Awards/Scholarships/Official Appreciation
(iii) Affiliation with the professionat
bod ies/institutions/societies and
(iv) Patents registered in own name or achieved for the
organization
(v) Any research/innovative measure involving official
recognition
(vi) Any other information.
;

(Note: Enclose a separate sheet if the space is
insufficient)
17. Please state whether you are applying for deputation
(ISTC)/Absorption/Re-employment basis. #
(Officers under Central/State Governments are only eligible

for "Absorption". Candidates of

non-Government
Organizations are eligible only for Short Term Contract)

# (The option of 'STC'/ 'Absorption'/ 'Re-employrnenf are
available only if the vacancy circular specially mentioned
recruitment by "STC" or "Absorption" or "Re-employment,)
18. Whether belongs to SC/ST

I have carefully gone through the vacancy circular/advertisement and I am well aware that
the information furnished in the Curriculum Vitae duly supported by the documents in respect of
Essential QualificationAffork Experience submitted by me will also be assessed by the Selection
Committee at the time of selection for one post. The information/details provided by me are correct
and true to the best of my knowledge and no material fact having a bearing on my selection has
been su ppressed/withheld.

Date:

Signature of the candidate
Address:

<!-- page 8 -->

ANNEXURE-III

Certification by the Employer/Cadre Cont.olting Authority
The information / details provided in the above application by the applicant are true and correct as
per the facts availabre on records. He/she possesses education quarifications and
experience
mentioned in the vacancy Circular. lI selected, he/she will be retieved immediatety.

2.

Also certified that:

i) There is no vigilance or disciptinary case pending/contemptated against

(ii) His/ Her integrity is certified.

(iii) His/ Her CR Dossier in originat is enclosed/photocopies of the ACRS for the last years
5
duly
attested by an officer of the rank of Under Secretary of the Govt. of lndia or above are enclosed.
(iv) No major/minor penatty has been imposed on him during the last .tO years.

Countersigned

(Employer/Cadre Controlling Authority with Seat)
