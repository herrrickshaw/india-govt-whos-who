---
doc_id: "7ccf2e7d6ec9c82f"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/ec7feecbec697e70853b920a0a64b476.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Struck off order w.e.f 04/04/2025 A/N of Smt. Kuljeet Kaur Staff no. 96517 DDG - E of P &T Service Group A Electrical"
date: "2025-04-04"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7a65394e489b2275"
---

<!-- page 1 -->

No.34-03/2023-EW

Government of India
Ministry of Communications
Department of Telecommunications
(A&E Section)
618-A, Mahanagar Doorsanchar Bhawan
New Delhi-110002

Dated:

04.04.2025

OFFICE ORDER
In accordance with

DoT

Letter No. 34-03/2023-EW

dated

12.03.2025,

Smt

Works Service
Kuljeet Kaur (Staff No. 96517), an officer of SAG of P&T Building
), DoT HQ
DDG(BW
Sr
O/o
the
in
cal)
Group ‘A", presently working as DDG (Electri

04.04.2025 (A/N)
stands retired voluntarily from Government Service w.ef
struck off from the
under Rule 43 of CCS (Pension) Rules, 2021. The officer is

strength

of Department

of Telecommunications

Headquarters

(DoT

HQ)

w.e.f

04.04.2025 (AN).
2.

The charge relinquished report may be furnished to all concerned offices.
This issues with the approval of the Competent Authority.

Sir
(Awadhesh Kumar
Director (Electrical)

Tel.No.: 011-23218925
Email: direlect-dot@nic.in
Copy to:

O 00 N HTOT S0

O

PPS to Secretary (T);
Member(S)/Member(T)/Member(F);
Additional Secretary(T)/Advisor(O)/Advisor(T);
CVO, DoT HQs;

Sr DDG(BW), DoT HQ;

DDG(Estt.)/DDG(C&A)/DDG(Accoums)/DDG(IT)/DDG(Pers), DoT HQs;
Admn I-IV/Cash/Pension/Lib./G-l/G-I/PFP/PHP/RTI/Vig.| Sec,DoT HQs
Pay Bill section, DoT

HQs;

ADG(APA)/ADG(Staff)/US(SNG)/AQ(SGT),

DoT HQ;

10.

The Officer concerned;

11.
12.

Dir (EW) for uploading on DoT website.
CCA (Department of Telecom), DoT Building Prasadnagar, New

13.

Delhi- 110005 (ccadelhi@gmail.com);
Order Bundle.

24/—
