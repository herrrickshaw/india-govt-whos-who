---
doc_id: "7bb5c5d6cc5dab74"
source_url: "https://morth.gov.in/backend/documents/uploaded/1790055394_JJSnZrMDfn.pdf"
ministry: "Road Transport and Highways (MoRTH)"
title: "Approved Sanction Ceiling for List of Work Proposals on National Highways entrusted with State/UT Governments to be taken up during FY 2026-27 under Short Term Maintenance Contract (STMC), Special Repair (SR) & Road Safety – reg ::"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "267534c0b63f2e5b"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

Annexure
Total Approved Sanction Ceiling for STMC, SR and Road Safety Works to be taken up in FY 2026-27 on
NHs entrusted to State / UT Governments
A. STMC Works - State / UT – wise Summary of Revised / Additional Sanction Ceiling

Existing Ceiling
S. No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21

State
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Goa
Gujarat
Haryana
Himachal Pradesh
Jharkhand
Karnataka
Kerala
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim

No.

Length (km)

29
1
16
6
1
17
1
2
0
5
4
17
31
0
0
1
0
10
7
4
0

1,000.96
19.50
484.84
227.24
21.00
788.71
24.57
1,086.00
0.00
187.94
115.90
672.50
711.54
0.00
0.00
27.38
0.00
422.36
196.95
180.25
0.00

Additional Ceiling
Cost
(Rs. Cr)
242.27
5.74
67.14
82.05
5.17
111.59
4.16
21.94
0.00
22.69
68.22
123.49
190.05
0.00
0.00
5.00
0.00
92.75
30.61
17.99
0.00

No.

Length (km)

9
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
5
0
0
0

533.84
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
45.60
0.00
0.00
0.00
0.00
0.00
470.45
0.00
0.00
0.00

Cost
(Rs. Cr)
134.58
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
7.15
0.00
0.00
0.00
0.00
0.00
47.23
0.00
0.00
0.00

Total Approved Ceiling
No.

Length (km)

38
1
16
6
1
17
1
2
0
5
4
18
31
0
0
1
0
15
7
4
0

1,534.80
19.50
484.84
227.24
21.00
788.71
24.57
1,086.00
0.00
187.94
115.90
718.10
711.54
0.00
0.00
27.38
0.00
892.81
196.95
180.25
0.00

Cost
(Rs. Cr)
376.85
5.74
67.14
82.05
5.17
111.59
4.16
21.94
0.00
22.69
68.22
130.64
190.05
0.00
0.00
5.00
0.00
139.98
30.61
17.99
0.00
Page 3 of 7

<!-- page 4 -->

Existing Ceiling
S. No.
22
23
24
25
26
27

State
Tamil Nadu
Uttar Pradesh
Uttarakhand
West Bengal
Chhattisgarh
Telangana
Total

No.

Length (km)

1
7
7
9
0
0
176

32.20
190.07
462.07
354.37
0.00
0.00
7,206.33

Cost
(Rs. Cr)
4.65
26.41
21.10
65.65
0.00
0.00
1,208.67

Additional Ceiling
No.

Length (km)

0
3
0
0
0
0
18

0.00
159.86
0.00
0.00
0.00
0.00
1,209.75

Cost
(Rs. Cr)
0.00
30.70
0.00
0.00
0.00
0.00
219.66

Total Approved Ceiling
No.

Length (km)

1
10
7
9
0
0
194

32.20
349.93
462.07
354.37
0.00
0.00
8,416.10

Cost
(Rs. Cr)
4.65
57.11
21.10
65.65
0.00
0.00
1,428.33

Page 4 of 7

<!-- page 5 -->

B. State / UT – wise Additional List of Works for which Sanction Ceiling Approved
1. Andhra Pradesh
STMC Works
Length
(in Km)

TPC (in Rs.
Cr.)

Short term maintenance of Devarapalli -jeelugumilli section of NHPot hole repair, cleaning of shoulders, CD works, Road furniture
516D i.e., from Km 0/0 to 20/500 ,29/630 to 30/500, 31/150 to 33/130, maintenance etc
36/630 to 40/305, 41/105 to 42/135, 43/680 to 44/630, 44/830 to
45/230, 45/380 to 45/580, 45/830 to 46/770, 47/380 to 48/230, 48/830
to 50/030, 56/000 to 56/130 of R&B NH Division, Vijayawada in the State
of Andhra Pradesh For the Year 2026-27

32.73

15.00

42

Km 300/000 to Km 382/080 of Uravakonda-Krishnagiri road

Initial Rectification like filling of Patch Repair work, Clearing of
Shoulders, C&G, Road Markings etc. Routine maintenance

82.08

19.00

3

42

Km 245.580 to Km 299/775 (Madanapalli - Punganuru-Palamaneru
section)

Initial Rectification like filling of Patch Repair work, Clearing of
Shoulders, C&G, Road Markings etc. Routine maintenance

54.20

9.80

4

544D

Km 74/427 to 135/0 of Kolimiguntla – Kaipa section

Initial Rectification like filling of Patch Repair work, Clearing of
Shoulders, C&G, Road Markings etc. Routine maintenance

60.57

9.79

5

544D

Km135/0 to 213/0 of Kaipa - Giddaluru section of NH-544D

Initial Rectification like filling of Patch Repair work, Clearing of
Shoulders, C&G, Road Markings etc. Routine maintenance

78.00

16.45

6

544D

Km 322/840 to Km 336/000, Km 337/000 to Km 343/000, Km 347/000 to Initial Rectification like filling of Patch Repair work, Clearing of
Km 348/0, Km 351/0 to Km 369/000, km 369/000 to Km 373/000, Km
Shoulders, C&G, Road Markings etc. Routine Periodic maintenance
375/000 to Km 380/000 and from Km 381/000 to Km 417/000

83.16

19.69

7

216

Km 170.797 to 220.156 of Losari to Machavaram section

Initial Rectification like filling of Patch Repair work, Clearing of
Shoulders, C&G, Road Markings etc. Routine Periodic maintenance

49.36

10.00

8

216

Gurajanapalle to Pasarlapudi section from Km 46+725 to Km 107+725

61.00

19.85

9

516D

Initial Rectification like filling of Patch Repair work, Clearing of
Shoulders, C&G, Road Markings etc. Routine Periodic maintenance
Short term maintenance of Devarapalli -jeelugumilli section of NHPot hole repair, cleaning of shoulders, CD works, Road furniture
516D i.e., from Km 0/0 to 20/500 ,29/630 to 30/500, 31/150 to 33/130, maintenance etc
36/630 to 40/305, 41/105 to 42/135, 43/680 to 44/630, 44/830 to
45/230, 45/380 to 45/580, 45/830 to 46/770, 47/380 to 48/230, 48/830
to 50/030, 56/000 to 56/130 of R&B NH Division, Vijayawada in the State
of Andhra Pradesh For the Year 2026-27
Total

32.73

15.00

533.84

134.58

S. No.

NH No.

1

516D

2

Strech Name / Chainage

Broad Scope of Works

Page 5 of 7

<!-- page 6 -->

2. Odisha
STMC Works
S. No. NH No.

Broad Scope of Works

Strech Name / Chainage

Length
(in Km)

TPC (in Rs.
Cr.)

1

26

from Km 239/280 to Km 294.280

Clearing and stripping excess soil including removal rank vegetation, embankment slope
cleaning, Road signages ,Restoration of rain cuts, Repair of pot holes, 40mm BC over
carriageway, Prime/Tack Coat, Providing thermoplastic compound including reflectorising
glass beads, providing crash barrier.

55.00

1.55

2

157A

from Ch 0/000 km to 36/100 km

Clearing and stripping excess soil including removal rank vegetation, embankment slope
cleaning, Road signages ,Restoration of rain cuts, Repair of pot holes, 30mm BC over
carriageway, Prime/Tack Coat, Providing thermoplastic compound including reflectorising
glass beeds.

36.00

10.14

3

326

Km 109/660 to Km 162/700, Km 178.400 to Clearing and stripping excess soil including removal rank vegetation, embankment slope
Km 183.700, Km 192/450 to Km 212/700, Km cleaning, Road signages ,Restoration of rain cuts, Repair of pot holes and long stretches
212/700 to Km 253/700, Km 253/700 to Km using WMM, DBM, BC laying over carriageway, Prime/Tack Coat, Road marking, sign
281/700 (Laxmipur to Kakirigumma), Km
boards, RPM and other road safety items
281/700 to Km 311/700

177.59

18.33

4

326

Km 40/00 to Km 68/600, Km 68/600 to Km
109/660

Clearing and stripping excess soil including removal rank vegetation, embankment slope
cleaning, Road signages ,Restoration of rain cuts, Repair of pot holes, 40mm BC over
carriageway, Prime/Tack Coat, Providing thermoplastic compound including reflectorising
glass beads, providing crash barrier.

69.66

13.03

5

326

km 327/700 to km 413/700, km 429/700 to km Clearing and stripping excess soil including removal rank vegetation, embankment slope
475/900
cleaning, Road signages ,Restoration of rain cuts, Repair of pot holes and long stretches
using WMM, DBM, BC laying over carriageway, Prime/Tack Coat, Road marking, sign
boards, RPM and other road safety items

132.20

4.18

470.45

47.23

Total

Page 6 of 7

<!-- page 7 -->

3. Uttar Pradesh
STMC Works
Broad Scope of Works

Strech Name / Chainage

S. No. NH No.

Length
(in Km)

TPC (in Rs.
Cr.)

1

727

Km 0.000 to 18.230

Repair and maintenance

18.23

3.78

2

730

Km 454.000 to 470.900, Km 474.000 to 505.000, Km 537.000 to
603.710

Repair & Maintenance

109.63

22.45

3

730

Km 505.000 to 537.000

Repair & Maintenance

32.00

4.47

159.86

30.70

Length
(in Km)

TPC (in Rs.
Cr.)

45.60

7.15

45.60

7.15

Total

4. Madhya Pradesh
STMC Works
S. No. NH No.
1

543

Strech Name / Chainage

Broad Scope of Works

Short term maintenance Mandla Nainpur from 0 to 25 & 75/6 to 95 Certain Quantities of DBM, BC, WBM / WMM, Micro Surfacing,
km of NH-543 in the State of Madhya Pradesh
Earthen Shoulder, Crash Barrier, Sign Boards, Centre Line Marking,etc
Total

Page 7 of 7
