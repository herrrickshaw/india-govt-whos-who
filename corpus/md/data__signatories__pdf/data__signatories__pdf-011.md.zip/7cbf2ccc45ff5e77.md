---
doc_id: "7cbf2ccc45ff5e77"
source_url: "https://mnre.gov.in/static/uploads/2025/08/5779e5f0046ca6be0163217fc710dcb5.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Gazette notification for BIS extension for Inverters under MNRE Quality Control Order for SPV Systems, Components and Devices Order 2017"
date: "2019-07-04"
pages: 3
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e6ec2384147bc3b7"
---

<!-- page 1 -->

रजिस्ट्री सं० डी० एल०-33004/99 REGD. NO. D. L.-33004/99
Rees
on
Eo) LisiGqa
nee -उ d =
tb
Che Gazette of Sndia
असाधारण
EXTRAORDINARY
भाग व-.-खण्ड 3---उप-खण्ड (1)
PART I—Section 3—Sub-section (ii)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
सं. 2101] नई दिल्‍ली, बुधवार, जुलाई 3, 2019/आषाढ़ 12, 1941
No. 2101] NEW DELHI, WEDNESDAY, JULY 3, 2019/ASHADHA 12, 1941
नवीन और नवीकरणीय ऊर्जा मंत्रालय
अधिसूचना
नई दिल्‍ली, 3 जुलाई, 2019

का.आ. 2320(अ).--यतः केन्द्र सरकार ने अनुसूची में सम्मिलित 6 उत्पादों हेतु दितांक 05 सितम्बर, 2017 के
का.आ. 2920 (ई) के तहत 'सौर प्रकाशवोल्टीय, प्रणालियाँ, उपकरण और घटक सामग्री (अनिवार्य पंजीकरण की आवश्यकता)
आदेश, 2017' जारी किया था जिसके प्रभावी होने की तारीख 5 सितम्बर, 2018 तय की गई। और यतः भारतीय मानक
ब्यूरो (बीआईएस) सहित विभिन्न हितधारकों के साथ विचार-विमर्श के उपरान्त उक्त आदेश के प्रभावी होने की तारीख पहले
अर्थात्‌ 16 अप्रैल, 2018 कर दी गई जिसे का.आ. सं. 1602(ई) के तहत दिनांक 16 अप्रैल, 2018 को अधिसूचित भारत के
राजपत्र में प्रकाशित और 30 जून, 2018 तक प्रभावी आदेश के साथ अनुबद्ध अनुसूची में क्रम सं. 1-3 के उत्पादों के लिए
विनिर्माता द्वारा स्वतः प्रमाणन देने की शर्त पर दिनांक 30 मई, 2018 को भारत के राजपत्र में संशोधित का.आ. 2183(ई) के
तहत प्रकाशित किया गया था।

2. और यतः उद्योग ने आदेश के अनुपालन के लिए और अधिक समय मांगा और यतः संगत हितधारकों के साथ
मामलों पर चर्चा की गयी थी, इसलिए स्व-प्रमाणन को 13.07.2018 को भारत के राजपत्र में प्रकाशित का.आ. 3449 (ई) के
तहत 04 सितम्बर, 2018 तक बढ़ा दिया गया, जिसे बाद में 12 सितम्बर, 2018 को भारत के राजपत्र में प्रकाशित का.आ.
सं. 4787(ई) के तहत आदेश में सूचीबद्ध सभी उत्पादों के लिए 20 सितम्बर, 2018 तक बढ़ा दिया गया, और उसके बाद
संलग्न अनुसूची में प्रत्येक उत्पादों के समक्ष उल्लिखित कार्यान्वयन की तिथियों के साथ सभी उत्पादों के लिए दिनांक
12.10.2018 के का.आ, 5259(ई) के तहत 01 जनवरी, 2019 तक बढ़ाया गया। इसके अलावा, यतः इन्वर्टरों के लिए
सीरीज दिशानिर्देश तैयार किए जा रहे थे, इसलिए इन्वर्टरों (मद 4-5) के लिए स्व-प्रमाण छूट को दिनाँक 04.01.2019 को
भारत के राजपत्र में प्रकाशित का.आ. 46 (ई) के तहत आगे 6 माह तक अर्थात्‌ 30 जून 2019 तक बढ़ाया गया। एसपीवी
मॉड्यूलों के मामले में स्व-प्रमाणन की तारीख को दिनाँक 13.02.2019 को भारत के राजपत्र में प्रकाशित का.आ. 861 (ई) के
तहत दिनाँक 01.01.2019 से 31.03.2019 तक इस शर्त के साथ बढ़ाया गया कि ऐसे विनिर्माताओं/विकासकों ने
31.10.2018 से पूर्व अपने एसपीवी मॉड्यूल परीक्षण प्रयोगशाला को प्रस्तुत कर दिये हैं।

3339 GI/2019 qd)

<!-- page 2 -->

<!-- page 3 -->

2 ‘THE GAZETTE OF INDIA : EXTRAORDINARY [PART I—SEc. 3(ii)]
3. और यतः यह देखते हुए कि इन्वर्टरों के लिए सीरीज दिशानिर्देश अनुमोदत की अंतिम प्रक्रिया में है, ऐसे
विनिर्माताओं के लिए, जिनके पास उक्त आदेश में विनिर्दिष्ट आईएस के अनुरूप अंतरराष्ट्रीय परीक्षण प्रयोगशालाओं से वैध
आईईसी और परीक्षण रिपोर्ट हैं, इत्वर्टरों (मद 4-5) के लिए स्व-प्रमाणन को आदेश के सुचारु कार्यान्वयन के लिए दिनांक

30.06.2019 से 30.09.2019 तक बढ़ाया गया माना जाता है।
[फा. सं. 223/140/2017-आरएंडडी-(गुणवत्ता नियंत्रण)]
डॉ. बी.एस. नेगी, सलाहकार/बैज्ञानिक 'जी', एमएनआरई

MINISTRY OF NEW AND RENEWABLE ENERGY
NOTIFICATION
New Delhi, the 3nd July, 2019

S.0.2320(E).—Whereas the Central Government had issued “Solar Photovoltaics, Systems,
Devices and Components Goods (Requirements for Compulsory Registration) Order, 2017“ vide
§.0. 2920(E) dated Sth September, 2017 for six products included in the Schedule with the date of coming
into force with effect from 5th September, 2018. And whereas, after having discussions with the various
stakeholders including the Bureau of Indian Standards (BIS), the date of coming into force of the said Order
was advanced to 16th April, 2018 on the condition of self-certification by manufacturers for products at
Sl. No. 1-3 in the schedule annexed to the order applicable till 30th June, 2018 published in Gazette of India
notified on 16th April, 2018 vide $.O. 1602(E), which was revised vide S.O. 2183(E) published in Gazette
of India on 30.05.2018.

2. And whereas, the industry had sought more time for compliance to the order and whereas the
issues involved were discussed with related stakeholders, the self-certification was extended to
4th September, 2018 vide S.O. 3449(E) published in Gazette of India on 13.07.2018, which was further
extended to 20th September 2018 for all products listed in the order vide $.0. No. 4787(E) published in
Gazette of India on 12th September 2018, and further to Ist January 2019 vide S.O. 5259(E) dated
12.10.2018 for all items with dates of implementation indicated against each product in the schedule
annexed. Further, whereas the series guidelines for inverters were in the process of preparation, the self-
certification relaxation for inverters (items 4-5) was further extended by six months i.e. up to 30th June 2019
vide S.O. 46(E) published in Gazette of India on 4.01.2019. In the case of SPV Module, the date of self-
certification was extended from 1.01.2019 to 31.03.2019 vide S.O. No. 861(E) published in Gazette of India
on 13.02.2019 subject to the condition that such manufacturers/developers had submitted their SPV Modules
to test laboratories before 31.10.2018.

3. And whereas, considering the series guidelines for inverters are in the process of finalization
for approval, the self- certification for inverters (items 4-5) for those manufacturers who have valid IEC and
test reports from international test labs corresponding to IS specified in the said order stands extended from
30.6.2019 to 30.9.2019 for smooth implementation of the order.

[F. No. 223/140/2017-R&D (Quality Control)]
Dr. B. S. NEGI, Adviser/Scientist G, MNRE

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-1 10064

and Published by the Controller of Publications, Delhi-110054. a i
ALOK Digitally signed
by ALOK KUMAR
KUMAR Date: 2019.07.04
10:37:32 +05'30'
