---
doc_id: "7c6dac0a4a3af3d6"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/0972_Advt_corrigendum_16072026.pdf"
ministry: "Department of Space"
title: "Corrigendum: ADVT-No.VSSC/P/ADVT/MME/26/2026 Dated:15.07.2026      40.64 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "78aa341396e82f77"
---

<!-- page 1 -->

भभारत सरकभार/GOVERNMENT OF INDIA
अअंतररक्ष वविभभाग/DEPARTMENT OF SPACE
वविक्रम सभारभाभभाई अअंतररक्ष ककद/VIKRAM SARABHAI SPACE CENTRE
वतरुविनअंतपपुरम/THIRUVANANTHAPURAM – 695 022
No.VSSC/P/ADVT/MME/26/2026

15.07.2026

CORRIGENDUM TO ADVT No. VSSC/P/ADVT/MME/26/2026 DT. 10.06.2026

क्रम सअं.
Sl. No.

01

वनवविदभा सअं.
Tender No.

VSSC/PURCHASE
UNIT V [MME
PURCHASE]/
VS2026000972 01
[ददो भभाग / PT TWO PART]

Clause no
Compliance Matrix –
Technical Terms (Annexure)
– Sl no.1 Standard to
comply

विरर न/ Description

मभातभा वनवविदभा शपुल्क
Qty. Tender
Fee

AA7075 T7351 प्ललेटटों कभा वनमभारर एविअं आपपूवतर

65700

वक.गभा/

लभागपूनहहीं /

Manufacture and Supply of AA7075
T7351 Plates.

65700
Kg.

NA

In place of

To be read as

The AA7075 T7351 plates
shall conform to the
specification AMS 4050.

The AA7075 T7351 plates shall
conform to the specification
AMS 4078.

All other terms and conditions of the original tender notice shall remain
unchanged.

हस्तभाक्षररत/Sd/प्रधभान, क्रय एविअं भअंडभार / Head, Purchase & Stores
