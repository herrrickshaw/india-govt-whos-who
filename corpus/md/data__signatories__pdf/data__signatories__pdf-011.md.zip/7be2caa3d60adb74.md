---
doc_id: "7be2caa3d60adb74"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/6edc243105e298c200bb4c013acb87c9.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Amendment of MDS Course Regulations- Automatic Lowering of Qualifying Percentile"
date: "2018-03-15"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "477942c7e8c0b5d1"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
PUBLIC NOTICE
General public is hereby informed that as per the Clause 7 of Dental
Council
of India, Master of Dental Surgery Course Regulations,
~
candidate has to secure minimum

2017 the

so" percentle for General category, 40th

percentile for Schedule Castes/Schedule Tribes/Other Backward Classes and
45th percentile for person with Locomotory disablity of lower limbs in NEET
for admission to post-graduate course held in the particular academic year. This
Ministry, in consultation with Dental Council of India (DCI) and Dte.GHS, has
approved the following amendment for substituting the existing second proviso
in the said Clause in order to ensure that all the seats in MDS courses are filled
up in the Dental Colleges across the country:

"Provided further that when the number of qualifying candidates in the
respective categories on the basis of the above mentioned percentile
are less than three times the number of vacancies, the cut-off percentile
will be automatically lowered in such a manner that the number of
eligible candidates shall be minimum three times the number of seats in
each respective category".

, .
