---
doc_id: "78fe3a5e2dd6c0fc"
source_url: "https://doj.gov.in/static/uploads/2025/09/050b412b38717a6336f329ce5de58079.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Indra Prasanna Mukerji, Judge, Calcutta High Court as Chief Justice of Meghalaya High Court (21.09.2024)"
date: "2024-09-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cca8f81f697fcce8"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K-13033/01/2024-USJI
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, dated 21st September, 2024.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint Shri Justice Indra Prasanna
Mukeiji, Judge of the Calcutta High Court, to be Chief Justice of the Meghalaya
High Court, with effect from the date he assumes charge of his office

yi 1 1A
(Jagan th Srinivasan)
Joint Secretary to the Government of India
Tele: 2338 3037

To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

No. K.13033/01/2024-USJI

Dated: 21.09.2024.

Copy to:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.

Shri Justice Indra Prasanna Mukerji, Judge of the Calcutta High Court
through the Registrar General, Calcutta High Court, Kolkata.
The Secretary to the Governor, Meghalaya, Shillong.
The Secretary to Governor, West Bengal, Kolkata.
The Secretary to the Chief Minister, Meghalaya, Shillong.
The Secretary to Chief Minister, West Bengal, Kolkata.
The Secretary to the Acting Chief Justice, Meghalaya High Court,
Shillong.
The Secretary to the Chief Justice, Calcutta High Court, Kolkata.
The Chief Secretary, Government of Meghalaya, Shillong.
The Chief Secretary, Government of West Bengal, Kolkata.
The Registrar General, Meghalaya High Court, Shillong.
The Registrar General, Calcutta High Court, Kolkata
The Accountant General, Meghalaya, Shillong.
The Accountant General, West Bengal, Kolkata.
The President's Secretariat, (CA.II Section), Rashtrapati Bhawan,
New Delhi.
PS to Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
Registrar (Conf.), o/o Chief Justice of India, 7 Krishna Menon Marg,
New Delhi.
PS to MLJ/ PS to MoS (L&J) PPS to Secretary (Justice).
Technical Director, MC, Department of Justice, with a request to
upload the Notification on the website of the Department
(www.doj.gov.in).

cl‘
(Prem hand)
Under Secretary (Appointments-I)
Tele: 011-23382978
