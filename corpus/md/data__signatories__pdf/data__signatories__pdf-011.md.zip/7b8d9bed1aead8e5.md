---
doc_id: "7b8d9bed1aead8e5"
source_url: "https://moef.gov.in/uploads/2021/08/doon-valley-amendment.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "S.O. 94(E) [06.01.2020] दून घाटी के चारों ओर पर्यावरण-संवेदनशील क्षेत्र घोषित करने में अंतिम संशोधन"
date: "2021-08"
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "c420fed972bf584a"
---

<!-- page 1 -->

रिजी सं. डी.
डी.एल.
एल.- 33004/99

REGD. NO. D. L.L.-33004/99

xxxGIDHxxx
सी.जी.-डी.एल.-अ.-10012020-215285
xxxGIDExxx
CG-DL-E-10012020-215285

असाधारण

EXTRAORDINARY
भाग II—खड 3 उपउप-खड (ii)
PART II—Section 3—Sub-section (ii)

ािधकार से कािशत

PUBLISHED BY AUTHORITY

नई दली, सोमवार
सोमवार,
वार, जनवरी 6, 2020
2020/
20/पौष 16, 1941

सं. 86]
No. 86]

NEW DELHI, MONDAY, JANUARY 6, 2020/PAUSHA 16, 1941

पयावरण, वन और जलवायु परवतन मंालय

अिधसूचना
नई दली, 6 जनवरी, 2020

का.
का.आ. 94(
94(अ).— अिधसूचना संया का.आ. 102 (अ), तारीख 1 फरवरी, 1989 (इसम इसके पात उ

अिधसूचना कहा गया है) को, तकालीन पयावरण और वन मंालय ने तकालीन उर देश (अब उराखंड) म दून
घाटी म, उर म मसूरी #रज़ से िघरा, उर-पूव म िहमालयी पवत%ेणी, दि'ण-पिम म िशवािलक %ेिणय( )ारा,
दि'ण-पूव म गंगा नदी और उर-पिम म यमुना नदी म उ*ोग(, खनन काय- और अ/य िवकासामक 0याकलाप(
पर, 'े म पयावरणीय भाव को 2यान म रखते 3ए ितबंध लगा दया था;

और, उ अिधसूचना के संबंध म कितपय दशा-िनद7श अिधसूचना संया का.आ. 943 (अ), तारीख 4 जुलाई,

2005 और का.आ. 2125 (अ), तारीख 13 दसंबर, 2007 )ारा जारी कए गए ह:;

और, इस बीच, क;ीय दूषण िनयंण बोड (सीपीसीबी) ने प सं. बी-29012/ईएसएस(सीपीए)/2015-16,

तारीख 7 माच, 2016 को उ*ोग( के वग>करण पर भी दशा-िनद7श जारी कए ह:;

और, उराखंड सरकार ने प सं. 122/डी-3-19-13(04)/2018, तारीख 10 अैल, 2019 को उ

अिधसूचना म संशोधन के िलए पयावरण, वन और जलवायु प#रवतन मंालय से अनुरोध कया;
117 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

और, पयावरण, वन और जलवायु प#रवतन मंालय ने उराखंड सरकार के अनुरोध क@ जांच क@ है;
और, उपयु संशोधन( और दशा-िनद7श( को समेकत करने और उ िनद7श( और संशोधन( के आधार पर शत-

का सामंजCय करने क@ भी आवEयकता है;

अतः, अब, के/;ीय सरकार पयावरण (संर'ण) िनयम, 1986 के िनयम 5 के उपिनयम (4) के साथ प#ठत
पयावरण (संर'ण) अिधिनयम, 1986 (1986 का 29) क@ उपधारा (1), के साथ धारा 3 क@ उपधारा (2) के खंड (v)
)ारा द शिय( का योग करते 3ए, उ अिधसूचना म िनHिलिखत संशोधन करती ह: और उपरो मानदंड म िमल
कर बनने वाली दून घाटी म आने वाले 0याकलाप( के संबंध म िनHिलिखत शतI अिधरोिपत कर, अथात्:अिधसूचना म, खंड (i), (ii), (iii), (iv), (v) और उपाबंध, के िलए िनHिलिखत को ितCथािपत कया
जाएगा, अथात:् उ

“ (i) औोिगक इकाइय के अव थान/ थल – क;ीय दूषण िनयंण बोड (सीपीसीबी) )ारा प सं. बी29012/ईएसएस(सीपीए)/2015-16, तारीख 7 माच, 2016 को धारा 18 (1) (बी) के तहत जल (दूषण क@ रोकथाम
और

िनयंण)

अिधिनयम,

1974

और

वायु

(दूषण

क@

रोकथाम

और

िनयंण)

अिधिनयम,

1981

लाल/नारं गी/हरा/सफ़ेद %ेिणय( के अंतगत औ*ोिगक 'े( के वग>करण के सांमजCय के संबंध म जारी कए गए संशोिधत

-

-

दशा िनद7श( के अनुसार होना चािहए और सीपीसीबी और पयावरण, वन और जलवायु प#रवतन मंालय )ारा समय
समय पर संशोिधत कया जा सकता है।

(ii) खननखनन- कसी भी खनन 0याकलाप को शुV करने से पहले संघ पयावरण, वन और जलवायु प#रवतन मंालय क@
मंजूरी अिभाX करनी होगी।

(iii) पयटन- पयटन िवकास योजना (टीडीपी) के अनुसार, राZय पयटन िवभाग )ारा तैयार कया जाना चािहए और संघ
पयावरण, वन और जलवायु प#रवतन मंालय )ारा यथािनयम अनुमोदत कया जाना चािहए।
(iv) चराईचराई- राZय सरकार )ारा तैयार क@ जाने वाली योजना के अनुसार और संघ पयावरण, वन और जलवायु प#रवतन
मंालय )ारा यथािनयम अनुमोदत कया जाना चािहए।
(v) भूिम उपयोगउपयोग- संपूण 'े के िवकास और भूिम उपयोग योजना के महायोजना के अनुसार, राZय सरकार )ारा तैयार
कया जाना है और संघ पयावरण, वन और जलवायु प#रवतन मंालय )ारा अनुमोदत कया जाएगा।

टपण:

क)

दून घाटी म उ*ोग( क@ लाल वग- क@ अनुमित नह[ होगी;

ख)

दून घाटी म \धन जलाने वाले उ*ोग( क@ कु ल संया को सभी ]ोत( से सफर डाइऑ`साइड के 8 टन
ित दन तक सीिमत कया जाएगा। (यह 1% सफर के साथ ित दन 400 टन कोयले के समान है।);

(
(

ग

मानदंड पर और स'म ािधकारी क@ पूव Cवीकृित के साथ होगी;

( )

औ*ोिगक 'े( के Cथल िनधा#रत

घ

नारंगी वग के उ*ोग, जो अब उ*ोग( क@ लाल वग- म ह:, को जारी रखा जाएगा, तथािप,
कसी िवCतार क@ अनुमित नह[ दान क@ जाएगी।”।

( )

िव*मान

[फा. सं. 25/6/2012-ईएसजेड]
डॉ. सतीश च/; गढ़कोटी, वैcािनक ‘जी’

<!-- page 3 -->

¹भाग IIµखड 3(ii)º

टपण: मूल अिधसूचना भारत के

भारत का राजप : असाधारण

3

, असाधारण, भाग II, धारा 3, उप-धारा (ii), संया का.आ. 102 (अ),
तारीख 1 फरवरी, 1989 को कािशत क@ गई थी।
राजप म

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 6th January, 2020
S.O. 94(E).—WHEREAS, vide notification number S.O. 102(E), dated the 1st February, 1989
(hereinafter referred as the said notification) the erstwhile Ministry of Environment and Forests imposed restriction
on location of industries, mining operations and other developmental activities in the Doon Valley, bounded on the
North by Mussoorie ridge, in the North-East by Lesser Himalayan ranges, on the South-West by Shivalik ranges,
river Ganga in the South-East and river Yamuna in the North-West in erstwhile Uttar Pradesh (now Uttarakhand),
keeping in view the environmental impact in the region;
AND WHEREAS, in respect of the said notification certain directions have been issued vide notification
number S.O. 943 (E), dated the 4th July, 2005 and S.O. 2125 (E), dated the 13th December, 2007;
AND WHEREAS, in the meantime the Central Pollution Control Board (CPCB) has also issued directions
on the categorisation of industries vide letter No. B-29012/ ESS(CPA)/2015-16, dated the 7th March, 2016;
AND WHEREAS, the Government of Uttarakhand vide letter No. 122/D-3-19-13(04)/2018, dated the 10th
April, 2019 requested the Ministry of Environment, Forest and Climate Change for amendment in the said
notification;
AND WHEREAS, the Ministry of Environment, Forest and Climate Change has examined the request of
the Government of Uttarakhand;
AND WHEREAS, there is a need to consolidate the amendments and the directions as above and also to
harmonise the conditions based on the said directions and amendments;
NOW THEREFORE, in exercise of the powers conferred by sub-section (1) and clause (v) of sub-section
(2) of section 3 of the Environment (Protection) Act, 1986 read with sub-rule (4) of Rule 5 of the Environment
(Protection) Rules, 1986, the Central Government hereby makes the following amendments in the said notification
and impose following conditions in respect of the activities falling the Doon Valley comprising of the above criteria,
namely: In the said notification, for clauses (i), (ii), (iii), (iv), (v) and ANNEXURE, the following shall be
substituted, namely:“(i) Location/siting of industrial units – It has to be as per modified directions issued by the Central Pollution
Control Board (CPCB) vide letter No. B-29012/ESS(CPA)/2015-16, dated the 7th March, 2016 under section
18(1)(b) of the Water (Prevention and Control of Pollution) Act, 1974 and the Air (Prevention and Control of
Pollution) Act, 1981 regarding harmonization of classification of industrial sectors under red/orange/green/white
categories and as may be amended from time to time by the CPCB and the Ministry of Environment, Forest and
Climate Change.
(ii) Mining – Approval of the Union Ministry of Environment, Forest and Climate Change must be obtained before
starting any mining activity.
(iii) Tourism – It should as per Tourism Development Plan (TDP), to be prepared by the State Department of
Tourism and duly approved by the Union Ministry of Environment, Forest and Climate Change.

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(iv) Grazing – As per the plan to be prepared by the State Government and duly approved by the Union Ministry of
Environment, Forest and Climate Change.
(v) Land Use – As per Master Plan of development and Land Use Plan of the entire area, to be prepared by the State
Government and approved by the Union Ministry of Environment, Forest and Climate Change.
Note:
(a)

Red categories of industries shall not be permitted in Doon Valley;

(b)

The total number of fuel burning industries that shall be permitted in the Doon Valley shall be limited
by 8 tonnes per day of Sulphur Dioxide from all sources. (This corresponds to 400 tonnes per day Coal
with 1 % Sulphur);

(c)

Siting of Industrial areas shall be based on the prescribed criterion and with prior approval of
Competent Authority;

(d)

Existing orange categories industries, which are now in the red categories of industries shall be
continued, however, no expansion shall be allowed.”.
[F. No. 25/6/2012-ESZ]
DR. SATISH C. GARKOTI, Scientist ‘G’

Note: The principal notification was published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section
(ii) vide number S.O. 102 (E), dated the 1st February,1989.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed by ALOK KUMAR

ALOK KUMAR

Date: 2020.01.10 11:25:38 +05'30'
