---
doc_id: "7dbd5ac9d9f41ff4"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/b8c3d310112b9f59259496ad1ba0257f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & Posting of officers in SAG of ITS Group A - reg"
date: "2025-02-04"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8f516909a0b09501"
---

<!-- page 1 -->

12-3/2024-5TG-1

1/3204383/2024

No. 12-3/2024-STG-I

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi

ORDER
OF ICE

Dated the 22" August, 2024

Subject: - Transfer & Posting of officers in SAG of ITS Group ‘A’ - reg.

posting

Approval of the competent authority is hereby conveyed for transfer &
of the following officers in the grade of SAG of ITS Group ‘A, with

immediate effect:
w No w No

[Name (Shri/Smt.)

[Place of Posting

[Posting on transfer

iB

Amit Saxena

MTNL

BSNL

w5

2.

follow.

The charge report may be furnished to all concerned. Hindi version will

Signed by Bijender Singh
088: 22-08-2024 16:22:22
(Bijender Singh)
Under Secretary 10 the Government of India
Tele 011-2303 6282
Email: bijender.s83@gov.in
Copy to:
1. Chairman, DCC/Member(S)/Member(T)/Member(F)/DG(Telecom), DoT;

2. AS(T)/ Administrator USoF / All Advisors, 001;
3. CMD, BSNL COJ cMb,MTNL
€0.3
4. CVO, DoT HQs;
5. All Sr. DDGs/DDGs DoT HQs;
6. Admn.|-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.| Sec., DoT HQs;

7. Pay Bill Section, DoT HQs;
8. US (SNG)/ADG (APAR)/AD (STG-1)/AAO (STG-l), DoT HQs;
9. The Officer concerned;
10. Official Language Section, DoT for Hindi version of the order;

11. Order Bundle/PA to US(SGT) for uploading this order on DoT website.
