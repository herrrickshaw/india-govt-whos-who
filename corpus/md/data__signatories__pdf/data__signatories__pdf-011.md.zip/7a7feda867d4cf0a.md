---
doc_id: "7a7feda867d4cf0a"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2026/10/d1977a962457f4a6caefb24c1969da9f.pdf"
ministry: "Tourism"
title: "Inviting comments of stakeholders for amendments of recruitment Rules for the post of Junior Translation Officer in India Tourism Offices, Ministry of Tourism"
date: "2026-10-14"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "23dafc0df6a0a210"
---

<!-- page 1 -->

A-1201 8 101 12021-Adnr n.I

Government of lndia
Ministry of Tourism
(Admin. l)

I'Tl Building,
l- I'arliamcnt Strcet,
New l)elhi-I10001
l)nrcd: I {.10.2(}26
Itr.
1-he Regional Director/Deputy Director General

India l'ourism Otfices

Delhi/Mumbai/Kolkata/Chennai/Guwahati
Subject: - Inviting comments ofstakeholders fbr amendments of recruitment Rules lor the post
of Junior Translation Officer in lndia Tourism Offices. Ministry of Tourism - regarding.
Sir.

Please find enclosed herewith duly approved revised draft amendments to the
Recruitment Rules tbr the post of Junior Translation OfTicer in India Tourisrn Offices for
circulation among all the stakeholders for their comments. Last date for inviting the commenls
of stakeholders shall be one nronth from the date of issue of letter for inviting the comments.
All the comments received fiorn the stakeholders shall be lorwarded to Under Secretary.
Admin I. Ministry of Tourism on email pt4ttrllErqglLtlltsq,rl,g('!-!!1 or l!l!!!!ur!l1!4it:. iq within
one rveek atler receipt ofthe comments.

2.

This shall be circulated on priority.
Yours taith

v,.

)

(l'rrveen Kunrar Sin
Under Secretar)'to thc Govt. of India
Copy to:-

l. I'f Division for uploaded on E-office and website of the Ministry.

.\o,lD

*

<!-- page 2 -->

(To Be Published, in Part ll, Section 3, Sub-Section (i) ofthe Gazette oflndia)
Government of India
Ministry of Tourism

NOTIFICATION
New Delhi, dated ...October, 2026
G.S.R ---- in exercise of the porvers cont'erred by the proviso to article 309 ofthe constitulion,
and in supersession of the Ministry of Tourisrn (Department of Tourism) Tourist olfices of
(lovernnrent of India. Jr. Hindi Translator Recruitment Rulcs l990.except as respects things
done or ornitted &r be dorre befbre such supersession. the President hereby rnakes the follon,ing
rules. regulating the method ol'recruitment to the post ofJunior Translation officer, in India
'l'ourism otfices in
Ministry' of Tourisrn. namely: -

l.

Shon title and corrmencement- (l) these rules rna1, be called Ministry of 1-ourism.
Covernment o['lndia 'lourisrn ol]lces. Junior'l'ranslation otllcer [lecruilment I{ules. 2026.

(2) 'l'hel shall come into tbrce on the date of their publication in the Ofllcial Gazette.

2.

Number ol'posts. classillcation and level in pay rratrix. - -l'he number ol'post. its
classitlcation and level in the pay matrix attached thereto shall be as specified in colurnns (2)
to (4) ofthe Schedule annexed to these rules.

3. Method of recruitment, age-limit and qualification. elc. - 'fhe method of recruitment
age- limit, qualifications and other matters relating thereto shall be as specified in columns(S)
to ( l4) ofthe aforesaid Schedule.

4.

Disqualificalion. - No person
(a) Who has entered into or contracted a marriage with a person having a spouse living,

or
(b) who. having a spouse living, has entered in contracted a marriagc rvilh any person.
Shall be eligible for appoinlment to the said post:
Provided that the Ccntral Government rray. ifsatisfied that such rnarriage is permissible
under thc personal law applicable to such person and the other party to marriage and
that there are olher grounds tbr so doing. exempt any person lrom the operation ol this
rule.

5. Power to relax.- Where the Central Government is of the opinion that it is necessary or
expcdient so lo do it rray by order for reasons to be recorded in writing, and in consultation
rvith Union Public Service Commission relax any of the provisions of these rules with respect
to any class or category olpersons.

6. Savings. - Nothing in these rules shall aflect reservation. relaxation ot'age linrit and other
concessiorrs required to be provided for the Schedule Castes. lhc Schedule Tribes. Ex.
Servicemen. Other Backward Classcs and othcr special categories o1'persotrs in accordancc
rvith the orders issucd bv the Ccntral Covernnrent liorn time to tinte in this regard.

q""J/

<!-- page 3 -->

Schcrlulc

Nanlc of thr posl.

Number 0f post. Classification.

Pa)'
and

l'at.

l
General Central level-6.

l

I

J

unior

Serv ice

* S u b.iect

variation.
dependent
rvork load

5

l.r

* 4(2026)

l-ranslation officer

Iland Whether
Grade selcction post or
non-selection
post.
Not Applicable

pay matrix Rs.

to Group 'B' Non- 35400Gazetted,
otl Non-Ministerial

I12400 Grade
Pay

Rs.4200

ol
.\gc linrit for dircct lltlucationll and Whethcr agc and I'criod ol Method
probation, il recru itment
other
rccru its.
cd ucational
qualilication
qualilications
anl
n'hethor by
prcscribed
requiretl
direct
for direct recruits
recruitment 0r
for tlirctt
rec rrr its.
rvill applv in thc
by
promotion or by
casc of
promotcs
dcpu tlltion

/absorption and

(,

7

j0 l ears

Master's degree Not applicablc

(Relaxable for
Governrnent

of a recognized
University in
scfvants upro 5 Hindi with English
years in accordance as a compulsory or
rvith the instructions elective subject or
or orders issued by as the medium of
the
Central examination at the
Covernment.)
degree level
Notc:
'l

oR

lt

thc
Ilerccntage of
thc vacancies to
bc fillcd by
l'arious nrethods

I
21'ears

l0
[)ircct recrLritn]elrt

Note:

Notc:-

For

direct "Vacancies
recruitment
caused

by the

t'or successlul incumbent being
completion ol away on
the

probation, a
mandatory

deputation or long
illness or study

leave or under

other
training of at circumslance for

induction

he crucial date firr Mastcr's degree

dcternrining the of a recognized

age-limit shall be as University in
specified b1' the tinglish rvith llindi
SSC.
as a compu lsory or
elective subject or
as the medium of
examination at the
degrec level

ott

Master's degfee

least

rveeks

two duration of one
year or more may

duration as be

prescribed by filled
on
the Ministry deputation basis
lrom officers
of Tourisrn.
of Central
Covernment:-

(a)

Holding
analogor.rs posts
on regular basis in

of recognized

k-'+

<!-- page 4 -->

in an

he parent cad

ubicct other tha

epartmcnt; and

Un iversity

indi or Iinglish

b) Posscssing th

ualiflcation an

wirh Ilindi
diurr and
English
as

perience

ribcd fb
irecl recrLr

nr pLrlsory'

c'lective sLrb.jcct

under col.7"

r as rned iLrnr ol'a
nr ination at t
egrec levcl;
R

Master's degree o
recogn r

Univcrsi(v in an
b ject other th
indi or English
ith English nre
Lrnr and ll intli as

mpulsory or
lective subject o
rr ed iu nr

o

cxarn inalion

a

e degree level;
R

aster's degree o
recognrze

niversity in an
b.icct other th
indi or I-inglish

ith Hindi an
nglish as
ompu

lsor1, o

lective subjects o
ither ol- the nv

a mcdiurn o
xanlrnatron an
e othel as

ompulsory o
lective subject a
egree level;

ND
ecognized Dipl
a or Ccrl illc
tn

rse

fronr
rarrslation
Hindi to English &
ice versa or tw

c\

tctt

\,

*

<!-- page 5 -->

f translation r,' o

lrom H indi

English and vi
versa in Central o
State Governmcn
ffices or Unio
crfltoncs
drn in istration.
inc lud ing

overnnrcnt of
Ind ia U ndertakin

In
case ol If a departmcntal Circunrstanccs in
rvhich
I Inion
rtcruitmcnt by Promotion
pronrotion/
service
Committcc cxists. I'ublic
rvhat is its (lonrnrissiou is trr
l)eputati()n
bc consultetl in
/rbsorption,
composition?
gradcs I'ronr rvhich
p ro nr o t io n/d e Jr u tat

nra king

rccruitnrcnt.

ion/:rbsurption ttr
he rnarlr.

ll

tl

li

Not applicable

Departrnental

Consultation rvith

Promotion
Conrmittee

U PSC not necessary

lbr

confirmation

(l)

Regional
Director/Deputy

Director General

of

the
concerned Region

- Chairperson

(2)

Assislant
Director Cencral
Assistant

or

Director of the

concerned

region - Menrber

(3)

Assistant

Director dealing
with

Adrrinistration in

the

Region

- Mernber

lA-t20181011202{-Ad

m n.l I

\

A

(Praveen Kumar Singh)
Undcr Secretar.v to the Govt. of India

({'
