---
doc_id: "7afbd36f74acb12e"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/cd3f5049bef5b7e111ce1e30b13f9ddf.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "WG1_List of participants of 2nd meeting held on 07.08.2024"
date: "2024-08-07"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d50b4e1a35fc1450"
---

<!-- page 1 -->

List of Participants of 2nd Meeting of Working Group-1 held on
07.08.2024

Sl No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.

Name
Shri. Viresh Goel
(Chairman)
Shri. Ankur
Shri. Anuresh Sharma
Shri. Ashok Kumar Bahal
Shri. Atul Jain
Ms. Ashwini V.N.
Shri. Avneesh Kumar
Shri. AVS Rao
Shri. Bharat Bhatia
Shri. Bimal Chopra
Shri. Chandra Murthy
Shri. Davender Singh Rawat
Ms. Deepali Sharma
Ms Dimple Singh
Dr. Sendhil Kumar
Ms. Harsha Ohri
Shri. Khagendra Singh
Shri. Kshem Kapoor
Shri. M.K. Pattanaik
Shri. Munish Gaur
Shri. Murali Medudula
Ms.Poonam Singh
Shri. PSM Tripathi
Shri. Punit Rathore
Shri. R.K. Nagaich
Shri. R.K. Sahu
Shri. R.R. Prasad
Shri. Rahul Mahna
Shri. Rajeev Dwivedi
Shri. Rajeev Kumar
Shri. Rajesh Rana
Shri. Rajith Ali
Shri. Ramji Singh
Shri. Diwakar
Shri. Sanjeet Rai
Ms.Shalini
Shri. Srinivas
Shri. Suman Thakur
Shri. Suneel Yadav
Shri. Suresh Kumar
Karthikeyan

Organization
WPC Wing, DoT
GMRT-NCRA
MTROA
MTROA
BIF
Harman International Pvt. Ltd.
WPC Wing, DoT
Aryaomnitalk HQ
IAFI
RJIL
IISc, Bangalore
WPC Wing, DoT
MIB
WPC Wing, DoT
Ericsson, 5GIF
WPC Wing, DoT
WPC Wing, DoT
COAI
WPC Wing, DoT
Tata Communications
RJIL
WPC Wing, DoT
Qualcomm
WMO, DoT
BECIL/MIB
G&GS-III, Ministry of Defence
JCES
Doordarshan
SHURE
SIA-India
MoPSW
Samsung
NCRA-GMRT
WPC Wing, DoT
CEAMA
Susan Future Technologies Ltd.

<!-- page 2 -->

41.
42.
43.
44.
45.
46.
47.
48.
49.

Shri. Suresh Madan
Ms.Swati Rawat
Shri. T. Srinivasa Rao
Shri. Umesh Kumar
Shri. Uttam Poddar
Shri. Vinay Shrivastava
Vishal Singh Yadav
Preetam Meena
Raju Dey

CEAMA
RJIL
WPC Wing, DoT
AAI
AD IT Tripura
Reliance Jio
WMO, DoT
WPC Wing, DoT
WMO, DoT
