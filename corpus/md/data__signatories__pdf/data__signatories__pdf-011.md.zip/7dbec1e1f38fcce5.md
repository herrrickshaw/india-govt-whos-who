---
doc_id: "7dbec1e1f38fcce5"
source_url: "https://mines.gov.in/admin/download/6ac36757666381791190871.pdf"
ministry: "Mines (MoM)"
title: "The Offshore Areas Mineral (Auction) Amendment Rules, 2026. (521.12 KB)"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "52409973cfd24025"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-24092026-276482
xxxGIDHxxx
CG-DL-E-24092026-276482
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 772]
No. 772]

नई दिल्ली, बृहस्ट्पजतिार, जसतम्बर 24, 2026/आज‍िन 2, 1948
NEW DELHI, THURSDAY, SEPTEMBER 24, 2026/ASVINA 2, 1948

खान मंत्रालय
अजधसूचना
नई दिल्ली, 24 जसतंबर, 2026
सा.का.जन. 842(अ).— कें द्रीय सरकार, अपतट क्षेत्र खजनि (जिकास और जिजनयमन) अजधजनयम, 2002 (2003
का 17) की धारा 35 द्वारा प्रित्त िजियों का प्रयोग करते हुए, अपतट क्षेत्र खजनि (नीलामी) जनयम, 2024 का और संिोधन
करने के जलए, जनम्नजलजखत जनयम बनाती है, अर्ाात:् —
1. संजक्षप्त नाम और प्रारं भ. — (1) इन जनयमों का संजक्षप्त नाम अपतट क्षेत्र खजनि (नीलामी) संिोधन जनयम, 2026 है।
(2) ये रािपत्र में उनके प्रकािन की तारीख को प्रिृत्त होंगे।
2. अपतट क्षेत्र खजनि (नीलामी) जनयम, 2024 के जनयम 9 में,—
(क) उपजनयम (8) के , पहले परंतुक में, “तीन” िब्ि के स्ट्र्ान पर, “िो” िब्ि रखा िाएगा;
(ख) उपजनयम (9) में, “तीन” िब्ि के स्ट्र्ान पर, “िो” िब्ि रखा िाएगा;

7327 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(ग) उपजनयम (10) में, “तीन” िब्ि के स्ट्र्ान पर, “िो” िब्ि रखा िाएगा;
(घ) उपजनयम (12) के , िूसरे परं तुक में “तीन” िब्ि के स्ट्र्ान पर, “िो” िब्ि रखा िाएगा।

[फा. सं . एम. IV-2306/10/2025-खान IV- भाग(1)]
कु लिीर ससंह यािि, संयुक्त सजचि

टटप्पण.— मूल जनयम भारत के रािपत्र, असाधारण, भाग 2, खंड 3, उपखंड (i) में अजधसूचना संख्या सा.जन.का. 502(अ)
तारीख 14 अगस्ट्त, 2024 द्वारा प्रकाजित दकए गए र्े और उसके पश्चात अजधसूचना संख्या सा.जन.का. 311(अ) तारीख 14
मई, 2025 द्वारा संिोजधत दकए गए र्े।

MINISTRY OF MINES
NOTIFICATION
New Delhi, the 24th September, 2026
G.S.R. 842(E).— In exercise of the powers conferred by section 35 of the Offshore Areas Mineral
(Development and Regulation) Act, 2002 (17 of 2003), the Central Government hereby makes the following rules further
to amend the Offshore Areas Mineral (Auction) Rules, 2024, namely: —
1. Short title and commencement: — (1) These rules may be called the Offshore Areas Mineral (Auction) Amendment
Rules, 2026.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Offshore Areas Mineral (Auction) Rules, 2024, in rule 9,—
(a) in sub-rule (8), in the first proviso, for the word ‘three’, the word ‘two’ shall be substituted;
(b) in sub-rule (9), for the word ‘three’, the word ‘two’ shall be substituted;
(c) in sub-rule (10), for the word ‘three’, the word ‘two’ shall be substituted;
(d) in sub-rule (12), in the second proviso, for the word ‘three’, the word ‘two’ shall be substituted.
[F. No. M.IV-2306/10/2025-Mines IV-Part-(1)]
KULVEER SINGH YADAV, Jt. Secy.

Note:— The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i),
vide notification number G.S.R. 502 (E), dated the 14 th August, 2024 and was only amended vide notification number
G.S.R. 311(E), dated the 14th May, 2025.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
BHABAJIT
DEKA

Digitally signed by BHABAJIT
DEKA
Date: 2026.09.24 22:40:21
+05'30'
