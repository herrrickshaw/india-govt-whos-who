---
doc_id: "7ae9b91fcbf24cf0"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/de6f0c51143a4de70838935c6b68f3ea.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer and posting of officers of JAG Grade of P and T BWS Civil Group A"
date: "2017-07-25"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c5a8095700da2f25"
---

<!-- page 1 -->

No,2-1/2016-CWG
Government of India
Ministry of Communications
Department of Telecommunications

***

5th Floor, Room No. 620,
Mahanagar Doorsanchar Bhawan,
, Jawahar Lal Nehru Marg,
New Delhi - 110002
Dated

~~ugust 2017

OFFICE ORDER
The following officers of JAG grade in P&T BWS (Civil) Group 'A' Service are transferred with
immediate effect and until further orders as per the details given below:
· Sr. ! Staff No.
· No.
' 92077
! 1.

' 2.

92132

!
'
Posting on Transfer
~lame of the
i Present Posting
i
Officer S/Sh
S.P. Mahapatra : Director(Civil), : Director (VP), DoT1 i
DoT, New Delhi · New Delhi
i
Sanjay Kumar
Director(VP),
Director( Civil), DoT, I
I
New Delhi
DoT, New Delhi

2.

This issues 1Nith the approval of the CorTrpetent Authority.

3.

Charge reports may be furnished to all concerned.

~~
(S.P. Mahapatra)
Director (Civil)
Tel: 23222045
Copy to: ­
1. PS to MoSC (IC), Sanchar Bhawan, New Delhi
2. PSO to Secretary (T),DoT, New Delhi
3. PPS to Secretary, DoP, ~lew Delhi.
4. PPS to Member (S),DoT, ~lew Delhi
5. PPS to Member (Planning),DoP, New Delhi
6. Sr.DOG (BW), DoT, New Delhi.
7. CVO, DoT, New Delhi
8. DDG (Estt), DoT, New Delhi
9. DDG (E&F) & CMD, HPIL, DoT, New Delhi.
10. DDG (C&A), DoT, New Delhi.
11. CE (Civil), DoP, New Delhi.
12. Director (Civil) & Director (VP), DoT, New Delhi.
13. DS (co-ordination) & Nodal Officer (RTI) for necessary change in CPIO.
~rder Bundle/Director (IT) for uploading this order on DoT website.
