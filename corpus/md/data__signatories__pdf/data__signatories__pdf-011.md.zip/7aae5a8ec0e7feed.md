---
doc_id: "7aae5a8ec0e7feed"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/0ab3cf22ec13d51a3f88b1c23adcccf4.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Bihar Panel: Order dated 27.06.2025 Engagement for High Court of Patna, CAT Patna Bench and District Court of Patna and East Champaran"
date: "2025-06-27"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a622adce848d590b"
---

<!-- page 1 -->

F. No. J-11017/4/2024-Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
####

Shastri Bhawan, New Delhi
Dated the 27th June, 2025

ORDER
The President is pleased to engage following Advocates for conducting
Central Government litigations before the High Court of Patna, Central
Administrative Tribunal. Patna Bench and District and Subordinate Courts at Patna
& at East Champaran (Motihari), as shown in the table below, with effect from the
date of this order for a period of three years or until further orders, whichever is
earlier

LIST 'A'
HIGH COURT OF PATNA

Contact Details

IsI. IName of Advocate
No. 1(S/Shri

IEnrolment No.

Senior Panel Counsel
1.

[

3.

r
Sinha

o
1
Friends Colony, Patna-800025
Mob. 9431019575
Email- nareshdixit(a)rediffmail.com
r
2385/1999
INagar, P.S- Patarkar Nagar, Behind
College of Commerce, Patna-800020
Mob: 9431002953
Emailraveenkrsinha.advocate@gmail . com

L

s

a

[4

r

5.

I

1

Kankarbagh, Patna-800020
Mob: 9470832651
Email- sujeet136588@gmail.com
r
ICouncil Bhawan, Patna High Court,
Patna-800001
Mob:9934830641, 7091569166
[Email- pkadvoc@gmail.com
lagat Narayan Road, Kadamkuan,
Behind Sir G.D Pataliputra High
FSchool, Patna-800003
Mob: 9431457018, 9608748893
Email: binaykumarsinha.nc8@gmail.com

Page 1 of 9

m5

m3

<!-- page 2 -->

6.

IRanjana Sinha

IA-24, Jay Sona Bhawan, Krishinagar 1296/2001
Patna-800025
Mob: 9869194257, 9326496440

Fa

[s

"Narmdeshwar Niwas" Baldeo Sahay
Road, Kadamkuan. Patna-03

1

Mob: 7004667595, 9835268264
Ma I- rajeshsinha040t@gmail.com
2

I

Mish ra

IHospital, Shivpuri, Patna-23
Mob: 9334296800

[r

o

rrlar

2

IBequsarai, Bihar-851101

a

a

®8

IShastri Nagar Post Office, Bailey
Road. Patna-800023
Mob. No. 9334043311
Email: sahayrajen@hotmail.com
6

c

I

a

Priyadarsh i

New Chitragupta Nagar, Kankarbagh,
Patna-800020
Mob. No. 9835298881
Email: Nksinha58@gmail.com
3
m
Residency, Aryasamaj
IMandir Road, RPS More North Baily
Road. Patna
Mob. 9931044121, 9430589660
rabin d rapriyada rshiadvphc@gamil . co

a

a

I

a

1

Mob-9431416349
6

IRamjaypal Path, Danapur, Patna801503
Mob: 9934785747
Email- girjeshadv@yahoo.com
a

1

I

IJagdishpur Kothi, P.S- Nautan,
District- Siwan (Bihar)
Mob: 9431623040
Email- amajaymishra2(a>gmail.com
l

a

Sinha
I

M

1800013

Mob: 9823623828
r
IBuilding, Opposite Durga Mata

B

Mandir, Patna-800001 , Bihar
L

Mob: 9708091488
r
Behind Abdul Hai. Exhibition Road.

Patna-800001(Bihar)
Mob: 9871956775
Page 2 of 9

B

<!-- page 3 -->

19. IGautam Kumar

ISheikhpura Durga Ashram Gali, Near 304/2013
Ex. C.M. Lalu's Apartment, Shastri
Nagar, Patna=800014
Mob: 9835406076

L

c

6

Marg, Patna-800001
Mob: 9431025100
H No. A/23, Snehi Path, Dr. B.
Bhattacharya Road, West Patel
Nagar, P.S and Post- Shastri Nagar,
Patna-800023, District Patna
Mob: 7903970458, 9931005268
Emailmadankumaradvocate@gmail. com

a

e

m4

2

1

IApartment Biscuit Factory Road PODigha, PS- Danapur, Patna (Bihar)1800012

Mob: 9801940009, 9431063893
Email:
neerahnandan8001@gmail . com
a

1

m3

IAnishabad, P.S- Gardanibagh,
District- Patna-800002
Mob: 9430001717
Email- spasswan1970@gmail.com
a
Dwarika Mandir, West Boring Canal
Road.Patna-800001
Mob: 9431201103, 7761891195
Mob:
rakeshkumarpatnahighcourt@gmail.c
om

r

Central Government Counsel
Ba

o

1

Patna, Bihar-800020
Mob: 7717773976
Email- rahuldeo2023(a)gmail.corrl

$a

br

6

a

Lakshmi

(near Palm View Hospital, Jagdeo
path, Patna-14)
Mob: 9431074838. 7543027900
Email- manoj.choutan@gmail.com
2
o
IColony, Ashiyana Digha Road, Patna25
Mob. No. 9955241804
Email- priyankaadv0123@gmail.com

Page 3 of 9

<!-- page 4 -->

27. IKumar Sachin

ISushila Sharma, Bakarganj, Bazaza,
Patna-800004
Mob. No. 9835095675

28. 1

a

E1972/2003

Email- adv.kumarsachin@gmail.com
®5

Mazar Lane, Bailey Road, C)pp-Pillar
No.76, Rajabazar, Patna(Bihar)

Mob: 9430556942, 9304815272
Email: chandantac(a)gmail.com
29. a

1

District- Samastipur
Mob: 9576508152,7766929302

a3 L
Singh
31. ma

32.

mMa;in
"”;'
Prasad

m5
3

1

IDistrict- Saran- 841101, Bihar
Mob: 9431050262, 9931072200
moperative

Colony, Road No.

m4

15E, Rajiv Nagar, Patna-24
Mob: 8809362754. 9431460444
Email- Kalpana.IIb@gmail.com
2

1

Mangal Deep Apartment, Gosai Tola
P.O & P.S Pataliputra, Patna-13
Mob: 9334406053

33. lvijay Kishore Bharti o

2

34. a

1

Kankar Bagh, Road No. – 1, Patna
Mob: 7004750740
Email- vijaykishore53@gmail.com

Sanjay Ram

35. a

36. a

1

IKankarbagh, Patna-20
IMob :9431421178
Emaillsanjay9431421 178@gmail .com
[anta Road, New Yarpur, P.SIGardanibagh, District- Patna-01
Mob: 9472071449
Email- bariar.rajiv72@gmail.com
a

IDigha Road, Nepali Nagar, Patna-25
Mob: 6200737748
Email- rishi6200737748@gmail.com
37. a

o

800016
Mob: 7004564434
38. a
Sharma

a3 a

ml

Email- sarsuman08@gmail.com
a
IBairiya, Patna-800007
Mob: 9434066080
Email- rksharma31198@gmail.com
,Deva Residency
bartment,Mangalam Vihar
Page 4 of 9

m8

5

<!-- page 5 -->

Colony,Ara Garden,Bailey
Road,Patna-14
Mb – 9835228019
Email- adv.sanjeevkumar@gmail.com
140. IArchana

o

11380/2006

lst Floor, New Colony, Chitragupt
Nagar, Kankarbagh, Patna – 20
Mob.- 9471860424. 7903562579
Email- adv.archana25@gmail.com

n4 r

a

L

I– II, Beur, Patna – 02

IShekhar Azad

Mb.- 8210881299. 9431084336
EmailIdr_chandrashekha r_azad@rediffmail .
R4

l

Ico m
a

Rajendra Path, Behind C.D.A.
Building, Patna – 800001
Mb.- 9334296800, 7645019308
Email- shallykumari1969@gmail.com
R4

a

a

m8

2

NaIa Par, Kurji, Patna – 10
Mb. - 7992276966, 9334227363
Email: advpnprasad@gmail.com

a4 r

o

1

Patna – 20

Mb.- 9431624105
R4

I

e

Pa swan

c

1801503

Mb.- 8578943012, 8709593387
Email- bk4330357@gmail.com
R4 a

o

3

West Mahesh Nagar, Patna - 24
Mb.- 9430829129
Email :
skmishramaheshnagar@yahoo. com
E4

a

I

®5

IApartment, Patel Path, Piller No. 76
Sheikhpura, Baily Road, Patna – 14
Mb.- 9431492472
Email :
nityanandadvocate@gmail . com
R4

l

jsingh
R4

)

)

IVijay Nagar, Rukanpura, Patna- 14
Mb.-9504799681
Email: chandansingh920@gmail.com

m4
0

L

ppartment,Behind

Old Petrol

Pump,Raja Bazar,Patna-14
Mb – 9308555357
Email : apurvakrsharma@gmail.com
Page 5 of 9

<!-- page 6 -->

50. IAbhishekh Kumar

IHouse No.-32A,Gokul Marg,North
IS.K.Puri,Patna-13
Mb-8709929603
Email: abhishekh910@gmail.com

12081/2013

a

o

H1

Nagar,Patliputra ,Patna-13
Mb.-9431810226, 7061675839
Email: aarshkumar.singh@gmail.com
o

a

1

Dwarika Puri, Hanuman Nagar,
Kankarbagh, Patna-26

Mb.- 7903056245

Email: minillb@gmail.com

B1

1

Fr

Email :
advsinghvishwajeet@gmail . com
r
IAmitabh Path, Maurya Path,
Khajpura, Patna – 14

0

IMb.- 9431421254
2

Mb.- 9431602901
Email: anuraqsaurav123@gmail.com
r
INear Jagdamba Nursing Home, Patna

e

23

Mb.-7870343536
Email: deepak15171@gmail.com

Baa
Singh

Dr

-owr -10, Flat No. -108, Sanchar
INagar (RR Builder), Adampur,
IKhagaul, Danapur, Patna – 801105
Mb,- 9386124831
Email: nksinhgphc@gmail.corr!

m2

e

2

Department, House No. – 284, Patna
13

Mb.- 9308333782
Email: k7davdnagar@gmail.com
1
r
Makhclumpur, Dist. Jahanabad, Bihar
Mob- 9431830211

bl
a

2

1

Bharti

Dairyapur, P.S Parsa Bazar, Dist.
Patna

&I

Mob- 9939019700, 8271225414
Email: skbhatiadvocate@gmail .com
9
o
Bhattacharya Road, West Patel
Nagar, P.S and Post- Shastri Nagar,
Patna-800023, District Patna
Mob: 7004297575, 9931005268
Page 6 of 9

<!-- page 7 -->

<!-- page 8 -->

8. IAbhishekh Kumar

IHouse No.-32A,Gokul Marg,North
S.K.Puri,Patna-13
Mb-8709929603
Email : abhishek910@gmail.com

IBR/2081/2013

Fa

o

ml

Nagar,Patliputra ,Patna-13
Mb.-9431810226. 7061675839
Email: aarshkumar.singh@gmail.com
r
0
IPassport Office, Ashiyana Digha Raod,
Patna -14
Mb.- 9430951977
Email: brijeshph(g)gmail.com
e
1
INear Jagdamba Nursing Home, Patna-

r
Pandey

e

23

Mb.-7870343536
Email: deepak15171@gmail.com

LIST 'C'
DISTRICT AND SUBORDINATE COURTS. BIHAR
SI. I Name of Advocate I
No. 1

Contact Details

} Enrolment No.

(S/Shri

DISTRICT-

PATN A

Additional Standinl Government Counsel
1.

o

I

Sinha

®4

!Nagar(Kali Mandir Road), Hanuman
Nagar, Kankarbagh, Patna 800026,
Bihar
Mob: 9304024660, 7488309321

DISTRICT- EAST CHAMPARAN (MOTIHARI)

Standing Government Counsel
[2

r

1

Mishra

:

IEast Champaran-845401, Bihar

Mob: 8809903990
Email- satish.mishra2007@gmail.com

Additional Standing Government Counsel
3.

I
Mishra

L

o
IEast Charnparan-845401, Bihar
Mob: 9470238686
Mob : shailendra9jan@gmail.com
Page 8 of 9

<!-- page 9 -->

2..
The engagement and professional fee of the aforesaid advocates will be
governed by the terms and conditions contained in this Department's OM No.
26(1)/1999-JudI. dated 24.09.1999 (List ’A’ & List 'B’) and No. 27(11)/99- JudI.
dated 24.09.1999 (List 'C') both read separately with OM No. 26(1)/2014/JudI.
dated 01.10.2015 & instructions issued subsequently through OMs especially the
OM No. J-16/11/2017-Judicial dated 08.02.2018 and OM No. J-16/20/2024Judicial dated 16.10.2024 imposing certain restrictions on panel counsel. The

aforesaid OMs are available on the website of this Department i.e.

www.legalaffairs.gov.in under the tab 'Judicial Section' and in the link 'Circulars
pertaining to litigations'.
Hindi version of this order will follow.

3.

'usty )
(Madhab Ch;'ra
Senior Government Advocate

Copy (through email) to:1.

PS to MoS (I/C) L&J.
2. PSO to Law Secretary/All Additional Secretaries in the main secretariat of Department

of Legal Affairs
Dr. Krishna Nandan Singh, Addl. SGI, High Court of Patna.
The Registrar, High Court of Patna.
5. The Registrar, CAT, Patna Bench.
6 Shri Harendra Prasad Singh, Sr. CGSC, CAT, Patna Bench.
7 The Cash (LA) Section, w.r.t. retainership fee to Sr. CGSC, CAT, Patna Bench.
8 The Pay & Accounts Office, Department of Legal Affairs, New Delhi
9 One copy of this order is uploaded on website of this Department i.e.
www.legaiaffairs.gov.in under tab *Judicial Section’ in the link 'Orders related to
empanelment of Advocates for Union of India’ for the information of panel counsel
as above and all other concerned
10. Hindi unit, Department of Legal Affairs for Hindi translation of the order,
11. Office / spare copy.
3
4

(KuFnar Gaurva)

Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dia@nic.in

Page 9 of 9
