---
doc_id: "7c568fc31eaeeec2"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/661537b9d893612026c1076f0bbfa755.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Fixation of pay of re-employed pensioners-General Policy thereof-Raising limit of exemption of pension."
date: "2025-07-14"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d907d55937253c15"
---

<!-- page 1 -->

* मे

5. DPE/Guidelines/1V(d)/5 | 4

| Fixation of pay of re-employed pensioners—General Policy thereof—Raising limit of

exemption of pension. |
Reference is invited to this Department’s OM No.3/3/85-S&A Cell dated 29.10.96 on the subject

mentioned above, in terms of which pension upto Rs.500/- is to be ignored in fixation of pay on re-
employment of service officers and officers holding Group ‘A’ posts who have retired before attaining’55
years of age. | |
2: | ‘The question of fuither liberalization of the provision has been under consideration and instructions
have since been issued by the Department of Personnel and Training vide their OM No.3/4/97-Estt.(Pay-Ib)
dated 7.11.97. It has now been decided to enhance the ignorable part of pension from Rs.500/- to Rs.1500/-
in the revised pay scale to the service officers and officers retiring before attaining the age of 55 years and
holding group ‘A’ posts in civil side on their re-employment. . .

3. The pension for the purpose of pay fixation will mean gross monthly pension. These guidelines
will take effect from 1.1.96. The limit of Rs.1500/- per month on entire pension, as the case may be, will
be applicable to cases of pensioners re-employed on or after 1.1.96. In the case of persons who are already
on employment, their pay may be re-fixed on the basis of these guidelines w.e.f. 1.1.96, provided they
exercise an option, in writing, for such re-fixation within a period of 6 months from the date of adoption of
these guidelines by the concerned Public Sector Undertaking (PSU), if they so opt, their terms would, be

| determined afresh is if they have been re-employed for the first time from 1.1.96. | 1
i, Mhe guidelines issued Uy BPE (aew DPE) vide its OM Mo.3/3/85-S&A Cell dated 29.10.86 & QM
tig 1/1/88-KPE(SE&A Cell) dated 6.3.28 06 the sublect si a : ;
© i I//6d-BPEOGE 4, Cell dated 9.3.89 o4 the subject siand modified to the exient mentioned above. Pay
f awe 40733 f 4 Ve-Eir OV ‘ pe aie nm ; 7" aphap £ a ws 7 2 2 oe . .. |
‘ixation of the re-einpl yed eusione! 9 will be decided as per these provisions, except the cases in which
 «tS-onnpioyed pensioners have already retired after serving their tenure/remaining service on superannuation.

° % A, OBE oy a कक 4 8३ ४ ८५ eo ts I हे ti 1९६ serene fi ope Agen cee dot re | . . |
हे | AR acmmnist ene ier) Departments of the Government of India are requested to bring the
roregoig to the noice of the Public Enterprises under their administrative control for information and -
५0॥४01187106:, ' *

(OPI O.M. No. 8-114/97-]7क(8/()51, तक्काइत 26" February, 2902) ,
sk ook oof
