---
doc_id: "7ba5fb00c9eca0e1"
source_url: "https://www.labour.gov.in/static/uploads/2025/07/74632d9eba50956a4f5a720c30c68864.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification reg. Amendment in the First Schedule item 29 (Download 820.6 KB)(20.07.2017)"
date: "2017-07-20"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "54a8669627d0b0dd"
---

<!-- page 1 -->

\

~ ~o ~o ~o-33004/99

REGD . NO. D. L.-33004/99

ciFi I

~he ([ja~ette of 3ndia
:m:rTUf"{UT

EXTRAORDINARY
'lWT II-~ 3-~-~ (ii)

I' ART 11-Scction 3-Sub-section (ii)

1Alfw.m- ~ ~
PUBLISHED BY AUTHORITY
Ti. 1736]
No. 17361

1

~ ~. ~. ~ 20, 2017 / ~ 30, 1939
NEW DELHI, TUESDAY, JUNE 20, 2017/ JYAISTI-IA 30, 1939

.,-{~, 20 "ff, 2017
<fiT.3lT. 1955(31) .-~ m'flR ~ ~ ~. 1947 (1947 <fiT 14) <fit URT 40 <fit \3"1-URT (1) lmf

~ ~Tfu;<IT <fiT ~ ~ ~. ~ "ffl1TUR ~ ~ foF ~ it "Q:m ~ 3lf<f~'l'li ~. ::rrti ~ ~ ~.
1947 <fit~ ~it f.'l<;;~Plfuld ~~rru;r~t 31~ :;:rw ~ ~ it. Of1l1 m,- 29 3lR

m ~~~

f'l.lR ~

f.'l <;;! R:t f1il d Of1l1 m,- 3lR ~ nstt

~.31~:-

['fiT.~- ~-11017/2/2017-:mtam:(~)]

~a:ri'm.~~

f?:aror: mr <fiT.arr. 251(31) ~ 25 ~. 2017 ~mr '+m:cr ~ m , 3111TmDJT, 'llTlT II, ~ 3, \3"1-~ (ii) it
~ ~ lmf ~ ~it affi\11 om: ~RITU<l fil;<rr l!1IT qr I

3827 G l/2017

{ I)

<!-- page 2 -->

2

(PART fl--SEC. 3(ii))

THE GAZETTE OF INDIA : EXTRAORDINARY

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 20th June , 2017
S.O. 1955(E).-In exercise of the powers conferred by sub-section (1) of section 40 of the Industrial Disputes
Act, 1947 (14 of 1947), the Central Government, on being satisfied that it is necessary in public interest so to do, hereby
makes the following amendments in the First Schedule to the said Industrial Disputes Act, 1947, namely: ln the said First Schedule, for serial number 29 and the entry relating thereto, the following serial number and the
entry shall be substituted, namely:_:
"29. 'Processing or production or distribution of fue l gases' (coal gas, natural gas and the like)"
[F. No. S-! 1017/2/2017-TR(PL)]
RAJEEV AROR'IA, Jt. Secy.
Note:

The First Schedule was last amended by notification published in the Gazette of Indi a, Extraordinary, Part II ,
Section 3, Sub-section (ii), vide number S.O. 251 (E),dated the 25 111 January, 2017

Uploaded by Dte. of Printing at Government of India Press. Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi- II 0054.

ALo K KuMAR

Digitally sig ned by ALOK KUMAR
Date: 20 17.06.22 11 :23:23 +05"30"
