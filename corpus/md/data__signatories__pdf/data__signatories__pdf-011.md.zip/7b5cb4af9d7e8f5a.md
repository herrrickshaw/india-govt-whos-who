---
doc_id: "7b5cb4af9d7e8f5a"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/07/87476e846872e44083a531735c620316.pdf"
ministry: "Tourism"
title: "Tender Discharge Notice w.r.t RFP Selection of Consultant for setting up of National Programme Management Unit (NPMU) under Swadesh Darshan Scheme."
date: "2024-05-02"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "45ca1be4d393909b"
---

<!-- page 1 -->

Government of India
Ministry of Tourism
(Swadesh Darshan Division)
Transport Bhawan,
1, Parliament Street,
New Delhi-110001
File No. SD-8/69/2023-SD Date 02.05.2024
Tender Discharge Notice
Subject: Discharge of RFP no. SD-8/69/2023-SD dated: 15.03.2024 for
‘Selection of Consultant for setting up of National Programme
Management Unit (NPMU) under Swadesh Darshan Scheme’.

The undersigned is directed to inform that the Request for Proposal
[RFP] bearing reference no. SD-8/69/2023-SD dated: 15.03.2024 for
‘Selection of Consultant for setting up of National Programme Management
Unit (NPMU) under Swadesh Darshan Scheme’ published on the official
website of the Ministry of Tourism www.tourism.gov.in and on the CPP
portal of the Government of India https://eprocure.gov.in/eprocure/app
hereby stands discharged with immediate effect for all purpose without any
financial liabilities or whatsoever to the Ministry of Tourism due to
administrative reasons and in accordance with the decision taken by the
Competent Authority.

१४७६८...
Uttank Joshi
Assistant Director General (SD)
उत्ल॑क itgit/UTTANK JOSHI
T सह्यक महानिदेशक //39/ Decor General
0, ‘adden tiara / Ministry of Tourism
भारत सरकार /00ल्‍#. ए ॥#03
All concerned bidders. me ie DE
