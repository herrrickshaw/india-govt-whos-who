---
doc_id: "7d44cbb201bbc3be"
source_url: "https://www.labour.gov.in/static/uploads/2025/07/16f25be719c9c7215232d3ae9f239932.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Filling up of one post of Personal Assistant on transfer on deputation basis in CGIT-cum-LC No.2, Mumbai-reg. - reg."
date: "2022-09-30"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d80fed31e4029fb3"
---

<!-- page 1 -->

File No. Z-25025/08/2021-CLS- II (e) (Computer No. 130019)

646653/2022/C LS-11

I
GO\ ernmcnt of lnd i:l
'lini,tr~ nf J Hho u r '-'- Ernplo~ llli..'lll

Ct.•ntf'a l <;on-t'IIOH'nf .m.Ju~trial Tribunal ~o. 2
'' • !..1£\ , :~~~' -;;-}i>!Ji, ..,:~·;-;-r.u•hP I!1.d. t l;::r P!_!' ~...hlfll- • •tl ~ ntt"-;;1 1 \llh'\~ II~'- <;-:;,1 \i, nl:.. u ·l'"'' · ..:.
l'.v ~viT .~ / PA ReLt! /

' 14.

1'2. 02'1

ClHCULAR
Sub Crlf•,g up t.'' ~ne post of P<"!>C•I'• tl..:..s~r5tant \'Jrt Tr.:Jr,.,!er 011
Deputa1ro" oa_,,~ 111 th€' ll'llt' <J I •:.H> . f·rnnH~rH lrtd •.r":>tii.:JI
Trlbunai ·Ctlm Labour Court-/. ;,,lumba.- ref,
It '' proposed to frll up one l)OSt o f Personal Ass r st<~nt on deput3t ron b<JSIS 1t1 Ccntr2l

lnd:l•'na! Tr•bullal·cu rn-Labour Court-2 N1t1mba1. initiall\i fu a penod of one year ur. tht>
:ot.o.·..r,.t: lt: rm .. ar.d cnnd rttorts ·

•":(1•,,

rer~onal tl,·,51:.t<1nl

rl

CH1•? po<.t of PNsO.<<'il A~s• stan; 111 Lf'v'[l b 1 1 tl•~ Pt,·r !\!A.TRIX of 7'' (PC
11 R~ '~:.oo ~4£\lO .,,, th ,_,r."ldc p ·~ H~ ·1200: PR-I i (prP·r~·.. is.,d;J,

ii)

~~per :he extc.:1nt' Recruitment H~.l>.?s, thP. po<.t rnciV b,,. lllle-tJ up o n deputacron Lla ~~
IJG!ll the c.~ndrdatt'·~

a)

(r) Holdtn~ illr.dogOl:~. post

1'" ri:, .. •,,r l1.1 :·. f>'

tu) W•lh 10 v 'a's 1e~ular ::;er vi~L· .n the Stenographer Gradt:. in the pJy band 1,
Rs. C:. 200 20,?r•O / - wrth grade pav o f R~ . 2,400 !-(pre-revised). (Level 4 1n the PAY

MA lRIX of i~ ~: PC} and,

b)

Possr>ss~r1g qualifrtatror <IS presc.ribPd rn RPcrwtment Hules for D•rect Rt>r.rurtmP.nt

'rl 111 or,, - '} horn , r<·rogf'rlL•<i Bor~rd
(II) )kll rest norm·. Otccattun W lllll,ut>.-:. :if,• l.llO \'y p .m
fran~crrpt1on: t!O Mins (F.nghsh) 55 nMi'.. IH111di} ~on computer}

11d

Oeoutat10n (d~ tv 1\llowantt- .;:hair be as oer the gurde'tnes , ~,sued hv DOP1
No /i22(B) / ,' '1-:1~ E:;tt (Pay II) rl:ilc:d lj r. \('\'!l~mhPr 2008

2. 1 ne <iltldtdate ~f'lr!Ctt!d will ho'.Jl' tPt' fJ~ Ivll !(, clr .. w j)cl't <i~ rnentrcned .1hov•· rasP~' 7'
CPC) or draw pay 1'1 the current po~t plus D~putation .'lilo·Nanct:.
:)

~E111f, drffer~Jirti.J:

II\ hJSIC f.i•lV the ' .P•r-•ctr;d Cilnd·drttr~ wil, e1~t t'l1hdn:.ecJ .,p-.. ;lunwnt'..1<

per Pay Rule~

Generated from eOffice by BRAJESH BHARDWAJ, SO(BB). SECTION OFFICER-MOLE. MINISTER'S OFFICE o n 30!09!20 22 04 , 37 PM

I

<!-- page 2 -->

File No. Z-25025/08/20 21-CLS- II (e) (Compu ter No. 130019)
64665 3 I 202 2 /CLS- 11

4.

The penod of deptJtation will ordinarily not exceed three years.

5 lt is requested that the ap plic:"cttions of interested, eligible and suitable candidates who
u 'n be spared for appointment may please besen t (in duplicate}, after du ly certifyiog
rhe details given by the can didate in the Bio Datil in the enclosed profo~ma along with
their complete 1.1p to da te ACRs(attested photo copies of last five years) and Vigilanc.<?
Clearance Certifkat~ rnav be sent so as to r~ach the undersigned on the following
address, latest 'Nlthin r.rl'? rnontb from the date of i.ssue of ~his circular.

-

--

Pre~>iding offin"r

·--------- - ·--- - -

Centr;;f Govr~rnrn,?nt Industrial Tribuna! -c un1 -L:J bour Court N0 . .2
Shran1 f\a ksha Bhavan 2"d Floor,
Shr<~:;rushtl Road, Opp. Priyadarshinl
Off Eo stern Express Hlgnway,
SHm, Murnbai- 400 022
- - - ---- - - -·----- ···-- ·- - -- -·~---

....

-~

'd ....

c-)
~
;l?~-

.

fT~{8ahadur l
Dy. Chief Labour Cornrnissioner(C}/
In charge

CG:T-2, rvlurnbai.

To
1. A.ll rvlinlstries I Departments of the Govt. of India .
2. All CGIT~cum·La bour Courts.
3 All Debts Recovery Tribunal
4 . l\ll Jncome Tax Tribun al
5. O·i· Chief Labour Con:missioner (C), Mutnbai
6. The Registrar General (Subordinate Judiciary}, Hon'ble High Court of Bombay.
7. All attached I Subordinate offices of the Ministry of Labour & Employment.
8. 1he- Under Secretary to the Govt. of J"dia, CLS-tl, Ministry of Labour & Emptoyment,
Ne ~v Delhi, With th e reqlJE;!St. to circulat e the vacancy Circular amongst the Central Govt.

Offln.'S / rv·lini <; tnes at i:r: llli

2
Generated from eOffice by BRAJESH BHARDWAJ. 50(88). SECTION OFFICER-MOLE, MINISTE R'S OFFICE on 30/09 /2022 o 4 ,3 7 PM

<!-- page 3 -->

File No. Z-25025/08/202 1-C LS-II(e) (Computer No. 130019)
64 6653 / 2022 ; CLS-11

PROFO ~MA

'.

t! r :

I

•

.lj)f) II_<Jfll

l1•

It

, '1

(I l

t

1

t

•.

,....,, : ~ ' . ·, ' \. I

i...

cJ:ld U 1l•

I

I

•

1

I

I I

·• 1 'nh 11

''•
I• lJ{ .1 1111t•l':

S Prc::.el' P•lv <t"<J I• 1v tidrH! vv ··, ~··, ,,. l'<i't
1

ll . JI('• 1 11 flql[fr

I.

.I ,P
I·~

r;. 1,,r ( j; t

\: •'r
1/v r ll'i

.

I

tJ I··\

j~j; I

r

,I

,,.

'•

•tdlt I.

f•t•.l

-

i.

,,

I'

'
,

!l

.. '

•

,,_·rvrll'

t

.. ,

,.

I

i .-

~(', r •:,J!"'!j

(,,,. j

Jl.i l .>

I I I Jr

(

i : I"

•., I

~

>ll'!.t

l '',.

l

·,

"'')"

I 1
I

,.

... B'! f

,,

'• I '.!it· d !1111, 'Ill[ l. it• l' :r

~~I I

(~

I I ) ll' I

'(l

.'

\

:

'.

I

t

t

~

t

'

'

>
61

i ~- ! j I(I r .
, ., I

I

• '

I

l \J I : I ' I I 1( ) ·. I ',

l;

._,~, ~ ., :

11 t

f:

Iff

'1"':.

r

ti ~\, :•P

'1.·'

I'

'I

I

. ,.

' ' ,,

•.• 1,.

•.'

._,

3
Generated rrom eOIIice by BRA)ESH BHARDWAJ. 50(66), SECTION OFFICER-MOLE, MINISTER'S OFFICE on 30/0912022 04:37 PM

<!-- page 4 -->

File No. Z-25025/08/2021-CLS- II(e) (Computer No. 130019)
646654/202 2/CLS-11

~~~

'iii

~

Co\'ernnll'nf of Jndi3
i\1 in is try of Li1 bour & Emplo) ment
Central Gm ernment Indust rial Tribunal i\o. 2

Shr~m.l\ak;hoB~"-' t10()r Slr··. ~rushu R~'>K! Opp. Piwa..W~iml. O[fEa-::_t-rn E'pre-;s ~l·g~).-,11:· ."""~7"'ion-. ~~orlt}~

No .CGIT· 2 I PA. .Rectt I

C,,( c}

Dated: 30l11 September,202.2

/2022.

CORRIGENDUM

K1ndly r_e fer to l h1s af. ce Circular no CGIT-2/PA Rectt/594/22. dated 28 09.2022
on the subject ftlling up of one post of Personal Asststant on Deputation basi" in . the

Centra l Governmen1 lnd1.1Strial Tribunal-cum-Labour Court-2, Mumbai. .
Poi~t (ii) of Sub Point (a} (ii) of said Ci rcular f with 10 years regular service in

the Stenographer Grade "' th e pay band-1 . Rs 5,200-20,2001- wi!h grade pay of Rs.
2. 400 (pre-revised) . (LewJI 4 m the Pay Matrix of 7m CPC) ancf; ) is de leted as per

amendment dated 27.07,2022 in the Recruitment Rules for Personal Assistant.
All other contents of the office circular no. CGIT-2JPA.Rectt/594/22. dated
26.09 2022 shall remain unchanged.
Appltca!lons of interested, eligible and suitable candidates may be sent at tile ·
address mentioned in the circular dt. 28.09.2022 within one month from the date of

1ssue of tl• is office corrigendum

~/( Tej Bahadur)
Dy. Chief Labour Commissioner( C)/
lncharge

CGIT·2. Murnb9i.

4
Generated from eOffice by BRA)ESH BHARDWAJ, SO(BB), SECTION OFFICER-MOLE, MINISTER'S OFFICE on 30/09/2022 04:37 PM
