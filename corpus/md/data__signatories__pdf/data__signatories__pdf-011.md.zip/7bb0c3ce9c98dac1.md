---
doc_id: "7bb0c3ce9c98dac1"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/dec81055e698c45bcfc0dc56bd6d9504.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RTI - Departments of Health and Family Welfare - Chs II - Order No. A 12025/02/2015 CHS-II dated 21st January 2015"
date: "2015-01-21"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "cc77f93c43cea1bf"
---

<!-- page 1 -->

)! Z .
4 —— कु
te
3 =
4& 7 bs F.No. A.12025/02/2015-CHS-II
Orga) x, Government of India
Jee कु Ministry of Health & Family Welfare
A ge a /® CHS-Division
uf & रे रे ke
(8५ द ( m,
NoPE Sus ; ;
ip Y Ls न Se} Nirman Bhawan, New Delhi
- (S x WY Dated: 21s January, 2015
&, | a We MLS ORDER
4 s &
With the approval of Competent Authority, Dr. C.R.Sarangi, Chief
Medical Officer (NFSG) of General Duty Medical Officer Sub-cadre of Central
Health © Service, presently posted at RoHFW, Bhubaneswar, is hereby
transferred and posted at CGHS, Delhi, on his own request his own request, with immediate
effect.
2. Charge relinquishment/ assumption report of the officer may be
obtained and sent to this Ministry in due course. J
८ A
(M.K.Sharvar)
Under Secretary to the Govt. of India
© Tel.No. 2306 2550
Copy to: 4 हु
WK ysAily
5 YY 1.The Director General of Health Services, Nirman Bhawan, New Delhi.
\Y /S\_2. Director, CGHS, Nirman Bhawan, New Delhi,
. /S" ~3.Regional Health Officer, RoHFW, Bhubaneswar, BJ-25, BUB Nagar,
. Bhubansewar-751014,
4.Additional Director (HQ), CGHS, Delhi, Sector 12, R.K.Puram, New
Delhi.
se S.Officer concerned (through the controlling Unit).
590. CHS.1/CHS-V Sections/APAR Cell. 22-40 केला है है ;
ve _“Incharge, NIC \for postitig the order on e Ministry’s website.
8. Order folder.
OC e.
pe]
