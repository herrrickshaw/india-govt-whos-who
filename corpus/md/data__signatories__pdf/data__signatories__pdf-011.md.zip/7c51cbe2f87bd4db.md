---
doc_id: "7c51cbe2f87bd4db"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/fb71818494094653ffbb09d20f82f6ef.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Revision of limit of Advance to Panel Counsel: OM dated 20.11.2017"
date: "2017-11-20"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e5c0e075c8e43e4a"
---

<!-- page 1 -->

F. No. J-11013/4/2017-Judl.
Government of India
Ministry of Law & Justice
Department of Legal Affairs
Judicial Section
कक केक के के के
Shastri Bhawan, New Delhi
Dated the 20" November , 2017
Office Memorandum
Subject: Terms and Conditions contained in Department’s OM No. 26(1)/1999 dated
24.09.1999 governing the engagement of various categories of Panel Counsels for Union of India
for various High Courts in the country (excluding High Court of Delhi, Bombay, Calcutta and
Karnataka) -- amendment of clause XI relating to out of pocket expenses.
कक कक
1. The undersigned is directed to convey the approval of the Competent Authority to revise
the provisions of advance, as prescribed under clause XI i.e. “Out of Pocket Expenses” of the
Revised Scheme containing terms and conditions for the engagement of various categories of
Panel Counsels for Union of India for various High Courts in the country (excluding the High Court
of Delhi, Bombay, Calcutta and Karnataka) contained in this Department’s OM No. 26(1)/1999
dated 24.09.1999, from Rs. 300/- to Rs. 3,000/-. The aforesaid clause XI stands amended
accordingly.
2. This issues with the approval of Hon’ble ML.
Epes
(R.K. Srivastava)
Deputy Legal Advisor
Tel No. 23387543
Copy to,

1. The PS to MU/PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary/PS to all Addl. |
Secretaries/PS to all JS&LA of Main Secretariat.

2. The In-charge Litigation (High Court) Section, CAT (PB) New Delhi, Lower Court Section.

3. The In-charge, Branch Secretariats Bengaluru, Mumbai, Kolkata and Chennai. |

4. The Additional Solicitors General of Rajasthan, Allahabad, Punjab & Haryana, Patna High
Courts & Sourthern Zone.

5. The Assistant Solicitors General of All High Courts other than Rajasthan, Allahabad, Punjab
& Haryana and Patna.

6. All the Sr. Central Govt. Standing Counsel for CAT Benches/AFT Benches except in the state
of Maharashtra, Kolkata, Karnataka & Tamil Nadu.

7. Allthe Standing Govt. Counsel in various District & Subordinate Courts in the country.

8. To upload on official website of this Department i. e. www.legalaffairs.gov.in in the tab
‘Judicial Section’ under the link ‘Circulars pertaining to litigation’ for the information of all
concerned.

9. The Hindi Section for issue of translated version of this OM to all concerned.

10. Guard File with 5 spare copies.

11. Office copy. \ te Dy न A

a — +न-+-+-ननननप न
(D. Srinivas)
Section Officer (Judicial Section)
