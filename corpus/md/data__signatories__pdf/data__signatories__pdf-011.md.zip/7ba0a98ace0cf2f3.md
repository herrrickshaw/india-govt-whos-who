---
doc_id: "7ba0a98ace0cf2f3"
source_url: "https://doj.gov.in/static/uploads/2025/12/432f992a5e319205c4b461bf56cc5504.pdf"
ministry: "Department of Justice (DoJ)"
title: "National Law School of India University, Bengaluru"
date: "2021-11-22"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d973344a72724e2e"
---

<!-- page 1 -->

File No. N-9/7/2015-NM
Government of India
Ministry of Law and Justice
Department of Justice
Jaisalmer House, 26, Mansingh Road,
New Delhi-110011
Dated: 21% May, 2018
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded for the payment of Rs. 5,48,626/-
only (Rupees Five Lakhs Forty Eight Thousand Six Hundred Twenty Six Only) to National Law
School of India University Bengaluru towards Third & Final Installment(As claimed by the University)
out of the total project cost of Rs. 22,36,750/- (Rupees Twenty Two Lakhs Thirty Six Thousand
Seven Hundred Fifty Only) (non-recurring expenditure) for under taking research project titled “Shifting
Paradigms: Making Clinical Legal Education Relevant ” under the “Scheme of Action Research and
Studies on Judicial Reforms” as per the terms of the agreement signed by National Law School of
India University Bengaluru with Department of Justice on 02" March, 2016.First & Second
instalments of Rs.4,47,350/- and Rs. 8,94,700/- were released to the National Law School of India
University Bengaluru, the implementing Agency vide this Department's sanction order of even no.
dated 03 March, 2016 and 28" February, 2017 respectively
‘ 2. The expenditure involved is debitable to Demand No. 61 during 2018-19 (Plan) under MH 2014-
Administration of Justice, 17-National Mission for Justice Delivery and Legal Reforms; 17.02-Action
Research and Studies on Judicial Reforms, 17.02.28-Professional Services
3, This has been entered in the Register of Grants/Expenditure at SI. No. 2 at page No. 25-26.
4, This issues with the approval of IFD [Law] vide AS & FA Dy. No. 1825 dated 08.05.2018
>penre>
Se
ZA. Khan)
Under Secretary to the Government of India
Telefax: 23072139
To,
Pay & Accounts Officer,
Ministry of Law & Justice, Department of Legal Affairs,
Janpath Bhawan, Janpath,
New Delhi
Copy to:-

4. Cash Section, Department of Justice with one spare copy and a copy of Agreement. It is requested
that the payment may be made through e-payment to National Law School of India University
Bengaluru

2. Cash-Il MHA, North Block, New Delhi

3. IFD/Budget Division, Ministry of Law and Justice, Legislative Department, Shastri Bhawan, New

elhi.
ne, Jaisalmer House, New Delhi for uploading on the Department of Justice website

5. Vice Chancellor, National Law School of India University, Nagarbhavi, Post Bag No.
7201, Bengaluru-560242.

6. Section Officer, Admn.Unit, Department of Justice, Jaisalmer House, New Delhi.

7. Principal Accounts Office, 4" Floor, Ministry of Law and Justice, Lok Nayak Bhawan,
Khan Market, New Delhi

8. Guard File.

9. Spare Copies-5.
