---
doc_id: "7ac1fb2b1ad7cac6"
source_url: "https://www.mospi.gov.in/uploads/administration/administration1763118916877_6ccbd58f-135b-4f28-a0e7-1b349269b7cd_Order_dated_14.11.2025.pdf"
ministry: "Statistics and Programme Implementation (MoSPI)"
title: "Appointment of HOD in FOD, Regional Office, Delhi- regarding."
date: "2025-11-14"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c21fbc82a481d203"
---

<!-- page 1 -->

A-36011/01/2025-Ad.III

I/88885/2025

सं या / No. A-36011/01/2025-Ad.III [E- 77083]
भारत सरकार/Government of India
सां यक और काय म काया वयन मं ालय
Ministry of Statistics and Programme Implementation
******
खुश द लाल भवन / Khurshid Lal Bhawan,
जनपथ, नई िद ी / Janpath, New Delhi,
िदनांक / Dated: 14/11/2025
आदेश / ORDER
Under Rule 12 (2) of the Delegation of Financial Powers Rules, 2024 and in
accordance with this Ministry’s Order No. A-36011/02/2024-Ad.III [E-65792] dated
06.09.2024, approval of the Competent Authority is hereby conveyed for the
delegation of ﬁnancial powers of HOD in respect of Field Operations Division
(FOD), Regional Oﬃce (RO), Delhi to Shri Nagesh Kumar Singh, DDG, RO, Delhi
under the Delegation of Financial Powers Rules, 2024 and General Financial
Rules, 2017 as amended from time to time, with immediate effect.
2. These delegated powers are subject to the conditions as speciﬁed in Para 3 of
this Ministry’s Order No. A-36011/02/2024-Ad.III [E-65792] dated 06.09.2024 as
reproduced below:
(i)
All cases beyond powers shown in the Annexure-I and Annexure-II of
Order dated 06.09.2024 shall be sent to IFD and then for the approval of
concerned authority (DG / AS / JS and Secretary).
(ii)

The above delegated powers shall not be further delegated to any other

subordinate authority.
(iii)
The powers in respect of matters not covered in the said order shall be
as per DFPRs, 2024.
(iv)
In terms of Rule 12 (2) of DFPRs 2024, there shall be no re-delegation
of powers in respect of:
(a) Rule 10 - Re-appropriation of funds;
(b) Rule 15 - Waiver of recovery of over payment made to Government
servants; and

<!-- page 2 -->

A-36011/01/2025-Ad.III

I/88885/2025

(c) Rule 16 - Appraisal and approval of schemes or projects.
(v)
The general conditions, rules, orders and especially the restrictions
given in the DFPRs and the provisions of General Financial Rules, 2017 shall
apply in the exercise of powers by the concerned oﬃcers. In other words, this
order only lays down the upper ceiling limits in respect of ﬁnancial powers on
different subjects / items.
(vi)
The powers are subject to economy instructions issued by the Ministry
of Finance from time to time, Fiscal Codes and procedures and the limit being
within the budgetary allocation for the year.
(vii) The above delegations are subject to availability of funds and budgetary
limits.
(viii)
The proposals on release of funds shall be in accordance with the
approved terms of the project /scheme. If there is any deviation in fulﬁllment
of conditions for releasing funds as per provisions of schemes guidelines or
instructions issued from time to time, then the relaxation for the condition shall
be sought from competent authority i.e. Secretary (S&PI).
(ix)
In the case of scheme, before seeking concurrence of IFD, Subject
Matter Division (SMD) shall ensure that the scheme has been approved by the
Competent Authority and proposal is as per the provisions of the scheme.
(x)
The Heads of Departments have to refer all cases, for which they are
not empowered to sanction expenditure as per the aforesaid delegation, to this
Ministry for approval.
(xi)
The aforesaid delegation of powers is subject to compliance of GFRs,
2017 and instructions of Department of Expenditure in the matter, as amended
from time to time, conditions mentioned under DFPRs 2024, and clariﬁcations
issued thereunder from time to time.
(xii)
All instructions issued by Ministry of Finance and Ministry of Statistics
and Programme Implementation from time to time in this regard shall be
adhered to scrupulously by all the authorities exercising the Financial Powers
under this order.

<!-- page 3 -->

A-36011/01/2025-Ad.III

I/88885/2025

3.
This issues with the approval of the Competent Authority, Ministry of
Statistics and Programme Implementation.

(नीलम अरोड़ा / Neelam Arora)
अवर स चव, भारत सरकार
Under Secretary to the Government of India
To
1. DG (NSS), K. L. Bhawan, New Delhi
2. ADG (FOD), Sankhyiki Bhawan, Delhi
3. Shri Nagesh Kumar Singh, DDG, RO Delhi, Sankhyiki Bhawan, Delhi
4. Pay & Accounts Officer, PAO (P.I.), R. K. Puram, New Delhi
5. Pay & Accounts Officer, PAO (Statistics), R. K. Puram, New Delhi
6. Cash & Account Officer (P.I.), K. L. Bhawan, Janpath, New Delhi
7. Cash & Account Officer (Statistics), R. K. Puram, New Delhi
8. DS (Admin.&Vig.) /DS&HOD/DS (IFD), K. L. Bhawan, Janpath, New Delhi
9. US(Ad.I/V)/US(Ad.IV&Cash)/DD(Gen.)&HOO/US (Vig.), K. L. Bhawan,
Janpath, New Delhi.
Copy to:
1. Sr. PPS to Secretary (S&PI)
2. PPSs to DG (DG)/DG (CS)/AS (PI)/AS&FA
3. PPS to JS (Admin.)
Copy also to:
1. Joint Director, DIID, R. K. Puram, New Delhi with the request to place the
order on the website of the Ministry.
2. E-Oﬃce team, MoSPI with the request to upload the order on the e-oﬃce
portal of MoSPI.
