---
doc_id: "79b8bebcffd80c05"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/0a6fb38ead171c1d8e88d99b1c6a34f3.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "List of amendments carried out in ILs/Registrations"
date: "2025-07-21"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "05c6eeb70e0078fb"
---

<!-- page 1 -->

Ammendments carried out in Industrial Licences/Registrations
During July 1998
---------------------------------------------------------------------------------------------------------S.No.
Name of the Company
LOI No.
Amendments carried out
No.&Date
& Date
---------------------------------------------------------------------------------------------------------1.

M/s.The Indian Sugars&
Refinaries Ltd

82(98)
5.6.98

Amendment in item of mfr
and capacity.

LI:82(98)/98-amendment
7.7.98

2.

M/s.The West Coast Paper
Mills Ltd

141(96)
22.9.97

Change of location from
Dandeli to Kesara Halli in
Uttar Kannada in Karnataka.

LI:141(96)/98-amendment
30.7.98

3.

M/s.ATL Textiles Ltd

298(97)
5.11.97

Amendment in the item of mfr
and capacity.

LI:298(97)/98-amendment
14.7.98

4.

M/s.Shriram Industrial
Entreprises Ltd

337(96)
20.8.96

Change of location from
Maukas to Naglamal in Meerut

LI:337(97)/98-amendment
16.7.98

5.

M/s.Rishab Fibres Ltd

203(97)
22.9.97

Amendment in item of mfr and
capacity.

LI:203(97)/98-amendment
16.7.98

6.

M/s.Jindal Cotex Ltd

63(98)
26.5.98

Amendment in item of mfr and
capacity

LI:63(98)/98-amendment
16.7.98

7.

M/s.Chaudhary Labels(P)
Ltd.

410(94)
22.8.94

Amendment in item of mfr and
capacity.

LI:410(94)/98-amendment
21.7.98

8.

M/s.Bhaurao Chavan SSK
Ltd

333((90)
2.5.90

Change of location from Mundkhed
to Degaon in Nanded,Maharashtra

9.

LI:333(90)/98-amendment
24.7.98

M/s.Supreme Woolen Mills
6(96)
Amendment in the item of mfr.
LI:6(96)/98-amendment
20.7.98
Ltd
9.1.96
and capacity.
----------------------------------------------------------------------------------------------------------
