---
doc_id: "7a1cf21fa12bec1b"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/02-12-2019.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Corrigendum/Addendum for Annual contract for maintenance and repair of Air Conditioners in DoSJE"
date: ""
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "39d42e1dbd2a92be"
---

<!-- page 1 -->

|
| .
| No.D-13011/01/2019-Gen]-I
: Government of India
| Ministry of Social Justice & Empowerment
(Department of Social Justice & Empowerment)
| (General. II Section)
Shastri Bhawan, New Delhi-1
Dated 29" November, 2019
ADDENDUM
Subject : Annual Contract for maintenance & repair of Air Conditioners in the
| Department of Social Justice & Empowerment ~ reg.
The undersigned is directed to refer to this Department tender dated 13.11.2019
on the subject cited above and to state that the financial bid sheet for the tender for
maintenance & repair of Air Conditioners which was inadvertently left out to be
published in the Tender Notice is attached herewith.
2. The last date of submission of Bids is therefore extended to 09.12,2019 at 4.00
PM from 03.12.2019 and opening Technical Bid will be on 10.12.2019 at 5.00 PM
| (financial bids shall be considered in t/o those firms which will be found eligible as
per technical bid). .
3. All other criteria, terms & conditions will be remain same as mentioned in
tender notice dated 13.11.2019.
4
९०1४४ «७.19
(Paras Kumar Singh)
Under Secretary to the Govt. of India
Tel.No,23389836
Copy to :-
1. To be published in CPP Portal and Department of SJ&E web-site for wide
publicity.
|
|
|
|
|
|
|

<!-- page 2 -->

-48-
. No.D-13011/01/2019-GenI-IT
Government of India
Ministry of Social Justice & Empowerment
(Department of Social Justice & Empowerment)
(General.II Section)
FINANCIAL BID FOR REPAIRING AND MAINTENANCE OF AIR
| CONDITIONERS.
SI. Items/Description
=
e 0 ype
chemical wash, oiling, electrical equipment
| ie.stablizer etc. and general services)
Tr
| applicable) for the below:
|
1 [15Ton(eachy - ू्््््-/-[(£_$ रू |$ |
pT
[B. [Running capacitorfeachy | छ
Jo कमकझछझॉऑ््झ$*
7 D ee ्हक्#£/ |
[ |
| |$  '
if |
[/ 1 [/$ [|
pf  छढऊ
| |$ |
Replacement (by new) (each) Po | / | |
| ६ | 9$|
[1_[Relay(each) -- - ् ्ू्ृूृूृूृूृूऑूइ_1(ू[ £$ |
| $ ऋ फक्‍तऊ
| री  9७9७8छझ'
++ —-}
a ऑक्‍980ल
ee ee eee
(O_ | Valve (each) 1 | ४  ह् छू | |
[P[Airfilter(each) इन ६ [६ | | ,
Po  &$&$ | |
[ff | | ।
CO | ।
T [installation chargesteach) | ऑ# 66 | -  झऑऊ| ।
Signature with date: |
Name & address and contract no. of the firm:
Contd...49/-
९५ yy

<!-- page 3 -->

. -49-
हु No.D-13011/01/2019-Genl-I
Government of India
Ministry of Social Justice & Empowerment
(Department of Social Justice & Empowerment)
| (General.II Section)
SL Items/Description Rates (in Rs.)
का
e ९ ९
| De-installation charges(each Pe
Wiring kit (Heating/cooling) (each [TCO
Body replacement per unit Po | छ$ |
Stabilizer New (Blucbitd)(each) |“ $ |  ढेढ
|/$& | 6 ]'
| AC Plug | £#$£$ ऑफ9फस्‍ल्‍लल्‍ढ् |
Motor for Indoor Unit P| £ट'
AC Indoor plate Po
P|
[DD |NewSensor  ूूूू््([(ट/ | 6 |
|
Signature with date:
Name & address and contract no, of the firm:
Pe yy
|
|
