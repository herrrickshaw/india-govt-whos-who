---
doc_id: "7cbe4bacdfd32121"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/11/4e8370e1f3c2ca0b84d2746210d972fd.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Detailed procedure regarding engagement of counsel on behalf of UoI: OM dated 21.10.2019"
date: "2022-03-23"
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "d7b357e21f59ab77"
---

<!-- page 1 -->

1
F. No. J-12017/1/2019-Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi
Dated 21" October, 2019
OFFICE MEMORANDUM
Sub: Engagement of Counsel on behalf of Union of India — regarding.
As per the Government of India (Allocation of Business) Rules, 1961 the
Department of Legal Affairs has, inter-alia, been entrusted with the following functions:
(9 rersereeeee engagement of counsel to appear on behalf of the
Union of India in the High Courts and subordinate courts where the
Union of India is a party.
| (ii) Conduct of cases in the Supreme Court and the High Courts
on behalf of the Central Government and on behalf of the
Governments of States participating in the Central Agency Scheme.
2. To perform the above functions the Department of Legal Affairs has been
empanelling suitable Advocates as Law Officers {i.e. Attorney General for India,
Solicitor General of India and Additional Solicitors General of India (ASGIs)} , Assistant
Solicitors General of India (Asst. 5015) and various categories of Panel Counsel for
various courts / tribunals across the country. These panels are made for a particular
tenure after which either their tenures are extended or new panels are formed. Besides
this, some Ministries / Departments performing special / technical functions have been
authorized to select panel of counsels as per their specific requirements and the said
panel is finally approved by this Department. In addition to this, in some specific /
sensitive / high stake cases, proposals are received from various Ministries /
Departments of Central Government for the engagement of special counsel which are
considered by the Department of Legal Affairs on case to case basis. All the
engagements / appearances of Advocates for conducting Central Govt. litigation before
any court / tribunal without approval of this Department or contrary to the procedure
established are in violation of the provisions of the Govt. of India (Allocation of
Business) Rules, 1961.
3. Earlier, from time to time instructions have been issued by this Department.
Recently, OM Nos. 34(01)/2012-Judl. dated 05.12.2012 and OM No. 29(2)/2002-Judl.
(Pt.) dated 16.01.2015 have been issued.
4. Despite this, It has come to notice of this Department that various Ministries /
Departments of Govt. of India and their subordinate offices (especially at District level)

<!-- page 2 -->

2
are deviating from this procedure. Therefore, it has been decided to again issue a
detailed OM re-iterating compliance / guidance of all the Ministries / Departments and
their subordinate offices, described as under:
(A) Various Courts / Tribunals at Delhi:

In Delhi, there are attached offices of this Department viz. Central Agency
Section, Litigation (High Court/CAT) Section, Litigation (Lower Court) Section of this
Department which are responsible for engaging suitable panel counsel from the panel of
this Department for various courts / tribunals situated in Delhi as and when
notices/requests, in this regard, are received by them. Similarly, In-charge Central
Agency Section and In-charge Litigation (High Court) Section are responsible for
engagement of Law Officers for conducting Central Govt. litigation before the Supreme
Court of India and High Court of Delhi, respectively. Details in this regard are as under:

Name of the ee before = =~ which
office ____ engagements are made
1. | Incharge, Central Agency | Supreme Court of India
section ह
2 Incharge, Litigation ‘High | High Court of Delhi, Armed Forces Tribunal
Court/CAT) Section (PB), National Green Tribunal (PB) and CAT
(PB), New Delhi and other Tribunals/
____| Commissions situated in Delhi.
3. | Incharge, Litigation (Lower | District Courts, Dwarka, Rohini, Patiala
Court) Section House, Tis Hazari, Karkardooma and Saket
| __and other subordinate courts in Delhi. and other subordinate courts in Delhi.
B). Marious Courts / Tribunal at Mumbai, Kolkata, Chennai and Bengaluru:

There are four Branch Secretariats of this Department at Mumbai, Kolkata.
Chennai and Bengaluru working as subordinate offices who engage counsel from the
panel of this Department for respective court / tribunal (including High Court, CAT
Bench, AFT Bench, NGT Bench and District & Subordinate Courts) within their
jurisdiction.

C). Various High Courts / CATs / AFTs / NGTs in the country:

In places except the stations mentioned under para (A) to (B) above, the
engagement of counsel from the panel for respective court / tribunal is made by the
concerned In-charge litigation for that court / tribunal. The present position in this regard
is aS under:

ae No. Court/ Tribunal in-charge litigation (by Designation) (by Designation)

1. High Courts _#4ांणा॥| 50100 56189| ० India (ASGI) “|

| OR
| Assistant —im: | General of India (Asst. SGI) |
____ (ASGI will prevail if available)

<!-- page 3 -->

3
2. CAT, AFT,NG~ Concerned Senior CentralGovernment  — ]|
Benches Standing Counsel (Sr. CGSC) |
outside Delhi) | a
D). District _& Subordinate Courts in the country except at Delhi, Mumbai,

Kolkata, Chennai & Bengaluru:

For District & Subordinate Courts in the country except at Delhi, Mumbai.
Kolkata, Chennai & Bengaluru, the concerned Standing Government Counsel (SGC) is
the In-charge litigation who is entrusted with the task of allocation of cases amongst the
other panel counsel for the concerned District & Subordinate Courts, i.e. Additional
Standing Govt. Counsel (including the SGC).

5. All the Departments / subordinate offices of the Central Government are required
to directly contact the Litigation Incharge of the concerned court / tribunal as detailed in
para 4 (A) to (C) above, for the engagement of counsel / change of counsel (if required)
from the panel for that court / tribunal to represent Union of India in their cases. The
contact details of the concerned ASGI / Asst. SGI / Sr. CGSC/ SGC / Incharge of
Litigation Sections & Branch Secretariats are available on the official website of this
Department. Departments / subordinate offices of Central Government are advised to
ensure from time to time that the panel counsel who is representing them is still on the
panel of this Ministry. If the tenure of representing panel counsel expires before disposal
of the case, the concerned Litigation Incharge may be approached for the engagement
of another counsel from the panel. All the Ministries / Departments are advised not to
engage counsel who are not on the panel of this Ministry/Department without approval
of this Department.

6. In addition to the above, in this context, Item No. 9 (i) of the Annexure to
Schedule V of the Delegation o° Financial Power Rules (DFPR), 1978 is also referred
which clearly establishes the principle for the expenditure on account of Legal Charges
which needs to be paid to all kinds of Barristers, Advocates, Arbitrators, Pleaders and
Umpires representing Union of India before any court (including tribunals) in the
country only with the prior consent of this Ministry, and, in case of Law Officers/panel
counsel engaged by this Ministry, Legal Charges are to be paid as per the fee schedule
prescribed by this Department for the purpose.

7. In light of the above, engagement of counsel to represent Union of India
before any court / tribunal of the country, who are not on the panel of Ministry of
Law & Justice with running tenure and / or whose engagement has not been
approved by Ministry of Law & Justice, is violation of (i) the Government of India
(Allocation of Business) Rules, 1961 and (ii) the Delegation of Financial Powers of Business) Rules, 1961 and (ii) the Delegation of Financial Powers
Rules, 1978.

8. All the OMs of this Department referred above, Details of concerned Litigation
Incharges and details of Panel Counsel (in the form of orders of empanelment) are
available on official website of this Department i.e. www. legalaffairs.gov.in.

<!-- page 4 -->

4
9. This is for information of all the Ministries / Departments of the Government of
India and offices subordinate to them for strict compliance.
10. All the subordinate offices of this Department i.e. the Central Agency Section,
Branch Secretariat at Mumbai, Kolkata, Chennai and Bengaluru, all Litigation Sections
at New Delhi and all the Litigation In-charges before various courts / tribunals in the
country are also requested to ensure strict compliance of instructions contained in this
Circular and in case of any deviation this Department may be informed immediately.
11. This issues with the apprcval of Hon’ble Minister for Law & Justice.
yh _—
(S. R. Mishra)
Additional Secretary
To,
1. All the Ministries / Departments of Govt. of India (as per list enclosed) with request to give
wide publicity of the contents of this circular amongst all their subordinate offices.
2. The Comptroller & Auditor Seneral of India with request to give wide publicity of the contents
of this circular amongst all of their Audit units.
3. The Controller General of Accounts with request to give wide publicity of the contents of this
circular amongst all their PAOs/ZAOs/CDDOs across the country.
4. The Registrars of all the High Courts/CATs/AFTs/NGTs in the country and their Benches with
request to the give wide publicity of the contents of this Circular amongst all the District
Judges under their jurisdiction.
9. The Incharge, Branch Secretariats at Mumbai, Kolkata, Chennai & Bengaluru.
6. The Incharge, Central Agercy Section, Supreme Court of India.
7. The Incharge, Litigation (High Court/CAT/Lower Court) Section at New Delhi.
8. The Additional Solicitors General of India for the High Court of Punjab & Haryana, Allahabad.
Patna and Rajasthan.
9. All the Senior Central Govt. Standing Counsel for various CAT Benches, AFT Benches. NGT
Benches across the country.
10. All the Standing Govt. Counsel for various District & Subordinate Courts in the country.

<!-- page 5 -->

5
F. No. J-12017/1/2019-Judicial Dated : 21.10.2019
Copy to:
1. PS to Hon'ble MLJ/PS tc Law Secretary/PS to Legislative Secretary/ PS to all Additional
Secretaries/PS to all Joint Secretaries of Department of Legal Affairs.
2. PS to Additional Legal Adviser (Judicial) of Department of Legal Affairs.
3. The Assistant Legal Adviser (Judicial) of Department of Legal Affairs.
4. To be uploaded on website of the Department of Legal Affairs i.e. www. legalaffairs.gov.in
under tab ‘Judicial Section’ in the link ‘Circulars pertaining to litigation’.
5. Office/Spare Copies.
=
L=> - aA
~~ (D. Srinivas) =
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
