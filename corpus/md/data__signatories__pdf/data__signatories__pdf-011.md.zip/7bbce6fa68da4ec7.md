---
doc_id: "7bbce6fa68da4ec7"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/f78f6ea82984d20570e952a8b5d75b81.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Guidelines for investment of surplus funds by PSEs"
date: "2025-07-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5a7a7704931aaa64"
---

<!-- page 1 -->

Guidelines on investment of surplus funds by Public Sector Enterprises
The Joint Parliamentary Committee (JPC), which enquired into the irregularities in securities transactions
had adversely commented on certain decisions of the public sector enterprises in the matter of investment
of surplus funds. The Committee had desired that clear guidelines be laid down about investment of
surplus funds by public sector enterprises in order to ensure that no misuse of PSU funds recurs. In
pursuance of the observations of the JPC, the Government had issued detailed guidelines vide O.M. of
even number dated 14th December, 1994. However, as the guidelines dated 14th December, 1994 was a
broad outline of the policies in the matter of investment of surplus funds, a need for clarification on specific
points has been felt in view of certain queries made by the PSEs and the financial institutions. The
clarifications in continuation of the earlier guidelines of 14.12.1994 are given below:
a.

The guidelines dated 14th December, 1994 stipulate in para 2(i) and 2(ii) that there should be
no element of speculation on the yield in respect of investments made by PSUs. It is clarified
that PSUs therefore will not be allowed to invest their surplus funds in UTI and other public and
private mutual funds as they are equity based and are, therefore, inherently risky.

b.

Para 2(iii) of the earlier guidelines indicated that there should be a proper commercial
appreciation before any investment decision of surplus funds is taken, and that the availability of
surplus funds may be worked out for a minimum period of one year at any point of time. The
Government now feels that as the availability of surplus funds with the PSUs is for short
duration, the preparation of advance estimates of surplus funds for one year may be difficult.
The public enterprises are, therefore, advised to make their best estimates of the availability of
surplus funds in consultation with their administrative Ministry.

c.

Para 2(iv) of the earlier guidelines states that the remaining period of maturity of any instrument
of investment should not be exceeding one year from the date of investment where the
investment is made in an instrument already issued. The Government have now decided that
while one year ceiling on the remaining maturity period shall hold good for the general
instruments, the public enterprises can also select treasury bills and Government of India
securities up to three years maturity period for the investment of surplus funds.

d.

The guidelines of December, 1994 have stated that the Term Deposits may be made with any
scheduled commercial bank (i.e. bank incorporated in India) and with a paid up capital of atleast
Rs.100 Crores, fulfilling the capital adequacy norm as prescribed by the RBI from time to time. It
has now been decided that instead of the condition of Rs.100 Crores as paid up capital there
will be a condition of Rs.100 Crores as ‘net worth’ of the bank, i.e. the paid up capital plus free
reserves of the bank should not be less than Rs.100 Crores.

e.

The guidelines of 14th December, 1994 under Para 3(ii) envisage that the investment may be
made in instruments which have been rated by an established Credit Rating Agency and have
been accorded the highest credit rating signifying highest safety, e.g. Certificates of Deposits,
Deposit Scheme or similar instruments issued by scheduled commercial bank/term lending
institutions including their subsidiaries as well as commercial paper of corporates. It is clarified
that credit ratings issued by rating agencies are broadly classified as investment grade and noninvestment grade. Since "highest credit rating" would mean the top most in the investment

<!-- page 2 -->

grade, which would limit choice and probably lower the overall yield, PSUs will now be free to
invest in instruments falling under investment credit rating.
The earlier guidelines also envisage that inter-corporate loans shall be permissible to be lent
only to Central PSUs which have obtained highest credit rating awarded by one of the
established Credit Rating Agencies for borrowing for the corresponding period. The Government
reiterate that inter-corporate borrowing programme can also be credit rated by rating agencies
and the public enterprises may invest surplus funds only on the basis of such ratings. This
would help to avoid the instances of the enterprise providing friendly support to other enterprise
on considerations other than safety.
2. The public enterprises are advised to keep the above clarifications in view together with the guidelines
given in the OM of even number dated 14th December, 1994 before deciding investment of their surplus
funds in any instrument. Further, the existing holding of the enterprise in the UTI schemes or similar
schemes of various other public sector and private sector mutual funds have to be disinvested to fall in line
with these guidelines. Such investment may however be phased out without running the risk of capital loss
with due approval from the Boards of the public enterprises.
3. Administrative Ministries/Departments are requested to suitably advise the public enterprises under their
administrative control to strictly comply with these guidelines.
4. These guidelines are issued in consultation with the Ministry of Finance.
(DPE O.M. No. 4(6)/94-Fin dated 01/11/1995)
O.M. No. 4(6) 94-Fin. dated 11/03/1996
Guidelines on investment of surplus funds by PSUs
Reference is invited to the OM of even number dated 14.12.94 and the subsequent clarifications issued by
DPE vide OM dated 1.11.95 on the above mentioned subject. Through these OMs the PSUs were advised
that the investment of surplus funds in UTI and other public and private sector mutual funds should not be
made as they are inherently risky. The PSUs were further advised that the existing holdings of the
enterprises in UTI or other similar schemes of various other mutual funds be disinvested to fall in line with
these guidelines and such liquidation of holdings be phased out without running the risk of capital loss.
2. The matter has been further examined by the Government and it has now been decided that the existing
holdings of PSUs in various schemes of UTI and similar mutual funds schemes of other public sector and
private sector mutual funds may be phased out over a period of three years.
3. The administrative Ministries/Departments are requested to suitably advise the public enterprises under
their administrative control to strictly comply with these guidelines.
4. These guidelines are issued in consultation with Ministry of Finance.
***
