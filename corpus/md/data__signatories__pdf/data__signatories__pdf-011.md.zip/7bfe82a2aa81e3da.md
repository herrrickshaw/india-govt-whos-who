---
doc_id: "7bfe82a2aa81e3da"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/84d949e0b03129bbead7200cd89fd2ab.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Letter to ISP Cs Comm no 605 of 2021 dated 29.01.2024"
date: "2024-01-29"
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "af7796a6b52f5125"
---

<!-- page 1 -->

Government

of India

BY EMAIL & DoT Website

Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Services Cell)
No. 813-07/LM-37/2021-DS-II
To,

Dated:29.01.2024

All Internet Service Licensees’

Subject: CS (COMM) No. 605 of 2021; Universal City Studios LLC & Ors. v/s_
dramacool.news & Ors. before Hon’ble Delhi High Court.
Kindly refer to the following:
Hon’ble Delhi High Court order dated 19.01.2024 and 22.01.2024 on the subject.
Para 7 of Hon’ble Delhi High Court order dated 26.11.2021 regarding blocking of
website identified by plaintiff.
Memo
Parties in CS (Comm) No. 605 of 2021

(i)
(ii)

of

(iii)

(Copies enclosed for ready reference)
In view of the above all the Internet Service licensees are hereby instructed to take

De

immediate necessary action for blocking access to 07 websites of defendants no. 94 to 99.

Email: dirds2-dot@nic.in
Encl: A/A

Copy to:
(i)

Sh. V.Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics Niketan,
Ministry of Electronics and Information Technology (MeitY) New Delhi for kind
information and with request to take action as per Annexure.

(ii)

Sanidhya Rao, Saikrishna & Associates (sanidhya@saikrishnaassociates.com) Plaintiff
Advocate for kind information.
a)

(iii)

Take action as per Annexure.

IT wing of DoT for uploading on DoT website.

<!-- page 2 -->

$~27
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 605/2021
UNIVERSAL CITY STUDIOS LLC AND ORS
Through:

..... Plaintiff
Ms. Ramya Ramkumar, Mr.
Raghav Goyal and Ms.
Ashta Sehgal, Advs.

versus
DRAMACOOL.NEWS AND ORS
Through:

%

..... Defendant
Mr. Ajay Digpaul, CGSC,
Adv. for R- 35 and 36.

CORAM:
SIDHARTH MATHUR (DHJS), JOINT REGISTRAR
(JUDICIAL)
ORDER
19.01.2024
List the matter for the purpose fixed on the date fixed i.e.

25.04.2024.
In the meantime, issue summons to the newly impleaded
defendants no. 94 to 98, through all permissible modes preferably
email, subject to filing of PF.

IA No. 1342/2024 (on behalf of the plaintiffs u/Order 1 Rule 10
of CPC seeking impleadment of additional mirrors, redirects,
or alphanumeric variations as defendants in the memo of
parties)
The

plaintiffs

are

seeking

to

implead

additional

mirrors/re-directs/alpha-numeric variations, as defendant nos. 94 to
98 since they are illegally distributing the copyrighted content of
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 19/01/2024 at 18:34:01

<!-- page 3 -->

the plaintiff. The relevant details of these proposed defendants are
mentioned in para no. 2 of this application. Keeping in view the
nature of the suit, this application is allowed.
The amended memorandum of parties is already on record.

SIDHARTH MATHUR (DHJS)
JOINT REGISTRAR (JUDICIAL)
JANUARY 19, 2024/jr

Click here to check corrigendum, if any

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 19/01/2024 at 18:34:01

<!-- page 4 -->

$~26
COURT OF DELHI
**
IN THE HIGH
DELHI AT NEW DELHI
DELHI
HIGH COURT
605/2021
+
CS(COMM)
CS(COMM) 605/2021
UNIVERSAL CITY STUDIOS
STUDIOS LLC AND ORS
UNIVERSAL
.....
bees Plaintiff
Through:
Ms. Ramya
Ramkumar,
Ramkumar,
Through:
Ramya
Adv.
Adv.
(M- 9845057887).
9845057887).
versus
versus
DRAMACOOL.NEWS AND ORS
DRAMACOOL.NEWS
Defendant
.....
— Defendant
None.
Through:
None.
Through:
CORAM:
CORAM:
SIDHARTH
SIDHARTH MATHUR
MATHUR (DHJS), JOINT REGISTRAR
REGISTRAR
(JUDICIAL)
(JUDICIAL)
O
RDER
ORDER
“%
22.01.2024
%
22.01.2024

OF

The file
on
The
file is being taken up
the oral request
request on behalf of the
up on
the

order
correction of the typographical
plaintiff for the correction
typographical error in the order
references to the
19.01.2024. In that order, there have been references
dated 19.01.2024.
98. Though
service of defendant
defendant nos. 94 to 98.
impleadment
impleadment and service
Though as per
per

defendant nos. 94
record,
record, those ought to have been with regard to defendant
98. This mistake
defendant no.
mistake is
to 99 and not only till defendant
no. 98.

corrected. So any
reference to “defendant
accordingly
nos. 94 to
accordingly corrected.
“defendant nos.
any reference
be
19.01.2024 shall now be
98” in the order dated 19.01.2024
read as “defendant
“defendant
read

99”.
nos.
nos. 94 to 99”.
This order be read as the corrigendum
This
corrigendum of
of the order dated
19.01.2024.
19.01.2024.
Le.
List the matter
matter for the purpose
purpose fixed on the date fixed i.e.

25.04.2024.
25.04.2024.

SIDHARTH
SIDHARTH MATHUR
MATHUR (DHJS)
JOINT REGISTRAR
REGISTRAR (JUDICIAL)
(JUDICIAL)
JANUARY 19, 2024/jr
JANUARY
Click here to check corrigendum,
Click
corrigendum, if
if any
any

19,

This is a digitally
order.
This
digitally signed
signed order.
be
shown above.
The authenticity of the
the order
from Delhi
Delhi High
Order Portal by
the QR
The
re-verified from
above.
QR code shown
order can be
High Court Order
by scanning
re-verified
scanning the

The Order
Order is downloaded
from the DHC Server
24/01/2024 at 11:06:15
11:06:15
The
downloaded from
Server on 24/01/2024

<!-- page 5 -->

$~21
*
IN THE HIGH COURT OF DELHI AT NEW DELHI
+
CS(COMM) 605/2021
UNIVERSAL CITY STUDIOS LLC AND ORS
..... Plaintiffs
Through: Mr.Sidharth Chopra, Ms.Suhasini
Raina, Ms.Disha Sharma, Ms.Surabhi
Pande and Ms.Sanidhya Rao,
Advocates.
versus
DRAMACOOL.NEWS AND ORS
..... Defendants
Through: None.
CORAM:
HON'BLE MR. JUSTICE YOGESH KHANNA
ORDER
%
26.11.2021
I.A. Nos. 15474/2021 and 15476/2021
1.
Exemption allowed, subject to all just exceptions.
2.

The application/s stand disposed of.

CS(COMM) 605/2021, I.A. Nos. 15473/2021 and 15475/2021
3.

Plaintiffs have filed this suit for permanent injunction for infringing

the plaintiffs’ exclusive rights, copyright, rendition of accounts and damages
etc against the defendants.
4.

Summons of the suit and notice of applications be issued to the

defendants through all modes/email and whatsapp returnable on 10.03.2022
before the learned Joint Registrar.
5.

It is alleged the plaintiffs No.1to 6 are a leading global entertainment

companies engaged in the business of creation, production, distribution of
motion pictures / cinematograph films. The plaintiffs have exclusive rights
to communicate their contents. No other entity can, without authorization
from the Plaintiff, upload, stream, make available for download,
communicate to the public the plaintiffs’ content i.e. films and series etc.

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/01/2024 at 17:25:32

<!-- page 6 -->

6.

The plaintiffs have further observed that the defendants No.1-25

(“Rogue Websites”) herein are engaged in primarily and substantially
making

available

for

the

public

hosting/download/streaming/

communicating the plaintiff’s content without authorisation.
7.

The defendants No.26 - 34 are Internet Service Providers which are

being arrayed for the limited purpose of blocking / restricting access to the
rogue websites identified in the present suit or any other website(s).

The

defendants No.35-36 are Department of Telecommunication and Ministry of
Electronics and Information Technology respectively which are government
department and being arrayed for the limited purpose of issuing notification
calling upon the internet and telecom service providers to block access to the
Rogue Defendants’ websites identified in the present suit, as also such other
websites which are subsequently discovered to be infringing the rights of the
plaintiff. The defendant No. 37 is “Ashok Kumar(s)”. No formal relief has
been sought against the Defendant Nos.26-36. The defendants No.1-25 are
anonymous websites and their details of owners are hidden or are forged
/inaccurate. These websites are vehicles of infringement and engaged in
flagrant violation of the Intellectual Property Rights of the plaintiffs, hence
the present suit. To prove the allegations of infringement of plaintiffs’
exclusive right in its contents, the plaintiffs have also filed various
documents on record.
8.

In view of above, the plaintiff has made out a prima facie case and in

case the defendants are not restrained ex parte, the plaintiffs shall suffer
irreparable loss and injury.
9.

Accordingly, till the next date of hearing, the defendants are

restrained in terms of prayers No.5(i) to 5(iii) of the injunction application.

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/01/2024 at 17:25:32

<!-- page 7 -->

10.

Compliance of Order 39 Rule 3 of the CPC be made within ten days.

11.

The defendants No.26 to 36 shall take immediate steps to comply with

above order.
12.

Upon completion of service/pleadings, the matter be listed before this

Court.
13.

Order dasti.

YOGESH KHANNA, J
NOVEMBER 26, 2021
M

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 24/01/2024 at 17:25:32

<!-- page 8 -->

23
COURT OF
DELHI AT NEW DELHI
DELHI
IN THE HIGH COURT
OF DELHI

ORIGINAL COMMERCIAL
COMMERCIAL JURISDICTION)
(ORDINARY
(ORDINARY ORIGINAL
JURISDICTION)

LA.NO.

I.A. NO. ______ OF 2024
IN

2021
CS(COMM)
CS(COMM) NO. 605 OF 2021

OF

MEMO OF PARTIES
AMENDED MEMO
PARTIES
AMENDED

(1)

Universal City Studios
Studios LLC.
Universal

its

having its office at
having

100 Universal
Universal City Plaza, Universal
Universal City,
100

CA 91608,
America,
91608, United States of America,
Email: antipiracy@nbcuni.com
Email:
antipiracy@nbcuni.com

(2)

Entertainment Inc.
Bros. Entertainment
Warner Bros.
Inc.

its

having its office at
having

Warner Boulevard,
4000 Warner
Boulevard, Burbank,
Burbank,
California 91522,
California
91522, United States of America
Email: antipiracy@warnerbros.com
Email:
antipiracy@warnerbros.com

(3)

Columbia Pictures
Columbia
Pictures Industries,
Industries, Inc.

its

having its office at
having

W. Washington
Culver City,
10202 W.
10202
Washington Blvd., Culver

90232-3195 United States of America,
CA 90232-3195
America,
Email: copyright_agent@spe.sony.com
Email:
copyright_agent@spe.sony.com

(4)

Netflix Studios,
Netflix
Studios, LLC

its

having its office at
having

100 Winchester
Winchester Cir Los Gatos
100

CA, 95032-1815,
America,
95032-1815, United States of America,

<!-- page 9 -->

24
Email: legal@netflix.com
Email:
legal@netflix.com

(5)

Pictures Corporation
Paramount Pictures
Paramount
Corporation

its

having its office at
having

Melrose Avenue,
5555 Melrose
Avenue, Hollywood,
Hollywood,

CA, 90038,
America,
90038, United States of America,
Email: CopyrightAgent@Paramount.com
Email:
CopyrightAgent@Paramount.com

(6)

Disney
Disney Enterprises,
Enterprises, Inc.

its

having its office at
having

500 S. Buena Vista, Burbank,
Burbank,
CA, 91521,
America,
91521, United States of America,
Email: tips@disneyantipiracy.com
Email:
tips(@disneyantipiracy.com
Plaintiffs
…
... Plaintiffs
Versus
Versus

(1)

dramacool.news
dramacool.news
dramacool.info
dramacool.info
dramacool.sk
dramacool.sk
dramacool.bid
dramacool.bid
dramacool.movie
dramacool.movie
dramacool.video
dramacool.video
dramacool.so
dramacool.so

dramacool.io
dramacoo1.io
dramacool.xyz
dramacool.xyz
watchasian.so
watchasian.so
watchasian.in
watchasian.in
information: drama.reply@gmail.com,
Contact information:
Contact
drama.reply@gmail.com,
abuseabuse@namecheap.com,
abuse@namecheap.com, abuse-

contact@publicdomainregistry.com,
contact@publicdomainregistry.com,

<!-- page 10 -->

25
a8b8b96ea340469cacd2 fb463 f2cc2ee.protect@withh
a8b8b96ea340469cacd2fb463f2cc2ee.protect@withh

eldforprivacy.com,
eldforprivacy.com, sknic@elbiahosting.sk,
sknic@elbiahosting.sk,
d6839230f1 ad4db4a86e6790a98f6bfd.protect@withh
d6839230f1ad4db4a86e6790a98f6bfd.protect@withh

eldforprivacy.com
eldforprivacy.com
(2)

123mkv.tel
123mkv.tel
123mkv.onl
123mkv.onl
123mkv.wtf
123mkv.wtf

123mkv.fyi
123mkv.fyi
123mkv.vip
123mkv.vip
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(3)

1 filmy4wap.art
1filmy4wap.art
1 filmy4wap.photos
1filmy4wap.photos
1 filmy4wap.onl
1filmy4wap.onl
1 filmy4wap.tube
1filmy4wap.tube
1 filmy4wap.in
1filmy4wap.in

1filmy4wap.website
1filmy4wap.website
information: filmywebrip@gmail.com,
Contact information:
Contact
filmywebrip@gmail.com,

abuse@namecheap.com,
abuse@namecheap.com, abuse@registrar.eu
abuse@registrar.eu
(4)

actvid.com
actvid.com
information: abuse@namecheap.com,
Contact information:
Contact
abuse@namecheap.com,

1af8e06dceb140ceac57fd10a96dfc3a.protect@withhe
laf8e06dceb140ceac57fd10a96dfc3a.protect@withhe
ldforprivacy.com
Idforprivacy.com
(5)

allmovieshub.co
allmovieshub.co

allmovieshub.org
allmovieshub.org
hdmoviehubs.site
hdmoviehubs.site
allmovieshub.in
allmovieshub.in

<!-- page 11 -->

26
information: admin@allmovieshub.org,
Contact information:
Contact
admin@allmovieshub.org,

abuse@registrar.eu,
abuse@registrar.eu, domains@hostinger.com,
domains@hostinger.com,
abuse@namecheap.com
abuse@namecheap.com
(6)

animeflix.in
animeflix.in
information: https://animeflix.in/dmca/
Contact information:
Contact
https://animeflix.in/dmca/

(7)

azseries.org
azseries.org
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(8)

bflix.to
bflix.to
information: contact.bflix@gmail.com
Contact information:
Contact
contact.bflix@gmail.com

(9)

desiremovies.tools
desiremovies.tools
desiremovies.cfd
desiremovies.cfd

desiremovies.digital
desiremovies.digital
desiremovies.one
desiremovies.one
desiremovies.immo
desiremovies.immo
information:
Contact information:
Contact

desiremovies.world@gmail.com,
desiremovies.world@gmail.com,
abuse@namecheap.com
abuse@namecheap.com
(10) dopebox.to
dopebox.to
dopebox.net
dopebox.net
information: abuse@namebright.com,
Contact information:
Contact
abuse@namebright.com,

dopebox.net@namebrightprivacy.com
dopebox.net@namebrightprivacy.com
(11) evo1.to
evol.to
evo1.net
evo l.net

<!-- page 12 -->

27
information: abuse@namecheap.com,
Contact information:
Contact
abuse@namecheap.com,
59b96eb8 1 f9f4c68aba404360d8099ec.protect@withh
59b96eb81f9f4c68aba404360d8099ec.protect@withh

eldforprivacy.com
eldforprivacy.com
f2movies.to
(12) f2movies.to
information:
Contact information:
Contact

https://www6.f2movies.to/contact
https://www6.f2movies.to/contact
fbox.to
(13) fbox.to
information: contact.fbox@gmail.com
Contact information:
Contact
contact.fbox@gmail.com
hdmovie5S.me
(14) hdmovie5.me

hdmovieS.in
hdmovie5.in
hdmovieS5.co
hdmovie5.co

hdmovie5.vip
hdmovieS5.vip
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(15) hdprimehub.co.in
hdprimehub.co.in
hdprimehub.one
hdprimehub.one
hdprimehub.com
hdprimehub.com
information: compliance@tucows.com
Contact information:
Contact
compliance@tucows.com
himovies.to
(16) himovies.to
information:
Contact information:
Contact

https://www5.himovies.to/contact
https://www5.himovies.to/contact
hurawatch.ru
(17) hurawatch.ru
information: hurawatch@gmail.com
Contact information:
Contact
hurawatch@gmail.com
movies2watch.tv
(18) movies2watch.tv

<!-- page 13 -->

28
information: abuse@namecheap.com,
Contact information:
Contact
abuse@namecheap.com,
25b1d79 1 bcc24aa2949e9a4aecfdd209.protect@withh
25b1d791bcc24aa2949e9a4aecfdd209.protect@withh

eldforprivacy.com
eldforprivacy.com
movies7.to
(19) movies7.to
information: movies7.inbox@gmail.com
Contact information:
Contact
movies7.inbox@gmail.com

(20) watchonlinemovies50.com.pk
moviesmanha.xyz
moviesmanha.xyz
moviesmanha7.com
moviesmanha7.com
moviesmanha.com
moviesmanha.com
Information:
Contact Information:
Contact

moviesmanha@protonmail.com,
moviesmanha@protonmail.com,
abuse@namecheap.com,
abuse@namecheap.com,
7£056e06b9cf4£589988c5b9561d24f8 protect@withh
7f056e06b9cf4f589988c5b9561d24f8.protect@withh

eldforprivacy.com,
eldforprivacy.com,
79c0553cde604770b6685e24b20d6d56.protect@with
79c0553cde604770b6685e24b20d6d56.protect@with
heldforprivacy.com
heldforprivacy.com
(21) moviesnation.org
moviesnation.org
information: admin@moviesnation.org,
Contact information:
Contact
admin@moviesnation.org,

abuse@ownregistrar.com
abuse@ownregistrar.com
(22) musichq.net
musichq.net
information: abuse@namecheap.com,
Contact information:
Contact
abuse@namecheap.com,
0£595c42864d455b90eb2735 16428c74.protect@with
0f595c42864d455b90eb273516428c74.protect@with

heldforprivacy.com
heldforprivacy.com
olamovies.one
(23) olamovies.one

olamovies.vip
olamovies.vip

<!-- page 14 -->

29
olamovies.me
olamovies.me
olamovies.us
olamovies.us
information: abuse@porkbun.com,
Contact information:
Contact
abuse@porkbun.com,

justinlplummer5@gmail.com
(24) primewire.es
primewire.es
information: primewirees@gmail.com
Contact information:
Contact

(25) tamilgun.pl
tamilgun.pl
tamilgun.tw
tamilgun.tw
information: support@name.com,
Contact information:
Contact
support@name.com,

tamilgun.tw@protecteddomainservices.com
(26) Atria Convergence
Technologies Pvt. Ltd.
Convergence Technologies
99A/113A,
99A/113A, Manorayana
Manorayana Palya
— 560032
560032
R.T. Nagar Bangalore
Bangalore –

Also At:
No. 1,
2nd and 3rd Floor, No.
1,

Indian Express
Indian
Queen’s Road,
Building, Queen’s
Express Building,
Karnataka
560001 Karnataka
Bangalore
Bangalore 560001

nodal.term@actcorp.in;
nodal.term@actcorp.in;
Jitesh.chathambil@actcorp.in
Jitesh.chathambil@actcorp.in
Bharat Sanchar
Sanchar Nigam Ltd.
(27) Bharat
Bharat Sanchar
Sanchar Bhawan,
Bharat
Bhawan, Regulation
Regulation Cell
Chandra Mathur
Mathur Lane
5th floor, Harish Chandra
-110001
Janpath,
Janpath, New Delhi -110001

ddg_reg@bsnl.co.in;
ddg reg@bsnl.co.in; sbkhare@bsnl.co.in
sbkhare@bsnl.co.in
sushmamishra7 1@gmail.com
averma@bsnl.co.in;
averma@bsnl.co.in; sushmamishra71@gmail.com

<!-- page 15 -->

30
(28) Bharti Airtel Ltd.
Tower-A, 6th
Airtel Centre,
Airtel
6th floor
Centre, Tower-A,

‘A’Wing,
No.16, Udyog
‘A’Wing, Plot No.16,
Udyog Vihar
122016
Ph -- IV, Gurgaon
– 122016
Gurgaon —
121 @in.airtel.com; compliance.officer@bharti.in;
121@in.airtel.com;
compliance.officer@bharti.in;

Ravi.gandhi@airtel.com;
jyoti.pawar@in.airtel.com ;; Ravi.gandhi@airtel.com;

amit.bhatia@airtel.com
amit.bhatia@airtel.com
Datacom Pvt. Ltd.
(29) Hathway
Hathway Cable & Datacom
Avenue
'Rahejas',4
"Rahejas',4 floor, Main Avenue
Mumbai-400054
Santacruz (W), Mumbai-400054
Santacruz

ajay.singh@hathway.net;
ajay.singh@hathway.net;
Sudhir.shetye@hathway.net
Sudhir.shetye@hathway.net
(30) Mahanagar Telephone
Telephone Nigam Ltd.
Sadan
5th Floor, Mahanagar
Mahanagar Doorsanchar Sadan

9, CGO Complex,
Complex, Lodhi Road
110003
New Delhi —– 110003

raco.mtnl@gmail.com;
raco.mtnl@gmail.com; mtnlcsco@gmail.com
mtnlcsco@gmail.com
gmracomtnl@gmail.com
gmracomtnl@gmail.com
Reliance Jio Infocomm
Infocomm Limited
Limited
(31) Reliance

4,

14 (TC 23), Phase
Phase 4,
RCP 14

B-Block ,, 3rd Floor,
B-Block
130 TwaneTwane- belapur Road,
C 4 130

Gansoli,
Gansoli,
Mumbai- 400701
400701
Navi Mumbai-

care@jio.com;
care@jio.com; Hitesh.marthak@relianceada.com;
Hitesh.marthak@relianceada.com;

<!-- page 16 -->

31
31
Kapoor.guliani@ril.com;
Kapoor.guliani@ril.com; mahipal.singh@ril.com;
mahipal.singh@ril.com;
sunil.kr.gupta@ril.com;
sunil.kr.gupta@ril.com; shilpi.kant@ril.com;
shilpi.kant@ril.com;

jyoti.jain@ril.com
(32) Shyam
Shyam Spectra
Spectra Pvt. Ltd.
No. 258,
Plot No.
Phase III,
Okhla Industrial
Industrial Estate,
Okhla
III,
Estate, Phase

110020
New Delhi —– 110020

Also at:
at:
No. 21-22, 3rd Floor
Plot No.
-122015
Udyog
Udyog Vihar, Phase IV, Gurugram
Gurugram -122015

info@spectra.co;
info@spectra.co; compliance@spectra.co
compliance@spectra.co
Teleservices Ltd.
(33) Tata Teleservices
Blocks
A, E & F Blocks
T. B.
B. Kadam
Voltas Premises
Premises -- T.
Kadam Marg
Voltas

Mumbai —
400033
Chinchpokli,
– 400033
Chinchpokli, Mumbai

pravin.jogani@tatatel.co.in;
pravin.jogani@tatatel.co.in;
anand.dalal@tatatel.co.in;
anand.dalal@tatatel.co.in; satya.yadav@tatatel.co.in
satya.yadav@tatatel.co.in
Vodafone India Limited
Limited
(34) Vodafone
Vodafone House,
Vodafone
House,

Peninsula Corporate
Corporate Park,
Kadam Marg,
Ganpatrao
Ganpatrao Kadam
Marg,
013 India
Mumbai -- 400 013
Lower Parel,
Lower
Parel, Mumbai

Also At:
Birla Centurion,
Centurion,
10th Floor,
10th
Floor, Plot no.794,
no.794,

<!-- page 17 -->

32
B Wing, Pandurang
Pandurang Budhkar Marg,

-

Mumbai - 400 030 India
Worli,
Worli, Mumbai

smitha.menon@vodafoneidea.com;
smitha.menon@vodafoneidea.com;
pankaj.kapdeo@vodafoneidea.com
Radhika.gokhale@vodafoneidea.com;
Radhika.gokhale@vodafoneidea.com;
sheena.thukral@vodafoneidea.com;
sheena.thukral@vodafoneidea.com;
sanjeet.sarkar@vodafoneidea.com;
sanjeet.sarkar@vodafoneidea.com;
lavati.sairam@vodafoneindia.com
lavati.sairam@vodafoneindia.com
Telecommunications
(35) Department
Department of Telecommunications

Through
Secretary,
Through Secretary,
Communications and
Ministry of Communications
and IT,
Sanchar Bhawan,
Ashoka Road,
20, Sanchar
Bhawan, Ashoka
110001
New Delhi —– 110001

adetds2secy-dot@nic.in,
secy-dot@nic.in, dirds2-dot@nic.in,
dirds2-dot@nic.in, adetds2-

dot@gov.in
dot@gov.in
Electronics and Information
Information Technology
(36) Ministry of Electronics
Technology
Director General
General (DIT) Cyber
Through
Through the Director
Cyber Laws &

e-security),
e-security),
Electronics Niketan,
Electronics
Niketan, 6, CGO Complex,
Complex,
110003
Lodi Road,
– 110003
Road, New Delhi —

cyberlaw-legal@meity.gov.in
cyberlaw-legal@meity.gov.in
Kumars
(37) Ashok Kumars

(38) primewire.top
primewire.top
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(39) primewire.li
primewire.li

<!-- page 18 -->

33
information:
Contact information:
Contact

primewire.inbox@protonmail.com
(40) watchonlinemovies77.com.pk
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
moviesmanha24.com
(41) moviesmanha24.com
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
dramacool9.co
(42) dramacool9.co
information: compliance@tucows.com
Contact information:
Contact
compliance@tucows.com
dramacool.bz
(43) dramacool.bz
information: abuse@godaddy.com
Contact information:
Contact
abuse@godaddy.com

(44) dramacool.pk
dramacool.pk
information: compliance@tucows.com
Contact information:
Contact
compliance@Wtucows.com
dramacool.ac
(45) dramacool.ac
information: abuse@godaddy.com
Contact information:
Contact
abuse@godaddy.com
hurawatch. it
(46) hurawatch.it
information: hurawatch@gmail.com
Contact information:
Contact
hurawatch@gmail.com
dramacool.sr
(47) dramacool.sr
information: drama.reply@gmail.com
Contact information:
Contact
drama.reply@gmail.com
dramacool.cm
(48) dramacool.cm
information: dramacoolinfo@gmail.com,
Contact information:
Contact
dramacoolinfo@gmail.com,

imasifrasool00@gmail.com
imasifrasool00@gmail.com

<!-- page 19 -->

34
moviesnation.uk
(49) moviesnation.uk
information: admin@moviesnation.in,
Contact information:
Contact
admin@moviesnation.in,

admin@moviesnation.org
admin@moviesnation.org
moviesnation.nl
(50) moviesnation.nl
information: admin@moviesnation.in,
Contact information:
Contact
admin@moviesnation.in,

admin@moviesnation.org
admin@moviesnation.org
moviesnation.lol
(51) moviesnation.lol
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(52) olamovies.cyou
olamovies.cyou
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com

(53) olamovies.wtf
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com
olamovies.website
(54) olamovies.website
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com

(55) hurawatch.pro
hurawatch.pro
information: abuse@nic.ru
Contact information:
Contact
abuse@nic.ru
movies2watch.cc
(56) movies2watch.cc
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
movies2watch.is
(57) movies2watch.is
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
movies2watch.ru
(58) movies2watch.ru

<!-- page 20 -->

35
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(59) himovies.top
himovies.top
information: domainabuse@tucows.com
Contact information:
Contact
domainabuse@tucows.com
hurawatch.at
(60) hurawatch.at
information: darksolar.team@gmail.com
Contact information:
Contact
darksolar.team@gmail.com
hurawatch.cc
(61) hurawatch.cc
information: abuse@sarek.fi
Contact information:
Contact
abuse@sarek.fi

(62) primewire.today
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(63) primewire.id
information: info@belidomain.co.id
Contact information:
Contact
info@belidomain.co.id

(64) tamilgun.news
tamilgun.news
information: abuse@name.com
Contact information:
Contact
abuse@name.com

(65) tamilgun.bio
tamilgun.bio
information: abuse@name.com
Contact information:
Contact
abuse@name.com

(66) tamilgun.org
tamilgun.org
information:
Contact information:
Contact

abuse@publicdomainregistry.com
abuse@publicdomainregistry.com
(67) tamilguns.vip
tamilguns.vip
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com

<!-- page 21 -->

36
(68) tamilguns.org
tamilguns.org
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com

(69) moviesnation.vip
moviesnation.vip
information: admin@moviesnation.in,
Contact information:
Contact
admin@moviesnation.in,

abuse@namecheap.com
abuse@namecheap.com
moviesnation.mx
(70) moviesnation.mx
information: admin@moviesnation.in,
Contact information:
Contact
admin@moviesnation.in,

abuse@namecheap.com
abuse@namecheap.com
moviesnation.tv
(71) moviesnation.tv
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(72) moviesnation.pw
moviesnation.pw
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
moviesnation.de
(73) moviesnation.de
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
watchasian.id
(74) watchasian.id
information: info@belidomain.co.id
Contact information:
Contact
info@belidomain.co.id
dramacool9.se
(75) dramacool9.se
information: drama.reply@gmail.com
Contact information:
Contact
drama.reply@gmail.com

(76) dramacool.cy
dramacool.cy
information: drama.reply@gmail.com
Contact information:
Contact
drama.reply@gmail.com
dramacool.cr
(77) dramacool.cr

<!-- page 22 -->

37
information: domains@marcaria.com
Contact information:
Contact
domains@marcaria.com
dramacool.do
(78) dramacool.do
information: drama.reply@gmail.com,
Contact information:
Contact
drama.reply@gmail.com,

info@nic.do
info@nic.do
dramacool.ba
(79) dramacool.ba
information: drama.reply@gmail.com
Contact information:
Contact
drama.reply@gmail.com

(80) desiremovies.motorcycles
desiremovies.motorcycles
information:
Contact information:
Contact

desiremovies.world@gmail.com,
desiremovies.world@gmail.com,
abuse@namecheap.com
abuse@namecheap.com
desiremovies.codes
(81) desiremovies.codes
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(82) desiremovies.gold
desiremovies.gold
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
desiremovies.asia
(83) desiremovies.asia
information: abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com

(84) olamovies.quest
olamovies.quest
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com
olamovies.best
(85) olamovies.best
information: abuse@porkbun.com
Contact information:
Contact
abuse@porkbun.com
movies7.io
(86) movies7.io

<!-- page 23 -->

38
information tld-abuse@nic.ru
Contact information:
Contact
thd-abuse@nic.ru
:

(87) dramacool.pa
dramacool.pa
information drama.reply@gmail.com
Contact information:
Contact
drama.reply@gmail.com
:

dramacool.hr
(88) dramacool.hr
information:
Contact information:
Contact

animeflix.net.in
(89) animeflix.net.in
information abuse@godaddy.com
Contact information:
Contact
abuse@godaddy.com
:

hurawatch.art
(90) hurawatch.art
information abuse@namecheap.com
Contact information:
Contact
abuse@namecheap.com
:

movies2watch.to
(91) movies2watch.to
information:
Contact information:
Contact

moviesnation.cx
(92) moviesnation.cx
information support@centralnic.com
Contact information:
Contact
Support@centralnic.com
:

(93) musichqfree.me
musichqfree.me
information admin@musichqfree.me,
Contact information:
Contact
admin@musichqfree.me,
:

abuse@namecheap.com
abuse@namecheap.com
dramacool.tube
(94) dramacool.tube
Information: abuse@namecheap.com
Contact Information:
Contact
abuse@namecheap.com

(95) dramacool.vip
dramacool.vip
Information: abuse@dynadot.com
Contact Information:
Contact
abuse@dynadot.com

<!-- page 24 -->

39
moviesnation.dev
(96) moviesnation.dev
Information: abuse@namecheap.com
Contact Information:
Contact
abuse@namecheap.com
admin@moviesnation.in
admin@moviesnation.in
moviesnation.wiki
(97) moviesnation.wiki
Information: abuse@namecheap.com
Contact Information:
Contact
abuse@namecheap.com
moviesnation.art
(98) moviesnation.art
Information: abuse@namecheap.com
Contact Information:
Contact
abuse@namecheap.com

(99) musichq.pe
musichq.pe
Information: noreply@data-protected.net
Contact Information:
Contact
noreply(@data-protected.net
…Defendants
... Defendants
Place: New Delhi
Place:
17th January 2024
Date: 17th
Date:

Mae

al | Astha
scneal
Raghav Goyal
AStia Sehgal
(D/9590/2022)
(D/9590/2022) | (D/3817/2019)
(D/3817/2019)
Saikrishna & Associates
Associates
Saikrishna
Advocates for the Plaintiffs
Plaintiffs
Advocates
110003
57, Jor Bagh, Delhi –— 110003
+91 9810621272
9810621272
+91
raghav@saikrishnaassociates.com
raghav@saikrishnaassociates.com
|

|

<!-- page 25 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
