---
doc_id: "7a3de2bcdd143ede"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/08/795a08f5f9068c724857a319444403f1.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Draft Quality Control Order, 2023 on Electric Ceiling Type Fans."
date: "2023-03-21"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "62ff49a114728acd"
---

<!-- page 1 -->

[To be published in the Gazette of India, Extraordinary, part II, Section 3, Sub-section (ii)]
Government of India
Ministry of Commerce and Industry
Department for Promotion of Industry and Internal Trade
ORDER
New Delhi, the------, 2023
$.0.-------(E).- In exercise of the powers conferred by sub-sections (1) and (2) of
section 16 read with section 17 and sub-section (3) of section 25 of the Bureau of
Indian Standards Act, 2016 (11 of 2016), the Central Government, after consulting
the Bureau of Indian Standards, is of the opinion that it is necessary or expedient so
to do in the public interest, hereby makes the following Order, namely:-

4. Short title and commencement.- (1) This Order may be called the Electric
CeilingType Fans (Quality Control) Order, 2023.

(2) It shall come into force with effect from six months from the date of publication of
this notification:

(3) Provided that for Micro and Small Enterprises, as defined under the
Micro, Small and Medium Enterprises Development Act, 2006 (27 of
2006), it shall come into force with effect from twelve months from the date of
publication of this notification.

2. Compulsory use of Standard Mark.- (1) Goods or articles specified in the
column (1) of the Table below shall conform to the corresponding Indian Standard
specified in column (2) of the said Table and shall bear the Standard Mark under a
license from the Bureau as per Scheme-1 of Schedule-II of the Bureau of Indian
Standards (Conformity Assessment) Regulations, 201 8:

(2) Provided that nothing in this Order shall apply to goods or articles manufactured
domestically for export:

(3) Provided further that nothing in this Order shall apply to goods or articles
manufactured domestically by an enterprise, registered under "Udyam portal" of the
Ministry of Medium, Small and Micro Enterprises, wherein the investment in plant and
machinery or equipment at original cost does not exceed Rs. twenty-five lakh rupees
and the turnover does not exceed two crore rupees for the previous financial year as
certified by a Chartered Accountant shall be exempted from implementation of the

<!-- page 2 -->

relevant Quality Control Order.

3. Certification and enforcement authority.- The Bureau shall be the certifying and
enforcing authority for the goods or articles specified in the column (1) of the said
Table.

4. Penalty for contravention.- Any person who contravenes the provisions of this Order
shall be punishable under the provisions of the Bureau of Indian Standards Act, 2016.

TABLE
Indian Standard Title of Indian Standard
[ty | (2) po G
Electric Ceiling TS 374: 2019 Electric Ceiling Type Fans -
Type Fans Specification
Note: For the purposes of this Table, the latest version of Indian Standards including
the amendments issues thereof, as notified by the Bureau of Indian Standards from
time to time shall apply from the date of such notification.
F. No. P-29026/3/2022-LEI
(Sanjiv)
Joint Secretary
