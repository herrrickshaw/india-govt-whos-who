---
doc_id: "7c9c5de1e0a72fde"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/0698a9f3a9da48fae8b686e1646256f6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '1930' to Ministry of Home Affairs"
date: "2022-01-27"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9e64c534b82722d5"
---

<!-- page 1 -->

1/3035959/2022

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-10/2018-AS-Ill/Short Codes/337/.;2.f

Dated: -2- ?rol/2022

To,
All Access Service Providers,
Subject: Switching over to new shorter code 1930 to Ministry of Home Affairs,
Government oflndia for National Cyber Crime Reporting Portal (NCRP) -reg.
This is in reference to the DoT letter 16-10/2018-AS-IWShort Codes/336/20 dated
24.01.2022 (copy enclosed) vide which short code '1930' is allocated to Ministry of Home
Affairs, Government of India for National Cyber Crime Reporting Portal for Cyber Crime
Prevention for Women and Children and earlier allocated short code '155260' have to be
withdrawn within six months from the implementation of new short code.
2. Now, MHA has desired cyber crime helpline number '1930' to be included in the
contacts pre-loaded in the SIM cards by default. In view of this, the undersigned is directed
to state that TSPs shall intimate respective SIM manufacturers for inclusion of the cyber
crime helpline number in the contacts pre-loaded in the SIM cards by default.
Signed by Sanchit Kumar
Garg
Date: 27-0t.;2022 17:02:12

(Sanchit Kumar Garg)
Assistant Director General (AS-III)
E-Mail: sanchitk.garg@gov.in

<!-- page 2 -->

'1/3015873/2022

Government of India
Ministry of Communications

Department of Teleeommu.nications
Accen Services Wing
ZO, Asboka Road, New Delhi-110001
No. 16-10/1018-AS-DI/Short Codes/336/ "--t>

Dated: J.4101/2022

To,

All Access Service Providers,
Subject: Switching over to new shorter code 1930 to Ministry of Home Affairs,
Government of IndJa for National Cyber Crime Reporting Portal {NCRP) •ref.
In partial modification to DoT letter No. 16-03/2013-AS-Ill/349/945 dated 09.04.2018
(copy enclosed), it is decided that short Code •1930• is allocated to Ministry of Home
Affairs, Government of India for National Cyber Crime Reporting Portal for Cyber Crime
Prevention for Women and Children and earlier allocated short code '155260' will be
withdrawn within six months from the implementations of these instructions
2. However) in the transition period both short codes i.e. '1930' and '155260' will be
working for National Cyber Crime Reporting Portal f~r Cyber Crime Prevention for
Women and Children and will be terminating at Toll Free Number 1800-1800-191.

3. All other features shall remain same.
4, This is issued with the approval of competent authority.
$.lgned' QY sanctlit Kumar
G&,g
<

•

. t)at.,; ,24-(l1,..;2022 1&.22;~ '

·(Sanchit'Kumn:Garg)·
ADG (AS-III)

Copy forwardeti for information and neeeaary action, if any, to:
1. Secretary. TRAI.
2. CMD MTNIJ CMD BSNL.
3.
Shri B.L. Meena Under Secretary~ Ministry of Home Affairs, w.r.t your letter
dated 06.01.2022 1 with a request to appoint a nodal officer to implement the helpline.
The Nodal Officer may contact Sr. DDG (LSA), LSA Unit, concerned States/UTs.
4. Director (P&N)) DoT (HQ), (respective LSA field unit may be asked to co­
ordinate with respective Nodal Officers and TSPs for implementation of Helpline, as
and when approached).
5. A copy for upload on DoT Website.
