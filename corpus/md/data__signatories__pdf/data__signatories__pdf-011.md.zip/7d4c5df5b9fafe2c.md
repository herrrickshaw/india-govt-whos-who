---
doc_id: "7d4c5df5b9fafe2c"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/eb145d968e58b90043d878ac8a0b3d4d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Modification in the guidelines for Trading of Access Spectrum"
date: "2023-08-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0541e7f23702b1a0"
---

<!-- page 1 -->

No. L-14006/05/2015-NTG (Pt.)-1
Government of India
Ministry of Communications
Department of Telecommunications
WPC Wing, 6th floor, Sanchar Bhawan, New Delhi
Dated the 1st August, 2023
Subject:

Modification in the guidelines for Trading of Access Spectrum by Access
Service Providers dated 12th October, 2015

To facilitate trading of access spectrum between Telecom Service Providers (TSPs)
across all IMT spectrum bands and all applicable block size(s), the Competent Authority has
decided to modify the para 4 and 6 of the guidelines for Trading of Access Spectrum by Access
Service Providers dated 12th October, 2015 as under:
Existing Para

Modified Para

4. Only outright transfer of right to use the
spectrum from the seller to buyer shall be
permitted. Leasing of spectrum is not
permitted.

4. Leasing of spectrum only to Captive NonPublic Network (CNPN) licencee shall be
permitted as per leasing guidelines L-14006/02
/2022-NTG dated 27.06.2022 amended from
time to time.

6. Spectrum trading shall be permitted only 6. The block sizes of Access Spectrum to be
in the following block size (band wise):
traded in different spectrum band(s) shall be as
per the block size(s) as specified in the NIA for
the latest auction held. Further, if there is any
Spectrum band
Block Size
residual spectrum to be traded, it may be
800 MHz
2*1.25 MHz
considered on pro-rata basis.
900 MHz
2*200 KHz
1800 MHz
2100 MHz
2300 MHz
2500 MHz

2*200 KHz
2*5 MHz
20 MHz in TDD
20 MHz in TDD and
2*10 in FDD

Also, if a particular spectrum band is not the
part of the NIA for the latest auction held, then
the block size as per latest available NIA for
that band shall be considered for trading.

2. The other terms and conditions of guidelines for Trading of Access Spectrum by Access
Service Providers dated 12th October, 2015 and clarifications issued from time to time in the
matter shall remain unchanged.
signed by (Avneesh Kumar)
AVNEESH Digitally
AVNEESH KUMAR
Assistant
Wireless Adviser
2023.08.01
KUMAR Date:
the Government of India
16:22:53to
+05'30'

To,
All Concerned

Page 1 of 1
