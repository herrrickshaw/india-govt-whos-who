---
doc_id: "7bd3b8cc4b93bf8d"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/0d0c524c2b7f23b19bc0c40309f9488c.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Confirmation of JTS(DR) of CLS. (02/02/2018) (Office Order- 04-18)"
date: "2018-02-02"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "57f5edb91e7bdc07"
---

<!-- page 1 -->

F. No. A-31012/01/2016-CLS.I(Voi.II)
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan, Raft Marg,
New Delhi, dated 2nd February, 2018
OFFICE ORDER No.Q4/2018

On successful completion of their probation period, the President is pleased to appoint
following temporary Junior Time Scale Officers of Central Labour Service [in level 10 of Pay Matrix,
Rs.56,100 - 1,77,500/-] substantively to the Junior Time Scale of Central Labour Service with
effect from the dates mentioned against their names in column 4:

s.
No.

Name of the Officer
(Sh./Ms.)(Shri)

(1)

Date of joining

Date of Confirmation

(3)

(4)

1.

NIRMAL CHANDRA KAR

(2)

06.04.2015

06.04.2017

2.

SHOABALI HASAN AU SAYYED

23.04.2015

23.04.2017

3.

RAHUL 1YAGI

28.01.2015

28.01.2017

4.

MANIKANDAN N.

02.04.2015

02.04.2017

5.

KANHU CHARAN SAHU

02.07.2015

02.07.2017

6.

SUSANTA KUMAR NAYAK

01.06.2015

01.06.2017

7.

RAJIV RANJAN

09.09.2015

09.09.2017

8.

KSHITIJ JAIN

20.01.2015

20.01.2017

9.

BARUN KUMAR JHA

29.01.2015

29.01.2017

08.04.2015

08.04.2017

29.12.2014

29.12.2016

12. SUNIL RAGHUNATH MALI

08.04.2015

08.04.2017

13. PRADYUMN KUMAR RANA

09.09.2015

09.09.2017

14. VISHAL ASHOK AMTE

22.04.2015

22.04.2017

15. HITLER THOUDAM

15.04.2015

15.04.2017

16. WONMI HORAM

04.08.2015

04.08.2017

17. BASAVARAJ

01.01.2015

01.01.2017

10. KANAGAVEL

PANDIYAN

SHANMUGAVEL

11. SUBAPRIYADARSHINI
MUTHUPANDI

1

<!-- page 2 -->

2.
Confirmation of the above mentioned Officers in the Junior Time Scale of Central Labour
Service is subject to outcome of the OA No. 310/01382/2014 filed by Shri L. Prasad before the
Hon'ble CAT, Madras, O.A. No.2197/2014 filed by Shri Mukesh Suman before the Hon'ble CAT, PB,
New Delhi, O.A. No. 330/1024/2014 filed by Ms. Neha Singh before the Hon'ble CAT, Allahabad.

~

(Ajay Malik)
Under Secretary to Government of India
To,

1. JTS Officers Concerned.
2.
3.
4.
5.

Office of the Chief Labour Commissioner(C), New Delhi.
Office of DG(LW), New Delhi .
The Establishments/ Organizations concerned.
Spare copies.

Copy to:The Director (NIC), Ministry of Labour & Employment (with request to upload the aforesaid
order in the Ministry's website).

2
