---
doc_id: "7c033cabde9ee12d"
source_url: "https://powermin.gov.in/static/uploads/2025/08/ad6c8ccffa8de9ee36f6cb2e59de8d8a.pdf"
ministry: "Power"
title: "Appointment of Shri Rajiv sharma as CMD, PFC-reg"
date: "2016-10-03"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5e8bef993c327227"
---

<!-- page 1 -->

= F.No.8/ 2 /2015-PFC Desk
Government of India
Ministry of Power
Shram Shakti Bhawan, Rafi Marg,
/ New Delhi: the 3° October, 2016.
ORDER
In pursuance of Article 81 of the Articles of Association of the Power
Finance Corporation Limited (PFC), the President is pleased to appoint
Shri Rajeev Sharma to the post of Chairman and Managing Director (CMD),
PFC in the scale of pay of Rs.80,000- 1,25,000/- for a period of five years
with effect from 1% October, 2016 (F.N.) i.e. the date of his assumption of
charge of the post, or till the date of his superannuation i.e. 31.05.2020, or
until further orders, whichever is the earliest.
2. Terms and conditions regulating the appointment of Shri Rajeev -
Sharma as CMD, PFC will be issued separately.
८४०० द्ढ्र
(C. Thenmoli)
Under Secretary to the Govt. of India
Telefax: 23711302.
Copy to:
“ 1. Shri Rajeev Sharma, CMD, Power Finance Corporation Ltd., Urjanidhi, 1,
Barakhamba Lane, Cannaught Place, New Delhi-110001.
2. Executive Director(HR), Power Finance Corporation Ltd, Urjanidhi, 1,
Barakhamba Lane, Cannaught Place, New Delhi.
. 3. Under Secretary(ACC), DoP&T, North Block, New Delhi with ref. to their
communication No.20/12/ 2016-EO(ACC) dated 27.04.2016.
4. Secretary, PESB, (DoP&T), Public Enterprises Bhavan, CGO Complex,
New Delhi w.r.t. their U.O.No.6/15/2015-PESB dated 18.01.2016.
5. Secretary, Department of Public Enterprises, CGO Complex, New Delhi.
6. Chairman, Central Electricity Authority, R.K.Puram, New Delhi.
7. Company Secretary, Power Finance Corporation Ltd., New Delhi.
= 8. All PSUs/Autonomous Bodies under the Ministry of Power.
9. PPS to MoSP(IC)/PPS to Secretary(P)/PPS to AS(SP), Ministry of Power.
a 10. All JSs/ JS&FA/ EA, Ministry of Power.
11. All Officers /Sections in the Ministry of Power.
412. Office Order folder/ Sanction File.
