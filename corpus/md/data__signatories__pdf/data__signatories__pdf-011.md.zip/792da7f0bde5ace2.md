---
doc_id: "792da7f0bde5ace2"
source_url: "https://www.dahd.gov.in/static/uploads/2026/10/b2c59953f08570e13fd8241435bdcb4a.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Rules 2010 under PCICDA"
date: "2026-10-16"
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a79321b4d7888f1b"
---

<!-- page 1 -->

Tf^fTfo^oTT^o-33004/99

^*ffiUv

REGD.NO. D.I,.-33004/99

(l\iz (Sazette of 3xidia
EXTRAORDINARY
SIFT II—WTZ 3—3^-12^5 (i)
PART II—Section 3—Sub-section (i)
PUBLISHED BY AUTHORITY
K 673|

^Tf f ^ # , M'JIHcJK, fc«i«K 14, 2010/3HISWUI 23, 1932

No.673|

NEW DELHI, TUESDAY, DECEMBER 14, 2010/AGRAHAYANA 23, 1932

( i^MleH 3ftT t l f t f i W R )

3#njERT
^f^#,

14f^R,20!0

m^r.fr. 974(3?).—T^jaff ^f wain* 3TR W ^ R T TRf? 3 ^ 1 3 STR tem srfafem, 2009 (2009 ^r 27) ^fr *TRT
42 £RT TT^fT Tlfen ^T M 1 ! " ^ "m, ^ *U+K PHHPdRsJd tWT ^HTcfr t , ^mrT: :—-

fe^T

1. ^ftfTH ^ ^ ^ ^ 1^TTT97 ff^ " ^ (fTte.—(1) FT twff ^ ^3Tl' 3 ^r^TPT^ 3TR HwU^ TPTt' ^ *T3F? sftT
(dl + lcf.^1 yHIUNaf ^T TTT5T ^ "RT^T TTt$FT 3TR H^W ^ TWR ^ft 3lfeJT) few 2010 ^?7 "STR I
(2) *K+kl T P m *f y-^l^ld # 7 ^ cTRK3 ^ ^ Sep! KRT I
2.

MR^IMI. • ( 1) Ft 1wtf "*f ^

3T^TT 'H^rf ^ fell '5^,..-

O)

" 3TfNlWT" ^T 3TT^PT t ^ 3 M U'*IH+ 3^R TRFfcR? Ttnf ^ ^ m ? 3TR Pd^>[ STfatWT, 2009 (2009 ^1
27);

(TsT)

" 3 m " ^T 3TT9RT t FT twff ^ MRrVI^ W l ;

Cn)

m\ ^T JTwm t , srP^rq*? ^ T ^ ^RT I

(2) FT M
^r^T 3T«f ^PtTTT: ^

3 # 1 fer TJTT Ti^f 3k 3rf^oijr=ki4, f3F#' w e ^ffi fen w i ^
#TT, ^ 1 fe 3?P^feH 3 ^TCI TpTT "I I

3Tfafwr 3 w e fen TFTT ^

3. el*icMui umumsi ^ T TOT.—(1) PH^I* SFQ PWP^d ^JT, TfJrT sh ^TI ^fecRT ah "4 arfatwr ^t
«TRT 9 ^ 3KT*fa TRJ3ff ^T dl+!$d wti 3TR il + l+^l MHI'-'IH^ «!!$ ^R^ ^ %T£ ^ ^ T WTFTT "?TT "q^f^ff 3TR ^qfe^' ^T
3Tp^f^fen^T^ I

CT^TM <il+i+<ui yHi"N^ ^Rt fen ^

"^R^ftrcriftH+i+^i ^

cTRte ^ # r ^T^TTF ^ 3TP*W wf \sn it ^ R dlcbi+m ^r

(3) ^44id ^ 3T^TT^T ^arf' ^ % ^ <il+|ch<"l "SRFT "^ ^ 1 1 ^ " ^ " TfftPHRbcifefT^THT I
4751 GI/2010
(1)

<!-- page 2 -->

THE GAZETTE OF INDIA : EXTRAORDINARY
( 4 ) t+><*<£i <£ f^pr i l + l ^ ^ i yHH'N^ ^Tf i m " " ® " *f fainf^ faRTT ^

[PARF Il-Snc. 3(i)|

f

( 5 ) dl+l<*<"l TTRFm f£*fRtt Ft fam H T&> T*TFffa *TFTTFT I

4. "qft^nrr 3ffr tfte" RT^JT "aRT% ^

y i * - u -CO H^faf+cw* ^TTOf^fe*7T3Tf*-R£Rt <&—

(37) W p c T ^ T 3 TT^m "3^T ft«# 3 W^-M^clM 3TR W

"qT?q ^T W-TfaTTT" 3 ^ 3?k ^ftfaRTT"Q^frT ^TH

TTT ^TT' ^TTf^ ^ ^TR^R "q' ^T 3TTOTR ^ **TFT M7 FT, "^TSFT ST^^Kt ^TT *ft ~VT^

*R# I

(Tar) spjqf^cr 3Tf«rgfer TRT «Pt "gfe TOI <Ffcni,a n ^ w ^Rfn T ^ ^ I + ^ I ^ T W-T ^ R afk ^frr ^ i ^ r j w
M^VtVIMI R' ^ ' I
(T|)

T^J ^

i£ PH^dK ^TT 3 F ^ ^TT t% ^T f R W ^ t W T 5 R fafnRM F I

(-6T) ^ T ^T^R 3TK T^TFT ^JT «*H"I ^

3RiT WT "qT W

(^r) -q^j ^iHHcf, gn V ^ ' V ' R ^ R T ^ t W ^ ^

RTCR "iTNt STRTtfcm ^T RS sft I

W^T^R STR^Tf? HVjr^r+rW+ ^TT H^kJlVqi ^ R F R t

•^f faRTT SRR^facT 3#-R?j3tT TFT "^ "^TT^T ^ f f F "eft TT<V1^ ^T Rff^T 3R I
(2) ^f< Rrg ^ r ^rwi ^r^rrfsfcT F T ^ T ^ R T F en ^

fa^ft TT9J 7T5T ^T. "2TT mtf 25 *& 3RFfa RR ^

w T T T £ T ^ tV^n "STTR I

R?J ?T^ ^T, T?] qifH* W * R . *R4l + {U| £RT TRJ ^

( 2) TOT^r+r-N* £RT M « I R ^TT *1^1 + <wi "^ * # ? ^ n tV^T ^TT^, Wl ^

fefRj

^

FHMilfI ^R I

HlT^4- ^ 1jfu^ ~R ^TT STT^TRT ^ 7$TH TR

f^TT ^TR, " ^ n ^T TT^T 3#T^RT i M ^ 7 P # I
( 3 ) TT2FT 3Tlwft., aHN^^chd! fti m , t^Rft ^jtfSffi cfT^ Tf' FfTZR ^T ^^TH ?T^ TTsFF^ ^
^3TR"g?T^^T^^t^t%^ M

fer

? R ^T Tf^TR ^ 1 ^ V

-sn^ c(i^ ^T^T ^ ^TF^T Hlfel^ SRI ^ T ^ T TRF^ ^ ? ^

STR TJfrm Tj5f?[ %^T

•^TR !
( 4 ) MVjhr^rM^ ^

M ^ r + o H l 3TfKfrt £RT ^

^ F f f ^ T f^TT mTT far T<[ ^T^ ^

mZRT

fa^rf?^

" M t tr+"

^ f c n ^rfa^TT"^TTT •HTCRT: :—
( ^T ) 7raT£TH.

(i ) "^T^ ^ H ^

frTCf "T5^ ^71 3TT^R T ^ ^ 3TT^R ^ ^ T FRT ^TtVgTTfaRTHfa^? ^ ^ ^TH ^TH

#TT "^nf^ !

^RTFT

fa^^"^

(iv) ^ 7 ^ TO ^

^3R^ •5TTm-^ ^ ^ ^fR? "qfe ^ t ^Tt "^TT FI I

t ^ "T^T Ttfm\ "^T ^fTI^ ^T ^

TFqTf^T J ^ q ^ l ' rTf I

( v) S f f e ^R^TT Tf ^TRH ^TT #5T "RH^ 3Tf^RT T4 ^ q ^ ^Tq TT H T^W q t ^ ^ t ^R "^HT ^Tf?TT I
( " ^ ) H4"|^I<UT.—(i) ^PqfaRTT -effr ^H rT^ ^rRt M

^

^

M T-?l ?W W ^f MfwPHcT ^ Ft ^TR7 I

( ii) ^^fl+<U| ^7T ^^FT T^RT^ 3TMRT ^ ^FR ^ ^ q ^t ^fl T3RT ^ 7 ^ t ^R #TT ^Itt?^ I
( T ) ^ f ^ T . — ( i ) fetRT "qR ^Rft fatftfel T?TH "^R ^T TJ^fcRT 3TR TTW^ff ^RT fa^TI ^THT ^T%^ faH^ ^"^ TSR>I
TRfa y^iPdd TOt ^ %TT "5ft>Tf^T "qpT^TfarT FT I
(ii ) TTsFfqcT ^

"9T^ ^

"RTq^R ^

fWl TSTX1! "Rfa^TT ^7T TRTFT TO ^

(iii)

fefrnH?qT^^r^

6. ^

^ t TWA' °^ 'qW ^ ffa*T "q' ^

^ O T ^TT U%4RH^T ^

W^

fetRl

^ * ^1

STTFR^M^'^RFRT^Tfa^T^w, i
?fa7T Ft eft ^H RTq^! ^ t fa"fa * f^tj, H^JMMH STRT^T, q^TleRT. t ^ f | sfft

HrWMIdH faHRT, ^RcT TR^R "^T TT^fa fa^ ^TTTT I

<!-- page 3 -->

[Wl 11-73*5 3 ( i ) ]

*TO ^T TRT5T : 3raT*TK*T
*Fl4 "On

-W^TT

•yHi"iM5i w n (fateiv <il*i+<ui ynium^ ^ w )

HlfcHcfc 'SBt xptH W I T

mm)

•3TTTT < f l * l * < U | 1WIU|<U cFT "teTTJT

^TTSTT

^TTO t r g L ^ - H H

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PAR: II—SH\ 3(i)|
"Efirtf is

Mt>jMi<rH

f^m
'4U«hK

yH|U|q^ W t f ( f ¥ w zfoRR*! W\m^ TOTT)

W "SRTf^TcI t ^ T I ^TRTT f % pHHPtfftsId U^TR ^ V^sfi ^

4lfdch 3tf ^rTT

(TRJ % ^TT%^ ^T " ^ "TOT)

c f l P u i M * ^ = ^ h i *«IIMHI

FL^'

(TFT ?TT TPff ^T ^TW) ^

s f o j "tyWii

f^7, ^

f^^<u||^K ^ J f ^T WW

(STHfff)

d)*l«b^U| ^ T f ^ T ^ l

^ t ^ "^T TJ^TR

(^ftf^r, 3T^T, ^

TT5TR)

^ £ ^

WHlfld ^ i f f t ^

fzh£ ^ xfTTira ^

IFTT8JT

^^rm in* q^nm

<!-- page 5 -->

[*TFT I I - ^ u s

3(i)]

*TTC?f ^ T T R l ^ f

: 3^TTmT°T

^ T 4 "n

*W«*N

(2)

(1)

(3)

"TO

3rrg {^)

3TtT ^ T ^ R

Tfg^TlF^T
2. T ^ J ^

cT81T

«

m l H * W facKUl

)

4. 341'dReh ^ ^ T

(4)

<!-- page 6 -->

6
(0

(2)

3[ffoF?T

f ^

H 1 ^! 1 ! " Sl*'-2l')l

THE GAZETTE OF INDIA : EXTRAORDINARY

( T T , "RT^T 3TIT

WTrTT)

3TT5R!

eB. f**T rT^rr ^T^T

_

(3)

(4)__

<!-- page 7 -->

[•qFT I I - T s F S 3 ( i ) ]

(I)

^TTrT ^ T TRR^T

(2)

6. f m ^^TTTT 3TOcJT ^ I H I ^ d l U , '

7. - q ^ ^ TWrforT ^ H ^ T ^ ^TT ^f TFT

8. ^rrft LIIWHI^M ^ fad<ui
^Tlft ^T% "Sfft Irrfsi

(3)

: 37^1^-11^1

(4)

<!-- page 8 -->

THE GAZETTE OF INDIA : EXTRAORDINARY

(0

(3)

(2)

( ^

(4)

^

WT/3PT)

TJcg W\ TTTTtH

Tfpg "3TI TT*FT

£KTTf#TrT

T i # m <TKfr§

TT^TTftT

^

T

^T^iB f^T/WTT

2. m f a * w

f^nrr

wi
3. ijtoisu "^FT "femr

(T§T) ^ ^ i w f ^ W T
( n ) C^TPT ^ # H % ^

MH^i^i

M*MI^ «mM ^^rnT

(-cr) TeRR cnr

(*rr) tn^rr Tret ' s ) ^ J H A rfsr
(-3T) ^HlsJirT 7R
(F)F*£T^
( o r ) < f f w rf?
( ^ ) fsff^r Trft^roT
5. TTr^ "^ TJ'WfarT ^TTTIT ^ TSTIT 3 TFT
6. liebHH ^ J % ^FT facRU|

[PART I I - - S E C . 3

<!-- page 9 -->

[^TPT I I - T s F ^ 3 ( i ) ]

(0

*TTTo" ^ 7 U5TT5f : -SRTT^TT^

(2)

9.

^__^_

Mlwm^M R M V TR^f fUsiJI

[ m u 51 -44/90- Hd^liKarrnft) (wi i v) |

MINISTRY OF AGRICULTURE
(Department of Animal Husbandry, Dairying and Fisheries)
NOTIFICATION
New Delhi, the 14th December, 2010
G.S.R. 974(E).—In exercise ofthc powers conferred by section 42 of the Prevention and Control of Infectious and
Contagious Diseases in Animals Act, 2009 (27 of 2009), the Central Government hereby makes the following rules, namely:1. Short title and commencement.—(1) These rules may be called the Prevention and Control of Infectious and
Contagious Diseases in Animals (Fonn of Vaccination Certificate, Manner of Post Mortem Examination and Disposal o\~
Carcass) Rules, 2010.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions.—(1) In these rules unless the context otherwise required;
(a)

L

Act' means the Prevention and Control of Infectious and Contagious Diseases in Animals Act, 2009
(27 of 2009);

(b) 'Form' means Form appended to these rules;
(c) section means a section of the Act.
(2) Words and expressions used in these rules and not defined but defined in the Act shall have the same meaning
as respectively assigned to them in the Act.
3. Form of vaccination certificate.—(1) The Director shall notify the institutions for agencies and persons
competent to vaccinate the animals and issue vaccination certificate under section 9 of the Act in the controlled area, free
area or infected area.
(2) The persons notified by the Director under sub-rule (1) for issuing vaccination certificate shall issue a vaccination certificate to the owner of the animal as early as possible but not exceeding three weeks from the date of vaccination
and shall maintain proper record of vaccination.

m$) allied

<!-- page 10 -->

THK GAZETTE OF INDIA : EXTRAORDINARY

|PART II -Sue. 3(i)]

(3) The vaccination certificate for animals other than poultry shall be specified in Form A.
(4) The vaccination certificate for poultry shall be as specified in Form R.
(5) The vaccination certificate shall be bi-lingual of which one language shall be vernacular.
4. Manner of conducting examination and post mortem.—(1) The veterinarian or the veterinary' officer shall(a)

arrange the examination and post mortem in proper lighting condition and at a secluded place either at the
owner's premises or the nearest location, as considered appropriate by the competent officer.

(b)

arrange collection of appropriate samples for confirmation ofthe scheduled notified disease and dispatch
the samples to appropriate laboratories.

(c)

arrange disposal of carcass as specified in rule 5 of these rules.

(d)

arrange disinfection ofthe premises and the place where post mortem examination was conducted.

(e)

provide a copy ofthe post mortem report to the owner ofthe animal in Form C. and inform the Director if in
the opinion of the Veterinarian or the Veterinary Officer, the death is caused by a scheduled notified disease.

(2) No post mortem shall be conducted when the cause of death is suspected to be Anthrax.
5. Disposal ofthe carcass of an animal infected with a scheduled notified disease.—(1) The carcass of an animal
that has died of a scheduled notified disease, or the carcass ofthe animal euthanized under section 25, the owner ofthe
animal shall dispose off the carcass either by burial, incineration or rendering,
(2) The veterinarian shall supervise the burial or incineration, which shall be performed preferably at the premises
ofthe owner ofthe anima! or the nearest location, as considered appropriate by the competent officer.
(3) The competent officer, if required, shall arrange transportation ofthe carcass ofthe infected animal in a secured
vehicle to the site ofthe disposal and the vehicle used for transportation ofthe dead animai shall be properK cleaned and
disinfected by the vehicle owner.
(4) The veterinarian or the Veterinary Officer shall ensure that the disposal of carcass is by any one of the
following methods, namely:
(a) Burial.—(i) the size ofthe pit for the burial shall be bigger than the si^e ofthe animal t hat allows all parts of
the animal carcass to be buried in the buria! pit and at least one metre of covering soil shall be used to cap the pit.
(ii)

a layer of five-centimetre iime shall be put al the bottom ofthe burial pit and again over the carcass before
filling the soil.

(iii)

the pit for burial shall be at least twenty metres away from watercourse and two hundred and fifty metres
away from well, bore-well or water spring used as a source of drinking water.

(iv)

the pit for burial shall not be in a seasonal water-logged or flood prone area.

(v)

for mass burial, the site shall be at least two hundred fifty metres away from human habitat.

(b)

Incineration.—(i) incineration shall be continued till the animal carcass is reduced to ashes.

(ii)

the site identified for incineration shall be at least two hundred fifty metres away from human habitat.

(c)

Rendering.—(i) rendering shall be practiced only on-site by agencies and institutes that have adequate
trained manpower in operating the rendering plant.

(ii)

the agency or the institute using rendering as a method of infected animal carcass disposal shall maintain
proper records of each rendering cycle.

(iii)

the rendered product shall not be used as ingredient of animal feed.

6. If any question of interpretation or doubt arises in relation to these rules, the matter shall be referred to the
Animal Husbandry Commissioner, Department of Animal Husbandry, Dairying and Fisheries, Government of India, for
decision.

<!-- page 11 -->

[^m n - i a ^

^TRcT W\ TRT5T : 3RTT^1T^

3(i)j

Form A

Department of Animal Husbandry
Government of
VACCINATION CERTIFICATE FOR ANIMAL OTHER THAN POULIRY
Certificate No. (unique vaccination certificate number)
Valid from (date of vaccination)

to (date till valid)

This is to certify that the animal of the following description has been vaccinated against (name of the disease or diseases)
on (date of vaccination) by using a vaccine the details of which are given below :
Description of the animal
Species

(name of the species)

Identification details

(ear-tag number/tattoo or other form
of markings)

Name of the owner

(full name of the owner of the animal)

Address of the owner

(full address of the animal owner)

Sex

(male/female)

Owner's contact
Phone number
Details of vaccination
Namcof the vaccine

(vaccine, name)

Vaccine production date

(date of production
of the used vaccine
batch)
(expiry dale of Ihc
vaccine batch used)

Type of vaccine

(live, inactivated,
adjuvant type)

Vaccine expiry date

Vaccine batch No.

(batch no. of the vaccine)

Vaccinated by

(name of the agenc\)

Name of the manufacturer

(vaccine manufacturer's
name)

Vaccinated by

(name of the
vaccinator)

Vaccination certificate issue details
Date of issue
Place of issue
Signature

Name and designation

Registration number with State
Veterinary Council/Veterinary Council of India

Official Scat

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

|FARi-11-

Sa.3(i)|
Form H

Department of Animal Husbandry
Government of
VACCINATION CERTIFICATE FOR POULTRY
Certificate No. (unique vaccination certificate number)
Valid from (date of vaccination) to (date till valid)
This is to certify that the Poultry of the following description have been vaccinated against (name of the disease or
diseases) on (date of vaccination) by using a vaccine the details of which are given below :
Details of vaccinated poultry
Poultry species

(chicken, duck, quail etc.)

No. of birds vaccinated (number immunized)

Name of the owner
Address of the owner

Poultry type

(Da\ Old Chicks, layers,
broilers, breeder etc.)

Marking details for
identification of
vaccination

(painting, wing lei
band etc.)

Backyard poultry

{\es no)

(dale of production of
the used vaccine batch)

(full name of (he owner of the animal)
(full address of the animal owner)

Owner's contact
Phone number
Commercial poultry
establishment

(yes no)

Details of vaccination
Name of the vaccine

(vaccine name)

Vaccine production
date •

Type of vaccine

(iive, inactivated,
adjuvant type)

Vaccine expiry date (expiry date of the
vaccine batch used)

Vaccine batch No.

(batch no. o( vaccine)

Vaccinated by

(name of the agenc\)

Name of the manufacturer

(vaccine manufacturer's
name)

Vaccinated bv

(name of the vaccinator)

Vaccination certificate issue details
Date of issue
Place of issue
Signature

Name and designation
Registration number with State
Veterinary Council/Veterinary Council of India
Official Seal

<!-- page 13 -->

L^TFT I I - T B F S 3 ( i ) ]

i-TRcT ^1 TR^T : 3TCTWT
Form C
Department of Animal Husbandry
Government of

POST MORTEM EXAMINATION REPORT FOR ANIMALS OTHER THAN POULTRY

(0

(2)

(3)

I'M report No.

PM conducted at (location)

PM date
Rcf. by

PM time
Rcf. date

1. Animal details
Species

Breed

Sex

Age (years)

Identification
No.''Mark

Anv other

Colour
History of illness
and treatment
Date of death

Time of death

2. Animal owner details
Name
Address
Contact number
3. External examination
Rigor mortis

External orifices

Condition of the
carcass

Udder

Hair coat

Visible Mucous membranes

Wound/turmor
(location and dimension)

Bones and joints

Other observations
4. Internal examination
Thoracic Cavity
Ribs
Cartilage
Pleura
Diaphragm
Larynx
Trachea
Bronchi
Lungs
I ,ymph nodes
Pericardium
U re/

/= r / ? ^ _ / y

(4)

<!-- page 14 -->

14
(1)

(2)

Endocardium
Myocardium
Aorla
Auricles
Ventricle
Oesophagus
Other observations
Abdominal cavity
Peritoneum
Fluid (colour,
quantity and
consistency)
Lymph nodes
Rumen/Stomach/
Reticulum
Omasum
Abomasum
Small intestine
Large intestine
Mesentery
Portal veins
Liver
Gallbladder
Pancreas
Kidney & Adrenals
Ureters
Urinary Bladder
Spleen
Other observations
Pelvic cavity
Testicle
Lpididymis
Spermatic cord
Scrotum
Prostrate
Penis
Vulva
Cervix
Vagina
Uterus
Ovary
Other observations
a. Head and Neck
Scalp
Skull bones
Meninges
Brain
Spinal cord
Cervical vertebra
Thyroids/Parathyroids

IZA^2_ILd^L 3JH1

THE GAZETTE OF INDIA : EXTRAORDINARY
(3)

(4)

<!-- page 15 -->

[*TPT U-W^

3(i)]

(I)
Other observations

^TTTrT 37T TOT3T : SmT^R^
(2)

(3)

(4)

5. Specimen collection details
Specimen type,
Preservatives used
Tests required
Laboratory address
6. Special observation or abnormalities

7. Opinion as to the probable cause of death

8. Post Mortem Report Issue Details
Date of issue
Place of issue
Signature
Name and designation
Registration numberwith State
Veterinary Council/Veterinary Council of India
Official Seal
Form D
Department of Animal Husbandry
Government of
POST MORTEM EXAMINATION REPORT FOR POULIRV
PM report No.

PM conducts

Date of death

Time ofdeatl

PM dare

PM time

Ref. by

Ref. date

1. Details of poultry
Specied
Age
Total flock number
Number of dead birds on which PM was conducted
Identification
mark/number if any
History of illness and
treatment
2. Owner details
Name
Address
3. Nutritional details
4. Post Mortem details
(a) External appearance

Breed
Sex
Number died

<!-- page 16 -->

16 _

THE GAZETTE OF INDIA : EXTRAORDINARY

0)

(2)

(3)

[PARI II-- Six. 3(i)]
(4)

'

_

(b) Subcutaneous tissue and musculature

(c) General observations after opening the carcass

(d) Respiratory system

(e) Cardiovascular system
<f) Digestive system

(g) Urinary system

(h) Genital system

(i) Immune system

(j) Nervous system

(k) Miscellaneous observations
5. Opinion as to the probable cause of death
6. Specimen collection details
Specimen type
Tests required
Laboratory address
7. I'M report issue details
VM report reference No.
Date of issue
Place of issue
Signature
Name and designation
Registration number with Slate
Veterinary Council/Veterinarv Council of India
Official Seal
[F.No. 51 -44/90-! ,DT(RIJ)(Vol. IV)|
RAJBIR SINGH RANA. it. Secy.

Printed by the Manager Government of India Press; Ring Rond. Mavapun. New Delhi-1 10064
and Published by the Controller oi' Publications. Delhi-! 10054.
