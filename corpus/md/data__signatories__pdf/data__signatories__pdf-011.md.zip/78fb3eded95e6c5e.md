---
doc_id: "78fb3eded95e6c5e"
source_url: "https://powermin.gov.in/static/uploads/2025/08/38097f05127baeb1046296e23b2f06cc.pdf"
ministry: "Power"
title: "Nomination of officer for appointment on deputation to post of CVO in CPSUs during the year 2015-16"
date: "2015-01-28"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a9dff58df26a3e9a"
---

<!-- page 1 -->

ae . . कि भारत सरकार Ee ae
sp Jishnu Barua, IAS : ee कार्मिक और प्रशिक्षण विमाग ae
Bh Joint Seqgétary (S&Vig.-II) ‘i nl कार्मिक,.लोक शिकायत तथा पेंशन मंत्रालय Hig
aoe Fax: O11-23092930 rete} DEPARTMENT OF PERSONNEL & TRAINING Pee
ae ace —~ — MINISTRY.OF PERSONNEL, PUBLIC GRIEVANCES ae
a oe AND PENSIONS es
Be : हर NORTH BLOCK, NEW DELHI - 110001 ae
as . + D.O.No.372/42/2014-AVD-IIL oe
ue: रा Dated the 28" January, 2015 Lacie
Bate : दि eee
oh Dear Secretary, हु : ee
re 1 : . ‘ aaa
कर Jf . pee
uae ‘ Nominations of officers are invited for appointment on deputation to the posts of poy vi
Se Q Chief Vigilance Officers in Central Public Sector Enterprises etc. It may be noted that these a
a posts are Non-Central Staffing Scheme posts. a
Nae SS Lee
aes WES ge 2 The duties and responsibilities of Chief Vigilance Officers are briefly enumerated ae
a क्र below: - ie | a
oe 2 i
ae ९४ \ ()) The Chief Vigilance Officer has been authorized to decide upon the existence Hy
see! oS : of vigilance angle in a particular case at the time of registration of complaint. ed
Sie . oe
se. O 2 (i) The Chief Vigilance Officer should screen all the complaints before referring Ean
oe them to CBI. : ae
sae . ० ee
nae q | (iii) Attending the quarterly meeting with Zonal Joint Director of CBI for baa
us Jz : preparation of “Agreed List”. a
Bane [fla sine
Bee She Ta
tee mt (jv) Monitofing on corruption, malpractices and misconduct on the part of as
oe 22 employees and to take remedial action. as
oie & ae
oo oe é feat Seta) aa See
४६1४: (v) osely monitoring the case related to criminal misconduct of employees and ake
ee coordinating with the CBI for expeditious disposal of such cases. ee
oe 3. The posts for Chief Vigilance Officers’ (CVOs) in the Central Public Sector ae
3 Enterprises (CPSEs) etc. are filled up as per the procedure laid down in the comprehensive ay
ee guidelines issued vide this Department's OM No. 372/8/99-AVD.III, dated 18" January, Loe
ok | 2001 ao is also available on this Department’s web-site. The guidelines are, however, 229 हो
कप under revision. | Eee
Ue 4, Details of vacancies of Chief Vigilance Officers in Central Public Sector | ae
se Enterprises etc. that are presently available and likely to arise.during the financial Pee
ae year 2015-16 are available on this Department's web-site. However, a tentative list of ne
Bele vacancies is enclosed. . eee
ier ect a
es @
ee e : Si
me E सूचना ae
a का अधिकार http://persmin.gov.in 4 ae
ce ae
age 8
a :
Pies ee
ae . aoe
eee -- 2 व 2
be ८ अमर
ae ae

<!-- page 2 -->

४ = 5. The officers sponsored for Joint Secretary level posts should be — (a) | ae
रे é empanelled to hold Joint Secretary level post at the centre; or (b) an officer of his/her Eee
: service and batch should be empanelled to hold Joint Secretary level post at the centre. ~ eek
The officers sponsored for Director level posts should have completed 14 years of Group oe

2 ‘A’ service and should have been granted the Non-Functional Selection Grade in the cadre. been
S > Be ee
2 . 6. In order to attract officers for manning the posts of CVOs in various CPSEs etc., Bases
5 certain special dispensations have been made. For instance, if a request is received from an ao
५ ‘ officer’ occupying a post under the Central Staffing Scheme on deputation, duly eS
“4 recommended by the Ministry/Department, with the approval of the Minister-in-charge for oe
ss being considered for appointment as Chief Vigilance Officer, at least one year before the an
expiry of his/her tenure on the Central Staffing Scheme post, such an officer if selected for ae

a appointment as Chief Vigilance Officer may be allowed a tenure of 3 years as Chief as
के Vigilance Officer subject to a maximum of 7 years combined tenure under the Central eo
z Staffing Scheme post and the post of- CVO. However, it is necessary to obtain cadre गा
रे clearance from the parent cadre for a shift from a Central Staffing Scheme post to a 1:58
५ Non-Central Staffing Scheme post as this entails an additional two years of deputation sags
: tenure. This may be brought to the notice of the All India Service Officers and the Officers हा
of Central Services working on ‘posts under the Central Staffing Scheme in your i

Ministry/Department. है का |

7. _. As equivalent officers of Central Public Sector Enterprises are also eligible for a
: appointment to the post-of CVO in CPSEs etc., this may be circulated within the sae
‘ CPSEs under your administrative control: + : kg ie
; 8. The officer on appointment to the post of Chief Vigilance Officer in Central Public 8
ss Sector Enterprises is not entitled to general pool accommodation but would be eligible for Ae
2] accommodation provided by the concerned CPSE, as per guidelines issued by the ioe
. Department of Public Enterprises, from time to time. ee

gaa

५ 1 9. While sponsoring the names of willing officers, it may also be indicated alongside ae

| each name, a maximum of three location(s)/station(s) in which the officer may like to be ae

| considered for placement. The current pay scale of the officers and the actual pay being as

रू | drawn at the time of sending the names should also be indicated. Once an officer gives the ee
i ! choice of location/station, then as far ds possible that officer would be considered for a
= | posting in any Central Public Sector Enterprises in that particular location/station. However, ae
the officer may be posted at any place in India. It has been noticed in the past that while “rae

: sponsoring names, preference has been shown for a particular CPSE/organization in a a
a | particular region, It is clarified that such requests cannot be entertained and officers are ae
Sy required to indicate only their options for place of postings. Officers sponsored will remain ic fe
under consideration for posting for the period of one year only from the date of clearance of a

Central Vigilance Commission or 31% March, 2016, whichever is earlier. a

5 10. The names of the officers sponsored for the previous years but not approved by CVC a
५ for appointment to the post of CVO, should not be sponsored again for this financial year a ne

3 2015-16: co

|

ee

ee

= era

; : oe

<!-- page 3 -->

22. . 4 so 8 ay

oe 11... The names of the officers who had applied for appointment as CVO for the previous Us
Hey financial year 2014-15, shall be retained in the offer list only upto 31.03.2015 and they have pas
ee to apply afresh for consideration for appointment against vacancies occurring during the ~ Sg
a financial year 2015-16. रे a8
i : _= 12. ~The details of this circular are also available on our Department's website at URL Loe
aie http://persmin.nic.in and we shall appreciate, if the contents of this circular could also be Se
i posted on your Department’s website for wide publicity. oes
oe हि Be
uh 13, I shall be grateful if you could arrange to forward names of suitable and willing t ae
fs officers for consideration for the posts of CVO in CPSEs etc. for the financial year 2015-16 hae
ae (drawn up in the prescribed proforma ना), keeping in view the above mentioned aS
ae requirements and suitability criteria in all respects, along with complete updated CR dossier ;
aes or certified copies of ACRs (at least for last 5 years) and vigilance clearance of the 8
Be sponsored officers; preferably by 30th April; 2015. |. : cs
ue soo With regards, 2
es s : Yours sincerely, ae
ae co ae
eae o> Be
ae. है हि Inu Barua) ae
ce + To : oe
e All Secretaries to the Government of India. ae
a ” Copy to:= हे a
ah é . The Central Vigilance Commissioner, Central Vigilance Commission, Satarkata oe
४ i Bhawan, GPO Complex, INA, New Delhi. a
oe (ishnu Barua) a
eh Joint Secretary to the Government of India | Eee
a . a
S ond
S
a se . eS
rr
ue cae
Be ] हे हि
Hats : : f
ae . ee
Be ree
a ae
2082, ड़ See

<!-- page 4 -->

z Tentative vacancy positions upto 31.03.2016 . ie
६ eee
ee : ee
ges =_|Production 5 sk t
i [2 [Ministry of Shipping" |Mormugao Port Trust (MPT), [Goa___|-DIR [30-Aprid___| Ne
Hf |_3_ [Ministry of Shipping“. “[Coctin Shipyard Ltd. (CSL), |ocki__|_DIR_| Lae
: Cee ore pe :
ie oa
ts |= | [Department of Heavy Industry |NEPA Limited. Nepanagar | | : 2
४; 7 | [Department of Heavy Industry [NTPC BHEL Power Projects IChittot (A-P.) | ४ | ea
i [Private Limited (NBPPL) fens a
: [Ministry of Coal [Coal Mines Provident Fund ae
[i ee aco Pe [PR | a
a | > | [Department of Defence Bharat Dynamics Ltd. (BDL) [Reet | | {1-Apr-14 297
a Production A
eS [Department of Defence [Mazageon Dock Ltd (MDL) sone
fe | 13 [Ministry ofReilways किले international Led, [Dethi____|_38_|Stun-15__—_— ae
te . one
i 15 [Ministry of Road Transport & [National Highway Authority of JS f20-Jun-15 Te
a . Highways {India (NHAI) ay
: Department of [Mahanagar Telephone Nigam ee
|Telecommunications Ltd.(MTNL) te

ie [Deni | DIR_| ae
: 48 [Department of Fertilizers Rashtriya Chemicals and Fertilizers [é-Aug-15 a
e Led, (RF) | cae
e Ministry of Textiles [National Instittute of Fashion 10-Aug-15 Cee
2 ie eo | a
ILtd. (HEC) a

PI | |
ः (0५0 Reger
pe | a
|Telecommunications ae

ie | सा या अम्मा |
० [Gas us
oo EES Eee किन फफिमनला | ७ ०
९ हे |(SIVNL) ect Be
: Ministry of Power Power Grid Corporation of India 3T-Tan-16 ee
४ [Department of Atomic Energy [Electronics Corporation of India [3-Feb-16 ae
fi Ltd. (ECIL) he
ne 27 |Ministry of Housing & Urban [Housing & Urban Development ae
६ Poverty Alleviation Corporation Ltd. (HUDCO) ES
: 28 ~ [Department of Chemicals and [Hindustan Organics Chemicals [Going to vacate kate
| पी
a . 8
Bee 22 2
22 ee
fe” . Le
eS a
fen . Re
ae ना : . ey
BSS . Lose
Be . ay
20072: ee
