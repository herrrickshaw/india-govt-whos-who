---
doc_id: "248546adaadbaca8"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/39e459e8b20d2337b459f52fd06c51a0.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "3G Auction Update: 22nd April, 2010"
date: "2010-04-22"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "57bc7ec05dbdcf75"
---

<!-- page 1 -->

3G Auction daily public report
End of day 11
Round information
Date

22 April 2010

Number of Clock Rounds completed today

6

Total number of Clock Rounds completed to date

64

Information by circle
Aggregate
Demand at
Round 64
Price

Excess
Demand at
Round 64
Price

Provisional
Winning
Price at end
of Round 64

Price
Increment
applied for
Round 65

Service Area

Round
Price in
Round 64

Delhi

Rs 850.42
Crore

5

2

Rs 850.42
Crore

Rs 40.00
Crore

Mumbai

Rs 752.38
Crore

5

2

Rs 752.38
Crore

Rs 37.61
Crore

Maharashtra

Rs 696.96
Crore

5

2

Rs 696.96
Crore

Rs 34.84
Crore

Gujarat

Rs 589.16
Crore

2

-1

Rs 583.33
Crore

Rs 0.00
Crore

Andhra
Pradesh

Rs 626.51
Crore

3

0

Rs 626.51
Crore

Rs 6.26
Crore

Karnataka

Rs 638.48
Crore

3

0

Rs 638.48
Crore

Rs 6.38
Crore

Tamil Nadu

Rs 717.72
Crore

2

-1

Rs 710.62
Crore

Rs 0.00
Crore

Kolkata

Rs 218.56
Crore

3

0

Rs 218.56
Crore

Rs 2.18
Crore

Kerala

Rs 238.98
Crore

4

1

Rs 238.98
Crore

Rs 2.38
Crore

Punjab

Rs 140.63
Crore

4

0

Rs 140.63
Crore

Rs 1.40
Crore

Haryana

Rs 213.91
Crore

3

0

Rs 213.91
Crore

Rs 2.13
Crore

<!-- page 2 -->

Aggregate
Demand at
Round 64
Price

Excess
Demand at
Round 64
Price

Provisional
Winning
Price at end
of Round 64

Price
Increment
applied for
Round 65

Service Area

Round
Price in
Round 64

Uttar Pradesh
(E)

Rs 252.45
Crore

2

-1

Rs 249.96
Crore

Rs 0.00
Crore

Uttar Pradesh
(W)

Rs 269.70
Crore

2

-1

Rs 267.03
Crore

Rs 0.00
Crore

Rajasthan

Rs 245.53
Crore

0

-3

Rs 243.10
Crore

Rs 0.00
Crore

Madhya
Pradesh

Rs 229.34
Crore

3

0

Rs 229.34
Crore

Rs 2.29
Crore

West Bengal

Rs 124.86
Crore

1

-3

Rs 123.63
Crore

Rs 0.00
Crore

Himachal
Pradesh

Rs 30.30
Crore

2

-2

Rs 30.00
Crore

Rs 0.00
Crore

Bihar

Rs 33.74
Crore

1

-3

Rs 33.41
Crore

Rs 0.00
Crore

Orissa

Rs 30.30
Crore

0

-3

Rs 30.00
Crore

Rs 0.00
Crore

Assam

Rs 30.30
Crore

0

-3

Rs 30.00
Crore

Rs 0.00
Crore

North East

Rs 30.60
Crore

2

-1

Rs 30.30
Crore

Rs 0.00
Crore

Jammu and
Kashmir

Rs 30.30
Crore

0

-4

Rs 30.00
Crore

Rs 0.00
Crore
