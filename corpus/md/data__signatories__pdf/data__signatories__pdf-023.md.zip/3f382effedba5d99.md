---
doc_id: "3f382effedba5d99"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/587a8e1d94dd98df6024338d233feae7.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Constitution of Telephone Advisory Comittees (TACs) at Telecomm District level - procedure to be followed Detail"
date: "2005-09-16"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f3946ab23068699"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF COMMUNICATIONS & IT
DEPARTMENT OF TELECOMMUNICATIONS
517, SANCHAR BHAWAN, 2-0-ASHOKA ROAD, NEW DELHI-I
No. 8-01/2004-PHP

September 16, 2005

CIRCULAR
Subject:-

Constitution of Telephone Advisory Committees (TACs) at
Telecom District level - procedure to be followed.

A number of references and queries are being made from time to time by TAC
members as well as Telecom Districts regarding provision of rent-free telephone
connection at places out side the jurisdiction of concerned Telecom District.

In this regard it has been decided that, rent-free TAC telephone connection
will be provided at the residence of TAC member within the area jurisdiction of the
concerned TAC or at the 2ddress as given in the nomination letter. In the case of
Hon'ble MPs, TAC telephone connection may be installed at any residential address
of the respective MP as per his/her choice.
Any other query in this regard may be dealt as per the existing commercial policy
in this regard by the Chairman of each TAC.

All the pending cases in this regard be disposed off accordingly
This issues with the approval of Hon 'ble Minister of Communications and
Information Technology.
Hindi version will follow.
( S. T. ABBAS )
Director (PHP)
Tel. No. 2337253 l
To
The Chairman-cum-Managing Director, BSNL, New Delhi
The Chairman-cum-Managing Director, MTNL, New Delhi.
The All the Chief General Managers, Telecom Circle/Telephone District.
Copy to:­
1.
2.
3.
4.

PS to MOC & IT/MOS(C & IT)
PPS to Chairman (TC)
PPS to Member (S)
Press Information Officer, DOT; PIB, Shastri Bhawan, New Delhi.

~

~-

(Mts~1PAI)

Assistant Director General (PHP)
Tel. No. 23725254
FAX No. 23723581
