---
doc_id: "0dceb6bd42e6c1d8"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/dc58c90682cc1a5908a928238409d818.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Appointment of Shri J B Singh Staff No 92062 in the Grade of Executive Engineer on regular basis"
date: "2015-06-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5a01d0589684cc26"
---

<!-- page 1 -->

Government of India
Ministryof Communications & IT
Department of Telecommunications
Sanchar Bhawan, New Delhi-110001

No.3-1/2004-CWG

bated the 3rd June, 2015
ORDER

President is pleased to appoint Sh. J.B. Singh (Staff No. 92062),
Assistant Executive Engineer (C) an officer of the P&T Building Works,
Group "A" Service in the grade of Executive Engineer (C) on regular basis
in the pay scale of Rs. ·10,000-325-15,200/-(Pre- revised) w.e.f 30.3.. 2005
and until further orders.
2.
The order is subject to the final outcome of OA/WP/SLP on the
subject pending in various Courts. Further the effective date of promotion
is subject to the rectification from Hon'ble Guwahati High Court.
3.
On promotion, the seniority of Sh. J.B. Singh, in Executive Engineer
(C) has been fixed below Sh. Rajeev Sharma (Staff No. 92061) & (Sl. No.
17) and above Shri Rajneesh Singal (Staff No. 92063) & (Sl. No. 18) for the
panelyear 2004-05
4.

Assumption of charge report may be furnished to all concerned
.

~

()~b\lf
(D.S.S. Srinivasa Rao)
Under Secretary to the Govt. of India
Copy to:
1. P.S. to MOS(C & IT).
2. CMD, BSNL, Corporate Office, Bharat Sanchar Bhawan, Harish
Chander Mathur Lane, Janpath, New Delhi - 110001
3. Member (S), DOT, New Delhi
4. The CVO, DOT/Director(VA), DOT w.r.t. their letter dated 5.5.2015
& dated 12.5.2015.
5. Member (Planning) PSB, DOP, New Delhi
6. PGM(BW), BSNL, Corporate Office, Telegraph Office Building,
Kashmere Gate, Delhi - 110006.
7. Sr.DDG(BW)/DDG(Estt.)/CE(C), DOP HQ, New Delhi.
8. CS to Advisor(HRD), DOT, New Delhi
""
9. The Officer concerned through PGM(BW), BSNL Corporate Office,
New Delhi
10.0ffice Order Bundle

(D.S.S. Srinivasa Rao)
Under Secretary to the Govt. of India
