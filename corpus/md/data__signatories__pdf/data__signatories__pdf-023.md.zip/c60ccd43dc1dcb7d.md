---
doc_id: "c60ccd43dc1dcb7d"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/f6f011bef5a8a7cb667b81d4f2676cff.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '1099' to Central Accident and Trauma Services to State Government of Bihar"
date: "2013-08-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4072f34915893740"
---

<!-- page 1 -->

To,

All Access Service Providers

Subject: Allocation of Short Code '1099' as ' Central Accident and Trauma Service' to
State Government of Bihar.
I am directed to convey the approval of competent authority for allocation of Short
Code '1099 ' as Central Accident and Trauma Service' to . State Government of Bihar which
may be used for providing Services of Ambulance, Mortuary cum transpon van--services and
other Health Services in Bihar.
2.

The features of the Helpline are as stated below:
(i)
(ii)
(iii)

Category-I Service (i.e. mandatory service to be provided by all the Access
Sen1ice providers);
Accessibility: Restricted with the Bihar LSA.
Metered (Called Party Pays).

~

(Narayan Ram)
Section Officer (AS-III)
Tel: Fax :23710488

·Copy forwarded for information and necessary action to:
1. Secretary, TRAI
2. Sr. DDG (TEC)
