---
doc_id: "de475e6e4f4ccda8"
source_url: "https://www.dot.gov.in/static/uploads/2026/10/f4d8df23756616f199b25eb7b25a9d02.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Office order no 1 6 2014 CWG regarding Administrative control of P and T Building with Gp A service"
date: "2014-10-30"
pages: 3
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "007e7c483d983a5b"
---

<!-- page 1 -->

है Government of India
Ministry of Communications and Information Technology
Department of Telecommunications
No. 1-6/2014-CWG Dated: 30" October, 2014
OFFICE ORDER
In suppression of earlier orders, the Cadre Management of P&T Building Works (Gr.’
A’) Service shall be under the administrative control of Member (Services), DoT Head quarter,
New Delhi w.e.f. 01.11.2014,
2.0 Director (Civil) for cadre management of Civil discipline and Director (Architecture) for
cadre management of Architecture & Electrical discipline shall be reporting to Member (S).
The updated channel of submission is overleaf.
This issues with the approval of Secretary (T). ”
ye
)
(2
(D. S. S. Srinivasa Rao)
Under Secretary to the Government of India
Copy to:
(i) PS to Secretary(T), DoT, New Delhi.
(ii) PS to Secretary, Department of Posts, Dak Bhawan, New Delhi.
(iii) Member(S)/Member(T)/Member(F), Telecom Commission
(iv) Sr OM RNser(OWAdviser(T/Adviser(F)/Administrator(USOF)US(TWJS(AVCVO, Dor Hq.ND.
(v) Sr. DDG(BW), DoT Hq., New Delhi.
(vi) Sr. DDG, TEC, New Delhi.
(vii) Director(Electrical)/Director(Civil) DoT Hq., New Delhi. .
(vill) CS to Adviser (HRD), DoT Hq., New Delhi.
(ix) Director(IT), DoT Hq., ND —for uploading on DoT Website
Copy for information:
(i) PS to MOCIT, DoT, Sanchar Bhawan, New Delhi.

<!-- page 2 -->

- Government of India
Ministry of Communications and Information Technology
Department of Telecommunications
No. 1-6/2014-CWG Dated: 30" October, 2014
OFFICE ORDER ‘
In suppression of earlier orders, the Cadre Management of P&T Building Works (Gr.’
A’) Service shall be under the administrative control of Member (Services), DoT Head quarter,
New Delhi w.e.f. 01.11.2014,
2.0 Director (Civil) for cadre management of Civil discipline and Director (Architecture) for
cadre management of Architecture & Electrical discipline shall be reporting to Member (S).
The updated channel of submission is overleaf.
This issues with the approval of Secretary (T). np
A
62
(D. S. S. Srinivasa Rao)
Under Secretary to the Government of India
Copy to:
(i) PS to Secretary(T), DoT, New Delhi.
(ii) PS to Secretary, Department of Posts, Dak Bhawan, New Delhi.
(iil) Member(S)/Member(T)/Member(F), Telecom Commission
(iv) AS(T)/Adviser(O)/Adviser(T)/Adviser(F)/Administrator(USOF)/JS(T)/JS(A)ICVO,DoT Hq.ND.
(v) Sr. DDG(BW), DoT Hg., New Delhi.| Sr. D&G (TEeRm),
(vi) Sr. DDG, TEC, New Delhi.
(vii) Director(Electrical)/Director(Civil) DoT Hq., New Delhi.
(vili) CS to Adviser (HRD), DoT Hq., New Delhi.
(ix) Director(IT), DoT Hq., ND — for uploading on DoT Website
(02 Dircez Gea
Copy for information:
(i) PS to MOC&IT, DoT, Sanchar Bhawan, New Delhi.

<!-- page 3 -->

हद
Channel of submission

Se 5. आहइट0 (6७ = sCDirector (Arch)

| By Gadenewenentct |
Civil Discipline} Arch, & Elect. Discipline)

A&E Section
a 2
CWG Section
==. SOICOWG) estat. -
