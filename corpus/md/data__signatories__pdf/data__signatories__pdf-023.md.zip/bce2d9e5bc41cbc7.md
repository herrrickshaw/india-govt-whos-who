---
doc_id: "bce2d9e5bc41cbc7"
source_url: "https://www.dot.gov.in/static/uploads/2026/10/079c61292e630b6b022178b0e3c1efb2.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Review DPC Promotion to the grade of Superintending Engineer in the P and T building work services under the DoT in compliance with different CAT orders"
date: "2014-08-01"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6af8f165b4f9bf8a"
---

<!-- page 1 -->

..
No.2-2/2002/CWG(PT)R
Government of India
Ministry of Communications & IT
Department of Telecommunications

Sanchar Bhawan, New Delhi-110001
Dated the 1st August,2014

ORDER

Subject:-

Review DPC - Promotion to the grade of Superintending
Engineer(Civil) in the P&T Building Works Service under the
Department of Telecommunications in compliance with different CAT
Orders.

In compliance of the order of Hon'ble CAT Madras bench in OA No.
161/2001 as upheld by the High Court of judicature at Madras in WP No. 17603 of
2001, order dated 6.1.2011 of the Hon'ble CAT Patna bench in OA No 10/2010
filed by Shri M.S. Siddique & others, order dated 21.7.2011 of the Hon'ble CAT
Allahabad bench in OA No. 1304 of 2010 filed by Shri P.K. Jain & others, order
dated 20. 10.2011 of the Hon'ble CAT, Ernakulam bench in OA No. 734/2009 filed
by Shri P. Kailasam & OA No. 599 of 2010 filed by Shri M. Raithaswamy and
interimorder dated 21.11.2011 of the Hon'ble CAT(PB), New Delhi in OA No.
3508 of 2009 filed by Shri AK. Mukati, a review DPC was held by UPSC on
17.04.2014. on the direction of the Hon'ble CAT'S order, the Seniority List of
EE(C) was revised on dated 26.8.2009 and based on that a proposal of review
DPC was sent to UPSC to review the recommendation made by UPSC in the DPC
held earlier on 23rd and 24th December, 2004 for 94 vacancies and 25th March,
2005 for 15 vacancies for promotion to the grade of Superintending Engineer
(Civil).
Accordingly a review DPC was held by UPSC on 17.04.2014 and in
supersession of this office order of even dated 4. 1.2005, dated 4.2.2005 & dated
19.4.20005 the following Executive Engineers (Civil) of the P&T Civil Wing are
promoted to the grade of Superintending Engineer (Civil) in the pay scale of Rs
12,000-375-16,500/- on regular basis with effect from the dates indicated against
their names and until further orders :
Contd .. Pg. no.2

<!-- page 2 -->

-2­
No. 2-2/2002-CWG(Pt.) R

(

SI.
No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37

Staff
No.
90046
90047
90048
90163
90049
90050
90053
90054
90055
90056
90058
90164
90059
90068
90167
90060
90062
90063
90064
90065
90066
90070
90073
90074
90076
90077
90078
90079
90080
90081
90082
90109
90084
90085
90169
90086
90087

Name (S/Shri)
A.K. GUPTA
B.K. BINDAL
GURBAX SINGH
--·
R.K.S. YADAV
A.K. NAGAR
YOGESH KUMAR
RAMAN
S.C. VIJAY
S.C. MOHAN
A.K. BHATTACHARYA
S.S. GOYAL
S.C. SRIVASTAVA
S.C. MISHRA
P.S. MOHANDAS (SC)
S.Cc ARORA
JAGDISH CHANDRA
V.K. MALHAN
M.K. CHAWLA
P.K. GUPTA
P.K. RAJPAL
KRISHAN KUMAR
KISHAN SINGH (SC)
S.K. SAXENA
A.K. GUPTA
H.K. BANSAL
V.S. GUPTA
ASHOK KUMAR
V.L. KUSHARE
N.K. TYAGI
S.K. SHEL
J.C. ROY
RAJ KUMAR - II
V.K. JAIN
M.M.S. OBEROI
V. MAHALINGAM
D.K. GUPTA
VINAY SARAN

With effect from
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004

I

Ir
I

Contd ..3

<!-- page 3 -->

-3­
No. 2-2/2002-CWG(Pt.) R

(

(

38
39
40
41
42
43
44
45
46
47

90171
90095
90088
90173
90089
90090
90177
90091
90178
90093

R.K. JAIN
A.A. SIDDIQUI
S.P.S. GREWAL
SMT. NASREEN QUADRI
SUYRYA PRAKASH
AK. MITTAL
P.O. MARWAHA
HARBHAJAN SINGH
V.K. CHADHA
P.K. SHARMA

30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
3.0.12.2004

48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75

90170
90098
90099
90172
90083
90179
90103
90104
90105
90094
90106
90181
90107
90108
90182
90117
90109
90111
90112
90113
90387
90184
90114
90115
90185
90.116
90189
90119

B. AMBALAGAN (SC)
KAMESHWAR KAUL
V.B. GUPTA
OM PRAKASH
S.N.S. NIRANJAN
B.K. YADAV
VIPIN SHARMA
GANGA PRASAD
S. PATABHIRAMAN
R.N. SINHA
S.P. NARANG
ABRAHAM JACOB
P.K. GARG
H.K. MANDORA
S.V. JOSHI
D.S. MESHRAM
RAJ KUMAR I
AK.GARG
A.K. JAIN
A.K. GUPTA
AK. RAM (SC)
A. BHATTACHARYA
VIJENDRA KUMAR
CHANDER BHUSHAN
A.K. SATIJA
S. HARi KUMAR
A. SUNDER
A.K. PATHAK

30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30. 12.2004
30.12.2004
Contd.A

~~

<!-- page 4 -->

-4­
No. 2-2/2002-CWG(Pt.) R

(

(

76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107

90121
90122
90123
90388
90125
90391
90127
90128
90129
90130
90131
90132
90133
90134
90135
90136
90137
90138
90139
90389
90141
90390
90142
90392
90143
90394
90144
90395
90148
90399
90147
90145

AMARJIT SINGH
AK. BANSAL
ALOK K. SAHDEV
M. RATHINASAMY
S.S. DAHIYA (SC)
AK. VERGHESE (SC)
MUKESH K. JAIN
M.S. VENTAGUDY
M.K. BAHRGAVA
D.S. DESHWAL
S.K. BABBAR
P.K. JAIN
NIRAJ GOYAL
B. VENUGOPAL
B.J. CHIRANJIVI (SC)
TIKAM SINGH (SC)
AK. SAHA (SC)
AK. MUKATI
S.M. MURGOD
AM. DESHPANDE
P.B. AHUJA
M.S. SIDIQUI
H.R. KAUSHIK
R.C. GUPTA
P.P. GUPTA
C.S. SATPUTE (SC)
ABHAI KUMAR
N.K.SINGH (SC)
M.M.S. BHANDARI
S. CHELAPAN (SC)
RAKESH KUMAR
SUBIR KHARE

30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
30.12.2004
01.02.2005
19.04.2005
19.04.2005
19.04.2005
19.04.2005
19.04.2005
19.04.2005
19.04.2005
19.04 2005
19.04.2005
19.04.2005
19.04.2005
19.04.2005

Contd ... 5

<!-- page 5 -->

-5­
No. 2-2/2002-CWG(Pt.) R
108
109
110

90146
90149
90398

J. GANESHAN (SC)
SHAILENDRA SHARMA
S.P. RAM (SC)

19.04.2005
19.04.2005
19.04.2005

The officer at SI. No. 10 Sh. A.K. Bhattacharya retires from service
on 31.1.2005, against this retirement vacancy Sh. A.M. Deshpande at SI. No. 95
has been appointed w.e.f. 1.2.2005

~~Y'f\,~1'1

(~~~R1~·
Under Secretary to the Govt.of India
Tele. No.23372350

Copy to:
1. PPS to Member(T), DOT
2. Sh. B.K. Mathur, Under Secretary, UPSC, Dholpur House, New Delhi
w.r.t UPSC letter no. 1/34(5)/2012 AP 3 dated 23.04.2014
3. Sr. DDG(BW), DOT, New Delhi.
4. CE(C), DOP HQ, Oak Bhawan, New Delh.i for information & necessary
action
5. CMD, BSNL, Corporate Office, New Delhi for information & necessary
action
6. CMD, MTNL, CGO Complex, New Delhi for information & necessary
action
7. PGM(BW), BSNL, Corporate Office, New Delhi
8. The CE(BW-1), MTNL, Ground Floor, Telephone Exchange Building, Jor
Bagh, Lodhi Road, New Delhi - 110003
9. OL Section for Hindi Version.
10. Office Order Bundle
11. Director (IT) with for placing the order in DOT website.

Contd ... 6

<!-- page 6 -->

'

'

-6­
No. 2-2/2002-CWG(Pt.) R
12. Pr. CCA/CCA, Tamil Nadu/Bihar/UP(E)/Kerala/Delhi with request to file
MA before respective Hon'ble CAT benches appraising Hon'ble
Tribunals of the implementation of the Orders of respective Hon'ble CAT
benches in OA No. 161/2001 as upheld by the High Court of judicature
at Madras in WP No. 17603 of 2001, order dated 6.1.2011 of the
Hon'ble CAT Patna bench in OA No 10/201 O filed by Shri M.S. Siddique
& others, order dated 21.7.2011 of the Hon'ble CAT Allahabad bench in
OA No. 1304 of 2010 filed by Shri P.K. Jain & others, order dated
20.10.2011 of the Hon'ble CAT, Ernakulam bench in OA No. 734/2009
filed by Shri P. Kailasam & OA No. 599 of 2010 filed by Shri M.
Raithaswamy and interim order dated 21.11.2011 of the Hon'ble
CAT(PB), New Delhi in OA No. 3508 of 2009 filed by Shri A.K. Mukati.

(Nt.:1rf~\
Under Secretary to the Govt.of India

(
