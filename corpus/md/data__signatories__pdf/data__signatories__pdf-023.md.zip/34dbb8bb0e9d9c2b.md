---
doc_id: "34dbb8bb0e9d9c2b"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/215b6f593a09ad13ce318e8789592eb3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Unified Licence issued by AS Wing as on 25.11.2014"
date: "2014-11-25"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1947d8464ea9e6ac"
---

<!-- page 1 -->

List of Unified licences Up to 14.11 .2014 issued by AS Wing

s
NO

I

Name of Company

Date of grant of
Unified Licence

Idea Cellular Limited

11-10-201 3

2

Reliance Jio Infocomm Ltd

2 1-1 0-201 3

3

Sistema Shyam Teleservices
Limited

03-1 0-201 3

Mi s Telewings
Communications Pvt Ltd

4

5

Mi s Sify Technologies

Limited
Mis Hughes Communications

6

India Limited

Mis Sprint Telecom India

7

Private Limited

8

9
10
11

Mis Bhatti Airtel Limited

27.1 1.201 3

27.06.2014

01.08.2014

29.08.2014

16. 10.2014

M/s Vodafone India Limited 21 .1 1.2014
M/s Vodafone East Limited 21 .11 .2014
Mis Vodafone Mobile
21 .11 .2014
Services Limited

Authorisation detail

Date of
Authorisation

Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
NLD
ILD
VSAT
PMRTS
INSAT MSS-R
ISP-"A"
Resale !PLC
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
NLD Service
Access Service
Access Service
Access Service
Access Service
Access Service
Access Service
NLD
ILD
Access Service
ISP-"A"
ISP Category-A
NLD Service
ILD Service
CUG VSAT

Service Area
Assam
West Bengal
Kolkata
North East
Tamil Nadu (incl Chennai)
J&K
Orissa
All Circles
National Area
National Area
National Area
National Area
National Area
National Area
National Area
Delhi
Guiarat
Kamataka
Kera la
Kolkata
Tamil Nadu
UP (West)
West Bengal
National Area

National Area

01.08.2014
02.09.2014

Andhra Pradesh
Bihar
Gujarat
Maharashtra
UP( East)
UP(West)
National Area
National Area
Assam
National Area
National Area
National Area
National Area

NLD

National Area

NLD
ILD
ISP Category-A
Access Service
Access Service
ISP-"A"
CUG VSAT
Access Service
Access Service

National Area
National Area
National Area
Delhi
Kolkata
National Area
National Area
Mumbai
Kolkata

Access Service

Delhi

11 ­ 10-2013

21-10-2013

03.10.2013

03.09.2014

27. 11.2013

21.08.2014
28.08.2014

27.06.201 4

29.08.2014
29. 11.20 14
30.11.2014
03.03.2014
15.09.2014

29.11.2014
30.11 .2014
30.11 .2014
