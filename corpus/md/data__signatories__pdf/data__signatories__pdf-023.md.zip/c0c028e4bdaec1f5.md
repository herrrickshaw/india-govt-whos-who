---
doc_id: "c0c028e4bdaec1f5"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/b6120ea9abf027654e83b51088c0d6e4.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Letter related to extension of Security Certification Time"
date: "2015-07-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4b0e734125cf6918"
---

<!-- page 1 -->

No. 10-54/2010-CS-m (Pt)/22
Government ofindia
Ministry of Communications & IT
Department of Telecommunications
(Carrier Services Wing)
Sanchar Bhawan, 2.0 Ashoka Road, New Delhi -110 001
Dated:.31.07.2015
To

,..
All NLD/ILD Licensees
Refere11ce­
(i)
DoT letter No.10-54/2010-CS-HI (NLD) dated 31.05.2011 and
(ii)
Do1' letter No.10-54/20.10-CS-ill (ILD) dated 31.05.2011.
Subject: Extension of time for Security Certification of Telecom Equipment within India in
respect of License Amendment dated 31.05.2011 for security related concerns for expansion of
Telecom.Services in various zones of the country.
·
.

.

. .

.

.

Kindly refer to ILD/NLD Licence amendinents dated 31.05.20i I issued vlde above referred DoT
letters wherein one of the clause in these licence amendments states as under:
· "The licensee shall induct only thC?se network elements into his telecom network, .which have been got
tested as per relevant contemporary Indian or International Security Standards e.g. IT & IT related
elements against ISOIIEC 15408 standards, for Information Security Management System against
ISO 27000 series standards, Telecom and Telecom related elements against 3GPP security standards
3GPP2 security standards etc. from any international agency! labs of the standards e.g. · Common
Criteria labs in case of ISO I !EC 15408 standards until .3]"1 March;2013, From ]81 April 2013 the
certification shall to be got done from authorized and certified agencies I labs. in India. The copies of
test results and test certificates shall be kept by the .licensee for a period of 10 years from the date .of
procurement ofequipment. "
·

2. As per above clause, the certification wast(} be got done from 01.04.2013. Subsequently the date
was extended to 1st April 2015 vide DoT lettei·s No. 10-54/2010-CS-III (Pt.) (NLD) dated 07.07.2014
arid letter No. I 0-54/2010-CS-m (Pt.) (ILD) dated 07.07.2014.
·

3. Now, all NLD/ILD Licensees are hereby intimated that the requirement of security certification of .
. telecom equipment only from authorized and certified agencies/labs within India has been extended
further by twelve months from 1st April 2015 to 1st April 2016.
-:~\~
~\\ll1,
(Subhash Chandra Kesarwani)
Assistant Director General (CS-Ill)
Tel: 011-23372644
Email: sc.kcsanvani@niC.in
Cbpy to:
1.
2.
3.
4.
5.
6.

Secretary TRAI, New Delhi
Wireless advisor, WPC Wing, New Delhi
Sr. DDG (WPF)/Sr. DDG (TERM), DoT, New Delhi
DDG (Security)/DDG (AS)/DDG (DS)/DDG (LF)
JS (IS), MHA
ADG (IT), DoT, New Delhi, kindly upload on DoT Website.,
