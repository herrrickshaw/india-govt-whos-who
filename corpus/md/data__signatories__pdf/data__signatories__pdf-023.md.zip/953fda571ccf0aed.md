---
doc_id: "953fda571ccf0aed"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/a76e273c6c2efc270c7cf849c568dea5.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Presentation on Auction Rules"
date: "2013-02-11"
pages: 77
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2f58b9580f0e0a66"
---

<!-- page 1 -->

Auction of Spectrum in 1800MHz,
900MHz and 800MHz bands

Auction Rules
e-Procurement Technologies Limited
February 8, 2013

<!-- page 2 -->

Outline
Auction Format / Spectrum to be Auctioned
General Information
Clock Stage – Overviews
Total Demand / Excess Demand / Top-up Blocks
EMD Requirements / Eligibility
Activity Rules / Auction Activity Requirement
Spectrum Cap
Bid Submission / Tie Rules
Provisional Winning Bidders
Closing Conditions
Round scheduling and extensions
Information Policy & Security Features

<!-- page 3 -->

Auction Format
The winners of the number of Blocks for each Service
Areas in 1800MHz, 900MHz and 800MHz bands
respectively will be determined through the Clock Stage.
The Clock Stage determines a common winning price for
each Service Areas in each of the bands where spectrum
is available.
Auction of Spectrum in 1800MHz and 900MHz bands is
scheduled to commence from 11th March, 2013. The
same is referred to as “First Auction”.
Auction of Spectrum in 800MHz band will start 2 days
after the close of the First Auction. This auction is
referred to as “Second Auction”.

<!-- page 4 -->

Spectrum to be auctioned in 1800MHz Band
Auction to be conducted in the Service Areas of Delhi,
Mumbai, Karnataka and Rajasthan.
In the Service Areas of Delhi and Mumbai, 12 blocks each
of 1.25MHz (15MHz) will be put to auction.
In the Service Areas of Karnataka and Rajasthan, 8 blocks
each of 1.25MHz (10MHz) will be put to auction.
In the Service Areas of Karnataka and Rajasthan, provision
will also be made for spectrum up to 3 blocks each of
1.25MHz (3.75MHz), wherever available, for topping up
the 8 blocks put for auction to meet the requirement of
New Entrants, if such an exigency arises.
There are no top-up blocks available in the Service Areas
of Delhi and Mumbai.

<!-- page 5 -->

Spectrum to be auctioned in 900MHz Band
Auction to be conducted in the Service Areas of Delhi,
Mumbai, and Kolkata.
In the Service Areas of Delhi and Mumbai, 12 blocks
each of 1.25MHz (15MHz) will be put to auction.
In the Service Area of Kolkata, 10 blocks each of
1.25MHz (12.50MHz) will be put to auction.
There are no top-up blocks available in any of the

Service Areas in 900MHz band.

<!-- page 6 -->

Spectrum to be auctioned in 800MHz Band
Auction to be conducted in 21 Service Areas, except
Rajasthan.
3 blocks each of 1.25MHz (3.75MHz) will be put to auction
in 19 Service Areas. In the Service Areas of Andhra
Pradesh and Punjab, 2 blocks each of 1.25MHz (2.50MHz)
will be put to auction.
Provision will also be made for spectrum of 1 block of
1.25MHz, wherever available, for topping up the 3 blocks
put for auction to meet the requirement of New Entrants,
if such an exigency arises.
Top-up blocks are NOT available in the Service Areas of
Andhra Pradesh, Delhi, Kolkata, Maharashtra, Mumbai
and Punjab.

<!-- page 7 -->

General Information
Bidders will be categorized as an “Existing
Licensee” or as a “New Entrant” or as a “Renewal
Licensee” for each of the Service Areas. The
categorization will be separately done for both
the auctions.
In the First Auction, the Bidders whose license is
due for renewal in 2014 will be categorized as
“Renewal Licensees” in the respective Service
Area.
Bidders will be able to submit their bids for the
number of blocks depending on their
categorization in the respective Service Areas.

<!-- page 8 -->

Clock Stage – Overview – I
In the First Auction, there will be simultaneous bidding
for all the blocks put to auction in each of the 5 Service
Areas in both the bands (1800MHz and 900MHz band).
In the Second Auction, there will be simultaneous
bidding for all the blocks put to auction in each of the 21
Service Areas in 800MHz band.
The Clock Stage will consist of a number of Clock Rounds.
The first Clock Round will begin with all blocks in a
Service Area in both the bands being offered at the
Reserve Price.
The ability to make bids is subject to the number of
Eligibility Points held by bidders, EMD requirements and
activity rules.

<!-- page 9 -->

Clock Stage – Overview – II
After each clock round, the bidders in each Service
Areas will be ranked with respect to the Provisional
Winning Blocks which they hold as per the tie rules.
In case of the First Auction, ranking will be done for
each of the Service Areas in each of the bands.
If Total Demand in a Service Area for a Clock Round
Price is NOT less than the number of blocks put to
auction, in which case the Clock Round Price will be
increased in the following clock round , with the price
increment linked to the level of Excess Demand.
Total Demand will be calculated on basis of
Number of Blocks for which Bids have been
submitted for a particular Clock Round Price.

<!-- page 10 -->

Clock Stage – Overview – III
In the following round, bidders state whether they
wish to bid at the new prevailing prices for the
number of blocks which they are permitted to
depending on their categorization.
Clock rounds continue until there is no further
activity in each Service Area at current clock price.
Once the clock stage closes, the current
Provisional Winning Bidders are declared Winning
Bidders.
The Provisional Winning Price will become the
Winning Price for all winners in that Service Area.

<!-- page 11 -->

Total Demand & Excess Demand
Total Demand is calculated based on the Total Number
of Blocks for which bids have been submitted for a
Clock Round Price.
Excess Demand is calculated based on the Total
Demand minus the Total Blocks (excluding top-up
blocks) put up for Auction.
If Excess Demand is –ve, the Clock Round Price in the
subsequent Round will remain same as the last
completed Clock Round.
If Excess Demand is Zero or +ve, the Clock Round Price
in subsequent Round will be the Clock Round Price of
last completed Clock Round plus a strictly positive
price increment.

<!-- page 12 -->

Top-up Blocks
Allotment of top up blocks would be considered to
accommodate the demand of a New Entrant only.
Top up blocks, wherever available, will be utilized in the
case where the New Entrant becomes a Provisional
Winning Bidder for the number of block(s)
Which is Greater than Zero but less than Four in case
of 1800MHz band .
Which is equivalent to One in case of 800MHz band.
Topping up facility will be used to make a minimum
allocation of 4 blocks only (in case of 1800MHz band)
and 2 blocks (in case of 800MHz band) even if the
bidder might have submitted the bid for higher number
of blocks in the particular Service Area.

<!-- page 13 -->

Example (Total Demand, Excess Demand & Top-up)
Service Area – Karnataka (1800MHz band)
Total blocks put to Auction – 8, Top-Up blocks - 3
Rank

Bidder Name

No. of Blocks for
which Bid
Submitted

No. of Blocks allotted
as a Provisional
winning Bidder

1

Existing Bidder-1

1

1

2

New Bidder-1

4

4

3

Existing Bidder-2

1

1

4

New Bidder-2

5

2 + 2 top up

Total Demand = 11, Excess Demand = 3

<!-- page 14 -->

Example (Total Demand, Excess Demand & Top-up)
Service Area – Karnataka (800MHz band)
Total blocks put to Auction – 3, Top-Up block - 1
Rank

Bidder Name

No. of Blocks for
which Bid
Submitted

No. of Blocks allotted
as a Provisional
winning Bidder

1

Existing Bidder-1

2

2

2

New Bidder-1

3

1 + 1 top-up

3

Existing Bidder-2

1

0

4

New Bidder-2

2

0

Total Demand = 8, Excess Demand = 5

<!-- page 15 -->

Earnest Money Deposit Requirements
Each block in a Service Area in each of the bands
has a deposit requirement.
In any round, any bid for a combination of Service
Areas must have a total deposit requirement less
than the Earnest Money Deposit made.
Initial eligibility will be determined by the Earnest
Money Deposit .
The Notice contains full details of these rules.

<!-- page 16 -->

Eligibility to make bids
Each block in a Service Area in each of the bands has
been assigned a specific number of eligibility points.
Each bidder has an initial number of eligibility points in
the first round based on the Earnest Money Deposit.
A bidder will maintain or lose part or all of its eligibility
to bid in subsequent clock rounds depending on its bid
in the current clock round and on the auction activity
rules.
These rules allow bidders flexibility to switch between
Service Areas (except if they are currently a provisional
winner in any Service Area, in which case, they can
switch from that Service Area only after they are
outbid).

<!-- page 17 -->

Activity Rules – I
A bidder’s activity in a clock round is the sum of:
the number of eligibility points associated
with the block(s) in the Service Area(s) in
which the bidder has been determined to be a
provisional winner at the end of the last
completed clock round (provided the bidder
has not bid in the same Service Area(s) in the
same band in current Clock Round); and
the eligibility points associated with the
block(s) in the Service Areas where the bidder
has made new bids

<!-- page 18 -->

Activity Rules – II
A bidder must demonstrate bid activity in each
clock round that equals or exceeds a certain
percentage of its eligibility, otherwise its eligibility
will be reduced proportionately in the following
round
The percentage (Auction Activity Requirement)
will increase over the duration of the clock stage
from 80% to 90% and then finally to 100%.
These increases will be made by the auctioneer as
overall bidding activity declines across all circles.

<!-- page 19 -->

Auction Activity Requirement
Depending on AAR set for a clock round, bidder will be
required to maintain a minimum BAR (Bidder Activity
Requirement)
If the Activity is maintained, for the subsequent round;
The eligibility will be equal to original eligibility
If not, will be reduced accordingly (rounded down to
nearest whole number) as per below given formula

Bidder’s Eligibility Points
in Clock Round (R+1)

=

Activity Level in Clock
Round R
Auction Activity
Requirement in Round R

<!-- page 20 -->

Auction Activity Requirement
AAR %
80%
90%
100%

Min.
Eligibility
points to
bid for

Initial
Eligibility
70
70
70

Eligibility Eligibility
associated for next
round *
with Bid
56
63
70

60
70
70

Eligibility
associated
with Bid

70
50
70
60
End of Auction

Eligibility
for Next
Round**

62
66

If bidder is NOT a provisional bidder in any service
area in last completed round, and fails to submit a
new bid in the subsequent round, then Eligibility
points for subsequent round will become zero and
hence will not be able to participate further.

<!-- page 21 -->

Spectrum Cap
The upper limit (maximum blocks) for which a bidder can
bid in any Service Area in any band will be restricted by a
Cap which is as follows:
The Overall Cap for each of the Service Areas is
calculated as 25% of the Total Spectrum assigned for
Telecom services in all bands.
The Spectrum Cap in each Service Area in each band
(Band-wise Spectrum Cap for each Service Area) is
calculated as 50% of the Total Spectrum assigned for
Telecom Services in that particular band in the
respective Service Area.

It is to be noted that the Total Spectrum assigned also
includes the Spectrum (excluding Top-Ups) being put in
the Current Auctions.

<!-- page 22 -->

Maximum Bidding Cap
The maximum number of blocks for which a bidder can
submit a bid for each Service Area in each band would be
the LOWEST of the Spectrum (converted to blocks) as
mentioned below:
1)

Overall Spectrum Cap in the Service Area minus Total
Current Holding across all bands in the particular
Service Area

2)

Spectrum Cap in the band minus Current Holding of the
bidder in the respective band for a Service Area

3)

Total Spectrum put to auction (excluding top-up) in a
Service Area in the respective band.

<!-- page 23 -->

Bid Submission – First Auction
Service Areas of Delhi and Mumbai
New Entrant / Renewal Licensee
The bidder has to bid for a minimum of Four (4) blocks in
either 1800MHz or 900MHz band in the respective Service
Area.
Such bidder can bid for any number of block(s) (including
“No” selection) in the corresponding 900MHz or 1800MHz
band.
If the bidder is already a Provisional Winning Bidder for a
minimum of four (4) blocks in either of the band, then in the
subsequent round at a higher Clock Round Price, if the bidder
opts for a “No” in that particular band, it will be construed as
equivalent to have submitted four (4) blocks in that particular
band. Such bidder can bid for any number of block(s) in the
corresponding band.

<!-- page 24 -->

Delhi and Mumbai – Submissions not Allowed
If the Bidder is NOT a Provisional Winning Bidder at the end of the
Previous Clock Round, following submissions will not be allowed

Case – 1

Case – 2

Case – 3

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

0

Yes

Less than 4

1800MHz

0

Yes

Less than 4

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

0

Yes

Less than 4

1800MHz

0

No

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Delhi

900MHz

0

No

1800MHz

0

Yes

Select Blocks

Less than 4

<!-- page 25 -->

Delhi and Mumbai – Submissions not Allowed
If the Bidder is a Provisional Winning Bidder at the end of the
Previous Clock Round, following submissions will not be allowed

Case – 1

Case – 2

Case – 3

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

2

Yes

Less than 4

1800MHz

0

Yes

Less than 4

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

4

Yes

Less than 4

1800MHz

0

No

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Delhi

900MHz

0

No

1800MHz

4

Yes

Select Blocks

Less than 4

<!-- page 26 -->

Valid Bids – Delhi and Mumbai
Case – 1

Case – 2

Case – 3

Case – 4

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

0

Yes

>3 / Any Number

1800MHz

0

Yes

Any Number / >3

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

0

Yes

Any Number

1800MHz

4

No

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Delhi

900MHz

0

No

1800MHz

4

Yes

>3

Service
Area

Band

Provisionally
Allocated Blocks

Want to
Bid

Select Blocks

Delhi

900MHz

0

Yes

>3 / Any Number

1800MHz

4

Yes

Any Number / >3

Select Blocks

<!-- page 27 -->

Bid Submission – First Auction
Service Areas of Delhi and Mumbai
Existing Licensee
The bidder will be able to submit the bid for a
minimum of One (1) block.
The bid of the bidder in any band is not bound in
any way with the bid in the corresponding band .

<!-- page 28 -->

Bid Submission – First Auction
Service Area of Kolkata

New Entrant
The bidder is required to bid for a minimum of Four
(4) blocks.

Existing Licensee / Renewal Licensee
The bidder can submit a bid for a minimum of One
(1) block

<!-- page 29 -->

Bid Submission – First Auction
Service Area of Karnataka and Rajasthan

New Entrant
The bidder will be required to bid for a minimum of
Four (4) blocks.

Existing Licensee
The bidder can submit a bid for a minimum of One
(1) block
Since there is no Spectrum due for renewal in 2014 in
the Service Areas of Karnataka and Rajasthan, there
will not be any categorization of bidders as “Renewal
Licensees” in these Service Areas.

<!-- page 30 -->

Bid Submission – Second Auction
New Entrant
The bidder will be required to bid for a minimum of
Two (2) blocks.

Existing Licensee
The bidder can submit a bid for a minimum of One
(1) block

There would be no bidders categorized as “Renewal
Licensee” in the Second Auction (800MHz band).

<!-- page 31 -->

Provisional Winning Blocks
For a Service Area in each band, Provisional Winning Blocks
are determined as follows:
Only the blocks submitted at the Current Clock Round
Price would be considered.
Hence, if there is a bid, even for a single block at the
Current Clock Round Price, the Provisional Winning
Block(s) from the previous Clock Round at a lower Clock
Round Price will NOT be considered.
Only in the case, where there is No bid at the Current
Clock Round Price, the Provisional Winning Blocks from
the previous Clock Round at a lower Clock Round Price will
be considered.
A bidder, who has been allocated ‘n’ blocks as Provisional Winning Bidder at the end
of last completed Clock Round for a Service Area in a particular band, will not be
allocated more than ‘n’ blocks in the subsequent round, if such bidder is NOT
revising the bid in the subsequent round for higher number of blocks.

<!-- page 32 -->

Provisional Winning Bidders
For a Service Area in a particular band, the Provisional
Winning Bidders are determined as follows:
The bidders who have submitted the Provisional
Winning Blocks will be ranked.
After each Clock Round, when the results of the
Rounds are declared, a bidder can be allotted any
number of blocks “equal to or less than” what has
been submitted at a Clock Round Price depending on
the ranking.
In any case, a bidder would be declared as a
Provisional Winning Bidder only if he is allocated the
minimum number of blocks required for each
category of bidders for each of the Service Areas.

<!-- page 33 -->

Provisional Winning Bidders
The minimum number of Provisional Winning
Block(s) required for a bidder to be declared as a
Provisional Winning Bidder is as given below:
For all the Service Areas in each bands, the
minimum number of Provisional Winning Blocks
required for a bidder categorized as an “Existing
Licensee” to be declared as a Provisional Winning
Bidder is One (1), irrespective of the number of
blocks for which the bid has been submitted.

<!-- page 34 -->

Provisional Winning Bidders (1800MHz & 900MHz band)
In the Service Areas of Delhi & Mumbai, the
minimum number of Provisional Winning Blocks
required for a bidder categorized as a “New Entrant”
or as a “Renewal Licensee” to be declared as a
Provisional Winning bidder would be 4 blocks in at
least one of the band (1800MHz or 900Mhz band),
irrespective of whether the bidder has submitted a
bid for more than 4 blocks.

<!-- page 35 -->

Provisional Winning Bidders (1800MHz & 900MHz band)
In the Service Area of Kolkata, the minimum number
of Provisional Winning Blocks required for a bidder
categorized as a “Renewal Licensee” to be declared
as a Provisional Winning bidder would be 1 block,
irrespective of whether the bidder has submitted a
bid for more than 1 block.
In the Service Area of Kolkata, Karnataka and
Rajasthan, the minimum number of Provisional
Winning Blocks required for a bidder categorized as a
“New Entrant” to be declared as a Provisional
Winning bidder would be 4 blocks, irrespective of
whether the bidder has submitted a bid for more
than 4 blocks.

<!-- page 36 -->

Provisional Winning Bidders (800MHz band)
In any Service Area, the minimum number of
Provisional Winning Blocks required for a bidder
categorized as a “New Entrant” to be declared as a
Provisional Winning bidder would be 2 blocks,
irrespective of whether the bidder has submitted a
bid for more than 2 blocks.

<!-- page 37 -->

Provisional Winning Prices
For a Service Area in a particular band:
At the end of each Clock Round, all the
Provisional Winning Blocks would have
been submitted at the same Price only.
The price at which the Provisional Winning
Blocks have been submitted becomes the
Provisional Winning Price.

<!-- page 38 -->

Ranking Information – I
Rank will be generated for each Service Area in each of
the band at the end of each Clock Round.

Change from
auction of
November, 2012

Only those Bidders who have submitted their
bids for the Service Area(s) in a band at the
Clock Round Price of the Current Clock Round
will be considered for ranking for the respective
Service Area(s) in the particular band at the
end of this particular Clock Round.
Only in the case where there are NO bids at the
Clock Round Price of the Current Clock Round, the
Provisional Winning Bidders from the immediate
previous Round at a lower Clock Round Price will be
considered.

<!-- page 39 -->

Ranking Information – II
A Renewal Licensee has an entitlement for retaining up to
a maximum of 10MHz spectrum or Current Holding
(Prescribed Limit), whichever is less. For this purpose,
1800MHz and 900MHz band will be considered as a Single
band. This entitlement has been incorporated in the
ranking rule and to be exercised by Renewal Licensees in
Service Areas of Delhi and Mumbai solely by participation
and bidding. The priority in ranking for retention in
900MHz band is limited to 2.5MHz only. The priority in
ranking for the balance spectrum up to the prescribed
limit will be accorded in the 1800MHz band, if the
Renewal Licensee submits the bid in this band.
For the Auction of Spectrum in 800MHz band (Second
Auction), there would be no bidders categorized as
“Renewal Licensee”.

<!-- page 40 -->

Consequences
Even if there is a bid for a Single block at a higher
Clock Round Price, all the Provisional Winning
Bidders from the earlier Clock Round at a lower
Clock Round Price will cease to remain as a
Provisional Winning Bidder, unless the same bidder
has submitted the bid at the higher Clock Round
Price.
In the Service Areas of Delhi and Mumbai, If a New
Entrant or a Renewal Licensee bidder is not
allocated the minimum 4 blocks required to be
declared as a Provisional Winning Bidder, in at least
one of the bands (1800MHz or 900MHz band), in
which case, the bidder will also not be allocated the
blocks in the corresponding band.

<!-- page 41 -->

Tie (Ranking) Rules – 1
A bidder, who is categorized as a “Renewal
Licensee”, will be ranked on priority for the
spectrum up to which the bidder is entitled for
retaining;
Where there is a tie according to the first criteria,
ranking will be in descending order of the highest
Clock Round Price when the bid was submitted in
the earlier rounds (excluding the Current round
for which the rank is being generated) in the
respective Service Area for a particular band;

<!-- page 42 -->

Tie (Ranking) Rules – 1I
Where there is a tie according to the first two criteria,
ranking will be in descending order of the count of the
number of times the bid has been submitted for a Unique
Clock Round Price for the particular Service Area in the
particular band;
Where there is a tie according to the first three criteria,
ranking will be in descending order according to the total
value of all Blocks for which bid has been submitted by
the bidder for all the Service Areas across all the bands at
the Current Clock Round Price;
Where there is a tie according to the first four criteria,
ties will be broken according to a random index assigned
to the Bid (in ascending order) in that service area when
it is received by the EAS

<!-- page 43 -->

Example – Delhi and Mumbai (Bids Submitted)
Bids submitted for the Service Area of Delhi in Round R. (Total
Blocks put to Auction = 12 in each band)
Bidder Name
Bidder-1
Bidder-2
Bidder-3
Bidder-4
Bidder-5
Bidder-6

Categorization
New
Existing
New
Renewal
Existing
Renewal

Band

No. of Blocks for which
Bid Submitted

1800MHz

4

900MHz

2

1800MHz

2

900MHz

0

1800MHz

5

900MHz

0

1800MHz

4

900MHz

2

1800MHz

3

900MHz

1

1800MHz

4

900MHz

4

<!-- page 44 -->

Explanation of above Example
Ranking will be generated for each Service Area for each
band. Hence, in the above example, ranking will be
generated for Delhi for 1800MHz band and 900MHz band
separately.
As per the Tie (Ranking) Rules, Renewal Licensees will be
ranked on priority for the spectrum up to which the
bidder is entitled for reservation.
If a Renewal Licensee bidder has submitted a bid for more
than 2 blocks in 900MHz band, wherein the Renewal
Licensee is entitled to retain up to 2 blocks (2.5MHz) in
900MHz band, in which case, 2 blocks will be ranked on
priority and the balance blocks would be considered for
Normal ranking.

<!-- page 45 -->

Explanation of above Example
Provisional Winning Blocks will be ranked virtually.
The bidders holding the Provisional Winning Blocks would
be declared as the Provisional Winning Bidders.
The Provisional Winning Bidders would be considered
subject to satisfying the minimum criteria for being
declared as Provisional Winning Bidders. If any of such
bidder(s) does not satisfy the minimum criteria in which
case, the next ranked (virtual) Provisional Winning Blocks
would be considered for ranking.
Only the Provisional Winning Bidders would be ranked.

<!-- page 46 -->

Example – Delhi and Mumbai (Ranking Process)
Ranking Process for 900MHz band in Delhi
Bidder Name
Bidder-1

Categorization
New

Band

No. of Blocks for which
Bid Submitted

900MHz

2

Blocks – BL1, BL2
Bidder-2

Existing

900MHz

0

Bidder-3

New

900MHz

0

Bidder-4

Renewal

900MHz

2

Blocks – BL3, BL4
Bidder-5

Existing

900MHz

1

Blocks – BL5
Bidder-6

Renewal

900MHz

4

Blocks – BL6, BL7,BL8,BL9

<!-- page 47 -->

Explanation of above Example (900MHz)
Bidder-4 & Bidder-6, being Renewal Licensees, are
entitled for Priority Ranking up to 2 blocks in 900MHz.
Hence, 2 blocks of Bidder-4 & Bidder-6 will be ranked
higher as Provisional Winning Blocks.
Balance of 2 blocks of Bidder-6 will be considered for
Normal Ranking.
The blocks submitted by other bidders will be considered
for Normal Ranking.

<!-- page 48 -->

Virtual Rank (Priority Ranking)
Blocks for Priority
Ranking

Bidder Name

BL3, BL4

Bidder-4

BL6, BL7

Bidder-6

Based on the parameters of the Tie breaking rule, the
above two bidders would be ranked virtually.
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-6

2

1

Bidder-4

2

2

<!-- page 49 -->

Virtual Rank (Normal Ranking)
Blocks for Normal Ranking

Bidder Name

BL1, BL2

Bidder-1

BL5

Bidder-5

BL8, BL9

Bidder-6

Based on the parameters of the Tie breaking rule, the
above three bidders would be ranked virtually below
the Priority Rankers for the balance (12-4=8) blocks.
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-1

2

3

Bidder-5

1

4

Bidder-6

2

5

<!-- page 50 -->

Final Ranking of Provisional Winning Bidders
Bidder Name

No. of Blocks
allocated Provisionally

Rank

Bidder-6

4

1

Bidder-4

2

2

Bidder-1

2

3

Bidder-5

1

4

• The rank of the Renewal Licensees generated and displayed
in the Final Ranking will be the rank generated as a Priority
Ranker only.
• It could happen that in 900MHz, such bidders can be
allotted partial or No blocks from the Normal Blocks
depending on the rank generated for the Provisional
Winning Blocks (Normal Rank) and depending on the Excess
Demand.

<!-- page 51 -->

Example – Delhi and Mumbai (Ranking Process)
Ranking Process for 1800MHz band in Delhi
Bidder Name
Bidder-1

Categorization
New

Band

No. of Blocks for which
Bid Submitted

1800MHz

4

Blocks – BL1, BL2, BL3, BL4
Bidder-2

Existing

1800MHz

2

Blocks – BL5, BL6
Bidder-3

New

1800MHz

5

Blocks – BL7, BL8, BL9, BL10,BL11
Bidder-4

Renewal

1800MHz

4

Blocks – BL12, BL13, BL14, BL15
Bidder-5

Existing

1800MHz

3

Blocks – BL16, BL17, BL18
Bidder-6

Renewal

1800MHz

4

Blocks – BL19, BL20, BL21, BL22

<!-- page 52 -->

Explanation of above Example (1800MHz)
Bidder-4 & Bidder-6, being Renewal Licensees, are
entitled for Priority Ranking up to a maximum of 6 blocks
in 1800MHz, since they have got the priority ranking of 2
blocks in 900MHz band.
Since, both the bidders have submitted the bid for 4
blocks each, they will be entitled for priority ranking for 4
blocks each.
Hence, 4 blocks of Bidder-4 & Bidder-6 will be ranked
higher on priority basis as Provisional Winning Blocks.
The blocks submitted by other bidders will be considered
for Normal Ranking.

<!-- page 53 -->

Virtual Rank (Priority Ranking)
Blocks for Priority Ranking

Bidder Name

BL12, BL13, BL14, BL15

Bidder-4

BL19, BL20, BL21, BL22

Bidder-6

Based on the parameters of the Tie breaking rule, the
above two bidders would be ranked virtually.
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-4

4

1

Bidder-6

4

2

<!-- page 54 -->

Virtual Rank (Normal Ranking)
Blocks for Normal Ranking

Bidder Name

BL1, BL2, BL3, BL4

Bidder-1

BL5, BL6

Bidder-2

BL7, BL8, BL9, BL10,BL11

Bidder-3

BL16, BL17, BL18

Bidder-5

Based on the parameters of the Tie breaking rule, the above
Four bidders would be ranked virtually below the Priority
Rankers for the balance (12-8=4) blocks.
Considering the balance blocks available for ranking, different
scenarios are as shown in the next slides.

<!-- page 55 -->

Virtual Rank (Normal Ranking)
Scenario – 1
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual Rank

Bidder-1

4

3

Bidder-2

0

4

Bidder-3

0

5

Bidder-5

0

6

Final Ranking of Provisional Winning Bidders
No. of Blocks allocated
Provisionally

Rank

Bidder-4

4

1

Bidder-6

4

2

Bidder-1

4

3

Bidder
Name

<!-- page 56 -->

Virtual Rank (Normal Ranking)
Scenario – 2
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual Rank

Bidder-2

2

3

Bidder-1

0

4

Bidder-3

0

5

Bidder-5

2

6

Final Ranking of Provisional Winning Bidders
No. of Blocks allocated
Provisionally

Rank

Bidder-4

4

1

Bidder-6

4

2

Bidder-2

2

3

Bidder-5

2

4

Bidder
Name

<!-- page 57 -->

Virtual Rank (Normal Ranking)
Scenario – 3
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual Rank

Bidder-3

4

3

Bidder-1

0

4

Bidder-5

0

5

Bidder-2

0

6

Final Ranking of Provisional Winning Bidders
No. of Blocks allocated
Provisionally

Rank

Bidder-4

4

1

Bidder-6

4

2

Bidder-3

4

3

Bidder
Name

<!-- page 58 -->

Example – Karnataka and Rajasthan (Ranking Process)
Ranking Process for 1800MHz band in Karnataka
Bidder Name

Categorization

Bidder-1

New

Band

No. of Blocks for
which Bid
Submitted

1800MHz

4

Blocks – BL1, BL2, BL3, BL4
Bidder-2

Existing

1800MHz

3

Blocks – BL5, BL6, BL7
Bidder-3

New

1800MHz

4

Blocks – BL8, BL9, BL10, BL11
Bidder-4

Existing

1800MHz
Blocks – BL12, BL13

2

<!-- page 59 -->

Virtual Rank
Scenario – 1
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-1

4

1

Bidder-2

3

2

Bidder-3

1+3 top-up

3

Bidder-4

0

4

Final Ranking of Provisional Winning Bidders
No. of Blocks allocated
Provisionally

Rank

Bidder-1

4

1

Bidder-2

3

2

Bidder-3

4

3

Bidder
Name

<!-- page 60 -->

Virtual Rank
Scenario – 2
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-1

4

1

Bidder-2

3

2

Bidder-4

1

3

Bidder-3

0

4

Final Ranking of Provisional Winning Bidders
No. of Blocks allocated
Provisionally

Rank

Bidder-1

4

1

Bidder-2

3

2

Bidder-4

1

3

Bidder
Name

<!-- page 61 -->

Example – 800MHz band Auction (Ranking Process)
Ranking Process for 800MHz band in Karnataka
Bidder Name

Categorization

Bidder-1

New

Band

No. of Blocks for
which Bid
Submitted

800MHz

3

Blocks – BL1, BL2, BL3
Bidder-2

Existing

800MHz

2

Blocks – BL4, BL5
Bidder-3

New

800MHz

2

Blocks – BL6, BL7
Bidder-4

Existing

800MHz

3

Blocks – BL8, BL9, BL10

<!-- page 62 -->

Virtual Rank
Scenario – 1
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-1

3

1

Bidder-2

0

2

Bidder-3

0

3

Bidder-4

0

4

Final Ranking of Provisional Winning Bidders
Bidder
Name

Bidder-1

No. of Blocks allocated
Provisionally

Rank

3

1

<!-- page 63 -->

Virtual Rank
Scenario – 2
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-2

2

1

Bidder-3

1+1 top-up

2

Bidder-1

0

3

Bidder-4

0

4

Final Ranking of Provisional Winning Bidders
No. of Blocks allocated
Provisionally

Rank

Bidder-2

2

1

Bidder-3

2

2

Bidder
Name

<!-- page 64 -->

Virtual Rank
Scenario – 3
Assuming the Virtual rank generated is as below:
Bidder Name

No. of Blocks allocated
Provisionally

Virtual
Rank

Bidder-4

3

1

Bidder-2

0

2

Bidder-3

0

3

Bidder-1

0

4

Final Ranking of Provisional Winning Bidders
Bidder
Name

Bidder-4

No. of Blocks allocated
Provisionally

Rank

3

1

<!-- page 65 -->

Closing Rule
The final clock round will be the first clock
round in which:
The Auction Activity Requirement is
100%; and
There is no activity in any of the Service
Areas i.e. for every Service Area, there is
no bid submitted by any of the bidders

<!-- page 66 -->

Round scheduling and Extensions
Default timetable for clock rounds:
Clock Round schedules will be from Monday –
Saturday, between 09.30 and 19.00 hrs.
Minimum round length will be for 30 minutes for the
First Auction and 60 minutes for the Second Auction.
Minimum time between rounds will be 20 minutes.
Given this, bidders will have the ability to extend rounds
Extension budget of 240 minutes (4 hrs) held by each
bidder.
Extension budget to be reduced in 10-minute
intervals.
Bidders can extend any clock round by a maximum of
1 hour (subject to availability of extension budget).

<!-- page 67 -->

Contingency Measures – I
Bids must be made through the Electronic Auction
System (EAS)
No other means of submission of bids will be
accepted.
Extensions are available to safe-guard against
minor technical problems and bidders should
consider carefully the implications of deliberately
using the extension budget to buy time for their
decisions.
Bidders will be given opportunity to access the
electronic auction system prior to the auction and
check that their systems work.

<!-- page 68 -->

Contingency Measures – II
In the event of any widespread technical problem
affecting multiple bidders, the auctioneer may
exceptionally:
Re-schedule the start of a Clock Round whose
starting time has been announced provided
that the Clock Round has not yet started;
Re-schedule the finishing time of a Clock
Round in progress;
Cancel and re-run a round provided no results
have been released.

<!-- page 69 -->

Information Policy

Before the relevant auction the following
information will be made public about each
bidder:
Ownership structure
Amount of EMD submitted
Limited transparency of bids during the auction.

<!-- page 70 -->

Information Policy for the Clock Rounds – I
At the end of each clock round information circulated
to all bidders will be confined to:
Clock Round Price per Block in each Service Area
of the last completed Clock Round;
Aggregate demand at the last completed Clock
Round Price;
Excess demand in the last completed Clock Round
Price;
Price Increment to be applied in each Service
Area;
Clock Round Price per Block in each Service Area
to be applied for the following round;

<!-- page 71 -->

Information Policy for the Clock Rounds – II

Eligibility Points available for following round;
The Provisional Winning Price;
The Number of Provisional Winning Blocks
held by the respective bidder;
Rank of the bidder in each of the Service Area,
if he is a Provisional Winning Bidder.

<!-- page 72 -->

Information Policy for the Clock Rounds – III

At the end of the Clock Round, the Auctioneer will
announce the Provisional Winning Price (Common
Winning Price) for each Service Areas.
At no stage during the Clock Rounds, will the
names of the bidders submitting their bids be
announced.
At the end of the Auction, all information about
the bidders and the prices will be released.

<!-- page 73 -->

Security Measures – I
Security of electronic auction system will be
protected by SSL encryption, user-id / password
and digital signature certificates.
Qualified Bidders will be provided with a User-id
(login-id) to access the EAS.
Qualified bidders will have to procure a Digital
Signature Certificate issued by any of the valid
Certifying Authority approved by Controller of
Certifying Authorities in India.

<!-- page 74 -->

Security Measures – II
Maximum of two Digital Signature Certificates can
be mapped with a User-Id.
The bidders can access the EAS using the Single
User-Id which is mapped with 2 Digital Signature
Certificates and from a maximum of 4 different
Public Static IP Address.
If the Authorised Signatories of both the Auction
are same, the same Digital Signature Certificates
would suffice.

<!-- page 75 -->

IT Requirements – I
The EAS supports the following Operating System:
Windows XP (Service Pack 3)
Windows Vista (Service Pack 3)
Windows 7 (Service Pack 1)
Following web browsers will be supported:
Internet Explorer 9.0
Mozilla Firefox 13.x
Google Chrome 20.x
Latest version of Java
Strongly recommend a clean installation guaranteed free
from viruses and trojans and that computer is not used to
access other websites.

<!-- page 76 -->

IT Requirements – II
Recommend that any computer with digital
certificates installed is kept physically secure.
Bidders should
connection.

have

a

reliable

Internet

Essential backup systems.
Pre-qualified bidders are strongly recommended
to ensure that their respective passwords and
Digital Signature Certificates are not compromised
in any way.
Full requirements will be specified in software
manual for bidders

<!-- page 77 -->

Thank you
