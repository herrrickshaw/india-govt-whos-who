---
doc_id: "dca25f29fb7bf2ef"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/4519d5f07639b21d6fd3ab1e4c7fe2c3.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '1099' to Central Accident and Trauma Service' to State Government of Bihar"
date: "2013-08-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "39b534cb26806291"
---

<!-- page 1 -->

F.No.16-3/2013-AS-Ill/.t.'?;if­
Govemment of India
Ministry of Communications & l.T.
Depai1ment of Telecommunications
(Licensing Cell (AS-lll Section)
Sanchar Bhawan, 20, Ashoka Road,
New Delhi-11000 I
' 2013
Dated: 02.08.
To,
All Access Service Providers

Subject: Allocation of Short Code '1099' as ' Central Accident and Trauma Service' to
State Government ofBihar.
I am directed to convey the approval of competent authority for allocation of Short
Code 'l 099' as Central Accident and Trauma Service' to State Government of Bihar which
may be used for providing Services of Ambulance, Mortuary cum transport van services and
other Health Services in Bihar.
2.

The features of the Helpline are as stated below:
(i)
(ii)
(iii)

Category-I Service (i.e. mandatory service w be pro·v-ided by all the Access
Service providers);
Accessibility: Restricted with the Bihar LSA.
Metered (Called Party Pays).
(Narayan Ram)
Section Officer (AS-Ill)
Tel: Fax :23710488

Copy forwarded for information and necessary action to:
1.
2.
3.
4.
5.
6.

Secretary, TRAI
Sr. DDG (TEC)
CMD, BSNL
CMD,MTNL
Chief Secretary, State Govt. of Bihar.
Secretary, Health cum Executive Director, State Govt. of Bihar, with reference to
your Letter No. SHSB/Gen.Admin/309/20 IO/Part-1/3109 dated 30.3 .2013
7. Director (S-1), DoT, HQ with request to circulate the sanction to related TERM Cells.
~irector (IT) with request to kindly upload on DoT Website.
0
