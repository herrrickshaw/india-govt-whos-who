---
doc_id: "ca4a9bc0eeb51b54"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/189a16127267821e2060ad748cda7aa9.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Repatriation of Group 'A' officers of various services working on deemed deputation in BSNL / MTNL back to their parent Department of Telecommunications (DoT)- Regarding."
date: "2011-11-04"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7ec02174e60c7367"
---

<!-- page 1 -->

Government of India
Ministry of Communications & Information Technology
Department of Telecommunications
(Absorption Cell)
520, Sanchar Bhavan,
20 Ashoka Road, New Delhi-110001
No. A-11013/33/2011-Absorption Cell

Dated: Jed November, 2011

Subject: Repatriation of Group 'A' officers of various services working on
deemed deputation in BSNL/MTNL back to their parent Department of
Telecommunications (DoT)- Regarding.
Reference: This office letter No. A-11013/31/2008-Abs.Cell dated 22.09.2011.
Through DoT Office Memorandum No.A-11013/31/2008-Abs.Cell dated
22.09.2011, all serving Group 'A' officers of Indian Telecom Service (ITS),
Telegraph Traffic Service (TTS), Telecom Factory Service (TFS), P & T Building
Works Service (Civil, Electrical & Architectural), Indian .P&T Accounts and
Finance Service (IP&T A&FS) and General Central Service (GCS) working on
deemed deputation in BSNL/MTNL were asked to exercise· their option for
absorption in BSNL/MTNL or to continue in the Government service. It was also
stipulated that officers not exercising any option will be deemed to have opted
for Government service and that no conditional option shall be accepted and any
sµch offer shall be treated as if the officer has not exercised option for absorption
in BSNL/MTNL.
2.
By the same above-said O.M. dated 22.09.2011, the last date for exercising
option by officers was prescribed as 08.11.2011. Several officers have given their
options for absorption in BSNL/MTNL or for Government Service in response to
above OM. Action to consider issue of Allocation Order (Presidential Order) in
respect of those officers who have exercised option for absorption in BSNL/
MTNL has been initiated.
3.
There are. many officers who have approached various Courts (CAT and
High Courts). In some cases some of the Associations have also approached the
Courts. Thus, all the Group 'A' officers on deemed deputation in BSNL/MTNL
fall in the following categories with respect to the absorption process:­

J/

()\\~\\\\\ . ·'Ck\)
ycl1)

/

\(:\''

~~~~.,

<(:ff'

Contd .... 2/

<!-- page 2 -->

: 2:

Category I

Officers who have opted for MTNL/BSNL.

Category II

Officers who have opted for Government Service.

Category III Officers who have approached different Courts where
hearing is in progress but no stay order has been granted by
these Courts.
Category IV Officers who approached the Courts and where the Courts,
as per records obtainable in DoT, have granted interim stay
or given interim directions. Besides, any officer who has
already obtained a stay order as on the date of issue of this
order from a High Court or CAT, such officer should
immediately intimate the fact to the Cadre Controlling
Authority with a copy to the Absorption Cell (attention Mr.
D. C. Madan, Under Secretary (Abs. Cell), Fax: 23372100 / e­
mail: dcmadan@gmail.com).
Category V Officers who do not belong to Category IV and have not
given any option or have exercised conditional option.
These officers arc deemed t.o have opted for Government
Service, by virtue of para 10 of O.M. dated 22.09.2011.
4.
The list of officers falling under category IV above where interim stay
orders have been given by the Courts is annexed.
5.
With the expiry of last date prescribed for exercising option, the period of
deemed deputation will end. As such, the officers who have either not exercised
their option or have opted for Government Service or have exercised conditional
option, therefore, stand reverted to Government. Officers belonging to Category
I would not revert back to Government since action to consider issue of
Allocation Orders (Presidential Orders) respecting them, has been initiated.
Contd ..... 3/

<!-- page 3 -->

: 3:

6.
All Group 'A' officers on deemed deputation to BSNL/MTNL excluding
those in Category I and IV thus stand reverted to Government and should report
to DoT immediately after having been relieved formally by BSNL/ MTNL, as the
case may be. They should be directed to do so by reporting to Sr. DDG (TEC),
Telecommunication Engineering Centre (TEC) at 3"1 Floor, Teletorium, Khurshid
Lal Bhawan, Janpath, New Delhi -110001 with a copy to the Cadre Controlling
Authority and Director (HRD) of BSNL/MTNL. Besides, they should give their
address, telephone/ mobile number and e-mail id for contact/ correspondence
and may not leave Hqs., i.e. New Delhi without appropriate approval.
7.
Above-said reversion to Government and reporting to DoT in the manner
afore-mentioned will be on transfer. These officers will seek their transfer
entitlements including joining time from Sr. DDG (TEC). BSNL/MTNL will issue
Last Pay Certificates (LPCs) in respect of the officers relieved at the earliest for
timely action to disburse pay and allowances to the officers by Sr. DDG (TEC)
who shall also deal with the personnel matters/claims relating to the repatriated
officers.
8.
Separate orders will be issued for assigning duties and responsibilities to
the repatriated officers.
9.
Since these orders apply to officers on deemed deputation to BSNL/MTNL,
they do not apply to other officers working in the . Department of
Telecommunications, its attached offices as well as Department of Posts. ~

(D. C:. Madan)
Under Secretary to the Govt. of India
Tel: 23036058

CMD, MTNL/CMD, BSNL
DDG(Estt)/DDG(FEB)/Sr. DDG(BW)/Sr. DDG (TEC)
Copy to:- DDG(C&A) - He is requested to suitably post the above-said~M;
on DoT website.
...-­

t-- \C
uL\

',.YY,CS 'I l

I

(D. C:. Madan)
Under Secretary to the Govt. of India
Contd .......4/

<!-- page 4 -->

: 4:

Copy for information to:­
(i)
(ii)
(iii)
(iv)
(v)
(vi)

PS to Hon'ble MoC&IT
PS to Hon'ble MoS(C&IT)(D)
PS to Hon'ble MoS(C&IT)(P)
PPS to Secretary, DoT
PPS to Secretary, Deptt. of Posts, Dak Bhawan, New Delhi.
PPS to Member (Services)/Member(Finance)/Member
(Technology)
(vii) PS to Additional Secretary (T), DoT
(viii) PPS to JS (T), DoT
(ix)
PPS to JS (A), DoT
No. A-11013/33/2011-Abs.Cell

Dated 3'd November, 2011

Copy also to all Principal Controllers/ Controllers/ Joint Controllers of
Communication Accounts, Department of Telecomn~unications, with the request
that the Government counsel who is defending High Court/CAT cases may be
apprised of the contents of the above letter.

(D. C. Madan)
Under Secretary to the Govt. of India
Tel: 23036058

<!-- page 5 -->

Page 1 of 3

Category IV
Accompaniment to O.M. No. A-11013/33/2011-Abs. Cell dated 03.11.2011

Officers who approached courts and courts have granted interim stay or
given interim directions
SI.No. Name of Court
Case No.
Name of the petitioners
1 High Court of
2 Andhra Pradesh
3 at Hvderabad
4
5
6
7
8
9
10
11
12
1 High Court of
2 Andhra Pradesh
3 at Hyderabad
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25

WP No. 25511
of 2005

P.S.R. KRISHNA
B.V. RAMANA MURTHY
M.S.S. RAO
K. DAMODARA RAO
BINOD KUMAR MISHRA
G. VENKATESWARA REDDY
P.V. MURALIDHAR
T. DURGA PRASAD
A. GANAPATI RAM
M.S.R. SARMA
L. ANANTHARAM
A. GOVINDARAJULU
WP No. 25531 R.M. JYOTHIRLINGAM
of 2005
Y. SIVA SANKARA REDDY
A.V. SRIKUMAR
Y. VENKATA NARAYANA
C.RAMACHANDRAN
K.M. DORA! SWAMY
MAHENDRA DHAKAR
G. RATNA KUMAR
C.V. RAMANA BABU
CH. SREENIVASU
I.N.Y. PRASAD
P.V.V.V. PRASADA RAO
C.A. REDDY
R. PAVANA MURTHY
MD. NAIMUDDIN
M.V. RAMANAIAH
M. RAVISHANKAR
M.T. RAJASEKHAR
M.BHADRU
G. SURESH REDDY
K. MURALI KRISHNA
V. BALASUBRAHMANYAM
G. SRINIVAS
MONISHA BISWAS
V. RAMBABU
.

<!-- page 6 -->

Page 2 of 3

26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67

.

·---­

B. RAVI KUMAR
P. RAJU
S. MUJIB PASHA
K.V. CHOUDARY
M.L.N. RAO
B. CHANDRA SENA
P.R.B. KUMAR
N. SATYANANDAM
U. SRINIVAS
K. NAVEEN KUMAR
O.S.N. REDDY
B. JAGDISH KUMAR
C. SRINIVAS
M. SESHACHALAM
M. VIJAYA KUMAR
P. SATYANARAYANA
V. VENKATESHWARLU
D.M. BHASKAR
G.V. MANOJ KUMAR
C.V. RAMA RAJU
G. RAJA RAM MOHAN
G. BABUJI
A. GOPALA KRISHNA RAO
A. VENKATESWARA RAO
C.V. RATNAM
V. SRIDHAR
K. MAOHU MOHAN KUMAR
R.M.M. KRISHNA
D.V. RAMANA MURTHY
R. MANI
R.V.S.S. RAMANJANEYULU
A. HANUMANTHA RAO
P. BALA GANGADHARA RAO
C.K. RADHA KRISHNAN
M. SRINIVASULU REDDY
G.V. RAMA KRISHNA
G. SURENDRA BABU
J.GANTA
P.S. SUBRAHMANYAM
K. NEELAYYA
K. RAMESH
K.K. THAKUR

<!-- page 7 -->

Page 3 of 3

68
69
70
71
1 High Court of
2 Andhra Pradesh
3 at Hyderabad
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26

M. CHANDRA MOUL!
P. SARATH BABU
D. SRINIVASA RAO
P. SITARAMA RAJU
WP No. 26712 N. JANARDHANA RAO
of2006
K. MADHUSUDHANA RAO
B. GOPAL
V. RAMESH
V. MUNINDRANATH
K. HANUMANTHA RAO
A. MUNI SEKHAR
K.V.N. RAO
G.GOURISHANKAR
J. RAVICHANDRA
G. NAGESHWARA RAO
N. MURALI
N.SUJATHA
P. KONDAIAH
K. RAJA SEKHAR
T.S. RAMA KRISHNA
M. CHANDRASEKHAR
D. BHASKARA RAO
J. RAMESH
P.L. YASHODHARA
L.SREENU
P. KRISHNAIAH
B. SUDHAKARA RAO
Y. RAVINDRANATH
M. ESHWAR
D.R. RAJESHWARI

.
