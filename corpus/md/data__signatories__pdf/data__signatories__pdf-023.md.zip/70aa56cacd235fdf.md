---
doc_id: "70aa56cacd235fdf"
source_url: "https://www.dot.gov.in/static/uploads/2026/09/e22ea086810d1d9ba210135ca240600c.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Instructions to immediately discontinue all mutual agreements, if any, in so far as agreements involve any possibility of the use of satellite mobile phones in India, with foreign companies"
date: "2012-01-02"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "b84b13dda1ea93a9"
---

<!-- page 1 -->

Government of India
Ministry of Communication & Information Technology
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-15/2009-AS Il1/Gen /49/ lo Dated: 02.01.2012
To
All the TSPs
Subject: Instruction to immediately discontinue all mutual agreements, if any, in so far as
agreements involve any possibility of the use of satellite mobile phones in India, with foreign
companics
As per prevailing policy. the use of satellite mobile phones is not permitted in India. all the Access
Service Licensees are instructed to immediately discontinue all mutual agreements with foreign
companies, if any, in so far as agreements involve any possibility of the use of satellite mobile
phones in India. Any violation of these instructions will be taken very seriously,
whe 4१%
Gi
(Subhash Chandra Kesarwani)
Assistant Director General (AS-TTD
मच E. we
\ Ve e-Mail: adgas3.hgq-dot@nic.in
ue “ है
XY Copy to:
we py
G) The Director (IT), DOT HQ, with a request to kindly upload the instruction on DOT
AY website, please.
s & Ly The Director (OL), DOT HQ, with a request to kindly provide Hindi Translation of this
instruction.
Hind: Translaban placd below may be powanded to
Qj IT Cell with a request te kindly upload the same
je bi A Hindi Version of DOT nents
_ की ५)
Dinecton psy _t+ 7G 01. 212 sera i
. 4 \\\ yy Dinecton(A-it) ae We IGT gra a fs
iP न —s oT
pol) Directo ZT) ae) ow
J | pix ® — (2fr)i2 aon)
>
Y)
ght [» <p ov
