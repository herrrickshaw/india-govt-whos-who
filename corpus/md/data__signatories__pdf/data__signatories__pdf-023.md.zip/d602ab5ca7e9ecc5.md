---
doc_id: "d602ab5ca7e9ecc5"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/e1d223b91f6f7d683f228d8e79a7578d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "3G and BWA Spectrum Auction Timelines Details"
date: "2009-09-11"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7d2d0f897db18d15"
---

<!-- page 1 -->

3G and BWA Spectrum Auction Timelines
Activity

Timeline

Release of Revised Information Memorandum

29-Sep-09

Deadline for submission of questions for pre-bid conference
Pre-bid conference
Issue of clarifications, if any

08-Oct-09
12-Oct-09
22-Oct-09

Notice Inviting Applications
Final date for Applications
Publication of ownership details of Applicants
Bidder Ownership Compliance Certificate
Pre-qualification of Bidders

26-Oct-09
13-Nov-09
18-Nov-09
23-Nov-09
27-Nov-09

Mock Auction
Start of the 3G-WCDMA Auction
Start of the EVDO and BWA Auctions

Payment
Payment of Bid Deposit by Successful Bidders
Payment of the balance amount (Successful Bid Amount
less Bid Deposit)

03-Dec-09 to 04-Dec-09
07-Dec-09
2 days after the close of the
3G-WCDMA Auction

Within 5 calendar days of the
close of the relevant Auction
Within 15 calendar days of the
close of the relevant Auction

Note:
Any changes in the Auction Timelines will be intimated on the Auction website. Participants are
requested to monitor the Auction website actively.
