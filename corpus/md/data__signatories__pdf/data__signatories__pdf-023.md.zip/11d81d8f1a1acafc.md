---
doc_id: "11d81d8f1a1acafc"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/0e57591026e9f8f7bec8648675c12c32.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of carrier international codes CIC for RJIL NLD services-regarding"
date: "2015-07-24"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e1db94c9f6ddf0ca"
---

<!-- page 1 -->

No. 10-70/2007-CS-III /32
Government of India
Ministry of CommiJnications & IT
Department of Telecommunications
(Carrier Services Wing)
Sanchar Bhawan, 20 Ashoka Road, New Delhi -110 001
Date.24.07.2015
Subject: Allotment of Carrier Identification Codes (CIC) for RJIL ILD Service -reg.
In consideration of request of Mis Reliance Jio Infocomm Limited to endorse the attached
letter of even no. dated 07.01.2015 to all concerns, all are requested to take necessary action,
if any, wi~h regard to attached letter on above mentioned subject.

Copy to: ·
1. Secretary, TRAI.
2. DG, COAl/SG, AUSPI
3. CMD MTNL/BSNL
4. Director (TERM-I), DoT, HQ with request to circulate the sanction to related TERM Cells.
5. All TSPs
6. ADG (IT) with request to kindly upload on DoT Website.

<!-- page 2 -->

.. ·... ·: ····

..
,

..

No.J0-7072Q07- Cs.:hJ
. · Governmentof India
.
·MiiiiStry of dom1nuniCatioi1S &JT
Departmerifof1'eiec9mmunications · ·
· S~nchar :Bhavan,20 ~ Ashoka Road .
.
·.
· New Delhi - 110001

· . ..

Dated: O"f01.2015
To
Mis Reliance Jio Infocomm Limited.
,
. D'.'7:, })hawandeep Bµilding, .
. "6,JahtarMantarRoad, NewDelhi.:110001 · · '

• · -. · : ·

:

• ·.

...

. .

.

.

.

.

•

· .·

.

•

. ·!

.

.

· :

.

· · · ··

SUB: Allotment Qf CIC Codes

The undersigned has been directed to convey the approval of the competent authority
for allotment ·of Carrier Identification Codes (CIC) .to M/s Reliance Jio lnfocomm Limited
(License Agreement No. 20-AOl/2013 AS-:T dated 21.10:20 l) for authorization of ILD
Services under UL) as mentioned in the following table:
S.No.

Name of
Providers

Service Nature
Licence

. of National CICCodes .
Toll
Quality

1.

Mis Reliarice Jio
Infocomm Limited

ILD
authorization
under UL

NonToll
Quali

Intemational
CIC
· Codes
Non- Toll .
Toll
Quality Quality
82

83

· ~~
(R.K. N't·aj'
Section Officer (CS-III)
