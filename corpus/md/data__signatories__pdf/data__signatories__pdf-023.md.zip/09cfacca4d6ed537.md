---
doc_id: "09cfacca4d6ed537"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/52be9ed70dd4f33a0ffc737462675fab.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of NOC for sale/rent of International Roaming SIM Cards/ Global Calling Cards in India as on 31.01.2011"
date: "2011-01-31"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dd084f4d242204f7"
---

<!-- page 1 -->

List of NOC for sale/rent of International Roaming SIM Cards/ Global Calling Cards in India as on 31.01.2011
Si, No.
1.

2.

Name & Address of the
company
M/s Cost Plus
Commerce Pvt. Ltd.,
C1/12, Vasant Vihar,
New Delhi-110057

NOC No. &
date
808-37/2005VAS/84 dated
14.05.2007

NOC for

M/s Uniconnect SIM
Pvt. Ltd., 602-604,
Midas Chambers, Plot
No A-11, Opp. Laxmi
Ind. Estate, OFF-Link
Road, Andheri (West),
Mumbai-400053

808-37/2007CS/09 dated
06.07.2007

sale of International
Inbound SIM Cards in
India

sale of International
Inbound SIM Cards in
India

Date of
Renewal
Renewed for
1 year w.e.f
14.05.2010
vide letter
No. 80869/2009CS(1) dated
18.06.2010.
Renewed for
1 year w.e.f.
06.07.2010
vide letter
No. 80837/2008CS(Pt)/11
dated
30.06.2010.

Date of Expiry
14.05.2011

06.07.2011

Remarks

<!-- page 2 -->

3.

M/s Matrix Cellular
(International) Services
Pvt. Ltd., 7, Khullar
Farms, Mandi Road,
Mehrauli, New Delhi110030

808-37/2007CS(Pt) dated
22.07.2007

sale/rent of International
Roaming SIM
Cards/Global Calling
Cards in India

Renewed for 22.07.2011
1 yr w.e.f
22.07.2010
vide letter no.
808-37/2008CS-I(Part-i)
dated
09.7.2010

4.

M/s Reliance Webstore
Limited, 15th Floor,
Vijaya Building, 17,
Barakhamba Road, New
Delhi-110001.

808-37/2007CS dated
23.07.2007
808-38/2007CS dated
19.09.2007

sale of International
Inbound Calling Card/
Global Calling Cards in
India &
sale of International
SIM Cards in India

Renewed for 30.09.2011
1 yr w.e.f
30.09.2010
vide letter no.
808-38/2007CS dated
25.10.2010

5.

M/s Falcon Business
Resources Pvt. Ltd., 910,
Prakash Deep, 7, Tolstoy
Marg, New Delhi110001

808-40/2007CS dated
20.09.2007

sale of International
SIM Cards/Global
Calling Cards in India

6.

M/s Bharti Airtel
Services Limited,
Airtel Center, Plot No.-

808-37VolII/2007-CS
dated

Renewed for 19.09.2011
1 year w.e.f
20.09.2010
vide letter no.
808-40/2007CS dated
27.09.2010
sale/rent of International Renewed for 09.09.2011
Roaming SIM
one year
Cards/Global Calling
w.e.f

<!-- page 3 -->

16, Udyog Vihar, PhaseIV, Gurgaon-122015,
Haryana..

10.09.2008.

Cards in India

7.

M/s Trikon Electronics
Private Limited,
101, 1st Floor, Sarvesh,
Bhawani, Dadar (Wset),
Mumbai-28

808-49/2009CS-1 dated
09.03.2009

Sale/rent of
International SIM
Cards/ Global calling
cards

8.

M/s Tata
Communications
Limited,
VSB, Mahatma Gandhi
Road,
Fort, Mumbai-400001

808-53/2009CS-1
dated
17.04.2009

Sale of Global Calling
Cards in India.

9.

M/s ACI Infocom
Limited,
217-218, Vasan Udyog
Bhawan,
Opp. High Street
Pheonix, Senapati Bapat
Marg, Lower
Parel,Mumbai- 400 013.
M/s Tata Teleservices

808-52/2009CS-1
Dated:
22.04.2009

Sale of International
SIM Card

808-50/2009-

Sale of Global Calling

10.

10.09.2010
vide letter no.
808-37/2007CS VolI
dated
27.09.2010.
Renewed for
one year
w.e.f
09.03.2010
vide letter no.
808-49/2009CS-1 dated
26.04.2010
Renewed for
one year
w.e.f
17.04.2010
vide letter no.
808-53/2009CS-1 dated
07.05.2010
Renewed for
one year
w.e.f
22.04.2010
vide letter no.
808-52/2009CS-1 dated
17.05.2010
Renewed for

09.03.2011

17.04.2011

22.04.2011

26.06.2011

<!-- page 4 -->

11.

12.

13.

14.

15.

(Maharashtra) Limited,
2-A, Old Ishwar Nagar,
Main Mathura Road,
New Delhi-110065.

CS-I Dated
26.06.2009

Cards in India

one year
w.e.f
26.06.2010
vide letter no.
808-50/2009CS-I Dated
30.06.2010

M/s Trawelisim Emobile
Services Private Limited,
26, Madhu Estate, 1st
floor, Pandurang
Budhkar Marg, Worli,
Mumbai-400013.
M/s Muni’s Telekom
Pvt. Ltd.,
B/107, Koldogri CHS
Ltd., 1st Floor, Parsi
Wada, Sahar Road,
Andher(East), Mumbai400 099.
M/s Bharti Airtel Ltd.,
Unitech World Cyber
Park, Tower-A, 4th Floor,
Sector-39, Gurgaon-122
001
M/s Virtual Soft Systems
Limited, F-69/19, Okhla
Industrial Area, Phase-I,
New Delhi-110 020
M/s Space Cellular Pvt.
Ltd., 305, Shree Sdaguru

808-55/2009CS-I Dated
18.06.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India.

808-60/2009CS-1 Dated
02.12.2009

Sale of Roaming SIM
Cars/Global Calling
Cards in India.

808-61/2009CS-I dated
09.02.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

08.02.2011

808-65/2009CS-I dated
16.03.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

15.03.2011

808-62/2009CS-I dated

Sale of Roaming SIM
Cars/Global Calling

21.04.2011

26.06.2011

Renewed for
further one
year vide
letter No.
808-60/2009CS-1 Dated
02.12.2010

01.12.2011

<!-- page 5 -->

16.

17.

18.

19.

20.

21.

CHS, Plot No.-36,
Sector-21, Kharghar,
Navi Mumbai-410210
M/s Indmobile Ventures
Limited, 110 Linkway
Estate, New Link Road,
Mumbai-400064.
M/s Seven Telecom
Limited, 401/408,
Aditya, Behind Abhijeet1, Near Mithakhali Six
Roads, Ellisbridge,
Ahmedabad-380006
M/s Bharti Hexacom
Limited, Airtel Center,
Plot No. 16, Udyog
Vihar, Phase-IV,
Gurgaon-122001
M/s Keshav Forex &
Travels Pvt. Ltd.,
C-115, Mittal Tower,
Nariman Point, Mumbai400002.
M/s Hash10 Telecom
Private Limited, G-8,
Gems Court, 14 Khadar
Nawaz Khan Road,
Nungambakkam,
Chennai- 600 034.
M/s Gimbans
Technologies Private

21.04.2010

Cards in India

808-64/2009CS-I dated
22.04.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

22.04.2011

808-67/2009CS-I dated
28.04.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

28.04.2011

808-63/2009CS-I dated
30.04.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

30.04.2011

808-68/2009CS-I dated
07.05.2010

Sale of International
Roaming SIM Cards in
India

07.05.2011

808-66/2009CS-I dated
07.06.2010

Sale of International
Roaming SIM Cards in
India

07.06.2011

808-72/2009CS-1 dated

Sale of Roaming SIM
Cars/Global Calling

25.09.2011

<!-- page 6 -->

22.

24

Limited, 27/7, Laxmi
Towers, 3rd Floor, Dr.
Radhakrishnan Salai,
Mylapore, Chennai600004
M/s Limco
Telecommunications
Private Ltd., 88,
Yashwant Place,
Chankyapuri, New
Delhi-110021
M/s ISE Cards India
Limited,
3/106, Vivek Khand,
Gomti Nagar, Lucknow,
Uttar Pradesh

28.09.2010

Cards in India

808-41/2007CS dated
27.09.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

26.09.2011

808-73/2009CS-1 dated
30.12.2010

Sale of Roaming SIM
Cars/Global Calling
Cards in India

30.12.2011
