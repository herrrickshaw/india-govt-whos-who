---
doc_id: "138c18facbdff0b4"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/30e67a104f33c6afdc9e4cb378957261.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Auction for 3G and BWA Spectrum: Process update- Issue of NIA Details"
date: "2009-12-12"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a4b40e56374a93e0"
---

<!-- page 1 -->

AUCTION FOR 3G AND BWA SPECTRUM: PROCESS UPDATE – ISSUE
OF NIA.
8th December, 2009
This is with reference to the Revised Information Memorandum issued on 23
October 2009. Government is in the process of finalising the details to be included
in the Notice Inviting Applications (NIA) which are being fine tuned. The NIA
will therefore be issued shortly.
Interested parties are advised to follow this website regularly for further details.
