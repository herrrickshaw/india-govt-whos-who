---
doc_id: "baeada4f75b94cf9"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/fdc568c251b7afdd57917509ff3c9dfc.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Letter No. A-11013/33/2011-Abs. Cell, adressed to Shri. S.P.Pachauri, Director (HR), MTNL"
date: "2011-10-07"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95b729ec088ab722"
---

<!-- page 1 -->

No. A-11013/33/2011-Abs. Cell
Government of India
Ministry of Communications & IT
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi-110~b;;
Dated:

October, 2011

Subject: Contingency plan in case of repatriation of Group 'A' officers to DoT
Kindly refer to your letter No. MTNL/CO/Dir(HR)/2011 dated 30th September,
2011 on the subject mentioned above.
2.
The contingency plans submitted by MTNL have been considered in this
Department and the following observations are made thereon.
i)

Contingency plans as submitted are evidently based on the presumption that
none of the unabsorbed ITS Officer presently working in BSNL/MTNL would
opt for absorption. But the number of officers working in MTNL opting for
absorption is not known at present and it has to be assumed that some officers
would opt for absorption.

ii)

MTNL has heavily relied on its proposal for deputation/foreign service of ITS
officers in the organization after obtaining exemption from the rule of
immediate absorption or by fresh recruitment (absorption) on selective basis
involving technical resignation under Rule 37 of the CCS (Pension) Rules,
1972
to run their services and operations efficiently before the actual
repatriation takes place.

iii)

Ongoing process of absorption of Group 'A' Officers in BSNL/MTNL has been
initiated by DoT under the relevant provisions of Rule 37-A of CCS (Pension)
Rules, 1972 and this process is required to be completed under the same rule
which include repatriation of Group 'A' Officers on deemed deputation to
BSNL/MTNL who opt for government service or do not exercise option at all
and sending the names of Officers in excess of the requirements of DoT to
Surplus Cell for their redeployment keeping in view the guidelines of DoP& T
regarding redeployment of surplus staff. As per these provisions, , Group A
officers who do not opt for absorption would need to report forthwith to DoT
HQs at Delhi for redeployment as per the procedure indicated herein.

(iv) The proposals submitted by MTNL in the contingency plan for deputation of
ITS officers on foreign service terms after seeking exemption from the rule of
immediate absorption or their fresh recruitment (absorption) in BSNL/MTNL
under rule 37 of CCS (Pension) Rules, 1972 even before completion of the
absorption process is not in order as the same would be in contravention of
rule 37-A of CCS (Pension) Rules, 1972. Hence, this proposal is not
acceptable.

<!-- page 2 -->

: 2:
(v)

Further, the proposed deputation/foreign service of ITS officers in
BSNL/MTNL, even after completion of the absorption process, cannot be
resorted to as the same would be against the spirit of rule 37-A and would also
run counter to the Cabinet decision under which Group 'A' officers were sent
on deemed deputation to BSNL/MTNL pending completion of the absorption
process.

(vi)

As regards fresh recruitment (absorption) of ITS officers under Rule 37 of CCS
(Pension) Rules, 1972, this mode can be resorted to only after completion of
the absorption process including repatriation of Group 'A' Officers on deemed
deputation to BSNL/MTNL who opt for government service and sending the
names of Officers in excess of the requirements of DoT to Surplus Cell for their
redeployment. Such officers would need to leave Government service and be
selected in the open recruitment process before they can be appointed in
MTNL through the fresh recruitment route. Only such selected officers can be
recruited and no officer would have any entitlement to be recruited through this
route once he has been repatriated to DoT.

(vii)

It may also be noted that in the event of fresh recruitment of ITS officers in
MTNL under Rules 37 of CCS (Pension) Rules, 1972 after their repatriation in
DoT, the service rendered by them in the particular grade of Service in DoT
shall not be counted towards seniority in their fresh appointment in MTNL and
that they would be placed at the bottom of the seniority in the grade in which
they are appointed. This may be brought to the notice of Group A officers so
that they can take an informed decision while exercising their option.

3.
In view of the above position, MTNL may rework out the contingency plan with
a view to ensuring that their services are not disrupted and their organizational needs
do not suffer. Besides, the option of direct recruitment of officers as proposed needs
to be pursued vigorously to ensure that at least some candidates are in position at the
earliest. Necessary preparatory steps in this regard may be initiated immediately.
4.
This Department may be apprised of the action taken in the matter at the
earliest and in no case later than 13th October, 2011.

~ o;r/ 1cT'J.o1 I
1

( Malay Shrivastava )
Joint Secretary (T)
To
Shri S.P. Pachauri,
Director (HR),
Mahanagar Telephone Nigam Limited,
Jeevan Bharati Building,
Connaught Circus,
NEW DELHl-110001
