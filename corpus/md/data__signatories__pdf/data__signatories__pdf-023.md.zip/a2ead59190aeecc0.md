---
doc_id: "a2ead59190aeecc0"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/a8b633fde20847511212f2b5ee83b349.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List Of Final Bidders Spectrum Auction February 2015"
date: "2015-02-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8e4e20d3ec0b830c"
---

<!-- page 1 -->

Auction of Spectrum in 2100 MHz, 1800 MHz, 900 MHz and 800 MHz

List of Final Bidders
List of Bidde rs fo r Auction of Spectrum in 2100 MH z, 1800 MH z, 900 MH z & 800 MHz
Sr.
No.

Name of Bidder

Application
Fee (Rs.)

EMO Amt.
(Rs. Crores)

1

M/s. Vodafone India Ltd

1,00,000/­

3,700.00

Net Worth
(Rs. Crores)

Paid Up Capital
(Rs. Crores)

EP
Allocated

8258.80

414.09

26825

----­

Not Allowed to Bid in Service
Areas/Bands

2

M/s. Bharti Airtel Ltd

1,00,000/­

4,336.00

73069.60

1998.70

30945

----­

3

M/s. Idea Cellular Ltd

1,00,000/­

4,000.00

19185.55

3597.48

28765

----­

4

M/s. Telewings Communications

1,00,000/­

724.95

1052.89

1923.08

5699

----­

1,00,000/­

500.00

(6668.61)

8334.77

3947

Can bid in all bands, but in a particular

Services (P) Ltd

5

M/s. Aircel Ltd

service area it can not bid in such
bands*, where applicant does not
have Spectrum in that service area .

6

M/s. Tata Teleservices Ltd

1,00,000/­

1,500.05

(8985.13)

7192.60

11695

Can not bid in 3 Service Area, namely
Assam, North East and J&K. Also, can
bid in such bands *
..
remaining service
areas,

not

in

the

where

applicant does not have Spectrum in
that service area.
7

M/s. Reliance Communications

8

M/s. Reliance JIO lnfocomm Ltd .

1,00,000/­

1,175.00

17022.00

1,00,000/­

4,500.00

23029.58

-

1244.49

9317

----­

23072.00

32005

----­

Lt9

* Note-1800 &900 MHz bands to be considered as one i.e. holding in 900 MHz band would make the bidder eligible for bidding in 1800 MHz band and vice­
versa . 2100 MHz band and 800 MHz band are to be cons idered separate.
