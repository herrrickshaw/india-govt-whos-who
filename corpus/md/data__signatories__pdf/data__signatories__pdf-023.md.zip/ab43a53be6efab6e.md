---
doc_id: "ab43a53be6efab6e"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/7328c24e94b27fc18645e9c060e768eb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Final Bidders"
date: "2012-11-06"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "81a2768ccb1257b7"
---

<!-- page 1 -->

1800MHz band Spectrum Auction

List of Final Bidders

<!-- page 2 -->

Final List of Bidders – 1800MHz band
Subsequent to the last date of withdrawal of Application, following is the final list of Bidders for the
1800MHz band Auction.

Bidders for the Auction of Spectrum in 1800MHz band
Sr.
No.

Name of Bidder

Earnest
Money Initial Eligibility Net worth (Rs.
Deposit (Rs. Crore) Points
Crore)

1

Bharti Airtel Limited

102.75

124

50901.10

2

Idea Cellular Limited

1306.75

1594

10848.22

3

Vodafone South Limited

229

276

11065.83

4

Videocon
Limited

Telecommunications

648

788

11809.28

5

Telewings
Communications
Services Private Limited

1096

1332

1020.30
