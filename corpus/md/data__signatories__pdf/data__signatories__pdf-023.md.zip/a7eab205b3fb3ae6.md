---
doc_id: "a7eab205b3fb3ae6"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/ac360c3b683e33228ec46d6c1c407f92.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Unified License up to 27.06.2014"
date: "2014-06-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e1b09f9fea5dd294"
---

<!-- page 1 -->

List of Unified licences
SNO

Name of Company

Date of grant of
Unified Licence

Authorisation detail

Date of Authorisation

Access Service-Assam
Access Service-West
Bengal Access ServiceKolkata Access ServiceNorth East Access ServiceTamil Nadu (Incl. Chennai)
Access Service- J&K
1 Idea Cellular Limited

11-0ct-13 Access Service- Orissa

11-0ct-13

2 Reliance Jio lnfocomm Ltd

Access Service
NLD (National Area)
ILD (National Area)
VSAT (National Area)
PMRTS
INSAT
MSS-R (National Area) ISP
"A" (National Area)
ISP
"B" (Telecom circle/Metro
Area)
ISP
"C" (SSA)
Resale
21-0ct-13 IPLC(National Area)

21-0ct-13

Sistema Shyam
3 Teleservices Limited

Access Service- Gujarat
Access Service- Kamataka
Access Service- Kerala
Access Service- Kolkata
Access Service- Tamil
Nadu Access ServiceUP(West) Access Service03-0ct-13 West Bengal

03-0ct-13

4

Mis Telewings
Communications Pvt Ltd

5 Mi's Sify TechnoloQies Ltd

To:

27.11.2013

27.06.2014

IT Wing to arrange to upload on the Website

Access Service-Andhra
Pradesh
Access Service-Bihar Access
Service- Gujarat Access
Service- Maharashtra Access
Service- UP (East)
Access Service- UP (West)

27.11.2013

ISP-A,NLD,ILD

27.06.2014
