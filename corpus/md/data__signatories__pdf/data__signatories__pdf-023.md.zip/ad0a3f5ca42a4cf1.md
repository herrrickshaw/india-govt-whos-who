---
doc_id: "ad0a3f5ca42a4cf1"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/44b9acab49aea9caf88cb8ba942e7f13.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "800MHZ Auction: Ownership details of Applicants"
date: "2012-10-19"
pages: 48
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "10666fab09a40931"
---

<!-- page 1 -->

Auction of Spectrum in 800MHz band

Applicant Ownership Details

<!-- page 2 -->

Auction of Spectrum in 800MHz band: Ownership details of Applicants
(as submitted by the Applicants)

Ownership details of the following Applicants for the Auction of Spectrum in 800MHz band are
provided in this document:

Tata Teleservices Limited
Videocon Telecommunications Limited

Notes:
1.

These details are as submitted by the Applicants. The Department of Telecommunications
has not verified the accuracy of the information.

2.

Publication of this list in no way implies that the Applicants will be pre-qualified merely on
submission of the Ownership Compliance Certificate.

3.

Duly executed Ownership Compliance Certificate must be submitted in hard copy, during
office hours before 1:00 PM (Indian Standard Time) on 25th October, 2012 at the following
address:
Joint Wireless Adviser
Department of Telecommunications
Room no 604,
Sanchar Bhawan,
20 Ashoka Road,
New Delhi – 110 001.

4.

Six sets (one original and five copies) of the Ownership Compliance Certificate need to be
submitted in a single sealed cover. Name and address of the Applicant must be clearly visible
on the sealed cover. The original must be marked as Original. Five photocopies of the
Original (certified by Company Secretary or Authorised Signatory) must also be submitted
and clearly marked as Copy No.: ______

5.

The Applicants should also submit scanned soft copy of the Original on CD-ROM/ DVD in a
single “pdf” document

6.

In case of discrepancies between the copies and the Original, the Original shall prevail.
However, the Government also reserves the right to summarily reject Applications in case of
discrepancies between the copies and the Original.

<!-- page 3 -->

Tata Teleservices Limited

<!-- page 4 -->

Shareholding details of Applicant /
Group Bidding Entity
&
Shareholding details of Associated
Licensees that have nominated the
Applicant as a Group Bidding Entity

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any, and
their present status

<!-- page 17 -->

<!-- page 18 -->

<!-- page 19 -->

<!-- page 20 -->

<!-- page 21 -->

<!-- page 22 -->

<!-- page 23 -->

Videocon
Telecommunications
Limited

<!-- page 24 -->

Shareholding details of Applicant /
Group Bidding Entity
&
Shareholding details of Associated
Licensees that have nominated the
Applicant as a Group Bidding Entity

<!-- page 25 -->

<!-- page 26 -->

<!-- page 27 -->

<!-- page 28 -->

<!-- page 29 -->

<!-- page 30 -->

<!-- page 31 -->

<!-- page 32 -->

<!-- page 33 -->

<!-- page 34 -->

<!-- page 35 -->

<!-- page 36 -->

<!-- page 37 -->

<!-- page 38 -->

<!-- page 39 -->

<!-- page 40 -->

<!-- page 41 -->

<!-- page 42 -->

<!-- page 43 -->

<!-- page 44 -->

<!-- page 45 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any, and
their present status

<!-- page 46 -->

<!-- page 47 -->

<!-- page 48 -->
