---
doc_id: "2bdde0cdbd2e449a"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/d7e61916b4a740eed6ffe71c19871ce9.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "1800MHz Auction -Data Files"
date: "2012-11-14"
pages: 91
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d378df4ad232aef0"
---

<!-- page 1 -->

Clock RoundService AreaClock RoundAggregate
Price (Rs. Demand
Crore)
Excess Demand
1 Andhra Pradesh286.91
4
-4
1 Assam
8.67
7
-1
1 Bihar
42.51
7
-1
1 Delhi
693.06
0
-8
1 Gujarat
224.84
8
0
1 Haryana
46.52
6
-2
1 Himachal Pradesh7.78
1
-7
1 Jammu & Kashmir6.33
6
-2
1 Karnataka
330.12
0
-8
1 Kerala
65.3
1
-7
1 Kolkata
113.72
4
-4
1 Madhya Pradesh53.99
6
-2
1 Maharashtra 262.81
4
-4
1 Mumbai
678.45
0
-8
1 North East
8.84
6
-2
1 Orissa
20.27
6
-2
1 Punjab
67.28
1
-7
1 Rajasthan
67.08
0
-8
1 Tamil Nadu
306.09
4
-4
1 Uttar Pradesh (East)
76.17
9
1
1 Uttar Pradesh (West)
107.41
6
-2
1 West Bengal
25.84
6
-2
2 Andhra Pradesh286.91
4
-4
2 Assam
8.67
7
-1
2 Bihar
42.51
7
-1
2 Delhi
693.06
0
-8
2 Gujarat
227.08
0
-8
2 Haryana
46.52
6
-2
2 Himachal Pradesh7.78
1
-7
2 Jammu & Kashmir6.33
6
-2
2 Karnataka
330.12
0
-8
2 Kerala
65.3
1
-7
2 Kolkata
113.72
4
-4
2 Madhya Pradesh53.99
6
-2
2 Maharashtra 262.81
4
-4
2 Mumbai
678.45
0
-8
2 North East
8.84
6
-2
2 Orissa
20.27
6
-2
2 Punjab
67.28
1
-7
2 Rajasthan
67.08
0
-8
2 Tamil Nadu
306.09
4
-4
2 Uttar Pradesh (East)
76.93
1
-7
2 Uttar Pradesh (West)
107.41
6
-2
2 West Bengal
25.84
6
-2
3 Andhra Pradesh286.91
4
-4
3 Assam
8.67
7
-1
3 Bihar
42.51
7
-1
3 Delhi
693.06
0
-8
3 Gujarat
227.08
0
-8

<!-- page 2 -->

3 Haryana
46.52
3 Himachal Pradesh7.78
3 Jammu & Kashmir6.33
3 Karnataka
330.12
3 Kerala
65.3
3 Kolkata
113.72
3 Madhya Pradesh53.99
3 Maharashtra 262.81
3 Mumbai
678.45
3 North East
8.84
3 Orissa
20.27
3 Punjab
67.28
3 Rajasthan
67.08
3 Tamil Nadu
306.09
3 Uttar Pradesh (East)
76.93
3 Uttar Pradesh (West)
107.41
3 West Bengal
25.84
4 Andhra Pradesh286.91
4 Assam
8.67
4 Bihar
42.51
4 Delhi
693.06
4 Gujarat
227.08
4 Haryana
46.52
4 Himachal Pradesh7.78
4 Jammu & Kashmir6.33
4 Karnataka
330.12
4 Kerala
65.3
4 Kolkata
113.72
4 Madhya Pradesh53.99
4 Maharashtra 262.81
4 Mumbai
678.45
4 North East
8.84
4 Orissa
20.27
4 Punjab
67.28
4 Rajasthan
67.08
4 Tamil Nadu
306.09
4 Uttar Pradesh (East)
76.93
4 Uttar Pradesh (West)
107.41
4 West Bengal
25.84
5 Andhra Pradesh286.91
5 Assam
8.67
5 Bihar
42.51
5 Delhi
693.06
5 Gujarat
227.08
5 Haryana
46.52
5 Himachal Pradesh7.78
5 Jammu & Kashmir6.33
5 Karnataka
330.12
5 Kerala
65.3
5 Kolkata
113.72

6
1
6
0
1
4
6
4
0
6
6
1
0
4
1
6
6
4
7
7
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
10
6
4
7
12
0
0
6
1
6
0
1
4

-2
-7
-2
-8
-7
-4
-2
-4
-8
-2
-2
-7
-8
-4
-7
-2
-2
-4
-1
-1
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
2
-2
-4
-1
4
-8
-8
-2
-7
-2
-8
-7
-4

<!-- page 3 -->

5 Madhya Pradesh53.99
5 Maharashtra 262.81
5 Mumbai
678.45
5 North East
8.84
5 Orissa
20.27
5 Punjab
67.28
5 Rajasthan
67.08
5 Tamil Nadu
306.09
5 Uttar Pradesh (East)
76.93
5 Uttar Pradesh (West)
109.55
5 West Bengal
25.84
6 Andhra Pradesh286.91
6 Assam
8.67
6 Bihar
44.21
6 Delhi
693.06
6 Gujarat
227.08
6 Haryana
46.52
6 Himachal Pradesh7.78
6 Jammu & Kashmir6.33
6 Karnataka
330.12
6 Kerala
65.3
6 Kolkata
113.72
6 Madhya Pradesh53.99
6 Maharashtra 262.81
6 Mumbai
678.45
6 North East
8.84
6 Orissa
20.27
6 Punjab
67.28
6 Rajasthan
67.08
6 Tamil Nadu
306.09
6 Uttar Pradesh (East)
76.93
6 Uttar Pradesh (West)
109.55
6 West Bengal
25.84
7 Andhra Pradesh286.91
7 Assam
8.67
7 Bihar
44.21
7 Delhi
693.06
7 Gujarat
227.08
7 Haryana
46.52
7 Himachal Pradesh7.78
7 Jammu & Kashmir6.33
7 Karnataka
330.12
7 Kerala
65.3
7 Kolkata
113.72
7 Madhya Pradesh53.99
7 Maharashtra 262.81
7 Mumbai
678.45
7 North East
8.84
7 Orissa
20.27
7 Punjab
67.28

6
5
0
6
6
1
0
4
1
0
6
4
7
4
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
0
6
4
7
8
0
0
6
1
6
0
1
4
6
5
0
6
6
1

-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4
-1
-4
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4
-1
0
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7

<!-- page 4 -->

7 Rajasthan
67.08
7 Tamil Nadu
306.09
7 Uttar Pradesh (East)
76.93
7 Uttar Pradesh (West)
109.55
7 West Bengal
25.84
8 Andhra Pradesh286.91
8 Assam
8.67
8 Bihar
44.65
8 Delhi
693.06
8 Gujarat
227.08
8 Haryana
46.52
8 Himachal Pradesh7.78
8 Jammu & Kashmir6.33
8 Karnataka
330.12
8 Kerala
65.3
8 Kolkata
113.72
8 Madhya Pradesh53.99
8 Maharashtra 262.81
8 Mumbai
678.45
8 North East
8.84
8 Orissa
20.27
8 Punjab
67.28
8 Rajasthan
67.08
8 Tamil Nadu
306.09
8 Uttar Pradesh (East)
76.93
8 Uttar Pradesh (West)
109.55
8 West Bengal
25.84
9 Andhra Pradesh286.91
9 Assam
8.67
9 Bihar
44.65
9 Delhi
693.06
9 Gujarat
227.08
9 Haryana
46.52
9 Himachal Pradesh7.78
9 Jammu & Kashmir6.33
9 Karnataka
330.12
9 Kerala
65.3
9 Kolkata
113.72
9 Madhya Pradesh53.99
9 Maharashtra 262.81
9 Mumbai
678.45
9 North East
8.84
9 Orissa
20.27
9 Punjab
67.28
9 Rajasthan
67.08
9 Tamil Nadu
306.09
9 Uttar Pradesh (East)
76.93
9 Uttar Pradesh (West)
109.55
9 West Bengal
25.84
10 Andhra Pradesh286.91

0
4
1
0
6
4
7
4
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
0
6
4
7
12
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
0
6
4

-8
-4
-7
-8
-2
-4
-1
-4
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4
-1
4
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4

<!-- page 5 -->

10 Assam
8.67
10 Bihar
46.43
10 Delhi
693.06
10 Gujarat
227.08
10 Haryana
46.52
10 Himachal Pradesh7.78
10 Jammu & Kashmir6.33
10 Karnataka
330.12
10 Kerala
65.3
10 Kolkata
113.72
10 Madhya Pradesh53.99
10 Maharashtra 262.81
10 Mumbai
678.45
10 North East
8.84
10 Orissa
20.27
10 Punjab
67.28
10 Rajasthan
67.08
10 Tamil Nadu
306.09
10 Uttar Pradesh (East)
76.93
10 Uttar Pradesh (West)
109.55
10 West Bengal
25.84
11 Andhra Pradesh286.91
11 Assam
8.67
11 Bihar
46.43
11 Delhi
693.06
11 Gujarat
227.08
11 Haryana
46.52
11 Himachal Pradesh7.78
11 Jammu & Kashmir6.33
11 Karnataka
330.12
11 Kerala
65.3
11 Kolkata
113.72
11 Madhya Pradesh53.99
11 Maharashtra 262.81
11 Mumbai
678.45
11 North East
8.84
11 Orissa
20.27
11 Punjab
67.28
11 Rajasthan
67.08
11 Tamil Nadu
306.09
11 Uttar Pradesh (East)
76.93
11 Uttar Pradesh (West)
109.55
11 West Bengal
25.84
12 Andhra Pradesh286.91
12 Assam
8.67
12 Bihar
46.43
12 Delhi
693.06
12 Gujarat
227.08
12 Haryana
46.52
12 Himachal Pradesh7.78

7
4
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
0
6
4
7
6
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
0
6
4
7
10
0
0
6
1

-1
-4
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4
-1
-2
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4
-1
2
-8
-8
-2
-7

<!-- page 6 -->

12 Jammu & Kashmir6.33
12 Karnataka
330.12
12 Kerala
65.3
12 Kolkata
113.72
12 Madhya Pradesh53.99
12 Maharashtra 262.81
12 Mumbai
678.45
12 North East
8.84
12 Orissa
20.27
12 Punjab
67.28
12 Rajasthan
67.08
12 Tamil Nadu
306.09
12 Uttar Pradesh (East)
76.93
12 Uttar Pradesh (West)
109.55
12 West Bengal
25.84
13 Andhra Pradesh286.91
13 Assam
8.67
13 Bihar
47.35
13 Delhi
693.06
13 Gujarat
227.08
13 Haryana
46.52
13 Himachal Pradesh7.78
13 Jammu & Kashmir6.33
13 Karnataka
330.12
13 Kerala
65.3
13 Kolkata
113.72
13 Madhya Pradesh53.99
13 Maharashtra 262.81
13 Mumbai
678.45
13 North East
8.84
13 Orissa
20.27
13 Punjab
67.28
13 Rajasthan
67.08
13 Tamil Nadu
306.09
13 Uttar Pradesh (East)
76.93
13 Uttar Pradesh (West)
109.55
13 West Bengal
25.84
14 Andhra Pradesh286.91
14 Assam
8.67
14 Bihar
47.35
14 Delhi
693.06
14 Gujarat
227.08
14 Haryana
46.52
14 Himachal Pradesh7.78
14 Jammu & Kashmir6.33
14 Karnataka
330.12
14 Kerala
65.3
14 Kolkata
113.72
14 Madhya Pradesh53.99
14 Maharashtra 262.81

6
0
1
4
6
5
0
6
6
1
0
4
1
0
6
4
7
1
0
0
6
1
6
0
1
4
6
5
0
6
6
1
0
4
1
0
7
4
7
1
0
0
6
1
6
0
1
4
6
5

-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-2
-4
-1
-7
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3
-8
-2
-2
-7
-8
-4
-7
-8
-1
-4
-1
-7
-8
-8
-2
-7
-2
-8
-7
-4
-2
-3

<!-- page 7 -->

14 Mumbai
678.45
14 North East
8.84
14 Orissa
20.27
14 Punjab
67.28
14 Rajasthan
67.08
14 Tamil Nadu
306.09
14 Uttar Pradesh (East)
76.93
14 Uttar Pradesh (West)
109.55
14 West Bengal
25.84

0
6
6
1
0
4
1
0
7

-8
-2
-2
-7
-8
-4
-7
-8
-1

<!-- page 8 -->

Clock RoundService AreaBidder
Provisional Winning
Provisionally
BidRank
at
Allocated
Start
of Provisional
of Possible
Blocks
Clock Round
atWinning
to
start
raise
Bid
(Per
of
decisionNo.
Bid
Clock
Block)(Rs.
in
at Clock
Round
startofCrore)
of
Round
Blocks
Clock Selected
Round
1 Andhra Pradesh
Bharti Airtel- Limited
0Not Bid
0
1 Andhra Pradesh
Idea Cellular- Ltd.
0Not Bid
0
1 Andhra Pradesh
Telewings Communications
Services
0 - Private Limited.
Bid
4
1 Andhra Pradesh
Videocon Telecommunications
Limited.
0Not Bid
0
1 Andhra Pradesh
Vodafone South
Limited
0Not Bid
0
1 Assam
Bharti Airtel- Limited
0Bid
1
1 Assam
Idea Cellular- Ltd.
0Bid
4
1 Assam
Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Assam
Videocon Telecommunications
Limited.
0Not Bid
0
1 Assam
Vodafone South
Limited
0Bid
2
1 Bihar
Bharti Airtel- Limited
0Not Bid
0
1 Bihar
Idea Cellular- Ltd.
0Bid
1
1 Bihar
Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Bihar
Videocon Telecommunications
Limited.
0Bid
4
1 Bihar
Vodafone South
Limited
0Bid
2
1 Delhi
Bharti Airtel- Limited
0Not Bid
0
1 Delhi
Idea Cellular- Ltd.
0Not Bid
0
1 Delhi
Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Delhi
Videocon Telecommunications
Limited.
0Not Bid
0
1 Delhi
Vodafone South
Limited
0Not Bid
0
1 Gujarat
Bharti Airtel- Limited
0Not Bid
0
1 Gujarat
Idea Cellular- Ltd.
0Not Bid
0
1 Gujarat
Telewings Communications
Services
0 - Private Limited.
Bid
4
1 Gujarat
Videocon Telecommunications
Limited.
0Bid
4
1 Gujarat
Vodafone South
Limited
0Not Bid
0
1 Haryana Bharti Airtel- Limited
0Not Bid
0
1 Haryana Idea Cellular- Ltd.
0Not Bid
0
1 Haryana Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Haryana Videocon Telecommunications
Limited.
0Bid
4
1 Haryana Vodafone South
Limited
0Bid
2
1 Himachal Pradesh
Bharti Airtel- Limited
0Not Bid
0
1 Himachal Pradesh
Idea Cellular- Ltd.
0Not Bid
0
1 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Himachal Pradesh
Videocon Telecommunications
Limited.
0Not Bid
0
1 Himachal Pradesh
Vodafone South
Limited
0Bid
1
1 Jammu & Kashmir
Bharti Airtel- Limited
0Not Bid
0
1 Jammu & Kashmir
Idea Cellular- Ltd.
0Bid
4
1 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Jammu & Kashmir
Videocon Telecommunications
Limited.
0Not Bid
0
1 Jammu & Kashmir
Vodafone South
Limited
0Bid
2
1 Karnataka Bharti Airtel- Limited
0Not Bid
0
1 Karnataka Idea Cellular- Ltd.
0Not Bid
0
1 Karnataka Telewings Communications
Services
0 - Private Limited.
Not Bid
0
1 Karnataka Videocon Telecommunications
Limited.
0Not Bid
0
1 Karnataka Vodafone South
Limited
0Not Bid
0
1 Kerala
Bharti Airtel- Limited
0Not Bid
0

<!-- page 9 -->

1 Kerala
Idea Cellular- Ltd.
01 Kerala
Telewings Communications
Services
0 - Private Limited.
1 Kerala
Videocon Telecommunications
Limited.
01 Kerala
Vodafone South
Limited
01 Kolkata
Bharti Airtel- Limited
01 Kolkata
Idea Cellular- Ltd.
01 Kolkata
Telewings Communications
Services
0 - Private Limited.
1 Kolkata
Videocon Telecommunications
Limited.
01 Kolkata
Vodafone South
Limited
01 Madhya Pradesh
Bharti Airtel- Limited
01 Madhya Pradesh
Idea Cellular- Ltd.
01 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
1 Madhya Pradesh
Videocon Telecommunications
Limited.
01 Madhya Pradesh
Vodafone South
Limited
01 Maharashtra
Bharti Airtel- Limited
01 Maharashtra
Idea Cellular- Ltd.
01 Maharashtra
Telewings Communications
Services
0 - Private Limited.
1 Maharashtra
Videocon Telecommunications
Limited.
01 Maharashtra
Vodafone South
Limited
01 Mumbai Bharti Airtel- Limited
01 Mumbai Idea Cellular- Ltd.
01 Mumbai Telewings Communications
Services
0 - Private Limited.
1 Mumbai Videocon Telecommunications
Limited.
01 Mumbai Vodafone South
Limited
01 North East Bharti Airtel- Limited
01 North East Idea Cellular- Ltd.
01 North East Telewings Communications
Services
0 - Private Limited.
1 North East Videocon Telecommunications
Limited.
01 North East Vodafone South
Limited
01 Orissa
Bharti Airtel- Limited
01 Orissa
Idea Cellular- Ltd.
01 Orissa
Telewings Communications
Services
0 - Private Limited.
1 Orissa
Videocon Telecommunications
Limited.
01 Orissa
Vodafone South
Limited
01 Punjab
Bharti Airtel- Limited
01 Punjab
Idea Cellular- Ltd.
01 Punjab
Telewings Communications
Services
0 - Private Limited.
1 Punjab
Videocon Telecommunications
Limited.
01 Punjab
Vodafone South
Limited
01 Rajasthan Bharti Airtel- Limited
01 Rajasthan Idea Cellular- Ltd.
01 Rajasthan Telewings Communications
Services
0 - Private Limited.
1 Rajasthan Videocon Telecommunications
Limited.
01 Rajasthan Vodafone South
Limited
01 Tamil NaduBharti Airtel- Limited
01 Tamil NaduIdea Cellular- Ltd.
01 Tamil NaduTelewings Communications
Services
0 - Private Limited.
-

Not Bid
Not Bid
Not Bid
Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Bid
Not Bid
Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid

0
0
0
1
0
4
0
0
0
0
0
0
4
2
0
0
4
0
0
0
0
0
0
0
0
4
0
0
2
0
4
0
0
2
0
0
0
0
1
0
0
0
0
0
0
4
0

<!-- page 10 -->

1 Tamil NaduVideocon Telecommunications
Limited.
01 Tamil NaduVodafone South
Limited
01 Uttar Pradesh
Bharti
(East)
Airtel- Limited
01 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
01 Uttar Pradesh
Telewings
(East) Communications
Services
0 - Private Limited.
1 Uttar Pradesh
Videocon
(East) Telecommunications
Limited.
01 Uttar Pradesh
Vodafone
(East) South
Limited
01 Uttar Pradesh
Bharti
(West)
Airtel- Limited
01 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
01 Uttar Pradesh
Telewings
(West) Communications
Services
0 - Private Limited.
1 Uttar Pradesh
Videocon
(West) Telecommunications
Limited.
01 Uttar Pradesh
Vodafone
(West) South
Limited
01 West BengalBharti Airtel- Limited
01 West BengalIdea Cellular- Ltd.
01 West BengalTelewings Communications
Services
0 - Private Limited.
1 West BengalVideocon Telecommunications
Limited.
01 West BengalVodafone South
Limited
02 Andhra Pradesh
Bharti Airtel- Limited
02 Andhra Pradesh
Idea Cellular- Ltd.
02 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
2 Andhra Pradesh
Videocon Telecommunications
Limited.
02 Andhra Pradesh
Vodafone South
Limited
02 Assam
Bharti Airtel Limited
8.67
1
1 yes
2 Assam
Idea Cellular Ltd. 8.67
4
2 yes
2 Assam
Telewings Communications
Services
0 - Private Limited.
2 Assam
Videocon Telecommunications
Limited.
02 Assam
Vodafone South Limited
8.67
2
32 Bihar
Bharti Airtel- Limited
02 Bihar
Idea Cellular Ltd.42.51
1
1 yes
2 Bihar
Telewings Communications
Services
0 - Private Limited.
2 Bihar
Videocon Telecommunications
42.51
Limited.
4
3 yes
2 Bihar
Vodafone South 42.51
Limited
2
22 Delhi
Bharti Airtel- Limited
02 Delhi
Idea Cellular- Ltd.
02 Delhi
Telewings Communications
Services
0 - Private Limited.
2 Delhi
Videocon Telecommunications
Limited.
02 Delhi
Vodafone South
Limited
02 Gujarat
Bharti Airtel- Limited
02 Gujarat
Idea Cellular- Ltd.
02 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
2 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
2 Gujarat
Vodafone South
Limited
02 Haryana Bharti Airtel- Limited
02 Haryana Idea Cellular- Ltd.
02 Haryana Telewings Communications
Services
0 - Private Limited.
2 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
2 Haryana Vodafone South 46.52
Limited
2
2-

Not Bid
Not Bid
Not Bid
Not Bid
Bid
Bid
Bid
Not Bid
Not Bid
Not Bid
Bid
Bid
Not Bid
Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
4
4
1
0
0
0
4
2
0
4
0
0
2
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 11 -->

2 Himachal Pradesh
Bharti Airtel- Limited
02 Himachal Pradesh
Idea Cellular- Ltd.
02 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
2 Himachal Pradesh
Videocon Telecommunications
Limited.
02 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
2 Jammu & Kashmir
Bharti Airtel- Limited
02 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
2 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
2 Jammu & Kashmir
Videocon Telecommunications
Limited.
02 Jammu & Kashmir
Vodafone South Limited
6.33
2
12 Karnataka Bharti Airtel- Limited
02 Karnataka Idea Cellular- Ltd.
02 Karnataka Telewings Communications
Services
0 - Private Limited.
2 Karnataka Videocon Telecommunications
Limited.
02 Karnataka Vodafone South
Limited
02 Kerala
Bharti Airtel- Limited
02 Kerala
Idea Cellular- Ltd.
02 Kerala
Telewings Communications
Services
0 - Private Limited.
2 Kerala
Videocon Telecommunications
Limited.
02 Kerala
Vodafone South Limited
65.3
1
1 yes
2 Kolkata
Bharti Airtel- Limited
02 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
2 Kolkata
Telewings Communications
Services
0 - Private Limited.
2 Kolkata
Videocon Telecommunications
Limited.
02 Kolkata
Vodafone South
Limited
02 Madhya Pradesh
Bharti Airtel- Limited
02 Madhya Pradesh
Idea Cellular- Ltd.
02 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
2 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
2 Madhya Pradesh
Vodafone South 53.99
Limited
2
22 Maharashtra
Bharti Airtel- Limited
02 Maharashtra
Idea Cellular- Ltd.
02 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
2 Maharashtra
Videocon Telecommunications
Limited.
02 Maharashtra
Vodafone South
Limited
02 Mumbai Bharti Airtel- Limited
02 Mumbai Idea Cellular- Ltd.
02 Mumbai Telewings Communications
Services
0 - Private Limited.
2 Mumbai Videocon Telecommunications
Limited.
02 Mumbai Vodafone South
Limited
02 North East Bharti Airtel- Limited
02 North East Idea Cellular Ltd. 8.84
4
1 yes
2 North East Telewings Communications
Services
0 - Private Limited.
2 North East Videocon Telecommunications
Limited.
02 North East Vodafone South Limited
8.84
2
22 Orissa
Bharti Airtel- Limited
02 Orissa
Idea Cellular Ltd.20.27
4
1 yes

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 12 -->

2 Orissa
Telewings Communications
Services
0 - Private Limited.
2 Orissa
Videocon Telecommunications
Limited.
02 Orissa
Vodafone South 20.27
Limited
2
22 Punjab
Bharti Airtel- Limited
02 Punjab
Idea Cellular- Ltd.
02 Punjab
Telewings Communications
Services
0 - Private Limited.
2 Punjab
Videocon Telecommunications
Limited.
02 Punjab
Vodafone South 67.28
Limited
1
1 yes
2 Rajasthan Bharti Airtel- Limited
02 Rajasthan Idea Cellular- Ltd.
02 Rajasthan Telewings Communications
Services
0 - Private Limited.
2 Rajasthan Videocon Telecommunications
Limited.
02 Rajasthan Vodafone South
Limited
02 Tamil NaduBharti Airtel- Limited
02 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
2 Tamil NaduTelewings Communications
Services
0 - Private Limited.
2 Tamil NaduVideocon Telecommunications
Limited.
02 Tamil NaduVodafone South
Limited
02 Uttar Pradesh
Bharti
(East)
Airtel- Limited
02 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
02 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 1Limited.
yes
2 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
2 yes
2 Uttar Pradesh
Vodafone
(East) South 76.17
Limited
0
32 Uttar Pradesh
Bharti
(West)
Airtel- Limited
02 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
02 Uttar Pradesh
Telewings
(West) Communications
Services
0 - Private Limited.
2 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
2 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
12 West BengalBharti Airtel- Limited
02 West BengalIdea Cellular Ltd.25.84
4
1 yes
2 West BengalTelewings Communications
Services
0 - Private Limited.
2 West BengalVideocon Telecommunications
Limited.
02 West BengalVodafone South 25.84
Limited
2
23 Andhra Pradesh
Bharti Airtel- Limited
03 Andhra Pradesh
Idea Cellular- Ltd.
03 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
3 Andhra Pradesh
Videocon Telecommunications
Limited.
03 Andhra Pradesh
Vodafone South
Limited
03 Assam
Bharti Airtel Limited
8.67
1
1 yes
3 Assam
Idea Cellular Ltd. 8.67
4
2 yes
3 Assam
Telewings Communications
Services
0 - Private Limited.
3 Assam
Videocon Telecommunications
Limited.
03 Assam
Vodafone South Limited
8.67
2
33 Bihar
Bharti Airtel- Limited
03 Bihar
Idea Cellular Ltd.42.51
1
1 yes
3 Bihar
Telewings Communications
Services
0 - Private Limited.
3 Bihar
Videocon Telecommunications
42.51
Limited.
4
3 yes

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 13 -->

3 Bihar
Vodafone South 42.51
Limited
2
23 Delhi
Bharti Airtel- Limited
03 Delhi
Idea Cellular- Ltd.
03 Delhi
Telewings Communications
Services
0 - Private Limited.
3 Delhi
Videocon Telecommunications
Limited.
03 Delhi
Vodafone South
Limited
03 Gujarat
Bharti Airtel- Limited
03 Gujarat
Idea Cellular- Ltd.
03 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
3 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
3 Gujarat
Vodafone South
Limited
03 Haryana Bharti Airtel- Limited
03 Haryana Idea Cellular- Ltd.
03 Haryana Telewings Communications
Services
0 - Private Limited.
3 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
3 Haryana Vodafone South 46.52
Limited
2
23 Himachal Pradesh
Bharti Airtel- Limited
03 Himachal Pradesh
Idea Cellular- Ltd.
03 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
3 Himachal Pradesh
Videocon Telecommunications
Limited.
03 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
3 Jammu & Kashmir
Bharti Airtel- Limited
03 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
3 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
3 Jammu & Kashmir
Videocon Telecommunications
Limited.
03 Jammu & Kashmir
Vodafone South Limited
6.33
2
13 Karnataka Bharti Airtel- Limited
03 Karnataka Idea Cellular- Ltd.
03 Karnataka Telewings Communications
Services
0 - Private Limited.
3 Karnataka Videocon Telecommunications
Limited.
03 Karnataka Vodafone South
Limited
03 Kerala
Bharti Airtel- Limited
03 Kerala
Idea Cellular- Ltd.
03 Kerala
Telewings Communications
Services
0 - Private Limited.
3 Kerala
Videocon Telecommunications
Limited.
03 Kerala
Vodafone South Limited
65.3
1
1 yes
3 Kolkata
Bharti Airtel- Limited
03 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
3 Kolkata
Telewings Communications
Services
0 - Private Limited.
3 Kolkata
Videocon Telecommunications
Limited.
03 Kolkata
Vodafone South
Limited
03 Madhya Pradesh
Bharti Airtel- Limited
03 Madhya Pradesh
Idea Cellular- Ltd.
03 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
3 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
3 Madhya Pradesh
Vodafone South 53.99
Limited
2
23 Maharashtra
Bharti Airtel- Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 14 -->

3 Maharashtra
Idea Cellular- Ltd.
03 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
3 Maharashtra
Videocon Telecommunications
Limited.
03 Maharashtra
Vodafone South
Limited
03 Mumbai Bharti Airtel- Limited
03 Mumbai Idea Cellular- Ltd.
03 Mumbai Telewings Communications
Services
0 - Private Limited.
3 Mumbai Videocon Telecommunications
Limited.
03 Mumbai Vodafone South
Limited
03 North East Bharti Airtel- Limited
03 North East Idea Cellular Ltd. 8.84
4
1 yes
3 North East Telewings Communications
Services
0 - Private Limited.
3 North East Videocon Telecommunications
Limited.
03 North East Vodafone South Limited
8.84
2
23 Orissa
Bharti Airtel- Limited
03 Orissa
Idea Cellular Ltd.20.27
4
1 yes
3 Orissa
Telewings Communications
Services
0 - Private Limited.
3 Orissa
Videocon Telecommunications
Limited.
03 Orissa
Vodafone South 20.27
Limited
2
23 Punjab
Bharti Airtel- Limited
03 Punjab
Idea Cellular- Ltd.
03 Punjab
Telewings Communications
Services
0 - Private Limited.
3 Punjab
Videocon Telecommunications
Limited.
03 Punjab
Vodafone South 67.28
Limited
1
1 yes
3 Rajasthan Bharti Airtel- Limited
03 Rajasthan Idea Cellular- Ltd.
03 Rajasthan Telewings Communications
Services
0 - Private Limited.
3 Rajasthan Videocon Telecommunications
Limited.
03 Rajasthan Vodafone South
Limited
03 Tamil NaduBharti Airtel- Limited
03 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
3 Tamil NaduTelewings Communications
Services
0 - Private Limited.
3 Tamil NaduVideocon Telecommunications
Limited.
03 Tamil NaduVodafone South
Limited
03 Uttar Pradesh
Bharti
(East)
Airtel- Limited
03 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
03 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
3 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
3 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
3 Uttar Pradesh
Bharti
(West)
Airtel- Limited
03 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
03 Uttar Pradesh
Telewings
(West) Communications
Services
0 - Private Limited.
3 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
3 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
13 West BengalBharti Airtel- Limited
03 West BengalIdea Cellular Ltd.25.84
4
1 yes
3 West BengalTelewings Communications
Services
0 - Private Limited.
-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 15 -->

3 West BengalVideocon Telecommunications
Limited.
03 West BengalVodafone South 25.84
Limited
2
24 Andhra Pradesh
Bharti Airtel- Limited
04 Andhra Pradesh
Idea Cellular- Ltd.
04 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
4 Andhra Pradesh
Videocon Telecommunications
Limited.
04 Andhra Pradesh
Vodafone South
Limited
04 Assam
Bharti Airtel Limited
8.67
1
1 yes
4 Assam
Idea Cellular Ltd. 8.67
4
2 yes
4 Assam
Telewings Communications
Services
0 - Private Limited.
4 Assam
Videocon Telecommunications
Limited.
04 Assam
Vodafone South Limited
8.67
2
34 Bihar
Bharti Airtel- Limited
04 Bihar
Idea Cellular Ltd.42.51
1
1 yes
4 Bihar
Telewings Communications
Services
0 - Private Limited.
4 Bihar
Videocon Telecommunications
42.51
Limited.
4
3 yes
4 Bihar
Vodafone South 42.51
Limited
2
24 Delhi
Bharti Airtel- Limited
04 Delhi
Idea Cellular- Ltd.
04 Delhi
Telewings Communications
Services
0 - Private Limited.
4 Delhi
Videocon Telecommunications
Limited.
04 Delhi
Vodafone South
Limited
04 Gujarat
Bharti Airtel- Limited
04 Gujarat
Idea Cellular- Ltd.
04 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
4 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
4 Gujarat
Vodafone South
Limited
04 Haryana Bharti Airtel- Limited
04 Haryana Idea Cellular- Ltd.
04 Haryana Telewings Communications
Services
0 - Private Limited.
4 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
4 Haryana Vodafone South 46.52
Limited
2
24 Himachal Pradesh
Bharti Airtel- Limited
04 Himachal Pradesh
Idea Cellular- Ltd.
04 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
4 Himachal Pradesh
Videocon Telecommunications
Limited.
04 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
4 Jammu & Kashmir
Bharti Airtel- Limited
04 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
4 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
4 Jammu & Kashmir
Videocon Telecommunications
Limited.
04 Jammu & Kashmir
Vodafone South Limited
6.33
2
14 Karnataka Bharti Airtel- Limited
04 Karnataka Idea Cellular- Ltd.
04 Karnataka Telewings Communications
Services
0 - Private Limited.
4 Karnataka Videocon Telecommunications
Limited.
04 Karnataka Vodafone South
Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 16 -->

4 Kerala
Bharti Airtel- Limited
04 Kerala
Idea Cellular- Ltd.
04 Kerala
Telewings Communications
Services
0 - Private Limited.
4 Kerala
Videocon Telecommunications
Limited.
04 Kerala
Vodafone South Limited
65.3
1
1 yes
4 Kolkata
Bharti Airtel- Limited
04 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
4 Kolkata
Telewings Communications
Services
0 - Private Limited.
4 Kolkata
Videocon Telecommunications
Limited.
04 Kolkata
Vodafone South
Limited
04 Madhya Pradesh
Bharti Airtel- Limited
04 Madhya Pradesh
Idea Cellular- Ltd.
04 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
4 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
4 Madhya Pradesh
Vodafone South 53.99
Limited
2
24 Maharashtra
Bharti Airtel- Limited
04 Maharashtra
Idea Cellular- Ltd.
04 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
4 Maharashtra
Videocon Telecommunications
Limited.
04 Maharashtra
Vodafone South
Limited
04 Mumbai Bharti Airtel- Limited
04 Mumbai Idea Cellular- Ltd.
04 Mumbai Telewings Communications
Services
0 - Private Limited.
4 Mumbai Videocon Telecommunications
Limited.
04 Mumbai Vodafone South
Limited
04 North East Bharti Airtel- Limited
04 North East Idea Cellular Ltd. 8.84
4
1 yes
4 North East Telewings Communications
Services
0 - Private Limited.
4 North East Videocon Telecommunications
Limited.
04 North East Vodafone South Limited
8.84
2
24 Orissa
Bharti Airtel- Limited
04 Orissa
Idea Cellular Ltd.20.27
4
1 yes
4 Orissa
Telewings Communications
Services
0 - Private Limited.
4 Orissa
Videocon Telecommunications
Limited.
04 Orissa
Vodafone South 20.27
Limited
2
24 Punjab
Bharti Airtel- Limited
04 Punjab
Idea Cellular- Ltd.
04 Punjab
Telewings Communications
Services
0 - Private Limited.
4 Punjab
Videocon Telecommunications
Limited.
04 Punjab
Vodafone South 67.28
Limited
1
1 yes
4 Rajasthan Bharti Airtel- Limited
04 Rajasthan Idea Cellular- Ltd.
04 Rajasthan Telewings Communications
Services
0 - Private Limited.
4 Rajasthan Videocon Telecommunications
Limited.
04 Rajasthan Vodafone South
Limited
04 Tamil NaduBharti Airtel- Limited
04 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 17 -->

4 Tamil NaduTelewings Communications
Services
0 - Private Limited.
4 Tamil NaduVideocon Telecommunications
Limited.
04 Tamil NaduVodafone South
Limited
04 Uttar Pradesh
Bharti
(East)
Airtel- Limited
04 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
04 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
4 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
4 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
4 Uttar Pradesh
Bharti
(West)
Airtel- Limited
04 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
04 Uttar Pradesh
Telewings
(West) Communications
Services
0 - Private Limited.
4 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
4 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
14 West BengalBharti Airtel- Limited
04 West BengalIdea Cellular Ltd.25.84
4
1 yes
4 West BengalTelewings Communications
Services
0 - Private Limited.
4 West BengalVideocon Telecommunications
Limited.
04 West BengalVodafone South 25.84
Limited
2
25 Andhra Pradesh
Bharti Airtel- Limited
05 Andhra Pradesh
Idea Cellular- Ltd.
05 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
5 Andhra Pradesh
Videocon Telecommunications
Limited.
05 Andhra Pradesh
Vodafone South
Limited
05 Assam
Bharti Airtel Limited
8.67
1
1 yes
5 Assam
Idea Cellular Ltd. 8.67
4
2 yes
5 Assam
Telewings Communications
Services
0 - Private Limited.
5 Assam
Videocon Telecommunications
Limited.
05 Assam
Vodafone South Limited
8.67
2
35 Bihar
Bharti Airtel- Limited
05 Bihar
Idea Cellular Ltd.42.51
1
1 yes
5 Bihar
Telewings Communications
Services
0 - Private Limited.
5 Bihar
Videocon Telecommunications
42.51
Limited.
4
3 yes
5 Bihar
Vodafone South 42.51
Limited
2
25 Delhi
Bharti Airtel- Limited
05 Delhi
Idea Cellular- Ltd.
05 Delhi
Telewings Communications
Services
0 - Private Limited.
5 Delhi
Videocon Telecommunications
Limited.
05 Delhi
Vodafone South
Limited
05 Gujarat
Bharti Airtel- Limited
05 Gujarat
Idea Cellular- Ltd.
05 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
5 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
5 Gujarat
Vodafone South
Limited
05 Haryana Bharti Airtel- Limited
05 Haryana Idea Cellular- Ltd.
05 Haryana Telewings Communications
Services
0 - Private Limited.
5 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
2
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 18 -->

5 Haryana Vodafone South 46.52
Limited
2
25 Himachal Pradesh
Bharti Airtel- Limited
05 Himachal Pradesh
Idea Cellular- Ltd.
05 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
5 Himachal Pradesh
Videocon Telecommunications
Limited.
05 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
5 Jammu & Kashmir
Bharti Airtel- Limited
05 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
5 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
5 Jammu & Kashmir
Videocon Telecommunications
Limited.
05 Jammu & Kashmir
Vodafone South Limited
6.33
2
15 Karnataka Bharti Airtel- Limited
05 Karnataka Idea Cellular- Ltd.
05 Karnataka Telewings Communications
Services
0 - Private Limited.
5 Karnataka Videocon Telecommunications
Limited.
05 Karnataka Vodafone South
Limited
05 Kerala
Bharti Airtel- Limited
05 Kerala
Idea Cellular- Ltd.
05 Kerala
Telewings Communications
Services
0 - Private Limited.
5 Kerala
Videocon Telecommunications
Limited.
05 Kerala
Vodafone South Limited
65.3
1
1 yes
5 Kolkata
Bharti Airtel- Limited
05 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
5 Kolkata
Telewings Communications
Services
0 - Private Limited.
5 Kolkata
Videocon Telecommunications
Limited.
05 Kolkata
Vodafone South
Limited
05 Madhya Pradesh
Bharti Airtel- Limited
05 Madhya Pradesh
Idea Cellular- Ltd.
05 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
5 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
5 Madhya Pradesh
Vodafone South 53.99
Limited
2
25 Maharashtra
Bharti Airtel- Limited
05 Maharashtra
Idea Cellular- Ltd.
05 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
5 Maharashtra
Videocon Telecommunications
Limited.
05 Maharashtra
Vodafone South262.81
Limited
1
2 yes
5 Mumbai Bharti Airtel- Limited
05 Mumbai Idea Cellular- Ltd.
05 Mumbai Telewings Communications
Services
0 - Private Limited.
5 Mumbai Videocon Telecommunications
Limited.
05 Mumbai Vodafone South
Limited
05 North East Bharti Airtel- Limited
05 North East Idea Cellular Ltd. 8.84
4
1 yes
5 North East Telewings Communications
Services
0 - Private Limited.
5 North East Videocon Telecommunications
Limited.
05 North East Vodafone South Limited
8.84
2
25 Orissa
Bharti Airtel- Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 19 -->

5 Orissa
Idea Cellular Ltd.20.27
4
1 yes
5 Orissa
Telewings Communications
Services
0 - Private Limited.
5 Orissa
Videocon Telecommunications
Limited.
05 Orissa
Vodafone South 20.27
Limited
2
25 Punjab
Bharti Airtel- Limited
05 Punjab
Idea Cellular- Ltd.
05 Punjab
Telewings Communications
Services
0 - Private Limited.
5 Punjab
Videocon Telecommunications
Limited.
05 Punjab
Vodafone South 67.28
Limited
1
1 yes
5 Rajasthan Bharti Airtel- Limited
05 Rajasthan Idea Cellular- Ltd.
05 Rajasthan Telewings Communications
Services
0 - Private Limited.
5 Rajasthan Videocon Telecommunications
Limited.
05 Rajasthan Vodafone South
Limited
05 Tamil NaduBharti Airtel- Limited
05 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
5 Tamil NaduTelewings Communications
Services
0 - Private Limited.
5 Tamil NaduVideocon Telecommunications
Limited.
05 Tamil NaduVodafone South
Limited
05 Uttar Pradesh
Bharti
(East)
Airtel- Limited
05 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
05 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
5 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
5 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
5 Uttar Pradesh
Bharti
(West)
Airtel- Limited
05 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
05 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
5 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
5 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
5 West BengalBharti Airtel- Limited
05 West BengalIdea Cellular Ltd.25.84
4
1 yes
5 West BengalTelewings Communications
Services
0 - Private Limited.
5 West BengalVideocon Telecommunications
Limited.
05 West BengalVodafone South 25.84
Limited
2
26 Andhra Pradesh
Bharti Airtel- Limited
06 Andhra Pradesh
Idea Cellular- Ltd.
06 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
6 Andhra Pradesh
Videocon Telecommunications
Limited.
06 Andhra Pradesh
Vodafone South
Limited
06 Assam
Bharti Airtel Limited
8.67
1
1 yes
6 Assam
Idea Cellular Ltd. 8.67
4
2 yes
6 Assam
Telewings Communications
Services
0 - Private Limited.
6 Assam
Videocon Telecommunications
Limited.
06 Assam
Vodafone South Limited
8.67
2
36 Bihar
Bharti Airtel- Limited
06 Bihar
Idea Cellular Ltd.42.51
2
1 yes
6 Bihar
Telewings Communications
42.51
Services
0 Private 4Limited.
-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
4

<!-- page 20 -->

6 Bihar
Videocon Telecommunications
42.51
Limited.
4
3 yes
6 Bihar
Vodafone South 42.51
Limited
2
2 yes
6 Delhi
Bharti Airtel- Limited
06 Delhi
Idea Cellular- Ltd.
06 Delhi
Telewings Communications
Services
0 - Private Limited.
6 Delhi
Videocon Telecommunications
Limited.
06 Delhi
Vodafone South
Limited
06 Gujarat
Bharti Airtel- Limited
06 Gujarat
Idea Cellular- Ltd.
06 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
6 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
6 Gujarat
Vodafone South
Limited
06 Haryana Bharti Airtel- Limited
06 Haryana Idea Cellular- Ltd.
06 Haryana Telewings Communications
Services
0 - Private Limited.
6 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
6 Haryana Vodafone South 46.52
Limited
2
26 Himachal Pradesh
Bharti Airtel- Limited
06 Himachal Pradesh
Idea Cellular- Ltd.
06 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
6 Himachal Pradesh
Videocon Telecommunications
Limited.
06 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
6 Jammu & Kashmir
Bharti Airtel- Limited
06 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
6 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
6 Jammu & Kashmir
Videocon Telecommunications
Limited.
06 Jammu & Kashmir
Vodafone South Limited
6.33
2
16 Karnataka Bharti Airtel- Limited
06 Karnataka Idea Cellular- Ltd.
06 Karnataka Telewings Communications
Services
0 - Private Limited.
6 Karnataka Videocon Telecommunications
Limited.
06 Karnataka Vodafone South
Limited
06 Kerala
Bharti Airtel- Limited
06 Kerala
Idea Cellular- Ltd.
06 Kerala
Telewings Communications
Services
0 - Private Limited.
6 Kerala
Videocon Telecommunications
Limited.
06 Kerala
Vodafone South Limited
65.3
1
1 yes
6 Kolkata
Bharti Airtel- Limited
06 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
6 Kolkata
Telewings Communications
Services
0 - Private Limited.
6 Kolkata
Videocon Telecommunications
Limited.
06 Kolkata
Vodafone South
Limited
06 Madhya Pradesh
Bharti Airtel- Limited
06 Madhya Pradesh
Idea Cellular- Ltd.
06 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
6 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
6 Madhya Pradesh
Vodafone South 53.99
Limited
2
2-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 21 -->

6 Maharashtra
Bharti Airtel- Limited
06 Maharashtra
Idea Cellular- Ltd.
06 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
6 Maharashtra
Videocon Telecommunications
Limited.
06 Maharashtra
Vodafone South262.81
Limited
1
2 yes
6 Mumbai Bharti Airtel- Limited
06 Mumbai Idea Cellular- Ltd.
06 Mumbai Telewings Communications
Services
0 - Private Limited.
6 Mumbai Videocon Telecommunications
Limited.
06 Mumbai Vodafone South
Limited
06 North East Bharti Airtel- Limited
06 North East Idea Cellular Ltd. 8.84
4
1 yes
6 North East Telewings Communications
Services
0 - Private Limited.
6 North East Videocon Telecommunications
Limited.
06 North East Vodafone South Limited
8.84
2
26 Orissa
Bharti Airtel- Limited
06 Orissa
Idea Cellular Ltd.20.27
4
1 yes
6 Orissa
Telewings Communications
Services
0 - Private Limited.
6 Orissa
Videocon Telecommunications
Limited.
06 Orissa
Vodafone South 20.27
Limited
2
26 Punjab
Bharti Airtel- Limited
06 Punjab
Idea Cellular- Ltd.
06 Punjab
Telewings Communications
Services
0 - Private Limited.
6 Punjab
Videocon Telecommunications
Limited.
06 Punjab
Vodafone South 67.28
Limited
1
1 yes
6 Rajasthan Bharti Airtel- Limited
06 Rajasthan Idea Cellular- Ltd.
06 Rajasthan Telewings Communications
Services
0 - Private Limited.
6 Rajasthan Videocon Telecommunications
Limited.
06 Rajasthan Vodafone South
Limited
06 Tamil NaduBharti Airtel- Limited
06 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
6 Tamil NaduTelewings Communications
Services
0 - Private Limited.
6 Tamil NaduVideocon Telecommunications
Limited.
06 Tamil NaduVodafone South
Limited
06 Uttar Pradesh
Bharti
(East)
Airtel- Limited
06 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
06 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
6 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
6 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
6 Uttar Pradesh
Bharti
(West)
Airtel- Limited
06 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
06 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
6 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
6 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
6 West BengalBharti Airtel- Limited
06 West BengalIdea Cellular Ltd.25.84
4
1 yes

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 22 -->

6 West BengalTelewings Communications
Services
0 - Private Limited.
6 West BengalVideocon Telecommunications
Limited.
06 West BengalVodafone South 25.84
Limited
2
27 Andhra Pradesh
Bharti Airtel- Limited
07 Andhra Pradesh
Idea Cellular- Ltd.
07 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
7 Andhra Pradesh
Videocon Telecommunications
Limited.
07 Andhra Pradesh
Vodafone South
Limited
07 Assam
Bharti Airtel Limited
8.67
1
1 yes
7 Assam
Idea Cellular Ltd. 8.67
4
2 yes
7 Assam
Telewings Communications
Services
0 - Private Limited.
7 Assam
Videocon Telecommunications
Limited.
07 Assam
Vodafone South Limited
8.67
2
37 Bihar
Bharti Airtel- Limited
07 Bihar
Idea Cellular Ltd.42.51
2
2 yes
7 Bihar
Telewings Communications
44.21
Services
4 Private 1Limited.
yes
7 Bihar
Videocon Telecommunications
42.51
Limited.
0
47 Bihar
Vodafone South 42.51
Limited
2
3 yes
7 Delhi
Bharti Airtel- Limited
07 Delhi
Idea Cellular- Ltd.
07 Delhi
Telewings Communications
Services
0 - Private Limited.
7 Delhi
Videocon Telecommunications
Limited.
07 Delhi
Vodafone South
Limited
07 Gujarat
Bharti Airtel- Limited
07 Gujarat
Idea Cellular- Ltd.
07 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
7 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
7 Gujarat
Vodafone South
Limited
07 Haryana Bharti Airtel- Limited
07 Haryana Idea Cellular- Ltd.
07 Haryana Telewings Communications
Services
0 - Private Limited.
7 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
7 Haryana Vodafone South 46.52
Limited
2
27 Himachal Pradesh
Bharti Airtel- Limited
07 Himachal Pradesh
Idea Cellular- Ltd.
07 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
7 Himachal Pradesh
Videocon Telecommunications
Limited.
07 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
7 Jammu & Kashmir
Bharti Airtel- Limited
07 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
7 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
7 Jammu & Kashmir
Videocon Telecommunications
Limited.
07 Jammu & Kashmir
Vodafone South Limited
6.33
2
17 Karnataka Bharti Airtel- Limited
07 Karnataka Idea Cellular- Ltd.
07 Karnataka Telewings Communications
Services
0 - Private Limited.
7 Karnataka Videocon Telecommunications
Limited.
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 23 -->

7 Karnataka Vodafone South
Limited
07 Kerala
Bharti Airtel- Limited
07 Kerala
Idea Cellular- Ltd.
07 Kerala
Telewings Communications
Services
0 - Private Limited.
7 Kerala
Videocon Telecommunications
Limited.
07 Kerala
Vodafone South Limited
65.3
1
1 yes
7 Kolkata
Bharti Airtel- Limited
07 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
7 Kolkata
Telewings Communications
Services
0 - Private Limited.
7 Kolkata
Videocon Telecommunications
Limited.
07 Kolkata
Vodafone South
Limited
07 Madhya Pradesh
Bharti Airtel- Limited
07 Madhya Pradesh
Idea Cellular- Ltd.
07 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
7 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
7 Madhya Pradesh
Vodafone South 53.99
Limited
2
27 Maharashtra
Bharti Airtel- Limited
07 Maharashtra
Idea Cellular- Ltd.
07 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
7 Maharashtra
Videocon Telecommunications
Limited.
07 Maharashtra
Vodafone South262.81
Limited
1
2 yes
7 Mumbai Bharti Airtel- Limited
07 Mumbai Idea Cellular- Ltd.
07 Mumbai Telewings Communications
Services
0 - Private Limited.
7 Mumbai Videocon Telecommunications
Limited.
07 Mumbai Vodafone South
Limited
07 North East Bharti Airtel- Limited
07 North East Idea Cellular Ltd. 8.84
4
1 yes
7 North East Telewings Communications
Services
0 - Private Limited.
7 North East Videocon Telecommunications
Limited.
07 North East Vodafone South Limited
8.84
2
27 Orissa
Bharti Airtel- Limited
07 Orissa
Idea Cellular Ltd.20.27
4
1 yes
7 Orissa
Telewings Communications
Services
0 - Private Limited.
7 Orissa
Videocon Telecommunications
Limited.
07 Orissa
Vodafone South 20.27
Limited
2
27 Punjab
Bharti Airtel- Limited
07 Punjab
Idea Cellular- Ltd.
07 Punjab
Telewings Communications
Services
0 - Private Limited.
7 Punjab
Videocon Telecommunications
Limited.
07 Punjab
Vodafone South 67.28
Limited
1
1 yes
7 Rajasthan Bharti Airtel- Limited
07 Rajasthan Idea Cellular- Ltd.
07 Rajasthan Telewings Communications
Services
0 - Private Limited.
7 Rajasthan Videocon Telecommunications
Limited.
07 Rajasthan Vodafone South
Limited
07 Tamil NaduBharti Airtel- Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 24 -->

7 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
7 Tamil NaduTelewings Communications
Services
0 - Private Limited.
7 Tamil NaduVideocon Telecommunications
Limited.
07 Tamil NaduVodafone South
Limited
07 Uttar Pradesh
Bharti
(East)
Airtel- Limited
07 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
07 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
7 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
7 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
7 Uttar Pradesh
Bharti
(West)
Airtel- Limited
07 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
07 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
7 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
7 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
7 West BengalBharti Airtel- Limited
07 West BengalIdea Cellular Ltd.25.84
4
1 yes
7 West BengalTelewings Communications
Services
0 - Private Limited.
7 West BengalVideocon Telecommunications
Limited.
07 West BengalVodafone South 25.84
Limited
2
28 Andhra Pradesh
Bharti Airtel- Limited
08 Andhra Pradesh
Idea Cellular- Ltd.
08 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
8 Andhra Pradesh
Videocon Telecommunications
Limited.
08 Andhra Pradesh
Vodafone South
Limited
08 Assam
Bharti Airtel Limited
8.67
1
1 yes
8 Assam
Idea Cellular Ltd. 8.67
4
2 yes
8 Assam
Telewings Communications
Services
0 - Private Limited.
8 Assam
Videocon Telecommunications
Limited.
08 Assam
Vodafone South Limited
8.67
2
38 Bihar
Bharti Airtel- Limited
08 Bihar
Idea Cellular Ltd.42.51
08 Bihar
Telewings Communications
44.21
Services
4 Private 2Limited.
yes
8 Bihar
Videocon Telecommunications
44.21
Limited.
4
1 yes
8 Bihar
Vodafone South 42.51
Limited
08 Delhi
Bharti Airtel- Limited
08 Delhi
Idea Cellular- Ltd.
08 Delhi
Telewings Communications
Services
0 - Private Limited.
8 Delhi
Videocon Telecommunications
Limited.
08 Delhi
Vodafone South
Limited
08 Gujarat
Bharti Airtel- Limited
08 Gujarat
Idea Cellular- Ltd.
08 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
8 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
8 Gujarat
Vodafone South
Limited
08 Haryana Bharti Airtel- Limited
08 Haryana Idea Cellular- Ltd.
08 Haryana Telewings Communications
Services
0 - Private Limited.
-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
2
0
0
2
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 25 -->

8 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
8 Haryana Vodafone South 46.52
Limited
2
28 Himachal Pradesh
Bharti Airtel- Limited
08 Himachal Pradesh
Idea Cellular- Ltd.
08 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
8 Himachal Pradesh
Videocon Telecommunications
Limited.
08 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
8 Jammu & Kashmir
Bharti Airtel- Limited
08 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
8 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
8 Jammu & Kashmir
Videocon Telecommunications
Limited.
08 Jammu & Kashmir
Vodafone South Limited
6.33
2
18 Karnataka Bharti Airtel- Limited
08 Karnataka Idea Cellular- Ltd.
08 Karnataka Telewings Communications
Services
0 - Private Limited.
8 Karnataka Videocon Telecommunications
Limited.
08 Karnataka Vodafone South
Limited
08 Kerala
Bharti Airtel- Limited
08 Kerala
Idea Cellular- Ltd.
08 Kerala
Telewings Communications
Services
0 - Private Limited.
8 Kerala
Videocon Telecommunications
Limited.
08 Kerala
Vodafone South Limited
65.3
1
1 yes
8 Kolkata
Bharti Airtel- Limited
08 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
8 Kolkata
Telewings Communications
Services
0 - Private Limited.
8 Kolkata
Videocon Telecommunications
Limited.
08 Kolkata
Vodafone South
Limited
08 Madhya Pradesh
Bharti Airtel- Limited
08 Madhya Pradesh
Idea Cellular- Ltd.
08 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
8 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
8 Madhya Pradesh
Vodafone South 53.99
Limited
2
28 Maharashtra
Bharti Airtel- Limited
08 Maharashtra
Idea Cellular- Ltd.
08 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
8 Maharashtra
Videocon Telecommunications
Limited.
08 Maharashtra
Vodafone South262.81
Limited
1
2 yes
8 Mumbai Bharti Airtel- Limited
08 Mumbai Idea Cellular- Ltd.
08 Mumbai Telewings Communications
Services
0 - Private Limited.
8 Mumbai Videocon Telecommunications
Limited.
08 Mumbai Vodafone South
Limited
08 North East Bharti Airtel- Limited
08 North East Idea Cellular Ltd. 8.84
4
1 yes
8 North East Telewings Communications
Services
0 - Private Limited.
8 North East Videocon Telecommunications
Limited.
08 North East Vodafone South Limited
8.84
2
2-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 26 -->

8 Orissa
Bharti Airtel- Limited
08 Orissa
Idea Cellular Ltd.20.27
4
1 yes
8 Orissa
Telewings Communications
Services
0 - Private Limited.
8 Orissa
Videocon Telecommunications
Limited.
08 Orissa
Vodafone South 20.27
Limited
2
28 Punjab
Bharti Airtel- Limited
08 Punjab
Idea Cellular- Ltd.
08 Punjab
Telewings Communications
Services
0 - Private Limited.
8 Punjab
Videocon Telecommunications
Limited.
08 Punjab
Vodafone South 67.28
Limited
1
1 yes
8 Rajasthan Bharti Airtel- Limited
08 Rajasthan Idea Cellular- Ltd.
08 Rajasthan Telewings Communications
Services
0 - Private Limited.
8 Rajasthan Videocon Telecommunications
Limited.
08 Rajasthan Vodafone South
Limited
08 Tamil NaduBharti Airtel- Limited
08 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
8 Tamil NaduTelewings Communications
Services
0 - Private Limited.
8 Tamil NaduVideocon Telecommunications
Limited.
08 Tamil NaduVodafone South
Limited
08 Uttar Pradesh
Bharti
(East)
Airtel- Limited
08 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
08 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
8 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
8 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
8 Uttar Pradesh
Bharti
(West)
Airtel- Limited
08 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
08 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
8 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
8 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
8 West BengalBharti Airtel- Limited
08 West BengalIdea Cellular Ltd.25.84
4
1 yes
8 West BengalTelewings Communications
Services
0 - Private Limited.
8 West BengalVideocon Telecommunications
Limited.
08 West BengalVodafone South 25.84
Limited
2
29 Andhra Pradesh
Bharti Airtel- Limited
09 Andhra Pradesh
Idea Cellular- Ltd.
09 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
9 Andhra Pradesh
Videocon Telecommunications
Limited.
09 Andhra Pradesh
Vodafone South
Limited
09 Assam
Bharti Airtel Limited
8.67
1
1 yes
9 Assam
Idea Cellular Ltd. 8.67
4
2 yes
9 Assam
Telewings Communications
Services
0 - Private Limited.
9 Assam
Videocon Telecommunications
Limited.
09 Assam
Vodafone South Limited
8.67
2
39 Bihar
Bharti Airtel- Limited
09 Bihar
Idea Cellular Ltd.44.65
2
1-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 27 -->

9 Bihar
Telewings Communications
44.21
Services
0 Private 4Limited.
9 Bihar
Videocon Telecommunications
44.21
Limited.
4
3 yes
9 Bihar
Vodafone South 44.65
Limited
2
29 Delhi
Bharti Airtel- Limited
09 Delhi
Idea Cellular- Ltd.
09 Delhi
Telewings Communications
Services
0 - Private Limited.
9 Delhi
Videocon Telecommunications
Limited.
09 Delhi
Vodafone South
Limited
09 Gujarat
Bharti Airtel- Limited
09 Gujarat
Idea Cellular- Ltd.
09 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
9 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
9 Gujarat
Vodafone South
Limited
09 Haryana Bharti Airtel- Limited
09 Haryana Idea Cellular- Ltd.
09 Haryana Telewings Communications
Services
0 - Private Limited.
9 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
9 Haryana Vodafone South 46.52
Limited
2
29 Himachal Pradesh
Bharti Airtel- Limited
09 Himachal Pradesh
Idea Cellular- Ltd.
09 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
9 Himachal Pradesh
Videocon Telecommunications
Limited.
09 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
9 Jammu & Kashmir
Bharti Airtel- Limited
09 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
9 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
9 Jammu & Kashmir
Videocon Telecommunications
Limited.
09 Jammu & Kashmir
Vodafone South Limited
6.33
2
19 Karnataka Bharti Airtel- Limited
09 Karnataka Idea Cellular- Ltd.
09 Karnataka Telewings Communications
Services
0 - Private Limited.
9 Karnataka Videocon Telecommunications
Limited.
09 Karnataka Vodafone South
Limited
09 Kerala
Bharti Airtel- Limited
09 Kerala
Idea Cellular- Ltd.
09 Kerala
Telewings Communications
Services
0 - Private Limited.
9 Kerala
Videocon Telecommunications
Limited.
09 Kerala
Vodafone South Limited
65.3
1
1 yes
9 Kolkata
Bharti Airtel- Limited
09 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
9 Kolkata
Telewings Communications
Services
0 - Private Limited.
9 Kolkata
Videocon Telecommunications
Limited.
09 Kolkata
Vodafone South
Limited
09 Madhya Pradesh
Bharti Airtel- Limited
09 Madhya Pradesh
Idea Cellular- Ltd.
09 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
9 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes

Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

4
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 28 -->

9 Madhya Pradesh
Vodafone South 53.99
Limited
2
29 Maharashtra
Bharti Airtel- Limited
09 Maharashtra
Idea Cellular- Ltd.
09 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
9 Maharashtra
Videocon Telecommunications
Limited.
09 Maharashtra
Vodafone South262.81
Limited
1
2 yes
9 Mumbai Bharti Airtel- Limited
09 Mumbai Idea Cellular- Ltd.
09 Mumbai Telewings Communications
Services
0 - Private Limited.
9 Mumbai Videocon Telecommunications
Limited.
09 Mumbai Vodafone South
Limited
09 North East Bharti Airtel- Limited
09 North East Idea Cellular Ltd. 8.84
4
1 yes
9 North East Telewings Communications
Services
0 - Private Limited.
9 North East Videocon Telecommunications
Limited.
09 North East Vodafone South Limited
8.84
2
29 Orissa
Bharti Airtel- Limited
09 Orissa
Idea Cellular Ltd.20.27
4
1 yes
9 Orissa
Telewings Communications
Services
0 - Private Limited.
9 Orissa
Videocon Telecommunications
Limited.
09 Orissa
Vodafone South 20.27
Limited
2
29 Punjab
Bharti Airtel- Limited
09 Punjab
Idea Cellular- Ltd.
09 Punjab
Telewings Communications
Services
0 - Private Limited.
9 Punjab
Videocon Telecommunications
Limited.
09 Punjab
Vodafone South 67.28
Limited
1
1 yes
9 Rajasthan Bharti Airtel- Limited
09 Rajasthan Idea Cellular- Ltd.
09 Rajasthan Telewings Communications
Services
0 - Private Limited.
9 Rajasthan Videocon Telecommunications
Limited.
09 Rajasthan Vodafone South
Limited
09 Tamil NaduBharti Airtel- Limited
09 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
9 Tamil NaduTelewings Communications
Services
0 - Private Limited.
9 Tamil NaduVideocon Telecommunications
Limited.
09 Tamil NaduVodafone South
Limited
09 Uttar Pradesh
Bharti
(East)
Airtel- Limited
09 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
09 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
9 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
9 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
9 Uttar Pradesh
Bharti
(West)
Airtel- Limited
09 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
09 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
9 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
9 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
9 West BengalBharti Airtel- Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 29 -->

9 West BengalIdea Cellular Ltd.25.84
4
1 yes
9 West BengalTelewings Communications
Services
0 - Private Limited.
9 West BengalVideocon Telecommunications
Limited.
09 West BengalVodafone South 25.84
Limited
2
210 Andhra Pradesh
Bharti Airtel- Limited
010 Andhra Pradesh
Idea Cellular- Ltd.
010 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
10 Andhra Pradesh
Videocon Telecommunications
Limited.
010 Andhra Pradesh
Vodafone South
Limited
010 Assam
Bharti Airtel Limited
8.67
1
1 yes
10 Assam
Idea Cellular Ltd. 8.67
4
2 yes
10 Assam
Telewings Communications
Services
0 - Private Limited.
10 Assam
Videocon Telecommunications
Limited.
010 Assam
Vodafone South Limited
8.67
2
310 Bihar
Bharti Airtel- Limited
010 Bihar
Idea Cellular Ltd.44.65
2
1 yes
10 Bihar
Telewings Communications
44.65
Services
0 Private 4Limited.
10 Bihar
Videocon Telecommunications
44.65
Limited.
4
2 yes
10 Bihar
Vodafone South 44.65
Limited
2
3 yes
10 Delhi
Bharti Airtel- Limited
010 Delhi
Idea Cellular- Ltd.
010 Delhi
Telewings Communications
Services
0 - Private Limited.
10 Delhi
Videocon Telecommunications
Limited.
010 Delhi
Vodafone South
Limited
010 Gujarat
Bharti Airtel- Limited
010 Gujarat
Idea Cellular- Ltd.
010 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
10 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
10 Gujarat
Vodafone South
Limited
010 Haryana Bharti Airtel- Limited
010 Haryana Idea Cellular- Ltd.
010 Haryana Telewings Communications
Services
0 - Private Limited.
10 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
10 Haryana Vodafone South 46.52
Limited
2
210 Himachal Pradesh
Bharti Airtel- Limited
010 Himachal Pradesh
Idea Cellular- Ltd.
010 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
10 Himachal Pradesh
Videocon Telecommunications
Limited.
010 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
10 Jammu & Kashmir
Bharti Airtel- Limited
010 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
10 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
10 Jammu & Kashmir
Videocon Telecommunications
Limited.
010 Jammu & Kashmir
Vodafone South Limited
6.33
2
110 Karnataka Bharti Airtel- Limited
010 Karnataka Idea Cellular- Ltd.
010 Karnataka Telewings Communications
Services
0 - Private Limited.
-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 30 -->

10 Karnataka Videocon Telecommunications
Limited.
010 Karnataka Vodafone South
Limited
010 Kerala
Bharti Airtel- Limited
010 Kerala
Idea Cellular- Ltd.
010 Kerala
Telewings Communications
Services
0 - Private Limited.
10 Kerala
Videocon Telecommunications
Limited.
010 Kerala
Vodafone South Limited
65.3
1
1 yes
10 Kolkata
Bharti Airtel- Limited
010 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
10 Kolkata
Telewings Communications
Services
0 - Private Limited.
10 Kolkata
Videocon Telecommunications
Limited.
010 Kolkata
Vodafone South
Limited
010 Madhya Pradesh
Bharti Airtel- Limited
010 Madhya Pradesh
Idea Cellular- Ltd.
010 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
10 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
10 Madhya Pradesh
Vodafone South 53.99
Limited
2
210 Maharashtra
Bharti Airtel- Limited
010 Maharashtra
Idea Cellular- Ltd.
010 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
10 Maharashtra
Videocon Telecommunications
Limited.
010 Maharashtra
Vodafone South262.81
Limited
1
2 yes
10 Mumbai Bharti Airtel- Limited
010 Mumbai Idea Cellular- Ltd.
010 Mumbai Telewings Communications
Services
0 - Private Limited.
10 Mumbai Videocon Telecommunications
Limited.
010 Mumbai Vodafone South
Limited
010 North East Bharti Airtel- Limited
010 North East Idea Cellular Ltd. 8.84
4
1 yes
10 North East Telewings Communications
Services
0 - Private Limited.
10 North East Videocon Telecommunications
Limited.
010 North East Vodafone South Limited
8.84
2
210 Orissa
Bharti Airtel- Limited
010 Orissa
Idea Cellular Ltd.20.27
4
1 yes
10 Orissa
Telewings Communications
Services
0 - Private Limited.
10 Orissa
Videocon Telecommunications
Limited.
010 Orissa
Vodafone South 20.27
Limited
2
210 Punjab
Bharti Airtel- Limited
010 Punjab
Idea Cellular- Ltd.
010 Punjab
Telewings Communications
Services
0 - Private Limited.
10 Punjab
Videocon Telecommunications
Limited.
010 Punjab
Vodafone South 67.28
Limited
1
1 yes
10 Rajasthan Bharti Airtel- Limited
010 Rajasthan Idea Cellular- Ltd.
010 Rajasthan Telewings Communications
Services
0 - Private Limited.
10 Rajasthan Videocon Telecommunications
Limited.
010 Rajasthan Vodafone South
Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 31 -->

10 Tamil NaduBharti Airtel- Limited
010 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
10 Tamil NaduTelewings Communications
Services
0 - Private Limited.
10 Tamil NaduVideocon Telecommunications
Limited.
010 Tamil NaduVodafone South
Limited
010 Uttar Pradesh
Bharti
(East)
Airtel- Limited
010 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
010 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
10 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
10 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
10 Uttar Pradesh
Bharti
(West)
Airtel- Limited
010 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
010 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
10 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
10 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
10 West BengalBharti Airtel- Limited
010 West BengalIdea Cellular Ltd.25.84
4
1 yes
10 West BengalTelewings Communications
Services
0 - Private Limited.
10 West BengalVideocon Telecommunications
Limited.
010 West BengalVodafone South 25.84
Limited
2
211 Andhra Pradesh
Bharti Airtel- Limited
011 Andhra Pradesh
Idea Cellular- Ltd.
011 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
11 Andhra Pradesh
Videocon Telecommunications
Limited.
011 Andhra Pradesh
Vodafone South
Limited
011 Assam
Bharti Airtel Limited
8.67
1
1 yes
11 Assam
Idea Cellular Ltd. 8.67
4
2 yes
11 Assam
Telewings Communications
Services
0 - Private Limited.
11 Assam
Videocon Telecommunications
Limited.
011 Assam
Vodafone South Limited
8.67
2
311 Bihar
Bharti Airtel- Limited
011 Bihar
Idea Cellular Ltd.44.65
2
2 yes
11 Bihar
Telewings Communications
46.43
Services
4 Private 1Limited.
yes
11 Bihar
Videocon Telecommunications
44.65
Limited.
4
3 yes
11 Bihar
Vodafone South 44.65
Limited
0
411 Delhi
Bharti Airtel- Limited
011 Delhi
Idea Cellular- Ltd.
011 Delhi
Telewings Communications
Services
0 - Private Limited.
11 Delhi
Videocon Telecommunications
Limited.
011 Delhi
Vodafone South
Limited
011 Gujarat
Bharti Airtel- Limited
011 Gujarat
Idea Cellular- Ltd.
011 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
11 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
11 Gujarat
Vodafone South
Limited
011 Haryana Bharti Airtel- Limited
011 Haryana Idea Cellular- Ltd.
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
2
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 32 -->

11 Haryana Telewings Communications
Services
0 - Private Limited.
11 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
11 Haryana Vodafone South 46.52
Limited
2
211 Himachal Pradesh
Bharti Airtel- Limited
011 Himachal Pradesh
Idea Cellular- Ltd.
011 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
11 Himachal Pradesh
Videocon Telecommunications
Limited.
011 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
11 Jammu & Kashmir
Bharti Airtel- Limited
011 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
11 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
11 Jammu & Kashmir
Videocon Telecommunications
Limited.
011 Jammu & Kashmir
Vodafone South Limited
6.33
2
111 Karnataka Bharti Airtel- Limited
011 Karnataka Idea Cellular- Ltd.
011 Karnataka Telewings Communications
Services
0 - Private Limited.
11 Karnataka Videocon Telecommunications
Limited.
011 Karnataka Vodafone South
Limited
011 Kerala
Bharti Airtel- Limited
011 Kerala
Idea Cellular- Ltd.
011 Kerala
Telewings Communications
Services
0 - Private Limited.
11 Kerala
Videocon Telecommunications
Limited.
011 Kerala
Vodafone South Limited
65.3
1
1 yes
11 Kolkata
Bharti Airtel- Limited
011 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
11 Kolkata
Telewings Communications
Services
0 - Private Limited.
11 Kolkata
Videocon Telecommunications
Limited.
011 Kolkata
Vodafone South
Limited
011 Madhya Pradesh
Bharti Airtel- Limited
011 Madhya Pradesh
Idea Cellular- Ltd.
011 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
11 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
11 Madhya Pradesh
Vodafone South 53.99
Limited
2
211 Maharashtra
Bharti Airtel- Limited
011 Maharashtra
Idea Cellular- Ltd.
011 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
11 Maharashtra
Videocon Telecommunications
Limited.
011 Maharashtra
Vodafone South262.81
Limited
1
2 yes
11 Mumbai Bharti Airtel- Limited
011 Mumbai Idea Cellular- Ltd.
011 Mumbai Telewings Communications
Services
0 - Private Limited.
11 Mumbai Videocon Telecommunications
Limited.
011 Mumbai Vodafone South
Limited
011 North East Bharti Airtel- Limited
011 North East Idea Cellular Ltd. 8.84
4
1 yes
11 North East Telewings Communications
Services
0 - Private Limited.
11 North East Videocon Telecommunications
Limited.
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 33 -->

11 North East Vodafone South Limited
8.84
2
211 Orissa
Bharti Airtel- Limited
011 Orissa
Idea Cellular Ltd.20.27
4
1 yes
11 Orissa
Telewings Communications
Services
0 - Private Limited.
11 Orissa
Videocon Telecommunications
Limited.
011 Orissa
Vodafone South 20.27
Limited
2
211 Punjab
Bharti Airtel- Limited
011 Punjab
Idea Cellular- Ltd.
011 Punjab
Telewings Communications
Services
0 - Private Limited.
11 Punjab
Videocon Telecommunications
Limited.
011 Punjab
Vodafone South 67.28
Limited
1
1 yes
11 Rajasthan Bharti Airtel- Limited
011 Rajasthan Idea Cellular- Ltd.
011 Rajasthan Telewings Communications
Services
0 - Private Limited.
11 Rajasthan Videocon Telecommunications
Limited.
011 Rajasthan Vodafone South
Limited
011 Tamil NaduBharti Airtel- Limited
011 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
11 Tamil NaduTelewings Communications
Services
0 - Private Limited.
11 Tamil NaduVideocon Telecommunications
Limited.
011 Tamil NaduVodafone South
Limited
011 Uttar Pradesh
Bharti
(East)
Airtel- Limited
011 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
011 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
11 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
11 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
11 Uttar Pradesh
Bharti
(West)
Airtel- Limited
011 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
011 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
11 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
11 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
11 West BengalBharti Airtel- Limited
011 West BengalIdea Cellular Ltd.25.84
4
1 yes
11 West BengalTelewings Communications
Services
0 - Private Limited.
11 West BengalVideocon Telecommunications
Limited.
011 West BengalVodafone South 25.84
Limited
2
212 Andhra Pradesh
Bharti Airtel- Limited
012 Andhra Pradesh
Idea Cellular- Ltd.
012 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
12 Andhra Pradesh
Videocon Telecommunications
Limited.
012 Andhra Pradesh
Vodafone South
Limited
012 Assam
Bharti Airtel Limited
8.67
1
1 yes
12 Assam
Idea Cellular Ltd. 8.67
4
2 yes
12 Assam
Telewings Communications
Services
0 - Private Limited.
12 Assam
Videocon Telecommunications
Limited.
012 Assam
Vodafone South Limited
8.67
2
312 Bihar
Bharti Airtel- Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 34 -->

12 Bihar
Idea Cellular Ltd.44.65
2
3 yes
12 Bihar
Telewings Communications
46.43
Services
4 Private 2Limited.
yes
12 Bihar
Videocon Telecommunications
44.65
Limited.
0
412 Bihar
Vodafone South 46.43
Limited
2
112 Delhi
Bharti Airtel- Limited
012 Delhi
Idea Cellular- Ltd.
012 Delhi
Telewings Communications
Services
0 - Private Limited.
12 Delhi
Videocon Telecommunications
Limited.
012 Delhi
Vodafone South
Limited
012 Gujarat
Bharti Airtel- Limited
012 Gujarat
Idea Cellular- Ltd.
012 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
12 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
12 Gujarat
Vodafone South
Limited
012 Haryana Bharti Airtel- Limited
012 Haryana Idea Cellular- Ltd.
012 Haryana Telewings Communications
Services
0 - Private Limited.
12 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
12 Haryana Vodafone South 46.52
Limited
2
212 Himachal Pradesh
Bharti Airtel- Limited
012 Himachal Pradesh
Idea Cellular- Ltd.
012 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
12 Himachal Pradesh
Videocon Telecommunications
Limited.
012 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
12 Jammu & Kashmir
Bharti Airtel- Limited
012 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
12 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
12 Jammu & Kashmir
Videocon Telecommunications
Limited.
012 Jammu & Kashmir
Vodafone South Limited
6.33
2
112 Karnataka Bharti Airtel- Limited
012 Karnataka Idea Cellular- Ltd.
012 Karnataka Telewings Communications
Services
0 - Private Limited.
12 Karnataka Videocon Telecommunications
Limited.
012 Karnataka Vodafone South
Limited
012 Kerala
Bharti Airtel- Limited
012 Kerala
Idea Cellular- Ltd.
012 Kerala
Telewings Communications
Services
0 - Private Limited.
12 Kerala
Videocon Telecommunications
Limited.
012 Kerala
Vodafone South Limited
65.3
1
1 yes
12 Kolkata
Bharti Airtel- Limited
012 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
12 Kolkata
Telewings Communications
Services
0 - Private Limited.
12 Kolkata
Videocon Telecommunications
Limited.
012 Kolkata
Vodafone South
Limited
012 Madhya Pradesh
Bharti Airtel- Limited
012 Madhya Pradesh
Idea Cellular- Ltd.
012 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
-

Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 35 -->

12 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
12 Madhya Pradesh
Vodafone South 53.99
Limited
2
212 Maharashtra
Bharti Airtel- Limited
012 Maharashtra
Idea Cellular- Ltd.
012 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
12 Maharashtra
Videocon Telecommunications
Limited.
012 Maharashtra
Vodafone South262.81
Limited
1
2 yes
12 Mumbai Bharti Airtel- Limited
012 Mumbai Idea Cellular- Ltd.
012 Mumbai Telewings Communications
Services
0 - Private Limited.
12 Mumbai Videocon Telecommunications
Limited.
012 Mumbai Vodafone South
Limited
012 North East Bharti Airtel- Limited
012 North East Idea Cellular Ltd. 8.84
4
1 yes
12 North East Telewings Communications
Services
0 - Private Limited.
12 North East Videocon Telecommunications
Limited.
012 North East Vodafone South Limited
8.84
2
212 Orissa
Bharti Airtel- Limited
012 Orissa
Idea Cellular Ltd.20.27
4
1 yes
12 Orissa
Telewings Communications
Services
0 - Private Limited.
12 Orissa
Videocon Telecommunications
Limited.
012 Orissa
Vodafone South 20.27
Limited
2
212 Punjab
Bharti Airtel- Limited
012 Punjab
Idea Cellular- Ltd.
012 Punjab
Telewings Communications
Services
0 - Private Limited.
12 Punjab
Videocon Telecommunications
Limited.
012 Punjab
Vodafone South 67.28
Limited
1
1 yes
12 Rajasthan Bharti Airtel- Limited
012 Rajasthan Idea Cellular- Ltd.
012 Rajasthan Telewings Communications
Services
0 - Private Limited.
12 Rajasthan Videocon Telecommunications
Limited.
012 Rajasthan Vodafone South
Limited
012 Tamil NaduBharti Airtel- Limited
012 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
12 Tamil NaduTelewings Communications
Services
0 - Private Limited.
12 Tamil NaduVideocon Telecommunications
Limited.
012 Tamil NaduVodafone South
Limited
012 Uttar Pradesh
Bharti
(East)
Airtel- Limited
012 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
012 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
12 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
12 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
12 Uttar Pradesh
Bharti
(West)
Airtel- Limited
012 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
012 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
12 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
12 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 36 -->

12 West BengalBharti Airtel- Limited
012 West BengalIdea Cellular Ltd.25.84
4
1 yes
12 West BengalTelewings Communications
Services
0 - Private Limited.
12 West BengalVideocon Telecommunications
Limited.
012 West BengalVodafone South 25.84
Limited
2
213 Andhra Pradesh
Bharti Airtel- Limited
013 Andhra Pradesh
Idea Cellular- Ltd.
013 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
13 Andhra Pradesh
Videocon Telecommunications
Limited.
013 Andhra Pradesh
Vodafone South
Limited
013 Assam
Bharti Airtel Limited
8.67
1
1 yes
13 Assam
Idea Cellular Ltd. 8.67
4
2 yes
13 Assam
Telewings Communications
Services
0 - Private Limited.
13 Assam
Videocon Telecommunications
Limited.
013 Assam
Vodafone South Limited
8.67
2
313 Bihar
Bharti Airtel- Limited
013 Bihar
Idea Cellular Ltd.44.65
013 Bihar
Telewings Communications
46.43
Services
4 Private 3Limited.
yes
13 Bihar
Videocon Telecommunications
46.43
Limited.
4
1 yes
13 Bihar
Vodafone South 46.43
Limited
2
2 yes
13 Delhi
Bharti Airtel- Limited
013 Delhi
Idea Cellular- Ltd.
013 Delhi
Telewings Communications
Services
0 - Private Limited.
13 Delhi
Videocon Telecommunications
Limited.
013 Delhi
Vodafone South
Limited
013 Gujarat
Bharti Airtel- Limited
013 Gujarat
Idea Cellular- Ltd.
013 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
13 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
13 Gujarat
Vodafone South
Limited
013 Haryana Bharti Airtel- Limited
013 Haryana Idea Cellular- Ltd.
013 Haryana Telewings Communications
Services
0 - Private Limited.
13 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
13 Haryana Vodafone South 46.52
Limited
2
213 Himachal Pradesh
Bharti Airtel- Limited
013 Himachal Pradesh
Idea Cellular- Ltd.
013 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
13 Himachal Pradesh
Videocon Telecommunications
Limited.
013 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
13 Jammu & Kashmir
Bharti Airtel- Limited
013 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
13 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
13 Jammu & Kashmir
Videocon Telecommunications
Limited.
013 Jammu & Kashmir
Vodafone South Limited
6.33
2
113 Karnataka Bharti Airtel- Limited
013 Karnataka Idea Cellular- Ltd.
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 37 -->

13 Karnataka Telewings Communications
Services
0 - Private Limited.
13 Karnataka Videocon Telecommunications
Limited.
013 Karnataka Vodafone South
Limited
013 Kerala
Bharti Airtel- Limited
013 Kerala
Idea Cellular- Ltd.
013 Kerala
Telewings Communications
Services
0 - Private Limited.
13 Kerala
Videocon Telecommunications
Limited.
013 Kerala
Vodafone South Limited
65.3
1
1 yes
13 Kolkata
Bharti Airtel- Limited
013 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
13 Kolkata
Telewings Communications
Services
0 - Private Limited.
13 Kolkata
Videocon Telecommunications
Limited.
013 Kolkata
Vodafone South
Limited
013 Madhya Pradesh
Bharti Airtel- Limited
013 Madhya Pradesh
Idea Cellular- Ltd.
013 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
13 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
13 Madhya Pradesh
Vodafone South 53.99
Limited
2
213 Maharashtra
Bharti Airtel- Limited
013 Maharashtra
Idea Cellular- Ltd.
013 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
13 Maharashtra
Videocon Telecommunications
Limited.
013 Maharashtra
Vodafone South262.81
Limited
1
2 yes
13 Mumbai Bharti Airtel- Limited
013 Mumbai Idea Cellular- Ltd.
013 Mumbai Telewings Communications
Services
0 - Private Limited.
13 Mumbai Videocon Telecommunications
Limited.
013 Mumbai Vodafone South
Limited
013 North East Bharti Airtel- Limited
013 North East Idea Cellular Ltd. 8.84
4
1 yes
13 North East Telewings Communications
Services
0 - Private Limited.
13 North East Videocon Telecommunications
Limited.
013 North East Vodafone South Limited
8.84
2
213 Orissa
Bharti Airtel- Limited
013 Orissa
Idea Cellular Ltd.20.27
4
1 yes
13 Orissa
Telewings Communications
Services
0 - Private Limited.
13 Orissa
Videocon Telecommunications
Limited.
013 Orissa
Vodafone South 20.27
Limited
2
213 Punjab
Bharti Airtel- Limited
013 Punjab
Idea Cellular- Ltd.
013 Punjab
Telewings Communications
Services
0 - Private Limited.
13 Punjab
Videocon Telecommunications
Limited.
013 Punjab
Vodafone South 67.28
Limited
1
1 yes
13 Rajasthan Bharti Airtel- Limited
013 Rajasthan Idea Cellular- Ltd.
013 Rajasthan Telewings Communications
Services
0 - Private Limited.
13 Rajasthan Videocon Telecommunications
Limited.
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 38 -->

13 Rajasthan Vodafone South
Limited
013 Tamil NaduBharti Airtel- Limited
013 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
13 Tamil NaduTelewings Communications
Services
0 - Private Limited.
13 Tamil NaduVideocon Telecommunications
Limited.
013 Tamil NaduVodafone South
Limited
013 Uttar Pradesh
Bharti
(East)
Airtel- Limited
013 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
013 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
13 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
13 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
13 Uttar Pradesh
Bharti
(West)
Airtel- Limited
013 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
013 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
13 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
13 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
13 West BengalBharti Airtel- Limited
013 West BengalIdea Cellular Ltd.25.84
4
1 yes
13 West BengalTelewings Communications
Services
0 - Private Limited.
13 West BengalVideocon Telecommunications
Limited.
013 West BengalVodafone South 25.84
Limited
2
214 Andhra Pradesh
Bharti Airtel- Limited
014 Andhra Pradesh
Idea Cellular- Ltd.
014 Andhra Pradesh
Telewings Communications
286.91
Services
4 Private 1Limited.
yes
14 Andhra Pradesh
Videocon Telecommunications
Limited.
014 Andhra Pradesh
Vodafone South
Limited
014 Assam
Bharti Airtel Limited
8.67
1
1 yes
14 Assam
Idea Cellular Ltd. 8.67
4
2 yes
14 Assam
Telewings Communications
Services
0 - Private Limited.
14 Assam
Videocon Telecommunications
Limited.
014 Assam
Vodafone South Limited
8.67
2
314 Bihar
Bharti Airtel- Limited
014 Bihar
Idea Cellular Ltd.47.35
1
1 yes
14 Bihar
Telewings Communications
46.43
Services
4 Private 4Limited.
yes
14 Bihar
Videocon Telecommunications
46.43
Limited.
4
2 yes
14 Bihar
Vodafone South 46.43
Limited
2
3 yes
14 Delhi
Bharti Airtel- Limited
014 Delhi
Idea Cellular- Ltd.
014 Delhi
Telewings Communications
Services
0 - Private Limited.
14 Delhi
Videocon Telecommunications
Limited.
014 Delhi
Vodafone South
Limited
014 Gujarat
Bharti Airtel- Limited
014 Gujarat
Idea Cellular- Ltd.
014 Gujarat
Telewings Communications
224.84
Services
4 Private 1Limited.
yes
14 Gujarat
Videocon Telecommunications
224.84
Limited.
4
2 yes
14 Gujarat
Vodafone South
Limited
014 Haryana Bharti Airtel- Limited
0-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
5
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 39 -->

14 Haryana Idea Cellular- Ltd.
014 Haryana Telewings Communications
Services
0 - Private Limited.
14 Haryana Videocon Telecommunications
46.52
Limited.
4
1 yes
14 Haryana Vodafone South 46.52
Limited
2
214 Himachal Pradesh
Bharti Airtel- Limited
014 Himachal Pradesh
Idea Cellular- Ltd.
014 Himachal Pradesh
Telewings Communications
Services
0 - Private Limited.
14 Himachal Pradesh
Videocon Telecommunications
Limited.
014 Himachal Pradesh
Vodafone South Limited
7.78
1
1 yes
14 Jammu & Kashmir
Bharti Airtel- Limited
014 Jammu & Kashmir
Idea Cellular Ltd. 6.33
4
2 yes
14 Jammu & Kashmir
Telewings Communications
Services
0 - Private Limited.
14 Jammu & Kashmir
Videocon Telecommunications
Limited.
014 Jammu & Kashmir
Vodafone South Limited
6.33
2
114 Karnataka Bharti Airtel- Limited
014 Karnataka Idea Cellular- Ltd.
014 Karnataka Telewings Communications
Services
0 - Private Limited.
14 Karnataka Videocon Telecommunications
Limited.
014 Karnataka Vodafone South
Limited
014 Kerala
Bharti Airtel- Limited
014 Kerala
Idea Cellular- Ltd.
014 Kerala
Telewings Communications
Services
0 - Private Limited.
14 Kerala
Videocon Telecommunications
Limited.
014 Kerala
Vodafone South Limited
65.3
1
1 yes
14 Kolkata
Bharti Airtel- Limited
014 Kolkata
Idea Cellular Ltd.
113.72
4
1 yes
14 Kolkata
Telewings Communications
Services
0 - Private Limited.
14 Kolkata
Videocon Telecommunications
Limited.
014 Kolkata
Vodafone South
Limited
014 Madhya Pradesh
Bharti Airtel- Limited
014 Madhya Pradesh
Idea Cellular- Ltd.
014 Madhya Pradesh
Telewings Communications
Services
0 - Private Limited.
14 Madhya Pradesh
Videocon Telecommunications
53.99
Limited.
4
1 yes
14 Madhya Pradesh
Vodafone South 53.99
Limited
2
214 Maharashtra
Bharti Airtel- Limited
014 Maharashtra
Idea Cellular- Ltd.
014 Maharashtra
Telewings Communications
262.81
Services
4 Private 1Limited.
yes
14 Maharashtra
Videocon Telecommunications
Limited.
014 Maharashtra
Vodafone South262.81
Limited
1
2 yes
14 Mumbai Bharti Airtel- Limited
014 Mumbai Idea Cellular- Ltd.
014 Mumbai Telewings Communications
Services
0 - Private Limited.
14 Mumbai Videocon Telecommunications
Limited.
014 Mumbai Vodafone South
Limited
014 North East Bharti Airtel- Limited
014 North East Idea Cellular Ltd. 8.84
4
1 yes
14 North East Telewings Communications
Services
0 - Private Limited.
-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 40 -->

14 North East Videocon Telecommunications
Limited.
014 North East Vodafone South Limited
8.84
2
214 Orissa
Bharti Airtel- Limited
014 Orissa
Idea Cellular Ltd.20.27
4
1 yes
14 Orissa
Telewings Communications
Services
0 - Private Limited.
14 Orissa
Videocon Telecommunications
Limited.
014 Orissa
Vodafone South 20.27
Limited
2
214 Punjab
Bharti Airtel- Limited
014 Punjab
Idea Cellular- Ltd.
014 Punjab
Telewings Communications
Services
0 - Private Limited.
14 Punjab
Videocon Telecommunications
Limited.
014 Punjab
Vodafone South 67.28
Limited
1
1 yes
14 Rajasthan Bharti Airtel- Limited
014 Rajasthan Idea Cellular- Ltd.
014 Rajasthan Telewings Communications
Services
0 - Private Limited.
14 Rajasthan Videocon Telecommunications
Limited.
014 Rajasthan Vodafone South
Limited
014 Tamil NaduBharti Airtel- Limited
014 Tamil NaduIdea Cellular Ltd.
306.09
4
1 yes
14 Tamil NaduTelewings Communications
Services
0 - Private Limited.
14 Tamil NaduVideocon Telecommunications
Limited.
014 Tamil NaduVodafone South
Limited
014 Uttar Pradesh
Bharti
(East)
Airtel- Limited
014 Uttar Pradesh
Idea
(East)
Cellular- Ltd.
014 Uttar Pradesh
Telewings
(East) Communications
76.17
Services
4 Private 2Limited.
yes
14 Uttar Pradesh
Videocon
(East) Telecommunications
76.17
Limited.
4
3 yes
14 Uttar Pradesh
Vodafone
(East) South 76.93
Limited
1
1 yes
14 Uttar Pradesh
Bharti
(West)
Airtel- Limited
014 Uttar Pradesh
Idea
(West)
Cellular- Ltd.
014 Uttar Pradesh
Telewings
(West) Communications
107.41
Services
4 Private 3Limited.
yes
14 Uttar Pradesh
Videocon
(West) Telecommunications
107.41
Limited.
4
2 yes
14 Uttar Pradesh
Vodafone
(West) South107.41
Limited
2
1 yes
14 West BengalBharti Airtel- Limited
014 West BengalIdea Cellular Ltd.25.84
5
114 West BengalTelewings Communications
Services
0 - Private Limited.
14 West BengalVideocon Telecommunications
Limited.
014 West BengalVodafone South 25.84
Limited
2
2-

Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid
Not Bid

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

<!-- page 41 -->

Provisional Winning
Provisionally
BidRank
at
Allocated
end
of of
Provisional
Clock
Provisional
Blocks
Round
atWinning
end
Winning
(Per
of Clock
Block)(Rs.
Bid Price
atRound
endatCrore)
ofthe
Clock
endRound
of Clock round (Per Block)(Rs. In Crore)
286.91
286.91
286.91
4
1
286.91
286.91
286.91
8.67
1
1
8.67
8.67
4
2
8.67
8.67
8.67
8.67
2
3
8.67
42.51
42.51
1
1
42.51
42.51
42.51
4
3
42.51
42.51
2
2
42.51
0
0
0
0
0
224.84
224.84
224.84
4
1
224.84
224.84
4
2
224.84
224.84
46.52
46.52
46.52
46.52
4
1
46.52
46.52
2
2
46.52
7.78
7.78
7.78
7.78
7.78
1
1
7.78
6.33
6.33
4
2
6.33
6.33
6.33
6.33
2
1
6.33
0
0
0
0
0
65.3

<!-- page 42 -->

-

65.3

-

1
-

113.72
-

-

-

4
2

262.81

4

8.84

4

8.84

2

20.27

4

20.27

1
-

2
-

67.28
-

2
-

-

-

1
-

-

-

1
-

-

-

1
2
-

-

-

1
-

-

-

1
-

4

53.99
53.99

2
-

1
-

306.09
-

-

1
-

4
-

1
-

65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09

<!-- page 43 -->

-

76.17
76.17
76.17

-

4
4
0

107.41
107.41

-

4
2

25.84

-

4

25.84

2

286.91

4

8.67
8.67

1
4

8.67

-

-

42.51
42.51

-

4
2

224.84
224.84

3
2
-

4
4
-

46.52
46.52

1
-

-

-

3

1
-

-

1
2

2

42.51
-

1
-

-

-

2
-

-

-

1
-

-

-

2
1
-

-

-

1
2
3

1
2
-

4
2

1
2

306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
42.51
42.51
42.51
42.51
42.51
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52

<!-- page 44 -->

-

7.78

-

1

6.33

-

4

6.33

-

2

65.3

1

113.72

4

53.99
53.99

4
2

262.81

4

8.84

4

8.84

1
-

2
-

20.27

1
-

-

-

1
2
-

-

-

1
-

-

-

1
-

-

-

1
-

-

-

2
-

-

-

1

2
-

4

1

7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27

<!-- page 45 -->

-

20.27

-

2

67.28

-

1

306.09

-

4

76.17
76.17
76.93

4
4
1

107.41
107.41

4
2

25.84

4

25.84

2

286.91

4

8.67
8.67

1
4

8.67

2

42.51

3
-

1
-

42.51

1
2
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2
1
-

-

-

2
3
1
-

-

-

1
-

-

-

1
-

-

-

2

1
-

4

3

20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
42.51
42.51
42.51
42.51

<!-- page 46 -->

42.51
-

2
-

224.84
224.84
-

4
4
-

46.52
46.52
-

4
2

7.78

1

6.33

4

6.33

2

65.3
-

1
-

4
-

53.99
53.99
-

1
-

1

113.72
-

2
-

-

-

1
-

-

-

1
2
-

-

-

1
2
-

-

-

2
-

1
-

4
2
-

1
2
-

42.51
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81

<!-- page 47 -->

-

262.81

-

8.84

-

-

-

-

-

-

20.27

-

2

67.28

1

306.09

4

76.17
76.17
76.93

1
-

4
4
1
-

107.41
107.41
-

1
-

-

-

2
-

-

-

1
-

-

-

2

4
-

-

1

2

20.27
-

1

4

8.84

2
3
1
-

4
2
-

25.84
-

4

2
1
-

4
-

1
-

262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84

<!-- page 48 -->

-

25.84

-

286.91

-

-

-

-

1
4

8.67

2

42.51
-

224.84
224.84

-

4
4

46.52
46.52

4
2

7.78

1
2
-

1
-

6.33
-

1
2
-

-

-

3
2
-

-

-

1

4
2
-

-

3
-

1

42.51
42.51
-

1
2
-

-

-

1
-

-

-

2

4

8.67
8.67

1
-

4
-

6.33
-

2

2
-

2
-

1
-

25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
42.51
42.51
42.51
42.51
42.51
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0

<!-- page 49 -->

-

65.3

-

1

113.72

-

4

53.99
53.99

-

4
2

262.81

4

262.81

1

8.84

4

8.84

-

-

20.27

-

2

67.28

2
-

1
-

306.09

1
-

-

-

2

4
-

-

1

2

20.27
-

2
-

-

-

1
-

-

-

1
2
-

-

-

1
-

-

-

1

1
-

4

1

65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09

<!-- page 50 -->

-

76.17
76.17
76.93

-

4
4
1

107.41
107.41
107.41

-

4
4
2

25.84

-

4

25.84

2

286.91

4

8.67
8.67

1
4

8.67

2

42.51
42.51
42.51
42.51

2
0
4
2

224.84
224.84

1
4
3
2
-

4
4
-

46.52

3
-

-

-

1
2
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

3
2
1
-

-

-

2
3
1

1
2
-

4

1

306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
42.51
42.51
42.51
42.51
42.51
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52

<!-- page 51 -->

46.52
-

2
-

7.78
-

1
-

6.33
6.33

-

1

113.72

4

53.99
53.99

4
2

262.81

4

262.81

1
-

1
-

8.84
-

1
2
-

-

-

1
-

-

-

1
-

-

-

1
-

-

-

2

2

65.3

2
-

4
-

8.84
-

-

-

-

1

4
-

-

2
-

1
-

2
-

2
-

46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27

<!-- page 52 -->

20.27
-

4
-

20.27
-

2
-

67.28
-

1

306.09

4

76.17
76.17
76.93

4
4
1

107.41
107.41
107.41

4
4
2

25.84

4

25.84

2

286.91

4

8.67
8.67

1
4

8.67

1
2
-

2
-

42.51
44.21

1
-

-

-

2
-

-

-

1
-

-

-

3
2
1
-

-

-

2
3
1
-

-

-

1
-

-

-

1
-

-

-

2
-

-

-

1
-

3
-

2
4

2
1

20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
42.51
42.51
42.51

<!-- page 53 -->

42.51
42.51
-

0
2
-

224.84
224.84
-

4
4

46.52
46.52

-

4
2

7.78

-

-

6.33

-

2

65.3

1

113.72

1
-

4
-

53.99
53.99

1
-

-

-

2
-

-

-

1

4
-

-

1
2

1

6.33
-

1
2
-

-

-

4
3

1
-

4
2

1
2

42.51
42.51
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99

<!-- page 54 -->

-

262.81

-

4

262.81

-

1

8.84

-

4

8.84

2

20.27

4

20.27

2

67.28

1

306.09

4

76.17
76.17
76.93

4
4
1

107.41
107.41
107.41

2
3
1
-

4
4
2
-

25.84

1
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2
-

-

-

1

3
2
1
-

4

1

262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84

<!-- page 55 -->

-

25.84

-

2
-

286.91
-

-

-

1
-

1
4
-

8.67

-

-

-

-

2

4

8.67
8.67

-

-

42.51 44.21
44.21
42.51 224.84
224.84
46.52
46.52
7.78
6.33
6.33
-

1
2
-

2

3
-

4
4

2
1
-

4
4

1
2
-

4
2

1
2
-

1

1
-

4

2
-

2

1
-

25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
44.21
44.21
44.21
44.21
44.21
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0

<!-- page 56 -->

-

65.3

-

1
-

113.72
-

-

-

-

4
2

262.81

-

-

8.84

-

4

8.84

2

20.27

2
-

4
-

20.27
-

1
-

-

-

2
-

-

-

1

1
-

-

1
2

4

262.81
-

1
-

-

-

1

4

53.99
53.99

1
-

2
-

67.28
-

-

2
-

1
-

1
-

0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09

<!-- page 57 -->

306.09
-

4
-

76.17
76.17
76.93
-

4
4
1
-

107.41
107.41
107.41
-

-

2

286.91

4

8.67
8.67

1
4

8.67

1
2
-

2
-

44.65
44.21
44.21
44.65
-

1
-

-

-

2
-

-

-

1
-

-

-

3
2
1

4

25.84

3
-

2
0
4
2
-

224.84
224.84
-

-

-

-

2
3
1

4
4
2

25.84
-

1
-

1
4
3
2
-

4
4
-

1
2
-

306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
44.21
44.21
44.21
44.21
44.21
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52

<!-- page 58 -->

46.52
46.52
-

4
2
-

7.78
-

1

6.33

-

4

6.33

2

65.3
-

53.99
53.99

-

4
2

262.81

4

262.81

1

8.84

2
-

4
-

8.84

1
-

-

-

1
2
-

-

-

1
-

-

-

1

4
-

-

1
-

1

113.72
-

2
-

-

-

1
-

-

-

1
2

1
-

2

2

46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84

<!-- page 59 -->

-

20.27

-

4

20.27

-

2

67.28

-

1

306.09

4

76.17
76.17
76.93

4
4
1

107.41
107.41
107.41

-

-

25.84

-

2

286.91

4

8.67
8.67

1
4

8.67

1
2
-

2
-

44.65

1
-

-

-

2
-

-

-

1
-

-

-

3
2
1

4
-

-

2
3
1

4
4
2

25.84
-

1
-

-

-

1
-

-

-

2
-

-

-

1

3
-

2

1

20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
44.65
44.65

<!-- page 60 -->

44.65
44.65
44.65
-

0
4
2
-

224.84
224.84
-

4
4

46.52
46.52

-

4
2

7.78

1

6.33

4

6.33

2

65.3
-

1
-

4
-

53.99

1
-

1

113.72
-

2
-

-

-

1
-

-

-

1
2
-

-

-

1
2
-

-

-

4
2
3

1
-

4

1

44.65
44.65
44.65
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99

<!-- page 61 -->

53.99
-

2
-

262.81
-

4
-

262.81
-

1

8.84

4

8.84

2

20.27

4

20.27

2

67.28

1

306.09

4

76.17
76.17
76.93

1
-

4
4
1
-

107.41
107.41
107.41
-

1
-

-

-

2
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2
-

2
3
1
-

4
4
2
-

3
2
1
-

53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84

<!-- page 62 -->

25.84
-

4
-

25.84
-

2
-

286.91
-

4

8.67
8.67

1
4

8.67

-

4
4

46.52
46.52

4
2

7.78

1
2
-

1
-

6.33
-

1
2
-

-

-

2
1
3
4
-

-

-

3

2
4
4
0

224.84
224.84

1
-

4
-

6.33
-

-

-

-

1
2

2

44.65
46.43
44.65
44.65
-

1
-

-

-

2
-

-

-

1
-

2
-

2
-

1
-

25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
44.65
44.65
44.65
44.65
44.65
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0

<!-- page 63 -->

-

65.3

-

1
-

113.72
-

-

-

4
2

262.81

4

262.81

1

8.84

4

8.84

2

20.27

2
-

4
-

20.27
-

1
-

-

-

2
-

-

-

1
-

-

-

1
2
-

-

-

1
-

-

-

1
-

4

53.99
53.99

1
-

2
-

67.28
-

-

2
-

1
-

1
-

0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0

<!-- page 64 -->

-

306.09

-

76.17
76.17
76.93

-

-

-

-

4
4
2

25.84

4

25.84

2

286.91

4

8.67
8.67

1
4

8.67

1
2
-

2
-

44.65
46.43
44.65
46.43
-

1
-

-

-

2
-

-

-

1
-

-

-

3
2
1
-

-

-

2
3
1
-

-

-

1

4
4
1

107.41
107.41
107.41

3
-

2
4
0
2
-

224.84
224.84
-

4

3
2
4
1
-

4
4
-

1
2
-

306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
44.65
44.65
44.65
44.65
44.65
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52

<!-- page 65 -->

-

46.52
46.52

-

7.78

-

1

6.33

4

6.33

2

65.3

1

113.72

4

53.99
53.99

4
2

262.81

1
2
-

4
-

262.81
-

1
-

-

-

1
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

1
2
-

-

-

1
-

1
-

8.84
-

4
2

2
-

4
-

1
-

46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84

<!-- page 66 -->

8.84
-

2
-

20.27
-

4
-

20.27
-

2

67.28

1

306.09

4

76.17
76.17
76.93

4
4
1

107.41
107.41
107.41

4
4
2

25.84

4

25.84

2

286.91

4

8.67
8.67

1
-

1
4
-

8.67
-

2
-

-

-

1
-

-

-

3
2
1
-

-

-

2
3
1
-

-

-

1
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2
-

1
2
-

2
-

3
-

8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
46.43

<!-- page 67 -->

-

-

-

44.65 46.43
46.43
46.43
224.84
224.84
46.52
46.52
7.78
6.33
6.33
65.3
113.72
-

4
4
2

3
1
2
-

4
4

1
2
-

4
2

1
2
-

1

1
-

4

2
-

2

1
-

1

1
-

4

1
-

46.43
46.43
46.43
46.43
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99

<!-- page 68 -->

53.99
53.99
-

4
2
-

262.81
-

4

262.81

-

1

8.84

4

8.84

-

-

20.27

-

2

67.28

1

306.09

4

76.17
76.17
76.93

1
-

4
4
1
-

107.41
107.41
107.41

1
-

-

-

2
-

-

-

1
-

-

-

2

4
-

-

1

2

20.27
-

2
-

-

-

1
-

-

-

1
2

2
3
1
-

4
4
2

3
2
1

53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41

<!-- page 69 -->

-

25.84

-

25.84

-

-

-

-

4

8.67
8.67

1
4

8.67

2

47.35
46.43
46.43
46.43

1
4
4
2

224.84
224.84

4
4

46.52
46.52

4
2

7.78

1
2
-

1
-

6.33
-

1
2
-

-

-

1
4
2
3
-

-

-

3
-

-

-

1
2
-

-

-

1
-

-

-

2
-

-

-

1

2

286.91

1
-

4
-

6.33
-

4

2
-

2
-

1
-

25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
46.43
46.43
46.43
46.43
46.43
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52
46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0

<!-- page 70 -->

-

65.3

-

1
-

113.72
-

-

4

4
2

262.81

4

262.81

1

8.84

4

8.84

-

-

2
-

4
-

20.27
-

1

2

20.27
-

2
-

-

-

1
-

-

-

1
2
-

-

-

1
-

-

-

1
-

53.99
53.99

1
-

2
-

67.28
-

-

2
-

1
-

1
-

0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84
8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0

<!-- page 71 -->

-

306.09

-

4
-

76.17
76.17
76.93
-

-

-

-

4
4
2

25.84

5

25.84

2

286.91

4

8.67
8.67

1
4

8.67

1
2
-

2
-

47.35
46.43
46.43
46.43
-

1
-

-

-

2
-

-

-

1
-

-

-

3
2
1
-

-

-

2
3
1
-

-

-

1

4
4
1

107.41
107.41
107.41

3
-

1
4
4
2
-

224.84
224.84
-

-

1
4
2
3
-

4
4
-

1
2
-

0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84
286.91
286.91
286.91
286.91
286.91
8.67
8.67
8.67
8.67
8.67
46.43
46.43
46.43
46.43
46.43
0
0
0
0
0
224.84
224.84
224.84
224.84
224.84
46.52

<!-- page 72 -->

-

46.52
46.52

-

4
2
-

7.78
-

-

-

6.33

-

2

65.3

1

113.72

4

53.99
53.99

4
2

262.81

1
2
-

4
-

262.81
-

1
-

-

-

1
-

-

-

1
-

-

-

2
-

-

-

1

4
-

-

1
2

1

6.33

1
-

1
-

8.84
-

-

2
-

4
-

1
-

46.52
46.52
46.52
46.52
7.78
7.78
7.78
7.78
7.78
6.33
6.33
6.33
6.33
6.33
0
0
0
0
0
65.3
65.3
65.3
65.3
65.3
113.72
113.72
113.72
113.72
113.72
53.99
53.99
53.99
53.99
53.99
262.81
262.81
262.81
262.81
262.81
0
0
0
0
0
8.84
8.84
8.84

<!-- page 73 -->

-

8.84

-

2

20.27

-

4

20.27

-

2

67.28

1

306.09

4

76.17
76.17
76.93

4
4
1

107.41
107.41
107.41

4
4
2

25.84

3
2
1
-

5
-

25.84

2
3
1
-

-

-

1
-

-

-

1
-

-

-

2
-

-

-

1
-

-

-

2

1
-

2

2

8.84
8.84
20.27
20.27
20.27
20.27
20.27
67.28
67.28
67.28
67.28
67.28
0
0
0
0
0
306.09
306.09
306.09
306.09
306.09
76.17
76.17
76.17
76.17
76.17
107.41
107.41
107.41
107.41
107.41
25.84
25.84
25.84
25.84
25.84

<!-- page 74 -->

Block)(Rs. In Crore)

<!-- page 75 -->

Clock RoundService AreaBidder
New EntrantClock RoundBid
in amount
which Bid
Clock
(Rs.
was
Crore)
Round
submitted
Random
No. in which
indexthe
assigned
bid was
to submitted
Bid
first tim
1 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited. 1 1.18E+09
1 Assam
Bharti AirtelNo
Limited
1
8.67
1 5.62E+08
1 Assam
Idea CellularYes
Ltd.
1
8.67
1 1.25E+09
1 Assam
Vodafone South
No Limited
1
8.67
1 1.89E+09
1 Bihar
Idea CellularNo
Ltd.
1
42.51
1 1.24E+09
1 Bihar
Vodafone South
No Limited
1
42.51
1 1.29E+09
1 Bihar
Videocon Telecommunications
Yes
Limited.
1
42.51
1 1.95E+09
1 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited. 1 1.13E+09
1 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
1 1.55E+09
1 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
1 5.96E+08
1 Haryana Vodafone South
No Limited
1
46.52
1 7.25E+08
1 Himachal Pradesh
Vodafone South
No Limited
1
7.78
1 7.02E+08
1 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
1 5.26E+08
1 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
1 1.04E+09
1 Kerala
Vodafone South
No Limited
1
65.3
1 12211783
1 Kolkata
Idea CellularYes
Ltd.
1
113.72
1 8.69E+08
1 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
1 5.26E+08
1 Madhya Pradesh
Vodafone South
No Limited
1
53.99
1 1.03E+09
1 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited. 1 1.05E+09
1 North East Idea CellularYes
Ltd.
1
8.84
1 4.9E+08
1 North East Vodafone South
No Limited
1
8.84
1 2.08E+09
1 Orissa
Idea CellularYes
Ltd.
1
20.27
1 8.97E+08
1 Orissa
Vodafone South
No Limited
1
20.27
1 9.39E+08
1 Punjab
Vodafone South
No Limited
1
67.28
1 5.67E+08
1 Tamil NaduIdea CellularYes
Ltd.
1
306.09
1 8.89E+08
1 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited. 1 2.3E+08
1 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
1 5.74E+08
1 Uttar Pradesh
Vodafone
(East) South
No Limited
1
76.17
1 1.96E+09
1 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
1 6.47E+08
1 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
1 2.01E+09
1 West BengalIdea CellularYes
Ltd.
1
25.84
1 6.67E+08
1 West BengalVodafone South
No Limited
1
25.84
1 7.13E+08
2 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited. 1 1.18E+09
2 Assam
Bharti AirtelNo
Limited
1
8.67
1 5.62E+08
2 Assam
Idea CellularYes
Ltd.
1
8.67
1 1.25E+09
2 Assam
Vodafone South
No Limited
1
8.67
1 1.89E+09
2 Bihar
Idea CellularNo
Ltd.
1
42.51
1 1.24E+09
2 Bihar
Vodafone South
No Limited
1
42.51
1 1.29E+09
2 Bihar
Videocon Telecommunications
Yes
Limited.
1
42.51
1 1.95E+09
2 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited. 1 1.13E+09
2 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
1 1.55E+09
2 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
1 5.96E+08
2 Haryana Vodafone South
No Limited
1
46.52
1 7.25E+08
2 Himachal Pradesh
Vodafone South
No Limited
1
7.78
1 7.02E+08
2 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
1 5.26E+08
2 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
1 1.04E+09

<!-- page 76 -->

2 Kerala
Vodafone South
No Limited
1
65.3
2 Kolkata
Idea CellularYes
Ltd.
1
113.72
2 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
2 Madhya Pradesh
Vodafone South
No Limited
1
53.99
2 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
2 North East Idea CellularYes
Ltd.
1
8.84
2 North East Vodafone South
No Limited
1
8.84
2 Orissa
Idea CellularYes
Ltd.
1
20.27
2 Orissa
Vodafone South
No Limited
1
20.27
2 Punjab
Vodafone South
No Limited
1
67.28
2 Tamil NaduIdea CellularYes
Ltd.
1
306.09
2 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
2 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
2 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
2 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
2 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
2 West BengalIdea CellularYes
Ltd.
1
25.84
2 West BengalVodafone South
No Limited
1
25.84
3 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.
3 Assam
Bharti AirtelNo
Limited
1
8.67
3 Assam
Idea CellularYes
Ltd.
1
8.67
3 Assam
Vodafone South
No Limited
1
8.67
3 Bihar
Idea CellularNo
Ltd.
1
42.51
3 Bihar
Vodafone South
No Limited
1
42.51
3 Bihar
Videocon Telecommunications
Yes
Limited.
1
42.51
3 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
3 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
3 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
3 Haryana Vodafone South
No Limited
1
46.52
3 Himachal Pradesh
Vodafone South
No Limited
1
7.78
3 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
3 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
3 Kerala
Vodafone South
No Limited
1
65.3
3 Kolkata
Idea CellularYes
Ltd.
1
113.72
3 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
3 Madhya Pradesh
Vodafone South
No Limited
1
53.99
3 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
3 North East Idea CellularYes
Ltd.
1
8.84
3 North East Vodafone South
No Limited
1
8.84
3 Orissa
Idea CellularYes
Ltd.
1
20.27
3 Orissa
Vodafone South
No Limited
1
20.27
3 Punjab
Vodafone South
No Limited
1
67.28
3 Tamil NaduIdea CellularYes
Ltd.
1
306.09
3 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
3 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
3 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
3 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41

1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
1 4.9E+08
1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08
1 2.01E+09
1 6.67E+08
1 7.13E+08
1 1.18E+09
1 5.62E+08
1 1.25E+09
1 1.89E+09
1 1.24E+09
1 1.29E+09
1 1.95E+09
1 1.13E+09
1 1.55E+09
1 5.96E+08
1 7.25E+08
1 7.02E+08
1 5.26E+08
1 1.04E+09
1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
1 4.9E+08
1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08

<!-- page 77 -->

3 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
3 West BengalIdea CellularYes
Ltd.
1
25.84
3 West BengalVodafone South
No Limited
1
25.84
4 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.
4 Assam
Bharti AirtelNo
Limited
1
8.67
4 Assam
Idea CellularYes
Ltd.
1
8.67
4 Assam
Vodafone South
No Limited
1
8.67
4 Bihar
Idea CellularNo
Ltd.
1
42.51
4 Bihar
Vodafone South
No Limited
1
42.51
4 Bihar
Videocon Telecommunications
Yes
Limited.
1
42.51
4 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
4 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
4 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
4 Haryana Vodafone South
No Limited
1
46.52
4 Himachal Pradesh
Vodafone South
No Limited
1
7.78
4 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
4 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
4 Kerala
Vodafone South
No Limited
1
65.3
4 Kolkata
Idea CellularYes
Ltd.
1
113.72
4 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
4 Madhya Pradesh
Vodafone South
No Limited
1
53.99
4 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
4 Maharashtra
Vodafone South
No Limited
4
262.81
4 North East Idea CellularYes
Ltd.
1
8.84
4 North East Vodafone South
No Limited
1
8.84
4 Orissa
Idea CellularYes
Ltd.
1
20.27
4 Orissa
Vodafone South
No Limited
1
20.27
4 Punjab
Vodafone South
No Limited
1
67.28
4 Tamil NaduIdea CellularYes
Ltd.
1
306.09
4 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
4 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
4 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
4 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
4 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
4 Uttar Pradesh
Telewings
(West) Communications
Yes
Services
4 Private
107.41Limited.
4 West BengalIdea CellularYes
Ltd.
1
25.84
4 West BengalVodafone South
No Limited
1
25.84
5 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.
5 Assam
Bharti AirtelNo
Limited
1
8.67
5 Assam
Idea CellularYes
Ltd.
1
8.67
5 Assam
Vodafone South
No Limited
1
8.67
5 Bihar
Idea CellularNo
Ltd.
5
42.51
5 Bihar
Vodafone South
No Limited
1
42.51
5 Bihar
Videocon Telecommunications
Yes
Limited.
1
42.51
5 Bihar
Telewings Communications
Yes
Services
5 Private
42.51Limited.
5 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
5 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84

1 2.01E+09
1 6.67E+08
1 7.13E+08
1 1.18E+09
1 5.62E+08
1 1.25E+09
1 1.89E+09
1 1.24E+09
1 1.29E+09
1 1.95E+09
1 1.13E+09
1 1.55E+09
1 5.96E+08
1 7.25E+08
1 7.02E+08
1 5.26E+08
1 1.04E+09
1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
4 4.61E+08
1 4.9E+08
1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08
1 2.01E+09
4 4.13E+08
1 6.67E+08
1 7.13E+08
1 1.18E+09
1 5.62E+08
1 1.25E+09
1 1.89E+09
1 7.17E+08
1 1.29E+09
1 1.95E+09
5 1.12E+08
1 1.13E+09
1 1.55E+09

<!-- page 78 -->

5 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
5 Haryana Vodafone South
No Limited
1
46.52
5 Himachal Pradesh
Vodafone South
No Limited
1
7.78
5 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
5 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
5 Kerala
Vodafone South
No Limited
1
65.3
5 Kolkata
Idea CellularYes
Ltd.
1
113.72
5 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
5 Madhya Pradesh
Vodafone South
No Limited
1
53.99
5 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
5 Maharashtra
Vodafone South
No Limited
4
262.81
5 North East Idea CellularYes
Ltd.
1
8.84
5 North East Vodafone South
No Limited
1
8.84
5 Orissa
Idea CellularYes
Ltd.
1
20.27
5 Orissa
Vodafone South
No Limited
1
20.27
5 Punjab
Vodafone South
No Limited
1
67.28
5 Tamil NaduIdea CellularYes
Ltd.
1
306.09
5 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
5 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
5 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
5 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
5 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
5 Uttar Pradesh
Telewings
(West) Communications
Yes
Services
4 Private
107.41Limited.
5 West BengalIdea CellularYes
Ltd.
1
25.84
5 West BengalVodafone South
No Limited
1
25.84
6 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.
6 Assam
Bharti AirtelNo
Limited
1
8.67
6 Assam
Idea CellularYes
Ltd.
1
8.67
6 Assam
Vodafone South
No Limited
1
8.67
6 Bihar
Telewings Communications
Yes
Services
6 Private
44.21Limited.
6 Bihar
Idea CellularNo
Ltd.
5
42.51
6 Bihar
Vodafone South
No Limited
1
42.51
6 Bihar
Videocon Telecommunications
Yes
Limited.
1
42.51
6 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
6 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
6 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
6 Haryana Vodafone South
No Limited
1
46.52
6 Himachal Pradesh
Vodafone South
No Limited
1
7.78
6 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
6 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
6 Kerala
Vodafone South
No Limited
1
65.3
6 Kolkata
Idea CellularYes
Ltd.
1
113.72
6 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
6 Madhya Pradesh
Vodafone South
No Limited
1
53.99
6 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
6 Maharashtra
Vodafone South
No Limited
4
262.81
6 North East Idea CellularYes
Ltd.
1
8.84

1 5.96E+08
1 7.25E+08
1 7.02E+08
1 5.26E+08
1 1.04E+09
1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
4 4.61E+08
1 4.9E+08
1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08
1 2.01E+09
4 4.13E+08
1 6.67E+08
1 7.13E+08
1 1.18E+09
1 5.62E+08
1 1.25E+09
1 1.89E+09
5 4.79E+08
1 7.17E+08
1 1.29E+09
1 1.95E+09
1 1.13E+09
1 1.55E+09
1 5.96E+08
1 7.25E+08
1 7.02E+08
1 5.26E+08
1 1.04E+09
1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
4 4.61E+08
1 4.9E+08

<!-- page 79 -->

6 North East Vodafone South
No Limited
1
8.84
6 Orissa
Idea CellularYes
Ltd.
1
20.27
6 Orissa
Vodafone South
No Limited
1
20.27
6 Punjab
Vodafone South
No Limited
1
67.28
6 Tamil NaduIdea CellularYes
Ltd.
1
306.09
6 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
6 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
6 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
6 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
6 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
6 Uttar Pradesh
Telewings
(West) Communications
Yes
Services
4 Private
107.41Limited.
6 West BengalIdea CellularYes
Ltd.
1
25.84
6 West BengalVodafone South
No Limited
1
25.84
7 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.
7 Assam
Bharti AirtelNo
Limited
1
8.67
7 Assam
Idea CellularYes
Ltd.
1
8.67
7 Assam
Vodafone South
No Limited
1
8.67
7 Bihar
Videocon Telecommunications
Yes
Limited.
7
44.21
7 Bihar
Telewings Communications
Yes
Services
6 Private
44.21Limited.
7 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
7 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
7 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
7 Haryana Vodafone South
No Limited
1
46.52
7 Himachal Pradesh
Vodafone South
No Limited
1
7.78
7 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
7 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
7 Kerala
Vodafone South
No Limited
1
65.3
7 Kolkata
Idea CellularYes
Ltd.
1
113.72
7 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
7 Madhya Pradesh
Vodafone South
No Limited
1
53.99
7 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
7 Maharashtra
Vodafone South
No Limited
4
262.81
7 North East Idea CellularYes
Ltd.
1
8.84
7 North East Vodafone South
No Limited
1
8.84
7 Orissa
Idea CellularYes
Ltd.
1
20.27
7 Orissa
Vodafone South
No Limited
1
20.27
7 Punjab
Vodafone South
No Limited
1
67.28
7 Tamil NaduIdea CellularYes
Ltd.
1
306.09
7 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
7 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
7 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
7 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
7 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
7 Uttar Pradesh
Telewings
(West) Communications
Yes
Services
4 Private
107.41Limited.
7 West BengalIdea CellularYes
Ltd.
1
25.84
7 West BengalVodafone South
No Limited
1
25.84
8 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.

1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08
1 2.01E+09
4 4.13E+08
1 6.67E+08
1 7.13E+08
1 1.18E+09
1 5.62E+08
1 1.25E+09
1 1.89E+09
1 4.51E+08
5 4.79E+08
1 1.13E+09
1 1.55E+09
1 5.96E+08
1 7.25E+08
1 7.02E+08
1 5.26E+08
1 1.04E+09
1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
4 4.61E+08
1 4.9E+08
1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08
1 2.01E+09
4 4.13E+08
1 6.67E+08
1 7.13E+08
1 1.18E+09

<!-- page 80 -->

8 Assam
Bharti AirtelNo
Limited
1
8.67
8 Assam
Idea CellularYes
Ltd.
1
8.67
8 Assam
Vodafone South
No Limited
1
8.67
8 Bihar
Idea CellularNo
Ltd.
8
44.65
8 Bihar
Vodafone South
No Limited
8
44.65
8 Bihar
Videocon Telecommunications
Yes
Limited.
7
44.21
8 Bihar
Telewings Communications
Yes
Services
6 Private
44.21Limited.
8 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
8 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
8 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
8 Haryana Vodafone South
No Limited
1
46.52
8 Himachal Pradesh
Vodafone South
No Limited
1
7.78
8 Jammu & Kashmir
Vodafone South
No Limited
1
6.33
8 Jammu & Kashmir
Idea CellularYes
Ltd.
1
6.33
8 Kerala
Vodafone South
No Limited
1
65.3
8 Kolkata
Idea CellularYes
Ltd.
1
113.72
8 Madhya Pradesh
Videocon Telecommunications
Yes
Limited.
1
53.99
8 Madhya Pradesh
Vodafone South
No Limited
1
53.99
8 Maharashtra
Telewings Communications
Yes
Services
1 Private
262.81Limited.
8 Maharashtra
Vodafone South
No Limited
4
262.81
8 North East Idea CellularYes
Ltd.
1
8.84
8 North East Vodafone South
No Limited
1
8.84
8 Orissa
Idea CellularYes
Ltd.
1
20.27
8 Orissa
Vodafone South
No Limited
1
20.27
8 Punjab
Vodafone South
No Limited
1
67.28
8 Tamil NaduIdea CellularYes
Ltd.
1
306.09
8 Uttar Pradesh
Vodafone
(East) South
No Limited
2
76.93
8 Uttar Pradesh
Telewings
(East) Communications
Yes
Services
1 Private
76.17Limited.
8 Uttar Pradesh
Videocon
(East) Telecommunications
Yes
Limited.
1
76.17
8 Uttar Pradesh
Vodafone
(West) South
No Limited
1
107.41
8 Uttar Pradesh
Videocon
(West) Telecommunications
Yes
Limited.
1
107.41
8 Uttar Pradesh
Telewings
(West) Communications
Yes
Services
4 Private
107.41Limited.
8 West BengalIdea CellularYes
Ltd.
1
25.84
8 West BengalVodafone South
No Limited
1
25.84
9 Andhra Pradesh
Telewings Communications
Yes
Services
1 Private
286.91Limited.
9 Assam
Bharti AirtelNo
Limited
1
8.67
9 Assam
Idea CellularYes
Ltd.
1
8.67
9 Assam
Vodafone South
No Limited
1
8.67
9 Bihar
Idea CellularNo
Ltd.
8
44.65
9 Bihar
Videocon Telecommunications
Yes
Limited.
9
44.65
9 Bihar
Vodafone South
No Limited
8
44.65
9 Bihar
Telewings Communications
Yes
Services
9 Private
44.65Limited.
9 Gujarat
Telewings Communications
Yes
Services
1 Private
224.84Limited.
9 Gujarat
Videocon Telecommunications
Yes
Limited.
1
224.84
9 Haryana Videocon Telecommunications
Yes
Limited.
1
46.52
9 Haryana Vodafone South
No Limited
1
46.52
9 Himachal Pradesh
Vodafone South
No Limited
1
7.78

1 5.62E+08
1 1.25E+09
1 1.89E+09
1 2.96E+08
1 7.17E+08
1 4.51E+08
5 4.79E+08
1 1.13E+09
1 1.55E+09
1 5.96E+08
1 7.25E+08
1 7.02E+08
1 5.26E+08
1 1.04E+09
1 12211783
1 8.69E+08
1 5.26E+08
1 1.03E+09
1 1.05E+09
4 4.61E+08
1 4.9E+08
1 2.08E+09
1 8.97E+08
1 9.39E+08
1 5.67E+08
1 8.89E+08
1 1.75E+09
1 2.3E+08
1 5.74E+08
1 6.47E+08
1 2.01E+09
4 4.13E+08
1 6.67E+08
1 7.13E+08
1 1.18E+09
1 5.62E+08
1 1.25E+09
1 1.89E+09
1 2.96E+08
1 5.38E+08
1 7.17E+08
5 9.12E+08
1 1.13E+09
1 1.55E+09
1 5.96E+08
1 7.25E+08
1 7.02E+08
