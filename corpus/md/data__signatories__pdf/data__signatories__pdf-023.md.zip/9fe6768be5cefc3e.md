---
doc_id: "9fe6768be5cefc3e"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/591ee0b5efae2b3457f9408a5651564b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "3G Auction Update: 13th April 2010"
date: "2010-04-13"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "82235cda3968b78f"
---

<!-- page 1 -->

3G Auction daily public report
End of day 4
Round information
Date

13 April 2010

Number of Clock Rounds completed today

6

Total number of Clock Rounds completed to date

22

Information by circle

Service
Area

Round
Price in
Round 22

Aggregate
Demand at
Round 22
Price

Delhi

Rs 437.65
Crore

3

Mumbai

Rs 416.78
Crore

4

1

Rs 416.78
Crore

Maharashtra

Rs 425.14
Crore

3

0

Rs 425.14
Crore

Rs 4.25
Crore

Gujarat

Rs 459.52
Crore

4

1

Rs 459.52
Crore

Rs 4.59
Crore

Andhra
Pradesh

Rs 425.14
Crore

3

0

Rs 425.14
Crore

Rs 4.25
Crore

Karnataka

Rs 420.94
Crore

4

1

Rs 420.94
Crore

Rs 4.20
Crore

Tamil Nadu

Rs 429.39
Crore

4

1

Rs 429.39
Crore

Rs 4.29
Crore

Kolkata

Rs 159.37
Crore

2

-1

Rs 157.80
Crore

Rs 0.00
Crore

Kerala

Rs 159.37
Crore

0

Rs 159.37
Crore

Rs 1.59
Crore

3

Excess
Demand
at Round
22 Price

Provisional
Winning
Price at end
of Round 22

Price
Increment
applied for
Round 23

0

Rs 437.65
Crore

Rs 4.37
Crore
Rs 4.16
Crore

<!-- page 2 -->

Aggregate
Demand at
Round 22
Price

Excess
Demand
at Round
22 Price

Provisional
Winning
Price at end
of Round 22

Price
Increment
applied for
Round 23
Rs 0.00
Crore

Service
Area

Round
Price in
Round 22

Punjab

Rs 127.36
Crore

1

-3

Rs 126.10
Crore

Haryana

Rs 145.76
Crore

2

-1

Rs 144.32
Crore

Rs 0.00
Crore

Uttar
Pradesh (E)

Rs 182.24
Crore

4

1

Rs 182.24
Crore

Rs 1.82
Crore

Uttar
Pradesh (W)

Rs 159.37
Crore

3

0

Rs 159.37
Crore

Rs 1.59
Crore

Rajasthan

Rs 174.22
Crore

3

0

Rs 174.22
Crore

Rs 1.74
Crore

Madhya
Pradesh

Rs 158.17
Crore

3

0

Rs 158.17
Crore

Rs 1.58
Crore

West Bengal

Rs 124.86
Crore

0

-4

Rs 123.63
Crore

Rs 0.00
Crore

Himachal
Pradesh

Rs 30.30
Crore

1

-3

Rs 30.00
Crore

Rs 0.00
Crore

Bihar

Rs 32.44
Crore

4

0

Rs 32.44
Crore

Rs 0.32
Crore

Orissa

Rs 30.30
Crore

0

-3

Rs 30.00
Crore

Rs 0.00
Crore

Assam

Rs 30.30
Crore

0

-3

Rs 30.00
Crore

Rs 0.00
Crore

North East

Rs 30.60
Crore

1

-2

Rs 30.30
Crore

Rs 0.00
Crore

Jammu and
Kashmir

Rs 30.30
Crore

0

-4

Rs 30.00
Crore

Rs 0.00
Crore
