---
doc_id: "2fa5e793ecad4ec1"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/1577260de576dcf8f7b916d7e9fd9573.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of 51 numbering series for common nodes.Details"
date: "2015-06-16"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7cec4780d627d335"
---

<!-- page 1 -->

Government of India
Ministry of Communication & Information Technology
Department of Telecommunications
Access Services Wing
20, Ashoka
Road, New Delhi-110001
Letter No. 16-5/2009-AS-IDNol.II/(Part) J 2-13 /

Dated:l6.06.2015

To,

Mis Telewings Communications Services Pvt. Ltd
Unit no.902, 9th floor, Le Meridian,
Commercial Tower, Windsor Place, .
New Delhi-11 0001
Subject: Allocation of 51 Numbering Series (MSISDN as GT codes) for common nodes.

On the above subject the undersigned is directed to inform that 51 numbering resources
belonging to 9060 series may be allowed to use as_MSISDN as GT codes by Mis Telewings

~
-­

Communications Services Pvt. Ltd as mentioned in annexure-I.

£'--n r..J_,:

fH. ~ .

S \b "\<·'
­

(Sanchit Kumar Garg)

ADET (AS-III)
Copy forwarded for information and necessary action, if any, to:
1.
2.
3.

Secretary, TRAI.
CMD, BSNL/MTNL.
Director (S-1), Director (S-Il), DoT HQ.

4.

All Access Service Providers
DG (COAI)/ SG,AUSPI

5.
- - - - - .- - 6;-

ADG(IT) _foi:_uploading on the website of DoT
.

.

.-

.

-- -----:--------- ---·--- -- ·----·---- -- -·--------

·

- ­

---- ----- ------- ----

<!-- page 2 -->

Annexure-1

SI. NO.

MSISDN as GT CODE

1
2
3
4
5
6
7
8
9

9060051500
9060251511
9060251512
9060251513
9060251514
9060251515
9060251516
9060251517
9060251518
9060251519
9060251501
9060251502
9060251503
9060251504
9060251505
9060251506
9060251507
9060251508
9060051541
9060051542
9060051543
9060051544
9060051545
9060051546
9060051547
9060051548
9060051549
9060051540
9060851548
9060851549
9060051561
9060051562
9060051563
9060051564
9060051551
9060051555
9060051556
9060051571
9060051572
9060051578
9060051580
9060051502
9060051503
9060051504
9060151541

10
11

12
13

14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45

-

- - - - - - - - - - -- - - - - - - - - - - - - · - -

--------­

<!-- page 3 -->

"

46
47
48
49

so
51

----·-·---·--­

9060051575
9060051573
9060051574
9060051577
9060051579
9060051576

--------------------·-­

-

-----------------
