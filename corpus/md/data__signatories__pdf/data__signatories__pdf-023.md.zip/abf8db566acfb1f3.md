---
doc_id: "abf8db566acfb1f3"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/adbf059f18970108c42bcd20a6cada52.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of officers of P&T Building Works (Group-A) service of Civil wing of DoT whose Presidential Orders issued"
date: "2005-01-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "242e277cc7becd17"
---

<!-- page 1 -->

LIST OFWORKING OFFICERS OF P&T BUILDING WORKS (GROUP A) SERVICE OF
CIVIL WING OF DOT WHOSE PRESIDENTIAL ORDERS ISSUED

Present Post *
S. No. Staff No.
Name(S.\Shri)
1 90089
Surya Prakash
2 92043
Kumar Manoj
3 92044
T.L.N.Reddy
4 92065
Sanjay Kumar
5 92197
Dharambir Kumar
6 92207
Abdul Khaliq
7 NA
Kishor Kumar Bhagat
8 NA
G Rajesh Khanna

Chief Engineer (Civil)
Executive Engineer (Civil)
Executive Engineer (Civil)
Executive Engineer (Civil)
Executive Engineer (Civil)
Executive Engineer (Civil)
AEE(Civil), Probationar
AEE(Civil), Probationar

Allocated
To
BSNL
BSNL
BSNL
BSNL
BSNL
BSNL
BSNL
BSNL

LIST OF RETIRED OFFICERS OF P&T BUILDING WORKS (GROUP A) SERVICE OF
CIVIL WING OF DOT WHOSE PRESIDENTIAL ORDERS ISSUED

S. No. Staff No.
Name(S.\Shri)
1 90037
J. C. Sethi
2 90224
P. Srinivasan
3 90207
P V Damodaran
4 90043
S M Kaushal
5 90166
P D Vashista
6 90036
A C Jana

Designation at the time of
Retirement
Chief Engineer (Civil)
Chief Engineer (Civil)
Executive Engineer (Civil)
Chief Engineer (Civil)
Superintending Engineer(Civil)
Chief Engineer (Civil)

Allocated
To
BSNL
BSNL
BSNL
BSNL
BSNL
BSNL
