---
doc_id: "7ddfcd8cf4b2e3d7"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/b5cc97be92a71f5881fb03f66e814e7a.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Auction_Day_13_Report"
date: "2015-03-18"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7ba359eed43abe9e"
---

<!-- page 1 -->

Spectrum Auction in 2100,1800,900 & 800MHz Bands
Daily Public Report: End of day 15
Date
Number of Clock Rounds completed today :
Total Number of Clock Rounds completed till Date :

2015-03-18
6
80

Information by Service Area
Provisional
Clock Round
Aggregate Excess Demand Winning Price Price Increment
Price per Block Demand at
per Block at Applicable for
at Round 80
in Round 80 (In Round 80 Price Price
end
Round Round 81 (In
(In No.) 80 (InofCrore
Crore in INR)
(In No.)
in Crore in INR)
INR)

Service Area

Band

Andhra Pradesh
Assam
Bihar
Delhi
Gujarat
Haryana
Himachal
Pradesh
Jammu &
Kashmir
Karnataka
Kolkata
Madhya Pradesh
Maharashtra
Mumbai
North East
Odisha
Punjab
Tamil Nadu
Uttar Pradesh
(East)
Uttar Pradesh
(West)
West Bengal
Andhra Pradesh
Assam
Bihar
Gujarat
Haryana
Himachal
Pradesh
Karnataka
Kerala
Madhya Pradesh
Maharashtra
North East
Odisha
Punjab
Rajasthan
Uttar Pradesh
(East)
Uttar Pradesh
(West)
West Bengal
Andhra Pradesh
Bihar
Gujarat

800 MHz
800 MHz
800 MHz
800 MHz
800 MHz
800 MHz

699.81
102.77
106.25
998.23
350.65
77.07

4
8
1
4
0
1

-1
-3
-3
1
-2
-5

686.09
102.77
106.25
998.23
347.18
70.71

0.00
0.00
0.00
9.98
0.00
0.00

800 MHz

26.66

0

-7

24.46

0.00

800 MHz

36.05

2

-5

35.35

0.00

800 MHz
800 MHz
800 MHz
800 MHz
800 MHz
800 MHz
800 MHz
800 MHz
800 MHz

378.75
185.58
391.29
887.35
918.46
28.76
53.86
112.67
450.00

0
0
4
5
0
4
0
0
0

-1
-1
-1
2
-6
-7
-6
-3
-1

0.00
183.75
391.29
887.35
909.37
28.48
51.30
107.31
0.00

0.00
0.00
0.00
17.74
0.00
0.00
0.00
0.00
0.00

800 MHz

167.50

0

-3

0.00

0.00

800 MHz

118.75

0

-1

0.00

0.00

800 MHz
900 MHz
900 MHz
900 MHz
900 MHz
900 MHz

71.96
144.31
37.35
81.36
146.71
30.24

0
45
0
25
30
31

-1
-25
-31
-6
-40
-31

71.25
136.15
36.99
80.56
134.60
29.36

0.00
0.00
0.00
0.00
0.00
0.00

900 MHz

11.60

0

-62

11.49

0.00

900 MHz
900 MHz
900 MHz
900 MHz
900 MHz
900 MHz
900 MHz
900 MHz

122.65
74.61
64.99
156.14
10.48
28.91
74.31
91.44

44
30
37
0
0
6
75
31

-26
-32
-25
-70
-44
-25
-3
-31

111.50
73.88
61.90
154.60
10.38
27.80
72.15
90.54

0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00

900 MHz

89.02

0

-31

88.14

0.00

900 MHz

110.25

30

-1

110.25

0.00

900 MHz
1800 MHz
1800 MHz
1800 MHz

41.91
49.04
12.40
48.07

0
6
0
0

-22
-13
-10
-17

41.50
48.56
0.00
47.60

0.00
0.00
0.00
0.00

<!-- page 2 -->

Haryana
Himachal
Pradesh
Karnataka
Kerala
Kolkata
North East
Odisha
Punjab
Rajasthan
Tamil Nadu
Uttar Pradesh
(East)
Uttar Pradesh
(West)
Andhra Pradesh
Assam
Delhi
Gujarat
Haryana
Karnataka
Kerala
Kolkata
Madhya Pradesh
Maharashtra
Mumbai
North East
Odisha
Rajasthan
Tamil Nadu
Uttar Pradesh
(East)
Uttar Pradesh
(West)

1800 MHz

9.59

23

-17

9.32

0.00

1800 MHz

2.92

0

-51

2.90

0.00

1800 MHz
1800 MHz
1800 MHz
1800 MHz
1800 MHz
1800 MHz
1800 MHz
1800 MHz

37.37
16.37
31.01
2.20
6.68
14.34
15.27
45.00

0
8
0
33
25
3
0
85

-9
3
-35
-9
-56
-5
-52
-10

37.00
16.37
29.82
2.20
6.62
14.20
14.55
45.00

0.00
0.16
0.00
0.00
0.00
0.00
0.00
0.00

1800 MHz

19.78

18

-3

19.59

0.00

1800 MHz

19.00

3

-8

19.00

0.00

2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz
2100 MHz

1375.00
195.11
3315.00
1302.90
232.30
1658.78
594.45
583.74
461.31
1520.05
3245.00
55.90
182.06
706.11
1737.20

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

-1
-1
-1
-1
-1
-1
-1
-1
-1
-1
-1
-1
-1
-1
-1

0.00
193.18
0.00
1290.00
230.00
1642.36
588.57
577.97
456.75
1505.00
0.00
55.35
180.26
699.12
1720.00

0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00

2100 MHz

456.01

0

-1

451.50

0.00

2100 MHz

530.60

0

-1

525.35

0.00
