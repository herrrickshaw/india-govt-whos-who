---
doc_id: "a5d59ffd4e27acd5"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/e3fb588c4ea66236af45a8329b445e54.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Communication of GSM/CDMA Quantum of Spectrum allotment against auction held in 2010,2012,2013 and 2014 to the CCAs"
date: "2015-02-05"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "304c37d11196fb45"
---

<!-- page 1 -->

rile No-1003/ 1/ 2011/Qr-WPC
Department of Telecommunication
800 Sanchar Bhawan New Delh i
(WPFWing)
Dated 05/02/2015
To,
All Pr CsCA/CsCA

Subject-Communication of GSM/CDMA Quantum of Spectrum allotted against Auction held in~olt>,
2012, 2013 and 2014 to the CCA's .

Kindly refer to this office letters Nos. 1012/08/Misc/WR/2014 dated 20/11/2014 and
25/11/2014 with which the Bid price was _communicated for working out the AGR as per
order issued-by WPC letter No. P~14010/01/2014-NTGdatea 31/10/2014.
The details of Quantum acquired by Various TSPs in different service areas in the
auction held in the year 2010, 2012, 2013 and 2014 are being sent for taking further
action at your end. Date of effect has also been indicated against each

quantum

allotted to the TSP for giving effect of rates for working out SUC.
This has the approval of competent authority.

EfiCI- as a6ove.
.

~')\--"\-.{

(Harish Chand)
ADG (WR}
Tel 011-2303-6362

<!-- page 2 -->

I

l

,./

:1e;:-;2:-rm e rc of ·i e1e:::>mmun i::ati::m
\J\j? :: \/If i fl:9

(V-·3 mup)

'.Stiqje=t: . :Detaii!s. 'Of ;spe=tr:um .ai!bcated to ·the :s uccessiu[ -bidde:-:s in variol!.ls
-aiuttior.s :·heia ~i n 20t 0,20 t 2 ,.:2lr";·3 :and :'20"i4.

'I;am::dire:Cted ~to~:refer · ~rou r tJ :D. letten 10. ·1D03/1/2Dt:1 /.QHNVR :dated 1'8 . ~1'1.2014
on i he :'. abov~ ~m:eri:ti.oneo ~su-bjecLand :to ;state i hat-'the :details ;.ci'( quantum ~of':spectrum

:all.ott~Ei~,to\th~;~0c~~~~i.ci-1 ~·~icici~·;~j·~-ih~:~~-~ti~n h.~i~ !~ 2p1:0~ 2:0:12 ·and 2014 pertainino
-t~:0~:$r~.
~~~~t~'
2cif1~1 .a:sed·:·h-eFeWith~as
:perAnnexur:e~lio Td. - ··' - -·
=
- .·.
··'-· -·--:.: ·:'. . ----.. ·=-:·· .
­
-···.~ . · .

·-· ~~:;,. ·,.-.:.:.:::~.~~~~ .: - ~ ..:'~.-:.: :··::.:• .. . ..-: ' ..

·:f>:·,~-~~; -=\tz~nr ,
• .::r.,: ~

~-~-.

:

'''

··,. ·,.

-:- •, ~-~ ... _~~: '-:.-=.~ . ~·· ·

·.:~>~-~ .:. _:~-::··~;··~!:~·:.:.\~~ •

·.

f_~.-~.~E-~:-~~~_,_·:.~.~.~-:~:.:::-~.: -·~ :.'. ·. -.. .! :::.•••_. :·.: .::_. ):~~-; · ~;-~-:.:.: :.-~=:. !::· : .-.- ~!. ·:

: :·..{~~: ... .. .

.•..::..:,...;-,;,• • . ..:...•. ...-., ~ :;--.:.- .;.,~ _ ; •• ~-~~:;.:·_ _ ..::_,____

::·i., .... _-· .:-

·-:··:

'.'i--.r:;. · · ·, ;~.1-~~ ...:---;.~~~:-~· ;,::·~! .:; .:.:. .-:.·· :.

..• :..:'. •..,.-:,;o;.,·:-1· .· .,., • .. •._._, .••• ,. • ,.,.

·- ·:-.:· .:·L~ :.:- ~:··~· ...

"<:~

:· ··''

-:· - -...··

- .-. - -;--: - ------ ---- ··- - - - ... --.:......

__ _

__: _,___:

- -~--·'.". :

__ __·. -- .
-

·--··------ - ·-·-- ··- - -·--·--·-----·- -- --'-------"---'--­
---===-:. =- .-:: · ··.: : _·.. :: . :-_·.:::.-.:.-. : ·:-.· . ::.::-:-..:=:-:=:--·-·.::-::."::::":::- - -·

___.

----- ----~:--

.:·

·.· ·.-·

---:------:----- - -·--- --­

_;_

___

.:

~r:_;-·

--' .~: .~:.f~,:

<!-- page 3 -->

·- .

­

- ---- - - --- - -

-:_-_- - - ·~~--

---,-------,-~-

;j

~,

-·· . -:·;/-

Anne>Cure-1

.---.-- - - - - - - - - - - - - - - - - - - - - - - - - - - ­

_!

-·

/f

.1/

{

De"Lails of 3G spectrum allotted to the successfu l bidders in the
auctio n held in 2010

Service
Area

Delhi

Successfu [
Bidder

Date of
earmarkin g
for
commercial
purpose

- Vodafone .Essar
_Lini-itep _ ·

01.09.2010

Quantum of
spectrum allotted in
MHz

5

Bharti Airtel Limited 0.1:U9.201 O
... -- - - :- · ···- - . ------ - . . ·- .. -· .
­
.. :

5

~

-Reliance ·'Be!ec·qm --; Dt.D9.20-1.0

5

Limited - · -­

'5

--. ..

:.·~:....

·.·

·-

·. ·-.·:·

.-···-,;..

-

• -

.

;._~."..~~---=-

~~,~~-~-~-~j-~:~.:~~,:~~:~;.-i~ ~~~-ro-~~dk5l~{i2~t~~~ _:.; ~~c::--·­
·· ..:::·.:..

.

.. ..

--::::-~~~~~~~~:.:::-::-:-::-.-~==-:=-=-.-::::.~=:.__:_:__:;2j:_,.::...:...:..=.::::.:.~....:
_-,
-. -- - - ----- .
: . ·~ . ..

-·-

.

. . - ·~ = -

J-·· --·- -

.- .. - ;

.-.~- Ai[cel.:kimited...._: ~ ·-

~01 :os.;20~ .o

. . :·

>''-°'i-~:L'- Bh~rti'.Airt~l ill~ited 01:·092oro ·:

;.:c::~-~~:. :·. :-_. : :~- ~:. ·-=__ :y.~.-~'~

.. ·;.. . -.·. -' ... -

.

: ~:5 _..

- . -.. _..,..

:5
5

"'."' ............. ..._. __

_-: y;~qsi1o_ne~ssar _
...., ....

- - --·,.·-· ..

-.~

.. - -.... .. -· ..

--

Ii

'

.:,. -.:... ;-

'I

**

:·~- 'Ui iTiit~J:t: -~:. -~ ~ -- ­

- Ai rcei~Limited '
..- :·..

***

';--. ~·-.:.. :.

·-- ·- _- -:._:_________ ....=_ ·-·--··· -·- ·- - -··-­

-5

--·~ "· ~--~~ - : __
\_

I

,_: ­

-: -_- -- - ---- , _

·- -·--·- ·- --

--------- ---·-···--- --·-·- - ----=--- ·- - -·..__ ._

I

·I

I

<!-- page 4 -->

r

·f

-

-··

f

V odafone Essa r
Limited
.A irce l Lim ited

Kol kata

Kera la

Oi .09.2 0'!0
0 1. 09.2010

Reliance Tel ecom
Limited

01.09.2010

Ide.a ·. cellula r
Limited
Tata..Teleservices
Limited ..

01.092010

· Idea Cellular
· liimite.d ~ · ··

5
5
·5

.o·t .09.201 O ·

5

01.:09:201:0 .

;\irce.l.Limited ..
Punj~b

5

:5

· -~-: J3 , Q3.2014.~ . ­

Reliance·Je1.eco­ m 01.'09.201:0

.Li mi!ec("~~-:~~~;_~:--. ·

......

- ~·:,· -.'!·­

.01.09201 CF_~

...5·
-

-·.' ..:•_

. ;.:,. :.:·. . :­ - -~ ..
..-:·­ ., . -::
·, ·-·-··

. .. ,:- ... - .

.

.- ·. ~s---.~

..

~- -·

·- -:~· -· '. ·­

-J

; --. '!

:.-.:

;': . .·. . :.

•. ~ • •. • ··'·'=•

..

-.·:.-·.

. ~·
·,.

·

~ --

·.

- .-_::;°':u:~ _,. :_::.:;,;. · \ mata "iFeleseD.tic·e~ -'.;; 'O~ :0.9:20t0
-~:.:·:_

~~

. -. ·

..

.- .: _.

· 01..09 .z.m;o :·=~:~-~L · .~_:, :<-'--'c'"· -· -­

- ---· -... .

~Madlhya•-. ~~ il dea~:ffi'ell.ular ..·_. .-~.

.·~ . ·Pr:~d~siI·'~..; :[fmit~l:i=:~-_:··~- · .. :·:.:_-~---.- ~---<~>-~-:·~: ·-·::·· __ · .s~-i:: '·-· ., .

...

-;:. ~···,,;;-;~~ lbi mited~~._~, .{" :~- -~ -- '·_. ."",. :-c~ ·o :--.:: ' · -"': ·: ·· ._.~:.5.·

~

..

_..,.

..

:_;.~i~.'\:~-~~~4;~~l~~~i7~~1~:~~~I . :°.B.~0~~~9·1;~:'~~:- : f·;:.;;_~.. !'°:- ·5 .

- -, > -~--·.:."' :.Tcata.-'Teleser:v.icps.>; 01 .0928_:1 O ·: ·>'.'_
- :· · ·· ' .; Hr:Diteif :- ·- -~ , :-.· ., · · ._

~:5

·· . -

·west
Berigal Bharti
Arr:teLLin:iit~a
o
- - ' - .
. .0.1 .09.201
.

, I:i

1:,

5

•'

1-------~-+-'-'-'-----==="'i==~-~--------i --- - ·~- - -· -

--1----'------iJ~:eltance-1:e lecom - :01:09~2Tf1_ D___ ___ _

-:.~·.'. Vodafone Essar

•· O'l .09.2010

5 ..

---·--.··-----·--------·--- -·1JrTiitea · ·- · ·.·-.....
-~

r----------+-----~~-~~~~-------'-!
-· - --

...:..... -~ ~----- ---· - Aircei-l:ih'._it~=a_==-:: Q~T~Q9~ Z0-1Q..=~= ~

.... · ---·----~----··· -- ... IJ
.. . .1·
I'

5

.-.. : ·_·_.Limited

:_____ _ -- ------·-i.:.. .. ___;_ __- ·-···· ­

..

···-· ······--- ~ s .
·-

--· ­ - ··- .

--·-- ---- -- - ·- -------- -·---- .. .

l,

<!-- page 5 -->

;:­
(
j .--~~~~---:-~~~~~~~---,--~~~~~~,-~~~~~~~~--,

Himachat
Pradesh

.r
;- kl
,. ~ r·"

--~'!
;//
it'
'

~

Bharti ?.irte: Li mited IO I 022010

I

,S Tei Private

5

ID'!. 08 .2 010

I

Limited ai'
Idea Cellular
Limited
Reliance Telecom

Di .092010

5

01.09.2010

5

Limited
· ·· Bihar

S Tel Private.

01. 09:2010 .

.5

Limited@
Bharti.Airtel.Limited 01.09.201 O

Reliance:TeJecom
··- ···- -­

timited
. ...

.01 .0920·1b

-·

-- -

5

5

.....

--··--·~-

:5
5
.:5 ·- .

_........_-_.

· ,:

.·.·. -. :·~I:~-:

~-

__

- .

- ... -

. ~X~".:~r?J;" :kilhalic~Jfi~·: ~~·:~:~~'!£'.; 'M ""S$·'f'"""3'''1" ,,. c'.'2' £,c~·~ <'· .'.··.··. . ... •...
~'

·.-·

'-'

J.

- _, .... --···

'.

: . -~- ::t' ~-~-

..

~--·

-

.

,

. .

. ,~ for']al.!!i.Inc:i~iFex,c_lutjiri(g~f:!~ntjai~~arfd ffqr'Chennai 'ser:Viq.~are-as;

. -~ -· · ·

·dcife ~Orte~rffia:rikin.g ~was 23zb_st2o~;fL:ama · t~/1{oz2·o ·:ro ~res:PS.cti,\ie!Y~-: _. ·
. '

. ..: .!' : :·~:>..

.·.

-.: .

r'· _

. -~

..·• - i

..:

".'

•

-

.•

•- 7

·.• : ·

.

'

-

.. - .

:~

c~~ .:_;_ - - · · : - : · - ·

·- : . .....

.,,.. ••

~

- ···:· .•.·;: :~'. : .

.-_.-··:

.@T)le.'.3G ·specfoi.Im:'in_2'.tOO-iM-Hz .ba~d;h-as ibe~n:wlth-dr.awn - - --- - ·
-

.

- -

..

.

- :'

--- ··

·'

--

-

.

-­

. .-.. • '

·---

. . _. .
~

·-·-··.;::_ -. - .

.:._ c~· •

~·- -:.

.. ;

-· -

............ _ _ _ ,, _

.. ~f - ... .

__ __________ __ ___ ······ --·----·--···------.. -····· "·----- .- ----­
. ­
- --··----· .. ·-----·,- -- --­

.

- - -·­

'. i

~

,._

___

~ -

-·-····- ··-·· -- - -------·-·- ···-·----· _,,

. .; --

-· -·

-· __ __ ,. ­
·•

- --

____________ __ -- ---·-------------··
­

<!-- page 6 -->

_i

i
~ ;f

I

/

,
,,"

Annexure-11
Details of spectrum allotted to the successful bidders.in 1800 MH z band in·November,.2012' auction
No. blocks won Quantum of
.Date of
Name of the
Name of the succeful bidder
Service Area
in the ·auction spectrum
Allotment
-- ----- - ..... ~..(each .. bLo~k.aL allotted.in......... _:__-________ __ _ _ __
1

'i.25 MHz)·

TeleWin~s - Communications ·

.Maharashtra

services PVt Ltd':·

4

·\1odafon·e:South .Limited

1

TeleWi!1gs:·c;:ammunicatip_ri~

_Videocon~TeL~c.Qm01Li~ic:a~ie._~s-.~.-.-.- :
Limited~..:.:::i. ;1}

Andhra
Pradesh.

:;-".

·

-· --...,.

18.06.2013

5.0
13.12:2013 .

s.o
05 .04.2013
' .

5.0 ·

.4.:._,::· ·

Tamn:t;Ja_dt:J::.:nrrea"c~(tll~t=lih11tec:L ·· · "... ,

..

13.12.2013

1.25•

-4_ .

. :- . :.

TeleWings,coi:nmunications

s~r:V(~~£BV:fat_ci.

5.0

...

4

. seriiices-PV.t=Ltd.

Gujarat

· MHi

13.12.zon

· 4. · ,;;~

s.ci.­ ·

11:11.2013."

...

· ·s.o ·

..

5~ 0

__-,.

.• .

. - -·

:-l~~~~:~'-;-··:f. ·:.:;;:·, .~,· · .. Q5._04.iQl3:...•~. -

"· ·

.

· :·c ,;·- ~~ ;:::

. ..

·~~lt\S&°'' °'."!~~~~c;· ~~?;~Jf::ti- '.L~'~\9h~ ~~\,;jo1,~. c~ •.c, '~:~ · ·. ·

·· ..~. :c , .:~ ;·=~~':

9

·: :vaE<ITiJW~soiitfl~timifea~:.::3::-:: ::;- ·..~

·-=:'-<~'?.;~

:<-; :;' :-:·~1:S: ~-~'-·:-?. ~:?1@~;20:13 /

_ . · ~ ­­

. ~ : !;;~!?;·. r~~~~i;J[f~il~~~~t~\. ~:.·. ;:.~;~·:~::r~5;; ·:·. ..
,_ . ·

• ·

1

~~---.'~ : _·: .. ici.ea~:eelL~tai.,_lirDffeH;-~~.;:~~- s~~:::-,~:·'·:~ ·-· .:. ~ ·-..1

·
Bitlar .

· . 'ili'aeoeoii·T€1e2arilfhwITi6aiti!Jfi s--'" · ·'··· . ·· .
· • ·dLtttit~riLt·_.::.~ ,_·;_~7';::~;~~:~~~,~~-c::.~- ~ 4 -

:,". -

Voaafi:rne:South..Uniitea:::· :.~..•· >
· -.f~ l~iij(ngs~to·m-mi'.fril'cations · 5~rVlces~RVt:[fd .. :·---~--...::. ..:::.::.::. .. ·
Oi-issa .
i'aeir'celfular:un;ited'·: -=-. '7 :
~-----· +v~o_a_a_fa_·n~e_s_6_u_t_h_T_im_i_te_u__
·
. ··_·-_'
:" _
Bharti Airtel 'Limited·
Assam

No1ih-East
.j ammu &
!{ashmir

I__J_

. 30.01:20.n

s;o

...

,,

os.04:20.B _..... . ,.,
_. "2.~·

1s:o(:i.20.n

4

j

~· o

- "·· ~~-·,_.-·_' .:o. •

- ·----- ---~~-- .. .. -.~: · :la;i·z:: ~o1·~ :~-_

'LI. .

·1

5.o • . .- 11:11.20.13

2

·· -

r :25 ·

.

-..

·_

_:.__2_~__,_
- l __2_
~ 5'---+1_s_.0_6_._20_1_3
·
__
4
1

1.:5

28.06.2013

r-ld-=e,...a_Ce_l_lu_l_ar_L_i_m_it_e_d__
.::._-_--_-_
. ._ __,__ _ _.!l._ _---,_ _ _
s_:o__·+·1_1_._L_·1._2_0_13_ _.:..,..,,,.,.--::. ,,
2
2:5
18.0fo2013
.
\ .
..l_~......-v·a·oafone South· limited
ldea Cellular Limited
------.1--~----s:_o__.,..1_1-.-11-.-2-0_13_ ___, ..-· _...,./2; .
Vbdaf9ne South Limited

_

!Vodafone South -Limited
!1dea·Cellularlimited.

'
u

I

:.s

18 .06.2013

::..5

118.06.2013
jo9.10.2014

S.O

~------ ~-~~==

<!-- page 7 -->

1.-

t>. nnei:ur:::-11 !

1­

1 De ~ai! s or spe::rr urr. ali onec rn th::: su::::essfu! oiade~ ~ ir. :!..800 1VlH2­

j

ban C: in February-, 20 1L; au ::t ion s

j Name of the
S. No.

I

Name of th e
succef ul bidde r !Service area

Date of
Spectrum

I
An dh ra
Prad esh
Haryana

North East

21. 10.2014

1.8

UP{E)

10.10.2014

1.8

West Bengal

14. 10.2014

1.2

Rajasthan

13 .10.2014

1.6

Kera la
Karnataka

Andh ra
Pradesh
Delhi
Gujarat

3

Haryana
M/s Idea Cellular Punjab
Ltd

Maharashtra
Mumbai

- ....__ ... ...__.

North East
MP
Kera la
Karnataka
HP
Andhra
Pradesh
Mumbai

1.8

21.10.2014
21.10.2014
21.10.2014
21.10.2014
10.10.2014
14.10.2014
16.10.2014
21.10.2014
14. 10.2014
14.10.2014
14.10.2014
09 .10.2014

r

6.0
0.6
1.6
6.0
8.0
9.0
2.0
5.0
7.0
.10.0
­
5:0
10.2

13.10.2014

8.8

Punjab
J&K

10.10.2014

2.6

MP

14.10.2014

North East

21.10.2014
14. 10.20 14
14.10.2014
21.10.2014
13.10.2014
13.10.2014
14.10.2014

5.8
7.0
8.8
5.0
8.2
5.0
5.0
4.4

Karnataka
Kera la
Rajsthan
Orissa
Tamil Nadu
West Bengal

.~

I.',
!•

'·

~

JI

Limited/Bharti
Hexacom Ltd

,,

6.0
7.0
5.0
8.2

Kolkata
Bharti Airtel

I

10.10.2014
10.10.2014
10.10.2014
10.10.2014

Delhi

4

0.6
2.4
8.0
8.2
4.4
8.0
0.6
4.0
7.0
5.0
0.8

10.10.2014

Kol kata
UP{E)

Aircel/Dl~hnet

13.10.20 14

J&K

Gujarat
Punjab

2

IVI Hz)

Rajasthan

Wiumba)
Vodafone

allotred (in

08.10.2014
10.10.20 14
10.10 .2014
13.10.2014
10.10.2014
10 .10.2014
10.10.2014
14.10.2014
14.10.2014
13 .10.2014

J°Delh i __.

1

Quantum of

Allotmen t of Spe::trum

-:­
!

I

<!-- page 8 -->

:!

~-,----~~~~~-,----~~~~----.-~~~-~-----

IAndhra
1

IPrades h

I

I

:>

Assam
ilelewing:;
:::ommuni:::arions
Biha r
/servi::es Pvt Ltd
UP(E )

!

UP {W)
Andhra
Pradesh
Assam
Delhi
Kera la
MP
West Bengal

6

Reliance Jio

l(arnataka
Kolkata
Maharashtra
Mumbai
North East
Gujarat
Orissa
Tamil Nadu
Total

~

---------- ­

E; _1C:.20lt.

::_ t;

15.10.201L;
08 _1CJ.201L;

6.0

i
10.10.2014 I

I 10.10. 2014
13 .10. 2014

'l - .

-· ­
1.8
2. 0

!

I

I

15.10.2014
21.10.2014
14 .10.2014
14.10.2014
14 .10.2014
14.10.2014
17.10.2014
14.10.2014
16.10.2014
21.10.2014
13.10.2014
13.10.2014
13.10.2014

I

II

i

5.8
5.4
5.4
5.0
6.4

I
I

5.6
5.0
-5.0
5.0
6.6
6.4
6.0
5.0
6.2
306.6

---·---------­

-~------

II
I

I
i

i
i

I!
1

~

I

I
)

<!-- page 9 -->

Annex urE--1 \i
bane
, De.:ai1s o.:.. sp e:trurr. aliotte c tc ::ne su:::cessru l oidcie rs in 90 0
in rebn.;a ry, 2014 au::tions
I
INamE: of th e If\la me oi I Date of i:ffective QLlantum of
I

l\IJ H~

i

lsu::::::efu i bidder the

ISern;ce

S. No.

j Allotment

date of

Spectrum

Iof Spectrum

allotment

aliotte d in

area

1

2

lv1/s Bharti
Airte l Limited

I
IViumba i

I 10.11.2014 29.11.20141
I 25.11.2014 29.11.2014

5

3

Cellular Ltd

I
6

25.11.2014

30.11.2014

7

Mumbai

26.11.2014 29.11.2014

11

Delhi
Kolkata

M/s Idea

lcil

Kolkata
M/s Vodafone
India Ltd

MHz(unpaire l

II

Delhi

Delhi

I

i 26.11.2014

30.11.2014 \

5

26.11.2014 30.11.2014

7

25.11.2014

5

30.11.2014

I

ii·
i;
:l;

-- -

.·

.

. 1:

;F·­

<!-- page 10 -->

1'

i

'iVPC - \Vinu
b

CDlvlA - Group
Suh.ice!.:· ( luunerly stmemem showing the details of allocations/surrender of spectrum for

CDJvlA service during the quaner ending on 31.12.2013 .
,.

'Jypr.; of
Spectrum

CDMA

Name of
Licensee

Service area

Mis SSTL

Delhi

lvf/s SSTL

Kolkata

Mis SSTL

Gujarat

· Mis SSTL

Karnatalca

Mis SSTL

Tamil Nadu

Mis SSTL

Ker ala

Mis SSTL

West Bengal

M/sSSTL

UP(W)

-----------------

-----------------

I Dme of

Quantum of VlPC letter No. and date
spectrum
(copy may be attached).
allocation
MHz/carriers
S.75·iv1Hz
09.10.2013
J-14025/603/2013-CDlviA
(
dated 09 .10.2013
09.10.2013
3.75 MHz
J-14025/604/2013-CDlvLA
dated 09.10.2013
09.10.2013
3.75 MHz
J-14025/605/2013-CDlvIA
dated 09.10.2013
I
09.10.2013
3.75 lvffiz
J-14025/606/2013-CDM.A.
1·
dated 09.10.2013
09.10.2013
3.75 lvIHz
J-14025/607/2013-CDl\!fA
dated 09.10.20l3
09.10.2013
'3.75 lvffiz . I J-14025/608/2013-CDlvfA
dated 09.10.20.13
I
09.10.2013
3.75 MHz
J-14025/609/2013-CDIVlA .!
dated 09.10.2013
.
09.10.2013
3.75 lvffiz
J-14025/610/2013-CDl\!fA .
dated 09.102013
--NIL-I -------------- ---------------------NIL-I -------------- --------------------

I

I

~

MIN Access
M'VVBB
--·

-----

·=

I
I

==--==========;:=======

-Oi.S.S~

Engineer
for Assistant Wireless Adviser to the Govt. of India
-

·­

ADG(vVR), \VFD Branch, Room no.715,Sanchar Bhawan , New Delhi-110 001
.

.

--------------------~~----------------------------------------------~---------------------------------------

U.O. No. J-14025 /208/2011-CDMA Dated :13/08/2014.

I ;·
