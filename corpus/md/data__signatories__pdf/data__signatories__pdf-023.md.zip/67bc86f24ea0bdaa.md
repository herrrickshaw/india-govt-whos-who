---
doc_id: "67bc86f24ea0bdaa"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/d63e733ee1b6dddf39231aa5e40ec9ad.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of NLD Service Providers As on 15.12.2015"
date: "2015-12-15"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "a035b4a0a0edabe0"
---

<!-- page 1 -->

List of Companies having NLD Service Licence before UL regime. of Companies having NLD Service Licence before UL regime. - PS 02 15:12 205°
= | Name of NLD Licensee Effective Date of
License
la. |
[29.11.2001 |
6. |
(8. |
M/s BT Global Communications India Pvt. Ltd (Formerly M/s_ i2i | 11.07.2006
Enterprises Ltd.)
Il. | M/s Loop Telecom Private Limited (formerly M/s Shippingstop Dot Com | 18.09.2006
(India) Pvt. Lid. (Surrendered on
ale
16. |
17. | M/s BT Telecom India Pvt. Ltd 20.02.2007
(Surrendered on
02.05.208)
18. |
(19. |
22. | M/s Cable & Wireless Networks India Private Limited 15.02.2008
(Applied for
surrender on
02.04.2014)
23. | Ms Orange Business Services India Network Pvt Ltd (Formerly Equant | 20.06.2008
Network Services India Private Limited)
24. | M/s Swan Connect Communications Private 12.08.2008
a Limited (Surrendered on
22.08.2009)
. M/s Videocon Telecommunications Ltd (formerly M/s Datacom Solutions | 18.03.2009
Private Limited)
M/s Unitech Long Distance Communications Services Ltd. 28.04.2009 (Applied
for surrender on
20.10.2014
[11.10.2011 |

<!-- page 2 -->

List of Companies having NLD Service authorization under UL regime. of Companies having NLD Service authorization under UL regime.
Name of Company : Date of Authorisation
No.
[1. | Mis Reliance Jio Infocomm Limited [21.10.2013 |
Ze M/s Telewings Communications Private Limited (name changed to M/s | 21.08.2014
Telenor India Communications Pvt Ltd)
M/s Sprint Telecom India Private Limited 29.08.2014
[ 4. | Mis Sify Technologies Limited 27.06.2014
M/s Hughes Communications India Ltd 02.09.2014
| 6. | M/s Sistema Shyam Teleservices Limited 03.09.2014
M/s NTT Communications India Network Services Private Limited [02.12.2015 SC=«d
Note : Validity period of above NLD Licence is 20 years from effective date of licenses.
