---
doc_id: "a64af940dcbb7a2b"
source_url: "https://www.dot.gov.in/static/uploads/2026/04/383d48b3d3eb752062c951b082f547a0.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Extension of time for Security Certification of Telecom Equipment"
date: "2016-04-01"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "414a30282824262a"
---

<!-- page 1 -->

Department of Telecommunications
(Security Wing)
To
All Telecom Service Providers/ Various service licensees
File No. 1-33/2016/TTSC Dated: 01.04.2016
Subject: Extension of time for Security Certification of Telecom Equipment
within India in respect of License Amendment dated 31.05.2011/3" June’ 2011 for
security related concerns for expansion of Telecom Services in various zones of
the country.
Kindly refer to the License Amendment dated 31.05.2011/3* June’ 2011 and
subsequent licenses issued to telecom service providers to address the national
concerns related to telecom and telecom networks wherein it is inter-alia stated in
the said license amendment that the licensee shall induct only those network
elements into his telecom network, which have been got tested as per relevant
contemporary Indian or international security standards e.g. IT & IT related
elements against ISO/IEC 15408 standards, for information security management
system against ISO 27000 series standards, telecom and telecom related elements
against 3GPP/3GPP2 security standards etc. from any international agency /labs of
the standards e.g. common criteria labs in case of ISO/IEC 15408 standards until
31st March, 2013. From 1s April 2013 the certification was to be got done only from
authorized and certified agencies/labs in India, which was later extended to 1st
April, 2016.
In this regard, the approval of the competent authority on extension of requirement
of security certification of telecom equipment only from authorized and certified
agencies/ labs within India has been received for a period of twelve months from 1*t
April, 2016 to 1st April 2017. Formal amendment will be issued by various licensing
wings in due course.
0%
poate
200
(A.K.MITTAL)
DDG (TTSC-Security)
