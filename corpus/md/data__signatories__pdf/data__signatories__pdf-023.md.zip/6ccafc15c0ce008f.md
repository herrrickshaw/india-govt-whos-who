---
doc_id: "6ccafc15c0ce008f"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/46a4823a02224392be7c069b83559c22.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Circular with reference to order No.12-6/2013-STG-I dated 16.5.2013 and order No 13-15/2013-14/PG &I"
date: "2013-05-16"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2de0fcee8649e3db"
---

<!-- page 1 -->

No.13-15/2013-14/PG& I
Government of India
Department of Telecommunications
Sanchar Bhawan, New Delhi-110001
Dated: 23'dMay, 2013
CIRCULAR
This is with reference to DoT order No. 12-6/2013-STG-I dated 16.5.2013 vide:which officers at SAG
and JAG level have been entrusted with the broad functional responsibilities of different functional
areas, including Public Grievances (PG).
2.

In order to discharge the duties relating to functional responsibilities of PG Wing of DoT,

these officers are required to get themselves acquainted with the present policies, procedures, and
methods which provide the framework for handling the PG functionalities of DoT. Some of the
documents (not exhaustive) which are useful and available in public domain at DoT/TRAl's web sites;
and which may be gone through for the above purpose are as below:­
a.

National Telecom Policy, 2012 document available on DoT website under the icon "Telecom

policy", especially with regard to provisions/ stipulations pertaining to Public grievance (PG)/
Quality of Services (QoS) and all such sections having bearing on PG/QoS.
b.

Compilation of Guidelines for Redressal of Public Grievances- Document issued by

Department of Administrative Reform & Public Grievances, Ministry of Personnel, Public
Grie~ances and

Pensions. The said document which is available on. DARPG's website

(http://pgportal.gov.in/Policy.aspx) contains the Guidelines/provisions issued by the above said
nodal ministry for handling public grievances in Go.vt. of India including Staff Grievances and
Citizen Charter.
c.

TRAI has notified a number of Directions/ Regulations/ Guidelines to address the issues

relating to telecom consumers.The TRAl's web site (www.trai.gov.in) may be visited for detailed
information

on

the

measures

taken

by

TRAI

to

protect

consumer

interest

(http://www.trai.gov.in/Content/mpci.aspx). The important Regulations requiring focussed
attention in this regard are:­
i) "Telecom Complaint Redressal Regulations 2012" issued by TRAI on 05/01/2012, in
replacement of the earlier Telecom Consumers Protection and Redressal of Grievances
Regulation, 2007, for providing speedy, effective and inexpensive redressal of grievances of
consumers by the services provider.
ii) "The Telecom Consumers Protection Regulations, 2012" which provide for various
measures for consumer's protection.

ii) "The Standards of Quality of Service of Basic Telephone Service (wire-line) and Cellular
Mobile Telephone Service Regulations, 2009 (along with subsequent amendments)" which
provide benchmarks for fixed/ mobile services.
iii) The Standards of Quality of Service for Wireless Data Services Regulations, 2012 (26 of
2012) which provide the benchmarks for wireless data services.

<!-- page 2 -->

iv) "Quality of Service (code of practice on metering and billing accuracy) Regulation, 2006"
issued on 21st March 2006, for protecting the interest of consumers relating to metering and
billing.
d. The quarterly performance reports issued by TRAI (which is based on data reported by
service providers to TRAI) in respect of all service providers indicating their performance against
the QoS benchmarks in respect of landline, mobile and broadband services may be gone through
to :assess the status of QoS in respect of the telecom services in. your area. (These reports are
available on TRAI website).
e.

TRAI also publishes report of the independent agencies engaged for the objective

assessment of quality of services and customer satisfaction survev. of Telecom Services in various
License Areas (The document is available on TRAI website). The same may also be gone through
to have a feel of perception of the consumers regarding the services in your area.
f.

DoT has adopted/ implemented the Centralized Public Grievance Redressal and Monitoring

System (CPGRAMS), a web based portal developed and maintained by NIC, Govt. of India, for
handling the Grievances received in DoT. As the officer in the PG Cells would be using this
system, it is requested that the user manual. thereof, available on the DARPG website, may also
be gone through.
3.

As the officers would also be handling the RTI applications of the complainant they are

required to go through the text of RTI Act, 2005 and the provisions therein in order to handle the
same in due Course.

4.

A meeting of all officers entrusted with PG functionalities is proposed to be organised in the

first week of June 2013, to brief and interact with the concerned officers of DoT HQ. During the
proposed meeting, these officers are expected to actively participate in the discussions for evolving
the process of systematic implementation of various aspects linked with broad scope of PG
functionality. Accordingly, all PG officers are requested to acquaint themselves with the above
mentioned documents/ details. The date of the meeting shall be intimated separately.
5.

Further, on getting relieved from TEC/ parent unit, the officers are requested to assume the

charge at their respective places of posting, and submit the charge report in ACG-61 to the
concerned TERM Cell, from where they would be drawing their salary. A copy of the charge
assumption report and contact details may also be sent to DDG PG, DoT HQ.

(V.K. Sethi)
ADG(PG-1)

23036934
Copy to :1. Director (Estt.) TEC % Sr.DDG(TEC) for information & intimation to all concerned.
2. Director (IT) DoT with request to upload the circular on DoT website
3. Office copy.
