---
doc_id: "288ee80e3cdf8daf"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/886aea1de2067d6ff940de9fd160d0f5.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of ILD service providers"
date: "2014-10-10"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f0531633cb3d2b6f"
---

<!-- page 1 -->

List of Companies having ILD Service Licence before UL regime.
SI.
No.
1.
2.

Name of Operator ILD

Mis Reliance Communications Limited
Mis Bharti Airtel Ltd

3.

Mis Data Access (India) LimU(1d
(Licence under suspt•nsiou)

4.
5.

Mis Bharat Sanchar Nigam Ltd.

7.
8.
9.
10.
ll.

MlsTata Communications Ltd.) (Formerly Videsh Sanchar
Nie;am Ltd.)
Mis i2i Enterprises Ltd. (BT Global Communications
India Pvt. Ltd)
Mis AT&T Global Network Services India Pvt. Ltd.
Mis Vodafone South Ltd.
Mis Sify Communications Ltd.
Mis Dishnet Wireless Ltd.
Mis BT Telecom India Pvt. Ltd

12.
13.
14.
15.

Mis Tulip IT Services Ltd.
Mis Soice Communications Ltd.
Mis Verizon Communications India Private Limited
Mis Cable & Wireless Networks India Private Limited

6.

- as on 10.10.2014
Effective Date of
License
25.02.2002
14.03.2002
27.03.2002 (Licence
under suspension
w.e.f. 03.06.2005)
29.01.2003
05.02.2004
11.07.2006

16.
17.
18.

09.10.2006
13.11.2006
21.11.2006
13.12.2006
20.02.2007
(Surrendered on
21.02.2010
06.07.2007
08.08.2007
03.01.2008
15.02.2008 (Applied
for surrender on
02.04.2014)
28.02.2008
18.06.2008
20.06.2008

20.
21.

12.08.2008
(Surrendered on
22.08.20fl'))
03.10.2008
06.10.2008

Mis P3 Technoloe;ies Pvt. Ltd.
Mis Mahanagar Telephone Nigam Ltd.
Mis Orange Business Services India Network Pvt. Ltd
(Formerly Equant Networks Private Ltd).
19. Mis Swan <'"~~·"'Communication Pvt. Ltd

22.
23.
24.
25.
26.
27.

Mis Citicom Networks Pvt. Ltd
Mis Etisalat DB Telecom Pvt Ltd (formerly Mis Swan
Telecom Pvt. Ltd.)
Mis Sine;tel Global (India) Private Ltd.
Mis Videocon Telecommunications Ltd (formerly Mis
Datacom Solutions Private Limited)
Mis Unitech Long Distance Com1nunications Services Ltd.
Mis Pacific Internet India Private Limited
Mis Telstra Telecommunications Pvt. Limited
Mis Infotcl Telecom Limited

05.03.2009
18.03.2009
28.04.20(!9
22.01.2010
11.10.2011
14.02.2012

List of Companies havinJ;. TLD Service authorization nnder UL regime.
SI.

Name of' Companv

Date of Au1h"ri<ation

M/s Bolin<lia Networks India Private Limited

04.06.2014

No.
1.

<!-- page 2 -->

2.
3.
4.

5.

Mis Reliance Jio Infocomm Limited
Mis Telewings Communications Private Limited
Mis Sprint Telecom India Private Limited
Mis Sitv Technologies Limited

21.10.2013
21.08.2014
29.08.2014
27.06.2014

Note : Validity period ofabove JLD Licence is 20 years from effective date oflicenses.
