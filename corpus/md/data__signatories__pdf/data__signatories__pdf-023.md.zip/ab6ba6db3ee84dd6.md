---
doc_id: "ab6ba6db3ee84dd6"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/abf0c1842a4cbd0fd751b76be9ffe510.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Draft Captive VSAT License - 05th July 2007"
date: "2007-07-05"
pages: 31
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "078a579f3f294ed9"
---

<!-- page 1 -->

-1-

GOVERNMENT OF INDIA �
MINISTRY OF COMMUNICATION �
DEPARTMENT OF TELECOMMUNICATIONS �
(TELECOM COMMISSION) �

LICENSE AGREEMENT
FOR �
CAPTIVE VSAT SERVICES
CLOSED USER GROUP DOMESTIC DATA
NETWORK USING INSAT SATELLITE SYSTEM
License No. ____________________
TOTAL PAGES………….

<!-- page 2 -->

-2This AGREEMENT is made on the………day of ________ by and between the President of
India acting through ______________________________________, ADG(SAT-IV),
Department of Telecommunications, Sanchar Bhavan, 20 Ashoka Road, New Delhi –110
001 (hereinafter called the LICENSOR which expression shall, unless repugnant to the
context or subject thereto include its successors in office and assigns) of the FIRST
PARTY.
AND
M/s ………………………………………..., a company registered under
the Companies Act 1956 and having its registered office at……………………………………
………………………………………………… acting though Shri …………………………
……………………………,the authorized signatory (hereinafter called the LICENSEE
which expression shall, unless repugnant to the context to include its successors in business
,administrators , liquidators, legal representatives and assigns ) of the SECOND PARTY.
WHEREAS by virtue of the provision of Section 4 of the Indian Telegraph Act 1885, the
LICENSOR enjoys privilege to grant License and the LICENSEE has requested to grant
License to establish, maintain and operate Captive VSAT Closed Users Group Domestic
Data Network via INSAT Satellite system (hereinafter called the SERVICE). Whereupon
and in pursuance to the said request , the LICENSOR has agreed to grant this License to
establish, maintain and operate Captive VSAT Closed Users Group Domestic Data Network
via INSAT Satellite system (hereinafter called the SERVICE).
NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
1. In consideration of the payment of License fee, and due performance of all terms and
conditions mentioned in this License agreement on the part of the LICENSEE, the
LICENSOR does, hereby grant under section 4 of the Indian Telegraph Act 1885 on a nonexclusive basis, this License to establish, maintain and operate Captive VSAT Closed Users
Group Domestic Data Network via INSAT Satellite system (hereinafter called the
SERVICE).
2. The LICENSE hereby granted will remain valid for 20 (Twenty) years from the Effective
date unless revoked earlier for any reason as provided herein below. The License is
extendable by ten years at a time, at the discretion of the Licensor on request of the
licensee received latest by 19th YEAR from the effective date and in absence of such
request for extension, the License shall automatically be terminated as per due date.
3. The LICENSEE hereby agrees and unequivocally undertakes to fully comply with all
terms and conditions stipulated in this License Agreement and without any deviation or
reservations of any kind.
4. Effective Date of this LICENSE shall be ……………….
5. The License shall be governed by the provision of Indian Telegraph Act, 1885, Indian
Wireless Telegraphy Act, 1933 and Telecom Regulatory Authority of India Act, 1997 as
modified or replaced from time to time. The rules, regulations frame there under.

<!-- page 3 -->

-3IN WITNESS WHEREOF the parties hereto have caused this Agreement to be
executed through their respective authorised representatives on the _________(day)
_______(month), ______ (year).

Signed by Shri ____________________________________ for and on behalf of President of ­
India. ­
(Name) ­
By ADG(SAT-IV) , Department of Telecommunications. ­
Signed on behalf of M/s. _________________________ by Mr. __________________________ ­
(Name and Designation), authorised signatory and holder of General Power of Attorney dated ­
_______________, executed in accordance with the Resolution No. ________________, dated ­
______________ passed by the Board of Directors. ­

( SEAL)
COMMON SEAL of M/s -----------------------i s affixed by Shri---------------------------( Name and Designation )
in the presence of :
(1) --------------------------------------------------( Name and Designation)
(2) ------------------------------------------------ ( Name and Designation)

Copy to:
(i)
(ii)
(iii)
(iv)
(v)
(vi)

Wireless Advisor, WPC, Sanchar Bhawan, N.Delhi.
DDG(LF), DOT, Sanchar Bhawan, N.Delhi.
NOCC, Eastern Court, N.Delhi.
Dy. Director IPO, ISRO HQ, Bangalore, Deptt. Of Space.
Secretary, TRAI, New Delhi.
CCA, Delhi Region, Delhi.

<!-- page 4 -->

-4-

TABLE OF CONTENTS
PAGE NOS.
1. SECTION -1:

SPECIFIC TERMS AND CONDITIONS

2. SECTION-II:

SCOPE OF SERVICE

3. SECTION – III

FINANCIAL CONDITIONS:

4. SECTION-IV:
PART-1
DEFINITIONS, INTERPRETATIONS AND TRANSITIONAL
PROVISIONS RELATING TO THE CONDITIONS
PART II
Condition – 1: OBLIGATIONS OF THE LICENSEE:
Condition –2:

ACCEPTANCE TESTING

Condition- 3:

EXTENSION OF LICENSE

Condition- 4:

TERMINATION OF THE LICENSE

Condition –5: RIGHT TO INSPECT THE SITE
Condition- 6: APPLICATION OF INDIAN
TELEGRAPH ACT.
Condition:- 7: FORCE-MAJEURE ­

<!-- page 5 -->

-5-

PAGE NOS.
Condition- 8: DISPUTES SETTLEMENT

Condition- 9: INTERCONNECTION WITH
OTHER NETWORKS
Condition: 10: LEASING OF THE SPACE
SEGMENT OF INSAT
Condition- 11: WPC WING’S LICENSE
PART III
COMPLIANCE STATEMENT
5. SECTION-V: DEFINITION OF CLOSED USER GROUP
FOR CUG DOMESTIC VSAT NETWORK
6. MONTHLY OPERATION REPORT PROFORMA
FOR VSAT NEWORK (ANNEXURE –I)
7. FINANCIAL BANK GUARANTEE (ANNENXURE- II)

<!-- page 6 -->

-6-

SECTION -1
SPECIFIC TERMS AND CONDITIONS:

1. Unless otherwise mentioned in the subject or context appearing hereinafter all the
Sections/ Annexures of the License agreement and the application for VSAT License along
with certificates/documents submitted along with the said application will form part and
parcel of this agreement and construed as part of this Agreement.
2. In this Agreement words and expressions will have the same meaning as are respectively
assigned to them in the Section IV.
3. The Licensor bears a right to revoke the License by giving 30 days notice in case of any
breach of the terms and conditions of the License, notwithstanding anything contained
contrary anywhere else in the License Agreement and the Licensor’s decision in this matter
will be final.
4. The bank guarantee is to be given by the Licensee in the prescribed proforma ­ at
Annexure –II .
5. The Licensee may transfer or assign the License Agreement with prior written approval
of the Licensor to be granted on fulfillment of the following conditions:(i)
When transfer or assignment is requested in accordance with the terms and
conditions on fulfillment of procedures of Tripartite Agreement if already executed
amongst the Licensor, Licensee and Lenders;
OR
Whenever amalgamation or restructuring i.e., merger or demerger is sanctioned
and approved by the High Court or Tribunal as per the Law in force; in accordance with
the provisions; more particularly of sections 391 to 394 of Companies Act, 1956;
AND
(ii) ­ The transferee or assignee is fully eligible in accordance with eligibility criteria
contained in tender condition or in any other document for grant of fresh license in
that area and shows its willingness in writing to comply with the terms and conditions
of the license agreement including past and future roll out obligations;
AND
(iii) ­ All the past due fully paid till the date of transfer/assignment by the transferor
company and thereafter the transferee company undertakes to pay all future dues
inclusive of any thing remained unpaid of the past period by the outgoing company.
6. It is further agreed and declared that not withstanding anything contained elsewhere, that:-

<!-- page 7 -->

-7-

( i ) The License is issued on non-exclusive basis
( ii ) The Licensor reserves the right to modify at any time the terms and conditions of the
License, if in the opinion of the Licensor it is necessary or expedient to do so in the interest
of the general public or for the proper conduct of telegraphs or on national security
consideration.
(iii) The LICENSOR reserves the right to take over the entire services, equipment and
networks of the LICENSEE, in part or in whole of the Service Area, or
revoke/terminate/suspend the license in the interest of national security or in the event of a
national emergency/war or low intensity conflict or any other eventuality in public interest
as declared by the Government of India. The specific orders or directions from the
Government issued under such conditions shall be applicable to the LICENSEE.
7. The HUB Station shall be operated and maintained by the Licensee subject to the
following conditions:(i) The Licensee is required to provide the details of the equipment, address of the equipment
location and site configuration details on monthly basis from the date of signing of the
License agreement or as and when desired by the Licensor.
(ii) The network Licensee shall, on demand, provide a VSAT capable of monitoring the
network to NOCC/authorized government agency free of cost, as and when desired.
(iii) Before energizing the VSAT network, necessary clearances from INSAT Network
Operations Control Center (NOCC) on payment of prescribed charges will be taken by
licensee. NOCC instructions with regard to space segment access and other relevant
operational matter will have to be obeyed by the licensee.
(iv) The licensee will provide a suitable hot line between network Management Center and
NOCC.
(v) The operation of the hub stations will have to be directly under the control of Licensee.
8. Licensee will be responsible for abiding by all rules, regulations and relevant laws.
9. The financial bank guarantee will be encashed and forfeited for violation of terms and
conditions of License , including commercial use of the network.
10. The Licensor reserves its right to amend or alter the conditions of this license, suo moto,
at any time.
11. Necessary clearances for frequency and siting clearance of earth stations (hub and
VSATs) should be taken from WPC before commencing the operation.
12. The services provided on this ‘Network’ will be for bonafide use of only authorized users
of this Network and will at no time and in no way be commercially exploited or used for
providing such services to any other users not specially authorized by the Licensor
sanctioning the ‘Network’.

<!-- page 8 -->

-813. The ‘Licensee’ of this Network will ensure that operation of systems/equipments on this
network does not cause any harm/loss to Telecom Service Provider. The Licensee will also
ensure that all works on this Network are carried out as per Rules and Regulations and
prescribed parameters of Deptt. of Telecom.
14. The License issued for this Network is only for the specific system/ equipments/ circuits
and services and users mentioned in Annexure-III. Any modification or addition of system/
equipments/circuits and services to the network should be done only after taking permission
of the Licensor. The Licensor reserves the right to revoke such License any time.
15. The licensee will ensure that no communication/message which is prejudical to the
interest of the Nation or to the security of India is passed over any part of this Network.
16. Not withstanding anything contained in the terms and conditions applicable for operation
of the network, the Licensee will not carry such messages on any part of this network which
are prohibited by law and the Licensee will be solely responsible for taking necessary
permission from the authorized agencies of the Government for transmission of such
messages
17. The Licensor reserves its right to monitor any messages transmitted and/or received on
any part of this Network. Facilities for the same will be provided by the licensee at his own
cost.
18. DOT will not be responsible for any loss/harm/damage etc. of any kind to the user/users
of this Network on account of any interruption on BSNL/ Licensed Telecom Service Provider
systems/network.
19. The installation of the Network, including any component thereof, can be inspected by
officers specifically authorized by the Licensor, if he wishes to do so, to ensure that the
prescribed conditions/standards have been adhered to.
20. Violation of any of the terms and conditions mentioned in this License agreement may
lead to termination of License and consequent disconnection of circuits etc.
21. Network will be used only for internal communication requirements of Licensee. VSATs
shall be placed and used inside the premises of the Licensee. Neither users other than
Licensee shall be given access to the network, nor third party traffic shall be carried on the
network.
22. Use of encryption is not normally permitted in the network. In case any encryption is
proposed to be used in the network, the same should be used only after taking specific
permission from the Licensor. Also, the licensee shall make available the encryption
software/ algorithm to the Licensor before using any encryption.
23. The intent of this License is not to grant long distance carrier rights on the Licensee.
24. No inter connection with PSTN/ public/private/value added/any other network is foreseen
in this License agreement except what is specifically permitted.

<!-- page 9 -->

-9-

SECTION-II
Scope of Service
This License is for captive VSAT service.
1.The captive VSAT Closed User Group Domestic Data Network via INSAT Satellite
System shall be restricted to geographical boundaries of India.
2. Network will be used only for internal communication & non-commercial purposes of
Licensee.
3. Neither users other than Licensee shall be given access to the network, nor third party
traffic shall be carried on the network.
4. The intent of this License is not to grant long distance carrier rights.
5. The scope of the service is to provide data connectivity between various sites scattered
throughout India using Very Small Aperture Terminals (VSATs). However, these sites
should form part of a Closed User Group (CUG) as defined in Section-V.
6. Captive VSAT service licensees can set up only one CUG for their own use.
7. A maximum Data Rate upto 512 kbps per VSAT for Star configuration & 2 Mbps for
Mesh configuration (including all carriers) is permitted subject to the compliance of the
Technical parameters as specified in TEC Interface Requirements No. IR/VST-08/02 Dec.
2003.

<!-- page 10 -->

- 10 -

Section – III
Financial Conditions:
1.

Fees payable.

1.1

Entry fee:

The applicant company will be required to pay a one-time entry fee of Rs. 30 lakhs before
signing the License Agreement. Entry fee will not be applicable for the migration to new
regime by existing licensees.
1.2 License Fees:
In addition to the Entry Fee, the licensee shall also pay license fee annually at @ Rs.
10,000/- per annum per VSAT installed. The total number of VSATs shall include all
types of VSATs (receive only/transmit only/ receive & transmit both etc.).
1.3

Radio Spectrum Charges

In addition, the LICENSEE shall also pay fees and Royalty for the use of Radio
frequencies as per the details prescribed by the Wireless Planning & Coordination Wing
(WPC).
1.4
The Licensee shall also pay the space segment charges as applicable from time to
time and secure them through a Financial Bank Guarantee.
2.0 Schedule of payment of license fee:
2.1 For the purposes of the License Fee, the first year shall end on 31st March following the
date of commencement of the License Agreement and the License Fee for the first year shall
be determined on a pro-rata basis for the actual duration of the ‘year’. From second year
onwards, the year shall be of Twelve English calendar months from 1st of April to the 31st
March for payment of License Fee.
Explanation: The license fee for the last quarter of the first year and last quarter of the last
year of the License will be computed with reference to the actual number of days after
excluding the other quarters, each being of three months.
2.2 The license fee shall be payable in four quarterly installments during each Financial Year.
Each quarterly installment shall be paid in advance, 15 days prior to the commencement of
that quarter, duly certified with an affidavit by a representative of the LICENSEE, authorized
by the Board resolution.
2.3 The quarterly payment shall be made together with a STATEMENT indicating the
number of VSATs in use along with their location at the end of each month. The number of

<!-- page 11 -->

- 11 VSATs in use at the end of each month shall be added for all the months of the quarter and
divided by the number of completed months for the purpose of calculation of License Fee.
2.4 The LICENSEE shall adjust and pay the difference between the advance payment made
and actual amount duly payable for a quarter, within 10 days of the completion of the quarter.
2.5 Any delay in payment of license fee or any other dues payable under the license beyond
the stipulated period will attract interest at a rate which will be 2% above the Prime Lending
rate (PLR) of State Bank of India existing on 1st April of that financial year. The interest shall
be compounded monthly and a part of the month shall be reckoned as a full month for the
purposes of calculation of interest.
2.6 In case, any under-reporting in the number of VSATs is detected, it shall attract a penalty
of 50% of the entire amount of short payment. The amount of short payment along with the
penalty shall be payable within 15 days, failing which interest shall be further charged as per
terms of Condition 2.5. The LICENSOR further reserves the right to terminate the license in
addition to the recovery of all dues under the License Agreement.
2.7 The Royalty payable towards WPC Charges shall be payable at such time(s) and in such
manner as the WPC Wing of Ministry of Communications may, prescribe from time to time.
2.8 The quarterly payments shall be made by the LICENSEE through a Demand Draft or Pay
Order payable at New Delhi, drawn on any Scheduled Bank in favour of the Pay & Accounts
Officer (HQ), DOT or any other Authority if so designated by the LICENSOR.
2.9 The LICENSOR reserves the right to verify the number of VSATs installed and in use
from the records of the Licensee or any other records available with it including spot
inspection of Network Management System (NMS).
2.10 The LICENSEE will have to make his own arrangement for all infrastructures involved.
The LICENSEE, shall separately pay the charges for communication resources and other
infrastructure facilities provided by BSNL/ MTNL/ Other Service Providers.

<!-- page 12 -->

- 12 -

1.0 Bank Guarantees:
3.1 The LICENSEE shall submit a Financial Bank Guarantee (FBG) valid for a period of
one year from any Scheduled Bank in India in the prescribed proforma at Annexure-II.
Initially, the Financial Bank Guarantee shall be for an amount of Rs. 30 lakhs which shall be
submitted before signing the License Agreement. Subsequently, the amount of FBG shall be
equivalent to the estimated sum payable annually towards the license fee. The amount of
FBG shall be subject to periodic review by the LICENSOR. (Financial Bank Guarantee is not
applicable in the case of Central Government Departments.) *
3.2 Performance Bank Guarantee is not applicable for captive VSAT networks.
3.3 Initially, the Bank Guarantee shall be valid for a period of one year and shall be renewed
from time to time. The LICENSEE, on its own, shall extend the validity period of the Bank
Guarantee for similar term at least one month prior to its date of expiry without any demand
or notice from the LICENSOR on year to year basis. Any failure to do so shall amount to
violation of the terms of the license and shall entitle the LICENSOR to encash the Bank
Guarantee and to convert into a cash security without any reference to the Licensee and at his
risk and cost. No interest or compensation whatsoever shall be payable by the LICENSOR on
such encashment.
3.4 Without prejudice to its rights of any other remedy, the LICENSOR may encash Bank
Guarantee (FBG) in case of any breach in terms and conditions of the License by the
LICENSEE.

* marked portion is to be added in case of Central Government Departments only. ­

<!-- page 13 -->

- 13 -

SECTION-IV
Part – I
DEFINITIONS, INTERPRETATIONS AND TRANSITIONAL PROVISIONS RELATING
TO THE CONDITIONS
1.

In these conditions unless the context otherwise requires:-

(a) “Effective date” is the date which is so specified in this License agreement.
(b) Licensor shall refer to the President of India acting through any authorized person, who
granted license under Section–4 of Indian Telegraph Act, 1885
and Indian Wireless
Telegraph Act, 1933, unless otherwise specified.
(c) “Message” means anything falling within paragraph 3 of section 3 of the Indian
Telegraph Act 1885, and specifically permitted under this License.
(d) “Service Area” defines the geographical limits within which the Licensee may operate
and offer the Services except the areas specified from time to time by Government of India.
(e) “Technical Specifications” means the specifications referred to as mandatory service
requirement of the related service.
(f) “Authority ” shall refer to the Director General, Telecommunications, Government of
India, and includes any officer empowered by him to perform all or any of the functions of
the Telegraph Authority under the ITA, 1885 or such Authority as may be established by
Law.
(g) “Validity of the License” is the period for which this License may be effective;
(h) “Value Added Service” for the purpose of this Licensee means enhanced
telecommunication service the provision of which necessarily involves both the use of a
telecommunication system and the provision by means of that system of a Service (other
than a directory information service), which is additional to the conveyance (not including
switching) of Messages by means of that system and switching incidental of such
conveyance;
(i) The term “Service” means closed user group captive VSAT domestic Data Network via
INSAT Satellite System.
(j ) “DOT” means the Department of Telecommunications.
(k) “WPC” means Wireless Planning and Coordination wing of Ministry of
Communications.
(l) NOCC” means Network Operation Control Centre.

<!-- page 14 -->

- 14 -

(m) “Closed User Group” is defined as per Section-V.
(n) “VSAT” means Very Small Aperture Terminal.
(o) “Designated Authority” means officials/officers designated by the Authority.
(p) “Captive VSAT License” means the License for those networks in which the equipment
and facilities are owned and operated by Licensee itself for own use. Third party ownership
and provision of services by third party are not permitted under this category of License.
(q) BSNL means Bharat Sanchar Nigam Limited
2. For the purpose of these conditions, reference to the supply of telecommunication
resources do not include the making available of such resources. The telecommunication
resources referred herein would have to be applied for and acquired in the normal course.

<!-- page 15 -->

- 15 SECTION –IV
Part II
Condition
1.

1

OBLIGATIONS OF THE LICENSEE:

1.1 The licensee will provide details of equipment, address of equipment location and site
configuration details on monthly basis to the Licensor from the date of signing of the License
agreement or as and when required by the Licensor.
1.2 The Licensee may apply for and obtain the desired resources from any Licensed Telecom
Service Provider. The operation and tariff for the traffic passed through these resources as
well as provision of these resources shall be governed by the prevailing rules and the
guidelines of the BSNL/ MTNL or other Licensed Telecom Service Provider on the subject.
This does not entitle the Licensee as a matter of right to demand the resources, including
space segment.
1.3 The Licensor reserves the right to revise the procedure of operation of License during its
currency based upon its experience or otherwise without any claims whatsoever on the
Licensor from the Licensee.
1.4 The Licensee shall provide at his own cost technical facilities for accessing any port of
the switching equipment at the HUB or an independent VSAT for interception of the
messages by the designated authorities at a location to be determined by the Licensor.
1.5 The Licensee shall provide a voice communication between the HUB Station and
Network Operation Control Centre of the INSAT System at his own cost.
1.6 Obtaining all type of clearances shall be the licensee’s obligation which will not have any
connection with the payment of License fee as per schedule fixed in the License agreement.
1.7 OWNERSHIP OF THE LICENSEE COMPANY
1.7(a) Foreign Direct Investment (FDI): The Licensee must be an Indian company,
registered under the Indian Companies Act’1956. The Licensee shall ensure that the
total foreign equity in the LICENSEE Company does not, at any time during the
entire LICENSE PERIOD, exceed 74% of the total paid up equity subject to the
following FDI norms:
(i) ­ Both direct and indirect foreign investment in the licensee company shall be
counted for the purpose of FDI ceiling. Foreign Investment shall include
investment by Foreign Institutional Investors (FIIs), Non-resident Indians
(NRIs), Foreign Currency Convertible Bonds (FCCBs), American Depository
Receipts (ADRs), Global Depository Receipts (GDRs) and convertible
preference shares held by foreign entity. Indirect foreign investment shall mean
foreign investment in the company/ companies holding shares of the licensee
company and their holding company/companies or legal entity (such as mutual

<!-- page 16 -->

- 16 funds, trusts) on proportionate basis. Shares of the licensee company held by
Indian public sector banks and Indian public sector financial institutions will be
treated as `Indian holding’. In any case, the `Indian’ shareholding will not be less
than 26 percent.
(ii) FDI up to 49 percent will continue to be on the automatic route. ­FDI in the
licensee company/Indian promoters/investment companies including their
holding companies, shall require approval of the Foreign Investment Promotion
Board (FIPB) if it has a bearing on the overall ceiling of 74 percent. While
approving the investment proposals, FIPB shall take note that investment is not
coming from countries of concern and/or unfriendly entities.
(iii) The investment approval by FIPB shall envisage the conditionality that Company
would adhere to licence Agreement.
(iv) FDI ­shall be subject to laws of India and not the laws of the foreign
country/countries.

1.7 (b) (i) The details of the equity holdings in the LICENSEE Company as disclosed by the
LICENSEE company, are as follows:
Sl. No.

Name of Promoter/Partner

Indian/
Foreign

Equity
%

Net
Worth

1.
2.
3.
(ii) Details of equity holding of the Promoter/Partner Indian Companies of the ­
LICENSEE Company, as disclosed by the LICENSEE company, are as follows: ­
Sl. No.

Name of Promoter/Partner

Indian/
Foreign

Equity
%

Net
Worth

1.
2.
3.
(iii) The LICENSEE shall declare the Indian & Foreign equity holding ( both direct &
indirect) in the LICENSEE company and submit unconditional compliance to
the FDI norms and security conditions on 1st day of January and 1st day of July
on six monthly basis to the LICENSOR. The compliance report should be
certified by the Company Secretary or the Statutory Auditor of the LICENSEE
Company.
1.7(c) There shall be no change in the Indian and Foreign promoter(s) or their equity
participation unless permitted by the LICENSOR. The licensee company may, with

<!-- page 17 -->

- 17 prior written consent of the LICENSOR replace a promoter(s) by another promoter(s)
of equal or higher standing as stipulated below :
•
•
•

an existing foreign promoter may be substituted by another foreign
promoter of similar standing.
The existing Indian Promoter(s) may also be allowed to acquire the foreign
promoter’s shareholding; and
Transfer of equity inter-se between existing Indian promoters may be
permitted, provided the majority Indian promoter continues to hold at least
the present shareholding for a period of five years from the effective date
of LICENSE AGREEMENT. The merger of Indian companies may be
permitted as long as competition is not compromised.

1.8 The LICENSEE shall also ensure that :
(i) ­
(ii) ­

Any change in share holding shall be subject to all necessary statutory
requirements.
Management control of the LICENSEE company shall at all times remain in
Indian hands.

1.9 ­ Change in the name of the LICENSEE Company shall be permitted in accordance
with the provisions under the Indian Companies Act, 1956.
1.10 Security Conditions
(i) The Chief Officer Incharge of technical network operations and the Chief Security
Officer should be a resident Indian citizen.
(ii) Details of infrastructure/network diagram (technical details of the network) could
be provided on a need basis only to telecom equipment suppliers/manufacturers
and the affiliate/parents of the licensee company. Clearance from the licensor
(Department of Telecommunications, Government of India ) would be required
if such information is to be provided to anybody else.
(iii) For security reasons, domestic traffic of such entities shall not be hauled/routed
to any place outside India.
(iv) The licensee company shall take adequate and timely measures to ensure that the
information transacted through a network by the subscribers is secure and
protected.
(v) ­ The officers/officials of the licensee companies dealing with the lawful
interception of messages will be resident Indian citizens.

<!-- page 18 -->

- 18 (vi) The majority Directors on the Board of the company shall be Indian citizens.
(vii) The positions of the Chairman, Managing Director, Chief Executive Officer
(CEO) and/or Chief Financial Officer (CFO), if held by foreign nationals, would
require to be security vetted by Ministry of Home Affairs (MHA). Security
vetting shall be required periodically on yearly basis. In case something adverse
is found during the security vetting, the direction of MHA shall be binding on the
licensee.
(viii) The Company shall not transfer the following to any person/place outside
India:(a) Any accounting information relating to subscriber (Note: it does not restrict
a statutorily required disclosure of financial nature) ; and
(b) User information .
(ix) The Company must provide traceable identity of their subscribers.
(x) ­ On request of the licensor or any other agency authorized by the licensor, the
licensee should be able to provide the geographical location of any subscriber at
a given point of time.
(xi) The Remote Access (RA) to Network would be provided only to approved
location(s) abroad through approved location(s) in India. The approval for
location(s) would be given by the Licensor (DOT) in consultation with the
Security Agencies (IB).
(xii) Under no circumstances, should any RA to the suppliers/manufacturers and
affiliate(s) be enabled to access Lawful Interception System(LIS), Lawful
Interception Monitoring(LIM), Call contents of the traffic and any such sensitive
sector/data, which the licensor may notify from time to time.
(xiii) The licensee ­company is not allowed to use remote access facility for
monitoring of content.
(xiv) Suitable ­technical device should be made available at Indian end to the
designated security agency/licensor in which a mirror image of the remote
access information is available on line for monitoring purposes.
(xv) Complete audit trail of the remote access activities pertaining to the network
operated in India should be maintained for a period of six months and provided
on request to the licensor or any other agency authorised by the licensor.

<!-- page 19 -->

- 19 (xvi) The licensee ­should ensure that necessary provision (hardware/software) is
available in their equipment for doing the Lawful interception and monitoring
from a centralized location.
(xvii) ­ The licensee should familiarize/train Vigilance Technical Monitoring
(VTM)/security agency officers/officials in respect of relevant
operations/features of their systems.
(xviii) It shall be open to the licensor to restrict the Licensee Company from operating
in any sensitive area from the National Security angle.
(xix) In order to maintain the privacy of voice and data, monitoring shall only be upon
authorization by the Union Home Secretary or Home Secretaries of the
States/Union Territories.
(xx) For ­monitoring traffic, the licensee company shall provide access of their
network and other facilities as well as to books of accounts to the security
agencies.
(xxi) The aforesaid Conditions shall be applicable to all the licensees ­ irrespective of
the level of FDI.

Condition 2
2.0 ACCEPTANCE TESTING :
2.1 Mandatory performance verification of HUB Station will be carried out by NOCC or any
other agency authorized by the Licensor for this purpose.
Mandatory performance verification of VSATs will be carried out by NOCC on following
basis:a) Full testing of VSATs with antenna of 3.8m or above .
a) Selective testing of VSATs with antenna of smaller size.
Condition

3

3.0 EXTENSION OF LICENSE :
3.1 The validity of this License is for a period of 20 years unless terminated under Condition
4.0. If requested by the licensee, extension may be granted by the Licensor for a period of 10
year at a time. The decision of the Licensor will be final in the matter. In case the licensee

<!-- page 20 -->

- 20 does not wish to extend the License beyond the expiry period, he will inform the Licensor
accordingly at least 90 days prior to the expiry of the License.
Condition

4

4.0 TERMINATION OF THE LICENSE :
4.1 TERMINATION FOR DEFAULT : ­
The LICENSOR may, without prejudice to any other remedy available for the breach of any ­
conditions of LICENSE, by a written notice of 30 Calendar days issued to the LICENSEE at ­
its registered office, terminate this LICENSE under any of the following circumstances : ­
If the LICENSEE: ­
a) fails to perform any obligation(s) under the LICENSE including timely payments of ­
License fee or other charges due to the LICENSOR; ­
b) fails to rectify, within the time prescribed, any defect as may be pointed out by the ­
LICENSOR. ­
OR
c) performs such activity which are not permitted under this License
4.2 TERMINATION FOR INSOLVENCY :
The Licensor may at any time terminate the License by giving written notice to the Licensee
without compensation to him, if the Licensee becomes bankrupt or otherwise
insolvent.Provided such termination will not prejudice or affect any right of action which has
accrued or will accrue thereafter to the Licensor. The bank guarantee provided by the
licensee will also be encashed and forfeited.
4.3 TERMINATION FOR CONVENIENCE : ­
If the Licensee is to surrender the License, he shall give a notice of 90 days. ­
4.4 TERMINATION FOR TRANSFER OF THE LICENSE : ­
The Licensee shall (clandestinely or otherwise) not transfer the licensing rights granted to
him in any manner whatsoever including sub contracting to any other party, fully or in part.
Any violation will be construed as a breach of License and the License shall be terminated in
accordance with Condition 4.1 hereinabove. The bank guarantee provided by the licensee will
also be encashed and forfeited without prejudice or affect any right of action which has
accrued or will accrue thereafter to the Licensor.
4.1

ACTIONS PURSUANT TO TERMINATION OF LICENSE :

4.5.1 In case of termination of License in terms of clause 4.1 & 4.2 or 4.4 , the Bank
Guarantee provided by the licensee shall be encashed and forfeited.

<!-- page 21 -->

- 21 4.5.2 In case of termination of License for convenience,the Bank Guarantee shall be
returned to the licensee 6 months after the termination of the License and after ensuring
clearance of all dues which the licensee company is liable to pay.
Condition
5.0

5

RIGHT TO INSPECT THE SITE :

5.1 The Licensor, or his authorized representative shall have the right to inspect the sites
wherefrom the Services are extended. The Licensor shall, in particular but not limited to,
have the right to have access to lines, junctions, trunks, terminating interfaces, processing
hardware/software, memories of live, magnetic, optical and any other varieties, wired
options, distribution frames, and to enter into dialogue with Input/Output devices or
terminals. The licensee will provide the necessary infrastructure for continuous monitoring
of the same if required by the Licensor or his authorized representative for national security
reasons. No prior permission/intimation shall be required to exercise the right of Licensor to
carry out the inspection.
5.2 DIRECTIONS FOR MAINTAINING OF DATA ON NETWORK MANAGEMENT
SYSTEM (NMS).
5..21 The information should be maintained in the Network Management System (NMS) in
such a way that by giving simple software command, the data related to the total number of
VSATs configurated/operational with date of commissioning should be available alongwith
their date of configuration, date of commissioning, coordinates, address of the VSAT
locations alongwith the name of city, district, state etc.
5.22 At the time of inspection by representatives of DOT or any one duly authorised by
DOT, it should be possible to take a soft copy of the details of the users.
5.23 Each site should have an identity code no. which should be unique to it and this
should be serially allotted at the time of configuring of new VSATs. While giving the
monthly report of the number of VSATs installed/de-installed during the month, this identity
code should also be mentioned. For the VSATs already existing, as on date, this code should
also be allotted in chronological order. Secondly, this identity code should be available on
the NMS. In case icons are used on NMS (Network Management System) then the data base
corresponding to the icon e.g. identity code, address of VSAT, configuration data,
commissioning date etc. should be easily available and should be maintained on the same
NMS.
5.24 The number of VSATs faulty/non-operational at any given time should be available in
each NMS by giving a simple software command.
5.25 The NMS should be on line i.e. original data in NMS should be available to the
inspecting party. The secondary data bases may be made for the use of the VSAT operator
but for inspection NMS should contain all the requisite information calculated from the data
from NMS only.

<!-- page 22 -->

- 22 5.26 The test sites should not be more than 2% of the total sites in the networks subject to a
maximum of ten sites. Each test site should be clearly named as test site in the NMS along
with the other details.
5.27 There should not be a difference of more than 15 days between configuration
commissioning of VSATs in the NMS.

and

5.28 The monthly report regarding the no. of VSATs at the end of each month being
submitted to LR cell of DOT with copy to Director(NOCC) and Director(Satellite) should be
submitted by the 7th of following month.
5.29 The monthly report being submitted to NOCC/LR cell/satellite cell should be submitted
in both soft copy and hard copy. The proforma is attached as Annexure-I.
5.30 The VSATs which have been closed/ transferred should be immediately deleted from
NMS. Their identity code should not be reused and details of the closure should be intimated
to the LR and Satellite cells of DOT and NOCC in the monthly operation report.
5.31 The compilation of all VSATs working at the end of each calender year with full details
such as ID code, date of commissioning, name and address of user, with Telephone no. and
FAX No. is also required to be submitted in both soft copy and hard copy.
5.32 Each VSAT licensee must provide the documents relating to approvals/ clearance for
the VSAT terminal from the Licensor such as NOCC/WPC.
Condition

6

6.0 Application of Indian Telegraph Act.
.
6.1 The LICENSEE shall adopt all means and facilitate in every manner the application of
the Indian Telegraph Act, 1885 and Indian Wireless Telegraphy Act, 1933 as modified or
replaced from time to time. The Service shall be provided in accordance with the provisions
of Indian Telegraph Rules as modified and amended from time to time.
6.2
As per the provision of Section 5 of Indian Telegraph Act, the licensee will provide
necessary facilities to the designated authorities of Central/State Government as conveyed by
the Licensor from time to time for interception of the messages passing through its network.
Section 5 (2) of the Indian Telegraph Act 1885 reads as under:
“On the occurrence of any public emergency or in the interest of public safety, the Central
Government or a State Government or any officer specially authorized in their behalf by the
Central Government or a State Government may, if satisfied that it is necessary or expedient
to do so in the interest of the sovereignty and integrity of India, the security of the State,
friendly relations with foreign states or public order or for preventing incitement to the
commission of an offense, for reasons to be recorded in writing, by order, direct that any
message or class of messages to or from any person or class of persons or relating to any
particular subject, brought for transmission by or transmitted or received by any telegraph,
shall not be transmitted or shall be intercepted or detained or shall be disclosed to the
Government making the order or an officer thereof mentioned on the order:

<!-- page 23 -->

- 23 Provided that press messages intended to be published in India of correspondents accredited
to the Central Government or a State Government shall not be intercepted or detained, unless
their transmission has been prohibited under this subsection.”
Condition

7

7.0 Force- Majeure
7.1
If at any time, during the continuance of this LICENSE, the performance in whole or
in part, by either party, of any obligation under this is prevented or delayed, by reason of war,
or hostility, acts of the public enemy, civic commotion, sabotage, Act of State or direction
from Statutory Authority, explosion, epidemic, quarantine restriction, strikes and lockouts (as
are not limited to the establishments and facilities of the Licensee), fire, floods, natural
calamities or any act of GOD (hereinafter referred to as EVENT), provided notice of
happenings of any such EVENT is given by the affected party to the other, within 21
Calendar days from the date of occurrence thereof, neither party shall, by reason of such
event, be entitled to terminate the LICENSE, nor shall either party have any such claims for
damages against the other, in respect of such non-performance or delay in performance.
Provided SERVICE under the LICENSE shall be resumed as soon as practicable, after such
EVENT comes to an end or ceases to exist. The decision of the LICENSOR as to whether
the service may be so resumed (and the time frame within which the service may be resumed)
or not, shall be final and conclusive.
7.2
However, the Force Majeure events noted above will not in any way cause extension
in the period of the LICENSE.
7.3
While it will normally not be a ground for non-payment of License Fee, the liability
for payment of License fee for such inoperative period(s) due to force majeure clause may,
however, be reduced/waived by the LICENSOR, at its discretion based on circumstances of
the EVENT.
7.4 Provision of alternative transponder capacity in case of any unforeseen failure of
normally allocated space segment is not guaranteed. In case of failure of space segment an
attempt will be made to provide the space segment from stand by transponder, if any
available to the extent technically feasible. However, no claims for the space segment failure
will be allowed.
Condition
8.0

8

DISPUTES SETTLEMENT:

8.1
As per provisions of Telecom Regulatory Licensor of India Act, 1997 as
amended from time to time, dispute, if any, between:
i)
ii)

the LICENSEE and a Group of Consumers, and
the Licensee and LICENSOR,

shall be settled in Telecom Disputes Settlement and Appellate Tribunal, if such dispute arises
out of or connected with the provisions of the license agreement.

<!-- page 24 -->

- 24 Condition
9
9.0 INTERCONNECTION WITH OTHER NETWORKS :
9.1 Interconnection with any other private/public/value added network except what is
specifically permitted hereinafter will not be done by the Licensee without prior permission
from the Licensor. Also no other service other than the one for which the License is granted
should be made available on this network. The Licensor reserves the right to grant or not to
grant such permission and also the right to impose necessary conditions if the permission is
granted. It is the obligation of the Licensee to ensure that the conditions are not violated by
any of his authorized member of this network.
i) Interconnection with PSTN - Not permitted
ii) Network of other VSATs – Interconnection shall be permitted through the Hub on case
to case basis, wherever the captive CUG nature of the network is not violated.
iii) Terrestrial data lines leased by users of VSATs – Interconnection shall be permitted on
case to case basis, wherever the CUG nature of the network is not violated.
iv)Terrestrial data lines of a public nature:- Interconnection shall be permitted through the
Hub provided it is connected to a public data network such as Internet/ INET.
v) Overseas office of the CUG for data transfer purposes:- Interconnection shall be
permitted on a case to case basis subject to the condition that the connection should be
between the hub and the server of the overseas office through a leased line passing through an
international gateway which can be monitored for security purposes.
vi) VAN Operators:- Interconnection shall be permitted on case to case basis, wherever the
CUG nature of the network is not violated.
vii) Internet/INET:- The hub of VSAT licensee shall be allowed to be connected to an
internet node of his choice through a lease line taken from Telecom service provider who is
authorised to sell bandwidth/ leased line. Similar inter-connection of the Hub with INET is
also permitted.
viii) Other media to provide for redundancy:- Switchover between a terrestrial CUG
network and a VSAT based CUG network belonging to the same licensee shall be permitted
for redundancy purpose.

Condition
10.0.

10

LEASING OF THE SPACE SEGMENT OF INSAT

10.1 The required space segment shall be reserved/allocated on INSAT satellites by
Department of Space (DoS) on the terms and conditions as specified by Department of
Space (DoS) from time to time.

<!-- page 25 -->

- 25 -

10.2 The operation of the space segment will be governed by rules and procedures of
NOCC.
10.3 The space segment charges will be payable to DoS as applicable from time to time.
Condition
11.0

11

WPC WING’S LICENSE

11.1
A separate License shall be obtained by the Licensee directly from the WPC Wing
of Ministry of Communication, which will permit utilization of appropriate radio frequency
spectrum for the establishment and operation of the VSAT Network under usual terms and
conditions of that License. Grant of License will be governed by normal rules, procedures &
guidelines and will be subject to completion of necessary formalities.
11.2 For this purpose, an application shall be made directly to the Wireless Advisor to the
Govt. of India, WPC Wing, Ministry of Communication, Dak Bhawan, Sansad Marg, New
Delhi – 110001 in a prescribed application form available from WPC Wing.
11.3 Siting clearance in respect of HUB Station/VSAT shall be obtained directly from the
WPC Wing for which an applicant shall apply directly to the Secretary, SACFA (Standing
Advisory Committee on Frequency Allocations) in the prescribed application form to the
following address:
The Secretary (SACFA) ­
WPC Wing, Ministry of Communications ­
Sardar Patel Bhawan, Sansad Marg, ­
New Delhi – 110001. ­
(Note: SACFA is the apex body in Ministry of Communications for considering matters
regarding frequency allocations and other related issues. Siting clearance refers to the
agreement of major wireless users for the location of proposed stations from the point of view
of compatibility with other radio systems and aviation hazard. It involves inter-departmental
coordination.)
11.1 ­ License fee and Royalty shall have to be paid for grant of WPC License which will be
as prescribed by WPC and subject to revision from time to time.
11.2The Licensee shall not cause harmful interference to other authorized users of radio
spectrum.
11.6 The Wireless Planning and Coordination (WPC) Wing shall have the right to inspect
from time to time the installations.

<!-- page 26 -->

- 26 -

SECTION—IV
PART III

COMPLIANCE STATEMENT

This company hereby agrees to fully comply with all Financial, Technical, Commercial and
General terms & conditions of License Agreement including amendments/ clarifications
issued by the Department of Telecom without any deviations.

Signature of the authorized signatory of the bidder/operating company.

For and on behalf of
_____________________________
(Name of the company)

<!-- page 27 -->

- 27 -

SECTION-V
Definition of Closed User Group for CUG domestic VSAT network:A Closed User Group is Permissible for following categories of business
associationship:i) Producer of goods and his trader/agent;
ii) Provider of service and his trader/agent;
iii) Producer of same category of goods (e.g. manufactures of petroleum products); and
iv) Provider of the same category of service (e.g. bank).
Provided that ultimate consumer of a service or a product shall not be a part of the Closed
User Group; and provided further that the closed user group is meant for legitimate business
communication purposes of the group.
A Closed User Group can also be formed among a holding company and its subsidiaries or
among interconnected undertakings, these terms being defined as per MRTP Act, 1969
provided that such Closed User Group shall be only for the purposes of legitimate business
communications of the group.

<!-- page 28 -->

- 28 -

ANNEXURE-I
MONTHLY OPERATION REPORT PROFORMA FOR VSAT NEWORK
1. ­
Reporting Month
2. ­
Name of the Network
3. ­
Name of the Hub Station
4.
Number of VSATs in operation at
the end of last month
:
5. ­
Number of VSATs in operation at the
end of month reported
Antenna Size

6. ­
7. ­
8. ­

:
:
:

:

Added during the
month

Withdrawn during
the month

Progressive Total

Power transmitted from Hub
:
Hub U/L EIRP
:
For Star (TDM/TDMA) TDM/FTDMA:

Data Rate
(Kbps)

9.

Out Bound Carriers
Uplink RF
Satellite
Frequency Power
(MHz)
(dBw)

Data Rates
(Kbps)

In Bound Carriers
No. of I/B
Uplink RF Satellite
Carriers
Frequency Power
(MHz)
(dBw)

Number of DAMA/PAMA Carriers ­
Data Rates (Kbps)

No. of Carriers

Satellite Power (dBw)

P
A
M
A
D
A
M
A

10. Any Alteration or addition in the configuration of HUB Station/ VSAT (in detail):
11. ­

Special feature if any:

<!-- page 29 -->

- 29 -

Sl
No

Site
Name
&
Addr
ess

Lon
gitu
de/
Lat
itud
e

Loo
k
An
gle
AZ/
EL

Size
of
VS
AT
in
Mts

Tx/
Rx
In
MH
z

Altitude
Above
MSL in
Mts

Ht of
Antenn
a mast
from
Ground
in Mts

Ht. of
Bldg.
in
Mts

Ht of
Antenn
a mast
from
roof in
Meters

Powe
r in
Watt
s

Date of
Commiss
ioning

<!-- page 30 -->

- 30 -

ANNEXURE-II
FINANCIAL BANK GUARANTEE
To
The President of India
Acting through The Telegraph Authority
In consideration of the President of India (hereinafter called ‘the Authority’) having agreed to
enter into a License agreement with M/s. ……………….. of ……………………. (hereinafter
called ‘the Licensee’) to establish, maintain and operate ---------------------------- service
(hereinafter called ‘the Service’) as per License No/LOI No------------------------------ dated …
……… (hereinafter called the License Agreement) on the terms and conditions contained in
the said License Agreement , which interalia provides for production of a Bank Guarantee to
the extent of Rs-----------------------(Rupees---------------------------only) by way of security
for payment of the License fee as well as such other fees or charges required to be paid by the
Licensee under the License Agreement. We …………………….. (indicate the name and
address and other particulars of the Bank) (hereinafter referred to as ‘the bank’) at the request
of the Licensee hereby irrevocably and unconditionally guarantee to the Authority that the
licensee shall pay all the dues, including but not limited to, the licensee fee, access charges
etc. to the Authority
2. We, the bank, hereby undertake to pay to the Authority an amount not exceeding Rs……
………….. (Rupees ……………………………… only) against any loss or damage caused
to or suffered or would be caused to or suffered by the Authority by reasons of any failure of
the licensee to extend the validity of the guarantee in terms of License agreement, pay all the
above mentioned fees, dues and charges or any part thereof within the period stipulated in the
License Agreement.
.
3. We, the Bank, hereby further undertake to pay as primary obliger and not merely
as surety to pay such sum not exceeding Rs……………….. (Rupees ……………………
only) to the Authority immediately on demand and without demur stating that the amount
claimed is due by way of failure of the licensee to pay any fees or charges or any part thereof
in terms of the said License Agreement.
4. WE, THE BANK , DO HEREBY DECLARE AND AGREE that the decision of
the Authority as to whether Licensee has failed to pay the said License fees or any other fees
or charge or any part thereof payable under the said License Agreement and as to the amount
payable to the Authority by the Bank hereunder shall be final and binding on us.
5. WE, THE BANK, DO HEREBY DECLARE AND AGREE that the
a)
Guarantee herein contained shall remain in full force and effect for a period of
------------------ from the date hereof and that it shall continue to be enforceable till all the
dues of the Authority and by virtue of the said License Agreement have been fully paid and
its claims satisfied or discharged or till Authority satisfies that the terms and conditions of the
said License Agreement have been fully and properly carried out by the said Licensee and
accordingly discharged this guarantee.

<!-- page 31 -->

- 31 b)
The Authority shall have the fullest liberty without our consent and without affecting
in any manner our Agreement or obligations hereunder to vary any of the terms and
conditions of the said License to extend time of performance of any obligations by the said
Licensee from time to time or to postpone for any time or from time to time any of the
powers exercisable by the Authority against the said Licensee and to forbear or to enforce
any of the terms and conditions relating to the said License Agreement and we shall not be
relieved from our liability by reason of any variation or extension being granted to the said
Licensee or forbearance act or omission on the part of the Authority or any indulgence by the
Authority to the said Licensee or to give such matter or thing whatsoever which under the law
relating to sureties would but for this provision, have effect of so relieving us.
c)
Any claim which we have against the Licensee shall be subject and subordinate to the
prior payment and performance in full of all the obligations of us hereunder and we will not
without prior written consent of the Authority exercise any legal right or remedy of any kind
in respect of any such payment or performance so long as the obligations of us hereunder
remains owing and outstanding.
d) This Guarantee shall be irrevocable and the obligations of us herein shall not be
conditional of any prior notice by us or by the Licensee.
6. We the BANK undertake not to revoke this Guarantee during its currency except with the
previous consent of the Authority in writing.
7 Notwithstanding anything contained above, our liability, under the Guarantee shall be
restricted to Rs. ____________ and our Guarantee shall remain in force until --_____ year
from the date hereof. Unless a demand or claim under this Guarantee is made on us in
writing within this date i.e. ______________ all your rights under the Guarantee shall be
forfeited and we shall be released and discharged from all liabilities thereunder.
Dated ……………..day …………………
Witness :
1…………………………………….
2. …………………………………...

for ………………………………..
(name of the Bank)
