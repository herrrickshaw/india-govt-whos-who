---
doc_id: "54adb6acd33e8d0b"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/6a28f8ece69d71e302e4cbcf5d4886b4.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "UL Agreement"
date: "2014-01-08"
pages: 176
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5918c973498a4f10"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF COMMUNICATIONS & IT
DEPARTMENT OF TELECOMMUNICATIONS
SANCHAR BHAWAN, 20, ASHOKA ROAD,
NEW DELHI-110 001, INDIA.

LICENSE AGREEMENT
FOR
UNIFIED LICENSE

NO. ____________________________ DATED ________

TOTAL PAGES ______________

1

<!-- page 2 -->

LICENSE AGREEMENT
FOR
UNIFIED LICENSE

This Agreement is made on the _______ day of ____________ (month),
___________ (year) between the President of India acting through
__________________
(Name & Designation of the Officer), Department of
Telecommunications (DoT), Sanchar Bhawan, 20, Ashoka Road, New Delhi – 110 001
(Hereinafter called the Licensor) of the FIRST PARTY.
AND
M/s __________________, a company registered under the Companies Act 1956,
having its registered office at ______________________________________________
acting through Shri. _______________________, the authorized signatory (hereinafter
called the Licensee which expression shall, unless repugnant to the context, include its
successor in business, administrators, liquidators and assigns or legal representatives)
of the SECOND PARTY.
WHEREAS by virtue of the provisions of Section 4 of the Indian Telegraph Act,
1885, the Licensor enjoys exclusive privilege to grant License for telecom services and
the Licensee has requested the Licensor for grant of Unified License with authorization
for providing services under Chapter …, ... and ….. , Part-II of the Schedule of the
Unified License in the service areas as mentioned in the Table below. Whereupon and
in pursuance to the said request, the Licensor has agreed to grant Unified License with
authorization for provision of services as per terms and conditions described in the
Schedule to the Unified License Agreement, Part-I and Chapters….., …, … and …. of
Part-II for services and service areas as detailed below:

Sl.
No.

Service

Service Area

Chapter of the PART-II of
Schedule

Whereas, Table shown hereinabove is subject to amendment for addition/deletion of
services and service areas in the event of grant of any further service authorization or
revocation / surrender / termination of any of the service authorized under the license,
in accordance with the terms and conditions contained in the schedule to the License.
NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
1.
In consideration of the payment of Entry Fee, License Fee and due performance
of all the terms and conditions mentioned in the above stated Parts and Chapters of this
Unified License on the part of the Licensee, the Licensor does, hereby grant under
Section 4 of the Indian Telegraph Act, 1885 on a non-exclusive basis, this License to
set up and operate the Service(s) in the service areas detailed and described above.
2.
This License shall be valid for a period of 20 years from the effective date of this
License unless revoked earlier for reasons as specified elsewhere in the document.
Validity period for service(s) authorized under any Chapter of Part-II of this Unified
2

<!-- page 3 -->

License, at a later date, shall be co-terminus with the validity period of this Unified
License.
3.
The Licensee hereby agrees and unequivocally undertakes to fully comply with
all terms and conditions stipulated in this License Agreement and without any deviation
or reservations of any kind.
4.

Effective Date of this License shall be ……………….

5.
This Unified License has been granted on non-exclusive basis and additional
Licenses may be issued in any Service Area from time to time in future without any
restriction on number of Licensees with same or different entry conditions.
6.
The License shall be governed by the provision of Indian Telegraph Act, 1885,
Indian Wireless Telegraphy Act, 1933 and Telecom Regulatory Authority of India Act,
1997 and Information Technology Act, 2000, as modified or replaced from time to time
or any other relevant Act.
IN WITNESS WHEREOF the parties hereto have caused this Agreement to be
executed through their respective authorized representatives on the _________(day)
__________(month), ______(year).

Signed for and on behalf of
President of India

Signed on
Behalf of
M/s.______________________

By

By

_____________________
(Name and Designation),
DOT, New Delhi

_______________________
(Name and Designation),
authorized signatory and holder of
General Power of Attorney dated
_______________,
executed
in
accordance with the Resolution No.
________________,
dated
______________ passed by the Board
of Directors. (Company Seal)

In the presence of:
Witnesses:
1. Signature
Name
Occupation.

Address

Place.

2. Signature
Name
Occupation.

Address

Place.

3

<!-- page 4 -->

TABLE OF CONTENTS
Schedule

Page No.
8

: TERMS AND CONDITIONS
PART – I

Chapter I

: General Conditions
Condition 1: Ownership of the Licensee Company
Condition 2: Scope of the License
Condition 3: Duration of License
Condition 4: Renewal of License
Condition 5: Modifications in the Terms and
Conditions of License
Condition 6: Restrictions on ‘Transfer of License’
Condition 7: Provision of Service
Condition 8: Delivery of Service
Condition 9: Requirement to furnish information
Condition 10: Penalty, Suspension, Surrender,
Termination/Revocation of License
Condition 11: Actions pursuant to Termination of License
Condition 12: Force-Majeure
Condition 13: Set Off
Condition 14: Way Leave
Condition 15: Dispute Settlement
Condition 16: Other Conditions

9
9
10
11
11

Chapter II

Commercial Conditions
Condition 17: Tariffs

18
18

Chapter III

Financial Conditions
Condition 18: Fees payable
Condition 19: Definition of ‘Adjusted Gross Revenue’
Condition 20: Schedule of payment of Annual
License Fee and other dues
Condition 21: Bank Guarantees
Condition 22: Preparation of Accounts.

19
19
20
20

Chapter IV

Technical Conditions
Condition 23: Technical Condition
Condition 24: Compliance to Directions/Instructions
Condition 25: The Applicable system
Condition 26: Engineering Details
Condition 27: Network Interconnection
Condition 28: Interface
Condition 29: Quality of Service

25
25
25
26
26
26
27
28

Chapter V

Operating Conditions
Condition 30: Subscriber Registration & Provision of Service
Condition 31: The Subscriber Terminals
Condition 32: Obligations imposed on the Licensee
Condition 33: Sharing of infrastructure
Condition 34: Inspection and Testing of Installations.
Condition 35: Right to inspect
Condition 36: Location of Network Elements
Condition 37: Confidentiality of information
Condition 38: Prohibition of certain Activities by
the Licensee
Security Conditions
Condition 39: Security Conditions

29
29
31
31
31
31
32
32
33

Chapter VI

12
12
13
13
13
13
15
15
16
16
16
16

22
23

33
35
35
4

<!-- page 5 -->

Chapter VII

Condition 40: Application of Indian Telegraph Act

41

Spectrum Allotment and use
Condition 41: Right to use the spectrum
Condition 42: Frequency Allotment

42
42
42

PART- II
Chapter VIII Access Service
Condition 1: Service Area
Condition 2: Scope of Access Service
Condition 3: Financial Conditions
Condition 4: Technical & Operating Conditions
Condition 5: Provision of IPTV Service
Condition 6: Network Interconnection
Condition 7: Emergency & Public Utility Service
Condition 8: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on
‘Statement of Revenue’ & ‘License Fee’
Appendix-II to Annexure-A: Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B : Norms for Preparation of Annual Financial
Statement

45
45
45
47
47
48
50
50
50

Chapter IX

Internet Service
Condition 1: Service Area
Condition 2: Scope of Internet Service
Condition 3: Financial Conditions
Condition 4: Network Interconnection
Condition 5: Provision of Service
Condition 6: Requirement to furnish information
Condition 7: Security Conditions
Condition 8: Monitoring Facilities
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on
‘Statement of Revenue’ & ‘License Fee’
Appendix-II to Annexure-A: Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B : Norms for Preparation of Annual Financial
Statement

64
64
64
65
66
66
67
67
68
70

Chapter X

76
76
76
77
77
78
79

NLD Service
Condition 1: Service Area
Condition 2: Scope of NLD Service
Condition 3: Financial Conditions
Condition 4: Network Interconnection
Condition 5: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on
‘Statement of Revenue’ & ‘License Fee’
Appendix-II to Annexure-A: Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B : Norms for Preparation of Annual Financial
Statement
Chapter XI
ILD Service

54
55
56
63

71
72
75

80
81
83
84
5

<!-- page 6 -->

Condition 1:
Condition 2:
Condition 3:
Condition 4:
Condition 5:
Condition 6:
Annexure-A:

Service Area
Scope of ILD Service
Financial Conditions
Technical Conditions
Network Interconnection
Security Conditions
Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on
‘Statement of Revenue’ & ‘License Fee’
Appendix-II to Annexure-A: Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B : Norms for Preparation of Annual Financial
Statement
Chapter XII GMPCS Service
Condition 1: Service Area
Condition 2: Scope of GMPCS Service
Condition 3: Financial Conditions
Condition 4: Technical Conditions
Condition 5: Roll Out Obligation
Condition 6: Operating Conditions
Condition 7: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on
‘Statement of Revenue’ & ‘License Fee’
Appendix-II to Annexure-A: Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B : Norms for Preparation of Annual Financial
Statement
Chapter XIII PMRTS Service
Condition 1: Service Area
Condition 2: Scope of PMRTS Service
Condition 3: Financial Conditions
Condition 4: Roll Out Obligation
Condition 5: Technical Conditions
Condition 6: Network Interconnection
Condition 7: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on
‘Statement of Revenue’ & ‘License Fee’
Appendix-II to Annexure-A: Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B : Norms for Preparation of Annual Financial
Statement

84
84
85
85
86
87
89

Chapter XIV VSAT CUG Service
Condition 1: Service Area
Condition 2: Scope of VSAT CUG Service
Condition 3: Financial Conditions
Condition 4: Technical Conditions
Condition 5: Roll Out Obligation
Condition 6: Network Interconnection
Condition 7: Performance Testing
Condition 8: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on ‘Statement of

118
118
118
118
119
120
121
122
123

90
91
95
96
96
96
96
97
97
99
99
103

104
105
108
109
109
109
109
110
111
111
112
113
114
115
117

124
6

<!-- page 7 -->

Revenue’ & ‘License Fee’
Appendix-II to Annexure-A:Format of ‘Statement of Revenue’ &
‘License Fee’
Annexure-B: Norms for Preparation of Annual Financial
Statement
Annexure-C: Monthly operation report proforma for
VSAT Network
Chapter XV INSAT MSS-R Service
Condition 1: Service Area
Condition 2: Scope of INSAT MSS-R Service
Condition 3: Financial Conditions
Condition 4: Roll Out Obligation
Condition 5: Technical Conditions
Condition 6: Network Interconnection
Condition 7: Performance Testing
Condition 8: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on ‘Statement of
Revenue’ & ‘License Fee’
Appendix-II to Annexure-A:Format of ‘Statement of Revenue’ & ‘License
Fee’
Annexure-B: Norms for Preparation of Annual Financial
Statement

125

Chapter XVI Resale of IPLC Service
Condition 1: Service Area
Condition 2: Scope of IPLC Service
Condition 3: Financial Conditions
Condition 4: Security Conditions
Annexure-A: Proforma for Affidavit regarding Calculation
Of ‘Revenue’ and ‘License Fee’
Appendix-I to Annexure-A: Format of Auditor’s Report on ‘Statement of
Revenue’ & ‘License Fee’
Appendix-II to Annexure-A:Format of ‘Statement of Revenue’ & ‘License
Fee’
Annexure-B: Norms for Preparation of Annual Financial
Statement

141
141
141
141
142

Annexures to Schedule
Annexure-I
:
Annexure-II :

Annexure-III
Annexure-IV
Annexure-V
Annexure-VI
Annexure-VII

:
:
:
:
:

Definition of Terms and expressions
Details of Minimum Equity, Minimum Networth,
Entry Fee, PBG, FBG and application processing
fee for various Service Authorizations
Proforma for Performance Bank Guarantee
Proforma for Financial Bank Guarantee
Telecom Service Areas
Table Indicating Limits of Penalty Amount
List of Secondary Switching Areas

126
128
129
131
131
131
131
132
133
134
134
134
136
137
138
140

143
144
145
147

148

159
160
163
166
168
169

7

<!-- page 8 -->

SCHEDULE
TO
THE UNIFIED LICENSE AGREEMENT
TERMS AND CONDITIONS

PART- I
[Terms and conditions contained in PART-I shall be applicable for all services provided
under this License, unless specified otherwise in the service specific Chapters in PARTII.]

8

<!-- page 9 -->

CHAPTER-I
GENERAL CONDITIONS
1. Ownership of the Licensee Company:
1.1 1FDI upto 100% with 49% under automatic route and beyond 49% through FIPB
route subject to observance of licensing and security conditions by licensee as well
as investors as notified by the DoT from time to time.
2
(i)
Both direct and indirect foreign investment in the Licensee Company shall be
counted for the purpose of calculating total FDI
3
(ii)
The licensee Company/ Indian Promoters/ Investment Companies including
their holding companies shall comply relevant provisions of extant FDI policy of the
Government. While approving the investment proposals may take into accounts
security concerns.

(iii)
FDI shall be subject to laws of India and not the laws of the foreign
country/countries. The Licensee shall comply with the relevant provisions of FDI policy
of the Government and such modifications to the policy as may be issued from time to
time.

(iv)
The words, mentioned hereinabove in Para 1.1, such as FDI, foreign equity,
investment companies, FIPB etc. shall have the same meaning as defined by
Department of Investment & Industrial Policy (DIPP) in its FDI Policy.

1.2
The Licensee shall declare the Indian & Foreign equity structure (both direct and
in-direct) in the Licensee company and submit a compliance report regarding
compliance of FDI norms and security conditions on 1 st day of January and 1st day of
July of every year to the Licensor in Proforma as may be prescribed from time to time.
This is to be certified by Company Secretary or Statutory Auditor, countersigned by duly
authorized Director of the Licensee Company.

1.3

The Licensee shall also ensure that:

(i)
Any changes in shareholding shall be subject to all applicable statutory
permissions under Laws of India.
(ii)
The Licensee Company shall not hold any other license for the services covered
under the scope of Unified License. In case the Licensee obtains any other License by
way of acquisition or merger, the License so obtained shall have to be migrated and
merged to the aforesaid Unified License as per prescribed procedure.
(iii)
In case the Licensee Company holds/obtains Access Spectrum, the Licensee
Company shall ensure compliance to the crossholding /substantial equity requirement
as per terms and conditions prescribed in Chapter VII of the License.
1

Amended vide DOT letter no 20-271/AS-I (Pt) dated 03.12.2013
Amended vide DOT letter no 20-271/AS-I (Pt) dated 03.12.2013
3
Amended vide DOT letter no 20-271/AS-I (Pt) dated 03.12.2013
2

9

<!-- page 10 -->

1.4
Change in the name of the Licensee Company, as per the provisions of the
Indian Companies Act, 1956, shall have to be intimated to the Licensor in writing along
with certified copy of the name change certificate within 30 days from the date of issue
of such certificate by Registrar of Companies.
1.5
The Licensee shall have a minimum paid up equity capital equal to the sum of
the Paid up Equity Capital required for each Service opted by the Licensee as per
Annexure-II. The requirement under this license for the total minimum paid up equity
capital shall be limited to Rs. 25 Crore (Rupees Twenty five crore only).
1.6 (i) The Licensee shall have a minimum Networth equal to the sum of the networth
required for each Service opted by the Licensee as per Annexure-II. The requirement
under this license for the combined minimum Networth shall be limited to Rs. 25 Crore
(Rupees Twenty five crore only). Net worth shall be as defined in the Companies Act
2013 and as amended from time to time. The networth of promoters/equity share
holders shall not be counted for determining the networth of the company.

1.6 (ii) The Licensee shall declare Paid up Capital and submit a compliance report on
1st day of January and 1st day of July of every year to the Licensor in Proforma as may
be prescribed from time to time. This is to be certified by Company Secretary or
Statutory Auditor, countersigned by duly authorized Director of the Licensee Company.
1.7
The Licensee shall maintain the required minimum paid up equity as per
Annexure-II during the currency of license.
1.8
The Licensee shall provide only those services for which authorization has been
granted in the License Agreement even if total amount of Entry Fee paid equals the
maximum limit and combined minimum requirement of Networth and Paid up Equity
Capital for all services are met.
1.9
At the time of obtaining any additional service authorization during the currency
of the License, all the eligibility requirements will have to be met by the Licensee.
2. Scope of License:
2.1
This License is granted to provide Service(s) as authorized in the License
Agreement and as per the scope defined in relevant chapter(s) of this License
Agreement, on a non-exclusive basis in the Service Area as applicable. Services can
be provided by Licensee on National Level, Telecom Circle/Metro Area Level and
Secondary Switching Area (SSA) Level as specified in Annexure-II. 22 Service Areas
(Telecom Circle/Metro Areas) are defined in Annexure-V. Administration of authorized
services shall be at the respective service area level for all purposes. Secondary
Switching Areas are defined in Annexure-VII
Provided further that the Licensor, of its own or through a Designated Entity shall
always have the right to operate the Service anywhere in India including the licensed
area for which this License is granted. The Licensor reserves the right to add additional
chapters to introduce new services
Names of various service areas and the geographical areas covered under them
are enclosed as Annexure-V.
10

<!-- page 11 -->

2.2(i) The Licensee may establish, operate and maintain Telecommunication Networks
and telecommunication services using any technology as per prescribed standards in
the service area as per scope of services authorized under this License. In case, the
Licensee obtains Access Spectrum, the terms and conditions of the allotment of
spectrum regarding use of technology shall be applicable.
(ii)
For providing the Service the Licensee shall utilize any type of equipment and
product that meet TEC standards, wherever made mandatory by the Licensor from time
to time. In the absence of mandatory TEC standard, the Licensee may utilize only those
equipment and products which meet the relevant standards set by International
standardization bodies, such as, ITU, ETSI, IEEE, ISO, IEC etc.,; or set by International
Fora, such as 3GPP, 3GPP-2, IETF, MEF, WiMAX, Wi-Fi, IPTV, IPv6, etc. as
recognized by TEC and subject to modifications/adaptation, if any, as may be
prescribed by TEC/Licensor from to time.
(iii) The Licensee shall not provide any service / services which require a separate
authorization/license unless specifically provided for in the chapters for services
authorized in this License Agreement.
(iv) The Licensee shall not provide broadcasting services under this License, for which
a separate License / registration is required as per Cable TV Networks (Regulation) Act
1995 and guidelines for DTH License or any other broadcasting service issued by
Ministry of Information and Broadcasting. However, provision of IPTV is permitted
under the service authorization of Access Service/Internet Service.
(v) It is obligatory upon the Licensee to provide the services by establishing a state-ofthe-art digital network.
2.3
The mode of ownership of subscribers’ terminal equipment will be at the option
of the subscriber.
2.4
Licensee shall make its own arrangements for all infrastructure involved in
providing the service and shall be solely responsible for the installation, networking,
operation and commissioning of necessary infrastructure, equipment and systems,
treatment of subscriber complaints, issue of bills to its subscribers, collection of
revenue, attending to claims and damages arising out of its operations etc. However,
the Licensee may share the infrastructure as permitted under the scope of respective
service authorization in PART-II of the Schedule to the License Agreement or as per
the directions/instructions issued by the Licensor from time to time.
3.

Duration of License:

3.1
This License shall be valid for a period of 20 years from the effective date of this
License unless revoked earlier for reasons as specified elsewhere in the document.
Validity period of any authorization of additional service(s) under this license shall be
co-terminus with the validity period of this license.
4.

Renewal of License:

4.1
The Licensor may renew, if deemed expedient, the period of License by 10 years
at one time, upon request of the Licensee, if made during the 19th year of the license
period, on the terms specified by the Licensor, subject to extant policy. The decision of
the Licensor shall be final and binding in this regard.
11

<!-- page 12 -->

4.2
On renewal, the Licensee may be required to pay a renewal fee as may be
notified by the Licensor.
5.

Modifications in the Terms and Conditions of License:

5.1
The Licensor reserves the right to modify at any time the terms and conditions of
the License, if in the opinion of the Licensor it is necessary or expedient to do so in
public interest or in the interest of the security of the State or for proper conduct of the
Telegraphs. The decision of the Licensor shall be final and binding in this regard.
6.

Restrictions on ‘Transfer of License’:

6.1
The Licensee shall not, without the prior written consent of the Licensor as
described below, either directly or indirectly, assign or transfer this License in any
manner whatsoever to a third party or enter into any agreement for sub-License and/or
partnership relating to any subject matter of the License to any third party either in
whole or in part i.e. no sub-leasing/partnership/third party interest shall be created. For
provision of the service by the Licensee, the Licensee may appoint or employ
franchisee, agents, distributors and employees.
6.2
The Licensor shall have the right to direct the Licensee to warn, penalize or
terminate the services of the franchisee or agent or distributor servant, after considering
any report of conduct or antecedents detrimental to the security of the nation. The
decision of the Licensor in this regard shall be final and binding and in any case the
Licensee shall bear all liabilities in the matter and keep the Licensor indemnified for all
claims, cost, charges or damages in this respect.
6.3
Intra service area mergers and acquisitions as well as transfer of licenses shall
be subject to the guidelines issued on the subject from time to time by the Licensor.
6.4
Further, the Licensee may transfer or assign the License Agreement with prior
written approval of the Licensor, in the following circumstances, and if otherwise, no
compromise in competition occurs in the provisions of Telecom Services:(i)(a) When transfer or assignment is requested in accordance with the terms and
conditions on fulfillment of procedures of Tripartite Agreement if already executed
amongst the Licensor, Licensee and Lenders; or
(i)(b) Whenever amalgamation or restructuring i.e. merger or demerger is sanctioned
and approved by the High Court or Tribunal as per the law in force; in accordance with
the provisions; more particularly Sections 391 to 394 of Companies Act, 1956; provided
that scheme of amalgamation or restructuring is formulated in such a manner that it
shall be effective only after the written approval of the Licensor for transfer/merger of
Licenses, and
(ii)
Prior written consent/No Objection of the Licensor has been obtained for transfer
or merger of Licenses as per applicable guidelines issued from time to time. Further,
the transferee/assignee is fully eligible in accordance with eligibility criteria as
applicable for grant of fresh License in that area and show its willingness in writing to
comply with the terms and conditions of the License agreement including past and
future roll out obligations as well as to comply with guidelines for transfer/merger of
Licenses including for charges as applicable; and

12

<!-- page 13 -->

(iii)
All the past dues are fully paid till the date of transfer/assignment by the
Transferor Company and Transferee Company; and thereafter the transferee company
undertakes to pay all future dues inclusive of anything remained unpaid of the past
period by the outgoing company.
[NOTE: The format of the Tripartite Agreement shall be provided by the Licensor as and
when requested by the Licensee and the Tripartite Agreement, if signed, shall become
part of this License agreement as annexure.]
7.

Provision of Service:

The Licensee shall be responsible for, and is authorized to own, install, test and
commission all the Applicable systems for providing the Service authorized under this
License agreement. The Licensee shall intimate to the Licensor well in advance before
the proposed date of commencement of any service in any Service Area containing the
details of network and required facilities for monitoring of the service installed by the
Licensee. Any service, permitted under the scope of this License Agreement, shall be
commenced by the Licensee only after prior approval of the Licensor. The approval
shall normally be granted within 90 days from the date of receipt of such intimation
provided that the Applicable System/Service is broadly compliant to the scope of the
License and requisite monitoring facilities are successfully demonstrated by the
Licensee.
8.

Delivery of Service (Service to subscriber):

The Licensee shall intimate the Licensor and TRAI of Commencement of Service
within 15 days of such commencement.
9.

Requirement to furnish information:

9.1
The Licensee shall furnish to the Licensor/TRAI, on demand in the manner and
as per specified timelines such documents, accounts, estimates, returns, reports or
other information in accordance with the rules/ orders as may be prescribed or as
directed from time to time. The Licensee shall also submit information to TRAI as per
any order or direction or regulation issued from time to time under the provisions of
TRAI Act, 1997 as amended from time to time.
10.

Penalty, Suspension, Surrender, Termination/Revocation of License:

10.1 (i) The Licensor may impose a financial penalty not exceeding the amount shown
in Annexure-VI for each service as per applicable service area per occasion for
violation of terms and conditions of license agreement. This penalty is exclusive of
Liquidated Damages, if any, as prescribed in this License Agreement.
10.1 (ii) The Licensor reserves the right to suspend the operation of this
License/Service Authorization in whole or in part, at any time, if, in the opinion of the
Licensor, it is necessary or expedient to do so in public interest or in the interest of the
security of the State or for the proper conduct of the Telegraph. License Fee payable to
the Licensor will not be required to be paid for the period for which the operation of this
License remains suspended in whole. Provided that if situation so warrants, the
Licensor may dispense with the issue of notice prior to such suspension. The decision
of the Licensor shall be final and binding in this regard.

13

<!-- page 14 -->

Provided further that the Licensor shall not be responsible for any damage or loss
caused or arisen out of aforesaid action. Provided also that the suspension of the
License shall not be a cause or ground for extension of the period of the License and
suspension period will be taken as period spent.
10.2 (i) The Licensor may, without prejudice to any other remedy available for the
breach of any conditions of License, by a written notice to the Licensee at its registered
office, terminate/revoke this License in whole or in part or any of the authorized
service(s) under any of the following circumstances :
If the Licensee:
a)

fails to perform any obligation(s) under the License including timely
payments of fee and other charges due to the Licensor, including
securitization of dues;

b)

fails to rectify, within the time prescribed, any defect/deficiency/correction
in service/equipment as may be pointed out by the Licensor/TRAI.

c)

goes into liquidation or ordered to be wound up.

d)

is recommended by TRAI for revocation of License for non-compliance of
the terms and conditions of the License.

e)

fails to comply with FDI norms.

f)

has furnished information/ certificates for obtaining the license which is
found false at any stage.

For this purpose, the Licensor shall issue a show cause notice of 21 days to the
Licensee. If the Licensor decides to revoke the license, the same will be effective from
the 61st calendar day from the date of issue of such termination/revocation order. The
Licensee shall be required to give a notice of at least 30 Calendar days to its customers
within this period of revocation order.
10.2(ii) In case of suspension or termination/revocation of the License / authorized
service, the Licensor may also impose a financial penalty not exceeding the amount
shown in Annexure-VI for each service per service area for violation of terms and
conditions of license agreement.
10.3 Licensee may surrender the License or any service authorization under this
License, by giving notice of at least 60 Calendar days in advance. In that case it shall
also notify all its subscribers by sending a 30 Calendar days notice to each subscriber.
The Licensee shall pay all fees payable by it till the date on which the surrender of the
License/Service authorization becomes effective. The effective date of such surrender
shall be 61st Calendar days counted from the date of receipt of such notice by the
Licensor, if it is not rejected by the Licensor within 30 days of date of receipt of the
notice.
10.4 The Licensor reserves the right to terminate/revoke/suspend the License or any
authorized service under this License, in whole or in part, at any time in the interest of
public by giving a notice of 60 Calendar days from the date of issue of such notice.
Provided that, in the interest of national security or in the event of national
14

<!-- page 15 -->

emergency/war or low intensity conflict or similar type of situations, the Licensor has the
right to revoke/suspend the License or any authorized service under this License, in
whole or in part, without any notice period.
10.5 The Licensor reserves the right to take over the services, equipment and
networks of the Licensee in the interest of national security or in the event of national
emergency/war or low intensity conflict or similar type of situations in full or in part in the
Service area. Further the Licensor reserves the right to keep any area out of the
operation zone of the Service if implications of security so require.
10.6 Breach of non-fulfillment of License conditions may come to the notice of the
Licensor through complaints or as a result of the regular monitoring. Wherever
considered appropriate Licensor may conduct an inquiry either suo-motu or on
complaint to determine whether there has been any breach in compliance of the terms
and conditions of the License by the Licensee. The Licensee shall extend all
reasonable facilities to conduct inquiry.
10.7 It shall be the responsibility of the Licensee to maintain the Quality of Service,
even during the period when the notice for surrender/revocation of License is pending
and if the Quality of Service is not maintained, during the said notice period, it shall be
liable to pay damages. The quantum of damages and to whom payable shall be
determined by the TRAI. Further, it shall also be treated as material breach liable for
action under Clause 10.1 and 10.2 of the License. The Licensee shall also be liable to
pay the License Fee till the end of the notice period and more specifically till the date on
which the surrender/revocation becomes effective.
11. Actions pursuant to Revocation of License:
11.1 If under the License Agreement, material event occurs which entitle the Licensor
to revoke the License Agreement, the Licensor shall proceed in accordance with the
terms and conditions provided in the Tripartite Agreement read with the License
agreement wherever such agreement is executed and signed. In cases where no such
Tripartite agreement is signed the action will be taken as per the Condition 11.2 below.
11.2 On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank Guarantee(s)
shall be released to the Licensee only after ensuring clearance of all dues, which the
Licensee is liable to pay to the Licensor. In case of failure of the Licensee to pay the
amounts due to the Licensor, the outstanding amounts shall be realized through
encashment of the Bank Guarantees without prejudice to any other action(s) for
recovery of the amounts due to the Licensor without any further communication to the
Licensee.
12.

Force- Majeure:

12.1 If at any time, during the continuance of this License, the performance in whole
or in part, by either party, of any obligation under this is prevented or delayed, by
reason of war, or hostility, acts of the public enemy, civic commotion, sabotage, Act of
State or direction from Statutory Authority, explosion, epidemic, quarantine restriction,
strikes and lockouts (as are not limited to the establishments and facilities of the
Licensee), fire, floods, natural calamities or any act of GOD (hereinafter referred to as
EVENT), provided notice of happenings of any such EVENT is given by the affected
party to the other, within 21 Calendar days from the date of occurrence thereof, neither
party shall, by reason of such event, be entitled to revoke this Agreement, nor shall
15

<!-- page 16 -->

either party have any such claims for damages against the other, in respect of such
non-performance or delay in performance. Provided Service under the License shall be
resumed as soon as practicable, after such EVENT comes to an end or ceases to exist.
The decision of the Licensor as to whether the service may be so resumed (and the
time frame within which the service may be resumed) or not, shall be final and binding.
12.2 However, the Force Majeure events noted above will not in any way cause
extension in the period of the License.
12.3 While it will normally not be a ground for non-payment of License Fee, the
liability for payment of License fee for such inoperative period(s) due to force majeure
clause may, however, be reduced / waived by the Licensor, at its discretion based on
circumstances of the EVENT.
13.

SET OFF:

13.1 In the event any sum of money or claim becomes recoverable from or payable
by Licensee to the Licensor either against this License Agreement or otherwise in any
manner, such money or claim can be (without restricting any right of set off for counter
claim given or employed by law) deducted or adjusted against any amount or sum of
money then due or which at any time thereafter may become due to the Licensee
under this License Agreement or any other agreement or contract between the Licensor
and the Licensee.
13.2 The aforesaid sum of money payable to the Licensee Company shall include any
security/ bank guarantee which can be converted into money.
13.3 After exercising the right of set off, the Licensor shall inform the Licensee of the
action taken.
14.

Way Leave:

The Licensee Company shall make its own arrangements for Right of Way
(ROW). In exercise of the provisions of the Section 19 B of the Indian Telegraph Act,
1885, the Central Government, vide Notification dated 24.5.1999, has conferred the
powers upon the duly authorized Licensee(s), licensed under Section 4 of the said Act,
to seek way-leave from any person including public authority, in connection with
providing the services, as per details mentioned in the said Notification. However, nonavailability of the ROW or delay in getting permission / clearance from any agency shall
not be construed or taken as a reason for non-fulfillment of the Roll-out obligations, if
any and shall not be taken a valid excuse for not carrying any obligations imposed by
the terms of this License or conditions of spectrum allotment.
15.

Dispute Settlement:

All disputes relating to this License will be subject to jurisdiction of Telecom
Disputes Settlement and Appellate Tribunal (TDSAT) as per provisions of TRAI Act,
1997 as amended from time to time. Dispute in any matter outside the domain of
TDSAT will lie in the jurisdiction of competent Courts in NCT of Delhi only.
16.

Other Conditions:

16.1 The Licensee shall be bound by the terms and conditions of this License
Agreement as well as instructions as are issued by the Licensor and by such
16

<!-- page 17 -->

orders/directions/regulations of TRAI as per provisions of the TRAI Act, 1997 as
amended from time to time.
16.2 The Licensee shall also be bound by the prevailing instructions / directions /
orders issued in respect of a service by the Licensor/ TRAI, if the same service is also
being provided by the Licensee to its subscribers.
16.3 The statutory provisions and the rules made under Indian Telegraph Act 1885 or
Indian Wireless Telegraphy Act, 1933 or Information Technology Act, 2000 or ,TRAI Act
1997 and the rules and regulations there under shall govern the provision of service
under this license agreement. Any order passed under these statutes shall be binding
on the licensee.

17

<!-- page 18 -->

CHAPTER-II
COMMERCIAL CONDITIONS
17.

Tariffs:

17.1 The Licensee will charge the tariffs for the Service as per the Tariff orders /
regulations / directions/decisions issued by TRAI from time to time. The Licensee shall
also fulfill requirements regarding publication of tariffs, notifications and provision of
information as directed by TRAI through its orders / regulations / directions issued from
time to time as per the provisions of TRAI Act, 1997 as amended from time to time.

18

<!-- page 19 -->

CHAPTER-III
FINANCIAL CONDITIONS
18.

FEES PAYABLE:

18.1

Entry Fee:

18.1.1
A one-time non-refundable Entry Fee for each authorized Service shall
be paid as per Annexure-II. The total amount of Entry fee shall be subject to a
maximum of Rs. 15 Crore (Rupees Fifteen crore only).
18.2

License Fee:

18.2.1
In addition to the Entry Fee, an annual License fee as a percentage of
Adjusted Gross Revenue (AGR) shall be paid by the Licensee service-area wise, for
each authorized service from the effective date of the respective authorization. The
License fee shall be 8% of the AGR, inclusive of USO Levy which is presently 5% of
AGR.
Provided that from Second Year of the effective date of respective authorization,
the License fee shall be subject to a minimum of 10% of the Entry Fee of the respective
authorized service and service area as in Annexure-II.
18.2.2
In case the Licensee obtains access spectrum for operation of any
authorized service in a service area, a ‘presumptive AGR’ for that authorized service
and service area shall be arrived at in accordance with the relevant provisions of the
Notice Inviting Application (NIA) document of the auction of spectrum or conditions of
spectrum allotment/LoI as the case may be. The License Fee based on presumptive
AGR shall be applicable from the date of issue of Letter of Intent earmarking such
spectrum or the effective date of the license/authorization, whichever is later. The
Licensee shall, in such cases, pay the license fee on the presumptive AGR or actual
AGR or the minimum license fee referred in condition 18.2.1, whichever is higher.
In case, the Licensee obtains spectrum for any service and service area in
different bids, the total presumptive AGR shall be the sum of the presumptive AGRs
calculated on the basis of the respective Bid amounts as prescribed in the respective
NIA or conditions of spectrum allotment/LoI as the case may be.
Provided that, for the spectrum obtained in the auctions conducted in November
2012 and March 2013, the presumptive AGR, for Access services shall be equal to 5%
of sum of the total bid amount by the Licensee for the respective Service Area.
18.2.3
The Licensor reserves the right to modify the above mentioned License
fee as percentage of AGR any time during the currency of this agreement.
18.3

Spectrum Related Charges:

In case the Licensee obtains spectrum, the licensee shall pay spectrum related
charges, including payment for allotment and use of spectrum, as per provisions
specified in the relevant NIA document of the auction of spectrum or conditions of
spectrum allotment/LoI/directions/instructions of the Licensor/WPC Wing in this regard.
The spectrum related charges shall be payable in addition to the License fee.
19

<!-- page 20 -->

18.4

Space Segment Charges:

18.4.1
In case of Satellite based service, the space segment charges will be
payable to Department of Space (DoS) as applicable and/or as may be specified from
time to time.
18.4.2
The space segment monitoring charges shall be payable to Network
Operations Control Centre (NOCC) by Licensee as per the rates decided by the
Licensor from time to time.
19.

Definition of ‘Adjusted Gross Revenue’:

19.1 The Gross Revenues and Adjusted Gross Revenue (AGR) for the purpose of
calculation of License fee for different services authorized under this license are
defined in the respective chapters of the Service in PART-II of this Schedule. .
20.

Schedule of payment of ANNUAL LICENSE FEE and other dues:

20.1 License Fee shall be payable in four quarterly installments during each financial
year (FY) commencing 1st of April.
20.2 The quarter in which the effective date of license/authorization falls, shall end on
the usual end date of that quarter for the purpose of license fee. The quarters where the
minimum license fee or license fee based on presumptive AGR becomes applicable,
and the last quarter of the license period, may not be of full three months, but of part
period only.
[Explanation:
(i)
For license/authorization with effective date on 13th July, the quarter will end
on 30th September.
(ii)
In such case the minimum license fee would become applicable w.e.f. 13th of
July next year and the quarter shall end on the following 30 th September.]
20.3 The minimum license fee or the license fee based on presumptive AGR, as may
be applicable, as per conditions 18.2.1 and 18.2.2, for the above part-periods, shall be
charged on pro-rata basis, based on actual number of days in the part period of the
Quarter.
20.4 License Fee shall be payable in four quarterly installments during each financial
year (FY). Quarterly installment of license fee for the first three quarters of a financial
year shall be paid within 15 days of the completion of the relevant quarter. The AGR
based license Fee shall be paid by the Licensee on the basis of revenue on accrual
basis for the quarter, duly certified with an affidavit by a representative of the Licensee
who is authorized by the Board Resolution coupled with General Power of Attorney.
However, for the last quarter of the financial year, the Licensee shall pay the License
Fee by 25th March on the basis of expected revenue for the quarter, subject to a
minimum payment equal to the revenue share paid for the previous quarter.
20.5 The Licensee shall adjust and pay the difference between the advance payment
made and actual amount duly payable for the last quarter of financial year within 15
days of the end of the quarter.
20

<!-- page 21 -->

20.6 The quarterly payment shall be made with an affidavit as at Annexure-A of the
respective Chapter of service authorization together with a STATEMENT OF
REVENUE SHARE AND LICENSE FEE separately for each service and service area in
the Proforma prescribed at Appendix-II to Annexure-A of the respective chapter of the
service, showing the computation of revenue and License fee payable. The aforesaid
quarterly STATEMENTS of each year shall be required to be audited by the Auditors
(hereinafter called Licensee’s Auditors) appointed by the Licensee under Section 224 of
the Companies’ Act, 1956. The report of the Auditor should be in the prescribed form
as per Appendix-I to Annexure-A of the respective Chapter of service authorization.
20.7 Any delay in payment of License Fee, or any other dues payable under the
License beyond the stipulated period will attract interest at a rate which will be 2%
above the Prime Lending Rate (PLR) of State Bank of India existing as on the
beginning of the Financial Year (namely 1st April) in respect of the license fees
pertaining to the said Financial Year. The interest shall be compounded monthly and a
part of the month shall be reckoned as a full month for the purposes of calculation of
interest. A month shall be reckoned as an English calendar month.
20.8 Final adjustment of the License fee for the year shall be made on or before 30 th
June of the following year, based on the gross revenue figures, the minimum License
Fee or the License fee based on Presumptive AGR, which shall be submitted by the
Licensee, duly certified by the AUDITORS of the Licensee in accordance with the
provision of the Companies’ Act, 1956.
20.9 A reconciliation between the figures appearing in the quarterly statements
submitted in terms of the Condition 20.4 of the License Agreement with those
appearing in annual accounts shall be submitted along with a copy of the published
annual accounts audit report and duly audited quarterly statements within 7 (seven)
Calendar days of the date of signing of the audit report. The annual financial account
and the statement as prescribed above shall be prepared following the norms as
prescribed in Annexure-B of the respective Chapter of service authorizations. The
statements and accounts submitted shall be assessed and verified by the Licensor and
through its units namely Offices of Controller of Communication Accounts in respective
service areas, as may be notified from time to time.
20.10 In case, the total amount paid as quarterly License Fee for the 4 (four) quarters
of the financial year, falls short by more than 10% of the payable License Fee, it shall
attract a penalty of 50% of the entire amount of short payment. However, if such short
payment is made good by the licensee on its own within 60 days from the last day of
the financial year, no penalty shall be imposed. In case demand for such shortfall is
made by the licensor after assessment and verification as per condition 20.7, such
amount shall be paid along with penalty within 15 days of issue of such demand, failing
which interest shall be further charged as per terms of Condition 20.5.
20.11 All the charges relating to spectrum shall be payable at such time(s) and in such
manner as prescribed from time to time by the Licensor/WPC Wing.
20.12 All sums becoming due and payable as mentioned in this License Agreement
shall be paid by the Licensee, service and service area wise, through e-transfers or
demand draft or Pay Order payable at New Delhi, drawn on any Scheduled Bank, in
favour of the Pay & Accounts Officer (HQ), DOT or at the designated office of the
Controller of Communication Accounts in service areas as may be designated by the
Licensor from time to time.
21

<!-- page 22 -->

20.13 The Licensee shall separately pay the access charges for carriage of calls
originating in its network but carried and terminated in the other Telecom Service
Providers’ networks. The Licensee shall also separately pay charges for network
resources obtained by the Licensee from other licensed service providers. This will be
governed by mutual agreement and/ or determination of TRAI, if any.
21.

BANK GUARANTEES:

21.1

Performance Bank Guarantee:

Performance Bank Guarantee (PBG) in prescribed format at Annexure-III of this
license agreement shall be submitted separately for each service and service area for
the amount as per Annexure-II, subject to a maximum of Rs 220 Crore initially, before
signing the License Agreement or subsequent authorization of service(s), as the case
may be, valid for one year, from any scheduled bank or public financial institution duly
authorized to issue such bank guarantee, to cover violation of license conditions and to
ensure the performance under the license agreement including compliance of
instructions issued by the Licensor from time to time. The PBGs shall be maintained
and kept valid by the licensee during the entire currency of the license agreement.
However, the Licensor may increase the value of PBGs whenever any demand is
raised for non-compliance of terms and conditions of License/authorization to the extent
it remains un-securitized by the existing PBGs, which shall be maintained till clearance
of such demand by the licensee.
21.2

Financial Bank Guarantee:

The Licensee shall submit Financial Bank Guarantee (FBG) separately for each
service and service area for the amount as per Annexure-II, subject to a maximum of
Rs 44 Crore initially before signing the License Agreement or subsequent authorization
of service(s), as the case may be, valid for one year, from any Scheduled Bank or
Public Financial Institution duly authorized to issue such Bank Guarantee, in the
prescribed Proforma at Annexure IV of this license agreement. Subsequently, the
amount of FBG shall be equivalent to the estimated sum payable equivalent to License
fee for two quarters and other dues not otherwise securitized. The amount of FBG shall
be subject to periodic review on six monthly basis by the Licensor and shall be renewed
from time to time.
21.3 Initially, the Bank Guarantees (FBG as well as PBG) shall be valid for a period of
one year and shall be renewed from time to time. The Licensee, on its own, shall
extend the validity period of the Bank Guarantees at least one month prior to date of its
expiry without any demand or notice from the Licensor on year to year basis. Any
failure to do so, shall amount to violation of the terms of the License and entitle the
Licensor to encash the Bank Guarantees and to convert into a cash security without
any reference to the Licensee at his risk and cost. No interest or compensation
whatsoever shall be payable by the Licensor on such encashment.
21.4 Where the Bank Guarantees have been encashed partially, the licensee on such
occasions, shall restore the encashed guarantees to the full amount. Any failure to do
so shall amount to violation of the terms and conditions of the license.
21.5 Without prejudice to its rights of any other remedy, Licensor may encash Bank
Guarantee (FBG as well as PBG) in case of any breach in terms & conditions of the
License by the Licensee.
22

<!-- page 23 -->

22.

Preparation of Accounts:

22.1 The Licensee will draw, keep and furnish independent accounts for each service
and service area and shall fully comply with any order, direction or regulation as may be
issued by TRAI and rules/instructions/directions as are issued by the Licensor from time
to time
22.2 The Licensee shall be obliged, in respect of each authorized service and service
area separately, to:
a) Compile and maintain accounting records, sufficient to show and explain its
transactions in respect of each completed quarter of the License period or of
such lesser periods as the Licensor may specify, fairly presenting the costs
(including capital costs), revenue and financial position of the Licensee’s
business under the License including a reasonable assessment of the assets
employed in and the liabilities attributable to the Licensee’s business, as well as,
for the quantification of Revenue or any other purpose.
(b) Procure in respect of each of those accounting statements prepared in
respect of a completed financial year, a report by the Licensee’s Auditor in the
format prescribed by the Licensor, stating inter-alia whether in his opinion the
statement is adequate for the purpose of this condition and thereafter deliver to
the Licensor a copy of each of the accounting statements not later than three
months at the end of the accounting period to which they relate.
c) Send to the Licensor a certified statement sworn on an affidavit, by
authorized representative of the company, containing full account of Revenue as
defined in condition 19 for each quarter separately along with the payment for
the quarter.
d)
Furnish to the Licensor full detail of inter-operator settlement of accounts
eg. pass through charges, usage of network and facilities, domestic and
international roaming including details of the settlement regime through
accounting rate or any other mechanism, etc. All bilateral settlements including
those between the ILD service provider and other foreign partners (carriers) shall
be through normal banking channel in a transparent manner.
22.3 (a) The Licensor or the TRAI, as the case may be, shall have a right to call for
and the Licensee shall be obliged to supply and provide for examination any books of
accounts that the Licensee may maintain in respect of the business carried on to
provide the service(s) under this License at any time without recording any reasons
thereof.
22.3 (b) Licensee shall invariably preserve all billing and all other accounting records
(electronic as well as hard copy) for a period of three years from the date of publishing
of duly audited & approved Accounts of the company and any dereliction thereof shall
be treated as a material breach independent of any other breach, sufficient to give a
cause for cancellation of the License.
22.4 The records of the Licensee will be subject to such scrutiny as may be prescribed
by the Licensor so as to facilitate independent verification of the amount due to the
Licensor as its share of the revenue.
23

<!-- page 24 -->

22.5 The Licensor may, on forming an opinion that the statements or accounts
submitted are inaccurate or misleading, order Audit of the accounts of the Licensee by
appointing Auditor at the cost of the Licensee and such auditor(s) shall have the same
powers which the statutory auditors of the company enjoy under Section 227 of the
Companies Act, 1956. The remuneration of the Auditors, as fixed by the Licensor, shall
be borne by the Licensee.
22.6 The Licensor may also get conducted a ‘Special Audit’ of the Licensee
company’s accounts/records by “Special Auditors”, the payment for which at a rate as
fixed by the Licensor, shall be borne by the Licensee. This will be in the nature of
auditing the audit described in para 22.5 above. The Special Auditors shall also be
provided the same facility and have the same powers as of the companies’ auditors as
envisaged in the Companies Act, 1956.
22.7 The Licensee shall be liable to prepare and furnish the company’s annual
financial accounts according to the accounting norms and principles prescribed and the
directions given by the Licensor or the TRAI, as the case may be, from time to time.
22.8 The Licensor, to ensure proper and correct assessment, verification and
settlement of revenue share paid, can, if deemed necessary, add, modify, alter,
substitute and amend whatever stated in this Chapter, namely Chapter-III of this
license. The licensee shall comply with the instructions/directions issued in this regard
from time to time.

24

<!-- page 25 -->

CHAPTER-IV
TECHNICAL CONDITIONS
23.

TECHNICAL CONDITIONS:

23.1 The LICENSEE shall provide the details of the technology, proposed to be
deployed for operation of the service, to the Licensor. For providing the Service the
Licensee shall utilize any type of equipment and product that meet TEC standards,
wherever made mandatory by the Licensor from time to time. In the absence of
mandatory TEC standard, the Licensee may utilize only those equipment and products
which meet the relevant standards set by International standardization bodies, such as,
ITU, ETSI, IEEE, ISO, IEC etc.,; or set by International Fora, such as 3GPP, 3GPP-2,
IETF, MEF, WiMAX, Wi-Fi, IPTV, IPv6, etc. as recognized by TEC and subject to
modifications/adaptation, if any, as may be prescribed by TEC from to time.
23.2 Requisite monitoring/interception facilities /equipment for each type of service,
shall be provided by the Licensee at its own cost for monitoring as per the requirement
specified by the Licensor from time to time.
23.3 The LICENSEE shall adhere to the National Fundamental Plans like National
Numbering Plan, Signaling Plan, Routing Plan, National Frequency Allocation Plan and
any other plan, as applicable to the respective service authorization, issued by
Department of Telecommunications and technical standards as prescribed by Licensor
from time to time.
23.4 The Licensor reserves the right to modify any of the National Fundamental
Plans.
24.

Compliance to Directions/ Instructions:

24.1

Norms on Electromagnetic Field exposure by BTS (Base Stations)

In case the Licensee install BTS for providing the service, if permitted under the scope
of the service authorization, the Licensee shall conduct audit and provide self
certificate, at prescribed interval and as per procedure prescribed by
Telecommunication Engineering Centre (TEC) / or any other agency authorized by
Licensor from time to time for conforming to limits / levels for antenna (Base Station
Radiation Emissions) for general public exposure as prescribed by Licensor from time
to time. The present limits / levels are reproduced below:
Frequency Range

E-field strength
(volt/meter (V/m))

400MHZ to 2000 0.434 f1/2
MHZ
2GHZ to 300 GHZ 19.29

H-field
strength(Amp
meter (A/m))
0.0011 f1/2
0.05

Power
density
/ (Watt/Sq.
meter
(W/Sqm))
f/2000
1

(f is frequency in MHz)
Self Certification shall be submitted to respective Telecom Enforcement, Resource &
Monitoring Cells of Licensor.
The LICENSEE shall comply with the instructions / directions/ guidelines issued by
Licensor on EMF exposure norms from time to time.
25

<!-- page 26 -->

24.2 The Licensee shall adopt Renewable Energy Technologies (RETs) for powering
the Telecom Network, deploy energy efficient equipment and reduce the carbon
footprint as per prevailing directions/ instructions and shall abide by further directions /
instructions as may be issued in this regard by Licensor/ TRAI from time to time.
24.3 The licensee shall adhere to the prevailing directions/ instructions and shall also
abide by further directions / instructions as may be issued by LICENSOR from time to
time in respect of
(a) Preferential Market Access for procurement of indigenous manufactured
products,
(b) Mandatory testing of equipment and
(c) Requirements on IPv6 implementation.
25.

The Applicable System:

25.1

In the process of operating the Services, the Licensee shall be responsible for:(i)
The installation of the systems excluding the installation of the equipment
at the subscriber’s premises which will be left at the option of the
subscriber;
(ii)
the proper upkeep and maintenance of the equipment;
(iii)
maintaining the criteria of performance;
(iv)
maintaining the Quality of Service as per clause 29.

26.

Engineering Details:

(a)

The Licensee shall furnish to the Licensor or its authorized representative(s), in
such manner and at such times as may be required, complete technical details
with all calculations for engineering, planning and dimensioning of the
system/network, concerned relevant literature, drawings, and installation
materials regarding the applicable system.

(b)

Licensee shall supply all tools, test instruments and other accessories to the
testing party of Licensor and /or TEC for conducting tests at any time during the
currency of the License.

27.

Network Interconnection:

27.1 Interconnection amongst the networks of Licensees shall take place where
specifically provided for in the Service Authorization Chapter in PART-II of the Schedule
to the License. In such cases the conditions of interconnections as specified below shall
be applicable.
27.2 Transmission links for interconnection shall meet relevant standards or Interface
Requirements (IR) issued by TEC from time to time.
27.3 Interconnection between the networks of different Licensees for carrying circuit
switched traffic shall be as per national standards of CCS No.7 as amended from time
to time by Telecom Engineering Centre (TEC) and also subject to technical feasibility
and technical integrity of the Networks and shall be within the overall framework of
interconnection regulations/ directions/ orders issued by the TRAI/ Licensor from time to
time. For inter-networking between circuit switched and IP based network, the Licensee
shall install Media Gateway Switch. Further, the Licensor may direct the LICENSEE to
adopt any other technical standards issued by TEC on interconnection related issues.
26

<!-- page 27 -->

27.4 Licensee shall interconnect with other Telecom Service Providers at the Points
of Inter-connection (POI) subject to compliance of prevailing regulations, directions or
determinations issued by TRAI. The charges for accessing other networks for internetwork calls shall conform to the Orders/ Regulations/ Guidelines issued by the TRAI/
Licensor from time to time. The Interconnection Agreements will, inter-alia, provide the
following:
(a)
To meet all reasonable demand for the transmission and reception of messages
between the interconnected systems.
(b)
To establish and maintain such one or more Points of Interconnect as are
reasonably required and are of sufficient capacity and in sufficient number to enable
transmission and reception of the messages by means of the Applicable Systems,
(c)

To connect, and keep connected, to their Applicable Systems.

27.5 The charges for accessing other networks for inter-network calls shall be based
on mutual agreements between the service providers conforming to the Orders/IUC
Regulations/Guidelines issued by the TRAI from time to time.
27.6 The provision of any equipment and its installation for the purpose of
Interconnection shall be subject to mutual agreement of the concerned parties and shall
conform to TRAI’s regulations and orders.
27.7 The Interconnection Tests for each and every interface with any Telecom Service
Provider shall be carried out by mutual arrangement between the Licensee and the
other party involved. In case of disagreement for rectification of deficiencies /
deviations in conducted interconnection tests, reference could be made to Licensor /
TRAI.
27.8 The interconnection with a Telecom Service Provider shall have to be withdrawn
within one hour of receipt of intimation or within such time as directed by the
LICENSOR in writing, in case of revocation of the LICENSE of the Telecom Service
Provider.
28.

Interface:

28.1 The Licensee shall operate and maintain the licensed Network conforming to
Quality of Service standards to be mutually agreed with other TSPs in respect of
Network- Network Interface subject to such other directions as Licensor or TRAI may
give from time to time. Failure on the part of Licensee to adhere to the network to
network interface standards of TEC is liable to be treated as breach of LICENSE terms
and conditions. For the purpose of providing the Service, the Licensee shall install his
own equipment so as to be compatible with other telecom service providers’ equipment
to which the Licensee's Applicable Systems are to be interconnected. The Licensee
shall be solely responsible for attending to any claims and damages arising out of his
operations.
28.2 The network resources including the cost of upgrading/ modifying
interconnecting networks to meet the service requirements of the LICENSEE will be
mutually negotiated with other TSPs keeping in view the orders and regulations issued
by the TRAI from time to time.

27

<!-- page 28 -->

28.3 In case of Satellite based services, the technical parameters & data rates
mentioned in Interface Requirements for Satellite Communications namely No. TECIR/SCB-08/02-SEP.2009 issued by TEC are to be strictly compiled with. Any notification
or modification issued by TEC from time to time in this regard shall be binding.
29.

Quality of Service:

29.1 The LICENSEE shall ensure the Quality of Service (QoS) as may be prescribed
by the Licensor or TRAI. The LICENSEE shall operate and maintain the licensed
Network conforming to Quality of Service standards subject to such other directions as
Licensor / TRAI may give from time to time. The LICENSEE shall adhere to such QoS
standard and provide timely information as required therein. Failure on part of
LICENSEE to adhere to the Quality of Service stipulations by TRAI/Licensor is liable to
be treated as breach of terms and conditions of License.
The LICENSEE shall provide periodic information on compliance of QoS
standards to TRAI/Licensor as per schedule notified.
29.2

The LICENSEE shall be responsible for: i)
ii)
iii)

Maintaining the performance and quality of service standards.
Maintaining the MTTR (Mean Time to restore) within the specified limits of
the quality of service.
The LICENSEE will keep a record of number of faults and rectification
reports in respect of the service, which will be produced before the
Licensor/ TRAI as and when and in whatever form desired.

29.3 The LICENSEE shall be responsive to the complaints lodged by his subscribers.
The LICENSEE shall rectify the anomalies within the MTTR specified and maintain the
history sheets for each installation, statistics and analysis on the overall maintenance
status.
29.4 The Licensor or TRAI may carry out performance tests on Licensee’s network
and also evaluate Quality of Service parameters prior to grant of permission for
commercial launch of the service, after successful completion of interconnection tests
and/ or at any time during the currency of the LICENSE to ascertain that the network
meets the specified standards on Quality Of Service (QoS). The LICENSEE shall
provide ingress and other support including instruments, equipment etc., for such tests.
29.5 The Licensee shall enforce and ensure QoS, as prescribed by the Licensor/ TRAI,
from the other Licensees with whom it may enter into agreement / contract for leasing /
hiring / buying or any such instrument for provision of infrastructure. The responsibility
of ensuring QoS shall be that of Licensee.
29.6

Disaster/Emergency/Public Utility Services:

The Licensee shall follow the guidelines /directions/ standard operating
procedures as may be prescribed for the disaster management/emergency response
services or any other instruction issued by Licensor in this regard from time to time.
The Licensee shall also facilitate the priority routing of emergency/public utility or
any other type of user calls as per guidelines /directions as may be prescribed by
Licensor.
28

<!-- page 29 -->

CHAPTER-V
OPERATING CONDITIONS
30.

Subscriber Registration and Provision of Service:

30.1 The LICENSEE shall register demand/request for telephone connection and or
any other Telecom Service without any discrimination from any applicant, at any place
in the service area for the service(s) authorized and provide the Service, unless
otherwise directed by the Licensor. The LICENSEE shall not in any manner
discriminate between subscribers and provide service on the same commercial
principle and shall be required to maintain a transparent, open to inspection, waiting list.
The LICENSEE shall clearly define the scope of Service to the Subscriber(s) at the time
of entering into contract with such Subscriber(s). Licensor shall have right to impose
suitable penalty, not limited to a financial penalty, apart from any other actions for
breach of this condition. The LICENSEE shall commence the Service on commercial
basis only after starting subscriber registration in the manner prescribed. Before
commencement of Service in an area, the LICENSEE shall notify and publicize the
address where any subscriber can register demand /request for Telecom Service. Any
change of this address shall be duly notified by the Licensee.
Provided that nothing contained herein will affect or prejudice the rights of the
LICENSEE to carry out check on credit worthiness of applicants for its services.
30.2 The LICENSEE shall widely publicize provision of service and shall not refuse
registration of demand in the service areas in which the Licensee has commenced
services. In case the provision of telephone connection or the requested telecom
service to an applicant is not feasible for technical or other reasons beyond the control
of Licensee, then the LICENSEE shall endeavour to make arrangement for providing
connections/Service in such cases within a reasonable time.
30.3(a)
The LICENSEE shall ensure continuity of services to its customers unless
LICENSE is Revoked or Suspended by the Licensor for any reason whatsoever.
30.3(b)
Licensee may discontinue any of the service, under a Service
Authorization, to its subscribers, by giving notice to Licensor and TRAI of at least 60
Calendar days in advance with reasons. In that case it shall also notify all its subscriber
by sending a 30 Calendar days notice to each of them. The effective date of
discontinuity of Service will be 61st Calendar days counted from the date of receipt of
such notice by the Licensor. The Licensor reserves the right to reject such request.
30.4 It shall be the responsibility of the LICENSEE to issue or cause to be issued bills
to its subscribers for use of the service. The LICENSEE shall maintain such records so
as to produce itemized billing information. The billing system of the LICENSEE shall be
able to generate the billing information, in adequate details, to ensure satisfaction of the
subscribers about the genuineness of the bill. The directions of TRAI, from time to time,
in this regard shall apply.
30.5 The LICENSEE shall offer a regular itemised billing to its subscribers wherever
applicable. In every case the LICENSEE shall be responsible to its subscribers and
shall ensure fulfillment of the obligations in this regard. The LICENSEE shall also
maintain necessary records for the billing cycles as specified by the Licensor or TRAI
from time to time.
29

<!-- page 30 -->

30.6 All complaints of subscribers in this regard will be addressed / handled as per
the orders or regulations or directions issued by the Licensor or TRAI from time to time.
30.7 Determination of TRAI with regard to publication of telephone service directory
containing information of subscribers of Telecom Service shall be applicable and
binding.
30.8 The Licensee’s contractual obligations to various Licensees and Other Service
Providers (OSPs) not requiring License under Section 4 of Indian Telegraph Act, 1885
will include terms and conditions under which the Service may be obtained, utilized and
terminated. However, the Licensee while providing the resources to other Licensees /
OSPs shall satisfy itself that such Licensee/OSP is eligible to obtain that resource.
30.9 The LICENSEE shall notify in writing all the policy and arrangements with
respect to repair, fault rectification, compensation or refunds. All complaints in this
regard will be addressed / handled as per the guidelines, order or regulation or direction
issued by the Licensor or TRAI from time to time.
30.10 Any dispute, with regard to the provision of Service shall be a matter only
between the aggrieved party and the Licensee, who shall duly notify this to all before
providing the Service. And in no case, the Licensor shall bear any liability or
responsibility in the matter. The LICENSEE shall keep the Licensor indemnified for all
claims, cost, charges or damages in the matter.
30.11 In case of provision of services by the LICENSEE through the Satellite media or
use of satellite media through owned/leased satellite connectivity:(i) The Licensee shall abide by the prevalent Government guidelines, policy, orders,
regulation or direction on the subject like Satellite communication policy, VSAT policy
etc.
(ii) Before putting in operation the network for Satellite based services, necessary
clearances from INSAT Network Operations Control Center (NOCC) on payment of
prescribed charges will be taken by the Licensee. NOCC instructions with regard to
space segment access and other relevant operational matters will have to be complied
by the Licensee.
(iii) For use of space segment and setting up and to start operating the Earth Station
etc., Licensee shall directly coordinate with and obtain clearance from Network
Operations Control Centre (NOCC), apart from obtaining SACFA clearance and
clearance from other authorities.
(iv) Mandatory performance verification of HUB Station will be carried out by NOCC or
any other agency authorized by the Authority for this purpose on payment of necessary
testing charges by Licensee.
(v) For VSATs supplied or leased by the Licensee, a certificate from the LICENSEE
duly supported by the manufacturer certificate meeting the mandatory performance
requirements shall be submitted by the LICENSEE to NOCC. Mandatory performance
verification of VSATs will be carried out by NOCC on selective basis on payment of
necessary testing charges by Licensee.

30

<!-- page 31 -->

(vi) The Licensee shall submit a monthly operational report to NOCC/Satellite cell in
DoT in both soft copy and hard copy.
31.

The Subscriber Terminals:

31.1 The Licensee shall have the right to undertake the sale, hire purchase, lease or
renting of the subscriber fixed / mobile terminals / Customer Premises Equipment
(CPE). Proper usage of terminal at subscriber's premises shall be as per agreement
between the Licensee and subscriber.
31.2 The Licensee shall be responsible to ensure that the subscriber terminal is
operated in accordance with the terms and conditions of the License, the Wireless
Operating License where applicable and relevant instructions/rules issued by
Licensor/TRAI. The Subscriber Identification Module (SIM) or equivalent device for the
purpose used in the subscriber terminal is non-transferable to other subscriber.
31.3 The subscriber terminals/CPE deployed in the network shall meet TEC
standards, wherever specified as mandatory by the Licensor from time to time and in
the absence of mandatory TEC standard, the Licensee may deploy subscriber
terminals that is certified to meet the relevant standards set by International
standardization bodies, such as, ITU, ETSI, IEEE, ISO, IEC etc. or International Fora,
viz., 3GPP, 3GPP-2, IETF, MEF, WiMAX, Wi-Fi, IPTV, IPv6, etc. as recognized by TEC
and subject to modifications/adaptation, if any, as may be prescribed by TEC from to
time. Only such category of subscriber unit as has been granted such a certificate shall
be brought into and operated within India under this Agreement.
31.4 Subscriber shall be given option to obtain the Subscriber Terminal from any
source subject to clause 31.3 above.
32.

Obligations imposed on the Licensee:

32.1 The provisions of the Indian Telegraph Act 1885, the Indian Wireless Telegraphy
Act 1933, and the Telecom Regulatory Authority of India Act, 1997, Information
Technology Act, 2000 as amended from time to time or any other relevant Act shall
govern this License.
32.2 The Licensee shall furnish all necessary means and facilities as required for the
application of provisions of Section 5(2) of the Indian Telegraph Act, 1885, whenever
occasion so demands. Nothing provided and contained anywhere in this License
Agreement shall be deemed to affect adversely anything provided or laid under the
provisions of Indian Telegraph Act, 1885 or any other law on the subject in force.
33. Sharing of infrastructure:
33.1 Sharing of active/passive infrastructure shall be governed by the terms and
conditions of respective service authorization and amendment/guidelines to be issued
by the Licensor from time to time.
34.

Inspection and Testing of Installations:

34.1 The Licensor / TRAI may carry out performance tests as required for checking
Quality of Service, if it so desires. The LICENSEE shall supply all necessary literature,
drawings etc. regarding the equipment installed and shall also supply all the tools, test
instruments and other accessories to the testing party of the Licensor / TRAI for
31

<!-- page 32 -->

conducting the tests. The list of performance tests will be furnished by the Licensee,
which may be amended by the Licensor.
34.2 The Acceptance Testing for each and every interface with any Telecom Service
provider may be carried out by mutual arrangements between the LICENSEE and the
other party involved. The Interconnection Test schedule shall be mutually agreed.
34.3 Whenever any element of the network/system of the Licensee, if permitted to be
installed outside the Service Area as per the terms of the respective service
authorization and has been so installed, the Licensee shall ensure availability of
facilities for access to such elements from within the Service Area without any limitation
or restriction and at anytime as required by the Licensor. However it shall not preclude
the Licensor from accessing such elements at its physical location for the purposes of
data/information in respect of any Service Area served by such element.
35.

Right to inspect:

35.1 The Licensor or its authorized representative or Ministry of Information &
Broadcasting in respect of IPTV Service, or its authorized representative shall have
right to access and inspect sites used for extending the Service and in particular but not
limited to leased lines, junction, terminating interfaces, hardware/software, memories of
semiconductor, magnetic and optical varieties, wired or wireless equipment, distribution
frames. The Licensor or its authorized representative may also conduct the
performance test including to enter into dialogue with the system through input/output
devices or terminals. The Licensee will provide the necessary facilities for continuous
monitoring of the system in the Licensed Service Area, as required by the Licensor or
its authorized representative(s). The inspection will ordinarily be carried out after
reasonable notice except in circumstances where giving such a notice will defeat the
very purpose of the inspection.
35.2 Wherever considered appropriate, Licensor or the Ministry of Information &
Broadcasting in respect of IPTV Service, may conduct any inquiry either suo-motu or on
the complaint to determine whether there has been any breach in compliance of terms
& conditions of the LICENSE by the Licensee and upon such inquiry, the Licensee
shall extend all reasonable facilities without any hindrance to the Licensor/Ministry of
Information & Broadcasting as the case may be.
36.

Location of Network Elements:

36.1 The Licensee on request shall provide to the Licensor location details of all
network elements including switching centres, transmission centres, along with routing
details, network operation & control/ management Centre, equipment details, network
topology, Base Stations, end to end connectivity, Cable routes and capacity along with
GIS mapping and any other detail as may be required by Licensor from time to time.
Any network resource including the band width/ leased line/ VPN either owned or taken
on lease/ hire shall be treated as part of the Licensee Network.
36.2 In areas which are sensitive from security point of view, as may be notified from
time to time by the Licensor, installation of any equipment or execution of project shall
be taken up only after the Licensor’s approval.
36.3 The Licensor may prescribe restrictions for provision of services in areas falling
near International Border/Line of Control/Line of Actual Control of India or any other
areas as may be prescribed by the Licensor.
32

<!-- page 33 -->

37.

Confidentiality of information:

37.1 The Licensee shall not employ bulk encryption equipment in its network.
Licensor or officers specially designated for the purpose may evaluate any encryption
equipment connected to the Licensee’s network. However, the Licensee shall have the
responsibility to ensure protection of privacy of communication and to ensure that
unauthorized interception of MESSAGE does not take place.
37.2 Subject to terms and conditions of the license, the Licensee shall take all
necessary steps to safeguard the privacy and confidentiality of any information about a
third party and its business to whom it provides the Service and from whom it has
acquired such information by virtue of the Service provided and shall use its best
endeavors to secure that:
a)
No person acting on behalf of the Licensee or the Licensee divulges or
uses any such information except as may be necessary in the course of
providing such Service to the Third Party; and
b) No such person seeks such information other than is necessary for the
purpose of providing Service to the Third Party.
Provided the above para shall not apply where:
a) The information relates to a specific party and that party has consented in
writing to such information being divulged or used, and such information is
divulged or used in accordance with the terms of that consent; or
b) The information is already open to the public and otherwise known.
37.3 The Licensee shall take necessary steps to ensure that the Licensee and any
person(s) acting on its behalf observe confidentiality of customer information.
37.4 The Licensee shall, prior to commencement of Service, confirm in writing to the
Licensor that the Licensee has taken all necessary steps to ensure that it and its
employees shall observe confidentiality of customer information.
37.5 The use of encryption by the subscriber shall be governed by the Government
Policy/rules made under the Information Technology Act, 2000.
38.

Prohibition of certain activities by the Licensee:

38.1 Carriage of objectionable, obscene, unauthorized or any other content, messages
or communications infringing copyright and intellectual property right etc., in any form,
in the network is not permitted as per established laws of the country. Once specific
instances of such infringement are reported to the Licensee by the enforcement
agencies/Licensor, the Licensee shall take necessary measures to prevent carriage of
such messages in its network immediately.
38.2 The LICENSEE is obliged to provide, without any delay, all the tracing facilities
to trace nuisance, obnoxious or malicious calls, messages or communications
transported through his equipment and network, to the agencies of Government of India
as authorized from time to time, when such information is required for investigations or
33

<!-- page 34 -->

detection of crimes and in the interest of national security. Any damages arising on
account of Licensee’s failure in this regard shall be payable by the Licensee.
38.3 In case any confidential information is divulged to the LICENSEE for proper
implementation of the Agreement, it shall be binding on the LICENSEE and its
employees and servants to maintain its secrecy and confidentiality.
38.4 The LICENSEE shall ensure that the Telecommunication infrastructure or
installation thereof, carried out by it, should not become a safety or health hazard and is
not in contravention of any statute, rule, regulation or public policy.
38.5 The Licensee shall in no case permit service to any Telecom Service Provider
(including those Other Service Providers who do not require License under Section 4 of
Indian Telegraph Act, 1885) whose License is either revoked or suspended or not in
operation at any point of time. Where connectivity already exists, the Licensee shall be
obliged to disconnect or sever connectivity immediately without loss of time upon
receipt of any reference from the Licensor in this regard. Disconnection shall be made
effective within one hour or within such time as directed by the Licensor in writing, after
receiving reference from the Licensor in this regard.

34

<!-- page 35 -->

CHAPTER-VI
SECURITY CONDITIONS
39.
The LICENSEE shall meet the instructions/directions of the Licensor issued
from time to time in the interest of national security apart from the following conditions.
39.1 The LICENSEE shall provide necessary facilities depending upon the specific
situation at the relevant time to the Government to counteract espionage, subversive
act, sabotage or any other unlawful activity.
39.2 The LICENSEE shall make available on demand to the person authorized by the
Licensor, full access to the switching centers, transmission centers, routers and other
network elements including equipment installed in subscriber premises etc. for technical
scrutiny and for inspection, which can be visual inspection or an operational inspection.
39.3 All foreign personnel likely to be deployed by the LICENSEE for installation,
operation and maintenance of the Licensee’s network shall be security cleared by the
Government of India prior to their deployment. The security clearance will be obtained
from the Ministry of Home Affairs, Government of India.
39.4 The LICENSEE shall ensure protection of privacy of communication and ensure
that unauthorized interception of messages does not take place.
39.5 The LICENSEE shall be completely and totally responsible for security of their
networks. The LICENSEE shall have organizational policy on security and security
management of their networks including Network forensics, Network Hardening,
Network penetration test, Risk assessment. Actions to fix problems and to prevent such
problems from recurring should be part of the policy. The LICENSEE shall submit its
policy to Licensor within 90 calendar days from the date of issue of the License/each
service authorization.
39.6 In furtherance of organizational security policy, the LICENSEE shall audit its
network or get the network audited from security point of view once in a financial year
from a network audit and certification agency. The first audit may be carried out in the
financial year succeeding the financial year of the signing of the LICENSE/ Service
authorization. The LICENSEE is free to engage the service of any agency for this
purpose, which is certified to carry out the audit as per relevant ISO standards.
Presently ISO 15408 and ISO 27001 standards are applicable.
39.7 The LICENSEE shall induct only those network elements into its telecom
network, which have been got tested as per relevant contemporary Indian or
International Security Standards e.g. IT and IT related elements against ISO/IEC 15408
standards, for Information Security Management System against ISO 27000 series
Standards, Telecom and Telecom related elements against 3GPP security standards,
3GPP2 security standards etc. The certification shall be got done only from authorized
and certified agencies/ labs in India or as may be specified by the Licensor. The copies
of test results and test certificates shall be kept by the LICENSEE for a period of 10
years from the date of procurement of equipment.
39.8 The LICENSEE shall include all contemporary security related features and
features related to communication security as prescribed under relevant security
standards while procuring the equipment and implement all such contemporary features
into the network. A list of features, equipments, software etc procured and implemented
35

<!-- page 36 -->

shall be kept by the LICENSEE till they are in use, which may be subjected to
inspection and testing by the Licensor at any time, in the network or otherwise, at the
option of the Licensor.
39.9

The LICENSEE shall
(i)
(ii)
(iii)

(iv)

(v)

Ensure that all the documentation, including software details are obtained
from manufacturer/vendor/supplier in English language.
Keep a record of operation and maintenance procedure in the form of a
manual.
Keep a record of all the operation and maintenance command logs for a
period of 12 months, which shall include the actual command given, who
gave the command, when was it given with date and time and from where.
For next 24 months the same information shall be stored/ retained in a nononline mode. For this purpose LICENSEE shall keep a list of User ID linked
with name and other details of the user duly certified by the system
administrator. The user list shall be provided to Licensor or agencies
designated by the Licensor as and when required.
Keep a record of all the software updating and changes. The major updating
and changes should also be informed to Licensor within 15 days of
completion of such updating and changes.
Keep a record of supply chain of the products (hardware/ software). This
should be taken from the manufacturer/ vendor/ supplier at the time of
procurement of the products.

39.10 (i)
The LICENSEE shall create facilities for the monitoring of all intrusions,
attacks and frauds on his technical facilities and provide reports on the same to the
Licensor. Such facilities shall be created by the Licensee within 12 months of effective
date of this LICENSE/ authorization and be reported to Licensor as and when created
during this period.
39.10 (ii)
The Licensee through suitable agreement clauses with vendor shall
ensure that the Vendor/ Supplier allow the Licensee, Licensor and/ or its designated
agencies to inspect the hardware, software, design, development, manufacturing facility
and supply chain and subject all software to a security/ threat check any time during the
supplies of equipment. The number of such visits will be limited to two in a Purchase
Order (PO). The expenditure for such visits, limited upto 40 man-days per visit, for each
purchase order of value above Rs 50 crore, shall be borne by the LICENSEE directly or
through vendor.
39.11 (i)
A penalty upto Rs 50 crore per occasion will be levied for any security
breach which has been caused due to inadvertent inadequacy/inadequacies in
precaution on the part of Licensee prescribed under this License. Licensor shall
constitute a five members committee, which shall include two cyber security experts, to
determine whether the breach is due to inadvertent inadequacy/ inadequacies or
otherwise. The committee shall also decide the amount of penalty depending upon loss,
gravity of breach etc.
39.11 (ii)
In case of inadequate compliance to the measures prescribed under this
License, act of intentional omissions, deliberate vulnerability left into the equipment or
in case of deliberate attempt for a security breach, penalty amount will be Rs. 50 crore
per breach. The same breach in the same equipment purchased through same PO or in
the same lot or the same negligence at the same time at multiple locations in an
36

<!-- page 37 -->

operator’s network will be considered as a single breach for the purpose of levying
penalty under this clause. The LICENSEE shall deposit the penalty amount with the
Licensor within 30 days of the issue of Notice.
39.11 (iii)
Besides the penalty, liability and criminal proceedings under the relevant
provisions of various Acts such as Indian Telegraph Act, Information Technology Act,
Indian Penal Code (IPC), Criminal Procedure Code (CrPC) etc can be initiated. In such
cases, LICENSE of the LICENSEE can also be terminated, vendor or supplier who
supplied the hardware/software, that caused the security breach, could be blacklisted
for doing business in the country or both. The LICENSEE must include the clause of
discretion of blacklisting of vendor or supplier in such cases in the agreement signed
with vendors/suppliers.
39.11 (iv)
Licensor may make any of the following suggestions, which help in
increasing the security of the telecom network, mandatory whenever deemed
necessary to do so.
a) May sign a suitable agreement with hardware/ software manufacturer/ vendors
and/or suppliers of services to ensure that the equipment/ services/ software
they supply are ‘Safe to Connect’ in the network, have been checked thoroughly
for risks and vulnerabilities, all addressable vulnerabilities have been addressed,
non-addressable vulnerabilities have been listed with remedial measures and
precautions provided. The agreement should cover aspects related to security
measures like access control, Password control and management etc. Clauses
addressing the service continuity and service up-gradation should also be
suitably included in the agreement, with consequences defined for each party in
case of breach, particularly the security breaches. As information dissemination
and facilitating measure, suggested clauses for such an agreement in the form of
a template will be available on the website of DoT. The service providers may
take all or selected provisions from this template, depending upon the type of
services they avail from a vendor/ supplier. They are free to add, modify, delete
any of the clauses from this template, because security of their network is their
responsibility and they will be liable for any security breach.
b) The Licensees should endeavour to create a forum, say, Telecom Security
Council of India (TSCI), on a voluntary basis to increase the security assurance
levels and share common issues.
c) The Licensee shall build their own capability and capacity to maintain and
operate the network, preferably through local maintenance personnel, because
the telecom network is a security sensitive infrastructure.
39.12 In the interests of security, suitable monitoring equipment as per requirement of
the Licensor or designated Security Agencies for each type of system used shall be
provided by the Licensee for monitoring as and when required by Licensor. The
specific orders or directions from the Government, issued under such conditions, shall
also be applicable.
39.13 The precise delineation of geographical borders taken by the Licensee for the
purpose of defining service area along International borders, if any, shall have prior
approval of the Government of India. The terrestrial boundaries of India shall be as
depicted in the maps issued by Survey of India.

37

<!-- page 38 -->

39.14 The use of the network for anti-national activities would be construed as an
offence punishable under the Indian Penal Code or other applicable law. The networks
cannot be used in such a manner as to endanger or make vulnerable a networked
infrastructure. Acts such as break-ins or attempted break-ins of Indian networks shall
be regarded as an anti-national act and shall be dealt with in accordance with the
Indian Penal Code. Licensee must ensure that their services are not used for such
purposes. Besides penal action as stated above, such an activity/activities could be
sufficient reason for the Licensor to revoke this license.
39.15 The Government through appropriate notification may debar usage of mobile
terminals in certain areas in the country. The LICENSEE shall deny Service in areas
specified by designated authority immediately and in any case within six hours on
request. The LICENSEE shall also provide the facility to carry out surveillance of Mobile
Terminal activity within a specified area.
39.16 Licensor shall have the right to take over the Service, equipment and networks of
the Licensee (either in part or in whole of the Service Area) in case any directions are
issued in the public interest by the Government of India in the event of a National
emergency / war or low intensity conflict or any other eventuality. Any specific orders or
directions from the Government of India issued under such conditions shall be
applicable to the Licensee and shall be strictly complied with.
39.17 (i) The Licensee shall ensure adequate verification of each and every customer
before enrolling him as a subscriber; instructions issued by the Licensor in this regard
from time to time shall be scrupulously followed. The Licensee shall make it clear to
the subscriber that the subscriber will be responsible for proper and bonafide use of the
service.
39.17 (ii)
Format prescribed by the Licensor delineating the details of information
required before enrolling a customer as a subscriber shall be followed by the Licensee.
A photo identification of subscribers shall be pre-requisite before providing the service.
The Licensor may prescribe service-wise detailed instructions for enrolment of
subscriber and activation of service from time to time.
39.17(iii)
The Licensee shall activate the Leased Line, Internet Leased Line and
IPLC service only after checking the bonafide of the customer, verifying details as per
Customer Acquisition Form (CAF) prescribed from time to time and physical inspection
of the site. Further, in the case of Leased Line, the reasons for taking the link by the
customer shall be recorded.
39.18 The complete list of subscribers shall be made available by the Licensee on their
website (having password controlled access), so that designated Security Agencies are
able to obtain the subscriber list at any time, as per their convenience with the help of
the password. The list should be updated on regular basis. Hard copy as and when
required by security agencies shall also be furnished.
39.19 The Licensor or its representative(s) will have an access to the Database relating
to the subscribers of the Licensee. The Licensee shall also update the list of his
subscribers and make available the same to the Licensor at such intervals as may be
prescribed. The Licensee shall make available, at any prescribed instant, to the
Licensor or its authorized representative details of the subscribers using the service.
39.20 The Licensee shall maintain all commercial records/ Call Detail Record (CDR)/
Exchange Detail Record (EDR)/ IP Detail Record (IPDR) with regard to the
38

<!-- page 39 -->

communications exchanged on the network. Such records shall be archived for at least
one year for scrutiny by the Licensor for security reasons and may be destroyed
thereafter unless directed otherwise by the Licensor. Licensor may issue directions
/instructions from time to time with respect to CDR/IPDR/EDR.
39.21 (i) Calling Line Identification (CLI) shall be provided. The network should also
support Malicious Call identification and Centralized Automatic Message Accounting
(CAMA).
39.21 (ii) Calling Line Identification (CLI) shall never be tampered as the same is also
required for security purposes and any violation of this amounts to breach of security.
39.22 (i) Utmost vigilance should be exercised in providing bulk connections for a single
user as well as for a single location. Provision of 10 or more connections may be taken
as bulk connections for this purpose. Special verification of bonafide should be carried
out for providing such bulk connections. Information about bulk connections shall be
forwarded to respective Telecom Enforcement, Resource & Monitoring Cell and any
other officer authorized by Licensor from time to time as well as all Security Agencies
on monthly basis.
39.22 (ii) The call detail records for outgoing calls made by customers should be
analyzed for the subscribers making large number of outgoing calls day and night and
to the various telephone numbers. Normally, no incoming call is observed in such
cases. This can be done by running special program for this purpose. The service
provider should devise appropriate fraud management and prevention programme and
fix threshold levels of average per day usage in minutes of the telephone connection; all
telephone connections crossing the threshold of usage should be checked for bonafide
use. A record of check must be maintained which may be verified by Licensor any
time. The list/details of suspected subscribers should be informed to the respective
TERM Cell of DoT and any other officer authorized by Licensor from time to time.
39.22 (iii) Active support must be extended by the service providers to the respective
TERM cells of DoT for detection of clandestine / illegal telecommunications facilities.
For this purpose, names of the Nodal officers & alternate Nodal Officers in respect of
each licensed service area as communicated to the Intelligence Agencies for
monitoring of telecommunications should also be forwarded to respective TERM cell of
DoT, and any other officer authorized by Licensor from time to time. The TERM Cell of
DoT will contact the Nodal Officer / alternate Nodal officer, and till the time such
nomination is received or in case of non-availability of such officer, the TERM Cell will
contact the Chief Executive Officer of the Licensee, for such support / coordination.
39.22 (iv) Bulk users premises should be inspected by the service providers at regular
intervals for satisfying themselves about bonafide use of such facilities. A record of
such inspection should be maintained and preserved for minimum one year, for
inspection / verification by the licensing authority or a designated officer of the authority.
39.22 (v) Leased circuits should also be checked/ inspected at regular intervals for
their bonafide use and to detect any misuse.

39.23 The Licensee shall also ensure compliance of the following conditions:

39

<!-- page 40 -->

(i)

The Chief Officer in charge of technical network operations and the Chief
Security Officer/Chief Information Security Officer, and in-charge of GMSC,
MSC, Soft-Switch, Central Database, ILD Gateway, VSAT Hub, INSAT MSS-R
Hub, PMRTS Central/Base Station, GMPCS Gateway, Switches and System
Administrators shall be resident Indian citizen.
(ii)
Licensee may, on need basis, provide details of its infrastructure/ network
diagram (technical details of the network) only to telecom equipment
suppliers/manufacturers and the affiliate/ parents of the Licensee Company.
Clearance from the Licensor would be required if such information is to be
provided to anybody else.
(iii)
For security reasons, domestic traffic of such entities as may be identified/
specified by the Licensor shall not be hauled/ routed to any place outside India.
For this purpose, location of satellites serving India for domestic traffic shall not
be treated as outside India.
(iv)
The Licensee Company shall take adequate and timely measures to ensure
that the information transacted through a network by the subscribers is secure
and protected.
(v)
The officers/ officials/ Nodal Executives of the Licensee companies dealing
with the lawful interception of messages will be resident Indian citizens.
(vi)
The majority Directors on the Board of the Licensee company shall be Indian
citizens.
(vii) The positions of the Chairman, Managing Director, Chief Executive Officer
(CEO) and/or Chief Financial Officer (CFO), if held by foreign nationals, would
require to be security vetted by Ministry of Home Affairs (MHA). Security
vetting shall be required periodically on yearly basis. In case something
adverse is found during the security vetting, the direction of MHA shall be
binding on the Licensee.
(viii) The Licensee shall not transfer the following to any person/place outside
India:a. Any accounting information relating to subscriber (except for international
roaming/billing) (Note: it does not restrict a statutorily required disclosure
of financial nature) ; and
b. User information (except pertaining to foreign subscribers using Indian
Operator’s network while roaming and IPLC subscribers).
(ix)

(x)

(xi)

(xii)

(xiii)
(xiv)

4

The Licensee must provide traceable identity of their subscribers. However, in case of
providing service to roaming subscriber of foreign Companies, the Indian Company
shall endeavour to obtain traceable identity of roaming subscribers from the foreign
company as a part of its roaming agreement.
On request of the Licensor or any other agency authorized by the Licensor, the
Licensee shall be able to provide the geographical location of any subscriber (BTS
location and Location details including latitude & longitude details) at a given point of
time.
The Remote Access (RA) to network would be provided only to approved locations
abroad through approved location(s) in India. The approval for location(s) would be
given by the Licensor (DoT) after satisfying itself about the appropriateness.4
Under no circumstances, should any RA to the suppliers/manufacturers and affiliate(s)
be enabled to access Lawful Interception System(LIS), Lawful Interception
Monitoring(LIM), Call contents of the traffic and any such sensitive sector/data, which
the Licensor may notify from time to time.

The Licensee Company is not allowed to use remote access facility for
monitoring of content.
Suitable technical device should be made available at Indian end to the
designated security agency/Licensor in which a mirror image of the remote

Amended vide DOT letter no 20-271/AS-I (Pt) dated 03.12.2013

40

<!-- page 41 -->

access information is available on line for monitoring purposes as per direction
of the Licensor from time to time.
(xv) Complete audit trail of the remote access activities pertaining to the network
operated in India should be maintained for a period of six months and provided
on request to the Licensor or any other agency authorized by the Licensor.
(xvi) The Licensee shall ensure that necessary provision (hardware/ software) is
available in their equipment for doing the Lawful interception and monitoring
from a centralized location.
(xvii) The Licensee shall familiarize/ train TERM Cell/ security agency officers/
officials in respect of relevant operations/ features of their systems.
(xviii) It shall be open to the Licensor to restrict the Licensee Company from
operating in any sensitive area from the National Security angle.
(xix) In order to maintain the privacy of voice and data, monitoring shall be in
accordance with rules in this regard under Indian Telegraph Act, 1885.
(xx) For monitoring traffic, the Licensee Company shall provide access of their
network and other facilities as well as to books of accounts to the security
agencies.
39.24 Licensor reserves the right to modify these conditions or incorporate new
conditions considered necessary in the interest of national security and public interest
or for proper conduct of TELEGRAPH.
40.

Application of Indian Telegraph Act, 1885:

40.1 The Licensee shall adopt all means and facilitate in every manner the application
of the Indian Telegraph Act, 1885 and Indian Wireless Telegraphy Act, 1933 as
modified or replaced from time to time. The Service shall be provided in accordance
with the provisions of Indian Telegraph Rules as modified and amended from time to
time.
40.2 As per the provision of Section 5 of Indian Telegraph Act, the Licensee will
provide necessary facilities to the designated authorities of Central/State Government
as conveyed by the Licensor from time to time for interception of the messages passing
through its network.
Section 5 (2) of the Indian Telegraph Act 1885 reads as under:
“On the occurrence of any public emergency or in the interest of public safety,
the Central Government or a State Government or any officer specially
authorized in their behalf by the Central Government or a State Government
may, if satisfied that it is necessary or expedient to do so in the interest of the
sovereignty and integrity of India, the security of the State, friendly relations with
foreign states or public order or for preventing incitement to the commission of
an offense for class or messages to or from any person or class of persons or
relating to any particular subject, brought for transmission by or transmitted or
received by any telegraph, shall not be transmitted or shall be intercepted or
detained or shall be disclosed to the Government making the order or an officer
thereof mentioned on the order:
Provided that press messages intended to be published in India of
correspondents accredited to the Central Government or a State Government
shall not be intercepted or detained, unless their transmission has been
prohibited under this subsection.”
41

<!-- page 42 -->

CHAPTER-VII
SPECTRUM ALLOTMENT AND USE
41.
Right to use the spectrum: This License Agreement does not confer any right
to allotment and use of spectrum for which separate specific Frequency Allotment and
Wireless Operating License (WOL) shall be required from Wireless Planning and
Coordination (WPC) Wing.
42.

Frequency Allotment:

42.1 The Frequency Allotment and WOL shall be required from the WPC Wing of the
Department of Telecommunications, Ministry of Communications & IT permitting
utilization of appropriate frequencies / band for the establishment, maintenance and
operation of Wireless elements of the Telecom Service, under specified procedure,
instructions, terms and conditions including payment for said allotment and use of
spectrum and for grant of WOL prescribed by WPC Wing from time to time. Services
offered by the Licensee using the spectrum shall be governed by the terms and
conditions of this License.
42. 2 Application, wherever required, after following the procedure under para 42.1,
shall be made to the “Wireless Adviser to the Government of India, WPC Wing,
Department of Telecommunications, Ministry of Communications & IT, Sanchar
Bhawan, New Delhi-110 001” in a prescribed application form available on WPC Wing
website: www.wpc.dot.gov.in. Online filing of the application shall be required for this
purpose.
42.3 In the event of holding/obtaining Access spectrum, no licensee or its promoter(s)
directly or indirectly shall have any beneficial interest in another licensee company
holding “Access Spectrum” in the same service area.
For the purpose of this clause:
(a)
Promoter shall mean legal entity other than Central Government, financial
institutions and scheduled banks, which hold 10% or more equity in the licensee
company.
(b)
Beneficial interest shall mean holding of any equity directly or indirectly including
through chain of companies in the licensee company.
(c)
Any arrangement contrary to above shall be made consistent with the above
stipulations within a period of one year from the date of grant of UL.
(d)
Exception granted in para 1.4 of UAS licensee in respect of basic and CMTS
licenses existing on 11.11.2003 shall end on the expiry of CMTS/UAS/Basic
Service license held by such licensee. They shall comply with the above
stipulation within a period of one year from the date of migration to UL.

42.4 The networth and paid up equity capital requirement, if any, for acquisition of
Access Spectrum, shall be as prescribed by the Licensor.
42.5 In case the Licensee obtains spectrum through auction, the provisions specified
in the relevant Notice Inviting Application (NIA) document for the auction of such
spectrum or conditions of spectrum allotment shall apply and this License shall be
suitably amended for this purpose.

42

<!-- page 43 -->

42.6 At the time of expiry of Unified License, the continuity of spectrum held by the
Licensee, if any, shall be governed by the terms and conditions of allotment of such
spectrum.
42.7 Allotment of spectrum for individual point-to-point fixed links i.e. Microwave
Backhaul Spectrum shall be subject to separate application to WPC Wing and the
allotment of the same is not linked to the compliance of roll out obligations where
prescribed. The allotment of backhaul spectrum is subject to availability, usual
processes and terms and conditions. Separate charges as prescribed from time to time
shall be payable for microwave backhaul spectrum.
42.8 The Licensor/ WPC Wing reserves the right to modify the procedure for allotment
of spectrum and/or rates for payment for said allotment and use of spectrum any time.

43

<!-- page 44 -->

PART - II
[PART-II consisting of Chapter – VIII to XVI contains the terms and conditions specific
to the respective Service Authorization, which are in addition to the terms and
conditions contained in PART-I]

44

<!-- page 45 -->

CHAPTER-VIII
ACCESS SERVICE
1.
Service Area: The Service Area of Access Service shall be the Telecom
Circle/Metro area as defined in Annexure-V. License/Authorization for Access Service,
if granted for more than one Service Area (Telecom Circle/Metro), shall be administered
separately for each Service Area as per terms and conditions contained in Part-I and in
this chapter.
2.

Scope of Access Service: Scope of this authorization covers the following:

2.1(a)(i)
The Access Service under this authorization covers collection, carriage,
transmission and delivery of voice and/or non-voice MESSAGES over Licensee’s
network in the designated Service Area. The Licensee can also provide Internet
Telephony, Internet Services including IPTV, Broadband Services and triple play i.e
voice, video and data. While providing Internet Telephony service, the Licensee may
interconnect Internet Telephony network with PSTN/PLMN/GMPCS network. The
Licensee may provide access service, which could be on wireline and / or wireless
media with full mobility, limited mobility and fixed wireless access.
(ii)
Licensee may enter into mutual commercial agreements for roaming facilities
(within same service area or other service areas) with other Cellular Mobile Telephone
Service Licensees/ Unified Access Service LICENSEEs/Unified License (Access
Services) LICENSEEs /Unified Licensees with Access Service authorization, unless
otherwise directed by Licensor, irrespective of spectrum band held or technology
deployed by such licensees. However, any Roaming arrangement shall not entitle the
Licensee to acquire customer in the spectrum band not held or technology not deployed
or for services/facilities not offered by the Licensee in its network.
(iii)
The Licensee can acquire customer for delivery of services offered in its network
using only the spectrum band held & technology deployed by the Licensee. While
roaming on other Licensees’ network, the services availed by the subscriber shall be
limited to only those services which have been subscribed in its home network.
(iv) The Licensee may also enter into agreements with telecom service providers
abroad for providing roaming facility to its subscriber unless directed by Licensor
otherwise.
(v) The Licensee may provide leased circuits within its respective service area.
Interconnection of leased circuits, whether point to point or in CUG network, with
PSTN/PLMN/GMPCS/Internet Telephony Network is not permitted.
(vi) The Licensee may also provide Voice Mail/Audiotex/Unified Messaging services,
Video Conferencing over its network to the subscribers falling within its SERVICE
AREA on non-discriminatory basis. All the revenue earned by the Licensee through
these services shall be counted towards the revenue for the purpose of paying License
Fee under the LICENSE AGREEMENT.
(vii) For provision of mobile services in areas falling near International Border of
India, the condition specified in clause 8.1(i) and 8.1(ii) of this authorization, shall be
applicable.
45

<!-- page 46 -->

(viii) Except those services permitted under the scope of this authorization, the
Licensee shall not provide any service / services which require a separate service
authorization / license.
(ix) The Licensee may offer “Home Zone Tariff Scheme (s)” as a subset of full mobile
service in well defined geographical Areas through a tariff of its choice within the scope
of orders of TRAI on the subject. Numbering and interconnection for this service shall
be same as that of fully mobile subscribers.
2.1 (b)
In respect of subscriber availing limited mobility facility, the mobility shall
be restricted to the local area i.e. Short Distance Charging Area (SDCA) in which the
subscriber is registered. While deploying such systems, the LICENSEE has to follow
the SDCA based linked numbering plan in accordance with the National Numbering
Plan of the respective SDCA within which the service is provided and it should not be
possible to authenticate and work with the subscriber terminal equipment in SDCAs
other than the one in which it is registered. Terminal of such subscriber in wireless
access system can be registered in only one SDCA. Multiple registration or Temporary
subscriber/ Subscription facilities in more than one SDCA using the same Subscriber
terminal in wireless access systems is not permitted and the same Subscriber Terminal
cannot be used to avail Limited Mobile facility in more than one SDCA. The system
shall also be so engineered to ensure that hand over of subscriber does not take place
from one SDCA to another SDCA under any circumstances, including handover of the
calls through call forwarding beyond SDCA. The LICENSEE must ensure that the
mobility in case of such limited mobile service/ facility remains restricted to SDCA.
2.2
Licensee may carry intra-circle long distance traffic on its network. However,
subject to technical feasibility, the subscriber of the intra-circle long distance calls, shall
be given choice to use the network of another Licensee in the same service area,
wherever possible. The Licensee may also enter into mutual agreements with other UL
Licensee (with authorization for access service)/ other Access service licensee/National
Long Distance Licensee for carrying its intra-Circle Long Distance traffic.
2.3
For providing service, the Licensee may appoint Franchisee for setting up and
operation of rural telephone exchanges and last mile linkages thereof. The licensee
may also appoint Cable Operators registered under The Cable Television Networks
(Regulation) Act, 1995 and the amendments thereto, as Franchisee to use the last mile
linkages in rural area provided by such Cable Operators. Responsibilities for ensuring
compliance of terms & conditions of the License shall vest with the Licensee and not
with the Franchisee. The terms of franchise agreement between Licensee and his
franchisee shall be settled mutually by negotiation between the two parties involved.
The Licensee shall report the details of such Franchisee to the Licensor as prescribed
from time to time.
2.4
The Licensee may provide internet service by using the Cable Network of
authorized Cable Operator, as last mile linkage, subject to applicable Cable Laws (The
Cable Television Networks (Regulation) Act, 1995) as modified from time to time.
2.5
IP Address assigned to a subscriber for Internet Telephony shall conform to IP
addressing Scheme of Internet Assigned Numbers Authority (IANA) only. Translation of
E.164 number / private number to IP address and vice versa by the licensee for this
purpose shall be as per directions/instructions issued by the Licensor.

46

<!-- page 47 -->

2.6
For provision of Internet Telephony, Internet Services, Broadband Services and
triple play i.e. voice, video and data, the Conditions No. 2.1(i), 2.1(vii), 2.1(ix), 2.1(x),
2.2, 5, 6, 7 and 8 of Chapter IX (Internet Service) shall also be applicable.
3.

FINANCIAL CONDITIONS

3.1

GROSS REVENUE

The Gross Revenue shall be inclusive of installation charges, late fees, sale proceeds
of handsets (or any other terminal equipment etc.), revenue on account of interest,
dividend, value added services, supplementary services, access or interconnection
charges, roaming charges, revenue from permissible sharing of infrastructure and any
other miscellaneous revenue, without any set-off for related item of expense, etc.
3.2

Adjusted Gross Revenue (AGR)

For the purpose of arriving at the “Adjusted Gross Revenue (AGR)”, following shall be
excluded from the Gross Revenue to arrive at the AGR:
I.
II.
III.

4.

PSTN/PLMN/GMPCS related call charges (Access Charges) actually paid
to other eligible/entitled telecommunication service providers within India;
Roaming revenues actually passed on to other eligible/entitled
telecommunication service providers and;
Service Tax on provision of service and Sales Tax actually paid to the
Government if gross revenue had included as component of Sales Tax
and Service Tax.

Technical & Operating Conditions

4.1
The
Licensee’s
network
shall
be
compliant
to
the
Regulations/Directions/instructions issued by TRAI/Licensor in respect of Mobile
Number Portability (MNP) before commencement of mobile services.
4.2
The sharing of infrastructure, owned, established and operated by the Licensee
under the scope of this Authorization, is permitted as below:
(i)
Sharing of “passive” infrastructure viz., building, tower, dark fiber, duct space,
Right of Way etc. with other Licensees.
(ii)
Provision of point to point bandwidth from their own infrastructure within their
Service Area to other licensed telecom service providers for their own use. However,
the Licensee hiring the bandwidth shall not resell such bandwidth.
4.3
Further, the Licensee may share its own active and passive infrastructure for
providing other services authorized to it under the license.
4.4
Moreover, sharing of active infrastructure with other licensees shall be governed
by the license conditions/amendments issued by the Licensor from time to time.
4.5

Location of switches and other network elements

(i) The licensee shall install applicable system within its service area. However, for IP
based Next Generation Network, Media Gateway Controller (MGC)/ Soft Switch can be
deployed within geographical boundaries of any one of the authorized service area for
47

<!-- page 48 -->

Access Services or anywhere in the country if the Licensee has authorization for
NLD/ILD service also. However, the Media Gateways shall be installed in each service
area to perform the function of switching subscriber traffic under the control of MGC for
call control.
(ii) The MGC/ Soft Switch and common service support systems such as Intelligent
Networks (IN), Billing, Network Operations Center (NOC) or any other equipment
specifically permitted by the Licensor, shall be located in a service area where the
licensee has Access service authorization or anywhere in the country if the Licensee
has authorization for NLD/ILD service also. Location of MGC/ soft switch and common
service support systems shall be intimated to Licensor as and when commissioned. In
respect of Short Message Service Center (SMSC), it can be installed in any of the
service areas where Licensee has authorization of access service.
5.

Provision of IPTV Service:

5.1(a) The Licensee while providing TV channels through IPTV shall transmit only
those television channels and in exactly same form (unaltered), which are registered
with or are otherwise permitted by the Ministry of Information and Broadcasting. In such
cases, the responsibility to ensure that content is in accordance with the extant laws,
rules, regulations etc. shall be that of the broadcaster and telecom Licensee will not be
held responsible. The Licensee shall not carry any television channels prohibited either
permanently or temporarily or not registered with the Ministry of Information &
Broadcasting.
5.1(b) The Licensee can obtain content from the Multi System Operator or the Cable
Operator for providing IPTV services.
5.1(c) The Licensee providing IPTV will show only those News and Current Affairs
television channels which have been registered with Ministry of Information and
Broadcasting. The Licensee will not produce or provide any other broadcast or nonbroadcast channel having any element of News and Current Affairs.
5.1(d) The provisions of Programme code and Advertisement code as provided in
Cable Television Network (Regulation) Act 1995 and Rules there under shall be
applicable even in the case of contents other than TV channels from broadcast
provided by the Licensee. Since the Licensee will be providing this content, the
Licensee shall be responsible for ensuring compliance to the codes with respect to
such content. In addition to this, such LICENSEEs will also be bound by various Acts,
instructions, directions, guidelines issued by the Central Government from time to time
to regulate the contents.
5.1(e) If the contents are being sourced from content providers other than Licensee,
then it will be the responsibility of Licensee to ensure that their agreements with such
content providers contain appropriate clauses to ensure prior compliance with the
Programme and Advertisement Codes and other relevant Indian laws, civil and criminal,
regarding content.
5.1(f) The Central Government in the Ministry of Information and Broadcasting shall
have the right to notify the number and names of channels of Prasar Bharati or any
other channel for compulsory carriage by the Licensee and the manner of reception and
retransmission of such channels.

48

<!-- page 49 -->

5.1(g) The Licensee while providing IPTV services should provide commercial
interoperability so that if the subscribers decide to switch over to any other service
provider or platform, they should be able to do so at the least cost. Commercial
interoperability here would mean that in addition to offering the receiver set on an
outright purchase basis, a subscriber should also have the option to purchase it on a
hire-purchase basis or on rental basis with a provision to return the receiver set on such
terms and conditions as may be laid down by regulations issued by TRAI.
5.2
The Government / Ministry of Information and Broadcasting may direct the
Licensee providing IPTV service to ensure preservation and retention for a period of 90
days from the date of broadcast unless specified otherwise, of different kinds of content
made available to their subscribers and requires it to ensure its security and also that it
is not tampered with during such period. The Licensee providing IPTV service may be
required to produce the same to the Government or its authorized representative, as
and when required and the Licensee providing IPTV service will be required to ensure
compliance to all such directions.
5.3
The Licensee providing IPTV service shall provide necessary facility for
continuous monitoring of the IPTV network at its own cost. The monitoring system must
provide Set top Box subscriber information as well as contents to the law enforcement
agency in plain readable, audible and viewable format as the case may be.
Provided that in case of any dispute, the records of broadcast of programmes
and advertisements shall be maintained till final disposal of the dispute.
Provided further that the Licensee shall provide access to the Government or
its authorized representative to all its facilities, including equipments, records, system
etc. for purposes of inspection.
5.4 On demand by the Government in the Ministry of Information and Broadcasting or
its authorized representative, Licensee providing IPTV service shall provide the
necessary equipment, services and facilities at designated place(s) for continuous
monitoring of the IPTV service by or under supervision of the Government or its
authorized representative.
5.5
The Licensee providing IPTV service shall submit such information with respect
to its service as may be required by the Government in the Ministry of Information and
Broadcasting or its authorized representative from time to time.
5.6
The Licensee providing IPTV service shall furnish any such information at
periodic intervals as may be required by the Government in the Ministry of Information
and Broadcasting or its authorized representative concerning Programme Content and
Quality, Technical parameters etc. relating to the service in the format as may be
required by the Government or its authorized representative from time to time.
5.7
The Licensee providing IPTV service shall furnish the complete details such as
name, technical details and license etc. of the value added service being provided
through IPTV network.
Provided that in case any new value added service is added, the Licensee
providing IPTV service shall obtain prior approval of the Government or Licensor. The
Government or the Licensor may from time to time, prescribe or prohibit certain value
added services.
49

<!-- page 50 -->

5.8
Any breach of the provisions of Act / License / Registration / Permission by
Licensee / cable operator/ Broadcasters shall be dealt with by designated agencies
which are responsible for administering such Acts / License / Registration /
Permissions.
5.9
The decision of the Ministry of Information & Broadcasting regarding any
violation of prevailing Acts/Rules/Guidelines pertaining to their administrative
jurisdiction in respect of content carried on IPTV service shall be final. The quantum of
penalties for such violation will be decided by Licensor in consultation with respective
Ministries/Department.
5.10 The Licensee before providing IPTV will give a self-certified declaration in the
specified format to the Licensor, M/o I&B and TRAI giving details of license no. and
service area under which IPTV service is proposed to be provided / started, the start
date, the areas being covered, details of network infrastructure etc.
6.

Network Interconnection:

6.1
Inter-Circle traffic from one service area to another shall be routed through the
network of NLD licensee or the Unified Licensee having authorization of NLD service.
6.2
It shall be mandatory for the LICENSEE to interconnect to/ provide
interconnection to all eligible Telecom Service Providers (eligibility shall be determined
as
per
the
service
provider’s
License
Agreement
and
TRAI’s
determinations/orders/regulations issued from time to time) to ensure that the calls are
completed to all destinations. Further, the Licensor may direct the Licensee to
implement the process whereby the subscribers could have a free choice to make intercircle/ international long distance calls through NLD/ ILD Operator.
6.3
International Long Distance traffic should be routed through network of NLD
service providers, to the ILD service provider’s gateways for onward transmission to
international networks subject to fulfillment of any Guidelines/ Orders/ Directions/
Regulation issued from time to time by LICENSOR/ TRAI. However, the Licensee shall
not refuse to interconnect with the ILD Service licensee directly in situations where POP
of ILD service licensee and Switches of Licensee’s (GMSC/ Transit Switch) are located
at the same station of Level-I TAX.
7.

Emergency and Public Utility Service:

7.1
The LICENSEE shall provide independently or through mutually agreed
commercial arrangements with other Telecom Service Providers all public utility
services as well as emergency services including toll free services like police, fire,
ambulance. Licensor may declare any public utility or emergency number as toll free
service from time to time. While providing access to public utility services/ emergency
services/ emergency response services/ services for relief and rescue on occurrence of
disaster including police, fire, etc. as defined from time to time, the Licensee shall take
all measures to ensure that such calls are delivered to the designated control room of
the concerned authority, as prescribed from time to time.
8.

Security Conditions:

8.1 (i) Licensee shall ensure that the Base Stations, Cell Sites or Radio Transmitters,
as the case may be, to provide mobile telephone services near International Border of
India, wherever located and established shall be as far away from such border as
50

<!-- page 51 -->

feasible and such Base Stations, Cell Sites or Radio Transmitters shall work in such a
fashion that radio signal(s), emanating there from, fade out when nearing or about to
cross international border and become unusable within a reasonable distance across
such border. For this purpose, suitable technical infrastructure shall be installed by the
Licensee.
8.1 (ii) Notwithstanding anything in condition 8.1(i) above, in the areas falling within 10
Kms of Line of Control (LOC), Line of Actual Control (LAC) and International Border
between Akhnoor in J&K and Pathankot and other areas as may be notified from time
to time by the Licensor, installation of Base Stations, Cell Sites or Radio transmitters or
any concerned equipment and execution of the concerned project by the Licensee shall
be taken up only after prior approval from local Army authorities about specific location
of BTS with prior intimation to the Licensor and concerned TERM Cell in addition to
requisite clearances.
8.1(iii) The Licensor, its authorized representative(s) as well as Army authorities may
inspect such BTS(s) and the Licensee shall facilitate inspection of the BTS as per
requisition from such authorities. During emergency, if so desired by the Licensor and /
or Army, the Licensee shall shut down such BTS(s) under intimation to the
Licensor/concerned TERM Cell. The order for shutting down such BTS(s) by Army must
be signed by at least Commanding Officer of local Army Unit.
8.1 (iv) Periodic surprise checks may be carried out by the Licensor or its authorized
representative(s) /Army and / or security agencies in order to ensure compliance of the
above conditions by Licensee(s). In case, any violation is detected, stern action shall be
taken according to the terms and conditions of the License Agreement, including
imposition of financial penalty.
8.2
The designated person of the Central/ State Government as conveyed to the
Licensor from time to time in addition to the Licensor or its nominee shall have the right
to monitor the telecommunication traffic in every MSC/ Exchange/ MGC/ MG/ Routers
or any other technically feasible point in the network set up by the Licensee. The
Licensee should make arrangement for monitoring simultaneous calls by Government
security agencies. For establishing connectivity to Centralized Monitoring System, the
Licensee at its own cost shall provide appropriately dimensioned hardware and
bandwidth/dark fibre upto a designated point as required by Licensor from time to time.
However, the respective Government instrumentality shall bear the cost at its end
hardware and leased line circuits from the MSC/ Exchange/ MGC/ MG/Router or from
the designated point as the case may be, to its monitoring centre to be located as per
its choice in its premises or in the premises of the Licensee. In case the security
agencies intend to locate the equipment at Licensee’s premises for facilitating
monitoring, the Licensee should extend all support in this regard including Space and
Entry of the authorized security personnel.
The Interface requirements as well as features and facilities as defined by the
Licensor should be implemented by the Licensee for both data and speech. The
Licensee should ensure suitable redundancy in the complete chain of Lawful
Interception and Monitoring equipment for trouble free operations of monitoring of at
least 480 simultaneous calls as per requirement with at least 30 simultaneous calls for
each of the designated security/ law enforcement agencies. Each MSC of the Licensee
in the service area shall have the capacity for provisioning of at least 3000 numbers for
monitoring. Presently there are ten (10) designated security/ law enforcement agencies.
The above capacity provisions and no. of designated security/ law enforcement
51

<!-- page 52 -->

agencies may be amended by the Licensor separately by issuing instructions at any
time.
8.3
Along with the monitored call, Call Related Information (CRI) shall be supplied in
the format prescribed from time to time, which shall at least have the following records:
(i) Called/calling party mobile/ PSTN numbers, even when subscriber is roaming.
(ii) Time/date and duration of call.
(iii) Location of target subscribers/coordinates and name of BTS site.
(iv) Telephone numbers if any call-forwarding feature has been invoked by target
subscriber.
(v) Data records for failed call attempts.
(vi) CDR (Call Data Record) of Roaming Subscriber.
The Licensor reserves the right to modify the requirement of records in respect of
CRI any time.
The Licensee shall be required to provide the call data records of all the specified
calls handled by the system at specified periodicity, as and when required by the
security agencies in the format prescribed from time to time.
8.4 The call detail records for outgoing calls made by those subscribers making large
number of outgoing calls day and night to the various telephone numbers with normally
no incoming calls, should be analyzed. The service provider should run special
programme, devise appropriate fraud management and prevention programme and fix
threshold levels of average per day usage in minutes of the telephone connection; all
telephone connections crossing the threshold of usage should be checked for bonafide
use. A record of check must be maintained which may be verified by Licensor any
time. The list/details of suspected subscribers should be informed to the respective
TERM Cell of DoT and any other officer authorized by Licensor from time to time.
8.5

Location Details:

(i)
The Licensee shall provide location details of mobile customers in the Service
Area as per below mentioned accuracy and time frame (from the effective date of this
license). It shall be a part of CDR in the form of longitude and latitude, besides the coordinate of the BTS, which is already one of the mandated fields of CDR.
Accuracy in Percentage
Distance
in Meters

50
100
300
500

Urban
(More than 1
million mobiles in
a municipal limit)
1 year 2 years
30
60
80

50
75
95

Sub – Urban & Rural
1 year*

2 years

3 years

50
60

50
60
70

60
70
80

Remote

2
years

50
60

3 years

60
70

*Applicable for the state of J&K, Assam and NE region.

52

<!-- page 53 -->

(ii)
To start with, these details will be provided for specified mobile numbers.
However, within a period of 3 years from effective date of license, location details shall
be part of CDR for all mobile calls.
(iii)
Depending upon the technological feasibility and development, the limits of
accuracy requirement with respect to location as part of CDR can be modified by the
Licensor any time in future.
(iv)
In case of Licensees who have migrated to Unified License from earlier Access
Service license, their obligations regarding location details, as mentioned in the above
conditions 8.5(i) to 8.5(iii), with respect to the reference date of obligations shall be
carried forward.
8.6
CLI Restriction (CLIR) should not be normally provided to the customers. Due
verification for the reason of demanding the CLIR, must be done before provision of the
facility. It shall be the responsibility of the service provider to work out appropriate
guidelines to be followed by their staff members to prevent misuse of this facility. The
subscribers having CLIR should be listed in a password protected website with their
complete address and details so that authorized Government agencies can view or
download for detection and investigation of misuse. While providing CLIR facility to
subscriber, it shall be ensured that the CLI is carried from end to end on the network.
However, CLIR must not be provided in case of bulk connections, call centres,
telemarketing services.

53

<!-- page 54 -->

ANNEXURE-A
(Proforma for Affidavit regarding details of calculation of “Revenue” and “License Fee”)
AFFIDAVIT
I ……………………………….., aged about ………….. years son of Shri
…………………, resident of ………………………………………………., do
solemnly affirm and state as under:
2.

That I am …………… …………………….of ………………………… (Name of the
Company), LICENSEE of ………………………………………. Service in
…………………………..Service Area and I am duly authorized by the resolutions
dated …………………………. Passed by Board of Directors of the Company to
furnish affidavit on behalf of ………………………….( Name of the Company).

3.

That in compliance of Condition No.. ………. Of Schedule…………..Part
………. And Annexure……of the License Agreement No. ………………………
signed between the Company and the Department Of Telecommunications, for
payment of License fee, a payment of Rs. ………………….. (Rupees ……….
……………………….
Is being made for the period ………………….. to
………………………….. . The details of calculation of ‘revenue’ and License fee
is as per Appendix-II …… (attached).

4.

That the contents in para 2 & 3 and Statement made in Annexure ___ are true
and correct to the best of my knowledge, based on the records of the company.

Deponent.

VERIFICATION:
Verified at ___________ on ___________ that the contents of paragraphs 1 to 3
of this Affidavit and attached ‘Statement of Revenue and License Fee’ as Annexure are
true and correct to the best of my knowledge, no part of it is false and nothing has
been concealed therefrom.
Deponent.

54

<!-- page 55 -->

APPENDIX-I to ANNEXURE-A
Format of Auditor’s Report On Statement Of Revenue And License Fee
To
The Board of Directors
……………………….
……………………….
We have examined the attached Statement of Revenue and License Fee of
………………………………………(the name of the operators) for the quarter(s) ending
_____________. We have also examined the reconciliation of the cumulative figures
for the quarter(s) ending _________ appearing in the Statement of Revenue and
License Fee of the company with the figures appearing in the profit and loss account of
the company for the year ended_________ which was audited by us. We understand
that the aforesaid statement(s) ( and the reconciliation) is /are to be furnished to the
Central Government for assessment of the License fee payable by the company to the
Government, in terms of the License agreement No…………………. signed between
the company and the Department of Telecommunications.
We report that:
1.
2.

3.

4.

*

We have obtained all the information and explanations which to the best of our
knowledge and belief were necessary for the purposes of our audit.
In our view, the company has an adequate internal control system in relation to
revenues which is commensurate with its size and the nature of its business.
The system, in our opinion, provides reasonable assurance that there is no
unrecorded revenue and that all revenue is recorded in the proper amount and in
the proper period.
No amounts payable in respect of sales tax, service tax or PSTN/toll/roaming
charges were outstanding at the last day of the quarter(s) for a period of more
than two months from the date they became payable, except for the
following:………
In our opinion and to the best of our knowledge and belief and according to the
explanations given to us, the Statement has been prepared in accordance with
the norms/guidelines contained in the said License agreement in this behalf and
gives a true and fair view of the revenue and License fee payable for the period
computed on the basis of the aforesaid guidelines except for the following:
Strike off wherever not applicable.
(SIGNATURE)

55

<!-- page 56 -->

APPENDIX-II toANNEXURE-A
Format of Statement of Revenue and License Fee
_____________________(Name and address of operator)
Access Services in___________________( Service Area)
Statement of Revenue and License Fee for the Quarter
…………………………………
of the financial year………………………………………..

S.N.
PARTICULARS

1
A
(i)
(ii)
(iii)
(iv)
(v)

(vi)
(vii)
(viii)

(ix)

B
(i)
(ii)
(iii)
(iv)
(v)

(vi)
(vii)
(viii)

ACTUALS
FOR
THE
PREVIOUS
QUARTER

(AMOUNT IN RUPEES)
ACTUALS
CUMULATIVE
FOR
THE UPTO
THE
CURRENT
CURRENT
QUARTER
QUARTER.

Revenue from services
Revenue from wire-line
subscribers:
Rentals
Call revenue within service
area
National LONG DISTANCE
CALL revenue
International
LONG
DISTANCE CALL revenue
Pass thru revenue for usage
of other networks (give
OPERATOR-wise details)
Service tax
Service charges
Charges on account of any
other value added services,
Supplementary Services etc.
Any
other
income
/
miscellaneous receipt from
wireline subscribers.
Revenue
from
WLL
subscribers : (Fixed)
Rentals
Call revenue within service
area
National LONG DISTANCE
CALL revenue
International
LONG
DISTANCE CALL revenue
Pass thru revenue for usage
of other networks (give
OPERATOR-wise details)
Service tax
Service charges
Charges on account of any
other value added services,
56

<!-- page 57 -->

(ix)

C
(i)
(ii)
(iii)
(iv)
(v)

(vi)
(vii)
(viii)

(ix)

D
D (a)

D(a) 1.
i.
ii
iii.
iv.

v.
vi.
vii
viii.

ix.

D(a) 2.
i.

ii.

Supplementary Services etc.
Any
other
income
/
miscellaneous receipt from
WLL subscribers.
Revenue
from
WLL
subscribers : (handheld)
Rentals
Call revenue within service
area
National LONG DISTANCE
CALL revenue
International
LONG
DISTANCE CALL revenue
Pass thru revenue for usage
of other networks (give
OPERATOR-wise details)
Service tax
Service charges
Charges on account of any
other value added services,
Supplementary Services etc.
Any
other
income
/
miscellaneous receipt from
WLL subscribers.
Revenue
from
Mobile
Services:
Revenue from GSM and 3G
spectrum based Mobile
Services:
Post paid options:
Rentals
Activation Charges
Airtime Revenue
Pass
through
charges
(provide
operator-wise
details)
Service Tax
Roaming charges
Service charges
Charges on account of any
other value added services.
Supplementary Services etc.
Any
other
income/
miscellaneous receipt from
post paid options.
Pre-paid options:
Sale of pre-paid SIM cards
including full value of all
components charged therein.
Activation Charges
57

<!-- page 58 -->

iii
iv

v
vi
vii
viii.

ix

Airtime Revenue
Pass
through
charges
(provide
operator-wise
details)
Service Tax
Roaming charges
Service charges
Charges on account of any
other value added services.
Supplementary
Services
etc.
Any
other
income/
miscellaneous receipt from
pre-paid options.

D(a) 3. Revenue
from
Mobile
i Community phone service
. including full value of all
components
charged
therein.
ii.
Any
other
income/
miscellaneous receipt from
Mobile Community phone
service.
D (b)
D(b) 1.
i.
ii
iii.
iv.

v.
vi.
vii
viii.

ix.

Revenue from CDMA based
Mobile Services:
Post paid options:
Rentals
Activation Charges
Airtime Revenue
Pass
through
charges
(provide
operator-wise
details)
Service Tax
Roaming charges
Service charges
Charges on account of any
other value added services.
Supplementary Services etc.
Any
other
income/
miscellaneous receipt from
post paid options.

D(b) 2.
i.

Pre-paid options:
Sale of pre-paid SIM cards
including full value of all
components charged therein.

ii.
iii
iv

Activation Charges
Airtime Revenue
Pass
through
charges
58

<!-- page 59 -->

v
vi
vii
viii.

ix.

(provide
operator-wise
details)
Service Tax
Roaming charges
Service charges
Charges on account of any
other value added services.
Supplementary
Services
etc.
Any
other
income/
miscellaneous receipt from
pre-paid options.

D(b) 3. Revenue
from
Mobile
i Community phone service
. including full value of all
components
charged
therein.
ii.
Any
other
income/
miscellaneous receipt from
Mobile Community phone
service.
D (c)
D(c) 1.
i.
Ii
iii.
iv.

v.
vi.
Vii
viii.

ix.

D(c) 2.
i.

Ii
iii.
iv.

v.

Revenue
from
BWA
Services:
Post paid options:
Rentals
Activation Charges
Airtime Revenue
Pass
through
charges
(provide
operator-wise
details)
Service Tax
Roaming charges
Service charges
Charges on account of any
other value added services.
Supplementary Services etc.
Any
other
income/
miscellaneous receipt from
post paid options.
Pre-paid options:
Sale of pre-paid SIM cards
including full value of all
components charged therein.
Activation Charges
Airtime Revenue
Pass
through
charges
(provide
operator-wise
details)
Service Tax
59

<!-- page 60 -->

vi.
Vii
viii.

ix.

Roaming charges
Service charges
Charges on account of any
other value added services.
Supplementary
Services
etc.
Any
other
income/
miscellaneous receipt from
pre-paid options.

D(c) 3. Revenue
from
Mobile
i Community phone service
. including full value of all
components
charged
therein.
ii.
Any
other
income/
miscellaneous receipt from
Mobile Community phone
service.
E

Revenue from Voice Mail
/any other value added
service

2

Income
from
trading
activity (all including of
sales tax)
Sale of handsets (Excluding
Sales Tax)
Sale of accessories etc.
(Excluding Sales Tax)
Any
other
income/
miscellaneous receipt from
trading activity. (Excluding
Sales Tax)
Sales Tax

(i)
(ii)
(iii)

(iv)
3
i.
ii.

iii.
iv.

v.

Revenue from roaming.
Roaming facility revenue from
own subscribers.
Roaming revenue from own
subscriber
visiting
other
networks
including
STD/ISD/pass thru charges
for transmission of incoming
call during roaming.
Roaming
Commission
earned.
Roaming revenue on account
of visiting subscribers from
other
networks
(provide
operator-wise details).
Service Tax if not included
60

<!-- page 61 -->

above.
Any
other
income/miscellaneous receipt
from roaming.

vi.

4
(i)
(ii)
(iii)

Income from investments
Interest income
Dividend income
Any other miscellaneous
receipt from investments.

5

Non-refundable
deposits
from subscribers

6

Revenue from franchisees
/resellers
including
all
commissions
and
discounts etc. excluding
the
revenues
already
included in IA&IB

7

Revenue
from
sharing/
leasing of infrastructure

8

Revenue from sale/ lease of
bandwidth,
links,
R&G
cases, turnkey projects etc.

9

Revenue
from
other
Operators on account of
pass through call charges
(provide
operator-wise
details).

10

Revenue
from
other
Operators on account of
provisioning
of
interconnection
(provide
operator-wise details)

11

Miscellaneous revenue

AA

GROSS REVENUE OF THE
Licensee COMPANY: (Add
1-11)

BB
1

DEDUCT:
Charges actually paid
to
other Service Provider(s)
(Operator-wise)
Roaming revenues actually
paid to other CMSPs and

2

61

<!-- page 62 -->

3
4
BB

CC

GMPCS service providers.
(operator-wise)
Service Tax paid to the
Government
Sales Tax paid to the
Government
TOTAL
DEDUCTIBLE
REVENUE (1+2+3+4)
ADJUSTED
GROSS
REVENUE (AA-BB)
REVENUE SHARE @ ---------------OF
ADJUSTED
GROSS REVENUE

62

<!-- page 63 -->

ANNEXURE-B
NORMS FOR PREPARATION OF ANNUAL FINANCIAL STATEMENTS




















Accounts shall be maintained separately for each telecom service operated by
the Licensee company.
Any category of accrued revenue, the amount of which exceeds 5% of the total
accrued revenue, shall be shown separately and not combined with any other
item/category.
Accrued Revenue shall indicate:
(a) All amounts billable for the period.
(b) Any billings for previous years that had been omitted from the previous
years’ P&L Accounts.
(c) Any non-refundable deposits collected from the customers/franchisees to
the extent these are credited to P&L Account for the year.
Subsidiary registers/ledgers shall be maintained for each item given above so as
to enable easy verification.
Service revenue (amount billable) shall be shown gross and details of
discount/rebate indicated separately.
Security or any other Deposits taken from the subscriber shall be shown
separately, for each category, and the amount that has fallen due for refund but
not yet paid also disclosed under two categories, namely:
o Up to 45 days
o More than 45 days.
Service Tax billed, collected and remitted to the Government shall be shown
separately.
Sales Tax billed, collected and remitted to the Government shall be shown
separately.
Details of Income from sales of goods shall be furnished indicating the income
and number of items sold under each category. Method of inventory valuation
used shall also be disclosed along with computation of cost of goods sold.
Sales shall be shown gross and details of discount/rebate allowed and of sales
returns shall be shown separately.
Income from interest and dividend shall be shown separately, without any related
expenses being set-off against them on the income side of the P&L Account.
Increase/decrease of stock shall be shown separately.
Details of reversal of previous years’ debits, if any, shall be shown componentwise, under the miscellaneous head (eg. Bad debts recovered etc.)
Item-wise details of income that has been set off against corresponding
expenditure.
Roaming Charges shall be shown under the following heads separately;
(a) Roaming airtime charges collected for each external network from own
(home) subscribers.
(b) Roaming airtime charges actually remitted to each external network.
(c) Roaming commission retained (Network-wise)
(d) Roaming commission paid (Network-wise)
(e) Any other variable charges collected and retained/passed on to other
operators, with details.
Total Airtime Units (Metered Units) for home and visiting subscribers and unbilled
numbers (e.g. service connections) to be furnished separately.

63

<!-- page 64 -->

CHAPTER-IX
INTERNET SERVICE
1.
Service Area:
The License/Authorization for Internet Service are granted
for three different Categories namely Category ‘A’, Category ‘B’ and Category ‘C’. The
Service Area for Category ‘A’ authorization shall be the National Area. The Service
Area for Category ‘B’ authorization shall be the Telecom Circle/Metro area as defined in
Annexure-V. The Service Area for Category ‘C’ authorization shall be the Secondary
Switching Area (SSA) as defined in Annexure-VII. If the Licensee desires to obtain ISP
Category ‘C’ Authorization, under Unified License, for more than four SSAs in a
Telecom
Circle,
the
Licensee
shall
be
required
to
obtain
ISP Category ‘B’ authorization for that Service Area.
License/Authorization for Internet Service, granted for more than one Service
Area (Telecom Circle/Metro/SSA), shall be administered at each Service Area level.
2.

Scope of Internet Service: Scope of this Authorization covers the following:

2.1
(i) The Licensee may provide Internet access including IPTV. The subscriber
shall have unrestricted access to all the content available on Internet except for such
content which is restricted by the Licensor/designated authority under Law. The
Licensee shall not offer VPN/Closed User Group services to its subscribers. The
content for IPTV shall be regulated as per law in force from time to time.
(ii) The Licensee may provide Internet Telephony through Public Internet by the use of
Personal Computers (PC) or IP based Customer Premises Equipment (CPE)
connecting only the following:
a) PC to PC; within or outside India
b) PC / a device / Adapter conforming to TEC or International Standard in India to
PSTN/PLMN abroad.
c) Any device / Adapter conforming to TEC or International Standard connected to ISP
node with static IP address to similar device / Adapter; within or outside India.
Explanation: Internet Telephony is a different service in its scope, nature and kind from
real time voice service as offered by other licensees like Basic Service Licensees,
Cellular Mobile Telephone Service (CMTS) Licensees, Unified Access Service (UAS)
Licensees, Unified Licensee (Access Service), Unified Licensee with authorization for
access services.
(iii) The Internet Telephony, only as described in condition (ii) above, can be provided
by the Licensee. Voice communication to and from a telephone connected to
PSTN/PLMN/GMPCS and use of E.164 numbering is prohibited.
(iv) Addressing scheme for Internet Telephony shall conform to IP addressing Scheme
of Internet Assigned Numbers Authority (IANA) only and the same shall not use
National Numbering Scheme / plan applicable to subscribers of Basic / Cellular
Telephone service. Translation of E.164 number / private number to IP address allotted
to any device and vice versa, by the licensee to show compliance with IANA numbering
scheme is not permitted.
64

<!-- page 65 -->

(v) For carrying originating and terminating traffic of its subscribers, the licensee may
establish its own transmission links within its service area. For this purpose, the
Licensee may also establish ‘Last Mile’ linkages within the service area either on fiber
optic cable or radio communication or underground copper cable. In case of radio links,
procedure as mentioned in Chapter VII of this License shall be applicable.
(vi)
Unified Messaging Services (UMS) within the scope of (i) to (ii) above can be
provided by the Licensee.
(vii) Internet Service to any VSAT Service subscriber can be provided, if the VSAT is
located within the Service area of the Licensee. For this purpose, a direct
interconnection of VSAT Network Hub through leased line obtained from an authorized
service provider to the Licensee’s node/server shall be permitted only for the Internet
traffic. The Licensee shall provide to the Licensor a monthly statement of VSAT
subscribers served with their locations and details of leased line interconnection with
the VSAT Hub. The VSAT Hub, however, need not be located in the service area of the
Licensee.
(viii) The Licensee may provide internet service by using the Cable Network of
authorized Cable Operator, as last mile linkage, subject to applicable Cable Laws (The
Cable Television Networks (Regulation) Act, 1995) as modified from time to time.
(ix) Licensee may install operate and commission International Internet Gateway in the
service area using satellite or submarine cable as medium after obtaining security
clearance/approval from Licensor.
(x) Licensee with International internet gateway is allowed to sell international internet
bandwidth to other licensed internet service providers. Provision of IPLC service is not
covered under the scope of this authorization.
(xi)
The Licensee may share “passive” infrastructure namely building, tower, dark
fiber, duct space, Right of Way owned, established and operated by it under the scope
of this Authorization with other Licensees.
2.2
3.

All subscribers, except dial up subscribers, shall be within the service area.
Financial Conditions:

3.1
Gross Revenue: The Gross Revenue shall be inclusive of all types of revenue
from Internet services, revenue from Internet access service, revenue from internet
contents, revenue from Internet Telephony service, revenue from activation charges,
revenue from sale, lease or renting of bandwidth, links, R&G cases, Turnkey projects,
revenue from IPTV service, late fees, sale proceeds of terminal equipments, revenue
on account of interest, dividend, value added services, supplementary services,
interconnection charges, roaming charges, revenue from permissible sharing of
infrastructure etc. allowing only those deductions available for pass through charges
and taxes/levies as in the case of access services, without any set-off for related item of
expense etc.
3.2 For the purpose of arriving at the “Adjusted Gross Revenue (AGR)” the following
shall be excluded from the Gross Revenue to arrive at the AGR:
(i) Service Tax on provision of service and Sales Tax actually paid to the Government if
gross revenue had included as component of Sales Tax and Service Tax.
65

<!-- page 66 -->

(ii) Roaming revenue actually passed on to other eligible/entitled telecom service
provider.
4.

Network Interconnection:

4.1
The Licensee may establish direct interconnectivity with the network of other
Internet Service Providers/Unified Licensee having authorization of Internet Service.
The Licensee may obtain leased bandwidth from any other Licensee authorized to
provide such bandwidth on lease.
4.2
The Licensee shall have no connectivity with PSTN/PLMN/GMPCS networks in
the country.
4.3
Resources required for interconnecting the licensee’s network to the network of
upstream internet access provider licensed by the Licensor including time frame for
provision of the same, will be mutually agreed between the parties concerned.
4.4
Licensees shall use IP (Internet Protocol) in conjunction with Transmission
Control Protocol (TCP) and shall meet the interface requirements as prescribed by TEC
/ Licensor to connect with other Telecom Service Providers’ network.
4.5
For provision of IPTV services, Condition no. 5 of Chapter no. VIII (Access
Services) shall be applicable.
5.

Provision of Service:

5.1
The Licensee shall have the right to undertake the sale, hire purchase, lease or
renting of the subscriber fixed / mobile terminals / CPE. Proper usage of terminal/CPE
at subscriber's premises shall be as per agreement between the Licensee and
subscriber.
5.2 For the purpose of providing the Service, the Licensee shall install its own suitable
equipment so as to be compatible with the other eligible licensed service providers’
equipment and connect the same directly or through any of the authorized licensed
service provider to Internet Gateway for routing International Internet Traffic.
5.3
The Licensee, having DTH service License from Ministry of Information and
Broadcasting, shall be permitted to allow customers for downloading internet data
through DTH after obtaining necessary permission from the Licensor. However, to
provide bidirectional Internet services through DTH, the Licensee shall be required to
have VSAT Service authorization.
5.4
It will be the responsibility of the Licensee to obtain IP addresses, domain name
etc. from competent authority.
5.5
In case the Licensee provides the Internet Access using de-licensed frequency
band, the licensee shall adhere to the prevailing directions/instructions and shall also
abide by further directions / instructions as may be issued by Licensor from time to time
in this regard.

66

<!-- page 67 -->

6.

Requirement to furnish information:

6.1
The licensee shall provide to the licensor, a quarterly report indicating the details
of ISP Nodes or Points of Presence with their locations and number of broadband /
leased / dial up subscribers. In case new nodes are to be installed, one month prior
notice is required to be given to the licensor.
6.2
The licensee shall provide to the licensor on regular basis the volume of internet
telephony traffic flowing through its network.
6.3
In case, the Licensee has authorization for both Access Service and Internet
Service in a common geographical area, the Licensee shall declare to the Licensor,
prior to commencement of service, the Service authorization (namely Access Service or
Internet Service authorization) under which the internet services are to be provided.
7.

Security Conditions:

7.1
The Licensee shall maintain CDR/IPDR for Internet including Internet Telephony
Service for a minimum period of one year. Parameters of IPDR shall be maintained as
per the directions/instructions issued by the Licensor from time to time.
7.2
The Licensee shall maintain log-in/log-out details of all subscribers for services
provided such as internet access, e-mail, Internet Telephony, IPTV etc. These logs
shall be maintained for a minimum period of one year.
7.3
For the purpose of interception and monitoring of traffic, the copies of all the
packets originating from / terminating into the Customer Premises Equipment (CPE)
shall be made available to the Licensor/Security Agencies.
7.3
The list of Internet Lease Line (ILL) customers is to be placed on a password
protected website in the following Performa:Name of IP address Bandwidth
Subscriber allotted
provided

Address of Date
of Contact
Installation Installation/
person with
Commissioning Phone /email

The Licensee shall advice its ILL customers to maintain the usage of IP
addresses/Network Address Translation (NAT) syslog, in case of multiple users on the
same ILL, for a minimum period of one year. The Licensee shall ensure compliance of
the above requirement by taking periodic feedback from the ILL customers or shall take
any other measures as necessary for compliance of this requirement. In case, the
Licensee finds that ILL customer is non-compliant to the above requirement, the
Licensee shall withdraw the service.
7.4
The login ID/ Password shall be provided to concerned DDG (TERM) of DoT.
Online updation of ILL customers’ data by Licensees should be done. This information
shall be accessible to authorized Government agencies.
7.5
Periodical inspections are to be carried out at the premises of ILL customers to
check possible misuse and possible interconnection of Internet leased line with PSTN,
PLMN, GMPCS network. First inspection at the premises of the customer must be done
within 15 days of commissioning of Internet leased line.
67

<!-- page 68 -->

7.6
A record of complete network diagram of set up at each of the ILL customer
premises along with details of connectivity shall be available at the site. All details of
other communications links (PSTN, NLD, ILD, WLL, GSM, other ISP etc.) and reasons
for taking the link by the customer to be recorded before activation of the link. The
same shall also be readily available for inspection at the respective premises of all ILL
customers.
7.8
An agreement shall be executed with each ILL customer which clearly mentions
the activities that are prohibited.
7.9
Licensee shall ensure that an entity, requesting ILL connection to use it for
provision of Internet services to its (entity’s) customers, should have a valid
authorization for Internet Service.
7.10 All the terms and conditions related to ILL under this authorization shall also
apply to the Internet Service provided through VSAT.
7.11 In case Licensee detects the misuse of Internet Leased Line, the Licensee shall
take immediate action to disconnect the service to this subscriber and file an FIR
against the subscriber. The Licensee shall intimate the Licensor of such misuse within
24 hours of detection of the same. In case such a misuse is detected by the Licensor,
the onus shall lie on the Licensee to prove that it had not connived in the misuse by its
ILL subscriber and has taken all the above mentioned steps to check the misuse of ILL.
Wherever it is found that the Licensee has itself been involved in/abetted the misuse of
ILL, it shall be construed as breach of terms and conditions of the license agreement.
7.12 In the interest of national security or public interest, the Licensee shall block
Internet sites/Uniform Resource Locators (URLs)/Uniform Resource Identifiers (URIs)
and / or individual subscribers, as identified and directed by the Licensor from time to
time.
7.13 The traffic of Internet nodes on places of security importance would be routed as
per directions issued from time to time by Licensor. Interconnection of these nodes to
other nodes within the country directly is not permitted.
8.

Monitoring Facilities:

8.1.1 Lawful Interception and Monitoring (LIM) systems of requisite capacities are to
be set up by LICENSEEs for Internet traffic including Internet telephony traffic through
their Internet gateways and /or Internet nodes at their own cost, as per the requirement
of the security agencies/Licensor prescribed from time to time. The cost of maintenance
of the monitoring equipment and infrastructure at the monitoring centre located at the
premises of the licensee shall be borne by the Licensee.
8.1.2 In case the Licensee obtains Access spectrum for providing Internet Service /
Broadband Wireless Access using the Access Spectrum, the Licensee shall install the
required Lawful Interception and Monitoring systems of requisite capacities prior to
commencement of service.
8.2
The Licensee, while providing downstream Internet bandwidth to an Internet
Service provider should ensure that all the traffic of downstream ISP passing through
the Licensee’s network can be monitored in the network of the Licensee.
68

<!-- page 69 -->

8.3
However, for nodes of Licensee having upstream bandwidth from multiple
service providers, the Licensee may be mandated to install LIM/LIS at these nodes, as
per the requirement of security agencies. In such cases, upstream service providers
may not be required to monitor this bandwidth.
8.4
In case the Licensee has multiple nodes/points of presence and has capability to
monitor the traffic in all the Routers/switches from a central location, the Licensor may
accept to monitor the traffic from the said central monitoring location, provided that the
Licensee is able to demonstrate to the Licensor/Security Agencies that all routers /
switches are accessible from the central monitoring location. Moreover, the Licensee
would have to inform the Licensor of every change that takes place in their topology
/configuration, and ensure that such change does not make any routers/switches
inaccessible from the central monitoring location. Further, on making any such change
in the network, Licensee shall demonstrate, if so required by the Licensor, compliance
to the above conditions and the decision of Licensor in this regard shall be final.
8.5
Office space of 10 feet x 10 feet with adequate and uninterrupted power supply
and air-conditioning which will be physically secured and accessible only to the
monitoring agencies shall be provided by the Licensee at each Internet Gateway
location at its cost.

69

<!-- page 70 -->

Annexure-A
(Performa for Affidavit regarding details of calculation of “Revenue” and “License Fee”)

AFFIDAVIT
I ……………………………….., aged about ………….. years son of Shri
…………………, resident of ………………………………………………., do solemnly
affirm and state as under:
2.
That I am …………… …………………….of ………………………… (Name of the
Company),
Licensee
of
……………………………………….
Service
in
…………………………..Service Area and I am duly authorised by the resolutions dated
…………………………. passed by Board of Directors of the Company to furnish
affidavit on behalf of ………………………….( Name of the Company).
3.
That in compliance of Condition No.. ………. Of Schedule…………..Part ……….
the License Agreement No. ……………………… signed between the Company and the
Department Of Telecommunications, for payment of License fee, a payment of Rs.
………………….. (Rupees ………. ………………………. is being made for the period
………………….. to ………………………….. . The details of calculation of ‘revenue’
and License fee is as per Appendix-II …… (attached).
4.

That the contents in para 2 & 3 and Statement made in Annexure ___ are true
and correct to the best of my knowledge, based on the records of the company.

Deponent.

Verification:
Verified at ___________ on ___________ that the contents of paragraphs 1 to 3
of this Affidavit and attached ‘Statement of Revenue and License Fee’ as Annexure are
true and correct to the best of my knowledge, no part of it is false and nothing has
been concealed therefrom.
Deponent.

70

<!-- page 71 -->

Appendix–I to Annexure-A

(Format of Auditor’s Report on Statement of Revenue And License Fee)

To
The Board of Directors
……………………….
……………………….
We have examined the attached Statement of Revenue and License Fee of
………………………………………(the name of the operators) for the quarter(s) ending
_____________. We have also examined the reconciliation of the cumulative figures
for the quarter(s) ending _________ appearing in the Statement of Revenue and
License Fee of the company with the figures appearing in the profit and loss account of
the company for the year ended_________ which was audited by us. We understand
that the aforesaid statement(s) ( and the reconciliation) is /are to be furnished to the
Central Government for assessment of the License fee payable by the company to the
Government, in terms of the License agreement No…………………. signed between
the company and the Department of Telecommunications.
We report that:
1.
2.

3.

4.

*

We have obtained all the information and explanations which to the best of our
knowledge and belief were necessary for the purposes of our audit.
In our view, the company has an adequate internal control system in relation to
revenues which is commensurate with its size and the nature of its business.
The system, in our opinion, provides reasonable assurance that there is no
unrecorded revenue and that all revenue is recorded in the proper amount and in
the proper period.
No amounts payable in respect of sales tax, service tax were outstanding at the
last day of the quarter(s) for a period of more than two months from the date they
became payable, except for the following:………
In our opinion and to the best of our knowledge and belief and according to the
explanations given to us, the Statement has been prepared in accordance with
the norms/guidelines contained in the said License agreement in this behalf and
gives a true and fair view of the revenue and License fee payable for the period
computed on the basis of the aforesaid guidelines except for the following:
Strike off wherever not applicable.
(Signature)

71

<!-- page 72 -->

Appendix–II to Annexure-A

Format of Statement of Revenue and License Fee
_____________________(Name and address of operator)
ISP License No.
in___________________( Service Area)
Statement of Revenue and License Fee for the Quarter
…………………………………
of the financial year………………………………………..

PARTICULARS
S.N.

1

Revenue from services
A

A1.
i
ii
iii
iv
V

vi

A2.
i.

ii.

B
B1.
i
ii
iii
iv
v

vi

ACTUALS
FOR
THE
PREVIOUS
QUARTER

(AMOUNT IN RUPEES)
ACTUALS
CUMULATIVE
FOR THE
UPTO THE
CURRENT
CURRENT
QUARTER
QUARTER.

Revenue from Pure Internet
Service ( Internet Access
and Content Service):
Post paid options:
Rentals
Activation Charges
Service Tax
Service charges
Charges on account of any
other value added services.
Supplementary Services etc.
Any other income/
miscellaneous receipt from
post paid options.
Pre-paid options:
Sale of pre-paid option
including full value of all
components charged therein.
Any other income/
miscellaneous receipt from
pre-paid options.
Revenue from Internet
Telephony Service:
Post paid options:
Rentals
Activation Charges
Service Tax
Service charges
Charges on account of any
other value added services.
Supplementary Services etc.
Any other income/
miscellaneous receipt from
post paid options.
72

<!-- page 73 -->

B2.
i.

ii.

C

2

(i)
(ii)
(iii)

3
(i)
(ii)
(iii)
4

Pre-paid options:
Sale of pre-paid option
including full value of all
components charged therein.
Any other income/
miscellaneous receipt from
pre-paid options.

Revenue from any other
value added service
Income from trading
activity (all including of sales
tax)
Sale of Terminal Equipments
Sale of accessories etc.
Any other income/
miscellaneous receipt from
trading activity.

Income from investments
Interest income
Dividend income
Any other miscellaneous
receipt from investments.
Non-refundable deposits
from subscribers

5

Revenue from franchisees
/resellers including all
commissions and
discounts etc. excluding
the revenues already
included in IA&IB

6

Revenue from sharing/
leasing of infrastructure

7

Revenue from sale/ lease
renting of bandwidth, links,
R&G cases, turnkey
projects etc.

8
i

Revenue from Roaming
Roaming facility revenue from
own subscribers.
Roaming revenue from own
subscriber visiting other
networks.
Roaming Commission

ii

iii

73

<!-- page 74 -->

iv

V
vi

earned.
Roaming revenue on account
of visiting subscribers from
other networks.
Service Tax if not included
above.
Any other
income/miscellaneous receipt
from roaming

9

Revenue from IPTV
Services

10

Revenue
from
other
Operators on account of
provisioning
of
interconnection

11

Miscellaneous Revenue

AA

GROSS REVENUE OF THE
Licensee COMPANY :(Add
1-11)
.
DEDUCT:
Service Tax paid to the
Government
Sales Tax paid to the
Government
Roaming revenue actually
passed on to other
eligible/entitled telecom
service provider.
TOTAL DEDUCTIBLE
REVENUE (1+2+3+4)
ADJUSTED GROSS
REVENUE (AA-BB)
REVENUE SHARE @ ---------------- OF ADJUSTED
GROSS REVENUE

B
15
2
3

BB
CC

5

Amended vide DoT Letter No 20-281/2010 AS-I Voll-VI dated 29.08.2013

74

<!-- page 75 -->

Annexure-B

NORMS FOR PREPARATION OF ANNUAL FINANCIAL STATEMENTS

















Accounts shall be maintained separately for each telecom service operated by
the Licensee Company.
Any category of accrued revenue, the amount of which exceeds 5% of the total
accrued revenue, shall be shown separately and not combined with any other
item/category.
Accrued Revenue shall indicate:
(a) All amounts billable for the period.
(b) Any billings for previous years that had been omitted from the previous
years’ P&L Accounts.
(c) Any non-refundable deposits collected from the customers/franchisees to
the extent these are credited to P&L Account for the year.
Subsidiary registers/ledgers shall be maintained for each item given above so as
to enable easy verification.
Service revenue (amount billable) shall be shown gross and details of
discount/rebate indicated separately.
Security or any other Deposits taken from the subscriber shall be shown
separately, for each category, and the amount that has fallen due for refund but
not yet paid also disclosed under two categories, namely:
o Up to 45 days
o More than 45 days.
Service Tax billed, collected and remitted to the Government shall be shown
separately.
Sales Tax billed, collected and remitted to the Government shall be shown
separately.
Details of Income from sales of goods shall be furnished indicating the income
and number of items sold under each category. Method of inventory valuation
used shall also be disclosed along with computation of cost of goods sold.
Sales shall be shown gross and details of discount/rebate allowed and of sales
returns shall be shown separately.
Income from interest and dividend shall be shown separately, without any related
expenses being set-off against them on the income side of the P&L Account.
Increase/decrease of stock shall be shown separately.
Details of reversal of previous years’ debits, if any, shall be shown componentwise, under the miscellaneous head (eg. Bad debts recovered etc.)
Item-wise details of income that has been set off against corresponding
expenditure.

75

<!-- page 76 -->

CHAPTER-X
NATIONAL LONG DISTANCE SERVICE
1.
Service Area:
The Service Area for the National Long Distance Service
shall be at National Level.
2.

Scope of the NLD Service: Scope of this Authorization covers the following:

2.1
(a)
The NLD Service Licensee shall have the right to carry inter-circle
switched bearer telecommunication traffic over its national long distance network. The
Licensee may also carry intra-circle switched traffic where such carriage is with mutual
agreement with originating access service provider.
(b) The Licensee can also, in respect of Basic Service, make mutually agreed
arrangements with the concerned Service Providers for picking up, carriage and
delivery of the traffic from different legs between Long Distance Charging Center
(LDCC) and Short Distance Charging Centers (SDCCs).
(c)
In the case of Cellular Mobile Telephone Service traffic, the inter-circle traffic
shall be handed/taken over at the Point of Presence (POP) situated in LDCA at the
location of Level I TAX in originating/terminating service area. For West Bengal,
Himachal Pradesh and Jammu & Kashmir such locations shall be Asansol, Shimla &
Jammu respectively.
(d)
The Licensee can provide Leased Circuit / Virtual Private Network (VPN)
Services.
(e)
Further, only for provision of Leased Circuits/Close User Groups (CUGs) on
leased circuits and for provision of national long distance voice service through Calling
Cards, falling within the scope of, and, in accordance with clauses 2.1 (a) and 2.1(b)
above, the Licensee can access the subscribers directly. While providing the domestic
leased circuits, the Licensee shall be required to make own suitable arrangements for
leased circuits /agreements with the Access Providers for last mile. Public network is
not to be connected with leased circuits/CUGs.
2.2(i) The Licensee can provide bandwidth to other telecom service licensee also.
2.2(ii) The Licensee may share “passive” infrastructure namely building, tower, dark
fiber, duct space, Right of Way owned, established and operated by it under the scope
of this Authorization with other Licensees.
2.3(i) Access to the subscribers for provision of National Long Distance voice services
(excluding message services) through Calling Cards shall be strictly within the scope of
and in accordance with clauses 1.1(a) to 1.1(d) above. Provision of other Intelligent
Network based services (except Intelligent Network service for operation of Calling
Cards) such as tele-voting and toll-free services is not allowed to Licensee. Provision of
Value Added Services such as SMS/ MMS, ringtones etc. through calling cards is also
not allowed.
2.3(ii) The charges and sharing of revenues for the service features, network
architecture and resources used for providing NLD voice services through calling cards
76

<!-- page 77 -->

shall be such as are mutually agreed between the service providers within the
framework of and in accordance with regulations, directions, orders or instructions as
may be issued from time to time by TRAI and directions, orders or instructions as may
be issued from time to time by the Licensor.
2.3(iii) The licensee shall clearly indicate to the subscriber the specifications of the
service to be offered through Calling Cards at the time of entering into contract with
such subscriber.
3.

Financial Conditions:

3.1

Gross Revenue &Adjusted Gross Revenue

‘REVENUE” for the purpose of levying License fee as a percentage of revenue shall
mean the Gross total Revenue income accruing to the Licensee by way of providing
NLD service
under the License including the revenue on account of
supplementary/value added services and leasing of infrastructure, interest, dividend
etc. as reduced by the component part of a pass-through nature actually paid to other
telecom service providers to whose networks the Licensee’s NLD network is
interconnected, for carriage of calls. The Gross Revenue shall also include previous
debits (e.g. bad debts recovered, of excess provisions in earlier years.) It is clarified
that any lease or rent charges for hiring of infrastructure shall not be so deducted.
Service tax and sales tax collected and passed on to the Government(s) from
customers of the Licensee shall not form a part of the Revenue.
4.

Network Interconnection:

4.1
The licensee, who has authorization for International Long Distance, National
Long Distance, Access services, may have only one Switch to provide the ILD, NLD
and Access services. Separate accounts of all the services are to be maintained by
duly apportioning the costs amongst the various services. However, the Access Service
through the said Switch may be provided only if the Licensee has the Access Service
authorization for the Service Area in which the switch is located. For this purpose,
Media Gateway or its equivalent shall be considered as Switch for which MGC/Soft
Switch can be installed anywhere in the country. Separate TAX and Gateway switch is
not mandatory. The Licensee may deploy circuit switched or managed Packet Switched
network to engineer its NLD networks.
4.2
For provision of National Long Distance voice services through Calling Cards,
the terms and conditions of interconnection shall be as mutually agreed between the
service providers within the framework of and in accordance with regulations,
directions, orders or instructions as may be issued from time to time by TRAI and
directions, orders or instructions as may be issued from time to time by the Licensor.
4.3
It shall be mandatory for Basic Service Providers, Cellular Mobile Service
Providers, Access Service Providers, UL(AS) and Unified Licensee (with authorization
of Access Service) to provide interconnection to NLD service providers. Further, the
Licensor may direct the Licensee to implement the process whereby the subscribers
could have a free choice to make international long distance calls through ILD
Operator.

77

<!-- page 78 -->

5.

Security Conditions:

5.1
The Licensee shall ensure that the Leased circuits are regularly checked for their
bonafide use and to detect any misuse.
5.2
The requisite monitoring facilities shall be provided by the Licensee as per
requirement of Licensor. The details of leased circuit provided by the Licensee shall be
provided monthly to security agencies &DDG(TERM) of the Licensed Service Area
(LSA) where the licensee has its registered office.
5.3

The Licensee shall transit the CLI as received from the Access/ILD operators.

78

<!-- page 79 -->

Annexure-A
(Proforma for Affidavit regarding details of calculation of “Revenue” and “License Fee”)
AFFIDAVIT
I ……………………………….., aged about ………….. years son of Shri
…………………, resident of ………………………………………………., do solemnly
affirm and state as under:
1.

That I am …………… …………………….of ………………………… (Name of the
Company), Licensee of ………………………………………. Service in
…………………………..Service Area and I am duly authorised by the resolutions
dated …………………………. passed by Board of Directors of the Company to
furnish affidavit on behalf of ………………………….( Name of the Company).

2.

That in compliance of condition No.. ………. of Schedule…………..Chapter
………. and Annexure………of the License Agreement No. ………………………
signed between the Company and the Department Of Telecommunications, for
payment of License fee, a payment of Rs. ………………….. (Rupees ……….
……………………….
is being made for the period ………………….. to
………………………….. . The details of calculation of ‘revenue’ and License fee
is as per Annexure …………… (attached).

3.

That the contents in para 1 & 2 and Annexure – A are true and correct to the
best of my knowledge, based on the records of the company.

Deponent.

VERIFICATION
Verified at ………………….. on ……………………….. that the contents of paragraphs 1
to 3 of the affidavit and Annexure- A are true and correct to my knowledge, no part of it
is false and nothing has been concealed therefrom.

Deponent.

79

<!-- page 80 -->

Appendix-I to Annexure-A
Format Of Auditor’s Report On Statement Of Revenue And License Fee
To
The Board of Directors
……………………….
……………………….
We have examined the attached Statement of Revenue and License Fee of
____________________________________________________(the name of the
operators) for the quarter(s) ending _____________. We have also examined the
reconciliation of the cumulative figures for the quarter(s) ending _______________
appearing in the Statement of Revenue and License Fee of the company with the
figures appearing in the profit and loss account of the company for the year
ended________________which was audited by us. We understand that the aforesaid
statement(s) ( and the reconciliation) is / are to be furnished to the Central Government
for assessment of the License fee payable by the company to the Government, in terms
of the License Agreement No___________________________________ signed
between the company and the Department of Telecommunications. We report that:
1.
We have obtained all the information and explanations which to the best of our
knowledge and belief were necessary for the purposes of our audit.
2.
In our view, the company has an adequate internal control system in relation to
revenues which is commensurate with its size and the nature of its business.
The system, in our opinion, provides reasonable assurance that there is no
unrecorded revenue and that all revenue is recorded in the proper amount and in
the proper period.
3.
No amounts payable in respect of sales tax, service tax or PSTN/toll/roaming
charges were outstanding at the last day of the quarter(s) for a period of more
than two months from the date they became payable, except for the
following:_______________________
4.
In our opinion and to the best of our knowledge and belief and according to the
explanations given to us, the Statement has been prepared in accordance with
the norms/guidelines contained in the said License agreement in this behalf and
gives a true and fair view of the revenue and License fee payable for the period
computed on the basis of the aforesaid guidelines except for the following:
*

Strike off wherever not applicable.

80
