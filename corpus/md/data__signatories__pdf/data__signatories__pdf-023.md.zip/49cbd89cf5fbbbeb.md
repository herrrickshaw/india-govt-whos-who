---
doc_id: "49cbd89cf5fbbbeb"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/38b0dba4f888dea9625903e69d9cc324.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Decentralisation of work of Maintenance and Renewal of FBG in respect of Spectrum Charges to the O/o CCA from 01-04-2011 . Letter dated19.05.2011"
date: "2011-05-19"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0245c05f595d3477"
---

<!-- page 1 -->

WFD/.1000/WPC-sp ch /FBG/02-2004-WFD
Government of India
Ministry of Communications
Department of Telecommunications
(WPF Branch)
Dt 19. 05. 2011

To
All the Pr. Cs CN Cs CA
Sub:- Decentralisation of work of Maintenance and renewal of FBG in respect of
spectrum charges to the 0/o CCA from 1-4-2011 .
Madam/ Sir,
Kindly refer to this office letters of even no dated 22nd 23rd of March 2011 on
the above subject vide which the work of maintenance and renewal of FBG in respect of
spectrum charges has been decentralized to the O/o CCA wef 1-4-2011 . In this regard
queries have been received from different o/o CCA seeking clarification on various issues
related to FBGs .It is clarified that :­
(1) Submission of FBGs by the Licensees who have not rolled out their services.
~lauses 21 .3 of license agreement may be referred in th is regard wh ich is
reproduced as
" The fees , charges and royalties for the use of spectrum and also for possession of
Wireless telegraphy equipment shall be separately securitized by furnishing FBG of an
amount equivalent to the estimated sum payable annually in the proforma annexed , to
WPC, valid for a period of one year, renewable from time to time till final clearance of all
such dues."
There is no prov1s1on for submission of FBG for an initial and minimum amount.
Clarification has been sought from the concerned wing of DOT and the same will be
intimated as and when it is received .
(2) Submission of FBGs by the Licensees who have not rolled out their services:- The
operators who have rolled out their services and have not submitted FBG may be requested
to submit same in view of clause 21 .3 of License Agreement.
(3) Calculation of amount for FBG :- Amount for FBG will be worked out as under:
Amount of FBG:- (Spectrum charges payable for the last 4Qtrs)*2 .20
4
It is further clarified that preference for consideration of AGR for the purpose
of calculation of spectrum charges will be in order of Audited AGR , Actual AGR and
estimated AGR.

<!-- page 2 -->

(4) Periodicity for the review for amount required : The amount of FBG will be reviewed
on six monthly basis. FBG for additional amount is to be submitted by the Licensee
accordingly.

It is reiterated that all the instructions issued by LF wing of DOT from time to time
may be referred in this regard
This issues with the approval of Sr. DOG (WPF) .

( Shree Ram)
ADG (WR)
Ph. 23036362
