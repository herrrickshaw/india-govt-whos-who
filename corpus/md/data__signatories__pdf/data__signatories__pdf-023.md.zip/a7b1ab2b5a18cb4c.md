---
doc_id: "a7b1ab2b5a18cb4c"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/ee200950989c33bd9f00a6d41c5df885.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List dated 27th March 06 of officers of P&T Building Works (Group A) Service of Electrical Wing of DoT whose Presidential Orders issued"
date: "2006-03-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "352ab2388850443c"
---

<!-- page 1 -->

LIST OF OFFICERS OF P&T BUILDING WORKS (GROUP A) SERVICE OF ELECTRICAL WING
OF DOT WHOSE PRESIDENTIAL ORDERS ISSUED
Sl.
Name (S/Shri/Smt) Staff No. Substantive Substantive Grade /on retirement
PO
No.
Grade as on
& Unit of posting
issued
30.9.2000
for
2

Manish Kumar
Girjesh Singh Solanki

3
4
5

Kartikeya Sinha
Akhilesh Trivedi
A.K. Jain, CE (E)

1

96586
96587
96589
96575
95021

AEE (E)

AEE (E), BSNL, Bhopal

BSNL

AEE(E)

CCA, New Delhi
CCA, Bombay
EE(E), MTNL, N. Delhi
CE(E), BSNL, N. Delhi

BSNL

AEE (E)
AEE(E)
EE(E)

BSNL
BSNL
BSNL
