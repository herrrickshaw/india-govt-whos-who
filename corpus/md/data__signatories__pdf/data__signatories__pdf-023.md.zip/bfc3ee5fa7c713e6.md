---
doc_id: "bfc3ee5fa7c713e6"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/9c290d368b2478c35dce730a8f390612.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Format for Commercial VSAT License - September,2009"
date: "2009-09-07"
pages: 55
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "29c02430c4d4c282"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF COMMUNICATION & INFORMATION
TECHNOLOGY
DEPARTMENT OF TELECOMMUNICATIONS

LICENCE AGREEMENT
FOR PROVISION OF
VSAT SERVICE USING INSAT SYSTEM
No. : 815-

/

-1-

-DS

<!-- page 2 -->

LICENCE AGREEMENT
This AGREEMENT is made on the --------------------- by and between the President of India
acting through Shri.........…………………………... (name), ADG (
) Department of
Telecommunications (DOT), Government of India, Sanchar Bhawan, 20 Ashoka Road, New
Delhi -110001 (hereinafter called the LICENSOR which expression shall, unless
repugnant to the context , include its successors and assigns) of the FIRST PARTY.
AND
M/s............………….........………...LIMITED , a company ................................
Registered under the Companies Act 1956 and having its registered office at
..................................………………………. acting through Shri ….................................... the
authorized signatory (hereinafter called the LICENSEE which expression shall, unless
repugnant to the context include its successors in business, administrators, liquidators, legal
representatives and permitted assigns) of the SECOND PARTY.
WHEREAS by virtue of provisions of Section 4 of Indian Telegraph Act1885, the
LICENSOR has privilege to grant the LICENCE and LICENSEE has requested to grant
Licence to establish, install, operate and maintain VSAT Closed Users Group Domestic Data
Network service via INSAT Satellite System on non- exclusive basis within territorial
boundary of India.
AND WHEREAS in pursuance to the said request of the LICENSEE , the LICENSOR has
agreed to grant the LICENCE to the LICENSEE to establish, install, operate and maintain
VSAT Closed Users Group Domestic Data Network service via INSAT Satellite System
(hereinafter called the SERVICE) on non- exclusive basis within territorial boundary of
India.
NOW THIS AGREEMENT WITNESSTH AS FOLLOWS :1.

In consideration of the payment of Entry Fee along with other payments mutually
agreed including LICENCE Fee and due performance of all terms and conditions
mentioned in the SCHEDULE on the part of the LICENSEE, the LICENSOR does,
hereby grant under section 4 of the Indian Telegraph Act 1885 ,on a non-exclusive
basis, this LICENCE to establish, install, operate and maintain the VSAT Closed
Users Group Domestic Data Network service via INSAT Satellite System (
SERVICE) within territorial boundary of India on the terms and conditions contained
in the SCHEDULE appended to this LICENCE AGEEMENT.

2.

Subject to Clause (1) herein above, the LICENCE hereby granted will remain valid
for 20 (Twenty) years from the Effective date, unless revoked earlier.

3.

The LICENSEE hereby agrees and unequivocally undertakes to fully comply with all
terms and conditions stipulated in this LICENCE AGREEMENT without any
deviation or reservations.

4 .

Unless otherwise mentioned or appearing from context, the Guidelines for provision
of VSAT Closed Users Group Domestic Data Network service via INSAT Satellite
System including the application and the Letter of Intent for LICENCE to operate
VSAT Closed Users Group Domestic Data Network service via INSAT Satellite

-2-

<!-- page 3 -->

System, shall form part and parcel of this AGREEMENT and all of them shall be read
as a single document. Provided, however, that in case of conflict or inconsistency on
any issue relating to this LICENCE AGREEMENT, the terms set out in the main
body of this AGREEMENT read with schedules and ANNEXURES hereto shall
prevail.
5.

The License shall be governed by the provision of Indian Telegraph Act, 1885, Indian
Wireless Telegraphy Act, 1933 and Telecom. Regulatory Authority of India Act, 1997
as modified or replaced from time to time and the rules, order, direction and
regulations issued or framed thereunder.

6.

EFFECTIVE DATE of the LICENCE is ------------------------ as the date of
signing of this LICENCE AGREEMENT.

IN WITNESS WHEREOF the parties hereto have caused this Agreement to be executed
through their respective authorized representatives on the ..……………….

Signed for and on behalf of the President of India

Signed on behalf of M/s ------

by ADG (LR-----), Department of Telecom(DOT),
Government of India

by Mr. -----------------Authorized Signatory as
holder of General Power of
Attorney dated --------------,
executed in accordance with
the Resolution dated ---------passed by the Board of
Directors.

IN PRESENCE OF :
1.
Signature

2.
Signature

Name

Name

Occupation

Occupation

Address

Address

Place

Place

-3-

<!-- page 4 -->

TABLE OF CONTENTS

PAGE NOS.
SCHEDULE – TERMS AND CONDITIONS
1.

OWNERSHIP OF THE LICENSEE COMPANY

2.

SCOPE OF LICENSE

3.

DURATION OF LICESNE

4.

EXTENSION OF LICENSE

5.

FEE PAYABLE

6.

SCHEDULE OF PAYMENT OF ANNUAL
LICENSE FEE AND OTHER DUES

7.

BANK GUARANTEES

8.

PREPARATION OF ACCOUNTS

9.

DELIVERY OF SERVICE

10.

INFORMATION TO THE LICENSOR AND TRAI

11.

TRANSFER OF LICENSE

12.

MODIFICATION IN THE TERMS AND
CONDITIONS OF LICENSE

13.

SUSPENSION, REVOCATION OR
TERMINATION OF LICESNE

14.

ACTION PURSUANT TO TERMINATION OF LICESNE

15.

OBLIGATION IMPOSED ON THE LICENSE

16.

NETWORK STANDARDS

17.

NETWORK INTRERCONNECTION

18.

TARIFFS

19.

CUSTOMER SERVICE

20.

COMPLAINT - BOOKING AND TREATMENT

-4-

<!-- page 5 -->

21

CONFIDENTIALITY OF INFORMATION

22.

QUALITY OF SERVICE

23.

SECURITY CONDITIONS

24.

PROHIBITION OF CERTAIN ACTIVIIES BY THE LICENSEE

25.

ACCEPTANCE TESTING

26.

RIGHT TO INSPECT

27.

OPERATING CONDITIONS

28.

OPERATION AND MAINTENANCE OF HUB STATION

29.

REQUIREMENT TO FURNISH INFORMATION

30.

ENGINEERING DETAILS

31.

DISPUTE SETTLEMENT

32.

FORCE – MAJURE

33.

SET OFF CLAUSE

34.

LEASING OF THE SPACE SEGMENT

35.

FREQUENCY OF AUTHORIZATION

DEFINTIONS AND INTERPRETATIONS
ANNEXURE-I : FORMAT FOR STATEMENT OF REVENUE
AND LICENSE FEE
ANNEXURE-II: FORMAT OF AUDITOR’S REPORT
ANNEXURE-III: NORMS FOR PREPARATION OF ANNUAL
FINANCIAL STATEMENT
ANNEXURE-IV: PROFORMA FOR PERFORMANCE BANK GUARANTEE FOR
FULFILLING ROLLOUT OBLIGATIONS
ANNEXURE-V: PROFORMA FOR FINACIAL BANK GUARANTEE
ANNEXURE-VI: PROFORMA FOR PERFORMANCE BANK GUARANTEE
ANNEXURE-VII: TRIPARTITE AGREEMENT

-5-

<!-- page 6 -->

SCHEDULE
TERMS AND CONDITIONS

OWNERSHIP OF THE LICENSEE COMPANY
1.1 A. Foreign Direct Investment (FDI): The Licensee must be an Indian company,
registered under the Indian Companies Act’1956. The Licensee shall ensure that the
total foreign equity in the LICENSEE Company does not, at any time during the
entire LICENSE PERIOD, exceed 74% of the total paid up equity subject to the
following FDI norms:
(i) Both direct and indirect foreign investment in the licensee company shall be
counted for the purpose of FDI ceiling. Foreign Investment shall include
investment by Foreign Institutional Investors (FIIs), Non-resident Indians
(NRIs), Foreign Currency Convertible Bonds (FCCBs), American Depository
Receipts (ADRs), Global Depository Receipts (GDRs) and convertible
preference shares held by foreign entity. Indirect foreign investment shall mean
foreign investment in the company/ companies holding shares of the licensee
company and their holding company/companies or legal entity (such as mutual
funds, trusts) on proportionate basis. Shares of the licensee company held by
Indian public sector banks and Indian public sector financial institutions will be
treated as `Indian holding’. In any case, the `Indian’ shareholding will not be less
than 26 percent.
(ii) FDI up to 49 percent will continue to be on the automatic route. FDI in the
licensee company/Indian promoters/investment companies including their
holding companies, shall require approval of the Foreign Investment Promotion
Board (FIPB) if it has a bearing on the overall ceiling of 74 percent. While
approving the investment proposals, FIPB shall take note that investment is not
coming from countries of concern and/or unfriendly entities.
(iii) The investment approval by FIPB shall envisage the conditionality that Company
would adhere to licence Agreement.
(iv) FDI shall be subject to laws of India and not the laws of the foreign
country/countries.
1.1 B. (i) The details of the equity holdings in the LICENSEE Company as disclosed by the
LICENSEE company, are as follows:
Sl. No.

Name of Promoter/Partner

Indian/
Foreign

Equity
%

Net
Worth

1.
2.
3.
(ii) Details of equity holding of the Promoter/Partner Indian Companies of the
LICENSEE Company, as disclosed by the LICENSEE company, are as follows:

-6-

<!-- page 7 -->

Sl. No.

Name of Promoter/Partner

Indian/
Foreign

Equity
%

Net
Worth

1.
2.
3.
(iii) The LICENSEE shall declare the Indian & Foreign equity holding ( both direct &
indirect) in the LICENSEE company and submit unconditional compliance to the
FDI norms and security conditions on 1st day of January and 1st day of July on
six monthly basis to the LICENSOR. The compliance report should be certified
by the Company Secretary or the Statutory Auditor of the LICENSEE Company.
1.2 There shall be no change in the Indian and Foreign promoter(s) or their equity
participation unless permitted by the LICENSOR. The licensee company may, with prior
written consent of the LICENSOR replace a promoter(s) by another promoter(s) of equal or
higher standing as stipulated below:
an existing foreign promoter may be substituted by another foreign promoter of similar
standing.
The existing Indian Promoter(s) may also be allowed to acquire the foreign promoter’s
shareholding; and
Transfer of equity inter-se between existing Indian promoters may be permitted, provided the
majority Indian promoter continues to hold at least the present shareholding for a
period of five years from the effective date of LICENCE AGREEMENT. The merger
of Indian companies may be permitted as long as competition is not compromised.

1.3

The LICENSEE shall also ensure that:

Any change in share holding shall be subject to all necessary statutory requirements.
Management control of the LICENSEE Company shall at all times remain in Indian hands.
1.4

Change in the name of the LICENSEE Company shall be permitted in accordance
with the provisions under the Indian Companies Act, 1956.

2.

Scope of the Licence

The LICENCE is granted to provide SERVICE as defined in Para 2.2 of this LICENCE
AGREEMENT, on a non-exclusive basis.
Provided further that the LICENSOR, of its own or through a DESIGNATED
AUTHORITY, shall always have a right to operate the SERVICE anywhere in India.
2.2 (i) The Closed User Group Domestic Data Network via INSAT Satellite System
using VSAT shall be restricted to geographical boundaries of India.
(ii) The intent of this LICENCE is not to grant long distance carrier rights.
(iii) The scope of service is to provide data connectivity between various sites scattered
within territorial boundary of India using VSATs. These sites should form part of Closed

-7-

<!-- page 8 -->

User Group (CUG). However, the Commercial VSAT licensee after obtaining ISP license
may use same Hub station and VSAT (remote station) to provide Internet service directly to
the subscribers, and in this case VSAT (remote station) may be used as a distribution point to
provide Internet service to multiple independent subscribers.
(iv)PSTN connectivity is not permitted. The VSAT service LICENSEEs can set up a number
of CUGs using the shared hub infrastructure.
(v) Data Rate, as specified in TEC Interface Requirements No. IR/SCB-08/01 MAY 2007,
is allowed, subject to the compliance of the Technical parameters as specified in TEC
Interface Requirements No. IR/SCB-08/01 MAY 2007, as modified from time to time.
2.3

Definition of Closed User Group for CUG domestic VSAT network:-

A Closed User Group is Permissible for following categories of business associationship:i)

Producer of goods and his trader/agent;

ii)

Provider of service and his trader/agent;

iii)

Producer of same category of goods (e.g. manufactures of petroleum
products); and

iv)

Provider of the same category of service (e.g. bank).

Provided that ultimate consumer of a service or a product shall not be a part of the Closed
User Group; and provided further that the closed user group is meant for legitimate business
communication purposes of the group.
A Closed User Group can also be formed among a holding company and its subsidiaries or
among interconnected undertakings, these terms being defined as per MRTP Act, 1969
provided that such Closed User Group shall be only for the purposes of legitimate business
communications of the group.
2.4

Licensee shall make its own arrangements for all infrastructure involved in providing
the service and shall be solely responsible for installation, networking and operation
of necessary equipment and systems, treatment of subscriber complaints, issue of bills
to its subscribers, collection of revenue, attending to claims and damages arising out
of his operations.

2.5

The LICENSEE shall clearly define the scope of Service to the subscriber(s) at the
time of entering into contract with such subscriber(s). Any dispute with regard to the
service provided to the subscriber shall be a matter between the subscriber and the
licensee only.

3.
DURATION OF LICENCE
This LICENCE comes into force on --------------------- (hereinafter called the EFFECTIVE
DATE of the LICENCE and is on non-exclusive basis, and shall be valid for a period of
20 years unless revoked earlier for reasons as stated in the LICENCE AGREEMENT.
4.

EXTENSION OF LICENCE

-8-

<!-- page 9 -->

The LICENSOR may extend, if deemed expedient, the period of LICENCE on terms
mutually agreed by 10 years at one time, upon request of the LICENSEE, if made during
19th YEAR of the LICENCE period. The decision of the LICENSOR shall be final in
regard to the grant of extension.
5.

FEES PAYABLE :

LICENSEE shall pay one time Entry Fee of Rs.30 lakhs (Rupees Thirty lakhs only) which
shall be non-refundable and shall be payable before signing of LICENCE.
LICENCE FEE :- In addition to the Entry Fee described above, Annual LICENCE
FEE in the form of revenue share @ 6 % (Six per cent) of ADJUSTED GROSS
REVENUE (AGR) inclusive of Universal Service Obligation (USO) shall be payable.
The AGR is defined in definitions.
Radio Spectrum Charges :The LICENSEE shall also pay fees and royalty for the use of radio frequency as per details
prescribed by Wireless Planing & Coordination (WPC).
The LICENSEE shall also pay the space segment charges as applicable from time to time and
secure them through a Financial Bank Guarantee.

6. SCHEDULE OF PAYMENT OF ANNUAL LICENCE FEE AND OTHER DUES
6.1

For the purposes of the LICENCE Fee at 5.2 and 5.3 above, the Ist year shall end on
31st March following the date of commencement of the LICENCE Agreement and the
LICENCE Fee for the First year shall be determined on a pro-rata basis for the actual
duration of the “year”. From second year onwards, the year shall be of Twelve
English calendar months from 1st of April to 31st of March for payment of LICENCE
Fee.
EXPLANATION: The License Fee for the last quarter of the first year and of the last
year of the License will, be computed with reference to the actual number of days
after excluding the earlier quarters, each being of three months.

6.2

LICENCE Fee shall be payable in four quarterly installments during each financial
year (FY). Quarterly installments of licence fees for the first three quarters of a FY
shall be paid within 15 days of the completion of relevant quarter. This fee shall be
paid by the licensee on the basis of actual revenues (on accrual basis) for the quarter
duly certified with an affidavit by a representative of the licensee, authorized by a
board resolution coupled with general Power of Attorney. However, for the last
quarter of FY, the licensee shall pay licence fee by 25th March on the basis of expected
revenues for the quarter, subject to a minimum payment equal to actual revenue share
paid for the previous quarter. The licensee shall adjust and pay the difference between
the payment made and actual amount duly payable (on accrual basis) for the last
quarter of FY within 15 days of the end of the quarter.

-9-

<!-- page 10 -->

6.3

The quarterly payment shall be made together with a STATEMENT in the prescribed
format given in Annexure-I, showing the computation of Adjusted Gross Revenue
(AGR) and LICENCE Fee payable for the previous quarter. The aforesaid
STATEMENTS of each year shall be required to be audited by the Auditors
(hereinafter called LICENSEE’s Auditors) of the LICENSEE appointed under Section
224 of the Companies’ Act, 1956. The report of the Auditor should be in prescribed
format given in Annexure-II.

6.4

The LICENSEE shall adjust and pay the difference between the advance payment
made and actual amount payable (on accrual basis) of the previous quarter, alongwith
the advance payment for the current quarter.

6.5

Any delay in payment of LICENCE Fee, or any other dues payable under the
LICENCE beyond the stipulated period will attract interest at a rate which will be 2%
above the Prime Lending Rate (PLR) of State Bank of India existing on 1st April of
that financial year. The interest shall be compounded monthly and a part of the
month shall be reckoned as a full month for the purposes of calculation of interest.

6.6

Final adjustment of the LICENCE Fee for the year shall be made on or before 30th
June of the following year based on the Gross Revenue Figures duly certified by the
Auditors of the LICENSEE in accordance with the provision of Companies’ Act,
1956.

6.7

A reconciliation between the figures appearing in the quarterly statements with those
appearing in annual accounts shall be submitted along with a copy of the published
annual accounts and audit report, within 7 (seven) days of the date of signing of the
audit report. The annual financial account and the statement as prescribed in condition
No. 6.3 shall be prepared following the norms as prescribed in Annexure-III.

6.8

In case, the total amount paid on the self assessment of the LICENSEE as quarterly
LICENCE Fee for the 4 (four) quarters of the financial year, falls short by more than
10% of the payable LICENCE Fee, it shall attract a penalty of 50% of the entire
amount of short payment. This amount of short payment along with the penalty shall
be payable within 15 days of the date of signing the audit report on the annual
accounts, failing which interest shall be further charged as per terms of Condition 6.5.
However, if such short payment is made good within 60 days from the last day of the
financial year, no penalty shall be imposed.

6.9

The LICENCE Fee/royalty towards WPC charges shall be payable at such time(s) and
in such manner as the WPC Wing of the Department of Telecommunications, Ministry
of Communication may prescribe from time to time.

6.10

All sums becoming due and payable as mentioned in this LICENCE Agreement shall
be paid by the LICENSEE through a demand draft or Pay Order payable at New Delhi,
drawn on any Scheduled Bank, in favour of the ‘Pay & Accounts Officer (HQ), DOT’
or any other Authority if so designated by LICENSOR.

6.11 The LICENSOR, to ensure proper and correct verification of revenue share paid, can,
if deemed necessary, modify, alter, substitute and amend whatever stated in
Conditions No. 6.3, 6.7, 8.5 and 8.6 hereinbefore and hereinafter written.

- 10 -

<!-- page 11 -->

7.

BANK GUARANTEES

(a)

Performance Bank Guarantee:

(i)

LICENSEE shall maintain throughout the period of the LICENCE a Performance
Bank Guarantee (PBG) in the prescribed format for Rs. 50 lakhs initially valid for one
year. The format of PBG is at Annexure-VI. The PBG will be encashed for violation
of any of the terms and conditions of the licence agreement. The PBG shall be
submitted before the licence agreement is signed and shall be in addition to the BG
submitted towards roll out obligation.

(ii)

The LICENSEE shall also submit alongwith entry fee a Performance Bank Guarantee
(PBG) in the prescribed format for Rs. 10 lakhs valid for eighteen months towards
meeting the roll out obligation. The format of this PBG is placed at Annexure-IV.

(iii)

In the event of non commissioning of service within the first year, another Bank
Guarantee for an amount of Rs. 10 Lakhs valid for 18 months shall be submitted.
Wherever the service is not commenced till the expiry of first year from the effective
date of LICENCE, the first Bank Guarantee of Rs. 10 Lakhs submitted alongwith
Entry Fee shall be encashed and forfeited by the LICENSOR. The second Bank
Guarantee shall be encashed and forfeited on expiry of two years from the effective
date of LICENCE for non commencement of service and the LICENCE shall be liable
for termination. The Bank Guarantee will be returned on satisfactory completion of
Roll Out Obligation.

(b)

Financial Bank Guarantee:

7.1

At the time of signing the Licence Agreement, the financial bank guarantee (FBG) for
Rs. 30 lakhs (equivalent to entry fee), valid for six months is to be submitted.
Thereafter, The VSAT LICENSEE shall submit a Financial Bank Guarantee (FBG),
valid for one year, from any Scheduled Bank in India or from any Indian Public
Financial Institution (IPFI) duly authorized to issue such Bank Guarantee, in the
prescribed format at Annexure-V. The amount of FBG shall be equivalent to an
estimated sum payable for two quarters towards LICENCE Fee and other dues not
otherwise securitised. The amount of FBG shall be subject to periodic review by the
LICENSOR.

7.2

The LICENSEE, on its own, shall extend the validity period of the Bank Guarantee(s)
for similar terms at least one month prior to date(s) of its expiry without any demand
or notice from the LICENSOR on year to year basis. Any failure to do so, shall
amount to violation of the terms of the LICENCE and entitle the LICENSOR to
encash the Bank Guarantee(s) and to convert it into a cash security, without any
reference to the LICENSEE at his risk and cost. No interest or compensation,
whatsoever, shall be payable by the LICENSOR on such encashment.

7.3

The Fees, charges and royalties for the use of spectrum and also for possession of
Wireless Telegraphy equipment shall be separately securitised by furnishing BG of an
amount equivalent to the estimated sum payable annually in the Performa prescribed

- 11 -

<!-- page 12 -->

by WPC, to WPC, valid for a period of one year, renewable from time to time till final
clearance of all such dues.
7.4

Without prejudice to its rights of any other remedy, the LICENSOR may encash the
Bank Guarantee(s) in case of any breach, in the terms and conditions of the LICENCE
by the LICENSEE.

8.

PREPARATION OF ACCOUNTS

8.1

The LICENSEE will draw, keep and furnish independent accounts for the SERVICE
and shall fully comply with the orders, directions or regulations as may be issued from
time to time by the LICENSOR or TRAI as the case may be.

8.2

The LICENSEE shall be obliged to:
a) Compile and maintain accounting records, sufficient to show and explain its
transactions in respect of each completed quarter of the LICENCE period or of such
lesser periods as the LICENSOR may specify, fairly presenting the costs (including
capital costs), revenue and financial position of the LICENSEE’s business under the
LICENCE including a reasonable assessment of the assets employed in and the
liabilities attributable to the LICENSEE’s business, as well as, for the quantification
of Revenue or any other purpose.
b) Procure in respect of each of those accounting statements prepared in respect of a
completed financial year, a report by the LICENSEE’s Auditor in the format
prescribed by the LICENSOR, stating inter-alia, whether in his opinion that statement
is adequate for the purpose of this condition and thereafter deliver to the LICENSOR
a copy of each of the accounting statements not later than three months after the end
of the period to which they relate.
c) Send to the LICENSOR a certified statement sworn on an affidavit, by authorized
representative of the company, containing full account of Revenue earned from the
SERVICE for each quarter separately alongwith the payment for the following
quarter.

8.3

8.4

(a)

The LICENSOR or the TRAI, as the case may be, shall have a right to call for
and the LICENSEE shall be obliged to supply and provide for examination
any books of accounts that the LICENSEE may maintain in respect of the
business carried on to provide the service(s) under this LICENCE at any time.

(b)

The LICENSEE shall invariably preserve all billing and all other accounting
records (electronic as well as hard copy) for a period of one year from the date
of publishing of duly audited & approved Accounts of the company and any
dereliction thereof shall be treated as a material breach independent of any
other breach, sufficient to give a cause for cancellation of the LICENCE.

The records of the LICENSEE will be subject to such scrutiny as may be prescribed by
the LICENSOR so as to facilitate independent verification of the amount due to the
LICENSOR as its share of the revenue.

- 12 -

<!-- page 13 -->

8.5

The LICENSOR may, on forming an opinion that the statements or accounts submitted
are inaccurate or misleading, order an Audit of the accounts of the LICENSEE by
appointing Auditor at the cost of the LICENSEE and such Auditor(s) shall have the
same powers which the statutory Auditors of the company enjoy under Section 227 of
the Companies Act, 1956. The remuneration of the Auditors, as fixed by the
LICENSOR, shall be borne by the LICENSEE.

8.6

The LICENSOR may also get conducted a ‘Special Audit’ of the LICENSEE
company’s accounts/records by “Special Auditors”, the payment for which at rates as
fixed by the LICENSOR, shall be borne by the LICENSEE company. The Special
Auditors shall also be provided the same facility and have the same powers as that of
the companies’ Auditors as envisaged in the Companies Act, 1956.

8.7

The LICENSEE shall be liable to prepare and furnish the company’s annual financial
accounts according to the norms prescribed and the directions given by the
LICENSOR or the TRAI, as the case may be, from time to time.

9.

DELIVERY OF SERVICE

LICENSEE shall be solely responsible for installation, networking and operation of necessary
equipment and systems for provision of SERVICE, treatment of SUBSCRIBER
complaints, issue of bills to its subscribers, collection of its component of revenue,
attending to claims and damages arising out of his operations.
A minimum of 5 VSATs alongwith HUB must be commissioned within a period of one year
from the effective date of LICENCE.

10.

INFORMATION TO THE LICENSOR AND TRAI

The LICENSEE shall be obliged to furnish any information to the LICENSOR as called upon
from time to time. The LICENSEE shall also submit information to TRAI as per any
order, direction and regulation issued from time to time under the provisions of TRAI
Act, 1997 or any amended or modified statue.
The LICENSEE shall, in no case, permit connectivity or similar type of service to any other
Telecom. SERVICE PROVIDER (including those OTHER SERVICE PROVIDERS
who do not require LICENCE under Section 4 of the ITA, 1885) whose LICENCE/
permission is either terminated or suspended or not in operation at a given point of
time. Where connectivity already exists, the LICENSEE shall be obliged to
disconnect or serve connectivity immediately without loss of time. Upon receipt of
any reference from the LICENSOR in this regard, disconnection shall be made
effective within one hour of receipt of such reference. On the question of disconnectivity the decision of the LICENSOR shall be final and binding.
Wherever considered appropriate LICENSOR may conduct an inquiry either suo-moto or on
a complaints to determine whether there has been any breach in compliance of the
terms and conditions of the LICENCE by the LICENSEE, and for facilitating such
inquiry the LICENSEE shall extend all reasonable facilities without any hindrance.

- 13 -

<!-- page 14 -->

11.

TRANSFER OF LICENCE
The Licensee may transfer or assign the License Agreement with prior written
approval of the Licensor to be granted on fulfillment of the following conditions:

When transfer or assignment is requested in accordance with the terms and conditions on
fulfillment of procedures of Tripartite Agreement if already executed amongst the
Licensor, Licensee and Lenders;
OR
Whenever amalgamation or restructuring i.e., merger or demerger is sanctioned and
approved by the High Court or Tribunal as per the Law in force; in accordance with
the provisions; more particularly of sections 391 to 394 of Companies Act, 1956;
AND
(ii) The transferee or assignee is fully eligible in accordance with eligibility criteria
contained in tender condition or in any other document for grant of fresh license in
that area and shows its willingness in writing to comply with the terms and conditions
of the license agreement including past and future roll out obligations;
AND
(iii) All the past due fully paid till the date of transfer/assignment by the transferor
company and thereafter the transferee company undertakes to pay all future dues
inclusive of any thing remained unpaid of the past period by the outgoing company.
12.

MODIFICATIONS IN THE TERMS AND CONDITIONS OF LICENCE

The LICENSOR reserves the right to modify at any time the terms and conditions of the
LICENCE, if in the opinion of the LICENSOR it is necessary or expedient to do so in
public interest or in the interest of the security of the State or for the proper conduct of
telegraphs. The decision of the LICENSOR shall be final and binding.
13.

SUSPENSION, REVOCATION OR TERMINATION OF LICENCE

The LICENSOR reserves the right to suspend the operation of this LICENCE in whole or in
part, at any time, if, in the opinion of the LICENSOR, it is necessary or expedient to
do so in public interest or in the interest of the security of the State or for the proper
conduct of Telegraphs. Revenue share as Licence Fee, payable to the LICENSOR
will not be required to be paid for the period for which the operation of this LICENCE
remains suspended in the entire Service Area but claim of refund of any charge or fee
shall not be maintainable.
Provided that the LICENSOR shall not be responsible for any damage or loss caused
or arising out of aforesaid action. Provided further that the suspension of the
LICENCE will not be a cause or ground for extension of the period of the LICENCE
and suspension period will be taken as period already spent.
13.2

Without prejudice any other remedy available for the breach of any conditions of
LICENSE, the LICENSOR may, by a written notice of 60 calendar days issued to
LICENSEE at its registered office, terminate this LICENCE in whole or parts, under
any of the following circumstances:
if the LICENSEE

- 14 -

<!-- page 15 -->

a)
b)

c)
d)
e)

13.3

fails to commission or deliver any or all of the services within
the time period(s) specified in the LICENCE.
fails to perform any obligation(s) under the LICENCE
including timely payments of LICENCE fee and other
charges due to LICENSOR.
fails to rectify the failure within the notice period, as may be
pointed out to the LICENSEE by the LICENSOR.
Becomes bankrupt/goes in liquidation or is declared insolvent
or is ordered to be wound up.
is recommended by TRAI for termination of LICENCE for
non compliance by the LICENSEE, of the terms and
conditions of the LICENCE.

LICENSEE may surrender the LICENCE, by giving an advance notice, of at least 60
calendar days to the LICENSOR to this effect. The LICENSEE shall also notify all
its subscribers of consequential withdrawal of SERVICE by sending a 30 calendar
days’ notice to them. The LICENSEE shall pay all dues payable by it till the date on
which the surrender of the LICENCE becomes effective. The effective date of
surrender of LICENCE will be 60 calendar days counted from the date of receipt of
such notice by the LICENSOR.
During the period when a notice for termination or surrender of LICENCE is pending,
the QUALITY OF SERVICE to the subscribers as per prescribed standards, shall
have to be maintained by the LICENSEE, failing which, it shall be treated as material
breach without prejudice to any other remedy available to the LICENSOR.

The LICENSOR reserves the right to revoke the LICENCE at any time in the interest of
public by giving a notice of 60 calendar days counted from the date of issue of such
notice.
The LICENSOR reserves the right to take over the entire services, equipments and
networks of the LICENSEE or revoke/terminate/suspend the LICENCE in public
interest or national security or in the event of national emergency/war or low intensity
conflict or similar type of situations. Further the LICENSOR reserves the right to
keep any area out of the operation zone of the service in implications of security so
requires. The decision of the LICENSOR shall be final.

ACTIONS PURSUANT TO TERMINATION OF LICENSE :
14.1

If under the Licence Agreement, an event occurs which entitles the LICENSOR to
terminate the Licence Agreement, the LICENSOR shall proceed in accordance with
the terms and conditions provided in the Tripartite Agreement wherever such
agreement is executed and signed. In cases where no Tripartite Agreement is signed,
the action will be taken as per the clauses given below:-

14.2

On termination or surrender or expiry of the LICENCE, the Bank Guarantee shall be
released to the LICENSEE only after ensuring clearance of all dues and fulfillment of
roll out obligation, otherwise the Bank Guarantee shall be encashed without prejudice
to any other action(s) for recovery of amounts due to LICENSOR.

- 15 -

<!-- page 16 -->

15.

OBLIGATIONS IMPOSED ON THE LICENSEE

The provisions of the Indian Telegraph Act 1885, the Indian Wireless Telegraphy Act 1933,
and the Telecom. Regulatory Authority of India Act, 1997 as modified from time to
time or any other statue on the replacement of either or all shall govern this
LICENCE.
The LICENSEE shall furnish all necessary means and facilities as required for the application
of provisions of Section 5 (2) of the Indian Telegraph Act, 1885, whenever occasion
so demands. Nothing provided and contained anywhere in this LICENCE
AGREEMENT shall be deemed to affect adversely anything provided or laid under
the provisions of Indian Telegraphs Act, 1885 or any other law on the subject in force.
16.

NETWORK STANDRADS

16.1

Data Rate (Transmission speed) :-Data rate, as specified in TEC Interface
Requirements No. IR/SCB-08/01 MAY 2007, is allowed. Provided that any other
notification or modification thereof issued by the Licensor from time to time shall be
binding on the Licensee.
Technical Parameters :-The technical parameters mentioned in Interface
Requirements for CUG domestic VSAT networks namely No. IR/SCB-08/01 MAY
2007 issued by T.E.C. are to be strictly compiled with. Any other notification or
modification thereof issued from time to time in this regard shall be binding.

16.2

16.3

Requisite monitoring facilities/ equipment for each type of system used, shall be
provided by the LICENSEE at own cost for monitoring as and when required by the
LICENSOR.

17.

NETWORK INTERCONNECTION
i)

Interconnection with PSTN Not permitted

ii)

Network of other VSATs – Interconnection shall be permitted through the Hub
on case to case basis, wherever the CUG nature of the network is not violated.

iii)

Terrestrial data lines leased by customers of VSATs – Interconnection shall be
permitted on case to case basis, wherever the CUG nature of the network is not
violated.

iv)

Terrestrial data lines of a public nature:- Interconnection shall be permitted
through the Hub provided it is connected to a public data network such as Internet/
INET.

v)

Overseas office of the CUG for data transfer purposes:- Interconnection shall
be permitted on a case to case basis subject to the condition that the connection
should be between the hub and the server of the overseas office through a leased
line passing through an international gateway which can be monitored for security
purposes.

- 16 -

<!-- page 17 -->

vi)

WAN Operators:- Interconnection shall be permitted on case to case basis,
wherever the CUG nature of the network is not violated.

vii)

Internet/INET:- The hub of VSAT LICENSEE shall be allowed to be connected
to an internet node of his choice through a lease line taken from Telecom service
provider who is authorized to sell bandwidth/ leased line. Similar inter-connection
of the Hub with INET is also permitted.

viii)

Other media to provide for redundancy:- Switchover between a terrestrial CUG
network and a VSAT based CUG network belonging to the same customer shall
be permitted for redundancy purpose.

17.1

Interconnection of CUGs :- Inter-connection between CUGs, where the CUG nature
of the network is not violated, will be permitted on a case to case basis.

17.2

Standardization of User Network and Network Interfaces :- The user-network
and network interfaces should conform to standard interfaces such as X25, X75,
TCP/IP or such international standards that may be specified from time to time by
Telecom authority.

17.3 The LICENSEE shall comply with any order, direction, determination or regulation
issued by TRAI under TRAI Act, 1997 as amended from time to time.

18.

TARIFFS

The LICENSEE will charge the tariff for the service as per the TRAI tariff orders/ regulations
/directions issued in this regard from time to time. The LICENSEE shall also fulfil
requirements regarding publication of tariff notification and provision of information
as directed by TRAI through its orders/ regulations/directions issued from time to
time as per provision of TRAI act 1997 as amended from time to time.
19.

CUSTOMER SERVICE

The LICENSEE shall register demand/ request for service without any discrimination from
any applicant, at any place in the service area and provide the SERVICE, unless
otherwise directed by the LICENSOR. The LICENSEE shall not in any manner
discriminate between subscribers and provide service on the same commercial
principle and shall be required to maintain a transparent, open to inspection.
LICENSOR shall have right to impose suitable penalty, not limited to a financial
penalty, apart from any other actions for breach of this condition. The LICENSEE
shall launch the SERVICE on commercial basis only after commencement of
registration in the manner prescribed. Before commencement of service in an area, the
LICENSEE shall notify and publicize the address where any subscriber can register
demand / request for service. Any change of this address shall be duly notified by the
LICENSEE.
The LICENSEE shall ensure continuity of services to its customers.

- 17 -

<!-- page 18 -->

The LICENSEE’s contractual obligations towards the CUSTOMER will include terms and
conditions under which the SERVICE shall be provided or terminated. The
LICENSEE shall notify to CUSTOMERs all the arrangements or everything with
respect to billing, repair, fault rectification, compensation or refunds etc.. All
complaints in this regard will be addressed/ handled as per the guidelines, orders or
regulations or directives issued by the LICENSOR.
The LICENSEE shall enter into a standard agreement with each of the VSAT subscriber.
The following condition shall be included in the agreement:
“The VSAT subscriber has read the LICENCE agreement between the LICENSEE
and the Authority completely and shall not violate any of the conditions/ restrictions
on his part in the process of using the service.” For this purpose LICENSEE shall
make a copy of this LICENCE agreement available to each of the subscriber.
19.5

The LICENSEE shall equip himself with the means to measure the originating
and
terminating traffic in respect of each subscriber. He should be able to generate the
billing information, in enough detail, to convince the subscribers satisfactorily.

20.

COMPLAINT – BOOKING AND TREATMENT :

The LICENSEE shall equip himself with adequate mechanisms to settle complaints from his
subscribers, to rectify the faults in his own equipment or those occurring in
subscriber’s equipment for which there is a maintenance contract between
LICENSEE and the subscriber(s) and take such corrective measures to bring the
faulty elements back into satisfactory operation. The MTTR agreed to shall be
respected. The LICENSEE shall also publish the information relating to the
complaints and remedial procedures relating to the Service.
All complaints of CUSTOMERs in this regard will be addressed/ handled as per the
guidelines, orders or regulations or directives issued by the LICENSOR or TRAI from
time to time.
Any dispute, with regard to the provision of SERVICE shall be a matter only between the
aggrieved party and the LICENSEE, who shall duly notify this to all before providing
the SERVICE. And in no case the LICENSOR shall have any liability or
responsibility in the matter towards the aggrieved party and shall be kept indemnified
from all costs, charges, claims or damages.

21.

CONFIDENTIALITY OF INFORMATION

Any encryption equipment connected to the LICENSEE’s network for specific requirements
has to have prior evaluation and approval of the LICENSOR or officer specially
designated for the purpose. However, the LICESEE shall have the responsibility to
ensure protection of privacy of communication and to ensure that unauthorized
interception of MESSAGE does not take place.

- 18 -

<!-- page 19 -->

Subject to conditions contained in these terms and conditions, the LICENSEE shall take all
necessary steps to safeguard the privacy and confidentiality of any information about
a third party and its business to whom it provides the SERVICE and from whom it has
acquired such information by virtue of the SERVICE and shall use its best endeavours
to secure that :
No person acting on behalf of the LICENSEE or any member of the LICENSEE’s group
(associates) divulges or uses any such information except as may be necessary in the
course of providing such SERVICE to the Third Party; and
No such person seeks such information other than is necessary for the purpose of providing
SERVICE to the Third Party.
Provided the above para shall not apply where :
The information relates to a specific party and that party has consented in writing to such
information being divulged or used, and such information is divulged or used in
accordance with the terms of that consent; or
The information is already open to the public and otherwise known.
The LICENSEE shall take necessary steps to ensure that the LICENSEE and any person (s)
acting on its behalf and members of the LICENSEE’s group (associates) and any
persons acting on their behalf observe confidentiality of customers information.
The LICENSEE shall, prior to commencement of SERVICE, confirm in writing to the
LICENSOR that the LICENSEE has taken all necessary steps to ensure that it and its
employees are observing confidentiality of customer information.

22.

QUALITY OF SERVICE

The LICENSEE shall ensure the Quality of Service (QoS) as prescribed by the LICENSOR
or TRAI. The LICENSEE shall adhere to such QoS standards and provide timely
information as required therein.
The LICENSEE shall be responsible for :Maintaining the performance and quality of service standards.
Maintaining the MTTR (Mean Time To Restore) within the specified
limits
the quality of service as given below in respect of normal failures excluding
catastrophes :

of

90% of faults resulting due to subscriber’s complaints should be rectified within 24 hours and
99% within 3 Calendar days.
The Licensee will keep a record of number of faults and rectification reports in respect of the
service, which will be produced before the LICENSOR/ TRAI as and when and in
whatever form desired.

- 19 -

<!-- page 20 -->

The Licensee shall be responsive to the complaints lodged by his subscribers. He shall rectify
the anomalies within the MTTR specified and maintain the history sheets for each
installation, statistics and analysis on the overall maintenance statue.
The LICENSOR or TRAI may carry out performance tests and also evaluate the QoS
parameters in LICENSEE’s network at any time during the tenure of the LICENCE
period. The LICENSEE shall provide ingress and other support including
instruments, equipment etc. for carrying out such performance tests and evaluation of
QUALITY OF SERVICE parameters.
23.

SECURITY CONDITIONS

LICENSEE shall not normally employ bulk encryption equipment in its network. However, if
any encryption equipment is used and connected to the LICENSEE’s network, then it
should have prior evaluation and written approval of the LICENSOR.
In areas which are sensitive from security point of view, as may be notified from time to time
by the LICENSOR, implementation of any installation of the equipment and
execution of project shall be taken up only after the LICENSOR’s approval.
The LICENSEE shall provide necessary facilities including any specific facility as may be
required depending upon the specific situation at the relevant time to the Government
of India to counteract espionage, subversive act, sabotage or any other unlawful
activity.
The LICENSEE shall make available on demand to the agencies authorized by the
LICENSOR, full access to the Hub station and VSAT Terminals etc. for technical
scrutiny and for inspection which can be visual inspection or an operational
inspection.
All foreign personnel likely to be deployed by the LICENSEE for installation, operation and
maintenance of the LICENSEE’s network shall be security cleared by the
Government of India prior to their deployment. The security clearance will be
obtained from the Ministry of Home Affairs, Government of India, who will follow
standard procedure in the matter.
The LICENSEE shall ensure protection of privacy of communication and ensure that
unauthorized interception of MESSAGEs do not take place.
LICENSOR shall have the right to take over the SERVICE, alongwith equipment and
network of the LICENSEE or revoke/ terminate/ suspend the LICENCE either in part
or in whole of the SERVICE AREA as per direction if any, issued in the public
interest by the Government of India in case of emergency or interest of national
security or war or low intensity conflict or any other eventuality. Provided any
specific orders or direction from the Government issued under such conditions shall
be applicable to the LICENSEE and shall be strictly complied with. Further, the
LICENSOR reserves the right to keep any area out of the operation zone of the
SERVICE if implications of security so require.

- 20 -

<!-- page 21 -->

LICENSOR reserves the right to modify these conditions or incorporate new conditions
considered necessary in the interest of national security, or public interest or for
proper conduct of telegraphs.
LICENSEE will ensure that the Telecommunication installation carried out by him should not
become a safety hazard and is not in contravention of any statue, rule or regulation
and public policy.
In the interests of security, suitable monitoring equipment as may be prescribed for each type
of system used will be provided by the LICENSEE for monitoring as and when
required by LICENSOR. The specific orders or directions from the Government,
issued under such conditions, shall be applicable.
The precise delineation of geographical borders taken by the LICENSEE for the purpose of
defining SERVICE AREA across International borders, if any, shall be prior approval
of the Government of India. The terrestrial boundaries of India shall be as depicted in
the maps issued by Survey of India.
The LICENSEE shall create a buffer zone of 10 KM width along the Indian International
border, if any, where no service would be permitted. Width of this buffer zone along
the borders with Indian Territory shall be as decided by the Government of India from
time to time. As and when there is any change in the structure of defined, for
whatsoever reason, buffer zone create by the LICENSEE, it should be reported to the
LICENSOR immediately. The Government and its authorized representative may
carry out physical verification of the accuracy of buffer zone so created.
The LICENSEE shall provide a list updated at quarterly intervals, of his subscribers directly
to authorized security agencies and also to the LICENSOR. Additions and deletions
in this list should be reported on monthly basis. The LICENSEE shall ensure
adequate verification of each and every CUSTOMER before enrolling him as a
subscriber, instructions issued by the LICENSOR in this regard form time to time
shall be scrupulously followed.
The designated person of the Central/State Government as conveyed to the LICENSOR from
time to time in addition to the LICENSOR or its nominee shall have the right to
monitor the Hub-Station/VSAT terminals and any other point in the network set up by
the LICENSEE. The LICENSEE should make arrangement for monitoring message
by Government security agencies at the location particularly desired by the Central
Government /the State Government /Union Territory. The Hardware/Software
required for monitoring of message in the VSAT network shall be engineered,
provided /installed and maintained by the LICENSEE as also in the premises of
security agencies at LICENSEE’s cost. However, the respective Government
instrumentality shall bear the cost of leased line circuits from the Hub to the
monitoring centers to be located as per their choice or in the premises of the
LICENSEE. In case the security agencies intend to locate the equipment for
facilitating monitoring, the LICENSEE should extend all support in this regard
including Space and Entry of the authorized security personnel. The Interface
requirements as well as features and facilities as defined by the LICENSOR should be
implemented by the LICENSEE.

- 21 -

<!-- page 22 -->

The LICENSOR or its representative (s) will have an access to the data base relating to the
subscribers of the LICENSEE. The LICENSEE shall also update the list of his
subscribers and make available the same to the LICENSOR at such intervals as may
be prescribed. The LICENSEE shall make available, at any prescribed instant, to the
LICENSOR or its authorized representative, details of the subscribed using the
service.
The LICENSEE shall maintain all commercial records with regard to the communications
exchanged on the network till the LICENSOR clears the same for destruction. Such
records shall be archived for at least one year for scrutiny by the LICENSOR for
security reasons.
23.17 (i) The Chief Officer Incharge of technical network operations and the Chief Security
Officer should be a resident Indian citizen.
(ii) Details of infrastructure/network diagram (technical details of the network) could
be provided on a need basis only to telecom equipment suppliers/manufacturers
and the affiliate/parents of the licensee company. Clearance from the licensor
(Department of Telecommunications, Government of India ) would be required
if such information is to be provided to anybody else.
(iii) For security reasons, domestic traffic of such entities shall not be hauled/routed
to any place outside India.
(iv) The licensee company shall take adequate and timely measures to ensure that the
information transacted through a network by the subscribers is secure and
protected.
(v) The officers/officials of the licensee companies dealing with the lawful
interception of messages will be resident Indian citizens.
(vi) The majority Directors on the Board of the company shall be Indian citizens.
(vii) The positions of the Chairman, Managing Director, Chief Executive Officer
(CEO) and/or Chief Financial Officer (CFO), if held by foreign nationals, would
require to be security vetted by Ministry of Home Affairs (MHA). Security
vetting shall be required periodically on yearly basis. In case something adverse
is found during the security vetting, the direction of MHA shall be binding on the
licensee.
(viii) The Company shall not transfer the following to any person/place outside
India:(a) Any accounting information relating to subscriber (Note: it does not restrict
a statutorily required disclosure of financial nature) ; and
(b) User information .
(ix) The Company must provide traceable identity of their subscribers.

- 22 -

<!-- page 23 -->

(x) On request of the licensor or any other agency authorized by the licensor, the
licensee should be able to provide the geographical location of any subscriber at
a given point of time.
(xi) The Remote Access (RA) to Network would be provided only to approved
location(s) abroad through approved location(s) in India. The approval for
location(s) would be given by the Licensor (DOT) in consultation with the
Security Agencies (IB).
(xii) Under no circumstances, should any RA to the suppliers/manufacturers and
affiliate(s) be enabled to access Lawful Interception System(LIS), Lawful
Interception Monitoring(LIM), Call contents of the traffic and any such sensitive
sector/data, which the licensor may notify from time to time.
(xiii) The licensee company is not allowed to use remote access facility for
monitoring of content.
(xiv) Suitable technical device should be made available at Indian end to the
designated security agency/licensor in which a mirror image of the remote
access information is available on line for monitoring purposes.
(xv) Complete audit trail of the remote access activities pertaining to the network
operated in India should be maintained for a period of six months and provided
on request to the licensor or any other agency authorised by the licensor.
(xvi) The licensee should ensure that necessary provision (hardware/software) is
available in their equipment for doing the Lawful interception and monitoring
from a centralized location.
(xvii) The licensee should familiarize/train Vigilance Technical Monitoring
(VTM)/security agency officers/officials in respect of relevant
operations/features of their systems.
(xviii) It shall be open to the licensor to restrict the Licensee Company from operating
in any sensitive area from the National Security angle.
(xix) In order to maintain the privacy of voice and data, monitoring shall only be upon
authorization by the Union Home Secretary or Home Secretaries of the
States/Union Territories.
(xx) For monitoring traffic, the licensee company shall provide access of their
network and other facilities as well as to books of accounts to the security
agencies.
(xxi) The aforesaid Conditions shall be applicable to all the licensees irrespective of
the level of FDI.
24.

PROHIBITION OF CERTAIN ACTIVITIES BY THE LICENSEE

The LICENSEE shall not hereunder engage, on the strength of this LICENCE, in the
provision of services other than the SERVICE as defined in this LICENCE
AGREEMENT.

- 23 -

<!-- page 24 -->

To remote any doubt, it is, hereby, clarified that nothing contained in condition 24.1 above
shall preclude the LICENSEE from engaging in advertising and promotional activities
relating to any of the applicable systems.
The LICENSEE shall ensure that objectionable, obscene, unauthorized content, messages or
communications infringing copyright, intellectual property etc., in any form, are not
carried on his network, consistent with the established laws of the country. Once
specific instances of such infringement are reported to the LICENSEE by the
authorized agencies, the LICENSEE shall ensure that the carriage of such material on
his network is prevented immediately.
The LICENSEE is obliged to provide, without any delay, all the tracing facilities to trace
messages or communications transported through his equipment and network, to
authorized officers of Government of India including Police, Customs, Excise,
Intelligence Department officers etc. when such information is required for
investigations or detection of crimes and in the interest of national security. Any
damages arising on account of LICENSEE’s failure in this regard shall be payable by
the LICENSEE.
In case any confidential information is divulged to the LICENSEE for proper implementation
of the AGREEMENT, it shall be binding on the LICENSEE, its employees, agents
and servants to maintain its secrecy and confidentiality.
25. ACCEPTANCE TESTING :
Mandatory performance verification of HUB Station will be carried out by NOCC or any
other agency authorized by the Authority for this purpose on payment of necessary
testing charges by LICENSEE.
For VSATs supplied or leased by the LICENSEE, a certificate from the LICENSEE duly
supported by the manufacturer certificate meeting the mandatory performance
requirements shall be submitted by the LICENSEE to NOCC. Mandatory
performance verification of VSATs will be carried out by NOCC on selective basis on
payment of necessary testing charges by LICENSEE.
26.

RIGHT TO INSPECT :
The LICENSOR, or his authorized representative shall have the right to inspect the
sites used for extending the SERVICE. The LICENSOR or its authorized
representative shall, in particular but not limited to, have the right to have access to
leased lines, junctions, terminating interfaces, hardware/software, memories of
semiconductor, magnetic and optical varieties, wired or wireless options, distribution
frames, and conduct the performance test including to enter into dialogue with the
system through input/out devices or terminals. The LICNESEE will provide the
necessary facilities for continuous monitoring of the system, as required by the
LICENSOR or its authorized representative(s). The LICENSOR will ordinarily
carried out inspection after reasonable notice except in circumstances where giving
such a notice will defeat the very purpose of the inspection.

- 24 -

<!-- page 25 -->

27. OPERATING CONDITION:
The LICENSEE shall make his own arrangements for all infrastructure involved in operation
and providing the Services. He shall be solely responsible for the installation,
networking, operation, treatment of the complaints, issue of bills and collection of
revenue for the services provided by him in addition to the claims, damages arising
out of this operation.
For the purpose of providing the Services, he may install equipment suitable to the
technology compatible with the Technical Parameters as specified in TEC Interface
Requirements No. IR/SCB-08/01 MAY 2007 as modified from time to time.
The LICENSEE will provide details of equipment, address of equipment location and site
configuration details on monthly basis to the Authority from the date of signing of the
LICENCE agreement or as and when required by the Authority.
In the process of operating the Services, the LICENSEE shall be responsible for :
(i)

The installation of the equipment at the sites, if required by the subscriber.
However, ownership (out right purchase or lease from LICENSEE) of
equipment at the subscriber’s premises will remain at the option of the VSAT
subscriber. The relevant specifications will be made available to the registered
subscriber desirous of obtaining their own VSATs.

ii)

The proper operation and maintenance of the equipment in the network, as
required.

iii)

Maintaining the criteria of performance as listed in the mandatory service
requirements.

iv)

Maintaining the MTTR within the scope of mandatory service requirements.

The LICENSEE shall be responsible for the measurement of the messages, in units, or as the
case may be and shall keep a record of the same for purposes of billing in so far as his
equipment and the Services are concerned. The LICENSEE shall maintain all
commercial records with regard to the communications exchanged on the network till
the Authority clears for destruction. Such records should be archived for at least one
year for scrutiny by the Authority for security reasons.
The LICENSEE shall be responsible for the complaints lodged by the users of his service.
He shall rectify the faults within MTTR specified in the scope of mandatory service
requirements.
The resources required for operation of the Services such as transponder/space segment etc.
will be mutually agreed between the parties. The LICENSEE may apply for and
obtain the desired resources from the Any other licensed Telecom Service Provider.
The Any other licensed Telecom Service Provider reserves the right to grant such
resources, on such terms and conditions as it may decide from time to time. The
operation and tariff for the traffic passed through these resources as well as provision
of these resources shall be governed by the prevailing rules and the guidelines of the

- 25 -

<!-- page 26 -->

BSNL/MTNL/the licensed Telecom Service Provider on the subject. This does not
entitle the LICENSEE as a matter of right to demand the resources, including space
segment.
The Authority reserves the right to revise the procedure of operation of LICENCE during its
currency based upon its experience or otherwise without any claims whatsoever on
the Authority from the LICENSEE.
The LICENSEE shall provide at his own cost technical facilities for accessing any port of the
switching equipment at the HUB for interception of the messages by the designated
authorities at a location to be determined by the Authority.
The LICENSEE shall provide a voice communication between the HUB Station and
Network Operation Control Centre of the INSAT System at his own cost.
Obtaining all type of clearances shall be the LICENSEE’s obligation which will not have
any connection with the payment of license fee as per schedule fixed in the license
agreement.
The LICENSEE should clearly indicate the specification of the service to the VSAT
subscriber at the time of signing the contract with them.
The intent of this LICENCE is not to grant long distance carrier rights to the LICENSEE. No
inter connection with PSTN/ public/private/value added/any other network is foreseen
in this LICENCE agreement except what is specifically permitted in condition 17 of
Licence Agreement.
28.

OPERATION AND MAINTENANCE OF HUB STATION :

28.1

The HUB Station shall be operated and maintained by the LICENSEE subject to the
following conditions:-

The Hub station as well as all the VSATs shall be within the geographical boundary of
India.
The VSAT at the premises of customer/ users should have a logo prominently displayed
indicating the name of VSAT LICENSEE.
The Authority or its representative will have access to the HUB as well as the technical
facilities provided by the LICENSEE for monitoring, inspection etc.
Before energizing the VSAT network, necessary clearances from INSAT Network
Operations Control Center (NOCC) on payment of prescribed charges will be
taken by the LICENSEE. NOCC instructions with regard to space segment access
and other relevant operational matters will have to be complied by the
LICENSEE.
The LICENSEE will provide a Hot line/ VSAT along with Remote NMS Terminal
between Hub/Network Control Station of CUG and NOCC of Authority for
effective monitoring of the space segment uses.

- 26 -

<!-- page 27 -->

The hub station shall have the auto tracking facility to access all the satellites in INSAT
Geo stationary arc. The hub station shall have 4 Port feed and motorized
polarization adjustment facility.
The information should be maintained in the Network Management System (NMS) in
such a way that by giving simple software command, the data related to the total
number of VSATs configured/operational with date of commissioning should be
available network-wise/customer-wise, alongwith their date of configuration, date
of commissioning, coordinates, address of the VSAT locations alongwith the
name of city, district, state etc.. In this regard, LICENSEE would abide by the
directive issued by the LICENSOR/ NOCC.

29.

REQUIREMENT TO FURNISH INFORMATION

The LICENSEE shall furnish such documents, accounts, estimates, returns, reports or other
information to the LICENSOR as well as to the TRAI in such manner and at such
frequency/ time frames as either of them may demand, in accordance with the rules/
orders as may be specified from time to time.

30.

ENGINEERING DETAILS :

The LICENSEE shall furnish to the LICENSOR, in such manner and at such times as the
LICENSOR may require, complete technical details with all calculations for
engineering, planning and dimensioning of the system/ network/ routes, concerned
relevant literature, drawing, installation materials regarding the APPLICABLE
SYSTEMS for the SERVICE.
List of performance tests conducted shall be furnished by the LICENSEE one month prior to
the date of commissioning of SERVICE. The report shall indicate clearly the
parameters, if any, not meeting the performance standards and their effect thereof.
LICENSEE shall supply all tools, test instruments and other accessories to the testing party of
LICENSOR for conducting tests.
31.

DISPUTES SETTLEMENT :

31.1

As per provisions of Telecom. Regulatory Authority of India Act, 1997 the dispute
between LICENSEE and the LICENSOR shall be settled in the Telecom. Disputes
Settlement and Appellate Tribunal, if such dispute arises out of or connected with the
provisions of this AGREEMENT. In the event of any amendment or modification or
replacement of TRAI Act, 1997 such modified provisions shall apply for adjudication
of the said dispute.

32.

FORCE-MAJEURE :

- 27 -

<!-- page 28 -->

If at any time, during the continuance of this LICENSE, the performance in whole or in part,
by either party, of any obligation under this is prevented or delayed, by reason of war,
or hostility, acts of the public enemy, civic commotion, sabotage, Act of State or
direction from Statutory Authority, explosion, epidemic, quarantine restriction, strikes
and lockouts (as are not limited to the establishments and facilities of the
LICENSEE), fire, floods, natural calamities or any act of GOD (hereinafter referred to
as EVENT), provided notice of happenings of any such EVENT is given by the
affected party to the other, within 21 Calendar days from the date of occurrence
thereof, neither party shall, by reason of such event, be entitled to terminate the
LICENSE, nor shall either party have any such claims for damages against the other,
in respect of such non-performance or delay in performance. Provided SERVICE
under the LICENSE shall be resumed as soon as practicable, after such EVENT
comes to an end or ceases to exist. The decision of the LICENSOR as to whether the
service may be so resumed (and the time frame within which the service may be
resumed) or not, shall be final and conclusive. However, the Force Majeure events
noted above will not in any way cause extension in the period of the LICENSE and
will also not be a ground for non-payment of LICENCE Fee.
Provision of alternative transponder capacity in case of any unforeseen failure of normally
allocated space segment is not guaranteed. In case of failure of space segment an
attempt will be made to provide the space segment from standby transponder, if any
available to the extent technically feasible. However, no claims for the space segment
failure will be allowed.
SET OFF CLAUSE :In the event any sum of money or claim becomes recoverable from or payable by LICENSEE
to the LICENSOR either against this LICENCE Agreement or otherwise in any
manner, such money or claim can be (without restricting any right of set off for
counter claim given or employed by law) deducted or adjusted against any amount or
sum of money then due or which at any time thereafter may become due to the
LICENSEE under this LICENCE Agreement or any other Agreement or contract
between the LICENSOR and the LICENSEE.
The aforesaid sum of money payable to the LICENSEE Company shall include any security,
which can be converted into money.
After exercising the right of set off, the LICENSOR shall expressly notify such action to the
LICENSEE company immediately in writing.

- 28 -

<!-- page 29 -->

34.

LEASING OF THE SPACE SEGMENT OF INSAT

The required space segment shall be reserved/ allocated on INSAT satellite by Department of
Space (DOS) on terms and conditions as specified by Department of Space (DOS)
from time to time.
The operation of space segment will be governed by rules and procedures of NOCC.
The space segment charges will be payable to DOS as applicable from time to time.
The space segment monitoring charges shall be payable to NOCC by LICENSEE as per the
rates to be decided by DOT.
35.

FREQUENCY AUTHORISATION

A separate LICENCE shall be obtained by the LICENSEE directly from the WPC Wing of
Ministry of Communication, which will permit utilization of appropriate radio
frequency spectrum for the establishment and operation of the VSAT Network under
usual terms and conditions of that LICENCE. Grant of LICENCE will be governed
by normal rules, procedures & guidelines and will be subject to completion of
necessary formalities.
For this purpose, an application shall be made directly to the Wireless Advisor to the Govt. of
India, WPC Wing, Ministry of Communication, Sanchar Bhawan, 20 Ashoka Road,
New Delhi – 110001 in a prescribed application form available from WPC Wing.
Siting clearance in respect of HUB Station/VSAT shall be obtained directly from the WPC
Wing for which an applicant shall apply directly to the Secretary, SACFA (Standing
Advisory Committee on Frequency Allocations) in the prescribed application form to
the following address:
The Secretary (SACFA)
WPC Wing, Ministry of Communications
Sanchar Bhawan, 20 Ashoka Road,
New Delhi – 110001.

Note: SACFA is the apex body in Ministry of Communications for considering
matters regarding frequency allocations and other related issues/matters. (Siting
clearance refers to the agreement of major wireless users for the location of proposed
stations from the point of view of compatibility with other radio systems and aviation
hazard. It involves inter-departmental coordination and is an involved process.)

LICENCE fee and Royalty shall have to be paid for grant of WPC LICENCE which will be
as prescribed by WPC and subject to revision from time to time.

- 29 -

<!-- page 30 -->

The LICENSEE shall not cause harmful interference to other authorized users of radio
spectrum. The Licensee shall abide by any instructions of the Government for
elimination of harmful interference to other authorized users.
The Wireless Planning and Coordination (WPC) Wing shall have the right to inspect from
time to time the installations from technical angle to check conformity with WPC
wing’s licence.
For use of space segment and setting up and operationalisation of Earth Station etc.,
LICENSEE shall directly coordinate with and obtain clearance from Network
Operations Control Centre (NOCC), apart from obtaining SACFA clearance and
clearance from other authorities.

DEFINITIONS AND INTERPRETATIONS
Unless the context otherwise requires, the different terms and expression used in the
LICENCE AGREEMENT shall have the following meaning assigned to them :1.

“ADJUSTED GROSS REVENUE” for the purpose of levying LICENCE Fee as a
percentage of revenue shall include the Gross Revenue excluding:i)

ii)

charges of pass through nature actually paid to other Telecom service
provider(s) to whose network, the LICENSEE’s network is interconnected for
carriage of data.
Service tax and sales tax actually paid to the Government, if gross revenue had
included the component of service tax.

“GROSS REVENUE”
The Gross Revenue shall include all revenues accruing to the LICENSEE on account
of goods supplied, services provided, leasing/hiring of infrastructure, use of its
resources by others, application fees, installation charges, call charges, late fees, sale
proceeds of instruments (or any terminal equipment including accessories), VSAT
hardware/software, fees on account of Annual Maintenance Contract/ Annual
Comprehensive Maintenance Contract income from value added services,
supplementary services, access or interconnection charges, etc. and any other
miscellaneous item including interest, dividend etc. without any set-off of related item
of expense etc.
2.

“APPLICABLE SYSTEMS” means all the necessary equipment, systems/ subsystems and components of the network engineered to meet relevant ITU standards,
ITU-T, ITU-R recommendations, TEC specifications and Industry Standards for
provision of SERVICE in accordance with operational, technical and quality
requirements and other terms and conditions of the Licence Agreement.

3.

“AUDITOR” means the Licensee’s Auditor for the time being appointed in
accordance with the provisions of the Companies Act, 1956.

- 30 -

<!-- page 31 -->

4.

“AUTHORITY” shall refer to the Director General, Telecommunications,
Government of India, and includes any officer empowered by him to perform all or
any of the functions of the Telegraph Authority.

5.

BACK HAUL CONNECTIVITY BETWEEN VSAT NETWORK AND HOST
COMPUTER OF THE CUSTOMERS
“Host computer of the customers can be connected to network of the service provider
by Radio, (subject to the availability of the frequencies), leased lines/ optical fibre
cables/other media from any licensed Telecom Service Provider can be used who is
authorized to lease out such lines for such interconnectivity.”

6.

‘BSNL’- Bharat Sanchar Nigam Limited and/ or its successors.

7.

“COMMISSIONING OF SERVICE” means complete installation of HUB equipment
and atleast 5 VSATs.

8.

“CONNECTABLE SYSTEM” means a telecommunication system which is
authorized to be run under a licence, which authorizes connection of that system to
the Applicable system.

9.

“DESIGNATED AUTHORITY” is the entity who is authorized or empowered by the
LICENSOR to issue instructions and to seek adherence to them.

10.

“DOT” means the Department of Telecommunications, Government of India who is
also the LICENSOR.

11.

“EFFECTIVE DATE” The date on which this LICENCE AGREEMENT is signed by
the parties and if the parties have signed on different dates, the later of two dates.

12.

“ENTRY FEE” The prescribed non-refundable amount of fee to be paid before
signing of LICENCE AGREEMENT to provide Basic Telephone Service in a Service
Area.

13.

“INTERCONNECTION” is as defined by the TRAI vide its regulations issued in this
respect.

14.

“ICC” means INSAT Coordination Committee.

15.

“LICENSEE” is the registered Indian Company that has been awarded LICENCE to
set up, operate and provide the SERVICE.

16.

“LICENSOR’S AUDITOR” means as Auditor appointed for the purpose of auditing
who shall have same powers as enjoyed by Auditors appointed under Section 227 of
the Companies Act, 1956.

17.

“MESSAGE” means anything falling within subsection 3 of section 3 of the Indian
Telegraph Act 1885, and specifically permitted under this LICENCE.

- 31 -

<!-- page 32 -->

18.

“NETWORTH” shall mean the sum total, in Indian rupees, of paid up equity capital
and free reserves converted at the prevalent conversion rate indicated by the Reserve
Bank of India on the date of the application.

19.

“NOCC” means Network Operation Control Centre of the Department of Telecom,
Government of India.

20.

“QUALITY OF SERVICE” means evaluation of Service on the basis of observed
measures on the grade of service, calls lost due to wrong processing, the bit error rate
or the response time. The Quality of Service also includes acceptable grade of
number of faults per unit population of the subscribers served, the Mean Time To
Repair (MTTR), faults carried over beyond the MTTR and the disposal thereof.

21.

“SERVICE AREA” defines the geographical limits within which the LICENSEE may
operate and offer the Services except the areas specified from time to time by
Government of India.

22.

The term “SERVICE” means closed user group domestic Data Network via INSAT
Satellite System using VSAT.

23.

TDSAT – Telecom. Disputes Settlement and Appellate Tribunal.

24.

“TECHNICAL SPECIFICATIONS” means the specifications referred to as
mandatory service requirement of the related service.

25.

“TEC” means Telecom. Engineering Centre.

26.

TRAI means Telecom. Regulatory Authority of India constituted under the TRAI Act
1997 as amended from time to time.

27.

“VALIDITY OF THE LICENCE” is the period for which this LICENCE may be
effective;

28.

“VSAT” means Very Small Aperture Terminal.

29.

“VSAT LICENCE” means the LICENCE for those networks in which the Hub
equipment and facilities are owned and operated by LICENSEE and services is
provided to third parties using the shared Hub infrastructure. The subscriber end
equipment and facilities may be owned by the subscriber/ LICENSEE.

30.

“WPC” means Wireless Planning and Coordination wing of Ministry of
Communications and Information Technology, Department of Telecommunication,
Government of India.

31.

“YEAR” for the purpose of the Licence Fee shall be the financial year ending 31st
March and the four quarters shall respectively end on 30th June, 30th September, 31st
December and 31st March.

- 32 -

<!-- page 33 -->

ANNEXURE-I

---------------------------------- (Name and address of operator)
VERY SMALL APERTURE TERMINAL SERVICE
Statement of Revenue and LICENCE Fee for the
Quarter……………………………………….
of the financial year………………………………

Sl. PARTICULARS
No.

1.
i.

ii.

iii.
iv.
v.

vi.

ACTUALS
FOR THE
PREVIOUS
QUARTER

Revenue from Services:
Revenue from provisioning of
VSAT service as defined at Sl.
No.1 under heading ‘Definition
and interpretations’ in the licence
after clause 35
Revenue from
supplementary/value added
services.
Service Tax
Revenue from lease/rentals of
items in 2(i) and (ii) below.
Revenue from Annual
Comprehensive Maintenance
Contract (ACMC)/ Annual
Maintenance Contract (AMC)
etc.
Any other income/ miscellaneous
receipt.

2.

Income from Trading activity:
(all inclusive of sales tax)
i. Sale of VSAT including antennas
and other accessories including
software, hardware etc.
ii. Sale of accessories, etc.
iii. Any other income/miscellaneous
receipt from trading activity.

3.

Income from investments.
i. Interest income
ii. Dividend income
iii. Any other miscellaneous receipt
- 33 -

(AMOUNT IN RUPEES)
FIGURES CUMULATIVE
FOR
FIGURES
CURRENT UPTO THE
QUARTER PREVIOUS
QUARTER

<!-- page 34 -->

from investments.
4.

Non-refundable deposits.

5.

Revenue from sharing/leasing
of other infrastructure

6.

Miscellaneous revenue.

AA GROSS REVENUE OF THE
LICENSEE COMPANY:

1.

2.
3.
BB
CC

DEDUCT:
Revenue of pass through nature
actually passed on to other
service providers. (operator-wise
details).
Note: Lease/rent charges for
hiring of infrastructure not to be
deducted.
Service Tax paid to the
Government.
Sales Tax paid to the
Government
TOTAL DEDUCTIBLE
REVENUE
ADJUSTED GROSS
REVENUE:
(AA-BB)
REVENUE SHARE
@…………… OF ADJUSTED
GROSS REVENUE:

- 34 -

<!-- page 35 -->

ANNEXURE -II
Format of AUDITOR’s Report on Statements of Revenue and LICENCE Fee
To
The Board of Directors,
……………………….
……………………….
……………………….

We have examined the attached Statement of Revenue and LICENCE Fee of
………………………. ………………………. (the name of the OPERATORs) for the
quarter(s) ending ………………………. . We have also examined the reconciliation of the
cumulative figures for the quarter(s) ending ………………………. appearing in the
Statement of Revenue and LICENCE Fee of the company with the figures appearing in the
profit and loss account of the company for the year ended ………………………. which was
audited by us. We understand that the aforesaid statement(s) (and the reconciliation) is / are
to be furnished to the Central Government for assessment of the LICENCE Fee payable by
the company to the Government, in terms of the LICENCE AGREEMENT No.
……………………… signed between the company and the Department of
Telecommunications. We report that:
We have obtained all the information and explanations which to the best of our
knowledge and belief were necessary for the purpose of our audit.
In our view, the company has an adequate internal control system in relation to revenues
which is commensurate with its size and the nature of its business. The system, in
our opinion, provides reasonable assurance that there is no unrecorded revenue
and that all revenue is recorded in the proper amount and in the proper period.
No amounts payable in respect of sales tax, service tax or PSTN/ toll/roaming charges
were outstanding at the last day of the quarter(s) for a period of more than two
months from the date they became payable, except for the following :
………………………
In our opinion and to the best of our knowledge and belief and according to the
explanations given to us, the Statement has been prepared in accordance with the
norms/ guidelines contained in the said LICENCE AGREEMENT in this behalf
and gives a true and fair view of the revenue and LICENCE Fee payable for the
period computed on the basis of the aforesaid guidelines except for the following:
* Strike off wherever not applicable.

ANNEXURE –III

- 35 -

<!-- page 36 -->

NORMS FOR PREPARATION OF ANNUAL FINANCIAL STATEMENTS
Accounts shall be maintained separately for each telecom service operated by the
LICENSEE company.
Any category of accrued revenue, the amount of which exceeds 5% of the total accrued
revenue, shall be shown separately and not combined with any other item/ category.
Accrued revenue shall indicate:
All amounts billable for the period
Any billings for previous years that had been omitted from the previous years’ P&L
Accounts.
Any non-refundable deposits collected from the Customers/ franchisees to the extent
these are credited to P&L Account for the year.
Subsidiary registers/ ledgers shall be maintained for each item given above so also enable
easy verification.
Service revenue (amount billable) shall be shown gross and details of discount/rebate
indicated separately.
Security or any other deposits taken from the subscribers shall be shown separately, for
each category, and the amount that has fallen due for refund but not yet paid also
disclosed under two categories, namely:
Up to 45 days
More than 45 days
Service Tax billed, collected and remitted to the Government shall be shown separately.
Sales Tax billed, collected and remitted to the Government shall be shown separately.
Details of Income from sales of goods shall be furnished indicating the income and
number of items sold under each category. Method of inventory valuation used shall
also be disclosed along with computation of cost of goods sold.
Sales shall be shown gross and details of discount/ rebate allowed and of sales returns
shall be shown separately.
Income from interest and dividend shall be shown separately, without any related
expenses being set-off against them on the income side of the P&L Account.
Increase / decrease of stock shall be shown separately.
Details of reversal of previous years’ debits, if any, shall be shown component-wise,
under the miscellaneous head. (e.g. Bad debts recovered etc.)
Item-wise details of income that has been set off against corresponding expenditure.

- 36 -

<!-- page 37 -->

ANNEUXRE-IV

PERFORMANCE BANK GUARANTEE FOR FULFILLING NETWORK ROLL-OUT
OBLIGATIONS FOR COMMERCIAL CLOSED USER GROUP VSAT SERVICE
To
The President of India
(Acting through Telegraph Authority)

In consideration of the President of India, Acting through Telegraph Authority (hereinafter
referred to as ‘the Authority’), having agreed to grant a LICENCE to M/s__________
________
___ ____________ of______________ ___________________(hereinafter
called 'the LICENSEE') to establish, maintain and operate Commercial Closed User Group
VSAT service (hereinafter called 'the SERVICE') as per Letter of Intent LICENCE
No………………… dated…………….. (hereinafter called 'the said LICENCE') on the terms
and conditions contained in the said LICENCE, which inter-alia provides for production of a
Bank Guarantee to the extent of Rs 10,00,000 (in words Ten lakhs only ) for the service by
way of security for the due observance and performance of the terms and conditions of the
said LICENCE. We……………………. (indicate the name and address and other particulars
of the Bank) (hereinafter referred to as 'the Bank') at the request of the LICENSEE hereby
irrevocably and unconditionally guarantee to the Authority that the LICENSEE shall render
all necessary and efficient services which may be required to be rendered by the LICENSEE
in connection with and/or for the performance of the said LICENSE and further guarantees
that the service which shall be provided by the LICENSEE under the said LICENCE, shall be
actually performed in accordance with the terms & conditions of the LICENSE to the
satisfaction of the Authority.
2.

We, the Bank, hereby undertake to pay the Authority, an amount not exceeding Rs.
10,00,000 (Rupees Ten lakhs only) against any loss or damage caused to or suffered
or would be caused to or suffered by the Authority by reason of any breach by the
said LICENSEE of any of the terms and conditions contained in the said LICENCE.

3.

We the Bank hereby, in pursuance of the terms of the said LICENCE, absolutely,
irrevocably and unconditionally guarantee as primary obligor and not merely as surety
the payment of an amount of Rs 10,00,000 (Rupees Ten lakhs only) to the Authority
to secure due and faithful performance by the LICENSEE of all his/their obligations
under the said LICENCE.

4.

We, the Bank hereby also undertake to pay the amounts due and payable under this
guarantee without any demur, merely on a demand from the Authority stating that the
amount claimed is due by way of loss or damage caused or would be caused to or
suffered by the Authority by reason of breach by the said LICENSEE of any of the
terms or conditions contained in the said LICENCE or by reason of the LICENSEE’s
failure to perform any of it's obligations under the said LICENCE."

- 37 -

<!-- page 38 -->

5.

We, the Bank, hereby agree that the decision of the Authority as to whether, the
LICENSEE has failed to or neglected to perform or discharge his duties and
obligations as aforesaid and/or whether the service is free from deficiencies and
defects and is in accordance with or not of the terms & conditions of the said
LICENCE and, as to the amount payable to the Authority by the Bank hereunder
shall be final and binding on the Bank.

6.

WE, THE BANK, DO HEREBY DECLARE AND AGREE that:

(a)

the Guarantee herein contained shall remain in full force and effect for a period of
One Year from the date hereof and that it shall continue to be enforceable till all the
dues of the Authority and by virtue of the said LICENCE have been fully paid and its
claims satisfied or discharged or till the Authority satisfies that the terms and
conditions of the said LICENCE have been fully and properly carried out by the said
LICENSEE and accordingly discharged this guarantee.

(b)

the Authority shall have the fullest liberty without our consent and without affecting
in any manner our obligations hereunder to vary any of the terms and conditions of
the said LICENCE or to extend time of performance of any obligations by the said
LICENSEE from time to time or to postpone for any time or from time to time any of
the powers exercisable by the Authority against the said LICENSEE and to forbear or
to enforce any of the terms and conditions relating to the said LICENCE and we shall
not be relieved from our liability by reason of any variation or extension being
granted to the said LICENSEE or forbearance act or omission on the part of the
Authority or any indulgence by the Authority to the said LICENSEE or to give such
matter or thing whatsoever which under the law relating to sureties would but for this
provision, have effect of so relieving us.

(c)

any claim which we have against the LICENSEE shall be subject and subordinate to
the prior payment and performance in full of all the obligations of us hereunder and
we will not without prior written consent of the Authority exercise any legal right or
remedy of any kind in respect of any such payment or performance, so long as the
obligations of us hereunder remains owing and outstanding.

(d)

This Guarantee shall be irrevocable and the obligations of us herein shall not be
conditional of any prior notice by us or by the LICENSEE.

7.

We the BANK undertake not to revoke this Guarantee during its currency except with
the previous consent of the Authority in writing.

8.

Notwithstanding anything hereinabove stated, our liability under the Guarantee is
limited to Rs. 10,00,000 (Rupees Ten lakhs only) and a claim arising out of the
guarantee must be received by the bank in writing on or before ------------------, after
which the liability of the bank would be extinguished.

- 38 -

<!-- page 39 -->

Dated________________day______________________

Witness:
1……………………
…………………….
…………………….
……………………
2…………………..
…………………….
…………………….
……………………

- 39 -

for___________________ ..
(Name of the Bank)

<!-- page 40 -->

ANNEXURE-V
PROFORMA FOR FINANCIAL BANK GUARANTEE
To
The President of India
(Acting through the Telegraph Authority)
In consideration of the President of India, (hereinafter called ‘the Authority’) having agreed
to
grant
a
LICENCE
to
M/s
_________________________
of__________________________(hereinafter called ‘the LICENCEE’) to establish, maintain
and operate …………. Service (hereinafter called the SERVICE) in accordance with the
LICENCE No._____________________dated_______(hereinafter called ‘the LICENCE) on
the terms and conditions contained in the said LICENCE, which inter-alia provides for
production of a Bank Guarantee to the extent of Rs. __________ (Rupees
________________ only) under the said LICENCE by way of security for payment of the
said LICENCE Fee as well as such other Fees/dues or charges required to be paid by the
LICENSEE under the LICENCE, We __________________(indicate the name and address
and other particulars of the Bank) (hereinafter referred to as ‘the Bank’) at the request of the
LICENSEE hereby irrevocably and unconditionally guarantee to the Authority that the
LICENSEE shall pay all the dues, including but not limited to, the LICENCE Fee and other
charges to the Authority.
2.

We, the Bank, hereby undertake to pay to the Authority an amount not exceeding
Rs.______________(Rupees_________________only) against any loss or damage
caused to or suffered or would be caused to or suffered by the Authority by reason of
any failure of the LICENSEE to extend the validity of the guarantee or give a fresh
guarantee in lieu of existing one, or to pay all the above mentioned Fees, dues and
charges or any part thereof within the periods stipulated in the LICENCE.

3.

We, the Bank, hereby further undertake as primary obligor and not merely as surety to
pay such sum not exceeding Rs._______________ (Rupees________________only)
to the Authority immediately on demand and without demur stating that the amount
claimed is due by way of failure of the LICENSEE to pay any Fees or charges or any
part thereof in terms of the said LICENCE.

4.

WE, THE BANK, DO HEREBY DECLARE AND AGREE that the decision of the
Authority as to whether LICENSEE has failed to pay the said LICENCE Fees or any
other Fees or charge or any part thereof payable under the said LICENCE and as to
the amount payable to the Authority by the Bank hereunder shall be final and binding
on us.”

WE, THE BANK, DO HEREBY DECLARE AND AGREE that the
(a)

Guarantee herein contained shall remain in full force and effect for a period of
_____________ from the date hereof and that it shall continue to be enforceable till
all the dues of the Authority and by virtue of the said LICENCE have been fully paid
and its claims satisfied or discharged or till Authority satisfies that the terms and
conditions of the said LICENCE have been fully and properly carried out by the said
LICENSEE and accordingly discharged this guarantee.

- 40 -

<!-- page 41 -->

(b)

The Authority shall have the fullest liberty without our consent and without affecting
in any manner our obligations hereunder to vary any of the terms and conditions of
the said LICENCE or to extend time of performance of any obligations by the said
LICENSEE from time to time or to postpone for any time or from time to time any of
the powers exercisable by the Authority against the said LICENSEE and to forebear
or to enforce any of the terms and conditions relating to the said LICENCE and we
shall not be relieved from our liability by reason of any forbearance act or omission
on the part of the Authority or any indulgence by the Authority to the said
LICENSEE or to give such matter or thing whatsoever which under the law relating to
sureties would but for this provision, have effect of so relieving us.

(c)

Any claim which we have against the LICENSEE shall be subject and subordinate to
the prior payment and performance in full of the obligations of us hereunder and we
will not without prior written consent of the Authority exercise any legal right or
remedy of any kind in respect of any such payment or performance so long as the
obligations of us hereunder remains owing and outstanding.

(d)

This Guarantee shall be irrevocable and the obligations of us herein shall not be
conditional of any prior notice by us or by the LICENSEE.

We the BANK undertake not to revoke this Guarantee during its currency except with the
previous consent of the Authority in writing.
Notwithstanding anything contained above, our liability, under the Guarantee shall be
restricted to Rs. ____________ and our Guarantee shall remain in force until _____
year from the date hereof. Unless a demand or claim under this Guarantee is made on
us in writing within this date i.e. ______________ all your rights under the Guarantee
shall be forfeited and we shall be released and discharged from all liabilities
thereunder.
Dated________________day_____________
Witness:
1………………………………….
2………………………………….

- 41 -

for____________________
(name of the Bank)

<!-- page 42 -->

ANNEXURE-VI
PROFORMA FOR PERFORMANCE BANK GUARANTEE
To
The President of India
(Acting through the Telegraph Authority)
In consideration of the President of India, (hereinafter referred to as ‘the Authority’), having
agreed to grant a LICENCE to M/s__________ ________
___ ____________
of______________ ___________________(hereinafter called 'the LICENSEE') to establish,
maintain and operate VSAT service (hereinafter called 'the SERVICE') as per Letter of
Intent LICENCE No………………… dated…………….. (hereinafter called 'the said
LICENCE') on the terms and conditions contained in the said LICENCE, which inter-alia
provides for production of a Bank Guarantee to the extent of Rs_________________(in
words_______________________ ) for the service by way of security for the due observance
and performance of the terms and conditions of the said LICENCE. We…………………….
(indicate the name and address and other particulars of the Bank) (hereinafter referred to as
'the Bank') at the request of the LICENSEE hereby irrevocably and unconditionally guarantee
to the Authority that the LICENSEE shall render all necessary and efficient services which
may be required to be rendered by the LICENSEE in connection with and/or for the
performance of the said LICENSEE and further guarantees that the service which shall be
provided by the LICENSEE under the said LICENCE, shall be actually performed in
accordance with the terms & conditions of the LICENSEE to the satisfaction of the
Authority.
2.

We, the Bank, hereby undertake to pay the Authority, an amount not exceeding
Rs……… (Rupees………………………… only) against any loss or damage caused
to or suffered or would be caused to or suffered by the Authority by reason of any
breach by the said LICENSEE of any of the terms and conditions contained in the
said LICENCE including failure to extend the validity of this guarantee or to give a
fresh guarantee in lieu of the existing one.

3.

We the Bank hereby, in pursuance of the terms of the said LICENCE, absolutely,
irrevocably and unconditionally guarantee as primary obligor and not merely as surety
the
payment
of
an
amount
of
Rs………………………………
(Rupees…………………. only) to the Authority to secure due and faithful
performance by the LICENSEE of all his/their obligations under the said LICENCE.

4.

We, the Bank hereby also undertake to pay the amounts due and payable under this
guarantee without any demur, merely on a demand from the Authority stating that the
amount claimed is due by way of loss or damage caused or would be caused to or
suffered by the Authority by reason of breach by the said LICENSEE of any of the
terms or conditions contained in the said LICENCE or by reason of the LICENSEE’s
failure to perform any of it's obligations under the said LICENCE."

- 42 -

<!-- page 43 -->

5.

We, the Bank, hereby agree that the decision of the Authority as to whether, the
LICENSEE has failed to or neglected to perform or discharge his duties and
obligations as aforesaid and/or whether the service is free from deficiencies and
defects and is in accordance with or not of the terms & conditions of the said
LICENCE and, as to the amount payable to the Authority by the Bank hereunder
shall be final and binding on the Bank.

6.

WE, THE BANK, DO HEREBY DECLARE AND AGREE that:

(a)

the Guarantee herein contained shall remain in full force and effect for a period of
Three Years from the date hereof and that it shall continue to be enforceable till all
the dues of the Authority and by virtue of the said LICENCE have been fully paid and
its claims satisfied or discharged or till the Authority satisfies that the terms and
conditions of the said LICENCE have been fully and properly carried out by the said
LICENSEE and accordingly discharged this guarantee.

(b)

the Authority shall have the fullest liberty without our consent and without affecting
in any manner our obligations hereunder to vary any of the terms and conditions of
the said LICENCE or to extend time of performance of any obligations by the said
LICENSEE from time to time or to postpone for any time or from time to time any of
the powers exercisable by the Authority against the said LICENSEE and to forbear or
to enforce any of the terms and conditions relating to the said LICENCE and we shall
not be relieved from our liability by reason of any variation or extension being
granted to the said LICENSEE or forbearance act or omission on the part of the
Authority or any indulgence by the Authority to the said LICENSEE or to give such
matter or thing whatsoever which under the law relating to sureties would but for this
provision, have effect of so relieving us.

(c)

any claim which we have against the LICENSEE shall be subject and subordinate to
the prior payment and performance in full of all the obligations of us hereunder and
we will not without prior written consent of the Authority exercise any legal right or
remedy of any kind in respect of any such payment or performance, so long as the
obligations of us hereunder remains owing and outstanding.

(d)

This Guarantee shall be irrevocable and the obligations of us herein shall not be
conditional of any prior notice by us or by the LICENSEE.

7.

We the BANK undertake not to revoke this Guarantee during its currency except with
the previous consent of the Authority in writing.

8.

Notwithstanding anything contained above, our liability, under the Guarantee shall be
restricted to Rs……. and our Guarantee shall remain in force until…… year from the
date hereof. Unless a demand or claim under this Guarantee is made on us in writing
within this date i.e. ….all your rights under the Guarantee shall be forfeited and we
shall be released and discharged from all liabilities thereunder.

- 43 -

<!-- page 44 -->

Dated________________day______________________

Witness:
1……………………
…………………….
…………………….
……………………
2…………………..
…………………….
…………………….
……………………

- 44 -

for___________________ ..
(Name of the Bank)

<!-- page 45 -->

ANNEXURE – VII
TRIPARTITE AGREEMENT
THIS TRIPARTITE AGREEMENT made at ___________________ on this the
_________ day of 2003 amongst;
THE PRESIDENT OF INDIA acting through Shri _________________ . The Assistant
Director General (LR-V), Department of Telecommunications, Sanchar Bhavan, New Delhi –
110 001 (hereinafter called “the LICENSOR”).
AND
_____________________________________, a company incorporated under the
Companies Act, 1956 having its Registered Office at _____________________________
acting through Shri _______________________ duly constituted attorney/authorized person
pursuant to the General Power of Attorney dated _______________ executed as per terms of
the Board Resolution dated _______________, (hereinafter called the LICENSEE).
AND
___________________________________, acting for itself as Lender, and as Agent for the
Lenders listed in schedule (hereinafter referred to as “the Agent”) through Shri
_________________________ duly constituted attorney/authorized officer pursuant to the
General Power of Attorney dated ________________ executed per terms of the Board
Resolution dated ______________.
WHEREAS:
(i)

By the LICENCE AGREEMENT dated __________ entered into between the
LICENSOR and the LICENSEE, the LICENSOR has granted the LICENCE to
the LICENSEE for a telecom project envisaging to establish, installed, operate
and maintain VSAT Closed User Group Domestic Data Network via INSAT
Satellite System on non exclusive basis within territorial boundary of India on the
terms, conditions and covenants agreed to between them and incorporated therein.

With a view to help and facilitate the financing of the Project to be set up by the
LICENSEE pursuant to the LICENCE referred to above, the parties hereto are
desirous of recording the terms and conditions to provide transfer/assignment of
LICENCE as hereinafter provided in this AGREEMENT to protect and secure the
Lender’s Interest arising out of grant of financial assistance to the LICENSEE.
The Lenders have agreed to grant Financial Assistance to the LICENSEE to the extent
mutually agreed between them on the terms, conditions and covenants set out in
the respective Loan AGREEMENTs entered into by the LICENSEE with the
respective Lenders.

- 45 -

<!-- page 46 -->

NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
ARTICLE – 1 DEFINITIONS
For the purpose of this AGREEMENT, the following terms shall have the following
meaning:
“Agent” means …(give name of the Agent) an Indian schedule bank/an Indian Public
Financial Institution/ an Indian Majority controlled, non-banking finance company
engaged in infrastructural projects in India acting for itself and as Agent for other
members of a consortium of Lenders who have consented to provide Financial
Assistance to the LICENSEE for the project.
(Explanation: Only Indian Financial Institution or a Scheduled Bank participating in the
financial assistance to the LICENSEE will act as the Agent).
“Event of Default” means occurrence of any of the following events:A default by the LICENSEE in payment of the LICENCE Fee or other dues duly
payable to the LICENSOR, under the LICENCE AGREEMENT.
A material default of the terms and conditions of Loan AGREEMENTs.
(Explanation: ‘Material Default’ shall means a continuous default by the LINCENSEE for a
minimum period of one month in payment of any two quarterly installments or one half
yearly installment either of principal or interest or both under the Loan AGREEMENT or any
breach by the LICENSEE of the terms & conditions of the Loan AGREEMENT or any other
document duly executed by the LICENSEE in favour of the Lenders which in the considered
opinion of the Agent is likely to affect adversely and substantially the ability of the
LICENSEE to work or operate the project.
“Financial Assistance” means the financial assistance granted or agreed to be granted by or
any money due to the Lenders under the Loan AGREEMENTs and/or any other
respective AGREEMENTs in respect of the projects referred to in Schedule hereto.
“LICENCE” means the LICENCE under the LICENCE AGREEMENT dated __________
entered into between the LICENSOR and the LICENSEE in respect of
________________ Service Area including any amendment made thereto from time
to time, for operation of ____________ service by LICENSEE.
“Lenders” means the parties referred to in the Schedule hereto and includes any syndicate
members or participant lender in any syndicate/participation financing.
“Lender’s Dues” means all monies owed by the LICENSEE to the Lenders in respect of the
project whether fallen due or nor under the Loan AGREEMENT or other respective
AGREEMENTs related to the project.
“Loan AGREEMENTs” means the AGREEMENTs entered/to be entered into between the
LICENSEE and the Lender or Lenders in respect of the Financial Assistance and
referred to in Schedule hereto.

- 46 -

<!-- page 47 -->

“Project” means the LICENSEE’s Basic Telephone Service/Cellular Mobile Telephone
Service (CMTS)/ radio paging Service, VSAT Service using INSAT System project
for establishment, maintenance and operation of Basic Telephone Service/CMTS
Radio Paging Service in the _____________ Circle/Service Area.s
“Selectee” means an Indian company within the meaning of Companies Act, 1956, selected
by the Lenders and proposed to the LICENSOR for the purpose of
assignment/transfer of the LICENCE as provided in this AGREEMENT.
ARTICLE 2
TRANSFER OR ASSIGNMENT OF LICENCE AS SECURITY
FOR FINANCIAL ASSISTANCE
The LICENSOR hereby agrees to transfer or assign the LICENCE by endorsement thereon in
favour of the selectee selected by the Lenders in accordance with the Articles 2 & 3
hereunder provided that nothing contained herein shall entitle the Lenders to operate
the Service under LICENCE themselves as a LICENSEE either individually or
collectively.
2.2

(a)
The Agent shall notify the LICENSEE and simultaneously intimate the
LICENSOR about the occurrence of any event of material default and require the
LICENSEE to remedy and cure the same within 30 days from the date of such notice.
(b)
The Notice of event of Default, shall be the conclusive evidence of such Event
of Default under the Loan AGREEMENT and it shall be final and binding upon the
LICESEE for the purpose of this AGREEMENT.

2.3

(c)
The LICENSOR and the LICENSEE hereby agree that upon the expiry of the
period of 30 days from the date of Notice of Event of Default where the LICENSEE
has failed or been unable to remedy or cure the default, the Lenders may invite,
negotiate and procure offers of Lenders for the take over and transfer of the project
together with all the assets pertaining to the Project of LICENSEE including the
LICENCE to the Selectee upon such selectee’s assumption of the liabilities and
obligations of the LICENSEE towards the LICENSOR under the LICENCE
AGREEMENT and toward the Lenders under their respective Loan AGREEMENTs.
The Selectee shall meet the following eligibility criterion for transfer of the assets of
the Project to it :
the Selectee shall be capable of properly discharging the duties, obligations and
liabilities under the LICENCE AGREEMENT.
the Selectee shall be capable and shall provide adequate security to the satisfaction of
the Lenders for the Financial Assistance.
The Selectee shall have the capability and shall given necessary consent to assume the
liability of the LICENCE Fee including the other dues of the LICENSOR and the
Lenders’ Dues;
The Selectee shall satisfy at the time of formulation of transfer proposal the networth
and experience criteria as well as technical and equity parameters as were adopted
for the selection of LICENSEE.

- 47 -

<!-- page 48 -->

The selection should not be of such a company or its sister concern who was/ has been
granted any LICENCE and became/ has become defaulter.
Any other appropriate criteria, as may be prescribed by the LICENSOR from time to
time, to ensure continuity in the service.
The Agent shall notify the LICENSOR of the accrual of right to seek transfer/assignment of
the LICENCE pursuant to Article 2.2 which the LICENSOR shall take on record.
Before transferring or assigning the LICENCE to the Selectee pursuant to this
AGREEMENT, the LICENSOR shall satisfy itself as to the eligibility criteria under
Article 2.3 and the decision of the LICENSOR in this regard shall be final.
ARTICLE – 3
MODALITY OF TRANSFER/ASSIGNMENT AND
ENDORSEMENT OF LICENCE

The modality for the Agent seeking the transfer/assignment/endorsement of the LICENCE
shall be as provided below:
The Agent after expiry of 30 days from the date of notice as per Article 2.2 may,
invite, procure and negotiate offers under a transparent procedure either by
private negotiations or public auction or tenders for transfer or takeover of the
assets including the LICENCE of the LICENSEE pertaining to the project by
the Selectee together with the Lenders Dues and the dues of the LICENSOR.
The Agent on behalf of the Lenders shall recommend to the LICENSOR, the name of
the Selectee for its acceptance and shall request the LICENSOR to:
accede to transfer to the Selectee the right to operate the network of the Project
in accordance with the terms agreed to between the Lenders and the
Selectee.
Endorse and transfer the LICENCE to the Selectee on the same terms and
conditions, for the residual period of the original LICENCE.
Enter into Tripartite AGREEMENT with the lenders and the Selectee on the
same terms and conditions as are contained in this AGREEMENT.
Facilitate granting of WPC, SACFA and other approvals, clearance,
permission necessary for operating the service upon the appropriate
applications made by the Selectee.
(iii) The LICENSOR subject to satisfaction of criterion as to the networth,
experience, technical and equity parameters set out and determined in accordance
with Article 2.3 & 2.5 and upon assumption of the liabilities by the Selectee as
provided in Article 2.2 (c), shall proceed to transfer/assign by endorsement the
existing LICENCE to the Selectee on the same terms and conditions as are contained
in the LICENCE AGREEMENT for the residual period in favour of the
Selectee.

- 48 -

<!-- page 49 -->

(iv) If the LICENSOR has by objection to the transfer of LICENCE in favour of
the Selectee in terms of this AGREEMENT, it shall within 90 days from either the
date of LICENSOR’S receipt of the proposal made by the Agent, or the last date of
any clarification called for the LICENSOR from the Agent, whichever date is later,
give a reasoned order after hearing the Agent, for its refusal. If no objection is raised
within the above mentioned time limit, by the LICENSOR for the selection of the
Selectee, the selectee shall be deemed to have been accepted except in cases of
accidental or willful omission or suppression of material facts in this connection.
The LICENSOR thereupon shall transfer/assign/endorse the LICENCE within 15
days of its acceptance/deemed acceptance of the Selectee.
Provided however, that in the event of a refusal as stated above, the Agent may
propose another Selectee whereupon the process outlined in this AGREEMENT for
such acceptance shall once again be repeated and followed.
Decision of LICENSOR in selection of the Selectee shall be final and biding on the
Licensee and Lender/Agent.
All actions of the Agent pursuant to this AGREEMENT shall be for the benefit of the
Lenders, and be biding upon Lenders. The Agent is authorized to receive
payments on account of compensation or consideration for transfer of the Project
in accordance with this AGREEMENT and give valid discharge for and on behalf
of all Lenders. All monies so received by the Agent shall be held by it in trust for
and made over to the Lenders to be distributed in accordance with their respective
rights under the Loan Agreements as modified by any inter-se arrangement among
the Lenders.
Unless otherwise agreed to by the LICENSOR, all actions as set out in Article 3.1 for the
selection of a Selectee whether on first or subsequent occasions and submission of the
final proposal to the LICENSOR for the transfer of the LICENCE in favour of the
Selectee shall be completed by the Agent within a period of six months or such other
period as may be mutually agreed by the LICENSOR and the Agent, from the date of
Notice of Event of Default.
The LICENSEE irrevocably agrees and waives any right to challenge the action of the Agent
or the Lenders or the LICENSOR taken pursuant to this AGREEMENT including the
assignment/transfer of the LICENCE in favour of the Selectee. The LICESEE agrees
and confirms that it shall not have any right to seek re-valuation of assets of the
Project or the LICENSEE’s Shares. It is confirmed by the LICENSEE that the right of
the Lenders is irrevocable and shall not be contested in any proceedings before any
Court or Authority and the LICENSEE shall have not right or remedy to prevent,
obstruct, injunct or restrain the LICENSOR or the Lenders from effecting or causing
the transfer/assignment/endorsement of the LICENCE as requested by the Lenders
through the Agent. Notwithstanding anything contained herein, the provisions of
Article 7.11 shall continue to prevail.
If the LICENSOR decides to transfer the LICENCE to any person other than the Selectee, it
shall take into account the Lenders Dues as well as the LICENSOR’S dues while
inviting bids from the prospective transferees or assignees and shall include a suitable
condition as agreed to by the Lenders for payment or take over of Lender’s dues by

- 49 -

<!-- page 50 -->

such transferee or assignee. Such Transferee or the assignee shall have the option of
repaying the Lenders debt in full or to execute a Tripartite AGREEMENT similar to
the AGREEMENT if lenders dues remain outstanding and undischarged.
If a Selectee (new/alternate LICENSEE as provided in Article 3.4 above) is not found, then
the LICENCE AGREEMENT shall stand terminated and the assets/infrastructure of
defaulting LICENSEE shall have to be disposed off with LICENSOR having the first
charge/right/precedence for recovery of its dues from proceeds of such disposal.
Remainder of the proceeds of such disposal, if any, shall go to offset the dues of
Lenders to the extent possible and balance left, if any, will go to the defaulting
LICENSEE. The defaulting LICENSEE shall be liable to the LICENSOR for cost of
all corrective efforts as per prevailing market forces and the decision of LICENSOR
shall be final in all respects.
Provided always that nothing in this AGREEMENT shall be interpreted to mean that the
LICENSOR has provided any guarantee or surety and it is expressly agreed that the
LICENSOR has not provided any surety, guarantee or counter guarantee whether
directly or indirectly for the recovery of Financial Assistance advanced or to be
advanced by the Lenders to the LICENSEE.

ARTICLE – 4
INTERIM PROTECTION OF SERVICE
AND PRESERVATION OF SECURITY
On the Agent issuing the Notice of Event of Default (and the LICENSEE has not cured the
default for a period of 30 days) as hereinabove provided or in other circumstances
which in the considered opinion of the Agent is likely to affect adversely and
substantially the Lenders’ security, the Lenders shall be entitled to institute protective
legal proceedings for a receivership to preserve and protect their security. In the first
instance, the Agent shall notify the LICENSOR, to assume such receivership and
operate the service, pending the transfer/assignment/endorsement of the LICENCE as
provided herein but in the event LICENSOR declines to assume receivership, the
Lenders shall be entitled to the appointment of a Receiver, with or without the
intervention of the Court, of the Project and the receivables pending the
transfer/assignment/endorsement of the LICENCE in accordance with this
AGREEMENT by the LINCENSOR. The receivership shall be co-terminus with the
transfer/assignment/endorsement of the LICENCE to a Selectee. The Receiver shall
be responsible for protecting the assets in receivership and rendering a true and proper
account of the receivership to the Agent in accordance with the terms of its
appointment. The Receiver shall make best efforts to protect the subscriber base of the
Network and continue the Service, in accordance with the LICENCE obligations.
Such a Receiver can be appointed by consent of the LICENSOR and the Lenders as
herein contained, or in a legal proceeding for appointment of a Receiver,
notwithstanding that no recovery or mortgage suit or any suit or proceeding for
enforcement of the Lenders’ Security is instituted by the Lenders. Such an action for
appointment of the Receiver or Court Receiver as above shall be without prejudice to
the other rights and remedies of the Lenders under the Loan Agreements.

- 50 -

<!-- page 51 -->

ARTICLE – 5
TERMINATION OF THE LICENCE BY THE LICENSOR
If under the LICENCE AGREEMENT, an event occurs which shall entitle the LICENSOR to
terminate the LICENCE AGREEMENT, the LICENSOR shall intimate the Agent
prior to exercising of its decision to terminate the LICENCE, and on such intimation
the Lenders if so decide may cure such events within a period of 30 days from the
date of the notice received from the LICENSOR failing which the LICENSOR
without any further notice to either the LICENSEE or the Agent be entitled to
terminate the LICENCE AGREEMENT, subject to Lenders’ right to receive
compensation (after setting off LICENSOR’s dues if any).
Upon receipt of the Notice as referred to in Article 5.1, intimating occurrence of an event
which can entail termination of LICENCE, the Agent shall take immediate steps to
consider such a notice as an Event of Default and may initiate steps to invite,
negotiate and procure offers for the take over and transfer of the Project of the
LICENSEE by a prospective Selectee in accordance with the procedure as provided in
Articles 2 and 3 hereinabove.

ARTILCE – 6
LENDERS’ RIGHT TO COMPENSATION
The LICENSEE hereby expressly authorizes payment of such compensation to the Lenders,
notwithstanding the pendency of any dispute or objection or claim that the
LICENSEE may have against the Lenders/LICENSOR. The payment of
compensation to the Lenders directly in accordance with this Article, made or caused
to be made by the LICENSOR shall constitute a valid discharge of the LICENSEE to
the extent of such payment received by the Lenders. All such payments shall be in
favour of and shall be receivable by the Lenders to the exclusion of any receiver or
Liquidator appointed for the assets of the LICENSEE.
6.2

The LICENSEE shall be entitled to receive any balance amount of the compensation
after the dues of the LICENSOR, and the Lenders and other direct Fees or charges
connected with the transfer of network of the LICENSEE to the Selectee, having been
paid therefrom.

- 51 -

<!-- page 52 -->

ARTICLE – 7
GENERAL
The parties hereto expressly represent and warrant that they are duly empowered to sign and
execute this Tripartite AGREEMENT and the agent is fully authorized by Members
of the Lender’s Consortium to enter into this Tripartite AGREEMENT for and on
their behalf.
Notices under the AGREEMENT shall be sent to the Addresses first hereinabove mentioned.
Any change in the address of any Party shall be duly notified by a Registered post
acknowledgement due and delivered to the other parties.
The expressions “the LICENSOR” and “THE LICENSEE” and “the Lenders” and “The
Agent” herein before used shall unless there be anything repugnant to the subject or
context include their respective replacements, successors, legal representatives,
administrators and permitted assigns.
This AGREEMENT shall not be affected by reorganization of any Lender or Agent and the
successor - in - interest of such Lender or Agent, shall have the benefit of this
AGREEMENT.
Any variation or modification to this AGREEMENT shall take effect when such variation or
modification is made in writing under the signatures of the concerned parties.
The LICENSEE shall be bound to pay all Stamp Duty or other imposts, costs, charges and
expenses as are applicable on this AGREEMENT or on any deed of assignment or
transfer of the project and in the event of the Lenders making such payment for the
time being, such payment shall be deemed to be a part of the Lenders’ Dues.
The parties hereby expressly agree that for the purpose of giving full and proper effect to this
AGREEMENT, the LICENCE AGREEMENT and this AGREEMENT shall be read
together and construed harmoniously.
The consultation, recommendation or approval of the Agent under this AGREEMENT shall
always be taken as a consultation, recommendation or approval of every concerned
Lender.
Notwithstanding anything contained in this AGREEMENT, the rights and remedies available
to the LICENSOR under LICENCE AGREEMENT and Interconnect AGREEMENT
respectively, shall remain protected and unaffected.
It shall not be necessary for the Lenders to enforce or exhaust any other remedy available to
them before invoking the provisions of this AGREEMENT.
(i) Any dispute, difference or claim arising out of or in connection with or in relation to this
AGREEMENT shall be decided by arbitration and shall be subject to the provisions
of the Arbitration and Conciliation Act, 1996 ( of India), or any modification or reenactment thereof and be governed by the laws of India. The venue for arbitration
shall be New Delhi and the Courts in New Delhi shall alone have jurisdiction in

- 52 -

<!-- page 53 -->

matters arising out of such arbitration AGREENEBT or award or protection of
property or assets of the project.
(ii) Before resorting to arbitration, the parties shall attempt to settle in good faith any
dispute, difference or claim referred to above, by negotiation between them and in the
event of failure of such negotiation, the arbitration shall be resorted to.
(iii) Each party to the dispute, difference or claim shall appoint one arbitrator and the
arbitral tribunal thus appointed shall make the award within 30 days after appointment
of the last arbitrator. In case the arbitrators thus appointed are of even number then
such appointed arbitrators shall choose another arbitrator with mutual consent who
will act as the presiding arbitrator of the arbitral tribunal.

- 53 -

<!-- page 54 -->

SCHEDULE
LIST OF LENDERS AND PARTICULARS OF LOANS
A List of Lenders and Loan Amounts/Financial Assistance
NAME OF LENDERS

B.

AMOUNT OF LOAN

DATE OF LOAN
AGREEMENT

Particulars of Syndication/Participation in the Loans.

C.

IN WITNESS WHEREOF, THE PARTIES HERETO HAVE SET THEIR HANDS AND
SEAL ON THE DATE, MONTH AND YEAR HEREINABOVE MENTIONED.
SIGNED, SEALED AND DELIVERED FOR AND ON BEHALF OF THE PRESIDENT OF
INDIA BY:
ASSISTANT DIRECTOR GENERAL (LR-V)
IN PRESENCE OF

- 54 -

<!-- page 55 -->

AND
SIGNED AND DELIVERED BY SHRI
----------------------- , CONSTITUTED ATTORNEY
DULY AUTHORISED OFFICER OF ---------------------------FOR AND ON BEHALF OF --------------------------------------ACTING FOR ITSELF & AS AGENT FOR OTHER LENDERS,
IN PRESENCE OF
AND
(

)

THE COMMON SEAL OF -------------------------------------------------LIMITED HAS PURSUANT TO THE
RESOLUTION OF ITS BOARD OF
DIRECTORS PASSED IN THAT
BEHALF ON THE --------------------------------- DAY OF ---------------------,
HEREUNTO BEEN AFFIXED IN THE
PRESENCE OF SHRI -------------------------------------------AND SHRI -------------------------- WHO HAS/HAVE
SIGNED/COUNTERSIGNED THESE
PRESENTS IN TOKEN THEREOF.

- 55 -
