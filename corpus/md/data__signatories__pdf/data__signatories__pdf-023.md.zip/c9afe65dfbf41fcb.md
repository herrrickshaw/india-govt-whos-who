---
doc_id: "c9afe65dfbf41fcb"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/6de6f1ec67b310339ae8c9a0ce643398.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Deployment of ITS officers in BSNL."
date: "2015-08-24"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a3163339bb61c809"
---

<!-- page 1 -->

No. A-11013/7/2013-Abs. Cell
Government of India
Ministry of Communications & Information Technology
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi-110001
Dated: 24th August, 2015
ORDER

Subject: Deployment of ITS officers in BSNL.

Vide order No. A-11013/7/2013-Abs. Cell dated 21.08.2015 issued by
Department of Telecommunications, Shri Sanjay Ghosh, an officer of JAG of Indian
Telecom Service (ITS) (Staff No. 20842) has been deployed in Bharat Sanchar Nigam
Limited (BSNL) with immediate effect and until further orders. Shri Sanjay Ghosh has
been directed to report to CCA, Kolkata for relieving.
2.
In partial modification of the above order dated 21.08.2015, Shri Sanjay Ghosh is
now directed to report to CCA, Guwahati for relieving.

3.

All other contents of the above mentioned order dated 21.08.2015 will remain the

same.

(Bire~tap)

Deputy Secretary (BP)
Tel: 011-23036032, 23712262
FAX: 01123372648
Email: birendra.pratap@nic.in
To
1.
2.
3.

CMD, BSNL
DDG (Estt), DoT
Officers concerned (Through CCA, Guwahati)

Copy for information to:­
(i)
(ii)
(iii)
(iv)
(v)
(vi)

PS to Hon'ble MoC&IT
PPS to Secretary, DoT
PPS to Member (Services)/Member(Finance)/Member (Technology)
Administrator, USO Fund
PPS to JS (T), DoT
PPS to JS (A), DoT

<!-- page 2 -->

: 2:
No. A-11013/7/2013-Abs. Cell

Dated: the 24th August, 2015

Copy also for information and necessary action to­
1.

Controller of Communication Accounts
Assam Telecom Circle
5th Floor, BSNL Bhawan, Pan Bazar,
Guwahati-781001

2.

Controller of Communication Accounts
Kolkata Phones Telecom Circle
8, Hara Street, 2nd Floor
Kolkata-700001

(Biren~p)

Deputy Secretary (BP)
Tel: 011-23036032, 23712262
FAX: 01123372648
Email: birendra.pratap@nic.in
