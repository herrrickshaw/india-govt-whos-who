---
doc_id: "ad0ed6e8ea3cda28"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/a708cf5c46ae71e49572ffbdc59a367d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Signing of Licence Agreements for Mobile Number Portability (MNP) Service"
date: "2009-04-21"
pages: 63
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "68c02e0f5e760a20"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF COMMUNICATIONS & IT
DEPARTMENT OF TELECOMMUNICATIONS
SANCHAR BHAWAN, 20, ASHOKA ROAD,
NEW DELHI-110 001. INDIA.

LICENCE AGREEMENT
FOR
MOBILE NUMBER PORTABILITY (MNP)
SERVICE

NO. 20-201/2008-AS-I

DATED ________

IN MNP Service Zone -----------

TOTAL PAGES ____________

Draft Licence Agreement for MNP Services – 19.03.2009

Page 1/63

<!-- page 2 -->

LICENCE AGREEMENT
FOR
MOBILE NUMBER PORTABILITY (MNP) SERVICE

This AGREEMENT is made on the _______ day of ____________ (month)
___________ (year) by and between the President of India acting through
Shri__________________
(name), ______________(designation), Department Of
Telecommunications (DOT), Sanchar Bhavan, 20, Ashoka Road, New Delhi – 110 001
(Hereinafter called the LICENSOR) of the FIRST PARTY.
AND
M/s __________________, a company registered under the Companies Act 1956,
having its registered office at ______________________________________________
acting through Shri. _______________________, the authorised signatory (hereinafter
called the LICENSEE which expression shall, unless repugnant to the context, include its
successor in business, administrators, liquidators and assigns or legal representatives) of
the SECOND PARTY.
WHEREAS by virtue of the provisions of Section 4 of the Indian Telegraph Act,
1885, the LICENSOR enjoys exclusive privilege to grant Licence and the LICENSEE
has requested to grant Licence for providing Mobile Number Portability (MNP)
Service in MNP Service Zone ---. Whereupon and in pursuance to the said request, the
LICENSOR has agreed to grant this Licence to provide Mobile Number Portability
(MNP) Service in MNP Service Zone --- as per terms and conditions described in the
SCHEDULE appended hereto.
NOW THIS AGREEMENT WITNESSETH AS FOLLOWS:
1.
In consideration of the payment of Licence fee, and due performance of all the
terms and conditions mentioned in this Licence agreement on the part of the LICENSEE,
the LICENSOR does, hereby grant under Section.4 of the Indian Telegraph Act, 1885 to
set up and operate the Mobile Number Portability (MNP) Service in the licensed
MNP service zone as described in SCHEDULE appended hereto.
2.
This LICENCE shall be valid for a period of 10 years from the effective date
unless revoked earlier for reasons as specified elsewhere in the document.
3.
The LICENSEE hereby agrees and unequivocally undertakes to fully comply with
all terms and conditions stipulated in this Licence Agreement and without any deviation
or reservations of any kind.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 2/63

<!-- page 3 -->

4.

Effective Date of this LICENCE shall be ……………….

5.
Additional Licences in LICENSEE’s MNP Service Zone may also be issued from
time to time in future without any restriction of number of operators with same entry
conditions or different entry conditions as described in SCHEDULE appended hereto.
6.
The Licence shall be governed by the provision of Indian Telegraph Act, 1885,
Indian Wireless Telegraphy Act, 1933, Telecom Regulatory Authority of India Act, 1997
and Information Technology Act, 2000 as amended from time to time.
IN WITNESS WHEREOF the parties hereto have caused this Agreement to be
executed through their respective authorised representatives on the _________(day)
__________(month), ______(year).
Signed for and on behalf of
President of India

Signed on __/___/_____, on
Behalf of
M/s.______________________

By

By

Mr._____________________
(Name and Designation),

Mr._______________________
(Name and Designation),
Authorised signatory and holder of General
Power of Attorney dated______, executed in
accordance with the Resolution No.
_____________, dated ____ passed by the
Board of Directors.

In the presence of:
Witnesses:
1. Signature
Name
Occupation.

Address

Place.

2. Signature
Name
Occupation.

Address

Place.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 3/63

<!-- page 4 -->

TABLE OF CONTENTS
Page No.
Schedule-

:Terms and Conditions

6

Part I

: General Conditions

6

Condition 1 to 10:
Part II

Part III

Part IV

General Conditions

6

Commercial Conditions

8

Condition 11: Ownership of the LICENSEE Company
Condition 12: Scope of the Licence
Condition 13: Duration of Licence
Condition 14: Extension of Licence
Condition 15: Modifications in the Terms and
Conditions of Licence
Condition1 6: Restrictions on ‘Transfer of Licence’
Condition 17: Provision of Service
Condition 18: Delivery of Service
Condition 19: Tariffs
Condition 20: Requirement to furnish information
Condition 21: Suspension, revocation or Termination
of Licence
Condition 22: Actions pursuant to Termination of Licence
Condition 23: Force-Majeure
Condition 24: SET Off Clause

8
10
11
11

Financial Conditions

17

Condition 25: Fees payable
Condition 26: Definition of ‘Adjusted Gross Revenue
Condition 27: Schedule of payment of ANNUAL
LICENCE FEE and other dues
Condition 28: Bank Guarantees
Condition 29: Preparation of Accounts.

17
17
17

Technical Conditions

22

Condition 30: Technical Condition
Condition 31: Technical Requirements
Condition 32: Acceptance Testing
Condition 33: Activities at the Licensee Company’s end
Condition 34: Broad Guidelines of duties and responsibilities

22
26
30
30

of MNP Service Provider
Condition 35: The Applicable system
Draft Licence Agreement for MNP Services – 19.03.2009

11
11
12
12
12
13
13
15
15
16

19
20

31
38
Page 4/63

<!-- page 5 -->

Part V

Part VI

Condition 36: Engineering Details
Condition 37: Network Interconnection
Condition 38: Interface
Condition 39: Quality of Service

38
39
39
40

Operating Conditions

41

Condition 40: Customer Service
Condition 41: Roll-out Obligations
Condition 42: Liquidated damages
Condition 43: Obligations imposed on the LICENSEE
Condition 44: Inspection and Testing of Installations.

41
41
41
42
42

Security Conditions

43

Condition 45: Right to inspect
Condition 46: Location of MNP Systems
Condition 47: Confidentiality of information
Condition 48: Prohibition of certain Activities by
the LICENSEE
Condition 49: Information on Ported Numbers to
Security Agencies
Condition 50: Security Conditions
Condition 51: Application of Indian Telegraph Act

43
43
43
44
45
45
48

ANNEXURES
Annexure-I

Glossary and Definition of Terms and Expressions

49

Annexure-II

Performa for Affidavit regarding details of calculation
of ‘Revenue’ and ‘Licence Fee’

52

Appendix - I to Annexure-II: Format of Auditors’ Report

53

Appendix - II to Annexure-II: Format of Statement of Revenue and License fee

54

Annexure-III

Norms for preparation of Annual Financial Statement

56

Annexure- IV

Performa for Financial Bank Guarantee

57

Annexure- V

Performa for Performance Bank Guarantee

59

Annexure- VI

MNP Service Zone(s)

61

Annexure- VII

Details of Licenced Service Area in the Country
under UASL / CMTS Licence

62

Draft Licence Agreement for MNP Services – 19.03.2009

Page 5/63

<!-- page 6 -->

SCHEDULE
TERMS AND CONDITIONS
Part-I GENERAL CONDITIONS
General Conditions
1.
Mobile Number Portability (MNP) allows subscribers to retain their existing
telephone number when they switch from one access service provider to another
irrespective of mobile technology or from one technology to another of the same or any
other access service provider.
2.
Presently, the country is divided into 22 Licensed Service Areas (LSAs)
(Annexure-VII) as defined in Unified Access Services (UAS) Licence guidelines dated
14-12-2005. For the purpose of grant of Licence(s) for MNP Services in India, the whole
country is divided into 2 MNP zones as per details in Annexure-VI.
It may be noted that there are certain CMTS/ UAS licences which are operating
either in Tamil Nadu (excluding Chennai), and/or Chennai or Tamil Nadu (including
Chennai) service area. A list of CMTS / UAS Licensee as on 28.02.2009 is available on
DoT website. Any further UAS licence granted after 28.02.2009 and in future shall also
be covered for MNP implementation as per existing policy of the Government.
3.
The Licensee shall have exclusive right to provide MNP solution in the licensed
MNP zone for a period of five(5) years from the effective date of licence and no MNP
licensee shall be inducted during this period in the said MNP Zone:
Provided that if the Licensee fails to perform in accordance with the Service Level
Agreements (SLAs) specified by the TRAI during this period, the Licensor, on the
recommendations of TRAI made by it either suo-moto or on the request of Licensor, may
induct MNP service licensee(s) ;
Provided further that the Licensor reserves its right to review this condition in the
interests of public and national security;
Provided further that pilot project for MNP may be approved and licensed for any period
by the Licensor for inducting a new Technology.
4.
The licensee will operate the MNP system based on ‘build, operate and owned
basis’. It shall take into account traffic study, services to be given, etc. for dimensioning
of its Mobile Number Portability Clearing House (MCH), Number Portability Data Base
(NPDB) and database query response system. The licensee company shall arrange all
those equipments and solutions (including tools and testers etc.) from time to time which
may be required for efficient working.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 6/63

<!-- page 7 -->

5.
The Licensee shall incur all the capital expenditure and operational
expenditures. It may be noted that the system will need to cater to mobile number
portability requirement for whole of the licensed MNP zone in a phased manner.
6.
LICENSEE shall be solely responsible for installation, networking and
operation of necessary equipment and systems for provision of SERVICE, treatment of
telecom operators complaints, issue of bills to the UAS/CMTS licensees of its MNP
zone, collection of its component of revenue, attending to claims and damages arising out
of his operations.
7.
LICENSEE shall be solely responsible for successful implementation/ operation
of MNP services and to resolve the issues of interconnections/ interfaces in respect of
present networks/services as well as future networks/services of the Basic, CMTS, UAS,
NLD and ILD operators at its own cost. However, the costs of upgradation, operation and
maintenance of network of Telecom Service Providers to support MNP in its network
shall be borne by the respective telecom service providers.
8.
The Licensee shall comply with all the terms and conditions of this Licence
Agreement as well as the orders, directions, determinations or regulations as may be
issued from time to time by the Licensor or TRAI as the case may be.
9.
The Licensee shall also be bound by all the terms & conditions of the tender
document no. 20-201/2008-AS-I dated 25.11.2008 and Comprehensive Clarifications/
Amendments of the tender document vide letter no. 20-201/2008-AS-I dated 22.01.2009,
unless otherwise amended by the Licensor.
10.
The Statutory provisions and the rules made under Indian Telegraph Act 1885,
Indian Wireless Telegraphy Act, 1933, Telecom Regulatory Authority of India Act, 1997
and Information Technology Act, 2000 shall govern this Licence agreement. Any order
passed under the statute(s) shall be binding on the licensee.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 7/63

<!-- page 8 -->

PART-II COMMERCIAL CONDITIONS

11.
11.1

Ownership of the LICENSEE Company:
Foreign Equity: The total foreign equity (directly and indirectly) in the paid up
equity capital of the LICENSEE Company shall not, at any time, exceed 74% of
the total equity subject to the following FDI norms :
(A)

Both direct and indirect foreign investment in the LICENSEE company
shall be counted for the purpose of FDI ceiling. Foreign Investment shall
include investment by Foreign Institutional Investors (FIIs), Non-resident
Indians (NRIs), Foreign Currency Convertible Bonds (FCCBs), American
Depository Receipts (ADRs), Global Depository Receipts (GDRs) and
convertible preference shares held by foreign entity. Indirect foreign
investment shall mean foreign investment in the company/ companies
holding shares of the LICENSEE company and their holding
company/companies or legal entity (such as mutual funds, trusts) on
proportionate basis. Shares of the licensee company held by Indian public
sector banks and Indian public sector financial institutions will be treated
as `Indian holding’. In any case, the `Indian’ shareholding will not be less
than 26 percent.

(B)

FDI up to 49 percent will continue to be on the automatic route. FDI in
the LICENSEE company/Indian promoters/investment companies
including their holding companies shall require approval of the Foreign
Investment Promotion Board (FIPB) if it has a bearing on the overall
ceiling of 74 percent. While approving the investment proposals, FIPB
shall take note that investment is not coming from countries of concern
and/or unfriendly entities.

(C)

Foreign Direct Investment (FDI) shall be subject to extant guidelines and
regulations. However, equity of the foreign partner in the Licensee
company should not be less than 26%.

11.2

The LICENSEE shall declare the Indian & Foreign equity holdings (both direct
and in-direct) in the LICENSEE company and submit a compliance report
regarding compliance of FDI norms and security conditions on 1st day of January
and 1st day of July on six monthly basis to the LICENSOR. This is to be certified
by the LICENSEE Company’s Company Secretary or Statutory Auditor.

11.3

Management control of the LICENSEE Company shall remain in Indian Hands.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 8/63

<!-- page 9 -->

11.4

11.4A

The LICENSEE shall also ensure that:
(i)

No telecom access service provider licensee company (Basic service, UAS
and/or CMTS) granted licence under Indian Telegraph Act, 1885 shall
hold any equity, directly or indirectly, in the bidder Company. Further, the
bidder shall also not likewise hold any equity, in any of such licensed
telecom access service providers – licensee companies.

(ii)

No MNP Licensee and their shareholders, either directly or indirectly,
shall have any substantial equity share holding (SEH) in more than one
MNP Licensee Company. ‘Substantial equity share holding (SEH) herein
will mean ‘an equity of 10% or more’.
The Licensor may relax condition prescribed in clause 11.4(ii) in case the
MNP service licence in the other MNP service zone has been terminated.

11.5

Change in the name of the LICENSEE Company shall be permitted in accordance
with the provisions under the Indian Companies Act, 1956.

11.6

Following equity holder(s) of the licensee company whose experience has been
taken into account for fulfilling the eligibility conditions and evaluation purpose,
shall not be allowed to dilute their equity shareholding in the licensee Company
below 26% equity share capital for at least four years from the date of submission
of bid i.e. 06.02.2009:
(i)
-----------------------------------------------------------(ii)
-----------------------------------------------------------(iii) ------------------------------------------------------------

11.7

Any changes in share holding shall be subject to all applicable statutory
permissions and conditions of the Licence agreement.

11.8

The merger/ acquisition of Indian companies may be permitted as long as
competition is not compromised as defined in condition 11.4 and the resultant
entity should remain compliant to the terms & conditions of this licence
agreement.

11.9

The Licensee Company shall maintain a minimum paid up capital of an amount
Rs. 10 Crores during the currency of the licence.

11.10 The licensee Company and equity holders in the Licensee Company shall
maintain a combined net-worth of atleast Rs. 100 Crores during the currency of
the licence.
The net worth of only those Equity Share Holders shall be counted, who have
26% or more equity in the Licensee company, in the proportion of their direct
equity. Any indirect equity held in the Licensee company shall not be counted for

Draft Licence Agreement for MNP Services – 19.03.2009

Page 9/63

<!-- page 10 -->

this purpose. Here the net worth shall mean the sum total, in Indian rupees, of
paid up equity capital and free reserves. While counting Net-worth, the foreign
currency shall be converted into Indian Rupees at the prevalent rate indicated by
the Reserve Bank of India.
12.

Scope of the Licence

12.1 The licensee shall be permitted to provide, Mobile Number Portability (MNP)
services in the licensed MNP zone, confirming to centralized All Call Query method that
meets the relevant International Telecommunication Union (ITU)/Telecommunication
Engineering Center (TEC) of DoT’s Technical and Performance standards as applicable.
12.2
The LICENSEE shall clearly define the scope of Service to the Telecom Access
Services and NLD/ILD operators at the time of entering into contract with such service
providers while entering into agreement with them for providing MNP.
12.3 Licensee shall make its own arrangements for all infrastructure involved in
providing the service and shall be solely responsible for installation, networking and
operation of necessary equipment and systems, treatment of subscriber complaints, issue
of bills to Access Service Providers, collection of revenue, attending to claims and
damages arising out of his operations.
12.4 The licensee shall establish, administer and operate the Mobile Number
Portability centralized clearing house (herein after called MCH) and logically centralized
Number Portability DataBase (herein after called ‘NPDB’) for implementation of mobile
number portability in the licensed MNP zone in accordance with QoS parameters,
defined criteria/ benchmarks, SLAs and other parameters including tariffs, as prescribed
by TRAI/DoT from time to time.
12.5 The MCH and NPDB established by the licensee shall be used by all
telecommunication service providers (both existing & new) (i.e. Basic, CMTS, UAS,
NLD and ILD Licensee(s)) of the licensed MNP zone for the purpose of supporting
porting of mobile numbers between mobile operators. As part of this activity, the
Applicable System of Licensee shall contain the updated porting information which will
be used by the telecommunication service providers for the purpose of routing calls to the
ported end-users.
12.6 The Licensee company will operate the MNP system based on ‘build, operate and
owned basis’. It shall take into account traffic study, services to be given, etc. for
dimensioning of its MCH, NPDB and database query response system. The Company
shall arrange all those equipments (tools and testers etc.) which may be required for
efficient working of the network from time to time.
12.7 The Licensee cannot provide any service except as mentioned above and which
otherwise shall require a separate licence.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 10/63

<!-- page 11 -->

12.8 The LICENSEE is permitted to provide, SERVICE by
utilizing any type of
network equipment, including circuit and/or packet switches, that meet the relevant
International Telecommunication Union (ITU)/Telecommunication Engineering Center
(TEC) / International standardization bodies as applicable.
12.9 It is obligatory upon the LICENSEE to provide the above stated services of good
standard by establishing a state-of-the-art digital network.
12.10 Any dispute, with regard to provision of SERVICE shall be a matter only between
the aggrieved party and the LICENSEE, who shall duly notify this to all before providing
the SERVICE, and in no case the LICENSOR shall bear any liability or responsibility.
The licensee shall keep the Licensor indemnified from all claims, cost, charges or
damages in the matter.
13.

Duration of Licence

13.1 This LICENCE shall be valid for a period of 10 years from the effective date
unless revoked earlier for reasons as specified elsewhere in the document.
14.

Extension of Licence

14.1 The LICENSOR may extend, if deemed expedient, the period of LICENCE by 10
years at one time, upon request of the LICENSEE, if made during 9th year of the Licence
period on terms mutually agreed. The decision of the LICENSOR shall be final in regard
to the grant of extension.
15.

Modifications in the Terms and Conditions of Licence

15.1 The LICENSOR reserves the right to modify at any time the terms and conditions
of the LICENCE, if in the opinion of the LICENSOR it is necessary or expedient to do so
in public interest or in the interest of the security of the State or for the proper conduct of
the SERVICE. The decision of the LICENSOR shall be final in this regard.
16.

Restrictions on ‘Transfer of Licence’

16.1 The LICENSEE shall not, without prior written consent as described below, of the
LICENSOR, either directly or indirectly, assign or transfer this LICENCE in any manner
whatsoever to a third party or enter into any agreement for sub-Licence and/or
partnership relating to any subject matter of the LICENCE to any third party either in
whole or in part.
Provided that the Licensee may transfer or assign the License Agreement with
prior written approval of the Licensor to be granted on fulfillment of the following
conditions:-

Draft Licence Agreement for MNP Services – 19.03.2009

Page 11/63

<!-- page 12 -->

(i)
Whenever amalgamation or restructuring i.e. merger or demerger is sanctioned
and approved by the High Court or Tribunal as per the law in force; in accordance with
the provisions; more particularly Sections 391 to 394 of Companies Act, 1956;
(ii)
The transferee/assignee is fully eligible in accordance with eligibility criteria
contained in license agreement conditions and show its willingness in writing to comply
with the terms and conditions of the license agreement including past and future roll out
obligations; and
(iii) All the past dues are fully paid till the date of transfer/assignment by the
transferor company or its holding company or any of its subsidiary company; and the
transferee company undertakes to pay all future dues inclusive of anything remaining
unpaid for the past period of the transferor company.
17.

Provision of Service

17.1 The LICENSEE shall be responsible for, and is authorised to own, install, test and
commission all the equipment to commission the Applicable system for providing the
MNP Service under the Licence agreement.
17.2 The LICENSEE shall be permitted to interconnect with Telecom Service
Providers (i.e Basic, CMTS, UAS,NLD and ILD licensee(s)) as mandated by the TRAI/
Licensor.
18.

Delivery of Service

18.1 MNP is to be implemented in each intra Licensed Service Area (LSA). Initially
MNP is to be implemented in all Metro and Category ‘A’ service areas within 6 month of
award of the Licence. Later on, the operation of MNP will be expanded in the rest of the
respective zones in time bound manner in phases. The total MNP implementation in each
zone in the country shall be completed within 1 year of award of the Licence in
respective zones.
18.2 The date of Test Certificate, issued by Telecom Engineering Centre (TEC) of
DOT or any other organization authorised by Licensor in this regard, will be reckoned as
the date of commissioning the service for the purpose of calculating liquidated damage
charges in terms of condition 42.
19.

Tariff

19.1 The per port transaction fees shall be as per TRAI’s regulation /direction/orders
for Mobile Number Portability from time to time.
19.2 The LICENSEE will charge the UAS/CMTS Licensees per port transaction fees
as per regulation/ direction/ orders of TRAI. The LICENSEE shall also fulfill
requirements regarding publication of tariffs, notifications and provision of information

Draft Licence Agreement for MNP Services – 19.03.2009

Page 12/63

<!-- page 13 -->

as directed by TRAI through its orders / regulations / directions issued from time to time
as per the provisions of TRAI Act, 1997 as amended from time to time.
20.

Requirement to furnish information

20.1 The Licensee shall furnish to the Licensor, on demand in the manner and as per
the time frames such documents, accounts, estimates, returns, reports or other
information in accordance with the rules/ orders as may be prescribed from time to time.
The LICENSEE shall also submit information to TRAI as per any order or direction or
regulation issued from time to time under the provisions of TRAI Act, 1997 or an
amended or modified statute.
20.2 The LICENSOR reserves right to seek complete information from the LICENSEE
of terms and conditions, and obligations under all contracts entered into with other
UASPs/CMSPs and other Licensed Telecom Service Providers on provisioning of MNP
service/ sharing of infrastructure / backbone for the provision of SERVICE, or any
change thereof and to obtain the authenticated copies of all such contracts.
20.3 The LICENSEE shall in no case provide MNP service to any Telecom Service
Provider whose licence is either terminated or suspended or not in operation at any point
of time but shall continue to maintain Data Base and provide MNP service to their
subscribers. The Licensee shall keep the LICENSOR indemnified from any claim arising
out of such Telecom Service Provider or third party.
21.

Suspension, Revocation or Termination of Licence

21.1 The LICENSOR reserves the right to suspend the operation of this LICENCE in
whole or in part, at any time, if, in the opinion of the LICENSOR, it is necessary or
expedient to do so in public interest or in the interest of the security of the State or for the
proper conduct of the SERVICE. Licence Fee payable to the LICENSOR will not be
required to be paid for the period for which the operation of this LICENCE remains
suspended in whole.
Provided that the LICENSOR shall not be responsible for any damage or loss
caused or arisen out of aforesaid action. Provided further that the suspension of the
LICENCE will not be a cause or ground for extension of the period of the LICENCE and
suspension period will be taken as period spent.
21.2 (i) The LICENSOR may, without prejudice to any other remedy available for the
breach of any conditions of LICENCE, by a written notice of 60 Calendar days issued to
the LICENSEE at its registered office, terminate the LICENCE under any of the
following circumstances:
IF THE LICENSEE:

Draft Licence Agreement for MNP Services – 19.03.2009

Page 13/63

<!-- page 14 -->

a)
b)
c)
d)
e)
f)
g)

fails to perform any obligation(s) under the LICENCE including timely
payments of fee and other charges due to the LICENSOR;
fails to rectify, within the time prescribed, any defect as may be pointed
out by the LICENSOR.
goes into liquidation or ordered to be wound up.
is recommended by TRAI for termination of LICENCE for noncompliance of the terms and conditions of the LICENCE.
fails to comply with FDI norms.
fails to comply with conditions of the licence.
fails to fulfil roll out obligation in the first phase or subsequent phase.

21.2 (ii) The Licensor reserves a right to impose a financial penalty not exceeding
Rs. 1 crore for violation of terms and conditions of licence agreement. The penalty shall
commensurate with the seriousness of the violations and will be recommended by a
Committee constituted in DOT. This penalty is exclusive of Liquidated Damages as
prescribed under condition 42 of this Licence Agreement.
21.3 LICENSEE may surrender the LICENCE, by giving notice of at least 60 calendar
days in advance. In that case it shall also notify all Access/NLD/ILD Service Providers
its customer of consequential withdrawal of SERVICE by sending a 30 calendar days
notice to each of them. The LICENSEE shall pay all fees payable by it till the date on
which the surrender of the licence becomes effective. The effective date of surrender of
LICENCE will be 60 calendar days counted from the date of receipt of such notice by
the licensor.
21.4 It shall be the responsibility of the LICENSEE to maintain the quality of service
even during the period when notice for surrender of LICENCE is pending and if the
quality of service is not maintained during the said notice period, it shall be treated as
material breach liable for termination at risk and consequence of the licensee including
forfeiture of Performance Bank Guarantee (PBG). The licensee shall also be liable to pay
the licence fee till the end of the notice period and more specifically till the date on which
the surrender/termination becomes effective.
21.5 The LICENSOR reserves the right to revoke the LICENCE at any time in the
interest of public by giving a notice of 60 calendar days from the date of issue of such
notice.
21.6 The LICENSOR reserves the right to take over the entire services, equipments
and networks of the LICENSEE or revoke/terminate/suspend the LICENCE in the
interest of public or national security or in the event of national emergency/war or low
intensity conflict or similar type of situations. Further the LICENSOR reserves the right
to keep any area out of the operation zone of the SERVICE if implications of security so
require.
21.7 Breach of non-fulfillment of Licence conditions may come to the notice of the
LICENSOR through complaints or as a result of the regular monitoring. Wherever

Draft Licence Agreement for MNP Services – 19.03.2009

Page 14/63

<!-- page 15 -->

considered appropriate LICENSOR/TRAI may conduct an inquiry either suo-moto or on
complaint to determine whether there has been any breach in compliance of the terms and
conditions of the LICENCE by the LICENSEE and upon such inquiry the LICENSEE
shall extend all reasonable facilities and shall endeavor to remove the hindrances of every
type.
22.

Actions pursuant to Termination of Licence

22.1 If under the Licence Agreement, material event occurs which entitle the
LICENSOR to terminate the Licence Agreement, the action will be taken as per the
condition below.
22.2 On termination or surrender or expiry of the LICENCE, the Bank Guarantee shall
be released to the LICENSEE only after ensuring clearance of all dues which the
LICENSEE is liable to pay to the licensor. In case of failure of the LICENSEE to pay the
amounts due to the LICENSOR, the outstanding amounts shall be realised through
encashment of the Bank Guarantee(s) without prejudice to any other action(s) for
recovery of the amounts due to the LICENSOR without any further communication to the
Licensee.
22.3 If the company fails to roll out the first phase services in six months from the
effective date of licence, then the licence may be terminated and the MNP licence for this
zone may be given to operator in the other zone.
22.4 In the event of termination of MNP licence for any reason as per conditions of the
licence, the MNP zone so falling vacant may be allotted to the MNP service licensee in
the other zone.
23.

FORCE- MAJEURE

23.1 If at any time, during the continuance of this LICENCE, the performance in
whole or in part, by either party, of any obligation under this is prevented or delayed, by
reason of war, or hostility, acts of the public enemy, civic commotion, sabotage, Act of
State or direction from Statutory Authority, explosion, epidemic, quarantine restriction,
strikes and lockouts (as are not limited to the establishments and facilities of the
LICENSEE), fire, floods, natural calamities or any act of GOD (hereinafter referred to as
EVENT), provided notice of happenings of any such EVENT is given by the affected
party to the other, within 21 Calendar days from the date of occurrence thereof, neither
party shall, by reason of such event, be entitled to terminate the LICENCE, nor shall
either party have any such claims for damages against the other, in respect of such nonperformance or delay in performance. Provided SERVICE under the LICENCE shall be
resumed as soon as practicable, after such EVENT comes to an end or ceases to exist.
The decision of the LICENSOR as to whether the service may be so resumed (and the
time frame within which the service may be resumed) or not, shall be final and
conclusive.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 15/63

<!-- page 16 -->

23.2 However, the Force Majeure events noted above will not in any way cause
extension in the period of the LICENCE.
23.3 While it will normally not be a ground for non-payment of Licence Fee, the
liability for payment of Licence fee for such inoperative period(s) due to force majeure
clause may, however, be reduced/waived by the LICENSOR, at its discretion based on
circumstances of the EVENT.
24.

SET OFF CLAUSE

24.1 In the event any sum of money or claim becomes recoverable from or payable by
LICENSEE to the LICENSOR either against this Licence Agreement or otherwise in any
manner, such money or claim can be (without prejudice to any right of set off for counter
claim given or employed by law) deducted or adjusted against any amount or sum of
money then due or which at any time thereafter may become due to the LICENSEE under
this Licence Agreement or any other agreement or contract between the LICENSOR and
the LICENSEE.
24.2 The aforesaid sum of money payable by the LICENSEE Company shall include
any security deposit which can be converted into money.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 16/63

<!-- page 17 -->

PART-III FINANCIAL CONDITIONS
25.

FEES PAYABLE

25.1 Entry Fee: One time, non-refundable, Entry Fee of Rs. 1 (one) Crore has been
paid by the LICENSEE prior to signing of this licence agreement.
25.2 Licence Fees: In addition to the Entry fee described above, the Licensee shall
also pay Licence fee annually @ 1 (one) % of Adjusted Gross Revenue (AGR) of the
licensee Company. There shall be a moratorium of licence fee payment for first two years
from effective date of the licence.
25.3 The Licensor reserves the right to modify the above mentioned Licence Fee at any
time during the currency of the MNP services license.
26.

Definition of ‘Adjusted Gross Revenue’

26.1 Gross Revenue: The Gross Revenue shall be inclusive of revenue from services,
Porting fees, sale proceeds of any software & hardware items, revenue on account of
interest, dividend, capital gains, value added services, supplementary services, access or
interconnection charges, revenue from permissible sharing of infrastructure and any other
miscellaneous revenue etc., without any set-off from related items of expense.
26.2 For the purpose of arriving at the “Adjusted Gross Revenue” the following will be
excluded from the Gross Revenue to arrive at the adjusted gross revenue:
Service Tax on provision of service and Sales Tax actually paid to the
Government; if gross revenue had included the component of Service Tax and
Sales Tax.
27.
DUES

SCHEDULE OF PAYMENT OF ANNUAL LICENCE FEE AND OTHER

27.1 For the purposes of the Licence Fee, the 1st year shall end on 31st March
following the date of end of period of moratorium of payment of Licence fee i.e. first two
years from the effective date of the licence and the Licence fee for the First year shall be
determined on a pro-rata basis for the actual duration of the “year”. From second year
onwards, the year shall be of Twelve English calendar months from 1st of April to the
31st March for payment of Licence Fee.
EXPLANATION: The Licence fee for the first quarter of the first year for the purpose
of licence fee and last quarter of the last year of the Licence will be computed with
reference to the actual number of days after excluding the other quarters, each being of
three months.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 17/63

<!-- page 18 -->

27.2 Licence Fee shall be payable in four quarterly installments during each financial
year (FY). Quarterly installment of licence fee for the first three quarters of a financial
year shall be paid within 15 days of the completion of the relevant quarter. This Fee shall
be paid by the LICENSEE on the basis of actual revenue (on accrual basis) for the
quarter, duly certified with an affidavit (Annexure-II) by a representative of the
LICENSEE, authorized by the Board Resolution coupled with General Power of
Attorney. However, for the last quarter of the financial year, the LICENSEE shall pay
the Licence Fee by 25th March on the basis of expected revenue for the quarter, subject to
a minimum payment equal to the actual revenue share paid for the previous quarter.
27.3 The LICENSEE shall adjust and pay the difference between the payment made
and actual amount duly payable (on accrual basis) for the last quarter of financial year
within 15 days of the end of the quarter.
27.4 The quarterly payment shall be made together with a STATEMENT in the
prescribed form as Appendix-II to Annexure- II, showing the computation of revenue
and Licence fee payable. The aforesaid quarterly STATEMENTS of each year shall be
required to be audited by the Auditors (hereinafter called LICENSEE’S Auditors) of the
LICENSEE appointed under Section 224 of the Companies’ Act, 1956. The report of the
Auditor should be in prescribed form as Appendix-I to Annexure-II.
27.5 Any delay in payment of Licence Fee payable, or any other dues payable under
the LICENCE beyond the stipulated period will attract interest at a rate which will be 2%
above the Prime Lending Rate (PLR) of State Bank of India existing as on the beginning
of the Financial Year (namely 1st April) in respect of the licence fees pertaining to the
said Financial Year. The interest shall be compounded monthly and a part of the month
shall be reckoned as a full month for the purposes of calculation of interest. A month
shall be reckoned as an English calendar month.
27.6 Final adjustment of the Licence fee for the year shall be made based on the gross
revenue figures duly certified by the AUDITORS of the LICENSEE in accordance with
the provision of Companies’ Act, 1956.
27.7 A reconciliation between the figures appearing in the quarterly statements
submitted in terms of the condition 27.4 of the agreement with those appearing in annual
accounts shall be submitted along with a copy of the published annual accounts audit
report and duly audited quarterly statements, within 7 (seven) Calendar days of the date
of signing of the audit report. The annual financial account and the statement as
prescribed above shall be prepared following the norms as prescribed in Annexure-III.
27.8 In case, the total amount paid as quarterly Licence Fee for the 4 (four) quarters of
the financial year, falls short by more than 10% of the payable Licence Fee, it shall attract
a penalty of 50% of the entire amount of short payment. However, if such short payment
is made good within 60 days from the last day of the financial year, no penalty shall be
imposed. This amount of penalty shall be payable within 15 days of the date of signing

Draft Licence Agreement for MNP Services – 19.03.2009

Page 18/63

<!-- page 19 -->

the audit report on the annual accounts, failing which interest shall be further charged per
terms of Condition 27.5.
27.9 All sums becoming due and payable as mentioned in this Licence Agreement
shall be paid by the LICENSEE through a demand draft or Pay Order payable at New
Delhi, drawn on any Scheduled Bank, in favour of the Pay & Accounts Officer (HQ),
DOT or any other Authority if so designated by LICENSOR.
27.10 The LICENSOR, to ensure proper and correct verification of revenue share paid,
can, if deemed necessary, modify, alter, substitute and amend whatever stated in
Conditions 27.4, 27.7, 27.5 and 27.6 hereinbefore and hereinafter written.
27.11 The LICENSEE shall also separately pay charges for network resources obtained
by the LICENSEE from other licensed service providers. This will be governed by the
determination of TRAI if any.
28.

BANK GUARANTEES:

28.1

Performance Bank Guarantee:

Performance Bank Guarantee (PBG) in prescribed format shall be submitted for
amount equal to Rs. 1 crores valid for two years before signing the Licence Agreement.
On completion of one year of MNP implementation for all the licensed service
areas of the licensed MNP zone, except those specifically restricted by DoT, 50 % of the
PBG amount shall be released while remaining 50% of the PBG shall be released after
the expiry of the license period.
28.2

Financial Bank Guarantee:

The LICENSEE shall submit a Financial Bank Guarantee (FBG), valid for three
year, from any Scheduled Bank or Public Financial Institution duly authorized to issue
such Bank Guarantee, in the prescribed Performa annexed. Initially, the financial bank
guarantee shall be for an amount of Rs. 2 Crore which shall be submitted before signing
the Licence agreement. Subsequently, the amount of FBG shall be equivalent to the
estimated sum payable equivalent to license fee for two quarters and other dues not
otherwise securitised and any additional amount as deemed fit by the Licensor. The
amount of FBG shall be subject to periodic review by the Licensor and shall be renewed
from time to time.
28.3 Initially, the bank guarantees shall be valid for a period of three year and shall be
renewed from time to time. The licensee, on its own, shall extend the validity period of
the bank guarantees for similar terms at least one month prior to date of its expiry without
any demand or notice from the licensor on year to year basis. Any failure to do so, shall
amount to violation of the terms of the licence and entitle the licensor to encash the bank
guarantees and to convert into a cash security without any reference to the licensee at his

Draft Licence Agreement for MNP Services – 19.03.2009

Page 19/63

<!-- page 20 -->

risk and cost. No interest or compensation whatsoever shall be payable by the licensor on
such encashment.
28.4 Without prejudice to its rights of any other remedy, LICENSOR may encash
Bank Guarantee (FBG as well as PBG) in case of any breach in terms & conditions of the
LICENCE by the LICENSEE.
29.

Preparation of Accounts.

29.1 The LICENSEE will draw, keep and furnish independent accounts for the
SERVICE and shall fully comply orders, directions or regulations as may be issued from
time to time by the LICENSOR or TRAI as the case may be.
29.2

The LICENSEE shall be obliged to:
a) Compile and maintain accounting records, sufficient to show and explain its
transactions in respect of each completed quarter of the Licence period or of
such lesser periods as the LICENSOR may specify, fairly presenting the costs
(including capital costs), revenue and financial position of the LICENSEE’s
business under the LICENCE including a reasonable assessment of the assets
employed in and the liabilities attributable to the LICENSEE’s business, as well
as, for the quantification of Revenue or any other purpose.
(b) Procure in respect of each of those accounting statements prepared in respect
of a completed financial year, a report by the LICENSEE’s Auditor in the format
prescribed by the LICENSOR, stating inter-alia whether in his opinion the
statement is adequate for the purpose of this condition and thereafter deliver to the
LICENSOR a copy of each of the accounting statements not later than three
months at the end of the accounting period to which they relate.
c) Send to the LICENSOR a certified statement sworn on an affidavit, by
authorized representative of the company, containing full account of Revenue
earned from the SERVICE for each quarter separately along with the payment for
the following quarter.

29.3

(a)
The LICENSOR or the TRAI, as the case may be, shall have a right to call
for and the LICENSEE shall be obliged to supply and provide for examination
any books of accounts that the LICENSEE may maintain in respect of the
business carried on to provide the service(s) under this Licence at any time
without recording any reasons thereof.
(b)
The LICENSEE shall invariably preserve all billing and all other
accounting records (electronic as well as hard copy) for a period of THREE years
from the date of publishing of duly audited & approved Accounts of the company
and any dereliction thereof shall be treated as a material breach independent of any
other breach, sufficient to give a cause for cancellation of the LICENCE.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 20/63

<!-- page 21 -->

29.4 The records of the LICENSEE will be subject to such scrutiny as may be
prescribed by the LICENSOR so as to facilitate independent verification of the amount
due to the LICENSOR as its share of the revenue.
29.5 The LICENSOR may, on forming an opinion that the statements or accounts
submitted are inaccurate or misleading, order Audit of the accounts of the LICENSEE by
appointing auditor at the cost of the LICENSEE and such auditor(s) shall have the same
powers which the statutory auditors of the company enjoy under Section 227 of the
Companies Act, 1956. The remuneration of the Auditors, as fixed by the LICENSOR,
shall be borne by the LICENSEE.
29.6 The LICENSOR may also get conducted a ‘Special Audit’ of the LICENSEE
company’s accounts/records by “Special Auditors”, the payment for which at a rate as
fixed by the LICENSOR, shall be borne by the LICENSEE. This will be in the nature of
auditing the audit described in condition 29.5 above. The Special Auditors shall also be
provided the same facility and have the same powers as of the companies auditors as
envisaged in the Companies Act, 1956.
29.7 The LICENSEE shall be liable to prepare and furnish the company’s annual
financial accounts according to the accounting principles prescribed and the directions
given by the LICENSOR or the TRAI, as the case may be, from time to time.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 21/63

<!-- page 22 -->

PART-IV
30.
30.1

TECHNICAL CONDITIONS

TECHNICAL CONDITIONS
Components of the proposed MNP Solution
a.
b.
c.
d.
e.
f.
g.
h.
i.
j.
k.
l.

MNP Clearing House (MCH)- Production site
Number Portability Data Base (NPDB)- Production Site
Query Response Database (QRDB)- Production site
MCH- Disaster Recovery site
NPDB- Disaster Recovery site
QRDB- Disaster Recovery site
Storage server
Web server
Report Generation server
O&M server
Others- Routers, switches etc
Local operator DB query response system (To be procured, installed,
operated, maintained by respective telecom service providers in their network)
m. Number Portability operator Gateway (To be procured, installed, operated,
maintained by respective telecom service providers in their network)
30.2

Architecture

30.2.1 The proposed architecture for implementation of MNP shall take in to account the
following:
• Cost Effectiveness
• Scalable and modular architecture
• High Performance –To meet bench marks as mandated by concerned
authority.
• Reliability – The solution shall conform to the reliability standards set by the
DoT/TRAI.
• Disaster Recovery at separate Geographic location(city)
• Support Open standards on interfaces towards telecom service provider ends.
• Security of centralized database
30.3

Solution Guidelines

30.3.1 Establishment, administration and operation of one centralized MNP Clearing
House (MCH) for port ordering, processing, notification and administration of ported
numbers between mobile Operators. The Company shall also establish, administer and
operate an online disaster recovery site of this MCH at a separate geographic site falling
in different seismic zone and with a minimum distance of 500 KM. The MCH will have

Draft Licence Agreement for MNP Services – 19.03.2009

Page 22/63

<!-- page 23 -->

modular architecture with scalability option so as to cater to the requirement of MNP for
the entire MNP Zone in phased manner.
30.3.2 Establishment, administration and operation of Centralized NPDB in the licensed
MNP zone of MCH – for supporting the centralized clearing house operations. The
NPDB will work as a centralized reference database and will be the repository of all
ported numbers in the respective MNP Zone. This database will be partitioned based on
the service areas as defined by DoT from time to time. The Company shall also establish,
administer and operate an online disaster recovery site of this NPDB/Query database at a
separate geographic site falling in different seismic zone and with a minimum distance of
500 km. The Centralised NPDB will have modularity and scalability option so as to cater
to the requirement of database for the entire MNP Zone in phased manner.
30.3.3 Disaster Recovery (DR) sites for MCH, NPDB, QRDB shall be maintained by
MNP service provider. DR sites shall be updated in real time manner and interconnected
with main production site with redundancy in connecting links to maintain continuity and
uninterrupted service . Interconnection shall be secure path protected and with sufficient
bandwidth.
30.3.4 Modularity of the centralized QRDB will be such as to support number portability
related queries for existing and future operators for call setup and data service delivery
(i.e. SMS/MMS) purposes. The centralised NPDB shall update operator local DB of
Telecom Service Providers in the MNP Zone(s) in real time as soon as porting process
for subscriber is completed and their associated routing information. The detail of
existing service providers in each service area is available at DoT’s website
www.dot.gov.in.
30.3.5 The Centralized Clearinghouse shall use an electronic processing approach for
processing port requests. This includes the management of the porting processes and
information exchange among the Operators to support MNP.
30.3.6 All CMTS/UAS licencsees, International and National Long Distance Operators
that deliver calls to a LSA shall implement direct routing i.e., All Call Query method, to
route calls to ported numbers.
30.3.7 Access Services Providers/ NLDO/ ILDO may have option to either maintain its
own local database or use shared Local operator DB with other telecom service providers
or may take services of MNP service provider for query response system.
30.3.8 Telecom service Operators’ interconnection (through operator’s gateways) with
the centralized clearinghouse (MCH) and NPDB will be through a secure network.
30.3.9 Each Access Service Providers/International and National Long Distance operator
that provide telecom services within service area in which MNP is implemented shall
receive mobile number ported numbers data downloads and associated routing
information from the centralized NPDB via an automated process and/or, if required, by
a manual process to their Local database query system.
30.3.10
It will be the responsibility of the Centralized NPDB to provide download
as per defined time(s). For the new operator, complete download will be provided while
for those operators who have downloaded the database earlier, incremental database
updates will be provided, if so desired.
Draft Licence Agreement for MNP Services – 19.03.2009

Page 23/63

<!-- page 24 -->

30.3.11
The Company shall describe all the call flow scenarios that will fit the
solution offered by the Licensee.
30.3.12
Other operators such as Application / content providers may require
downloads of ported numbers and associated routing information in order to deliver their
services to subscribers. This may be provided by the Licensee on commercial terms and
conditions subject to conditions as may be prescribed by DoT / TRAI from time to time.
30.3.13
Any issues relating to creation of database, interfaces, performance
parameters, service levels shall be resolved by the DoT / TRAI whose decision would be
final and binding on the Licensee.
30.4 CENTRALIZED MOBILE NUMBER PORTABILITY CLEARINGHOUSE
(MCH) AND NETWORK PORTABILITY DATABASE(NPDB):
30.4.1 The Mobile Number Portability Centralized Clearing house (MCH) is a
centralized system used by mobile Operators to port mobile subscriber numbers so that
subscribers may retain their number when changing Operators.
30.4.2 The clearinghouse shall exchange porting messages among participating
Operators, validate these messages, and notify all Operators of ported numbers and their
associated routing information.
30.4.3 The Clearinghouse will support a uniform set of process flows and business rules
to which all Operators will adhere when performing port transactions.
30.4.4 The Clearinghouse shall be a hardware and software platform with automated
and/or manual interfaces for Operators, message processors and a Centralized number
portability database (NPDB) serving as the repository for all ported numbers in the
respective MNP Zone.
30.4.5 The Centralized number portability database (NPDB) shall maintain a record of
all ported numbers and a history file of all transactions relating to the porting of a
number.
30.4.6 The Clearinghouse shall utilize timers to govern the order of execution of the
MNP processes and to help ensure that requests are executed in a timely manner.
30.4.7 The Centralized clearinghouse shall be responsible for meeting performance
standards as prescribed, providing user and technical support services and training for
industry companies/regulator/Licensor on an ongoing basis.
30.5

Number Portability Operator Gateway:

30.5.1 The Number Portability Operator Gateway is an Operator-based workflow system
for processing and managing MNP port transactions with the centralized clearinghouse
and Operator back-end systems, e.g. order and provisioning systems.
30.5.2 The Gateway will accept port requests, pass them on to the centralized
clearinghouse, and co-ordinate ported number updates from the clearinghouse to backend systems in the operator’s network.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 24/63

<!-- page 25 -->

30.5.3 The Gateway will also provide management and reporting functions to allow the
Operator to monitor the porting process.
30.5.4 The Gateway shall utilize timers to enable the Operator to manage and control
MNP processes in their business environment in conformance with the clearinghouse
process flows.
30.5.5 The Gateway shall be a hardware and software platform with automated and
manual interfaces to the clearinghouse, message processors and a local database that
stores all data required to support exchange of MNP messages between an Operator and
the Clearinghouse.
30.5.6 The Gateway shall provide an interface to the Operator’s order and provisioning
systems. This interface may be custom-designed to integrate with existing Operator
order and provisioning systems.
30.5.7 The interfaces provided by the Licensee company towards the operator’s
gateways should be open standard. The Licensee company shall provide the details of
such interfaces (like API etc.) for interconnection of the operator’s gateways to its system
(MCH and NPDB). The operators shall be responsible for establishing, maintaining and
connecting their respective number portability gateways with the company’s system on
the interface stated by the company. In case, MCH equipment requires specific software
at the operator’s number portability gateways to communicate with MCH equipment,
then such software shall be provided to operators by the MCH free of charge/Cost.
30.6 CENTRALISED MOBILE
QUERY RESPONSE SYSTEM:

NUMBER

PORTABILITY

DATABASE

30.6.1 The Mobile Number Portability Query Response System shall be a real-time
database with number portability corrected routing data that could be queried by Operator
networks during call setup to provide the routing number, based on the dialed number.
30.6.2 With the implementation of MNP, Operators shall have the capability to access
and retrieve number portability corrected routing data (supplied by the Clearinghouse
reference database) in order to properly route calls to ported numbers.
30.6.3 Centralized MNP Query response DB may be serving to multiple kinds of
networks e.g. PSTN, CDMA, GSM, NGN with different kind of protocols INAP, MAP,
CAP, WIN, IS-41, SIP, ENUM etc with different versions over SS#7, SIGTRAN, IP etc.
MNP Query response system should support all these multiple requirements at same time
to match with the network capability of different networks.
30.6.4 The Query Response System will be updated from and synchronized with the
reference database in the Clearinghouse.
30.6.5 The licensee shall provide the query database to the operators, if operator so
desires. In such case the operators will either query routing information available with
them, or from the central query system of the operator.
30.7

For mobile number portability in India, Direct Solution i.e. All Call Query
method shall be implemented.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 25/63

<!-- page 26 -->

30.8

In a multi-operator scenario when N operators are involved, the system should be
capable of providing an efficient, cost effective, complete call set up with clear
definitions of operator’s responsibility for routing with further provision for
scalability to support future introduction of inter service area MNP.

30.9

The system should be flexible, scalable and configurable to meet future
requirements. The design of clearing house will be such that total time to port
should not exceed two working days initially but up gradable to much faster
levels. Customer shall approach the recipient operator for porting his/her number.
Donor operator shall not use ported out numbers till such time it is in use by the
ported subscriber. After the surrendering of number by ported subscriber the
number shall revert back to the original donor operator.

30.10 Department of Telecommunications shall provide unique Routing Number (RN)
to each Access Services operator to enable routing to ported number. There will
be one RN for each licensee in every LSA. However, system should also support
multiple RNs per operator in one LSA.
30.11 The Licensees/Licensee shall specify the details of the technology (which shall
always be digital), quality of service and other performance parameters of the
system proposed to be deployed for operation of the service. The technology
should be based on standards issued by ITU/TEC or any other International
Standards Organization/ bodies and the licensee shall seek the approval of the
licensor before deployment of such technologies.
30.12 Requisite monitoring facilities /equipment for each type of system used, shall be
provided by the LICENSEE at its own cost for monitoring as and when required
by the LICENSOR/ designated security agencies.
30.13 Quality of Service: The system should meet the Quality of Service
standards/requirements as specified by TRAI from time to time.
30.14 The licensee can not provide additional facilities in case of any value
addition/upgradation that the technology permits at later date without the prior
approval of licensor.
31.

Technical Requirements

31.1 Within the scope of this licence agreement, the licensee company shall provide all
required central facilities, functions, protocols, procedures, mechanism to provide Mobile
Number Portability (MNP) service as well as all necessary software and hardware.
31.2 The provision should be there in the system (MCH and NPDB) that any of the
ported number can not be used by the Donor Operator till such time it is in use by the
ported subscriber. After the surrendering of number by the ported subscriber, the number
shall revert back to the original Donor Operator on receipt of the information from the
recipient operator. MCH shall facilitate the process and shall be responsible for reverting
the surrendered ported-out number, back to the Donor Operator.
31.3

Once the port is negotiated, network routing information will be passed to each

Draft Licence Agreement for MNP Services – 19.03.2009

Page 26/63

<!-- page 27 -->

access and long distance Operator that provides service within the service area. Porting
mechanism shall be of the type: Break before Make i.e. Donor will stop serving the
subscriber once the port negotiation is completed, then the recipient will start serving the
subscriber. Break time should not exceed more than two(2) hours with the possibility to
reduce it further.
31.4 MCH shall support both synchronization and command level update with both
push and pull mechanism i.e. the porting database can be send to all concerned operators
OR it can be downloaded by them as desired by the concerned operators.
31.5 The execution of porting requests and updating of the local database of the
operator shall be carried out at predetermined specified times in a day. These times shall
be decided in consultation with the operator(s).
31.6 Incremental data download shall be supported. If any new operator starts services
in a telecom service area full data download would be provided.
31.7 Archive (storage) of porting data of last seven days (minimum) shall be available
and will be made available to the operator on request as per mutual commercial
agreement.
31.8 The Licensee company must describe all the porting processes that are associated
with the clearing house (MCH) and how these processes were localized for the Indian
market.
31.9 All MNP processes among the Operators should be supported using the same
protocol for responding to and initiating subscriber port requests. These processes include
the allocation and management of e-tickets (i. e. acknowledgement / docket with all
relevant subscriber details) for porting requests, exchange of messages among
participating Operators, validation of these messages, and the notification of executed
ports to all Operators. The system should include a Reference Database (RDB) that will
serve as the repository for all ported numbers and their associated routing information. It
will also store information regarding porting history, statistical summaries of ports
initiated, ports completed, and ports rejected for tracking, auditing and accounting
purposes.
31.10
The mobile subscriber shall approach the Recipient Operator for porting his/her
number. Therefore the porting request will be initiated by the recipient operator.
31.11 The total time to port should not exceed two (2) working days initially from the
request of the subscriber but up gradable to much faster levels. The System design shall
exhibit high cohesion and low coupling characteristics so as to minimise interdependency
with other applications and services. The Licensee company shall clearly highlight the
critical System interfaces where upgrades and/or operational activities by the Operators
may affect the availability and performance of the System. Non-proprietary hardware that
is commercially available shall be preferred. Where that is not the case, the Licensee
company shall clearly identify and define the functionality of those hardware and provide
justification for their usage.
31.12 The Licensee company shall work closely with the Operators to ensure that the
System inter-operate with existing fixed line and mobile networks in the most cost
effective and efficient manner.
Draft Licence Agreement for MNP Services – 19.03.2009

Page 27/63

<!-- page 28 -->

31.13 The Licensee shall provide access to all NLDOs/ILDOs/Access providers for
interconnection. The telecom service providers shall establish connectivity from their
number portability gateways to the main and DR site at their own cost. The Licensee
company shall provide all necessary infrastructure facilities like space for housing for
transmission equipment, air conditioning, power, connectivity port etc. without any
charge from the service providers and may factor-in these charges while calculating per
port transaction charges for bidding purposes. However, service providers shall be
responsible for establishing and managing the interconnection with the NPDB Query
response system and MCH. The Licensee company shall work with the service providers
to manage the security and availability of these interconnections.
31.14 The MCH/NPDB System design shall be based on open standards on the
interfaces towards service providers which shall be extensible/ modular and support
various standard interfaces to enable an Operator’s information and network systems to
access and communicate with the MCH/QNPDB system in real-time as well as
distributing the Routing Information.
31.15 Port Management System(Consists of MCH/NPDB/QNPDB) Requirements:
31.14.1
The Licensee company shall implement adequate port management
procedure for smooth MN portability. All requirements shall be spellout clearly by the
Licensee company in detail including various parameters.
31.14.2
The terms and conditions of interconnection including standard interfaces,
points of interconnection and technical aspects will be as mutually agreed between the
operator and Licensee company, subject to compliance of prevailing regulations,
directions and determinations issued by DoT/TRAI from time to time.
31.16 Error Monitoring:
31.15.1 Error Logs:31.15.1.1
The Licensee company shall retain, for at least one year or as defined, a
log of all transactions, including all attempts (successful and unsuccessful) to access the
System, as well as all messages which enter or leave the System, and all database updates
or modifications that occur as a result of processing any of these messages.
31.15.1.2
indicate:

If any problem is to occur while processing a message, the logs shall

•

the nature of the problem, e.g., a database unique constraint violation;

•

the time of the problem; and

•

the contents of the message that caused the problem, including the particular
port for which the message applies, the donor, the recipient and the
originator of the message

31.15.1.3
indicate:

If the problem occurred while attempting to send a message, the logs shall

•

the nature of the problem;

•

the time the problem occurred; and

Draft Licence Agreement for MNP Services – 19.03.2009

Page 28/63

<!-- page 29 -->

•

the contents of the message that was not able to be sent successfully

31.15.2 Error Handling:•

The System shall validate all incoming messages to ensure that they
conform to the definition of the porting process. The Licensee company
shall have well defined mechanism for error handling including flexibility to
accommodate additional error conditions & response thereof. The Licensee
company shall work out the error message details in consultation with the
service providers.

31.17 Availability
31.16.1
The System (both hardware and software) shall be designed for high
availability and continuous operation. All major hardware components, including
router/firewall, web servers, data servers etc. shall have redundancy provisions. The
Licensee company shall specify in detail how the availability and redundancy are
provided.
31.18 The port management system(Consists of MCH, Centralised NPDB & NPDB
Query response system) shall achieve availability of not less than (say) 99.99% on
quarterly basis(i. e. every three months) and any failure of maintaining system below
99.99% (or as per order/direction/regulation of TRAI) service availability, the
Performance Bank Guarantee may be forfeited if so recommended by TRAI. For the
benchmarks related to quality of service etc., a separate regulation will be issued by
TRAI.
31.19 Capacity Requirements and Performance
31.18.1
Presently, the number of expected portings and transactions are not
known. The Licensee company shall assess the requirement itself and accordingly design
the system.
31.18.2
The Licensee company shall provide benchmarks for performance
throughput of the proposed System – from port as well as messaging throughput
perspective.
31.20 Maintenance and Operations
31.19.1
The system shall provide visual status of the system in real time and make
it possible to carry out preventive maintenance and service upgrades without any service
down time.
31.21 Audit Logs and Reports
31.20.1

Logs
•

The Porting Management System (MCH) shall log data for every port for

Draft Licence Agreement for MNP Services – 19.03.2009

Page 29/63

<!-- page 30 -->

which an Operator is either a Donor or Recipient Network Operator. Such
data will be used for reconciliation purposes.
•

31.20.2

Key transactions and audit logs shall be archived off-site and stored
permanently for future references, while event/non critical logs and data
information shall be retained for at least one year or as defined.
Reports

The System shall be a capable to generate reports pertaining to various
transactions and porting events in the format and at frequency as prescribed by
DoT/TRAI .
32.

Acceptance Testing

32.1

Acceptance Test Plan:-Prior to commencement of the operation of MNP, the
Licensee Company shall get its system acceptance testing as per TEC/DoT
approved test plan and to the satisfaction of the testing party(s) of DoT.

32.2

Operations and Maintenance Tests: The Licensee company shall ensure that
the system and services are in a condition ready for the commencement of
Acceptance Testing within four (4) months of award of the contract. The
Licensee company and the Operators shall, at their own costs, carry out all
Acceptance Testing as laid down by TEC/DoT.

33.

Activities at the Licensee Company’s end

Licensee shall have to carryout following activities for implementing MNP.
However the list of following activities are indicative and not exhaustive:•

Equipment installation and testing

•

Leased line connectivity from operator ends to MCHA and NPDB

•

Operator’s end preparation for gateway switch connectivity, interfaces etc.

•

Meeting with security agencies for lawful interception requirements, if any.

•

Testing between operator’s (Access & long distance) end to MCHA, NPDB, NP
query response system

•

End to end testing between one operator to all other operators in the licensed area.

•

Training to the technical persons of the operators for MCHA & NPDB, Local query
NP database system functionality etc.

•

Rigorous test for data synchronization between Central NPDBs and between Central
NPDBs to Local NPDBs

Draft Licence Agreement for MNP Services – 19.03.2009

Page 30/63

<!-- page 31 -->

34.
Broad Guidelines of duties and responsibilities of MNP Service Provider:
The Licensee company should follow the broad guidelines of duties and responsibilities
of as mentioned below:
34.1

The Entity responsible should adhere to the following:
a.
b.
c.
d.
e.

34.2

A record of logs shall be maintained for all activities for at least for a
period of one year unless otherwise specified.
MNP Service Provider cannot deviate from the stated guidelines
stipulated by Regulator/Licensor.
Escalate the issues to Regulator and provide reports to Regulators as per
their requirement.
Processing of porting request shall be first come first serve basis.
Individual porting requests may be preferred compared to bulk request.
Protection of sensitive information and meeting requirements of security
agencies.

Service Implementation and Launch

34.2.1 Planning & Engineering Services
• Assist Licensor / regulator / operators to understand the significance of key Mobile
Number Portability (MNP) issues, analyze alternative approaches, and assist the
members in reaching consensus that is in the best interest of all stakeholders.
• Develop preliminary and final Number Portability Clearing House (MCHA) Process
Flows and External Interface specifications.
• Obtain DoT concurrence for both Specifications to confirm the feature functionality
that will be delivered in the MCHA software release.
34.2.2 Data Centre Establishment
• Provide 24x7 secure and redundant Data Centers conforming to highest industry
norms ( and necessary ISO certifications: Production Site and a Disaster Recovery and
Test Site which are geographically stable to accommodate the MCHA system
platform.
• Provide access control systems to ensure entry only by authorized personnel
designated by the Clearinghouse Provider to perform installation, resolve problems
and perform maintenance.
• Establish a secure environment to protect clearing house and personal data in
conformance with standing laws.
34.2.3 Platform Installation
• Procure, install and maintain all hardware, Third Party Software required for the
operation of the MCHA, Disaster Recovery and Test systems and for inter-

Draft Licence Agreement for MNP Services – 19.03.2009

Page 31/63

<!-- page 32 -->

connectivity between the MCHA, operators and any applicable operational support
systems (such as monitoring and ticketing systems, operations web site, etc.).
• Develop and maintain a customer web site for posting the latest MCHA
documentation, MCHA release information, reports, industry notifications of downtime, etc.
• Secure and restrict website access for each operator and other authorized users (i.e.,
password protected).
• Design a network at each Site required for the operations of the MCHA system and for
inter-connectivity between the MCHA and any applicable customer operational
support systems (such as monitoring and ticketing systems).
• Establish all internal data communication links, paths, network configurations for the
MCHA system at each Site.
• Provide the means to load balance incoming traffic to its network.
34.2.4 Software Development
• Develop code to implement the MCHA software features based on the Process Flow
and External Interface Specifications that have been confirmed by DOT.
• Conduct software testing to help ensure the integrity of the MCHA software system.
• Collect routing and reference data from operators to configure and localize the MCHA
software for use .
34.2.5 Software Installation
• Verify that pre-requisites of the installation are successfully completed prior to the
start of the initial installation.
• Provide installation of the MCHA system for the Production, Disaster Recovery and
Test systems.
• Perform post-installation verification testing to verify that the MCHA is functioning
and is ready for Installation Verification.
• Troubleshoot and resolve any issues identified to ensure platform readiness for the
Production, Disaster Recovery and Test Systems.
34.2.6 Installation Verification
• Develop an Installation Verification Test Plan (“IVTP”) that will define the scope,
procedures, methodologies, data requirements, and test cases to be used to test the
MCHA, along with expected test case results and responsibilities of the Parties with
respect to the testing activities. IVTP will be approved by DoT.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 32/63

<!-- page 33 -->

34.2.7 Operator Access
• Provide Points of Presence – for leased lines, VPN, etc. - for Operator access to the
MCHA production and disaster recovery systems.
• Establish Operator IDs and login assignments for each MCHA user.
• Identify the number of GUI users expected.
• Identify the point of contact for each Operator.
• Assist operators in arranging with the Data Centre to get their requested connectivity
in place so they can connect to the MCHA.
34.2.8 Industry Testing
• Develop an Inter-Operator Test Plan (“IOTP”) that will assist the industry to define the
guidelines, scope, methodologies, data requirements and test scenarios to be used to
test the MCHA. IOTP will be approved by DoT.
• Provide technical support for each operator in connecting to each system.
• Provide technical support for the industry for operator testing consisting of
Connectivity Testing, System Testing, and Inter-Operator Testing in the timeframes set
forth in the Final Schedule.
• Assist the industry to determine the testing strategy, progress tracking and coordination
for industry acceptance.
• Provide Help Desk personnel as initial point of contact to track issues reported by the
industry.
• Troubleshoot and resolve issues reported.
• Schedule with the industry periodic down-times in order to correct Severity 1 or 2
conditions found.
34.2.9 Service Live
• Confirm and provide final reference data set (routing assignments, national numbering
plan, timer values, etc.) for service live.
• Refresh the production database whereby test data is dropped and final reference data
set is loaded.
• Provide technical support during service launch.
• Confirm industry readiness and coordinate industry cut-over for service live.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 33/63

<!-- page 34 -->

34.2.10

Documentation

• Provide Process Flow descriptions of the porting processes, messages, timer
definitions, system interfaces, and data for MCHA that will be available to all
operators.
• Provide an External Interface (Interface Specification) that describes the mechanized
external [Simple Object Access Protocol (SOAP)] interface to the MCHA that will be
available to all operators.
• Provide an End-User Guide containing instructions for service providers who use the
MCHA Graphical User Interface (GUI).
• Distribute the documentation accordingly (i.e. password protected web site download,
email distributions, etc.)
34.2.11

Training

• The Licensee shall impart extensive, comprehensive technical, commercial training on
MNP system to officers of TRAI/DoT for at least 80 man-weeks at India/ abroad on
cost of Licensee. However, expenditure on TA/ DA for such trainings will be borne by
TRAI/DoT.
• Conduct training for Permitted or Authorized Users (“MCHA End-User Training”).
• Provide training materials in advance of the training class via electronic media.
34.2.12

Program Management

• Identify preparation activities to assist TRAI/DoT coordinate and manage the launch
of Mobile Number Portability (MNP) in India.
• Designate a single point of contact Project Manager to develop a Project Plan who will
work with the TRAI/DoT and manage the activities set forth in the Project Plan.

34.3

Service Operations and Maintenance

34.3.1 Service Delivery
• All technical-hardware & support to Access Services Providers, NLD and ILD
operators to provide MNP services to Mobile Subscriber in accordance with the terms
and conditions as defined by DOT/TRAI from time to time.
• Automatically process transactions between the pertinent Donor Operator(s) and
Recipient Operator(s) in connection with requests by mobile Subscribers for the
porting of their mobile numbers using the MCHA system.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 34/63

<!-- page 35 -->

• Store ported mobile numbers and their routing information in a reference database, as
well as any revisions and updates of the database.
• Enable Access Services Operator/ NLD, ILD operator’s information systems to access
and communicate with the MCHA System for port processing and notification
distribution.
• Generate reports with statistical information related to MNP Services activity for
billing purposes including activity level reports, porting history, port in and port out
request as may be required from time to time.
• Timely broadcasting of porting updations.
• Updating database of deactivated / surrendered ‘ported number’ and timely
information to Number Rangeholder
34.3.2 Help Desk Support
• Provide and staff a Help Desk to support access service / NLD / ILD operators users
24X7.
• Provide Level 1 and Level 2 user support to Access Services / NLD / ILD .
• Log and refer to systems administration personnel any issues related to MCHA
Systems, hardware, third party software, and connectivity.
• Ensure the accuracy and timeliness of any information which is input into the MCHA
System and processing the data obtained by its use of the System.
• Provide application level security through authentication procedures for operator
access to the MCHA System SOAP Interface and the graphical user interface (GUI).
• Provide, maintain and use a standard Help Desk trouble ticketing system which can
allow operators to access and enter trouble reports and requests for assistance to
include incidents, severity levels and other related information and operators to query
and check on the status of their requests.
• Problem Determination Intervals:
o Severity 1 Defects: XXXXX
o Severity 2 Defects: XXXXX
o Severity 3 Defects: XXXXX
• Restoration Interval:
o Severity 1 Defects: XXXXX

Draft Licence Agreement for MNP Services – 19.03.2009

Page 35/63

<!-- page 36 -->

o Severity 2 Defects: XXXXX
o Severity 3 Defects: XXXXX
• Resolution Interval:
o Severity 1 Defects: XXXXX
o Severity 2 Defects: XXXXX
o Severity 3 Defects: XXXXX
34.3.3 System Administration
• Provide MCHA Systems administration of logon activation and security for operators,
TRAI/DoT and other authorized users.
• Provide access for law enforcement and other security agencies to the porting data.
• Provide logon administration:
o Assisting with new logon requests;
o Initialization of logon id, password, and security level;
o Adding new Service Providers as users to the System;
o Notifying Service Providers of logon activation; and
o Resolving problems with existing logon ids or passwords.
34.3.4 Database Backup and Restoration
• Provide for weekly reboots, daily back-ups, and weekly archiving.
• Provide for full MCHA database backups that are automatically performed.
• Perform incremental MCHA database backups each night during business days.
• Perform file system backup and MCHA database backup before and after the initial
installation, and before and after each upgrade to the System.
• In case restoration is needed, recover, as appropriate, all data from the media for the
last full MCHA database backup and/or data from the media for the last incremental
backup.
• Send copies of the backup media to the backup/disaster recovery site and also to an
outside storage facility each week.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 36/63

<!-- page 37 -->

34.3.5 Hardware & Software Maintenance
• Maintain the hardware and software including third party software at all sites.
• Resolve technical errors in the clearinghouse software, hardware or system design.
• Provide Maintenance Releases whose timing and content shall be determined by the
Clearinghouse Provider as deemed needed to keep the MCHA System and services
functioning.
• Communicate the features and update schedule of each release to TRAI/DoT prior to
general availability in the System.
34.3.6 System & Network Monitoring
• Provide monitoring of the hardware & third party software at both sites on a 24/7
basis.
• Perform complete monitoring of the system, including but not limited to following:
o Network connectivity
o Hardware - Memory Usage, CPU usage, Hard Disk Usage (inc. storage
array and server internal disks)
o Third party software
o Application processes
• Monitor, manage, and maintain connectivity between the operator point of presence
and the MCHA system.
• Provide load balancing to distribute Internet traffic between multiple web or database
servers.
34.3.7 Performance Engineering
• Monitor and track capacity and throughput characteristics of the MCHA system.
• Compile data continually and analyze how well the system conforms to the
requirements from time to time.
• Establish proactive plans to upgrade the system to meet increasing load to maintain
service level commitments.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 37/63

<!-- page 38 -->

34.3.8 Invoicing, Billing & Collecting
• Generate monthly reports on porting activity for each operator for porting to be billed
based on TRAI’s regulation/orders/direction in the matter.
• Provide a Monthly Usage Report of the previous month's activity that may include the
number of transactions and subscription services per Operator.
• Create operator invoices based on Monthly Report.
• Deliver invoices to operators specifying the payment remittance to the Collection
Account.
• Collect and register all operator payments.
34.3.9 Business Continuity Planning
• Develop a Business Continuity Plan based on a disaster recovery strategy.
• Coordinate, if needed, and confirm results of Disaster Recovery dry-run for operator
fail-over from Production System to Disaster Recovery System.
34.3.10

Program Management

• Review the decisions and action items arising from post-live and ongoing program
management meetings with DOT/TRAI and the Operators.
• Conduct project review meetings with TRAI/DoT and provide status reports at a
frequency to be mutually agreed to by the Clearinghouse Provider and TRAI/DoT.
• Attend meetings to review monthly performance reports, proposed changes,
operational optimization, new service requirements and outstanding incidents.
35.
35.1

The Applicable System
In the process of operating the Services, the Licensee shall be responsible for:(i)
(ii)
(iii)

36.
(a)

the proper upkeep and maintenance of the equipment;
maintaining the criteria of performance;
maintaining the QoS as mandated by concerned authority.

Engineering Details
The Licensee shall furnish to the Licensor or its authorised representative(s), in
such manner and at such times as may be required, complete technical details with
all calculations for engineering, planning and dimensioning of the system/

Draft Licence Agreement for MNP Services – 19.03.2009

Page 38/63

<!-- page 39 -->

network, concerned relevant literature, drawings, installation materials regarding
the applicable system.
(b)

List of performance tests shall be furnished by the Licensee to the licensor
/TEC three month prior to the date of commissioning of service.

(c)

Licensee shall supply all tools, test instruments and other accessories to the testing
party of Licensor and /or TEC for conducting tests, if it so desires, prior to
commissioning of the service or at any time during the currency of the Licence.

(d)

Any delay on part of the LICENSEE in offering the system for conducting
performance tests to TEC/ Licensor will not be considered as the valid reason for
non-fulfillment of the Roll-out obligations imposed by the terms of this Licence.

37.

Network Interconnection

37.1 Interconnection to the networks of telecom service providers shall be provided
, within the overall framework of interconnection regulations issued by the TRAI from
time to time.
37.2 The Interconnection Tests for each and every interface with any Service provider
may be carried out by mutual arrangement between the Licensee and the other party
involved. The Interconnection Tests schedule shall be mutually agreed.
38.

Interface

38.1 MNP service provider shall be responsible to resolve inter-operability issues with
various telecom service providers.
38.2 The LICENSEE shall operate and maintain the licensed Network conforming to
Quality of Service standards to be mutually agreed in respect of Network- Network
Interface. For the purpose of providing the SERVICE, the LICENSEE shall install his
own equipment so as to be compatible with other service providers’ equipment to which
the licensee's Applicable Systems are intended for interconnection. The Licensee shall be
solely responsible for attending to claims and damages arising out of his operations.
38.3 The additional telecommunication resources for the provision of the service and
networking the geographically dispersed equipment of the LICENSEE shall be
leased/rented on mutually agreed terms from service providers including BSNL, MTNL
or authorised Telecom Service Providers.
38.4 The interconnection and technical interfaces between networks of MNP service
provider(s) and Telecom service provider(s) shall be governed by the orders/notifications
of the TRAI issued from time to time on interconnection/access charges.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 39/63

<!-- page 40 -->

38.5 The network resources including the cost of upgrading/modifying interconnecting
networks to meet the service requirements of the licensee shall be mutually negotiated
keeping in view the orders and regulations issued by the TRAI from time to time.
38.6 MNP licensee shall be responsible to successfully inter-connect, inter-work and
inter-operate their NPDB, QRDB, MCH system with NP Gateway and Local DB
network/ system at Telecom service provider end through sharing of information,
modification in system or interfaces, and inter-action, coordination with the telecom
service providers as detailed in the tender.
39.

Quality of Service

39.1 The LICENSEE shall ensure the Quality of Service (QoS) as prescribed by the
LICENSOR or TRAI. The LICENSEE shall adhere to such QoS standards and provide
timely information as required therein.
39.2 The Licensee shall be responsive to the complaints lodged by his subscribers. He
shall rectify the anomalies within the MTTR specified and maintain the history sheets for
each installation, statistics and analysis on the overall maintenance status.
39.3 MTBF:
The Licensee shall deploy an applicable system to meet MTBF
specified by TRAI/DOT for provision of MNP services.
39.4 The LICENSOR or TRAI shall carry out performance tests on Licensee’s network
and also evaluate Quality of Service parameters in licensee’s network prior to grant of
permission for commercial launch of the service after successful completion of
interconnection tests and/or at any time during the currency of the Licence to ascertain
that the network meets the specified standards on Quality Of Service (QOS). The
licensee shall provide ingress and other support including instruments, equipment etc., for
such tests.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 40/63

<!-- page 41 -->

PART-V
40.

OPERATING CONDITIONS

Customer Service

40.1 The LICENSEE shall be bound to interconnect in order to provide MNP service
to all the licensed telecom service providers (Basic Service, UAS, CMTS, NLD and ILD
licensees) without any discrimination, unless directed otherwise by the LICENSOR in
writing.
40.2 It shall be the responsibility of the Licensee to issue or cause to be issued bills to
the UAS/CMTS licensees for use of the service. The Licensee shall maintain such
records so as to produce itemised billing information. The billing system of the licensee
shall be able to generate the billing information, in adequate details, to ensure satisfaction
to the access services licensees i.e. UAS/CMTS licensees, about the genuineness of the
bill. The directions of TRAI, from time to time, in this regard shall apply.
40.3 The LICENSEE’s contractual obligations to various Telecom Service Providers
will include terms and conditions under which the SERVICE may be obtained, utilised
and terminated.
40.4 The LICENSEE shall notify in writing all the arrangements with respect to repair,
fault rectification, compensation or refunds. All complaints in this regard will be
addressed / handled as per the guidelines, order or regulation or direction issued by the
LICENSOR or TRAI from time to time.
40.5 Any dispute, with regard to the provision of SERVICE shall be a matter only
between the aggrieved party and the LICENSEE, who shall duly notify this to all before
providing the SERVICE. And in no case the LICENSOR shall bear any liability or
responsibility in the matter.
41.

Roll-out Obligations

41.1 LICENSEE shall ensure the commissioning of MNP service as per condition 18,
failing which liquidated damages will be levied as per condition 42.
42.

Liquidated Damages

42.1 The time period stipulated in the condition 18 regarding ‘Delivery of Service’ in
this Licence shall be deemed as the essence of the contract and the service must be
brought into commission not later than such specified time period. No extension in
delivery date will be granted. If the Service is brought into commission after the expiry
of the due date of commissioning, without prior written concurrence of the licensor and is
accepted, such commissioning will entail levy of Liquidated Damages (LD) under this
Condition.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 41/63

<!-- page 42 -->

42.2 In case the LICENSEE fails to bring the Service or any part thereof into
commission (i.e., fails to deliver the service or to meet the required roll out obligations)
within the period prescribed for the commissioning, the Licensor shall be entitled to
recover LD charges for failure of delivery of Service/ Roll Out obligations. The
applicable LD charges shall be Rs.10,000 (Rupees ten thousand) per fortnight for the first
3 months, Rs. 50,000 (Rupees fifty thousand) per fortnight for the next 3 months and
Rs.1 lakh per fortnight for the further 6 months delay. Part of the fortnight is to be
considered as a full fortnight for the purpose of calculating the LD charges. For delay of
more than 12 months the Licence may be terminated under the terms and conditions of
the Licence agreement. The fortnight shall mean 15 Calendar days.
42.3 The Liquidated Damages (LD) under this Condition shall be imposed separately
against failure of compliance of condition 41.
43.

Obligations imposed on the Licensee

43.1 The provisions of the Indian Telegraph Act 1885, Indian Wireless Telegraphy
Act, 1933, Information Technology Act, 2000 and the Telecom Regulatory Authority of
India Act, 1997 as modified from time to time or any other statute on their replacement
shall govern this LICENCE.
43.2 The LICENSEE shall furnish all necessary means and facilities as required for the
application of provisions of Section 5(2) of the Indian Telegraph Act, 1885, whenever
occasion so demands. Nothing provided and contained anywhere in this Licence
Agreement shall be deemed to affect adversely anything provided or laid under the
provisions of Indian Telegraph Act, 1885 or any other law in force.
44.

Inspection and Testing of Installations.

44.1 The Licensor / TRAI may also carry out all performance tests required for
checking Quality of Service, if it so desires. The LICENSEE shall supply all necessary
literature, drawings etc. regarding the equipment installed and shall also supply all the
tools, test instruments and other accessories to the testing party of the LICENSOR /
TRAI for conducting the tests. The list of performance tests will be furnished by the
LICENSEE three month prior to the date of commissioning to the Licensor. In case the
Licensor chooses to conduct performance test and some deficiency is found therein by
the licensor, the delay caused for rectification of the deficiencies, if any, will be entirely
on account of the LICENSEE.
44.2 The testing for each and every interface with the telecom service providers may
be carried out by mutual arrangements between the LICENSEE and the other party
involved. The Test schedule shall be mutually agreed.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 42/63

<!-- page 43 -->

PART-VI SECURITY CONDITIONS
45.

Right to inspect.

45.1 The LICENSOR or its authorised representative shall have right to inspect the
sites used for extending the Service and in particular but not limited to, have the right to
have access to leased lines, junctions, terminating interfaces, hardware/software,
memories of semiconductor, magnetic and optical varieties, wired or wireless options,
distribution frames, and conduct the performance test including to enter into dialogue
with the system through Input/output devices or terminals. The LICENSEE will provide
the necessary facilities for continuous monitoring of the system, as required by the
LICENSOR or its authorised representative(s). The Inspection will ordinarily be carried
out after reasonable notice except in circumstances where giving such a notice will
defeat the very purpose of the inspection.
45.2 Wherever considered appropriate LICENSOR/TRAI may conduct any inquiry
either suo-moto or on complaint to determine whether there has been any breach in
compliance of terms & conditions of the LICENCE by the LICENSEE and for such
inquiry the LICENSEE shall extend all reasonable facilities without any hinderance.
46.

Location of MNP Systems:

46.1 The LICENSEE shall provide to the LICENSOR location details of MNP systems
(Main and DR), location of telecom service providers systems connected with Main and
DR systems of the licensee, including routing details etc., and location of these centres
shall not be changed without prior approval of the LICENSOR.
46.2 In issues which are sensitive from security point of view, as may be notified from
time to time by the LICENSOR, implementation / provisioning of MNP service in such
cases shall be taken up only after the LICENSOR’s approval.
47.

Confidentiality of information:

47.1 The licensee shall not employ bulk encryption equipment in its network. Any
encryption equipment connected to the LICENSEE’s network for specific requirements
has to have prior evaluation and approval of the LICENSOR or officer specially
designated for the purpose.
47.2 Subject to conditions contained in these terms and conditions, the LICENSEE
shall take all necessary steps to safeguard the privacy and confidentiality of any
information about a third party and its business to whom it provides the SERVICE and
from whom it has acquired such information by virtue of the SERVICE provided and
shall use its best endeavors to secure that :

Draft Licence Agreement for MNP Services – 19.03.2009

Page 43/63

<!-- page 44 -->

a)
No person acting on behalf of the LICENSEE or the LICENSEE divulges
or uses any such information except as may be necessary in the course of
providing such SERVICE to the Third Party; and
b) No such person seeks such information other than is necessary for the purpose
of providing SERVICE to the Third Party.
Provided the above para shall not apply where:
a) The information relates to a specific party and that party has consented in
writing to such information being divulged or used, and such information is
divulged or used in accordance with the terms of that consent; or
b) The information is already open to the public and otherwise known.
47.3 The LICENSEE shall take necessary steps to ensure that the LICENSEE and any
person(s) acting on its behalf observe confidentiality of customer information.
47.4 The LICENSEE shall, prior to commencement of SERVICE, confirm in writing
to the LICENSOR that the LICENSEE has taken all necessary steps to ensure that it and
its employees shall observe confidentiality of customer information.
(i) In the interests of security, suitable monitoring equipment as may be prescribed for
each type of system used will be provided by the LICENSEE for monitoring as and
when required by LICENSOR. The specific orders or directions from the
Government, issued under such conditions, shall be applicable.
(ii) LICENSEE will ensure that the installation carried out by it should not become a
safety hazard and is not in contravention of any statute, rule or regulation and
public policy.
48.

Prohibition of certain Activities by the Licensee.

48.1 The LICENSEE shall not engage on the strength of this LICENCE in the
provision of any other Service other than the SERVICE as defined in this Licence
Agreement.
48.2 To remove any doubt, it is, hereby, clarified that nothing contained in condition in
Para above shall preclude the LICENSEE from engaging in advertising and promotional
activities relating to MNP service.
48.3 The LICENSEE shall take necessary measures to prevent objectionable,
obscene, un-authorised or any other content, messages or communications infringing
copyright, intellectual property etc., in any form, from being carried on his network,
consistent with the established laws of the country. Once specific instances of such
infringement are reported to the LICENSEE by the enforcement agencies, the
LICENSEE shall ensure that the carriage of such material on his network is prevented

Draft Licence Agreement for MNP Services – 19.03.2009

Page 44/63

<!-- page 45 -->

immediately. Any damages arising out of default on the part of LICENSEE in this regard
shall be borne by the LICENSEE.
48.4 The LICENSEE is obliged to provide, without any delay, tracing facility to trace
nuisance obnoxious or malicious calls, messages or communications through his
equipment and network from one access services operator to other operator. Any
damages arising out of default on the part of LICENSEE in this regard shall be borne by
the LICENSEE.
48.5 In case any confidential information is divulged to the LICENSEE for proper
implementation of the Agreement, it shall be binding on the Licensee and its employees
and servants to maintain its secrecy and confidentiality.
49.

Information on Ported Numbers to Security Agencies:

49.1 MNP Licensee shall provide updated database of ported numbers or other details
as may be required by the Licensor/designated security agencies in the format required by
them as per directions issued by the Licensor from time to time.
50.

Security Conditions:

50.1 The LICENSEE shall provide necessary facilities depending upon the specific
situation at the relevant time to the Government to counteract espionage, subversive act,
sabotage or any other unlawful activity.
50.2 All foreign personnel likely to be deployed by the LICENSEE for installation,
operation and maintenance of the LICENSEE’s network shall be security cleared by the
Government of India prior to their deployment. The security clearance will be obtained
from the Ministry of Home Affairs, Government of India, who will follow standard drill
in the matter.
50.3 The LICENSEE shall ensure protection of privacy of communication and ensure
that unauthorized interception of messages does not take place.
50.4 LICENSOR reserves the right to modify these conditions or incorporate new
conditions considered necessary in the interest of national security and public interest or
for proper provision of TELEGRAPH.
50.5 In the interests of security, suitable monitoring equipment as may be prescribed
for each type of system used will be provided by the LICENSEE for monitoring as and
when required by LICENSOR. The specific orders or directions from the Government,
issued under such conditions, shall be applicable.
50.6 The designated person of the Central/State Government as conveyed to the
Licensor from time to time in addition to the Licensor or its nominee shall have the right
to monitor the transactions and installations or any other technically feasible point in the

Draft Licence Agreement for MNP Services – 19.03.2009

Page 45/63

<!-- page 46 -->

network set up by the licensee. The hardware at licensee’s end and software required for
such monitoring shall be engineered, provided/installed and maintained by the Licensee
at licensee’s cost. However, the respective Government instrumentality shall bear the
cost of user end hardware and leased line circuits from the MNP Lisensee’s installations
to the monitoring centres to be located as per their choice in their premises or in the
premises of the licensee. In case the security agencies intend to locate the equipment at
licensee’s premises for facilitating monitoring, the licensee should extend all support in
this regard including Space and Entry of the authorised security personnel. The Interface
requirements as well as features and facilities as defined by the Licensor should be
implemented by the licensee. The Licensee should ensure suitable redundancy in the
complete chain of Monitoring equipment for trouble free operations of monitoring as may
be notified from time to time.
50.7 LICENSOR shall have the right to take over the SERVICE, equipment and
networks of the LICENSEE (either in part or in whole of the MNP Zone) in case any
directions are issued in the public interest by the Government of India in the event of a
national emergency / war or low intensity conflict or any other eventuality. Any specific
orders or directions from the Government of India issued under such conditions shall be
applicable to the LICENSEE and shall be strictly complied with. In case equipment/
services are taken over by the Licensor after 5 years from effective date of the Licence,
no compensation shall be payable.
50.8 In such case, compensation, if any, including the charges for taking over the
equipment, if these are taken would not be more than amortized value of the equipment
and net profit calculated at the rate of the net profit of the previous quarter (loss,
however, will be ignored) for the balance period of time i.e. period between time taken
over and five years when the exclusive right otherwise would have been completed.
50.9 The Licensor or its representative(s)/ designated security agencies will have an
access to the Database, transactions / messages relating to the porting of mobile
subscribers, on-line / off-line access to Licensee’s network and other facilities as well as
books of accounts etc.
50.10 The Licensee shall maintain all commercial records with regard to the messages
exchanged on the network. Such records shall be archived for at least three year for
scrutiny by the Licensor for security reasons and may be destroyed thereafter unless
directed otherwise by the licensor.
50.11 The Licensee company shall take adequate and timely measures to ensure that
information transacted through its network is secure and protected. The Licensee
company has to ensure that the system has security management process and control for a
number of different roles ranging from system administrators, government and for the
operators. The Licensee company shall ensure that the network/system is protected from
unauthorized access. The data and system integrity should be ensured. The data centres
should conform to the highest industry norms and necessary ISO certifications.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 46/63

<!-- page 47 -->

50.12 Remote access of the system for the purpose of operation, maintenance &
monitoring will be as per the Licensor’s orders in force from time to time.
50.13 Active support must be extended by the service providers to the respective
Telecom Enforcement, Resource & Monitoring (TERM) cells of DoT or any authorized
agency of DoT for detection of any clandestine / illegal telecommunications activity. For
this purpose, names of the Nodal officers & alternate Nodal Officers in respect of
licensed MNP Zone as communicated to the Intelligence/security Agencies should also
be forwarded to respective TERM cell of DoT, DDG(Security) DoT and Access Services
Cell of DoT. The TERM Cell of DoT or any other designated officer of DoT will contact
the Nodal Officer / alternate Nodal officer, and till the time such nomination is received
or in case of non-availability of such officer, the TERM Cell will contact the Chief
Executive Officer of the licensee, for such support / coordination.
50.14 The LICENSEE shall also ensure compliance of the following conditions:
(i)
The Chief Officer in charge of technical network operations and the Chief
Security Officer should be a resident Indian citizen.
(ii)

Details of infrastructure/ network diagram (technical details of the network)
could be provided on a need basis only to telecom equipment
suppliers/manufacturers and the affiliate/parents of the licensee company.
Clearance from the licensor (Department of Telecommunications, Government
of India) would be required if such information is to be provided to anybody
else.

(iii)

The licensee company shall take adequate and timely measures to ensure that
the information transacted through a network by the subscribers is secure and
protected.

(iv)

The officers/officials of the licensee companies dealing with the lawful
interception of messages will be resident Indian citizens.

(v)

The majority Directors on the Board of the Licensee company shall be Indian
citizens.

(vi)

The positions of the Chairman, Managing Director, Chief Executive Officer
(CEO) and/or Chief Financial Officer (CFO), if held by foreign nationals,
would require to be security vetted by Ministry of Home Affairs (MHA).
Security vetting shall be required periodically on yearly basis. In case
something adverse is found during the security vetting, the direction of MHA
shall be binding on the licensee.

(vii)

The Licensee shall not transfer the following to any person/place outside India:(a) Any accounting information relating to the customerss (Note: it does not
restrict a statutorily required disclosure of financial nature) ; and
(b) User information

(viii) The Licensee shall familiarize/ provide training to the Telecom Enforcement,
Resource & Monitoring (TERM)/ security agency officers/ officials in respect
of relevant operations/ features of their systems.
Draft Licence Agreement for MNP Services – 19.03.2009

Page 47/63

<!-- page 48 -->

51.

Application of Indian Telegraph Act

51.1 The LICENSEE shall adopt all means and facilitate in every manner the
application of the Indian Telegraph Act, 1885 as modified or replaced from time to time.
The Service shall be provided in accordance with the provisions of Indian Telegraph
Rules as modified and amended from time to time.
51.2 As per the provision of Section 5 of Indian Telegraph Act, the licensee will
provide necessary facilities to the designated authorities of Central/State Government as
conveyed by the Licensor from time to time for interception of the messages passing
through its network.
Section 5 (2) of the Indian Telegraph Act 1885 reads as under:
“On the occurrence of any public emergency or in the interest of public safety, the
Central Government or a State Government or any officer specially authorised in their
behalf by the Central Government or a State Government may, if satisfied that it is
necessary or expedient to do so in the interest of the sovereignty and integrity of India,
the security of the State, friendly relations with foreign states or public order or for
preventing incitement to the commission of an offense for class or messages to or from
any person or class of persons or relating to any particular subject, brought for
transmission by or transmitted or received by any telegraph, shall not be transmitted or
shall be intercepted or detained or shall be disclosed to the Government making the order
or an officer thereof mentioned on the order:
Provided that press messages intended to be published in India of correspondents
accredited to the Central Government or a State Government shall not be intercepted or
detained, unless their transmission has been prohibited under this subsection.”

Draft Licence Agreement for MNP Services – 19.03.2009

Page 48/63

<!-- page 49 -->

ANNEXURE-I
Glossary and Definition of Terms and Expressions
A. Glossary
S.No.

Abbreviation

Expansion

1.
CEO
Chief Executive Officer
2.
CFO
Chief Financial Officer
3.
CH
Clearing House
4.
CMSP
Cellular Mobile Service Provider
5.
DNS
Domain Name System
6.
DoT
Department of Telecommunications, Govt. of India
7.
DR
Disaster Recovery
8.
ENUM
E Number
9.
FCCBs
Foreign Currency Convertible Bonds
10.
FDI
Foreign Direct Investment
11.
FIIs
Foreign Institutional Investors
12.
FIPB
Foreign Investment Promo
13.
GDRs
Global Depository Receipts
14.
GSM
Global System for Mobile Communication
15.
ILDO
International Long Distance Operator
16.
LRN
Locational Routing Number
17.
MCHA
Mobile Number Portability Clearing House
18.
MHA
Ministry of Home Affairs
19.
MMS
Multimedia Messaging Service
20.
MNP
Mobile Number Portability
21.
NLDO
National Long Distance Operators
22.
NP
Number Portability
23.
NPDB
Number Portability Database
24.
PBG
Performance Bank Guarantee
25.
QNPDB
Network Portability database query response system
26.
QoS
Quality of Service
27.
RDB
Reference Database
28.
RFP
Request for Proposal
29.
SIP
Session Initiation Protocol
30.
SLA
Service Level Agreement
31.
SMS
Short Message Service
32.
TEC
Telecom Engineering Center
33.
TRAI
Telecom Regulatory Authority of India
34.
UASL
Unified Access Service License
Note: All definitions like telecom service provider, access service provider, etc., in
the document may be taken from the existing service licenses issued by the DoT, a
copy of the same is available on the DoT’s website.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 49/63

<!-- page 50 -->

B.

Definition of Terms and expressions

Unless the context otherwise requires, the different terms and expression used shall
have the meaning assigned to them in the following paragraphs:
1.

APPLICABLE SYSTEMS: The "applicable system" means all the necessary
equipment/ sub-systems engineered to provide MNP SERVICE in accordance
with operational/technical and quality requirements and other terms and
conditions of the Licence agreement.

2.

Auditor means the Licensee’s auditor for the time being appointed for the
purpose and in accordance with the provisions of the Companies Act, 1956.

3.

Cellular Mobile Telephone Service Provider (CMSP) means a licensee
authorised to provide cellular mobile telephone service under a licence, to provide
the service in a specified service area.

4.

Connectable System means a telecommunication system which is authorised to
be run under a Licence to provide public telecommunications service and is
authorised to be connected to the Applicable system.

5.

DIRECT EXCHANGE LINE (DEL): A telephone connection between the
subscriber’s terminal equipment and the terminal exchange.

6.

DOT means Department of Telecommunications, Government of India who is
also the Licensor. DoT & Licensor, wherever used in the Licence agreement are
inter-changeable.

7.

EFFECTIVE DATE: The effective date is the date which is so specified in this
license agreement.

8.

Emergency means an emergency of any kind, including any circumstances
whatever resulting from major accidents, natural disasters and incidents involving
toxic or radio-active materials.

9.

Emergency Services in respect of any locality means the relevant public, police,
fire and ambulance services for that locality.

10.

ENGINEERING: The technical application of the dimensioning rules and results
thereof in order to provide network resources to meet specified Grade of Service
(GOS).

11.

LICENCE: Licence means a Licence granted or having effect as if granted under
section 4 of the Indian Telegraph Act 1885 and Indian Wireless Act 1933.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 50/63

<!-- page 51 -->

12.

LICENSEE: A Company registered under the Companies Act, 1956 and the
bidder that has been awarded Licence to provide the MNP service in India.

13.

Message means anything falling within sub-section (3) of section 3 of the Indian
Telegraph Act 1885.

14.

“Mobile Switching Centre, also known as MSC” means the switching
equipment installed as a part of the network which performs all switching
functions of calls for providing various services under the scope of this Licence.
All the commercial information and data bases reside in the MSC.

15.

“Operator” means any person who is Licensed to run a Relevant Connectable
System;

16.

OR/QR Specifications means technical and quality requirements contained in the
OR/QR Specifications of Telecom Engineering Centre, Department of
Telecommunications unless otherwise specified.

17.

Public Switched Telephone Network (PSTN) means a fixed specified switched
public telephone network. A two-way switched telecommunications service to the
general public.

18.

Public Land Mobile Network (PLMN) means land based mobile network e.g.
Cellular Mobile Telephone Service being operated within the country under
Licence from Telecom Authority on non-exclusive basis.

19.

QUALITY OF SERVICE: "Quality of Service" is evaluated on the basis of
observable measure on the grade of service, Calls lost due to wrong processing,
the bit error rate or the response time and also includes acceptable grade of
number of faults per unit population of the subscriber served, the mean time to
restore (MTTR), faults carried over beyond the MTTR and the satisfactory
disposal thereof.

20.

Subscriber: Subscriber means any person or legal entity, which avails of the
Mobile Telecom Service from the Licensed telecom access service providers.

21.

TELECOM AUTHORITY: The Director General, Telecommunications,
Government of India and includes any officer empowered by him to perform all
or any of the functions of the Telegraph Authority under the Indian Telegraph
Act, 1885 or such authority as may be established by law.

22.

TRAI means Telecom Regulatory Authority of India constituted under the TRAI
Act, 1997 as amended from time to time.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 51/63

<!-- page 52 -->

ANNEXURE-II
(Performa for Affidavit regarding details of calculation of “Revenue” and “Licence Fee”)
AFFIDAVIT
I ……………………………….., aged about ………….. years son of Shri
…………………, resident of ………………………………………………., do
solemnly affirm and state as under:
2.

That I am …………… …………………….of ………………………… (Name
of the Company), LICENSEE of ………………………………………. Service in
…………………………..Service Area and I am duly authorised by the
resolutions dated …………………………. passed by Board of Directors of the
Company to furnish affidavit on behalf of ………………………….( Name of the
Company).

3.

That in compliance of Condition No.. ………. Of Schedule…………..Part
………. and Annexure……of the Licence Agreement No. ………………………
signed between the Company and the Department Of Telecommunications, for
payment of Licence fee, a payment of Rs. ………………….. (Rupees ……….
………………………. is being made for the period ………………….. to
………………………….. . The details of calculation of ‘revenue’ and Licence
fee is as per Appendix-II …… (attached).

4.

That the contents in para 2 & 3 and Statement made in Annexure ___ are true and
correct to the best of my knowledge, based on the records of the company.
Deponent.

VERIFICATION:
Verified at ___________ on ___________ that the contents of paragraphs 1 to 3
of this Affidavit and attached ‘Statement of Revenue and Licence Fee’ as Annexure are
true and correct to the best of my knowledge, no part of it is false and nothing has been
concealed therefrom.
Deponent.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 52/63

<!-- page 53 -->

APPENDIX –I TO ANNEXURE-II
Format of Auditor’s Report On Statement Of Revenue And Licence Fee
To
The Board of Directors
……………………….
……………………….
We have examined the attached Statement of Revenue and Licence Fee of
………………………………………(the name of the operators) for the quarter(s) ending
_____________. We have also examined the reconciliation of the cumulative figures for
the quarter(s) ending _________ appearing in the Statement of Revenue and Licence Fee
of the company with the figures appearing in the profit and loss account of the company
for the year ended_________ which was audited by us. We understand that the aforesaid
statement(s) ( and the reconciliation) is /are to be furnished to the Central Government for
assessment of the Licence fee payable by the company to the Government, in terms of the
Licence agreement No…………………. signed between the company and the
Department of Telecommunications.
We report that:
1.
2.

3.
4.

*

We have obtained all the information and explanations which to the best of our
knowledge and belief were necessary for the purposes of our audit.
In our view, the company has an adequate internal control system in relation to
revenues which is commensurate with its size and the nature of its business. The
system, in our opinion, provides reasonable assurance that there is no unrecorded
revenue and that all revenue is recorded in the proper amount and in the proper
period.
No amounts payable in respect of sales tax, service tax or PSTN/toll/roaming
charges were outstanding at the last day of the quarter(s) for a period of more than
two months from the date they became payable, except for the following:………
In our opinion and to the best of our knowledge and belief and according to the
explanations given to us, the Statement has been prepared in accordance with the
norms/guidelines contained in the said Licence agreement in this behalf and gives
a true and fair view of the revenue and Licence fee payable for the period
computed on the basis of the aforesaid guidelines except for the following:
Strike off wherever not applicable.
(SIGNATURE)

Draft Licence Agreement for MNP Services – 19.03.2009

Page 53/63

<!-- page 54 -->

APPENDIX-II TO ANNEXURE-II
Format of Statement of Revenue and Licence Fee
_____________________(Name and address of operator)
Mobile Number Portability in___________________( MNP Zone)
Statement of Revenue and Licence Fee for the Quarter
…………………………………
of the financial year………………………………………..
The Gross Revenue shall be inclusive of revenue from services, Porting fees, sale
proceeds of any software & hardware items, revenue on account of interest, dividend,
capital gains, value added services, supplementary services, access or interconnection
charges, revenue from permissible sharing of infrastructure and any other miscellaneous
revenue etc., without any set-off from related items of expense.
(Please note that mere mention of certain activities in this proforma does not
explicitly permit the licensee such activities)
S.N.

1.
(i)
(ii)

2.
(i)
(ii)
(iii)

(iv)
(v)
3.

PARTICULARS

ACTUALS
FOR
THE
PREVIOUS
QUARTER

(AMOUNT IN RUPEES)
ACTUALS
CUMULATIVE
FOR THE
UPTO THE
CURRENT
CURRENT
QUARTER
QUARTER.

Revenue from services
Revenue from Mobile
Number Porting fees
Revenue from Bureau/
Outsourcing/ Support
services
Revenue from other
services
sale proceeds of any
software items
sale proceeds of any
hardware items
Charges on account of
any
value added
services,
Supplementary Services
etc.
access
or
interconnection charges
any other revenue
Sales tax

Draft Licence Agreement for MNP Services – 19.03.2009

Page 54/63

<!-- page 55 -->

4.

Service tax

5.

Service charges

6.

Income
from
investments
Interest income
Dividend income
Any
other
miscellaneous receipt
from investments.
Non-refundable
deposits

(i)
(ii)
(iii)
7.
8.

Revenue
from
franchisees /resellers
including
all
commissions
and
discounts etc.

9.

Revenue
from
sharing/ leasing of
infrastructure

10.

GROSS REVENUE
OF THE LICENSEE
COMPANY:

11.
(i)

DEDUCT:
Service Tax actually
paid to the Government
Sales Tax actually paid
to the Government

(ii)
12.

TOTAL
DEDUCTIBLE
REVENUE

13.

ADJUSTED GROSS
REVENUE (AA-BB)

14.

REVENUE SHARE
@ ----------------- OF
ADJUSTED GROSS
REVENUE

Draft Licence Agreement for MNP Services – 19.03.2009

Page 55/63

<!-- page 56 -->

ANNEXURE –III
NORMS FOR PREPARATION OF ANNUAL FINANCIAL STATEMENTS
•
•
•

•
•
•

•
•
•
•
•
•
•
•

Accounts shall be maintained separately for the MNP Zone operated by the
LICENSEE company.
Any category of accrued revenue, the amount of which exceeds 5% of the total
accrued revenue, shall be shown separately and not combined with any other
item/category.
Accrued Revenue shall indicate:
(a) All amounts billable for the period.
(b) Any billings for previous years that had been omitted from the previous
years’ P&L Accounts.
(c) Any non-refundable deposits collected from the customers/franchisees to
the extent these are credited to P&L Account for the year.
Subsidiary registers/ledgers shall be maintained for each item given above so as to
enable easy verification.
Service revenue (amount billable) shall be shown gross and details of
discount/rebate indicated separately.
Security or any other Deposits taken from the subscriber shall be shown
separately, for each category, and the amount that has fallen due for refund but
not yet paid also disclosed under two categories, namely:
o Up to 45 days
o More than 45 days.
Service Tax billed, collected and remitted to the Government shall be shown
separately.
Sales Tax billed, collected and remitted to the Government shall be shown
separately.
Details of Income from sales of goods shall be furnished indicating the income
and number of items sold under each category. Method of inventory valuation
used shall also be disclosed along with computation of cost of goods sold.
Sales shall be shown gross and details of discount/rebate allowed and of sales
returns shall be shown separately.
Income from interest and dividend shall be shown separately, without any related
expenses being set-off against them on the income side of the P&L Account.
Increase/decrease of stock shall be shown separately.
Details of reversal of previous years’ debits, if any, shall be shown componentwise, under the miscellaneous head (eg. Bad debts recovered etc.)
Item-wise details of income that has been set off against corresponding
expenditure.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 56/63

<!-- page 57 -->

ANNEXURE-IV
PROFORMA FOR FINANCIAL BANK GUARANTEE
To
The President of India
In consideration of the President of India (hereinafter called ‘the Authority’) having
agreed to grant a Licence to M/s _____________________________________________
of _____________________________________ (hereinafter called ‘the LICENSEE’) to
establish, maintain and operate MNP Service (hereinafter called ‘the SERVICE’) in
________________ Zone (Name of MNP Zone) in accordance with the Letter of Intent/
Licence
No.______________________________________
dated
___________________ (hereinafter called ‘the Licence’) on the terms and conditions
contained in the said Licence, which inter-alia provides for production of a Bank
Guarantee
to
the
extent
of
Rs.__________________
(in
words
_________________________) under the said Licence by way of security for payment of
the said Licence fee as well as such other fees or charges required to be paid by the
LICENSEE under the Licence. We _______________ (indicate the name and address
and other particulars of the Bank) (hereinafter referred to as ‘the Bank’) at the request of
the LICENSEE hereby irrevocably and unconditionally guarantee to the Authority that
the LICENSEE shall pay all the dues, including but not limited to, the Licence fee etc. to
the Authority.
2.
We, the Bank, hereby undertake to pay the Authority an amount not exceeding
Rs………(Rupees…………only) against any loss or damage caused to or suffered or
would be caused to or suffered by the Authority by reason of any failure of the
LICENSEE to extend the validity of the guarantee or give a fresh guarantee in lieu of
existing one in terms of the Licence Agreement, pay all the above mentioned fees, dues
and charges or any part thereof within the periods stipulated in the Licence.
3.
We, the Bank, hereby further undertake to pay as primary obligor and not merely
as surety to pay such sum not exceeding Rs._________________________ (Rupees
_____________________ Only) to the Authority immediately on demand and without
demur stating that the amount claimed is due by way of failure of the LICENSEE to pay
any fees or charges or any part thereof in terms of the said Licence.
4.
WE, THE BANK, DO HEREBY DECLARE AND AGREE that the decision of
the Authority as to whether LICENSEE has failed to pay the said Licence fees or any
other fees or charge or any part thereof payable under the said Licence and as to the
amount payable to the Authority by the Bank hereunder shall be final and binding on us.
5.

WE, THE BANK, DO HEREBY DECLARE AND AGREE that the

(a)
Guarantee herein contained shall remain in full force and effect for a period of
Three Years from the date hereof and that it shall continue to be enforceable till all the

Draft Licence Agreement for MNP Services – 19.03.2009

Page 57/63

<!-- page 58 -->

dues of the Authority and by virtue of the said Licence have been fully paid and its
claims satisfied or discharged or till Authority satisfies that the terms and conditions of
the said Licence have been fully and properly carried out by the said LICENSEE and
accordingly discharged this guarantee.
(b)
The Authority shall have the fullest liberty without our consent and without
affecting in any manner our obligations hereunder to vary any of the terms and conditions
of the said Licence or to extend time of performance of any obligations by the said
LICENSEE from time to time or to postpone for any time or from time to time any of the
powers exercisable by the Authority against the said LICENSEE and to forbear or to
enforce any of the terms and conditions relating to the said Licence and we shall not be
relieved from our liability by reason of any variation or extension being granted to the
said LICENSEE or forbearance act or omission on the part of the Authority or any
indulgence by the Authority to the said LICENSEE or to give such matter or thing
whatsoever which under the law relating to sureties would but for this provision, have
effect of so relieving us.
(c)
Any claim which we have against the LICENSEE shall be subject and subordinate
to the prior payment and performance in full of all the obligations of us hereunder and we
will not without prior written consent of the Authority exercise any legal right or remedy
of any kind in respect of any such payment or performance so long as the obligations of
us hereunder remains owing and outstanding.
(d)
This Guarantee shall be irrevocable and the obligations of us herein shall not be
conditional of any prior notice by us or by the LICENSEE.
6.
We, the BANK, undertake not to revoke this Guarantee during its currency except
with the previous consent of the Authority in writing.
7.
Notwithstanding anything contained above, our liability, under the Guarantee
shall be restricted to Rs…… and our Guarantee shall remain in force until Three years
from the date hereof. Unless a demand or claim under this Guarantee is made on us in
writing within this date i.e. …. all your rights under the Guarantee shall be forfeited and
we shall be released and discharged from all liabilities thereunder.
Dated_______________ day ________________
Witness:
1…………………………..
……………………………
……………………………
……………………………
……………………………

Draft Licence Agreement for MNP Services – 19.03.2009

for _____________________
(Name of the Bank)
2…………………………..
……..……………………
……………………………
……………………………
……………………………

Page 58/63

<!-- page 59 -->

ANNEXURE -V
PROFORMA FOR PERFORMANCE BANK GUARANTEE
To
The President of India
In consideration of the President of India (hereinafter referred to as ‘the
Authority’)
having
agreed
to
grant
a
Licence
to
M/s
_____________________________________________of_________________________
___________ (hereinafter called ‘the LICENSEE’) to establish, maintain and operate
MNP Service (hereinafter called ‘the SERVICE’) in MNP Zone …… as per Letter of
Intent/ Licence No. ____________________ dated __________ (hereinafter called ‘the
said Licence’) on the terms and conditions contained in the said Licence, which inter-alia
provides for production of a Bank Guarantee to the extent of Rs.__________________
(in words _________________________) for the service by way of security for the due
observance and performance of condition 41 of the terms and conditions of the said
Licence. We _______________ (indicate the name and address and other particulars of
the Bank) (hereinafter referred to as ‘the Bank’) at the request of the LICENSEE hereby
irrevocably and unconditionally guarantee to the Authority that the LICENSEE shall
render all necessary and efficient services which may be required to be rendered by the
LICENSEE in connection with and/or for the performance of condition 41 of the said
LICENSEE and further guarantees that the service which shall be provided by the
LICENSEE under the said Licence, shall be actually performed in accordance with
condition 41 of terms & conditions of the LICENCE to the satisfaction of the Authority.
2.
We, the Bank, hereby undertake to pay the Authority an amount not exceeding
Rs…(Rupees…only) against any loss or damage caused to or suffered or would be
caused to or suffered by the Authority by reason of any breach by the said LICENSEE of
condition 41 of the terms and conditions contained in the said Licence including failure
to extend the validity of this guarantee or to give a fresh guarantee in lieu of the existing
one.
3.
We, the Bank hereby, in pursuance of the terms of the said Licence, absolutely,
irrevocably and unconditionally guarantee as primary obligor and not merely as surety
the payment of an amount of Rs._________________________ (Rupees
_____________________ Only) to the Authority to secure due and faithful performance
by the LICENSEE of all his/their obligations under condition 41 of the said Licence.
4.
We, the Bank hereby also undertake to pay the amounts due and payable under
this guarantee without any demur, merely on a demand from the Authority stating that the
amount claimed is due by way of loss or damage caused or would be caused to or
suffered by the Authority by reason of breach by the said LICENSEE of any of the terms
or conditions contained in the said Licence or by reason of the LICENSEE’s failure to
perform any of it’s obligations under condition 41 of the said Licence.”

Draft Licence Agreement for MNP Services – 19.03.2009

Page 59/63

<!-- page 60 -->

5.
We, the Bank, hereby agree that the decision of the Authority as to whether the
LICENSEE has failed to or neglected to perform or discharge his duties and obligations
under condition 41 as aforesaid and/or whether the service is free from deficiencies and
defects and is in accordance with or not of the condition 41 of terms & conditions of the
said Licence and as to the amount payable to the Authority by the Bank hereunder shall
be final and binding on the Bank.
6.
(a)

(b)

(c)

(d)

WE, THE BANK, DO HEREBY DECLARE AND AGREE that:
the Guarantee herein contained shall remain in full force and effect for a period of
Two Years from the date hereof and that it shall continue to be enforceable till all
the dues of the Authority and by virtue of the said Licence have been fully paid
and its claims satisfied or discharged or till Authority satisfies that the condition
41 of terms and conditions of the said Licence have been fully and properly
carried out by the said LICENSEE and accordingly discharged this guarantee.
the Authority shall have the fullest liberty without our consent and without
affecting in any manner our obligations hereunder to vary any of the terms and
conditions of the said Licence or to extend time of performance of any obligations
by the said LICENSEE from time to time or to postpone for any time or from time
to time any of the powers exercisable by the Authority against the said
LICENSEE and to forbear or to enforce any of the terms and conditions relating
to the said Licence and we shall not be relieved from our liability by reason of any
variation or extension being granted to the said LICENSEE or forbearance act or
omission on the part of the Authority or any indulgence by the Authority to the
said LICENSEE or to give such matter or thing whatsoever which under the law
relating to sureties would but for this provision, have effect of so relieving us.
any claim which we have against the LICENSEE shall be subject and subordinate
to the prior payment and performance in full of all the obligations of us hereunder
and we will not without prior written consent of the Authority exercise any legal
right or remedy of any kind in respect of any such payment or performance so
long as the obligations of us hereunder remains owing and outstanding.
This Guarantee shall be irrevocable and the obligations of us herein shall not be
conditional of any prior notice by us or by the LICENSEE.

7.
We the BANK undertake not to revoke this Guarantee during its currency except
with the previous consent of the Authority in writing.
8.
Notwithstanding anything contained above, our liability, under the Guarantee
shall be restricted to Rs…… and our Guarantee shall remain in force until Two years
from the date hereof. Unless a demand or claim under this Guarantee is made on us in
writing within this date i.e. …. all your rights under the Guarantee shall be forfeited and
we shall be released and discharged from all liabilities thereunder.
Dated_______________ day ________________
Witness:

for _____________________
(Name of the Bank)
1……………………………………………………………………..
2……………………………………………………………………..

Draft Licence Agreement for MNP Services – 19.03.2009

Page 60/63

<!-- page 61 -->

ANNEXURE-VI
LICENSED SERVICE AREAS OF MNP SERVICE ZONE – 1
Sr. No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.

Name of Licensed Service Areas

Category of Licensed Service Areas

Delhi
Mumbai
Maharashtra
Gujarat
Haryana
Punjab
Rajasthan
Uttar Pradesh (E)
Uttar Pradesh(W)
Himachal Pradesh
Jammu & Kashmir

Metro
Metro
A
A
B
B
B
B
B
C
C

LICENSED SERVICE AREAS OF MNP SERVICE ZONE – 2
Sr. No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.

Name of Licensed Service Areas

Category of Licensed Service Areas

Kolkata
Tamil Nadu including Chennai
Andhra Pradesh
Karnataka
Kerala
Madhya Pradesh
West Bengal
Assam
Bihar
North East
Orissa

Draft Licence Agreement for MNP Services – 19.03.2009

Metro
A
A
A
B
B
B
C
C
C
C

Page 61/63

<!-- page 62 -->

ANNEXURE-VII
DETAILS OF LICENCED SERVICE AREA IN THE COUNTRY UNDER UASL /
CMTS LICENCE
Sl.
Name of
Areas covered
No. Service Area
01.
West
Bengal Entire area falling within the Union Territory of Andaman & Nicobar
Service Area
Islands and area falling within the State of West Bengal and the State
of Sikkim excluding the areas covered by Kolkata Metro Service
Area.
02. Andhra Pradesh Entire area falling within the State of Andhra Pradesh.
Service Area
03. Assam Service Entire area falling within the State of Assam.
Area
04. Bihar
Service Entire area falling within the re-organised State of Bihar and newly
Area
created State of Jharkhand pursuant to the Bihar Reorganisation Act,
2000 (No.30 of 2000) dated 25th August, 2000.
05. Gujarat Service Entire area falling within the State of Gujarat and Union Territory of
Area
Daman and Diu, Silvassa (Dadra & Nagar Haveli).
06. Haryana Service Entire area falling within the State of Haryana except Panchkula
Area
town and the local areas served by Faridabad and Gurgaon Telephone
exchanges.
07. Himachal
Entire area falling within the State of Himachal Pradesh
Pradesh Service
Area
08. Jammu
& Entire area falling within the State of Jammu & Kashmir including
Kashmir Service the autonomous council of Ladakh.
Area
09. Karnataka
Entire area falling within the State of Karnataka
Service Area
10. Kerala Service Entire area falling within the State of Kerala and Union Territory of
Area
Lakshadeep and Minicoy.
11. Madhya Pradesh Entire area falling within the re-organised State of Madhya Pradesh
Service Area
as well as the newly created State of Chattisgarh pursuant to the
Madhya Pradesh Reorganisation Act, 2000 (No:28 of 2000) dated
25th August, 2000.
12. Maharashtra
Entire area falling within the State of Maharashtra and Union
Service Area
Territory of Goa, excluding areas covered by Mumbai Metro Service
Area.
13. North
East Entire area falling within the States of Arunachal Pradesh,
Service Area
Meghalaya, Mizoram, Nagaland, Manipur and Tripura.
14. Orissa Service Entire area falling within the State of Orissa.
Area
15. Punjab Service Entire area falling within the State of Punjab and Union territory of
Area
Chandigarh and Panchkula town of Haryana.
16. Rajasthan
Entire area falling within the State of Rajasthan.
Draft Licence Agreement for MNP Services – 19.03.2009

Page 62/63

Category
B

A
C
C
A
B
C
C
A
B
B

A
C
C
B
B

<!-- page 63 -->

Service Area
17. Tamilnadu
Service
Area
(including
Chennai Service
Area)
17A Tamilnadu
.
Service
Area
(excluding
Chennai Service
Area)*
17B Chennai Service
.
Area*
18.

19.

Uttar
(West)
Area

Pradesh
Service

Entire area falling within the State of Tamilnadu and Union Territory
of Pondichery including Local Areas served by Chennai Telephones,
Maraimalai Nagar Export Promotion Zone (MPEZ), Minzur and
Mahabalipuram Exchanges

A

Entire area falling within the State of Tamilnadu and Union Territory
of Pondichery excluding
Local Areas served by Chennai
Telephones, Maraimalai Nagar Export Promotion Zone (MPEZ),
Minzur and Mahabalipuram Exchanges

A

Local Areas served by Chennai Telephones, Maraimalai Nagar
Export Promotion Zone (MPEZ), Minzur and Mahabalipuram
Exchanges
Entire area covered by Western Uttar Pradesh with the following as
its boundary districts towards Eastern Uttar Pradesh : Pilibhit,
Bareilly, Badaun, Etah, Mainpuri and Etawah. It will exclude the
local telephone area of Ghaziabad and Noida. However, it will also
include the newly created State of Uttaranchal pursuant to the Uttar
Pradesh Re-organisation Act, 2000 (No.29 of 2000) dated 25th
August, 2000.
Entire area covered by Eastern Uttar Pradesh with the following as its
boundary districts towards Western Uttar Pradesh : Shahjahanpur,
Farrukhabad, Kanpur and Jalaun.
Local Areas served by Delhi, Ghaziabad, Faridabad, Noida, and
Gurgaon Telephone Exchanges
Local Areas served by Calcutta Telephones.

A

Uttar
Pradesh
(East)
Service
Area
20. Delhi
Service
Area
21. Kolkata Service
Area
22. Mumbai Service Local Areas served by Mumbai, New Mumbai and Kalyan Telephone
Area
Exchanges
* No new UAS licence is being issued for Sl. No. 17A and 17B after 15.09.2005.
NOTE:
1. Yenum, an area of Union Territory of Pondicherry is served under Andhra Pradesh
Telecom Circle in East Godavari LDCA.
2. The definition of Local areas of exchanges will be as applicable to the existing
cellular operators, i.e. at the time of grant of cellular Licences in Metro cities.
3. The definition of local areas with regard to the above service area as applicable to this
Licence is as per definition applicable to Cellular Mobile Service Licences as in the
year 1994 & 1995, when those Licences were granted to them. This is in accordance
with respective Gazette Notification for such local areas wherever issued and as per
the statutory definition under Rule 2 (w) Indian Telephones Rules, 1951, as it stood
during the year 1994/1995 where no specific Gazette Notification has been issued.

Draft Licence Agreement for MNP Services – 19.03.2009

Page 63/63

B

B
Metro
Metro
Metro
