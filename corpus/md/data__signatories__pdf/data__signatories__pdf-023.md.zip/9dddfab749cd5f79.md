---
doc_id: "9dddfab749cd5f79"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/7f67dbf4b392e92109d8d0ac7c803c97.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Unified License up to 03.09.2014"
date: "2014-09-03"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4fd62987219943a6"
---

<!-- page 1 -->

44444444444444444444444444444444444444444

aa
OO

4

4

Oayaayyayyyyayy

a mmm)mll lmmmammmlm

amlmmlmmmKmamal4amammmal

4

mmmlmmmmmt mmm mlmmmmmmmmmmammmlm

a aayya
aay ayya
yayaa a
eaaayaa

al lyaala ayya a aal
aaaaaaa

a4mm mlm3mllmmm)amm lmmmlmalmmamlmal

4

a aayya
al lyaala ayy

mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
44a44a4444 mmmmmmmmmmmmmm

mmmmm
lmmlmlmllml
aalamlm
tamltmtmml
44a44a4444
mmmlmtm m
mmmmmmmmmmmmmm
)mlmlm)tmllmm)
mmmmmmmmmmmmmm KKa
mmmmmmmmmmmmmm ammmmm
mmmmmmmmmmmmmm mllm)mmmlmm
taa
tmlmalmlmmmmm
aaa
tmlmalmlmmmmm
aaaa
aa4444a44aa4a
44a44a4444
44a44a4444
aaa m
tmlmalmlmmmmm
aaaaa4aaaaa aa4444a44aa4a

amaaama
ammmlmmaaa)
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
44a44a4444 mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
taammmmmmmmm
mmmmmmmmmmmmmm

4

aaaaaaaaaaaa

4444444444

a4mmmm4 m mmtlalalmmmmammmlm

4444444444

4

a4mmd ltmmm)amm lmmmlmalmmal mmmammmlm

4444444444

4

a4mmm4mmllm mlmmammal mmmammmmlmmammmlm

4444444444

tmlmalmlmmmmm
tmlmalmlmmmmm
amltm
t tmmml
ammlmlmam
ammmlm
4444444444
aalamlm
mmmlmtm m
)am)lmml)
lmmlmlmllml
aa4444a44aa4a 4444444444
a44 aa4
haa444
r4 aa
tttaaa4
4444444444
aa aaa4 4aa

mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm
mmmmmmmmmmmmmm )a)tmml)
mmmmmmmmmmmmmm )a)lmml)
taa
tmlmalmlmmmmm
aaa
aa4444a44aa4a
mmmmmmmmmmmmmm mmmmm
aahaaaa
aa4444a44aa4a
amam)mlmlam amm aa4444a44aa4a
taammmmmmmm
aa4444a44aa4a
a4a4a4aa4444
aa4444a44aa4a
))tmTmm
aa4444a44aa4a
taam
aa4444a44aa4a
taa
aa4444a44aa4a
a4a
aa4444a44aa4a
amam)mlmlam amm aa4444a44aa4a

4444444444
4444444444

4444444444
4444444444
4444444444
4444444444
