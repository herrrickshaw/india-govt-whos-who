---
doc_id: "74cfc6f158bffa4e"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/a5d0fd505315bae28a00769e8cc51043.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "PaymentMethodologyAndPaymentDetails"
date: "2015-03-29"
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3fa45d689666a788"
---

<!-- page 1 -->

F.No.1000/23/2014 -WF/Auction
Government of India
Ministry of Communication & IT
Department of Telecommunications
29th March, 2015
Subject: Auction of Spectrum in 800MHz, 900MHz, 1800MHz and 2100MHz bands,
Spectrum Auction February 2015: Update on Payment Methodology: Intimation of
amounts due

Kindly refer to Section 4.5 (Payment Terms) of the Notice Inviting Applications dated
09-01-2015 in respect of the Spectrum Auction February 2015. In continuation of the email
dated 26-03-2015 and 27-03-2015, you are hereby intimated the amounts due and the same are
enclosed as Annexure to this letter. Payments can be made through following method:
Through Real Time Gross settlement (RTGS)/ Core Banking facility as per the
following instructions:­
(A) The Successful Bidder's request to its Bank for transfer through RTGS, which is used
for inter-bank transfers of money: or through Core Banking, if its account is with
State bank of India (SBI), should contain the following details:
(i)
Bidder's name and Account holder's name;
(ii)
Branch's name: SBI New Delhi, Main Branch, IFSC Code
SBIN0000691
(iii)
Name of the Ale : "Spectrum Auction";
(iv)
Account No. : 32647292194
(B) Successful Bidders need to ensure that the remitting Bank puts "Bidder's name and
the number of services area/s for which the payment pertains" under the column
"sender to Receiver information" in case of RTGS, or in the "NaiTation Line" in case
ofremitting bank being SBI (core banking) while transferring the money.
(C) Successful Bidders must take the UTR Number (in case of RTGS) or Journal Number
(in case remitting bank is SBI and method of transfer is core banking) of credit
transaction to the Account as detailed in (A) above and mail the following
inf01mation to spectrumauction-dot@nic.in ai1d aoac2.hg-dot@nic.in
(a) In case ofRTGS-UTR Number of credit transaction.
OR
In case of Core Banking (Remitting bank being SBI)­
(i)
Journal Number of the credit transaction;
(ii)
SBI Account Number from which the amount has been transferred;
(iii)
Cheque Number (if any) used to transfer the money;
(iv)
Date of transaction.
(b) Name of the Company;
(c) Total amount transferred;

<!-- page 2 -->

(d) Names of the service areas and the corresponding amounts for each of the service
areas (total should tally with the figure at (C) above.)
Please note that the last date for payment is 08-04-2015. It is also clarified that upfront
payment of amount greater than the specified amounts (which is sum total of 25% and 33% of
the total amount due in relevant bands) in the enclosed letter can be made and in such a scenario,
the value of installments and required bank guarantees would be revised pro-rata for the
remaining amount.
Further, if it is proposed to make any partial payment of the proposed upfront due in
advance, the same may please be indicated. It may be noted that in such case the payment date,
for the purpose of the further annual installments, shall be the anniversary of the date on which
the balance payment of upfront is made withiri the stipulated time, as indicated above.

It may also be noted that if the payment is not received by the last date, the EMD will be
forfeited. This will be without prejudice to any other action that DoT might take. The Bidder­
wise amounts payable is attached.
After making the payment, the Successful Bidders may apply in accordance with NIA
provisions. Kindly note that as_intimated earlier the allocations of Spectrum are subject to final
result of SLP (c) Nos.5735-5736 of2015 , Transfer Petition (Civil) Nos.352-356, 363 and 477 all
of 2015(order of Hon' ble Supreme Court has already been uploaded on DoT website and mailed
to all bidders).

Encl: as above (one)
-Sd­
(V. N. TANDON)
Director (WF)
Ph.23036215
9868217076
To all successful bidders in the Spectrum auction in respect of NIA issued on 09-01-2015 (as
amended from time to time).
Copy to:
(i)
(ii)
(i)
(ii)

Wireless Advisor, Do T
DDG (AS-I)
Director (WR)/ADG(WR)
Director (TA-II)/PAO (HQ), DoT- He may book the amounts received under HoA
127500-103-01-02

<!-- page 3 -->

M/s. Aircel Ltd
Service Areas -1800

Total

MHz Band

Blocks Spectrum

Payable - Full Upfront

Won

Won (per

Payment Option (Rs.)

(No.)

Block)

Total Winning Amount

(Rs Crores)

Payable

Price of

Total Winning Amount Upfront Payment
Amount - Deferred

Installment and FBG
Amount - Deferred

Payment Option (33% of Payment Option

(Rs.)

Upfront Payment (Rs)

(Rs)

<!-- page 4 -->

M/s. Bharti Airtel Ltd
Service Areas -900
MHz Band

AP
Assam
Bihar
HP
Karnataka
NE
Odisha
Punjab
Rajasthan
WB
Total

Total
Blocks
Won
(No.)

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (25% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)

Price of
Spectrum
Won (per
Block)
(Rs Crores)

45
31 !
8
37 i
44
44 !
6
5o j
30
11 !
306

136.15
36.99!
88.86
11.49 !
111.50
10.38!
27.80
72.15 !
141.73
41.SO!

61267500000
11466900000 !
7108800000
4251300000 !
49060000000
4567200000 !
1668000000
36075000000 !
42519000000
4565000000 !
222,548,700,000

No. of Service Areas in which Blocks Won
Service Areas -1800
MHz Band

Andhra Pradesh
Haryana
Kolkata
North East
Odisha
Punjab
Total

Price of
Spectrum
Won (per
Block)
(Rs Crores)

Total
Blocks
Won
(No.)

6
17 !
10
8l
31
I

sj

48.56
9.32 !
29.82
2.20 :
6.62
14.20!

77

Total
Blocks
Won
(No.)

2913600000
1584400000 i
2982000000
164862114 !
2052200000
710000000 i
10,407,062,114

.

Price of
Spectrum
Won (per
Block)
(Rs Crores)

Gujarat

li

Haryana
MP
Maharashtra
Odisha
Tamil Nadu
UP (E)
Total

1
1!
1

1;
1
1!
7

961488000
522852000 !
984060000
54404498 !
677226000
234300000 !
3,434,330,498

384420384
209045736
393445080
21751907
270767268
93677400
1,373,107,775

6
Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (33% of Payment Option
(Rs)
Total Winning Amount
Payable
(Rs.)

1290.00 •
230.00
456.75 !
1505.00
180.26 !
1720.00
451.50 ;
"

12900000000 !
2300000000
4567500000 !
15050000000
1802600000 !
17200000000
4515000000 :
58,335,100,000

No. of Service Areas in which Blocks Won
M/s. Bharti Airtel Ltd

9048597075
1693546461
1049898672
627874497
7245671400
674529768
246346920
5327916750
6279631110
674204850
32,868,217,503

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.) Payment Option (33% of Payment Option
Total Winning Amount
(Rs)
Payable v
(Rs.)

No. of Service Areas in which Blocks Won
Service Areas -2100
MHz Band

15316875000
2866725000 !
1777200000
1062825000 !
12265000000
1141800000 !
417000000
9018750000 !
10629750000
1141250000 !
55,637,175,000
10

4257000000 \
759000000
1507275000 !
4966500000
594858000 !
5676000000
1489950000 \
19,250,583,000

1702026000
303462000
602635950
1985697000
237835044
2269368000
595709100
7,696,733,094

7
Amount Payable
(Rs)

Upfront Payment (Rs)

Installment & FBG
Amount (Rs)

<!-- page 5 -->

M/s. Idea Cellular Ltd
Service Areas -900
MHz Band

AP
Gujarat
Haryana
Karnataka
Kerala
MP
Maharashtra
Punjab
UP(W)
Total

Total
Blocks
Won
(No.)

Price of
Spectrum
Won (per
Block)
(Rs Crores)

25
25 !
30
25 !
30
37 !
45
28 [
25

Total Winn ing Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.) Payment Option (25% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)

136.15
134.60 !
30.24
lll.50 j
73.88
61.90 !
154.60
72.15 j
147.71

270

34037500000
33650000000 !
9072000000
27875000000 !
22164000000
22903000000 i
69567089490
20202000000 !
36927500000

8509375000
8412500000 !
2268000000
6968750000 !
5541000000
5725750000 !
17391772372
5050500000 !
9231875000

5026998375
4969768500
1339843680
4116858750
3273401160
3382544070
10274363447
2983633380
5453822475

276,398,089,490

69,099,522,372

40,821,233,837

No. of Service Areas in which Blocks Won
Service Areas -1800
MHz Band

Himachal Pradesh
Karnataka
North East
Odisha
TamilNadu
UP West
Total

Total
Blocks
Won
(No.)

24
5
5
25
32
11

Price of
Spectrum
Won (per
Block)
(Rs Crores)

3.18
37.00
2.20
6.62
45.00
19.19

102

9
Installment and FBG
Total Winning Amount Upfront Payment
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.) Payment Option (33% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)

755380638
1850000000
103038821
1655000000
14400000000
1587571823

249275610
610500000
34002811
546150000
4752000000
523898701

99664921
244089000
13594942
218360700
1899936000
209464226

20,350,991,282

6,715,827,123

2,685,109,790

No. of Service Areas in which Blocks Won
Service Areas -2100
MHz Band

Total
Blocks
Won
(No.)

Price of
Spectrum
Won (per
Block)
(Rs Crores)

6
Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (33% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)

Amount Payable
(Rs)

Upfront Payment (Rs)

<!-- page 6 -->

M/s. Reliance Communications Ltd
Service Areas -800
MHz Band

Assam
Gujarat
Haryana
HP

J&K
Kolkata

NE
Odisha
Punjab
UP(W)
WB
Total

Total

Price of

Blocks Spectrum
Won
Won (per
(No.) Block)
(Rs Crores)
4
2
1
2
2
1
4
1
2
1
1
21

102.77
347.18
70.71
24.46
35.35
183.75
31.72
51.30
107.31
118.75
71.25
1144.55

Installment and FBG
Total Winning Amount Upfront Payment
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (25% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)
4110800000
6943600000
707100000
489200000
707000000
1837500000
1268800000
513000000
2146200000
1187500000
712500000
20,623,200,000

INo. of Service Areas in which Blocks Won
Service Areas -900
MHz Band

HP

Total
Blocks
Won
(No.)

Price of
Spectrum
Won (per
Block)
(Rs Crores)

25

11.49

Haryana
Karnataka
North East
Odis ha
Punjab
Total

Total
Blocks
Won
(No.)

Price of
Spectrum
Won (per
Block)
(Rs Crores)

3
3
20
25
3
54

9.32
37.00
2.20
6.62
14.20

72249948
104416830
271380375
187389072
75764970
316972278
175381875
105229125
3,045,840,408

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.) Payment Option (25% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)
2872500000

718125000

424239525

2
Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.) Payment Option (33% of Payment Option
(Rs)
Total Winning Amount
Payable
(Rs.)
279600000
1110000000
463607288
1655000000
426000000
3,934,207,288

No. of Service Areas in which Blocks Won
M/s. Reliance Communications Ltd

607124052
1025500284
104431599

11

!No. of Service Areas in which Blocks Won
Service Areas -1800
MHz Band

1027700000
1735900000
176775000
122300000
176750000
459375000
317200000
128250000
536550000
296875000
178125000
5,155,800,000

92268000
366300000
152990405
546150000
140580000
1,298,288,405

36890424
146453400
61168346
218360700
56206440
519,079,310

5
Amount Payable
(Rs)

Upfront Payment (Rs)

Installment & FBG
Amount (Rs)

<!-- page 7 -->

,.

M/s. Reliance JIO lnfocomm Ltd.
Service Areas -800
MHz Band

Assam
Bihar
Haryana
HP
J&K
MP
Mumbai
NE
Odisha
UP (E)
Total

Total

Price of
Blocks Spectrum
Won
Won (per
(No.) Block)
(Rs Crores)

4
4
4
4
4
4
4
4
4
3
39

102.77
107.31
70.71
24.46
35.35
510.49
909.37
31.72
51.30
167.50

Total Winning Amount Upfront Payment
Installment and FBG
Amount - Deferred
Payable - Full Upfront Amount - Deferred
Payment Option (Rs.) Payment Option (25% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)

4110800000
4292400000
2828400000
978400000
1414000000
20419600000
36374800000
1268800000
2052000000
5025000000
78,764,200,000

No. of Service Areas in which Blocks Won
Service Areas -1800
MHz Band

Total
Blocks
Won
(No.)

Haryana

20

Himachal Pradesh
Kolkata
Rajasthan
TamilNadu
UP East
Total

50
3
15
88

Price of
Spectrum
Won (per
Block)
(Rs Crores)

9.32
3.18
29.82
14.55
45.00
21.39

1r;

· -

• :1';11

607124052
633944556
417726396
144499896
208833660
3015770724
5372194212
187389072
303059880
742142250
11,632,684,698

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.) Payment Option (33% of Payment Option
Tota l Winning Amount
(Rs)
Payable
(Rs.)

1864000000
858600000
7455000000
4434090680
1350000000
2906923472
18,868,614,152

No. of Service Areas in which Blocks Won
M/s. Reliance JIO lnfocomm Ltd.

1027700000
1073100000
707100000
244600000
353500000
5104900000
9093700000
317200000
513000000
1256250000
19,691,050,000
10

615120000
283338000
2460150000
1463249924
445500000
959284746
6,226,642,670

245936160
113283684
983612700
585033924
178119000
383539483
2,489,524,951

6
Amount Payable
(Rs)

Upfront Payment (Rs)

Installment & FBG
Amount (Rs)

<!-- page 8 -->

r

M/s. Tata Teleservices Ltd
Service Areas -800
MHz Band

Total
Blocks
Won
(No.)

AP

3
1
1
2
2

Delhi
Haryana
Maharashtra
Mumbai
Total

Price of
Spectrum
Won (per
Block)
(Rs Crores)
757.48
1059.62
70.71
999.27
909.37

9

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (25% of Payment Option
Total Winning Amount
(Rs)
Payable
(Rs.)
22724400000
10596200000
707100000
19985400000
18187400000

5681100000
2649050000
176775000
4996350000
4546850000

3356166636
1564952778
104431599
2951643726
2686097106

72,200,500,000

18,050,125,000

10,663,291,845

5

No. of Service Areas in which Blocks Won
Service Areas -1800
MHz Band

Total
Blocks
Won
(No.)

Andhra Pradesh
Total

13

Price of
Spectrum
Won (per
Block)
(Rs Crores)
48.56

13

Total Winning Amount Upfront Payment
Installment and •FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (33% of Payment Option
Payment Option (Rs.)
(Rs)
Total Winning Amount
Payable
(Rs.)
6,312,800,000

2,083,224,000

832,910,832

6,312,800,000

2,083,224,000

832,910,832

1

!No. of Service Areas in which Blocks Won
M/s. Tata Teleservices Ltd

Amount Payable
(Rs)
7~:""~= -: 1111 11 11111 1

Upfront Payment (Rs)
i'.J llll

Installment & FBG
Amount (Rs)

<!-- page 9 -->

r· '

M/s. Vodafone India Ltd
Service Areas -900
MHz Band

Total
Blocks
Won
(No.)

Gujarat

Price of
Spectrum
Won (per
Block)
(Rs Crores)

30 i
31
32
25
25
32
28
11

Haryana
Kerala
Maharashtra
Odisha
Rajasthan
UP ( E)
WB
Total

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (25% of Payment Option
(Rs)
Total Winning Amount
Payable
(Rs.)

134.60!
30.24
73.88
154.60
27.80
141.73
155.12
41.50

214

40380000000 !
9374400000
23641600000
38648383050
6950000000
45353600000
43433600000
4565000000

10095000000 !
2343600000
5910400000
9662095762
1737500000
11338400000
10858400000
1141250000

5972202000
1386473760
3496592640
5707979693
1027905000
6707797440
6423829440
675163500

212,346,583,050

53,086,645,762

31,397,943,473

No. of Service Areas in which Blocks Won
Service Areas -1800
MHz Band

Total
Blocks
Won
(No.)

Gujarat

8

Price of
Spectrum
Won (per
Block)
(Rs Crores)

17

Total Winning Amount Upfront Payment
Installment and FBG
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (33% of Payment Option
Payment Option (Rs.)
Total Winning Amount
(Rs)
Payable
(Rs.)

47.60

5
29.82
6
21.39
28
No. of Service Areas in which Blocks Won

Kolkata
UP East
Total

Service Areas· -2100
MHz Band

Total
Blocks
Won
(No.)

Assam
Karnataka
Kera la
NE
Rajasthan
UP(W)
Total

Price of
Spectrum
Won (per
Block)
(Rs Crores)

1
11
1

1j
1

1!

2203587202
275385000
383713898

881034229
110103930
153415793

8,674,806,364

2,862,686,100

1,144,553,952

3
Installment and FBG
Total Winning Amount Upfront Payment
Payable - Full Upfront Amount - Deferred
Amount - Deferred
Payment Option (Rs.)
Payment Option (33% of Payment Option
(Rs)
Total Winning Amount
Payable
(Rs.)

193.18
1642.36 !
588.57
55.35 j
699.12
525.35 !

6

6677536975
834500000
1162769389

.

1931800000
16423600000 !
5885700000
553500000 [
6991200000
5253500000 1

637494000
5419788000 !
1942281000
182655000 !
2307096000
1733655000 !

37,039,300,000 _

_12,222,969,000

!No. of Service Areas in which Blocks Won
M/s. Vodafone India Ltd

254881692
2166929784
776559258
73028790
922418928
693146790
_

4,886,965,242

6
Amount Payable
(Rs)

Upfront Payment (Rs)

Installment & FBG
Amount (Rs)
