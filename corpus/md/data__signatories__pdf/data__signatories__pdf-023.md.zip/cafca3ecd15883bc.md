---
doc_id: "cafca3ecd15883bc"
source_url: "https://www.dot.gov.in/static/uploads/2026/08/42bf894aa6ed4629c0d7cac1c33d31a8.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code '104' to Health Information Helpline' to State Govt. of Chhattisgarh regarding"
date: "2013-08-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8954f6a6ad821f7d"
---

<!-- page 1 -->

F.No.16-3."201 l-A5-111"26'l _{(,b
CluYern111ent of india
!Vlinistr: ofC:on1n1unication & lnforn1ation Technolog:
Depann1en1 of Teleco1nn1un ications
.Access Services \Ving
20. Ashoka Road. Ne"' Delhi- I I 0001

Dated 27108"2013
To
.i\.11 .A..ccess Service Providers

Subject: Allocation of Short Code '104' as 'Health Information Helpline' to State Govt.
of Chhattisgarh regarding.

I am directed to convey the approval of competent authorit\" for allocation of Short
Code · 104 · as 'Health Information Helpline' to State Govt. of Chhattisgarh.
The features of the Helpline are as stated below:
(i)

Category-! Sc1vice (i.e. mandatory serv"ice to be provided bY ali the -.\ccess
Service providers)

(ii)

Accessibility:
Chhattisgarh.

(iii)

Metered !Calling Part\ Pavs)

Restricted within the jurisdiction ·of State Government of

~- /"'.'-, \ i

c~~~)1')
(Narayan'l&am)
Section Officer (AS-III)
Tel: Fax :23 7 10488

Copy forwarded for information and necessary action. if any. to:
1.
3.
4.
5.
6.
7.
8

Secretary, TRAl
Sr. DDG (TEC)
CMD, BSNL
CMD. MTNL
Chief Secretary, State Govt. ofChhattisgarh.
The Director Health Service. Govt. of Chhattisgarh. D.K.Campus. Raipur. Chhattisgarh
with reference to your letter No. N il.12013 dated 19.08.2013.
Dire r (S-1). DoT. HQ with request to circulate the sanction to related TERM Cells.
irector (lT) with request to kindly upload on DoT Website.
