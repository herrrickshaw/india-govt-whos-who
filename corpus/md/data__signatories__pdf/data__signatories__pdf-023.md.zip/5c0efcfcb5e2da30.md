---
doc_id: "5c0efcfcb5e2da30"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/b644aafa9923cd5e51860e293cea8b91.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Auction of 3G and BWA Spectrum – Response to queries"
date: "2008-12-15"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e3fef27a6f4d0308"
---

<!-- page 1 -->

Auction of 3G and BWA Spectrum – Response to queries

Auction of 3G and BWA Spectrum – Response to queries
Table 1.

Information Memorandum

Date

Issue raised

Response

13-Dec-08;
Saturday

We are finding that para 1.1.8
(page 8) has specified as last
date for submission of
application as 31st December
2008, while Table 3 on page
13 the last date is mentioned
as 5th January 2009.

The last date for submission of
Application is 5th January, 2009.
Changes, if any, will be
communicated through the DoT
Auction website.
Accordingly, Recipients are advised
to note that the dates mentioned in
para 1.1.8 (page 8) and para 7.2.1
(page 46) of the Information
Memorandum stand corrected to 5th
January, 2009.

Updated on 15th December, 2008
