---
doc_id: "07ff9ae1be5f2c6f"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/d44ed6bd24029d87f68eee7b99fcd4eb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Unified Licences up to 27.11.2013"
date: "2013-11-27"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2bc96bc9d1d598c2"
---

<!-- page 1 -->

List of Unified licences Up to 27.11.2013
S NO

Name of Company

Date of grant of
Unified Licence

Authorisation detail

Date of Authorisation

1 Idea Cellular Limited

Access Service-Assam
Access Service-West Bengal
Access Service- Kolkata
Access Service- North East
11-Oct-13
Access Service- Tamil Nadu
(Incl. Chennai)
Access Service- J&K Access
Service- Orissa

11-Oct-13

2 Reliance Jio Infocomm Ltd

Access Service
NLD (National Area)
ILD (National Area)
VSAT (National Area)
PMRTS
INSAT
21-Oct-13
MSS-R (National Area) ISP "A"
(National Area)
ISP "B"
(Telecom circle/Metro Area)
ISP "C" (SSA)
Resale IPLC(National Area)

21-Oct-13

Access Service- Delhi
Access Service- Gujarat
Access Service- Karnataka
Access Service- Kerala
3-Oct-13
Access Service- Kolkata
Access Service- Tamil Nadu
Access Service- UP(West)
Access Service- West Bengal

3-Oct-13

Access Service-Andhra
Pradesh
Access Service-Bihar Access
Service- Gujarat Access
Service- Maharashtra Access
Service- UP (East)
Access Service- UP (West)

27.11.2013

3

4

Sistema Shyam
Teleservices Limited

M/s Telewings
Communications Pvt Ltd

27.11.2013
