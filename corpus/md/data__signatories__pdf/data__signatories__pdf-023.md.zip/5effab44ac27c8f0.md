---
doc_id: "5effab44ac27c8f0"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/8bacea82d59158715d054fb638dee70f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "3G Auction: Ownership details of Applicants"
date: "2010-03-23"
pages: 78
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ef68154cef74ebe3"
---

<!-- page 1 -->

Auction of 3G Spectrum

Applicant ownership
details

<!-- page 2 -->

Auction of 3G Spectrum: Ownership details of Applicants
(as submitted by the Applicants)
Ownership details of the following Applicants for the 3G Auction are provided in this
document.
Aircel Limited
Bharti Airtel Limited
Etisalat DB Telecom Private Limited
Idea Cellular Limited
Reliance Telecom Limited
S Tel Private Limited
Tata Teleservices Limited
Videocon Telecommunications Limited
Vodafone Essar Limited
Notes:
1.
2.
3.

4.

5.
6.

These details are as submitted by the Applicants. The Department of Telecommunications has not
verified the accuracy of the information
The Applications are still being reviewed. Publication of this list in no way implies that the
Applicants will be pre-qualified merely on submission of the Ownership Compliance Certificate
Duly executed Ownership Compliance Certificate must be submitted in hard copy, during office
hours before 5:00 p.m. (Indian Standard Time) on 26th March, 2010 at the following address:
Joint Secretary (Telecom)
Department of Telecommunications – Auction Team
Room no 319, Department of Telecommunications,
Sanchar Bhawan,
20 Ashoka Road,
New Delhi
Six sets (one original and five copies) of the Ownership Compliance Certificate need to be
submitted in a single sealed cover. Name and address of the Applicant must be clearly visible on
the sealed cover. The original must be marked as Original. Five photocopies of the Original
(certified by Company Secretary or Authorised Signatory) must also be submitted and clearly
marked as Copy No.: ___
The Applicants should also submit scanned soft copy of the Original on CD-ROM/ DVD in a
single “pdf” document
In case of discrepancies between the copies and the Original, the Original shall prevail. However,
the Government also reserves the right to summarily reject Applications in case of discrepancies
between the copies and the Original.

<!-- page 3 -->

Aircel Limited

<!-- page 4 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 5 -->

<!-- page 6 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 7 -->

<!-- page 8 -->

Shareholding details of
Associated Licensees that have
nominated the Applicant as a
Group Bidding Entity

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

Bharti Airtel Limited

<!-- page 12 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 13 -->

<!-- page 14 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->

<!-- page 18 -->

Shareholding details of
Associated Licensees that have
nominated the Applicant as a
Group Bidding Entity

<!-- page 19 -->

<!-- page 20 -->

Etisalat DB Telecom
Private Limited

<!-- page 21 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 22 -->

<!-- page 23 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 24 -->

<!-- page 25 -->

Shareholding details of
Associated Licensees that have
nominated the Applicant as a
Group Bidding Entity

<!-- page 26 -->

<!-- page 27 -->

Idea Cellular Limited

<!-- page 28 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 29 -->

<!-- page 30 -->

<!-- page 31 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 32 -->

<!-- page 33 -->

<!-- page 34 -->

Reliance Telecom
Limited

<!-- page 35 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 36 -->

<!-- page 37 -->

<!-- page 38 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 39 -->

<!-- page 40 -->

<!-- page 41 -->

Shareholding details of
Associated Licensees that have
nominated the Applicant as a
Group Bidding Entity

<!-- page 42 -->

<!-- page 43 -->

<!-- page 44 -->

S Tel Private Limited

<!-- page 45 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 46 -->

<!-- page 47 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 48 -->

<!-- page 49 -->

Tata Teleservices
Limited

<!-- page 50 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 51 -->

G

TAT A

ANNEXURE-3

March 17, 2010
Joint Secretary (Telecom),
Department of Telecommunications,
Ministry of Communications & Information Technology,
Sanchar Shavan,
20, Ashoka Road,
New Delhi-11 0117.
Subject:

Certificate - Requirement as per Sr. No.6 (a) of application
NIA No.P-11014/13/2008-PP dated 25th February 2010.

for 3G Auction

vide

Dear Sir,
(1)
(2)

This is to certify that Tata Sons Limited, an Indian Company, is a Promoter of Tata
Teleservices Limited. It is Indian Company.
Details of Promoters! Partners! Shareholders in the Company: Tata Teleservices
Limited as on 1st March 2010.
(Note: the Promoters are required to be separately indicated)

(a)

( NA)

NA
65.90
NA
NA
Indian
33.68
NA
100
TOTAL
NTT
26.47
DoCoMo
Others
Inc.
Tata
The
Tata
Communications
Tata
of
10.61
Net
Shareholder
5.60
7.92
5.45
Industries
Promoter!
Power
worth
Co.
Ltd.
Partner
Indian
Ltd.
Indian
Indian
Aranda
Tata
2.64
Sons
34.10
7.33
Others
Not
Indian
Limited
Indian
-Ltd.
0.29
Indian!
21,455.73
Foreign
Note
3Investments
Sr.Name
Siva
Industries
Paid-up
Equity
&
capital
Holdings
Not
Applicable
(Rs.
Crores)
Rs.
Foreign
Percentage
(NA)
-Foreign
See
Foreign
1 & 2)

(See Applicable
Notes

ForTATA TElESERVICES LIMITED
~

1;3

Kiran Thacker

TATA TELESERVICES LIMITED
A, E & F Blocks Voltas Premises T. B. Kadam Marg Chinchpokli
Tel 91 22 66671414

Fax 91 2266605335

~

General Manager (LegilJ) & Company Secretary

Mumbai 400033

website www.tataindicom.com

Registered Office Jeevan Bharati Tower I 10th Floor 124 Connaught Circus New Delhi 110001

<!-- page 52 -->

G

TATA
(b)

65.90%

INDIAN
FOREIGN
Note:

34.10%

1) Bidder Company, Tata Teleservices Limited's networth is adequate and hence
promoters' networth is not required to be considered.
2) Promoters networth certificate is attached as abundant precaution as annexure 3A.
3) Tata Teleservices Limited's paid up equity capital is Rs.4144.40 crores (please see
Annexure 5) which is adequate to meet paid up capital requirement of RS.118
crores for 20 circle UAS Licences held by it .

For TAT A TELESERVICES

LIMITED

Kiran Thacker
General Manager (Legal) & Company Secretary

154
TATA TELESERVICES LIMITED
A. E & F Blocks Voltas Premises T. B. Kadam Marg Chinchpokli Mumbai 400033
Tel 9122 66671414
Fax 912266605335
website www.tataindicom.com
Registered Office Jeevan Bharati Tower I 10th Floor 124 Connaught Circus New Delhi 110001

<!-- page 53 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 54 -->

-II

G

TATA

(Note: In case any of the Associated Licensees is a listed Company, attach the stock
exchange filing establishing the Common Parent as a promoter of the Company).
Filing done by Tata Teleservices (Maharashtra)
attached as Annexure 7.

Limited with National

(Note: Attach Certificates from Company Secretary
Company whose shareholding is presented.)
Certificate
9.

15.

attached

as Annexure

UASL
UASL
S.No.
terminated I
surrendered

signatory

of each

4.

List of telecom service licence(s) held by the Applicant
partners, if any, and their present status:

UASL
Service Area)

or authorised

stock exchange is

and its allies/ sister concerns/

Tata
Teleservices
Teleservices
Status
Chennai
Tata
DELHI
KERALA
BIHAR
HARYANA
PRADESH
(WEST)
Type
ofUTTAR
the
Licence
(Basic
Name
of Ltd.
theTeleservices
Company
GUJARAT
TAMILNADU
ANDHRA
HIMACHAL
MADHYA
ORISSA
RAJASTHAN
KOLKATA
KARNA
PUNJAB
TAKA
PRADESH
PRADESH
Operative
PRADESH
UTTAR
PRADESH
(EAST)
Operative

Ltd.
operativel whether

9
TATA TElESERVICES LIMITED
2A. Old Ishwar Nagar, Main Mathura

Road, New Delhi 110065

Tel: +91 11 66558555,66558666 Fax: +91 11 66558908,66558909
website www.tataindicom.com
Registered Office Jeevan Bharati Tower I 10th Floor 124 Connaught Circus New Delhi 110001

<!-- page 55 -->

G

UASL
Limited
Ltd. A
(Maharashtra)
Internet
Private Limited
Services
Category
Category

TAT
A
Tata
S&A
Communications
Services
NelcoInternet
Limited
- - AllInternational
Tatanet
Services
MUMBAI
NORTH
EAST
ASSAM
WEST
BENGAL
MAHARASHTRA
& KASHMIR Tata
IndiaJAMMU
Teleservices Ltd.
Operative

AllSP
India
IT
UASL
NLD
ILD
ITSP
ISP
17.ISP(IT)

name ofwith
DIL Internet
(Applicant)
change
DOT)
(License
still
in
thename
Limited
pending

Tata
TAT ATeleservices
Communications
TATA
Communications
Ltd.

<!-- page 56 -->

G

-

Tata
Ltd. Internet Services
Limited
Category A
B
Limited
(Company

Delhi
Ghaziabad
All
Mumbai
India
Gurgaon
Commercial
IP-II
ITSP
ISP
Mail- All
Chennai
CUG
India
ISP(IT)
33Voice
licenses
-pending)
License
Communications
Limited along
with all
transfer
merged
with
Tata

TATA

Limited
Tata
Tatanet
ServicesVSNL
LimitedBroadband
DirectCommunications
Internet
VSNL
Broadband
Operative.
Surrendered
Operative
surrendered.
TAT A Power Company

IT

40
39
38

(Type of the Licence means Basic! Cellular! UASL! Paging! NLD!ILD!IP-lIlicences
of all the Licences held by Allies! sister concerns!
common equities must be shown separately.)

II
TATA TElESERVICES

etc. Details

Partners or legal entities with 10% or more

lIMI

2A. Old Ishwar Nagar, Main Mathura Road, New Delhi 110065
Tel: +91 11 66558555, 66558666 Fax: +91 11 66558908, 66558909 website www.tataindicom.com
Registered Office Jeevan Bharati Tower I 10th Floor 124 Connaught Circus New Delhi 110001

<!-- page 57 -->

Shareholding details of
Associated Licensees that have
nominated the Applicant as a
Group Bidding Entity

<!-- page 58 -->

G

TATA
March 17, 2010
Joint Secretary (Telecom),
Department of Telecommunications,
Ministry of Communications & Information Technology,
Sanchar Bhavan,
20, Ashoka Road,
New Delhi - 110 117.

This is to certify that Shareholding of M/s Tata Teleservices (Maharashtra) Limited (TTML) and
paid-up capital as on February 28, 2010 is as under:
Tata
Teleservices
3.52
100.00
Indian
Public
17.32
Indian
20.72
0.50
Name
37.65
of
13.55
Promoter/
Fils
NTT
DoCoMo
7.24
12.12
0.93
Inc.
86.45
Sons
LimitedPartner/
Tata
Power
Rs.
Shareholder
held
Co.
in
Ltd.-Indian
Indian
TTML
/ Foreign
94,645,300
668,694,200
18,971,968,540
16,401,424,090
3,286,264,460
3,930,654,780
NRls/OCBS/other
1,372,631,740
2,298,569,260
2,570,544,450
7,143,178,910
177,329,890
Body
Other
Bodies
Corporate
Percentage
Paid-up
Equity
capital
Foreign
Foreign
Sr. The
7.
5.
Sub-total

Paid up capital is Rs.1897.19 crores.
For Tata Teleservices (Maharashtra) Limited

~
Madhav Joshi
Chief Legal Officer & Company Secretary

'5 ~
TATA TELESERVICES (MAHARASHTRA)

LIMITED

D-26/2 TTC Industrial Area MIDC 5anpada P.O.Turbhe Navi Mumbai 400 703
Tel.:91-22-66615445
Fax:91-22-66605516/17/67917777
Registered Office: C Block Voltas Premises T. B.Kadam Marg Chinchpokli

Mumbai 400 033.

<!-- page 59 -->

Videocon
Telecommunications
Limited

<!-- page 60 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 61 -->

viDeocon
mobile services
Annexure "D"

VIDEOCON TELECOMMUNICATIONS LIMITED
Annexure "D" to Application for 3G Auction
(Point 6, 6(a) of Application)
CERTIFICATE
This is to certify that following are the details of Promoters/Partners/ Shareholders of
Videocon Telecommunications Limited:
Name of Promoter/ Partner/
Shareholder/

Indian/
Foreign

Equity
Percentage

Net Worth
Rs. Cr.

Videocon International

Indian

79.63

1,985.55 #

Indian
Indian

10.37
10.00

6,776.47 #
127.47@

100.00

8,889.49

SI
No.

3.

Electronics Limited *
Videocon Industries Limited
Jumbo Techno Services
Private Limited
Total

Paid up
Capital in
Rs. Cr.
2,000.00k
275.42#

10.00''

* Includes Four Individual shareholders holding 10 Equity Shares each (holding less
than 5%), beneficial ownership whereof is with Videocon International Electronics
Limited.
# Net worth as on 30 th September, 2009 (as per last Audited Balance Sheet Date)
Net worth as on 31 s, March, 2009 (as per last Audited Balance Sheet Date)

Equity Details:
Indian
Foreign
Total

100%
NIL
100%

This certificate is issued on this 17 th day of March, 2010, specifically for submission to
Department of Telecommunications.
For VIDEOCON TELECOMMUNICATIONS LIMITED

CHANDRA HE AR A. NAGARKAR
COMPANY SECRETARY

bO

<!-- page 62 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 63 -->

viDeocon
mobile services

UAS
UAS
UAS
UAS

TN (including
Chennai)
UP East
UP West
West Bengal

Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited

(Note: Attach undertaking that in case the Applicant is declared a Successful Bidder in any
service area where it (alongwith its Associated Licensees) does not currently hold a UAS'
CMTS license, it will acquire a UAS license.)

Ownership details of each of the Associated Licensees establishing the shareholding
of the Common Parent in each of the Associated Licensees.
(Note: In case of step-down subsidiaries, the shareholding details at each level have to
be submitted, in the same format as in point 6(a) (above), clearly establishing the direct/
indirect shareholding of the Common Parent in the Associated Licensees.)
(Note: In case any of the Associated Licensees is a listed Company. attach the stock
exchange filing establishing the Common Parent as a promoter of the Company.)
(Note: Attach Certificates from Company Secretary or authorised signatory of each
Company whose shareholding is presented.)

Not Applicable
List of telecom service license(s) held by the Applicant and its allies/ sister concerns /
partners, if any, and their present status:
Type of License (Basic
Cellular/UASL/Paging/NLD/IL
D/IP-II etc) and service area

Name of the Company

Status whether
operative/surrend
ered/terminated

UASL for Andhra Pradesh

Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited

Operative

UASL for Assam
UASL for Bihar
UASL for Delhi
UASL for Gujarat

Operative
Operative
Operative
Operative

Arvid Bali
Senior Vie
ident

10

<!-- page 64 -->

vioeocon
mobile services
UASL for Haryana
UASL for Himachal Pradesh
UASL for Jammu & Kashmir

UASL for Karnataka

Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited

Operative

Videocon Telecommunications

Operative

Operative
Operative

Limited

UASL for Kerala

Videocon Telecommunications
Limited

Operative

UASL for Kolkata

Videocon Telecommunications
Limited

Operative

UASL for Madhya Pradesh

Videocon Telecommunications
Limited
Videocon Telecommunications
Limited

Operative

Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited
Videocon Telecommunications
Limited

Operative

Videocon Telecommunications

Operative

UASL for Maharashtra
UASL for Mumbai
UASL for North East
UASL for Orissa
UASL for Rajasthan
UASL for TN (including
Chennai)
UASL for UP (East)

UASL for UP (West)

Operative

Operative
Operative
Operative
Operative
Operative

Limited
UASL for West Bengal

Videocon Telecommunications

Operative

Limited
NLD License for All India

Videocon Telecommunications
Limited

Operative

ILD License for All India

Videocon Telecommunications
Limited

Operative

(Type of the License means Basic/ Cellular/ UASL/ Paging/ NLD/ ILD/ IP-II licenses etc.

Arvind Bali
Senior Vice F3tcesident

11

<!-- page 65 -->

Vodafone Essar
Limited

<!-- page 66 -->

Shareholding details of Applicant
/ Group Bidding Entity

<!-- page 67 -->

<!-- page 68 -->

<!-- page 69 -->

List of telecom service licence(s)
held by Applicant and its allies/
sister concerns/ partners, if any,
and their present status

<!-- page 70 -->

<!-- page 71 -->

Shareholding details of
Associated Licensees that have
nominated the Applicant as a
Group Bidding Entity

<!-- page 72 -->

<!-- page 73 -->

<!-- page 74 -->

<!-- page 75 -->

<!-- page 76 -->

<!-- page 77 -->

<!-- page 78 -->
