---
doc_id: "badf25bae2c8a446"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/a2b371a84adf6a7432922b2c2eaa0740.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Announce of pre-qualified bidders for Mobile Munber Portability (MNP) Services Licence(s)-postponement regarding"
date: "2009-01-16"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dabb9fa342ce2dfc"
---

<!-- page 1 -->

Department of Telecommunications

Press Release

Date: 161h February, 2009

The bids against the tender for Mobile Number Portability (MNP)
service licence(s) were opened on 06.02.2009 and the names of pre­
qualified bidders were to be announced on 16.02.2009. This date for
announcement of pre-qualified bidders is hereby postponed and fresh
schedule of dates shall be notified shortly.

****
