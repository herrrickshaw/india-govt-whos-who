---
doc_id: "73cfd68aa206ccdc"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/d3909c6d2ad78d65cf76a2ab522d2378.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of NOC for Sale Rent of International SIM Card Global Calling cards of Foreign Operator in India As on 31.07.2015"
date: "2015-07-31"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ce4f679a885fca20"
---

<!-- page 1 -->

List of NOC for Sale / Rent of International SIM Card / Global Calling cards of
Foreign Operator in India
As on 31.07.2015
Sl.
Name and Address of the Company
No.
01. M/s. Lyca Telecom Pvt. Ltd., New no.5, Old no. 2,9th Avenue, Ashok Nagar,
Chennai-600083.
02. M/s. Aryans E-World Pvt. Ltd., 10-A Vishwakarma Park, Laxmi Nagar ,
Delhi-110092.
03. M/s Global SIM Pvt. Ltd., CB -202 2ND FLOOR Pvt No. Flate 202 Ring Road Naraina
Near Petrl PUMP New Delhi-110028
04. M/s BIRDS Telebyte Pvt. Ltd., 509 Vakratund Corporate Park, Goregaon (East),
Vishweshwar Nagar Mumbai-400063.
05. M/s Telecrest Cellular Service Pvt. Ltd.,106 ANSAL BHAWAN 16 KG Marg,
Connaught Place, Delhi-11000150
06. M/s Go Talk Mobiles Private Ltd Door No.4/398, FEROPLAY Complex, P.O. Karad
Paramba, Via Farook College Mallapuram Kerala-673632.
07. M/s Jaxter Technology Pvt. Ltd., 228, Pragati Industrial Estate, N.M. Joshi Marg,
Lower Parel (E),Mumbai-400 011.
08. M/s Roam1 Telecom Limited, B-236, Gate No. 6, 1st Floor, Okhla Industrial Area,
Phase-I, New Delhi-110 020.
09. M/s. Value Roam Telecast Pvt. Ltd ECO Space IT Park,401,B-238, 4th Floor, Old
Nagardas Road, Mogra Village Andheri(E),Mumbai-400069
10. M/s 360 Global Mobile Pvt. Ltd., Office No.9&10, 1st Floor, D- Wing,, New Elco
Arcade , Hill Road, Bandra (W), Mumbai-400050.
11. M/s Global Hello Pvt. Ltd., S-210,2nd Floor,Nipun Plaza, Sector -4 Vaishali,
Gaziabad-201010 (UP)
12. M/s. Medinyx Software Solution Pvt Ltd,S-490-A,Greater Kailash Part-I,
Delhi-110048
13. M/s. SNSGAP International Services Pvt. Ltd., H-43, 3rd Floor, Sector 63,
Noida-201301 (UP)
14. M/s Hitmax Industries Pvt. Ltd., SS-1/388, Sector A, Aliganj, Sitapur Road Yojna,
Lucknow- 226021.
15. M/s Sonera Trading Pvt. Ltd.,48/1447, Paul Nagar,Calicut,Kerala-673006
16. M/s Aryatech Communications Pvt. Ltd., 275, Old Kashinath Bhawan, M.I. Road,
Jaipur-302001.
17. M/s Viva Communications Pvt. Ltd.,24, Ethiraj Salai, Wellingdon Estate No.7,
3rd Floor, Egmore, Chennai-600 008.
18. M/s Supama Forex Pvt. Ltd..,A/7, Bharat Nagar, Grant Road,Mumbai-400 007.
19. M/s Friscon Telecom Pvt. Ltd., 701, Asmita Abhisek Bld, Opp. Radha Krishna
School, Sunder Nagar, Malad-West,Mumbai-400064.
20. M/s. Talk More Communications Pvt. Ltd., SCO 829-830, Sector 22A
Chandigarh-160022.
21. M/s Matrix Cellular (International) Services Pvt. Ltd., 7, Khullar Farms, Mandi Road,
Mehrauli, New Delhi-110030.

NOC valid
Upto
01.01.2018
05.01.2018
05.01.2018
05.01.2018
05.01.2018
29.01.2018
10.02.2018
22.04.2018
22.04.2015
15.04.2018
08.05.2015
17.05.2018
18.05.2018
23.05.2017
19.06.2015
27.06.2017
30.06.2017
18.06.2017
18.06.2017
07.07.2017
21.07.2017

<!-- page 2 -->

S.
No.
22.
23.
24.
25.
M/s.
26.
27.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40
41
42
43
44

Name and Address of the Company
M/s Uniconnect SIM Pvt. Ltd., 602-604, Midas Chambers, Plot No A-11, Opp. Laxmi
Ind. Estate, OFF-Link Road, Andheri (West), Mumbai-400053.
M/s GG telecrest Pvt. Ltd., 102, Ansal Bhawan, 16-K.G.Marg, New Delhi-110 001.
M/s Seven Telecom Pvt. Ltd., 401/408 Aditya, Behind Abhijeet-1, Mithakhali Six
Roads, Ellisbridge, Ahemedabad-380006.
M/s Stay Connect Cellular Services Pvt. Ltd., Flat No.33, Plot No. E-12, Imperial-II,
Royal Garden Estate, Sector-61, Noida, U.P-201301.
M/s Touchpoint Services Pvt Ltd, SCO 11-12, 2nd Floor,Sector-15 Part-2,Gurgaon-1
M/s Falcon Business Resources Pvt. Ltd., D-1588, Okhla Industrial Area, Phase-I,
New Delhi-110020.
M/s Earthroam Pvt. Ltd., C-152, Phase-II, Chattarpur Enclave, New Delhi-110074.
M/s Lebara Mobile Private Ltd., FM House, 302, Anna Salai, Teynampet,
Chennai-600006
M/s Reliance Webstore Limited, 15th Floor, Vijaya Building, 17, Barakhamba Road,
New Delhi-110001.
M/s.Trump Tele Ventures Pvt Ltd, New Excelsior Building,6th Floor, A.K.Nayak
Marg, Fort MUMBAI-400001.
M/s Tsim Communication Services Pvt. Ltd.,402, 4th Floor, Dosti Tulip Building,
Dosti Acres, SMD Road, Wadala(E),Mumbai-400 037.
M/s Peak Mobiles India Pvt. Ltd., 15B, Trinty Castle, Edappally, Kochi-682024.
M/s. One world Teleservices Pvt. Ltd, Khasara No. 261,Ground Floor, Westend
Marg, Kohinoor Enclave Saidulabad, Delhi-110074
M/s Roam Free Cellular Pvt. Ltd., A-47, Lower Ground Floor, Hauz Khas, New
Delhi-110016.
M/s. Three Spark Telecommunications Pvt Ltd,204-B,Sudarshan Apartments,
Behind Spencer, Daily, Karve Nagar,Pune-411502
M/s Globus Roaming Services Pvt. Ltd., E-95, Greater Kailash-II (FF),New Delhi110048.
M/s KSquare Telecom Pvt. Ltd., 3-11-129 RTC Colony, L.B.Nagar, Hyderabad-74.
M/s Muni’s Telekom Pvt. Ltd.,B/107, Koldogri CHS Ltd., 1st Floor, Parsi Wada, Sahar
Road, Andheri (East), Mumbai-400 099.
M/s. Samridhi Suntel Services Pvt Ltd, G-20, 3rd Floor, Main Market, Shakarpur,
Delhi-92.
M/s Interface Destination Pvt Ltd,11/158 Basement Malviya Nagar, New Delhi110023
M/s ISE Cards India Limited,3/106, Vivek Khand,Gomti Nagar, Lucknow-226010
M/s Rajeshwari Communication Infra Private Limited., 1-1-336/95,Viveknagar,Chikkadpally
Hyderabad-500020, Andhra Pradesh.

NOC valid
Up To
05.07.2017
04.07.2017
28.08.2017
22.08.2017
07.08.2017
19.09.2017
27.09.2017
27.09.2017
29.09.2017
14.10.2017
03.10.2017
23.10.2017
22.10.2017
13.11.2017
18.11.2017
01.12.2017
18.12.2017
01.12.2017
18.12.2017
25.12.2017
30.12.2014
27.07.2018

Note: The request of Renewal of NOC at Sl. 09, 11, 15 & 43, are under examination. Renewal of
NOC would be considered only after the fulfilment of Terms & Condition of renewal of NOC.
