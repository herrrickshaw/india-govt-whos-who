---
doc_id: "acae1033eefdc4bf"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/59f58ed2aa7c94ef436c86da4ba2d87d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of Applicants for 800MHZ Auction."
date: "2012-10-19"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dec9095b03d46448"
---

<!-- page 1 -->

Spectrum Auction in 800MHz band

List of Applicants

<!-- page 2 -->

List of Applicants – 800MHz band
Applications have been received from the following applicants for the Auction of Spectrum in
800MHz band. These lists are provided for information only and do not in any way imply that these
Applications have been processed or pre-qualified.

List of Applicants for Auction of Spectrum in 800MHz band
Sr. No.

Name of Applicant

1.

Tata Teleservices Limited

2.

Videocon Telecommunications Limited
