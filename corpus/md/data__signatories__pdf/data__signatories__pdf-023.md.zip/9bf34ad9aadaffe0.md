---
doc_id: "9bf34ad9aadaffe0"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/fdb19ee56b8ac9cf3d1f1cc12f20ad2e.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Extension in the period of deemed deputation of Group A officers of various services transferred to MTNL/BSNL"
date: "2008-09-16"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "4820a7ea7854d0b7"
---

<!-- page 1 -->

No.A-11013/1/2005-Admn.|I/Absorption Cell
Government of India
Ministry of Communications & Information Technology
Department of Telecommunications
(Absorption Cell)
5" Floor, Sanchar Bhawan,
20, Ashoka Road, New Delhi-110001.
Dated September 12, 2008
OFFICE MEMORANDUM

Subject:- Extension in the period of deemed deputation of Group A officers
of various services of the Department of Telecommunications
(DoT) transferred to Mahanagar Telephone Nigam Limited

(MTNL)/Bharat Sanchar Nigam Limited (BSNL).

The undersigned is directed to state that the competent authority has decided
to extend the period of deemed deputation, without deputation allowance, of officers
belonging to various Group A services of the Department of Telecommunications
transferred to MTNL/BSNL till 22.12.2008 or the date of allocation, me er is
earlier. = ;

ra 5
\ (D.C. Madan)
| Under Secretary to the Govt. of India
\\ Tel.:011-23372100/23036058
ke CMD, MTNL/CMD, BSNL - with a view to giving wide publicity to the contents of this
; letter.
/
«|
oe ee पे
oO 79 SR) — Shri Shakeel Anmad, DDG(SR), ,BSNL, Room No.811, Bharat Sanchar
we Bhawan, Janpath, New Delhi- 110 001.
८५५
av Copy to:- DDG(C&A) — He is requested to get the above-said Office ae dum
Vy suitably posted on our website i.e. www.dot.gov.in. he
=
a 1 (D.C, Madan)
+ Ny Under Secretary to the Govt. of India
N x Tel.:011-23372100/23036058
ES x Copy for information to:-
w & :
ey Ss (i) PS to Hon’ble MOC&IT
# की: ५ हे (ii) PS to Hon'ble MOS(C&IT)
=e ey (iii) PS to Secretary, DOT
ae 2g (iv) Sr.PPS to Secretary, D/o Posts, Dak Bhawan, New Delhi.
ee ee), iat (v) Sr.PPSs to Member (Services)/Member (Finance)/Member (Technology)
& sie a (vi) Sr.PPS to Additional Secretary (T), DoT
g aon (vii) PS to JS (T), DoT
9h ewe
fag. A.) /Disector (T)
निदेशक (आई- 1 17:
BL A /Dy. NO. PO
विनोफ/08०-.०००« तिल
