---
doc_id: "6f289bf49fe4fddc"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/450_Tender_Notice_29092026.pdf"
ministry: "Department of Space"
title: "URSC/GLOBAL TENDER NOTICE NO. Group C: 0450/2026-27 Dated:25.09.2026      915.08 KB"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "356fb6f737bb8f87"
---

<!-- page 1 -->

भारत सरकार, अंत र

वभाग /Government of India, Department of Space

य.ू आर. राव उप ह के

(य.ू आर.एस सी.)/ U R Rao Satellite Centre [URSC]

(पूव म इसरो उप ह के

/ (Formerly known as ISRO Satellite Centre)

एच.ए.एल. एयरपोट रोड, वमानपुरा पो ट,
HAL Airport Road, Vimanapura Post,
बगलू /Bengaluru - 560 017
India

यू.आर.एस.सी./ वैि क िनिवदा सूचना सं /
URSC/GLOBAL TENDER NOTICE NO. Group C: 0450/2026-27
भारत के रा पित की ओर से व. धान, य एवं भंडार, यू.आर. राव उप ह के
मदों की आपूित के िलए केवल ई- ापण के ज रए िनिवदाएं आमंि त ह:

25.09.2026

(यू.आर.एस.सी.), ारा िन िल खत

On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC]
invites tenders ONLY through e-procurement for supply of the following.

दो भाग िनिवदा: वैि वक न वदा / Two Part Tenders: GLOBAL TENDER
.सं.
Sl.
No.

िनिवदा संदभ
TENDER REFERENCE

संि
िववरण
BRIEF DESCRIPTION

दरू थ संचालन के लए आव यक हाडवेयर,
िजसम एक रोबो टक भज
ु ा, कुशल एंड

इफे टर (अं तम उपकरण) और हैि टक
01

URSC/HS/IS202600045001

फ डबैक वाले द ताने शा मल ह।

Teleoperation
hardware
constituting
of
robotic
arm,
dexterous end effector and gloves
with haptic feedback
टडर काशन ितिथ
Tender publish date

25.09.2026 (16.00 Hrs.)

बोली
ुत करने हेतु ारं िभक ितिथ
Bid Submission Start Date

25.09.2026 (16.30 Hrs.)
Page 1 of 2

<!-- page 2 -->

बोली
ीकरण ितिथ
Bid Clarification Date upto

05.10.2026 (10.00 Hrs.)

बोली
ुत करने हेतु िनयत ितिथ
Bid Submission Due Date

12.10.2026 (14.00 Hrs.)

बोली खोलने की ितिथ
Bid Opening Date

12.10.2026 (14.30 Hrs.)

वैध िडिजटल ह

ा र माणप (डी. एस.सी) ा

इ ु क िनिवदाकार https://eproc.isro.gov.in पर लॉग इन

करके अपना

ाव ऑनलाईन भेज सकते ह। कोई िनिवदा शु

लागू नहीं है।

Interested Tenderers having valid Digital Signature Certificate [DSC] may login to
https://eproc.isro.gov.in and submit Offers online. No Tender fees applicable.
िनिवदाओं को उपरो

िनिद िदनां क पर खोला जाएगा। अह िव े ताओं के दर बोली को खोलने की समयसूची को

बाद म सूिचत िकया जाएगा। बोली लगाने से संबंिधत िववरण को इसरो ई- ापण पोटल म लािगन करके दे खा जा
सकता है ।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in
case of Two-Part Tenders) of Qualified Vendors will be intimated later. Bidding details can be
seen by the participated vendors by logging into ISRO e-procurement portal.
उपरो

के संबंध म शु दप /अनुशेष, कोई हो, तो यिद उसे हमारे ई-पोटल एवं वेबसाइट पर कािशत िकया

जाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and Website.

-sdव. धान,

य व भंडार / Sr. Head, Purchase & Stores

Page 2 of 2
