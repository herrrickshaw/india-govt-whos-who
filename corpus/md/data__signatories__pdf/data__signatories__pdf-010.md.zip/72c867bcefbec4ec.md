---
doc_id: "72c867bcefbec4ec"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/30c5c24b4c1d1fbb63e81fdfa82b7b96.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Struck off order of Sh A K Midha"
date: "2020-09-11"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9e0293f8b8bc2e3d"
---

<!-- page 1 -->

No.34-02/2014-EW हु
Government of India
Ministry of Communications
Department of Telecommunications
618-A, Mahanagar Doorsanchar Bhawan,
J L Nehru Marg, New Delhi-1 10002.
Dated : \\ September 2020
OFFICE ORDER
Consequent upon his posting to Delhi LSA vide order No.1-1/2002-EW
dated 14.07.2020 and subsequent relieving on 18.08.2020 (A/N) from Office of
DGT, Hars vide No.01-01/2020-DGT dated 18.08.2020, name of Shri Amrish
Kumar Midha (Staff No.96512) an officer in the SAG of the P&T BWS Group ‘A’
is hereby struck off from the strength of DoT Hars w.e.f 18.08.2020 (A/N).
(S. K. Khare)
Director (Elect)
To
1. PS to Hon’ble MoC
2. PS to Hon’ble MoSC
3. PPS to Secretary (T)
4. PS to M(S)/M(T)/M(F)/DG(T)
5. DDG (Admn.), LSA Delhi
6. Admn.-I/I/II/IV/G-I/G-II/Pay Bill/Cash/PAO/PFP. Section
7. Officer concerned
8. Order Bundle
