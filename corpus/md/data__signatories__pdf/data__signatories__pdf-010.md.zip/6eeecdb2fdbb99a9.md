---
doc_id: "6eeecdb2fdbb99a9"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/3c42b91fee24d981367752a4f0e40644.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "No of PM-WANI hotspots State-UT wise as on 02.02.2024"
date: "2024-02-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "688f73aad4c077f7"
---

<!-- page 1 -->

STATE / UNION TERRITORY WISE NUMBER OF PM WANI WI-FI
HOTSPOTS AS ON 02.02.2024
Serial
Number
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.

Name of State/ Union Territory
Andaman & Nicobar
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chandigarh
Chhattisgarh
Delhi
Goa
Gujarat
Himachal Pradesh
Haryana
Jharkhand
Jammu & Kashmir
Karnataka
Kerala
Ladakh
Lakshadweep
Maharashtra
Meghalaya
Manipur
Madhya Pradesh
Mizoram
Nagaland
Odisha
Punjab
Puducherry
Rajasthan
Sikkim
Telangana
Tamil Nadu
Tripura
Uttarakhand
Uttar Pradesh
West Bengal
Total
***

No. of PM WANI
hotspots
259
6065
1016
882
3967
257
2816
68799
422
4162
935
3774
1020
2289
20192
4930
601
1
16322
256
19
7530
3
78
2892
3739
89
2913
13
4238
7507
308
968
8533
3947
181742
