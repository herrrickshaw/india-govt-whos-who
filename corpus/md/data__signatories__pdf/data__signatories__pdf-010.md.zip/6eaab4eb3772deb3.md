---
doc_id: "6eaab4eb3772deb3"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/7ce2e2a9aa7e763b2faf0b3f6eebf109.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to the Commercial VSAT CUG License Agreement for procurement of Telecommunication equipment"
date: "2021-03-11"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "03ca2a4fcb011ea1"
---

<!-- page 1 -->

File No. 815-66/2021-SAT
Government of India
Ministry of Communications
Department of Telecommunications
(Satellite Division)
20, Ashoka Road, New Delhi - 110001
Dated 11 111 March, 2021
To,
All Commercial VSAT CUG Licensees
Subject: Amendment to the Commercial VSAT CUG License Agreement for procurement
of Telecommunication equipment- reg.

In pursuance to Condition 12. 1, the Licensor hereby amends the Commercial VSAT
CUG Li cense Agreement and appends the fo llowi ng sub-clause number 23.18 in Security
Condition s, Schedul e-Terms and conditions as under:
..23.18. The Government through the Designated Authority will have the right to impose
conditions for procurement of Telecommunication Equipment on grounds ofDefe nce ofIndia,
or matters directly or indirectly related thereto, for national security. Designated Authority
for this purpose shall be National Cyber Security Coordinator. In this regard, the licensee
shall provide any information as and when sought by the Designated Authority.

'

Designated Authority shall notify the categories of equipment for which the security
requirement related to Trusted Sources are applicable. For the said categories of equipment,
Designated Authority shall notify the Trusted Sources along with the associated
Telecommunication Equipment (Trusted Products). The Designated Authority may also notify
a list <~/Designated Sources from whom no procurement can be done. Procedure for inclusion
of Telecommunication Equipment in the list of Trusted Sources will be issued by the
Designated Authority.
With effect from 15'11.!une 2021, the licensee, shall only connect Trusted Products in its
network and also seek permission from Designated Authority for upgradation of existing
Network utilizing the Telecommunication Equipment not designated as Trusted Products.

' Annual Maintenance Contracts (AMC) or
However. these directions will not affect ongoing
updates to existing equipment already inducted in the network as on date ofeffect.

<!-- page 2 -->

The licensees shall comply with the Guidance for Enhanced Supervision and
Effective Control of Telecommunication Networks, as per guidelines to be issued by the
licensor. "

2.
This amendment shall be part and parcel of the Commercial VSAT CUG License
Agreement and alI others Term s & Conditions shall remain un changed .

~
/J D'!,J
J

J-.o ')··.f

(Raj K mar Jha)
Assistant Director General (Satellite-II)
For and o n behalf of the President of India
Ph. No. 23 710248

Copy to:

I.
2.
3.
4.

Chairm an, TRAI.
DG (T) HQ, DoT HQ.
CMD (BSN L)/ CMD (MTN L).
Adviso r (Economi cs)/ Sr. DOG (TEC)/ Wireless Adv isor/ DOG (LFP)/ DOG (LFA)/ DOG
(WPF)/ DOG (SA)/ DOG (SPP I)/ CVO, DoT.
5. DOG (CS)/ DOG (OS)/ DOG (AS)/DDG (A/C) DoT HQ.
6. Director (IT) may kindl y arrange to upload this letter on the website of DoT.
