---
doc_id: "6e418bcec654aafc"
source_url: "https://mohua.gov.in/static/uploads/2026/06/bcf7652e0f0cd0ad70abd05dc77a118f.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Notification No. GSR 486 Dated 12.04.1962 U/S 1(2) of the Delhi Rent Control Act, 1958"
date: "2026-06-19"
pages: 8
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "2df0cfba5cddf979"
---

<!-- page 1 -->

PN a res Sacre i ae ee
1
| REGISTERED No, D. 222 } . Lass,
| oe aS Lig RA ie
= Gee RY COPY
गा डर ५
Say
. The Gazette FY of Endi 0
Key PP vo RY OF ros
i eata aaa vnusarn oy xumionary हि pene ADO
i d
‘ श्र ey © Creer: library)
1 PUBLISHED BY AUTHORITY ( a है oe
we Si ue fo
q फल 5 | कर
i No. 16] NEW DELHI, SATURDAY, APRIL 21, 1962/VAISAKHA f, 1884.0: 20eecs
| Oe
1. ५ NOTICE oh
The undermentioned Gazette of India Extraordinary was published upto the 7th April
1962 :--
nee ee
= Issue No, and Date Issued by Subject
No. :
i ee,
| 31 G.S.R, 463, dated 7th Ministry of Food The Rice (Madhya Pradesh) Price
|| April, 1962.4 and “Agriculture, Control _ "(Third Amendment)
} Order, 1962. %
G.S.R, 464, dated 7th Do.1 }The Rice (Punjab) Second Price
| April, 1962." Control (Second Amendment)
| Order; 1962.
i et
i 7% {Copies of the Gazette Extraordinary mentioned above will be supplied on
1 indent to the Manager of Publications, Civil Lines, Delhi. Indents should be
{ submitted so as to reach the Manager within ten days of the date of issue of e
j this Gazette.
| PART M—Section 3—Sub-section (i)
i हु
1 +> General Statutory Rules (including orders, bye-laws etc. of a general .
4 character) issued by the Ministries of the Government of India (other
i than the Ministry of Defence) and by Central Authorities (other than.
है the Administrations of Union Territories).
{ MINISTRY OF HOME AFFAIRS
* New Delhi, the 10th April 1962
G.S.R. 482.—In pursuance of sub-rule (1) and_the first proviso to sub-rule (2)
' of rule 4 of the Indian Police Service (Cadre) Rules. 1954, the Central Govern-
ment. in consultation with the Government of Orissa hereby makes the following
} further amendments in the LP.S. (Fixation of Cadre Strength) Regulations 1955: न
= Amendments
५ In the Schedule to the said Regulations,. for the entries relating to ‘Orissa’
7 the following shall be substituted, namely:—
~ “1. Senior posts under State Government 41
i Inspector General of Police 1
7 Deputy Inspectors General of Police 6
Assistant Inspectors General of Police 3
! Superintendents of Police (District) 13
| (445 )

<!-- page 2 -->

है eee
THE GAZ |
446 THE GAZETTE OF INDIA; APRIL ANA ST) लत 1 1962/VAISAKHA. 1, 1884 [Parr I a,
Superintendent of Pulse Ratleas का
Superintendent of » Special Branch 1
Superintendent of Police, Vigilance 3
Superintendent of Police, Crime Branch 1
Additional Superintendents of Police 9
Principal, Police Training College 1
Commandants, Orissa Military Police 2
41 Zee
2 Senior posts under Central Government 12 ra
53
3. Posts to be filled by promotion in accordance with
Rule 9 of the Indian Police Service (Recruitment)
Rules, 1954 18 |
/ 4 Posts to be filled by direct recruitment 40 |
5. Deputation Reserve at the rate of 15 per cent of 4 above 6
5. Leave Reserve at the rate of 11 Per cent of 4 above 4 ||
7. Junior Posts at the rate of 20-60 per cent of 4 above 8 q
8. Training Reserve at the rate of 10:59 Per cent of 4 above 4 |
Direct Recruitment Posts 62 |
Promotion Posts 13 |
है Total Authorised Strength 75 |
i |
(No. 7/7/62-AIS(1)) |
G. R. NAIR, Under Secy: a
outa हू
New Delhi, the 11th April 1962 a |
GSR. 483—In exercise of the powers CQnterred by section 2 of the Union |
pattitories (Laws) Act, 1950, the Coven Government “hereby extends to aca
tgiritory of Delhi,” the Punjab’ Benet (East Punjab Amendment) Act 1606 !
(Bast Punjab Act No. XII of 1949)" subject to the following modifications,
namely:— - fees a
* Moorricattons if
1. In section 1,— 1
(1) 100 sub-section (2), the following sub-section shall be substituted,
namely:— +]
“(2) It extends to the whole of the Union territory of Delhi.”; 1
(ii) sub-section (3) shall be omitted, = ir |
2. Sections 2 and 4 shall be omitted, . है |
3:40 section 3, for the words “the said Act”, the words and brackets “the
Punjab Excise Act as in force in the ines territory of Delhi (hereinafter refer.
red to as the said Act)” shall be substitt ed, :
4 In section 7, clause (i) shall be omitted, | oh
, ANNEXURE हु
THE PUNTAR EXCISE (FAST PTINTIAB AMENDMENT) ACT, 1949 AS |
EXTENDED TO THE UNION TERRITORY OF DELHI A] 2
East Punjab Act No. XII of 1949 4
An Act further to amend the Punjab Excise Act (I of 1914), |
It is hereby enacted as follow:— |
1. Short title, extent and smendmen nent) This Act may be called the |
Punjab Excise (East Punjab Amendment) Act, 1949, . |
डर

<!-- page 3 -->

| a
L sec. 8()} = THE GAZETT# OF INDIA: APRIL 21, 1962/VAISAKHA 1, 1984 44%
| (2), It extends ‘to the whole of the Union territory of Delhi.
| (3) Omitted. :
| 2, Amendment of section 24 of the Punjab Excise Act (I of 1914).—Omitted: .
| .
| 22 |, 3. Amendment of section 27 of the Punjab Excise Act (I of 1914).—In sub-sec-
yy tion (1) of section 27 of the Punjab Excise Act as in force in the Union territory
\ of Delhi (hereinafter referred to as the said Act), for the words “any person”,
the words “any man not below the age of twenty-five years”, shall be substituted,
4, Amendment of section 29 of the Punjab Excise Act (I of 1914)—Omitted,
| 5, Amendment of section 30 of the Punjab Excise Act (I of 1914)—For sec-
| tion 30 of the said Act, the following shail be substituted: —
Prohibition of employment of men — “30, No person who is licensed to
1s under the age of 25 years and of sell any liquor ow — intoxicating
1 women. drug for consumption on his १
premises shall, during the hours
in which such’ premises are kept
open for business, employ or
permit to be employed, cither
with or without renumeration,
any man under the age of 23
years or any woman in any part
of such premises in which such
liquor or intoxicating drug is con+
| sumed by the public.”
6. Amendment of section 61 of the Punjab Excise Act (1 of 1944).—In sub-
© section (1) of section 61 of the said Act, for the words “two years”, ihe wende
r ’ “three years” shall be substituted.
| 7, Amendment of section 62 of the Punjab Excise Act (I of 1914).—In sec~
tion 62 of the said Act—
(i) Omitted,
Gi) in clause (b) of the words “child under the age of sixteen years” the
= words “man under the age of twenty-five years” shall be substituted.
: (No. F. 3/3/61-Judl.II-UTL-41]
i GSR. 484.—In exercise of the powers conferred by section 22 of the Bengal
| Agricultural Income-tax Act, 1944 (Bengal Act IV of 1944), as extended to the
| Union territory of Tripura,’ the Central Government hereby appoints for the
purpose of hearing appeals preferred under section 36 of the sgid Act, an Appel-
| late Tribunal consisting of the following three members, namely:— .
1, The District and Sessions Judge, Judicial Member and President of
| * “Tripura, Ex-Officio. the Tribunal.
ke 2, Shri R. C. Bhattacharjee, BL, Ad- Lawyer Member.
*) vocate, Agartala. :
3, Shri Narayan Banerjee, A.C.A.,8/2 Accountant Member.
i Hastings St. Calcutta-1.
| Each of the members mentioned above is appointed for a period of six months
5; commencing on and from the date of this notification.
| [No. F. 19/6/62-Judl.II.]
|
|
है GSR. 485,—In exercise of the powers conferred by section 2 of the Union
Territories (Laws) Act, 1950, the Central Government he.eby extends to the
1 Union territory of Delhi, the Punjab Excise (East Punjab Amendment) Act, 1949
SS eS eee
Lee )
5 !
!
)

<!-- page 4 -->

i fe |

‘

५ 448 THE GAZETTE OF INDIA: APRIL 21, 1962/VAISAKHA 1, 1884 [Parr I
(East Punjab Act, No, XXI of 1949), subject to the following modifications, —~
name.y:—

Movirications.
1. In section 1— j i
(i)for sub-section (2), the following sub-section . shall be substituted,
namely: — i ta
“(2) It extends to the whole of the Union territory of Delhi.”;
(ii) sub-section (3) shall be omitted.
(2) Sections 2 and 4 shall be omitted.
3, In section 3, for the words “the said Act” the words and brackets “the :
Punjab Excise Act, as in force in the Union territory of Delhi (herematter refer.
red to as the said Act)” shall be substituted,
4. In section 7, clause (i) shall be omitted. 1
io 4
ANNEXURE,
. THE PUNJAB EXCISE (EAST PUNJAB AMENDMENT) ACT, 1949, AS
EXTENDED ‘lO ‘HE UNION TERRITORY OF DELHI.
East Pungas Act, No. XII, or 1949, पु
An Act further to amend the Punjab Excise Act, (I of 1914).
Tt is, hereby enacted as follows; शरण
1, Short title, extent and commencement.—(1) This Act may be called the
Punjab Excise (Bast Punjab Amendment) Act, 1949.
(2) It extends to the whole of the Union territory of Delhi, amet
(8) Omitted. 1 i 7
2. Amendment of section 24 of the Punjab Excise Act (1 of 1914) —Omitted.
हु 3. Amendment of section 27 of the Punjab Excise Act (1-of 1914).—In sub-
section (1) of section 27 of the Punjab Excise Act, as in force in the Union terri-
tory of Delhi (hereinafter referred to as the said Act), for the words “only per- 1
son” the words “any man not below the age of twenty-five years”, shall be sub-
stituted, j 1 हर |
4, Amendment of section 29 of the Punjab Excise Act (1 of 1914). —Omitted.
5, Amendment of section 30 of the Punjab Excise Act (I of 1914).—For section |
30 of the said Act, the following shall be substituted: — ही {
Prohibition of employment of men “30. No person who is licensed to
> under the age of 25 years and of sell any liquor or intoxicating
women. drug for consumption on his pre-
. mises shall, during the hours in _
. which such premises are Isept
open for business,’ employ ‘or per-
mit to be employed, either with दर
or without renumeration, any *~ 4
man under the age of 25 years or
. any. woman in any part of such
premises in which’ such liquor or-
intoxicating drug is consumed by#~
the public.”
6. Amendment of section 61 of the Punjab Excise Act (E of 1914).—In sub-
section (1) of section 61, of the said Act, for the words “two years”, the words ,
“three years” shall be substituted.
7, Amendment of section 62 of the Punjab Excise Act (I of 1914).—In section
ge 62 of the said Act,— \ |
(i) Omitted. i |

<!-- page 5 -->

कै J ४
fo ak
| ~
|
| 38०, १0)) ‘THE GAZETTE OF YNDIA: APRIL 21, 1962/VAISAKHA 1, 1884 449
=
ana eee SS पपसपमनप+८%3«८- माप
(ii) in clause (b) for the words “child under the age of sixteen years” the
words “man under the age of twenty-five Years” shall be’ substitut-
मे }
है a (No. F. 3/3/61-Jual. I-UTL-41.]
| P. N. KAUL, Dy. Secy.
i er ‘
a Spa
New Delhi, the 12th April. 1962
GSR. 486.—In exercise of powers conferred by the Proviso to sub-section (2)
of section 1 of the Delhi Rent Control Act, 1958 (59 of 1958), the Centrar Gov-
ernment hereby extends all the Provisions of the said Act,—
(a) to the areas which immediately before the 7th April, 1958, were includ-
ed in the Notified Area Committee, Najatgarh and the Notihed Area
Committee, Narela; and
(b) to the localities mentioned in the schedule to the notification of the
oS Municipal Corporation of Delhi No. F. 9/5/59-R. & S. dated the 28th
December, 1959, published in the Delhi Gazette part IV, dated the
7th January, 1960, and which by virtue of that notification, have
formed part’ of the urban areas’ within the limits of the Municipal हु
Corporation of Delhi.
INo. 35/8/61-Delhi-l]
AL V. VENKATASUBBAN, Dy. Secy,
TRA ance ee सम 1 1 se
MINISTRY OF FINANCE
Ve (Department of Revenue)
। ak CenTraL Excisrs
New Dethi, the 21st April 1962
GSR. 487.—In exercise of the powers conferred by rule 12-A, of the Central ’
Excise Rules, 1944, as in force in India and as applied to the State of Pondicherry,
i the Central Government hereby makes the following further amendment in the
ia notification of the Government of India’ in the Ministry of Finance (Department
हा — of févenue) No, 62/58-Central Excises, dated the 21st ॥ 1958, namely—

} ? In the Table annexed to the said notification, against serial No. 1—Sugar, for
item (xi) and the entries relating thereto in columns 3 and 4, the following shall
be substituted, namely—

3 4
ao कार i) ae ee :
(xi) Mango Pulp containing not less than 5% Rs. 1.40 per quintal of
of sugar by weight. such goods.”* .
Span ha ah वप्त््वेपतन सननसन- 1 1
= #8 i I 1 [ INo. 18/62.)
& GSR. 488.—In exercise of the powers conferred by sub-rule (i) of rule 8
i of the Central Excise Rules, 1944, as in force in India and as applied to the State |
ot Pondicherry, the Central Government hereby makes the following further
amendment in the notification of the Government of India in the Ministry of
, Finance (Department of Revenue) No. 21/61-Central Excises dated the ist March,
1961, namely:—
In the said notification, for the first proviso, the following proviso shall be
substituted, namely;—
“Provided that if during any half year beginning with the Ist April, 1961.
a oma. 9, Manufacturer or ari or an exporter other than en € manufacturer, exports manufacturer, export,
cere 2
) )

<!-- page 6 -->

grater, Sue - ee
| |
ay dh
» |
5 i
=?
450 ¥HE GAZETTE OF INDIA: APRIL 2i, 1962/VAISAKHA 1, 1884 ~ (Parr 11 V
a पे किक रा की a — enna - =
—— men a 1
not less than 30 percent of the cotton fabrics produced by the many
nol urer on automatic looms, the entire quantity of such 2apset
cleared during-that perioa lor home consumption shall be exempt
from so much of the duty as is in excess of ‘the duty specified 9
column 4”.
[No. 19/62.]
L, M, KAUL, Dy. Secy:,:. |
_—_ |
(Department of Revenue) fo
CORRIGENDA
Customs anp CENTRAL EXCISE |
New Delhi, the 2ist April 1962 | है
6.8.8. 489.--10 the Customs and Central Excise Duties Export Drawback |
(General) Amendment Rules, 1962, published with ‘Notification of the Govern- हे
(Genert India in the Ministry of Finance (Department of Revenue) No. G.S.R. 269 97 | Ss
हि को No. 34/94/60-Cus.1V) dated the 3rd March, 1962 for the word ‘after’ in |
line 3 of para 2 read ‘for’.
[No. 44/F. No. 34/94/60-Cus.IV]
; है Customs |
New Delhi, the 2ist April 1962
GSR. 490.—In the Customs Notification of the Government of India in the
Ministry of Finance (Department of Revenue) No. GSR. 440/40/F. No. 34(16)/
2/62-Cus. IV, dated the 7th April 1962,
(a) for ‘after the existing item at Serial No. 154° |
read ‘after the existing item at Serial No. 152’ डे {
(b) for “155” read “153”.
[No, 48/F. No. 34(16)/2/62-Cus..V.]
है D, N. MEHTA, Under Secy:
(Department of Revenue) ©
ORDER *
StaMPs we |
New Delhi, the 17th April 1962 f
GSR. 491.—In exercise of the powers conferred Py clause (a) of sub-section
. (1) of section 9 of the Indian Stamp Act, 1899 (2 of 1899), the Central Goverp |
Coit hereby directs that the duty chargeable in the State of Mysore under th: |
Sila Act on receipts granted by the head of a gale for payments made to hi,
said veount of wages of labourers employed by the ‘Agriculture Department of |
fhe Government of Mysore shall be remitted.
मं [No, 6-F. No. 1/23/62-Stamps/Cus. VIL}. %
J. DATTA, Under Secy.
MINISTRY ————aEeme OF Ms FEL MINES & FUEL ४ “es
के New Delhi, the: 12th April 1962 Ayr)
GSR. 492—In exercise of the powers conferred by section 17 of the Coal | |
Mines (Conservation and Safety) Act, 1952 (12 of 1952), the Central Government | |
hereby makes the following rules further to amend the Coal Mines (Conservation
and Safety) Rules, 1954, the same having been previously published as required
By sub-section (1) of the said section, namely:— |
: 1. These rules may be called the Coal Mines (Conservation and Safety)
(Third Amendment) Rules, 1962.

<!-- page 7 -->

| See. 3(i)) THE GAZETTE OF INDIA: APRIL 21, 1963, VAISAKITA 1, 1884 451
aan न ततसस परम न पस्‍+ञ+३++++++++_-+++++-++++-_#ै_ 1
| के 2. In sub-rule (5) of rule 60 of the Coal Mines (Conservation and Safety)
| Rules, 1954, for the figures, letters and words “Bist day of July” ihe .
| figures, letters and words “30th day of September” shal! be substituted,
| (No. C5-5(5) /61.]
GSR, 493.—In exercise of the powers conferred by section 17 of the Coal
Mines (Conservation and Safety) Act, 1952 (12 of 1952), the Central Goven.
ment hereby makes the following rules further to amend the Coal Mines
ag (Conservation and Safety) Rules, 1954, the same having been previously published
“s88 required by sub-section (1) of the said section, namely:—
1. these rules may be called the Coal Mines (Conservation and Safety)
(Second Amendment) Rules, 1962.
2. In the Coal Mines (Conservation and Safety) Rules, 1954, in rule 39,—
(1) fn sub-rule (3), the following proviso shall be inserted at the end. namely:—
“Provided that where wagon samples are not available because of the
entire output of a seam or section of a seam being used for colliery’s
own consumption or for the manufacture of soft coke or hard coke,
bs the Board shall have power to draw samples from such points of
= consumption or manufacture, before the commencement of any of
| the said operations in the same manner as wagon samples are drawn,
and to fix the final grade of the seam or seams or section of a seam
on the basis of such samples”;
: (2) in sub-rule (3-A), for the words “The drawal of.seam samples and wagon
samples”, the words “The drawal of samples” shall be substituted
'[No. C5-5(6)/61.]
S. P. GUGNANI, Dy. Secy. है
5 —_ ee
के MINISTRY OF HEALTH
४ New Delhi, the 12th April 1962
GSR. 494.—In exercise of the powers conferred by the proviso to article 309,
of the Constitution, the President hereby makes the following rules to amend the
Directorate General of Health Services (Recruitment to certain Class Ill posts
in the Drugs Standard Control Organisation) Rules, 1960, published with the
Notification of the Government of India in the Ministry of Hea'th No. F. 6-28/57-
| Estt, (CHS), dated the 25th October, 1960, namely:—
1. Title—These rules may be called the Directorate General of Health Services
‘i (Recruitment to certain Class TIT posts in the Drugs Standard Control Organi
tion) Amendment Rules, 1962. :
| 4B | 2. In the Directorate General of Health Services (Recruitment to certain
| > Class TIT posts in the Drugs Standard Control Organisation) Rules, 1960,
G) in the proviso to rule 4, the words “or displaced persons’ shall be
A omitted;
“9” (ii) for rule 5, the following rule shall be substituted, namely:—-
} “5. (a) No person. who has more than one wife living or who having
[Ls a spouse living, marries in any case in which such marriage is void
by reason of its taking place during the lifetime of such spouse,
५ shall be eligible for appointment to service; and
ns (b) no woman. whose marriage is void by reason of the husband having
a wife living at the time of such marriage or who has married a
person who has a wife living at the time of such a marriage shall
by be eligible for appointment to service.
पं Provided that the Central Government may, if satisfied that there are special
grounds for so ordering, exempt any person from the operation of this rule”.
(ii) in the Schedule against items 1 and 2. for the entries in column 7, the
है 5. following entries shall be substituted, namely:—
i | “(i) B.Sc, with Chemistry (Main) and Physics, Botany or Zoology as a
| subsidiary subject; or
11% ॥
oh कननन> “न ea tcc ee A SE
— गा 4 ’

<!-- page 8 -->

।
7 452 THE GAZETTE OF INDIA: APRIL 21, 1962/VAISAKHA 1, 1884 [Parr 11 —gxo. 3(i)] ह
sae Lak 8 z a 57 कक |
SSaannnInniamammeieeeee
Gi) B.Se. with Botany (Main) and Chemistry as subsidiary subject; or |
# 4
(iii) A graduate in Pharmacy; or
(iv) B. Se. (Tech) in Food and/or Drugs.” , हे
(०, ए. 6-28 /57-Estt.(CHS).] हु
i D. KRISHNA AYYAR, Under Secy. ‘
i 1
ol
. ५४४४३
f
| ,
* |
*
९ é
= |
t
1
1
|
॥ ae
~E |
. न्याय न तन--++नन 5 हि
PRINTED IN INDIA BY THE GENERAL MANAGER, GOVERNMENT OF INDIA PRESS. i
NEW PELHI AND PUBLISHED BY THE MANAGER OF PUBLICATIONS, DELHI, 1962
