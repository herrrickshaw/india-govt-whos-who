---
doc_id: "6fb9b6c6edd03cd0"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/7695be89177e1f0ed950d5c1ffaaf366.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Plugs and Socket-Outlets and Meters (Quality Control) Amendment Order, 2020"
date: "2025-07-15"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "4612471c9f87bf56"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-18052020-219428
xxxGIDHxxx
CG-DL-E-18052020-219428
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 1356]
No. 1356]

नई ददल्ली, सयोगंवार, ंई 18, 2020/वैिाख 28 , 1942
NEW DELHI, MONDAY, MAY 18, 2020/VAISAKHA 28, 1942

वाजणज्य रर उ्योगग ंं्ालय
(उ्योगग संवधधन रर आंतररक व्यापार जवभाग)

आदेि
नई ददल्ली, 18 ंई, 2020
का.आ. 1517(अ).—भारतीय ंानक ब्यूरयोग अजधजनयं, 2016 (2016 का 11) की धारा 25 की उप-धारा (3)
के साथ परित धारा 16 की उप-धाराओं (1) रर (2) द्वारा प्रदत्त िजतियय का प्रययोगग करते ुए, भारतीय ंानक ब्यूरयोग से
परांिध करने के बाद कें द्र सरकार की राय है दक ऐसा करना िनजहत ंें आवश्यक है, अत: एतद्द्वारा प्लग्स एंड सकके आउ लेट्स तथा एजटि व एनिजी  हेत अल् नटिं ंग करं डाररे टि कनेटि ेड स्ट् ेर क प्रीपेंें ंी र (टिवाजल ी कं रयोगल), आदेि,
2019 ंें संियोगधन करने के जलए जनम्नजलजखत आदेि करती है, नांत:—
1.
संजिप्त िी्धक रर प्रारं भ– (1) रस आदेि कयोग प्लग्स एंड सकके -आउ लेट्स तथा एजटि व एनिजी  हेत अल् नटिं ंग
करं डाररे टि कनेटि ेड स्ट् ेर क प्रीपेंें ंी र (टिवाजल ी कं रयोगल) संियोगधन आदेि, 2020
(2) यह रसके िासकीय रािप् ंें प्रकािन की तारीख से प्रभावी हयोगगा।
2.
प्लग्स एंड सकके -आउ लेट्स तथा एजटि व एनिजी  हेत अल् नटिं ंग करं डाररे टि कनेटि ेड स्ट् ेर क प्रीपेंें ंी र
(टिवाजल ी कं रयोगल), आदेि, 2019 ंें पैरा 1 के उप-पैरा (2) ंें “01.06.2020” अंक कयोग “01.12.2020” अंक से
प्रजतस्ट्थाजपत दकया िाएगा।
[फा. सं. पी-29014/39/2017-एलईआई]
ंनंीत के . नंदा, संयटित सजवव
2084 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

नयोग : प्रंख आदेि का.आ. 4353(अ), ददनांक 05 ददसंबर, 2019 के िररए भारत के रािप्, असाधारण, भाग II,
खंड 3, उप-खंड (ii) के तहत प्रकाजित ुआ था।
MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry & Internal Trade)
ORDER
New Delhi, the 18th May, 2020
S.O. 1517(E).—In exercise of the powers conferred by sub-sections (1) and (2) of section 16 read
with sub-section (3) of section 25 of the Bureau of Indian Standards Act, 2016 (11 of 2016), the Central
Government, after consulting the Bureau of Indian Standards, is of the opinion that it is necessary so to do
in the public interest, hereby makes the following order to amend the Plugs and Socket-Outlets and
Alternating Current Direct Connected Static Prepayment Meters for Active Energy (Quality Control)
Order, 2019.
1. Short title and commencement.- (1) This order may be called the Plugs and Socket-Outlets and
Alternating Current Direct Connected Static Prepayment Meters for Active Energy (Quality Control)
Amendment Order, 2020.
(2) It shall come into force on the date of its publication in the Official Gazette.
2. In the Plugs and Socket-Outlets and Alternating Current Direct Connected Static Prepayment Meters
for Active Energy (Quality Control) Order, 2019, in Paragraph 1, in sub-paragraph (2) for the figures
“01.06.2020”, the following figures “01.12.2020” shall be substituted.
[F. No. P-29014/39/2017-LEI]
MANMEET K. NANDA, Jt. Secy.
Note : The principal order was published in the Gazette of India, Extraordinary under Part II, Section 3,
Sub-section (ii) dated 5th December, 2019 vide S.O. 4353(E), dated the 04th December, 2019.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR VERMA

Digitally signed by MANOJ KUMAR
VERMA
Date: 2020.05.18 21:20:48 +05'30'
