---
doc_id: "70d7ffcd2aac5ce4"
source_url: "https://www.legislative.gov.in/static/uploads/2026/03/91680c7f82e4613a3ff0426aaab15d9b.pdf"
ministry: "Legislative Department (LD)"
title: "List Of Repealed Laws From June, 2014 To June, 2026"
date: "2026-07-02"
pages: 157
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4bb93b356bb13e55"
---

<!-- page 1 -->

List of Repealed Acts from June, 2014 to 2025 through various
Repealing and Amending Acts and other Acts
S. No Year

1

2

3

4

5

6

1850

1850

1850

1850

1852

Act No.

Act Name

3 and 4
Vict., c. 65

The Admiralty Court Act,
1840

12

The Public Accountants’
Defaults Act, 1850

18

The Judicial Officers
Protection Act, 1850

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

21

The Caste Disabilities
Removal Act, 1850

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

37

The Public Servants
(Inquiries) Act, 1850

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

8

The Sheriffs' Fees Act,
1852

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

The Usury Laws Repeal
Act, 1855

7

1855

28

8

1856

9

9

1857

5

Repealed By
The Admiralty
(Jurisdiction and
Settlement of
Maritime Claims)
Act, 2017(22 of
2017)
The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)
The Bills of Lading
The Indian Bills of Lading
Act, 2025 (18 of
Act, 1856
2025)
The Repealing and
The Oriental Gas
Amending Act, 2023
Company Act, 1857.
(Act No. 37 of 2023)

<!-- page 2 -->

10

11

12

13

1857

1857

1859

1860

14

15

16

17

18

19

1862

1863

1866

1867

1867

7

The Repealing and
The Madras Uncovenanted Amending (Second)
Officers Act, 1857.
Act, 2017 (Act No. 4
of 2018)

21

The Repealing and
The Howrah Offences Act, Amending (Second)
1857.
Act, 2017 (Act No. 4
of 2018

12

The Calcutta Pilots Act,
1859.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018

45

The Indian Penal Code,
1860

24 and 25
Vict., c. 10

The Admiralty Court Act,
1861

The Bharatiya Nyaya
Sanhita, 2023 (45 of
2023)
The Admiralty
(Jurisdiction and
Settlement of
Maritime Claims)
Act, 2017(22 of
2017)

3

The Repealing and
The Government Seal Act, Amending (Second)
1862.
Act, 2017 (Act No. 4
of 2018)

16

The Excise (Spirits) Act,
1863

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

21

The Converts' Marriage
Dissolution Act, 1866

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

1

The Ganges Tolls Act,
1867

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

11

The Oriental Gas
Company Act, 1867.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

<!-- page 3 -->

20

21

22

23

24

25

26

27

28

29

1867

1871

1872

1873

1874

1875

1875

1876

1879

1879

25

The Press and
The Press and Registration Registration of
of Books Act, 1867
Periodicals Act, 2023
(51 of 2023)

4

The Coroners Act, 1871.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

1

The Indian Evidence Act,
1872

The Bharatiya
Sakshya Adhiniyam,
2023 (47 of 2023)

16

The North-Western
Provinces Village and
Road Police Act, 1873.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

4

The Foreign Recruiting
Act, 1874

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

18

The Indian Law Reports
Act, 1875

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

The Central Provinces
Laws Act, 1875.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

19

The Dramatic
Performances Act, 1876.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

6

The Elephants
Preservation Act, 1879

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

14

The Repealing and
The Hackney-carriage Act, Amending (Second)
1879.
Act, 2017 (Act No. 4
of 2018)

20

<!-- page 4 -->

30

31

32

33

34

35

36

1879

1879

1881

1881

1881

1882

1883

The Legal Practitioners
Act, 1879

The Advocates
(Amendment) Act,
2023 (33 of 2023)

19

The Raipur and Khattra
Laws Act, 1879.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

11

The Municipal Taxation
Act, 1881.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

13

The Fort William Act,
1881.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

16

The Obstruction in
Fairways Act, 1881.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

The Madras Forest
(Validation) Act, 1882.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

The Bikrama Singh's
Estates Act, 1883.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

18

21

10

The
Telecommunications
Act, 2023 (44 of
2023)
The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

37

1885

13

The Indian Telegraph Act,
1885

38

1885

18

The Land Acquisition
(Mines) Act, 1885.

11

The Repealing and
The Indian Tramways Act,
Amending Act, 2025
1886
(Act No. 37 of 2025)

39

1886

<!-- page 5 -->

40

41

42

43

44

1886

1888

1888

1890

1890

45

The Oudh Wasikas Act,
1886.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

The Police Act, 1888.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

8

The Indian Tolls Act,
1888.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

9

The Indian Railways Act,
1890

The Railways
(Amendment) Act,
2025 (9 of 2025)

13

The Excise (Malt Liquors)
Act, 1890

53 and 54
vict., c. 27

The Colonial Courts of
Admiralty Act, 1890

21

3

46

1891

16

The Colonial Courts of
Admiralty (India) Act,
1891

47

1892

2

The Marriages' Validation
Act, 1892

10

The Government
Management of Private
Estates Act, 1892.

48

1892

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Admiralty
(Jurisdiction and
Settlement of
Maritime Claims)
Act, 2017(22 of
2017)
The Admiralty
(Jurisdiction and
Settlement of
Maritime Claims)
Act, 2017(22 of
2017)
The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)
The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

<!-- page 6 -->

49

50

51

52

53

54

55

1893

1895

1897

1897

1897

1897

1897

The Porahat Estate Act,
1893.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

15

The Government Grants
Act, 1895.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Public Servants
(Inquiries) Amendment
Act, 1897

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

4

The Indian Fisheries Act,
1897

The Repealing and
Amending Act, 2015
(No. 17 of 2015)

5

The Repealing and
Amending Act, 1897

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

8

The Reformatory Schools
Act, 1897.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

14

The Indian Short Titles
Act, 1897

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

2

56

1898

3

The Lepers Act, 1898

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

57

1898

6

The Indian Post Office
Act, 1898

The Post Office Act,
2023 (43 of 2023)

23

The Church of Scotland
Kirk Sessions Act, 1899

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

The Amending Act, 1901

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

58

59

1899

1901

11

<!-- page 7 -->

60

61

62

63

64

65

66

67

68

1902

1903

1905

1911

1912

1912

1912

1913

1915

4

The Repealing and
The Indian Tramways Act,
Amending Act, 2016
1902
(No. 23 of 2016)

1

The Amending Act, 1903

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

4

The Indian Railway Board
Act, 1905

The Railways
(Amendment) Act,
2025 (9 of 2025)

10

The Prevention of
Seditious Meetings Act,
1911.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

7

The Bengal, Bihar and
Orissa and Assam Laws
Act, 1912.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

8

The Wild Birds and
Animals Protection Act,
1912

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

13

The Delhi Laws Act,
1912.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

6

The Mussalman Wakf
Validating Act, 1913

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

7

The Delhi Laws Act,
1915.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

69

1916

7

The Indian Medical
Degrees Act, 1916

70

1917

1

The Inland Vessels Act,
1917

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Inland Vessels
Act, 2021 (24 of
2021)

<!-- page 8 -->

71

72

73

74

75

1917

1919

1920

1920

1921

25

The Sir Currimbhoy
Ebrahim Baronetcy
(Amendment) Act, 1917.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Local Authorities
Pensions and Gratuities
Act, 1919

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

33

The Identification of
Prisoners Act, 1920

The Criminal
Procedure
(Identification) Act,
2022 (11 of 2022)

34

The Passport (Entry into
India) Act, 1920

The Immigration and
Foreigners Act, 2025
(13 of 2025)

17

The Cattle-trespass
(Amendment) Act, 1921.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)
The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

76

1922

22

The Police (Incitement to
Disaffection) Act, 1922.

77

1923

5

The Boilers Act, 1923

The Boilers Act,
2025 (12 of 2025)

6

The Cantonments (House
Accommodation) Act,
1923.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

8

The Employee's
Compensation Act, 1923

The Code on Social
Security, 2020 (36 of
2020)

42

The Mussalman
The Mussalman Wakf Act,
Wakf (Repeal) Act,
1923
2025( 15 of 2025)

26

The Indian Carriage of
Goods by Sea Act, 1925

78

79

80

81

1923

1923

1923

1925

The Carriage of
Goods by Sea Act,
2025 (19 of 2025)

<!-- page 9 -->

82

83

84

85

1926

1927

1928

1929

The Trade Union Act,
1926

The Industrial
Relation Code 2020
(35 of 2020)

17

The Lighthouse Act, 1927

The Marine Aids to
Navigation Act, 2021
(20 of 2021)

12

The Hindu Inheritance
(Removal of Disabilities)
Act, 1928

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

21

The Transfer of Property
(Amendment)
Supplementary Act, 1929

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

The Mussalman Wakf
Validating Act, 1930

16

86

1930

32

87

1931

16

88

1931

20

89

90

1932

1932

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Provisional
The Provisional Collection Collection of Taxes
of Taxes Act, 1931
Act, 2023 (50 of
2023)
The Sheriff of Calcutta
(Power of Custody) Act,
Rep., Act 04 of 2018
1931

11

The Public Suits
Validation Act, 1932.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

24

The Bengal Suppression of
Terrorist Outrages
(Supplementary) Act,
1932.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

91

1933

2

The Children (Pledging of
Labour) Act, 1933

92

1933

17

The Indian Wireless
Telegraphy Act, 1933

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The
Telecommunications
Act, 2023 (44 of
2023)

<!-- page 10 -->

93

94

95

1934

1934

1934

15

The Repealing and
The Sugar-cane Act, 1934. Amending Act, 2023
(Act No. 37 of 2023)

22

The Aircraft Act, 1934

The Bharatiya
Vayuyan Adhiniyam,
2024 (16 of 2024)

27

The Assam Criminal Law
Amendment
(Supplementary) Act,
1934

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)
The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

96

1935

13

The Jubbulpore and
Chhattisgarh Divisions
(Divorce Proceedings
Validation) Act, 1935

97

1936

4

The Payment of Wages
Act, 1936

The Code on wages,
2019 (29 of 2019)

5

The Decrees and Orders
Validating Act, 1936

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

16

The Bangalore Marriages
Validating Act, 1936

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

18

The Red Cross Society
(Allocation of Property)
Act, 1936

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

22

The Indian Companies
(Amendment) Act, 1936

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

11

The Hindu Women's Right The Repealing and
to Property (Amendment) Amending Act, 2017
Act, 1938
(Act No. 2 of 2018)

20

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

98

99

100

101

102

103

1936

1936

1936

1936

1938

1938

The Criminal Law
Amendment Act, 1938.

<!-- page 11 -->

104

105

106

107

108

109

110

111

112

113

114

1938

1939

1939

1940

1941

1941

1941

1941

1941

1941

1941

24

The Employers’ Liability
Act, 1938

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

16

The Registration of
Foreigners Act, 1939

The Immigration and
Foreigners Act, 2025
(13 of 2025)

29

The Indian Tariff (Fourth
Amendment) Act, 1939

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

12

The Income-tax Law
Amendment Act, 1940

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

4

The Repealing and
Amending (Second)
The Berar Laws Act, 1941.
Act, 2017 (Act No. 4
of 2018)

7

The War Injuries
Ordinance, 1941.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

12

The Delhi Restriction of
Uses of Land Act, 1941.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

22

The Indian Merchant
Shipping (Amendment)
Act, 1941

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

23

The Indian Income-tax
(Amendment) Act, 1941

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

24

The Excess Profits Tax
The Repealing and
(Second Amendment) Act, Amending Act, 2016
1941
(No. 23 of 2016)

25

The Railways (Local
The Repealing and
Authorities' Taxation) Act, Amending Act, 2016
1941
(No. 23 of 2016)

<!-- page 12 -->

115

116

117

118

119

120

121

122

1942

1942

1942

1943

1944

1944

1945

1945

18

The Repealing and
The Weekly Holidays Act, Amending (Second)
1942.
Act, 2017 (Act No. 4
of 2018)

20

The Collective Fines
Ordinance, 1942.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

41

The Armed Forces
(Special Powers)
Ordinance, 1942.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

23

The War Injuries
(Compensation Insurance)
Act, 1943.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Central Excise Act,
1944 (1 of 1944) (except
as respects goods included
in entry 84 of the Union
List of the Seventh
Schedule to the
Constitution)

The Central Goods
and Services Tax
Act, 2017 (12 of
2017)

21

The Public Health
(Emergency Provisions)
Ordinance, 1944.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

24

The War Gratuities
(Income-tax Exemption)
Ordinance, 1945.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

30

The Secunderabad
Marriage Validating
Ordinance, 1945.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

<!-- page 13 -->

123

124

125

126

127

128

129

130

131

132

1946

1946

1946

1946

1946

1946

1947

1947

1947

1947

2

The Bank Notes
(Declaration of Holdings)
Ordinance, 1946.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

6

The Criminal Law
Amendment Ordinance,
1946.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

10

The Termination of War
(Definition) Ordinance,
1946.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

20

The Industrial
Employment (Standing
Orders) Act, 1946

The Industrial
Relation Code 2020
(35 of 2020)

22

The Mica Mines Labour
Welfare Fund Act, 1946

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

31

The Foreigners Act, 1946

The Immigration and
Foreigners Act, 2025
(13 of 2025)

14

The Industrial Disputes
Act, 1947

The Industrial
Relation Code 2020
(35 of 2020)

16

The Trading with the
Enemy (Continuance of
Emergency Provisions)
Act, 1947.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

44

The Income-tax and
Business Profits Tax
(Amendment) Act, 1947

The Repealing and
Amending Act, 2016
(No. 23 of 2016

45

The Indian Trade Unions
(Amendment) Act, 1947

The Repealing and
Amending Act, 2016
(No. 23 of 2016

<!-- page 14 -->

The Repealing and
Amending Act, 2015
(No. 17 of 2015)

133

1947

47

The Foreign Jurisdiction
Act, 1947

134

1948

11

The Minimum Wages Act, The Code on wages,
1948
2019 (29 of 2019)

26

The Junagadh
Administration (Property)
Act, 1948.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

34

The Employees' State
Insurance Act, 1948

The Code on Social
Security, 2020 (36 of
2020)

38

The Continuance of Legal
Proceedings Act, 1948

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

40

The Indian Matrimonial
Causes (War Marriages)
Act, 1948

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

48

The Income-tax and
Business Profits Tax
(Amendment) Act, 1948

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

51

The Imperial Library
(Change of Name) Act,
1948

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

58

The Repealing and
The Exchange of Prisoners
Amending Act, 2016
Act, 1948
(No. 23 of 2016)

60

The Resettlement of
Displaced Persons (Land
Acquisition) Act, 1948

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

The Factories Act, 1948

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

135

136

137

138

139

140

141

142

143

1948

1948

1948

1948

1948

1948

1948

1948

1948

63

<!-- page 15 -->

144

145

146

147

148

149

150

151

152

153

154

1949

1949

1949

1949

1949

1950

1950

1950

1950

1950

1950

24

The Delhi Hotels (Control
of Accommodation) Act,
1949

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

51

The Requisitioned Land
(Apportionment of
Compensation) Act, 1949.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

53

The Indian Merchant
Shipping (Amendment)
Act, 1949

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

59

The Merged States (Laws)
Act, 1949

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

61

The Repealing and
The Professions Tax
Amending (Second)
Limitation (Amendment
Act, 2017 (Act No. 4
and Validation) Act, 1949.
of 2018)

4

The Preventive Detention
Act, 1950.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

9

The Indian Tea Control
(Amendment) Act, 1950

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

23

The Appropriation
(Railways) Act, 1950

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

24

The Appropriation Act,
1950

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

26

The Drugs (Control) Act,
1950

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

33

The Opium and Revenue
Laws (Extension of
Application) Act, 1950

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

<!-- page 16 -->

155

156

157

158

159

160

161

162

163

164

165

1950

1950

1950

1950

1950

1950

1950

1950

1950

1950

1951

The Appropriation (No. 2)
Act, 1950

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

50

The Preventive Detention
(Amendment) Act, 1950.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

52

The Essential Supplies
(Temporary Powers)
Amendment Act, 1950

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

60

The Appropriation (No. 3)
Act, 1950

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

67

The Cooch-Behar
(Assimilation of Laws)
Act, 1950.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

71

The Indian Income-tax
(Amendment) Act, 1950

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

72

The Essential Supplies
(Temporary Powers)
Second Amendment Act,
1950

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

74

The Telegraph Wires
(Unlawful Possession)
Act, 1950.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

77

The Appropriation
(Railways) No. 2 Act,
1950

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

79

The Appropriation (No. 4)
Act, 1950

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

1

The Code of Criminal
Procedure (Amendment)
Act, 1951

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

39

<!-- page 17 -->

166

167

168

169

170

171

172

173

174

175

176

1951

1951

1951

1951

1951

1951

1951

1951

1951

1951

1951

The Code of Civil
Procedure (Amendment)
Act, 1951

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

The Part B States (Laws)
Act, 1951.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

4

The Preventive Detention
(Amendment) Act, 1951.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

6

The Appropriation
(Railways) Act, 1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation Act,
1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Appropriation
(Railways) No. 2 Act,
1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation (Vote
on Account) Act, 1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Appropriation
(Railways) No. 3 Act,
1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation
The Appropriation (No. 2 )
Acts (Repeal) Act,
Act, 1951
2016 (22 of 2016)

42

The Indian Merchant
Shipping (Amendment)
Act, 1951

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

51

The Railway Companies
(Emergency Provisions)
Act, 1951.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

2

3

<!-- page 18 -->

177

178

179

180

181

182

183

184

185

186

1951

1951

1951

1951

1951

1951

1951

1952

1952

1952

57

The Punjab Appropriation
Act, 1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

58

The Appropriation
(Railways) No. 4 Act,
1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

59

The Delhi Premises
(Requisition and Eviction)
Amendment Act, 1951

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

60

The Appropriation (No. 3)
Act, 1951

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

66

The Part C States
(Miscellaneous Laws)
Repealing Act, 1951.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

69

The Plantations Labour
Act, 1951

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

70

The Displaced Persons
(Debts Adjustment) Act,
1951.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Part B States
Marriages Validating Act,
1952.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

9

The Indian Independence
Pakistan Courts (Pending
Proceedings) Act, 1952

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

13

The Appropriation Act,
1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 19 -->

187

188

189

190

191

192

193

194

195

196

1952

1952

1952

1952

1952

1952

1952

1952

1952

1952

14

The Punjab Appropriation
Act, 1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation
(Railways) Act, 1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

21

The Appropriation
(Railways) Vote on
Account Act, 1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

28

The Appropriation (Vote
on Account) Act, 1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Preventive Detention
(Amendment) Act, 1952.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

35

The Mines Act, 1952

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

43

The Appropriation
(Railways) No. 2 Act,
1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

44

The Appropriation (No. 2)
Act, 1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

49

The Indian Tea Control
(Amendment) Act, 1952

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

54

The Central Tea Board
(Amendment) Act, 1952

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

34

<!-- page 20 -->

197

1952

61

The Repealing and
The Preventive Detention
Amending (Second)
(Second Amendment) Act,
Act, 2017 (Act No. 4
1952.
of 2018)

198

1952

74

The Forward Contracts
(Regulation) Act, 1952

The Finance Act,
2015 (20 of 2015)

80

The Appropriation (No. 3)
Act, 1952

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

1

The Appropriation Act,
1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation (Vote
on Account) Act, 1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation
(Railways) Act, 1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) No. 2 Act,
1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Patiala and East
Punjab States Union
Appropriation Act, 1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Patiala and East
Punjab States Union
Appropriation (Vote on
Account) Act, 1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Appropriation
The Appropriation (No. 2)
Acts (Repeal) Act,
Act, 1953
2016 (22 of 2016)

11

The Administration of
Evacuee Property
(Amendment) Act, 1953

199

200

201

202

203

204

205

206

207

1952

1953

1953

1953

1953

1953

1953

1953

1953

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

<!-- page 21 -->

208

209

210

211

1953

1953

1953

1953

13

17

23

The Appropriation (No. 3)
Act, 1953
The Patiala and East
Punjab States Union
Appropriation (No. 2) Act,
1953
The Indian Merchant
Shipping (Amendment)
Act, 1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Repealing and
Amending Act, 2016
(No. 23 of 2016)

25

The Indian Income-tax
(Amendment) Act, 1953

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

212

1953

33

The Appropriation (No. 4)
Act, 1953

213

1953

49

The Salt Cess Act, 1953

The Finance Act,
2016 (28 of 2016)

50

The Appropriation (No. 5)
Act, 1953

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

51

The Patiala and East
The Appropriation
Punjab States Union
Acts (Repeal) Act,
Appropriation (No. 3) Act,
2016 (22 of 2016)
1953

54

The Reserve Bank of India
The Repealing and
(Amendment and
Amending Act, 2016
Miscellaneous Provisions)
(No. 23 of 2016)
Act, 1953

3

The Ancient and Historical
Monuments and
The Repealing and
Archaeological Sites and
Amending Act, 2017
Remains (Declaration of
(Act No. 2 of 2018)
National Importance)
Amendment Act, 1953

214

215

216

217

1953

1953

1953

1954

<!-- page 22 -->

218

219

220

221

222

223

224

225

226

227

1954

1954

1954

1954

1954

1954

1954

1954

1954

1954

4

The Abducted Persons
(Recovery and
Restoration) Amendment
Act, 1954.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

5

The Appropriation Act,
1954

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) Act, 1954

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Repealing and
The Government of Part C
Amending (Second)
States (Amendment) Act,
Act, 2017 (Act No. 4
1954.
of 2018)

8

The Appropriation (Vote
on Account) Act, 1954

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Control of Shipping
(Amendment) Act, 1954

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

11

The Appropriation
The Appropriation
Acts (Repeal) Act,
(Railways) No.2 Act, 1954
2016 (22 of 2016)

13

The Press (Objectionable
Matter) Amendment Act,
1954

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

15

The Transfer of Evacuee
Deposits Act, 1954.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

16

The Appropriation (No. 2)
Act, 1954

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 23 -->

228

229

230

231

232

233

234

235

236

237

1954

1954

1954

1954

1954

1954

1954

1954

1954

1954

20

The Absorbed Areas
(Laws) Act, 1954.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

23

The State Acquisition of
Lands for Union Purposes
(Validation) Act, 1954

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

33

The Indian Income-tax
(Amendment) Act, 1954

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

36

The Chandernagore
(Merger) Act, 1954.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

40

The Appropriation (No. 3)
Act, 1954

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

41

The Taxation Laws
(Extension to Jammu and
Kashmir) Act, 1954

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

42

The Administration of
Evacuee Property
(Amendment) Act, 1954

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

47

The Appropriation (No. 4)
Act, 1954

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

51

The Preventive Detention
(Amendment) Act, 1954.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

53

The Prevention of
Disqualification
(Parliament and Part C
States Legislatures)
Second Amendment Act,
1954

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

<!-- page 24 -->

238

239

240

241

242

243

244

245

246

247

248

1954

1955

1955

1955

1955

1955

1955

1955

1955

1955

1955

56

The Appropriation
The Andhra Appropriation
Acts (Repeal) Act,
Act, 1954
2016 (22 of 2016)

3

The Appropriation
The Andhra Appropriation
Acts (Repeal) Act,
Act, 1955
2016 (22 of 2016)

4

The Andhra Appropriation The Appropriation
(Vote on Account) Act,
Acts (Repeal) Act,
1955
2016 (22 of 2016)

5

The Appropriation
(Railways) Act, 1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) No. 2 Act,
1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation Act,
1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Appropriation (Vote
on Account) Act, 1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Appropriation (No. 2)
Act, 1955

16

The Medicinal and Toilet
Preparations (Excise
Duties) Act, 1955

19

The Repealing and
The Commanders-in-Chief
Amending (Second)
(Change in Designation)
Act, 2017 (Act No. 4
Act, 1955.
of 2018)

26

The Code of Criminal
Procedure (Amendment)
Act, 1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Central Goods
and Services Tax
Act, 2017 (12 of
2017)

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

<!-- page 25 -->

249

250

251

252

253

254

255

256

257

258

1955

1955

1955

1955

1955

1955

1955

1956

1956

1956

29

The Industrial Disputes
(Appellate Tribunal)
Amendment Act, 1955

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

30

The Abducted Persons
(Recovery and
Restoration) Continuance
Act, 1955.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

38

The Appropriation (No. 3)
Act, 1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

45

The Working Journalists
and other Newspaper
Employees (Conditions of
Service) and
Miscellaneous Provisions
Act, 1955

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

46

The Appropriation (No. 4)
Act, 1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

47

The Appropriation (No. 5)
Act, 1955

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

52

The Prevention of
Disqualification
(Parliament and Part C
States Legislatures)
Amendment Act, 1955

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

4

The Bar Councils
(Validation of State Laws)
Act, 1956.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

5

The Appropriation Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Sales-Tax Laws
Validation Act, 1956

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

<!-- page 26 -->

259

260

261

262

263

264

265

266

267

268

269

270

1956

1956

1956

1956

1956

1956

1956

1956

1956

1956

1956

1956

10

The Control of Shipping
(Continuance) Act, 1956

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

11

The Appropriation (Vote
on Account) Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation
(Railways) Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

13

The Appropriation
(Railways) No. 2 Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Appropriation
(Railways) No. 3 Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation
(Railways) No. 4 Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

16

The Appropriation
(Railways) No. 5 Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

19

The Appropriation (No. 2)
Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

20

The Travancore-Cochin
Appropriation (Vote on
Account) Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

23

The Travancore-Cochin
Appropriation Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

26

The Indian Income-tax
(Amendment) Act, 1956

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

27

The Representation of the
People (Second
Amendment) Act, 1956

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

<!-- page 27 -->

271

272

273

274

275

276

277

278

279

280

281

1956

1956

1956

1956

1956

1956

1956

1956

1956

1956

1956

36

The Industrial Disputes
(Amendment and
Miscellaneous Provisions)
Act, 1956

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

43

The Appropriation (No. 3)
Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

44

The Appropriation (No. 4)
Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

45

The Newspaper (Price and
Page) Act, 1956

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

46

The Travancore-Cochin
Appropriation (No.2) Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

50

The Indian Cotton Cess
(Amendment) Act, 1956.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

52

The Government Premises The Repealing and
(Eviction) Amendment
Amending Act, 2016
Act, 1956
(No. 23 of 2016)

63

The Scheduled Castes and
Scheduled Tribes Orders
(Amendment) Act, 1956

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

65

The Abducted Persons
(Recovery and
Restoration) Continuance
Act, 1956.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

66

The Code of Civil
Procedure (Amendment)
Act, 1956

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

69

The Terminal Tax on
Railway Passengers Act,
1956.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

<!-- page 28 -->

282

283

284

285

286

287

288

289

290

291

1956

1956

1956

1956

1956

1956

1956

1956

1956

1956

70

The Ancient and Historical
Monuments and
The Repealing and
Archaeological Sites and
Amending Act, 2017
Remains (Declaration of
(Act No. 2 of 2018)
National Importance)
Amendment Act, 1956

79

The State Bank of
Hyderabad Act, 1956

The State Banks
(Repeal and
Amendment) Act,
2018 (19 of 2018)

83

The Appropriation
(Railways) No. 6 Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

84

The Appropriation
(Railways) No. 7 Act,
1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

85

The Appropriation (No. 5)
Act, 1956

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

88

The Representation of the
People (Miscellaneous
Provisions) Act, 1956.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

91

The Administration of
Evacuee Property
(Amendment) Act, 1956

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

93

The Young Persons
(Harmful Publications)
Act, 1956

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

95

The Banking Companies
(Amendment) Act, 1956

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

97

The Delhi Tenants
(Temporary Protection)
Act, 1956.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

<!-- page 29 -->

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)
The National
Medical Commission
Act, 2019 (30 of
2019)
The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

292

1956

100

The Motor Vehicles
(Amendment) Act, 1956

293

1956

102

The Indian Medical
Council Act, 1956

294

1957

1

The Appropriation Act,
1957

2

The Appropriation (No.
2) Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Appropriation (Vote
on Account) Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Kerala Appropriation
Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Kerala Appropriation
(Vote on Account) Act,
1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Appropriation
(Railways) Vote on
Account Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation (No. 3)
Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Life Insurance
The Repealing and
Corporation (Amendment) Amending Act, 2016
Act, 1957
(No. 23 of 2016)

22

The Appropriation
(Railways) No. 2 Act,
1957

295

296

297

298

299

300

301

302

303

1957

1957

1957

1957

1957

1957

1957

1957

1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 30 -->

304

305

306

307

308

309

310

311

312

313

314

1957

1957

1957

1957

1957

1957

1957

1957

1957

1958

1958

24

The Appropriation (No. 4)
Act, 1957

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

32

The Forward Contracts
(Regulation) Amendment
Act, 1957.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

37

The Legislative Councils
Act, 1957.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

47

The Indian Telegraph
(Amendment) Act, 1957

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

53

The Indian Railways
(Amendment) Act, 1957

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

54

The Preventive Detention
(Continuance) Act, 1957.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

56

The Appropriation (No. 5)
Act, 1957

58

The Additional Duties of
Excise (Goods of Special
Importance) Act, 1957

64

The Prevention of
Disqualification
(Amendment) Act, 1957

4

The Appropriation Act,
1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) Act, 1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Central Goods
and Services Tax
Act, 2017 (12 of
2017)
The Repealing and
Amending Act, 2016
(No. 23 of 2016)

<!-- page 31 -->

315

316

317

318

319

320

321

322

323

324

325

1958

1958

1958

1958

1958

1958

1958

1958

1958

1958

1958

8

The Appropriation (Vote
on Account) Act, 1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Control of Shipping
(Continuance) Act, 1958

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

10

The Appropriation
(Railways) No. 2 Act,
1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation (No. 2)
Act, 1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Appropriation (No. 3)
Act, 1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

23

The Appropriation
(Railways) No. 3 Act,
1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

29

The Working Journalists
(Fixation of Rates of
Wages) Act, 1958

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

33

The Estate Duty
(Amendment) Act, 1958

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

35

The Manipur and Tripura
(Repeal of Laws) Act,
1958

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

40

The Appropriation (No. 4)
Act, 1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

49

The Appropriation
(Railways) No. 4 Act,
1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 32 -->

326

327

328

329

330

331

332

333

334

335

336

1958

1958

1958

1958

1959

1959

1959

1959

1959

1959

1959

50

The Appropriation
(Railways) No. 5 Act,
1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

51

The Appropriation (No. 5)
Act, 1958

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

54

The Prevention of
Disqualification
(Amendment) Act, 1958

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

56

The Himachal Pradesh
Legislative Assembly
(Constitution and
Proceedings) Validation
Act, 1958.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

1

The Indian Income-tax
(Amendment) Act, 1959

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

2

The Appropriation Act,
1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation
(Railways) Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) No. 2 Act,
1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation (Vote
on Account) Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The Appropriation (No. 2)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Coal Grading Board
(Repeal) Act, 1959

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

<!-- page 33 -->

337

338

339

340

341

342

343

344

345

346

347

1959

1959

1959

1959

1959

1959

1959

1959

1959

1959

1959

18

The Appropriation (No. 3)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

19

The Appropriation
(Railways) No. 3 Act,
1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Pharmacy
(Amendment) Act, 1959.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

24

29

31

The Public Wakfs
(Extension of Limitation)
Act, 1959
The Employment
Exchanges (Compulsory
Notification of Vacancies)
Act, 1959

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Code on Social
Security, 2020 (36 of
2020)

34

The Appropriation (No. 4)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

35

The Appropriation (No. 5)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

36

The Appropriation (No. 6)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

37

The Central Excises and
Salt (Amendment) Act,
1959

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

38

The State Bank of India
(Subsidiary Banks) Act,
1959

The State Banks
(Repeal and
Amendment) Act,
2018 (19 of 2018)

39

The Kerala Appropriation
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 34 -->

348

349

350

351

352

353

354

355

356

357

358

1959

1959

1959

1959

1959

1959

1959

1959

1960

1960

1960

40

The Appropriation (No. 7)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

41

The Criminal Law
(Amendment) Act, 1959

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

46

The Government Savings
Certificates Act, 1959 (46
of 1959)

The Finance Act,
2017 (13 of 2018)

48

The Miscellaneous
The Repealing and
Personal Laws (Extension) Amending Act, 2017
Act, 1959
(Act No. 2 of 2018)

53

The Kerala Appropriation
(No.2) Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

55

The Appropriation (No. 8)
Act, 1959

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

59

The Mineral Oils
(Additional Duties of
Excise and Customs)
Amendment Act, 1959

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

61

The Married Women's
Property (Extension) Act,
1959

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

2

The Displaced Persons
(Compensation and
Rehabilitation)
Amendment Act, 1960

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

3

The Appropriation Act,
1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Motor Vehicles
(Amendment) Act, 1960

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

<!-- page 35 -->

359

360

361

362

363

364

365

366

367

368

369

370

1960

1960

1960

1960

1960

1960

1960

1960

1960

1960

1960

1960

7

The Appropriation
(Railways) Act, 1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Appropriation
(Railways) No. 2 Act,
1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Appropriation (Vote
on Account) Act, 1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation (No. 2)
Act, 1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation
(Railways) No. 3 Act,
1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

16

The Estate Duty
(Amendment) Act, 1960

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

18

The Indian Boilers
(Amendment) Act, 1960

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

19

The Hindu Marriages
(Validation of
Proceedings) Act, 1960

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

22

The Cotton Transport
(Amendment) Act, 1960.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

28

The Taxation Laws
(Amendment) Act, 1960

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

29

The Appropriation
(Railways) No. 4 Act,
1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

30

The Appropriation (No. 3)
Act, 1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 36 -->

371

372

373

374

375

376

377

378

379

380

1960

1960

1960

1960

1960

1960

1960

1960

1960

1960

31

The Tripura Municipal
Law (Repeal) Act, 1960.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

36

The Appropriation (No. 4)
Act, 1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

38

The Central Excises
(Conversion to Metric
Units) Act, 1960

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

40

The Customs Duties and
Cesses (Conversion to
Metric Units) Act, 1960

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

45

The Indian Museum
(Amendment) Act, 1960

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

47

The Bilaspur Commercial
Corporation (Repeal) Act,
1960.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

48

The Mahendra Pratab
Singh Estates (Repeal)
Act, 1960.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

49

The Appropriation
(Railways) No. 5 Act,
1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

50

The Appropriation (No. 5)
Act, 1960

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Tripura Excise Law
(Repeal) Act, 1960.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

53

<!-- page 37 -->

381

382

383

384

385

386

387

388

389

390

391

392

1960

1960

1960

1961

1961

1961

1961

1961

1961

1961

1961

1961

54

The Railway Passenger
Fares (Amendment) Act,
1960

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

57

The British Statutes
(Application to India)
Repeal Act, 1960

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

65

The Companies
(Amendment) Act, 1960

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

2

The Appropriation Act,
1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Orissa Appropriation
Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation
(Railways) Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) No. 2 Act,
1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Banking Companies
(Amendment) Act, 1961

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

9

The Appropriation (Vote
on Account) Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Orissa Appropriation
(Vote on Account) Act,
1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation (No. 2)
Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

18

The Orissa Appropriation
(No. 2) Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 38 -->

393

394

395

396

1961

1961

1961

1961

20

The Appropriation (No. 3)
Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

22

The Appropriation
(Railways) No. 3 Act,
1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

27

The Motor Transport
Workers Act, 1961

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

36

The Newspaper (Price and
Page) Continuance Act,
1961

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Income-Tax Act,
2025 (30 of 2025)

397

1961

37

The Appropriation (No. 4)
Act, 1961

398

1961

43

The Income-tax Act, 1961

53

The Code on Social
The Maternity Benefit Act,
Security, 2020 (36 of
1961
2020)

54

The Appropriation
(Railways) No. 4 Act,
1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

55

The Sugar (Regulation of
Production) Act, 1961

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

57

The Appropriation (No. 5)
Act, 1961

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation Act,
1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

399

400

401

402

403

1961

1961

1961

1961

1962

<!-- page 39 -->

404

405

406

407

408

409

410

411

412

413

414

415

1962

1962

1962

1962

1962

1962

1962

1962

1962

1962

1962

1962

4

The Appropriation
(Railways) Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation (Vote
on Account) Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation
(Railways) Vote on
Account Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Air Corporations
(Amendment) Act, 1962

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

18

The Appropriation
(Railways) No. 2 Act,
1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

19

The Appropriation (No. 2)
Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

22

The Appropriation (No. 3)
Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

23

The Appropriation
(Railways) No. 3 Act,
1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

28

The Appropriation (No. 4)
Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

29

The Appropriation
(Railways) No. 4 Act,
1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

40

The Appropriation
(Railways) No. 5 Act,
1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

41

The Appropriation (No. 5)
Act, 1962

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 40 -->

416

417

418

419

420

421

422

423

424

425

426

1962

1962

1962

1962

1962

1963

1963

1963

1963

1963

1963

43

The Companies
(Amendment) Act, 1962

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

56

The State-Associated
Banks (Miscellaneous
Provisions) Act, 1962

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

59

The Personal Injuries
(Emergency Provisions)
Act, 1962

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

62

The Emergency Risks
(Goods) Insurance Act,
1962.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

63

The Emergency Risks
(Factories) Insurance Act,
1962.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Hindi Sahitya
Sammelan (Amendment)
Act, 1963.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

5

The Appropriation
(Railways) Act, 1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) No. 2 Act,
1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation Act,
1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Appropriation (Vote
on Account) Act, 1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation (No. 2)
Act, 1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 41 -->

427

428

429

430

431

432

433

434

435

436

437

1963

1963

1963

1963

1963

1963

1963

1963

1963

1963

1963

16

The Appropriation
(Railways) No. 3 Act,
1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Appropriation
(Railways) No. 4 Act,
1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

18

The Appropriation (No. 3)
Act, 1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

21

The Compulsory Deposit
Scheme Act, 1963

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

25

The Appropriation (No. 4)
Act, 1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

29

The Institutes of
Technology (Amendment)
Act, 1963.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

31

The Appropriation
(Railways) No. 5 Act,
1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

35

The Dramatic
Performances (Delhi
Repeal) Act, 1963.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

37

The Personal Injuries
(Compensation Insurance)
Act, 1963

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

38

The Major Port
The Major Port Trusts Act,
Authorities Act,
1963
2021 (1 of 2021)

44

The Appropriation (No. 5)
Act, 1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 42 -->

438

439

440

441

442

443

444

445

446

447

448

1963

1963

1963

1964

1964

1964

1964

1964

1964

1964

1964

46

The Appropriation
(Railways) No. 6 Act,
1963

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

53

The Companies
(Amendment) Act, 1963

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

56

The Delhi Development
(Amendment) Act, 1963.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Appropriation
(Railways) Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation (Vote
on Account) Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Appropriation Act,
1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation
(Railways) No. 2 Act,
1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation (No. 2)
Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Appropriation (No. 3)
Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Public Employment
(Requirement as to
Residence) Amendment
Act, 1964.

The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

22

The Appropriation (No. 4)
Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 43 -->

449

450

451

452

453

454

455

456

457

458

459

1964

1964

1964

1964

1964

1964

1965

1965

1965

1965

1965

23

The Delhi (Delegation of
Powers) Act, 1964.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

29

The Appropriation (No. 5)
Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

32

The Companies
(Amendment) Act, 1964

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

39

The Appropriation (No. 6)
Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

42

The Kerala Appropriation
Act, 1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

50

The Appropriation
(Railways) No. 3 Act,
1964

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation Act,
1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Appropriation
(Railways) Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation
(Railways) No. 2 Act,
1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation (Vote
on Account) Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Kerala Appropriation
Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 44 -->

460

461

1965

1965

8

The Kerala Appropriation
(Vote on Account) Act,
1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The Appropriation (No. 2)
Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Kerala Appropriation
(No. 2) Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

462

1965

13

463

1965

21

464

465

466

467

468

469

470

471

1965

1965

1965

1965

1965

1965

1965

1965

23

The Payment of Bonus
Act, 1965
The Banking Laws
(Application to Cooperative Societies) Act,
1965

The Code on wages,
2019 (29 of 2019)
The Repealing and
Amending Act, 2016
(No. 23 of 2016)

24

The Kerala Appropriation
(No. 3) Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

25

The Kerala Appropriation
(No. 4) Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

26

The Appropriation (No. 3)
Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

27

The Appropriation (No. 4)
Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

28

The Appropriation
(Railways) No. 3 Act,
1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

29

The Appropriation
(Railways) No. 4 Act,
1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

31

The Companies
(Amendment) Act, 1965

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

<!-- page 45 -->

472

473

474

475

476

477

478

479

480

481

482

1965

1965

1965

1965

1966

1966

1966

1966

1966

1966

1966

37

The Appropriation (No. 5)
Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

43

The Kerala Appropriation
(No. 5) Act, 1965

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

44

The Metal Corporation of
India (Acquisition of
Undertaking) Act, 1965.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

50

The Goa, Daman and Diu
(Absorbed Employees)
Act, 1965.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

5

The Appropriation (Vote
on Account) Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation Act,
1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation
(Railways) Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Appropriation
(Railways) No. 2 Act,
1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Kerala Appropriation
Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The Kerala Appropriation
(Vote on Account) Act,
1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation (No. 2)
Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 46 -->

483

484

485

486

487

488

489

490

491

492

493

1966

1966

1966

1966

1966

1966

1966

1966

1966

1966

1966

14

The Kerala Appropriation
(No. 2) Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

21

The Merchant Shipping
(Amendment) Act, 1966

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

27

The Appropriation (No. 3)
Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

30

The Electricity (Supply)
Amendment Act, 1966

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

32

The Beedi and Cigar
Workers (Conditions of
Employment) Act, 1966

The Occupational
Safety, Health and
Working Conditions
Code, 2020 (37 of
2020)

37

The Companies (Second
Amendment) Act, 1966

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

39

The Kerala Appropriation
(No. 3) Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

40

The Kerala Appropriation
(No. 4) Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

41

The Kerala Appropriation
(No. 5) Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

42

The Appropriation
(Railways) No. 3 Act,
1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

43

The Appropriation
(Railways) No. 4 Act,
1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 47 -->

494

495

496

497

498

499

500

501

502

503

504

505

1966

1966

1966

1967

1967

1967

1967

1967

1967

1967

1967

1967

45

The Appropriation (No. 4)
Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

46

The Appropriation (No. 5)
Act, 1966

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

47

The Representation of the
People (Amendment) Act,
1966

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

1

The Appropriation Act,
1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation (Vote
on Account) Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Appropriation
(Railways) Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation
(Railways) Vote on
Account Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Goa, Daman and Diu
Appropriation Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Goa, Daman and Diu
Appropriation (Vote on
Account) Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Rajasthan
Appropriation Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Rajasthan
Appropriation (Vote on
Account) Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Essential
Commodities
(Amendment) Act, 1967

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

<!-- page 48 -->

506

507

508

509

510

511

512

513

514

515

516

1967

1967

1967

1967

1967

1967

1967

1967

1967

1968

1968

16

The Repealing and
The Anti-Corruption Laws Amending (Second)
(Amendment) Act, 1967.
Act, 2017 (Act No. 4
of 2018)

18

The Appropriation
(Railways) No. 2 Act,
1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

19

The Appropriation (No. 2)
Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

23

25

The Appropriation
(Railways) No. 3 Act,
1967
The Standards of Weights
and Measures (Extension
to Kohima and
Mokokchung Districts)
Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Repealing and
Amending Act, 2016
(No. 23 of 2016)

32

The Appropriation (No. 3)
Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

33

The Appropriation (No. 4)
Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

34

The Manipur
Appropriation Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

35

The Haryana
Appropriation Act, 1967

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation Act,
1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation (Vote
on Account) Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 49 -->

517

518

519

520

521

522

523

524

525

526

1968

1968

1968

1968

1968

1968

1968

1968

1968

1968

8

The Appropriation
(Railways) Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Appropriation
(Railways) No. 2 Act,
1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The Haryana
Appropriation Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Haryana
Appropriation (Vote on
Account) Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

13

The West Bengal
Appropriation Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The West Bengal
Appropriation (Vote on
Account) Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Uttar Pradesh
Appropriation Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

16

The Uttar Pradesh
Appropriation (Vote on
Account) Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

18

The Appropriation (No. 2)
Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

20

The Uttar Pradesh
The Appropriation
Appropriation (No. 2) Act, Acts (Repeal) Act,
1968
2016 (22 of 2016)

527

1968

21

The West Bengal
The Appropriation
Appropriation (No. 2) Act, Acts (Repeal) Act,
1968
2016 (22 of 2016)

528

1968

23

The Public Provident Fund The Finance Act,
Act, 1968 (23 of 1968)
2017 (13 of 2018)

<!-- page 50 -->

529

530

531

532

533

534

535

536

537

538

539

1968

1968

1968

1968

1968

1968

1968

1968

1968

1968

1968

37

The Appropriation
(Railways) No. 3 Act,
1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

38

The Appropriation
(Railways) No. 4 Act,
1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

40

The Bihar Appropriation
Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

41

The Appropriation (No. 3)
Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

42

The Appropriation (No. 4)
Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

43

The Uttar Pradesh
The Appropriation
Appropriation (No. 3) Act, Acts (Repeal) Act,
1968
2016 (22 of 2016)

49

The Delhi and Ajmer Rent
The Repealing and
Control (Nasirabad
Amending Act, 2019
Cantonment Repeal) Act,
(Act No. 31 of 2019)
1968.

54

The Appropriation
(Railways) No. 5 Act,
1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

55

The Appropriation
(Railways) No. 6 Act,
1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

60

The State Agricultural
Credit Corporations Act,
1968

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

64

The Punjab Appropriation
Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 51 -->

540

541

542

543

544

545

546

547

548

549

550

1968

1968

1968

1969

1969

1969

1969

1969

1969

1969

1969

65

The Pondicherry
Appropriation Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

66

The Appropriation (No. 5)
Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

67

The Bihar Appropriation
(No. 2) Act, 1968

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation (Vote
on Account) Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation Act,
1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation (No. 2)
Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation
(Railways) No. 2 Act,
1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

13

The Appropriation (No. 3)
Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Companies
(Amendment) Act, 1969

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

22

The Banking Companies
(Acquisition and Transfer
of Undertakings) Act,
1969

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

<!-- page 52 -->

551

552

553

554

555

556

557

558

559

560

561

1969

1969

1969

1969

1969

1969

1969

1969

1969

1969

1969

23

The Coal Bearing Areas
(Acquisition and
Development)
Amendment Act, 1969

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

28

The Central Sales Tax
(Amendment) Act, 1969

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

29

The Appropriation
(Railways) No. 3 Act,
1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

30

The Appropriation
(Railways) No. 4 Act,
1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

31

The Appropriation (No. 4)
Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

37

The Delhi High Court
(Amendment) Act, 1969

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

38

The Wakf (Amendment)
Act, 1969

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

41

The International
Monetary Fund and Bank
(Amendment) Act, 1969.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

46

The Punjab Legislative
Council (Abolition) Act,
1969

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

48

The Appropriation
(Railways) No. 5 Act,
1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

49

The Appropriation No. 5
Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 53 -->

562

563

564

565

566

567

568

569

570

571

572

573

1969

1969

1969

1970

1970

1970

1970

1970

1970

1970

1970

1970

50

The Appropriation (No. 6)
Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

51

The Manipur
Appropriation Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

52

The Bihar Appropriation
Act, 1969

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation (Vote
on Account) Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation Act,
1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Manipur
Appropriation Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Manipur
The Appropriation
Appropriation (No. 2) Act, Acts (Repeal) Act,
1970
2016 (22 of 2016)

10

The West Bengal
Appropriation (Vote on
Account) Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The West Bengal
Appropriation Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Appropriation
(Railways) Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

13

The Appropriation
(Railways) No. 2 Act,
1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

18

The Appropriation (No. 2)
Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 54 -->

574

575

576

577

578

579

580

581

582

1970

1970

1970

1970

1970

1970

1970

1970

1970

24

The Petroleum
(Amendment) Act, 1970

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

25

The Merchant Shipping
(Amendment) Act, 1970

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

32

The West Bengal
The Appropriation
Appropriation (No. 2) Act, Acts (Repeal) Act,
1970
2016 (22 of 2016)

36

The Appropriation (No. 3)
Act, 1970

37

The Occupational
The Contract Labour
Safety, Health and
(Regulation and Abolition) Working Conditions
Act, 1970
Code, 2020 (37 of
2020)

38

The Appropriation
(Railways) No. 3 Act,
1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

44

The Appropriation (No. 4)
Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

45

The Appropriation (No. 5)
Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

46

The Appropriation
(Railways) No. 4 Act,
1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
The National
Commission for
Indian System of
Medicine Act, 2020
(14 of 2020)

583

1970

47

The Appropriation
(Railways) No. 5 Act,
1970

584

1970

48

The Indian Medicine
Central Council Act, 1970

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 55 -->

585

586

587

588

589

590

591

592

593

594

595

596

1970

1971

1971

1971

1971

1971

1971

1971

1971

1971

1971

1971

51

The Central Labour Laws
(Extension to Jammu and
Kashmir) Act, 1970

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

1

The Appropriation
(Railways) Vote on
Account Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation
(Railways) Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Manipur
Appropriation (Vote on
Account) Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Manipur
Appropriation Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation Act,
1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation (Vote
on Account) Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Orissa Appropriation
(Vote on Account) Act,
1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Orissa Appropriation
Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Mysore Appropriation The Appropriation
(Vote on Account) Act,
Acts (Repeal) Act,
1971
2016 (22 of 2016)

11

The Appropriation
The Mysore Appropriation
Acts (Repeal) Act,
Act, 1971
2016 (22 of 2016)

12

The West Bengal
Appropriation (Vote on
Account) Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 56 -->

597

598

599

600

601

602

603

604

605

606

607

1971

1971

1971

1971

1971

1971

1971

1971

1971

1971

1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

13

The West Bengal
Appropriation Act, 1971

18

The Manipur
The Appropriation
Appropriation (No. 2) Act, Acts (Repeal) Act,
1971
2016 (22 of 2016)

19

The Appropriation
(Railways) No. 2 Act,
1971

20

The Bengal Finance (Sales
The Repealing and
Tax) (Delhi Validation of
Amending Act, 2017
Appointments and
(Act No. 2 of 2018)
Proceedings) Act, 1971

25

The Punjab Appropriation
Act, 1971

27

The Appropriation
The Mysore Appropriation
Acts (Repeal) Act,
(No. 2) Act, 1971
2016 (22 of 2016)

28

The West Bengal
The Appropriation
Appropriation (No. 2) Act, Acts (Repeal) Act,
1971
2016 (22 of 2016)

29

The Appropriation
The Gujarat Appropriation
Acts (Repeal) Act,
Act, 1971
2016 (22 of 2016)

30

The Appropriation (No. 2)
Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

38

The Appropriation (No. 3)
Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

54

The Coal Bearing Areas
(Acquisition and
Development)
Amendment and
Validation Act, 1971

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 57 -->

608

609

610

611

612

613

614

615

616

617

618

1971

1971

1971

1971

1971

1971

1971

1972

1972

1972

1972

58

The Appropriation
(Railways) No. 3 Act,
1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

60

The Appropriation (No. 4)
Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

61

The Punjab Appropriation
(No. 2) Act, 1971

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

63

The Jayanti Shipping
Company (Acquisition of
Shares) Act, 1971

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

64

The Coking Coal Mines
(Emergency Provisions)
Act, 1971

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

65

The Asian Refractories
Limited (Acquisition of
Undertaking) Act, 1971.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

68

The Uttar Pradesh
Cantonments (Control of
Rent and Eviction)
(Repeal) Act, 1971.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

1

The Appropriation Act,
1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

2

The Appropriation (No. 2)
Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Appropriation
(Railways) Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation
(Railways) No. 2 Act,
1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 58 -->

619

620

621

622

623

624

625

626

627

628

629

1972

1972

1972

1972

1972

1972

1972

1972

1972

1972

1972

5

The Appropriation
(Railways) (Vote on
Account) Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation (Vote
on Account) Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Appropriation (No. 3)
Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Appropriation
(Railways) No. 3 Act,
1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

36

The Coking Coal Mines
(Nationalisation) Act,
1972.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

39

The Payment of Gratuity
Act, 1972

The Code on Social
Security, 2020 (36 of
2020)

51

The Appropriation (No. 4)
Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

58

The Indian Copper
Corporation (Acquisition
of Undertaking) Act, 1972

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

62

The Limestone and
Dolomite Mines Labour
Welfare Fund Act, 1972

Rep., Act 02 of 2018

63

The Appropriation
(Railways) No. 4 Act,
1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

64

The Appropriation
(Railways) No. 5 Act,
1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 59 -->

630

631

632

633

634

635

636

637

638

639

640

641

1972

1972

1972

1973

1973

1973

1973

1973

1973

1973

1973

1973

65

The Appropriation (No. 5)
Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

66

The Appropriation (No. 6)
Act, 1972

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

72

The Sick Textile
Undertakings (Taking over Rep., Act 23 of 2016
of Management) Act, 1972

4

The Appropriation (Vote
on Account) Act, 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation Act,
1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) Act, 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation
(Railways) No. 2 Act,
1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Andhra Pradesh
Appropriation (Vote on
Account) Act 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Andhra Pradesh
Appropriation Act, 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The Orissa Appropriation
(Vote on Account) Act,
1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

12

The Orissa Appropriation
Act, 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Coal Mines (Taking
The Repealing and
Over of Management) Act, Amending Act, 2016
1973
(No. 23 of 2016)

<!-- page 60 -->

642

643

1973

1973

16

The Manipur
Appropriation (Vote on
Account) Act, 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

19

The Appropriation (No. 2)
Act, 1973

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

644

1973

26

645

1973

28

The Coal Mines
(Nationalisation) Act,
1973
The Manipur
Appropriation Act , 1973

Rep., Act 04 of 2018
Rep., Act 22 of 2016

646

1973

29

The Andhra Pradesh
Appropriation (No. 2) Act, Rep., Act 22 of 2016
1973

647

1973

30

The Orissa Appropriation
(No. 2) Act, 1973

648

1973

35

649

1973

38

650

1973

42

651

1973

43

652

1973

56

653

1973

59

654

1973

61

655

1973

62

The Appropriation (No. 3)
Act, 1973
The Appropriation
(Railways) No. 3 Act,
1973
The Orissa Appropriation
(No. 3) Act, 1973
The Manipur
Appropriation (No. 2) Act
, 1973
The Alcock Ashdown
Company Limited
(Acquisition of
Undertakings) Act, 1973.

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

Rep., Act 31 of 2019

The Homoeopathy Central
Rep., Act 15 of 2020
Council Act, 1973
The Appropriation
(Railways) No. 4 Act,
Rep., Act 22 of 2016
1973
The Konkan Passenger
Ships (Acquisition) Act,
Rep., Act 23 of 2016
1973

<!-- page 61 -->

656

1973

63

The Appropriation (No. 4)
Act, 1973

Rep., Act 22 of 2016

657

1973

64

The Appropriation (No. 5)
Act, 1973

Rep., Act 22 of 2016

658

1973

65

The Orissa Appropriation
(No. 4) Act, 1973

Rep., Act 22 of 2016

659

660

1974

1974

The Bharatiya
Nagarik Suraksha
Sanhita, 2023 (46 of
2023)
The Repealing and
Amending Act, 2016
(No. 23 of 2016)

2

The Code of Criminal
Procedure, 1973

4

The Esso (Acquisition of
Undertakings in India)
Act, 1974

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
Rep., Act 22 of 2016

661

1974

7

The Appropriation (Vote
on Account) Act, 1974

662

1974

10

The Appropriation
(Railways) Act, 1974

663

1974

13

The Gujarat Appropriation
Rep., Act 22 of 2016
Act , 1974

664

1974

14

665

1974

15

666

1974

16

667

1974

17

The Gujarat Appropriation
(Vote on Account ) Act ,
1974
The Appropriation
(Railways) No. 2 Act,
1974
The Appropriation
(Railways) No. 3 Act,
1974
The Appropriation Act,
1974

Rep., Act 22 of 2016

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

668

1974

18

The Pondicherry
Appropriation (Vote on
Account) Act, 1974

669

1974

19

The Appropriation (No. 2)
Act, 1974

670

1974

24

The Gujarat Appropriation
Rep., Act 22 of 2016
(No. 2) Act, 1974

Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 62 -->

671
672

1974
1974

25

The Pondicherry
Appropriation Act , 1974

Rep., Act 22 of 2016

28

The Coal Mines
(Conservation and
Development) Act

Rep., Act 23 of 2023

The Additional
Emoluments (compulsory
deposit) Act, 1974

Rep., Act 23 of 2016

673

1974

37

674

1974

43

675

1974

44

676

1974

61

677

1974

62

The Gujarat Appropriation
Rep., Act 22 of 2016
(No. 3) Act , 1974

678

1974

63

The Gujarat Appropriation
Rep., Act 22 of 2016
(No. 4) Act , 1974
Rep., Act 22 of 2016
Rep., Act 22 of 2016

The Appropriation (No. 3)
Act, 1974
The Appropriation
(Railways) No. 4 Act,
1974
The Appropriation (No. 4)
Act, 1974

679

1974

64

The Pondicherry
Appropriation (No. 2) Act
, 1974

680

1975

5

The Appropriation (Vote
on Account) Act, 1975

681

1975

6

682

1975

7

683

1975

8

684

1975

9

685

1975

10

The Appropriation
(Railways) Act, 1975
The Appropriation
(Railways) No. 2 Act,
1975
The Appropriation
(Railways) No. 3 Act,
1975
The Pondicherry
Appropriation Act , 1975
The Pondicherry
Appropriation (Vote on
Account ) Act , 1975

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 63 -->

686

1975

11

The Appropriation Act,
1975

Rep., Act 22 of 2016

687

1975

14

The Gujarat Appropriation
(Vote on Account ) Act ,
Rep., Act 22 of 2016
1975

688

1975

15

The Gujarat Appropriation
Rep., Act 22 of 2016
Act , 1975

689

1975

17

The Nagaland
Appropriation Act , 1975

Rep., Act 22 of 2016

18

The Nagaland
Appropriation (Vote on
Account ) Act , 1975

Rep., Act 22 of 2016

Rep., Act 4 of 2018
Rep., Act 22 of 2016

690

1975

691

1975

19

The All-India Services
Regulations (Indemnity)
Act, 1975

692

1975

21

The Appropriation (No. 2)
Act, 1975

693

1975

26

694

1975

27

695

1975

30

696

1975

36

The Appropriation (No. 3)
Act, 1975

Rep., Act 22 of 2016

697

1975

37

The Appropriation (No. 4)
Act, 1975

Rep., Act 22 of 2016

The Tobacco Cess
Act,1975
The Nagaland
Appropriation (No. 2) Act
, 1975
The Pondicherry
Appropriation (No. 2) Act
, 1975

Rep., Act 28 of 2016
Rep., Act 22 of 2016

Rep., Act 22 of 2016

698

1976

2

The Burmah Shell
(Acquisition of
Rep., Act 23 of 2016
Undertakings in India) Act

699

1976

5

The Appropriation Act,
1976

Rep., Act 22 of 2016

700

1976

6

The Appropriation
(Railways) Act, 1976

Rep., Act 22 of 2016

<!-- page 64 -->

The Appropriation
(Railways) No. 2 Act,
1976
The Sales Promotion
Employees (Conditions of
Service) Act, 1976

701

1976

7

Rep., Act 22 of 2016

702

1976

11

703

1976

16

The Nagaland
Appropriation Act , 1976

Rep., Act 22 of 2016

704

1976

17

The Pondicherry
Appropriation Act , 1976

Rep., Act 22 of 2016

Rep., Act 04 of 2018

Rep., Act 29 of 2019

(Rep., Act 37 of
2020)

705

1976

22

The Assam Sillimanite
Limited (Acquisition and
Transfer of Refractory
Plant) Act, 1976

706

1976

25

The Equal Remuneration
Act, 1976,

28

The Parliamentary
Proceedings (Protection of
Rep., Act 04 of 2018
Publication) Repeal Act,
1976.

707

1976

708

1976

31

709

1976

38

710

1976

39

711

1976

40

712

1976

43

713

1976

47

The Levy Sugar Price
Equalisation Fund Act,
1976
The Appropriation (No. 3)
Act, 1976
The Pondicherry
Appropriation (No. 2) Act
, 1976
The Nagaland
Appropriation (No. 2) Act
, 1976
The Appropriation (Vote
on Account) Act, 1976
The Appropriation
(Railways) No. 2 Act,
1976

Rep., Act 37 of 2025
Rep., Act 22 of 2016
Rep., Act 22 of 2016

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 65 -->

714

1976

48

715

1976

50

The Appropriation
(Railways) No. 3 Act,
1976
The Tamil Nadu
Appropriation Act , 1976

Rep., Act 22 of 2016
Rep., Act 22 of 2016

716

1976

51

The Tamil Nadu
Appropriation (No. 2) Act
, 1976

717

1976

52

The Gujarat Appropriation
Rep., Act 22 of 2016
Act , 1976

55

The Iron Ore Mines,
Manganese Ore Mines and
Rep., Act 31 of 2019
Chrome Ore Mines Labour
Welfare Cess Act 1976

56

The Beedi Workers
Labour Welfare Cess Act,
1976 (56 of 1976)

718

719

1976

1976

Rep., Act 22 of 2016

The Taxation Laws
(Amendment) Act,
2017 (18 of 2017)

720

1976

61

The Iron Ore Mines,
The Repealing and
Manganese Ore Mines and
Amending Act, 2019
Chrome Ore Mines Labour
(Act No. 31 of 2019)
Welfare Fund Act, 1976.

721

1976

62

The Beedi Workers
Welfare Fund Act, 1976.

Rep., Act 31 of 2019

722

1976

64

The Appropriation (No. 4)
Act, 1976

Rep., Act 22 of 2016

723

1976

76

The National Library of
India Act, 1976.

Rep., Act 04 of 2018

724

1976

83

The Appropriation (No. 5)
Act, 1976

Rep., Act 22 of 2016

84

The Tamil Nadu
Appropriation (No. 3) Act
, 1976

Rep., Act 22 of 2016

85

The Pondicherry
Appropriation (No. 3) Act
, 1976

Rep., Act 22 of 2016

725

726

1976

1976

<!-- page 66 -->

727

1976

89

The Indian Iron and Steel
Company (Acquisition of
Shares) Act, 1976.

Rep., Act 04 of 2018

The Delhi Sales Tax
(Amendment and
Validation) Act, 1976

Rep., Act 02 of 2018

728

1976

91

729

1976

95

730

1976

96

731

732

733

734

1976

1976

1976

1976

The Appropriation (No. 6)
Act, 1976
The Braithwaite and
Company (India) Limited
(Acquisition and Transfer
of Undertakings) Act,
1976.

Rep., Act 22 of 2016

Rep., Act 04 of 2018

97

The Burn Company and
Indian Standard Wagon
Rep., Act 23 of 2016
Company(Nationalisation)
Act, 1976

98

The laxmirattan and
Atherton West Cotton
Mills (taking over of
Management) Act, 1976

Rep., Act 23 of 2016

100

The Metal Corporation
(Nationalisation and
Miscellaneous Provision)
Act

Rep., Act 23 of 2023

106

The Untouchability
(Offences) Amendment
and Miscellaneous
Provision Act, 1976

Rep., Act 23 of 2016

735

1976

110

736

1976

111

737

1976

112

The Appropriation
(Railways) No. 4 Act,
1976
The Appropriation
(Railways) No. 5 Act,
1976
The Appropriation (No. 7)
Act, 1976

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 67 -->

738

1976

113

The Gujarat Appropriation
Rep., Act 22 of 2016
(No. 2) Act , 1976
Rep., Act 22 of 2016

739

1976

114

The Pondicherry
Appropriation (No. 4) Act
, 1976

740

1977

1

The Appropriation (Vote
on Account) Act, 1977

Rep., Act 22 of 2016

741

1977

2

The Appropriation Act,
1977

Rep., Act 22 of 2016
Rep., Act 22 of 2016

742

1977

3

The Appropriation
(Railways) Vote on
Account Act, 1977

743

1977

4

The Appropriation
(Railways) Act, 1977

Rep., Act 22 of 2016

16

The Disputed Elections
(Prime Minister and
Speaker) Act, 1977.

Rep., Act 04 of 2018

17

The Caltex Acquisition of
Shares of Caltex oil
Refining (India) Limited
and of the undertakings in
India of Caltex India
Limited Act, 1977

Rep., Act 23 of 2016

744

745

1977

1977

The Appropriation
(Railways) No. 2 Act,
1977
The Appropriation (No. 2)
Act, 1977

746

1977

18

747

1977

22

748

1977

28

The Appropriation (No. 3)
Act, 1977

36

The Water (Prevention and
Control of pollution) Cess Rep., Act 18 of 2017
Act, 1977

41

The Smith, Stainstreet and
Company Limited
(Acquisition and Transfer

749

750

1977

1977

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

Rep., Act 04 of 2018

<!-- page 68 -->

of Undertakings) Act,
1977

751

1977

42

752

1977

45

753

1978

3

754

1978

4

755

1978

5

756

1978

6

757

1978

7

758

1978

8

759

1978

11

The Gresham and Craven
of India (Private) Limited
(Acquisition and Transfer
of Undertakings) Act,
1977
The Appropriation (No. 4)
Act, 1977
The Appropriation (Vote
on Account) Act, 1978
The Appropriation
(Railways) Act, 1978
The Appropriation
(Railways) No. 2 Act,
1978
The Appropriation
(Railways) No. 3 Act,
1978
The Appropriation Act ,
1978
The Appropriation (No. 2)
Act , 1978
High Denomination
Banknotes
(Demonetisation) Act,
1978

760

1978

13

The Hindustan Tractors
Limited (Acquisition and
Transfer of Undertakings)
Act, 1978.

761

1978

18

The Appropriation (No. 3)
Act , 1978

Rep., Act 04 of 2018

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

Rep., Act 18 of 2023

Rep., Act 04 of 2018

Rep., Act 22 of 2016

<!-- page 69 -->

762

1978

21

763

1978

35

764

765

766

767

1978

1978

1978

1978

40

41

The Deposit Insurance
Corporation (Amendment
and Miscellaneous
Provision) Act, 1978
The Appropriation (No. 4)
Act , 1978
The Additional Duties of
Excise (Textiles and
Textile Articles) Act,
1978
The Britannia Engineering
Company Limited
(Mokameh Unit) and the
Arthur Butler and
Company (Muzaffarpore)
Limited (Acquisition and
Transfer of Undertakings)
Act, 1978

Rep., Act 23 of 2016

Rep., Act 22 of 2016
The Central Goods
and Services Tax
Act, 2017 (12 of
2017)

The Repealing and
Amending Act, 2025
(Act No. 37 of 2025)

42

The Bolani Ores Limited
(Acquisition of Shares)
and Miscellaneous
Provisions Act, 1978.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

49

The Sugar Undertakings
(Taking Over of
Management) The whole.
Act, 1978

The Repealing and
Amending Act, 2015
(No. 17 of 2015)

The Appropriation
(Railways) No. 4 Act,
1978
The Appropriation
(Railways) No. 5 Act,
1978
The Appropriation (No. 5)
Act , 1979

768

1979

1

Rep., Act 22 of 2016

769

1979

2

770

1979

3

771

1979

7

The Appropriation (Vote
on Account) Act , 1979

Rep., Act 22 of 2016

772

1979

8

The Appropriation Act ,
1979

Rep., Act 22 of 2016

Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 70 -->

773

1979

9

774

1979

10

775

1979

11

776

1979

12

777

1979

19

778

1979

28

779

1979

30

780

1980

2

781

1980

3

782

1980

9

783

1980

10

784

1980

11

785

1980

12

786

1980

39

787

1980

43

The Appropriation (No. 2)
Act , 1979
The Appropriation
(Railways) Act , 1979
The Appropriation
(Railways) No. 2 Act ,
1979
The Punjab Excise (Delhi
Amendment) Act, 1979
The Appropriation (No. 3)
Act , 1979
The Kosangas Company
(Acquisition of
Undertakings) Act, 1979
The Inter-State Migrant
Workmen (Regulation of
Employment and
Conditions of Service)
Act, 1979
The Appropriation Act,
1980
The Appropriation
(Railways) Act, 1980
The Appropriation
(Railways) Vote on
Account Act, 1980
The Appropriation
(Railways) No. 2 Act ,
1980
The Appropriation (Vote
on Account) Act, 1980
The Appropriation (No. 2)
Act, 1980
The Appropriation
(Railways) No. 3 Act ,
1980
The Appropriation (No. 3)
Act , 1980

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 04 of 2018
Rep., Act 22 of 2016
Rep., Act 23 of 2016

Rep., Act 37 of 2020

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 71 -->

788

789

1980

1980

58

The Bengal Chemical and
Pharmaceutical Works
Limited (Acquisition and
Transfer of Undertakings)
Act, 1980.

Rep., Act 04 of 2018

63

The Code of Criminal
Procedure Amendment
Act, 1980

Rep., Act 02 of 2018

Rep., Act 23 of 2016

790

1980

64

The Maruti Limited
(Acquisition and Transfer
of Undertaking) Act, 1980

791

1980

68

The Tea (Amendment)
Act, 1980

Rep., Act 31 of 2019

792

1980

71

The Appropriation (No. 4)
Act , 1980

Rep., Act 22 of 2016

793

1981

2

The Appropriation (Vote
on Account ) Act, 1981

Rep., Act 22 of 2016

794

1981

3

The Appropriation Act,
1981

Rep., Act 22 of 2016

795

1981

4

The Appropriation (No. 2)
Act, 1981

Rep., Act 22 of 2016

796

1981

5

The Appropriation (No. 3)
Act, 1981

Rep., Act 22 of 2016

797

1981

8

798

1981

9

799

1981

10

800

1981

11

801

1981

15

The Appropriation
(Railways) Act, 1981
The Appropriation
(Railways) No. 2 Act,
1981
The Appropriation
(Railways) No. 3 Act,
1981
The Appropriation
(Railways) No. 4 Act,
1981
The Appropriation (No. 4)
Act , 1981

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 72 -->

802

1981

18

The Essential
Commodities (Special
Provisions) Act, 1981

Rep., Act 23 of 2016

Rep., Act 23 of 2016

803

1981

19

The Prevention of blackmarketing and
Maintenance of Supplies
of Essential commodities
(Amendment) Act, 1981

804

1981

30

The Cine-workers Welfare
Rep., Act 02 of 2018
Cess Act, 1981

805

1981

33

806

1981

34

807

1981

37

808

1981

41

809

1981

50

810

1981

54

811

1981

55

812

1981

56

The Cine-Workers
Welfare Fund Act, 1981
The Appropriation
(Railways) No. 5 Act,
1981
The Appropriation (No. 5)
Act, 1981

Rep., Act 36 of 2020
Rep., Act 22 of 2016
Rep., Act 22 of 2016

The Burmah Oil Company
[Acquisition of Shares of
Oil Indian Limited and of
the Undertakingd in India
of Assam Oil company
Rep., Act 23 of 2016
Limited and the Burmah
Oil Company (India
Trading) Limited] Act,
1981
The Cine-Workers and
Cinema Theatre
Workers (Regulation of
Employment) Act, 1981
The Appropriation
(Railways) No. 6 Act,
1981
The Appropriation
(Railways) No. 7 Act,
1981
The Appropriation (No. 6)
Act, 1981

Rep., Act 37 of
2020

Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

<!-- page 73 -->

813

1981

57

The Appropriation (No. 7)
Act, 1981

Rep., Act 22 of 2016

The Aligard Muslim
University Amendment
Act, 1981

Rep., Act 31 of 2019

814

1981

62

815

1982

3

816

1982

5

817

1982

6

818

1982

7

819

1982

8

820

1982

19

821

1982

26

822

1982

31

823

1982

32

824

1982

33

The Sugar Cess Act, 1982
The Appropriation (Vote
on Account ) Act, 1982
The Appropriation Act,
1982
The Appropriation
(Railways) Act, 1982
The Appropriation
(Railways) No. 2 Act,
1982
The Appropriation (No. 2)
Act, 1982
The Prevention of cruelty
to Animals (Amendment)
Act, 1982
The Estate Duty
(Amendment) Act, 1982
The Appropriation
(Railways) No. 3 Act,
1982
The Appropriation (No. 3)
Act , 1982

Rep., Act 18 of 2017
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016
Rep., Act 23 of 2016
Rep., Act 23 of 2016
Rep., Act 22 of 2016
Rep., Act 22 of 2016

825

1982

36

The Chaparmukh-Silghat
Railway Line and the
Katakhal-Lalabazar
Rep., Act 37 of 2025
Railway Line
(Nationalisation) Act, 1982

826

1982

38

The Payment of Wages
(Amendment) Act, 1982

Rep., Act 23 of 2016

<!-- page 74 -->

827

1982

49

The National Waterway
(Allahabad HaldiaStretch
of Ganga BhagirathiHooghly River) Act, 1982
The Amritsar Oil Works
(Acquisition and Transfer
of Undertakings) Act,
1982
The Central Excise Laws
(Amendment and Transfer
of Undertaking) Act, 1982

Rep., Act 17 of 2016

828

1982

50

Rep., Act 23 of 2016

829

1982

58

830

1982

60

The Appropriation (No. 4)
Act, 1982

Rep., Act 22 of 2016
Rep., Act by 31 of
2019

Rep., Act 23 of 2016

831

1982

63

The Road transport
Corporations
(Amendment) Act, 1982

832

1982

65

The Anti-Hijacking Act,
1982

Rep., Act 30 of 2016

833

1982

68

The Drugs and Cosmetics
(Amendment) Act, 1982

Rep., Act 23 of 2016

71

The Andhra scientific
Company Limited
(Acquisition and Transfer
of Undertaking) Act

Rep., Act 23 of 2023

2

The Appropriation (Vote
on Account) Act, 1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

3

The Appropriation Act,
1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

4

The Appropriation (No. 2)
Act, 1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation
(Railways) Act, 1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

834

835

836

837

838

1982

1983

1983

1983

1983

<!-- page 75 -->

839

840

841

842

843

844

845

846

847

848

849

1983

1983

1983

1983

1983

1983

1983

1983

1983

1983

1983

6

The Appropriation
(Railways) No. 2 Act,
1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation
(Railways) No. 3 Act,
1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Appropriation No. 3
Act, 1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Delhi Motor Vehicles
Taxation (Amendment)
Act, 1983.

The Repealing and
Amending Act, 2023
(Act No. 37 of 2023)

19

The Appropriation No. 4
Act, 1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

20

The Delegated Legislation
Provisions (Amendment)
Act, 1983

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

21

The Appropriation
(Railways) No. 4 Act,
1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Jute Manufactures
Cess Act, 1983 (28 of
1983)
The National Oilseeds and
Vegetable Oils
Development Board Act,
1983

The Taxation Laws
(Amendment) Act,
2017 (18 of 2017)

28

29

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

35

The Dangerous Machines
(Regulation) Act, 1983.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

36

The Appropriation (No. 5)
Act, 1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 76 -->

850

851

852

853

854

855

856

857

858

859

860

1983

1983

1983

1983

1984

1984

1984

1984

1984

1984

1984

37

40

41

The Appropriation
(Railways) No. 5 Act,
1983

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Textile Undertakings
(Taking Over of
Management) Act, 1983
The Transformers and
Switchgear Limited
(Acquisition and Transfer
of Undertakings) Act,
1983.

The Repealing and
Amending Act, 2016
(No. 23 of 2016)
The Repealing and
Amending Act, 2019
(Act No. 31 of 2019)

44

The Indian Railways
(Amendment) Act, 1983

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

1

The Banking Laws
(Amendment) Act, 1983

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

6

The Appropriation (Vote
on Account) Act, 1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

7

The Appropriation Act,
1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

8

The Appropriation (No. 2)
Act, 1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

9

The Appropriation
(Railways) Act, 1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

10

The Appropriation
(Railways) No. 2 Act,
1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

11

The Appropriation
(Railways) No. 3 Act,
1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 77 -->

861

862

863

864

865

866

867

868

869

870

871

1984

1984

1984

1984

1984

1984

1984

1984

1984

1984

1984

16

The Ganesh Flour Mills
Company Limited
(Acquisition and Transfer
of Undertakings) Act,
1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

18

The Appropriation (No. 3)
Act, 1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

19

The Government of Union
Territories (Amendment)
Act, 1984

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

26

The Payment of Gratuity
The Repealing and
(Second Amendment) Act, Amending Act, 2016
1984
(No. 23 of 2016)

33

The Mogul Line Limited
(Acquisition of Shares)
Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

34

The Essential
Commodities
(Amendment) Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

38

The Delhi Development
(Amendment) Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

39

The Punjab Municipal
(New Delhi Amendment)
Act, 1984.

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

43

The Aluminium
Corporation of India
Limited (Acquisition and
Transfer of Aluminium
Undertaking) Act, 1984.

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

45

The Employees’ State
Insurance (Amendment)
Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

50

The Appropriation (No. 4)
Act, 1984

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 78 -->

872

873

874

875

876

877

878

879

880

881

882

1984

1984

1984

1984

1984

1984

1984

1985

1985

1985

1985

53

The Estate Duty
(Amendment) Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

54

The Levy Sugar Price
Equalisation Fund
(Amendment) Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

55

The Hooghly Docking and
Engineering Company
The Repealing and
Limited (Acquisition and
Amending Act, 2025
Transfer of Undertakings) (Act No. 37 of 2025)
Act, 1984

57

59

The Bengal Immunity
Company Limited
(Acquisition and Transfer
of Undertakings) Act,
1984.
The University Grants
Commission
(Amendment) Act, 1984

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)
The Repealing and
Amending Act, 2016
(No. 23 of 2016)

63

The Dowry Prohibition
(Amendment) Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

67

The Taxation Laws
(Amendment) Act, 1984

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

3

The General Insurance
Business (Nationalisation)
Amendment Act, 1985

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

4

The Appropriation Act,
1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

5

The Appropriation (No. 2)
Act, 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

6

The Appropriation
(Railways) Act, 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

<!-- page 79 -->

883

884

885

886

887

888

889

890

891

892

893

1985

1985

1985

1985

1985

1985

1985

1985

1985

1985

1985

7

The Appropriation
(Railways) No. 2 Act,
1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

14

The Appropriation (Vote
on Account) 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation (No. 3)
Act, 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

16

The Appropriation
(Railways) No. 3 Act,
1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Appropriation
(Railways) No. 4 Act,
1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

29

The Appropriation (No. 4)
Act, 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

37

The Tea Companies
(Acquisition and Transfer
of Sick Tea Units) Act,
1985

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

42

The Appropriation (No. 5)
Act, 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

68

The Appropriation (No. 6)
Act, 1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

71

The Appropriation
(Railways) No. 5 Act,
1985

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

The Customs
(Amendment) Act, 1985.

The Repealing and
Amending (Second)
Act, 2017 (Act No. 4
of 2018)

80

<!-- page 80 -->

894

895

896

897

898

899

900

901

902

903

904

1985

1985

1986

1986

1986

1986

1986

1986

1986

1986

1986

81

The Banking Laws
(Amendment) Act, 1985

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

83

The Futwah-Islampur
Light Railway Line
(Nationalisation) Act,
1985

The Repealing and
Amending Act, 2016
(No. 23 of 2016)

5

the Central Excise Tariff
Act, 1985

The Central Goods
and Services Tax
Act, 2017 (12 of
2017)

6

The Additional Duties of
Excise (Textiles and
Textile Articles)
Amendment Act, 1985

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

7

The Additional Duties of
Excise (Goods of Special
Importance) Second
Amendment Act, 1985

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

8

The Customs Tariff
(Amendment) Act, 1985

The Repealing and
Amending Act, 2017
(Act No. 2 of 2018)

12

The Appropriation (Vote
on Account) Act, 1986

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

13

The Appropriation Act,
1986

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

15

The Appropriation
(Railways) Act, 1986

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

16

The Appropriation
(Railways) No. 2 Act,
1986

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)

17

The Appropriation
(Railways) No. 3 Act,
1986

The Appropriation
Acts (Repeal) Act,
2016 (22 of 2016)
