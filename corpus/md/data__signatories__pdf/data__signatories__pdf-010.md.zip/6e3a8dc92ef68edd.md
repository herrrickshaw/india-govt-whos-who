---
doc_id: "6e3a8dc92ef68edd"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/0893e8bf7afffa7a86e03408f675528f.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction letter dated 28.07.2021 under FSS"
date: "2025-06-25"
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "76a02577b1289ff4"
---

<!-- page 1 -->

In X.N
P-4402 5/7/2020-DBA-1
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
New Delhi, Dated the

28th

July, 2021

To
The Accounts Officer,
Pay & Accounts Office,
Department of Industrial Policy & Promotion,
UdyogBhavan,
New Delhi,
Subject:- Payment of
40,39,82,387/- (Rupees Forty Crore Thirty Nine Lakh Eighty Two
Thousand Three Hundred Eighty Seven only) to NEDFi under the Freight Subsidy
Scheme for disbursement to eligible industrial units during 2021-22.
Sir,
I am directed to convey the sanction of the President for payment of an amount
of 4039,82,387/- (Rupees Forty Crore Thirty Nine Lakh Eighty Two Thousand Three
Hundred Eighty Seven only) to North Eastern Development Finance Corporation Ltd. (NEDFi),
NEDFi House, G.S. Road, Dispur, Guwahati, Assam, Pin-781006 for disbursement of subsidy
to eligible claims (as per list enclosed at Annexure) located in States of NER under the Freight
Subsidy Scheme, on the basis of recommendations of the State Level Committee concerned
and as per existing terms and conditions of the Scheme, as amended from time to time. NEDFi
will furnish the requisite utilization certificate in Form 19-A of GFR, 2017 to this Department
within three months from date of receipt of Sanction.
2.
NEDFi will release the subsidy to the eligible units in accordance with the provisions of
the Freight Subsidy Scheme notified by this Department and as amended from time to time.
Before releasing subsidy, NEDFi will mandatorily undertake scrutiny of the documents
provided in the modified checklists forwarded to all the States/Nodal agencies. NEDFI will also
ensure that the payment to the beneficiary units is made through EAT module. The release of
subsidy may be made to all the eligible industrial units, as per the list of beneficiary units
enclosed with this sanction.
NEDFi vide their letter no. NEDFi/HO/CS/03-OlNol.20/2020-21/77 dated 08.04.2021
3.
informed that no unspent amount is lying with them under Freight Subsidy Scheme for the year
2019-20.
40,39,82,387/- (Rupees Forty Crore Thirty Nine Lakh Eighty Two
4.
An amount of
Thousand Three Hundred Eighty Seven only)may be released in favour of North Eastern
Development Finance Corporation Ltd.(NEDFi) to their A/c No.35796685374, State Bank of
India, Guwahati Medical College Branch, Sethi Trust Building, G.S. Road, Bhangagarh, MICR
Code -781002012 and IFSC Code --SBlN0007700.

<!-- page 2 -->

-2P-44025/7/2020-DBA-iI
Utilization of the above mentioned amount by NEDFi will be subject to the following
5.
terms and conditions as per norms prescribed in GFR 20017 as well as the Scheme
notifications/guidelines:NEDFI will maintain a separate account of the funds released by this Department
(I)
towards release of subsidy to eligible units recommended by the State Level Committee under
the Freight Subsidy Scheme.
The A/C of subsidy released and disbursements made by NEDFI shall be open to
(ii)
inspection by the sanctioning authority/CAG/lnternal Audit Party of the Chief Controller of
Account, Ministry of Commerce & industry, Department of Industrial Policy & Promotion, New
Delhi.
The funds released by this Department shall be utilized for the purpose for which it has
(iii)
been sanctioned.
(iv)
NEDFI shall not park the funds with them and shall release the due amount without
delay after completing all necessary formalities as per the Scheme guidelines and relevant
GFR norms. Interest earned if any is to be reported on quarterly basis by NEDFI to this
Department.
(v)
NEDFI will furnish the Utilization Certificate for the funds being released in GFR 19A
Format within the prescribed time schedule i.e. 01 .04.2022.
(vi)
NEDFI will give an undertaking that they have been following the provisions of Rule
4(1)(a) & (b) of RTI Act, 2005.
(vii) NEDFI will ensure that the assisted unit has not availed subsidy for the same purpose
or activities from any other Ministry/Department of the Government of India or any State
Government.
(viii) The State Governments of NER/NEDFi shall furnish a Performance-cum-achievement
report within stipulated time including their general remarks on the functioning of the Freight
Subsidy Scheme as per GFR 212(3).
(ix)
A detailed expenditure statement shall be furnished by NEDFi to this Department on
monthly basis.
6.
The undersigned will act as Drawing and Disbursing Officer for the purpose of this
sanction.

(1

L,

<!-- page 3 -->

-3P-44025/7/2020-D BA-Il
7.

The expenditure is debitable to the following Head of Accounts:Other Outlays on Industries & Minerals (Major Head)
Major Head "2885"
- Development of Backward Areas (Sub Major Head)
02
02.101
Subsidies (Minor Head)
15.02
Freight Subsidy
15.02.33
- Subsidies. Under the Demand No. 11 - Department of Industrial
Policy and Promotion during the year 2021 - 22.

The necessary funds for the proposed release under FSS shalt be provided by way of
8.
internal re-appropriation of Rs. 40,39,83,000/- from "MH-2552 (non-functional), minor head00.238- Development of backward areas, 09.01- Transport Subsidy Scheme, 09.01.33 *
Subsidies to Major Head- 2885 (functional) - Other Outlays on Industries & Minerals, 02Development of Backward Areas, 02.101-Subsidies, 15.02- Freight Subsidy, 15.02.33Subsidies".
This issues with the concurrence of Integrated Finance Wing, Department of Industrial
9.
Policy & Promotion vide their Diary No. 44988 dated 26.07.2021.
Yours faithfully,

(P. Dasgupta)
Director
Tele: 011-2306 1688

<!-- page 4 -->

-4P-4402517/2020-DBA-li
Copy to:-

1. The Chairman & Managing Director, North Eastern Development Finance Corporation
Ltd. (NEDFi), NEDF1 House, G.S. Road, Dispur, Guwahati, Assam-781006. The
disbursement of Freight Subsidy may be made to the eligible units in North Eastern
Region as per the provisions of the Scheme and instructions issued from time to time.
The utilization certificate may be furnished in the Form 19-A along with the unit-wise
details of the subsidy disbursed.
2. The Principal Director of Audit, Economic and Services Ministries, A.G.C.R. Building,
Indraprastha Estate, New Delhi.
3. Finance-11 Section, Integrated Finance Wing, Department of Industrial Policy &
Promotion.
4. Accounts Officer, Principal Accounts Office, Department of Industrial Policy &
Promotion. Sanction ID is enclosed.
Principal
Secretary!
Secretary,
Assam/Meghalaya/Tripura.

5.

Department

of

Industries,

Govt.

of

6. Director, Directorate of Industries, Govt. of Assam/Meghalaya/Tripura.
7. Budget & Accounts Section.
8.

Sanction Folder.

9.

Guard File.

iK
(P. Dasgupta)
Director
Tele: 011-2306 1688

<!-- page 5 -->

C)

c)

C
OW

(D
0)

Z

4-.

E

N-

N-

00

a)

N
U)

(N

C')

U)

0)

C')

C

(

(0

(N

C)

C)
N

C)
(N

N-

U)

c')

U)
0)

C)
N

a)
C)

(0

°..

U)

(N

co

C')

U)

(N

-

V,
(N

U)
C)
U)

C')
N
C)

c'

U)
_

06

L6

(N

U)

.0

(D

co

C
C)

(0
0)

CE

,-

o C

U)

EE

0

>1

CC
CL

00

NC')
N

N-

06

L6

-

N-

to

v

C4

C')

0)
Cl)

IL)

('_)

C)

.
(0

.o

L-

I-n

— C)
0..

c) C
>
Q_

C
0
0
C
C,,

U)

C-CO
_j

0)

C')
N-

CO

Cl)

9-.

C

CL

C)

I-

C)

— '
o

0

C

CC

'o
-

C)
U)
C)

E

C)
C)

E

o
'4-

CO
CD

(N

()

U)

(N

N

- to

IT

cr,

CD

CD

N-

0

C)

(N

CD
(N

0

(N

0
N

(N

rCl
(N

.3-

.-

(N

0)

(N

C'

U
cli

U)
(N

0)

U)

0)

Q

(N

(0
(N

Iq
C)

co

(N

U)

U)

(0

(0

(0

(0

N

U)

0
N
C)

C)

CD
N

C)

C)

Cl
N
(N

C)
N
CO

C)

N
(N

N
0)
0

N
(0
CD

C')

Q

co

C')

C')

.
C')

U)

U)

(0

(0

(C)

(L)

N

IL)

C)

C)

C)

0
(N

C)

(N

C)
N

C)

(N

(N

(N

4
P

N-

C)

C)

CD

C)

C)

C)

Cl)

N

C)
N

a.

N
C)

C)

1

LO

U7

CD
N

CD
C"l

C)

C)

C)

N

N

CC
3

C')

In

cli

CD

N

C)
N

0

a,

0

C)

0

C)

CD

CD

CL

'CN
CD (N

N

(N

(N

0

(N

(N
('4

(N

(N

(N
(N

N

N

N

N

N

N

N

p
co

p

p

p

p

p

p

U)

U)

U)

a)

U)

U)

C

:j
C

C

C

C

Op
U)
(I
U)

U-

C

C

r

N

IN

r

-

D U)
D U)
.c .2 .
.c .9 .
.r

(N

C')

D

2 .

.0 .2 .

(I)

D (I)
-c .2 .
-

U)

(0

D

2 .

0

2
0

T
C
CC

C)
CD

CD

0
N
N-P

r
w

.

C
o

(I)

C)
C)

N
(0

0
.C')

C)

I.o

(N

..-

- C')

o

U)
U,
0

IL)

(0

CD

0

LL

C)
(0

CD

0
U)

(0

N-

U)

to
(N

9-.

.0

U)

C)

(N

CL
CC

C)
U)

0.

(N

'1'
C')
0)

(0

U)
N-

CD

N--

N-

E
12
(0

(I)
-c.2 .

N-

CO

<!-- page 6 -->

CD

U)
CD

0)
0)
CD

U)
N
N

c)

U)

N

0

C)

10

N

CD

()

14)
CD

CD

C)
N

LI)
N

0

N
CD

C

N

04

CD

N

(C

CD

04

T
:_: ~

Lo

N

m

CD

N

C')

04

N

r

CD

CD

N

a;

o

C)
N

LI)

LI)

r

04
(6
C

N
ai
CD

04

0

(0

0)

N

N

N
0

CD

CD

CD
N

CD
('4

C)

N

N
0)

C')
LO

U)

CD

CD

C)

CD

CD

~

2

0

CD

N
N

0)

CD

N-

CD

CD

C)

C)

0

0)
N
CD

CD

N

CD

N

CD

0

CD

C)

C)

C')
C

N

N
C)

C')

C')

C')

CD
C')

N

N

CD

N

CD

N

lx)

N

r

N

N
-

CD

r

r

CD

C)

N

N

N

C

-

C

CD

r

CD

N

N

N-C

CD

(0

N

N

N

N

(0

0
oJ.

0

0

CD

0

CD

C')

C')

C')

C')

N

N

F-

C'I

N

N

N

N

'-

C

CD

C)

CD

CD

CD

C)

CD

C

CD

CD

CD

CO

N

N

Cl )

C)
C')

U)

U)

U)

U)

U)

ul

r

r

C)

CD

CD

CD

N

N

N

N

N

N

N

N

N

NCD

N

CD

C)

CO

N

-

r

C')

0

N

0)

C')

CD

CD

04
C
CD
N

C')

0

r

N

C')

C)

N

N
0)
C

C)
N
N

N

0

C)

N
N

N

c-I

N

-

N

r

04
04

r

N

NQ

U)

0

r

CD

O

N

CD

lx)

CD

04

C')

N

CD

CD

CD

N

N

CO

CO

00

CD

r

N

CD

CD

-

C')

CD
C')

CD

CC)

CD

CD

CD

CD

N

N

N

N

(0

CO

0

0

CZ

D

cl)

-

LO

-

N
C

U)

N

c

C)
(V)

CD

N

in

U)
N

N

N

N

CD

N

N

CD

N

CD

—

CD

N

lx)

CD

N

N

U)

N

0)

N
C)
N

LO

N
N-

CD

N

CD
N
LI)
N

C)

N

N

N

CD

N

N

CD

LO
LAD

N

'-

-

IL

IL

-

9

D

a

'-

a

—0

Q
-

ME

(

C_)

°E

CL

,

(I Q

'

DtE

E
J

F- z

__ __

<!-- page 7 -->

U)
.J.

C)
C)

C)
co,

C14

LO

LI)

a

('4
C)
CO

CD
CD

C)

C)

('1
co

U)

0)
'4)
LI)
0)

C)

14)

CD

-

C)

aD

CD

CO

C)

C))

(ID

F

( I)

LO

C)
N

Lo
CC

lc~

C)

CC)

(C)

C)

N

c)
0)

Gi
N
C)

U)
C

(C

C14
F

vi

N

C)
C)

C)
N

()

0)

CD

CD

r

0

r

F

)
Cl)

N

C)

F

F

N
LO

F

F

C)

P

F

CD

F

F

F

CD

0

CD

CD

C)

C)

F

F

C)

Cl)

(0

CD

F
F

F

In

N

C)

N

F

Cl)

C

N

N

N

CD
C)

cli

F

F

C

C)

N

N

N

F

C)

C)

U)

o

o
F

CD

(0

C)

C)
0)

F

CD
CIA

C)

0)

C)

C)

N

N

a)

N

N

C

C)

N

C

C)

F

N

N

N-

C)

F

N

F

t--

N

0)

C)

N

N

N

N•

CO

F

0
r

C.

0

F
F

F

0

0
U)

U)

U)

N

N

._

U)
F

C)

CO

tm
—

o

C

U)

LIJCCOC
-

U)

Z Z<

t

-

U)

U)

oB
Z Z
<
N

U)

O

ZZ
F

0)

C

WCCOC

WCCO

N

CD

C

C

CL

C
CO

N

F
F

0)

0)

C:)

C)

C)

N

C')

C)

C)
a)

C)

C)

to

0

F

F

F

F

_

.

CD

N

N

N

N

N

C)

C)

C)

N

N

LO

U)

N

N

0)

N

N

('4

('4

C')

.

0

0)

C.

C)

CO

06

N

N

N

N

rID

CO

00

C)

0

0

C

F

F

F

F

N

N-

LO

U)

CO

U)

C
CO

WCCO
U)
0)U)

ZZ<

U)
0gU)

-

a

ZZ
U)

N

N

N

N

<!-- page 8 -->

CA

00

CN

CD

C14

t—

Cli

co

N

CD
N
U)

0)

00

Cl)

N

N

N-

U)

(0

CD

0)

0)

0

n

0)

C)

Cl)

N

N

N

N

N

N

C')

C')

CD

N

CD

C)

CD

C')

C')

C)
C')

00

0)

0)

C)
N

C)

C)

N

N

N

CD

C)

C)

C)

N-

U)

U)

co

C)
N

C)
N

C)
N

C

C)

C)

N
N

N
N

C)

(0

U)

U)

C')

C)

C)

C)

N

N

N

C)

CD

C)
U)

CD

(0
0

C)

C)

C)

C)

CD

N

C)

C)

CD

C)

C)

N

N

N

C)

N
C)

C)

C)

C)

CD

N

N

co
0

C')

C

C'

C)

C)

C)

C')

C
C)
co

C)

N

N

(0

CD

C)

CD

C)

C)

C)

C)
N

C)

C)

C')

C')

CD

2E
(

C)

N

C)

'

(0

(0

N

N

N

N

N

_

2E
't

-

D

E .

C14

C)

r

N

CX)

______

'

E.E

D

~

Th

co

N
N

-

-

Wwuu—
CN

C)

!

.-.

0)

C

r

N

N

CO

N

N

0

N

N

0)

C)

0)

C)

LO
N

cz;

N

C)
Cl)

a)

ct

00
C)

CD

N
C)

Cl)

N

CD

-

C')

cli

C')

N

N

N

U)

U)

N

N

C).

OD
N
C)

0)

N

C')

C)

0)

cC

CD

C)

C)

CO

co

C)

(0

U)

0)

C)

N

N-

0)

C)

C)

N

N

N

N

N

0)

CL)

-

~ 2.
(n Li
-

Cl)

cu

E

<r1

CL

<!-- page 9 -->

j1i

U)
L1)

co

\

to

U,

C)

C4

cli

C14

C)
04

00

oo

U)

CNI

c'_

cli

N
.

a)

N
C)

NN

N-

(0

Nco

U)

OD
N

(0

0)

N
N
N

N
cNi

C

N- -

N

N
N

N

C

(0

00

00
r
r

0)
C

N
(0
C)

N
cli

N
(lj

-

C
N

r
C

N

c'4

N
C6
C)
U)

N
C)

CD
C)

C)

.
C)

C

Ci)

(0

(0

0

C)
N

N
0)
U)
r

U)

C)
N
0)

C)

N
U)

N

N

C

C

0)

a)

U)

r

N

C)

C)
N

N

C

C)

r

r

C)

C
N

r

N
Cl)
C)

N

N
Ci)
C)

C

C)
Cl)

C

C)

C)
N

C)

N-

N-

N

ci)

r
C

C)
r

—

N

N
r

ci)

CL

0-

2

a 2ct
(00:

) 0

N

N

N

N

N

N

CD

C

C
N

C

C
C14

Cli

2

2

C

ci)

10
r
C

U)
r
0

ci)

ci)

ci)

Cl)

C)

C)

U)
r
C

r
C

N

N

C-a
C

(0

r
r
C)

P

U)

(0
C)

C)

C

E

•E

5'_

: J)

a 0:

2

a

m

N

C)

CL

CL

N-

Cl)

r

C)

c

U)

N

C

C
N

CO

—WEiE

C

C)

C

U)

N

Co

N

N

N

N

C)

C)

00

CO

N
r

C

co

U)
C
C14

N
r

N

IcnD

C

(0

U)

(0

CD

C)

C
Cl)

ci)

r

r

C)

Ci)

C

N
p

C)

C)

NC

N

N

N

N

N

(0

ci)

C

C

C)

N

N

C

ci)

Cl)

ci)

N
C)

r
C

C

-

ci)

Cl)

N

N
N

C

C

C)

N
N
C)

N

C
N

C)

r
C

C)

r

Ci)

E

E

0

Ct 2 C

Ct

0 C Ct 2

0)

C

,

U)

0

D

E
U) 1)

N

E

In

U)

0

0 D

U)

C co 0 C

<!-- page 10 -->

N

CO

N-

IT

CD

N

N

a

NC

C)

0)

U)

C)
CO
U)

N

CO

Q)
U)

CO

C)
U)

U)
CO

N-

U)

a

U)

CO

N
U)

CO

N

C)
C)

I

CO

CD

N

N-

N-

co

N

N
U)

I

I

I

N

C)
0)

0)
U)

N-

C)

I

I

I

a)

0)

N

U)

U)

N

LO

00

—FIT

c

cli

LO

C)

04

C14

00

CN

C14

N

co

Cl)—Cl)

(D

TI-

r-

Cl)

r-

DO

DO

00

00

C14

00

N

C14

Cl

4

L6

L
9-9
co

>-2

-E
2D
(DO

OO

U)

CD

t)>

D0

CCt

(9O

oj
a) LL- Qi

co LL

(I)LLQ-

<.Z

N-

co

C)

CD
U)

U)

<!-- page 11 -->

0)

N

N

C)
CO
CO
a)

0)

N

LO

0)

Vi

—

CO
N
CD

—

0

(0
(0
(N
CO

-

U)
N

CO
N
(0

-

U)
C)

C)
CO

_
CO
N

N

CO

N-

I

$

cl~

(0

N0)

CO
C)
CD

'

CO
N

CD

CO
(0

N-

0)

Cl

0

N

C)
(3)

N

-

'4)
N-

N
N

'

N

CO

-

CO
N
NNN

N-

0)

CO
N

Co
CO
'4)
0
CO
0)

CO
(3)
C)
0)

CO
N
N
(N

0
'4)
N-

I

I

I

I

I

I

CO
(N
CC)
It
CO
(14

(0
()
'4)
C)
CO
C)

CO
N
NNN

NCO
C)
C)
C)

C)
(0
N
N
(N

C)

--

-

a)
U)
(7)

CO
CO
Vi
CD
CO
0)

C)

(0

(0
0
N

CO
CO
0

C)
CO
CO
CO

(0
(0
N
U)
N--

C))

CO

CO

CO

(C)

CO

N-

t4)

CD

(0

CD
N

0
N
C)

CD
N
C14

0
N

0
N
CD
CD
N
(N

CD

C)

C)

C)

CD

N

N

N

(N

N

0)

CO

CO
C)

C)

N

N

0
7
C)
CD

CO

CO
C)

(N

r

a

Co
CO
N-

'

N

r

N

0)
N

N

C)
NN

C)

N-

CO

N-

$4)

CD

(0

CO

CO

(0

C)
(14
(0
C)

C)
04

C)
N

CD
N
('4

C)
N
CO
CD

C)
('4
C)

0
('4
('4
.

C)
('4
C')
C)

C)
CO

I C')

'

,

14)

0

N

7

C)
('4
CO
0

Cl)

IM

CO

CO

CO

CO

C)
C14
CC)
0
C)
CO

0)

N-

CO

N-

CO

CD

(0

CO

CO

CO

C)
(-4

C)
N
Cl

C)
N

C)
N
C)

C)
N
C)

C)

C)

C)

C)
N

C)
(N

CO

CD

CD

CO

(14

N

(N

C')

CO

CO

C)
(N
N-

0
N
4
CD

C)
(N
li
CD

CD
NJ
CO
0

C)

C)
N

C)
N

C)
('4

C)
N

C)
('4

C)
CD

0)
CD

CC)
C)

CO
C)
N
CD

CO
0
(N
CD

N

C)

r

,-

r

r

(14
C)
0

- .

CO

C)

I CD

0

Cl

- N

(N

('4

C14
C)

(0

tO

CO

41)

CO

CO

CO

41)

44)

U)

C)

CD

C)

C)

C)

C)

C)

00

C)

(0
C)

CD
17

C)
C)

7

CO
C)
('1

C)

C)

CO
C)
N

P

C)

(0
C)
C14

('4

('4

0

0

0

U)
'0

U)
0

,

It

.—

-

.0

(0

-

)

(N
$4)

4])

U)

1

CD
CO

-

U)

)

U)

a

C.)

0

U)

E

U)

0
IL

It
CO

C))
CO

-

.0

(1)
IL

-

.0

IL

-E

in
°
0

oo

0)

Q)0)

2

2

>

(9<0

(0

(9<0

000000

N-

CO

C)

LI)

CO

00)
C) >-

4])

2n

C)

C')
U)

C)
CO
( 14

(0
to

U)

2

LL -

0 co C)
C)
(0

-

CO

<!-- page 12 -->

( ('N

CY)

N.

N-

N

CO

CD
CO

-

a

CO

F.CD

N

CO

C)
CO

NC)
N
CD
CD
(N

CD

CO
g
N
CD

P
CD

(0
CD
N
0)

P

C)

a)
CO

LO

(3)

CD

N
C)
CD

C)
(N

(1)
CD
N
(N

'

¶2

C)
N
CD
''-

'-

CO

C)
14)

N-

04

rl-i

N
(3)

LI)

CO

CO

Cl)

C)

C)

C)

(0

CD

C)
C14
CO
C)

CD

C)

C)

CD

(I)
C)

CO
CD

C)
C)

r—

N.
C)

CO
CD

'(N
CD

(C)

CD
N
N

C)
N

CD

0)

CO

0)

CD
N

C)
N

CD

(C)

(N

C)

CD
N
(0
P

.•

N.

N
C')

—

Cl)

(0

C)

CD

C)

CD

C)

N.

C)

(C)

CO

C)

C)

(N

(N

N

Li)

U)

U)

N

N

N

CD
CO
N

C)
Cl)

(N

ct

C)
CO

CD

CD

C)

N.

C)
C)
_

N

co
CD

CO

-

LI)

N

N
CD

CD

'n

0CG)Om
O00000<_.s<00(0
N

CD

CO
(0

Li)

(0

(C)

(0
CD

C')

CO

(1

4

N

N

CC
0)

CD

CD

CD

Cl)

CO

CO

N

N

N

N

C)

C)

0

C)
N
(4

CO

N

ct

C)

N

.

N

C)

Ct)

CO

0

(C)

C')

CD

N

C)
0

0)

C)

N

N

Cl)

CD

N

N

co

(0

14)

CO

C)

C)

N

F.NN
r

(0

11)

Cl)

(C)

N

C)

N

0)

CD

N.

N-

(0

Cl)

Cl)

CO

CC

C)

C')

Cli

U)

C)

CO

00

co

C)

r

ED

Cl)

LO

00
LO

00

N-

CN

CO

C)

C)

E
E'aoco
<00(0

.U1
Ca)O0
<00(0

E>m

E>co

N

00
CD

0)
(0

CD

(0

N-

<!-- page 13 -->

NN
C)

N

oc~

OD

N

()

C)
N-

N

0

N

N
N
cc~

N

N

c)

N

N
N

N

N

6

0)

N-

C4

d

C)

C

r

N
N-

0)

ol:t

-

0)

N

N

N

0)

co

N

N

C)

I
I
I

0)

N
N
N

0)
N

cx5
N

N
N

N
N

N

N
C

N-

DO

c'i

6

C)

N

N

C

N
N

C)

C)

N

C)

0

N

N

N

C)

N
C

C

C).

Q

C

C

C).

C).

C

C)
C:)

C)
C
CC
0

C)
C)

CD

CD

N

N

o6

CD

N

C)
C~

C14

N
N

N

N

N

a,

a,

£)'E

£)

a,2

x-E

D

a,

L()

D

-1E

i-E

E

E>
N

N

-

-0

(u

C)

CL

C:L
D

0)

Co

00

C)

C)
N
N

N

N

N

N

N

D

C

N

N•

N

N

N

C)

C)

C)

C)

CD

C

D

C)

C

N

C)

N
N

C

CD

C

0•

O

C

C

N

06

N

0

C)

0

N

C)

N

C

C

C

CD

N

Q

C)

co

C

CO

C)

C

C

..

Co

C)

6

C)

N

N

C

C).

Cl
C)

( )

0

C)

6

C)

C

N

C

N

N

N

C)

N

N
(0

C

C

C)

C)

CD

r

Cl)
)

(0

cq

CD

6

C

C)

C

C)

N-

C

C

()

6

N

6

C

C•

C)

C)

C)

6

C14.

N

N

N
C)

C).

C)

CD

CD

C)

cD

N

N

C)
C)

N

(0
C

6

C)

N

N

N
N

N

CC

N

(0

N

Co

<!-- page 14 -->

00

co

CD

co

00

LO

cn

lily

CD

00

LO

Nr

It

Co
0)
)

0)

N-

0)

C)

CD
(C)

a

N

(0

(0

(0

N-

co
CD

00

CD

C)

N
CO

C)
N

(C)

U)

LO

CD

CD

N

N
CD

C)
P

N

C)

CD

a)

C ))

1)

C,

CD

CD

N

N

C)

CD

(14

Cl

CD
ç)

C)

p

(C)
p

C)

I))

a)

C:)

a)

CO

a)

a)

CD

CD

C)

-

a)

U)

a)

C)

C)

C)

N
P

C)

C':)

co

r-

r

N
P

N
P

N

C)

CD

0

CD

C)
N

C)
N

co

co

N

N
N

,-

C)

C)
N
C')

P
CN
N

P

_

c
-_Ei:

.

.

r

o

E

<CL

E

-°

E

<0
Go

E

C

E

C

N

-

a)
!14

C)

CD

C)

N

0'

P

C)

N
a)
P

N
a)
P

C)

a)
C)

(C)
C)

U)
C)

C)
N N
11
6
O C)
C)
C')

C)
N

C)

C)
N
NP
U)

NCD

C)
U)
-

-

Cl)

C

CL

C

.2
.?

.DCü,U)

C

a)OE

U.

.

--a:
-'-

O

D

(I)

N

N
P

N

(0
)

C)
-

N
P

0)
(0
D

r

C)

C)

P

0)
C)
C)

a)

N

C)

C)

C)

LL

CD
(D
CD
)

C)

N

N

-

C)

N

CD
N

N

a)

N
P

0)

N

,-

0)

N
(
p

C-)

C>
c)

C)

0)

N

C)
C)

CD
co

)

—a.rn

CL

<' -

DUJ

U)

C

CO

Cl)

.2

.2

oE

aDOE

C

C

<Cl)

0 C
a)rn

WH

<Cl)

0

~

C

WH

<!-- page 15 -->

C)

c)

cc

N

N

N

N
(0

co

N

N

N
N
CO

N
N

_

N
N

00

(0

tn

CD

U)

LO

CD

U)

Cl)

N
N

N

N

U)

N

N
N

to

N
(0

cc~

co

co

N
N

N
N

_
N

N

co

cc

N

CD

N

U)

In

CD

U)

cc

N

N

N

U)

I
I
I

()

N
N

0)

N

0)

CD

N

Cli
U)

r

0)
r

r

N

C)

o

0)
CD
(0

N
cc

U)

(0

r

r

r

C)
C4

N

U)
o
CO

_

C)

CO
CD
N

CD

_

co

0)

r

cc

C,

N

C)

C)

N

N

N

N

(0

_

-

cc

r

r

N

LL

-

cc

C)

N

N

N

N

C)

r

C)
N

C)
N

C)
N

N

N
(0

N
(0

N

0)

N

_

N

N

_

CD

CD

CD

UU)

N

CD

r

C)

CD

Cl

N

N

N

N

N
N

N
N

r

N

N

CD

CD

CD

N

N

-

C.
C)

CD

N

CD

N

CD

a)

H

CD

to

U)

N

N

06

00

N

N

CD

co
Cl

N

N
N

LL

V
0

u..

)
0)

0)

C

C

co

(1)
C0

_3
U)

r

CD

N

U)

N

U)

CD

CD

N

(0
N

0)

()
C)

U)

co

-

CD

c)
N

C)
N
0)
C)

CD

C)

r

N

N

0)

0)

0)

N

N

N
N

N

C)

co

N

00

C)
0)

N

U)
(0

CD
U)

U)
CD

So
co

N

ao

0)

C0

m

<!-- page 16 -->

CO

U)

C)

C)

CO

0)

N

_N

(N

0)

C)

N

CO

CO
C

LI)
0

C)

co

N

(0

N
C)
N

(0

N
N-

N
N

CO

'-

C)
(0
N
C)
N

N

(N

N

N

(0

C)

CO
CO

N
N

C)
NN
C)
CO

U)

0
CO

N

CO

CO

N-

N
N

N
N

'Kt

r(0

C)

CO

(3)

(N
C)

C)
Cl)
N

N

(N

N

(0

C)

U)
00

N-

C)

N

c
C)

C)
C)

-

'-

(0

L

0)

a)
(N

CO

C)

C)

N-

C)

0)
(0
N-

NN

C)
N
N
N-

CO
(0
C)
LI)

N
N

cr

a)

0)

(0
N
N
NC)
N
Co
NO

Cl )
(0

0)

LO

(N

CO

C)

CO

(0

'k

N

CO

0)

0)

C)

C)
(N
N

C)
N
0)
C)

C)
N
(N

N(N

C)
(0

C)

0)

0)

C)

C)

C)
(N
(0

C)
N
C)
C)

C)
N

C)
('4
N

CD
N

U)
N

C)

C)

C)
N
C)

a)

a)

0)

C)

C)

C)

00

C)

C)
N
C)
CD
C)

C)
(N
N

CD
(N
a)
C)

CD
(N
0)
C)

CD
(N

C)
04
N

C)
N

-

C)
(N
NC)

CO

CO

CO

(0

CO

U)

CO

(7)

C)

C)

C)

00

C)

C)

CD

CD

C)

C)

N

N

(N

CD
N

-

C)

NC

C)

NC

U)
C)

(Y)
C)

(0

(0

(0

C)
(N

C)
(N

C)
(N

C.
(N

C)

C)

CD

C)
N

N
C)

N
CD

C)

C)

C)

C)

(N

N

N-

N-

Co

C)

CO

C)
C)

N

(N
C)

-.

-

C)

C)

CD

N

N

0
N
C)

C4 CD

C)

C)

N

C)

C)

(N
CD

N
(0
CD
C)

(N

I

_ 6

Cl)
P
0
CO

U) c

C)

C)

C)

CO

CO

N

_
C)

-.

C) C)
-1L.

N
NP
N

N-

P

0)
N

-

N

N

N

-

CO

U)
Co

n

CU)

CLI)
.0

>-

CU >

.9

fl

~

9E

< -t,

a)

>-C

('4

a)

-

di

0

>-

0

c

U)

.-

(I)

>

C)

a)2.—
0

(1)

(2)-.

(30
It

0

(1)

C)O
LO

0H-

>0

(1

Oz_

.9
U

IL
ECCU

.

C)

(0

o

-Q--

o
..

LL

ECCU
a)
0C1

OI-

<!-- page 17 -->

co

Cl)

co

04

C)
cC
C
N
U,
Cl)

co

co
C)

C)
00

(C

CN

cC
C
N

In

C14

C
00

co
C)

N

_

N

N

U)

P

r
CD
N

N

Ul

P

N

N

r
C
N

N

C)

p0

0

C
N
N

_

o
Cl)

(C

(C

LL

r

r
C

m

.Go _

CC)

r

_

C)
r

C

U)

(C

r

C

o

N

.

or

r

N

N

P

r

P

C.
C
N

N

0•

(C
P

0

P

>0

C)>-

cn

C)
N

N

n2

mE

C)>

W

N
N

C

N

N

N

mE

U)

r
C

N

(0

>0

v,2

N

r

N
(0

N

r
C

C

r
C
N

r
C

C3

LO

C

r

r

LL

CD

U,
r

C.

r
C

- _

C)

_

r
C
N

P

. _

N

U)

N

_

CD

C

0

U)

N

p0

_

Cl)

_

C)

C
N

Cj

0

N

N

C)
r
C
N

(C

N
N

N

N
N

N

N

r
C

N
N

C

r

(C

0)

N
N

a

a

C6

C)
r

CF)
r
C
N

0)
0)
r
C)
N

ILO

(0
N
(C

N

N

0)
N

(C
00

Cl)

U,

CD

LI)

co

N

N
N

00

LO

Cli

Lri

CL

mE

C)>_

m
2W

—0

<!-- page 18 -->

f TJFTTT1FJJi
CO
U

U)
C'
(0
CO

(0
C
U)

CO

co
('4
CO
CO
U)

U)
CO
N
(0

(0
CO
N-

(0
(0
F)

(0

N

N('4

N
F)

00
C14

Cl)
(14

Lo

liT

I

I

C)

N

(0

U)

r>
U)
U)

N
CO

CO
N
(C)
(C)

p-

U)
CL)

CO
U

4)
C'
(0

Oct

0)

U)

U)

('4

CO

U)

F)
CO
N

-

00

CO

C)

C)

C)

C)

ID

(C)
C)

0)
C)

0'4

F)

CO
C)
U)
0
N

N

0)

CD

C)

C)

C)

N

7

04
17

1

CO

00

C)

0)

1

(0

CO
('4
CO
U)

in

w—

r

N

7

O

N

C)

C)

C)

C)

C)

C)

C)

C)

C)
N

C
N

F)

CO

CO

(C)

C)

N

CO

C)
N
C)

C)

6

6

F)

C')

CO

0)

0)

0)

-

C)
C')

C)
NJ

Co
N

-

U)

N

NJ
N

CO

C)

NJ N

CD

N

C)

C14

C,4

0

'

-

('4
i -.

CO
C)

J
C)

U)

D?0)

CL

c

(U

2-o

co

r

Co
N
N

,-

7

1

CO

Cl)

CO

6

7

CO

C)

0)

0)

C)

C)
N

C)
C')

C)
NJ

C)
NJ
N

CD

C)

CD

C)

C)

C)

C)

0

U)

U)

_

U)

(C)

(C)

(0

U)

>(

CD

><

C)

0

C)

NW
C')

NW
F)

-

NJ
F--

N

N-

C)

CD

C)

C)

C)

('4

C)
NJ

C)
NJ

C)
NJ

C)

-

C)

C)

CD

0.

C) X

C)

NLU

NW

F)

CO
CD

QO)

)<
-

-

'-

d)

C)''

'-

-

C)
NJ

C)
NJ
C)

0

C)

C)

0) >

0) >
0)0

C

C

C

.2

2

5) >

(1)

IOC

cL

F-

H

0)

C)
N

CD
N
C)

C)

!e

(0
C)
0
N

N

C)

(5

NJ

C)
N
N
P

1)

5)>
C00

('4
CD

C')

C)•
N

.

C)
N
C)

r

r

C)

LL

E

C)
0)
N

N

CD C)
HNJ

CO

CC)
U)
00
('4

Cl)

C)
NJ

-

_J Co_

('1
(7)

U)

N

CD

CD

N

c')

C)

C)
N

C)
NJ

C)

~

F)

NJ

_

U)

C)

C)

C)

C)

C)

N
N

I

C)
C)
CO
F)
N____ N
0)
0)

0)

LO

C14

>

lI)Q.

LL

_j
CU)

cm

.

(1)

CU)

CU)

2

2

cL

__
LO

r-

<!-- page 19 -->

(I) 1

IL()

c)
0

N-

litOI
t__r.

•

(0

c

0

co

..

to
LI)

to

0

to

LI)

(0

U)

uc

c

cli

co

to
0

('J
0

N

(0

o

Cl)
0
a)
0

N
a) cDc
C)
C)
0

N

N-.
CD

C
('1

—

o 0

0

+
+
Li'
+

LL
('l0
I

__U,

0

+
CO
+

j °.

(1)0
C.,

-

(I)

ui2.6.2

2--=g-=

0
.
