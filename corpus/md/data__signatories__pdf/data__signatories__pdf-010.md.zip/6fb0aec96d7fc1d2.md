---
doc_id: "6fb0aec96d7fc1d2"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/209f796daaefb6168c3f14b07c1c6cd9.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of M2M numbering series to Ms Bharti Airtel Limited for Maharashtra LSA"
date: "2025-06-05"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ba1e9550b97e464b"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No.16-02/2024-AS-III/Part-I/ 106 Dated: 05.06.2025
To,
M/sBharti Airtel Limited
Subject: Allocation of M2M numbering series to M/s Bharti Airtel Limited
for Maharashtra LSA.

In consideration of request of M/s Bharti Airtel Limited to allocate additional
number resources for Maharashtra LSA, it is decided to allocate 5 million additional
numbering series to M/s Bharti Airtel Limited for Maharashtra LSA as follows:

TSP LSA Country | M2M_ [Licensee Identifier| Device
Code 2 | Identifier| 4-digits (10000 |Number 6
digits | 3 digits blocks) digits
(1 Million)
1. [M/s BhartiMaharashtral 91 575 | | 4129 XXXXXX
Airtel
Limited =
2... This is issued with the approval of competent authority. a fee
Digitally signed by
» Vaibhav Jain.,
3 < : Date: 05-06-2025
oo. . 10:58:50
a eee क Director (AS-III)
he aa Ph. No. 011-23372488
के Copy for kind information and necessary action, if any, to;
. Secretary, TRAI.
2. All Access Service Licensees. . :
3. Director(T), DGT HQ, DoT with request to circulate the sanction to related
LSA.
4. A copy for upload on DoT website. है हु
