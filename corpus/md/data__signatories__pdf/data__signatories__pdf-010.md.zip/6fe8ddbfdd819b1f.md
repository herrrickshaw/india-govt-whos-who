---
doc_id: "6fe8ddbfdd819b1f"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/84531748263066.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Dr. Ambedkar foundation is inviting the Application for the appointment of Consultant Schemes"
date: ""
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ed067f5cce8aafcb"
---

<!-- page 1 -->

DAIC-11012/7/2021-DAIC-FA 1/46051/2025
| Dr. Ambedkar Foundation
(An autonomous body under the Ministry of Social Justice & Empowerment)
Govt. of India
West Block-1, Wing-7, Ground Floor,
| R.K.Puram, New Delhi-110066
(Tel.011-26180213)
Website: www.ambedkarfoundation.nic.in
आज के के के के के
INVITATION OF APPLICATIONS FOR APPOINTMENT OF CONSULTANT (ACCOUNTS AND SCHEMES) OF APPLICATIONS FOR APPOINTMENT OF CONSULTANT (ACCOUNTS AND SCHEMES
Applications are invited for those candidates who are retired in the Central Government /State
Government/Union Territory/Public Sector Undertakings/Autonomous Organizations, Company/Private
Organizations ete. for filling up Vacancies in the Dr. Ambedkar Foundation, an autonomous body under the
Ministry of Social Justice & Empowerment.
jor ऑफऊ<ऊ/
| [0 | | ० फफ//|;/
2. Complete information of post, eligibility criteria, application format and other details are available
on the website at www.ambedkarfoundation.nic.in, htps://socialjustice.gov.in, hitps://cva.nic.in and
https://dopt.goy.in.
3. Last date for receiving of applications through proper channel from date of issue of advertisement
in employment news within 21 days. Incomplete applications received after the last date shall not be
considered.
4. Address for sending applications:
Director
Dr. Ambedkar Foundation,
(an autonomous body under the ministry of social justice and empowerment)
| Govt. of India
West Block-1, Wing-7, Ground Floor, R.K Puram, New Delhi-110066
A Ae
| rector, DAF
अनिलकुमार वी. पाटिल///1॥00॥8&/ V, Patit
at tee one कण
Or. Ambedkar Foundation
'समाजीक न्याय एवं अधिकारिता मंत्रालय
‘Mo Social Justice & Enpowermont
भारत सरकार, नई दिल्ली ०
क्‍ ‘Government of india, New Dethi

<!-- page 2 -->

DAIC-11012/7/2021-DAIC-FA 1/46052/2025
| E.O No. 34929
Dr. Ambedkar Foundation
(An autonomous body under the Ministry of Social Justice & Empowerment)
Govt. of India
West Block-1, Wing-7, Ground Floor,
| R.K.Puram, New Delhi-110066
| (Tel.011-26180211)
Website: www.ambedkarfoundation.nic.in
Horror ik
Date:21/05/2025
| Subject:- Invitation of applications for appointment/engagement as a Retried Officer from Central
Government /State Government/Union Territory/Public Sector Undertakings/Autonomous Organizations,
Company/Private Organizations etc. Consultant (Schemes) in Dr. Ambedkar Foundation-reg.
Filling up of Vacancies in Consultant (Scheme) Contract Basis in the Dr. Ambedkar Foundation,
Ministry of Social Justice & Empowerment.
2. Applications are invited for those candidates who are working on contract basis in the Central
Government /State Government/Union Territory/Public Sector Undertakings/Autonomous Organizations,
Company/Private Organizations etc. for filling up Vacancies in the Dr. Ambedkar Foundation, an
| autonomous body under the Ministry of Social Justice & Empowerment.
3. The Details of Educational Qualification & Experience required by the candidates on Contract Basis
are as under:
Job Description
Not exceeding 62 years as on 01 January,2025
Salary Range (Rs.) As per the Govt. norms and approved by Mo SJE for the consultant is as
under:
(a) Gr-II (SO Level) @ Rs.35,000/- P.M. + Rs.2,000/- as conveyance.
(b) Gr-III (US Level) @ Rs.42,000/- P.M. + Rs.3,000/- as conveyance.
Contract Basis (initials for One Year which may be extended further)
| Qualifications Graduation/Post Graduation from any recognized University.
Experience of handling legal cases in a Government
Department/Autonomous Bodies/PSUs.
Desirable Working Knowledge of Computer Operation and E-Office.
Working knowledge of Noting and Drafting in Hindi and English,
Cut Off Date Cut-off date for determing various eligibility criteria (educations
qualifications, age limit, experience etc) will be the last date for
submission of applications i.e 23.06.2025
Primary Responsibilities: Schemes, Legal Matters, CP GRAM, VIP References, Parliament
Questions and any other work assigned by competent authority.
|
|
|

<!-- page 3 -->

| 4, “HOW TO APPLY:
0) Eligible candidates may fill application form in given proforma (Format-l) giving complete
details with recent photograph. Application sent to the office of Dr. Ambedkar Foundation,
West Block-1, Wing-7, R.K Puram, New Delhi-110066 by 23.06.2025 (i.e. Last date for
submission of application).
(ii) A scanned copy of application alongwith all requisite documents such as document in support
of Date of Birth, Valid Identity proof of the candidate issued by Govt. Certificates regarding
Educational/Professional Qualification, Experience Certificate etc. must be sent (in pdf format
only) through email at dir.da!-msje@ov.in or before last date i.e 23.06.2025 List of documents
are required to be enclosed is available at Annexure-B.
(iii) Application in other than prescribed proforma (Format-I)/incomplete application not received
on or before closing date will be rejected without any intimation to candidate concerned.
(iv) No fee is required to be paid by the candidates.
5. Willing and eligible candidates, who can join immediately on selection and are free from vigilance
angle may be sent application to the Dr. Ambedkar Foundation, West Block-1, Wing-7, Ground Floor, R.K.
Puram, New Delhi-1 10066 in the prescribed format as per Annexure-A within Z date.
( पा iD
irector, DAF
अनिलकुमार वी, पीटेल/#॥॥॥जवाअ ९४. 2291
Prews / Director
f sretsar nfrert/ Dr. Ambedkar Foundation
समाजीक न्याय एवं अधिकारिता मंत्रालय
Mio Socat. usc & Empowerment
रत सरकार, नई दिल्ली
Government of India, New Delhi
|
|
|

<!-- page 4 -->

Annexure-A.
Dr. Ambedkar Foundation
(An autonomous body under the Ministry of Social Justice & Empowerment) (photo)
Govt. of India
Camp office: West Block-1, Wing-7, Ground Floor,
R.K.Puram, New Delhi-110066
(Tel.011-26180213)
Website: www.ambedkarfoundation.nic.in
DETAILS OF CANDIDATES ’
SINo | Particulars Details to be filled by Candidates
Name of the candidate [| ् ््-्््मऑ---ऑऑ'
2 Guardian Father/Mother Name with
Mobile No
| 3, | Date of Birth/Age
(as on 01 January,2025)
4. Category
(Gen/OBC/SC/ST)
5. Sex
(Male/Female/Transgender)
[& | AadharNo (Copytobeencbsed) | i
7. Education Qualification (10
Onwards)
(Exam/Year of
passing/Division/Yage)
(Copy to be enclosed)
Technical Qualification
(Internet Access/Power Point
Presentation /Excel/MS Word)
Experience
(Job From & To)
|
Skill
(Computer Typing English/Hindi)
11. Home Address with Pin
Code
Date : Signature of Candidate
Place:

<!-- page 5 -->

| Annexure-B
| LIST OF DOCUMENTS TO BE ENCLOSED
| S.No. Description Indicate
(Yes/No)
A) Educational Qualifications | ti‘sSsSs—sS™Y
| 1. Matriculation Certicate (Class X Pass
Certificate)
| 2. Class XII Pass Certificate
| 3. Certificate of other educational qualifications
| such as UG, PG, ete.
B) LS
| C) | Valid Identity proof of the candidate issued by
Government (Aadhar/PAN Card)
D) | Experience Certificate in the prescribed format
| (Annexure-B) for service rendered in the Central
| Government /State Government/Union
Territory/Public Sector Undertakings/Autonomous
Organizations, Company/Private Organizations etc.
started from latest one.
E) | Copy of LPC and PPO should be enclosed by the
|? | retired Government servant.
F) | Any other relevant documents in support of the
|? | candidature.
