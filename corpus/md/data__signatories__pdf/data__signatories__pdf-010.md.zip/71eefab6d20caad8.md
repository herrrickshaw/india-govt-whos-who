---
doc_id: "71eefab6d20caad8"
source_url: "https://www.moes.gov.in/static/uploads/2025/06/d6413fe858c14d5021b880ba230fe3d7.pdf"
ministry: "Earth Sciences (MoES)"
title: "Tender for Disposal of Obsolete Office Equipments, Ministry of Earth Sciences, O/o Controller of Accounts"
date: "2018-03-24"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "55bc91ffafefd674"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
Ministry of Earth Sciences
Prithvi Bhavan, Lodhi Road, New Delhi – 110003
O/o Controller of Accounts
No. PrAO/Admin/Disposal of Obsolete & Unwanted Stores/2017-18

TENDER FOR DISPOSAL OF OBSOLETE OFFICE EQUIPMENTS
Sealed tenders are invited from the interested Recyclers/ Re-processors for disposal of condemned
computer systems, UPS, other computer peripherals, furniture and other office equipments (herein referred as
“items”) as mentioned in the Annexure II on “As is Where is” basis.
Schedule of Tender:
1 Tender No.
2 Tender Type

No. PrAO/Admin/Disposal of Obsolete & Unwanted
Stores/2017-18
Limited

3 Tender Category

Sale

4 Estimated Cost

1,60,000/- (Rs One Lakh Sixty Thousand ) Only

6 Amount of Earnest Money
Deposit
7 Last date and time of receipt of
tender
8 Date and time of opening of
tender
9
Venue

5,000/- (Rupees Five Thousand) Only
23-03-2018 at 13:00 hours
23-03-2018 at 15:00 hours
O/o the Controller of Accounts, Ministry of Earth
Sciences, Prithvi Bhavan, Lodhi Road, New Delhi 110003

SENIOR ACCOUNTS OFFICER (ADMINISTRATION)
O/O THE CONTROLLER OF ACCOUNTS, MOES,
LODHI ROAD, NEW DELHI – 110003

Page 1 of 13

<!-- page 2 -->

Tender No.: PrAO/Admin/Disposal of Obsolete & Unwanted Stores/2017-18

GENERAL TERMS AND CONDITIONS
Sub: Tender for disposal of obsolete office equipments

1.

Parties: The parties to the contract are the vendor (The tenderer to whom the order has been issued) and

the Government of India through the O/o Controller of Accounts, Ministry of Earth Sciences for and on behalf of
the President of India.

2.

Addresses: For all purposes of the contract including arbitration there under, the address of the tenderer

mentioned in the tender shall be final unless the tenderer notifies the change of address by a separate letter sent by
registered post with acknowledgement due to the undersigned. The tenderer shall be solely responsible for the
consequences of any omission or error to notify change of address in the aforesaid manner.

3.

Tender Availability & Earnest Money Deposit:

a) The tender form along with terms and conditions can be downloaded from the website https://eprocure.gov.in
or http://moes.gov.in/. No printed copies will be provided.
b)

Earnest Money Deposit of Rs 5,000/- (Rupees Five Thousand) only must be deposited by the tenderers

through an Account Payee Demand Draft/Banker’s Cheque in favour of PAO (Sectt), MoES, New Delhi.

c)

EMD is to remain valid for a period of forty-five (45) days beyond the final bid validity period.

d)

EMD of the unsuccessful bidders will be returned to them at the earliest after expiry of the final

bid validity and latest on or before the 30
e)

th

day after the award of the contract.

Tenderer shall not be permitted to withdraw his/her offer or modify the terms and conditions thereof. In

case the tenderer fails to observe and comply with the stipulations made herein or backs out after quoting the
rates, the aforesaid amount of earnest money will be forfeited to the Government.
f)

The tenders without the Earnest Money Deposit will be summarily rejected.

g)

No claim shall lie against the Government Department in respect of erosion in the value or interest on

the amount of Earnest Money Deposit.
Page 2 of 13

<!-- page 3 -->

4.

Inspection of Items by Interested Parties:
All interested tenderers, after having obtained the bid documents, may visit the address mentioned in

Section 8 (Page 5), with prior appointment only, on the following mentioned dates and time:
a) 8th and 9th March 2018: 11 AM to 01 PM
b) 16th March 2018: 11 AM to 01 PM
5.

Preparation of Tender Documents: SINGLE - BID SYSTEM:

a)

Tender documents

in the following manner is to be prepared and the Tender should contain the

documents as under:
(i) Terms and Conditions Checklist (Annexure I) with all documents.
(ii) Price bid in the format (Annexure II).
b)
Tenderers are required to quote for the whole lot in each of the Groups (summarized below) in the
prescribed Tender forms (Annexure-II) and enclose the duly filled in and signed form in a sealed cover.
c)

Groupings made in the tender for offering the price for the items:
(i) G1 – e-Waste
(ii) G2 – Computers and Peripherals
(iii) G3 – Furniture
(iv) G4 – Scrap and Other Office Equipments

d)

Tenderer may bid for all the groups mentioned above or selectively.

e)

The price quoted (tender) shall remain valid for a period of 90 days from the date of tender opening.

f)
Selection of highest bidder will be made based on total price offered for each of the Groups
individually/separately.
g)
Tender should be superscribed on the top of the sealed envelopes as `Tender for Disposal of Obsolete
Office Equipments’.
h)

The envelope containing the tenders shall be properly sealed. Envelopes stapled shall not be accepted. All

the envelopes must be sealed and the Tender No. and Due date of opening must be superscribed thereupon. Name
and address of the tenderer must also be indicated on each envelope. In case of non-submission of the bids as
above, the tender shall be treated as ‘Disqualified’.

Page 3 of 13

<!-- page 4 -->

6. Signing of Tender:
Individual signing the tender or other documents connected with contract must specify whether he/she signs as:
(a)

A sole proprietor’ of the concern or constituted attorney of such sole proprietor.

(b)

A partner of the firm, if it be a partnership firm, in which case he must have the authority to execute

contracts on behalf of the firm and to refer to arbitration disputes concerning the business of the partnership either
by virtue of the partnership agreement of by a power of attorney duly executed by the partners of the firm.

(c)
Director or a principal officer duly authorized by the Board or Directors of the Company, if it is a
company.

7. N.B:
(a)

In case of partnership firm, a copy of partnership agreement or general power of attorney duly attested

by a Notary Public, should be furnished on a stamp paper duly sworn or affirmed by all the partners admitting
execution of the partnership agreement or general power of attorney. The attested copy of the certificate of
registration of firm should also be enclosed along with the tender
(b)

In case of partnership firm, where no authority to refer disputes concerning the business of partnership

has been conferred on any partner, the tender and all other related documents must be signed by all partners of the
firm.
(c)

A person signing the tender form or any documents forming part of the tender on behalf of another person

should have an authority to bind such other person and if on enquiry it appears that the persons so signing had no
authority to do so, the competent authority may without any prejudice, cancel the contract and hold the signatory
liable for all costs, consequences and damages under the civil and criminal remedies available.

(d)

The tenderer should sign and affix his/her firm’s stamp at each page of the tender and

all its annexure as acceptance of the offer made by the tenderer will be deemed as contract and no separate formal
contract will be drawn. NO PAGE SHOULD BE REMOVED/ DETATCHED FROM THIS NOTICE
INVITING TENDER. The duly signed NIT should be attached to other tender documents without fail.
Tenders received without duly signed/stamped tender form will be rejected.

Page 4 of 13

<!-- page 5 -->

8. Submission of Tender documents: Tenders should be addressed to :
Senior Accounts Officer (Administration),
O/o Controller of Accounts,
A-20, Mausam Bhawan, Lodhi Road
New Delhi – 110003
a)
The tenders may be deposited in person by the tenderer in the Tender Box kept in the office of address
given above during working hours.
OR
b)

The tenders can be sent by Registered post or Speed post so as to reach the undersigned on or before the

scheduled date and time. This office is not responsible for any kind of delay for receipt of tender within the
specified date and time and the tenders received after the scheduled date and time will be out rightly rejected.
Only one tender should be kept in one cover. The tender is not transferable.

9.

Opening of Tender:
The tenderer is at liberty either himself or to authorize a representative (not more than one) to be present
at the time of opening of the tender. The representative attending the opening of the tender on behalf of the
tenderer should bring with him a letter of authority from the tenderer and a proof of identification on the date and
time indicated in the “Schedule of Tender”. The Tender will be opened and read out in the presence of tenderer’s
representatives. If the tenders could not be opened at the given time and date due to unforeseen circumstances, the
tenders will be opened on next working day at the same time/ venue.

10. Criterion for Evaluation of Tenders:
The evaluation of the tenders will be made on the basis of technical information and commercial
information furnished in form given in Annexure-II. It must be kept in view that no decision will be given by the
Tender Evaluation Committee and any inferences drawn during the meeting of this committee by the tenderers or
their representatives will be their own view and the Department will not be responsible and abide by the same.
The reasons for selection or rejection of a particular tender will not be disclosed..

11. Right to decide the tender:
The Controller of Accounts, Ministry of Earth Sciences reserves all rights to reject any tender including
those tenderers who fail to comply with the instructions without assigning any reasons, whatsoever and does not
bind itself to accept any specific tender. The decision of the CA, MoES in this
Page 5 of 13

<!-- page 6 -->

regard is final and binding. Any failure on the part of the tenderer to observe the prescribed procedure and any
attempt to canvas will prejudice the Tenderer’s quotation. Any attempt on the part of the tenderer to influence in
any way for acceptance of his tender will render for rejection. The decision of the CA, MoES shall be final on any
matter of dispute arising out of this tender.

12. Communication of Acceptance:
The successful tenderer will be informed of the acceptance of his tender by post and e-mail.

13. Scope of work:
Disposal of obsolete office equipments is to be made from office of the Controller of Accounts, Ministry
of Earth Sciences, Mausam Bhawan, New Delhi - 110003.

14. Time Schedule:
a) Completion period: The successful tenderer shall be required to make full payment (quoted price in the
tender minus the EMD of Rs. 5,000/-) by an Account Payee Cheque in favour of PAO (Sectt), MoES, New
Delhi within 5 working days of the acceptance of the tender.
b) The tenderer shall lift all the items from the disposal site to his premises within 5 working days after
making the payment as above.
c) On failure to do so, tender inviting authority shall have the right to forfeit the entire amount of the bidder
including the EMD and dispose the items to the alternate bidder.
d) The vendor has to submit the details of all the items collected from this office after the completion of the work or
7 days whichever is earlier. This office will not bear any transportation or handling charges for this.

e) The successful tenderer shall take the responsibility to set right any damages caused during lifting of the
materials, to the satisfaction of the concerned authority. On failure to do so, the CA, MoES shall have the right to
forfeit the entire amount of the tenderer and dispose the items to alternate tenderer.
f) During the currency of the tender, additional condemned hardware if any should be lifted by the successful
tenderer at the rates quoted or higher rates that may be applicable at the time of lifting, as the case may be.

g) The condemned hardware being disposed off is only for recycling or reuse. The use of the lifted items in any other
form will lead to appropriate legal action. The hard drives in the CPUs should be drilled into or crushed beyond
usage before lifting. The successful tenderer will be responsible to ensure this action.
Page 6 of 13

<!-- page 7 -->

15. Arbitration:
If any difference arises concerning, this Agreement, its interpretation on the payment to be made there under,
the same shall be settled by mutual consultations and negotiations. If attempts for conciliation do not yield any
results within a period of 90 days, either of the parties may make a request to the other party for submission of the
dispute for decision by an arbitral tribunal containing a sole Arbitrator to be appointed by the Controller of
Accounts, Ministry of Earth Sciences. Such request shall be accompanied with a panel of names of three persons
to act as a sole arbitrator. In case of such arbitrator refusing, unwilling or becoming incapable to act or his
mandate having been terminated under law, another arbitrator shall be appointed in the same manner from among
the panel of three persons to be submitted by the claimant. The arbitration proceedings shall take place at New
Delhi and shall be conducted in English. The provisions of Arbitration and Conciliation Act, 1996 and the rules
frames there under and in force shall be applicable to such proceedings.

For any clarification, please contact at following nos.:
(A) Shri. Madhukar Gupta, Sr. AO, O/o the CA, MoES, A-20, Mausam Bhawan, Lodhi Road, New Delhi - 110003
[011-2464 2151].
(B) Shri. Harish Kumar, AAO, O/o the CA, MoES, A-20, Mausam Bhawan, Lodhi Road, New Delhi - 110003 [0112464 2152].

Page 7 of 13

<!-- page 8 -->

ANNEXURE – I
TERMS AND CONDITIONS CHECK LIST
(to be submitted along with the Bid)
Sl. No

Terms and conditions

1.

Name of the Tenderer / concern and address

2.

Contact Number (s)

3.

Remarks

e-mail Address

4.

Whether each page of NIT and its Annexures
have been stamped and signed

5.

Earnest Money Deposit Details
Banker’s Cheque / Demand Draft
Number

6.
7.
8.
9.

Nature of the Concern
Sole / Partnership / Company
Documents attached in respect of nature of
the concern
Details of any other information (i.e copies of
the Trade licence, PAN, VAT Regd etc).
Whether the tenderer agrees to the general
terms and conditions mentioned in the NIT

UNDERTAKING
1. I/We undertake that I/we have carefully studied all the terms and conditions and understood the parameters of the
proposed work of the Department of Posts and shall abide by them.
2. I /We further undertake that the information given in this tender is true and correct in all respect and we hold the
responsibility for the same.

Date:

Signature of the tenderer.
Page 8 of 13

<!-- page 9 -->

ANNEXURE – II

PRICE BID
Tender for disposal of e-waste material
Name and Address of the Tenderer:
Telephone No.:
I/we have inspected the obsolete/ used items related to the computer hardware, peripherals,
furniture and e-waste items, and am/are interested to purchase the same on “AS IS WHERE IS” basis. My
/Our offer for the items is given below:

Obsolete Items Group G1
e-Waste
Sr. Particulars of store
No.

Quantity/weight/Size (Approx.)

1.

One (1)
IGBT/BY PASS UPS SERVER.
Two(2) Spilt
Two(2) Window

2.
3.

Used Uniline
voltage stabilizer
Used Burnt LG air
conditioner
(1.5 ton)
Used Voltage
stabilizer

4.

Used UPS

5.

Used Smart power
UPS

6.

Used Blue star
Water Dispenser

Two(2)
1. Electrom
2. Everom (SPC)
Two(2)
Pulstech
Two(2)
1.Prao/MoES/Admn/UPS/13
2. No identification number
available.
Mini magic

Year of
purchase

Offer Price

2008-09
22.07.2009
11.11.2008
31.03.2009
2011-12
2011-12
30.09.2009
18.12.2009
TOTAL
(Rupees)

Our total offer for all items in G1 is Rs.……………..…………... (Rupees . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
)
.........................................
.......................

Note: The number of items mentioned above may vary.
Page 9 of 13

Signature of tenderer

<!-- page 10 -->

Obsolete Items Group G2
Computers and Peripherals
Sr.No.

Quantity/weight/Size

Quantity

1.

CPU + Monitor + KeyBoard
HP

8

Working

2.

CPU + Monitor + KeyBoard
HCL

3

Working

3.

CPU + Monitor + KeyBoard
HP

7

Not Working

4

CPU + Monitor + KeyBoard
HCL

3

Not Working

21

11 Working
10 Not Working

Total Desktop Systems

Condition

Offer Price

Rs.

Our total offer for all items in G2 is Rs.……………..…………... (Rupees . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
................................................................ )

Note: The number of items mentioned above may vary.

Page 10 of 13

Signature of tenderer

<!-- page 11 -->

Obsolete Items Group G3
Furniture
Sr. No.
1.

Item

Quantity/weight/Size
(Approx.)

Year of
purchase

Computer Table
(wooden with
iron frame)
Wooden
Table/Trolly.

One(1) 2.5’x4.0’

05.11.2009

Two (2) 3.5’x 2.25’

26.03.2012

3.

Wooden Rack

One (1) 10’x 1.5’

08.10.2008

4.

Iron frame
partition with
glass
Wooden Racks

Two (2) 4’x 4’
Iron Grill

06.03.2009

Three (3)
1. 1.5’x 5.0’
2. 2.0’x 4.5’
3. 2.0’x 5.0’
One (1)
1. 2.5’x 6.0
One (1)
1. 1.25’x 8.0’

08.10.2008

2.

5.

6.
7.

Wooden
Centre table
Wooden Racks

24.08.2009
08.10.2008

8.

Broken
Computer Table

One(1)
1. 2.5’x 4.0

08.10.2008

9.

Wooden Racks

One(1)
1. 2.0’x 2.0’

NA

10.

Computer tables

17.11.2009

11.

Computer Tables

12.
13.

Computer table
(small)
Computer table

Four(4) 2’x4’
Sunmica with iron frame
One (1) 4’x2’
Sunmica with iron frame
One (1) 2’x3’

05.11.2009

14.

Iron Racks

One (1) 2’x5’
Sunmica with iron frame
One (1) 1.5’x3.5’

15.

Office Table

One (1) 1.5’x 5.0’

16.02.2012

16.

Iron Racks

One (1) 1.5’x3.0

06.03.2009

17.

Office table

One (1) 2.’x4.5

NA
Page 11 of 13

10.11.2010
05.11.2009

08.11.2008

Offer Price

<!-- page 12 -->

18.

Small Table

One (1) 1.5’x3.0’

NA

19.

One (1) 2.0’x2.0

NA

20.

Wooden Side
Rack
Big Office Table

One(1) 3.0’x5.0’

17.10.2013

21.

Computer Table

One (1) 2.0’x4.0’

08.10.2008

22.

Small Table

One (1) 1.5’x 3.0’

NA

23.

Side Rack

One (1) 1.25’x 3.0

29.09.2010

24.

Computer Table

One (1) 3.0’x 1.5’

NA

25.

Computer table

One(1) 1.5’x5.0’

NA

26.

Wooden Racks

One(1) 1.5’x 3.0

16.03.1982

27.

Big table

One (1) 4.0’x6.0’

05.02.2009

28.

Wooden Table

One(1) 2.0’x4.0’

16.02.2012

29.

One(1) 1.5’x3.0’

NA

30.

Table Rack with
locks
Computer Table

One(1) 4.0’x2.0’

NA

31.

Table

One(1) 3.0’x1.5’

29.09.2010

32.

Revolving chair

One (1)

22.12.2009

33.

Four (4)

19.03.2012

34.

Executive Chair
leather made
Fixed chair

Two(2)

05.11.2009

35.

Fixed chair (Red)

Four (4)

19.03.2012

36.

Fixed chair
(Yellow)

Four (4)

19.03.2012
TOTAL
(Rupees)

Our total offer for all items in G3 is Rs.……………..…………... (Rupees . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
....
....
....
....
....
....
....
....
....
....
....
....
....
....
....
....

)

Note: The number of items mentioned above may vary.
Page 12 of 13

Signature of tenderer

<!-- page 13 -->

Obsolete Items Group G4
Scrap and Other Office Equipment
Sr.
No.

Particulars of
store

Quantity/weight/Size
(Approx.)

Year of
purchase

Remarks

1.

Used Typewriter

1982-83

Scrap

2.

Server cabinet
(Steel)

Two (2)
1. Godrej
2. Halda
3.
One (1) 1.5’x2.0’

08.02.2011

Used

3.

Digital server
cabinet
(Full size, tall)

One(1)
4.0’x2.0’x10.0’

26.03.2009

Unused

Offer Price

TOTAL
(Rupees)
Our total offer for all items in G4 is Rs.……………..…………... (Rupees . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
)
................................................................

Note: The number of items mentioned above may vary.

Signature of tenderer

I/We have gone through the terms and conditions given in the tender documents and agree with the same.
I/We understand that in the event of non-compliance of the terms and conditions of the tender, my/our EMD shall
be forfeited by the Controller of Accounts, Ministry of Earth Sciences, Prithvi Bhavan, New Delhi – 110003.

Signature of the tenderer with date stamp of the firm.

Page 13 of 13
