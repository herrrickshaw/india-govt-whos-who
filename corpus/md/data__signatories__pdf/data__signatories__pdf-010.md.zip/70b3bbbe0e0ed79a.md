---
doc_id: "70b3bbbe0e0ed79a"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/09/ecac82b18917021f689f41588fd2a301.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Bid Documents for hiring of agency for setting UP, Managing and operating the National Toll Free AIDS Helpline -1097 through GeM Portal"
date: "2026-09-23"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5c132274a05edc24"
---

<!-- page 1 -->

बड सं या/Bid Number : GEM/2026/B/8045180
दनांक /Dated: 16-09-2026

बड द तावेज़ / Bid Document

बड ववरण/Bid Details
बड बंद होने क तार ख/समय /Bid End Date/Time

16-10-2026 18:00:00

बड खुलने क तार ख/समय /Bid Opening
Date/Time

17-10-2026 18:00:00

बड पेशकश वैधता (बंद होने क तार ख से) /Bid Offer
Validity (From End Date)

60 (Days)

मं ालय/रा य का नाम /Ministry/State Name

Ministry Of Health And Family Welfare

वभाग का नाम /Department Name

Department Of Health And Family Welfare

संगठन का नाम /Organisation Name

N/a

कायालय का नाम /Office Name

National Aids Control Organization

िशकायत िनवारण के संपक ववरण/ Contact details of HOD Email id :bharti.sahai@nic.in
Buyer Email id: tanveet.kaur@gov.in
Grievance redressal
Custom Bid for Services - NATIONAL TOLL FREE AIDS
HELPLINE 1097

व तु

ण
े ी /Item Category

समान

ण
े ी/Similar Category

Call Centre Service - Per Connect Minute Basis
Call Centre Service - Per Seat Basis

अनुबंध अविध /Contract Period

2 Year(s) 1 Day(s)

बडर का यूनतम औसत वा षक टनओवर (3 वष का)
/Minimum Average Annual Turnover of the
bidder (For 3 Years)

178 Lakh (s)

उ ह ं/समान सेवा के िलए अपे

त वगत अनुभव के

वष/Years of Past Experience Required for
same/similar service

3 Year (s)

इसी तरह क सेवाओं का पछला आव यक अनुभव है /Past
Experience of Similar Services required

Yes

टनओवर पा ता मानदं ड/Turnover eligibility criteria

To be verified by the buyer at the time of technical
evaluation

एमएसएमई के िलए अनुभव के वष और टनओवर से छूट दान
क गई है /MSE Relaxation for Years of
Experience and Turnover

No

टाटअप के िलए अनुभव के वष और टनओवर से छूट दान
क गई है /Startup Relaxation for Years of
Experience and Turnover

No

1/7

<!-- page 2 -->

बड ववरण/Bid Details
व े ता से मांगे गए द तावेज़/Document required
from seller

या आप िन वदाकार

Experience Criteria,Bidder Turnover
*In case any bidder is seeking exemption from Experience /
Turnover Criteria, the supporting documents to prove his
eligibility for exemption must be uploaded for evaluation by
the buyer

ारा अपलोड कए गए द तावेज़ को

िन वदा म भाग लेने वाले सभी िन वदाकार को दखाना
चाहते ह? संदभ मेनू है/Do you want to show
documents uploaded by bidders to all
bidders participated in bid?
बड लगाने क समय सीमा

Yes (Documents submitted as part of a clarification or
representation during the tender/bid process will also be
displayed to other participated bidders after log in)

वतः नह ं बढ़ाने के िलए

आव यक बड क सं या। / Minimum number of
bids required to disable automatic bid
extension

3

दन क सं या, जनके िलए बड लगाने क समय-सीमा
बढ़ाई जाएगी। / Number of days for which Bid

7

would be auto-extended
ऑटो ए सटशन अिधकतम कतनी बार कया जाना है । /
Number of Auto Extension count
बड से रवस नीलामी स
बड का

1

य कया/Bid to RA enabled No

कार /Type of Bid

तकनीक मू यांकन के दौरान तकनीक

Two Packet Bid
प ीकरण हे तु

अनुमत समय /Time allowed for Technical
Clarifications during technical evaluation

7 Days

अनुमािनत िन वदा मू य (सभी कर स हत) भारतीय पये म
/ Estimated Bid Value in INR (Inclusive of all 89153150
taxes)
मू यांकन प ित/Evaluation Method

Total value wise evaluation

मू य दशाने वाला व ीय द तावेज ेकअप आव यक है /
Financial Document Indicating Price
Breakup Required

Yes

ईएमड

ववरण/EMD Detail

एडवाईजर बक/Advisory Bank

State Bank of India

ईएमड रािश/EMD Amount

891531

ईपीबीजी ववरण /ePBG Detail
एडवाइजर बक/Advisory Bank

State Bank of India

ईपीबीजी

3.00

ितशत (%)/ePBG Percentage(%)

2/7

<!-- page 3 -->

ईपीबीजी क आव यक अविध (माह) /Duration of ePBG
required (Months).

24

(a). जेम क शत के अनुसार ईएमड छूट के इ छुक बडर को संबंिधत केटे गर के िलए बड के साथ वैध समिथत द तावेज़ तुत करने है । एमएसई
केटे गर के अंतगत केवल व तुओं के िलए विनमाता तथा सेवाओं के िलए सेवा दाता ईएमड से छूट के पा ह। यापा रय को इस नीित के दायरे से
बाहर रखा गया है ।/EMD EXEMPTION: The bidder seeking EMD exemption, must submit the valid supporting document
for the relevant category as per GeM GTC with the bid. Under MSE category, only manufacturers for goods and
Service Providers for Services are eligible for exemption from EMD. Traders are excluded from the purview of this
Policy.
(b).ईएमड और संपादन जमानत रािश, जहां यह लागू होती है , लाभाथ के प
in favour of Beneficiary, wherever it is applicable.
(c).ईएमड और संपादन जमानत रािश लाभाथ के प
the buyer in the form of a surety bond.

म होनी चा हए। / EMD & Performance security should be

म होनी चा हए। / Earnest Money Deposit (EMD) shall also be accepted by

लाभाथ /Beneficiary :
Pay and Accounts Officer Sectt.
Department of Health and Family Welfare, Ministry of Health and Family Welfare, Kartavya Bhawan, New Delhi110001
(Pay And Accounts Office Sectt.)

UIN Number NCTGC2415P
बोली वभाजन लागू नह ं कया गया/Bid splitting not applied.
एमआईआई अनुपालन/MII Compliance
एमआईआई अनुपालन/MII Compliance

Yes

1. The minimum average annual financial turnover of the bidder during the last three years, ending on 31st
March of the previous financial year, should be as indicated above in the bid document. Documentary evidence in
the form of certified Audited Balance Sheets of relevant periods or a certificate from the Chartered Accountant /
Cost Accountant indicating the turnover details for the relevant period shall be uploaded with the bid. In case the
date of constitution / incorporation of the bidder is less than 3-year-old, the average turnover in respect of the
completed financial years after the date of constitution shall be taken into account for this criteria.
2. Years of Past Experience required: The bidder must have experience for number of years as indicated above in
bid document (ending month of March prior to the bid opening) of providing similar type of services to any
Central / State Govt Organization / PSU. Copies of relevant contracts / orders to be uploaded along with bid in
support of having provided services during each of the Financial year.
3. Estimated Bid Value indicated above is being declared solely for the purpose of guidance on EMD amount and
for determining the Eligibility Criteria related to Turn Over, Past Performance and Project / Past Experience etc.
This has no relevance or bearing on the price to be quoted by the bidders and is also not going to have any
impact on bid participation. Also this is not going to be used as a criteria in determining reasonableness of
quoted prices which would be determined by the buyer based on its own assessment of reasonableness and
based on competitive prices received in Bid / RA process.
4. Past Experience of Similar Services: The bidder must have successfully executed/completed similar Services
over the last three years i.e. the current financial year and the last three financial years(ending month of March
prior to the bid opening): 1. Three similar completed services costing not less than the amount equal to 40% (forty percent) of the
estimated cost; or
2. Two similar completed services costing not less than the amount equal to 50% (fifty percent) of the estimated
cost; or
3. One similar completed service costing not less than the amount equal to 80% (eighty percent) of the estimated
cost.

3/7

<!-- page 4 -->

('sd f 3TTd)g fu(, dre 6t rrqqrro.u /Exce! Uproad Required :
Financial Proposal - L7g95590_35,xlsx

3{frtrfr strq-dr ./3nE?{dF- ta/a O A t i o n a I e u a I i f i c at i o n D a ta R
I

/

e q u i re d

!ntroduction about the project /services being proposed for procurement
using custom bid
functionatity: 178955904 7 pdf
lnstruction To Bidder:1 7.8.955 9Q54. pdf
Pre Qualification criteria ( pec ) etc if any required:r.7g9559Q61.odf
Scope of Work:1 7895590F8. odf

Payment Terms: 179955907 7. pdf
Penalties :17 95590

.

pdf

Quantifiable Specification / Standards of The Service/ BOeX789559095.pdf
Project Experience and euarifying criteria Requirement: 17g9559101.pdf
Educational Qualification including profile of SME/Consultants
/professional Resources /Technica!
Resources if they are part of project .:17g9559110.pdf
GEM Availabitity Report ( GAR) r178955 116.pdf

Any other Documents As per specific Requirement of Buyer -r:I7g9559122.pdf

Undertaking of comoetent Authority is mandatory to create
custom Bid for services. please
download standard format document and upload:lllgjjp!]ajdI

This Bid is based on euatity & Cost Based Selection (eCBS) . The parameter
wise quatification
requirement is as under:Parameter Name
Minimum Turnover, Agency
Experience, Profile of Team,
I nfornration Technology
Systcms, Training Capacity arrd
Knowledge Management,

Max Marks

Cutoff Marks

Qualification Methodology
Document

100

70

View File

Understanding of project
Req uirements and Certifications
and Presence

Buyer Defined rota! eualifying Marks for Technicat eualification: 70
QCBS Weightage(Technica!:Financiat):]0+7€ Ma^r 5e t(Ad
()

6Ia JO: Jo

lnterview venue:National AIDS control organization, 9th Floor, Chandralok Building,
110001

Presentation venue:National AIDS Control organization, 9th Floor, chandralok

Delhi-110001

36, Janpath, New Delhi-

Buildrng, 36, Janpath, New

Designation of CA : Additional secretary and MD, National AIDS Control organization
Office of CA ; Department of l-iealth and Family welfare, Minisrry of Healt.lr and Farnily

Welfare

CA approval document link : View file

417

<!-- page 5 -->

Pre Bid Detail(s)
मू य िभ नता खंड द तावेज़/Pre-Bid
Date and Time

ी- बड थान/Pre-Bid Venue

28-09-2026 11:00:00

National AIDS Control Organization, 9th Floor, Chandralok Building, 36,
Janpath, New Delhi-110001

Custom Bid For Services - NATIONAL TOLL FREE AIDS HELPLINE 1097 ( 1 )
तकनीक

विश याँ /Technical Specifications
ववरण/ Specification

मू य/ Values

कोर / Core
Description /Nomenclature of Service Proposed for procurement using
custom bid functionality

NATIONAL TOLL FREE AIDS
HELPLINE 1097

Regulatory/ Statutory Compliance of Service

YES

Compliance of Service to SOW, STC, SLA etc

YES

एडऑन /Addon(s)

अित र

विश

द तावेज़ /Additional Specification Documents

परे षती/ रपो टग अिधकार /Consignees/Reporting Officer and Quantity

.सं. /S.N
o.

1

परे षती/ रपो टग
अिधकार /Consignee
Reporting/Officer

Tanzin Dikid

े ता

ारा जोड़ गई बड क

पता/Address

110001,6 & 9th Floor,
Chandralok Building, 36,
Janpath, New Delhi

अित र आव यकता
/Additional
Requirement

Quantity

Project /
Lumpsum
Based

N/A

वशेष शत /Buyer Added Bid Specific Terms and Conditions

1. Past Project Experience
Proof for Past Experience and Project Experience clause: For fulfilling the experience criteria any
one of the following documents may be considered as valid proof for meeting the experience criteria:a.
Contract copy along with Invoice(s) with self-certification by the bidder that service/supplies against the
invoices have been executed.b. Execution certificate by client with contract value.c. Any other document
in support of contract execution like Third Party Inspection release note, etc.Proof for Past Experience and
Project Experience clause: For fulfilling the experience criteria any one of the following documents may be
considered as valid proof for meeting the experience criteria:a. Contract copy along with Invoice(s) with
self-certification by the bidder that service/supplies against the invoices have been executed.b. Execution
certificate by client with contract value.c. Any other document in support of contract execution like Third
Party Inspection release note, etc.

5/7

<!-- page 6 -->

अ वीकरण/Disclaimer
The Additional Terms and Conditions (ATC) have been incorporated by the Buyer after approval of their
Competent Authority. The Buyer ,is solely responsible for the impact of these clauses on the bidding process, its
outcome, and consequences thereof including any restriction arising in the bidding process due to these ATCs
and including the modification of technical specifications and / or terms and conditions governing the bid.All
representations / grievances pertaining to the ATC clauses shall be raised with the buyer organization directly
and not with GeM.If any of the clause(s) is/are incorporated by the Buyer regarding the following, the bid &
resultant contract shall be treated as null & void. Further, GeM reserves the right, at its sole discretion, to cancel
the bid forthwith, without issuance of any prior notice or intimation :1. Publishing Custom / BOQ bids for items for which regular GeM categories are available (unless such
Custom / BOQ item is bunched with the major regular product Category Item).
2. Mandating procurement of / from specific Brand / Make / Model / Manufacturer / Dealer except in case of
Single Bid / Proprietary Article Certificate (PAC) Buying.
3. Inclusion of disqualification criteria related to suspension of seller / service provider, where such
suspension period has already expired.
4. Mandating submission of documents (other than EMD and signed Integrity Pact - which can be submitted
within 5 days of bid opening) in physical form as a pre-requisite to qualify bidders.
5. Publishing bids on GeM for procurement of works.
6. Procurement of Goods by creating a Service bid on GeM & vice-versa.
7. Seeking sample with bid or approval of samples during bid evaluation process. However, trial / sample, as
the case may be, shall be permitted in cases where trial / sample are allowed as per approved and
published procurement policy of the Buyers’ controlling Ministry / Department / State / Public Sector
Enterprises Headquarters. If there is any violation of trial / sample clause with regard to approved policy
of the Buyers’ Ministry / Department / State / Public Sector Enterprises Headquarters, then this is to be
determined and redressed by the concerned Buyer Organisation only.
8. Seeking experience from specific organization / department / institute only or from foreign / export
experience.
9. Creating bid for items from incorrect categories.
10. Reference of conditions published on any external site or reference to external documents/clauses.
11. Asking for any Tender fee / Bid Participation fee, as the case may be.
12. Buyer added ATC Clauses which are in contravention of clauses defined in bid detail section, including
specifications, EMD Detail, ePBG Detail and MII and MSE Purchase Preference sections of the bid, unless
otherwise allowed by the applicable GeM GTC.
13. Any ATC clause in contravention with GeM GTC Clause 4 (xiii) (h) will be invalid. In case of multiple L1
bidders against a service bid, the buyer shall place the Contract by selection of a bidder amongst the L-1
bidders through a Random Algorithm executed by GeM system.
14. In a category based bid, adding additional items, through buyer added, additional scope of work/
additional terms and conditions/or any other document. If buyer needs more items along with the main
item, the same must be added through bunching category based items or by bunching custom catalogues
or bunching a BoQ with the main category based item, the same must not be done through ATC or Scope
of Work.
Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of
this bid, they can raise their representation against the same by using the Representation window provided in
the bid details field in Seller dashboard after logging in as a seller. Buyer is duty bound to reply to all such
representations and would not be allowed to open bids if he fails to reply to such representations.

All GeM Sellers/Service Providers shall ensure full compliance with all applicable labour laws,
including the provisions, rules, schemes and guidelines under the four Labour Codes i.e. the Code
on Wages, 2019; the Industrial Relations Code, 2020; the Occupational Safety, Health and Working
Conditions Code, 2020; and the Code on Social Security, 2020 as and when notified and brought into
force by the Government of India.
For all provisions of the Labour Codes that are pending operationalisation through rules, schemes or
notifications, the corresponding provisions of the pre-existing labour enactments (such as The
Minimum Wages Act, 1948, The Payment of Wages Act, 1936, The Payment of Bonus Act, 1965, The
Equal Remuneration Act, 1976, The Payment of Gratuity Act, 1972, etc. and relevant State Rules)

6/7

<!-- page 7 -->

shall continue to remain applicable.
The Seller/ Service Providers shall, therefore, be responsible for ensuring compliance under:
All notified and enforceable provisions of the new Labour Codes as mentioned hereinabove;
and
All operative provisions of the erstwhile Labour Laws until their complete substitution.
All obligations relating to wages, social security, safety, working conditions, industrial relations etc.
and any other statutory requirements shall be strictly met by the Seller/ Service Provider. Any noncompliance shall constitute a breach of the contract and shall entitle the Buyer to take appropriate
action in accordance with the contract and applicable law.
This Bid is governed by the General Terms and Conditions, conditions stipulated in Bid and Service
Level Agreement specific to the Service, as the case may be, as provided in the Marketplace.
However, in case of Service, if any condition specified in General Terms and Conditions is
contradicted by the conditions stipulated in Service Level Agreement specific to said Service, then it
will over-ride the conditions in the General Terms and Conditions.
This Bid is governed by the सामा य िनयम और शत/General Terms and Conditions, conditions stipulated in Bid and
Service Level Agreement specific to this Service as provided in the Marketplace. However in case if any condition
specified in सामा य िनयम और शत/General Terms and Conditions is contradicted by the conditions stipulated in
Service Level Agreement, then it will over ride the conditions in the General Terms and Conditions.
जेम क सामा य शत के खंड 26 के संदभ म भारत के साथ भूिम सीमा साझा करने वाले दे श के बडर से खर द पर
भारत के साथ भूिम सीमा साझा करने वाले दे श का कोई भी बडर इस िन वदा म बड दे ने के िलए तभी पा
स म

ितबंध के संबंध म

होगा जब वह बड दे ने वाला

ािधकार के पास पंजीकृ त हो। बड म भाग लेते समय बडर को इसका अनुपालन करना होगा और कोई भी गलत घोषणा कए जाने

व इसका अनुपालन न करने पर अनुबंध को त काल समा

करने और कानून के अनुसार आगे क कानूनी कारवाई का आधार होगा।/In terms

of GeM GTC clause 26 regarding Restrictions on procurement from a bidder of a country which shares a land border with India, any bidder from a country which shares a
land border with India will be eligible to bid in this tender only if the bidder is registered with the Competent Authority. While participating in bid, Bidder has to undertake
compliance of this and any false declaration and non-compliance of this would be a ground for immediate termination of the contract and further legal action in
accordance with the laws.

--- ध यवाद/Thank You---

7/7
