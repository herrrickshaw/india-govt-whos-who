---
doc_id: "721fcbbf108efa5b"
source_url: "https://dohe-education.gov.in/static/uploads/2026/02/8e99edb490740e8cabcc82c01c611951.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "General Policy on Establishment of New Central University and Conversion of State University into Central University New Image"
date: "2025-12-31"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "621554c0ac614a2a"
---

<!-- page 1 -->

GENERAL POLICY ON ESTABLISHMENT OF NEW CENTRAL UNIVERSITY
AND CONVERSION OF STATE UNIVERSITY INTO CENTRAL UNIVERSITY
With a view to increasing access and improving the quality of higher education in the
country, the 11th Five Year Plan as approved by the National Development Council
(NDC) envisaged setting up of one Central University each in States which did not have
any Central University till then. Accordingly, 16 Central Universities were established by
the Central Universities Act, 2009 in different un- served States.
In the 12th Five Year Plan, as approved by NDC, the focus is on scaling up of capacity
in existing institutions rather than increasing the number of institutions, with
exception of new institutions needed to address critical regional and social gaps. The
Central Government has launched a new centrally sponsored Scheme, Rashtriya
Uchchtar Siksha Abhiyan (RUSA) which would seek to incentivize the State
Governments to improve higher education by creating additional capacity in existing
institution and set up new institutions in un-served and underserved areas. Under this
scheme, the State Government would have the flexibility to set up new Universities and
Colleges keeping in mind the local requirements.
As regards conversion of the State University into Central University, this Ministry
has taken a policy decision not to convert State Universities into Central Universities for
reasons of legacy issues, adjustment of existing staff and disaffiliation of affiliated
colleges.
**
