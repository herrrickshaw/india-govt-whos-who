---
doc_id: "6dc6fb3edc7d3ce1"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/e551a544a23a00387198ad93809cbda4.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction order dated 22-07-2021 to Invest India"
date: "2025-07-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e242df79103c8eb3"
---

<!-- page 1 -->

No. P-36017/97/2020-Investment Promotion
Government of India
Ministry of Commerce and Industry
Department for Promotion of Industry and Internal Trade
Investment Promotion Section
Udyog Bhawan, New Delhi-11
Datcd~~ftr1July, 2021
To,
The Accounts Officer,
Pay & Accounts Office,
Department of Industrial Policy & Promotion,
Udyog Bhawan, New Delhi - 110011.
Sub:

Release of funds (as advance) to Invest India for the activities of projects being
implemented for the year 2021-22.

Sir,
I am directed to convey the sanction of the President to release the amount of
Rs. 41,96,00,000/- (Forly One Crore Ninety Six Thousand Rupees Only) in favour of Invest
India, First Floor, Vigyan Bhawan Annexe, Maulana Azad Road, New Delhi-110011, as
advance against the activities of projects being implemented by Invest India for FY 2021-22.
2.

The approval is subject to the following conditions:-

i.
ii.
iii.

iv.

v.

vi.

vii.
viii.

The advance shall be utilized by Invest fndia only for the purpose for which the same
is sanctioned. The execution of the activities for whJch the amount is sanctioned shall
not be entrusted to another institution or organization.
lnvest India shall submit the Utilization Certificate in the prescribed form duly signed
by the Head ofthc [nstilution/Organization in compliance to the provision ofGFR.
Detailed account of each expenditure incurred against the advance shall be kept
together with the documei1ts/vouchers etc. as evidence of actual expenditure and shall
be furnished to the DPHT alongwith the original pre~receipted invoices in triplicate.
lnvest India shall maintain a register of permanent and semi-permanent assets
acquired wholly or mainly out of the above funds/sanction in the prescribed format
and copy thereof should be furnished to this Ministry.
Assets acquired wholly or substantially out of the Government Grants shall not be
disposed off without obtaining the prior approval of the sanctioning Authority of the
Grants.
Invest India shall adhere to all the relevant provisions of GFR and any other
instruction/guidelines issued by the Government from time to time, while making
procurement/ purchases of goods and services including compliance to the provisions
of GFR in case of outsourcing of services and engagement of consultants.
Any unspent amount with interest @ I 0% from the date of release of funds shall be
surrendered to the Government.
Any misuse of the advance paid shall be liable to enforcement of suitable penalty viz.
blacklisting of the agency or any other action found appropriate by the DPIIT.

3.
The amount of Rs. 41,96,00,000/- (Fo1ty One Crom Ninety Six Thousand Rupees
Only) will be released as advance in favour of Invest India to their A/c No. 0359050 I 24195,
Punjab National Bank, Tansen Marg, Tansen Marg Branch, New Delhi - 11000 I, IFSC Code
- PUNB0035920.
1 of2

li

H

<!-- page 2 -->

4.
The expenditure is debitable to Demand No. 11 of the Department for Promotion of
Industry and Internal Trade for financial year 2021-22 under the following head.
2852

80
800
40.01
40.0l.28

Industry (Major Head)
General (Sub-Major Head)
Other Expenditure (Minor Head)
Scheme of Investment Promotion (Sub-Head)
Professional Services (Object Head)

5.
Shr_i Rohtas Singh, Under Secretary, DPIIT will act as Drawing and Disbursing
Officer for the purpose of this sanction.

6.
This sanction is issued with the concurrence of AS&FA and approved by Secretary,
Department for Promotion of Industry and Internal Trade vide. Diary No. 42161 dated
19/07/2021.

Yours faithfully,

~~ ,
(Bimla Rawat)
Under Secretary to the Govt. ofJndia
Tel. No. 011-23063490

Copy to:
1. Shri Bhaskar Chaturvedi, CFO, Invest India, First Floor, Vigyan Bhawan Annexe,
Maulana Azad Road, New Delhi - 110011.
2. The Chief Controller of Accounts. Pay & Accounts Office, DPIIT. Udyog Bhawan,
New Delhi.
3. Pay and Account Office, DPIIT, Udyog Bhawan.
4. The Principal Director of Audit, Economic & Services Ministry, AGCR Building,
I.P.Estate, New Delhi-110002.
5. l.F. Wing (Finance-II), DPIIT, Udyog Bhawan, New Delhi. With reference to Diary
No. 42161 dated 19/07/2021
6. B~A__.Section DPIIT, Udyog Bhawan, New Delhi.
~ ...-Ca'sn-n Section (two copies oflnvoices/ Bills and Bank details).
U.-~ . Guard File, (Investment Promotion Section).

2 of2
