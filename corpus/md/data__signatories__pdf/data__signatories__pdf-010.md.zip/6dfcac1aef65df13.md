---
doc_id: "6dfcac1aef65df13"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/b7e631781e9a612e7708409ba118e2c4.pdf"
ministry: "Department of Science and Technology (DST)"
title: "2nd Call for DST Science, Technology, and Innovation Policy Postdoctoral Fellowship"
date: "2017-05-30"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e7dff1aac2ac394"
---

<!-- page 1 -->

DST - SCIENCE, TECHNOLOGY, AND
INNOVATION POLICY FELLOWSHIPS
PROGRAMME
(DST-STI-PFP)

GUIDELINES AND PROFORMA
FOR SUBMISSION OF APPLICATIONS

Last date of submission of application for DST-STI
Fellowship: May 30, 2017

Government of India
Ministry of Science & Technology
Department of Science & Technology
Policy Research Cell
Technology Bhawan, New Mehrauli Road
New Delhi-110016
(April 2017)

<!-- page 2 -->

Ministry of Science and Technology
Department of Science and Technology
DST Science, Technology, and Innovation Policy Fellowships
Background and Motivation
Science, Technology, and Innovation (STI) are now recognized as playing a significant
role in advancing human, social, and economic development and meeting the
aspirations of people and nations across the world. As a result, understanding STI
processes and exploring ways to strengthen them is a major strand of intellectual
activity, evinced by the explosion of literature on these topics in the last decade. At
the same time, there are significant efforts to link this understanding to better policy
making by a range of governmental agencies (both in developed and emerging
economies) and inter-governmental organizations.
In recognition of importance and potential of STI in meeting India’s developmental
challenges through “acceleration of the pace of discovery and delivery of science-lead
solutions for faster, sustainable and inclusive growth,” the government launched the
Science, Technology, and Innovation Policy in 2013. Department of Science and
Technology (DST) recognized the importance of evidence-driven research and
analysis in underpinning the effective achievement of the objectives of this policy and
established DST Centers for Policy Research (CPRs) in various academic institutions
across the country (Annexure-I). These centers are engaged in targeted research in
number of key areas relevant to the country, train young scholars in STI policy
research, and contribute towards better STI policy making by providing inputs to
DST.
The role of suitable human resources is key to the success of STI policy research
enterprise, perhaps even more than many traditional areas of research since
intellectual engagement with this area ideally requires both understanding of the STI
domain and processes, as well as policy research skills that draw on various strands
of social sciences. Thus individuals with a background in natural science, medicine
engineering or social science with a background of STI policy research are
particularly suited for such research and, if trained appropriately, can bring a unique
and important perspective to impending issues in this arena.

2

<!-- page 3 -->

Fellowship Proposal
As the country is lagging behind in terms of critical mass and proper structure of
policy research institution(s), on the recommendation of the Committee of Experts,
Policy Research Cell of DST had announced in 2016 a DST-STI Policy Fellowship
Programme at post-doctoral level to generate a critical mass of policy researchers.
At present, there is no systematic formal pathway in the country to support such a
professional transition, although personal experiences of many established STI policy
researchers suggest that there is indeed a cohort of young graduates who have an
interest in making such transition and contribute systematically to STI policy-making
in the country. The fellowship programme was initiated with the broad objective of
(a) enhancing human resources that can engage with and contribute to the STI policy
domain and (b) strengthen the knowledge base, think tank, and evidence based policy
making. The fellowship may provide an opportunity to develop the skills for young
scientists and engineers who are interested in engagement with the STI policy
domain and/or as STI policy researchers. This programme aims to attract and
encourage top-quality researchers to work on the issues pertaining to STI policy and
contribute their knowledge and analytical skills in the policy realm.
It is proposed to call for DST-STI Policy Fellowship- 2017 at POSTDOCTORAL
Level. The Fellowship program would also provide an opportunity for policy-makers
in various government departments /agencies to draw upon STI policy research
expertise from this pool.
DST-STI POSTDOCTORAL FELLOW: The main objective of DST-STI Fellowship is to
build up the cadre of academic STI policy researchers in the country, such that these
Fellows may actively contribute in policy making in academia, research
organizations, or even in government. The candidates who have received a Ph.D. (or
equivalent) in natural science /medicine/engineering/ policy research/social science
(with a background of STI policy research) within the last three years will be eligible
to apply for the fellowship. Applicants must be capable of doing independent research
work and have published at least 3 research papers in peer reviewed journals. At the
time of application, applicant’s age should be below 35 years.
This will be a 2-year fellowship (with a possible extension of one more year,
depending upon performance) where the recipient would be located in a DST-CPR
(by mutual agreement) or in an active policy research group in academic/research
institutions within the country to undertake STI policy research align to the research
program of that CPR or mutually agreed with consent of DST-PRC and policy
researchers/mentors in other than that of CPR. They also will build active linkages to
a relevant government agency (either a scientific ministry or a line ministry with an
S&T component), facilitated by DST itself and/or the DST-CPR. It is hoped that over a
time, as policy makers realize the importance of such Fellows, they will be
forthcoming to support such Fellows and even host them. In addition to undertaking
research and policy engagement, there will be a set of activities – such as a seminar
series or topical workshops – developed by the DST-CPRs (in consultation with DST)

3

<!-- page 4 -->

– that will further add value to the experience gained by Fellows and also build a
community for them.
Eligibility
Science/medicine/engineering/ social science (with a background of STI policy)
academic scholars, STI policy researchers, with good academic record and holding a
Ph.D. degree (within the last three years) are eligible to apply. Applicants must be
capable of doing independent research work and have published at least 3 research
papers in peer reviewed journals. At the time of application, applicant’s age should be
below 35 years.
Application/Proposal
Applicants are required to submit following documents written in English:


Research Proposal

A proposal of maximum 5 pages on empirical research on STI policy issues,
preferably, the issues pertaining to thematic areas of the candidates’ desired DST-CPR
and/or other Policy Research Group in academic/research institutions (proposal
must be formulated though consultation with DST-CPR or active policy research
group). The proposal must include: a) a STI related research title, b) a research
objective, c) STI related Policy research background/ questions, d) research
methodologies, and e) a research plan, including the evidence based outcome.


Curriculum Vitae



Two recommendation letters.

The remuneration and terms and conditions will be guided as per applicable rules, of
DST. The fellowship programme will be run by Policy Research Cell, DST. The duly
constituted Review Committee comprising others scientific departments/ ministries
representatives as well eminent policy makers, academicians will select the fellows,
monitor the progress and make further review of the fellowship programme.
Selection/Support
The duly constituted Review Committee will select candidates based on their
research track record and the relevance, quality, and significance of their proposals.
Once the Review Committee finalizes the selection, the program office (Policy
Research Cell, DST) will notify a review result to selectees via e-mail. The selected
Postdoctoral Fellows will be awarded a fellowship of Rs. 80,000/- (consolidated) in
the level of INSPIRE Faculty. Based on the Committee’s decision, an amount up to Rs.
200,000/- will be granted annually to the Postdoctoral Fellows to cover researchrelated costs and contingency.
Number Postdoctoral Fellowships :8* (tentative and can be increased, decreased at
the discretion of DST)

4

<!-- page 5 -->

How to apply: Candidates are required to submit a copy of application in prescribed
format available at DST website www.dst.gov.in. The envelope should be superscribed
with "DST-STI-PFP Application 2017”. The application should be sent to Dr. Akhilesh
Mishra, Scientist D, Department of Science and Technology, Technology Bhawan,
New Mehrauli Road, New Delhi-110016 by speed post. A soft copy of proposal should
also be mailed at akhilesh.mishra@nic.in.
(Applicants may note that R&D related proposals will not be considered. Proposal
must be on STI policy related issues)
Last Date of Submission: 30th May, 2017.

***********

5

<!-- page 6 -->

ANNEXURE -1

DST- Centre for Science Policy Research
Sr
No

Name & Address of
the Policy Centre

Name & Address of the
Coordinator

Specific focus/ theme Area of Policy Research
Work

Prof. T. A. Abinandanan
Materials Engineering
Indian Institute of Science,
Bangalore-560 012
Email:abinandanan@gmail.com
abinand@materials.iisc.ernet.in,

1. Scientometric Analysis of Indian Institutions

1.

DST- Centre for
Policy Research at
IISc-Bangalore

Prof. Ambuj Sagar
Coordinator, DST- Centre for
Policy Research at IIT-Delhi
Indian Institute of Technology
Hauz Khas, New Delhi-110 016
Email: asagar@hss.iitd.ac.in

1. India’s Innovation Mapping

Prof. S. B. Sareen

1. Understating ecosystem to promote
strengthen S&T Entrepreneurship

DST- Centre for
Policy Research" at
IIT-Delhi
2.

3.

DST- Centre for
Policy Research in
S&T
Entrepreneurship
“Entrepreneurship
Development
Institute of India
(EDII)" Gandhinagar

Entrepreneurship Development
Institute of India (EDII),
P.O. Bhat 382 428,
Gandhinagar, Gujarat
Email: sareen@ediindia.org

2. Research on Funding Patterns and Policies
3. Methods of Assessing Multi-Dimensional
Impact

2. Technology Transfer
3. Sectorial research study
4. Benchmarking study reports
and

2. Scan International Strategy to promote S&T
based Entrepreneurship and integrating
inclusive growth element
3. Prospects and Constraints in Technology
Commercialization by R&D Institutions in
India: The Strategy Imperatives
4. Maintaining data base of high technology
entrepreneurs and preparing and publishing case
studies of such entrepreneurs

4.

5.

DST- Centre for
Policy Research" at
Babasaheb Bhimrao
Ambedkar (Central)
University, Lucknow

DST- Centre for
Policy Research" at
Panjab University,
Chandigarh

Dr. Venkatesh Dutta
Babasaheb Bhimrao Ambedkar
University (A Central University)
Rae Bareily Road, Vidya Vihar,
Lucknow – 226 025 (UP)
Tel. (+091 522) 2440826/27,
2441515, 2551615, Fax:091-5222440821
E-mail:
dvenks@gmail.com,
duttada@yahoo.co.in
Mob:+91-9918466778

1. Study of policies and mechanisms for delivery of
STI outputs to diverse stakeholders including
innovation for social inclusion with special
reference to: Sustainable agriculture; Health;
Energy; Water resource management and
Climate governance.
2. Map STI effectiveness in bringing social
inclusion

1. Study of policies and mechanisms that could
Prof. R Tewari
Coordinator, DST- Centre for
promote to enhance and expand private sector
Policy Research Panjab University,
participation in STI activities including industry
Sector 14, Chandigarh, UT- academia - R&D collaboration
160014
Email: rupinder@pu.ac.in,
2. Motivation and promotion of IP generation as a
dstprc2014@pu.ac.in
tool for enhanced Academia industry
collaborations.

6
