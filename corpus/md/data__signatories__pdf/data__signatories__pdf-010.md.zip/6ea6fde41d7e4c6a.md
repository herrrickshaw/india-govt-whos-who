---
doc_id: "6ea6fde41d7e4c6a"
source_url: "https://www.labour.gov.in/static/uploads/2025/07/57fb075dcc62d5baeb153db71c488c15.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Objections and Suggestions on the amendments to the Payment of Wages Act, 1936"
date: "2016-12-02"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6a88a47cb5846fa1"
---

<!-- page 1 -->

F. No. S-31012/2/2016-WC
Government of India
Ministry of Labour & Employment
Shram Shakti Bhawan, New Delhi
Dated the 02nd December, 2016
Subject: Amendments to the Payment of Wages Act, 1936 – regarding.
The Payment of Wages Act, 1936 regulates the payment of wages of certain classes of
employed persons. Section 6 of the Act envisages that all wages shall be paid in current coin or
currency notes or in both. However, a proviso was inserted in section 6 of the said Act in the
year 1975 enabling the employer, after obtaining the written authorization of the employed
person, to pay him the wages either by cheque or by crediting the wages in his bank account.
2.
One of the reasons for ineffective enforcement of payments of wages to workers is the
payment of wages in cash. With the passage of time, technology has gone a sea change. A large
section of the employed persons have now bank accounts. So, payment of wages only through
cheque or through bank transfer in the bank account of employed persons will reduce the
complaints regarding non-payment or less payment of minimum wages, besides serving the
objectives of digital and less cash economy.
3.
In the recent years advancements in technology, progress in mobile banking and
innovative technologies to facilitate digital payments have enabled large number of small
denomination transactions to be handled smoothly in electronic mode. The Government of India
has taken policy decisions encouraging cashless/electronic transactions.
4.
The Central Government, therefore, intends to make amendments in section 6 of the
Payment of Wage Act, 1936. The details of the existing provisions and proposed amendments
are as under:
Sl.
Section
No.
1
Section 6

Existing Provision

Proposed Provision

“6. Wages to be paid in
current coin or currency
notes.- All wages shall be paid
in current coin or currency
notes or in both:

“6. Wages to be paid in current coin or
currency notes.- All wages shall be paid
in current coin or currency notes or in both:

Provided that the employer
may, after obtaining the
written authorization of the
employed person, pay him the
wages either by cheque or by
crediting the wages in his
bank account.”

Provided
that
the
appropriate
Government may, by notification in the
Official Gazette, specify the industrial or
other establishment, the employer of
which shall pay to every person
employed in such industrial or other
establishment, the wages either by
cheque or by crediting the wages in his
bank account.”

Page 1 of 2

<!-- page 2 -->

5.
It is, therefore, published in public domain, as part of Pre-Legislative Consultation
Policy, for the information of all persons likely to be affected thereby and notice is hereby given
that the said proposal shall be taken into consideration after 16/12/2016.
6.
Any objections or suggestions, which may be received from any person or organisation
with respect to the said proposal within the time frame stipulated above, shall be considered by
the Central Government.
7.
The objections and suggestions shall be addressed to the Secretary, Ministry of Labour
and Employment, Shram Shakti Bhawan, Rafi Marg, New Delhi-110001.
******

Page 2 of 2
