---
doc_id: "72baf441c5e1dccf"
source_url: "https://powermin.gov.in/static/uploads/2025/06/8894a98ae19dcb20484850de89a4e5a2.pdf"
ministry: "Power"
title: "Amendment to MoP Notification No GSR 780(E) regarding Recruitment Rules for the post of Deputy Director General (Technical) and Deputy Director General (Finance) in BEE"
date: "2023-12-04"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a0da173dd175f484"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-05122023-250417
xxxGIDHxxx
CG-DL-E-05122023-250417
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 690]

नई दिल्ली, सोमिार, दिसम्बर 4, 2023/अग्रहायण 13, 1945
NEW DELHI, MONDAY, DECEMBER 4, 2023/AGRAHAYANA 13, 1945

No. 690]

जिद्युत मंत्रालय
अजधसूचना
नई दिल्ली, 1 दिसम्बर, 2023
सा.का.जन. 873(अ).—कें द्रीय सरकार, ऊिाा संरक्षण अजधजनयम, 2001 (2001 का 52) की धारा 56 द्वारा प्रित्त
िजियों का प्रयोग करते हुए, ऊिाा िक्षता ब्यूरो के उप महाजनिेिक (एनएमईईई) की जनयुजि और सेिा संबंधी िते और
जनबंधन जनयमािली 2012 में संिोधन के जलए जनम्नजलजखत जनयम बनाती है, अर्ाात् :1. संजक्षप्त नाम और प्रारं भ.- (i) इन जनयमों का संजक्षप्त नाम ऊिाा िक्षता ब्यूरो के उप महाजनिेिक (एनएमईईई) जनयुजि
और सेिा संबंधी ितें और जनबंधन संिोधन जनयम, 2023 है।
(ii) ये रािपत्र में इनके प्रकािन की तारीख से प्रिृत्त होंगे।
2. ऊिाा िक्षता ब्यूरो के उप महाजनिेिक (एनएमईईई) की जनयुजि और सेिा संबंधी ितें और जनबंधन जनयम 2012 (जिसे
इसमे इसके पश्चात् उि जनयम कहा गया है) की अनुसूची में, उप महाजनिेिक (तकनीकी) के पि के संबंध में, (क) स्ट्तंभ (4) में, "पीबी4 - रु. 37400-67000 + ग्रेड िेतन रु. 10000" अक्षरों, अंकों और िब्िों के स्ट्र्ान पर
“िेतन मैट्ररक्स में स्ट्तर 14 (144200-218200 रुपए)” िब्ि, अंक और अक्षर रखे िाएंग;े
(ख) स्ट्तंभ (6) में, "ट्रिप्पण" के स्ट्र्ान पर, जनम्नजलजखत "ट्रिप्पण" रखा िाएगा, अर्ाात:् -

7481 GI/2023

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

"ट्रिप्पण - आयु-सीमा जनधााट्ररत करने की जनणाायक तारीख भारत में अभ्यर्र्ायों से आिेिन प्राप्त करने की अंजतम तारीख
होगी, (असम, मेघालय, अरुणाचल प्रिेि, जमिोरम, मजणपुर, नागालैंड, जत्रपुरा, जसदिम, लाहौल और स्ट्पीजत जिला और
जहमाचल प्रिेि के चंबा जिले के पांगी उप-मंडल क्षेत्र, अंडमान और जनकोबार द्वीप समूह, लद्दाख या लक्षद्वीप संघ राज्य क्षेत्र
के अभ्यर्र्ायों के अजतट्ररक्त),''
(ग) स्ट्तंभ (7) में, -(i)

मि (i) में "आिश्यक" और "िांछनीय" िीर्ाकों के अधीन, "या अर्ािास्त्र या अनुप्रयुि अर्ािास्त्र या कारबार
या जित्त या औद्योजगक अर्ािास्त्र या ऊिाा जनयोिन और अर्ािास्त्र" िब्िों का लोप दकया िाएगा;

(ii)

"िांछनीय" िीर्ाक के अधीन, मि (i) में, "या रसायन जिज्ञान" िब्िों के पश्चात्, "या स्ट्नात्कोत्तर जडग्री"
िब्ि रखे िाएंग;े

(घ) स्ट्तंभ (11) में, मि (ii) में, "पीबी4 - रु.37400-67000 + ग्रेड िेतन रु.8700", अक्षरों, अंकों और िब्िों के स्ट्र्ान
पर "िेतन मैट्ररक्स में स्ट्तर 13 (123100-215900 रुपये)" िब्ि, अंक और अक्षर रखे िाएंगे; और
(ड.) स्ट्तंभ (11) में, "छप्पन िर्ा" िब्िों के स्ट्र्ान पर "अट्ठािन िर्ा" िब्ि रखे िाएंगे।
3. उि जनयमों में उप महाजनिेिक (जित्त) में (क) स्ट्तंभ (4) में, "पीबी4 - रु. 37400-67000 + ग्रेड िेतन रु. 10000" अक्षरों, अंकों और िब्िों के स्ट्र्ान पर
“िेतन मैट्ररक्स में स्ट्तर 14 (144200-218200 रुपए)” िब्ि, अंक और अक्षर रखे िाएंग;े
(ख) स्ट्तंभ (6) में, "ट्रिप्पण" के स्ट्र्ान पर, जनम्नजलजखत "ट्रिप्पण" रखा िाएगा, अर्ाात:् "ट्रिप्पण - आयु-सीमा जनधााट्ररत करने की जनणाायक तारीख भारत में अभ्यर्र्ायों से आिेिन प्राप्त करने की अंजतम तारीख
होगी, (असम, मेघालय, अरुणाचल प्रिेि, जमिोरम, मजणपुर, नागालैंड, जत्रपुरा, जसदिम, लाहौल और स्ट्पीजत जिला और
जहमाचल प्रिेि के चंबा जिले के पांगी उप-मंडल क्षेत्र, अंडमान और जनकोबार द्वीप समूह, लद्दाख या लक्षद्वीप संघ राज्य क्षेत्र
के अभ्यर्र्ायों के अजतट्ररक्त),''
(ग) स्ट्तंभ (7) में, (i)

कारबार या जित्त " िब्िों के स्ट्र्ान पर " जित्त जििेर्ज्ञता सजहत कारबार प्रबंधन" िब्ि रखे िाएंगे;

(ii) "या इं िीजनयरी और कारबार में स्नातक जडग्री" िब्िों का लोप दकया िाएगा;
(घ) स्ट्तंभ (11) में, मि (ii) में, "पीबी4 - रु. 37400-67000 + ग्रेड िेतन रु. 8700", अक्षरों, अंकों और िब्िों
के स्ट्र्ान पर "िेतन मैट्ररक्स में स्ट्तर 13 (123100-215900 रुपए)" िब्ि, अंक और अक्षर रखे िाएंगे;
(ड़) स्ट्तंभ (11) में, " छप्पन िर्ा " िब्िों के स्ट्र्ान पर "अट्ठािन िर्ा" िब्ि रखे िाएंगे।
[फा. सं. 13/11/2021-ईसी]
अिय जतिारी, अपर सजचि

ट्रिप्पण :- मूल जनयम भारत के रािपत्र असाधारण भाग II, खंड 3, उप-खंड (i) में सा.का.जन. 780 (अ) तारीख
22 अक्तूबर, 2012 द्वारा प्रकाजित दकए गए र्े।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

MINISTRY OF POWER
NOTIFICATION
New Delhi, the 1st December, 2023
G.S.R. 873(E).— In exercise of the powers conferred by section 56 of the Energy Conservation Act, 2001
(52 of 2001), the Central Government, hereby makes the following rules to amend the Bureau of Energy Efficiency
Appointment and Terms and Conditions of Service of Deputy Director General (NMEEE) Rules, 2012, namely:1. Short title and commencement.- (i) These rules may be called the Bureau of Energy Efficiency Appointment and
Terms and Conditions of Service of Deputy Director General (NMEEE) Amendment Rules, 2023.
(ii) They shall come into force from the date of their publication in the Official Gazette.
2. In the Schedule to the Bureau of Energy Efficiency Appointment and Terms and Conditions of Service of Deputy
Director General (NMEEE) Rules, 2012 (hereinafter referred to as the said rules), in the post relating to the Deputy
Director General (Technical), –
(a) in column (4), for the letters, figures and words “PB4- Rs.37400–67000 + Grade Pay Rs.10000”, the
words, figures and letters “level 14 (Rs.144200–218200) in the pay matrix” shall be substituted;
(b) in column (6), for “Note”, the following “Note”, shall be substituted, namely:“Note : The crucial date for determining the age-limit shall be closing date for receipt of applications from candidates
in India, (other than those in Assam, Meghalaya, Arunachal Pradesh, Mizoram, Manipur, Nagaland, Tripura, Sikkim,
Lahual and Spiti District and Pangi sub-division of Chamba District of Himachal Pradesh, Union Territory of
Andaman and Nicobar Islands, Ladakh or Lakshadweep),”
(c) in column (7), -(i) under the headings “Essential” and “Desirable”, in item (i), the words “or Economics or Applied
Economics or Business or Finance or Industrial Economics or Energy Planning and Economics”
shall be omitted;
(ii) under the heading “Desirable”, in item (i), after the words, “or Chemistry”, the words “or Master
degree in” shall be inserted;
(d) in column (11), in item (ii), for the letters, figures and words “PB4 - Rs.37400–67000 + Grade Pay
Rs. 8700”, the words, figures and letters “level 13 (Rs.123100–215900) in the pay matrix” shall be
substituted; and
(e) in column (11), for the words “fifty-six years” the words “fifty-eight years” shall be substituted.
3. In the said rules, in Deputy Director General (Finance), –
(a) in column (4), for the letters, figures and words “PB4 - Rs. 37400–67000 + Grade Pay Rs.10000”, the
words, figures and letters “level 14 (Rs.144200–218200) in the pay matrix” shall be substituted;
(b) in column (6), for “Note”, the following “Note” shall be substituted, namely:“Note : The crucial date for determining the age-limit shall be closing date for receipt of applications from candidates
in India (other than those in Assam, Meghalaya, Arunachal Pradesh, Mizoram, Manipur, Nagaland, Tripura, Sikkim,
Lahual and Spiti District and Pangi sub-division of Chamba District of Himachal Pradesh, Union Territory of
Andaman and Nicobar Islands, Ladakh or Lakshadweep),”
(c) in column (7),–
(i) for the words “Business or Finance”, the words “ Business Administration with Finance Specialization”
shall be substituted;
(ii) the words “or Bachelor Degree in Engineering and Business” shall be omitted;
(d) in column (11), in item (ii), for the letters, figures and words “PB4- Rs.37400–67000 + Grade Pay Rs. 8700”,
the words, figures and letters “level 13 (Rs.123100–215900) in the pay matrix” shall be substituted;
(e) in column (11), for the words “fifty-six years” the words “fifty-eight years” shall be substituted.
[F. No.13/11/2021-EC]
AJAY TEWARI, Addl. Secy.

NOTE:- The principal rules were published in the Gazette of India Extraordinary Part II, Section 3, sub-section (i)
as G.S.R. 780(E) dated 22nd October, 2012.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
SARVESH KUMAR
SRIVASTAVA

Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2023.12.05 14:01:33 +05'30'
