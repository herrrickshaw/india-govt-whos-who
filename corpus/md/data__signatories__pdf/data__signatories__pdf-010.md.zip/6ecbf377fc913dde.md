---
doc_id: "6ecbf377fc913dde"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/4d84dd873efb9c94bce6aaedb74788bf.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Sanction Order for the FY-2019-20"
date: "2020-07-27"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "e7276e748a3c789a"
---

<!-- page 1 -->

126
202989/2020/IPR-VII
हि P-24029/56/2018-IPR-VIL
‘une aeR/Government of India
वाणिज्य एवम उद्योग मंत्रालय/५॥ inistry of Commerce & Industry
औद्योग संवर्धन और आंतरिक क्यापर fem/Department for Promotion of Industry and Internal Trade
(आई०पी०आर-ग्रतिलिपि अधिकार/[ PR-Copyright Section)
उद्योग भवन, नई दिल्‍ली-110011 /Udyog Bhavan, New Delhi-1 10011,
दिनाक: D “7 / 02/2020

To,

The Accounts Officer

Pay & Accounts Office,

Department for Promotion of Industry and Internal Trade

Ministry of Commerce and Industry

Udyog Bhawan New Delhi.

Subject: Release of grant-in-aid of Rs. 11,25,000/- (Rupees Eleven Lakh Twenty Five Thousand
only) National Law University(NLU) Delhi for incurring expenditure under IPR Chair activities
under the Scheme for Pedagogy and Research in IPRs for Holistic Education and Academia
(SPRIHA) for FY 2019-20,
Sir,

1 am directed to convey the sanction of the President to the payment of grant-in-aid of Rs,
11,25,000/- (Rupees Eleven Lakh Twenty Five Thousand only) for FY 2019-20 to National Law
University(NLU) Delhi for incurring expenditure for the approved activities of IPR Chair and the
conditions for Grant as provided in the norms of the Scheme for Pedagogy and Research in IPRs for
Holistic Education and Academia (SPRIHA).

2. The grantee does not have any pending UC and audited accounts under the Scheme.
3. The grant is subject to the following conditions:

i, The grant will be utilized only for the approved items of expenditure in accordance with
Norms of the Scheme for Pedagogy and Research in IPRs for Holistic Education and
Academia (SPRIHA) issued by the Department of Industrial Policy & Promotion vide their
O.M. No. F. 17-2/2016-IPR-VII dated 28.02.2018,

ii, The accounts and records shall be maintained in accordance with the procedure prescribed by
the Government of India.

iii. The assets acquired by the grantee out of the grants sanctioned shall be subject to the rules and
conditions prescribed by the Government of India from time to time in this regard,

iv.A register of the Permanent and semi-permanent assets acquired wholly or partly out of the
Government grant shall be maintained in the prescribed form and a copy thereof is furnished
to this Ministry. No item of the assets shall be transferred or otherwise disposed of without the
concurrence of the Ministry,

V. Before the amount is paid, a bond shall be executed by the Institute/Organization in respect of
the grant, if necessary under Rules. The organization receiving the grant shall have to give an
undertaking that no grant-in-aid has been received from any other authorities of the Central or
State Governments and that a grant-in-aid for the same Purpose has not been applied for by the
Organization to any of those authorities,

<!-- page 2 -->

127
202989/2020/IPR-VII
: vi. The account of all grantee Institutions or Organization shall be opened to inspection by the
sanctioning authority and audit, both by the Comptroller and Auditor General of India under
the provision of CAG (DPC) Act 1971 and Internal Audit by the Principal Accounts Office of
हु the Ministry or Department whenever the institution or organization is called upon to do so.
vii. The organization shall have to give an undertaking that the grant shall be utilized for the
purpose, and only for the purpose, for which it is sanctioned. Failure to do so shall render the
organization liable to refund to the Government the grant in full with such interest thereon as
the Central Government may decide.
vili.Separate accounts for the grant will be maintained and any information sought by the
Government of India will be furnished within the stipulated time.

ix. The assets acquired through government grant except those declared obsolete shall not be
disposed of without prior approval of the authority which sanctioned the grant.

x. The grant received under this scheme shall not be utilized for meeting the previous liabilities
or debt.

xi.A Utilization Certificate, certifying that the amount has been utilized for the Purpose for which
it has been sanctioned duly supported by a statement of audited accounts from concerned
Chartered Accountant or authorized auditor of the University/Institution as the case may be
and countersigned by the head of the organization, shall be furnished immediately after the
close of current financial year 2019-20 within one year from the date of issue of the
sanction. No previous UC is pending in respect of scheme for which this sanction relates,

xii. TA/DA should be paid as per Government of India Rules.

xiii. The decision of the Secretary to the Government of India in the Ministry of Commerce and
Industry (Department for Promotion of Industry and Internal Trade) on the question whether
there has been breach or violation of any of the terms and conditions appended to the grant
shall be final and binding on the grantee.

xiv. Institution receiving grant should irrespective of the amount involved, be required to
maintain subsidiary accounts of the Government grant and furnish to the accounts officer a set
of audited statement of accounts, These audited statement of accounts should be furnished
after utilization of the grants-in-aid or whenever called for. The accounts of all grantee
institutions shall be open for inspection by the sanctioning authority and audit.

Xv. If the Grantee fails to utilise the Grant for the Pupose for which the same has been sanctioned
or does not adhere to the terms & conditions of Grants and GFRs provisions, the Grantee
Institution shall be required to refund the Grants with interest @ 10% per annum.

xvi.The Grantee Institution shall not utilise the interest earned on the recurring/ non-recurring
Grants-in-Aid released to the Institution for any Purpose. the Interest earned shall be indicated
in UCs which can be either adjusted in next release or to be refunded to Gol after Grants-in-

Aid is utilised,
4, The grant of Rs. 11,25,000/- (Rupees Eleven Lakh Twenty Five Thousand only) to
National Law University(NLU) Delhi is debitable to Demand No.11 - Department for Promotion of
Industry and Internal Trade; Head of Accounts: 3475.00.102.11.11 “Scheme for Pedagogy and
Research in IPRs for Holistic Education and Academia”; 3475.00.102.11.11.31 — “Grant-in-Aid
General” 2019-20 and will be drawn by the Drawing & Disbursing Officer of the Department for
Promotion of Industry and Internal Trade and paid to National Law University(NLU), Delhi

<!-- page 3 -->

128
202989/2020/IPR-VII
S through Demand Draft/ Cheque/ Electronic/Telegraphic transfer of funds as per bank details of the
Grantee institution for making payment as below:-
हि Name of the Name of \Address/Code Bank [A /C Name and No. MICR Code and
beneficiary jank Branch IFSC Code
INATIONAL LAW |UCO First Floor, Pankaj |National Law {110028051
UNIVERSITY, BANK Plaza Plot No. 4, 1 niversity — Project and
DELHI ector — 4, Dwarka [Training ICBA0001871
New Delhi— 110075 [A/c No.
18710110012215
a The total release under this Object Head, including the Present sanction would be Rs.
_______/- during the current financial year as against the B.E. of Rs. 3,85,00,000/-.
6. Shri R.K Punia, Under Secretary, DPIT wil! act as Drawing & Disbursing Officer for the
purpose of Grants-in-aid Bill in r/o this sanction,
7. The pattern of grant/expenditure has been approved by the Ministry of Finance. ‘This sanction
is being issued in conformity with the rules and principles of the scheme as approved by the Ministry
of Finance.
8. This issues with the concurrence of the Integrated Finance Wing vide their Dy. No.
-2516 1 dated the 241 2.] 2020.
was Dutta)
Deputy Director
Copy to:
1. The Dean, NLU, Sector — 14 Dwarka, New Delhi — 110075
2. The Registrar, NLU, Sector — 14 Dwarka, New Delhi — 110075
By Drawing and Disbursing Officer, Department for Pormotion of Industry and Internal
Trade with two spare copies and bill in duplicate.
Ny 2 Ud
ems Dutta)
Deputy Director
Copy also forwarded to:
1. Accountant General, New Delhi.
2. A.G.C.R. (Spl. Cell), New Delhi.
3. Director General of Audit, Central Revenue, IP Estate, New Delhi.

<!-- page 4 -->

129
202989/2020/IPR-VII
4. Finance-II Division/B&A Section, DIPP Sanction Folder/Guard File.
N | 2M] .
(Nayonika Dutta)
Deputy Director
