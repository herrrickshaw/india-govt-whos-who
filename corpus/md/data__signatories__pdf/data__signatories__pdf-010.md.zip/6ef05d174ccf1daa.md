---
doc_id: "6ef05d174ccf1daa"
source_url: "https://mohua.gov.in/static/uploads/2025/11/a3e9a23d1fc58451db3ed105cae7ed2b.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of Rs. 358.80 lakh as part amount of 3' installment of Central Assistance to State Govt. of Jharkhand for 36 BLC (New Construction) projects under PMAY-U Mission - reg."
date: "2021-02-03"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f52082006c3e5ccb"
---

<!-- page 1 -->

https://pths.nic. inlSanction/TemplateAdvice.aspx?AdviceNums...

PAO(Sectt.)/HUA/Ad min /Advice/2020-21//514 -/,S —
GOVERNMENT OF INDIA
PAO(Sectt.), M/o Housing and Urban Affairs
507-C(wing),Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664

To,
The General Manager,
Reserve Bank of India,
Central Accounts Section,
Additional Office Building,
East High Court Road,
NAGPUR - 440 001

Code No:

707

Advice No: 495
Advice Date: 04/02/2021

Sir,
Please debit our account with Rs.3,58,80,000/- (Three Crore Fifty Eight Lakh Eighty
Thousand Only.) by contra credit to the following accounts of the Governments with the amounts
mentioned against each:

Month and Year of Accounts: February,2021
Sl.No.

Name of the
State

State
Code

1

JHARKHAND

125

The Amount to be Settled: February,2021

Scheme Code

Amount

1989-STATE AND UT
GRANTS UNDER PMAY
(URBAN)

3,58,80,000

GRAND TOTAL:

3,58,80,000

Sanction No. and Date

N-11012/33/2019HFA-V-UD (Comp. No.
9062285) dated
03/02/2021

Signature of the authorized official

91-(Pawan Kumar Bhatnagar)
Senior Accounts Officer

1. 0/0 the Accountant General (A&E)-I, Jharkhand, Ranchi-834002
B K Mandal, US(HFA), M/o-HUA

Pawa n
hatnar
(Senior Accounts Officer)

a) /-O-- HF/
12
-

frfl-M'
-\

I of 1

04-02-2021 12:47

<!-- page 2 -->

N-i 1012/33/20 19-IIFA-V-UD (Comp. No. 9062285)

Government of India
Ministry of Housing & Urban Affairs
HFA-V Section
Room No. 03, Technical Cell, Gate No. 7,
Nirman Bhan, New Delhi
Dated: 03.02.2021
To
Pay and Accounts Officer (Sectt.),
Ministry of Housing and Urban Affairs
Nirman Bhawan,
New Delhi-ii
Sub:

Release of Rs. 358.80 lakh as part amount of 3" installment of Central
Assistance to State Govt. of Jharkhand for 36 BLC (New Construction)
projects under PMAY-U Mission - reg.

Sir,
I am directed to convey the Sanction of the President of India to the release of Rs.
3,58,80,000/- (Rupees Three Crore Fifty Eight Lakh and Eighty Thousand only)
to State Govt. of Jharkhand for 36 BLC (New Construction) projects as part amount of 3rd
installment of Central Assistance (ST component) for Creation of Capital Assets
under Pradhan Mantri Awas Yojana - Urban (PMAY-U) Mission for the FY 2020-21.
The statement showing details of the projects against which the above Grant is released
towards part amount of 3'' installment of the Central Assistance is at Annexure.
2.

The State Govt. of Jharkhand was released funds of Rs. 22152.00 lakh as part amount
1st
of
and 2nd installment of Central Assistance for 18,460 beneficiaries of 36 BLC (NC)
projects i-ide this Ministry's sanction letter No. N-lloll/28/2016-HFA-III (C. No. 3016738)
dated 04.05.2017, letters of even number dated 26.03.2019, 16.09.20 19 and 24.09.2019.
In compliance to the conditions for release of 3!(1 and final installment of Central
4.
Assistance for 36 BLC (NC) projects, the following have been furnished by the Govt. of
Jharkhand:
i. UCs of Rs. 19,783.20 lakh (more than 89%) against the total Central Assistance of Rs.
22,152.00 lakh released for the said projects under PMAY-U Mission.
ii. Physical progress report as per Enclosure to Annexure 8 of the Mission guidelines
iii. ATR on TPQMA Report
iv. Completion certificate for 18,961 houses in various cities of the 36 BLC (NC) projects,
as per Annexure 9 of the Mission guidelines.
V.
Status of 6 mandatory reforms under PMAY-Mission, which is in conformity
with Annexure A attached with M0A.
vi. Compliance report on Desk and Site scrutiny conducted by HUDCO for the said
projects.
vii. Photographs of the completed houses.
3.

The State has furnished physical progress report and Third Party Quality Monitoring
5.
(TPQM) report along with Action Taken Report (ATR). The TPQMA has found quality of
work to be satisfactory and the compliances on the recommendations of TPQMA have also
been made by the State as per ATR.
Based on decision of CSMC under Pradhan Mantri Awas Yojana (PMAY) - Housing for
6.
All (Urban) Mission in its 20th meeting held on 21.03.2017, the amount of central grant is
being released subject to the following conditions:
Contd. ...P2/

<!-- page 3 -->

-9-

i. The funds shall be utilized for the purpose and within the selected categorized
beneficiaries, for which these are given. Otherwise these will have to be refunded along
with interest as per provisions under GFR 2017.
ii. The expenditure on the implementation of the scheme/projects will be shared between
the Central and the State/ULB/lmplementing Agency , (IA) as committed- The
committed State share should also be released within 15 days from the date of receipt
of Central Assistance in the SLNA account. In case of shortfall of StatefULB/IA share,
corresponding amount of Central share will be deducted from the subsequent releases
for the projects.
iii. The funds including Central Assistance and State share will thereafter be released by
the State/UT Government to the implementing agencies without any delay failing
which the amount would be recovered from the State/UT Government with interest, as
applicable, for the period of default.
iv. Necessary sanctions/approvals/compliances required under the statutory or other
regulatory regime as applicable would be obtained by the authority(ies) concerned
with the project(s).
v. The State Government and implementing agency shall put in place a monitoring
system to ensure that the project(s) achieve scheduled milestone and envisaged
outcomes including implementation of reforms and other conditionalities required
under the scheme.
A. The State Government shall utilize the grant in accordance with the approved
guidelines for the implementation of the Scheme of PMAY-U Mission.
vii. The State Government shall furnish the Utilization certificates of the Grant released in
the prescribed format as per GFR 2017 as provided in the scheme guidelines.
viii. Where there is an element of cash transfer to individual beneficiaries, the same may be
made through DBT/EAT module of PFMS as applicable. The State Government shall
submit an authenticated certificate from the bank showing complete details of
disbursement of funds to each beneficiary before further releases for the projects.
ix. The State Government shall ensure the geo-tagging of all houses approved under BLC
component of PMAY(U) Mission.
x. The State Government shall be required to certify that the specifications of the houses
conform to NBC/IS Standards and that requisite infrastructure for the projects are
provided by the State Government/ULB.
xi. The State Government shall ensure quality monitoring of the said projects by Third
Party Quality Monitoring Agency (TPQMA) in 2-3 visits and submit the Action Taken
Report (ATR) on the observations/recommendations of TPQMA before release of
balance amount of 3i'd and final installment of Central Assistance.
xii. The balance amount of 3rd and final installment of Central Assistance will be released
contingent of achieving all mandatory reforms, completion of projects including
construction of houses and infrastructure in each project and submission of project
completion reports for all approved projects as per Annexure 9 of the Mission
Guidelines.
The
State should ensure that Model Code of Conduct is not violated while releasing
xiii.
funds to Implementing Agencies/ULBs/Beneficiaries.
Contd. ... P.3/

-

I

MW

<!-- page 4 -->

-

3-

Additional allocation through 2nd Supplementary Demand for Grants 2020-21 for
7.
PMAY-U is vet to be received. Therefore, in pursuance to DEA O.M. No. 7/41/2019-BA(Pt.I)
dated 06.01.2021 conveying authorization for incurring excess expenditure of Rs. 6,000.00
crore over and above BE allocation for PMAY-U by invoking Appendix-lo under Rule 61 and
69 of GFR 2017, the expenditure involved will be debited from head 3601.06.502.01.03.35
(ST component) under Demand No. 57 of Ministry of Housing and Urban Affairs for the
year 2020-21 and will be transferred to the following head of accounts on regularization after
receiving the 2nd SDG 2020-21:
Major Head
Sub-Major Head

3601

Minor Head

06
796

Sub Head

17

Detailed Head
Object Head

01

Grants-in-Aid to State Governments
Centrally Sponsored Schemes
ST Component
Pradhan Mantri Awas Yojana (Urban)
Assistance to State Governments for PMAY(U

1 7-0 1-35 Grants for Creation of Capital Assets

8.
The amount will be credited to the State Government's Account at Reserve Bank of
India, CAS, Nagpur as per procedure laid down by Ministry of Finance, Department of
Expenditure in this regard.
Requisite UCs of ist and 2nd installment of Central Assistance have been received from
9.
State Govt. and are enclosed herewith.
10.
As per rule 236(1) of GFR, 2017, the relevant accounts of the Grantee
Institution(s)/Organisation(s) shall be open to inspection by the sanctioning authority and
audit, both by the Comptroller and Auditor General of India under the provision of CAG
(DPC) Act 1971 and internal audit by the Principal Accounts Office of the Ministry or
Department, whenever the Institution or Organisation is called upon to do so.
ii
This issues with the concurrence of the Finance Division vide their Note # 104-106
No. (E: 9062285) dated 11.09.2020.
This sanction has been registered at S. No. 2.38 in the Sanction Register of HFA
Mission Directorate of the Ministry of HUA for the year 2020-21.
12.

Yours faithfully,
(B.K
Under Secretary to the Government of India
Tel. 011-23063285
End.: As above.
Copy to:

1. Secretary, Urban Development & Housing Deptt., State Government of Jharkhand,
Ranchi
2. Accountant General (A&E), Jharkhand
3. CCA,MoHUA
4. Director (IFD), MoHUA
5. Director (HFA-3), MoHUA
6. Deputy Secretary (Budget), MoHUA
Contd... . P.4/

<!-- page 5 -->

7. NITI Aayog, SP Divn./DR Divn., New Delhi
8. 0/0 CGA, Mahalekha Niyantrak Bhavan, New Delhi.
9. Dy. Chief (MIS/DRMC), HFA Directorate to place this sanction at appropriate place on
the Website of the Ministry.
10. PMU (MIS), HFA Directorate
11.AO (HFA), MoHUA
12. Sanction folder
13. File Copy
(B.K. Mandal)
Under Secretary to the Government of India

<!-- page 6 -->

P

-

-

c
0

o

o

o

0

c

0

c

0

0

0

0

pi

-

1

C0

F

C"

C'

-

-

C

—•-----;

—

—

i

—

—

C

o
•5

-,

*

E
0 L

-

-

1'

c

II

2

-5

E

0

I

-

•C'

r

CC'
02

I
C

P
6

6

6

C'

6

'C

b

._•5

'C.0

C

6
C

t

C
0 0

t0

-

b k

i -i_I1IIIIIEI_IIIii

<!-- page 7 -->

g

FPF
F

P

a

a

F

PP

F

I

-

9

1

I

-

0

0

0

0

-

2

2

0
ci

L
o

-'9F

C.-

O!I

-

•_c

0

1i00
c-'9

c9

I1 Ifl Oh

o

'

o

c 6C

0

c<

00

Xc

-

c

c
B
E

00

-9--

3

9

F

4

-

2

E

0

2

0

2

2

2

<!-- page 8 -->

8

8

0

o

0

(

0

0
0
0

P

00

8

0
Vt

-

0

0

H

P

0

0

0

C.

0

0

P

"

0

-

0
'a

'0

k
C.-

EC'€.

8E
CoC
Cz

E=

0

liil

:E:5 1

'C

I1
:

'8'

'E'.0

:.

ON

a

<!-- page 9 -->

I 2i6oa2/o1fHFA-v SECTION
J
n

Form CFR 19- A
ISet' Rule 2123 (l)J
Form

U1itiz.,6on Certi1i.'tv

Certified that out of R--.l 2258A01- (One hundred twenty twu tsor* fifty e1i( I.kIi fourty thousand
wily) Giants-in-aid sanctioned duiirnt the ycal 2017-18 in favor of Urban Development & Housing
Development, Govt. of Jharkhand under this Ministry/Department Letter no. given in the table below, a
sum of Rs.12258.40/- (One hundred twenty twO crore fifty eight Iakh fourty thousand only) has
been utilized for the purpose of Beneficiary Led Construction under Pradhan Maniri Awas Yojna
(PMAY) for which it was sanctioned and that the balance of Rs. NIL remaining utilized at the end of
the year.

Sr. No.

Letter No. and Dale

Amount (In Lkkh)

A

N-I 1011/28/2016-I IFA-Itl(( -N-306738)Datcd:-04.05.201 7

12059.40

B.

N-1 101 1/28/20 16-flEA-I I l(CN-30 I 6738)Datcd;-3 1.05.2017

199.00

C.

Amount Received (A+B)

12258.00

D.

Expenditure

12258.00

Balance Amount (C-D)

0.00

2. Certified that I have satisfied myself that the conditions on which the grant-in-aid was sanctioned
have been duly fulfilled/ are being fulfilled and that I have exercised the following checks to see that
the money was actually utilized for the purpose for which it was sanctioned.
3. Physical progress of the projects, where Government of India grants have been utilized, is enclosed.
Kind of Check exercised:
I. VLBs wise UC details kept in file

run Kumar Singh)
Principal Secretary to Govt.

<!-- page 10 -->

704

tJC for F.Y. (2019-20)
CFR 12—C
(Rule 239)
Govt. Of lharkliand
Form Utilization Certificate For the year 2019-2020
No.

Letter No. and Date
-

Amount Certified that out of Rs. 7723.80 Lakhs* of grants
(In IakIISJ

sanctioned Juring the year 2018-19 in favour of Urban
Development

Central fund released
year
during
the
2018-19
(*As per details given
below)
LI 1012/33/2019HFA-V-UD
(Comp. No.-9062285)
dated 26.03.19

&

Housing

Department.

Govt.

Jharkhand under the Ministry/ Department Letter no.
given in the margin and Rs. 7723.80 Lalclis on account
of unspent balance of the previous year, a sum of Rs.
7723.80 Lakhs has been utilizcd for the propose of

7723.80

PMAY(U)-Vertical IV for which it was sanctioned and
that the balance of Rs. 0.00 Lakhs remaining unutilized
of the end of the year has been surrendered to
Government (vide No..

dated ..)/ will be adjusted

towards the grants payable during the year.
2.

Total Fund Received:-

772380

3.

Fund utilized
31.08.2019

7723.80

4.

Total Unspent Balance
( Row 2-3)

upto

0.00

Certified that I have satisfied myself that the conditions on which the grants-in-aid
was sanctioned have been duly fulfilled/ are being fulfilled and that I have exercised
the followings checks to see that the money was actually utilized for the propose for
which it was sanctioned.
Kinds of Check exercised
I. Cash Book
2. Pass Book
3. Utilization Certificate w.r.t ULBs
4. Sanction Letters w.r.t ULBs
5. Annexnrc-8 of PMAY Guidelines
2.

Signature..

Of

.

Designation.. .Director

Designation.. .Secretary

Date:,.. P.'!j! ..............

Date:

/P. /L I .............
