---
doc_id: "6d836ddbbc2a49ea"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/8fc7a1a844ca95b4a39cc4fad16ffcd1.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Appointment /Promotion of employees of CPSEs In CDA Scales of pay on or after 01.01.1989."
date: "2009-08-10"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "128b1de0808f785c"
---

<!-- page 1 -->

7
4 No. 2(41)/09-DPE worGLoK_|2009M
Government of India
Ministry of Heavy Industries & Public Enterprises
_ Department of Public Enterprises
Public Enterprises Bhawan,
Block No. 14, C.G.0. Complex,
Lodhi Road, New Delhi-110003
हु Dated:/Q August, 2009
OFFICE MEMORANDUM -
Subject: Appointment / promotion of the employees of CPSEs in CDA scales
of pay on or after 01.01.1989.

The undersigned is directed to invite attention to Para 3(iii) of this Department's
O.M.No.2(43)/90-DPE(WC) dated 12.6.1990 which, inter alia, provides that all
appointments made on or after 01.01.1989 in respects of all categories of employees by
the CPSEs would be deemed to have been governed by the IDA pay scales and IDA. है
The aforesaid O.M. dated 12.6.1990 is in pursuance of the Supreme Court Judgment
dated 03.05.1990 giving directions for implementation of the report of High Powered Pay
Committee.

2. Para 3 (ii) of the Supreme Court Judgment dated 03.05.1990 provides that the
employees appointed on ‘or after January 1, 4989 will be governed by such pay scales
and allowances as may be decided by the Government in its discretion. Those
appointed earlier with IDA pattern will continue to be governed in accordance with the
terms and conditions of their appointment.
3. Earlier references were received from certain Ministries/CPSEs wherein a
question had been raised as to whether the word ‘appointment’ as mentioned in para 3
(ii) of Supreme Court's Judgment dated 03.05.1990, Annexure-I to the DPE O.M. dated
12.06.1990 on the subject of implementation of Higti Powered Pay Committee's
recommendations, includes ‘promotion’ also. The matter was considered in consultation *
(with Ministry of Law & Justice, Department of Legal Affairs. It was held that recruitment
, includes any method provided for inducting a person in public service.. Appointment, .
4selection, promotion and deputation are all well-known methods of recruitment. The
(४005 ‘employment’ or ‘appointment’ have been held to be wide enough to include the
» “matter of promotion including promotion to selection posts. '
4, On the issue whether ‘Eppointment’ includes ‘promotion’, the clarification as per
Para 3 above was given on a Case by case basis. This issue has been raised again by
some Ministries/ CPSEs in the context of recent pay revision in the case of employees of
both CDA and IDA pay scales in CPSEs. It is again emphasized that there is no change
in the position as given in para 3 above.
5. In case there are any Court Cases/ Court Orders relating to CDA/ IDA pattern of
employees in a particular CPSE, the Administrative Ministry) CPSE should take into
account the implications. of such Court Cases/Court Orders while de over ©
employees from CDA pattern of pay scales to IDA pattern of pay scales. 5
a
(P.4 Michael)
Undersecretary
Tel: 24360823
To *
4. Administrative Ministries/ Departments of the Government of India
2. Chief Executives of Central Public Sector Enterprises.
a
V
ARCHIVED
