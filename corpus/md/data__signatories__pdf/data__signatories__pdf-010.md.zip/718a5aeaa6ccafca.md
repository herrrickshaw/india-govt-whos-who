---
doc_id: "718a5aeaa6ccafca"
source_url: "https://mnre.gov.in/static/uploads/2025/08/30ad0e9d69f15b9477b2a3d510b396cc.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Guidelines for implementation of Central Public Sector Undertaking (CPSU) Scheme Phase-II (Government Producer Scheme)"
date: "2019-03-05"
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ac6698f18f94fcf8"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

No. 302/4/2017-GRID SOLAR
भारत सरकार / Government of India
नवीन और नवीकरणीय ऊर्ाा मंत्रालय/ Ministry of New & Renewable Energy
ग्रिड सौर ऊर्ाा प्रभाग / Grid Solar Power Division
Block No. 14, C.G.O. Complex,
Lodi Road, New Delhi – 110003
Dated: 10th May, 2021
ORDER
Subject: Implementation of Central Public Sector Undertaking (CPSU) Scheme Phase-II (Government
Producer Scheme) for setting up 12,000 MW grid-connected Solar Photovoltaic (PV) Power Projects by
the Government Producers with Viability Gap Funding (VGF) support for self-use or use by
Government/ Government entities, either directly or through Distribution Companies (DISCOMS)Amendment –reg.
1. Reference is invited to this Ministry’s Order No. 302/4/2017-GRID SOLAR dated 5th March 2019 and
amendment thereto vide Order No. 283/20/2019-GRID SOLAR-Part(2) dated 13th April 2020 and it is
hereby conveyed that the Order for Scheme Guidelines for Central Public Sector Undertaking (CPSU)
Scheme Phase-II (Government Producer Scheme) stands amended as follows:
Clause
No.
3.2.3

Existing Provision
3.2.3 Usage Charges:
Power produced by the Government
Producers can be used for self-use or use
by Government/ Government entities,
either directly or through DISCOMS on
payment of mutually agreed usage
charges of not more than Rs. 2.80/unit,
which shall be exclusive of any other third
party charges like wheeling and
transmission charges and losses, point of
connection charges and losses, crosssubsidy surcharge, State Load Despatch
Centre (SLDC)/ Regional Load Despatch
Centre (RLDC) charges, etc. as may be
applicable.

3.2.5

3.2.5

VGF:

3.2.5.1 With the objective of covering the
cost difference between the domestically
produced solar cells and modules and
imported solar cells and modules, VGF
shall
be
provided
under
the
Scheme. While the maximum permissible
VGF has been kept at Rs. 0.70 cr./MW, the
actual VGF to be given to a Government
Producer under the Scheme would be
decided through bidding using VGF
amount as a bid parameter to select
project proponent. The Indian Renewable
Energy Development Agency Limited
(IREDA) will be entrusted with the task of
conducting
the
bidding
amongst

Modified Provision
3.2.3 Usage Charges:
Power produced by the Government
Producers can be used for self-use or use
by Government/ Government entities,
either directly or through DISCOMS on
payment of mutually agreed usage
charges of not more than Rs. 2.45/unit,
which shall be exclusive of any other third
party charges like wheeling and
transmission charges and losses, point of
connection charges and losses, crosssubsidy surcharge, State Load Despatch
Centre (SLDC)/ Regional Load Despatch
Centre (RLDC) charges, etc. as may be
applicable.
3.2.5

VGF:

3.2.5.1 With the objective of covering the
cost difference between the domestically
produced solar cells and modules and
imported solar cells and modules, VGF
shall
be
provided
under
the
Scheme. While the maximum permissible
VGF has been kept at Rs. 0.55 cr./MW, the
actual VGF to be given to a Government
Producer under the Scheme would be
decided through bidding using VGF
amount as a bid parameter to select
project proponent. The Indian Renewable
Energy Development Agency Limited
(IREDA) will be entrusted with the task of
conducting
the
bidding
amongst

<!-- page 14 -->

Clause
No.

3.6.1

Existing Provision

Modified Provision

Government Producers for allocation of
solar power project capacity under the
Scheme, with VGF amount as a bid
parameter to select project proponent. The
maximum permissible VGF amount will
also be reviewed from time to time, by
MNRE, and will be reduced by MNRE if
the cost difference comes down. VGF will
be released in two tranches as follows:

Government Producers for allocation of
solar power project capacity under the
Scheme, with VGF amount as a bid
parameter to select project proponent. The
maximum permissible VGF amount will
also be reviewed from time to time, by
MNRE, and will be reduced by MNRE if
the cost difference comes down. VGF will
be released in two tranches as follows:

i. 50% on Award of contract to the EPC
contractor (including in-house EPC
Division); and

i. 50% on Award of contract to the EPC
contractor (including in-house EPC
Division); and

ii. balance
50%
on
successful
commissioning of the full capacity of
the project

ii. balance
50%
on
successful
commissioning of the full capacity of
the project

3.2.5.2 The VGF provided under the
Scheme can be used by the Government
Producers as their equity in solar power
project(s) being set up them under this
Scheme.

3.2.5.2 The VGF provided under the
Scheme can be used by the Government
Producers as their equity in solar power
project(s) being set up them under this
Scheme.

3.2.5.3 If a Government Producer sets up
solar PV power project(s) under CPSU
Scheme Phase-II, in an UMREPP/ Solar
Park, both, the Central Financial
Assistance (CFA) as per UMREPP/ Solar
Park Scheme as well as VGF under the
CPSU Scheme Phase-II, will be eligible.

3.2.5.3 If a Government Producer sets up
solar PV power project(s) under CPSU
Scheme Phase-II, in an UMREPP/ Solar
Park, both, the Central Financial
Assistance (CFA) as per UMREPP/ Solar
Park Scheme as well as VGF under the
CPSU Scheme Phase-II, will be eligible.

3.6.1
Timelines
commissioning:

for

project

The solar power projects under this
scheme shall be commissioned within a
period of:
(i). For projects upto 500 MW
capacity:
Projects
to
be
commissioned within 24 (twenty
four) months from the date of letter
of award
(ii). For projects more than 500 MW
capacity: Capacity upto 500 MW
must be commissioned within 24
(twenty four) months from the date
of letter of award and balance
capacity to be commissioned within
next six months.

3.6.1
Timelines
commissioning:

for

project

The solar power projects under this
scheme shall be commissioned within a
period of 30 (thirty) months from the
date of letter of award.
However, in order to expedite the
implementation of the Scheme and to give
impetus
to
domestic
solar
PV
manufacturing, a shorter timeline can also
be specified by MNRE.

<!-- page 15 -->

Clause
No.

Existing Provision

Modified Provision

However, in order to expedite the
implementation of the Scheme and to give
impetus
to
domestic
solar
PV
manufacturing, a shorter timeline can also
be specified by MNRE.
2. This issues with the approval of Hon’ble Minister (NRE & Power).

(Sanjay G. Karndhar)
Scientist-D
Email: karndhar.sg@nic.in
Tel: 011-24363498
To
Pay and Accounts Officer,
Ministry of New & Renewable Energy,
New Delhi
Copy for information and necessary action to:
1.
2.
3.
4.
5.
6.
7.

Central Government Ministries/Departments,
Principal Director of Audit, Scientific Audit-II, DGACR Building. I.P. Estate, Delhi-02
All State/UT Energy Secretaries
All Heads of State/UT Nodal Agencies
All State/UT DISCOMs
Chairman & Managing Director, SECI
Chairman & Managing Director, IREDA

Internal Distribution:
1.

PS to Hon’ble Minister of State (I/C) for New & Renewable Energy, Power and MoS for Skill
Development and Entrepreneurship
2. Sr. PPS to Secretary, MNRE
3. All Advisers and Group Heads/JS (AKS) / JS (BPY) / JS (DDJ)/ JS&FA/ Eco. Adviser
4. All Scientist-F/ Scientist-E/ Directors
5. All Scientist-D / Dy. Secretaries
6. All Scientist-C/ Under Secretaries
7. All Scientist-B
8. NIC, MNRE for uploading on Ministry’s website
9. CA, MNRE / Cash Section
10. Hindi Section for Hindi version
11. Sanction Folder

(Sanjay G. Karndhar)
Scientist-D
Email: karndhar.sg@nic.in
Tel: 011-24363498

<!-- page 16 -->

· f.

F. No. 283/20/2019-GRID SOLAR-Part(2)
147d JR / Government of India

fj 3# +fjaufq 3if riauy Ministry of New & Renewable Energy
)s #k 3f 7 / Grid Solar Power Division
Block No. 14, C.G.O. Complex,
Lodhi Road, New Delhi - 110003

Dated: 02" June, 2021
OFFICE MEMORANDUM
$

Sub: Solar PV Power Projects under Tranche-I and Tranche-II of CPSU Scheme Phase II
(Government Producer Scheme), implemented by SECI - reg.

1. Reference. is invited to the requests received from SECI vide its letter nos.
SEel/Solar/CPSU PII/T1 & T2/ Extension/40369 dated 11.12.2020 and dated 26.03.2021
and. email dated 16.04.2021, regarding extending the time lines for project execution under
Tranche I and II of CPSU Scheme Phase-II.

2. Representations have been received for extending the timelines for projects in Tranche-Ill
of CPSU Scheme Phase-II, primarily on account of temporary shortage of equipment for
solar PV power projects, particularly domestically manufactured solar PV cells. The
interactions of the Ministry with industry stakeholders have also indicated that the addition
of new domestic manufacturing capacity of solar cells has been delayed due to COVID-19
related travel restrictions.

3. Against the above background, with the approval of Hon'ble Minister (NRE & Power),
MNRE modified the Scheme Guidelines for CPSU Scheme Phase-II to increase the
project timelines. The commissioning period has been enhanced from present 24 (twenty
four) months to 30 (thirty) months from the date of letter of award (LoA). Further, the
timeline for the intermediate milestone of "Award of EPC Contract', which was 6 (six)
months from LoA, in Tranche-I & Tranche-II, has also been increased to 12 (twelve)
months from the date of LoA.

4. In order to address certain issues pertaining to projects sanctioned under Tranche-I &
Tranche-II of CPSU Scheme Phase -II, the amended timelines shall also be applicable to
Tranche-I & Tranche-II projects.

5. In accordance with these new timelines, for projects under Tranche I & II:
l

a) Government Producers who had awarded the EPC contract within 6 (six) months from
the date of issuance of LoA by SECI, shall increase the time period for project
execution by EPC contractor such that the total project timeline is 30 (thirty) months
from the date of LoA by SECI.

Page 1 of2

<!-- page 17 -->

b) Projects where the award of EPC contract happened beyond 6 (six) months but within
12 (twelve) months of LoA by SECI, such delay is regularised and the Government
Producers shall keep the time period for project execution by EPC contractor such
that the total project timeline is 30 (thirty) months from the date of LoA by SECI.
c) In cases where the EPC contract has not been awarded even within 12 (twelve)
months of issuance of LoA, SECI may carefully assess the readiness of the project for
commissioning within 30 (thirty) months of LoA, and based on that decide on giving
more time for award of EPC contract, subject to the payment of applicable penalties
by such Government Producers. The overall project completion timeline in such cases
will stay at 30 (thirty) months. All other projects are to be cancelled and such
organisations can apply afresh or participate in future CPSU Scheme tenders.
d) The above timelines are excluding the extension(s) given on account of COVID-19,
including the 5 (five) months blanket extension already given by MNRE.

6. A compliance report on Para-5 above shall be submitted by SECI within a fortnight of this
O.M.

7. This issues with the approval of Hon'ble Minister (NRE & Power).

Md.ca

(Mohd Azmal Mansoori)
Scientist-B
Email: azmal.mnre@gov.in

To:
The Chairman & Managing Director, Solar Energy Corporation of India (SECI), Plate-B, 6th
Floor, Tower 2, NBCC Office Block, East Kidwai Nagar, New Delhi-110023
Copy to:

1. AII concerned
2. NIC, MNRE, for uploading on MNRE website for dissemination of information.
Copy for internal circulation to:
PS to Hon'ble Minister (NRE & Power)/ Sr. PPS to Secretary I Sr. PPS to JS (AKS) / Dir (RG)/
Sci-D (SK)

Page 2 of 2

<!-- page 18 -->

<!-- page 19 -->
