---
doc_id: "6ec0ca3cc73ffa8a"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2026/10/79da9550cbd2b55dfd7b57a51dd56eb0.pdf"
ministry: "Department of Land Resources (DLR)"
title: "Work Order for Engaging Yashwantrao Chavan Academy of Development Administration, Pune for establishment of Centre of Excellence (COE) in Land Administration Management under DILRMP- Reg."
date: "2024-09-25"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eabb9721583d6c3a"
---

<!-- page 1 -->

No.: 23012/0/2024-LRD (e-3013879)
Government of India
Ministry of Rural Development
Department of Land Resources

NBO Building
Nirman Bhawan, New f)elhi
Dated: 25.09.2024

I'o,
The Director General
Yashwankao Chavan Academy of Development Administration
(YASHADA)
Pune

Subiect: Work Order for tsngaging Yashwantrao Chavan Academy of Development
Administration, Pune for cstablishment of Centre of Excellence (COE) in Land Administration
Management under DILRMP- Rcg.
Sir,

I am directed to refer to thc proposal on cstablishmcnt of Ccnhc of Excellence (COE) in
Land Administration Managemcnt undcr Digital India Land Records Modcrnization Programmc
(DII-RMP) rcccivcd vidc lcttcr No. ADG/2O24IDoLR-COE datcd 7'l/06/2024 (copy enclosed)
from Additional Director Gcncral, YASHADA, Punc.

2.

lt is informed that Compctent Authority in this Dcpartmcnt has approvcd the proposal

with following Terms of Refcrenccs (ToRs):

i.

OBfECTTVES:

a. Monitor and cvaluate thc impact of land govemance rcforms and initiatives and provide
feedback for continuous improvcment.

b. Conduct research on bcst practices and innovative solutions in land administration and
management.

c. Provide technical advice and support to State governments and policy makers for the
development of effectivc land governance policies and strategics.
d

. Provide assistancc in survcy / re-survey activities using advanced technologies like
ETS/ DGI'S, drone, LiDAR ctc. for rural and urban arcas.

e. Provide assistance and support in implementation of innovative initiatives like BhuAadhaar or ULPIN. NGDRS and Transliteration of Land Records in various States/UTs.

f. Contribute to strengthcn and streamline process towards land tenure security, Land
reforms, land records digitization, consolidation of holding and the resolution of land
disputes.

g. Support in standardization of various paramcters rclated to Land Parcels as envisaged in
National Geospatial Policy 2022

h. Provide support for having cfficicnt system for collection of rents, transfer and alienation of
land, land improvement and agricultural loans excluding acquisition of non-agricultural
land or buildings, town planning improvc mcnts, thc asscssmcnt and collection of revcnuc,
survey of revenue purposes, alicnation of revenues il thc Statcs
"t0

?.\

<!-- page 2 -->

Provide training regarding Administration of the RFCTLARR Act, 2013 and matters
relating to acquisition of land for purposes of the Union.

Provide guidance for rccovcry of claims in a State in respcct of taxcs and other public
demands, including arrcars of land revenue and sums recoverable as such arrears, arising
outside that State.

k. Establish a knowlcdgc managcment system for sharing information, best practices, and
lessons learned in land administration and managemcnt.

l. To provide support in legal mattcrs like study of various acts and suggestions for
amcndment related to land and rcgistration processes.

m. Advocate for policy reforms aimed at improving transparency, accountability, and
cfficienry in land administration systems.

n. Build partnerships and networks with other institutions, govemment agencies, and
stakeholders to facilitate knowledgc exchange and collaboration.

o. Enhance the capacity of land administration professionals through training programs,
workshops, and scminars.

p. Provide technical assistance to other countries in thc implcmcntation of land govemance
reforms and initiatives.

q. Support efficient land usc planning and management that contribute to economic growth,
social equity, and environmental sustainability.

Functions: The CoE is envisioncd as a hub for research, training, and capacity building in
the field of land administration and management for thc States of Chhattisgarh, Goa,
Guiarat, Madhya Pradcsh, Maharashtra and UT of Dadra & Nagar Haveli and Daman &
Diu. The COE shall provide rclevant inputs to DOLR pertaining to the following:

a. Conduct thc impact and evaluation studies on various paramcters of land governance and
provide feedback and suggcstions for improvcments.

b. Compile and document thc bcst practices/innovative initiativcs of va ous States/UTs in
field of Land Govcrnance.

c. Provide technical assistance in survey/re-survey using ETS/ DPGS, drones, LiDAR etc. to
the regional statcs whcrc the CoE is establishcd.

d. Provide hands-on training for digitization and georefcrcncing using open-source GIS
softwarc like QGIS to local revenuc functionaries.

e. Conduct high Quality Training in Land Surveying, Computcrization of RoRs, Digitization
of Cadastral Maps with spccial focus on emerging technologics for Urban and Rural areas.

f. Support in various activities of Digital India Land Records Modcrnization Prograrrune
(DILRMP) and Digitization of Urban Land Records Programmc (DULREP)

g. Study various acts of State Govcrnmcnt related to urban and rural land records and titling
ctc

h. Prcpare and update the glossary of various terms in differcnt States/UTs with their
meanings for stardardizing thc RoRs and other documents relatcd to Land.

4h{*,

Assist in formulating various standards related to land parccls as pcr National Geospatial
Policy (NGP) 2022 and formulating draft standards for placing beforc Thcmatic Working
Group on Land Parccls of DoLR for further modifications.

<!-- page 3 -->

j. Conduct Research and Dcvelopmcnt in related fields and disseminate the results of the
R&D, other activities and transforming them into sustainable proposals/ solutions.

k. Support crcativc and innovative proposals related to Land AdministratiorL Management or
Governance in terms of functions and facfities.

l. Establish a sound new institutional base for executing the programmes/ projects by
strengthening the existing infrastructure.

m. Foster relations across countrics, bctwccn govemmcnts, workcrs, chambers of commerce,
academia, industry and othcr Industrial associations in cstablishing collaborations of
various projects of Institute/Organizations in the domain of Land Govemance.

n. Create network of ncarby institutcs for capacity building and montoring support to various
Revenue Officials and field functionaries for effective implemcntation of

schemes/programmcs.

o. lmplcmentation of action points emcrged during mceting hcld on 29.08.2024 in DoLR as
per minutes of the mecting (copy attached).

IINANCIAL TIRMS AND CONI)I'I-IONS:

t

a

YASHADA will bc paid by DoLR a sum of Rs.45,60,000/- (Rs. Forty Fivc Lakh Sixty
Thousand only) for 1.t ycar (01.10.2024-31,.03.2025\ and Rs. 67,20,000/- (Rs. Sixty Sevcn
Lakh Twenty Thousand) from 2nd year onwards for the activitics as mentioned in thc
proposai received from YASIJADA vide letter No. ADG/ 2024/ DoLR-COE dated
1,1,/06/2024 ar.d in accordancc with Table 1 below.

b. Funds will bc rclcascd in 4 cqual quartcrly installmcnts i.c. 25% of thc total yearly budgct
at a time. The paymcnts shall bc made evcry quartcr in advancc after rcceiving dctailcd
activities undcrtakcn during thc quartcr and Utilization Ccrtificate for at least 75%

cxpenditure of fund rclcascd for prcvious quarter.
'I'able1
Year

Iixpcnditurc IIead
(non-Ilecurring)

Operational Iixpcnditure
(Recurring)

'fotal Amount

12,00,000

33,60,000

45,60,000

Nll.

67,20,000

67,20,000

Ycar -1

(rNR)

(1* October,
202+37*

Madt205)
Year -2 (1'r

Apm,NZL
31$ March,

2026)

Onwards

iv.

I{EVIEW BY DOLI(:
A Quarterly report containing details of activities, trainings, workshops etc. undertakcn by
CoE would be sent to DoLR and a dctailcd prcscntation along with future action plan shall
bc donc, before rclcasc of amount for ncxt quarter.

qd-

<!-- page 4 -->

3. Thc guidelincs issucd vidc lcttcr No.2j012/ 01, / 2024-LRD (e-3012879) dated 31.05.2024 for
establishment of Ccntrc of Excellence (CoE) under DILRMP shall bc adhered for
functioning of CoE.

4. The details of Bank Account Number, IFSC Code, Branch Name may bc comrnunicated for
fund release.

5. This issucs with thc approval of Competent Authority.
Yours Faithfull v,

4
(Day
Jo
Deputy Secretary to the Govt. of India
Email: dn.joshi@nic.in

Copy for Information: PIJS to Sccrctary, LR/PS to AS(LR)/ PS to JS(LR)/I'S to JS&FA/Dircctor
(SB)/ DS(LR)/DS(IFD)/ Manager Gcospatial (MR)

)Y
