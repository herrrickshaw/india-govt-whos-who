---
doc_id: "72bf5a0fd10aede1"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/09/9e82a36f6c243d97a98edba08dda12d1.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Corrigendum to Mediation Act, 2023"
date: "2024-11-29"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "cfb39796eb75abf8"
---

<!-- page 1 -->

Sec. 1] THE GAZETTE OF INDIA EXTRAORDINARY 3
6. The amendments made to the Constitution by the Constitution (One Hundred and
Sixth Amendment) Act, 2023 shall not affect any representation in the House of the People,
the Legislative Assembly of a State or the Legislative Assembly of the National Capital
Territory of Delhi until the dissolution of the House of the People, the Legislative Assembly
of a State or the Legislative Assembly of the National Capital Territory of Delhi, as the case
may be, in existence at the commencement of the said Act.
DR. REETA VASISHTA,
Secretary to the Govt. of India.
CORRIGENDA
THE MEDIATION ACT, 2023
No. 32 or 2023
In the MEDIATION ACT, 2023 (32 OF 2023), as published in the Gazette of India,
Extraordinary, Part II, Section 1, dated the 15th September, 2023, Issue No. 35,—
(i) at page 17, line 46, for "section 26", read "section 25";
(ii) at page 18, line 8, for "sub-section (4)", read "sub-section (3)";
(iii) at page 18, line 10, for "sub-section (5)", read “sub-section (4)";
(iv) at page 18, line 12, for "clause (d)", read "clause (e)";
(v) at page 18, line 14, for "clause (i)", read "clause (j)";
(vi) at page 18, line 16, for "clause (m)", read “clause (n)";
(vii) at page 19, line 11, for "Service", read "Services";
(viii) at page 21, line 5, for "Cine-Workers", read "Cine-workers";
(ix) at page 21, line 9, for "Citizen", read "Citizens";
(x) at page 23, line 20, for "Legal", read "the Legal".
CORRIGENDUM
THE JAN VISHWAS (AMENDMENT OF PROVISIONS) ACT, 2023
No. 18 or 2023
In the JAN VISHWAS (AMENDMENT OF PROVISIONS) ACT, 2023 (18 of 2023),
as published in the Gazette of India, Extraordinary, Part II, Section 1, dated the
11th August, 2023, Issue No. 21, at page 48, lines 41 and 42, for 'a fine’, read ‘or a fine’.
UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI-110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI-110054.
Kshitiz Sea
MGIPMRND—388GI(S3)—29-09-2023. Mohan =
