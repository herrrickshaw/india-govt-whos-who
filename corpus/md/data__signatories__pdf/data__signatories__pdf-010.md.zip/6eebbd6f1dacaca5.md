---
doc_id: "6eebbd6f1dacaca5"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/48a2d8b927a6d5813223d3393e598d58.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of Unified License (Virtual Network Operator)/UL(VNO), bearing no. DS-11/470/2018-DS-III, dated 31-07- 2019 for Category ‘B’ ISP Authorization for Mumbai Service Area, granted to M/s Channel III Internet Pvt Ltd"
date: "2026-07-28"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1338a386686dd8e1"
---

<!-- page 1 -->

DS-11/470/2018-DS-III

I/3424654/2026

WITHOUT PREJUDICE
F. No. DS-11/470/2018-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
(Data Services Cell)
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 28-07-2026
To,
M/s Channel III Internet Private Limited
Address: No. 126, Hill Road, Off. Somnath Lane, Bandra (West),
Mumbai - 400050, Maharashtra.
Email Id: channeliii@hotmail.com

Subject:- Termination/Revocation/Cancellation of Uniﬁed License (Virtual
Network Operator)/UL(VNO), bearing no. DS-11/470/2018-DS-III, dated 31-072019 for Category ‘B’ ISP Authorization for Mumbai Service Area, granted
to M/s Channel III Internet Private Limited, in terms of clause 10.2 (i)
(Chapter-I of Part-I) of the said License Agreement.

Whereas, Department of Telecommunications, Government of India (“the
Licensor”) has granted a Uniﬁed License (Virtual Network Operator)/ UL(VNO)
bearing
no. DS-11/470/2018-DS-III, dated 31-07-2019 (“the License”) for
Category ‘B’ ISP Authorization for Mumbai Service Area to M/s Channel III
Internet Private Limited (“the Licensee”)
2.
WHEREAS, the LICENSEE is required to provide the services under the
terms and conditions of the License and instructions issued by the LICENSOR from
time to time.
3.
That for alleged violation of Conditions No. 18.2.1, 20.3, 20.5, 20.9, 21.2 &
21.3. under Chapter-III of Part-I of the License, a Show Cause Notice No. DS11/286/2023-DS-II, dated 04.05.2026 (“SCN”) was issued to the Licensee on the
address provided in the License. The aforesaid SCN was sent by way of speed
post bearing ID no. ED897748665IN as well as by an email on the registered email
ID(s) of the Licensee on 07.05.2026. The Licensee was also reminded regarding
the aforesaid SCN vide email dated 09.06.2026.

<!-- page 2 -->

DS-11/470/2018-DS-III

4.
That the aforementioned SCN was issued to the Licensee to submit its
reply, within 21 days, as to why the License granted to it should not be terminated,
in terms of the Condition No. 10.2(i) under Chapter-I of the Part-I of the License.
5.
That despite having given enough time and opportunity to the licensee to
show cause and explain the alleged violation of terms and conditions of the license
mentioned in the SCN, the licensee has failed to submit any reply whatsoever to
the licensor within the time frame allowed to the licensee.
6.
That the failure of the Licensee to submit any reply or explanation to alleged
violation of terms and conditions of the license mentioned in the SCN implies that
the Licensee has nothing to say in this regard and that the Licensee has failed to
comply with the conditions of the License and therefore, has violated the conditions
of the License as alleged in the SCN.
7.
Therefore, the competent Authority has now decided to terminate/ revoke/
cancel the Uniﬁed License (Virtual Network Operator)/UL(VNO), bearing no.
DS-11/470/2018-DS-III, dated 31-07-2019 for Category ‘B’ ISP Authorization for
Mumbai Service Area, granted to M/s Channel III Internet Private Limited, in
terms of clause 10.2 (i) under Chapter-I of Part-I of the License and that the said
license is terminated/ revoked/ cancelled w.e.f. 61 st calendar day from the date of
issue of this letter.
8.
That the Licensee is further directed to terminate and stop all
interconnections with all service providers eﬀective from the date of termination of
the License.
9.
That the Licensee is further directed to issue a notice of at least 30 calendar
days to all its customers within 30 days from today in terms of the condition 10.2(i)
(Chapter-I of Part-I) of the License Agreement reproduced as under:
“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order”.
10.
That the Licensee shall take note of the clause 11.2 (Chapter-I of Part-I) of
the License, which is reproduced as under:
“On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank
Guarantee(s) shall be released to the Licensee only after ensuring clearance of all
dues, which the Licensee is liable to pay to Licensor. In case of failure of the
Licensee to pay the amounts due to the Licensor, the outstanding amounts shall be
realized through encashment of the Bank Guarantees without prejudice to any
other action(s) for recovery of the amounts due to the Licensor without any further
communication to the Licensee”.
11.
That the Licensee shall also take note that in case, it comes to the notice of
the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.
12.
That the Bank Guarantee(s) submitted by the Licensee against the said
license will be released in terms of clause 11.2 under Chapter-I of Part-I of the

I/3424654/2026

<!-- page 3 -->

DS-11/470/2018-DS-III

I/3424654/2026

License after ensuring clearance of dues, including dues/ penalty arising, if any, as
a consequence of the aforesaid violation.
13.

That the Licensee may acknowledge the receipt.

Director (DS-II)
Email: dirds2-dot@nic.in
jto1ds2-dot@gov.in

Copy to: 1. DG Telecom, DoT, New Delhi, with a request to instruct the concerned
LSA(s) to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any “telecom resources” to/from M/s Channel
III Internet Private Limited.
2. Additional DGT, Mumbai LSA, DoT.
3. Sr. Joint CGCA(Revenue), O/o CGCA, DoT with a request to release the
Bank Guarantees of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of Data Service Cell is concerned, the same will be intimated to O/o
CGCA in due course of time.
4. Secretary, TRAI.
5. Wireless Advisor, for issue of Dues/No Dues Certiﬁcate till the eﬀective date
of termination of License and convey to office of CGCA.
6. Dy. CCA, O/o Pr CCA, Mumbai Circle, DoT.
7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/
DDG(WPF), DoT HQ.

8. Director (IT), DOT HQ for uploading this order on DoT website for information
to all Service Providers.
9. File No.: DS-11/470/2018-DS-III
