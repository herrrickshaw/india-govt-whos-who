---
doc_id: "6fdf03f07cadf15b"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/6b4dfd5b2cecebdb7079a8fe86209bb0.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Engagement of two Asst. SGIs for High Court of Calcutta (PB) at Kolkata: Order dated 13.01.2022"
date: "2022-01-17"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "211ae41891aebe61"
---

<!-- page 1 -->

F. No J-1 10141512020-Judicial
Government of lndia
I\Iinistry of Law & Justice
Department of Legal Affairs
(Judicial Section)

Shastri Bhawan, New Delhi,
Dated 13th Janua ry, 2022

ORDER
The President is pleased to engage following two Advocates as Assistant
Solicitors General of lndia for the High Court of Calcutta (PB) at Kolkata, as
shown in the table below, for a period of three years with effect from the date of
this order or until further orders, whichever is earlier:
Hiqh Court of Calcutta (PB) At Kolkata

Assistant Solicitors General of lndia
st.
No
1

Name of
Advocate (S/Shri)

Contact details

Enrollment No

Dhiraj Kumar
Trivedi

Res: "Trivedi Bhawan", 25A,
Ch ittaranjan Avenue, Kolkata700001, West Bengal
Off: 1B, Old Post Office Street, 1't
Floor, Kolkata-700001, West
Bengal
tMob: 9831128150
Email: dhirajtrivedi@gmail com

wB/1063/1998

Res.& Chamber: 1, Hara Prasad
Shastri Sarani, New Alipore,
Block-B, Kolkata-700053
lVlob: 9831011379
Email: billwadal@gmail.com

wB/1 021t2004

(Dhiraj Trivedi)

2

Billwadal
Bhattacharyya

3.

The engagement and professional fee of the aforesaid advocates will be
governed by the terms and conditions contained in this Department's OM No.
26(1)/99-Judl. dated 24.09.1999 read with OM No. 26(1)12014lJudl. dated
01.10.2015 & instructions issued subsequently through OlVs. The aforesaid OMs
are available on the website of this Department i.e. www.legalaffairs.qov.in inside
the tab 'Judicial Section' under heading 'Circulars pertaining to litigations'.

4.

Hindi version of this order will follow

d

(R K Srivastava)
Joint Secretary& Legal Adviser

I
.112-

tj

DI

B--rnngtrn

<!-- page 2 -->

F, No. J-1 1014/5/2020-Judicial

Dated: 13.01.2022

Copy to:-

1. PS to IvlL&J/PS to I\/SLJ/PS to Law Secretary/Ps to Legislative Secretary/All Additional
Secretaries/Ps to all JS&LA in the Main Sectt.

2. PS to Attorney General of lndia/Ps to Solicitor ceneral of lndia/Ps to all Addl. Solicitors
General of lndia.

3. All Assistant Solicitors General of lndia in various High Courts.
4. The Registrar, High Court of Calcutta (PB) at Kolkata.
5. The lncharge, Branch Secretariat at Kolkata.

6. Both the Asst. SGls figuring in the table under para 1 above with request to send their Bank
Account details etc. to Cash (LA) Section in this Department for the purpose of payment of
monthly retainership fee.

7. The Cash (LA) Section, w. r. t. payment of retainership fee to two Asst. SGls figuring in the
table under para 1 above w.e.f. the date of this order.
8. The Pay & Account Office, Department of Legal Affairs, New Delhi.
9. Hindi unit, Department of Legal Affairs for Hindi translation of the order.
10. To be uploaded on website of this Department i.e
Section'.
1 1. Office/spare copies.

le

laffa irs

H

ov. in under tab'Judicial

(1. C. Dabaria)

Assistant Legal Adviser (Judicial)
Tel. 01'1-23384831
Email: judaclal-dla@nic.in
