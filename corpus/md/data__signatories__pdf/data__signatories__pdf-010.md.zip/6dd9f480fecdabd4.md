---
doc_id: "6dd9f480fecdabd4"
source_url: "https://www.mea.gov.in/images/pdf/Vacancy_Circular_31_August_2017.pdf"
ministry: "External Affairs (MEA)"
title: "Vacancy circular for Filling up of post of Section Officer (SO) and Assistant Section Officer (ASO) In the Ministry of External Affairs on deputation"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "6810f92c9eabb025"
---

<!-- page 1 -->

/ 1/ ५
No. Q/PF/586/2/2017
Government of India
Ministry of External Affairs
(Administration Division)
Jawaharlal Nehru Bhawan, Janpath,
New Delhi, the 31° August, 2017
Office Memorandum
Subject: Filling up of post of Section Officer (SO) and Assistant Section
Officer (ASO) in the Ministry of External Affairs on deputation — reg.
The Ministry of External Affairs requires the services of qualified
Sr. AOs/AOs/AAOs and Sr. Accountants/Sr. Auditors, who have experience in finance,
budget, project management and monitoring of Government projects, at Section Officer
and Assistant Section Officer levels respectively.

. 2. In order to fill these posts, it is proposed to engage suitably qualified officers on
deputation basis as per the standard DoP&T guidelines. Applications are sought from
the officers of Sr. AO/AO/AAO level for the post of Section Officer (in the Level-10 of
Pay Matrix) and from the officials of Sr. Accountant/Sr. Auditor level for the post of
Assistant Section Officer (in the Level-7 of Pay Matrix) with specialisation in the above-

| mentioned areas. The duties involve examination and processing of financial proposals,

| monitoring financial evaluation and accounting of Government of India projects,
consultancy agreements, and procurements training courses etc. Detailed QRs relating
to the assignment is enclosed.

है 3. It is requested that this circular may be given wide publicity among staff and may
also be circulated among Subordinate/Attached offices. Interested officers may be
instructed to apply by 6™ October, 2017 as per the pro-forma enclosed with the QRs.

=
नए पट 7
(S. D. Moorthy)
Deputy Secretary (PF & PG)
Tel: 49015360
Copy to:
1) Office of C&AG, New Delhi. है
2) Office of CGA, New Delhi.
3) All Ministries/Departments of Central Government. All Ministries/Departments
are requested to circulate the vacancies to Attached/Subordinate Offices as well.
4) All Notice Boards in the Ministry of External Affairs.
5) US(XP), MEA — with the request to upload the circular on Ministry's website.

<!-- page 2 -->

; Aly
MINISTRY OF EXTERNAL AFFAIRS,
Jawaharlal Nehru Bhawan, Janpath, New Delhi — 110 001
Applications in the prescribed proforma (as per Annexure-A of the advertisement) are
invited from suitable and eligible candidates for filling up of posts of Section Officer on
pier in 8 ——— Affairs , New Delhi as per details given below:-
1. | Name of the Post | : | Section Officer
2. | No. of Posts : | 02 (Two) _
3. | Qualification : | Graduation
4. rh in the Pay |: | Level-10 of Pay Matrix
Matrix
5. | Period of : | The Period of deputation is initially for three years.
Deputation He the period may be extended or curtailed on
performance basis, functional requirements and relevant
- a uidelines.
6. — :| a) Officers holding posts of Sr. AO/AO/AAO or analogous post
Requirements for at least three years; Sr. Auditor/Sr. Accountant/or
analogous post for at least five years.
b) Officers should be conversant with Govt. of India financial
| rules such as General Financial Rules (GFR), Delegation of
Financial Power Rules (DFPR), Govt. Accounting Rules
| | हु | (GAR), CPWD Manual, CPWD Accounts Code, processes |
telated to incurring expenditure out of allocations such as |
securing regulatory approvals, issue of sanctions etc till
| | final booking thereof, and related instructions issued by
Ministry of Finance from time to ote el oe co
| | He Officers should have working knowledge of computer
| ____ operations, particularly MS Excel and MS Word.
| 7. | Work Experience : | ¢ Financial evaluation and accounting of Government of India
| (at least three | projects, consultancy agreements, procurements training
| years in any or all courses etc.
| the areas is} | © Settlement of Running Account bills and other claims of
| desirable) project implementing agencies from time to time.
| ¢ Scrutiny and evaluation of Tender Documents,
| Memorandum of Understanding, Agreements/Contracts to
| | be signed with implementing agencies.
¢ Evaluation of Financial/Service Regulations of
| | | डे
| | | ¢ Formulation of Budget of Ministries/Departments.
¢ Audit of Ministries/Departments
| | Le Handling Parliamentary matters, especially those with
8 (How financial implications.
8. | How to apply : | Completed application should be sent to Shri_S. D. Moorthy,
| Deputy Secretary (PF & PG), Ministry of External Affairs, Secretary (PF_& PG), Ministry of External Affairs
Room Room No. 4071, Jawaharlal Nehru Bhawan, Janpath, New 4071, Jawaharlal Nehru Bhawan, Janpath, New
| | Delhi-110001_ Phone Dethi-110001_Phone_ No. 011-49015367_in the prescribed
proforma (Annexure A) alongwith up-to-date attested copies of
APARs for the last three years and Vigilance Clearance
| Certificate, Integrity Certificate, Statement of Major/Minor
Penalty, if any, imposed on the officer during the last 10 years
| || (or as the case may be) of the officers from the present
| a employer,

<!-- page 3 -->

|
21५
MINISTRY OF EXTERNAL AFFAIRS
Jawaharlal Nehru Bhawan, Janpath, New Delhi — 110 001
Applications in the prescribed proforma (as per Annexure-A of the advertisement) are invited from
suitable and eligible candidates for filling up of posts of Assistant Section Officer on deputation basis in the
Ministry of External Affairs, New Delhi as per details given below:
(1. Name of Post :_| Assistant Section Officer
2. _| No. of Posts |_:_| 05 (Five)
| 3. | Qualification |: | Graduation
|4. |Level in. the Pay [| Level-7 of Pay Matrix
Matrix _
| 5. Period of Deputation | : | The period of deputation is initially for three years.
| However, the period may be extended or curtailed on performance basis,
L | functional requirements and relevant DoP&T guidelines.
6. Eligibility/Essential : | a) Officials holding posts of Sr. Auditor/Sr. Accountant or analogous post
| Requirements for at least two years.
OR
| Successful completion of training in the Cash and Accounts Work in
| the Institute of Secretariat Training and Management (ISTM) or
equivalent and a minimum of two years’ experience in Cash,
| Accounts and Budget Work.
| b) Officers should be conversant with Government of India financial rules
such as General Financial Rules (GFR), Delegation of Financial
| Powers Rules (DFPR), Government Accounting Rules (GAR), CPWD
Manual, CPWD Accounts Code, processes related to incurring |
ee out of allocations such as securing regulatory approvals,
: | issue of sanctions etc. till final booking thereof, and related
| instructions issued by Ministry of Finance from time to time;
c) Officer should be fully conversant with the TDS system of the IT
Department as applicable to Government Departments.
| | d) Officers should have working knowledge of computer Operations,
| fi MS Excel and MS Word.
|7 Work _. (at) : | Applicants would have the following broad responsibilities, among others
| least two years in ¢ Examination and Processing of Financial Proposals
any or all the areas ¢ Formulation of Budget
is desirable) * Audit procedures and reports
| | ¢ Financial evaluation and accounting of Government of India projects,
| consultancy agreements, procurements training courses etc.
| | ¢ Scrutiny and evaluation of Tender Documents, Memorandum of
| Understanding, Agreements/Contracts to be signed with
| implementing agencies.
| ¢ Evaluation of Financial/Service Regulations of Institutions/agencies.
¢ Handling Parliamentary matters, especially those with financial
implications
¢ General work of administrative/financial nature
| It may be noted that the above duties may involve short travels outside of
|_| 4 country for brief durations. Accordingly, only those officers who are
है हि Open to travelling abroad occasionally need apply. __
8. | How to apply : | Completed application should be sent to Shri_S._D. Moorthy,
| Deputy Secretary (PF & PG), Ministry of External Affairs, Room No.
4071, Jawaharlal Nehru Bhawan, Janpath, New Delhi — 110 001,
Phone No. 011-49015367 in the prescribed proforma (Annexure-A)
| | alongwith up-to-date attested copies of APARs for the last two years and
| Vigilance Clearance Certificate, Integrity Certificate, Statement of
| Major/Minor Penalty, if any, imposed on the officer during the last 10 (or
| हा _ as the case may be) years of the officials from the present employer.

<!-- page 4 -->

44
. Annexure A !
APPLICATION PROFORMA FOR THE POST OF SECTION OFFICER AND
ASSISTANT SECTION OFFICER (ON DEPUTATION)
1. Name & Designation : है Paste your
passport size
2. Post applied for : photo here
3. Date of Birth $
4. Gender: Male/Female :
5. Date of Retirement :
6. Educational Qualifications:
7. Mobile No. & e-mailID :
8. Details of employment in the chronological order. Enclose a separate sheet duly authenticated
by the Department, if space below is insufficient.
ere Postheld [From [To | Scale of Pay] Nature of duties
Office/Institution/ and basic pay | performed
| Organization - therein
9. Nature of present employment : Temporary / Permanent
10... Basic pay, Level of Pay Matrix :
11. Additional information, if any, which you would like to mention in support of your
suitability for the post. Enclose a separate sheet, if the space is insufficient.
12. Whether belongs to SC/ST/OBC/Physically handicapped:
13. Remarks
(Signature of the candidate)
Address:
Date:

It is certified that particulars furnished are correct and no disciplinary case is either
pending or contemplated against the officer and no penalty, major or minor, was imposed on the
officer during the last 5 years and his integrity is beyond doubt.

Signature of the Head of Department
(With Stamp)
