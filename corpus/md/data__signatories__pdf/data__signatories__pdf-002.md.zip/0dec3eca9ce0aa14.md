---
doc_id: "0dec3eca9ce0aa14"
source_url: "https://dsel-education.gov.in/static/uploads/2025/09/94b3426c41dc2a45dd0e0c50d09213df.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "Minutes of the Meeting on the Right of Children to Free and Compulsory Education Act, 2009 held on 14th August, 2010"
date: "2010-08-14"
pages: 14
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "dc92748e2a5c37ab"
---

<!-- page 1 -->

™~
Minutes of the Meoting on the Right of Children to Free and Compulsory
द Education Act, 2009 held on 14" August, 2010

The Ministry of Human Resource Development convened a meeting on

14" August 2010 with cross section of stakeholders, comprising educationists

and academics, principals of schools, as weil as representatives of civil society

organizations and non government organizations to elicit suggestions on the

implementation of the provisions of the Right of Children to Free and

Compulsory Education (RTE) Act, 2009. A list of participants is attached at
Annexure 1

Smt D Purandeswari, Minister of State for Human Resource
Development extended 3 warm weicome to the participants, and stated that the
RTE Act was a historic Jegisiation, giving children in the 6-14 age group the right
to free and compulsory education, The RTE Act is a consequential legislation to
Article 21A of the Constitution, and would enabie all chikiren, especially children
belonging to disadvantaged groups and weaker sections to access and complete
elementary education of good quality. This consultation was organised with 2
view to dispelling doubts and apprehensions about its implementation She
stated that (t lc indeed important for all stakeholders to come together to ensure
ecucation of squitebie quality for children from disadvantaged groups anc
weaker sections. She stated that India is committed to the global goal of
Education for All. Indie’s commitment was reaffirmed in the Jomtien (1996) and
Dakar (2000) Conference indie’s ability to use knowledge will, uttimately. decide
its position im the comity of nations The RTE Act casts @ responsibility on the
Central Government, State Governmants and local authorities to provide free anc
compuissty elementary education to all children in an inclusive and child-friendly
schoo! environment To accompiish the objectives of the Act. the participation
and contribution of all stakeholders. including aided and unaided schools anc the
toca! community t& critical.

Shr Kapil Sibal, Minister of Human Resource Development also
welnomed the participants. and stated that the purpose of the meeting was to
elicit views/oninion of all the stakeholders on certain specific issues relating to
the inipiementation of the RTE Act — applicability of the RTE Act on minority
educationa! institutions, screening procedure for admission in schools, proof of
residence for schoo! admission, and recognition of schools under the Act With
this. Minister of Human Resource Development took up the issues for discussion:

1

<!-- page 2 -->

1.
Sh. Neil O'Brien, Chairman, Chairman, Council for the Indian School
Certificate Examination, stated that the RTE Act is a very welcome step
forward, but needed certain clarifications. He staled that the word ‘minority is not
mentioned anywhere in the Act, and expressed concem on the applicability of the
provisions of sections 21 and 22 of the Act to Minority schools. He stated that
Minority schools should be exempted from the provisions of sactions 21 and 22.
Dr, Kancha Iiliah, Osmania University, stated that the RTE Act may raise
Soubts regarding the functioning of Madarsas, and suggested that the Ministry
of HRD may over 2 period of time work towards providing them a recognized
curriculum and syllabus along with religious education.
Shri Inamdar suggested that aided minority schools should be kept outside the
ambit of section 21 and 22 of the RTE Act.
Ms. Amoeta Multa Wattal, Principal, Springdales School, Pusa Road. stated
that the fundamental issue was quality of public education: private education is
available even for the minority community
Or Abusaieah Shariff, Member-Secretary, Sachar Commitee stated that
people wan! education of their choice for their childran, and referred to tne
growing aspwations of people for education in private schools He further siated
that according tc the Sachar Committees Report. less than 3% Muslim children go
to Madarsas. in Keraiz, children attend Madarsas as also reguiar schools. in
other States, like UP and Bihar, however children attend only Madarsas He
Suggested that Gol snould recognise Madarsas as reguiar schools, and create
an equivalence level, which takes into account culture and language issues. He
Stated tha! 99% Musiim children are going to regular schools, anc! their education
if Not & problem, therefore Madarsas which cater to @ very small percentage of
children should not be viewed as a probiem
Prof. Furgan Qamar, Vice Chancellor, Central University, Himachal
Pradesh, stated that people are happy about the intent and objectives of the
RTE Act The number of chikiren in Madarsas is not very large, but these should
not be seen as children who are not attending school, and parents sending
children to Madarsas should not be perceived as not performing their duty
Stipulated in section 10 of the RTE Act He also suggested a systern of
equivalence between the curricula in Madarsas with that provided under section

<!-- page 3 -->

29 of the Act. He suggested that there should be a separate Board, on the lines
of ICSE Board With regard to recognition of schools, he stated that a large
cumber of schools run by Minority Institutions may not meet the norms and
standards specified in the Schedule of the RTE Act, and therefore there are
apprehensions about the recognition process. He also stated that bringing
Musiims into mainstream institutions is very important, and suggested that
‘neighborhood’ school should be seen from the viewpoint of the minority
community, and schools should be set up in predominantly Minority areas.
Minister of Human Resource Development clarified that:

(a) The Government has introduced a Bill in the Parliament to amend the RTE
Act, in'which it has been proposed that the SMC constituted u/s 21 in
respect of aided minority institutions would function in an advisory
capacity, and that the SMCs of such schools would not be required to
prepare a School Development Plan u/s 22 of the Act;

(0) Madarsas impart religious education. There is no intention of interfering in
this process of religious instruction.

(9) # large number of children go to other schools — minority of otherwine:
these schools must conform to the norms and standards specified in the
RTE Act. The Act provides = 3-year window for institutions to conform to
the norme and standards. anc « 5-year window to ansure that al! teachers
scquire the prescribed minimurn qualifications

Sh. Pramod Mahajan, Secretary, DAV Trust sought clarification as to whether
the ‘no screening’ clause is applicable only to the 25% children from
disadvantaged groups and weaker sections, or aiso to the remaining 75%, The
Minister of Human Resource Development clanfied that the provisions of section
13 (1) of the RTE Act is applicable for all admissions. Shri Mahajan stated that in
such a situation the schools would not be able to extend admission to children of
their teaching and non teaching staff, alumni, etc He stated that random
selection will not work.

Ms Ameota Mulla Wittal stated that private schools in Delhi were following the
admission procedure in accordance with the directions of the Deini High Court. In
respect of admissions under EWS quota, the schools were following the lottery

2

<!-- page 4 -->

system for EWS. in respect of general students, she-atated that a point system is
being followed, under which points are allotted to each applicant on basis of pre-
determined norms, encompassing neighborhood, alumni, sibling, girl child, child
of single parent, etc She stated that extending the lottery system for ail
admissions may become administratively infeasible She stated that the present
admission system was open and transparent, and should be allowed to continue.
Shri Ashok Pratap Singh, Chairman, Modern School, stated that schools vary
in terms of their philosophy and objectives. The concept of screening has to seen
from the viewpoint of their philosophy. In Modern School, he stated, an effort is
made to ensure that there is no discrimination He stated that ‘screening’ per se
's not bad, and that random selection is not feasible. He added screening is a
dynamic, not a static, concept, and that fact has to be appreciated institution by
institution. He further clarified that Modern School lays down a criteria of 20%
admission for children of alumni, 20% for siblings, as also weightages for gender,
Sister Cyril, Principal, Loreto School, Kolkata stated that for 30% Loreto,
Kolkatta has taken children on the basis of a lottery system, and 50% children
beiong to disadvantaged groups and weaker sactions. In 30 years, she stated,
there hes not beer 2 single failure She stated if is important to admit children
from disadvantaged groups and weaker sections. Loreto Schoo! nas 2 status of a
minority institution, with @ quota for Catholic children, but the number of Minority
instiutions far exceeds the number of minority chikiran in the country. She stated
that screening should De prohibited at all jevels of education, She adced that हि
Schools that cater to only children from weil of backgrounds desarve only 10
Percen| credit for the success of their puplis. Or, the other hand, schools catering
to children from disadvantaged backgrounds deserve 90 percent credit for the
Success of their pupils as they receive iittie heip at home
Minister of Human Resource Development explained that the objective of the
Provisions of section 13(1) is to ensure that admission procedure is non-
discriminatory and transparent and to disaliow schools from profiling children and
their parents on the basis of ability Admission tests and interviews are generally
@ too! for eliminating children
Ms, Manju Bharat Ram, Chairperson, Shri Ram Schools stated that in Delhi,
the schoois while following the High Court order have laid out a procedure which
is transparent and rational and that should be allowed to continue. She stated
7

<!-- page 5 -->

that the critena followed takes into account the needs of ‘single parent, special

needs children, area and neighbourhood, etc.

Ms. Shyama Chona, former Principal, OPS, RK Puram mentioned thet in Delhi
NCT, every schools is required to prepare a 100 point formula, in accordance
with the recommendations of the Ganguly Committee, and approval of the
Directorate of Education, Government of Delhi. She was of the view that this -
System should be allowed fo continue, as it is rational and transparent.

Prof. Krishna Kumar, CIE, University of Delhi drew attention to the spirit of
RTE Act. which aims at free and compulsory elementary education as a
fundamental right for all children in the country. He said that laws evolve when
they begin to be implemented. The RTE Act should be allowed to function for a
couple of years, before decisions are taken to change its provisions. Screening,
which provides for selection of ‘good’ children on parameters, which are rarely
acknowledged in the school prospectuses, is a social Darwinist philosophy. In :
academic circles there has been a jong struggle against this philosophy He
Stated that the very thought that ‘some’ schools ‘deserve’ children who are
perceived to be more able than others is flawed. The RTE law gives us an
Opportunity to ensure that schools, principals and teachers reflect on the
‘homogeneity’ of thair clientele He referred to Jerome Sruner and Montessori
and stated that school principals and teachers mus! understand that classroom
Processes become richer if the class has children trom varying backgrounds and
acilies ft is an academically astablished pomt that heterogeneity in the
Siassraom jeads. to greater creativity Every child has enormous potential. He
further stated that many private schools are providing good service, but these are
scarce, and few and far between. ‘Scarcity’ has consequently got associated with
‘Quality and the average parent has begun to feel that the more difficult it is to
g@ admission the greater the quality of that school. He emphasized the need for
moving towards composite classrooms with students from diverse backgrounds
rather than homogenous anc exciusivist schools, and argued that heterogeneous
classrooms are the greatest challenge for the teacher as they help in creating
better iearning environment. Screening to assess @ child's ‘intelligence’ should be
prohibited. The idea of ‘categories’ and the admission of children in accordance
with predetermined categories through random selection may be explored
further,
Prof. Marmar Mukhopadhyay, former Director. NUEPA stated that the issue of
Screening is altogether an urban centric issue and desis with a very small
percentage of children studying in schools actoss the country He stated that

5

<!-- page 6 -->

Kendriya Vidyalays have no admission tests and still they are doing so weil
Other schools could follow the same. Screening, especially on the basis of caste
Should be sfopped. He suggested that the RTE Act should not be amended for
the next 2 —3 years
Shri Steven De Costa, Principal Frank Anthony School said that his schoo! is
accredited to ICSE and is committed ensuring that siblings get admission. Under
these circumstances, it may become difficult for the school to give 25%
admission to children from the neighbourhood. He also mentioned that there
were 9 schoois in close proximity which was making it difficult for the school to fil!
even its existing free-ship seats
Dr. Kancha Illiah stated that schools having a positive discrimination policy in
matters of admission should be accepted under the RTE Act For example,
schools in tribal areas, catering largely to tribal populations, should continue to
Cater to such children.
Prof Anita Rampal, Faculty of Education, University of Delhi stated that
categories should be rationa! and non-discriminatory, and should not be on the
basis of educational qualification of parents. Based on such pre-determined
norms, admission should be through randomized selection within the categories,
anc shoulc be made under = transparent procedure
Shri Veeraghavan President. Sharat Vidys Bhawan stated that provision for
CWSN should aiso be made in admissions
Major Genera! (retd.) Kanwar Singh Malhotre, Principal Mayo Coliege
PoInted Out that the resisential schoo! takes admissions at classes 4, 5 and 7 and
the child's ability to cope in 2 residential environment in school is necessary. In
his schooj mterviews are heic im order to assess the capability and confidance of
the child to cope in @ residential environment. Hence some screening becomes
essential
Shri Praveen Vashishtha, Lawrence School, Sanawar stated that his school
makes admissions at class 5 and 7. by which time children have had some
experience and consequently ‘background’ comes into play. He also raised the
issue of admission of children from neighborhood in residential schools.
6

<!-- page 7 -->

Shri Manoj Singh, Commissioner NVS informed that NVS, besides being
residential schools, is also mandated to admit talented children through an
entrance test. However, the NVS has been served a notice by the NCPCR for
Conducting admission tests which is not in conformity with the provisions of
section 13 (1) of the RTE Act Minister of Human Resource Development
Stated that the Ministry woukd be addressing this issue separately
Concluding, the Minister of Human Resource Development stated that the
consensus of the House was that each school may formulate a policy under
which admissions are to take place The policy must include categorization in
terms of objectives of the school, including provision for positive discrimination
ang affirmative action on a rational, reasonable and just basis. This policy should
be placed in the public domain, given wide publicity and explicitly stated in the
school prospectus. There should be no testing and interviews for any child/parent
falling within or outside the categories, and selections would be on a random
basis. He stated that based on this understanding the Ministry would take further
appropnate action
3 Proof of Residence
Sister Cyril, Principal stated that street children do not have any resiience tnd
hence cannot produce any proof of residence. She aiso stated that there are jot:
of children migrating from Binar. Jharkhand etc. to Kolkate and it is not possible
tc obtain proof of residence in these cases in many cases these children stay
only tors period of si months
Minister of Human Resource Deveiopment stated that if Ration Card is
available that shoul be accepted as proof of residence. In other cases the
cencemed schoo! should decide about in case the Ration Card is not available
Shri G.P. Chopra, President, DAV Coliege Management Committee stated
that there are afternoon schools and those schools are not insisting for any proot
of residence
Secretary (SE&L) stated that as per the Act inclusive education should be
Provided to all children and if there is any afternoon school it has to function as
an inclusive school conforming to the provisions of the Act Representative from
the Dethi Govt. stated that affidavit by parent regarding address proof may be
treated as proof of residence.
>

<!-- page 8 -->

The Minister of Human Resource Development stated that the Ministry would
issue appropriate guidelines in this regard,
4 Recognition of Schools
Minister of Human Resource Development stated that he has received
representations from various Private unaided schools expressing apprehension
regarding the procedure for recognition of schools under the RTE Act. Col. Arun
Datta, Principal, Sainik School, Karnal stated that the schools which have
already been granted recognition should be deemed to be recognized under the
RTE Act and should not be required to undergo a fresh process for recognition.
This viewpoint was also reiterated by Shri Praveen Vashisht. Dr Shyama -
Chona stated that the Directorate of Education, Govt. of NCT of Delhi is now
asking for fresh recognition till class VIII.
Ms. Manju Bharat Ram stated that even the govemment schools should be
asked to undergo the process of recognition as several schools run by the
Government do not adhere to the norms and standards laid down in RTE.
Minister of Human Resource Development clarified that. under the RTE Act
AS schools, including Government schools are required to adhere to the norms
and standards specified in the Schedule -
Prof Anita Rampal stated that there may be several schools which do not mest
the norms and standards specified in the Schedule However, the Act prowdes a
3 year window to provide the infrastructural facilities and 8 5 year window to
provide trainec teachers She expressed the view tha! even if the schoo! has
been running for several years, it would not mean that # adheres to the norms
under the Act
Minister of Human Resource Development stated that schools which nave
been running before the commencement of the Act and have been sariier
granted recognition by the Stats Government must file an affidavit to the effect
that they are jn alignment with the provisions of the Act. There should be no need
{0 put in place an inspection system which would lead to an ‘inspector raj’ for
existing schools. Only where it comes to the notice that the schools are not in
alignment with the provisions of the Act should a mechanism of verification or
authentication be put in place. He felt that the Government should facilitate the
process of recognition in @ smooth manner.
8

<!-- page 9 -->

5 Other issues

The following additional issues were flagged for further discirssiot:

i Financial viability of reimbursement for admission of 25% quota under
section 12(1) (c).

i Special provision for children with disabilities

i, Schools affiliated to International Boards

lv. Curriculum of schools in different States affiliated to the CBSE vis-a-vis
the provisions of section 29 of the RTE Act read with the definition of
appropriate Government in section 2(a) of the RTE Act.

¥. _ Issues with regard to residential schools and defining neighbourhood for
such schools.

°

<!-- page 10 -->

ANNEXURE |
हे LIST OF PARTICIPANTS
1 Shri Kapil Sibal, Minister of Human Resource Development.
2... Smt D.Punsndeswari, Minister of State for Human Resource Development.
3 Smt Anshu Vaish, Secretary, Department of School Education and Literacy.
4. Smt Anita Kaul. Additional Secretary, Department of Schoo] Education and
Literacy.
is Shri S.C. Khuntia, Joint Secretary . Department of Schoo! Education and Literacy.
6. Sti A.K. Singh, Joint Secretary , Department of School Education and Literacy.
7. Prof Krishan Kumar, Education Department. University of Delhi.
8 Ms Ameeta Mulia Wattl
Principal. Springdales School
0 Ms. Law Vaktyanathan
Principal. Modern School
\ है 10... Padma Shri Sister M. Cyril Mooney’
i Prmeipal. Lorem Day Schoo! Seniduh.
Ni Ms. Manje Bharat Ram
Chairperson, The Shri Ram 546
12 Shn BS Yadav
Delhi Public School. Jodhpur
13, Prof. Furgan Qumar
Vice Chancelior, Central University of Himachal Pradesh
14 Dr. Abusaleh Shariff
| Ministry of Home A fiairs, Government of India
15. Shri MP. Vijay Kumar
Former Project Director. SSA. Tami) Nadu.
10
