---
doc_id: "0f6b0acb0a6de5b8"
source_url: "https://dohe-education.gov.in/static/uploads/2025/12/ed748c7f1e53b85a88a10174d10fb469.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Mid-Day Meal Rules, 2015 Under National Food Security Act, 2013 Notified"
date: "2015-10-01"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5d10d1f33fa6572f"
---

<!-- page 1 -->

“8”
pib.nic.in
PRESS INFORMATION BUREAU
GOVERNMENT OF INDIA
***
MID-DAY MEAL RULES, 2015 UNDER NATIONAL FOOD SECURITY ACT, 2013
NOTIFIED
New Delhi, October 01st, 2015
The Central Government notified ‘Mid Day Meal Rules, 2015’ on September 30th, 2015. The National
Food Security Act, 2013 (NFSA, 2013) contains provisions related to welfare schemes including Mid
Day Meal Scheme. In accordance with the provisions of the Act, the Ministry of HRD has finalized
the MDM Rules after consultation with the States and other related Central Ministries. The rules will
be known as Mid Day Meal Rules, 2015 and will be in effect from the date of notification in the
Gazette of India. The Rules inter alia provide for temporary utilization of other funds available with
the school for MDM in case school exhausts MDM funds for any reason; Food Security Allowance to
be paid to beneficiaries in case of non-supply of meals for specified reasons; and monthly testing of
meals on a random basis by accredited Labs to check its quality. Further, the Rules also provide that
concerned State Governments shall fix responsibility on the person or agency if meals are not provided
on 3 consecutive school days or 5 days in a month. These rules and their effective compliance by
implementing agencies in the States will ensure better regularity in serving mid day meals in schools
and also improve quality of the meals as well as overall implementation of the Mid Day Meal Scheme
in the country. The salient provisions of the rules are as under:


Entitlements of children: Every child within the age group of six to fourteen years studying in
classes I to VIII who enroll and attend the school, shall be provided hot cooked meal having
nutritional standards of 450 calories and 12 gm of protein for primary and 700 calories and 20
gm protein for upper primary free of charge every day except on school holidays. The place of
serving meals to the children shall be school only.



Implementation of the Scheme: Every school shall have the facility for cooking meal in
hygienic manner. Schools in urban area may use the facility of centralised kitchens for cooking
meals wherever required in accordance with the guidelines issued by the Central Government
and the meal shall be served to children at respective school only.



Responsibility of School Management Committee: The School Management Committee
mandated under Right to Free and Compulsory Education Act, 2009 shall also monitor
implementation of the Mid-day meal Scheme and shall oversee quality of meals provided to the
children, cleanliness of the place of cooking and maintenance of hygiene in implementation of
mid day meal scheme.

<!-- page 2 -->



Utilization of School Funds: The Headmaster or Headmistress

of the school shall be

empowered to utilise any fund available in school for the purpose of continuation of Mid Day
Meal Scheme in the school in case of temporary unavailability of food grains, cooking cost etc.
in the school. The utilised fund shall be reimbursed to the school account immediately after
receipt of mid day meal funds.


Testing of the meals by Accredited Labs to ensure nutritional standards: Hot cooked meal
provided to children shall be evaluated and certified by the Government Food Research
Laboratory or any laboratory accredited or recognized by law, so as to ensure that the meal
meets with the nutritional standards and quality.



The Food and Drugs Administration Department of the State may collect samples to ensure the
nutritive value and quality of the meals. The samples shall be collected at least once in a month
from randomly selected schools or centralised kitchens and sent for examination to the
accredited laboratories.



Food Security Allowance. - If the Mid-Day Meal is not provided in school on any school day
due to non-availability of food grains, cooking cost, fuel or absence of cook-cum-helper or any
other reason, the State Government shall pay food security allowance by 15th of the succeeding
month in the manner provided herein below:(a)

Quantity of Food grains as per entitlement of the child; and

(b)

Cooking cost prevailing in the State.
 In case of non-supply of meal by the Centralised Kitchen, the Food Security Allowance
shall be realised from the Centralised Kitchen as stated above.
 Provided that in case a child has not taken food on offer for whatever reasons, no claim
of food security allowance shall lie with the State Government or Centralised Kitchens:
 Provided further that no claim shall lie with State Government or Centralised Kitchen
for reasons of quality of food grains and meal:
 The State Government shall take action to fix responsibility on the person or agency in
accordance with the procedure laid down, if mid day meal is not provided in school on
school days continuously for three days or at least for five days in a month.
 Wherever an agency of Central Government is involved, the State Government shall
take up the matter with Central Government which shall resolve the matter within a
month.
******

GG/RT/DS/RK/MDM
