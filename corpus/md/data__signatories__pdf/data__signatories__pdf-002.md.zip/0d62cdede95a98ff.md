---
doc_id: "0d62cdede95a98ff"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/bdb1aa603d38c0d104b5b68de55eeb44.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Important policy decisions taken and activities/initiatives during July, 2016"
date: "2016-07-31"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0c1ebdeae59822b6"
---

<!-- page 1 -->

Important policy decisions and activities /initiatives
during the month of July 2016
( Department of shod Alucation and Mba)

06) 23" Joint Review Mission (JRM) of Serva Shiksha Abhiyan, comprising
independent experts and members of external funding agencies (World Bank,
DFID, EU) was held from 21“ to 28" July 2016 to review the status of civil
works and financial management of the State Implementation Society of
States/UTs.

(ii) 1“ Meeting of Central Grant in-aid Committee (CGIAC) on Scheme for
Providing Quality Education in Madrasas (SPQEM) & Infrastructure
Development in Minority Institutes (IDMI) was held on 12.07.2016.

(iii) The cooking cost for Mid Day Meal Scheme 2016-17 has been increased by 7 %
w.e.f. 1* July 2016.

(iv) Out of 54 Kendriya Vidyalays approved for opening by Cabinet Committee on
Economic Affairs (CCEA) 42 KVs have been opened so far.

(v) A Video conference was taken by me with the State Education Secretaries
(Primary and Secondary Education) on 18.07.2016 to review the preparedness
of the States/UTs for on-line submission of data of scholarship holders on
National Scholarship Portal mainly with regard to Aadhaar enrolment and
seeding of Aadhaar with bank accounts of beneficiaries covered under two
Centrally Sponsored schemes of this Department viz. National Means-cum-
Merit Scholarship Scheme (NMMSS) and National Scheme of Incentive to
Girls for Secondary Education (NSIGSE), covered under DBT platform. State-
wise progress was monitored in this regard. The conference was attended by
Shri Ajay B. Pandey, CEO/DG, UIDAI and
Shri M. K. Mishra, Joint Secretary, Department of Financial Services among
others. The State Governments were instructed to complete the task of applying
through scholarship portal by 31.08.2016.

(vi) Swachh Vidhyalaya Puraskar~ The framework and the time line of awards,
2016 nave been circulated to ali States/UTs. A Video Conferencing was also
conducted by me with Education Secretaries/Principal Secretaries of all
States/UTs to brief them about the guidelines and timelines for the awards at
District, State and National Level.
