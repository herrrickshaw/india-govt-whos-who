---
doc_id: "0ce73d82df5a6cfa"
source_url: "https://morth.gov.in/backend/documents/uploaded/1772003200_BtcrpTRpy4.pdf"
ministry: "Road Transport and Highways (MoRTH)"
title: "G.S.R. 07(E) dated 02nd January, 2026 regarding Acoustic vehicle Alerting System (AVAS) in M and N vehicles category ::"
date: ""
pages: 8
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d65e89c4fb965c49"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-09012026-269253
xxxGIDHxxx
CG-DL-E-09012026-269253
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 17]
No. 17]

नई दिल्ली, िुक्रवार, िनवरी 9, 2026/पौर् 19, 1947
NEW DELHI, FRIDAY, JANUARY 9, 2026/PAUSHA 19, 1947

सड़क पररवहन और रािमागग मंत्रालय
अजधसूचना
नई दिल्ली, 5 िनवरी, 2026
सा.का.जन. 17(अ).— मोटर यान अजधजनयम, 1988 (1988 का 59) की धारा 212 की उपधारा (1) द्वारा यथा
अपेजित, कें द्रीय मोटर यान (मोटर यान िुर्गटना जनजध) जनयम, 2022 में संिोधन करने के जलए प्रारुप जनयम, भारत सरकार
के सड़क पररवहन और रािमागग मंत्रालय की अजधसूचना संख्या सा.का.जन. 351(अ), दिनांदकत 28 मई, 2025, भारत के
रािपत्र, असाधारण, भाग II, खंड 3, उपखंड (i) में प्रकाजित दकए गए थे, जिनमें उन सभी व्यजियों से जिनका उससे प्रभाजवत
होना संभाव्य है, उस तारीख से जिसको रािपत्र की प्रजतयां, जिसमें उि अजधसूचना प्रकाजित की गई थी, िनता को उपलब्ध
करा िी गई थीं, से तीस दिन की अवजध के अवसान से पूवग आिेप और सुझाव आमंजत्रत दकए गए थे;
िबदक रािपत्र अजधसूचना की प्रजतयां तारीख 29 मई, 2025 को िनता के जलए उपलब्ध करा िी गई थीं;
और, उि प्रारूप जनयमों के संबंध में िनता से प्राप्त आिेपों या सुझावों पर कें द्रीय सरकार द्वारा सम्यक रूप से
जवचार दकया गया है;
अतः, अब कें द्रीय सरकार मोटर यान अजधजनयम, 1988 (1988 का 59) की धारा 164ख के साथ परित धारा
164ग की उप-धारा (2) के खंड (फ), (ब), (भ), और (म) द्वारा प्रित्त िजियों का प्रयोग करते हुए, कें द्रीय मोटर यान
(मोटर यान िुर्गटना जनजध) जनयम, 2022 का संिोधन करने के जलए जनम्नजलजखत जनयम बनाती है, अथागत:् 1. संजिप्त िीर्गक और प्रारं भ.- (1) इन जनयमों का संजिप्त नाम कें द्रीय मोटर यान (मोटर वाहन िुर्गटना जनजध) संिोधन
जनयम, 2025 है।
209 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) परंतु, इन जनयमों में अन्यथा यथा उपबंजधत के जसवाय, ये रािपत्र में उनके अंजतम प्रकािन की तारीख को
प्रवृत्त होंगे।
2. कें द्रीय मोटर यान (मोटर वाहन िुर्गटना जनजध) जनयम, 2022 (जिसे इसमें इसके पश्चात उि जनयम कहा गया है) के
जनयम 2 में, खंड (ङ) का लोप दकया िाएगा।
3. उि जनयम के , जनयम 3 के खंड (ग) में, “रकम” िब्ि के स्ट्थान पर “खाता” िब्ि रखा िाएगा।
4. उि जनयम के , जनयम 4 में, उप-जनयम (3) के पश्चात जनम्नजलजखत उप-जनयम अंतःस्ट्थाजपत दकया िाएगा, अथागत्:“(4) न्यास सड़क िुर्गटनाओं से संबंजधत ऐसे अन्य कायग और ऐसे अन्य उत्तरिाजयत्वों का जनवगहन करे गा, िैसा दक
के न्द्रीय सरकार द्वारा समय-समय पर जवजनर्िगष्ट दकया िाएगा।”
5. उि जनयम के , जनयम 5 (i) के सारणी में क्रम संख्या 5 के स्ट्तंभ (2) की प्रजवजष्ट के स्ट्थान पर जनम्नजलजखत प्रजवजष्ट रखी
िाएगी, अथागत:्
“सड़क पररवहन और रािमागग मंत्रालय के उप सजचव के रैं क से जनम्न कोई अजधकारी नहीं”
6. उि जनयम में, जनयम 6 के स्ट्थान पर जनम्नजलजखत जनयम रखा िाएगा, अथागत:् न्याजसयों की िजियााँ और कायग- (1) न्यास के उद्देश्यों को अग्रसर करने के जलए और उससे संबंजधत आनुर्ंजगक या सहायक
मामलों को आगे बढाने के जलए, न्यास की जनम्नजलजखत िजियााँ होंगी:—
(क) मोटर यान िुर्गटना जनजध (न्यास कोर) के कायगकरण और उपयोग का काजलक पुनर्वगलोकन और िहां कही भी
आवश्यक हो, सूसंगत सुधारात्मक उपायों के जलए के न्द्रीय सरकार को जसफाररि करना;
(ख) जहट एण्ड रन मोटर िुर्गटना स्ट्कीम, 2022 के पीजडत को प्रजतकर और धारा 162 के अधीन जवरजचत स्ट्कीम के
दक्रयान्वयन पर के न्द्रीय सरकार को जसफाररि करना;
(ग) जनयम 10 के अधीन दकए गए अंििान जिसमें मोटर यान िुर्टग ना जनजध (न्यास कोर) िाजमल है, की प्राजप्त और
उसके उपयोग के आधार पर मात्रा का वार्र्गक पुनर्वगलोकन;
(र्) दकसी प्राजधकरण या अजभकरण को, ऐसी ितों और सीमाओं के अध्यधीन, िो ऐसे प्राजधकार में जवजनर्िगष्ट की
िायें, जनम्नजलजखत कायों में से एक या एक से अजधक के जलए प्राजधकृ त करना, अथागत:् (i)

मोटर वाहन िुर्गटना जनजध का प्रबंधन;

(ii)

जहट एंड रन मोटर िुर्गटना पीजड़तों को मुआविा स्ट्कीम, 2022 और धारा 162 के अधीन बनाई गई स्ट्कीम
का दक्रयान्वयन;

(iii) कें द्रीय मोटर यान (मोटर यान िुर्गटना जनजध) जनयम, 2022 के जनयम 11 के अनुसरण में मोटर यान
िुर्गटना जनजध का उपयोग सुजनजश्चत करना।
(ङ) जहट एंड रन मोटर िुर्गटना पीजड़तों को मुआविा योिना, 2022 और धारा 162 के अधीन बनाई गई योिना के
कायागन्वयन के जलए उत्तरिायी दकसी भी प्राजधकरण या अजभकरणों द्वारा उिाए गए दकसी भी मुद्दे पर जवचारजवमिग करना;
(च) मोटर वाहन िुर्गटना जनजध के प्रिासन या जहट एंड रन मोटर िुर्गटना पीजड़तों को मुआविा योिना, 2022 और
बनाई गई योिना के कायागन्वयन से संबंजधत दकसी भी अन्य मामले पर कें द्रीय सरकार से जसफाररि करना;
(छ) न्यास के कायगकरण के जलए जवजनयम और उप-जवजध बनाना;
(ि) कोई अन्य मामला िो उन उद्देश्यों की प्राजप्त से प्रत्यित: संबंजधत हो जिनके जलए न्यास का गिन दकया गया था।
(2) न्यास के दक्रयाकलाप और कायों का सामान्य अधीिण, जनिेिन और प्रबंधन न्यासी बोडग में जनजहत होगा िो
सभी िजियों का प्रयोग कर सकता है और सभी कायग और कृ त्य कर सकता है िो न्यास द्वारा प्रयोग की िा सकती हैं या की
िा सकती हैं।
7. उि जनयम के , जनयम 7 के उप-जनयम (1) के स्ट्थान पर जनम्नजलजखत उप-जनयम रखा िाएगा:-

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

“(i) यह न्यास, न्यास जवलेख द्वारा िाजसत होगा, िो दक इन जनयमों के अजतररि होगा और न दक इसके अल्पीकरण
में होगा।”
8. उि जनयम के जनयम 8 के , (i) उप-जनयम (1) में, (क) “न्यासी” िब्ि के पश्चात, “या ऐसा प्राजधकरण या अजभकरण जिसे न्यास द्वारा प्राजधकृ त दकया िाए” िब्ि
अंतःस्ट्थाजपत दकए िाएंगे;
(ख) "बजहयों और" िब्िों के पश्चात, "प्राप्त और संजवतररत िावों के अजभलेख सजहत" िब्ि अंतःस्ट्थाजपत दकए िाएंगे;
(ii)

उप-जनयम (2) में, “न्यासी” िब्ि के पश्चात, “या ऐसा प्राजधकरण या अजभकरण जिसे न्यास द्वारा प्राजधकृ त दकया िाए”
िब्ि अंतःस्ट्थाजपत दकए िाएंगे;

(iii) उप-जनयम (3) में, “न्यासी” िब्ि के पश्चात, “या ऐसा प्राजधकरण या अजभकरण जिसे न्यास द्वारा प्राजधकृ त दकया िाए”
िब्ि अंतःस्ट्थाजपत दकए िाएंगे;
(iv) उप-जनयम (4) में, “न्याजसयों” िब्ि के पश्चात, “या ऐसा प्राजधकरण या अजभकरण जिसे न्यास द्वारा प्राजधकृ त दकया
िाए” िब्ि अंतःस्ट्थाजपत दकए िाएंगे।
(v)

उप-जनयम (7) के पश्चात जनम्नजलजखत उप-जनयम अंतःस्ट्थाजपत दकए िाएंग,े अथागत:् “(8) न्याजसयों या न्यास द्वारा प्राजधकृ त कोई प्राजधकरण या अजभकरण द्वारा यह सुजनजश्चत दकया िाएगा दक
अजधजनयम के अधीन बनाई गई स्ट्कीम के अधीन भुगतान जवजनधागररत समय-सीमा के भीतर दकया िाए।
(9) के न्द्रीय सरकार, इन जनयमों, जहट एण्ड रन मोटर िुर्गटना के पीजड़तों को मुआविा स्ट्कीम और धारा 162 के
अधीन बनाई गई स्ट्कीम के दक्रयान्वयन के जहत में िैसा सही समझे वैसी कायगवाही कर सके गी।

9. उि जनयम के जनयम 10 में, (i) जनयम 10 को उसके उप-जनयम (1) के रूप में संख्यांदकत दकया िाएगा;
(ii) उप-जनयम (1) के खण्ड (क) में, िैसा दक इस प्रकार क्रमांदकत है, (क) उपखंड (i) के स्ट्थान पर जनम्नजलजखत उपखंड और परं तुक रखे िाएंगे, अथागत्, भारत में मोटर बीमा का व्यवसाय करने वाली बीमा कम्पजनयों द्वारा संग्रजहत कु ल तृतीय पि प्रीजमयम का ऐसा
प्रजतित, िैसा दक न्यास द्वारा जवजनर्िगष्ट दकया गया है:
परं तु बीमा कम्पजनयां न्यास द्वारा जवजनर्िगष्ट दकए िाने पर, न्यास द्वारा जवजनर्िगष्ट अवजध के भीतर अंििान
िमा करें गी”;
(ख) उपखंड (ii) का लोप दकया िाएगा;
(iii) उप-जनयम (1) के खण्ड (ख) में, उप-खण्ड (i) का लोप दकया िाएगा;
(iv) उप-जनयम (1) के उपखंड (ग) में, िैसा दक इस प्रकार क्रमांदकत है, (क) खंड (क) में जनम्नजलजखत खंड और परंतुक प्रजतस्ट्थाजपत दकया िाएगा, अथागत,् भारत में मोटर बीमा का व्यवसाय करने वाली बीमा कम्पजनयों द्वारा संग्रजहत कु ल तृतीय पि प्रीजमयम का ऐसा
प्रजतित, िैसा दक न्यास द्वारा जवजनर्िगष्ट दकया गया है:
परं तु बीमा कम्पजनयां न्यास द्वारा जवजनर्िगष्ट दकए िाने पर, न्यास द्वारा जवजनर्िगष्ट अवजध के भीतर अंििान
िमा करें गी”;
(ख) खंड (ख) का लोप दकया िाएगा;

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(v) इस प्रकार क्रमांदकत उप-जनयम (1) के पश्चात जनम्नजलजखत उप-जनयम अंतःस्ट्थाजपत दकया िाएगा, अथागत:् “(2) न्यास, धारा 162 के अधीन बनाई गई योिना की अपेिाओं के आधार पर बीजमत यानों के खाते में और जहट
एंड रन मोटर िुर्गटना पीजड़तों को मुआविा योिना, 2022 की अपेिाओं के आधार पर जहट एंड रन मुआविा खाते
में, समय-समय पर न्यूनतम िेर् राजि जवजनर्िगष्ट करेगा िो अनुरजित रखी िाएगी।”
10. उि जनयम के जनयम 11 के (i) खंड (क) में, (क)

उपखंड (i) में, “बीमाकृ त यानों द्वारा काररत िुर्गटनाओं” िब्िों के पश्चात, “और धारा 162 के अंतगगत बनाई
गई योिना के कायागन्वयन से संबंजधत दकसी भी प्रभार के जलए” िब्ि और अंक अंतःस्ट्थाजपत दकए िाएंगे;

(ख) उप-खण्ड (ii) और (iii) का लोप दकया िाएगा;
(ii) खंड (ख) में, (क) उप-खण्ड (i) में, मि (क) में, “अबीमाकृ त यानों द्वारा काररत और जहट एण्ड रन मोटर िुर्गटनाओं के पीजड़तों”
िब्िों के स्ट्थान पर, “बीमाकृ त यानों से काररत िुर्गटनाओं से जभन्न और धारा 162 के अन्तगगत बनाई गई स्ट्कीम
के दक्रयान्वयन से संबंजधत दकसी प्रभार” िब्ि रखे िाएंगे;
(ख) खंड (ii) और (iii) का लोप दकया िाएगा;
(iii) खंड (ग) में, (क) उप खंड (i) के स्ट्थान पर जनम्नजलजखत खंड प्रजतस्ट्थाजपत दकया िाएगा, (i) “जहट एंड रन मुआविा खाते का उपयोग जहट एंड रन िुर्गटना पीजड़तों को जहट एंड रन मोटर िुर्गटना
पीजड़तों को मुआविा स्ट्कीम, 2022 के साथ परित धारा 161 और धारा 164क के अनुसरण में मुआविा प्रिान
करने के जलए और जहट एंड रन मोटर िुर्गटना पीजड़तों को मुआविा योिना, 2022 के कायागन्वयन से संबंजधत
दकसी भी प्रभार के जलए दकया िाएगा।”
(ख) उप-खण्ड (ii) का लोप दकया िाएगा।
11. उि जनयम के जनयम 12 के , (i)

उप-जनयम (2) में, “नामजनर्िगष्ट अजभकरण को जनजध स्ट्थांतररत करना” िब्ि के स्ट्थान पर, “न्यास द्वारा प्राजधकृ त
प्राजधकरण या अजभकरण द्वारा मोटर वाहन िुर्गटना जनजध के उपयोग की अनुज्ञा िेगा” िब्ि रखे िाएंगे;

(ii)

उप-जनयम (3) में, “नामजनर्िगष्ट अजभकरण द्वारा” िब्ि का लोप दकया िाएगा;

(iii) उप-जनयम (4) में, (क) “अबीमाकृ त यानों द्वारा काररत मोटर िुर्गटना” िब्िों के स्ट्थान पर “बीमाकृ त यानों द्वारा काररत िुर्गटनाओं
से जभन्न अन्य िुर्गटनाएं” िब्ि रखे िाएंगे;
(ख) “नामजनर्िगष्ट अजभकरण द्वारा” िब्ि का लोप दकया िाएगा;
(iv) उप-जनयम (5) का लोप दकया िाएगा;
(v) उप-जनयम (6) के स्ट्थान पर जनम्नजलजखत उप-जनयम रखा िाएगा, अथागत:् “यदि जहट एंड रन िुर्गटना का कारण बनने वाले मोटर यान की पहचान बाि में हो िाती है (क) प्राजधकृ त बीमाकताग या स्ट्वामी, िैसी भी जस्ट्थजत हो, पीजड़त के नगिीरजहत उपचार पर व्यय की गई स्ट्वीकृ त
िावा राजि को असुरजित यानों या जहट एंड रन मोटर िुर्गटना संबंधी खाते में प्रजतपूर्तग करने के जलए उत्तरिायी
होगा;
(ख) और यदि मोटर िुर्गटना िावा अजधकरण ने कोई अजधजनणगय पाररत कर दिया है, तो प्राजधकृ त बीमाकताग या
स्ट्वामी जहट एंड रन मोटर िुर्गटना पीजड़तों को मुआविा योिना, 2022 के अधीन प्राप्त मुआविा राजि को
ऐसे अजधजनणगय के अनुसरण में जहट एंड रन मुआविा खाते में वापस कर िेगा।”;

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

5

भारत का रािपत्र : असाधारण

(vi) उप-जनयम (7) का इसके परं तुक और स्ट्पष्टीकरण सजहत लोप दकया िाएगा।
(vii) उप-जनयम (7) के पश्चात जनम्नजलजखत स्ट्पष्टीकरण अंतःस्ट्थाजपत दकया िाएगा, अथागत्:“ स्ट्पष्टीकरण– इस जनयम के प्रयोिनों के जलए, “अनुमोदित िावा रकम” का तात्पयग ऐसे प्राजधकरण या अजभकरण द्वारा
अनुमोदित ऐसी िावा रकम से है, जिसे कें द्रीय सरकार द्वारा जवजनर्िगष्ट दकया िा सके गा।”
12. उि जनयमावली में, जनयम 14 का लोप दकया िाएगा।
[फा. सं. आरटी-11036/64/2019-एमवीएल(कमेटी ई)]
महमूि अहमि, अपर सजचव

रटप्पणी:- मूल जनयम भारत के रािपत्र, असाधारण, भाग II, खंड 3 उप-खंड (i) की अजधसूचना संख्या सा.का.जन. 162(अ),
दिनांदकत 25 फरवरी, 2022 द्वारा प्रकाजित दकए गए थे।

MINISTRY OF ROAD TRANSPORT AND HIGHWAYS
NOTIFICATION
New Delhi, the 5th January, 2026
G.S.R. 17(E).— Whereas, the draft rules to amend the Central Motor Vehicles (Motor Vehicle Accident Fund)
Rules, 2022 were published, as required by sub-section (1) of Section 212 of the Motor Vehicles Act, 1988 (59 of
1988), vide notification of the Government of India in the Ministry of Road Transport and Highways, vide number
G.S.R 351(E), dated the 28th May, 2025, in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i),
inviting objections and suggestions from all persons likely to be affected thereby before the expiry of the period of thirty
days from the date on which copies of the Official Gazette containing the said notification were made available to public;
And, whereas, copies of the said Official Gazette notification, were made available to the public on the 29th
May, 2025;
And, whereas, the objections and suggestions received from the public in respect of the said draft rules have
been duly considered by Central Government;
Now, therefore, make in exercise of the powers conferred by clauses (v), (w), (x), and (y) of sub-section (2) of
section 164C read with Section 164B of the Motor Vehicles Act, 1988 (59 of 1988), the Central Government hereby
makes the following rules, to amend the Central Motor Vehicle( Motor Vehicle Accident Fund) Rules, 2022 namely:1. Short title and commencement. - (1) These rules may be called the Central Motor Vehicles (Motor Vehicle Accident
Fund) Amendment Rules, 2025.
(2) Save as otherwise provided in these rules, they shall come into force on the date of their publication in the
Official Gazette.
2. In the Central Motor Vehicles (Motor Vehicle Accident Fund) Rules, 2022 (herein after referred to as the said rules),
in rule 2, clause (e) shall be omitted.
3. In the said rules, in clause (c) of rule 3, for the word “Amount”, the word “Account” shall be substituted.
4. In the said rules, in rule 4, after sub-rule (3), the following sub-rule shall be inserted, namely:—
“(4) The Trust shall perform such other functions and discharge such other responsibilities related to road
accidents as may be specified, from time to time, by the Central Government”.
5. In the said rules, in rule 5 (i) in the Table in Serial number 5 in column (2), for the entry the following entry shall be
substituted, namely:
“An officer not below the rank of Deputy Secretary, Ministry of Road Transport and Highways”
6. In the said rules, for rule 6, the following rule shall be substituted namely:Powers and functions of Trustees - (1) For the furtherance of the objects of the Trust, and matters incidental
or ancillary to the attainment thereof, the Trust shall have the following powers:—

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(a)

to periodically review of the working and utilisation of the Motor Vehicles Accident Fund (Trust
Corpus), and make recommendations to the Central Government for relevant corrective steps, wherever
necessary;

(b)

to make recommendations to the Central Government on the implementation of the Compensation to
Victims of Hit and Run Motor Accidents Scheme, 2022 and the scheme framed under section 162;

(c)

to annually review the quantum based on the receipt of contributions made to the Motor Vehicle Accident
Fund (Trust Corpus) made under rule 10 of the Central Motor Vehicles (Motor Vehicles Accident Fund)
Rules, 2022 and utilisation thereof;

(d) to authorise, subject to such conditions and limitations as may be specified in such authorisation, any
authority or agency for one or more of the following functions, namely:—
(i)

the management of the Motor Vehicle Accident Fund;

(ii)

implementation of the Compensation to Victims of Hit and Run Motor Accidents Scheme, 2022
and the scheme framed under section 162;

(iii) to ensure utilisation of the Motor Vehicles Accident Fund in accordance with rule 11 of the
Central Motor Vehicles (Motor Vehicles Accident Fund) Rules, 2022.
(e)

to deliberate upon any issues raised by any authorities or agencies responsible for the implementation of
the Compensation to Victims of Hit and Run Motor Accidents Scheme, 2022 and the scheme framed
under section 162;

(f)

to make recommendations to the Central Govt. on any other issues related to the administration of the
Motor Vehicles Accident Fund or implementation of the Compensation to Victims of Hit and Run Motor
Accidents Scheme, 2022 and the scheme framed;

(g)

to frame regulations and bye-laws for the working of the Trust;

(h)

any other matter directly related to the attainment of the objectives for which the Trust was constituted.

(2) The general superintendence, direction and management of the affairs and business of the Trust shall vest in the
Board of Trustees which may exercise all powers and do all acts and things which may be exercised or done by
the Trust.
7. In the said rules, in rule 7, in sub-rule (I), for the word “formulated in accordance with these rules, and the Trust
Deed”, the word “which” shall be substituted.
8. In the said rules, in rule 8,—
(i) in sub-rule (1),—

(ii)

(a)

after the words “The Trustees”, the words “or such authority or agency as may be authorised by the
Trust” shall be inserted;

(b)

after the word “records”, the words “including records of the claims received and disbursed,” shall be
inserted;

in sub-rule (2), after the words “The Trustees”, the words “or such authority or agency as may be authorised by
the Trust” shall be inserted;

(iii) in sub-rule (3), after the words “the Trustees”, the words “or such authority or agency as may be authorised by the
Trust” shall be inserted;
(iv) in sub-rule (4), after the words “maintained by the Trustees”, the words “or such authority or agency as may be
authorised by the Trust” shall be inserted.
(v)

after sub-rule (7), following sub-rules shall be inserted, namely,—
“(8) The Trustees or such authority or agency as may be authorised by the Trust shall ensure that payments are
made as per the specified time limit under the schemes framed under the Act.
(9) The Central Government may take such action as it may deem fit in the interest of implementing these
rules, the Compensation to Victims of Hit and Run Motor Accidents Scheme, 2022 and the Scheme framed
under section 162.”

9. In the said rules, in rule 10,—
(i) the rule 10 shall be numbered as sub-rule (1) thereof;
(ii) in clause (a) of sub-rule (1) as so numbered,—

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

(a) for sub clause (i), the following sub clause and proviso shall be substituted, namely,—
“such percentage of total third party premium collected by insurance companies carrying on the business of
motor insurance in India as may be specified by the Trust:
Provided that the insurance companies shall deposit contributions as and when specified by the Trust,
within such period as may be specified by the Trust”;
(b) sub clause (ii) shall be omitted;
(iii) in clause (b) of sub-rule (1) as so numbered, sub clause (i) shall be omitted;
(iv) in sub clause (c) of sub-rule (1) as so numbered,—
(a) in clause (a), following clause and proviso shall be substituted, namely,—
“such percentage of total third party premium collected by insurance companies carrying on the business of
motor insurance in India as specified by the Trust:
Provided that the insurance companies shall deposit contributions as and when specified by the Trust,
within such period as may be specified by the Trust”;
(b) clause (b) shall be omitted;
(v) After sub-rule (1) as so numbered, the following sub-rule shall be inserted, namely,—
“(2) The Trust may, from time to time, specify a minimum balance which shall be maintained in the Account
for Insured Vehicles, based on the requirements of the scheme framed under section 162 and the Hit and Run
Compensation Account based on the requirements of the Compensation to Victims of Hit and Run Motor
Accidents Scheme, 2022.”.
10. In the said rules in rule 11—
(i) in clause (a),—
(a)

in sub clause (i), after the words “accidents caused by insured vehicles”, the words and figures “and for
any charges relating to the implementation of the scheme framed under Section 162” shall be inserted;

(b)

sub clauses (ii) and (iii) shall be omitted;

(ii) in clause (b),—
(a)

in sub clause (i), in item (a), for the words “caused by uninsured vehicles and hit and run motor accident
victims”, the words “other than those caused by insured vehicles and any charges relating to
implementation of the scheme framed under Section 162” shall be substituted;

(b)

clauses (ii) and (iii) shall be omitted;

(iii) in clause (c),—

(a) for sub clause (i), following clause shall be substituted, —
(i) “Hit and Run Compensation Account shall be utilised for providing compensation to hit and run
accident victims as per Section 161 and Section 164A, read with the Compensation to Victims of Hit and
Run Motor Accidents Scheme, 2022 and for any charges related to implementation of the Compensation
to Victims of Hit and Run Motor Accidents Scheme, 2022.” ;
(b) sub clause (ii) shall be omitted.
11. In the said rules, in rule 12,—
(i)

in sub-rule (2), for the words “transfer the fund to the designated agency”, the words “permit the utilisation of the
Motor Vehicle Accident Fund by such authority or agency authorised by the Trust” shall be substituted;

(ii)

in sub-rule (3), the words “by the designated agency” shall be omitted;

(iii) in sub-rule (4),—
(a)

for the words “motor accidents caused by uninsured vehicles”, the words “accidents other than those
caused by insured vehicles” shall be substituted;

(b)

the words “by the designated agency” shall be omitted;

(iv) sub-rule (5) shall be omitted;
(v) for sub-rule (6), the following sub-rule shall be substituted, namely,—

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

“If the identity of the motor vehicle causing the hit and run accident is subsequently identified (a)

the authorised insurer or owner, as the case may be, shall be liable to reimburse the approved claim
amount spent on the cashless treatment of the victim, to the Account for Uninsured Vehicles or Hit and
Run Motor Accident;

(b)

and if the Motor Accident Claim Tribunal has passed an award, the authorised insurer or owner shall
return the compensation amount received under the Compensation to Victims of Hit and Run Motor
Accidents Scheme, 2022 to the Hit and Run Compensation Account, in accordance with such award.”;

(vi) sub-rule (7), along with the proviso and Explanation thereto, shall be omitted;
(vii) After sub-rule(7), following Explanation shall be inserted, namely:“Explanation – For the purposes of this rule, “approved claim amount” shall mean such claim amount approved by
such authority or agency as may be specified by the Central Government”.
12. In the said rules, rule 14 shall be omitted.

[F. No. RT-11036/64/2019-MVL(Committee E)]
MAHMOOD AHMED, Addl. Secy.

Note:- The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3 Sub-section (i), vide
notification number G.S.R 162(E), dated the 25 th February, 2022.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH KUMAR
SRIVASTAVA
Date: 2026.01.09 22:34:03 +05'30'
