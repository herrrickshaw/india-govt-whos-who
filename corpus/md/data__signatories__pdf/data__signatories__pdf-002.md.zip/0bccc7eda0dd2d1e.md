---
doc_id: "0bccc7eda0dd2d1e"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/dada8cf69f67e1c6f36e061e22c43326.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Order (Paper Section) 9 February, 2016"
date: "2025-07-02"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f8cc64a65a4a06d"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (ii)
PART II—Section 3—Sub-section (ii)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 382]
No. 382]

ubZ fnYyh] c`gLifrokj] iQjojh 11] 2016@ek?k 22] 1937
NEW DELHI, THURSDAY, FEBRUARY 11, 2016/MAGHA 22, 1937

  

    

(

)

(कागज अनुभाग)
ाग)

आदेश

, 9 फरवरी, 2016
(िवकास एवं िविनयमन) अिधिनयम, 1951 (1951 का 65) 18 ˘ˇˆ˙ 
ˆ ˝˛°, ˜ ! °"#ˆ$%&'˘ˆ()*+˝, 2004 ,˜!(  ˝ ˘°˘-िलिखत आदेश करती है, नामत:—
का.
का.आ. 447(
447(अ).—

(1)

ˆ.+˝#ˆ$%&'˘ˆ()*(संशोधन) आदेश, 2016 कहा जायेगा।

(2)

ˆ.! %/),˜0! ˝   1!˝23.4

#ˆ$%&'˘ˆ()*+˝, 2004 ,˜, अनुसू5,˜˘, ˝ ,°3(67न से संबंिधत मद 4 ,˜8.सं. 121 ˝ 970!!˝!(9(˘˘3˘:
,˜˘-˘˘1!(;ˆ
 7˘3˘:% <%° , नामत:—
“122.

,=!!>?/˘/˝/°(@9 @> . िल., इकाई-I, A# B C,/ 6', िशवाकाशी, ˘3DE3 , तिमलनाडु ”।
[फा. सं. 4(2)/2015-कागज]

=˝# &!., !(ˆBˇ!˘53
,$+˝2 ˝ %/), असाधरण, भाग II, खंड 3, उपखंड (ii) ,˜(11 AF$बर, 2004 के का.आ. 1105 (अ) के
 ˘ ˆ˝ ˆ˝7˝G(1 A=, 2015 के का.आ. 639 (अ) के ˘/!(  ˆ ˆ74
नोटः

733 GI/2016

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

MINISTRY OF COMMERCE AND INDUSTRY
(Department of Industrial Policy and Promotion)
(PAPER SECTION)
ORDER
New Delhi, the 9th February, 2016
S.O. 447(E).—In exercise of the powers conferred by section 18 G of the Industries (Development and
Regulation) Act, 1951 (65 of 1951), the Central Government hereby makes the following order further to amend the
Newsprint Control Order, 2004, namely:—
1.

(1) This order may be called the Newsprint Control (Amendment) Order, 2016.
(2) It shall come into force on the date of its publication in the Official Gazette.

2.
In the Newsprint Control Order, 2004, in the Schedule, in item 4 relating to the name of the mill and location,
after S. No. 121, and the entries relating thereto, the following serial number and entries shall be added, namely:—
“122. M/s. Sripathi Paper & Boards Pvt. Ltd., Unit-I, Anaikuttam Post, Sivakasi, Virudhvnagar, Tamil Nadu”.
[F. No. 4(2)/2015-Paper]
SHAILENDRA SINGH, Jt. Secy.
Note : The principal order was published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (ii) vide
number S.O. 1105 (E), dated the 11th October, 2004 and lastly amended vide number S.O. 639(E), dated the
1st April, 2015.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
