---
doc_id: "0bbbfb39ad50f35e"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/fff5206055c1cb79ce9e0af81f5ab218.pdf"
ministry: "Department of Science and Technology (DST)"
title: "Tender notice for LED DISPLAY Panel & Multiple display browser based system along with wiring."
date: "2015-02-26"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a64cf064bc9db8ba"
---

<!-- page 1 -->

<!-- page 2 -->

GENERAL TERMS AND CONDITION

A The sealed quotation should reach on or before the specified date in the enquiry letter
addressed to Under Secretary, Admn II B, Technology Bhawan, New Delhi 110016.
THE COVER SHOULD BE SUPERSCRIBED WITH THE FOLLOWING:

Supply & Installation of 55-59” LED with multiple display browser based system

B This office takes no responsibility for delay, loss or non-receipt of quotations/documents sent by
post where as reserves the right to accept or reject any part of the tender without assigning any
reasons.
C Corrections if any must be attested. All rates shall be indicated both in words as well as in
figures, where there is a difference between rates quoted in words and figures, rate quoted in
words will prevail. The firm has to submit the signed copy of the Terms and Conditions along
with the quotation. The submission is for the acceptance of the general terms and conditions
without which the quote would be rejected.
D EMD: Earnest money amounting to Rs.10,000/- (Rupees Ten Thousand Only) in the form of
Bankers Cheque/ Account Payee Demand Draft of nationalized bank/ commercial Bank drawn
in favour of DDO, Department of Science & Technology should accompany the tender. Tender
without EMD shall be summarily rejected (EMD exemption is applicable for those who are
registered with DGS&D for the said items). The earnest money should initially be valid up to 45
days beyond period of Bid validity. The earnest money of unsuccessful bidders will be returned
on finalization of tender. The earnest money of successful bidders will be returned on receipt of
Security Deposit or it may be adjusted in the security deposit if requested by the tenderer.
E SECURITY DEPOSIT: the successful tenderer shall furnish the security deposit within 2 weeks
after placement of order at the rate of 10% of the order value, failing which the EMD will be
forfeited automatically, to DST, without any notice. The security deposit shall be furnished in the
form of Demand Draft/ FDR/ Bank Guarantee drawn in the favour of DDO, Department of
Science & Technology and should be valid for 27 months. The security deposit will be returned
in full on completion of successful guarantee/warranty period.
F RIGHT OF ACCEPTANCE: This office reserves the right to reject the lowest tender or any or all
the tenders without assigning any reason whatsoever.
G QUOTATIONS VALIDITY: Quotation should be valid for a minimum period of six months.
H QUALIFYING BID: Bidders who quote lowest bundle cost will be declared as qualifier on basis
of L1 provided the bidder has submitted all the required documents mentioned in the tender
document.
I GURANTEE TERMS: The supplier should provide warrantee/guarantee for minimum TWO year
and onsite support. Any parts failing during the guarantee period shall be repaired /replaced free
of charge by the supplier at the installation site.
Page 2 of 7

<!-- page 3 -->

J

Qualification Criteria for Vendor
1 Vendor should be either original equipment Manufacturer or Authorized dealer of reputed and
established brand. Manufacturer Authorization letter should be enclosed.
2
Vendor should have been dealing in the LED/LCD/PLASMA display systems for past
three years & supplied the same to any Ministry/Govt. Department.

K. PRICE & STATUATORY DUTIES:
1 It should be mentioned specifically whether the price quoted includes all taxes and duties.
2 Sales tax and / or other duties and levies where legally leviable and intended to be claimed
should be distinctly and separately mentioned in the quotation. Where it is not done no claim
for Sales Tax / Service Tax will be admitted at any later stage and no ground whatsoever.
3 VAT/CST registration No. and date of its validity should be mentioned.
4 This office will not issue any Form such as ‘C’, ‘D’ etc.
L DESPATCH INSTRUCTIONS: The firm will dispatch the materials by road under insurance
cover and freight paid by tenderer.
M DELIVERY PERIOD: Materials should be supplied by the tenderer within 2 Weeks from the date
of issue of Purchase Order at DST, Technology Bhawan, New Delhi.
n LATE DELIVERY CHARGS: If the delivery of the material will be delayed more than specified
time, 0.5% of the total amount will be charged per week subject to maximum 10% of ordered
value.
o
PAYMENT TERMS:
1 Payment will be made, after completion of supply, installation & testing of the item and
submitting the invoice. No advance payment will be made.
2 Payment would be in Indian Rupees.
3 Payment would be made in the name of company.
p ADDITIONAL/Reduced QUANTITY: DST reserves the right to place order for additional quantity
of the ordered quantity at the same rates and terms and condition till the validity of Quotation.
q
The tender should have valid Sales Tax/Service tax number. It is required to mention Sales
Tax/Service tax Numbers and enclose copy of the registration.

Page 3 of 7

<!-- page 4 -->

r DOCUMENTATION: One copy each of operational and service manuals shall be supplied along
with the equipment in the event of order being placed. All associated software should be
supplied in original CD/DVD licensed to DST along with one set of Hard copy document on
operational methods.
s

ENCLOSURES:
The firm must submit the following enclosures along with the
tender. 1 Financial bid with all quoted items.
2 Technical manuals/Detailed technical literature /catalogues for all the offered products
3 Signed copy of general terms and condition by the authorized person. Printed terms and
conditions of tendering firms will not be considered as forming part of their tender
4 Any other document mentioned elsewhere in the tender document.(Clouse ‘J’)

The tender is liable to be rejected in the absence of the above enclosures with the sole
responsibility of the tenderer

Page 4 of 7

<!-- page 5 -->

CHECK LIST
Please ensure to check the following before submitting quotation otherwise, quotation will be liable for

rejection.

.
1

PRICE

Price quoted both in figures and words are correct.
However price quoted in words will prevail, if there is
any difference

2
3

VALIDITY
PAYMENT TERMS

For minimum six months
No advance, Payments will be done after receipt of

4

DELIVERY PERIOD

5

PAKAGING/FORWARDING
CHARGE

6

LAVIES/TAXES

material in good working condition and accepted by
this office.
Material should be delivered within 2 weeks from
the date of supply order
Should be clearly indicated. Mentioning “EXTRA”
will not be acceptable. Delivery is to be made at
DST, Technology Bhawan.
Levis/Taxes if any are to be clearly mentioned.

7
8

TRANSIT INSURENCE
ENCLOSURE

Clearly indicate as per clause “L” of GTC
. As per clause” S “of GTC

9

PAN/TIN

REGISTRATION COPY OF PAN, TAN, ST TO BE
ENCLOSED

10
11

DUE DATE
OPENING DATE/TIME

09 March 2015. 1500 hrs
09 March 2015 1530 hrs

Page 5 of 7

<!-- page 6 -->

Annexure-I
Specification for LED & multi input browse based system
SCOPE:
One Numbers of 55-59” LED displays of internationally reputed brands is to be installed
at DST, New Delhi to be used as display system at entrance and one number of multiple
browse based system to have multi inputs for display on screen. It should include all necessary
accessories & cables i.e. 20 meter VGA cable, HDMI cables, audio video cables & VGA to
HDMI converter (to connect VGA output of PC to LED display HDMI port)
GENERAL FEATURE OF THE DISPLAY UNITS:
1 The offered LED display units should fall in the category of Smart TV and should be of
reputed international brand. Preferred brands are Sony, Samsung, LG and Panasonic.
2 It should meet the requirement of 24 x7 operations.
3
4

The LED display should be of Full HD resolution and switchable aspect ratio between 4:3
and 16:9.
It should have multi-format USB play out (Photo, Audio and video).

5

The offered model should be supplied with wall mount accessories and table stand. It would
be the responsibility of the bidder to install (one time) the offered LED displays at the site
designated by authority.
6 It should have preset picture setting/ modes like Cinema, sports, music, Vivid, natural etc.
7 It should have built in speakers with amplifier for audio monitoring.
8 LED should be supplied with full wireless handheld remote control whereas similar control
should be available on LED display unit.
9 LED should have VGA port OR provision for connectivity of PC/Laptop through VGA cable
10 The offered unit should cover the manufacturer’s warranty of minimum 2years.
11 The multi input browser based system should have provision to input the data as per desire of
department. It should have facility for HDMI/VGA/audio/video port.
12 Input to this system can be managed from a single location as well as it can be updated
remotely.
13 System should be user friendly.
Technical Specifications
1. Size Diagonally

-

55-59’’

2. Backlight

-

LED

3. Connectivity a. Composite/Component Video in

-

b. HDMI interface

-

2no or more

c. USB 2.0
d. VGA interface (VGA Port or through VGA to
HDMI converter assembly)

-

1no or more

-

1no

e. RF input

-

1no

f. Ethernet/LAN
Resolution
Aspect Ratio support

4
5
6

1no

1no
Full HD 1920 x1080 pixels
4x3 and 16x9 switchable

USB application should support Photo Viewer (jpeg), Music Player (mp3), Video Player (MPEG2/MPEG4 or
better)
7. Speakers

-

Min 2no

8. Viewing Angle

-

175º (H) or better

9. Full functional Remote with AA or AAA batteries.
10.

Power supply

-110-220 V, 50 Hz

<!-- page 7 -->

Appendix ‘A’ TO L T E No D-15013/2/2014 Admn II B

dted. 26 Feb 2015

1. M/s S B
Enterprises.
Chopra Complex, Mall Road
New Delhi-110015

2. M/s Abhi Projection
11/21, Shop No- 10(Basement), Shabharwal
Complex New Delhi-110018
3. M/s Jagdamba Enterprises.
CD-35 A, Hari Nagar,
New Delhi-110064

4. M/s Gaurishankar Technologies
Limited CA-7A, Hari Nagar
New Delhi, 110064

Private

5. Global Infotel Solution
184, GF
Mohammadpur
Bhikaji Cama Palace
New Delhi-110016
6. Aryan E-Soft Pvt Ltd
F- 8 Shankar Market
Connaught Palace
New Delhi-110001
7

Shree Info Solutions Enterprises
465-C/1 Sayed Wali Gali, Azadpur,
Delhi-110033

8. Any other firm registered with Govt. ministries/ Departments or original manufacturer of
item can also participate.

Page 7 of 7
