---
doc_id: "0ede9cb86e81aeb8"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/180b9f94826cceb6a436dce239279864.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Tender Notice - Inviting Bids from Translation Agencies"
date: "2017-09-01"
pages: 10
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "43f7bc8ee6a828ba"
---

<!-- page 1 -->

TENDER NOTICE
Quotations are invited from Translation Agencies / Firms to be included in the proposed
panel (for a period of 2 years) of the Ministry of Health and Family Welfare for doing translation
work, specially from English to the Hindi, of the health related and other various topics and the
website of the Ministry (Individuals need not apply).
2; The tender is required to be submitted on twin bid basis ie. Technical Bid (Annexure-II)
and the Financial Bid (Annexure-III) complete in all respect, in separate sealed envelopes
superscribed ‘Technical Bid’ and ‘Financial Bid’. Both these covers should be enclosed in a
separate envelope superscribed “Quotation for Hindi translation work”. The sealed quotations
should reach this Department i.e. Smt. Niharika Singh, Joint Director (OL), Ministry of Health
& Family Welfare, Room No.754, ‘A’ Wing, Nirman Bhawan, New Delhi by 1400 hrs on
08 September, 2017 along with a Demand Draft/Bankers Cheque for Rs.2,000/- on account of
earnest money. The quotation will be opened at 1500 hrs on the same day. Tenderer or their
representative need to remain present at the time of opening of the tender.
3) All successful bidders finalized for empanelment, will be required to sign a contract with
Ministry of Health & Family Welfare for doing translation work on L1 (lowest rate) as per the
terms and conditions enclosed as Annexure-I.
4. The tender notice and detailed terms and conditions (Annexure-I) and other Annexures IT
to IV and Section 2, can also be downloaded from the Ministry’s website www.mohfw.nic.in.
ia
Ly
wind ‘a Singh)
Joint Director (OL)
Tel: 2306 0162
Copy to:
NIC, Ministry of Health and Family Welfare, New Delhi — with the request to upload the Tender
Notice and terms and conditions (Annexure-I) and Annexure I to IV, Section 2 on the website of
MoH&FW.

<!-- page 2 -->

Annexure-I
GENERAL TERMS & CONDITIONS

1 Translation Agencies/Firms aspiring for inclusion in the proposed panel will be selected
on the basis of screening held by Evaluation Committee formed for this purpose.

2. The Agencies/Firms should submit proof of providing translation services and references
(viz. work orders, TDS deduction certificates, work completion certificates, etc.) to
other Ministries/Departments/ Offices etc. should be enclosed along with their
quotations. Tenders received without relevant documents will not be entertained.

3: Assigned work is required to be translated precisely from English to Hindi and vice versa
in Unicode enabled Font viz. Mangal or MS Unicode Font or as advised by the
concerned authority through e-mail. Since the assigned work is of time bound nature, it
is required to be provided within the prescribed time limit while maintaining the quality
of translation, typing and vetting. Thereafter, the quality and accuracy will be checked
by the Department. Corrections, if any, are to be carried out by the Agency/Firm at its
expenses. No payment/compensation ete would be given for carrying out corrections.

4, The selected Agency/Firm would work from their premises. All man power/equipments/
Hardware/software etc. required for the tendered work should be arranged by the
Agency/Firm at their cost. MoH&FW will not provide any office space, computers,
internet, telephone, etc. for the translation works. Department will not provide any
stationery, papers, CDs etc. for this purpose.

ae Translation work to be assigned, could be of any nature viz. technical/non-technical
material, report, speech etc

6. Translation charges (inclusive of translation, vetting, typing and proof reading charges)
per word should be quoted in the tender. No other payment, whatsoever, will be made for
any activity/visit connected with the work other than the agreed translation charge.

at: Payment : The payment will be made based on accepted rate per word of the given text,
number of words to be counted as per word processor.

8. Duration of Assignment-

8.1 Translation work may be given even in odd hours through e-mail or hard copy,
which would be required to complete on urgent basis within the prescribed time
limit with accuracy.

8.2 The Agency / its translators would be required to be in constant communication
with the concerned officials of the Ministry through email/ phone till the task is
completed satisfactorily.

9. The Agency/Firm could be removed from the Empanelled list if the quality of the
translation work is not found upto the mark or complete translation is not provided within
the given time limit, in such case, concerned Agency/Firm will not be assigned any
translation work.

<!-- page 3 -->

10. Corrupt and Fraudulent Practices

10.1 “Corrupt Practice” means the offering, giving, receiving or soliciting of anything
of value to influence the action of the public official.

10.2. “Fraudulent Practice” means a misrepresentation of facts in order to influence
empanelment process or a execution of a contract to the detriment of Ministry and
includes collusive practice among authorized representative/service providers.

10.3. The Ministry will suspend assignment of works , if it determines that the Agency
recommended for empanelment has engaged in corrupt or fraudulent practices and
initiate process for dis-empanelment.

11. Submission of Proposals

11.1 The Technical Proposals will include following essential documents - each of them
duly signed and stamped
1. Technical Proposal submission letter (Section 2)

2: Technical Bid (Annexure II format)
3. Copy of Tender document signed and stamped.
4. Copy of PAN/TAN/GSTIN - self attested

11.2. The tenderer should sign and stamp each part of this tender document as a token of
having read and understood the terms and conditions contained therein and submit
the same along with the bid.

11.3 The original proposal (Technical Proposal and Financial Proposal) shall be prepared
in indelible ink. It shall contain no interlineations or overwriting.

11.4 The Technical Proposal should be placed in a sealed envelope and superscribed
“Technical Proposal for Translation Work” Hindi to English and Vice versa for
the Ministry of Health and Family Welfare".

11.5 Further, the Financial Proposal (Annexure III format) shall be placed in a sealed
envelope and superscribed “Financial Proposal for Translation Work” Hindi to
English and vice versa for the Ministry of Health and Family Welfare.

11.6 If the Financial Bid is not submitted in a separate sealed envelope duly super-scribe
as indicated above, this will constitute grounds for declaring the Bid non-
responsive.

11.7 Both the sealed envelopes should be put into an outer envelope and sealed. The
outer envelope shall be super-scribed “Technical & Financial Proposal -
Translation Work Hindi to English and Vice Versa for the Ministry of
Health and Family Welfare" with the due date for submission. The Bottom Left
corner of the outer cover should carry the full name, address, telephone nos., e-
mail ID etc. of the agency submitting the Proposal.

<!-- page 4 -->

11.8 The outer envelope containing the sealed Technical and Financial Proposals should
be addressed to:
The Joint Director (OL)
Room No.754, ‘A’ Wing
Ministry of Health and Family Welfare,
: Nirman Bhawan, Maulana Azad Road,
New Delhi - 110011

11.9 Incomplete tenders and tenders received late will be summarily rejected.

11.10 An authorized representative of the firm should authenticate all pages of the
Technical and Financial Proposals either by putting initials or full signatures on
each page.

11.11 The Technical and Financial proposals should be submitted on or before
08.09.2017 latest by 1400 hrs.

11.12 No Proposal will be accepted after the deadline for submission and in the event of
any proposal being received after the closing time for submission of proposals, the
same shall be returned un-opened.

11.13. The proposals should be accompanied by an EMD in the form of a bank draft/
guarantee/FDR of Rs.2,000/- (Rupees Two thousand only) drawn in favour of
DDO, MoH&FW payable at New Delhi towards earnest money deposit (EMD).
Tenders received without EMD shall not be considered.

11.14 This Earnest Money Deposit (EMD) of Rs.2,000 (Rupees Two Thousand only) of
unsuccessful tenderers will be returned immediately after finalization of contract.
No interest will be payable on the said amount. The EMD of successful bidder
will be refunded on submission of Performance security.

11.15 The Ministry reserves its right to accept the tender either in full or in part.
Conditional, erroneous and incomplete Bids will be rejected outright.

11.16 The Ministry reserves its right to summarily reject offer received from any agency
on national security considerations, without any intimation to the bidder.

11.17 The Ministry reserves the right to place an order for the full or part quantities under
any items of work under scope of work.

11.18 Performance security of Rs.5000/- (Rupees Five thousand only) in the form of a
bank draft/guarantee/FDR drawn in favour of DDO, MoH&FW payable at New
Delhi shall be paid by successful bidder. It should remain valid for a period of 60
days beyond the date of completion of all contractual obligations.

12. Opening of Proposals and Selection Process

12.1 The Proposals received will be opened at 15.00 pm on 08.09.2017 in the presence
of authorized representatives of the agencies who have submitted proposals on or
before 08.09.2017 at 1400.

<!-- page 5 -->

12.2 First, the envelope titled “Technical Bid” of all bidders will be opened and bids
will be evaluated for technical criteria. The bids found qualified technically will be
announced to the present bidders/their representatives. Thereafter, financial bids of
only qualified technical bidders will be opened.

12.3. Out of the bids found qualified technically, the name of bidder with lowest
rate/value of financial bid (L1) will be announced to all the bidders. Other bidders
found qualified technically, will be offered to work on this rate and bidders
agreeing for the same will be required to submit their consent letter on the spot (in
Annexure IV format).

12.4 Thereafter, the qualified bidders will be required to submit on the spot all their
original documents, registration, proof of Office Address, PAN/TIN/TAN/
GSTIN, certificates for work experience and work completion before the
Evaluation Committee and the same will be returned on a date specified and
notified to all hitherto qualified bidders.

12.5 The final list of successful bidders will be displayed by the Evaluation Committee
within 03 days of the above process of submission and also notified to the
concerned.

12.6 The Technical Proposals will, in the first instance, be opened and examined in the
Ministry by an authorised Committee to ascertain fulfillment of eligibility criteria
and submission of required documents. Agencies who fulfill the eligibility criteria
and have submitted all required documents in their Technical Proposal will be
shortlisted.

12.7 Financial Bids of the shortlisted Agencies (agencies found technically responsive)
will be opened in the presence of authorized representatives of the agencies on a
date /time to be specified by the Ministry of Health and Family Welfare. Financial
evaluation would be based on lowest rate offered for total cost per word translated
including typing, proofreading, vetting .While opening financial bids, the rates
quoted by each Agency per word by each bidder would be communicated to all
verbally on the spot.

12.8 From the time the Technical Proposals are opened to the time the contract is
awarded, if any Agency wishes to contact the Ministry on any matter related to its
proposal, it should do so only in writing through email. Any effort by the Agency
to influence the Ministry in the proposal evaluation or contract award decisions
may result in rejection of the proposal of the Agency.

12.9 The rate of translation will be fixed on L-1 basis. Only those appropriate agencies
who give their consent to do translation work on this rate will be empanelled.
This _rate will remain fixed for the entire contract period of two years.
Empanelment will be for two years which could be extended depending upon the
performance of Agency/Firm.

12.10 In case of a tie for L1 rate, Agencies with more experience than above, having
worked for Government Departments, translated some books / documents etc. and
having some special accreditations/ ISO certificates etc. to be preferred.

12.11 The Ministry reserves the right to cancel the tender without assigning any reason,
to partly split the translation work and give it to any other agency at its discretion.

<!-- page 6 -->

12.12 The tender will remain valid for 45 days from the date of opening of tender.
13. Other Important Information
13.1 The selected agency will be responsible for any discrepancies with respect to the
translation.
13.2 Period of validity of the tender is 45 days from the closing date of the proposals.
13.3 Agencies submitting proposals will not be permitted to alter or modify their bids
after expiry of the deadline for receipt of bids.

~ 13.4 The Ministry reserves its right not to accept bids from agencies resorting to
unethical practices or on whom investigation/enquiry proceedings has been
initiated by Government Investigating Agencies / Vigilance Cell.

14. Penalty Clause: In case of backing out from the tendering, the EMD may be forfeited in
full or in part as decided by competent authority.

14.1. Incase of delay / untimely submission of work/assignments, a delay of 0.5% of
the contract value per day subject to a maximum of 10% of Contract Value will be
charged as Liquidated Damages on the Agency

14.2 After issue of the contract, the Performance Guarantee is liable to be forfeited in
full or part in case of underperformance by the agency, besides other action,
including blacklisting of the agency as may be deemed fit by the Ministry of
Health and Family Welfare, Govt. of India.

15. Termination: The Ministry may terminate the Contract of the agency in case of the
occurrence of any of the events specified below:

a. Ifthe Agency becomes insolvent or goes into compulsory liquidation.

b. If the Agency, in the judgment of Ministry has engaged in corrupt or fraudulent
practices in competing for or in executing this Contract.

c. Ifthe Agency submits to the Ministry a false statement which has a material effect on
the rights, obligations or interests of the Ministry.

d. If the Agency places itself in position of conflict of interest or fails to disclose
promptly any conflict of interest to the Ministry.

e. If the Agency fails to provide the quality services as envisaged under this Contract.
Reasons for the same would be recorded in writing. In such an occurrence the Ministry
shall give a written advance notice before terminating the Contract of Agency.

eee

<!-- page 7 -->

Annexure-II
TECHNICAL BID
| | Name of the Agency / Firm |: |
2. |Complete Address:
Tele No.
| Fax No.
E-mail)
3. | Enclose proof of work done in Central Ministries/
Department/ Organizations etc. (certificates, TDS
| deduction certificates, Work Completion
Certificates)
4. |(i) PAN No.
(ii) TIN/TAN No.
(iii) GSTIN No.
(Enclose copy of the same)
5. | Whether the tender documents have been signed Yes/No
and stamped, as a token of having read and
understood the terms and conditions contained
therein and submitted the same along with the
bid.
Declaration:-
I/We undertake that documents are genuine/authentic and nothing material has been concealed and
that I/We are not black listed/nor debarred by any Government organization. I/We understand that
the contract is liable to be cancelled, if found to be having obtained, through fraudulent
means/concealment of information. We have also understood the scope of work and other
schedule of requirements as stated in the invitation to tender.
(Signature of Authorized Signatory)

<!-- page 8 -->

SECTION 2: TECHNICAL PROPOSAL
I. TECHNICAL PROPOSAL SUBMISSION LETTER
: 1 लक ८०००५०० ०८०३)
From:
[Name of the Firm]
To:
The Joint Director (OL),
Ministry of Health and Family Welfare
R.No.754, ‘A’ Wing,
Nirman Bhawan, Maulana Azad Road,
New Delhi -— 110011
Subject : Translation work Hindi to English and vice versa Request
Sir / Madam,
We, the undersigned, offer to undertake the assignment of Translation work (Hindi to English and
vice versa) for the Ministry of Health and Family Welfare, Govt. of India, in accordance with
your Tender Document No................dated [................J. We hereby submit our Technical
Proposal for the same.
We understand you are not bound to accept any Proposal you receive.
Yours Sincerely,
Signature:
Name & Designation of the authorized Signatory:
Name of Firm: हक
Address हे आल जि जा
Phone
Mobile.

<!-- page 9 -->

Annexure-IIT
FINANCIAL BID
Name of the Agency/Firm :
Address :
Contact Tel. No. :
Name of the work Rate (in Rupees)
(1) | Translation Charges (per word) | Rs. (in figures), (in words)
| Hindi to English and vice versa
including Typing, vetting, proof
reading (inclusive of all taxes).
Signature of the authorized signatory.
Name of the Official of the Agency/Firm.
Date:
Place: Agency/Firm Seal

<!-- page 10 -->

Annexure IV
Consent Letter
(to be submitted after opening of Financial Bid)
106 ००००० रल्‍ऋ+ ०
From:
[Name of the Firm]
To:
The Joint Director (OL),
Ministry of Health and Family Welfare,
Room No.754, ‘C’ Wing,
Nirman Bhawan, Maulana Azad Road,
New Delhi-—110 011
Subject: Willingness to work at the L1 (lowest tendered) rate for Translation work in the
Ministry of Health & Family Welfare
Sir / Madam,
We, the undersigned, offer to undertake the assignment of Translation work (Hindi to English and
vice versa) for the Ministry of Health and Family Welfare, Govt. of India, in accordance with
your Tender Document No................dated [-eeseeeteteseesseeeeee]) We hereby submit our
Technical Proposal for the same.
We understand you are not bound to accept any Proposal you receive.
Yours Sincerely,
Signature:
Name & Designation of the authorized SIBMADOYS. ८००७२२६६७ ४३७०३ 1००४ ५५०० ०,००५
Name of Firm
Address i ले
Phone / Mobile No. ee eee ce
