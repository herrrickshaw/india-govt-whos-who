---
doc_id: "0dfae4b5936cdba7"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/f37a26a9f304efcf512018ad449707aa.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Cancellation of offer of appointment to the post of Assistant Divisional Engineering Telecom, JTS of ITS Group A in the Department of Telecommunications on the basis of the results of Engineering Services Examination, 2023 -reg."
date: "2025-03-25"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "16a28f1b278c5b4e"
---

<!-- page 1 -->

No. 7-1/2024-STG.II
Government of India
Ministry of Communications
Department of Telecommunications

419, Sanchar Bhawan, 20 Ashoka Road,
New Delhi-110001
Date: 24 March, 2025
To,
Shri Souvik Barman

5/0 Shri Paresh Chandra Barman
Ward No.10, Mathabhanga
P.O. Mathabhanga, District - Cooch Behar
West Bengal - 736146.

Sub: Cancellation of offer of appointment to the post of Assistant Divisional
Engineering Telecom (JTS of ITS Group °‘A’) in the Department of
Telecommunications on the basis of the results of Engineering Services
Examination, 2023 -reg.

Sir,
| am directed to refer to this office letter of even number dated 04.09.2024, vide
which an offer of appointment to the post of Assistant Divisional Engineering
Telecom (JTS of ITS Group ‘A) in this Department was issued to you on the basis
of Engineering Services Examination- 2023 and vide the said letter you were
directed to report O/o DG (NTIPRIT), Department of Teleommunciations, ALTTC
Campus, Ghaziabad- 201001 (Uttar Pradesh) on 23.09.2024.
2.
In response to that said offer of appointment dated 04.09.2024, vide email
dated 04.09.2024, you requested for extension in joining. Your request for
extension in joining was granted by this Department and you were directed 10
report O/o DG (NTIPRIT), Department of Telecommunications, ALTTC Campus,
Ghaziabad- 201001

(Uttar Pradesh) on or before 25.11.2024, vide letter of even

number dated 13.09.2024. However, as informed by NCA-T, Ghaziabad, you did
not join on 25.11.2024. Thereafter, reminder of even number dated 20.12.2024,
was issued to you and vide the said letter you were directed to report O/0 DG

(NTIPRIT),

201001

Department

of Telecommunications,

ALTTC

Campus,

Ghaziabad-

(Uttar Pradesh) on or before 30.12.2024. In response to that said reminder,

vide email dated 02.01.2025, you conveyed that you will not 06 able to join the post
of Assistant Divisional Engineering Telecom (JTS of ITS Group “A) in this
Department.
3. Therefore, in accordance 90175 letter of even number dated 04.09.2024, the
offer of appointment to the post of Assistant Divisional Engineering Telecom (JTS
of ITS Group ‘A’)" in this Department is cancelled .
4.

This is issues with the approval of competent authority.
Yours faithfully,

Digitally signed by
Sunil Kumar
(Bt KAd23)2025
Under Secretary to the Gavi2¢l India
Tele No: 2303 6282

<!-- page 2 -->

Copy to: i. DG (NTIPRIT), Ghaziabad, UP- 201001.

ii. Shri Harpreet Singh, Deputy Secretary (Rectt.), Sanchar Bhawan, New Delhi110001.

हा. Shri B.K. Singh, Under Secretary, UPSC, Dholpur House, Shahjahan Road,
New Delhi- 110069.
iv.

PSO

to Secretary/

Member

(Services)

DDG

Bhawan, New Delhi- 110001.
V. Web Administrator for uploading on DoT website.

vi. Guard File.

(Estt.),

DoT

HQ.,

Sanchar
