---
doc_id: "0dc4effcdee2552d"
source_url: "https://www.legislative.gov.in/static/uploads/2025/06/2d73c96fe9523136d58e418a31592b2c.pdf"
ministry: "Legislative Department (LD)"
title: "Action taken on the 251st Report of Law Commission-Letter dt 22 11 14 issued to State Governments"
date: "2014-11-22"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "93a4b34fba183056"
---

<!-- page 1 -->

<!-- page 2 -->

251ST REPORT of LAW COMMISSION OF INDIA
II.

ENACTMENT TO BE REPEALED BY PARLIAMENT IN CONSULTATION
WITH CONCERNED STATE GOVERNMENTS

S.No.

Short title of the Act

Subject

1.

Weekly Holidays Act,
1942 (18 of 1942)

Labour Laws

Recommendation
Commission of India

of

Law

Recommendation: Repeal subject
to factual verification
The Act provides for the grant of
weekly
holidays
to
persons
employed in shops, restaurants
and theatres. Section 4 of the Act
mandates
that
every
person
employed
in
a
position
of
management
in
any
shop,
restaurant or theatre shall be
allowed holiday of one whole day.
The purpose of this Act has been
subsumed by the Shops and
Establishments Acts of each State.
Hence, this Act can be repealed
subject to factual verification that
every State has a Shops and
Establishment Act.

2.

Prize Competitions
Act, 1955 (42 of 1955)

Trade
Commerce

and Recommendation: Repeal
This Act provides for the control
and
regulation
of
prize
competitions “in which prizes are
offered for the solution of any
puzzle based upon the building up,
arrangement,
combination
or
permutation, of letters, words or
figures” and do not involve use of
any skill. It largely applied to
competitions involving gambling
and betting in the States of
Bombay, Madras, Orissa, Uttar
Pradesh,
Hyderabad,
Madhya
Pradesh, Patiala and East Punjab
and all Part C States. However,
each of these states has its own
legislation pertaining to regulation
of gambling and betting. This Act
has fallen into disuse and its
purpose has been subsumed by
State-specific laws. Hence, this Act
can be repealed.
