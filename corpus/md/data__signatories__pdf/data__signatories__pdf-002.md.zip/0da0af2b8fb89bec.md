---
doc_id: "0da0af2b8fb89bec"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/94cb3229b1dcd61d22373a3f8041542f.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Change of panel of Sh. Himanshu Malik to Central Govt. Counsel for Punjab & Haryana HC :Order dated 26.11.2020"
date: "2020-11-26"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "842535fdcb2f2bb3"
---

<!-- page 1 -->

J-11017/10/2020- Judicial
Government of India
Ministry of Law & Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan New Delhi
Dated 26" November, 2020
ORDER
With reference to this Department's earlier Order with even number dated 204. 2020
the President is pleased to change the panel of Shri Himanshu Malik, Advocate in above
referred order, from Additional Central Government Counsel to Central Government Counsel
for the High Court of Punjab & Haryana for a period of three years with effect from the date of
this order or until further orders, whichever is earlier. The mobile number of Shri Himanshu
Malik may be read as 91-8685895982.
2. The engagement and professional fee of the aforesaid advocate will be governed by the
terms and conditions contained in this Department's OM No 26(1)/99-Judl. dated 24.09.1999
read with OM No. 26(1)/2014/Jud! dated 01.10.2015 & instructions issued subsequently through
OMs. The aforesaid OMs are available on the official website of this Department ie.
www.legalaffairs.gov.in under the tab Judicial Section & in the link ‘Circulars pertaining to
litigations’.
3. Hindi version of this order will follow.
Kida
(S. R. Mishra)
Additional Secretary
Copy to
4. PS to MLJ/PPS to Law Secretary/PPS to Secretary, Legislative Department/PPS to all
Lae Ara» | Secretaries/PS to all JS & LAs in the Main Secretariat.
A 2 Sir Satyapal Jain, Ld Additional Solicitor General of India, Kothi No 2224, Sector-15-C.
mh ie. (CHANT | $
«3s Shri. Chetan M Asstt. Solicitor High Court of Punjab & Haryana, House
: 1 handigarh-1600
- | rt of Punjab & Haryana.
। ite, 516/Se Chandigarh.
Legal Affairs for Hindi translation of the order.
| irs wit the request to upload this order on the website of
spare CO “
oe | शक 5 >
के (0. Srinivas)
a. Section Officer(Judicial)
हि 27"
