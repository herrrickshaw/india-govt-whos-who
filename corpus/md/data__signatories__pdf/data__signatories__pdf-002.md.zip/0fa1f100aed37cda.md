---
doc_id: "0fa1f100aed37cda"
source_url: "http://www.moef.gov.in/storage/tender/1789969652.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "G.S.R. 788(E).— राष्ट्रीय राजधानी क्षेत्र और आस-पास के इलाकों में वायु गुणवत्ता प्रबंधन आयोग (पराली जलाने के लिए पर्यावरण मुआवज़ा लगाने, वसूलने और इस्तेमाल करने से जुड़े) नियम, 2026 का मसौदा          PDF          आकार:  787.26 KB"
date: ""
pages: 7
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "c4a252c6e70937a8"
---

<!-- page 1 -->

रजिस्ट्रीसं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-16092026-276233
xxxGIDHxxx
CG-DL-E-16092026-276233
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 720]

नई दिल्ली, मंगलवार, जसतंबर 8, 2026/ भाद्र 17, 1948
NEW DELHI, TUESDAY, SEPTEMBER 8, 2026/ BHADRA 17, 1948

No. 720]

पर्ाावरण, वन और िलवार्ु पररवतान मंत्रालर्
अजधसूचना
नई दिल्ली, 8 जसतंबर, 2026
सा.का.जन. 788(अ).— कें द्रीर् सरकार वार्ु गुणवत्ता प्रबंधन आर्ोग अजधजनर्म, 2021 (2021 का 29) की धारा
25 की उप-धारा (2) के खंड (ि) द्वारा प्रित्त िजिर्ों का प्रर्ोग करते हुए, पराली िलाने के जलए पर्ाावरणीर् प्रजतकर
लगाने, संग्रहण और उपर्ोग से संबंजधत जनर्म बनाए िाने तथा दिनांक 28-04-2023 को सा.का.जन. 322 (अ) के माध्र्म
से प्रकाजित वार्ु गुणवत्ता प्रबंधन आर्ोग (राष्ट्रीर् रािधानी और जनकटवती के क्षेत्रों में पराली िलाने के जलए पर्ाावरणीर्
प्रजतकर का अजधरोपण, संग्रह और उपर्ोग) जनर्म, 2023 तथा दिनांक 06-11-2024 को सा.का.जन. 690 (अ) के माध्र्म
से प्रकाजित उसके संिोधन की अजधक्रमण करते हुए जनम्नजलजखत मसौिा अजधसूचना िारी करती है तथा उि मसौिा
अजधसूचना को इससे संभाजवत होने की वाली आम िनता एवं अन्र् जहतधारकों की िानकारी के जलए एतद्द्वारा प्रकाजित
करती है। इसके अलावार्ह भी सूजचत दकर्ा िाता है दक उि अजधसूचना को भारत के रािपत्र में प्रारूप अजधसूचना के
प्रकािन की तारीख से साठ दिनों की अवजध समाप्त होने के पश्चात कें द्र सरकार द्वारा इस पर जवचार दकर्ा िाएगा।
प्रारूप अजधसूचना में अंतर्वाष्ट प्रस्ट्तावों के संबंध में कोई व्यजि दकसी प्रकार की आपजत्त अथवा सुझाव िेना चाहता है, तो
वह जनधााररत अवजध के भीतर जलजखत रूप में डाक द्वारा संर्ि
ु सजचव, सीपी प्रभाग, छठा तल, पृथ्वी ववंग,इं दिरा
6927 GI/2026

(1)

<!-- page 2 -->

2

THEGAZETTEOFINDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

पर्ाावरण भवन, िोर बाग रोड, पर्ाावरण, वन और िलवार्ु पररवतान मंत्रालर्,नई दिल्ली-110003 को भेि सकता है
अथवा जनम्नजलजखत ई-मेल के पते पर इलेक्ट्रॉजनक माध्र्म से भेि सकता है:
v.pazhaniyandi@nic.in अथवा prasoon.tripathi76@gov.in

प्रारूप अजधसूचना
के न्द्रीर् सरकार राष्ट्रीर् रािधानी और जनकटवती क्षेत्रों में वार्ु गुणवत्ता प्रबंधन आर्ोग अजधजनर्म, 2021 (2021
का 29) की धारा 25 की उप-धारा (2) के खंड (ि) द्वारा प्रित्त िजिर्ों का प्रर्ोग करते हुए तथा राष्ट्रीर् रािधानी क्षेत्र
और जनकटवती के क्षेत्रों में वार्ु गुणवत्ता
प्रबंधन आर्ोग (पराली िलाने पर पर्ाावरणीर् प्रजतकर का अजधरोपण, संग्रह और उपर्ोग) जनर्म, 2023 के अजधक्रमण में,
ऐसे अजधक्रमण से पूवा दकए िाने वाले अथवा न दकए िाने वाले कार्ों के संबंध में अपवाि को छोड़कर, वार्ु गुणवत्ता
प्रबंधन आर्ोग के परामिा से, जनम्नजलजखत जनर्म बनाती है, अथाात्:—
1.

संजक्षप्त नाम, और और प्रारं भ होना .— (1) इन जनर्मों का संजक्षप्त नाम राष्ट्रीर् रािधानी और जनकटवती क्षेत्रों में

वार्ु गुणवत्ता प्रबंधन आर्ोग (पराली िलाने पर पर्ाावरणीर् प्रजतकर का अजधरोपण, संग्रह और उपर्ोग) जनर्म, 2026
कहा िा सकता है।
(2) र्े राष्ट्रीर् रािधानी क्षेत्र दिल्ली, पंिाब राज्र्, हररर्ाणा राज्र् तथा रािस्ट्थान और उत्तर प्रिेि में लागू होंगे।
(3) र्े रािपत्र में उनके प्रकािन की तारीख को प्रवृत्त होंगे।
2.

पररभाषाएँ.—(1) इन जनर्मों में, िब तक संिभा से अन्र्था अपेजक्षत न हो के जसवार्,—

(क) "अजधजनर्म" से राष्ट्रीर् रािधानी और जनकटवती के क्षेत्रों में वार्ु गुणवत्ता प्रबंधन आर्ोग अजधजनर्म, 2021 (2021
का 29) अजभप्रेत है;
(ख) "आर्ोग" से धारा 3 के अधीन गरठत राष्ट्रीर् रािधानी और जनकटवती के क्षेत्रों में वार्ु गुणवत्ता प्रबंधन आर्ोग
अजभप्रेत है;
(ग) "कृ षक" से खेती र्ा कृ जष उपि भूजम का स्ट्वामीर्ा अजधभोगी र्ा काश्तकार अजभप्रेत है;
(घ) "धारा" से अजधजनर्म की धारा अजभप्रेत है।
(2) उन िब्िों और पिों को िो इसमें प्रर्ुि हैं और पररभाजषत नहीं हैं, ककं तु अजधजनर्म में पररभाजषत हैं, वही अथा होंगे िो
उस अजधजनर्म में हैं।
3.

पराली िलाने के जलए पर्ाावरणीर् प्रजतकर का अजधरोपण.— आर्ोग, अजधजनर्म के प्रावधानों के अनुसार,

पराली िलाने के जलए जनम्नजलजखत िरों पर पर्ाावरणीर् प्रजतकर अजधरोजपत कर सकता है:—
(क) िो एकड़ से कम भूजम वाले कृ षक प्रत्र्ेक घटना के जलए पाँच हिार रुपर्े के पर्ाावरणीर् प्रजतकर के संिार् का भुगतान
करें ग;े
(ख) िो एकड़ र्ा उससे अजधक ककं तु पाँच एकड़ से कम भूजम वाले कृ षक प्रत्र्ेक घटना के जलए िस हिार रुपर्े के
पर्ाावरणीर् प्रजतकर के संिार् का भुगतान करें ग;े

<!-- page 3 -->

[भागII—खण्ड3(i)]

3

भारत का रािपत्र : असाधारण

(ग) पाँच एकड़ से अजधक भूजम वाले कृ षक प्रत्र्ेक घटना के जलए तीस हिार रुपर्े के पर्ाावरणीर् प्रजतकर के संिार् का
भुगतान करें गे।
4.

पराली िलाने के जलए पर्ाावरणीर् क्षजतपूर्ता का संग्रहण.—(1) पर्ाावरणीर् प्रजतकर इन जनर्मों से उपाबद्ध प्ररूप

में जनर्िाष्ट चालान के रूप में कृ षक से संग्रहीत दकर्ा िाएगा।
(2) कृ षक इन जनर्मों के अधीन चालान िारी होने की तारीख से तीस दिन से अनजधक अवजध के भीतर चालान के अनुसार
राजि को करेगा;
(3) र्दि दकसान उप-जनर्म (2) में जनर्िाष्ट अवजध के भीतर चालान की राजि का भुगतान करने में जवफल रहता है, आर्ोग,
कृ षक से िेर् राजि को जवजनर्िाष्ट करते हुए एक प्रमाण-पत्र तैर्ार करेगा और उस प्रमाण-पत्र को चालान प्रपत्र के साथ
संबंजधत राज्र् सरकार र्ा, र्थाजस्ट्थजत, संघ राज्र् क्षेत्र द्वारा इस संबंध में प्राजधकृ त अजधकारी को भेिेगा;
(4) उप-जनर्म (3) में जनर्िाष्ट अजधकारी, प्रमाण-पत्र और चालान प्रपत्र प्राप्त होने पर, उसमें जवजनर्िाष्ट राजि को कृ षक से
ऐसे वसूल करेगा िैसे दक र्ह भूजम रािस्ट्व का बकार्ा हो;
(5) संबंजधत राज्र् सरकार र्ा संघ राज्र् क्षेत्र में प्रचजलत भूजम रािस्ट्व अजभलेख का रखरखाव करने वाला संबंजधत राज्र्
सरकार र्ा संघ राज्र् क्षेत्र का अजधकारी र्ह सुजनजश्चत करेगा दक जिस भूजम पर पराली िलाने की ऐसी घटना की सूचना
प्राप्त हुई है र्ा इस बात का प्रमाण है दक भूजम में पराली िलाने की घटना घरटत हुई है, उस भूजम के जवरुद्ध उि अजभलेख
में लाल प्रजवजष्ट जचजन्हत की िाए।
(6) उप-जनर्म (5) में जनर्िाष्ट लाल प्रजवजष्ट उि घटना की तारीख से पंद्रह महीने की अवजध तक वैध रहेगी और उि अवजध
की समाजप्त पर, र्दि उस अवजध के िौरान उि भूजम पर पराली िलाने की कोई बाि की घटना घरटत होना नहीं पार्ा गर्ा
है र्ा अन्र्था प्रमाजणत नहीं हुआ है तथा इन जनर्मों के अधीन अजधरोजपत पर्ाावरणीर् प्रजतकर, र्दि कोई हो, िमा कर िी
गई है, तो उसे हटार्ा हुआ माना िाएगा:
बिते दक, र्दि उि भूजम पर पराली िलाने की कोई घटना बाि में पाई िाती है अथवा र्ह अन्र्था प्रमाजणत हो िाता है
दक ऐसी घटना घरटत हुई है र्ा इन जनर्मों के तहत अजधरोजपत कोई पर्ाावरणीर् प्रजतकर, उि अवजध के भीतर िमा नहीं
दकर्ा गर्ा है, तो लाल प्रजवजष्ट पंद्रह माह की अगामी अवजध के जलए वैध रहेगी;
(7) इस जनर्म के तहत संग्रह की गई पर्ाावरण क्षजतपूर्ता राजि को संबंजधत राज्र् प्रिूषण जनर्ंत्रण बोडा र्ा प्रिूषण जनर्ंत्रण
सजमजत के खाते में िमा दकर्ा िाएगा।
5. पराली िलाने के जलए पर्ाावरणीर् मुआविे का उपर्ोग-(1) स्ट्व-स्ट्थाने फसल अवजिष्ट प्रबंधन उपकरण और मिीनरी
िैसी अवजिष्ट प्रबंधन प्रौद्योजगदकर्ों को आर्थाक सहार्ता प्रिान करना:
(2) फसल जवजवधीकरण कार्ाक्रमों को बढावा िेना;
(3) बार्ोमास उपर्ोग और भंडारण अवसंरचना के जवकास और संचालन में सहार्ता करना;
(4) फसल अवजिष्ट प्रबंधन के क्षेत्र में अनुसंधान और जवकास के जलए जवत्तपोषण;
(5) संधारणीर् खेती के जलए पर्ाावरण-अनुकूल संधारणीर् कार्ापद्धजतर्ों पर दकसानों को जिजक्षत और प्रजिजक्षत करना;
और
(6) ऐसे अन्र् उपार् िो आर्ोग द्वारा, र्ा दिल्ली-राष्ट्रीर् रािधानी क्षेत्र और जनकटवती क्षेत्रों में राज्र् सरकारों द्वारा,
अपने-अपने अजधकार क्षेत्र में, पराली िलाने के जनवारण और जनर्ंत्रण के जलए आवश्र्क समझे िाएं।
[फा. सं. एच-11013/03/2022-सीपीडब्ल्र्ू]
उिर् चौधरी, संर्ुि सजचव

<!-- page 4 -->

4

THEGAZETTEOFINDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

प्रपत्र
(जनर्म 3 और जनर्म 4 िेख)ें
चालान सं.
दिनांक : ……../……../………
चालान
राष्ट्रीर् रािधानी क्षेत्र और जनकटवती क्षेत्रों में वार्ु गुणवत्ता प्रबंधन आर्ोग अजधजनर्म, 2021 (2021 का 29) और राष्ट्रीर् रािधानी
क्षेत्र और जनकटवती क्षेत्रों में वार्ु गुणवत्ता प्रबंधन आर्ोग (पराली िलाने पर पर्ाावरणीर् प्रजतघर का अजधरोपण, संग्रह और उपर्ोग)
जनर्म, 2026 की धारा 15 के अनुपालन में, जनम्नोजल्लजखत दकसान को पराली िलाते हुए पार्ा गर्ा/ररपोटा दकर्ा गर्ा है र्ा इस बात
का प्रमाण है दक उसकी भूजम में पराली िलाई गई है, और पररणामतः अजधजनर्म और ऊध्वोजल्लजखत जनर्मों के अनुसार पर्ाावरणीर्
प्रजतकर अजधरोजपत दकर्ा गर्ा है, और उसे जनम्नजलजखत जववरण के अनुसार ऐसा पर्ाावरण प्रजतकर िमा करने का जनिेि दिर्ा िाता
है, अथाात्:1. दकसान का नाम:
2. मकान संख्र्ा:
3. गली:
4. ग्राम:
5. डाकघर :
6. तहसील:
7. जिला:
8. राज्र्:
9. संपका नं.:
10. भूजम का जववरण जिसमें भूजम की खसरा, खेवट और खतोनी संख्र्ा िाजमल है:
11. पराली िलाने के जलए भूजम िेने वाले दकसान की भूजम का क्षेत्रफल (उजचत बॉक्ट्स पर रटक करें )
i

2 एकड़ से कम

ii

2 से 5 एकड़ के बीच

iii

5 एकड़ से अजधक

ऊपर नाजमत दकसान चालान की तारीख से तीस दिनों के भीतर, र्था जस्ट्थजत ----------रुपर्े (िब्िों में -------रुपर्े मात्र) का
पर्ाावरणीर् प्रजतकर नकि र्ा जडमांड ड्राफ्ट के माध्र्म से अथवा इलेक्ट्रॉजनक माध्र्म से संबंजधत राज्र् प्रिूषण जनर्ंत्रण बोडा र्ा प्रिूषण
जनर्ंत्रण सजमजत के खाते में िमा कर सकता है।
हस्ट्ताक्षर:
नाम:
पिनाम:
पता:
अजधकारी की मुहर:
संपका नं.:

<!-- page 5 -->

[भागII—खण्ड3(i)]

भारत का रािपत्र : असाधारण

5

MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 8th September, 2026
G.S.R. 788(E).—The following draft notification which the Central Government proposes to issue, in
exercise of the powers conferred by clause (h) of sub-section (2) of section 25 of the Commission for Air Quality
Managmeent in National Capital Region and Adjoining Areas Act, 2021 (29 of 2021), for bringing out rules relating
to imposition, collection and utilisation of Environmental Compensation for Stubble Burning and also in
supersession of the Commission for Air Quality Management in National Capital Region and Adjoining Areas
(Imposition, Collection and utilisation of Environmental Compensation for Stubble Burning ) Rules, 2023 published
vide G.S.R. 322 (E) dt. 28-04-2023 and its amendment published vide G.S.R 690 (E) dt. 6-11-2024, is hereby
published for information of the public and other stakeholders likely to be affected. Further, notice is hereby given
that the said notification will be taken into consideration by the Central Government on or after the expiry of sixty
days from the date on which the draft notification is published in the Gazette of India;
Any person interested in making any objection or suggestion on the proposals contained in the draft notification may
do so in writing within the period so specified through post to the Joint Secretary, CP Division,6th Floor, Prithvi
Wing, Indira ParyavaranBhawan,JorBagh Road, Min. of Environment, Forest & Climate Change, New Delhi110003 or electronically at email address:
v.pazhaniyandi@nic.inOR prasoon.tripathi76@gov.in.

DRAFT NOTIFICATION
In exercise of the powers conferred by clause (h) of sub-section (2) of section 25 of the Commission for Air
Quality Management in National Capital Region and Adjoining Areas Act, 2021 (29 of 2021) and in supersession of
the Commission for Air Quality Managmeent in National Capital Region and Adjoining Areas (Imposition,
Collection and utilisation of Environmental Compensation for Stubble Burning ) Rules, 2023, except as respects
things to be done or omitted to be done before such supersession, the Central Government, in consultation with the
Commission for Air Quality Management in National Capital Region and Adjoining Areas, hereby makes the
following rules, namely:1. Short title and commencement.-(1) These rules may be called the Commission for Air Quality Management in
National Capital Region and Adjoining Areas (Imposition, Collection and Utilization of Environmental Compensation
for Stubble Burning) Rules, 2026.
(2) They shall apply to the National Capital territory of Delhi, State of Punjab, State of Haryana and National Capital
Region of Rajasthan and Uttar Pradesh.
(3) They shall come into force on the date of their publication in the Official Gazette.
2. Definitions.-(1) In these rules, unless the context otherwise requires, (a) "Act" means the Commission for Air Quality Management in National Capital Region and Adjoining Areas Act,
2021 (29 of 2021);
(b) "Commission" means the Commission for Air Quality Management in National Capital Region and adjoining
areas constituted under section 3;
(c) "Farmer" means the owner or occupier or cultivator of the farming or agricultural land;
(d) "Section" means a section of the Act.
(2) Words and expressions used herein and not defined but defined in the Act shall have the same meanings as
assigned to them in the Act.

<!-- page 6 -->

6

THEGAZETTEOFINDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

3. Imposition of environmental compensation for stubble burning.—The Commission may impose environmental
compensation as per the provisions of the Act for stubble burning, at the following rates:(a) the Farmer having an area of land of less than two acres shall pay an environmental compensation of five thousand
rupees, per incidence;
(b) the Farmer having an area of land of two acres or more but less than five acres shall pay an environmental
compensation of ten thousand rupees, per incidence;
(c) the Farmer having an area of land of more than five acres shall pay an environmental compensation of thirty
thousand rupees, per incidence.”.
4. Collection of Environmental Compensation for stubble burning.—(1) The environmental compensation shall
be collected from the Farmer in the form of challan as specified in Form annexed to these rules;
(2) The Farmer shall pay the amount in pursuance of challan under these rules within a period not exceeding thirty
days from the date of issuance of form of challan;
(3) If the Farmer fails to pay the challan amount within the period specified under sub-rule (2), the Commission shall
prepare a certificate specifying the amount due from the Farmer and forward the certificate along with the form of
challan to the officer authorised by the respective State Government or, Union territory, as the case may be, in this
regard;
(4) The officer referred to in sub-rule (3) shall, on receipt of the certificate and the form of challan, shall proceed to
recover the amount specified thereunder from the Farmer as if it were an arrear of the land revenue;
(5) The officer of the respective State Government or, Union Territory who maintains the land revenue record as
prevalent in the respective State Government or, Union Territory shall ensure that such record is marked with red
entry against the land on which such incident of stubble burning is found or otherwise established to have occurred in
the land.
(6) The red entry referred to in sub-rule (5), shall remain valid for a period of fifteen months from the date of said
incident and shall, upon expiry of the said period, be deemed to have been removed, if no subsequent incident of
stubble burning is found or otherwise established to have occurred on the said land during the said period and
environmental compensation, if any, imposed under these rules has been deposited:
Provided that where any subsequent incident of stubble burning is found or otherwise established to have
occurred on the said land or environmental compensation, if any, imposed under these rules has not been deposited
within the said period, the red entry shall remain valid for a further period of fifteen months;
(7) The environmental compensation collected under this rule shall be deposited in the account of respective State
Pollution Control Board or Pollution Control Committee.
5. Utilisation of Environmental Compensation for stubble burning.—(1) subsidizing residue management
technologies such as in-situ crop residue management equipment and machinery:
(2) incentivizing crop diversification programmes;
(3) supporting development and operation of biomass utilization and storage infrastructure;
(4) funding research and development in the area of crop residue management;
(5) educating and training farmers on eco-friendly sustainable practices for sustainable farming; and
(6) such other measures as may be deemed necessary by the Commission, or by the State Governments, in Delhi-

<!-- page 7 -->

[भागII—खण्ड3(i)]

7

भारत का रािपत्र : असाधारण

National Capital Region and adjoining areas, in their respective jurisdictions, for the prevention and control of stubble
burning.
[F. No. H-11013/03/2022-CPW]
UDAY CHAUDHARI, Jt. Secy.
FORM
(See rule 3 and rule 4)
Challan No.
Dated: …./…./…...
CHALLAN
In pursuance of the section 15 of the Commission for Air Quality Management in National Capital Region and
Adjoining Areas Act, 2021 (29 of 2021) and the Commission for Air Quality Management in National Capital Region
and Adjoining Areas (Imposition, Collection and Utilization of Environmental Compensation for Stubble Burning)
Rules, 2026, the Farmer described below was found/ has been reported to burn stubble or there is an evidence to the
effect that Stubble Burning has happened in his land, and consequently Environmental Compensation has been
imposed as per the Act and the rules mentioned above, and is directed to deposit such Environmental Compensation as
per the following details, namely:1. Name of the Farmer:
2. House No.:
3. Street:
4. Village:
5. Post Office :
6. Tehsil:
7. District:
8. State:
9. Contact No.:
10. Details of land including Khasra, Khewat and Khatoni number of the land:
11. The area of land of the farmer who has resorted to stubble burning: (tick the appropriate box
i

Less than 2 acres

ii Between 2 to 5 acres

iii

More than 5 acres

The Farmer named above may deposit the Environmental Compensation of Rupees____________________ (in
words_____________________ only), through Cash or Demand Draft or through electronic mode in the account of
respective State Pollution Control Board or the Pollution Control Committee, as the case may be within thirty days
from the date of Challan.
Signature:
Name:
Designation:
Address:
Seal of the Officer:
Contact No:
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
KUMER Digitally signed

CHAND
MEENA

by KUMER
CHAND MEENA
Date: 2026.09.16
14:18:21 +05'30'
