---
doc_id: "0c3eeeb91ba8b93f"
source_url: "https://mohua.gov.in/static/uploads/2025/10/c1068177145704634a4f286bd85f5658.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Annexure"
date: "2025-10-16"
pages: 150
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c99110172e7bedfb"
---

<!-- page 1 -->

ANNEXURES

<!-- page 2 -->

<!-- page 3 -->

ANNEXURE 1.1. BASE DATA FOR 87
URBAN CENTERS IN INDIA

<!-- page 4 -->

<!-- page 5 -->

BASE DATA FOR 87 URBAN CENTERS IN INDIA
Capital
City

PCI
1998-1999

PCI
2001-2002

Shape of the
Town

Public
Transport
Availability

Type

S.No

1a

1

Kavaratti

LAK

-

0.10

32

316

Y

Circular

N

Mini buses,Tourist Taxis, Auto
Rick-shaws

Tourist, Education

2

Silvasa

DAD

0.117

0.22

491

45

Y

Linear

N

Auto-rickshaws

Industrial

3

Itanagar

ARU

0.165

0.35

110

318

Y

Linear

N

4

Daman

DAM

-

0.36

122

293

Y

Linear

N

5

Kohima

NAG

0.514

0.79

20

3,929

Y

Hilly

N

6

Gangtok

SIK

0.780

0.92

77

1,195

Y

Hilly

N

7

Panaji

GOA

0.722

0.97

23

4,217

Y

Semi Circular

Y

8

Port Blair

ANI

0.750

1.00

467

215

Y

Linear

Y

1b

9

Shimla

HP

1.304

1.73

100

1,730

Y

Hilly

1a

10

Agartala

TRI

1.574

1.89

58.84

3,218

Y

11

Gandhinagar

GUJ

1.234

1.96

57

3,438

1b

12

Aizawl

MIZ

1.552

2.28

572

1a

13

Imphal

MAN

2.028

2.50

1b

14

Shillong

MEG

2.234

2.68

15

Guntūr

AP

4.711

16

Belgaum

KAR

17

Pondicherry

18

1a

State

Public Transport Details

Population
Density
(based on
2001 pop)

Category name

1b

City Name

Population in Population in Area (Sq.
Lakhs (1991) Lakhs (2001)
Km)

Bus

Local Train

Metro

Tram

Others

If others

Mini buses,Tourist Taxis, Cycle
Rick-shaws
Mini buses,Tourist Taxis, Auto
Rick-shaws
Taxis

Administrative , Tourist
Tourist, Education
Tourist, Administrative

Private Taxis, Jeeps and
Landrovers
Two-Wheelers, Auto-Rickshaws,
Cars, Taxis, Tourist Coaches,
Taxis, Cycle-Rickshaws, Auto
Rickshaws, Ferry

Administrative , Tourist

Y

Jeeps, Taxis

Tourist

Linear

N

Private Taxis

Tourist, Administrative

Y

Circular

Y

Auto-Rickshaws, Taxis

Administrative

399

Y

Hilly

Y

Taxis

Tourist, Administrative

30

8,341

Y

Linear

N

Taxis

Tourist, Administrative

10.36

25,857

Y

Hilly

N

Taxis

Tourist, Administrative

5.00

-

N

7416

10,590

Semi Circular

Y

Taxis, Cycle-Rickshaws

Industrial

4.024

5.06

-

N

7838

11,516

Linear

Y

Auto-rickshaws

Administrative

PON

3.991

5.08

1,752

Y

9781

23,178

Semi Circular

Y

Two types of rickshaws are
available, the pedalled and the

Tourist, Education

Bhāvnagar

GUJ

4.052

5.18

-

N

9796

13,684

Circular

Y

Auto-Rickshaws

Industrial

19

Dehra Dūn

UAR

3.681

5.28

-

Y

6755

7,937

Circular

Y

Taxis, Cycle-Rickshaws

Tourist, Education

20

Mangalore

KAR

4.263

5.39

4,844

N

7838

11,516

Circular

Y

Taxis, Auto-rickshaws

Industrial

21

Tiruppur

TN

3.062

5.43

-

N

8955

12,717

Linear

Y

Auto-rickshaws

Industrial

22

Amrāvati

MAH

4.216

5.50

9,345

N

12183

14,892

Linear

Y

Taxis, Auto-rickshaws, Tongas

Tourist, Education

23

Jamnagar

GUJ

3.260

5.58

-

N

9796

13,684

Semi Circular

Y

Taxis, Auto-rickshaws

Industrial
Industrial

24

Warangal

AP

4.678

5.77

25

Cuttack

ORI

4.403

5.88

26

Jammu

J&K

3.000

6.08

27

Bhiwandi

MAH

3.922

6.21

28

Gorakhpur

UP

5.056

6.23

29

Bīkāner

RAJ

4.963

6.40

30

Morādābād

UP

4.437

6.41

290

111

59

60

300

270

Administrative

Administrative

-

N

7416

10,590

Circular

Y

Taxis, Auto-rickshaws, Cyclerickshaws

9,865

N

4896

5,927

Linear

N

Taxis, Auto-rickshaws

Tourist

-

N

6543

7,541

Semi Circular

Y

Mini buses,Tourist Taxis

Tourist

2,071

N

12183

14,892

Linear

Y

-

N

5066

5,687

Circular

Y

2,370

N

6182

8,571

Circular

N

Taxis, Auto-rickshaws, Tongas

Tourist

-

N

5066

5,687

Linear

Y

Taxis

Administrative

A-1

Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws

Industrial
Industrial

<!-- page 6 -->

Category name

2

S.No

City Name

State

Population in Population in Area (Sq.
Km)
Lakhs (1991) Lakhs (2001)

Public Transport Details

Population
Density
(based on
2001 pop)

Capital
City

PCI
1998-1999

PCI
2001-2002

Shape of the
Town

Public
Transport
Availability

Bus

Local Train

Metro

Tram

Others

If others

Type

31

Alīgarh

UP

4.805

6.68

-

N

5066

5,687

Circular

Y

Taxis

Administrative

32

Kota

RAJ

5.374

7.05

-

N

6182

8,571

Linear

N

Taxis, Auto-rickshaws, Tongas,
Cycle-rickshaws, Tempos

Inudstrial, Education

33

Jalandhar

PUN

5.095

7.09

-

N

12710

15,210

Linear

Y

Taxis

Administrative

34

Raipur

CHH

4.913

7.19

3,824

Y

6539

7,303

Linear

N

Taxis, Auto-rickshaws, Cyclerickshaws

Administrative, Agriculture

35

Bareilly

UP

6.174

7.30

-

N

5066

5,687

Circular

N

Taxis

Administrative, Agriculture

36

Salem

TN

5.783

7.49

94

7,963

N

8955

12,717

Semi Circular

Y

Taxis, Autorickshaws

Industrial

37

Mysore

KAR

6.533

7.86

81

9,761

N

7838

11,516

Circular

Y

Taxis, Autorickshaws

Tourist

38

Dispur

ASS

0.000

8.19

-

Y

39

Bhubaneswar

ORI

6.431

8.44

3,622

Y

40

Tiruchchirappalli

TN

7.119

188

233

8.47

41

Jodhpur

RAJ

6.663

8.56

42

Ranchi

JHA

6.148

43

Gwalior

MP

44

Sholapur

45

76

N

N
4896
8955

5,927
12,717

Semi Circular
Semi Circular

Y
Y

Mini buses,Tourist Taxis, Auto
Rick-shaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Autorickshaws

Tourist, Administrative
Tourist, Pilgrim
Industrial, Trade &
Commercial

Taxis, Auto-rickshaws, Tongas,
Bi- Cycles
Taxis, Scooters, Cycle
Rickshaws
Local taxis, Auto rickshaws, and
Six - seater Tempos

Administrative, industrial

Tourist

11,338

N

6182

8,571

Semi Circular

N

8.63

-

Y

N/A

N/A

Circular

Y

7.178

8.66

-

N

6584

7,699

Semi Circular

N

MAH

6.208

8.73

4,905

N

12183

14,892

Semi Circular

Y

Taxis, Autorickshaws

Administrative

Calicut

KER

8.012

8.80

-

N

7938

10,709

Semi Circular

Y

Taxis, Autorickshaws

Administrative

46

Bhilai (Bhilai
Nagar)

CHH

6.855

9.24

-

N

18166

26,550

Semi Circular

N

47

Chandigarh

HAR

7.162

9.66

264

3,659

Y

19761

28,271

Circular

Y

48

Hubli-Dharwar

KAR

6.483

9.68

150

6,453

N

7838

11,516

Linear

Y

49

Ghaziabad

UP

5.118

9.69

-

N

5066

5,687

Semi Circular

N

50

Rajkot

GUJ

6.545

10.00

-

N

9796

13684

Linear

N

51

Vijayawada

AP

8.458

10.34

9,359

N

7416

10590

Semi Circular

Y

52

Faridabad

HAR

6.177

10.50

-

N

11079

14250

Linear

Y

53

Allahabad

UP

8.445

10.50

16,648

N

5066

5687

Linear

Y

54

Dhanbad

JHA

8.150

10.60

-

N

N/A

N/A

Linear

N

55

Gauhati

ASS

7.284

10.60

200

5,300

N

5715

6,059

Semi Circular

Y

Mini bus, Taxis

Administrative, Trade &
Commercial

56

Amritsar

PUN

7.088

10.85

150

7,233

N

12710

15,210

Linear

N

Cycle Rickshaws, Taxis

Piligrim, Administrative

57

Asansol

WB

7.639

10.90

-

Y

6756

10375

Linear

N

Taxis

Industrial
Industrial

178

110.44

63

Taxis, Autorickshaws,Cyclerickshaws
Taxis, Autorickshaws,Cyclerickshaws
Taxis, Autorickshaws,Cyclerickshaws,Tongas
Taxis, Autorickshaws,Cyclerickshaws
Unmetered taxis, Auto
rickshaws, Tongas and few
private cars.
Tourist Taxis, Metered Taxis,
Auto rickshaws, and Cycle
Rickshaws
Tourist Taxis, Metered Taxis,
Auto rickshaws, and Cycle
Rickshaws
Tourist Taxis, Metered Taxis,
Auto rickshaws, and Cycle
Rickshaws
Taxis, Scooters, Cycle
Rickshaws

Administrative

Administrative
Adninistrative
Education & Commercial
Administrative
Administrative

Commercial

Industrial

Mining

58

Jamshedpur

JHA

8.292

11.00

64

17,188

N

N/A

N/A

Linear

N

Taxis, Scooters, Cycle
Rickshaws

59

Srinagar

J&K

7.400

11.10

105

10,571

Y

6543

7,541

Semi Circular

Y

Mini buses,Tourist Taxis

Toruist

60

Jabalpur

MP

8.889

11.20

-

N

6584

7699

Linear

Y

Mini buses,Tourist Taxis

Administrative, Education

A-2

<!-- page 7 -->

S.No

3

61

Trivandrum

KER

10.352

11.22

62

Nashik

MAH

7.253

11.52

4

City Name

State

Population in Population in Area (Sq.
Lakhs (1991) Lakhs (2001)
Km)

Category name

63

Meerut

UP

8.498

11.61

64

Madurai

TN

9.412

11.85

65

Visakhapatnam

AP

10.571

13.46

66

Agra

UP

10.280

13.69

67

Ludhiana

PUN

10.427

14.00

310

Public Transport Details

Population
Density
(based on
2001 pop)

Capital
City

PCI
1998-1999

PCI
2001-2002

Shape of the
Town

Public
Transport
Availability

3,619

Y

7938

10,709

Semi Circular

Y

-

N

12183

14892

Linear

Bus

Local Train

Metro

Tram

Others

If others

Type

Taxis, Autorickshaws, two
wheelers

Administrative & Education

Y

Taxis

Piligrim
Industrial

-

N

5066

5687

Linear

N

Taxis, cycle rickshaws, autorickshaws

1,619

N

8955

12,717

Linear

Y

Taxis

Tourst, Education

-

N

7416

10590

Semi Circular

Y

Taxis and Auto-rickshaws

Administrative, Industrial

200

6,845

N

5066

5,687

Linear

N

Taxi, tempo, auto-rickshaw and
cycle rickshaw

Tourist

159

8,785

N

12710

15210

Linear

Y

Taxis and Auto-rickshaws

Industrial

732

Taxis, Mini Buses and Autorickshaws
Taxis, Mini Buses and Autorickshaws
Taxis, Mini Buses and Autorickshaws

68

Bhopal

MP

10.628

14.58

320

4,556

Y

6584

7,699

Linear

Y

69

Vadodara

GUJ

11.268

14.93

148

10,073

N

9796

13684

Semi Circular

Y

70

Indore

MP

11.091

16.93

-

N

6584

7699

Linear

Y

71

Coimbatore

TN

11.007

16.95

106

16,066

N

8955

12717

Linear

Y

Taxis,Auto-rickshaws

Industrial, Educational

72

Kochi

KER

16.6

18.18

730

2490.41096

N

7938

10709

Linear

Y

Ferry, Auto -rickshaws

Industrial

73

Patna

BIH

12.865

18.36

136

13,500

Y

3037

3,554

Linear

Y

Tempos, Cycle Rickshaws

Administrative

74

Varanasi

UP

15.309

18.95

85

22,294

N

5066

5,687

Linear

N

Cycle-rickshaws, Autorickshaws

Piligrim

75

Nagpur

MAH

16.210

21.13

270

7,826

N

12183

14,892

Circular

Y

Share cabs and Autos

Commercial &
Administration

76

Lucknow

UP

16.692

22.46

338

6,655

Y

5066

5687

Circular

Y

Share cabs and Jeeps

Administrative
Tourist
Industrial, Commercial

77

Jaipur

RAJ

18.182

26.80

544

4,926

Y

6182

8,571

Circular

Y

Taxis, Auto-rickshaws, Cyclerickshaws

78

Kanpur

UP

19.940

27.16

597

4,549

N

5066

5,687

Linear

Y

Tempos, Cycle Rickshaws

79

Surat

GUJ

17.172

30.90

680

4,544

N

9796

13,684

Linear

N

80

Pune

MAH

30.660

42.00

700

6,000

N

12183

14,892

Circular

Y

81

Ahmadabad

GUJ

43.462

59.34

1,330

4,462

N

9796

13,684

Circular

Y

82

Hyderabad

AP

46.444

63.83

900

7,092

Y

7416

10,590

Circular

Y

83

Chennai

TN

58.190

70.14

1,189

5,899

Y

8955

12,717

Circular

Y

84

Bangalore

KAR

63.303

86.25

1,279

6,744

Y

7838

11,516

Circular

Y

85

Delhi

DEL

94.191

138.50

1,758

7,878

Y

18166

26,550

Circular

Y

86

Kolkata

WES

126.492

147.38

1,851

7,962

Y

6756

10,375

Linear

Y

87

Greater Mumbai

MAH

145.262

177.02

4,355

4,065

Y

5811

6,715

Linear

Y

5

6

A-3

Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws
Taxis, Auto-rickshaws, Cyclerickshaws

Administrative & Industrial
Industrial
Industrial, Commercial

Industrial
Industrial & Education
Administrative, Industrial &
Commercial
Administrative
Administrative, industrial
Administrative and
Commercial
Administrative and
Commercial
Administrative and
Commercial
Administrative, Industrial &
Commercial

<!-- page 8 -->

<!-- page 9 -->

ANNEXURE 1.2. CITY SHAPE
ASSUMPTION

<!-- page 10 -->

<!-- page 11 -->

CITY SHAPE ASSUMPTION
Shape factor is derived as the ratio of the length of the city in the smallest direction (X) to the
length to the longest direction (Y).
Shape factor = X/Y

The shape assumed for the selected cities is presented in Table given below.

A-4

<!-- page 12 -->

Shape of the selected cities

Sl. No

Name of the city

Shape

1
2
3
4
5
6
7
8

Hubli- Dharward
Patna
Kanpur
Kolkata
TVM
Varanasi
Shimla*
Panaji

Linear
Linear
Linear
Linear
Linear
Linear
Hilly
Linear

9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30

Mumbai
Guwahati
Amritsar
Chennai
Kochi
Pondicherry
Gangtok*
Bhuvaneshwar
Raipur
Agra
Madurai
Bhopal
Bangalore
Ahmedabad
Chandigarh
Delhi
Bikaner
Hyderabad
Surat
Nagpur
Pune
Jaipur

Linear
Linear
Linear
Semi-Circular
Semi-Circular
Semi circular
Hilly
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular
Circular

Shape Factor
(Minimum spread
/ maximum
spread)
0.30
0.35
0.37
0.37
0.43
0.47
0.50
0.57
0.57
0.58
0.64
0.73
0.74
0.75
0.78
0.78
0.80
0.82
0.89
0.83
0.83
0.85
0.86
0.89
0.93
0.95
0.96
1.00

(Note: *- Gangtok and Shimla are hilly terrain cities and hence not classified
into any category based on shape)

A-5

<!-- page 13 -->

From the above table, the range of shape factor assumed for the three groups of cities are
given in Table given below.

Range of Shape Factor assumed for different shapes of cities
Sl. No.

City Shape

Range of Shape
factor assumed

1

Linear

< 0.6

2

Semi-circular

0.61 - 0.74

3

Circular

0.75 - 1.0

A-6

<!-- page 14 -->

<!-- page 15 -->

ANNEXURE 2.1. PRIMARY SURVEY
FINDINGS

<!-- page 16 -->

<!-- page 17 -->

PRIMARY SURVEY FINDINGS

Traffic Characteristics at Inner City Locations during Peak Hour

1

Gangok

Average
Share of
Fast Traffic
(%)
100

2

Panaji

83

17

100

3

Shimla

100

0

100

4

Pondicherry

85

15

100

5

Bikaner

84

16

100

6

Raipur

81

19

100

7

Bhuvaneshwar

83

17

100

8

Chandigarh

85

15

100

S no

City

Average
Share of
Slow Traffic
(%)
0

Total
(%)
100

9

Hubli-Dharwad

83

17

100

10

Guahati

89

11

100

11

Amritsar

79

21

100

12

Trivandrum

97

3

100

13

Madurai

94

6

100

14

Agra

81

19

100

15

Bhopal

94

6

100

16

Kochi

97

3

100

17

Patna

68

32

100

18

Varanasi

73

27

100

19

Nagpur

83

17

100

20

Jaipur

88

12

100

21

Kanpur

86

14

100

22

Surat

91

9

100

23

Pune

89

11

100

24

Ahemadabad

92

8

100

25

Hyderabad

97

3

100

26

Chennai

94

6

100

27

Bangalore

100

0

100

28

Delhi

97

3

100

29

Kolkata

88

12

100

30

Mumbai

98

2

100

A-7

<!-- page 18 -->

Peak Hour Traffic Composition on interior city locations (%)
Sl.
No.

City Name

Std. Bus
(incl. tourist
and
educational
bus)

Mini
bus

Cars/Jeep
/Van

Two
Wheelers

Auto
Ricksha
ws

Comme
rcial
Vehicle
s

SMVs

Total

1

Gangok

0%

13%

49%

36%

0%

2%

0%

100%

2

Panaji

9%

4%

17%

30%

14%

9%

17%

100%

3

Shimla

12%

17%

30%

31%

0%

9%

0%

100%

4

Pondicherry

10%

2%

22%

33%

14%

5%

15%

100%

5

Bikaner

4%

1%

16%

25%

30%

8%

16%

100%

6

Raipur

1%

2%

11%

30%

31%

7%

19%

100%

7

Bhuvaneshwar

2%

1%

13%

42%

20%

5%

17%

100%

8

Chandigarh

9%

2%

27%

33%

10%

5%

15%

100%

9

Hubli-Dharwad

19%

5%

12%

28%

15%

4%

17%

100%

10

Guahati

5%

4%

22%

37%

18%

3%

11%

100%

11

Amritsar

2%

4%

18%

18%

31%

6%

21%

100%

12

Trivandrum

8%

3%

21%

44%

16%

5%

3%

100%

13

Madurai

13%

4%

21%

40%

12%

5%

6%

100%

14

Agra

4%

4%

15%

28%

23%

7%

19%

100%

15

Bhopal

4%

6%

19%

41%

20%

4%

6%

100%

16

Kochi

11%

2%

23%

46%

12%

4%

3%

100%

17

Patna

1%

3%

14%

25%

21%

5%

32%

100%

18

Varanasi

1%

5%

17%

18%

27%

4%

27%

100%

19

Nagpur

6%

1%

22%

38%

11%

5%

17%

100%

20

Jaipur

7%

4%

25%

43%

6%

3%

12%

100%

21

Kanpur

8%

2%

22%

28%

21%

5%

14%

100%

22

Surat

2%

1%

23%

35%

26%

4%

9%

100%

23

Pune

6%

1%

13%

38%

26%

5%

11%

100%

24

Ahemadabad

8%

1%

21%

40%

20%

3%

8%

100%

25

Hyderabad

15%

3%

27%

29%

19%

4%

3%

100%

26

Chennai

8%

3%

20%

40%

18%

4%

6%

100%

27

Bangalore

13%

2%

30%

28%

24%

2%

0%

100%

28

Delhi

12%

4%

37%

23%

19%

2%

3%

100%

29

Kolkata

17%

4%

29%

24%

11%

3%

12%

100%

30

Mumbai

7%

3%

39%

29%

18%

3%

2%

100%

A-8

<!-- page 19 -->

Commercial Vehicles (Trucks & MAV) movement at Outer Cordon Points
(8 hours during day time)

Sl. No.

City

Total Nos.

Share of total
vehicles crossing
the cordon points
(%)

1

Gangtok

1086

5

2

Panaji

3650

10

3

Shimla

3800

13

4

Pondichery

7679

13

5

Bikaner

7623

12

6

Raipur

10408

23

7

Bhuvaneshwar

13884

22

8

Chandigarh

10994

15

9

Hubli-Dharwad

8411

19

10

Guwahati

2858

6

11

Amritsar

7046

11

12

Trivandrum

8518

18

13

Madurai

21891

26

14

Agra

11190

15

15

Bhopal

16088

29

16

Kochi

21676

32

17

Patna

7946

14

18

Varanasi

7704

12

19

Nagpur

17674

21

20

Jaipur

18896

20

21

Kanpur

18209

29

22

Surat

21778

34

23

Pune

20267

21

24

Ahmedabad

24784

19

25

Hyderabad

22705

15

26

Chennai

42306

25

27

Bangalore

36617

24

28

Delhi

43006

19

29

Kolkata

40321

22

30

Mumbai

47683

22

A-9

<!-- page 20 -->

Commercial Vehicles Movement Crossing the Cordon Points (during 8 hours of daytime)
Total
Vehicles
(8 hrs)

Total Commercial
Vehicles (8 hrs)

Ext- Ext Commercial
(8 hrs)

Int- Ext & Ext- Int
Commercial (8 hrs)

1

Gangtok

24124

1086

5

391

2

695

% of Total
Vehicles
crossing
the
cordon
points
3

2

Panaji

37905

3650

10

1497

4

2154

6

3

Shimla

28570

3800

13

1479

5

2321

8

4

Pondicherry

60443

7679

13

2995

5

4684

8

5

Bikaner

65831

7623

12

3354

5

4269

6

6

Raipur

46016

10408

23

3469

8

6939

15

7

Bhuvaneshwar

63406

13884

22

5692

9

8192

13

8

Chandigarh

71492

10994

15

3987

6

7007

10

9

Hubli Dharwad

44214

8411

19

3701

8

4710

11

10

Guahati

45618

2858

6

1086

2

1772

4

11

Amritsar

63357

7046

11

3079

5

3967

6

13

Madurai

48443

8518

18

2896

6

5622

12

14

Agra

85458

21891

26

11310

13

10581

12

14

Trivandrum

77162

11190

15

4588

6

6602

9

15

Bhopal

55144

16088

29

4022

7

12066

22

16

Kochi

67638

21676

32

6720

10

14956

22

17

Patna

56372

7946

14

3337

6

4609

8

18

Varanasi

63416

7704

12

3698

6

4006

6

19

Nagpur

83485

17674

21

4552

5

13122

16

20

Jaipur

92845

18896

20

7369

8

11527

12

21

Kanpur

63472

18209

29

9468

15

8741

14

22

Surat

64479

21778

34

5959

9

15819

25

23

Pune

97558

20267

21

6485

7

13782

14

24

Ahmedabad

129767

24784

19

7661

6

17123

13

25

Hyderabad

155312

22705

15

15137

10

7568

5

26

Chennai

167117

42306

25

13538

8

28768

17

27

Bangalore

152965

36617

24

16111

11

20506

13

28

Delhi

224131

43006

19

15912

7

27094

12

29

Kolkata

181847

40321

22

13306

7

27015

15

30

Mumbai

213975

47683

22

16212

8

31471

15

Sl.no

City
Nos.

Nos.

% of Total
Vehicles
crossing the
cordon
points

A-10

Nos.

% of Total
Vehicles
crossing
the cordon
points

Nos.

<!-- page 21 -->

Peak Hour Journey Speed on Major Road Network
Sl. No.

City

Average Journey
Speed (KMPH) on
major corridors

1

Gangtok

23.8

2

Panaji

28

3

Shimla

26

4

Pondicherry

24.1

5

Bikaner

24

6

Raipur

21

7

Bhuvaneshwar

20

8

Chandigarh

30

9

Hubli-Dharwad

23

10

Guahati

20

11

Amritsar

24

12

Trivandrum

23

13

Madurai

27

14

Agra

28

15

Bhopal

24

16

Kochi

25

17

Patna

23

18

Varanasi

17.7

19

Nagpur

23

20

Jaipur

20.9

21

Kanpur

20

22

Surat

24.2

23

Pune

24

24

Ahemadabad

21

25

Hyderabad

19

26

Chennai

19

27

Bangalore

18

28

Delhi

16

29

Kolkata

18

30

Mumbai

16

A-11

<!-- page 22 -->

On -Street Parking Availability o Major Road Corridors for the
Selected Cities
S.No

Major Roads Length used
for Parking (%)

City

1

Gangtok

31%

2

Panaji

41%

3

Shimla

48%

4

Pondicherry

45%

5

Bikaner

35%

6

Raipur

32%

7

Bhuvaneshwar

36%

8

Chandigarh

36%

9

Hubli-Dharwad

35%

10

Guahati

45%

11

Amritsar

49%

12

Trivandrum

47%

13

Madurai

52%

14

Agra

53%

15

Bhopal

51%

16

Kochi

56%

17

Patna

56%

18

Varanasi

50%

19

Nagpur

61%

20

Jaipur

58%

21

Kanpur

48%

22

Surat

60%

23

Pune

53%

24

Ahemadabad

43%

25

Hyderabad

29%

26

Chennai

27%

27

Bangalore

17%

28

Delhi

14%

29

Kolkata

19%

30

Mumbai

16%

A-12

<!-- page 23 -->

Pedestrian Opinion Ranking on Pedestrian Facilities
S.No
City
Rank
1

Gangok

1.1

2

Panaji

1.3

3

Shimla

1.2

4

Pondicherry

1.3

5

Bikaner

1.2

6

Raipur

1.4

7

Bhuvaneshwar

1.5

8

Chandigarh

4.1

9

Hubli-Dharwad

1.8

10

Guahati

2.1

11

Amritsar

2.4

12

Trivandrum

1.9

13

Madurai

2.3

14

Agra

2.7

15

Bhopal

2.4

16

Kochi

2.6

17

Patna

1.8

18

Varanasi

2.3

19

Nagpur

3.4

20

Jaipur

3.6

21

Kanpur

1.7

22

Surat

2.4

23

Pune

3.1

24

Ahemadabad

3.5

25

Hyderabad

3.0

26

Chennai

3.4

27

Bangalore

3.5

28

Delhi

3.7

29

Kolkata

3.9

30
Mumbai
(Note: Rank 1- lowest and 5- best)

A-13

3.9

<!-- page 24 -->

% of Major Roads with Lane Configuration*
Sl.no

City

2 Lane

4 Lane

6 and above

1
Gangtok
92
8
0
2
Panaji
59
41
0
3
Shimla
85
15
0
4
Pondicherry
84
16
0
5
Raipur
90
10
0
6
Chandigarh
12
84
4
7
Gauhati
39
61
0
8
Amritsar
49
40
11
9
Trivandrum
84
16
0
10
Madurai
75
25
0
11
Agra
64
36
0
12
Bhopal
68
32
0
13
Cochin
73
27
0
14
Jaipur
58
37
6
15
Pune
68
28
4
16
Ahmedabad
50
41
9
17
Hyderabad
54
42
4
18
Bangalore
12
81
7
19
Delhi
8
89
3
20
Kolkata
62
31
7
21
Mumbai
27
57
17
Note *- Includes only major roads with 2 lane and above width)

A-14

Total
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100
100

<!-- page 25 -->

ANNEXURE 2.2. TRIP LENGTH
FREQUENCY DISTRIBUTION

<!-- page 26 -->

<!-- page 27 -->

TRIP LENGTH FREQUENCY DISTRIBUTION
GANGTOK
70%
60%

TRIPS (%)

50%
40%
30%
20%
10%

10-12

12-14

14-16

16-18

10-12

12-14

14-16

16-18

10-12

12-14

14-16

16-18

8-10

6-8

4-6

2-4

0-2

0

0%

TRIP DISTANCE (in Km)

PANAJI
50%

TRIPS (%)

40%

30%

20%

10%

8-10

6-8

4-6

2-4

0-2

0

0%

TRIP DISTANCE (in Km)

SHIMLA
50%

30%

20%

10%

8-10

6-8

4-6

2-4

0-2

0%
0

TRIPS (%)

40%

TRIP DISTANCE (in Km)

A-15

<!-- page 28 -->

A-16

TRIP DISTANCE (in Km)

60%

50%

40%

30%

20%

10%

0%
12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

16-18

70%

14-16

RAIPUR
14-16

TRIP DISTANCE (in Km)

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)
TRIPS (%)

28-30

26-28

24-26

22-24

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

PONDICHERRY

60%

50%

40%

30%

20%

10%

0%

TRIP DISTANCE (in Km)

BIKANER

70%

60%

50%

40%

30%

20%

10%

0%

<!-- page 29 -->

A-17

TRIP DISTANCE (in Km)

28-30

26-28

24-26

22-24

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

BHUVANESWAR

30%

20%

10%

0%

TRIP DISTANCE (in Km)

CHANDIGARH

40%

30%

20%

10%

0%

TRIP DISTANCE (in Km)

HUBLI DHARWAD

30%

20%

10%

0%

<!-- page 30 -->

A-18

TRIP DISTANCE (in Km)

28-30

26-28

24-26

22-24

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

GUWAHATI

50%

40%

30%

20%

10%

0%

TRIP DISTANCE (in Km)

AMRITSAR

40%

30%

20%

10%

0%

TRIP DISTANCE (in Km)

TRIRUVANANTHAPURAM

40%

30%

20%

10%

0%

<!-- page 31 -->

A-19

30%

20%

10%

0%

TRIP DISTANCE (in Km)
10-12

8-10

6-8

4-6

2-4

0-2

0

26-28

24-26

22-24

TRIPS (%)
30%

20%

10%

0%
16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

20-22

40%

18-20

AGRA

18-20

TRIP DISTANCE (in Km)

16-18

14-16

40%

20-22

BHOPAL
12-14

TRIP DISTANCE (in Km)

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

TRIPS (%)

MADURAI

50%

40%

30%

20%

10%

0%

<!-- page 32 -->

A-20

TRIP DISTANCE (in Km)

30%

20%

10%

0%
12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

28-30

26-28

24-26

20-22

18-20

16-18

40%

22-24

VARANASI

14-16

TRIP DISTANCE (in Km)

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

TRIPS (%)

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

KOCHII

30%

20%

10%

0%

TRIP DISTANCE (in Km)

PATNA

40%

30%

20%

10%

0%

<!-- page 33 -->

A-21
KANPUR

40%

30%

20%

10%

0%

TRIP DISTANCE (in Km)

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

18-20

16-18
24-26
26-28

24-26
26-28

22-24

TRIP DISTANCE (in Km)
22-24

0%
20-22

10%

20-22

20%

14-16

30%
18-20

JAIPUR

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

TRIP DISTANCE (in Km)

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

TRIPS (%)

NAGPUR

50%

40%

30%

20%

10%

0%

<!-- page 34 -->

A-22

TRIP DISTANCE (in Km)

10%

0%
18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

22-24

20%

28-30

AHMEDABAD
20-22

TRIP DISTANCE (in Km)

26-28

24-26

22-24

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)
TRIPS (%)

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

SURAT

40%

30%

20%

10%

0%

TRIP DISTANCE (in Km)

PUNE

50%

40%

30%

20%

10%

0%

<!-- page 35 -->

A-23

TRIP DISTANCE (in Km)

26-28
28-30

28-30

28-30

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

26-28

0%

26-28

10%
24-26

20%

24-26

BANGALORE

24-26

TRIP DISTANCE (in Km)

22-24

0%
22-24

10%

22-24

20%

20-22

30%

20-22

CHENNAI

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

TRIP DISTANCE (in Km)

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)
TRIPS (%)

HYDERABAD

30%

20%

10%

0%

<!-- page 36 -->

A-24

TRIP DISTANCE (in Km)
24-26
26-28
28-30

24-26

26-28

28-30

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

22-24

0%

22-24

10%
20-22

20%

20-22

MUMBAI
18-20

TRIP DISTANCE (in Km)

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

TRIPS (%)

28-30

26-28

24-26

22-24

20-22

18-20

16-18

14-16

12-14

10-12

8-10

6-8

4-6

2-4

0-2

0

TRIPS (%)

DELHI

20%

10%

0%

TRIP DISTANCE (in Km)

KOLKATA

20%

10%

0%

<!-- page 37 -->

ANNEXURE 3.1. TRANSPORT
CHARACTERISTICS OF 30 STUDY CITIES

<!-- page 38 -->

<!-- page 39 -->

Name of the City

GANGTOK

Gangtok, the capital city of Sikkim is located in the East District and situated in the
lower Himalayas. Gangtok is simply a great place for tourism, especially for people
who like to explore the wonderful Buddhist Monasteries and surroundings are
beautiful and appealing. The study area is the Gangtok Development Area
comprising about 76.95 sq. kms. and about 0.92 lakh population as per 2001 census.
The population of Gangtok city is 0.59 lakhs covering the area 25 Sq.Km as per
Census 2001 with a decadal growth rate of 17 per cent. Vehicle population of the city
is very less. The total number of registered vehicles in Gangtok city in 2005 is 3977.
The vehicle population has experienced an annual growth rate of 16% during the
past 5 years. National Highway No. 31-A connects the city with other places. The
road network is comprised mainly by 2 lane roads. The city does not have a proper
public transport system.

I. General:
Study Area

: 76. 95 Sq.Km

Administrative Boundary

: Gangtok Development Area

Population (2001)

: 0.92 lakhs

2007 Population (estimated)

: 1.12 lakhs

2007 Employment (estimated)

: 0.31 Lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: Yes

Population Category

: 1b

Shape Category

:1

Terrain

: Hilly Terrain

Availability of City Bus service

: Absent

Average Travel speed (KMPH)
on major corridors

: 23.8

A-25

<!-- page 40 -->

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips (Lakhs)
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 0.87
: 0.83
: 2.11

Share (%)
4
40
0
0
56
0

Trips(Lakhs)
0.03
0.33
0.00
0.00
0.47
0.00

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions
Calibration Functions
a
172.8

b
1.0552

c
0.06852

IV. Mode Choice
VM = α TTM + β TCM
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows

A-26

<!-- page 41 -->

α

β

Two Wheeler

0.1388

-0.4104

Car

-0.03258

-0.0359

Auto

-

-

Public Transport

-

-

Mode

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

2021
Value
(Lakhs)

%

%

2031
Value
(Lakhs)

%

PV+ IPT (In Nos.)

0.520

45.84

0.904

53.44

1.497

61.98

PT (in Nos.)*

0.0

0.0

0.0

0

0.0

0.0

54.16

0.788

46.56

0.958

39.02

0.614
(Note:*- model output, **-estimated)
NMT *(In nos.)**

A-27

<!-- page 42 -->

Name of the City

PANAJI

Panaji is a capital of Goa State and is situated along the river Mandovi, on Island of
Tiswadi. Panaji is spotted as one of the most attractive tourist destination centers in
India, and it attracts around 2.0 Lacs National tourists and 0.35 lacs international tourist
annually. The study area is the area within the Panaji Development Area comprising

about 22.63sq. kms. and about 0.97 lakh population as per 2001 census. The
population of Panaji city is 0.58 lakhs covering an area of 8.12 Sq.km as per Census
2001 with a decadal growth rate of 38.3 per cent.

The total number of registered

vehicles in Panaji city in 2005 is 7151. The vehicle population has experienced an
annual growth rate of 6.7% during the past 5 years. Two National Highways NH 17
and NH 4 A is connecting the city with other places.

I. General:
Study Area

: 22.63 Sq .Km

Administrative Boundary

: Panaji Development Area

Population (2001)

: 0.97 lakhs

2007 Population (estimated)

: 1.05 lakhs

2007 Employment (estimated)

: 0.40 lakhs

Shape of the city

: Linear

Capital City (Yes/No)

: Yes

Population Category

: 1(a)

Shape Category

:3

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 28

A-28

<!-- page 43 -->

Zoning Map

Network Map
Network Length
Number of Links
Number of Nodes

Number Of Zones
Internal Zones
External Zones

: 89Km
: 603
: 417

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 0.76
: 0.80
: 2.41

Share (%)
26
27
5
5
34
3

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-29

Trips
(Lakhs)
0.21
0.21
0.04
0.04
0.27
0.03

: 22
: 18
:4

<!-- page 44 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions and values are as follows
Calibration Functions
a
175.0

b
1.0680

c
0.06931

IV. Mode Choice
VM = α TTM + β TCM
Where,
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
α

β

Two Wheeler

0.1358

-0.1792

Car

0.17291

-0.0347

Auto
Public
Transport

0.1747

-0.0694

-0.4559

0.71865

Mode

V. Travel demand Forecast
Mode

2011
Value
(Lakhs)
PV+ IPT (In Nos.)*
0.520
PT (in Nos.)*
0.025
NMT *(In nos.)**
0.324
(Note:*- model output, **-estimated)

Horizon Year Trips/Day
2021
Value
%
%
(Lakhs)
61.83
0.784
66.68
2.83
0.026
2.25
36.14
0.365
31.07

A-30

2031
Value
%
(Lakhs)
1.140
72.35
0.025
1.61
0.410
26.04

<!-- page 45 -->

Name of the City

SHIMLA

Shimla, the State capital of Himachal Pradesh, is known as the “Queen of Hill
Stations” and the former summer capital of British Government and Punjab State
has got unique privilege of being a hill station. It is situated on a range of hills which
forms the last traverse of the central Himalayas south of the river Sutlej. The study
area is the Shimla Planning Area (SPA) comprising about 100 sq. kms. The
population of SPA is 1.73 lakhs as per Census 2001 with a decadal growth rate of 33
per cent. The total number of registered vehicles in Shimla city in 2005 is 19,849. The
vehicle population has experienced an annual growth rate of 5.43% during the past 5
years. The city is developed in linear shape. National highway No. 22 and National
Highway No. 88 connects Shimla with other places in the State and outside. Public
transport in Shimla Planning Area is through bus transport provided by HRTC and
mini buses operated on selected routes by the licensed private operators.

I. General:
Study Area

: 100 Sq.Km

Administrative Boundary

: Shimla Planning Area

Population (2001)

: 1.73 lakhs

2007 Population (estimated)

: 1.8 Lakhs

2007 Employment (estimated)

: 0.64 lakhs

Shape of the city

: Linear

Capital City (Yes/No)

: Yes

Population Category

: 1(b)

Shape Category

:3

Terrain

: Hilly

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 26

A-31

<!-- page 46 -->

$
$
$

$

$
$

$

$

$

$

$

$

$
$
$
$

5

$
$

$

$
$

$

$
$

$

4

$
$

12

$
$

$

$

$

$

$

$
$

$$

$
$ $
$
$

$

3

$

$

$

$

$

$
$

$$

$$$

$
$ $

$

$

$

$

$

25

$

$

$

21
20

$

$

$

$

9
$

$
$

$

$

$
$

$

$
$

18

$

$
$

$

$

17

$
$

$

13

7

$

22
$

$

$

$

$
$
$

$

$

$

$
$

$

$

$
$

$
$

$$

$

$
$
$

$

8

$

$
$

$

$
$

$

$

$
$

$

$

$

6

$

$

$
$

10
$

$

$

$
$

$

$

$

$

$
$

$

19

$

$

$

$

$

$
$

$

$
$
$

$

$
$
$

$

1

$

$

$

$

$

$

$

$
$
$

$
$
$ $

$$

$

$

11

$

$
$
$
$

$

$

$

$

$

$
$

$

$

$

$

$

2
$

$

$

$

$
$

$
$

$

$

$
$

$

$

$
$

$
$

$

$

$

$

$

$
$

24

23

$

14
$

$
$
$
$

$
$
$

15

$

$

16

$

$

$
$

$

$

$
$

$

$
$

$

Network Map

Zoning Map

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips (Lakhs)
Average Trip Length (Km)
Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 0.78
:1.45
: 3.0
Trips
(Lakhs)
0.12
0.25
0.0
0.23
0.84
0.01

Share (%)
8
17
0.0
16
58
1

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-32

<!-- page 47 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions and the values as follows
Calibration Functions
a

b

c

155.9

0.9546

0.06223

IV. Mode Choice
VM = α TTM + β TCM
Where,
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode
Two Wheeler

α

β

0.1401

0.0000

Car

0.00000

-0.0343

Auto

-

-

Public
Transport

-0.0100

0.04195

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

%

2021
Value
(Lakhs)

%

2031
Value
(Lakhs)

%

PV+ IPT (In Nos)*

0.636

37.05

1.059

45.79

1.628

54.94

PT (in Nos.)*

0.105

6.10

0.123

5.33

0.121

4.09

0.976
(Note:*- model output, **-estimated)

56.86

1.130

48.88

1.214

40.97

NMT *(In nos.)**

A-33

<!-- page 48 -->

Name of the City

PONDICHERRY

Union Territory of Pondicherry is situated on the Coromandel Coast about 162 kms
south of Chennai and 22 kms north of Cuddalore. Pondicherry encompasses many
tourist attractive places. The bulk of Pondicherry region is an irregular stretch of land
consisting, the municipalities of Pondicherry & Oulgaret and five panchayats. The study
area is the Pondicherry Development Area which is about 290 Sq. km, with the total
population of 5.08 lakhs according to the 2001 census. Pondicherry is grown in semi
circular shape. NH 45- A connects Pondicherry with other places. Public Transport

need of the city is performed by buses operated by Pondicherry Road Transport
Corporation (PRTC) and Private Operators.

I. General:
Study Area

: 290 Sq. km

Administrative Boundary

: Pondicherry Development Area

Population (2001)

: 5.08 lakhs

2007 Population (estimated)

: 5.68 Lakhs

2007 Employment (estimated)

: 1.80 Lakhs

Shape of the city

: Semi-circular

Capital City (Yes/No)

: yes

Population Category

:2

Shape Category

:2

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 24.1

A-34

<!-- page 49 -->

Network Map

Zoning Map

II. Base year Trip Characteristics
Per capita Trip Rate
Daily Trips (Lakhs)
Average Trip Length (Km)
Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

Share (%)
30
4
4
7
40
15

: 0.96
: 4.88
: 3.0
Trips (Lakhs)
1.48
0.19
0.18
0.32
1.97
0.75

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-35

<!-- page 50 -->

Where,
‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function
Calibration Functions
a

b

c

117.1

0.7244

0.04784

IV. Mode Choice
VM = α TTM + β TCM
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode
Two Wheeler

α

β

0.1325

0.4410

Car

0.23109

-0.0331

Auto

0.2076

-0.0367

Public
Transport

-0.0268

0.12700

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

%

2021
Value
(Lakhs)

%

2031
Value
(Lakhs)

%

PV+ IPT (In Nos)*

2.636

43.78

4.014

51.68

6.035

59.27

PT (in Nos.)*

0.173

2.87

0.191

2.46

0.233

2.28

3.213
(Note:*- model output, **-estimated)

53.35

3.563

45.87

3.915

38.44

NMT *(In nos.)**

A-36

<!-- page 51 -->

Name of the City

BIKANER

Bikaner is situated in the north part of Rajasthan. The city, just like Jodhpur, is
surrounded by great walls. It has Ganganagar and Hanumannagar in its northern side
whereas Churu lies in its eastern side. The study area is the Bikaner Planning Area with
area of 270 Sq. Km. As per 2001 census the population is 6.40 lakhs. National Highway
No. 11 connects the city with other places. The road network is comprised by 38% of 2
lane roads, 58% of 4 lane, etc. The city does not have a formal public transport system.

I. General:
Study Area

: 270 Sq.Km

Administrative Boundary

: Bikaner Planning Area

Population (2001)

: 6.4 lakhs

2007 Population (estimated)

: 7.6 lakhs

2007 Employment(estimated)

: 2.2 Lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: No

Population Category

:2

Shape Category

:1

Terrain

: Plain

Availability of City Bus service

: Absent

Average Travel speed (KMPH)
on major corridors

: 24

A-37

<!-- page 52 -->

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode

: 0.81
: 6.21
: 2.60

Share (%)

Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

21.5
8.28
5.23
0.0
45.83
19.16

Trips
(Lakhs)
1.34
0.51
0.33
0.0
2.85
1.19

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions

Calibration Functions
a
113.4

b
0.7028

c
0.04648

A-38

<!-- page 53 -->

IV. Mode Choice
VM = α TTM + β TCM

VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows

α

β

Two Wheeler

0.2230

0.0784

Car

0.14109

-0.0513

Auto
Public
Transport

0.0903

0.0000

-

-

Mode

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011

2021

2031

Value
(Lakhs)

%

Value
(Lakhs)

%

Value
(Lakhs)

%

PV+ IPT (In Nos)*

2.761

37.57

4.585

46.33

6.98

55.02

PT (in Nos.)*

0.0

0.0

0.0

0.0

0.0

0.0

NMT *(In nos.)**

4.588

62.43

5.311

53.67

5.707

44.98

(Note:*- model output, **-estimated)

A-39

<!-- page 54 -->

Name of the City

RAIPUR

Raipur is the capital city of the recently formed State of Chhattisgarh, carved out of the
erstwhile State of Madhya Pradesh. The city is also the head quarter of Raipur District.
Raipur, being the capital of Chattisgarh, is positioned to support the mineral based
industries. The study area is the Raipur planning area covering 188 sq. km. As per 2001
census the planning area covers a population of 7.19 lakhs, in which the city population
is 6.70 lakhs. Raipur is developed in linear shape. Three National Highways such as NH
6, NH 43 and NH 200 connects city with other places. The road network is comprised

by 37% of 2 lane roads, 60% of 4 lane, etc. There is no organized public transportation
system present in Raipur.

I. General:
Study Area

: 188 Sq. km

Administrative Boundary

: Raipur Planning Area

Population (2001)

: 7.19 lakhs

2007 Population (estimated)

: 8.80 Lakhs

2007 Employment (estimated)

: 2.11 Lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: No

Population Category

:2

Shape Category

:1

Terrain

: Plain

Availability of City Bus service

: Absent

Average Travel speed (KMPH)
on major corridors

: 21

A-40

<!-- page 55 -->

Network Map

Number of Links
Number of Nodes

Zoning Map
Number Of Zones
Internal Zones
External Zones

: 1700
: 1248

II. Base year Trip Characteristics
Per capita Trip Rate
Daily Trips
Average Trip Length (Km)
Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

Share (%)
25
9
4
0
35
28

: 0.94
: 8.07
: 3.03
Trips (Lakhs)
2.04
0.71
0.31
0.0
2.79
2.22

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-41

: 74
: 70
:4

<!-- page 56 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions
Calibration Functions
a

b

c

102.1

0.6355

0.04228

IV. Mode Choice
VM = α TTM + β TCM
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode
Two Wheeler

α

β

0.0864

0.1651

Car

0.16313

-0.0237

Auto

0.1186

0.0000

Public
Transport

-

-

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

2021
Value
(Lakhs)

%

%

2031
Value
(Lakhs)

%

PV+ IPT (In Nos)*

4.03

40.32

7.56

48.69

13.29

56.99

PT (in Nos.)*

0.0

0.0

0.0

0.0

0.0

0.0

59.68

7.97

51.31

10.03

43.01

5.96
(Note:*- model output, **-estimated)
NMT *(In nos.)**

A-42

<!-- page 57 -->

Name of the City

BHUBANESWAR

Bhubaneswar is the capital city of East Indian State of Orissa located in Khorda district
at a distance of about 64 km from Puri. The city boasts of majestic temples and shrines,
which form a major part of its tourist attractions. The study area is the Bhubaneswar
Development Area comprising about 233 sq. kms. and about 8.44 lakh population as per
2001 census. The population of Bhubaneswar city is 6.48 lakhs covering 135 sq. kms as
per Census 2001 with a decadal growth rate of 50 per cent. The total number of
registered vehicles in Bhubaneswar city in 2001 is 26,244. The vehicle population has
experienced an annual growth rate of 14% during the period between 1991 and 2001.
Two national highways, NH 5 (Kolkatta- Chennai) and NH 203 (Bhubaneswar – Puri)
traverse through the city. The road network is comprised by 38% of 2 lane roads, 56% of
4 lane, etc. Public transport need of the city is performed through buses operated by the
Orissa government.

I. General:
Study Area

: 233 Sq.km

Administrative Boundary

: Bhubaneswar Development Area

Population (2001)

: 8.44 lakhs

2007 Population (estimated)

: 10.94 lakhs

2007 Employment(estimated)

: 2.77 lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: Yes

Population Category

:2

Shape Category

:1

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 20

A-43

<!-- page 58 -->

$

$

$
$
$ $

$ $

$
$

$

$
$

$

$

$

$

$

$

$

$
$

$

$

$

$

$
$
$

$
$
$

$
$

$

$

$

$

$
$

$

$
$

$

$
$

$

$

$
$
$
$
$
$ $

$

$

$ $
$

$
$

$

$

$

$

$

$

$

$

$

$$
$

$$

$
$

$

$ $

$
$
$

$
$
$$
$

$
$

$

$
$

$
$

$

$

$
$
$

$

$

$

$

$

$ $

$

$
$

$

$
$

$

$

$

$

$

$

$

$

$ $

$
$
$

$

$

$
$

$

$

$
$

$

$

$

$

$

$

$

$

$

$

$
$
$$ $

$

$

$

$

$

$

$

$

$

$

$

$

$

$

$
$

$

$
$
$

$
$

$

$

$

$

$
$
$ $
$
$
$

$

$
$
$
$

$

$

$

$

$

$$
$
$
$
$

$$

$

$
$

$

$

$
$

$

$

$

$

$
$

$
$

$
$

$
$

$
$$

$ $$

$
$

$
$

$

$

$
$$

$

$

$

$
$
$

$

$

$

$
$

$

$

$

$
$
$

$

$

$

$
$

$

$

$$

$

$

$
$
$

$
$

$

$

$ $
$

$

$$

$

$

$

$

$

$
$

$
$

$

$

$

$

$

$
$ $

$$
$

$

$$

$

$
$
$

$
$

$
$

$
$

$

$

$

$

$
$$

$
$

$

$

$

$

$

$

$
$
$

$

$ $

$

$$

$$
$

$

$

$

$

$

$
$

$

$

$

$
$
$
$

$
$

$

$

$

$

$
$

$

$

$

$

$
$

$
$

$$
$
$

$

$
$

$

$

$$

$
$

$

$$
$

$ $

$$

$

$

$
$

$
$

$
$
$

$
$

$

$
$

$
$

$

$

$
$
$

$

$$

$

$
$
$

$$

$
$
$
$

$

$

$

$

$

$

$
$
$

$

$

$
$

$

$
$

$

$

$

$

$$

$
$$

$
$

$
$

$

$

$

$

$

$
$

$
$

$
$$
$
$$

$

$
$$

$

$

$

$
$

$
$

$

$

$

$
$

$

$
$

$
$

$

$

$

$

$
$

$

$
$

$
$

$

$

$
$$

$

$

$
$

$

$
$

$
$ $
$
$ $

$

$

$

$

$

$
$

$ $

$ $
$

$
$
$

$
$

$
$

$
$

$

$ $

$

$
$
$

$
$

$

$

$

$ $

$

$

$

$

$

$

$$

$

$
$

$

$
$

$

$
$
$

$

$
$

$
$

$

$$

$

$

$

$

$

$

$
$

$

$

$
$
$

$

$

$

$

$

$
$

$

$

$$ $
$

$
$

$
$

$$

$

$$

$

$
$
$

$

$
$
$

$
$
$

$

$

$
$

$
$
$

$
$

$

$

$
$

$

$

$

$

$

$
$
$
$

$

$ $

$ $

$

$

$

$
$

$

$ $

$

$

$$

$

$

$

$
$

$

$ $
$

$

$

$$
$

$
$

$
$$ $

$

$

$
$
$

$
$ $

$

$

$
$

$

$

$

$

$
$

$

$
$
$
$

$ $
$

$
$

$

$

$

$

$$

$
$

$

$

$

$
$

$

$$

$

$

$

$

$

$
$

$ $

$

$
$$

$

$

$

$

$

$

$

$

$

$

$

$
$
$
$

$

$

$

$

$

$

$

$

$

$

$

$

$

$

$
$

$
$

$

$
$
$

$

$

$

$ $

$
$

$

$

$

$

$

$

$

$

$
$
$ $$

$

$

$
$

$

$

$

$

$

$$

$

$

$

$
$
$

$

$

Network Map

Zoning Map

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 0.96
: 10.46
: 3.92

Share (%)
30
12
4
4
28
21

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-44

Trips
(Lakhs)
3.17
1.26
0.42
0.44
2.96
2.21

<!-- page 59 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions

Calibration Functions
a

b

c

94.7

0.5913

0.03952

IV. Mode Choice
VM = α TTM + β TCM
where
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode

α

β

Two Wheeler

0.1401

-0.3670

Car

0.01330

-0.0347

Auto

-0.0630

-0.0141

Public
Transport

-0.0408

0.23618

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

PV+ IPT (In Nos)*
PT (in Nos.)*

2011
Value
(Lakhs)
6.413
0.245

NMT *(In nos.)**
6.015
(Note:*- model output, **-estimated

50.60

2021
Value
(Lakhs)
11.611

57.42

1.93

0.359

1.78

0.56

1.79

47.47

8.252

40.81

10.74

34.20

%

A-45

%

2031
Value
%
(Lakhs)
20.10
64.01

<!-- page 60 -->

Name of the City

CHANDIGARH

Chandigarh is located in western side of river Ghaggar and Shimla National highway, is
the capital city of both Punjab and Haryana. The study area considered for the study is
the Chandigarh Planning Area including Municipal corporation area having 114 sq. Km.

As per 2001 census, the population of the study area is 9.66 lakhs with a decadal
growth rate of 50 per cent. At present about 6,00,000 vehicles are plying in the city
roads of Chandigarh. The average yearly growth rate of vehicle population in the
city is about 6%. Two National Highways, NH 21 and NH 22 traverse through the
city. The city is developed in Semi circular shape. The road network is comprised by
58% of 4 lane roads, 42% of 6 lanes. Chandigarh city is a planned city with wide
roads and other facilities. Public transport need of the city is performed through bus
operated by Chandigarh Transport Undertaking (CTU).

Study Area

: 150 Sq.Km

Administrative Boundary

: Chandigarh Planning Area

Population (2001)

: 9.66 lakhs

2007 Population (estimated)

: 11.2 Lakhs

2007 Employment (estimated)

: 2.44 lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: Yes

Population Category

:2

Shape Category

:1

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 30

A-46

<!-- page 61 -->

Zoning Map

Network Map
Network Length
Number of Links
Number of Nodes

Number Of Zones
Internal Zones
External Zones

: 393Km
: 1050
: 670

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 1.18
: 11.49
: 4.50

Share (%)
10
28
3
18
23
18

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-47

Trips
1.14
3.17
0.4
2.10
2.62
2.06

: 24
: 20
:4

<!-- page 62 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions
Calibration Functions
a
96.6

b
0.6026

c
0.04023

IV. Mode Choice
VM = α TTM + β TCM
where
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
α

β

Two Wheeler

0.3849

-0.2002

Car

0.76875

-0.1514

Auto
Public
Transport

0.4194

-0.1387

-0.0271

0.23445

Mode

V. Travel demand Forecast
Horizon Year Trips/Day

Mode

2011

2021

2031

value

%

value

%

value

%

PV+ IPT (In Nos)*

8.241

51.26

15.237

57.80

27.392

63.42

PT (in Nos.)*

1.550

9.64

2.264

8.59

3.630

8.40

6.286
NMT *(In nos.)**
(Note:*- model output, **-estimated)

39.10

8.862

33.62

12.169

28.17

A-48

<!-- page 63 -->

Name of the City

Hubli- Dharwad

Hubli, situated 428 kms from Bangalore, is a twin city with Dharwad which is 16 km
away and is a major town located in the northern part of Karnataka. Hubli City is the
commercial centre of the district. It is also an important city for the Indian Railways,
being the zonal headquarters of South Western Railway and the Hubli Division.
Dharwad is the cultural capital of Northern Karnataka. Due to extremely favorable
climatic conditions and because of the aesthetic people, it is often called the 'paradise of
pensioners'. The study area is the Hubli -Dharward planning area including the two
Municipal corporations and suburbs with an area of 200 Sq. Km. As per 2001 census the
Population is 9.86 lakhs. National Highway No 4 passes through the city. Public
Transport need of the city is performed by buses operated by Karnataka State Road
Transport Corporation (KSRTC).

I. General:
Study Area

: 200 sq.km

Administrative Boundary

: Hubli -Dharward Planning Area

Population (2001)

: 9.68 lakhs

2007 Population (estimated)

: 11.17 lakhs

2007 Employment (estimated)

: 2.64lakhs

Shape of the city

: Linear

Capital City (Yes/No)

: No

Population Category

:2

Shape Category

:3

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 23

A-49

<!-- page 64 -->

Zoning Map

Network Map

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 0.92
: 10.23
: 3.95

Share (%)
25
10
0.5
22
22.5
19

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-50

Trips
(Lakhs)
2.57
0.99
0.04
2.30
2.37
1.96

<!-- page 65 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai, Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj - Trip Attractions to zone j,
‘Fij- Deterrence Function

a, b, c- Calibration functions
Calibration Functions
a
102.2

b
0.6358

c
0.04230

IV. Mode Choice
VM = α TTM + β TCM
where
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode

α

β

Two Wheeler

0.3077

1.0696

Car

0.37884

-0.0681

Auto

0.4065

-0.0619

Public
Transport

-0.0324

0.19253

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

5.385
1.302
PT (in Nos.)*
4.591
NMT *(In nos.)**
(Note:*- model output, **-estimated)
PV+ IPT (In Nos)*

%

47.75
11.54
40.71

A-51

2021
Value
(Lakhs)

8.005
1.514
5.126

%

54.66
10.34
35.00

2031
Value
(Lakhs)

11.269
1.893
5.464

%

60.50
10.16
29.33

<!-- page 66 -->

Name of the City

GUWAHATI

Guwahati, the capital city of Assam, is recognized to be the most critical city in the
Northeast India. The city has a well-developed connectivity with the rest of the
country and acts as the gateway to the entire North Eastern India. Guwahati is a part
of Kamrup District and located on the banks of the Brahamaputra River. The study
focuses on the Guwahati Metropolitan Development Authority jurisdiction,
comprising of Guwahati Municipal Corporation Area (GMCA), North Guwahati
Town Committee area, Amingaon and some revenue villages. The area is known as
the Guwahati metropolitan area (GMA) and covers an area of 264 Sq.km. As per
2001 census the population is 10.60 lakhs with a decadal growth rate of 38.6 per cent.
The city is developed in semi circular shape. Three National Highways NH 31, NH
37 and NH 40 connect the city with other places.

Public Transport needs are

performed by buses operated by Assam State Transport Corporation (ASTC) and by
Private operators.

I. General:
Study Area

: 264 Sq.Km

Administrative Boundary

: Guwahati metropolitan area

Population (2001)

: 10.60 lakhs

2007 Population (estimated)

: 11.9 Lakhs

2007 Employment (estimated)

: 2.64 lakhs

Shape of the city

: Linear

Capital City (Yes/No)

: Yes

Population Category

:3

Shape Category

:3

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 20

A-52

<!-- page 67 -->

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode

: 0.98
: 11.62
: 4.14

Trips
(Lakhs)
2.35
2.10
1.39
0.94
2.39
2.45

Share (%)

Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

20
18
12
8
21
21

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions and values as follows
Calibration Functions
a

b

c

99.0

0.6168

0.04111

A-53

<!-- page 68 -->

IV. Mode Choice
VM = α TTM + β TCM

Where,
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows

Mode

α

β

Two Wheeler

0.1120

-0.1248

Car

0.08727

-0.0290

Auto

0.0227

-0.0287

Public
Transport

-0.0383

0.21015

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

%

2021
Value
(Lakhs)

%

2031
Value
(Lakhs)

%

PV+ IPT (In Nos)*

7.710

55.83

10.626

61.88

14.412

67.5

PT (in Nos.)*

0.591

4.28

0.657

3.82

0.801

3.75

5.510
(Note:*- model output, **-estimated)

39.89

5.890

34.3

6.138

28.75

NMT *(In nos.)**

A-54

<!-- page 69 -->

Name of the City

AMRITSAR

Amritsar is a border city located in the northern western part of Punjab. It is 228 km
west of State capital of Chandigarh, 82 km from Jalandhar. The study area is the
development area comprised by the city and the suburban areas. The area covered
by the Municipal Corporation of Amritsar is taken as the study area is 139.58 sq. km,
out of which 105.86 sq. km is developed and 33.72 sq. km is undeveloped. The study
area has a population of 10.85 as per 2001 census. The city is developed in linear
shape. National highway No. 1 and National Highway No. 15 connects the city with
other region. The road network is comprised by 37% of 2 lane roads, 55% of 4 lane,
etc. The city of Amritsar does not possess any public transport system for intra city
movements.

I. General:
Study Area

: 150 Sq. km

Administrative Boundary

: Amritsar Planning Area

Population (2001)

: 10.85 lakhs

2007 Population (estimated)

: 11.08 Lakhs

2007 Employment (estimated)

: 4.06 Lakhs

Shape of the city

: Linear

Capital City (Yes/No)

: No

Population Category

:3

Shape Category

:3

Terrain

: Plain

Availability of City Bus service

: Absent

Average Travel speed (KMPH)
on major corridors

: 24

A-55

<!-- page 70 -->

38

24

23
8

59

46
47

31

56

4

7

6

54

30

45

29

53

28

39

48

33

60

20

25

21

34
22
2 32 3
57
9
1
51
12
10
36
40
43 41 42
37
58
35

13

55

44

16
19

14

52

15

17
18

49

50

26

27
5

Network Map
Network Length
Number of Links
Number of Nodes

Zoning Map
: 469Km
: 1839
: 1239

Number Of Zones
Internal Zones
External Zones

II. Base year Trip Characteristics
Per capita Trip Rate
Daily Trips (Lakhs)
Average Trip Length (Km)
Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

Share (%)
31
14
4
0
27
25

: 1.08
: 12.38
: 4.50
Trips (Lakhs)
3.84
1.67
0.51
0.00
3.32
3.04

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-56

: 67
: 64
:3

<!-- page 71 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions
Calibration Functions

a

b

C

94.2

0.5886

0.03935

IV. Mode Choice
VM = α TTM + β TCM
where
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode

α

Β

Two Wheeler

-0.1788

1.3190

Car

-0.00750

0.0621

Auto

0.2020

-0.1850

-

-

Public
Transport

V. Travel demand Forecast
Mode

PV+ IPT (In PCU)*
PT (in Nos.)*
NMT *(In nos.)**

2011
Value
(Lakhs)

6.951
0.0
6.76

Horizon Year Trips / Day
2021
Value
%
%
(Lakhs)

50.68
0.0
49.32

(Note:*- model output, **-estimated)

A-57

10.23
0.0
7.53

57.60
0.0
42.40

2031
Value
(Lakhs)

14.49
0.0
7.99

%

64.46
0.0
35.54

<!-- page 72 -->

Name of the City

THIRUVANANTHAPURAM

Thiruvananthapuram is the State capital of Kerala and is one of the major tourist
destinations in India. Thiruvananthapuram is a strategically important city in southern
India as the city is very close to the international shipping route and East-West shipping
axis. Being close to Tamil Nadu Border, the city provides a key link in movement of
goods and passengers to and from southern Tamil Nadu into Kerala. The study area for
the purposes of this study is the Thiruvananthapuram Development Authority (TRIDA)
area that constitutes the city and the adjoining 10 gram panchayats including the
upcoming 3 satellite towns. The Thiruvananthapuram Development Authority (TRIDA)
area spreads over 310 Sq Kms. As per 2001 census the population is 11.22 lakhs. The city
is developed in semi circular shape. National Highway 47 connects the city with Tamil
nadu and other places. The road network is comprised by 21% of 2 lane roads, 70% of

4 lane, etc. Public Transport need of the city is performed by buses operated by
Kerala State Road Transport Corporation (KSRTC) and private operators.

I. General:
Study Area

: 310 Sq. Km

Administrative Boundary

: Thiruvananthapuram Development Area

Population (2001)

: 11.22 lakhs

2007 Population (estimated)

: 13.83 Lakhs

2007 Employment (estimated)

: 3.71 Lakhs

Shape of the city

: Linear

Capital City (Yes/No)

: Yes

Population Category

:3

Shape Category

:2

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
On major corridors

: 23

A-58

<!-- page 73 -->

Network Map
Network Length
Number of Links
Number of Nodes

Zoning Map
:562Km
: 806
: 575

Number Of Zones
Internal Zones
External Zones

II. Base year Trip Characteristics
Per capita Trip Rate
Daily Trips
Average Trip Length (Km)
Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 1.03
: 12.47
: 4.7

Share (%)

Trips (Lakhs)

19
10
10
22
20
19

2.39
1.27
1.22
2.69
2.53
2.37

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-59

: 94
: 91
:3

<!-- page 74 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions
Calibration Functions
a
86.6

b
0.5436

c
0.03654

IV. Mode Choice
VM = α TTM + β TCM

where
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode

α

β

Two Wheeler

-0.0131

0.1402

Car

0.15684

-0.0026

Auto

0.1105

-0.0592

Public
Transport

-0.0440

0.29271

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

%

2021
Value
(Lakhs)

%

2031
Value
(Lakhs)

%

PV+ IPT (In Nos)*

6.879

50.09

9.732

56.76

13.315

62.32

PT (in Nos.)*

1.619

11.79

1.792

10.46

2.181

10.21

38.13

5.615

32.78

5.870

27.47

5.236
(Note:*- model output, **-estimated)
NMT *(In nos.)**

A-60

<!-- page 75 -->

Name of the City

MADURAI

The temple town of Madurai, situated on the bank of river Vaigai and 500 km
southwest of Chennai, is the third largest city in Tamil Nadu and the district
headquarters of Madurai District. It is a famous pilgrim centre and gateway to south
Tamil Nadu having the famous Meenakshi temple at its core. Madurai is a town and
a municipal corporation. The study area is the Local Planning area of Madurai
covering 732 Sq. Km. As per 2001 census the population is 11.85 lakhs. The city is
developed in linear shape. Two National Highways, namely, NH 7 and NH 49
provide regional connectivity to Madurai.

The Public Transport needs of the city

are performed by the bus operated by State Transport Corporation (STC).

I. General:
Study Area

: 732 Sq. km

Administrative Boundary

: Madurai Local Planning Area

Population (2001)

: 11.85 lakhs

2007 Population (estimated)

: 14.24 Lakhs

2007 Employment (estimated)

: 3.61 Lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: No

Population Category

:3

Shape Category

:1

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 27

A-61

<!-- page 76 -->

Network Map
Network Length
Number of Links
Number of Nodes

Zoning Map

:405 Km
: 973
: 661

Number Of Zones
Internal Zones
External Zones

II. Base year Trip Characteristics
Per capita Trip Rate
Daily Trips
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

Share (%)
15
7
9
16
34
18

: 1.14
: 16.23
: 5.20

Trips (Lakhs)
2.46
1.20
1.40
2.64
5.54
2.99

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-62

: 94
: 81
: 13

<!-- page 77 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions and values as follows
Calibration Functions
a

b

c

85.6

0.5377

0.03617

IV. Mode Choice
VM = α TTM + β TCM
Where,
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows

α

β

Two Wheeler

0.0046

-0.0009

Car

0.02579

-0.0445

Auto

0.0598

-0.1018

Public Transport

-0.0017

-0.10334

Mode

V. Travel demand Forecast
Horizon Year Trips/Day
Mode

2011
Value
(Lakhs)

PV+ IPT (In Nos)*

2021
%

Value
(Lakhs)

7.751

41.98

PT (in Nos.)*

1.298

NMT *(In nos.)**

9.413

2031
%

Value
(Lakhs)

%

11.508

49.58

16.234

56.55

7.03

1.528

6.58

1.925

6.7

50.99

10.174

43.83

10.546

36.74

(Note:*- model output, **-estimated)

A-63

<!-- page 78 -->

Name of the City

AGRA

Agra is situated on the Western Bank of river Yamuna at about 200 Kms from Delhi
in the State of Uttar Pradesh. Agra is one of the key tourist destinations attracting
tourists from all over the world. The study area is the Agra Development Area
comprising about 200 sq. kms. and about 13.69 lakh population as per 2001 census.
The population of Agra city is 12.75 lakhs as per Census 2001 with a decadal growth
rate of 30.37 per cent. The total number of registered vehicles in Agra city in 2006 is
4, 75,700. The vehicle population has experienced an annual growth rate of 10%
during the past 10 years. Agra at present does not offer good intra-city public
transportation to local and floating population.

I. General:
Study Area

: 200 Sq.Km

Administrative Boundary

: Agra Development Area

Population (2001)

: 13.69 lakhs

2007 Population (estimated)

: 16.77 Lakhs

2007 Employment (estimated)

: 3.69 Lakhs

Shape of the city

: Circular

Capital City (Yes/No)

: No

Population Category

:3

Shape Category

:1

Terrain

: Plain

Availability of City Bus service

: Present

Average Travel speed (KMPH)
on major corridors

: 28

A-64

<!-- page 79 -->

79

82

91

87

83

90

92

89

16
14

17

18

19

21
20

30

29
31
32

88

13

86 85
8

9

15

81

52

78
77

2
75

3

74

22

10
7
4
25 11 6
24
5
12
28
36
37
34
27
35 39 38
26
41
40
33
42
49
44
43
45
50
48
51
46 47
23

80

73

66

65

72

67
70

1

69
53

71

68
54

55 56

57

63

58

64

62 61
60
59

Network Map
Network Length
Number of Links
Number of Nodes

Zone Map
: 269Km
: 693
: 500

Number Of Zones
Internal Zones
External Zones

II. Base year Trip Characteristics
Per capita Trip Rate (all modes)
Daily Trips
Average Trip Length (Km)

Mode
Two Wheeler
Car
Auto
Public Transport
Walk
Cycle

: 1.06
: 17.81
: 4.40

Share (%)
31
17
3
2
27
21

III. Base year Calibrated Model Functions
Trip Distribution
Tij =Ai Oi Bj Dj Fij ,

Fij = aCbij e - cCij

A-65

Trips (lakhs)
5.45
2.95
0.54
0.32
4.83
3.72

: 95
: 90
:5

76

<!-- page 80 -->

Where, ‘C’ is the generalized cost of travel from one zone to other.
Ai , Bj - Balancing Factors,
Oi - Trip Production from zone I,
Dj- Trip Attractions to zone j,
‘Fij- ’ Deterrence Function

a, b, c- Calibration functions and values as follows
Calibration Functions
a
80.0

b
0.5044

c
0.03409

IV. Mode Choice
VM = α TTM + β TCM
where
VM - Utility function
TTM - Travel Time by Mode M
TCM - Travel Cost by Mode M
α and β are calibration parameters specific to each mode and values are as follows
Mode

α

β

Two Wheeler

0.1601

-0.4333

Car

-0.02374

-0.0387

Auto
Public
Transport

-0.0955

-0.0059

-0.0441

0.34771

V. Travel demand Forecast
Mode

PV+ IPT (In Nos)*
PT (in Nos.)*
NMT *(In nos.)**

2011
Value
(Lakhs)

11.053
0.178
9.783

Horizon Year Trips/Day
2021
Value
%
%
(Lakhs)

52.60
0.85
46.56

(Note:*- model output, **-estimated)

A-66

17.785
0.234
12.025

59.20
0.78
40.03

2031
Value
(Lakhs)

24.647
0.293
12.59

%

65.67
0.78
33.55
