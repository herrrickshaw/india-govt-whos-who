---
doc_id: "0bccdd8fa7bb80dc"
source_url: "https://www.mea.gov.in/images/pdf/Extension_of_Vacancy_Circular_new.pdf"
ministry: "External Affairs (MEA)"
title: "Extension of the last date Vacancies Circular for the post of Passport Officer, Deputy Passport Officers & Assistant Passport Officers in CPO on deputation basis"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "83a797534148576c"
---

<!-- page 1 -->

No. V.1V/575/8/2016 1
Ministry of External Affairs
CPV Division
Patiala House Annexe,
Pe Tilak Marg, New Delhi-110001,
Dated: 08.07.2016
VACANCY CIRCULAR
The undersigned is directed to refer to this Ministry’s vacancy circulars of even no.
dated 15.06.2016 and to say that the last date of the vacancy circular has been extended upto
29" July, 2016.
2, All Ministries / Department of Government of India are requested to circulate the
above posts among the officers under the Central Government, working with them and
forward the application of eligible and interested officers, along with their dossier and a
certificate to the effect that they are clear from vigilance angle, to the undersigned, latest by
29" July, 2016.
eee
(A mana)
DPO(PVA)
011-23386936
To,
I. All Ministries/ Department of Government of India
2. All Chief Secretaries to the State Governments.
Copy to:-
1. Ministry of External Affairs-[Kind attn to: Joint Secretary (AD)]
2. Director (XP), Ministry of External Affairs, Shastri Bhawan, New Delhi- with the
request to upload this circular on the MEA’s website.
3. Director(PSP), Ministry of External Affairs, CPV Division, New Delhi -with the request
to upload this circular on the Passport Seva website
4. Director (CS), DoPT, Lok Nayak Bhawan, Khan Market, New Delhi- with the request to
upload the circular on DoPT’s website for wider circulation
5. All Passport Offices.
6. Branch Secretariat at Chennai, Kolkata, Guwahati, Hyderabad.
7. Spokesman, JCM, MEA, New Delhi.
8. O/o JS (PSP) & CPO, CPV Division, MEA, New Delhi.
