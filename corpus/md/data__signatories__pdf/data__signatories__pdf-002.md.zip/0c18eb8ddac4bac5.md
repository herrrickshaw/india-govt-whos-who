---
doc_id: "0c18eb8ddac4bac5"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/65409f654ffd8b2cb5b7f1e1d93d94c2.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of short code '155340' to Department of Rural Development and Panchayat Raj Government of Tamil Nadu"
date: "2022-10-06"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c205c17a6b0fb839"
---

<!-- page 1 -->

1b- 3 /20 'i 'i -A'J-1 1i/V UL.11
'3063239/2022

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No.16 ,3/2011 /AS-lll/Vol.ll/320/2.3'q

Dated: 06-10-2022

To,
All Access Service Providers.
Subject:
Allocation of Short Code '155340' to Department of Rural
Development and Panchayat Raj, Government of Tamil Nadu.

Short code '155340' is allocated as citizen centric services helpline related
to water supply, street lighting, sanitation, basic amenities and other grievances of
the rural public to Department of Rural Developrrieh(Panchayat Raj , Government
of Tamil Nadu with following features as:
(i)
Category-I: Service (i.e. mandatory service to be provided by
a.II the Access providers).
(ii)
Accessibility: R·estricted i.e. within state.
(iii)
Metered Service: (It may be taken as Called Party Pays or
Calling Party Pays depending on a separate intimation, to this effect,
issued from the agency to which th is short code is allocated in
furthe rance to this DoT instruction).
2.

All are requested to take necessary action.

3.

This is issued with the approval of competent authority.
Signed by Sanchit Kumar
Garg
Date: 06-10-2022 10:17:47

(Sanchit Kumar Garg)
ADG (AS-Ill)
Copy forwarded for information and necessary action, if any, to:

1.
Secretary, TRAI.
2.
CMD MTNU CMD BSNL. ·
.·· :_.- . ··
3.
Dr. Darez Ahamed, Commissioner, Rural Development and panchayat Raj,
Panagal Building, Saidapet, Chennai-600015 w.r.t. letter No. 31175/2022/PRI 3.1
dt. 19.09.2022 with a request to appoint a nodal officer to implement the helpline.
The Nodal officer may contact Sr. DOG (LSA), LSA Unit, concerned States/UTs.
4.
Director (P&N), DGT (HO)'. (respective LSA field unit may be asked to co­
ordinate with. respective Nodal Officers and TSPs for implementation of Helpline,
as and when approached).
5.
A copy for upload on DoT Website.
