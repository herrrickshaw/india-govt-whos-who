---
doc_id: "0be6e8eabd1caa23"
source_url: "https://www.labour.gov.in/static/uploads/2026/09/da0b77713e836df14d4b5c7dedd1e7b0.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification i.r.o. under Rule 111(1) of the OSH&WC Rules, 2026"
date: "2026-07-07"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "0b32cf80fc7d778c"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-जे.एच.-अ.-11072026-274403
xxxGIDHxxx
CG-JH-E-11072026-274403
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 547]
No. 547]

नई कदल्ली, बृहस्ट्पजतिार, िुलाई 9, 2026/आषाढ 18, 1948
NEW DELHI, THURSDAY, JULY 9, 2026/ASHADHA 18, 1948

श्रम और रोिगार मंत्रालय
(खान सुरक्षा महाजनदेिालय)
अजधसूचना
धनबाद, 7 िुलाई, 2026
सा.का.जन. 605(अ).— उपिीजिकािन्य सुरक्षा, स्ट्िास्ट््य और काययदिाएं (के न्रीय) जनयम, 2026 के जनयम 111
के उप-जनयम 1 के तहत मुझे प्रदत्त िजियों का प्रयोग करते हुए, मैं, उज्ज्िल ता, खान मुख्य जनरीक्षक-सह-सुजिधाप्रदाता,
जिसे खान सुरक्षा महाजनदेिक के रूप में भी नाजमत ककया गया है, एतद्द्वारा जनर्दयष्ट करता हूँ कक प्रारं जभक जचककत्सा परीक्षा
की सूचना का प्रपत्र जनयोिा द्वारा िांच ककए िाने िाले व्यजि को कदया िाएगा।
दायरा:

यह फॉमय उपिीजिकािन्य सुरक्षा, स्ट्िास्ट््य और काययदिाएं (के न्रीय) जनयम, 2026 के जनयम 111 के
उप-जनयम 1 के अनुसार िांच ककए िाने िाले व्यजि को जनयोिा द्वारा दी िाने िाली प्रारं जभक जचककत्सा
परीक्षा की सूचना जनर्दयष्ट करता है।

प्रयोज्यता:

नोटिस का यह रूप एक जनयोिा द्वारा िांच ककए िाने िाले व्यजि को िारी ककया िाएगा और िारी
ककया गया ऐसा नोटिस व्यािसाजयक सुरक्षा, स्ट्िास्ट््य और कायय जस्ट्िजत (कें रीय) जनयम, 2026 के जनयम
111 के उप-जनयम 1 के अनुसार जनयोिा द्वारा परीक्षा प्राजधकरण को भेिा िाएगा और सभी खानों पर
लागू होगा।

5165 GI/2026

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

प्रारं जभक जचककत्सा परीक्षा की सूचना
सं .

कदनांक......................

श्री/श्रीमती/सुश्री................... रोिगार की प्रकृ जत.................. .......... पुत्र/पुत्री या/पत्नी .................. को
इसके द्वारा सूजचत ककया िाता है कक उसे उपिीजिकािन्य सुरक्षा, स्ट्िास्ट््य और काययदिाएं (के न्रीय) जनयम, 2026 के
जनयम 111 के उप-जनयम 1 के तहत प्रारं जभक जचककत्सा परीक्षा के जलए स्ट्ियं उपजस्ट्ित होना होगा..................... (िांच
प्राजधकारी का नाम दीजिए) ........... (स्ट्िान का सिीक जििरण दें) ............ (जतजि दें) ........ (समय दें)।
श्री/श्रीमती/ सुश्री............. ध्यान दें कक यकद िह उजचत कारण के जबना, उपरोि जचककत्सा परीक्षा के जलए स्ट्ियं
उपजस्ट्ित होने में जिफल रहते है, तो िह ................ (जतजि) से खान में रोिगार के जलए पात्र नहीं होंगे |

माजलक/एिेंि/प्रबंधक के हस्ट्ताक्षर और नाम जतजि और मुहर
खान/कं पनी का
[फा. सं. डीिीएमएस/02-1/2026/सीएमसी (मुख्यालय)]
उज्ज्वल ता, खान मुख्य निरीक्षक-सह-सुनवधाप्रदाता

MINISTRY OF LABOUR AND EMPLOYMENT
(Directorate General Of Mines Safety)
NOTIFICATION
Dhanbad, the 7th July, 2026
G.S.R. 605(E).— In exercise of the powers conferred on me under sub-Rule 1 of the Rule 111 of the
Occupational Safety, Health and Working Conditions (Central) Rules, 2026, I, Ujjwal Tah, Chief Inspector-cumFacilitator of Mines, also designated as the Director General of Mines Safety, hereby, specify the form of the notice of
initial medical examination shall be given by an employer to the person to be examined.
Scope:

This form specify the notice of initial medical examination to be given by an employer to the person
to be examined as per sub-rule 1 of the Rule 111 of the Occupational Safety, Health and Working
Conditions (Central) Rules, 2026.

Applicability:

This form of the notice shall be issued by an employer to the person to examined and such notice
issued shall be sent to examination authority by an employer as per sub-rule 1 of the Rule 111 of the
Occupational Safety, Health and Working Conditions (Central) Rules, 2026 and applicable to the all
mines.
Notice of Initial Medical Examination

No…………..

Date………………….

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

3

भारत का रािपत्र : असाधारण

Sri/Srimati/Miss………………. Nature of employment……………… son/daughter or/wife of…………………….
…………………………is hereby notified that he/she should present himself/herself for an Initial Medical Examination,
under sub-rule (1) of the rule 111 of The Occupational Safety, Health And Working Conditions (Central) Rules, 2026,
before………………… (give name of the examining authority) at ……….. (give exact description of place) on
………… (give date) at …….. (give time).
Shri/Shrimati/Miss…………. may note that if he/she fails, without reasonable cause, to submit himself/herself
for the medical examination aforesaid he/she shall not be eligible for employment to the mine from………………(date)

Signature & Name of Owner/Agent/ Manager date & Seal
Name of Mine/ Company

[F. No. DGMS/02-1/2026/CMC (HQ)]
UJJWAL TAH, Chief Inspector-cum-Facilitator of Mines

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. BHABAJIT
DEKA

Digitally signed by BHABAJIT
DEKA
Date: 2026.07.11 16:32:58 +05'30'
