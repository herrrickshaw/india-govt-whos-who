---
doc_id: "0c4efd1d7bb733ac"
source_url: "https://mohua.gov.in/static/uploads/2026/06/532115b8828dac50c68532c359b50e9a.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Notifcation No. S.O.1236 dated  27.03.1979 U/S 1(2) of the Delhi Rent Control Act, 1958"
date: "2026-06-19"
pages: 78
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e0f5235c788b5697"
---

<!-- page 1 -->

REGISTERED NO. D. (D)-73

The Gazette of India
PUBLISHED BY AUTHORITY
No. 15 ]

NEW DELHI, SATURDAY, APRIL 14, 1979/CHAITRA 24, 1901
Separate Paging is given to this Part in order that it may be filed as a separate compilation.

PART II—Section 3—Sub-section (ii)

Statutory Orders and Notifications issued by the Ministries of the Government of India
(other than the Ministry of Defence) by Central Authorities
(other than the Administrations of Union Territories)

ELECTION COMMISSION OF INDIA
ORDER
New Delhi, the 21st February, 1979
S.O. 1189.—Whereas the Election Commission is satisfied that Shri Ramchandra Ganga Lokhande, Pendori, Taluka
Karjot, District Kulaba, a contesting candidate for General
Election to the Maharashtra Legislative Assembly held in
February, 1978 from 18-Khalapur constituency, has failed
to lodge an account of his election expenses as required by
the Representation of the People Act, 1951, and the Rules
made thereunder;
And whereas the said candidate, even after due notice,
has not given any reason or explanation for the failure and
the Election Commission is satisfied that he has no good
reason or justification for the failure ;
Now, therefore, in pursuance of section 10A of the
said Act, the Election Commission hereby declares the said
Shri Ramchandra Ganga Lokhande to be disqualified for
being chosen as, and for being, a member of cither House
of Parliament or of the Legislative Assembly or Legislative
Council of a State for a period of three years from the
date of this order.
[No. MT-LA/18/78(111)]
1367GI/78—

(973)

<!-- page 2 -->

974

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAlTRA 24, 1901

[PART II—SEC. 3(ii)]

S.O. 1190.—Whereas the Election Commission is satisfied
that Shri Mahadik Baliram Sitaram, Musco Colony, F-24,
Khopoli, Taluka Khalapur, District Kul'aba, a contesting
candidate foi general election to the Maharashtra Legislative
Assembly held in February, 1978 from 18-KhaIapur constituency, has failed to lodge an account of hia election
expends as requiied by the Representation of the 1'eoole
Ac, 1951, and the rules made thereunder;
And whereas, after considering the representation made
by the said candidate, the Election Commission is further
satisfied thai he has no good reason or justification for the
failure ;
Now, therefore, in pursuance of section 10A of the said
Act, the Election Commission hereby
declares the said
Shri Mahadik Baliram Sitaram to be disqualified for being
chosen as., and for being, a member of either House of
Parliament or of the Legislative Assembly or Legislative
Council of a State for a period of three years from the
date of this order.
[No, MT-LA/18/78(112)1

New Delhi, the 7th. March, 1979
S.0 1192.—Whereas the Election Commission is satisfied
that Shri MiuTa Nurulbark Abbas, 1123 ' C
Kolhapur,
Maharashtra a contesting candidate for General
Election
to the Maharashtra Legislative Assembly held in February,
1978 from 284-K.olhapur constituency, has failed to lodge
an account of his election expenses as required by the
Representation of the People Act, 1951, and the Rules
made thereunder ;
And whereas the said candidate, tven after due notice,
has not given any reason or explanation for the failure and
the FFcction Commission is satisfied that he has no fiood
reason or justification for the failure ;
Now, therefore, in pursuance of section 10A of the
said Act, the Election Commission hereby declares the said
Slid Mulla Nurulbark Abbas to be disqualified for being
chosen as, and for being a member of either House of
Parliament or of the Legislative Assembly or Legislative
Council of a State for a period of three years from the
date of this order.
[No. MT-LA/284/78(116)J

<!-- page 3 -->

975
S.O. 1194.—Whereas the Election Commission is satisfied
that Shri Bhola Rabidas,
Santipur
Colaney,
Sikhar-5
(Assam ^) a contesting candidate for general election to the
Legislative Assembly held in February, 1978, from 9-Silchar
constituency, has failed to lodge an account of his election
expenses as required by the Representation of the People
Act, 1951. and the Rules madt; thereunder;
And whereas the said candidate, even after due notice
has not given any reason or explanation for the failure and
the Election Commission is satisfied that he has no good
reason or justification for the failure ;
Now, therefore, in pursuance of section 10A of the said
Act, the EFection Commission hereby
declares the said
Shri Bhola Rabidas to be disqualified for being chosen as,
and for being, ;i member of either House of Parliament or
of the Legislative Assembly or Legislative Council of
a
Slate for a period of three years from the date of this
order.
[No. AS-LA/9/7S(2)]

New Delhi, the 9th March, 1979
S.O. 1193.—Whereas the Election Commission is satisfied
that Shri Harendra Chandra Paul, Hospital Road, Silchar
(Assam) a contesting candidate for general election to the
Legislative assembly held in February, 1978, from 9-Silchar
constituency, has failed to lodge an account of his election
expenses as required by the Representation of the People
Act, 1951, and the Rules made thereunder;
And whereas the said candidate, even after due notice,
has not given any reason or explanation for the failure and
the Election Commission is satisfied that he has no good
reason or justification for the failure ;
Now, therefore, in pursuance of section 10A of the said
Act, the Election Commission hereby
declares the said
Shri Harendra Chandra Paul to be disqualified for being
chosen as, and for being a member of the either House of
Parliament or of the Legislative Assembly or Legislative
Council of a State for a period Of three years from the
date of this order.
[No. AS-LA/9/78(l)]

New Delhi, the 16th March, 1979
S.O. 1195.—Whereas the Election Commission is satisfied
that Shri Edupalli Peddi Raiu, First Ward, Pulla Village,
West Godavari District, (Andhra Pradesh), a contesting candidate for general election to the Andhra Pradesh Legislative
Assembly held in February, 1978, from 68-Ungutur constituency, has failed to lodge any account of his election expenses
ag required by the Representation of the People Act, 1951,
and the Rules made thereunder ;
And whereas the said candidate, even after due notices, has
not given any reason or explanation for the failure and the
Election Commission is further satisfied that he has no good
reason or justification for the failure ;
Now, therefore, in pursuance of section 10A of the said
Act, the Election Commission hereby declares the paid Shri
Edupalli Peddi Raju to be disqualified for being chosen as,
and for being a member of either House of Parliament or
of the Legislative Assembly or Legislative Council of a State
for a period of three years from the date of this order.
[No. AP-LA/68/78(20)J

<!-- page 4 -->

976

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(ii)J

New Delhi, the 23rd March, 1979
S.O. 1197.—Whereas the Election Commission is satisfied
that Shri Dineswar Tasha, Gormur Duliagaon,
Jorhat-7
(Assam) a contesting candidate for general election to the
Legislative Assembly held in February, 1978, from 101-MarianI
constituency, has failed to lodge an account of his election
expenses as required by the Representation of the People Act,
1951, and the Rules made thereunder;
And whereas the said candidate; even after due notice, has
not given any reason or explanation for the failure and the
Election Commission is satisfied that he has no good reason
or justification for the failure ;
Now, therefore, in pursuance of section 10A of the said
Act, the Election Commission hereby declares the said Shri
Dineswar Tasha to be disqualified for being chosen as, and
for being, a member of either House of Parliament or of the
Legislative Assembly or Legislative Council of a State for u
period of three years from the date of this order.
[No. AS-LA/101/78(in
New Delhi, the 20th March, 1979
S.O. 1196.—Whereas the Election Commission is satisfied
that Shri K. S. Kandasamy, Melachinniahpuram, T. SeJapatti Post, (via) R. R, Nagar, District Ramanathapuram, a
Con.estiriK candidate for election to
the Tamil
Nadu
Legislative Assembly from 206-Virudhunagar
Constituency
held in June, 1977, has failed to lodge any account of his
election expenses as required by the Representation of the
People Act, 1951, and the Rules made thereunder;
And whereas .he said candidate, even after due notices
has not given any reason or explanation for the failure
and the Election ComrniSjion is further satisfied that he has
no good reason or justification for such failure ;
Now, therefore, in pursuance of section 10A of (he said
Act, the Election Commission hereby
declares the said
Shri K S. Kandasamy to be disqualified for being chosen
as, and for being, a member of either House of Parliament
or of the Legislative Assembly or Legislative Council of a
State for a period of three years from the date of thin
order.
[No. TN-IA/206/77(15)j

S.O. 1198.—Whereas the Election Commission is satisfied
that Shri Jogen Buragohain, Devaguri Chapori Gaon, P.O.
Mariani, District Jorhat (Assam), a contesting candidate for
general election to the Legislative Assembly held in February,
1978, from 101-Manani constituency, has failed to lodge an
account of his election expenses as required by the Representation of the People Act, 1951, and the Rules madr thereunder ;
And whereas the said candidate, even after due notice, has
not given any reason or explanation for the failure and the
Election Commission is satisfied that he has no good reason
or justification for the failure ;
Now, therefore, in pursuance of section 10A of the said
Act, the Election Commission hereby declares the said Shri
Jogen Buragohain to be disqualified for being chosen as, and
for being, a member of either House of Parliament or of
the Legislative Assembly or Legislative Council of a Star*
for a period of three years from the date of this order.
(No. AS-LA/101/78(2)]

<!-- page 5 -->

97?
ORDERS
New Delhi, the 24tb March, 1979
S.O. 1200.—Whereas the Election Commission is satisfied
that Shri Kailash, 2093, The Mall, Bhatinda,
District
Bhatinda,
(Punjab) a contesting candidate for general elec1
tion to the Punjab Legislative Assembly herd in June, 1977
from 11-Bhatindu constituency, has failed to
lodge an
account of his election expenses at all as required by the
Representation of the People Act. 1951, and the Rules made
ihereunder ;
And whereas the said candidate, even after the notice,
has not given any reason or explanation for the failure and
the Erection Commission is satisfied that he has no good
reason or justification for the failure ;
Now, therefore, in pursuance of section 10A of (he said
Act, the Election Commission hereby declares the said
Shri Kailash to be disqualified Cor being chosen as, and for
being, a member of either House of Parliament or of the
Legislative Assembly or Legislative Council of a State for
a period of three years from the date of this order.
[No. PB-LA/111/77]
V. NAGASUBRAMANIAN, Secy.
S.O. 1199.—Whereas the Election Commission is satisfied
that Sfari Akula Venkata Subbaiah, Gajulamandyam, via Renigunta, Chandragiri Taluk, Chittoor District (Andhra Pradesh),
a contesting candidate for general election to the Andhra Pradesh Legislative Assembly held in February, 1978 from 149Tirupathi constituency, has failed to lodge any account of
hm election expenses as required by the Representation at
the People Act, 1951, and the Rules made thereunder;
And whereas the said candidate, even after due notices,
has not given any reason or explanation for the failure and
the Election Commission is further satisfied that he has no
good reason or justification for the failure;
Now, therefore, in pursuance of section 10A of the said
Act, the Election Commission hereby declares the said Shri
Akula Venkata Subbaiah to be disqualified for being chosen
as, and for being, a member of either House of Parliamem
or of the Legislative Assembly or Legislative Council of a
State for a period of three years from the date of this order.
[No. AP-LA/14S>/78(22)]

MINISTRY OF LAW, JUSTICE AND COMPANY
AFFAIRS
(Department a" Justice)
NOTICE
New Delhi, the 29th March, 1979
S.O. 1201.—Notice is hereby given by the Competent
Authority in pursuance of rale 6 of the Notaries Rules,
1956, that application has been made to the said Authority,
under rule 4 of the said Rules, by Shri S, A, Poonawala,
Advocate, 12, Ismail Building, 381, Dr. Dadabhoy Naorpjl
Road, Fort, Bombay for appointment as a Notary to practise in and throughout the State of Maharashtra.
2. Any objection to the appointment of the said person as
u Notary may be submited in writing to the undersigned
within fourteen clays of the publication of this notice.
[No. F. 22(29 /79-JUR.]

L. D. HINDI, Competent Authority.

<!-- page 6 -->

978

THE GAZETTE OF INDIA : APRIL 14, 197S>/CHAITRA 24, 1901

[PART II—SEC. 3(ii)]

MINISTRY OF FINANCE
(Department of Revenue)
CORRIGENDUM
New Delhi, the 21st Novsmber, 1978
INCOME-TAX
S.O. 1203.—The Department of Revenue hereby amend the
notification No. 2186 (F. No. 203/19/78-ITA. ID dated the
25th February, 1978 as under :—
For
"Poonawalla Research Foundation,
Bombay."
Read
"Serum Institute of India
Research Foundation, Poona."
[No. 2585 (F. No. 203/19/78-ITA. II)]

(Department of Company Affairs)
New Delhi, the 9th April, 1979
S.O. 1202.—In exercise of the powers conferred by section
410 of the Companies Act, 1956 (1 of 1956), the Central Government hereby appoints Shri Murli S. Dcora, Chairman,
Maharashtra State Small Industries Development Corporation,
Bombay, as a member of the Advisory Committee constituted
by it under the notification of the Government of India in
the Ministry of Law, lustice and Company Affairs, Department
of Company Affairs No. S.O. 623(E) dated the 28th October,
1978 and hereby makes the following amendment in the said
notification, namely :—
In the said notification, after entry 4, the following entiy
shall be inserted, namely :—
"5. Shri Murli S. Dwra,"
[File No. 3/4/78-CL. V]
K. N. RAMCHANDRAN, Dy. Secy.

New Delhi, the 2nd January, 1979
INCOME-TAX
S.O. 1204.— It is hercbv mtifbi for general information
thit the followins icie'UMic rev"irch programme has been
jpyj v>v;] forth? period specifi.1.! b)l'">wf;irtns purposes of subMJtio.i (2A1 of Section 35 of th: Lricom>*;'x Act, 1%1 read
with Rule 6(iv) of the licome-ta.\ Act, 196- by the Secretary,
Djnartmont of Science & Technolocy, New Delhi.
N;imc of the Scientific Re- Utilisation of high magnesia and
search Programme :
high silicii limestones of Birmitrapur area for cement manufacture.

<!-- page 7 -->

979
Name of Ihe Spnnsorer :

To be undertaken by:

M/s. Bisra Stone Lime Company
Ltd., Chartered Bunk Building,
Calcutta-700001.
Cemert Research Institute of
India, M-10, South Extn. II,
New Delhi-] 10049.
16-S-78.

INSTITUTION
The National Kidney Foundation (India), Bombay.
This notification is effective for a period of 2 ycant from
4-12-1978 to 3-12-1980
[No. 2670 (F. No. 203/200A/78-ITA. 11]
P. N. JHESfGON, Under Secy.

Proposed ckte of commence men t.
Anticipated date of Com-. 15-4-1979.
pletion.
Re. S6.000.
Estimated oullny

2. The Cement Research Institute, of India, New Delhi
stands approved u/s. 35(l)fii) or the Income-tax Act, 1961 vide
Ministry of Finance Notification No. 10/18/63-ITA, T dated the
21st M.irch, 1961.
[No. 2630 (F. No. 203/150/78-ITA.T1)]

NewDelhi, the 25th Janiury, 1979
S.O. 1206-—It is hereby notified for general information
tint the following scientific research programme has been
approved for tho period specified below for the purposes of subsection (2A) of Section 35 of the Tncomo-tax Act, 1961, by the
Indian Cmncil of Agricultural Research, New Delhi.
1. Scientific Research Pro-

gramme :
Sp MiiOre 1 (i\) by;

M/s. Hindustan Milk Food Manufacturers Ltd., New Delhi.

3, Sponsored (b) a(:

National Dairy Research Institute, Karnr.I.

New Delhi, the 19th January, 1979
S.O. 1205.—It is hereby notified for general information
that the institution mentioned below has been approved by
Indian Council of Medical Research, New Delhi the prescribed authority for the purposes of clause (ii) of subsection (1) of Section 35 of the Income-tax Act, 1961 read
with Rule 6(ii) of the Income-tax Rules, 1962 under the
category of "scientific research association" in the field of
Medical Research, subject to the following conditions :—
(1) That the institution will maintain a separate account
of the sums received by it for scientific research in
the field of medical research.
(2) That the institution will furnish annual returns of
its scientific research activities to the Council for
each financial year by 31st May each year at the
latest in such form as may be laid down and intimated to them for this purpose.

Research project on Socio-Economic Survey of Nabha and
Semana Tehsils, District Patiala

4. D intion of
Programme:

Research 3 years from 1st April, 1979.

5. Fs'imitel Expenditure :

Rs. 3,07,000+10%

2. The National Dairy Research Institute, Kernel stands
approve 1 u ider Section 35(1 )(ii) of the Income-tax Act, I9fil
n i<". vt inifry of Finance (Department of Revenue) Notification
No. 2579 (F. No. 2O3/50/7H-ITA. I!) d:'ted 15th November,
1978.
[No. 2683 ([•'. No. 203/163/76-JTA. I])]

<!-- page 8 -->

9*0

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(ii)]

S.O, 120H.—It is hereby notified for general infnormation
thiii the following scientific research programme has been approved for the period specified below for the purposes of subsection (2A) of section 35 of the Income-tax Act, 1961 by
the Indian Council of Medical Research, New Delhi :—

S.O. 1207.—In continuation of this Departments Notification No. 2453 dHtcd 2-8-78, it is hereby notified for general
information that the. institution mentioned below has been
approved by Indian Council of Agricultural Research, the
prescribed authority for the purposes of clause (ii) of 8'ibscction (1) of Section 35 of the Income-tax Act, 1961.
INSTITUTION
Kfahore Bharati Bankheri, District Hoshnng-abad, (Madhya
Pradesh).
This notification is effective for a period of 3 years from
1-10-1978 to 30-9-1981
[No. 2fi85 (F. No. 203/11/79-ITA. JI1

Name oL the Scientific
Research Proprnrjime :

"Study of Re-use of coils In
Haemodialysis".

To be undertaken bv :

S.M.S. Medical College &
Hospital, Jaipur.

Duration of Project :

Five years from 1-9-1978 to
31-8-1983.

Estimated Expenditure :

Rs. 4,00,000/ (Rupees Four
Lakhs only).

The approval for the above project is subject to the following conditions :—•
(1) That the institution will maintain a separate account
of thi amounts received and expenditure incurred
for this research project as distinct from the other
expenditure of S.M.S. Medicnl College 4 Hospital,
Jaipur.
(2) That the institution will furnish annual returns of this
scientific research project to Ihc Council for each
financial year by 31st May each year at the lateit
In such form as may be laid down and intimated
to them for thii purpose.
The S.M.S. Medical College & Hospital, Jaipur has been approved under Section 35(1 )(ii) of the Income-tax Act, vide
Ministry of Finance, Department of Revenue Notification No.
320, F. Nn. 203/7/73-ITA. II dated 27th March, 1973.
This approval is effective for a period of 5 years
1-9-1978 to 31-8-1983.

from

fNo. 2686 i(F. No. 203/147/78-ITA. II]

New Delhi, the 31st January, 1979
S.O. 1209.—It is hereby notified for general information
Hmt the institution mentioned below has been approved by the
Indian Council of Agricultural Research, the prescribed authority for ttie purposes of clause (il) of lub-section (1) of
section 35 of the Income-tax Act, 1961.
INSTITUTION
Hexamer Agricultural Research & Development Foundation
Pvt. Ltd., Bombay.
This notification will be effective for a period of one year
from 26-12-1978 to 25-12-1979.
[No. 2700 (F, No. 203/9/79-TTA. II.)]

<!-- page 9 -->

981

New Delhi, the 6th February, 1979
S.O. 1211.—It is hereby notified for general information
that the following scientific research programme has been
approved for the period specified below for the purposes of subsection (2A) of Section 35 of the Income-tax Act, 1961 read with
rule 6(iv) of the Income-tax Rules, 1962 by the Secretary Department of Science and Technology, New Delhi.

New Delhi, the 2nd February, 1979
S.O. 1210.—It i8 hereby notified for general information that the institution mcntIon<Sd below has been approved by Indian Council of Medical Research, the prescribed authority for the purposes of clause (ii) of subsection (1) of Section 35 of th« Income-tax Act, 1961 read
with Rule 6(ii) of the Income-tax Rules, 1962 under the
category of "scientific research association" in the field of
Medical Research, subject to the following conditions :—
(ii) That the institution will furnish annual returns of
of the sums received by it for scientific research
in the field of medical research.
(ii>Tbat the institution will furnish annual returns of
its scientific research activities to the Council by
31st, May each vcar at the latest in such form
as may be laid down and intimated to them for
this purpose,
INSTITUTION
Gujar Mai Modi Hospital & Research Centre for Medical Sciences, New Delhi.

Name of the icientific re- Studies on process for the manufacture of eplchlorohyrin /glycesearch programme :
rine & process design Phase I
at a scale 120 kg. per day.
M/s. Meta Zinc Pvt. Ltd.. New
Name of the sponsorer:
India Centre, 5th Floor, Cooperage Road, Bombay.
Regional Research Laboratory,
Sponsored at
Hyderabad.
January,
1979.
Proposed date of commencement :
Anticipated date of com- December, 1980.
pletion :
Rs. 10 laths.
Pvtinvitcd omlav :
2. The Regional Research Laboratory, Hyderabad is a unit
of C.S.I.R- which stands approved under section 10(2) (xiii)
of the Income-tax Act, 1922 vide late Finance Department*?
Notification No. 34 dated 24-11-] 946.

This notification is effective fof a period of 2 years from
2-1-1979 to 1-1-1981.
[No. 2708/F. No. 201/l$/7')-n.\.

II]

New Delhi, the 7th February, 1979
S O 1212.—In eexreise of the powers conferred by clause
(v) of subsection (23C) of section 10 of the Income-tax
Act 1961 (43 of 1961), the Central Government hereby
notifies Arolmigu Naganathaswami Temple, Nainarkott and
MangaiamUhaswami Temple, Thiru Uthirakosamangai for
the purpose of the said section for and from the assessment
year 1973-74.
[No. 2726/F. No. 197/112/77-mA'l
1367GT/78—2

<!-- page 10 -->

982

THE GAZETTE OF INDIA : APRIL 14, 1979/CHA1TRA 24, 1901

[PARI II—SEC. 3(ii)]

ORDER
New Delhi, Ihe 30th March, 1979
STAMPS
S.O. 1114.—In exercise of the powers conferred by clause
U>) of sub-section (1) of section 9 of the Indian Stamp Act,
1899 (2 of 1899), the Central Government hereby remits the
duty with which the bonds in the form of promissory notes
to the value of fifty-five lakhs of rupees, to be issued by the
Haryana Financial Corporation, arc chargeable under the
said Act.
[No. 7/79-Stamps-F. No. 33/8/79-ST]
S. D. RAMASWAMY, Under Secy.

S.O. 1213.—It is hereby notified for general information
that the institution mentioned below has been approved by
the Indian Council for Social Sciences Research, the prescribed authority for the purposes of clause (iii) of subsection (1)
of section 35 of the Income-tax Act, 1961, subject to the
following conditions :—
(i) The funds collected by the K. R. Cama Oriental
Instiftile Bombay under this exemption will be utilised exclusively for promotion of research in social
sciences ;
(ii) That the institute shall maintain separate accounts of
the funds collected by them under the exemption.
Ciii) That the Institute shall send an Annual Report to
the Indian Council of Social Sciences Research,
New Delhi, showing tne funds collected under the
exemption ami the manner in which the funds were

(Department of Economic Affairs)
(Banking Division)
New Delhi, the 21st March, 1979
S.O. 1215.—In exercise of the powers conferred by section
5i of the Banking Regulation Act. 1949 (10 of 1949), Ihe
Central Government, on the recommendation of the Reserve
Bank of India, hereby declares that the provisions of subsection (2) of Section 19 of the said Act shall not applv for
a period of two years from the date of this notification to the
United Industrial Bank Ltd., Calcutta, in sofar as they relate
to its Tioldings of (he shares in M/s. Surendrn Engineering
Works (P) Ltd., Calcutta as pledgee.
[No. I5(5)-B.O. IIJ/791

Utilised,

INSTITUTION
The K. R. Cama Oriental Institute, Bombay.
This notification is effective from 1-4-1978,
[No. 2728/R No. 2O3/134/76-ITA II]
I. P. SHARMA, Director

S.O. 1216.—In exercise of the powers conferred by section
53 of the Banking Regulation Act, 1949 (10 of 1949), the
Central Government, on the recommendation of the Reserve
Hunk of India, hereby declares that the provisions of Scctior!
9 of the said Act shall not apply upto 30th December, 1979
to the Kamataka Bank ltd., Mangalore, in respect of the immovable property consisting of two open sites bearing plot
No. 58 and fi9 measuring 110'x30' each, situated within the
sub reRi'Mralion divisions of Jamkhandi, Bijapur District held
by il.
TNo. 15(6)-B.O. III/791
M. B. USGAONKAR, Under Secy.

<!-- page 11 -->

983

S.O, 1217.—Jn pursuance of clause 5(IV) of the Terms and
Conditions sanctioned by the Central Government under an
Order dated 22-2-1974 relating to the acquisition by the
State Bank of Tndia of the business of the Krishnaram Baldeo
Bank Limited, and in exercise o[ the powers conferred by
sub-section (7) of Section 35 of the Slate Bank of India Act,
1955 (23 of 1955), the Central Government hereby extends
the time limit for final valuation of the unrealised assets of
the Krishnaram Baldeo Bank Limited for a further period of
two years from the 19th April, 1979 to the 18th April, 1981,
both days inclusive.
[No. 17<5)-B.O. HI/78]
BALDBV SINGH, Jt. Secy.

MINISTRY OF COMMERCE, CIVIL SUPPLIES AND
COOPERATION
New Delhi, the 7th Apiil, 1979
S.O. 1218 Whereas the Central Government In exercise of
powci-s conferred by section !* of the llxport (Quality control
ami inspection Act, 1963 (22 of 1963) published a proposal to
iccognise the Indian Standards Institution Certification Mark
in rchUion ii_r Rubber Beltings as required by sub-rule (2) of.
rule 11 of the Export (Quality Contiol and Inspection) Rules,
l%4 In the Gazette of India, Part IT, Section 3, Sub-section
!'ii) dated the 1st April. 1978 under the order of Government
of India in the Ministry of Commerce No. S.O, 878 dated
the 1st April, 1978 ;
And whereas objections and suggestion were invited till the
15th May, 1978 from all persons likely to he affected thereby;
\nd whereas the copies of the said Gazette were made
a\ailablc to the public on 3rd April, 1978.
And whereas the objections and suggestions received from
the public on the SLIij draft have been considered by the Centi;il Government.
Novv, therefore, in exercise of the powers conferred by section 8 of the Export (Quality Control and Inspection) Act,
1963 (22 of 1963), the Central Government hereby recognises
ihe Indian Standards Institution Certification Mark in relation
lo Rubbjr Belling for the purpose of denoting that, whetc
Rubber Beltings are affixed with such mark, they shall be
deemea lo be in conformity wiih the standard specifications
recognised by the Central Government under section 6 of
the said Act published with the Notification of Government
ol Jndia in the Ministry of Commerce, S.O. 847 dated 13th
March, 1967 read with subsequent amendment S.O. 1297 dated
4th April. 1%8.
Definition
In this Notification "Rubber Beltings' shall mean atiy ot
the beltings mentioned in the Annexure to this notification
made from woven canvas or v, oven wolid by interweaving
layers of cotton and or hair or both and binders impregnated
with rubber linseed base/bituminous compound etc. with
or without rubber cover, the whole beJng vulcanised or/procecsecl together in a uniform manner, used for the puiposc
of conveying materials or power transmission.
Annexure
1 Rubber and fabric conveyor and elevator belting.
2. Rubber transmission belting.
.". Solid woven impicgnaL'd cotton belting.
4 Solid woven impregnated hair belting.
[Nu. d(-13)/73-F.I&rBl
C D. kUKRUTI. Uiini Diream

<!-- page 12 -->

984

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

Office of the Chief Controller of Imports and Exports
(Department of Commerce)
ORDER
New Delhi, the 27th March, 1979
S.O. 1219.—M/s The Fertilizer Corporaiton of India Ltd.,
jorakhpur Unit, P.O. Fertilizer Factory, Gorakhpcr, (UP)
•vere granted an import licence No. lA/2443593/C/XX/
H/64/77 dt. 2-9-77 for Rs. 67,00O/-(Rupees sixty seven
housand only). They have applied for the issue of a dupH:ate Customs Purpose and Exchange Control Purposes copy of
he said licence on the ground that original Customs purposes
ind Exchange Control purposes copy has been misplaced/lost.
t is further slated that original customs purposes and exchange
Control Purposes copy was not registered with the Customs
mthoritics and Bank. Both the copies of the licence were not
raced and the balance available on it was Rs. 67,000/- a* on
J2-2-79.
1. In support of this contention the applicant has filed
in dffidavit certified by Oath Commissioner. I rim accordingly
atisfled that both the original Customs Copy and Exchange
mpy of the said licence has been lost. Therefore, in exercise
)f the powers conferred under sub Clause 9(cc) of the imDOrts (Control) Order 1955 dt. 7-12-65 as amended the snid
in'ginal Customs Purposes and Exchange Control Purposes
:opies of the licence No. T/I/2443593 dt. 2-9-77 issued to
\i/n. Fertilizer Corporation of India Ltd,, Gorakhpur Is here>y cancelled.
3. A duplicate Custcms Purposes and Exchange Control
urpo»es copy of the said licence is being Issued separately
o the licensee.

3

C. S. ARVA.
[File No. Fert/28/77-78/PLS/A]

[PART II—SEC. 3(ii)]

New Delhi '.he 28th March, 1979
S.O. 1220—M/s. Ashok Lcyland Limitde, 2K, North Beach
Road, Madras were granted import licence No. P/D/2212982|
R/MG/66/H/77 daled 17-2-1978 for import of Raw materials and components as per list attached to il valued at
Ks. 1.31,24,9K6/- under U.K. Credit.
2. They have requested for the issue of duplicate Exchange
Control purposes copy of the above said licence on the ground
that the original Exchange control copy has been lost or mMplaocd. ft has been further reported by the licensee that the
licence had an unutilised balance of Rs. 1,29,95,686/-.
3. In biippnrt of their contention, the applicant Iiavc filed an
affidavit. The undersigned is satisfied that the original Exchange Control Purposes Copy of import licence No.
P/D/2212982 dated 17-2-1978 has been lost or misplaced
and hence directs that a duplicate Exchange Control Purposes
copy of the said licence should be issued to the applicant.
The original Exchange Control copy is hereby cancelled.
4. The Duplicate Exchange Control Purposes copy of the
wild licence is being issued separately.
Particulars of licence.
S. No.
Licence No.
Descriptiou of
Country
& date
goods
I
P/D/2212982
Raw materials and
U.K.
dt.17.2.78
components.
Vaiidi y LI)3to Valuo in Rs.
Utilised value
Balance
16.2.1979
1.31,24,986/Rs. 1,29,300/- Rs. 12995686/fTile No. Airto/A-2iC9)/AM/78/RM-4]
C. S ARYA,
Dy, Chief Controller of Imports & Exports
loi Chief Controller of Imports and Exporters.

<!-- page 13 -->

985
S.O. 1222.—The Central Government, having considered
in consultation with the Forward Markets Commission, the
application for renewal of recognition made under Section
3 of the Forward Contracts (Regulation) Act, 1952 (74 of
1952) by the Northern Indian Cotton Association Ltd. Bhatinda and being satisfied that it would be in the interest of the
trade and also in the public interest so to do, hereby grants,
in exercise of the powers conferred by Section 6 of tbo said
Act, recognition to the aid Association for a further period
of three years from 16th April, 1979 to the 15th April, 1982
(both days inclusive), in respect of forward contract in
cotton.
2. The recognition hereby granted is subject to the condition that the said Association shall comply with such directions, as may, from time to time, be given by the Forward
Markets Commission,
[No. 12(3)- IT /79]

(Department of Civil SuppHes & Corporation)
New Delhi, the 27th March, 1979
S.O. 1221 The Central Ciovernment, having considered in
consultation with the Forward Markets Commission, the ftplicotion for lenewal of recognition made under Section 5 of
the Forward Contracts (Regulation) Act, 1952 (74 of 1952)
by Southern Gujurat Cotton Dealers' Association, Surat and
being satisfied tU.it it would be in the interest of the trade
and also in the public interest so to do, hereby grants, in cxeidse of the pawers conferred by Section 6 of the, said Act,
iecoKnition to the .said Association for a further period of
three years from the 16th April, 1979 to the 15th April,
1982 (both days inclusive), in respect of forward contracts
in cotton.
2, The jeeognition hereby granted is .subject to the condition
that the suit! Association shall comply with such directions,
rfi may, from time to time, be given by the Forward Markets
Commission.
[No. 12(3)-JT/79]

S.O. 1223—The Central Ooverjimnct, having considered
in consultation with the Forward Markets Commission, the
application for renewal of recognition made under Section
5 of the Forward Contracts (Regulation)) Act, 1952, (74 of
1952), by the East India Jute and Hessian Exchange Limited, 43, Nctaji Subhas Roud, Calcutta, and being satisfied that
it would be in the interest of the trade and also in tho
public interest so to do, hereby grants, in exercise of the
powers conferred by Section 6 of the said Act, recognition
to the said Exchange for a further period of three years
from 29th March, 1979 to 28th March, 1982 (both days
inclusive) in respect of forward contracts in raw jute (including nie^a) in the States of West Bengal, Bihar, Assam,
Meghalaya, Orissa and Tripura and the Union Territories of
Arunachal Pradesh and Mizoram.
2. The recognition hereby granted is subject to the condition that the said Exchange shall comply with such directions as may, from time to time, be given by the Forward
Markets Commission.
[No. I2(J).IT / 79]
K. S. MATHEW, Dy. Secy.

<!-- page 14 -->

986

THE GAZETTE OF INDIA : APRIL 14, 1979/CHA1TRA 24, 1901

[PART II^SEC. 3(ii)]

<!-- page 15 -->

987

<!-- page 16 -->

988

THE GAZETTE OF INDIA -.APRIL 14, .1979./CHAITRA U, 1901

[ P ^ T II-T-SBC 3(ii)]

<!-- page 17 -->

989

1367 OI/78—3

<!-- page 18 -->

990

THE GAZETTE OF INDIA: APRIL 14, 1979/CHAITRA 24, 1901

[PAET II—SEC 3(ii)]

<!-- page 19 -->

991

<!-- page 20 -->

992

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(11)]

<!-- page 21 -->

993

<!-- page 22 -->

994

THE GAZETTE OF INDIA : APRIL 14,- 1979/CHAITRA 24, 1901

[PART II—SEC. 3(il)]

<!-- page 23 -->

995

<!-- page 24 -->

996

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART TI—SEC. 3(ii)]

INDIAN STANDARDS INSTITUTION
New Delhi, 1979-03-27
S.0.1224. —In pursuance of sub-regulation (1) of Regulation 8 of the Indian Standards Institution (Certification Marks) Regulation!!, 1955, as amended from time to time, the Indian Standards Institution, hereby, notifies that one hundred and flftynine licences,
particulars of which are given in the following Schedule, have been renewed during the month of March 1976 :
SCHEDULE

si.
No.

Licence No.
(CM/L )

Period of
Validity

Name and Address of the Licensee

Article/Process covered by the Licence and the
Relevants IS: Designation

(1)

(2)

(3)

(4)

(5)

1. CM/L-50
1958-01-02
2. CM/L-57

1958-01-19
3. CM/L-59

1958-01-20
4. CM/L-78
1958-04-24
5. CM/L-86

1958-04-24
6. CM/L-172
1960-03-11
7. CM/L-174
19604)3-11
8. CM/L-208

1960-07-29
9. CM/L-232

1960-10-17

1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
19764)2-01
to
1977-01-31
1976-04-01
to
1977-03-31
1976-04-01
to
1977-03-31
1976-02-16
to
1977-02-15
1976-02-01
to
1977-01-31

East India Plywood Co. Ltd., Calcutta

Tea-chest plywood panels—
IS: 10—1970

Assam Valley Plywood Pvt. Ltd., Calcutta

Tea-chest plywood panels—
IS: 10—1970

As^am Bengal Veneer Inds. Pvt. Ltd., Oodala- Tea-chost plywood panels—
bari, Distt. Jalpaiguri (W.B.)
IS: 10—1970
Grossley & Towers Pvt. Ltd., Calcutta

Yea-chest plywood panels—
IS: 10—1970

The Surma Match & Industries Pvt, Ltd., Cal- Tea-chest plywood panels—
IS: 10—1970
cutta.
Parle Products Pvt. Ltd., Bombay

Biscuits (excluding wafer biscuits)—
IS: 1011—1968

Satho Biscuits Chooolatc Co, Poona

Biscuits (excluding wafer biscuits)—
IS: 1011—1968

Bengal Chemical & Pharmaceutical Works Ltd., Ncphthalenc—
IS: 539—1955
Calcutta.
Assam Plywood Products, Village Kakojan Tea-chest plywood panels—
IS: 10—1970
(Assam).

<!-- page 25 -->

997
(1)

(2)

10. CM/L-327
1961-07-31
11. CM/L-369
1961-12-22
12. CM/L-382
1962-02-09
13. CM/L-403
1962-04-02
14. CM/L-429
1962-06-03
15. CM/L-515
1963-03-15
16. CM/L-631
1964-02-21
17. CM/L-654
1964-04-28
18. CM/L-730
1964-06-29
19. CM/L-731
1964-06-29
20. CM/L-756
1964-08-12
21. CM/L-831
1964-11-02
22. CM/L-832
1964-11-02
23. CM/L-83.1
1964-11-06
24. CM/L-1005
1965-02-08
25. CM/L-1006
1965-02-08
26. CM/L-1007
1965-02-08
27. CM/L-1008
1965-02-08
28. CM/L-1016
1966-02-26
29. CM/L-1090
1965-06-03
30. CM/L-1091
1965-06-03
1367 GI778—4

(3)

(4)

1976-02-01 India Plywood Co., Calcutta
to
1977-01-31
1976-01-01 D.C.M. Container Works, New Delhi
to
1976-12-31
1976-04-01 Narhari Engineering Works, Bombay
to
1977-03-31
1976-03-01 The Hindustan Mineral Products Co. Pvt, Ltd.,
to
Bombay.
1976-08-31
1976-03-01
-doto
1976-08-31
1976-04-01 A.M. Rehmani, Ahraedabad
to
1977-03-31
1976-02-01 Bayer (India) Ltd., Thana
to
1977-01-31
1976-03-01 Sree Venkateswara Minerals (Pvt.) Ltd., Madras
to
1977-02-28
1976-02-01 New Bharat Steel Rolling Mills, Bombay
to
1977-01-31
1976-02-01
-doto
1977-01-31
1976-03-01 Sree Venkateswara Minerals (P) Ltd., Madras
to
1976-12-31
1975-11-16 Agarwal Hardware Pvt. Ltd., 24-Parganas
to
1976-11-15
1975-11-16
-doto
1976-11-15
1976-02-16 Kandivli Metal Works, Thakurdwar (Mahato
rashtra).
1977-02-15
1976-02-16 Singh Engg. Works (P) Ltd., Kanpur (U.P.)
to
1977-02-15
1976-02-16
-doto
1977-02-15
1976-02-16 B.R. Herman & Mohatta (India) Pvt. Ltd.,
to
Ulhaanagar, Kalyan, Bombay,
1976-08-31
-do1976-02-16
to
1976-08-31
1976-02-01 National Electro Mechanical Co., Rajkot-2
to
1977-01-31
1976-03-01 West India Steel Co. Ltd., Cheruvannur, Feroke
to
(Kerala).
1977-02-28
-do1976-03-01
to
1977-02-28

(5)
Tea-chest plywood panels—
IS: 10—1970
18-Litre square tins—
18:916-1966
Three-phase induction motors with class 'A'
insulation up to 7.5 kW (10 HP) only—
IS: 325—1970
BHC dusting powders.—
IS: 561—1972
BHC water dispersible powder concentrates—
IS: 562—1972
Dye based fountain pen inks—
IS: 1221—1971
Formulations based on stabilized raethoxy
ethyl mercury chloride concentrates—
IS: 2358—1963
BHC dusting powders—
IS: 561—1972
Structural steel (standard qunliiy)—
IS: 226—1975
Structural steel (ordinary quality)—
IS: 1977—1975
DDT dusting powders—
IS: 564—1961
Structural and steel (standard quality)—
IS: 226—1975
Structural steel (ordinary quality)—
IS: 1977—1975
Wroght aluminium and aluminium alloy for
utensils—
IS: 21—1975
Structural steel (standard quality)—
IS: 226—1975
Structural steel (ordinary quality)—
18:1977—1975
Structural steel (standard quality)—
IS: 226—1975
Structural steel (ordinary quality)—
IS: 1977—1975
Three-phase induction motors—
IS: 325—1970
Structural steel (standard quality)—
IS: 226—1975
Structural steel (ordinary quality)—
IS: 1977—1975

<!-- page 26 -->

998

o;I

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1301
(2)

(3)

(4)

[PART U—SEC. 3(ii)]
(5)

31 . CM/L-1184
1965-12-16

1976-03-01
to
1977-02-23

32 . CM/L-1210
1966-02-15

1976-02-16
to
1977-02-15
1976-03-16 Foods Fats & Fertilizers Ltd., Tanuku Road, Compounded feeds for cattle—
to
(West Oodevari Distt), A.P.
IS: 2052—1968
1977-03-15
1976-03-01 Central Insecticides & Fertilizers, Bombay' COCWDP—
to
IS: 1507—1966
1977-02-08
1976-03-01
-doAldrin D P to
IS: 1308—1974
1977-02 28
1976-01-01 Digvijay Metal Industries, New Delhi
Door closers (hydraulically regulated); sizes
1,2, 3 only—
to
IS: 3564—1970
1976-12-31
1976-02-01 Premier Timber & Plywood Products, Jalpaiguri Tea-ohest plywood panels—
to
(W. Bnegal).
IS: 10—1970
1977-01-31
1976-02-16 Hindustan Conductors Pvt. Ltd., Baroda
Hard drawn stranded aluminium and steel
to •
cored aluminium conductors for overhead
powr transmission purposes—
1977-02-15
15:398—1961
1
1975-11-16 Agarwal Hardware Works Pvt. Ltd., Calcutta Cold twisted steel bars for concrete reinforceto
ment—
1976-11-15
IS: 1786—1966
1976-01-16 Sandoz (India) Ltd., Thana
Malathion EC—
to
IS: 2567—1973
1977-01-15
1976-03-01 Oswal Electrlcals, Farldabad (Haryana)
Single-phase small AC and universal electric
to
motors with class 'A' insulation 0.18 kW
1976-08-31
(i HP) and 0,55 kW (3/4 HP)
IS: 1996—1964
1975-12-16 Bajrangbali Engg. Co. Pvt. Ltd., Howrah (W. Structural steel (standard quality)—
IS: 226—1975
to
Bengal).
1976-12-15
1975-12-16
-doStructural steel (ordinary quality)—
TS: 1977—1975
to
1976-12-15
1976-03-01 Central Insecticides & Fertilizers, Bombay-72 DDT DP—
to
IS: 564—1961
1977-02-28
1976-01-16 Swarup Chemicals, Lucknow
BHC DP—
to
IS: 561—1972
1977-01-15
1976-03-01 Central Insecticides & Fertilizers, Bombay
BHC EC—
to
IS: 632—1972
1977-02-28
1975-02-16 The Hulkoti Co-operative Cattle Feed Proces- Poultry feeds—
sing Society Ltd., Distt. Dharwar (Mysore
IS: 1374— 196R
to
State).
1977-0245
1976-03-01 Central Insecticides & Fertilizers, Bombay
Organo mercuric 1 dry seed dressing formulato
tions—
IS : 3284-1965
1977-02-28
-doAldrin EC—
1976-03-01
to
IS: 1307—1973
1977-02-28
1976-02-01 fiast India Industries Prop: East India Rubber Structural steel (standard quality)—
IS: 226—1975
Works (P) Ltd., 24-Parganas (W. Bengal).
to
1977-01-31
-doStructural steel (ordinary quality)—
1976-02-01
IS: 1977—1975
to
1977-01-31

33. CM/L-1337
1966-09-29
34,, CM/L-1397
1967-02-28
35,, CM/L-1398
1967-02-28
36. CM/L-1591
1967-12-31
37. CM/L-1627
1968-01-24
38. CM/L-1638
1968-02-16

39. CM/L-1649
1968-03-08
40. CM/L-1660
1968-03-27
41. CM/L4663
1968-03-27

42. CM/L-1715
1968-06-12
43. CM/L-1716
1968-06-12
44, CM/L-1738
1968-07-11
45. CM/L-1969
1969-05-15
46. CM/L-2012
1969-07-08
47. CM/L-2052
1969-08-18
48. CM/L-2077
1969-09-22
49. CM/L-2078
1969-09-22
50. CM/L-2125
1969-10-27
51. CM/L-2126
1969-10-27

Toxmo Industries, G.N. Mill P.O., Coimbatons Three-phase induction motors up to
and including 15 kW (20 HP) with
class 'A' Insulation—
IS: 3?5—1970
Annapurna Biscuit (Mfg) Co., Kanpur
Biscuits—
IS: 1011—1968

<!-- page 27 -->

999
(1)

(2)

52. CM/L-2182
1969-12-24
53. CM/L-2220
1970-01-22
54. CM/L-224K
197OO2-10

55. CM/L-2251
1970-02-10
56. CM/L-2252
1970-02-10
57. CM/L-2261
1970-02-25
58. CM/L-2273
1970-03-06
59. CM/L-2471
1970-11-30
60. CM/L-2436
1971-02-08
61. CM/L-2541
1971-02-16

62. CM/L-2581
1971-02-09
63. CM/L-2599
1971-03-17
64. CM/L-2633
1971-03-29
65. CM/L-2648
1971-03-30
66. CM/L-2657
1971-03-31
67. CM/L-2703
1971-06-16
68. CM/L-2722
1971-07-28
69. CM/L-2859
1971-12-31
70. CM/L-2866
1972-01-07
7J. CM/L-287!
1972-01-U
72. CM/L-2872
1972-01-14

(3)
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-16
to
1977-02-15
1976-02-16
to
1977-02-15
1976-02-16
to
1977-02-15
1976-02-01
to
1977-01-31
1976-03-01
to
1977-02-28
1976-02-16
to
1977-02-15
1976-02-01
to
1977-01-31
1976-01-01
to
1976-06-30
1976-03-16
to
1976-09-15
1976-03-16
to
1977-03-15
1976-02-01
to
1977-01-31
1976-01-16
to
1977-01 IS
1976-04-01
to
J 977-03-31

(4)

(5)

Bengal Electric Concern, Howrah

Door closers (hydraulically regulated) size 2
only—
13:3564—1970
Kanoria Chemicals & Inds, Ltd., Distt Mirjapur BHC technical—
(U.P.)
IS: 560—1969
Assam Conductors & Tubes Ltd., Gauhati Hard drawn Btranded aluminium and steel
(Assam)
cored aluminium conductors for overhead
power transmission purposes—
IS: 398—1961
Vijay Timber Trading Co., Pathankot Distt. Plywood tea-chest battens—
Gurdaspur (Ph.)
IS:10(Pt. Ill)—1974
B. Uttam Singh & Sons, Jullundur City

Hockey srlchs—
IS: 829—1965

The Tannery & Footwears Corpn. of India Ltd ., Miners' safety leather boots and shoes with
Kanpur
rubber soles and heels and leather (Type 1)—
IS: 1989—1973
Trirjcni Tissues Ltd., Calcutta
Base paper for carbon paper—
IS: 3413—1966
Hary;ina Chemicals & Pesticides, Bahadurgarh, BHC dusting powders—
IS: 561—1972
Distt. Rohtafc (Haryana)
Hindustan Steel Ltd., Bangalore

Bcco Engineering Co. Ltd., Batala (Pb.)

Plant Protection Industries, Guntur

Cold twisted steel bars for concrete reinforcement—
IS: 1786—1966
Cold twisted deformed steel bars for concrete
reinforcement upto 14 mm diameter and
more than 14 mm diameter—
IS: 1786—1966
BHC D P IS: 561—1972

B.A.S. Metal Works, New Delhi

Door closers (hydraulically regulated); size 2
only-—•
IS: 3564—1970
Prabhat Tron Foundry & Metal Industries (P) Sand cast iron soil pipes—
IS: 1729—1964
Ltd., Rourkela (Orissa).
E.I.D. Parry Ltd., Tadepalli, Guntur Distt. (A-P) Malathion EC—
IS: 2567—1973
Hindustan Steel Ltd. Bombay

Cold twisted steel bars for concrete reinforcemert—
IS: 1786—1966

197 V12-01 Gannan Ounkerlcy & Co. Ltd ., Borr.bay
Valve fittings for compressed gas cylinders
to
(LPG)1976-11-30
IS: 3224—1971
1976-02-16 Udaipur Distillery Co. Pvt. Ltd., Udaipur Gin—
to
(Rajasthan)
IS: 4100—1967
1977-02-15
Whisky—
—do—
1976-02-16
IS: 4449—1967
to
1977-02-15
1976-01-16 Gladstone Lyall Employees Irdl. Cooperative Bitumen felts for water proofing and dampproofing Type 3, Grades 1 and 2—
Society Ltd., Calcutta
to
IS: 1322—1970
1977-01-15
Malatuion D P 1976-03-01 Central Insecticides & Fertilizers, Bombay
IS: 2J68—1973.
to
1977-02-2S
1976-01-16 Mukund Iron & Steel Works Ltd., Thana Cold twisted steel bars for concrete teluforoement—•
to
(Maharashtra')
IS: 1786—1966
1977-06-15

<!-- page 28 -->

1000
(1)>

THE GAZETTE OF INDIA : APRIL 14, 1979,/CHAITRA 24, 1901
(2)

73,. CM/L-2884
1972-01-24
74,• CM/L-2895
1972-02-02
75, CM/L-2910
1972-02-15
76. CM/L-2921
1972-02-18

(3)
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-16
to
1976-08-15
1976-02-16
to
1977-02-15

(4)
Indore Steel & Iron Mills, Ahmedabad
Industrial Engg. Works Bombay

Tata Iron & Steel Co., Bombay
Omega Cables Ltd., Madras

77. CM/L-2922
1972-02-18

76-02-16
to
1977-02-15

Omegaa Cables Ltd. Madras

78. CM/L-2923
1972-02-18

1976-02-16
to
1976-02-15

Omega Cablos Ltd., Madras

79. CM/L-2924
1972-0M8

1976-02-16
to
1977-02-15

—do-

80. CM/L-2930
1972-02-22

1976-03-01
to
1977-02-28
1976-02-16
to
77-02-15

81. CM/L-2986
1972-03-17

Central Insecticides & Fertilizers, Bombay
Omega Cables Ltd., Madras

[PART II—SEC. 3(11)]
(5)

Cold twisted steel bars for concrete reinforcement—
IS: 1786—1966
Cold twisted steel bars for oncrete reinforcement—
IS: 1786—1966
Cold twisted steel bars for concrete reinforcement—
IS: 1786—1966
Hard-drawn stranded aluminium and steel
cored aluminium conductors for overhead
power transmission purposes—
IS: 398—1961
(a)PVC insulated cables:
(i) Single core (unsheathed and sheathed)
250/440 volts and 650/1 100 volts
grade with aluminium or copper conductors ;
(if) Twin core, (PVC sheathed) 250/440
volts grade with aluminium conductors;
(iii) Twin twisted, 250/440 volts grade with
copper conductors; and
(iv) Four core, circular (PVC sheathed)
650/1 100 volts grade with aluminium
conductors.
(b) PVC insulated flexible cords
(v) PVC sheathed, 250/440 volts grade
with copper conductors—
IS: 694 (Pt. I & II)—1964
Polyethylene Insulated and PVC sheathed cables
with aluminium conductors, single core
only—
IS: 1596—1970
Thermoplastic insulated weatherproof cables:
(l)PVC insultaed and PVC sheathed:
(i) Single-core, 650/1 100 volts grade with
aluminium conductors and
(ii) Twin core, flat, 250/440 volts grade
with aluminium conductors—
IS: 3035 (Pt. D-1965
(2) Polyethylene insulated, taped, braided and
compounded:
(i) Single-core, 250/440 volts and 650/1
100 volts grade with aluminium conductors; and
(ii) Twin core, flat, 250/440 volts and
650/1 100 volts grade with aluminium
conductors—
IS: 3035 (Pt. II)—1965
f3) Polyethylene insulated and polyethyleno
sheathed:
(i) Single core, 250/440 volts and 650/1
100 volts grade with aluminium conductors; and
(ii) Twin core, flat, 250/440 volts grade
with aluminium conductors—
IS: 3035 (Pt. Ill)—1967
Dichlorvos EC—
IS: 5277—1969
PVC insulated (heavy duty) electric cables for
working voltages up to and including 1 100
volts with aluminium or copper conductors—
IS: 1554 (Et. I)—1964

<!-- page 29 -->

1001
(1)

(2)

82. CM/L-3060
1972-05 09
83. CM/L-3307
1973-01-29
84. CM/L-3313

1973-01-13
85. CM/L-3325

1973-02-06
86. CM/L-3345
1973-02-27
87. CM/L-3357
1973-03-07
88. CM/L-3379

1973-04-06
89. CM/L-3403
1973-04-30
90. CM/L-3406
1973-05-03
91. CM/L-3485

1973-07-18

91. CM'L-3555

1973-09-25

93. CM/L-3S6O

1973-09-28

94. CM/L-3564

1973-10-10

1975-11-16
to
1976-05-15
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-16
to
1977-02-15
1976-03-01
to
1977-02-28
1976-03-16
to
1977-03-15
1976-01-01
to
1976-12-31

Gujarat State Co-operative Marketing Society DDT DP—
IS: 564—1961
Ltd. Ahmedabad.

1976-01-16
to
1977-01-15
1975-11-16
to
1976-11-15

Sandoz (India) Ltd.. Thana

1976-02-01
to
1976-07-31
1976-02-01
to
1976-07-31
1976-03-01
to
1977-02-28
1975-10-10
to
1976-10-15

95. CM'L-3604

1975-12-01
to
1976-11-30

96. CM/L-3628

1975-12-16
to
1976-12-15
1976-01-16
to
1977-01-15
1976-01-16
to
1977-OM5
1976-01-16
to
1977-01-15
1976-02-01
to
1977-01-31
1976-02-01

1973-11-28

1973-12-07

97. CM/L-3653

1974-01-OS

98. CM/L-J65S

1974-01-OS

99. CM'L-36tf

1974-01-25
100 . CM/L-369Z

I974-01-2S

101 , CM/L-3693

1974-01-28

102., CM/L-3696
1974-01-28
103 . CM/L-3701

1974-02-06

(5)

(4)

(3)

National Electro-Meohnical Co., Rajkot (Gujarat).
Klrloskar Brothers Ltd., Dewas (M.P.)
Assam Bengal Plywood Co., Calcutta

Hiad Enterprises, Kanpur

Protective steel toe caps for footwears—
IS: 5852—1970

The Tata Iron & Steel Co., Lid. Bangalore

Cold twisted steel bars for concrete reinforcement—
IS: 1786—1966
Hard drawn stranded aluminium and steel
cored aluminium conductors for overhead
power transmission purposes—
IS: 398—1961
EndrinEC—
IS: 1310—1974

Bihar Cable Co., Patna (Bihar)

Khoday Industries
(Mysore).

Pvt.

Ltd.,

Bangalore Carbon paper for typewriting and handwriting—
IS: 1551—1959; and
IS: 3450—1966

Bat -Bro Engineering & General Mfrs., Delhi
Asian SteeJ Industries Ltd., Hyderabad
Central Insecticides & .Fertilizer, Bombay

Cables for motors vehicles, PvC insulted
without further covering, licht dul\—
IS: 2465—1969
Steel wire for the core of steel-cored aluminium
conductors IS: 398—1961
JBudosulf:./ E C 1S: 4323--1967

Plastic Moulders Ltd., Howrah

Low density polycthyler.c
pi^cs, pressure
ratings up to 6 kgfycm1 ard 10 kgf(cm»
and size up to 50 mm OD—
IS: 3076—1968
Usha Mariin Black (Wire Ropes) Ltd., Ranchi Plain hard-drawn sleel wiie for prestressed
concrete:
(i) Cold-drawn stress-relived vile: and
(ii) As-drawn wire—
IS: 1785 (Pt. 0—1966; and
IS: 1785 (Pt. Il)~~1967
Do.
Indented wire for prcstresscd cor ere u-—
IS .-6003—1970
Kovai Pesticides, Polluci

BHC D P IS: 561—1972

Precision Rubber Industiics Pvt. Ltd., Thana
(Maharashtra).

Synthetic mbbej appicrs (reinforced)
for drafting systems—
IS; 4892—1968
Amur Dye-Chem Ltd., Kalyan (CR) Maha- O—Anisidirc—
rashtra.
IS: 5648—1970
M.iyur Industries, Yeutnial (MaUsuashtra)
Do.

(0

1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31

Single-phase small ac and universal electric
motors—
IS: 996—1964
Horizontal centrifugal pumps for clear, cold,
fresh water for agricultural purposesi s : 6595—1972
Tea-chest plywood panels—
IS: 10—1970

Endrin ECIS: 1310--1974
Milatliion E C IS: 2567—1973

Hindustan Wire Ltd-, Faridabad (Haryaria)

ACSR Steel core wire—
IS; 398—1961

Kilpest Pvt. Ltd., Govindpura, Bhopal

Malathion EC—
18:2567—1973

for

<!-- page 30 -->

1002
1

THE GAZETTE OF INDIA : APRIL 14, 19797CHAITRA 24, 1901
2

J04 . CM/L-3702

1974-02-06

105i. CM/L-3706

1974-02-06

106 i. CM/L-3714

1974-02-14

107 '. CM/L-3715

1974-02-14

108 . CM/L-3719

1974-02-15

109 , CM/L-3720

1974-02-18

110 , CM/L-3721

1974-02-18

in . CM/L-3723
1974-02-09

112 . CM/L-3726

1974-02-27

113 . CM/L-3740

1974-03-13

114 . CM/L-3742

1974-03-13

U S , . CM/L-3747

1974-03-15

116., CM/L-3787
1974-04-02
117. CM/L-3788
1974-04-02
118. CM/L-37R9
1974-04-02
119. CM/L-3790
1974-04-02
120.. CM/L-3791
1974-04-02
121. CM/L-3793
1974-04-02
122. CM/L-3829
1974-05-15
123. CM/L-3830
1974-05-15
124. CM/L-3831
1974-05-15
125. CM/L-3832
1974-05-15
126. CM/L-3833
1914-05-15
127. CM/L-3834
1974 -05-15
128. CM/L-3835
1974-05-15

3

4

[PART H—SEC. 3(ii)]
5

1976-02-01 Hindustan Wires Ltd,, Faridabad (Haryana)
Indented wire for prc-tressed concrete—
to
15:6003—1970
1977-01-03;I
1976-02-16 Banjjalore wire Rod Mill, (A unit of Transport Structural steel (standard qua lily)—
(0
Corpn of India Pvt. Ltd..) Bargalore.
IS: 2?f—1975
1977-02-15
1976-02-16 Sirhind Steel Rolling Mills, Ahmcdabad Structural steel (sten'ard quality —
to
(Gujarat).
IS: 226—1975
1977-02-15
1976-02-16
Structural steel (ordinary quality,1—
Do.
to
IS: 1977—1975
1977-02-15
1976-02-16 Equipment Conductors & Cables (Pvt.) Lid., AAC & ACSR conductorsto
Faridnbad (Haryana).
TS: 398—1961
1977-02-15
1976-02-16 Hindustan Steel Ltd., Calcutta
Cold twisted steel bars for concrete reinforceto
ment—
1977-02-15
IS: 1786—1966
1976-02-16 Metallic^ hnterpri.se, Ahmedabud
Nickel sulphate—
IS: 1809— I96K
to
1977-02-15
1976-03-01
Assam Chemical Industries, Bongaigaon DDT FC—
to
(Assam).
IS: 633—1956
1977-02-28
1976-02-16 Rawel Industries Pvt. Ltd., Bahad urgarfii Rotary t>haft oil seal, unit type C—
to
IS: 1529—1969
(Haryarna).
1977-02-15
1976-03-16 M. Gunvantrai Pvt, Ltd., Bombay
Domestic gas stoves for use with liquified
to
petroleum gases—
18:4246-1972
1977-03-15
1976-03-16 Evergreen Engineers, Calcutta
Protective steel toe caps for footwear—
to
IS .-5852—1970
1976-09-J 5
1976-01-16 Hyderabad Chemical Supplies (P) Ltd. Hydera- Mulathion EC—
to
bad.
IS: 2567—1973
1976-06-15
1976-02-01 Rallies India Ltd., Madras
BHC D P to
IS: 561—1972
1977-01-31
1976-02-01 Rallis India Ltd., Madras.
Endrln EC—
to
IS : 1310-1974
1977-01-31
1976-02-01
do.
Dimathoate E C to
IS : 3903—1975
1977-01-31
1976-02-01
Fonitrothion EC—
do.
to
IS : 5281—1969
1977-01-31
1976-02-01
do.
BHC WDP—
to
TS : 562—1972
1977-01-31
1976-02-01
do.
COC WDP—
to
IS : 1507—1966
1977-01-3)
1976-02-01 Rallis India Ltd., Howrah.
BHC DP—
to
TS : 561—1972
1977-01-31
Do.
BHC W O P 1976-02-01
to
IS : 562—1972
1977-01-31
Do.
DDT DP—
1976-02-01
to
IS : 564—1961
1977-01-31
Do.
DDT WDP—
19764)2-01
to
TS : 565—1961
1977-01-31
Do.
1976-02-01
BHC EC—
to
IS : 632—1972
1977-01-31
Do.
DDT EC—
1976-02-01
to
IS : 633—1958
1977-01-31
1976-01-01
Do.
Endriit EC—
to
IS : 1310—1974
1977-01-31

<!-- page 31 -->

1003
(1)

(2)

129. CM/L-3B36
1974-05-15
130. CM/L-3837
1974-05-15
131. CM/L-3997
1974-10-21
132. CM/L-4023
1974-10-31
133. CM/L-4043
1974-11-07
134. CM/L-4045
1974-11-16
135. CM/L^124
1975-01-08
136. CM/L-4158
1975-01-22
137. CM/L-4159
1975-01-22
138. CM/L-4162
1975-01-22
139. CM/L-U67
1975-01-22
140. CM/L-4179
1975-01-30
141. CM/L-4188
1975-01-30
142. CM/L^19l
1975-01-30
143. CM/L^197
1975-02-10
144. CM/L-4202
1975-02-10
145. CM/L-4205
1975-02-10
146. CM/L-4206
1975-02-10

1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1975-11-01
to
1976-10-31
1976-04-01
to
1977-03-31
1975-11-76
to
(976-11-15
1975-11-16
to
1976-11-15
1976-0]-lfi
to
1977-06-15
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1977-01-31
1976-02-01
to
1976-12-15
1976-02-01
to
1977-01-31
1976-02-01
to
1976-07-15
1976-02-16
to
1977-02-15
1976-02-16
to
1977-02-15
1976-02-16
to
1977-02-15

147. CM/L-4209
1975-02-12

1976-02-01
to
1977-01-31

148. CM/L-4210
1975-02-12

1976-02-16
to
1977-02-15

149. CM/L-4216
1975-02-17

1976-03-01
to
1977-08-31
1976-03-01
to
1977-02-2K
1976-03-01
to
1976-08-31

150. CM/L-4222
1975-02-21
151. CM/L-4223
1975-02-21

(5)

(4)

(3)

COC WDP—
IS : 1507—1966

Rallis India Ltd., Howrah

Repacking of dimethoate EC.
I S : 3903—1975

Do.
Asian Steel Industries Ltd., Hyderabad.

Galvanised stay strand—
IS : 2141—1968

Rosin & Turpontme Factory, Nahan

Gum spirit of turpentine grades 1 & 2—
IS : 533—1973

The Alloy Steel plant, Hindustan Steel Ltd,, Case hardening steels—
Durgapur Distt. Buidwan.
IS : 4432—1967
The Alloy Steel Plant, Durgapur, Distt. Burd- Steels for hardening and tempering—
wan (W.B.).
IS : 5517—1969
Devidayal (Sales) Pvt. Ltd., Bombay.

Endosulfan DP—
IS : 4322—1967

Bharat Pulverising Mills Pvt. Ltd., Bombay.

Carbaryl DP—
IS : 7122—1973

Vallabh Pesticides Mfg. Co,, Anand, Distt. Carbaryl DP—
Kaira (Gujarat),
IS : 7122—1973
New Metal Industries, Calcutta.

Brass ball valves (horizontal plunger type)
15 mm size—
IS : 1703—1968
Assam Timber Products, Doom Doorna, Distt. Tea-chest plywood panels—
IS : 10—1970
Dibrugarh (Assam).
Bhoruka Steel Ltd.,
Bangalore.

Makadcvapura

Fort Giostcr Industries Ltd., Calcutta.
Motilal Pesticides India, Mathura.

Post, Carbon steel billets, blooms, slabs and bars
for forcings—
IS : 1875—1971
Shot firing cables, single-shot, parallel twin
PVC insulatedIS : 5950—1971
Hcptachlor EC—
IS : 6439—1972

The Mysore iron & Steel Ltd., Bhadravati Carbon chromium steel for the manufacture of
(Mysore State).
balls, rollers & bearings races—
IS : 4398—1972
Rallis India Ltd., (Fertilizer & Pesticides Repacking of dimethoate EC—
Division), Koppuravuru, Nambur P.O.,
IS : 3903—1966
Guntur Distt. (A.P.),
Repacking of malathion EC—
Rallis India Ltd,, Howrah.
IS : 2567—1973
Dripless Faucets (India). New Delhi.

Sand cast brass screw down bib taps & slop
taps 15 mm size & stop taps up to 25 mm
size—
IS : 781—1967
Ranka Cables Pvt. Ltd., Cuddapah, Andhra Hard drawn stranded aluminium and steelPradesh.
cored aluminium conductors for ove/head
power transmission purposes—
IS : 398—1961
Regal Steel Works, Calcutta.
(i) Shuttles for hessian and sacking looms—
I S : 1186—1971;
(ii) Shuttles for automatic cop-changing jute
looms—
IS : 2784—1971; and
(iii) Shuttles for jute broad looms—
IS : 2910—1971
Kamdhcnu Pesticides, Poomi
BHC W O P IS : 562—1972
Krishna Miners & Traders, Jaipur,
Do.

DDT EC
IS : 633—1956
Malathion E C IS : 2567—1973

<!-- page 32 -->

1004
(1)

FHE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901
(2)

0)

[PART II—SEC. 3(ii)]
(5)

(4)

152. CM/L-4224
1975-02-21

1976-03-01
to
1977-03-31

Indian Steel Rolling Mills Ltd., Chlngleput Mild steel and medium tensile steel bars and
hand drawn stee] wires for concrete reinforceDistt. (T.N.).
ment—

153. CM/L-4226
1975-02-21

1976-03-01
to
1977-02-28
1976-03-01
to
1977-05-15
1976-03-01
to
1977-05-15

Kesoram Spun Pipes & roundries, (Prop. : Cast iron fittings for pressure pipes for water
Kesorum Industries & Cotton Mills Ltd.,
gas and sewage—
Distt. Hooghly (W.B).
IS : 1538—1969
Mukaud Irou & Steel Works Ltd., Thana Case hardening steels—
IS : 4432—1967
(Maharashtra).

154. CM/L-4242
1975-02-26
155. CM/L-4243
1975-02-26
156. CM/L-4244
1975-02-26
157. CM/L-4247
1975-02-26
158. CM/L-4254
1975-03-07
159. CM/L-4289
1975-04-03

TO . A'l'i fti*

TT\TOfi'y

l o 1 4 J Z \trT* 11)—i JD*

Carbon steel black bars for production of
machined parts for general cngineeiinE purposes—
IS : 2073—1970
1976-03 -01 Mysore Iron & Steel Ltd., Bhadravati, S. Rly., Alloy steel billets, blooms & slfbs for forjgings
for engineering purposes—
(Karnataka).
to
IS : 4368—1967
1977-07-15
Cold twisted deformed steel bars for concrete
1976-03-01 Amrlt Steels Ltd., Ghaziabad.
reinforcement—
to
IS : 1786—1966
1977-02-2*
Wrought aluminium and aluminium alloy
1976-03-01 Nagadevi Industries, Bangalore.
utensils—
to
IS : 21—1975
1977-02-28
18-Litre square tins—
1976-04-01 Ashok Metal Industries, Rajkot.
IS : 916—1966
to
1977-03-31
Do-

[No. CMD/13 :12]

<!-- page 33 -->

1005

1367GI/78—5

<!-- page 34 -->

1006

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(li)]

<!-- page 35 -->

1007

<!-- page 36 -->

1008

THE GAZETTE OF INDIA : APRIL 14, 1979/CHATTRA 24, 1901

[PART II—SEC. 3(ii)]

<!-- page 37 -->

1009

<!-- page 38 -->

1010

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(ii)]

<!-- page 39 -->

1011

<!-- page 40 -->

1012

THE GAZETTE OF INDIA: APRIL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(ii)]

S.0.1225. In pursuance of sub-regulation (1) of Regulation 8 of the Indian Standards Institution (Certification Marks) Regulation 1955, as amended from time to time, the Indian Standards Institution, hereby, notifies thfit one hundred and seventeen licences,
particulars of which are given in the following schedule have been renewed during the month of Way 1976 ;
SCHEDULE
SI.
No.

Licence No.
(CM/L)

Period of
Validity

(1)

(2)

(3)

1. CM/L-275
1961-02-15
2. CM/L-452
1962-09-03
3. CM/L-514
1973-03-07

1976-03-01
to
1977-02-28
1976-05-01
to
1977-04-30
1976-03-16
to
1976-09-15

4. CM/L-778
1974-08-27

1976-04-01
to
1977-03-31

5. CM/L-1013
1965-02-22

1976-03-01
to
1977-02-28

6. CM/L-1015
1965-02-26

1976-03-16
to
1977-03-15

7. CM/L-1223
1966-03-09

1976-03-16
to
1977-03-15
1976-03-16
to
1977-03-15
1976-04-16
to
1977-04-15
1976-05-01
to
1977-10-31
1976-04-16
to
1977-04-15
1976-04-01
to
1977-03-31
1976-04-01
to
1977-03-31
1976-04-16
to
1976-10-15
1976-04-01
to
1977-03-31
1976-05-01
to
1976-10-31

8. CM/L-1226
1966-03-11
9. CM/L-1242
1966-04-14
10. CM/L-1526
1967-09-15
11. CM/L-1538
1967-10-05
12. CM/L-1603
1968-01-01
13. CM/L-1607
1968-01-05
14. CM/L-1674
1968-04-10
15. CM/L-1687
1968-04-30
16. CM/L-1734
1968-07-10
17. CM/L-1862
1968-12-23
18., CM/L-1876
1968-12-23

Name & address of the Licensee

Article/Process covered by the Licensee ar.d
the Relevant IS : Designation

(4)

(5)

Sudhir Chemical Co., Bombay-25.

COC W O P IS : 1507—1966

Northern Minerals (P) Ltd., Curgaon (Haryana) BHC D P IS : 561—1972
The Indian Tool Manufacturers Ltd., Bombay-22.

(i) Twist drills parallel shank, short scries or
jobber—
IS : 5101—1969
(ii) Twisted drills morse taper shank—
IS : 5103—1969
Oriental Power Cables Ltd., Cablenagar, Paper insulated lead sheathed cables (with
aluminium condeuctors) for electricity supDistt. Kota (Rajasthan).
ply upto & including 3.3 kV—
IS : 692—1973
Cast iron flushing cisterns for water closets
Arail Brothers, Faridabad.
and urinals (bell typo) high level, 10 & 12.5
litres capacity—
IS : 774—1971
Water meters (domestic type) type 'A' only:
Capstan Meters (India) Ltd., Jaipur-302004.
(a) Dry dial type—15, 20, 25 and 40 mm
sizes;
(b) Wet dial type 15 mm size—
IS : 779—1968
Calcutta Plywood Mfg. Co., P.O. Ledo, Distt. Tea-chest plywood panels—
IS : 10—1970
Lakhimpur (Assam).
Bindawala Industrial Corporation, Calcutta-7. All aluminium conductors and ACSR conductors—
IS : 398—1961
Plava Chemicals, Madras-29.
Endrin EC—
IS : 1310—1974
Insecticides & Allied Chemicals, Madras-45.

BHC DP—
IS : 561—1972

Hardwyn Industrial Trading Corpn., Delhi- Door closers (hydraulically regulated), sizes
1, 2 & 3—
110035.
IS : 3564—1970
The English Electric Co. of India Ltd., HRC cartridge fuse links upto 650 volts—
IS : 2208—1962
Madras-43.
Aluminium Industries (Assam)
P.O. Tinsukia (Assam).
Indolil Chemicals Ltd., Thana.
Oriental Power Cables Ltd.,
Distt. Kota (Rajasthan).
Freewill & Co., Jullundur City.

1975-03-16 Eastend Supply Co., Calcutta-1.
to
1976-3-15
1976-03-16 Union Products, Calcutta-4.
to
1977-03-15

Pvt.

Ltd., Tea-chest metal fittings—
IS : 10—1970
Zineb WDP—
IS : 3899—1966

Cablenagar, AAC & ACSR conductorsIS : 398—1961
(i) Footwball (lacelcss);
(ii) Basket ball (Laccless);
(iii) Volleyballs (laceless)—
IS : 417—1974
Tea-chest plywood pauels—
IS : 10—1970
Tea-chest plywood panels—
IS : 10—1970

<!-- page 41 -->

1013
(1)

CO

19. CM/L-1993
1969-06-24

20. CM/L-2020
1969-07-15
21. CM/L-2053
1969-08-20
22. CM/L-2120
1969-10-23
23. CM/L-2129
1969-10-30
24. CM/L-2289
1970-03-24
25, CM/L-2290
1970-03-24
26. CM/L-2304
1970-04-06
27. CM/L-2434
1970-10-22
28. CM/L-2470
1970-11-30
29. CM/L-2575
1971-03-03

30. CM/L-2625
1971-03-29
31. CM/L-2628
1971-03-29
32. CM/L-2645
1971-03-30
33. CM/L-2667
1971-04-22
34.1CM/L-2702
1971-06-15
35. CM/L-2729
1971-08-04
36. CM/L-2762
1971-09-13
37. CM/L-2763
1971-09-13
38. CM/L-2778
1971-10-06
1367 GI/78—6.

(3)
1976-05-01
to
1977-04-30

(4)
Jammu Rosin & Turpentine Factory, P.O. Rostu ^gum-rosin);
Miransahib, Jammu Tawi.
Type
(a) Pale
(b) Medium
(c) Dark
IS : 553—1975
Krishna Mines & Traders, Jaipur West (Rajas- EndrinEC—
than),
IS : 1310—1974

(5)
Grade
WG, N and WW
M, K aLd H

D

1976-04-16
to
1976-04-15
1976-05-01 Jammu Rosin & Turpentine Factory, P.O. Gum spirit of turpentine, Grade 2—
to
Miransahib, Jammu Tawi.
IS : 533—1975
1977-04-30
1976-05-01 Crown Timber & Foods Pvt. Ltd., P.O. Plywood tea-chest battens—
to
Yamunanagar (Haryana).
IS : 10—1970
1977-04-30
1976-04-01 S. N. Chemical Industries, Gurgaon
BHC D P to
IS : 561—1972
1977-03-31
Water meters (domestic type)—
1976-03-16 Paramount Meten (Pvt.) Ltd., Jamnagar
IS : 779—1968
to
1977-03-15
Tea-chest metal fittings—
1976-04-01 Mascot & Co., Calcutta-700010
to
IS : 10—1970
1976-09-30
1976-04-16 Prem Electrical Conductors (Madras) Pvt. All aluminium conductors and ACSR conto
Ltd., Madras-26.
ductors—
1977-04-15
IS : 398-1961
1976-05-01 Wavin India Ltd., Madras-58
Unplasticized PVC pipes for potable water
to
supplies—
1977-04-30
IS : 4985—1968
1976-05-01 Rajasthan Rajya Sahkari Kraya Vikraya BHC DP—
Sangh Ltd., Jaipur (Raj.).
IS : 561—1972
to
1977-04-30
1976-03-16 P. Rakesh Electrical Works, New Delhi-110028 PVC insulated unsheathed & PVC sheathed
cables aluminium conductors, 250/440 volts
to
grade 650/1100 volts grade—
1977-03-15
IS : 694 (Part H>~1964
1976-04-01 J. & V. Saw Mills, Perumpaikad P.O., Kot- Tea-chest battens—
tayam-6.
IS : 10 (Pt. HI)—1974
to
1977-03-31
Tea-chest metal fittings—
1976-04-01 N. Prasad & Co., CaIcutta-7
IS : 10—1970
to
1977-03-31
1976-04-01 Sibsagar Forest Products, P.O. Suffry, Distt. Tea-chest plywood panels—
to
Sibsagar (Assam).
IS : 10—1970
1977-03-31
DDT DP—
1976-05-01 Bangalore Pesticides Ltd., Bangalore-22
IS : 564—1961
to
1977-04-30
Cold twisted steel bars for concrete reinforce1976-05-16 Jolly Steel Industries Pvt. Ltd., Poona-14
ment—
to
TS : 1786—1966
1977-05-15
1976-04-16 R. Ponnuswamy Naidu & Sons, Coimbatore-1 Tea-chest metal fittings—
to
IS : 10—1970
(Tamil Nadu).
1977-04-15
Structural steel (standard quality)—
1976-05-16 Jolly Steel Industries P. Ltd., Poona-14
IS : 226—1975
to
1977-05-15
-DoStructural steel (ordinary quality)—
1976-05-16
to
IS : 1977—1975
1977-05-15
1976-04-01 Prakash Saw Mills, Kallettumkara P.O., Near Tea-chest battens—
IS : 10 (Pt. Ill)—1974
Irinjalakadu Rly. Station, Distt. Trichur
to
(Kerala).
1977-03-31

<!-- page 42 -->

1014

0)

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901
(2)

(3)

(4)

(5)
(i) Footballs (laceless);
(ii) VolleybaUs (Laceless);
(iii) Basketballs (Laceless)—
IS : 417—1974
Tea-chest battens—
IS : 10—1970

39. CM/L-2935
1972-02-23

1976-04-01
to
1977-03-31

40. CM/L-2955
1972-03-09

1976-03-16 Jayantl Timbor Industries, Yamunanagar
to
(Haryana).
1977-03-15
1976-04-01 Associated Instrument Mfrs. (India) Pvt. Ltd., Vicat apparatus—
to
NewDelhi-110015.
IS : 5513—1969
1977-03-31
1976-04-01 (Doncord Aral Pvt. Ltd., Ukkiam, Thoraip- 1^on-metal helmets for civil defence—
IS : 2300—1968
pakkam Village, Madras-20
to
1977-03-31
1976-04-01
-DoProtective helmets for scooter and motor
to
cycle riders—
1977-03-31
IS : 4151—1968
1976-04-01 F. C. Sondhl & Co. (I) Pvt. Ltd., Juilundur CO Football (laceless)
(ii) Volleyball Gaceless);
City.
to
(iii) Basketball (laceless)—
1977-03-31
IS : 417—1974
1976-04-01 Associated Instrument Mfrs. (India) Pvt. Ltd., (i) Length gauge as per clause 5.2(b);
to
New Delhl-110015.
(ii) Thickness gauge as per clause 4.2(b);
1977-03-31
(iii) Cylindrical metal measure 3 lit, 15 lit
and 30 lit as per clause 3,2(b)—
IS : 2386 (Pt. I & II)—1963
1976-04-01 The English Electric Co. India Ltd., Madras-43 Gas operated relays—
to
IS : 3637—1966
(Tamil Nadu).
1977-03-31
1976-04-01 Gangappa Cables Ltd., Hyderabad-500039 (i) Enamelled round including copper wires
to
(Andhra Pradesh).
with high mechanical properties—
1977-03-31
IS : 3800 (Pt. IV)—1968
(ii) Enamelled round winding copper wires
for elevated temperature—
IS : 4800 (Pt. V)—1968
1976-04-01 Evershine Electrical Works (I), New Delhi- Thermoplastic weatherprooflng cables :
110015
to
(i) PVC unsheathed & PVC sheathed all
1977-03-31
aluminium conductor 250/440 V—
IS : 3035 (Pt. I)—1965
(ii) Polyethylene insulated, taped braded &
compounded single core, aluminium
conductors—250/440 & 650/1100 V—
IS : 3035 (Pt. II)—1965
1976-04-01 English Electric Co. of India Ltd., Madras-43 (0 Electro-magnetic relays; and
to
(Tamil Nadu)
(ii) Induction relays—
1977-03-31
IS : 3231—1965
1976-05-01 Rajasthan Vanaspati Products P. Ltd.. Bhilwani 18-Htre square tins—
to
(Rajasthan).
IS : 916—1966
1977-04-30
1976-04-16 Metal Udyog Pvt. Ltd., Udaipur (Rajasthan)
Endrin EC—
to
IS : 1310—1974
1977-04-15
1976-03-16 P. Rakesh Electrical Works New Delhi-110028 PVC insulated PVC sheathed (HD) cabki for
to
working voltages upto and including 1.1
1977-03-15
kV with coppar and aluminium conductor—
IS : 1554 (Pt I)—1964
1976-05-01 New Chemi Industries P. Ltd, Bombay-400067
BCH D P to
IS : 561—1972
1977-04-30
1976-05-01
-doEndrin EC—
to
IS.-I310—1974
1977-04-30
1976-05-01
-doMalathlon E C to
IS : 2567—1973
1977-04-30
1976-05-01
-doDDT EC—
to
IS:633—1956
1977-04-30

41. CM/L-2965
1972-03-10
42. CM/L-2969
1972-03-10
43. CM/L-2983
1972-03-16

44. CM/L-2998
1972-03-28

45. CM/L-3003
1972-03-29

46. CM/L-3OO6
1972-03-30
47. CM/L-3010
1972-03-30

48. CM/L-3012
1972-03-30

49. CM/L-3017
1972-03-30
50. CM/L-3048
1972-04-28
51. CM/L-3089
1972-06-27
52., CM/L-3093
1972-07-03

53,. CMrL-3411
1973-04-13
54 . CM/L-3414
1973-05-11

55. CM/L-3415
1973-05-11

5t1 CM/L-3461
1973-06-28

Golden Sports, JuIlundur-2

[PART IT—SEC. 3(il)]

<!-- page 43 -->

1015
1

2

57. CM/L-3536
1973-09-06
58. CM/L-3599

1973-11-13
59. CM/L-3676

1974-01-16

60. CM/L-3685

1974-01-25

61. CM/L-3704

1974-02-06
62, CM/L-3711
1974-02-08
63. CM/L-3727
1974-02-28
64. CM/L-3728
1974-02-28
65. CM/L-3733

1974-03-05
66. CM/L-3743
1974-03-15
67. CM/L-3751

1974-03-15
68. CM/L-3753
1974-03-20
69. CM/L-3762

1974-03-29
70 CM/L-3764
1974-03 -29
7 1 . CM/L-3785

1974-04-02
72. CM/L-3796

1974-04-05
73. CM/L-3797
1974-04-09

74. CM/HSOS
1974-04-16

3

4

1976-03-16 Union Pesticides, Vidisha (M.P.)
to
1977-03-15
1976-04-01 Arkay Wires (P) Ltd, Kanpur
to
1977-03-31
1976-01-01 Indian Traders Pvt. Ltd., New Delhi-l 10015
to
1977-01-15

5
BHC DP—
IS:561—1972
AAC & ACSR conductors—
IS: 398—1961

PVC insulated and PVC sheathed cables
aluminium conductors, 250/440 and 650/1100
volts—
IS : 694 (Pt II)—1964
1976-02-01 Manju Electrical Industries Pvt Ltd, Coimbatore- Horizontal centrifugal pumps for celar, cold,
to
641021 (Tamil Nadu)
fresh water for agricultural purposes size
65 mm x 50 mm, 75 mm x 65 mm and 100 mm x
1977-01-31
73 mm only—
IS : 6596—1972
1976-02-16 U.K. Paint Industries, G T . Road, Amritsar Waterproof cement paint for exteriro use, all
to
colours—
1976-08-15
IS : 5410—1969
1976-02-16 iChakrabarty Commercial Traders CalcuitH-4 Tea-chest plywood ptmels—
to
IS : 10—1970
1977-02-15
Dry distemper—
1976-03-01 Golden Chemical Works. Amritsar
IS : 427—1965
to
1977-02-28
Industiial safety helmets—
1976-03-01 Udyogi Brothers, Calcutta-2
IS : 2925—1964
to
1977-02-28
1976-03-16 Progressive Industrial Corpn, RanchH (Bihar) All aluminium conductors and ACSR conducto
tors—
1977-03-15
IS : 398—1961
1976-03-16 Venus Pump & Engg. Works, Howrah
Sluice valves for water works purposes, class 1
to
sizes upto and including 200 mm—
1977-03-15
IS : 780—1969
1976-03-16 Industrial Plastics (India), Calcutta-27
Industrial safety helmets—
to
IS : 2925—1964
1977-03-15
1976-04-01 D.V.J. Engineierng, Caloutta-16
Flameproof enclosures of electrical apparatus—
IS : 2148—1968
to
1976-09-30
1976-04-01 Patel plastic Corpn, Bombay
Plastic water closet seats and covers. Type A—
IS : 2548—1967
to
1977-03-31
1976-04-01 Rallis India Ltd, (Fertilizer & Pesticides Divi- BHC DP—
IS : 561—1972
to
sion), Tata Fison
Pesticides Formulating
1977.03-31
Unit, Bombay-400080
1976-04-01 Oriental Power Cables Ltd, Cablenagai, Distt Thermoplastic
weatherproof cables PVC
to
insulated & PVC sheathed—
Kota (Raj)
1977-03-31
IS : 3035 (Pt I)—1965
1976-04-01 Punjab Saltpetre Refinery Ltd, FerozOpour City Malathion EC—
IS : 2567—1973
to
1977-03-31
Single phase ac electricity meters 2 wire whole
1976-04-16 Andhra Pradesh Electric Equipment Corpn,
current watt hour meters class 2.0, rating
to
Hyderabad-18
5—lOA—
1977-04-15
IS : 722 (Pt II)—1969
1976-04-16 ]Plastic Moulders Ltd, Howrah
High density polyethylene pipes for potable
to
water supply
1977-04-15
(1) upto & including 110 mm OD, rating
4 kgf/cm'
(2) Upto and inoludlng 110 mm OD rating
2.5 kgf/cm'
(3) Upto & including 110 mm OD, rating
6 kgf/cm1
(4) Upto and including 110 mm OD, rating
10 kgf/cm1
IS : 4984—1972

<!-- page 44 -->

1016

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901
2

3

75. CM/L-3807
1974-04-16

1976-04-16
to
1977-04-15
1976-04-16
to
1977-04-15
1976-05-01
to
1977-04-30
1976-05-01
to
1977-04-30
1976-05-01
to
1977-04-30
1976-05-01
to
1977-4-30
1976-04-01
to
1977-03-31
1976-01-16
to
1977 06-13
1976-03 -01
to
1977-02-28
1976-03-16
to
1976-09-30
1976-04-01
to
1977-03-31

1

76. CM/L-3808

1974-04-16
77. CM/L-3811
1974-04-19
78. CM/L-3821

1974-04-24
79. CM/L-3914
1974-08-05
80. CM/L-3951

1974-09-09
81. CM/L-4039
1974-11-05
82. CM/L-4125

1975-01-10
83. CM/L-4227

1975-02-21
84. CM/L4252

1975-03-07
85. CM/L-1268
1975-03-20

86. CM/L-4270
1975-03-20
87. CM/L-4277

1975-03-26
88. CM/L-4278
1975-03-26
87. CM/L-4284
1975-03-26
90. CM/L-4286

1975-04-03
9-1., CM/L-4290
1975-04-03
92, CM/L-4291
1975-04-08
93 . CM/L-4293

1975-04-08
94. CM/L^295
1975-04-08

[PART II—SHC. 3(ii)]

5

4

Metal Udyog Pvt-Ltd, Udaipur (Raj)

-doDura Cable Corpn, New Delhi

Industrial Cables flndia) Ltd, Kila Zaffargarh,
Distt Jind (Haryana)
Now Chomi Industries Pvt Ltd, Borabay-400067

do-

DDT DP—
IS ; 564—1961
BHCDP
IS : 561—1972
PVC insulated cable aluminium conductors
250/440 & 650/1100 volts—
IS : 694 (Pt 11)—1964
Galvanized steel wires and strips for armouring
cables—
IS : 3975—1967
Malathion DP—
IS : 2568—1973
DDT DP—
IS ; 564—1961

Kohinoor Paints Pvt Ltd, Chheharta, Amritsar

Black Japan, type A—
IS : 341—1973

Davidayal (Sales) Pvt Ltd, Bombay 400010

Endosulfan E C IS : 4323—1967

Baporia Sports, Jullundur

Shuttle cocks, Grade—selected and standard—
IS : 415—1963

Indiclay, Bombay-62

Carbaryl DP—
IS : 7122—1973

The En Reid India Ltd, (Agro Engineers Divi- Single clinder, vertical four stroke air cooled
sion), Madras-600020
spark ignition
engines of the following
ratings
kW
RPM
Type
(i) 1.1 (1.5 HP)
3400
MK-12/2
R.P.M.
(ii) 2,2 (3 HP)
3000
MK-25
R.P.M.
IS : 7347—1974
Sakti Engineering Co, Vtfayawada Taluk (A,P.) AAC & ACSR conductors—
IS : 398—1961

1976-04-01
to
1977-03-31
1976-04-01 Enpec Wire Industics (P) Ltd, 24 Paiaganas Tea-chest metal fittings—
to
IS : 10-1970
1977-03-31
1976-04-01 S.D.S. Corpn, Calcutta-12
Tea-chest metal fittings—
to
IS : 10—1970
1977-03-31
1976-04-01 Indiclay, Bombay-62
BHC DP—
to
IS : 561—1972
1977-09-30
1976-04-01 Assam Chemical Industries, Bongaigaon, Assam Malathion EC—
to
IS : 2567—1973
1977-03-31
1976-04-01
Aldrin EC—
-doto
IS : 1307—1973
1977-03-31
1976-04-16 Utkal Pesticides and Chemicals, Jagannathpur, Endrin EC—
to
Distt Qanjam (Orissa)
IS : 1310—1974
1977-04-15
-do1976-04-16
DDT EC—
to
IS : 633—1956
1977-04-15
1976-04-16 Vljaya Pulvriiers, Guntur Distt (A.P.)
Endrin EC—
to
IS : 1310—1974
1977-04-15

<!-- page 45 -->

1017
1

2

95. CM/L-4296
1975-04-08
96. CM/L-4297
1975-04-08
97. CM/L-4298
1975-04-08
98. CM/L-4299
1975-04-08
99. CM/L-4301
1975-04-08
100. CM/L-4302
1975-04-08
101. CM/L-4303
1975-04-08
102. CM/L-43(M
1975-04-10
103. CM/L-4306
1975-04-14
104. CM/L-4312
1975-04-14
105. CM/L-4313
1975-04-14

106. CM/L-4318
1975-04-21
107. CM/L-4319
1975-04-21
108. CM/L-4321
1975-04-21
109. CM/L-432?
1975-04-21
110. CM/L-4323
1975-04-21
111. CM/L-4330
1975-04-21
112. CM/L-4336
1975-04-25
113. CM/L-4337
1975-04-25
114. CM/L-1342
1975-04-25
115. CM/L-4344
1976-04-25
116. CM/L-4363
1975-05-09
117. CM/L-4368
1975-05-09

3

4

5

AAC & ACSR conductors—
1976-04-16 General Metals, Trivendrum-695019 (Kerala)
TS : 389—1961
to
1977-04-15
Dye based fountain pen inks, red and royal
1976-04-16 Sudha Industries, Ludhiana
blue—
to
IS : 1221—1971
1977-04-15
1976-04-16
-doFerro gallo tannate fountain pen ink (0.1
per cent iron content)—
to
IS : 220—1972
1977-04-15
DDTEC—
1976-04-16 Mctal Udyog Pvt Ltd, LJUaipur
IS : 633—1956
to
1977-04-15
Tower bolts, aluminium, type 3—
1976-04-16 Argent Industries, New Delhi
IS : 204—1974
to
1977-04-15
1976-04-16 Crop Health Products Pvt Ltd, Ghaziabad
DDT EC
IS : 633—1956
to
1977-04-15
1976-04-16 Kirloskar Brothers Ltd Kirloskarvadi, Taluka Sluice valves for water works purposes, class 2,
upto and including 600 mm sizes—
to
Tasgaon, Distt Sangll (Maharashtra)
IS : 2906-1969
1977-04-15
1976-04-16 Hindustan Koku Wire Ltd. Faridabad
(Har- Galvanized steel wire for armouring cables—
rS : 3975—1967
to
yana)
1977-04-15
1976-04-16 Anand Timber Traders Yamunanagar
Plywood tea-chest battens—
to
TS : 10—1970
1976-01-15
Horizontal centrifugal pumps for clear, cold
1976-04-16 Coimbatore Premier Corpn Pvt LtJ, Coimbafresh water size 65 x 50 mm (Type 2) (B 2)
to
tore-641030
IS : 1520-1772
1977-04-15
1976-04-16 Photophone Pvt Ltd, Bombay-400072
16 mm portable sound and picture cinematoto
graph projectors, 230 volts, 50 Hz 400 W
(Maharashtra)
1977-04-15
iwn with projection lamp of 24 V/220 W,
hologpn lamp (firm's model Nos IMI 15107
F and IMI 35108 P)—
IS : 4497—1968
1976-05-01 Auditniya Mineral Traders, Kondopuram R.S. DDT EC—
to
Cuddapah Distt (A.P.)
IS : 633—1956
1977-01-15
Besan—
1976-05-01 Gokal Chand Prabhu Dayal, Jammu Tawi
IS : 2400—1963
to
1977-04-30
1976-05-01 Tropical Agros systems (P) Ltd, Ottapalam-3 DDT DP to
(Kerala)
IS : 564—1961
1977-04-30
-doDDT E C 19'/6-05-01
IS : 633—1956
to
1977-04-30
-doEndrin EC—
1976-05-01
TS : 1310—1974
to
1977-04-30
1976-05-01 Krishna Miners & Traders, Jaipur West (Rajas- DDT D P IS : 564—1961
than)
to
1977-04-30
18-Htre square tins—
1976-05-01 Tata Tin Mfrs Co, New Delhi
to
IS : 716—1966
1977-04-30
Malathion DP—
1976-05-01 Tropical Agrosystcma (P) Ltd, Ottapalam-3
IS 2568—1973
(Kerala)
1977^30
DDT DP—
1976-05-01 Madhusudan Industries, Madras-81
to
IS : 564—1961
1977-04-30
1976-05-01 Pesticides India, Udaipur
Dimethoate EC—
IS : 3903—1966
to
1977-04-30
Carbaryl D P 1976-05-16 Motilal Pesticides India, Mathura (U.P.)
to
IS : 7122—1973
1977-05-15
DDTEC—
1976-05-16 Prakash Pulverising Mills, Alwar (Rajasthan)
to
IS : 633—1956
1977-05-15
[No. CMD/13 : 12]
A.P. BANERJI. Dy. Director General

<!-- page 46 -->

1018

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART U ^ S E C .

3(ii)]

<!-- page 47 -->

1019

<!-- page 48 -->

1020

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART I I ^ S E C . 3(U)]

<!-- page 49 -->

1021

New Dclh], 1979-03-30
S.O. 1226.—In pursuance of sub-regulation (1) of Regulation 8 of the Indian Standards Institution (Certification Marks)
Regulations, 1955, as amended from time to time, the Indian Standards Institution hereby notifies that fortyseven licences, particulars,
of which are given in the following Schedule, have been granted during thc.Month of July 1976 authorising the licensees to use the standard
mark.
SCHEDULE
SI Licence No.
(CM/L-)

Period of Validity

Name & Address of the Licensee

NO.

(1)

(2)

1. CM/L-5333
1976-07-01

1367GI/78—7

From

To

(3)

(4)

1976-07-01

(J)

Article/Process Covered by the licence
and Rolcvant IS ; Designation

(6)

1977-06-30 Siddhaitha Feiro Alloys Ltd, Rishra Carbon steel cast billet ingots for
on National Highway No. 2 (Delhi
rolling into sti uctural stool (standard
Road) Near Rishra Sub-Powor Staquality)—
tion, P.S. Serampore Distt. Hooghly
TS : 6914-1973
(Office : 25, Nefaji Subhas Road,
Calcutta-700001)

<!-- page 50 -->

1022
(i:1

THE GAZETTE OF INDIA : APRIL 14, 1979/CHATTRA 24, 1901
(2)

(3)

(4)

(5)

[PART II—SEC. 3(ii)]
(6)

2. CM/L-3334
1976-07-06

1976-07-16

1977-07-15 Agro Plastic Industries, 92, Virwanl Hand operated continuous knapsack
Industrial Eslato, Goregaon East, sprayer, piston type—
Bombay-400063
IS : 3906 (Pt I)—1974

3. CM/L-5335
1976-07-09

1976-07-16

1977-07-15 Dalmla Dairy Industries (Prop. Dalraia Skim milk powder—
Industries Ltd.) Chana Sewar Bypass
IS : 1165-1967
Road, Bhartpur (Rajasthan)

4. CM/L-5336
1976-07-09

1976-07-01

5. CM/L-5337
1976-07-09

1976-07-16

Krishi Rasayan (Bihar), Larger Indus- Endrin EC—
IS : 1310-1974
trial Estate (Bela) P.O. R.K. Ashram,
Muzaffarpur-842201
1977-07-15 MotUal Pesticides India, Masani Delhi Endosulfan EC—
Road, Mathura-281001
IS : 4323-1967

6. CM/L-5338
1976-07-09

1976-07-16

1977-07-15 Saraswati Steel & Alloys Ltd., Mcerut Carbon steel cast billet ingots for
rolling into structural steel (standard
Road, Muzaflfarnagar (U.P.)
quality)—
IS : 6914-1973

7. CM/L-5339
1976-07-09

1976-07-16

1977-07-15

8. CM/L-5340
1976-07-09

1976-07-16

1977-07-15 S. D's Lab-Chem Industries, 116 B, Sulphuric acid Grades (1) (Pure) and
Kandlvali Industrial Estate, Kandivali (2) (AR)
(West) Bombay-400067
IS : 266-1961

9. CM/L-5341
1976-07-09

1976-07-16

1977-07-15

-do-

Acetic acid Grades (1) PURE and (2)
AR—
IS : 695-1965

10. CM/L-5342
1976-07-09

1976-07-16

1977-07-15

-do-

Hydrochloric acid grades (1) PURE and
(2) A R IS : 265-1962

11. CM/L-5343
1976-07-09

1976-07-16

1977-07-15

-do-

12. CM/L-5344
1976-07-09

1976-07-16

13. CM/L-5345
1976-07-09

1976-07-01

1977-06-30 P.V.S, Industries, Amaravathy,
Hospet-583201

14. CM/L-5346
1976-07-09

1976-07-01

1977-06-30 Vorlon Industries & Chemicals, 551/1, DDT DP—
Mogappcri (Via) Padi, Madras-60005() IS : 564-1961

15. CM/L-5347
1976-07-09

J 976-06-16

1977-06-15 Southern Insecticides & Fertilizers, Fenitrothion EC—
l-A/2, Industria Estate, Ambattur,
IS ; 5281-1969
Madras-600098

16. CM/L-5348
1976-07-09

1976-07-01

1977-06-30 Ayyappa Agro Chemicals, No. 27-A, BHC DP—
IS : 561-1972
Kottur Road, Sulloswaranpalty Post,
Pollachi-642006 (Coimbatore Distt)

17. CM/L-5349
1976-07-09

1976-07-16

1977-07-15 Co-operative Cattle Feed Factory Compounded feeds for cattel—
(Rajasthan State Co-operative
IS : 2052-1968
Marketing Federation Ltd.) 88 Indusitrial
Area, Jhotwara (Jaipur West)

18. CM/L-5350
1976-07-14

1976-07-16

1977-07-15 A.K. Corporation Ltd., Mallkapuram, Carbon steel cast billet ingots for
Visakhapatnam (A.P.) (Office :
rolling into structural steel (standard
7-10-3, Krilampudl, Visakhapatnamquality)—
530003)
IS : 5914-1973

1977-06-30

-do-

Carbon steel cast billets ingots for
rolling Into structural steel (ordinary
quality)—
IS : 6915-1973

Nitric acid Grades (1) PURE and (2)
AR—
IS : 264-1950
1977-07-15 A.K. Corporation Ltd., Malkapuram, Carbon steel cast billet ingots for
Visakhapatnam (A.P.) (Office :
rolling into structural steel (ordinary
7-10-30 Klrlampudi,
Vasakhapatquality)—
nam-530003)
IS : 6915-1973
DDT WDP—
IS : 565-1961

<!-- page 51 -->

1023
1

(2)

19,. CM/L-5351

(3)

(4)

(5)

(6)

1976-07-16

1977-07-15 Partap Stool Rolling Mills Ltd, Indus- Structural stocl (ordinary quality)—
IS : 1977-1975
trial Area, Patancheru, Distt Medak,
(A.P.)

1976-07-16

1977-07-15 Crown Surgical Dressing Mfg Co, 66 Hatidloom cotton bandage cloth—
IS : 863-1969
Sidhpura Industrial Estate, Masrani
Lane, Kurla, Bombay-400070

1976-07-16

1977-07-15 Techon Enterprise, 3/136, Paschim Tea-chest metal flttiags—•
Puttiary, Calcutta-700041
IS : 10-1970

1976-07-16

1977-07-15 Sudhakar P.V.C. Products, Qovt. Indus- Rigid non-mstallic conduits for electritrial Estate, Suryapot, Nalgonda
cal installations size 32 mm—
Distt (A.P.)
IS : 2509-1973

23. CM/L-5355
1976-07-14

1976-07-16

1977-07-15 Mohta Ispat Ltd., 70-72, Industrial Aroa, Carbon steel cast billot ingots for
Ratlam-457001 (M.P.)
rolling into structural steel (standard
quality)—
IS : 6914-1973

24. CM/L-5356

1976-07-16

1977-07-15

1976-07-14

2C). CM/L-5352

1976-07-14
21. CM/L-5353

1976-07-14
22. CM/L-5354

1976-07-14

Carbon steel cast billet ingots for
rolling into structural steel (ordinary
quality)—
IS : 69154973

•do-

1976-07-14

25. CM/L-5357
1976-07-14

1976-07-16 1977-07-15

26. CM/L-5358
1976-07-14

1976-07-16

1977-07-15 Hastings Mills Ltd., Rishra (Olfljo : 14, Jute fabric for fertilizer bags—
Netaji Subhas Road, Calcutta-700001)1 IS : 7407-1974

27. CM/L-5359

1976-07-16

1977-07-15 B.S. Agriculture Industries (India), Vortical dicscl engine, water, cooled,
single cylinder, four stroke of the
12/15/A A, NawalganJ, Agra-282006
following rating :
R.P.M.
Type
KW

1976-07-14

Pest Chemi Co, M.I. DC. Shod No. Endrin EC—
26, Chemical Zone, AmbarnathIS : 1310-1974
421501 Thana (Office : U/210-C,
Dr. Ambedkar Road,
Matumga,
Bombay-400019)

3.67 (5 HP) 1500
BSV-1
IS : 1601-1960
1977-07-15 Bitumen Products (India) 90A, Biren Industrial bitumen Grade 85/25 and
Roy Road, (East) Calcutta-700041
90/15—
IS : 702-1961
1977-07-15 UK. Paints Industries, Village Sultun- Putty for use on window frames—
pur, Mehrauli—Gurgaon Road,
IS : 419-1967
New Delhl-110030.

28. CM/L-5360

1976-0746

29. CM'L-5361

1976-07-16

30. CM/L-5362

1976-07-16

1977-07-15 Bharat Minerals & Chemicals Co., BHC DP—
Transport Depot Road, (Behind
IS : 561-1972
No. 9) Calcutta-700027 (Offico :
174, Mahatma Gandhi Road, Calcutta-700007)

31. CM/L-5363
1976-07-14

1976-07-16

1977-07-15 Rallis India Ltd., F & D Division, Chlordanc E C Tata Flson Pesticides Formulating
IS : 2682-1966
Unit, 431/34, Balarajeshwar Road,
Mulund, Bombay-400080.

32. CM/L-536-t

1976-0746

1977-07-15 Krishna Chemical Industries, Laige Aldrin EC—
Industrial Estate, Barari, BhagalrmrIS : 1307-1973
812003 (Bihar)

33. CM/L-5365

1976-07-16

1977-07-15

1976-0744
34. CM/L-5366
1976-07-14

1976-07-16

1977-0745

35. CM/L-S367

1976-07-16

1977-07-15 A1 lied Chemical Industries, Hajo Road, Endosulfan EC—
IS : 4323-1967
Amingaon, Gauhati-781031 (Office :
G.N.BadololRoad,Gauhati-781003)
(Assam)

1976-07-14

1976-07-14

1976-07-14

1976-07-04

1976-07-14

-do-

Malathion EC—
IS : 2867-1967

Krishi Rasayan (Bihar), A-2, Largo BHC D P Industrial Eslalo, R.K. Ashram,
IS : 561-1972
Muzaffaipui -842001

<!-- page 52 -->

1024
1

FHE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901
2

3

36. CM/L-536S
1976-07-14
37. CM/L-5369
1976-07-14

1976-07-16

38. CM/L-5370
1976-07-14

1976-07-16

39. CM/L-5371
1976-07-16

1976-07-16

40. CM/L-5372
1966-07-20
41. CM/L-5373
1976-07-20

1976-08-01

42. CM/L-5374
1976-07-21

1976-08-01

43. CM/L-5375
1976-07-21

1976-08-01

44. CM/L-5376
1976-07-21

1976-08-01

45. CM/L-5377
1976-07-21

1976-08-01

46, CM/L-5378
1976-07-21

1976-08-01

47. CM/L-5379
1976-07-28

1976-03-16

1976-07-16

1976-08-01

4

5

[PART II—SEC. 3(ii)]
6

1977-07-15 Sunray Chemical Industries, Jamuna Malathion DP—
Kinara, Agra-282004 (UP.;
IS : 2568—1973
1977-07-15 Shiv Shakti Pipe Industries, Kukra BHC D P Road, New Mandi, Muzaffarnagar
IS : 561—1972
(U.P.)
1977-07-15 Rallis India Ltd, F & D Division, Fenitrolhion FC —
Thana-Belarur Road, P.B. No. 91
IS : 5281—1969
Thana-400601 (Mahaiashtra)
1977-07-15 Sharpedge Ltd, 34 & 36 Okhla Indus- Blades, razor, safety stainless sled
trial Estate, New Delhi-110020
only, medium (ype—
IS : 7371—1975
1977-07-31 [ndo Swing Ltd, Narsapur Ro?d, Safety razor blades—
Blanagar, Hyderabad
IS : 7371—1975
1977-07-31 Lauls (Pvt) Ltd, 33-B, Industrial Aiea Structural steel (standaid qna)ji\)
N.I.T. Faridabad. Distt Gurgaon
IS : 226—1975
(Haryana)
1977-07-31 Mahta Ispat Ltd, 70-72, Industrial Steel ingots for volute, helical and
Area.Ratlam-457001 ( M l . )
laminated springs for automotive
suspension 55 Si 2 Mn 90 Grade—
IS : 3431—1965
1977-07-31
-doSteel ingots for the manufacture of
laminated springs (railway rolling
stock) 55 Si 2 Mn 90 Grade—
IS : 3885 (Pt I)—1966 &
IS : 3885 (Pt II)—1969
1977-07-31 The Rajasthan Small Industries Corpn. Bidis—
Ltd, 12, Sahdev Marg, C-Scheme, IS : 1925—1974
Jaipur (Factory at Pandeyji Ka
Bagh, Jaipur Road, Tonk under the
style of Mayur Bidi Industries)
1977-07-31 James Huton & Co, 37/803, Power Coal tar food colour preparations and
House Rod, Cochin-682018
mixtures—
TS : 5346—1975
1977-07-31 Hilton Rubber Pvt Ltd, 40th K M . (i) Rubber conveyor and elevator
Stone, G.T. Road, Village & P.O.
goneral purpose belting—
Ral, (Sonopat) Haryana
IS : 1891 (Pt 1)—1968
(ii) Rubber conveyor and elevator
heat resistant belting—
IS : 1891 (Pt n)—1972
1977-08-15 IISCO Stanton Pipe & Foundry Co. Centrlfugally cast (spun) iron pressure
Ltd, Dewas Road, Ujjain-456010
pipes for water gas and sewage
(M.P.)
upto 300 mm nominal- diameter
classes LA, A and B—
IS : 1536—1967
[No. CMD/13 : 11]
A. P. BA NERJI, Deputy Director General
MINISTRY OF INDUSTRY
(Department of Industrial Development
ORDER
New Delhi, the 28th February, 1979
S.O. 1227/JDRA.—In exercise of the powers conferred
by Section 6 of the Industries (Development and Regulation)
Act, 1951 (65 of 1951) read with Rules 2, 4 and 5 of the
Development Council Procedural Rules 1952, the Central
Government hereby makes the following amendments in the
order No. S.O.
/IDRA dated 18-12-78 of the Government of India, Ministry of Industry •(Department of
Industrial Development) namely :-—
In the said order.
In the said order for S. Nos. (1) and (2) "Shri M. A,
RangHswnrry, Special Secretary Department of
Industrial
Development" and "Shri S. K. Sarkar, Joint Secretary,
Department of Industrial Development", respectively, "Special Secretary. Department of Industrial Development" and
"Joint Secretary Department of Industrial Development"
respectively should be substituted.
[F. No. 38(14)/7fi-M.I.]
SURESH KUMAR, Dy. Secy.

<!-- page 53 -->

1025
Land) Act, 1962 (50 of 1962). the Central Government
declared its intention to acquire the right of user in the
liiiula specified in the schedule appended to I hut notification
for the purpose of layinjt pipeline ;
And whereas the Compclent Authority has under Subsection (1) of Section 6 of the said Act, submitted report
to the Government;
And further whereas the Central Government has. after
considerinK the said report, decided to acquire the right of
user in the Iqods specified in the schedule appended to thjy
notification;
Now, therefore, in exercise of the power conferred by
suh-seciion fl) of Section
6 of the snid Act, the Central
Government hereby dec1 ares that the right of user in
the said lands specified in the schedule appended to thin
notification hereby acquired for laying the pipelines ;
And further In exercise of power conferred by Sub-section
(4) of that Section, the Central Government directs that
the right of user in the said lands shall instead of vesting
in the Central Government vest on this date of the publication of this declaration in the Oil & Natural Gas Commission free from encumbrances.
SCHEDULE
For Laying Pipeline from Well No. NKAN to QGS-CUMCTF Kadi
State : Gujarat
Villages

Hec- Arc Centiarc
tare
District : Mehsana Taluka : Kadi
93
0
AC,
14
91/2
0
22
20
Survey Ni>

83

0

District : Mehsana
252/P
252/P
260/1
260/4
260/2
262/4

19

20

Taluka : Viramgam
0
15
48
0
0
0
0
0

18
03
03
05
17

72

24
24
50
64

[No. !20t6/6/77-Prod.]

MINISTRY OF PETROLEUM, CHEMICALS AND
FERTILIZER
(Department of Petroleum)
New Delhi, the 29th March, 1979
S.O. 122H.--.\Vlieieiw by a notifL-ilion of ih? Government
of India in the Ministry of Petroleum, S, O. No. 897 dated
13-3-78 under Sub-section (1) of Section 3 of the Pctroleuni
and Minerals Pipelines (Acquisition of Right of User in

<!-- page 54 -->

1026

THE GAZETTE OF INDIA : APRIL 14, 1979/CHATTRA 24, 1901

[PART II—SEC, 3<U)]

SCHEDULE
Pipeline from Well No. S—31 lo S—15
Slate : Gujarat

District ; Mehsamt Taluka : Kalol

Village

Survey No.

•Tethalaj

417
447

Cart track.
421
422

446/1 and 2
445
426

441/1
441/2
442/2 B
442/2 A
440/3
438/1
428/3
430

Hec- Are Ccntare
tiare
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

03
10
01
10
07
20
01
01

04
Ofi

04
03
03
06
02
03

fiO

50
«
50
65
25
20
00
65
45
95
00
60
30
K5
90

[No. 12016/1/78-Prod]

S.O. 1229.—Whereas) by a notification of the Government
of India in the Ministry of Petroleum, S.O. No. 3363 dated
5-11-78 under Sub-section (1) of Section 3 of the Petroleum
and Minerals Pipelines (Acquisition of Right of User in Land)
Act, 1962 (50 of 1962), the Central Government declared its
intention to acquire the right of user in the lands specified
in the schedule appended to that notification for the purpose
of laying pipeline ;
And whereas the Competent Authority has under SubBcction (1) of Section 6 of the 8nid Act, submitted report to
the Government;
And further whereas the Central Government has, after
considering the said report, decided to acquire the right of
user in the lands specified in the schedule appended to this
notification ;
Now, therefore, in exercise of the power conferred by subsection (1) of the Section 6 of the said Act, the Central
Government hereby declares that the right of user in the
said lands specified in the schedule appended to this notification hereby acquired for laying the pipelines ;
And further In exercise of power conferred by Subsection
(4) of that Section, the Central Government directs that the
right of user in the said lands shall instead of vesting in
the Central Government vest on this date of the publication
of this declaration in the Oil & Natural Gas Commission
free from encumbrances.

<!-- page 55 -->

1027
New Delhi, the 30th March, 1979
S.O. 1230. Whereas by a notification of tlic Government
of India in the Ministry of Petroleum, S.O. No. 3321 dated
30-10-78 under Sub-section (1) of Section 3 of the Petroleum
and Minerals Pipelines (Acquisition of Right of User in Land)
Act, 1962 (50 of 1962), the Central Government declared
its intention to acquire the right of user in the lands specified
in the schedule appended to that notification for the purpose
of laying pipeline;
And whereas the Competent Authority has under Subsection (1) of Section 6 of the said Act, submitted report to
the Government;
And further whereas the Central Government has, after
considering the said report, decided to acquire the right of
user in the lands specified in the schedule appended to this
notification ;
Now, therefore, in exercise of the power conferred by subsection (1) of the Section 6 of the said Act, the Central
Government hereby declares that the right of user in the
said lands specified in the schedule appended to this notification hereby acquired for laying the pipelines ;
And further in exercise of power conferred by Sub-section
(4) of that Section, the Central Government directs that th»
right of user in the said lands shall instead of vesting in the
Central Government vest on this dale of the publication of
this declaration in the Oil and Natural Gas Commission free
from encumbrances.
SCHEDULE
Acquisition of Right of User from Well No, Sobhasan-36 to
W.H.I. Sobhasan-10.
State ; Gujarat
Village

Kukas

District & Taiuka : Mehsana
Survey No.

318/P
322

Hec- Are Centare
tiare
0
0

38
03

16
00

[No. 12016/4/78-Prod]

New Delhi, the 31st March, 1979
S.O. 1231.—Whereas by a notification of the Government
of India in the Ministry of Petroleum, S.O. No. 146 dated
16-12-78 under Sub-section (lj of Section 3 of the Petroleum
and Minerals Pipelines (Acquisition of Right of User in
Land) Act, 1962 f50 of 1962), the Central Government declared its intention to acquire the right of user in the lands
specified in the schedule appended to that notification for
the purpose of laying pipeline ;
And whereas the Competent Authority has under Subsection (1) of Section 6 of the said Act, submitted report
Lo the Government;
And further whereas the Central Government has, after
considering the said report, decided to acquire the right of user
in the lands specified in the schedule appended to this notification ;
Now, therefore, in exercise of the power conferred by
sub-section (1) of the Section 6 of the suid Act, the Central
Government hereby declares that the right of user in the
said lands specified in the schedule appended to this notification hereby acquired for laying the pipelines;
And further in exercise of power conferred by Sub-section
(4) of that Section, the Central Government directs that the
right of user in the said lands shall instead of vesting in the
Central Government vent on this date of the publication of
this declaration in the Oil and Natural Gas Commission free
from encumbrances.

<!-- page 56 -->

1028

THE GAZETTE OF INDTA : APRTL 14, 1979/CHAITRA 24, 1901

[PART II—SEC. 3(ii)]

SCHEDULE
Rou from Wt.ll No. M. (5X)to STM lo SPD
Stale : Gujarat

Distt : Mehsanu

Survey N o .

Vi 11 nee

Memadpura

BaNasan

TaliiKu : Mehsana

Hectare

Are

0
09
39
0
03
3R
15
0
42
Taluka-~Viramgam
Dislt : Ahmcdabad
0
07
95/1 & 2
0
07
94/3
06
0
82/1
0
0?
K2/2
0
05
89

Ccntiare

New Delhi, the 30lh March. 1979

00
25
00

S.O. J233.—In pursuance of sub-rule 4 of rule 10 of the
Official Language (use for Official purposes of the Union)
RUIM, 1976 the Central Government hereby notifies the following Offices, the staff whereof have acquired the working
knowledge of Hindi :—

50
00
50
50
50

1. Director General of Health Services, Nirman Bhavaiu
New Delhi.
2. Government Medical Store Depot, Bombay Cential,
Bombav.
[No, E. 11012/4/79-O L. Implementation]

[No. 12016/16/78-Prod]
S.M.Y. N A D E E M , Under Secy.

MINISTRY OF HEALTH A N D FAMILY

WELFARE

(Department of Health)

CORRIGENDUM
New Delhi, lhc 28tb February, 1979
S.O. 1232.—The Department of Personnel anj Administrative Rrforms have informed this Ministry that the Secretary
of States' Service (Medical Attendance) Rules, 1938, hnve
been repealed from the 1st October, 1972, therefore the words
"the Secretary of States' Services (Medical Attendance) Rules,
1938 appearing in para 2 of this Ministry's Notification No.
S 11Ol2/6/78-CGHS(P)(A) dated the 27th June, 1978—
Central Govrenment Health Scheme (Piinc) Rules, 1978 may
be treated to have been deleted.
[No. S. 11012/6/78-CGHS(P)(A)]
K, C. KAPO0R, Under Secy.

A. P. ATRI, Director

<!-- page 57 -->

1029
1

2

3

4

5

7. Sh. R.S. Mathur

Technical
Assistant

Technical
Assistant

1-3-69

R. Sh. K.K. Abrol

18-2-72
Quality
Inspector-I
1-1-77
Senior
Godown
Keeper
[No. : 52/l/79-FC.lII(Vol.II)]
BAKHSHI RAM, Dy. Secy.

FPS
Inspector
9. Shri V.G . Narnyuna- . Senior
Godown
murthy
Keeper

MINISTRY OF AGRICULTURE & IRRIGATION
(Department of Food)
ORDER
New Delhi, the 24th March, 1979
S. O. 1234.— Whereas the Central Government has
ceased to perform the functions of purchase, storage, movement,
transport, distribution and sale of foodgrains done by the Department of Food, the Regional Directorates of Food, the
Procurement Directors and the Pay &. Accounts Offices of the
Oipartm^nt of Food which under Section 13 of Food Corporations Act, 1964 (37 of 1964) are the functions of ihe Food Corporation of India;
And wh^rcai the following officers and employees serving
in tho Department of Food, the Regional Directorate of Food,
the Procurement Directorates and the Pay & Accounts Offices
of the Department of Food and engaged in the performance of
the functions mentioned above have not, in response to the
Circular of the Central Government dated the 16th Apiil, 1971
intimated, within the date specified therein, their intention of
not becoming employees of the Food Corporation of India as
required by the proviso to sub-Section (I) of Section 12A of the
said Act;
Now, therefore, in exercise of the powers conferred by Section HA of the Food Corporations Act, 1964 (37 of 1964) as
amended upto date the Central Government hereby transfer the
following officers and employees to the Food Corporation of
India with effect from the date mentioned against etch of them
SI.. N a m e of t h i Officer Permanent
post held
N<3. employees
under the
Central
GOvt,

1

i

Post held
under the
Central
Govt. at
the time of
transfer
4

1. Sh. H . R . Ahluwalia

Date of
transfer
to the
FCT

5

L.D.C.

L.DC.

2-7-78

.

Technical.
Officer

Assistant
Director

1-3-69

3. Sh. Naniga Pd. .

Watchman

Watchman

1-3-69

4. Sh. Sargoo Ram

Dusting
Operator

Dusting
Operator

1-3-69

Watchman

1-3-69

Godown
Clerk

21-2-78

2. Sh. R.R.Scn

.

5. Sh Brijender Singh

6. Sh. Lakhan Singh
1367GI/7R—8

-^—

<!-- page 58 -->

1030

fHE GAZETTE OF INDIA : APRIL 14, 197WCHAITRA 24, 1901

[PAST II—SEC. 3(ii)]
TABLE

SI1. Description of the Property
isfo0 fthe
p roP1srty
1

2

Name of the
Government
Companies

3

1. The land, building and premises Eastern Coalknown as 13, R,N. Mukher- fields Limited
jee Road, Calcutta, where the
Coal Board's Head Office was
located, together with all the
fixtures, furniture and office
equipment located therein and
one of the three motor cars
owo«d by the Coal Boaid, nt
Calcutta.
2. The land office and residential
buildings and premises known
as the Coal Board Colonies
Lachipur( and Asansol, including the Pump House and rest
house where the Coal Board's
office & Staff
colony were
located together with all the
fixtures, furniture, vehicles and
office and other equipment
located therein.

MINISTRY OF ENERGY
(Department of Coal)
ORDER
New Delhi, the 24th March, 1979
S.O. 1235. - I n exercise of the powers conferred by
Section 13 of the Coal Mines (Conservation and Development)
Act, 1974 (78 i f 1974), the Central Government, being satisfied
that the Government Companies specified in column (3) of the
Table below arc willing to comply with the teims and conditions imposed by the Central Government, hereby directs tliat
the right, title and interest of the Coal Bopxd in rclrtion lo i1s
properties specified in column (2) of the so id Tuble shell, instttd
of continuing to vest in the Central Government, vest in the said
Government Companies with effect fiom the date specified in
column (4) of the aforesaid Table:

Date
from
which it
is vested
4
1-11-1975

1-11-1975
Central Mine
Planning &
Design
Institute Limited

3. Land of approximately 17.65 Western Coalacres
area in Baikunthpur, fields Limited
Madhya Pradesh belonging to
the Coal Board.

1-11-1975

4. Land of approximately 9 acres National Coal
area In Ramgarh, District Development
Hazaribagh, Bihar.
Corporation Ltd
now known as
Central Coalfields Limited

1-4-1975

5. The installations known as Eastern CoalJambad
Kajora Ropeways fields Limited
in Ranlganj Coal field and the
appurtenant Central Workshop
at Lachipur together with all
lands, buildings, roads, plant,
equipment, ftiratture, vehicles,
stores and spares connected with
the said ropeways project.

1-11-1975

6. Furniture, office equipment Western Coel
and other equipments at ex- fields Limited
Coal Board's Nagpur office.

1-11-1975

7. Furniture and office equipment Coal Mines
at ex-Coal Board's
Kan- Authority Ltd.
pur office.
now known as
Coal India Ltd.

1-4-1975

8. The Land, office and residential Bharat Coking
buildings and premise? known Coal Limited
as Coal Board Colonies at Hfrapur and Seraidhalla near Dhanbad where the Coal Board's office
and staff quarters were located

1-4-1975

<!-- page 59 -->

1531
2

3

•<*•

1

together with all the fixtures,
furnituie, vehicles and office and
other equipment located therein.
9. The installation known as Area Bharat Coking
'D' Ropeways and Area 'F' Coal Limited
Ropeways in Jharia coalfield
together with all land, buildings,
roads, plant, equipment, furniture, vehicles, stores and spares
connected with the said ropeways
project.

1-4-1975

2. The Order published in the Gazette of India part II,
Section 3, Sub-section (ii) dated the 23rd July, 1977 bearing
S.O. No. 2360 is hereby cancelled.
[File No. 55019/24/75-CPC/CRC]
S.R.A. RIZVI, Director

<!-- page 60 -->

1032

THE GAZETTE OF INDIA: APRIL 14, 1979/CHAITRA 24, 1901

IPART II—SEC 3(ii)J

<!-- page 61 -->

1033

MINISTRY OF WORKS AND HOUSING
New Delhi, the 27th March, 1979
S.O. 1236.—In exercise of the powers conferred by the
proviso to sub-section (2) of section 1 of the Delhi Rent
Control Act, 1958 (No. 59 of 1958), the Central Government
hereby extends all the provisions of the Delhi Rent Control
Act, 1958
(a) to the localities mentioned in the corrigendum of
the Municipal Corporation of Delhi No. 8047/T/
CO/SC, dated the 31st March, 1960 (copy enclosed
as Annexure 'A') published in Part IV of the Delhi
Gazette dated the 14th April, 1960 which by virtue
of that notification have formed part of the urban
areas within the limits of the Municipal Corporation
of Delhi.
(b) to thv localities mentioned in the Schedule
to
the Notification of the Municipal Corporation of
Delhi No. RNZ/526, dated the 23yd May, 1963
(copy enclosed as Anncxure 'B') published in Part IV
of the Delhi Gazette No. 24, dated tbc 13th June,
1963 and which by virtue of that noflffcation have
formed i>urt of the urban areas within the limits of
the Municipal Corporation of Delhi, and
(c) to the localities mentioned in the Schedufe to the
notification of the Municipal Corporation of Delhi
No. F. 9(2)/66-Law. Corp, dated the 28th May,
1966 (copy enclosed as Annexure 'C') published In
Part IV of the Delhi Gazette No. 41, dated the
3rd June, 1966 and which by virtue of that notification have formed P?rt of the urban areas within the
limits of the Municipal Corporation of Delhi.
ANNEXURE 'A'
p \ R T I V DELHI GAZETTE, DELHI ADMINISTRATION :
APRIL 14, i960
MUNICIPAL CORPORATION OF DELHI
CORRIGENDA
Delhi, the 31st March, 1960
No. 8047/T/CO./SC.—In the notification No. F. 9/5/59- R&S,
dated the 28th December, 1959 published in the Government
of India, Delhi Gazette (Part TV) dated the 7ih January, I960
tilt name* of the following thiee villages may be added at
the end of the notification :—
18. Kebhopur

-Keshopur - 31

19. Madipur

- Madipur

- 709

20. Khiala

- Khiala

- 48, 48/1 to 93.

R. BHARDWAJ, Deputy Commissioner,
Municipal Corporation of Delhi.

<!-- page 62 -->

1034

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[P/iKi II—SEC 3(ii)]

ANNEXURE ' C

ANNEXURE 'B'
DELHI GAZETTE

DELHI GAZETTE

DELHI ADMINISTRATION

EXTRAORDINARY
PART IV

No. 24 Delhi,Thursday, June 13,1963/Jyaistha23,1885
PART IV

No. 41 Delhi. Friday, Juno 3, 1966/Jyaistha 13, 1888

Notifications of Departments of the Delhi Administration
othor than notifications included in Part-I

DELHI ADMINISTRATION, DELHI
(Local-Self Government Department)

DELHI ADMINISTRATION

NOTIFICATIONS

(Municipal Corporation of Delhi)

Delhi, the 3rd June, 1966

NOTIFICATIONS

No. F. 2(49)/6S-LSG:—The following is published for general
information.

Delhi, the 23rd May, 1963

NOTIFICATION
No. RNZ/SZ6:—In exercise of the powers conferred by clause
(a) of section 507 of the Delhi Municipal Corporation Act,
1957 (66 of 1957) the Corporation, with the previous approval
of the Central Government, hereby declares that the following localities; mentioned in the Schedule given belowhitherto forming part of the rural areas, shall cease to be
rural areas:
SCHEDULE

s.

Name of Zone

No

J . Shihdara Zone

4.

5.
6
7.

Khureji Khas

Particulars of area
proposed to be
urbanised
The entire remaining area of the
said revenue estate
which has not so
far been urbanised.

-do-do-

Sadhora Khurd
Sadhora Kalan
Chaukri
Mubarakabad

-do-do-do-

-do•do-do-

Nemri
Dhaka
Salimpur
Majora Madipnr

-do-do-do-

Azadpur
Shakurpur
Madipirr
Khiala
Kcshopur
Qasaidaraptir
Najafgarh
Masudabad
Haibatpur
Mehrauli
Ladha Sarar
Khirki

-do-do-do-do-do-do-do-do-do-do-do-do-

2..' Civil Lines Zone

3

Nanie of the
revenue Estate

-do8.
-do9.
10. West Zone
-do11.
-do12.
-do13.
-do14.
-do15.
-do16.
17. South Zone
-do18
-do19.

Delhi, the 28th May, 1966
No. F.9(2)/6*-Law. Corp.:—In exercise of the powers conferred by clause (a) of Section 507 of the Delhi Municipal
Corporation Act, 1957 (66 of 1957) the Corporation, with the
previous approval of the Central Government, hereby declares
thit the following localities mentioned in the Schedule given
bslow, hithirto, forming part of the rural areas, shiill cease to
be rural areas :—
SCHEDULE
S. Name of the Zone Name of the
No.
revenue estate
1

3

4

I.

Khampur Raya

The entire remainin a area of the
said revenue estate which has
not so far been
urbanised

->

Shadipur
Naraina
Tatarpur
Chaukphandi
Tehar
Nangal Raya
Assalatpur
Possangipur
Nangli Jalab
Budhela

-do-do-do-do-do-do•do-do-do-do-

Kilokri
Bahlepur
Bhaddar
Kotla
Mubarakpur
Tamur Nagar
(Revenue Estate
ofKttofcri)
Khizrabad

-do-do-

1. West Delhi

3.
4.
5.
6.
7.
8.
9.
10.
11.

II. South Delhi
1.

3.
4.

Sd/- ILLEGIBLE
Commissioner,
Municipal Corporation of Delhi

2

Particulars of the
area proposed to
be urbanised

5.

-do-do-do-

<!-- page 63 -->

1035
1
6.

2

3

4

ITie entire remain.
Serai Juliana
ir.R area of the
(Revenue Estate
said revenue EsBahapur)
tate which has
not so far been
urbanised

1

2

lit. North Delhi
I.

Masihagarh
(Revenue
Estate
Bahapur)
Joga Bai
Okhia
Garhi Jharia
Maria

-do-

Zamrudpur
Masjid Moth
Shahpur Jat
Humayunpur
Kauz Khas
Yusuf Sarai
MohftmmadpuT

-do-do-do-do-do-do-do-

18.

Munlrlca (In
Revenue Estate
of Modhpur)

-do-

3.
4.

19,

Jaselfl
Madanpw Khadar
Tekhand
Sheikh Sarai
Begampur
Serai Shahji
Hauz Rani
Ad. chini
Kalu Serai
Ber Serai
Chiras Delhi
Katwaria
Serai

-do-

5.

7.

8.

9,
10.
Jl.
12.

13.
14.
15.
16.
17.

20.
21.
22.
23.
24.
25.
26.
2728.
29.
30.
31.
32.

33.
34.

Basant Nagar
Madangir
Badarpur

The entire remaining area of the
said revenue Estate which has
not so far been
urbanised.
-do-do-

Dhlrpur

Malikpur
3.

Rajpur
Chhawanl

-do-do-

4.

Bharola

-do-

5.

Peepal ThaU

-do-

6.

Rampura
(Revenue
Estate of
Shakurpur)
Wazirpur

-do-do-

-do-do-do-do-do-do-do-do^
-do-do-dO'

7.

-do-

IV. Shahdara Side
1.
2.

Kaitwara
Obonda

-do-

Mauzpur

-do-

Jilmila
Ttbirpttr
(Nazul)
Karkar Duman

-do-

-do-

-do-do-do-

35.

Kharara

'do-

36.

Arakpur Bagh
Mochi (Nazul)

-do-

Klshangarh
(In Revenue
Estate of
Mehrsuli)

-do-

38.

Khanpur (part)

-do-

39.

Tugiakabad

-do-

The entire area
except the village mbadl area
'which has already been declared urban vide
notification No. F
9/5/59-R&S,
dated 28-12-1959.
-doThe entire remaining area of the
said revenue Estate which has
cot so far been
urbanised.

7.

Selarnpur
Shahdara

8.

Ghondli

-do-

9.

Mandali
Fazalpur
Ghazipur

-do-

6.

-do-

Harinfigar
Ashram (In
Revenue
Estate of
Kilokri)

37.

3

10.

-do-

11.

Kachhlmpur

-do-

12.

Hasanpur

-do-

13.

Shakarpur
Khas
Saboli

-do-

14.

-do-

K. L. RATHEE,
Commissioner,
Municipal Corporation of Delhi
(F. NO. 23011/4/77-R.C.C]
R. P. SINGH Dy. Secy.

<!-- page 64 -->

1036

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PAKT II—SEC. 3(ii)]

New Delhi, the 17th March, 1979
S.O 1238.—In exercise of the powers conferred by Section
5 of the Administration of Evacuee Property Act, 1950 (XXXI
of 1950), the Central Government hereby appoints Shri
Dharam Vir, Deputy Secretary ui the Rehabilitation Department of the State Government of Haryana, as Assistant
Custodian General of Evacuee Property for the purpose of
discharging the duties imposed on such Assistant Custodian
General by or under the said Act. This supersedes the notification No. H8)/Spl. CeH/77-SS II dated 1-3-79.
|N6. 1(8)/Spl. Cell/77-SS. Il|
D. N. ASDA, Jt. Directw

MINISTRY OF SUPPLY AND REHABILITATION
(Department of Rehabilitation)
New Delhi, Ihc 17th March, 1979
S.O. 1237.—In exercise of the powers conferred on me as
Custodian General by sub-section (3) of Section 55 of the
Administration of Evacuee Property Act, 1950 (31 of 1950),
I do hereby delegate to the Assistant Custodian General for
the State of Haryana, appointed vide this Department's notification No. 1(8)/Spl. Cell/77-SS. 11, dated the 17th March
1979, the following powers of the Custodian General.
(i) Powers under Section 24 and 27 of Ihe Act
(il) Powers of approval of transfer of any evacuee property under Section 10(2) (O) of the Act.
(iii) Power of transfer of cases under Rule 30-A of the
Administration of Evacauec Property
(Central)
Rules, 1955.
This supersedes notification No. 1(8)/Spl. Cen/77-SS.II
dated 1-3-1979.
[No. l(8)/Spl. Cell/77-SS. II]
KAUSHAL KUMAR, Custodian General

MINISTRY OF COMMUNICATIONS
(P. & T. 3o«rd)
New Delhi, the 28th March, 1979
S.O. 1239.—In pursuance of para (a) of Section III of Rule
434 of Indian Telegraph Rules, r951, as introduced
by
S.O. No. 627 dated 8th March, 1960, the Director General,
Posts and Telegraphs, hereby specifies the 16th April, 1979
as thj© date on which the Measured Rate System will be
introduced in Mahe Telephone Exchange, Kerala Telecom.
Circle.
[No. 5-11/79-PHB]
R. C. KATARIA, Asstt. Director General (PHB)

<!-- page 65 -->

1037
New Delhi, the 31st March, 1979
S.O. 1240 In exercise of the powers conferred by subrale (2) ol rule <K clause (b) of sub-rule (2) of nife 12, and
sub-rule (11 of nilc 24 read with rule 34, of the Central
Civil Services
(Classification, Control and Appeal) Rules,
1965, the I1 esident hereby makes the following further amendments in the notification of the Government of India in the
Ministry of Communications
(Posts
and
Telegraphs)
No. S.R O. 620, dated the 28th February, 1967, namely :—
In the Schedule to the said notification —
(i) In Part II-p-General Central Service, Group 'C\ under
the heading "Railway Mail Office", against
the
eniry "Mail Guards", in columns 2 and 3 for the
existing entries "Inspector, Railway Mail Service"
the following entries shall be substituted, namely :—
"Inspector, Railway Mail Service/Assistant Superintendent, Railway Mail Service"' ;

Now, tneretore, in exercise oi trie poweTS conterrea oy section 7A and clause (d) of sub-scction(l) of section 10 of
the Industrial Disputes Act, 1947 (14 of 1947), the Central
Government hereby constittues an Industrial Tribunal of which
Shri C. L. Narasimha Rao shall be the Presiding Officer
with headquarters at Hyderabad and refers the said dispute
for adjudication to the said Tribunal.
SCHEDULE

(ii) In Part IH General Central Service, "Group D"
under the heading, "Railway Mail Service", against
the entry "All posts" in Columns 2 and 3 for the
existing entries, "Inspector, Railway Mair Service,
(in other offices and sections under his jjurisdiction)"
the following entries shall be substituted, namely: —
"Inspector, Railway Mail Srvice/Assistant Superintendent Railway Mail Service (in other offices and
sections under his jurisdiction)"

S.O. 1242 In pursuance of section 17 of the Industrial
Disputes Act, 1947 (14 of 1947), the Central Government
hereby publishes the following award of the Central Government Industrial Tribunal, Calcutta in the industrial dispute
between the employers in relation to the management of Life
Insurance Corporation of India, Calcutta and their workmen
which was received by the Central Government on the 26th
March, 1979.
CENTRAL GOVERNMENT INDUSTRIAL TRIBUNAL
CALCUTTA

[No. 153/1/78-Dlsc IT]
V. S, RAO, Asstt, Director General (Disc.)

Whether the action of the management of Singareni
Collieries Company Limited in dismissing
from
service Shri B. Narayana, Clerk, Godavan Khani
No 2A Incline with effct from lllh June, 1978 is
justified 7 If not, to what relief is the concerned
workman entitled ?
[F. No. L.21012(21)/78-D.IV(B)]
New Delhi, the 27Lh March, 1979

Reference No. 37 of 1»76
PARTIES:
Employers in relation to the Management of Life Insurance Corporation of India, Eastern Zone. Calcutta.
AND
Their Workmen.
APPEARANCES:
On behalf of Employers—Sri S. Sarkar, Advocate.
On behalf of Workmen—Sri D. L. Sen Gupta, Sr. Advocate, with Sri H. L. Roy, Advocate.
STATE : West Bengal.

INDUSTRY : Insurance.
AWARD

This is a reference under clause (d) of Subsection (1) of
Section 10 of the Industrial Disputes Act, 1947, referred to
this Tribunal for adjudication by the Government of India
vide Order No. L-17012(3)/76-D. IV(A), dated 23rd December.
1976. The material part of the order of reference is as
follows :
"Whether the penalty imposed on Shri Saroj Kiinnr
Chowdhury, Cashier, Serampore Branch Office of
the Life Insurance Corporation of India Vide Order
No. CDO/Pcrs/pP-7/74, dated the 31st lanuary,
1975 of the Senior Divisional Manager, Life Insurance Corporation of India, Calcutta is fair, just and
proper 7 If not, to what relief is the concerned
workman entitled 7"

MINISTRY OF LABOUR
ORDEK
New Delhi, the 12th March, 1979
S.O. 1241.—Whereas the Central Government is of opinion
that an industrial dispute exists between the employers in
relation to the management of Ramagundam Division No. 1
of the Singnreni Collieries Company Limited, Post Office
Godavari Khani, District Karimnagar (Andhra Pradesh) and
their workman in respect of the matters specified in the
Schedule hcieto annexed :
And whereas the Central Government considers it desirable
to refer the said dispute for adjudication ;
1367GI/78—9

2. At all material times the concerned workman was employed as a Cashier at the Serampore Branch Office of the
Life Insurance Corporation of India. On June 27, 1973 a
sum of Rs. 900 lying in his custody on the counter wain
taken away during the busy hours of the day by an outsider
who came to the counter on the plea of obtaining change
for a one hundred rupee note. The man entered from hi*hind. It was the pay day of the month and the Cashier
was busy. Tt is common case that the counter from which
he had to handle cash, did not have any enclosure. After
the incident had taken place the management has secured the
counter by an enclosure.
3. It is not in dispute that as a result of the Incident the
Life Insurance Corporation has lost a sum of Rs. 900 On
or about July 8, 1974 a chargesheet was served on the

<!-- page 66 -->

]038

THE GAZETTE OF TND1A : APRIL 14, 1979/CHAITRA 24, 190?

concerned workman. He was charged with failure to maintain
devotion to duty and gross negligence resulting in breach
of Regulation 21 of the Life Insurance Corporation of India
(Stnff Regulation). 1960. An enquiry was held. The Enquiry
Officer came to the conclusion that the concerned workman
should have been more cautious Hnd alert as Cashiers are
expected to be and that hk method of handling cash was
to some extent negligent, By an order dated January 31,
1975 the Senior Divisional Manager imposed on the concerned workman with immediate effect two penalties, namely,
(i) Recovery from his pay or such other amount as may be
due to him the sum of Rs. 900 in 15 equal monthly Instalments and (ii) Stepping down of his pay by one stage in the
time-scale. The above punishments were awarded under
Regulation 39fl)fc) and 32(l)(d) of the Staff Regulation 1960.
4. The propriety and validity of the aforesaid order were
sought to be assailed on behalf of the concerned workman.
The question was tried as a preliminary issue. By an Order
dated February S, 1979. T held that the enquiry proceedings
and the Report of the Enquiry Officer arc valid. A copy of
the said order is annexed hereto and marked with the letter
'A' as a part of this Award.
5. The Tribunal having held that the enquiry was properly
held, the learned advocate appearing on behn'f of the concerned workman has contended before me at the fina.1 hearina
that the punishment awarded to the concerned workman in
the circumstances of the case is so harsh and oppressive a*
to justify interference. He rei'cd on a Damage in the oftcited decision of the Supreme Court in Workmen v Firestone
Tyre Hud Rubber Company, 1973 T T.T.J 278, para 29 at
pagps 293 and 294 to which I shall advert presently
fi. On behalf of the management reliance was placed on the
decisions of the Supreme Court in East India Hold v. Their
workmen, reported in Supreme Court Labour Judgments 1974,
Volume 5, pnire 291. This judgment was delivered m Civil
Appeal No. 311 of 1973 on December 12, 1973. There P.
Jaganmohan Roddv, J, speaking for the Court observed :
"Once misconduct is proved^ either in the enquiry condieted by the employer or bv the evidence placed
brfore the Tribunal for the first time, the punishment imposed cannot be interfered with bv the Tribunal excent in cases where the punishment is harsh
and oppressive"
In the other case, namely. Management of M/s. Eastern
Electric and Trading Co., v. Baldev LPI. Supreme Court Labour
Judgments, 1975. Volume 12, pace 192, A. Alagiriswami, T.
relied on the statement of law in Firestone Tyre and Rubeer
Company's case which was expressed in these terms:
"Once the misconduct is proved either in the enautry
conducted by an empiover or by the evidence placed
before a trbunai for Ihe first time, punishment imposed cannot be interfered with by the tribunal
except in cases where the punishment is so harsh ns
to suggest victimisation."
The learned Judge also relied on the observations made (n
the case of Hind, Constn. and F.nsti. Co Ltd. v. Their workmen, 1965 T LTJ 462. There it was said,
"In respect of punishment for misconduct under the
standing orders, if any. is a matter for the rmnacement to flecMc and if th^re is any jurisdiction for
the punishment imposed, the tribunal should not Interfere The Tribunal is not required to consider
the propriety or ndrquacv of the mmi'hmcnr or whether it i" pxcrsiive or too severe. But where tlie
punishment <s shockingly disproportionate, regard being
had to the particular conduct and the past record
or is such. :^s no reasonable employer would ever
Impose in like circumstance."), the TribiTial mav treat
the irrmosition
of rnch punishment as itself showing
victim:tntion or unfair labour practice,"
7, On the ciucstinn of nnnishment, il h necessary to consider certain aspects of the case.
Tt was not in dl'-nute
that the concerned workman hfid an unblemished record of
service. Tt is nobody's case that he has ever been found negligent in the past irj the discharge of his duties. Moreover it is
leeifimnte to ronrlude on the basis of evidence that (he
management h^d been nec'ijrent in not providing the counter
with enclosure, thereby departing from established practice,

[PART II—SEC. 3<iM]

Had the management taken proper care and caution to make
the counter secure by providing it with an enclosure, the
incident could have been, in all probability avoided. It was
the pay day and the Cashier was working under great strain.
The Enquiry Officer has found that he should have been more
cautious and alert as Cashiers are expected to be and his
method of handling cash was to some extent negligent. He
has also pointed out in the concluding sentence of his Report
that he has been removed from the Cash Department with
effect from 24th July, 1974.
8. Two penalties have been imposed on the Cashier under
sub-clause (c) and sub-clause (d) of Clause 1 of Regulation
39 of the Staff Regulation, An order has been made for
recovery from the pay or such other amount as may be due
to him of the whole of tho pecuniary loss caused to the
Corporation by his negligence. An order has also been made
for reduction of his pay hy one stage in the time-scale. Tt
is true that (he Regulation 32 permits imposition of one or
more of the penalties for good and sufficient reasons. The
fact remains however that more than one penalty has been
imposed on the concerned workmen. Reduction of his pay
bv one stage in the time-scale will havo a permanent impact
in the shap of reduced wage packet in salary, dearness allowance and other emoluments, Tt ranks high in (he scale of
penalties. I do not propose to interfere with Ihe penalty directing recovery of the loss from the concerned workman. But I
•do feel (hnt having regard to the facts and circumstances of
the ense, his past record of service, the fact (hat the management failed in its duty to take proper precaution by securing
the counter with an enclosure, and the finding of negligence
by the Enquiry Officer in guarded language, the penalty imposed under sub-clause (d) of clause (1) of Regulation 39 i-too harsh, oppressive and grossly disproportionate,
9. Learned advocate appearing on behalf of the management
submitted, that recovery of the loss from the concerned workman is not a penally at all. He claimed that it is in fhc nature
of recovery of an indemnity or compensation, He may be
right on general grounds but in the contemplation of the
Staff Regulations, recovery of the pecuniary loss caused to
the Corporation by negligence is a penalty and therefore must
be treated as one for the purpose of this case.
10. Mr. Sen Gupta relied on Presidency Talkies v Natarafan,
a decision of the Madras High Court reported in ATR 1969
Madras 121 and Bhasknr Textiles Mills Ltd. v Presiding Officer. Industrial Tribunal reported in 1975 LLJ (1) 79. On the
basis of these decisions he submitted that as the negligence in
the present case was not deliberate, no misconduct was committed bv the concerned workman. I do not think thin c-nntenrion has any relevance. Regulation 39 (1) Ccl speaks of pecuniary loss caused to the Corporation by negligence. The concerned workman has been found negligent in the discharge of
his duties and Regulation 39 O) (c) has been rightly attracted.
11. f now proceed to answer the questions raised by the
Order of Reference as follows : The penalty imposed on Sri
Saro) Kumar Chowdhury, Cashier, Serampore Branch, Office
of Life Insurance Corporation of Tndia by (he order dated
January 31, 1975 of the Senior Divisional Manager, Life Insurance Corporation of India is fair, just and proper as regards the
recovery from his pay or such other amount as may be duo
to him of a sum of Rs. 900 in 15 equal instalments As regards
the other penally imposed under the said order by stepping
down his p'iv by one >fage in the time-scale, T hold that the
same is not just, fair and norper. No effect will he given to
that part of Ihe order of the : Senior Divisional Manager, Life
Insurance Corporation of Ind a, Calcutta by which the pay of
the concerned workman was stepped down hy one slaee in
the time-scale. The concerned workman will be entitled to
salary, dearness allowance and nil other allowances, benefits and
advantages to which he would have been entitled had the said
penalty never been imposed on him under <hc ordiT,
This is my Award.
Dated. Calcutta, The 21st March, 1979.
S. K. MUKHERJEA. Presiding Officer

<!-- page 67 -->

1039
ANNEXURE 'A'
CENTRAL GOVERNMENT INDUSTRIAL TRIBUNAL
CALCUTTA
Reference No. 37 o£ 1976
PARTIES :
Employers; in relation to ihe management of Life Insurance Corporation of India, Eastern Zone, Calcutta.
And
Their Workman
APPEARANCES:
On behalf of Employee—Shri S. Sarkar, Advocate.
On behalf of Workmen-—Sri D. L. Sen Gupta, Sr. Advocate, with Sri 11. L. Roy, Advocate.
Workmen.
State : West Bengal

Industry : Insurance.
ORDER

This reference is undei clause (d) of sub-section (11 of Seclion 10 of the Industrial Disputes Act, 1947. It Involves the
question of justification of imposition of penalty on a cashier
in the employment of the Life Insurance Corporation
of India
nt its branch office at Sernmpore. The order1 of reference
reads as follows :
"Whether the penalty imposed on Sri Suroj Kumar Chowdhury, Cashier, Serampore Branch Office of the Life
Insurance Corporation of India Vide Order No. COO/
Pers/DP-7/74 dated the 31st January, 1975 of the
Senior Divisional Manager, Life Insurance Corpoiation of India, C-alcutu is fair, just and proper
If not, to what relief is Ihe concerned workman entitled '!"
2. flic concerned Turkman v\as tmpioyed at all material
times m a cashier at the Serampore Branch office of the Life
Insurance Corporation of India. The case as disclose*! in the
pleading filed on hit. behalf by the Union appears to be that
on June 27. 1973 a sum of Rs. 9000 lying in his custody was
snatched away at a busy hour of the day from, the counter by
;in outsider who came on the plea of obtaining change for n
one hundred rupee note, It is stated that the man entered from
behind. It was the pay day of the month and the cashier was very
busy The cashier, it is common case, had to handle cash ai a
counter uhieh did not have any enclosure. As soon as the
amount was stolen the theft was discovered, a due and cry
was raised and the man was chased by the employees. The
man could not however be apprehended. Thereafter on or about
Inly 8. 1974 more than one year after the incident, a char£«
sheet was served on the concerned workman. The charge was
as follows :
"You, Sri Saroj Kumar Chowdhury, S. R. No, 5456 working as ;i Casrrer in our Scrampore Branch offici. arc
hereby charged for the following offences '•
That you failed to maintain devotion to duty in discharg inir your dutv :is :t Cashier ns evident from the fact
that n sum of Rs. 900 (Rupees nine hundred) only
wai found missing from vour
custody on the
27th June, 1973 at about 1.50 P.M.
Your above act amounted lo gioss negligence and serious
offlence and this constituted breach of Regulation 21
of the I ifc Insurance Corporation of India (Staff)
Regulation, i960 and for that you are liable to be
punished under Regulation 39 of the LIC (Staff) Rcculations. 1960."

Cash Counter of the Serampore Branch Office, a man
suddenly entered inside the counter and stood on the
right side of my chair. When the said intiudcr was
challenged by me, he asked for an encashment of a
hundred rupee note which I refused and asked him
to go out of the counter. The man left the place hurriedly. On my turning to the leit, the 10 rupee bundle
from which the payment was being made to my surprise, was tound missing from the table. From the
conduct and demeanour of the said intruder 1 could
take it conclusively that taking advantage of my attention being diverted to him the said intruder could
manage to take the whole bundle of that 10 rupee
notes from my table and made good his escape so
hurriedly. Immediately after the incident I raised a
hue and cry and chased the said man with some of my
colleagues but he was able to decamp with tie money
before we could make any effective attempt to catch
hold of him. We could, however, gather from the
Rikshawalla at that gale thut 3/4 persons carne out
from the Office in a suspicious manner und hurriedly
went towards the Station by Rikshaws. Thereafter I
reported the matter to the Branch Manager who closed the Cash Box in my presence and asked me and
some of my colleagues to go to the Station and search
for the suspected man if he could be traced there.
At the instance of the Branch Manager, I along with
some of my colleagues went to the station and searched for the
suspected man but could not trace him
there. Pot1 this purpose we were allowed to utilise the
A. B. M's car. 1 came to the office and reported the
matter to the Branch Manager. The Branch Manager
then counted the Cash when Rs. 900 was found to be
short. At the close of the Office cash was closed on
the basis that Rs. 900 was stolen from the counter. I
then at the instance of B. M. :went to the Local Thana
and lodged a complaint stat ng the facts in details.
Since then various enquiries were made and it was
clearly ascertained and established that a sum of
Rs. 900 was stolen by the said intruder who could
enter Into the cash counter because there was no sufficient protection to Btop access of the outsiders to thu
Cash Counter. The amount could have been stolen
from my table by the intruder not due to any fault
of my part but evidently for want off protection as
should have been provided by the proper authorities."
4. Thereafter an enquiry was held by Mr. S. N, Dutta. At
the enquiry, the concerned workman made a statement. Evidence was also given by Svs. A. K. Ganguly, Sachipriya
Mukherjee, Agent, A. S. Bhattacharjee, Branch
Manager,
Serampore, Monotosh Chatterjee, Cashier and by Naresh
Chandra Sinha, Cashier, Harendra Kr. Paul, Cashier, Dipak Kr.
Chakravorty, Asokc Kr, Mukherjee and A. K. Dutta. By common consent, statements made in writing by certain persons
were accepted as statements made before the Enquiry Officer,
5. The Enquiiy Officer came to the conclusion that the
concerned workman should have been more cautious and alert
as cashiers are expected to be and that his method of handling
cash was to some extent negligent. The Enquiry Officer submitted his Report to the Senior Divisional Manager, Life Insurance Corporation of India on or about 28th October, 1974.
There after the management proposed imposition of certain
penalties by a notice dated 11th November, 1974. The concerned workman made representations in reply to the said notice.
The Senior Divisional Manager not being satisfied with the
representations, by an order on 31st January, 1975 imposed on
the concerned workman with immediate effect under Regulation
39 (1) (c) and 39 (1) (d) (Staff) Regulation, 1960 two r*nalt;es,
namely, 0) recovery from his pay or such other amount as
may be due to him, the sum of Rs, 900 in 15 equal instalments
nnd (ii) stepping down of his pay by one stage in the time-scale.

3. The concerned workman filed a reply in answer to the
charge sheet on August 3, 1974. He refuted Ihe charge and
narrated the incident in these terms :

6. The present reference involves consideration of the propriety of the aforesaid order. Mr. D. L. Sen Gupta appearing
on behnif of the concerned workman questioned the validity
of the enquiry proceedings, The pn-ties agreed that the Tribunal should, in the first instance, decide the validity of the encruiry. I therefore propose to deal with the question of vaTidity of the enquiry as a preliminary issue,

"On or about 27th June at nboul 1.50 p.m. while in course
of my normal duties I was making paymen in the

7. Mr. Sen Gurjta sought to assnil the enquiry proceedings
and the Keporf made by the Enquiry Officer on a variety of
grounds. The Fnquiry Officer, he submitted, did not serve any

<!-- page 68 -->

1040

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

notice on the management to produce evidence; he cast ihe
burden of proof on the delinquent ; he combined in himself
the role of the prosecutor, judge and witness; he imported
personal knowledge of matters which are not on record in arriving a.t his conclusion ; he did not base his conclusion on
the evidence on recorded but gave his finding contrary to evidence was biased in deciding the case ; moreover the charge
of failure to maintain devotion to duty is too vague. In the
result, Mr. Sen Gupta submitted, the finding that the concerned workman was negligent in the performance of his
duties is perverse.
8. The Enquiry Officer gave evidence before me. The original notice intimating tho date of commencement of the enquiry was served on the delinquent. He intimated to the
management the date of commencement of the proceedings by
sending a copy of the notice which was served on the delinquent. He did not summon the management to give evidence.
It appears that although the management was not given a separate notice, due intimation of the commencement of the enquiry
was received by them in the shape of the copy of the notice
served on the delinquent.1 It was for the management to choose
what evidence, if any, they should have adduced. The Enquiry
Officer summoned Mr. A. S, Bhattacharya, the Manager of
Serampore Branch. He was free to decide whether he should
summon any witness or not, otn his own. In any event, the
management hus made no grievance of the fact that no separate
intimation of the commencement of the proceedings was given
to them by the Enquiry Officer. I am therefore unable to hold
that by reason of a separate intimation not having been given
to the management of the date of enquiry, the enquiry proceedings were vitiated.
9. Mr. Sen Gupta contended that the Enquiry Officer wrongly cast the burden of proof on the delinquent. As far us 1 can
see, what he really means is that the Enquiry Officer was not
justified in holding ihe opinion that the delinquent was not at
the relevant moment making any payment to any person, on
the ground that if it were otKerwise, the delinquent would
have certainly produced the person to whom payment WHS
being made. The attitude expressed in the said opinion does
not, In my opinion, militate against the presumption of innocence or throw the initial burden of proof on the delinquent,
Facts which are peculiarly within the knowledge of tha delinquent had to be established. The loss is admitted. After all, if
the delinquent was making payment at the relevant moment, it
is not to be expected of tie management to prove that he was
not making any payment. Whether he was making payment or
not was a fact pecu'iarly w'thin the knowledge of the delinquent and it is for the delinquent to substantiate his contention
by disclosing the name of the person to whom payment was
being made and by evidence of that person prove the fact of
payment. I do not consider It unreasonable on- the part of the
Enquiry Officer to expect the delinquent to produce the pfr'on
to whom he was making payment in support of the case that
he was busy in making payment at (he time wh«n the Incident
took place In Firestone Tyre and Rubber Company Ltd. v
Their workmen, 1967 LLJ II 715, SC, Hidayatullah, J. delivering the judgement of the Court observed :
" ....reliance was placed on 1963—11 LL. J, 367, 392,
396 and 452. These cases no doubt lay down that
before a delinquent is asked anything, all the evidenre
against him must be led. This cannot be an invariable rule in all cases. The situation is different
where the accusation is based on a matter of record
or the facts are admitted. In such a case it may
be permissible to draw the attention of the delinquent to the a nevidence
on the record which goes
ajta'nst hi"! ( i which if he cannot satisfactorily
explain must lead to a conclusion of guilt
It
Is all a question of justice and fairplay."
10. Mr. Sen Gupta relied on the case of Associated Cement
Company v. Their Workmen, 1963 LTJ II 396, and contended
that the Enquiry Officer had imported his personal knowledge
In arriving at his conclusion and on that ground his Report
should be rejected. The Enquiry Officer stated in his Report,
"Even if Shri Chowdhury was making a payment to any
person he, as a cashier, should have taken out the reo'ujsite
number of notes from the bundle and put the remaining
bundle of notes in the drawer and not left the same on the
counter". Elsewhere in the Report he said, "The bundle of
notes were kept or» the table instead of in the drawer or

[PAKT II—SEC. 3(11)]

cash-box and that Sri Chowdhury had temporarily allowed his
attention to be diverted", Mr, Sen Gupta contended that
there was no evidence that there was any drawer or any
cash box where the bundle of notes could be kept and the
view taken by the Enquiry Officer that the bundle of note?
should have been kept in the drawer or in the cash box Is
based on conjecture. He was importing his personal knowledge of the existence of lrawers or cash box. The Enquiry
Officer appears to have thought that only the requisite number
of notes should have been put on the table for making individual payments. For making payments in succession, a bundle
of notes or a large number of notes should not have been
deposited on the table. It was not suggested specifically to
Ihe Enquiry Officer in cross-examination that there was no
drawer or cash box at the disposal of the delinquent. In
any event, it h not unreasonable to infer that there were
either drawers or a cash box where the bundle of notes could
have been kept. Though the Enquiry Officer did not specifically ask at the cnqkiiry whether the delinquent had access
to drawers or cash box, he relied, as he said, on th« general
practice prevailing in Life Insurance Offices. At all events,
if there were no drawers or cash box, the cashier, having
regard to the risk involved, should have, in my opinion,
asked the management lo provide him with a cash box.
U. It was pointed out by Mr. Sen Gupta that there was
evidence in the annexure to the Enquiry Report that on the
date of occurrence, the delinquent made 45 salary payments
and 18 non-salary payments. It was also deposed by Sri
Sachipriya Mukherjce that Sri Chowdhmy was busy. The
receiving counter, he said, was very busy on that day. He
submitted that having regard to that evidence, the Enquiry
Officer ought to have held that at the rime of occurrence of
the incident the delinquent was busy in the act of making
payments. The Enquiry Officer concerned himself with the
question, how the delinquent was engaged at the time when
the incident actually took place. It was submitted that by
placing the burden of proof on the delinquent the Enquiry
Officer disclosed bias against the delinquent. As I have held,
the initial burden of proof was not placed on the delinquent
As the defence was thnt he was busy in the act of making
payments, it was not unreasonable to expect him to produce
evidence on the question of fact of payment at the relevant
point of time. I am unable to hold that any bias on tho
part of the Enquiry Officer has been established.
12. It was then contended that the delinquent did not have
knowledge of the evidence against him. Mr. Sen Gupta relied
on the case of Meenglass Tea Estate v. Its Workmen, 1963
LLJ II, 392 (S. C.) where Hidayauallah , J,, observed In
course of the judgment:
"

. .The enquiry consisted of putting questions to each
workman in turn. No witness was examined in support of the charge before the workman was question
ed. It is an elementary principle that a person who is
required to answer a charge must know not only the
accusation but also the testimony by which th« accusations is supported. He must be given a fair chance
to hear the evidence in support of the charge and to
put such relevant questions by way of cross-examination as he desires.

In this case the loss of Rs. 900 by theft is not in dispute
That the money was lost from the custody of the delinquent
is also admitted. The evidence was given by the delinquent himself and persons who were invited by him to depose on the
circumstances in which the lass took place. Tho management
did not produce any witness and no question of cross-examination could possibly arise. The Enquiry Officer assessed the
evidence placed before him and came to the conclusion he did.
13, The charge brought against the delinquent was that he
had failed to maintain devotion to duty as a cashier as evident
from the fact that a sum of Rs, 900 was found missing from
his custody. As I have snid before, whether delinquent was
negligent or not wonld depend on the facts and circumstances
in which the loss took place and as those were peculiarly within
the knowledge of the delinquent, it was for him to establish
that the loss of money took place from his custody in circumstances over which he had reasonably no control. It Is, therefore, immaterial whether the management adduced any evidence
or not. In any event, there is no evidence against the delinquent of which the delinquent may be said to have had no
knowledge

<!-- page 69 -->

1041
14. It was contended that the charge was vague. Regulation
No. 21 of the Life Insurance Corporation (Staff) Regulation
provides that every employee of the Corporation shall at all
times maintain absolute integrity and devotion to duty. The
delinquent was a cashier. His responsibilities are to be found
in the relevant Manual. If he failed to exercise the requisite
quantum of care commensurate with the responsibilities of his
office, he would be failing in devotion to duty. In my opinion,
it will be unreasonable to hold that failuie to maintain devotion to duty is a charge too vague to answer.
15. Mr. Sen Gupta submitted that in construing the statement made by the delinquent that the introuder managed to
make away with the bundle of ten rupee notes from table
while his attention was diverted to a man who had suddenly
entered inside the counter as an admission of negligence, the
Enquiry Officer acted perversely inasmuch as normally such
diversion of attention is only to expected his contention which
is a little out of context, is hardly tenable. Having regard to
the nature of his duties, a cashier while he is disbursing cash
ought to exercise utmost care and caution and mainta'n a high
degree of composure.
16. The Enquiiy RepoLl is to be read as ,i whole. "I he Enquiry Officer has, in my opinion, given cogenl reasons for his
findings, It is not necessary for the Tribunal to agiee wuh him
on all points. All that is necessary is to ascertain whether hi?
conclusions are such as could reasonably be drawn under the
facts and circumstances of the case having due regard to the
materials on record. It will not be fair to dismiss the finding1;
of the Enquiry Officer as perverse.
17. In the case of K. L. Shinde vs State of Mysore. AIR
1976 SC 1080, the Supreme Court laid down that departmental
proceedings do not stand on the same footing as criminal prosecution in which a high degree of proof is required. Departmental proceedings are not strictly governed by the rules of
evidence as contained in the Evidence Act. The learned
Advocate appearing on behalf of the management relied on
the case of Tata Engineering and Locomotive Co., Ltd. v
Prasad, 1969 LLJ'TI, 799 and submitted that a tribunal ought
not to be hypercritical in its attitude to a domestic enquiry.
Having regard to the evidence of the Enquiry Officer and the
materials on record, I am satisfied that the enquiry was fairly
and properly held and the Enquiry Report does not suffer from
any infirmity.'
18. Tn that view of the matter, I hold that the enquiry
proceedings and the Report of the Enquiry Officer are valid.
• The case is posted for hearing on 14th March, 1979.
Dated 8-2-79.
S. K. MUKHERJEA, Presiding Officer
[No. L-17012 (3)/76-D, IV fA)]

New Delhi, tie 2nd April, 1979
S.O. 1243.—In pursuance of section 17 of the Industrial Disputes Act, 1947 fl4 of 1947). the Central Government hereby
publishes the following award of the Central Government
Industrial Tribunal, Calcutta in the industrial dispute between
the employers in relation to the management of Calcutta Port
Trust, Calcutta and their workmen which WHS received by ihe
Central Government on 2nd April, 1979.
CENTRAL GOVERNMENT INDUSTRIAL TRIBUNAL •
CALCUTTA
Reference No. 18 of 1977
PARTIES :
Employers in relation to the management of Calcutta
Port Trust, Calcutta,
AND
Their Workmen
APPEARANCES :
On behalf of Employers—Sri D. K Mukherjc,:. 1 aboui
Officer.

On behalf of Workmen—Sri K. K. Roy Ganguly, Jt.
Secretary, Calcutta Port and Shore Mazdoor Union.
STATE : West Bengal.

INDUSTRY : Po.t &. Dock.
AWARD

By an order of reference made under clause fdj of Subsection (1) of Section 10 of the Industrial Disputes Act, 1947
an industrial dispute was referred to this Tribunal for adjudication by the Government of India, Ministry of Labour, vide
Order No. L-32012 (8>/76-D. IV (A) dated 15lh June, 1977.
The reference reads ;
"Whether the management in relation to Calcutta Port
Trust, Calcutta are justified is not giving one promotional increment lo Survaslm Byomkesh
Nanda,
Abdul Rashid, Kalipuda Mondal and Sudan Ch.
Uhughu, Lift Drivers, from the dates ol their piomotion ? If not to what relief are the concerned
workmen entitled ?"
2. For the efficient control, management and administration
of the affairs of the Calcutta Port Tru^, the Trust, maintains
a number of departments. The Chief Mechanical Engineers
Department is one of these departments. The head of the Department is the Chief Mechanical Engineer.
3. The Chief Mechanical Engineer's department has been
divided into a number of sections and unit". One of the sections is known as G R.J. and N.S.D. section, lu the said section
various types of cargo handling equipments viz,. Cranes, Lifts
and other contrivances have been installed for the purpose ot
handling cargo. For operation and maintenance of these equipment different categories of employees, viz., Unskilled tabour,
Crane Khalasis, Lift Drivers and Crane Drivers are employed.
In any Crane Section, such as N.S.D. and G.R.J. Section, normally recruitment is made at the lowest category i.e. unskilled
labour. Unskilled labour arc considered for promotion to the
post of Crane Khalasy/Lift Driver and Crane Khaiasy/Llft
Drivers are considered foi promotion to the post of Crane
Drivers.
4. The concerned workmen were appointed as unskilled
labour under the Calcutta Port Trust in the sixties. JT bey were
subsequently promoted to the post of Crane Khalasi in the pay
scale of Rs. 80-1-85-2-95-EB-3-110 in accordance with their
seniority after they had passed an appropriate suitability test.
5. In the year 1975 vacancies arose in the post of Lift
Driver in the said section and the concerned workmen were
appointed or promoted to the posts of Lift Driver, in the pay
scale of Rs. 115-3-136-4-14Q-EB-4-160 on the basis of their
(seniority after they had passed an appropriate suitability test.
6. It is contended by the Port Tru*t that the placement
of the concerned workmen in the post of Lift Driver was not
a case of promotion but an adjustment by Material movement.
I shall presently indicate the basis of that contention. The
concerned workmen contend that the post of Lift Driver is
a promotional post from the post of a crane khalasi. They
also contend that the post of a lift Driver involves greater
skill and responsibilities then that of a crane khalasi
7. It is not in dispute that upto 31st December, 1968 the pay
scale of crane khalisis used to be Rs. 8O-1-85-2-96-EB-3-11O
and that of lift drivers used to be Rs. 85-2-95-3-1 ]0. Thereafter
the pay scales of the abe^e categories were determined according to the recommendations of the Central Wage Board for
port and Dock Workers. Thoso recommendations became
effective from 1st January, 1969. Prior to the implementation
of the recommendations of the Wage Board their were 12
scales of pay for clajn TV employees in the major Poits of
India. The Wage Board ununimou'-ly decided thai 12 pay
scales for class IV employees be reduced to four and that the
then scales should be clubbed in the manner prescribed by
the Wage Board in paragraphs 7.2.11 and 7.2.12 of their recommendations,
8. According to the unanimous recommendations of the
Wage Board as accepted by. the Government, pay scales of
the Crane khalasis and Lift Driven were elubbed together and
they were allotted a common scale of Rs. 115-3-136-4-140-EB4-160, Similarly many other pay scales of class IV employees
having small variations were clubbed together find given one
or other of the four scales. As a result some promotional posts
were elubbed with posts in lower grades,

<!-- page 70 -->

1042

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

9. It will therefore bo seen that at the timo when the concerned workmen were placed in the post of Lift Driver the
pay scales OL Crane khalasis and of Lift drivers were identical.
10. It has been pointed out by the Union in paragraph 8
of their written statement that prior to the implementation o(
the recommendations of the Central Wage Board for Major
Ports in India the scale of pay of Lift Driver was always different from that of Crane Khalasi and the post of Lift driver
>vas always considered as the promotional post from the post
of Crane Khakm. Accordingly promotional increment, in
accordance with- Fundamental Rule 22C was always extended
to the incumbent promoted to the post of Lift drievr from
Crane Khalasi. This h:is not been disputed by the management.
In fact, in a letter dined lune 3, 1976 addressed to the Asstt
Labour Commissioner, Central by (he Labour Advisor and
Indusrial Relations Olliccr, which has been made Ext. W-l by
consent of parties, it was stated :
"Furthermore, it may be stated that piioi to levision ot
scales of pay by Wage Board the scale of pay of
Crane Khalasi was Rs. 80—110 and of Lift Driver
wus Rs. 85—110. After revision, both scales are identical i.e., Rs. 115—160. As the starting of Lid
Driver's scale was higher than that of Crane Khalnsi
prior to revision of scale of pay by Wage Board, the
post of Life Driver was considered to be a promotional post for Crane Khalasi. However, it was always
considered necessmy that Crane Khalasi must have
working knowledge of Lift Driving for promotion
to the posL of Crane Driver. The posts of Lift
drivel are tiled up on the basis of seniority-cum
suitability. A nominal test is held while adjusting a
OMIO Khalasi against the post of Lift Driver. Birt
it is essential lhat he obtains a certiiicate of Lift
Driving issued by the Lift Inspector, Government
of West Bengal."
11. I may refer to Rule 22-C of the Fundamental Rule?
and the proviso thereto which are relevant for determination
of the present dispute :
"F. R. 22-O. Notwithstanding anything coiutined in these
Rules, whetc a Government servant lulding a post
in a substantive, temporary or cfficiaiins capacity to
another post carrying duties and responsibilities of
greater importance than those aiUiLUing to the poit
held by him, his initial pay in the time-scale of the
higher post shall be fixed at the stage next above
the pay notionally arrived at by increasing his pay
in respect of the lower post by onfr increment at
the stage at which such pay has accrued.
+ ***
••**
**«•>!•
Provided that if Government servant either:
(i) has previously held substantively or officiated in :—
(1) *»*
(li) *•*
(iii) a permanent post other than a tenure post or
temporary post (including a post in a body, incorporated or not, which is whollp or substantially
owned or controlled by the Government on an
Identical time-scale; or
(li) is appointed substantively to a tenure post on a time
scale, identifical with that of another tenure post
which he has previously held substuntively or in
which he has previously officiated; then proviso to
F.R. 22 shall apply in the matter of the initial
fixatiun of pay and counting of previous service for
increment,"
12- The first question which arises is whether the post of
lift driver carries duties and responsibilities of greater importance than those attaching to the post held by a franc Khalnsi.
In paragraph 15 of the management's written statement the
minimum qualificatins of a lift driver and a Crane Khalasi
have been specified. What has not been stated there is that a
lift driver must hold a certificate of eligibility from the Stale
Government. On a consideration of the minimum qualifications required of H Crane Khalasi and a lift driver, the fact
that the lift driver must in addition to other qualifications

[PAST K—SEC. 3(ii)T

hold a certificate of eligibility, and having regaid to the fact
that the post of a lift driver was considered to be a promotional pust for a Crune Khalasi and the pay scale of lift
driver was better than the puy scale of Crane khalasi, 1 have
no hesitation in coming to the conclusion that the post of a
lift driver carries duties and responsibilities of greater importance than those attaching to the post held by a Crane Khalasi.
13. There is no dispute that the concerned Crane Khalasis
held the post of Crane Khalasi in a substantive capacity and
have been promoted or appointed in a substantive capacity
to the post of lift drivers. It may also be accepted that the
post of lift driver which carries duties and responsibilities
of greater importance and which has been regarded as a
promotional post is a higher post m the contemplation of
1-uudamenlul Kulc 22-C. The question now arises whether
the initial pay of the concerned workmen should be hxed
at the suige next above the pay notionally arrived at by
increasing the pay in respect ot lower post by one increment
at the stage at which such pay has accured. li is argued on
behajf of the concerned workmen that having regard to the
provisions of F.R. 2-C the answer ij, in the affirmative or
in other words they are entitled to one promotional increment with effect from the dates of their promotion.
J4. 1 have stated that at the material time th« pay-scales
of the post of Crane Khalasi and of Lift driver were identical.
Fundamental Rule 22 provides:
"F.R. 22. The initial subsantive pay of a Government
seivant who is appointed substantively to a posts on
a time-scale of pay is regulated as follows :
(a) If he holds a lien on a permanent post other than
a tenure post, or would hold a lien on such a
post had his lien not been suspended :
fi) When an appointment to the new post involves
the assumption or duties or responsibilities of
greater importance as interpreted tor the purpose
of Rule 30 than those attaching to such permanent post, he will draw as, inital pay the stage
of the time-scale next above his substantive pay
in respect of the old post.
• * +*

¥¥**

4*4< +

Provided, both in cases covered by clause (a) and in
cases, other than cases of re-employment after resignation or removal or dismissal from the public service, covered by clause (b) that if he tMlber :—
(lj has previously held substantively or officiated in—
(ii) a permanent or tempoiary post in the same timescale, or
(Hi) a permanent post other than a tenme post or a
temporary post (including a post m a body, incorporated or not, which is wholly ot substantially owned or controlled by the Government)
on an identical time scale ; or
a ) +**•
then the initial pay shull not, except in cases ot
reversion to parent cadre governed by proviso
(lKiii), be less than the puy other than special
pay, personal pay or emoluments classed as pay
by the President under Rule lJ(21)u)(i;i) which
he diew on the last occasion, and he shall count
the period during which he drew that pay on
such last and any previous occasions for increment in the stage of the time-scale equivalent
to that pay.***"
1 have pomtedoiit Hurt the pay scales of the post of Crane
Khalasi and Lift Driver were at the material time and still
aic identifical. Fundamental Rule 31(b) define-, id-nfical timestralcs as follows :
"(31)(b) Time-scale are snid to be identical if the minimum, the period of increment and the rnte of increment of the time-scales are identical."
In f;ict there « no dispute that the two ponts have identical
t;nie-scale. Incidentally it may b£ pointed out that 'time-

<!-- page 71 -->

1043
scale of pay' has been defined in Fundamental Rule 3 Km to
mean pay which, subject to any condition prescribed in thp°e
rules, rises for a periodical increments from a. minimum lo
a maximum.
15. I have set out the relevant portions of the last pioviwi
to Fundamental Rule 22-C. The concerned woikmen haj
previously held substaniivcly permanent posts that is to say,
the post of Crane khalasi on u time-scale identical with ihe
time-scale of the post of Lift Driver. In ihoic circumstance*
the relevant proviso to Fundamental Rule 22-C Ls applicable
In the matter of initial fixation of pay and counting of previous service for increment.
16. It seems to me that so long as the pay scale of the
post lift dri'fcr was higher or better than that of Crane
khalasi the piomotional increment was available to Crane
khalasis under Fundamental Rule 22-C on their appointment
or promotion to the post of Lift Driver. With the two timescales of pay becoming identical, the proviso to Fundamental
Rule 22 became applicable and the promotional Increment
Which was payable under Fundamental Rule 12-C so long
as the pay-scales were not identical, were no longer available
having regard to the proviso to F.R. 22. On an anxious
consideration of th« proviso to Fundamental Rule 22-C,
Rule 22 and Ihe relevant proviso thereto, I am unable to
hold that a promotional increment is due to the concerned
workmen who have been promoted or appointed to the posts
of lift driver.
17. Tn Ihe view 1 have taken. T answer the reference us
follows :
The management in relation to the Calcutta Port Trust
Calcutta are justified in not giving one promotional
Increment to Sarvashri Byotnkesh Nmda, Abdul
Rashid, Kalipada Mondal and Sudan Ch. Ohughu.
Lift Drivers from the dates of their promotion. They
are not entitled to any relief.
This Is my Award.
Dated, Calcutta,
The 26th March, 1979.
S. K. MUKHERJEA, Presiding Officei
TNo. L-32012(8)/76-D.]V(A)J
NAND LAt. Desk Officer

<!-- page 72 -->

1044

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

[PART II—Stc. 3(ii)]

7. The employer shall display on the notice board of the
establishment a copy of the rules of the provident fund as approved by the Central Government and as and when amended,
Ihe amendments thereto, alongwith a translation of Ihc sniient
points thereof, in the language of the majority of the employees.

New Delhi, (he 29th March, 1979
S.O, 1244.—Whereas M/s Neyveli Lignite Corporation
Limited (hereinafter refencd lo as ihc said establishment)
has applied for exemption lo iu lignite mines ai Neyveli in
the State of Tamil Nadu under clause (a) of sub-section flj
of section 17 of the Employees' Provident Funds and Miscellaneous Provisions Act, 1952 (19 of 1952) (hereinafter referred to os the said Act);
And whereas in the opinion of the Central Government,
the rules of the provident fund of the said establishment
with respect to the rates of contribution are not less favourable to the employees therein than those specified in section
6 of the said Act, and the employees are also in enjoyment
of other provident fund benefits which on the whole are
not less favourable to the employees than the benefits provided under the said Act or under the Employees' Provident
Funds Scheme, 1952 (hereinafter referred lo as the suid
Scheme) in relation to the employees in any other establishment of a similar character ;
Now. therefore, in exercise of the powers conferred by
clause fa) of sub-section (1) of section 17 of the said Act,
and subject to the conditions specified in the Schedule annexed hereto, the Central Government hereby exempts Ihc
lignite mines of the said establishment from the operation of
all the provisions of the said Scheme.
This notification shall be deemed to have come info forcr
with effect the filh January, 1979.
SCHEDULE
The employer in relation, to the said establishment shall
provide for such facilities for inspection and pay such Inspection charges as the Central Government may, from time
to time, direct under clause (a) of sub-section (3) of section
17 of the Employees' Provident Funds and Miscellaneous
Provisions Act, 1952, within 15 days from the close of evorv
month,
2. The employer, in relation to the said establishment,
fi) shall comply with the directions issued by Ihe Central
Government, from time to time, under clause (d) at
sub-section f3) of section 17 of the said Act In regard
to the investment of contribution to the provident
fund of the said establishment (hereinafter referred
to as provident fund);
(ii) shall take due care to see that the Board of Trusteesconstituted in respect of that establishment invest
the provident fund contributions in accordance with
the directions issued by the Central Government,
from time to time, and shall be responsible for such
investment of the provident fund contributions by the
said Bonrd of Trustees.
3. The employer shall submit such returns lo the Regional
Provident Fund Commissioner as the Central Government may,
from time to time, direct.
4. The employer shall furnish to each employee an annual
statement of accounts of Pass Book.
5. All expenses involved in the administration of the provident
fund including the maintenance of accounts, submission of
accounts ;uid returns, transfer of accumulations, payment ot
inspection charges, etc., shall be borne by the employer.
6. The employer shall credit, every year, to the account of
each member interest at such rates as may be determined by
the Board of Trustee* and such rate shall not be legs than the
one determined by Ihe Central Government from time (o time,

8. Where an employee who is already a member of the
Employees Provident Fund (statutory fund) or the Provident
Fund of another exempted establishment is employed in his
establishment the employer shall immediately, enroll him as
a member of the fund of the establishment, and accept the
past accumulations in respect of such employee and credit the
same lo his account.
9. The employer shall enhance the rate of provident fund
contribution1) appropriately if the rate of provident fund contribution for the class of establishments, in which his establishment falls is enhanced under the Employees Provident Funds
and Miscellaneous Provisions Act, 1952 so that the benefits
under Ihe provident fund scheme of the establishment shall
not become less favourable than the benefit provided under
the said Act.
10. The establishment shall submit an audited balance sheet
of its provident fund every year to the Regional Provident
Fund Commissioner within three months of the close of the
year.
U. No amendment of the rules of the provident furtd shall
be made without the previous approval of the Regional Provident Fund Commissioner and where any amendment is
likely to affect adversely the interest of the employees, the
Regional Provident Fund Commissioner shall, before giving
his approval, give a reasonable opportunity to the employers
to explain their point of view,
[No. S, 35O16/3/79-PF. U\

<!-- page 73 -->

1045
S. O. 1245—Whereas Messrs D & H SecberoD Electrodes
Private Limited, Post Bag No. 3, Indore (hereinafter referred
to as the said establishment) have applied for exemption undei
sub-section (2A) of section 17 of the Employees Provident
Funds and Miscellaneous Provisions Act, 1952 (19 of 1952)
(hereinafter referred to as the said Act);
And whereas, the Central Government is satisfied that the
employees of the said establishment arc, -without making any
separate contribution or payment of premium, in enjoyment
of benefits under the Group Insurance Scheme of the Life
Insurance Corporation of India in the nature of Life Insurance
which are more favourable to such employees than the benefits admissible under the employees Deposit Linked Insurance
Scheme, 1976 (hereinafter referred to as the said scheme) ;
Now, therefore, in exercise of the powers conferred by
sub-section (2A) of section 17 of the said Act and subject to
the conditions specified in the Schedule annexed hereto, the
Central Government hereby exempts the said establishment
from the operation of all the provisions of the said scheme.
SCHEDULE
1. The employer in relation to the said establishment shall
submit such returns to the Regional Provident Fund Commissioner, Madhya Pradesh, Indore, maintain such accounts and
provide such facilities for inspection, as the Central Government may, direct from time to time.
2. The employer shall pay such inspection charges as the
Central Government may, from time to time, direct under
clause (a) of sub-section (3A) of section 17 of the said Act,
within 15 days from the close of every month.
3. All expenses involved in the administration of the Group
Insurance Scheme, including maintenance of accounts, submission of returns, payment of insurance premia, transfer of
accounts, payment of inspection charges, etc. shall be borne
by the employer,
4. The employer shall display, on the Notice Board of the
establishment, a copy of the rules of the Group Insurance
Scheme as approved by the Central Government and, as and
when amended, alongwith a translation of the salient features
thereof, in the language of the majority of the employees.
5. The employer shall arrange, in respect of an employee
who leaves the establishment and joins another establishment
covered under the said Act, to transfer to the Insurance Fund
in respect of the other establishment, the proportionate premium to the credit of the outgoing employee.
6. Where an employee, who is already a member of the
Employees Provident Fund or the Provident Fund of an establishment exempted under the said Act, is employed In his
establishment, the employer shall immediately enrol bim as
a member of the Group Insurance Scheme and pay necessary
premium in respect of him to the Life Insurance Corporation
of India.
7. The employer shall arrange to enhance tb« benefits available to the employees under the Group Insurance Scheme
appropriately, if the benefits available to the employees under
the said scheme are enhanced, so that the benefits available
under the Group Insurance Scheme arc more favourable to
the employees than the benefits admissible under the said
scheme.
8. Notwithstanding anything contained in the Group Insurance scheme, if on the death of an employee the amount
payable under this scheme be less than the amount that
would be payable had the employee been covered under
the said scheme the employer shall pay the difference to the
legal heir/nominee of he employee as compensation.
9. No amendment of the provisions of the Group Insurant*
Scheme shall be made without the prior approval of the
Regional Provident Fund Commissioner, Madhya Pradesh,
Indore and where any amendment is likely to effect adversely
the interest p_f the employees, the Regional Provident Fund
Commissioner, shall before giving hig approval, give a reasonable opportunity to the employees to explain their point
of view.
1367GI/78—10

<!-- page 74 -->

1046

THE GAZETTE OF INDIA : APRIL 14, 1979/CHArTRA 24, 1901

[PART II—SEC. 3(ii)]

10. Whore, for any reason, the employees of the establishment do not remain covered under the Group Insurance
Scheme of the Life Insurance Corporation of India aa already
adopted by the establishment, or the benefits to the employees
under this scheme are reduced in any manner, the exemption
shall be deemed to have been cancelled with effect from that
date and the establishment shall be treated as covered under
the said scheme.
11. Where, for any reason, the employer fails to pay the
premium within the due date, as fixed by the Life Insurance
Corporation of India, and the policy is allowed to lapse, the
exemption, is liable to be cancelled and the employer proceeded against.
12. In case of default, if any, made by the employer in
payment of premium etc., tho responsibility for payment of
assurance benefits to the nominee or the legal heirs of deceased
members who would have been covered under the Employees
Deposit-linked Insurance Scheme, 1976 but for grant of this
exemption, will be that of the employer.
[No. S. 35014/J8/79-PF. II]

S.O. 1246.—Whereas Messrs Bharat Aluminium Company
Limited, Korba (hereinafter referred to as the said establishment) have applied for exemption under sub-section (2A)
of section 17 of the Employees' Provident Funds and Miscellaneous Provisions Act, 1952 (.19 of 1952) (hereinafter referred to the said Act);
And whereas, the Central Government is satisfied that the
employees of the said establishment are, without making any
separate contribution or payment of premium, in enjoyment
of benefits under the Group Insurance Scheme of the Life
Insurance Corporation of India in the nature of life insurance
which are more favourable to such employees than The benefits
admissible under the employees Deposit-Linked Insurance
Scheme, 1976 (hereinafter referred to as the said scheme);

<!-- page 75 -->

1047
Now, therefore, in exercise of the powers conferred by subsection (2A) of section 17 of the said Act and subject to the
conditions specified in the Schedule annexed hereto, the Central Government hereby exempts the said establishment from
the operation of all the provisions of the said scheme
SCHEDULE
1. The employer in relation to the said establishment shall
submit such returns to the Regional Provident Fund Commissioner, Madhya Pradesh, Indore, maintain such accounts
and provide such facilities for inspection, as the Central
Government may direct from time to time,
2. The employer shall pay such inspection charges as the
Central Government may, from time to time, direct under
clause (a) of sub-section (3A) of section 17 of the said Act,
within 15 days from the close of every month.
3. All expenses involved in the administration of the Group
Insurance Scheme, including maintenance of accounts, submission of returns, payment of insurance premia, transfer
of accounts, payment of inspection charges, etc. shall be
borne by the employer.
4. The employer shall display, on the Notice Board of the
establishment, a copy of the rules of the Group Insurance
scheme as approved by the Central Government and, as and
when amended, alongwith a translation of the salient features.
5. The employer shall arrange, in respect of an employee
who leaves the establishment and joins another establishment
covered under the said Act, to transfer to the Insurance Fund
in respect of the other establishment, the proportionate premium to the credit of the outgoing employee.
6. Where an employee, who is already a member of tnc
Employees' Provident Fund or the Provident Fund of an
establishment exempted under the said Act, is employed in
his establishment, the employer shall immediately enrol him
as a member of the Group Insurance Scheme and pay necessary premium in respect of him to the Life Insurance Corporation of India.
7. The employer shall arrange to enhance the benefits available to the employees under the Group Insurance Scheme
appropriately, if the benefits available to the employees undei
the said scheme are enhanced, so that the benefits availubie
under the Group Insurance Scheme are more favourable to
the employees than the benefits admissible under the said
scheme.
8. Notwithstanding anything contained in the Group Insurance Scheme, if on the death of an employee the amount
payable under this scheme be less than the amount that would
be payable and the employee been covered under the said
scheme the employer shall pay the difference to the legal heir/
nominee of the employee as compensation.
9. No amendment of the provisions of tbe Group Insurance
Scheme shall be made without the prior approval of lhe
Regional Provident Fund Commissioner, Madhya Pradesh,
Indore and where any amendment is likely to effect adversely
the interest of the employees, the Regional Provident Fund
Commissioner, shall before getting his approval, give a reasonable opportunity to the employees to explain their point
of view.
10. Where, for any reason, the employees of the establishment do not remain covered under the Group Insurance
Scheme of the Life Insurance Corporation of India a-: already
adopted by the establishment, or the benefits to the employees
under this Scheme are reduced in any manner, the exemption
shall be deemed to have been cancelled with effect from that
date and the establishment shall be treated as covered under
the said scheme.

New Delhi, the 30th March, 1979
S.O. 1247 -In exercise of the powers conferred by subsection (3) of section 1 of the Employees' State Insurance
Act, 1948 (34 of 1948), the Central Government hereby
appoints the 22nd April, 1979 as the date on which the
provisions of Chapter IV (except sections 44 and 45 which
have already been brought into force) and Chapters V
and VI (except sub-section (1) of section 76 and sections
77, 78, 79 and 81 which have already been brought into force)
of the said Act shall come into force in the following areas
in the State of Orissa namely :—
"Areas comprising the revenue villages of Remed, Daripalli, Baraipalt, Sakhi Gopinath, Tajvata, KhctraJpur, Pandri Pathar, Puri Champa, Ainthapal, Kharijamia, Chhatra Sagar, Khamtalai, Gopal Mai, Sambalpur, Marik Munder, Balibandh, Bohidarmal Kantapet, Ghusurijada Bandba, Sidheswar Berna, Deheri
Pali, Charbati, Tangarpali, Sarla, Sunapaii, Dhanupalli, Bhatra, Bad Famuda, Sambalei Padar and
Durgapali in police station Sambalpur Sadar, Tehml
Sambalpur Sadar District Sambalpnr.
[No. S-38013/5/79-HI]
S S. SAHASRANAMAN, Dy. Secy.
New Delhi, the 3rd April, 1979
S.O. 1248 In pursuance of Section 17 of the Industrial
Dispute Act, 1947 (14 of 1947), the Central Government
hereby publishes the following award of the Central Government Industrial Tribunal, Calcutta, in the Industrial Dispute
between the employer in relation to the management Of
Gourangdi Colliery of Bhanora Sub-Area of Eastern Coalfields Limited District Burdwan and their workmen which was
received by the Central Government on 31st March, 1979.
CENTRAL GOVERNMENT INDUSTRIAL TRIBUNAL,
CALCUTTA
Rerefence No. 5 of 1977

11. Where, for any reason, the employer fails to pay the
premium within the due date, as fixed by the Life Insurance
Corporation of India, and the policy is allowed to lapse, the
exemption is liable to be cancelled and the employer proceeded
against.

PARTIES:
Employers in relation to the management of GourangdiColliery of Bhanora Sub-Area of Eastern Coalfields Limited

12. In case o^ default, if any, made by the employer In
payment of premium etc., the responsibility for paj'ment of
assurance benefits to the nominee or the legal heirs of
deceased members who would have been covered under the
Employees Deposit-linked Insurance Scheme, 1976 but for grant
of this exemption, will be that of the employer,
[No. S. 35014/13/79-PF.II1

AND
Their Workmen.
APPEARANCES:
On behalf of Employe™—Shri M. N. Kar, Advocate.
On behalf of Workmen—Absent.

<!-- page 76 -->

1048

THE GAZETTE OF INDIA : APRIL 14, 1979/CHAITRA 24, 1901

STATE: West Bengal

INDUSTRY: CoaT Mines.
AWARD

By Order No L-19012/11/76-D.III(B)-D.IV(B)
dated
25th February, 1977, the Government of India, Ministry of
Labour referred an industrial dispute existing between the
employers in relation to the management of Gourangdi Colliery of Bhanora Sub-Area of Eastern Coalfields Limited and
their workmen to this Tribunal, for adjudication. The material part of the Order reads :
"Whether tlie management of Gourangdi Colliery of
Bhanora Sub-Area of Eastern Coalfields Limited
are justified in stopping the work of Sarva Shri.
1. Sibo Gourah
2. Abhirnanyu Swain
3. Somnath Muni
4. Horu Muni
5. Hari Sethi
6. Sudarshan Muni
7. Ananda Patra
S. Natabar Bisai
9. Bhim Nay a t
10. Bijuli Swainln
11. Khosse Nayak
12. Bhaskai Nayak
13. Upendra Nayak
14. Uday Sethi
15. Manglu Sethi
16. Khadala Suiain
17. Phapuli Gourah
18. Arakhit Dalo Behara
19. Gandhi Sethi
20. Padmalochan PanigiahJ
21. Trinath Saho, nnd
22. Raghu Gourah
with effect from 1-10-1974 7 [f not, to what relief are the
concerned workmen entitled ?"
2. The reference was registered on March 4, 1977 under
the order of my predecessor Sri Justice E. K Moidu. On
that day notice was issued to the parties for filing their
written statements. After my assumption of office in
June,
1978 the case
became
ready
on July 4,
1978,
The reference
was fixed for peremptory hearing on
November 3, 1978. On the date of hearing learned advocate
for the management appeared but no-body appeared on
behalf of the workmen. Meanwhile, an application for adjournment of hearing had been received by the Tribunal
office through post. The Secretary of the Union asked for
adjournment on the ground that he was unable lo attend
the hearing "due to prc-occupation". With the consent of
the learned advocate of the management the case was adjourned to 5th December, 1978 for peremptory hearing.
On December 5, 1978 the learned advocate for the Management appeared but nobody appeared on behalf of the
concerned workmen. An application for adjournment by the
Secretary of the Union arrived by post. In the application
it was stated that the Secretary had been ailing and was not
in a position to attend the hearing and therefore an adjournment was prayed for. The case was adjourned again
to January 10, 1979 for peremptory hearing. Learned advocate appearing on behalf of the management did not
object to the adjournment. At the next date of hearing on
January 10, 1979 learned Advocate for the management
appeared but nobody appeared on behalf of the concerned
workmen. A telegram was received from the Secretary of
the Union asking for adjournment of the case on the ground
that he had to attend to some urgent work, On that date
the order made was as follows : "The hearing of the case
has been adjourned already on successive days at the instance of the Union. As a Fast opportunity, an adjournment
is granted and hearing of the case Is fixed on 29th January,
1979. The order is peremptory. The Union is advised to
make arrangements for proper representation on the next
date of hearing. Let it be recorded that Mr. Kar appearing

[PART II—SEC. 3(ii)]

on behalf of the management objects to any further adjournment of hearing." On January 29, 1979 learned advocate appeared for the management, Mr, B. N. Chatterje«
filed a petition for adjournment of hearing on the ground
that he had stated negotiations with the higher authorities
for settlement of the dispute. On that representation being
made by Mr. Chatterjec, the hearing was adjourned to
March 1, 1979 for filing memorandum of settlement ov lor
final hearing. On March 1, 1979 learned Advocate on behalf of the management appeared but nobody appeared on
behalf of the concerned workmen. In order to afford a last
opportunity lo the workmen to press their claim, I adjourned the hearing of the case to March 23, 1979 suo motu
After
the order had been made an application was received
f
rom tre Secretary of the Union asking for adjournment on
the ground that owing to engagements in connection with
a marriage ceremony in the family he was unable to
nttend the hearing on March 1, 1979, As the hearing of
the case had already been adjourned no further action was
called for.
3. Today at the hearing of the case, learned advocate on
behalf of the management was present but no one appeared
on behalf of the union Mr. M, N. Kar appearing for the
management handed over a copy of a letter from the Secretary of the Union which he stated his client had received
on March 21, 1979. The original of this letter arrived later.
The letter is addressed to the Secretary of the Tribunal. It
reads : "
I beg to inform, you that I have been ailing
since 19-3-79 with attack of serious dysentery and hence it
would not be possible for me to attend your court on
23-3-1979. Kindly give due consideration to my present condition and favour me with an adjournment of the case to
some other date." Mr. M. N. Kar submitted that the Court
has been more than indulgent to the Union. It is an old
Reference of two years' standing and no further adjuornment should be granted.
4. On an anxious consideration of the history of this
case, the fact that repeated adjournments had been given
again and again on different grounds, I am firmly of opinion
that no further adjournment should be granted in this case
and the reference should be finalfy disposed of. Tt appears
from the conduct of those who are incharge of conducting
this case on behalf of the concerned workmen that they are
either unwilling or unable to press their claim at the hearing
of this reference. In these circumstances, I am unable to
adjourn the case as I am of the view that granting further
adjournment will not be in the interest of justice, I therefore
dispose of the reference by passing a "no dispute" award
for non-prosecution.
S.K. MUKHERJEA, Presiding Officer
Dated, Calcutta, 26th March, 1979.
[No. L.19012/11/76-D. TTI(B)/D. IV(B)]
SHASHf BHUSHAN, Desk Offlcei.
New Delhi, the 3rd April, 1979
S.O. 1249 In pursuance of section 17 of the Industrial
Disputes Act, 1947 (14 of 1947), the Central Government
hereby publishes the following award of the Central Government Industrial Tribunal, New Delhi in the industrial dispute
between the employers in relation to the management of
Allahabad Bank, Jaipur and then* workman over termination
of services of Shri Mahendra Kumar, Sub-Staff, Jaipur Branch
with effect from 3-8-76, which was received by the Central
Government on 29-3-79,
BEFORE SHRI MAHESH CHANDRA, PRESIDING OFFICER, CENTRAL GOVT. INDUSTRIAL TRIBUNAL-CUMLABOUR COURT, NEW DELHI
I.D. No. 135 of 1977
In re:
The General Secretary,
Rajasthan Bank Employees Union,
C/o Punjab National Bank,
Station Road.
Bikaner.
-...
(Reg: Shri Mahendra Kumar).

Petitioner.

<!-- page 77 -->

1049
Versus
The Manager,
Allahabad Bank, S. M. S. Highway,
Jaipur.
AWARD
The Central Government as appropriate Government vide
its Order No. L-12012/171/76-D.I1.A, dated the 2nd June,
1977 made a reference to this Tribunal u/s 10 of the I.D.
Act, 1947 :
'Whether the action of the management of Allahabad
Bank, Jaipur in terminating the services of Shrl
Mahcndra Kumar, Sub-Staff, Jaipur Branch w.e.f.
3-8-76 is legal and justified 7 If not, to what relief
is the workman entitled ?
2, On receipt of the reference usual notices were sent to
the parties and a statement of claim was filed on behalf
of the workman. Thereafter a written statement was also filed.
Finally a replication was filed. On the pleadings of the
parties issues were framed and the only issue framed was as
referred in the order of reference and the case was adjourned
for evidence of the parties. In the meanwhile talks for compromise started between the parties and finally a com-

promise was arrived at between the parties. It was ordered to
be recorded in so far as it was beneficial for the workman.
The statement of Shri R. L. Kbandelwal and Shri P. C.
Parikh, the representative of the Union and the Management
respectively was recorded in which it is stated by them that
'the workman Union and Bank have arrived at a settlement
and in consequence the workman has been reinstated. A
no dispute award may be made in this reference. Parties
be left to bear their costs*.
3. In view of the statement recorded above, a no dispute
award is hereby made in the reference and parties are left
to bear their own costs.
FURTHER AWARDED
That requisite number of copies of this award may be seat
to the appropriate Government for necessary action at their
end.
MAHESH CHANDRA, Presiding Officer
Dated: the 16th March, 1979.
[No. L-12012/171/76-D.II.AJ.
S. K. MUKHERJEA, Under Secy.

1368 GI/78—11
PRINTED BY THE MANAGER, QOV r. OF INDIA PRESS, RINO ROAD, NEW DELHI-110064
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI-110054

1979

<!-- page 78 -->
