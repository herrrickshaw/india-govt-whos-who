---
doc_id: "0f3eaf61ee86effd"
source_url: "https://mnre.gov.in/static/uploads/2025/08/2400254f8f8b3a4397f2140439b97dc1.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Guidelines for series approval of Solar PV Inverters for conducting testing in test Labs for implementation of Quality Control Solar Photovoltaics Systems, Devices and Component Goods Order 2017."
date: "2019-08-26"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b351354eedd2f21"
---

<!-- page 1 -->

26th August 2019
File No.223/36/2018-R & D Coord (QC).

Ministry of New & Renewable Energy
(Standards & Quality Control Division)
Guidelines for series approval of Solar PV Inverters for conducting testing in test Labs
for implementation of Quality Control Solar Photovoltaics Systems, Devices and
Component Goods Order 2017.
The guidelines are issued to facilitate test labs/manufacturers in formation of series of
products for approval of product family including change in design, materials, etc. for the
testing of Solar Inverters in the test labs for compulsory registration with BIS for
implementation of the Solar Photovoltaics Systems, Devices and Component Goods Order
2017. These guidelines are applicable for SPV based Off Grid, Grid-Tied and Hybrid
Inverters of capacities up-to 150KW. The following series guidelines will be followed for
conducting tests on Solar Inverters as per standards included in the said order by the test
labs.
1. Definition of Product Family
A product family can be defined by the maximum configuration of components/subassemblies plus a description of how the models are constructed from the maximum
configuration using these component and sub-assemblies. All models which are included
in the family typically have same Hardware and same Firmware essential to ensure
conformity with applicable requirements.
2. Process of Testing and Certification
The manufacturer will have to submit a declaration about the series of their product while
submitting the samples of a particular series for testing to test lab. Out of the entire range
of models intended to be covered under registration, the highest rated model shall be
tested to cover the entire range of family. The lab will be required to charge the cost of
testing only for the highest rated Inverter size model and test report can be issued to all
such sets of lower wattage. Product label of each series model shall be placed in the test
report. If there is a change in construction, material/components in the family then the
product will be submitted to test Labs for fresh testing. The Firmware/software can have
different limit setting as per the rating of the model in a given series, however the overall
Firmware functionality should remain same.
2.1 Series Guidelines
The series guidelines are based on the following design and construction
considerations:
i.

The Inverters having PV voltage rated 1000/1100Vdc max and AC voltage 415V ac
Nominal
Contd. page 2

<!-- page 2 -->

-2-

ii.

iii.

iv.

v.
vi.
vii.

Both Hardware and Firmware are the same as declared by the Inverter
Manufacturer. The Firmware can have different limit settings as per the model
rating in the series.
Products having different Hardware Architecture and Firmware functionality shall
be tested separately. Within the Family the components with different ratings
(Power/current) can be allowed provided the Inverter with max rated component
(such as EMC filters, Capacitors, Transformers, Inductors, IGBT/Mosfets, etc.) is
tested.
All the models under one family shall have same rated Input/Output voltage, Same
frequency and No. of Phases at output, Same PCB design and layout, same power
stage topology, same insulation class (low or high frequency transformer or
transformerless), same control algorithm/firmware, Same cabinet design and class
of construction. If the cabinet design architecture is changing between various
models in the family (keeping the same Internal Hardware like PCB layout between
various models in the family), then all the different cabinet designs are to be tested
or verified for Ingress Protection by either testing it at NABL approved laboratories
or test reports shall be submitted from ISO/IEC 17025/ILAC accredited
laboratories.
The Maximum rated Inverter within the family shall be considered as the
representative test sample for all the models in that family for safety tests.
Inverters having PV voltages rated 1100Vdc shall be tested at 1000V
Inverters having PV voltages rated greater than 1000Vdc and greater than 415Vac
are not covered in these guidelines.

2.2 Documentation
The following information should also be provided with the samples;
i.
ii.
iii.
iv.
v.
vi.
vii.
viii.
ix.
x.
xi.
xii.

Product Datasheet
Complete Bill of Materials list with components.
IEC or any other equivalent international standards, where IEC is not available,
safety certificates for critical components.
Schematics/Single Line diagram with working principle
Enclosure openings/drawings
PCB wiring diagram/layouts with voltage markings and components layout
diagrams on the PCB.
Actual PCB boards (Only PCBs without components) for spacing measurements
1 set of additional PCB boards with components for the destructive safety tests
User Manual/Instruction/Operation Manual
Any internal test reports.
Accessories like mounting & grounding hardware, spare cable with connectors one
end open
Firmware Details like Version Name.

The Test laboratory should not accept the Inverters for testing without above detail.
However, in case the samples have already been submitted to Test Lab or are in the process
Contd. page 3

<!-- page 3 -->

-3-

of submission, the concerned manufacturers will be required to submit an undertaking
for compliance of the instructions contained in these guidelines to BIS for granting
registration. The testing sequence and the pass criterion should be strictly followed in
accordance with the test standards. These guidelines will come into force from the date of
MNRE notification.
Note: Confidentiality of the documents submitted shall be maintained by the
concerned test laboratory.
2.3 Marking:
All the Inverters should contain the following clear and indelible Marking Label &
Warning Label as per IS16221 Part II, clause 5.
The equipment shall, as a minimum, be permanently marked with:
a. The name or trade mark of the manufacturer or supplier;
b. A model number, name or other means to identify the equipment,
c. A serial number, code or other marking allowing identification of manufacturing
location and the manufacturing batch or date within a three-month time period.
d. Input voltage, type of voltage (a.c. or d.c.), frequency, and maximum continuous
current
e. for each input.
f. Output voltage, type of voltage (a.c. or d.c.), frequency, maximum continuous
current, and
g. for a.c. outputs, either the power or power factor for each output
h. The Ingress Protection (IP) rating
Marking shall be located adjacent to each fuse or fuse holder, or on the fuse holder, or in
another location provided that it is obvious to which fuse the marking applies, giving the
fuse current rating and voltage rating for fuses that may be changed at the installed site.
2.4 Guidelines for Quantitative Selection of Samples
IS 16221 (Part 2):2015/IEC 62109-2:2011 Safety of Power Converters for use in Photovoltaic
Power Systems Part 2 (Particular Requirements for Inverters) and IS 16169:2014/IEC
62116:2008 Test Procedure of Islanding Prevention Measures for Utility – Interconnected
Photovoltaic Inverters
Two samples in the family should be submitted (2 no Max rated model) for testing where
1no Maximum rated model will undergo testing. The inverters shall have been
manufactured from specified materials and components in accordance with the relevant
drawings and process sheets and have been subjected to the manufacturer's normal
quality control and production acceptance procedures. The inverters shall be complete in
every detail and shall be accompanied by the manufacturer's handling, mounting and
connection instructions, including the maximum permissible system voltage.
Contd. page 4

<!-- page 4 -->

-4-

All the applicable tests referred in the relevant standards will be carried out. In the case of
IS16221 Part 2, the tests referred in the said standard including IS16221 Part 1 will be
carried out. The detailed testing will be carried out as per procedures and guidelines given
in the above mentioned standards. IS16169 is not applicable for the Standalone/Off grid
Inverters and hence IS16169 shall not be tested for the Standalone/Off grid inverters. The
sequence of testing is given in Annexure I.
Note: Most of the tests concerning safety of solar power converters referred in IS
16221(Part 2): 2015 are to be done as per IS 16221(Part 1) :2016. Due to the Inverter safety
testing complications or for the components understanding, the lab shall carry out tests
after having conversation with the manufacturer or Manufacturer to be present in
verifying the test setup prior to testing for the critical tests as given in table in
Annexure-II.
2.5 Retesting guidelines for any test failures:
If any test fails in sequence 1, then a new sample is to be submitted by the manufacturer
and only the tests in the sequence 1 will be repeated after components & construction
review and IS 16169.
Similarly, if any test fails in sequence 2, then a new sample is to be submitted by the
manufacturer and only the tests in the sequence 2 will be repeated after the components
& construction review. IS16169 can be omitted for a failure in sequence 2 unless the critical
internal components are not changed.
In both the above case (failures in sequence 1 or 2), repetition for IS16169 testing shall only
be done on 3 Balanced conditions and any 2 Imbalance conditions. Appropriate retesting
fee will be charge by test labs for all those repeat tests. The retesting sequence should start
from beginning in order to document the changes made in the components & construction
and to ensure the compliance for IS 16169 is not disturbed.
A total of only one failure is permitted in each testing sequence and a second failure in
that particular sequence will be considered as a total failure.
2.6 Pass criteria
Pass criteria for Solar Inverters should be as per IS 16169 and IS 16221 Part II, wherever
applicable.
2.7 Brands
All brands with respective model numbers should be listed in the test report. Test samples
of all brands are not required to be submitted. However, product labels for respective
brands must be placed in the test report. Lab may also include statement about coverage
of this brand and respective model numbers to be covered based on the representative
model tested and the declaration submitted by the manufacturer about multiple brands
and respective model numbers. The products manufactured in two different locations
shall be tested separately.
Please refer to “Process for Registration” under Registration Scheme available at BIS
website www.crsbis.in.

<!-- page 5 -->

Annexure I
Testing/Documentation Sequence:

<!-- page 6 -->

Annexure - II
Table 1
Clause (IS 16221 List of Tests
(Part 1):2016)
7.3.2.6
Working voltage and
DVC
7.3.9

9.2.2

7.5.2

4.4.4.6

4.6

4.3.2.1

4.4.4
Method 1

Assistance of manufacturers for technical
and operational issue of components
To tap out points and connect oscilloscopes
at various internal auxiliary and Gate
drive/control power supplies
Protection against shock To tap out point across the total bus
hazard due to stored
capacitors and connect oscilloscope
energy
Limited power source To overload the auxiliary, Gate drive/
tests
control power supplies with loads to check
the maximum VA power
Voltage test (dielectric To remove some components like MOVs,
strength test)
X/Y capacitors or branch circuits which is
connected across the ground
Backfeed current test for To put current probes after the DC fuses in
equipment with more
the input side and before the contactor/relay
than one source of
in the AC output side of the inverter.
supply
Backfeed voltage
To tap out point to connect voltage probes
protection
after the DC fuses in the input side and
before the contactor/relay in the AC output
side of the inverter.
Maximum temperatures To put thermocouples in the all the critical
- General
components without damaging the inverter
functioning
Single Fault conditions To open or short the critical components
to be applied
which is identified as its failure may lead to
shock or Fire hazard.
Example: DC bus capacitor short, IGBT D-S
short ( C-E), IGBT G-D short ( G-E), IGBT
open gate ( Disable the IGBT by shorting the
G -E), output current measurement (open
any one phase), output voltage
measurement (open any one phase), control
circuit failure (remove power from control
circuit)
