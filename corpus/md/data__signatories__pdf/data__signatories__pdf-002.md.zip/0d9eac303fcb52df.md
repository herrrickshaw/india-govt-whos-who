---
doc_id: "0d9eac303fcb52df"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/4688b7503bcc124176691cfeeeb0da89.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Draft amendment of Recruitment Rules for the Post of Senior Laboratory Technician in the Institute of Serology, Kolkata"
date: "2018-08-07"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "da9035216d3fcb92"
---

<!-- page 1 -->

छः
No. A-12018/09/2014-MHLII
Government of India
Ministry of Health and Family Welfare
. Directorate General of Health Services
Ok He KK
Subject: Public notice on draft Recruitment Rules for the post of Senior

Laboratory Technician in Institute of Serology, Kolkata. |
In compliance with DOPT’s OM No. AB-14017/61/2008-Estt.(RR) dated

13.10.2015, the draft Recruitment Rules for the post of Senior Laboratory
Technician Head Clerk in Institute of Serology, Kolkata is annexed. |
The stakeholders interested in making any objections/comments or |
suggestions on the draft Recruitment Rules may do so in writing, within a |
period of 30 days from the date of publication of draft Recruitment Rules to |
Shri V.Prasad, Deputy Director (MH), Room No. 559, A-Wing, Nirman |
Bhawan, Maulana Azad Road, New Delhi — 110011 or e-mail address:
v.prasad@nic.in ay,

MA bey
(MK. Chowdhuyy$7/2 |

Director
Tel: 23061015
New Delhi
Dated:
| |
|
1
|
i
1
/
1

<!-- page 2 -->

[TO BE PUBLISHED IN THE GAZETTE OF INDIA PART II, SECTION 3, SUB-SECTION (i}]
Government of India
. Ministry of Health and Family Welfare
New Delhi, the ................2018
NOTIFICATION

G.S.R. — In exercise of the powers conferred by the proviso to article 309 of the Constitution, and in

supersession of the Institute of Serologist, Kolkata, Senior Laboratory Technician, Group 'C’ Post,

Recruitment Rules, 1973, in so far as they relates to the post of Senior Laboratory Technician except as

respects things done or omitted to be done before such supersession, the President hereby makes the

following rules regulating the method of recruitment to the post of Senior Laboratory Technician in Ministry
of Health and Family Welfare, Institute of Serology, Kolkata, namely:- |
!

1. Short title and commencement. — (1) These rules may be called the Ministry of Health and Family ।
Welfare, Institute of Serology, Kolkata, Senior Laboratory Technician, Group 'C’ post Recruitment |
Rules, 2018.

(2)They shall come into force on the date of their publication in the Official Gazette.

2. Number of posts, classification and level in the pay matrix. - The number of said post, its classification |
and the level in the pay matrix attached thereto shall be as specified in columns (2) to (4) of the |
Schedule annexed to these rules. |

3. Method of recruitment, age limit, qualifications, efc. — The method of recruitment, age limit,
qualifications and other matters relating to the said post shall be as specified in columns (5) to (13) of
the said Schedule.

4. Disqualification. — No person, —

(a) who has entered into or contracted a marriage with a person having a spouse living ; or

(b) who, having a spouse living, has entered into or contracted a marriage with any person.
shall be eligible for appointment to the said post: |
}
Provided that the Central Government, may, if satisfied that such marriage is permissible under
the personal law applicable to such person and other party to the marriage and that there are other |
grounds for so doing, exempt any person from the operation of this rule. |

5. Power to relax. — Where the Central Government is of the opinion that it is necessary or expedient so |
to do, it may, by order, for reasons to be recorded in writing and in consultation with Union Public :
Services Commission, relax any of the provisions of these rules with respect to any class or category of |
persons.

i

&

6. Saving. — Nothing in these rules shall affect reservations, relaxation of age limit and other concessions :
required to be provided for the Scheduled Castes, the Scheduled Tribes, Ex-servicemen and other |
special categories of persons, in accordance with the orders issued by the Central Government from |
time to time in this regard. |
[

L

1

हि

- i

<!-- page 3 -->

SCHEDULE ®
Name of | Number of posts. Classification. Level in the pay matrix. ; Whether selection post | Age limit for direct recruits.
the post. or non-selection post.
Senior 8 * (2018) General Central Service, Level - 5 (29200- 92300) | Non-selection Not Applicable.
Laboratory |, ia Group ‘C’
Technician | "subject to variation Non-Gazetted
depending on Non-Ministerial
workload.
|
Educational and other | Whether age and educational | Period of probation, if any. Method of recruitment, whether by direct recruitment or by |
qualifications required for | qualifications prescribed for direct promotion or by deputation or absorption and percentage of
direct recruits. recruits will apply in the case of the posts to be filled by various methods. |
promotees.
ete आजआखकएखखई |
Not Applicable. Not Applicable. Not Applicable. 100 % by promotion.
|
1
|
|
|
|
|

<!-- page 4 -->

&
In case of recruitment by promotion or | Ifa Departmental Promotion Committee exists, what is its composition. Circumstances in which Union
deputation’ absorption grade from which Public Services Commission
promotion or deputation/absorption to be is to be consulted in making
made. : recruitment.
Pe
PROMOTION: Group ‘C' Departmental Promotion Committee (for considering promotion): Not applicable.
Laboratory Technician of the Department
with 10 years regular service in the level 3 | 1. Additional or Senior most Assistant Serologist, |
in the Pay Matrix. Institute of Serology, Kolkata — Chairman. :
Note 4:Where Junior who have completed L
their qualifying or eligibility service are | 2. Assistant Serologist,, Institute of Serology Kolkata — Member :
being considered for promotion, their
seniors would also be considered | 3. One Gazetted Officer from other Central L
provided they are not short of the requisite; © Government office in Kolkata — Member i
qualifying or eligibility service by more than i
half of such qualifying or eligibility service
or two years, whichever is less , and have |
successfully completed probation period :
for promotion to the next higher grade
along with their juniors who have already 1
completed such qualifying or eligibility
service.
Note 2: '
The eligibility list for promotion shall be
prepared with reference to the date of /
completion by the officers of the
prescribed qualifying service in the |
respective grade or post ।
190.0.11018/09/2016-0॥1-॥] द
: (B.L. Meena)
Under Secretary to the Government of India |
!
1
1
1
;
a
