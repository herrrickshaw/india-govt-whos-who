---
doc_id: "0faef336f73aad5e"
source_url: "https://www.dpe.gov.in/static/uploads/2025/07/c4499f6676b9a8055b2fb566a1a03f8e.pdf"
ministry: "Department of Public Enterprises (DPE)"
title: "Policy for the Sixth Round for Wage Negotiations in Public Sector Enterprises"
date: "2025-07-15"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "04d212ff7b4fd84e"
---

<!-- page 1 -->

CHAPTER IV
WAGE POLICIES & RELATED MATTERS
(a) Wage Policy/Pay Revision/HPPC Recommendations
11.
DPE/Guidelines/IV(a)/11
Policy for the Sixth Round for Wage Negotiations in Public Sector Enterprises.
The undersigned is directed to convey the decision of the Government that the next round of wage negotiations
(Which fell due on a general basis from 1.1.97) with the workers of Central Public Sector Enterprises may be
commenced by the Managements of the Enterprises with the Trade Unions/Associations, subject to the following
conditions:i) The management of PSEs would be free to negotiate the wage structure for the employees not covered by the
Justice Mohan Committee, keeping in view and consistent with the generation of resources/profits by the concerned
enterprises.
ii) No budgetary support for the wage increase shall be provided by the Government.
iii) For PSEs which are monopolies or near monopolies or operate under an administered price structure, it must be
ensured that any increase in wages after negotiations does not result in any increase in administered prices of their
goods and services.
iv) The wage revisions shall be subject to the condition that there shall be no increase in labour cost per physical unit
of output. There may be exceptions where units were already working at optimum capacity considering industry vide
norms; in such cases the administrative Department may consult DPE.
2. As regards sick units registered with BIFR, until BIFR approves revival plan of such enterprises in which provisions
have been made for additional expenditure on account of pay revision, no revision of pay would be allowed to the
employees of such enterprises.
3. The public enterprises may implement the negotiated wages after confirming to the administrative Ministry and
the Department of Public Enterprises that the revisions are within the approved parameters, and that it has been
ensured that such negotiated wages would not come in conflict with the wage revision of officers and non-unionised
supervisors of public enterprises.
4. The Justice Mohan Committee, which has already submitted its recommendations regarding pay package and
perquisites for officers and non-unionised supervisors, have recommended pay revision in every 10 years instead of 5
years that has been in practice. In the event of Government accepting the recommendations of the Justice Mohan
Committee in this regard, the revision of wages for the workers should also be effected once in every 10 years, in
order to ensure uniformity. This aspect may also be kept in view.
5. The wage settlements should be negotiated by the PSEs in accordance with the above parameters. The
administrative Ministries/Departments are requested to issue suitable instructions to the public sector enterprises
under their administrative control on the above lines, under intimation to this Department.
(DPE OM No. 2(11)/96-DPE(WC) dated 14th January, 1999)
***
