---
doc_id: "0ca4cb9d04fcd7d2"
source_url: "https://www.moes.gov.in/static/uploads/2025/06/64e7bc4ffc6b1b4b299310325f1e5bb2.pdf"
ministry: "Earth Sciences (MoES)"
title: "Tender for Flower Supply"
date: "2025-06-19"
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e03b1bb40eb00817"
---

<!-- page 1 -->

~0~ofct01l0/3/4/20

16 filtHier'll

31R(1 fI {Chi {

~uft- fa :n11Tl cH:;jI<>l'll
~cfr ~,

~o"Qd1o-gyoChI(Fq~Cffl

<>IltT m-,1Tlt ~
~-

-I 10003

01/02/2017

t- f!"fuq Qq 3Ur ~
t- Cfi"1RT ;R- fI C(i 16 t- ~~ m ~
;R- ~ qr:IT
"
;R- m ~ qr:r ~
(fm <H:;jI <>l'll c;qm 3i I'llYGI (i fI {Chi t'I ~
t- fA1! ~
~ ~
fli tHIITl
"
,
"
(:R<>lJITlCfl-VII
at) t- fA1! c;T ~
QOII~ (Two Bid System) (iCflaflch'l (fm fa~'lll
Fa1faC:;1 3i'1ITl<>lI$1Tl
(online) 3ilcHGl(i cfi'r ~ @ 6 I rncFa1faC:;l)
q;r t- ~
~
~ ufti(EMO) t- ~ Rs.30,0001(c=fR:r ~
CfIT f5J1is ~,
000, Ministry of Earth Sciences, t- aw=r ~ ~
6Prr1 3fCR f!"fuq
~

<H:;jI <>l'll

(filtHier'll),

quftfa:n11Tl cH:;jI<>l'll q~cfr ~,
~
~

fA:&CfI{,~"'-o

I (filtHier'll

16/0'612017/ CfiT ~

03.30

31afWl),;R-/5103/2017
.:>

CfiT ~

~

cfi'r 3fNfct

rn

CFa1faC:;l) ~

"
(2)

~

faa:IT ~

03.00

ufti(EMO)

cH:;jI<>l'll C\3ffi ~

t- <>ftCT ~

\jj Iil Jill

m. ~

~

CfIT 5%

q{Cfi~iferfl

RiCf'llf{tI

nftI ~

3ilTltHlFa1(i ~
.:>

CfiT ~

~ t- 60f?;a:r (iCfl ~
(3)

<:rg ~

Cfl{

cfi'r CI"{', ~

~

~

~

"

~

~

~

t- ~

~

t- f1T~ ~
""

;R- ~

~

~,

t- cH:;jI<>l'll t- ~

<>fr ~

q~cfr ~,
~

cfi'r

~

cfi'r ~

0lT fcF ~

C\3ffi ~

6', ill ~

c;TI ;R- ~

~ ~ CI"{' 3fr ~

Cfl{ ~~
I ~
"

~

;R- 5lN tl

(iCfl rn

q:;Jf CfiT <H:;jI <>l'll ;R- ~

-110003

.:>'

t- ~
t- ~
flCRlq(i

-

~I

C;~m!fcF CRIT ~

3f(>ldT ~

~

"

~

~

~

m- ITlt ~

<>IltT

~O"Qd1o-gyOChI(Fq~Cffl,

~O"Qd1o-gyOChI(Fq~Cffl,

<>IltT m-, ITlt ~

6' <:IT a:r6T 6'1 ~
cfi'r ~

faa:IT ~
"

;R- qgi1
IITlI ~I
.:>

.:>

<!-- page 2 -->

.

, ,

.
'

m ~ m *'"~ ~ ~ ~ ~ ~ ~
2. m~~~~~~~m~~~*,"~~1
3.

~

<A=llc>lll ~

fcR::fT 3ft' <IT ~

qfff

~

*'"

c=fro:1~

1,

CfiTt~ru:r

~3ft'

CfiR'UT ~

ftW <'m $tT1

31cffU ~

JifcllChI'{

~

~

~

~~tl
4.

<A=llc>lll ~

qfff

~

~

mfffi:r
.:)

tl

m

tRT
~

m 'J{ 3ffld1~

\511Q d II

c=rm ~~

3W '(>ll"dT(i"tR' 3fG=lI' ~

CfiT ~

6.

~

m q;r ~
31~

~

tR'

~

CR' ~

~

~fclC;1

C;fCiI~\51

fcR::fT 3ft' ~

CfiRUT ~

~
~

3,qa:;)i

illl ~ Ci ~

1icr m

*'"

\jj&(i' CR'

<>fr~

diU
Iq iiI q iffi;Ci 'fC1{' ~
.:)

c=rm ~

m~ ~ .:)

~

a:r

fiJ""l1cCi

6tr tR', ~ .:)

CfiT

m CfiT 6ctlC; I'{ ~ \51~ffil CA

\J1TQdTT I
q~ollCAl

~

3W ~ .:)

fa1trRoT

~

3lc=rc1:~

<A=llc>lll c;qm
,

~ICi.JlCi

<IT f1CA$"l1cfi ~

~

\J1TQdTT1 <A=llc>lll

fcti<:rr \J1TQdTT I

~
7.

~

~fclC;1
C\?RT

fcR::fT 3ft' ~

<A=llc>lll ~
C;fCiI~\51

<IT ChAilifi

m~ ~

<IT ~Rf CfiT ~mfac=r

fcR::fT 3ft' ~

~

~

m ~ m qrc;fr ~

~ m~

d""l1ffilCh ~

~

mffilCfl

<IT ~~ITRt=r

~

~

fcrt:TR'

<A=llc>lll tR' ~~

o:r6T 'J""lTa1T

\J1TQdTT1
8.

\J1T ~

~

3ft' ~

~ fclC;1 ~

~

09.

'>IfCilq

~

~3ft'

~,ChI<l<;hCA

qa=r ~

31~

fila:rr ~

~

~

31~

~

CfiT ~mfac=r 31~

~

fcR::fT 'fC1{' tR' ~
~

~

~

3tR ~
3tR~:m

~

~

ct11~~1

~

1O.

1:fi"N

~

I 1:fi"N
~

CR'

cfr ~

1 1.

<A=llc>lll fila:rr ~

~

qr:IT 'J{ 1:fi"N
o,

~ .:)

~

3f'(>fdT-3f'(>fdT

31~

3fG=lI'

.:)

~mfac=r ~

q;r ~

cR"aTI ~

\J1TQdTT I

CR' ~

'J""lTa1T\jjll1dll

fct; ~

m ~ m qrc;fr qgl at ~

C;fCiI~\jj

~

~

~fclC;1

'J{ ~

m f0R:r

CfiT ~ ~
CfiT ~

tan ~ 1icr ~

~
~~

6tr ~

~3ft'

~

~<nOl ~

emf CfiT qq;T t, 3W ~

~3ft'

~

~

~t> I
~

mc=r: CfilN ~

rl (1Cf)' c>ld II0"11

8.30

I CfifcFf :8 Ci~IS! \jj 0"1Ch a:r 6tr tR' ~ fcl C;I ~ ,

3tR q '( lh~cRcrf1 ~ Cfll ~t1 uffi \jj&(i' CR' <>fr~
'ChffiOT ~

m ChIO"1ai~
Ci\Tc:Cfl{OI ~
~

~

~ ~

~

ft:~Cl(1

f1J~ ~1 CfiT Ji fen 'rCi

I

~
CR' 'f1'CflCiT

tI

~

~

"Tit ~
)

fait~TCfi.:mw

(ft:~Ir~)

.:)

f1'{ChI'{

v

<!-- page 3 -->

"

-3-

"

~
1.

faifck\ICh{

m~

fai~C\1

2.

~

qm ~

~
~

~

~

~/ctcl¢rl ~o <rtt ~

ffi;qlcrl

~

3(>'~,@

'fit 1

SlCHlolq::l

~

3rcf~<r

ta:rr

WIT, "~

~.;)

~

~

~

~

~

°

f?0r dfl! ~

~

1'1CHI Iq::l

fai ~ C; ICh{ Cf)d1 ~

Cf)d1 ~

~

~

Cf)d1 1!Cfl *"1{Chi fI

<H::lI<'l<11 fct~

~

Chldl01IC""1

,

6 en- ~

~

~

~

fai<hTl~R9(1

31m

~

(Eligibility criteria) :-

1l"l1Ci1C\s

Cfl"~

cfi'r CHN ~

~I

I'ICHlf6'IC""I ~
~

~

~

ma:<1 ifctiC""l ~

"

~

~

~

~

~

6 Icfl ~~
~
dT<TI 61 31RfCfl'{' ~

0lT(1T

~

.;)

~

0ffC.ldTJ' #;'p1

~

~~~I
3.

4.

"

~

~

~

,

"

5.

tf)(>l" ~ ~(11

"

Chi dl01 1("1 ~
6.

~

"

~

CfiT CflTJ1 ~

"

m~
~

(Black List) ~ ~

® ~ c=rm ~

cjua:r

~

Cf)d1

~ tOc>lT
cfi'r 3fTtffct CfiT 1!Cfl ~ CfiT .3-1a131cr ~. ~ ~
~
""
~ ~
'fit 1
~ fcR:fr ~ *H Chi fI fct~
c=rm m.T fl {Ch IfI fR=~ITa:flfaidTcl1
ST'<'lT dT<TI

tf)(>l" ~

m-I

c<1 Clfll <1 Cf)d1 ~

"

Cf)d1 1!Cfl <>fmT ~

m-. ~

~

3i fai ClI~

61

~

:H<'ldCf1 'fit 1

mra=n ~

6 fit; <'l~<H~c{

~ c;mt ~ ~

fl<'ldLCf1Ch -VII (Annexure

-VII) ~ ~

dfl! ~

cfi'r ~3'"

tf)(>l" ~

~
~

CfiT ~

tOc>lT ~

.;)

rn (fai~C\I)

tf)(>l" ~ ~ C""II CflT ~

~

<H::lI<'l<1 (~cfr
~

1)4fs\;41 (Selection Process)

"€/<rCI1"

~

~

~I

Cf)""(>l"
(Total) ~
.;)

~'~"II

~~(11

Cf)CH"uffi

(Amount)

c;~mmr:mr ~I

~~(11

~ ~

CHC; (Items) CfiT

CflT <H::lI<'l<1 C\ClClI{1
~
,

~

&)~~
.;)

(ft~fI Cf11R)
.;)

Copy to:1. NIC Division of Ministry of Earth Sciences with the request to display the above tender notice on the
web site of this Minsitry.
2. All Ministrise/Departments
with the request to give due publicity for the above tender among the
contractors working with them.
3. Computer Division, MoES with the request to upload the tender notice in the Central Public
Procurement Portal of Government of India (e procure.gov. in) and the web site of this Minsitry.

<!-- page 4 -->

-4Open Tender No.MoES/3/4/20

16-Genl.
Annexure-I

Instructions

for Online Bid Submission

The bidders are required to submit soft copies of their bids electronically on the CPP Portal, using
valid Digital Signature Certificates. The instructions given below are meant to assist the bidders in
registering on the CPP Portal, prepare their bids in accordance with the requirements and submitting
their bids online on the CPP Portal.
More information useful for submitting online bids on the CPP Portal may be obtained
at: hUps:/ /eprocure.gov. in/eprocure/app.
REGISTRA TION

1. Bidders are required to enroll on the e-Procurernent module of the Central Public Procurement
Portal (URL: https://eprocure.gov.in/eprocure/app.)
by clicking on the link "Online Bidder
Enrollment" on the CPP Portal which is free of charge.
2. As part of the enrolment process, the bidders will be required to choose a unique username and
assign a password for their accounts.
3. Bidders are advised to register their valid email address and mobile numbers as part of the
registration process. These would be used for any communication from the CPP Portal.
4.Upon enrolment, the bidders will be required to register their valid Digital Signature Certificate
(Class II or Class ITI Certificated with signing key usage) issued by any Certifying Authority
recognized by CCA India (e.g.Sify/TCS/nCode/eMudhra
etc.), with their profile.
5.0nly one valid DSC should be registered by a bidder. Please note that the bidders are responsible to
ensure that they do not lend their DSC's to other which may lead to misuse.
6. Bidder than logs on to the site through the secured long-in by entering their user ID/password and
the password of the DSC/ e-Token.
SEARCHING

FOR TENDER DOCUMENTS

l.There are various search options built in the CPP Portal, to facilitate bidders to search active
tenders by several parameters. These parameters could include Tender ID, Organization
arne,
Location, Date, Value, etc. There is also an option of advanced search for tenders, wherein the
bidders may combine a number of search parameters such as Organization Name, Form of Contract,
Location, Date, Other keywords etc. to search for a tender published on the CPP Portal.
2.0nce the bidders have selected the tenders they are interested in, they may download the
requirement documents/ tender schedules. These tenders can be moved to the respective 'My
Tenders' folder. This would enable the CPP Portal to intimate the bidders through SMS/e-mail 111
case there is any corrigendum issued to the tender document.
3.The bidder should make a note of the unique Tender fD assigned to each tender, in case they want
to obtain any clarification/help from the Helpdesk.

<!-- page 5 -->

"

-5PREPARATION OF BIDS
I.Bidder should take into account
submitting their bids.

any corrigendum

published

on the tender document

before

2. Please go through the tender advertisement and the tender document carefully to understand the
documents required to be submitted as part of the bid. Please note the number of covers in which the
bid documents have to be submitted, the number of documents- including the names and content of
each of the document that need to be submitted. Any deviations from these may lead to rejection of
the bid.
3.Bidder, in advance, should get ready the bid documents to be submitted as indicated in the tender
documents/schedule and generally, they can be in PDF/XLS/RARlDWF/JPG
formats. Bid documents
may be scanned with 100 dpi with black and white option which helps in reducing size of the
scanned document.
4.To avoid the time and effort required in uploading the same set of standard document which are
required to be submitted as part of every bid, a provision of uploading such standard documents
(e.g.PAN card copy, annual reports, auditor certificates etc.)has been provided to the bidders. Bidders
can use "My Space" or "Other important Documents" area available to them to upload such
documents. These documents may be directly submitted from the "My Space" area while submitting
a bid, and need not be uploaded again and again. This will lead to a reduction in the time required for
bid submission process.
SUBMISSION OF BIDS
\1.Bidder should log into the site well in advance for bid submission so that they can upload the bid
in time i.e. on or before the bid submission time. Bidder will be responsible for any delay due to
other issues.
2.The bidder has to digitally sign and upload the required bid documents one by one as indicated in
the tender documents.
3.Bidder has to select the payment option as "offline" to pay the tender fee/EMD as applicable and
enter details of the instrument.
4.Bidder should prepare the EMD as per the instructions specified in the tender documents. The
original should be posted/couriered/given
in person to the concerned official, latest by the last date of
bid submission or as specified in the tender documents. The details of the DD/any other accepted
instrument, physically sent, should tally with the details available in the scanned copy and the data
entered during bid submission time. Otherwise the uploaded bid will be rejected.
5.Bidders are requested to note that they should necessarily submit their financial bids in the format
provided and no other format is acceptable. If the price bid has given as a standard BoQ format with
the tender documents, then the same is to be downloaded and to be filled by all the bidders. Bidders
are required to download the BoQ file, open it and complete the white colored (unprotected) cells
with their respective financial quotes and other details (such as name of the bidder). 0 other cells
should be changed. Once the details have been completed, the bidder should save it and submit it
only online, without changing the filename. Tfthe BoQ file is found to be modified by the bidder, the
bid will be rejected.
6.The server time (which is displayed on the bidder's dashboard) will be considered as the standard
time for referencing the deadlines for submission of the bids by the bidders, opening of bids etc. The
bidders should follow this time during bid submission.

<!-- page 6 -->

-67. All the documents being submitted by the bidders would be encrypted using PKI encryption
techniques to ensure the secrecy of the data. The data entered cannot be viewed by unauthorized
persons until the time of bid opening. The confidentially of the bids is maintained using the secured
Socket Layer 128 bit encryption technology. Data storage encryption of sensitive fields is done. Any
bid document that is uploaded to the server is subjected to symmetric encryption using buyers/bid
openers public keys. Overall, the uploaded tender documents become readable only after the tender
opening by the authorized bid openers.
8.The uploaded tender documents become readable only after the tender opening by the authorized
bid openers.
9.Upon the successful and timely submission of bids (i.e. after Clicking "Freeze Bid Submission" in
the portal), the portal will give a successful bid submission message & a bid summary will be
displayed with the bid no. and the date & time of submission of the bid with all other relevant details.
10.The bid summary has to be printed and kept as an acknowledgement of the submission of the bid.
This acknowledgement may be used as an entry pass for any bid opening meetings.
ASSISTANCE TO BIDDERS
I.Any queries relating to the tender documents and the terms and conditions contained therein should
be addressed to the Tender inviting Authority for a tender or the relevant contract person indicated in
the tender.
2.Any queries relating to the process of online bid submission or queries relating to CCP Portal in
general may be directed to the 24x7 CPP Portal Helpdesk. The contact number for the helpdesk is
180030702232.

<!-- page 7 -->

·

.'
Annexure-II
TENDER ACCEPTANCE

LETTER
Date:

To,
Director (General Administration)
Ministry of Earth Sciences
Prithvi Bhawan
Lodhi Road,
ew Delhi-II 0003
Sub: Acceptance
Tender Reference
Name

of Terms & Conditions

0.MoES/3/4/20

of Tender/Work:

of Tender

16-Genl.

Quotation
Sciences.

for supply of flowers to Ministry

of Earth

Dear Sir,
I.

I/We have downloadedl obtained the tender document(s) for the above mentioned
'Tender/Work'
from the web site(s) namely www.moes.gov.in
or central Public
Procurement Portal of Govt. of India i.e eprocure.gov.in as per your advertisement,
given in the above mentioned website(s).

2. I1We hereby certify that II we have read the entire terms and conditions of the tender
documents from page
o. 1 to 6 (including all documents like annexure(s).
schedule(s) etc. which form part of the contract agreement and I/We shall abide by
the terms Iconditions/clauses
contained therein.
3.

The corrigendum(s) issued from time to time by your department I organization on
the website too has also been taken into consideration,
while submitting this
acceptance letter.

4.

II We hereby unconditionally
accept
tender document(s)1 corrigendum(s)

the tender conditions
in its totality/entirety.

of above

mentioned

5. In case any provisions of this tender are found violated then your departmentl
organization shall without prejudice to any other right or remedy be at liberty to
reject this tenderl bid including the forfeiture of the full said earnest money
deposit absolutely.

Yours faithfully,

<!-- page 8 -->

Important

ANNEXUR

-111

PROFORMA
(Company document)
[Required for technical bid]
The following documents shall be placed in the Technical Bid for providing
manpower for this Ministry of Earth Sciences
(Without

these information

Technical Bid will not be evaluated
be rejected straightway)

Items
Earnest Money Deposit (Demand Draft/Pay order/Bank
of Rs.30.0001In favour of DDO,
Guarantee/
FDR
MoES.The Original(hard
cOQY of the EMD) shall be
deQosited by hand In the Tender Box Placed in this
Ministry in Room No.1, Prithvi Bhawan Lodhi Road, New
Delhi

Secretarial

and the same will

Page No (Please mention the Page
number positively)
Scanned Copy at Page No

Terms and Conditions of the Tender duly signed by the
tenderer as token for acceptance of Terms & Conditions of
the Tender
PAN Card of Firm/Company (attach copy of PAN Card).
VAT/Service tax registration certificate

Page No.

Experience as per eligibility criteria (copy)
Experience certificate copies issued by the clients to the
tender, at least for one year

Scanned copy at page No
Scanned copy at page No

Scanned copy at page No
Scanned copy at page No

Signature of the Tenderer
With seal of the Firm/Company

<!-- page 9 -->

,

..
Annexure -IV
PROFORMA
(Company detail)
[Required for technical bid]
To,
The
Ministry of Earth Sciences
Prithvi Bhawan
Lodi Road,
New Delhi-I 10003

Subject; Providing flowers to MoES.
Sir,
The undersigned have read and examined in detail the tender
hereby express our interest to provide such services.
Corresponding

document

and do

Details;

1

Name ot the Company

'2

Address otthe

3

Name of the Contract person to whom
all references shall be made regarding
this tender

4.

Telephone

).

L-rnau ot the contract person

6.

Fax No. ( with STD code)

I.

Earnest Money detail

Company

( with STD code)

Uemand Dratt No & date:
Bank Name:
Drawn in favour of:

It is certified that the person, who shall be provided for Work\duties
necessary qualification for taking up this assignment.

are competent and have the

Thanking you,
Yours faithfully,
(Signature of the Authorized Person)
Date:
Place:
Business Address:

Name:
Designation:
Seal:

<!-- page 10 -->

· ".'

Annexure- V
PROFORMA
(Minimum Eligibility)
[Required for technical bid]

The details in respect of the company are as given under:
I

Name ot the company

1.

Year ot Regrstranon/Incorporation

j.

Annual I urnover during last j years
2013-14
2014-15
2015-16

4.

Experience in having successfully completed similar
works during the last three years in a government /
semi government department

Write the applicable one tor
your firm.

Yours faithfully,
Signature of the Authorized Person)
Name:
Date;

Designation:

Place: Seal:
Business Address:

<!-- page 11 -->

Annexure -VI

Proforma for DECLARATION
[Required for technical bid]
Declaration

Letter on Official Letter head stating the following;

(i)

We are not involved in any major litigation that may have an impact of affecting or
compromising the delivery of Services as required under this tender.

(ii)

We are not black-listed
Undertaking in

by any

Central!

State

Government/

Public

Sector

India.

Yours faithfully,

(Signature of the Authorized
Person)
ame:
Date;
Place:
Business Address:

Designation:
Seal:

<!-- page 12 -->

.,
Annexure -VII
Financial Bid
S.No.

Items
(Rates are to be quoted for one number per Item)

l.

Round Flower arrangement for Senior officers Room
for 5 days in a week (8 flowers per one arrangement)
Round Flower arrangement for Senior officers Room
for 5 days in a week (6 flowers per one arrangement)
Round Lilly flower (big size) 25 flower per one
bouquet.
Round Lilly flower (big size) 20 flower per one
bouquet.
Lilly flower arrangement for table (ovel shape) 40
pieces flower per one.
Lilium flower arrangement for table (ovel shape) 25
pieces flower per one.
22" Inch round Floating arrangement desi rose petals
with candle big size (5 days in a week).
16" Inch round Floating arrangement desi rose petals
with candle small size (5 days in a week).
Desi rose flower garlands 6ft. (Mala).
Marigold garlands 3ft. (Mala).
Mix flower gate decoration.
Different mix roses Flower bouquet
Round flower arrangements (Red Roses & Lilly only)
Standing bouquet flower arrangements for Minister
room.
Lilly flower Arrangement 10 flower for table
Total Amount (including taxes, if any)

2.
3.
4.
5.
6.
7.
8.
9.
10.
1l.
12.
13.
14.
15.

one :- ~
31a131m
~
,J

Jl Q ~Cf(i
(flICRlcrll)

*****
\511OiChifI
~

~

~~lh~Oi

~

q:,-jf

Rates

q-~cfr
fcl:n 10i
c..

a:ro24669596 Jt ~

CR~ I(>ill

CR ~

~

61
