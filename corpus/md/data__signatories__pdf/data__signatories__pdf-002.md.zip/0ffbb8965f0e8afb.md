---
doc_id: "0ffbb8965f0e8afb"
source_url: "https://www.mospi.gov.in/uploads/latestReleases/latest_release_1791544164788_4ac0b71d-ff2b-4920-9280-1682573e95f6_Press_Release_for_GSDP_by_Expenditure_Side.pdf"
ministry: "Statistics and Programme Implementation (MoSPI)"
title: "Press Note on Draft Guideline for Compilation Gross State Domestic Product (GSDP) Estimates by Expenditure Approach with Base Year 2022-23"
date: "2026-10-09"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c236434f869addb1"
---

<!-- page 1 -->

Government of India
Ministry of Statistics & Programme Implementation (MoSPI)
National Statistics Office (NSO)
New Delhi
Dated: 09th October, 2026

Press Release

Release of Draft Guideline for Compilation Gross State Domestic Product (GSDP) Estimates
by Expenditure Approach with Base Year 2022-23
The National Statistics Office (NSO), Ministry of Statistics & Programme Implementation
(MoSPI), Government of India, has prepared the draft guideline for Compilation of Gross State
Domestic Product (GSDP) Estimates from Expenditure Side with Base Year 2022-23. The
guideline is being released and uploaded on the official website of MoSPI (link attached below).
The draft guideline provides a uniform and comprehensive framework for compilation of
GSDP estimates from the expenditure side across States and Union Territories, with the objective
of ensuring consistency, comparability and methodological standardization under the revised base
year framework.
The draft guideline elaborates the concepts, coverage, data sources, estimation procedures
and methodologies for compilation of GSDP from the expenditure side, covering the major
expenditure components, including Private Final Consumption Expenditure (PFCE), Government
Final Consumption Expenditure (GFCE), Gross Fixed Capital Formation (GFCF), Changes in
Inventories, Valuables and Net Exports. At present, some States/UTs are compiling estimates of
GFCF and GFCE; however, PFCE estimates are not being compiled by any State/UT. The
document, therefore, provides a comprehensive framework and methodological guidance to
facilitate the compilation of these expenditure components at the State/UT level.
The guideline emphasizes the use of State-specific data sources and appropriate allocation
indicators for estimation of various expenditure components, to the extent feasible. In cases where
direct State-level data are not available, suitable allocation methodologies and relevant indicators
have been recommended for deriving State-wise estimates in a consistent and comparable manner.
The compilation of GSDP from the expenditure side provides an important complementary
approach to the production/income-side estimation of GSDP and would facilitate a comprehensive
assessment of economic activity at the State/UT level. The estimates would also contribute towards
strengthening the State-level national accounts framework and improving the consistency of State
estimates with the methodology followed at the national level.

<!-- page 2 -->

The release of draft guideline is an important step towards harmonization of estimation
practices across States/UTs and strengthening the statistical capacity of State Directorates of
Economics and Statistics (DESs) for the compilation of expenditure-side GSDP estimates.
The draft Guideline is available on the official website of MoSPI
(https://www.mospi.gov.in/uploads/documents/productChartTable/1791542971494Draft%20Guideline%20for%20compilation%20of%20GDP%20by%20Expenditure%20side.pdf)
for wider dissemination and feedback from stakeholders by 28th October, 2026
*****
