---
doc_id: "0bed4a86b3fbac09"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/11/47d9036da5285c45fd5b857b763f6104.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Acceptance of resignation of Shri Manu S., Dy. SGI, High Court of Kerala: Order dated 28.03.2024"
date: "2024-10-21"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "0660951e43c378c2"
---

<!-- page 1 -->

F. No. J-11014/4/2024-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
RRR
Shastri Bhawan, New Delhi,
Dated the 29" March, 2024
ORDER
The President is pleased to accept the resignation of Shri Manu S.,
Deputy Solicitor General of India for the High Court of Kerala, with effect
from 21.03.2024.
2. Consequently, the name of Shri Manu S., Advocate, appearing in the
List ‘A’ of this Department’s Order No. J-11017/9/2021-Judicial dated
03.11.2021, stands omitted.
3. Hindi version of this order will follow.
(Jaspal Singh Dhanju)
Deputy Legal Adviser (Judicial)
Copy (through email) to:
1. PS to Hon’ble Minister of State (Independent Charge) for Law & Justice.
2. PSO to Law Secretary / all the Additional Secretaries and Joint Secretaries in the
main secretariat of Department of Legal Affairs.
3. PPS to Ld. Attorney General of India/PS to Ld. Solicitor General of India.
4. All the deputy SGIs in various High Court, as per list.
5. The Registrar, High Court of Kerala
6. Sh. Manu S., Ex-Dy. SGI.
7. Cash (LA) Section to stop the payment of Shri Manu S., ex-Dy. SGI w.e.f.
21.03.2024,
8. The Pay and Account Office, Department of Legal Affairs, New Delhi.
9. To be uploaded on website of this Department i.e. www.legalaffairs.gov.in under
tab ‘Judicial Section’ in the link “Orders related to empanelment of Advocate for
Union of India”.
10. Hindi Section, Department of Legal Affairs, for translation of this order.
11. Spare copies.
4
Wwe 2.१
०१
(Kumar Gaurav)
Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
