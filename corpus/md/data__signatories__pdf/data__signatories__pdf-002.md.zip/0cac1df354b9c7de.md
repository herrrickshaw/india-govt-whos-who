---
doc_id: "0cac1df354b9c7de"
source_url: "https://www.dahd.gov.in/static/uploads/2026/10/e6833fc466fe9632370baaa7d445741b.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "DAHD’s Operational Guidelines for Part VIII (Livestock Sector Reforms)"
date: "2026-04-10"
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95b6a9feac2ab186"
---

<!-- page 1 -->

No. T-110ilt / 4 / I}}1-LHS-DADF (38710)
Government of India
Dlirying
of Fisheries, Animal Husbandry&
Ministry
-'-Dairying
&
ilp;"ment of Animal Husbandry
Division)
leni*at Husbandry Statistics
Second Floor, Chandralok Building
Delhi - 110001
JanPath, New

Dated L0'h APtit,2026

To
1.

TheSecretary,FinanceDepaftment,GovernmentofAlltheStates/UTwith
legislature (as pet the standatd list)

) TheSecretary,AnimalHusbandry&VetednaryServices,GovetnmentofAllthe
standatd list)

iiu,".l UTs wittr legislatute (as pet the

(Livestock Sectot Reforms) of the Scheme
Part-VIII
for
Guidelines
Opetational
Sub]ect
EY 2026'27 (SASCI 2026-27)
for special,t .i.trrr". to States ro, crpitriirrrrJ.,rrr.r.,
Sir/Madam,

of
Patt vIII (Livestock Seclor Reforms)
I(ndly refer to the subiect cited above and the
(SASCI
to States for Capitai Investment 2026-27
the scheme guidelines fot 'special-arririr,t"
India vide
Ministty of ,Fiirance, Government of
2026-27),issued by Departm*t:_f P_"p.:iil;
opetationai
March' 2026'. The
.27',h
their iettet No.aa(1)/p F-S/2026-2? d;;8-;;;;'
money under Patt -vIII (Livestock
,"
Guidelines for submission of ,ppli"utior[i
^i^rlincentive
S-..to, Refotms) of SASCI 2026-27

are enclosed'

SASCI 2026.27

2,ThisoperationGuidelinesareinadditiontotheDoE,sGuidelinesfor ate requested to
dated21,hMarch,2026.So,alltheStateGovelnmeflts&UTAdministtations
proposals'
,"i". U",f. these guidelines while submitting their

$agat

Advisot (Stats)
advisot.ahs@dahd'nic'in
TeLz 0Lt-2L401473

Copy to:

PTi.]:",
1. Additionai Secretaf}, Public Finance (States)- 110001
No.16098, Kattalrya-Bhzrvanl' New

Department of Expenditwe, Roorn

Delhi

2.AlltheDivisionalHeads,DAHD,IftishiBhavan,NewDelhi_110001
New Delhi - 110001
3. Pr. PPS t" S""'"t"y, DAHD' Krishi Bhavan'
New
2026-27, AHS Division' DAHD'
4. Guard Fite of SASCI (Livestock Sector Refot ms)
Delhi - 110001

<!-- page 2 -->

10.04.2026

No. T-11013 / 4 / 2025- ttErS_DADF (38710)
Government of India
Ministry of Ffsheries, Animal Husbandry & Dairying
Department of Animal Husbandry & Dairying
(Animal Husbandry Statistics Division)
Opetational Guidelines fot Pat- VIII (Livestock Sector Reforms) of the Scheme for
Special Assistance to States for Capital InvestmentFY 2026-27 (SASCI 2026-27)

1.
Objective: The objective of the Part - VIII (,ivestock Sector Reforms) of the scheme
guidelines for 'Special Assistance to States for Capitallnvestment 2026-27 (SASCI 2026-27)'issued
by Department of Expenditure, Ministry of Finance, Government of India vide their letter
No.44(1)/PF-512026-27 (CAPED dated 27'h March, 2026 ts to facilitate the development of a
tobust ecosystem fot the Iivestock sector and to promote the creation of quality infrastructure in
livestock, dairy and veterinary sector.

2.

Outlay: An amount of {31000 crote is earmarked under this Part of the scheme for

FY2026-27. The incentive amounts may be utilized by the State Government/UT Administrations
for capital projects in any sector. However, preference may be given to utilize this amount to
strengthen the Iivestock & vetednary infrastructure Iisted in Annexure I.

3.
Gtouping of States: For providing incentive under SASCI Part- VIII (.ivestock Sector
Reforms), States/UTs have been grouped as follows:
Category
Amount
Eatmatked

A

B

C

D

300

250

150

100

8. Andhra

15 Haryana

23. Arunachal

Pradesh

Ptadesh

2. Madhya

t6 Himachal

9. Assam

(R.s. In

ctore)

L,rst
States/
UTs

ol

1. Uttar
Pradesh

3. Rajasthan
4. Bihar
5. \il/est Bengal

6. Gujarat

7. Maharashtta

10. Chhattishgarh
I 1. Jhatkhand

12.I{arnattka
13. Tamil Nadu
14.Telangana

Ptadesh

I7 Jammu &
IGshmir
18 I{etala
t9 Meghalaya
20 Odisha
2t Punjab
22 Uttarakhand

Pradesh

24.Delhi
25. Goa
26.Manipar
2T.Mizorzm
28. Nagaland
29. Puducherry
30. Sikkim
31. Tripura

4.

Reforms and Incentive Suuctute: Release of incentives under this Part, States/UTs shall
be subject to the fulfiLment of the qualifying critelirz and the score obtained under the performance
crrtetia, as specified below -

4.1 Quali$ring Criteria -

Fot qualifying of incentives under this Part, States/UTs shall fulfil at least five out of the following
six ctiteria as on 30.09.2026 -

<!-- page 3 -->

#
Items
Action
Verification
(, Establishment of Nodal Officers fot the National Drgrtat A certiflcate from Seniorlnstitutional
Livestock Mission (T{DLM) shall be most officer (Addl. Chief
Mechanism for appointeil at ail. levels, from Gram Secretary/
Principal

National Drgital Panchayatf\il/ard level to State Secretary / Secretary) in the
Livestock Mission Headquatters, in accordance with the Animal
Husbandry
(I.TDLIVI)
DAHD's Order No.NDLM Department of
the
Appointment of No.1/2025-26 dated 12h November States/UTs is to be
Nodal Officers

;ubmitted. All accounts need
!o be created & validated in

2025.

lre NDLM -

Bhant

Pashudhan portal.
(ii) Establishment of NDLM Committees namely State Level Copy of the televant Orders/

Institutional
Steering Committees (SLSC), State OMs to be shated with
Mechanism for Level Implementation Committee DAHD.
National Drgrtal (SLIC), District Level Implementation
Livestock Mission Committee pLIC)&Block Level

(]\DLM)

Implementation Committee @LIC),

Constitution of shall be constituted
NDLM Committees

appropriate

^t
OM

administrative levels in accotdance with

the

DAHD's
No.T2001,1,/1,1,/2025-AHS_DADF' (E38162) dated 1.2'h November, 2025.

Ihe States/UTs shall have issued the 3opy of the order for posts

(*) -reatron

rf Integrated Sample crders for the creationof posts against :teation is to be shared with
Survey (ISS) Posts
lhose posts allotted under the DAHD.
lntegrated Sample Suwey (ISS).

1v

Uploading the Daty Ihe States/UTs shall have uploaded A cetificate from MD State
Jata
rhe complete data on dairy institutions D^rty Federation is to be
lata on the NDLM -D^ty Vikas submitted and cross check
Portal.

from NDLM - Dary Vikas

Portal.
.v)

Mapping of

State Ihe States/UTs shall have mapped all A certifi.cate from Senior-

Veterinary Institutions

fie veterinary institutions and Animal most off,cer (Addl. Chief

/ Anirnal Husbandry Husbandry Infrasttuctures - including Secretary/
Principal
[nftasttucture
rospitals, dispensaries, veterinary sub- Sectetary / Secretary) in the
realth centres, laboratoties, diagnostics Animal
Husbandry
:enters, ABC centres, recovely areas, Department of
the
Jog kennels, dog vans, dog shelters- on States/UTs is
to be
\TDLM- Bharat Pashudhan Potal.

;ubmitted and cross check

[rom NDLM

Bhant

Pashudhan Portal.
Vl

Fodder Resoutces Ihe States/UTs shall have prepared 3opy of the relevant Orders/
Plan
and notified a Fodder Resources Plan, CMs to be shared with
as advised in the DAHD's OM No.R- DAHD,
2401 B / 29 / 2\22-Catrle_Div @-23126)

Jated November 24, 2025.

<!-- page 4 -->

4.2 Petfotmance Cdtetia:

Thete ate twelve performance criteria with different weights to assess the quantum of incentive
eligibiJity of aStatefUT. Those are sl.

Iotal

Conditions / petformance indicators

e

No.
1

Updation of Aadhaar & Mobile number of Livestock Owners on NDLM
Bhatat Pashudhan Portal .State-wise targets are given at Annexute -II.
S coi ng n e t

i c: (asse ssn

a.

Upto 50%

-0

d.

)90o/o

-20

en

t upto i 0't'S eptem ber, 20 2 6,)

b. >50o/o and (= 75o/o - 1,0
c. )75o/o and (= 90%- 15

2

.)

^^-^

20

Adoption of Guidelines for Minimum Standards of Veterinary Institutions
(GMSVD of India in accotdance with DAHD's guidelines issued vide OM
No.I(-1 1 / 47 / 2024-LH (E 27 7 7 7) dated 26'h November 2025 and 27'h March,
2026. The States/UTs shall formally adopt the GMSVI of India thtough a
notification or official order in accordance with the DAHD's guidelines latest 20
6y 30.11..2026.The States/UTs shall furnish the.copy of the Notification /Ord,er
cf adoption of GI\{SVI to DAHD along with Action Plan of implementation
cf GMSVI in plrased mal1fler in accordance with OM dated 27'h March,2026.

20

20

Foot and Mou*r Disease €MD) Vaccination following Standard Operating
Ptocedute (SoP) in the round fot which the end date falls between 1" of April
and 30'h Sept2026.
Scoins metic: hssessment oeiod l"Aori/-3AbSebt. 2026)
a. 1\0o/o vaccination coverage following SoP - 0
b. 80-90% vaccination coverage following SoP - 10
c. >90o/o vaccination coverage following SoP- 20
(Baud on NDl,h4 - Bharat Pashudhan portal data)

20

20

20

20

State-wise targets of vaccination coverage following the ptescribed Standard
Operation Procedures (SoP) are at Annexute III.
4

Percentage of provision in State/UT Budget for Fodder DevelopmentT
Veterinary InfrzLstructure Developmentf Livestock Breeding Infrastructurt
Developmefif Ammal Husbandry Infrastnrcture Development in the Vikshir
Bhant- Gaarzntee forRozgar. and Ajeevika Mission Gramin 0/B - GRAMG)7
MGNREGA A ction Plan-2026 -27
ScorinE metdc (rrs on 30.1,1..2026\: BudEetarv Provision (BP) as 0/o of total VBGRAMG/ l,f G l.lREGA Budget
: 0 marks
a. BPl= 2a/o
1=
b. BP>2oiobut
4o/o : 4 marks
c. BP >4o/obut 1= 60/o : 8 marks
d. BP>6o/o but (= 8%o : 72 marks
e. BP>8% but (= 70oh:1,6 marks
: 20 matks
f. BP>10%

<!-- page 5 -->

Filling up the vacantYetfParavet Posts
a. Publication of advertisements for filling up of veterinary posts against the
1
vac ttcy as on 31" March 2026 - latest by 30.1,1.2026
b. Publication of advertisements for fi1ling up of para-vetelinary posts against the
rracaflcy as on 31" March 2026 - latest by 30.11.2026
6 Artificial Inseminatio" (AD coverage as per prescribed Standard Opetating Procedures
(SOP) and tatgets
5

20

1,

icorinE mettic
a. No increase over tafgets - 0 matks
b. Up to 5o/o above targets - 3 marks
c. 5-10% above targets
- 5 marks
o/o
d. Ovet 10 above targets - 10 marks
*Based on NDLM-Bhatat Pashudhan portal data)
State-wise tarEets upto 30'h September. 2026 are at Annexure - IV.
7 Conception rate @ased on NDLM -Bharat Pashudhan potal data)
Scoring metric (atest by 30'h Novembet,2026):
a. < 33oh Conception tate - 0 marks

1

10

1C

10

C

10

b. 33o/o - 40oh Cotception tate - 5 marks
c. > 40o/o Conception rate -10 marks

I Growth rate in milk procurement by Coopetative/ Milk Procurement Centre (A{PC). AlJ
India - Milk procurement Growth CAGR 6%o Baseline.
Scoring metric 0atest by 30'h September. 2026):Incremental Improvement:
a. Growth I 6 o/o over September 2025 Milk procurement - 0 marks
b. Growth ) 6 o/o to I 9o/o over Sep 2025 }t,Ilk Ptocurement - 5 marks
c. Gtowth > 9o/o Sep 2025 Milk Procurement
- 10 marks
(State auerages thall be calculated using we@hted di$riL't au€rager, prEortionate to milk prorurement uolume)

State-wise Milk Procuremefit as in Septemb er 2025 are at Annexure - V.
) Establishment & Functioning of New D^ry Cooperative Societies (DCS) as compared
to State-wise \Mhite Revolution 2.0 targets till 30th September 2026 atAnnexute - VI.
a. No increase over targets - 0 marks
b. Inctease <50oh above targets (fot Underserved Areas 25o/o above tatgets) 3 matks
1C 10
c. Increase is 50-75 oh above targets (for Underserved Ateas 50o/o above
targets) - 5 marks
d. Increase > 75o above targets (for Underserved Areas 600/o above targets) 10 marks
1C Filling up the vacant post as on 31.03.2026 under Integrated Sample Surwey (ISS)

a. Publication of advertisements for filling up of ditect tecruitment posts vacant
as on 31" Match 2026 - latest by 30.09.2026
10
5
b. At least >50oh of posts .vacarnt as on 31,.03.2026 fot ISS filled - latest b1 5
30.09.2026.

1.1.

Livestock Insutance of tatgeted population that is to be insuted during FY 2026-27
State-wise details of targeted population is at Annexute-Yll.
a. Selection of Insurance Company under New Scheme latest by 30'h November, 5
2026 - 5 matks
b. Achieving Insurance targets for.2026-27 undet existing/ new scheme - latest
10
by 30dSeptember,2026
o Insutance < 25oh of tatget : 0 matks
5
o Insurance25o/o-50o/o of target :3 matks
o Insurance > 50oh of tatget : 5 marks
4

<!-- page 6 -->

Stedlization and vaccination of targeted dog population of stray dogs fiom 1" April,
2026 to 30'h September,2026 against the allotted targets in accotdance with the ABC
Rules. State -wise targets are given at Annexure - VIII. (assessment will be based on
the data uploaded on NDLM portal)

1,

Scoring ma[ric:

a. < 70o/o of tatget - 0 matks
b. 70o/o to 80o/o of target - 5 marks
c. ) 900/o of target - 10 marks

1,C

10

t7(

Total

5.

Calculation of Incentive: States/UTs that firlfil the qualiftrng criteria shall be eligible for
incentives based on the percentage of scores obtained undet the petformance criteria, as detailed
below:
SI

icore obtained by state in Second Assessment ncentive asoh of amount eafinarked

No
1

Less than 50 %o

)

2

i0oh to75 oh
Vlore that7l o/n

;0%
100 %

3

6.

States/ Union Tetdtodes will earmark preferably minimum of 20 percent of theit
allocated funds for underserved areas of States/UTs. The State wise list of undetserved
districts zr.e attached as Annexures -IX, which is consist of PM-DDI(Y districts as per the
Ministry of Agdculture and Farmers Welfare, Aspirational Distticts as per NITI Aayog, Hilly
Districts as per the India State of Forest Report 2023, Noth-Eastern Districts as per official
districts within each state, and Arid regions as per the National Rainfed Area Authority. Furthet
Annexure - X is the underserved Blocks as per NITI Aayog's Aspirational Blocks Programme
which are not covered in Aspirational Districts Iisted in Annexure IX.

The Special .Assistance under SASCI 2026-27 is purely for capital investrnent. No
compoflent for expenditue of recurdng nature is admissible under this. The States & UTs with
legislature shall ensure that there is no duplication in funding of the projects apptoved undet the
scheme with either funds provided by the Government of India or any funds of States/ UTs.
Futther, the State/UT Governments shall ensure that there is no duplication in the projects
submitted for approval under different parts of the Scheme for SASCI. States/ UTs, if they wish,

7.

may submit projects of a higher value than the funds allocated, indicating their preferencef priotity.

The balance amount of such projects, over and above of the fund allocated to be borne by the
States/UTs from theil owfl resources.

8.

Submission a:nd Verification:
State Governments/ UT Administrations, upofl completion of the teforms, shall submit a report
alongwith documenrary evidence to the Advisot (Stats) (e-maik advisot.ahs@dahd.nic.in )
Department of Anrrial I{usbandry and Dairying (DAHD), Government of India in the presCribed
fotmat at Annexure XI to Annexute XIII latest by 30.11.2026. DAHD will examine the teports
submitted by States/UTs through an iirternal Committee, to be constituted for the purpose. The
DAHD shall thereafter make recommendations to the Deparlment of Expenditure poE) fot
release of the incentives amount by 31.12.2026. The funds/incentives shall be utilized within the
fnancnlyeat 2426-27 '

*>k*********

<!-- page 7 -->

Annexure - I
Pteferable Items fot Capital Expenditure - Livestock & Yctc;iinary
The States/ UTs is free to propose any capital investment project prefetabll, From the list given
below from the incentive amourit. It may be a fresh as well as last mile feeder for any ongoing
project pteferably aligned with the capex categoties outlined in following tatole.

#
u)

Ltems

Scope

ilnclu4gs

Diagnostic and surgical units,
Veterinary Hospital/ College/ l.-onstfuctlon,
Itaining Infrastructure: to reflovation,
and teaching/aaining blocks,
strengthen last-mile veterinary :xpansion of vetednaty hostels, and labontories for
service delivery and build skilled :olleges, veterinary veterinary colleges.
workforce.

hospitals, dispensaries,

iretednary sub-health

lentfe,

and

ceaching/ttaining
mstitutions.
(ii)

Laboratory Inftastructute: to Establishment or Expenditute
towards
lmprove sutveillance, ffaceability, upgrading
of :stablishing ISO 17025
and quality assurance actoss labotatodes fot disease ;tandards, State Disease
livestock systems.
diagnosis, feed and Diagnostic Labs (SDDLs),
fodder testing, milk and Regional Fodder Testing
miik products quality Labs, Milk and tesidue testing
analysis, and genet-ic labs for cooperatives
profilinE.

(*) Semen Stations, Semen Banks, Establishment or Semen production stations

Artificial

Insemination rpgrading
semen rnd cryogenic storage banks,
Infiastructute, IVF Labs, Genomic ;tations, stofage banks, Project ptoposals that
Labs: to enhance breed quality, tVF labs, Genomic promote private sector
patticipation in livestock,
productivity, and teptoductive Labs.
Jaity, and veterinary service
efficiency.
:lelivery, aligned with GOI
norms (ex: establishment of
Breed Multiplication Fatms),
AI delivery centres and

raining facilities, In-vitro

leri\zatton (IVF)

labs,

Genomic Labs for elite bteed
multiplication.
(t") Livestock Fatms, Bull mother Establishment or Fodder seed production units
farms, sheep, goat, poultry, pig modernization of farms rnd demonstration plots,
farms, Foddet Farms, Heifer [or breeding for bovine Heifet reating centres with
Readng Centres: to ensure genetic lnimals and also for nutritional and health support
conservation, fodder secudty, and :on-bovine animals like systems, Rejuvenation . of
improved female calf survival.
sheep, goat, poultry, pig ryazing lands, water bodies
[atms and young stock [or livestock.
reating, as well as for
[odder cultivation.
(") Vaccine Manufactuting Units: to Facilities of production Expenditure towards GMP
ensure timely and affotdable :f veterinary vaccines :ompliance to make existing
yaccine avatTabltty for naional [or endemic and [acilities GMP Compliant,
:merging diseases.
livestock health programs.
Quality control labs and cold
itorage, Technology transfer
rnd scale-up infrastructute.

<!-- page 8 -->

(", Vetednary Medicine or Ethno- Units for formulation Expenditure towatds GMP
Veterinary
Medicine and production of compliance to make existing
facilities GMP Compliant,
Manufacturing Units: to promote veterinary
rffordable, locally soutced'animtl pharmaceuticals and R&D labs for indigenous
knowledge systems.
healthcare solutions and reduce traditional remedies.
tesis
lntimicrobial
tance.
towards
Mobile Purchasing of MVUs, Expenditure
("") Strengthening of
Veterinary Units (\tIVU$/ New ;ttengthening of purchasing of new Mobile
Y eterrnary Units, purchasing
Mobile Veterinary Units.
:xisting MVUs
of Diagnostic Equipment for
existing MVUs.

(No expenditute of
recuring natufe is
admissible. States/UTs
will have to make
arrangements fot opefation
and maintenance of New

MVUs)
3*) Strengthening of existing Animal Io control of dog bite, Construction of operation
Birth Control (ABC) Center / rabies transmission & theatre & post recovefy ateas,
Establishment of New ABC manage stray dog kennel construction, surgical
population.
Centres:
(a) Caprtal grants up to Rs.35 lakh

to Municipal Local Bodies for
establishment/strengthening of
Animal Birth Control Centres.

equipment
theatre &

operation
stedlization
equipment, dog catching van,
dog shelter.

@) Incentives grant @Rs.2,000 per

dog sterilization and vaccination
(based on the report of NDLM
portal) for execution of capital
works in Municipal Local Body
Ateas.

G) Capital grants to Municipal

Local Bodies up to Rs.30 lakh fot
establishment/strengthening of
dos shelter.
Sreation of new Expenditute towards dung
(i") Sustainable Dairying
Development of manure value 3ompressed Biogas based small, medium & latge
rnd Large Biogas plant bio-gas/ CBG plant and
:hain infrastflrcture

Dury manure value
and
Milk infrastructure
3ooperative

ry

the

chaitr

Federations to promote
rhe Circularity in Dairy

lndustry along with
:lung-based manure
(") Dairy Processing Plant

Lnftastructute
3reation of new as well

Expenditure

towards

lJpgradaion/
upgradaionf newf
of Valuemodernization
of
Dairy
modemization
Product
Added
Processing Plant
Manufacturinq Facility
Note: States/UTs will be responsible for futute maintenance of assets created under
SASCI 2026-27 Patt - VIII.

rs

<!-- page 9 -->

ANNEXURE.II
STATE-WISE TARGET FOR AADHAR & MOBILE UPDATION OF LIVESTOCK
OWNERS IN NDLM-BHARAT PASHUDHAN PORTAL
STATES /UTs

sl.

LIVESTOCK OWNERS

No.
1

Andhra Pradesh

36,65,564

2

Arunachal Pradesh

47.465

.f

Assam

33.50.21.0

4

Bihat

76,27,446

5

Chhattissath

24,55,341,

6

Delhi

19.622

7

Goa

8,570

B

Guiarat

65,1,7,9L0

9

llzryana

19.90.505

10

IIimachal Ptadesh

13.11.295

11.

ammu & IQshmir

18,99,126

1,2

harkhand

22,61.,125

13

{atnataka

69.63.913

1.4

l{erala

11,92,648

15

Vadhya Ptadesh

78,89,190

16

Mahatashtra

68.18.003

17

Manipur

66.309

1B

Veghalaya

1,32,237

1.9

26,489

20

'l4izonm
\aEaland

21.

Cdisha

22

Puducherty

23

Punjab

15.98.040

24

Raiasthan

81,64,840

25

SikLrm

85,872

26

Iamil Nadu

38.88.868

27

lelangana

20,95,770

28

Iripura

3,86,839

29

Uttar Pradesh

7,79,14,7 64

30

Uttarakhand

L2,92,4g5

31.

West Bengal

74,21,900

60.222
35,94,629

22,148

<!-- page 10 -->

ANNEXURE.III
STATE-WISE FMD VACCINATION TARGETS DURING 1"' APRIL TO 3O'h
SEPTEMBER,2026 FOR WHICH THE DATE OF THE ROUND FALLS DURING
THIS PERIOD OF FY 2026.27
States/ UTs

sl.

No.

FMD vaccination Tatget
(Aptil- September, 2026)
(In Lakhs)

1.

Andhta Ptadesh

93.00

2

Arunachal Pradesh

2.00

J

A.ssam

87.00

4

Bihar

217.00

5

3hhatisgath

6

Delhi

1.55

7

.rOa

0.56

B

Gajarat

187.00

9

llaryana

62.00

10

Himachal Pradesh

16.00
24.00

14

ammu & I(ashmir
harkhand
l{arnataka
l{erala

15

Madhya Ptadesh

260.00

16

Maharashtra

172.00

17

2.25

1B

Manipur
\Ieghalaya

19

tllizontr,

0.14

20

Nagaland

0.60

21

Cdisha

78.00

22

Puduchetry

0.78

23

Punjab

60.00

24

Rajasthan

233.00

25

Sikkim

1.05

26

Iamil Nadu

92.00

27

Ielengana

61..21

28

7.30

29

Iripura
Uttar Pradesh

30

Uttarakhand

21.00

S7est Bengal

149.00

1,1,

1,2

13

31

BB.OO

95.00
93.00
10.00

4.10

354.00

<!-- page 11 -->

ANNEXURE.IV
STATE.WI SETARGET S FOR ARTIFICAL INSEMINATI ON (AI) COYERAGE
DURING lsr APRIL TO 30rH SEPTEMBER,2026
Tatgets fot AIs during

States/UTs

sl.

f'April, 2026 to 30'h Sept 2026

No.
1

Andhta Pradesh

2

Arunachal Ptadesh

j

Assam

3,46,059

4

Bihat

1.1,,69,51.0

5

Chhattisgarh

3,23,454

23,30,003
524

6

Goa

7

Gu)^r^t

43,86,11.1,

B

Himachal Pradesh

3,52,428

9

Haryana

20,94,392

10

ammu

2,30,065

tGshmir

2,80,919

1,1

harkhand

7,21,,434

1,2

l{arnataka

34,99,374

13

Ketala

5,26,625

L4

Madhya Pradesh

23,53,841

15

Maharashtta

16,09,076

16

Manipur

4,974

17

Veghalaya

9,105

1B

)dtzoram

1,186

19

)dagaland

7,955

20

Cdisha

4,85,085

21

Punjab

L5,65,327

22

Puduchetty

23,324

23

Rajasthan

12,10,695

24
25

likkim
Iamil Nadu

38,45,979

26

Ielangana

1.1,21,365

27

Iripura

28

Uttar Pradesh

728,1.3,272

29

Uttarakhand

4,40,070

30

$7est Bengal

22,90,9;50

31

Delhi

12,441

11.,021.

56,370

10,350

10

<!-- page 12 -->

ANNEXURE. V
STATE.WISE MILK PROCUREMENT STATUS OF COOPERATIVES/
MILK PROCUREMENT CENTRE (MPC) IN SEPTEMBER 2025
Sl. No.

Lakh Lite Per Day (LLPD)

States/UTs

1

A.runachal Ptadesh*

2

Andhra Pradesh

29.86

J

Bihar

21.47

4

hhattisgarh

0.45
0.36
205.4

7

rOa
3ularat
llaryarra

B

Himachal Pradesh

0.96

9

1.26

10

ammu & IQshmir
harkhand

1.1

Karnataka

101.01

12

Kerala

12.34

13

Madhya Pradesh

9.24

14

Mahatashtra

39.47

15

Manipur

0.01

1,6

\l.eghalaya

0.1.2

17

Mizoram

0.02

1B

Nagaland

0.08

1.9

Cdisha

4.72

20

Pondicherry

1.26

21

Punjab

15.69

22

Rajasthan

24.91

23

Sikkim

24

Iamil Nadu

35.59

25

Telangana

3.53

26

Iripura

0.04

27

Uttar Pradesh

3.30

28

Uttarakhand

2.28

29

Assam

1..33

30

West Bengal

2.04

31

Delhi+

5

6

3.48

2.25

0.5

*Note: Curerutfi there is no procurement in ArunachalPradesh

b Delhi. Tberefore sturt of

procurement before 30'h SEtember,2026 willbe taken as /000k achieuement of target.

1,1

<!-- page 13 -->

ANNEXURE. VI
STATE.WISE TARGETS FOR ESTABLISHMENT & FUNCTIONING OF NEW
DAIRY COOPERATTYE SOCTETTES (DCS) AS PER WHrTE REVOLUTTON 2.0
TARGETS FY 2026-27
Sl. No

New DCS Creation FY 2026-27
April-September
Full Yeat

States/UTs

1

Atunachal Pradesh

2

Andhta Pradesh

3

Assam

4

Bihar

5

26

1.3

240

1,20

166

B3

260

130

202

101

13

lhhattisEarh
Goa
Gularat
Hatyana
Himachal Pradesh
ammu & ISshmir
harkhand
l{arnataka
Kerala

14

Madhya Pradesh

1,044

522

1.5

s06

253

1.6

Vahanshtta
Manipur

60

30

17

Meghalaya

100

50

18

\[izoram

22

1.1

19

)daqaland

18

9

20

Cdisha
Puduchetry

1,244

622

21

22

Puniab

23

24

6

7
B

9

10
11
1,2

25

910

455

374

187

640

320

34

17

5

Raiasthan

1,600

800

iikkim
Iamil Nadu

30

15

324

162

306

153

)elhi

29

748

230
374

244

31

28

460

4BB

30

27

B

51,4

10

lelanEana
I'ripura
Jttar Pradesh
Jttarakhand
West Bengal

26

16

1.028

12

28

14

2,026

1,,01,3

334

167

530

265

6

-)

<!-- page 14 -->

ANNEXURE. VII
STATE.WISE NUMBER OF ANIMALS TO BE INSURED DURING FY 2026-27

Sl. No.

No. of animals

States/UTs

1

Andhra Pradesh

2

Arunachal Pradesh

4,377

J

Assam

69,850

4

Bihar

2,06,28O

5

2,99,385

hhattisgath

59,282

6

Delhi

997

7

Goa

442

B

Gujarat

1,51,668

9

Haryana

36,949

10

Himachal Pradesh

25,198

1,1,

lammu & IQshmir'

58,341
1,24,469

13

Iharkhand
Katnataka

1.4

I(erala

15

Madhya Pradesh

2,O2,081

1,6

Maharashtra

1,89,t83

1.7

Manipur

3,176

1B

Meghalaya

6,055

19

Mizoram

1_,4O9

20

Nagaland

3,096

21

fdisha

98,31,4

22

Puducherry

23

Punjab

37,6L6

24

Rajasthan

3,79,L44

25

Sikkim

26

Iamil Nadu

1,86,448

27

Telangana

2,27,336

28

Iripura

29

Uttar Pradesh

2,88,374

30

Uttarakhand

26,453

31

S7est Bengal

2,12,159

12

2,35,928
13,093

1_,139

1,752

8,506

13

<!-- page 15 -->

ANNEXURE -YIII
STATE.WISE TARGETS OF STRAY DOG POPULATION TO BE STERILIZED
DURING THE PERIOD FROM 1sr APRIL,2026 TO 30rH SEPTEMBER,2026
States/UTs

sl.

No

f argeted sttay dog population ftom 1"'Aptilr2026 tc
i0'hSeptembe42026

1

Andhta Pradesh

96,000

2

Atunachal Pradesh

2,000

-)

Assam

24,000

4

Bihat

78.000

hhattishgath

36,000

6

Delhi

66,000

7

.rOa

8.000

B

9

Guiant
llaryana

10

Himachal Pradesh

4,000

11

ammu & IGshmir

18,000

12

harkhand

44.000

13

l{atnataka

1,,20,000

14

Kerala

15

Madhya Pradesh

1.20.000

1.6

Maharashtra

2,48,000

17

Manipur

4,000

1B

Meghalaya

4,000

19

Mizoram

4.000

20

Nagaland

4,000

21

Odisha

40,000

22

Puduchery

6.000

23

Punjab

62,000

24

Rajasthan

25

Sikkim

26

Iamil Nadu

1,76,000

27

Telangana

70,000

28

Iripura

4.000

29

Uttar Pradesh

2.56.000

30

Uttarakhand

20,000

31

West Bengal

1,92,000

5

1.40.000
58,000

74,000

1,06,000
2.000

14

<!-- page 16 -->

ANNEXURE - IX
The List of undetserved Districts (PMDDKY/ADP/ Hilly/NE Distticts/ARID)
States/UTs

No. of
Distticts

Districts Name

1

Andhra Pradesh

7

Alluri Sitharamarajt, ParwathipuramManyam, YSR l{adapa, Sti Sathya Sai
, Anantapur, Annamayya, I(urnool

2

Amnachal

27

Anjaw, Bichom, Changlang, ISaDaadt, Longding, Namsai, Dibang Valle
g, East l{ameng, East Siang, Siang,I(amle,I(ey Panyor,I(urungl(umey, L
tparada,Lohit, Lower Dibang Valley, Lower Siang, Lower Subhansiri, Pa
kkel(essang, Papum Pare, Shi Yomi, Taw^ng,Tttap, Uppet Siang, Uppet

sl.

No.

Pradesh

Subhansiri. !7est I(amens, West Sianq
J

4

Assam

Bihar

35

Ba1ah, Baksa, Batpeta, Biswanath, Bongaigaon, Cachar, Chataideo, Chira

17

ng, Darrang, Dhemaji, Dhubri, Dibrugarh, Dima Hasao, Goalpara, Gola
ghat, Hailakandi, Hoj ai, J orhat, I(amrup, I(amtup Metto, I(arbiAnglong,
l{oktaJhat, Lakhimpur, Majuli, Marigaon, Nagaon, Nalbari, Sivasagar, So
nitpur, South Salmara-Ma ncachar, Sribhumi, Tamulpur, Tinsukia, Udalgu
ri, \X/est I(arbiAnglong
Nrata, Aurangabad, Banka, Begusarai, Gay a, J amui, I(atihar, I(hagada, M

'naffarpur, Nawada, Purnia, Sheikhputa, Sitamarhi,
Ea, Siwan,I(ishanganj

Madhubani, Darbhan

apur, D askhinB as tarD antew ara, U ttar B as tarl(anker, I(ondaga
cn, I(orba, Mahasamund, Narayanpur, Rajnandgaon, Sukma, Jashpur

5

Chhattisgath

11

B astat, Bij

6

Goa

1

South Goa

7

Gujarat

1,2

B

Harvana
Himachal

.)

Dahod, Narmada, I(achchh, Chhotaudepur, PanchMahals, Jamnaga, Sure
ndtanagat, |unagadh, B anasl(antha, Mahe s ana, Ahmedab ad, Ra j kot
Nuh, Hisat, Mahendragath

9

12

Chamba, Bilashpur, Hamirput, I(angra,ICnnaur,
Kullu,Lahaul&Spiti, Mandi, Shimla,Sirmaur, Solan, IJna

20

B aramul7a, I(upwata, Anantnag, B adgam, B andipora, D o da, Gandetb al, J

Pradesh
10

[ammu &

t(ashmir
1.1

1.2

lharkhand

Karnataka

19

17

1,3

I(erala

10

14

Madhya Pradesh

1,6

15

Maharashtra

19

16

Manipur

16

17

Meghalaya

1,2

lmmu, I(athua,ICshtwar, I(ulgam, Poonch, Pulwama, Rajouri, Ramban,
Reasi, Samba, Shopiyan, Srinagat, Udhamput
Bokaro, Chatra,Dumka, Garhwa, Gfuidih, Godda, Gumla, Hazaribagh,I{
hunti, Lateh a4 Lohatdaga, Pakul, Palamu, ITest Singhbhum, East Singhb
hum, Ramgarh, Ranchi, Sahibgani, Simdega
Raichur, Yadgir, Tumakuru, Chitradurga, I(oppal, Gadag, Haveri, Chikka
ballapura,Belagavr, Chikkamagalutu, Dakshina laannada, I{odagu, Shivam

cgga,UttaralSnnada,BalTatt,Dharwad,Raichur
W ay anad, I(ozhiko de, I(as arago d, I(annur,Ernakulam, I dukki, I{ollam, M
alappuram, Palakkad, Thiruvananthaputam
Barwant, Chhatarpur, Damoh, Guna, East Nimar, Rajgarh, Singrauli, Vid
isha,Anuppur, Dindod, Alirajput, Shahdol, l)rr-Larra, Sidhi, Niwari, Tikam
sarh

Gadchiroli, Nandurb ar, D harashiv, \Washim, P alghar, Y av atrnal, Dhule, R
atl S ambhajinagar,Nanded, B eed, I(olhaput,
aigad, Chandraput, Chh
^ft^p
Nashik, Pune, Ratnagiri, Satara, Sindhudurg, Solupqt
Iamenglong, Chandel, Churachandpur, Bishnupur, Imphal East, Imphal
West, Jiribam, I(akching, I(amjong, Kangpokpi, Noney, Pherzawl, Senap
ati, Tengnoupal, Thoubal, Ukhrul
\West I(hasi
East Garo Hills, East Jaintta Hills, East I{hasi Hills, Eastern
\ff/est
Gato H
Hills, North Garo Hills, fu-Bhoi, South Garo Hills, South
\ff/est
lls, South \X/est I(hasi Hills, West Garo Hills,
Jarnia Hills, \X/est K
rasi Hills
15

<!-- page 17 -->

1B

Mizotam

17

19

)Jagaland

17

20

fdisha

10

21

Punjab

5

22

Rajasthan

17

23

Sikkim

6

24

Iamil Nadu

10

25

Telangana

7

26

Iripura

B

27

Uttar Pradesh

17

28

Uttarakhand

L3

Ltzawl, Champhai, Hnahthial, I{hawzawl, I(olasib, Lawngtlai, Lunglei, M
rmit, Saitual, Setchhip, Siaha
Chumoukedima, Dimapur, I(phire, I(ohima, Longleng, Meluri, Mokokc
hung,-Mon, Niuland, Noklak, Peren, Phek, Shamator, Tseminyu, Tuens
lng, \il7okha, Zunheboto
Balangir, Dhenkanal, G ajapatt, I(alahandi, I(andhamal, I(oraput, Malkan
qiri, Nabarangpur, Nuapada, Rayagada,Sundarqarh
erozepur, Moga, Faztlka, Bathinda, Sanqrur
B aran, B atmer,Jaisalmer, I(arauli, Sirohi, Nagaur, Pali,
Jodhpur, Bikanet,
3huru, Jalo re, Ganganagar, Jhtnjhunu, Jhalawar, Sikar, Ajmet,Hanumang
rth
Sangtok, Gyalshing, Mangan, Namchi, Pakyong, Soreng
Virudhunag ar, Ranananthapuram, Thoothukudi (Tuticorin), Sivaganga,
loimbatore, I(anniyakumari, Madurai, Tenkasi, The Nilgiris, Tirunelveli
Adilabad, Bhadtadril(othagudem, Bhupalapally,Narayanpet, JogulambaG
ldwal,Tangoan,Na garkurnool
Dhalai, Gomati, I(howai, Noth Tripura, Sepahijala, South Tripura, Unak
rti, $7est Triputa
Sahraich, Balrampur, Banda,Chandauli, Chitrakoot, Fatehpur, Hamirpur,
lalaunJhansi,Lalitpur,Mahoba,Pruyagra),PtatapEarh,Shrawasti, Siddharth
l^gar, Sonbhadra, Unnao
A.lmora, B ageshwar, Chamoli,Champawat,D ehradun, Pauri Garhw al, Har
dwar, Nainital, Pithoragarh, Rudraprayag, TehriGarhwal, Udham Singh
Nagar, Uttarkashi

29

West Benqal

Iotal

5

A.lipurduar, Darieeling, lhargrain, I(alingpung, Purulia

380

Y

1,6

<!-- page 18 -->

ANNEXURE - X
ASPIRATIONAL BLOCKS
State/UTs
Andhra
Ptadesh

No. of No. of District Name
Districts Blocks
2
NTR
-)

Block Name
lbrahimpatnam, Penuganchiprolu
Yerragondapalem

Prakasam

Bihar

13

29

Bhagalpur, Bhojpur, Buxar [agdishpur, Pirpainti, Sabour, Sonhaula
Gopalganj, I(aimu: Sultanganj, Behea, Sandesh, Shahput
*Bhabua), Lakhisarai Btahmpur
Madheputa, Munget,
Chakki, Uchkagaon, Bhagwanpur, Chand
PurbiChamparan, Rohtas Kudra, Ramgath, Rampur, Surajgarha
Chausa, Bairy arpur, Dharhara,Jamalpur
Samastipur, Supaul,
Tarapur, I(alyanput, I(esaria, Tilouthu
Vaishali
Hasanpur, ISanpur, Basantpur, Lalganl

Chhattisgarh

B

9

Balrampur, Gariyaband
Shakatgath, Garry aband, Mainpur,
Gaurella-Pendta-Mar.wahi G aarcl7a-2, B odla, B aikunthpur,
t3birdham, I(orea, Mohla A Chowki (Td), Pratappur, Lakhanpur
Manpur, Surajpur, Sutguja

Guiatat

j

4

Dang, Patan,Tapt

H.aryana

4

5

Bhiwani, CharkhiDadri Behal, Loharu, Badhra
Hathin, Nahar

Palwal, Rewati

Jhatkhand

5

1.2

Deoghar,
lamtata,
S

Karnataka

-)

8

araikelal(h

Subir, Santalpur, I(ukarmunda, Nizar

Dhanbad Satath, Sarwan, Devipur, I(arown,
Fatehpur,
I(oderma Govindput,
aw

^ts

^rr,

KatmatanrVidyasagar, Jainagar.
Markacho, Gamhaia, I(ukru, Seraikella

Bidar, Ifulburgi, Y i)ay apura Iaamalanagaru, Aurad, Chittaguppa,

:

Humnabad, Afzalpu4 I(alagi, Shahbadha
Thalikoti
Madhya
Ptadesh

14

Maharashua

4

6

Odisha

5

18

24

Bhind, Dhar, Jhabu a, I{.atni Gohad, Tirla, Meghfl^gar, Rama, Ranapur,

Khargone,

Mandla Thandla, Rithi, Bhagvanpvrq Zuanya,
Motena, Panna, Ratlam Mav ai, N arayangan j, P ahadgarh, Ajaigarh,
Mauganj, Rewa, Satna Bajna, Hanumana, Jawa, Sirmout,
Majhgawan, Rampur Baghelan,I(arahal,
Sheopur, Shivpuri
Sheopur, Vijaypurl(olaras, Pichore
,

Amravati, Hingoli,
[alna, Watdha

Bargarb,

Chikhaldara, Dharni, Hingoli, Badnapur,
Partur, I{aranla

I(eonjhar Palkamal, Banspal, Champua, Jhumpura

Mayutbhanj, Nayagath I(endujharSadar, Patana, Telkoi
Harichandanpur, Jashipur, Thakurmunda,

Sambalput

Bahalda,

Brjatala, Jamda, I(usumi, Rairangput
Tfuinq, D asap alla, Naktideul

17

<!-- page 19 -->

Puniab

4

7

Amdts at, Gutdaspur, J alandha4 I(aputhala Llnala, HarsheChhina, Dera Baba

Nanak, I(alanaut, Shahkot
Dhilwan, Sultanpurl-odhi

Rajasthan

15

15

Kotputali-Bahrog Banswara, Bharatput, Neemtana, Sajjangarh, Vair, I{otari
Chittotgarh Keshoraipatan, Nimbhaheta
Shahpura, Bundi,
,DausaDholpur, Dungatpur, Pali RamgarhPachsrata, Baseri
Prutapgarh, Rajsamand, Gangapur City [honthri, Rani Station, Peepalkhunt
Bheem, Gangapur City, Peeplu
Ionk, Udaipur
Kherwara

Iamil Nadu

10 10 Ariyalur, I(allakurichi, I(anrr, Perambalur, Andimadam, I{alvarayan Hills

Alathur
Pudhukottai, Ranipet, Thinrvannamalai Ihogaimalai,
Ihiruvatankulam, Timd, Jawathu
Iiruchirappalli, Vellore, Villupuram
Hills, Turaiyur, I(V.I(uppam
Ihiruvennainallur

Ielangana

-)

Uttat

29 52

J

Pradesh

Mahabubabad, Mulugu, Nirmal

Gangaram, IGnnaigudem, Pembi

Aligarh, Ambedkar Nagar, Amethi,Ballia Gangiri, Bhiti, Bhiyawn, Tanda
Barabanki, Bareilly, Basti, Bijanaut, Budaun [agdishpur, Jamo, Shukul Bazar,
Deoria, Etah, Farrrrkhabad, Ghaziput Bansdih, Chilkahar, Nindaura

Gonda, Gorakhput, Hardoi, Jaunput, Puredalai, B aheri, F atehganl (\X/est)
Kasganj, I(aushambi, I3eri, I(ushi Nagar, Damkhauda, Harraiya, I(udaraha
N/[.aharajganj, Mlrzapal Pilbhit, Rampur, Kotwali, Najibabad, Ambiapur

Sambhal, Sitapur, St IGbir Nagar, St Ravidas Asafpur, GauriBazatAwagarh
Nagar
faithra, Nawabganj, Rajepur,

Varachahxrat, Virno, Rupaideeh
Babhanjot,
Pandarilftipal

Bansgaon, Brahmput, Sandila,

Machhali Sahar, Ram Pur,
GanjDundwara
Manjhanpur,
Bankeyganj,
Dhaurhara,
Vishunpura, Mithaura, }{al\a.
Amanpur,
Kaushambi,

Patehra, Putanpur, Saidnagar,

Asmauli, Gunnaur, Biswan.
Baghauli,Aurai

West Bengal

Total

B

lndpur, I(hafta-1, Onda.
Maldah, Murshidabad, Medinipur lWest, 24 Khoyrasol, Mayureswar-1, Nanoor,
Panganas
Kumarganj,
Chanchal-1.
South, Dinajput Uttar
[-Iarishchandrapur, Bhagabangola[, Lalgola, I(eshiary, Salbani, Magra
llat-2,
Thakurpukur
Mahestola, Chopra, Goalpokher-1.
Soalpokher-2, Hemtabad.
lslampur, ltahar

22 Bankuta, Birbhum, DinajputDakshin.

130 zzl

Source: NITI AaltogOM Nunber - N -14072/221/2023-ADP (elile-42793), dared 22.07.2025

18

<!-- page 20 -->

ANNEXURE -XI
Fotmat fot applying for the incentives under (Livestock Sector refotms) of the SASCI 202627

To
The Secretary
Depattment of Animal Husbandry & Dairying
Government of India
ISishi Bhavan
New Delhi - 110 001
Sfu,

It is to cettify that our State/UT has fulfilled 5/6 reforms of 6 qualifying refotms as on
31"October,2026 and scored above 50o/o of perfotmance criteria, thereby eligible for incentives
under Part VIII (Livestock Sectot Reforms) of SASCI 2026-27 issued vide DAHD's letter
No.4a(1 ) /P tr -S / 2026 -27 (CAPEX) dated 27'h March, 2026.

Signature
Designation
Seal

Sectetary in-chatge
Animal Husbandry Depatment
Govt of

h/

,/
,s

<!-- page 21 -->

ANNEXURE - XII
Format fot applying for incentive-under (Livestock Sector reforms) of the SASCI 2026-27

1. State Name:

2. Compliance Table
sl. Actions
No.

Documentary Evidence

Compliance
Status

(Yes/No)

2

Establishment of
lnstitutional
Mechanism for

Crder/ Notification of appointment
cf NDLM Officers at all levels from
Gram Panchzyatf Ward level to State

NDLM -

Headquarters - accounts cteated and

appointment of
NDLM Offiecrc
Establishment of
lnstitutional
Mechanism fot

NDLM -

constitution of
NDLM Committees
3

+

Cteation of Posts
Lrnder Integrated
Sample Sutvey (ISS)
Dairy Data Upload

'ralidated in the NDLM - Bharat
Pashudhan portal.
Relevant Orders/ OMs constituting
State Level Steering Committee
(SLSC), State Level Implementation
Committee (SLIC), District Level
Implementation Committee (DLIC)
and Block Level Implementation
Committee (BLIC).
Relevant Orders/ OMs cteatiflg the
allotted posts under Integrated Sample
Survey

Self-certification by MD State/UT

Dnoy Federation and cross check
from NDLM - Dairy Vikas portal
)

Mapping of
Veterinary /

Husbandry
lnstitutions

State Self-certification

by senior most

lnknal officers of State/UT- Addl. Chief
Sectetary/ Pr. Secretary/ Secretary,
Deptt. Of Animal Husbandry &
Veterinary Services and ctoss check
from NDLM - Bharat Pashudhan
portal.

Foddet Resources
Plan

Relevant Otders/OMs notifying the
Fodder Resoutces Plan in compliance
cf DAHD's OM No.R24018/29/2122-Cattle_Div (E23126) dated24'h November, 2025.

20

List of
Enclosed
Documents

<!-- page 22 -->

ANNEXURE. XIII
Fotmat fot applying fot incentive undet (Livestock Sector refotms) of the SASCI 2026-27

1. State Name:
2. Compliance Table

sl.

Actions

Documentary
Evidence

Updation of Aadhaar & Mobile number of
Livestock Owners on NDLM
Bhant
Pashudhan Portal. State-wise targets for data
sanittzatton are at Annexute -II.
Scorins meftic: (assessment ullta l0l

Self-cetification ftom

Seotember.2026)

Animal Husbandry &

No
1

-)

Secretary

/ Secretary, of

Veterinary Service

a. Upto 50%
-0
b. >50o/o and <= 75o - 1,0
c. >75o/o and (= 90o/o- 1,5
d. >900
- 20
2

Senior most officers Addl.
Chief
Secr.etary /Principal

Depattment.

Verification from
NDLM
Bhatat
Pashudhan Portal.

Adoption
of Guidelines for Minimum Standards
of Veterinary Institutions (GMSVI) of India in
accordance with DAHD's guidelines issued vide
OM No.I(-1,1,/47 /2024-LH (E 27777) dated
26'h November2025 and27'h March, 2026.The
States/UTs shall formally adopt the GMSVI of
India through a notification or official ordet in
accordance with the DAHD's guidelines latest
by 30.11.2026. The States/UTs shall furnish the
copy of the Notification/Order of adoption of
GMSVI to DAHD alongwith Action Plan of
implementation of GMSVI in phased maflner.

Relevant Order/
Notification
of

FMD Vaccination following Standard

Self-certification from
ienior most officers Addl.
Chief
3ecretary /Principal

Operating Procedure (SoP) in the round for
which the end date of the tound falls between 1"
of April to 30'h Sept2026.
Scorinq metdc: (assessment period 1" April 30h Seotember- 2026\
<80o/o vaccination coverage following -

". 0

b. 80-90% vaccination coverage following
soP - 10
b. >90o/o vaccination coverage following
soP- 20
(Band on NDL I - Bbarat Pashudban portal data)
State-wise targets of vaccination coverage

following the prescribed Standard Operation
Procedures (SoP) ate at Annexure III.

2t

state/uT Govt.

Secretary

/ Sectetary, of

Animal Husbandry &

Veterinary Serwice
Depattment.

Verification from
NDLM
Bharat
Pashudhan Potal.

of
Compliance List
Enclosed
itatus
[Yes/No) Documents

<!-- page 23 -->

Percentage of provision in State/UT Budget

Eor Fodder Development/ Yetertnary

Relevant VB - GRAMG Action
Plan of State/UT Govt.

lnfrastructure Developmentf Livestock
Breeding Inftastmcture Development/

AnimaL Husbandry Inftastmcture
Development in the Vikshit Bharat
Guarantee for Rozgar and Ajeevika Mission
GRAMG) erstwhile
Gramin 0/B

MGNRE GA Action Plan-2026 -27
ScorinE metric (status as
Budgetary Provision @P) as o/o of totalYBGRAMG Budget
a. BP<= 2o/o : 0 matks
b. BP>2o/obttt 1= 4o/o : 4 matks
c. BP > 4o/obut 1= 60/o : 8 marks
d. BP> 60/o but <= 87o : 72 marks
e. BP> 8% but (= 10oh:1"6 marks
: 20 matks
f. BP> 10o/o
Filling up the v^c fltYetfParavet Posts

a. Publication of advertisements for
filling up of veterinary posts against
the vacancy as on 31't March 2026 latest by 30.11.2026
b. Publication of advertisements for
filling up of para-veterinary posts
against the vacancy as on 3l't March
2026 - latest by 30.11.2026
Artificial Insemination (AI) coverage as per
ptescdbed Standard Operating Procedures
(SOP) and tatgets
Scorins metric
a. No increase over targets-0 marks
Up to 5o/o above targets-3 marks
5
5-I0 % above

b.
c.

targets

-

Relevant Ordets/OMs
ldvertisement.

Self-certification ftom Seniot

most officers

Addl. Chief

Secr.etary/Ptincipal Secretary/
Secretary, of Animal Husbandry &

Vetednary Sewice Department.
Verification ftom NDLM
Bhant Pashudhan Portal.

marks
d. Over 10 o/o above targets-1O marks
@ased on NDLM-Bharat Pashudhan

potaldata)

State-wise targets upto 30s Septembe4 2026
are at Annexure - IV.

3onception rate (based on NDLM -Bharat

Self-certification from Senior

Pashudhan potal data)

most officers

Scoring metric (atest by 30'h Novembet,

Secretary/Pdncipal Secretary/
Secretary, ofAnimal Husbandry &

2026):

a. I 33o/o Conception tate - 0 matks
b. 33Yo - 40o/o Conception rate-S marks
c. (c) > 40oh Conception rate - 10

Vetednary Service Depattment.
Verification from NDLM
Bhant Pashudhan Portal.

matks

22

/

Addl. Chief

<!-- page 24 -->

B

Growth r^te in milk procurement by Self-certification by Managing
Coopenttvef Milk Procurement Centre Director (A4D) State D^ty
(I\4PC). A11 India - Milk procurement Growth

CAGR 6%o Baseline

ScorinE metric fiatest bv 30'h September.
202 6) :Iiicremental Improvement:
a. Growth I 6 o/o over September 2025
Milk procurement - 0 marks
b. Growth > 6 oh to < 9o/o over Sep 2025
Milk Procurement - 5 marks

Federation - which would be cross

checked from NDLM - Dary
Vikas portal

Ptocurement - 10 marks
/State aueragu thall be calculated aing weighted dirtrict
Tuerager, ?rlpzrtionate to milk procurement uolume)

State-wise Milk Procurement as in September
2025 are at Annexure - V.

9

1

Establishment & Functioning of New Duoy
Cooperative Societies (DCS) as compared to
State-wise \)fhite Revolution 2.0 targets ti[ 30m
September 2026 atAnnexure - VL
a. No increase ovef targets - 0 matks
b. Inctease < 50o/o above targets (for
Underserved Areas 25o/o above
targets) - 3 marks
c. Inctease is 50-75 o/o above targets
(for Underserved Areas 507o above
targets) - 5 marks
d. Increase > 75o/o above targets (for
Underserved Areas 60o/o above
targets) -10 marks
Filling up the vacant post as on 31.03.2026
under Integrated Sample Survey (ISS).
a. Publication of advertisements for
filling up of direct recruitment posts

Relevant Orders/OMs of
establishment & functioning of
new DCS

Relevant advertisement and
appointment Orders.

vacant as on 31't March 2026 -

latest by 30.09.2026
b. At least >50% of posts vacant as on

31.03.2026 for ISS filled by
3OthSeptember, 2026 - latest by
30.09.2026

1,1

Livestock Insurance of targeted population
that is to be insured dudng FY 2026-27.
a. Selection of Insurance Company
under New Scheme latest by 30th
November,2026 - 5 marks
b. Achieving Insurance targets for
2026-27 under existing / new
scheme - latest by 30.09.2026
o Insurance 125o/o of target: 0 marks
o Insurance 25o/o-50o/o of target: 3

Relevant orders of selection of
Insutance Company.
Achieving Insurance Targets

Self-certification from Senior

most officers

& Veterinary Service Department.

Verification from NDLM
Bharat Pashudhan Potal.

marks

o Insurance ) 50o/o of target :

5

marks
23

,%

Addl. Chief

Secretary/Principal Secretary/
Secretary, of Animal Husbandry

<!-- page 25 -->

1,

Sterilization and vaccination of tatgeted dog
:opulation of stray dogs from 7''1lpr[,2026
:o 30'h September, 2026 against the allotted
:argets in accordance with the ABC Rules.
State -wise targets are given at Annexute VIII. (assessmerit will be based on the data
"rploaded on NDLM portal)
Scoring metric:

Self-certification ftom Senior
most officers Addl. Chief
Secretary/Principal Secretary/
Secretary, of Animal Husbandry

&

Vetednary

Service

Department. Vedfication from

NDLM
Portal.

0 marks
a. <70oA of target b. 70o/oto 80% of target 5 marks
10 marks
c. > 90Yo of target -

3. Certification

. Authorized Signatory detaiis
o Dat€, Seal and Signature

24

Bharut Pashudhan
