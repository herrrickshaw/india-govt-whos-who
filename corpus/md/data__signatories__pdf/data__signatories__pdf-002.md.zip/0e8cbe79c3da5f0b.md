---
doc_id: "0e8cbe79c3da5f0b"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/07/ecca49e403f9cf5a1b7339d7dcaffede.pdf"
ministry: "Tourism"
title: "Tender for conceptualization, design and construction of India pavilion at ITB 2024, Berlin on 5th-7th ,2024."
date: "2024-01-16"
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f51ebdae7e2d24e5"
---

<!-- page 1 -->

<!-- page 2 -->

GOVERNMENT OF INDIA
MINISTRY OF TOURISM
MARKETING & PROMOTION (INTERNATIONAL) DIVISION
TENDER DOCUMENT
Date 16/01/2024
Tender No. OM/1/2023-OM-Part(9)-ITB
Tender for Design & Construction of India Pavilion at ITB 2024, Berlin on
5th-7th, March 2024.

1.

BRIEF DESCRIPTION OF THE PROJECT

The Ministry of Tourism, Government of India regularly participates in major
international Travel Fairs and Exhibitions, including ITB 2024, Berlin.
The Ministry of Tourism requires the services of a professional agency or
or Consortium of professional agencies (maximum two agencies i.e 1 lead
agency + 1 Partner may form consortium) for conceptualization, design and
construction of India Pavilion and providing other related ancillary services (as
detailed under the Scope of Work in this document) in ITB 2024, Berlin.

1.1

1.2 The Indian Pavilion at ITB 2024, Berlin should present India as a multifaceted destination that combines an ancient culture and heritage with a
modern, innovative and vibrant present. The pavilion should be open,
minimalistic and impactful. The essence of a visit to the pavilion should be
experience based and visually appealing with use of various technologies. The
aim of the India Pavilion is to give the visitor, experience of visiting India as a
tourist, focusing on its varied tourist attractions.

1.3 The India Pavilion has co-exhibitors including Tour Operators, Travel
Agents, Hoteliers, Airlines and State Governments, who are provided space
within the Pavilion to showcase their tourism products and packages. The
Pavilion will provide each of the co-exhibitors with self-contained booths of
4 sq. mtr each. Larger spaces will be provided in multiples of 4 (i.e 8 sq. mtr.
12 sq.mtr. and so on).

2.

ELIGIBILITY CRITERIA

2.1. A professional agency with an annual turnover of Rs. 4.00 crore or more (if
Annual turnover of agencies in USD /Euro, etc. the same should be converted
and quoted in INR using official exchange rate of the Ministry of External Affairs,
Govt. of India for the month of December 2023 at Annexure-5 below) during the
financial year 2021-22 or 2022-23 (Audited) or during Calendar year 2021
(Audited) or during the Calendar year 2022 (Audited) as the case may be.

<!-- page 3 -->

2.2. Previous experience of handling work of conceptualizing, designing and
construction of Pavilion of the size 500 sq. mt. at minimum three (3)
international fairs and exhibitions, held overseas during the Financial Year
2018-19, 2019-20, 2021-22 and 2022-23. Out of the three projects one
project should be for Government (Central / State or Foreign Govt.) / PSU
organization (Event conducted virtually will not be counted).

2.3. Relaxation of norms for SMEs will be as per the instructions of Government
of India.
Name of
theEvent

Month
&Date
the event

ITB-Berlin 2024

05 to 07,
(ReferTo Annexure March 2024
4 for floor plan)

City
& Space
of Country hired for
India
where
Pavilion
held
Berlin,
Germany

705
Mt.

Estimated No. of
booths
required in
India Pavilion

Sq. 50-55 individual
booths of 4
. each and 10-12
larger
booths
ranging from 8-12
Sq. Mt.

4.

SCOPE OF WORK

4.1

Conceptualization, designing and construction of India Pavilion and
providing other related ancillary services, as detailed in the Specifications
and Requirements in para-5 of this tender document, at ITB 2024, Berlin.

4.2

The scope of work will include providing water supply fittings in the
cafeteria and electrical fittings in the pavilion / and in all booths of coexhibitors as per requirements, as well as daily cleaning of the pavilion
during the course of the exhibition.

4.3

The scope of work will include construction of the pavilion at site well in
time, maintenance and cleanliness activities, during the event and
dismantling of the pavilion after the event.

4.4

All the other ancillary works relating to India Pavilion like printing of
participant’s directory, providing ethnic uniforms for staff working in the
India Pavilion, providing storage area including pantry with provision for
tea/coffee, drinking water, microwave oven, refrigerator providing
backdrop for Press Conference organised during the event are also
included in the scope of work.

4.5

The design must be made adaptable to the booth space as specified above.

4.6

The agency will be responsible for storage and transportation of reusable
material for the events covered in this tender.

<!-- page 4 -->

4.7

The India Pavilion must have a fresh look at ITB 2024, Berlin and must not
appear jaded or worn-out due to normal wear and tear or damage to the
material used / re-used.

4.8

The Electricity and all expenditure including miscellaneous charges
relating to the space raised by the organizer of the event will be all
inclusive in the quoted amount by the agency while submitting the bid.

5.

SPECIFICATIONS AND REQUIREMENTS

5.1

India Pavilion at ITB Berlin 2024, will have 50-55 individual booths of
4 Sq. Mt. each and 10-12 larger booths ranging from 8 -12 Sq. Mt. for
co-exhibitors in the pavilion. This may vary depending on the registrations
received.

5.2

The Pavilion should reflect an open and inviting look, with minimum
barriers and have a professional; business type lay out conducive for
conducting buyer–seller meetings. Material and other items used for
construction of India Pavilion should be of international standards
and should adhere to the specifications prescribed by fair authorities.

5.3

The Pavilion should focus on the brand Incredible India — as its campaign
tagline to revive international tourism along with effective ‘Incredible India’
branding.

5.4

There should be a dedicated activity area for cultural performances, yoga,
sari tying and mehndi demonstrations etc.

5.5

Modern technology including 2 large LED video screens/walls should
be incorporated in the Pavilion. The video wall / screen should be of
6m x 2.5 m of 1.9 micron pitch would have static displays for photo
opportunities as well as for running loops of Incredible India
promotional films.

5.6

There should be easy accessibility to and within the Pavilion and double
sided signage for all participants/ co-exhibitors in the Pavilion.

5.7

The India Pavilion at ITB 2024, Berlin should have:

•

Prominent and visible signage.

•

Visible and prominently located Reception area with Information Counters.

•
•

A VIP lounge, comfortable enough to hold press interviews, meetings, etc.
Individual storage with locking provision, with visible fascia (i.e company
name of all Co-Exhibitors / participants properly displayed)
A separate larger, covered storage area for use by Ministry of Tourism.
Designated areas for activities such as mehndi application, handicraft
display / demonstrations, cultural performances, etc.

•
•

<!-- page 5 -->

•

Office space, with working desks and chairs.

•

A Cafeteria/Restaurant area.

•

A Pavilion plan display in four corners of the pavilion indicating the
placement of booths with booth numbers, for facilitating visitors and
business contacts of the co-exhibitors.

•

Internet connectivity and individual electrical connections.

•

Greenery/Plants to be placed within the Pavilion.

5.8

Optimum use is to be made of the first / mezzanine floor at ITB 2024,
Berlin where permissible, in keeping with the overall theme and décor of
the Pavilion.

5.9

The Pavilion should be erected on a raised platform of 2 inches and all
images displayed will be back lit in the form of Translates.

5.10 The space earmarked for common facilities including activity area will be
restricted to 30% of the total area of the Pavilion, whereas 70% of the area
of the Pavilion will be for booths / areas for participants in the Pavilion.
This may change depending on the registrations received.

5.11 The responsibility for required insurances and other formalities and
adhering to local laws and rules/regulations/requirements
organisers of the event would be the responsibility of the agency.

of

the

5.12 The agency should ensure that the India Pavilion is fully constructed and
ready to use latest by 1800 hrs. on the previous day prior to
commencement of ITB 2024, Berlin.

6.

PRE-BID MEETING:

6.1

A pre-bid meeting will be held for the interested bidders in the Conference
Room, Ministry of Tourism, Government of India, Transport Bhavan,
and 1 Parliament Street, New Delhi 110001 at 1100 hrs. 22/01/2024, for
clarifications required on any aspect pertaining to the tender Document.
Any change in the pre-bid meeting schedule will be notified on the Ministry
of Tourism’s website www.tourism.gov.in. The pre-bid queries could be
sent to the Ministry of Tourism prior to the meeting till 1500 hrs on
19/01/2024 as per the following format:S. No.

6.2

Tender
Clause No.

Page No.

Current
requirement

Clarifications
requested

Based on discussions held during the pre-bid meeting, amendments /
clarifications in the tender Document will be hosted on the websites of the
Ministry of Tourism www.tourism.gov.in and on e-procure website of the
Government of India on or before 1700 hrs. On 24/01/2024.

<!-- page 6 -->

7.

GUIDELINES FOR SUBMISSION OF BIDS:

7.1

Bids for construction of India Pavilion at ITB 2024, Berlin should be
submitted in two covers (Cover-I Technical & Cover-2 Financial) as per
following:

7.2

Superscribed “Technical Bid - Tender for Design & Construction of India
Pavilion at ITB 2024, Berlin should include following documents/details:

(i)

Details of the Tenderer / Bidder

•

Copy of PAN Card & GST Registration certificate (or Income Tax Account
Number as applicable for overseas bidder).

•

Chartered Accountant certificate only, indicating turnover of the company
during the financial year 2021 or, financial year 2021-22 (Audited) or,
Financial year 2022-23 (Audited) or, calendar year 2022(Audited) in
support of fulfilling the requirement as indicated at clause 2.1 to the RFP,
to be submitted. Duly signed certificate from Chartered Accountant only
will be accepted as supporting document.

•

Profile of the Agency / Company (lead agency in case of Consortium).

•

Details of Technical Manpower and Staff available in–house with the
bidding agency (both the partners in case of consortium).

•

Track record of the agency (lead agency in case of consortium) - details of
experience of setting up Pavilions/ Booths/Stands at International Fairs /
Exhibitions in an area of 500 Sq. Mts and above held overseas during the
four years i.e 2018-19, 2019-20, 2021-22 and 2022-23 with copies of
relevant work orders mandatorily and Client completion certificates
preferably in support of the details furnished. The work order & client
completion certificates should indicate name of the fair, date, month and
year of the fair and total area hired for construction of Pavilion / Booth /
Stand.
•

Details of Pavilions / Stands / Booths designed and constructed for other
countries at various International fairs / exhibitions held overseas
during the four years i.e 2018-19, 2019-20, 2021-22 and 2022-23 with
copies of relevant work order mandatorily and Client completion
certificates preferably in support of the details furnished.
Fact sheet of experience shall be given the below Table format

Name Date Area
Hired Entity for which
of the of the
For
Pavilion was
event Event construction constructed and also

Completion
Certificate
Reference No

Work
order with
reference

<!-- page 7 -->

of the
pavilion in
Sq mts.

indicate Govt/
Pvt/PSU/ Foreign
Govt

with the page
number on
which the
Document
is attached

No
with
the
page
no
on
which the
document
is
attached

•

The Bidder (both the agencies in case of consortium bidding) shall not have
been declared ineligible for corrupt or fraudulent practices with any
Government departments/ agencies/ ministries or PSU’s and should not
be blacklisted at the time of submission of bid. Further, bidding agencies
should submit an undertaking agreeing to undertake the assignment in
accordance with the Scope of Work and terms and conditions detailed in
the tender document. A declaration by the authorised representative of the
bidding agency, on the letter head of the agency, to be submitted as per
format given in Annexure 1.

•

In case of bidding by a consortium, a copy of MoU / Agreement for forming
consortium duly signed by both the partners and clearly indicating the
name of the lead agency in the consortium to be submitted.

(ii) The Concept/ Design of the India Pavilion at ITB 2024, Berlin with detailed
layout, decoration plan, etc. should be submitted online.

(iii) BID SECURITY/BID SECURITY DECLARATION
A Bidder is required to submit, along with its Bid, Bid Security Declaration
as per Annexure - 3 (the, Bid Security Declaration) accepting that if they
withdraw or modify their Bids during period of validity etc. they will be
barred from submission of Bids in any Works/Service tender issued by
Ministry of Tourism, Government of India for a period upto 5 (five) years. The
Bid shall be summarily rejected if it is not accompanied by Bid Security
Declaration. The Bid document shall be available free of cost through
e-Procurement Portal and Ministry of Tourism Website.)
The Bidder shall furnish as part of its Bid, a Bid Security Declaration.
Any Bid not accompanied by the Bid Security Declaration shall be summarily
rejected by the Authority as non-responsive.
The Authority shall be entitled to bar the Bidder from submission of Bids in any
Works/Service tender issued by Ministry of Tourism, Government of India for a
period upto 5 (five) years as Damages inter alia in any of the events specified.
The Bidder, by submitting its Bid pursuant to this RFP, shall be deemed to have
acknowledged and confirmed that the Authority will suffer loss and damage on
account of withdrawal of its Bid or for any other default by the Bidder during

<!-- page 8 -->

the period of Bid validity as specified in this RFP. No relaxation of any kind on
Bid Security declaration shall be given to any Bidder.
7.3 Superscribed “Financial Bid” – Tender for Design & Construction of
India Pavilion at ITB 2024, Berlin.
(i) The financial bid for ITB 2024, Berlin must be submitted as per Performa at
Annexure- 2.
(ii) Financial bids of technically qualified agencies will be evaluated on the basis
of total cost for event (i.e cost quoted for ITB 2024, Berlin) exclusive of
taxes/GST.
(iii) GST / Taxes as applicable will be paid by the Ministry of Tourism
(iv) The bid of the agency will be treated as unresponsive in case of a mismatch
while quoting financial cost between figure and words, or mismatch between
per sq. mtr. Rate and total cost.
(v) The financial bid should be in Indian Rupees (INR). If, however, the Agency has
formulated costs in a currency other than Indian Rupees (INR), for the sake of
uniformity and comparison, the same may be converted to Indian Rupees (INR)
as per the official exchange rate of the Ministry of External Affairs (MEA),
Government of India for the month of December 2023.

Official MEA exchange rates for the month of December 2023 in
respect of some of the leading currencies:
Foreign Currency

INR (December 2023)

1 US Dollar

Rs. 84.02

1 Pound Sterling

Rs. 105.51

1 Euro

Rs. 92.42

To view the official currency exchange rates of MEA for the month of
December 2023 bidders may refer to Annexure-5.
(vii)

The cost quoted will be firm (in the currency quoted) and fixed for the
duration of performance of the contract. At no point of time will any
deviation from the quoted rate (in the currency quoted) be entertained
by the Ministry of Tourism.

(viii) The Financial Bid shall not include any conditions attached to it and any
such conditional financial proposal shall be rejected summarily.

7.4

Submission to be in electronic form

<!-- page 9 -->

The Applicant shall submit his bid in the electronic form on or before 1200 hrs on
06/02/2024.
7.5

Documents to be signed by Authorized Representative

Proposals along with all the scanned copies of the document should be submitted
in the electronic form only through online portal as mentioned above. Before the
proposal documents are uploaded, all attached documents should be signed by
the authorized representative (the “Authorised Representative”) and in case of
consortium by the Authorized Representative of the Lead Member as detailed
below:
(i)

by the proprietor, in case of a proprietary firm; or

(ii)

by a partner, in case of a partnership firm and/or a limited liability
partnership; or

(iii) by a duly authorized person holding the Power of Attorney, in case of a
Limited Company or a corporation.
7.6 Power of Attorney for Authorised Representative
A copy of the Power of Attorney for Authorised Representative (in case of
Consortium by Authorised Representative of Lead Member of Consortium) certified
under the hands of a partner or director of the Applicant and notarised by a
notary public in the form specified in Appendix-I (Form- 3/4) shall accompany the
Proposal.
7.6.1 Those bids sent off line will not be entertained.
7.7 All documents submitted by the agencies should be signed and stamped
(seal of the company) on each page by the authorised signatory of the company.
The document should be spiral bound, duly page numbered, and properly
indexed. The agencies who do not submit their bids in the proper format, with
required documents and in the required format will be liable for rejection.
7.8 The agencies submitting their bids should also mention that they agree to the
terms and conditions mentioned in the tender document.
8.

OPENING OF BIDS AND SELECTION PROCEDURE:

8.1

Technical bids will be opened at 11.00 hrs. on 07/02/2024 to ascertain
fulfilment of eligibility criteria and submission of required documents.
Thereafter, a Constituted Committee will evaluate the Technical Bids of
the agencies which are found eligible after initial scrutiny of the bids.
Evaluation of technical bids of the eligible agencies would be based on
documents furnished in support of items at Sr. No. (i) of the table in Para
8.2. In respect of items at Sr. No. (ii) to (vi) of the table, the evaluation
would be on the basis of presentation on Concept & design to be made by
the eligible tenderers/agencies before the said Constituted Committee in

<!-- page 10 -->

the Ministry of Tourism. Date, time and venue of the presentations will
be conveyed to the eligible agencies.
8.2

The technical bids will be judged following the criteria as detailed
below:
S.No.

Component

(i)

Experience in setting up of Pavilions/ Booths/ Stands
at International Fairs / Exhibitions in an area of
500 Sq. Mt and above held overseas during four years
2018-19, 2019-20, 2021-22 and 2022-23

Marks
60 marks

(12 marks per fair & exhibition for a maximum of
60 Marks)
(ii)

Concept & Design of Pavilion

25 marks

(iv)

Effective Utilisation of Space including the first /
mezzanine Floor

5 marks

(v)

Effective Branding in the Pavilion

5 marks

(vi)

Innovative ideas and other attractions in the Pavilion

5 marks

Total

100 marks

8.3

Whereas, Technical Evaluation will carry a weight age of 70%, financial
bids will carry weightage of 30% . The agencies scoring 70 per cent marks
(70 marks) or above in the Technical Evaluation shall be eligible for
opening of their financial bids.

8.4

The financial bids of only those agencies that score 70% per cent marks
(70 marks) or above in Technical Evaluation will be opened in the presence
of their representatives. The date and time of opening of the financial bids
will be conveyed to the selected agencies. Financial evaluation will carry a
weightage of 30 Marks.

8.5

The agency which scores the highest aggregate marks on the basis of
technical and financial evaluation (after adding the scores from the
technical and financial evaluation) will be awarded the contract for
construction of the India Pavilion at the event.

8.6

The Financial Bid is to be submitted, based on space of 705 sq. mtr.
at ITB 2024, Berlin. In the event of any change in the space booked
for the India Pavilion, the total cost (exclusive of taxes) quoted by
the agency would be reduced / increased on pro-rata basis (on per sq.
mtr. basis).

<!-- page 11 -->

9.

Terms of Payment: No advance payments will be made. Payment will be
made to the successful bidder as per the following schedule:

9.1

Payment of 50% of the total contractual amount will be made by
electronic transfer as per the Bank details received from the successful
bidder on timely completion of construction of the Pavilion authenticated
by the concerned officer of the Ministry of Tourism, Government of India.

9.2

Payment of 50%of the total contractual amount will be made through
electronic transfer as per the Bank details received from the successful
bidder after obtaining a certificate from the concerned officer of the
Ministry of Tourism, Government of India on completion of the Travel
Mart, dismantling the pavilion and clearing of the site satisfactorily by the
agency as per the scope of work and in accordance with the terms and
conditions of the Work Order issued to the Agency.

10.

ADDITIONAL INFORMATION

10.1 The Ministry of Tourism reserves the right to reject or accept any offer
without assigning any reasons whatsoever.
10.2 Incomplete and conditional bids will be rejected outright.
10.3 Any Displays / Translites produced for the India Pavilion at the events
will be the property of the Ministry of Tourism, Govt. of India, on
completion of the contractual period.
10.4 Design selected for the India Pavilion at ITB 2024, Berlin will be the
property of the Ministry of Tourism. The Ministry of Tourism reserves it
right to use the same design for other fairs organised / participated by
the Ministry of Tourism and its field offices in India and overseas.
10.5 The selected service provider will ensure that the design,
construction and maintenance of the India Pavilion are in
compliance with the regulations issued by the fair/exhibition
organisers including insurance as applicable.
10.6 The successful agency will execute a Performance Guarantee for 10% of
the total value of the contract in the form of Account Payee Demand
Draft or a Bank Guarantee from a Commercial Bank in an acceptable
form or in the form of a Fixed Deposit Receipt pledged to the ‘Pay &
Accounts Officer, Ministry of Tourism’ payable at New Delhi. The
Performance Guarantee should remain valid for a period of 60 days
beyond the completion of the period of contract. The Security
Deposit/Bank Guarantee will be released after satisfactory completion of
the contractual obligation on part of the agency.
10.7 The Ministry of Tourism is however not bound to accept any tender or to
assign any reason for non-acceptance. The Ministry of Tourism reserves

<!-- page 12 -->

its right to accept the tender either in full or in part. Conditional,
erroneous and incomplete Bids will be rejected outright.
10.8 The Ministry of Tourism reserves its right to summarily reject offer received
from any agency on national security considerations, without any
intimation to the bidder.
10.9 The Ministry of Tourism reserves the right to place an order for the full or
part quantities under any items of work under scope of work.
10.10 Agencies submitting proposals will not be permitted to alter or modify their
bids after expiry of the deadline for receipt of bids.
10.11 The Ministry of Tourism reserves its right not to accept bids from agencies
resorting to unethical practices or on whom investigation/enquiry
proceedings has been initiated by Government Investigating Agencies /
Vigilance Cell.
10.12 Penalty Clause:
The agency would have to submit Performance Guarantee for amount
equivalent to 10% of the value of the contract after the contract is
awarded to it. The same shall be liable to be invoked amount appropriated
to the government account in full or part in case of underperformance by
the agency, besides other action, including blacklisting of the agency as
may be deemed fit by the Ministry of Tourism, Govt. of India as per details
given below:
(a)

(b)

(c)

In case it is noticed that agency has been unable to deliver any
work enumerated in the Scope of Work or specified by the Ministry
of Tourism in part as enumerated under each item of work, penalty
@ 2% of the total cost quoted against component at Para 2 (a) of the
financial bid format at -2 i.e ‘Construction, maintenance &
dismantling of the India Pavilion work would be imposed.
In case, the agency has compromised on quality of construction of
India Pavilion / deviation from the approved design, penalty upto 10%
of the total cost quoted against component at Para 2 (a) of the financial
bid format at Annexure-2 i.e ‘Construction, maintenance &
dismantling of the Pavilion work would be imposed.
In case of any other deficiencies in execution of the project, a
Committee of officers of appropriate level decided by the competent
authority will decide on damages to be recovered and/or other
action to be taken, after examining all aspects of the case.

10.13 Liquidated Damages: In the event of service provider’s failure to complete
the work within the specified time as indicated at clause 5 above, and as
per the requirements of standards of quality constructions, as mentioned
in the tender document, the Ministry of Tourism will recover from the
service provider, as Liquidated Damages, a sum of 2 % of the total cost of
the contract for every hour’s delay beyond 1800 hrs. of the previous day

<!-- page 13 -->

till 0700 hrs. on the day of commencement of the Fair. In case, the agency
fails to handover the stand fully constructed in all respect for use by the
Ministry of Tourism by 0700 hrs., the total cost of the project payable
would be forfeited, besides, the Ministry may take action to debar the
agency from participation in future tenders and/or blacklist the agency
10.14 Validity of Tender: Period of validity of the Tender is 120 days from the
closing date of the proposals. If need be, necessary extension would be
considered by the Ministry of Tourism.
10.15 Insurance: Insurance, including transit insurance will be arranged by the
service provider.
10.16 Termination by default: Ministry of Tourism reserves the right to
terminate the contract of any agency in case of change in the Government
procedures or for unsatisfactory services.
10.17 Risk – Purchase Clause: If the service provider, after submission of
tender and the acceptance of the same, fails to abide by the Terms and
Conditions of the tender document or fails to complete the work within the
specified time or at any time repudiates the contract, the Ministry of
Tourism will have the right to:

a) Forfeit the EMD
b) Invoke Security Deposit / Performance Bank Guarantee, debar it
from participation in further tenders, can initiate action to recover the
liquidated damage and consider black listing of firm.

c) In case the Ministry gets the incomplete job completed through
alternative sources and if price of completing the work is higher, the
service provider shall pay the balance amount incurred by the
Ministry for completing the work, to the Ministry.

d) For all purposes, the work order accepted by the bidder and issued
by the Ministry of Tourism will be considered as the formal contract.
10.18 Force Majeure: Neither party will be liable in respect of failure to fulfil its
obligations, if the said failure is entirely due to Acts of God,
Governmental restrictions or instructions, natural calamities or
catastrophe, epidemics or disturbances in the country. If there is a delay
in performance or other failures by the service provider to perform its
obligation under its contract due to event of a Force Majeure, the service
provider shall not be held responsible for such delays/failures. If a Force
Majeure situation arises, the service provider shall promptly notify the
Ministry in writing of such conditions and the cause thereof providing
sufficient and satisfactory evidence immediately on occurrence of such
event. Unless otherwise directed by the Ministry in writing, the service
provider shall continue to perform its obligations under the contract as
far as reasonably practical, and shall seek all reasonable alternative
means for performance not prevented by the Force Majeure event.
10.19 Arbitration:

<!-- page 14 -->

(a) In event of any dispute or difference between the Ministry and the
Agency, such disputes or differences shall be resolved amicably by
mutual consultation. If such resolution is not possible, then the
unresolved dispute or difference shall be referred to arbitration of the sole
arbitrator to be appointed by the Secretary, Ministry of Tourism on the
recommendation of the Department of Legal Affairs, Government of India.
The provision of Arbitration and Conciliation Act, 1996 (No.26 of 1996)
shall be applicable to the arbitration. The Venue of such arbitration shall
be at New Delhi or any other place, as may be decided by the arbitrator.
The language of arbitration proceedings shall be English. The arbitrator
shall make a reasoned award (the “Award”), which shall be final and
binding on the Ministry and the Agency.
The cost of the arbitration shall be shared equally by both the parties to
the agreement i.e. the Ministry and the Agency (ies) and the service
provider. However, expenses incurred by each party in connection with
the preparation, presentation shall be borne by the party itself.

(b) Pending the submission of and /or decision on a dispute, difference or
claim or until the arbitral award is published; the Ministry and the
Agency shall continue to perform all of their obligations under this
Agreement without prejudice to a final adjustment in accordance with
such award.
10.20 Jurisdiction: The contract shall be governed by the Laws of India.

R. K. Bhati
Assistant Director General
Marketing & Promotion (International)
Ministry of Tourism
Government of India,
New Delhi

<!-- page 15 -->

ANNEXURE - 1
To be provided on ‘Company letter head’

The Asst. Director General
Marketing & Promotion (International)
Ministry of Tourism
Transport Bhawan,
1, Parliament Street,
New Delhi
Subject: - Undertaking
Madam / Sir,
This has reference to the Ministry of Tourism’s Tender no.………………
dated …………. for Design & Construction of India Pavilion at ITB 2024,
Berlin.
In this context, I / We as an authorized representative(s) of company
certify the following:(a)

That we are not declared ineligible for corrupt or fraudulent
practices with any Government departments/ agencies/ Ministries
or PSU’s and are not blacklisted on the date of submission of this
bid.

(b)

That we will undertake the assignment, in accordance with the
Scope of Work and the terms & conditions detailed in the tender
document and at the cost submitted by the agency in the financial
bid (Cost should not be mentioned in this undertaking).

Name of the Bidder: ..................................
Authorised Signatory:.................................
Name:
Seal:
Date:
Place:

<!-- page 16 -->

ANNEXURE – 2
Format for Financial Quote details

To be provided on ‘Company letter head’
The Asst. Director General
Marketing & Promotion (International)
Ministry of Tourism
Transport Bhawan,
1, Parliament Street,
New Delhi
Subject: - Financial Quote Details.
Madam,
This has reference to the Ministry of Tourism’s RFP no.
…………………
dated
……………………. for Design & Construction of India Pavilion at ITB 2024, Berlin.
2.
In this context, our total financial quote (for ITB 2024, Berlin) in respect of
above RFP is Rs. ................./-(Rupees in words), excluding taxes/GST, as detailed
below:
Sr. No.

Particulars

ITB 2024, Berlin
(Total Area of India Pavilion:
705 Sq. Mt.)
Cost per Sq. Mt. Total Cost.
(Excl. Taxes
(Excl. Taxes
GST
GST

a)

b)

Total cost of Fabrication of India Pavilion (Exclusive of
Taxes / GST) (including adaptation of the design,
construction, maintenance & dismantling of the
pavilion; Decoration, branding & Display within the
pavilion; Transportation of material if any to the site
and back and Expenditure on many other activities /
components including those listed in the scope of
work, etc.)
Total cost for ITB 2024, Berlin (exclusive of taxes /
GST) in words.

3.
I / We understand that the total cost (exclusive of taxes / GST) as given
above will be considered for financial evaluation.
Name of the Bidder: ..................................
Authorised Signatory:.................................
Name:
Seal:
Date:
Place:

<!-- page 17 -->

Please Note
(i)

Financial bids of technically qualified agencies will be evaluated on the
basis of total cost for event (i.e. cost quoted for ITB 2024, Berlin)
exclusive of taxes/GST.

(ii)

GST / Taxes as applicable will be paid by the Ministry of Tourism.

(iii)

The bid of the agency will be treated as unresponsive in case of a
mismatch while quoting financial cost between figure and words, or
mismatch between per sq. mtr. Rate and total cost.

(iv)

The financial bid should be in Indian Rupees (INR). If, however, the
Agency has formulated costs in a currency other than Indian Rupees
(INR), for the sake of uniformity and comparison, the same may be
converted to Indian Rupees (INR) as per the official exchange rate of the
Ministry of External Affairs (MEA), Government of India for the month of
December 2023.

Official MEA exchange rates for the month of December 2023 in respect of
some of the leading currencies:

Foreign Currency

INR (December 2023)

1 US Dollar

Rs. 83.45

1 Pound Sterling

Rs. 101.00

1 Euro

Rs. 89.81

To view the official currency exchange rates of MEA for the month of December
2023, bidders may refer to Annexure- 5.
(v)
The cost quoted will be firm (in the currency quoted) and fixed for
the duration of performance of the contract. At no point of time will any
deviation from the quoted rate (in the currency quoted) be entertained by
the Ministry of Tourism.
(vi)
The Financial Bid shall not include any conditions attached to it and
any such conditional financial proposal shall be rejected summarily.
**********

<!-- page 18 -->

ANNEXURE- 3
BID SECURITY DECLARATION
Bid Security Declaration Format
(To be forwarded on the letterhead of the Bidder / Lead Member of Consortium)
Ref. Date:

Tender No.:

To
The Asst Director General
Marketing & Promotion (International)
Ministry of Tourism
Transport Bhawan,
1, Parliament Street,
New Delhi
Sub: Bid for ……………………………. Project

I/We hereby declare that:
1. I/We am/are aware that I/we have been exempted from submission of Bid
Security in lieu of this Bid Security Declaration.
2. I/We understand that bid must be supported by a Bid-Security Declaration.
3. I/We understand and accept that if I/We withdraw my/our bid within the
bid validity period or if awarded the bid and on being called upon to submit
the Performance Guarantee/Performance security, fail to submit the same
within the stipulated time period as mentioned in the bidding document or
on being called upon to sign the contract agreement, fail to sign the same
within such period mentioned in the bidding document, I/We , i.e.
*******************(the name of bidder) accept that I/ We shall be banned
from submission of Bids in any Works/Service tender issued by Ministry of
Tourism for a period upto 5 (five) years.
4. I/We agree that the decision of the Authority regarding invocation of the Bid
Security Declaration shall be final and binding on me/us and shall not be
called upon in question under any circumstances.
5. Name and Signature of Authorized Signatory of Bidder along with seal of
Bidder

<!-- page 19 -->

ANNEXURE-4
Floor Plan of ITB 2024, Berlin

<!-- page 20 -->

<!-- page 21 -->

ANNEXURE -5

<!-- page 22 -->

<!-- page 23 -->

<!-- page 24 -->

<!-- page 25 -->
