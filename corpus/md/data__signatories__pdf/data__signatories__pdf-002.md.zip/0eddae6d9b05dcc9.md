---
doc_id: "0eddae6d9b05dcc9"
source_url: "https://www.dot.gov.in/static/uploads/2026/09/eeb61d060f9611a1365b2234fd353e81.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Termination/Revocation/Cancellation of Unified License (UL), bearing No. DS-11/399/2017-DS-III, dated 09.01.2018 for Category 'C ISP Authorization for Lucknow SSA in UP(East) Service Area, granted to M/s Bytel Tranet Pvt. Ltd."
date: "2026-09-01"
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "cb3db09e5b002d35"
---

<!-- page 1 -->

DS-11/399/2017-DS-IIl 1/3437161/2026
WITHOUT PREJUDICE
F. No. DS-11/399/2017-DS-III
Government of India
Ministry of Communications
Department of Telecommunications
(Data Services Cell)
Sanchar Bhawan, 20, Ashoka Road
New Delhi-110001
Dated: 01-09-2026
To,
M/s Bytel Tranet Pvt. Ltd.
62, Sai BVR Tower, Gaura Bagh,
Kursi Road, Lucknow, U.P-226026
Email: bytelgroup@gmail.com , admin@bytel.in
Subject:- Termination/Revocation/Cancellation of Unified License (UL),
bearing No. DS-11/399/2017-DS-Ill, dated 09.01.2018 for Category ‘C’ ISP
Authorization for Lucknow SSA in UP(East) Service Area, granted to M/s
Bytel Tranet Pvt. Ltd., in terms of clause 10.2 (i) under Chapter-l of Part-I of
the said License Agreement.
Whereas, Department of Telecommunications, Government of India (“the
Licensor”) has granted a Unified License (UL), bearing no. DS-11/399/2017-DS-Ill,
dated 09.01.2018 (‘the License”) forCategory ‘C’ ISP Authorization
for Lucknow SSA in UP(East) Service Area, to M/s Bytel Tranet Pvt. Ltd. ("the
Licensee").
2. Whereas, the Licensee is required to provide the services under the terms
and conditions of the License and instructions issued by the LICENSOR from time
to time.
3. Whereas, as per National Security Directive on Telecommunication Sector
(NSDTS), the licensees are required to connect only Trusted Products in its
network with effect from 15th June 2021. Condition 39.7.1 of the Security
Conditions (Chapter-Vl) of the Unified License (UL) Agreement further stipulates
that, with effect from 15'" June 2021, the licensee, shall only connect Trusted
Products in its network and also seek permission from Designated Authority for
upgradation or expansion of existing Network utilizing the Telecommunication
Equipment not designated as Trusted Products. Instructions to all the Licensees by
the Licensor have been issued in the past vide letters dated 30.03.2021,
16.06.2021 and 10.06.2022, requesting compliance related to trusted telecom
products and registration on Trusted Telecom Portal. Pursuance with the licensee
through various communication have also been done by the concerned LSA field
unit of the department in this regard.

<!-- page 2 -->

DS-11/399/2017-DS-IIl 1/3437161/2026
4. That for non-registration on the Trusted Telecom Portal, a Show Cause
Notice, bearing no. DS/1/2025-DIR(DS-Il), dated 16.01.2025 (“SCN”), was issued
to the Licensee on the address provided in the License. The aforesaid SCN was
sent by way of speed post as well as by an email on the registered email ID(s) of
the Licensee on 20.01.2025.

5. That the aforesaid SCN was issued to the Licensee to submit its reply, within
21 days, as to why the License granted to it should not be terminated, in terms of
the clause 10.2(i) under Chapter-| of the Part-I of the License.

6. That despite having given enough time and opportunity to the Licensee to
show cause and explain the alleged violation of terms and conditions of the
License mentioned in the SCN, the Licensee has failed to submit any reply
whatsoever to the Licensor. Further, concerned LSA field unit, vide its email dated
25.08.2026 has informed that the licensee is still not registered on the Trusted
Telecom Portal.

7. That the failure of the Licensee to either comply the stated non-compliance
or submit any reply or explanation to alleged violation of terms and conditions of
the license mentioned in the SCN implies that the Licensee has nothing to say in
this regard and that the Licensee has failed to comply with the conditions of the
License and therefore, has violated the conditions of the License as stated in the
SCN.

8. Therefore, the competent Authority has now decided to terminate/ revoke/
cancel the Unified License (UL), bearing No. DS-11/399/2017-DS-Ill, dated
09.01.2018 for Category ‘C’ ISP Authorization for Lucknow SSA in UP(East)
Service Area, granted to M/s Bytel Tranet Pvt. Ltd., in terms of clause 10.2 (i)
under Chapter-| of Part-I of the License and that the said License is terminated/
revoked/ cancelled w.e.f. 61S‘ calendar day from the date of issue of this letter.

9. That the Licensee is further directed to terminate and stop all
interconnections with all service providers effective from the date of termination of
the License.

10. That the Licensee is further directed to issue a notice of at least 30
calendar days to all its customers within 30 days from today in terms of the
condition 10.2(i) under Chapter-| of Part-I of the License Agreement reproduced as
under:

“The Licensee shall be required to give a notice of at least 30 Calendar days to its
customers within this period of revocation order’.

11. That the Licensee shall take note of the clause 10.7 under Chapter-I of
Part-I of the License, which is reproduced as under:

“It shall be the responsibility of the Licensee to maintain the Quality of Service,
even during the period when the notice for surrender/revocation of License is
pending and if the Quality of Service is not maintained, during the said notice
period, it shall be liable to pay damages. The quantum of damages and to whom
payable shall be determined by the TRAI. Further, it shall also be treated as
material breach liable for action under Clause 10.1 and 10.2 of the License. The

<!-- page 3 -->

DS-11/399/2017-DS-IIl 1/3437161/2026
Licensee shall also be liable to pay the License Fee till the end of the notice period
and more specifically till the date on which the surrender/revocation becomes
effective.”

12. That the Licensee shall take note of the clause 11.2 under Chapter-I of
Part-l of the License, which is reproduced as under:

“On revocation or surrender or cancellation of License/Service Authorization(s)
due to reasons whatsoever or expiry of the License, the relevant Bank
Guarantee(s) shall be released to the Licensee only after ensuring clearance of all
dues, which the Licensee is liable to pay to Licensor. In case of failure of the
Licensee to pay the amounts due to the Licensor, the outstanding amounts shall be
realized through encashment of the Bank Guarantees without prejudice to any
other action(s) for recovery of the amounts due to the Licensor without any further
communication to the Licensee”.

13. That the Licensee shall also take note that in case, it comes to the notice of
the Licensor about any other violation of license conditions by the Licensee,
necessary action in respect of said violation may be initiated by the Licensor in due
course of time.
14. That the Bank Guarantee(s) submitted by the Licensee against the said
license will be released in terms of clause 11.2 under Chapter-l of Part-I of the
License after ensuring clearance of dues, including dues/ penalty arising, if any, as
a consequence of the aforesaid violation.
15. That the Licensee may acknowledge the receipt.
Digitally signed by
SHASHI KUMAR
Date: 01-09-2026
10:13:08
Director (DS-Il)
Email: dirds2-dot@nic.in
jto1ds2-dot@gov.in
Copy to: -

1. DG Telecom, DoT, New Delhi, with a request to instruct the concerned
LSA(s) to intimate all Licensees/Infrastructure Providers in their area to
discontinue to provide/obtain any “telecom resources” to/from M/s Bytel
Tranet Pvt. Ltd.

2. Addl. DGT, UP(East) LSA, DoT.

3. Sr. Joint CGCA(Revenue), O/o CGCA, DoT with a request to release the
Bank Guarantees of the aforesaid company after ensuring dues from
respective sections of DoT as per letter No. vide 1-90/2012/LF-1(Pt.1) dated
05.09.2018 and letter No. 1-8/2017/LFP-1 dated 17.04.2017. As far as
due(s) of Data Service Cell is concerned, the same will be intimated to O/o
CGCA in due course of time.

4. Secretary, TRAI.

<!-- page 4 -->

DS-11/399/2017-DS-IIl 1/3437161/2026
5. Wireless Advisor, for issue of Dues/No Dues Certificate till the effective date
of termination of License and convey to office of CGCA.
6. Dy. CCA, O/o Pr CCA, UP(East) Circle, DoT.
7. DDG(AS)/DDG(CS)/DDG(SAT)/DDG(SA)/DDG(SPPI)/DDG(LFP)/
DDG(WPF), DoT HQ.
8. Director (IT), DOT HQ for uploading this order on DoT website for information
to all Service Providers.
9. File No.: DS-11/399/2017-DS-III
