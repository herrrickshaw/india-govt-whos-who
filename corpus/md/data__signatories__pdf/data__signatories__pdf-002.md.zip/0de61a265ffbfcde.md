---
doc_id: "0de61a265ffbfcde"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/44804396788027702adf9560dd749cd5.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Draft Model Recruitment Rules of Nursing Officer"
date: "2018-08-07"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8e872bb1fc0b473e"
---

<!-- page 1 -->

GOVERNMENT OF INDIA
MINISTRY OF I{EALTHAND FAMILY WELFARE
Public Notice on draft Model Recruitment Rules for the post ofNursing Officer/ Staff
Nurce ofHospital / Establishment under Central Govemmqnt.

In compliance with DOPT'S OM No. 48.4017161/2008- Estt(RR) dated
03.10.2015 the draft Model Recruitment Rules for the post ofNursing Officer/ Staff
Nurse is annexed herewith.

The stakeholders interested in making any objections / comments or suggeshons on
the draft Model Recruitment rules may do so in writing, within a period of 30 days
from the date of publication of draft Model Recruitment Rules to Dr Rathi
Balachandran, ADG(Nursing), Nursing Division, Ministry of Health & Farnily
Welfare (Room No. 751- A Wing), Nirman Bhawan, New Delhi e- mail address:
rathi.bala@eov.in

ADG(Nursing)

##ffiffir''

<!-- page 2 -->

o

;:E

aF i.e

-9
:x

I

b:3
-

d.9

rT

3 Sg*o
l) t!-

H:;E

p

:EE€€[EE

z

=b

EE
o

'

l!

o

I

3c_

z
F

;H(9
q o.>
==

g€Egc?i

0\92

o()

E:i

r!

t

t!

o
o

z

N

93
3r b
irg
E€ 3
2? A

E!A9IE€
@

z

-9

z

F6
E

.E.ob
:b
e.)
E

=E:E
.9n9

EE;
3;3

'! aE

E,
o0:

bE
3E

[5
::
Eg
.Er -.s? -2E
s+

Er
E:

fa
i
E"g :-

€E

Er

IHe
*;s
EEe$*
-^b.EEg
=sE
=

z

=cE
9!x;

! a;^:

. E;+€E fETE€
r 3i=,! q;e+;

lltr

EA

o

z

|

hE g9",i

F

o

o

-o-

PE 21
,.;

o
N

:

'; r

z

o

o 6tz

ol

.=EP
o

:i

r.i:i;

E EE;
;.EtiEES

lE

:! EE!€ !;Ig;eB

o
o
'.>

$= g _ E E

i E:; s € I ; sf E
=

E--: E E

0

zo

-;1!;
c;s: et r
ggs:-EE;5g

E

E E-*Eg€

6U

==

rl^i5

E€ 5-E
E
L0 -

E E*EE
EEE

ts 5 Hg F g E

z

<g

sutEii;5!Ei;:

<!-- page 3 -->

iffEiEi*

;E:.3 g; Ig

z
F

zo
lt

3 ;E !;g ;FEi I:;EiE E*t;E:E:ggE
:sg€ii;si;;
s E: *s *g:€ El:;!;
tl;rE:,*#i;iEtcet:
!'c:;;:l=;;c:

g: 5g;g=iEiE;€u !*; ei;t;r*; gi;lii:

i!*f Ei: i: ;;;
E

sr'Eeii*3E;ili

<!-- page 4 -->

Ee.g

E.c*
- -F

=
C-

I
I

o

.9H

€.9

E'E.=
'- (J !t

.or.9

;;E

lt B
e

l5*-€ l9 t
16Es E

l=

6

z

(1,

o
E

z

t6+:.-

e:.:
l=; b-

F

lE

a\

18

F; E

E

-l

E

g

lriiE
e z
lF; @
l: E;* H ;

9.9

Z

zo

*: !

qx

EEg.gsg
tc)
-.l: = = o c
EEEP;B
'au:
o
=
1E
"t.
P: -Pv P si
rx
-; =]

IEE
I .iP;*
!..
l.o - .9 :: .;

I

IL

I

I

^ls,gE6€:
8 3cJ>!1

I

q
et
v:;;

E==

>2

.E E o,!

.g;t-,9.E
E5

3.c5 E

916

E{E
: F- i:

l9:9.gE,gF 3E e'
IEEEAd'*P sEbE
POC':
c!!oE

EtEs

:EaE9
L E.c

':
tgEE
q5

I

i

ls€
Ef
lc :.! :
E

l*
tii
l!
IF

.l!

E
