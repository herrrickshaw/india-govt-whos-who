---
doc_id: "0f46a7e2dfceb48c"
source_url: "https://doj.gov.in/static/uploads/2025/09/e1919d8dbe42b18d99c7daa00e42f7f5.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Mohd. Yousuf Wani, Judicial Officer as an Additional Judge of the Jammu & Kashmir and Ladakh High Court (21.03.2024)"
date: "2024-03-21"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aa863e416e8b44ba"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K.13021/03/2023-US.II
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011.
Dated: 21st March, 2024.
NOTIFICATION
In exercise of the power conferred by Clause (1) of Article 224 of the
Constitution of India, the President is pleased to appoint Shri Mohd. Yousuf
Wani, to be an Additional Judge of the Jammu & Kashmir and Ladakh High
Court, for a period of two years with effect from the date he assumes the
charge of his office.
—410.4A.
(Gaurav Masaldan)
Joint Secretary to the Government of India
Tele: 23072142
To
The Manager,
Government of India Press,
Minto Road, New Delhi.

<!-- page 2 -->

2

No. K.13021/03/2023-USJI

Dated: 21.03.2024.

Copy to:

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.

Shri Mohd. Yousuf Wani, Judicial Officer through the Registrar General,
J&K and Ladakh High Court, Jammu/Srinagar.
The Principal Secretary to Lt. Governor, Union Territory of Jammu and
Kashmir, Jammu/Srinagar.
The Secretary to the Lt. Governor, Union Territory of Ladakh, Leh.
The Secretary to the Chief Justice, High Court of Jammu & Kashmir and
Ladakh, Jammu/Srinagar.
The Chief Secretary, Government of Jammu & Kashmir,
Jammu/Srinagar.
Pr. Secretary to the Lt. Governor, Government of Ladakh, Leh-Ladakh.
The Registrar General, High Court of Jammu & Kashmir and Ladakh,
Jammu/Srinagar
The Pr. Secretary to Government, Finance Department, Union Territory
of Jammu & Kashmir, Jammu/Srinagar
The Secretary Finance, Administration of UT of Ladakh.
The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.
PS to the Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.
Registrar (Conf), o/o the Chief Justice of India, 07, Krishna Menon
Marg, New Delhi.
PS to the MoS, L&J (I/C)/ PPS to Secretary (Justice).
Technical Director, NIC, Department of Justice, with a request to upload
the notification on the website of the Department (www.doj.gov.in).

7, 1 03 " Il l
(Prein C and)
Under Secretary (Appointments-I)
Tele: 2338 2978
