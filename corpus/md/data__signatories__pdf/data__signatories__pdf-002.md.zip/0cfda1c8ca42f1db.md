---
doc_id: "0cfda1c8ca42f1db"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/d144cf3cac913c2a54a8e98b21938526.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Acceptance of resignation of 10 Advocates and deletion of one Advocate due to his death: Order dated 14.08.2019"
date: "2019-08-19"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "7bda1e6ec48eb463"
---

<!-- page 1 -->

ee F. No. J-11/2/2018-Judicial
Government of India
Ministry of Law and Justice
. Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated 14" August, 2019
ORDER
The President is pleased to accept the resignation of following ten Advocates and to
delete the name of one Advocate due to his death, who all figure as panel counsel in
various categories for various courts as mentioned under column III and with effect from the
dates as mentioned under column-V in table ‘A’ below, consequently, their names occurring
in various orders of this Department as mentioned under column-lV in table ‘A’, stand
deleted:
Table ‘A’
Name of me of Court & | Detail of concerned | Date of
Advocate Category of Panel order of acceptance of
(S/Shri) empanelment resignation
a i 2) | (west
[1 | ॥ rial a 638 Vo Vv
1 Brijendra Vikram | Central Govt. No. 36(1)/2015-Judl. | 03.02.2019
Singh Counsel for | dated 09.04.2015
| Allahabad High read with No.
Court, Lucknow J-11017/20/2017-
Bench Judicial dated
| 09.04.2018
2 Ms. Uttara Babbar | Gr. ‘A’ Panel J-11016/1/2019- 12.04.2019
| Counsel for the Judicial dated
| Supreme Court of 01.02.2019
F India
3. | Bhishm Datt | District & | J-11015/1/2016- Date of this
Singh Tomar Subordinate Courts, | Judicial dated order
(Enrl. No. | Mathura (UP) 28.12.2016
| UP/959/1999)
| 4. | P. Veera Reddy Sr. Panel Counsel for | J-11017/24/2018- 28.04.2019
| the erstwhile High | Judicial dated
Court of Judicature | 03.10.2018
at Hyderabad for the
| | state of Telangana &
| the state of Andhra
1 | | Pradesh
| 5. | Yadava Karkera Central Govt. | J-11017/7/2018- Date of this
| | Counsel for the High | Judicial dated order
| Court of Karnataka at | 20.03.2018
| Bangalore
|
| order

<!-- page 2 -->

fe ५
ie
_7. | Bhupeshwar Central Govt. J-11017/25/2018- Date of this
i | Jaswal Counsel for the High | Judicial dated order
| Court of Punjab & 22.11.2018
| Haryana at
४ Chandigarh
| 8. | Vineet Kumar -do- -do- 03.06.2019
| Jakhar
19. | Laxmidhar Standing Govt. J-11015/8/2016- His name is
Mohapatra Counsel for District & | Judicial dated | deleted due to
Subordinate Courts, .| 16.05.2016 read with | his death
Puri (Odisha) Order No. intimation
| J-11017/2/2019- dated
| Judicial (Part-4) | 23.05.2019
dated 09.03.2019
10. | K. V. Sabu Central Govt. J-11017/15/2018- 20.02.2019
Counsel for the High | Judicial dated
Court of Kerala 24.08.2018
Prakasan -do- |_४० | 25.03.2019
Keke
2s Hindi version of this order will follow.
(S. R. Mishra)
Additional Secretary
Copy for information to:
1. PS to MLJ/ PS to MSLJ/PS to Law Secretary/PS to Legislative Secretary.
2. The Incharge Central Agency Section, Supreme Court of India, New Delhi.
3. The Incharge, Branch Secretariat, Bangalore.
4 4. Shri Shashi Prakash Singh, Addl. SGI, Allahabad High Court
है! 5. Shri Satya Darshi Sanjay, Addl. SGI, Patna High Court.
6. Shri Satya Pal Jain, Addl. SGI, Punjab & Haryana High Court at Chandigarh.
7. Shri Gyan Prakash, Asst. SGI, Allahabad High Court, Allahabad.
8. Shri K. Laxman Asst. SGI, High Court of Telangana at Hyderabad.
9. Shri. Asst. SGI, High Court fo Odisha at Cuttack.
; 10. Shri P. Vijay Kumar, Asst. SGI, High Court of Kerala.
: . 11. Shri Kharag Singh Chhonkar, Standing Govt. Counsel, District Mathura, R/o Gram Kamora, Post
| Madora, Dist. Mathura (UP).
12. The Cash (LA) Section to stop the retainership fee to Late Laxmidhar Mohapatra, (Standing Govt
Counsel for District Puri (Orissa) vide his death intimation dated 23.05.2019 (copy enclosed)
13. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.
14. To be uploaded on website of this Department i.e. www.legalaffairs.gov.in under tab ‘Judicial
Section’ in the link ‘List of empanelled Counsel’
15. Hindi Section, Department of Legal Affairs, for translation of this order,
| 16. Guard File with 5 spare copies yer
for Section Officer (Judicial)
Tel. 011-23384945
Email: judicial-dla@nic.in
