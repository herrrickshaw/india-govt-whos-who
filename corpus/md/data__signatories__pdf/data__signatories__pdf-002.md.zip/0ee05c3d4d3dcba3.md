---
doc_id: "0ee05c3d4d3dcba3"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/05/a37e6976c707687c9b49706ecaea2af9.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "National Programme for Prevention & Management of Trauma and Burn Injuries – Group II Day 1 19 September 2019"
date: "2026-05-13"
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "65b22e80a12cf230"
---

<!-- page 1 -->

‘National Programme for Prevention
& Management of Trauma and Burn
Injuries (NPPMT&BI)’

<!-- page 2 -->

Trauma Care Programme
• Objective : Trauma Care Facilities along the Highways.
– Bring down preventable deaths due to road accidents.
– Develop a pan-India Trauma Care Network at every 100
Km.
• 11th Five Year Plan(2007-2012):
 100% centrally sponsored
 116 Trauma Care Facilities (TCFs) identified and funded
 Status: functional-105, construction work under progress10, construction not initiated-1
• 12th Five Year Plan(2012-2017):
– Additional 80 TCFs supported on 60:40% sharing basis
(Center: State); first instalment of funds released

<!-- page 3 -->

Levels wise Unit cost of TCFs
Level

Unit Cost
Unit Cost
Number of TCFs
(11th FYP)-Rs (12th FYP)-Rs approved during
in crores
in crores
11th & 12th FYP

I
15.93
17.13
6
II
9.63
10.27
76
III
4.775
4.94
114
L-1: Apex Trauma care facility in Medical College with
more than 500 beds,
L-II: in Hospitals/Medical Colleges with bed strength
between 300-500
L-III: in District Hospitals with bed strength between 100200

<!-- page 4 -->

Other activities being undertaken in Trauma Care Programme

• National Injury Surveillance , Trauma Registry and
Capacity Building Centre (NISC) has been
established at Dr. RML Hospital (www.nisc.gov.in).
• Capacity building: various training courses for all
level of healthcare providers in the field of trauma
care are being conducted on regular basis.
• IEC activities on various modes of communications
being undertaken.
• Technical guidelines and documents are developed
from time to time with help of experts in the field.

<!-- page 5 -->

National Programme for Prevention &
Management of Burn Injuries

 Initiated on pilot basis during 11th FYP.
 For Prevention of Burn Injuries, provide timely and
adequate treatment in case of burn injuries.

100% centrally sponsored.
Implemented only in 3 Medical Colleges and 6 District
Hospitals.
 12th Five Year Plan-National Programme
47 Medical Colleges supported and first installment
released towards construction and equipment.
• Financial support for setting up of a Burn Unit in Medical
Colleges is Rs 6.579 Cr.
• Centre & State share --60%:40%; 90:10 in case of NE States and
hilly regions.
• UTs are provided 100% funding
• Capacity building/ Training, IEC, etc.

<!-- page 6 -->

Issues in Trauma & Burn Programme
• 11 TCFs (9 in Bihar, 1 in Maharashtra, 1 in Jharkhand) of
11th FYP are yet to become functional.
– The concerned States to apprise the reasons please ???
• Trauma & Burn Units of 12th plan,
– No State sought second installment.
– In most of the cases UCs of first installment not
received/ not submitted in the prescribed format.
• States to forward the proposals for release of funds on
reimbursement basis.
– No such proposal received so far for Trauma & Burns
Programme.

<!-- page 7 -->

THANK YOU
