---
doc_id: "0ba6deb8a123bd4b"
source_url: "https://mohua.gov.in/static/uploads/2025/10/3e4c0f16be7cc543029a7ee5c7045807.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "NUSP"
date: "2025-10-15"
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "296f501d22cca983"
---

<!-- page 1 -->

National Urban Sanitation Policy
Ministry of Urban Development
Government of India

<!-- page 2 -->

<!-- page 3 -->

National Urban Sanitation Policy
Ministry of Urban Development
Government of India

3

<!-- page 4 -->

National Urban Sanitation Policy

4

<!-- page 5 -->

National Urban Sanitation Policy

Contents
Background

6

Vision

7

Key Sanitation Policy Issues

7

Policy Goals

7

Implementation Support Strategy

9

Components of National Urban Sanitation Policy

11

Annexure - I

Draft Framework for Developing State Sanitation Strategies 13
Annexure - II

Draft Framework for a City Sanitation Plan

16

Annexure - III

National Award Scheme for Sanitation for Indian Cities

5

34

<!-- page 6 -->

National Urban Sanitation Policy

Background
Sanitation is defined as safe management of human excreta, including its safe
confinement treatment, disposal and associated hygiene-related practices. While this
policy pertains to management of human excreta and associated public health and
environmental impacts, it is recognized that integral solutions need to take account of
other elements of environmental sanitation, i.e. solid waste management; generation of
industrial and other specialized / hazardous wastes; drainage; as also the management of
drinking water supply.
According to Census 2001, 27.8% of Indians, i.e. 286 million people or 55 million
households live in urban areas1 – projections indicate that the urban population would have
grown to 331 million people by 2007 and to 368 million by 2012. 12.04 million (7.87 %)
Urban households do not have access to latrines and defecate in the open. 5.48 million
(8.13%) Urban households use community latrines and 13.4 million households (19.49%)
use shared latrines. 12.47 million (18.5%) households do not have access to a drainage
network. 26.83 million (39.8%) households are connected to open drains. The status in
respect of the urban poor is even worse. The percentage of notified and non-notified slums
without latrines is 17 percent and 51 percent respectively. In respect of septic latrines the
availability is 66 percent and 35 percent. In respect of underground sewerage, the
availability is 30 percent and 15 percent respectively. More than 37% of the total human
excreta generated in urban India, is unsafely disposed. This imposes significant public
health and environmental costs to urban areas that contribute more than 60% of the
country’s GDP. Impacts of poor sanitation are especially significant for the urban poor
(22% of total urban population), women, children and the elderly. The loss due to diseases
caused by poor sanitation for children under 14 years alone in urban areas amounts to Rs.
500 Crore at 2001 prices (Planning Commission-United Nations International Children
Emergency Fund (UNICEF), 2006). Inadequate discharge of untreated domestic/municipal
wastewater has resulted in contamination of 75 percent of all surface water across India.
The Millennium Development Goals (MDGs) enjoin upon the signatory nations to extend
access to improved sanitation to at least half the urban population by 2015, and 100%
access by 2025. This implies extending coverage to households without improved
sanitation, and providing proper sanitation facilities in public places to make cities opendefecation free.

In 2001, about 285 million people, or 27.8% of India's 1.02 billion population, lived in 5,161 cities. About 37%
lived in 35 million-plus metros, the rest being equally divided between 388 large towns (0.1 up to a million) and
4,738 small towns (less than 0.1 million). Over the last five decades, annual rates of growth of urban
population ranged between 2.7 to 3.8% - 2.7% being the growth rate during 1991-2001. Projections estimate
that 331 million people would be living in Urban India by 2007, growing in the Eleventh Plan period to 368 million
by 2012 (Office of Registrar General and Census Commissioner, Govt. of India, 2006).
1

6

<!-- page 7 -->

National Urban Sanitation Policy

Vision
The vision for Urban Sanitation in India is:
All Indian cities and towns become totally sanitized, healthy and liveable and ensure
and sustain good public health and environmental outcomes for all their citizens
with a special focus on hygienic and affordable sanitation facilities for the urban
poor and women.

Key Sanitation Policy Issues
In order to achieve the above Vision, following key policy issues must be addressed:
■

■

■

■

■

■

■

Poor Awareness: Sanitation has been accorded low priority and there is poor
awareness about its inherent linkages with public health.
Social and Occupational aspects of Sanitation: Despite the appropriate legal
framework, progress towards the elimination of manual scavenging has shown limited
success, Little or no attention has been paid towards the occupational hazard faced
by sanitation workers daily.
Fragmented Institutional Roles and Responsibilities: There are considerable gaps
and overlaps in institutional roles and responsibilities at the national, state, and city
levels.
Lack of an Integrated City-wide Approach: Sanitation investments are currently
planned in a piece-meal manner and do not take into account the full cycle of safe
confinement, treatment and safe disposal.
Limited Technology Choices: Technologies have been focussed on limited options
that have not been cost-effective, and sustainability of investments has been in
question.
Reaching the Un-served and Poor: Urban poor communities as well other residents
of informal settlements have been constrained by lack of tenure, space or economic
constraints, in obtaining affordable access to safe sanitation. In this context, the
issues of whether services to the poor should be individualised and whether
community services should be provided in non-notified slums should be addressed.
However provision of individual toilets should be prioritised. In relation to “Pay and
Use” toilets, the issue of subsidies inadvertently reaching the non-poor should be
addressed by identifying different categories of urban poor.
Lack of Demand Responsiveness: Sanitation has been provided by public agencies
in a supply-driven manner, with little regard for demands and preferences of
households as customers of sanitation services.

Policy Goals
The overall goal of this policy is to transform Urban India into community-driven, totally
sanitized, healthy and liveable cities and towns.

7

<!-- page 8 -->

National Urban Sanitation Policy

The specific goals are:
A

Awareness Generation and Behaviour Change

Awareness Generation and Behaviour Change
a. Generating awareness about sanitation and its linkages with public and environmental
health amongst communities and institutions;
b. Promoting mechanisms to bring about and sustain behavioural changes aimed at
adoption of healthy sanitation practices;
B

Open Defecation Free Cities

Achieving Open Defecation Free Cities
All urban dwellers will have access to and use safe and hygienic sanitation facilities and
arrangements so that no one defecates in the open. In order to achieve this goal, the
following activities shall be undertaken:
a.
b.

c.

C

Promoting access to households with safe sanitation facilities (including proper
disposal arrangements);
Promoting community-planned and managed toilets wherever necessary, for groups
of households who have constraints of space, tenure or economic constraints in
gaining access to individual facilities;
Adequate availability and 100 % upkeep and management of Public Sanitation
facilities in all Urban Areas, to rid them of open defecation and environmental
hazards;
Integrated City-Wide Sanitation

Re-Orienting Institutions and Mainstreaming Sanitation
a. Mainstream thinking, planning and implementing measures related to sanitation in all
sectors and departmental domains as a cross-cutting issue, especially in all urban
management endeavours;
b. Strengthening national, state, city and local institutions (public, private and
community) to accord priority to sanitation provision, including planning,
implementation and O&M management;
c. Extending access to proper sanitation facilities for poor communities and other unserved settlements;
Sanitary and Safe Disposal
100 % of human excreta and liquid wastes from all sanitation facilities including toilets
must be disposed of safely. In order to achieve this goal, the following activities shall be
undertaken:
a.
b.

8

Promoting proper functioning of network-based sewerage systems and ensuring
connections of households to them wherever possible;
Promoting recycle and reuse of treated waste water for non potable applications
wherever possible will be encouraged.

<!-- page 9 -->

National Urban Sanitation Policy

c.
d.

Promoting proper disposal and treatment of sludge from on-site installations (septic
tanks, pit latrines, etc.);
Ensuring that all the human wastes are collected safely confined and disposed of
after treatment so as not to cause any hazard to public health or the environment.

Proper Operation & Maintenance of all Sanitary Installations:
a. Promoting proper usage, regular upkeep and maintenance of household, community
and public sanitation facilities;
b. Strengthening ULBs to provide or cause to provide, sustainable sanitation services
delivery;

Implementation Support Strategy
Government of India recognizes that sanitation is a state subject and on-ground
implementation and sustenance of public health and environmental outcomes requires
strong city level institutions and stakeholders. Although there are some common elements
across urban areas of India, there are a number of factors, constraints and opportunities
that are peculiar to specific situation of states and cities with respect to sanitation,
climate, physiographic factors, economic, social and political parameters, and institutional
variables, etc2. Therefore each state and city needs to formulate its own sanitation
strategy and their respective city sanitation plan respectively in overall conformity to the
National Policy.
Government of India Support
Ministry of Housing and Poverty Alleviation (HUPA) is administering a Centrally Sponsored
Scheme for Integrated Low Cost Sanitation (ILCS). Under this scheme, central subsidy to the
extent of 75%, state subsidy to the extent of 15% and beneficiary contribution to the extent of

In this context, it may be noted that the interpretation and translation of the National Policy in the special
states in the North-Eastern States, Andaman and Nicobar Islands, and Lakshadweep, will take account of
their situation (especially community institutions and financial arrangements) and make special and/or
additional provisions supporting by Government of India.
2

9

<!-- page 10 -->

National Urban Sanitation Policy

10% is provided for. The main objective of the scheme is to convert around 6 lakh dry latrines
into low cost pour flush latrines by 31st March 2010. 75% of the central allocation will be used
for conversion and the remaining 25% will be used for construction of new toilets for EWS
households who have no toilets in urban areas. This scheme focuses on the provision of
latrines/toilets and the elimination of open defecation and scavenging. It does not cover the
problem of inadequate sanitation, including treatment and disposal of sewage and solid waste
management, which has considerable environmental and health implications. The scope of
urban sanitation is much larger than the issues covered under the Scheme for Integrated Low
Cost Sanitation which essentially focuses on provision of latrines to prevent open defecation in
order to eliminate manual scavenging.
Towards achievement of the Urban Sanitation Policy Goals, the Government of India will
support:
a.

b.

c.
d.
e.
f.
g.

States will be encouraged to prepare State Level Sanitation Strategies within a period
of 2 years. Chapter on Draft Framework for Developing State Sanitation Strategies
gives an outline of the strategy (Annexure I);
Identified cities will be urged to prepare model City Sanitation Plans within a period of
2 years. Chapter on Draft Framework for a City Sanitation Plan gives an outline of the
plan (Annexure II);
Providing assistance for the preparation of Detailed Project Report (DPR) as per city
sanitation plan as soon as requests for funding are received;
Promote public-private partnership in respect of key projects/activities identified in
the city sanitation plan;
Provide technical assistance and support for awareness generation and capacity
building to states and cities within this financial year;
Periodic rating of Cities in respect of Sanitation, and recognition of best performers
by instituting a National Award within this financial year (Annexure III);
Funding projects wherever possible from existing schemes. The Ministry of Urban
Development is implementing schemes such as the Jawaharlal Nehru National Urban
Renewal Mission (Urban Infrastructure and Governance (UIG) component), the Urban
infrastructure development scheme for small and medium towns (UIDSSMT). Both
these schemes have a time span of 7 years (2005-12) with a budget of Rs1, 00,000
crore of which the share of the central government is Rs 50,000 crore. Out of 324
projects sanctioned upto 31.03.08, 125 pertain to sewerage, storm water drainage
solid waste management. In addition, this Ministry is also responsible for the scheme
for new satellite townships and counter magnet cities and 10% lumpsum provision for
North Eastern states including Sikkim which provide funds for the creation of urban
infrastructure facilities. Proposals for financing of projects in the sewerage, solid
waste disposal and storm water drainage sector will be accorded high priority under
all these schemes. It is recognised that in spite of access to these schemes, there
may be a deficit of funds in which case the option of approaching bilateral and
multilateral agencies will be explored.

Government of India will support states in developing and implementing innovative
strategies to accord priority to urban sanitation. States and cities can explore a number of
options in achieving sanitation goals including;

10

<!-- page 11 -->

National Urban Sanitation Policy

■

■

■

■

■
■

■

■

■

Using existing provisions with regard to sanitation in municipal and other Acts to
promote compliance;
Amending municipal Acts, framing of bye-laws and regulations (e.g. building and
construction bye-laws) to promote sanitation by public and private agencies, prohibit
discharge of untreated sewage into open areas wherever necessary;
Create a system of incentives and disincentives including punitive actions and levies
and charges on polluters wherever appropriate;
Re-orienting policies to ensure that urban poor households or residents in informal
settlements obtain access to improved sanitation facilities;
Ear-marking and making land available for community and public sanitation facilities;
Promoting partnerships with public, private and non-governmental agencies for
improved provision, maintenance and management of sanitation facilities;
Mainstreaming sanitation in all public activities (e.g. by coordinating with health,
education and infrastructure sectors3);
Taking up sanitation in a mission mode in order to mobilize joint actions from different
public and non-government agencies. This can be accomplished by forming an urban
sanitation steering committee at the state level and a task force at the city level;
Exploring other options and innovations that may be suitable locally.

The components of Govt. of India national support strategy are presented below.

Components of National Urban Sanitation Policy
Govt. of India shall support the following components:
Awareness Generation
A country-wide Information, Education and Communication (IEC) Strategy will be designed
and implemented for raising awareness on the public health and environmental importance
of sanitation. The socio-cultural biases against sanitation and sanitary work need to be
targeted, and dignity and humane approach promoted in the elevation of priority to
sanitation in public affairs. Further, the public-good nature of urban sanitation necessitating
collective action needs to be highlighted in the minds of all stakeholders.
Institutional Roles
The Govt. of India will support clear assignment of roles and responsibilities, resources
and capacities and institutional incentives in relation to setting standards, planning and
financing, implementation, knowledge development, capacity building and training,
Monitoring & Evaluation (M&E), and regulatory arrangements. The government will help
states and cities in ensuring sanitation as a core responsibility of Urban Local Bodies as

Investments in proper sanitation facilities (arrangements right up to treatment and safe disposal) must
become a compliance requirement for any investments in infrastructure (e.g. urban transport, railways,
airlines, etc.), and health and education sectors. For instance, urban transport investments must become 100
percent sanitation compliant by providing investments for public and community sanitation, as also specific
plans for transport of solid waste, septage, and appropriate arrangements for sewerage systems.
3

11

<!-- page 12 -->

National Urban Sanitation Policy

envisaged in the Constitutional (Seventy fourth) Amendment Act, 1993. The special roles
of NGOs and Community Based Organisations (CBOs) will be recognized in mobilizing
communities, raising awareness and in working with poor communities to assist them in
finding affordable, community-managed solutions to sanitation.
Reaching The Un-Served And Poor Households
The national policy will help urban areas adopt a city-wide, demand-based participatory
approach to individual (resolving tenure, space and affordability constraints), and
community sanitation where individual sanitation facilities are not feasible. Towards this,
special slum and community sanitation plans will be formulated as a part of the City
Sanitation Plan. Provision of public sanitation facilities will also be supported.
Knowledge Development
The policy recognizes the importance of developing and disseminating knowledge on
institutional development, technology choices and management regimes, planning new
developments and upgradation, and sustainability issues.
Capacity Building
Govt. of India will help formulate and implement a National level strategy on capacity
building and training to support states and cities to build their personnel capacities and
organizational systems for delivery of sanitation services.
Financing
The Govt. of India, wherever possible, will explore possibilities of providing assistance for
funding projects proposed as part of City Sanitation Plans through its schemes like
JNNURM, UIDSSMT, 10% Lump Sum for NE States, Satellite Township Scheme, etc.
However, the emphasis will be on improving the efficiency of existing sanitation
infrastructure and service delivery.
National Monitoring & Evaluation
At the national level, the Govt. of India will support periodic rating of cities by independent
agencies. A National Annual Award will be instituted on the basis of this rating (Chapter on
National Award Scheme for Sanitation for India Cities).
Coordination at the National Level
National investments in urban infrastructure and housing shall accord high priority to
sanitation. Towards this, sanitation will be mainstreamed into all relevant programmes of
all the relevant sectoral ministries.

12

<!-- page 13 -->

National Urban Sanitation Policy

Annexure - I
Draft Framework for Developing State Sanitation Strategies
Government of India recognizes that sanitation is a state subject and on ground
implementation and sustenance of public health and environmental outcomes requires
strong city level institutions and stakeholders. Further, in spite of the common elements
that characterize urban areas of India across the length and breadth of the country, there
are a number of factors and forces, constraints and opportunities, that are peculiar to
specific situation of states and cities viz. their historical legacy with respect to sanitation,
climate and physiographic factors, economic, social and political parameters, and
institutional variables, etc. Therefore, it is best that each of the States develops its own
State level Strategy to achieve the policy goals set out in the National Urban Sanitation
Policy. In this context, it may be noted that the interpretation and translation of the
National Policy in the special states i.e the North-Eastern States, Andaman and Nicobar
Islands, and Lakshadweep, will take account of their situation (especially community
institutions and financial arrangements) and make special and/or additional provisions
supported by Government of India.
Like in the national policy, state strategies are recommended to detail out the following
generic headings or areas requiring attention:
a)

Clear assignment of institutional responsibility, resources and capacities: State Urban
Sanitation Strategies must ensure clear ULB responsibility as envisaged in the 74th
Constitutional Amendment (CA). Where this is partial or incomplete, states will need
to make concerted efforts to devolve powers, roles and responsibilities along with
financial and personnel resources necessary for ULBs to discharge their functions.
Alongside, the ULBs will also have to be accorded wide-ranging powers over agencies
that currently carry out sanitation related activities in the city but are not directly
accountable to them, e.g. para-statals and PHEDs.

b)

Setting standards at the State Level (within the overall frame of national standards):

■

■
■

■

13

Environment Outcomes (e.g. State Pollution Control Board standards on effluent
parameters, diminishing water resources, impact of climate change, use of low
energy intensive onsite/decentralised wastewater treatment technologies, distributed
utilities etc),
Public Health Outcomes (e.g. State Health Departments)
Processes (e.g. safe disposal of on-site septage) and infrastructure (e.g. design
standards) (PHEDs/ Para-statals ) and coverage of the informal sector activities like
disposal of waste water,solid waste etc.
Service Delivery standards (e.g. by Urban Development departments)

<!-- page 14 -->

National Urban Sanitation Policy

■

■

Manpower issues such as adequate remuneration, hazardous nature of work,
employment on transparent terms and conditions, use of modern and safe
technology, provision of adequate safety equipment such as gloves, boots, masks,
regular health checkups, medical and accident insurance cover etc.
States are recommended to not just emulate but set their standards higher than the
national standards in order to encourage its institutions and citizens to target higher
standards of public health and environment.

c)

Planning and financing at the State Level: ULBs will need to be made responsible
for planning and financing public infrastructure, and leveraging such private
investments as may be required for achieving outcomes (as stated in their State
Strategies). The problem of shortage of funds needs to be factored in. In this regard,
States will need to devolve adequate and predictable resources to ULBs including
setting tariffs, inter-governmental fiscal transfers and devising targeting of subsidies
to the poorest of the poor households. The issue of recovery of O & M cost and
through the introduction of use charges collection of dues needs to be emphasised as
a means of ensuring accountability as well as financial sustainability. In doing so,
State Government’s support to ULBs will need to be increasingly re-oriented to reward
the achievement of outcomes (moving way from input, process and hardware funding
per se). State governments will also be encouraged to launch awards for best
performing cities to bring about a competitive spirit in achieving total sanitation by
cities. Considerable coordination will also be required across other government
agencies and institutions, private and community institutions – to highlight the priority
to sanitation, as well as in planning and implementation of programs.

d)

Reaching the Un-served populations and the Urban Poor at the State level:
States will need to resolve tenure, space and affordability constraints to providing
individual sanitation facilities preferentially, and community facilities where individual
provision is not feasible. The provisioning of basic sanitation should be de-linked from
the issues of land tenure. Every urban dweller should be provided with minimum
levels of sanitation, irrespective of the legal status of the land in which he/she is
dwelling, possession of identity proof or status of migration. However, the provision of
basic services would not entitle the dweller to any legal right to the land on which he/
she is residing. At least 20% of the funds under the sanitation sector should be
earmarked for the urban poor. The issues of cross subsidiary the urban poor and their
involvement in the collection of O&M charges should be considered. States will need
to issue guidelines to support cities in adopting participatory approaches to
community sanitation, and rational planning for appropriate and adequate sanitation
for floating population, institutions and public place workers, with explicit recognition
of cost recovery for sustainable management, service delivery and repairs and
maintenance. Special role of NGOs and CBOs needs to be recognized in this
respect, especially for community sanitation facilities.

e)

Service Delivery in cities: ULBs will need to be responsible for asset-creation and
managing systems including service delivery. In this context, the ULB may bring in
public, private and community agencies/groups to provide services on its behalf. But

14

<!-- page 15 -->

National Urban Sanitation Policy

the final accountability with regard to performance in sanitation will have to be that of
the ULB. Departments and para-statals currently carrying out these responsibilities
will need to be accountable to the respective ULBs (including for example, financing
through the ULBs). The State governments will need to make explicit directions in
this regard, including roles for NGOs and CBOs and the urban poor.
f)

Regulation of cities and within cities: State Strategies will need to dwell on this
issue carefully – strengthening existing state level institutions that are charged with
ensuring compliance of ULBs to environmental standards (e.g. State Pollution Control
Boards), health outcomes (e.g. Health Departments), and Service Delivery Standards
(e.g. State Urban Departments). Wherever these responsibilities or action on
deviance are not spelt out clearly, the state strategy will need to make these clear.
The strategy will also have to identify the ULB as having the key regulatory remit
over all properties and agencies/households in the city in respect of outcomes and
process standards stipulated by it.

g)

Monitoring & Evaluation at the State and City Levels: The State government will
be responsible for M&E of its cities’ performance, and hence needs to devise data
collection and reportage systems using outcome indicators. ULBs in turn need to
track compliance of households (establishments, etc.) with outcomes and process
standards that it has adopted. Introducing citizens’ report cards, citizens’ monitoring
committees, self-assessment system, inter-city competitions, etc will be considered.
NGOs and CBOs will also play key roles in M&E.

h)

Capacity Building & Training: The state strategy needs to identify agencies that
will train its state level, ULB personnel and orientation of elected representatives.
These agencies could be specialist agencies of the state government, and/or NGOs
and private sector organizations. This will also need to focus on capacity building, i.e.
not just training but also development of systems and capacities of ULBs in
sanitation, in line with the Urban Sector Reforms that the state may be implementing.
ULBs will need to provide training on sanitation to their own staff – using state level
resource agencies. They will need to utilize Govt. of India and State Government
Schemes for training and capacity building in order to achieve this.

15

<!-- page 16 -->

National Urban Sanitation Policy

Annexure - II
Draft Framework for a City Sanitation Plan
Purpose
The purpose of this framework is to assist Urban Local Bodies, NGOs, community based
organizations, citizens and private sector agencies in Govt. of India through a series of
steps toward achieving the goal of 100 percent sanitation in their cities. The focus of this
note is on how to go about the process. Since each city will make choices based on
demand and need, local context, availability of financial and human resources, and the
opportunity for innovations, this note does not answer what options etc. to choose. The
exact contents of this framework may be adapted to suit the state’s urban sanitation
strategy and used for its cities. To assist in thinking through the challenge, some core
building blocks are outlined in this note, as presented in Fig. (1).
Though apparently linear, the process needs to be highly iterative and draw in inputs from
one series of steps to another.
States will need to determine time-frames and deadlines to achieve the goals mentioned in
the National Urban Sanitation Policy and will need to spell out a detailed roadmap,
including the incremental targets for achievement of goals. For example, to achieve the
goal of open defecation free (ODF) by year 2011, a detailed plan for extending access will
need to be formulated and implemented in a time-bound manner. All such steps will need
to be spelt out in and operationalized under the CSPs. While some of the activities in the
sanitation plan may be possible to complete with little financial resources e.g. better
utilization of existing facilities, improved management systems for septage cleaning,
awareness generation; etc. whereas others e.g. reconditioning or laying new sewers, may
Figure 1: Generic Elements of Planning, Implementation and M&E of City Wide Sanitation

Specify legal and
regulatory
Responsibility

Setting up

City
Sanitation
Task Force

and
Implementing
Agency

Fixing
Permanent
Institutional
Responsibility
and Sanitation
Implementation
Roles

City Wide
Sanitation
Plan (CSP)

and Financing consultations

Multi-Stakeholder Meeting,
Public Resolution and IEC
Campaign
Baseline Data Collection and concurrent use of
data in initial actions, IEC Campaigns, and
detailed planning

16

Technology
Choice:
upgradation, New
Investments, O&M
Management

O&M
and
Service
Delivery
Systems

Implementatio
n Management
and M&E/
Supervision

Special
Approaches for
Sanitation for
the Poor

State and City Level

Reward Schemes

Evaluation
of 100%
Sanitation
Status

Capacity Building

Monitoring of
100% Sanitation
Status

<!-- page 17 -->

National Urban Sanitation Policy

be more resource-intensive. The CSP will need to be prepared keeping in view what the
city can afford and finance. It will be better as far as possible to improve the effectiveness
of existing facilities before embarking on expensive new investments. Further, thinking
about the whole city, and not just some portions or just some facilities, will be necessary
to achieve the goals in a comprehensive and systematic manner.

Steps for Achieving 100% Sanitation
Key Principles
The National Urban Sanitation Policy identified the following core principles that need to be
addressed. These must be used as a guide by the cities:
■
■
■
■
■
■
■

Institutional Roles and Responsibilities
Awareness Generation for changing mindsets
City-wide Approach
Technology Choice
Reaching the un-served and poor
Client focus and Generation of Demand
Sustained Improvements

Preparatory Actions
City Sanitation Task Force
Mobilize Stakeholders: The first step in making the cities 100% sanitized is to elevate
the consciousness about sanitation in the mind of municipal agencies, government
agencies and most importantly, amongst the people of the city.
a)

■

■

■
■
■

■

■

17

Constitute a multi-stakeholder City Sanitation Task Force comprising representatives
from
Agencies directly responsible for sanitation including on-site sanitation, sewerage,
water supply, solid waste, drainage, etc including the different divisions and
departments of the ULB, PHED, etc;
Agencies indirectly involved in or impacted by sanitation conditions including
representatives from the civil society, colonies, slum areas, apartment buildings, etc,
Eminent persons and practitioners in civic affairs, health, urban poverty,
Representatives from shops and establishments,
Representatives of other large institutions in the city (e.g. Cantonment Boards, Govt.
of India or State Govt. Enterprise campuses, etc.),
NGOs working on water and sanitation, urban development and slums, health and
environment,
Representatives of unions of safai karamcharis, sewerage sanitary workers, recycling
agents / kabaris, etc

<!-- page 18 -->

National Urban Sanitation Policy

■

■
■

Representatives from private firms/contractors formally or informally working in the
sanitation sector (e.g. garbage collectors, septic tank de-sludging firms etc.)
Representatives from educational and cultural institutions
Any other significant or interested stakeholders

Some of the elected Members of the ULB must be members of the Task Force. The Task
Force should be headed by the Mayor with the executive head (e.g. Municipal
Commissioner) as the Convenor. Cities can also choose to appoint, as a part of the Task
Force, City Sanitation Ambassadors chosen from eminent people who enjoy outstanding
credibility and influence amongst the city’s leadership and population. Political leadership
must be involved from all political parties and persuasions so that the sanitation campaign
has the full support of all stakeholders and no opposition from any group. One of the things
to be considered by the Task Force is to organize a multi-stakeholder, multi-party meeting
in the preparatory stage, and take a formal resolution to make the city 100% Sanitized,
and publicize the same, with all signatories.
b)
■
■
■

■

■
■
■
■

The City Sanitation Task Force will be responsible for:
Launching the City 100% Sanitation Campaign
Generating awareness amongst the city’s citizens and stakeholders
Approving materials and progress reports provided by the implementing agency, other
public agencies, as well as NGOs and private parties contracted by the Implementing
Agency, for different aspects of implementation (see below)
Approving the City Sanitation Plan for the city prepared by the Sanitation
Implementation Agency after consultations with citizens
Undertaking field visits from time to time to supervise progress
Issue briefings to the press / media and state government about progress
Providing overall guidance to the Implementation Agency
Recommend to the ULB fixing of responsibilities for city-wide sanitation on a
permanent basis

The Task Force should meet formally frequently (at least once in two months) in the initial
stages to monitor and guide the process of planning and implementation. At a later stage,
meetings and field visits can be on an as-needed basis. In some cities, the City Sanitation
Task Force may divide up roles and responsibilities amongst smaller sub-committees
to focus on different aspects closely while keeping the overall character of the Task
Force intact.
c)

18

The Task Force should appoint one of the key agencies, preferably the ULB, to
become the City Sanitation Implementing Agency for the CSP for the city. This
agency will be responsible for day-to-day coordination, management and
implementation of the sanitation programs on a city-wide basis. The agency will
coordinate with and agree on joint actions with other public agencies, and contract in
and supervise the services of NGOs (through Memorandum of Understanding) and
private parties (through contracts) for preparing and disseminating materials for IEC,
conducting baseline surveys and stakeholder consultations, maintaining a

<!-- page 19 -->

National Urban Sanitation Policy

comprehensive GIS-based database, implementing physical works, letting out and
supervising O&M management contracts, etc.
The ULB should formally notify and publicize the appointment of the City Sanitation Task
Force and Implementing Agency.
d)

Assign Institutional Responsibilities: One of the key gaps in urban sanitation is lack
of clear and complementary institutional responsibilities. This comprises two aspects:
a) roles and responsibilities institutionalized on a permanent basis; and b) roles and
responsibilities for the immediate campaign, planning and implementation of the
City’s Sanitation Plan – based on which the former can be outlined, experimented
with, and finally institutionalized.

The Sanitation Task Force will recommend the assigning of permanent responsibilities for
city-wide sanitation to the ULB including the following aspects:
■

■
■
■

■
■

■

The ULB to have final overall responsibility for city-wide sanitation, including
devolving power, functions, functionaries and funds to them
Planning and Financing including State Government and Govt. of India schemes
Asset creation including improvement, augmentation
Operations and Management (O&M) Arrangements for all network, on-site, individual,
community and public sanitation facilities and systems (including transportation up to
final treatment and disposal of wastes)
Fixing tariffs and revenue collections in order to make O&M sustainable
Improving access and instituting special O&M arrangements for the urban poor and
un-served populations in slum areas and in mixed areas
Adopting standards – for
– Environment Outcomes (e.g. State Pollution Control Board standards on effluent
parameters),
– Public Health Outcomes (e.g. State Health Departments),
– Processes (e.g. safe disposal of on-site septage) and
– Infrastructure (e.g. design standards) (PHEDs/ Parastatals ), and
– Service Delivery standards (e.g. by Urban Development departments)

■

■
■
■

Adoption of Regulatory roles including environmental standards (e.g. State Pollution
Control Boards), health outcomes (e.g. Health Departments).
Measures in case specific stakeholders do not discharge their responsibilities properly
Training and Capacity Building of implementing agency and related personnel
Monitoring of 100% Sanitation involving multiple stakeholders

While the responsibilities for each of the above roles may temporarily vested in one or the
other stakeholders, for reasons of efficiency and effectiveness during the campaign period,
the Task Force will recognize that these roles must be permanently institutionalized in the
ULB and amongst other stakeholders. Therefore, the recommendation of later permanent
roles may be different from those in the Campaign Period.

19

<!-- page 20 -->

National Urban Sanitation Policy

In many cases, Acts, rules and regulations exist but these are not enforced. This may be
a good entry point to start on roles and responsibilities (also see Section 3.5 below for
details).The roles and responsibilities for the Sanitation Plan implementation are outlined in
the relevant section below – this will also be the task of the City Sanitation Task Force.
Baseline Data Collection and Creating Database/GIS
In parallel with the preparatory steps, the ULB / Implementing Agency will collate the
information on sanitation that exists with the ULB itself and other agencies in the city. This
will include demographic, institutional, technical, social and financial information. In
addition, it will commission a private agency or an NGO or both to carry out primary data
collection on the missing items – the surveys will use a mix of structured and participatory
techniques. All the data collected must be amenable to linking to an existing or proposed
Geographic Information Systems (GIS) for the city. (If this does not exist, setting up a GIS
for water, sanitation and solid waste management must be finalized and putting into
immediate implementation). The baseline will be over-laid on plans for development of new
areas and colonizations, based on the Master Plan of the City. If a Master Plan does not
exist, appropriate projections will be made after consulting real estate development public
authorities as well as private agencies. The combined database from the above exercise
will form the basis for planning and implementing the campaign. Since such data collection
can be time-consuming, ULBs must start very early on this activity and start using data as
and when it starts becoming available. One of the methods of making the data collation
and database preparation process efficient and adaptive to planning and implementation
actions, is to break it down into simplified components like:
Stage I Data: – use for initial preparatory actions
■

■

■

ULB and PHED data on institutional parameters (organizational structure,
investments and assets, personnel, O&M systems and finances),
Census 2001 data on households, JNNURM/UIDSSMT or other schemes’ data
compiled for poor households
ULB data on public sanitation and available crude data on conveyance and treatment.

Stage II Data: - use for IEC Campaign, and planning 100 percent access on a city-wide
basis.
■

■

■

Refined secondary data on existing conditions of disposal and conveyance (sewers,
on-site pits, availability and use of suction machines, etc.) and treatment systems
(landfill sites, recycling, etc.);
Baseline primary data on household / unit arrangements for sanitation and waste
disposal, and hygiene behaviour and perceptions about service providers
Baseline primary data on citizens’ demands and perceptions about sanitation
arrangements, outcomes, and health and environmental linkages

Stage III Data: - Use for planning and implementing institutional changes, social
mobilization and upgradation, improvements and new investments in assets and systems
of O&M, M&E, etc.
20

<!-- page 21 -->

National Urban Sanitation Policy

■

■

■
■
■

Primary data based on sample condition assessment surveys (see parameters
above) of arrangements, disposal and treatment systems
Institutional Assessment detailed information on existing and required skills and
capacities, systems and procedures, financial position
Social – personal hygiene and public health behaviour and practices
Economic – Surveys on willingness to pay for different options
Financial – Costs of O&M, Revenue and tariffs, systems of community management
of community and neighbourhood level systems

Usually, a baseline study needs to be completed in about three to four months (Class II
and above), depending on the size of the city and complexities involved. About two
months is adequate to complete baseline in Cities of Class III and below. Combining
participatory approaches with institutional and other stakeholders, with observation and
community and household interactions using checklists, schedules, etc., makes the data
collection efficient and economical. It may be noted that the baseline is not a census of all
properties and households/units. It is rather an assessment, usually using sampling to
cover all representative types of situations obtaining in the city, in order that progress can
be measured at later points in time comparing with the baseline. Most immediately,
baseline studies are required for planning the City-wide sanitation plan. It is advisable to
cover all aspects during the baseline: technical, institutional, social, economic, financial,
urban poor etc. and be cautious that none of the aspects are left out. Even if the baseline
studies are completed in a short period – this is necessary so that planning processes are
not kept on hold for long – further data collection and updating of records must continue
later on too, and become a part of the ULB/Implementation Agency’s implementation
management system.
Awareness Generation and Launch Of 100% Sanitation Campaign
After a reasonable amount of data (See above) has been collated from secondary and
primary sources, and the Task Force is in place, the first task will be of launching a citywide 100% Sanitation Campaign. This will be ideally timed with Govt. of India national
media campaign, and a state wide campaign that the state government may choose to
launch. If required, a professional media agency may be commissioned to work closely
with the Task Force and Implementing Agency to package the messages and direct them
effectively to different stakeholder groups in the city. NGOs may be commissioned to do
group messaging and door-to-door campaigns with special stakeholders like slum-dwellers
etc. Schools and Colleges can play a special role in propagating the messages in their
institutions as well as in their families.
At the city level, it will be advisable to launch the campaign as a time-bound program that
all stakeholders need to work towards. Appropriate media like Newspapers, TV and city
and ward / neighbourhood level programs (sweeping streets, health camps, tree-planting
etc.) may be engaged. There should be an intensive first round followed by successive
rounds that may be focused on specific aspects and / or special type of stakeholders, or
neighbourhoods. One of the methods that some cities or neighbourhoods may try out is to
declare Clean City Week every year or half-year. The Task Force should enlist the
participation of leaders and eminent persons to lead the campaigns. The messages and

21

<!-- page 22 -->

National Urban Sanitation Policy

media / campaign strategy for each of the successive rounds must be planned carefully.
There are a number of other programmes (e.g. health, education, HIV / AIDS, etc.) that
have media campaigns. The 100% Sanitation campaign should be coordinated with such
agencies so that maximum multipliers can be gained by collaborative and calibrated
working of these initiatives. Wherever possible, messages should be put in other
campaigns to reinforce the impact.
Specifying Legal and Regulatory Institutional Responsibilities
Even though many of the municipal laws refer to sanitation responsibilities of households
and ULB, etc. these are not clearly laid out or comprehensive. The Implementing Agency
will examine the law and rules in this regard and make recommendations for the Task
Force to make the rules explicit regarding:
■
■
■
■

Safe sanitary arrangements at unit level (household, establishment)
Designs and systems for safe collection
Norms for transport / conveyance
Treatment and final disposal

The recommended standards and guidelines are available from CPHEEO and Environment
Acts. These will need to be formally adopted including laying down the monitoring and
regulatory responsibilities, and incentives and disincentives for doing so. This must
include the system of user charges / fees, fines and community pressure mechanisms to
help people move to desirable public health behaviour. Actions to be taken in case of
institutional failure will also be specified clearly.
All the above recommendations will be considered by the Task Force and recommended to
the ULB for appropriate action. Executive changes may be implemented immediately
whereas legal matters may be referred to the State Government if not within the ambit of
the ULB. Expert advisors on the Sanitation Task Force will be the resources to utilize for
this task – matters may be discussed with national or state level agencies if standards are
not clear, or need to be further detailed. Interim and working standards may suffice in
many cases to immediately adopt and implement, whereas the codification and detailing
may be undertaken in parallel. In all cases, the Task Force will strive to make standards
22

<!-- page 23 -->

National Urban Sanitation Policy

based on the goals of total or 100% Sanitation, and as much as possible, simple and easy
for ULBs and public to understand and adhere to.
Planning and Financing
The task of planning and finding sources of funding will be under the oversight of the Task
Force but carried out by the Implementing Agency. The Agency will take assistance from
consultants etc. to help prepare the plans for the city for different aspects including
institutional, social, technical, financial, etc. At all stages, the plans must be
comprehensive and cover the whole of the city, and not just one part or aspect. Therefore,
a number of innovative measures may have to be used.
The Government of India’s JNNURM, UIDSSMT and BSUP are the key programs to
source funding resources (others being special programs for the North-East and satellite
towns schemes, etc.), apart from State Government’s own resources. Planning should be
aligned to the above funding sources (as well as what customers are willing to pay by way
of connection fees, user charges, etc.), and seek to derive maximum benefits from these
sources for achieving 100% Sanitation. The City and States will also need to explore other
sources of finance to fund their sanitation plans since Govt. of India scheme resources
may not be enough to fulfil all requirements. In this context, it may also be noted that
investments will need to financially sustainable and hence, cities may lay down options
(different levels of infrastructure and service levels) depending what they can afford in the
medium term, and what will prevent them from getting trapped in high loan repayment
liabilities, or O&M management expenditure bubble at a later point in time.
The City Sanitation Plans (CSP) must be prepared and presented by the Implementing
Agency and presented to the Task Force for approval. While the exact contents of the
CSP may vary depending on the local situation, the following aspects must be covered:
■

■

■
■

■

■
■

■

■

23

Plan for Development of Institutions / Organizations responsible for sanitation, and
their roles and responsibilities;
Plan for ensuring 100% Sanitation Access to different socio-economic groups, and
related O&M systems (including improving existing systems, supplementary
facilities, O&M Management contracts using PPP and community management,
etc.);
Costs and tariffs for service provision;
The issue of collection of dues needs to be emphasised as a means of ensuring
accountability as well as financial sustainability
Investments and O&M systems for new development areas / market and public
places, and residential and other habitations
Plan for safe collection, conveyance and treatment of sanitary wastes
Plan for M&E of implementation, and of achieving and sustaining 100% Sanitation
(including use of community monitoring, etc.)
Issues such as diminishing water resources, impact of climate change, use of low
energy intensive onsite/decentralised wastewater treatment technologies, distributed
utilities etc.
Manpower issues such as adequate remuneration, hazardous nature of work,

<!-- page 24 -->

National Urban Sanitation Policy

■

employment on transparent terms and conditions, use of modern and safe
technology, provision of adequate safety equipment such as gloves, boots, masks,
regular health checkups, medical and accident insurance cover etc.
Plans for other aspects significant locally

Some of the bigger cities may choose to prepare the plans on a regional / district or wardwise basis. This may be a good way to mobilize stakeholders of the respective wards /
regions and generate competition. However, at all times, it must be emphasized that such
divisions are only limited to convenience in execution and monitoring, and sanitation must
be a city-wide achievement. Hence, the Task Force will have a special role in ensuring the
integration of all the regional or functional components of the CSP as outlined above.
In order to promote wide ownership reflecting the collective and collaborative spirit of the
sanitation endeavour, the CSP should be presented to the public for feedback at different
stages of its development. Notwithstanding the inclusive and representative character of
the City Sanitation Task Force, it is to the city’s benefit if more and more city stakeholders
are able to contribute to the Plan. Holding of at least one, preferably two (draft and final
stages) public meetings, needs to be considered by the Task Force.
Technical Options
Technology choice poses a major problem in Indian cities not only because of lack of
information on what exists at present, but also because of the constraints of land, tenure,
and low budgetary priority accorded to sanitation historically. This leads to estimations of
investments using conventional technologies that are mind-boggling and paralyze any
incremental action. The key issues about Technical Options are:
■

■

■

■

■

24

Technologies come with attendant capital and O&M costs, and management systems
that may or may not be appropriate to a city’s situation at a given time. Very often we
can fall into the trap of planning systems that are difficult to finance, institutions are
not ready and geared to operate and maintain them, and people are not ready or
willing to adopt these and pay for service provision. Also, technology is linked to a
whole set of environmental, behavioural and cultural parameters that need be taken
into account. A holistic approach is required for technology choice.
Approach to difficult existing situations (e.g. dense areas with on-site systems
draining into nalis) is to think about upgradation and retro-fitting options to make the
systems sanitary and safe and perform to their existing capacity first.
Technologies need to be incremental – for instance, even if sewers are ideal for
dense settlements, they may not be feasible to immediately execute. In such cases,
interim (e.g. on-site, or community septic tanks or latrines if space is a constraint)
systems may be planned with a view to later upgrade these to more sophisticated
system (e.g. sewerage).
Technologies and attendant systems for new development areas can be planned in
advance. This results in early investments leading to cheaper and more sustainable
systems in the future.
Technologies are only a means and not an end in itself. They are to enable sanitary
and safe confinement and disposal and hence, the approach to design must be
keeping these ends in view.

<!-- page 25 -->

National Urban Sanitation Policy

■

Technologies that promote recycle and reuse of treated wastewater should be
encouraged.

There is considerable information available on existing options as also the experience with
some new systems and processes – see for instance, “The Guide to Decision making –
Technical Options for Urban Sanitation in India” (Draft, WSP SA, 2007). These need to be
reviewed by the Implementing Agency and where needed, specialist advice sought from
state and national level agencies, and the private and community sectors. Exposure visits
and training programs will be required to take an informed decision. Finally, customers are
at the heart of such systems – households and establishments must be consulted on
expressing their preference after being made aware of the pros and cons of each of the
systems under consideration.
Technology choice again should address the city-wide nature of the challenge – a mix of
options must add up to addressing the issue completely, not just in bits.
Finally, technologies need to be planned for the full cycle of arrangements at the unit level,
conveyance/transport, and final treatment and disposal into the environment. Any
combination of systems that does not lead to the output of 100 % safe collection,
conveyance and treatment, will not serve the purpose of achieving 100% Sanitation for the
city.
Situation Analysis Studies show that the bulk of decision-making and unit level
investments are made by households and establishments – with more focus on
arrangements, and less attention to disposal. Public agencies are concerned with disposal
and treatment but boundaries of roles and responsibilities are not clear. In many if not
most of the cases, public agencies are also unable to accord much attention to the public
infrastructure and systems for disposal and treatment (e.g. sewerage systems, sewage
treatment plants), or leave it for the households to resolve their problems (e.g. cleaning of
septage). Thus issues of O&M and sustainability need to be kept in view when planning for
technology options (also see below).
Reaching the Un-Served Populations and the Urban Poor
Experiences from many Indian cities show that a differentiated approach is necessary to
extend good quality sanitation services to the poor – the group that suffers the most in
terms of adverse impacts on health and lost earnings.
Participatory approaches are needed to consult the poor settlements and involve them in
the process of planning and management of sanitation arrangements. Many settlements
may have the necessary conditions to support the provision of individual on-site sanitation
arrangements (e.g. as tried out in some pockets in Ahmedabad, etc.) that are ideal, in many
others, tenure and legal issues prevent provision of individual toilets and hence CTs are the
only way for immediate succour and access (e.g. as is the case with Mumbai, Pune, etc.).
In some places, conventional and shallow sewers have also been tried out as alternative to
on-site solutions in dense settlements. Examination of legal / tenurial, space and affordability
issues in close consultation with communities becomes a key step in planning innovative
means that are owned by users and will be sustainably managed by them.
25

<!-- page 26 -->

National Urban Sanitation Policy

NGOs can play an important role in mobilizing slum communities. Further, when
community groups themselves take over the O&M of community facilities, then
sustainable services become possible. This is also a way of reducing costs (compared to
say, pay and use public toilets) and making services affordable to the poorest of families.
Another segment of population normally without sanitation is those who live in dispersed
urban locations not being slums or in groups of houses that have legally not been notified
as slums. Innovative approaches are required to extend services to these population
groups too.
It may be noted that Public Sanitation is for general public or floating populations whereas
CTs are those where an identifiable core group of users exist, even if floating population
may occasionally use these facilities.
The Implementing Agency will need to take stock of the legal and non-notified settlements
in the city, and in partnership with NGOs and Community Based Organizations (CBOs),
initiate a process of collaborative planning and delivery of services. Sanitation services
also serve as an entry point for improved water supply, drainage improvements and
community managed solid waste disposal systems – these areas should also be targeted
while planning for sanitation is being undertaken.
At least 20% of the funds under the sanitation sector should be earmarked for the urban
poor. The issues of cross subsidisation of the urban poor and their involvement in the
collection of O&M charges should be addressed.
Finally and not least of all the obstacles, is the mindset of officers of ULBs and other
citizens: biases and myths often hinder proper service provision to poor settlements.
There must be a concerted effort to raise awareness amongst all stakeholders about the
huge health and environmental costs that all have to bear if services are not
comprehensively provided to all citizens. Two steps are necessary to achieve this change
in mindsets: a) orientation programs must be conducted for ULB functionaries; and b)
setting up permanent systems in ULBs, complemented with agreements with NGOs and
CBOs, to deliver services and monitor outcomes on an urgent basis to all poor
households, as well as others who are either un-served or have unsanitary arrangements
for defecation, collection or disposal.
Operation & Maintenance and Service Delivery Systems
Institutional systems for O&M are at the heart of any successful set of systems and
procedures to achieve and sustain 100 % sanitation. As outlined above, responsibilities for
institutions are weakly defined and even if stipulated hardly followed properly.
Therefore, existing systems must be examined with the question: which agency or
institution is responsible for operating and maintaining the system or a part thereof? If they
do not discharge their responsibilities, what corrective action or recourse exists and who is
responsible for this? For new investments similar questions need to be asked so that
assets and services do not suffer from lack of proper O&M. A city-wide perspective is

26

<!-- page 27 -->

National Urban Sanitation Policy

necessary since O&M is required for all parts of the sanitation systems, whether they are
to do with excreta removal, or drainage or solid waste management. Assigning institutional
responsibility also must go hand in hand with technology selection, design and
implementation/creation of assets.
While sewerage systems have limited responsibility of households (from own property to
nearest street connection), institutions responsible for the rest of the conveyance systems
are faced with a number of personnel, finance and incentives related constraints. These
need to be mapped and clearly addressed – even with little resources; innovations need to
be made in the organization responsible (ULB department or PHE unit) to seek immediate
remedies while a more systematic planned set of steps to improve O&M may be
implemented during the plan.
In most on-site systems, households are left to fend for themselves – often, there is no
check on unhealthy and illegal practices such as draining wastes in to nalas and drains.
These also need to be brought under the remit of the respective public agency and
properly dealt with. Septage clearance services are another area where quick action can
be initiated and the necessary fees charged from households.
In drainage and solid waste too, a number of steps can be initiated (some of these have
been successfully tried out in solid waste management in many Indian cities) that ensure
that O&M and service delivery are proper and in which consumer households also have a
stake and roles built in.
Preparing O&M Protocol for each of the sanitation facilities in the city is a good step in
this direction, and their adherence needs to be monitored by senior officers, elected
representatives and community members.
O&M systems often suffer because customers do not recognize this as a service, and do
not pay for the poor service levels. O&M is closely related to the financial sustainability of
service provision, and hence, the Implementing Agency must take full stock of the
financial implications of improving current and future service levels. These should lead to
proposals to the City Task Force, as a part of the CSP, on how to recover or fund the
costs of O&M.
Customer complaints and redressal systems are another major area needing attention.
One of the important changes that need to be effected amongst the ULB, or service
provision agency is to treat citizens as customers of services. Accordingly, complaints,
redressal and feedback systems can be instituted for sustained improvements. Preparing
proper customer records and taking structured feedback are ways already tried out in other
sectors with satisfactory results in improving public services. Providing orientation and
training programs, implementing customer relationship systems, and linking O&M
performance to personnel performance are ways to examine for implementation of
improved service delivery systems.
Finally, in many cases, households and communities may be in a better position to carry
out O&M tasks or monitor performance thereof. This approach works specially when

27

<!-- page 28 -->

National Urban Sanitation Policy

communities have incentives to work together and/or there are considerable externalities
of a particular behaviour (individual actions affecting others easily). Maintenance
management of CTs, maintaining cleanliness in neighbourhoods, keeping drains and nalas
clean, street sweeping, etc. are examples where community groups can easily monitor the
performance of service providers. In case of poorer neighbourhoods and slums, some of
these tasks may be formally entrusted to local groups too.
Capacity Building & Training
The role of capacity building and training is crucial in achieving and sustaining 100 %
sanitation. Because of the historical neglect, the what and how to do of sanitation is
limited to a minuscule group of personnel in ULBs / service provider agencies – even
these skills run down over time due to little scope for application and sometimes the
narrow nature of the specific job. Therefore, two broad kinds of interventions are
necessary:
a)
b)

Orientation, building of skills and aptitude for carrying out different types of activities
in respect of total sanitation
Designing and implementing working systems in ULBs or service provision agencies
to provide the right kind of structures, linkages and organizational systems and
environments that utilize the skills and perspectives imparted above.

The task of building capacities is huge – this is compounded by the generally low levels of
synthesis and dissemination of existing knowledge and experiences of working with
different kind of technologies, management regimes, organizational systems and
processes and institutional relationships. Therefore, there is a dual agenda of consolidating
and applying existing and new knowledge in a learning-by-doing framework, and building
capacities thereon in an adaptive manner that is able to accommodate a range of
personnel from different kind of backgrounds. National and State level Resource
Organisations including NGOs, need to be brought in by the City Task Forces, to assist in
this huge agenda – that needs to be woven closely with the Sanitation Campaign,
Planning, Implementation, and Monitoring and evaluation. Similarly, specialist institutions
need to be deployed early with assistance of the Union and State Governments, so that
the knowledge development on technologies and management regimes is quickly made
available for the city to adapt. The role of NGOs will be valuable in training and capacity
building for participatory methods and consultation techniques to be used with the urban
poor and un-served households.
Two strategies are worth considering in the capacity building agenda: a) bulk training for a
range of municipal, NGO/CBO, private sector personnel - right from the start of the
campaign in the city; b) Differentiated and specialized training on a demand-basis to
personnel in and outside the government over the period of the Sanitation Plan
implementation.
One of the common death-knells of training and capacity building is the lack of incentives
and organizational environment to practice learnt perspectives and skills. This highlights
the need for the Task Force and implementing organizations to plan the training of their
personnel in such a manner that their skills can be put to productive use.
28

<!-- page 29 -->

National Urban Sanitation Policy

Agencies from the private sector, public and NGO training and capacity building
institutions must be involved in the campaign process to carry out the necessary
assessments and help the Task Force plan and devise a strategy for Human Resource
Development and capacity development through the implementation cycle, and institute
appropriate practices within the institutional framework of the ULB and other stakeholders
for the future.
Implementation Management and Monitoring & Evaluation
Implementation Management
The task of Implementation management can prove to be onerous if the planning stages
are done in a hurry or are inadequate in taking account of ground reality (including current
assets, finances, capacities and availability of suppliers and vendors, and other
environmental conditions). While the Implementation Agency will be responsible for overall
implementation, it is useful to think about plan implementation and delivery mechanisms
for each of the components of the Plan (as outlined in Section 3.6 above). The typical
components indicate that there need to be either in-house resources deployed for these
tasks (e.g. as in bigger ULBs) or private and NGO service providers need to be contracted
or commissioned to carry out the implementation. The following types of skills and
competencies are required in these implementation agents:
■

■
■
■
■

■
■

Institutions / Organizations Development, and financial (capital and O&M costs,
tariffs, ULB finances, etc.)
Socio-economic and community management
Urban planning
Health and environmental linkages to sanitation
Technical capacities to implement new assets and facilities and set up O&M
systems for new development areas
Monitoring & Evaluation
Capacities to address plans for other local aspects

Expert institutions, Consultants, NGOs, etc. who were involved in planning, may be
considered for participating in and providing Project Management Support to the
Implementation Agency. In some of the larger cities, this may be an effective way to
achieve efficient implementation of a large-scale sanitation plan for which the city may not
have all expertise and management competencies within the ULB, or where many parallel
activities are to be implemented leading to shortage of personnel capacities for peaks of
activity.
Contracts and their management are crucial in making sure that the implementation is
without delays and adheres to appropriate quality standards. Two broad kinds of services
are required: hardware related capacities that have to do with implementing physical works
and software / process related capacities e.g. social mobilization, institutional
development, training, etc. Since the ULB may not have requisite capacities and systems
to effectively deal with the challenges of contracting and supervision of contracts,
innovations are needed: these include taking assistance from State level agencies in
selection and procurement; appointing contractors and consultants on a cost-plus basis;

29

<!-- page 30 -->

National Urban Sanitation Policy

lump-sum or unit-price contracts for other components and so on. Memoranda of
Understanding (e.g. with NGOs) to arrive at a common shared understanding of
responsibilities and deliverables are another tool to address some of the components.
Finally, training in contract management may be an area that core members of the
Implementing Agency need to go through if requisite capacities are deemed to be wanting.
The presence and guidance of the City Sanitation Task Force will be an assurance of
quality procedures, fairness, and focus on deliverables. Supervision and M&E of
implementation will provide other methods of mid-course correction.
Monitoring & Evaluation and Supervision of Progress
The City Sanitation Task Force and the Implementing Agency need to think about M&E of
the implementation as an integral part of the City Sanitation Plan (CSP). The mechanisms
to be used in monitoring implementation include:
■

■
■

■

■
■

Administrative data from Implementing Agency Reports and from the implementing
consultants, contractors
Task Force field visits to different parts of the city
NGOs working in different parts of the city, e.g. an NGO working in certain slum
pockets may be able to monitor changes in the relevant settlements since they work
there and visit and interact with people regularly. A Memorandum of Understanding or
undertaking to provide additional expenses may be required from the ULB, whereas
some NGOs, especially those working on health, may be collecting some of this data
as a part of their own work;
Community Groups asked to provide structured feedback to the implementing agency
and the Task Force on progress of implementation and the condition in their
respective neighbourhoods
Independent third party assessments
Concurrent Evaluations by a Survey Agency

An important aspect of monitoring and evaluation is to make the findings and reports
available to the public so that feedback and suggestions can be received from other
stakeholders. Sharing key features in monthly Task Force meetings and press briefings
are also another way of mobilizing city stakeholders and eliciting their cooperation.

Evaluation of 100% Sanitation Status
The mechanisms and systems used for M&E often determine the quality of assessments
of results as well as to a large extent the responses of different stakeholders. Section 4 of
the Chapter on National Award Scheme for Sanitation for India Cities lists draft M&E
indicators in terms of output, process and outcome related parameters.
While the Task Force and Implementing Agency may use a combination of mechanisms
suggested above for implementation, for evaluation of 100% Sanitation Milestone
achievements, a number of tools can be considered:

30

<!-- page 31 -->

National Urban Sanitation Policy

■

■

■
■

A mix of Self-Assessment by the City Sanitation Task Force – based on
Implementation Agency data, citizens’ groups feedback, and primary Field Visits;
Independent Report Cards and Evaluation Missions commissioned by the City Task
Force and/or mounted by the State Government
Cross-city monitoring with participation of State level and other-city stakeholders
Govt. of India monitoring missions and independent agencies

Experiences from other sectors shows that multi-stakeholder M&E systems, using
simplified formats to assess objective indicators are likely to build a shared ownership,
and economically produce reliable results. Therefore, the City Sanitation Task Force may
consider publicizing, as a part of the initial awareness generation campaign, the key
indicators that all stakeholders should monitor, and devise a simplified mechanism to
collect data and report on.
Introduction of competitive reward schemes within cities are another way to improve the
quality of monitoring and evaluation of 100% Sanitation achievements.

Monitoring of 100% Sanitation Status
In order to ensure that after the city or parts thereof do not slip back after the achievement
of the milestone, there need to be systems instituted to ensure that this is not a one-time
achievement but rather a permanent change in behaviour, systems and practices.
Again, multiple stakeholders need to be involved in this process, while the ULB or the
Task Force may take the lead in doing so. The mechanisms to institute sustenance of
change include:
■

■

■

31

ULB Roles in monitoring processes, outputs and outcomes: the ULB will need to
assume leadership and institutionalize the means of monitoring the 100% Sanitation
Status. This will be closely tied to New Investments and O&M roles and
responsibilities within the ULB divisions, but it is recommended that a unit separate
from the above units is made responsible for the overall outcomes of the city’s
achievements and their sustenance. The ULB will also be able to do this more
effectively if it involves other government agencies (Environment, Health related
within and outside its own organization) NGOs, CBOs, the urban poor etc.
The role of Citizens’ Groups in monitoring on a day-to-day basis is invaluable and
should be mobilized especially for the protection of neighbourhoods, incremental
improvements, as well as immediate reportage of any deviance that needs solutions.
At the overall city level of course, the erstwhile monitoring of implementation will
transform into adding the responsibilities relating to sustained change at the ground
level.
The best method of sustaining change is to regularly collect formal data and informal
information and feedback, and make it public so that there is pressure created
equally on the public agencies, private service providers, as well as households and
communities, to keep to sustained practices. Rewards again serve as triggers for
sustenance and in many cases, also to make improvements that will earn credit to
the city. As the Rewards Section (below) outlines, there are a number of other indirect

<!-- page 32 -->

National Urban Sanitation Policy

benefits that accrue to cities becoming 100 percent sanitized and making constant
improvements.

City Reward Schemes
Cities can institute their own reward schemes to incentivise local stakeholders to
participate in the process of improvements for reaching 100% sanitation. Rewards could
be given following the national guidelines on an area basis. For example, the following
could be units for rewards:a)
b)
c)
d)
d)
e)

Municipal Wards;
Colonies or Residents’ Associations;
Schools, colleges and other educational institutions
Market and Bazaar Committees,
City-based institutions or localities e.g. Railway stations, Bus Depot, Office
Bhawans, etc.
Other locations and institutions that may be in the city.

The reward may contain a nominal amount of money for further upkeep and maintenance
of sanitary systems, improvements in infrastructure targeted to better health and
environment, as also special purposes like holding Environment Fairs, Health Camps, etc.
A scroll of honour, public function to accord recognition, and rating of wards may also be
considered as a part of rewards.
While such rewards are being instituted, it must be emphasized that the responsibility of
any group or locality is not over by just its own achievements. It must be a city-wide
enterprise and no one will be safe and benefit from a health life and environment unless
everyone in the city area and its surroundings moves to improved personal and community
practices of 100% sanitation.
The leadership of municipal ward elected representatives, local community leaders,
citizens’ groups and community based organizations, will be a crucial in achieving and
sustaining 100 % sanitized wards or localities. They must be mobilized to compete in a
healthy manner in achieving sanitation.
{Therefore, the reward scheme should become important in local community civic affairs,
politics, and valorize the local economy too.}

Cities with Special Institutions and Characteristics
i)

ii)

32

There may be cities that have special institutional arrangements: cities where ULBs
are not in place or have responsibilities only for a part of the city (other parts coming
under a cantonment or a development authority). In such cities, a multi-agency Task
Force will need to be created that can plan, guide and monitor the 100% sanitation
campaign. It will be crucial that no part of the city is left out and as convenient and
efficient, the authorities implement similar measures in their respective jurisdictions.
Cities where ULBs are only partially responsible for sanitation, other responsibilities

<!-- page 33 -->

National Urban Sanitation Policy

iii)

vested in para-statal agencies like PHED / PWD. The City Sanitation Task Force
must involve representatives from all agencies involved in sanitation. This will include
all agencies responsible for household / unit level sanitation, sanitation and
sewerage, water supply, health and environment.
Cities that have unique topographical, environmental features (e.g. hilly or coastal
regions), and therefore may be vulnerable to natural phenomena like floods, landslips,
earthquakes, etc. Specialist advice may be sought by such cities from expert
national and state level agencies, and private firms. Such specialist institutions may
be invited to become members in the City Sanitation Task Force, and contribute their
specialist knowledge and advice to the process. In cities vulnerable to natural
disasters, special measures for sanitation must be explicitly incorporated in their
Disaster Preparedness and Mitigation Plan.

If such a plan does not exist, the Task Force must lay out the steps to be taken for the
city to cope with such disasters including:
a)
b)

c)
d)

Institutional Roles and Responsibilities for disaster preparedness,
Incorporation of disaster preparedness in the design and O&M of sanitation
arrangements and systems (at household / unit level, in transport and conveyance,
and in sewage treatment / disposal),
Emergency measures and rehabilitation measures in the event of disasters,
Building key points from above in public awareness generation campaigns.

Reference and Resource Material
Manual on Sewerage and Sewage Treatment, CPHEEO, Ministry of Urban Development,
Government of India.
Urban Sanitation in India – Planning for a Better Future, Urban Sanitation Planning
Guidance Notes, Ministry of Urban Development, Government of India
WSP-SA (2007). A Guide to Decision-Making: Technology Options for Urban Sanitation in
India. Draft for Discussion. Forthcoming.
ASCII (2007).Case Studies on Urban Sanitation from Indian Cities (CD).

33

<!-- page 34 -->

National Urban Sanitation Policy

Annexure - III
National Award Scheme for Sanitation for Indian Cities
Goal
In order to rapidly promote sanitation in urban areas of the country (as provided for in the
National Urban Sanitation Policy and Goals 2008), and to recognize excellent performance
in this area, the Government of India intends to institute an annual award scheme for
cities. The award is based on the premise that improved public health and environmental
standards are the two outcomes that cities must seek to ensure for urban citizens. In
doing so, governments in states and urban areas will need to plan and implement holistic
city-wide sanitation plans, thereby put in place processes that help reach outputs
pertaining to safe collection, disposal and disposal (including conveyance, treatment, and/
or re-use without adverse impacts on the environment in and around the cities). It may be
noted that the awards will not recognize mere inputs, hardware or expenditure incurred in
urban sanitation but assess how these lead to achievements of intermediate milestones
toward the final result of 100 % safe disposal of wastes from the city on a sustainable
basis. Cities will need to raise the awareness of city stakeholders (households,
establishments, industries, municipal functionaries, media, etc.) since improved sanitation
can ensure improved public health and environmental outcomes only if considerable
changes in behaviour and practice take place across the spectrum of society.
Concept of Totally Sanitized Cities
A totally Sanitized City will be one that has achieved the outputs or milestones specified in
the National Urban Sanitation policy, the salient features of which are as follows:
■
■

■
■

■
■
■

Cities must be open defecation free
Must eliminate the practice of manual scavenging and provide adequate personnel
protection equipment that addresses the safety of sanitation workers.
Municipal wastewater and storm water drainage must be safely managed
Recycle and reuse of treated wastewater for non potable applications should be
implemented wherever possible.
Solid Waste collected and disposed off fully and safely
Services to the Poor and Systems for Sustaining Results
Improved Public Health Outcomes and Environmental Standards

Baseline, Eligibility and Selection Procedure
a)

34

Baseline and Planning: First, each of the cities will conduct a survey (based on
secondary and primary data sources) and establish a comprehensive baseline with
respect to (liquid and solid) waste generation, collection and disposal in the city. This
will enable them to place themselves through objective self-assessment, in the

<!-- page 35 -->

National Urban Sanitation Policy

b)

c)

d)

e)

f)

g)

relevant sanitary category (see below). This will form the basis for a City Sanitation
Campaign to mobilize all stakeholders, and raise awareness about and priority to 100
% sanitation. Based on the baseline, the city will draw up and implement with support
from the State Government and Govt. of India, a comprehensive City Sanitation Plan
to address the situation in order to reach the goal of becoming 100% sanitized.
Implementation: The city will implement its City Sanitation Plan in a strategic
manner, clearly prioritizing areas that need urgent attention, and implementing longterm plans in parallel. Again, emphasis will be on mobilizing all city stakeholders and
raising the importance of behaviour change, practices and installations for safe and
sanitary disposal of all wastes of the city on a sustainable basis.
Achievement of milestones: The cities/urban areas that have achieved the
sanitation outputs and outcomes described above and have systems and procedures
in place to sustain these, will apply to their State Governments (State Urban
Development / Municipal Administration Department), for recognition and nomination
for the national award.
State-level Verification and Awards: The state government will be fully responsible
for supporting and supervising their cities to implementing the above steps, and in
this regard, may consider instituting a State-level award scheme to promote
competition amongst the urban areas within the state. State Governments will also
need to launch state level awareness campaigns.
National Cities’ Sanitation Rating: The MoUD, Govt. of India, will commission
independent agencies to carry out surveys of all Class I cities (and other cities
included under JNNURM) and publish the results nationally as the basis for
recognizing performance. In addition, Govt. of India may also request states for
recommending cities showing commendable performance, that will be followed by a
due verification process.
Criteria for Awards: The National Urban Sanitation Advisory Group, constituted by
the MoUD, will be responsible for setting out and revising criteria for the national
award. This Committee will also be the final authority in deciding annual awards to
applicant cities.
Type of Awards: the award scheme will recognize the achievement of cities at the
national level. However, no monetary incentive or reward is envisaged for the award.
The award may however include, for city and state representatives, sponsorship to
participate in national events, trainings, and exchange and learning visits to other
locations.

Rating and Categorization of Cities
■

35

The rating of cities in regard to their performance in sanitation improvements will be
based on set of objective indicators of outputs, processes and outcomes, as
presented in Table (1).

<!-- page 36 -->

National Urban Sanitation Policy

Table 1: Indicative Objective Rating Chart for Sanitation in Cities (Draft)
No

Indicators

1

Ouput-related

50

A
i.

No open defecation sub-total
Access and use of toilets by urban poor and other un-served households
(including slums) - individual and community sanitation facilities
Access and use of toilets for floating and institutional populations adequate public sanitation facilities
No open defecation visible
Eliminate Manual Scavenging and provide personnel protection
equipment to sanitary workers
Proportion of total human excreta generation that is safely collected
(6 points for 100%)
Proportion of total black waste water generation that is treated and
safely disposed off (6 points for 100%)
Proportion of total grey waste water generation that is treated and
safely disposed off(3 points for 100%)
Proportion of treated waterwater that is recycled and reused for non
potable applications
Proportion of total storm-water and drainage that is efficiently and
safely managed (3 points for 100%)
Proportion of total solid waste generation that is regularly collected
(4 points for 100%)
Proportion of total solid waste generation that is treated and safely
disposed off (4 points for 100%)
City wastes cause no adverse impacts on surrounding areas outside
city limits (5 points for 100%)

16

2

Process-related**

30

A
B

M&E systems are in place to track incidences of open defecation
All sewerage systems in the city are working properly and there is no
ex-filtration (Not applicable for cities without sewerage systems)
Septage/sludge is regularly cleaned, safely transported and disposed
after treatment, from on-site systems in the city (MAXIMUM 10 marks for
cities without sewerage systems)
Underground and Surface drainage systems are functioning and are
well-maintained
Solid waste management (collection and treatment) systems are efficient
(and are in conformity with the MSW Rules, 2003)
There is clear institutional responsibility assigned; and there are
documented operational systems in practice for b)/c) to e) above
Sanctions for deviance on part of polluters and institutions is clearly
laid out and followed in practice

4

ii.
iii.
iv.
B
C
D
E
E
F
G
H

C

D
E
F
G

Points*

4
4
4
4
6
6
3
3
3
4
4
5

5

5
4
5
4
3

3

Outcome-related

20

A
B

Improved quality of drinking water in city compared to baseline
Improved water quality in water bodies in and around city compared
to baseline
Reduction in water-borne disease incidence amongst city population
compared to baseline

7

C

7
6

* The marks for the above indicators will be revised every two to three years. Over time, indicators about
more stringent conditions e.g. no-urination, or spitting in open/public spaces, etc. will be introduced as
indicators. The weights accorded to each category and specific indicators will also be revised.** In this
context, bigger cities may consider instituting good practice systems that comply with ISO (International
Standards Organization) and/or BIS (Bureau of Indian Standards) process systems.

36

<!-- page 37 -->

National Urban Sanitation Policy

On the basis of the above rating scheme, cities will be placed in different categories
as presented in Table (2). National rating survey data will utilize these categories for
publication of results.

■

Table 2: City Colour Codes: Categories
No. Category

Description

1

Red

2
3
4

Black
Blue
Green

Cities on the brink of public health and environmental “emergency” and
needing immediate remedial action < 33
Needing considerable improvements 34-66
Recovering but still diseased – 67-90
Healthy and Clean city – 91 – 100

■

■

■

On the basis of plans prepared and implemented, cities will be able to measure the
results of their actions, and be able to clearly chart out their improvements over time
compared to their baseline situation.
On achievement of remarkable results, i.e. coming into the Green category (Healthy
and Clean City), cities will typically become eligible for the national award. Other
cities showing remarkable incremental performance or selective achievements may
also be given special or honorary awards. Cities in different size-classes may also be
considered for category-wise awards.
Based on results of the Rating survey and selection of awardees, cities will be invited
to participate in a National Urban Sanitation Award ceremony.

Special and Honorary Awards
In order to mobilize cities to participate in the competition, two strategies will be followed:■
■

Institution of award schemes as a part of State Strategies
Institution of special and honorary awards to cities showing spectacular performance
in selective dimensions or substantial increments

Special Awards: will be given to recognize special achievements, especially in the initial
stages, since achievement of 100% sanitation may be difficult especially in the initial
stages. For instance, a city may demonstrate remarkable performance in the area of
stopping open defecation although 100 percent treatment may be constrained because of
lack of time and resources within a given year. In such cases of selective performance,
awards will be instituted – in the initial years, these awards will be to accord recognition to:
■
■
■
■

37

Stopping Open Defecation
Remarkable performance in awareness generation
Institutional assignment and implementation of operational procedures
Mobilization of community organizations or non-government agencies in sanitation
campaigns

<!-- page 38 -->

Honorary Awards for Exemplary Performance: It may be difficult for many urban areas
to immediately show all-round performance in sanitation. Therefore, cities showing
maximum overall improvements in a given year, compared to their baseline situation, may
also be given an award with a view to recognition of incremental efforts made.
If State strategies incorporate award schemes, many of the above category of performers
will be pre-selected from states, and sent up for the national competition.

Funding
a)

b)

c)

The Ministry of Urban Development, Govt. of India, will fund the national rating
surveys, and bear the expenses for organizing the annual national Award
Presentation Ceremony.
Cities will utilize funds that they are eligible for, following guidelines, under the Govt.
of India-assisted (JNNURM, UIDSSMT, VAMBAY etc.). State Government schemes
may also supplement funds for the purpose to their cities.
The Government of India will support the cities and State Governments’ efforts by i)
launching a national communication campaign for awareness generation; ii) providing
technical assistance and guidance (Guidance Notes, training and capacity building,
etc.) for cities; iii) Providing funding support from Govt. of India-assisted schemes,
where provided for; and iv) Funding the national rating of cities’ surveys and annual
award ceremony.

<!-- page 39 -->

<!-- page 40 -->

National Urban Sanitation Policy

Government of India

Ministry of Urban Development
Nirman Bhawan, New Delhi 110 011, India
Phone: (91-11) 23022199 • Fax: (91-11) 23062477 • E-mail: secyurban@nic.in

40
