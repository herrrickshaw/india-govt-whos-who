---
doc_id: "0ccf2d0b9d8d8cd1"
source_url: "https://shipmin.gov.in/sites/default/files/Circular%20Sr%20Dy%20Secretary%20MoS.pdf"
ministry: "Ports, Shipping and Waterways (MoPSW)"
title: "Circular Sr Dy Secretary MoS.pdf"
date: ""
pages: 12
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "caf7302449b0cf88"
---

<!-- page 1 -->

& “विभाग
R/Phkone: 91-22-6656 4096 | 6s सामान्य प्रशासन T
$awEmail: secretary@mumbaiport.gov.in wh पोर्ट भवन, दूसरा माला
anargz/Websiterwww.mumbaiport.goy.in मुंबई बर्ड पत्तन प्राधिकरण ser sane बेलार्ड इस्टेट,
; Mumbai Port Authority Uae .
~r 2 & 15 SR General Administration
G 9 as Fe Department,
toy (7) eo
कक ey हु) S.V. Marg, Ballard Estate,
No. GAD/P/RECT-Sr.Dy Secretary! D 60 Co ee 2025
Recruitment Notice
The Chairpersons
All Major Port Authorities Authorities
Sir/Madam,
Sub: Filling up the post of Sr. Dy. Secretary in the pay scale of
Rs. 80000-220000 by absorption through Composite Method
in Mumbai Port Authority — Reg.
1. The post of Sr. Dy. Secretary in Mumbai Port Authority will fall vacant wef.
1.7.2025. The post is to he filled by absorption through composite method from officers
of Major Ports, fulfilling the eligibility criteria as mentioned at Annexure I.
2. The selection is by merit for which overall grading in the APARs should not
be below “Very Good’.
3. Applications are invited from eligible and willing officers of all the
Major Port Authorities possessing the prescribed qualifications and experience as
mentioned at Annexure I. The application shall be submitted through 'Online
Application Portal (OAP)' of the Ministry of Ports, Shipping and Waterways
(website http://onlinevacancy.shipmin.nic.in) -/fonlinevacancy.shipmin.nic.in) from 27.1.2025 to 25.2.2025. No
application submitted other than OAP will be accepted.
4. wis The candidate has to submit the hard-copy of the application form uploaded in OAP
to his administrative Port for onward forwarding to MbPA.
5. The administrative Ports are required to forward the applications of the candidates
—_- ‘Application for the post of Sr. Dy. Secretary in Mumbai Port
uthority” on or before 12.3.2025, along with the following documents:
Lind न
(....2)

<!-- page 2 -->

‘ : ee

(9) certified copies of APARs for the last 5 years (2019-20 to 2028-24), duly
attested by an officer not below the rank of Dy. HOD on each of the
pages;

(ii) @ statement showing year-wise availability of APARs and grading
duly signed by the HoD/ Secretary. If APAR for a particular year
during the last 5 years is not available, "No Report Certificate" may be
furnished, along with APARs of the preceding years;

(iii) Attested Photocopies of all certificates and proof of educational
qualification, present and past work experience in the respective post
and pay scale.

(iv) No objection certificate from the respective Port,

(v) Undertaking of the applicant that he will not withdraw his
candidature, if selected by Services Selection Committee;

(vi) Administrative clearance of the concerned port (Annexure ID)

(vii) Vigilance report is to be furnished in the prescribed format (Annexure
Il).

(viti) If any. major or minor penalty has been imposed on the applicant
during the last 10 years, the disciplinary case leading to such penalty
along with necessary documents may be sent along with the
application.

6. As per the Ministry’s circular No. A-29018/4/2081/PE-I dated 11.8.2021, in
case of receipt of advance copy of application from any candidate, his candidature
will not be considered if his application is not received through proper
channel from the Port within 15 days of the last date of receipt of applications.
Therefore, Major Ports are requested to forward the applications with complete set
of enclosures on or before 12.3.2025. Applications received after 12,3,2025 lications received after 12.3.2025
will not be considered.
7. While forwarding the application, the Major Ports are to enclose all relevant
documents at a time. No piecemeal/part forwarding will be considered.
8. The crucial date for eligibility criteria will be the date of arising of vacancy,
ie. 1.7.2025 in terms of Ministry of Ports, Shipping and Waterways’ circular No.
A-29018/4/2081/PE-I dated 11.8.2021.

(.....3)

५००१

<!-- page 3 -->

es न
9. As per the Ministry’s guidelines dated 11.8.2021 regarding filling up the Dy.
HoD level posts in Major Port Authorities, Port official who withdraws his
candidature for the post after his selection by the Services Selection Committee,
will be liable for debarment from future selection to Dy. HoD level posts in all Major
Port Authorities for a period of two years.
10. Incomplete applications or applications received after due date will not be
considered.
Yours faithfully,
etic: eae
(P.N. Bah 9)
Encl: As above SECRETARY
MUMBAI PORT AUTHORITY
COPY TO:
1) The Secretary to the Government of India,
Ministry of Ports, Shipping & Waterways,
New Delhi for information. (Kind Attn: Shri Pradeep
Soft copy of the cireular is already forwarded Kumar Roy, Director —PHRD
on email address:
pravin.s@nic.in and web-ship@gov.in.

<!-- page 4 -->

: ब् Annexure I
Name of | No. | Classif | Scale | Whether Upp | Educational and other | Whether Perio | Method of In case of promotion/ Re
the Post of ication | of Selection | er qualifications (a) age dof | recruitment absorption/deputation, mar
Pos Pay orNon- | Age | prescribed for direct (b) Prob | (whether by grades from which it ks
: t Rs.) Selection | limit | recruitment educationa | ation | direct should be made
for 1 Gn recruitment or
direc qualificati | years | by
t ons M promotion/absor
recr © ption/deputatio
uitm experience n/
ent for direct
Gn recruits
year will apply
8) in the case
of
promotion
absorption
/deputatio
n
ee | | | A | S| CGO ep [SNS पलक
Senior 16000 | Selection Essential :- (a) No By absorption Officers holding x
Deputy -400- (@ A degree from (b) Yes through analogous posts or the
Secretary/ 20800 recognized University. | (c) No composite post of Dy. Secretary and
Senior (ii) Twelve years’ method failing | equivalent posts in the
Personnel experience in which respective discipline of
Officer executive cadre in the GAD (such as CPRO/Dy.
field of General By deputation Estate Manager/Dy. Chief
Administration, from other Law Officer/Personnel
Personnel, Industrial Govt. Officer) in the scale of pay
Relations etc. in an organizations of Rs. 13000-18250 with 3
Industrial/Commercial and failing both | years’ regular service in
/Govt. Undertaking. the grade in a Major Port
By direct Trust or Dy. Secretary
Desirable:- recruitment and equivalent posts in
@) Post Graduate the respective discipline
degree/diploma in of GAD with 2 years’
Personnel regular service in the
Management grade and a combined
Industrial Relations regular service of 7 years
Social Work/Labour in the scales of pay of Rs.
Welfare or allied 10750-16750 and Rs.
subjects or degree in 13000-18250 in respective
Law from a recognizer discipline of GAD in a
University/Institution. Major Port Trust will be
eligible.

<!-- page 5 -->

था ANNEXURE II II
SANEXURE IT
Certificate to be given by Head of Department of to be given b Head of Department of
Shri/Smt.
na आम
Designation,
a ae

1. It is certified that the particulars furnished by the officer are correct,

2 It is certified that no disciplinary/vigilance case is pending or contemplated
against the applicant and he/she is clear from Vigilance and Administrative
angle.

By His/Her integrity is certified.

4. It is certified that no major/minor Penalties have been imposed on the
applicant during the last 10 years. If any, kindly indicate details thereof.

5. Attested copies of ACRs for the last five years (1.4.2019 to 31.3.2024) are
enclosed.

6. It is certified that the incumbent meets the requisite eligibility criteria w.r.t,
educational qualification and experience ag specified in the Annexure I of the
circular for absorption through composite method.

SIGNATURE OF THE
HEAD OF DEPARTMENT WITH SEAL

<!-- page 6 -->

Annexure III
Format IIT
: MUMBAI PORT AUTHORITY
Particulars of the wn 80k the officer for whom Vigilance Comments/Status has been sought for whom Vigilance Comments/Status has been sought
Name of Officer (in full al fe een
Fea: te ee
Date of Birth akc 2
Date of Retirement हि aaa
Date of entry into service Foie ea ey
Service to which the officer belongs
wherever applicable
Revised Payscale EPS ee Oe
Whether Annual Property Return (APR) has
been submitted in time
[9 [Date of submission of APR as a Deeg S|
10 Positions held including whether the officer has functioned as a CVO in part
time or additional charge capacity (During the ten precedin; ears
SL | Organization Designation and | Administrative/ From To
No. | (Name in full) | Place of posting Nodal Ministry/
Deptt.
11 | Whether any punishment was awarded to the officer during the last
10 years and if so, the date of imposition and details of the penalty.(*
12 | Is any disciplinary / criminal proceedings or Chargesheet pending
against the officer as on date (Ifso, details to be furnished — including
reference number if any of the commission)
13 | Is any action contemplated against the officer as on date (If so details
to be furnished) (*
14 | Whether any complaint with vigilance angle pending against the
officer as on date (If es, details to be furnished)
Date: TT!__———_Signature of Head of Department) of Head of Department)
15 | Whether the officer has been placed on the "Agreed List" or "List of a
Officers of Doubtful Integrity", If yes details to be given
16 | Whether any allegation of misconduct involving vigilance angle was
examined against the officer during the last 10 years and if so, with
what result (*
The applied post being Selection post at the level of Head of Department, the officer is Clear/not clear
from vigilance angle as per the guidelines of DoPT/CVC issued from time to time.
Date : CHIEF VIGILANCE OFFICER
(*) If vigilance clearance had been obtained from the Ministry/CVC in the past, the information may
be provided for the period thereafter.

<!-- page 7 -->

H/Phone: 91-22-6656 4096 27238 बंद
ई-मेलशएफा्वा: secretary@mumbaiport.gov.in © SUIS PUS विधा %
Saurge/ Website: www.mumbaiport.gov ia Se पोर्ट भवन, दूसरा माला
मुंबर्ड पत्तन प्राधिकरण शूरजी वल्लभदास मार्ग, बेलार्ड इस्टेट,
= Mumbai Port Authority मुंबई - 400 001. *
( Cy “6 है ee a General Administration
ose ae ॥/ लि ०
SAGARMALA न कलन ey) &) S.V. Marg, Ballard SSS NEE अमन
PORT LED eROseE RITE re Sie RY > oh Bet Tacisir of Progen 8 Property MUMBAI - 400 001.
सं.सा.प्र.वि/पी/भर्ती-वउसचिव/ 3 66 2.4- जनवरी 2025
भर्ती सूचना
अध्यक्ष
सभी महापत्तन प्राधिकरण
महोदय/ महोदया,
विषय : मुंबई पत्तन प्राधिकरण में संयुक्त पद्धति से विलयन द्वारा रु. 80000-220000 के
वेतनमान में वरिष्ठ उप सचिव का पद को भरना-संबंधी, :

1... मुंबई पत्तन प्राधिकरण में वरिष्ठ उप सचिव का पद दि. 1.7.2025 से रिक्त होगा. यह पद संयुक्त
पद्धति से विलयन द्वारा महा पत्तन प्राधिकरणों से अधिकारियों का समावेश करके भरा जाना है, जिसके लिए
आवश्यक पात्रता मानदंड अनुलग्नक- 1 में है.

2... चयन प्रक्रिया योग्यता के अनुसार होगी, जिसके लिए एपीएआर में समग्र ग्रेडिंग "वेरी गुड" से कम
नहीं होनी चाहिए.
3... अनुलग्नक-1 के अनुसार निर्धारित योग्यता, अनुभव के धारक सभी महा पत्तन प्राधिकरणों के पात्र
और इच्छुक अधिकारियों से आवेदन आमंत्रित किए जाते हैं. आवेदन 27.1.2025 से
25.2.2025 तक RH, पोत परिवहन तथा जलमार्ग मंत्रालय. (वेबसाईट
http://onlinevacancy shipmin anic.in) & "ऑनलाईन आवेदन पोर्टल (ओएपी)" के माध्यम से
प्रस्तुत किया जा सकता है. ओएपी के अलावा कोई भी आवेदन स्वीकार नहीं किया जाएगा.
4... उम्मीदवार को ओएपी में अपलोड किए गए आवेदन पत्र की हार्ड कॉपी अपने प्रशासनिक पोर्ट के पास
मुं.प. प्रा. को अग्रेषित करने हेतु प्रस्तुत करना होगा.
5. प्रशासनिक पत्तनों को दिनांक 12.3.2025 को या उससे पहले उम्मीदवारों के आवेदन निम्नलिखित
दस्तावेजों के साथ लिफाफे में भरकर लिफाफे पर "मुंबई पत्तन प्राधिकरण में वरिष्ठ उप सचिव के पदके
लिए आवेदन" इस प्रकार लिखकर अग्रेषित करने होंगे:
oral

<!-- page 8 -->

(i) feet 5 af # (2019-20 % 2023-24 am) allie Frere मूल्यांकन रिपोर्टो की
प्रमाणित प्रतियाँ, उप विभागप्रमुख स्तर के अधिकारी द्वारा हर एक पन्ने पर विधिवत प्रमाणित
करके;

(४) वार्षिकनिष्पादन मूल्यांकन रिपोर्टों की वर्षवार उपलब्धता तथा श्रेणीकरण दशनिवाला विवरण
विभाग प्रमुख/सचिव द्वारा विधिवत हस्ताक्षरित हो. पिछले पाँच वर्षो में से यदि किसी विशिष्ट
वर्ष/अवधि की वार्षिक निष्पादन मूल्यांकन रिपोर्ट उपलब्ध न हो, तो उसके बारे में "रिपोर्ट
नहीं है प्रमाणपत्र" पूर्ववर्ती वर्षों के वार्षिक निष्पादन मूल्यांकन रिपोर्ट के साथ प्रस्तुत
किया जाए;

(४1) संबंधित पद एवं वेतनमान के लिए सभी प्रमाणपत्रों की सत्यापित फोटोकॉपीयाँ तथा शैक्षणिक
योग्यता प्रमाणपत्र और वर्तमान तथा पिछले कार्य का अनुभव प्रमाणित करना आवश्यक है.

(५) संबंधित पोर्ट द्वारा अनापत्ति प्रमाण पत्र.

(५) आवेदक को इस आशय का प्रतिज्ञापत्र देना होगा कि यदि सेवा चयन समिति द्वारा चयन किया

गया, तो उम्मीदवारी वापस नहीं ली जाएगी, तथा

(i) संबंधित पोर्ट की प्रशासनिक अनापत्ति (अनुलग्नका);

(शा) निर्धारित प्रपत्र में सतर्कता रिपोर्ट प्रस्तुत किया जाए (Sere TT)

(शा) यदि पिछले 10 वर्षो के दौरान आवेदक पर कोई बड़ा या मामूली दण्ड लगाया गया हो, तो
ऐसे दण्ड की और ले जानेवाली अनुशासनिक मामले के साथ आवश्यक कागजात भी आवेदन
के साथ भेजा जाए.

6. पोर्ट द्वारा किसी भी आवेदक के संबंध में आवेदन की अग्रिम प्रति प्राप्त होने के मामले में मंत्रालय के
दिनांक 11.8.2021 के परिपत्र सं. ए. 29018/4/2081/ पीई-1 के अनुसार यदि उसका आवेदन पोर्ट द्वारा
उचित माध्यम से आवेदन प्राप्त करने की अंतिम तिथि के 15 दिनों के भीतर तक प्राप्त नहीं हुआ तो उम्मीदवार
की उम्मीदवारी पर विचार नहीं किया जाएगा. अत: महापत्तनों से अनुरोध है FF 82.3 2025 को या उससे
पहले संलग्नकों के पूरे सेट के साथ आवेदनों को अग्रेषित करें. 12.3.2025 के बाद प्राप्त आवेदनों पर
विचार नहीं किया जाएगा.
7. आवेदन को अग्रेषित करते समय, महापत्तनों को सभी संगत कागजातों को एक ही समय में संलग्न
करके भेजना होगा. कोई भी आधे-अधूरे/अंश भाग के अग्रेषण पर विचार नहीं किया जाएगा.
8  पत्तन, पोत परिवहन तथा जलमार्ग मंत्रालय के दिनांक 11.8.2021 की पत्र ax
29018/4/2081/पीई- के संदर्भ में पात्रता मानदण्ड के लिए निर्णायक तिथि 1.7.2025 होगी.
५6००)--

<!-- page 9 -->

9. मंत्रालयके दिनांक 11.8.2021 के दिशानिर्देशों के अनुसार महा पत्तन प्राधिकरणों में उप विभाग प्रमुख
स्तर के पदों को भरने के संबंध में, पोर्ट अधिकारी यदि सेवा चयन समिति द्वारा अपने चयन के बाद पद के लिए
अपनी उम्मीदवारी वापस लेता है तो वह भविष्य में दो वर्षों के लिए सभी महा पत्तन प्राधिकरणों में उप विभाग
प्रमुख स्तर के पदों के चयन के मामले में रोक के लिए उत्तरदायी होगा.
10. नियत तिथि के पश्चात या अपूर्ण आवेदनों का विचार नहीं किया जायेगा.
भवदीय,
०
loa) ews
(पवन ना. बाहेकर)
संलग्न. यथोक्त. सचिव
मुंबई पत्तन प्राधिकरण
प्रतिलिपि

1) सचिव, भारत सरकार, पत्तन, पोत परिवहन

तथा जलमार्ग मंत्रालय,

नई दिल्‍ली को सूचनार्थ प्रेषित (ध्यानाकर्षण: श्री प्रदीप कुमार

पर aoe pith पहले ही ईमेल पता: े रॉय, निदेशक, पीएचआरडी)

pravin.s@nic.in and web-ship @gov.in.

पर अग्रेषित की गई है.

<!-- page 10 -->

SATS BT Ue a संसाधन विभाग
पद का नाम पर्दों | वर्गीकरण | वेतनमान । पदचयन सीधी भर्ती | सीधी भर्ती के लिए क्या सीधी भर्ती | often | achat पदोन्‍नति/विलयन/ प्रतिनियुक्ति के अभ्युक्ति
की (सये) |या केलिए निर्धारित शैक्षिक के लिए निर्धारित | की पध्दति मामले में भर्ती किस श्रेणी से की जानी
संख्या गैरचयन | अधिकतम | एवं अन्य योग्यताएँ (क) आयु अवधि | (सीधी भर्ती |है
पद आयु सीमा (ख) शैक्षिक (वर्षों | या पदोन्‍नति/ ९
(वर्षों में) योग्यताएँ में) विलयन/
(ग) अनुभव प्रतिनियुक्ति
पदोन्‍नति/ ERT)
विलयन/
प्रतिनियुक्ति के
मामले में लागू है
“जल जे कि ae a ee
5. | वरिष्ठ श्रेणी -1 16000- चयन 42 अनिवार्य : (क) नहीं मिश्रित | मिश्रितपछतति द्वारा विलयन के लिए
उप सचिव/ — वर्ष 1) मान्यताप्राप्त (ख) a पध्दति द्वारा |
ane | 20800 विश्वविद्यालय से पदवी | (ग) नहीं विलयन से | में सादृश पदपर रहे अधिकारी या
अन्यथा | 13000-18250 रु वेतनमान में उप
अधिकार #)औद्योगिक/वाणिज्य/ सचिवके पदपर रहे या किसी महापत्तन
है सरकारी उपक्रम में अन्य. | * सामान्य प्रशासन में तत्समान पद वाले
सामान्य प्रशासन, कार्मिक, ae (जैसे कि, मुख्य जनसंपर्क अधिकारी/
औचोगिक संबंध आदि में संस्थाओं से | >' संपदा प्रबंधक/उप मुख्य विधि
कार्यकारी पदपर 12 वर्षो संस्थाओं से अधिकारी/ कार्मिक अधिकारी) रहे उसी
का अनुभव प्रतिनियुवित्त | ac de वर्षों की नियमित सेवा
द्वारा, | वाले अधिकारी या संबंधित सामान्य
वांछनीय : प्रशासन में उप सचिव और तत्समान पद
1) मान्यताप्राप्त दोनों द्वारा न | वाले तथा उसी वेतन श्रेणी में 2 वर्षों की
विश्वविद्यालय/संस्था से होने से | नियमित सेवा वाले और किसी महापत्तन
मं में संबंधित सामान्य प्रशासन में 10750.
संबंध/समाज सेवा/श्रम 16750 तथा 13000-18250 रु इन
कल्याण या उससे संबंधित West वेतनमानों में 7 वर्षों की संयुक्त नियमित
विषयों में स्नातकोत्तर a सेवा करनेवाले अधिकरी अ्क हैं.
'पदवी/पदविका या कानून प्रतिनियुक्तिकेलिए
| errata, सरकारी/अर्धसरकरी/स्वायत्त निकाय में
सादृश पंद वाले अधिकारी या सामान्य
| प्राशासन में 13000-18250 रु
| वेतनमान में उस वेतन श्रेणी में 3 वर्ष
i नियमित सेवा करनेवाले उपसचिव या
तत्समान पद वाले अधिकारी अर्दक
होंगे. योग्यता के आधार पर चयन किया
i जाएगा जिसके लिए वार्षिक गोपनीय
| रिपोर्ट में संपू्ण श्रेणी करण का स्तर
"बहुत अच्छा" से कम नहीं होना चाहिए,
