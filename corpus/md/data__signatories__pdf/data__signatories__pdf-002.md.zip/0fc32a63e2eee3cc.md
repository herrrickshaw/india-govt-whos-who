---
doc_id: "0fc32a63e2eee3cc"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/babae9a4888f771a3a54183a15cd2747.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "40 2017 04 13 Implementation of eOffice-Lite (SPARROW) in DoT - Extension of Testing Phase"
date: "2017-04-13"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d5f070ecea4a1aac"
---

<!-- page 1 -->

File No.8-36/2015-IT-V

Government of India
Minis try of Communications
Department of Telecommunications
Sanchar Bhawan, 20, As hoka Road
New Delhi - 110 001
New Delhi, Dated the 13/04/2017
Subject: Imple me ntation of e Office -Lite (S PARROW) in DoT – Exte ns ion of
te s ting phas e
In continuation to even no. letter dated 06.04.2017 regarding implementation of
eO ffice-Lite(SPARRO W) in DoT, it is to intimate that the duration for awarenes s ,
learning and tes ting for eO ffice-Lite (SPARRO W) portal [https ://s parrowdot.eoffice.gov.in/] for filling up of eAPAR for the year 2016-17 has been extended upto
26.04.2017 for DoT O fficers (ITS, IP&T AFS, IP&T BWS and IRRS Cadres ).
Subs equently, the SPARRO W portal s hall be under maintenance for a s hort period
before getting live.
2.
This is is s ued with the approval of S ANJAY KUMAR MITTAL, DDG(S KM)IT, O/o DDG(IT)
Signature Not Verified

Digitally signed by VINAI KUMAR KANAUJIA
Date: 2017.04.13 16:19:38 IST

(Vinai Kumar Kanaujia)
Director(IT)
Telephone-2303 6509
To:
DDG(Es tt.), DDG(E&F) and JS(A)
Copy to:
1. Role Admin/Nodal O fficer through Cadre Controlling Authorities
2. NIC-DoT
