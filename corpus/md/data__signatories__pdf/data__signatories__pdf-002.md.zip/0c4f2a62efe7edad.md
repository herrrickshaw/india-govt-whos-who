---
doc_id: "0c4f2a62efe7edad"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/2edabc6342478bfea967eb3c4157d42b.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Proposed Recruitment Rules for the post of Lower Division Clerk in RAK College of Nusing Lajpat Nagar. New Delhi - Schedule"
date: "2024-08-09"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7a81e6670b8be64b"
---

<!-- page 1 -->

Schedule-I
Name of the Number of
post
post

(1)

Classification Level
in the
pay
matrix

(2)

Lower
07
Division Clerk

(3)

(4)

Whether Whether benefit Age- limit for direct recruits
selection of added years
or non- of service
selection admissible
post
under Rule 30
of the CCS
(Pension)
Rules, 1972.

(5)

(6)

(7)

General
Level-2 NonNot Applicable
Central Civil (19900- Selection
Services
63200)
Group ‘C’
NonGazetted/
Ministerial

Educational and other
qualifications required for direct
recruits

(8)

i. 12th Class or equivalent
qualification from a

Between 18 and 27 years of
age
(Relaxable
for
Government servants up to 40
years in accordance with the
instructions or orders issued by
the Central Government).
Note: The crucial date for
determining the age limit shall
be the as ﬁxed by the Staﬀ
Selection Commission. (Where
recruitment is not through
SSC,
crucial
date
for
determining the age limit shall
be the last date for receipt of
application.)

Whether age and Period
of Method of recruitment whether by
educational
probation if any direct recruitment or by promotion or
qualifications
by deputation/ absorption and
prescribed for
percentage of the vacancies to be
direct recruits will
filled by various methods
apply in the case
of promotes
(9)

(10)

Yes, to the extent 02 Years
indicated in Col.
11.

(11)

i. 85% by direct recruitment
through SSC. (The words

recognized Board or

“through SSC” may be

University.

deleted, where recruitment is

ii. A typing speed of 30 w.p.m.
in English or 25 w.p.m. in
Hindi on manual typewriter
Or
A typing speed of 35 w.p.m. in
English or w.p.m. in Hindi on
computer. (35 w.p.m. and 30
w.p.m. correspond to 10500
KDPH/9000 KHPH on an average
of 5key depressions for each work)
reserved for them.

not through SSC).

ii. 10% of the vacancies shall
be filled from amongst the
Group C Staff in the Grade
pay of Rs. 1800 and who
possess 12 th Class pass or
equivalent qualification and
have rendered 3 years
regular service in the grade,
on the basis of departmental
qualifying examination is 45
years. (50 years of age for
the SC/ST)
Note:- if more of such employees
than the number of vacancies
available under Clause (ii) qualiﬁed
at the examination, such excess
number of employees shall be
considered for ﬁlling the vacancies

<!-- page 2 -->

arising in the subsequent years so
that the employees qualifying at an
earlier examination are considered
before those who qualify at a later
examination. (iii) 5% of the
vacancies shall be filled on senioritycum ﬁtness basis from Group C
employees who have 3 years
regular service in posts with the
Grade Pay of Rs. 1800/-.
In
case
of
recruitment
by If a Departmental Promotion Circumstances in which
promotion/deputation/absorption grades from Committee exists, what is its Union
Public
Service
which promotion/ deputation/absorption to be composition.
Commission to be consulted
made
in making recruitment.
(12)
As stated in Col. 11

(13)
Group ‘C’ Departmental
Promotion Committee (for
considering promotion):

1 Nursing Advisor , Dte.GHS,
MoHFW - Chairperson
2 Principal , RAKCON
- Member
3 Deputy Director, RAKCON Member
4 Administrative Officer,
RAKCON –
Member

Group ‘C’ Departmental
Confirmation Committee (for
considering confirmation):
1 Nursing Advisor, Dte.GHS,
MOHFW - Chairperson
2 Principal, RAKCON
- Member
3 Deputy Director, RAKCON Member
4 Administrative Officer,
RAKCON –
Member

(Full composition with specific
designation may be given).

(14)

Not applicable
