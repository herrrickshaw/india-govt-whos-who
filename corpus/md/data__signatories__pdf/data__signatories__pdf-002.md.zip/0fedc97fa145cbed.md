---
doc_id: "0fedc97fa145cbed"
source_url: "https://mnre.gov.in/static/uploads/2025/08/608d45ae7480540c77907115f578140d.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Exemption for BIS registration to SPV Module Manufacturers with annual production capacity less then 50MW having valid IEC Certificates under MNRE Quality Control Order on SPV Systems, Devices and Goods Order 2017"
date: "2020-10-23"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7c25166b7a24d4fc"
---

<!-- page 1 -->

रजजस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-23102020-222693
xxxGIDExxx
CG-DL-E-23102020-222693
ऄसाधारण
EXTRAORDINARY
भाग II—खण्ड 3—ईप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3369]
No. 3369]

नइ ददल्ली, िुक्रवार, ऄक्तूबर 23, 2020/कार्षतक 1, 1942
NEW DELHI, FRIDAY, OCTOBER 23, 2020/KARTIKA 1, 1942

नवीन और नवीकरणीय उजाा मंत्रालय
ऄजधसूचना
नइ ददल्ली, 23 ऄक्तूबर, 2020
का.अ. 3798(ऄ).—यतः के न्द्र सरकार ने ऄनुसूची में सजममजलत 6 ईत्पादों हेतु ददनांक 05 जसतमबर, 2017 के
का.अ. 2920(ऄ) के तहत ‘सौर प्रकािवोल्टीय, प्रणाजलयााँ, ईपकरण और घटक सामग्री (ऄजनवाया पंजीकरण की
अवश्यकता) अदेि, 2017’ जारी दकया था, जजसके प्रभावी होने की तारीख 5 जसतमबर, 2018 थी। और यतः भारतीय
मानक ब्यूरो (बीअइएस) सजहत जवजभन्न जहतधारकों के साथ जवचार-जवमिा के ईपरान्द्त का.अ. सं. 2183(ऄ) के तहत
ददनांक 30 मइ, 2018 को ऄजधसूजचत भारत के राजपत्र में प्रकाजित और 30 जून, 2018 तक प्रभावी अदेि के साथ
ऄनुबद्ध ऄनुसूची में क्रम सं. 1-5 के ईत्पादों के जलए जवजनमााता द्वारा स्ट्वतः प्रमाणन देने की िता पर ईक्त अदेि के प्रभावी
होने की तारीख को पहले करके 16 ऄप्रैल, 2018 कर ददया गया था, जजसे ददनांक 13.07.2018 के का.अ. सं. 3449(ऄ)
के खंड 2 के तहत ददनांक 4 जसतमबर, 2018 तक और अगे बढाया गया था।
2.
आसके ऄलावा, ऐसे माड्यूल जनमााताओं को जजनकी वार्षिक ईत्पादन क्षमता 50 मेगावाट से कम है, भारत के
राजपत्र में ऄजधसूजचत का.अ. सं. 3449(ऄ) के खंड 3 के तहत बीअइएस प्रमाणीकरण के जलए 04.09.2020 तक दो विा
तक की छू ट दी गइ है, बिते ईनके पास आस ऄवजध के जलए वैध अइइसी प्रमाण पत्र (या तो 2005 ऄथवा 2016) या ईस
ऄवजध जजसके जलए अइइसी प्रमाणपत्र, जो भी पहले हो, वैध था, तथा आसके ऄलावा, आस िता पर दक ईनके द्वारा
16.04.2018 से पहले अइइसी प्रमाणपत्र प्राप्त दकए गए हों ।
3.
और यतः ऄजखल भारतीय सौर ईद्योग संघ (एअइएसअइए), नइ ददल्ली ने यह सूजचत दकया है दक कोजवड 19
की घटना के चलते घरे लू सौर ईद्योग को बचाए रखने की गंभीर चुनौजतयां सामने अइ हैं और ईनके ईत्पादों के जलए
अइइसी प्रमाण पत्र की वैधता तक एसपीवी माड्यूलों के जलए बीअइएस प्रमाणन छू ट को अगे बढाने की मांग की है, ऄत:
5171 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

यह ऄजधसूजचत दकया जाता है दक ददनांक 13.07.2018 की ऄजधसूचना के खंड 3 को संिोजधत दकया जाता है, और ऐसे
माड्यूल जनमााताओं के जलए ईक्त अदेि में जवजनर्ददष्ट भारतीय मानकों के ऄनुरूप, अइइसी प्रमाण पत्रों की वैधता तक
बीअइएस पंजीकरण से छू ट प्रदान की जाती है, बिते दक एसपीवी माड्यूलों के जलए अइइसी प्रमाण पत्र 16.04.2018 से
पहले प्राप्त दकए गए हों। आन जनमााताओं को अइइसी प्रमाण पत्रों की वैधता समाप्त होने के बाद ऄजनवाया रूप से बीअइएस
पंजीकरण कराना होगा।
[फा. सं. 223/140/2017-अर एंड डी समन्द्वय (गुणवत्ता जनयंत्रण)]
डॉ. बी.एस. नेगी, सलाहकार/वैज्ञाजनक ‘जी’, एमएनअरइ
MINISTRY OF NEW AND RENEWABLE ENRGY
NOTIFICATION
New Delhi, the 23rd October, 2020
S.O. 3798(E).—Whereas the Central Government had issued “Solar Photovoltaics, Systems,
Devices and Components Goods (Requirements for Compulsory Registration) Order, 2017 “vide
S.O. 2920(E) dated 5th September 2017 for six products included in the Schedule with the date of
coming into force with effect from 5th September 2018. And whereas, after having discussions with the
various stakeholders including the Bureau of Indian Standards (BIS), the date of coming into force
of the said Order was advanced to 16th April 2018 on the condition of self-certification by manufacturers
for products at Sl. No. 1-5 in the Schedule annexed to the same order applicable till 30th June, 2018
published in Gazette of India notified on 30th May 2018 vide S.O. 2183(E), which was further extended
to 4th September 2018 vide Clause 2 of S.O. No. 3449(E) dated 13.07.2018.
2.
Further, the module manufacturers whose annual module production capacity is less than 50MW,
vide Clause 3 of S. O 3449(E) notified in Gazette of India on 13th July 2018 were exempted for BIS
certification for two years till 4.09.2020 provided they had a valid IEC Certificate (either 2005 or 2016)
for the period, or for the period for which IEC certificate was valid, whichever is earlier and further
provided the IEC certificate had been obtained before 16.04.2018.
3.
And whereas, All India Solar Industries Association (AISIA), New Delhi has conveyed that
COVID 19 disruption has posed serious challenges for the survival of domestic solar industry, and
sought extension of the BIS certification exemption till the validity of IEC certificates for their products
(SPV Modules), it is hereby notified that the Clause 3 of the notification dated 13.07.2018 stands revised
allowing exemption for BIS registration to such modules manufacturers till the validity of IEC
certificates corresponding to the Indian Standards specified in the said order provided the IEC certificates
for SPV Modules had been obtained before 16.04.2018. These manufacturers will be required to go
compulsorily for BIS registration after the validity of IEC Certificates is over.
[F. No. 223/140/2017-R&D Coord.(Quality Control)]
Dr. B.S. NEGI, Adviser/Scientist 'G', MNRE

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. KUMER CHAND
MEENA

Digitally signed by KUMER
CHAND MEENA
Date: 2020.10.23 21:35:30
+05'30'
