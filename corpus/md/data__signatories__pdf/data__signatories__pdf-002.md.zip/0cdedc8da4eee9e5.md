---
doc_id: "0cdedc8da4eee9e5"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/f4b0ad03d03fc481989c50fdd2f387d5.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Instructions regarding allocation of cases: OM dated 19.04.2016"
date: "2016-04-19"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "929281c281eeda42"
---

<!-- page 1 -->

•
F.No. J-18/1/2016-Judl.
Government of India
Ministry of Law & Justice
Department of Legal Affairs

Shastri Bhawan, New Delhi
19th April, 2016

OFFICE MEMORANDUM

Instructions have been issued from time to time by this Ministry with regard
to handling of court cases by the Law Officers as well as the Panel Counsels.
The Ministry has appointed Addl. Solicitor General in the recent past in the
High Court of Punjab and Haryana at Chandigarh, High Court of Rajasthan at
Jaipur, High Court of Karnataka at Bangalore. Certain instances have been brought
to the notice of the Ministry where allocation of the cases have not been done as per
the instructions issued in this regard. It is reiterated that wherever there is a
Branch Secretariat of this Ministry of Law and Justice. i.e. Mumbai, Kolkata,
Chennai and Bangalore, cases are to be allocated to the Panel Counsels by the
In-Charge Branch Secretariat of the Ministry. However, in respect of important
cases, the In-Charge of the Branch Secretariats are advised to consult the Addl.
Solicitor General for proper defence of the cases.
Wherever there is no Branch Secretariat, it is the Addl. Solicitor General of
India, who will be over all In-Charge of the litigation and is required to allocate
cases to the Government Counsels ensuring that there is proper distribution of
cases. He is also required to maintain records of the cases distributed and forward a
statement to the Main Secretariat to enable compilation of statistics in this regard.
In so far as Karnataka is concerned, there are two Addl. Solicitors General,
one for the Karnataka High Court at Bangalore and other for the Southern Zone i.e.
for the High Courts of Andhra Pradesh and Kerala. Each of them is responsible for
handling litigation matters in respect of their jurisdiction only.
In respect of High Courts, where no Addl. Solicitor General has been
appointed, it is the Assistant Solicitor General, who is responsible for equitable
distribution of cases among the empanelled Counsels in courts. Assistant Solicitors
General are also required to furnish monthly statement of the cases distributed
among the Counsels.

Contd....2

<!-- page 2 -->

-2-

Monthly statements about distributions of cases to Panel Counsels/Law
Officers should be furnished to the Main Secretariat by 10th day of the following
month.

( .K. Malhotra)
Law Secretary
To
1. The Incharge, Central Agency Section.
2. The Incharge Litigation (High court) Section, CAT(PB) New Delhi, Lower Court
Section.
3. The Incharge, Branch Secretariats Bangalore, Bombay, Chennai and Kolkata.
4. Additional Solicitors General of Rajasthan, Allahabad, Punjab 86 Haryana and
Patna High Courts 86 Southern Zone.
5. Assistant Solicitors General of All High Courts other than Rajasthan, Allahabad,
Punjab 86 Haryana and Patna.
