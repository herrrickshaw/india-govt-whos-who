---
doc_id: "0ee939cb1aa89bdc"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/6430aee5b3b9979089c83c8dbf0e38e6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Corrigendum regarding telecomunication identifiers in series 1600 to Bharti Airtel Limited"
date: "2025-02-13"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6e1fb4b474be3fc4"
---

<!-- page 1 -->

<!-- page 2 -->

16-02/2024-AS-III

I/3249156/2025

Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No.16-02/2024-AS-III/N62

Dated: 11.02.2025

To,
M/s Bharti Airtel Limited
Subject: Allocation of telecommunication identiﬁers in numbering series
'1600' exclusively for service and transactional voice calls to M/s Bharti Airtel
Limited.
This is in reference to DoT instructions dated 23.12.2024 regarding allocation
of separate numbering series (1600) for service & transactional voice calls and
your application under Saral Sanchar Portal for allotment of telecommunication
identifiers in numbering series '1600' for 22 LSAs.
2.
In this regard, the approval of competent authority is hereby conveyed for
allocation of telecommunication identiﬁers in numbering series '1600' to M/s Bharti
Airtel Limited as tabulated below: S. No. TSP Name

Name of LSA

Proposed code

01

AIRTEL

Andhra Pradesh

1600-100-XXX

02

AIRTEL

Assam

1600-101-XXX

03

AIRTEL

Bihar

1600-102-XXX

04

AIRTEL

Delhi

1600-103-XXX

05

AIRTEL

Gujarat

1600-104-XXX

06

AIRTEL

Haryana

16000-105-XXX

07

AIRTEL

Himachal Pradesh

1600-106-XXX

08

AIRTEL

Jammu & Kashmir

1600-107-XXX

09

AIRTEL

Karnataka

1600-108-XXX

10

AIRTEL

Kerala

1600-109-XXX

<!-- page 3 -->

16-02/2024-AS-III

I/3249156/2025

11

AIRTEL

Kolkata

1600-110-XXX

12

AIRTEL

Madhya Pradesh

1600-111-XXX

13

AIRTEL

Maharashtra

1600-112-XXX

14

AIRTEL

Mumbai

1600-113-XXX

15

AIRTEL

Orissa

1600-115-XXX

16

AIRTEL

Punjab

1600-116-XXX

17

AIRTEL

Tamil Nadu

1600-118-XXX

18

AIRTEL

Uttar Pradesh (West)

1600-119-XXX

19

AIRTEL

Uttar Pradesh (East)

1600-120-XXX

20

AIRTEL

West Bengal

1600-121-XXX

21

BHARTI-HEXACOM

North East

1600-114-XXX

22

BHARTI-HEXACOM

Rajasthan

1600-117-XXX

Note: Value of 'XXX' may range from 000 to 999, giving 1000
telecommunication identifiers for each LSA.
Director (AS-III)
Ph: - 011-23372488
Copy for kind information and necessary action, if any, to:
1. Secretary, TRAI
2. Director (T), DGT Hq. with a request to convey the allocation to concerned
LSA field unit.
3. All MNP Licensees.
4. A copy for upload on DoT website.
