---
doc_id: "0baf074beecd5b73"
source_url: "https://dsel-education.gov.in/static/uploads/2025/10/9d92c7a003cd6ea37c6b2cbdca2a60a0.pdf"
ministry: "Department of School Education and Literacy (DSEL)"
title: "Uttar Pradesh-Corrigendum"
date: "2023-06-12"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "7b6657606ec766ce"
---

<!-- page 1 -->

F.No. 12-1/2023-IS-15
Government of India
Ministry of Education
Department of School Education and Literacy
15-15 Section
aie
Shastri Bhawan, New Delhi
Dated: _ June, 2023
12
Corrigendum
Subject : Samagra Shiksha — Corrigendum to the Minutes of the meeting of the Project
Approval Board held on 28" April 2023 to consider the Annual Work Plan & Budget (AWP&B)
2023-24 of Samagra Shiksha for the State of Uttar Pradesh- reg.

The unde® igned is directed to refer to the State Government’s D.O letter No. Pre-
primary/2587/2023-24 dated 02" June, 2023 regarding PAB proposal 2023-2024 of Uttar Pradesh for
Pre-Primary / ECCE (under Recurring Grant) and to state that after considering the request of the
Govt. of Uttar Pradesh, following changes are made in the remarks of the Pre-Primary Recurring
component(in the costing sheet) on the PAB Minutes relating to the AWP&B of 2023-24 of Samagra
Shiksha, Uttar Pradesh
For:

विस... मम a nee िलनिनिशियश (है | Lakh)
Activity Master Physical | Unit Cost Remarks
Pre-Primary (Recurrin: eee |
TLM for Children 1643445 0.002 3286.89 Recommended

TLM @ @ 200 per
child for 1631168
students enrolled in
Balvatika and
12,277 students in
pre-primary
sections as per
UDISE data.
Support to Pre-Primary (Existing) 31013 0.55609 17246.019170 Recommended at
| proposed average
unit cost for 31013
Balvatika and 242
pre-primary schools
with enrolled
students as per
UDISE.
Grand Total | 05801 [|

<!-- page 2 -->

Read :
MT Bde 2 ae o_o (2 In lakh)
Activity Master Physical | Unit Cost Financial Remarks
2
TLM for Children 1643445 0.002 3286.89 Recommended
TLM @2 200 per
child for 1631168
students enrolled in
Balvatika and
12,277 students in
pre-primary
sections as per
UDISE data.
Support to Pre-Primary (Existing) 31013 0.55609 17246.019170 Recommended as
proposed average
unit cost of &
0.53507 lakh for
30171 Schools and
the unit cost of =
1.30913 lakh for
842 schools under
the SS
[| नई 20532.9
2. Other paras of the minutes circulated vide Department’s communication No. |2-1/2023-IS-15
dated 25" May, 2023 remains unaltered
3. This issues with the approval of the Competent Authority.
197.6] 2023
(Kamal Gandhi)
Under Secretary to the Govt. of India
Tel.No. 011-23070450
To
I. Sh. Deepak Kumar, Additional Secretary, Basic Education Department, Govt. of Uttar
Pradesh.
2. Sh. Vijay Kiran Anand, Director General School Education and State Project Director,
Samagra Shiksha, Uttar Pradesh
Copy to:
1. All Divisional Heads of SS-I and SS-II Bureau.
2. All Under Secretary of SS-I and SS-II Bureau.
Copy for information to:
1. PPS to Secretary (SE&L)
2. PS to AS(SS-I)
3. Ms. Tara Naorem, Principal Chief Consultant
4. Shri Rajeev Mehra, Sr. Consultant
5. Ms. Juhi Kumari, Sr. Consultant
6. Shri Inderjeet Vatsa, Sr. Consultant
