---
doc_id: "0bbbb91feb24a58a"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/260c918c7543061b08085889dee870b1.pdf"
ministry: "Tourism"
title: "Tender for Design & Construction of India Stand at 38 Vitrina Turistica - ANATO 2019 Bogota, Colombia"
date: "2025-08-03"
pages: 11
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9dcf697735063991"
---

<!-- page 1 -->

INDIA TOURISM
GOVERNMENT OF INDIA
1270 Avenue of the Americas, Suite 303, New York, NY 10020
Telephone: 212-586-4901 * Toll Free: 1-800-953-9399 « Fax: 212-582-3274
Web: www.incredibleindia.org E-mail: ny@itonyc.com
No. 38/Vitrina-ANATO/2018-19 Dated: December 04, 2018
TENDER NOTICE INVITING QUOTATIONS FOR DESIGN AND CONSTRUCTION OF
INDIA STAND AT
38 Vitrina Turistica — ANATO 2019 Bogota, Colombia to be held from 27"
February to 01% March 2019
India Tourism New York, an office of the Ministry of Tourism, Government
of India invites quotations from agencies having prior experience in design,
conceptualization, construction of exhibition stands for construction of exhibition
stand and provision of ancillary services in_38 Vitrina Turistica - ANATO, Bogota
to be held from 27'" February to 01% March 2019. The interested agencies may
download full tender document with detailed scope of work, eligibility criteria and
format for application from www.tourism.gov.in (click on the tab “Tenders & RFP”
in the homepage) or contact by E-mail to ny@itonyc.com .
Sealed quotations as per format should reach at the above address on or
before 17:30 hrs on December 28", 2018 (Friday).
a
Assistant Director
India Tourism New York
W)
Incredible tndia

<!-- page 2 -->

TENDER NOTICE INVITING QUOTATIONS FOR DESIGN AND CONSTRUCTION OF NOTICE INVITING QUOTATIONS FOR DESIGN AND CONSTRUCTION OF
INDIA STAND AT
38 Vitrina Turistica - ANATO 2019 Bogota, Colombia to be held from 27" February to
015‘ March 2019

The 38 Vitrina Turistica —- ANATO is being held from 27" February to 018 March
2019 in Bogota, Columbia. India Tourism, New York would be participating in the
fair by hiring a space of 36 sq mts with Stand Nos. 2226 — 2228 — 2325 - 2327.A
copy of the floor plan is also enclosed herewith.
The primary objective of participation in this fair is to depict India in South American
market as an attractive tourist destination. Besides, India Tourism, New York, there
would be 08 Indian Tour Operators participating in the fair as co-exhibitors in the
India Tourism Stand. In all, there would be 09 participants including India Tourism
New York Office as main Stand Holder.
India Tourism, New York invites quotations from interested stand construction
agencies/companies having previous experience of handling work of similar nature
at international fairs and exhibitions for conceptualization, designing and
construction of India booth and providing other related ancillary services during
ANATO Exhibition.

Name of the| Dates of | Space Type of Max No. of

Fair Fair Booked

Stand Co-exhibitor

38 Vitrina | 27" 36 Sqmts | 03 Sides | 08 Plus India

Turistica - | February to Stand N Open Tourism

ANATO 2019 - | 018 March | 9'and No. (Total 09

Bogota, 2019 2226 - counters)

Colombia 2228 -

2325 - 2327
(१) पे

<!-- page 3 -->

The scope of work and requirements are given below:

Qualification:

Registered agency having prior experience in design, conceptualization, and
construction of exhibition/event stands.

A. Scope of Work

i) To design a unique, user friendly and innovative stand for India at the
Exhibition/fair. The stand design must have elements of Indian theme
and flavor, modern Business type layout and design.

ii) Fabrication ofindia Tourism Stand strictly following ॥6
mandatory/specific guidelines of the Event’s Organizers. The overall
layout of the Pavilion should be open and inviting.

iii) | To provide all required furniture and lighting, etc. for the entire duration
of the event. The layout should be conducive for conducting buyer-
seller meetings and effective “Incredible India” branding.

iv) To dismantle and dispose of the stand once event is over.

v) The India Pavilion must have a fresh look at ANATO 2019 and must not
appear jaded or worn-out due to normal wear and tear or damage to the
material used / re-used.

B. Specifications and Requirements for India Tourism stand.

i) Storage chamber with sufficient space and racks to store cartons of
brochures and coat hangers. The outer wall of the storage may be
branded with India images. A small fridge for storing beverages and food
items. The Storage requires electricity supply for functioning of fridge.

ii) Each of the 08 co-exhibitors in the India stand will get a separate booth
with a table having lockable storage, two chairs each on either side of the
table, small waste paper bin at all counters, Plants or other accessories
for beautification as well as daily cleaning of the pavilion during the
exhibition, suitable lighting and electric points to charge laptop and
mobile phone (electronic gadgets). There must be sufficient privacy to
enable them to conduct individual meeting at their designated booth.

© (बट

<!-- page 4 -->

iii) | There should be easy accessibility and sufficient space to and within the
stand and visible signage for all the co-exhibitors/participants in the
pavilion / stand.

iv) India Tourism, New York is the main stand holder and must get more
space in the center of the stand with broader table for keeping its
brochures/publicity material. In addition, in the middle of the India stand,
there must be a rectangular / squarish table with at least 4 chairs to make
any presentation.

v) The stand must have large format graphics portraying myriad tourism
products of India (High resolution images would be provided by India
Tourism, New York, if requested).

vi) | The agency should also provide tea/coffee bags, milk, sugar, disposable
cups & Paper Glasses, paper napkins, stirrers’ etc. Drinking water
dispenser machine with hot and cold water options.

vii) | Carpeting of floor, if required.

viii) |The design of the stand must be attractive, appealing, user friendly and
fire proof. It should not give a cramped look.

ix) Names of the co-exhibiting agencies along with their company logo to be
printed on their table/podium.

x) Design should include some kind of partition between the exhibitors to
provide them privacy while conducting their business.

xi) A large “Incredible India” logo must be mounted on top of the India stand,
which must be visible from a distance. Assigned Booth number to be
clearly displayed as part of the signage.

xii) | Agency must also indicate wattage of power required for the stand.

xiii) | Should adhere to norms of safety & security charted out by the organizers
of the fair/event.

xiv) | The scope of work will include construction of the stand at site well in
time maintenance activities during the event and dismantling of the
pavilion after the event. A representative of the stand constructor should
be available on call during working hours of the trade show.

4
७५ Ly 1१५०८

<!-- page 5 -->

xv) Fabrication of India Tourism stand should be strictly as per the specific
guidelines of the Exhibition organizers. It is the responsibility of the
agency to strictly comply with the guidelines of the show organizers, in
regard to material to be used for construction of stand and procedure for
construction and dismantle of stand. The website of ANATO may be
referred for the guidelines for external booth constructors.

xvi) Arrangement of intermate/Wi-fi at India Stand.
xvii) The agency should ensure that the India Pavilion is fully constructed and
ready to use at least a day before commence of ANATO 2019.
The above are few broader requirements. However, India Tourism welcome more
suitable ideas and suggestions from the agencies.
C. Guidelines for Submitting Tenders:
1. The tender should be submitted in two covers as per the following details:
Cover-1: Super scribed “Construction of India Stand at 38 Vitrina Turistica
- ANATO-2019 Bogota, Colombia : Technical Bid”.
To include the following documents / details:
Details of the Tenderer:

° Profile of the Agency / Company.

e Track record - details of jobs undertaken for other tourism boards / similar
events, with copies of relevant work orders in support of the details
furnished. Experience of setting up Pavilions/ Booths/ Stands at
International Fairs / Exhibitions / Events as well as at International
Tourism related Fairs / Exhibitions Events during the last three years
may be highlighted.

(5)
Ley —

<!-- page 6 -->

¢ Specific experience relating to ANATO, if any with copies of relevant work
orders in support of details furnished.

¢ All bidders should submit a self-undertaking that they have never been
blacklisted by any Government of India Ministry/ Department/ Authority/
Organization/ Agency.

e Details of any awards won for stand design in the past three years
supported by documentary proof.

e All bidders should submit their Concept/ Design of the India stand/
Pavilion with detailed layout, decoration plan, etc. (only single design) in
hard copy as well as on Flash Drive/CD.

Cover — 2: Super scribing “Construction of India Stand 38 Vitrina

Turistica - ANATO 2019 Bogota, Colombia: Financial Bid”.

To include the following documents / details:

(i) A Financial Bid, duly dated and clearly indicating the cost against each
of the following components:

a) Construction, maintenance & dismantling of the pavilion.

b) Decoration and display within the pavilion.

०) Transportation of material to the site and back.

d) Expenditure on other activities as listed in the scope of work
above including technical equipment like video wall, audio
system, etc.

e) Taxes

f) Others

9) Total

(ii) All bidders should indicate cost for the stand as well as the total cost
inclusive of all taxes. Taxes (if any) should also be indicated separately.

(iii) All costs involved must be clearly indicated in USD.

(iv) | Mode of payment must be clearly indicated.

<!-- page 7 -->

(v) _ The financial bid should contain an undertaking by the agency that the
agency accepts and agrees to abide by the terms and conditions as
mentioned in this tender document.

(vi) Format for submission of the financial bids is provided in Annexure- A.

2. The two sealed covers, super scribed ‘Construction of India Stand at 38
Vitrina_Turistica — ANATO 2019 Bogota, Colombia Turistica — ANATO 2019 Bogota, Colombia Technical Bid’ and
‘Construction of India Stand 38 38 Vitrina Turistica - ANATO 2019 Bogota
Colombia Financial Bid’ in Covers | and II respectively should be put up ina
separate cover super scribed.

3. “Technical and Financial Bid for Construction of India Stand 38 Vitrina
Turistica - ANATO 2019 Bogota, Colombia with the details of the company
e.g. Full Name, Postal Address, Telephone Number, Fax Number, E-mail of
the Tenderer on the bottom left corner of the cover and sent to The
Assistant Director, India Tourism New York, 1270, Avenue of the
Americas, Suite # 303, New York, NY-10020 to reach on or before 17:30
hrs. of December 28'", 2018 (Friday).

4. Allthe documents submitted by the agencies should be signed and stamped
on each page by the authorised signatory of the company. The document,
duly page numbered, and properly indexed. The agencies who do not submit
their bids in the proper format, with required documents and in the required
format would be liable for rejection.

5. The agencies submitting their bids should also mention that they agree to
the terms and conditions mentioned in the tender document.

D. Opening of Bids and Selection Process:

1. Technical bids will be opened to evaluate the technical Bids of the agencies
which are found eligible after initial scrutiny of the bids.

2. The technical bids will be judged by following criteria as detailed below:

c
\ 2 ejay

<!-- page 8 -->

me ee |
Experience of setting up Pavilions/ Booths/ Stands at | 10 marks
International Fairs / Exhibitions / Events during last three
years.
Experience of setting up Pavilions/ Booths/ Stands at | 10 marks
International Tourism related Fairs / Exhibitions /Events
during last three years.
Awards received for Pavilions / Booths / Stands at events | 05 marks
in (i) and (ii) above.
Concept & Design of Pavilion 30 marks
Effective Utilization of Space 05 marks
vi. Effective Branding in the Pavilion 05 marks
vii. Innovative ideas and other attractions in the Pavilion 05 Marks
[I

3. Whereas, Technical Evaluation will carry a weightage of 70 marks, financial
bids will carry weightage of 30 marks. The agencies scoring 70 per cent
marks (49 marks) or above in Technical Evaluation shall be eligible for
opening of their financial bids.

4. Financial evaluation will carry a weightage of 30 Marks. The financial bids
of only those agencies that score 70 percent mark (49 marks) or above in
Technical Evaluation will be opened in the presence of their representatives.
The date and time of opening of the Technical and Financial bids will
be at around 2.00 PM on 2" January, 2019 (Wednesday).

5. The agency which scores the highest aggregate marks on the basis of
technical and financial evaluation (after adding the scores from the technical
and financial evaluation) will be awarded the contract for construction of the
India Stand at the event.

(8) Ly 1७०

<!-- page 9 -->

E. Terms of Payment: Payment will be made to the successful bidder as per

the following schedule:

(i) 100% payment in advance will not be given. However, India
Tourism may consider Payment of 30% of the total contractual
amount by check or electronic transfer before the construction of
the stand.

(ii) Payment of balance 70% of the total contractual amount will be
made through check/bank draft/electronic transfer on completion
of the stand construction in 38 Vitrina Turistica - ANATO 2019
Bogota, Colombia and dismantling the same once event is over by
clearing the site.

F. ADDITIONAL INFORMATION

(i) India Tourism New York reserves its right not to accept bids from
agencies resorting to unethical practices or on whom investigation /
enquiry proceedings has been initiated by Government Investigating
Agencies / Vigilance Cell.

(ii) Incomplete and conditional bids will be rejected outright. Agencies
submitting proposals will not be permitted to alter or modify their bids
after expiry of the deadline for receipt of bids.

(iii) Any Displays / Translites/Images produced for the India Stand at the
event will be the sole property of the Ministry of Tourism, Government
of India (in this case India Tourism, New York), on completion of the
event.

(iv) Validity of Tender: Tender shall remain valid for acceptance for a
period of one year from the date of opening of Tender/ or till the end
of the event for which the tenders were called for, whichever is earlier.

(v) Insurance: Insurance, including transit and third party insurance will
be arranged by the service provider.

(vi) Liquidated Damages: In the event of service provider's failure to
complete the work within the specified time, and as per the
requirements of standards of quality constructions, as mentioned in
the tender document, India Tourism New York will recover from the
service provider, as Liquidated Damages, a sum of 10 % of the

(१) ly
“ i a

<!-- page 10 -->

contract price for every day’s delay. Besides, if the execution is

delayed, India Tourism New York may take action to debar the agency

from participation in further tenders and/or blacklist the agency.

(vii) Termination by default: India Tourism New York reserves the right
to terminate contract of any agency in case of change in the
Government procedures or for unsatisfactory services, without
assigning any reasons.

(viii) Risk — Purchase Clause: If the service provider, after submission of
tender and the acceptance of the same, fails to abide by the Terms
and Conditions of the tender document or fails to complete the work
within the specified time frame or at any time repudiates the contract,
India Tourism New York will have the right to:

(a)In case cost escalates after awarding the contract/during
construction then the agency has to complete the incomplete job
through alternative sources as its responsibility, the service
provider shall bear the balance amount incurred for completing the
work.

(b) For all purposes, the work order accepted by the bidder and issued
by India Tourism New York will be considered as the formal
contract.

(ix) Force Majeure: Neither party will be liable in respect of failure to fulfil
its obligations, if the said failure is entirely due to Acts of God,
Governmental restrictions or instructions, natural calamities or
catastrophe, epidemics or civil disturbances in the country. If there is
a delay in performance or other failures by the service provider to
perform its obligation under its contract due to event of a Force
Majeure, the service provider shall not be held responsible for such
delays/failures. If a Force Majeure situation arises, the service
provider shall promptly notify it in writing of such conditions and the
cause thereof providing sufficient and satisfactory evidence
immediately on occurrence of such event. Unless otherwise directed
by the organizer in writing, the service provider shall continue to
perform its obligations under the contract as far as reasonably
practical, and shall seek all reasonable alternative means for
performance not prevented by the Force Majeure event to complete
the work.

(1०) धन ay
