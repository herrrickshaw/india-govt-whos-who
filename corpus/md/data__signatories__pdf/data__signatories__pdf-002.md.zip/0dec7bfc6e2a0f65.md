---
doc_id: "0dec7bfc6e2a0f65"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2026/05/471d010a67e6e5158f7ed1a0026f7b5b.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Transplantation of Human Organs (Amendment) Rules, 2008"
date: "2026-05-21"
pages: 19
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "371b594128bccc9d"
---

<!-- page 1 -->

MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health and Family Welfare)
NOTIFICATION
New Delhi, the 3 1st July, 2008
GS.R.571(E)— In exercise of the powers conferred by sub-section (1) of section 24 of the
Transplantation of Human Organs Act, 1994 (42 of 1994), the Central Government hereby
makes the following amendments to the Transplantation of Human Organs Rules, 1995,
namely:-
1. Short title and Commencement
(1) These rules may be called the Transplantation of Human Organs
(Amendment) Rules, 2008.
(2) They shall come into force on the date of their publication in the Official
Gazette. :
2. In the Transplantation of Human Organs (Amendment) Rules, 2008 (hereinafter
referred to as the said rules), - (i) clause (d) shall be renumbered as clause (f), thereof and
before clause (f) as so renumbered the following clauses shall be inserted, after clause (c),
namely: पु
0). after sub-rule (c) of Rule 2, the following shall be inserted:
“(d) “National Accreditation Board for Laboratories” (NABL) means a Board set up by the
Quality Council of India (set up by the Government of India) for undertaking assessment and
accreditation of testing and calibration of laboratories in accordance with the intemational
standard ISO / IEC 17025 and ISO 15189;
24५45 #7/०8- 5

<!-- page 2 -->

(i) (७) the Registered Medical Practitioner, as defined in clause (n) of section 2 of
’ Transplantation of Human Organs Act, 1994 includes an allopathic doctor with MBBS or
equivalent degree under the Medical Council of India Act.

3. In the Said rules, in rule 3, for the words and figure “Form.1” the words, figures and

letters “Forms 1(A), 1(B) and 1(C) shall be substituted:

4. In the said rules, - (i). in rule 4 for sub-rule(1) the following sub-rule shall be

substituted, namely:-

“(). Duties of the Medical Practitioner: ,

(1) A registered medical practitioner shall, before removing a human organ from the body of
a donor before his death, satisfy himself —

(a) that the donor has given his authorization in appropriate Form 1(A) or 1(B) or 1(C).

(b) that the donor is in proper state of health and is fit to donate the organ, and the
tegistered- medical practitioner shall sign a certificate as specified in Form 2.

(०) that the donor is a near relative of the recipient, as certified in Form 3, who has
signed Form 1(A) or 1(8) as applicable to the donor and that the donor has
submitted an application in Form 10 jointly with the recipient and that the proposed
donation ‘has been approved by the concerned competent authority and that the
necessary documents as prescribed and medical tests, if required, to determine the
factum of near relationship, have been examined to the satisfaction of the Registered

: Medical Practitioner i.e. Incharge of transplant centre.
(d) that in case the recipient is spouse of the donor, the donor has given a statement to the
effect that they are so related by signing a certificate in Form 1(B) and has submitted an
है application in Form 10 jointly with the recipient and that the proposed donation has
been approved by the concerned competent authority under provisions of sub-rule(2) of
rule 4A. - हु
(e) In case of a donor who is other than a near relative and has signed Form 1(C) and
1 submitted an application in Form 10 jointly with the recipient, the permission from the
Authorisation Committee for the said donation has been obtained.
(i) In‘rule 4 in sub-rule(2) for clause (b) the following clause shall be substituted,
namely:- , हि
_ “(b) that then person lawfully in possession of the dead body has signed a certificate as
specified in Form 6.”
(iii) the existing Form 7 shall be omitted. . , .
5. In the said rules, after rule 4 the following rule shall be inserted, namely:-
“4-A (1) The medical practitioner who will be part of the organ transplantation
Authorisation team for carrying out transplantation operation shall not be a member
Committee of the Authorisation Committee constituted under the provisions of
clauses (a) and (b) of sub-section(4) of section 9 of the Act.

<!-- page 3 -->

(2) Where the arg te proposed transplantation is between a married couple he couple, the
. Registered Medical Practitioner i.e. Incharge of transplant centre must
evaluate the factum and duration of marriage and ensure that
documents such as marriage certificate, marriage photograph etc. are
kept for records along with the information on the number and age of
children and.family photograph depicting the entire immediate family,
. birth certificate of children containing particulars of parents.
(3) When the proposed donor or recipient or both are not Indian
Nationals/citizens whether ‘near relatives’ or otherwise, Authorisation
Committees shail consider all such requests. .
(4) when the proposed donor and the recipient are not ‘near relatives’, as
defined under clause(i) of section 2 of the Act, the Authorisation
. Committee shall evaluate that,- है
(@) _ there is no commercial transaction between the recipient and the donor and that
no payment or money or moneys worth as referred to the Act, has been made to
the donor or promised to be made to the donor or any other person;
(i) the following shail specifically be assessed by the Authorisation Committee:-
(a) an explanation of the link between them and the circumstances which led to
ह the offer being made;
(b) reasons why the donor wishes to donate; .
(c). documentary evidence of the link, e.g. proof that they have lived together,
छठ;
(d)_ old photographs showing the donor and the recipient together;
(ji) that there is no middleman or tout involved; :
° (9५) that financial status of the donor and the recipient is probed by asking them to give -
appropriate evidence of their vocation and income for the previous three financial
years. Any gross disparity between the status of the two must be evaluated in the
backdrop of the objective of.preventing commercial dealing;

(v) that the donor is not a drug addict or known person with criminal record;

(vi) that the next of the kin of the proposed unrelated donor is interviewed regarding
awareness about his or her intention to donate an organ, the authenticity of the link
between the donor and the recipient and the reasons for donation. Any strong
views or disagreement or objection of such kin shall also be recorded and taken

«note of.’ ‘ / oo :
6. In the said rules:- है
0) For rule 6 the following rules shall be substituted, namely:-

<!-- page 4 -->

6. The donor and the recipient shall. make jointly an application to grant approval for
removal and transplantation of a human organ, to the concerned competent
authority or Authorisation Committee as specified in Form 10. The Authorisation
Committee shall take a decision on such application in accordance with the
guidelines in rule 6-A.” ‘

(ii) after rule 6, the following rule shall be inserted, namely:- .

“6A. Composition of Authorisation Committees:

1. There shall be one State level Authorisation Committee. .

2. Additional authorisation committees may be set up at various levels as per norms

given below, namely:-

@ no member from transplant team of the institution should be a member of the
respective Authorisation Committee. All Foreign Nationals (related and unrelated)
should go to ‘Authorisation Committee’ as abundant precaution needs to be taken in
such cases; हि .

(ii) Authorisation Committee should be Hospital based in Metro and big cities if the
number of transplants exceed 25 in a year at the respective transplantation centres.
In smaller towns, there are State or District level Committees if transplants are less
than 25 in a year in the respective districts. .

(A) Composition of Hospital Based Authorisation Committees: (To be constituted by the :

State Goverment and in case of Union territory by the Central Government).

(a) the senior most person officiating as Medical Director or Medical Superintendent of

the Hospital;
(0) two senior medical practitioners from the same hospital who are not part of the
transplant team; 7

(० two members being persons of high integrity, social standing and credibility, who
have served in high ranking Government positions, such as in higher judiciary, senior
cadre of police service or who have served as a reader or professor in University
Grants Commission approved University or are self-employed professionals of repute
such as lawyers, chartered accountants and. doctors (of Indian Medical Association)
etc.: and

(d) Secretary (Health) or nominee and Director Health Services or nominee.

(B) Composition of State or District Level Authorisation Committees: (To be constituted

by the State Government and in case of Union territory by the Central Government).

<!-- page 5 -->

(a) a Medical Practitioner officiating as Chief Medical Officer or any other equivalent post
in the main/major Govemment Hospital of the District.

(b) two sénior medical practitioners to be chosen from the pool of such medical
practitioners who are residing in the concemed District and who are not part of any
transplant team. :

. (० two senior citizens, non-medical background (one lady) of high reputation and.
integrity to be chosen from the pool of such citizens residing in the same district, who
have served in high ranking Government positions, such as in higher judiciary, senior
cadre of police service or who have served as a reader or professor in University
Grants Commission approved University or are self-employed professionals of repute
such as lawyers, chartered accountants and doctors (of Indian Medical Association)
etc.; and

(d) Secretary (Health) or nominee and Director Health Services or nominee. : .

(Note: Effort should be made to have most of the members’ ex-officio so that the need to

change the composition of committee is less frequent.) .

6B. The State level committees shall be formed for the purpose of providing approval or
no objection certificate to the respective donor and recipient to establish the legal
and residential status as a domicile state. It is mandatory that if donor, recipient and
place of transplantation are from different states, then the approval or ‘no objection

" certificate’ from the respective domicile State Govemment should be necessary.
The institution where the transplant is to be undertaken in such case the approval of
Authorisation Committee is mandatory.

60. The quorum of the Authorisation Committee should be minimum four. However,
quorum ought not to be considered as complete without the participation of the
Chairman. The presence of Secretary (Health) or nominee and Director of Health
Services or nominee is mandatory.

6D. The format. of the Authorisation Committee approval should be uniform in all the
institutions in a State. The format may be notified by respective State Government.

6E. Secretariat of the Committee shall circulate copies of all applications received from
the proposed donors to all members of the Committee. Such applications should be
circulated along with all annexures, which may have been filed along with the

ह applications. At the time of the meeting, the Authorisation Committee should take
note of all relevant contents and documents in the course of its decision making
process and in the event any document or information is found to be inadequate or
doubtful, explanation should be sought from the applicant and if it is considered

<!-- page 6 -->

necessary that any fact or information requires to be verified in order to confirm its
veracity or correctness, the same be ascertained through the concemed officer(s) of
the State/ Union territory Goverment.
66: The Authorisation Committee shall focus its attention on the following, namely:-
(a) Where the proposed transplant is between persons related genetically, Mother,
. Father, Brother, Sister, Son or Daughter above the age of 18 years). .
the concemed competent authority shail evaluate:-

(0)... resutts of tissue typing and other basic tests;

(i) documentary evidence of relationship e.g. relevant birth certificates and .
marriage certificate, certificate from Sub-divisional magistrate/ Metropolitan
Magistrate/or Sarpanch of the. Panchayat; है J

(ii) documentary evidence of identity and residence of the proposed donor e.g.
Ration Card or Voters identity Card or Passport or Driving License or PAN

है Card or Bank Account and family photograph depicting the proposed donor
and the proposed recipient along with another near relative;

(iv) _ if in its opinion, the relationship is not conclusively established after evaluating

हु the above evidence, it may in its discretion direct further medical tests as
prescribed as below:

(a) the tests for Human Leukocyte Antigen (HLA), Human Leukocyte
Antigen-B alleles to be performed by the serological and/or Polymerase
chain reaction (PCR) based Deoxyribonucleic acid (DNA) methods.

(b) test for Human Leukocyte Antigen-DR beta genes to be performed
using the Polymerase chain reaction (PCR) based Deoxyribonucleic
acid (DNA) methods.

(©) _ the tests referred to in sub-rules (i) and (ii) shall be got done from a
laboratory accredited with National Accreditation Board for Laboratories.
(NABL).”

: (d) where the tests referred to in (i) to (ji) above do not establish a genetic
relationship between the donor and the recipient, the same tests to be
performed on both or at least one parent, preferably both parents. If
parents are not available, same tests to be performed on such relatives
of donor and recipient as are available and are willing to be tested
failing which, genetic relationship between the donor and the recipient
will be deemed to have not been established. है ,

<!-- page 7 -->

[भागा-खण्ड30)]॥ TT eB _ भारत का राजपत्र : असाधारण. 2
(0) The papers for approval of transplantation would be processed by the registered
medical practitioner and administrative division of the Institution for transplantation,

while the approval will be granted by the Authorisation Committee. | .

(०) Where the proposed transplant is between a married couple (except foreigners,
whose cases should be dealt by Authorisation Committee):

The concerned competent authority or authdrisation committee as the case may be

must evaluate all available evidence to establish the factum and duration of marriage

and ensure that documents such as mariage certificate, marriage photograph is
placed before the committee along with the information on the number and age of
children and a family photograph depicting the entire immediate family, birth
certificate of children containing the particulars of parents.

(d) Where the proposed transplant is between individuals who are not “near relatives”.

The authorization committee shall evaluate:-

() that there is no commercial transaction between the recipient and the donor. That
no payment of money or moneys worth as referred to in the sections of the Act,
has been made to the donor or promised to be made to the donor or any other
person. In this connection the - Authorisation Committee shall take into
consideration:~

है (a) an explanation of the link between them and the circumstances which led
to the offer being made;
(b), documentary evidence of the link e.g. proof that they have lived together
etc.;
(c) reasons why the donor wishes to donate; and
(d) old photographs showing the donor and the recipient together.

(ii) that there is no middlemanftout involved;

(ii) that financial status of the donor and the recipient is probed by asking them to
give appropriate evidence of their vocation and income for the previous three
financial years. Any gross disparity between the status of the two, must be
evaluated in the backdrop of the objective of preventing commercial dealing;

(9५) that the donor is not a drug addict or a known person with criminal record;

(v) that the next of kin of the proposed unrelated donor is interviewed regarding
awareness about his/her intention to donate an organ, the authenticity of the link
between the donor and the recipient and the reasons for donation. Any strong
views or disagreement or objection of such kin may also be recorded and taken ,
note of; and : : है

<!-- page 8 -->

(e); When the proposed donor or the recipient or both are foreigners:-

() a senior Embassy official of the country of origin has to certify the relationship
between the donor and the recipient.

(ii) Authorisation Committee shall examine the cases of Indian donors consenting to
donate organs to a foreign national (who is a near relative), including a foreign
national of Indian origin, with greater caution. Such cases should be considered
rarely on case to case basis.

(0) In the course, of determining eligibility of the applicant to donate, the applicant
should be personally interviewed by the Authorisation Committee and minutes of
the interview should be recorded. Such interviews with the donors Should be
videographed.

(9) In case where the donor is a woman greater precautions ought to be taken. Her
identity and independent consent should be confirmed by a person other than the
fecipient. Any document with regard to the proof of residence or domicile and
particulars of parentage should be relatable to the photo identity of the applicant in
order to ensure that the documents pertain to the same person, who is the proposed
donor and in the event of any inadequate or doubtful information to this effect, the
Authorisation Committee may in its discretion seek such other information or
evidence as may be expedient and desirable in the peculiar facts of the case.

(6) The Authorisation Committee should state in writing its reason for rejecting/
approving the application of the proposed donor and all approvals should be subject
to the following conditions:- .

(i) that the approved proposed donor would be subjected to all such medical
tests as required at the relevant stages to determine his biological capacity
and compatibility to donate the organ in question.

(i) __ further that the psychiatrist clearance would also be mandatory to certify his &
mental condition, awareness, absence of any overt or latent psychiatric
disease and ability to give free consent.

(iii) all prescribed forms have been and would be filled up by al! relevant persons
involved in the process of transplantation.

(iv) © all interviews to be video recorded.

(0) The authorisation committee shall expedite its decision making process and use its

discretion judiciously and pragmatically in all such cases where, the patient requires

immediate transplantation. हु

<!-- page 9 -->

[भागा-खण्ड30)]_._._._. मअभरतंकाराजपत्र : असाधारण >>
0) Every authorised transplantation centre must have its own website. The Authorisation
Committee is required to take final decision within 24 hours of holding the meeting for grant
of permission or rejection for transplant. The decision of the Authorisation Committee should
be displayed on the notice board of the hospital or Institution immediately and should reflect
on the website of the hospital or Institution within 24 hours of taking the decision.’ Apart from
this, the website of the fospital or institution must update its website regularly in respect of
the total number of the transplantations done in that hospital or institution along with the
details of each transplantation. The same data should be accessible for compilation, analysis

° and further use-by respective State Governments and Central Government.
7. In the said rules, in rule 7, after clause(2) the following clause shall be inserted,
namely:- :
*7(3) before a hospital is registered under the provisions of this rule, it shall be mandatory
for the hospital to nominate a transplant coordinator.”
8. In the said rules, for rule 9 the following rule shall be substituted, namely:-
°9. Conditions for grant of Certificate of Registration:

No hospital shall be granted a certificate of registration under this Act unless it fulfils
the following requirement of manpower, equipment, specialized services and facilities
as laid down’ below:-

A General Manpower Requirement Specialised Services and Facilities:

हू (1) 24 hours availability of medical and surgical, (senior and junior) staff.

(2) 24 hours availability of nursing staff, (general and speciality trained).

(3) 24 hours availability of Intensive Care Units with adequate equipments, staff
and support system, including specialists in anaesthesiology, intensive care.

(4) 24 hours availability of laboratory with muttiple discipline testing facilities

हे . including but not limited to Microbiology, Bio-Chemistry, Pathology and:
Hematology and Radiology departments with trained staff.

(5) 24 hours availability of Operation Theater facilities (OT facilities) for planned
and emergency procedures with adequate staff, support system and
‘equipments.

(6) 24 hours availability of communication system, with power backup, including

“but not limited to multiple line telephones, public telephone systems, fax,
computers and paper photo-imaging machine.

(7) Experts (Other than the experts required for the relevant transplantation) of
relevant and associated specialties including but not limited to and depending
upon the requirements, the experts in internal medicine, diabetology, |

2945 GI/08-Y

<!-- page 10 -->

6 _____CTHEGAZETTE OF INDIA: EXTRAORDINARY ___[Paxr Il —Sec. 3(i)]
gastroenterology, nephrology, neurology, paediatrics, gynaecology immunology
and cardiology etc. should be available to the transplantation centre.

B Equipments: :
Equipments as per current and expected scientific requirements specific to organ or
organs being transplanted. The transplant centre should ensure the availability of
the accessories, spare-parts and back-up/maintenance/service support system in
relation to all relevant equipments.
C _Experts and their qualifications:- ,
(A) Kidney Transplantation:
M.S. (Gen.) Surgery or equivalent qualification with three years post M.S. training in
a recognised center in India or abroad and having attended to adequate number of
renal transplantation as an active member of team. है
(8) Transplantation of liver and other abdominal organs
M.S. (Gen.) Surgery or equivalent qualification with adequate post M.S. training in
an established center with a reasonable experience of performing liver
transplantation as an active member of team- हु
(0) Cardiac, Pulmonary, Cardio-Pulmonary Transplantation:
M.Ch. Cardio-thoracic and vascular surgery or equivalent qualification in India or
abroad with at least 3 years experience as an active member of the team >
performing an adequate number of open heart operations per year and well-versed
with Coronary by-pass surgery and Heart-vaive surgery. ‘
(D) Cornea Transplantation:
M.D./M.S. ophthalmology or equivalent qualification with one year post M.D./M.S
training in a recognised hospital carrying out Corneal transplant operations.
[F. No. S-12011/12/2007-MS]
VINEET CHAWDHRY, Jt. Secy.
Note :— The principal rules were published in the Gazette of India vide notification No. S-12011/2/1994-MS, dated
the 4th February, 1995, Extraordinary, under G.S.R. No. 51(E).
