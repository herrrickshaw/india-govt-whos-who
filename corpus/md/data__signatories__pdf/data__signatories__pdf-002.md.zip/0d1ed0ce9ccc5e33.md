---
doc_id: "0d1ed0ce9ccc5e33"
source_url: "https://www.dst.gov.in/static/uploads/2026/02/222140f08021b7aa2e6e9741639ade4a.pdf"
ministry: "Department of Science and Technology (DST)"
title: "IGSTC 2+2 Call 2017 - Basic Guidelines"
date: "2018-02-13"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "433be2bd34699103"
---

<!-- page 1 -->

Basic Guidelines: First Stage Proposal - Call 2017

IGSTC Call for Joint R&D+I Project Proposals 2017
2+2 Mode of Partnership between India and Germany

1

About IGSTC

Indo-German Science & Technology Centre (IGSTC), established by the Department of
Science and Technology (DST), Government of India, and the Federal Ministry of Education
and Research (BMBF), Germany facilitates Indo-German R&D networking through substantive
interactions among government, academia/research system and industry to foster innovation
for the overall economic and societal developments of both the countries. The Centre
envisions to:
• Advance industrial research partnership with mutuality of interest and respect
• Create a platform for cross fertilisation of ideas
• Develop knowledge networks for industrial sectors to enhance competitiveness
• Establish joint knowledge pools to address global challenges
• Serve as a nodal centre to promote Indo-German technology partnership

2

Partnership Model and Thematic Area

IGSTC intends to catalyse innovation centric R&D projects by synergising the strength of
research/academic institute and public/private industry from India and Germany. This Call for
proposals is aimed at supporting joint R&D+I projects of industrial relevance by means of “2+2
Mode of Partnership” 1 in the overall thematic area:
“Advanced Manufacturing and New Materials”
with the subtopics:
• Industry 4.0 (new human-machine interaction processes/digital and cloud manufacturing)
• Machine building (low cost sub-systems/components for improved precision, reliability,
productivity)
• Process technologies for new materials including nanomaterials
• Light weight design and processes
It is expected that the proposed project ideas are in the Technology Readiness Level - 4
(TRL - 4). For any further information, please refer to:
https://ec.europa.eu/research/participants/data/ref/h2020/wp/2014_2015/annexes/h2020wp1415-annex-g-trl_en.pdf

3

Basic Principles

Project should be proposed involving both Indian and German partners. Each project will be
executed by the Principal Investigators (PI) from all the partners. Joint team may select one PI
as the coordinator, who will finally submit the First Stage Proposal in consultation with all
partners. Written consent of all partners should be obtained.
Project proposal is expected to provide insights and exploitable research results leading to
new technologies, products and/or services. The benefits of partnership should be clearly
identifiable.
1

“2+2 Mode of Partnership” refers to projects with the participation of at least one German and one Indian research
institution as well as one German and one Indian industry partner

<!-- page 2 -->

Project proposal should ensure that all the project partners contribute to and benefit from an
equitable and balanced cooperation with adequate protection for intellectual property rights
used in and generated during the joint efforts.
IGSTC will execute a two step evaluation process by a Joint Scientific Committee. Applicants
have to submit a First Stage Proposal first and will be asked to submit the Second Stage
Proposal if their proposal is evaluated positively. Each evaluation step might take up to two to
three months. The projects which are finally selected will be supported by IGSTC usually for a
maximum period of three years.

4

Financial Support

Funding is provided in the form of non-repayable grants amounting about € 450,000 per
project to the German partners, and INR 230 Lakhs to the Indian partners for a period of up to
three years, to cover costs for personnel and other costs. An additional funding period of up to
two years may be granted in exceptional cases. The entire project funding would be provided
under the umbrella of Indo-German Science &Technology Centre (IGSTC). Financial support
for the Indian partners would be released by IGSTC in India and financial support for the
German partners would be released through DLR-PT in Germany.
Indian Partners: 100% of the eligible costs in the form of grant to institutional partner
(research/academic) and up to 50% of the eligible costs in the form of grant to industrial
partner. However, the maximum grant amount to the Indian industrial partner will be limited to
INR 50 Lakhs.
German Partners: 100% of the eligible costs in the form of grant to institutional partner
(research/academic) and usually 50% of the eligible costs in the form of grant to industrial
partner (for details, see German Call text). For the research establishments, which receive
basic funding from the Federal or State Governments, project funding to cover additional
expenditure can be granted only under certain conditions.

5

Eligible Costs
• Costs for personnel involved in the project
• Specific equipment / demonstration unit / pilot plant including software licensing for the
project (equipment that is not part of the applicant’s basic equipment)
• Consumables / materials
• Mobility costs (international/domestic travel and hospitality cost). Long term (up to three
months) exchange visits of young researchers are encouraged.
• Networking events (organising project related workshops / brain-storming meetings)
• Outsourcing / subcontract
• Contingency
• Overheads

Indian Partners: Contingency and overhead amounts should be limited to 5% and 10% of
eligible cost, respectively. In this case, cost of equipment should not be included in calculating
total eligible costs. Industry partner is not eligible for overhead cost.
German Partners: In accordance to German funding procedures, cost based proposals will
be able to ask for overheads, whereas German Universities are eligible for 20%
“Projektpauschale”.

2

<!-- page 3 -->

6

Evaluation

IGSTC will execute a two step evaluation process. In the first step, all the First Stage
Proposals will undergo an eligibility check by the project management team, followed by
evaluation by a Joint Scientific Committee. The evaluation process will consider:
•
•
•
•
•

Compliance to the thematic area of the Call
Novel innovative research within the scientific scope
Scientific merit and feasibility of the project, taking into account state of the art
Scientific credentials and global competitiveness of the project partners
Level of contribution of each partner / collaborative interaction and added value of the
consortium
• Innovative potential for industrial application (prospects for commercial success /
commercial exploitability)
• Support of young scientists
• Appropriateness and necessity of funds asked for
In the second step, all the shortlisted (successful) applicants will be requested to submit
Second Stage Proposals. These Proposals will be evaluated again by a Joint Scientific
Committee for their final recommendation for funding.

7

Who can Apply

Applicants from public and private non-profit research organisations, public and private
institutions of higher education, universities, and public or private companies having R&D
bases (i.e. DSIR recognition for in-house R&D in case of Indian industry partner) are eligible to
submit applications. The applicants should be holding a regular/permanent position. An Indian
/ German company is defined as one which is registered in the respective country with 51% or
more ownership held by the citizens of the country. Applicants already having an ongoing
2+2 project with IGSTC (on the Call deadline) are not eligible to apply.

8

Other Requirements

German Applicants: Please see German “Bekanntmachung” in the “Bundesanzeiger”.
Indian Applicants: A private company is required to make an appropriate contribution – at
least 50%, as a rule – towards the eligible project costs. Remaining funding up to 50% of the
projected cost (with a limit of INR 50 Lakhs) can be supported as a grant (on prevailing terms
and conditions), depending on the project’s orientation towards application. Grants for
universities, research establishments and similar institutions are calculated on the basis of the
eligible project related expenditure which can be funded to a maximum of 100%.

9

Contacts

It is recommended that applicants contact IGSTC Secretariat in India or Project Office
Germany prior to submitting the application. The contact addresses are:
INDIA

GERMANY

Dr. P V Lalitha
Indo-German Science & Technology Centre
Phone: +91-1244929407
E-mail: lalitha.pv@igstc.org

Dr. Martin Goller
German Aerospace Centre (DLR)
Project Management Agency
Phone: +49-22838211407
E-mail: martin.goller@dlr.de

3

<!-- page 4 -->

10

Submission of Proposals

The project proposal should be submitted online using pt-outline: https://secure.ptdlr.de/ptoutline/app/igstc2017
The project proposal should be submitted in the IGSTC format, which can be downloaded as a
word document from the IGSTC website (www.igstc.org).
Applications not submitted in the specified format and/or not within the specified page
limits will be rejected.
Application (via pt-outline) must be submitted no later than 13th February 2018. The
submission deadline is not a cut-off deadline. However, it may not be possible to consider
project proposals received after this date. No legal claims can be derived from the submission
of a proposal.
A hard copy of each application with the signatures of all PIs has to be sent to:
Dr P V Lalitha
Indo-German Science & Technology Centre
Plot No. 102, Institutional Area
Sector - 44, Gurgaon - 122003
INDIA

11

Entry into Force

These funding regulations will enter into force on the day of their publication in the Federal
Gazette (Bundesanzeiger) and the IGSTC website.

4
