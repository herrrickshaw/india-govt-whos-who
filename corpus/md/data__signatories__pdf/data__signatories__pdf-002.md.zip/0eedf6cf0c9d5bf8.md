---
doc_id: "0eedf6cf0c9d5bf8"
source_url: "https://master-dolr.digifootprint.gov.in/static/uploads/2025/09/bbc24205d66498a7ff58924f626b0f12.pdf"
ministry: "Department of Land Resources (DLR)"
title: "Fillling up the post of Staff Car Driver (Grade-II) in Department of Land Resources on deputation basis-reg"
date: "2020-09-09"
pages: 6
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "876da374353d52b1"
---

<!-- page 1 -->

A-11015/1/2019-Admn.
Government of India

Ministry of Rural Development

Department of Land Resources
G-Wing, NBO Building,
Nirman Bhawan, New Delhi

Oy
Dated, September 2020
Subject: Filling up the post of Staff Car Driver (Grade-ll) in Department of Land
Resources on deputation basis - reg.

The Department of Land Resources, Ministry of Rural Development invites
applications for filling up the post of Staff Car Driver (Grade-ll) purely on deputation
basis, as mentioned below:

Name of post No. of posts |Level in Pay Matrix
Staff Car Driver (Grade-ll) 01 IRs. 4000-100-6000 (pre-revised)

Level - 4, Rs.25500-81100 (7th CPC)
2. The details of the post along with eligibility criteria required, are given in Annexure
- |. The appointment will be made purely on deputation basis initially for a period of two
years and may further be extended upto three years. The terms and conditions of
deputation will be governed in terms of the instructions issued by the Department of
Personnel and Training vide OM No. 6/8/2009-Estt. (Pay Il) dated 17.06.2010 and OM
No. 2/6/2018-Estt. (Pay Il) dated 18.05.2018 and as amended from time to time.
Candidates, who volunteer for the post will not be permitted to withdraw their names
later.
3. Applications of interested and eligible officials and whose services can be
spared in the event of their selection may please be forwarded in the prescribed format
(Annexure-Il) to the Under Secretary (Admn), Department of Land Resources, Ministry
of Rural Development, NBO Building, Nirman Bhawan, ‘G’ Wing, New Delhi - 110011
alongwith the following documents:-

(i) Certified copies of up-to-date Annual Performance Appraisal Report/ Annual

Confidential Report (APAR/ACR Dossiers) for the last five years,

(ii) Integrity Certificate

Cc ~

<!-- page 2 -->

(iii) Vigilance Clearance including certification that no
disciplinary proceedings/Criminal Proceedings are either pending or
contemplated against the applicant.
5. The duly filled in complete application should reach this Office latest by 30th
September, 2020. Applications received after the closing date or otherwise found
incomplete will not be considered. While forwarding the applications, certification (as
per Annexure-ll) by the Cadre Controlling Authority must be submitted.
Encl.: as above.
(Th. Lianboi)
Under Secretary to the Government of India
Tel:011- 2304 4635
To
All Ministries/ Departments/ Autonomous organisations/ Attached Offices
under the Government of India - with the request to give it wider publicity to
all the eligible officers.
Copy to:
(1) STD, NIC, DoLR — with the request to upload the Circular on DoLR website.
(2) STD, NIC, DoRD - with the request to upload the Circular on DoRD website.

<!-- page 3 -->

ANNEXURE —1
2. |Classification General Central Services Group ‘C’
pene awcantognentineeay |
Level inthe Pay Matrix Rs. 4000-100-6000 (pre-revised)
| |
|
Grades from Regular Staff Car Driver (Grade-Il) in Level - 4,
hich deputation is tobe Rs.25500-81100/- (7th CPC) Rs. 4000-100 -6000 (pre-
lone and Qualification revised) working in Central Govt. Ministries/
Departments / Autonomous bodies / Attached offices,
tc.
OR
. Regular Staff Car Driver (Ordinary Grade) Level — 2,
IRs.3050-75-3950-80-4590 (pre-revised) working in
Central Govt. Ministries/ Departments / Autonomous
bodies / Attached offices etc., with nine years regular
service in the Grade.
AND
(i) Subject to the passing of the trade test as conducted
by Electrical and Mechanical Workshop of National
Airports Authority, New Delhi or any other
recognized institution; and
(ii) Must be able to read English numerical and figures.
(iii) Must have good knowledge of traffic regulations.
(iv) Must be able to locate faults and carry out minor
running defects.
(v) Must be able to change wheels and correctly inflate
tyres.
[| limit he maximum age limit for appointment by deputation
shall not be exceeding 56 years as on the closing date of
receipt of applications

<!-- page 4 -->

ANNEXURE - II
Application for the post of Staff Car Driver (Grade - Il) on deputation basis in the for the post of Staff Car Driver (Grade - Il) on deputation basis in the
Department of Land Resources, Ministry of Rural Development, Government of of Land Resources, Ministry of Rural Development Government of
India, New Delhi.
Advertisement No. 7
1) Name in full (in Block letters) 3
2) Father’s/ Husband’s name :
3) Nationality :
4) Sex हु
5) Date of Birth 4
6) Age as on date :
7) Present / Correspondence address:
Telephone :
Mobile ¢
E-mail :
8) Permanent address
Telephone :
Mobile E
9) a) Whether SC/ST/OBC :
b) Whether Physically handicapped? i

<!-- page 5 -->

10) Educational qualifications:
Exams Name of the Year of Subjects Percentage
passed University passing lof marks
lobtained
11) Experience details of all previous and present employment:
Name Name Pay Scale/ Period Nature of
of the of the post Salary To 0७6७5
Employer
12) Any other relevant information:
DECLARATION : |
| solemnly declare that all the statements made in this application are true,
complete and correct to the best of my knowledge and belief. | understand and agree
that in the event of any information being found false OR incorrect/ incomplete OR
ineligibility being detected at any time before OR after selection/interview, my
candidature is liable to be rejected and | shall be bound by the decision of the
Department of Land resources.
Signature
(Full name of the applicant)
Place:
Date :
- a
Tee arto

<!-- page 6 -->

Certification by the Employer/ Cadre Controlling Authority:
The information/details provided in the above application by the applicant are true
and correct as per the facts available on records. He/she possess educational
qualifications and experience mentioned in the vacancy circular. If selected, he/she will
be relieved immediately.
2. Also certified that:
(1) There is no vigilance or disciplinary case pending/contemplated
against Shri/Smt.
(2) _ His/Her integrity is certified.
(3) _ His/Her CR Dossier in original is enclosed/photocopies of the ACRs/APARs
for the last 5 years duly attested by an officer of the rank of Under Secretary of the
Govt. of India or above are enclosed.
(4) No major/minor penalty has been imposed on him/her during the last 10 years
or a list of major/minor penalties imposed on him/her during the last 10 years is
enclosed. (as the case may be).
Countersigned
(Employer/ Cadre Controlling Authority with Seal)
