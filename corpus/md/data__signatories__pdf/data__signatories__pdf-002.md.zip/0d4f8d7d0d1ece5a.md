---
doc_id: "0d4f8d7d0d1ece5a"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/486148070c571d30dff69d7809bc968d.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Entrustment of Additional charge of DDG DM, DoT HQ -reg."
date: "2025-05-07"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "21bfe07859f00d09"
---

<!-- page 1 -->

12-3/2025-STG-I

I/3275009/2025

No. 12-3/2025-STG-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
Dated the 07th May, 2025
OFFICE ORDER
Subject: - Entrustment of additional charge - reg.
The approval of the competent authority is hereby conveyed for entrustment
of additional charge of DDG (DM), DoT HQs to Sh. Dindayal Tosniwal, DDG(NT),
DoT HQs with immediate effect and without any extra remuneration.
2.
The charge report may be furnished to all concerned. Hindi version will
follow.

Copy to:

(Bijender Singh)
Under Secretary to the Government of India
Tele 011-2303 6282

1. Chairman, DCC/Member(S)/Member(T)/Member(F)/DG(Telecom), DoT;
2. AS(T)/ Administrator USoF / All Advisors, DoT;
3. CVO, DoT HQs;
4. All Sr.DDGs /DDGs DoT HQs;
5. DDG (C&A), DoT HQs;
6. Admn.I-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.I Sec., DoT HQs;
7. Pay Bill Section, DoT HQs;
8. US (SNG)/ADG (APAR)/AD (STG-1)/AAO (STG-I), DoT HQs;
9. The Officers concerned;
10. Official Language Section, DoT for Hindi version of the order;
11. Order Bundle/PA to US(SGT) for uploading this order on DoT website.
