---
doc_id: "104efab2fad16ba1"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/c9d7f74df314f844cdc93f5b5faca012.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Notification of the Child Labour (Prohibition and Regulation) Amendment Rules,(2 june 2017)"
date: "2017-06-02"
pages: 15
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "39089340d61f982f"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

EXTRAORDINARY
II—
3—
(i)
PART II—Section 3—Sub-section (i)
PUBLISHED BY AUTHORITY
. 444]

No. 444]

NEW DELHI, FRIDAY, JUNE 2, 2017/ JYAISTHA 12, 1939

श्रम और रोजगार मंत्रालय
ऄधिसूचना
नइ दिल्ली, 2 जून, 2017
सा. का. धन. 543(ऄ).— बालक श्रम (प्रधिषेि और धिधनयमन) धनयम, 1988 का और संशोिन करने के धलए बालक और कु मार
श्रम (प्रधिषेि और धिधनयमन) ऄधिधनयम, 1986 (1986 का 61) की िारा 18 की ईपिारा (1) की ऄपेक्षानुसार, कधिपय प्रारूप धनयम
भारि सरकार के श्रम और रोजगार मंत्रालय की ऄधिसूचना सं. सा.का.धन. 392(ऄ) िारीख 20 ऄप्रैल, 2017 द्वारा भारि के राजपत्र,
ऄसािारण, भाग II, खंड 3, ईपखंड (i) में प्रकाधशि दकए गए थे, ईन पर ईन सभी व्यधियों से धजनके ईससे प्रभाधिि होने की संभािना है,
ईि ऄधिसूचना के राजपत्र की प्रधियां जनिा को ईपलब्ि होने की िारीख से िीस दिनों की ऄिधि के भीिर अक्षेप और सुझाि अमंधत्रि
दकए गए थे ;
और राजपत्र की प्रधियां जनिा को 20 ऄप्रैल, 2017 को ईपलब्ि करा िी गइ थीं ;
और ईि प्रारूप धनयम के संबंि में जनिा से अक्षेपों और सुझािों पर के न्द्रीय सरकार द्वारा धिचार कर धलया गया है ;
ऄिः, ऄब के न्द्रीय सरकार, बालक और कु मार श्रम (प्रधिषेि और धिधनयमन) ऄधिधनयम, 1986 (1986 का 61) की िारा 18 द्वारा
प्रित्त शधियों का प्रयोग करिे हुए, बालक श्रम (प्रधिषेि और धिधनयमन) धनयम, 1988 का और संशोिन करने के धलए धनम्नधलधखि धनयम
बनािी है, ऄथााि् :1. (1) आन धनयमों का संधक्षप्ि नाम बालक श्रम (प्रधिषेि और धिधनयमन) संशोिन धनयम, 2017 है
(2) ये ईनके राजपत्र में ऄंधिम प्रकाशन की िारीख को प्रिृत्ि होंगे
2. बालक श्रम (प्रधिषेि और धिधनयमन) धनयम, 1988 (धजसे आसमें आसके पश्चाि् मूल धनयम कहा गया है) के धनयम 1 के ईपधनयम (1) में
“बालक श्रम” शब्िों के थथान पर “बालक और कु मार श्रम” शब्ि रखे जाएंगे
3. मूल धनयमों के धनयम 2 में,-(i) खंड (क) और खंड (ख) के थथान पर धन‍नधलधखि खंड रखे जाएंगे, ऄथााि् :--

3527 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

‘(क) “ऄधिधनयम” से बालक और कु मार श्रम (प्रधिषेि और धिधनयमन) ऄधिधनयम, 1986 (1986 का 61) ऄधभप्रेि
है ;
(ख) “सधमधि” से ऄधिधनयम की िारा 5 की ईपिारा (1) के ऄिीन गठठि िकनीकी सलाहकार सधमधि ऄधभप्रेि है ;’;
(ii) खंड (घ) के पश्चाि् धन‍नधलधखि खंड ऄंि:थथाधपि दकए जाएंगे, ऄथााि् :-‘(घक) “धनधि” से ऄधिधनयम की िारा 14ख की ईपिारा (1) के ऄिीन गठठि बालक और कु मार पुनिाास धनधि
ऄधभप्रेि है ;
(घख) “धनरीक्षक” से िारा 17 के ऄिीन के न्द्रीय सरकार द्वारा धनयुि धनरीक्षक ऄधभप्रेि है ;
(घग) “नगरपाधलका” से संधििान के ऄनुच्छे ि 243थ के ऄिीन गठठि थि:सरकार की कोइ संथथा ऄधभप्रेि है ;’;
(iii) खंड (ङ) के पश्चाि् धन‍नधलधखि खंड ऄंि:थथाधपि दकया जाएगा, ऄथााि् :-‘(ङक) “पंचायि” से संधििान के ऄनुच्छे ि 243ख के ऄिीन गठठि पंचायि ऄधभप्रेि है ;’;
(iv) खंड (छ) के पश्चाि् धन‍नधलधखि खंड ऄंि:थथाधपि दकया जाएगा, ऄथााि् :-‘(ज) आन धनयमों में प्रयुक्ि शब्ि और पि, जो ईनमें पठरभाधषि नहीं है ककिु ऄधिधनयम में पठरभाधषि है, का िही ऄथा
होगा, जो ईनका ऄधिधनयम में है ’
4. मूल धनयमों के धनयम 2 के पश्चाि् धन‍नधलधखि धनयम ऄंि:थथाधपि दकया जाएगा, ऄथााि् :-‘2ऄ. ऄधिधनयम के ईल्लंघन में बालकों और कु मारों के धनयोजन के प्रधिषेि के संबंि में जागकतकिा—कें रीय सरकार यह
सुधनधश्चि करने के धलए दक ऄधिधनयम के ईपबंिों के ईल्लंघन में बालकों और दकशोरों को धनयोधजि न दकया जाए या ईन्द्हें
दकसी व्यिसाय या प्रदरियया में काया करने के धलए ऄनु्ाि न दकया जाए, समुधचि ईपायों के माध्यम से,-(क) लोक और पारं पठरक माध्यम िथा जनसंपका के माध्यम का ईपयोग करके लोक जागकतकिा ऄधभयानों का प्रबंि
करे गी, धजसके ऄंिगाि िूरिशान, रे धडयों, आं टरनेट और प्रप्रट मीधडया है िादक सािारण पधब्लक, धजसके ऄंिगाि
बालकों और कु मारों, धजन्द्हें ऄधिधनयम के ईपबंिों के ईल्लंघन में धनयोधजि दकया गया हो, के धनयोक्िा है, को
ऄधिधनयम के ईपबंिों के धिषय में जागकतक दकया जाए धजससे दक धनयोक्िाओं य या ऄन्द्य व्यधक्ियों को बालकों
और कु मारों को ऄधिधनयम के ईपबंिों के ईल्लंघन में दकसी व्यिसाय या प्रदरियया में धनयोधजि करने से
हिोत्साधहि दकया जा सके ;
(ख) ईपरियमों या ऄधिधनयम के ईपबंिों के ईल्लंघन में बालकों या कु मारों के धनयोजन की घटनाओं य की, कें रीय
सरकार द्वारा धिधनर्दिष्ट प्राधिकाठरयों को ठरपोटा करने के धलए संचार के असानी से पहुंचे जा सकने िाले
सािनों और धि्ापनों का संििान ;
(ग)

संभि पठरमाण िक ऄधिधनयम, आन धनयमों और ईनसे संबंधिि सूचना का रे ल कोचों, रे लिे थटेशनों, मुख्य बस
थटेशनों, टोल प्लाजास, पत्िनों और पत्िन प्राधिकरणों, धिमानपत्िनों िथा ऄन्द्य लोक थथानों, धजसके ऄंिगाि
शॉप्रपग सेंटर, मार्दकट, धसनेमा हाल, होटल, ऄथपिाल, पंचायि कायाालय, पुधलस थटेशन, अिासीय कल्याण
संगम कायाालय, औद्योधगक क्षेत्र, धिद्यालय, शैधक्षक संथथाएं, न्द्यायालय पठरसर िथा आस ऄधिधनयम के ऄिीन
प्राधिकृ ि सभी प्राधिकाठरयों के कायाालय हैं, में प्रिशान ;

(घ) समुधचि धिधि के माध्यम से धिद्यालय धशक्षा में धशक्षण साम्ी और पा्यकरियम में संििान ; और
(ङ) प्रधशक्षण को समाधिष्ट करने और ऄधिधनयम के ईपबंिों पर साम्ी के प्रधि संिेिनशील बनाने िथा ईसके प्रधि
धिधभन्द्न पणिाठरयों के ईत्िरिाधयत्ि, कें रीय श्रम सेिा, पुधलस, न्द्याधयक और धसधिल सेिा ऄकािधमयों,
ऄध्यापक प्रधशक्षण और पुनश्चयाा पा्यकरियमों का संििान िथा ऄन्द्य सुसंगि पणिाठरयों, धजसके ऄंिगाि पंचायि
के सिथय धचदकत्सक और सरकार के संबंधिि का्मक हैं, के धलए संिेिनशीलिा कायारियमों का प्रबंि करना

<!-- page 3 -->

II

3

(i)

2अ. बालक का धशक्षा को प्रभाधिि दकए धबना कु टुंब की सहायिा करना—(1) िारा 3 के ईपबंिों के ऄिीन रहिे हुए बालक
दकसी भी रीधि में ऄपनी धिद्यालय धशक्षा को प्रभाधिि दकए धबना,-(क) ऄपने कु टुंब के ईपरियम में आस शिा के ऄिीन रहिे हुए सहायिा कर सके गा दक ऐसी सहायिा,-(i)

ऄधिधनयम के ऄनुसूची के भाग क

ख में सूचीबद्ध दकसी पठरसंकटमय व्यिसाय या प्रदरियया में

नहीं होगी ;
(ii)

में धिधनमााण, ईत्पािन, अपू्ि या खुिरा Ük`a[kyk के दकसी थिर पर कोइ काया या व्यिसाय या
प्रदरियया सध‍मधलि नहीं होगी, जो बालक या ईसके कु टुंब या कु टुंब के ईपरियम के धलए पाठरश्रधमक
प्रिान करिी हो ;

(iii)

में ईसके कु टुंब या कु टुंब ईपरियम की सहायिा करने के धलए िहां ऄनु्ाि दकया जाएगा, जहां कु टुंब
ऄधिभोगी है ;

(iv)

में िह धिद्यालय समय और 7 बजे सायं और 8 बजे प्राि: के बीच कोइ काया नहीं करे गा ;

(v)

में िह सहायिा के ऐसे काया में धनयोधजि नहीं होगा, जो बालक की धशक्षा के ऄधिकार या
धिद्यालय में ईसकी ईपधथथधि के साथ हथिक्षेप करिी हो या ईसमें बािा डालिी हो या जो
प्रधिकू ल रूप से ईसकी धशक्षा को प्रभाधिि करिी हो, धजसके ऄंिगाि ऐसे कायाकलाप हैं, धजन्द्हें
संपूणा धशक्षा से ऄलग नहीं दकया जा सकिा है जैसे गृह काया या ऄन्द्य ऄधिठरि पाठयरियम
गधिधिधियां हैं, जो ईसे धिद्यालय में सौंपी गइ हैं ;

(vi)

में धबना धिश्राम के सिि रूप से दकसी काया में धनयोधजि नहीं होगा, जो ईसे थका िें और ईसे
ईसके थिाथ्य और मधथिष्क को िरोिाजा करने के धलए धिश्राम ऄनु्ाि दकया जाएगा िथा कोइ
बालक एक दिन में धिश्राम की ऄिधि को सध‍मधलि न करिे हुए िीन घंटें से ‍यािा के धलए
सहायिा नहीं करे गा ;

(vii)

में दकसी बालक का दकसी ियथक या कु मार के थथान पर ईसके कु टुंब या कु टुं ब के ईपरियम की
सहायिा के धलए रखा जाना सध‍मधलि नहीं है ; और

(viii)

ित्समय प्रिृत्ि दकसी ऄन्द्य धिधि के ईल्लंघन में नहीं होगी ;

(ख) ऄपने कु टुंब की मिि या सहायिा ऐसी रीधि में करना, जो दकसी व्यिसाय, संकमा, पेशे, धिधनमााण या कारबार
या दकसी संिाय या बालक को फायिें या दकसी ऄन्द्य व्यधक्ि की मिि के धलए, जो बालक पर धनयंत्रण रखिा है,
के धलए है िथा जो बालक की िृधद्ध, धशक्षा और सम् धिकास के धलए ऄिरोिकारी नहीं है
थपष्टीकरण 1.—आस धनयम के प्रयोजनों के धलए, के िल—
(क) बालक का सगा भाइ और बहन ;
(ख) बालक के मािा-धपिा द्वारा धिधिपूिाक गोि लेने के माध्यम से बालक का भाइ या बहन ; और
(ग) बालक के मािा-धपिा का सगा भाइ और बहन,
को बालक के कु टुंब में सध‍मधलि दकया जाएगा
थपष्टीकरण 2.(1)— थपष्टीकरण 1 के प्रयोजनों के धलए, यह थपष्ट दकया जािा है दक प्रारं भि: आस संबंि में कोइ संिेह
दक व्यधक्ि सगा भाइ या बहन है, को, यथाधथथधि, संबंधिि नगरपाधलका या पंचायि द्वारा जारी ऐसे व्यधक्ि की
िंशािली या समुधचि सरकार के संबंधिि प्राधिकारी द्वारा जारी दकसी ऄन्द्य धिधिक िथिािेज की जांच करके िूर
दकया जा सके गा

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) जहां धिद्यालय में धशक्षा प्राप्ि कर रहा कोइ बालक धिद्यालय के प्रिानाध्यापक या मुख्याध्यापक को धबना दकसी
संसूचना के लगािार िीस दिन के धलए ऄनुपधथथि रहिा है िो प्रिानाध्यापक या मुख्याध्यापक सूचना के धलए ऐसी
ऄनुपधथथधि की संसूचना धनयम 17ग के ईपधनयम (1) के खंड (i) में धनर्दिष्ट संबंधिि नोडल ऄधिकारी को िेगा
2आ. बालक का कलाकार के रूप में काया करना—(1) िारा 3 के ईपबंिों के ऄिीन रहिे हुए बालक को धन‍नधलधखि शितों  के
ऄिीन रहिे हुए कलाकार के रूप में काया करने के धलए ऄनु्ाि दकया जा सके गा, ऄथााि् :-(क) दकसी बालक को एक दिन में पााँच घंटें से ‍यािा काया करने के धलए और धबना दकसी धिश्राम के िीन घंटों के
ऄनधिक के धलए काया करने के धलए ऄनु्ाि नहीं दकया जाएगा ;
(ख) दकसी श्रव्य-िृश्य कायारियम या दकसी िाधणध‍यक समारोह, धजसमें बालक की भागीिारी ऄंििाधलि है, का
धनमाािा बालक की सहभाधगिा को ईस धजले के धजला मधजथरे ट से, धजसमें ईस कायाकलाप को दकया जाना है,
ऄनु्ा प्राप्ि करने के पश्चाि् ही शाधमल करे गा और धजला मधजथरे ट को कायारियम को अरं भ करने से पूिा प्ररूप ग
में एक िचनबंि िथा बालक सहभाधगयों, यथाधथथधि, मािा-धपिा या संरक्षक की सहमधि, प्रोडक्शन या
समारोह से व्यधष्टक का नाम, जो बालक की सुरक्षा और संरक्षा के धलए ईत्िरिायी हैं, की सूची प्रथिुि करे गा
और यह सुधनधश्चि करे गा दक ईसकी दफल्म और िूरिशान कायारियमों की थरियीप्रनग आस धडथक्लेमर को धिधनर्दिष्ट
करिे हुए की जाएगी दक यदि दकसी बालक को शूटटग में धनयोधजि दकया गया है िो यह सुधनधश्चि करने के
धलए दक शूटटग की समथि प्रदरियया के िररान बालक का िुकतपयोग, ऄनिेखी या ईत्पीड़न न नहीं हो, के धलए सभी
ईपाय दकए गए हैं ;
(ग) खंड ख में धनर्दिष्ट िचनबंि 6 मास के धलए धिधिमान्द्य होगा और ईसमें ऐसे प्रयोजन के धलए समय-समय पर
कें रीय सरकार द्वारा जारी मागािशाक धसद्धांिों िथा संरक्षण नीधियों के ऄनुसार बालक की धशक्षा, सुरक्षा, संरक्षा
िथा बाल शोषण की ठरपोटा करने के धलए ईपबंिों का थपष्ट कथन होगा, धजसके ऄंिगाि—
(i)

बालक के शारीठरक और मानधसक थिाथ्य के धलए सुधििाओं य का सुधनश्चय ;

(ii)

बालक के धलए समयबद्ध पोषक अहार ;

(iii)

िैधनक अिश्यकिाओं य के धलए पयााप्ि अपू्ि के साथ सुरधक्षि, थिच्छ अश्रय ; और

(iv)

बालकों के संरक्षण के धलए ित्समय प्रिृत्ि सभी लागू धिधियों का ऄनुपालन, धजसके ऄंिगाि
ईनका धशक्षा, िेखरे ख और संरक्षण िथा यरन ऄपरािों से सुरक्षा के धलए ऄधिकार है ;

(घ) बालक की धशक्षा के धलए समुधचि सुधििाओं य का प्रबंि दकया जाएगा िादक यह सुधनधश्चि दकया जा सके दक
धिद्यालय में पाठों की धनरं िरिा बनी रहे और दकसी बालक को 27 दिन से ऄधिक के धलए लगािार काया करने
के धलए ऄनु्ाि नहीं दकया जाएगा ;
(ङ) समारोह या कायारियम के धलए ऄधिकिम 5 बालकों के धलए एक ईत्िरिायी व्यधक्ि की धनयुधक्ि की जाएगी
िादक बालक की सुरक्षा, िेखरे ख और ईसके सिोत्िम धहि का सुधनश्चय दकया जा सके ;
(च) बालक द्वारा कायारियम या समारोह से ऄ्जि अय के कम से कम बीस प्रधिशि को सीिे दकसी राष्रीयकृ ि बैंक में
बालक के नाम से धनयि जमा खािे में जमा दकया जाएगा धजसको बालक के ियथक होने पर बालक को प्रत्यय
दकया जा सके गा ; और
(छ) दकसी बालक को ईसकी आच्छा और सहमधि के धिकतद्ध दकसी श्रव्य-िृश्य और रियीड़न ा कायाकलाप, धजसके ऄंिगाि
ऄनरपचाठरक मनोरं जन कायाकलाप भी हैं, में भाग लेने के धलए बाध्य नहीं दकया जाएगा
(2) िारा 3 की ईपिारा (2) के थपष्टीकरण के खंड ग के प्रयोजनों के धलए ईसमें ऄंि्िष्ट “ऄन्द्य ऐसा कायाकलाप” पि से
धन‍नधलधखि ऄधभप्रेि होगा—
(i)

कोइ कायाकलाप, धजसमें बालक दकसी खेल प्रधिथपिाा या समारोह या ऐसी खेल प्रधिथपिाा या समारोह के
धलए प्रधशक्षण में भाग ले रहा है ;

<!-- page 5 -->

II

5

(i)
(ii)

िूरिशान पर धसनेमा और डाक्यूमेंटरी प्रिशान, धजसके ऄंिगाि ठरयल्टी शो, क्िीज़ श शो, टेलेंट शो, रे धडयो या
कायारियम या कोइ ऄन्द्य माध्यम है ;

(iii)

नाटक सीठरयल ;

(iv)

दकसी कायारियम या समारोह में एंकर के रूप में भागीिारी ; और

(v)

कोइ ऄन्द्य कलात्मक ऄधभनय, धजसे कें रीय सरकार व्यधष्टक मामलों में ऄनु्ाि करे , धजसके ऄंिगाि िनीय
फायिें के धलए थरीट प्रिशान सध‍मधलि नहीं है ’

5. मूल धनयमों के धनयम 15 के पश्चाि् धन‍नधलधखि धनयम ऄंि:थथाधपि दकया जाएगा, ऄथााि् :-“15ऄ. काया के घंटें—िारा 7 के ईपबंिों के ऄिीन रहिे हुए दकसी कु मार से दकसी थथापन में काया के ईिने घंटों से ऄधिक काया
करने की ऄपेक्षा नहीं होगी या ऄनु्ाि नहीं दकया जाएगा धजिने की ऐसे थथापन में कु मार के काया के घंटों को धिधनयधमि करने
के धलए ित्समय प्रिृत्ि धिधि के ऄिीन ऄनु्ेय हैं ”
6. मूल धनयमों के

16

ईपधनयम (1) में “बालक” शब्ि के थथान पर “कु मार” शब्ि रखा जाएगा

7. मूल धनयमों के 16 के पश्चाि् धन‍नधलधखि धनयम ऄंि:थथाधपि दकया जाएगा, ऄथााि् :-“16ऄ. बालक या कु मार को बालक और कु मार श्रम पुनिाास धनधि से रकम का संिाय—(1) िारा 14ख की ईपिारा (3) के ऄिीन बालक
और कु मार श्रम पुनिाास धनधि में, यथाधथथधि, प्रत्यय, जमा या धिधनिान की गइ धनधि और ईस पर ईिभूि ब्याज का ईस बालक या कु मार
को धन‍नधलधखि रीधि में संिाय दकया जाएगा धजसके पक्ष में ऐसे रकम का प्रत्यय दकया गया है, ऄथााि् :-(i)

ऄधिकाठरिा रखने िाला धनरीक्षक या नोडल ऄधिकारी ऄपने पयािेक्षण के ऄिीन सुधनधश्चि करे गा दक ऐसे बालक या कु मार का

एक खािा दकसी राष्रीयकृ ि बैंक में खोला जाए और, यथाधथथधि, ईस बैंक को, धजसमें धनधि की रकम को जमा दकया गया है या िारा
14ख की ईपिारा (3) के ऄिीन धनधि में रकम को जमा करने के धलए ईत्िरिायी व्यधक्ि ;
(ii)

बालक या कु मार के पक्ष में धनधि में समानुपािी रकम पर ईिभूि ब्याज को ऄिा-िा्षक रूप से यथाधथथधि, बालक या कु मार के

खािे में बैंक या रकम का धिधनिान करने के धलए ईत्िरिायी व्यधक्ि धनरीक्षक को सूचना के ऄिीन ;
(iii) जब संबद्ध बालक या कु मार ऄठारह िषा की अयु पूरी कर लेिा है िब यथा संभि शीघ्र िुरन्द्ि या िीन मास की ऄिधि के भीिर,
बालक के पक्ष में ईस पर ईद्भूि ब्याज, धजसमें बैंक में शेष ब्याज या िारा 14ख की ईप-िारा (3) के ऄिीन आस प्रकार धिधनिान दकया
गया शेष भी है, के साथ जमा की गइ, धनक्षेप की गइ या धिधनिान की गइ कु ल रकम, यथाधथथधि, बालक या कु मार के ईि बैंक खािे में
ऄन्द्िठरि की जाएगी ; और
(iv) धनरीक्षक संबद्ध बालक या कु मार की धिधशधियों, जो ईसकी पहचान करने के धलए पयााप्त हैं, के साथ खंड (ii) और खंड (iii) के ऄिीन
ऄन्द्िठरि रकम की एक ठरपोटा िैयार करे गा िथा के न्द्रीय सरकार को िा्षक रूप से ठरपोटा की एक प्रधि सूचनाथा भेजेगा
(2) ऄधिधनयम के ईपबंिों के ईल्लंघन के धलए बालक या कु मार के पक्ष में न्द्यायालय के अिेश या धनणाय के ऄनुसरण में जुमााने के माध्यम
से या ऄपरािों के शमन के धलए िसूल की गइ कोइ रकम भी धनधि में जमा की जाएगी और ऐसे अिेश या धनणाय के ऄनुसार व्यय की
जाएगी
8. ‘मूल धनयमों के धनयम 17 के थथान पर, धनम्नधलधखि रखा जाएगा, ऄथााि्:'17 अयु का प्रमाणपत्र- (1) जहां धनरीक्षक को यह अशंका है दक दकसी कु मार को दकसी ऐसे व्यिसाय या प्रसंथकरणों में धनयोधजि दकया
गया है धजनमें ईसे ऄधिधनयम की िारा 3क के ऄिीन धनयोधजि दकया जाना प्रधिधषद्ध है, िहां िह ऐसे कु मार के धनयोजक से यह ईपेक्षा
कर सके गा दक िह समुधचि धचदकत्सा प्राधिकारी से अयु का प्रमाणपत्र धनरीक्षक को प्रथिुि करे
(2) समुधचि धचदकत्सा प्राधिकारी, ईप-िारा (1) के ऄिीन अयु का प्रमाणपत्र जारी करने के धलए कु मार की परीक्षा करने समय;(i)

कु मार का अिार काडा, और ईसके ऄभाि में;

(ii)

धिद्यालय से जारी जन्द्म की िारीख का प्रमाणपत्र या, कु मार के संबद्ध परीक्षा बोडा
प्रमाणपत्र, यदि ईपलब्ि हों और ईसके ऄभाि में ;

से जारी मैठरकु लेशन या समिुल्य

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(iii) धनगम या नगरपाधलक प्राधिकारी या पंचायि द्वारा दिए गए कु मार का जन्द्म प्रमाणपत्र पर धिचार करे गा;
और खंड (i) से खंड (iii) में धिधनर्दिि पद्धधियों के ऄभाि में ही, ऄधथथधिकास परीक्षण या दकसी ऄन्द्य निीनिम धचदकत्सीय अयु
ऄििारण परीक्षण के माध्यम से ऐसे धचदकत्सा प्राधिकारी द्वारा अयु ऄििाठरि की जाएगी
(3) ऄधथथधिकास परीक्षण या कोइ ऄन्द्य निीनिम धचदकत्सीय अयु ऄििारण परीक्षण ऄपर श्रम अयुि की पंधि के समुधचि प्राधिकारी,
जो के न्द्रीय सरकार द्वारा आस धनधमत्त धिधनर्दिि दकया जाए, के अिेश पर संचाधलि दकया जाएगा और ऐसा ऄििारण, ऐसे अिेश की
िारीख से पन्द्रह दिन के भीिर पूरा दकया जाएगा
(4) ईप-धनयम (1) में धनर्दिि अयु प्रमाणपत्र प्ररूप ‘ख’ में जारी दकया जाएगा
(5) अयु प्रमाणपत्र के जारी दकए जाने के धलए धचदकत्सा प्राधिकारी को संिय
े प्रभार िहीं होंगे जो, यथाधथथधि, के न्द्रीय सरकार या रा‍य
सरकार द्वारा ईनके धचदकत्सा बोडतों  के धलए धिधनर्दिि दकए जाएं
(6) धचदकत्सा प्राधिकारी को संिय
े प्रभार ईस कु मार के

क द्वारा िहन दकए जाएंगे धजसकी अयु आस धनयम के ऄिीन ऄििाठरि की

जािी है
थपिीकरण:- आस धनयम के प्रयोजन के धलए,(i) “धचदकत्सा प्राधिकारी” से ऐसा कोइ सरकारी धचदकत्सक, जो दकसी धजले के सहायक शल्य धचदकत्सक की पंधि से ऄन्द्यून हो या
कमाचारी रा‍य बीमा औषिालय या ऄथपिालों में धनयोधजि समिुल्य पंधि का धनयधमि धचदकत्सक ऄधभप्रेि है ;
(ii) “कु मार” से ऄधिधनयम की िारा 2 के खंड (i) में यथा पठरभाधषि कु मार ऄधभप्रेि है ’
9. मूल धनयम के धनयम 17 के पश्चाि्, धनम्नधलधखि धनयम ऄन्द्िःथथाधपि दकए जाएंगें ; ऄथााि:् “17क व्यधि, जो पठरिाि फाआल कर सकें गे- ऐसा कोइ व्यधि, जो दकसी ऄपराि के दकए जाने के धलए ऄधिधनयम के ऄिीन
पठरिाि फाआल कर सके गा, में थकू ल प्रबंिन सधमधि, बालक संरक्षण सधमधि, पंचायि या नगरपाधलका से थकू ल ऄध्यापक और प्रधिधनधि
सध‍मधलि हैं, जो ईस िशा में पठरिाि फाआल करने के धलए संिेिनशील होंगे दक ईनके ऄपने -ऄपने थकू लों के छात्रों में से कोइ छात्र आस
ऄधिधनयम के आन ईपबंिों का ईल्लंघन करके धनयोधजि दकया जािा है
17ख. ऄपरािों का शमन करने की रीधि- (1) कोइ ऄधभयुि व्यधि,(i) जो िारा 14 की ईप-िारा (3) के ऄिीन पहली बार कोइ ऄपराि करिा है; या
(ii) जो मािा-धपिा या संरक्षक होिे हुए, ईि िारा के ऄिीन ऄपराि करिा है,
िारा 14घ की ईप-िारा (1) के ऄिीन ऄपराि का शमन करने की ऄधिकाठरिा रखने िाले धजला मधजथरे ट के पास अिेिन फाआल
कर सके गा
(2) धजला मधजथरेट ईप-धनयम (1) के ऄिीन फाआल दकए गए अिेिन पर ऄधभयुि व्यधि और संबद्ध धनरीक्षक को सुनने के पश्चाि्,
अिेिन का धनपटान करे गा और यदि अिेिन ऄनु्ाि कर दिया जािा है िो धनम्नधलधखि के ऄिीन रहिे हुए शमन करने का प्रमा णपत्र
जारी करे गा(i) ऐसे प्रमाणपत्र में धिधनर्दिि समय के भीिर, ऐसे ऄपराि के धलए ईपबंधिि

ऄधिकिम जुमााने के पचास प्रधिशि की राधश

का संिाय; या
(ii) खंड (i) के ऄिीन धिधनर्दिि शमनकारी रकम के साथ ऐसे ऄपराि के धलए ईपबंधिि ऄधिकिम जुमााने का पच्चीस प्रधिशि की
ऄधिठरि राधश का संिाय, यदि ऄधभयुि ईक्ि खंड के ऄिीन धिधनर्दिि समय के भीिर शमनकारी रकम का संिाय करने में ऄसफल रहिा
है और ऐसा धिलंधबि संिाय धजला मधजथरे ट द्वारा यथाधिधनर्दिष्ट की जाने िाली और ऄिधि, जो ईस खंड में धिधनर्दिष्ट ऄिधि से ऄधिक
नहीं होगी, के भीिर दकया जाएगा
(3) शमनकारी रकम ऄधभयुि व्यधि द्वारा के न्द्रीय सरकार को संित्त की जाएगी
(4) यदि ऄधभयुि व्यधि ईप-धनयम (2) के ऄिीन शमनकारी रकम का संिाय करने में ऄसफल रहिा है िो कायािाही िारा 14घ की ईपिारा (2) के ऄिीन धिधनर्दिि दकए गए ऄनुसार जारी रहेगी

<!-- page 7 -->

II

(i)

7

17ग. धजला मधजथरेट के किाव्य- (1) धजला मधजथरेट(i)

नोडल ऄधिकाठरयों के रूप में ्ाि होने िाले ईसके ऄिीनथथ ऐसे ऄधिकाठरयों को, जो िह अिश्यक समझे, धिधनर्दिि करे गा,
जो िारा 17क के ऄिीन के न्द्रीय सरकार द्वारा ईसको प्रित्त और ऄधिरोधपि धजला मधजथरेट की सभी या दकन्द्हीं शधियों का
प्रयोग करें गे और सभी या दकन्द्हीं किाव्यों का पालन करें गे

(ii)

नोडल ऄधिकारी को ऄिीनथथ ऄधिकारी के रूप में ईसकी ऄधिकाठरिा की थथानीय सीमाओं य के भीिर ईसके द्वारा प्रयोग की
जाने िाली ऐसी शधियों और पालन दकए जाने िाले किाव्यों, जो िह समुधचि समझे, को समनुिधे शि करे गा

(iii)

धनम्नधलधखि से धमलकर बनी धजले में बनाइ जाने िाले कायाबल के ऄध्यक्ष के रूप में ऄध्यक्षिा करे गा;(क)

ईसकी ऄधिकाठरिा की थथानीय सीमाओं य के प्रयोजनों के धलए िारा 17 के ऄिीन धनयुि धनरीक्षक;

(ख)

ईसकी ऄधिकाठरिा की थथानीय सीमाओं य के प्रयोजनों के धलए पुधलस ऄिीक्षक;

(ग)

ईसकी ऄधिकाठरिा की थथानीय सीमाओं य के प्रयोजनों के धलए ऄपर धजला मधजथरेट ;

(घ)

ईसकी ऄधिकाठरिा की थथानीय सीमाओं य के प्रयोजनों के धलए खंड (i) के ऄिीन धनर्दिि नोडल ऄधिकारी;

(ङ)

ईसकी ऄधिकाठरिा की थथानीय सीमाओं य के प्रयोजनों के धलए सहायक श्रम अयुि (के न्द्रीय);

(च)

िो िषा की ऄिधि के धलए चरियानुरियमी अिार पर धजले में धनयोधजि बालकों के बचाि और पुनिाास में ऄन्द्ििाधलि प्रत्येक
थिैधच्छक संगठन से िो-िो प्रधिधनधि;

(छ)

धजला न्द्यायािीश द्वारा नामधनर्दिि दकए जाने िाले धजला धिधिक सेिा प्राधिकरण का एक प्रधिधनधि; और

(ज)

धजला िुव्याापार धनिारण यूधनट का सिथय;

(झ)

धजले की बालक कल्याण सधमधि का ऄध्यक्ष;

(ञ)

मधहला और बाल धिकास से संबंधिि भारि सरकार के मंत्रालय की एकीकृ ि बालक संरक्षण थकीम के ऄिीन धजला बाल
श्रम संरक्षण ऄधिकारी;

(ट)

धजला धशक्षा ऄधिकारी ;

(ठ)

धजला मधजथरेट द्वारा नाम धनर्दिि दकया गया कोइ ऄन्द्य व्यधि;

(ड)

काया बल का सधचि खंड (i) में धनर्दिि कोइ नोडल ऄधिकारी होगा और ऄध्यक्ष द्वारा नाम धनर्दिि दकया जाएगा;

(2) ईप-िारा (1) के खंड (iii) में धनर्दिि कायाबल प्रत्येक मास में कम से कम एक बार बैठक करे गा और ईपलब्ि समय, ित्समय प्रिृत्त धिधि
के ऄनुसार छापामारी का धबन्द्ि,ु योजना की गोपनीयिा, समय-समय पर के न्द्रीय सरकार द्वारा जारी बचाि और प्रत्याििान के धलए
मागािशी धसद्धांिों के ऄनुसार पीधड़न िों और साधक्षयों का संरक्षण िथा ऄंिठरम ऄनुिोष को ध्यान में रखिे हुए बचाि काया संचाधलि करने
की व्यापक कारा िाइ योजना बनाएगा और काया बल के न्द्रीय सरकार द्वारा ऐसे प्रयोजन के धलए सृधजि पोटाल पर ऐसी बैठक के कायािृत्त को
भी ऄपलोड कराएगा
(3) ईप-िारा (1) में धनर्दिि किाव्यों के ऄलािा, धजला मधजथरेट नोडल ऄधिकाठरयों के माध्यम से सुधनधश्चि करे गा दक बालक और कु मार,
जो ऄधिधनयम के ईपबंिों का ईल्लंघन करके धनयोधजि दकए जािे हैं, बचाए जािे हैं िथा ईन्द्हें (क) धनम्नधलधखि के ईपबंिों के ऄनुसार
पुनिाधसि दकया जाएगा(i) दकशोर न्द्याय (बालकों की िेख-रे ख और संरक्षण) ऄधिधनयम, 2015 (2016 का 2) िथा िद्धीन बनाए गए धनयम;
(ii) बंधिि श्रम पद्धधि (ईत्सािन) ऄधिधनयम, 1976 (1976 का 19);
(iii) के न्द्रीय बंधिि श्रधमक पुनिाास सेक्टर थकीम, 2016;
(iv) कोइ राष्ट्रीय बालक श्रम पठरयोजना;
(v) ित्समय प्रिृत्त कोइ ऄन्द्य धिधि थकीम, धजसके ऄिीन ऐसे बालकों या कु मारों को पुनिाधसि दकया जाए; और धनम्नधलधखि के
ऄध्यिीन-

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(I)

सक्षम ऄधिकाठरिा के न्द्यायालय के धनिेश, यदि कोइ हों;

(II)

आस संबंि में समय-समय पर के न्द्रीय सरकार द्वारा जारी दकए गए बचाि और प्रत्याििान के धलए मागािशी
धसद्धांि

17घ, धनरीक्षकों के किाव्य- िारा 17 के ऄिीन के न्द्रीय सरकार द्वारा धनयुि कोइ धनरीक्षक, ऄधिधनयम के ईपबंिों का ऄनुपालन सुधनधश्चि
करने के प्रयोजनों के धलए,
(i)

समय-समय पर के न्द्रीय सरकार द्वारा जारी धनरीक्षण के सधियमों का ऄनुपालन करे गा;

(ii)

आस ऄधिधनयम के ईपबंिों का ऄनुपालन सुधनधश्चि करने के प्रयोजनों के धलए समय-समय पर के न्द्रीय सरकार द्वारा
जारी ऄनुिश
े ों का ऄनुपालन करे गा; और

(iii)

आस ऄधिधनयम के ईपबंिों का पालन सुधनश्चि करने के प्रयोजन के धलए ईसके द्वारा दकए गए धनरीक्षण िथा ऐसे
प्रयोजनों के धलए ईसके द्वारा की गइ कारा िाइ के बारे में के न्द्रीय सरकार को त्रैमाधसक ठरपोटा करे गा

17ड. अिधिक धनरीक्षण और मॉनीटर करना- के न्द्रीय सरकार िारा 17 के ईपबंिों को कायााधन्द्िि करने के धलए मॉनीटर करने िथा
धनरीक्षण की प्रणाली सृधजि करे गी, धजसमें धनम्नधलधखि सध‍मधलि होंगे (i)

ईन थथानों का धनरीक्षक द्वारा संचालन दकए जाने िाले अिधिक धनरीक्षण की संख्या, धजन पर बालकों के धनयोजन
प्रधिधषद्ध हैं और पठरसंकटमय व्यिसायों या प्रसंथकरण दकए जािे हैं;

(ii)

ऐसे ऄन्द्िरालों, धजन पर धनरीक्षक के न्द्रीय सरकार को खंड (i) ऄिीन धनरीक्षण की धिषय-िथिु से संबंधिि ईसको प्राप्त
हुइ धशकायिों िथा ित्पश्चाि् ईसके द्वारा की गइ कारा िाइ के ब्यररों की ठरपोटा करे गा;

(iii)

धनम्नधलधखि का आलेक्रॉधनक रूप से या ऄन्द्यथा ऄधभलेख का रखा जाना(क)

ऄधिधनयम के ईपबंिों का ईल्लंघन करने पर काया करिे हुए पाए गए बालक और कु मार, धजसमें ऐसे बालक भी
हैं जो आस ऄधिधनयम का ईल्लंघन करने पर कु टु ‍ब या कु टु ‍ब ईिमों में लगे हुए पाए जािे हैं;

(ख)

शमन दकए गए ऄपरािों की संख्या और ब्यररे ;

(ग)

ऄधिरोधपि और िसूल की गइ शमनकारी रकम के ब्यररे ; और

(घ)

ऄधिधनयम के ऄिीन बालकों और दकशोरों को प्रिान की गइ पुनिाास सेिाओं य के ब्यररे ”

10. मूल धनयम से संलग्न प्ररूप क के थिंभ 2 के शीषा में, “बालक का नाम” शब्िों के थथान पर “कु मार का नाम” शब्ि रखे जाएंगे
11. मूल धनयम से संलग्न प्ररूप ख के पश्चाि्, धनम्नधलधखि प्ररूप ऄन्द्िःथथाधपि दकया जाएगा, ऄथााि्:-

“प्ररूप ग
[धनयम 2इ(1)(ख) िेंखे]
बालक और कु मार श्रम
(प्रधिषेि और धिधनयमन) धनयम, 1988 के धनयम 2इ(1)(ख) के ऄिीन िचनबंि
मैं,.........................

िाधणध‍यक

अयोजन................................

का

श्रव्य

िृश्य

अयोजक............................ का ईत्पािक हं धजसमें धनम्नधलधखि बालक भाग ले रहे हैं, ऄथााि् :-

मीधडया

प्रथिुिीकरण

या

<!-- page 9 -->

II

9

(i)

रिय. सं.

बालकोबबालकों का नाम

मािा-धपिाबसंरक्षक का नाम

पिा

यह िचन िेिा हं दक.................................. अयोजन (अयोजन को धिधनर्दिि करें ) में उपर ईधल्लधखि बालकों के शाधमल
होने के िररान, बालक और कु मार श्रम (प्रधिषेि और धिधनयमन) ऄधिधनयम, 1986 (1986 का 61) और बालक और कु मार
श्रम (प्रधिषेि और धिधनयमन) धनयम, 1988 के दकसी ईपबंि का ईल्लंघन नहीं होगा और बालकों के शारीठरक और मानधसक
थिाथ्य िथा ऄन्द्य ऄपेक्षाओं य का पूरा ध्यान रखा जाएगा िादक ईसेबईन्द्हें कोइ ऄसुधििा न हो मैं यह भी िचन िेिा हं दक
अयोजन के िररान बालकों के संरक्षण, धजसके ऄन्द्िगाि ईनके धशक्षा के ऄधिकार, िेखभाल और संरक्षण, लैंधगक ऄपरािों के
धिरूद्ध धिधिक ईपबंि भी हैं, के धलए ित्समय प्रिृत्त लागू सभी धिधियों का ऄनुपालन दकया जाएगा

िारीख.....................

नाम और हथिाक्षर ”

[सं.ए-42025ब2ब2004-सीएल (खंड IV)]
राजीि ऄरोड़न ा, संयुि सधचि
ठटप्पणः मूल धनयम भारि के राजपत्र ऄसािारण, भाग II, खंड 3, ईप-खंड (i) में सा.का.धन. 847(ऄ) िारीख 10 ऄगथि, 1988 द्वारा
प्रकाधशि दकए गए थे

MINISTRY OF LABOUR AND EMPLOYMENT
NOTIFICATION
New Delhi, the 2nd June, 2017
G.S.R. 543 (E).—Whereas the draft of certain rules to amend the Child Labour (Prohibition and Regulation)
Rules, 1988 were published as required by sub-section (1) of Section 18 of the Child and Adolescent Labour (Prohibition
and Regulation) Act, 1986 (61 of 1986), in the notification of the Ministry of Labour and Employment number G.S.R.
392(E), dated the 20th April, 2017, in the Gazette of India, Extraordinary, Part II, section 3, sub-section (i), inviting
objections and suggestions from all persons likely to be affected thereby before the expiry of the period of thirty days
from the date on which the copies of the Official Gazette containing the said notification were made available to the
public;
And whereas the copies of the said Gazette were made available to the public on the 20 th April, 2017;
And whereas the objections and suggestions received from the public on the said draft rules have been
considered by the Central Government;
Now, therefore, in exercise of the powers conferred by section 18 of the Child and Adolescent Labour
(Prohibition and Regulation) Act, 1986 (61 of 1986), the Central Government hereby makes the following rules to amend
the Child Labour (Prohibition and Regulation) Rules, 1988, namely:1. (1) These rules may be called the Child Labour (Prohibition and Regulation) Amendment Rules, 2017.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Child Labour (Prohibition and Regulation) Rules, 1988 (hereinafter referred to as the principal rules), in rule 1,
in sub-rule (1), for the words ―Child Labour‖, the words ―Child and Adolescent Labour‖ shall be substituted.
3. In rule 2 of the principal rules, -(i)

for clauses (a) and (b), the following clauses shall be substituted, namely:-

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

(ii)

(iii)
(iv)

[PART II—SEC. 3(i)]

‗(a) ―Act‖ means the Child and Adolescent Labour (Prohibition and Regulation) Act, 1986 (61 of 1986);
(b) ―Committee‖ means the Technical Advisory Committee constituted under sub-section (1) of section 5 of the
Act;‘;
after clause (d), the following clauses shall be inserted, namely:‗(da) ―Fund‖ means the Child and Adolescent Rehabilitation Fund constituted under sub-section (1) of section
14B of the Act;
(db) ―Inspector‖ means the Inspector appointed by the Central Government under section 17;
(dc) ―Municipality‖ means an institution of self-Government constituted under article 243Q of the
Constitution;‘;
after clause (e), the following clause shall be inserted, namely:‗(ea) ―Panchayat‖ means a Panchayat constituted under article 243B of the Constitution;‘;
after clause (g), the following clause shall be inserted, namely:―(h) words and expressions used in these rules, but not defined therein and defined in the Act, shall have the
meanings as assigned to them in the Act.‖.

4. After rule 2 of the principal rules, the following rules shall be inserted, namely:‗2A. Awareness on prohibition of employment of child and adolescents in contravention to Act.- The Central
Government, to ensure that the children and adolescents are not employed or permitted to work in any occupation or
process in contravention to the provisions of the Act, through appropriate measures, shall –
(a) arrange public awareness campaigns using folk and traditional media and mass media including television,
radio, internet based application and the print media to make the general public, including the employers and the
children and adolescents who may be employed in contravention to the provisions of the Act, aware about the
provisions of the Act, and thereby discourage employers or other persons from engaging children and
adolescents in any occupation or process in contravention of the provisions of the Act;
(b) promote reporting of enterprises or instances of employment of children or adolescents in contravention to the
provisions of the Act, by developing and advertising easily accessible means of communication to authorities
specified by the Central Government;
(c) display to the possible extent the provisions of the Act, these rules and any other information relating thereto in
railway coaches, at railway stations, major bus stations, toll plazas, ports and port authorities, airports and other
public places including shopping centers, markets, cinema halls, hotels, hospitals, Panchayat offices, police
stations, resident welfare association offices, industrial areas, schools, educational institutions, court complexes,
and offices of all authorities authorised under the Act;
(d) promote through appropriate method the inclusion of the provisions of the Act in learning material and syllabus
in school education; and
(e) promote inclusion of training and sensitisation material on the provisions of the Act and the responsibilities of
various stakeholders thereto, in Central Labour Service, police, judicial and civil service academies, teachers
training and refresher courses and arrange sensitisation programmes for other relevant stakeholders including,
Panchayat members, doctors and concerned officials of the Government.
2B. Child to help his family without affecting education.- (1) Subject to the provisions of section 3, a child may,
without affecting his school education, in any manner, –
(a) help his family in his family enterprise, subject to the condition that such help, -(i)
shall not be in any hazardous occupation or process listed in Part A and Part B of the Schedule to the Act;
(ii)
shall not include work or occupation or process at any stage of the manufacturing, production, supply or
retail chain that is remunerative for the child or his family or the family enterprise;
(iii)
shall only be allowed to help in his family, or in a family enterprise, where his family is the occupier;
(iv)
shall not perform any tasks during school hours and between 7 p.m. and 8 a.m.;
(v)
shall not be engaged in such tasks of helping which hinders or interferes with the right to education of
the child, or his attendance in the school, or which may adversely affect his education including
activities which are inseparably associated to complete education such as homework or any extracurricular activity assigned to him by the school;
(vi)
shall not be engaged in any task continuously without rest which may make him tired and shall be
allowed to take rest to refresh his health and mind, and a child shall not help for more than three hours
excluding the period of rest in a day;

<!-- page 11 -->

II

(i)

11

(vii)

shall not include in anyway substitution of the child for an adult or adolescent while helping his family or
family enterprise; and
(viii)
shall not be in contravention to any other law for the time being in force;
(b) aid or assist his family in such manner which is not incidental to any occupation, work, profession, manufacture
or business, or for any payment or benefit to the child or any other person exercising control over the child, and
which is not detrimental to the growth, education and overall development of the child.
Explanation 1.- For the purposes of this rule, only –
(a) biological brother and sister of the child;
(b) brother or sister of the child through lawful adoption by parents of the child; and
(c) biological brother and sister of parents of the child,
shall be included for comprising the family of a child.
Explanation 2.- For the purposes of Explanation 1, it is hereby clarified that preliminarily, any doubt as to whether a
person is a biological brother or sister, may be removed by examining the pedigree of such person issued by the
concerned Municipality or Panchayat, as the case may be, or any other legal document issued by concerned authority of
the appropriate Government.
(2) Where a child receiving education in a school remains absent consecutively for thirty days without intimation to the
Principal or Head Master of the school, then, the Principal or Head Master shall report such absence to the concerned
nodal officer referred to in clause (i) of sub-rule (1) of rule 17C for information.
2C. Child to work as an artist.- (1) Subject to the provisions of section 3, a child may be allowed to work as an artist
subject to the following conditions, namely: –
(a) no child shall be allowed to work for more than five hours in a day, and for not more than three hours without
rest;
(b) any producer of any audio –visual media production or any commercial event involving the participation of a
child, shall involve a child in participation only after obtaining the permission from the District Magistrate of
the district where the activity is to be performed, and shall furnish to the District Magistrate before starting the
activity an undertaking in Form C and the list of child participants, consent of parents or guardian, as the case
may be, name of the individual from the production or event who shall be responsible for the safety and security
of the child, and ensure that all screening of his films and television programmes shall be made with a
disclaimer specifying that if any child has been engaged in the shooting, then, all the measures were taken to
ensure that there has been no abuse, neglect or exploitation of such child during the entire process of the
shooting;
(c) the undertaking referred to in clause (b) shall be valid for six months and shall clearly state the provisions for
education, safety, security and reporting of child abuse in consonance with the guidelines and protection policies
issued by the Central Government from time to time for such purpose including –
(i) ensuring facilities for physical and mental health of the child;
(ii) timely nutritional diet of the child;
(iii) safe, clean shelter with sufficient provisions for daily necessities; and
(iv) compliance to all laws applicable for the time being in force for the protection of children, including
their right to education, care and protection, and against sexual offences;
(d) appropriate facilities for education of the child to be arranged so as to ensure that there is no discontinuity from
his lessons in school and no child shall be allowed to work consecutively for more than twenty-seven days;
(e) one responsible person be appointed for maximum of five children for the production or event, so as to ensure
the protection, care and best interest of the child;
(f) at least twenty per cent, of the income earned by the child from the production or event to be directly deposited
in a fixed deposit account in a nationalised bank in the name of the child which may be credited to the child on
attaining majority; and
(g) no child shall be made to participate in any audio visual and sports activity including informal entertainment
activity against his will and consent.
(2) For the purposes of clause (c) to the Explanation to sub-section (2) of section 3, the expression ―such other activity‖
contained therein, shall mean –

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(i) any activity where the child himself is participating in a sports competition or event or training for such sports
competition or event;
(ii) cinema and documentary shows on television including reality shows, quiz shows, talent shows; radio and any
programme in or any other media;
(iii) drama serials;
(iv) participation as anchor of a show or events; and
(v) any other artistic performances which the Central Government permits in individual cases, which shall not
include street performance for monetary gain.‘.
5. After rule 15 of the principal rules, the following rule shall be inserted, namely:―15A. Hours of work.– Subject to the provisions of section 7, no adolescent shall be required or permitted to work in an
establishment in excess of such number of hours of work as is permissible under the law for the time being in force
regulating the hours of work of the adolescent in such establishment.‖.
6. In rule 16 of the principal rules, in sub-rule (1), for the word ―children‖, the word ―adolescents‖ shall be substituted.
7. After rule 16 of the principal rules, the following rule shall be inserted, namely:―16A. Payment of amount to child or adolescent from and out of Child and Adolescent Labour Rehabilitation
Fund.- (1) The amount credited, deposited or invested, as the case may be, under sub-section (3) of section 14B to the
Child and Adolescent Labour Rehabilitation Fund and the interest accrued on it, shall be paid to the child or adolescent in
whose favour such amount is credited in the following manner, namely:(i)

(ii)

(iii)

(iv)

the Inspector or the nodal officer having jurisdiction shall, under his supervision, ensure that an account of such
child or adolescent is opened in a nationalised bank and inform the bank in which the amount of the Fund is
deposited or, as the case may be, to the officer responsible to invest the amount of the Fund under sub-section
(3) of section 14B;
the interest accrued on the proportionate amount of the Fund in favour of the child or adolescent shall be
transferred every six months to the account of the child or adolescent, as the case may be, by the bank or officer
responsible to invest the amount under information to the Inspector;
when the concerned child or adolescent completes the age of eighteen years, then, as soon as may be possible
forthwith or within a period of three months, the total amount credited, deposited or invested in favour of the
child along with interest accrued thereon remaining in the bank or remaining so invested under sub-section (3)
of section 14B, shall be transferred to the said bank account of child or adolescent, as the case may be; and
the Inspector shall prepare a report of the amount transferred under clause (ii) and clause (iii) with particulars of
the concerned child or adolescent sufficient to identify him and send a copy of the report annually to the Central
Government for information.

(2) Any amount recovered by way of fine or for composition of offences in pursuance of an order or judgement of a
Court in favour of a child or adolescent for the contravention of the provisions of the Act, shall also be deposited in the
Fund and shall be spent in accordance with such order or judgement.‖.
8. For rule 17 of the principal rules, the following rule shall be substituted, namely:‗17. Certificate of age.- (1) Where an Inspector has an apprehension that any adolescent has been employed in any of the
occupation or processes in which he is prohibited to be employed under section 3A of the Act, he may require the
employer of such adolescent to produce to the Inspector a certificate of age from the appropriate medical authority.
(2) The appropriate medical authority shall, while examining an adolescent for issuing the certificate of age under subrule (1), take into account –
(i) the Aadhar card of the adolescent, and in the absence thereof;
(ii) the date of birth certificate from school or the matriculation or equivalent certificate from the concerned
examination Board of the adolescent, if available, and in the absence thereof;
(iii) the birth certificate of the adolescent given by a corporation or a municipal authority or a Panchayat;
and only in the absence of any of the methods specified in clauses (i) to (iii), the age shall be determined by such
medical authority through an ossification test or any other latest medical age determination test.

<!-- page 13 -->

II

(i)

13

(3) The ossification test or any other latest medical age determination test shall be conducted on the order of the
appropriate authority of the rank of Additional Labour Commissioner, as may be specified by the Central Government in
this behalf, and such determination shall be completed within fifteen days from the date of such order.
(4) The certificate of age referred to in sub-rule (1) shall be issued in Form B.
(5) The charges payable to the medical authority for the issue of the certificate of age shall be same as specified by the
Central Government or the State Government, as the case may be, for their Medical Boards.
(6) The charges payable to the medical authority shall be borne by the employer of the adolescent whose age is
determined under this rule.
Explanation.- For the purposes of this rule, –
(i)

(ii)

―medical authority‖ means a Government medical doctor not below the rank of an Assistant Surgeon of
a District or a regular doctor of equivalent rank employed in Employees‘ State Insurance dispensaries or
hospitals;
―adolescent‖ means an adolescent as defined in clause (i) of section 2 of the Act.‘.

9. After rule 17 of the principal rules, the following rules shall be inserted, namely:―17A. Persons who may file complaint.- Any person who may file a complaint under the Act for commission of any
offence include school teachers and representatives from school management committee, child protection committee,
Panchayat or Municipality, who shall be sensitised to file complaint, in the event that any of students in their respective
schools is employed in contravention to the provisions of the Act.
17B. Manner of compounding offences.- (1) An accused person,(i) who commits an offence for the first time under sub-section (3) of section 14; or
(ii) who being parent or a guardian, commits an offence under the said section,
may file an application to the District Magistrate having jurisdiction for compounding the offence under sub-section
(1) of section 14D.
(2) The District Magistrate shall after hearing the accused person and the Inspector concerned, on an application filed
under sub-rule (1), dispose of such application, and if the application is allowed, issue the certificate of compounding,
subject to –
(i)
(ii)

the payment of a sum of fifty per cent; of the maximum fine provided for such offence within a period to
be specified in such certificate; or
the payment of an additional sum of twenty-five per cent; of the maximum fine provided for such offence
together with the compounding amount specified under clause (i), if the accused person fails to pay the
compounding amount under the said clause within the specified period, and such delayed payment shall be
made within a further period as may be specified by the District Magistrate, which shall not exceed the
period specified in that clause.

(3) The compounding amount shall be paid by the accused person to the Central Government.
(4) If the accused person fails to pay the compounding amount under sub-rule (2), then, the proceeding shall be continued
as specified under sub-section (2) of section 14D.
17C. Duties of District Magistrate. - (1) The District Magistrate shall –
(i)

specify such officers subordinate to him, as he considers necessary, to be called nodal officers, who shall
exercise all or any of the powers and perform all or any of the duties of the District Magistrate conferred and
imposed on him by the Central Government under section 17A;

(ii)

assign such powers and duties, as he thinks appropriate, to a nodal officer to be exercised and performed by him
within his local limits of jurisdiction as subordinate officer;

(iii)

preside over as chairperson of the Task Force to be formed in a district consisting of –
(a) Inspector appointed under section 17 for the purposes of his local limits of jurisdiction;

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(b) Superintendent of Police for the purposes of his local limits of jurisdiction;
(c) Additional District Magistrate for the purposes of his local limits of jurisdiction;
(d) nodal officer referred to under clause (i) for the purposes of his local limits of jurisdiction;
(e) Assistant Labour Commissioner (Central) for the purposes of his local limits of jurisdiction;
(f) two representatives each from a voluntary organisation involved in rescue and rehabilitation of employed
children in the district on rotation basis for a period of two years;
(g) a representative of the District Legal Services Authority to be nominated by the District Judge;
(h) a member of the District Anti-trafficking Unit;
(i) Chairperson of the Child Welfare Committee of the District;
(j) District Child Protection Officer in the District under the Integrated Child Protection Scheme of the
Ministry of the Government of India dealing with women and child development;
(k) District Education Officer;
(l) any other person nominated by the District Magistrate;
(m) Secretary of the Task Force shall be any of the nodal officers referred to in clause (i) and nominated by the
Chairperson.
(2) The Task Force referred to in clause (iii) of sub-rule (1) shall meet at least once in every month and shall make a
comprehensive action plan for conducting the rescue operation, taking into account the time available, point of raid in
accordance with the law for the time being in force, confidentiality of the plan, protection of victims and witnesses and
the interim relief, in accordance with the guidelines for rescue and repatriation issued by the Central Government from
time to time; and the Task Force shall also cause to upload the minutes of such meeting on the portal created for such
purpose by the Central Government.
(3) In addition to the duties referred to in sub-rule (1), the District Magistrate shall ensure through nodal officers that the
children and adolescents who are employed in contravention of the provisions of the Act are rescued and shall be
rehabilitated –
(a) in accordance with the provisions of –
(i) the Juvenile Justice (Care and Protection of Children) Act, 2015 (2 of 2016) and the rules made there under;
(ii) the Bonded Labour System (Abolition) Act, 1976 (19 of 1976);
(iii) the Central Sector Scheme for Rehabilitation of Bonded Labourers, 2016;
(iv) any National Child Labour Project;
(v) any other law or scheme for the time being in force under which such children or adolescents may be
rehabilitated; and subject to (I) the directions, if any, of a court of competent jurisdiction;
(II) the guidelines for rescue and repatriation issued by the Central Government from time to time in this regard.
17D. Duties of Inspectors.- An Inspector appointed by the Central Government under section 17, for the purposes of
securing compliance with the provisions of the Act, shall –
(i) comply with the norms of inspection issued by the Central Government from time to time;
(ii) comply with the instructions issued by the Central Government from time to time for the purposes of securing
the compliance with the provisions of the Act; and
(iii) report the Central Government quarterly regarding the inspection made by him for the purposes of securing the
compliance with the provisions of the Act and the action taken by him for such purposes.
17E. Periodical inspection and monitoring.- The Central Government shall create a system of monitoring and
inspection for carrying into effect the provisions of section 17, which may include–
(i) the number of periodical inspection to be conducted by the Inspector of the places at which the employment of
children is prohibited and hazardous occupations or processes are carried out;
(ii) the intervals at which an Inspector shall report to the Central Government complaints received to him relating to
the subject matter of inspection under clause (i) and the details of action taken by him thereafter;

<!-- page 15 -->

II

15

(i)

(iii) maintenance of record electronically or otherwise of(a) children and adolescent found to be working in contravention of the provisions of the Act including
children who are found to be engaged in family or family enterprises in contravention of the Act;
(b) number and details of the offences compounded;
(c) details of compounding amount imposed and recovered; and
(d) details of rehabilitation services provided to children and adolescents under the Act.‖.
10. In Form A appended to the principal rules, in the heading of column 2, for the words ―Name of child‖, the words
―Name of adolescent‖ shall be substituted.
11. After Form B appended to the principal rules, the following Form shall be inserted, namely:-

―FORM C
[ See Rule 2C(1)(b)]
Undertaking under rule 2C(1)(b) of the
Child and Adolescent Labour (Prohibition and Regulation) Rules, 1988
I …………………………………………….. producer of …………………………………. an audio visual
media production or organiser of ……………………………………………………………. a commercial event,
involving the participation of the following child/children, namely:-

S.No.

Name of the Child/
Children

Parent‘s/Guardian‘s

Address

Name

do hereby undertake that in the course of the involvement of the above mentioned child/children in the event
………………………………………………………………..(specify the event), there shall be no violation of any of the
provisions of the Child and Adolescent Labour (Prohibition and Regulation) Act, 1986 (61 of 1986) and the Child and
Adolescent Labour (Prohibition and Regulation) Rules, 1988 and full care shall be taken of the physical and mental
health, and other requirements of the child/children, so that he/they feel no inconvenience. I also undertake that during
the event, all laws applicable for the time being in force for the protection of children, including their right to education,
care and protection, and legal provisions against sexual offences will be complied.
Dated:………………..

Name and signature of the Producer.‖.

[No.A-42025/2/2004-CL (Vol.IV)]
RAJEEV ARORA, Jt. Secy.
Note.- The principal rules were published in the Gazette of India, Extraordinary, Part II, section 3, sub-section (i) vide
G.S.R 847(E), dated the 10th August, 1988.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

ALOK KUMAR

Digitally signed by ALOK KUMAR
Date: 2017.06.05 16:25:58 +05'30'
