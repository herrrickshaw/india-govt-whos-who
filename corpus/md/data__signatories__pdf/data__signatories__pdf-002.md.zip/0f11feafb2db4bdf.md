---
doc_id: "0f11feafb2db4bdf"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/93dcdf2d5c81a26d2743396c0a931218.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum -Revised average annual turnover criteria for Selection of Creative Design Agency for Installation of a GI Product Exhibit"
date: "2025-07-01"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8d56ffca674f93f6"
---

<!-- page 1 -->

P-24039/238/2023-I
PR-IV
P-24039/238/2023-IPR-IV
3ITTc,
fF{c:fil{ /Government
/Government of
3TT(A q(wit
of India
India

& Industry
c:11fut,-ll 3-tr{
3c:\.Q)c11 iaia4
cl-i:>llc>lll /Ministry
afvlou
3ilt 32lam
/Ministry of
of Commerce
Commerce &
Industry
(3~,ll)cll
c"<:!NI'{ fm-lm)/
(3a<Mar ~ 3-ITT" 3-lic1~c:fi
3riaRa, <4rqlx
faana)/

iaaa 3ilc

(Department
(Department for
for Promotion
Promotion of
of Industry
Industry &
Internal Trade)
Trade)
& Internal
~
, ~"JTTcl1",
~ 3-tRM-cfiscfc.{
/I Patents,
Patents, Trade
Trade Mark,
Mark,
ma,, ~a~fc:lc:fi
alaiaa, iaa
3ilk diiimgact 3la1m
31man
qaeu,
'�
.:,
�
Geographical
Geographical Indication
Indication and
and Semi-Conductor
Semi-Conductor Section
Section
*kkk*
*****
110001
Vanijya
Vanijya Bhawan,
Bhawan, New
New Delhi
Delhi -- 110001
th
Dated: 22
22 April,
April, 2024
2024
Dated:

cs

CORRIGENDUM
Subject: - Revised
Revised average
average annual
annual turn-over
turn-over criteria
criteria for
for Selection
Selection of
of Creative
Creative Design
Design
Agency
a GI
GI Product
Product Exhibit
Exhibit reg.
reg.
Agency for
for Installation
Installation of
of a

With reference
to GEM Bid No.GEM/2024/8/4788699
No.GEM/2024/B/4788699 dated
dated 15.03.2024,
15.03.2024,
With
reference to
regarding Request
Request for
for Proposal
Proposal (RFP)
(RFP) for
for Selection
Selection of
of Creative
Creative Design
Design Agency
Agency for
for
regarding
a GI
GI Product
Product Exhibit"
Exhibit" at
at Yashobhoomi,
Yashobhoomi, IICC,
IICC, Dwarka,
Dwarka, Delhi,
Delhi, all
all
Installation
Installation of
of a
prospective
prospective bidders
bidders are
are hereby
hereby informed
informed that
that the
the minimum
minimum average
average annual
annual turnover
turnover
has been
been revised
revised..(Reduced
to ,f 5 Cr) along
along with
with other
other Technical
Technical evaluation
evaluation criteria.
criteria.
has
(Reduced to
The
The revised
revised Evaluation
Evaluation criteria
criteria is
is attached
attached (Annexure-I).
(Annexure-l).

Turnover
5 Crto
Cr to 10
Cr
~5
<10 Cr
<10
10 Cr
Cr to
to ~20
20 Cr
Cr
~20
20 Cr
Cr to
to ~30
30 Cr
Cr

Revised
Revised Minimum
Minimum Average
Average Annual
Annual Turnover
Turnover
Marks
Supporting Document
Marks
55 Marks
Copy of
of CA
CA Certificate
Certificate
Copy
10 Marks
Marks
10
15
15 Marks
Marks

~.�

(Arun
(Arun Kumar
Kumar Gupta)
Gupta)
Under Secretary
Secretary to
to the
the Govt
Govt of
of India
India
Under
Email
Email idid- ak.gupta38@nic.in
ak.gupta38@nic.in

<!-- page 2 -->

ANNEXURE-1
S.No

1.

Evaluation
Criteria
Evaluation Criteria

Creative Content
•• Innovative
O Marks
Innovative concepts - 110
•• Interactive Design
Design Elements - 10 Marks
•• Miniature model
model - 5 Marks

Max
Marks
Marks

Supporting Document

••
••

25

••
••

on similar Projects
Previous Experience on
Non-Government
Non-Government Clients
•• Three marks per project but maximum
maximum 5
projects will be
be considered.
15

22..

Government Clients
•• Four marks per project but maximum
maximum 5
projects will be considered
considered..

•

20
••

3.
3.

projects executed
executed
Scale of the projects
•• INR 40 Lakhs - 11 crore - 5 Marks
•• INR1Crore-1
.5crore-7Marks
INR 1 Crore -1.5
crore - 7 Marks
•• INR 1.5 Cr and above -- 10 Marks

10
10

Awards Won/ Appreciation
Appreciation
award,, but maximum
maximum
•• Three marks per award
marks 15.
15.

4.
4.

5.
5.

15
15

minimum average annual
Bidder Should have minimum
turnover: turnover:
•• Between 5 Cr to 10 Cr --- 5 Marks
•• Between 1
O Cr to 20 Cr --10 Marks
10
•• Between 20 Cr to 30 Cr ---15 Marks
Total

Original briefs to compare execution
against concept and
and objectives.
and
Multi-view designs
and threethree­
dimensional representation
representation of the
should also be
be submitted
submitted..
design should
A presentation on
on the design should
should
also be submitted
Only Completed works will be
considered
considered for evaluation. Projects
under production
production will not be
be
considered
considered for evaluation
evaluation.. In
In case of
campaign
campaign,, at least one deliverable
should
should have
have been
been completely
produced
produced and
and delivered
delivered in
in the past
three Financial
Financia l Years period.
Projects listed have to be supported
supported
Projects
by respective
Purchase
respective Work Orders/
Orders I Purchase
Orders I Email awarding
awarding work from
from
Invoices raised
raised by
Official ID's etc. Invoices
Agency shall
shall not be deemed as Work
Orders.
Above documents should
should clearly
mention scope of work,
mention
work, amount
allocated, and date when work is
awarded

Proof of scale of project by way of Work
need to be
order/Purchase Order need
submitted. Selection committee may
make exception for self-financed
self-financed projects
projects
make
provided
provided sufficient related
related documents are
furnished by the agency as suooortino.
supporting.
•• Awards
should
be
from
be
State/Nationally/Internationally
recognized
recognized bodies or relevant
industry association/committee.
•• As a proof, official
official certificate or
citation received
received by the agency would
need
need to be
be submitted. The award
award
maybe in the name of the agency or
maybe
the Head/Representative of the
agency. Certificates of Participation
Participation
will
not
be
deemed
as
Awards/Appreciation letters
letters
Copy of CA Certificate

15

100
