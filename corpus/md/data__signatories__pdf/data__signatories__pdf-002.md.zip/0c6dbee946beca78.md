---
doc_id: "0c6dbee946beca78"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/2b3e404e70f49e07c7f2067432ae0970.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Guidelines for NGO Involvement under National Health Mission in the Twelfth Five Year Plan"
date: "2025-12-11"
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3df980a19900186f"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

Table of Contents
I.

Background

1

II.

Framework 

3

III. Structure 

9

IV.

Financial Structure 

15

V.

Selection of NGOs

17

<!-- page 6 -->

<!-- page 7 -->

I. Background

1.1

1.2

In the Ninth Five Year Plan (1997-2002), the
Department of Family Welfare introduced the
Mother NGO scheme under the Reproductive
and Child Health (RCH) Programme. Under
the scheme, grants were sanctioned to
NGOs called Mother NGOs (MNGOs)in
allocated districts, who in turn issued grants
to small NGOs called Field NGOs (FNGOs),
in the districts. The broad objectives of the
MNGO scheme were a) addressing the gaps
in information on RCH services in the project
area, b) building institutional capacity at the
State, district/field level, c)advocacy and d)
awareness generation.
The selection of organizations in the MNGO
scheme was formalized through detailed
guidelines issued by the Government of India
(GOI) in 2003 which predate the design and
launch of National Rural Health Mission
(NRHM). Although several clarificatory
amendments to the guidelines were issued,
repeated evaluations of the scheme revealed
that while the scheme had the potential to
reach the vulnerable and marginalized, several
limitations of the design elements, including
limited decentralization, transparency in the
selection of NGOs, lack of clarity in the roles
and responsibilities of the participating NGOs,
complicated programmatic and financial
guidelines, and delays in fund releases, had
limited the effectiveness of the scheme.After
the MNGO scheme was decentralized from

2008-09 onwards, the Ministry of Health and
Family Welfare through its NGO Division has
been providing grant-in-aid to 10 Regional
Resource Centers , which are National Level
NGOs working for capacity building of NGOs
in the States.
1.3

The National Rural Health Mission (NRHM) was
launched in April 2005.The NRHM Framework
for Implementation1 encourages partnerships
with Non-Governmental Organizations to
improve the effectiveness of implementation
and to make health services and facilities
accountable to citizens. The Mission provides
for collaboration with voluntary groups/
organizations for advocacy, building capacity at
all levels, monitoring and evaluation, delivery
of health services and working together with
community based organizations. The NRHM
implementation framework provisions about
5% of the total NRHM outlay as the resource
allocation to the voluntary sector2. Such an
allocation provided an opportunity to build
NGO capacity and leverage community linkages
to develop/strengthen people’s organization for
more active participation in enabling improved
health outcomes, especially for the poor and
marginalized.

1.4

NGOs have played a significant role in shaping
the design of NRHM and in championing

1
2

Reference: Framework of implementation NRHM
As defined in Para 2.1

<!-- page 8 -->

2

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

in the high priority districts and NGOs
could bring in additional human resources,
especially in the areas where community
involvement is required. Given the low
density with which skilled professional
service providers are available, many
tasks of the department remain undone
merely because the system cannot spare
professionals for tasks like community
mobilization, training Panchayati Raj
Institution (PRI) members and Village
Health Sanitation and Nutrition Committee
(VHSNC) members, or training, supporting
and supervising Accredited Social Health
Activists (ASHAs) or for initiating
Behaviour Change Communication (BCC)
programmes in schools.

its implementation. They have consistently
expressed eagerness to participate in
strengthening public health systems, instead
of becoming parallel to it. There is now,
sufficient experience across the country to
show that NGOs can take on a variety of roles
beyond awareness generation and community
mobilization and undertaking service delivery
in specific situations. There are NGOs that
can work to leverage and support the health
department in terms of human resources,
developments of skills and provision of
technical assistance.Though some States have
made considerable use of NGO capacity, this
has neither been consistent and widespread
enough, nor is it focused in the districts where
it is needed the most.
1.5

1.6

It is important to revitalize the NGO
Partnership in the 12th Five Year Plan keeping
in mind the potential for broadening the scope
of NGO involvement so as to accelerate the
achievement of public health goals.The context
of the scheme has also changed. The National
Health Mission announced in 2012, which
encompasses NRHM including RCH and the
National Urban Health Mission as its two SubMissions, anticipates a much larger and wider
set of roles for NGOs.
The rationale for NGO participation in NHM
include following:
a. There is a need for the participation of all
those sections that have a commitment
to the principle of universal access to
quality health care. The task is too big for
the department alone and anyone who
wants to meaningfully participate must be
provided the space to do so.
b. As a part of national commitment
to inclusive growth, we must make
special efforts to reach out to poor
and marginalized sections of the rural
and urban population. Many NGOs
have formed and structured themselves
explicitly to address such a goal.
c. Human resources and capacity within
the department are limited particularly

d. There is a need for innovation, fresh
ideas and many different perspectives
to inform the process of health planning
and programme implementation. There
are today a number of NGOs who have
built up technical capacity and professional
public health experience which the
government acknowledges and seeks to
tap for enhancing outcomes.
1.7

Past experience of NGO schemes at the State
and National Level suggests that there is a
need of flexibility to suit NGO competencies
and State contexts. There is also clarity on the
measurable outcomes that are expected to be
delivered and adequate financial packages to
enable achievement of these outcomes. There
is also a need of well-designed monitoring
and evaluation framework to assess the
achievements. Mentoring and technical support
as per need to enhance NGO capacities
to deliver the expected outcomes is also
required. In particular, with the continuing
focus on community engagement in NHM, the
need for NGO participation is much higher
than it has been ever before. Therefore, there
is a wider scope for NGO involvement and
consequently the need for revised guidelines
for the NGO participation under NHM. These
operational guidelines are intended to provide
a broad framework to the States to engage
with NGOs and facilitate their participation in
a seamless manner.

<!-- page 9 -->

II. Broad
Framework
for NGO
Involvement
under NHM
Key Features of the Revised
Guidelines
2.1

For the purpose of this document, the term
NGO means “not for profit organizations
registered as a Trust or a Society”. There are
several players with in the “ for profit” sector
ranging from individual private providers
(untrained and trained), private nursing homes
and private teaching hospitals, as well as
organizations established by corporate bodies
(as part of Corporate Social Responsibility)
that could play the roles set out in these
guidelines. However, the mechanisms and
guidelines for engaging such agencies are not
covered in this document.

2.2

The scope of work for the NGOs is envisaged to
move beyond reproductive and child health to
a more comprehensive approach which would
include community level interventions under
NRHM, NUHM, Communicable Diseases, Non
Communicable Diseases and other emerging
issues.

2.3

The Ministry of Health and Family Welfare
(MOHFW), Government of India would
provide policy guidance and technical support.
Support to NGOs functioning at state and
district level would be routed through the
Programme Implementation Plan (PIP) of the
state.

2.3

At the National level, an NGO Support
Resource Centre (NSRC) housed within the
existing National Health Systems Resource
Centre would provide policy and technical
inputs to GOI and state and technical assistance
to the RRC/NSO at the state level. State and
District Health Societies will be required to
play a more active role. The NRHM guidelines
to utilize upto 5% of the total NRHM funds as
Grants-in-aid to NGOs would be maintained /
continue to apply for NHM Funds.

2.4

Effective NGO participation requires capacity
building and on-site mentoring of NGOs
along with experience sharing workshops
and documentation of best practices in NGO
led interventions. In the earlier phase of the
programme the Regional Resource Centers
(RRCs) played this role. At present, Grant-inaid is provided directly to these RRCs by GOI.
The funding for these RRCs would also be
through the State PIP route and not directly
to the RRC as was the case hitherto. States
which do not have RRCs, or which do not wish
to continue with the existing RRCs, may set up
or house NGO Support Organization(NSO) –
one per State to provide technical assistance to
the NGOs at the State/district level. In larger
States (with more than 30 districts), the NSO
could have a larger team to ensure high quality
support. NSOs need to instituted as per

<!-- page 10 -->

4

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

State’s priorities and at the State’s discretion.
The NSO may be selected by the Grants-inAid Committee at the state level in order to
enable State ownership and to ensure that
planning and support for NGO interventions
is synergized with State and district specific
priorities.
2.5

through various divisions at the Center for
NGO interventions to support policy inputs
and avoid duplication of efforts and funding
between different divisions.
2.7

NGOs with the required level of competence
would be selected by the States to work at the
State and District levels. For some activities,
the entire district can be covered and for
others the district can identify the blocks for
NGO support and prioritize the engagement
of NGOs in those blocks.

2.8

Selection of NSO and NGOs may follow the
process outlined in Section IV. At the district
level, the NGOs could be divided into two
types based on function as follows:

The revised framework for the Implementation
of NHM envisages that programme funds will
be administered through the following five
Flexipools envisaged in NHM:
a. NRHM and RCH flexi pools funds.
b. NUHM Flexipool
c. Flexible pool for Communicable Diseases
d. Flexible pool for Non Communicable
Diseases, Injury and Trauma

yy Field NGOs (FNGOs) – NGOs which
would carry out the activities like
training and capacity building, community
monitoring, advocacy and community
mobilization, planning, etc.

e. Infrastructure Maintenance.
2.5

2.6

NGO interventions under the four Flexipools
would be routed through the state State
Programme Implementation Plans (PIPs). The
funds requirement for the RRC/NSO as well
as the NGOs at the State level and district
levels would be reflected in the four flexi
pools of the NHM. For interventions under
the Communicable diseases and certain NonCommunicable Diseases such as the National
Programme for Control of Blindness (NPCB),
the respective programme divisions have
formulated their own guidelines articulating
the system of approval, selection, fund release
monitoring and evaluation etc. which would
continue to apply. In the case of new emerging
programmes like tobacco control, mental health,
control of cancer, diabetes cardiovascular
diseases and stroke, the guidelines for
NGO involvement may be developed by the
concerned programme divisions.
The reporting of NGO interventions under the
various flexipools would be to the respective
divisions at the State level. These divisions at
the State level would in turn report to the
divisions at the Central level.The NGO division
at the Ministry would maintain a centralized
database for the funds allocated and released

yy Service NGOs (SNGOs) – NGOs which
would focus on service delivery especially
in un-served and underserved areas.
2.9

Clear cut output/performance indicators for
NGOs should be identified and indicated in
the Memorandum of Understanding (MoU)
signed between the State/District health
societies with the NGO laying down the tasks
to be performed by the NGOs. The MoU
should also include performance indicators
on the financial parameters like submission
of Utilization Certificates (UCs), audited bank
statements etc. For example, in case of service
NGOs running a health facility; utilization rates,
and increase in OPD attendance etc. could
be measurable output indicators. In case of
Field NGOs engaged for capacity building and
training of PRIs, VHSNC members, the output
indicators could include the number of batches
taken up for training, the number of persons
trained, pre and post training level of knowledge
of the trainees etc. These indicators must be
specific and measurable to evaluate the task
to be performed by the NGO. The agreement/
MoU with the NGO should elaborate upon

<!-- page 11 -->

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

the resources extended by the districts, State
and NSO.
2.10 Periodic reviews and external evaluations will
be undertaken by the state to assess progress
in accordance with the terms outlined in the
MOUs. The state could seek support from
the NGO Support Resource Center (NSRC)
at the central level or academic and research
bodies at state or national levels in undertaking
reviews and evaluations.

Role of NGOs
2.11 As health is a State subject and decentralization
is a priority under NHM the States may identify
priority areas for partnerships with NGOs
according to the State’s priorities. Further,
different NGOs have a range of capabilities and
areas of expertise and thus the areas for NGO
involvement also need to be broad. NGOs
could be effectively involved in training, service
delivery, supportive supervision and monitoring
advocacy, research and innovations in Maternal
Health, Child Health – including Immunization
and Newborn Care, Sexual and Reproductive
Health, Adolescent health including School
Health, Malnutrition
including
anemia,
Communicable and Non Communicable
diseases, Declining sex ratio and Inter-sectoral
Convergence.
2.12 NGOs could be supported to get involved in
capacity building and community processes
(the VHSNC, the ASHA programme, public
participation in the RKS, public participation in
district planning and in community monitoring).
The element of community monitoring could
be further expanded in areas such as improving
data quality in HMIS and MCTS, measuring
availability of drugs, and monitoring support to
JSSK.
2.13 NGOs could be supported to work in special
cases such as districts affected by Left Wing
Extremism disaster prone areas etc.

5

2.14 NGOs could also be involved for
supplementing capacities in some key areas
of high priority and where they have interest,
but where medical professionals are unable
to give continued attention. Examples include
the monitoring of Pre-Conception and PreNatal Diagnostic Techniques (PCPNDT)
Act PCPNDT implementation, assessing
environmental health impact, monitoring of
food and drug adulteration, and promotion of
rational drug use – amongst the population and
also professionals.
2.15 Community monitoring which emerged as
a viable strategy in the Eleventh Plan needs
to be built upon and scaled up. VHSNCs, PRI
members and Self Help Groups (SHGs) should
develop the capacity to undertake community
monitoring and social audits. This is one area
where NGOs can play an important role in
capacity building and support.
2.16 NGOs could also be supported to undertake
service delivery in un-served and underserved
areas through managing health facilities such as
Primary Health Center (PHC), First Referral
Unit (FRU) and Mobile Medical Units. (MMUs).
Un-served and underserved areas are those
that are remote, inaccessible/hard to reach
such as tribal, hilly, and desert areas or areas
that do not have access to existing government
health infrastructure like peri-urban areas. The
State and District Health Society have the
flexibility to categorize areas as un-served or
underserved for focused attention.
2.17 NGOs can be effectively engaged in addressing
social determinants of health such as nutrition,
water and sanitation and convergence with
schemes for women empowerment and
poverty alleviation.
2.18 Given the needs of the XII Plan and the move
towards Universal Health Coverage, there
are several areas, particularly in approaches
to community health intervention for which
evidence needs to be build. NGOs would be
supported to undertake innovations in order
to test approaches and gather such evidence.

<!-- page 12 -->

6

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

2.19 The roles and theme areas for NGO
involvement discussed above are illustrative
and the States may further determine and
define the role of NGOs as per their priorities.
While reflecting the fund allocation for NGOs
in the State PIP the role of the NGOs would
also be defined by the State.

Duration of a Project Assigned to
an NGO
2.20 Duration of the project will be decided by the
State based on the activity for which the NGO
is selected. The duration will vary according to
the intervention for which the NGO is funded
and should be reflected in the state PIP. In
case of Service NGOs the suggested average
project duration may be fixed for three years.

Monitoring,
Reporting

Evaluation

and

2.21 A monitoring and evaluation system is essential
for effective, participatory and periodic
monitoring of NGOs based on local situation
and priorities. A system of periodic reporting,
review, and ongoing monitoring will be
instituted for tracking NGO performance. This
will enable the NGOs to make mid-course
corrections, if required, based on the findings
of the review. It will also ensure that the State’s
priorities and the goals of the project are being
met. The monitoring and evaluation system
proposed is as follows:
yy The performance of the NGO would be
monitored on the basis of agreed indicators,
which would be clearly mentioned in the
MoU signed between the NGO and the
State government. These indicators should
be relevant and specific to the work
undertaken by the NGO and not be longterm impact indicators like reduction in
IMR, MMR etc. that are affected by several
other factors.
yy Depending upon the level of functioning,
the NGO will submit a detailed report
of its activities in the prescribed format

(financial and physical) to the State Nodal
Officer / Mission Director or the Chief
Medical Officer (CMO) of the district
through the designated NGO Coordinator
(quarterly for narrative and monthly for
financial) with a copy endorsed to the
NSO/RRC. The NGO Coordinator/CMO
would give their suggestions and guidance
after examining the report.
yy Quarterly Review meetings will be held at
state / district level (as applicable) involving
NGOs, State Nodal Person / Mission
Director at State level, District Collector /
CMO at district level, NGO Coordinator
and the NSO/RRC. The District Collector
will chair these review meetings. At the
meeting, the NGO will report on progress
as well as constraints faced in the field.
These meetings will serve as a forum
for discussing any problems faced by the
NGOs in the project implementation,
the inputs and support required from the
government machinery etc.
yy The State would commission external
evaluations as and when required to
review, study and improve the programme.
The State NGO Coordinator would
be empowered to conduct external
evaluation of state and district level NGOs
of upto 5% NGOs, selected on a random
basis. These evaluations could also include
the performance indicators agreed upon
at the time of signing the MoU with the
NGO. However, it should be ensured
that the same NGOs are not subjected
to repeated, multiple evaluations unless
there is a specific reason for doing so. The
Terms of Reference for Monitoring and
evaluation (M&E) should be developed
with NGO participation, as far as possible.
NGOs should have the opportunity to
provide feedback for M&E processes and
reports.
yy Monitoring of community based NGO
activities should be undertaken by teams
which have both the competence and
experience in implementing community
based interventions.

<!-- page 13 -->

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

2.22 The suggested frequency of monitoring of
performance of NGOs at various levels is as
under:
Levels
NSO
Field NGO
SNGO

Monitored by whom
SHS, with technical inputs from the
NGO Support Resource Centre
DHS, NSO/RRC
DHS, NSO/RRC

System of Grievance Redressal
2.23 An effective grievance redressal system will be
instituted at the state level so that NGOs can get
a fair hearing in case on non- selection and or
termination.

Frequency
Annual
Bi-annual
Bi-annual

7

<!-- page 14 -->

8

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

<!-- page 15 -->

III. Structure
of the NGO
Scheme

concerned technical divisions in NHSRC
would be utilized for mentoring and
training of NGOs and NSOs. The NSRC
would also facilitate linkages of the NSOs/
RRCs and NGOs and other national state
policies and programs. Capacity building of
NSOs and NGOs for qualitative research
and process documentation through
collaboration with research organizations
will be undertaken. In addition, the
expertise of the National Institute of
Health and Family Welfare (NIHFW), as
required for training and capacity building
would also be employed.

The proposed structure is a three-tier system
extending from the district to the national level. The
structure, function and constituency at each tier are
given in the following sections.

National Level:
3.1

The role of the GOI/ MOHFW would be
one of policy guidance and financing of NGO
activities in the State through the State PIP.

3.2

The NGO division will be a part of the National
Programme Management Unit (NPMU) and
would provide support to the states as and
when required. The NGO division would be
strengthened to maintain a centralized database
of NGO Schemes under various programme
divisions within the Ministry of Health and
Family Welfare (MOHFW).

3.3

The NGO Support Resource Center would
be set up within National Health Systems
Resource Center (NHSRC) to function as
the technical arm of the NGO division. It
would provide technical support to NGOs,
coordinate and forge country wide linkages to
NGO assisted interventions, develop capacity
of, mentor and monitor NGOs.
yy The NHSRC would be adequately staffed
for performing the functions of NSRC.The

yy The NSRC will be responsible in
identifying areas where innovations are
needed and will provide technical support
to NGOs in implementing, evaluating and
documenting such innovations. Funding for
such innovations could be routed through
the NSOs or directly to implementing
organizations in the field through state
PIPs.
3.4

The Advisory Group for Community Action
(AGCA) has been established for supporting
the process of community based planning and
monitoring through NGOs. The NSRC would
work with the AGCA to ensure that the
selection, capacity building and monitoring are
in synergy.

<!-- page 16 -->

10

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

State Level

1. State Health Secretary/Commissioner
Health Services

3.5

2. Mission Director, NRHM

The organizational structure proposed at the
State level is as follows:

3. Lead NGOs/Institutions

yy State Grants in Aid Committee

4. Head of RRC/NSO

yy State Advisory Group

5. Representatives of 1-2 district NGOs
(depending on the size of the State)
nominated by the districts by rotation

yy State NGO Cell (SNGOC) / Coordinator
yy NGO Support Organization (NSO/RRC).

6. Director, SIHFW

States Grants in Aid Committee
(SGIAC)
3.6

3.7

The State Grants in Aid Committee (SGIAC)
would select the NSOand NGOs to work at
the state and district levels, including for such
activities such as training, evaluations and
innovations.
The proposed constitution of committee is as
follows:

8. State NGO Coordinator would act as the
Convener for this group.
3.9

The roles and responsibilities of the SAG
would include:
yy Overall guidance to the NGO programs
under NRHM in the State
yy Review of performance of State and
District level NGOs

yy State Health Secretary

yy Review the work of the NSO/ RRC.

yy Mission Director NRHM

yy Assist regular Monitoring and Evaluation
of the NGO led programmes.

yy Director SIHFW
yy Representatives of two State level NGOs
nominated by the State Health Secretary
yy State NGO Coordinator
yy RRC/NSO Project Director (except
when selection for RRC/NSO is under
consideration of State GIAC).
yy Regional Director of MoHFW.
yy When the state is in the process of
selection of the NSO/RRC the state GIAC
will include a representative of the NSRC
and the MOHFW.

State Advisory Group
3.8

7. Director, SHSRC

The State Advisory Group (SAG) would be the
body at the State level to guide, support and
advise the programme and would be housed
within the NSO. The SAG would be chaired
by the State Health Secretary. The SAG would
consist of the following official and non-official
member:

yy Internal and external evaluation of the
NGO led programmes after completion
of one year
yy Share views and experiences with all
stakeholders in the State and National
advisory group
yy Adapt guidelines for NGO participation in
the context of the State's requirement.

State NGO Cell
3.10 The State NGO cell will be the located within
the State Programme Management Unit. The
State NGO cell will be responsible for fund
release to the NGOs and administration of
the NGO led programmes in the State. It will
monitor and evaluate the NGO programmes
under NRHM in the State, and Coordinate
with the NGO division, NSRC at the Centre
and with the NSO/ RRC of the State.

<!-- page 17 -->

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

3.11 The proposed State NGO cell staffing is as
follows:
yy State NGO Coordinator-1
yy Programme Assistant- 1-2
yy Data Assistant - 1
yy Finance Assistant - 1
3.12 A full time State NGO coordinator will head the
State NGO Cell. The State NGO Coordinator
may be placed on deputation from the State
government or hired on contractual basis from
the open market.
3.13 In States where the required quantum of
support for NGOs is low, the State could in
initial phase appoint a State NGO coordinator
with 1-2 assistants to manage the program
rather than establish a NGO cell and then
gradually expand as the NGO program scales
up.
3.14 The functions of State NGO Cell will be:
yy Support the RRC/NSO and District Health
Society (DHS) for the management of the
NGO schemes.
yy Work closely with the State Health Society
and DHS, and communicating government
policies to NGOs.
yy Coordinate with the programme officers
of various health programmes to facilitate
interface between the NGOs and the
State health department.
yy Enable periodic field visits, developing
terms of reference and participating in the
evaluations, ensuring timely submission
of reports by the NGOs, timely release
of funds and maintaining the necessary
records.
yy Function as the coordination point
between the NSO and the NGO and
other technical resource institutes for
meeting the technical needs of the NGOs
under the scheme and sharing monitoring
reports with the NSO.

11

yy The State NGO Coordinator will be the
Member Secretary of the State Grants in
Aid Committee.
yy Facilitate signing of MoU between NGOs
and State Health Society
yy The State Coordinator will undertake
external evaluation of upto 5% of the
NGOs working in the State under the
scheme on a randomized sample basis.

RRC/ NSO
3.15 The RRC/NSO would be responsible for
capacity building of the NGOs in the State.
They would also be responsible for maintaining
a list of master trainers, adaptation of training
modules to State requirements/language,
training of trainers in the State and /district
level, and monitoring and evaluation.
3.16 The main role of the NSO is to provide
technical support and assistance to the NGO
Programme. The NSO will be collocated/work
in close collaboration with the State Health
Systems Resource Centers / ASHA Resource
Centers.
3.17 Key functions of the NSO include:
a. Support the state in field appraisal and
selection of NGOs at district levels.
b. Serve as the secretariat for the State
Advisory Group
c. Develop a data base of NGOs in the state
that could participate in the programme
d. Build capacity of district NGOs to manage
interventions
e. Develop training and communication
material as needed.
f.

Build up systems for monitoring and
periodic evaluation of NGO performance
vis-a-vis the objectives set for the
programme.

g. Ensure that participating NGOs at state and
district levels in other programmes(skill
building, service, delivery, advocacy/social

<!-- page 18 -->

12

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

mobilization, and certification/quality
monitoring) have access to standardized
protocols, guidelines, and standards and
are closely linked to the respective public
sector programs in the particular area of
implementation.
h. Serve as a center for conducting research
and documentation of best practices.
i.

j.

Could serve as a laboratory for
demonstrating best practices and
innovations and serve as learning and
training center.
Support advocacy efforts and liaison with
other such agencies at state and district
level.

k. Organize review workshops, experience
sharing
workshops
and
thematic
workshops at state and district levels,
based on emerging needs.
l.

Support the state in development of PIPs.

m. Participate in National level activities as
appropriate
3.18 In addition to supporting the NGO Programme,
the RRC/NSO, may be entrusted by the State
government with providing technical assistance
to other community based programmes under
NRHM or with the State government as it has
the capacity to manage. States may provide
separate funding to RRC/NSOs for taking up
additional works.This decision may be made by
the State based on the capacity and quality of
leadership available with the RRC/NSO.
3.19 The RRC/ NSO maybe selected with the
understanding that it would serve the period
of the NHM (in the 12th Plan) but be subject
to annual appraisal. Its performance would be
appraised annually based on its reports and
based on feedback from the Mission Director
of the State Health Society. Its continuation
would be subject to its performance being
found satisfactory on the annual appraisal. The
criteria for annual appraisal would be provided
to both the State and the NSO at the time
of signing the MoU. All NSOs will undergo a
midterm review commissioned by the NSRC.

3.20 The selection of the RRC/NSO would be
done by the State GIAC. There are already
existing RRCs/NSOs which could be included
in the program after an appraisal of their
effectiveness. New NSO would be selected in
the states that currently do not have RRCs.
The selection process includes the invitation by
advertisement, desk review to shortlist using a
scoring system and a field appraisal. Details on
selection of NGOs can be seen in Section IV.
3.21 NSOs will have the following personnel:
1. NSO Coordinator - 1
2. Training Coordinator -1
3. Community
Processes
Coordinator – 2

and

M&E

4. IT Assistant - 1
5. Finance and Administrative Assistant -1
3.22 RRCs/NSOs with the necessary competence
could be provided with implementation grants
(i.e serve as an FNGO or SNGO) but this
cannot exceed more than two projects whose
intent primarily is to serve as demonstration of
best practice.

District Level
3.23 The organizational structure proposed at the
District level is as follows:
yy District NGO Committee
yy District NGO Coordinator
yy Field NGO
yy Service NGO

District NGO Committee
3.24 The District NGO Committee would be
constituted within the District Health Society
and will be responsible for selection of NGOs
in the district. The members of the committee
would include:

<!-- page 19 -->

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

yy District Collector or his nominee
yy CMO of the District
yy One CHC in-charge
yy District Social Welfare Officer (in charge
of WCD)
yy Representative of the NSO/RRC

13

as the District NGO Coordinator.
3.28 The key functions of the District NGO
coordinator would be as follows:
yy Implementation of NGO Program in the
district.

yy District Programme Manager

yy Selection of NGOs as a member of
District NGO Committee.

yy District NGO Coordinator will be the
Member Secretary

yy Coordination of activities of NGOs in the
district.

yy State NGO Coordinator may be included
as a special invitee

yy Facilitation of the advertisement for the
selection of NGOs.

yy Representatives of two reputed State
NGOs nominated by the Mission Director
(NRHM)

yy Undertaking desk review of all the
applications and informing all the applicants
about the status of their applications.

3.25 District level NGO selection will be undertaken
for activities to be conducted at the district or
block level.These could include ASHA trainings,
VHSNC trainings, supportive supervision, IEC
in a district specific issue and orientation of
district staff on social determinants. Technical
support for district level NGO selection and
for the functions of district NGOs will be
provided by the NSO.

yy Ensuring timely fund disbursal to NGOs
and collection of Utilization Certificates.

3.26 The key functions of the District NGO
Committee will be:
yy Selection of district level NGOs.
yy Facilitation of the signing of MoU between
the NGO and the District Health Society.
yy Conduct review meetings to assess
performance of NGOs.
yy Facilitate training programmes by NGOs
and keep the State Health Society
informed about the selection and release
of funds to NGO.

District NGO Coordinator
3.27 A District NGO coordinator would be
nominated by the DHS for the implementation
of NGO programmes at the district/block level.
A district level Medical Officer or the District
Programme Manager (DPM) may be designated

yy Suggesting corrective action to NGOs on
the basis of their activity reports.
yy Monitoring of NGOs performance to
enable needs based technical support and
to make recommendtion on continuation
of grants.
yy Ensuring adequate supplies to NGOs.
yy Ensuring close collaboration between
NGOs and all health related programmes
yy Coordination with the RRC/NSO to
ensure that training and technical support
provided commensurate with programme
requirement
yy Coordination of programmatic and
financial reporting to State and Centre.
3.29 At the district level, the NGOs would be
divided into two types based on function as
follows:
yy Field NGOs (FNGOs) – NGOs which
would carry out any of the activities listed
in –2.11 to 2.18.
yy Service NGOs (SNGOs) – NGOs which
would focus on service delivery especially
in un-served and underserved areasrunning PHC, FRU, MMU etc.

<!-- page 20 -->

14

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

Field NGO (FNGO)
3.30 These NGOs will be selected to carry out
interventions at the district and sub-district
level. Activities like community monitoring,
capacity building of PRIs, VHSNCs, etc. would
be carried out by FNGOs. They can undertake
work in the entire district or a part of it
depending upon the capacity and requirement.

Service NGO (SNGO)
3.31 These are NGOs with proven capacity to
deliver services in identified un-served and
underserved areas based on requirements of
the district.
3.32 The following are the guidelines specific to
Service NGOs:
yy Not more than 40% of the funds proposed
by the State in their PIP for NGOs may be
allocated for SNGOs.
yy The scale of funding depends on the nature
and scale of intervention proposed.
yy Charitable institutions and also hospitals

running on a not-for-profit basis may be
included under Service NGOs.
yy If the state selects an NGO to manage a
PHC, then all Sub Centers under the PHC
should also be allocated to that NGO
yy For Service provision the plan should be
to run government infrastructure through
government functionaries in the long term.
If a State wants to run a government facility
through SNGO then NRHM will support
this on a reducing balance basis.
yy NGOs providing services through their
own establishments, in areas where
government services are not available, will
be fully funded depending on the project
cost.

<!-- page 21 -->

IV. Financial
Structure

4.1

Laying down robust, efficient, transparent and
timely processes for selection, supervision and
payment is the cornerstone of good NGO
policy. Hitherto NGO schemes have been
constrained by problems in the selection,
supervision and prompt and dignified payment
to NGOs. Poor governance issues that affect
these processes, over time lead to weakening
the entire nongovernmental sector.

4.2

Upto5% of the total NHM funds should be
earmarked for NGO involvement.

4.3

Funds required for the RRC/NSO and for
NGOs at the State and district levels would
be reflected under the respective flexipools of
the Annual Programme Implementation Plans
submitted by states for NHM.

4.4

The flow of funds will be from the NHM flexi
pools to the State Health Society. The State
Health Society will release funds to the district,
which in turn will release funds to the District
Health Society, which in turn will release it to
the NGOs. For NGOs that are funded to State
level activities, funds will flow from SHS to
NGOs directly.

4.5

After the issue of sanction letter and signed
MoU, the District Health Society will release
grant to the NGOs. The State Health Society

and the District Health Society will together
ensure that fund releases to the NGOs are
timely and adequate. The funding in a district
may be enhanced by the State Health Society
depending on the specific requirements of the
District.
4.6

A bank guarantee may be asked of the NGOs
for 10% of the amount of the first tranche of
fund release. Fund disbursal would be done at
the implementation level with a bank transfer
i.e. State level or District level for NGOs
engaged at the respective level.

4.7

Release of funds of subsequent installments
would to be done only based on utilization of
funds released earlier and ensuring appropriate
physical progress.

4.8

In case of default, no further grants would be
released to a NGO.The District Health Society
will evaluate the performance and if there is a
violation of any norms, will blacklist the NGO.
The NGO can appeal to the State Health
Society.

4.9

A 12 % institutional overhead for internal
organizational strengthening would enable
NGOs to stay motivated and interested in
the programme and reduce pressures on even
good NGOs to falsify accounts to cover some

<!-- page 22 -->

16

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

legitimate institutional needs, especially the
needs to develop its own internal capacity, pay
its support staff and renew its own motivation
levels.

yy Once the MoU has been signed the
District Health Society releases the grant
to the NGO as under:

4.10 The following are financial guidelines for Field
NGOs and Service NGOs:

2nd release: 40% of the total grant
based on the UCs received

yy The salary component shall not exceed
35% of the total budget, however.

3rd release: 40% of the total grant
based on UCs submitted and favorable
evaluation report.

yy Charges such as rent for space, capacity
building, TA and DA for the staff will not
exceed 25%.
yy Contingency of 10% of the total cost
minus the salaries is permissible
yy Funds will not be provided for construction
of building and purchase of vehicles,
however in extremely under-served
areas, SNGOs could be funded for capital
expenditures but that is a decision to be
taken at state level.
yy FNGO/SNGO may be permitted a onetime non –recurring grant to purchase of
essential assets during the first six months
of the project. The amount of the grant
would be decided by the State or District
Health Society with whom the MoU is
signed.
yy The following would be the permitted
expenditure:
Clinical equipment required for the
implementation of the proposed
project
However, purchase of land or
construction of building is not
permitted.

1st release: 15% of the total grant

4th release*: 5% of the total grant –
the final grant is released on receiving
the completed UCs and audited
Statement of accounts along with
project completion report.
yy The following would be the funding
provided to the SNGO providing services
through a government facility:
1st year: 80%
2nd year: 75%
3rd year: 50%
yy The remaining funds would be provided by
the State Government.
yy From the 4th year onwards, NRHM will
provide only a token grant of 25% for
operating government facilities through
SNGOs.
yy The NGO will claim reimbursement of
the last installment after submission of the
final report.

<!-- page 23 -->

V. Selection of
NGOs

5.1

In view of the broad vision of the NHM, there
is a need for many different types of NGOs to
be involved both at the State and the District
Levels. The NGOs also bring in very different
competencies to assist the government in
fulfilling its commitments to the people. To
enable this, there is a need to understand
NGO competencies as categorized into four
overlapping but distinct sets.
yy NGOs with good grassroots linkages
that have a strong commitment to the
marginalized and dispossessed, but with
little technical and professional health
expertise. They also have competencies
for advocacy and for training elected
representatives, community level workers
and functionaries – not necessarily in the
health sector.
yy NGOs with professional or managerial
skills and with substantial expertise in
managing hospitals and outreach health
service delivery programmes.
yy NGOs that have professional competencies
in training health workers especially
paramedical and nursing staff, but little
service delivery experience, especially of
larger projects.
yy NGOs with public health expertise, which
could serve as institutions of evaluation

research and policy development support,
of advocacy and support to planning and
programme implementation.
5.2

Presently there are very few organizations
that combine all these functions and at scale.
Therefore the objective of these guidelines
would be to allow the states a flexibility to
enter into a variety or partnership models with
a diverse number of NGOs in order to achieve
the objectives of the National Health Mission.

5.3

RRC/NSO and Field/ Service NGOs selection
would be by the State GIAC and District GIAC
respectively

5.4

Selection of NGOs would be based on the
following criteria:
1. Registration:
NGO should be registered under the
Societies Registration Act/Indian Trust
Act/ Indian Religious and Charitable
Act/Companies Act or the State
counterparts of such acts for more
than three years.
NGOs applying for projects in a State
other than that of its registration
should have experience of working
in the state for atleast three years in
the last 7 years. However in the case

<!-- page 24 -->

18

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

for the NSO/RRC, Rs 25 lakh for State
Level and Rs. 10 lakh for district level
projects.

of specialized activities such as those
related to technical and support
functions, organizations registered in
other states would also be considered.
Alternately, branches affiliated to a
National federation/organization can
be registered with the parent body.

The NGO should be financially stable.
Either have own infrastructure or
access to rented infrastructure.
NGOs should have appropriate
infrastructure, strong community
outreach networks, stable governance
structures,
transparent
financial
systems and flexible administrative
norms.

For Field NGOs, the NGO should
preferably have office premises in
the district/block where it wants to
operate.
An NGO blacklisted or placed under
funding restriction by any Ministry
or Department of the Government
of India (GoI), State Government or
CAPART would not be eligible for
applying under the scheme. NGOs
applying for projects under the NGO
scheme should give an affidavit to this
effect certifying that they have not
been blacklisted by any Ministry or
Department of the Government of
India or a State Government.
2. Experience:
At least 10 years of experience for
NGO support organization, 5 years
for State level projects and 3 years
for district level projects in health
sector and/or in the concerned
social sector (e.g. education, women’s
empowerment, training, community
mobilization, health services, microplanning, IEC, rural development etc.)

Assets amounting to Rs. 20/10/2.5 lakh
for NGOs applying for projects at the
level of RRC or NSO/State/District
level respectively in the name of the
organization.

Procedures for Selection
State Level
5.5

State GIAC will select RRC/NSO/NGOs that
will carry out projects that span the entire state
(e.g. IEC, campaigns, state training functions), or
cover interventions in more than one districts,
and service delivery NGOs.

5.6

Depending on the identified need of the region,
NGOs may also be engaged for work at the
divisional level, or for a cluster of districts. This
could be done in circumstances where district
NGOs are difficult to find or for a specific
purpose, for example – if gender empowerment
training is to be imparted to specific groups like
SHGs. NGOs that have done good work under
the MNGO scheme may be given preference.

5.7

The same process for selection to be followed
with NSO and state NGO Coordinator taking
an active role.

Past experience in working with state/
central governments preferably in
health sector.
Experience in working with NRHM
would be desirable
Field presence in the district for which
the NGO is applying
Experienced/Qualified personnel.

District Level
3. Financial:
Annual turnover of at least 50 lakh

5.8

The District NGO Committee will be
responsible for selection of NGOs which will

<!-- page 25 -->

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

implement in either a few blocks or the entire
district.
For NGO interventions that require annual
budgets or over Rs. 10 lakhs, the State GIAC
will be involved in the selection.
5.9

Process for selection should be transparent,
well defined, open and accountable. The
selection process should be initiated through
an open advertisement process. The proposal
would be ranked on a set of scoring criteria,
approved by the GIAC at each level. After
the desk review and short list, field appraisal
would be conducted for final selection. The list
of the selected /empanelled NGOs would be
available onMoHFW website. NGOs would be
categorized based on schemes and geographical
locations.

5.10 The selection process for NGO selection will
be through the following steps:yy Open advertisement in 2 leading
newspapers – one in English and the other
in the regional language.
yy Names of the selected NGOs would also
be displayed on the website of the State/
District Health Department.

19

yy Field appraisal of the short-listed
organization would be done by a team
constituted for the purpose, which could
include members from the NSO, district
NGO coordinator, finance personnel and
District Programme Manager.
yy Based on the recommendations of
this team, the district NGO selection
committee will be finalized. The whole
selection process should normally take 60
days.
5.11 The partnerships will be formalized through
a MoU with the district, state or center as
appropriate. The DHS would enter into a MoU
with the NGO, which would detail the key
roles and responsibilities of each. These MoUs
would be subject to central review and be the
basis of audit and programme monitoring. The
period of appointment of the NGO would be
based on the project duration which would
vary depending on the nature of the project.

<!-- page 26 -->

20

Guidelines for Ngo Involvement Under
National Health Mission in the Twelfth Five Year Plan

<!-- page 27 -->

<!-- page 28 -->
