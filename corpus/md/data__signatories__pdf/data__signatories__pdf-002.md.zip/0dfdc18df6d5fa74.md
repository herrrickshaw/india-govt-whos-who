---
doc_id: "0dfdc18df6d5fa74"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/248e9be329f3978b8a60762ddd864d34.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Result of the Interview for appointment as Notary for the State of Gujarat (held on 08.10.2018 to 05.11.2018)"
date: "2019-03-01"
pages: 211
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ee62bfe792e86c33"
---

<!-- page 1 -->

Government of India
Ministry of Law and Justice
Department of Legal Affairs
Notary Cell
****
Notary Cell, Department of Legal Affairs had conducted Interviews for
appointment as notaries for the State of Gujarat from 08.10.2018 to 05.11.2018 at
Ahmedabad. The candidates were assessed keeping in view their competency, legal
knowledge and other relevant factors related to the selection of Notary as per
requirement of the Notaries Act, 1952, the Notaries Rules, 1956 and the relevant
guidelines by the Interview Board constituted for the purpose by the Central
Government. On the basis of the performance of the candidates before the Interview
Board, the Interview Board has recommended names of the following candidates for
appointment as notaries for the State of Gujarat.

2.

All the successful candidates, whose names appear in the below mentioned list,

will be issued Appointment Letters for appointment as Notary shortly. The candidates
are strictly advised not to visit this Office personally for submission of any document or
for issue of certificate of practice. Only after receiving appointment letter from this
Department, the concerned candidate is required to send the documents mentioned in
the appointment letter. The certificate will be issued in due course of time.
BY THE ORDER OF THE
COMPETENT AUTHORITY
NOTARY CELL
01.03.2019

<!-- page 2 -->

Interview
Sl.No.

Name

Area Of
Practice

Father's Name

1

1

Yogeshkumar
Navinchandra
Doshi

20.04.16

Himmatnagar

Navinchandra
Laxmichand
Doshi

Gen

2

2

Bhagat Bina
Pranjivanbhai

OBC

26.04.16

Surat

Pranjivanbhai
Motiram Bhagat

3

3

Ms.Jagruti
Ramanbhai Patel

OBC

18.04.16

Surat Distt.

Nilamkumar
Maganbhai
Patel

4

4

Ms.Pinky
Vinodchandra
Shah

Gen

18.04.16

Surat Distt.

Kalpeshkumar
Manulal Shah

5

5

Bhavesh Vyas

Gen

04.05.16

Rajkot

Navinchandra
Jatashankar
Vyas

6

6

Ms.Prtit Vijaybhai
Mehta

Gen

22.04.16

Bhavnagar

Vijaybhai Mehta

7

7

Bhavinkumar
Jasvantlal Patel

Gen

17.04.16

Civil Court
Vansda

Jasvantlal
Amrutlal Patel

8

8

Ms.Sangita
Bhikhabhai Khunt

Gen

02.05.16

Surat

Bhikhabhai
Khunt

S.No.

Category

Date of
App'n

Address

Enrol. No.

Sneh-Priy' Vkhariyawad,
B/H Dena Bank Dr. Gandhi G/667/1993 Dt.
Road, Himmatnagar13.08.1993
383001
Hari Om' Bunglow Opp. The
Surat Peoples Co.Op.
G/919/1998 Dt.
Bank, Katargam Main
09.10.1998
Road-395004
4/1332, Koliwad,
G/2559/2005
Begampura, Surat GujaratDt.21.08.05
395003
Flat No.304, Rushabh
Apartment, Khapatia
G/1296/2008
Chakla, Nr.Pani Ni Bhit,
Dt.07.09.08
Gandhi Chowk Surat
Gujarat-395003
Shivanjali Janakpuri Block
No.195, Street No.6,
G/3559/1999
Sadhuvashavani Marg
Dt.22.08.99
University Road Rajkot
Gujarat-360005
137, Gitanjali Complex 1st
Floor Mangalsinhji Road
G/691/1987
Kalanala Bhavnagar
Dt.04.10.87
Gujarat-364001
Main Bazar At Po Unai Ta
G/2734/2001
Vansfa Navsari GujaratDt.04.11.01
396590
385A, Tapi Darshan
Soceity-1 Causway Circle
G/2543/2006
Singanpur Road Surat
Dt.27.10.06
Gujarat-395004

<!-- page 3 -->

9

9

10

10

Deriya Manjibhai
Ranchhodbhai

Gen

18.05.16

Distt.Court
Banaskantha

11

15

Kodekar Rasiklal
Chhanalal

OBC

04.08.16

Ahmedabad

12

16

Subhahs Motiani

Gen

14.07.16

Ahmedabad

Thanwardas
MO

13

21

Dave Chetnaben
Natvarlal

Gen

22.07.16

Bhabhar
Banaskantha

Dave Natvarlal

14

22

Oza Ajaykumar
Jayantilal

Gen

19.07.16

Tharad
Banaskantha

Oza Jayantilal

15

24

Ms. Dipikakumari
Bhavanishankar
Pandya

Gen

08.06.16

Modasa

Bhavanishankar
Bhuralal
Pandya

16

25

Daki Ramesh
Khima

SCBC

30.05.16

Mangrol
Distt.Junagadh

Daki Khimabhai
Hirabhai

17

27

Parmar
Narayanbhai
Becharbhai

OBC

09.06.16

Modasa

Parmar
Becharbhai
Pitambabhai

92, Vidhyakunj Society
Modasa Gujarat-383315

G/59/1988
Dt.25.03.88

Chaudhari
Abhabhai
Sarupabhai

Madhavnagar Socayati
Highway Char Rasta
Tharad At-Ta Tharad
Distt.Banaskantha Gujarat385565

G/1029/1994
Dt.26.10.94

18

31

Chaudhari
Hareshbhai
Abhabhai

OBC

06.06.16

Vadodara

Gen

17.08.16

Banaskantha
Distt.

Babubhai
Parmar

23 B Vrundavan Park
Society Bhadarva Chokdi
Savli Vadodara Gujarat391770
At. & Po. Madana Gadh Ta.
Palanpur Distt.Banaskantha
Gujarat
Navkholi Chharanagar
Kubrenagar Ahmedabad
Gujarat-382340
F Ward H.No.43,
Kubernagar Ahmedabad
Gujarat-382340
Tirupatinagar Nav Road
Bhabhar Ta Bhabhar
Distt.Banaskantha Gujarat385320
Near Madhusaheb Hospital
Bh.Ekta Complex At Po
Tharad Banaskantha
Gujarat-385565
159 Vidhyakunj Society
Moadasa Ta. Modasa
Sabarkantha Gujarat383315
At.Divasa Near Bus Stand
Ta- Mangrol Distt.Junagadh
Gujarat-362240

Vipulkumar
Babubhai Parmar

Deriya
Ranchhodbhai
Kevalbhai
Kodekar
Chhanalal
Chamanlal

G/1665/2004
Dt.14.08.04
G/796/1998
Dt.12.09.98
G/489/2003
Dt.26.04.03
G/651/2006
Dt.02.05.06
G/2535/2005
Dt.21.08.05

G/85/2004
Dt.30.01.04

G/2455/2005
Dt.21.08.05
G/1422/2008
Dt.07.09.08

<!-- page 4 -->

19

34

Thakore Dilipsinh
Bharatsinh

Gen

Nil

Bharuch
Distt.& City

Thakore
Bharatsinh
Prabhatsinh

20

35

Devendra
Dilipbhai
Sukhadiya

Gen

26.05.16

Gandhinagar
Distt.Court

Dilipbhai

21

37

Kishanbhai
Gigabhai Vaghela

SC

20.06.16

Surat

Gigabhai
Aatabhai
Vaghela

22

38

Dalaji Punamaji
Patel

OBC

06.07.16

Deesa Ta
Lakhani Distt.
Banaskantha

Punamaji
Dharamji Patel

23

39

Navinchandra
Ranchhodbhai
Changani

Gen

08.05.16

Surat City

Ranchhodbhai

24

45

Sandip Ambalal
Christie

Gen

01.09.16

Ahmedabad

Ambalal
Christie

25

46

Bhavesh
Dilipkumar Trivedi

Gen

30.07.16

Ahmedabad
Court Met.

Dilipkumar
G>Trivedi

47

Pareshkumar
Manubhai Parikh

Ahnedabad

Manubhai
Parshottamdas
Parikh

26

Gen

23.08.16

10, Pushpkunj Society,
Zadeshwar Road At.Po.
Maktampur Ta.
Distt.Bharuch Gujarat392012
438/4, Suryavandna Flat
Sector-30 Gandhinagar
Gujarat-382030
202, Krishna Flats,
Bahucher Nagar Opp.
Hariom Mill Ved Road Surat
Gujarat-395004
At.Post Kotada Ta Lakhani
Banaskantha Gujarat385535
29, Shyamkrushna Raw
House Mahadev Chowk
Mota Varachha Surat City
Gujarat-394101
B-19, Bethal Krupa Society
Behind Haripura Housing
Maninagar East
Ahmedabad Gujarat380008
1, Tirupati Bunglows Nr.
Gautam Flats, Dehgam
Road Naroda Ahmedabad
Gujarat-382330
63, Sahjanand Park Society
Opp. Vaibhav Hall National
Highway Road Nr.
Samratnagar Post Isanpur
Ahmedabad Gujarat382443

G/2975/2000
Dt.25.11.2000

G/224/1998
Dt.28.03.98
G/1843/2007
Dt.29.11.07
G/3602/1999
Dt.22.04.99
G/112/2003
Dt.11.01.03

G/2521/2001
Dt.07.10.01

G/2148/2006
Dt.24.07.06

G/905/1995
Dt.28.07.95

<!-- page 5 -->

50

Chavda
Narendrasinh
Gulabsinh

Gen

11.07.16

Khedbrahma &
Idar

Chavda
Gulabsinh

28

51

Trivedi
Vijaykumar
Baluprasad

Gen

00.07.16

Khedbrahma &
Idar

Trivedi
Baluprasad

29

53

Thanki Harish
Padmanabhbhai

Gen

19.07.16

Devbhumi
Dwarka &
Porbandar

Thanki
Padmanabhbha
i Purushottam

30

54

Ms.Jayshreeben
Desai

OBC

11.07.16

Patan

Liladhar Desai

31

57

Anil Naginbhai
Patel

OBC

08.09.16

Uplu Faliyu
Nanived

Naginbhai
Khushalbhai
Patel

32

59

Ms. Bhavini
Rashmin Sheth

Gen

15.09.16

Rajkot Distt

Rashmin
Natvarlal Sheth

33

61

Bhaskarbhai
Natwarlal Jasani

Gen

14.09.16

Rajkot City

Natwarlal
Harjibhai Jasani

34

62

Chandulal
Muljibhai
Pambhar

Gen

13.09.16

Rajkot City

Muljibhai
Gopabhai
Pambhar

35

63

Manish
Bhagwanji
Gundecha

Gen

15.09.16

Adipur CityGandhidham
Distt.-Kachchh

Bhagwanji Kanji
Gundecha

27

At Po. Poshnia Ta- Poshina
Distt. Sabarkantha Guajrat383422
Devinagar Area Vijay Nivas
Station Road Khedbrahma
Ta. & Distt. Sabarkantha
Gujarat-383255
Near Post Office At. Raval
Tal. Kalyanpur Jamnagar
Gujarat-361325
30, Gayatri Nagar Sidhpur
Road Patan Gujarat-384265
439 Uplu Faliyu Nanived
Taluka City Surat Gujarat395004
Shri Goverdhan Jalaram
Plot No.5, Street No.2, Opp.
Saakar Flats Near Indira
Circle Rajkot Gujarat360005
Pratibha B-31, Gunatit
Nagar Behind Bus Stand
Gondal Rajkot Gujarat360311
Shreeji Complex, 2nd Floor
Shreeji Krupa Bunglows
Society Satyasai Hospital
Main Road Nana Mava
Road Rajkot Gujarat360005
H.No.Trs-127, Ward No.4A, Near Sindhology School
Adipur-Kachchh Gujarat370205

G/810/2005
Dt.28.05.05
G/2051/1999
Dt.21.03.99
G/2233/2005
Dt.06.08.05
G/2093/1999
Dt.21.03.99
G/1859/2003
Dt.31.08.03

G/2178/2000
Dt.09.09.2000

G/1419/2003
Dt.10.08.03

G/1332/2003
Dt.10.08.03

G/1026/1999
Dt.21.03.99

<!-- page 6 -->

64

Punitkumar
Harishchandra
Dudhrejiya

37

65

Zala Babubhai
Udabhai

Gen

24.08.16

38

66

Parmar
Pravinkumar
Mangalbhai

OBC

03.08.16

36

OBC

15.09.16

Kachchh
Kapadwanj
Kathalal
Nadiad
Distt.Kheda
Kapadwanj
Kathalal
Nadiad
Distt.Kheda

Harishchandra
Magniram
Dudhrejiya

Plot No.380, Ward No.DC-5
MK House Near Court
Building Adipur-Kachchh
Gujarat-370205

G/399/2008
Dt.20.06.08

Udabhai

At.Mota Rampura Po.
Chikhlod Ta. Kapadwanj
Kheda Gujarat-387640

G/283/2003
Dt.22.02.03

Mangalbhai

At.Po. Dampat Ta. Kathalal
Kheda Gujarat-387630

G/305/2003
Dt.22.02.03

39

67

Bharatkumar
Sardarji Thakor

OBC

26.09.16

Palanpur

Sardarji

40

68

Shantuji Somaji
Thakor

OBC

14.09.16

Banaskantha
Distt.

Somaji

41

69

Vikram Babuji
Ramsena

OBC

14.09.16

Banaskantha
Distt.

Babuji

42

70

Mahendrasinh
Ranjitsinh Jadeja

Gen

01.09.16

Ahmedabad

Ranjitsinh
Jadeja

43

71

Sangramji
Bhathiji Dhunkh

OBC

19.09.16

Palanpur

Bhathiji

44

72

Sureshkumar
Vashramji Thakor

OBC

26.09.16

Palanpur

Vashramji
Thakor

Krushna Nagar Society
Near High School Athamani
Sheri At.Jagana Ta.
Palanpur Banaskantha
Gujarat-385011
At.Post- Khodla TaPalanpur Distt.Banaskantha
Gujarat-385510
260 Virkrupa Society
Tajpura Dhundiyawadi
Palanpur Banaskantha
Gujarat-385001
A/30, Tripada Society Nr.
Gor No Kuvo Maninagar
East Ahmedabad Gujarat380008
At/Kotada Bhakhar Post
Madana Dangiya Ta.
Palanpur Banaskantha
Guajrat-385510
At.Po. Kumbhalmer
Ta.Palanpur Banaskantha
Guajrat-385510

G/182/2001
Dt.24.02.01

G/1143/1999
Dt.21.03.99
G/864/2002
Dt.11.07.02

G/1441/2003
Dt.10.08.03

G/2519/2006
Dt.07.10.06
G/1112/2007
Dt.30.07.07

<!-- page 7 -->

20.08.16

Ahmedabad
Kalupur

Shaileshbhai H
Magiyawala

1400 Mamunayk Pole
Kalupur Thankshal
Ahmedabad Gujarat380001

G/1045/2003
Dt.20.07.03

16.07.16

Bharuch

Kapadia
Subodhchandra

A/352, Kabirpura Khatriwad
Bharuch Gujarat-392001

G/2671/2005
Dt.24.09.05

45

75

Ms.Ankita
Shaileshbhai
Magiyawala

46

76

Kapadia
Jatinkumar
Subodhchandra

47

79

Ranvirsinh
Mohabatsinh
Parmar

Gen

06.09.16

Gandhidham

Mohabatsinh
Parmar

48

80

Joshi
Pankajkumar
Jayantilal

Gen

06.09.16

Gandhidham

Joshi Jayantilal

49

81

Ms.Rajput
Bhumika

Gen

26.08.16

Ahmedabad

Keshubhai

50

83

Ranusinh Dursinh
Chauhan

OBC

05.07.16

Talod

51

84

Chauhan
Jashvantsinh
Galabsinh

OBC

05.07.16

Bayad

52

85

Bankim
Jitendrabhai Patel

Gen

28.10.16

Ahmedabad

Jitendrabhai
Raojibhai Patel

53

87

Antiya Valabhai
Ramjibhai

Gen

27.09.16

Palanpur

Ramjibhai

Gen

Gen

Dursinh
Himmatsinh
Chauhan
Chauhan
Galabsinh
Hamirsinh

H.No.E-13, Gujarat Housing
Board Sector-5,
Gandhidham Kachchh
Gujarat-370201
Tenament No.3, Plot
No.278, Ward No.3/A
Adipur Kachchh Gujarat370205
C/3, Shivam Appt.Kabir
Chowk Sabarmati Motera
Ahmedabad Gujarat380005
Gobarji Na Muvada TaTalod Sabkarnatha Gujarat383325
At.Po. Chandrej Ta-Bayad
Sabarkantha Gujarat383325
12, Amar Society, Opp.
Balwatika Kankaria
Maninagar Ahmedabad
Gujarat-380008
Near Darjivas At.Sundha
Po.Mota Banaskantha
Guajrat-385510

G/1331/2006
Dt.21.06.06

G/321/2003
Dt.22.02.03

G/687/2009
Dt.27.06.09
G/82/1997
Dt.20.08.97
G/4612/1999
Dt.05.11.99
G/1049/2005
Dt.03.07.05
G/1505/2001
Dt.07.08.01

<!-- page 8 -->

54

88

55

89

56

90

57

92

58

Rajubhai
Sumarbhai
Ramvani

Gen

19.09.16

Godhra

SC (PH)

27.10.16

Kapadwanj &
Kathalal

SC

28.10.16

Kapadwanj &
Kathalal

Yogeshkumar
Dolatrai Dave

Gen

25.10.16

Amreli Distt.

Dolatram

93

Ashokkumar
Mavjibhai
Panchotiya

Gen

22.10.16

Surat City

Mavjibhai
Tribhovanbhai
Panchotiya

59

98

Harishkumar
Ranchhodbhai
Pandit

Gen

03.11.16

Kapadwanj &
Kaithal

Ranchhodbhai
Battilal Pandit

60

99

Ms.Falguniben
Prafullchandra
Barot

OBC

28.10.16

Bharuch Distt.

Barot
Prafullchandra

103

Ms. Nutan
Arunbhai Pandit

28.10.16

Makarpura,
Vadodara

Arunbhai
Gurubhai
Pandit

61

Rathod
Rameshchandra
Devjibhai
Ms.Daxaben
Khushalbhai
Rhoit

Gen

Sumarbhai

Rathod
Devjibhai
Manabhai
Khusalbhai
Ganeshbhai
Rohit

10, Zulelal Society
Bhuravav Godhra
Bhuravav Godhra
Panchmahals Gujarat389002
At.Kevadiya Po. Atarsumba
Ta. Kapaswanj Distt.Kheda
Gujarat-387610
Rohitvas Near Meenabazar
Kapadwanj Kheda Gujarat387620
Sharda Shopping Centre
At-Moti Kunkavav TaKunkavav Vadia Near
Shivalay Amreli Gujarat365450
B/21, 2nd Floor Santoshi
Nagar Society
Nr.Kantareshwar Mahadev
Mandir Lalita Chokdy
Katargam Surat Gujarat395004
At & Post Attarsumba Ta.
Kapadwanj Distt.Kheda
Gujarat-387610
903, Sai Heights Near
Rohini Nagar Abc Cross
Road Bholav Bharuch
Gujarat-392001
B/1, Punja Complex Opp.
Hajira Pratapnagar Bridege
Makarpura Road Vadodara
Gujarat-390004

G/1318/2003
Dt.10.08.03

G/746/2000
Dt.05.05.2000
G/924/2000
Dt.05.05.2000

G/2961/2005
dt.24.09.05

G/2707/2006
Dt.07.10.06

G/2647/2000
Dt.09.09.2000
G/1251/2008
Dt.07.09.08

G/2331/2006
Dt.03.09.06

<!-- page 9 -->

62

104

Harisinh Javanji
Parmar

63

107

Vikram Aastimal
Shah

Gen

21.11.16

Surat City

Aastimal Shah

64

108

Parmar Varsha
Premchandbhai

SC

23.11.16

Vadodara

Premchandbhai

65

113

Sinhol Kishorbhai
Bhikhabhai

SC

03.12.16

Ahmedabad

Sinhol
Bhikhabhai

66

116

Ms.Hetal
Labhashankar
Raval

Gen

2.11.16

Palanpur

Labhashankar
Raval

67

119

Trivedi
Yogendrakumar
Bhikhabhai

Gen

05.12.16

Nadiad
Distt.Court

Bhikhabhai

68

120

Patel
Rameshkumar
Nathabhai

Gen

03.12.16

Malpur

Patel Nathabhai

69

121

Shah Nikhil
Kumarpal

Gen

26.10.16

Bhavnagar

Kumarbhai
Shah

70

122

Pravn Rasikbhai
Bathwar

SC

15.12.16

Botad

Rasikbhai
Gorabhai
Bathwar

Gen

27.09.16

Palanpur

Javanji Parmar

340 Thakor Vas At
Vedancha Ta.Palanpur
Banaskantha Gujarat385510
Plot No.105, Sarve No.41-2,
Shastri Chowk Behind
Madina Masjid Limbayat
Surat Gujarat-394210
2, Shiv Hari Society Near
Jesal Society Sahyog
Gorwa Vadodara Guajrat390016
50, Bharat Nagar 84 Ordi
Gita Mandir Road
Ahmedabad Gujarat380022
191 Kantheriya Hanuman
Road Fasiya Tekra Palanpr
Banaskantha Gujarat385001
At.Post Attarsumba
Daniwada Faliyu Ta.
Kapadwanj Kheda Gujarat387610
At.Parsoda Po. Nanawada
Ta. Palpr Aravalli Gujarat383345
Plot No.833, Gunatitnagar
K.K.Avenue Road Opp.
Deep Party Plot Bhavnagar
Gujarat-364001
Thadha Ni Wadi,
Shantinagar Near Khas
Road Botad Gujarat-364710

G/1807/2005
Dt.17.07.05

G/235/2001
Dt.24.02.01

G/1047/2008
Dt.26.07.08

G/903/2009
Dt.11.07.09

G/2869/2001
Dt.04.11.01

G/1354/2006
Dt.21.06.06
G/2095/2002
Dt.11.09.02
G/2917/1999
Dt.04.07.99
G/1457/2009
Dt.11.09.09

<!-- page 10 -->

71

123

Kodekar
Roleshkumar
Manojbhai

OBC

25.07.16

Ahmedabad

Kodekar
Manojbhai
Chhanalal

72

125

Ashish Devidas
Kapadia

OBC

06.05.16

Mandvi
Distt.Surat

Devidas Kapdia

73

127

Alpesh

SC

18.09.16

Surat Distt.&
Session Court

Maganbhai

74

128

Hitsh
Ranchhodbhai
Jadav

OBC

14.12.16

Vanthali

Ranchhodbhai
Bhimjibhai
Jadav

75

129

Kapadia
Pravinbhai
Jivabhai

SC

08.12.16

Ahmedabad

Jivabhai
V.Kapadia

76

130

Maheshkumar
Madhusudan
Shukal

Gen

27.11.16

Tarapur

Madhusudan
Shukal

77

131

Chaudhari
Rajeshkumar

OBC

25.12.16

Mehsana
Distt.Court

Chaudhari
Kesharbhai

78

141

Thakor
Nareshkumar
Mangalji

OBC

03.12.16

Deesa

Thakor Mangalji
Galbaji

79

142

Solanki Nareshji
Anarji

Gen

03.12.16

Deesa

Solanki Anarji
Mohanji

80

148

Ms.Bansari
D.Bhatt

Gen

28.12.16

Vadodara

Dhimant
V.Bhatt

81

150

Gyansingh
Ramswarup
Yadav

Gen

14.11.16

Ahmedabad

Ramswarup
Yadav

B/3, Hari Krushna Bunglows
Akash Darshan Society
Motera Ahmedabd Gujarat382475
At.Po. Mandvi Sonigaliya
Main Road Ta-Mandvi Surat
Gujarat-394160
At Post Bhairav Taluka Sub
Distt. Kamrej Surat Gujarat394180
Bag Darvaja Road Girraj
Society Shapur Sorath
Junagadh Gujarat-362205
D-4, Shakti Krupa Soceity2, IOC Road Chandkheda
Ahmedabad Gujarat382424
Shukal Nivas Dixit Faliyu
Po.Tarapur Taluka Tarapur
Distt.Anand Gujarat-388180
At.Amblipura, Post Dhinoj,
Ta. Chanasma Distt. Patan
Gujarat-384225
At.Chandisar Banaskantha
Gujarat-385510
At.Rasana Mota Taluka
Deesa Banaskantha
Gujarat-385535
B/40 Manorath Soceity
Opp. Amar Complex New
Sama Road Vadodara
Gujarat-390024
33-4, Navi Chali
Chamanpura Ahmedabad
Gujarat-380016

G/973/2009
Dt.11.07.09
G/1024/1998
Dt.28.11.98
G/1210/2009
Dt.08.08.09
G/864/2008
Dt.18.07.08
G/583/2008
Dt.27.06.08
G/2329/2001
Dt.07.10.01
G/1844/2005
Dt.17.07.05
G/876/2000
Dt.05.05.2000
G/1804/1999
Dt.21.03.99
G/1718/2006
Dt.09.07.06
G/326/1990
Dt.24.06.90

<!-- page 11 -->

82

152

Yogeshkumar
Chhaganbhai
Dabhi

83

160

Vaghela
Mukeshkumar
Samatbhai

OBC

06.01.17

Bhavnagar

Vaghela
Samatbhai
Govindbhai

84

161

Gohil
Kishorkumar

SC

03.01.17

Bhavnagar
Distt.

Khodabhai

85

163

Ashokkumar
Harmanbhai
Thakor

OBC

17.07.16

Anand

Harmanbhai
Zaverbhai
Thakor

86

164

Ms.Beena
Girjashanker Jani

Gen

10.12.16

Vadodara

Girjashanker

87

165

Ms. Sayrabanu
Pathan

Gen

07.01.17

Dabhoi

Irfanbhai

88

166

Mrs. Kavitaben
Bhailalbhai Gajjar

OBC

01.01.17

Sola
Ahmedabad

Rakeshkumar

89

168

Parul Pravinsinh
Raj

Gen

03.01.17

Padra
Distt.Vadodara

Pravinsinh
Keshaisinh Raj

90

171

Kiritsinh
Prahladsinh

Gen

07.07.17

Ahmedabad

Prahladsinh
Rajput

91

175

Mrs. Sonal
Navinchandra
Brahmbhatt

OBC

20.03.17

Gandhinagar

Kamalnayan
Brahmbhatt

SC

20.12.16

Vadodara

Chhaganbhai
L.Dabhi

104, Sneh Flat Near Sapan
Flats Behind Mother School
Gotri Road Vadodara
Gujarat-390021
Old Sihor BH Kanya Shala
Sihor Bhavnagar Gujarat364240
Plot No.36, Ekta Society,
College Road, Sihor
Distt.Bhavnagar Gujarat364240
Nr.Logania Kuva
At.Bhadraniya Ta. Borsad
Anand Gujarat-388530
302 Shandiya Shreem
Shrushti Sun Pharma Road
Vadodara Gujarat-390012
Desai Nagar At & Post
Sadhli Ta. Sadhli Vadodara
Gujarat-391250
10 Mahalaya-Ii Bunglows
Science City Road Sola
Ahmedabad Gujarat380060
24, Narsinh Nagar Society
Nr.Gayatri Temple Padra
Vadodara Gujarat-391440
B-35, Purushottam Park
Society, Nr Little Flower
School, Chandkheda,
Ahmedabad - 382
424,Gujarat
Plot No. 530/1, Sector 3 C,
Dist. Gandhinagar - 382
006, Gujarat.

G/2729/1999
Dt.04.07.99
G/155/1999
Dt.13.02.99
G/848/2004
Dt.10.07.04
G/1665/2005
Dt.17.07.05
G/1303/2000
Dt.24.06.2000
G/99/2004
Dt.30.01.04
G/441/2007
Dt.11.06.07
G/1877/2004
Dt.14.08.04

G/981/2000 Dt.
05.05.2000

G/1758/2003
Dt. 31.08.03

<!-- page 12 -->

92

177

Maheshkumar
Keshavjibhai
Savsani

93

180

Virendra V.
Raninga

Gen

06.04.17

Rajkot

Vinodrai

94

181

Ms. Kalpana
Babulal Mehta

OBC

06.04.17

Rajkot City

Babulal
Pitamberbhai
Mehta

95

184

Vasava Arunaben
Bhailalbhai

ST

02.03.17

Bharuch

Vasava B.
Dhanjibhai

96

186

Chandreshkumar
Yogendraprasad
Bhatt

Gen

28.02.17

Savarkantha

Yogendraprasa
d Mahashankar
Bhatt

97

191

Hinaben
Niranjanbhai Soni

Gen

09.05.17

Mangrol Court

N.H. Soni

98

195

Shah Asvin
Ravilal

Gen

11.05.17

Mandvi Kutch

Ravilal

99

197

Darshankumar
Ramanbhai Patel

Gen

05.07.17

State Of
Gujarat

Ramanbhai
Jesingbhai
Patel

100

198

Prajapati Navin
Dahyabhai

OBC

14.07.17

Valsad

P.D.
Laxmanbhai

Gen

01.04.17

Rajkot

Keshavjibhai N.
Savsani

Dev Bhakti, Krishna Park
Street No.2, B/H. Popatpara
Rail Nagar Main Road,
Rajkot - 360 001, Gujarat.
Momai Krupa, 1/7 Jayraj
Plot, Palace Road, Rajkot 360 001, Gujarat
Om App Block No.3,
Karanpara Street No.24,
Opp. Fire Brigade, Rajkot 360 001, Gujarat.
Jalaram Nagar, DU.
Waghpura, Umalla TAJhagadia, Bharuch, Gujarat
- 393 120.
Suyog Bhavan, Nr. Branch
Post Office,Mehtapura,
Himatnagar, Dist. Sabar
Kantha, Gujarat - 383 001.
Parekh Electronics, Opp.
Jain Templenava, Kosamba
Mangrol, Dist. Surat,
Gujarat - 394 120.
K T Shah Road, Temle
Street Mandvi, Dist.
Kachchh, Gujarat-370 465.
6, Karnavati Society,
Visnagarroad, Vijapur,
Mehsana, Gujarat - 382 870
Opp Atul First Gate, Village
Parnera, Ta Valsad, Dist.
Valsad, Gujarat - 396 020.

G/2335/2005
Dt. 06.08.05
G/1959/2005
Dt. 17.07.05
G/1909/2006
Dt. 24.07.06

G/3170/2000
Dt. 25.11.2000

G/1540/2000
Dt. 22.07.2000

G/54/2010 Dt.
17.01.10
G/2804/2004
Dt. 26.12.04
G/2255/2005
Dt. 06.08.05
G/507/1989 Dt.
17.07.89

<!-- page 13 -->

101

199

Rajeshkumar
Ratilal Parmar

SC

01.06.17

Gheekanta

Ratilal
Somabhai
Parmar

102

201

Dharti Shah

Gen

04.01.17

Ahmedabad

Tejas Shah

103

202

Nayankumar
Ramniklal
Pajwani

Gen

15.05.17

Rajkot City

Ramniklal M.
Pajwani

104

206

Ajay Kumar
Tripathi

Gen

30.11.16

Vadodara

Birendrakumar
Tripathi

105

215

Sodha
Chentankumar
Jentilal

Gen

25.03.17

Rajkot Court

Jentilal
Parshotam
Sodha

106

219

Togadiya Vijay
Ravjibhai

Gen

31.03.17

Rajkot City

Ravjibhai

107

220

Prashant
Pradipbhai
Lathigra

Gen

31.03.17

Rajkot Gujarat

Pradipbhai R.
Lathigra

108

221

Mehta Dilip
Manshankar

Gen

29.03.17

Rajkot

Manshankar

104/7, Sai Flats, NR
Navrang School, Odhav
Industrial Estates, Dist.
Ahmedabad, Gujarat - 382
415.
27-267, Parishram
Apartment, Near
Shivranjani Cross Road,
Dist. Ahmedabad, Gujarat 380 015.
F/7 Merry Gold Residency,
B/H Cosmo Complex,
Mahila Collage Chowk, Dist.
Rajkot, Gujarat - 360 001.
A/3, Pavan Park Society,
Opp. Roses Garden Chhani
Road, Dist, Vadodara,
Gujarat - 390 002.
Avkar App 203, Kedavadi
Main Road, Palang Chowk,
Dist. Rajkot, Gujarat - 360
002.
Trinertraplot No.61, Fulwadi
Park, Sattyasai Road
Nanamava, Dist. Rajkot,
Gujarat - 360 005.
"Radhe", 2-Shiva Maharaj
Close Street No.2, Near
Soni Bazar, Kothariya
Naka, Dist. Rajkot, Gujarat 360 001.
Jayallaxmi Krupa, 1Alkapuri Raiya Road, Dist.
Rajkot, Gujarat - 360 007.

G/332/2005 Dt.
12.02.05

G/1035/2003
Dt. 20.07.03

G/1686/2006
Dt. 09.07.06

G/1762/2004
Dt.14.08.04

G/1065/1999
Dt.21.03.99

G/635/2003
dt6. 26.04.03

G/2116/2006
Dt. 24.07.06

G/1247/2002
Dt. 31.07.02

<!-- page 14 -->

109

222

Sekhaliya Ashvin
Vallabhbhai

110

224

Chauhan
Shankarlal
Balakabhai

OBC

28.03.17

Limkheda

Balakabhai

111

225

Kanaksinh Naval
Sinh

OBC

04.04.17

Limkheda

Navalsinh

112

228

Ms. Parmar
Bharatiben
Babulal

SC

24.03.17

Dist. Court
Palanpur

Babubhai M
Parmar

113

229

Chavada
Jaydipsinh
Narvatsinh

Gen

15.03.17

Godhra

Chavada
Narvatsinh

114

234

Solanki
Ashishbhai

SC

04.04.17

Gadhada

Narenbhai

115

236

Ganesh
Yashvanth
Dusane

Gen

04.04.17

Surat Distt.
Court

Yashvanth
Eknath Dusane

116

239

Desai Lalit
Dayalbhai

Gen

31.03.17

Surat Distt.

Desai
Dayalbhai
Narshihbhai

117

243

Dahyabhai
Pathubhai
Parmar

ST

01.05.17

Palsana Civit
Court

Pathubhai
Kachharabhai
Parmar

Gen

29.03.17

Rajkot

Vallabhbhai

2-Gadhiya Nagar, Raj Auto
Street, Santkabir Road,
G/1120/2004
Dist. Rajkot, Gujarat-360
Dt. 10.07.04
003.
Opp. Vishram Gruh, At.
G/1592/1999
Pall, Ta. Limkheda, Dist.
Dt. 21.03.99
Dohad, Gujarat -389 140.
121/1, Faliyu, At. Dabhada,
G/104/2005 Dt.
Ta. Limkheda, Dist. Dohad,
12.02.05
Gujarat - 389 140.
13, Shivshakti Satkar
Society, Ganeshpura Road, G/267/2008 Dt.
Palanpur, Dist. Banas
29.03.08
Kantha, Gujarat - 385 001.
46/1, Samarpan Tenament
& Raw House, Vrundavan
G/4178/1999
Nagar-2, Dst. Panch Mahal,
Dt. 19.09.99
Gujarat - 389 001.
Janta Society, AT- Narayan
Nagar, Ambardi Para, TAG/2922/2005
Lathi, Dist. Amreli, Gujarat Dt. 24.09.05
365 22.
59, Chhatrapati Shivaji
Nagar,Limbayat, Udhna,
G/2746/2001
Dist. Surat, Gujarat - 392
Dt. 04.11.01
201.
3, Santosh Apartment,Plot
No.20, Om Nagar Near
G/1762/2001
Gopal Nagar, Parvat Patiya
Dt. 18.09.01
Dumbhai Road, Dist. Surat 395 010, Gujarat.
Vihat Nagar, Near G.E.B.
Kadodara Char Rasta, Ta. G/627/2010 Dt.
Palsana, Dist. Surat,
14.04.10
Gujarat - 394 327.

<!-- page 15 -->

246

119

250

Parmar
Kalyansing
Laxmansing

OBC

04.03.17

Ahmedabad

Laxmansing H.
Parmar

120

256

Kalpeshkumar
Karshanlal Kariya

Gen

18.02.17

Patan

Karshanlal

121

260

Kumarpal
Samantbhai
Vinzuda

SC

02.02.17

Savarkundla

Samantbhai

122

261

Bhogilal
Vallabhbhai Patel

Gen

15.02.17

Vadodara
Distt. Court

Vallabhbhai
Patel

123

262

Ramanbhai
Ambalal Sharma

OBC

21.02.17

Vadodara

Ambalal
Madhavdas
Sharma

124

265

Ms. Shah
Jagrutiben
Shantilal

Gen

21.02.17

Dabhoi

Dipakkumar

268

Sohalkumar
Vinodchanra
Vyas

Gen

13.04.17

Dabhoi

Vinodchandra
Vyas

Patelwaga Dabhoi
Vadodara Gujarat-391110

G/488/2006
Dt.19.02.06

269

Ms. Rashmi
Sajay Shah

Vadodara

Sanjay
Chandulal Shah

701-A, Arihant Super
Market, Nr. Lalbaug
Crossing Manjalpur, Baroda
Gujarat-390011

G/284/1994
Dt.28.03.94

126

11.04.17

Ahmedabad

G/3074/2000
Dt.25.11.2000

118

125

Gen

Dahyalal
Laludas Nayak

35/207, Anandnagar, 100ft,
TP Road, Vejalpur Satellite
Ahmedabad Gujarat380015
Mota Thakor Vas, Bareja
Ahmedabad Gujarat382425
47, Gayatri Nagar Society,
B/H. Gayatri Temple, At.
Radhanpur Patan Guajrat385340
68, Chamundamatanu
Mandir, Street No.3, Near
Khadikaryalay AtSavarkundla Amreli
Gujarat-364515
B/50, Vrajdham Society,
Sussen Tarsali Ring Road,
Vadodara Gujarat-390009
501, Shalimar Chambers,
Opp. Sardar Bhavan Near
Sai Baba Mandir, Raopura
Vadodara Gujarat-390001
Shamlaji Ni Sheri,
Shreemali Waga At-Po- TaDabhoi Vadodara Gujarat391110

Girishkumar
Dahyalal Nayak

Gen

28.03.17

G/579/1986
Dt.23.08.86
G/233/1988
Dt.23.04.88
G/596/2002
Dt.20.04.02

G/414/1976
Dt.10.09.76
G/68/1981
Dt.02.02.81

G/813/1998
Dt.12.09.98

<!-- page 16 -->

127

272

Rathod
Bhanjibhai
Desabhai

128

275

Haribhai
Dhudabhai Patel

OBC

06.04.17

Palanpur

Dhudabhai

129

277

Bhatt Hirenkumar
Arvindbhai

Gen

18.03.17

Banaskantha

Arvindbhai

130

278

Devendra
Kantibhai
Prajapati

Gen

18.03.17

Ahmedabad

Kantibhai
Dahyabhai
Prajapati

131

279

Ms. Arika
Girishkumar Vala

Gen

13.04.17

Amreli

Girishkumar
Virajbhai Vala

132

281

Ms. Rupal
Kiritkumar Soni

Gen

30.03.17

Godhra

Kiritkumar Soni

133

282

Ms. Lata
Ramanlal Shelat

Gen

12.04.16

Bharuch

Ramanlal
Shelat

134

284

Vikram Kantilal
Kahar

OBC

03.04.17

Surat Distt.

Kantilal
Narandas
Kahar

135

285

Ms. Raksha
Kalubhai Goti

Gen

02.04.17

Surat Distt.

Kalubhai
Haribhai Goti

SC

03.04.17

Savarkundla

Desabhai

Near Ramdev Pir Temple,
Behind Khadi Karyalay At,
Savarkundla Amreli
Gujarat-364515
At.Akedi Post-Bhutedi TaPalanpur Banaskantha
Guajrat-385010
4, Ambikanagar Society,
Near Jalaram Temple,
Banaskantha Gujarat385320
53, Gopi Krushna Society,
Opp. Lake Chandlodiya
Ahmedabad Gujarat382481
Ratanvila Manekpara Street
No.2/B, Behind Krishna
Petrol Pump, Amreli
Gujarat-365601
5, Arihant Nagar Society,
Bamroli Road, Godhra
Panchmahals Gujarat389001
40, Narayan Nagar-1, Bh
Four Shop Bharuch
Gujarat-392001
1-23-29, Near Makkaipul,
Beside Lucky Battery,
Machhiwad Nanpura Surat
Gujarat-395001
45, Gadhpur Township,
Village Pasodara Ta-Kamrej
Surat Gujarat-394180

G/761/1988
Dt.12.10.88
G/1161/2002
Dt.31.07.02
G/1410/2001
Dt.07.08.01

G/1536/2003
Dt.10.08.03

G/2968/2006
Dt.02.12.06

G/1602/2005
Dt.03.07.05
G/298/1985
Dt.01.09.85
G/1159/1998
Dt.25.12.98
G/1747/2009
Dt.23.09.09

<!-- page 17 -->

02.04.17

Surat City &
Distt.

Patabhai
Bhikhabhai
Vora

136

286

Dilip Patabhai
Vora

137

287

Mahek
Narendrakumar
Gandhi

OBC

10.04.17

Surat Distt.

Narendrakumar
Mohanlal
Gandhi

138

292

Dhaval Anilkumar
Mehta

Gen

26.09.17

Distt.Court
Gandhinagar

Anilkumar
Hiralal Mehta

139

294

Dhansukh
Bhagvanji Jogi

Gen

28.09.17

Kachchh Distt.

Bhagvanjibhai
Mithabhai Jogi

140

296

Kuvadiya
Jagubhai
Mansurbhai

OBC

18.09.17

Rajkot

Mansurbhai

141

298

Chaudhari
Bharatkumar
Meghjibhai

OBC

20.12.17

Gandhinagar

Meghjibhai

142

301

Jagdishbhai
Jashubhai Patel

Gen

09.10.17

Surat Distt.

Jahsubhai
Mahijibhai Patel

143

302

Dholariya
Prakash Lalaji

Gen

30.06.17

Amreli

Dholariya Lalji
Vashrambhai

144

303

Parmar Valabhai
Ajeshibhai

SC

14.09.17

Vav

Parmar
Ajeshibhai
Ganeshbhai

OBC

119, Sant Jalaram Society,
Opp. Pandol Industry Ved
Road, Surat Gujarat395004
33,2, Mathura, Jaldarshan
Society, Near Umrigar
School, Poly Umrigar Road,
Umra Surat Gujarat-395007
Plot No.1277/2, Sector-4c,
Gandhinagar Gujarat382006
Plot No.28, Ramvadi
Shaktinagar, Bhachau
Taluka Bhachau Kachchh
Gujarat-370140
411, Maruti Nanadan
Complex, Jawahar Road
Opp. Galaxy Hotel,4th Floor
Rajkot Gujarat-360001
Block No.717/4 CH-1 Type
Near Post Office Sector-8,
Gandhinagar Gujarat382007
14/A, Bhagunagar Society,
Ganeshpura
(Chhaprabhatha), Sayan
Road, Amroli, Surat
Gujarat-94107
At.Pipariya Taluka
Khambha Distt.Amreli
Gujarat-365650
At-Pratappura East Ta-Wav
Distt.Banaskantha Gujarat385566

G/2408/2003
Dt.15.10.03

G/1252/2009
Dt.08.08.09
G/2818/2001
Dt.04.11.01
G/590/2000
Dt.05.05.2000

G/653/2010
Dt.14.04.10

G/604/2000
Dt.05.05.2000

G/1498/1995
Dt.21.12.95

G/2088/2006
Dt.24.07.06
G/579/2010
Dt.04.04.10

<!-- page 18 -->

145

312

Baraiya Premji
Balubhai

146

313

Dalwadi
Jagdishbhai
Jasamatabhai

OBC

07.06.17

Botad

Jasamatbhai
Rudabhai
Dalwadi

147

314

Hitendrakumarbal
krushna Pathak

Gen

30.10.17

Petlad

Balkrushna
Harinaryan
Pathak

148

315

Mahipatsinh
Bhavsinh Parmar

Gen

08.10.17

Rajkot

Parmar
Bhavsinh

149

318

Leuva
Bharatkumar
Becharbhai

SC

19.01.18

New
Chandkheda

Becharbhai

150

321

Shah Axaykumar
Vipinchandra

Gen

19.11.17

Vadodara

Vipinchandra

151

322

Prajapati
Vishnubhai
Ishvarbhai

OBC

05.10.17

Gandhinagar,
Mansa

Prajapti
Ishvarbhai
Revabhai

152

324

Mukesh
Narendrabhai
Patel

Gen

07.11.17

Ahmedabad

Narendrabhai
A.Patel

153

329

Ms. Sadariya
Hema Nathalal

OBC

11.11.17

Gandhinagar
Distt.Court

Nathalal

OBC

23.09.17

Una

Balubhai

At Una, 4th Panchavati
Society, Bh Shah
H.D.School Gir Somnath
Gujarat-362560
Nr. Mamladar Kacheri
Behind Railway Station
Ranpur Botad Gujarat382245
Joshini Chali Ashapuri
Road At.Petlad Anand
Gujarat-388450
Prakash-7, Radha Nagar
BH Laxminagar Rajkot
Gujarat-360004
H/201, Hiradhan Halcyon
B/H Satyamev Hospital
Near Pavan Residency New
Chandkheda Ahmedabad
Gujarat-382424
B-310, Vishala Flat, Near
Punam Complex, Waghodia
Road Vadodara Gujarat390019
Himatpura (Lakroda), Po.
Rangpur, Ta. Mansa
Distt.Gandhinagar Gujarat382835
44, Apuva Bunglows B/H
Utsav Enclave, Memnagar
Ahmedabad Gujarat380052
Plot No.536/1, Sector-13/A,
Gandhinagar Gujarat382013

G/2020/2003
Dt.31.08.03

G/752/2007
Dt.29.06.07
G/1721/2006
Dt.09.07.06
G/918/2007
Dt.29.06.07

G/991/2006
Dt.21.06.06

G/1450/2000
Dt.22.07.2000

G/19/2008
Dt.15.02.08

G/832/2003
Dt.22.06.03
G/426/2001
Dt.23.03.01

<!-- page 19 -->

154

330

Ms. Chauhan
Varsha
Trikamsinh

155

333

Parmar Ashok
Harivadan

SC

28.12.17

Mahesana

Harivadan

156

337

Bhavin
Jayendrakumar
Shah

Gen

20.11.17

Ahmedabad

Jayendrakumar
Rasiklal Shah

157

338

Swanit
Maheshkumar
Vaidya

Gen

29.12.17

Vadodara

Maheshkumar

158

339

Jain Ajitkumar
Chhakilal

Gen

23.02.18

Ahmedabad

Chhakilal Jain

159

340

Shukla Hiralben
Ghanshyambhai

Gen

06.03.18

Nadiad

Ghanshyambha
i Rasiklal
Shukla

160

342

Harsinh
Purushottamsinh
Rathod

Gen

16.03.18

Palanpur

Purushottam

161

343

Ms. Jani Hema
Prakashchandra

Gen

30.01.18

Kachchh Distt.

Prakashchandr
a Pratapray
Jani

162

344

Rank Vipul
Vallabhbhai

Gen

08.03.18

Vadia

Vallabhbhai

Gen

04.09.17

Ahmedabad
City

Trikamsinh.J.C
hauhan

A-19, Bhuvneshwari Park,
Janta Nagar Soceity Area
Chandkheda Ahmedabad
Gujarat-382424
Arjanbari Darwaja, Near
Ashapuri Temple
Vankarvas At. Vadnagar
Mahesana Gujarat-384355
20/218, Poojan Apartment
Nr. Jivraj Mehta Hospital
Paldi Ahmedabad Gujarat380007
A-11, Aashray Park, Near
Garden Diwalipura
Vadodara Gujarat-390007
52/1, 1st Floor Sector-5,
Nirnaynagar, Chandlodia
Road, Ahmedabad Gujarat382481
4, Hariom Society, Near
Vaishali Cinema, Old
Dumral Road, Kheda
Gujarat-387002
55, Ambica Nagar, Near
Terapanth Bhavan Palanpur
Banaskantha Gujarat385001
601, Anjali Tower, Hospital
Road, Near Bhuj English
School Kachchh Gujarat370001
At. Vadia Surag Para Patel
Line Amreli Gujarat-365480

G/1271/2000
Dt.24.06.2000

G/1574/2000
Dt.22.07.2000

G/1757/2007
Dt.13.10.07
G/2718/2001
Dt.04.11.01
G/1689/2000
Dt.06.08.2000

G/1519/2010
Dt.27.06.10

G/324/1993
Dt.29.04.93

G/901/1992
Dt.06.10.92
G/2122/2002
Dt.11.09.02

<!-- page 20 -->

163

345

Kaushik
Ganpatbhai Patel

164

347

Parag Nayanbhai
Shah

Gen

24.02.18

Rajkot

Nayanbhai
Shah

165

351

Ms. Hetal Jaymin
Dave

Gen

14.12.17

Ahmedabad
City

Jaymin Dave

166

352

Ms. Makwana
Manglagauri
Purushottam

Gen

06.01.18

Gandhinagar

Purushottam

167

356

Ms. Riddhi
Vijaykumar Shah

Gen

24.09.17

Bhadara

Nilesh P.Shah

168

361

Ms. Veena
Mulchand
Sharma

Gen

28.11.18

Patan

Mulchand

169

364

Dipan Rajeshbhai
Master

Gen

16.11.17

Surat Distt.

Rajeshbhai
Govindbhai
Master

170

367

Kirankumar
Ambalal Ajmeri

OBC

21.11.17

Surat Distt.

Ambalal
Mohanlal Ajmeri

171

368

Ravi Shankar
Shukla

Gen

21.11.17

Vadodara City
& Area

Jwala
Prasad.M.Shukl
a

Gen

03.03.18

Ahmedabad
City

Ganpatbhai
A.Patel

11, Prabhukrupa Society
Opp. Gayatri Temple Ranip
Ahmedabad Gujarat382480
Parag, 5 Prakash Society
Opp. Nirmala Convent
School Rajkot Gujarat360007
101, Sparsh Aspire Opp.
Ruturaj Flat Pt College
Cross Road Paldi
Ahmedabad Gujarat380007
Plot No.372/1, Sector-2/B,
Gandhinagar Gujarat382007
B-402, Sugam Residency,
New Sharda Mandir Road,
Jain Nagar Paldi
Ahmedabad Gujarat380007
Lavkush Appartment, Blick
No.108, 1st Floor Veraval
Distt.Gir Somnath Gujarat362266
333, Chhapaniyo Mohallo,
Near L.N.B., Dalia High
School, Adajan Gam Surat
Guajrat-395009
43, Hariom Nagar Society1, New Kosad Road, Amroli
Surat Gujarat-394107
122/C, Vishwamitri
Township, Opp. Gujarat
Society Tractor, Vishwamitri
Vadodara Gujarat-390011

G/461/2005
Dt.05.03.05

G/496/2007
Dt.11.06.07

G/1412/2003
Dt.10.08.03

G/3828/1999
Dt.22.08.99

G/2868/2010
Dt.28.08.10

G/2896/2004
Dt.26.12.04

G/2697/2006
Dt.07.10.06
G/2376/2004
Dt.26.09.04
G/640/1989
Dt.07.08.89

<!-- page 21 -->

Derasar Street, Near
Darbargadh Morbi Gujarat363641
3rd Floor, Parth Complex,
Savsar Plot Main Road,
Morbi Gujarat-363641
Bhavni Kunj Kalika Plot-1,
Raj Bank Street, Ravapar
Road, Morbi Gujarat363641
Plot No.49-A, Ram Krushna
Mahavir Nagar Anjar
Kachchh Gujarat-370110
B-104, Shree Hari Blessing,
Near Achal Residnecy Opp.
Raj Avenue, New
C.G.Road, Ahmedabad
Gujarat-382424
12-A, Uganda Park Sociey,
B/H Sardar Patel Singh
School Bhairavnath Road
Maninagar Ahmedabad
Gujarat-380008
61, Yogi Krupa Society,
B/H. Mahavir Society, Puna
Simada Road, Puna Gam
Surat Gujarat-395010

172

372

Ms. Khushbu
Yogesh Kothari

Gen

24.11.17

Morbi

Yogeshbhai

173

373

Virendra
Jayvantlal Mehta

Gen

25.11.17

Morbi

Jayvantlal
Nimchand
Mehta

174

374

Ms.Chandibham
mar Kajal
Kisorbhai

Gen

12.10.17

Morbi

Kishorbhai

175

375

Ms. Barot
Shantaben
Khodabhai

SC

23.11.17

Gandhidham(
Kachchh)

Barot
Khodabhai
Khetabhai

176

377

Ravat
Rameshkumar
Natvarbhai

SC

20.11.17

Gandhinagar

Ravat
Natvarbhai
Arjanbhai

177

380

Jatin Vijaybhai
Kella

Gen

03.11.17

Bhadara

Vijaybhai
C.Kella

178

387

Vaghani
Ghanshyamkuma
r Lalubhai

Gen

21.11.17

Surat Distt.

Lalubhai
Jerambhai
Vaghani

388

Sureshchandra
Ranchhodbhai
Parekh

Surat Distt.

Ranchhodbhai
Mohanbhai
Parekh

B-105, Meeranagar Udhna
Distt.Surat Gujarat-394210

G/2004/2004
Dt.26.09.04

Marutirao
Nathujirao Buvir

111/B, Kailashnagar
Society, Near Dumbhal Fire
Station, Parvatpatia
Dumbhal Surat Gujarat395002

G/51/2000
Dt.29.02.2000

179

180

389

Harishchandra
Marutirao Bhuvir

Gen

Gen

18.11.17

14.11.17

Surat Distt.

G/1101/2010
Dt.20.06.10
G/46/1993
Dt.05.02.93
G/2493/2003
Dt.15.10.03
G/1897/2010
Dt.26.07.10

G/115/2008
Dt.15.02.08

G/535/2007
Dt.11.06.07

G/2096/2004
Dt.26.09.04

<!-- page 22 -->

181

390

Ms. Dave Artiben
Rohitkumar

Gen

08.12.17

Gandhinagar

Rohitkumar

182

391

Joshi Jignesh
Harshadbhai

Gen

08.12.17

Gandhinagar

Harshadbhai

183

392

Ms. Jadeja
Dharmendraba
Ramsinh

Gen

23.11.17

Rajkot

Jadeja Ramsinh
Hemubhai

184

393

Ms. Parul Chetan
Shah

Gen

16.11.17

Vadodara

Chetan Shah

185

394

Mohammed Arif
Sharfuddin Ansari

Gen

14.11.17

Surat Distt.

186

398

Nimeshkumar
Arvind Gohel

OBC

01.11.17

Jmfc Court
Kathor

187

404

Thakor
Nareshkumar
Varasangji

OBC

26.02.18

Jmfc Visnagar

Varasangji

188

407

Raval Bharat
Khimshankar

Gen

28.02.17

Botad City

Raval
Khimshankar
Manishankar

189

413

Damor
Shanabhai
Virabhai

ST

30.01.18

Dahod

Damor Virabhai
Kacharbhai

Mohammed
Sharfuddin
Ashmoammed
Ansari
Arvindbhai
Shantibhai
Gohel

Bunglows No.15,
Meghdhanushya Vibhag-1.
Dholeswar Mandir Road,
Randesangam
Gandhinagar Gujarat382007
Plot No.1237/2, Sector-7/D,
Gandhinagar Gujarat382007
Vaidehi, Ashapura Society
Gondal, Rajkot Main Road,
B/H, Ashapura Provision
Store Rajkot Gujarat360311
B/179, Amit Nagar Society,
VIP Road, Near Amit Nagar
Circle Vadodara Gujarat390018
3b, Ansar House, B/56-58,
Zainab Park Societym Near
Alvi Row House, Gorat
Surat Gujarat-395009
Flat No. 306, Gajanan
Apartment, Kamrej, Surat,
Gujarat - 394 180.
At. Gothava Vaghajipura,
Ta. Visnagar Mahesana
Gujarat-384315
54/B, Sawastik Society,
Paliyad Road Botad
Gujarat-364710
At. Motiav Po. Pahad Ta.
Limkheda Distt.Dahod
Gujarat-389140

G/1034/1999
Dt.21.03.99

G/72/2007
Dt.02.03.07

G/2710/2010
Dt.28.8.10

G/177/1995
Dt.28.01.95

G/62/2005
Dt.12.02.05
G/1579/2008
dt. 07.09.08
G/646/2008
Dt.27.06.08
G/2668/2005
Dt.24.09.05
G/1880/2002
Dt.11.09.02

<!-- page 23 -->

190

416

Hitesh Jayantilal
Thacker

Gen

12.02.18

Anjar Kutch

Jayantilal
J.Thacker

191

421

Solanki Jayantilal
Pravinbhai

SC

08.03.18

Banaskantha

Pravinbhai
B.Solanki

192

422

Chhotubhai
Vasanji Prajapati

OBC

06.01.18

Valsad

Vasanji
Prajapati

193

423

Ms. Patel
Jagrutiben
Parshottamdas

Gen

25.11.17

Mahmedabad

Patel
Parshottamdas
Revabhai

194

425

Pravinji Chhabaji
Thakor

OBC

12.10.17

Vadgam

Chhabaji

195

431

Chauhan
Vijaysing
Samantsinh

OBC

09.10.17

Civil Court
Ghoghamba

Samantsinh

196

433

Timba Haresh
Lakshmanbhai

OBC

06.10.17

Mangrol
Distt.Junagadh

Lakshmanbhai

197

436

Vimal Vajubhai
Bhadresha

OBC

12.10.17

Mirzapur

Vajubhai J.
Bhadresha

198

437

Pradhyuman
Ochchhavlal
Joshi

Gen

03.10.17

Dakor

Ochchhavlal
Bhikhabhai
Joshi

Plot No.19, Vrindavan
Nagar, Kachchh, Gujarat370110
Chamar Vas Paldi,
At.Po.Paldi Ta. Deodar
Banaskantha Gujarat385330
Malviyaji Road,
Kumbharwad, Near Prajapti
Wadi Valsad Gujarat396001
At.Areri Po. Khatraj Ta.
Mahmedabad Kheda
Gujarat-387130
At.Nagana Colony PostPilucha Ta-Vadgam
Banaskantha Gujarat385421
At. Valinath Post, Farod,
Taluka Ghoghamba
Panchmahals Gujarat389365
Siraj Road, Near
Tower,Junagadh Gujarat362225
C-22, Valbhacharya
Society, B/H Jivraj Park
Society, Ahmedabad
Guajrat-380051
Bhrahm Pole, At.Po. Dakor
Ta. Thasra Kheda Gujarat388225

G/714/1999
Dt.21.03.99
G/123/2006
Dt.29.01.06

G/1047/1991
Dt.24.11.91
G/740/2005
Dt.14.04.05
G/471/2003
Dt.26.04.03

G/873/2001
Dt.21.06.01
G/1955/2003
Dt.31.08.03
G/1309/1999
Dt.21.03.99
G/3430/2000
Dt.23.12.2000

<!-- page 24 -->

199

438

Rajesh Somaiah
Kusuma

OBC

09.10.17

Surat Distt.

Somaiah
Yakaiah
Kusuma

200

439

Vijaykumar
Bansilal Mali

OBC

08.10.17

Surat Distt.

Bansilal
Namdev Mali

201

440

Ms. Lilavatiben
Mangalsing Gohil

Gen

03.01.18

Vasna Road
Vadodara

Narendrasing
Ramsing Raj

202

441

Dipeshkumar
Virendrakumar
Soni

Gen

22.12.17

Met.Court
Gheekanta

Virendrakumar
Soni

203

443

Jadeja
Omdevsinh
Rajendrasinh

Gen

21.12.17

Rajkot

Rajendrasinh
Jilubha Jadeja

204

452

Patel
Kameshkumar

Gen

12.10.17

Bardoli
Distt.Surat

Kantilal

205

456

Ms. Devika
Babubhai Trivedi

Gen

16.09.17

Vadodara City
Area &Distt.

Harshad Mehta

206

458

Pradyumansinh
Bharatsinh Jhala

Gen

14.09.17

Dhrangadhra

Bharatsinh
Balsinh Jhala

90, Madhu Nagar Nr.
Limbayat Police Station,
Opp. Fashion World Tailor,
Udhana Limbayat Surat,
Gujarat-394210
Building No.19.B.2, Flat
No.904, Green City Bhatha
Surat Gujarat-394510
D-40, Samaroan Hosing
Complex, Near Raneshvar
Mahadev Vasna Road
Vadodara Gujarat-390012
3, Chanakya Towerm
Badakdev Ahmedabad
Gujarat-380054
Ashapura Block No.73,
Narayan Nagar Kalavad
Road Rajkot Gujarat360005
3,Shantiniketan Society,B/H
Janta Nager Bardoli Taluka
Bardoli Surat Gujarat394601
105, Aadinath
Society,Behind Bright
School,Vip
Road,Karelibaug, Vadodara
Gujarat-390002
Block No.B/6,Mayur
Bhawan,Nr.Bus Stand
Dharangadhra
Surendranagar Gujarat363310

G/2649/2010
Dt.08.08.10

G/1595/2010
Dt.26.07.10
G/2502/2010
Dt.08.08.10
G/560/2007
Dt.11.06.07
G/726/2007
Dt.18.06.07

G/2253/2003
Dt.15.10.03

G/1003/2000
Dt.05.05.2000

G/2058/2006
Dt.24.07.06

<!-- page 25 -->

207

464

Rathod
Ramessinh
Saratansinh

208

468

Raval
Krushnachandra
Bharatkumar

Gen

05.12.17

Distt.Court
Gandhinagar

Raval
Bharatkumar

209

473

Umeshkumar
Babubhai Patel

OBC

22.12.17

Surat Distt.

Babubhai
Jivanbhai Patel

210

477

Ms.Kevat
Ramshree
Jagdevprasad

Gen

18.12.17

Met.Court
Gheekanta

Jagdevprasad
Kevat

211

488

Rupesh Anadkat
Naginbhai

Gen

25.09.17

Distt.Court
Rajkot

Naginbhai
Narbherambhai
Anadkat

212

489

Sakariya Hitesh
Samatbhai

OBC

25.09.17

Distt.Court
Rajkot

Samatbhai
Ambabhai
Sakariya

213

490

Ms. Nayana
Manubhai
Chauhan

OBC

28.09.17

Nyay Mandir
Vadodara

Manubhai
Vitthalbhai
Chauhan

214

491

Trivedi Chintan
Kantilal

SC

13.10.17

Distt.Court
Gandhinagar

Trivedi Kantilal
Pitambardas

215

495

Ms. Savaliya
Mital Mansukhlal

Gen

27.05.17

Met.Court
Gheekanta

Mansukhlal S.
Savaliya

OBC

20.12.17

Distt. &
Session Court
Gandhinagar

Saratansinh

At- Anodiya Po.
Dodipur,Ta.Mansa
Distt.Gandhinagar Gujarat382855
Plot No.303/2,
Kisannagar,Gandhinagar
Gujarat-382028
A-104,Atmia Residency,B/H
Katargam Police Station,
Kumbharwad Katargam
Surat Gujarat-395004
B-15, Surjit Society-1,
Nr.Ramji Mandir India
Colony,Bapunagar
Ahmedabad, Gujarat382350
203, Radiance
Apt.Nr.Ambika Park Rajya
Road, Rajkot Gujarat360007
Shree
Khodiyarkrupa,Bhramniya
Paraopp.Gurudev Complex,
Pedak Main Road Rajkot
Gujarat-360003
Block No.1009, Sharad
Nagar, Nr. Iti Tarsali,
Vadodara Gujarat-390009
Plotno.1004, Swastik
Society, Sec27,Gandhinagar Gujarat382028
T-401 Icb Flora, Opp. Silver
Nest, Behind Vodafone
Tower Gota Ahmedabad
Gujarat-382481

G/1764/2007
Dt.13.10.07
G/1468/2003
Dt.10.08.03
G/1182/1998
Dt.25.12.98

G/107/2000
Dt.29.02.2000

G/1144/1995
Dt.01.09.95

G/1175/2010
Dt.20.06.10

G/762/2004
Dt.08.05.04
G/1281/2008
Dt.07.09.08

G/665/2008
Dt.27.06.08

<!-- page 26 -->

216

499

Kaushikbhai
Ramanbhai
Sodha

Gen

07.11.17

Nadiad

Ramanbhai
Hathisinh
Sodha
Fulabhai
Harmanbhai
Solanki

217

501

Madhavsing
Fulabhai Solanki

OBC

11.11.17

Petlad

218

504

Ms. Prafullaben

OBC

06.11.17

Gandhinagar

Vasantlal

219

506

Sharma
Yogendra
Ramawtar

Gen

27.12.17

Dantiwada
Colony

Ramawtar

220

507

Rajeshbhai
Ramubhai Warli

ST

21.08.17

Umbergaon

Ramubhai
Bhadiyabhai
Warli

221

509

Ms. Beena
Maganbhai
Maheshwari

Gen

25.12.17

Bhuj-Kutch

Maganlal

222

511

Bhushan
Dattubhai Nandre

Gen

21.11.17

Met.Court
Gheekanta

Dattubhai
Nandre

223

512

Vaghela
Maheshkumar
Najibhai

OBC

21.12.17

Porbandar

Nagjibhai

224

516

Sanjaykumar
Himmatlal
Bhesania

Gen

13.11.17

Amreli

Himmatlal
Gokalbhai
Bhesania

225

519

Daxaben
Natvarlal Ravat

SC

02.11.17

Gadhinagar

Senma
Dineshkumar
Muljibhai

15, Trimurti Society, Pij
Road Nadiad Kheda
Gujarat-387002
Gokulpura At. Pandolo Ta
Petlad Anand Gujarat388160
Plot No.575/2, GF-2,
Satyam Flat Sector No.30,
Gandhingar Gujarat-382030
25, Brahmani Shopping
Centre Taluka Panchayat
Road, Dantiwada Colony
Ta. Dantiwada,
Banaskantha Gujarat385505
At.Zaroli Post Chhipawad,
St Bhlad Ta. Umbergaon
Valsad Gujarat-396112
Plot No.58, Sumangalam
Vrundavan Park Madhapar
Kachchh Gujarat-370001
33, Rajeshwari Society, Nr.
Bobin Factory, Ranip
Ahmedabad Gujarat382480
Chamunda Krupa,
Dhobivada, Madhavpur
Ghed Porbandar Gujarat362230
Keriaroad, Rokadvadi,
Manekpara,Street No.17,
Amreli Gujarat-365601
GEB, Gandhinagar Road,
Behind Nursary Chiloda
Mota Ta. Distt.Gandhinagar
Gujarat-382355

G/1717/2005
Dt.17.07.05
G/797/2008
Dt.05.07.08
G/362/1983
Dt.06.07.83

G/1660/2003
Dt.10.08.03

G/408/2010
Dt.04.04.10
G/338/2009
Dt.28.03.09
G/1118/2003
Dt.20.07.03

G/96/2001
Dt.24.02.01
G/1301/2007
Dt.30.07.07
G/344/2010
Dt.09.02.10

<!-- page 27 -->

226

522

Vaghela
Manusinh Chelaji

Gen

09.11.17

Palanpur

Vaghela Chelaji
Godadji

Meta At.Po.Meta TaVadgam Banaskantha
Gujarat-385520

G/88/2007
Dt.02.03.07

227

523

Ravat
Bhaveshkumar
Kanabhai

SC

30.12.17

Distt. &
Session Court
Mehsana

Kanabhai

At.Mulsan, Ravat Sheri Ta.
Mehsana Gujarat-382710

G/567/1993
Dt.13.08.93

228

524

Puiyush
Himmatbhai
Kantharia

SC

30.12.17

Surat

Himmatbhai
Prabubhai
Kantharia

229

528

Gamit
Sanjaykumar
Shantilal

ST

13.12.17

Vyara
Distt.Tapi

Gamit Shantilal
Duliyabhai

230

531

Nareshbhai
Jingabhai Rathva

ST

22.04.18

Chhotaudepur

Jingabhai
Ganjubhai

231

532

Patel Mukeshbhai
Gandabhai

Gen

11.05.18

Distt.Court
Mehsana

Patel
Gandabhai

232

533

Patel
Kamleshkumar
Ranchhodbhai

Gen

08.05.18

Distt.Court
Mehsana

Patel
Ranchhodbhai

233

534

Kanaiyalal Galabji
Thakor

OBC

17.03.18

Met.Court
Gheekanta

Galabji
S.Thakor

234

535

Solanki
Jigneshkumar
Hargovindas

SC

10.05.18

Mehsana

Solanki
Hargovindas
Nanabhai

235

536

Zala Jalusinh
Dansinh

OBC

16.06.18

Himatnagar
Distt.

Zala Dansinh
Fatesinh

A-41, Ambica Row House,
Nr.Kamrej Cross Road,
Taluka Kamrej Surat
Gujarat-394185
31, Panchwati Park,
Andharwadi Road Vyara,
Ta.Vyara Distt.Tapi Gujarat394650
At.Po Dahndhoda, Mohan
Faliya, Ta Chhotaudepur,
Gujarat-391165
Kamalpur (Kh), Ta.Visnagar
Mahesana Gujarat-384305
73, Shyamvihar Bunglows
Part-1, Opp. Avshar Party
Plot Modhera Road
Mehsana Gujarat-384002
Thakorvas, Gam Memadpur
Daskroi Ahmedabad
Gujarat-382449
14/A, Sarvodya Society
Part-2, Near Head Post
Office, Visnagar Road
Mehsana Gujarat-384001
At.Po,Nava Ta.Himatnagar
Distt.Sabarkantha Gujarat383001

G/1813/2007
Dt.13.10.07

G/1854/2007
Dt.29.11.07
G/338/2003
Dt.22.02.03
G/977/2004
Dt.10.07.04
G/116/2008
Dt.15.02.08
G/679/2000
Dt.05.05.2000
G/547/2005
Dt.05.03.05
G/938/1994
Dt.09.10.94

<!-- page 28 -->

236

537

Suthar
Pragnaben
Damodardas

237

538

Chavda
Gautamkumar
Kantilal

SC

10.05.18

Mehsana

Chavda Kantilal
Manabhai

238

539

Ms. Zaveri
Manisha
Bharatkumar

Gen

06.07.18

Ahmedabad

Bharatkumar

239

540

Sanjay Paljibhai
Makwana

SC

07.07.18

Met.Court
Gheekanta

Paljibhai
Makwana

240

541

Vimalkumar
Bavabhai Rathod

SC

09.11.17

Surat

Bavabhai
Valjibhai
Rathod

241

543

Dharmendrasinh
Gajendrasinh
Peshrana

OBC

31.10.17

Panchmahals

Gajendrasinh
Prabhatsinh
Peshrana

242

544

Ms. Dina
Ashokkumar
Nayak

OBC

21.09.17

Ahmedabad

Ramanlal B
Nayak

243

552

Pankajkumar
Parmar

SC

05.04.16

Ahmadabad
City

Vijaybhai
Parmar

OBC

16.06.18

Himatnagar
Distt.

Suthar
Damodar
Maganlal

18-A, One Society,
Motipura Himatnagar
Sabarkantha Gujarat383001
20/A.K.Nagar Near
Hirannagar Somnath Road,
Mahesana Gujarat-384001
O-206, Sun Real Homes,
B/H Savan Bunglows Nr.
GST Crossing, Khodiyar
Temple New Ranip,
Ahmedabad Gujarat382470
31, Chhotubhai Co.Op.
Hous. Society, Nr. Chhipa
Kabrastan Geeta Mandir
Road Ahmedabad Gujarat380022
3,Punit Nagar Society,
Palanpur Patiya Rander
Road Surat Gujarat-395009
Pramukh Ashish, Holi
Chakla Near Bus Station
Ghoghamba Panchmahals
Gujarat-389365
5/6, Tulsivan Society, Nr.
Shaivali Bus Stand Vejalpur
Road,Ahmedabad Gujarat380051
141/76 Raichand Meghraj
Ni Chal Tulsi Kanta
Amdupura Naroda Road
Ahmedabad,Ahmadabad,G
ujarat

G/2907/1999
Dt.04.07.99
G/1497/2001
Dt.07.08.01

G/68/2010
Dt.17.01.10

G/1808/2004
Dt.14.08.04

G/2131/2005
Dt.06.08.05
G/840/2001
Dt.21.06.01

G/598/1999
Dt.21.03.99

G/889/1995
Dt.28.07.95

<!-- page 29 -->

244

554

Patel
Jigneshkumar
Ganpatbhai

245

557

Patel
Manojkumar
Jeshingbhai

SC

27.09.16

Kalol

JESHINGBHAI
ALJIBHAI
PATEL

246

563

Patel
Rajeshkumar
Prahladbhai

Gen

07.06.16

Kalol

PRAHLADBHAI

247

570

Prajapati
Dilipbhai
Nagjibhai

OBC

09.03.16

Kalol

NAGJIBHAI
RUGHNATHBH
AI PRAJAPATI

248

572

Singh Ajay
Gulabsingh

Gen

26.07.16

Palanpur

GULABSINGH

249

574

Mohan Manjibhai
Kanjariya

OBC

17.08.16

Kalyanpur

MANJIBHAI
SAMATBHAI
KANJARIYA

250

582

Jayshree
Rameshkumar
Davda

OBC

09.02.17

Bhuj

UMRANIYA
RAVJI GOVIND

Gen

05.05.16

Ahmadabad
City

Ganpatbhai

18 Kamlesh Park Society
B/H Priya Cinema Nr
Prakash Hindi School Po
Krishnanagar Saijpur
Bogha,Ahmadabad,Gujarat
26 AMBIKA NAGAR
SOCIETY NANI KADI
TALUKA
KADI,MAHESANA,GUJAR
AT
MOTOVAS AT
RAMNAGAR TA
KALOL,GANDHINAGAR,G
UJARAT
BLOCK NO 9 AAVKAR
SOCIETY NEAR PANJRA
POLE OPP GAYATRI
MANDIR AT KALOL
,GANDHINAGAR,GUJARA
T
38 SHASTRINAGAR
GOBRI ROAD
PALANPUR,BANAS
KANTHA,GUJARAT
MAHAKALI GARBI
CHOWK AT AND POST .
JAMKALYANPUR DIST
DEVBHUMI
DWARKA,JAMNAGAR,GUJ
ARAT
SHREE HARI
OPP.SORATHIA SAMAJ
VADI NAVA VAS
MADHAPAR
TAL.BHUJ.KACHCHH,KAC
HCHH,GUJARAT

G/1123/2000
Dt.05.05.2000

G/2249/2000
Dt.09.09.2000

G/1042/2001
Dt.21.06.01

G/1193/2008
Dt.26.07.08

G/2742/2005
Dt.24.09.05

G/3184/2005
Dt.28.10.05

G/34/2006
Dt.29.01.06

<!-- page 30 -->

251

583

Mukesh
Tulshibhai
Khanna

252

585

Sanjaykumar
Jayantilal Modi

OBC

20.03.17

Palanpur

JAYANTILAL

253

586

Parmar Bhavesh
Narsinhbhai

SC

22.11.16

Ahmadabad
City

Narsinhbhai
Bhalabhai

254

590

Rekhaben
Himanshu Trivedi

Gen

14.09.16

Himatnagar

JATASHANKA
R PANDYA

255

593

Mishra Neeraj
Vijaynarayan

Gen

03.10.17

Ahmadabad
City

Mishra
Vijaynarayan

256

596

Manhar Manibhai
Patel

Gen

28.10.16

Ahmadabad
City

Manibhai K.
Patel

257

599

Mehta Nilesh
Sureshbhai

Gen

11.08.16

Bhavnagar

SURESHBHAI
RATILAL
MEHTA

602

Prajapati
Ashokkumar
Shankarlal

Modasa

PRAJAPATI
SHANKARLAL
DHARMABHAI

258

SC

20.03.17

Palanpur

TULSHIBHAI

OBC

11.12.16

15 NRUSINH KRUPA
AMBEDKAR SOCIETY
NEW LAXMIPURA
PALANPUR,BANAS
KANTHA,GUJARAT
A6 DHARTI TOWNSHIP
AKESAN ROAD
AHMEDABAD HIGHWAY
PALANPUR,BANAS
KANTHA,GUJARAT
30 Siddhi Society B/H
Vaijnath Mahadev Temple
Makarba Road Vejalpur
Ahmedabad,Ahmadabad,G
ujarat
MOONLIGHT BEHIND
TRIVEDI TRADER NAVA
BAZAR
HIMATNAGAR,SABAR
KANTHA,GUJARAT
A 18 Chunnilal Park Society
Opp Baroda Xpress
Highway C T
M,Ahmadabad,Gujarat
1 Shantimani Society Nr K
K Nagar Cross Road
Ghatlodiya,Ahmadabad,Guj
arat
FLAT NO. 202 GAUTAM
PARK. CHITRANJAN
CHOWK.
VIDHYANAGAR,BHAVNAG
AR,GUJARAT
AT . PO . SAKARIYA TA .
MODASA
,ARVALLI,GUJARAT

G/178/1998
Dt.08.03.98

G/389/1996
Dt.08.03.96

G/1394/2008
Dt.07.09.08

G/888/1995
Dt.28.07.95

G/600/2006
Dt.18.03.06

G/203/1984
Dt.22.02.84

G/1196/2001
Dt.21.06.01

G/928/2004
Dt.10.07.04

<!-- page 31 -->

259

603

Kamleshkumar
Devendraprasad
Joshi

260

606

Nagjibhai
Vaghabhai Asal

SC

23.11.16

Vav

VAGHABHAI
MADEVBHAI
ASAL

261

607

Datania
Kirtikumar
Bapalal

OBC

23.01.17

Ahmadabad
City

Bapalal

262

610

Sarvaiya
Jayshree Harilal

SC

15.12.16

Bhavnagar

HARILAL

263

612

Kirtika Jayntilal
Makwana

SC

16.01.17

Vadodara

JAYNTILAL
MAKWANA

264

613

Dhruva Ketan
Trivedi

Gen

12.08.16

Surat City

Anantray Joshi

265

616

Parmar
Bhailalbhai
Narsangbhai

ST

12.07.16

Bharuch

Narsang
Parmar

266

617

Mukeshbhai
Mahijibhai Raval

OBC

12.07.16

Bharuch

Mahijibhai
Raval

267

618

Patel Mukeshbhai
Manubhai

Gen

15.12.16

Vaso

MANUBHAI

Gen

17.11.16

Chorasi

DEVENDRAPR
ASAD

B.6 FLAT NO. 103
AXARDHAM
APPARTMENT CHHAPRA
BHATHA ROAD AMROLI
SURAT,SURAT,GUJARAT
AT.DETHALI PO.DETHALI
TA.WAV,BANAS
KANTHA,GUJARAT
1001/3 Navi Vadwali Pole
Opp Nagoriwad Shahpur
Ahmedabad,Ahmadabad,G
ujarat
PLOT NO 323A SHAKTI
NIVAS NEAR APPU
TREDRASS
ANANDNAGAR ROAD
BHAVNAGAR,BHAVNAGA
R,GUJARAT
13 SANJU NAGAR B/H
GUJRATI SCHOOL
GOTRI,VADODARA,GUJA
RAT
H.1/101 Omkar Residency
Palanpur Canal Road
Palanpur
Jakatnaka,Surat,Gujarat
2571 Ayodhyanagar Link
Road
Bharuch,BHARUCH,GUJA
RAT
22 Odvas Jambusar
Bharuch,BHARUCH,GUJA
RAT
BHRAMPOLE NEAR
SWAMINARAYAN TEMPLE
VASO,KHEDA,GUJARAT

G/814/1999
Dt.21.03.99

G/1396/2001
Dt.07.08.01
G/291/2001
Dt.26.03.01

G/827/2001
Dt.21.06.01

G/1184/2008
Dt.26.07.08

G/1209/2002
Dt.31.07.02

G/3359/2005
Dt.18.12.05
G/341/1997
Dt.20.12.97
G/953/1991
Dt.17.10..91

<!-- page 32 -->

268

620

Arvindkumar
Prabhatbharthi
Goswami

269

621

Joshi
Shradhdhaben
Durgashankar

Gen

13.12.16

Bhiloda

DURGASHANK
AR

270

624

Rathod
Indrajitsinh
Amarsinh

Gen

14.12.16

Bhiloda

AMARSINH

271

625

Hardik Bharatbhai
Bhatt

Gen

30.12.16

Ahmadabad
City

Bharatbhai S
Bhatt

272

627

Tayde Hemant
Anandbhai

Gen

31.12.16

Ahmadabad
City

Anand Bhai
Tayde

273

630

Bhagat
Dilipkumar
Dhulabhai

OBC

23.01.17

Anand

BHAGAT
DHULABHAI
SHANKARBHAI

274

637

Patel Amrutbhai
Ranchhodbhai

OBC

21.12.16

Talod

PATEL
RANCHHODBH
AI NATHUBHAI

275

640

Prajapati
Ravikumar
Babubhai

OBC

02.06.17

Ahmadabad
City

Babubhai N
Prajapati

OBC

19.01.17

Amreli

PRABHATBHA
THI

GOKULDHAM SOCIETY 1
OPP JALARAMNAGAR
HANUMANPARA ROAD
AMRELI,AMRELI,GUJARA
T
AT.PO.NAVABHAVNATH
TA.BHILODA
DIST.ARVALLI,ARVALLI,G
UJARAT
36 RATHOD FALI
AT.PO.DHAMBOLIYA
TA.BHILODA
DIST.ARVALLI,ARVALLI,G
UJARAT
4/K/482 Vivekanand Nagar
Hatijan
Ahmedabad,Ahmadabad,G
ujarat
34 Shrushti Bunglows B/H
Janta Nagar Chandkheda
Ahmedabad,Ahmadabad,G
ujarat
OPPOSITE PRIMARY
SCHOOL AT VAGHASI
,ANAND,GUJARAT
AT.TALODGAM OPP
MAHADEV TEMPLE
TAL.TALOD,SABAR
KANTHA,GUJARAT
D 75 Indrajit Society Nr
Thakkarbapa Nagar Nikol
Gam Road
Ahmedabad,Ahmadabad,G
ujarat

G/996/1999
Dt.21.03.99

G/136/1999
Dt.13.12.99

G/1504/2000
Dt.22.07.2000

G/119/2006
Dt.29.01.06

G/1095/2003
Dt.20.07.03
G/2795/2003
Dt.30.12.03
G/464/2003
Dt.26.04.03

G/612/2008
Dt.27.06.08

<!-- page 33 -->

276

641

Joshi
Swetakumari
Pravinkumar

277

642

Chauhan
Arvindkumar
Dalpatsinh

OBC

24.12.16

Vijaynagar

Chauhan
Dalpatsinh
Jethusinh

278

650

Nalinchandra
Jayntilal Ahya

Gen

27.12.16

Rajkot

Jayntilal Ahya

279

656

Jasvantsinh
Vaghela

Gen

31.12.16

Vadodara

Amarshih

280

659

Kesari Simaben
Kamleshbhai

Gen

30.12.16

Bhavnagar

Chelaram

281

660

Rohitkumar
Maneklal Bhavsar

Gen

31.12.16

Padra

Maneklal
Narandas
Bhavsar

282

661

Bhatt
Devangkumar
Chandrashankar

Gen

30.12.16

Dabhoi

Bhatt
Chandrashanka
r R.

283

664

Chirag Mistry

Gen

01.05.17

Vadodara

Hasmukhbhai

Gen

02.06.17

Ahmadabad
City

Pravinkumar B
Joshi

21 New Rajesthan Society
Nr Anil Mill
Bapunagar,Ahmadabad,Guj
arat
At Post. Kalvan Vasahat
Taluka. Vijaynagar Dist.
Sabarkantha,Sabar
Kantha,Gujarat
Jaliyan 5 Saurashtra Kala
Kendra Nr. Paras Hall
Nirmala Convent Road
Rajkot,Rajkot,Gujarat
At Post Sevada Ta
Tilakwada Dist
Narmada,NARMADA,GUJA
RAT
Plot No.67 Line No.7
Vivekanand Park
Sindhunagar Mokshmandir
Road
Bhavnagar,Bhavnagar,Guja
rat
49 Narsinhnagar Society
Near Old Bus Depot
Padra,Vadodara,Gujarat
Ambica Bhuvan Subhash
Tekro At And Post Chandod
Ta
Dabhoi,Vadodara,Gujarat
B 13 Viharkunj Soc Opp
Vihar Cinema Beside
Ranmukteshwar Mandir
Pratapnagar Road
Vadodara,Vadodara,Gujarat

G/658/2008
Dt.27.06.08

G/1121/1999
Dt.21.03.99

G/2001/2004
Dt.26.09.04

G/1386/2004
Dt.14.08.04

G/1319/2004
Dt.10.07.04

G/733/1989
Dt.11.09.89
G/2760/1999
Dt.04.07.99

G/2938/2006
Dt.02.12.06

<!-- page 34 -->

284

665

Jitendra
Pundalikrao
Borkar

285

668

Rohit Snehalben
Muljibhai

SC

01.01.17

Vadodara

Muljibhai D
Rohit

286

669

Chandrashekhar
Rao

OBC

01.04.17

Savli

Vishnuprasad

287

670

Dave Mehul
Bhupendrabhai

Gen

01.03.17

Chotila

Dave
Bhupendrabhai
Vrajlal

288

673

Thakor Hemal
Somaji

OBC

03.10.17

Palanpur

Thakor Somaji
Kasaji

289

676

Jitendrakumar
Haribhai Thakor

Gen

01.05.17

Surat City

Haribhai
Nathusinh
Thakor

290

677

Sharma Rajnikant

OBC

01.10.17

Lunawada

Chimanbhai

291

681

Laljibava
Abhesinh
Padhiyar

Gen

01.08.17

Padra

Abhesinhji R
Padhiyar

292

685

Rajendrasinh
Navalsinh Jadeja

Gen

24.04.17

Lalpur

Navalsinh

293

686

Ajaykumar
Chaudhari

Gen

01.10.17

Mahesana

Karshanbhai
Chaudhari

Gen

31.12.16

Vadodara

Pundalikrao A
Borkar

47 Kashiba Nagar Society
Behind Sardar Estate Ajwa
Road
Vadodara,Vadodara,Gujarat
E.114 Devnagar Saiyad
Vasna
Road,Vadodara,Gujarat
At Po Savali Ta Savali
Vadodara,Vadodara,Gujarat
Parishram Opp Court
Building
Chotila,Surendranagar,Guja
rat
Juna Telephone Exchange
Mahila Mandal
At.Palanpur,Banas
Kantha,Gujarat
16 Surya Row House Opp
Shree Ram Marble Althan
Bhatar Road,Surat,Gujarat
At Po Dhesiya Ta
Lunawada Dist Mahisagar
Ta
Lunawada,Mahisagar,Gujar
at
To. Chokari(Shahpura) Ta.
Padra Nr. Bsnl
Tower,Vadodara,Gujarat
Rajshakti Near Gayatri
Society
Lalpur,Jamnagar,Gujarat
23 Sharnam Villa Bunglows
Nr Saurabh School
Radhanpur Road
Mahesana
2,Mahesana,Gujarat

G/1549/2001
Dt.07.08.01
G/1728/2008
Dt.02.10.08
G/1607/2009
Dt.11.09.09
G/2168/1999
Dt.21.03.99

G/2209/2005
Dt.06.08.05
G/1298/1995
Dt.11.10.95

G/105/2002
Dt.03.01.02

G/2772/2006
Dt.02.12.06
G/288/2005
Dt.12.02.05

G/641/1984
Dt.23.08.84

<!-- page 35 -->

294

687

295

691

296

701

Archana
Nimeshkumar
Patel
Chavda
Hemabhai
Shankarbhai
Kamleshkumar
Girishbhai
Makwana
Chandbibi
Mahebubbhai
Bahelim
Miteshkumar
Rameshbhai
Patel

Gen

01.11.17

Vadodara

Amrutlal

OBC

01.11.17

Viramgam

Chavda
Shankarbhai
Bhagvanbhai

5 Dipak Nagar Society Opp
Mehsana Nagar Garba
Ground
Nizampura,Vadodara,Gujar
at
At Po Dumana Viramgam
Viramgam,Ahmadabad,Guj
arat

SC

20.01.17

Amod

Girishbhai L
Makwana

Aamli Pura Vankarvas
Amod,Bharuch,Gujarat

Gen

17.01.17

Vaghodia

Yusufbhai
Sulemanbhai
Sindhi

Gen

17.01.17

Vadodara

Rameshbhai

Gajjar
Deepakkumar
Jayantilal

Gen

18.01.17

Dabhoi

Jayantilal

712

Pathak
Bhaskarbhai
Hiralal

Gen

18.01.17

Dabhoi

Hiralal

301

713

Jaymin Sheth

Gen

18.01.17

Savli

Mahendrabhai

302

714

Vipulkumar
Ashwinbhai Shah

Gen

18.01.17

Savli

Ashwinbhai
Shah

303

715

Vikramsinh
Parmar

Gen

18.01.17

Savli

Ganpatsinh

297

703

298

706

299

708

300

G/1031/2008
Dt.26.09.08

G/479/2003
Dt.26.04.03
G/1177/2009
Dt.08.08.09

At.Po. Falod Ta. Waghodia
G/1990/2008
Dist Vadodara Waghodia
Dt.27.12.08
Vadodara,Vadodara,Gujarat
A 34 Castle White Near
G/1625/2000
Motnath Tample
Dt.22.07.2000
Harni,Vadodara,Gujarat
Opp.Vakil Banglow Hira
Bhagol Road
G/1154/2000
At.Po.Ta.Dabhoi,Vadodara, Dt.05.05.2000
Gujarat
Pathak Faliya
At.Po.Kayavarohan
G/319/1984
Ta.Dabhoi,Vadodara,Gujara
Dt.29.04.84
t
Azad Pole Gandhi Chowk
G/594/1989
At And Post Savali Dist
Dt.24.07.89
Vadodara,Vadodara,Gujarat
14 Krushna Park Society
Near Reliance Petrolpump G/2511/2003Dt
At And Post Savali Dist
.15.10.03
Vadodara,Vadodara,Gujarat
At And Post
Parthampura(Shihora) Ta
G/4139/1999
Savali Dist
Dt.19.09.99
Vadodara,Vadodara,Gujarat

<!-- page 36 -->

719

Pragna Amrutlal
Bhagat

OBC

31.01.17

Surat City

Amrutlal
Somabhai
Bhagat

305

722

Mrunal
Arvindkumar
Parikh

Gen

21.01.17

Dohad

Arvindkumar
Mithalal Parikh

306

729

Gen

28.01.17

Patan

Rameshray

307

730

Gen

03.03.17

Patan

Somabhai

308

731

Kirtanben
Krishnabhai
Salve

SC

02.09.17

Surat City

Krishnabhai
Ragho Salve

309

735

Ajaysinh
Mandansinh
Chauhan

OBC

25.01.17

Rajkot

Madansinh
Karansinh
Chauhan

310

737

Parmar
Pratapsinh
Madarsinh

Gen

25.01.17

Sihor

Parmar
Madarsinh

311

738

Dipesh Kanubhai
Desai

Gen

29.01.17

Vadodara

Kanubhai Desai

312

747

Joshi Keyurkumar
Maheshkumar

Gen

02.09.17

Visnagar

Maheshkumar

313

748

Modi
Kaushikkumar
Ramnarayan

OBC

02.09.17

Visnagar

Ramnarayan

Maniyarvado Tower Bazar
Visnagar,Mahesana,Gujarat

G/1038/2001
Dt.21.06.01

314

753

Shukla
Kaushikbhai

Gen

02.01.17

Kheralu

Bholanath

Brahmanvas Near Kharikui
Kheralu At.Po.Ta.Kheralu
,Mahesana,Gujarat

G/631/1990
Dt.05.08.90

304

Vora Angiras
Rameshray
Patel Pinalkumar
Somabhai

2220 Kuva Wadi Opp Ekta
Service Station Nanpura
Surat,Surat,Gujarat
Ramkrishna Nivash Gokul
Society . Ii Chakalia Road
Laxmi Mill
Road,Dohad,Gujarat
Ganesh Sheri Nagarwado
,Patan,Gujarat
2 Mavjinagar Society At Po
Balisana ,Patan,Gujarat
E.401 Shreepad Ethics Nr
Raj World New L P Savani
School Road Palanpur
Surat,Surat,Gujarat
Nishi Appartment Flat No
201 B/H Prabhat Hospital
Nr. Shorf Road
Rajkot.,Rajkot,Gujarat
Village.Tana Taluko.Sihor
Dist.Bhavnagar,Bhavnagar,
Gujarat
C.81 Samarpan Park
Society Near Bapod Jakat
Naka Waghodiya Road
Vadodara,Vadodara,Gujarat
9a Saraswati Society
Kamana Road
Visnagar,Mahesana,Gujarat

G/2174/2002
Dt.11.09.02
G/1853/2001
Dt.18.09.01
G/168/1987
Dt.09.03.87
G/3362/2006
Dt.30.12.06
G/4557/1999
Dt.24.10.99

G/1190/2004
Dt.10.07.04
G/960/1991
Dt.17.10.91
G/1407/2005
Dt.03.07.05
G/2868/2001
Dt.04.11.01

<!-- page 37 -->

315

756

Sheela
Devrajbhai
Jodhani

Gen

02.03.17

Surat City

Devrajbhai
Lavabhai
Jodhani

316

759

Sunitaben Sheth

Gen

27.02.17

Godhra

Vedprakash
Dube

317

763

Sendhav
Govindbhai
Somabhai

OBC

02.08.17

Sami

Somabhai

318

769

Patel Naginbhai
Ishwarbhai

Gen

27.02.17

Vadodara

Patel
Ishwarbhai
Khushalbhai

319

770

Patel Ghanshyam
Popatbhai

Gen

02.09.17

Ahmadabad
City

Patel Popatbhai
Ranchhodbhai

320

772

Pandya
Jagdishkumar
Ravishankar

Gen

05.03.17

Mahesana

Jagdishbhai

321

773

Patel Vinubhai
Amichandbhai

Gen

02.08.17

Prantij

Patel
Amichandbhai
Kalidas

322

781

Ilaben
Chandubhai
Parekh

OBC

03.05.17

Vadodara

Chandubhai
Parekh

323

782

Shah Kiritkumar
Shantilal

Gen

25.02.17

Vadodara

Shah Shantilal
Jivanlal

31 Laxminarayan Society
Laxmikant Asharm Road
Katargam
Surat,Surat,Gujarat
7 Vardhman Nagar Nr.
Science College Ground
Kasudi Road,Panch
Mahals,Gujarat
Sindhvai Nagar Society
Khandiya Road At Post
Shankheshwar,Patan,Gujar
at
At And Post Bharthana Ta.
Karjan Ta.
Karjan,Vadodara,Gujarat
2094 Vaidh Sheri Khara
Kuva Nr. City Survey Office
Sarkhej Ahmedabad
,Ahmadabad,Gujarat
10 Sunrice Park Society
Opp Nagalpur College
Highway
Mehsana,MAHESANA,GUJ
ARAT
At Po. Vadvasa Ta. Prantij
Patel Vas,Sabar
Kantha,Gujarat
A 34 Pushpak Township
Opp Reliance Cricket
Stadium At And Post
Undera
Vadodara,Vadodara,Gujarat
34.B Udyog Nagar Society
Near Ayurvadic Collage
Waghodia
Road,Vadodara,Gujarat

G/1247/2009
Dt.08.08.09

G/305/2008
Dt.17.05.08

G/638/1996
Dt.30.03.96
G/433/1978
Dt.09.09.78
G/906/2001
Dt.21.06.01

G/3216/2006
Dt.29.12.06

G/739/1999
Dt.21.03.99

G/962/2004
Dt.10.07.04

G/831/1995
Dt.14.07.95

<!-- page 38 -->

324

783

Panna
Jitendrabhai
Dodiya

SC

03.01.17

Ahmadabad
City

Jitendrabhai D
Dodiya

325

786

Bhadra
Karshandas
Ratanshibhai

Gen

03.04.17

Vapi

Bhadra
Ratanshibhai

326

789

Bharatkumar B.
Patel

Gen

16.02.17

Ahmadabad
City

Bhikhabhai
Manjibhai Patel

799

Jahvantsinh
Pruthviraj
Vaghela

OBC

23.02.17

Palanpur

PRUTHVIRAJ
VAGHELA

800

Shivsagar
Thakorbhai Patel

Morvi

THAKORBHAI
JADAVJIBHAI
PATEL

329

802

Vijaykumar
Satyendra Shinde

Gen

15.02.17

Vadodara

SATYENDRA
SADASHIV
RAO SHINDE

330

803

Bhavnabahen
Chimangiri
Goswami

OBC

20.02.17

Visnagar

CHIMANGIRI

327

328

Gen

28.02.17

2 A The Shramjivi
Adharshnagar Society Nr
Manmohan Society Everest
Cinema Cross Road
Saraspur
Ahmedabad,Ahmadabad,G
ujarat
D.204 Siddhi Co Op Hsg
Soc Ltd Plot No . 415
Koparli Road
Opposite.Sarvajanik
Highschool Near.Ambamata
Temple Plot No 415 Gidc
Vapi,Valsad,Gujarat
B/31 Nilkanth Society Nr.
Ram Rajyanagar Opp. Shiv
Park Odhav Ahmedabad
,Ahmadabad,Gujarat
At.Po.Ghada Ta.Deesa
.,Banas Kantha,Gujarat
502 Rameshwar
Appartment Vaibhav Laxmi
Society Village Ravapar
Dist Morbi,Morbi,Gujarat
6 Vihar Society Opp Akota
Garden Main Gate Near Rc
Patel Esate
Akota,Vadodara,Gujarat
20 Ishwarkrupa Society B/H
Iti Opp Vaibhavnagar
Society N A Area At
Visnagar,Mahesana,Gujarat

G/152/2002
Dt.03.01.02

G/1093/2006
Dt.21.06.06

G/3307/1999
Dt.08.08.99
G/883/2003
Dt.02.07.03
G/1934/2006
Dt.24.07.06

G/248/1973
Dt.30.07.73

G/1174/2004
Dt.03.12.04

<!-- page 39 -->

331

804

Ravindra
Vishrambhai
Gupta

332

808

Joshi Nailesh
Mahendrakumar

Gen

23.02.17

Palanpur

Mahendrakuma
r

333

810

Sanjaykumar
Ramanlal Maheta

OBC

17.02.17

Surat City

Ramanlal
Maganlal
Maheta

334

812

Smita Natvarbhai
Vaghela

SC

03.05.17

Vadodara

Ramabhai
Parmar

335

814

Boghani Ejaj Aziz

OBC

16.03.17

Jetpur

Aziz

336

815

Nileshkumar
Maganlal
Jotangia

OBC

22.02.17

Surat City

Maganlal

337

817

Ami Babubhai
Vakharia

Gen

23.02.17

Surat City

Babubhai
Kantilal
Vakharia

338

818

Ravi Rameshbhai
Tank

OBC

23.02.17

Rajkot

Rameshbhai
Tank

339

820

Pareshkumar
Hasmukhbhai
Patel

Gen

27.02.17

Ahmadabad
City

Hasmukhbhai K
Patel

OBC

03.01.17

Ahmadabad
City

Vishrambhai A
Gupta

107 Society Chali Nr
Jantanagar A E C Road
Amraiwadi
Ahmedabad,Ahmadabad,G
ujarat
22 Ankit Society Behind
Neesarg Honda Deesa
Highway Palanpur,Banas
Kantha,Gujarat
44 Henirut. Sargam Row
House. Kim. Olpad
,Surat,Gujarat
C.102 Saraswati Nagar
New Sama Raod Near
Kailaspati Mandir
Vadodara,Vadodara,Gujarat
Old Panch Pipla Road
Jagdish Plot
Jetpur,Rajkot,Gujarat
204 Giriraj Appartment
Daya Park Society Karanj
L.H. Raod,Surat,Gujarat
Flat No 105/B Badri Mahal
Apartment Nr Ambika
Niketan Parle Point Surat
City,Surat,Gujarat
Ravi 1 Sorathiya Wadi Nr
Yogiraj,Rajkot,Gujarat
6 Saffron Shukan 6 Opp
Science City Sola
Ahmedabad,Ahmadabad,G
ujarat

G/57/2006
Dt.29.01.06

G/398/2003
Dt.22.02.03
G/86/2005
Dt.12.02.05
G/584/2005
Dt.14.04.05
G/1045/2008
Dt.26.07.08
G/661/2005
Dt.14.04.05
G/2474/2001
Dt.07.10.01
G/1023/2009
Dt.11.07.09
G/2301/2002
Dt.23.09.02

<!-- page 40 -->

340

822

Joshi Sudhirbhai
Ratanshibhai

341

825

Kripa Ram

OBC

23.02.17

Vadodara

Ajudhya Prasad

342

826

Navinchandra
Uttamchand Shah

Gen

23.02.17

Karjan

Uttamchand
Dalichand Shah

343

828

Barad
Jayendrasinh
Ramsinh

Gen

25.03.17

Danta

Ramsinh
Joravarsinh
Barad

344

830

Rajaram
Shukhadev Raut

Gen

23.02.17

Vadodara

Shukhadev
Raut

345

831

Dhansukhbhai
Khusalbhai
Maisuria

OBC

24.02.17

Surat City

Khusalbhai
Gomanbhai
Maisuria

346

833

Trivedi
Priteshkumar
Vishnuprasad

Gen

28.02.17

Himatnagar

Trivedi
Vishnuprasad
Madhalal

347

834

Jitendrakumar
Harilal
Dhrangdhariya

OBC

26.02.17

Rajkot

Harilal
Bhavanbhai
Dhrangdhariya

Gen

03.02.17

Deodar

Ratanshibhai

47 Purusotam Park Near
Diamand Society Highway
Deesa,Banas
Kantha,Gujarat
A.5 Vallabh Township Near
Jay Yogeshwar Township
Ajwa
Road,Vadodara,Gujarat
Uttam Mansion Near Bob
Nava Bazar At Post Karjan
Taluka Karjan District
Vadodara,Vadodara,Gujarat
Baradvas At .Abhapura Ta .
Danta,Banas
Kantha,Gujarat
6 Ganesh Nagar Bh
Makarpura Bus Depot Near
Saligram Apartment
Makarpura,Vadodara,Gujar
at
A 107 Vijaydeep Society
Old Kosad Road Opp Utran
Railway Station Amroli
Surat Surat,Surat,Gujarat
Near Shilpa Society
Bagicha Area
Himatnagar,Sabar
Kantha,Gujarat
Shramdip Bhartinagar
Street No.2 Near Nanda
Hall. Kothariya Main
Road,Rajkot,Gujarat

G/1025/2002
Dt.11.07.02

G/2749/2000
Dt.23.09.2000

G/15/1984
Dt.18.01.84
G/1475/2005
Dt.03.07.05

G/845/2004
Dt.10.07.04

G/842/1988
Dt.18.11.88

G/28471999
Dt.04.07.99

G/747/2003
Dt.22.06.03

<!-- page 41 -->

348

835

Mansukhlal
Dayabhai
Paramar

SC

26.02.17

Wadhwan

Dayabhai
Ramjibhai
Paramar

349

839

Vinodkumar
Dayabhai Parmar

SC

27.02.17

Chuda

Dayabhai
Ramjibhai
Parmar

350

841

Rajnikant
Gopalbhai Shah

Gen

27.02.17

Padra

Gopalbhai
Chimanlal Shah

351

844

Ashokkumar
Vasantbhai Patel

Gen

28.02.17

Padra

Vasantbhai
Ramdasbhai
Patel

352

848

Rashmikaben
Maghabhai
Parmar

SC

03.10.17

Palanpur

Maghabhai

353

850

Patel
Mukeshkumar
Narsinhbhai

Gen

28.02.17

Himatnagar

Patel
Narsinhbhai
Lalabhai

354

853

Varecha
Dhanabhai
Becharbhai

SC

03.01.17

Palanpur

Becharbhai
Varecha

355

855

Sanketsinh
Jashvantsinh
Solanki

Gen

03.01.17

Vadodara

Jashvantsinh
Solanki

D.R.Sadan Shakti Nandan
Society B/H Nadoda
Boarding 80 Feet Road
Wadwan
City,Surendranagar,Gujarat
At . Mojidad Ta . Chuda Dist
.
Surendranagar,Surendrana
gar,Gujarat
E/19 Rampark Society
Station Road Padra Taluka
Padra District
Padra,Vadodara,Gujarat
30 Maruti Nagar Society
Pataliya Hanuman Road
Padra Taluka Padra District
Vadodara,Vadodara,Gujarat
Ramdev Ashish Sonbaug
Os Mira Gate
Palanpur,Banas
Kantha,Gujarat
59 Rangmahol Society
Mahakali Mandir Road
Himatnagar,Sabar
Kantha,Gujarat
At .Dhandha Ta.Palanpur
Dist Banaskantha,Banas
Kantha,Gujarat
44 Narayan Highlife Duplex
Opp Solace Hospital Near
Parivar Char Rasta Dabhoi
Waghodiya Ring Road
Vadodara,Vadodara,Gujarat

G/1014/1999
Dt.21.03.99

G/1931/2006
Dt.24.07.06

G/1079/2004
Dt.10.07.04

G/906/1995
Dt.28.07.95

G/2276/2005
Dt.06.08.05

G/3599/1999
Dt.22.08.99
G/1668/2005
Dt.17.07.05

G/1975/2005
Dt.17.07.05

<!-- page 42 -->

356

856

357

857

358

858

Kalaben
Mulshankar
Trivedi
Rathod
Gautambhai
Kakubhai
Parmar
Rameshbhai
Lalabhai

Gen

03.10.17

Savar Kundla

Mulshankar

Panchvati Society Mahuva
Road ,Amreli,Gujarat

G/134/2001
Dt.24.02.01

SC

03.10.17

Savar Kundla

Kakubhai

Behind Momai Temple Juna
Gadhakada Road At
Savarkundla,Amreli,Gujarat

G/781/2009
Dt.27.06.09

SC

16.03.17

Harij

Lalabhai

Indira Nagar Radhanpur
Road At Harij,Patan,Gujarat

G/886/2002
Dt.11.07.02

Gen

03.04.17

Surat City

Laljibhai
Zaverbhai
Savani

F 502 Shantiniketan Flora
Near Sanskartirth School
Abrama Road Mota
Varachha,Surat,Gujarat
I/11 Mahisagar Nagar
Society Opp Alwa Naka
Gidc Road
Manjalpur,Vadodara,Gujara
t
C 41 M N Park .3 B/H
Maisuriya Samajwadi
Shastri Road
Bardoli,Surat,Gujarat
At Somjipura Taluka Padra
District
Vadodara,Vadodara,Gujarat
At Post Mahamadpura
Taluka Padra District
Vadodara,Vadodara,Gujarat
2/333 Vakal Street At
Rander,Surat,Gujarat

359

860

Jivraj Laljibhai
Savani

360

863

Prakashkumar
Sureshchandra
Thakkar

Gen

03.02.17

Vadodara

Sureshchandra
Manharlal
Thakkar

361

867

Chaudhari
Vipulbhai
Arunbhai

ST

03.10.17

Surat City

Chaudhari
Arunbhai
Veljibhai

362

868

SC

03.04.17

Padra

363

870

Gen

03.04.17

Padra

364

873

OBC

29.03.17

Surat City

365

874

OBC

25.03.17

Botad

Narsinhbhai

At.Dhankaniya Ta.Botad
Dist.Botad,Botad,Gujarat

G/841/2001
Dt.21.06.01

366

879

Gen

03.06.17

Surat City

Batukbhai
Shamjibhai
Gadhiya

24 Old Shakti Vijay Society
Near Laxmi Hotel Varachha
Road,Surat,Gujarat

G/1073/2004
Dt.10.07.04

Jashvantbhai
Ramjibhai
Vaghela
Shaileshkumar
Jashubhai
Parmar
Hema Umrigar
Ghodakiya
Kanjibhai
Narsinhbhai
Yogesh
Batukbhai
Gadhiya

Ramjibhai
Hirabhai
Vaghela
Jashubhai
Babarbhai
Parmar
Balubhai
Umrigar

G/2755/2001
Dt.04.11.01

G/2133/2004
Dt.26.09.04

G/2673/2006
Dt.07.10.06
G/1351/2001
Dt.07.08.01
G/1502/2001
Dt.07.08.01
G/2831/2005
Dt.24.09.05

<!-- page 43 -->

Gupta
Chandrakant
Manmohanlal
Gondaliya
Jitendra
Ganpatram

Gen

26.05.17

Olpad

Manmohanlal
Gupta

OBC

14.03.17

Amreli

Ganpatram

Ashokkumar
Karsanbhai Patel

Gen

03.08.17

Surat City

Karsanbhai
Laljibhai Patel

887

Pallaviben
Morlidhar Barot

OBC

04.12.17

Ahmadabad
City

Morlidhar P
Barot

371

889

Ashok
Manshukhlal
Bhatt

Gen

03.08.17

Surat City

Manshukhlal
Mahashankar
Bhatt

372

892

Manojkumar
Haribhai Sojitra

Gen

16.03.17

Rajkot

Haribhai
Govindbhai
Sojitra

373

894

Ashish Ramjibhai
Sojitra

Gen

16.03.17

Rajkot

Ramjibhai
Mohanbhai
Sojitra

374

895

Ashish
Vallabhbhai
Viradiya

Gen

16.03.17

Rajkot

Vallabhbhai
Jethabhai
Viradiya

375

897

Parulben
Rajeshbhai
Sardhara

Gen

20.03.17

Surat City

Babubhai
Gagdasbhai
Thummar

367

881

368

884

369

886

370

Kuwa Faliyu At Paria
OLPAD,SURAT,GUJARAT
Maheta Market Opp Haweli
At
Savarkundla,Amreli,Gujarat
A.202. Shivalik Residency.
Nr. Lalita Char Rasta.
Katargam. Surat
,Surat,Gujarat
A 6 Kamal Appartment Nr
Bhagyoday Soc Jantanagar
Road
Ghatlodiya,Ahmadabad,Guj
arat
G.2. Navkar Flat. Patel
Falia. Katargam. Surat
,Surat,Gujarat
Plot No 15. Shreenath
Park.Opp Shiv Dairy Behind
Parasana Palace. Mota
Mava Kalawad Road.
Rajkot,Rajkot,Gujarat
'Ashish'. Shakti Soc. Street
No 13 Santkabir Road. B/H
Sardar School Rajkot
,Rajkot,Gujarat
'Sahaj'. Bhavnath Park 1
Street No 7. Hari Ghava
Marg. Kothariya Main Road.
Rajkot,Rajkot,Gujarat
55 Manish Nagar Society Nr
Gaytri Temple Dabholi
Road Surat,Surat,Gujarat

G/2551/2006
Dt.07.10.06
G/630/1992
Dt.07.08.92
G/2620/2000Dt
.09.09.2000

G/1947/2007
Dt.13.12.07

G/735/2002
Dt.11.07.02

G/2032/2006
Dt.24.07.06

G/2345/2006
Dt.03.09.06

G/1870/2006
Dt.09.07.06
G/1346/2008
Dt.07.09.08

<!-- page 44 -->

B/17. Ram Nager C R Patil
Estate Road
Dindoli,SURAT,GUJARAT
G1 Arihant Flat Behind
Sitabau Ground Manjalpur
Vadodara,VADODARA,GUJ
ARAT
A 8 Krushna Sarvodaya
Society Opposite Acharya
Nursing Home Subhanpura
Vadodara,VADODARA,GUJ
ARAT
At And Post Duma Ta
Jambughoda Dist
Panchmahal ,Panch
Mahals,Gujarat
Plot No 49 Flat No 104
Shanti Tirth
Devubag,BHAVNAGAR,GU
JARAT
Chhapariya Char Rasta
Near Gandhi Ashram
Himatnagar,Sabar
Kantha,Gujarat
Opp Sabar Stedium Main
Gate Bholeshwar
Himatnagar,Sabar
Kantha,Gujarat

376

901

Dilipkumar
Laxmikanth Jha

Gen

03.11.17

Chorasi

Laxmikanth Jha

377

902

Vandana
Dattatray Patil

Gen

05.01.17

Vadodara

Dattatray
Gabhirrao Patil

378

903

Krunal
Balwantkumar
Parmar

SC

29.03.17

Vadodara

Balwantkumar
Mangaldas
Parmar

379

904

Mukeshkumar
Govindbhai
Chauhan

SC

03.10.17

Jambughoda

Govindbhai
Chauhan

380

912

Hiteshkumar
Udaysinhbhai
Tuvar

OBC

14.03.17

Bhavnagar

Udaysinhbhai

381

915

Desai Kalyanbhai
Bhalabhai

OBC

03.10.17

Himatnagar

Bhalabhai

382

916

Solanki
Sureshkumar
Hirabhai

SC

03.10.17

Himatnagar

Hirabhai

383

918

Naranbhai
Mansurbhai
Dangar

OBC

14.03.17

Bhesan

Mansurbhai
Khimabhai
Dangar

At. Kariya Ta. Bhesan
,Junagadh,Gujarat

G/1765/2003
Dt.31.08.03

921

Ashishkumar
Mansukhlal
Jagani

Surat City

Mansukhlal
Kanjibhai
Jagani

A.201 2nd Floor Satsang
Residency Oop Pusti Dham
Haveli Satelite Road Moata
Varachha,Surat,Gujarat

G/2570/2000
Dt.09.09.2000

384

Gen

03.12.17

G/222/2004
Dt.20.02.04
G/1251/2009
Dt.08.08.09

G/1433/2008
Dt.07.09.08

G/787/2008
Dt.05.07.08

G/850/2003
Dt.22.06.03

G/194/2000
Dt.29.02.2000

G/83/2005
Dt.12.02.05

<!-- page 45 -->

385

922

Dinesh
Kishorbhai
Makwana

386

928

Shaileshkumar
Jayantilal Pandya

Gen

15.03.17

Wadhwan

Jayantilal
Dayashakar
Pandya

387

929

Pradyumansinh
Bharatsinh
Makwana

Gen

15.03.17

Wadhwan

Bharatsinh
Lalubha
Makwana

388

930

Khandvi Balvant
Dudabhai

SC

18.03.17

Rajkot

Dudabhai

389

932

Dipak Jadavbhai
Tank

OBC

22.03.17

Surat City

Jadavbhai

390

933

Prakash Gopalji
Raval

Gen

15.03.17

Wadhwan

Gopalji
Dayashankar
Raval

391

934

Suresh
Ramsamuj Yadav

OBC

31.03.17

Chorasi

Ramsamuj

937

Kamlesh
Chandrakant
Bhatt

Gen

16.03.17

Rajkot

Chandrakant
Bhatt

392

SC

03.12.17

Wadhwan

Kishorbhai
Kanjibhai
Makwana

Ganpati Fatsar Ganesh
Nagar Opp Primary School
Wadhwan
City,Surendranagar,Gujarat
Block No.8 Vivekanand
Society 4/A New Junction
Road,Surendranagar,Gujar
at
16 17 First Floor Ambar
Plaza.4 Opp Lakhtar Uttara
Jail Chowk
Surendranagar,Surendrana
gar,Gujarat
Maa. Kailash Dhara Park.
Near Vidyut Nagar 2 Raiya
Road. Rajkot,Rajkot,Gujarat
205 Gokil Apartment Opp.
Ghanshyam Nagar Street
No. 22 L.H. Raod
Karanj,Surat,Gujarat
Sharada Nagar 2 Near
Madhuvan Pan 80 Feet
Road
Surendranagar,Surendrana
gar,Gujarat
Plot No. 77 Ram Rajya
Society Nr. Mangal Pande
Hall
Godadara,Surat,Gujarat
203. Puja Appartment
Vaniyawadi St. No 5
Bhaktinagar
Circle,Rajkot,Gujarat

G/579/2006
Dt.18.03.06

G/144/1999
Dt.13.02.98

G/2719/2004
Dt.07.11.04

G/1767/2000
Dt.06.08.2000
G/2365/2006
Dt.03.09.06

G/1663/2002
Dt.14.08.02

G/1698/2008
Dt.02.10.08

G/765/2002
Dt.11.07.02

<!-- page 46 -->

393

939

Chhasatiya
Jaydeepsinh
Khumansinh

394

941

Joshi Arunkumar
Kantilal

Gen

27.03.17

Savar Kundla

Kantilal

395

944

Mukesh Bhalerav
Patil

Gen

16.03.17

Surat City

Bhalerav
Namdev Patil

396

945

Barupal
Trilokchand
Kishanlal

Gen

23.08.17

Ahmadabad
City

Barupal
Kishanlal Jivanji

397

947

Pinkeshkumar
Semual Vishwas

SC

06.10.17

Ahmadabad
City

Semual
Makwana

398

949

Dharmendra
Keshavji Tank

OBC

31.03.17

Rajkot

Keshavji
Govindbhai
Tank

399

950

Bipin Hirjibhai
Tank

OBC

31.03.17

Rajkot

Hirjibhai
Govindbhai
Tank

400

952

Maisuria
Prakashkumar
Kantilal

OBC

17.03.17

Kamrej

Kantilal
Parbhubhai
Maisuria

401

956

Mahendra Manilal
Patel

OBC

17.03.17

Surat City

Manilal
Naranbhai Patel

Gen

17.03.17

Vadodara

Khumansinh

13 Vaghela Faliyu Near
Darbar Gadh At Post
Bhadarwa Ta
Savli,Vadodara,Gujarat
Suryadev Chowk Shivaji
Nagar Bhole
Sai,Amreli,Gujarat
153.154.155. Mahadev
Nagar.4. Krishna Near
Janta Medical. Dindoli.
Surat ,Surat,Gujarat
22 Duplex Tankar
Residensy Nr Jaimin Park
Society Vatva Road
Vatva,Ahmadabad,Gujarat
3.Kamal Bunglows Ioc
Road. Nr.Shyam
Bunglows.1
Chandkheda,Ahmadabad,G
ujarat
Shri Chamunda Krupa Punit
Society Navdurga 30 Feet
Road Kothariya
Road,Rajkot,Gujarat
Punit Society Navdurga 30
Feet Road Nr Gatral Krupa
Kothariya
Road,Rajkot,Gujarat
Hemdhyuti. 1908. Radha
Krishna Society Block
No.318.B. At.Po. Kathor
Kamrej. Surat,Surat,Gujarat
226. Machhiwad. B.S.
Parsiwad Amroli. Surat
,Surat,Gujarat

G/135/2007
Dt.02.03.07
G/915/1991
Dt.17.10.91
G/2609/2001
Dt.07.10.01

G/85/2003
Dt.11.01.03

G/1782/2004
Dt.14.08.04

G/2441/2005
Dt.21.08.05

G/1946/2005
Dt.17.07.05

G/843/2004
Dt.10.07.04
G/2597/2006
Dt.07.10.06

<!-- page 47 -->

402

957

Bharatkumar
Ashokkumar
Nayak

403

959

Kalpanaben
Jaishankar
Pathak

404

965

405

966

406

971

Acharya Pinkiben
Rameshbhai

Gen

04.08.17

Ahmadabad
City

Acharya
Rameshbhai

407

973

Jitendra Vaishnav

OBC

18.03.17

Thangadh

VALLABHDAS
VAISHNAV

408

974

Prashant
Kanubhai Patel

Gen

25.03.17

Rajkot

409

976

Dipakkumar
Dineshbhai
Mehta

Gen

22.03.17

Rajkot

410

977

Shailesh
Natavarlal Vyas

Gen

31.03.17

Rajkot

Chhaganbhai
Bhagwanbhai
Vora
Pathan
Liyakatkhan
Mukhtyarkhan

OBC

29.03.17

Visnagar

ASHOKKUMAR

SC

17.03.17

Surat City

Jaishankar
Kashiram
Pathak

OBC

18.03.17

Surat City

Bhagwanbhai L
Vora

OBC

21.03.17

Kheda

MUKHATYARK
HAN

KANUBHAI
VALJIBHAI
PATEL
DINESHBHAI
MOHANLAL
MEHTA
Natavarlal
Narbheram
Vyas

23 Asaitnagar Bihaind
Parimal Society Opp
Mahesh Petrol Pump
Mahesana Road
Visnagar,Mahesana,Gujarat
82.Vishal Co.Op.Hos.
Society. Opp. Evershine
Marble.
Sou.Uni.Road.Bhatar Char
Rasta. Althan.
Surat,Surat,Gujarat
202 Surabhi Complex Opp
Katargam Library Katargam
Surat,Surat,Gujarat
At.Chandna Pathan Faliyu
Ta.Kheda
Dist.Kheda,Kheda,Gujarat
15/A Komal Enclave P T
College Road Paldi
Ahmedabad,Ahmadabad,G
ujarat
Dharampark Jagdish
Pottery Tarnetar Road
Thangadh
Thangadh,Surendranagar,G
ujarat
Parth Tower 7th Floor Near
Indira Circle 150 Feet Ring
Road,Rajkot,Gujarat
''Shree Harsiddhi Krupa''
Tirupati Nagar Stree No 5
Raiya Road,Rajkot,Gujarat
Gayatri Krupa Kothariya
Colaony Quarter No. 124 80
Feet Road,Rajkot,Gujarat

G/179/1995
Dt.28.01.95

G/2597/2004
Dt.07.11.04

G/1816/2001
Dt.18.09.01
G/1270/2004
Dt.10.07.04
G/1223/2004
Dt.10.07.04

G/3130/1999
Dt.08.08.99

G/1672/2002
Dt.14.08.02
G/173/2004
Dt.20.02.04
G/2203/2000
Dt.09.09.2000

<!-- page 48 -->

978

Kaushik
Gautambhai
Gediya

412

980

Dipakkumar
Rameshbhai
Khandhedia

Gen

413

983

Jigna
Prafulchandra
Trivedi

414

984

415

Vadodara

Gautambhai
Gediya

22.03.17

Rajkot

Rameshbhai
Maganbhai
Khandhedia

Gen

19.03.17

Vadodara

Prafulchandra
Trivedi

Jain Bhavna
Nileshkumar

Gen

04.03.17

Ahmadabad
City

Ratilal B Mali

985

Asha
Jayeshkumar
Patel

Gen

22.03.17

Ahmadabad
City

Pravinbhai N
Patel

416

986

Pravinbhai
Bhailalbhai
Parmar

SC

22.03.17

Vadodara

Bhailalbhai
Dhulabhai
Parmar

417

987

Patel Hina
Pareshkumar

Gen

22.03.17

Ahmadabad
City

Ambalal S Aptel

418

988

Patel Laljibhai
Jethabhai

Gen

20.03.17

Dabhoi

Jethabhai

419

989

Chudesra Anisha
Farukbhai

OBC

30.03.17

Barwala

Anvarbhai
Adambhai
Gadhiya

411

SC

19.03.17

C 42 Radhika Society B/H
Devnagar Vasna Road
Vadodara,Vadodara,Gujarat
Samruddhinagar Block No
37 12 Kalawad Road Bh
Vrundavan Society
Rajkot,Rajkot,Gujarat
B 113 Krishna Park Society
Near Sayajipark Bus Stop
Ajwa
Road,Vadodara,Gujarat
24 Gangamaiya Society
Hatkeshwar Mahadev Road
Khokhra Maninagar East
Ahmedabad,Ahmadabad,G
ujarat
D 15 Navratna Appartment
Nr Sola Railway Crossing
Ghatlodia
Ahmedabad,Ahmadabad,G
ujarat
1760 Chitrakut Society
Behind. Akashvani
Makarpura Road
Vadodara,Vadodara,Gujarat
C 7 Alkapuri Society Nr
Super School Ghatlodia
Ahmedabad,Ahmadabad,G
ujarat
HANUMAN FALIYA
NANDODI BHAGOL
AT.PO.TA.DABHOI,VADOD
ARA,GUJARAT
Soni Sheri Kundal Darwaza
Ander
Barwala,BOTAD,GUJARAT

G/2386/2005
Dt.06.08.05
G/1711/2000
Dt.06.08.2000

G/1459/2008
Dt.07.09.08

G/124/2008
Dt.15.02.08

G/1606/2005
Dt.03.07.05

G/250/2007
Dt.03.05.07

G/952/2006
Dt.21.06.06

G/639/1983
Dt.30.08.83
G/70/2010
Dt.08.02.10

<!-- page 49 -->

SC

24.03.17

Vadodara

Ratilal
Keshavlal
Jadav

420

991

Vipul Ratilal
Jadav

421

992

Manojkumar
Hasmukhbhai
Patel

Gen

04.11.17

Surat City

Hamukhbhai
Gordhanbhai
Patel

422

995

Manharbhai
Dalsukhbhai
Parmar

SC

05.04.17

Kalol

Dalsukhbhai
Kanabhai
Parmar

423

997

Mayur
Chandrakant
Kosambia

SC

24.03.17

Surat City

Chandrakant
Ratilal
Kosambia

424

998

Alpesh Amrutlal
Jariwala

OBC

21.03.17

Surat City

Amrutlal
Shantilal Rana

425

1000

Solanki Manubhai
Bhikhabhai

OBC

21.03.17

Anand

Bhikhabhai
Chaturbhai
Solanki

426

1004

Sandipkumar
Rajendraprasad
Tiwari

Gen

21.03.17

Vadodara

Rajendraprasad
Kedarnath
Tiwari

427

1007

Sandeep
Yashwantbhai
Joshi

Gen

21.03.17

Surat City

Yashwantbhai
Ramchandra
Joshi

428

1008

Jadeja
Hardevsinh
Kalubha

Gen

25.03.17

Lodhika

Kalubha

D 140 Ambika Park Society
Near Gordhanbhai Park
Refinery Road
Gorwa,Vadodara,Gujarat
7/2450 Choki Sheri
Saiyedpura
Surat,Surat,Gujarat
Behind Of Primary School.
Vejalpur Road At And Post.
Sureli Tehsil. Kalol,Panch
Mahals,Gujarat
13.Syndicate Flats Nr.
Kanak Raw House Anand
Mahal Road Adajan
Surat,Surat,Gujarat
64 Khodiyar Nagar Opp
Bharat Nagar 80 Feet Road
Bhathena Anjana Udhna
Surat,Surat,Gujarat
Dhebakuva Post Valasan
Ta Dist
Anand,Anand,Gujarat
B/21 Shivam Tenament Nr.
Alankar Society Tp 13
Chhani Jakat
Naka,Vadodara,Gujarat
3 Dariya Mahel Park
Society Opp. Surat
Municipal Corporation
Muglisara
Road,Surat,Gujarat
At . Chhapra Tal. Lodhika
,RAJKOT,GUJARAT

G/557/2004
Dt.27.03.04
G/1274/2001
Dt.07.08.01
G/2801/2005
Dt.24.09.05

G/2583/2006
Dt.07.10.06

G/3027/2005
Dt.24.09.05
G/1462/2004
Dt.14.08.04
G/106/2007
Dt.02.03.07

G/2632/2006
Dt.07.10.06

G/2302/2000
Dt.09.09.2000

<!-- page 50 -->

429

1010

Ashokkumar
Jivrajbhai Patel

Gen

05.07.17

Jetpur

Jivrajbhai
Nathubhai Patel

430

1011

Prafulchandra
Barot

OBC

27.03.17

Ahmadabad
City

Natvarlal

431

1014

Chauhan
Vasantbahen
Sardarsinh

OBC

04.08.17

Himatnagar

Sardarsinh
Somsinh
Chauhan

432

1016

Prajapati Ila
Laljibhai

OBC

27.03.17

Nadiad

Prajapati
Laljibhai
Mohanbhai

433

1017

Pancholi
Rajeshkumar
Bhikhabhai

OBC

22.03.17

Sinor

Bhikhabhai

434

1018

Dipakkumar
Ramprasad
Pandit

Gen

22.03.17

Surat City

Ramprasad
Gayaprasad
Pandit

435

1021

Ashok M Shah

Gen

22.04.17

Umreth

Mohanlal

436

1026

Sachinkumar
Chimanlal
Shrimali

SC

04.12.17

Ahmadabad
City

Chimanlal
Khemchandbha
ishrimali

437

1028

Rajesh
Dhansukhlal
Tailor

OBC

23.03.17

Surat City

Dhansukhlal
Amrutlal Tailor

438

1037

Dharmesh
Khushalbhai
Kataria

SC

25.03.17

Surat City

Khushalbhai
Lallubhai
Kataria

Matru Ashish Shanti Nagar
Street No.1
JETPUR,RAJKOT,GUJARA
T
901 Sunder Gopal Complex
Ambawadi Circle Ellisbridge
Po,Ahmadabad,Gujarat
At.Po . Hajipur Ta .
Himatnagar Dist .
Sabarkantha,Sabar
Kantha,Gujarat
2 Amar Nivas Opp
Suryanagar Society B/H
Vaishali Cinema
Nadiad,Kheda,Gujarat
Bazar Faliya At.Po.Barkal
Ta.Sinor,Vadodara,Gujarat
220. Shaktinagar. Opp.
B.R.C. B.H. Harinagar.3.
Udhna. Surat.
,Surat,Gujarat
Tran Pole Marudiya Pole
Umreth,ANAND,GUJARAT
401/2258 Shivshaktnagar
Gujarat Housing Board
Chandkheda,Ahmadabad,G
ujarat
B.234. Jalaramnagar. B.H.
Udhna. Railway Colony.
Udhnayard. Limbayat.
Surat.,Surat,Gujarat
52. Vaishali Row House.
Near J.K. Moters. Pal
Patiya. Pal Road. Adajan.
Surat,Surat,Gujarat

G/1282/2001
Dt.07.08.01
G/12/1976
Dt.23.01.76
G/2288/2004
Dt.26.09.04

G/1693/2005
Dt.17.07.05
G/3579/1999
Dt.22.08.98
G/2296/2001
Dt.07.10.01
G/191/1978
Dt.23.06.78
G/1224/2005
Dt.03.07.05

G/122/2005
Dt.12.02.05

G/3447/2006
Dt.31.12.06

<!-- page 51 -->

439

1040

Thakor Gopalsinh
Shivsinh

440

1041

Rajeshkumar
Harivadan
Pandya

Gen

28.03.17

Talod

Harivadan
Ambalal
Pandya

441

1047

Chaitali
Chandubhai Patel

OBC

25.03.17

Surat City

Chandubhai
Jerambhai
Patel

442

1048

Hetal
Narendrabhai
Agrawal

Gen

30.03.17

Gandhidham

Narendrabhai
Agrawal

443

1050

Girish Kantilal
Raval

Gen

29.03.17

Himatnagar

Kantilal

444

1054

Darshit Kantilal
Vyas

Gen

19.04.17

Rajkot

Kantilal K Vyas

445

1056

Jashubhai
Koyagibhai Amin

SC

26.03.17

Bodeli

Koyagibhai
Amin

446

1059

Mukesh
Premjibhai
Rathod

SC

27.03.17

Surat City

Premjibhai
Hirabhai
Rathod

OBC

25.03.17

Himatnagar

Shivsinh

Shaktinagar Nr Taluka
Panchayat Office At Po Ta
Himatnagar,Sabar
Kantha,Gujarat
Mahiyal Ta Talod Dist
Sabarkantha,Sabar
Kantha,Gujarat
C.103. Shree Bharti
Residency. Near Gothik
Heritej. New L.P. Savani
Road. Pal. Pal. Adajan.
Surat.,Surat,Gujarat
E.83 Iffco Colony
Udaynagar
Gandhidham,Kachchh,Guja
rat
34 Gopalkunj Society B/H
Kotiyark Society
Chhapariya Road
Himtnagar,Sabar
Kantha,Gujarat
Shubham 6.Niranjani
Society Rameshwar Chowk
Raiya Road
Rajkot,Rajkot,Gujarat
10 Jankalyan Society Ali
Kherva Bodeli Ta Bodeli
Dist Chhota
Udepur,Chhotaudepur,Guja
rat
D.5. Sarvasw Row House.
Opp. Honey Park Appt.
Honey Park Road. Adajan.
Surat ,Surat,Gujarat

G/1679/2005
Dt.17.07.05
G/1284/2002
Dt.31.07.02

G/2449/2001
Dt.07.10.01

G/849/2007
Dt.29.06.07

G/723/1998
Dt.22.08.98

G/120/2006
Dt.29.01.06

G/819/1998
Dt.12.09.98

G/2275/2004
Dt.26.09.04

<!-- page 52 -->

447

1061

Jitendra
Kalyanbhai
Chakrani

Gen

27.03.17

Surat City

Kalyanbhai
Kurjibhai
Chakrani

448

1062

Anilkumar
Virsingh Bhai
Makwana

ST

04.06.17

Ahmadabad
City

Virsingh
Kadakiya
Makwana

449

1064

Prakashkumar
Ishwarbhai Rohit

SC

27.03.17

Bodeli

Ishwarbhai
Mavjibhai Rohit

450

1068

Chirag
Narendrakumar
Bhatt

Gen

30.03.17

Vadodara

Narendrakumar
Bhatt

451

1070

Surjuse Ritesh
Rameshbhai

OBC

30.03.17

Surat City

Surjuse
Rameshbhai
Damdaji

452

1075

Hitesh Chimanlal
Valand

OBC

29.03.17

Himatnagar

Chimanlal

453

1077

Indermal Devraj
Purohit

Gen

28.03.17

Surat City

Devraj
Shankarji
Purohit

454

1081

Mamta
Vasudevbhai
Tarnekar

Gen

28.03.17

Surat City

Vasudevbhai
Dashrathbhai
Tarnekar

A.38. Pramukh Chhaya
Society. Puna Simada
G/2459/2006
Road. Punagam.
Dt.03.09.06
Surat,Surat,Gujarat
Block C 101 Nilkanth Park 1
Opp Gopalnagar Near St
G/883/2008
Xaviers High School
Dt.18.07.08
Memnagar,Ahmadabad,Guj
arat
B17 Bapunagar Society
Near Water Tank Dabhoi
Road At And Post Ta Bodeli
G/444/2005
Dist Chhotaudepur
Dt.05.03.05
391135,Chhotaudepur,Guja
rat
F 6 Nutansaurabh Society
Behind Vijaynagar Harni
G/1920/2004
Varasiya Ring Road
Dt.14.04.05
Vadodara,Vadodara,Gujarat
Plot No 39 Ambika Nagar
G/2026/2007
B/H Harinagar
Dt.30.12.07
2,Surat,Gujarat
3 Rushikesh Society Nr
Reliance Mall Tasiya Road
G/417/1995
Himatnagar,Sabar
Dt.15.03.95
Kantha,Gujarat
I.433. Saidham Palace.
G/4742-A/2005
Shilpa Park Society. L.H.
Dt.06.10.05
Road. Surat. ,Surat,Gujarat
E.1.B. Magan Nagar.2. First
Floor. Near Nayan Deep
G/1792/2007
Apartment Dhanmora.
Dt.13.10.07
Katargam. Singanpor Road.
Surat,Surat,Gujarat

<!-- page 53 -->

1083

Mr Rakesh
Mahendrakumar
Gandhi

456

1085

Mukeshkumar
Madhubhai
Boricha

SC

457

1094

Rajesh Kumar
Mohanbhai
Waghela

SC

455

458

1096

459

1101

460

1103

461

Rajput
Sureshkumar
Ramanlal
Tejalben
Dineshchandra
Parekh

OBC

Surat City

Mehendrakuma
r Sakarlal
Gandhi

28.03.17

Surat City

Madhubhai
Punabhai
Boricha

28.03.17

Vadodara

Mohanbhai

28.03.17

Rajput
Ramanlal
Chhitabhai
Parekh
Dineshchandra
Maganlal

Gen

28.03.17

Bharuch

OBC

28.03.17

Bharuch

Parshotam
Pithabhai Dafada

SC

17.05.17

Amreli

Pithabhai

1104

Shilaben
Manubhai Patel

ST

28.03.17

Surat City

Manubhai
Dhirubhai Patel

462

1105

Sudhirkumar
Subodhkumar
Mehta

Gen

04.04.17

Ahmadabad
City

Subodhkumar
Ravishankar
Mehta

463

1107

Beena
Ranchhodbhai
Raval

Gen

30.03.17

Vadodara

Ranchhodbhai
Punambhai
Raval

D..3.11. Anjana Tenement.
Nr. Raghukul Market. Ring
Road. Surat ,Surat,Gujarat
E.504. Sanai Residency.
Opp. Parshuram Garden.
Honey Park. Adajan. Surat
,Surat,Gujarat
B 410 Sahjanand Flats
Near Vadsar Bridge Vadsar
Village Road
Vadsar,Vadodara,Gujarat
Vejalpur Bambakhana
Chamunda Traders
Bharuch,Bharuch,Gujarat
59 Mangaldeep Society
Dahej Bypass Road
Bharuch,Bharuch,Gujarat
Dasi Jivan Krupa
Siddharthnagar Chital
Road,Amreli,Gujarat
88. Vrundavan Society.
Sachin Vanz Road. Nr.
Durdarshan Kendra.
Sachin. Surat,Surat,Gujarat
36 Vinayak Park Society
Opp Tirupati School Nr
Lake
Chandlodia,Ahmadabad,Gu
jarat
B/32 Akshatnagar Society
Near Abhilasha Chokdi New
Sama Road Chhani Jakat
Naka
Vadodara,Vadodara,Gujarat

G/766/2004
Dt.08.05.04
G/1785/2000
Dt.06.08.2000

G/2255/2003
Dt.15.10.03
G/2200/2004
Dt.26.09.04
G/1879/2003
Dt.31.08.03
G/171/2002
Dt.03.01.02
G/199/2010
Dt.09.02.10

G/3614/1999
Dt.22.08.99

G/2336/2003
Dt.15.10.03

<!-- page 54 -->

Gen

28.03.17

Vadodara

Kanubhai
Ambalal Patel

D.412 Kedardham Flats
Opp. Hari Party Plot
Manjalpur,VADODARA,GU
JARAT
2.207.B. Kunj Gali. Parekh
Faliya. Near Rander
Peoples Bank. Rander.
Surat,Surat,Gujarat

464

1109

Alpeshkumar
Kanubhai Patel

465

1111

Dipali
Hemntkumar
Navik

Gen

29.03.17

Surat City

Kamleshkumar
Chandravadan
Kapasiawala

466

1119

Bariakoli
Vijaykumar
Jivabhai

OBC

29.03.17

Bodeli

Bariya Jivabhai
Dipabhai

At Post Navapura Ta Bodeli
,Chhotaudepur,Gujarat

467

1121

Mehta Jatinkumar
Labhshankar

Gen

24.04.17

Savar Kundla

Mehta
Labhashankar
Gaurishankar

468

1125

Tewar
Sunilkumar
Padmakant

Gen

29.03.17

Vadodara

TEWAR
PADMAKANT
PRAHLADBHAI

469

1127

Babubhai
Manchhubhai
Surati

SC

04.02.17

Surat City

Manchhubhai
Makanbhai
Surati

470

1129

Kiritkumar
Keshavbhai
Chovatiya

Gen

15.04.17

Rajkot

Keshavbhai
Premjibhai
Chovatiya

471

1130

Darji Manojkumar
Rameshchandra

OBC

29.03.17

Vadodara

Darji
Rameshchandr
a Maganlal

Nandi Shora Vadi Opp Jay
Shri Cenema
Savarkundla,Amreli,Gujarat
27 ANKUR SOCIETY B/H
RANCHHODJI MANDIR
WAGHODIA ROAD
PANIGATE VADODARA
390019,VADODARA,GUJA
RAT
D.2 Shivani Row House
Capt.Laxmi Marg
Opp.Bhumi Complex New
Rander Road
Surat,Surat,Gujarat
Dwarkesh Pranami Park C
Street No 1 Near New
Gandhi Society Khodal
Hotel 40 Feet Road 150
Feet Ring Road
Rajkot,Rajkot,Gujarat
73 Damodar Nagar B/H
Rajdeep Complex Tarsali
Vadodara
390009,Vadodara,Gujarat

G/2194/2004
Dt.26.09.04

G/2015/2007
Dt.30.12.07
G/1669/2000
Dt.22.07.2000
G/959/1994
Dt.09.10.94

G/225/1988
Dt.23.04.88

G/2081/2009
Dt.03.12.09

G/2073/2006
Dt.24.07.06

G/906/1992
Dt.06.10.92

<!-- page 55 -->

472

1132

Ranjana
Shyamsunder
Pandya

473

1135

Mistri Mitalkumar
Dahyabhai

OBC

30.03.17

Talod

Mistri
Dahyabhai
Bababhai

474

1140

Bharvad
Jagashibhai
Bhanubhai

OBC

30.03.17

Radhanpur

Bhanubhai

475

1146

Shetal
Navinchandra
Shukal

Gen

24.04.17

Ahmadabad
City

Navinchandra

476

1148

Kailash
Nathubhai Vala

OBC

30.03.17

Surat City

Nathubhai
Bachubhai Vala

477

1151

Kishor Dilipbhai
Khairnar

OBC

31.03.17

Surat City

Dilipbhai
Damubhai
Khairnar

478

1153

Mukeshkumar
Vitthaldas
Bhavsar

Gen

31.03.17

Vadodara

Vitthaldas
Narandas
Bhavsar

479

1156

Vipul Baldevbhai
Paneria

SC

31.03.17

Surat City

Paneria
Baldevbhai

1159

Rakesh
Bhagvandas
Parmar

Surat City

Bhagvandas
Karsandas
Parmar

480

Gen

29.03.17

Vadodara

Shyamsunder
Pandya

SC

31.03.17

23 Ankur Society Opp
Poonam Complex
Waghodia Road Vadodara
390019,Vadodara,Gujarat
At.Po.Talodgam Chela
Bhagat Nu Faliyu Tal.Talod
Dist.Sabarkantha,Sabar
Kantha,Gujarat
Bharvadvas At Kamalpur
(Satun) Ta
Radhanpur,Patan,Gujarat
12 Niranjan Baugh Society
D Cabin
Sabarmati,Ahmadabad,Guj
arat
177. Nandanvan Society.
Near Singanpore Shak
Market. Couse Way.
Singanpore Road.
Surat.,Surat,Gujarat
226 Mansi Residency Near
Cr Patil Estate Dindoli
Surat,Surat,Gujarat
B 110 Siv Baunglow Society
Opp Pragti Nagar New V I P
Warasia Ring
Road,Vadodara,Gujarat
House No.301 Sarvoday
Street Nr.Fier Station
Morabhagal Rander
Surat,Surat,Gujarat
7/4789 Begampura
Chidiyakui Mandir Street
Near Torrent Power
Company
Surat,Surat,Gujarat

G/299/2001
Dt.26.03.01

G/2803/2003
Dt.30.12.03
G/460/2005
Dt.05.03.05
G/979/2002
Dt.11.07.02

G/2010/2008
Dt.27.12.08

G/1217/2007
Dt.30.07.07
G/46/1999
Dt.13.02.99

G/275/2007
Dt.03.05.07

G/2537/2005
Dt.21.08.05

<!-- page 56 -->

481

1162

482

1168

483

1169

484

1171

485

Tailor Biren
Bhikhabhai

OBC

31.03.17

Vadodara

Tailor
Bhikhabhai
Rayjibhai

Jayesh
Chandrakant
Bagdawala
Ajitkumar
Indrasinh
Brahmbhatt
Manohar
Gangasing
Rajpurohit

Gen

31.03.17

Surat City

Chandrakant
Gangaram
Bagdawala
Indrasinh
Prabhatsinh
Brahmbhatt
Gangasing
Javatsing
Rajpurohit

OBC

31.03.17

Vadodara

Gen

31.03.17

Surat City

1173

Rathod Kirtisinh
Lalsinh

OBC

31.03.17

Himatnagar

Rathod Lalsinh
Motisinh

486

1177

Tanu
Yogendrakumar
Oza

Gen

31.03.17

Mahesana

Jayantkumar
Vyas

487

1179

Urvashi Gor

Gen

31.03.17

Bhuj

Shantilal Gor

488

1192

Jignesh
Nagarbhai Hingu

OBC

31.03.17

Surat City

Nagarbhai

489

1198

Sima
Sureshchandra
Chaturvedi

Gen

31.03.17

Vadodara

Sureshchandra
S Chaturvedi

490

1201

Bhatiya
Bipinchandra
Shankalchand

OBC

31.03.17

Limkheda

SAKALCHAND

A/13 Pramukh Vatika
Society B/H Hariom Society
B/S Narayan Kathiyawadi
Hotel
Atladara,Vadodara,Gujarat
4.1831. Panjanigharwad.
Koliwad. Begumpura. Surat.
,Surat,Gujarat
Sara Faliyu At Po Sathod
Tal
Dabhoi,Vadodara,Gujarat
A 303. Indraprast Complax.
Punagam Road. Magob.
Surat.,Surat,Gujarat
At.Soja Po.Pedhamali
Ta.Vijapur Dist .
Maheasna,Mahesana,Gujar
at
14 Nilkanth Bangloj
Nagalpur 2
,Mahesana,Gujarat
Opposite Trabmakeshwar
Temple Out Of Sarpat Gate
Airport
Road,Kachchh,Gujarat
5 Valinath Society Kapodra
Char Rasta Varachha Road
Surat ,Surat,Gujarat
B 58 Madhavpark Chhani
Nh No. 8
Vadodara,Vadodara,Gujarat
Bariya Road Opp. Umariya
Coloni Bariya Road Palli Ta.
Limkheda,DOHAD,GUJAR
AT

G/973/1995
Dt.28.07.95

G/2495/2001
Dt.07.10.01
G/820/1992
Dt.06.10.92
G/2835/2003
Dt.30.12.03
G/319/2000
Dt.29.02.2000
G/2103/2006
Dt.24.07.06
G/315/1996
Dt.08.03.96
G/1453/2007
Dt.07.09.07
G/1779/2009
Dt.01.10.09
G/3453/1999
Dt.22.08.99

<!-- page 57 -->

491

1202

Chandreshbhai
Harsukhbhai
Patel

Gen

31.03.17

Rajkot

Harsukhbhai
Karshanbhai
Patel

492

1203

Gor Shilpa

Gen

31.03.17

Bhuj

Gor Jayantilal

493

1207

Atul Harsukhlal
Joshi

Gen

31.03.17

Rajkot

Harsukhlal
Jeshankar
Joshi

494

1212

Pravinaben
Gangaram Surti

SC

04.01.17

Surat City

Gangaram
Keshavbhai
Surti

495

1214

Chandresh
Jayantilal
Lakdawala

OBC

04.01.17

Surat City

Jayantilal
Nagindas
Lakdawala

496

1216

Patel Vishal
Sharadkumar

Gen

21.04.17

Ahmadabad
City

Sharadkumar C
Patel

497

1218

Rajendrasinh
Dharmendrasinh
Gohil

Gen

04.01.17

Rajkot

Dharmendrasin
h Bapalal Gohil

498

1224

Parmar
Nitinkumar
Kantilal

SC

04.11.17

Himatnagar

Parmar Kantilal
Lalabhai

Block No. B/46 Aalap
Avenue 80 Ft Road
University Road
Puskardham Road
Rajkot,Rajkot,Gujarat
162 Siddhivinayak Nagar
Government
Colony,Kachchh,Gujarat
Yagni 1.Ganesh Park Opp
Chandan Park Raiya Road
Rajkot,Rajkot,Gujarat
80. Shree Keshav Nivas.
B.H. Udhna Railway Yard.
Near Saibaba Society.
Udhna. Surat.,Surat,Gujarat
49. Deepjyot Society. B.H.
Dipanjali Society. Opp.
Nana Nani Garden.
Palanpur Road.
Surat.,Surat,Gujarat
B 17 Karnavatinagar Nr
Swaminarayan Mandir B/H
Parswanath Township Nava
Naroda
Ahmedabad,Ahmadabad,G
ujarat
Raj Chamunda Block No
134 Street No 4b Opp
Radhika Dairy Rail Nagar 2
Rajkot,Rajkot,Gujarat
At And Po Vaktapura Ta
Himatnagar Dist
Sabarkantha,Sabar
Kantha,Gujarat

G/111/2006
Dt.29.02.2000

G/4250/1999
Dt.19.09.98
G/2676/2000
Dt.09.09.2000
G/1078/2009
Dt.08.08.09

G/1067/1998
Dt.28.11.98

G/2062/2001
Dt.19.09.01

G/1891/2000
Dt.06.08.2000

G/1120/2005
Dt.03.07.05

<!-- page 58 -->

499

1225

Hemanshu
Pravinbhai
Shishangiya

500

1230

Laljibhai
Govindbhai
Degama

OBC

05.02.17

Rajkot

Govindbhai
Gandabhai
Degama

501

1231

Bina Modi

OBC

04.12.17

Bharuch

Rameshchandr
a Mehta

502

1246

Pushkar
Manishankar
Joshi

Gen

04.04.17

Surat City

Manishankar
Pitambar Joshi

503

1252

Oza
Jagdishkumar
Bhagavanbhai

OBC

04.04.17

Santalpur

Bhagavanbhai

504

1257

Tadvi
Umeshkumar
Ramanbhai

ST

04.09.17

Nandod

Ramanbhai

505

1258

Vaghela
Jayeshbhai
Dayabhai

SC

04.05.17

Limbdi

Dayabhai

506

1261

Vithlani
Hareshkumar
Manshukhlal

Gen

04.05.17

Rajkot

Manshuhlal

1265

Rahulbhai
Bhikhabhai
Vasava

ST

15.06.17

Bharuch

Bhikhabhai

507

OBC

04.05.17

Rajkot

Pravinbhai

Mangal Pravin Walkeshwar
Society Main Road Near
Hasanwadi,RAJKOT,GUJA
RAT
Jamna Park Street No 7
Corner Morbi Road
Jakatnaka Near Khodiyar
Gen Store,Rajkot,Gujarat
22 Modheshwari Nagar
Opp. District Court
,Bharuch,Gujarat
B.2.19. Shivam Complex.
Near L.P.D. School. Puna
Gam Road. Surat
,Surat,Gujarat
Moto Prajapativas At Varahi
Ta Santalpur,Patan,Gujarat
Tekara Falia At Amadala Po
Zariavadi Ta
Garudeshwar,Narmada,Guj
arat
At Karol Ta Chuda Dist
Surendranagar Gujarat
363410,Surendranagar,Guj
arat
Jalaram Ashish 3
Dwarkadhir Soc Mavadi
Rajkot,Rajkot,Gujarat
2 Vinaypark Society Nr
Gayatri Flat Maktampur
Bharuch,BHARUCH,GUJA
RAT

G/1932/2005
Dt.17.07.05

G/2824/2004
Dt.26.12.04
G/1241/2008
Dt.07.09.08
G/2111/2002
Dt.11.09.02
G/1056/2004
Dt.10.07.04
G/881/2005
Dt.28.05.05

G/3058/1999
Dt.08.08.99
G/2688/2001
Dt.04.11.01
G/505/2009
Dt.13.06.09

<!-- page 59 -->

508

1266

Shah Varsha
Babulal

509

1270

Ashokkumar
Shamjibhai
Saradva

1272

Rajesh Jethalal
Joshi

510

Sureshkumar
Amarshibhai
Savani
Dipakkumar
Dineshchandra
Dave

Gen

Gen

Gen

16.05.17

Ahmadabad
City

Shah Babulal
Shivlal

J.311 Shreenandnagar Part
1 Opp Jain Derasar
Vejalpur,Ahmadabad,Gujar
at

G/31/2002
Dt.03.01.02

04.06.17

Morvi

Shamjibhai
Vasharambhai
Saradva

2 Sahyog Socity Ravapar
Road Morbi,Morbi,Gujarat

G/2523/2002
Dt.15.10.02

Morvi

Jethalal
Narmadashank
ar Joshi

04.06.17

Gen

04.06.17

Surat City

Amarshibhai
Bhikhabhai
Savani

Gen

04.11.17

Rajkot

Dineshchandra

OBC

04.06.17

Jetpur

Jayantigiri
Umaravgiri
Gosai

04.07.17

Rajkot

Rameshbhai
Dayaljibhai
Ruparel

Gen

24.04.17

Ahmadabad
City

Rajanikant S
Pandya

OBC

26.04.17

Mahesana

Mukundlal

511

1273

512

1274

513

1278

Satyen Jayantigiri
Gosai

514

1280

Rashmin
Rameshbhai
Ruparel

Gen

515

1283

Pandya Mitesh
Rajanikant

516

1284

Barot Kanaiyalal

Rava Par Road Subhash
Nagar Street No 7 Block No
203 Soham Nr Kenal
Morbi,Morbi,Gujarat
B.502 Platinum Heights
Opp Utran Power House
Utran,Surat,Gujarat
Gauri Krupa 4 Hansaraj
Nagar Nr Railway Junction
Main Road,Rajkot,Gujarat
Khodapara Main Road
Jetpur,Rajkot,Gujarat
A 304 Mansa Tirth
Appratment 1 Opp Geeta
Mandir Nr Bhakti Nagar
Circle,Rajkot,Gujarat
B/8 Parasmani Flat Nr
Daxini Society Maninagar
Ahmedabad,Ahmadabad,G
ujarat
9/B 108 Gayatrikrupa
Society Nr Ramba Girls
School Nagalpur
Mehsana,Mahesana,Gujara
t

G/1968/2000
Dt.06.08.2000
G/834/2003
Dt.22.06.03
G/168/2003
Dt.25.01.03
G/765/2003
Dt.23.06.03
G/1862/2005
Dt.17.07.05

G/308/1996
Dt.08.03.96

G/1707/2000
Dt.14.08.2000

<!-- page 60 -->

517

1286

Rekha
Rohitkumar Patel

Gen

17.05.17

Ahmadabad
City

Motiram S
Rajput

518

1289

Hemang
Mahendrabhai
Jani

Gen

04.11.17

Rajkot

Mahendrabhai
Maganbhai Jani

519

1290

Kamleshkumar
Natvarlal Mochi

OBC

20.04.17

Himatnagar

Natvarlal
Govindbhai
Mochi

520

1291

Arvindbhai
Maganbhai
Vasani

Gen

14.04.17

Rajkot

Maganbhai
Vasani

521

1295

Solanki
Rahulkumar
Tapubhai

SC

04.10.17

Amreli

Solanki
Tapubhai
Govindbhai

522

1300

Naina Arun Tank

SC

04.10.17

Surat City

Govindbhai
Premjibhai Mori

523

1307

Alpa Amrutlal
Modh

Gen

04.11.17

Vapi

Amrutlal Modh

524

1308

Vekariya Amit
Bhupendrabhai

Gen

15.05.17

Rajkot

Vekariya
Bhupendrabhai
Panchabhai

28 D Kali Gopal Nagar
Tejendra.4 Nr Sarvottam
Nagar Sabarmati
Ahmedabad,Ahmadabad,G
ujarat
Anand Rameshwar Chowk
Bh Amrapali Cinema
Shreeji Nagar
Rajkot,Rajkot,Gujarat
Girnar Society Opp
Rushabhdev Society
Hanumanji Mandir Gali
Pologround,Sabar
Kantha,Gujarat
Shivam Block.47 Om
Residency Bh..Gol
Residency Nr..Nanamava
Rajkot,Rajkot,Gujarat
Baharpara Savarkundla
Road Sai
Krupa,Amreli,Gujarat
108. Mehta Nagar Society.
Near Radhaswami Society.
Singanpor Char Rasta. Ved
Road. Katargam.
Surat.,Surat,Gujarat
A.10 Alkapark Shopping
Centre Jalaram Medical
Store Tin Rasta
Sarigam,Valsad,Gujarat
Block No.24 Alay
Residency Behind Alap
Heritage Satya Sai Hospital
Road,Rajkot,Gujarat

G/205/2010
Dt.09.02.10

G/846/2004
Dt.10.07.04

G/267/2010
Dt.09.02.10

G/1649/1999
Dt.13.02.99
G/1162/2007
Dt.30.07.07

G/4761/1999
Dt.05.11.98

G/76/2005
Dt.12.02.05

G/2876/2006
Dt.02.12.06

<!-- page 61 -->

525

1311

Kothiya Rakesh
Trikambhai

Gen

04.11.17

Rajkot

Kothiya
Trikambhai

526

1312

Jagdish
Chhaganbhai
Sorthiya

Gen

04.11.17

Rajkot

Chhaganbhai
Mithabhai
Sorthiya

527

1313

Hursangji Gemarji
Thakor

OBC

05.10.17

Danta

Gemarji

528

1314

Champaneri Ajay
Natvarlal

Gen

04.12.17

Rajkot

Champaneri
Natvarlal

529

1315

Bhatt Haresh
Chimanlal

Gen

04.12.17

Rajkot

Bhatt Chimanlal

530

1316

Pandya Aruna
Harilal

Gen

04.12.17

Rajkot

Harila Mayaram
Pandya

531

1317

Rathawa
Kachubhai
Sisalabhai

ST

04.12.17

Bodeli

Rathawa
Sisalabhai
Chimabhai

532

1318

Joshi
Prakashkumar
Bachubhai

Gen

04.12.17

Kankrej

Joshi
Bachubhai
Panaram

533

1320

Parmar Maghaji
Chaturji

OBC

04.12.17

Kankrej

Parmar Chaturji
Kaluji

Rakesh Kunj 4 New Shakti
Soc Sant Kabir Road
Rajkot,Rajkot,Gujarat
5 Mehul Nagar Patel Pan
Street Kothariya Road
Rajkot,Rajkot,Gujarat
At . Bamaniya Post . Moriya
Ta . Danta,Banas
Kantha,Gujarat
Vasanti 1a Bhaktinagar Soc
Bh Hemani Hospital
Rajkot,Rajkot,Gujarat
Rudra 3 Chhotu Nagar
Block No 13b1 Raiya Road
Rajkot,Rajkot,Gujarat
Nirmal Ravi Railnagar 3
Street No 4 Block No 153
Bajarang Vadi Main Road
Jamnagar
Road,Rajkot,Gujarat
3 Shreenathji Society Beda
Faliya Tokij Road Ta
Jetpurpavi,Chhotaudepur,G
ujarat
At And Po.Umbari
Ta.Kankrej ,Banas
Kantha,Gujarat
At And Po.Khimana
Ta.Kankrej ,Banas
Kantha,Gujarat

G/1977/2005
Dt.17.07.05
G/2022/2005
Dt.17.07.05
G/413/ 2005
Dt.05.03.05
G/4841/1999
Dt.05.12.99
G/2762/1999
Dt.04.07.99

G/2370/2000
Dt.09.09.2000

G/2124/2003
Dt.01.01.03
G/71/1997
Dt.30.07.97
G/1443/2000
Dt.22.07.2000

<!-- page 62 -->

534

1321

Chavda
Satyenkumar
Ratilal

535

1322

Yazadi Darbsha
Ichhaporiya

Gen

04.12.17

Surat City

Darbsha
Dinshaji
Ichhaporiya

536

1324

Tadvi Kishorbhai
Jikubhai

ST

04.12.17

Tilakwada

Tadvi Jikubhai
Ukkedbhai

537

1329

Solanki Dhiraj
Rajnikant

SC

17.04.17

Ahmadabad
City

Solanki
Rajnikant
Shakarabhai

538

1333

Nileshkumar
Natwarbhai Surati

SC

27.04.17

Olpad

Natwarbhai
Durlabhbhai
Surati

539

1334

Vasava
Balvantbhai
Balubhai

ST

13.04.17

Nandod

Vasava
Balubhai
Chandubhai

540

1339

Halaiya
Ripalkumar
Nathubhai

SC

05.02.17

Amreli

Halaiya
Nathubhai
Khodabhai

541

1340

Divyesh
Punamchand
Jumkhawala

OBC

13.04.17

Surat City

Punamchand
Nanabhai
Jumkhawala

542

1344

Jayantkumar
Dhulabhai
Makwana

SC

26.05.17

Ahmadabad
City

Dhulabhai
Govindbhai
Makwana

543

1347

Jignesh
Pravinbhai
Pisadia

Gen

14.04.17

Surat City

Pravinbhai
Bhagvatibhai
Pisadia

OBC

04.12.17

Upleta

Ratilal

Pratiksha 6 Trilokdham
Society Near Dwarkadhish
Society B/H Janta Garden
At Upleta,Rajkot,Gujarat
21. Ashirwad Society. Near
Navyug College. Rander
Road. Surat ,Surat,Gujarat
At.Po.Rangen Ta.Tilkwada
Dist.Narmada,Narmada,Guj
arat
147/1149 G H Board Opp
Sharda School
Kalapinagar,Ahmadabad,G
ujarat
At.Kasad Po.Takarma
Ta.Olpad
Dist.Surat,Surat,Gujarat
At.Po.Timbi (Khakhrepura)
Ta.Nandod
Dist.Narmada,Narmada,Guj
arat
Batarvadi Shiv Shakti Near
Patel Disels
Street,Amreli,Gujarat
67. Giriraj Society. 2. Near
Sagar Complex. Anand
Mahal Road Adajan. Surat
,Surat,Gujarat
C 62/63 Punitnagar Society
Near Cadila Crossing
Ghodasar,Ahmadabad,Guja
rat
131. Jay Jalaram Nagar
Society. Opp. Petrol Pump.
Jahangirpura.
Surat,Surat,Gujarat

G/1084/1999
Dt.21.03.99
G/2800/2006
Dt.02.12.06
G/46/2009
Dt.07.02.09
G/2735/2002
Dt.17.12.02
G/1794/2007
Dt.13.10.07
G/4025/1999
Dt.19.09.99
G/1683/2007
Dt.13.10.07
G/1409/2007
Dt.07.09.07

G/648/1984
Dt.23.08.84

G/2719/2006
Dt.07.10.06

<!-- page 63 -->

544

1350

Mehta
Bharatkumar Hirji

Gen

18.04.17

Mandvi

545

1351

Parghi
Jaysukhbhai
Kalabhai

SC

14.04.17

Gondal

546

1352

Purnima
Harshadrai Mehta

Gen

15.04.17

Rajkot

547

1355

Hitesh Kanaiyalal
Joshi

Gen

17.04.17

Rajkot

548

1358

Jhala
Jayadityasinh
Vikramsinh

Gen

28.04.17

Rajkot

Jhala
Vikramsinh

549

1360

Vasudev
Jagjivanbhai
Pandya

Gen

21.04.17

Rajkot

Jagjivanbhai
Pandya

550

1365

Jadeja
Jitendrasinh
Dilawarsinh

Gen

24.04.17

Rajkot

Dilawarsinh
Sajjansinh
Jadeja

551

1367

Rajeshbhai
Babubhai Ramani

Gen

19.04.17

Surat City

Babubhai
Nagjibhai
Ramani

552

1371

Barmeda Pooja
Shashikant

Gen

21.04.17

Anjar

Shashikant

553

1373

Jagdishkumar
Jitendraprasad
Joshi

Gen

23.09.17

Deesa

Jitendraprasad
S Joshi

554

1374

Mahipalsinh
Gulabsinh
Vansiya

Gen

18.04.17

Surat City

Gulabsinh
Jaysinh
Vansiya

Hirji
Kalabhai
Deshabhai
Parghi
Harshadrai
Amarchand
Mehta
Kanaiyalal
Chunilal Josih

Village.Durgapur
Tal.Mandvi
,Kachchh,Gujarat
At Gondal Bhagvatpara
Domadiya Society
,Rajkot,Gujarat
Vidhyabhavan Flat No . 2
22/39 New Jagnath
Rajkot,Rajkot,Gujarat
Guru Krupa 6 Laxmiwadi
Rajkot,Rajkot,Gujarat
At Ankevadiya Ta Limbadi
Dist
Surendranagar,Surendrana
gar,Gujarat
14 Ramnath Para Gayatri
Darshan
Rajkot,Rajkot,Gujarat
Sajjan Pratap 26/B
Niranjani Socity Nr Saurabh
Soctiy Comunity Hall Raiya
Road Rajkot,Rajkot,Gujarat
86 Kamal Park Society 2 Nr
Spining Mill Kapodra L H
Road
Varachha,Surat,Gujarat
Shivaji Road Opp. Pujara
Faliya
Anjar,Kachchh,Gujarat
16 Meghdoot Society Nr
Kachhi Colony
Deesa,Banas
Kantha,Gujarat
23. New Faliyu. Sachin.2.
Ta. Choryasi. Surat
,Surat,Gujarat

G/944/1999
Dt.21.03.99
G/1783/2000
Dt.06.08.2000
G/395/2010
Dt.04.04.10
G/593/1994
Dt.12.08.94
G/396/2004
Dt.27.03.04
G/370/1993
Dt.22.06.93
G/836/1989
Dt.06.10.89

G/2044/2004
Dt.26.09.04
G/1193/2007
Dt.30.07.07
G/2364/2004
Dt.26.09.04
G/2232/2002
Dt.11.09.02

<!-- page 64 -->

555

1377

Jitendra
Popatbhai
Mangukiya

556

1381

Harvadanbhai
Valjibhai Umrigar

557

1382

558

1388

Rupal Ajitprasad
Pathak
Rashesh
Pareshbhai
Gandhi

Gen

19.04.17

Surat City

Popatbhai
Muljibhai
Mangukiya

OBC

18.04.17

Surat City

Valjibhai
Ramabhai
Umrigar

Gen

18.04.17

Dohad

Ajitprasad
Pathak

14 Ramdev Raw House
Opp. Mansarovar 4 Yogi
Chowk Punagam
Surat,Surat,Gujarat
Old. Daviyawad Street.
Athva. Umra. Post.
S.V.N.I.T College.
Ichchanath.
Surat.,Surat,Gujarat
K K House Nilam Society
Dahod,Dohad,Gujarat

Gen

05.04.17

Rajkot

Pareshbhai
Gandhi

201 Suman Arced Raiya
Road Rajkot,Rajkot,Gujarat

559

1389

Bhut Panna
Bachubhai

560

1392

Sondagar Tushar
Dilipbhai

OBC

27.04.17

Rajkot

Dilipbhai Ratilal
Sondagar

561

1394

Brahamania
Suhasini
Laxmikant

SC

05.06.17

Ahmadabad
City

Laxmikant
Chhanabhai
Brahamania

562

1395

Amrut Maganlal
Pandya

Gen

24.04.17

Rajkot

Maganlal
Harjivanbhai
Pandya

1396

Vijaybhai
Narendrabhai
Gohel

OBC

24.04.17

Rajkot

Narendrabhai
Gohel

563

Gen

26.04.17

Rajkot

Bachubhai
Premjibhai Bhut

Vishal Complex Second
Floor Block No 4 Mavdi
Main Road
Rajkot,Rajkot,Gujarat
Ravi Randal 1/13
Udaynagar Mavdi Main
Road Rajkot,Rajkot,Gujarat
265 Rohitnivas Nr
Ramjimandir Kochrab
Bhilwas
Paldi,Ahmadabad,Gujarat
Chandra Mauli Kailash
Nagar Nr Modi School 150
Feet Ring Road
Rajkot,Rajkot,Gujarat
Shree Ram Krupa Shree
Nathdwara Park Block No
105 Opp Railnagar Bh
Popatpara,Rajkot,Gujarat

G/2471/2002
Dt.29.09.02

G/349/1994
Dt.04.05.94
G/2095/2009
Dt.03.12.09
G/2006/2005
Dt.17.07.05
G/1728/2001
Dt.18.09.01
G/544/2008
Dt.20.06.08
G/88/1999
Dt.13.02.98

G/443/2006
Dt.19.02.06

G/1320/2003
Dt.10.08.03

<!-- page 65 -->

564

1397

Dharmesh
Rajnikant Joshi

Gen

24.04.17

Rajkot

Rajnikant
Vinodrai Joshi

565

1400

Umesh
Mahendrabhai
Patel

Gen

21.06.17

Dehgam

Mahendrabhai
H Patel

566

1403

Ileshkumar
Pramodbhai Patel

OBC

05.02.17

Olpad

Pramodbhai
Haribhai Patel

567

1407

Mistri
Zankhanaben
Rasiklal

OBC

20.04.17

Idar

Mistri Suthar
Rasiklal P

568

1408

Patel Jagdishbhai
Prabhudas

Gen

20.04.17

Prantij

Patel
Prabhudas
Shivabhai

569

1412

Chitrodia
Kalyankar
Kangibhai

SC

05.09.17

Ahmadabad
City

Kangibhai A
Chitrodia

570

1413

Kansara
Kiritkumar

Gen

29.04.17

Mahesana

Natvarlal

571

1414

Atulkumar
Ishverbhai Patel

OBC

05.02.17

Olpad

Ishverbhai
Parbhubhai
Patel

Manisha Kailash Nagar
Socity Street No 2 Nr
Gandhi Gram
Policestation,Rajkot,Gujarat
16 Akshardham Township
B/H Kalpana Nagar
Society.1 Ta
Dahegam,Gandhinagar,Guj
arat
B. 27 Dhan Laxmi Society .
B/H Ahir Auto At . Po.
Sayan . Ta .
Olpad,Surat,Gujarat
45 Pushpkunj Society Opp
Arts And Commerce
College Valasana Road
Idar,Sabar Kantha,Gujarat
Approach Road At Po.
Majara Ta. Prantij,Sabar
Kantha,Gujarat
17/19 Mahalaxmi
Appartment Soni Ni Chali
Cross Road Odhav
Ahmedabad,Ahmadabad,G
ujarat
6 Sattadhar Bunglow
Manav Ashram Circul
Visnagar Road
Mehsana,MAHESANA,GUJ
ARAT
Mandir Faliyu At . Rundh
(Shekhpur) Po . Va .Sayan .
Ta . Kamrej,Surat,Gujarat

G/3030/2000
Dt.25.11.2000

G/1774/2005
Dt.17.07.05

G/418/2003
Dt.22.02.03

G/215/2008
Dt.14.03.08
G/726/2001
Dt.21.06.01

G/2191/2000
Dt.09.09.2000

G/278/1993
Dt.23.04.93

G/1172/1994
Dt.22.12.94

<!-- page 66 -->

572

1415

Bhavna
Narendrakumar
Anadkat

573

1417

Bhavesh
Chandulal Pattani

Gen

05.10.17

Rajkot

Chandulal
Ratanshi
Pattani

574

1421

Naran Kanji
Gadhavi

OBC

24.05.17

Mandvi

Kanji Dhanraj
Gadhavi

575

1422

Shailesh
Chhaganbhai
Solanki

OBC

22.04.17

Surat City

Chhaganbhai
Bhalabhai
Solanki

576

1426

Geetaben Kantilal
Vaghela

SC

05.10.17

Ahmadabad
City

Kantilal
Haribhai
Vaghela

577

1427

Hemantkumar
Nagindas Modi

OBC

26.04.17

Palanpur

Nagindas

578

1429

Natvarlal
Dharmabhai
Parmar

SC

26.04.17

Palanpur

Dharmabhai

579

1430

Dilipsinh
Manharsinh
Mahida

Gen

06.08.17

Olpad

Manharsinh
Prabhatsinh
Mahida

580

1431

Vijaykumar
Khushalbhai
Patel

OBC

21.06.17

Olpad

Khushalbhai
Dahyabhai
Patel

Gen

27.04.17

Rajkot

Popatbhai

Sadguru Krupa Block No
E71 Nilkanth Park Bh
Nilkanth
Cinema,Rajkot,Gujarat
Vishvajeet 2 Geeta Nagar
Dhebar
Road,Rajkot,Gujarat
Plote No. 59 Ayodhya
Nagar
Mandvi,Kachchh,Gujarat
A/105 Smruti Society Near
Gajera Circle Fulpada Road
Katargam
Surat,Surat,Gujarat
14/423 Ashoka Awash New
C G Road Chandkheda
Ahmedabad,Ahmadabad,G
ujarat
21/B/3 Kailashnagar O/S.
Becharpura Fatak
Palanpur,Banas
Kantha,Gujarat
Son Bag Near Mira Gate
Near Chabutaro
Palanpur,Banas
Kantha,Gujarat
B/7 Dattkrupa Society
Sehara Bai Jeen Road At .
Po. Kim . Ta .
Olpad,Surat,Gujarat
Masma Faliyu At . Po.
Ishanpor Ta .
Olpad,Surat,Gujarat

G/783/2007
Dt.29.06.07
G/1044/1994
Dt.26.10.94
G/11338/2008
Dt.26.07.08
G/1927/2007
Dt.29.11.07

G/1061/2005
Dt.03.07.05

G/2456/1999
Dt.28.04.99

G/14/2006
Dt.29.01.06

G/2568/2006
Dt.07.10.06
G/1427/2009
Dt.11.09.09

<!-- page 67 -->

Patel
Mohmedsiddik
Yunus Ismail
Jagatprakash
Naraindas
Mansharamani

Gen

24.04.17

Bharuch

Patel Yunus
Ismail

Gen

28.04.17

Rajkot

Naraindas
Namomal
Mansharamani

Gautamkumar
Kanjibhai Rana

SC

05.09.17

Ahmadabad
City

Kanjibhai J
Rana

1436

Rathod
Hansaben
Tribhovanbhai

SC

05.11.17

Ahmadabad
City

Tribhovanbhai
D Rathod

585

1444

Rohini Prabhakar
Kurlekar

Gen

05.05.17

Ahmadabad
City

Prabhakar G
Kurlekar

586

1449

Joshi Jignasa
Jagdishchandra

Gen

26.04.17

Vadodara

Jagdishchandra
Chunilal Joshi

587

1452

Prajapati
Mahendrakumar

OBC

28.04.17

Mahesana

Kantilal

588

1455

Kalavanti
Khakhan Gala

Gen

10.04.17

Bhachau

Khakhan

581

1432

582

1434

583

1435

584

143 New Estate At Post
Manubar Ta
Bharuch,Bharuch,Gujarat
Sheetal Chhaya Sadar
Bazar Main Road
Rajkot,Rajkot,Gujarat
B.16 Anushree Nivas New
Kamal Kunj Society Ioc
Road Chandkheda
Ahmedabad,Ahmadabad,G
ujarat
B/35 Vaidehi Co Op Society
B/H Navrang Tenament.2
Isanpur Vatva Road
Ahmedabad,Ahmadabad,G
ujarat
4 Mukund Appartment
Maniyasha Road Maninagar
E
Ahmedabad,Ahmadabad,G
ujarat
C/102 Motibhai Park Opp.
Vaikunth . 2 New Vip Road
Vadodara,Vadodara,Gujarat
At Anandpura Post
Dangarwa Ta Kadi Dist
Mehsana
,MAHESANA,GUJARAT
Plot No.4 Santi Nagat
Behind ST Depot
Samakhiyali
Vill.Samakhiyali
Ta.Bhachau,Kachchh,Gujar
at

G/3216/2005
Dt.28.10.05
G/652/1980
Dt.22.11.80

G/205/1988
Dt.23.04.88

G/312/2008
Dt.17.05.08

G/485/1999
Dt.21.03.99

G/1598/1995
Dt.21.12.95
G/224/2004
Dt.20.02.04

G/206/2010
Dt.09.02.10

<!-- page 68 -->

SC

27.04.17

Rajkot

Upendrabhai
Rajabhai
Rathod

SC

27.04.17

Surat City

Gopalbhai
Morarbhai
Chauhan

Gen

29.04.17

Himatnagar

Shankarbhai

Javidhusain
Abdulrahim
Multani

OBC

27.04.17

Surat City

Abdulrahim
Multani

1463

Dipikaben
Mavjibhai
Chaudhari

Gen

16.06.17

Tharad

Mavjibhai

594

1465

Vasava
Dineshbhai
Bhangabhai

ST

29.04.17

Sagbara

Bhangabhai
Vasava

595

1466

Vipul Babulal
Kansara

Gen

28.04.17

Palanpur

Babulal

596

1467

Gen

28.04.17

Surat City

Kanjibhai
Dharamshibhai
Dudhagara

597

1471

OBC

05.02.17

Botad

Jesingbhai

598

1472

Gen

28.04.17

Bharuch

Thakore
Bhagatsinh
Jivansinh

589

1458

590

1459

591

1461

592

1462

593

Dilsukh Upendra
Rathod
Hasmukhbhai
Gopalbhai
Chauhan
Patel
Ashokkumar
Shankarbhai

Hasmukh
Kanjibhai
Dudhagara
Vijaybhai
Jesingbhai
Chavda
Thakore
Virendrasinh
Bhagatsinh

Chamunda Krupa
Meghmaya Nagar 4
Rajnagar Chowk Nana
Mava Main
Road,Rajkot,Gujarat
64.64. Arihant Park Society.
Chhaparabhatha Road.
Amroli. Surat.,Surat,Gujarat
At Fojivada Po Kabodara
Ta Talod,Sabar
Kantha,Gujarat
7/2971. Swastik Apartment.
Flat No.4. Nani Kadiya
Sheri. Saiyadpura.
Surat,Surat,Gujarat
32 Madhav Nagar Society
Near Highway Char Rasta
Tharad,Banas
Kantha,Gujarat
Bhangabhai Aanganvadi
Faliyu Amiyar Amiyar
Sagbara,Narmada,Gujarat
11/1 Kasiba Nagar Near
Karnavat School Gobri
Road Palanpur,Banas
Kantha,Gujarat
18. J.T. Nagar Society.
Puna Bombay Market
Road. Surat.,Surat,Gujarat
Bhagat Ni Wadi Near Old
Daliya Factory
Botad,Botad,Gujarat
Fata Talav Gadariawad
Bharuch,Bharuch,Gujarat

G/51/2005
Dt.12.02.05

G/1984/2007
Dt.13.12.07
G/1136/2005
Dt.03.07.05
G/2850/2000
Dt.23.09.2000

G/396/2010
Dt.04.04.10
G/1594/2007
Dt.07.09.07
G/1733/2001
Dt.18.09.01
G/1802/1999
Dt.21.03.99
G/1867/2005
Dt.17.07.05
G/899/1987
Dt.31.12.87

<!-- page 69 -->

599

1473

Mukeshkumar
Natvarlal Nadoda

Gen

05.05.17

Surat City

Natvarlal
C.Nadoda

600

1474

Kishor Pragjibhai
Bhanvadia

Gen

05.03.17

Rajkot

Pragjibhai
Vaghjibhai
Bhanvadia

601

1476

Mansukh
Devshibhai
Chavda

SC

29.04.17

Jamkandorna

Devshibhai
Nathabhai
Chavda

602

1477

Sharma Harish
Ghanshyam

Gen

20.05.17

Ahmadabad
City

Ghanshyam N
Sharma

603

1478

Hemalkumar
Bhupendrabhai
Gohel

OBC

05.06.17

Rajkot

Bhupendrabhai
Kanjibhai Gohel

604

1480

Jayvirsinh
Devubha Jadeja

Gen

05.03.17

Bhuj

Devubha
Jadeja

605

1481

Rushi
Nautambhai Joshi

Gen

29.04.17

Rajkot

Nautambhai
Bhanubhai
Joshi

606

1484

Banjara
Shyamkumar
Mangilal

OBC

05.08.17

Ahmadabad
City

Mangilal K
Banjara

607

1485

Arunkumar
Manilal Parmar

OBC

19.05.17

Palanpur

Manilal

19 Rajhans Society
Nr.Krishna Resi.
Ambatalawadi
Katargam,Surat,Gujarat
Block No 33 Prashil Park
Opp Neels City Club
University Road
Rajkot,Rajkot,Gujarat
At.Dadvi Ta.Jamkandorna
Dist.Rajkot,Rajkot,Gujarat
833 Veji Bhai Well Motera
Road Sabarmati
Ahmedabad,Ahmadabad,G
ujarat
Aadharsh 16 A Natraj
Nagar Main Road Opp
Natraj Complex University
Road Rajkot,Rajkot,Gujarat
210 Shyam Banglow Odhav
Avenue.1 Near Mundra
Relocation Site
Bhuj,Kachchh,Gujarat
Flat No 104 Shanti Kalash 2
Vidhiyanagar
Rajkot,Rajkot,Gujarat
71/80 Mohanlal Vakil Chawl
Chamanpura Asarwa
Ahmedabad,Ahmadabad,G
ujarat
Sukha Mehta No Madh
Khoda Limda
Palanpur,Banas
Kantha,Gujarat

G/3396/2005
Dt.18.12.05

G/107/1975
Dt.01.05.05
G/4409/1999
Dt.16.10.99
G/688/1998
Dt.22.08.98

G/1855/2005
Dt.17.07.05

G/1854/2006
Dt.09.07.06
G/1912/2001
Dt.18.09.01
G/117/1997
Dt.20.08.97

G/811/1992
Dt.06.10.92

<!-- page 70 -->

1486

Narendra
Laxmanbhai
Kakadiya

609

1487

Samirkumar
Chimanbhai Patel

OBC

610

1490

Ajaykumar
Kanjibhai Gohil

611

608

Gen

29.04.17

Surat City

Laxmanbhai

29.04.17

Surat City

Chimanbhai
Maganbhai
Patel

OBC

29.04.17

Surat City

Kanjibhai
Gangdas Gohil

1491

Dhabaliya
Girishkumar
Chandrakant

Gen

19.05.17

Gondal

Chandrakant

612

1504

Atulkumar Hiralal
Sutaria

SC

05.11.17

Ahmadabad
City

Hiralal P
Sutaria

613

1508

Bipinkumar
Pitambarbhai
Jadav

SC

05.11.17

Ahmadabad
City

Pitambarbhai M
Jadav

614

1511

Patel
Ashokkumar
Laxmanbhai

OBC

06.01.17

Palanpur

Laxmanbhai

615

1515

Mauna Vijaysinh
Dikhit

Gen

05.06.17

Ahmadabad
City

Vijaysinh L
Dikhit

616

1518

Shukla Kaushal
Narendrakumar

Gen

17.06.17

Mahesana

Narendrakumar

46 Shivshankar Parvati
Society Varachha
Road,Surat,Gujarat
204. Sandhyavandan Row
House. Palanpur
Jakatnaka. Mini Virpur
Road. Surat.,Surat,Gujarat
B.1102 Kalpavrukshaa
Garden Opp. Nakshtra
Heights Gaurav Path Road
Pal,Surat,Gujarat
9 Radhakrushna Nagar
Gondal Dist
Rajkot,Rajkot,Gujarat
Ratnadeep Gayatrinagar
Opp Hanuman Chawk
Sarkhej Gam
Ahmedabad,Ahmadabad,G
ujarat
376/81 Gayatri Nagar Nr
Baliya Dev Temple Sarkhej
Gam
Ahmedabad,Ahmadabad,G
ujarat
Patel Vas At And Post .
Jalotra Ta . Vadgam,Banas
Kantha,Gujarat
11 Govardhan Appartment
Jayent Park Society
Bhaduat Nagar Isanpur
Road
Ahmedabad,Ahmadabad,G
ujarat
72/Dharti Township Dhobi
Ghat Road Opp Patidar
Society,Mahesana,Gujarat

G/1963/2003
Dt.31.08.03
G/2909/2006
Dt.02.12.06

G/584/2009
Dt.13.06.09
G/93/1992
Dt.23.02.92

G/318/1995
Dt.15.03.95

G/73/2007
Dt.02.03.07

G/1780/ 2008
Dt.15.11.08

G/347/2009
Dt.28.03.09

G/1941/2004
Dt.14.08.04

<!-- page 71 -->

617

1520

Parmar
Dharmendrakuma
r Ramanlal

SC

05.04.17

Vadodara

Ramanlal
Laxmanbhai
Parmar

618

1521

Vijaykumar
Gomanbhai Ahir

OBC

05.03.17

Chorasi

Gomanbhai
Sukhabhai Ahir

619

1524

Jyotikumari
Sureshbhai Patel

OBC

05.04.17

Surat City

Sureshbhai
Patel

620

1527

Patel Snehaben
Hasmukhbhai

Gen

05.04.17

Anklesvar

Patel
Hasmukhbhai
Bhavanbhai

621

1530

Anil Maganlal
Gajjar

OBC

07.01.17

Ahmadabad
City

Maganlal

622

1531

Hemant
Kaushikbhai
Bhatt

Gen

05.05.17

Ahmadabad
City

Kaushik
Manubhai Bhatt

623

1533

Minaxi
Chhaganbhai
Parmar

SC

05.05.17

Vadodara

Chhaganbhai
Parmar

624

1539

Chavda Gautam
Kanjibhai

SC

05.08.17

Rajkot

Chavda
Kanjibhai
Rajabhai

A/41 Meera Society
Diwalipura Old Padra
Road,Vadodara,Gujarat
41. Iswar Darshan Soc.
Kumbhariya Gam. Nr.
Laxmi Nagar. Puna
Kumbhariya Road. Ta.
Choryasi.
Surat.,Surat,Gujarat
B/H Sahakari Mandali At .
Po . Masma Ta .
Olpad,Surat,Gujarat
Desai Faliya At Post Govali
Ta
Jhagadia,Bharuch,Gujarat
21 Mamta Park Society
Opp. Chuval Society Gota
Road Chandlodia
Ahmedabad,Ahmadabad,G
ujarat
10 Mitra Milan Society Opp
Mirambica High School
Mirambica School Road
Naranpura
Ahmedabad,Ahmadabad,G
ujarat
A 1 Shree Krishna
Sarvoday Soc Opp Gorwa
Work Shop Subhan Pura
Vadodara,Vadodara,Gujarat
Shree Kuldevi Krupa 12
Ambedkar Nagar Aji
Vasahat 80 Feet
Road,Rajkot,Gujarat

G/1322/2000
Dt.24.06.2000

G/1749/2009
Dt.23.09.09

G/1638/2008
Dt.02.10.08
G/2430/2004
Dt.26.09.04

G/608/2003
Dt.26.04.03

G/1674/2001
Dt.18.09.01

G/1417/2009
Dt.11.09.09

G/2044/2006
Dt.24.07.06

<!-- page 72 -->

625

1540

Arti Subhashbhai
Rajwaniya

626

1541

Chavda Anilbhai
Devjibhai

SC

26.05.17

Limbdi

Chavda
Devjibhai
Jethabhai

627

1545

Bavaliya Magan
Gordhanbhai

OBC

05.12.17

Rajkot

Gordhanbhai

628

1546

Viken Mansukhlal
Gajiwala

OBC

05.06.17

Surat City

Mansukhlal
Manilal
Gajiwala

629

1548

Parekh
Satishkumar
Balkrishna

OBC

18.05.17

Ahmadabad
City

Balkrishna
Bhikhabha
Parekh

630

1552

Neha
Hiteshkumar
Koradia

Gen

26.05.17

Surat City

Hiteshkumar
Kantilal Koradia

631

1560

Rajeshkumar
Keshavlal
Sangharetia

SC

19.05.17

Daskroi

Keshavlal
Manilal
Sangharetia

632

1561

Sandeep Kirtibhai
Shah

Gen

13.05.17

Bhuj

Kirtibhai Shah

633

1562

Mukeshkumar
Prabhulal
Upadhyay

Gen

13.05.17

Bhuj

Prabhulal
Upadhyay

634

1568

Vaniya
Chandrakant
Bhanubhai

SC

15.05.17

Ahmadabad
City

Bhanubhai R
Vaniya

OBC

05.08.17

Ahmadabad
City

Subhashbhai B
Rajwaniya

6 Koshti Society Nr Jai Hind
High School Maninagar
Ahmedabad,Ahmadabad,G
ujarat
At .Untadi Ta.Limbdi
Dist.Surendranagar
,Surendranagar,Gujarat
At Gadhadiya Jam Ta
Jasdan Dist
Rajkot,RAJKOT,GUJARAT
9.549. Kotsafil Main Road.
Opp. Wadifaliya Bus Stand.
Surat.,Surat,Gujarat
Nr Om Shanti Bhawan
Village Kasindra Ta
Daskroi,Ahmadabad,Gujara
t
18. Green Enclave Row
House Near Sardar Bridge
Gujarat Gas Circle Adajan .
Surat,Surat,Gujarat
162 Aradhana At.Po.Nandej
Opp The Pont Nandej
Daskroi,Ahmadabad,Gujara
t
10 A Mahmad Pannah
Chamber Mahadev Gate
Bhuj,Kachchh,Gujarat
Sanidhyay Houses House
No.3 Mahavir Nagar
Bhuj,Kachchh,Gujarat
3 Sukhsagar Society Nr
Ambalal Park Danilimda
Ahmedabad,Ahmadabad,G
ujarat

G/2090/2001
Dt.18.09.01
G/804/2007
Dt.29.06.07
G/1113/2007
Dt.30.07.07
G/217/2003
Dt.25.01.03
G/1009/2008
Dt.18.07.08

G/2685/2006
Dt.07.10.06

G/2450/2002
Dt.29.09.02
G/857/2006
Dt.02.05.06
G/948/1995
Dt.28.07.95
G/2407/1999
Dt.28.04.98

<!-- page 73 -->

635

1569

Vaidya Anjana
Kishorkumar

Gen

20.05.17

Ahmadabad
City

Ramanlal D
Sadhira

636

1571

Vaghela
Bhanuprasad
Ganabhai

SC

13.06.17

Ahmadabad
City

Ganabhai D
Vaghela

637

1576

Anilkumar
Keshavbhai
Parmar

SC

05.10.17

Surat City

Keshavbhai
Parshotambhai
Parmar

638

1577

Suhagini
Maheshbhai
Rana

OBC

05.12.17

Ahmadabad
City

Maheshbhai R
Rana

639

1579

Mistry Kamlesh
Jhinabhai

OBC

02.06.18

Ahmadabad
City

Jhinabhai
Morarbhai
Mistry

640

1582

Pragneshkumar
Ranchhodbhai
Patel

Gen

18.05.17

Ahmadabad
City

Ranchhodbhai
M Patel

641

1586

Pankaj Shantilal
Lotwala

OBC

05.11.17

Surat City

Shantilal
Iswarlal Lotwala

642

1588

Bhati Ramila
Dudaram

Gen

29.05.17

Ahmadabad
City

Bavar
Bheraram

643

1589

Nihit Ashvinbhai
Joshi

Gen

20.05.17

Ahmadabad
City

Ashvinbhai
Manaharlal
Joshi

75 Rajeshwari Colony Nr
Isanpur Canel Road
Maninagar
Ahmedabad,Ahmadabad,G
ujarat
5/3 Prema Uka Ni Chali
Opp Keka Shashtri Gov
College Khokhra Maninagar
Ahmedabad,Ahmadabad,G
ujarat
C.6. Dharmaraj Apartment.
Dindayal Society. Nr.
Kishan Dairy. Palanpur
Patiya. Surat.,Surat,Gujarat
9 Jivraj Appartment B/H
Savita Park Opp Lotus
School Govindwadi Isanpur
Ahmedabad,Ahmadabad,G
ujarat
B.78 Mahavir Society
Behind Navnirman School
Ranip,Ahmadabad,Gujarat
B/15 Pankaja Bunglows
Opp Mahalaxmi Intercity
Kathwada Road
Naroda,Ahmadabad,Gujarat
B.No.54.55 Dindayal
Society Palanput Patia
Rander Road,Surat,Gujarat
L/307 Shrinand Nagar .3
Vejalpur,Ahmadabad,Gujar
at
118/2816 Gujarat Housing
Board Nr Netaji Nagar
Meghaninagar,Ahmadabad,
Gujarat

G/3479/1999
Dt.22.08.98

G/3083/2006
Dt.28.12.06

G/2292/2002
Dt.23.09.02

G/2641/2001
Dt.07.10.01

G/740/2002
Dt.14.08.02
G/3712/1999
Dt.22.08.98
G/1706/2009
Dt.23.09.09
G/899/2009
Dt.11.07.09
G/636/2002
Dt.20.04.02

<!-- page 74 -->

644

1597

Bharatkumar
Pravinchandra
Pittalia

OBC

16.05.17

Ahmadabad
City

645

1600

Sanjaykumar
Mohanbhai
Parekh

OBC

15.05.17

Vadodara

646

1601

Divyesh
Rameshchandra
Acharya

Gen

16.05.17

Vadodara

647

1604

Atul Dinkarbhai
Patel

Gen

24.05.17

Ahmadabad
City

648

1606

Parmar
Jasavantbhai
Parmabhai

SC

29.05.17

Ahmadabad
City

649

1613

Dangar
Ashokbhai
Mayabhai

SC

31.05.17

Rajkot

650

1618

Kalpana Satish
Panchal

Gen

25.05.17

Ahmadabad
City

651

1620

Mand Ketan
Vajsurbhai

OBC

20.05.17

Rajkot

Pravinchandra

O.10 Vardhaman Nagar
Flats Near C P Nagar
Bhuyangdev Cross Road
Sola Road
Ghatlodia,Ahmadabad,Guja
rat

MOHANBHAI
At.Po Kurali Ta.Karjan
SANTILAL
,Vadodara,Gujarat
PAREKH
RAMESHCHAN
1181 Laxmikunj Society
DRA
New I.P.C.L. Road Gorwa
GORDHANDAS
Vadodara,Vadodara,Gujarat
ACHARYA
199 Mahasukh Nagar Nr
Dinkar Hari
Nobal School Krishna
Patel
Nagar,Ahmadabad,Gujarat
8 Dwarkapuri Society Nr
Parmar
Bagefirdos Police Line .2
Parmabhai
Jogeshwari Road
Khushalbhai
Amraiwadi,Ahmadabad,Guj
arat
Dudhh Nagar Socity
MAYABHAI
Goghavadar Road
DUDABHAI
Dudheswar Krupa
DANGAR
Gondal,Rajkot,Gujarat
B/5 Jay Avaneu Behind
Rasiklal
Avani Park Near
Mansukhlal
Vishwamitri Bus Stop
Shah
Jivarajpark,Ahmadabad,Guj
arat
Jay Rameshwar Royal
VAJURBHAI
Avenue Silver Stone Main
DEVAYATBHAI
Road Nr Marvadi Building
MAND
Rajkot,Rajkot,Gujarat

G/903/2001
Dt.21.06.01

G/1651/2006
Dt.09.07.06
G/1678/2001
Dt.18.09.01
G/2552/2001
Dt.07.10.01

G/1173/2007
Dt.30.07.07

G/2069/2002
Dt.11.09.02

G/55/1993
Dt.05.02.93

G/1702/2002
Dt.14.08.02

<!-- page 75 -->

652

1621

Madhavi Rajesh
Mohanbhai

OBC

30.05.17

Wankaner

Mohanbhai

653

1622

Sagarbhai
Maljibhai Desai

OBC

21.05.17

Ahmadabad
City

Maljibhai
Jitabhai Desai

654

1624

Barai Shailesh
Laxmidas

Gen

22.05.17

Jamjodhpur

Barai Laxmidas
Karshandas

655

1625

Hitesh
Hasmukhbhai
Patel

Gen

08.04.17

Ahmadabad
City

Hasmukhbhai
Laxmanbhai
Patel

656

1626

Laxmiben
Maganbhai
Makwana

SC

06.06.17

Ahmadabad
City

Maganbhai
Savabhai
Makwana

657

1627

Geeta Ramanlal
Patel

Gen

22.05.17

Surat City

Ramanlal
Dahyabhai
Patel

658

1628

Mehul Rajanikant
Dave

Gen

06.10.17

Vapi

Rajanikant
Pranlal Dave

659

1629

Fulsingh H.
Purohit

Gen

06.10.17

Vapi

Hansraj G.
Purohit

660

1630

Martand
Shambhuprasad
Thaker

Gen

29.05.17

Palanpur

Shambhuprasa
d

Luhar Street Main Bajar
Wankaner,Morbi,Gujarat
103 Girjasut(Giriraj Society)
Vagheshwari Society Road
Chandlodiya,Ahmadabad,G
ujarat
Opp Gayatri Temple Umiya
Nagar Shiv Shakti
Jamjodhpur,Jamnagar,Guja
rat
D.303 Madhav Recidency
Viratnagar
Odhav,Ahmadabad,Gujarat
52 Chamunda Colony
Jogeshwari Road Bage
Firdosh
Amraiwadi,Ahmadabad,Guj
arat
21. Ayodhya Nagari
Society. Honey Park Road.
Op. Patel Pragati Mandal
Vadi. Adajan.
Surat.,Surat,Gujarat
A1 207 Chamunda Dream
City Koparli Road Nr. St
X'viers School Chharwada
Tal.Vapi,Valsad,Gujarat
M.20 City Centre Bazar
Road Vapi Vapi
Town,Valsad,Gujarat
Brahmanvas Delhi Gate
Opp. Lal Dawakhana
Palanpur,Banas
Kantha,Gujarat

G/1181/2008
Dt.26.07.08
G/1180/1995
Dt.11.10.95

G/2199/2004
Dt.26.09.04
G/2589/2001
Dt.20.03.01

G/2513/2006
Dt.17.05.06

G/3050/2000
Dt.25.11.2000

G/2348/2004
Dt.26.09.04
G/209/2002
Dt.03.01.02
G/1416/2001
Dt.07.08.01

<!-- page 76 -->

661

1631

Kaminibahen
Champakbhai
Patel

OBC

06.02.17

Kamrej

Champakbhai
Chimanbhai
Patel

662

1635

Patel Kalpesh
Ambalal

Gen

22.05.17

Himatnagar

Patel Ambalal
Khetabhai

663

1637

Vimal
Bhupendrabhai
Panwala

OBC

24.05.17

Surat City

Bhupendrabhai
Harilal Panwala

664

1640

Gen

23.05.17

Surat City

665

1641

SC

23.05.17

Kankrej

666

1647

Dineshbhai
Harjibhai Gohel

OBC

14.06.17

Ahmadabad
City

Harjibhai
Karamsibhai
Gohel

667

1651

Jayshree
Somabhai Thakor

OBC

06.05.17

Ahmadabad
City

Somabhai
Shivabhai
Thakor

668

1654

Doshi Amitkumar
Nanalal

Gen

06.08.17

Limbdi

Nanalal

669

1656

Rajeshkumar
Umeshbhai
Baraiya

SC

26.05.17

Surat City

Umeshbhai
Nathubhai
Baraiya

1659

Kapilkumar
Vishnuprakash
Upadhyay

Rajkot

Vishnuprakash
Vanmalidas
Upashyay

670

Geetaben
Ghanshyambhai
Borada
Vaghela
Gangaram
Ukabhai

Gen

26.05.17

Popatbhai
Dharamshibhai
Mangukiya
Vaghela
Ukabhai
Methabhai

At Post Kamrej Gam
,Surat,Gujarat
6/19 Navanagar
Himatnagar,Sabar
Kantha,Gujarat
5. Jayant Park Society.2.
Opp. Kailashnagar Society.
Sagrampura.
Surat.,Surat,Gujarat
A.96. Sarita Sagar Society.
Chikuvadi. Nana Varachha
Road. Surat.,Surat,Gujarat
At.Tana Po.Thara
Ta.Kankrej,Banas
Kantha,Gujarat
B.18 Tejendra Vihar Society
Part.2 Post. T.B Nagar
Viratnagar Road
Nikol,Ahmadabad,Gujarat
1344/1 O/S Of Delhi Gate
Shahibaug
Road,Ahmadabad,Gujarat
Pranlal Magan No Dehlo
B/H Vegetibla Market At.
Limbdi,Surendranagar,Guja
rat
132. Ranchhod Park
Society. B.H. Prakash
Bakery. Ramnagar. Rander.
Surat,Surat,Gujarat
Jadeshwar Road Opp Pwd
Office Shree Ghanshyam
Wankaner,Morbi,Gujarat

G/1931/2009
Dt.01.10.09
G/2918/2004
Dt.26.12.04
G/681/2010
Dt.08.05.10
G/2165/2009
Dt.03.12.09
G/166/1996
Dt.08.03.96
G/2273/1999
Dt.28.04.98
G/1871/2001
Dt.18.09.01
G/963/1998
Dt.09.10.98

G/1315/1999
Dt.21.03.99
G/995/2006
Dt.21.06.06

<!-- page 77 -->

671

1660

Kirtibahen
Shantilal
Chhowala

Gen

26.05.17

Surat City

Shantilal
Balubhai
Chhowala

672

1661

Niraj Girdharlal
Solanki

OBC

12.11.17

Rajkot

Giridharlal
Solanki

673

1663

Sanjaykumar
Nathuram
Ramanuj

OBC

22.06.17

Jasdan

Nathurambhai
Bhimdas
Ramanuj

674

1666

Dabhi Rakshbhai
Gopalbhai

OBC

24.06.17

Limbdi

Gopalbhai

675

1668

Yadav
Jaspalsingh
Keshrisingh

Gen

28.05.17

Valia

Yadav
Keshrisingh
Mojisingh

676

1673

Himatbhai
Babubhai Gajera

Gen

29.05.17

Surat City

Babubhai
Jethabhai
Gajera

677

1674

Rahevar
Jankiben
Dhanesinh

Gen

30.05.17

Himatnagar

Rahevar
Dhanesinh
Kodarsinh

678

1680

Patel Gaurang
Natvarbhai

Gen

06.03.17

Ahmadabad
City

Natvarbhai
Raijibhai Patel

679

1681

Patel Atulkumar
Natvarbhai

Gen

06.09.17

Ahmadabad
City

Natvarbhai
Raijibhai

680

1682

Arun Lalchand
Lahoti

Gen

30.05.17

Surat City

Lalchand
Mohanlal Lahoti

A.7.48. Gotalawadi
Muncipal Ternament.
Gotalawadi. Katargam.
Surat.,Surat,Gujarat
5 Ghb Colony Block No L5
Opp Mvm Collage Kalawad
Road Rajkot,Rajkot,Gujarat
To.Vinchhiya Near Ramji
Mandir
Dist.Rajkot,Rajkot,Gujarat
Matam Chowk Bahela Para
At.
Limbdi,Surendranagar,Guja
rat
Gayatri Nagar At Post
Netrang Ta
Netrang,Bharuch,Gujarat
C.504 Sanskrut Residency
Nr Swastik Tower .
Sarthana Jakatnaka
Varachha Road .
Surat,Surat,Gujarat
Mahavirkhadki Zuna Bazar
Himatnagar
Dist.Sabakantha,Sabar
Kantha,Gujarat
C.40 Payal Nagar Society
Nr Khodiya Mandir
Naroda,Ahmadabad,Gujarat
G.501 Paras Galaxy Nr
Haridarshan Chowkdi Nava
Naroda,Ahmadabad,Gujarat
F.12.A. Poddar Residency.
Cenal Road. Vesu.
Surat.,Surat,Gujarat

G/3171/2000
Dt.25.11.2000
G/2033/2002
Dt.11.09.02
G/950/2009
Dt.11.07.09
G/393/2004
Dt.27.03.04
G/202/2003
Dt.25.01.03

G/121/2002
Dt.03.01.02

G/228/2008
Dt.14.03.08
G/1495/1999
Dt.21.03.99
G/1138/2001
Dt.21.06.01
G/147/2003
Dt.11.01.03

<!-- page 78 -->

681

1685

Manubhai
Chandulal Modi

Gen

13.06.17

Ahmadabad
City

Chandulal Modi

682

1686

Nishaben
Jayendrakumar
Patel

Gen

31.05.17

Vadodara

Vasantbhai
Patel

683

1691

Sharma Shefali
Chiragkumar

OBC

24.06.17

Ahmadabad
City

Dineshkumar
Bhatia

684

1693

Indubha
Jashubha Jadeja

Gen

20.06.17

Wankaner

Jashubha
Jadeja

685

1695

Urvashi
Baldevbhai
Bharthi

OBC

06.12.17

Rajkot

Baldevbharthi
Shankarbharthi
Goswami

686

1697

Ketanbhai
Bhikhubhai
Vasoya

Gen

06.07.17

Ahmadabad
City

Bhikhubhai
Virjibhai Vasoya

687

1699

Dilipkumar
Hirjibhai Dodia

OBC

06.08.17

Ahmadabad
City

Hirjibhai
Valjibhai Dodia

688

1709

Rathod
Piyushkumar

SC

15.06.17

Patan

Manharlal

689

1710

Dipak Devshibhai
Donga

Gen

06.09.17

Surat City

Devshibhai
Ukabhai Donga

17 Vrundavan Bunglows Nr
Medilink Hospital Shyamal
Shivranjani Ring Road
Setellite
Ahmedabad,Ahmadabad,G
ujarat
At Po Dharamapuri Taluka
Dabhoi District
Vadodara,Vadodara,Gujarat
C 25 Ambica Nagar Society
Nr Water Tank Odhav
Ahmedabad,Ahmadabad,G
ujarat
Digvijay Nagar Pedak
Wankaner,Morbi,Gujarat
Meera' Amruta Society
Block No. 38.A Street No. 5
Behind Amruteshwar
Temple,Rajkot,Gujarat
D.14 Radhika Banglows
Opp Sukan Banglows Nikol
Naroda Road New
Nikol,Ahmadabad,Gujarat
B/102 Gokul Appartment
Badapark Society Opp
Gardan Mirambica School
Road Ankur
Naranpura,Ahmadabad,Guj
arat
3/2/95/2 Motisara Aghara
Darvaja Road
Patan,Patan,Gujarat
73. Vrundavan Society.
Near Dabholi Char Rasta.
Ved Road. Surat
,Surat,Gujarat

G/66/1975
Dt.04.03.75

G/904/1995
Dt.28.07.95
G/711/2009
Dt.27.06.09
G/356/2007
Dt.11.05.07
G/97/2002
Dt.03.01.02

G/556/2006
Dt.18.03.06

G/646/1995
Dt.29.06.95

G/134/1999
Dt.13.02.98
G/528/2004
Dt.27.03.04

<!-- page 79 -->

690

1712

Rakesh Kiritbhai
Badheka

Gen

06.10.17

Songadh

Kiritbhai

691

1713

Sangitabala
Nanjibhai Khatra

Gen

06.09.17

Surat City

Nanjibhai
Dhanjibhai
Khatra

692

1715

Parmar Vijay
Laxmanbhai

SC

06.10.17

Jasdan

Laxmanbhai
Mangabhai
Parmar

693

1716

Chauhan
Vidhiben
Dilipkumar

Gen

06.10.17

Vadodara

Dilipkumar
Chauhan

694

1718

Patel
Bharatkumar

Gen

28.06.17

Mahesana

Girishkumar

695

1719

Shah Ketankumar
Kanaiyalal

Gen

09.12.17

Godhra

Kanaiyalal

696

1721

Nayak
Pradipkumar

OBC

29.06.17

Mahesana

Ashokkumar

697

1722

Rathod Nanjibhai
Dudabhai

SC

06.12.17

Jasdan

Dudabhai
Dehabhai
Rathod

BRAHMIN STREET
NAVAGAM
SONGADH,TAPI,GUJARAT
E.B. 301. Priyank
Residency. Near
Dharmanandan Row
House. Sete Light Road.
Mota Varachha.
Surat.,Surat,Gujarat
At Jasdan Buddha Nagar
Society Near Lohiya Nagar
Primary School
Jasdan,Rajkot,Gujarat
46 Venugopal Residency
Sun Pharma Road Atladra
Vadodara,Vadodara,Gujarat
U.64 Kunal Residency Opp
Sahara Township
Radhanpur Road
Mahesana,MAHESANA,GU
JARAT
3 Shanti Nagar B H
Navapura Kalol,Panch
Mahals,Gujarat
29 A Bhimnath Row House
Soceity Near Para Ambaji
Temple
Mahesna,MAHESANA,GUJ
ARAT
At Jasdan Satderi Lati Plot
Jasdan At Jasdan Ta
Jasdan,Rajkot,Gujarat

G/2284/2003
Dt.15.10.03

G/2774/2003
Dt.30.12.03

G/87/2004
Dt.25.11.04
G/1025/2009
Dt.11.07.09

G/1606/2000
Dt.22.07.2000

G/1695/2004
Dt.14.08.04

G/413/2003
Dt.22.02.03

G/646/1991
Dt.08.09..91

<!-- page 80 -->

698

1727

Vania
Pravinchandra

SC

16.06.17

Bhuj

Vania
Varjangbhai

699

1728

Jani Manjulaben
Dayashankar

Gen

20.06.17

Amreli

Dayashankar

700

1729

Oza Daxaben
Babulal

OBC

18.09.17

Ahmadabad
City

Babulal R Oza

701

1730

Bhatt
Chandravadan
Devshankarbhai

Gen

20.06.17

Dhari

Devshankarbha
i

702

1732

Modi Manisha
Pravinchandra

OBC

16.06.17

Ahmadabad
City

Pravinchandra
Modi

703

1734

Jesungbhai
Dosjibhai Patel

Gen

28.06.17

Palanpur

Dosjibhai

704

1736

Laxmanbhai
Fulajibhai Patani

OBC

07.06.17

Ahmadabad
City

Fulajibhai
Patani

705

1738

Kanubhai
Chaudhari

OBC

23.06.17

Visnagar

Jethabhai

1739

Dashrathbhai
Parsottambhai
Paneria

Surat City

Parsottambhai
Govindbhai
Paneria

706

SC

16.06.17

Plot No 50 Arihant Nagar
Near Garbi Chowk
Bhuj,Kachchh,Gujarat
Om Nagar Sahayog Sheri
Block No 247 Chital
Road,Amreli,Gujarat
A.59 Hariom Nagar Nr
Cadila Bridge Ghodasar
Ahmedabad,Ahmadabad,G
ujarat
At Dhari Ajanta Society
Behind Petrol
Pump,Amreli,Gujarat
B/2/24 Nirman Complex R
C Technical Road
Ghatlodiya,Ahmadabad,Guj
arat
Morvas At Post.Vedancha
Ta. Palanpur
Banaskantha,Banas
Kantha,Gujarat
9 Jugde Saheb Ni Chali
Wakhapura Opp Potaliya
Talav Saraspur
Ahmedabad,Ahmadabad,G
ujarat
AT Gunja Ta Visnagar Dist
Mahesana
,MAHESANA,GUJARAT
61. Ashirwad. Maneeba
Park Society.
Chhaparabhatha Road.
Amroli. Surat.,Surat,Gujarat

G/684/1996
Dt.30.03.96
G/2643/1999
Dt.04.07.98
G/933/2006
Dt.21.06.06
G/620/1999
Dt.21.03.99
G/797/2003
Dt.22.06.03

G/1382/1999
Dt.21.03.99

G/154/1987
Dt.09.03.87

G/1089/2002
Dt.13.08.02
G/709/1993
Dt.14.09.93
