---
doc_id: "0ddc7ae1d1ae1b4f"
source_url: "https://www.darpg.gov.in/static/uploads/2026/02/e1ae3f280c1b00c6cae1a76f80bf1e22.pdf"
ministry: "Department of Administrative Reforms and Public Grievances (DARPG)"
title: "5.0"
date: "2025-11-07"
pages: 76
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2792b997c3a897b0"
---

<!-- page 1 -->

SPECIAL

CAMPAIGN 5.0
2nd OCT - 31st OCT 2025
ASSESSMENT REPORT

<!-- page 2 -->

TWEET BY PMO ON SPECIAL CAMPAIGN 5.0

Shri Narendra Modi
Hon'ble Prime Minister of India

<!-- page 3 -->

TABLE OF CONTENTS

Launch of Special Campaign 5.0

1

Special Campaign 1.0 -5.0 Cumulative Outcomes (2021-2025)

2

Special Campaign Achievements: Top Performers
•
•
•

Revenue Earned
Cleanliness Campaign Sites
Space Freed

Key Highlights of Special Campaign 5.0
•
•
•
•

Revenue Earned
Cleanliness Sites
Space Freed
Files Closed/Weeded Out

3
4
5
6
7
8
9

Geographical Extent

10

Best Practices

11

Before After

48

Glimpses of Special Campaign 5.0
•
•
•

Leadership by Hon'ble Ministers
Field Ofﬁces
Campaign in Overseas Ofﬁces

Media Coverage & Outreach
•
•
•
•
•
•

Media Outreach
Twitter Mentions by Hon'ble MoS (PP)
Media Coverage
Print Media Coverage
PIB Statements
PIB Statements by DARPG

55
61
63
66
67
68
69
71
72

<!-- page 4 -->

LAUNCH OF SPECIAL CAMPAIGN 5.0
MoS, M/o Personnel, Public Grievances and Pensions, Dr. Jitendra Singh launched the Preparatory
(15-30 September) and Implementation Phase (2-31 October) of the Special Campaign 5.0

1

<!-- page 5 -->

SPECIAL CAMPAIGN 1.0 -5.0 CUMULATIVE OUTCOMES (2021-2025)

Cleanliness
Campaign
Sites

23.65
Lakh

Revenue
Earned

Rs. 4,130.63
CR

Space
Freed

930.02
Lakh sq. ft.

Files Closed/
Weeded Out

167.38
Lakh

(Rs. in Crore)

2,364.05

833.92

4,130.63

643.82
Files Closed/
Weeded Out (In Lakh)

131.40

2
1

<!-- page 6 -->

SPECIAL CAMPAIGN ACHIEVEMENTS : TOP PERFORMERS
Revenue Earned (Rs. in Crore)
Special Campaign 5.0
Total Revenue Earned by Scrap Disposal : Rs. 833.92 Cr
6.89 6.83
34.24

9.88

6.50

Special Campaign 1.0-5.0
Total Revenue Earned from Scrap Disposal : Rs. 4130.63 Cr

4.39 40.84

38.00

126.21

56.86

33.53
87.15 54.08
100.76
116.67

27.59

207.65

364.13

59.45

2453.28
570.05

MoR

MoD

Coal

MoPNG

MoP

DHE

DoT

DoF

MoS

Others

MHI

559.58

MoR

MoD

Coal

MHI

Power

MoPSW

MoM

DAE

MHA

Others

MoPNG

3

<!-- page 7 -->

SPECIAL
CAMPAIGN ACHIEVEMENTS : TOP PERFORMERS
SC
1.0-5.0
Cleanliness Campaign Sites (Nos. in Lakhs)
Special Campaign 1.0 -5.0
Total Cleanliness Campaign Sites: 23.65 Lakh

Special Campaign 5.0
Total Cleanliness Campaign Sites: 11.59 Lakh

0.41

0.15

0.12

0.11

0.08 0.08
0.39

1.13

0.84

1.30

0.57

0.39 0.28
0.45
0.49

1.64
9.41

2.16

6.16
1.96

2.52
4.6
DoSEL

Posts

MoWCD

Railways

DFS

MHA

MORTH

DoPH

MoSDE

Others

MoD

1
4

<!-- page 8 -->

SPECIAL
CAMPAIGN ACHIEVEMENTS : TOP PERFORMERS
SC
1.0-5.0
Space Freed (In Lakh Sq. Ft)
Special Campaign 5.0
Total Space Freed: 233.75 Lakh Sq. Ft.

6.06

2.36
3.03
3.90

2.16 2.11

Special Campaign 1.0-5.0
Total Space Freed: 930.02 Lakh Sq. Ft.
12.51

21.56
112.89

132.73

12.46

13.62
16.03

373.14

21.37

14.45

58.7
70.17

20.82

81.43

44.41

137.86

Coal

MHI

MoD

DHE

Railways

MoPNG

DARE

DFS

DST

Others

Sports

Coal

MHI

DFS

MoD

Railways

MoM

MIB

DSIR

DoSEL

Others

DHE

1
5

<!-- page 9 -->

KEY HIGHLIGHTS OF SPECIAL CAMPAIGN 5.0
Revenue Earned (Rs in Crore)
Rs. 833.92 Crore Revenue Earned – About 1.28 times more than Special Campaign 4.0

900

Rs. 570.05
Cr.

Rs. 58.70
Cr.

MoR

Rs. 56.86
Cr.

MoD

Coal

833.92

800
700

650.1

600

556.35

500
372

400
300

Rs. 38
Cr.

MoPNG

Rs. 34.24
Cr.

MoP

200
100
0

82.54
SC 1.0

SC 2.0

SC 3.0

SC 4.0

SC 5.0

6

<!-- page 10 -->

KEY HIGHLIGHTS OF SPECIAL CAMPAIGN 5.0
Cleanliness Sites (In Nos)
11,59,783 Campaign Sites – Almost double the cleanliness coverage of Special Campaign 4.0

6,16,141
DoSEL

1,95,620
MoWCD

11,59,783

1,30,000
Posts
5,97,276

2,58,673

84,184
MoR

41,041
DFS

6,154
SC 1.0

1,01,582
SC 2.0

SC 3.0

SC 4.0

SC 5.0

7

<!-- page 11 -->

KEY HIGHLIGHTS OF SPECIAL CAMPAIGN 5.0
Space Freed (In Lakh sq. ft)
233.75 lakh sq. ft. of Space Freed – About 1.23 times larger than Special Campaign 4.0

112.89
Coal

20.82
MoD

44.41
MHI

250

233.75

200

189.75
164

150
100

14.45
DHE

6.06
MoR

90

50
12
0

SC 1.0

SC 2.0

SC 3.0

SC 4.0

SC 5.0

8

<!-- page 12 -->

KEY HIGHLIGHTS OF SPECIAL CAMPAIGN 5.0
Files Closed/Weeded Out
Total Files Closed/Weeded Out: 29,51,689

9,85,729

2,39,439

1,81,378

1,73,381

1,73,111

1,29,445

1,28,527

90,629

80,064

60,527

Files closed/Weeded Out: Top 10 Ministries/Departments
Ministry of Heavy Industry
Ministry of External Aﬀairs
Ministry of Coal
Department of Legal Aﬀairs

Central Board of Direct Taxes (Income Tax)
Department of Personnel and Training
Department of Higher Educa on

Ministry of Home Aﬀairs
Department of Food and Public Distribu on
Ministry of Labour and Employment

9

<!-- page 13 -->

GEOGRAPHICAL EXTENT
All States/UTs/Overseas Missions/Posts

Srinagar

Geographical Extent

Gundla

Kullu
Goindwal
Jagadhri
Nainital
Pipli
Bikaner
Lucknow

Jaipur

Varanasi
Singrauli

Gandhinagar

Budhni

Bharuch

Pune
Chicalim

1.

Uslapur

Nagpur
Karimnagar

Vijaypura

Nalanda

Ziro
Tezpur
Mokochang

Gangtok

Shillong

Imphal
Jiribam
Agartala
Bishnupur Aizawl

Chaibasa Barrackpore
Sambhalpur

Waltair

Chengalpattu
Ulaganthan village
Thanjavur

2. CAPF Forces - Jiribam and Agartala
3. Post Ofﬁces - Mokokchung and Barrackpore
4. Mines - Bharuch
5. FCI Divisional Ofﬁces - Ziro and Kannur
6. Toll Plazas - Bikaner
7. Income Tax Ofﬁce - Gangtok
8. BHEL - Goindwal
9. MoEFCC Insititute - Kullu

Ponda

Kannur

Railway Stations - Uslapur

Port Blair

Kanniyakumari

10

<!-- page 14 -->

BEST PRACTICES
1

PRESERVATION OF RECORDS

7

E-WASTE MANAGEMENT

2

RECORDS WEEDED OUT

8

INCLUSIVITY

3

CLEANLINESS PRACTICES

9

SCRAP DISPOSAL

4

ENHANCEMENT OF OFFICE SPACE

10

CITIZEN CENTRIC PRACTICES

5

EFFICIENT MANAGEMENT OF SPACE

11

DIGITISATION

6

ENVIRONMENT FRIENDLY ACTIVITIES

12

WASTE TO WEALTH

11

<!-- page 15 -->

PRESERVATION OF RECORDS

Preservation and Conservation of Historic Lithographs at
The Asiatic Society, Kolkata; Ministry of Culture
12

<!-- page 16 -->

PRESERVATION OF RECORDS

Exhibition on historical value records
Inaugurated by Hon’ble Culture Minister
Sh. Gajendra Singh Shekhawat; National
Archives of India

Legislative records (1912–2000) transferred
to the National Archives of India; Legislative
Department

13

<!-- page 17 -->

RECORDS WEEDED OUT

Old records reviewed and
weeded for shredding;
Department of Health &
Family Welfare

Review of physical records in
Departmental record room;
Legislative Department

14

<!-- page 18 -->

RECORDS WEEDED OUT

Weeding out of old physical records at the Pr.CCIT Ofﬁce, Kochi, Kerala;
Central Board of Direct Taxes (Income Tax)

15

<!-- page 19 -->

CLEANLINESS PRACTICES

Cleanliness Drive by INS Dwarka and INS Shivaji; Department of Military Affairs

16

<!-- page 20 -->

CLEANLINESS PRACTICES

Extensive cleanliness drives at border locations, government campuses, and
metro facilities, carried out by SSB, ITBP,BSF, CRPF, Delhi Police, CISF units and
Assam Riﬂes ; Ministry of Home Affairs
17

<!-- page 21 -->

CLEANLINESS PRACTICES

Cleanliness activities at the Kanyakumari,
Thirumukkudal; Ministry of Earth Sciences

Drone-powered cleaning of Amrit Bharat
Express, an innovation driven best practice;
Ministry of Railways

18

<!-- page 22 -->

ENHANCEMENT OF OFFICE SPACE
BEFORE

AFTER

Artistic wall painting at Puducherry Head
Post Ofﬁce; Department of Posts

Renovation and modernisation of
Barrackpore sub-post ofﬁce enhancing
infrastructure and functionality;
Department of Posts
19

<!-- page 23 -->

ENHANCEMENT OF OFFICE SPACE
State- Gujarat
Salangpur Primary School,
Barvala Botad

State- Maharashtra
Jilha Parishad Shala, Pimpri, Thane

State- Andhra Pradesh
PM SHRI Kendriya Vidyalaya,
Anantapur

BEFORE

BEFORE

BEFORE

AFTER

AFTER

AFTER

Schools across the Nation rejuvenated through whitewashing, repainting and
essential minor repairs to create cleaner learning environment; Department of
School Education and Literacy
20

<!-- page 24 -->

ENHANCEMENT OF OFFICE SPACE
State- Assam : PM SHRI CNS HSS SONITPUR

State- Rajasthan : PM SHRI JNV Suratgarh

BEFORE

BEFORE

AFTER

AFTER

Schools across the Nation rejuvenated through whitewashing, repainting and
essential minor repairs to create cleaner learning environment; Department of
School Education and Literacy

21

<!-- page 25 -->

ENHANCEMENT OF OFFICE SPACE

Vibrant wall art at Shastri Bhawan on themes like Waste to Wealth and Recycling, promoting
sustainability and creativity; Legislative Department

22

<!-- page 26 -->

EFFICIENT MANAGEMENT OF SPACE

BEFORE

AFTER

A cluttered 500 sq.ft. area transformed into a modern, fully
equipped ofﬁce space; Department of Biotechnology

23

<!-- page 27 -->

EFFICIENT MANAGEMENT OF SPACE
BEFORE

AFTER

Old Light & Sound Show control room
transformed into a Museum Souvenir
Shop at Victoria Memorial, Kolkata;
Ministry of Culture

Terrace area of the ITO Kerala Residential
Complex transformed into a Fitness
Studio; Central Board of Direct Taxes

24

<!-- page 28 -->

ENVIRONMENT FRIENDLY ACTIVITIES

Tree plantation by Hon'ble Minister of State (PP) Dr. Jitendra Singh;
Department of Administrative Reforms and Public Grievances
25

<!-- page 29 -->

ENVIRONMENT FRIENDLY ACTIVITIES

Pathogenic Biomedical Waste
converted into Value-added Soil
Additives CSIR-NIIST at
Thiruvananthapuram; Department of
Scientiﬁc and Industrial Research

Tree Plantation drive Midnapore;
Department of Financial Services

26

<!-- page 30 -->

E-WASTE MANAGEMENT

A nationwide E-waste recycling initiative
at Shastri Bhawan, New Delhi; Ministry
of Mines

E-Waste Collection Campaign
organised at AIIMS Guwahati; Ministry of
Health and Family Welfare

27
12

<!-- page 31 -->

E-WASTE MANAGEMENT

An E-Waste Disposal Drive conducted by
HPCL MLIF; Ministry of Petroleum and
Natural Gas

An E-Waste Disposal Drive conducted at Sardar
Patel Bhawan; Department of Administrative
Reforms & Public Grievances

28

<!-- page 32 -->

E-WASTE MANAGEMENT

E-waste disposal activities by NCSM to
promote sustainable waste management
practices; Ministry of Culture

E-Waste Management Awareness Webinar
conducted; Department of School Education &
Literacy

29

<!-- page 33 -->

E-WASTE MANAGEMENT

E-Waste Collection Kiosk by
Western Coalﬁelds Limited;
Ministry of Coal

E-waste disposal drive at
Neyveli Lignite Corporation
India Limited; Ministry of Coal

E-waste disposal drive at
Faridabad; Central Board of
Indirect Taxes and Customs

30

<!-- page 34 -->

EFFICIENT MANAGEMENT OF SPACE
INCLUSIVITY

Felicitation of Safai Mitras;
Ministry of Statistics and
Programme Implementation

Health Check-up Camp for
Safai Mitras organised by FTII;
Ministry of Information and
Broadcasting

Felicitation of Safai Mitras;
Department of
Administrative Reforms &
Public Grievances

31

<!-- page 35 -->

INCLUSIVITY

Pink Dispensary operated entirely by women
employees at Patansaongi, Nagpur Area by
Western Coalﬁelds Limited; Ministry of Coal

Coal India’s ﬁrst fully women-operated Central
Store Unit at Korba Chhattisgarh by South
Eastern Coalﬁelds Limited; Ministry of Coal

Awareness programme for Safai Mitras;
Ministry of Mines
32

<!-- page 36 -->

SCRAP DISPOSAL

Scrap disposal by Western
Coalﬁelds Limited;
Ministry of Coal

Scrap Disposal by Northern
Coalﬁelds Limited;
Ministry of Coal

Grounded vehicles at Shastri
Bhawan E-auctioned;
Department of Higher Education

33

<!-- page 37 -->

CITIZEN CENTRIC PRACTICES
Amrit Samvaad a citizen-centric initiative of the Ministry of Railways, provided a direct platform
for dialogue between railway authorities and passengers. Organised at Amrit and other major
stations, it highlighted key improvements under the Amrit Bharat Station Scheme
4
3
14
1

21

Jammu &
Kashmir

Punjab
Haryana

10
4
Uttrakhand
Delhi

Rajasthan

30

Gujarat

35

Maharastra

189

121

Uttar
Pradesh

Madhya Pradesh

10

51

West Tripura
Bengal

116

34

Odisha

32

Andhra
Pradesh

1

57

Karnataka
Tamil
Nadu

Assam
Bihar

Jharkhand

Telangana

23

21

109

Puducherry

1

24

Kerala

No. of Amrit Samvaad organised

34

<!-- page 38 -->

CITIZEN CENTRIC PRACTICES
Dak Chaupal a grassroot initiative conducted by the Department of Posts through postal teams, who
engaged with local communities, to address service-related needs at the doorsteps of citizens, covering
the last mile and fostering effective service delivery with community engagement.

37

13

15

Himachal
Punjab

878

Haryana

Gujarat

11
Uttar
Pradesh

Madhya Pradesh

Assam
Bihar

Jharkhand

3

West
Bengal

Chhattisgarh

41
54

Odisha

17

61

51

Delhi

Rajasthan

4504

39

197

9

Karnataka
Tamil
Nadu

66

No. of Dak Chaupal organised
35

<!-- page 39 -->

CITIZEN CENTRIC PRACTICES

A grievances redressal portal launched for
farmers enrolled under PMFBY is a best
practice in grievance redressal; Department
of Agriculture and Farmers Welfare

Contraband worth ₹1,011 Crore including 26
lakh foreign cigarettes, 250 kg NDPS Drugs,
gutkha/pan masala & e-cigarettes destroyed
by Customs Commissionerate; Central Board
of Indirect Taxes and Customs

Cleanliness through the initiative via
Rajmargyatra App rewarding citizens
with ₹1,000 FASTag recharge for spotting
dirty NH toilet at Toll Plazas; Ministry of
Road Transport & Highways

36

<!-- page 40 -->

CITIZEN CENTRIC PRACTICES

Waste to Wealth awareness
material on lung cancer
prepared from tobacco
containers collected in drop
boxes; Ministry of Health and
Family Welfare

Bio-Toilets Installed at
Northen Coalﬁelds Limited
units; Ministry of Coal

Blood donation camp at Rajiv
Gandhi Bhawan, New Delhi;
Ministry of Civil Aviation

37

<!-- page 41 -->

DIGITISATION

QR code-based ﬁle inventory mobile
application “AbhiLekhAbhi” by the Income
Tax Ofﬁce at Hyderabad; Central Board of
Direct Taxes

Roll-out of Facial Attendance
System across Branch Post
Ofﬁces under Kanyakumari,
Madurai, Tuticorin, and Theni
Postal Divisions of the Southern
Region, Tamil Nadu Circle;
Department of Posts

38

<!-- page 42 -->

DIGITISATION

SBI launched the Cyber
Security Booklet to promote
safe digital banking practices
and cyber awareness;
Department of Financial
Services

Special programme on National Cyber
Security Awareness; Ministry of
Electronics & Information Technology

Online quiz on Cyber
Security organised for
employees on the theme
“Cyber Jagrit Bharat”;
Ministry of Women and
Child Development

39

<!-- page 43 -->

DIGITISATION

Workshop on Cyber Swachhata for Central Ministries & Departments organized by
Department of Administrative Reforms & Public Grievances

40

<!-- page 44 -->

WASTE TO WEALTH

“Bodhi Tree” Waste to Art, Varanasi;
Ministry of Railways

Sculptures made of recycled materials as
an initiative “Kabaad Se Jugaad”;
Ministry of Mines

41

<!-- page 45 -->

WASTE TO WEALTH
Waste to Art initiatives by Ministry of Culture

42

<!-- page 46 -->

WASTE TO WEALTH

Scrap and E-Waste materials transformed into 3D models of
drones, tractors & cultivators; Department of Agriculture and
Farmers Welfare

Mother and Baby Doll
model from e-waste;
Ministry of Mines

43

<!-- page 47 -->

WASTE TO WEALTH

S-400 Missile model;
Ministry of Coal

An 11-ft horse crafted from
scrap metal at Yesvantpur
Coaching Depot.; Ministry of
Railways

7-foot-high statue of a
coal miner made of
waste glass installed at
Magadh-Sanghmitra
area; Ministry of Coal

44

<!-- page 48 -->

WASTE TO WEALTH

ANGARA, the company’s mascot,
sculpted entirely from scrap
metal at Western Coalﬁelds
Limited, Nagpur; Ministry of Coal

A Cow statue designed from
scrap material at CCBF,
Sambalpur; Department of
Animal Husbandry & Dairying
45

<!-- page 49 -->

WASTE TO WEALTH

Waste-to-Wealth demo helicopter made
from 100% hospital metal scraps at RIMS,
Imphal; Ministry of Health & Family
Welfare

India’s First Steel Slag Highway on MumbaiGoa (Indapur-Panvel Section of NH-66)
Stretch; Department of Scientiﬁc and
Industrial Research

46

<!-- page 50 -->

WASTE TO WEALTH

Shri Jagannath Temple

Shri Ramanathanswamy Temple

Shri Badrinath Temple

Shri Dwarikanath Temple

Scrap materials transformed into artistic replicas of the Chardham
Temples of India at Mahanadi Coalﬁelds Limited, Odisha; Ministry of Coal
47

<!-- page 51 -->

BEFORE-AFTER

<!-- page 52 -->

Construction of Hydraulic Vehicle Lift at Indira Paryavaran Bhawan,
New Delhi; Ministry of Environment, Forest and Climate Change
49

<!-- page 53 -->

Old records weeded out at New Delhi; Department of Empowerment
of Persons with Disabilities
50

<!-- page 54 -->

Ofﬁce space cleared of scrap at SLUSI Regional Ofﬁce Ahmedabad;
Department of Agriculture, Cooperation and Farmers Welfare
51

<!-- page 55 -->

Transformation of free space into workstation at Translational Health
Science and Technology Institute (THSTI); Department of Biotechnology
52

<!-- page 56 -->

Construction and demolition waste cleared from ofﬁce premises;
Department for Promotion of Industry and Internal Trade
53

<!-- page 57 -->

GLIMPSES OF
SPECIAL CAMPAIGN 5.0

<!-- page 58 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0
Leadership by Hon’ble Ministers

Minister of Youth Affairs & Sports, Dr. Mansukh
Mandaviya inspected the cleanliness and
upkeep of Jawaharlal Nehru Stadium, New Delhi

Minister of Micro, Small & Medium Enterprises,
Shri Jitan Ram Manjhi organised the
Swachhata pledge

MoS for Law & Justice, Shri Arjun Ram Meghwal
reviewed activities on Swachhata and record
management at the Legislative Department

MoS for Information & Broadcasting, Dr. L. Murugan
inspected and reviewed activities on Swachhata
and pendency reduction at Doordarshan Bhawan

55

<!-- page 59 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0
Leadership by Hon’ble Ministers

MoS for Education, Dr. Sukanta Majumdar
participated in Swachhata activities at
IIM Calcutta

MoS for Health & Family Welfare, Shri Prataprao
Jadhav reviewed cleanliness and administrative
efﬁciency measures at Nirman Bhawan, New Delhi

MoS for Home Affairs, Shri Bandi Sanjay Kumar
reviewed the progress of Special Campaign 5.0

MoS for Heavy Industries, Shri Bhupathiraju
Srinivasa Varma conducted a surprise inspection
at the Udyog Bhawan, New Delhi

56

<!-- page 60 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0
Leadership by Hon’ble Ministers

MoS for Minority Affairs, Shri George Kurian
inspected cleanliness activities at the Ministry ofﬁce

MoS for Education, Shri Jayant Chaudhary
felicitated Safai Mitras at PMSHRI Kendriya
Vidyalaya No. 1, Delhi Cantt.

MoS for Railways, Shri V. Somanna reviewed the
progress of Special Campaign 5.0 and inspected
the Yesvantpur Coaching Depot in Bengaluru

Minister of Environment, Forest & Climate
Change, Shri Bhupender Yadav inspected the
record room and ofﬁce areas at Paryavaran
Bhawan, New Delhi

57

<!-- page 61 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0
Leadership by Hon’ble Ministers

Minister of Health & Family Welfare, Shri Jagat
Prakash Nadda reviewed the progress of Special
Campaign 5.0 and inspected cleanliness
measures at Nirman Bhawan, New Delhi

Minister of Communications and DoNER,
Shri Jyotiraditya M. Scindia inspected ofﬁce
premises and reviewed “Clean Ofﬁce, Clear
Governance” activities

Minister of Civil Aviation, Kinjarapu Rammohan
Naidu inaugurated a new Creche Facility
promoting inclusivity at Udan Bhawan

58

<!-- page 62 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0
Leadership by Hon’ble Ministers

5th October 2025

28th October 2025

Group of Ministers reviewed the progress of Special
Campaign 5.0

59

<!-- page 63 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0
Leadership by Hon’ble Ministers

Minister of Agriculture, Shri Shivraj Singh
Chouhan reviewed quality disposal of
public grievances

Minister of DoCA Shri Pralhad Joshi chaired a
review meeting on Special Campaign 5.0

Minister of Food & Public Distribution, Sh. Prahlad
Joshi chaired a review meeting on Special
Campaign 5.0

Union MoS for Communications, Dr. Chandra
Sekhar Pemmasani reviewed cleanliness
initiatives at Sanchar Bhawan

60

<!-- page 64 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0

Field Ofﬁces

FMMTTI, DA&FW, Budhni

MECL CSD, MoM, Hingna

Assam Riﬂes, MHA, Nagaland

CBIC, Dhandhuka

NRFMT&TI, DA&FW, Hisar

NITRD, DHFW, New Delhi
61

<!-- page 65 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0

Field Ofﬁces

IIE, MSDE, Guwahati

Jammu Airport, MoCA

NERIWALM, DoWR&RD, Tezpur

DoPPW, New Delhi

MoPSW, Goa

NCPOR, MoES, Goa
62

<!-- page 66 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0

Campaign in Overseas Ofﬁces

Mombasa

Saudi Arabia

Cape Town

Kuwait

Lithuania

Scotland

Republic of Cyprus

Finland

63

<!-- page 67 -->

GLIMPSES OF SPECIAL CAMPAIGN 5.0

Campaign in Overseas Ofﬁces

Melbourne

Morocco

Bangladesh

Slovakia

Rajshahi

Chile

Djibouti

Morocco

64

<!-- page 68 -->

MEDIA COVERAGE
& OUTREACH

<!-- page 69 -->

MEDIA OUTREACH

No. of Tweets Issued: 18,105
7,500 Infographics

1 Panel Discussion on DD News

No. of PIB released: 313

1 Panel Discussions on Sansad TV

3245 Tweets from DARPG

13 Panel Discussions at IIPA Studio

Widespread Print Media Coverage

1 Spotlight on AIR

Men ons
16.5K

Interac ons
343K

Reach
~100M

Engagement Rate

10.5%
66

<!-- page 70 -->

TWITTER (NOW X) MENTIONS BY HON'BLE MoS (PP)

67

<!-- page 71 -->

MEDIA COVERAGE

Spotlight on AIR

Panel Discussion on DD News

Panel Discussion on Sansad TV
68

<!-- page 72 -->

PRINT MEDIA COVERAGE

69

<!-- page 73 -->

PRINT MEDIA COVERAGE

70

<!-- page 74 -->

PIB STATEMENTS

71

<!-- page 75 -->

PIB STATEMENTS by DARPG

72

<!-- page 76 -->

DEPARTMENT OF ADMINISTRATIVE REFORMS AND PUBLIC GRIEVANCES
GOVERNMENT OF INDIA
5TH FLOOR SARDAR PATEL BHAWAN SANSAD MARG NEW DELHI-110001
