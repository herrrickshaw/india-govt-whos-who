---
doc_id: "0c5b3ba2dc6ff0e3"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/b6e40ec8e102f1b942b2a5c807ea062b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Grant of Concessional Telephone facilities to retired and retiring employees of DOT Details"
date: "2010-06-22"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6a269914ac14ad28"
---

<!-- page 1 -->

No. 24-2/2009-PHP
Governmen! of India
Ministry of Communications & IT
Departmen! of Telecommunications
517, Sanchar Bhawan, Ashoka Road, New Delhi-I

***
Dated: 22nd June, 20 I 0

ORDER
Sub:

Grant
of
Concessional
Telecom
Facilities
to
Chairman/Members of Telecom Commission - regarding.

retired

DoT Order N0. 28-02,'2004-PIIP (Vol.JI) dated 23rd September, 2009 has
the provision for the following telecom facilities to the officers of the level of
Chairman I Members of Telecom Commission after superannuation from DoT:­
(i)

(ii)

One GSM Mobile Telephone conneclion with STD/ISD/
National/International Roaming and 3G facility subjec! to a free
limit of Rs. 3000/- per month.
One Broadband connection with 2 Mbps speed and data download
limit of 2 GB per month free of charge.

~

It has now been decided by the competent authority that the retired
Members/Chairman (T clecom Commission) will have discretion to choose any
tariff plan of MTNL/BSNL in respect of mobile! broadband connection subject
lo free limits prescribed therein.

(R.K.Sinha)
Section Officer (Pf-IP-II)
Tel: 2307 6255
To
1.
2.
3.
4..

Chairman, Telecom Commission
Member(S) I Member (T) ! Member (F). Telecom Commission
Chairman-cum-Managing Director, BSNL Nev, Delhi.
Chairman-cum-Managing Director, MTNL New Delhi.
