---
doc_id: "0e186bfd0a8fec8b"
source_url: "https://mohua.gov.in/static/uploads/2025/12/c29df0a7312e19cad913fb959a0a54e0.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Organizational Structure of Municipality"
date: "2016-11-14"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "681bf9a4f15af31c"
---

<!-- page 1 -->

XII. Organizational Structure of Municipality
14.

Even though there is no specific requirement under the 74th Constitution Amendment

Act relating to the organizational structure of Municipalities, the issue is as to what should be
the provisions in the municipal laws relating to the same.
(1)

Each State Government would have to, in the interest of a proper organizational
design and management structure of the Municipalities and for professionalization
of the municipal officers and employees, take critical decisions in these aspects.

(2)

The Calcutta Municipal Corporation Act, 1980, in section 14, provides for
appointment of ten statutory officers and section 17 provides for the “Establishment
of the Corporation and Schedule of Posts” which are required to be classified into 4
categories, namely, category ‘A’ posts, category ‘B’ posts, category ‘C’ posts and
category ‘D’ posts, on the basis of scales of pay of such posts. It further requires
that the Corporation shall maintain a schedule of posts which shall include the
designation and number of posts under each designation of officers and employees
constituting the “Establishment of the Corporation”.

(3)

The West Bengal Municipal Act, 1993, under section 53, provides for the
appointment of an Executive Officer, a Health Officer, an Engineer, a Finance
Officer, a Medical Officer, a Secretary and an Office Superintendent besides a
number

of

other

functionaries

which

shall

constitute

the

“Municipal

Establishment”. These officers are to be deputed from the State Cadres of Common
Municipal Services.
(4)

The Tamil Nadu Urban Local Bodies Act, 1998, in section 59, provides that the
municipal establishment shall consist of 4 classes of officers, namely, Class 1, of
heads of departments in the Municipality; Class 2, of officers who are immediately
next in rank to Class 1 officers; Class 3, of others (not being persons holding posts
in the service classified by the Government as basic service) appointed to serve
under the Municipality; and Class 4, of persons holding posts in the service
classified by Government as basic service.

1

<!-- page 2 -->

(5)

In the Bombay Provincial Municipal Corporation Act, 1949, as in force in Gujarat,
section 45 provides for appointment of a City Engineer, section 47 of a Municipal
Chief Auditor, section 48 of a Municipal Secretary and section 49 of a Deputy or
Assistant Municipal Commissioner.

(6)

The issues which each State Government need to consider regarding the
organizational structure of the Municipalities are :
(a)

what should be the size of the Municipal Establishments for the different
levels of Municipalities ?

(b)

who should be the appointing authorities ?

(c)

whether there should be State cadres of municipal officers and employees,

(d)

whether there should be one or more Municipal Service Commissions, and

(e)

whether a State Municipal Vigilance Authority may also be constituted.

Provisions Made in the Municipal Law

16.

The Municipal Law, in clause 36, provides for appointment of different categories
of officers for Municipal Corporations, Municipal Councils and Nagar Panchayats,
and also identifies the appointing authorities. Clause 37 provides for the
preparation of an “Establishment of Municipality and schedule of posts”, while
clause 38 specifies the “Appointing Authorities”. Clause 43 provides for
constitution of “Cadres of common municipal services” and the appointments
therefor, and clause 44 provides for the constitution of “Municipal Service
Commission for Municipal Corporation” and clause 45 provides for “Constitution
of State Municipal Service Commission for the Municipal Councils and Nagar
Panchayats”. Clause 46 provides for the “State Municipal Vigilance Authority”.

17.

Clause 42 introduces an innovation by way of appointment of a Municipal
Establishment Audit Commission to review and report on the status of the
municipal establishments in the State. The Commission would fix norms and
standards of manpower for different tasks performed at various levels of the
Municipalities.

2
