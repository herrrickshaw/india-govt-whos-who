---
doc_id: "100ddc4e2fdce38e"
source_url: "https://www.mea.gov.in/images/pdf/PO_01_11_2016.pdf"
ministry: "External Affairs (MEA)"
title: "Vacancy Circular for the post of Passport Officer"
date: ""
pages: 5
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "ca5d3796429b7e65"
---

<!-- page 1 -->

oe No. V.IV/575/21/2016
के Ministry of External Affairs
द्र CPV Division
Patiala House Annexe,
Tilak Marg, New Delhi-110001,
Dated: 01.11.2016
VACANCY CIRCULAR
The Ministry of External Affairs (CPV Division) intends to fill the following posts in
Passport Offices at stations indicated below amongst officers under the Central Government
including officers of All India Services / Central Secretariat Service in the Ministries / Departments
of the Government of India , on deputation basis:-
Number of Posts & Name | Scale of Pay | Eligibility
of Passport Office
Passport | 2 (Two): Pay Band-3, |Officers under the Central
Officer Rs. _15,600- |Government including officers of All
(PO) 1 Post ~— Passport Office, | 39,100 + |India Services:
Bangalore Grade Pay Rs.
1 Post — Passport Office, | 7,600/- (a) (i) holding analogous Posts on
Hyderabad (Pre-revised) {regular basis in the parent cadre or
department; or
(ii) with five years’ service in the
Grade rendered after appointment
thereto on a regular basis in posts in
Pay Band-3 (Rs. 15,600-39,100) and
Grade Pay of Rs. 6,600 (Pre-revised)
or equivalent in the Parent cadre or
Department; and
(b) Possessing _ the following
educational qualification and
experience:
(i) Bachelor’s degree from a
recognized University in India or
Association of Indian Universities
recognized degrees of foreign
Universities;
(ii) One year experience in Passport or
Consular or Emigration or
Administration or Finance or
Accounts or Vigilance work.
फिट

<!-- page 2 -->

-U-
~ Note 1: The Departmental Officers in the feeder category who are in the direct line of promotion
के will not be eligible for consideration for appointment on deputation. Similarly, deputationists shall
कि not be eligible for consideration for appointment by promotion.
Note 2: Period of deputation including period of deputation in another ex-cadre post held
immediately preceding this appointment in the same or some other organization or department of
the Central Government shall ordinarily not to exceed three years.
Note 3: The maximum age limit for appointment by deputation shall not be exceeding fifty six years
as on the closing date of receipt of applications.
Note 4: For the purpose of appointment on deputation basis, the service rendered on a regular basis
by an officer prior to the 1° January, 2006 or the date from which the revised pay structure based
on the Sixth Central Pay Commission recommendations has been extended, shall be deemed to be
service rendered in the corresponding grade pay or pay scale extended based on the
recommendations of the Pay Commission except where there has been merger of more than one
pre-revised scale of pay into one grade with acommon grade pay or pay scale, and where this benefit
will extend only for the post for which that grade pay or pay scale is the normal replacement grade
without any upgradation
2 The selected officers will be on deputation for a period of three years initially which can be
curtailed or extended further, depending upon the requirement, and with the consent of the officer
and approval of the lending department. The usual deputation terms will apply.
3. All Ministries/Departments of Government of India are requested to circulate the above posts
among the officers under the Central Government including officers of All India Services/ State
Government, working with them and forward the application (in prescribed pro forma Annexure A)
of eligible and interested officers, along with their dossiers and a certifica: Venere the effect that they are
clear from vigilance angle, to the undersigned by 1 December, 2016.
Oe
एसी! &
(M em)
Deputy Passport Officer (PVA) |
Ph. No. 011-23388648
To,
1; All Ministries/ Department of Government of India
2. All Chief Secretaries to the State Governments.
Copy to:-
1. Ministry of External A ffairs-[Kind attn to : Joint Secretary (Admn)].
2. Director (XP), Ministry of External Affairs, Shastri Bhawan, New Delhi- with the request
to upload this circular on the MEA’s website.
3. Director(PSP), Ministry of External Affairs, CPV Division, New Delhi -with the request
to upload this circular on the Passport Seva website
4. Director (CS), DoPT, Lok Nayak Bhawan, Khan Market, New Delhi- with the kind request
to upload this circular on DoPT’s website for wider circulation.
5. All Passport Offices.
6. Branch Secretariat at Chennai, Kolkata, Guwahati, Hyderabad.
7. Spokesman, JCM, MEA, New Delhi.
8. O/o JS (PSP) & CPO, CPV Division, MEA, New Delhi.

<!-- page 3 -->

ANNEXURE - A
CURRICULAM VITAE PROFORMA
1, Name (in Block letters) EWU SE Es cess oinawenrer auratus
2. Applied for the post of CHG NTTEEUEN ac anenenwesensne
(i) Place (Name of Station/s in order) Cl rcanmsasenes
(2)............
(3)............
3. Date of Birth (in Christian era) bvascbctsebosasonevssesescees
(i) Age as on 01.12.2016
[closing date of circular] 2
4. Date of retirement under Central/
State Government Rules sewn awestece saednasesesnaasscia
5. Educational Qualifications Bea eeesereettreretattrerten
6. Whether belongs to SC/ST हे लककतभ४2 ०० 5००००» «५०८०७
7. Educational qualifications and experienced possessed
—_———————--—_[T]T 1
Qualification/
Experience possessed
by the officers
Essential (I) (1)
(2)
(3)
Desired (1)
——————_1 33
Contd......2

<!-- page 4 -->

कि 2
8. Details of service, in chronological order.
Enclose a separate sheet, duly authenticated
by your signature, if the space is insufficient...
Office/ Post held From To Grade Scale of | Nature of
Institution Pay Pay and | Duties (in
Basic Pay | details)
|“ ee ee |
[| _1_ 1 | |
9. Contact details:
(A) Present Add:-
(i) Tel. No. 2४७ :४७०७३ ०४४७ ६७३४ ।३९२१६
(ii) Mob. No. Fe eee
(iii) E-mail- SSEARATAITAUCS IIIS Sn wen
(B) Office Add(with office name):-
(i) Tel. No. HUBS Acie coneennones
(ii) Mob. No. ccgeRNER RITE EEE La
(iii) E-mail- SEENON ERE:
10. In case the present post is held
on deputation / contract basis, please state
(a) Name of Office / Organization
and address (with Tel. No.) Sea eee ene renter
(b) The date of initial appointment waueeunpaeesenees ss
(c) Period of appointment on deputation was teaannvecew sense
(d) Name of the parent office / organization
to which you belong sates sniceiveone ess
Contd....3

<!-- page 5 -->

4.
I have carefully gone through the vacancy circular and I am well aware that the
Curriculum Vitae duly supported by documents submitted by me will also be assessed by the
Selection Committee at the time of selection for the post.
Signature of the candidate
Address. .....0:.0.0s.0ss0004+
Dated...........00006
It is certified that Shri/MS. ......0...c0:c:ccseeseeeetenessseseseseseeedS Clear from vigilance angle
and in case of selection, he/she will be relieved.
(Signature of Head of Office with Seal)
