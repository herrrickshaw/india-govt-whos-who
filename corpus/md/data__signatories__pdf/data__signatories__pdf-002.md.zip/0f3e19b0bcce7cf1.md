---
doc_id: "0f3e19b0bcce7cf1"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/f420f995af585bbb996845fe5f1b9fd9.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "District & Subordinate Courts in Punjab: Order dated 28.12.2016"
date: "2017-02-21"
pages: 11
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "63e58b29ead39ac6"
---

<!-- page 1 -->

: 1
F. No. J-11015/17/2016-Judl.
Government of India
Ministry of Law & Justice
Department of Legal Affairs
Judicial Section
ake
Shastri Bhawan, New Delhi,
Dated 284 December 2016
ORDER
In supersession of this Department's order No. 36(18)/2014-Judl. dated 19.02.2014 regarding
engagement of Standing / Additional Standing Govt. Counsel for District & Subordinate Courts in the
State of Punjab, the President is pleased to empanel following Advocates as Standing / Additional
Standing Govt. Counsel for conducting Central Govt. litigation (except cases of Railways & Income Tax
Department) before various District & Subordinate Courts in the State of Punjab as mentioned below,
for a period of three years from the date of this order or until further orders, whichever is earlier:
DISTRICT & SUBORDINATE COURTS
PUNJAB
pe a ee 0252...
DISTRICT AMRITSAR ]
SR. NAME ADDRESS MOBILE ENROLEMENT |
| NO. ia — NO, |
Additional Standing Govt. Counsel
1. | Navjeevan 49, Green Field, A Block, Majitha 9814444198 P/174/1987
Sharma Road, Amritsar |
|
2, | Umesh Kumar | 4, Street Nathe Khan No.6, Gate 9815007181 P/38/1993 ।
Gaind Khazana, Amritsar |
Vijayant Khanna | 7, Anand Avenue, Amritsar 9779171240 P/959/1989
4. | Sanjeev Kumar | H.No. 809, Street No. 5, Sharifpura, | 9914978034 P/4661/2010
Amritsar
5. | Rajinder Joshi | H. NO. 42-D, Gali No. 2, Gopal | 9815454876 | P/202/1901 7
Nagar, Majitha Road, Amritsar ls Bh
Sanjay SCF, D-32, Ranjit Avenue, Amritsar | 9815911108 P/314/1991
Aggarwal Daehn tes 31800 Bie
7. | Raman 5-D, Radha Soami Road, Near 9814148877 P/1212/1999
Aggarwal Adarsh Cinema, Amritsar

<!-- page 2 -->

न 2
के Anil Kumar 888, Lane No. 3, Kot Atma Singh, | Not provided P/63/1984
Sharma o/s Ram Bagh, Amritsar
Preeti Mohan 14-A, Shastri Nagar, Amritsar 9501077776 P/1631/2013
Taneja
10. | Mangal Singh 37, Kabir Park, Opp. GND 9872727258 P/1095/2007
University, Amritsar
Seems.
DISTRICT BARNALA |
Standing Govt. Counsel
La NAME ADDRESS MOBILE ENROLEMENT
NO.
Abhey Kumar | #52, 16 Acre Scheme, Behind New | 9417123577 P/106/1987
Jindal Bus Stand, Barnala Fd
Additional Standing Govt. Counsel
2. | Deepak Rai H.No, B6/313, Purana Bazaar, 9780007918 P/2891/2009
Near Ram Leela Ground, Barnala 1201
DISTRICT BATHINDA
Standing Govt. Counsel
ka ADDRESS MOBILE ENROLEMENT |
NO,
1. | Rajinder H.No. 41, Street No. 10/13, Guru 9888008214 P/1619/2005
Parshad Gobind Singh Nagar, Bathinda
Sharma
Additional Standing Govt. Counsel |
2. | Chander Mohan | 6255, Lakhi Ram Street, Sirki 9814129903 P/196/2001
Bazar, Bathinda
3. | Dinesh Kumar | Chamber No. 136, Lawyers’ 9803547760 P/755/2007
Chamber Complex, Ground Floor,
District Court, Bathinda ache beh.
4, | Mithu Ram #17201, Aggarwal Colony, 9417025640 P/291/1979
Gupta Bathinda, हे
5. | Aditya Mittal 19441, Street NO. 2, Bibi Wala 9888147139 P/2527/2008
Road, Bathinda

<!-- page 3 -->

: 3
DISTRICT FARIDKOT
Standing Govt. Counsel
Ae NAME ADDRESS MOBILE ENROLEMENT
NO.
1. | Harpartap Singh | Chamber No. 50, District Courts 9417398454 P/1145/2001
Faridkot, 151203
Additional Standing Govt. Counsel
2. | Gagandeep Chamber No. 105, District Courts, 9779952210 P/3057/1999 |
Singh Sukhija Sukhija Street, Main Bazar, |
Faridkot |
Dildeep Singh _| District Court, Faridkot 9780600978 | P/3530/2040
[ 4. | Jaskirat Singh _ | District Court, Faridkot 8054952864 [P/1232/1999
Ashok Kumar | Ch. No. 136, Distt. Courts, Faridkot | 9878950042 | P/381/1976
Anuj Gupta New Cantt Road, Street No. 6/2r, 9855807535 | P/839/2013
Faridkot-151203 :
DISTRICT FATEHGARH SAHIB |
Standing Govt. Counsel
ae
NO.
Subhash Ward No. 11, Near LIC Building, 9855480144 ~ P/306/1979
Chandra Lutava | Amloh, Distt. Fatehgarh Sahib
Additional Standing Govt. Counsel
2. | Gaurav Garg Ward No. 5, Madhav Enclave, 9888209164 P/1827/2008
Anniya Road, Amloh, District |
Fatehgarh Sahib
3. | Narinder Kumar | H. No. 3126, Nai Abadi, Near BDO | 9915615000 P/995/2000
Office, Sirhind Mandi, Tehsil and
District Fatehgarh Sahib
4. | Ashok Kumar | Ward NO. 2, Khanna Road, Amloh, | 9876084496 P/404/1977
Tehsil Amioh, Distt. Fatehgarh
Sahib

<!-- page 4 -->

: 4
DISTRICT FAZILKA
Standing Govt. Counsel
coe | ADDRESS MOBILE ENROLEMENT
NO. — |
1. | Sushil Kumar B-Ill, 348, Gandhi Nagar, Fazilka 9417266737 P/1003/1981
Gumber eek = eae
Additional Standing Govt. Counsel
2. [AnilKamra | Street No. 1, Crossing 6%, New Not provided P/201/1981
Suraj Nagri, Abohar, District Fazilka iiss ties
DISTRICT FEROZEPUR
Standing Govt. Counsel
ae NAME ADDRESS ENROLEMENT
NO.
1. | Mukesh Goyal | H.No. 92-93, Street No. 3, 9814934859 P/2717/1999
Ferozepur Cantt., District |
Ferozepur. |
Additional Standing Govt. Counsel
2. | Iqbal Dass 398-A, New Azad Nagar, Ferozepur | 9417784652 P/931/2008
Bawa Cit 9217600052
3. | Gourav Kumar | R.K.Traders, Main Bazar, Tehsil 9914390200 P/1559/2010
Guru Har Sahai, District Ferozepur
Sahil Gupta H.No, 46, Street No.1, Near Shani 9417952432 P/2619/2009
Mandir, Ferozepur Cantt., District
Ferozepur
DISTRICT GURDASPUR
Set i cca i Lee geen eee traces SORE
Standing Govt. Counsel
eo | ADDRESS MOBILE ENROLEMENT
NO.
Parminder Kahnuwan Road, Gurdwara Wali 9815313487 P/633/1992
Singh Gali, Gurdaspur 9872204624
Ghumman की |

<!-- page 5 -->

- 5
Additional Standing Govt. Counsel
2} Varun Gosain H.No, 290/291, Improvement Trust | 9888877884 P/3084/2010
Colony, Scheme No. 5, Jail Road,
Gurdaspur. Rs
3 Jasvinder Singh | 123/150, Shastri Nagar, Batala, 9814402123 P/534/2001 |
District Gurdaspur. a al
DISTRICT HOSHIARPUR
Standing Govt. Counsel
Ee ADDRESS MOBILE =
NO.
1. | Munish Kumar | 153, New Civil Lines, Hoshiarpur | 9888297882 | P/1213/1998
|__| Ralhan i Teen et a
Additional Standing Govt. Counsel |
2. | Ajay Gupta Mohalla Narayan Nagar, Sada Ram | 9888712143 | P/1924/1999 - हु
Colony, Bahadurpur, Hoshiarpur
3. | Sandeep Kumar | B-12, MCH, 10/2, New Jagatpura, | 9780340300 P/1876/2008
Hoshiarpur &
4. | Rohit Kumar S/o Vinod Kumar, Office Opp. 9888347578 P/1742/2007
Sawraj Gurdwara, Main Market, VPO
Hazipur, Tehsil Mukerian, District
Hoshiarpur. » Bi
DISTRICT JALANDHAR
Standing Govt. Counsel
eo NAME ADDRESS MOBILE ENROLEMENT
NO.
1. | Raj Kumar WP-89, Basti Sheikh, Jalandhar 9815099700 PI67S/1986 |
Bhalla = 3 हि aoe है Bl
Additional Standing Govt. Counsel
2. | Karan Kalia Jagdish Niwas, EH-178, Civil Lines, | 9646599858 P/536/1984 |
Jalandhar 9814820858
3. | Harsh V. Kohli | 299, New Kalgidhar Avenue, 66 9876641444 P/218/1998
Feet Road, Jalandhar. ef
Sumit Kaushal | Chhati Gali, Mehli Gate, Phagwara | 9876083218 P/2201/2010

<!-- page 6 -->

a 6
| J.L:Naagar 264, Chahar Bagh, Jalandhar City 9814517614 P/55/1984
Surinder Mohan | Chamber No. 119, District Courts, 9815390872 P/507/1990
Jalandhar
Bharat Bhushan | WT-292, Basti Sheikh, Jalandhar | 9814576712 P/818/2006
eee Ravish Malhotra | 396-A, J.P.Nagar, Jalandhar 9781030307 P/1288/2004
Vikas Bhardwaj | 5, Shivaji Park, Near Gurudwara 9988599094 P/2806/2008
Diwan Asthan, Central Town,
Jalandhar
10. | Rajesh Kumar | H.No. B-ilI/19-20, Arya Samaj 9417224747 P/305/1998
Street, Phillaur, District Jalandhar
Sanjeev Kamboj | E A 58, Quilla Mohalla, Jalandhar | 9814165614 P/816/1995
12. | Amit Singh Chamber No. 347, New Courts, 9888564013 P/1707/2005
Sandha Jalandhar
13. | Jaswant Singh | 52, Golden Colony, Phase-Il, 9815194027 P/217/1997 !
Birring, Jalandhar
14. | Gurvinder Paul | 77, Vasant Avenue, Meethapur 9876806741 PH711985 |
Singh Rana Road, Jalandhar
DISTRICT KAPURTHALA
Standing Govt. Counsel
ie | ADDRESS MOBILE reo
NO,
1. | Inderjit Kumar | 4-B, Sham Nagar (Shiv Puri), 9417223900 P/2265/2006
Phagwara, District Kapurthala |
DISTRICT LUDHIANA
Standing Govt. Counsel
NO.
1. | Rakesh Bhatia | 1740/32/A, Bank Colony, Ward No. | 9814058855 P/154/4995
28, Zone West, Haibowal Kalan,
Ludhiana
Y

<!-- page 7 -->

: 7.
Additional Standing Govt. Counsel ]
|
os
2. | Vivek Bhardwaj | H.No. 42044, Misserpura Bazar, 9463243099 P/1061/2010 |
Jagraon, District Ludhiana _ eae 7 =|
3. | Darshan Kumar | Kothi No. 1311, Central Town, 9417136837 P/258/1974
Gupta Pakhowal Road, Ludhiana ae
4, | Amrit Singh 4047, Street No.3, Narinder Nagar, | 9888011768 P/984/2004
Samrala Chowk, Ludhiana
5. | Kamal Gupta H.M. 92, Jamalpur Colony, 9953080451 R/2759/2007
Ludhiana 9356846411
Rupila Mohini Chamber No. 8042, 8" Floor, 9888921314 P/3317/1999
Chamber Complex, Part Il, District
Court Ludhiana.
DISTRICT MANSA |
|
Standing Govt. Counsel |
ca NAME [| ADDRESS MOBILE ENROLEMENT
NO.
Suraj Kumar | DAV School Street, Water Works 9417428632 P/237/1987
Chhabra Road, Mansa
DISTRICT MOGA
SR. NAME | ADDRESS MOBILE ENROLEMENT
NO. NO. |
|
Additional Standing Govt. Counsel |
|
1. | Varinder Kumar | H.No. 11/239, Old Grain Market, 9876130621 P/4220/2002 |
Moga-142001 |
2. | SamirGupta | H. No. 414, Street No. 7, New 9653726580 P/1629/2003
Town, Moga-142001 2 आम गे
DISTRICT MOHALI (S. A. S. NAGAR)
ae | NAME — ae 1 ADDRESS MOBILE ENROLEMENT |
ia NO. —
Standing Govt. Counsel
1. | Puneet Kothi No. led Sector 24-A, 9988981719 किक
Chauhan Chandigarh

<!-- page 8 -->

8
Additional Standing Govt. Counsel
Geetanjali Bali] H. No. 2018, Sector 66, Mohali 9815199690 P/3205/2010
Manish Joshi HIG No, 244, Sector 71, Mohali 9417007240 P/1423/2006
4. | Neeru Thareja | Flat No. 908, Gilco Heights, Sector | 9888517418 P/1191/2007 |
127, Gilco Valley, SAS Nagar,
Mohali
5. | Yogesh Goyal | H.No.1849-A, Randhawa Road, 9914698123 P/811/2005
Kharar, District SAS Nagar,
Mohali.
DISTRICT NAWASHAHAR (S. B. S. NAGAR)
NAME ADDRESS MOBILE ENROLEMENT
NO. :
Standing Govt. Counsel |
1. | Dhiraj Chamber No. 76, Judicial Court 9815293297 P/1501/2000
Sehajpal Complex, Nawanshahar, Distt. SBS |
Nagar |
Additional Standing Govt. Counsel
2. | Nipun Bhalla | Chamber No. 5, Judicial Court 9463686768 P/1493/2012
Complex, Nawanshahar, Distt. SBS
Nagar
3. | Dinesh VPO Sahiba, Tehsil Balachor, 9463848480 गा |
Bhardwaj District Shaheed Bhagat Singh
Nagar |
|
DISTRICT PATHANKOT
oo | ADDRESS ee ENROLEMENT
ENO. ;
Standing Govt. Counsel
1. | Rajdeep Singh | Near Vaishnu Mata Mandir, Behind | 9417253287 | —
Vishvkarma Mandir, Sant Nagar,
Pathankot 5 ae

<!-- page 9 -->

: 9
Additional Standing Govt. Counsel
2. | Ms. Neelkamal | D/o Shri Fazilat Masih, R/o Near C, | 9876717699 P/97 1/1999
N. |. Church, Mission Road,
Pathankot.
3. | Ms. Neel Kamal | Near C. N. |. Church, Mission | 9876717899 P/971/1999
Road, Pathankot. aan
|
DISTRICT PATIALA
NAME ADDRESS MOBILE | ;
NOE
Standing Govt. Counsel
1. | Sanjay Garg 168-A, Urban Estate Focal Point, 9877001792 P/125/1993
Rajpura, District Patiala :
Additional Standing Govt. Counsel
2. | Bikram Jit Shakuntlam Niwas, Near Old Police | 9814955252 P/T45/1998
Passey Station, Old Tehsil Rajpura, Distt.
Patiala now Distt. Mohali
Aditya Gupta | H.No. 29, Urban Estate, Phase-3, | 9872201235 P/3169/2009
Patiala
VPO Tepla, Tehsil Rajpura, District | 9814253237 P/1086/1993
Patiala
5. | Rakesh Kumar | H.No. 317, Ward No. 5, Garg 9417040815 P/220/1990
Colony, Tehsil Old Rajpura, District
Patiala
6. | Rupinder Kaur | 46, Sewal Colony, Near 22 Number | 9814969685 P/2892/1999
a Phatak, Patiala |
7. | Bansal Jonny H.No. 4, Dhillon Marg, Model Town, | 9855576186 P/2471/2006 |
Dunichand Patiala ies
Kamal Deep Kothi No. 387, Dalima Vihar, 9646200138 P/639/1993
Sharma Rajpura, District Patiala =|
Satpal Sharma | H.No. 327, Bharat Colony, Ward 9815497325 P/1270/1998
No. 28, Old Rajpura, Tehsil
Rajpura, District Patiala
10. | Vishavdeep H.No, 2327, Sector 44C, 9888488658 हा
Gupta Chandigarh, Chamber No. 173,
Lawyers’ Chamber, District Courts
Patiala
11. | Rajesh Goyal Upper Storey, Mamta Finance 9814323302 P/4800/2010
Company, Toll Market, Jakhal
— Road, Patran, Distt. Patiala-147105

<!-- page 10 -->

: 10
DISTRICT ROOPNAGARIROPAR
ADDRESS MOBILE =
NO.
Standing Govt. Counsel
1. | Manish Village Chandesar, P.O. Mangewal, | 9417064555 P/936/2000
Dharmani Tehsil Anandpur Sahib, District
Ropar
Additional Standing Govt. Counsel
2. | Sachin Kaushal | S/o oe ee | Devinder Kumar, Rio Ward | 9872658904 P/580/2004 |
No. 4, Mohalla Attari, Shri |
Anandpur Sahib, Distt. Roopnagar |
ifs |
DISTRICT SANGRUR |
NAME ADDRESS MOBILE ENROLEMENT |
zal a
Additional Standing Govt. Counsel 7
1. | Surjit Singh 129, Khalifa Street, Near Janta 9417422277 P/1147/2004 |
Randhawa Karyana Store, Sangrur-148001 |
2; The engagement and professional fee of the aforesaid advocates will be governed by the terms
and conditions contained in this Department's OM No. 27(11)/99-Judl. dated 24.09.1999 read with OM
No. 26(1)/2014/Judl. dated 01.10.2015 & instructions issued subsequently through OMs. The aforesaid
OMs are available on the website of this Department i.e. www.lawmin.nic.in under heading ‘Circulars
pertaining to litigations’.
3. Hindi version of this order will follow.
Paws
(R. K. Srivastava)
Deputy Legal Adviser
