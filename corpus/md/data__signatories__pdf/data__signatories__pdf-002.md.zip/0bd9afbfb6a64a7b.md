---
doc_id: "0bd9afbfb6a64a7b"
source_url: "https://doj.gov.in/static/uploads/2025/09/4348e464da2c0261573c0c1f0f232e98.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Sh. Justice Y.G. Khobradage and 03 other Addl. Judges as Permanent Judges of Bombay High Court (19.07.2024)"
date: "2024-07-19"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "78da6701596f6591"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13014/02/2024-US.I (i)
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011, dated 19th July, 2024.

NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint S/Shri Justices (i)
Yanshivraj Gopichand Khobragade, (ii) Mahendra Wadhumal Chandwani, (iii)
Abhay Sopanrao Waghwase, and (iv) Ravindra Madhusudan Joshi, Additional
Judges of the Bombay High Court, to be Judges of that High Court with effect from
the date they assume the charge of their respective offices.

si
(Jagannah Stinivasan)
Joint Secretary to the Government of India
Tele: 2338 3037

To
The Manager,
Government of India Press,
Mint° Road,
New Delhi.

<!-- page 2 -->

No. K-13014/02/2024-US-I (i)

Dated:19.07.2024.

Copy to:1.

2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.

S/Shri Justices (i) Yanshivraj Gopichand Khobragade, (ii) Mahendra
Wadhumal Chandwani, (iii) Abhay Sopanrao Waghwase, and (iv) Ravindra
Madhusudan Joshi, Additional Judges of the Bombay High Court through the
Registrar General, Bombay High Court, Mumbai.
The Secretary to the Governor, Maharashtra, Mumbai.
The Secretary to the Governor, Goa, Panaji.
The Secretary to the Chief Minister, Maharashtra, Mumbai.
The Secretary to the Chief Minister, Goa, Panaji.
The Secretary to the Chief Justice, Bombay High Court, Mumbai.
The Chief Secretary, Government of Maharashtra, Mumbai.
The Chief Secretary, Government of Goa, Panaji.
The Registrar General, Bombay High Court, Mumbai.
The Accountant General, Maharashtra, Mumbai.
The Accountant General, Goa, Panaji.
The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.
PS to the Principal Secretary to the Prime Minister, Prime Minister's Office,
South Block, New Delhi.
Registrar (Conf.), o/o the Chief Justice of India, 7 Krishna Menon Marg, New
Delhi.
PS to the MoS, L&J (I/C), L&J/PPS to Secretary (J).
Technical Director, MC, Department of Justice, with a request to upload the
notification on the website of the Department (www.doi.eov.in).

611 76
(Prem hand)
Under Secretary (Appointments-I)
Tele: 011-23382978
