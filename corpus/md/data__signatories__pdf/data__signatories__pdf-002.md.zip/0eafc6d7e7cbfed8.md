---
doc_id: "0eafc6d7e7cbfed8"
source_url: "https://socialjustice.gov.in/writereaddata/UploadFile/230517.pdf"
ministry: "Department of Social Justice and Empowerment (DoSJE)"
title: "Tender for hiring of Services of Security Guard"
date: ""
pages: 7
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9eb0d1dac9ea0da3"
---

<!-- page 1 -->

f
|
| No.D-11020/01/2014-Genl.]
i ey Government of India
. Ministry of Social Justice & Empowerment
| Department of Social Justice & Empowerment
| Shastri Bhavan, New Delhi
Dated the 23 May, 2017
| Notice Inviting Tender
| (Last date 16.06.2017 at 3.00 PM)
| Sealed tenders are invited from reputed and registered firms for hiring of services of
| Security Guards for round the clock security in the office of Department of Social Justice &
| Empowerment located at Jeevan Prakash Building, Connaught Place, West Block-8, R. K.
Puram and Pt. Deendayal Upadhyay Bhawan, CGO complex as per the details given at
Annexure-I, IT & IIL. At present services of 09 (nine) Security Guards are required which may
| vary depending upon the requirement at a given time. The quotations may be sent in sealed
envelopes marked "Quotations for hiring of services of Security Guards" and should be dropped
in the Tender Box at Facilitation Centre of the Department at Garage No. 8, Ground Floor,
Shastri Bhavan, New Delhi latest by 3.00PM on or before 16.06.2017. The tender will be
opened at 4.00PM on the same day in Room No. 240 'A' Wing, Shastri Bhavan, New Delhi.
Representatives of the applying firms are at liberty to be present at the time of opening of
| quotations.
| Eligibility Criteria
1. The agency should have experience for providing services of manpower to reputed
organizations in Government for at least three years. Attach list of clients as above along with
satisfactory performance certificate from 3 such clients.
2. The agency should furnish attested copies of the following documents as per Annexure I:
i) Registration Certificate under Contract Labour (R&A) Act, 1970
ii) ESI/EPF/Income-Tax/Service Tax Registration Certificates.
iii) Income Tax/Clearance Certificate for last three years/copy of Tax return.
(iv) Quality Certification i.e. ISO etc.
(v) Minimum wages payment certificate from Labour Enforcement Office.
(vi) Balance sheet for last three years.
3. The overall merits will be decided by the committee on the basis of technical
specifications and rates quoted by the bidder.
4, The bidder should submit a Demand Draft of Rs. 10,000/-(Rupees Ten thousand only)
drawn in favour of DDO, Department of Social Justice & Empowerment, New Delhi as EMD
along with the quotations failing which the bid will be rejected. EMD in any form other than
stated above shall not be accepted. The earnest money of the tenderers whose tenders are not
accepted will be returned without any interest thereon after finalization of the tender. |
5. Tender without documents as above/incomplete tenders are liable to be rejected. The |
Department reserves the right to accept/reject any offer without assigning any reason thereof,
beer जा |

<!-- page 2 -->

t
| -2-
) 7
| 6. The details of the work involved are as under:
(i) | The agency/contractor shall be responsible for all security measures and arrangements
to safeguard the movable and immovable property.
| (ii) Opening the locks of premises at commencement of office & applying the locks when
the office closes.
| (iii) Prevention of unauthorized entry of personnel including all types of outside vendors
| in the premises. Getting the particulars of visitors entered in the relevant register.
| (iv) At the reception, the security guard will have to sce that the visitors are properly
attended to and guided and if need be necessary security check may be exercised.
| (vy) Any other work assigned to him by the competent authority.
|
| 7. The tender is subject to the following terms & conditions:
i, The agency should be registered under Labour laws for providing services of man
power and with the Registrar of firms for at least 3 years before the closing date of
| tender.
ii. The agency shall not engage any sub-contractor or transfer the contract to any other
person.
iii. The clearance of the local police will be obtained by the agency before deployment of i
the personnel and a copy of the same should be submitted to this office. |
iv. In normal course, the contract can be terminated by the Department by giving one |
month's notice & by contractor by giving three months notice. In case the services of |
the contractor are not found satisfactory, the contract can be terminated without |
giving any notice. :
v. The terms and conditions contained herein shall form part of and shall be taken as if
they were included in contract agreement to be entered into by the agency. !
vi. The contractor shall take due care to comply with the provisions of the Contract
Labour (Regulation & Abolition) Act, 1970 including all other legal obligations, like
policy changes made by the Government or legal amendments from time to time, |
during the period of contract.
vii. The contract shall remain valid for a period of one year. However, if required the \
contract can be extended further on mutual agreement after the expiry of the tenure on :
the same terms & conditions for a period not exceeding another 2 years. |
viii. Any personnel engaged by the Agency if found indulging in illegal and intolerable |
activities will be handed over to the police or any other action deemed fit against him |
will be taken besides termination of the contract immediately. Agency shall be solely |
responsible for the conduct and behaviour of persons deployed by the agency. i
ix. The agency shall not replace the staff without proper substitute & without prior i
permission, of the Department. |
x. In normal conditions worker will not be deployed for double duty. However, in case :
of emergency/urgency, a worker may be allowed for not more than two continuous ५
duties with proper written information to the authority in the Ministry. |
A |
I
|
4
|
i

<!-- page 3 -->

|
t
-3-
i.

i xi. Security guards should have photo identity card having details of Name, Residential

| Address, Phone Number if any, ESI card No, & E.P.F. Number.

xii. The agency shall be prompt in making replacement in case any Guard is not available
on duty or found unsuitable for Duty. Agency shall promptly arrange additional staff
whenever required by the Department.

xiii. The agency/contractor shall work under the overall supervision and direction of the
officer authorized by the Under Secretary (Admn.).

: xiv. The agency will be responsible for complying with payment of minimum wages and
other benefits including prescribed number of duty hours/leave/ holidays, etc. to its
employees deployed in the Department, as per Labour Laws in force from time to

time. The agency will be responsible to comply with all labour legislations including

social security, Service-Tax wherever applicable and such other statutory orders by

Government/Municipality which may be in force from time to time.

xv. Any dispute regarding the contract shall be resolved through arbitrator to be

| nominated by Additional Secretary or Secretary in this Department. The contract shall

| be subject to the Indian Law and the jurisdiction of the courts located in Delhi.
8. PENALTY CLAUSE: A penalty of Rs.200/-(Rupees two hundred only) per instance
shall be imposed and deducted from the contractor's /Agency's bill, if:

| (a) The Security Guard is not found in proper uniform and displaying photo identity card.

| (b) The Security Guard is found indulging in smoking/drinking at the time of duty hours and

| such Security Guard shall not be allowed to enter in the office premises in future.

(c) The Security Guard is found sleeping during duty hours.
(d) The Security Guard is found missing from the place of duty, for any reason.
(e) The behaviour of Security Guard is found harsh/rude and non-cooperative towards the
staff.
(f) The Security Guard is found performing the duty by submitting fake name & address,
(g) The Security Guard does not perform his duty properly.
Yours faithfully,
(Deepak es
Under Secretary to the Govt. of India
an go eT
sre te ean empowerment
Sete 20 ‘Eno
me Ss Mow

<!-- page 4 -->

| ‘
। A
1) ANNEXURE-I
TENDER FORM FOR THE ENGAGEMENT OF PRIVATE SECURITY AGENCY FOR
PROVIDING SECURITY GUARD
1. Name of the Firm:
2. Full Postal Address with
Cell Phone No, Telephone No. and Fax No,
3. Date of Establishment of Firm.
4. Nature of the firm i.e. whether proprietorship/
Partnership/limited. Details of partners etc.
5. If your firm Registered under
| Labour Act, Factories Act ete give details of
| Registration No. (Please enclose photocopy)
| 6. Total number of Employees:
7, Are you in the list of approved contractors
of any other organizations / institutions, if any,
give details (Append extra page if necessary):
8. Give details of any Government contracts
executed during the last three years
(append extra page if necessary):
9, Any other information which you
consider necessary to furnish:
10. Details of Earnest Money to be deposited
along with Tender Form.
11... Permanent Account No. of Income Tax- |
Department (attach copy) |
|
12. Service Tax Registration Certificates (attach copy) |
13, EPF Regn No., ESIC Account No. (attach copy) |
14... Copy of ITR of last three years (attach copy) |
15. Copy of ISO Certificate or any other International |
Accrediation certificate (attach copy) |
16. Minimum wages payment certificate from Labour Enforcement Office |
(attach copy) |
i
17. Balance Sheet/ Audited Account of last three years. ya
18. | Name and Address of your Bankers |
stating the name in which the Account stands.
-contd- i

<!-- page 5 -->

i
| ता
i 5
O
It is certified that the particulars given above are true to the best of my knowledge and
I/we have read the terms & conditions and duties/responsibilities of the Security Staff to be
engaged for the purpose and have also understood the same and do hereby undertake to abide by
the same without any reservations on any ground whatsoever. In case of any breach of the said
। conditions, I/we shall be responsible for the consequences of the same.
Full Name & Signature of Authorized Signatory of the Agency with
rubber stamp affixed.
| Date
। Place __
t
{
|
|
|
|
|
i
|
|
|
j
|

<!-- page 6 -->

i
|
| -6-

(३) ANNEXURE-IT
| DETAILS OF THE CHARGES FOR PROVIDING SECURITY GUARDS:
|
| Monthly Charges (In Rs.) for one Security Guard for six days a week.
| 1. Basic wages
|
| 2. Total amount towards ESIC per month

in respect of one Security Guards.
| 3. Total amount towards EPF per month
| in respect of one Security Guards.
| 4, Uniform and washing allowance
| 5. Total Cost per Head
| “4, Service charges per month to be claimed by the
| contractor.
| 8. Weekly off/National Holidays
: 9, Grand Total
10. Service Tax
11. Any other charges claimed by the contractor.
Date:-
Place:-
Full Name of Tenderer:

Signature and the seal of Tenderer
|
|
|
|
|
i

<!-- page 7 -->

|
i , oe
ft og is
j .
2
i.
“ ANNEXURE-DI
LIST OF DOCUMENTS TO BE ATTACHED ALONGWITH THE FORM
| I. List of the Institutions with period to whom similar services are/were being
provided along with performance report from respective authorities.
2. Organization set up which should clearly indicate the total staff strength and its
break-up category wise.
3. Performance report or commendation certificate obtained from the police
authorities, if any.
i 4. An attested photocopy of the contract already entered with any Government or
well reputed organization.
5. Coloured Photographs of Security Guards in uniform (of both summer and winter)
with the sample identity card including whistle, cane, badge etc.
6. Copy of Registration Certificate of the firm related to the ESIC, EPF, S. Tax and I.
Tax ,Permanent Account Number, Labour Department, DGR etc.
7. Any other relevant information may also be furnished.
|
| Signature of the Tenderer along with seal and date
|
we
ँ
|
