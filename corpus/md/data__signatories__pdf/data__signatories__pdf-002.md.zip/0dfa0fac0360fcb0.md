---
doc_id: "0dfa0fac0360fcb0"
source_url: "https://consumeraffairs.gov.in/public/upload/admin/cmsfiles/menus/RTI_Rulesmenu.pdf"
ministry: "Department of Consumer Affairs (DoCA)"
title: "RTI Rules   (PDF, 131.55 KB)   RTI Rules  -->"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5c04112527dfc0d2"
---

<!-- page 1 -->

MINISTRY OF PERSONNEL, PUBLIC GRIEVANCES AND PENSIONS
(Department of Personnel and Training)
NOTIFICATION
New Delhi, the 31st July, 2012
GS.R.603(E).—In exercise of the powers conferred by Section 27 of the Right to Information Act, 2005 (22 of 2005)
and in supersession of the Central Information Commission (Appeal Procedure) Rules, 2005 and the Right to Information
(Regulation of Fee and Cost) Rules, 2005 except as respects things done or omitted to be done before such supersession,
the Central Government hereby makes the following rules, namely :—
I. Short title and commencement —(1) These rules may be called the Right to Information Rules, 2012.
(2) They shall come into force on the date of their pUblication in the Official Gazette.
2. Definitions.—In these rules, unless the context otherwise requires,—
(a) "Act" means the Right to InforrnationAct, 2005 (22 of 2005);
(b) "Commission" means the Central Information Commission constituted under sub-section (1) of Section
12 of the Act;
•
"First
Appellate
Authority"
means
an
officer
in the public authority who is:senior in rank to the Central
(c)
Public Information Officer to whom an appeal under sub-section (1) of Section 19'of the Act lies;
(d) "Registrar" means an officer of the Commission so designated and includes an Additional Registrar,
Joint Registrar and Deputy Registrar;
(e) "Section" means a Section of the Act;
(Call other words and expressions used herein but not defined in these rules shall have the same meanings
assigned to them in the Act.

'g q8 6-112--2

<!-- page 2 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY
3. Application Fee.

—

[PART II—Sec. 3(i)]

An application under sub-section (1) of Section 6 of the Act shall be accompanied by a fee

of rupees ten and shall ordinarily not contain more than five hundred words, excluding annexures, containing address of the
Central Public Information Officer and that of the applicant:
Provided that no application shall be rejected only on the ground that it contains more than five hundred words.
4. Fees for providing information. Fee
for providing information under sub-section (4) of Section 4 and
sub-sections (I) and (5) of Section 7 of the Act shall be charged at the following rates, namely :—
—

(a) rupees two for each page in A-3 or smaller size paper;
(b) actual cost or price of a photocopy in large size paper;
(c) actual cost or price for samples or models;
(d) rupees fifty per diskette or floppy;
(e) price fixed for a publication or rupees two per page of photocopy for extracts from the publication;
(Ono fee for inspection of records for the first hour of inspection and a fee of rupees 5 for each subsequent hour
or fraction thereof; and
(g) so much of postal charge involved in supply of information that exceeds fifty rupees.
5. Exemption from Payment of Fee. No fee under rule 3 and rule 4 shall be charged from any person who, is
below poverty line provided a copy of the certificate issued by the appropriate Government in this regard is submitted
alongwith the application.
—

6. Mode of Payment of fee.

—

Fees under these rules may be paid in any of the following manner, namely:—

(a) in cash, to the public authority or to the Central Assistant Public Information Officer of the public authority,
as the case may be, against a proper receipt; or
(b) by demand draft or bankers cheque or Indian Postal Order payable to the Accounts Officer of the public
authority; or
(c)

by electronic means to the Accounts Officer of the public authority, if facility for receiving fees through
electronic means is available with the public authority.

7.

Appointment of Secretary to the Commission. The
Central Goveinment shall appoint an officer not below
the rank of Additional Secretary to the Government of India as Secretary to the Commission.
—

8. Appeal to the Commission.

Any person aggrieved by an order passed by the First Appellate Authority or
by non-disposal of his appeal by the First Appellate Authority, may file an appeal to the Commission in the format given in
the Appendix and shall be accompanied by the following documents, duly authenticated and verified by the appellant,
namely:
(i)

—

a copy of the application submitted to the Central Public Information Officer;

(ii) a copy of the reply received, if any, from the Central Public Information Officer;
(iii) a copy of the appeal made to the First Appellate Authority;
(iv) a copy of the Order received, if any, from the First Appellate Authority;
(v) copies of other documents relied upon by the appellant and referred to in his appeal; and
(vi) an index of the documents referred to in the appeal.
9. Return of Appeal.

An appeal may be returned to the appellant, if it is not accompanied by the documents as
specified in rule 8, for removing the deficiencies and filing the appeal complete in all respects.
10. Process of appeal.

—

(1) On receipt of an appeal, if the Commission is not satisfied that it is a fit case to proceed
with, it may, after giving an opportunity of being heard to the appellant and after recording its reasons, dismiss the appeal:
—

Provided that no appeal shall be dismissed only on the ground that it has not been made in the specified format if
it is accompanied by documents as specified in rule 8.
(2) The Commission shall not consider an appeal unless it is satisfied that the appellant has availed of all the
remedies available to him under the Act.

<!-- page 3 -->

: 3ffiltIR17

%RR

3(i)]

(3) For the purposes of sub-rule (2), a person shall be deemed to have availed of all the remedies available to him
under the Act:
(a) if he had filed an appeal before the First Appellate Authority and the First Appellate Authority or any other
person competent to pass order on such appeal had made a final order on the appeal; or
(b) where no final order has been made by the First Appellate Authority with regard to the appeal preferred, dnd
a period of forty five days from the date on which such appeal was preferred has elapsed.
11. Procedure for deciding appeals.

—

The Commission, while deciding an appeal may.—

receive oral or written evidence on oath or on affidavit from concerned or interested person;
(ii) peruse or inspect documents, public records or copies thereof;
(iii) inquire through authorised officer further details or facts;
(iv) hear Central Public Information Officer, Central Assistant Public Information Officer or the First Appellate
Authority, or such person against whose action the appeal is preferred, as the case may be;

,

(v) hear third party; and
(vi) receive evidence on affidavits from Central Public Information Officer, Central Assistant Public Information
Officer, First Appellate Authority and such other person against whom the appeal lies or the third party.

12. Presence of the appellant before the Commission.
seven clear days before the date of hearing.

—

(I) The appellant shall be informed of the date at least

(2) The appellant may be present in person or through his duly authorised representative or through video
conferencing, if the facility of video conferencing is available, at the time of hearing of the appeal by the
Commission.
(3) „Where the Commission is satisfied that the circumstances exist due to which the appellant is unable to attend
the hearing, then, the Commission may afford the appellant another opportunity of being heard before a final
decision is taken or take any other appropriate action as it may deem fit.
13. Presentation by the Public Authority.

—

The public authority may authorise any representative of any of its

officers to present its case.
14. Service of notice by Commission.
any of the following modes, namely:—
(i)

—

The Commission may issue the notice by name, which shall be served in

service by the party itself;

(ii) by hand delivery (dasti) through Process Server;
(iii) by registered post with acknowledgement due;
(iv) by electronic mail in case electronic address is available.
15. Order of the Commission. The order of the Commission shall be in writing and issued under the seal of the
—

Commission duly authenticated by the Registrar or any other officer authorised by the Commission for this purpose.
[F. No. I/35/2009-1R]
MANOJ JOSHI, R. Secy.
APPENDIX
FORMAT OF APPEAL
(See Rule 8)
I. Name and address or the appellant
2.

Name and address of the Central Public Information Officer to whom
the application was addressed

3.

Name and address of the Central Public Information Officer who gave
reply to the Application

<!-- page 4 -->

THE GAZETTE OF INDIA : EXTRAORDINARY
4.

Name and address of the First Appellate Authority Who decided the
First Appeal

5.

Particulars of the application

6.

Particulars of the order(s) including number, if any, against which the
appeal is preferred

7.

Brief facts leading to the appeal

8.

Prayer or relief sought

9.

Grounds for the prayer or relief

10. Any other information relevant to the appeal
I I. Verification/authentication by the appellant

Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-I 10054.

[PART 11—Sec 3(i)]
