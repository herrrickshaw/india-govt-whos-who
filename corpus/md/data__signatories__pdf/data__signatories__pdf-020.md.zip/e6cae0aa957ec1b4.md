---
doc_id: "e6cae0aa957ec1b4"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/01506a045ee1c5ea3b3b00a8baed0607.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Provision of telecom facilities and reimbursement to officers of DoT- regarding"
date: "2018-10-08"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cf3d88de8a8d425c"
---

<!-- page 1 -->

No. 2-3/2008-PHP
Government of India
Ministry of Communications
Department of Telecommunications, PHP Wing
516, Sanchar Bhawan, 20, Ashoka Road, New Delhi-110001

Dated the

81h October, 2018

Sub: Provision of telecom facilities and reimbursements to officers of DoT- regarding
The undersigned is directed to forward herewith a copy of Finance Division O.M. No. 9­
35/2017-18-Fin. dated 11.04.2018 on the subject cited above for information/necessary action.
2.
Further, it has been decided by the competent authority that provision of Mobile handset
reimbursement to all the eligible employees of DoT shall continue as per PHP Section OM No. 15­
2/2009-PHP II dated 30.3.2016 irrespective of their opting for Service Mobile Connections either
as per PHP Section order no. 3-1/2013-PHP dated 12.2.2013 or Finance Wing O.M. No. 9­
35/2017- 18-Fin. dated 11.4.2018.
3.
In case , eligible officers opt for telecom facilities in accordance with Finance Wing O.M.
No. 9-35/2017-18-Fin. dated 11.4.2018, they will be required to disconnect all their Service
telecom facilities from PHP Wing , DoT HQ and will have to produce disconnection orders of the
same to the concerned authority in order to avai l said telecom facility issued by Finance Wing ,
DoT.

4.

This issues with the approval of Competent Authority.

Encl: As above

Copy to :
(i)
(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)
(ix)
(x)
(xi)

PS to Hon'ble MOS(l/C), MOC
PPS to Secretary(T).
PPS to Spl. Secretary(T).
PPS to Member(S)/Member(F)/Member(T)/ DG(T), DoT, New Delhi
Advisor(T)/Advisor(O), Advisor(F) /Legal Advisor/Administrator, USOF/CVO DoT.
All Sr. DOG/DOG, DoT HQ.
DDG(C&A), DoT HQ.
All CCAs/ All LSAs.
Director(IT), DoT for uploading the circular on DoT website.
Guard file.
Office Copy

<!-- page 2 -->

No. 9-35/ 2017-18-Fin.

Government of India
Ministry of Communications
Department ofTeJecommunications
Sanchar Bhawan, 20, Ashok Road, New Delhi
Dated uth April, 2018.

OFFICE MEMORANDUM
Please find enclosed herewith Ministry of Finance, Department of Expenditure OM No,
71(3)/t:Cootd/:w18 dated 26.oy2018, wherein the meixiffi.um rnouthly reimbursable amount, towards
charges on Residential Telephone/Mobile Phone/ Broadband/Data Card use (for internet purposes),
are as under:

Rank/Desiiznation

Ceiling Amt. (Rs.)

Secretary to the GOI & equivalent rank
Additional Secretary to the GOJ & equivalent rank
Jt. Secretary to the GOI & equivalent rank
Director & Dy. Secretary to the GOI & equivalent rank
Below the rank of Dy. Secret.ary to the GOI (restricted to 25% of
sanctioned strength of Gr. 'A' Officers in a Ministry/
Depa rtment/Attached/Subordinate office)

1.

2.

..

3.
4·
5·

42oo+Applicabl~ Taxes
3ooo+AppJicabJe Taxes

27oo+Applicable Taxes
225o+Applicable Taxes

uoo+Aoolicable Taxes

2.
Eligible officers of Department of Telecom may now opt for either reimbursement of charges
on Residential Telephone/Mobile Phone/ Broadband/Data Card use (for internet purposes) Plan as
per Deptt. of Expenditure OM quoted above or to avail the facility provided by Department of
Telecom vide circular No. 3-1/2013-PHP dated 22.06.2016.
3.
In case officers opt to avail facilities according to Ministry of Finance circular vide para i
above they will have to surrender the Residential Telephone/Mobile Phone/ Broadband/Data Card
use (for internet purposes) facilities provided in accordance with DoT Circular No. 3-1/2013-PHP
dated 22.06.2016. While submitting their bills/receipts to the concerned DDOs (as per enclosed
annexure) for reimbursement as per DoE OM dated 26.03.2018, they will be required to furnish a
certificate to the effect that they are not availing Residential Telephone/Mobile Phone/
Broadband/Data Card use (for internet purposes) in accordance with the DoT circular No. 3-1/2013­

oil .

PHP dated 22.06.2016 as amended from time to time.

l A

4.

~

This issues with the approval of Secretary (T).

},

~

(Manish Kumar Gupta)
Director (Finance)
Copy to:
Sr. PPS to the Secretary (T),
2.. Sr. PPS to the Member (F)/Member (S)/Member (T),
3. Controller General of Communications Accounts,
4. Director General (Telecom)
5. Sr. PPS t:o the Adviser (F),
6. Sr. PPS to the Additional Secretary (T),
7. Sr. PPS to the Administrator, USOF,
8. PS to Jt. Secretary (A)/Jt. Secretary (T)
9. All Sr. Deputy Directors General, in DoT, HQ/TEC/NTIPRIT New Delhi,
10. Director General, NICF,
,di Utpi.il}' Ullt C Wr~ utlltldJ Jll l.J u J' i l~, i'< e \•. Uellu,
ii. . All Principal Controllers/Controllers of Communications Accounts in DoT,
i3. All Heads ofLSAs
i4. Under Secretary (SEA) for uploading on DoT Website/Guard File
i.

<!-- page 3 -->

Annexure
Government of India

Ministry of Communications
Department of Telecommum~ations

CLAIM FOR REIMBURSEMENT OF TELEPHONE CALL CHARGES OF RESIDENTJAL TET B>HONE
/MOBI.t.E./ BROADBAND I MOBILE DATA I DATAtAl{b

(Ministry of Finance, Dep.tt. .ofExpenditure OM No.24(3)/E.Coord/~018 dated ~6.Q3,~9yU .... __
fTo be submitted quarterly to Cash Section, DoT/Concerned DDO] .
i.

·Name ofAppficant

2.

Designation

·

3. Pay Level & Basic Pay :
4. P¢riod Cif Claim
5. Limit prescribed by
MoF OM per Month
6. .Amount Claimed
7. Leave.av.ailed I Training
un4e~g<;>ne, if,~y•.
d~ring the a"pv~..period

8. netails ofBills f
Receipts Attached
1 certify that I have not availed Residential Telephone/Mobile Phone/ Broadband/Data Card

use (for internet purposes) provided by Department of Telecom during the period ofthis claim.

Date

I

I

Signature ........................................... .
Name .................................... ,~ ........... .

<!-- page 4 -->

Page 1of3

F .No. 24(3)/E.Coord/2018

Ministry of Finance
Department of Expenditure

New Delhi, the 26 1h Mai ch 2018
OFFICE MEMORANDUM
Subje~t: - Provision of telephone facilities and reimbursements to officers of

Government of India.
Ttie Depoirtment of Expenditure has from time 10 time issued ins tructions on
provision of telephone facilities. monetary cei lings on rei mbursement to the officers of the
Government of India Given tl1e Increasi ng dependence on telecommunication
technology Including mobile telept:iones for carrying out official work . the e:xist1ng
instructions have l:Jeen comprehensively reviewed, revised and the following Instructions
are hereby circulated for compliance by all Ministry/Departments, ~!-!Rersessibn of all
earlier instructions Issued by this Department on the subject.

1. Official Telephones
1.1

All officers of the level of Deputy Secretary equivalent and above are
entitled for office te lephone with STD facillty. For officers of the level below
Deputy Secretary. MlnJstryJDepartments may decide in consultation with the
Financial Advisers on prov iding STD facility depenrJing on their functional
requirements.

1.2

ISD facility is allowed on official telephones in respect of Administrative
·
Secretaries only.

1.3

1.4

All other cases for providing ISO facility on official telephone for officers of
the level below Secretary to the Government of India may be decided by the
Administrative Secretary in consultation with the concerned Financial Adviser.
Administrative Secretary/ Head of Departme nts may in consultation with

lt)e concerned Financial Adviser provide officers below the· 1evel of Deputy
Slf'<.retary offlcial telephones with STD facility on functional basis. This facility
shou ld not be given in a routine man ner but extreme caution and austerity should
be exercised

1.5

Financial Advisors shall submit a half-yearly report to D/o Expenditure on
the number of ISO facility concurred/approved during a financial year.

2. Residential telephones
2.1

All officers of the level of Deputy Secretary equivalent and above are
entitled for one official residential landline telephone with STD facility.

2.2

Residential te lephone can be· allowed to officials below the rank of Deputy
Secretary equivalent on functional basis subject to the condition that this facility ·
shall be restricted to 25% of the sanctioned stre ngth of GroLtP 'A' officers in a
Ministry/Department. This limit w ill equa lly apply to Attached and Subordinate
offices.
·

. ----·-----·----------·-----­

<!-- page 5 -->

Page 2 of 3

2.3

ISO facility shall not be allowed on residential telepl1ones

2.4

Personal staff of Ministers [Private Secretary, Additional Private Secretary
and 1st PA of Ministry] and Administrative Secretary [Principal Staff Officer (PSO)/
Senior Principal Private Secretary/ Principal Private Secretary/Private Secretaryj,
Section Officer (Parliament) and Assistant Section Officer (Parliament) are entitled
to the facility of one residential landline telephone

3. Mobile Phone Handsets
Officers of the level of Secretary and equivalent will be entitled to
reimbursement for one mobile handset costing not more than Rs.25,000/­
(Rupees Twenty Five thousand only) once during the whole tenure. Global
roaming facility shall not be allowed on the mobile connection.

3.1

4. Reimbursement oftelephone call charges
4.1

Reimbursement of telephone call charges of residentia) telephone/ mobile
phone/broadband/mobile data/data card shall be as per entitlement given below:

; SI.
1 No.

Level/Des ignation

Limit on reimbursement

II

Secre tary to the Government of India and Rs.4200/- pe-rm onth + taxes as i
L_ eoujvaJerit
applica ble
level
i

i 2.

r-3.
4.

rs.

J

I

I

4.2
4.3

Additiona l Secretary to the Government

Rs . 3000/- per month + taxes as I

of India and eguival ent level

applicable

!

Joint S e ~reta ry to the Government of Rs. 2700/- per month + taxes as l
lndia~ nd ~ guivalent level
,__~ ll~~- -- · - - - - - - ,
to
tiie Rs. 2250/- per month + taxes as 1
Director/De puty
Secretary
_Gi>VE?..~.~m~n_~ o !J. nqi~ an.d equiva)ent level a_ppliqable
1
Below the rank of Deputy Secretary and Rs. 1200/- per month + taxes as t
equivalent to the Government of India applicable

---

~~

J

(rnstricted to 25% of the sanct;oned stcength

of Group 'A' officers in a Ministry/
_O eJ?C! rtme n tl~tt ac h ed/S u bord i m1te office)

J

No SIM/data-card will be provided by office.
There will be no separate ceiling for the landline/ mobile/broadband/mobile
data/data card. The amount reimbursable will cover /andline and I or mobile
/broadband/mobile data/data card connection and shall be limited to the ceiling

prescribed or as per actuals whichever is lower Call charges over and above the
ceiling prescribed along with taxes thereon shall be paid by tl1e officers
4.4

The amount shall be reimbursed on submission of bills/receipt by the
concerned officer Officers are at iiberty to choose the service provider and the
tariff package for residential landline/mobi/e phones.

4.5

In case where husband and wife are sharing the same residential landline
telephone and both are entitled for reimbursement, only one of them Will be
allowed reimbursement against the residential landline telephone. The claim for
mobile phone charges shall be treated separately for each of the officer subject
to the entitled ceiling.

4.6

1

Reimbursement for mobile will be restricted to the officer in whose name
the mobile connection is registered

<!-- page 6 -->

Page 3 of 3

4.7

The entitlement of an officer drawing pay in a scale intervening between
that of Director and Joint Secretary would be at par with that of Deputy
Secretary/Director.

4.8

Excess expenditure upto 30% of the ceiling amount (applicable to the
officer) can be reimbursed to officers of Joint Secretary equivalent and above
and also to Private Secretary/ Officers on Special Duty to the Ministers subject to
their submitting a certificate. duly justifyinq that excess exoenditure inciirred was
for ofticral purpose and unavoidable. This reimbursement would require the
concurrence of the Financial Adviser concerned and sanction of tt1e
Adrninistralive Secretary/ Secretary Equivaleni of trie Department/ Organization.
In so far as Secretary/ Secretary equivalent officer are concerned, tt1ey shall be
competent to exercise the aforesaid powers in their own cases The power to
sanction this expenditure shall not be delegated.

4.9

Telephone reimbursement will not be admissible 1n cases of Leave (of any
nature) and trainings which are for more than one calendar month (s).

5.

Mobile Facility during official visits abroad

5.1

Offieiafs and c:lelegations visiting abroad for the purpose of short official
vis1ts/meeting/conferences/workshops may be provided SIM card by our Mission I
Embassy In case SIM card ls not provided by our Mission I Embassy, there will
be a monetary ceiling of Rs .2000/- per d-ay for officer above tile level of Additional
Secretary and equivalent and Rs 1000/- per day for other officers towards
reimbursement of call charges

5.2

No mobile phone facility shall
whatsoever including training abroad.

6.

be

provided

during

training

period

These orders shall be effective from the date of issue of this Office
Memorandum

(H. Atheli)
Director
Tel. 011 - 2309 2604
To:

1 All Ministries/Departments of the Government of India
2. All Financial Advisers of Ministries/Department of the Government of India
3. Office of Comptroller & Auditor General of India

Copy to:
NIC Unit, Mio Finance with the request to upload the Office Memorandum on Department
of Expenditure website

.....

- -·-·--------..,,----- - - ­
