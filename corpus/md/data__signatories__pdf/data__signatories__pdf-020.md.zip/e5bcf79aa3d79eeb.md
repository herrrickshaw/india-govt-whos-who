---
doc_id: "e5bcf79aa3d79eeb"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/8d9dc6d8abe91b676c4bc52d313da72d.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Tools and Punches (Quality Control) Order, 2020"
date: "2025-07-01"
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "aed20b769f1835a7"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-04112020-222948
xxxGIDExxx
CG-DL-E-04112020-222948
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 3515]
No. 3515]

नई ददल्ली, बुधवार, नवम्बर 4, 2020/कार्ततक 13, 1942
NEW DELHI, WEDNESDAY, NOVEMBER 4, 2020/KARTIKA 13, 1942

वाजणज्य और उद्योग मंत्रालय
(उद्योग संवधधन और आंतररक व्यापार जवभाग)

आदेि
नई ददल्ली, 4 नवम्बर, 2020
का.आ. 3994(अ).—भारतीय मानक ब्यूरो अजधजनयम, 2016 (2016 का 11) की धारा 25 की उप-धारा (3) के
साथ परित धारा 16 की उप-धाराओं (1) और (2) द्वारा प्रदत्त िजियों का प्रयोग करते हुए, भारतीय मानक ब्यूरो से
परामिध करने के बाद कें द्र सरकार की राय है दक ऐसा करना िनजहत में आवश्यक है, अत: एतद्द्वारा जनम्नजलजखत आदेि
करती है, नामत:1.

संजिप्त िीर्धक और प्रारं भ - (1) इस आदेि को प्रेस टूल-पंजिज़ (गुणवत्ता जनयंत्रण) आदेि, 2020 कहा िाएगा।
(2) यह ददनांक 10.5.2021 से प्रभावी होगा।

2.
मानक जिह्न का अजनवायध प्रयोग- ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुएं या सामान उक्त ताजलका के कॉलम
(2) में उजल्लजखत तद्नुरूपी भारतीय मानक के अनुरूप होंगे तथा उनमें भारतीय मानक ब्यूरो (अनुपालन मूल्यांकन)
जवजनयम, 2018 की अनुसूिी-II की स्ट्कीम-I के अनुसार ब्यूरो के लाइसेंस के तहत मानक जिह्न लगा होगा:
बिते दक जनयाधत की िाने वाली वस्ट्तुओं या सामान पर इस आदेि से कु छ भी लागू नहीं होगा।
3.
प्रमाणन और प्रवतधन प्राजधकरण – भारतीय मानक ब्यूरो उि ताजलका के कॉलम (1) में जवजनर्ददष्ट वस्ट्तुओं या
सामान के संबंध में प्रमाणन और प्रवतधन प्राजधकरण होगा।
5388 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

ताजलका
वस्ट्तु या सामान

भारतीय मानक

भारतीय मानक का िीर्धक

(1)

(2)

(3)

प्रेस टू ल-पंजिज़

आईएस 4296 (भाग 1): 2016

प्रेससग के जलए औिार भाग 1 60 जडग्री कॉजनकल हेड और स्ट्रे ट िक
वाले राउं ड पंजिज़

आईएस 4296 (भाग 2): 2015

प्रेससग के जलए औिार भाग 2 जससलजिकल हेड और स्ट्रेट अथवा
ररड्यूस्ट्ड िक वाले पंजिज़

आईएस 4296 (भाग 3): 2015

प्रेससग के जलए औिार भाग 3 60 जडग्री कॉजनकल हेड और
ररड्यूस्ट्ड िक वाले राउं ड पंजिज़

नोट : इस ताजलका के प्रयोिन के जलए, भारतीय मानक ब्यूरो द्वारा समय-समय पर अजधसूजित दकए गए संिोधनों सजहत
भारतीय मानकों का नवीनतम संस्ट्करण, ऐसी अजधसूिना की तारीख से लागू होगा।
[फा. सं. पी-29026/2/2019-एलईआई]
अजनल अग्रवाल, संयुक्त सजिव
MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
ORDER
New Delhi, the 4th November, 2020
S.O. 3994(E).—In exercise of the powers conferred by sub-sections (1) and (2) of section 16 read
with sub-section (3) of section 25 of the Bureau of Indian Standards Act, 2016 (11 of 2016), the Central
Government, after consulting the Bureau of Indian Standards, is of the opinion that it is necessary or
expedient so to do in the public interest, hereby makes the following Order, namely:1. Short title, commencement. – (1) This Order may be called the Press Tool- Punches (Quality Control)
Order, 2020.
(2) It shall come into force with effect from 10.05.2021.
2. Compulsory use of Standard Mark.- Goods or articles specified in the column (1) of the Table shall
conform to the corresponding Indian Standard specified in column (2) of the said Table and shall bear the
Standard Mark under a license from the Bureau as per Scheme-I of Schedule-II of Bureau of Indian
Standards (Conformity Assessment) Regulations, 2018:
Provided that nothing in this Order shall apply to goods or articles meant for export.
3. Certification and Enforcement Authority.- The Bureau of Indian Standards shall be the certifying and
enforcing authority for the goods or articles specified in the column (1) of the said Table.
TABLE
Goods or articles
(1)
Press ToolPunches

Indian Standard
(2)
IS 4296 (Part 1): 2016
IS 4296 (Part 2): 2015
IS 4296 (Part 3): 2015

Title of Indian Standard
(3)
Tools for Pressing
Part 1 Round Punches with 60 Degrees
Conical Head and Straight Shank
Tools for Pressing
Part 2 Punches with Cylindrical Head
and Straight or Reduced Shank
Tools for Pressing
Part 3 Round Punches with 60 Degrees
Conical Head and Reduced Shank

Note: For the purposes of this Table, the latest version of Indian Standards including the amendments
issued thereof, as may be notified by the Bureau of Indian Standards from time to time, shall apply
from the date of such notification.
[F. No. P-29026/2/2019-LEI]
ANIL AGRAWAL, Jt. Secy.
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
CHAND
and Published by the Controller of Publications, Delhi-110054. KUMER
MEENA
Digitally signed by KUMER CHAND
MEENA
Date: 2020.11.04 20:04:40 +05'30'
