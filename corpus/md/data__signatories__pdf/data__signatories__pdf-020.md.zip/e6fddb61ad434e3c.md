---
doc_id: "e6fddb61ad434e3c"
source_url: "https://www.dst.gov.in/static/uploads/2025/10/4bcf37355d8fc6b97e9ca4388b356287.pdf"
ministry: "Department of Science and Technology (DST)"
title: "OM 04.09.2025"
date: "2025-09-04"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "302463054dd5c315"
---

<!-- page 1 -->

i,

tqffq lihfrdft$inirdq

rmn iful}fl)frrs1ftEr

idrmlflw, wq{trdryf
l.

I

T{mi 1lCC16

{?ifiifii

f t.itl, iel

jrilri?t :14 tirtij21?i

TT t:rr

,

lfii)tj?fii!,2iisijir/3
{[!0A.X r

00llrftllaffiitT0rlFlOlA

.

IJII\jISTRY {]F S(IIENCI ANO TICIII\IOLOGY

ilIPAfiIItiHNIOF $CIINCEANO TECiINOIO(]Y

?ti:rtJ!r,B 2651idli
I[Cl.lt'I0L0GYBl"lA\i[1t1,

Nr|tl fulfiliftIijli R0ACI

?6863rJ4i 2t]8U?419

NiI4/ D[1l-lr,11il 016

;-_--

';'.{r'l:'/,'iVf l)S l{; fWW.lSi COi tn

A-1 2Egg
/ O2l2023- E stt. I I !

Dated oY- o9 - 2-oL5
OFFICE MEMORANDUM

subject : uproading of the Advertisement

on the DST website-reg.
This Deoartmen-l is in the process, of
of 04 posrs of 'young Frot"r.ioriurl"ir'ir,e initiating the recruitment process for filling up
o"Gitfi".i o"t"b-qgnge and rechnorogy on
contract basis failing -as per tre aovliiisement
no. DST/05/zbzs-estt.til (copy encrosed).
The application oroiess'shall rturt
the date .1 p',ioii.riion of the advertisement
employment news/rozgar samachar.
in
Accordingiy, pro$;;ile appricants
are advised to
keep a warch on the ufcoming

ir#

2'

eoiti"r.

To facilitate

"tiri "";b6_E;in"*r.

l!9 qiospective app-licants, this Department shall publish a notice
on its website' after puotication'ot
tn. uir"rtisement inln6 emproyment hews, inoicating

the important dates ih reration t" uri

iipri.;ti;; ;;;i;J;; [ro.".r.

Encl: Advt.no. DST/05/2025_Estt.lil

\W

,r-*. Hfr?, srr{d F{mT{/Under s..r.t.,y(tffiffi:iJ#Jfl

f,sa,*ma TIIJIii;.ilJ

[iffi|]

;ffi l[11

To,

Dr. Rabindra K. panigrahy, Scientist ,E,

advertisement on the wnit's

& ErM, DST_ with a request to uproad
(;;l;b & ;ecruitment
the
ceil webpage
of the DST w6bsite.
