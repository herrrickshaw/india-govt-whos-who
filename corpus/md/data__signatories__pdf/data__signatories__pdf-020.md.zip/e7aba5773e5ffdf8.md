---
doc_id: "e7aba5773e5ffdf8"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/06/0567c6d10ac4d948d6d0170a1dfb1516.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Application for certified copy of registered design under section 17(2)"
date: "2025-06-30"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e991ce4f3d1fd51d"
---

<!-- page 1 -->

FORM 16
Fee Rs. 500

APPLICATION FOR CERTIFIED COPY OF THE
REGISTERED DESIGN
Section 17 (2)

1

Insert name, address

and nationality.

I/we1 _____________________________________________
__________________________________________________
hereby request you to furnish me (or us) a certified copy of the
following design.

2

Insert number and

of design.
3

Insert the name of

Design No.2 ______________________ Class ___________ class
In the name of 3 ___________________________________
_________________________________________________

proprietor of the Design.
My/Our address for service in India is:
________________________________________________
________________________________________________
Dated this _________________ day of ____________ 2000
4

To be signed by the
applicant(s) or
authorised agent.

(Signed)4 _______________________________________

TO
THE CONTROLLER OF DESIGN,
THE PATENT OFFICE, CALCUTTA.
