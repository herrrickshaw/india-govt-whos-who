---
doc_id: "e8727eb2aece9b2f"
source_url: "https://dof.gov.in/static/uploads/2025/09/0b9bdeba96a12622eb020fc006cab7e4.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Vacancy Circular for recruitment to the post of Joint Commissioner (Fisheries) in Level-13 in Department of Fisheries (03-06-2024)"
date: "2024-06-03"
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5193ee2a9fbd1876"
---

<!-- page 1 -->

<!-- page 2 -->

ANNEUXURE-I
BIO-DATA/CURRICULUM VITAE PROFORMA
1. Name and Address (in Block
Letters)
2. Date of Birth (in Christian era)
3.i) Date of entry into service
ii) Date of retirement under
Central/State Government Rules
4. Educational Qualifications
5. Whether Educational and
other qualifications required for
the post are satisfied. (if any
qualification has been treated as
equivalent to the one prescribed
in the Rules, state the authority
for the same)
Qualifications/ Experience required as Qualifications/experience possessed by the
mentioned in the advertisement/vacancy officer
circular
Essential
Essential
A) Qualification
A) Qualification
B) Experience
B) Experience
Desirable
Desirable
A) Qualification
A) Qualification
B) Experience
B) Experience
5.1 Note: This column needs to be amplified to indicate Essential and Desirable
Qualifications as mentioned in the RRs by the Administrative Ministry/Department/Office at
the time of issue of Circular and issue of Advertisement in Employment News.
5.2 In the case of Degree and Post Graduate Qualification Elective/main subjects and
subsidiary subjects may be indicated by the candidate.
6. Please state clearly whether in the light of
entries made by you above, you meet the
requisite Essential Qualifications and work
experience of the post.
6.1 Note: Borrowing Departments are to provide their specific comments/views confirming
the relevant Essential Qualification/ Work experience possessed by the Candidate (as
indicated in the Bio-data) with reference to the post applied.

<!-- page 3 -->

7. Details of Employment, in chronological order. Enclose a separate sheet duly
authenticated by your signature, if the space below is insufficient.
Office/Institution Post held on From
regular basis

To

*Pay Band and
Grade
Pay/Pay
Scale of the post
held on regular
basis

Name
of
Duties (in
details)
highlighting
experience
required for
the
post
applied for

*Important: Pay-band and Grade Pay granted under ACP/MACP are personal to the officer
and therefore, should not be mentioned. Only Pay Band and Grade Pay/Pay Scale of the
post held on regular basis to be mentioned. Details of ACP/MACP with present pay Band
and Grade Pay where such benefits have been drawn by the Candidate, may be indicated as
below;
Office/Institution

Pay, Pay Band, and From
grade pay drawn
under
ACP/MACP
Scheme

8. Nature of present
employment
i.e,
Adhoc or Temporary
or Quasi-Permanent
or Permanent
9. In case the present
employment is held on
deputation/ contract
basis, please statea) The date of initial b)
Period
of c) Name of the
appointment
appointment
on parent
deputation/contract office/Organization
to
which
the
applicant belongs.
9.1 Note: In case of Officers already on deputation, the applications
of such officers should be forwarded by the parent
cadre/Department along with Cadre Clearance, Vigilance Clearance
and Integrity Certificate.

To

d) Name of the post
and Pay of the post
held in substantive
capacity
in
the
parent organization

<!-- page 4 -->

9.2 Note: Information under Column 9(c) & (d) above must be given
in all cases where a person is holding a post on deputation outside
the cadre/organization but still maintaining a lien in his parent
cadre/ organization.
10. If any post held on Deputation in the past by the applicant, date
of return from the last deputation and other details.
11. Additional details about present employment:
Please state whether working under (indicate the name of your
employer against the relevant column)
a. Central Government
b. State Government
c. Autonomous Organization
d. Government Undertaking
e. Universities
f. Others
12. Please state whether you are working in the same Department
and are in the feeder grade or feeder to feeder grade.
13. Are you in revised Scale of Pay? If yes, give the date from which
the revision took place and also indicate the pre-revised scale
14. Total emoluments per month now drawn
Basis pay in the PB
Grade Pay
Total Emoluments

15. In cases the applicant belongs to an Organisation which is not following the Central
Government Pay-Scales, the latest salary Slip issued by the Organisation showing the
following details may be enclosed.
Basic Pay with scale of Dearness Pay/interim relief / other Total Emoluments
pay
and
rate
of Allowances etc., (with break-up
increment
details)

16. A Additional information, if any, relevant to the post you
applied for in support of your suitability for the post.
(This among other things may provide information with regard
to (i) additional academic qualifications (ii) Professional training
and (iii) work experience over and above prescribed in the
vacancy Circular/Advertisement)
(Note: Enclose a separate sheet, if the space is insufficient)
16. B Achievements:
The candidates are requested to indicate information with
regard to;
(i) Research publications and reports and special projects
(ii) Awards/Scholarships/Official Appreciation
(iii) Affiliation with the professional bodies/institutions
/societies and;
iv) Patents registered in own name or achieved for the

<!-- page 5 -->

organization
(v) Any research/ innovative measure involving official
recognition vi) any other information.
(Note: Enclose a separate sheet if the space is insufficient)
17. Please state whether you are applying for deputation
(ISTC)/Absorption/Re-employment Basis. #(Officers under
Central/State Governments are only eligible for “Absorption”.
Candidates of non-Government Organizations are eligible only
for Short Term Contract)
# (The option of ‘STC’ / ‘Absorption’/’Re-employment’ are
available only if the vacancy circular specially mentioned
recruitment by ‘STC’ or “Absorption” or “Re-employment”).
18. Whether belongs to SC/ST
I have carefully gone through the vacancy circular/advertisement and I am well
aware that the information furnished in the Curriculum Vitae duly supported by the
documents in respect of Essential Qualification/Work Experience submitted by me will also
be assessed by the Selection Committee at the time of selection for the post. The
information / details provided by me are correct and true to the best of my knowledge and
no materials fact having a bearing on my selection has been suppressed/withheld.

(Signature of candidate)
Address-----------------------------------------------------------Date----------------------

<!-- page 6 -->

Certification by the Employer/Cadre Controlling Authority
The information /details provided in the above application by the applicant are true
and correct as per the facts available on records. He/she possesses educational
qualifications and experience mentioned in the vacancy Circular. If selected, he/she will be
relieved immediately.
2.

Also certified that;

i)
There
is no vigilance or disciplinary case pending/contemplated against
Shri/Smt.___________________
ii)

His/Her integrity is certified.

iii)
His/Her CR Dossier in original is enclosed / photocopies of the ACRs for the last 5
years duly attested by an officer of the rank of Under Secretary of the Govt. of India or
above are enclosed.
iv)
No major/minor penalty has been imposed on him/her during the last 10 years Or A
list of major/minor penalties imposed on him/her during the last 10 years is enclosed. (as
the case may be)

countersigned

_______________________________________
(Employer/cadre controlling authority with seal)
