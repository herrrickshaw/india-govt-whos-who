---
doc_id: "e8650b7e5de1bbce"
source_url: "https://dohe-education.gov.in/static/uploads/2026/05/0c4fe43e8c8cf1040493d08bda6a1773.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Vice-Chancellor of CSU, Delhi"
date: "2026-06-01"
pages: 4
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "14c1298a9eb1d395"
---

<!-- page 1 -->

No.1-1/2026-Skt.II
GOVERNMENT OF INDIA
MINISTRY OF EDUCATION
DEPARTMENT OF HIGHER EDUCATION
wake
we
Dated the.2s May, 2026
Advertisement No.01/2026
Appointment of Vice-Chancellor of Central Sanskrit University, Delhi
Applications are invited for the post of Vice-Chancellor of Central Sanskrit University, Delhi. The
Vice-Chancellor, being the academic as well as administrative head, is expected to be:
i. An eminent scholar in the field of Sanskrit and allied subjects and his qualifications
shall be as specified in the regulations made under the University Grants Commission
Act, 1956 (3 of 1956) in this behalf.

ii. Preferably not more than 65 years of age as on the closing date of receipt of
applications of this advertisement.

iii. A person possessing the highest level of competence, integrity, morals and
institutional commitment.

iv. Adistinguished academician, with a minimum of 10 years' experience as Professor in a
University or 10 years' experience in a reputed research and/or academic
administrative organization with proof of having demonstrated academic leadership.

Salary and Service Conditions
« The post carries a pay of Rs. 2,10,000/- (Fixed) per month with Special Allowance of Rs.
11,250/- and other usual allowances.
* The other terms and conditions of the services will be those as set forth in the Central
Sanskrit Universities Act, 2020 and Statutes and Ordinances of the University.
Procedure for appointment
* Appointment will be made from a panel of three names recommended by a Selection
Committee in accordance with the procedure laid down in the Central Sanskrit
Universities Act, 2020.
Submission of Application
* The advertisement is available on the websites https://www.education.gov.in and
https://www.sanskrit.nic.in/

<!-- page 2 -->

* Candidates are required to "APPLY ONLINE ONLY" on the Ministry of Education
SAMARTH portal as per the link given below:

https://vcrec.samarth.ac.in/index.php/

« The Ministry will not be responsible for the delay in receipt of applications for
whatever reasons it maybe.

* The persons who are already in service should apply through proper channel and
submit their applications through their employer alongwith the NOC/ Vigilance
Clearance Report given by the Chief Vigilance Officer of their Institutions/
Department alongwith the applications.

« Incomplete applications/ applications received after the last day for receipt of
applications will not be considered.

* The above link will be active from 1° June, 2026, 10:00 Hours to 307 June, 2026,

17:00 Hours.
0८८८ के
a
we Saumy. oF in)
Deputy Secretary to the Government of India
Tel No.: 23070182

<!-- page 3 -->

W.1-1/2026-GaHA. IT
भारत सरकार
शिक्षा मंत्रालय
उच्चतर शिक्षा विभाग
दिनांक 2 मई, 2026
विज्ञापन सं.01/2026
केन्द्रीय संस्कृत विश्वविद्यालय, दिल्‍ली के कुलपति की नियुक्ति
केंद्रीय संस्कृत विश्वविद्यालय, दिल्‍ली के कुलपति पद के लिए आवेदन आमंत्रित किए गए
हैं। शैक्षणिक के साथ-साथ प्रशासनिक प्रमुख होने के कारण कुलपति से निम्नलिखित अपेक्षाएं
की जाती है:

1. संस्कृत और संबद्ध विषयों के क्षेत्र में एक प्रतिष्ठित विद्वान और उसकी अहर्ताएं
विश्वविद्यालय अनुदान आयोग अधिनियम, 1956 (1956 का 3) के तहत बनाए गए
विनियमों में यथा विनिर्दिष्ट अहर्ताएं होंगी।

1. इस विज्ञापन में आवेदन प्राप्ति की अंतिम तिथिपर 65 वर्ष की आयु से अधिक का नहीं
होना वांछनीय।

॥#. सर्वोच्चस्तर की सक्षमता, सत्यनिष्ठा, नैतिकता और संस्था के प्रति प्रतिबद्धता संपन्‍न
व्यक्ति।

iv एक प्रतिष्ठित शिक्षाविद, जिसे विश्वविद्यालय में प्रोफेसर के रूप में न्यूनतम 10 वर्ष या
प्रतिष्ठित अनुसंधान और/ या शैक्षणिक संगठन में प्रशासनिक नेतृत्व का प्रदर्शन करने
के प्रमाण के साथ 10 वर्ष का अनुभव हो।

वेतन और सेवा शर्तें:

+ पद पर प्रतिमाह वेतन 2,10,000/- रुपये (नियत) और 11,250/- रुपये का विशेष

भत्ता और अन्य सामान्य भत्ते देय होगा।

<!-- page 4 -->

*« सेवाओं के अन्य नियम और शर्तें, केंद्रीय संस्कृत विश्वविद्यालय अधिनियम, 2020 और
विश्वविद्यालय की संविधियों और अध्यादेश में निर्धारित के अनुसार होंगी।

नियुक्ति की प्रक्रिया:

* केंद्रीय संस्कृत विश्वविद्यालय अधिनियम, 2020 में निर्धारित प्रक्रिया के अनुसार चयन
समिति द्वारा अनुशंसित तीन नामों के पैनल से नियुक्ति की जाएगी।

आवेदन जमा करना:

« विज्ञापन वेबसाइट #95://४५४७४.९४७८४४०71.४०७.॥। और https://www.sanskrit.nic.in/
पर उपलब्ध है।

*« उम्मीदवारों को नीचे दिए गए लिंक के अनुसार शिक्षा मंत्रालय के समर्थ पोर्टल पर
"केवल ऑनलाइन आवेदन" करना होगा:

https://vcrec.samarth.ac.in/index.php/

*_ मंत्रालय किसी भी कारण से आवेदन प्राप्त होने में विलंब के लिए उत्‌तरदायी नहीं
होगा।

+ ot cafe cect से ही सेवारत हैं, उन्हें उचित माध्यम से आवेदन करना चाहिए और
अपने संस्थान/विभाग के मुख्य सतर्कता अधिकारी द्वारा दिया गया अनापत्ति प्रमाण-
पत्र/सतर्कता निकासी रिपोर्ट के साथ अपने नियोक्ता के माध्यम से अपना आवेदन जमा
करना चाहिए।

*« अपूर्ण आवेदनों /आवेदन प्राप्ति की अंतिम तिथि के बाद प्राप्त आवेदनों पर विचार नहीं
किया जाएगा।

+ उपरोक्त लिंक दिनांक ॥ जून, 2026, 10:00 बजे से दिनांक 30 जून, 2026, 17:00
बजे तक सक्रिय रहेगा। Weg

a ar
(डॉ. सौम्य
उप सचिव, भारत सरकार
टेलीफोन नंबर: 23070182
