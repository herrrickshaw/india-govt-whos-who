---
doc_id: "e92f47feed72fd3c"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/0783258b36ba11ec85ed59aa27fd68de.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Inviting comments on proposed amendments to the Telecommunications Engineering Service (Group 'B' Posts) Recruitment Rules, 2019-regarding"
date: "2026-05-14"
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aed98cbedbd0fd55"
---

<!-- page 1 -->

3-11(01)/2021-Estt(RR)/
TES.

1/3398130/202

F. n0.9-11(01)/2021-Estt.(RR)/TES

Government of India
Ministry of Communications
Department of Telecommunications
(Establishment Wing)

Sanchar Bhawan
20, Ashoka Road, New Delhri‘- 110 001

Dated |2 May 2026
Office Memorandum
Subject: Inviting comments on proposed amendments to the Telecommunications Engineering
Service (Group ‘B’ Posts) Recruitment Rules, 2019 — regarding
The undersigned is directed to place on the website of the Department of
Telecommunications a draft of amendments proposed to the Telecommunications Engineering
Service (Group ‘B’ Posts) Recruitment Rules, 2019 in respect of the posts of Junior Telecom
Officer and Sub-Divisional Engineer, for inviting comments/inputs from stakeholders. The
details of the proposed amendments are placed at Annexure.
2.

All stakeholders are requested to furnish their comments/inputs, if any, on the proposed

amendments to the undersigned at the email address adetestt-dot@gov.in within 30 days from

the date of issue of this Office Memorandum.
Encl.: as above

%"‘1[/&["
(Pravin Kumar Singh)
Assistant Divisional Engineer (Telecom)

Tel: 011 2303 6707
Email: adetestt-dot@gov.in
To:
All stakeholders concerned (through the website of Department of Telecommunications)
Copy to:
1. Member

(Services),

Digital

Communications

Commission,

Department

of

Telecommunications
2. Deputy Director General (Establishment), Department of Telecommunications
3. Director, Information Technology Cell,
uploading on the website of the Department

Department

of Telecommunications,

for

<!-- page 2 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)Y/TES, dated 13.5.2026

Tabular statement regarding the proposed amendments to the Ministry of Communication:
Department of Telecommunications, Telecommunications Engineering Service (Group ‘B’
Posts) Recruitment Rules, 2019 (“Rules”)
Proposed amendments to the Rules
Rule

.

number
4.

-

Proposed

Existing provision

.

provision

Service under Territorial Army.— Persons appointed to the said
posts, who has not completed the age of forty years shall if so
required, be liable to serve in the Territorial Army subject to the
provisions of section 6 A of the Territorial Army Act, 1948 (56 of

[Omitted]

1948) and the rules made there under.

3.

Liability for Transfer.—Persons appointed to the said posts shall
be liable to transfer anywhere in India.

[Omitted]

Proposed amendments to the Schedule to the Rules
1. Name of Post: Sub-Divisional Engineer
Column
nil:ln:::r

Column heading

Existing provision

Proposed provision

Schedule

?2)

Number of Posts

364" (2018) "Subject to
254" (2026) "Subject to
variation dependent on
variation dependent on
workload.
workload.
(10) | Method of
Ten per cent. by promotion
Twenty per cent. by
Recruitment, whether | failing which by deputation
promotion failing which
by direct recruitment | including short-term contract., | by deputation including
or by promotion or by | Ninety per cent. by deputation | short-term contract.
deputation/absorption | (including short-term
Eighty per cent. by
and peltcentage of the contracl)- or re-employment of deputation (including

vacamfles to be filled | Ex-Servicemen.

short-term contrac) or re-

by various methods

employment of Armed
Forces Personnel.
Promotion:
Junior Telecom Officer of
the Department of
Telecommunications in
Level 7 in the pay matrix

(11) | In case of recruitment | Promotion:
by promotion or
Junior Telecom Officer of
deputation/
Department of
absorption, grades
Telecommunications in
from which promotion Level 7 in the pay matrix (Rs.:
or deputation/
44900-142400) with 2 years
absorption to be made regular service and who have
successfully completed two

Yo

Page 1 of 12

(344,900-1,42,400) with 2
years’ regular service and
who have successfully
completed two weeks’

<!-- page 3 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

weeks prescribed in-service
Training.
Note: Where juniors who have
completed their qualifying or
eligibility service are being
considered for promotion, their
seniors shall also be considered
provided they are not short of
the requisite qualifying or
eligibility service by more than
half of such qualifying or
eligibility service or two years,

prescribed in-service
training.
Note 1: Where juniors
who have completed their
qualifying or eligibility
service are being

whichever is less, and have

than half of such

successfully completed their
probation period for promotion
to the next higher grade along
with their juniors who have
already completed such
qualifying or eligibility
service.

qualifying or eligibility

Deputation (including short
term contract):

Officers from the Central or
State Governments or Union
Territories or Public Sector
Undertakings or Universities
or Recognised Research
Institutions or Statutory and
Autonomous bodies:
(a)(i) holding analogous posts

on regular basis in the parent

considered for promotion,

their seniors shall also be
considered provided they
are not short of the
requisite qualifying or
eligibility service by more

service or two years,
whichever is less, and

have successfully
completed their probation
period for promotion to
the next higher grade
along with their juniors
who have already
completed such qualifying
or eligibility service.
Deputation (including
short term contract):

Officers from the Central
or State Governments or
Union Territories or
Public Sector
Undertakings or
Universities or
Recognised Research
Institutions or Statutory
and Autonomous bodies:

cadre or department; or
(ii) with two years service in
the level rendered after
appointment thereto on a
regular basis in posts in level-7
(a)(i) holding analogous
(Rs. 44900-142400) in the pay
posts on regular basis in
matrix or equivalent in the
the parent cadre or
parent cadre or department; or
department; or
(iii) with six years service in
(ii) with two years’
the level rendered after
service in the level
appointment to the post on a
rendered after
regular basis the level-6 (Rs.
appointment thereto on a

W

Page 2 of 12

<!-- page 4 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

35400-112400) in the pay
matrix or equivalent in the
parent cadre or department;
and
(b) possessing the following
educational qualifications and
experience:
1. (i) Bachelor degree in
Engineering or Technology in
Electrical or Electronics or
Electrical Communication or
Computer Science or

Telecommunications or
Information Technology or
Instrumentation from a
University incorporated by an
Act of the Central or State
Legislature in India or other
Educational Institutes
established by an Act of
Parliament or declared to be
deemed as University under
Section 3 of the University
Grants Commission Act, 1956;

or (ii) passed Sections A and B
of the Institution Examinations
of the Institution of Engineers
(India); or

(iii) obtained a Degree or
Diploma in Engineering, from
such foreign University or
College or Institution and
under such conditions as may
be recognised by the
Government for the purpose
from time to time; or

(iv) passed Graduate
Membership Examination of
the Institution of Electronics
and Telecommunication
Engineers (India); or

flort—

Page 3 of 12

regular basis in posts in
level-7 (344,900~
1,42,400) in the pay

matrix or equivalent in the
parent cadre or
department; or

(iii) with six years’ service
in the level rendered after
appointment to the post on
aregular basis the level-6

(%35,400-1,12,400) in the
pay matrix or equivalent
in the parent cadre or
department; and
(b) possessing the
following educational
qualifications and
experience:
(1) Bachelor degree in
Engineering or
Technology in Electrical
or Electronics or

Electrical
Communications or
Electronics

Communications or
Computer Science or
Telecommunications or

Information Technology
or Instrumentation from
a recognised University or
Institute.
Note 2: The candidates,

who have passed Sections
A and B of the Institution
Examinations of the
Institution of Engineers
(India) or passed Graduate

Membership Examination
of the Institution of
Electronics and
Telecommunication
Engineers

<!-- page 5 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

(v) passed Graduate
Membership Examination of
the Institution of Electronics
and Radio Engineers, London

(India) or passed
Associate Membership
Examination Parts IT and

held after November, 1959; or

the Aeronautical Society
of India, who were
enrolled with the said
institutions upto the 31%

(vi) passed Associate
Membership Examination
Parts II and III or Sections A
and B of the Aeronautical
Society of India; and

III or Sections A and B of

May, 2013, shall also be

eligible.

(2) Two years’ experience
2. Two year experience in field
in field of
of Telecommunications and
Telecommunications or

Administration.

Note 1: The departmental
officers in the feeder grade
who are in the direct line of
promotion shall not be eligible
for consideration for
appointment on deputation.
similarly, the deputationists
shall not be eligible for
consideration for appointment

by promotion.
Note 2: the period of
deputation including period of
deputation in another ex-cadre
post held immediately
preceding this appointment in
the same or some other

organisation or department of
the central government shall
ordinarily not to exceed 3
years. The maximum age-limit
for appointment by deputation
shall be not exceeding 56 years
as on the closing date on
receipt of applications.
For Ex-Servicemen:
Deputation or ReEmployment: The armed
forces personnel of the rank of

Yo"

Page 4 of 12

Administration or
Electronics or Information
Technology or Cyber
Security or Information
and Communication
Technology.
Note 3: The departmental
officers in the feeder
grade who are in the direct
line of promotion shall not
be eligible for

consideration for
appointment on
deputation. Similarly,
deputationists shall not be
eligible for consideration
for appointment by
promotion.
Note 4: The period of
deputation, including
period of deputation in
another ex cadre post held
immediately preceding
this appointment in the
same or some other
organisation or
department of the Central
Government, shall

ordinarily not to exceed 3

<!-- page 6 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

Subedar-Major (level 8),
Subedar (level 7 and NaibSubedar (level 6) or equivalent
rank in Air Force or Navy who
are due to retire or to be
transferred to reserve within a
period of one year and have the
qualifications and experience
as prescribed as above shall
also be considered. If selected,

such officers will be given
deputation terms up to the date
on which they are due for
release from the armed forces;

thereafter they may be
continued on re-employment

terms.

years. The maximum agelimit for appointment by
deputation shall be not
exceeding 56 years as on
the closing date on receipt
of applications.

Re-employment of
Armed Forces
Personnel:
The armed forces
personnel of the rank of
Subedar-Major (level 8),
Subedar (level 7 and
Naib-Subedar (level 6) or
equivalent rank in Air
Force or Navy who are
due to retire or to be

transferred to reserve
within a period of one
year and have the
qualifications and
experience as prescribed

as above shall also be
considered. If selected,

such officers will be given
deputation terms up to the
date on which they are
due for release from the
armed forces; thereafter

they may be continued on
re-employment terms.
(12) | If a Departmental
1. Group ‘B’ Departmental | 1. Group ‘B’
Promotion Committee | Promotion Committee
Departmental Promotion
exists, what is its

Composition

o

consisting of:

Committee, consisting of:

1. Advisor, Department | (1) Advisor, Department
of
of
Telecommunications —
Telecommunications
Chairman
— Chairperson
2. Deputy
Director | (2) Deputy Director
General, Department
General, Department
of
of
Page 5 of 12

<!-- page 7 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

Telecommunications —
Member
3. Director, Department
of
Telecommunications —
Member

Telecommunications
—Member
(3) Director, Department
of
Telecommunications —
Member

2. Group ‘B’ Departmental

Confirmation Committee
(for considering
confirmation of Ex-

2. Group ‘B’

Serviceman) consisting of:

Committee (for

I: Advisor, Department of

Departmental
Confirmation
considering confirmation

Telecommunications — | °f Armed Forces
Chaitman
Personnel), consisting of:
2. Deputy
Director | (1) Advisor, Department
General, Department of
of Telecommunications

Telecommunications —
Member

3. Director, Department of
Telecommunications —

Member

(13) | Circumstances in
which UPSC to be
consulted in making
recruitments

Consultation with Union
Public Service Commission
necessary while appointing an
officer on deputation
(including short term contract)
or re-employment basis.

Qo

Page 6 of 12

— Chairperson
(2) Deputy Director

General, Department of]
Telecommunications

— Member
(3) Director, Department
of Telecommunications
— Member
Consultation with Union
Public Service
Commission is not
necessary.

<!-- page 8 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

Name of Post: Junior Telecom Officer
Column
pamiber in
the
Schedule
?2)

(@)

Column
heading

Existing provision

Proposed provision

Number of Posts | 106" (2018) "Subject to variation | 107" (2026) "Subject to
dependent on workload.
variation dependent on
workload.
Educational and | Essentials:
Essentials:
other
Qualification
required for
direct recruits

Bachelor degree in Engineering | Bachelor
degree
in
Engineering or Technology
or Technology in Electrical or
in Electrical or Electronics or
Electronics or Electrical
Electrical Communication or
Communication or Computer
Electronics Communication
Science or Telecommunications
or Computer Science or
or Information Technology or
Telecommunications
or
Instrumentation from a
Information Technology or
University incorporated by an
Instrumentation
from
a
Act of the Central or State
recognised
University or
Legislature in India or other
Institute.
Educational Institutes
Note 1: The candidates, who
established by an Act of
have passed Sections A and
Parliament or declared to be
B
of
the
Institution
deemed as University under
Examinations
of
the
Section 3 of the University
Institution
of
Engineers
Grants Commission Act, 1956;

or passed Sections A and B of

(India) or passed Graduate
Membership Examination of

the Institution of Electronics
the Institution Examinations of
and
Telecommunication
the Institution of Engineers
(India); or obtained a Degree or Engineers (India) or passed
Associate
Membership
Diploma in Engineering, from
Examination
Parts
II and IIT
such foreign University or
or Sections A and B of the
College or Institution and under
Aeronautical ~ Society
of
such conditions as may be
India, who were enrolled
recognised by the Government
with the said institutions up
for the purpose from time to
to the 31% May, 2013 shall
time; or passed Graduate
also be eligible.
Membership Examination of the
Note 2: Qualifications are
Institution of Electronics and
relaxable at the discretion of
Telecommunication Engineers
the Union Public Service
(India); or passed Graduate
Commission in case of
Membership Examination of the
candidate otherwise well
Institution of Electronics and
qualified.
Radio Engineers, London held

hor—"

Page 7 of 12

<!-- page 9 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

after November, 1959: or passed
Associate Membership
Examination Parts I and III or
Sections A and B of the
Aeronautical Society of India or
any other qualification which
has been recognized by the
Government in consultation with
the Union Public Service
Commission for the purpose of
admission to the Engineering
Services Examination.
Note 1: Qualifications are

Note 3: The qualification(s)
regarding experience is/are
relaxable at the discretion of
the Union Public Service
Commission, for reasons to

be recorded in writing in the
case of candidates belonging
to Scheduled Castes or
Scheduled Tribes if at any
stage of selection the Union
Public Service Commission,

is of the opinion that
number
of
relaxable at the discretion of the sufficient
candidates
from
these
Union Public Service
Commission in case of candidate communities possessing the
requisite experience are not
otherwise well qualified.
likely to be available to fill up
Note 2: The qualification(s)
the vacancies reserved for
regarding experience is/are
relaxable at the discretion of the them.
Union Public Service
Commission, for reasons to be

recorded in writing in the case of
candidates belonging to
Scheduled Castes or Scheduled
Tribes if at any stage of
selection the Union Public
Service Commission, is of the

©)

Period of

opinion that sufficient number of
candidates from these
communities possessing the
requisite experience are not
likely to be available to fill up
the vacancies reserved for them.
Two years.
Two years, for direct recruits.

Probation, if any:

(10)

Method of
Recruitment

By direct recruitment.

80 per cent by direct
recruitment.
20 per cent by promotion,
failing which by deputation
(including short-term
contract).

ot

Page 8 of 12

<!-- page 10 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

an

In case of
recruitment by
promotion or
deputation/

Not applicable.

Promotion:
Junior Engineer (Telecom)
officers of the Department of

Telecommunications in

absorption,

Level 6 in the pay matrix

grades from
which promotion
or deputation/
absorption to be
made

(%35,400-1,12,400) with 5
years’ regular service and
who have successfully
completed two weeks”
prescribed in-service
training.
Note 1: Where juniors who
have completed their
qualifying or eligibility
service are being considered
for promotion, their seniors
shall also be considered,

provided they are not short
of the requisite qualifying or
eligibility service by more
than half of such qualifying
or eligibility service or two
years, whichever is less, and

have successfully completed
their probation period for
promotion to the next higher
grade along with their
juniors who have already
completed such qualifying or
eligibility service.
Deputation (including
short- term contract):
Officers from the Central or
State Governments or Union
Territories or Public Sector
Undertakings or Universities
or Recognised Research
Institutions or Statutory and
Autonomous bodies:
(a)(i) holding analogous
posts on regular basis in the

o

Page 9 of 12

<!-- page 11 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

parent cadre or department;

or
(ii) with five years’ service

in the level rendered after
appointment thereto on a
regular basis in posts in

level-6 (% 35,400-1,12,400)
in the pay matrix or
equivalent in the parent
cadre or department; and

(b) possessing the following
educational qualifications
and experience:
(1) Bachelor degree in
Engineering or Technology

in Electrical or Electronics
or Electrical
Communications or
Electronics Communications
or Computer Science or
Telecommunications or
Information Technology or

Instrumentation from
a recognised University or
Institute.
Note 2: The candidates, who

have passed Sections A and

B of the Institution
Examinations of the
Institution of Engineers
(India) or passed Graduate
Membership Examination of
the Institution of Electronics
and Telecommunication
Engineers (India) or passed
Associate Membership
Examination Parts IT and IIT
or Sections A and B of the
Aeronautical Society of
India, who were enrolled

with the said institutions

fho”

Page 10 of 12

<!-- page 12 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

upto the 31 May, 2013,
shall also be eligible.
(2) Two years’ experience in
field of Telecommunications
or Administration or

Electronics or Information
Technology or Cyber
Security or Information and
Communication
Technology.
Note 3: The departmental
officers in the feeder grade
who are in the direct line of
promotion shall not be
eligible for consideration for
appointment on deputation.
Similarly, deputationists
shall not be eligible for
consideration for
appointment by promotion.
Note 4: The period of
deputation including period

of deputation in another ex
cadre post held immediately
preceding this appointment
in the same or some other
organisation or department
of the Central Government,

(12)

Ifa

Group ‘B’ Departmental

Departmental
Promotion
Committee

Confirmation Committee,

consisting of:
(1) Senior Deputy Director
exists, what is its
General, Department of
Composition
Telecommunications —
Chairman

W

Page 11 of 12

shall ordinarily not to exceed
three years. The maximum
age-limit for appointment by
deputation shall be not
exceeding 56 years as on the
closing date for receipt of
applications.
1. Group ‘B’
Departmental
Confirmation Committee,

consisting of:
(1) Senior Deputy Director
General, Department of
Telecommunications —
Chairperson

<!-- page 13 -->

Annexure to DoT OM no. 9-11(01)/2021-Estt. (RR)/TES, dated 13.5.2026

(2) Deputy Director General,

Department of
Telecommunications —
Member
(3) Director, Department of
Telecommunications —

Member

(2) Deputy Director General,
Department of

Telecommunications —
Member
(3) Director, Department of
Telecommunications —
Member
2. Group ‘B’
Departmental Promotion

Committee, consisting of:
(1) Senior Deputy Director
General, Department of

Telecommunications —
Chairperson
(2) Deputy Director General,
Department of
Telecommunications —
Member
(3) Director, Department of
Telecommunications —
Member
sk

Page 12 of 12
