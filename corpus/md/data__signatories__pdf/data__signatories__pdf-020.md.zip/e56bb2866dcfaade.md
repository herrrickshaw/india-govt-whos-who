---
doc_id: "e56bb2866dcfaade"
source_url: "https://doj.gov.in/static/uploads/2025/09/104f730114eb415044f783e87f9667f4.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Justice Chakradhari Sharan Singh, Judge, Patna HC as Chief Justice of Orissa High Court (02.02.2024)"
date: "2024-02-02"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f121d110903b5f4c"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)

No. K-13027/02/2023-USJI
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisahner House, 26, Man Singh Road,
New Delhi-110 011, Dated: 02' February, 2024.
NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint Shri Justice
Chakradhari Sharan Singh, Judge of the Patna High Court, to be Chief Justice
of the Orissa High Court, with effect from the date he assumes charge of his
office.

LLJ
(Nar an Prasad)
ent of India
Deputy Secretary to the Gove
Tele: 2307 2149
To
The Manager,
Government of India Press,
Minto Road, New Delhi.

<!-- page 2 -->

2
No. K-13027/02/2023-US.II

Dated: 02.02.2024

Copy to:1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.

Shri Justice Chakradhari Sharan Singh, Judge of the Patna High Court
through the Registrar General, Panta High Court, Patna.
The Secretary to the Governor, Odisha, Bhubaneswar.
The Secretary to the Governor, Bihar, Patna.
The Secretary to the Chief Minister, Odisha, Bhubaneswar.
The Secretary to the Chief Minister, Bihar, Patna.
The Secretary to the Acting Chief Justice, Orissa High Court, Cuttack.
The Secretary to the Chief Justice, Patna High Court, Patna.
The Chief Secretary, Government of Odisha, Bhubaneswar.
The Chief Secretary, Government of Bihar, Patna
The Registrar General, Orissa High Court, Cuttack.
The Registrar General, Patna High Court, Patna.
The Accountant General, Odisha, Bhubaneswar.
The Accountant General, Bihar, Patna.
The President's Secretariat, (CA.II Section), Rashtrapati Bhavan, New
Delhi.
PS to Principal Secretary to the Prime Minister, PM's Office, South Block,
New Delhi.
Registrar (Conf.), o/o Chief Justice of India, 7, Krishna Menon Marg, New
Delhi.
PS to MoS (I/C) (L&J)/ PPS to Secretary (J).
Technical Director, NIC, Department of Justice, with a request to upload
on the website of the Department (www.doj.gov.in).

07,

70-2.4

(Prem Chand)
Under Secretary (Appointments-I)
Tele: 011-23382978
