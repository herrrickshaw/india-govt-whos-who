---
doc_id: "e9dc5b41aef3adc8"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/31924fc2e785de0e9af2e68e5a82db33.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Order No A46011-41-2011-CHS II dated"
date: "2011-07-29"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5854873957f50938"
---

<!-- page 1 -->

a Ne
— | Bee ms =
Bre 5 की 10.0.46011/41/2011-0पसत5.1
me Government of India
Ministry of Health & Family Welfare
(CHS-Division)
Nirman Bhawan, New Delhi - 110 108.
Dated the 29% July 2011.
OFFICE MEMORANDUM
Subject- Regarding addition of degrees in the Civil List of SAG Officers
(Regular) of GDMO Sub-cadre of CHS — Dr. Anita Jain, Additional!
Director (HQ), CGHS Delhi.
The undersigned is directed to refer to letter dt. 06/07/11 received from
Dr. Anita Jain, Addl. Director (HQ}, CGHS, Delhi on the subject noted above
and to say that the necessary entries adding the following degrees have becn
made in the Updated Civil List of SAG officers (Regular) in GD Sub-cadre ol
CHS as on 01/07/201 land have also been made in the working copy of this
Ministry (copy enclosed):
(i) LLB
(ii) Post Graduate Diploma in Disaster Management
(iii) Post Graduate Diploma in Maternal & Child Health
(iv) Post Graduate Diploma in HIV & Family Education
The same will be displayed on the website of this Ministry as and when
the Civil List of SAG officers is circulated.
Ken n
(GYA PRASAI})
SECTION OFFICE
Ph. No. 23061441,
Encl: As Above.
To
Dr, Anita Jain
Additional Director (HQ)
CGHS
| No.9, Bikaner House Hutments,
: Shahjahan Road
| New Delhi.
Copy to:
| In charge, NIC with the request to upload on the website of this Cu
| 4 ul
| (ava Any
SECTION OFFIC }y
. Ph. No. 2306 1-191

<!-- page 2 -->

| i aa a a a ia aa ee |
|
wd
छ
mZzng mrezzz2z209
PRO, Feet oS Baa
69 है 2 हे
= ak = es eee
= f re ee पं छ्ै
2 8०७ of 58292
. RB ag 84 88 7 ६ है ० ६
> < os”? 3
2, See 5
के हिण्ण मल 3
| gx G PF ©
ढ़ =
हि REE
4 z~ =
“ =
; 2
= 28
acs
z:7
#
x N
2 »
> 8|°
5 x
४ कु
©
cs
S 8
9 °
b re
‘ , 3 ; 1
y ° ° |
°o ठ '
3)
8 ५3
£ 2
8 o
9 9
iy nN
2 °
= -_
a
