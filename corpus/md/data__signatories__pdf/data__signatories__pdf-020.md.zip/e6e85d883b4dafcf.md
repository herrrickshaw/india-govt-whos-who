---
doc_id: "e6e85d883b4dafcf"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/20e3e9ebd289e239616a840ae2c7d4c8.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Notes 7"
date: "2013-12-03"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ef2d86b6b1619474"
---

<!-- page 1 -->

of India
India
Government of
Government
Industry
Ministry
Ministry of
of Commerce
Commerce and
and Industry
Department
of Industrial
Promotion
Department of
Industrial Policy
Policy &
& Promotion
Series)
Press
No. 77 (2013
{2013 Series)
Press Note
Note No.
Subject:Amendment of
existing policy
issue of
unlisted Indian
Subject:- Amendment
of the
the existing
policy on
on issue
of shares
shares by
by unlisted
Indian
Companies
under FCCB/ADR/GDR,
FCCB/ADR/GDR, pursuant
pursuant to
Companies under
to the
the Foreign
Foreign Currency
Currency
Convertible
Bonds and
Convertible Bonds
and Ordinary
Ordinary shares
shares (Through
(Through Depository
Depository Receipt
Receipt
Mechanism) (Amendment)
Mechanism)
(Amendment) Scheme,
Scheme, 2013.
2013.
1.0
1.0 ··

Present
Position:
Present Position:

1.1
1.1
Paragraph 3.3.4 (iii) of the 'Consolidated FDI Policy', effective from April 5, 2013,
FCCB/ADR/GDR,
ADR/GDR, reads as
relating to the issue of shares by unlisted Indian Companies under FCCB/
below:(iii) Unlisted companies, which have not yet accessed the ADR/GDR route for raising
capital in the international market, would require prior or simultaneous listing in the
domestic market, while seeking to issue such overseas instruments. Unlisted companies,
which have already issued ADRs/GDRs in the international market, have to list in the
domestic market on making profit or within three years of such issue of ADRs/GDRs,
whichever is earlier. ADRs/GDRs are issued on the basis of the ratio worked out by the
issue. The proceeds so
so
Indian company in consultation with the Lead Manager to the issue.
India. Pending repatriation or
raised have to be kept abroad till actually required in India:
utilization of the proceeds, the Indian company can invest the funds in:(a) Deposits, Certificate of Deposits or other instruments offered by banks rated
by Standard and Poor, Fitch, IBCA, Moody's etc.
etc. with rating not below the
rating stipulated by Reserve Bank from time to time for the purpose;
(b) Deposits with branch/es of Indian Authorized Dealers outside India; and
((c)
c) Treasury bills and other monetary instruments with a maturity or unexpired
maturity of one year or less.
less.
2.0
2.0

Revised Position:
Revised
Position:

2.1
position in this regard and notified the
2.1
The Government of India has reviewed the pos1t10n
Foreign Currency Convertible Bonds and Ordinary shares (Through Depository Receipt
11th�
Mechanism) (Amendment) Scheme, 2013 vide Notification no. G.S.R. 684 (E) dated 11
October, 2013.

<!-- page 2 -->

Accordingly,
3.3.4 (iii)
(iii) of
of the
FDI Policy,
from April
2.2
Accordingly, Paragraph
Paragraph 3.3.4
the 'Consolidated
'Consolidated FDI
Policy, effective
effective from
April
2.2
5, 2013
5,
2013,, is
is replaced
replaced by
by the
the following:
following:
"Unlisted companies
shall be
capital abroad
abroad without
the requirement
"Unlisted
companies shall
be allowed
allowed to
to raise
raise capital
without the
requirement of
of
prior
prior or
or subsequent
listing in
in India
India initially
initially for
period for
for two
to the
the
two years
years subject
subject to
subsequent listing
for aa period
following conditions:
conditions:
following
(a)
Unlisted companies
companies shall
shall list
abroad only
in IOSCO/FATF
(a) Unlisted
list abroad
only on
on exchanges
exchanges in
IOSCO/FATF
compliant jurisdictions
jurisdictions or
or those
those jurisdictions
jurisdictions with
with which
which SEBI
SEBI has
has signed
signed bilateral
bilateral
compliant
agreements;
agreements;
which they
submit to
the proposed
(b)
shall file
(b) The
The Companies
Companies shall
file aa copy
copy of
of the
the return
return which
they submit
to the
proposed
exchange/regulators
also to
exchange/regulators also
SEBI for
purpose of
of Prevention
Prevention of
of Money
Money
to SEBI
for the
the purpose
Laundering Act
(PMLA). They
They shall
shall comply
requirements
Laundering
Act (PMLA).
comply with
with SEBI's
SEBI's disclosure
disclosure requirements
of the
the primary
exchange prior
prior to
to the
the listing
listing abroad;
in addition
to that
in
addition to
that of
primary exchange
abroad;
(c)
company shall
shall be
fully compliant
(c) While
While raising
raising resources
resources abroad,
abroad, the
the listing
listing company
be fully
compliant with
with
the
FDI policy
in force;
force;
the FDI
policy in
(d)
abroad may
overseas debt
debt or
(d) The
The capital
capital raised
raised abroad
may be
be utilized
utilized for
for retiring
retiring outstanding
outstanding overseas
or
for
abroad including
acquisitions;
for operations
operations abroad
including for
for acquisitions;
(e)
as stipulated
stipulated at
(e) In
In case
case the
the funds
funds raised
raised are
are not
not utilized
utilized abroad
abroad as
at (d)
(d) above,
above, such
such
companies shall
shall remit
within 15
15 days
days and
such money
companies
remit the
the money
money back
back to
to India
India within
and such
money
shall be
category banks
recognized by
and may
may be
shall
be parked
parked only
only in
in AD
AD category
banks recognized
by RBI
RBI and
be used
used
domestically."
domestically."
3.0
3.0

The above
will take
take immediate
immediate effect.
effect.
The
above decision
decision will

Additional Secretary
to the
India
Additional
Secretary to
the Gov
Gov mment
rnment of
of India
D/o
IPP File
5/17/2013-FC-I dated
-- 03December,
o,l''1December, 2013
2013
D/o IPP
File No:
No: No.
No. 5/17/2013-FC-I
dated -Copy
Copy forwarded
forwarded to:
to:
1.
I.
2.
2.
3.
3.

Press Information
Information Officer,
Press Information
- for
necessary publicity.
publicity.
for giving
giving necessary
Press
Officer, Press
Information Bureau
Bureau NIC in
in the
the Department
of Industrial
Policy and
and Promotion
uploading the
Press Note
Note
for uploading
the Press
NIC
Department of
Industrial Policy
Promotion -- for
on DIPP's
on
DIPP's website.
website.
Hindi
Hindi version.
Hindi Division,
Division, DIPP
DIPP for
for providing
providing Hindi
version.
