---
doc_id: "e6164cfcdd7b6a4f"
source_url: "https://mohua.gov.in/static/uploads/2025/11/de7fd48dfa1f61e6f0dbe013f7fccb43.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Central services Rules and Orders issued Thereunder -Extension of appointment of Private Medical Practitioner as Authorized Medical Attendant  for the Employees of Ministry of Housing And Urban Affairs"
date: "2025-11-03"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f7d7a0c5bb2d135f"
---

<!-- page 1 -->

No. D-12015/110/2015-Admn-IIT
Government of India
Ministry of Housing and Urban Affairs
Nirman Bhavan, Maulana Azad Road
New 42/7/% 11
Dated: Bed IH [POP F-
OFFICE MEMORANDUM |
Sub: Central Services (Medical Attendance) Rules and Orders issued Thereunder-Extension
of appointment of Private Medical Practitioner as Authorized Medical Attendant for
the Employees of Ministry of Housing and Urban Affairs-regarding.
. In continuation of this Ministry's Office Memorandum of even number dated:
| 15/11/2016 and willingness of Dr. Vinay Yadav, MD, Physician, Care Clinic, 53-A, New Vinay Yadav, MD, Physician, Care Clinic, 53-A, New
Roshan Pura Extn. Najafgarh, New Delhi-43 Dated: 11/11/2017 Pura Extn. Najafgarh, New Dethi-43 Dated: 11/11/2017 on the subject noted
above, as Authorized Medical Attendants (AMAs) for Central govt. employees working in
the Ministry of Housing and urban Affairs and their family members and within a radius of
16 kilometers has been extended for another year from 14/11/2017 to 13/11/2018.
This issues in accordance with the provisions contained in the Central Services (Medical
Attendance) Rules, 1944 and orders issues thereunder from time to time on the following
terms & conditions: -
(i) The Authorized Medical Attendant will charge fee for consultation and injection at the
rates prescribed under C5 (MA) Rules, 1944,
(ii) The Authorized Medical Attendant will follow strictly the provisions of CS (MA) Rules
1944 and order issued from time to time.
(ii) This nomination can be terminated even before the expiry of the terms of appointment
without giving any notice/reasons.
(Sunil Kumar)
Under Secretary to the Govt. of India
Tel. No: 011-23062295
Copy to:

1. The Pay & Accounts Officer, M/o Housing and Urban Affairs, Nirman Bhawan, New Delhi.

2. Dr. Vinay Yadav, MD, Physician, Care Clinic, 53-A, New Roshan Pura Extn. Najafgarh,
New Delhi-110043.

3. DGHS, Nirman Bhawan, New Delhi-110011

4. Admn.I, IT & IV Section;

5. Shri Hari Kishan, MTS and all Employees of Ministry of Housing and Urban Affairs
residing at Village Thuljhuli Post Office Gumanhera, Delhi-110073 and within the radius
of 16 Kilometers.

NIC with the request to upload the OM;
7. Notice Board/Sanction folder,
(Sunil Kumar)
Under Secretary to the Govt. of India
Tel. No: 011-23062295
rr a 4 9३ ३३३३३३३३३७४४४३३३४४७३६४३७४६७४३३/हनतनुननतततररत नल. र्रः
