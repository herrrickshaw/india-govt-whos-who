---
doc_id: "e5a38ad50c58aeaa"
source_url: "https://doj.gov.in/static/uploads/2025/12/9e6b17c7a20a1f8ea54e03618bb6e3ed.pdf"
ministry: "Department of Justice (DoJ)"
title: "Administrative Staff College of India (ASCI), Hyderabad"
date: "2021-11-22"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "62fba48f5825da8e"
---

<!-- page 1 -->

7 File No. N-9/16/2014-NM
Government of India
Ministry of Law and Justice
Department of Justice
Jaisalmer House,
26-Mansingh Road, New Delhi-110011
Dated: 19" March, 2018
SANCTION ORDER
Sanction of the Competent Authority is hereby accorded to the payment of Rs. 78,847/- only
(Rupees Seventy Eight Thousand Eight Hundred Forty Seven Only) to Administrative Staff College
of India (ASC), Hyderabad towards Third & Final Instalment ( part payment) out of the total
project cost of Rs. 23,75,000/- (Rupees Twenty Three Lacs Seventy Five Thousand Only) (non-
recurring expenditure) for under taking research project titled “Analysis of causes for Pendency in
High Courts and Subordinate Courts for improved court management ” under the “Scheme of
Action Research and Studies on Judicial Reforms” as per the terms of the agreement signed by
Administrative Staff College of India (ASCI), Hyderabad and Department of Justice on 0204
March, 2016. First & Second installments of Rs.4,75,000/- & Rs. 9,50,000/- only respectively was
released to the Administrative Staff College of India (ASCI), Hyderabad the implementing Agency
vide this Department's sanction orders of even no. dated 04" March, 2016 and 10" November,
. 2016.
2. The expenditure involved is debitable to Demand No. 61 during 2017-18 (Plan) under MH 2014-
Administration of justice, 17-National Mission for Justice Delivery and Legal Reforms; 17.02-Action
Research and Studies on Judicial Reforms, 17.02.28-Professional Services.
3. This has been entered in the Register of Grants/Expenditure at SI. No. 3 at page No. 33-34.
4. This issues with the approval of IFD [Law] vide AS & FA Dy. No. 1578 dated 14/03/2018. i —
ee —
(Giridhar G Pai)
Director
Telefax: 23072145
To,
Pay & Accounts Officer,
Ministry of Law & Justice, Department of Legal Affairs,
Janpath Bhawan, Janpath,
New Delhi
Copy to:-
1. Cash Section, Department of Justice with one spare copy and a copy
of Agreement. It is requested that the payment may be made through e-payment to The
Administrative Staff College of India (ASCI), Hyderabad.
2. Cash-Il MHA, North Block, New Delhi
3. IFD/Budget Division, Ministry of Law and Justice, Legislative Department, Shastri
Bhawan, New Delbhi.
4. NIC, Jaisalmer House, New Delhi for uploading on the Department of Justice website.
5. Director General, Administrative Staff College of India (ASCI), Bella Vista, Raj Bhawan Road,
Hyderabad-500082.
6. Section Officer, Admn.Unit, Department of Justice, Jaisalmer House, New Delhi.
7. Principal Accounts Office, 4" Floor, Ministry of Law and Justice, Lok Nayak Bhawan,
Khan Market, New Delhi.
8. Guard File
9. Spare Copies-5.
॥
|
