---
doc_id: "ea0cb2c1279ab6eb"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/08/7de9fca1ead90e1af7f0255951427099.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Notification No. GSR 625(E) dated 07.08.1983 regarding Acetylene"
date: "1983-08-07"
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "299752e5b826b357"
---

<!-- page 1 -->

Notification
No.GSR 625(E) dated 07.08.1983 regarding
th

No. M-1217, dated 20 November, 1926: In exercise of the powers conferred by Section 17 of
the Indian Explosives Act, 1884 (IV of 1884), and in supersession of the Commerce and Industry
th
Department Notification No.12455, dated the 20 October, 1917, the Governor-General-inCouncil is pleased to declare that picric acid, picrates and mixtures of picric acid shall be deemed
to be explosives within the meaning of the said Act, subject to the following exceptions, namely:--

a. Picric acid or a picrate when mixed with not less than one half its own weight of
b.

water shall not be deemed to be an explosive.
Picric acid when thoroughly mixed with not less than three times its own weight
of—
i.
anhydrous sulphate of soda, or
ii.
crystallized sulphate of soda, and packed in hermetically closed
packages, or
iii. potash alum.
Shall not be deemed to be an explosive.

C.

Picric acid when the quantity does not exceed 1 oz. Shall not be deemed to
be an explosives, provided that -

iv.

v.

vi.
vii.

such picric acid is so kept and conveyed as not be liable whether under
the action of fire or otherwise, to come in contact with any substance
specified in the annexed schedule, or with any fire or light capable of
igniting such picric acid;
such picric acid when dry is contained in a packet from which the
contents cannot escape; and in the construction of which no metal other
than aluminium or an alloy containing not less than 90 per cent of
aluminium is used;
each package is legibly marked "Picric acid";
if the picric acid is contained in glass bottles, the stoppers shall not be of
glass.

SCHEDULE
:
Any of the following metals or metallic oxides, namely, lead, oxide of lead, oxide of iron, potash,
baryta, lime, soda, oxide of zinc, oxide of copper; and any compound of such metal or oxide
(other than a metallic sulphate); or any chlorate, nitrate, or other oxidising agent,; or any other
substance declared by the Governor-General-in-Council to be capable of forming with picric acid
a dangerous compound:
Provided that this schedule shall not be deemed to include any metal or oxide unavoidably
formed on any metal, used in the construction of any ship, boat or carriage, or contained in any
paint, where the packages containing picric acid are protected from direct contact with such metal
or paint.
No.M.1217, dated 13-7-1927.—In pursuance of sub-section (2) of Section 18 of the Indian
Explosives Act, 1884 (IV of 1884), and in supersession of the notification of the Government of
nd
India, in the Home Department No.1964, dated the 2 September, 1887, the Governor-General-

<!-- page 2 -->

in-Council is pleased to prescribe that drafts of rules proposed to be made under the said Act
shall be published --

a. when the authority making the rules is a Local Government, in one issue of the local
b.

Official Gazette in English and in such other language or languages as the Local
Government may direct; and
when the authority making the rules is the Governor-General-in-Council, in one issue of
the Gazette of India, in English.
th

No.M-1217(2), dated 9 May, 1928 : In exercise of the powers conferred by Section 17 of the
Indian Explosives Act, 1884 (IV of 1884), the Governor-General-in-Council is pleased to declare
that Di-Nitro-phenol, Di-Nitro-phenolates and mixtures of Di-Nitro-phenol with any other
substances shall be deemed to be explosives within the meaning of the said Act, subject to the
following exceptions, namely:--

a. Di-Nitro-phenol during the process of manufacture, if mixed with moisture in the
proportion of 85 parts by weight of Di-Nitro-phenol to not less than 15 parts by weight of
moisture shall not be deemed to be an explosive.
b. Di-Nitro-phenol if mixed with water in the proportion of 85 parts by weight of di-Nitrophenol to not less than 15 parts by weight of water and contained in water-tight packages
shall not be deemed to be an explosive.
c. Di-Nitro-phenol containing less than 15 parts by weight of water and not exceeding 5 1bs.
in quantity if contained in packages from which it cannot escape and in the construction
of which, with the exception of nails, screws or other devices necessary for securing the
packages, no metal other than aluminium or an alloy containing not less than 90 per cent
of alluminium is used, shall not be deemed to be an explosive:
Provided that the foregoing exceptions shall not apply unless:-i.
otherwise, to come in contact with any substance specified in the
annexed Schedule or with any fire or light capable of igniting such DiNitro-phenol; and
ii.
the Di-Nitro-phenol is so kept and conveyed as not to be liable whether
under the action of fire or each package is legibly marked "Di-Nitrophenol".
d. Di-Nitro-phenolate when mixed with not less than half its own weight of water and kept or
conveyed in
water-tight packages shall not be deemed to be an explosive.
e. Di-Nitro-phenol when thoroughly mixed with not less than three times its own weight of –
i.
Anhydrous sulphate of soda, or
ii.
Crystallized sulphate of soda, and packed in hermetically closed
packages, or
iii. Potash alum,
Shall not be deemed to be an explosive, provided that each package is
legibly marked with name of the substance.
SCHEDULE
Any of the following metals or metallic oxides, namely, lead, oxide of lead, oxide of iron,
potash, baryta, lime, soda, oxide of zinc, oxide of copper and any compound of such
metal or oxide (other than a metallic sulphate), any chlorate, nitrate, or other oxidising
agent, or any other substance declared by the Governor-General-in-Council to be
capable of forming with Di-nitro-phenol a dangerous compound:

<!-- page 3 -->

Provided that this Schedule shall not be deemed to include any metal, or oxide
unavoidable formed or any metal, used in the construction of any ship, boat or carriage,
or contained in any paint, where the packages containing Di-nitro-phenol are protected
from direct contact with such metal or paint.
th

No.M-1272(1), dated 28 September, 1938.—In exercise of the powers conferred by
Section 17 of the Indian Explosives Act, 1884 (IV of 1884), the Central Government is
pleased to declare that any gas when compressed in any metal container whether such
gas when so compressed be in +[ the gaseous liquified or dissolved state] shall be
deemed to be an explosive within the meaning of the said Act:
th

No.M-1217(3), dated 30 November, 1940 as amended by GSR 571, dated 1—41966.—In pursuance of sub-rule (4) of Rule 60 of the Explosives Rules, 1940, the Central
Government is pleased to prescribe the appended form for the grant or renewal of
licences under that rule in respect of boats used for the transport of explosives, and to
direct that a fee of rupees sixteen shall be payable for the grant or renewal of each such
licence.
Licence for the transport of explosives in boats
Name of boat or other distinguishing mark.______________________
Official No.
______________________
Gross metric tonnage, if any.
______________________
Name of owners.
______________________
Fee—Rs.16.
The above boat is hereby licensed, under Rule 60 of the Explosives Rule, 1940, for the
transport of explosives up to a maximum of _________*kg within the limits of the Port
of__________________in_______________areas outside port limits subject to the provisions of
the Explosives Rules, 1940, and the Indian Explosives Act, 1884.
The licence shall remain in force
______________________20_____
issued
of_________________20___.

till

the ______________________day of
at________________the____________day

Conservator of Port of Licensing Authority appointed under Rule 60 of the Explosives Rules,
1940.
th

No.S.&P. II-Exp. 102(44)(ii) 51, dated 8 September, 1954.—In exercise of the powers
conferred by Sections 5 and 7 of the Indian Explosives Act, 1884 (IV of 1884), as applied by the
th
notification of the Government of Assam No.TAD/L/4/51, dated 27 January, 1953, to those areas
of the United Khasi-Jaintia Hills District which were known as the Khasi States immediately
before the commencement of the Constitution of India, the Central Government hereby makes
the following rules the same having been previously published as required by Section 18 of the
said Act, namely:-The Explosives Rules, 1940 shall extend to and have effect in so much of the areas of the
United Khasi-Jaintia Hills District as were known as the Khasi State immediately before the
commencement
of
the
Constitution:
Provided that the said rules in their application to the said areas shall be subject to the same
exceptions and modifications as they are subject to in the rest of the areas of the said United
Khasi-Jaintia Hills District.

<!-- page 4 -->

th

No.S. & P. II-Exp. 2(3)/57, dated 14 October, 1957.—In pursuance of clause (1) of Article 239
of the Constitution and in supersession of all previous notifications on the subject, the President
hereby directs that the Administrators of Delhi, Himachal Pradesh, Manipur, Tripura, the
Andaman and Nicobar Islands and the Laccadive, Minicoy and Aminidivi Islands, shall subject to
the control of the President and until further orders, discharge the functions of the Central
Government under the proviso to Rule 82 of the Explosives Rules, 1940, u nder the proviso to
Rule 83 of the said rules and under Rule 93 of the said rules, in their respective administration.
G.S.R.64(E), dated 27-1-1992.—In exercise of the powers conferred by the Section 6 of the
Indian Explosives Act, 1884 (4 of 1884), and in super session of the notification of the
Government of India, Ministry of Works, Housing & Urban Development No. 3/12/65-PII (IX),
dated 1-4-1966, the Central Government is pleased to prohibit the manufacture, possession and
importation of any explosive consisting of or containing sulphur or sulphurate in admixture with
chlorate of potassium or any other chlorate:
Provided that this prohibition shall not extend to the manufacture or possession of such
explosives:

a. in small quantities for scientific purposes;
b. for the purpose of manufacturing heads of matches;
c. for use in toy amorces (paper caps for toy pistols); or
d. in percussion caps for use in Railway Fog Signals.
G.S.R.625(E), dated 7-8-1983 (w.e.f. 16-8-1983).—In exercise of the powers conferred by
Sections 17 and 6 of the Indian Explosives Act, 1884 (4 of 1884) and in super session of the
notification of the Government of India in the late Department of Labour No.M-1268(1), dated the
th
9 January, 1939, the Central Government hereby:

1. declares that acetylene,
a. when liquid, or
b. when subject to any pressure, or
c. when in admixture with air or oxygen in whatever proportion and at whatever pressure,
and

d. whether or not in admixture with other substances, shall be deemed to be an explosive
within the meaning of the said Act; and
2. prohibits absolutely the manufacture, possession, t rasnport and importation of such
acetylene as is declared by this notification to be an explosive subject to the exceptions
mentioned in the Schedule annexed hereto and when it is contained in a homogeneous porous
substance with acetone or other approved solvent in accordance with the provisions of the Gas
Cylinders Rules, 1981.
SCHEDULE

1. Any acetylene which the Central Government, on being satisfied, that it is not possessed
2.

of explosive properties may by order exempt from the operation of this notification.
Any acetylene in admixture with air or oxygen when such admixture takes place—

a. only in a burner or other contrivance in which the mixture is intended to be burnt;
b. unavoidably, in the first use or recharging of an apparatus properly designed and
constructed with a view to the production of commercially pure acetylene.

<!-- page 5 -->

3.

Any acetylene in admixture with oil-gas (that is to say, a gas manufactured from mineral
oil) and under compression if the following conditions are fulfilled, namely:--

a. the acetylene shall be generated only by such process as may be approved by the Chief
b.
c.
d.

Controller of Explosives;
the proportion of acetylene shall not exceed fifty parts by volume in every one hundred
parts of the mixture of acetylene and oil gas;
the acetylene and oil-gas shall be mixed together in a chamber or vessel before the
gases are subject to compression; and
2
the mixture shall not be subjected to a pressure exceeding 1.55 kg/cm (1550 cm. Water
column).

4. Any acetylene which is subjected to a pressure not exceeding 1.55 kg/cm2 (1550 cm.
Water column) so long as it is manufactured in an apparatus and kept in a premises
approved by the Chief Controller subject to the conditions mentioned hereunder:
Provided that approval in respect of premises may not be necessary if the apparatus is of
a design not requiring a charge of Carbide of Calcium exceeding two kilogrammes at any
one time.
CONDITIONS

1. Acetylene is manufactured or kept in an apparatus of a type approved in writing by the
2.

Chief Controller of Explosives (apparatus includes any appliance inclusive of fittings used
for the manufacture of acetylene gas by interaction of Carbide of Calcium with water).
(a) The apparatus shall be so constructed that lime sludge cannot gain access to or clog
any pipe intended for the passage of gas or the water feed. Sludge overflow or outlet
shall
be
large
enough
to
avoid
frequent
clogging.
(b) The use of glass in water gauge, sight boxes, shall be avoided, but where provision of
glass
is
absolutely
necessary as part of the apparatus it shall be effectively protected against fracture or
fragmentation.
(c) The apparatus shall be so constructed that it is not possible, even by incorrect
manipulation of cocks, to seal the
generating chamber hermetically.
(d) The empty space above the water level in a generator shall be as small as is
consistent
with
proper
working
of
the
apparatus.
(e) No metal containing more than 70 per cent of copper shall be present in any portion of
the
apparatus.
(f) The various parts of the apparatus shall be of adequate strength to withstand any
pressures
that
may
be
generated
therein.
(g) The size of the pipes carrying the gas shall be proportional to the maximum rate of
generation, so that undue back pressure from throttling may not occur.

3. The apparatus shall have an arrangement to generate acetylene gas as fast as it can be
4.
5.

used/removed and must stop generating immediately the gas delivery is closed, or the
gas holder is filled.
The apparatus shall have an efficiency of at least 90 per cent.
The temperature of any part of the apparatus when working shall not exceed 80 degree
Celcius Suitable means for ascertaining the temperature of those parts of apparatus
where heat is liable to be generated shall be provided:
Provided that if it be shown to the satisfaction of the Chief Controller that a higher
temperature is necessary in any generating apparatus and that such higher temperature

<!-- page 6 -->

may be used without danger, the Chief Controller may allow the use of higher
temperature under such conditons as he may specify.

6. (a) The apparatus used shall not be made to work at a pressure exceeding 0.15 kg/cm2
(1550 cm. Water column):
Provided that if it be shown to the satisfaction of the Chief Controller that a higher
pressure is necessary in any generating apparatus and that such higher pressure may be
used without danger, the Chief Controller may allow the use of higher pressure up to a
2
maximum of 1.55 kg/cm (1500 cm. Water column) under such conditions as he may
specify.
(b) In the use of the apparatus, regard shall be had to the danger of stoppage of passage
of the gas and consequent increase of pressure (i.e., even if the gas supply be cut off or
any of the pipes become blocked, the pressure in the generator must not exceed its
design working pressure).

7. (a) Adequate precautions shall be taken to prevent any escape of gas from the
apparatus.
(b) Gas-holders shall be fitted with blow-off pipes carried up to a suitable point in the
open air. The inlet and outlet of gas-holder shall be provided with shut-off valves which
can be easily closed in an emergency.

8. (a) The carbide shall be completely decomposed in the apparatus, so that the lime sludge
discharge therefrom shall
not be capable of generating more gas.
(b) The apparatus shall give no tarry or other heavy condensation products from the
decomposition of the carbide.

9. (a) An open tank shall be provided in the open air for the reception of all residue and
such residue shall remain for at least ten hours in not less than four times its bulk of
water
in
such
tank.
(b) Precautions shall be taken to prevent any lime sludge from being discharged into the
drains.
(c) No source of ignition shall be brought within 9 metres from a tank used for reception
of lime sludge.

10. An apparatus shall have an efficient arrangement capable of effectively preventing a flash
back from the acetylene
delivery pipe to the generator or to the gas-holder, as the case may be.
11. All electrical motors, lights, switches and other fittings inside a shed housing an
apparatus for acetylene generation and within 15 metres of such shed shall be of flame
proof construction conforming to IS:2148 and of a type approved by the Chief Controller.
12. (a) Acetylene generating apparatus shall be installed in a lightly constructed shed made
of suitable non-flammable materials.
(b) The shed shall be adequately ventilated near the ground level and near the roof.
(c) A concrete floor covered with suitable conductive material and raised at least 60 cms.
above the ground level should be provided.
(d) Escape doors must open outwards and give direct exit to the open space. Their
position and number must be such as to provide adequate means of exit in the event of
an emergency.
13. The shed housing an apparatus shall maintain distance not less than 30 metres from an
Oxygen manufacturing plant
building, 90 metres from an air-intake point, 9 metres from sludge tank and 15 metres
from any other protected works:

<!-- page 7 -->

Provided that dissolved acetylene cylinder filling-cum-storage shed and carbide storage
shed may be adjoining the shed housing an apparatus for acetylene generation and in
such case the above mentioned distances shall be observed from the entire building.

14. All apparatus, machinery and other equipment shall be efficiently earthed at all times.
The
earthing
connections
should be tested at least once in a year and record of all such tests maintained.
15. Nothing in conditions 11,12,13 and 14 shall apply to an apparatus of a design requiring
charge of carbide of calcium not exceeding 2 kgs. at any one time provided the same is
kept in a room forming part of building with a suitable exit leading to open space/road.
16. No part of an apparatus or connected distribution system shall be opened without
bringing it down to the ambient temperature and no repair with flame or heat shall be
carried out unless the apparatus and connected distribution system and the surroundings
are made free of acetylene gas. All repairs shall be carried out under the supervision of
an experienced person.
G.S.R. 687(E), dated September, 1984.—In exercise of the powers conferred by sub-section (2)
of the Section 14 of the Explosives Act, 1884, the Central Government hereby exempts from the
provisions of sub-rule (1) of Rule 135, Rule 137 and Condition 1 of the Licence in Form 24, of the
Explosives Rules, 1983, the explosives of Class-7 FIREWORKS, DIVISION-2 and any person or
class of persons desiring to possess and sell the said explosives at a temporary shed under a
licence to be issued in Form 24 of the Explosives Rules, 1983, by the District Authority subject to
the following conditons, namely:--

1. The fireworks shall be kept in a shed made of non-flammable material which is closed
2.
3.
4.

5.

and secured so as to prevent unauthorised persons having access thereto.
The sheds for possession and sale of fireworks shall be at a distance of at least 3 metres
from each other and 50 metres from any protected works.
The sheds shall not be facing each other.
No oil burning lamps, gas lamps or naked lights shall be used in the shed or within the
safety distance of the sheds for the purpose of lighting. Any electrical light, if used shall
be fixed to the wall or veiling and should not be suspended by flexible wire. Switches
should be fixed rigidly near the ceiling and a master switch should be provided for each
row of sheds.
Display of fireworks shall not be allowed within 50 metres of any shed.

G.S.R. 565(E), dated August 20, 1993.—In exercise of the powers conferred by sub-section (2)
of Section 14 of the Explosives Act, 1884 (4 of 1884), the Central Government hereby exempts
the Chief Controller of Explosives, Nagpur from the provisions of Rules 32 and 113 of the
Explosives Rules, 1983, for transport, storage and use of authorised explosives for their testing
station at Gondkheri, District Napgur, Maharashtra State subject to the following conditions,
namely:--

1. The explosives possessed at a time shall not exceed—
Class
1
100
Class
2
or
Class
3
Class
2
and
Class
3
400
Class
6
Division
1
10,000
Class
6
Division
2
10,000
Class
6
Division
3
12,500
(Electric or Ordinary or Electric and Ordinary)

kg
or
kg.
metres.
metres
Nos.

<!-- page 8 -->

2. The explosives shall be stored in magazines constructed as per requirements of the
3.

Explosives Rules, 1983.
Relevant provisions of the Explosives Rules, 1983 relating to possession, transport, and
use of such explosives are strictly observed.

G.S.R. 639(E), dated October 6, 1993.—In exercise of the powers conferred by sub-section (2)
of Section 14 of the Indian Explosives Act, 1884, the Central Government hereby exempts M/s.
Narmada Chematur Petrochemicals Ltd., from the operation of the provision of sub-rule (1) of
Rule 87 and sub-rule (1) of Rule 113 of the Explosives Rules, 1983, for manufacture and handling
of DNT (Di-Nitro Toluene), an explosive of Class 3 Division 2, subject to the following conditions,
viz:--

1. DNT shall be manufactured in the factory to be established at Bharuch (Gujarat) by M/s

2.
3.

4.
5.

6.

Narmada Chematur Petrochemicals Ltd., a joint venture company of Gujarat Narmada
Vally Fertilizers Ltd., in association with Chematur Engg., AB-Sweden and IBI Chematur,
Bombay, as an intermediate product only. The DNT produced by nitration of toluene shall
be fully consumed in the hydrogenation unit for manufacture of Meta Toluene Di-amines
(MTD).
0
DNT shall be kept in liquid form at elevated temperature of around 70 C in admixture with
adequate quantity of water, till it is separated and pumped to the hydrogenation plant.
The separator and the pump unit shall not contain more than 100 kgs. of pure DNT. The
building housing these units shall conform to specified safety clearance and shall be
constructed and traversed as prescribed by the Chief Controller of Explosives, as per the
provisions of the Explosives Rules, 1983.
Only qualified and competent persons shall conduct and supervise operations involving
manufacture and handling of DNT.
Every person incharge of or engaged in the manufacture and handling of DNT shall at all
times take due precautions for the prevention of accidents by fire or explosion and for
preventing unauthorised persons from having access to the premises meant for handling
of DNT.
Free access to the factory premises shall be given at all times to any inspecting officer
authorised by the Chief Controller of Explosives for ascertaining that the provisions of the
Act, rules and the conditions of this notification are being duly observed.

G.S.R. 898(E), dated November 27, 1992.—In exercise of the powers conferred under subsection (2) of Section 14 of the Explosives Act, 1884 (4 of 1884), the Central Government hereby
exempts any person from the operation of the provisions of sub-rule (1) of Rule 87 and sub-rule
(1) of Rule 113 of the Explosives Rules, 1983 for manufacture, possession and sale of
Colour/Star Matches, an explosive of Class 7 Fireworks Divn. 2, subject to the following
conditions namely:-CONDITIONS

1. The manufacture of Colour/Star Matches shall be done in a factory approved by the Chief
Controller of Explosives.
Any person desiring to manufacture Colour/Star matches shall submit to the Chief
Controller of Explosives, an application, plans of the proposed building and site drawn to
scale, description of process/work to be carried out, detailed process of manufacture and
prescribed scrutiny fee.

<!-- page 9 -->

2. (a) The Colour/Star matches shall be manufactured in one or more lightly constructed
single storied buildings(s) which may be divided into rooms. The quantity of Colour/Star
matches or its ingredients in the manufacturing rooms and bonded storage room shall not
exceed the following:-(b) Not more than four persons shall be allowed at any time in any of the manufacturing rooms
namely Mixing, Drying and Dipping rooms.
(c) Doors of all the rooms shall open outwards.
(d) A clear space 6M, 9M or 15M for the manufacturing capacity of 100 Kgs. 200 Kgs. or 500
Kgs., respectively shall be maintained all round the factory building. A 2M high barbed wire
fencing or wall of adequate strength shall be provided along the perimeter of this safety zone.
(e) The manufacturing and storage rooms shall have adequate space to accommodate
comfortably the prescribed quantity of explosives and the number of persons.

3. (a) The explosive mixture on each stick shall not exceed 0.8 gm in case of colour and 1.0
gm in case of star match.
(b) The side painting on each box shall have a clearance of at least 2 mm. from the
edges.

4. (a) Ingredients shall be kept adequately separated until their mixing. Potassium Chlorate
shall be kept in a separate room away from the other ingredient storage.
(b) Mixing of the ingredients shall be done under solvent or water. Any electrical grinder
used for mixing shall have flameproof/dust tight motor and accessories as the case may
be.
(c) The dipped splinter frames shall be dried racks not exceeding 1.8M in height and the
number of such racks in the drying room shall not exceed 10 in number. Each rack shall
hold
a
maximum
of
10
frames
placed
in
the
alternate
groves.
(d) The matches shall not be accumulated unpacked and shall be packed as soon as
they
are
dried.
(e) The manufacture shall be done only between sunrise and sunset.
(f) No loose explosives composition shall be left in the factory at the close of the working
day. All such material shall be carefully collected and destroyed as per the procedure laid
down at the close of the day.

5. (a) The interior of the manufacturing rooms and the fittings therein, other than machinery,
shall be so constructed, lined or covered as to prevent exposure of any iron or steel or
detaching of any grit, iron or similar substance in such manner as to come in contact with
any explosives. The interior including the floor of the rooms shall be kept clean and free
from grit.
(b) No tools, implements, balance, weights, receptacles etc. made of iron or steel shall be
brought
or
kept
at
any
time
in
the
licensed
premises.
(c) No stone implements such as mortars, pestles, grinders etc. shall be used for
grinding, mixing or ponding of match composition.

6. (a) All due precautions shall be taken during drying of the match sticks and in handling
dried matches. No smoking, fire or naked light shall be allowed in the premises.
(b) Adequate provisions of water shall be made in the premises for fire fighting purpose.

<!-- page 10 -->

7. (a) If Controller of Explosives calls uponthe manufacturer of Color/Star Matches by notice
in writing to execute any repairs or to make any alterations to the factory premises which
are in the opinion of such authority necessary for the safety of the premises or of the
persons working in the factory, the manufacturer shall execute the repairs, alterations
within the period.
(b) No change in the manufacturing process and no addition/alteration in the premises
shall be carried out without permission form Controller of Explosives.

8. (a) No persons shall commit or attempt to commit any act which may tend to cause fire or
explosion in or about any place where Colour/Star Matches are manufactured, stored,
handled or transported:
Provided that nothing in this connection shall apply to any act which is reasonably
necessary for the purpose of manufacture, storage or handling during transport of any
such matches or of any article present therewith.
(b) Every person in charge of or engaged in the manufacture, sale, transport or handling
of Colour/Star Matches shall at
all times :

a. Observe all the precautions for the provision of accidents by fire or explosion;
b. Prevent unauthorised persons from having access to the body composition and
head composition;

c. Prevent any other person from committing any such act as is prohibited under
sub-condition (a) above.

10. The manufacture Color/Star matches shall be done under the supervision of qualified and
competent person.
11. Free access to the factory premises shall be given at all times to any authorised
inspecting or sampling officer and all facilities shall be offered to such officer for
ascertaining that the provisions of the Act, Rules or the conditions of this Notification are
duly observed.
12. Accidents by fire or explosion shall be reported without delay to the Controller of
Explosives and to the officer in charge of the nearest police station.
13. If the factory is used for manufacture of safety matches as well, such manufacture shall
be completely discontinued and the premises, freed of safety match and its ingredients
before taking up manufacture of Colour/Star matches. The Controller of Explosives in
whose jurisdiction the factory is situated shall be intimated before commencing
manufacture of Colour/Star matches and on its completion. After completion of
manufacture and before resuming manufacture of safety match, the premises shall be
made free of all compositions used in manufacture of Colour/Star Match.
14. No person under 18 years of age and no person who is in a state of intoxication or of
unsound mind shall be employed in or allowed to enter the factory.
15. The Colour/Star Matches shall not be stored, handled or transported along with other
items of fireworks, safety matches, flammable or hazardous materials.
