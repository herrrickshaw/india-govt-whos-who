---
doc_id: "e9d4ccdfb2878ebb"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/2fecd1b06052d0326c5b0c3a160a2954.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of MSC codes to Ms Tata Teleservices Maharashtra Limited for Mumbai LSA for provisioning of internet telephony service"
date: "2025-06-27"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "07ed3d1afb49f8ad"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Departinent of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
(Access Services Wing)
No.16-06/2024-AS-IN/ [AS Dated: 27.06.2025
To,

M/s Tata Teleservices (Maharashtra) Limited
Subject: Allocation of MSC codes to M/s Tata Teleservices (Maharashtra)
Limited for Mumbai LSA for provisioning of internet telephony service-
Regarding.

In consideration to the request of the above-mentioned service provider, the
undersigned is directed to convey the allotment of MSC code for provisioning of
internet telephony service as per details given below:

Ss. Licensee Licensed Access-MSC code allotted tol

No. Service Area |meet demand of One Lakh
Subscriber's

1. |Taia Teleservices हे

(Maharashtra) Limited Mumbai . 92409
a Aforementioned series may be used by TSP except for the ported out
subscriber (if any).

हि हि : Digitally signed by
3. This is issued with the approval of competent authority. VAIBHAV JAIN
Date: 27-06-2025
16:21:13
Director (AS-IIl)
Ph. No. 011-23372488
Copy for kind information and necessary action, if any, to:
1. Secretary, TRAI
2. Director (T), DGT, HQ with request to convey the allocation to concerned
LSA field unit.
3. All Access Service Providers
4. All MNP Licensees.
5. A copy for upload on DoT website.
