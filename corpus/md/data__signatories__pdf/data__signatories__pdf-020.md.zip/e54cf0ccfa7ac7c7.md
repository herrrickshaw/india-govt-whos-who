---
doc_id: "e54cf0ccfa7ac7c7"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/67c23c0a1892e03b28a0676d61125529.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Transfer & Posting of officers in SAG of ITS Group A - reg"
date: "2024-08-07"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "87f1b45e74835827"
---

<!-- page 1 -->

12-3/2024-STG-I

I/3200710/2024

No. 12-3/2024-STG-I
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20 Ashoka Road, New Delhi
Dated the 07th August, 2024
OFFICE ORDER
Subject: - Transfer & Posting of officers in SAG of ITS Group ‘A’ - reg.
Approval of the competent authority is hereby conveyed for transfer &
posting of the following oﬃcers in the grade of SAG of ITS Group ‘A’, with
immediate effect:
Sl.
No

Staff
No

Name(Shri/Smt.)

Place of Posting

Posting on transfer

1. 20773 Anshuman Gupta

Raipur, MP LSA

2. 20750 Devendra Dwivedi

BSNL

3. 20909 Lalit Bihari Lal

Under Posting

BSNL
(On Own Cost)
Raipur, MP LSA
(On own cost)
BSNL

4. 20932 Vikas Garg

Under posting

SPPI Division, DoT HQ

5. 20971 Abhay Kumar

Under posting to
BSNL
SPPI Division, DoT
HQs

J&K LSA

6. 20814 Vinod Kumar

2.
follow.

SRI Division, DoT HQs

The charge report may be furnished to all concerned. Hindi version will

(Bijender Singh)
Under Secretary to the Government of India
Tele 011-2303 6282
Email: bijender.s83@gov.in
Copy to:
1. Chairman, DCC/Member(S)/Member(T)/Member(F)/DG(Telecom), DoT;
2. AS(T)/ Administrator USoF / All Advisors, DoT;
3. CMD, BSNL CO.;
4. CVO, DoT HQs;
5. Addl. DGT, MP LSA/ Addl. DGT, J&K LSA
6. All Sr. DDGs/DDGs DoT HQs;

<!-- page 2 -->

12-3/2024-STG-I

I/3200710/2024

7. DDG (C&A), DoT HQs;
8. Admn.I-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.I Sec., DoT HQs;
9. Pay Bill Section, DoT HQs;
10. US (STG-III)/ADG (APAR)/AD (STG-1)/AAO (STG-I), DoT HQs;
11. The Officer concerned;
12. Official Language Section, DoT for Hindi version of the order;
13. Order Bundle/PA to US(SGT) for uploading this order on DoT website.
