---
doc_id: "e5bf87e8dbdafd04"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/0734af15dfbebb24de93e41422c0870f.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Corrigendum- Pre-Bid Queries Meeting for the Appointment of Consulting Agency for Mystery Shoppers"
date: "2025-07-01"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "337b59499884363a"
---

<!-- page 1 -->

No. P-37022/12/2023-lC
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade (DPIIT)
(Industrial Corridors Section)
Udyog Bhawan, New Delhi
Dated:01th August, 2023
Corrigendum
Subject: Pre-Bid Queries Meeting for the Appointment of Consulting Agency
for Mystery Shoppers for the Industrial Corridors Scheme through Video
Conferencing– reg
With reference to GEM Bid No. GEM/2023/B/3662504 dated 07.07.2023, regarding
Request for Proposal (RFP) for hiring a Consulting Agency/ Organization/ Institution
to carry out Mystery Shopping of Industrial Corridors Scheme issued by this
Ministry, all prospective bidders are hereby informed that due to unforeseen reasons
the pre-bid meeting scheduled to be held on 2nd August 2023 at 11:30 am through
physical mode now will be held through Video Conference. The link of the
meeting can be find below:
Hosted by DPIITMOC&I
https://railtelindia.webex.com/railtelindia/j.php?MTID=m327f96eebb766c0584
80b06aed449f24
Wednesday, August 2, 2023 11:30 AM | 2 hours | (UTC+05:30) Chennai,
Kolkata, Mumbai, New Delhi
Meeting number: 2515 911 4871
Password: 02082023 (02082023 from video systems)
Join by video system
Dial 25159114871@railtelindia.webex.com
You can also dial 210.4.202.4 and enter your meeting number.
Join by phone
+65-6703-6949 Singapore Toll
Access code: 251 591 14871
2. It is requested that all participant companies kindly make it convenient to attend
the aforementioned meeting.
