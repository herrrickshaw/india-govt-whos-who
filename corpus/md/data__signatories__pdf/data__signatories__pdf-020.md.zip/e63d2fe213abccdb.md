---
doc_id: "e63d2fe213abccdb"
source_url: "https://dohe-education.gov.in/static/uploads/2026/07/0794db440f85dcda89676958534a06c3.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Vice-Chancellor, Central University of Odisha"
date: "2026-07-02"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e364308c6922e9c4"
---

<!-- page 1 -->

No. 2-812025 CU.[
Govemment of India
Ministry of Education
Department of Higher Education

Kartalya Bhavan, New Delhi
Dated:2nd July 2026

To.
The Registrar,
Central University of Odisha
Koraput - 763004

Subject: Appointment of the Vice Chancellor, Central University of Odisha.
Sir,

I am directed to convey that the Hon'ble President oflndia in her capacity as the Visitor
of
central University of odisha has been pleased to appoint Dr. Ajit Kumar Shasany, Director csIRNational Botanical Research Institute, Lucknow as the Vice Chancellor ofthe University for a term
of five years from the date on which he enters upon his office or until he attains the age of70 years,
whichever is earlier.

2.

The terms and conditions of the services of Dr. Ajit Kumar Shasany, Director CSIR-National

Botanical Research Institule, Lucknow as the Vice-Chancellor of the Central University of

Odisha

shall be those as set forth in the Act, statutes and ordinances etc of the University.

Yours faithfully,

(Shreya Bh a

waj)
Deputy Secretary to the Covt. of lndia

l,

Dr. Ajit Kumar Shasany, Director cslR-National Botanical Research Institute, Lucknow.

2.

The controller of Administration, cSIR-National Botanical Research Institute, Lucknow.

J.

President's Secretariat New Delhi (Attn: Nitin Gupta, DS), w.r.t ID No . clll-07037 /3/2025-

CA-lll dated 30.06.2026.
4.

The Secretary, University Grants Commission, New Delhi.

5.

The Secretary General, Association of Indian Universities, New Delhi.
PS to ENfl PS to MoS (SM)/ pS to MoS (JC).

6.
7.

PPS to Secretary (HE).

8.

PPS to AS (Edu).

9.

CMIS for placing on the website of MoE.
