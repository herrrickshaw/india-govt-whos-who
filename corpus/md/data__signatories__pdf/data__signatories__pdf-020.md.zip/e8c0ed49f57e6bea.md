---
doc_id: "e8c0ed49f57e6bea"
source_url: "https://doj.gov.in/static/uploads/2025/09/f0a83c4681543f18c515a77f65375861.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of Shri Justice Arindam Sinha, Judge of Orissa High Court as Acting Chief Justice of Orissa High Court w.e.f. 20.01.2025 (17.01.2025)"
date: "2025-01-17"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b92a0577dd3b373d"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
No. K. 11019/04/2025-US.I/II
Government of India
Ministry of Law and Justice
Department of Justice
(Appointments Division)
Jaisalmer House,
I, Man Singh Road,

New Delhi- 11011.
Dated: 17th January, 2025.

NOTIFICATION
In exercise of the powers conferred by Article 223 of the Constitution of
India, the President is pleased to appoint Shri Justice Arindam Sinha, Judge of
the Orissa High Court.9 to perform the duties of the office of the Chief Justice of
that High Court with effect from 20.01.2025 consequent upon retirement of Shri
Justice Chakradhari Sharan Singh, Chief Justice, Orissa High Court on
19.01.2025

Joint Secretary to the Government of India
Tele : 011-23383037
To
The Manager,
Government of India Press,
Minto Road, New Delhi.

<!-- page 2 -->

-2-

Dated: 17.01.2025.

No. K. 11019/04/2025-US.I/II
Copy to:

Sh.i Justice Arindam Saha, Judge of Orissa High Court, through Registrar
General, Orissa High Court, Cuttack.
The Secretary to the Governor, Odisha9 Bhubaneswal:.
The Secretary to the Chief Minister, Odislla, Bhubaneswar.
4. The Secretary to the Chief Justice, Orissa High Court, Cuttack.
The Chief Secretary, Government of Odisha, Bhubaneswar.
The Registrar General, Orissa High Court, Cuttac;k.
The Accountant General, Odisha, Bhubaneswar.
8. The President’s Secretariat, (CA.II Section), New Delhi.
9
PS to the Principal Secretary to the Prime Minister, PM’s Office, New Delhi.
10. Registrar (Conf.), O/o the Chief Justice of India, 07 Krishna Menon Marg9 New

Delhi
11. PS to the MoS (I/C) L&J / PPS to the Secretary (Justice).
12. Technical Director, NIC, Department of Justice, with a request to upload the
notification on the website of the Department (www.doj .gov.in).

;::r;
IrII;}===11: r )
Under Secretary to the Government of India
Tele : 011-23383087
