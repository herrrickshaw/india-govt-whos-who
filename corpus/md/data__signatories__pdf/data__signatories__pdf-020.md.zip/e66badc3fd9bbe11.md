---
doc_id: "e66badc3fd9bbe11"
source_url: "https://www.dot.gov.in/static/uploads/2026/10/f8d4dbdae3a3056ceeee8fe4b0672b7f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 1002 of 2026 in the Hon’ble High Court of Delhi: DoT instructions dated 08.10.2026 to ISPs"
date: "2026-10-08"
pages: 61
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08e7d3582fd148e9"
---

<!-- page 1 -->

4-10/2025-DGT/4(PartVIII)

I/3452142/2026

By Email/ DoT Website
File No.: 4-10/2025-DGT/4 (Part-VIII)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date: 08-10-2026

To
All Licensees with Internet Service Authorization
Subject: CS(COMM) 1002/2026: Amazon Seller Services Private Limited vs.
HTTPS//CINEVOOD.LOVE/ & Ors. in the Hon’ble High Court of Delhi.
Please ﬁnd enclosed the Hon’ble High Court of Delhi order(s) dated
15.09.2026 in the captioned case.
2.
Please refer to para(s) 37 & 39 of the afore said court order along with List 1
to 6 regarding blocking access to website(s)/domain(s) [101 nos], as per the
enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said website(s)/domain(s), as per the enclosed list, in compliance with the
said court order(s).
Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court
order/ enclosed Annexure pl.
ii.
Mr. Manish Rawat (mrawat@saikrishnaassociates.com), Plaintiﬀ's CounselFor kind information and with a request to take action as per the enclosed
Annexure pl.
iii.
The Special DGT, Delhi LSA – For kind information and further necessary
action.

<!-- page 2 -->

4-10/2025-DGT/4(PartVIII)

I/3452142/2026

CS(COMM) 1002/2026:
List of Websites
List - 1
S.No. Website Name
1
9xmovie.int.in
2
jalshamoviez.farm
3
fmovies.direct
4
movielinkhub.net
5
vegamoviess.foo
6
sflix.today
7
cinevood.rocks
8
d10.downloadhub.food
9
hdmovie2a.live
10
movieshunt.monster
11
vegamovito.ltd
12
newhdmovie2.club
13
hdmoviefan.com
14
hdmovie2r.boo
List - 2
S.No. Website Name
1
moviezguru.farm
2
ww5-fmovies.com
3
hindilinks4u.energy
4
yomovies.church
5
moviedrivebd.com
6
filmywap.bet
7
7sttarhd.diy
8
filmyzilla69.com.in
9
cinevood.net
10
ww2.themoviesboss.blog
11
mp4law.com
List - 3
S.No. Website Name
1
prmovies.church
2
ofilmywap.fyi
3
flixfoxweb.app
4
hindilinks4u.asia
5
mlsbd.co
6
sd4.sdmoviespoint.tours
7
moviesbazar.pk
8
movierulzhome.com
9
sitenp.com
10
bollypro.com

Registrar
Dynadot, LLC
NameCheap, Inc.
Tucows Domains Inc.
NameSilo, LLC
Devexpanse Ltd
Tucows Domains Inc.
Dynadot Inc
Tucows Domains Inc.
Dynadot Inc
Spaceship, Inc.
Spaceship, Inc.
Dynadot Inc
Dynadot Inc
Spaceship, Inc.
Registrar
NameCheap, Inc.
Internet Domain Service BS Corp
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Dynadot Inc
Dynadot, LLC
Dynadot, LLC
Tucows Domains Inc.
Dynadot LLC
Dynadot Inc
Registrar
NameCheap, Inc.
Dynadot Inc
GoDaddy.com, LLC
NameCheap, Inc.
Tucows Domains Inc.
NameCheap, Inc.
PKNIC
Dynadot Inc
Realtime Register B.V.
Dynadot Inc

<!-- page 3 -->

4-10/2025-DGT/4(PartVIII)

11
watchofree.website
12
moviezmad.co
13
hhdmovies.study
14
moviehubbd.my
15
watch-movies.com.pk
16
moviesnation.energy
17
allmovieshub.coffee
18
rogmovies.bar
19
ssrmovies.jetzt
20
9xmoviies.mobile
21
ssrmovies.blue
22
8xfilms.net
23
vegamovies.ws
24
movies-x.com
List - 4
S.No. Domains
1
7starhdc.com
2
hdmovies23.cards
3
filmesv.com
4
9xmovie.lat
5
hdmovie88.club
6
moviespapa.delhi.in
7
vega-care.com
8
katmoviehdonline.com
9
9xmovie.kaufen
10
bdmusic23.watch
11
11xmovies.online
12
cinemalux.mom
List - 5
S.No. Domains
1
cinevood.rent
2
9kmovies2.life
3
kmmovies.rest
4
7starhd.wiki
5
ddrmovies.fyi
6
themoviesflix.voto
7
rogmovies.onl
8
dotmorr.com
9
9xmovie.network
10
10xflix.fit
11
vegamoviess.mobi
12
dudefilms.stream
13
mkvcinemas.study
14
bolly4u.fitness

I/3452142/2026

NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
PKNIC
NameCheap, Inc.
NameCheap, Inc.
NAMECHEAP
Dynadot Inc
DYNADOT LLC
OVH SAS
Dynadot Inc
Namecheap, Inc.
Dynadot Inc
Registrar
Gransy, s.r.o.
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot, LLC
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot Inc
Spaceship, Inc.
Registrar
Spaceship, Inc.
Dynadot Inc
Spaceship, Inc.
Dynadot Inc
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
Devexpanse Ltd d/b/a Regery.com
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

<!-- page 4 -->

4-10/2025-DGT/4(PartVIII)

List - 6
S.No. Domains
1
7starhd.exchange
2
7starhdc.com
3
9xmovie.cool
4
9xmovie.koeln
5
allmovieshub.style
6
bdhdmusic23.forum
7
bollyflix.af
8
bollygle.com
9
coolmoviez.surf
10
filmiz.xyz
11
filmycab.org
12
hdjan24.co
13
hdmovies23.cards
14
hdtvdir.com
15
hindilinks4u.lat
16
ihdhub4u.com
17
mkvmoviespoint.vet
18
moviebaaz.baby
19
moviesnation.gives
20
rogmovies.beer
21
southfreak.my
22
thekhatrimaza.sarl
23
vega-movies.video
24
vegamoviesq.com
25
vegamoviess.you
26
world4ufree.beer

I/3452142/2026

Registrar
Dynadot Inc
Gransy, s.r.o.
Dynadot Inc
Dynadot, LLC
NameCheap, Inc.
NAMECHEAP
Gransy s.r.o.
Dynadot Inc
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
NameCheap, Inc.
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
Dynadot Inc
Tucows Domains Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Dynadot, LLC
Dynadot Inc
NameCheap, Inc.
Dynadot Inc
Dynadot, LLC
Dynadot Inc

<!-- page 5 -->

const1.hq-dgt-dot < const1.hq-dgt-dot@govcontractor.nic.in >

Fwd: URGENT | DOT & MEITY | First List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]

Subodh Saxena < ddgit.hq-dgt-dot@gov.in >
Sat, 26 Sep 2026 8:43:08 PM +0530
To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>,"Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>,"SUNIL
KUMAR"<const1.hq-dgt-dot@govcontractor.nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>

============ Forwarded message ============
From: VINAY . <vinay.2009@gov.in>
To: "Prem Chand Sharma"<ddga.hq-dgt-dot@gov.in>, "Subodh Saxena"<ddgit.hqdgt-dot@gov.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Wed, 23 Sep 2026 10:06:58 +0530
Subject: Fwd: URGENT | DOT & MEITY | First List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Sir/Madam,
Please refer to the trailing email on the above subject.
The present case pertaining to blocking of websites/URLs/domains regarding the
infringement of copyright/ trademark/ patent/ exclusive rights of the plaintiff. Such type
of matters are being dealt by the Office of DG(Telecom) , hence, it is being forwarded for
necessary action in the matter, please. It is also requested to register the case on the
LIMBS portal if not registered yet.
Regards,
Vinay
Assistant Section Officer (Legal)
Law Division, DoT

<!-- page 6 -->

============ Forwarded message ============
From: Suneet Kumar Tomar <dirlaw-dot@gov.in>
To: "VINAY ."<vinay.2009@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Nuruddin"<nuruddin.69@nic.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Rohit Meena"<rohit.meena29@gov.in>
Date: Wed, 23 Sep 2026 09:55:42 +0530
Subject: Fwd: URGENT | DOT & MEITY | First List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
Please send to the concerned division.

Regards,
Suneet Kumar Tomar
Director (Law)
Department of Telecommunication
Ministry of Communication
Government of India

============ Forwarded message ============
From: Law Division, DOT <law-dot@gov.in>
To: "Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Wed, 23 Sep 2026 09:54:37 +0530
Subject: Fwd: URGENT | DOT & MEITY | First List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

============ Forwarded message ============
From: Amit Agrawal <secy-telecom@gov.in>
To: "Law Division, DOT"<law-dot@gov.in>
Cc: "Sanjeev Gupta"<advisoro-dot@nic.in>
Date: Wed, 23 Sep 2026 09:51:56 +0530
Subject: Fwd: URGENT | DOT & MEITY | First List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Amit Agrawal
Secretary
Department of Telecommunications
2nd Floor, Sanchar Bhawan
Tele: 011-23719898, 23711209

<!-- page 7 -->

Email: secy-dot@nic.in; secy-telecom@gov.in

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Manish Shukla"
<dirit.hq-dgt-dot@gov.in>, <cyberlaw-legal@meity.gov.inss>, "Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"<pkumar@meity.gov.in>,
"Sathyanarayanan Subramanian"<sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Angad Makkar"
<angad@saikrishnaassociates.com>, "Raghav Goyal"
<raghav@saikrishnaassociates.com>
Date: Wed, 23 Sep 2026 00:05:11 +0530
Subject: URGENT | DOT & MEITY | First List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs. https://cinevood.love/
& Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
WITHOUT PREJUDICE
BY EMAIL

23.09.2026
To,
Defendant No. 12: Department of Telecommunications
secy-dot@nic.in
dirds2-dot@nic.in
dirit.hq-dgt-dot@gov.in
Defendant No. 13: Ministry of Electronics and Information Technology
cyberlaw-legal@meity.gov.inss
gccyberlaw@meity.gov.in
pkumar@meity.gov.in
sathya.s@meity.gov.in
Subject: URGENT | DOT & MEITY | First List of Additional Websites for Real – Time Blocking in
compliance of order dated 15.09.2026 passed by the Hon’ble High Court of Delhi in suit titled
Amazon Seller Service Private Limited vs. https://cinevood.love/ & Ors. [CS(COMM) 1002 of
2026]
Dear Sir,
We act on behalf of Amazon Seller Services Private Limited (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.
The Plaintiff is the first and exclusive owner of rights, including but not limited to intellectual
property rights and copyright, in the subject cinematograph film titled ‘VIBE’ (hereinafter
referred to as the “Film”), which was released theatrically across India on 18th September 2026.
The Film qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957 Act’) and, being
a work of visual recording with accompanying sound recordings, it further qualifies as a

<!-- page 8 -->

“cinematograph film” under Section 2(f) of the 1957 Act. Plaintiff being the exclusive first owner
and distributor of the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 of the 1957 Act and consequently has exclusive rights
enumerated under Section 14(d) of the 1957 Act.
Our Client has instituted the above-captioned Suit against various ‘rogue’ Websites, inter alia
Defendant Nos. 1 to 11, before the Hon’ble High Court of Delhi, on account of their unauthorized
hosting, streaming, and illegal communication of Our Client's copyrighted content, including the
cinematograph film ‘Nishaanchi’, and seeking permanent as well as ex-parte ad-interim and
temporary injunction restraining the infringement of Our Client's exclusive rights and copyright
in the Film by the said rogue websites, as well as for other reliefs.
Our Client has also arrayed Government departments i.e. Department of Telecommunication
(DoT) (Defendant No. 12) and the Ministry of Information and Technology (MEITY) (Defendant
No. 13) various Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 14 – 22) as
well as the concerned Domain Name Registrars (Defendant No. 23 – 34), to ensure effective
compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Ms. Jyoti Singh, Delhi High
Court on 15.09.2026, on which date, the Hon’ble Court was pleased to issue summons and notice
to you and was also pleased to pass an ex-parte ad-interim order in terms of Prayers at
Paragraph16 of application under Order XXXIX Rules 1 and 2 of the Code of Civil Procedure,
1908 (“CPC”). The relevant paragraphs of the Order dated 15.09.2026 are extracted herein below:
“35. Accordingly, till the next date of hearing, Defendants No. 1 to 11 and/or any person
acting on their behalf are restrained from in any manner communicating, hosting,
streaming and/or making available for viewing and downloading, without
authorization of the Plaintiff, the upcoming film VIBE on their websites or any other
electronic or digital platforms, in any manner whatsoever, amounting to infringement
of Plaintiff’s copyright.
36. Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the domain names
of Defendants No. 1 to 11, as indicated in ANNEXURE-A to this order, within 36 hours
from the date of receipt of copy of this order and file compliance affidavits within six
weeks.
37. Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants No. 1 to 11
websites forthwith on receipt of copy of this order. Defendants No. 12 and 13 shall issue
necessary notifications to the ISPs for blocking access to Defendants No. 1 to 11 websites
mentioned in ANNEXURE-A hereunder within 36 hours from the date of receipt of
copy of this order. Compliance affidavits shall be filed within six weeks from today.
38. Defendants No. 23 to 34 are directed to disclose complete details of Defendants No. 1
to 11 including email addresses, mobile numbers, contact details, payment details and
KYC details, to the extent available with them, within four weeks from today in a sealed
cover/password protected document.
39. It is further directed that if any other website is found to be unauthorizedly
streaming and communicating the film VIBE, over which Plaintiff has the copyright,
Plaintiff will be at liberty to communicate this information to Defendants No. 12 to 34
for blocking the websites on real time basis and upon receiving the intimation,
Defendants No. 14 to 34 shall take immediate steps to block and suspend the websites
and Defendants No. 12 and 13 shall issue necessary notification in this regard.”
In light of the above, the list of additional rogue websites discovered till date during the currency
of the proceeding is attached herewith. These websites are illegally streaming and communicating
the Film over which Our Client has exclusive rights and copyright.
You are hereby requested to comply with the order dated 15.09.2026 by immediately issuing
notification to all the ISPs registered under you to block access to the identified rogue websites
during the course of the proceeding, on a real-time basis so that there is no delay.

<!-- page 9 -->

The next date of hearing in the captioned matter is 19.01.2027 before the Hon’ble Court and
07.10.2026 before the Ld. Joint Registrar.
For your convenience, please find attached the Order dated 15.09.2026, passed by the Hon’ble
Court of Justice Jyoti Singh, Delhi High Court.
List of the additional websites is also enclosed herewith and the evidence against the websites is
available in the link below:
https://drive.google.com/drive/folders/1S73miEa91ap_tjqGB2ZBWdEm0CpnMYgj?usp=sharing
If you have any queries regarding this matter, please feel free to reach out to the following:
mrawat@saikrishnaassociates.com
Please acknowledge a safe receipt.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiff

Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of legal
professional privilege, not being waived or lost by mistaken transmission or receipt.
If you have received this mail in error, please notify us at
info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)
Order dated 15.09.2026.pdf

First List.xlsx

<!-- page 10 -->

423 7 KB

10 2 KB

<!-- page 11 -->

List - 1
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14

Website Name
9xmovie.int.in
jalshamoviez.farm
fmovies.direct
movielinkhub.net
vegamoviess.foo
sflix.today
cinevood.rocks
d10.downloadhub.food
hdmovie2a.live
movieshunt.monster
vegamovito.ltd
newhdmovie2.club
hdmoviefan.com
hdmovie2r.boo

Registrar
Dynadot, LLC
NameCheap, Inc.
Tucows Domains Inc.
NameSilo, LLC
Devexpanse Ltd
Tucows Domains Inc.
Dynadot Inc
Tucows Domains Inc.
Dynadot Inc
Spaceship, Inc.
Spaceship, Inc.
Dynadot Inc
Dynadot Inc
Spaceship, Inc.

<!-- page 12 -->

const1.hq-dgt-dot < const1.hq-dgt-dot@govcontractor.nic.in >

Fwd: URGENT | DOT & MEITY | Second List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]

Subodh Saxena < ddgit.hq-dgt-dot@gov.in >
Sat, 26 Sep 2026 8:26:11 PM +0530
To "Manish Shukla"<dirit.hq-dgt-dot@gov.in>,"ADG Technology DGT HQ"<adgnt.hq-dgtdot@gov.in>,"Arun Kumar"<consnt.hq-dgt-dot@govcontractor.nic.in>,"Kripa Shanker
Pandey"<adt.hq-dgt-dot@gov.in>,"SUNIL KUMAR"<const1.hq-dgtdot@govcontractor.nic.in>

============ Forwarded message ============
From: VINAY . <vinay.2009@gov.in>
To: "Prem Chand Sharma"<ddga.hq-dgt-dot@gov.in>, "Subodh Saxena"<ddgit.hqdgt-dot@gov.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Thu, 24 Sep 2026 10:38:32 +0530
Subject: Fwd: URGENT | DOT & MEITY | Second List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Sir/Madam,
Please refer to the trailing email on the above subject.
The present case pertaining to blocking of websites/URLs/domains regarding the
infringement of copyright/ trademark/ patent/ exclusive rights of the plaintiff. Such type
of matters are being dealt by the Office of DG(Telecom) , hence, it is being forwarded for
necessary action in the matter, please. It is also requested to register the case on the
LIMBS portal if not registered yet.
Regards,
Vinay
Assistant Section Officer (Legal)
Law Division, DoT

<!-- page 13 -->

============ Forwarded message ============
From: Suneet Kumar Tomar <dirlaw-dot@gov.in>
To: "VINAY ."<vinay.2009@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Nuruddin"<nuruddin.69@nic.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Rohit Meena"<rohit.meena29@gov.in>
Date: Wed, 23 Sep 2026 17:56:29 +0530
Subject: Fwd: URGENT | DOT & MEITY | Second List of Additional Websites for Real
– Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
Please send to the concerned division

Regards,
Suneet Kumar Tomar
Director (Law)
Department of Telecommunication
Ministry of Communication
Government of India

============ Forwarded message ============
From: Law Division, DOT <law-dot@gov.in>
To: "Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Wed, 23 Sep 2026 16:50:55 +0530
Subject: Fwd: URGENT | DOT & MEITY | Second List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

============ Forwarded message ============
From: Amit Agrawal <secy-telecom@gov.in>
To: "Law Division, DOT"<law-dot@gov.in>
Date: Wed, 23 Sep 2026 12:27:58 +0530
Subject: Fwd: URGENT | DOT & MEITY | Second List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Amit Agrawal
Secretary
Department of Telecommunications
2nd Floor, Sanchar Bhawan
Tele: 011-23719898, 23711209

<!-- page 14 -->

Email: secy-dot@nic.in; secy-telecom@gov.in

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Manish Shukla"
<dirit.hq-dgt-dot@gov.in>, <cyberlaw-legal@meity.gov.inss>, "Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"<pkumar@meity.gov.in>,
"Sathyanarayanan Subramanian"<sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Angad Makkar"
<angad@saikrishnaassociates.com>, "Raghav Goyal"
<raghav@saikrishnaassociates.com>
Date: Wed, 23 Sep 2026 12:20:18 +0530
Subject: URGENT | DOT & MEITY | Second List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs. https://cinevood.love/
& Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
WITHOUT PREJUDICE
BY EMAIL

23.09.2026
To,
Defendant No. 12: Department of Telecommunications
secy-dot@nic.in
dirds2-dot@nic.in
dirit.hq-dgt-dot@gov.in
Defendant No. 13: Ministry of Electronics and Information Technology
cyberlaw-legal@meity.gov.inss
gccyberlaw@meity.gov.in
pkumar@meity.gov.in
sathya.s@meity.gov.in
Subject: URGENT | DOT & MEITY | Second List of Additional Websites for Real – Time Blocking
in compliance of order dated 15.09.2026 passed by the Hon’ble High Court of Delhi in suit titled
Amazon Seller Service Private Limited vs. https://cinevood.love/ & Ors. [CS(COMM) 1002 of
2026]
Dear Sir,
We act on behalf of Amazon Seller Services Private Limited (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.
The Plaintiff is the first and exclusive owner of rights, including but not limited to intellectual
property rights and copyright, in the subject cinematograph film titled ‘VIBE’ (hereinafter
referred to as the “Film”), which was released theatrically across India on 18th September 2026.
The Film qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957 Act’) and, being
a work of visual recording with accompanying sound recordings, it further qualifies as a

<!-- page 15 -->

“cinematograph film” under Section 2(f) of the 1957 Act. Plaintiff being the exclusive first owner
and distributor of the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 of the 1957 Act and consequently has exclusive rights
enumerated under Section 14(d) of the 1957 Act.
Our Client has instituted the above-captioned Suit against various ‘rogue’ Websites, inter alia
Defendant Nos. 1 to 11, before the Hon’ble High Court of Delhi, on account of their unauthorized
hosting, streaming, and illegal communication of Our Client's copyrighted content, including the
cinematograph film ‘Nishaanchi’, and seeking permanent as well as ex-parte ad-interim and
temporary injunction restraining the infringement of Our Client's exclusive rights and copyright
in the Film by the said rogue websites, as well as for other reliefs.
Our Client has also arrayed Government departments i.e. Department of Telecommunication
(DoT) (Defendant No. 12) and the Ministry of Information and Technology (MEITY) (Defendant
No. 13) various Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 14 – 22) as
well as the concerned Domain Name Registrars (Defendant No. 23 – 34), to ensure effective
compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Ms. Jyoti Singh, Delhi High
Court on 15.09.2026, on which date, the Hon’ble Court was pleased to issue summons and notice
to you and was also pleased to pass an ex-parte ad-interim order in terms of Prayers at
Paragraph16 of application under Order XXXIX Rules 1 and 2 of the Code of Civil Procedure,
1908 (“CPC”). The relevant paragraphs of the Order dated 15.09.2026 are extracted herein below:
“35. Accordingly, till the next date of hearing, Defendants No. 1 to 11 and/or any person
acting on their behalf are restrained from in any manner communicating, hosting,
streaming and/or making available for viewing and downloading, without
authorization of the Plaintiff, the upcoming film VIBE on their websites or any other
electronic or digital platforms, in any manner whatsoever, amounting to infringement
of Plaintiff’s copyright.
36. Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the domain names
of Defendants No. 1 to 11, as indicated in ANNEXURE-A to this order, within 36 hours
from the date of receipt of copy of this order and file compliance affidavits within six
weeks.
37. Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants No. 1 to 11
websites forthwith on receipt of copy of this order. Defendants No. 12 and 13 shall issue
necessary notifications to the ISPs for blocking access to Defendants No. 1 to 11 websites
mentioned in ANNEXURE-A hereunder within 36 hours from the date of receipt of
copy of this order. Compliance affidavits shall be filed within six weeks from today.
38. Defendants No. 23 to 34 are directed to disclose complete details of Defendants No. 1
to 11 including email addresses, mobile numbers, contact details, payment details and
KYC details, to the extent available with them, within four weeks from today in a sealed
cover/password protected document.
39. It is further directed that if any other website is found to be unauthorizedly
streaming and communicating the film VIBE, over which Plaintiff has the copyright,
Plaintiff will be at liberty to communicate this information to Defendants No. 12 to 34
for blocking the websites on real time basis and upon receiving the intimation,
Defendants No. 14 to 34 shall take immediate steps to block and suspend the websites
and Defendants No. 12 and 13 shall issue necessary notification in this regard.”
In light of the above, the list of additional rogue websites discovered till date during the currency
of the proceeding is attached herewith. These websites are illegally streaming and communicating
the Film over which Our Client has exclusive rights and copyright.
You are hereby requested to comply with the order dated 15.09.2026 by immediately issuing
notification to all the ISPs registered under you to block access to the identified rogue websites
during the course of the proceeding, on a real-time basis so that there is no delay.

<!-- page 16 -->

The next date of hearing in the captioned matter is 19.01.2027 before the Hon’ble Court and
07.10.2026 before the Ld. Joint Registrar.
For your convenience, please find attached the Order dated 15.09.2026, passed by the Hon’ble
Court of Justice Jyoti Singh, Delhi High Court.
List of the additional websites is also enclosed herewith and the evidence against the websites is
available in the link below:
https://drive.google.com/drive/folders/1KH8MVgXh6BEghzlxxtUychfkkE5tMq11?usp=sharing
If you have any queries regarding this matter, please feel free to reach out to the following:
mrawat@saikrishnaassociates.com
Please acknowledge a safe receipt.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiff
Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of legal
professional privilege, not being waived or lost by mistaken transmission or receipt.
If you have received this mail in error, please notify us at
info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)
Second List.xlsx

Order dated 15.09.2026.pdf

<!-- page 17 -->

10 5 KB

423 7 KB

<!-- page 18 -->

List - 2
S.No.
1
2
3
4
5
6
7
8
9
10
11

Website Name
moviezguru.farm
ww5-fmovies.com
hindilinks4u.energy
yomovies.church
moviedrivebd.com
filmywap.bet
7sttarhd.diy
filmyzilla69.com.in
cinevood.net
ww2.themoviesboss.blog
mp4law.com

Registrar
NameCheap, Inc.
Internet Domain Service BS Corp
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Dynadot Inc
Dynadot, LLC
Dynadot, LLC
Tucows Domains Inc.
Dynadot LLC
Dynadot Inc

<!-- page 19 -->

const1.hq-dgt-dot < const1.hq-dgt-dot@govcontractor.nic.in >

Fwd: URGENT | DOT & MEITY | Third List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]

Subodh Saxena < ddgit.hq-dgt-dot@gov.in >
Sat, 26 Sep 2026 8:25:54 PM +0530
To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>,"Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>,"SUNIL
KUMAR"<const1.hq-dgt-dot@govcontractor.nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>

============ Forwarded message ============
From: VINAY . <vinay.2009@gov.in>
To: "Prem Chand Sharma"<ddga.hq-dgt-dot@gov.in>, "Subodh Saxena"<ddgit.hqdgt-dot@gov.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Thu, 24 Sep 2026 10:38:59 +0530
Subject: Fwd: URGENT | DOT & MEITY | Third List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Sir/Madam,
Please refer to the trailing email on the above subject.
The present case pertaining to blocking of websites/URLs/domains regarding the
infringement of copyright/ trademark/ patent/ exclusive rights of the plaintiff. Such type
of matters are being dealt by the Office of DG(Telecom) , hence, it is being forwarded for
necessary action in the matter, please. It is also requested to register the case on the
LIMBS portal if not registered yet.
Regards,
Vinay
Assistant Section Officer (Legal)
Law Division, DoT

<!-- page 20 -->

============ Forwarded message ============
From: Suneet Kumar Tomar <dirlaw-dot@gov.in>
To: "VINAY ."<vinay.2009@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Nuruddin"<nuruddin.69@nic.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Rohit Meena"<rohit.meena29@gov.in>
Date: Wed, 23 Sep 2026 17:56:54 +0530
Subject: Fwd: URGENT | DOT & MEITY | Third List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
Please send to the concerned division

Regards,
Suneet Kumar Tomar
Director (Law)
Department of Telecommunication
Ministry of Communication
Government of India

============ Forwarded message ============
From: Law Division, DOT <law-dot@gov.in>
To: "Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Wed, 23 Sep 2026 16:51:50 +0530
Subject: Fwd: URGENT | DOT & MEITY | Third List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

============ Forwarded message ============
From: Amit Agrawal <secy-telecom@gov.in>
To: "Law Division, DOT"<law-dot@gov.in>
Date: Wed, 23 Sep 2026 16:10:38 +0530
Subject: Fwd: URGENT | DOT & MEITY | Third List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Amit Agrawal
Secretary
Department of Telecommunications
2nd Floor, Sanchar Bhawan
Tele: 011-23719898, 23711209

<!-- page 21 -->

Email: secy-dot@nic.in; secy-telecom@gov.in

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Manish Shukla"
<dirit.hq-dgt-dot@gov.in>, <cyberlaw-legal@meity.gov.inss>, "Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"<pkumar@meity.gov.in>,
"Sathyanarayanan Subramanian"<sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Angad Makkar"
<angad@saikrishnaassociates.com>, "Raghav Goyal"
<raghav@saikrishnaassociates.com>
Date: Wed, 23 Sep 2026 15:58:11 +0530
Subject: URGENT | DOT & MEITY | Third List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs. https://cinevood.love/
& Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
WITHOUT PREJUDICE
BY EMAIL

23.09.2026
To,
Defendant No. 12: Department of Telecommunications
secy-dot@nic.in
dirds2-dot@nic.in
dirit.hq-dgt-dot@gov.in
Defendant No. 13: Ministry of Electronics and Information Technology
cyberlaw-legal@meity.gov.inss
gccyberlaw@meity.gov.in
pkumar@meity.gov.in
sathya.s@meity.gov.in
Subject: URGENT | DOT & MEITY | Third List of Additional Websites for Real – Time Blocking
in compliance of order dated 15.09.2026 passed by the Hon’ble High Court of Delhi in suit titled
Amazon Seller Service Private Limited vs. https://cinevood.love/ & Ors. [CS(COMM) 1002 of
2026]
Dear Sir,
We act on behalf of Amazon Seller Services Private Limited (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.
The Plaintiff is the first and exclusive owner of rights, including but not limited to intellectual
property rights and copyright, in the subject cinematograph film titled ‘VIBE’ (hereinafter
referred to as the “Film”), which was released theatrically across India on 18th September 2026.
The Film qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957 Act’) and, being
a work of visual recording with accompanying sound recordings, it further qualifies as a

<!-- page 22 -->

“cinematograph film” under Section 2(f) of the 1957 Act. Plaintiff being the exclusive first owner
and distributor of the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 of the 1957 Act and consequently has exclusive rights
enumerated under Section 14(d) of the 1957 Act.
Our Client has instituted the above-captioned Suit against various ‘rogue’ Websites, inter alia
Defendant Nos. 1 to 11, before the Hon’ble High Court of Delhi, on account of their unauthorized
hosting, streaming, and illegal communication of Our Client's copyrighted content, including the
cinematograph film ‘Nishaanchi’, and seeking permanent as well as ex-parte ad-interim and
temporary injunction restraining the infringement of Our Client's exclusive rights and copyright
in the Film by the said rogue websites, as well as for other reliefs.
Our Client has also arrayed Government departments i.e. Department of Telecommunication
(DoT) (Defendant No. 12) and the Ministry of Information and Technology (MEITY) (Defendant
No. 13) various Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 14 – 22) as
well as the concerned Domain Name Registrars (Defendant No. 23 – 34), to ensure effective
compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Ms. Jyoti Singh, Delhi High
Court on 15.09.2026, on which date, the Hon’ble Court was pleased to issue summons and notice
to you and was also pleased to pass an ex-parte ad-interim order in terms of Prayers at
Paragraph16 of application under Order XXXIX Rules 1 and 2 of the Code of Civil Procedure,
1908 (“CPC”). The relevant paragraphs of the Order dated 15.09.2026 are extracted herein below:
“35. Accordingly, till the next date of hearing, Defendants No. 1 to 11 and/or any person
acting on their behalf are restrained from in any manner communicating, hosting,
streaming and/or making available for viewing and downloading, without
authorization of the Plaintiff, the upcoming film VIBE on their websites or any other
electronic or digital platforms, in any manner whatsoever, amounting to infringement
of Plaintiff’s copyright.
36. Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the domain names
of Defendants No. 1 to 11, as indicated in ANNEXURE-A to this order, within 36 hours
from the date of receipt of copy of this order and file compliance affidavits within six
weeks.
37. Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants No. 1 to 11
websites forthwith on receipt of copy of this order. Defendants No. 12 and 13 shall issue
necessary notifications to the ISPs for blocking access to Defendants No. 1 to 11 websites
mentioned in ANNEXURE-A hereunder within 36 hours from the date of receipt of
copy of this order. Compliance affidavits shall be filed within six weeks from today.
38. Defendants No. 23 to 34 are directed to disclose complete details of Defendants No. 1
to 11 including email addresses, mobile numbers, contact details, payment details and
KYC details, to the extent available with them, within four weeks from today in a sealed
cover/password protected document.
39. It is further directed that if any other website is found to be unauthorizedly
streaming and communicating the film VIBE, over which Plaintiff has the copyright,
Plaintiff will be at liberty to communicate this information to Defendants No. 12 to 34
for blocking the websites on real time basis and upon receiving the intimation,
Defendants No. 14 to 34 shall take immediate steps to block and suspend the websites
and Defendants No. 12 and 13 shall issue necessary notification in this regard.”
In light of the above, the list of additional rogue websites discovered till date during the currency
of the proceeding is attached herewith. These websites are illegally streaming and communicating
the Film over which Our Client has exclusive rights and copyright.
You are hereby requested to comply with the order dated 15.09.2026 by immediately issuing
notification to all the ISPs registered under you to block access to the identified rogue websites
during the course of the proceeding, on a real-time basis so that there is no delay.

<!-- page 23 -->

The next date of hearing in the captioned matter is 19.01.2027 before the Hon’ble Court and
07.10.2026 before the Ld. Joint Registrar.
For your convenience, please find attached the Order dated 15.09.2026, passed by the Hon’ble
Court of Justice Jyoti Singh, Delhi High Court.
List of the additional websites is also enclosed herewith and the evidence against the websites is
available in the link below:
https://drive.google.com/drive/folders/1KxNNZEGfXEuxaLXlUmJYhWU5Cxwmdo5_?
usp=sharing
If you have any queries regarding this matter, please feel free to reach out to the following:
mrawat@saikrishnaassociates.com
Please acknowledge a safe receipt.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiff
Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of legal
professional privilege, not being waived or lost by mistaken transmission or receipt.
If you have received this mail in error, please notify us at
info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)
Third List.xlsx

Order dated 15.09.2026.pdf

<!-- page 24 -->

10.9 KB

423.7 KB

<!-- page 25 -->

List - 3
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24

Website Name
prmovies.church
ofilmywap.fyi
flixfoxweb.app
hindilinks4u.asia
mlsbd.co
sd4.sdmoviespoint.tours
moviesbazar.pk
movierulzhome.com
sitenp.com
bollypro.com
watchofree.website
moviezmad.co
hhdmovies.study
moviehubbd.my
watch-movies.com.pk
moviesnation.energy
allmovieshub.coffee
rogmovies.bar
ssrmovies.jetzt
9xmoviies.mobile
ssrmovies.blue
8xfilms.net
vegamovies.ws
movies-x.com

Registrar
NameCheap, Inc.
Dynadot Inc
GoDaddy.com, LLC
NameCheap, Inc.
Tucows Domains Inc.
NameCheap, Inc.
PKNIC
Dynadot Inc
Realtime Register B.V.
Dynadot Inc
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Spaceship, Inc.
PKNIC
NameCheap, Inc.
NameCheap, Inc.
NAMECHEAP
Dynadot Inc
DYNADOT LLC
OVH SAS
Dynadot Inc
Namecheap, Inc.
Dynadot Inc

<!-- page 26 -->

const1.hq-dgt-dot < const1.hq-dgt-dot@govcontractor.nic.in >

Fwd: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]

Subodh Saxena < ddgit.hq-dgt-dot@gov.in >
Sat, 26 Sep 2026 8:13:28 PM +0530
To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>,"Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>,"SUNIL
KUMAR"<const1.hq-dgt-dot@govcontractor.nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>

============ Forwarded message ============
From: VINAY . <vinay.2009@gov.in>
To: "Prem Chand Sharma"<ddga.hq-dgt-dot@gov.in>, "Subodh Saxena"<ddgit.hqdgt-dot@gov.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Fri, 25 Sep 2026 11:07:51 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Sir/Madam,
Please refer to the trailing email on the above subject.
The present case pertaining to blocking of websites/URLs/domains regarding the
infringement of copyright/ trademark/ patent/ exclusive rights of the plaintiff. Such type
of matters are being dealt by the Office of DG(Telecom) , hence, it is being forwarded for
necessary action in the matter, please. It is also requested to register the case on the
LIMBS portal if not registered yet.
Regards,
Vinay
Assistant Section Officer (Legal)
Law Division, DoT

<!-- page 27 -->

============ Forwarded message ============
From: Suneet Kumar Tomar <dirlaw-dot@gov.in>
To: "VINAY ."<vinay.2009@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Nuruddin"<nuruddin.69@nic.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Rohit Meena"<rohit.meena29@gov.in>
Date: Fri, 25 Sep 2026 09:43:30 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
Please send to the concerned division.

Regards,
Suneet Kumar Tomar
Director (Law)
Department of Telecommunication
Ministry of Communication
Government of India

============ Forwarded message ============
From: Law Division, DOT <law-dot@gov.in>
To: "Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Fri, 25 Sep 2026 09:30:09 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

============ Forwarded message ============
From: Amit Agrawal <secy-telecom@gov.in>
To: "Law Division, DOT"<law-dot@gov.in>
Date: Fri, 25 Sep 2026 09:13:27 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Amit Agrawal
Secretary
Department of Telecommunications
2nd Floor, Sanchar Bhawan
Tele: 011-23719898, 23711209

<!-- page 28 -->

Email: secy-dot@nic.in; secy-telecom@gov.in

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Manish Shukla"
<dirit.hq-dgt-dot@gov.in>, <cyberlaw-legal@meity.gov.inss>, "Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"<pkumar@meity.gov.in>,
"Sathyanarayanan Subramanian"<sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Angad Makkar"
<angad@saikrishnaassociates.com>, "Raghav Goyal"
<raghav@saikrishnaassociates.com>
Date: Thu, 24 Sep 2026 22:46:28 +0530
Subject: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs. https://cinevood.love/
& Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
WITHOUT PREJUDICE
BY EMAIL

24.09.2026
To,
Defendant No. 12: Department of Telecommunications
secy-dot@nic.in
dirds2-dot@nic.in
dirit.hq-dgt-dot@gov.in
Defendant No. 13: Ministry of Electronics and Information Technology
cyberlaw-legal@meity.gov.inss
gccyberlaw@meity.gov.in
pkumar@meity.gov.in
sathya.s@meity.gov.in
Subject: URGENT | DOT & MEITY | Fourth List of Additional Websites for Real – Time Blocking
in compliance of order dated 15.09.2026 passed by the Hon’ble High Court of Delhi in suit titled
Amazon Seller Service Private Limited vs. https://cinevood.love/ & Ors. [CS(COMM) 1002 of
2026]
Dear Sir,
We act on behalf of Amazon Seller Services Private Limited (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.
The Plaintiff is the first and exclusive owner of rights, including but not limited to intellectual
property rights and copyright, in the subject cinematograph film titled ‘VIBE’ (hereinafter
referred to as the “Film”), which was released theatrically across India on 18th September 2026.
The Film qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957 Act’) and, being
a work of visual recording with accompanying sound recordings, it further qualifies as a

<!-- page 29 -->

“cinematograph film” under Section 2(f) of the 1957 Act. Plaintiff being the exclusive first owner
and distributor of the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 of the 1957 Act and consequently has exclusive rights
enumerated under Section 14(d) of the 1957 Act.
Our Client has instituted the above-captioned Suit against various ‘rogue’ Websites, inter alia
Defendant Nos. 1 to 11, before the Hon’ble High Court of Delhi, on account of their unauthorized
hosting, streaming, and illegal communication of Our Client's copyrighted content, including the
cinematograph film ‘Nishaanchi’, and seeking permanent as well as ex-parte ad-interim and
temporary injunction restraining the infringement of Our Client's exclusive rights and copyright
in the Film by the said rogue websites, as well as for other reliefs.
Our Client has also arrayed Government departments i.e. Department of Telecommunication
(DoT) (Defendant No. 12) and the Ministry of Information and Technology (MEITY) (Defendant
No. 13) various Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 14 – 22) as
well as the concerned Domain Name Registrars (Defendant No. 23 – 34), to ensure effective
compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Ms. Jyoti Singh, Delhi High
Court on 15.09.2026, on which date, the Hon’ble Court was pleased to issue summons and notice
to you and was also pleased to pass an ex-parte ad-interim order in terms of Prayers at
Paragraph16 of application under Order XXXIX Rules 1 and 2 of the Code of Civil Procedure,
1908 (“CPC”). The relevant paragraphs of the Order dated 15.09.2026 are extracted herein below:
“35. Accordingly, till the next date of hearing, Defendants No. 1 to 11 and/or any person
acting on their behalf are restrained from in any manner communicating, hosting,
streaming and/or making available for viewing and downloading, without
authorization of the Plaintiff, the upcoming film VIBE on their websites or any other
electronic or digital platforms, in any manner whatsoever, amounting to infringement
of Plaintiff’s copyright.
36. Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the domain names
of Defendants No. 1 to 11, as indicated in ANNEXURE-A to this order, within 36 hours
from the date of receipt of copy of this order and file compliance affidavits within six
weeks.
37. Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants No. 1 to 11
websites forthwith on receipt of copy of this order. Defendants No. 12 and 13 shall issue
necessary notifications to the ISPs for blocking access to Defendants No. 1 to 11 websites
mentioned in ANNEXURE-A hereunder within 36 hours from the date of receipt of
copy of this order. Compliance affidavits shall be filed within six weeks from today.
38. Defendants No. 23 to 34 are directed to disclose complete details of Defendants No. 1
to 11 including email addresses, mobile numbers, contact details, payment details and
KYC details, to the extent available with them, within four weeks from today in a sealed
cover/password protected document.
39. It is further directed that if any other website is found to be unauthorizedly
streaming and communicating the film VIBE, over which Plaintiff has the copyright,
Plaintiff will be at liberty to communicate this information to Defendants No. 12 to 34
for blocking the websites on real time basis and upon receiving the intimation,
Defendants No. 14 to 34 shall take immediate steps to block and suspend the websites
and Defendants No. 12 and 13 shall issue necessary notification in this regard.”
In light of the above, the list of additional rogue websites discovered till date during the currency
of the proceeding is attached herewith. These websites are illegally streaming and communicating
the Film over which Our Client has exclusive rights and copyright.
You are hereby requested to comply with the order dated 15.09.2026 by immediately issuing
notification to all the ISPs registered under you to block access to the identified rogue websites
during the course of the proceeding, on a real-time basis so that there is no delay.

<!-- page 30 -->

The next date of hearing in the captioned matter is 19.01.2027 before the Hon’ble Court and
07.10.2026 before the Ld. Joint Registrar.
For your convenience, please find attached the Order dated 15.09.2026, passed by the Hon’ble
Court of Justice Jyoti Singh, Delhi High Court.
List of the additional websites is also enclosed herewith and the evidence against the websites is
available in the link below:
https://drive.google.com/drive/folders/1yzQ1EXdI-cNxl2I6ixr15Qj97uXn2qhL?usp=sharing
If you have any queries regarding this matter, please feel free to reach out to the following:
mrawat@saikrishnaassociates.com
Please acknowledge a safe receipt.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiff
Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of legal
professional privilege, not being waived or lost by mistaken transmission or receipt.
If you have received this mail in error, please notify us at
info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)
Order dated 15.09.2026.pdf

List 4.xlsx

<!-- page 31 -->

423 7 KB

10 1 KB

<!-- page 32 -->

List - 4
S.No.
1
2
3
4
5
6
7
8
9
10
11
12

Domains
7starhdc.com
hdmovies23.cards
filmesv.com
9xmovie.lat
hdmovie88.club
moviespapa.delhi.in
vega-care.com
katmoviehdonline.com
9xmovie.kaufen
bdmusic23.watch
11xmovies.online
cinemalux.mom

Registrar
Gransy, s.r.o.
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot, LLC
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot Inc
Dynadot Inc
Spaceship, Inc.

<!-- page 33 -->

const1.hq-dgt-dot < const1.hq-dgt-dot@govcontractor.nic.in >

Fwd: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]

Subodh Saxena < ddgit.hq-dgt-dot@gov.in >
Sat, 26 Sep 2026 8:14:03 PM +0530
To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>,"Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>,"SUNIL
KUMAR"<const1.hq-dgt-dot@govcontractor.nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>

============ Forwarded message ============
From: VINAY . <vinay.2009@gov.in>
To: "Prem Chand Sharma"<ddga.hq-dgt-dot@gov.in>, "Subodh Saxena"<ddgit.hqdgt-dot@gov.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Fri, 25 Sep 2026 11:07:30 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Sir/Madam,
Please refer to the trailing email on the above subject.
The present case pertaining to blocking of websites/URLs/domains regarding the
infringement of copyright/ trademark/ patent/ exclusive rights of the plaintiff. Such type
of matters are being dealt by the Office of DG(Telecom) , hence, it is being forwarded for
necessary action in the matter, please. It is also requested to register the case on the
LIMBS portal if not registered yet.
Regards,
Vinay
Assistant Section Officer (Legal)
Law Division, DoT

<!-- page 34 -->

============ Forwarded message ============
From: Suneet Kumar Tomar <dirlaw-dot@gov.in>
To: "VINAY ."<vinay.2009@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Nuruddin"<nuruddin.69@nic.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Rohit Meena"<rohit.meena29@gov.in>
Date: Fri, 25 Sep 2026 09:21:07 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
Please send to the concerned division.

Regards,
Suneet Kumar Tomar
Director (Law)
Department of Telecommunication
Ministry of Communication
Government of India

============ Forwarded message ============
From: Law Division, DOT <law-dot@gov.in>
To: "Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Fri, 25 Sep 2026 09:17:57 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

============ Forwarded message ============
From: Amit Agrawal <secy-telecom@gov.in>
To: "Law Division, DOT"<law-dot@gov.in>
Date: Fri, 25 Sep 2026 09:14:51 +0530
Subject: Fwd: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Amit Agrawal
Secretary
Department of Telecommunications
2nd Floor, Sanchar Bhawan
Tele: 011-23719898, 23711209

<!-- page 35 -->

Email: secy-dot@nic.in; secy-telecom@gov.in

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Manish Shukla"
<dirit.hq-dgt-dot@gov.in>, <cyberlaw-legal@meity.gov.inss>, "Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"<pkumar@meity.gov.in>,
"Sathyanarayanan Subramanian"<sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Angad Makkar"
<angad@saikrishnaassociates.com>, "Raghav Goyal"
<raghav@saikrishnaassociates.com>
Date: Thu, 24 Sep 2026 23:29:56 +0530
Subject: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs. https://cinevood.love/
& Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
WITHOUT PREJUDICE
BY EMAIL

24.09.2026
To,
Defendant No. 12: Department of Telecommunications
secy-dot@nic.in
dirds2-dot@nic.in
dirit.hq-dgt-dot@gov.in
Defendant No. 13: Ministry of Electronics and Information Technology
cyberlaw-legal@meity.gov.inss
gccyberlaw@meity.gov.in
pkumar@meity.gov.in
sathya.s@meity.gov.in
Subject: URGENT | DOT & MEITY | Fifth List of Additional Websites for Real – Time Blocking in
compliance of order dated 15.09.2026 passed by the Hon’ble High Court of Delhi in suit titled
Amazon Seller Service Private Limited vs. https://cinevood.love/ & Ors. [CS(COMM) 1002 of
2026]
Dear Sir,
We act on behalf of Amazon Seller Services Private Limited (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.
The Plaintiff is the first and exclusive owner of rights, including but not limited to intellectual
property rights and copyright, in the subject cinematograph film titled ‘VIBE’ (hereinafter
referred to as the “Film”), which was released theatrically across India on 18th September 2026.
The Film qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957 Act’) and, being
a work of visual recording with accompanying sound recordings, it further qualifies as a

<!-- page 36 -->

“cinematograph film” under Section 2(f) of the 1957 Act. Plaintiff being the exclusive first owner
and distributor of the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 of the 1957 Act and consequently has exclusive rights
enumerated under Section 14(d) of the 1957 Act.
Our Client has instituted the above-captioned Suit against various ‘rogue’ Websites, inter alia
Defendant Nos. 1 to 11, before the Hon’ble High Court of Delhi, on account of their unauthorized
hosting, streaming, and illegal communication of Our Client's copyrighted content, including the
cinematograph film ‘Nishaanchi’, and seeking permanent as well as ex-parte ad-interim and
temporary injunction restraining the infringement of Our Client's exclusive rights and copyright
in the Film by the said rogue websites, as well as for other reliefs.
Our Client has also arrayed Government departments i.e. Department of Telecommunication
(DoT) (Defendant No. 12) and the Ministry of Information and Technology (MEITY) (Defendant
No. 13) various Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 14 – 22) as
well as the concerned Domain Name Registrars (Defendant No. 23 – 34), to ensure effective
compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Ms. Jyoti Singh, Delhi High
Court on 15.09.2026, on which date, the Hon’ble Court was pleased to issue summons and notice
to you and was also pleased to pass an ex-parte ad-interim order in terms of Prayers at
Paragraph16 of application under Order XXXIX Rules 1 and 2 of the Code of Civil Procedure,
1908 (“CPC”). The relevant paragraphs of the Order dated 15.09.2026 are extracted herein below:
“35. Accordingly, till the next date of hearing, Defendants No. 1 to 11 and/or any person
acting on their behalf are restrained from in any manner communicating, hosting,
streaming and/or making available for viewing and downloading, without
authorization of the Plaintiff, the upcoming film VIBE on their websites or any other
electronic or digital platforms, in any manner whatsoever, amounting to infringement
of Plaintiff’s copyright.
36. Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the domain names
of Defendants No. 1 to 11, as indicated in ANNEXURE-A to this order, within 36 hours
from the date of receipt of copy of this order and file compliance affidavits within six
weeks.
37. Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants No. 1 to 11
websites forthwith on receipt of copy of this order. Defendants No. 12 and 13 shall issue
necessary notifications to the ISPs for blocking access to Defendants No. 1 to 11 websites
mentioned in ANNEXURE-A hereunder within 36 hours from the date of receipt of
copy of this order. Compliance affidavits shall be filed within six weeks from today.
38. Defendants No. 23 to 34 are directed to disclose complete details of Defendants No. 1
to 11 including email addresses, mobile numbers, contact details, payment details and
KYC details, to the extent available with them, within four weeks from today in a sealed
cover/password protected document.
39. It is further directed that if any other website is found to be unauthorizedly
streaming and communicating the film VIBE, over which Plaintiff has the copyright,
Plaintiff will be at liberty to communicate this information to Defendants No. 12 to 34
for blocking the websites on real time basis and upon receiving the intimation,
Defendants No. 14 to 34 shall take immediate steps to block and suspend the websites
and Defendants No. 12 and 13 shall issue necessary notification in this regard.”
In light of the above, the list of additional rogue websites discovered till date during the currency
of the proceeding is attached herewith. These websites are illegally streaming and communicating
the Film over which Our Client has exclusive rights and copyright.
You are hereby requested to comply with the order dated 15.09.2026 by immediately issuing
notification to all the ISPs registered under you to block access to the identified rogue websites
during the course of the proceeding, on a real-time basis so that there is no delay.

<!-- page 37 -->

The next date of hearing in the captioned matter is 19.01.2027 before the Hon’ble Court and
07.10.2026 before the Ld. Joint Registrar.
For your convenience, please find attached the Order dated 15.09.2026, passed by the Hon’ble
Court of Justice Jyoti Singh, Delhi High Court.
List of the additional websites is also enclosed herewith and the evidence against the websites is
available in the link below:
https://drive.google.com/drive/folders/1gpW8LuFYZfre0BCQ2iOlqWd9fW50AxNu?usp=sharing
If you have any queries regarding this matter, please feel free to reach out to the following:
mrawat@saikrishnaassociates.com
Please acknowledge a safe receipt.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiff
Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of legal
professional privilege, not being waived or lost by mistaken transmission or receipt.
If you have received this mail in error, please notify us at
info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)
Order dated 15.09.2026.pdf

List 5.xlsx

<!-- page 38 -->

423 7 KB

10 3 KB

<!-- page 39 -->

List - 5
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14

Domains
cinevood.rent
9kmovies2.life
kmmovies.rest
7starhd.wiki
ddrmovies.fyi
themoviesflix.voto
rogmovies.onl
dotmorr.com
9xmovie.network
10xflix.fit
vegamoviess.mobi
dudefilms.stream
mkvcinemas.study
bolly4u.fitness

Registrar
Spaceship, Inc.
Dynadot Inc
Spaceship, Inc.
Dynadot Inc
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
Devexpanse Ltd d/b/a Regery.com
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.

<!-- page 40 -->

const1.hq-dgt-dot < const1.hq-dgt-dot@govcontractor.nic.in >

Fwd: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]

Subodh Saxena < ddgit.hq-dgt-dot@gov.in >
Sat, 26 Sep 2026 7:42:57 PM +0530
To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Arun Kumar"<consnt.hq-dgtdot@govcontractor.nic.in>,"Kripa Shanker Pandey"<adt.hq-dgt-dot@gov.in>,"SUNIL
KUMAR"<const1.hq-dgt-dot@govcontractor.nic.in>,"Manish Shukla"<dirit.hq-dgtdot@gov.in>

============ Forwarded message ============
From: VINAY . <vinay.2009@gov.in>
To: "Prem Chand Sharma"<ddga.hq-dgt-dot@gov.in>, "Subodh Saxena"<ddgit.hqdgt-dot@gov.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Fri, 25 Sep 2026 16:58:27 +0530
Subject: Fwd: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Sir/Madam,
Please refer to the trailing email on the above subject.
The present case pertaining to blocking of websites/URLs/domains regarding the
infringement of copyright/ trademark/ patent/ exclusive rights of the plaintiff. Such type
of matters are being dealt by the Office of DG(Telecom) , hence, it is being forwarded for
necessary action in the matter, please. It is also requested to register the case on the
LIMBS portal if not registered yet.
Regards,
Vinay
Assistant Section Officer (Legal)
Law Division, DoT

<!-- page 41 -->

============ Forwarded message ============
From: Suneet Kumar Tomar <dirlaw-dot@gov.in>
To: "VINAY ."<vinay.2009@gov.in>, "Nuruddin Nuruddin"<solegal-dot@gov.in>,
"Nuruddin"<nuruddin.69@nic.in>
Cc: "Rohit Meena"<jtolaw-dot@gov.in>, "Rohit Meena"<rohit.meena29@gov.in>
Date: Fri, 25 Sep 2026 16:46:06 +0530
Subject: Fwd: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
Please send to the concerned division

Regards,
Suneet Kumar Tomar
Director (Law)
Department of Telecommunication
Ministry of Communication
Government of India

============ Forwarded message ============
From: Law Division, DOT <law-dot@gov.in>
To: "Suneet Kumar Tomar"<dirlaw-dot@gov.in>
Date: Fri, 25 Sep 2026 16:32:37 +0530
Subject: Fwd: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

============ Forwarded message ============
From: Amit Agrawal <secy-telecom@gov.in>
To: "Law Division, DOT"<law-dot@gov.in>
Date: Fri, 25 Sep 2026 16:16:57 +0530
Subject: Fwd: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real –
Time Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High
Court of Delhi in suit titled Amazon Seller Service Private Limited vs.
https://cinevood.love/ & Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============

Amit Agrawal
Secretary
Department of Telecommunications
2nd Floor, Sanchar Bhawan
Tele: 011-23719898, 23711209
Email: secy-dot@nic.in; secy-telecom@gov.in

<!-- page 42 -->

============ Forwarded message ============
From: Manish Rawat <mrawat@saikrishnaassociates.com>
To: <secy-dot@nic.in>, "Ram Meena"<dirds2-dot@nic.in>, "Manish Shukla"
<dirit.hq-dgt-dot@gov.in>, <cyberlaw-legal@meity.gov.inss>, "Dr. Sandip
Chatterjee"<gccyberlaw@meity.gov.in>, "Prafulla Kumar"<pkumar@meity.gov.in>,
"Sathyanarayanan Subramanian"<sathya.s@meity.gov.in>
Cc: "Yatinder Garg"<yatinder@saikrishnaassociates.com>, "Angad Makkar"
<angad@saikrishnaassociates.com>, "Raghav Goyal"
<raghav@saikrishnaassociates.com>
Date: Fri, 25 Sep 2026 15:54:36 +0530
Subject: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real – Time
Blocking in compliance of order dated 15.09.2026 passed by the Hon’ble High Court
of Delhi in suit titled Amazon Seller Service Private Limited vs. https://cinevood.love/
& Ors. [CS(COMM) 1002 of 2026]
============ Forwarded message ============
WITHOUT PREJUDICE
BY EMAIL

25.09.2026
To,
Defendant No. 12: Department of Telecommunications
secy-dot@nic.in
dirds2-dot@nic.in
dirit.hq-dgt-dot@gov.in
Defendant No. 13: Ministry of Electronics and Information Technology
cyberlaw-legal@meity.gov.inss
gccyberlaw@meity.gov.in
pkumar@meity.gov.in
sathya.s@meity.gov.in
Subject: URGENT | DOT & MEITY | Sixth List of Additional Websites for Real – Time Blocking in
compliance of order dated 15.09.2026 passed by the Hon’ble High Court of Delhi in suit titled
Amazon Seller Service Private Limited vs. https://cinevood.love/ & Ors. [CS(COMM) 1002 of
2026]
Dear Sir,
We act on behalf of Amazon Seller Services Private Limited (hereinafter referred to as “Our
Client”). Our Client is the Plaintiff in the above-captioned suit.
The Plaintiff is the first and exclusive owner of rights, including but not limited to intellectual
property rights and copyright, in the subject cinematograph film titled ‘VIBE’ (hereinafter
referred to as the “Film”), which was released theatrically across India on 18th September 2026.
The Film qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957 Act’) and, being
a work of visual recording with accompanying sound recordings, it further qualifies as a
“cinematograph film” under Section 2(f) of the 1957 Act. Plaintiff being the exclusive first owner

<!-- page 43 -->

and distributor of the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 of the 1957 Act and consequently has exclusive rights
enumerated under Section 14(d) of the 1957 Act.
Our Client has instituted the above-captioned Suit against various ‘rogue’ Websites, inter alia
Defendant Nos. 1 to 11, before the Hon’ble High Court of Delhi, on account of their unauthorized
hosting, streaming, and illegal communication of Our Client's copyrighted content, including the
cinematograph film ‘Nishaanchi’, and seeking permanent as well as ex-parte ad-interim and
temporary injunction restraining the infringement of Our Client's exclusive rights and copyright
in the Film by the said rogue websites, as well as for other reliefs.
Our Client has also arrayed Government departments i.e. Department of Telecommunication
(DoT) (Defendant No. 12) and the Ministry of Information and Technology (MEITY) (Defendant
No. 13) various Internet and Telecom Service Providers (ISPs / TSPs), (Defendant No. 14 – 22) as
well as the concerned Domain Name Registrars (Defendant No. 23 – 34), to ensure effective
compliance of any orders that the Hon’ble Delhi High Court was inclined to pass.
The above-mentioned matter came up before the Hon’ble Justice Ms. Jyoti Singh, Delhi High
Court on 15.09.2026, on which date, the Hon’ble Court was pleased to issue summons and notice
to you and was also pleased to pass an ex-parte ad-interim order in terms of Prayers at
Paragraph16 of application under Order XXXIX Rules 1 and 2 of the Code of Civil Procedure,
1908 (“CPC”). The relevant paragraphs of the Order dated 15.09.2026 are extracted herein below:
“35. Accordingly, till the next date of hearing, Defendants No. 1 to 11 and/or any person
acting on their behalf are restrained from in any manner communicating, hosting,
streaming and/or making available for viewing and downloading, without
authorization of the Plaintiff, the upcoming film VIBE on their websites or any other
electronic or digital platforms, in any manner whatsoever, amounting to infringement
of Plaintiff’s copyright.
36. Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the domain names
of Defendants No. 1 to 11, as indicated in ANNEXURE-A to this order, within 36 hours
from the date of receipt of copy of this order and file compliance affidavits within six
weeks.
37. Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants No. 1 to 11
websites forthwith on receipt of copy of this order. Defendants No. 12 and 13 shall issue
necessary notifications to the ISPs for blocking access to Defendants No. 1 to 11 websites
mentioned in ANNEXURE-A hereunder within 36 hours from the date of receipt of
copy of this order. Compliance affidavits shall be filed within six weeks from today.
38. Defendants No. 23 to 34 are directed to disclose complete details of Defendants No. 1
to 11 including email addresses, mobile numbers, contact details, payment details and
KYC details, to the extent available with them, within four weeks from today in a sealed
cover/password protected document.
39. It is further directed that if any other website is found to be unauthorizedly
streaming and communicating the film VIBE, over which Plaintiff has the copyright,
Plaintiff will be at liberty to communicate this information to Defendants No. 12 to 34
for blocking the websites on real time basis and upon receiving the intimation,
Defendants No. 14 to 34 shall take immediate steps to block and suspend the websites
and Defendants No. 12 and 13 shall issue necessary notification in this regard.”
In light of the above, the list of additional rogue websites discovered till date during the currency
of the proceeding is attached herewith. These websites are illegally streaming and communicating
the Film over which Our Client has exclusive rights and copyright.
You are hereby requested to comply with the order dated 15.09.2026 by immediately issuing
notification to all the ISPs registered under you to block access to the identified rogue websites
during the course of the proceeding, on a real-time basis so that there is no delay.
The next date of hearing in the captioned matter is 19.01.2027 before the Hon’ble Court and
07.10.2026 before the Ld. Joint Registrar.

<!-- page 44 -->

For your convenience, please find attached the Order dated 15.09.2026, passed by the Hon’ble
Court of Justice Jyoti Singh, Delhi High Court.
List of the additional websites is also enclosed herewith and the evidence against the websites is
available in the link below:
https://drive.google.com/drive/folders/1brRyIZXFirMctcBGa3joB88V8PKsOEk1?usp=sharing
If you have any queries regarding this matter, please feel free to reach out to the following:
mrawat@saikrishnaassociates.com
Please acknowledge a safe receipt.

Sincerely,
Manish Singh
Saikrishna & Associates
Counsels for the Plaintiff
Manish Singh | Associate | Saikrishna & Associates, 57 Jor Bagh, Delhi - 110003,
India|Tel:+91-11-40244360 (100Lines) |Handphone: +91-9927402957 | Enrolment
Number - D/11561/2025
• MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
• WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
• CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
• INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
• INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
• MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files
constitutes confidential information of S&A and may also be the subject of legal
professional privilege, not being waived or lost by mistaken transmission or receipt.
If you have received this mail in error, please notify us at
info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised

2 Attachment(s)
List 6.xlsx

Order dated 15.09.2026.pdf

10.7 KB

423.7 KB

<!-- page 45 -->

<!-- page 46 -->

List - 6
S.No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26

Domains
7starhd.exchange
7starhdc.com
9xmovie.cool
9xmovie.koeln
allmovieshub.style
bdhdmusic23.forum
bollyflix.af
bollygle.com
coolmoviez.surf
filmiz.xyz
filmycab.org
hdjan24.co
hdmovies23.cards
hdtvdir.com
hindilinks4u.lat
ihdhub4u.com
mkvmoviespoint.vet
moviebaaz.baby
moviesnation.gives
rogmovies.beer
southfreak.my
thekhatrimaza.sarl
vega-movies.video
vegamoviesq.com
vegamoviess.you
world4ufree.beer

Registrar
Dynadot Inc
Gransy, s.r.o.
Dynadot Inc
Dynadot, LLC
NameCheap, Inc.
NAMECHEAP
Gransy s.r.o.
Dynadot Inc
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
NameCheap, Inc.
Dynadot Inc
Dynadot Inc
NameCheap, Inc.
Dynadot Inc
Tucows Domains Inc.
NameCheap, Inc.
NameCheap, Inc.
NameCheap, Inc.
Dynadot, LLC
Dynadot Inc
NameCheap, Inc.
Dynadot Inc
Dynadot, LLC
Dynadot Inc

<!-- page 47 -->

$~50
*
IN THE HIGH COURT OF DELHI AT NEW DELHI
#

CNR No. DLHC010434262026

+

CS(COMM) 1002/2026
AMAZON SELLER SERVICES PRIVATE LIMITED
.....Plaintiff
Through: Mr. Saikrishna Rajagopal, Mr.
Sidharth Chopra, Ms. Sneha Jain, Mr. Yatinder
Garg, Mr. Angad Singh Makkar, Mr. Raghav
Goyal and Mr. Manish Singh, Advocates.
versus
HTTPS//CINEVOOD.LOVE/ & ORS.
Through:

.....Defendants

CORAM:
HON'BLE MS. JUSTICE JYOTI SINGH
ORDER
15.09.2026

%

I.A. 25153/2026 (for pre-institution mediation)
1.

This application is filed on behalf of the Plaintiff under Section 12-A

of the Commercial Courts Act, 2015 read with Section 151 CPC seeking
exemption from Pre-Institution Mediation.
2.

Having regard to the facts of the present case wherein urgent relief is

prayed for and in light of the judgment of Supreme Court in Yamini
Manohar v. T.K.D. Keerthi, (2024) 5 SCC 815, as also Division Bench of
this Court in Chandra Kishore Chaurasia v. RA Perfumery Works Private
Ltd., 2022 SCC OnLine Del 3529, exemption is granted to the Plaintiff from
Pre-Institution Mediation.
3.

Application is allowed and disposed of.

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 1 of 14

<!-- page 48 -->

I.A. 25151/2026 (u/S 80 r/w Section 151 CPC)
4.

This application is filed on behalf of the Plaintiff seeking exemption

from serving prior notice under Section 80 CPC on Defendants No. 12/DoT,
13/MeitY, 15/BSNL and 17/MTNL.
5.

For the reasons stated in the application, the same is allowed

exempting Plaintiff from serving prior notice under Section 80 CPC on
Defendants No. 12, 13, 15 and 17.
6.

Application stands disposed of.

I.A. 25152/2026 (u/O XI Rule 1 (4) r/w Section 151 CPC)
7.

This application is filed on behalf of the Plaintiff seeking to place on

record additional documents.
8.

Plaintiff, if it wishes to file additional documents at a later stage, shall

do so strictly in accordance with provisions of the Commercial Courts Act,
2015.
9.

Application is allowed and disposed of.

I.A. 25154/2026 (u/S 151 CPC)
10.

This application is filed on behalf of the Plaintiff seeking permission

to file redacted versions of the documents as captured in paragraph 2 of the
application.
11.

For the reasons stated in the application, the same is allowed

permitting Plaintiff to file redacted versions of the documents captured in
paragraph 2 of the application.
12.

Application stands disposed of.

CS(COMM) 1002/2026
13.

Let plaint be registered as a suit.

14.

Upon filing of process fee, issue summons to the Defendants through

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 2 of 14

<!-- page 49 -->

all permissible modes, returnable before the learned Joint Registrar on
07.10.2026.
15.

Summons shall state that the written statements shall be filed by the

Defendants No. 1 to 11 within 30 days from the receipt of summons along
with affidavits of admission/denial of the documents filed by the Plaintiff.
16.

It will be open to the Plaintiff to file replications within 30 days from

the date of receipt of written statements along with affidavits of
admission/denial of documents filed by Defendants No. 1 to 11.
17.

If any of the parties wish to seek inspection of any documents, the

same be sought and given within the timeline prescribed in Delhi High
Court (Original Side) Rules, 2018.
18.

Learned Joint Registrar will carry out admission/denial of documents

and marking of exhibits.
I.A. 25150/2026 (u/O XXXIX Rules 1 and 2 r/w Section 151 CPC)
19.

This application is filed on behalf of the Plaintiff under Order XXXIX

Rules 1 and 2 read with Section 151 of CPC for grant of ex parte ad interim
injunction.
20.

Issue notice to the Defendants through all permissible modes,

returnable before Court on 19.01.2027.
21.

Case of the Plaintiff as set out in the plaint is that Plaintiff is engaged

inter alia in the business of commissioning and distributing original audiovisual content and has commissioned and/or distributed several theatrical
films and original web-series, including ‘Nishaanchi’, ‘Mirzapur’, ‘Bhool
Chuk Maaf’ and ‘Citadel: Honey Bunny’. Plaintiff is also an exclusive
licensee for several films and web series and the content is released and
marketed under the brand name ‘Amazon MGM Studios’. Plaintiff continues

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 3 of 14

<!-- page 50 -->

to expand its footprint in the Indian film and entertainment industry, having
recently unveiled its largest-ever Indian content slate at the “Prime Video
Presence” in March, 2026, including and an extensive theatrical line-up
from several Hindi and regional-language films scheduled for release in
2026 and 2027, including titles such as ‘Raftaar’, ‘Dilkashi’ and ‘Nayi
Naveli’.
22.

It is stated that the Plaintiff is the first and exclusive owner of all

rights, including but not limited to intellectual property rights and copyright,
in the subject upcoming cinematograph film titled ‘VIBE’ (earlier proposed
to be named ‘S.W.A.G’). Plaintiff had commissioned Drongo Films LLP for
development and production of the Film, which is a ‘work made for hire’
and all rights therein vest in the Plaintiff, immediately upon creation thereof.
To this effect, Plaintiff has executed with Drongo Films a Production
Company

Services

Agreement

dated

24.06.2025,

Standard

Terms

Agreement dated 22.07.2025 and First Addendum dated 25.11.2025. Each of
the said agreements, indicate that Plaintiff is the sole and exclusive owner of
all rights including intellectual property rights and exploitation rights in the
Film and all underlying works commissioned by Drongo Films in production
of the Film and being the owner, Plaintiff is entitled to enforce the rights in
the Film and initiate or defend legal proceedings relating to any
infringement.
23.

It is stated that the film VIBE is scheduled for pan-India

theatrical release, including in Delhi, on 18.09.2026 and the official
trailer was released on 02.09.2026 on YouTube and is accessible at
https://www.youtube.com/watch?v=meknZizkusk. The trailer has already
garnered in excess of 48 million views as on 08.09.2026, which is indicative

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 4 of 14

<!-- page 51 -->

of the considerable anticipation, audience interest and engagement generated
by the Film. VIBE is written and directed by Kunal Kemmu, who also stars
in the Film alongside other actors including Preity G. Zinta. The Film
qualifies as a ‘work’ under Section 2(y) of the Copyright Act, 1957 (‘1957
Act’) and, being a work of visual recording with accompanying sound
recordings, it further qualifies as a “cinematograph film” under Section 2(f)
of the 1957 Act. Plaintiff being the exclusive first owner and distributor of
the Film is the producer/author under Section 2(d) of 1957 Act and thus the
owner of copyright in VIBE as per Section 17 and consequently has
exclusive rights enumerated under Section 14(d).
24.

It is stated that Plaintiff has invested substantial money and resources

towards acquisition, distribution and exploitation rights of the Film and
therefore, has substantial commercial and proprietary interests in the
successful and unhindered theatrical and subsequent exploitation. By virtue
of Section 14(d), Plaintiff has the exclusive right to communicate the Film
by to the public. The expression ‘Communication to the public’ is defined
under Section 2(ff) to include inter alia the act of ‘making any work
available for being seen or heard or otherwise enjoyed by the public’.
Section 51 of 1957 Act, prohibits and deems infringement inter alia doing of
any act, which is within the purview of exclusive rights granted to the
copyright owner under Section 14 of 1957 Act, without license/authorization
by the owner or in contravention thereof as also permitting for profit any
place to be used for communication of a cinematograph film to the public
where such communication constitutes infringement unless the party in
question was unaware and had no reasonable ground to belief that such
communication constitutes infringement. Therefore, any hosting, streaming,

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 5 of 14

<!-- page 52 -->

reproduction, distribution, making available to the public and/or
communication to the public of the Film VIBE, or facilitation of the same,
without Plaintiff’s authorisation, by any means and on any platform
including internet and mobile, will amount to infringement under Section
51(a) and (b) of 1957 Act.
25.

It is stated that the present suit is directed against 11 rogue websites

arrayed as Defendants No. 1 to 11, particulars whereof are set out in the
plaint as follows:-

26.

It is stated that Defendant Websites primarily and substantially engage

in communicating to the public, hosting, streaming and/or making available
to the public, including in Delhi, Plaintiff’s copyright-protected content
without authorisation and have done so in the past for various films such as

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 6 of 14

<!-- page 53 -->

‘Nishaanchi’. Defendants No. 1 to 11 websites are vehicles of infringement
whose whole business model is designed to provide members of the public
access to copyrighted content without authorisation. The mala fide intent is
evident from the vast volume of content available on the websites,
systematic, organised and intentional nature of the infringement and the
regularity and consistency with which the content is uploaded/updated. To
identify and collect evidence qua the activities of these Defendants,
investigations were carried out and it was found that Defendants No. 1 to 11
are continuously and illegally transmitting, communicating and/or making
public Plaintiff’s copyrighted content and therefore, Plaintiff apprehends that
upon release of the film VIBE, infringing copies will be made available on
Defendants’ website, without Plaintiff’s authorisation and therefore, the
present suit has been filed.
27.

Learned counsel for the Plaintiff submits that it is settled industry

practice to release a film for theatrical exhibition first and to make it
available on OTT services and television only thereafter, the theatrical
release being the most important stage in the life of a film since its
commercial value depends substantially upon the popularity and success
achieved during the period of theatrical exhibition. It is ordinarily the “Box
Office” collection of a film that determines its worth. Unscrupulous
elements, seeking to make illegal gains by exploiting the interest and
curiosity of a movie-goer to view a film as early as possible upon its release,
make infringing copies available for viewing and downloading, almost
simultaneously with the theatrical release. In respect of films commissioned
and/or distributed by the Plaintiff in the past, such as ‘Nishaanchi’,
‘Mirzapur’ and ‘Bhool Chuk Maaf’, infringing copies were communicated to

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 7 of 14

<!-- page 54 -->

the public and made available for download and viewing on various websites
within hours of theatrical release. Such unauthorised exploitation directly
impacts the business of the Plaintiff, erodes the value of the Film and
interferes with the crucial and narrow window of theatrical exploitation,
besides diluting the separate and distinct rights to exploit the Film on OTT
services subsequently.
28.

It is urged that there is a serious apprehension that on release of VIBE,

infringing copies of the upcoming film will be made available on Defendants
No. 1 to 11 websites, without authorisation from the Plaintiff, who has not
licensed or authorised the said Defendants to communicate the said film to
public. In fact, Plaintiff has concrete evidence that these websites are
claiming to make available the film under the category ‘coming soon’ on
their platforms. Defendants No. 1 and 4 to 8 have organised content under
categories such as ‘Bollywood movie’ and Defendants No. 1, 4, 6, 8 and 11
are holding out that they will update their respective websites with the latest
content and add new titles upon request of the users. Defendant No. 2 has
already listed the film VIBE under the category ‘coming soon’ on its
platform.
29.

It is further urged that Defendants No. 1 to 11 websites having provide

services, which mask or hide their identities and locations of their servers,
rendering it virtually impossible to locate the operators. Contact details in
their WHOIS particulars are incomplete, incorrect and unresponsive. Take
down notices issued by the Plaintiff on 07.09.2026 to the publicly available
email addresses have elicited no response. Defendants No. 1 to 3 further
encourage their users to resort to VPN services should a website not function
properly or should access become difficult from a particular location. In

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 8 of 14

<!-- page 55 -->

these circumstances, it is urged that since the film VIBE is scheduled for
theatrical release on 18.09.2026, Defendants No. 1 to 11 be restrained from
in any manner streaming, distributing, communicating etc. to the public the
upcoming film VIBE in any manner whatsoever.
30.

Having heard learned counsel for the Plaintiff, I am of the view that

Plaintiff has made out a prima facie case for grant of ex parte ad interim
injunction against the Defendants. Balance of convenience lies in favour of
the Plaintiff and it is likely to suffer irreparable harm in case the interim
injunction, as prayed for, is not granted.
31.

Case of the Plaintiff is that Defendants No. 1 to 11 websites are rogue

websites engaged in piracy of copyrighted content and their primary purpose
is to transmit, stream, download, communicate, issue copies of, cause to be
seen or heard by the public and make available to the public, content over
which Plaintiff holds exclusive rights, without any authorisation. These
websites appear to be intentionally and systematically uploading vast
volume of infringing content and no contact details pertaining to them are
publicly available and perusal of their names and home pages shows that
they are perhaps pseudonymous.
32.

Plaintiff claims copyright in the cinematograph film VIBE, which is

scheduled for theatrical release on 18.09.2026. Going by the past experience
where Defendants No. 1 to 11 have communicated Plaintiff’s copyrighted
content to public for unlawful monetary gains, Plaintiff apprehends that
these websites including Defendant No. 35/John Doe will communicate,
host, stream and make public the content of the upcoming film, which will
not only violate Plaintiff’s copyright under 1957 Act but also adversely
impact the revenues. During the course of hearing, Mr. Chopra submitted

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 9 of 14

<!-- page 56 -->

that the film VIBE has received CBFC certification and Plaintiff is looking
forward to a huge commercial success of the movie and therefore its
dissemination and communication by the rogue websites will be detrimental
to Plaintiff’s interest.
33.

Being the first and exclusive owner of copyright in the film VIBE and

having rights under Section 14(d) of 1957 Act, Plaintiff is entitled to protect
the copyright vested in it. Piracy of this nature strikes at the very window
during which a film is expected to recoup its investment and must be dealt
with a heavy hand. In Jiostar India Private Limited v. Vegamovies.Yachts
& Ors., CS (COMM) 977/2025, this Court granted real time dynamic
injunction prior to release of the film ‘Jolly LLB 3’. In Universal City
Studios LLC. and Others v. Dotmovies Baby and Others, 2023 SCC
OnLine Del 4955, Court was of the view that to keep pace with the dynamic
nature of the infringement undertaken by hydra-headed websites, a
‘Dynamic+ injunction’ ought to be granted to protect copyrighted works as
soon as they are created, so that no irreparable loss is caused to the authors
and owners of copyrighted works, as there is an imminent possibility of
works being uploaded on rogue websites or their newer versions
immediately upon release. Relevant passages from the order are as follows:“17. Any injunction granted by a Court of law ought to be effective in
nature. The injunction ought to also not merely extend to content which is
past content created prior to the filing of the suit but also to content which
may be generated on a day-to-day basis by the Plaintiffs. In a usual case
for copyright infringement, the Court firstly identifies the work, determines
the Copyright of the Plaintiff in the said work, and thereafter grants an
injunction. However, owing to the nature of the illegalities that rogue
websites induldge in, there is a need to pass injunctions which are also
dynamic qua the Plaintiffs as well, as it is seen that upon any film or series
being released, they may be immediately uploaded on the rogue websites,
causing severe and instant monetary loss. Copyright in future works comes
into existence immediately upon the work being created, and Plaintiffs

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 10 of 14

<!-- page 57 -->

may not be able to approach the Court for each and every film or series
that is produced in the future, to secure an injunction against piracy.
xxx

xxx

xxx

19. As innovation in technology continues, remedies to be granted also
ought to be calibrated by Courts. This is not to say that in every case, an
injunction qua future works can be granted. Such grant of an injunction
would depend on the fact situation that arises and is placed before the
Court.
20. In the facts and circumstances as set out above, an ex parte ad interim
injunction is granted restraining the Defendants, who are all rogue
websites, from in any manner streaming, reproducing, distributing, making
available to the public and/or communicating to the public any
copyrighted content of the Plaintiffs including future works of the
Plaintiffs, in which ownership of copyright is undisputed, through their
websites identified in the suit or any mirror/redirect websites or
alphanumeric variations thereof including those websites which are
associated with the Defendants' websites either based on the name,
branding, identity or even source of content. To keep pace with the
dynamic nature of the infringement that is undertaken by hydra-headed
websites, this Court has deemed it appropriate to issue this ‘Dynamic+
injunction’ to protect copyrighted works as soon as they are created, to
ensure that no irreparable loss is caused to the authors and owners of
copyrighted works, as there is an imminent possibility of works being
uploaded on rogue websites or their newer versions immediately upon the
films/shows/series etc. The Plaintiffs are permitted to implead any
mirror/redirect/alphanumberic variations of the websites identified in the
suit as Defendants Nos. 1 to 16 including those websites which are
associated with the Defendants Nos. 1 to 16, either based on the name,
branding, identity or even source of content, by filing an application for
impleadment under Order I Rule 10 CPC in the event such websites merely
provide new means of accessing the same primary infringing websites that
have been injuncted. The Plaintiffs are at liberty to also file an
appropriate application seeking protection qua their copyrighted works,
including future works, if the need so arises. Upon filing such applications
before the Registrar along with an affidavit with sufficient supporting
evidence seeking extension of the injunction to such websites, to protect
the content of the Plaintiffs, including future works, the injunction shall
become operational against the said websites and qua such works. If there
is any work in respect of which there is any dispute as to ownership of
copyright, an application may be moved by the affected party before the
Court, to seek clarification.”

34.

The issue of rogue websites engaged in piracy of copyrighted content

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 11 of 14

<!-- page 58 -->

poses a recurring threat and there is no gainsaying that piracy must be
curbed. There is a need for immediate relief in the present case considering
that the theatrical release of the Film VIBE is scheduled on 18.09.2026 and
delay in blocking access to Defendants No. 1 to 11 Websites, or any other
website indulging in similar unlawful activities, will lead to irreparable loss
to the Plaintiff.
35.

Accordingly, till the next date of hearing, Defendants No. 1 to 11

and/or any person acting on their behalf are restrained from in any manner
communicating, hosting, streaming and/or making available for viewing and
downloading, without authorization of the Plaintiff, the upcoming film VIBE
on their websites or any other electronic or digital platforms, in any manner
whatsoever, amounting to infringement of Plaintiff’s copyright.
36.

Defendants No. 23 to 34 (DNRs) are directed to lock and suspend the

domain names of Defendants No. 1 to 11, as indicated in ANNEXURE-A to
this order, within 36 hours from the date of receipt of copy of this order and
file compliance affidavits within six weeks.
37.

Defendants No. 14 to 22 i.e. the ISPs are directed to block Defendants

No. 1 to 11 websites forthwith on receipt of copy of this order. Defendants
No. 12 and 13 shall issue necessary notifications to the ISPs for blocking
access to Defendants No. 1 to 11 websites mentioned in ANNEXURE-A
hereunder within 36 hours from the date of receipt of copy of this order.
Compliance affidavits shall be filed within six weeks from today.
38.

Defendants No. 23 to 34 are directed to disclose complete details of

Defendants No. 1 to 11 including email addresses, mobile numbers, contact
details, payment details and KYC details, to the extent available with them,
within four weeks from today in a sealed cover/password protected

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 12 of 14

<!-- page 59 -->

document.
39.

It is further directed that if any other website is found to be

unauthorizedly streaming and communicating the film VIBE, over which
Plaintiff has the copyright, Plaintiff will be at liberty to communicate this
information to Defendants No. 12 to 34 for blocking the websites on real
time basis and upon receiving the intimation, Defendants No. 14 to 34 shall
take immediate steps to block and suspend the websites and Defendants No.
12 and 13 shall issue necessary notification in this regard.
40.

Plaintiff shall continue to file Affidavits providing the details of the

newly discovered website(s), their Domain Names and the URL(s), which
are communicated and blocked, to ensure that Court is kept informed of the
website(s) in respect of which blocking orders are sought. Plaintiff shall also
file appropriate applications for impleadment whenever necessary.
41.

If any website, which is not primarily infringing the exclusive rights

of the Plaintiff, is blocked in pursuance of this order, such entity is permitted
to approach the Court by giving an undertaking that it does not intend to do
any illegal dissemination of the content over which Plaintiff has exclusive
rights and the Court would consider modifying the injunction, if the facts
and circumstances so warrant.
42.

Plaintiff shall comply with the provisions of Order XXXIX Rule 3

CPC within a period of two weeks from today.

JYOTI SINGH, J
SEPTEMBER 15, 2026
S.Sharma

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 13 of 14

<!-- page 60 -->

ANNEXURE-A

CS(COMM) 1002/2026
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 16/09/2026 at 23:27:44

Page 14 of 14

<!-- page 61 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
