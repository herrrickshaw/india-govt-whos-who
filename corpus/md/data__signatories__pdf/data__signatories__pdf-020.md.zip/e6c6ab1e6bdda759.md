---
doc_id: "e6c6ab1e6bdda759"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2025/12/28c9edd2d15cc6bb4cefe806670d0ef6.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Circular pertaining to Litigation"
date: "2015-05-08"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "292b0492c868434e"
---

<!-- page 1 -->

‘ Pee F OAV SCV AO IUU SE, |
- Government of India
Ministry of Law and Justice
Department of Legal Affairs [
Judicial Section
eee?
New Delhi, 8"” May, 2015
OFFICE MEMORADUM
Subject:- Deletion of the name of Cabinet Secretary from the array of respondents in |
Litigation/Court Cases - regarding
हक क #कऊ॑ के ऊँ के के के के औके कै के के के के
It has been brought to the notice of this Department that Cabinet Secretariat has been
receiving a large number of cases from different Courts/Tribunals which would generally fall in either
of the following categories in so far as enlisting of respondents is concerned:-
(i) Union of India (UO!) through Cabinet Secretary is arrayed as a proforma respondent,
with the Ministry/Department specifically concerned with the subject of the case having been
made the main respondent;
ii) UOl through Cabinet Secretary is arrayed as the only respondent and the
Ministry/Department concerned is NOT impleaded as a respondent;
(iii) UO! along with a Ministry/Department which is not in fact, concerned with the case, is
arrayed as a respondent, resulting in the Notice for hearing being served to the Department
which is not in a position to effectively defend the case on behalf of UOI, and
(iv) UO! along with a PSU/subordinate office under the Ministry/Department proper is
impleaded as the respondent, resulting in failure/inability of the Ministry/Department proper
to defend the case on behalf of UOI.
2. Cabinet Secretariat has been forwarding copies of the OA/WP/CP as the case may be, along
with the Notice to the concerned Ministries/Departments with the request to defend the case on
behalf of the Union of India and to get the name of Cabinet Secretary who is not directly concerned
with the subject of the case, deleted from the list of respondents
3. There have been instances where the Ministry/Department referred the proposal (i.e. for
deletion of the name of Cabinet Secretary from the array of respondents) to the Government Counsel
for his/her views. There has not been consistency in the views expressed by the Government Counsel.
Some of them express the view that deletion of the name of Cabinet Secretary from the array of
respondents would not be possible, even as they fail to cite any reasons for the averment. The drafting
of the counter-affidavit usually takes a considerable time on account of the need to consult different
Departments and to take inputs from them. In some cases, the Court gives very limited timeline for
filling reply.
4. In view of the above, it has been decided for the guidance of the Administrative Ministries
that:-
(i) All the Ministries/Departments will seek the deletion of the name of Cabinet Secretary
from the array of respondents and defend the interest of UOI, after receiving the
instructions from the Cabinet Secretariat on receipt of the Notice of the case.
(ii) The Ministry/Department will immediately engage the services of Law Officers/panel
counsel, only through the Officer in charge, Central Agency Section for the cases before
the Supreme Court, In- charge, Litigation (High Court) of Delhi/CAT, Principal Bench &
Lower court section, Branch Secretariats at Bengaluru/Chennai/Mumbai/ Kolkata or the
concerned Additional/ Assistant Solicitors General for the cases before other High
Courts.

<!-- page 2 -->

agin
(iii) Once the Government Counsel is engaged, the Ministry/Department will get an
application drafted in consultation with the Government Counsel to implead itself as a
respondent (in case it has not already been impleaded as respondent) and also to nek
deletion of the name of Cabinet Secretary from the array of respondents, incorporating
a prayer to the Hon'ble Court/Tribunal on the following lines:
“aes It is submitted that the President of India has formulated two sets of Rules under
Article 77 (3) of the Constitution of India for convenient transaction of Business of the ale |
Under the Govt. of India (Allocation of Business) Rules, 1961, Business of the Govt. of India is
allocated by assigning one or more Departments in the charge of a Minister. Under the Govt. of |
India (Transaction of Business) Rules, 1961, the business of the Department is disposed of by or |
under the general or special directions of the Minister- in- charge (Ref: Rule 3). In short, the |
business allocated to Ministry/Department is disposed of by the Minister-in-charge मिल
following the Rules cited above. Therefore, the name of Cabinet Secretary, to whom the subject
matter of the instant petition is not allocated, may be deleted as a Respondent....

(iv) The Ministry/Department will also simultaneously prepare para-wise reply in
consultation with all concerned. The parawise comments prepared by the
administrative Department/Ministry will be forwarded to the Government Counsel so as
to enable him to prepare counter affidavit/reply in accordance with the rules of the
Court/Tribunal. Thereafter, the same may be got vetted from the Department of Legal
Affairs. The Legal Adviser who vets the counter affidavit has to ensure that the legal
defence which are available to the Union Government are properly reflected in the
counter. The Counter affidavit will also contain a paragraph containing the prayer that

the name of Cabinet Secretary be deleted from the array of Respondents, by
reproducing the text as given in (iii) above.

(V) The Ministry/Department will keep the Cabinet Secretariat informed of further
development of the Case, including status of compliance of interim directions, if any,
given by the Hon’ble Court/Tribunal. The Court case Module of e-Samiksha hosted by
the Cabinet Secretariat will also be kept updated by the Ministries/Departments at
periodic intervals.

5. This issues with the 4pproval of Hon'ble Minister for Law and Justice. heceeed)
eee Ra eines ६ ५५५८८
(Suresh Chandra)
Joint Secretary and Legal Adviser to the Government of India
To
1. All Ministries/Departments as per the list,
2. Allthe Law Officers as per the list
3. All Assistant Solicitors General as per the list.
4... Incharge, Branch Secretariats at Bengaluru/Chennai/Mumbai/Kolka ta.
5. The Cabinet Secretariat w.r.t. their U.O. No. A-60025/1/2014-CC dated 24.2.2015
6. NIC to upload the same on the Ministry's website. Ya)
Be vt
(R. K. Srivastava)
Deputy Legal Adviser (Jud)
