---
doc_id: "e8ecfbb2e5fbee7f"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/12/09c88927ae77bf9eee861c86bdcccd0f.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "RFP 2011-12 for appointment of Statutory Auditor and scope of statutory audit under NRHM - Format of UC"
date: "2025-12-03"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "86facd0eb34ca105"
---

<!-- page 1 -->

MISSION DIRECTORATE
NATIONAL RURAL HEALTH MISSION, ____________ (Name of the State)
DEPARTMENT OF HEALTH & FAMILY WELFARE
GOVT. OF ___________(Name of the State)
FORM GFR 19-A
[See Government of India’s Decision (1) below Rule 150]
UTILIZATION CERTIFICATE OF _____________________ FOR THE YEAR 2009-10
GRANT LETTER
NO. & DATE

Opening Balance as on 01.04.09
State Matching
Govt of India
Total
Share

G.27017/71/2008NRHM (Fin)/10,
dt.27.02.09
R.14012/4/2006EAG/NRHM-II-4,
dt.27.03.06
G.27017/5/2009NRHM (Fin)/1,
dt.22.05.09
G.27017/5/2009NRHM (Fin)/4,
dt.24.08.09
G.27017/5/2009NRHM (Fin)/8,
dt.20.10.09
G.27017/5/2009NRHM (Fin)/11,
dt.21.12.09
G.27017/5/2009NRHM (Fin)/19,
dt.29.03.10

Expenditure during the year out of
State Matching
GOI fund
Total
Share

Refunded to GoI

Closing Balance as on 31.03.10
State Matching
Govt of India
Share

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

State Matching Share
TOTAL

Funds received during the year from
State Matching
Govt of India
Total
Share

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

-

Certified that I have satisfied my self that the conditions on which the grant-in-aid was sanctioned have been dully fulfilled / are being fulfilled and that I have exercised the following checks to see that money was actually utilized for
the purpose for which it was sanctioned.
Kinds of Checks exercised:
1. Audited by Charted Accountant Firm appointed by State Health Society, Govt. of ________(name of the State).
2. Audited by Charted Accountant Firm appointed by Govt. of India.
Signature : ___________________
Designation : Mission Director,
NRHM, ________(name of the State).
Date: ________________________

<!-- page 2 -->

<!-- page 3 -->

Closing Balance as on 31.03.10
Total
-

-

-

-

-

-

-

Signature : ___________________
Designation : Mission Director,
NRHM, ________(name of the State).
Date: ________________________
