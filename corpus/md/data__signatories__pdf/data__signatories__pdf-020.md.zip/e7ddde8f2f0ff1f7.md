---
doc_id: "e7ddde8f2f0ff1f7"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/722f450575fe2fe9a2e9efba5f388ecb.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Order No. A.22012/27/2006-CHS-II dated"
date: "2010-11-19"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "82cc8080c94b2e5b"
---

<!-- page 1 -->

A.22012/27/2006-CHS-II
Government of India
Ministry of Health & Family Welfare
CHS Division
Nirman Bhawan, New Delhi
19 November, 2010
OFFICE ORDER
Dr. (Ms.) S. Brindha, presently working with GNCT Delhi is appointed as
Director, CGHS w.e.f. 1.12.2010 vice Dr. S. Barik superannuating on 30.11.2010;
and Dr. (Ms.) Anita Jain, presently working as AD (MSD) is appointed as Additional
Director (Hq), CGHS with immediate effect and until further order.
2. Dr. (Ms.) Anita Jain will also hold additional charge of AD (MSD). till such
time an officer is appointed as AD (MSD) on regular basis.
3. This issues with the approval of the Competent Authority.
जाए
Under Secretary to the Govt. of India
Telefax : 23062550
Copy to:
1. Officer Concerned
2. PS to HFM/ PPS to MOS (HFW)
3. PPS to Secretary (HF W)
. 4 PPS to DGHS
5. AS (H)/ AS. & FA/ AS & MD/ AD &DG/ Addl. DG (Stat)
6. All Joint Secretaries in the Department
7. Secretary(Health), GNCT, Delhi with the request to relieve the officer
concerned to take up the new assignment. .
8. All Directors / DS / US in the Department
9. Order folder / Spare copies.
10. Director (CGHS)
11. AD (HQ), Bikaner House, New Delhi
12. Ads/IDs,.CGHS, at different centres.
U3-~ Dir (NIC), Ministry of Health & Family Welfare for uploading on notice
___...___. board of E-I section at Intrahealthnic.in = 1. .ै.[.[.]औ]औ]२४<£ a
14. Transfer posting folder
15. Guard file
