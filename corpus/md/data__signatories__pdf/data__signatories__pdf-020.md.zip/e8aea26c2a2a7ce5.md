---
doc_id: "e8aea26c2a2a7ce5"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/01/f377810b3423eeed61adbbed9f34f5ad.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Empanelment for various Courts in the state of Maharashtra: Order dated 17.08.2018"
date: "2018-08-17"
pages: 23
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "5c90692351259458"
---

<!-- page 1 -->

F.No. J-11017/21/2018-Judicial
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
Shastri Bhawan, New Delhi,
Dated 17" August, 2018
ORDER
In supersession of this Department's earlier orders No. 36(3)/2012-Judl. dated
12.02.2013, No. 36(3)/2015-Judl. dated 08.05.2015, No. J-11017/16/2016-Judl. dated
11.05.2016, J-11017/5/2016-Judicial dated 30.08.2017 and No. J-11017/21/2018-Judicial
dated 14.08.2018 all in respect of panel of counsel for various courts in the state of
Maharashtra, the President is pleased to engage following Advocates for conducting Central
Government litigation before the High Court of Bombay at Mumbai and its Bench at
Aurangabad, the Central Administrative Tribunal, Bombay Bench at Mumbai and its Circuit
Bench at Nagpur, the National Green Tribunal, Western Zone Bench at Pune and before
various District & Subordinate Courts in the state of Maharashtra, as mentioned in the table
below, with effect from the date of this order for a period of three years or until further orders
whichever is earlier:
Panel of Counsel
for various Courts in the state of Maharashtra
No A a का of | Contact details a 4 een
| No. | Advocate
| (S/Shri _ - _ i} |
| |
| High Court of Bombay at Mumbai |
| Special Counsel |
} reese ee
= 1. | Avinash J.| 14, Harbour View, Mather Pakhadi | MAH/104/1953 |
। | Rana Road, Mazgaon, Mumbai-400010 |
Mob: 9820131410 |
| Tel. 022-23731270, 23750237
|
} 2 Beni M. | Sanawala Building, 2"° Floor, 19, Bank | 4
| | Chatterjee Street, Fort, Mumbai-400023
| | Mob: 9820298615 |
Po __ ३ _॒1_॒_ २ २॒ २ [ [ उ॒_ [ [स। सतत __ [ _उ_उ_॒_॒३ २उ 8 (1 |
| 3. | Dhairyasheel A. | 1502/B, ‘Sukhada’ Sir Ponchkhawala | MAH/201/1985 |
| Nalavade Road, Worli, Mumbai-400030 |
Mob: 9322228652
| Email: dhairysheel@hotmail.com
4 Dr. Poornima | 73/63, Mehrdad, Cuffe Parade, = |
Advani Mumbai-400005 | |
a Mob EONS Rb aT 9924728070 tt
5. | G.R. Sharma 12, 2% Floor, Western India House, 17, | MAH/851/1983 |
Sir, P. M. Road, Fort, Mumbai-400001. | |
| | Mob: 9819234064 |
| Email: doctorlaw.india@gmail.com
=e Coke
Et

<!-- page 2 -->

6. Mahendra |. Dhun Apartments, 66 Worli Hill Road, | -- |
Sethna Mumbai-400018 |
Mob: 9967414096 |
7. | Nikhil Milind | Cabin No. 12, 2°° House, Examiner | MAH/1082/1994
| Sakhardande Cross Building, Ballard Street, Fort,
| Mumbai-400001
Mob: 9820061601 |
8 Pradeep S. | Sheel Chambers, 2"° Floor, 10, Cawasji | MAH/890/1986
Jetly Patel Street, For, Mumbai-400001.
Mob: 9820089868
Email: pradeepjetly@hotmail.com
} 9. Prasad Oval House, 7" Floor, British Hotel | MAH/1147/1981 |
Dakhephalkar Lane, Nagindas Master Road, Opp. |
Commerce House, Fort, Mumbai. |
Mob: 9820043405 |
10. Rajendra B. | 1502/B, ‘Sukhada’, Sir Ponchkhawala | --
Raghuvanshi Road, Worli, Mumbai-400030
Mob: 9422293000 |
11 RajivChavan | Sai Prasad Building, Flat 802, Service | --
| Road, Plot 608/1/B, Bandra East,
| Mumbai-400051
| हलक a एन Mob: 9821062438 |
12. | Ramchandra Apte Rugnalaya, Ram Maruti Road, | MAH/496/1979 |
| Shantaram Cross Lane No. 1, Naupada, Thane |
| Apte | (W)-400602 | (a Designated Sr.
| Mob: 9869005795 | Advocate)
| Tel. 022-25337270 |
। | |
| 13. | Rashmikant 6, Owners Court, Mogal Lane, Mahim, | --
| Viveklal Desai Behind Mahim Bazar Post Office, | |
| Mahim, Mumbai-400016
| | Mob: 9820006728
| | Tel. 24379078, 24212357
| 14. | Rui Adellino | Flat # 503, 5" Floor, ‘A’ Wing, Mahavir | MAH/1237/1990
| Rodrigues Towers, Off Dr. E. Moses Road, D. S.
Marg, Worli, Mumbai-400018. |
| Mob: 9821266054 |
|
15. | Shyam Mehta 5A, Sindhu House, 3/5 Nanabhai Lane, | MAH/954/1999
| Fort, Mumbai-400001
| Mob: 9820038287
16 Suresh 401, Godavari Sadan, Kashinath Dhuru | MAH/15/1982
Shantaram Marg, Near Keerti College, Dadar (VV),
Pakale Mumbai-400028
| Mob: 9869286838
| 17. | Atul Damle 10A, Tamrind House, Tamrind Lane,
| Fort, Mumbai-400001
Mob: 9869033847, 9820146525
Tel. 022-22664215, 22695097
I<
&5>--

<!-- page 3 -->

High Court of Bombay at Mumbai |
Senior Panel Counsel Group-! |
18. | Abhay Sadanand | 204/402, 27 & 4" Floor, Rehman | MAH/816/1985
Khandeparkar House, Nadirsha, Sukhia Street, Fort, |
Mumbai-400001
Mob: 9820144734
L | Tel. 022-22874589/90
| 19. | Abhaykumar A-11/404, Sector 2, Shanti Nagar, | MAH/1530/1992
| | Ahuja Mira Road (E), Thane-401107
Mob: 9820074618
| Tel. 022-657 18208
|| Email: abhayahuja69@gmail.com
20. Advait M. Sethna | Dhun Apartment, 13" Floor, 66, Worli | MAH/1805/2000
Hill Road, Mumbai-400018
| Mob: 9892462945
| Tel. 022-22004411
| Email: advaitsethna@gmail.com
21. | Mrs. Anjali Neel | 15, Mayur, 377, VP Road, Girgaum, | MAH/1871/1995
Helekar Mumbai-400004
Tel. 022-238886778
| 22 Bharat Bhushan | D2/201, Krishna Kaveri, Lokmanya | MAH/1445/1981
| Sharma Tilak Marg, Yamuna Nagar, Andheri
| (W), Mumbai-400053
Mob: 9821246902
| Tel. 022-26327432
| Email: sharma.bbs@gmail.com
) 23. B.K. Ashok 703-A-Citiscape, Near Kohinoor Inter | MAH/433/1985
| Kumar | Continent, Andheri Kurla Road,
Andheri (E), Mumbai-400053,
| Mob: 9821246902
Tel. 022-26327432 :
| 24 Balkrishna 4/5, Samadhan Lokmanya Tilak Road, | MAH/492/1979
| Dattatraya Joshi | Mulund-West, Mumbai.
|
25 Bharat H. Mehta | Chitalia House, Ist Floor, Near Paris | MAH/988/1978
| | Bakery, 274, Dr. Cawasji Hormasji
| | Street, Behind Parasi Dairy, Princess
| Street, Mumbai-400002 Mob
| 9819063301 Tel. 022-22071328
| 26 D.N. Mishra | 18, Anand Bhawan, Subhash Nagar, | MAH/1176/1982
| | Asalpha, Ghatkopar (W), Mumbai-
400084
| Mob: 9869066199
| Tel. 022-25168521
Email
| mishradeepnarayan@hotmail.com
शा Dashrath New MHADA Colony, 25E, Flat No. | MAH/1872/1991
Avadhraj Dube 101, Opp. NNP-1, Film City Road,
| Goregaon (E), Mumbai
| | Mob: 9819167539
| | Tel. 022-28413755
Email: dashrathdube@gmail.com
-3- we
SS

<!-- page 4 -->

28. | Deepak Thakre 1302, B Wing, Simran Residency, | MAH/1269/1987
Sector 7, Kharghar, Navi Mumbai |
| Mob: 9820056926 |
| 29. | G. Hariharan 47/3, Manisha Nagar, Kalwa, Thane- | MAH/176/1984
400605 |
Mob: 9819618720
Tel, 022-25347956
| 30 Ganesh Krishnaji | 1-4, Shree-Nalanda, Ghantali Devi |) MAH/1353/1985
Sovani Path, Naupada, Thane-400602
Mob: 9820928507
Tel. 022-25336043
{__j|__ Email: ganeshsovani@hotmail.com
| 31 Gulabchandra R. | Flats 210/211, Sangeet Complex | MAH/991-B/1976
| Dwivedi Building No. 10/C, Jesal Park,
| Bhayander (E), Dist. Thane-401105
Mob: 9322764235
Tel. 022-69533479
32. | Hasmukh V. Sameer Building, Opp. ‘Maruti | MAH/135/1964 |
Mehta Temple’, Road # 16, Sion (E), |
Mumbai-400022
Mob: 9867385520 |
Tel. 022-24075944
Email: hasmukhmehta80@gmail.com
Bhardwaj |
34. | Mrs. Jyotsna N.|B. N. Sicka Nagar, V. P. Road, | MAH/490/1973
Pandhi Mumbai-400004 |
Mob: 9821388533
Tel. 022-23851165
Email: pandhi_in@yahoo.com i
35. | Mrs. Madubala K. | Orchid Residency, Tower 10 (Teak), | MAH/1013/1982 |
| | Kajle flat No. 1404. Next R. City mall, L. B. |
| 5. Marg, Ghatkopar (W), Mumbai - |
| | 400086
| Mob: 9820091301, 9323901723
Email: madhubalakajle@yahoo.com _ || |
Tel. 022-25331716 - |
Mob: 9820187392
37. |Namesh Dutt P.| Flat No. # 401, Building A-1, | MAH/2332/1998 |
Sharma Shivehhaya, Gilbert Hill Road, Andheri
(E), Mumbai-400058 |
Mob: 9870419389 |
Tel. 022-26209477
38 Neel Girish | 15, Mayur, 377, VP Road, Girgaum, | MAH/610/1994
Helekar Mumbai-400004
Mob: 9820378297 |
z Tel. 022-238886778 |
39. | Mrs. Neeta V. Shriniketan CHS Ltd., Ground Floor, | MAH/1137/1982 |
Masurkar Flat #2, 14 M. K. Road, Marine Lines |
Cross Road, # 2, Behind
Commissioner of Central Excise
Building, Churchgate, Mumbai-
400020
Mob: 9869005744
Tel. 022-22071361
Email
adv.neeta.masurkar@gmail.com
“a Kk

<!-- page 5 -->

40 | Nirmeshkant R. | 3, Esperance, ‘D'Monte Lane, Orlem, | MAH/970/1989
| Prajapati Malad (W), Mumbai-400064
| Mob: 9324154853
Tel. 022-28813320
Email: nirmeshkantp@gmail.com
41. | P.M. Palshikar Off. 323, Shramjivan, B-5, Wadala | MAH/569/1983
Truck Terminus, Opp. New Cuffe
| Parade, Wadala (E), Mumbai-400037
| Mob: 9820085036
| Tel. 022-65063566, 24046794
| Email: pmpalshikar@gmail.com
42. | Parag Vyas Shop No. 12 & 13, Ground Floor, | MAH/3829/2003
Diamond Mansion, Dr. Viegas Street,
Corner of Kalbadevi Road, Mumbai-
400002 |
Mob: 9820152279, 7738616787
Email: parag@paragvyas.net
43 Pratik Saxeria 109, Blue Moon Chambers, 25 Nagin | MAH/370/1996
Das Master Road, Fort, Mumbai-
400001 Mob: 9820074515
Purnima Anil | 1/0/19, Silver Valley, Chatrapati | MAH/085/1985
Awasthi Shivaji Marg, Vakola, Santacruz (E),
Mumbai-400055
Mob: 9821580635
Tel. 022-26680211
Email: purniawasthi@gmail.com
45. | Rajesh 104-Sea View Palace, 48-Pali Hill, | MAH/1828/1995
Ghanshyam Bandra (W), Mumbai-400050
Singh Mob: 9820061970
Tel. 022-26482362, 26442942
Email: legalliaisonsO6@yahoo.in
46. | RutujaA. 402, Sitaram Apartment, Charkop | MAH/1360/1994
Ambekar Sector-Il, Plot # 120, Kandivali (W),
Mumbai-400067
Mob: 9324088995
Tel. 022-28695812
47 S. R. Rajguru Block # 7, Yashodhan Building, | MAH/166/1961
Hanuman Cross Road # 2, Vile Parle
(E), Mumbai-400057
Mob: 9869014519
Tel. 022-22824385
48. | Sajan Oommen Flat No. 403, Building No. 29, | MAH/1374/1988
Sanskruti, 90 FT Road, Thakur
Complex, Kandivili (E), Mumbai-
400101
| Mob: 9819806809
Tel. 022-28546409 |
Email: sajanoommen@hotmail.com |
Sandesh 215, Commerce House, Nagindas, | MAH/4256/1999 |
Dadasaheb Patil Master Road, Fort, Mumabi.
Tel. 022-66666648
50. | Sanjeev Rajendra | 301, J.P. Residency, Chincholi | MAH/3197/2001 |
Prasad Singh Bunder Road, Near Kingston |
Complex, Malad (W), Mumbai-400064 |
Tel. 022-28775118 |
Email: adv.sanjeev@yahoo.co.in
“e a

<!-- page 6 -->

“see mace a 51. | Shenaz Vipsy Flat # 1, Mez Floor, 56, Pedder Road, | MAH/1839/1988 |
Bharucha | Mumbai-400026
| Mob: 9821332584
| | Tel. 022-23863074
| Email: svbharucha@gmail.com
ee / | ____ oO 11 1
| 52 Soma Singh | Clo Yogesh Pathak, 407, Apejay | MAH/1683/1991
| House, 130, B. S. Marg, Fort,
| | Mumbai-400001
| Mob: 9820003503
Tel. 022-22049188
| 53. Suresh Kumar 4/51, Sardar Nagar-4, Sion-Koliwada, | MAH/575/1991
| | Mumbai-400037
| Mob: 9323972486
| | Tel. 022-24031655
| Email: skthakur2@yahoo.com
54 Sushilkumar 63, Podar Chambers, S.A. Brelvi | MAH/1026/1991
Halwasia Road, Fort, Mumbai-400001
Mob: 7666787766
Email: halwasiaco@gmail.com
55 Suvedita |. Shah | Navjivan CHS Ltd., Building # 9, Flat # | MAH/601/1973 |
| 51, Lamington Road, Mumbai-400008 |
Mob: 9821280357 |
| Tel. 022-23010306 |
| Email: suveditashah@rediffmail.com |
| Le Vaishali Mukund | 5/18, Ahmed Sailer Building, S.J. | MAH/2116/1999
| Choudhari Marg, Near Hind Mata Cinema, Dadar |
Mumbai-400014
Mob: 9821932716
Tel. 022-24124640
57. Vijay H. Kantharia | “Nawab Building” 2™ Floor, D. N. | MAH/314/1992
Road, Opp. Thomas Cook, Mumabi-
400001
Mob: 9322201919
| Tel. 022-22042006 |
Email
vijaykantharia@rediffmail.com |
58 Rajshekhar Mistry Mansion, First Floor, 107, M. G. | MAH/648/1975
Vinayak Govilkar | Road, Hutatma Chowk, Fort, Mumbai- |
| 400023 |
Mob: 9820151202 |
Tel, 022-22670173
Email |
| contact@govilkarandassociates.in _|
59. Yogendraprasad | 161/A, Topiwala Building, Dr. | MAH/1641/1987 |
| R. Mishra Ambedakar Road, Parel, Mumbai-
400012
Mob: 9892123507
Tel. 022-24115193
| | Email: yrmishra@hotmail.com
j | |
ai Ste J

<!-- page 7 -->

60. | Yogeshwar OM Dnyanesh Co-op. Housing | MAH/955/1989
| Shivnath Bhate Society Ltd. Flat # 17, Third Floor, S
| G. Bharve Marg, Kurla (W), Mumbai-
| 400070
| Mob: 9920473770, 9869073770
Te. 022-26500508
Email: yogeshbhate@yahoo.co.in
61. | Aditya Thakkar 58, Shanti Sadan, Shivaji Park, | MAH/3985/2005
Dadar, Mumbai-400028 I
Mob: 9821534225 | ‘
Tel. 022-22821427 | |
Email: aat273@gmail.com |
62 Ashok D. Shetty 4/34, Tardeo A/c Market, Tardeo | --
Road, Mumbai-400034. \
Mob: 9821039980, 9820137387 |
Tel. 022-23520472, 23521890
Email: adshetty51@yahoo.com
63. | Hiten Mob: 9821332003 |
। Venegaonkar i
64. | Narendra L-4/64, Prinita Housing Society, Near | MAH/1488/1995
| | Chandrakant Shahu College, Laxminagar, Pune-
| Walimbe 411009
| Mob: 9422084709, 9168895155
| Email: ncwalimbe@gmail.com
|
65 Naveena Kumai 21, 2°° Floor, Gitanjali Building, Near | MAH/1016-B/2003
Radio Club, Colaba, Mumbai-400005 |
Mob: 9702058819, 9322358819
Email: advnaveena@hotmail.com |
| 66. | Prakash Gajanan | 105, Bhiwandiwala Building, Next to
| Hartalkar Dist. Court, Above Axis Bank, Court
| Naka, Thane (W), Maharashtra, Pin-
| 400601 |
| Mob: 9869005671 |
| Email: prakashhartalkar@yahoo.com
67. | Ravindranath R. | B-4-28, M.I.G. Colony, |
| Shetty Gandhi Nagar, Bandra (E), Mumbai-
400051 :
68. | Shardul Singh Bugalow No. 18A, MAH/2795/2008
| Miniland Bungalows, Gate No. 4,
| Tank Road, Bhandup (W), Mumbai-
| 400078
| Mob: 9619140001
| Tel. 022-22657354
| Email: shardulsingh@hotmail.com
69. | Dr. Birendra Mob: 98310087982 MAH/259/1996
| Saraf
| 70. | Uma Kshirsagar | C-103, Chamunda CHS _ Ltd., | MAH/383/1992
Wagle Taikalwadi, Mahim,
Mumbai-400016 |
| Mob: 9820057325
| Tel. 022-24373438
l Email: uklegal@rediffmail.com
3 ee

<!-- page 8 -->

[ 71, | Smt Shuchi MAH/1103/1991
| Halwasia
| 72. | Vasant S. | C/3/30-Saifee  Manzil, | Kennedy | MAH/599/1975

Gokhale Bridge, Opera House, Girgaon,

Mumbai-400004

Mob: 9769323663, 9821863675

Email: |

vasant.gokhale1952@gmail.com

High Court of Bombay at Mumbai |
Senior Panel Counsel Group-ll

73 Afroz Latif Shah 1501, Deep Tower, Lokhandwala | -- |
Complex, Opp. Greenpark, Off. | |

Oshiwara, Andheri (W), Mumbai- |

| 400053 Mob: 9820333484 |

| 74. | Amrendra J. 1, Nanji Niwas, 7" Kasturba Road, | MAH/2564/2003
Mishra Borivili (E), Mumbai-400066

Tel. 022-28058579, 28614889 !

| Email: ajmishra009@gmail.com
75. | Anil D. Yadav B-402, Yogmudra, Parag Nagar, | MAH/815/2005
| Near New Link Road, Dahisar (E),

Mumbai-400068 '
| Mob: 9833185577, 9022677666 |
| Email:

anildyadavS5680@yahoo.co.in

76 Aniruddha Arun A-11/17/18, Mayursadan, | MAH/177/1999
| Garge Nenewadi, Waldhuni, Kalyan-
| 421301
Mob: 9820244123 |
Tel. 022-22625356
77 Anjani Kumar Off. No. 75/76, 4" Floor, Laxmi | MAH/1908-C/1994
Singh Insurance Building, Sir P. M. Road,

Fort, Mumbai-400001

Mob: 9869036589

Tel. 022-65108299, 28553633

Email: aks1703@gmail.com

78. | Anurag Hemant 6&7 Ground Floor, Gundecha
Gokhale Chambers, Nagindas Master Road,

Mumbai-400023

Mob: 9869033847
| 79. | Ashok R. Verma | Villa Berry Building, 1* Floor, Room | MAH/1995/1995
| No. 27, Oamar Park, Wardedn
| Road, Mumbai-400036

Mob: 9892215396

Email:

ashokverma1962@gmail.com

80. | Ashutosh Flat No. 5, Prajakta Co-op. Housing | MAH/3152/2004
Ravindra Gole Society, Brahmin Society,
| Naupada, Thane (W)-400602
| Mob: 9819598173
| Tel, 022-25337270, 25421736 |
| Email: ashutoshrgole@gmail.com
-§- mh _
a
1

<!-- page 9 -->

81 Ashwinkumar Room No. 36, AAWI, 17 Floor, High | MAH/3639/2003
Ramchandra Court Building, Fort, Mumbai-
| Kapadnis 400032
| Mob: 9833986624
| 82. | BhavinR. Bhatia | 15/16, S. P. Business Centre, | MAH/3629/2005 |
| | Prakash Chambers, 77, Nagindas | |
| Master Road, Fort, Mumbai- :
400023
Mob: 9324991191 r
Tel. 022-28765803
Email: bhatiabhavin@gmail.com
83. | Chandrakant 118/120, Vithoba Lane, Shri Vithal | MAH/1034/1994
Narayan Chavan | Mandir Building, 2” Floor,
Vithalwadi, Kalbadevi Road,
Mumbai-400002
Mob: 9322884114
Tel. 022-22401241
Email:
chandrakantchavan09@gmail.com
84. | Jaydeep Deo Flat No. 10, 4" Floor, Yash Co. Op.
Housing Society, 649 Ranade |
Road, Extension, Shivaji Park, |
Dadar, Mumbai-400028
| Mob: 9820876593
85. | Kapil N. Moye 65, Sonawalla Building, 2° Floor, | MAH/5780/1999
Bombay Samachar Marg, Fort,
Mumbai-400023
Mob: 9920055066
86. | Mandar Vasant 2, Dnhanashree CHS, Opp. Godbole | MAH/2702/1999
Limaye Hospital, M. G. Road, Naupada, :
Thane-400602 1
Mob: 9820401315
Email: limayemv@yahoo.co.in
87. | Manisha S. Plot No. 79, Office No. 501, 5" | --
Jagtap Floor, M. B. House, Janmabhoomi
(Khandangale) Marg, Fort, Mumbai-400001
Mob: 9892099833
Email: manisha@jshekhar.com
88. | Mayuresh Block No. 2, Yamuna Niwas, G. B. | MAH/733/2001
Surendra Lagu Road, Charai, Thane-400601
89. | Mohd. Ali MS Gulmarg Apartment, 6" Floor, Flat /
Chunawala No. 601, 6" Floor, YMCA Road,
Morland Road, Above Bank of
Baroda, Mumbai-400008
Mob: 9821099019 :
90. | Narayan A/501, ‘Nilambari’, Sector 19, Airoli, | MAH/2139/1999
Ramratan Bubna_ | Dist. Thane-400708
Mob: 9821259697
Tel. a |
Email: nrbubna@gmail.com |
91 Nisha N. Valani Room No. 36, AAWI, High Court, | MAH/4587/1993 |
Fort, Mumbai-400032 |
Mob: 9323926258, 8108414900 |
=4- mel -

<!-- page 10 -->

92. | Prasenjit Khosla | 3 Floor, Empire House, 214, A. K. | MAH/2820-B/2005
Nayak Marg, Fort, Mumbai-400001
Mob: 9867734759
Email: |
| khoslaprasenjit@rediffmail.com |
|
| 93. Rajendra Block No. 6, MD-11, Observatory | MAH/1574/2000
| Madhukar Compound, Near Sena Cinema, R.
Haridas C. Church, Colaba, Mumbai-
400005 |
Mob: 9819259663
Email: |
rajendraharidas461@gmail.com
94 Rakesh Naresh 154, Mittal Towers, ‘A’ Wing, | MAH/4213/2009
Reddy Nariman Point, Mumbai-400021.
Mob: 9833311086 4
95 Sachin Dattatraya | 302, “Gokuldham” MAH/1554/2004 |
| Kadam CHS, Plot No. 10/A, Sector-20,
| Kharghar, Navi Mumbai-410210 }
| Mob: 9833648809
| Email: advkadam@gmail.com
96. | Shahaji R. Shinde | 2003, Neelkanth Heights, B.P.S. | MAH/121/1990
Cross Road, Mulund (West),
Mumbai-400080 हे
Mob: 9870046999
Tel. 022-25623306
Email: advshahaji09@gmail.com |
छा Shrinivas Bobde | 101-A,Vaitarna Buildings, MAH/6340/2011
Sir Pochkhanwalla Road, Worli,
Mumbai-400030.
Mob: 9619846066
Siddharth Shah Ground Floor, Hamam House, | MAH/4227/1999
Ambalal Doshi Marg, Fort, Mumbai
Mob: 932228663
Email: lawyersidd@gmail.com
Vaibhav Sugdare | C/o Shri Vijaysingh Thorat, Sr. | MAH/1534/2000
Advocate,
47" Floor, Ambalal doshi Marg,
Above Stock Market Stock
Exchange Post Office, Fort,
Mumbai-400001
Mob: 9892040944
100. | Vijay Killedar G-3, Commerce House, Nagindas | MAH/1694/2002
Master Road, Mumbai-400001
Mob: 9819356999, 9321365999
Tel. 022-22704534
101. | Ms. Anamika 501/A Wing, Dosti Florentine, Dosti | MAH/2567/1990 हि
Malhotra Ajkars, Wadala (E), Mumbai-400037
Mob: 9820698770, 9820923977
Tel. 022-24031072
Email: malhotraanamika20@yahoo.in
102. Devesh Tripathi 14, 2° Floor, Cama Chambers, Above | D/2136/2011
Welcome Restaurant, Flora Fountain, ,
Fort,
Mumbai-400023
Mob: 09004524359
Email: dtadvocate@gmail.com
—fo- cw
wl
