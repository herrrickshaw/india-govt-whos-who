---
doc_id: "e81b3ea578cbbb4e"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/3ebdb65f1b03f9d0e838bfd4d38353d9.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "List of NLD Licensees as on 30.09.2022"
date: "2022-10-28"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9270142516a910e4"
---

<!-- page 1 -->

List of NLD Licensees as on 30.09.2022

1

SUMMARY
S. No.
1
2
3
4

Type of License
Standalone NLD
UL(NLD) authorization
Total No of NLD
UL(NLD) VNO authorization
Under insolvency/surrender/wound up

No. of licensee
20
26
46
12
5

1. List of Companies having NLD Service License before UL regime.
Sr. Name of Company
No.

License No.

Effective Date
of License

1
2
3
4

10-21/2001-BS-1(NLD-02)
10-14/2006-BS-I(NLD-04)
10-10/2006-BS-I
10-05/2006-BS-I (NLD-07)

28.01.2002
10.05.2006
07.07.2006
11.07.2006

10-16/2006-BS-I(NLD-08)

11.07.2006

10-42/2006-BS-I (NLD-11)

09.10.2006

10-40/2006 (BS-I) (NLD-14)

23.11.2006

10-38/2006-BS-I (NLD-17)
10-25/2006-BS-I (NLD-19)
10-44/2007-CS-III(NLD-20)

30.07.2007
27.12.2007
03.01.2008

10-77/2007-CS-III(NLD-22)

20.06.2008

10-64/2008-CS-III (NLD-24)

03.10.2008

10-89/2008-CS-III(NLD-26)
10-67/2010-CS-III (NLD-31)
10-46/2012-CS-III (NLD-33)

05.03.2009
11.10.2011
01.04.2013

5
6
7

8
9
10

11

12
13
14
15

M/s Reliance Communications Limited
M/s Mahanagar Telephone Nigam Ltd.
M/s Railtel Corporation of India Ltd.
M/s Tikona Infinet Ltd. (Formerly HCL Infinet
Ltd.)
BT Global Communications India Pvt. Ltd (M/s
i2i Enterprises Ltd.)
M/s AT&T Global Network Services India Pvt.
Ltd.
M/s Vodafone Idea Limited (Subsequent to
amalgamation of M/s Spice Communications Ltd.
with M/s Idea Cellular Limited, NLD license in
the name of M/s Spice Communications Limited
has been transferred)
M/s Tata Teleservices Ltd.
M/s Oil India Limited
M/s Verizon Communications India Private
Limited
Ms Orange Business Services India Network Pvt
Ltd (Formerly Equant Network Services India
Private Limited)
M/s Shyam Spectra Private Limited (Erstwhile
M/s Citycom Networks Pvt. Ltd.)
M/s SingTel Global (India) Private Limited
M/s Telstra Telecommunications Pvt. Limited
M/s Bharat Broadband Network Limited

2. List of Companies having NLD Service authorization under UL regime.
Sr. Name of Company
No.

License No.

1
2
3

20-401/2013 (AS-I)
20-419/2014-AS-I
20-408/2013-AS-I

M/s Reliance Jio Infocomm Limited
M/s Sprint Telecom India Private Limited
M/s Sify Technologies Limited

ADG(CS-III), Carrier Services Wing, DoT HQ �

Effective
Date of
Authorization
21.10.2013
29.08.2014
27.06.2014
(Migrated
to

<!-- page 2 -->

List of NLD Licensees as on 30.09.2022

2

4

M/s Hughes Communications India Ltd

20-413/2013-AS-I

5

10-77/2015-CS-III
20-491/2015-AS-I
10-81/2015-CS-III

08.03.2016
29.03.2016

8
9
10

M/s NTT Communications India Network
Services Private Limited
M/s Andhra Pradesh State FIbre Net Pvt. Ltd.
M/s Microscan Infocommtech Pvt. Ltd. (Formely
M/s Microscan Computers Pvt. Ltd.)
M/s Smartx Services Ltd.
M/s Ishan Netsol Pvt. Ltd.
M/s Power Grid Corporation of India Ltd.

UL)
02.09.2014(Mi
grated to UL)
02.12.2015

20-529/2016 AS-I
821-22/2013-DS
20-532/2016 AS-I

11
12

M/s Lightstorm Telecom connectivity Pvt. Ltd.
M/s Bharat Sanchar Nigam Ltd.

20-1212/2020-AS-I
20-1206/2020-AS-I

13
14
15
16
17
18

M/s V-CON Mobile & Infra private limited
M/s Assam Electronics Development Corporation
Ltd.
M/s Oneweb India Communications Pvt. Ltd.
M/s Ringcentral India Pvt. Ltd.
M/s Nelco Limited
M/s Bharti Airtel Ltd

DS-11/250/2018-DS-III
20-579/2018-AS-I dated
30.12.2017
20-1254/2021-AS-I
20-1244/2021-AS-I
10-29/2021-CS-III
20-430/2014-AS-I dated
03.03.2014

27.12.2016
14.02.2017
02.05.2017
(Migrated
to
UL)
28.08.2020
29.02.2020
Date of signing
10.12.2020
19.01.2021
29.07.2021

19

M/s Tata Communications Ltd.

821-78/2014-DS dated
24.01.2014

20

M/s Yotta Network Services Pvt. Ltd.

21
22
23
24
25
26

M/s Ctrl S NLD Services Pvt. Ltd.
M/s Jio Satellite Communications Ltd.
M/s Powergrid Teleservices Limited
M/s OneOTT Intertainment Limited
M/s Extreme Infocom Pvt. Ltd.
M/s Adani Data Networks Limited

DS-11/243/2019-DS-III dated
16.10.2021
10-86/2020-CS-III
20-1286/2021-AS-I
20-1302/2022-AS-I
821-52/2013-DS
20-1320/2022-AS-I
20-1327/2022-AS-I

6
7

24.08.2021
31.08.2021
01.11.2021
29.11.2021
Date of signing
24.08.2021
01.01.2022
Date of signing
08.12.2021
29.11.2021
28.12.2021
09.03.2022
11.05.2022
23.05.2022
17.06.2022
26.08.2022

3. List of Companies having NLD Service authorization under UL(VNO) regime.
Sr. Name of Licensee
No.

License No.

1

M/s Speedon Network Limited

10-36/2017-CS-III

2
3

M/s GTPL Broadband Pvt. Ltd.
M/s NTT Communications India
Services Private Limited

4
5
6

M/s West Unified Communications India Pvt Ltd
M/s Velrush Business Networks Private Limited
M/s Bharti Airtel Ltd

10-100/2017-CS-III
Network 20-537/2016-AS-I

20-592/2018 AS-I
20-1233/2020-AS-I
20-1218/2020-AS-I

ADG(CS-III), Carrier Services Wing, DoT HQ �

Effective
Date of
Authorization
26.03.2018
13.07.2018
20.08.2020
(Additional
authorization)
31.07.2019
24.06.2021
21.10.2021

<!-- page 3 -->

List of NLD Licensees as on 30.09.2022

7
8
9
10
11

12

M/s Tata Communications Ltd.
M/s Centurylink Communications India Pvt. Ltd.
M/s Avaya Cloud Services Private Limited
M/s ZVC India Private Limited
M/s Webex Communications (India) Private
Limited
M/s Veeno Communications Private Limited

3

20-1246/2021-AS-I
20-1256/2021-AS-I
20-1279/2021-AS-I
20-1310/2022-AS-I
20-1214/2020-AS-I

26.11.2021
28.01.2022
23.05.2022
24.05.2022
25.05.2022

20-1176/2019-AS-I

09.09.2022

4. List of NLD Licensee which are under insolvency/ wound up/applied for surrender
Sr. Name of Licensee
No.

License No.

1

M/s Tulip IT Services Ltd.

10-09/2006-BS-I(NLD-09)

2

M/s Dishnet Wireless Ltd.

10-03/2006-BS-I (NLD-15)

3

M/s Etisalat DB Telecom Pvt Ltd (formerly M/s
Swan Telecom Pvt. Ltd.)
M/s Videocon Telecommunications Ltd
(formerly M/s Datacom Solutions Private
Limited)
M/s Unitech Long Distance Communications
Services Ltd.

10-85/2008-CS-III (NLD-25)

4

5

10-32/2008-CS-III(NLD-27)

10-48/2008-CS-III (NLD-28)

*******

ADG(CS-III), Carrier Services Wing, DoT HQ �

Effective
Date of
License
08.08.2006
(Wound up)
13.12.2006
(Under
insolvency)
06.10.2008
(Wound up)
18.03.2009
(Under
insolvency)
28.04.2009
(Applied for
Surrender)
