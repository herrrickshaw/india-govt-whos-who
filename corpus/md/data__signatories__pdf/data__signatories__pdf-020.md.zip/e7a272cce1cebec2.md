---
doc_id: "e7a272cce1cebec2"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/685e4f0d0f57aa0662da8db0934336eb.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "Appointment of Director of IIIT (PPP) Agartala, Tripura"
date: "2018-08-26"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "34203f8beef9aa56"
---

<!-- page 1 -->

G overnm ent of India
M inistry of H u m an R esource D evelopm ent
D e p artm en t of Higher E d u catio n
Technical Section - I

Appointment of Director of HIT (PPP) Agartala, Tripura

A pplications are invited, for ap p o in tm e n t to th e p o st of D irector of In d ian In stitu te of
Inform ation Technology in Public- Private P a rtn e rsh ip m ode (IIIT-PPP), A gartala.

2.

The D irector of a HIT, being th e academ ic as well as ad m in istrativ e h ead , is

expected to have proven adm in istrativ e, teach in g an d re se a rc h b ack g ro u n d (including
significant experience in re se a rc h guidance at th e Ph.D . level) w ith th e lead ersh ip
qualities to h e ad a n In s titu te of N ational im portance. The can d id a te sh o u ld be a Ph.D.
in th e ap p ro p ria te b ra n c h w ith a n o u tsta n d in g academ ic reco rd th ro u g h o u t a n d a
m inim um of 10 y ears experience as a Professor in a re p u te d E d u c a tio n a l In stitu te
(relaxable in case of an o u tsta n d in g candidate). A pplicant sh o u ld preferably be no t
m ore th a n 60 y ears of age. The p o sts carry a fixed pay of Rs. 7 5 ,0 0 0 /- p lu s Special
Allowance of Rs. 5 ,0 0 0 /- p e r m o n th w ith allow ances (pre-revised) a s adm issible u n d e r
th e R ules of th e In stitu te .

3.

The HIT A gartala is a n au to n o m o u s in stitu tio n e sta b lish e d in PPP m ode, w ith

p articip atio n from th e C en tral G overnm ent, th e concerned S tate G overnm ent, an d the
In d u stry P artner(s). The first D irector of In stitu te is being app o in ted . The D irector will
be appointed after o b tain in g th e approval of th e C om petent A u thority b a se d on the
reco m m en d atio n s m ade by th e Search-cum -S clcction C om m ittee. The S earch -cu m Selection

C om m ittee

ad vertisem ent,

as

will

well

as

consid er

applications

n o m in atio n s

received

received
from

in

re sp o n se

em in e n t

to

th is

p erso n s.

The

a p p o in tm en t will be on c o n tra c tu a l b a sis for a period of five y ears or till th e a tta in m e n t
of 70 years, w hichever is earlier, a s p er u s u a l te rm s an d conditions.

<!-- page 2 -->

4.

In terested in d iv id u als m ay apply giving detailed re su m e in th e fo rm at available

on th e w ebsite fw w w .m hrd. gov.inl. The application along w ith e n clo su re s m ay be se n t
by R eg istered /S p eed P o st to Under Secretary, Department of Higher Education,
Ministry of Human Resource Development, Room No.203, ‘C’ Wing, Shastri
Bhawan, New Delhi - 110001 so a s to reach w ithin 30 days from th e d ate of th is

a d v ertise m e n t.

5.

P ersons em ployed in G overnm ent D ep artm en ts, A utonom ous O rganizations and

Public Sector U n d ertak in g s, sh o u ld sen d th e ir ap p licatio n s th ro u g h p ro p e r ch an n el
w ith an A dvance Copy to th e above ad d ress. Envelope co n tain in g th e ap p licatio n form
sh ould have in scrib ed on top of it “APPLICATION FOR THE POST OF DIRECTOR,
IIITfPPP), AGARTALA”. O ne copy (in MS-Word form at) of th e application m u s t be sen t
electronically to praveersaxena.edu@ m c.in w ithin th e p rescrib ed period.

Date of advertisement: 28th July, 2018

<!-- page 3 -->

Format of Application for the post of Director of HIT (PPP) Agartala

Affix the latest
passport
size
Photo

(Applicant is requested to type the information in the following format, and can add more lines in the
format wherever required.)
1. General Information of Applicant
Name
(In Capital Letters)
Date of Birth
(Day/Month/Y ear)
Correspondence
Address

Mobile No. :
Phone No.
Landline No. :
Email

2.Present Position

a.

Designation

b.

Organization

c.

Pay Scale

d.

Date of
appointment to
the present post
Total Experience
(In Years and
Months)

e.

<!-- page 4 -->

2

3.

Details of experience possessed as per eligibility criteria:
(10 years’ Professorship)
S.No.

Post held

Organisation

Pay Scale

Nature of duties

Experience
(In Years and
Months)

4.Educational Qualification (In chronological order from latest to Graduation level)
S.No.

Qualification

University

Year

Subject(s) /
Topic(s)

%
Achieved

Distinctions
etc.

5. Administrative Experience/Post(s) & responsibilities held
S.
No.

Post

1.

Head of the Department
Chairman, Professional/
Academic Bodies
Member, Board of
Studies
Dean of Faculty
Member of Academic
Council/Senate
Member of Executive
Council/BoG
Member of Professional/
Academic Bodies
Others (Specify)

2.
3
4.
5.
6.
7.
8.

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years and
Months)

6. (a) Academic/Teaching Experience & responsibilities (In chronological order from latest to oldest)
S. No.

Post

Organization/
University

From
(Date)

Duration
To
(Date)

Experience
(In Years
and Months)

<!-- page 5 -->

3
(b) Participation and contribution in relevant areas in higher education
Organisation

Area of specialisation

Visiting Professor
Resource Person
Others (Specify)
(c) Involvement with formulation of academic programmes:
S.No.

Nomenclature of Innovative Academic
Programmes formulated

Date of approval by
Senate

Year of
Introduction

(d) Important MoUs formulated for academic collaborations:
S.
No.

MoUs formulated

Name of Agencies/Dcpartments
involved

YearofM oU

Name of Agencies/Dcpartments
involved

Period of holding
the Chair

(e) Position of Chairs:
S. No. Name of Chair

7. International academic Exposure, if any
S. No.

Post/
Assignment

Organization/
Institute

Area of Assignment
From

8. Scholarly achievements:

A. Contribution to Journals and Books:
Details
Books authored
Editor in Chief
Editorships
Peer reviewer for
Member of the International Advisory
Board
Others (Specify)

Duration
In Years &
To
Months

<!-- page 6 -->

%

"5

4

B. Publications:

B.I Kindly provide list of scholarly publications in recognised professional and/or academic journals:
Total Publications: e..................
S.No.

Date

Title

Name of journal

Refereed
journal or
not

Number of
Citations
(where possible)

B.II List of articles in popular magazines or newspapers
Total A rticles:...............
S.No.

Date

Title

Name of Magazine/
Newspaper

C. Participation and scholarly presentations in conferences:
C.I National
S.No.

Date

Title of Conference or Institution
'
r '

Title/Subject of presentation (if made)

Title of Conference or Institution

Title/Subject of presentation (if made)

C.II International
S.No.

Date

D. Participation and contribution in National/International Fora in the area of your academic and
professional expertise
Number(s)
Plenary Lectures/Invited Talks
Congresses attended
Examinership etc.
Others (Specify)

International
National
International
National
International
National
International
National

<!-- page 7 -->

»

5
9. Research Projects:
S.No.

Client/Organisation’s
name

Nature of project

Duration of
project

10. Consulting experience:

List key consulting assignments undertaken:
S.No.

11.

Sr.
No.

Client/ Organisation’s
name

Nature of assignment

Duration of
assignment

Honours /Awards & Fellowships for Outstanding Work:

Name of
Award/F ellowship
etc.

Elected/Honorary
Fellow

Awarded by

Year of Award

*'
12.

No. of Research Scholars successfully guided :

Name of Programme

13.

Awarded (No.) (Under-progress not to be included)

Strengths (in 100 words)

14. Your Vision for the Institute (upto 500 Words)

Amount
of grant
(Rupees)

<!-- page 8 -->

i

6
15. Details of Referees, if any
S. No.

Name of the
Referee

Post Held by
Referee

Email

Phone No.

Mobile

I, hereby, declare that all the statements/ particulars made/furnished in this application are true, complete and
correct to the best of my knowledge and belief. I also declare and fully understand that in the event of any
information furnished being found false or incorrect at any stage, my application/candidature is liable to be
summarily rejected at any stage and if I am already appointed, my services are liable to be terminated
without any notice from the post of Director as per Act/ Statutes etc. and other applicable rules.

Place:
Date:
Note:

(Signature of the Applicant)

Total No. of pages (A-4 size) of the application should not exceed 10 pages.
