---
doc_id: "e5d5adad4f11e08e"
source_url: "https://powermin.gov.in/static/uploads/2025/06/99713d8ffb91d3b323a770903c34f04a.pdf"
ministry: "Power"
title: "Determination of Green Tariff under Electricity (Promoting Renewable Energy Through Green Energy Open Access) Rules, 2022 and Implementation of the Rules"
date: "2023-05-02"
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9e6e88d4c4256228"
---

<!-- page 1 -->

F. No. 13/02/2023-RCM
Government of India
Ministry of Power
(RCM Division)
***
Shram Shakti Bhawan, Rafi Marg,
New Delhi, 13th May, 2023
To
The Secretary of all SERCs/JERCs
Subject: Determination of Green Tariff under Electricity (Promoting
Renewable Energy Through Green Energy Open Access) Rules, 2022 and
Implementation of the Rules - reg.
Madam/Sir,
The Electricity (Promoting Renewable Energy Through Green Energy Open
Access) Rules, 2022 were notified on 6th June, 2022 (amended on 27th January,
2023) to facilitate use of Renewable Energy (RE) by the consumers and to further
accelerate India's RE programs. SERCs/JERCs vide letter dated 10.10.2022 (copy
enclosed) were informed to take appropriate action for determination of Green
Tariff under Rule 4 (2) (C) (c).
2.
The aforementioned rule provides that the tariff for the supply of green
energy shall be determined separately by the Appropriate Commission based on
the Average Pooled Power Purchase Cost of the renewable energy, cross-subsidy
charges (if any), and service charges covering the prudent cost of the distribution
licensee for providing the green energy. Electricity Rules, 2005 (as amended) also
provide that cross subsidy surcharge shall not exceed 20% of Average Cost of
Supply.
3.
It has come to notice that only a few States have determined the Green
Tariffs, however such tariffs had been set at a rate much higher than the Average
Power Purchase Cost of renewable energy procured by the Discoms. It is imperative
that for incentivizing more and more use of renewable energy, the tariff is strictly in
accordance with said Rules. In view of this position, it is clarified that in no case the
Green Tariff should be higher than Average Power Purchase Cost of RE +
Surcharge @ 20% of ACoS + (say) a reasonable margin of 25 paisa.
4.
Further, it was noticed that some SERCs which have notified the Green
Energy Open Access Regulations have not completely aligned the regulations in
accordance with the rules notified by the Ministry. In this regrad attention is drawn
towards the provisions of section 181 of the Act, which mandates that Regulations
by SERCs shall be in consistent with the Act and Rules. The SERCs which have not
notified Green Energy Open Access regulations need to notify the regulations in a
time bound manner. It may be noted that Rules framed under the Act have the
force of law, and any violation of the law is liable for action under the provisions of
the law.

<!-- page 2 -->

5.
Accordingly, it is conveyed to all SERCs to take appropriate action for
determination of Green Tariff, implement the Green Open Access Rules notified by
the Central Government and align Open Access Regulations in accordance with
the notified Rules, at the earliest. The status of compliance may be sent within 15
days of issue of this letter.
6.

This issues with the approval of competent authority.

Encl.: As above.

Yours faithfully,

(Suresh Annepu)
Director (RCM)
Tel: 011-2371-7737
Copy to:

1. Secretary , MNRE, New Delhi
2. ACS/Principal Secretaries (Energy/Power), All States/UTs
3. Secretary, FOR/CERC, New Delhi
4. CMD/MDs of All Discoms
5. Heads of all SLDCs
Copy also to: PS to Hon’ble Minister of Power and NRE/ PPS to Secretary
(Power)/PSO to CE(R&R)/PPS to Director (RCM), MoP.

<!-- page 3 -->

<!-- page 4 -->
