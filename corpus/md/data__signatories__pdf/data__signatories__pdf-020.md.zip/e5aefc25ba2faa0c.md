---
doc_id: "e5aefc25ba2faa0c"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/cda708d358ae983aeef81b5cd0c4ebcb.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 117 of 2024 in the Hon’ble High Court of Delhi: DoT instructions dated 22.05.2026 to ISPs"
date: "2026-05-22"
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f7c2db2ef7582272"
---

<!-- page 1 -->

4-10/2025-DGT/4(Part-IV)

I/3401126/2026

By Email/ DoT Website
File No.:4-10/2025-DGT/4(Part-IV)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
2nd Floor, UIDAI HQ, New Delhi -110001
Date: -05-2026
To
All Licensees with Internet Service Authorization
Subject : CS(COMM) 117/2024 : Universal City Studios LLC & Ors. v.
fzkidd.net & Ors. in the Hon’ble High Court of Delhi.
Please find enclosed the Hon’ble High Court of Delhi order dated 24.04.2026 and
dated 07.02.2024 in the captioned case.
2.
Please refer to para 3 of the Court order dated 24.04.2026, in respect of blocking
access to the website(s)/domain(s) [22 nos.] enumerated in the enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action in respect of blocking access to the said
website(s)/domain(s), as per the enclosed list, in compliance with the said court orders.

Encl: A/A
ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Mr. Aditya Singh Thakur (aditya.t@saikrishnaassociates.com), Plaintiff
Counsel- For kind information and with a request to take action as per the enclosed
Annexure pl.

<!-- page 2 -->

4-10/2025-DGT/4(Part-IV)

I/3401126/2026

CS(COMM) 117/2024 :
Websites
SCHEDULE A
URL
of
New
Mirror/Redirect/Alphan
umeric Variations of
Injuncted Websites

S.No.

Domain
Name
of
Mirror/Redirect
/Alphanumeric Variation
of Injuncted
Websites

1

www.filmyzilla35.com

https://www.filmyzilla3

2

filmyzilla35.com

https://filmyzilla35.com

3

www.filmyzilla34.com

https://www.filmyzilla3
4.com

4

filmyzilla34.com

https://www.filmyzilla3
4.com

5

filmyzilla32.com

https://filmyzilla32.com

6

filmyzilla30.com

https://filmyzilla30.com

7

filmyzilla26.com

https://filmyzilla26.com

8

filmyzilla19.com

https://filmyzilla19.com

9

filmyzilla28.com

https://filmyzilla28.com

10

filmyzilla27.com

https://filmyzilla27.com

11

filmyzilla20.com

https://filmyzilla20.com

12

filmyzilla22.com

https://filmyzilla22.com

13

filmyzilla3.com

https://filmyzilla3.com

14

filmy-zilla.com

https://filmy-zilla.com

15

filmyzilla.com.gr

https://filmyzilla.com.gr

16

filmyzilla0.com

https://filmyzilla0.com

IP Addresses of New
Mirror/Redirect/
Alphanumeric
Variation of Injuncted
Websites

104.21.64.216
172.67.187.227
172.67.187.227
104.21.64.216
104.21.86.33
172.67.214.103
104.21.86.33
172.67.214.103
172.67.223.8
104.21.62.105
172.67.217.75
104.21.35.103
104.21.29.138
172.67.149.58
104.21.11.124
172.67.166.7
172.67.176.125
104.21.31.118
104.21.36.42
172.67.185.47
104.21.16.29
172.67.166.12
104.21.54.224
172.67.142.206
104.21.62.123
172.67.223.196
172.67.222.126
104.21.70.99
104.21.45.173
172.67.217.9
172.67.222.54

<!-- page 3 -->

4-10/2025-DGT/4(Part-IV)

I/3401126/2026

17

filmyzilla.pub

https://filmyzilla.pub

18

moviesmod.blue

https://moviesmod.blue

19

animewatchtv.su

https://animewatchtv.su

20

aniwatchtv.by

https://aniwatchtv.by

21

toonstream.dad

https://toonstream.dad

22

toonstream.one

https://toonstream.one

104.21.54.15
104.21.27.221
172.67.143.155
172.67.171.237
104.21.88.12
104.21.14.224
172.67.204.136
104.21.83.86
172.67.218.62
172.67.155.217
104.21.66.36
172.67.223.2
104.21.17.66

<!-- page 4 -->

5/18/26, 4:25 PM

Fwd: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S. (COMM) No. 117 of 2024 [Universal…

Fwd: Compliance with the Order of the
Hon’ble Delhi High Court dated 24.04.2026 const1.hq< const1.hq-dgt-dot@govcontractor.nic.in >
in C.S. (COMM) No. 117 of 2024 [Universal dgt-dot
City Studios LLC & Ors. v. fzkidd.net & Ors.]

Manish Shukla < dirit.hq-dgt-dot@gov.in >
Mon, 04 May 2026 12:03:20 PM +0530

To "ADG Technology DGT HQ"<adgnt.hq-dgt-dot@gov.in>,"Kripa Shanker Pandey"
<adt.hq-dgt-dot@gov.in>,"SUNIL KUMAR"<const1.hq-dgtdot@govcontractor.nic.in>,"Arun Kumar"<consnt.hq-dgt-dot@govcontractor.in>

हार्दिक शुभकामनाओं के साथ/ With warm regards,
मनीष शुक्ला/ Manish Shukla
निदेशक (टी), डीजीटी मुख्यालय/ Director (T), DGT HQ

============ Forwarded message ============
From: Aditya Singh Thakur <aditya.t@saikrishnaassociates.com>
To: <secy-dot@nic.in>, <dirit.hq-dgt-dot@gov.in>, <ada2.dl-dgt-dot@gov.in>, <cyberlawlegal@meity.gov.in>, <gccyberlaw@meity.gov.in>, <pkumar@meity.gov.in>,
<sathya.s@meity.gov.in>, "Kripa Pandey"<cscsolan33@gmail.com>,
<dgthqtechnologyvertical@gmail.com>, <adt.hq-dgt-dot@gov.in>, <dirds2-dot@nic.in>
Cc: "Mehr Sidhu"<mehr@saikrishnaassociates.com>
Date: Fri, 01 May 2026 10:16:26 +0530
Subject: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in
C.S. (COMM) No. 117 of 2024 [Universal City Studios LLC & Ors. v. fzkidd.net & Ors.]
============ Forwarded message ============

WITHOUT PREJUDICE
BY-EMAIL
Date: 01st May 2026
Department of Telecommunications
Through Secretary,
Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi – 110001
secy-dot@nic.in;
dirds2-dot@nic.in,
dirit.hq-dgt-dot@gov.in
about:blank

1/6

<!-- page 5 -->

5/18/26, 4:25 PM

Fwd: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S. (COMM) No. 117 of 2024 [Universal…

Ministry of Electronics and Information Technology
Through the Director General (DIT) Cyber Laws & e-security),
Electronics Niketan, 6, CGO Complex,
Lodi Road, New Delhi – 110003
cyberlaw-legal@meity.gov.in
gccyberlaw@meity.gov.in

Re: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S.
(COMM) No. 117 of 2024 [Universal City Studios LLC & Ors. v. fzkidd.net & Ors.]
Dear Sir,
1.
We write to you on behalf of Universal City Studios LLC., having its office at
100 Universal City Plaza, Universal City, CA 91608, United States of America, Warner
Bros. Entertainment Inc., having its office at 4000 Warner Boulevard; Burbank, California
91522, United States of America; Columbia Pictures Industries, Inc., having its office at
10202 W. Washington Blvd., Culver City, CA 90232-3195 United States of America;
Netflix Studios, LLC, having its office at 100 Winchester Cir Los Gatos, CA, 95032-1815
United States of America; Paramount Pictures Corporation, having its office at 5555
Melrose Avenue, Hollywood, CA, 90038, United States of America and Disney
Enterprises, Inc., having its office at 500 S. Buena Vista, Burbank, California 91521,
United States of America; (hereinafter referred to as “Our Clients”).
2.
Our Clients are the authors and/ or first owners and/ or owners of
cinematograph films (“Original Content”). Our Clients instituted a Suit against various
infringing websites before the Hon’ble High Court of Delhi, inter alia, for permanent
injunction restraining violation of Plaintiff’s copyrights in relation to the Original Content
as well as for other reliefs. Our Clients also impleaded various internet and telecom service
providers, as well as the concerned Government Departments (Department of
Telecommunication and the Ministry of Electronics and Information Technology), as
Defendants, to ensure effective compliance of any order that the Hon’ble Delhi High Court
was inclined to pass.
3.
The above-mentioned matter came up before Hon’ble Justice Mr. Sanjeev
Narula, High Court of Delhi on 07th February 2024 and the Hon’ble Judge was pleased to
pass an ex-parte ad-interim order in favour of the Plaintiffs. The relevant portion of the
order dated 07th February 2024 is extracted below:
“13. Referring to the judgment in Universal City Studios LLC (Supra), Mr.
Saikrishna seeks a dynamic+ injunction in the present case. He emphasizes that the
directions issued by this Court in the aforesaid judgment have facilitated identification and
blocking of several rogue websites hosting pirated content on just a domestic level, but
also internationally. In the opinion of the Court, present is a fit case for the grant of
protection to future works that may be created by the Plaintiffs. Accordingly, the following
directions are issued:
13.1. The rogue websites – Defendants No. 1 to 28 (as enlisted in Annexure A to this
order) are restrained from, in any manner, streaming, reproducing, distributing, making
available to the public and/or communicating to the public any copyrighted content of the
Plaintiffs including future works of the Plaintiffs, in which ownership of copyright is
about:blank

2/6

<!-- page 6 -->

5/18/26, 4:25 PM

Fwd: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S. (COMM) No. 117 of 2024 [Universal…

undisputed, through their websites identified in the present suit or any mirror/ redirect
websites or alphanumeric websites, or any variations thereof including those websites
which are associated with the Defendants’ websites, either based on the name, branding,
identity of its operator, or discovered to provide additional means of accessing the
Defendants’ websites, and other domains/ domain along with their sub-domains and subdirectories, owners, website operators/ entities or even sources of content.
13.2. The Plaintiffs are directed to file an application under Order I Rule 10 of the
Code of Civil Procedure,1908 [“CPC”] for impleadment of domains that are found to be
mirror/ redirect websites or alphanumeric websites, or any variations thereof including
those websites which are associated with the Defendants’ websites either based on the
name, branding, identity of its operator, or discovered to provide additional means of
accessing the Defendant’s website and are discovered to have been engaging in infringing
the Plaintiffs’ exclusive rights, with sufficient supporting evidence. Such applications shall
be listed before the Joint Registrar, who, on being satisfied with the material placed on
record, shall issue the appropriate directions to the ISPs and the Defendants No. 38 and 39
– Department of Telecommunications and Ministry of Electronics and Information
Technology.
13.3. Defendants No. 29-37/ ISPs shall give effect to this injunction by blocking
Defendants No. 1 to 28, as noted in Annexure A. Defendants No. 38 and 39 shall issue
blocking orders against the websites within a period of one week from the release of the
order.
13.4. The respective Domain Name Registrars of Defendants No. 1 to 28, upon being
intimated by the Plaintiffs, shall lock and suspend the said domain names. In addition, any
details relating to the registrants of the said domain names including KYC, credit card,
mobile number, etc. be also provided to the Plaintiffs.”
4. In view of the order dated 07th February 2024, Our Clients had filed Impleadment
Application against the below-mentioned website, for impleading it as Defendant No. 113134, in the said suit:
Defendant Nos.

Mirror/redirect/alphanumeric domain
name of the Proposed Defendant

about:blank

113.

www.filmyzilla35.com

114.

filmyzilla35.com

115.

www.filmyzilla34.com

116.

filmyzilla34.com

117.

filmyzilla32.com

118.

filmyzilla30.com

119.

filmyzilla26.com

120.

filmyzilla19.com

121.

filmyzilla28.com
3/6

<!-- page 7 -->

5/18/26, 4:25 PM

Fwd: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S. (COMM) No. 117 of 2024 [Universal…

122.

filmyzilla27.com

123.

filmyzilla20.com

124.

filmyzilla22.com

125.

filmyzilla3.com

126.

filmy-zilla.com

127.

filmyzilla.com.gr

128.

filmyzilla0.com

129.

filmyzilla.pub

130.

moviesmod.blue

131.

animewatchtv.su

132.

aniwatchtv.by

133.

toonstream.dad

134.

toonstream.one

5. The learned Joint Registrar of the Hon’ble High Court of Delhi vide Order dated
24th April 2026, was pleased to implead the above-mentioned Defendants and has
extended the ex-parte ad interim injunction order dated 07th February 2024 against the said
Defendants. The relevant extracts of the Order dated 24th April 2026 are reproduced
hereinbelow for ease of reference:
“1. The plaintiffs is seeking to implead additional rogue-websites as defendant no.
113 to 134 because they have been found to be indulging in illegally disseminating the
copyrighted material belonging to the plaintiff. Keeping in view the contents of the suit
and the application, the same is allowed. The proposed defendants are impleaded as
defendant nos. 113 to 134. Issue summons to the newly impleaded defendants.
--XX-XX-XX-3. The lock / suspension and blocking order passed by the Hon’ble Court on
07.02.2024 shall operate qua the freshly impleaded defendants as well which stands
injuncted, in terms of directions contained in paragraph 13 of the order dated 07.02.2024.
Further, in terms of the directions contained in para 13.3, defendant ISP’s shall give effect
to the injunction by blocking defendant nos. 113 to 134. Also, Department of
Telecommunications and Ministry of Electronics and Information Technology shall issue
blocking orders qua defendant no. 113 to 134 within a period of one week in terms of
directions contained in para 13.3 of the order dated 07.02.2024. The concerned DNR of
the newly impleaded defendant shall lock and suspend the domain name, and also supply
necessary details of the domain name registrant / KYC etc to the plaintiffs as directed in
para 13.4 of the order dated 07.02.2024. A copy of this order be served on the ISP’s, DoT
& MEITY and the concerned DNR. Compliance of Order 39 Rule 3 CPC be done within a
week. IA is allowed and disposed off accordingly.”
about:blank

4/6

<!-- page 8 -->

5/18/26, 4:25 PM

Fwd: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S. (COMM) No. 117 of 2024 [Universal…

6.

Accordingly, we request you, DOT & MeitY (i.e. Defendant Nos. 38 and 39

respectively) comply with the order of the Hon’ble High Court of Delhi dated 24th April
2026 by issuing appropriate blocking orders against the said website as identified in
Annexure-A (separately attached along with the email as list of domains), also mentioned
in paragraph 4 of this letter.
7. A copy of the orders dated 07th February 2024 and 24th April 2026 are attached
herewith along with a copy of the Impleadment Application and documents as filed before
the Hon’ble High Court of Delhi are being made available through the following link for
your kind perusal and necessary action:
https://drive.google.com/drive/folders/1m8GaM-A33ldtVa0rUBf8jC-iuFzWWt8L?
usp=sharing
8. For your reference, the next date of hearing in the matter is 2nd July 2026 before
the Joint Registrar. In view of the above facts and circumstances, we request you to
comply with the Order of the Hon’ble High Court of Delhi dated 24th April 2026 by
blocking the Defendant Websites as mentioned in paragraph 4 of this present
communication letter.

Regards,
Aditya Singh Thakur
Saikrishna & Associates
Counsel for the Plaintiffs
Enclosed:
1.

Copy of the order dated 07th February 2024

2.
3.
4.

Copy of the order dated 24th April 2026
List of Websites
Impleadment Application and Documents

Aditya Singh Thakur | Associate | Saikrishna & Associates, 57, Jor Bagh, New Delhi - 110003 | Tel:
+91-120-4633900 (100 Lines), Fax: +91-120-4633999 | Handphone: +91-9098929420 | Enrolment
Number - D/12816/2025
MANAGING IP - Asia-Pacific 2020- Firm of the Year- India- Copyright
WTR 1000 – Gold Ranked Firm- Enforcement & Litigation – 2016 - 2020
CHAMBERS – Asia Pacific 2015-2020 - Leading Firm- IP & TM - 2016-2020
INDIAN BUSINESS LAW JOURNAL– Indian Law Firm Awards-Intellectual Property- 2019 &
2020
INDIAN BUSINESS LAW JOURNAL – Law Firm Awards- Media, Entertainment & Sport -2020
MANAGING IP - Global Awards 2014 - Firm of the Year – India - Patent Contentious
The Information contained in this e-mail and/or in any of the attached files constitutes confidential information of S&A and
may also be the subject of legal professional privilege, not being waived or lost by mistaken transmission or receipt. If you have
received this mail in error, please notify us at info@saikrishnaassociates.com immediately by reply email and destroy the original
- any use, disclosure or copying of this mail is unauthorised.

about:blank

5/6

<!-- page 9 -->

5/18/26, 4:25 PM

Fwd: Compliance with the Order of the Hon’ble Delhi High Court dated 24.04.2026 in C.S. (COMM) No. 117 of 2024 [Universal…

3 Attachment(s)
Annexure A (List of Websites) …

07.02.2024 high_court_order (…

11.7 KB

57.5 KB

24.04.2026 high_court_order (…
121.7 KB

about:blank

6/6

<!-- page 10 -->

$~31
*
IN THE HIGH COURT OF DELHI AT NEW
DELHI
+
CS(COMM) 117/2024
UNIVERSAL CITY STUDIOS LLC & ORS
.....Plaintiff
Through: Ms. Mehr Sidhu, Mr. Aditya
Singh Thakur and Mr. Affan
Moin, Advs.

versus
FZKIDD.NET & ORS.
.....Defendant
Through:

None.

CORAM:
JOINT REGISTRAR (JUDICIAL) MS. SWATI KATIYAR
ORDER
%
24.04.2026
Fresh I.A. 11468/2026 on behalf of the plaintiffs seeking
impleadment of additional mirrors, redirects, or alphanumeric
variations as Defendant nos. 113-134.
1.

The

plaintiffs

is

seeking

to

implead

additional

rogue-websites as defendant no. 113 to 134 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Keeping in view the contents
of the suit and the application, the same is allowed. The proposed
defendants are impleaded as defendant nos. 113 to 134. Issue
summons to the newly impleaded defendants.
2.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve the newly impleaded defendant
with summons within a week through the electronic mode only, on
filing of PF.
3.

The lock / suspension and blocking order passed by the

Hon’ble Court on 07.02.2024 shall operate qua the freshly
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:53

<!-- page 11 -->

impleaded defendants as well which stands injuncted, in terms of
directions contained in paragraph 13 of the order dated
07.02.2024. Further, in terms of the directions contained in para
13.3, defendant ISP’s shall give effect to the injunction by blocking
defendant

nos.

113

to

134.

Also,

Department

of

Telecommunications and Ministry of Electronics and Information
Technology shall issue blocking orders qua defendant no. 113 to
134 within a period of one week in terms of directions contained in
para 13.3 of the order dated 07.02.2024. The concerned DNR of
the newly impleaded defendant shall lock and suspend the domain
name, and also supply necessary details of the domain name
registrant / KYC etc to the plaintiffs as directed in para 13.4 of the
order dated 07.02.2024. A copy of this order be served on the
ISP’s, DoT & MEITY and the concerned DNR. Compliance of
Order 39 Rule 3 CPC be done within a week. IA is allowed and
disposed off accordingly.
MS. SWATI KATIYAR,
JOINT REGISTRAR (JUDICIAL)
APRIL 24, 2026/bk

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:53

<!-- page 12 -->

SCHEDULE A
URL
of
New
Mirror/Redirect/Alphan
umeric Variations of
Injuncted Websites

S.No.

Domain
Name
of
Mirror/Redirect
/Alphanumeric Variation
of Injuncted
Websites

1

www.filmyzilla35.com

https://www.filmyzilla3

2

filmyzilla35.com

https://filmyzilla35.com

3

www.filmyzilla34.com

https://www.filmyzilla3
4.com

4

filmyzilla34.com

5

filmyzilla32.com

https://www.filmyzilla3
4.com
https://filmyzilla32.com

6

filmyzilla30.com

https://filmyzilla30.com

7

filmyzilla26.com

https://filmyzilla26.com

8

filmyzilla19.com

https://filmyzilla19.com

9

filmyzilla28.com

https://filmyzilla28.com

10

filmyzilla27.com

https://filmyzilla27.com

11

filmyzilla20.com

https://filmyzilla20.com

12

filmyzilla22.com

https://filmyzilla22.com

13

filmyzilla3.com

https://filmyzilla3.com

14

filmy-zilla.com

https://filmy-zilla.com

15

filmyzilla.com.gr

https://filmyzilla.com.gr

16

filmyzilla0.com

https://filmyzilla0.com

IP Addresses of New
Mirror/Redirect/
Alphanumeric Variation
of Injuncted Websites

104.21.64.216
172.67.187.227
172.67.187.227
104.21.64.216
104.21.86.33
172.67.214.103
104.21.86.33
172.67.214.103
172.67.223.8
104.21.62.105
172.67.217.75
104.21.35.103
104.21.29.138
172.67.149.58
104.21.11.124
172.67.166.7
172.67.176.125
104.21.31.118
104.21.36.42
172.67.185.47
104.21.16.29
172.67.166.12
104.21.54.224
172.67.142.206
104.21.62.123
172.67.223.196
172.67.222.126
104.21.70.99
104.21.45.173
172.67.217.9
172.67.222.54

<!-- page 13 -->

104.21.54.15
104.21.27.221
172.67.143.155
172.67.171.237
104.21.88.12
104.21.14.224
172.67.204.136
104.21.83.86
172.67.218.62

17

filmyzilla.pub

https://filmyzilla.pub

18

moviesmod.blue

https://moviesmod.blue

19

animewatchtv.su

https://animewatchtv.su

20

aniwatchtv.by

https://aniwatchtv.by

21

toonstream.dad

https://toonstream.dad

172.67.155.217

https://toonstream.one

104.21.66.36
172.67.223.2
104.21.17.66

22

toonstream.one

<!-- page 14 -->

$~43
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 117/2024
UNIVERSAL CITY STUDIOS LLC & ORS
Through:

..... Plaintiffs

Mr. Saikrishna Rajagopal, Ms.
Suhasini
Raina,
Ms.
Ramya
Ramkumar and Mr. Mehr Sidhur,
Advocates.

versus
FZKIDD.NET & ORS.
Through:

..... Defendants
None.

CORAM:
HON'BLE MR. JUSTICE SANJEEV NARULA
ORDER
07.02.2024

%

I.A. 2908/2024 (seeking exemption from filing certified/ clearer/ proper/
translated copies of documents with proper margins)
1.

Exemption is granted, subject to all just exceptions.

2.

The Plaintiffs shall file legible and clearer copies of exempted

documents, compliant with practice rules, before the next date of hearing.
3.

Accordingly, the application stands disposed of.

I.A. 2909/2024 (u/Section 80 r/w Section 151 of the Code of Civil
Procedure, 1908, seeking exemption from issuing notice to Defendant Nos.
38 and 39)
4.

Issue notice to Defendants No. 38 and 39, by all permissible modes,

upon filing of process fee, returnable on 10th July, 2024.
5.

Reply, if any, be filed before the next date of hearing.

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 1 of 13

<!-- page 15 -->

CS(COMM) 117/2024
6.

Let the plaint be registered as a suit.

7.

Upon filing of process fee, issue summons to the Defendants by all

permissible modes. Summons shall state that the written statement(s) shall
be filed by the Defendants within 30 days from the date of receipt of
summons. Along with the written statement(s), the Defendants shall also file
affidavit(s) of admission/denial of the documents of the Plaintiff, without
which the written statement(s) shall not be taken on record.
8.

Liberty is given to the Plaintiffs to file replication(s) within 15 days of

the receipt of the written statement(s). Along with the replication(s), if any,
filed by the Plaintiffs, affidavit(s) of admission/denial of documents of the
Defendants, be filed by the Plaintiffs, without which the replication(s) shall
not be taken on record. If any of the parties wish to seek inspection of any
documents, the same shall be sought and given within the timelines.
9.

List before the Joint Registrar for marking of exhibits on 16th April,

2024. It is made clear that any party unjustifiably denying documents would
be liable to be burdened with costs.
10.

List before Court for framing of issues thereafter.

I.A. 2907/2024 (u/Order XXXIX Rule 1 & 2 r/w Section 151 of the Code of
Civil Procedure, 1908, restraining infringement of copyright)
11.

Mr. Saikrishna Rajagopal, counsel for Plaintiffs, seeks an ex-parte ad-

interim injunction against streaming of Plaintiffs’ original content/ work on
rogue websites impleaded as Defendants No. 1 to 28, which is protected
under the Copyright Act, 1957. He presents the Plaintiffs’ case as follows:
11.1. The Plaintiffs namely, Universal City Studios LLC, Warner Bros.

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 2 of 13

<!-- page 16 -->

Entertainment Inc., Columbia Pictures Industries, Inc., Netflix Studios, LLC,
Paramount Pictures Corporation, and Disney Enterprises, Inc., are amongst
the world’s leading entertainment companies, engaged in the production and
distribution of motion pictures/ cinematograph films. They are the first
author/ owner of these works and assert copyright protection therein.
11.2. There is a proliferation of a large number of online platforms enabling
circulation of unauthorized, unlicensed and pirated content of the Plaintiffs
to viewers. Defendants No. 1 to 28 are few of such rogue websites that are
facilitating the streaming/ viewing of cinematograph films and audio-visual
content such as, motion pictures and television programs, inter alia
generated by the Plaintiffs, on devices connected to the internet. They permit
the viewers to store the content on their personal devices, leading to
largescale copying and dissemination of such content to other unauthorized
and unlicensed users. The said websites act as directories/ indexes of
hyperlinks that redirect the end-user to the host site, where the content can
be streamed or downloaded from a cloud storage site. Defendants No. 1, 2,
5, 6, 8, 9, 19, 11, 13, 17 and 25 even provide a refined search option to the
user, where they can select the content on basis of the type, quality, genre,
year of release etc. The operators of these websites employ techniques to
mask their identities or provide incorrect details for the purpose of domain
name registrations. For a ready reference, a list of impugned websites is
attached to the present order as Annexure A.
11.3. Plaintiffs’ legal notices to takedown the infringing content from the
websites have been futile. Defendants No. 1 to 28 are thus knowingly
engaging in the impugned activities, in utter disregard of the Plaintiffs’
rights. In addition to enabling the hosting, uploading, steaming, reproducing,

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 3 of 13

<!-- page 17 -->

downloading etc. of Plaintiffs’ works, Defendants No. 1 to 28 also offer
hacks to users to circumvent detection or blocking orders. For instance, they
recommend users to use VPN to stream the pirated content. Access to
several of the Defendant-websites has been blocked across jurisdictions,
including, Australia, England and Wales.
11.4. The above-noted assertions are further supported by the findings of a
Private Investigator employed by the Plaintiffs. The Investigator has,
through an extensive investigation, identified the major ‘brands’ of websites
that provide pirated content and the various guises/ names under which the
sites operate. Per the Investigator’s report, if the websites are blocked/ taken
down under a court order, the operators of such websites create mirroring
websites, under the same name so as to draw traffic. For instance, one
“ofilmyzilla.agency” which was ordered to be blocked by this Court vide
judgment dated 31st August, 2021 in CS(COMM) 401/2022,1 resembles
Defendant No. 2 herein [“ofillyzilla.com.ms”]. A similar pattern has been
noted in Defendants No. 1, 3 and 9.
11.5. The Plaintiffs have devoted enormous resources in the creation,
production, distribution, marketing and advertising of their content. The act
of copying Plaintiffs’ original content and storing it on any media, and
communicating the same to the public without Plaintiffs’ assent amounts to
infringement of the Plaintiffs’ copyright by Defendants No. 1 to 28 in terms
of Section 51(a)(i) and (ii) and Section 51(b) of the Copyright Act. In
support of the above, reliance is placed on the judgments of this Court in
UTV Software Communication Ltd. and Ors v. 1337x.to and Ors,2 and
1
2

Titled Universal City Studios LLC v. Myflixer.to and Ors.
DHC Neutral Citation: 2019:DHC:2047.

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 4 of 13

<!-- page 18 -->

Universal City Studios LLC. & Ors. v. Dotmovies.baby & Ors.3
12.

The Court has considered the afore-noted and perused the screenshots

of impugned websites [Defendants No. 1 to 28] which reveal that the said
Defendants are, on a real-time basis, offering for viewing and download the
content originally produced by the Plaintiffs, without their consent or a valid
license, resulting in financial losses to them. In these circumstances, given
the need to adopt stringent measures to curb online piracy, as acknowledged
by this Court on several occasions, the Plaintiffs have been able to
demonstrate a prima facie case in their favour, and in case an ex-parte adinterim injunction is not granted, they will suffer an irreparable loss. Balance
of convenience also lies in favour of the Plaintiffs, and against Defendants
No. 1 to 28.
13.

Referring to the judgment in Universal City Studios LLC (Supra),

Mr. Saikrishna seeks a dynamic+ injunction in the present case. He
emphasizes that the directions issued by this Court in the aforesaid judgment
have facilitated identification and blocking of several rogue websites hosting
pirated content on just a domestic level, but also internationally. In the
opinion of the Court, present is a fit case for the grant of protection to future
works that may be created by the Plaintiffs. Accordingly, the following
directions are issued:
13.1. The rogue websites – Defendants No. 1 to 28 (as enlisted in Annexure
A to this order) are restrained from, in any manner, streaming, reproducing,
distributing, making available to the public and/or communicating to the
public any copyrighted content of the Plaintiffs including future works of the
Plaintiffs, in which ownership of copyright is undisputed, through their
3

DHC Neutral Citation: 2023:DHC:5842.

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 5 of 13

<!-- page 19 -->

websites identified in the present suit or any mirror/ redirect websites or
alphanumeric websites, or any variations thereof including those websites
which are associated with the Defendants’ websites, either based on the
name, branding, identity of its operator, or discovered to provide additional
means of accessing the Defendants’ websites, and other domains/ domain
along with their sub-domains and sub-directories, owners, website operators/
entities or even sources of content.
13.2. The Plaintiffs are directed to file an application under Order I Rule 10
of the Code of Civil Procedure,1908 [“CPC”] for impleadment of domains
that are found to be mirror/ redirect websites or alphanumeric websites, or
any variations thereof including those websites which are associated with
the Defendants’ websites either based on the name, branding, identity of its
operator, or discovered to provide additional means of accessing the
Defendant’s website and are discovered to have been engaging in infringing
the Plaintiffs’ exclusive rights, with sufficient supporting evidence. Such
applications shall be listed before the Joint Registrar, who, on being satisfied
with the material placed on record, shall issue the appropriate directions to
the ISPs and the Defendants No. 38 and 39 – Department of
Telecommunications and Ministry of Electronics and Information
Technology.
13.3. Defendants No. 29-37/ ISPs shall give effect to this injunction by
blocking Defendants No. 1 to 28, as noted in Annexure A. Defendants No.
38 and 39 shall issue blocking orders against the websites within a period of
one week from the release of the order.
13.4. The respective Domain Name Registrars of Defendants No. 1 to 28,
upon being intimated by the Plaintiffs, shall lock and suspend the said

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 6 of 13

<!-- page 20 -->

domain names. In addition, any details relating to the registrants of the said
domain names including KYC, credit card, mobile number, etc. be also
provided to the Plaintiffs.
14.

Compliance of Order XXXIX Rule 3 CPC be effected within five

days. Compliance and service is permitted through e-mail owing to the fact
that the exact contact details or addresses of these parties are not known.
15.

Issue notice to the Defendants, by all permissible modes, upon filing

of process fee, returnable on 10th July, 2024. Reply to the application be
filed within four weeks from the service of the present order along with the
paper book.
16.

List before the Court on 10th July, 2024.

SANJEEV NARULA, J
FEBRUARY 7, 2024/as

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 7 of 13

<!-- page 21 -->

ANNEXURE – A
Particulars of Defendants No. 1 to 28
S. No.

Domain Name

URL

IP Address

https://fzkidd.net

104.21.55.121

Defendant No. 1
1.

fzkidd.net

172.67.148.24
Defendant No. 2
2.

ofilmyzilla.com.
ms

https://www.ofilmyzilla.
com.ms

104.21.38.99
172.67.221.129

3.

ofilmyzilla.com.
ve

https://ofilmyzilla.com.v
e

104.21.69.149
172.67.209.93

4.

ofilmyzilla.it

http://ofilmyzilla.it

104.21.33.68
172.67.159.135

Defendant No. 3
5.

tamilyogi.plus

https://tamilyogi.plus

176.119.25.26

6.

tamilyogi.love

http://tamilyogi.love

176.119.25.26

7.

tamilyogi.band

http://tamilyogi.band

176.119.25.26

https://soap2day.tel

104.21.94.221

Defendant No. 4
8.

soap2day.tel

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 8 of 13

<!-- page 22 -->

172.67.140.139
Defendant No. 5
9.

myflixer.la

10. flixer.ph

https://myflixer.la

111.90.141.93

https://flixer.ph

104.21.81.48
172.67.188.46

11. myflixer.ph

http://myflixer.ph

159.89.195.240

12. sflix.watch

https://www1.sflix.watch

104.21.5.63

13. sflixz.to

https://sflixz.to

172.67.183.133

https://moviesmod.dev

104.26.0.59

Defendant No. 6

Defendant No. 7
14. moviesmod.dev

104.26.1.59
172.67.73.149
15. moviesmod.wiki

https://moviesmod.wiki

104.21.53.236
172.67.219.237

16. moviesmod.one

https://moviesmod.one

104.21.79.159
172.67.146.121

Defendant No. 8

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 9 of 13

<!-- page 23 -->

17. freemovies360.

https://freemovies360.cc

104.21.47.25

Cc
172.67.170.17
Defendant No. 9
18. streamm4u.com

https://ww1.streamm4u.c
om

104.21.37.174
172.67.210.200

19. streamm4u.to

https://streamm4u.to

104.21.63.90
172.67.145.21

Defendant No. 10
20. desicinemas.ink

https://desicinemas.ink

104.21.25.222
172.67.134.204

Defendant No. 11
21. epxmovies.net

https://epxmovies.net

104.21.24.171
172.67.219.195

Defendant No. 12
22. movi.pk

https://movi.pk

104.21.49.206
172.67.192.136

Defendant No. 13
23. 123moviesfree.m
x

https://123moviesfree.m
x

104.21.54.239
172.67.169.131

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 10 of 13

<!-- page 24 -->

Defendant No. 14
24. filmygallery.bab

https://filmygallery.baby

104.21.47.44

25. filmygallery.app

http://filmygallery.app

104.21.79.78

26. filmygallery.cab

https://filmygallery.cab

104.21.74.121

y

172.67.158.91
27. filmygallery.club

http://filmygallery.club

104.21.24.94
172.67.218.37

28. filmygallery.foo

http://filmygallery.foo

104.21.94.154
172.67.137.201

29. filmygallery.lol

http://filmygallery.lol

104.21.92.53
172.67.186.207

30. filmygallery.pro

http://filmygallery.pro

104.21.87.115
172.67.143.6

Defendant No. 15
31. zorox.to

https://zorox.to

172.67.165.179

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 11 of 13

<!-- page 25 -->

32. zoro.vc

http://zoro.vc

104.21.66.209

https://flixwave.to

104.21.44.190

Defendant No. 16
33. flixwave.to

172.67.203.60
Defendant No. 17
34. upmovies.to

https://upmovies.to

172.64.104.12
172.64.105.12

Defendant No. 18
35. mydownloadhubt
ube.net

https://mydownloadtube.
net

104.21.36.51
172.67.185.163

Defendant No. 19
36. movie-web.app

https://movie-web.app

104.21.32.108
172.67.185.164

Defendant No. 20
37. moviekhhd.biz

https://moviekhhd.biz

104.21.1.9
172.67.151.185

Defendant No. 21
38. movieshd.watch

https://movieshd.watch

104.21.42.172
172.67.206.207

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 12 of 13

<!-- page 26 -->

Defendant No. 22
39. goflixtor.com

https://goflixtor.com

104.21.28.235
172.67.147.201

Defendant No. 23
40. cinehub.wtf

https://cinehub.wtf

107.189.2.163

https://arc018.to

104.21.53.54

Defendant No. 24
41. arc018.to

172.67.209.35
Defendant No. 25
42. flixerplus.com

https://flixerplus.com

109.70.148.47

https://netmovies.to

104.21.31.158

Defendant No. 26
43. netmovies.to

172.67.178.61
Defendant No. 27
44. aniwatch.to

https://aniwatch.to

104.26.10.10
104.26.11.10
172.67.69.17

Defendant No. 28
45. toonstream.in

https://toonstream.in

104.21.45.222

CS(COMM) 117/2024
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 01/05/2026 at 09:16:57

Page 13 of 13

<!-- page 27 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
