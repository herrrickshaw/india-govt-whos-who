---
doc_id: "e7ac78fcb5f0b95c"
source_url: "https://www.dot.gov.in/static/uploads/2026/04/5ae8be426a00e587532bd4316eef261b.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allocation of additional Wireline Access Service Codes to M/s Reliance JIO Infocomm Ltd for 3 SDCAs of Bihar and Madhya Pradesh LSAs."
date: "2026-04-09"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "be55b122e57d5c1b"
---

<!-- page 1 -->

16-03/2024-AS-III

I/3386349/2026

Government of India/ भारत सरकार
Ministry of Communications/ संचार मं ालय
Department of Telecommunications/ दरू संचार िवभाग
Sanchar Bhawan, 20 Ashoka Road, New Delhi-110001
संचार भवन, 20 अशोक रोड, नई िद ी-110001
(Access Services Wing)
No.16-03/2024-AS-III/270

Dated:09.04.2026

To,
M/s Reliance JIO Infocomm Ltd.
Subject:- Allocation of additional Wireline Access Service Codes to M/s
Reliance JIO Infocomm Ltd for 3 SDCAs of Bihar and Madhya
Pradesh LSAs.
In consideration of the request of the above-mentioned service provider, the
undersigned is directed to convey the allotment of ﬁxed wireline codes/levels as
per the details given below:
S.
No.

Name of SDCA (SDCA
code)

Name of
LSA

Wireline Code
allotted

1.

JHUMARITALAIYA (6534)

Bihar

32

2.

BETUL (7141)

Madhya
Pradesh

32

3.
2.

BURHANPUR (7325)

Madhya
Pradesh
This is issued with the approval of competent authority.

32

Asst. Director (AS-III)

Copy for kind information and necessary action, if any, to:
1. Secretary, TRAI
2. Director (T), DGT, HQ with request to convey the allocation to concerned
LSA field unit.
3. All Access Service Providers
4. A copy for upload on DoT website.
5. Official language division, DoT for Hindi version of the letter.
