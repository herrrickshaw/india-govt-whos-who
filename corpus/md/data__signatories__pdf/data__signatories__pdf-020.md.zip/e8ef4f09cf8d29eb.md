---
doc_id: "e8ef4f09cf8d29eb"
source_url: "https://mohua.gov.in/static/uploads/2025/10/356b5a41dd6f2834073c507cf26b82b1.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Delhi Apartment ownership Act, 1986"
date: "1986-12-23"
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7eb974646ca937c4"
---

<!-- page 1 -->

REGISTERED No. D-(I))-li

crags y1

M FM

F" *A151 4

t e ^a Otte of ju6 c

I

EXTRAORDINARY
otrr ll-gcs I
PART II- Section 1

PUBLISHED BY AUTHORITY
RO 72]
Rf fdc, if'tft'Ift, fkEr$z, 23, 1986'414 2
^^^^ , 3908 ( TM)
No. dal NEW DELHI , TUSDAY, DECEMBER a;, '986/PAUSA
a, r9o8 (SAKA)

ita wq 73' twxr aaa si anal (S' Partin P:F ^! anT R WWK
Separate paging is glrcu to this Part In order that it may be filed
as a separate compilation

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi,-the 23rd December 1986/Pausa 2, 1908 (Saka)
The following Act of Parliament received the assent of the President
on the 23rd December, 1986, and is hereby published for general information:-

THE DELHI APARTMENT OWNERSHIP ACT, 19$6
No. 58 OF 1986
[23rd December, 1986]
An Act to provide for the ownership of an individual apartment in a
multi-storeyed building and of an undivided interest in the common
areas and facilities appurtenant to such apartment and to make
such apartment and interest heritable and transferable and
for matters connected therewith or incidental thereto.
WHKRrns with a view to securing that the ownership
and control of
the material resources of the community are so distributed
as to sub-serve the common good, it is expedient to provide
for the ownership of
.an individual apartment in a multi-storeyed building and of an undivided
.Interest In the common areas and facilities -appurtenant
to such apartment, and to make such apartment and'interest heritable
and transferable.and to provide for matters connected therewith or incidental
thereto;
Bz it enacted by Parliament in the Thirty-seventh Year
of tha'Republic
of India as follows:-

(1)

<!-- page 2 -->

GAZETTE OF INDIA EXTRAORDINARY

Purr II-

CHAPTERI
Short title,
extent and
commence.
meat.

PRUX&IMAaY
1. (1) This Act may be called the Delhi Apartment Ownership Act,

1986. .

(2) It extends to the whole of the Union territory of Delhi.

Applka.
tion.

(3) It shall come into force on such date as the Administrator may,
by notification in the Official Gazette, appoint.
2. The provisions of this Act shall apply to every apartment in a multistoreyed building which was constructed mainly for residential or commercial or such other purposes as may be prescribed, by(a) any group housing co-operative society; or
(b) any other person or authority,
before or after the commencement of this Act and on a free hold land,
or a lease hold land, if the lease for such land is for a period of thirty
years or more:
Provided that, where a building constructed, whether before or after
the commencement of this Act, on any land contains only two or three
apartments, the owner of such building may, by a declaration duly executed and registered under the provisions of the Registration Act, 1908,
indicate his intention to make the provisions of this Act- applicable to
such building, and on such declaration being made, such owner shall
execute and register a Deed of Apartment in accordance with the provisions of this Act, as if such owner were the promoter
in relation to
such building.

DeAnj•
dons.

3. In this Act, unless the context otherwise requires,(a) "Administrator" means the Administrator of the Union
territory of Delhi appointed by the President
under article 239 of
the Constitution;
(b) "allottee", in relation to an apartment,

means the person
to whom such apartment has been allotted, sold or otherwise transferred by the promoter;
(c) "apartment" means a

part of any property, intended for any
type of independent use, including one or more rooms or enclosed
spaces located on one or more
floors or any part or parts
thereof, in
a multi-storeyed building to be used for residence or office or for the
practice
of any profession, or for the carrying on of any occupation,
trade or business or for such other type of independent
use as may
be prescribed, and with a direct exit
to a public street, road or highway, or to a common area leading to such street, road or highway,
and includes
any garage or room (whether or not adjacent to the
multi-storeyed building in which such apartment is located) provided by the promoter for use by the owner of such apartment for
parking any vehicle or, as the case
may be, for the residence of any
domestic aide employed in such apartment;
(d) "apartment number" means the number, letter or combination thereof , designating an apartment;

<!-- page 3 -->

Sac, 1 ] THE GAZETTE OF INDIA EXTRAORDINARY

(e) "apartment owner" means the person or persons owning an
apartment and an undivided interest in the common areas and facilities appurtenant to such apartment in the percentage specured in the
Deed of Apartment;
(j) "Association of Apartment Owners",(i) in relation to a multi-storeyed building not falling within
sub-clause (ii), means all the owners of the apartments therein;
(ii) in the case of the multi-storeyed buildings in any area,
designated as a block, pocket or otherwise , means all the owners
of the apartments in such block, pocket or other designated area,
acting as a group in accordance with the bye-laws;
(g) "authority" includes any authority constituted or established
by or under any law for the time being in force;
(h) "Board" means.the Board of Management of an Association
of Apartment Owners elected by its members under the bye-laws;
(i) "bye-laws", means the bye-laws made under this Act;
(j) "common areas and facilities ", in relation to a multi -storeyed
building, means(i) the land on which such building is located and all easements, rights and appurtenances belonging to the land and the
building;
(i4) the foundations , columns, girders , beams , supports,
main walls, roofs , halls, corridors, lobbies, stairs stairways, fireescapes and entrances and exits of the building;
(iii) the basements , cellars, yards , gardens, parking areas,
shopping centres, schools and storage spaces;
(iv) the premises for the lodging of janitors or persons
employed for the management of the property;
(v) installations of central services, such as, power. light,
gas, hot and cold water, heating, refrigeration , air conditioning,
incinerating and sewerage;
(vi) the elevators , tanks, pumps , motors, fans, compressors..
ducts and in general all apparatus and installations existing for
common use;
(vii) such other community and commercial facilities. as
may be prescribed;'and
(viii) all other parts of the property necessarv or convenient to its existence , maintenance and safety , or normally in
common use;
(k) "common expenses " means(i.) all sums lawfully assesse' against the apartment owners
by the Association of Apartment Owners for meeting the expenses
of administration . maintenance, repair or replacement of the
common areas and facilities;
(^i) expenses declared as common expenses by the provisions
of this Act or by the bye-laws, or agreed upon by the Association
of Apartment Owners;

<!-- page 4 -->

4'

TAE

GAZETTE OF INDIA EXTRAORDINARY

PART II-

(1) "common profits "

means the balance of all income , rents,
profits and revenues from the common areas and facilities remaining
after the deduction of the common expenses;

(m)"competent authority " means,(i) a Secretary in the Delhi Administration, or
or

(ii) the Vice - Chairman

of the Delhi Development Authority,

(iii) the Land and Development
Officer of the Central Government,
who may be authorised

by the Administrator, by notification in the
Official Gazette, to perform the functions of the competent authority
under this Act;
(n) "Deed of Apartment " means the
Deed of Apartment referred to in section 13;
(o) "Delhi" means the

Union territory of Delhi;

(p) "joint family" means a Hindu
undivided family, and in the
case of other persons ,
a group or unit , the members
by custom , joint in '
of which are
possession or residence;
(q) "limited common areas and facilities "
means those common
areas and facilities which are designated
in
writing
by ' the promoter
.before the allotment ,
sale or other transfer of any apartment as reserved for use of certain apartment
or apartments to the exclusion of
the other apartments;
(r) "Manager " means the Manager

of an Association of Apartment Owners appointed under the bye-laws;
(s) "multi-storeyed

building" means a building constructed on
any land, containing four or more apartments ,
or two or more buildings in any area designated as a block
, pocket or otherwise, each
containing two or more apartments
, with a total of four or more
apartments in all such buildings ,
and includes a building containing
two or three apartments in respect of which a declaration has been
made under the proviso to section 2;
(t) "owner'", in relation to an apartment, inc'udes, for the
purposes of this Act, a lessee
' of the land on which the building containing such apartment has been constructdd, where the lease of such
land is for a period of thirty years or more;
(u) "person" includes a firm and a joint family, and also includes
a group housing co-operative society;
(v) "prescribed" means prescribed by rules made under this Act;
(to) "promoter" means the authority, person or co-operative
society, as the case may be, by which, or by whom, any multistoreyed building has been constructed;
(x) "property" means the land, the multi-storeyed building, all
improvements and structures thereon, and all easements, rights and
appurtenances belonging thereto, and all articles of personal property
intended for use in connection therewith.

1

<!-- page 5 -->

SEC. 1] THE GAZETTE OF INDIA EXTRAORDINARY 5

CHAPTER II
OWNERSHIP, HERITABILITY AND TRANSFERABILITY OF APARTMENTS

4. (1) Every person-to whom any apartment is allotted, sold or otherwise transferred by the promoter, on or after the commencement of this
Act, shall, save as otherwise provided in section 6, and subject to the
other provisions of this Act, be entitled to the exclusive ownership and
possession of the apartment so allotted, sold or otherwise transferred to
him.
(2) Every person to whom any apartment was allotted, sold or otherwise transferred by the promoter before the commencement of this Act
shall, save as otherwise provided under section 6 and subject to the other
provisions of this Act, be entitled, on and from such commencement, to
the exclusive ownership and possession of the apartment so allotted, sold
or otherwise transferred to'him.
(3) Every person who becomes entitled to the exclusive ownership
and possession of an apartment under sub-section (1) or sub-section (2)
shall be entitled to such percentage of undivided interest in the common
areas and facilities as may be specified in the Deed of Apartment and
such percentage shall be computed by taking, as a basis, the value of the
apartment in relation to the value of the property.
(4) (a) The percentage of the undivided interest of each apartment
owner in the common areas and facilities sha'l have a permanent character, and shall not be altered without the written consent of all the apartment owners.
(6) The percentage of the undivided interest in the common areas and
facilities shall not be separated from the apartment to which it appertains and shall be deemed to be conveyed or encumbered with the apartment, even though such interest is not expressly mentioned in the conveyance or other instrument.
(5) The common areas and facilities shall remain undivided and no
apartment owner or any other person shall bring any action for partition
or division of any part thereof, and any covenant to the contrary shall
be void.
(6) Each apartment owner may use the common areas and facilities
in accordance' with the purposes for which they are intended without
hindering or encrbacdling updh the lawful rights-of the other. apartment
owners.
(7) The necessary work relating to maintenance, repair and replacement of the common areas and facilities and the making of any addition.;
or improvements thereto, shall be carried out only in accordance with
the provisions of this Act and the bye-laws.
(8) The Association of Apartment Owners shql' have the irrevocable
right, tr be exercised by the Board or Manager to have access to each
apartment from time to time during r^asonable hours for the maintenance, repairs or replacement of any of the common areas or facilities
therein, or accessible therefrom, or for making emergency repairs therein
necessary to prevent damage to tht common areas and facilities or to
any other apartment or apartments.

Ownership of
apartments.

<!-- page 6 -->

6 THE GAZETTE OF INDIA EXTRAORDINARY PART HApartment to
*be heritable and
transferable.

5. Subject to the provisions of section 6, each apartment, together with
the undivided interest in the common areas and facilities appurtenant
to such apartment, shall, for all purposes constitute as a heritable and
transferable immovable property within the meaning of any law for the
time being in force, and accordingly, an apartment owner may transfer
his apartment and the percentage of undivided interest in the common
areas and facilities appurtenant to such apartment by. way of sale, mortgage, lease , gift, exchange or in any other manner whatsoever in the
same manner , to the same extent and subject to the same rights, privileges , obligations, liabilities, investigations, legal proceedings, remedy and
to penalty, forfeiture or punishment as any other immovable property
or make a bequest of the same under the law applicable to the transfer
and succession of immovable property:
Provided that where the allotment, sale or other transfer of any
apartment has been made by any group housing co-operative society in
favour of any member thereof, the transferability of such apartment and
all other matters shall be regulated by the law applicable to such group
housing co-operative society.

Ownership
of apartment
subject to
conditions.

6. Where any allotment, sale or other transfer of any apartment has
been made, whether before or after the commencement of this Act, In
pursuance of any promise of payment, or part payment, of the consideration thereof, the allottee or transferee, as the case may be, shall not
become entitled to the ownership and possession of that apartment or
to a percentage of undivided interest in the common areas and facilities
appurtenant to such apartment. until full payment has been made of the
consideration thereof together with interest, if.anv due thereon, and
where any such allottee or transferee has been inducted into the possess'on of such apartment or any part thereof in pursuance of such allotment
or transfer, he shall, until the full payment of the consideration has been
made, continue to remain in possession thereof on the same terms and
conditions on which he was so inducted into possession of such apartment or part thereof.

Compliance
with the
cncemmla
and byelaws.

7. Each apartment owner shall comply strictly with the bye-laws and
with the covenants. ronditions and restrictions set. forth in the Deed of
'Apartment, and failure to comply with any of them shall be a ground
for action to recover sums due for damages, or for injunctive relief, or
both. by the Manager or Board on behalf of the Association of Apartment
Owners, or, in a proper case, by an aggrieved apartment owner.

Right
of

R. (1) Where any Land to riven on lease by a person (hereafter in this
section referred to as the lessor) to another person (hereafter in this
section referred to as the lessee. whirl, term shall include a person in
whose favour a sub-lease of such land has been granted). and any multistoreyed building has been constructed on such lease-hold land by the
lessee or by any other person authorised by him or claiming through
him, such lessee shall grant In resnect of the land as many sub-leases
as there are apartments in such multi-storeyed building and shall execute

re-entry.

1-

<!-- page 7 -->

slq
- Stc. 1]

THE GA7X•yZiC OF INDIA EXTRAORDINARY

7

separate deeds of sub- lease in respect
of such land in favour of each
apartment owner,(a) in the case of a multi-storeyed building constructed before
the cotttmencement of this Act, within three months from such commencement, or

(b) in the case of a multi-storeyed building constructed after
the commencement of this Act, within three months from the Cate
on which the possession of any apartment in such muiti-storeyed
building is delivered to him:
Provided that no sub-lease in respect of any land shall be granted
except on the same terms and conditions on which the lease in respect
of the land has been granted by the lessor and no additional terms and
conditions shall be imposed by the lessee except with the previous approval of the lessor.
(2) Where the lessee has any reason to suspect that there had been
any breach of the terms and conditions of the sub-lease referred to in
sub-section (1), he may himself inspect the land on which the multiStoreyed building containing, the concerned apartment has been constructed, or may authorise one or more persons to inspect such land and
make a report as to whether there had been any breach of the terms and
conditions of any sub-lease in respect of such land and, if so, the nature
and extent of such breach, and for this purpose, it shall be lawful for(
the lessee or any person authorised by him to enter into, and to be in,
the land in relation to which such breach has been or is suspected to
have been committed.
(3) Where the lessee or any person authorised by him makes an
inspection of the land referred to in sub-section (1), he shall record in
writing his findings on such inspection [a true copy of which shall be
furnished to the apartment owner by whom such breach of
the terms
and conditions of sub-lease in respect of the land appurtenant to the
apartment owned by him has been committed (hereinafter referred to
as the defaulting apartment owner)] and where such findings
indicate
that there had been any breach of the terms and conditions of the sublease in respect of such land, the lessee
may, by a notice in writing,
require the defaulting apartment owner to refrain from committing any
breach of the terms and conditions of the sub-lease in respect of such
land, or to pay in lieu thereof such composition fees as may be specified
in the notice in accordance with such scales
of composition fees as may
be prescribed.
(4) The defaulting apartment owner who is aggrieved
by any notice
served on him by the lessee under sub-section (3) may, within thirty
days from the date of service of such
notice, prefer an appeal to the
Court of the District Judge having jurisdiction (hereinafter referred to
as the District Court), either challenging the finding of the lessee or any
person authorised by him or disputing the amount of composition fees
as specified in the notice, and the District Court may, after giving the
parties a reasonable opportunity of being heard, confirm, alter
or reverse
those findings or may confirm, reduce or increase
the amount of composition fees or set aside the notice.

<!-- page 8 -->

THE GAZETTE OF INDIA EXTRAORDINARY

PART I(_.-

- (5) Where, on the breach of any terms and conditions of any sub-lease
in respect of any land, any composition fees
become payable , the defaulting apartment owner shall be deemed to have
been guilty of such
breacn and in default of payment thereof it shall be lawful for the lessee
to recover the amount of the composition fees from the defaulting
apartment owner as an arrear of land revenue.
.46) Where any composition fees are paid whether in pursance of
the notice served under suo-section ( 3) or in accordance with the decision
of.the District . Court or a. higher court on appeal ,
no further action shall
be taken by the lessee for the breach of the terms and conditions of the
sub-lease in respect of the land in relation to which payment of such
composition fees has been made.
(7) If the defaulting apartment owner omits or fails to refrain from
committing any breach of the terms and conditions of the sub -lease in
respect of the land or , as the case may be,
omits or fails to pay the
composition fees in lieu thereof(i).in accordance with the notice issued by the lessee under sub-section (3), or
(ii) where the findings of the lessee or the person authorised to
inspect the land about any breach of the terms and conditions of any
sub-lease in respect of the land or the amount of composition fees
specified in the notice issued by the lessee are altered by the District
Court on appeal or by any higher court on further appeal, in accordance with the decision of the District Court or such higher court, .as
the case . may be,
the lessee shall be entitled,(a) where no appeal has been preferred under sub - section (4),
within sixty days from the date of - service of the notice under subsection (3), or
(b) where an appeal has been preferred under sub-section (4),
within. sixty days from the date on which the appeal is finally disposed of by the District Court or, where any further appeal is preferred to a higher court , by such higher court,
to exercise the right of re-entry in respect of the undivided interest of
the lessee in the-land appurtenant to the apartment owned by the defaultingapartment owner, and where such right of re -entry cannot be exercised except ' by the ejectment of the defaulting apartment owner from
his apartment , such right of re-entry shall include . a right to eject the
defaulting apartment owner from the concerned apartment;.
Provided that no such ejectment shall be made unless the defaulting
apartment . owner has been paid by the lessee such amount as compensation for such ejectment as may be determined in accordance with the
,. -prescribed scales of compensation.
(8) No appeal preferred under sub -section (4) shall be admitted,
unless twenty - five per cent. of the composition fees specified in the
notice served on the defaulting apartment owner has been deposited to
the credit of the District Court in savings bank account to be opened by
the District ' Court in any branch of an approved bank:

i

<!-- page 9 -->

S•-11 T.HE GAZE

TTE OF INDIA EXTRAORDINARY

;Provided that theiDistrict. Court may, on sufficient cause b g ,
ieither remit•or reduce the amount of such credit of defaulting apartment
-owner; by whom-such deposit, has been made:
Provided further that the amount of such deposit together with the
Interest due thereon shall be distributed by the District Court in accordance with the decision in such appeal, or where any further appeal has
been. preferred .against such decision, in accordance with the decision in
such further,appeal.
(9) The defaulting apartment owner, who is aggrieved by the amount
offered to be paid to him under the proviso to sub-section (7) as compensation for ejectment from his apartment may, within thirty days from
the date of such offer, prefer an appeal to the District Court and the
District Court may, after giving the parties a reasonable opportunity of
_be.ng, heafd,7maintain, increase or reduce the amount of compensation.

(10) -On the ejectment of the defaulting apartment owner from the
apartment under sub-section (7), the lessee by whom such ejectment has
'been made may make a fresh allotment of the concerned apartment to
any other person on such terms and conditions as he may think fit:
Provided that the consideration for such fresh allotment shall not be
more than the amount which has been paid to the defaulting apartment
owner as compensation.
(11) Where any lessee omits or fails to take any action either in
accordance with the provisions of sub-section (2) or sub-section (3) or
sub-section (7), the'lessor may, in the first instance, require the lessee
.by a notice in writing to take action against the defaulting apartment
owner under sub-section (2) or sub-section (3) or, as the case may be,
under sub-section (7), within a period of ninety days from the date of
service of such notice, and in the event of the omission or failure of the
lessee to do so within such period, the lessor may himself take action as
contained in. sub-section (2) or sub-section (3) or sub-section (7), and
the provisions of sub-section (4) to sub-section (6) and sub-section (8)
to sub-section (10), shall, as far as may be, apply to any action taken by
'him as if such action had been taken by the lessee.
(12) For the removal of doubts, it is hereby declared that no work
in any apartment by the owner thereof shall be deemed to be a breach
pf the terms of the sub-lease in respect of the land on which the multistoreyed building containing such apartment has been constructed unless
the work is prohibited by section 11.

3011955.
6 of 1959.
of 1970.
0 of 1980.

Explanation.-In this section, "approved bank" means the State -Bank
of India constituted under section 3 of the State Bank of India Act, 1955,
or.a subsidiary bank constituted under section 3 of the State Bank of
India (Subsidiary Banks) Act, 1959, or a corresponding new bank conBanking Companies
(Ac and
quisition
' STransfer of
f Under akings) Act, 197
0 or a corresponding new bank con:etituted :under .section .3 of :the Banking Companies (Acquisition and
Transfer of Undertakings) Act, 1980.

<!-- page 10 -->

10 THE GAZETTE OF INDIA EXTRAORDL\ARY
Purchasers or
persons
taking
lease
of apartments
from
apartment
owners
to execute an
undertaking.
Benamidar of
the
apartment to
be
deemed
to be
the

real
owner.

Certain
worts
prohibited.

PART iI-

9. Notwithstanding anything contained in the Transfer of Property
Act, 1882, or in any other law for the. time being in force, any person
acquiring any apartment from any apartment owner by gift, exchange,
purchase or otherwise, or taking lease of an apartment from an apartment owner for a period of thirty years or more, shall,(a) in respect of.the said apartment, be subject to the provisions of this Act; and
(b) execute and register an instrument in such form, in such
manner and within such period as may be prescribed giving an undertaking to comply with the covenants, conditions and restrictions,
subject to which such apartment is owned by the apartment owner
aforesaid.
10. If any apartment is acquired by any person, whether by allotment, sale or otherwise with the consideration thereof paid-or provided
by another person, the acquirer shall, notwithstanding anything contained in the Transfer of Property Act, 1882, or in the Indian Trusts Act, 1882
or in any other law for the time being in force, be deemed to be the
real owner of such apartment,. and no court shall entertain any claim
of the person paying or providing such consideration for title to such
apartment on the ground that the acquisition of the apartment was made
on behalf of such person or on behalf of someone through whom such
person claims.
11. No apartment owner shall do any work which would be prejudicial to the soundness or safety of the property or reduce the value
thereof or impair any easement or hereditament or shall add any
material structure or excavate any additional basement or cellar without first obtaining the consent of all the other apartment owners.
Explanation.-In this section, reference to apartment owners shall
be construed, in relation to a multi-storeyed building in any block,
pocket or other designated area, the apartment owners of the concerned
multi-storeyed building in such block, pocket or other designated area.

Encumbrances
against
apartments.

12. (1) The owner of each apartment may create any encumbrance,
only against the apartment owned by him and the percentage of the
undivided interest in the common areas and facilities appurtenant to
such apartment in the same manner and to the same extent as may
be created in relation to any other separate parcel of property subject to
individual ownership:
Provided that where any such encumbrance is created, the apartment
in relation to which such encumbrance has been created shall not be
partitioned or sub-divided,
(2) No labour performed or material furnished with the consent, or
at the request, of an apartment owner or his agent or his contractor or
sub-contractor, shall be the basis for a charge or any encumbrance under
the provisions of the Transfer of Property Act, 1882, against the apartment or property of any other apartment owner not expressly consentIng to, or requesting the same, except that such express consent shall
be deemed to be given by the other apartment
owner in the ease of
emergency repairs thereto. .

<!-- page 11 -->

5zc.

11 THE GAZETTE OF INDIA EXTRAORDINARY 11

(3) The labour 'performed and material furnished for the common
areas and facilities, if duly authorised by the Association of Apartment
Owners in accordance with the provisions of this Act, or the bye-laws,
shall be deemed to be performed or furnished with the express consent of
each apartment owner and shall be the basis for a charge or encumbrance
under the Act aforesaid against each of the apartments and shall be
subject to the provisions of sub-section (4).
(4) In the event of a charge or any encumbrance against two or
more apartments, becoming effective, the apartment owners of the
separate apartments may remove their apartments and the percentage
of undivided interest in the common areas and facilities appurtenant to
such apartments from the charge or encumbrance on payment of the
fractional or proportional amounts attributable to each of the apartments
affected and on such payment, the apartment and the percentage of undivided interest in the common areas and facilities appurtenant thereto
shall be free of the charge or encumbrance so removed:
Provided that such partial payment shall not prevent the person
having a charge or any of the encumbrances from proceeding to enforce
the rights, in relation to the amount not so paid, against any other
apartment and the percentage of undivided interest in the common areas
and facilities appurtenant to such apartment.
(5) On any such payment, discharge or other satisfaction, referred
to in sub-section (4), the apartment and the percentage of undivided
Interest in the common areas and facilities appurtenant thereto shall be
free and clear of the charge or encumbrance, so paid, satisfied or discharged,
CHAPTER III
DEED 'OF APARTMENT AND ITS REGISTRATION

13. (1) Whenever any allotment, sale or other transfer of any
apartment is made, the promoter shall,(a) in the case of an allotment, sale or other transfer made
after the commencement of this Act, within three month from the
date of such allotment, sale or other transfer, or
(b) in the case of any allotment, sale or other transfer made
before the commencement of this Act, within six months from the
date of such commencement,
execute a Deed of Apartment containing the following particulars,
namely:(i) the name of the allottee,
(ii) description of the land on which the building and the common areas and facilities are located; and whether the land is freehold or lease-hold, and if lease-hold, the neriod of such lease,
(iii) a set of floor plans of the multi-storeyed building showing
the lay-out and location, number of apartments and bearing a verified
statement of an architect certifying that it is an accurate copy of
the portions of the plans of the building as filed with, and approved
by, the local authority within the jurisdiction of which the building is located, - -

eoatects
of
Deed of
Apartment.

<!-- page 12 -->

12 THE. GAZETTE OF INDIA EXTRAORDINARY PART II-

(iv). description of the multi -storeyed building
, stating the
number of storeys and. basements
, the number of apartments in that
building and the principal materials of which
it is constructed,
(v) the apartment number ,
or statement of the location of the
apartment , its approximate area, number and dimension of rooms,
and immediate common area to which it has access, and any other
data necessary for its proper identification,
(vi) description of the common areas and facilities and the
percentage of undivided interest appertaining to the apartment in'
the common areas and facilities,
(vii)

description of. the limited common areas and facilities, if.,
any, stating to which apartments their use is. reserved,
(viii) value of the property and of each apartment
, and a statement that the apartment and such percentage of undivided interest
are not encumbered in any manner whatsoever on the
date of execution of the Deed of Apartment,

(ix) statement of the purposes for which the building
and each
of the apartments are intended and restricted as to use,
(x) the name of the person to receive service of process, together
with the particulars of the residence or place of business of. such
person,
(xi) provision as to the percentage
of votes by the apartment'
owners which shall be determinative of whether to
uild, re pair,
restore , or sell the property in the
event of damage reb
eb destruction
of all or any part of the property:
Provided that the competent authority may, if it is satisfied that the
promoter was prevented by sufficient
cause from executing the Deed
of Apart ment in relation to any apartment
within the period of three
months, or six months, as the case may be, permit the promoter to
execute such Deed of Apartment within such further period ,
not exceeding six months, as it may specify.
(2) The promoter shall(a) file in the office of the competent authority, and
(b) deliver to the concerned allotfee or transferee as the case
may be,
a certified copy of each Deed of Apartment as registered under section
14.
(3) Whenever any transfer of any apartment Is made by the owner
thereof, whether, by sale, lease, mortgage ,
exchange, gift or-otherwise,
the transferor shall deliver to the transferee the certified copy of the Deed
of Apartment delivered to him under sub-section (2) after malting an
endorsement thereon as to the name ,
address and other particulars of
the transferee , to enable the transferee to get the endorsement on the
certified copy of the Deed of Apartment registered in accordance with
the provisions of section 14.

<!-- page 13 -->

SEC. 1

] THE GAZETTE OF INDIA EXTRAORDINARY

13

(4) Whenever any succession takes place to any apartment or part
thereof, the successor shall, within a period of six months from the date
such succession, make an application to the competent authority for
recording
ng such succession on the certified copy of the Deed of Apartment in-relation to the concerned apartment and, if there is any
dispute as to the. succession to. the apartment, the competent authority
shall decide the same, and for this purpose such authority shall have
the powers of a civil court, while trying a suit, and its decision shall
have effect. of a decree and shall be appealable as if it were a decree
passed by the principal civil court of original jurisdiction.
(5) Whenever any succession to an apartment has been recorded by
the competent authority under sub-section (4), such authority shall
send a true copy of such record, to the concerned Registrar for regis'r- tration thereof in accordance with the provisions of section 14.
(6), For, the removal of doubts, it is hereby declared that the provisions of this section shall be in addition to, and not in derogation of,
the provisions of any other law, for the time being in force, relating
to the-transfer of immovable property.
14. (1) Every Deed of Apartment and every endorsement thereon
relating to the transfer of the apartment shall be deemed to be a

16 of 1908

Re s istra
❑ of -tio

document which is compulsorily registrable under the Registration Act, Dead , 1908 and shall be registered
with the Re t Apart'
g i s rar accordingly,
and the words ment.
and expressions used in this section but not defined in this Act, shall have
the meanings respectively assigned. to them, in the Registration Act,
1908.
(2) In all registration offices, a book called "Register of Deeds of
Apartments under the Delhi Apartment Ownership Act, 1986" and an
index relating thereto shall be kept in such form and shall contain such
particulars as may be prescribed.

r (3) Whenever any endorsement on a Deed of Apartment
is registered, the concerned Registrar shall forward a certified copy thereof to the
competent authority to enable that authority to make necessary
entries in
the certified copy of the concerned Deed of Apartment flied with it
under sub- section . (2) of section 13.
(4) Any person acquiring any apartment shall be deemed to have
notice of the contents of the Deed of Apartment and the endorsement,
if any, thereon as from the date of its registration under this section.

CHAPTER

IV

-

•AsSOCIATION OF APARTMENT OWNERS AND
BYE-LAWS FOR Tim, RECVLATION
OF THE AFFAIRS

OF SUCH ASSOCIATION

r 15. (1) There shall be an Association of Apartment Owners for the
administration of tha affairs
in relation to the apartments and the property appertaining thereto and for the management
of common areas
and facilities:
Provided that where-any area has been
demarcated far the construction of , multi-storeyed buildings, whether such
area is called . a block or
pocket or . by-any other name, there shall
he a single Association of
Apartment Owners in such demarcated area;

Association of
Apartment
Owners
and

bye-laws
relating
thereto,

<!-- page 14 -->

14 THE GAZETTE OF INDIA EXTRAORDINARY

PART II-

(2) The Administrator may, by notification in the Official Gazette,
frame model bye-laws in accordance with which the property referred
to in sub-section (1) shall be administered by the Association of Apartment Owners and every such Association shall, at its first meeting, make
its bye-laws in accordance with the model bye-laws so framed, and in
making its bye-laws the Association of Apartment Owners shall not
make any departure from, variation of, addition to, or omission from,
the model bye-laws aforesaid except with the' prior' approval of the
Administrator and no such approval shall be given if, in the opinion of the
Administrator, such departure, variation, addition or omission will
have the effect of altering the basic structure of the model bye-laws
framed by him.

(3) The model bye-laws framed under sub-section (2) shall provide
for the following, among other matters, namely:(a) the manner in which the Association of Apartment Owners
I
is to be formed;
(b) the election, from among apartment owners, of a Board of
Management by the members of the Association of Apartment
Owners;
(c) the number of apartment owners constituting the Board,
the composition of the Board and that one-third of members of the
Board shall retire annually;

(d) the powers and duties of the Board;
(e) the honorarium, if any, of the members of the Board;
(f) the method of removal from office of the members of the
Board; .
(g) the powers of the Board to engage
Manager;

the services of a
- -w-'7I

(h) delegation of powers and duties of the Board to such
Manager;
(i) method of calling meetings of the Association of Apartment
Owners and the number of members of such Association who shall
constitute a quorum for such meetings;
(j) election of a President of the Association of Apartment
Owners from among the apartment owners, who shall preside over
the meetings of the Board and of the Association of Apartment
Owners;
'
(k) election of a Secretary to the Association of Apartment
Owners from among the apartment owners, who shall be an exofficio member of the Board and shall keep two separate minutes
books, one for the Association of Apartment Owners and the other
for the Board, pages of each of which shall be consecutively numbercd and authenticated by the President of the Association of Apartment Owners, and shall record, in the respective minutes books, the
resolutions adopted by the Association of Apartment Owners or the
Board, as the case may be; -

7i

<!-- page 15 -->

Src..lj

THE GAZETTE OF INDIA EXTRAORDINA y 1 j

(1) election of a Treasurer from among the apartment owners,
who. shall keep the financial records of the Association of Apartment Owners as also of the Board;
(m) maintenance, repair and replacement of the common areas
and facilities and payment therefor;
(n) manner of collecting from the apartment owners or any
other occupant of apartments, share of the common expenses;
(o) resignation and removal of persons employed for the maintenance, repair and replacement of the common areas and facilities;
(p) restrictions with regard to the use and maintenance of
the apartments and the use of the common areas and facilities,
as may be necessary to prevent unreasonable interference in the
lase of each apartment and of the common areas and facilities by
the several apartment owners;
(q) any matter which may be required by the Administrator
to be provided for in the bye-laws for the proper or better administration of the property;
(r) such other matters as are required to be, or may be, provided for in the bye-laws.
(4) The bye-laws framed under sub-section (2) may also contain
provisions , not inconsistent with this Act,(a) enabling the Board to retain certain areas of the building
for commercial purposes and to grant lease of the areas so retained,
and to apply the proceeds of such lease for the reduction of the
common expenses for maintaining the building, common areas and
facilities, and if any surplus is left after meeting such expenses, to
distribute such surplus to the apartment owners as income;
(b) relating to the audit of the accounts of the Association of.
Apartment Owners and of the Board, and of the administration of
the property;
(c) specifying the times at which and the manner in which
annual general meetings and special general meetings of the Association of Apartment Owners shall be held and conducted;
(4) specifying the time at which and the manner in which, the
annual report relating to the activities of the Association of Apartment Owners shall be submitted;
(e) specifying the manner in which the income derived and
expenditure incurred by the Association of Apartment Owners shall
be dealt with, or as the case may be, accounted for.
16. (1) The Board or Manager(a) shall have, if requested so to do by a mortgagee having a
first mortgage covering an apartment, the authority to, and
(b) shall, if required so to do by the bye-laws or by a majority
of the apartment owners,
obtain insurance for. the property against loss or damage by fire or
other hazards under such terms and for such amounts as shall be so
requested or required.

103w ance.

<!-- page 16 -->

'16

THE

GAZETTE OF INDIA EXTRAORDINARY

PART.II-

(2)'Such insurance coverage shall be written on the property in the
name, of such Board or Manager as trustee for each of the apartment
owners in the percentages specified in the bye-laws.
(3) The premia payable in respect of every such insurance shall be
common expenses,
(4) The provisions of sub-sections (1) to (3) shall be without prejudice to the right of each of the apartment owner to insure his own
apartment for his benefit.
Disposition of
property,
destruction or,
damage.

17.' If within sixty -days of the date of damage or destruction to all,
or part of any property, or within such further time as the competent
.authority may, having regard to the circumstances of the case, allow,
the Association of Apartment Owners does not determine -to -repair,
reconstruct or re-build such property, then, and in that event,(a) ' the property shall be deemed to be owned in common by
the apartment owners; ,
(b) the undivided interest in the property owned in common,
which shall appertain to each apartment owner, shall be the percentage of the undivided interest previously owned by such owner
in the common areas and facilities;
i (e) any incumbrances, affecting any of the apartments, shall be
deemed to be transferred in accordance with the existing priority
to, the,percentage. of the undivided interest of the apartment, owner
;.in.the property;
(d) the,property shall be subject to an action for partition at
the suit of any apartment owner in which event, the net proceeds
of sale together with the net proceeds of the insurance on the pro.perty, if any, shall be considered as one fund and shall be divided
;amongst all the apartment owners in the percentage equal to the percentage of undivided interest owned by each apartment owner in the
property after paying out, all the respective shares of the apart.ment.owners to the extent sufficient . for the purpose and all charges
on the -undivided interest in the property owned by each apartment
owner,

Action . 18, . (1) 'Without prejudice to the, rights of any apartment owner,
action may be' brought by the Board or Manager, in either case in the
discretion of the Board on behalf of two or more of the apartment owners
as their respective interest may appear, with respect to any cause of
action relating to the common.areas and facilities or more • than one
apartment.
(2) The service of process on two or more apartment owners in any
vction i relating to the. common areas and facilities or more than one
rapaatment may be made on the person, designated in the bye-lawn 'to
receive service of process,

r`

<!-- page 17 -->

Src. 1] THE GAZETTE OF INDIA EXTRAORDINARY

'Y

17

CHAPTER V
COMMON PROFITS, COMMON EXPENSES AND OTHER MATTERS

19. (1) The common profits of the property shall be distributed among,
and the common expenses shall be charged to, the apartment owners
according to the percentage of the undivided interest of the apartment
owners in the common areas and facilities.
(2) Where the apartment owner is not in the occupation of the
apartment owned by him, the common expenses payable by such
apartment owner may be recovered from the person in the occupation
of the apartment.

20. No apartment owner may exempt himself from liability for his
contribution towards the common expenses by waiver of the use of
enjoyment of'any of the common areas and facilities, or by the abandonment of his apartment.

Common
profits,
common
expenses and
other
matters.

Apart' ment
owner
not to be
exempt
from
liability
for contribution,
by waiver
of the,
use of the,
common
areas . and 1,,i-

21. All sums assessed by the Association of Apartment Owners, but
unpaid for the share of the common expenses chargeable to any apartment, shall constitute a charge on such apartment prior to all other
charges except only(i) the charge, if any, on the apartment for payment of Government and municipal taxes; and

Common
expenses
to be a
charge
on the
apartment.

(ii) all the sums unpaid on a first mortgage of the apartment.
22. (1) Notwithstanding anything to the contras, contained in any
law relating to local authorities, each apartment and its percentage of
undivided interest in the common areas and facilities appurtenant to
such apartment (including an apartment in respect of which the provisions
of this Act were applied under the proviso to se&ion 2) shall be deemed
to be separate property for the purpose of assessment of tax on lands and
buildings leviable under such law and shall be assessed and taxed accordingly; and for this purpose a local authority shall make suitable regulations to carry out the provisions of this section.
(2) Neither the multi-storeyed building nor the property nor the
common areas
and facilities referred to in sub-section (1), shall be
deemed to be separate properties for the purpose of the levy of such
taxes.

Separate
assess.
ments.

<!-- page 18 -->

18
Ioint
and
several
liability,
of vendor
etc., for
unpaid
common
expenses.

THE GAZETTE OF INDIA EXTRAORDINARY PART II-

23. (1) Upon the sale, bequest or other transfer of an apartment, the
purchaser of the apartment or the grantee or legatee or the transferee,
as the case may be, shall be jointly and severally liable with the vendor
or the transferor for all unpaid assessments against the vendor or transferor for his share of the common expenses up to the time of the sale,
bequest or other transfer, without prejudice to the right of the purchaser,
grantee, legatee or transferee to recover from the vendor or the transferor any amount paid by the purchaser, grantee, legatee or transferee'
therefor.
(2) Any purchaser, grantee, legatee or transferee referred to in subsection (1) shall be entitled to a statement from the Board or Manager setting forth the amount of the unpaid assessment against the vendor
or transferor, as the case may be, and such purchaser, grantee, legatee
or transferee shall not be liable for, nor shall the apartment be sold
subject to a charge for any unpaid share. of common expenses against such
apartment accrued prior to such sale, bequest or other transfer, in excess
of the amount set forth in the statement.
CHAPTER VI
MISCELLANEOUS

Act to
be binding on
apartment
owners,
tenants,
etc.

24. (1) The provisions of this Act shall have of ect notwithstanding
anything inconsistent therewith contained in any other law for'the time
being in force or in any contract, undertaking or other instrument and
all apartment owners, tenants of owners, employees of owners and
tenants, or any other person who may, in any manner, use the property
or any part thereof to which this Act applies, shall be subject to the
provisions of this Act and the bye-laws and the rules made thereunder:
Provided that nothing contained in this sub-section shall affect the
right, title or interest acquired by any allottee or other person in common areas and facilities from any promoter on or before the 28th day
of February, 1986. (2) All agreements, divisions and determinations lawfully made by
the Association of Apartment Owners in accordance with the provisions
of this Act and the bye-laws shall be deemed to be binding on all apartment owners.

N

Power to
exempt
stamp
duty,
registration fee
and court
fees and
power to
refund.

25. (1) The Central Government may, by notification in the Official
Gazette, reduce or remit, whether prospectively or retrospectively from
a date not earlier than the date of commencement of this Act,(a) the stamp duty with which, under any law relating to
stamp duty for the time being in force, instruments or documents
executed by or on behalf of a promoter, apartment owner or Association of Apartment Owners relating to any of the purposes of this
Act are respectively chargeable;
(b) any fee payable by or on behalf of any promoter, apartment
owner or Association of Apartment Owners in relation to instruments
or documents referred to in clause (a) under any law relating to
registration of documents or to court fees, for the time being in
force,
and which the Central Government is competent to levy.

<!-- page 19 -->

Ssc. 1] THE GAZETTE OF INDIA EXTRAORDIN.4N,y

19
(2) The Central Gover may ut
o: fee paid in pursuance of y refund the amount of any duty
any aandreferred
subj
to in subses ction
such circumstances, to such extent
tions, if subject to such term (1) in
any, as that Government mav, by condiY order, determine .
26. For the removal
,
4 of i8s2, of the doubts
it is hereby declared that the provisions Removal
e Transfer of Property At1882
,
shall, in so far as they are not of
inconsistent
with
the
provisions
Co'
f
this
Act, apply to the transfer of any doubts,
apartment, together with its
.
undivided interest in the cpmmon areas
and facilities appurtenant thereto
,
ment,
by lease
the owner of such apartwhether such transfer is mademade
by sale,
gift or otherwise
, mortgage ,
exchange,
perty.
as they apply to the transfer of any immovable pro-

Gazette
, The Central Government may, by notification in the Official Power to
27. (1)
make rules to carry out the provisions
of this Act.

(2) In particular and m ake
prejudice to the rules.
foregoing Power ,
such rules ma generality of the

matters, namely y Provide for all or any

of the following

(a) the purposes
other than the purposes
for which
specified
any multi-storeyed building may be utilised; in section 2,
(b) the type of
independent use
clause
in
( c) of section than the uses
s other
3, which may be specified
made of an apartment;
(c) the community and commercial facilities
which may be
included
Common areas and facilities under sub clause (v
clause
(j) in
of section 3;
i i) of
(d) the scales of composition fees
section 8 for the breach of the terms andwhich may be paid under
sub-lease; conditions
of any lease or

S
(e) the scales in accordance with which compensati
paid for the ejectment of an apartment owner
of his apartment,
determined as required by sub-section 7)r,m
shall be of section 8;
(j) the form and manner
in which ,
which ,
an instrument referred to in clause and the period within
(
executed and registered; of section
shall
b)9, be
and (g) the form in which the Register of
er the Delhi Apartment Ownershi Inds od A partmenx
relating thereto shall be ke t and p Acicu and the
p
Register shall contain as required b the particulars which index
h such
by sub - section 2
O
(h) an of section
14;
any other matter which
prescribed. is required to be, or
may be,
(3) Every rule made under this Act shall be laid,
be after it is made, before each as soon may
of Parliament wh
session for a total daysHouse
which
ile i
na ris
^eSSlOn or in two period of
I thirty d S
y
be
Comprised
in one
or more session
successive sessions . an
of the
- in
immediate) folio
d if, before the expiry
'
sessions aforesaid ,
session or the successive
both Houses agree
e Vi
making any modification in

<'q1

<!-- page 20 -->

20 THE GAZETTE OF LhDIA EXTRAORDINARY [

!'ART

U-S EC. I]

the rule, or both Houses agee that the rule should not be made, the
rule shall thereafter have effect only in such modified form or be of no
effect, as the case may be; so, however, that any such modification or
annulment shall be without prejudice to the validity of anything
previously done under that rule.

C. RAMAN MENONAdditional Secy. to the Govt. of India.

ii

II

PRINTED BY 17IE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD,
NJ'W DELHI MW PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI,

<!-- page 21 -->

[PART II-SEC . 11 THE GAZETTE

OF INDIA EXTR:?Olt DIIvTARY 21

CORRIGENDA
In the Additional Duties of Excise (Goods of Special Imn ortancc) (Amendment)
Act, 1985 (7 of 1986) as published in the Gazette of India, Extraordinary, Part 11
Section 1, dated the 20th January, 1986 (Issue No. 7) :-

Page Heading/Sub- Column Line For Read
No. Heading No..
3 --- 4 5 6 -2

1701.20

3

1

--

2

2402. 10

3

1

--

-

2

..

3

2

--

3

24.03

3

3

--

3

2403.11

3
3

3

24.04

2
3

3

2404.19

3

3

24C4. 29

3

2

3

2404.32

3

2

3

2404.42

3

1

.ring

Bearing

3

2404.49

4

1

:I

Nil

4

5107. 10

3

4

5107.24

3

6

-

-

7

521)7.90

4

6

schedule

Schedu le

8

5208.23

3

3

,etup

set up

5208.29

4

10

9

5209.11

3

2

; etez

metre

9

5209. 12

3

2.

-eter

metre

10

5211. GO

3

7

OR.

OR-

10

5212.00

3

15

OWNED, OWNED

11

54.09

3

14

N

12

54.10

3

21

C.

3

1

3

1

13:
13

5412. 10

14

5503. 30

17'' 5511.12

--

-

--

-

per

EA HEAT
OR

-

7.
3.

3

-

ptr

--

-

<!-- page 22 -->

22

TEE GAZETTE OF INDIA EXTRAORDINARY [PAST II-.5-'c. 1;
.t

1

2

3

4

5
--

17

55.12

3

23

18

5512. 12

3

1

is

5512. 21

3

1

of

18

55.02

2

7

5802.22

19

58. 05

3

4

typed

19

5805.14

3

2

of

19

5901.20

3

1

20

5902.10.

3

1

20

_502.20.

3

1

20

5902. EG

-

t

20

:9.C:

20

5905.10

20

5905.20

1

21

Section 5.

1

1

3

or

5832.11
`, cJ
of

Of

- c:

viscoscr

viccc^

T1^ :TIL2S

_-

1

Second
S-c3nd
Scheduled Sc..'dnle.
