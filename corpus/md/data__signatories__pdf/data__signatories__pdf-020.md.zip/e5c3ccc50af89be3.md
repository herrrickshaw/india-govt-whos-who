---
doc_id: "e5c3ccc50af89be3"
source_url: "https://www.labour.gov.in/static/uploads/2025/07/29845ed542476171121682a43640f537.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Amendment to the Recruitment Rules of Group 'A' and Group 'B' (Gazetted ) post of DGFASLI-reg."
date: "2024-03-18"
pages: 91
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "f05e1df01b54174e"
---

<!-- page 1 -->

ANNEXURE It
Form to be filled by the Ministry/Department while forwarding proposals to the Ministry of Personnel, Public Grievances and Pensions (Department of Personnel, &
Training) and the Union Public Service Commission for Amending approved Recruitment rules,
1, (a) Name of the Post : Director General
(b) Name of the Ministry/Deptt. : Directorate General Factory Advice Service & Labour Institutes, Ministry of Labour & Employment
2. Reference No, in which Commission's advice on
recruitment rules was conveyed
3:
revision proposed
the pos Labour Institutes Service & Labour Institutes
workload.
Non-Ministerial. Gazetted, Non-Ministerial.
(4) Pay Band and Grade Pay / | Rs,5900-200-6700 Level-14 in the pay matrix (Rs 144200- Pay scale revised to Rs. 18400-500-
Pay scale 218200).* - NPA - Only for those 22400, PB 4 Rs. 37400-67000 + GP.
possessing recognized medical 10000 and Level 14 as per V", VI"
qualification and VII" Pay Commission's
respectively.
(5) Whether Selection No change
selection post
or non-
selection
post
(6) Age limit for Not exceeding 50 years Not Applicable ‘The method of direct recruitment is
direct recruits proposed to be dispensed with,
(Reiaxable for Government servants upto five
years in accordance with the instructions or
orders issued by the Central Government),
Note: The crucial date for determining the age-
limit shall be the closing date for receipt of

<!-- page 2 -->

applications from candidates in India (and not
the closing date prescribed for those in Assam,
Meghalaya, Arunachal Pradesh, Mizoram,
Manipur, Nagaland, Tripura, Sikkim, Ladakh
Division of Jammu and Kashmir State, Lahaul
and Spiti district and Pangi Sub Division of
Chamba district of Himachal Pradesh,
Andaman and = Nicobar = Islands_—or
Lakshadweep.

(7) Whether Yes Not applicable (To be deleted). This is not applicable as the benefit of
benefit qualifying service has been dispensed
of added years with by DoP&PW O.M. No, 7/7/2008-
gisevics P&PW (F) dated 13.02.2009
admissible communicated that Rule 30 of
nade CCS(Pension) Rules ,1972 had been

omitted vide GSR no. 928(E) dated
rule 30 of the 21.12.2012.
CCS (Pension)
Rules, 1972

(8) Educational Essential Not Applicable. The method of recruitment on direct
and (i) Degree in Mechanical or Electrical or recruitment basis is proposed to be
other qualifi- Chemical or Marine or Production or dispensed with,
cations Industrial Engineering or a
required recognized university or equivalent OR
for direct
recruits Master's Degree in Chemistry or Biochemistry

or Psychology (with Industrial Psychology as
one of the papers) or Physiology of a
Recognized University or equivalent. OR

A Recognized Medical qualification
included in the first or second Scheduled or
Part th of
the Third Schedule (other than the licentiate
qualifications) to the Indian Medical Council
Act, 1956 (102 of 1956) Holders of educational
qualifications included in Part II of the Third
Schedule should fulfill the conditions
stipulated in Section 13(3) of the said Act.

<!-- page 3 -->

(ii) Fifteen years’ experience of which seven
years’ should be in a_ responsible
administrative position in an organisation
concerned with training, education and
research in safety and health, productivity and
allied matters like job analysis and work study
and other human problem in Industry such as
Physiology, Ergonomics and Industrial
Psychology.
(iii) Experience of running management
training courses and management consultancy
services.
Note} Qualifications are relaxable at the
discretion of the Union Public Service
Commission in case of Candidates
otherwise well Qualified, =
Note 2: The qualification regarding
experience is relaxable at the discretion of the
Union Public Service Commission in the case
of candidates belonging to the Scheduled
Castes and the Scheduled Tribes if, at any stage
of selection, the Union Public Service
Commission is of the opinion that sufficient
number of candidates from these communities
possessing the requisite experience are not
likely to be available, to fill up the vacancies
reserved for them,

Desirable
Master's Degree in Engineering relevant to
essential qualification(i)" above from a
recognized University or equivalent,

OR
Doctorate Degree in Psychology or Physiology
or Chemistry or Biochemistry of a recognized
University or equivalent.

<!-- page 4 -->

OR
Post-graduate Degree or Diploma in Social and
Preventive Medicine or Industrial] Hygiene or
Physiology or Medicine or Occupational
Health from a recognized University or
quivalent.

(9) Whether age Age: No Not applicable The method of recruitment on direct
and Educational Qualification: Yes recruitment basis is proposed to be
educational dispensed with.
qualifications
prescribed for
direct recruits
will apply in the
case of
romotees

(10)Period of One year for direct recruits Not applicable The method of recruitment on direct
probation, if recruitment basis is proposed to be
an) dispensed with.

(11)Method of Promotion failing which by wansfer on | Promotion failing which deputation | To remove stagnation in feeder
recruitment deputation (including short term contract) | (including short term contract) grade as a DR, if appointed, will
Whether by failing both by direct recruitment, hold the post for atleast 3-5 years
Girect rechiitment during which no promotion will
or by promotion be there and will cause
or by deputation/ is i
trenefee and stagnation.
percentage of
the vacancies
to be filled by
various methods

<!-- page 5 -->

(12) In case of Promotion Promotion
recruitment Years of experience has
by Deputy Director General with three years’ | Deputy Director General with three years’ regular | been proposed to
promotion/ regular service in the grade failing which | service in the grade failing which Deputy Director enhance to make it at
deputation/ Deputy Director General, with eight years’ | General, with eight years’ combined regular service in par with the total
transfer, combined regular service in the grades of | the grades of Deputy Director General/Director. experience of feeder
grades Deputy Director General/Director,
from Note 1: When combined service in the grades of pe
which Note; Where juniors who have completed their | Deputy Director General and Director is considered, Fs 3
promotion/ qualifying/eligibility service are__being | the Officer should have rendered at least one year | 10 line with the
deputation’ considered for promotion their seniors would | regular service in the grade of Deputy Director | qualifications of feeder
transfer to be also be considered provided they are not short | General. grade Posts as
made of the requisite qualifying/eligibility service by Psychology &
more than one year and have successfully Physiology disciplines
completed their probation period, if prescribed. | Deputation (including short term contract) have been dispensed ig
Transfer on deputation (including short | Officers under the Central/State Governments/ Public wit Ma
term contract) Sector Undertakings/Recognized Research Institutes हर ः
Officers under the Central/State Governments! | Statutory or Autonomous Organisations;
Public = Sector ~—_ Undertakings/Recognized a) (i) holding analogous posts on regular basis;
Research Institutes Statutory or Autonomous OR
Organisations; (ii) with three years regular service in posts in
the Pay Level-13 or —_ equivalent;
a) (i) holding analogous posts on regular OR
basis; (iii) with eight years’ regular service in posts in
OR the Pay Level-12 or equivalent; and
(ii) with three years; regular service in
posts in the scale of Rs.4500-5700 or b) Possessing the following educational
equivalent; qualifications:
OR
(iii) with eight years’ regular service in | Essential: (i) Bachelor's Degree in Mechanical
posts in the scale of Rs.3700-5000 or | Engineering or Electrical Engineering or
equivalent; and Chemical Engineering or Instrumentation or
b) Possessing the educational qualifications Production Engineering or Industrial
eed. गत Engineering or Civil Engineering of a
‘The departmental officers in the feeder recognized University or Institute.
category who are in the direct line of
romotion shall not _be eligible _ for

<!-- page 6 -->

consideration for appointment on deputation, Or

similarly, deputationists shall not be eligible

for consideration for appointment by | Master Degree in Chemistry or Biochemistry or

promotion ( period of deputation including | tndustrial Hygiene or Bachelor Degree in

peu of deputation _ another Schaar Pest | biochemical Engineering from a recognized

immediately preceding this appointment Universit

in the same or 5016 other 9

organisation/department of Central

Government shall not exceed five years, The Or

maximum age limit for appointment by | A recognised medical qualification i.e. MBBS

transfer on deputation (including short-term | (or Equivalent) as per the provisions of the

contract) shall be not exceeding 56 years as on | National Medical Commission Act. 2019;

the closing date of receipt of applications), And
Post Graduate Degree or Diploma in Preventive
and Social Medicine or Community Medicine or
Industrial Health from a recognized university.
(ii) Twenty one years’ experience of which ten
years’ should be in a responsible administrative
position in an organisation concerned as Head of
the organisation or a Division of an Industry with
handling various aspects of industrial safety
including training, —_ education, research,
productivity, management consultancy services
and allied matters like job analysis and work
study and other human problem in Industry such
as Occupation Health, Welfare and social
wellbeing.
Desirable:
Master’s Degree in Engineering relevant to
essential qualification (i) above from a
recognized University or equivalent.

Or

<!-- page 7 -->

Doctorate Degree in or Chemistry or Bio-
Chemistry of a recognized University or
equivalent.
(13) Ifa 1. Group ‘A’ Departmental Promotion | 1. Departmental Promotion Committee
Departmental Committee (for considering promotion) (for considering promotion)
Promotion (i)Chairman/Member, Union Public Service
Committee Commission — Chairman (i) Chairman/Member, Union Public Service
exists, what (i)Secretary, Ministry of Labour — Member. Commission — Chairman
is its composition (iii)Additional Secretary/ Ministry of Labour- | (ii) Secretary, Ministry of Labour —Member-
Member (iii) Additional Secretary or equivalenv Joint
Secretary or Equivalent, Ministry of Labour-
2. Group ‘A’ Departmental Promotion | Member
Committee
(for considering confirmation)
i)Secretary, Ministry of Labour — Chairman.
ii)Additional Secretary, Ministry of Labour —
Member.
Note: The proceedings of the Departmental
Promotion Committee relating to confirmation
of a direct recruit shall be sent to the Union
Public Service Commission for approval. 1,
however, these are not approved by the Union
Public Service Commission a fresh meeting of
the Departmental Promotion Committee to be
presided over by the Chairman or a Member of
the Union Public Service Commission shall be
held.
(14)Circumstances Consultation with the Union Public Service | Consultation with the Union Public Service
in which Commission necessary while making direct | Commission is necessary.
Union Public recruitment and appointing an officer on
Service deputation (including short-term contract).
Commission
is to be
consulted in
making
recruitment

<!-- page 8 -->

4. Names, addresses and telephone numbers
of the Ministry's Representatives with
whom these proposals may be discussed,
if necessary, for clarification/early decision
Date : Signature of the officer
sending the proposals
Place ; Tele No.:

<!-- page 9 -->

ANNEXURE Til
Form to be filled by the Ministry/Department while forwarding proposals to the Ministry of Personnel, Public Grievances and Pensions (Department of
Personnel, & Training) and the Union Public Service Commission for Amending approved Recruitment rules.
1. (a) Name of the Post : Deputy Director General
(b) Name of the Ministry/Deptt. : Directorate General Factory Advice Service & Labour Institutes, Ministry of Labour
2. Reference No. in which Commission's advice on
recruitment rules as conveyed
3.
Provision in the approved rules Revised provisions proposed Reasons for the
revision proposed
Deputy Director General, Factory Advice Deputy Director General, Factory Advice
the post Service and Labour Institutes Service and Labour Institutes
3* (1989). *-Subject to variation dependent on | 3* (2023). *-Subject to variation dependent on
workload workload
Non-Ministerial, Non-Ministerial.
(4) Pay Band and Rs.4500-150-5700. Level-13 in the pay matrix (Rs 123100-215500).*- | Pay scale revised to Rs,
Grade Pay / Pay scale NPA - Only for those possessing recognized 14300-450-22400, PB 3+
medical qualification GP 8700 and Level 13 as per
Vv", Vi® and VII" Pay
Commission's respectively.
(5) Whether Selection. No change
selection post
or non-
selection
post
(6) Age limit for Not exceeding 50 years (Relaxable for | Not Applicable The method of recruitment
direct recruits Government servants upto five years in on direct recruitment basis is

<!-- page 10 -->

accordance with the instructions or orders proposed to be dispensed
issued by the Central Government). with.
Note: The crucial date for determining the age

limit shall be the closing date for receipt of

applications from candidates in India (and not

the closing date prescribed for those in Assam,

Meghalaya, Aninachal Pradesh, Mizoram,

Manipur, Nagaland, Tripura, Sikkim, Ladakh

Division of Jammu and Kashmir State, Lahaul

and Spiti district and Pangi Sub-Division of

Chamba district of Himachal Pradesh, the

Andaman and Nicobar Islands or

Lakshadweep).

(7) Whether Yes Not applicable (To be deleted) This is not applicable as the
benefit benefit of qualifying service
of added years has been dispensed with by
ता ब्लास्ट DoP&PW O.M, No, 7/7/2008-
admissible P&PW (F) dated 13.02.2009
ander: communicated that Rule 30 of

3 CCS(Pension) Rules ,1972 had
rule 30 of the been omitted vide GSR no.
CCS (Pension) 928(E) dated 21.12.2012.
Rules, 1972

(8) Educational Essential Not Applicable The method of recruitment
and other (Degree in Mechanical or Electrical or on direct recruitment basis is
qualifications Chemical or Marine or Production or proposed to be dispensed
required Industrial Engineering of a recognized with.
for direct University or equivalent.
recruits OR

Master’s Degree in Chemistry or Bio-
chemistry or Physiology or Psychology (with
Industrial Psychology as one of the papers) of
a recognized University.

OR
