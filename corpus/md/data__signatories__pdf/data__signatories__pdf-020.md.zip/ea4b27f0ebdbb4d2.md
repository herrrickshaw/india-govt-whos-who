---
doc_id: "ea4b27f0ebdbb4d2"
source_url: "https://moef.gov.in/storage/tender/The-Water-(Prevention-and-Control-of-Pollution)-Amendment-Act-2024.pdf"
ministry: "Environment, Forest and Climate Change (MoEFCC)"
title: "S.O. 5408(E) [21-12-2023] - वन्यजीव (संरक्षण) अंतर्राष्ट्रीय व्यापार के नियम, 2023।    साईज :  353.91 KB"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ecc1dcabfeb64aa2"
---

<!-- page 1 -->

jftLVªh lañ Mhñ ,yñ—(,u)04@0007@2003—24

REGISTERED NO. DL—(N)04/0007/2003—24

सी.जी.-डी.एल.-अ.-16022024-252144
xxxGIDHxxx
CG-DL-E-16022024-252144
xxxGIDExxx

vlk/kkj.k
EXTRAORDINARY
Hkkx II — [k.M 1
PART II — Section 1

izkf/kdkj ls izdkf'kr
PUBLISHED BY AUTHORITY
lañ 5]

ubZ fnYyh] c`gLifrokj] Qjojh 15] 2024@ ek?k 26] 1945 ¼'kd½

No. 5]

NEW DELHI, THURSDAY, FEBRUARY 15, 2024/MAGHA 26, 1945 (SAKA)

bl Hkkx esa fHkUu i`"B la[;k nh tkrh gS ftlls fd ;g vyx ladyu ds :i esa j[kk tk ldsA
Separate paging is given to this Part in order that it may be filed as a separate compilation.

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 15th February, 2024/Magha 26, 1945 (Saka)
The following Act of Parliament received the assent of the President on the
15th February, 2024 and is hereby published for general information:—

THE WATER (PREVENTION AND CONTROL OF POLLUTION)
AMENDMENT ACT, 2024
NO. 5 OF 2024
[15th February, 2024.]

An Act further to amend the Water (Prevention and Control of Pollution)
Act, 1974.
6 of 1974

WHEREAS in pursuance of clause (1) of article 252 of the Constitution, the Water
(Prevention and Control of Pollution) Act, 1974 had been passed by Parliament;
AND WHEREAS it is considered necessary to make certain amendments thereto for
decriminalising and rationalising minor offences to further enhance trust-based governance
for ease of living and doing business;
AND WHEREAS in pursuance of clause (1) of article 252 of the Constitution read with
clause (2) thereof, resolutions have been passed by the Legislative Assemblies of the States
of Himachal Pradesh and Rajasthan to the effect that the said Act should be amended by an
Act of Parliament for the purposes hereinafter appearing.
BE it enacted by Parliament in the Seventy-fifth Year of the Republic of India as
follows:—
1. (1) This Act may be called the Water (Prevention and Control of Pollution) Amendment
Act, 2024.

Short title
application and
commencement.

<!-- page 2 -->

2

2

THE GAZETTE OF INDIA EXTRAORDINARY

[Part II—

(2) It applies, in the first instance, to the whole of the States of Himachal
Pradesh and Rajasthan and the Union territories; and it shall apply to such other
State which adopts this Act by resolution passed in that behalf under clause (1) of
article 252 of the Constitution read with clause (2) thereof.
(3) It shall come into force, at once in the States of Himachal Pradesh and
Rajasthan and the Union territories, and in any other State which adopts this Act
under clause (1) of article 252 of the Constitution read with clause (2) thereof on
the date of such adoption.
Amendment of
section 4.

2. In section 4 of the Water (Prevention and Control of Pollution) Act, 1974
(hereinafter referred to as the principal Act), in sub-section (2), in clause (a), after
the words “State Government”, the words “in such manner as may be prescribed
by the Central Government” shall be inserted.

Amendment of
section 5.

3. In section 5 of the principal Act, in sub-section (9), after the word
“prescribed”, the words “by the Central Government” shall be inserted.

Amendment of
section 25.

4. In section 25 of the principal Act, in sub-section (1), for the proviso, the
following proviso shall be substituted, namely:—
“Provided that the Central Government may in consultation with the
Central Board, by notification in the Official Gazette, exempt certain
categories of industrial plants from the provisions of this sub-section.”.

Insertion of new
section 27A.
Power to issue
guidelines.

5. After section 27 of the principal Act, the following section shall be
inserted, namely:—
“27A. (1) Notwithstanding anything in this Act, the Central
Government in consultation with the Central Board, may, by notification in
the Official Gazette, issue guidelines on the matters relating to the grant,
refusal or cancellation of consent by any State Board for establishment of
any industry, operation or process, or treatment and disposal system or to
bringing into use of a new or altered outlet including the mechanism for
time-bound disposal of the application made under section 25 or period of
validity of such consent.
(2) Every State Board, in discharge of its functions for the purposes
of grant, refusal or cancellation of consent under section 25 or section 27
shall act in accordance with the guidelines issued under sub-section (1).”.

Substitution of
new sections 41
and 41A for
section 41.

6. For section 41 of the principal Act, the following sections shall be
substituted, namely:—

Failure to
comply with
provisions of
section 20 or
directions issued
thereunder.

“41. (1) Whoever contravenes or does not comply with the directions
given under sub-section (2) or sub-section (3) of section 20, within such
time as may be specified in the direction, shall, in respect of each such
contravention or non-compliance, be liable to pay a penalty which shall not
be less than ten thousand rupees, but which may extend to fifteen lakh
rupees.
(2) Where any person continues contravention or non-compliance
under sub-section (1), he shall be liable to pay an additional penalty of ten
thousand rupees every day during which such contravention continues.

6 of 1974.

<!-- page 3 -->

Sec. 1]

3

THE GAZETTE OF INDIA EXTRAORDINARY

41A. (1) Whoever contravenes or does not comply with any order or
direction issued under clause (c) of sub-section (1) of section 32 or any
direction issued by a court under sub-section (2) of section 33 or any direction
issued under section 33A, shall, in respect of each such contravention or noncompliance, be liable to pay the penalty which shall not be less than ten
thousand rupees, but which may extend to fifteen lakh rupees.

3
Failure to
comply with
provisions of
section 32, or
directions issued
under section 33
or section 33A.

(2) Where any person continues contravention or non-compliance
under sub-section (1), he shall be liable to pay an additional penalty of ten
thousand rupees every day during which such contravention continues.”.
7. In section 42 of the principal Act,—
(a) in sub-section (1), for the long line, the following long line shall
be substituted, namely:—

Amendment of
section 42.

“shall be liable to pay penalty which shall not be less than ten thousand
rupees, but which may extend to fifteen lakh rupees.”;
(b) for sub-section (2), the following sub-section shall be substituted,
namely:—
“(2) Where any person continues contravention or non-compliance
under sub-section (1), he shall be liable to pay an additional penalty of
ten thousand rupees every day during which such contravention
continues.”.
8. For sections 43 and 44 of the principal Act, the following sections shall
be substituted, namely:—

Substitution of
new sections for
sections 43 and
44.

“43. Whoever contravenes the provisions of section 24, shall be liable
to pay the penalty which shall not be less than ten thousand rupees, but
which may extend to fifteen lakh rupees and where such contravention
continues, he shall be liable to pay an additional penalty of ten thousand
rupees every day during which such contravention continues.

Penalty for
contravention of
provisions of
section 24.

44. Where for the purpose of grant of a consent in pursuance of the
provisions of section 25 or section 26, the use of a meter or gauge or other
measure or monitoring device is required and such device is used for the
purposes of those provisions, any person who knowingly or wilfully alters
or interferes with that device so as to prevent it from monitoring or
measuring correctly shall be liable to pay penalty which shall not be less
than ten thousand rupees, but which may extend to fifteen lakh rupees.”.

Penalty for
contravention of
section 25 or
section 26.

9. Section 45 of the principal Act shall be omitted.

Omission of
section 45.

10. For section 45A of the principal Act, the following sections shall be
substituted, namely:—
‘45A. If any person contravenes any of the provisions of this Act or
any order or direction issued thereunder, for which no penalty has been
provided for in this Act, shall be liable to pay the penalty which shall not be
less than ten thousand rupees, but which may extend to fifteen lakh rupees,
and where such contravention continues, he shall be liable to pay an
additional penalty which may extend to ten thousand rupees for every day
during which such contravention continues.
45B. (1) The Central Government, for the purposes of determining the
penalties under the provisions of this Act shall appoint an officer not below
the rank of Joint Secretary to the Government of India or a Secretary to the

Substitution of
new sections
45A to 45E for
section 45A.
Penalty for
contravention of
certain
provisions of
Act.

Adjudicating
officer.

<!-- page 4 -->

4

4

THE GAZETTE OF INDIA EXTRAORDINARY

[Part II—

State Government to be the adjudicating officer, to hold an inquiry and to
impose the penalty in the manner, as may be prescribed:
Provided that the Central Government may appoint as many
adjudicating officers as may be required.
(2) The adjudicating officer may summon and enforce the attendance
of any person acquainted with the facts and circumstances of the case to give
evidence or to produce any document, which in the opinion of the
adjudicating officer, may be useful for or relevant to the subject-matter of
the inquiry and if, on such inquiry, he is satisfied that the person concerned
has contravened the provisions of this Act, he may determine such penalty
as he thinks fit under the provisions of this Act:
Provided that no such penalty shall be imposed without giving the
person concerned an opportunity of being heard in the matter.
(3) The amount of penalty imposed under the provisions of
sections 41, 41A, 42, 43, 44, 45A and 48, shall be in addition to the liability
to pay relief or compensation under section 15 read with section 17 of the
National Green Tribunal Act, 2010.
Appeal.

45C. (1) Any person aggrieved by the order passed by the
adjudicating officer under section 45B may prefer an appeal to the National
Green Tribunal established under section 3 of the National Green Tribunal
Act, 2010.

19 of 2010.

19 of 2010.

(2) Every appeal under sub-section (1) shall be filed within sixty days
from the date on which the copy of the order made by the adjudicating
officer is received by the aggrieved person.
(3) The National Green Tribunal may, after giving the parties to the
appeal an opportunity of being heard, pass such order as it thinks fit,
confirming, modifying or setting aside the order appealed against.
(4) Where an appeal is preferred against any order of the adjudicating
officer under sub-section (1), such appeal shall not be entertained by the
Tribunal unless such person has deposited with the Tribunal ten per cent. of
the amount of the penalty imposed by the adjudicating officer.
Penalty amount
to be credited to
Environmental
Protection Fund.

45D. Where an adjudicating officer imposes penalty or additional
penalty, as the case may be, under the provisions of this Act, the amount of
such penalty shall be credited to the Environmental Protection Fund
established under section 16 of the Environment (Protection) Act, 1986.

Offences for
failure to
comply with
provisions of
section 25 or 26
and for failure
to pay penalty.

45E. (1) Whoever fails to comply with the provisions of section 25 or
section 26, in respect of each such failure, shall be punishable with
imprisonment for a term which shall not be less than one year and six
months but which may extend to six years and with fine, and in case the
failure continues, with an additional fine which may extend to fifty thousand
rupees for every day during which such failure continues after the conviction
for the first such failure.
(2) If the failure referred to in sub-section (1) continues beyond a
period of one year after the date of conviction, the offender shall be
punishable with imprisonment for a term which shall not be less than two
years but which may extend to seven years and with fine.
(3) Where any person fails to pay the penalty or the additional penalty,
as the case may be, imposed under the provisions of this Act within ninety
days of such imposition, he shall be punishable with imprisonment for a
term which may extend to three years, or with fine which may extend to
twice the amount of the penalty or additional penalty so imposed or with
both.

29 of 1986.

<!-- page 5 -->

Sec. 1]

5

THE GAZETTE OF INDIA EXTRAORDINARY

5

(4) Where any offence under sub-section (1) or sub-section (2) or
sub-section (3) has been committed by a company, every person who, at
the time the offence was committed, was directly in charge of, and was
responsible to, the company for the conduct of the business of the
company, as well as the company, shall be deemed to be guilty of such
offence and he shall be liable to be proceeded against and punished
accordingly:
Provided that nothing in this sub-section shall render any such person
liable to any punishment provided in sub-section (1) or sub-section (2) or
sub-section (3), if he proves that the offence was committed without his
knowledge or that he exercised all due diligence to prevent the commission
of such offence.
(5) Notwithstanding anything in sub-section (4), where an offence has
been committed by a company and it is proved that the offence has been
committed with the consent or connivance of, or is attributable to any
neglect on the part of, any director, manager, secretary or other officer of
the company, such director, manager, secretary or other officer shall also
have deemed to be guilty of that offence and shall be liable to be proceeded
against and punished accordingly.
Explanation.—For the purposes of this section,—
(a) “company” includes body corporate, firm, trust, society and
any other association of individuals;
(b) “director”, includes director of the company, partner of the
firm, members of the society or trust or member of any association of
individuals, as the case may be.’.
11. Section 47 of the principal Act shall be omitted.
12. For section 48 of the principal Act, the following section shall be
substituted, namely:—
“48. (1) Where contravention of any provision of this Act has been
committed by any Department of the Central Government or State
Government, the Head of the Department shall be liable to pay the penalty
equal to one month of his basic salary:

Omission of
section 47.
Substitution of
new section for
section 48.
Penalty for
contravention
by Government
Department.

Provided that such Head of the Department shall not be liable for such
contravention, if he proves that the contravention was committed without
his knowledge or instructions or that he exercised all due diligence to
prevent such contravention.
(2) Where any contravention under sub-section (1) is attributable to
any neglect on the part of, any officer, other than the Head of the
Department, such officer shall be liable to pay the penalty equal to one
month of his basic salary:
Provided that such officer shall not be liable for the contravention, if
he proves that he exercised all due diligence to avoid such contravention.”.
13. In section 49 of the principal Act, in sub-section (1), after clause (a), the
following clause shall be inserted, namely:—
“(aa) the adjudicating officer or any officer authorised by him in this
behalf; or”.

Amendment of
section 49.

<!-- page 6 -->

6

6
Amendment of
section 63.

THE GAZETTE OF INDIA EXTRAORDINARY

[Part II— Sec. 1]

14. In section 63 of the principal Act, in sub-section (2),—
(i) after clause (a), the following clause shall be inserted, namely:—
“(aa) the manner of nomination of the chairman of the State
Board and the terms and conditions of service of the chairman of the
State Board under clause (a) of sub-section (2) of section 4 and under
sub-section (9) of section 5;”;
(ii) after clause (m), the following clause shall be inserted, namely:—
“(ma) the manner of holding inquiry and imposing penalties by
the adjudicating officer under section 45B;”.

Amendment of
section 64.

15. In section 64 of the principal Act, in sub-section (2), in clause (e), for
the words, brackets and figures “the chairman and the member-secretary of the
State Board under sub-section (9) of section 5 and”, the words “the membersecretary of the State Board” shall be substituted.

———
The above Bill has been passed by the Houses of Parliament.

DR. RAJIV MANI,
Secretary to the Govt. of India.

Dated the

Speaker.
—————

I assent to this Bill.

Dated the

President.

UPLOADED BY THE MANAGER, GOVERNMENT OF INDIA PRESS, MINTO ROAD, NEW DELHI–110002
AND PUBLISHED BY THE CONTROLLER OF PUBLICATIONS, DELHI–110054.
MGIPMRND—741GI(S3)—15-02-2024.

signed
Kshitiz Digitally
by Kshitiz Mohan
Date: 2024.02.15
Mohan 10:54:23 -08'00'
