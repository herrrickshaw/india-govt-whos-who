---
doc_id: "e984ff6dadde16f0"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/ae4f5ebba9470651ac74d56a24617430.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Advisory for Haj Pilgrims-Advisory to HAJ Pilgrims on MERS-CoV infection"
date: "2017-09-06"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3246de6610fa272e"
---

<!-- page 1 -->

Ministry of Health and Family Welfare
Government of India
Haj Pilgrimage 2013
Advisory to HAJ Committee on MERS-CoV infection
(Formerly called “novel coronavirus”)
WHO has reported 96 confirmed cases of Middle East Corona virus (MERS-CoV) and
47 deaths in 8 countries since the outbreak was first reported in April. 2012 till 19th
August, 2013. Most people infected with MERS-CoV had severe illness and pneumonia,
with around 50% mortality. The virus can spread from person to person through close
contact, so pilgrims living and travelling in close quarters may be at risk, even though
the risk is considered very low. However, the disease has High mortality and there is no
available vaccine or specific treatment for illness. World Health Organization has
issued interim travel advice on MERS-CoV for pilgrimages to Saudi Arabia. (On
WHO website)
The Saudi Ministry of Health recommends that elderly (above 65 years of age) and
those with chronic diseases (e.g. heart disease, kidney disease, respiratory disease,
diabetes) and pilgrims with immune deficiency (congenital and acquired), Malignancy
and terminal illnesses, pregnant women and children (under 12) coming for Hajj and
Umrah this year, to postpone the performance of the Hajj and Umrah for their own
safety. In view of this it is recommended that individuals in above mentioned categories
should think postponing their travel/pilgrimage this year. At present WHO does not
advise
specific
measures
at
Port
of
Entries
(Airport/Ports
of
embarkation/disembarkation).

Current Situation
Cases of respiratory illness caused by Middle East Respiratory Syndrome Coronavirus
(MERS-CoV) have been identified in multiple countries. MERS-CoV was previously
called "novel coronavirus."

MERS Cases and Deaths, April 2012 – till 19th August, 2013
Countries

Cases (Deaths)

Countries

Cases (Deaths)

France

2 (1)

Saudi Arabia

76 (39)

Italy

3 (0)

Tunisia

2 (0)

Jordan

2 (2)

Qatar

2 (1)

Total

96 (47)

United Kingdom
United Arab Emirates (UAE)

3 (2)
6 (2)

<!-- page 2 -->

As a matter of precaution, Ministry of Health and Family Welfare, Govt. of India has
issued following guidance for the Haj pilgrims and visitors to the Saudi Arabia.
All pilgrims should have a prior HEALTH CHECK-UP and obtain a medical fitness
certificate duly signed by a Qualified Medical Practitioner (with MBBS and registered
with Medical Council of India or with State Medical Council) and be advised to comply
with common public health guidelines to curb the spread of respiratory infectious
disease as follows:
1. Before leaving for India advice, on general health precautions.

 Maintain good personal hygiene
 Wash hands with soap and water or disinfectant, especially after coughing and
sneezing.
 Use disposable tissues when coughing or sneezing and dispose it in the waste
basket.
 Try as much as possible to avoid hand contact with the eyes, nose and mouth.
 Avoid direct contact with the infected persons (people with symptoms such as
cough, sneeze, expectoration, vomiting, and diarrhoea) and do not share
personal gadgets.
 Wearing masks, especially when in crowded places.
 All haj pilgrims should have a prior HEALTH CHECK-UP and obtain a
medical fitness certificate duly signed by a Qualified Medical Practitioner
(with MBBS qualification, registered with Medical Council of India or with
State Medical Council).
2. During Travel To Saudi Arabia
 All travellers suffering from fever while on flight should contact on arrival, the
Medical Help Desk at the International Airport for assistance.
3. During period of stay in Saudi Arabia
3.1 During the stay/pilgrimage avoid close contact with any person having
respiratory illness and follow general health precautions as mentioned
above.
3.2 Look for Symptoms of MERS CoV infection:
• Haj pilgrims and visitors to the Saudi Arabia should be familiar with the
symptoms of this disease, namely fever, cough, running nose, sore
throat and difficulty in breathing. Participants and visitors need to selfmonitor their health.

<!-- page 3 -->

3.3 If you think you have symptoms of MERS Cov infection:
• Consult the medical officer in your camp/ contingent. If need be, seek
immediate advice from the medical facility provided at the camp
dispensary.
• If the advice of the medical doctor is to stay in the camp, avoid close
contact with others for 14 days (after your symptoms begin). All close
contacts should seek Health care if they develop any symptoms
(suffering from fever and symptoms of lower respiratory illness, such as
cough or shortness of breath), up to within 14 days of their return to
India. Report to nearest identified health facility if symptoms aggravate
(high fever, difficulty in breathing, blue colour of the skin or lips, blood in
sputum).
• Anyone who contracts MERS Cov during the visit to Saudi Arabia should
consult at health facilities for diagnosis and treatment notified by the
Government and such patients should use triple layered surgical masks.
(all persons, including a healthcare worker or family members should
seek medical advice, Who was in contact with or has provided care for
the patient suffering from acute fever and respiratory symptoms.)
3.4 Follow simple public health measures to prevent spread of MERS Cov as
given in Annexure-1
4. While returning to India
•

While returning to India, if you think you have fever, symptoms of respiratory
illness, you are advised to report to the Immigration desk or medical unit at
the arrival hall.

5 After return to India:
•

After returning to India, for 14 days, continue to be on the lookout for
symptoms of MERS CoV and report to the health facility for treatment.

<!-- page 4 -->

Annexure-1
Do’s and Dont’s
DOs:








Cover your mouth and nose with a handkerchief or tissue when you
cough or sneeze.
Wash your hands often with soap and water or use an alcohol based
hand gel.
Avoid touching your eyes, nose or mouth.
Avoid crowded places.
Stay more than an arm's length from persons afflicted with flu.
Get plenty of sleep.
Drink plenty of water and eat nutritious food.

DO NOT:



Shake hands or hug in greeting.
Take medicines without consulting a physician.

<!-- page 5 -->
