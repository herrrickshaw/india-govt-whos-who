---
doc_id: "e72af51dfecb3e3b"
source_url: "https://mnre.gov.in/static/uploads/2025/07/3587bbdceb8bddea366ada289beb7d42.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Scheme Guidelines for Implementation of Pilot projects for use of Green Hydrogen in the steel sector under the National Green Hydrogen Mission"
date: "2024-02-02"
pages: 10
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "895509f9499481be"
---

<!-- page 1 -->

353/77/2023-NT
Government of India
Ministry of New and Renewable Energy
(Hydrogen Division)
कक
Atal Akshay Urja Bhawan, Lodhi
Road, New Delhi 110003
Date: 02 February 2024
To

The Pay & Accounts Officer, '

Ministry of New and Renewable Energy, New

Delhi- 110003
Subject: Scheme Guidelines for implementation of Pilot projects for use of Green

Hydrogen in the Steel Sector under the National Green Hydrogen Mission
(NGHM)
Sir/Madam,

I am directed to convey the sanction of the President of India for the
implementation of the Scheme for Pilot projects on use of Green Hydrogen in the Steel
Sector under the National Green Hydrogen Mission (NGHM)
he Objectives: The Scheme has following objectives:

i. To advance technologies and expertise for the utilization of Green Hydrogen in

the steelmaking process, addressing any existing gaps.

ii, To support the deployment of Green Hydrogen and its derivatives in the steel,

on a pilot basis.

ili. To validate the technical feasibility and performance of Green Hydrogen and

its derivatives in the Iron & Steel manufacturing in real-world operational हु

conditions.

iv. To evaluate the economic viability of the use of Green Hydrogen and its

derivatives in the iron & steel sector

v. To evaluate the performance of Green Hydrogen and its derivatives based low-

carbon iron & steel and identify the areas for improvement.

vi. To demonstrate safe and secure operations of Green Hydrogen and its

derivatives based production of low-carbon iron & steel.

3. The Scheme will be implemented as per the detailed Guidelines given at Annexure.
4, The expenditure on this scheme will be met from the budget provisions made under
the National Green Hydrogen Mission Head.

5. The Implementing Agency for this scheme shall be nominated by the Ministry of
Steel

<!-- page 2 -->

6. This issues in exercise of the powers conferred on this Ministry and with the
concurrence of IFD vide their Diary. No. 405 dated 02 February 2024.
7. This has the approval of Hon'ble Minister of Power and New and Renewable Energy.
Yours faithfully,
oy oe
(Prasad Chaphekar)
Deputy Secretary
Email: prasad.chaphekar@gov.in
‘ Enclosed: Annexure
Copy to
1. Secretary, Ministry of Steel
2. All Central Government Ministries and Departments
3. All Members of the Empowered Group under the Mission
4, All Members of the Advisory Group under the Mission
5. CEO, NITI Aayog, Sansad Marg, New Delhi
6. State Nodal Agencies (SNAs) of all States/UTs
7. Major Public Sector Enterprises operating in Renewable Energy/Power Sector
8. Principal Director of Audit, Scientific Audit-II, DGCAR, I.P. Estate, Delhi-11002
9. Director General (Local Bodies), Office of the Comptroller & Auditor General,
Deendayal Upadhyay Marg, New Delhi
10. Solar Energy Corporation of India (SECI), 6th floor, Plate-B, NBCC office, Block tower-2,
East Kidwai Nagar, New Delhi. 110023
11. Indian Renewable Energy Development Agency Limited (IREDA), 3rd floor, August
Kranti Bhavan, Bhikaji Cama place, New Delhi-110066
Internal distribution
1. PS to Hon'ble Minister of Power and New and Renewable Energy
2. PS to Hon'ble Minister of State of New and Renewable Energy and Chemicals and
Fertilizers
3. PSO to Secretary, MNRE
4. AllJoint Secretaries/Advisors/Group heads, MNRE
5. All Scientist-F /Scientist-E/Director, MNRE
6. All Scientist -D/Deputy Secretaries, MNRE
7. All Scientists-C/Under Secretaries, MNRE
8. All Scientist-B, MNRE
9. NIC, MNRE for uploading on the MNRE website
10. CA, MNRE for cash Section
11. Hindi Section of Hindi Version
12. Sanction Folder

<!-- page 3 -->

Annexure
Ministry of New & Renewable Energy (MNRE)
Government of India
kek
Scheme Guidelines for implementation of Pilot projects for use of Hydrogen in the
Steel Sector

1. Introduction

1.1. The National Green Hydrogen Mission, hereafter mentioned as the ‘Mission’, was
launched on 4 January 2023 with an outlay of Rs. 19,744 Crore with an aim to make
India a Global Hub for production, usage and export of Green Hydrogen and its
derivatives. It will contribute to India’s goal to become Aatmanirbhar (self-reliant)
through clean energy and serve as an inspiration for the global Clean Energy
Transition. The Mission will lead to significant decarbonisation of the economy,
reduced dependence on fossil fuel imports, and enable India to assume technology
and market leadership in Green Hydrogen. Under the Mission, along with other
initiatives, the Ministry of New & Renewable Energy (MNRE) proposes to implement
pilot projects for replacing fossil fuels and fossil fuel-based feedstock with GH» and its
derivatives.

1,2. Steel production is one of the potential sectors where Green Hydrogen can replace
fossil fuels. With the falling costs of renewable energy and electrolysers, it is
expected that Green-Hydrogen based steel can become cost-competitive over the
next few years. Provision of carbon credits and imposition of market barriers on
carbon intensive steel, in some countries, is likely to further enhance the viability of
Green Hydrogen based steel. To assess the potential for use of Green Hydrogen in
the steel industry, the Mission supports setting up of pilot projects in the steel
sector. These pilot projects will be implemented through the Ministry of Steel (MoS)
and the Scheme Implementing Agencies (SIAs) as elaborated under this scheme.

2. Pilot Projects in Steel Sector

2.1, Para 7.7.1(c) of the Mission Document states that the efforts to enhance low - carbon
Steel production capacity will be supported. Considering the higher costs of Green

<!-- page 4 -->

Hydrogen at present, Steel plants can begin by blending a small percentage of Green है
Hydrogen in their processes. The blending proportion can be progressively
increased as cost-economics improves and technology advances. Further, upcoming
steel plants should be capable of operating with Green Hydrogen. This would ensure

that these plants are able to participate in future global low-carbon Steel markets.
Green field projects aiming at 100% green steel will also be considered.

2.2, Thrust areas under this Scheme for providing support for development/ selection/
validation of commercially viable technologies, for the utilization of hydrogen in steel
sector, are as follows:

i, Use of 100 % Hydrogen in DRI process using vertical shaft/kiln
ii, Use of Hydrogen in Blast Furnace, as per limits prescribed.
iii, Substitution of fossil fuels with Hydrogen in a gradual manner in DRI
process,
iv. Any other innovative use of Hydrogen for reducing Carbon emissions in
Iron & Steel production.
3. Objectives of the Scheme
i, To advance technologies and expertise for the utilization of Green Hydrogen in
the steelmaking process, addressing any existing gaps.
: ii, To support the deployment of Green Hydrogen and its derivatives in the steel,
ona pilot basis.

iii. To validate the technical feasibility and performance of Green Hydrogen and its
derivatives in the Iron & Steel manufacturing in real-world operational
conditions.

iv. To evaluate the economic viability of the use of Green Hydrogen and its
derivatives in the iron & steel sector.

v. To evaluate the performance of Green Hydrogen and its derivatives based low-
carbon iron & steel and identify the areas for improvement.

vi. To demonstrate safe and secure operations of Green Hydrogen and its
derivatives based production of low-carbon iron & steel.

4. Budgetary Outlay: Rs. 455 Crore till FY 2029-30
5. Rationale and the Salient Features
se? हु

<!-- page 5 -->

5.1. These pilot projects will help identify operational issues and gaps in terms of current
technology readiness, regulations, implementation methodologies, infrastructure and
supply chains. These will serve as valuable inputs for future scaling and commercial
deployment of Green Hydrogen in the iron & steel sector.

5.2. The use of Green Hydrogen and its derivatives in the steel sector, through the
proposed pilot projects, will lead to development of necessary infrastructure
including as refueling stations, storage and distribution networks, resulting in
establishment of a Green Hydrogen ecosystem in the steel sector. With the expected

के reduction in the cost of Green Hydrogen production over the years, the utilization in
the steel industry is expected to increase.

5.3. Salient features of the Scheme are given below:

i, Projects with an intention to develop Pilot Scale/ Demonstration Plants for
replication of technology will be supported.

li, Ministry of Steel shall finalize the SIA(s) for implementation of the Scheme

iii, Ministry of Steel to develop a transparent and competitive framework for
selection of pilot projects.

iv. The SIAs shall issue the call for proposals for projects under the scheme in line
with the selection framework developed by Ministry of Steel.

v. MNRE will issue administrative sanctions for the projects under the Scheme है
based on the recommendations of Project Appraisal Committee (PAC).

vi. The SIA will share knowledge and the outcome of the pilot projects through
project completion report, monitoring reports, workshops, and publications to
disseminate findings, best practices, and lessons learned from the pilot.

vii. | The Scheme aims to leverage existing resources and infrastructure available for
transport, storage and use of Green Hydrogen and its derivatives in the iron &
steel sector.

viii, The Scheme would primarily fund capital equipment required for use of
Hydrogen in the iron & steel manufacturing process Expenses on account of
production of Hydrogen, land, etc. will not be funded. The cost of preparing the
Detailed Project Report (DPR) may be covered under the scheme for approved
projects subject to the ceiling specified in sub-para x.

ix, Financial support for projects will be evaluated and granted taking into
consideration the specific needs, merits, and feasibility of each project.

en

<!-- page 6 -->

x. Funding of the approved projects shall not exceed 50% of the total cost of the
project. For consortium of Independent Steel Producers (ISP) and DRI industry
or associations or DRI industry, the funding may be increased to 70% of the
project cost, with the approval of the Project Appraisal Committee.

6. Implementation Methodology
6.1. Selection of application areas: Ministry of Steel will explore the possibilities of
हि taking up the projects in consortium mode. The SIA will identify the areas for

implementation of pilot projects based upon the thrust areas mentioned in para 2.2

in consultation with the Ministry of Steel.

6.2. Call for proposals: The SIA(s) will issue Call for Proposals for the projects. The
न proposal shall be submitted to the SIAs. In case of a consortium/partnership-based
proposal, a lead agency should be mentioned, which shall function as Executing

Agency (EA) for that project.

i. The eligible EAs would include CPSUs, State-PSUs, Private sector, State
Corporations, Indian R&D institutions/Research labs/academic institutions,
JVs/Partnerships/Consortiums of such entities.

ii The necessary capabilities need to exist with the EAs for taking forward the
completed pilot projects towards commercialization.

6.3. Evaluation and Award: The proposals will be evaluated by a Project Appraisal

Committee in accordance with the criteria specified in the Call for Proposals. The

letter of Award shall be issued to the EA by the SIA upon receipt of administrative

sanction from MNRE.
6.4. Execution and Commissioning: Work shall be executed as per the approved scope
+ of work,
6.5. Technical and Regulatory approvals: The EA shall be solely responsible for
obtaining the safety, environmental and regulatory approvals, as required.
6.6. Testing and Certification: The EA shall get necessary testing and certification
compliance from concerned agencies.
se”
4

<!-- page 7 -->

7. Funding and Disbursement
7.1 Ministry of Steel may decide the allocation of the budget between different types of
pilot projects envisaged to be taken up under the scheme.
7.2 Stages of disbursement of CFA for both the components is given below:
[so] Stages of Disbursement Percentage of CFA to be released
23060 लाल 0 80०५ (१७७)
Milestone based disbursements*
* The milestones for disbursement of funds shall be specified in the Call for proposals to
be issued by the SIA.

7.3 Funds will be released to the SIAs by MNRE on the recommendation of the Project
Appraisal committee, received through Ministry of Steel.

7.4 Ministry of Steel may also specify further terms and conditions for grant of financial
assistance for general financial prudence.

8. Timelines and Penalty Provisions

8.1. The grants released shall be exclusively earmarked for the project and should not be
diverted for any other purpose.

8.2. If the EA fails to utilize the grant for the purpose for which it has been sanctioned or
fails to complete the project as per DPR, it shall refund the entire amount of the grant,
with interest as per GFR to MNRE.

३०) ह

<!-- page 8 -->

8.3. The Call for proposals should indicate a suitable timeline for completion of the
project. Extension of up to one year may be granted for completion of the project on
the basis of adequate justification, with the approval of the Steering Committee,
without any penalty. Any extension beyond one year shall only be granted with the
approval of the Minister of New and Renewable Energy, with suitable penalties which
shall be specified by the SIAs in the Call for Proposals issued.

8.4. MNRE reserves the right to retract sanction or cancel or short-close projects in
consultation with the Steering Committee in cases where the EA(s) or the project(s)
face unreasonable delays or fail to comply with the objectives/ provisions of this
Scheme or the Mission.

9. | Monitoring Framework

9.1 Steering Committee

9.1.1 Overall monitoring of the scheme and projects undertaken will be carried out by a
Steering Committee (SC) under the co-chairpersonship of Secretary, Ministry of Steel
and Secretary, MNRE. The Steering Committee shall be responsible for overall
monitoring and implementation of this scheme and suggest modifications and course
corrections for its successful implementation.

हु 9.1.2 In case of any ambiguity in the interpretation of any of the provisions of this scheme,
| the decision of MNRE shall be final. The SC will also facilitate/ recommend measures
to resolve difficulties, if any.
: 9.2 Project Appraisal Committee: A Project Appraisal Committee (PAC) under the
chairpersonship of Secretary/Additional Secretary, Ministry of Steel, with Mission
Director, National Green Hydrogen Mission (NGHM) as a member and other members
Me nominated by Ministry of Steel shall monitor/review/evaluate the project proposals
and recommend projects for sanction of Central Financial Assistance (CFA). The PAC
shall monitor sanctioned projects on a quarterly basis for the allocation of funds based
upon the progress of the project. The PAC shall send recommendations to MNRE for
the release of CFA through Ministry of Steel.

9.3 The SIAs shall also devise a monitoring mechanism to track the progress under the
pilot projects. The same may be shared with Ministry of Steel and MNRE.

eb”

<!-- page 9 -->

9.4 Quarterly monitoring reports shall be submitted by the SIAs to Ministry of Steel and
MNRE.

9.5 Expenditure of funds will be monitored by MNRE. Utilization Certificates shall be
provided by the SIA as per the provisions of GFR.

10. Project Completion

10.1. The SIAs shall submit the Project Completion Report (PCR) to the PAC within one
month from the completion of project. PCR shall include the following:

i, Technical aspects of the project, including the hardware, software, and other

technologies used.

ii, Technical challenges encountered during the project, and how they were
overcome.

iii, Outcome of the project comprising of technical know-how generated along with
the data collected during the execution of the project.

iv. Recommendations for future projects, based on the lessons learned from
project.

11. Guidelines for safeguard of Intellectual property: Ministry of Steel shall issue the
necessary guidelines for the safeguard of any Intellectual Property Rights such as
Publications, Patents, Registered Designs or Trademarks etc. which are generated
through projects funded under this scheme. The guidelines may also be a part of the
Call for Proposals to be issued by the SIAs.

12. Power to amend Scheme Guidelines: MNRE may make the necessary amendments
in the Scheme Guidelines, as and when required, with the approval of the Minister of
New & Renewable Energy.

sek

<!-- page 10 -->

\
