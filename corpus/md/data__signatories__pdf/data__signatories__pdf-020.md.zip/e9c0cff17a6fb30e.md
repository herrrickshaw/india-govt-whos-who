---
doc_id: "e9c0cff17a6fb30e"
source_url: "https://www.dot.gov.in/static/uploads/2026/06/2c6e9db8f58d7adcc63ca38f29cc45b8.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Amendment to CMTS License Agreement in respect of definition of Networth"
date: "2014-01-08"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3f7c71698df7c5d7"
---

<!-- page 1 -->

Government of India
Department of Telecommunications
AS-I Cell
No.20-405/2013-AS.I

Dated the 08-Jan, 2014

To,
All CMTS Licensees
Subject: Amendment to CMTS License Agreement in respect of definition of Net worth.
In exercise of the powers conferred in pursuance of Condition 5 of the CMTS License
Agreement the LICENSOR hereby amends following definition of Net worth in the CMTS
License agreement.
S.No.
I.

Existin2 clause

Amended clause

Tender document for CMTS, Section Ill,
General Conditions No. 5.1 (iii)
....
Net worth is defined as the total in Rupees
ofpaid up equity capital and free reserves.
Net worth of individual promoters shall be
taken as equal to assets minus liabilities.

Tender document, Section III CMTS, General
Conditions No. 5.1 (iii)

..

" . ...
Net worth shall be as defined in the Companies Act
2013 and as amended from time to time.

....."

..... ..

2.
All other terms and conditions of the CMTS License agreement including
amendments and instructions issued from time to time shall remain unchanged.
3.

Please acknowledge receipt.

~)S\1\1'1

(R.K.SONI)
Director (AS.I)
Ph.N o.23036284.
Copy to:
I. Administrator USOF/Wireless Advisor/Sr. DDG(TEC)
2. Sr DDG(WPF)/Sr DDG(Security-Term)/JS(T)/ DDG(CS)/ DDG(DS) /DDG(LF-I)/
DDG(LF-II)/DDG (AC)
3. Secretary TRAI
4. Director (IT) may kindly arrange to upload this letter on the website ofDoT.
