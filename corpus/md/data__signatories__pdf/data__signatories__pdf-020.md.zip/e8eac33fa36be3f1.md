---
doc_id: "e8eac33fa36be3f1"
source_url: "https://dof.gov.in/static/uploads/2025/12/249bfd7d22b936653a69b43849aac5af.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Corrigendum-4_Date Extension & Pre Bid under the section “ RFB for Hiring a Communication Agency under PM-MKSSY”"
date: "2025-12-18"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "9021a9c14614222a"
---

<!-- page 1 -->

Government of India
Ministry of Fisheries, Animal Husbandry & Dairying
Department of Fisheries
First Floor, Chandra Lok Building, Janpath,
New Delhi-110001
CORRIGENDUM NO.4 Date: 17.12.2025
Subject: Revision of Bid Submission End Date and holding of Pre-Bid Meeting to clarify
further queries हि
This is in continuation of the earlier corrigenda issued in respect of the Request for Bids
(RFB) detailed below:
STEP/RFB No.: IN-DOF-503128-NC-RFB
Tender ID: 2025_DoF_883723_1
Name of Consulting Services: Hiring of a Communication Agency for the Designing and न
Implementation of a Comprehensive Communication and Outreach Strategy under PM-
MKSSY.
In order to clarify additional queries and doubts raised by prospective bidders after the due date
as decided during Pre-Bid Meeting held on 13" November, 2025, the Competent Authority has
decided to conduct another Pre-Bid Meeting. Accordingly, the Bid Submission End Date has
been revised as indicated below.
Revised Schedule
Revised Bid Submission End Date: 01° January 2026 at 02:30 PM
Additional Pre-Bid Meeting:
> Date & Time: 224 December 2025 at 11:00 AM
> Venue: Department of Fisheries, Government of India,
First Floor, Chandra Lok Building, Janpath, New Delhi — 110001
> Submission of Queries
* Queries, if any, may be submitted by email to srveeragandham@ord.gov.in on or
before 24"" December 2025 up to 11:00 AM.
« Subject Line: “Clarification — RFB for Hiring of Communication Agency — Tender
ID: 2025 DoF _883723_1”
. eries must be submitted in Excel (xls) format with columns:
7. No. | RFB Reference/Page No. | RFB Clause | Clarification Sought]
* Queries received after the stipulated time or through any other medium shall not be
entertained.
Revised Bid Opening Date :02™ January 2026 at 03:00 PM (Bidders who have submitted
their bids and wish to attend the opening of the Technical Bids in person may do so at the
designated venue, as provided under ITB Clause 26.1 of the RFB documents).
Prospective bidders are advised to regularly visit the | ¢-Proc Portal
(https://eprocure.gov.in/eprocure/app) s://eprocure.gov.in/eprocure/app) for further updates. Kh
Sask \
(r. Traun Kumar Singh)
Assistant Commissioner (Fisheries)
