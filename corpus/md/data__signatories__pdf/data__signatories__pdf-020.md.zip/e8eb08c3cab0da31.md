---
doc_id: "e8eb08c3cab0da31"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/a6cc60192a9fb5204d65a2491e3aee55.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Recruitment Rules for the post of Laboratory Assistant Grade-I and II in the Directorate of National Vector Borne Disease Control Programme"
date: "2020-11-24"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "800da98a4a3f8006"
---

<!-- page 1 -->

gov.in
abbistdi“siog1187@govin

For Office Use Only
Ministry of Health & Family Welfare
Meta Data for Documents

Name of Division:

S.no

Item
Information to be Displayed •
Document title to be
Re.c.tuihs.e..+ gule8 jor ill Pe ÷ 9 Labots&tory Ma iiriast 4displayed on website
Carside_nzata_ 77- i n +1_, /1/4",41.,--) Al
Division/Autonomous Body
(Contact E-mail-id)
Va.. cd...a.i/ a A
Language (English)
ciati4A 44.-Pf.hia.,/
Form of Document
(e.g. pdf,doc,x1s)
C___
(zip format not allowed)
Reference URL or Detailed
POE
Validity

.DL. 0

7

Name & Email-Id of Sender

8

Section of Website, where
it is to be uploaded

Programme/Reports/News & Highlights/Key Developments/Disease Alerts/Events &
Announcements/Vacancies

It is Certified that the Content have been Checked . The Content need to be following (kindly tick the appropriate option):
[ 1
1. New
2.F.Ipdate L
3. Delete [
. Signature:
Nome of Nodal Office): ent idystriath
Designation: ifmitt, Se,cre,
Email-id: bra:/51/40.11orth %Pe

*A. &

C )

Contact No: 2 3o6 )
Contents Approved by (2S/AS)
Signature:
Name:
Designation: JS/AS
Email-id:

(REKI-IAStr)

Contact No:

joint

eelllken
For Uploading on Webslte
Level 1:
Level 2:
Level 3:
Level 4:

(Signature of Web InFormatIon Manager)
Uploaded on:
Uploaded by:

Secrutary

TteTreeer
ea t 84 F.W.
/Govt. of India
tal/New Delhi
ITRUmr
0

<!-- page 2 -->

File No. 1-77/2019(Admn-I)/FTS NO . 8020927
Government of India
Ministry of Health and Family Welfare
(VBD Section)

Subject:- Public Notice on Amendment of Recruitment Rules for the post of Laboratory
Assistant Grade- I and II in the National Vector Borne Disease Control Programme (NVBDCP).
In compliance of DOP&T's O.M. No. AB.14017/16/2008-Estt. (RR) dated 13.10.2015,
the draft Notification containing Recruitment Rules etc. for the post of Laboratory Assistant
Grade- I and II in the National Vector Borne Disease Control Programme (NVBDCP) are
annexed.
2. The stakeholders interested in making any objections/comments or suggestions on the
draft Recruitment Rules may do so in writing, within a period of 30 days from the date of
publication of draft Recruitment Rules to Shri Baidyanath Prasad, Under Secretary, Ministry
of Health & Family Welfare, Room No. 753-A, Nirman Bhawan, Maulana Azad Road, New
Delhi 110011 or e-mail address. baidyanath.prasad@nic.in and sovbdhfw@gmail.com

(Baidyanath Prasad)
Under Secretary to the Govt. of India
Tel. No. 23061510
New Delhi

<!-- page 3 -->

[TO BE PUBLISHED IN GAZETTE OF INDIA, PART II, SECTION 3, SUB-SECTION(i)
GOVERNMENT OF INDIA
MINISTRY OF HEALTH AND FAMILY WELFARE
New Delhi , Dated

2020.

NOTIFICATION
G.S.R ..... In exercise of the powers conferred by the proviso to article 309 of the
constitution, and in supersession of National Malaria Eradication Programme, Delhi (GroupC posts) Recruitment Rules, 1980 in so far as they relate to the post of Laboratory
Assistant/Junior Technician except as respects things done or omitted to be done before
such supersession, the President hereby makes the following rules regulating the method of
recruitment to the posts of Laboratory Assistant Graded and II in the National Vector Borne
Disease Control Programme, (NVBDCP), under the Directorate General of Health Services,
Ministry of Health and Family Welfare, namely:-

1. Short title and commencement, -(i) These rules may be called the Ministry of Health
and Family Welfare, National Vector Borne Disease Control Programme, Laboratory
Assistant Grade( Group 'C' Post) Recruitment Rules, 2020.
(ii) They shall come into force on the date of their publication in the Official Gazette.
Number of post, classification and level in the Pay Matrix- The number of post, its
2.
classification and the level in the Pay Matrix attached thereto shall be as specified in
columns (2) to (4) of the said Schedule annexed to these rules.
Method of Recruitment, age-limit, qualification etc,- The method of recruitment, age3.
limit, qualifications and other matters shall be as specified in columns (5) to (13) of
Schedule.
4.

Disqualification: - No person,-

Who has entered into or contracted a marriage with any person having a spouse
living; or
Who, having a spouse living, has entered into or contracted a marriage with any
person,
shall be eligible for appointment to the said post:
Provided that the central Government may, if satisfied that such marriage is
permissible under the personal law applicable to such person and the other party to the
marriage and that there are other grounds for so doing, exempt any person from the
operation of this rule.
Power to relax: - Where the central Government is of the opinion that it is necessary
5.
or expedient so to do, by order, for reasons to be recorded in writing and in consultation with
the Union Public Service Commission, relax any of the provisions of these rules with respect
to any class or category of persons.
Saving: - Nothing in these rules shall affect reservations, relaxation of age-limit and
6.
other concessions required to be provided for the Scheduled Castes, the Scheduled Tribes,
Exaervicemen and other special categories of persons in accordance with the orders issued
by the Central Government from time to time In this regard.

<!-- page 4 -->

Schedu e
Name of the
Post

Number of Posts

1
Laboratory
Assistant
Gr-I

2.
34* (2020)
*Subject to variation
dependent on
workload

Classification

Level in Pay
Matrix

3.
4.
General Central Level- V of
Service, Group'C' the Pay
Non- Gazetted
Matrix
(Non-Ministerial) Rs. 2920092300.

Whether selection
post or Nonselection post.

Age limit for direct recruits

5.
Non-Selection

6.
Between 18 and 27 years of
age.

Educational and other qualifications
required for direct recruits.
7.
Essential :Graduate in Science.

(Relaxable for Government
Servants up to Forty years
in accordance with the
instructions or orders issued
by the Central Government).

Desirable :(i) One Year experience from a
Government recognized Medical/Biological
Laboratory.
(ii)Knowledge of computer.

Whether age and education
al qualifications prescribed
for direct recruits will apply
in the case of promotees.
8.
No

Period of
Method of recruitment, whethe
probation, if r by direct recruitment or by
any
deputation and percentage of
the vacancies to be filled by
various methods.

In case of recruitment by
promotion grades, from
which promotion/deputat
ion to be made.

If a Departmental promotion Committee
exists what is its composition and/or
Confirmation

9.
Two years
for direct
recruits.

11.
By promotion from
Laboratory Assistant
Gr-II in the pay level 4 of
Pay Matrix with 5 years
regular service

12.
Group 'C' Departmental Promotion
Committee (for considering promotion/and
or confirmation) consisting of

10.
50% by promotion
50% by direct recruitment.

Circumstances in
which Union Publi
c Services Commi
ssion is to be cons
ulted in making
recruitment.
13.
Not applicable.

Joint Director / Deputy Director,
Directorate of National Vector Borne
Disease Control Programme:- Chairman;
Deputy Director, Directorate General
of Health Services / any other Institution
of the Dte. Located in Delhi/New DelhiMember;
Administrative Officer, Directorate of
National Vector Borne Disease Control
Programme- Member.
File No. 1-77/2019/Admn.-I
(Baidyanath Prasad)
Under Secretary to thre Govt. of India

<!-- page 5 -->

Schedule
Name of the
Post

Number of Posts

1
Laboratory
Assistant
Gr-Il

2.
37*(2020)
*Subject to
variation dependent
on workload

Classification

Level in Pay
Matrix

3.
4.
General Central Level- IV of
Service, Group'C' the Pay
Non- Gazetted
Matrix
(Non-Ministerial) Rs.2550081100

Whether selection
post or Nonselection post.

Age limit for direct recruits

5.
Non-Selection

6.
Between 18 and 27 years of
age.
(Relaxable for Government
Servants up to Forty years in
accordance with the
instructions or orders issued
by the Central Government).

Educational and other qualifications
required for direct recruits.
7.
Essential :Graduate in Science.
Desirable :(i) One Year experience from a
Government recognized Medical/Biological
Laboratory.
(ii)Knowledqe of computer.

Whether age and education
al qualifications prescribed
for direct recruits will apply
in the case of promotees.

Period of
probation, if
any

8,
No

9.
Two years
for direct
recruits.

Method of recruitment,whether In case of recruitment by
by direct recruitment or by
promotion grades, from
which promotion/deputat
deputation and percentage of
ion to be made.
the vacancies to be filled by
various methods.
10.
50% by promotion
50% by direct recruitment.

11.
By promotion from
Insect Collectors in the
pay level 2 of Pay Matrix
with 8 years regular
service.

If a Departmental promotion Committee
exists, what is its composition or
Confirmation

12.
Group 'C' Departmental Promotion
Committee (for considering promotion/and
or confirmation) consisting of

Circumstances in
whichUnion Public
Service Commissi
on is to be consult
ed in making
recruitment.
13.
Not applicable.

Joint Director / Deputy Director,
Directorate of National Vector Borne
Disease Control Programme:- Chairman;
Deputy Director, Directorate General
of Health Services / any other Institution
of the Dte. Located in Delhi/New DelhiMember;
Hi) Administrative Officer, Directorate of
National Vector Borne Disease Control
Programme- Member.
File No. 1-77/2019/Admn.-I
(Baidyanath Prasad)
Under Secretary to the Govt. of India
