---
doc_id: "e59dfd5bd948ded2"
source_url: "https://www.dot.gov.in/static/uploads/2026/07/ecb10429f54e360c45af08ad83f970ed.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Allotment of Short code ‘1908’ to Bengaluru City Police"
date: "2017-06-29"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e9896949b40b9ec8"
---

<!-- page 1 -->

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, Ne w Delhi- I I 000 I
Dated : 29/06/20 17

No . 16-3/2009-AS.lll (Part)/112 / ";:/-\°t
To.
All Access Service Providers.
CORRIGENDUM
Subject :- Allocation of Short Code for Drug Menace regarding.

The undersigned is directed to convey that as a pa11ial modification of DoT letter of even
number dated 19/05 /2 017 (copy enclosed). the Short Code '155260' allocated to Bengaluru
City Police for its Call Centre regarding drug Menace in Bengaluru may now be read as
'1908'. The other features shall remain same as earlier.
2. This is issued with the approval of Sr. DOG (AS).
3. All are requested to take necessary action.
Copy Enclosed: as above

E-Mail: sanchitk.garg(ii),gov.in

Copy forwarded for informati on and necessary action to. if any. to :
I.
Secretary. TRAI.
2.
Additional Chief Secretary. Home Department. Karnataka Govt. vv.r.t yo ur D.O letter dated
HD 45 PND 2017 dated 22-06-2017.
3.
CMD MTNL /CMD BSNL.
4.
Commi ssioner of" Police. lnlantry Road. lkn ga luru-5(1000 I with reference to yo ur letter no.
CB I AddlCP /Crime/CC/42/2017 dated I 5i05 12017 to appoint a noda l officer to impl ement
th e helpline . The Nodal officer may contact DOG (TERM). TERM Ce ll. Bengaluru).
5.
Director (TERM-I), DoT (HQ) (TERM Ce ll-Bangal ore be asked to co-ordinate with
respective Nodal Officers and TSPs for implementation of Helpline, as and when
approached).
6.
A copy for upload on DoT Website .

<!-- page 2 -->

Government of India
Ministry of Communications
Department of Telecommunications
Access Services Wing
20, Ashoka Road, New Delhi-110001
No. 16-3/2009-AS.III/Part /109 b88.

Dated : 19/05/2017

To,
All Access Service Providers.
Subject :- Subject: Allocation of Short Code 155260 for Drug Menace regarding.
The undersigned is directed to convey the allocation of Short Code '155260' to
Bengaluru City Police for its Call Centre regarding drug Menace in Bangaluru with following
features as under:
(i) Category-I: Service (i.e. mandatory service to be provided by all the Access
providers.
(ii) Accessibility: Un-restricted i.e. available on STD also.
(iii) Metered service: (It may be taken as Called Party Pays or Calling Party Pays
depending on intimation, to this effect, issued by the agency to which this short code is
· allocated in furtherance to this DoT instruction).
2. :

All are requested to take necessary action.

3.

This is issued with the approval of Sr. DOG (AS).

E-Mail: sanchitk.garg<(iJ.!!OY.in
Copy forwarded for information and necessary action to, if any, to:

1.
2.
3.

Sec!'etary, TRAI.
~·
.
CMD MTNL /CMD BSNL.
~O/<t
:Comrnissioner of Police. Infantry Road. Bengaluru-56000 I with reference to
·• ;
your letter no. ~B. I Add!CP /C rime/CC/42/2017
dated 15/05/2017 to appoint a
nodal officer "to implement the helpline.(The Nopal officer may contact DOG
(TERM), TERM Cell, Bengaluru).

4.

Director (TERM-1), DoT (HQ) (TERM Cell-Bangalore be asked to co-ordinate
with respective Nodal Officers and TSPs for implemen.tation of Helpline, as and
when approached).
A copy for upload on DoT Website .

5.

~

/

:··4;.:
·::· y~} .

o/{,,
