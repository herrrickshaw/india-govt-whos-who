---
doc_id: "e5d22b7cff33dba7"
source_url: "https://doj.gov.in/static/uploads/2025/09/3299d16da33628b79c3419f06482bea3.pdf"
ministry: "Department of Justice (DoJ)"
title: "Order of appointment of Shri Ajay Digpaul and one other as Judges of the Delhi High Court (06.01.2025)"
date: "2025-01-06"
pages: 2
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "7a554e75e5d4efa0"
---

<!-- page 1 -->

(TO BE PUBLISHED IN THE GAZETTE OF INDIA, PART 1 SECTION 2)
F. No. K-13017/03/2023-US.1
Government of India
Ministry of Law & Justice
Department of Justice
(Appointments Division)
Jaisalmer House, 26, Man Singh Road,
New Delhi-110 011.
Dated 06" January, 2025.
NOTIFICATION
In exercise of the power conferred by clause (1) of Article 217 of the
Constitution of India, the President is pleased to appoint S/Shri (i) Ajay Digpaul
and (ii) Harish Vaidyanathan Shankar to be Judges of the Delhi High Court, in
that order of seniority, with effect from the date they assume charge of their
| respective offices.
1 oat 25
(7; agannatll {4d vesan)
Joint Secretary to the Government of India
Tele: 2338 3037
To
The Manager,
Government of India Press,
Minto Road,
New Delhi.

<!-- page 2 -->

-2-
F. No. K-13017/03/2023-US.1 Dated: 06.01.2025.
Copy to:-
1. S/Shri (i) Ajay Digpaul and (ii) Harish Vaidyanathan Shankar, Advocates
: through the Registrar General, Delhi High Court, New Delhi.

2. The Secretary to Lt. Governor, NCT of Delhi, Delhi.

3. The Secretary to Chief Minister, NCT of Delhi, Delhi.

4, The Secretary to the Chief Justice, Delhi High Court, New Delhi.

5. The Chief Secretary, Government of NCT of Delhi, New Delhi.

6. The Registrar General, Delhi High Court, Delhi.

| 7. The President's Secretariat, (CA.II Section), Rashtrapati Bhawan, New
Delhi.

8. PS to the Principal Secretary to the Prime Minister, PM's Office, South
Block, New Delhi.

9. Registrar (Conf.), o/o the Chief Justice of India, 07, Krishna Menon Marg,
New Delhi.

10. PS to the MoS (I/C) L&J/ PPS to the Secretary (Justice).

11. Sr. Technical Director, NIC, Department of Justice, with a request to
upload the notification on the website of the Department
(www.doj.gov.in)

eS
rosin
¢ (Anant Kumar)
Under Secretary to the Govt. of India
Tele: 23383087
