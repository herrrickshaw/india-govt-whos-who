---
doc_id: "e9abe8478a9adc0c"
source_url: "https://www.dot.gov.in/static/uploads/2026/05/6a1fe20e3945acf0504ea261c176afc8.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 807 of 2025 in the Hon’ble High Court of Delhi: DoT instructions dated 22.05.2026 to ISPs"
date: "2026-05-22"
pages: 32
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d0a5df33519adef9"
---

<!-- page 1 -->

4-10/2025-DGT/4(Part-II)

I/3400735/2026

By Email/ DoT Website
File No.: 4-10/2025-DGT/4(Part-II)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
2nd Floor, UIDAI HQ, New Delhi -110001
Date: -05-2026
To
All Licensees with Internet Service Authorization
Subject: CS (COMM) 807/2025: SPORTA TECHNOLOGIES PVT. LTD. versus JOHN
DOE AND ORS in the Hon’ble High Court of Delhi.
Please find enclosed the Hon’ble High Court of Delhi order dated 08.08.2025 in the
captioned case.
2.
Please refer to para 30(c) of the said Court order along with the list received from the
counsel for plaintiff regarding blocking access to the website(s)/domain(s) [04 numbers] as
listed in the enclosed list.
3.
In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action in respect of blocking access to the said
website(s)/domain(s), as per the enclosed list, in compliance with the said court orders.

Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Sh. Ritwik Marwaha (Ritwik@fiduslawchambers.com), Plaintiff’s CounselFor kind information and with a request to take action as per the enclosed Annexure
pl.

<!-- page 2 -->

4-10/2025-DGT/4(Part-II)

C.S. (COMM.) 807 of 2025 - Sporta Technologies Pvt. Ltd. v. John Doe and Ors.
Ser. No.
Websites/URLs
fankode.pages.dev
1
faancode.pages.dev
2
cmvxfancode.pages.dev
3
footsters.netlify.app
4

I/3400735/2026

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

C.S. (COMM.) 807 of 2025 - Sporta Technologies Pvt. Ltd. v. John Doe and Ors.
Ser. No.
Websites/URLs
1
fankode.pages.dev
2
cricinsider1.pages.dev/Fancodee
3
run-machine.pages.dev/fancode
4
crictos99.pages.dev/fc
5
criccoder264.pages.dev/Fancode
6
faancode.pages.dev
7
cmvxfancode.pages.dev
8
footsters.netlify.app

<!-- page 14 -->

$~39
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 807/2025 & I.As. 19316-20/2025
SPORTA TECHNOLOGIES PVT. LTD.
.....Plaintiff
Through: Mr. Prithvi Singh, Mr. Rohan Krishna
Seth and Mr. Ritwik Marwaha,
Advocates
versus
JOHN DOE AND ORS
Through:

.....Defendants
Mr. Ankur Mittal, CGSC with Mr.
Aviraj Pandey, Advocate for D-25 &
D-26

CORAM:
HON'BLE MS. JUSTICE MANMEET PRITAM SINGH ARORA
ORDER
%
08.08.2025
I.A. 19320/2025 (Application for exemption from filing original, redacted
copies and clear copies)
1.

The present application has been filed by the Plaintiff seeking

exemption from filing the original, redacted copies and clear copies of
documents.
The Plaintiff seeks two (2) weeks to file original, redacted copies and
clear copies of the documents enlisted therein.
2.

Original documents shall be produced/filed at the time of

Admission/Denial, if sought, strictly as per the provisions of the
Commercial Courts Act, 2015 and the Delhi High Court (Original Side)
Rules, 2018.
3.

The Plaintiff is directed to file the redacted and clear copies of the

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 1 of 18

<!-- page 15 -->

documents within two (2) weeks.
4.

Accordingly, the application stands disposed of.

I.A. 19319/2025 (Application under Order XI Rule 1(4) CPC seeking leave
to file additional documents)
5.

This is an application seeking leave to file additional documents under

Order XI Rule 1(4) of the Code of Civil Procedure, 1908 (‘CPC’) [as
amended by the Commercial Courts, Commercial Division and Commercial
Appellate Division of High Courts Act, 2015 (‘Commercial Courts Act’)],
within 30 days.
6.

The Plaintiff, if it wishes to file additional documents will file the

same within 30 days from today, and it shall do so strictly as per the
provisions of the Commercial Courts Act and the Delhi High Court
(Original Side) Rules, 2018 (‘DHC Rules’).
7.

For the reasons stated in the application, the same is allowed.

8.

Accordingly, the application is disposed of.

I.A. 19318/2025 (Application for seeking exemption from advance service
to the Defendants)
9.

In view of the fact that the Plaintiff has sought an ex-parte ad-interim

injunction, the exemption from effecting advance service upon the
Defendants in granted.
10.

Accordingly, the application stands disposed of.

I.A. 19317/2025 (Application seeking exemption from pre-institution
mediation)
11.

Having regard to the facts of the present case and in light of the

judgement of Supreme Court in Yamini Manohar v. T.K.D. Keerthi1,
1

2023 SCC OnLine SC 1382.

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 2 of 18

<!-- page 16 -->

exemption from attempting pre-institution mediation is granted.
12.

Accordingly, the application stands disposed of.

CS(COMM) 807/2025
13.

Let the plaint be registered as a suit.

14.

Issue summons. Mr. Ankur Mittal, learned counsel on behalf of the

Defendant Nos. 25 and 26 accepts summons. He confirms the receipt of the
suit paper-book and waives the right of formal service of summons.
No direction is being issued to the Defendant Nos. 25 and 26 to file
written statement at this stage.
15.

Summons be issued to Defendant Nos. 1 to 8, 10 to 24 through e-mail.

Affidavit of service(s) be filed within two (2) weeks.
16.

The summons shall indicate that the written statement(s) must be filed

within thirty (30) days from the date of receipt of the summons. The
Defendant(s) shall also file affidavits of admission/denial of the documents
filed by the Plaintiff, failing which the written statement(s) shall not be
taken on record.
17.

The Plaintiff is at liberty to file replication(s) thereto within thirty (30)

days after filing of the written statement(s). The replication(s) shall be
accompanied by affidavits of admission/denial in respect of the documents
filed by the Defendant(s), failing which the replication(s) shall not be taken
on record.
18.

It is made clear that any unjustified denial of documents may lead to

an order of costs against the concerned party.
19.

Any party seeking inspection of documents may do so in accordance

with the Delhi High Court (Original Side) Rules, 2018.
20.

List before the learned Joint Registrar (J) for completion of service

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 3 of 18

<!-- page 17 -->

and pleadings on 17.09.2025.
21.

List before the Court on 19.01.2026.

I.A. 19316/2025 (Application under Order XXXIX Rule 1 and 2 CPC)
22.

The present application has been filed under Order XXXIX Rules 1

and 2 of the CPC seeking an interim injunction against the Defendants.
23.

The underlying suit has been filed seeking permanent injunction

restraining the Defendants from infringement of exclusive broadcast
reproduction rights of the Plaintiff, which it has acquired through various
exclusive agreements entered into with the third parties.
24.

Learned counsel for the Plaintiff states that the Plaintiff is the

proprietor of multi-sports aggregator platform called ‘FanCode’ which was
founded by the Plaintiff in 2019. He states that under the said platform i.e.,
‘FanCode’, the Plaintiff offers content, merchandise and community
engagement. He states that more specifically the Plaintiff streams live
matches, offers sports content, live match scores etc.
24.1. He states that streaming of live sporting event on ‘FanCode’ is done
on the basis of licensing arrangement entered into between the Plaintiff and
various sporting bodies, agencies and TV channels.
24.2. He states that the Plaintiff’s ‘FanCode’ platform has reached over 100
million users.
24.3. He states that the Plaintiff is also a registrant of domain i.e.,
‘fancode.com’, which was registered in the name of the Plaintiff on
22.12.2012.
24.4. He states that Plaintiff has executed various agreements with the third
parties to secure exclusive broadcasting rights for the territory of India. He
states that in some of the agreements, Plaintiff has exclusive rights for the

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 4 of 18

<!-- page 18 -->

entire world. He states that the subject matter of the present suit are
agreements, which are listed at paragraph ‘8’ of the plaint and read as under:
(i)

Agreement with Formula One World Championship Ltd. The date of

the event to be streamed under this agreement is from August to December,
2025. (‘F1 Agreement’).
(ii)

Agreement with Cricket West Indies, Inc. The date of the event to be

streamed under this agreement is from July, 2025 to August, 2025. (‘CW1
Agreement’).
(iii)

Agreement with Union Des Associations Européennes De Football.

(‘UEFA Women’s Agreement’).
(iv)

Agreement with MLB Advanced Media, L.P. The date of the event to

be streamed under this agreement is from September, 2025 (the ‘MLB
Agreement’)
(v)

Agreement with PGA TOUR Enterprises, LLC. The date of the event

to be streamed under this agreement is from July to December, 2025 (the ‘PGA
Agreement’)
(vi)

Agreement with EMPA GmbH. The date of the event to be streamed

under this agreement is from April, 2025 to October, 2025 (the ‘DTM
Agreement’)
(vii)

Agreement with HBA Media Ltd. (the ‘HBA Agreement’)

(viii)

Agreement with Pitch International LLP and The Football League

Limited. The date of the event to be streamed under this agreement is from
August, 2025 till May, 2026 (the ‘EFL Agreement’)
(ix)

Agreement with T Ten Sports Management FZC. The date of the

event to be streamed under this agreement is from September, 2025 till
December, 2025 (the ‘TSM Agreement’)
(x)

Agreement

with

Asian

Football

Confederation.

(the

‘AFC

Agreement’)
(xi)

Agreement with Commune Marketing and Events Private Limited for

exclusive broadcasting rights over the matches organized under the Nature Isle

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 5 of 18

<!-- page 19 -->

T10 League. The date of the event to be streamed under this agreement is from
December, 2025 (the ‘Nature Isle T10 League Agreement’)
(xii)

Agreement with Commune Marketing and Events Private Limited for

exclusive broadcasting rights over the matches organized under the Spice Isle
T10 League. (the ‘Spice Isle T10 League Agreement’)
(xiii)

Agreement with Commune Marketing and Events Private Limited for

exclusive broadcasting rights over the matches organized under the Jamaica
T10 League (the ‘Jamaica T10 League Agreement’)
(xiv)

Agreement with Commune Marketing and Events Private Limited for

exclusive broadcasting rights over the matches organized under the St Lucia
T10 League (the ‘St. Lucia League Agreement’)
(xv)

Agreement with Commune Marketing and Events Private Limited for

exclusive broadcasting rights over the matches organized under the Vincy
Premier League (the ‘Vincy Premier League Agreement’)
(xvi)

Agreement with Commune Marketing and Events Private Limited

exclusive broadcasting rights over the matches organized under the Trinidad
T10 League (the ‘Trinidad T10 League Agreement’)
(xvii)

Agreement with Cricket Victoria. The date of the event to be streamed

under this agreement is from 2025 till 2028 (the ‘CV Agreement’)
(xviii)

Agreement with Grup Mediapro S.L.U. (the ‘Venezuela Agreement’)

(xix)

Agreement with Dorna Sports S.L. The date of the event to be

streamed under this agreement is from 2025 till 2027 (the ‘MotoGP
Agreement’)
(xx)

Agreement with Hockey India. The date of the event to be streamed

under this agreement is from 2023 to 2026 (the ‘Hockey India Agreement’)
(xxi)

Agreement with Marron Media Group Pty Ltd. (the ‘Marron

Agreement’)
(xxii)

Agreement with Absolute Legends Sports Private Ltd. The date of the

event to be streamed under this agreement is from 2023 to 2027 (the ‘ALS
Agreement’)

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 6 of 18

<!-- page 20 -->

(xxiii)

Agreement with Elev8 India Sportz Private Limited. The date of the

event to be streamed under this agreement is from 2022 till 2032. (the ‘Elev8
Agreement’)
(xxiv)

Agreement with Cricket Boland NPC. The date of the event to be

streamed under this agreement is from 2024 till 2026. (the ‘Boland
Agreement’)
(xxv)

Agreement with Innovative Production Group FZ LLC (the ‘IPG

Agreement’)
(xxvi)

Agreement

with

European

Cricket

League

AG

(the

‘ECL

Agreement’)
(xxvii) Agreement with the Afghanistan Cricket Board (the ‘ACB
Agreement’)
(xxviii) Letter issued by Commune Marketing and Events Private Limited.
The date of the event to be streamed under this agreement is from 01.02.2023
till 31.12.2025. (the ‘Commune Letter’)
(xxix)

Letter issued by Liga Nacional de Futbol Profesional (the ‘LaLiga

Letter’)
(xxx)

Agreement with The Tamil Nadu Cricket Association. The date of the

event to be streamed under this agreement is from 01.04.2023 till 31.03.2026.
(the ‘TNCA Agreement’)
(xxxi)

Agreement with TCM Sports Management Private Limited. The date

of the event to be streamed under this agreement is from 10.05.2025 till
09.05.2026 (the ‘KCA Agreement’)

24.5. He states that no entity other than the Plaintiff is authorized to
broadcast, re-transmit, host, stream, make available for viewing and
download, provide access to or communicate to the public, the broadcast/
livestream of any of the events forming part of the aforesaid agreements ‘in
India’ without explicit approval from the Plaintiff.
24.6. He states that Defendants No. 1 to 8 are rogue websites and identity of

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 7 of 18

<!-- page 21 -->

Defendant No. 9 is not known (John Doe), which have, on multiple
occasions and in the recent past, infringed the broadcast rights of the
Plaintiff by illegally hosting, streaming, broadcasting, making available for
viewing and providing access to pirated content on their respective
website/mobile application to users in India. He states that these websites
are accessible without using VPN.
24.7. He states that viewership of sports related content is at its peak at the
time of ‘live telecast’ of the said sporting events, and any piracy and/or
infringement during such times through any mode or platform, significantly
impacts the revenues, which could be either via subscription fees or by way
of advertisements to the Plaintiff. He states that, therefore, it is essential that
the Plaintiff’s broadcast reproduction rights conferred by virtue of Section
37 of the Copyright Act, 1957, be protected against infringement and
commercial misappropriation by Defendant Nos. 1 to 8 and 9 (John Doe).
24.8. He states that with respect to the trademarks ‘FANCODE’ the
Plaintiff has acquired various trademark registration which is given below:

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 8 of 18

<!-- page 22 -->

24.9. He states that Defendant Nos. 1 to 8 operate impugned websites
through which they illegally livestream/broadcast various events for which
exclusive broadcasting rights vests with the Plaintiff. He states that the
footage streams on these websites contain the ‘FanCode’ watermark and
originate from the Plaintiff’s website. He states that the said websites of the
said Defendants run contents, which contains the trademark of the Plaintiff,
and thus, it amounts to infringement of trademarks of the Plaintiff and
passing off. He states that Defendant Nos. 6 and 8 are engaged in
unauthorised distribution of Plaintiff’s exclusive broadcast content. He states
that Defendant Nos. 1, 2, 3, 4, 5 and 7 additionally use the logos and marks
of the Plaintiff. He states that the infringement and passing off by the said
websites of the Defendant Nos. 1 to 8 are set out in paragraph ‘15’ of the
plaint and are extracted as under:

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 9 of 18

<!-- page 23 -->

Defen Website
Screenshot
dant
Content
No.
1.
www.fancode.dev

2.

of

Defendant’s

website

with

Skfclive.pages.de
v

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 10 of 18

<!-- page 24 -->

3.

Criccoder.pages.d
ev

4.

Insiderlive1.pages
.dev

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 11 of 18

<!-- page 25 -->

5.

tv.durbinlive.com

6.

Sportsevo.zetaspo
rts.in

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 12 of 18

<!-- page 26 -->

7.

Fancode.cricketnation.live

8.

Sportifyprimefc.
web.app

24.10. He states that the Defendant Nos. 1 to 8 are habitual infringers and
Plaintiff apprehends that in light of the past conduct and current operations
of Defendant Nos. 1 to 8, their illegal activities are likely to continue even
after the passing of any injunction order against it and therefore, Plaintiff
seeks a dynamic injunction to cover all future websites/URLs/mobile
application that may pop-up eventually to mimic their modus operandi, thus
infringing the Plaintiff’s broadcast rights granted to it vide the various
agreements mentioned at para 24.4.
25.

This Court has heard the learned counsel for the Plaintiff and perused

the record.
26.

A perusal of the plaint along with the documents annexed therewith

shows that Plaintiff has exclusive rights in respect of the content acquired

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 13 of 18

<!-- page 27 -->

through broadcasting rights vide various agreements mentioned hereinabove
at para 24.4. It is stated that a large number of live sports events are
scheduled to be held during the currency of the aforesaid agreements and an
ex parte ad interim injunction is prayed to be granted in order to ensure that
the investment made by the Plaintiff in acquiring broadcasting rights to these
events is not jeopardized in any manner. In addition, it is stated that the
Plaintiff is the proprietor of the registered trademarks referred to in para 24.8
of this order.
27.

It is stated that Defendant Nos. 1 to 8 are rogue websites and mobile

applications which are illegally broadcasting the content on their interface
and also infringing the trademarks of the Plaintiff. It is stated that Defendant
No. 2 is a mobile application. The screenshots of the website/URLs of the
Defendant Nos. 1 to 8 are given in the plaint and also extracted hereinabove
at para 24.9 show that the said Defendants are indulging in unauthorized
broadcast of the Plaintiff’s content and unauthorizedly using the Plaintiff’s
marks. Defendant No. 9 is a John Doe party whose name is yet to be
identified. It is stated that as the live events progress, there is a possibility of
more rogue websites and applications streaming infringing content coming
up.
28.

Upon examination of the screenshots of the websites operated by

Defendant Nos. 1, 2, 3, 4, 5, and 7, it is evident that these websites display
the Plaintiff’s marks/logo, thereby infringing the Plaintiff’s registered
trademarks and constituting an act of passing off as well.
29.

In the overall conspectus, Plaintiff has made out a prima facie case for

grant of an injunction against the rogue websites and mobile applications
i.e., Defendant Nos. 1 to 8. This Court is satisfied that if the interim

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 14 of 18

<!-- page 28 -->

injunction is not granted at this stage, irreparable injury would be caused to
the Plaintiff. Balance of convenience also lies in the favour of the Plaintiff.
Accordingly, the following directions are issued:
(i)

Defendant Nos. 1 to 8, their proprietor, partners, officers,

servants, employees, and all others acting for and on their behalf are
restrained from making available to the public, any content which
results in infringement of the Plaintiff’s broadcast reproduction rights
in the ongoing ‘F1 Agreement’, the ‘MLB Agreement’, the ‘PGA
Agreement’, as also those rights acquired from the agreements
mentioned at para 24.4 of this order, on their website/mobile
applications or in any other manner;
(ii)

Defendant Nos. 1, 2, 3, 4, 5 and 7, their proprietor, partners,

officers, servants, employees, and all others acting for and on their
behalf are restrained from using the Plaintiff’s trademarks mentioned at
para 24.8 of this order, in any manner which amounts to infringement
and/or passing off.
(iii)

Defendant Nos. 10 to 15 are directed to suspend and lock the

domains i.e., fancode.dev, durbinlive.com, zetasports.in and cricketnation.live. Further, they are directed to suspend and lock sub-domains
i.e., skfclive.pages.dev, criccoder.pages.dev, insiderlive1.pages.dev,
insiderlive1.free.nf and sportifyprimefc.web.app.
(iv)

Defendant Nos. 10 to 15 shall reveal the names of all the

registrants of the websites mentioned in para 24.9 of this order as also
any other information including their mobile numbers, subscription
information, bank account, credit card or any other details which they
may have.

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 15 of 18

<!-- page 29 -->

(v)

Defendant Nos. 25 and 26 are directed to issue blocking orders

within 36 hours after the service of this order against the websites
and/or mobile applications mentioned at para 24.9 of this order.
Pursuant thereto, Defendant Nos. 16 to 24 are directed to block access
to the websites and/or mobile applications mentioned at para 24.9 of
this order within 36 hours.
30.

In respect of prayer clause at para 2(g) of the captioned application

wherein dynamic injunction is being prayed for, considering that the subject
matter of the Plaintiff’s agreement are live sporting events, this Court is of
the opinion that to keep pace with dynamic nature of the infringement it is
appropriate that a dynamic injunction is also issued to protect the intellectual
property rights of the Plaintiff. Therefore, during the currency of the
agreements as mentioned in para 24.4, if the Plaintiff discovers that other
mirror websites or rogue websites, are streaming footage of live sporting
events covered by the said agreements, the Plaintiff is given liberty till the
next date of hearing:
(a) To communicate the details of the said websites and/or applications to
both DoT and MeitY for issuance of blocking orders and
simultaneously to the ISPs for blocking the said websites so as to
ensure that these websites can be blocked on a real time basis and
there is no considerable delay.
(b) Upon receiving such communication from the Plaintiff, the
DNRs/ISPs shall take steps to immediately (within 24 hours) to block
the rogue websites and/or rogue applications in question.
(c) The DoT and MeitY shall also issue blocking orders immediately
(within 24 hours) upon the Plaintiff communicating details of the

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 16 of 18

<!-- page 30 -->

websites and/or applications, which are streaming the live sporting
events.
(d) After communicating the details of the rogue websites and/or
applications to DNRs/ISPs, DoT and MeitY, Plaintiff shall continue
to file affidavits along with evidence of infringement, with the Court
in order to ensure that the Court is fully informed of the said websites,
in respect of which blocking orders are sought by the Plaintiff. The
affidavits shall be filed within 48 hours of issuing the communication.
30.1. If any website and/or applications, which is not primarily an
infringing website and/or applications is blocked in pursuance of the present
order, it is permitted to approach this Court by giving an undertaking that it
does not intend to do any illegal dissemination of the exclusive broadcast
content of the Plaintiff and thereafter, the Court would consider modifying
the injunction accordingly.
30.2. Such a relief is called for in the present matter, especially in view of
the fact that majority of the subject matter content is live sporting event.
Any delay in blocking the rogue website and/or applications would in fact,
result in considerable pecuniary loss to the Plaintiff and result in irreparable
violation of the Broadcast reproduction rights of the Plaintiff.
31.

Compliance of Order XXXIX Rule 3 CPC be done within three (3)

weeks. Compliance and service is permitted through e-mail.
32.

Issue Notice. In the peculiar facts of this case, service is permitted

through e-mail to Defendant Nos. 1 to 8. Notice to Defendant No. 10 to 26
be issued through all modes.
33.

Reply to the application be filed within four (4) weeks from the

service of the present order along with the paper book. Rejoinder thereto if

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 17 of 18

<!-- page 31 -->

any be filed within three (3) weeks thereafter.
34.

List before the learned Joint Registrar (J) for completion of service

and pleadings on 17.09.2025.
35.

List before the Court on 19.01.2026.

36.

The digitally signed copy of this order, duly uploaded on the official

website of the Delhi High Court, www.delhihighcourt.nic.in, shall be treated
as the certified copy of the order for the purpose of ensuring compliance. No
physical copy of orders shall be insisted by any authority/entity or litigant.

MANMEET PRITAM SINGH ARORA, J
AUGUST 8, 2025/rhc/SK

CS(COMM) 807/2025
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 13/08/2025 at 17:07:12

Page 18 of 18

<!-- page 32 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
