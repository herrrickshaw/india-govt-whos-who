---
doc_id: "e6a1c8e6bbfda678"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/db9c4123260dc41d921edde1f122a576.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Draft of amendment of Recruitment Rules for the post of Senior Sanitary Inspector,Group 'C' post in Rural Health Training Centre, Najafgarh ,New Delhi"
date: "2018-08-07"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5bc5a903c69c5308"
---

<!-- page 1 -->

A

Government of India
Ministry of Health and Family Welfare
(Hospital II Section)

Subject;- Public Notice on Amendment of Recruitment Rules for the post of Senior
Sanitary Inspector, Group 'C', Rural Health Training Institute, Najafgarh-reg;.

In compliance of DOP&T's O.M. No. AEl.l4017/61/2O08-Estt(RR) dated
13.10.2015, the draft Recruitment Rules for the post of Senior Sanitary Inspector,
Group 'C', Rural Health Training Institute, Najafgarh a.re annexed.

2.

The sta-keholders interested in making any objections/comments or suggestions
on the &aft Recruitment Rules may do so in writing within a period of 3O days from
the date of publication of draft Recruitment Rules to Shri Manoj Kumar Singh, Under
Secretary, Ministry of Health & Family Welfare, Room No. 501-D, Nirman Bhawal,
Maulana Azad Road, New Delhi-110008 or email address mk.singh52@,nic.in

, (Maloj Kumar Singh)
Under Secretary to the Gow. of India
Tele no.- 23061521
New Delhi,
May 2018

Government of India

<!-- page 2 -->

ITO BE PUBLISHED IN THE GMETTE OF INDIA, PART II, SECTION 3, SUB.SECTION] (D]
Government of lndia
Ministry of Health and Family Welfare
NOTIFICATION
New Delhi, the ................2018.

R ..-

G'S
ln exercise of the powers confened by the proviso to article 309 of
the Constitution, and in
supersession ofthe Rural Health Training Centre, Najafgarh, New Delhi,
Senio, sanitary tnspecior, necruitrent
Rules,.1989, in so far as they relate to the post of Seni-or sanitary
lnspector, except ai
ing, oon. o,
omitted to be done before such supersession, the President nereuy
mares fl,r. riro*ing fu., iegutating the
method of recruitment to the post of senior Sanitary Inspector, in
palatgarn,
thL Rural H..rft

*ril.iit

iirini"ng C.ntre,

New Delhi, namely:-.

l

Short title and commencemenl, (1) These rules may be
called the Ministry of Health and Famity welfare,
.
Rural Health Training cenhe, Najafgarh, New Derhi, Senior

Sanitary rnrp..toile.upli; iosi1'necruitment

Rules,2018.
(2)They shall come into force on the date of their publication

in the official Gazette.

2. Number of post, classification, level in the pay matrix or pay scale,- The number of the
said post, its
classificalion and the level in the.pay matrix or pay scale attached
thereto snarr oe as rp#.-j in .otrrn,
(2) to (4) of the Schedule
annexed to these rules.

3 Method of recruitment, age-limit, qualification, etc. - The method of recruitment ageJimit, qualification and
other matters relating to the said post shall be as specilied

4. Disqualiflcation.- No person,

-

(a) who has entered into or contracted a marriage
(b) Who, having a spouse living, has entered int6

shall be eligible for appointment to the said post:

in columns (5) to (i 3) ot i'r1.

,rij s'.r,.0rr..

wfth a person having a spouse riving, or

or contracted a maniage with.ny p#on,

Provided that the Central Government may, if satisfied that

personal law applicable to such person and

such maniage is permissible under the

the other party to the marriage and tiat there are other grounds
for so doing, exempt any person from the operation
of inis iule.

5' Power to relax. - Where the Cenlral Government is of the opinion that it is necessary or expedient so
it may, by order, for reasons to be recorded in writing

to any class or category of persons.

to do,

relax any of the prorisions oi tir".e i,!.r'*im ,.rp..t

6 Saving .- Nothing in these rules shall affect reservations, relaxation of age-limit and other concessions
required to be provided for the Scheduled Castes, the scheduled

Ex'servicemer and other special

Tribes, thJ otner aacr<waio ctasses, the
persons in accordance wiih the o;d;;;;uei ly'tne
of
.categories
centrat

Government from time to time in this regard.

<!-- page 3 -->

SCHEDULE

(

Name of tfie

Number of posts.

post.
(1)

Classification.

(2)

Senior Sarutary

(3)

z'(2018)

*subject

lnspector.

General

to variation

dependent on
workload.

Non- Ministerial,

Whetherffi

Not applicable.

A)

-ientral

Service, Group,C,,
Non-Gazetted,

qualifications prescribed for
direct
recruits will apply in the case
of

Level in the pay
matrix or pay scale.

Period of proUatroU if

t_evet-5 (Rs.29200_

92300) in the pay

Whether seGction post I Age
limit for direct
or non-selection post,
recruits.

for direct recruits.

(5)

Not applicable.

EducationaT and other

qualifications required

(6)

(7)

ruot applicable.

Not applicable.

--

matrix.

Method

promotion or Oy oeputaiionl
:.^.^ig1t_or,by
and percentage of tnJ posis jo'oe
Sbsorption
ureo oy various methods

ln case o

deputation/ absorption grade 'from
which
promotion or deputation
/absorption to n.

made.

Two years,
Promotion fr
of regular service in thqlevei

+ oitn. pr1l'""'

tf a Oepart

Circumstancei-

L Group C
1, Director, RuralHealth
Centre,
2, Administrative Officer, lraining
Ruratiealth
3, Gazetted

in which Union

Commission is to be consulted

officer

Najafgarh

Public Sorvices
recruitment.

_ Chairman

.'-'"""v Centre,
ilning
vv",,v, ,rqJqr,crrr
Najafgarh _ Member,

_ Member.

ll' Departmentar confirmation committee (for
1. Director, Rural Health Training

in mal

considering confirmation) consisting:_

Najafgarh
_ Chairman
Najafgarh _ Member

Centre,
2' Administrative officer, Rurat i'earth
-. rrliriig
"-"""v centre,
vvrrrrw' rroJqrYdrrr
3' Gazetted Officer

- Member.

lNo,A. 1 20t Alt qtZO t S-tr,tH,Ut

,

Under S:cretary to m,

\^^,!!f

cor.r,i##ri;ffill
