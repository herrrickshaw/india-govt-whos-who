---
doc_id: "e6a0ca9d9ab6ac31"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/11/a96427f000a233c80530d3d6a9600803.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "CHS (Amendment) Rules 2025"
date: "2015-03-03"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2a7e5575ed80909e"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-28082025-265781
xxxGIDHxxx
CG-DL-E-28082025-265781
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 541]

नई दिल्ली, बृहस्ट्पजतवार, अगस्ट्त 28, 2025/भाद्र 6, 1947
NEW DELHI, THURSDAY, AUGUST 28, 2025/BHADRA 6, 1947

No. 541]

स्ट्वास्ट््य और पररवार कल्याण मंत्रालय
(स्ट्वास्ट््य और पररवार कल्याण जवभाग)
अजधसूचना
नई दिल्ली, 25 अगस्ट्त, 2025
सा.का.जन. 585(अ).— राष्ट्रपति संतिधान के अनुच्छेद 309 के परंिुक द्वारा प्रदत्त शतियों का प्रयोग करिे हुए
एिद्द्वारा कें द्रीय स्िास््य सेिा तनयम, 2014 में और संशोधन करने हेिु तनम्नतितिि तनयम बनािे हैं, अर्ााि:् 1. (1) इन तनयमों का संतिप्त नाम कें द्रीय स्िास््य सेिा (संशोधन) तनयम, 2025 है।
(2) ये राजपत्र में उनके प्रकाशन की िारीि से प्रिृत्त होंगे।
2. कें द्रीय स्िास््य सेिा तनयम, 2014 में, (i) अनुसूची 2 में, क्रम संख्या 4 के सामने, शीर्ाक “(I) तशिक तिशेर्ज्ञ उप कै डर (सहायक प्रोफे सर या सहबद्ध
प्रोफे सर या प्रोफे सर)” के अधीन, क्रम संख्या 1 के सामने, शीर्ाक "(ि) िधामान महािीर आयुर्िाज्ञान महातिद्यािय

5735 GI/2025

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

और सफ़दरज़ंग अस्पिाि, नई ददल्िी" के अधीन, क्रम संख्या 17 और उससे संबंतधि प्रतितियों के पश्चाि्,
तनम्नतितिि को अंिःस्र्ातपि दकया जाएगा, अर्ााि:् क्रम संख्या

पदनाम या तिशेर्ज्ञिा

पदों की संख्या

“18.

पीडीयाट्रिक न्यूरोिॉजी

01

19.

पीडीयाट्रिक ऑन्कोिॉजी

01”;

(ii) अनुसूची-6 में, क्रम संख्या 59क और उससे संबंतधि प्रतितियों के पश्चाि् तनम्नतितिि को अंिःस्र्ातपि दकया
जाएगा, अर्ााि:् क्रम संख्या

तिर्य

अपेतिि स्नािकोत्तर तडग्री अहािा

अपेतिि स्नािकोत्तर तडप्िोमा
अहािा

“59ि.

59ग.

पीडीयाट्रिक

डॉक्टर ऑफ मेतडतसन (पीडीयाट्रिक न्यूरोिॉजी); या

न्यूरोिॉजी

तडप्िोमेट नेशनि बोडा (पीडीयाट्रिक न्यूरोिॉजी)

पीडीयाट्रिक

डॉक्टर ऑफ मेतडतसन (पीडीयाट्रिक ऑन्कोिॉजी)

-

-”

ऑन्कोिॉजी
[फा. सं. A.12018/03/2024-CHS-V]
जनजखल गिराि, संयुक्त सजचव
ट्रटप्पण:- मूि तनयम अतधसूचना संख्या. सा.का.तन. 272 (अ), िारीि 7 अप्रैि, 2014 द्वारा प्रकातशि की गयी र्ी और
ित्पश्चाि तनम्नतितिि अतधसूचना संख्याओं द्वारा संशोतधि दकए गए र्े, अर्ााि:् 1. सा.का.तन. 668(अ), िारीि 12 जुिाई, 2018
2. सा.का.तन. 459(अ), िारीि 28 जून, 2019
3. सा.का.तन. 662(अ), िारीि 17 अक्टू बर, 2024.

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health and Family Welfare)
NOTIFICATION

New Delhi, the 25th August, 2025
G.S.R. 585(E).— In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
President hereby makes the following rules further to amend the Central Health Service Rules, 2014 namely:-

1. (1) These rules may be called the Central Health Service (Amendment) Rules, 2025.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Central Health Service Rules, 2014, –
(i) in SCHEDULE II, against serial number 4, under the heading “(I) TEACHING SPECIALIST SUB-CADRE
(Assistant Professor or Associate Professor or Professor)”, against serial number 1, under the sub-heading “(b)
VARDHAMAN MAHAVIR MEDICAL COLLEGE AND SAFDARJUNG HOSPITAL, NEW DELHI”, after
serial number 17 and the entries relating thereto, the following shall be inserted, namely:Sl. No.
“18.
19.

Designation or Specialty
Pediatric Neurology
Pediatric Oncology

Number of posts
01
01”;

(ii) in SCHEDULE-VI, after Serial No.59A and the entries thereto, the following shall be inserted, namely:S. No.

Subject

Requisite Post Graduate Degree Qualifications

“59B.

Pediatric
Neurology
Pediatric
Oncology

Doctorate of Medicine (Pediatric Neurology); or
Diplomate National Board (Pediatric Neurology)
Doctorate of Medicine (Pediatric Oncology)”

59C.

Requisite Post
Graduate Diploma
Qualifications
-”

[F. No. A.12018/03/2024-CHS-V]
NIKHIL GAJRAJ, Jt. Secy.
Foot Note:- The Principal rules were published vide notification number G.S.R. 272(E), dated the 7 th April, 2014 and
subsequently amended vide the following notification numbers, namely:(1) No. G.S.R. 668(E), dated 12th July, 2018
(2) No. G.S.R. 459(E), dated 28th June, 2019
(3) No. G.S.R. 662(E), dated 17th October, 2024.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. SARVESH
SRIVASTAVA
Digitally signed by SARVESH KUMAR SRIVASTAVA
Date: 2025.08.28 21:36:43 +05'30'
