---
doc_id: "e5daa0ea15bcf156"
source_url: "https://www.legislative.gov.in/static/uploads/2025/07/7868ddb3c4686eeed374169ed5cfe05c.pdf"
ministry: "Legislative Department (LD)"
title: "SOR, The Constitution (Ninety-sixth Amendment) Act, 2011"
date: "2010-02-14"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2ccabef4d3479bb1"
---

<!-- page 1 -->

STATEMENT OF OBJECTS AND REASONS
The Government of Orissa forwarded to the Central Government in December 2008, the
Resolution passed by the Legislative Assembly of Orissa on 28th August, 2008 that, inter
alia, the name of the language specified as "Oriya", in the Eighth Schedule of Constitution
be changed as "Odia" and translation of the word "Odia" in Hindi language should be
revised as "~

" accordingly

and authorised

the Government

of Orissa

to place the

matter before Government of India for change of name of the State and change of language
of the State and change of their Hindi translations.
2. The Constitution (One Hundred and Thirteenth Amendment)
Bill, 20 10 seeks to
change of name of the language mentioned in the Eighth Schedule of the Constitution of
India, from 'Oriya' to 'Odia'.

NEW

P. CHIDAMBARAM.

DELHI;

The 14th February, 2010.

2
