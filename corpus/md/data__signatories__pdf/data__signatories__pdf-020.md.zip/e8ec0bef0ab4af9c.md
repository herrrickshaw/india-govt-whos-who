---
doc_id: "e8ec0bef0ab4af9c"
source_url: "https://steel.gov.in/sites/default/files/2025-04/Steel%20and%20Steel%20Products%20%28Quality%20Control%29%20Second%20%28Amendment%29%20Order%2C%202013_0.pdf"
ministry: "Steel (MoS)"
title: "Steel and Steel Products (Quality Control) Second (Amendment) Order, 2013_0.pdf"
date: "2025-04"
pages: 2
method: "tesseract:eng+hin"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d082510b46d84ef0"
---

<!-- page 1 -->

राजस्ट्री सं० डी० एल०-33004/99 Se - REGD. NO. D.L.-3300499
a SEY 2
eas
असाधारण
१ EXTRAORDINARY
भाग प--खण्ड 3-...उप-खण्ड (0)
PART I—Section 3—Sub-section (ii)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
क्ग्रगोततततततजस उन पलक 77 ८.२हन२#ल६ततनपससकफसपस<
i. 414) नई दिल्‍ली, सोमवार, फरवरी 25, 2013/फाल्गुन 6, 1934
No. 414] NEW DELHI, MONDAY, FEBRUARY aol _NEW DELHI, MONDAY, FEBRUARY 25, 2013/PHALGUNA 61934 2013/PHALGUNA 6, 1934
a eed
इस्पात मंत्रालय टिप्पण :--मूल आदेश दिनांक 12 मार्च, 2012 को भारत के
आदेश > राजपत्र, असाधारण में अधिसूचना संख्या का.आ. 414( अ),
नई दिल्‍ली, 15 फरवरी, 2015 के जरिए अधिसूचित किया गया ।
काओआ,. 449अ).--केन्द्रीय सरकार, भारतीय मानक ब्यूरो MINISTRY OF STEEL
अधिनियम, 1986 (1986 का 63) की धारा 14 द्वारा प्रदत्त शक्तियों
का प्रयोग करते हुए, भारतीय मानक ब्यूरो से परामर्श करने के पर्चांत्‌ पक a :
इस्पात एवं इस्पात उत्पाद (गुणवत्ता नियंत्रण) आदेश, 2012 को 12020 she {sth February) 2013 ह
संशोधित करते WERT निम्नलिखित आदेश करती है, अर्थात्‌ Bee S.O. 449(E),—in exercise of the powers conferred
ee आदेश को हि oss by Section 14 of the Bureau of Indian Standards Act, 1986
Ree ib (1) SA START को इस्सात एवं: इस्पात दत्माद ( (63 of 1986), the Central Government, after consulting the
) संशोधन आदेश, 2013 कहा जाए। Bureau of Indian Standards, hereby makes the following
(2) यह आदेश शासकीय राजपत्र में प्रकाशन की तिथि से order to amend the Steel and Steel Products (Quality
प्रवृत्त होगा । Control) Order, 2012, namely :-—
2. इस्पात एवं इस्पात उत्पाद (गुणवत्ता नियंत्रण) आदेश, 1. dd) This order may be called the Steel and Steel
2012 की अनुसूची में निम्नलिखित स्पष्टीकरण अंत में जोड़ा जाएगा, Products (Quality Control) Amendment Order, 2013.
ae: (2) It shall come into force on the date of its
: lication i ial Gazette.
“'स्पष्टीकरण.---सीमा-शुल्क अथवा आबकारी प्राधिकारी pe का मल — ics (Quai Contry
टैरिफ in the Steel an ee! "060६ alt ontrol
सीमा शुल्कों अथवा आबकारी टैरिफ शीर्षों के अनुसार Order, 2012, in the Schedule, the following Explanation shall
शुल्क लगाने का निर्णय लेते समय इस आदेश के प्रावधानों. ६७ inserted at the end, namely :--
का इस्तेमाल कॉँलम (1) की अनुरूपी प्रविष्टि के तहत “Explanation. —The Customs or Excise authorities
उल्लिखित भारतीय मानक संख्या के अंतर्गत कॉलम (2) may, while taking a decision on the levy of duty
की अनुरूपी प्रविष्टि के तहत बताए गए विशेष उत्पादों के as per the Customs or Excise Tariff Heads, apply
लिए करते हैं तथा इस प्रकार के मामले में यह आदेश उन the provisions of this Order to the specific
उत्पादों पर लागू नहीं होगा जो कॉलम (3) की अनुरूपी products described under corresponding entry
प्रविष्टि के तहत उल्लिखित आईटीसी ( एचएस) कोडों के under column (2), covered under the Indian
ata = Standard number mentioned under corresponding
अंतर्गत आते हैं लेकिन कॉलम (1) में उल्लिखित अनुरूपी entry under column (1) and in such case this Order
भारतीय मानकों के तहत नहीं आते हैं । shall not apply to those products which falls under
[फा. सं, 1(3), /2012-टीडब्ल्यू (भाग फाइल) ] the ITC (HS) Codes mentioned in corresponding
es entry under column (3) but do not fall under the
डॉ. दलोप सिंह, अपर सचिव 0 अंक
766 0/2013 | है ay

<!-- page 2 -->

72 THE GAZEILE UF INDIA: RA LAnUnu NE z
Oe a नननननननननत तनमन
corresponding Indian Standards mentioned under 'टिप्पण . :--मूल आदेश दिनांक 12 मार्च, 2012 को भारत के
हि. column (1).” राजपत्र, असाधारण में अधिसूचना संख्या का.आ. 415( 3),
[F.No. 172012-TW (Pt. File)] के जरिए अधिसूचित किया गया तथा बाद में इसे अधिसूचना
Dr. DALIP SINGH, Addl. Secy. संख्या का.आ. 2128(अ), दिनांक 10 सितम्बर, 2012
और का.आ. 2510(अ) , दिनांक 17 अक्तूबर, 2012
Note :— The principal Order was published in the Gazette के जरिए संशोधित किया गया ।
of India, Extraordinary vide notification number ORDER
§.0.414(B), dated the 12th March, 2012. New Dethi; the 15th February, 2013
आदेश S.O. 450(E).—in exercise of the powers conferred
by Section 14 of the Bureau of Indian Standards Act, 1986
नई दिल्‍ली, 15 फरवरी , 2013 (63 of 1986), the Central Government, after consulting the
केन्द्रीय सरकार, भारतीय ब्यूरो Bureau of Indian Standards, hereby makes the following
came 450(24).— रिकार, भारतीय मानक ब्यूः se order further to amend the Steel and Stee} Products (Quality
अधिनियम, 1986 (1986 का 63) की धारा 14 द्वारा प्रदत्त शक्तियों Control) Second Order, 2012, namely :—
का प्रयोग करते हुए, भारतीय मानक ब्यूरो से परामर्श करने के 1. (1) This order may be called the Stee! and Stee]
पश्चात्‌ इस्पात एवं इस्पात उत्पाद (गुणवत्ता नियंत्रण) द्वितीय Products (Quality Contro!) Second (Amendment)
आदेश, 2012 को संशोधित करते हुए एतद्द्वारा निम्नलिखित आदेश Order, 2013.
करती है। अ्थीत + ee (2) It shall come into force on the date of its
रती हैं, अः publication in the Official Gazette.
1, (1) इस आदेश को इस्पात एवं इस्पात उत्पाद (गुणवत्ता 2. (a) In the Steel and Steel Products (Quality Control)
क््स्त्रण संशोधन Second Order, 2012, inthe Schedule, against serial number
7 .
नियंत्रण) द्वितीय संशोधन आदेश, 2013 कहा जाए 9, in the entries under column (4), after item (A) and the
(2) यह आदेश शासकीय राजपत्र में प्रकाशन की तिथि से entries relating thereto, the following item and entries shal}
प्रवृत्त होगा । be inserted, namely — - ैीओआ inserted, namely :—
: ये Date of coming into force of the product in the standard to
2. (क) इस्पात एवं इस्पात उत्पाद (गुणवत्ता ) द्वितीय the extent given below
आदेश, 2012 की अनुसूची के क्रम संख्या 9 में कॉलम (4) की === gees
अबिष्टि में मद (च) और इससे संबंधित प्रविष्टियों के बाद निर्म्लिख्ित eer oO
मद एवं प्रविष्टियों को जोड़ा जाएगा, नामतः +-- (A) Product (B) With effect from
ee —C fe) Plmtmcfthicimess of 21st “Plate ofthicknessof  SistMarch,2013";
जच दो गई मानक सीमा में उत्पाद के शामिल होने की तिथि 10 mm to 80 mm and width
(4) of 2500 mm or more
of 2500 mmormore 5-77
(क) उत्पाद (ख) निम्न तिथि से लागू (b) the following Explanation shall be inserted at the
SS rrr end, namely :-—

*) a Team S80 TEA 31 HH, 201375 «Explanation.—The Customs or Excise authorities
की मोटाई और 2500 एमएम अथवा may, while taking a decision on the levy of duty as
इससे अधिक की चौड़ाई वाली प्लेट per the Customs or Excise Tariff Heads, apply the

इससे अधिक के ee 5 ie ; ‘fi

(ख) निम्नलिखित स्पष्टेकरण अंत में जोड़ा जाएगा, नामतः :-- provisions of this Order to the specific products

ss described under corresponding entry under

“स्पष्टीकरण.---सीमा-शुल्क अथवा आबकारी प्राधिकारी column (2), covered under the Indian Standard

सीमा-शुल्कों अथवा आबकारी टैरिफ शीर्षों के अनुसार number mentioned under corresponding entry
शुल्क लगाने का निर्णय लेते समय इस आदेश के प्रावधानों के a (One दा = an ie —

कॉलम अनुरूपी apply ¢ products wi falls under the

a eae Be (1) t fete के तहत (HS) Codes mentioned in correspondingentry under
उल्लिखित भारतीय मानक संख्या के cial (2) column (3) but do not fall under the corresponding

की अनुरूपी प्रविष्टि के तहत्‌ बताए गए विशेष उत्पादों के Indian Standards mentioned under column (1)."
लिए करते हैं तथा इस प्रकार के मामले में यह आदेश उन [F.No. 1(792012-TW]
उत्पादों पर लागू नहीं होगा जो कॉलम (3) की अनुरूपी Dr. DALIP SINGH, Addl. Secy.
wate के तहत उल्लिखित नल (एचएस) कोडों के Note :— The principal Order was published in the Gazette
अंतर्गत आते हैं लेकिन कॉलम (1) 'उल्लिखित अनुरूपी of India, Extraordinary vide notification number
: भारतीय मानकों के तहत नहीं आते हैं । §.0. 415(E), dated the 12th March, 2012 and
; -टीडब्ल्यू subsequently amended vide notification numbers
el “ase } §.0.2128(E), dated the 10th September, 2012 and

डॉ. दलीप सिंह, अपर सचिव $.0. 2510(E), dated the } 7th October, 2012.
nee Det 10084 Se gern
Printed by the Manager, Government of India Press, Ring Road, Mayapuri, New Dethi-1 10064
land Published by the Controller of Publications, Delhi-110054.
