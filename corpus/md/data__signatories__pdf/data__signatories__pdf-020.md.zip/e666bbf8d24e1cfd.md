---
doc_id: "e666bbf8d24e1cfd"
source_url: "https://dohe-education.gov.in/static/uploads/2025/09/792c6e30a6338e9af846ebc5fd5d7361.pdf"
ministry: "Department of Higher Education (DoHE)"
title: "IIITs - Information pertaining to Third Party Audit through software for the year 2024-25 in pursuance of DOPT's OM dated 07.11.2019 - reg."
date: "2025-07-21"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "76fd4c8488c9aea5"
---

<!-- page 1 -->

F.No. 76-1/2021-TS.I
Government of India
Ministry of Education
Department of Higher Education
Technical Section-l (I!ITs)
'C' Wing, Shastri Bhawan, New Delhi
Dated the 21 July, 2025
Subject : IllTs — Information pertaining to Third Party Audit through software for the year 2024-25 in
pursuance of DOPT's OM dated 07.11.2019 - reg.
With reference to RTI Section’s OM Nos.M-11014/1/2021-RTI dated 17.07.2023 and 06.12.2022 on the
subject cited above, it is request to upload the following information in RT! Weblink of the Department.
अल कर मिड Proposed course of action
The Boards, Councils & Information is already provided and is available in the RTI web link of the
other Bodies are | Department, MoE portal at - https://www.education.gov.in/en/rti_he (under
described however the | heading- IIITs inf on Boards and Councils -Transparency Audit wrt
composition, date of | compliance under Sec 4 of RTI Act-2005 )
constitution, term/tenure
and power & function in
detail are not available
on website.
2. For PPP Projects the | Setting up of 20 IIITs under PPP Mode:
information regarding
input/ outcomes were not Input:
available As of now, total 20 IITs are functioning under Not-for-Profit Public Private
Partnership model. The Capital cost of each IIITs is Rs.128.00 Cr. to be
contributed in the ratio of 50:35:15 by the Central Government, State
Government & Industry Partner(s) respectively and for any North-Eastern
State it is 57.5:35:7.5. In addition, an amount of Rs.10 cr. under OH-31 is
provided to each IITs for meeting recurring expenditure till project mode.
A total amount of Rs.1,316.56 crores [(i) Creation of Capital Asset (OH-
35) - Rs.1,126.75 cr., and (ii) Grants in aid General (OH-31) - Rs.189.81 cr. ]
released as on 31.03.2025, since inception.
Outcomes:
le To set up a model of education which can produce best-in-class human
resources in IT and harnessing the multi-dimensional facets of IT in various
domains. While the number of students produced by these IIITs would be
less, the impact they create would be substantial, in their expert domain.
* To contribute to the development of industries and finally boost the economic
rowth of the country.
&
_ — fp.
( far Mal Yadav)
Section Officer
To
ANIC Cell, DHE, MoE
E-mail : dhe-mhrd@nic.in  - (request for uploading on RTI web link of the Deptt)
Copy to:
US(RTI), DHE, MoE
E-mail : nishant.upadhyaya34@nic.in, rtiiedu@nic.in, rtisectiond1@gmail.com
