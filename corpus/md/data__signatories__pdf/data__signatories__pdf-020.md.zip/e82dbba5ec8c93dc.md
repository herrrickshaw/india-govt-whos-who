---
doc_id: "e82dbba5ec8c93dc"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/e9e2df5c11da08065503415cbd6ed743.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Letter to ISPs CS Comm no. 809 of 2024 dated 26.03.2025"
date: "2025-03-27"
pages: 89
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7d877597d1591e03"
---

<!-- page 1 -->

813-7/25/2024-DS

I/3262834/2025

By Email/DoT website
Government of India
Ministry of Communications
Department of Telecommunications
Sanchar Bhawan, 20, Ashoka Road, New Delhi - 110 001
(Data Service Cell)
No. 813-07/LM-38/2024-DS-II

Dated:26-03-2025

To,
All Licensees with Internet Service Authorization
Subject: CS (COMM) No 809 of 2024: Star India Pvt. Ltd. Vs. vegamovies.pet
& Ors before the High Court of Delhi.

Kindly ﬁnd enclosed the Hon’ble Delhi High Court orders dated20.09.2024 [
para 30(1.4) and 30(1.5)] and 24.03.2025 on the subject matter.
2. Please refer to para 3, 6 and 9 of the court order dated 24.03.2025 in respect of
blocking of websites/domains [139 nos.] enumerated in memo of parties
iro defendant nos. from 600 to 695 and 699 to 742.
3. In view of the above, all Licensees with Internet Service Authorization are hereby
instructed to take immediate necessary action for blocking of the said
websites/domains, as above, for compliance of the said court order.
Encl: AA

Director (DS-II)
Email: dirds2-dot@nic.in
Copy to:
i. Sh. V.Chinnasamy, Scientist E (chinnasamy.v@meity.gov.in), Electronics
Niketan, Ministry of Electronics and Information Technology (MeitY) New
Delhi for kind information and with request to take action as per the Annexure
pl.
ii. Ms. Ishi Singh <ishi@saikrishnaassociates.com> Plaintiﬀ's Advocate for kind
information and requested to take action as per the Annexure pl.
iii. IT Wing of DoT for uploading this order on DoT websites pl.

<!-- page 2 -->

$~19
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 809/2024
STAR INDIA PVT LTD
.....Plaintiff
Through:

Ms. Ishi Singh (VC), Advocate

versus
VEGAMOVIES.PET & ORS.
.....Defendant
Through:

Mr. Mrinal Ojha, Mr. Debarshi
Dutta, Mr. Arjun Mookerjee,
Mr. Yogesh Singh, Advocates
for D-24.
Mr. Yash Raj, Advocate for
D-26 & 140.

CORAM:
JOINT REGISTRAR (JUDICIAL) Dr. AJAY GULATI
ORDER
24.03.2025

%

I.A. No. 7618/2025 on behalf of the plaintiff seeking
impleadment of additional websites engaged in infringing
activities as defendant nos. 600-642 (rouge websites) in the
memo of parties.
1.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 600 to 642 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. The DNR’s concerning the
rogue websites have already been arrayed as defendants.
Keeping in view the contents of the suit and the application, the
same is allowed. The proposed defendants are impleaded as
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 26/03/2025 at 11:55:54

<!-- page 3 -->

defendant nos. 600 to 642. Issue summons to newly impleaded
defendants.
2.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve them with summons within a
week, through the electronic mode only.
3.

The order blocking the rogue-websites passed by the

Hon’ble Court on 20.09.2024 shall operate qua the freshly
impleaded defendants as well in terms of relevant directions
contained in para 30 of the order dated 20.09.2024, and para 4
of the order dated 26.09.2024 passed by the Hon’ble Court. IA is
allowed and disposed off accordingly. A copy of this IA be also
sent by the plaintiff to DNR’s (who already stand arrayed)
concerning these rogue websites.
I.A. No. 7617/2025 on behalf of the plaintiff seeking
impleadment of additional websites engaged in infringing
activities as defendant nos. 643-698 (rouge websites along
with their domain name registrars) in the memo of parties.
4.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 643 to 695 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Proposed defendant nos. 696
to 698 are the Domain Name Registrars for some of these new
rogue websites whose impleadment is also necessary to give
effect to the dynamic injunction operating in favour of the
plaintiff.

Keeping in view the contents of the suit and the

application, the same is allowed. The proposed defendants are
impleaded as defendant nos. 643 to 698.

Issue summons to

newly impleaded defendants.
5.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve them with summons within a
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 26/03/2025 at 11:55:54

<!-- page 4 -->

week, through the electronic mode only.
6.

The order blocking the rogue-websites passed by the

Hon’ble Court on 20.09.2024 shall operate qua the freshly
impleaded defendants as well in terms of relevant directions
contained in para 30 of the order dated 20.09.2024, and para 4
of the order dated 26.09.2024 passed by the Hon’ble Court. IA is
allowed and disposed off accordingly. A copy of this IA be also
sent by the plaintiff to DNR’s (who already stand arrayed)
concerning these rogue websites.
I.A. No. 7616/2025 on behalf of the plaintiff seeking
impleadment of additional websites engaged in infringing
activities as defendant nos. 699-742 (rouge websites along
with their domain name registrars) in the memo of parties.
7.

The plaintiff is seeking to implead additional rogue-

websites as defendant nos. 699 to 741 because they have been
found to be indulging in illegally disseminating the copyrighted
material belonging to the plaintiff. Proposed defendant no. 742 is
the Domain Name Registrar for one of the proposed defendants
i.e. proposed defendant no. 734 whose impleadment is also
necessary to give effect to the dynamic injunction operating in
favour of the plaintiff. Keeping in view the contents of the suit
and the application, the same is allowed.

The proposed

defendants are impleaded as defendant nos. 699 to 742. Issue
summons to newly impleaded defendants.
8.

The amended memo filed alongwith this IA is taken on

record. Steps be taken to serve them with summons within a
week, through the electronic mode only.
9.

The order blocking the rogue-websites passed by the

Hon’ble Court on 20.09.2024 shall operate qua the freshly
impleaded defendants as well in terms of relevant directions
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 26/03/2025 at 11:55:54

<!-- page 5 -->

contained in para 30 of the order dated 20.09.2024, and para 4
of the order dated 26.09.2024 passed by the Hon’ble Court. IA is
allowed and disposed off accordingly. A copy of this IA be also
sent by the plaintiff to DNR’s (who already stand arrayed)
concerning these rogue websites.
Dr. AJAY GULATI
(DHJS),
JOINT REGISTRAR (JUDICIAL)
MARCH 24, 2025/sk
Click here to check corrigendum, if any

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 26/03/2025 at 11:55:54

<!-- page 6 -->

Websites/Domains to be blocked:Sl.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42

Def. No.
600
601
602
603
604
605
606
607
608
609
610
611
612
613
614
615
616
617
618
619
620
621
622
623
624
625
626
627
628
629
630
631
632
633
634
635
636
637
638
639
640
641

Website/Domain
7starhd.is
1moviesfd.autos
9xmovies.hockey
9xmoviies.art
9xmoviies.shop
bolly4u.moe
bolly4you.biz
bolly-flix.biz
afilmyhit.monster
bdmusic23.boats
desiremovies.how
desiserials.li
dotmoviess.club
downloadhub.rsvp
filmy4z.site
filmyfly.moi
filmygod.beauty
filmy-hunk.com
filmyzerox.com
filmyzilla.net.vc
giboss.com
hdmovie2.best
hdmovie2.capital
hdmovie2.ms
issishqkarabrakha.com
kmmovies.click
llodynet.bond
lodynet.nl
maatisebandhidor.net
mkvmovispoints.autos
movies4u.mx
movies4you.mom
moviespapa.cz
moviezguru.cam
pika-show.org
pocketmeinaasman.net
ssrmoviess.mom
sumanindoriserial.net
tenalirama2.net
uwatchfree.homes
vasudhaserial.net
vegamovies-nl.life

<!-- page 7 -->

43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87

642
643
644
645
646
647
648
649
650
651
652
653
654
655
656
657
658
659
660
661
662
663
664
665
666
667
668
669
670
671
672
673
674
675
676
677
678
679
680
681
682
683
684
685
686

vegamoviess.life
2vv.yodesitv.org
3movierulz.live
5movierulz.tel
7starthd.com.cv
7starhd.club
9kmovies.fish
9xmovie.voto
9xmovies.loan
9xmoviess.biz
10hitmovies.pro
apnetv.li
bolly4u.vc
desirulez.org
dopebox.to
dudefilms.ws
filmybuff.space
filmyhit.up.in
full4movies.markets
hdhub4u.loans
hdking.press
hdmoviearea.makeup
hindilinks4u.living
jaaduternazar.net
luxecinema.fans
mannatserial.net
moviediskhd.online
mp4movies.makeup
neelive.com
pogolinks.lat
poovalan.blog
solarmovies.ms
southfreaks.xyz
ssrmovies.pm
themoviesflix.am
thenextplanet.coupons
thevegamovies.ru
topmovies.nexus
tvids.tv
updatetamila.com
vegamovies7.ch
vegamoviese.fit
vegamoviese.pro
vegamoviess.beauty
watch4freemovies.com

<!-- page 8 -->

88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132

687
688
689
690
691
692
693
694
695
699
700
701
702
703
704
705
706
707
708
709
710
711
712
713
714
715
716
717
718
719
720
721
722
723
724
725
726
727
728
729
730
731
732
733
734

watchmovierulz.men
watchseries.mn
watchsomuch.tv
watch-tvseries.tv
world4ufree.fyi
world4ufree.rest
wowmovies.cfd
yomovies.land
yomoviess.biz
1cinevood.cool
1moviesfd.boats
1shows.com
5movierulz.ag
5movierulz.camp
5movierulz.report
7filmywap.net
123moviesfree9.pics
720pflix.autos
7starhd.hockey
7starhd.je
7sttarhd.xyz
9xmovies.limo
bdhdmusic23.ink
bollyflix.gr.com
bolly-flix.store
ddrmovies.loan
downloadhub.moi
downloadhubs.top
extramovies.coupons
filmy4wap.bar
filmycab.shop
fmovies24-to.com
full4movies.coupons
fullymaza.autos
hdmovies23.monster
hindilinks4u.email
jalshamoviez.am.in
khatri-maza.biz
kmmovies.biz
moviesrock.dog
moviezguru.best
moviezwap.dad
sdmovies-point.mom
skymovieshd.farm
techyinformer.in

<!-- page 9 -->

133
134
135
136
137
138
139

735
736
737
738
739
740
741

uhdmovies.top
vegamovies.energy
vegamoviies.biz
watch5movierulz.cc
watchmovierulz.uno
wlext.is
ydesiserials.com

<!-- page 10 -->

IN THE HIGH COURT OF DELHI AT NEW DELHI
(ORDINARY ORIGINAL COMMERCIAL JURISDICTION)
CS (COMM) NO. 809 OF 2024
IN THE MATTER OF:
Star India Pvt. Ltd.

…Plaintiff
Versus

vegamovies.pet & Ors.

…Defendants

AMENDED MEMO OF PARTIES
IN THE MATTER OF:
1.

hosStar India Private Limited
Star House, Urmi Estate,
95, Ganpatrao Kadam Marg,
Lower Parel (W),
Mumbai- 400013
Also, at:
Vatika Business Centre, Thapar House,
Gate No. 1, Eastern & Central Wing
3rd Floor, 124 Janpath
New Delhi -110001
Email:

ashok.yadav@hotstar.com

…Plaintiff
Versus
1.

vegamovies.pet
Email: admin@VegaMovies.To ,
moviescontact@protonmail.com
pw-325afeb9143183d27297aa8bfB7f6flo@privacyguardian.org
Contact No. +1.3478717726

17

<!-- page 11 -->

2.

filmywap.rest
Email: support@namecheap.com
Contact No. +1 3102593259

3.

luxmovies.lol
Email: moviescontact@protonmail.com

4.

movies4u.diy
Email: abuse@namecheap.com; movies4ujp@proton.me
Contact No: +1 6613102107

5.

manatelugumovies.cc
Email: abuse@sarek.fi; support.telugumovies@gmail.com
Contact No: +358931577910

6.

new1themoviespalace.online
Email: abuse@namecheap.com
Contact No: +1 9854014545

7.

prmovies.food
Email: abuse@namecheap.com
Contact No: +1 6613102107

8.

movies4u.fun
Email: abuse@namecheap.com; movies4ujp@proton.me
Contact No: +1 9854014545

9.

gogodramas.su
Email: dramaon.su@whoisprotectiveservice.com

10.

extramovies.my
Email: support@namecheap.com ; extramovies.top@gmail.com
Contact No: + 3102593259

18

<!-- page 12 -->

11.

hdmovie2.id

19

Email: info@belidomain.co.id ; support@hdmovie2.com
12.

flixerabd.store
Email: abuse@hostinger.com
Contact No: + 37068424669

13.

hdmovies23.help
Email: abuse@namesilo.com ; bdmusic23life@gmail.com
Contact No: + 4805240066

14.

11xmovies.lat
Email: abuse@namesilo.com; bdmusic23life@gmail.com
Contact No: + 4805240066

15.

hdmovie22.com
Email:abuse@namecheap.com;
ba5c2bd1bab747b680bbe31b7b1ed4e1.protect@withheldforprivacy.com
Contact No: +1 9854014545

16.

ajker.in
Email: abuse@godaddy.com

17.

mkvin.skin
Email: abuse@namecheap.com
Contact No: +1 9854014545

18.

0gomovies.cam
Email: abuse@namecheap.com
Contact No: +1 9854014545

19.

tamildhool.app
Email : abuse@namecheap.com

20.

anupama.net

<!-- page 13 -->

Email: abuse@porkbun.com
Contact No: +1 9712666028

21.

baalveer.pk
Email: ashar@pknic.net.pk

22.

tamildhoolll.cc
Email: abuse@spaceship.com
Contact No: +1 6613102107

23.

kurumbi.com
Email: abusecomplaint@squarespace.com
Contact No: +1 6466935324

24.

Godaddy.com, LLC
Email: grievanceofficer@godaddy.com
4th Floor, Statesman House, Barakhamba Road
Connaught Place, New Delhi,
Central Delhi, Delhi.
Also at:
14455 North Hayden Road,
Suite 219 Scottsdale,
AZ, 85260, United State.

25.

Namecheap LLC
Email: support@namecheap.com ;
grievance.officer@namecheap.com
4600 East Washington Street Suite 300,
Phoenix, Arizona 85034, US

26.

Porkbun LLC
21370 SW Langer Farms Parkway, Suite-142-429

20

<!-- page 14 -->

Sherwood, OR 97140, US

21

Email: support@porkbun.com; abusegrievance-officer-in@porkbun.com
27.

Spaceship, Inc.
4600 East Washington Street, Suite 300,
Phoenix, AZ 85034, USA
Email: support@spaceship.com

28.

Sarek Oy
Email: terve@sarek.fi
Urho Kekkosen Katu 4-6 E, 00100 Helsinki, Finland

29.

PT. Jagat Informasi Solusi
Email: frieska@belidomain.co.id
Indosurya Plaza Lantai 3A, Jalan Muhammad Husni Thamrin,
nomor 8-9, Jakarta, 10230

30.

Hostinger operations, UAB
Email: support@hostinger.com
Hostinger, UAB. Jonavos str. 60C, 44192

31.

Namesilo LLP
Email: internaldomains@namesilo.com
1300 E. Missouri Avenue Suite A-110

32.

Squarespace Domains LLC
Email: abuse-complaints@squarespace.com
255 Varick Street, 12th Floor, New York, NY, 10014

33.

Pknic SRS Inc.
Email: staff@pknic.net.pk
435 Tariq Block, Garden Town, Lahore, Pakistan

34.

Active- SU

<!-- page 15 -->

22

Email: id@nic.ru ; sales@register.su
2/1, 3d Khoroshevskaya str., Moscow, 123308, Russian Federation
35.

Atria Convergence Technologies Private Limited
99A/113A, Manorayana Palya
R.T. Nagar Bangalore – 560032
Also, at:
2nd and 3rd Floor, No. 1,
Indian Express Building, Queen’s Road,
Bangalore – 560001, Karnataka
Email:

nodal.term@actcorp.in;

nodalofficer.ncr@actcorp.in,

jitesh.chathambil@actcorp.in
36.

Mahanagar Telephone Nigam Ltd.
5th Floor, Mahanagar Doorsanchar Sadan
9, CGO Complex, Lodhi Road
New Delhi – 110003
E-mail: raco.mtnl@gmail.com; mtnlcsco@gmail.com;
gmracomtnl@gmail.com

37.

Reliance Jio Infocomm Limited
RCP 14 (TC 23), Phase 4,
B-Block, 3rd Floor,
C 4 130 Twane- belapur Road,
Gansoli, Navi Mumbai- 400701
E-mail: care@jio.com; Hitesh.marthak@relianceada.com;
Kapoor.guliani@ril.com; mahipal.singh@ril.com;
sunil.kr.gupta@ril.com; shilpi.kant@ril.com;
jyoti.jain@ril.com; rudraksha.sinha@ril.com;
neelakantan.an@ril.com

38.

Shyam Spectra Pvt. Ltd.

<!-- page 16 -->

Plot No. 258,
Okhla Industrial Estate, Phase III,
New Delhi – 110020
Also, at:
Plot No. 21-22, 3rd Floor,
Udyog Vihar, Phase IV,
Gurugram -122015
E-mail: info@spectra.co; compliance@spectra.co
39.

Tata Teleservices Ltd.
A, E & F Blocks Voltas Premises - T. B. Kadam Marg
Chinchpokli, Mumbai – 400033
E-mail: pravin.jogani@tatatel.co.in; anand.dalal@tatatel.co.in;
satya.yadav@tatatel.co.in

40.

Vodafone Idea Limited
Vodafone House,
Peninsula Corporate Park,
Ganpatrao Kadam Marg,
Lower Parel, Mumbai - 400 013 India
Also, at:
Birla Centurion,
10th Floor, Plot no.794,
B Wing, Pandurang Budhkar Marg,
Worli, Mumbai - 400 030 India
E-mail: smitha.menon@vodafoneidea.com;
pankaj.kapdeo@vodafoneidea.com
Radhika.gokhale@vodafoneidea.com
sheena.thukral@vodafoneidea.com;
lavati.sairam@vodafoneidea.com

41.

Bharat Sanchar Nigam Ltd

23

<!-- page 17 -->

Bharat Sanchar Bhawan, Regulation Cell
5th floor, Harish Chandra Mathur Lane
Janpath, New Delhi -110001
E-mail: ddg_reg@bsnl.co.in; sbkhare@bsnl.co.in;
averma@bsnl.co.in; sushmamishra71@gmail.com
42.

Bharti Airtel Ltd.
Airtel Centre, Tower-A, 6th Floor
‘A’Wing, Plot No.16, Udyog Vihar
Ph - IV, Gurgaon – 122016
E-mail: amit.bhatia@airtel.com

43.

Hathway Cable & Datacom Pvt. Ltd.
‘Rahejas',4 floor, Main Avenue
Santacruz (W), Mumbai-40054
E-mail: ajay.singh@hathway.net; dulal@hathway.net;
sudhir.shetye@hathway.net

44.

Department of Telecommunications
Through Secretary,
Ministry of Communications and IT,
20, Sanchar Bhawan, Ashoka Road,
New Delhi – 110001
E-mail: secy-dot@nic.in, dirds2-dot@nic.in

45.

Ministry of Electronics and Information Technology
Through the Director General (DIT) Cyber Laws & e-security),
Electronics Niketan, 6, CGO Complex,
Lodi Road, New Delhi – 110003
E-mail: cyberlaw-legal@meity.gov.in; gccyberlaw@meity.gov.in;
pkumar@meity.gov.in, sathya.s@meity.gov.in

46.

National Internet Exchange of India (NIXI)

24

<!-- page 18 -->

9th Floor, B-Wing, Statesman House,

25

148, Barakhamba Road,
New Delhi- 110001
Email: info@nixi.in; legal@nixi.in
47.

Ashok Kumar

48.

thevegamovies.io
Email:jsalldmca@gmail.com, abuse@godaddy.com,
Contact No.: +1.4806242599, +1.480624250

49.

vegamovies.doctor
Email:vegamovies.com@gmail.com,
d8e5ae1de6194a3ea91a77d12fe75e2d.protect@withheldforprivacy.com,
abuse@namecheap.com
Contact No.: +354.4212434, +1.9854014545

50.

vegamovies.se
Email: voiseries@protonmail.com, info@ke-systems.net
Contact No.: +1-650-319-8930

51.

vegamovies.support
Email: abuse@godaddy.com,
Contact No.: +1.4806242599, +1.4806242505

52.

vegamovies.taxi
Email:vegamovies.com@gmail.com,
1603f131e49c431f80940aeb1e92e17e.protect@withheldforprivacy.com,
abuse@namecheap.com
Contact No.: +354.4212434, +1.9854014545

53.

vegamovies.tv.in
Email: myteam0006@gmail.com, abuse@dynadot.com

54.

vegamovies.uk.com
Email:vegamoviespublisher@proton.me, abuse@namecheap.com,
Contact No.: +1.9854014545

55.

vegamovies1.lol

<!-- page 19 -->

Email: abuse@namecheap.com,

26

Contact No.: +1.9854014545
56.

vegamovies4u.xyz
Email: vegamovies4u.xyz@gmail.com, abuse@hostinger.com
Contact No.: +370.68424669

57.

vegamovies20.xyz
Email:

eb4b3f1d4a564d8194696560de5bc27a.protect@withheldforprivacy.com,

abuse@namecheap.com
Contact No.: +1.9854014545
58.

vegamovieshd.cc
Email:pwp-1f4bb38acc8315bab66eae1595b155dd@privacyguardian.org,
dmc@prmovies.lc, abuse@namesilo.com
Contact No.: +1.3478717726, +1.4805240066

59.

vegamovieshd.club
Email: abuse@porkbun.com
Contact No.: +1.5038508351

60.

vegamovieshd.lol
Email: vegamovieshdsouth@gmail.com, abuse@namecheap.com
Contact No.: +1.9854014545

61.

vegamovieslink.com
Email:abuse@spaceship.com,
Contact No.: +354.4212434, +1.6613102107

62.

vegamoviesofficial.com
Email:tektuk2001@gmail.com,abuse@realtimeregister.com,abuse@hostinger.com
Contact No.: +31.384530759, +370.64503378

63.

vegamoviess.live
Email:123movieshub0@gmail.com, abuse@godaddy.com,
Contact No.: +1.4806242599, +1.4806242505

64.

luxmovies.co.in
Email: 123movieshub0@gmail.com, abuse@publicdomainregistry.com
Contact No.: +1.2013775952

<!-- page 20 -->

65.

luxmovies.one

27

Email: myteam0006@gmail.com, abuse@spaceship.com,
Contact No.: +1.6613102107
66.

luxmovies.skin
Email:fd0f680a05294898ab16cb801655346f.protect@withheldforprivacy.com,
abuse@namecheap.com
Contact No.: +1.9854014545

67.

1filmyhit.com
Email:OHNER@1filmyhit.com.customers.whoisprivacycorp.com,
abuse@internet.bs
Contact No.: +1.5163872248, +1.5163015301

68.

afilmywap.org.je
Email: afilmywap.in@gmail.com

69.

dilkotumsepyarhua.com
Email:abuse@registrar.eu,
Contact No.: +31.104482297

70.

filmymeet.sbs
Email: abuse@namecheap.com,
Contact No.: +1.9854014545

71.

filmywapi.com.co
Email:4742f6b3c35142cba3a69901374c0a58.protect@withheldforprivacy.com,
abuse@namecheap.com
Contact No.: +1.6613102107

72.

jhanak.su
Email: chuarbaaz2@gmail.com

73.

joya9tv.com
Email:

d3f4b80be13c4489817636e492b6dc68.protect@withheldforprivacy.com,

abuse@namecheap.com
Contact No.: +354.4212434, +1.9854014545
74.

khatrimaza.forum
Email: myteam0006@gmail.com, support@namecheap.com

<!-- page 21 -->

Contact No.: +1.3102593259
75.

kisikepyarmein.com
Email:abuse@spaceship.com,
Contact No.: +354.4212434, +1.6613102107

76.

kmmovies.net
Email:abuse@spaceship.com,
Contact No.: +354.4212434, +1.6613102107

77.

meethakhattapyaarhamara.com
Email: abuse@dynadot.com,
Contact No.: +1.6505854708, +1.6502620100

78.

megamovie.in
Email: contactmegamovie@gmail.com, abuse@hostinger.com
Contact No.: +370.64503378

79.

mkvcinemas.org.in
Email: abuse@godaddy.com

80.

modirekol.com
Email: abuse@1api.net
Contact No.: +49.68949396x850

81.

moviesdada.rest
Email: mkvpapa.com@gmail.com, support@namecheap.com,

82.

mp4moviez.glass
Email: admin@mp4moviez.in, abuse@name.com
Contact No.: +1.7208009072, +1.7203101849

83.

ofilmywap.org.vc
Email: abuse@dynadot.com, amp4moviez.in@gmail.com
Contact No.: +1.6502620100

84.

ottbangla.lol
Email: abuse@namecheap.com,
Contact No.: +1.9854014545

85.

prmovies.food

28

<!-- page 22 -->

29

Email:

3cadee96bada4b67a00bf7b789bf7cc5.protect@withheldforprivacy.com,

abuse@namecheap.com
Contact No.: +1.6613102107, +1-650-319-8930
86.

prmovies.pet
Email:

3710c5047f384050936b5adb18a7e1c5.protect@withheldforprivacy.com,

abuse@namecheap.com
Contact No.: +354.4212434, +1.9854014545
87.

styleapac.com
Email: 720pflix.com@gmail.com, abuse@godaddy.com
Contact No.: +1.4806242599, +1.4806242505

88.

tamilprint.autos
Email: myteam0006@gmail.com, abuse@spaceship.com
Contact No.: +1.6613102107

89.

ww2.movierulz.com.pk
Email: dmca@streamtape.com, ashar@pknic.net.pk
Contact No.: +92 (332) 477-1656,

90.

wwu.yodesiserials.su
Email: support@ardis.ru, dramaon.su@whoisprotectservice.net

91.

yodesidrama.net
Email:d569fd64d6a045169d89c0bc2076eb0c.protect@withheldforprivacy.com,
abuse@namecheap.com
Contact No.: +354.4212434, +1.9854014545

92.

zididill.site
Email: abuse@spaceship.com,
Contact No.: +1.6613102107

93.

1flix.gifts
Email : abuse@porkbun.com
Contact No: +1.9712666028

94.

2moviesda.com
Email : abuse@spaceship.com

<!-- page 23 -->

Contact No: +354.4212434
95.

30

5moviesrulz.net
Email:e9e7438ac04543328e4352a8493010cc.protect@withheldforprivacy.com;
abuse@namecheap.com;4movierulz.se@protonmail.com
Contact No: +354.4212434

96.

6movies.stream
Email:abuse@namecheap.com;
4b599fd791ff4e15aaae84c23a4f1df9.protect@withheldforprivacy.com
Contact No: +354.4212434

97.

7starhd.clinic
Email:49dbd9890ee341b09db6643e2835334c.protect@withheIdforprivacy.com;
abuse@namecheap.com ; 9xmoviewin@gmail.com
Contact No: +354.4212434

98.

7starhd.vote
Email : abuse@godaddy.com; jsalldmca@gmail.com
Contact No: 1.4806242505

99.

8xfilms.icu
Email : abuse@porkbun.com; azanssg42@gmail.com
Contact No: +1.8557675286

100. 8xmovies.asia
Email : abuse@porkbun.com; azanssg42@gmail.com
Contact No: +1.9712666028
101. 9kmovies.com
Email : 379d2f2c842f4a9581ce17ee78d8decf.protect@withheldforprivacy.com ;
abuse@namecheap.com; 9kmovies.com@gmail.com
Contact No: +354.4212434
102. 9xmovies.com.br
Email : demi@registro.br; 9xmovies2025@gmail.com
Contact No: +55 11 5509 3505
103. 9xmovies.dating

<!-- page 24 -->

31

Email : 69ad1c2966c14449af f848c9093c4824.protect @withheIdforprivacy.com;
abuse@namecheap.com; 9xmovies.site@gmail.com
Contact No: +354.4212434
104. 9xmovies.fashion
Email : abuse@netim.com;azanssg42@gmail.com
Contact No: +33.972307476
105. 10starhd.army
Email : abuse@dynadot.com; 10starhdteam@gmail.com
Contact No: 1.6592629199
106. 10xflix.co
Email : abuse@nacheap.com; jsalldmca@gmail.com
107. 123mkv.baby
Email : abuse@spaceship.com; myteam0006@gmail.com
Contact No: +1.6613102107
108. 720pflix.my
Email : support@namesilo.com; 720pflix.com@gmail.com
Contact No: +1.6024928198
109. a1movies.hair
Email : abuse@namecheap.com; a1moviesvip@proton.me
Contact No: +1.9854914545
110. aagmaal.sbs
Email : abuse@namecheap.com;
802f4d72185b45aa84804d07a9ca34ff.protect@withheldforprivacy.com
Contact No: +1.9854014545
111. afilmyhit.firm.in
Email : abuse@dynadot.com; afilmyhit.com@gmail.com
112. allmovieshub.beauty
Email : abuse@namecheap.com
Contact No: +1.9854014545
113. bdmusic99.biz
Email : abuse@namecheap.com; rohimtalukdar208@gmail.com

<!-- page 25 -->

Contact No : +1.6613102107

32

114. bflix.gg
Email : abuse@namecheap.com
115. bolly4hd.online
Email : abuse@porkbun.com
Contact No : +1.8557675286
116. bolly4u.cam
Email : abuse@porkbun.com
Contact No :+1.9854014545
117. bolly4umovies.net
Email : yvlbrianturner568@gmail.com; dmca@bolly4umovies.net
Contact No : (850) 473-6173
118. bollywap.click
Email : abuse@namecheap.com; bollywap@protonmail.com
Contact No : +1.6613102107
119. bollywoodhdmovies.xyz
Email : abuse@spaceship.com
Contact No : +1.6613102107
120. cinebro.top
Email : abuse@namesilo.com; moviebaazinfo@gmail.com
Contact No : +1.4805240066
121. ddrmovies.win
Email : abuse@porkbun.com; azanssg42@gmail.com
Contact No : +1.5938598351
122. hdmovie2.now
Email : abuse@namecheap.com;
fc075fad9f014ca8a1ff485ae16cd31a.protect@withheldforprivacy.com
Contact No : +1.6027723958
123. isaimini.com.mk
Email : agent@designated.uk; designated@agent.mk
Contact No : +1.4156499101

<!-- page 26 -->

124. m.9xflix.fashion

33

Email : abuse@spaceship.com; myteam0006@gmail.com
125. movies4u.casino
Email :
7c5a00256af340f6a8e7c29934545648.pr-otect@withheldforprivacy.com;
Contact No : +354.4212434
126. moviesfd.fashion
Email : abuse@namecheap.com
Contact No : +1.6613182187
127. mp4moviez.coach
Email : abuse@namecheap.com; admin@mp4moviez.in
9e163e2aD26148e9979abaoes77bfead.protect @withheIdforprivacy.com
Contact No : +354.4212434
128. prmovies.day
Email : abuse@namecheap.com
Contact No : +1.6613102107
129. themoviesflix.beer
Email : abuse@godaddy.com ; jsalldmca@gmail.com
Contact No : +1.4896242595
130. vegamovies.claims
Email : abuse@namecheap.com ; vegamovies.com@gmail.com
2cbd626acc8d4dd49eba26ebbe132fsoprotect@withheIdforprivacy.com
Contact No : +354.4212434
131. ww1.4movierulz.llc
Email:abuse@namesilo.com;pw0fb15b7ca34d9497d444491bba8f6a0c@privacyguardian.org;
5movierulz@proton.me
Contact No : +1.3478717726
132. ww6.movierulzhub.co
Email : abuse@namesilo.com ; 5movierulz@proton.me
Contact No : +1.4805240066

<!-- page 27 -->

133. xmovies8.vip

34

Email : abuse@namecheap.com
Contact No : +1.4805240066
134. yomovies.ing
Email : abuse@namecheap.com
Contact No : +1.6613102107
135. NameSilo, LLC
8825 N, 23rd Ave Suite 100
Phoenix, AZ
USA – 85021
Email : abuse@namesilo.com ; support@namesilo.com; legal@namesilo.com
136. Key-Systems GmbH
Im Oberen Werk 1
66386 St. Ingbert
Germany
Email: info@ke-systems.net
Contact No: +49-68949396850
137. Realtime Register B.V.
Burgemeester Drijbersingel 51
8021 JB Zwolle
The Netherlands
Email: abuse@realtimeregister.com; support@realtimeregister.com
Contact No: + 31 38 453 0759
138. Endurance Digital Domain Technology Private Limited
HD-016, WeWork Nesco IT Park, Building 4,
Nesco IT Park Western Express Highway, Goregaon (East)
Goregaon East Mumbai Goregaon East
Maharashtra India 400063
Email: compliance@edtpl.in; grievance-officer@publicdomainregistry.com
139. Internet Domain Service BS Corp
98 Hampshire Street Nassau N-4892.

<!-- page 28 -->

Bahamas.

35

Email: contact-en@internet.bs
140. Hosting Concepts B.V. d/b/a Registrar.eu
Kipstraat 3c-5c, Rotterdam 3011 RR
Netherlands, +31104482296
Email: support@openprovider.com,
support@openprivider.com
141. 1API GmbH
Talstrasse 27, Homburg,
Saarland 66424, DE
Email: abuse@1api.net
142. NETIM
264 avenue Arthur Notebart,
59160 Lille France
Email: sales@netim.com; grievance-officier@netim.net; abuse@netim.net
143. Network Solutions, LLC
Herndon, Virginia,
Jacksonville,Florida,
Florida, U.S.
Email : domain.operations@web.com
144. MARCOM-REG
Danica Rucigaj 11
MK-1000 SKOPJE
Email : info@registrar.mk
145. Registro.br
Av. João Dias, 3163 - Santo Amaro,
São Paulo - SP, 05801-000
Email: doc@registro.br; hostmaster@registro.br ; pagamento@registro.br
146. 1kuttymovies.com.co
Email : abuse@namecheap.com
147. 2filmyhunk.com

<!-- page 29 -->

Email : abuse@registrar.eu

36

148. 3kmovies.quest
Email : abuse@namecheap.com ; bdmusic23life@gmail.com
149. 5movierulz.day
Email : abuse@dynadot.com ; 4movierulz.se@protonmail.com
150. 5movierulz.dev
Email : abuse@name.com
151. 8xfilms.diy
Email : azanssg42@gmail.com ; abuse@porkbun.com
152. 123moviesfree9.guru
Email:abuse@namecheap.com;
aa5f460680fd4c25baa7c3ac26c9f42c.protect@withheldforprivacy.com
153. afilmyhit.er.in
Email : afilmyhit.com@gmail.com
154. afilmywap.giving
Email : afilmywap.in@gmail.com
155. allmovieshub.cafe
Email: abuse@hostinger.com
156. bdmusic28.buzz
Email : bdmusic28.net@gmail.com ; abuse@namesilo.com
157. bmlcarbon.com
Email : 2kia@mail.ru ; abuse@regtime.net
158. bollyfun.cloud
Email : abuse@hostinger.com; domains@hostinger.com
159. btspro24.com
Email : SUPPORT@sav.com ; ABUSE-CONTACT@sav.com
160. desicinemas.lol
Email : abuse@namecheap.com
161. desitellybox.net
Email:desitvbox@yahoo.com;a8066da521114ceeaa1e5ba1bb9b0da9.protect@with
heldforprivacy.com ; abuse@namecheap.com

<!-- page 30 -->

37

162. downloadhub.pet

Email : 25df68c0a607444286f5707a9aeb3b2f.protect@withheldforprivacy.com :
abuse@namecheap.com
163. downloadhub4u.me
Email

:

abuse@namecheap.com

:

3ea37079d41e432da15220d54e8567ed.protect@withheldforprivacy.com
164. extramovies.soy
Email : extracloud786@gmail.com ; abuse@enom.com
165. filmycab.sbs
Email : bf89501ae7d94f4f8a7f0cdb891dfce1.protect@withheldforprivacy.com ;
abuse@namecheap.com
166. hdhub4u.solutions
Email : abuse@godaddy.com
167. hdjan24.pro
Email

:

abuse@namecheap.com

f8b45e3c83b34a0e948b5ed43e311cb8.protect@withheldforprivacy.com
168. hdmovies2.loans
Email : abuse@spaceship.com
169. hindilinks4u.makeup
Email : cadb933281034bc89d6e5e093897402c.protect@withheldforprivacy.com ;
abuse@namecheap.com
170. jalshamoviez.im
Email : Tinaba047@gmail.com ; padcock@domicilium.com
171. jalshamoviez.info.in
Email : jalshamoviez123@proton.me
172. katmovie.skin
Email : myteam0006@gmail.com ; abuse@spaceship.com
173. latesthdmovies.qpon
Email : abuse@porkbun.com
174. mkvboss.net
Email : abuse@spaceship.com

;

<!-- page 31 -->

175. mkvcinemas.soy

38

Email : domainabuse@tucows.com
176. mlsbd.tv
Email : abuse@dynadot.com
177. movieruls.cc
Email:movierulzfree@gmail.com;
6c81541a3b8a40a2b518d0bd884e7971.protect@withheldforprivacy.com;
abuse@namecheap.com
178. movies4u.eu.com
Email: movies4ujp@proton.me ; abuse@namecheap.com
179. movies4u.love
Email: abuse@namecheap.com
180. movies4u.vote
Email: abuse@namecheap.com
181. movies4u.voto
Email : movies4ujp@proton.me ; abuse@spacehip.com
182. moviesda.ing
Email : abuse@spaceship.com
183. movieshunt.art
Email : movieshuntpro@proton.me ; abuse@spaceship.com
184. movieswood.homes
Email : abuse@spaceship.com
185. moviezguru.me
Email:abuse@namecheap.com;
473ab6b6af404876a5c82ac7376ab1f7.protect@withheldforprivacy.com
186. moviezwap.plus
Email :

moviezwaphd@protonmail.com ; abuse@namesilo.com ; pwp-

91d4e289c7c6bbc20478cb9ddb90ccb9@privacyguardian.org
187. mp4movies.my
Email : myteam0006@gmail.com ; abuse@spaceship.com
188. serialtv.biz

<!-- page 32 -->

Email : admin@serialtv.biz ; abuse@namecheap.com
189. skymovieshub.in
Email: abuse@hostinger.com
190. ssrmoves.wtf
Email : ssrmovies-dmca@proton.me
191. tamilrockers.dev
Email : abuse@namecheap.com
192. vegamovies.capital
Email : abuse@porkbun.com
193. vega-movies.my
Email : myteam0006@gmail.com ; abuse@spaceship.com
194. watchmovierulz.tf
Email : abuse@name.com
195. worldfree4u.my
Email : myteam0006@gmail.com ; abuse@spaceship.com
196. ww19.4movierulz.io
Email : abuse@namecheap.com
197. yomoviess.my
Email : abuse@spaceship.com
198. 3kmovies.love
Email : bdmusic23life@gmail.com ; support@namesilo.com
199. Sav.com, LLC
2229 South Michigan Ave Suite 303
Chicago, IL 60616
Email: support@sav.com.com
200. Enom LLC
Kirkland, Washington
United States
Email : abuse@enom.com
201. Nic.im
Domicilium (IoM) Limited

39

<!-- page 33 -->

40

The Isle Of Man Datacentre
Ronaldsway Industrial Estate
Ballasalla
Isle of Man
IM9 2RS
British Isles
Email : info@nic.im
202. Nic.wf
Immeuble le Stephenson, 1, rue Stephenson,
Montigny-Le-Bretonneux, 78180, FR
Email : support@afnic.fr
203.

Dynadot LLC
210 S Ellsworth Ave
#345 San Mateo,
CA 94401 US
Email : info@dynadot.com ; nixi.grievance.officer@namecheap.com

204. Name.com Inc.
PO Box 1769
Denver,CO
United States, 80201
Email : abuse@name.com
205. Tucows Domains Inc.
96 Mowat Avenue
Toronto, ON M6K 3M1
Canada
Email : domainabuse@tucows.com , info@tucows.com
206. Regtime Ltd.
443013,

Samara,

office

center

Moskovskoe shosse, 17, office 2103 , 21st floor
Email: support@webnames.ru, s.shar@regtime.net
207. 1movierulzhd.guru

“Vertical”

,

<!-- page 34 -->

Email

:

41

admin@movierulzhd.com;

a1df518b30a44a6db8ca4427950a3213.protect@withhedprivacy.com;
abuse@namecheap.com
208. 1moviesfd.store
Email: abuse@namecheap.com
209. 1tamilmv.ac
Email : abuse@sarek.fi
210. 1tamilprint.art
Email: tamilprint@proton.me; abuse@namecheap.com
211. 1xbetmovies.world
Email: 1xbetmovies@gmail.com; abuse@hostinger.com
212. 7starhd.org.pl
Email: 7starhd.com@gmail.com; pl-admin@dns.pl
213. 9xmovies.camera
Email: 9xmovies.com@gmail.com; abuse@name.com
214. 10hitmovies.blog
Email: 10hitmovies@gmail.com; abuse@namesilo.com
215. 11xmovies.skin
Email: bdmusic23life@gmail.com; abuse@namecheap.com
216. atishmkv.guru
Email:
a11fe343aa2247ae8fa10cc6ad583a68.protect@withheldforprivacy.com;
abuse@namecheap.com
217. desiremovies.africa
Email: nicrelations@opensrs.com
218. desimovies.moe
Email: desiremovies.com@gmail.com; abuse@namecheap.com
219. downloadhub.voto
Email: downloadhub.com@gmail.com
220. downloadhub4u.work
Email: abuse@namecheap.com

<!-- page 35 -->

221. dudefilms.my

42

Email: abuse@namecheap.com
222. filmymeet.vip
Email: abuse@dynadot.com
223. filmywap.com.tr
Email: filmywap.contact@proton.me; onur.gencer@btk.gov.tr
224. filmyworld.com.co
Email: abuse@registrar.eu
225. filmyworld.makeup
Email: myteam0006@gmail.com; abuse@spaceship.com
226. filmyworlds.support
Email: filmyworld111@proton.me; abuse@namecheap.com
227. full4movies.gifts
Email: abuse@porkbun.com
228. hdhub.world
Email: abuse@spaceship.com
229. hdhub4u.pe
Email: abuse@1api.net
230. hdmovie2.house
Email:
f8dfd4cbe31247be8b9865d5357692e6.protect@withheldforprivacy.com;
abuse@namecheap.com
231. hdmovie2.pe
Email: help@ascio.com
232. hdmovies23.vip
Email: bdmusic23life@gmail.com; abuse@namesilo.com
233. hindiserial.net
Email: abuse@spaceship.com
234. jalshamoviez.moe
Email: abuse@namecheap.com
235. jubileetalkies.com

<!-- page 36 -->

43

Email:

1b5a7a16f81b41fb8cdeb3261c38a1ac.protect@withheldforprivacy.com;
abuse@namecheap.com
236. kutty-movies.my
Email: myteam0006@gmail.com; abuse@spaceship.com
237. meghabarsenge.com
Email: abuse@name.com
238. mkvfun.net
Email:
ee8f7b686e584ca88767ce316c49f546.protect@withheldforprivacy.com;
abuse@namecheap.com
239. movierulzfree.su
Email: info@tcinet.ru; su-adm@ripn.su
240. movies4u.vc
Email: abuse@namecheap.com
241. movies-mood.my
Email: myteam0006@gmail.com; abuse@spaceship.com
242. moviesrock.blog
Email: abuse@hostinger.com
243. moviezguru.work
Email: abuse@namecheap.com
244. mp4moviez.insure
Email: admin@mp4moviez.in; abuse@namecheap.com
245. mullupum.com
Email: abuse@godaddy.com
246. neeplay.net
Email:

neeplay@proton.me;

1bxwrcqtq@whoisprivacyprotect.com;

abuse@enom.com
247. ofilmywap.org.pl
Email: amp4moviez.in@gmail.com; pl-admin@dns.pl
248. pakvegamovies.com

<!-- page 37 -->

Email: pakvegamovies@gmail.com; abuse@namecheap.com

44

249. skymovieshd.moe
Email: skymoviesHD.in@gmail.com; abuse@namecheap.com
250. ssrmovies.london
Email: ssrmovies.com@gmail.com ; abuse@namecheap.com
251. thekhatrimaza.ing
Email: thekhatrimaza@protonmail.com; abuse@namecheap.com
252. themoviesflix.lat
Email: jsalldmca@gmail.com; abuse@godaddy.com
253. themoviesverse.life
Email: jsalldmca@gmail.com; abuse@godaddy.com
254. thevegamovies.gg
Email: jsalldmca@gmail.com; abuse@namecheap.com
255. vegamovies4u.im
Email: info@nic.im; imdomainadmin@nic.im
256. vegamovies4u.lat
Email: abuse@namecheap.com
257. wvv.madamsir.net
Email: abuse@porkbun.com
258. yomovies.express
Email:
c05788bde9074acc99a72acde9bf42f9.protect@withheldforprivacy.com;
abuse@namecheap.com
259. Dns.pl
ul. Kolska 12,
01-045 Warsaw
Email: info@dns.pl
260. OpenSRS
96 Mowat Ave,
Toronto,ON M6K 3M1,
Canada

<!-- page 38 -->

Email: domainabuse@tucows.com
261. trabis.gov.tr
Eskisehir Road 10.
Km No:276 06530
Cankaya / ANKARA
Email: support@trabis.gov.tr
262. EPAG Domain services GmbH
Strandvejen125
DK-2900Hellerup,
Denmark
Email: sales@ascio.com
263. Tcinet.ru
127083, Russia, Moscow, inner ter. of the city, Aeroport
municipal district, ul. 8 Marta,
house 1, building 12,
room1/7
Nearest metro stations — Dynamo, Aeroport
Email: info@tcinet.ru
264. 4filmydhoom.com
Email: filmydhoom@proton.me , abuse@spaceship.com
265. 7hitmovies.moe
Email: abuse@namecheap.com
266. 7starmv.lat
Email: 720pflix.com@gmail.com, abuse@dynadot.com
267. 8xmovies.cfd
Email: azanssg42@gmail.co, abuse@spaceship.com
268. 9kmovies.voto
Email: 9kmovies.com@gmail.com, abuse@name.com
269. 9xflix.mx
Email: mymkvcinemas.com@gmail.com, abuse@nic.mx
270. 9xflix.voto

45

<!-- page 39 -->

Email: 9xflix.com@gmail.com, abuse@name.com
271. 9xmovies.es
Email: info@nic.es, esnic-tech@red.es
272. 9xmoviies.top
Email: azanssg42@gmail.com, abuse@porkbun.com
273. 11xmovies.love
Email: bdmusic23life@gmail.com, support@namesilo.com
274. 720pflix.cab
Email: 720pflix.com@gmail.com, abuse@dynadot.com
275. a1movies.pics
Email: a1moviesvip@proton.me, abuse@namecheap.com
276. bolly4u.cat
Email: Bolly4u.info@gmail.com, domainabuse@tucows.com
277. bolly-4u.in
Email: support@tldregistrarsolutions.com
278. bolly4you.buzz
Email: myteam0006@gmail.com, abuse@spaceship.com
279. bollyflix.me.in
Email: jsalldmca@gmail.com
280. bollymod.buzz
Email: abuse@spaceship.com
281. desiremovies.beer
Email: domainabuse@tucows.com
282. dotmoviess.my
Email: myteam0006@gmail.com, abuse@spaceship.com
283. extramoviess.my
Email: myteam0006@gmail.com, abuse@spaceship.com
284. filmyfly.earth
Email: admin@filmyfly.net, compliance@tucows.com
285. filmymeet.5g.in
Email: abuse@dynadot.com

46

<!-- page 40 -->

286. filmypro.online

47

Email: abuse@hostinger.com
287. fmovies.tube
Email: domainabuse@tucows.com
288. full4movies.christmas
Email: abuse@namecheap.com
289. hdhub4u.gg
Email: abuse@namecheap.com
290. hdmoviehub.tech
Email: hdmoviehubforall@gmail.com, abuse@inwx.com
291. hdmovies4u.cx
Email: hdmovies4u@protonmail.com, abuse@key-systems.net
292. ibommatelugumovies.top
Email: abuse@dynadot.com
293. khatrimazafull.cloud
Email: contactmaza@protonmail.com, support@namecheap.com
294. mkvin.bond
Email:

910cf165997240e2954ab693dcc36ef9.protect@withheldforprivacy.com,

abuse@namecheap.com
295. mkvmoviespoint.buzz
Email: myteam0006@gmail.com, abuse@spaceship.com
296. movie4me.cymru
Email: movie4me2@protonmail.com, abuse@namecheap.com
297. movie4u.click
Email: abuse@namecheap.com
298. moviebaaz.site
Email: moviebaazinfo@gmail.com, abuse@namecheap.com
299. moviedrivebd.com
Email: moviedrivebd10@gmail.com
300. movies4u.bz
Email: abuse@namecheap.com

<!-- page 41 -->

48

301. movies4u.living
Email: movies4ujp@proton.me, abuse@spaceship.com
302. movies4u.loans
Email: movies4ujp@proton.me, abuse@spaceship.com
303. moviesdaddy.me
Email:

7e57ea9d4ea043c399250e9671726c21.protect@withheldforprivacy.com,

abuse@namecheap.com
304. movies-flix.com
Email:

cf1311cff4b447b692236da0e1083e10.protect@withheldforprivacy.com,

abuse@namecheap.com
305. movieshunt.buzz
Email: abuse@spaceship.com
306. moviezwap.im
Email: moviezwaphd@protonmail.com, imdomainadmin@nic.im
307. msmovies.cloud
Email: msmovies.owner@gmail.com, domain@hostinger.com
308. oomoye.life
Email: oomoye@proton.me, 13a5ada3081a48128bcf6d7c971c79e1.protect@with
heldforprivacy.com, abuse@namecheap.com
309. rdxhd.wiki
Email: rdxhd096@gmail.com, abuse@namecheap.com
310. rogmovies.com
Email:

moviescontact@protonmail.com,

853972ba949f4a5892742Bb05d21e521.protect@withheldforprivacy.com,
abuse@namecheap.com
311. sdmovies.my
Email: myteam0006@gmail.com, abuse@spaceship.com
312. skymovieshd.house
Email: sfilmywapin@gmail.com, abuse@dynadot.com
313. ssrmovies.joburg

<!-- page 42 -->

Email: ssrmovies-dmca@proton.me, nicrelations@opensrs.com

49

314. vegamovies.fish
Email: abuse@porkbun.com
315. vegamovies4u.beauty
Email:abuse@namecheap.com
316. vegamovies7.com
Email: abuse@spaceship.com
317. vegamovieshub.pl
Email: info@dns.pl
318. ww2.watchmovierulz.tf
Email: support@name.com
319. yomovies.house
Email:

5d842be3ad94445e930be24a11011121.protect@withheldforprivacy.com,

abuse@namecheap.com
320. yomoviess.buzz
Email: myteam0006@gmail.com , abuse@spaceship.com
321. yrkkhdesi.com
Email: admin@yrkkhdesi.com, abuse@spaceship.com
322. Nic.es
".es" Domain Registration Department
Public Business Entity red.es
Bronze Building Plaza Manuel Gómez Moreno,
s/n 28020 Madrid (Spain)
Email: info@nic.es, esnic-tech@red.es
323. TLD Registrar Solutions Ltd.
Saddlers House, 44 Gutter Ln,
Lonfdon, EC2V 6BR
United Kingdom
Email: support@tldregistrarsolutions.com
324. INWX GmbH
Hardturmstrasse 161

<!-- page 43 -->

8005 Zurich

50

Switzerland
Email: info@inwx.com
325. Central Nic Ltd.
4th Floor, Saddlers House,
44 Gutter Lane,
London, EC2V 6BR
Email: registrars@centralnic.com, info@centralnic.com, support@centralnic.com
326. OwnRegistrar, Inc.
18 San Carlos Street
Los Angeles, California
94110, United States
Email: abuse@ownergistrar.com
327. 1filmymeet.dr.in
Email: abuse@dynadot.com
328. 1moviesfd.life
Email:
f633fac7bcde42dba8578613dc8e6fa3.protect@withheldforprivacy.com;
abuse@namecheap.com
329. 5filmyzilla.com
Email: abuse@spaceship.com ;
filmyzilla2024@proton.me
330. 5movierulz.gay
Email: support@namesilo.com; abuse@namesilo.com
331. 7starhd.im
Email: jsalldmca@gmail.com; padcock@domicilium.com
332. 7starhd.net.pl
Email : 7starhd.com@gmail.com; support@openprovider.com
333. 7starmv.mom
Email: 720pflix.com@gmail.com; abuse@namecheap.com
334. 7sttarhd.pics

<!-- page 44 -->

Email: azanssg42@gmail.com; abuse@porkbun.com

51

335. 9xmovies.vegas
Email: 9xmovies.com@gmail.com; abuse@namecheap.com
336. allmovieshub.host
Email: abuse@hostinger.com
337. atishmkv2.shop
Email: abuse@namecheap.com
338. bdmovie440.pro
Email: mlsbdteam@gmail.com; contact@privacyprotect.org; abuse@hostinger.com
339. bdmusic28.love
Email: bdmusic28.net@gmail.com; support@namesilo.com
340. cinemaluxe.fans
Email: luxedmcaremoval.liable826@passinbox.com; donainabuse@tucows.com
341. ddrmovies.diy
Email: azanssg42@gmail.com; abuse@porkbun.com
342. dotmoviess.top
Email: myteam0006@gmail.com; abuse@spaceship.com
343. downloadhub.actor
Email: abuse@namecheap.com
344. downloadhub.loans
Email: downloadhub.com@gmail.com; abuse@namecheap.com
345. downloadhub1.buzz
Email: myteam0006@gmail.com; abuse@spaceship.com
346. downloadhub4u.life
Email:

f5cf27e73c2e476bba3f1a0803eb1c2e.protect@withheldforprivacy.com;

abuse@namecheap.com
347. dudefilms.com.im
Email: info@nic.im; imdomainadmin@nic.im
348. fibwatch.shop
Email: abuse@namecheap.com
349. filmycity.uno

<!-- page 45 -->

Email: myfilmycity@gmail.com; abuse@hostinger.com

52

350. hdmovies23.asia
Email: bdmusic23life@gmail.com; pwp-8939ce9dd81aOc3d51af8c6761671334@
privacyguardian.org; abuse@namesilo.com
351. herogayab.vip
Email: info@herogayab.vip; abuse@namecheap.com
352. jalshamoviez.internet.in
Email: jalshamoviez123@proton.me; abuse@dynadot.com
353. laughterchefs.co
Email: copyright@herogayab.me; abuse@dynadot.com
354. luxmoviess.my
Email: myteam0006@gmail.com; abuse@spaceship.com
355. movie4me.london
Email: movie4me2@protonmail.com; abuse@namecheap.com
356. moviemax.cc
Email:
bde3d29da7784c23a71f4976890a30e7.protect@withheldforprivacy.com;
abuse@namecheap.com
357. movierulzhub.live
Email: contactus001122@gmail.com; abuse@namecheap.com
358. movies4u.ad
Email: abuse@namecheap.com
359. moviezguru.skin
Email: abuse@namecheap.com
360. mp4moviez.hockey
Email: admin@mp4moviez.in; abuse@namecheap.com
361. mp4-moviez.my
Email: myteam0006@gmail.com; abuse@spaceship.com
362. neeplay.tv
Email: neeplay@proton.me; abuse@namecheap.com
363. ofilmywap.org.uk

<!-- page 46 -->

Email: amp4moviez.in@gmail.com; abuse@dynadot.com

53

364. ofilmyzilla.giving
Email: ofilmyzilla.com@gmail.com; abuse@dynadot.com
365. prmovies.report
Email: abuse@namecheap.com
366. rabse.net
Email: abuse@dynadot.com
367. skymovieshd.toys
Email: skymoviesHD.in@gmail.com; abuse@namecheap.com
368. tamildhool.su
Email: support@regtime.net; nrtigershroff@gmail.com
369. tamilprint33.art
Email: tamilprint@proton.me; abuse@namecheap.com
370. thekhatrimaza.bet
Email: thekhatrimaza@protonmail.com; abuse@namecheap.com
371. vegamovies4u.website
Email: abuse@namecheap.com
372. vegamovieshd.online
Email: vegamovieshdsouth@gmail.com; abuse@namecheap.com
373. vegamoviesz.my
Email: contact@vegamoviez.com.in; abuse@namecheap.com
374. yomovies.mba
Email:
85f3043818a244038db4c1e49288c54b.protect@withheldforprivacy.com;
abuse@namecheap.com
375. Regtime-su
Samara, Moskovskoe shosse, 17,
office 2103 (TOP "Vertical", 21st floor)
443013
Email: regtime.su@allperson.ru ; abuse@regtime.net
376. 2filmywap.net

<!-- page 47 -->

Email: filmywap.contact@proton.me, abuse@spaceship.com

54

377. 5filmydhoom.com
Email: filmydhoom@proton.me, abuse@spaceship.com
378. 5movierulz.best
Email: abuse@name.com, abuse@name.com
379. 7hitmovies.support
Email:

abuse@namecheap.com,

d76bb948d43d4fadaa1f2462469b6033.protect

@withheldforprivacy.com
380. 9xflix.cool
Email: 9xflix@protonmail.com, abuse@namecheap.com
381. 9xmovies.ad
Email : 9xmovies.com@gmail.com, abuse@namecheap.com
382. 9xmovies.com.ng
Email: 9xmovies2025@gmail.com, rajsharma078778@gmail.com
383. 9xmoviess.top
Email: abuse@spaceship.com
384. afilmyhit.info.in
Email: afilmyhit.com@gmail.com
385. alphatron.tv
Email: support@namesilo.com, abuse@namesilo.com
386. bdhdmusic23.fun
Email:
6179670838a14c909a454c83a7c467a8.protect@withheldforprivacy.com,
abuse@namecheap.com
387. bdhdmusic23x.fun
Email: BDHDMUSIC23@gmail.com, abuse@namecheap.com
388. bollymod.mom
Email: abuse@spaceship.com
389. cinedokan.top
Email: cinedokan@gmail.com, abuse@namesilo.com

<!-- page 48 -->

390. ddrmovies.studio

55

Email: abuse@porkbun.com
391. desiremovies.haus
Email: domainabuse@tucows.com
392. desiremoviess.lat
Email: abuse@spaceship.com
393. enjoyserial.com
Email: : cad75be7c3574d9287bf19cc10758a77.protect@withheldforprivacy.com,
abuse@namecheap.com
394. extramovies.cx
Email: extracloud786@gmail.com, abuse@key-systems.net
395. filmlinks4u.one
Email:
0e312ce8b6284dc7a59b58185bfc3464.protect@withheldforprivacy.com,
abuse@namecheap.com
396. filmyfly.capetown
Email: admin@filmyfly.net, domainabuse@tucows.com
397. filmyfly.dr.in
Email: abuse@dynadot.com
398. filmyworld.my
Email: abuse@spaceship.com
399. filmyzilla4.com
Email: filmyzilla.my@proton.me, abuse@internet.bs
400. freecouchtuner.com
Email: support@freecouchtuner.com, abuse@godaddy.com
401. full4movies.delivery
Email:
05f22df783564277963202ba2f6517c8.protect@withheldforprivacy.com,
abuse@namecheap.com
402. hdhub.wiki
Email: abuse@spaceship.com

<!-- page 49 -->

56

403. hdhub4u.is
Email : isnic@isnic.is
404. hdmovie2.faith
Email: abuse@spaceship.com
405. hdmovie2.ninja
Email: abuse@namecheap.com
406. hindilinks4u.express
Email:

f2f5be880c8b423eaab23caebb45cd44.protect@withheldforprivacy.com,

abuse@namecheap.com
407. katmoviehd.biz.pl
Email: abuse@dynadot.com
408. kmmovies.site
Email: tobyjoneswebmaster@gmail.com, abuse@spaceship.com
409. lodynet.io
Email: abuse@name.com
410. m.ssrmovies.capetown
Email: ssrmovies-dmca@proton.me, nicrelations@opensrs.com
411. megamovies.wiki
Email:

b1fddcc3fe744641aecd457a058767fa.protect@withheldforprivacy.com

,

abuse@namecheap.com
412. movies4u.cash
Email: movies4ujp@proton.me, abuse@spaceship.com
413. moviescounter.info
Email:

d12b90096124424db065a04a7f1d8449.protect@withheldforprivacy.com,

abuse@namecheap.com
414. movieshere4u.online
Email: copyright@filmy4wap.ml, abuse@spaceship.com
415. moviesrush.today
Email: f0fwmu7r@anonaddy.me, abuse@namecheap.com
416. movieverse4u.store
Email: abuse@namecheap.com

<!-- page 50 -->

57

417. moviezguru.today
Email:

e521f59a8aa14bc89dd292544687c41f.protect@withheldforprivacy.com,

abuse@namecheap.com
418. mp4moviez.dog
Email: admin@mp4moviez.in, abuse@namecheap.com
419. skymovieshd.up.in
Email: sfilmywapin@gmail.com, abuse@dynadot.com
420. tamildhooltv.com
Email:

tanjkn9uucg6ve3@proxy.dreamhost.com,

domain-

abuse@DREAMHOST.COM
421. themoviesflix.im
Email: jsalldmca@gmail.com, imdomainadmin@nic.im
422. vegamovies.sarl
Email: abuse@spaceship.com
423. vegamovies4u.life
Email:

a007862767b64cedb1ed90bfdee8fd26.protect@withheldforprivacy.com,

abuse@namecheap.com
424. vegamoviese.com.in
Email: contact@vegamoviez.com.in, abuse@dynadot.com
425. vegamoviess.skin
Email: myteam0006@gmail.com, abuse@spaceship.com
426. watchmovierulz.dad
Email: abuse@name.com
427. ww4.0123movies.live
Email: abuse@namecheap.com, movies123.bz@outlook.com
428. ww4.123movies.com.pk
Email: ashar@pknic.net.pk, staff@pknic.net.pk
429. yodesi.org
Email: abuse-contact@sav.com, SUPPORT@sav.com
430. ISNIC
Katrinartuni 2, 18th floor

<!-- page 51 -->

105 Reykjavik, Iceland

58

Email : isnic@isnic.is
431. Dreamhost LLC
417 Associated Rd # 327
CA, 92821
United States
Email: Domain-abuse@DREAMHOST.COM
432. wwv1.4movierulz.io
Email: 155cadfc55b44384a9952d7cb0b17660.protect@withheldforprivacy.com,
abuse@namecheap.com
433. yomovies.report
Email: df0c7e5fcd2547b9a9f5b79b10245860.protect@withheldforprivacy.com,
abuse@namecheap.com
434. wowmovies.fun
Email: wowmovies.fun@gmail.com, abuse@namecheap.com
435. world4ufree.observer
Email: world4ufree@gmail.com, domainabuse@tucows.com
436. vegamovies7.cc
Email: abuse@spaceship.com
437. www.yrkkhdesiserial.su
Email: support@ardis.ru, iamrizwan.com@gmail.com
438. vegamovies.systems
Email: 19352a989a57453ea9a14c28123bd192.protect@withheldforprivacy.com,
abuse@namecheap.com
439. todaypk.im
Email: contactus001122@gmail.com, imdomainadmin@nic.im
440. thenextplanet.network
Email: TheNextPlanet@protonmail.com, abuse@namecheap.com
441. tamilprint34.art
Email: tamilprint@proton.me, abuse@namecheap.com
442. tamiltvserial.online

<!-- page 52 -->

Email: abuse@hostinger.com,

59

443. ssrmovies.cymru
Email: ssrmovies-dmca@proton.me, compliance@tucows.com
444. swatchseries.is
Email: isnic@isnic.is, iana-contact@isnic.is
445. skymovieshd.market
Email: sfilmywapin@gmail.com, abuse@dynadot.com
446. mp4moviez.condos
Email: admin@mp4moviez.in, abuse@namecheap.com
447. sdmoviespoint.uno
Email: abuse@namecheap.com
448. moviesrock.pl
Email: support@realtimeregister.com
449. moviespapa.parts
Email: moviespapa.com@gmail.com, abuse@namecheap.com
450. moviesjoy.skin
Email: support@namesilo.com
451. movieshunt.world
Email: movieshuntpro@proton.me, abuse@spaceship.com
452. moviesbazar.online
Email: moviesbazarorg@gmail.com, abuse@godaddy.com
453. mlhbd.com
Email:

pwp-56486c47359d854759fcc6e2419b9740@privacyguardian.org,

abuse@namesilo.com
454. moviedubbed4u.in
Email: abuse@hostinger.com
455. movies4u.ac
Email:

688904ff1ea743268fe1b86d74a5e42e.protect@withheldforprivacy.com,

abuse@namecheap.com
456. mkvmoviespoint.yatchs
Email: myteam0006@gmail.com, abuse@spaceship.com

<!-- page 53 -->

457. 1movierulzhd.my
Email: admin@movierulzhd.com, dnsadmin@mynic.my
458. 1moviesfd.lol
Email: abuse@namecheap.com
459. 5movierulz.online
Email: 4movierulz.se@protonmail.com, abuse@nicenic.net
460. 7hitmovies.watch
Email: abuse@namecheap.com
461. 7starhd.contact
Email: 7starhd.com@gmail.com, abuse@namecheap.com
462. 7starhd.cymru
Email: 9xmoviewin@gmail.com, abuse@namecheap.com
463. 7starhd.fund
Email: 7starhd.com@gmail.com, abuse@name.com
464. 7starhd.gg
Email: jsalldmca@gmail.com, abuse@namecheap.com
465. 9xmovies.vc
Email: 9xmovies.com@gmail.com, abuse@dynadot.com
466. 9xmoviies.xyz
Email: azanssg42@gmail.com, abuse@porkbun.com
467. bdmusic23.love
Email: support@namesilo.com
468. brahmamudiserial.today
Email: contact@privacyprotect.org, abuse@hostinger.com
469. deewaniyat.net
Email: abuse@dynadot.com
470. desicinema.org
Email: abuse@name.com
471. downloadhub4u.today
Email: abuse@namecheap.com
472. mkvcinemas.phd

60

<!-- page 54 -->

Email: domainabuse@tucows.com

61

473. hdmovies23.homes
Email: bdmusic23life@gmail.com, abuse@namecheap.com
474. hdmovies4u.tw
Email: hdmovies4u@protonmail.com, tw-admin@twnic.tw
475. hdmoviearea.my
Email: myteam0006@gmail.com, abuse@spaceship.com
476. hdmovie4u.my
Email: myteam0006@gmail.com, abuse@spaceship.com
477. hdmovie2.cymru
Email: abuse@spaceship.com
478. 11xmovies.pics
Email: bdmusic23life@gmail.com, abuse@namesilo.com
479. hdking.run
Email:

pwp-6f5498cdcefcc6ddab65ef8916da1aae@privacyguardian.org,

abuse@namesilo.com
480. hdhub4u.promo
Email:

c4158771aefd43a182a075a9b8b2926e.protect@withheldforprivacy.com,

abuse@namecheap.com
481. dudefilms.diy
Email: abuse@namecheap.com, partners@inaming.co
482. extramovies.aisa
Email: Extramovies.asia@gmail.com, abuse@namecheap.com
483. filmyhit.team
Email: contact@privacyprotect.org, abuse@hostinger.com
484. fmovies.gifts
Email: abuse@porkbun.com
485. hdhub4one.me
Email: abuse@porkbun.com
486. ARDIS-SU
236010, Kaliningrad, Tenistaya alley str., 18

<!-- page 55 -->

INN:3906244121
Email: support@ardis.ru,
487. MYNIC
Level 3, Tower 2, Menara Cyber Axis,
Jalan Impact, 63000 Cyberjaya,
Selangor Darul Ehsan,
Malaysia
Email: customercare@mynic.my
488. NICENIC International Group Co. Ltd.
Room 1704 Hang Lung Center Paterson Street,
Causeway Bay, Hong Kong.
Email: support@nicenic.net
489. TWNIC
3F., No. 123, Sec. 4,
Bade Rd., Songshan Dist.,
Taipei 105, Taiwan
Email: ia@twnic.net.tw
490. Nic.diy
23 Lime Tree Bay,
West Bay Grand Cayman,
Cayman Islands KY1-1505
Email: abuse@inaming.co
491. yodesirulez.org
Email: abuse@registrar.eu
492. yomoviess.club
Email: myteam0006@gmail.com, abuse@spaceship.com
493. world4ufree.my
Email: myteam0006@gmail.com, abuse@spaceship.com
494. vegamoviese.my
Email: contact@vegamoviez.com.in, info@dynadot.com
495. vegamoviess.rest

62

<!-- page 56 -->

Email: myteam0006@gmail.com, abuse@spaceship.com

63

496. vegamovies7.foo
Email: abuse@spaceship.com
497. themoviesflix.tc
Email: jsalldmca@gmail.com, info@nic.tc
498. vega-movies.capetown
Email: admin@vegamovies.co.za, nicrelations@opensrs.com
499. thekhatrimaza.band
Email: thekhatrimaza@protonmail.com, abuse@namecheap.com
500. thekhatrimaza.tc
Email: jsalldmca@gmail.com, info@nic.tc
501. serialmaza.info
Email: copyright@serialghar.co, abuse@dynadot.com
502. skymovieshd.li
Email: skymoviesHD.in@gmail.com, dns-operatio@switch.ch
503. pogolinks.wiki
Email: abuse@namecheap.com
504. new.movielinkbd.live
Email: abuse@spaceship.com
505. mp4moviez.tennis
Email: admin@mp4moviez.in, abuse@namecheap.com
506. moviesnation.email
Email: support@namesilo.com
507. moviezguru.digital
Email: abuse@namecheap.com
508. movierulzin.com
Email: dmca@streamango.com, abuse@namesilo.com
509. movies-mod.art
Email: myteam0006@gmail.com, abuse@spaceship.com
510. mkvfun.org
Email: : d70fdc9a0fc94a45a6c736f71df09dfc.protect@withheldforprivacy.com,

<!-- page 57 -->

abuse@namecheap.com

64

511. latesthdmovies.men
Email: abuse@porkbun.com
512. meghabarsengetv.com
Email: abuse@spaceship.com
513. khatrimazafull.cfd
Email: contactmaza@protonmail.com, abuse@namecheap.com
514. hdking.men
Email: support@namesilo.com
515. katmovie.mom
Email: myteam0006@gmail.com, abuse@spaceship.com
516. full4movies.food
Email: abuse@namecheap.com
517. hdhub.baby
Email: abuse@spaceship.com
518. filmycity.email
Email: myfilmycity@gmail.com, contact@privacyprotect.org
519. filmyworlds.autos
Email: filmyworld111@proton.me, abuse@namecheap.com
520. filmycab.bond
Email: abuse@namecheap.com
521. dudefilms.work
Email: abuse@namecheap.com
522. f2movies.watch
Email: abuse@namecheap.com
523. cinemaluxe.cam
Email: : jsrthhjrsthhf.untouched693@passinbox.com, abuse@spaceship.com
524. desitellybox.to
Email: desitvbox@yahoo.com, egullich@colo.to
525. bolly4you.art
Email: myteam0006@gmail.com, abuse@spaceship.com

<!-- page 58 -->

526. bollymod.rest
Email: abuse@namecheap.com
527. bflixtv.org
Email: abuse@dynadot.com
528. biggboss18watch.com
Email: daniakhan8586@gmail.com, abuse@netim.net
529. allmovieshub.team
Email: domain@apiname.com
530. anupama.vip
Email: abuse@namecheap.com
531. 9xmoviess.my
Email: myteam0006@gmail.com, abuse@spaceship.com
532. afilmyhit.internet.in
Email: afilmyhit@gmail.com
533. 9xmovies.luxe
Email: abuse@spaceship.com
534. 9xmovies.cv
Email: 9xmovies.com@gmail.com, jseales@dynadot.com
535. 9xmovie.review
Email: azanssg42@gmail.com, abuse@spaceship.com
536. 9xmovies.com.sc
Email: 9xmovies2025@gmail.com, abuse@dynadot.com
537. 9xflix.mov
Email: 9xflix@protonmail.com, domainabuse@tucows.com
538. 7starhd.by
Email: jsalldmca@gmail.com
539. 7starhd.lgbt
Email: 7starhd.com@gmail.com, abuse@spaceship.com
540. 5movierulz2.day
Email: domainabuse@tucows.com
541. NICTC

65

<!-- page 59 -->

P.O. Box 599, Level 2,

66

Le Vele Plaza, Grace Bay,
Providenciales, Turks & Caicos islands, B.W.I.
Email : info@nic.tc
542. Nic.li
P.O.Box
CH-8021 Zurich, Switzerland
Email: registry@nic.ch
543. Tonic.to
1350 Bayshore Hwy
Suite 610
Burlingame, CA, 94010
Email: hostmaster@tonic.to , stopspam@tonic.to
544. Atak Domain Bilgi Teknolojileri A.S.
İstasyon, Efe Sadık Cd. No: 4 İç Kapı
No: 2, 41400 Kartepe/Kocaeli
Email:

domain@apiname.com,

domain@atakdomain.com
545. TriIncom Ltd
Vitebsk region, Novopolotsk, ul.
Yubileynaya, house 2A, office 308
Email: info@hb.by
546. 123moviesfree9.pro
Email: abuse@namecheap.com
547. moviesfd.mom
Email: abuse@namecheap.com
548. movierulz.vu
Email: abuse@dynadot.com
549. starhd.so
Email: jsalldmca@gmail.com, registry@dynadot.com
550. 7starmv.xyz

complaint@atakdomain.com,

<!-- page 60 -->

Email: 720pflix.com@gmail.com, abuse@namecheap.com

67

551. 8xmovies.org
Email: 8xmovies@gmail.com, abuse@spaceship.com
552. 720pflix.homes
Email: 720pflix.com@gmail.com, abuse@namecheap.com
553. 9xmovies.com.pr
Email: 9xmovies2025@gmail.com, abuse@dynadot.com
554. 9xsmovies.com
Email: azanssg42@gmail.com, abuse@spaceship.com
555. a1movies.space
Email: a1moviesvip@proton.me, abuse@namecheap.com
556. allmovieshub.name
Email: abuse@namecheap.com,
a42c418992c24974870eb1fda4162c90.protect@withheldf orprivacy.com
557. bolly4you.mom
Email: myteam0006@gmail.com, abuse@spaceship.com
558. bollyflix.co.nz
Email: bollyflix@protonmail.com
559. desi-serial.su
Email: support@regtime.net, leaderhayan@gmail.com
560. desitashan.app
Email: abuse-contact@sav.com
561. dotmoviess.mom
Email: myteam0006@gmail.com, abuse@spaceship.com
562. downloadhub.how
Email: compliance@tucows.com, domainabuse@tucows.com
563. dudefilms.baby
Email: abuse@namecheap.com
564. filmyhit.cafe
Email: domain@apiname.com,domain@apiname.com
565. filmywap.com.af

<!-- page 61 -->

Email: filmywap.contact@proton.me, info@subreg.cz
566. filmyworld.cyou
Email: myteam0006@gmail.com, abuse@spaceship.com
567. filmyworlds.pwdwb.in
Email: Filmyworld111@proton.me
568. filmyzilla.net.bz
Email: abuse-zilla@proton.me, abuse@key-systems.net
569. hdmovie2.doctor
Email: abuse@spaceship.com
570. hdmovie2.group
Email: abuse@namecheap.com
571. hdmovie2.is
Email: isnic@isnic.is, iana-contact@isnic.is
572. hdmovie2.wiki
Email: abuse@spaceship.com
573. hdmoviehub.mobi
Email:hdmoviehubforall@gmail.com, abuse@spaceship.com
574. ibomma.baby
Email: abuse@dynadot.com
575. katmovie.hair
Email: myteam0006@gmail.com, abuse@spaceship.com
576. kmmovies.club
Email: tobyjoneswebmaster@gmail.com, abuse@spaceship.com
577. latesthdmovies.party
Email: abuse@porkbun.com
578. luxmoviess.top
Email: myteam0006@gmail.com, abuse@spaceship.com
579. mkvcinemas.moe
Email: compliance@tucows.com
580. movies4u.id
Email: info@belidomain.co.id

68

<!-- page 62 -->

581. movies4u.plus
Email: movies4ujp@proton.me, abuse@spaceship.com
582. movieshunt.club
Email: movieshuntpro@proton.me, abuse@spaceship.com
583. moviespapa.cash
Email: moviespapa.com@gmail.com, abuse@dynadot.com
584. moviezguru.coupons
Email: abuse@namecheap.com
585. moviezwap.diy
Email: moviezwaphd@protonmail.com
586. mp4moviez.pub
Email: admin@mp4moviez.in, abuse@name.com
587. ofilmyzilla.phd
Email: ofilmyzilla.com@gmail.com, abuse@dynadot.com
588. skymovieshd.how
Email: sfilmywapin@gmail.com, abuse@dynadot.com
589. ssrmovies.qpon
Email: ssrmovies-dmca@proton.me, abuse@name.com
590. tamilaruvi.tv
Email: abuse@registrar.eu,
591. tamilprint35.art
Email: tamilprint@proton.me, abuse@namecheap.com
592. thevegamovies.by
Email: jsalldmca@gmail.com
593. vegamovies.uz
Email: voiseries@protonmail.com
594. watchmovierulz.foo
Email: abuse@name.com
595. worldfree4u.cab
Email: worldfreeuindin@gmail.com, abuse@namecheap.com
596. ww3.movierulz.wf

69

<!-- page 63 -->

Email: dmcamovierulz@gmail.com, info@ptstrustee.com

70

597. Gransy s.r.o.
Borivojova 878/35
130000 Prague
Czech Republic
Email: info@subreg.cz
598. PT Jagat Informasi Solusi (int)
Indosurya Plaza Lantai 3A,
Jalan Muhammad Husni Thamrin nomor 8-9
JAKARTA PUSAT
Email: info@belidomain.co.id
599. INSTRA CORPORATION PTY LTD
GPO BOX 988
Melbourne
Victoria, Australia, 3001
Email: registry_admin@instra.com
600. 7starhd.is
Email: jsalldmca@gmail.com
601. 1moviesfd.autos
Email: 6d7e5d97bdaf4b95a533c8967631a690.protect@withheldforprivacy.com
602. 9xmovies.hockey
Email: 9xmovies.com@gmail.com
603. 9xmoviies.art
Email: azanssg42@gmail.com
604. 9xmoviies.shop
Email: 9xmovies@gmail.com
605. bolly4u.moe
Email: bolly4u.info@gmail.com
606. bolly4you.biz
Email: myteam0006@gmail.com

<!-- page 64 -->

607. bolly-flix.biz

71

Email: myteam0006@gmal.com
608. afilmyhit.monster
Email: myteam0006@gmail.com
609. bdmusic23.boats
Email: bdmusic23life@gmail.com
610. desiremovies.how
Email: compliance@tucows.com
611. desiserials.li
Email: abuse@registrar.eu
612. dotmoviess.club
Email: myteam0006@gmail.com
613. downloadhub.rsvp
Email: 60b150ad6de44ca9b41f76ac70d556b5.protect@withheldforprivacy.com
614. filmy4z.site
Email: admin@filmy.net
615. filmyfly.moi
Email: admin@filmyfly.net
616. filmygod.beauty
Email: myteam0006@gmail.com
617. filmy-hunk.com
Email: abuse@registrar.eu
618. filmyzerox.com
Email: info@filmyzerox.in
619. filmyzilla.net.vc
Email: filmyzilla2024@proton.me
620. giboss.com
Email: support@giboss.com
621. hdmovies2.best
Email: abuse@spaceship.com

<!-- page 65 -->

622. hdmovies2.capital

72

Email: abuse@dynadot.com
623. hdmovies2.ms
Email: info@key-systems.net
624. issishqkarabrakha.com
Email: abuse@spaceship.com
625. kmmovies.click
Email: tobyjoneswebmaster@gmail.com
626. llodynet.bond
Email: admin@llodynet.bond
627. lodynet.nl
Email: abuse@namecheap.com
628. maatisebandhidor.net
Email: abuse@dynadot.com
629. mkvmoviespoints.autos
Email: myteam0006@gmail.com
630. movies4u.mx
Email: 5cde3b26b6cd43788b738e785bbfd1f7.protect@withheldforprivacy.com
631. movies4you.mom
Email: myteam006@gmail.com
632. moviespapa.cz
Email: moviespapa.com@gmail.com
633. moviezguru.cam
Email: dmca@namecheap.com
634. pika-show.org
Email: abuse@dynadot.com
635. pocketmeinaasman.net
Email: abuse@dynadot.com
636. ssrmoviess.mom
Email: myteam0006@gmail.com

<!-- page 66 -->

637. sumanindoriserial.net
Email: Dynadot Abuse Dept abuse@dynadot.com
638. tenalirama2.net
Email: abuse@spaceship.com
639. uwatchfree.homes
Email: myteam0006@gmail.com
640. vasudhaseria.net
Email: abuse@spaceship.com
641. vegamovies-nl.life
Email: bunny2005.pr@gmail.com
642. vegamoviess.life
Email: abuse@godaddy.com
643. 2vv.yodesitv.org
Email: abuse@registrar.eu
644. 3movierulz.live
Email: dmca@streamtape.com
645. 5movierulz.tel
Email: Dynadot Abuse Dept abuse@dynadot.com
646. 7starhd.com.cv
Email: 7starhd.com@gmail.com
647. 7starhd.club
Email: 7starhd.com@gmail.com
648. 9kmovies.fish
Email: 9kmovies.com@gmail.com
649. 9xmovie.voto
Email: azanssg42@gmail.com
650. 9xmovies.loan
Email: 9xmovies.site@gmail.com
651. 9xmoviess.biz
Email: myteam0006@gmail.com

73

<!-- page 67 -->

652. 10hitmovies.pro

74

Email: 10hitmovies@gmail.com
653. apnetv.li
Email: info@switch.ch
654. bolly4u.vc
Email: dmca@namecheap.com
655. desirulez.org
Email: admin@privacy.ccireg.com
656. dopebox.to
Email: hostmaster@tonic.to
657. dudefilms.ws
Email: 9e87a6bb5df04683b5664cbe5e6a985.protect@withheldforprivacy.com
658. filmybuff.space
Email: movieforest4k@gmail.com
659. filmyhit.up.in
Email: afilmyhit.com@gmail.com
660. full4movies.markets
Email: fee25a99e23a4c4ba66819dac28310af.protect@withheldforprivacy.com
661. hdhub4u.loans
Email: hdhub4u@protonmail.com
662. hdking.press
Email: 732617f3e66b5066c7f15843c6f1d16e@privacyguardian.org
663. hdmoviearea.makeup
Email: myteam0006@gmail.com
664. hindilinks4u.living
Email: 59a85cb96b634c4095fe6b7c061c1392.protect@withheldforprivacy.com
665. jaaduterinazar.net
Email: Dynadot Abuse Dept abuse@dynadot.com
666. luxecinema.fans
Email: domainabuse@tucows.com

<!-- page 68 -->

667. mannatserial.net

75

Email: Dynadot Abuse Dept abuse@dynadot.com
668. moviediskhd.online
Email: moviediskhd@proton.me
669. mp4movies.makeup
Email: myteam0006@gmail.com
670. neelive.com
Email: neelive@proton.me
671. pogolinks.lat
Email: 7ba7e1ebb5d24c5fb3df4c9fe437bdd9.protect@withheldforprivacy.com
672. poovalan.blog
Email: abuse@hostinger.com
673. solarmovies.ms
Email: abuse@sarek.fi
674. southfreaks.xyz
Email: rashedvlog8@gmail.com
675. ssrmovies.pm
Email: ssrmovies-dmca@proton.me
676. themoviesflix.am
Email: jsalldmca@gmail.com
677. thenextplanet.coupons
Email: thenextplanet@protonmail.com
678. thevegamovies.ru
Email: jsalldmca@gmail.com
679. topmovies.nexus
Email: domainabuse@tucows.com
680. tvids.tv
Email: admin@tvids.tv
681. updatetamila.com
Email: inthamizha30@gmail.com

<!-- page 69 -->

682. vegamovies7.ch

76

Dynadot Abuse Dept abuse@dynadot.com
683. vegamoviese.fit
Email: dmca@vegamiviese.fit
684. vegamoviese.pro
Email: contact@vegamoviez.com.in
685. vegamoviess.beauty
Email: myteam0006@gmail.com
686. watch4freemovies.com
Email: dbdd823e3ba5451eb415341c78597a41.protect@withheldforprivacy.com
687. watchmovierulz.men
Email: abuse@nicenic.net
688. watchseries.mn
Email: domainabuse@tucows.com
689. watchsomuch.tv
Email: abuse@joker.com
690. watch-tvseries.tv
Email: admin@watch-tvseries.tv
691. world4ufree.fyi
Email: world4ufree@gmail.com
692. world4ufree.rest
Email: myteam0006@gmail.com
693. wowmovies.cfd
Email: wowmovies.fun@gmail.com
694. yomovies.land
Email: 51451be941764b2797ce0d755dc80945.protect@withheldforprivacy.com
695. yomoviess.biz
Email: myteam0006@gmail.com
696. CCI REG S.A.
Torre Global Bank

<!-- page 70 -->

77

Piso21Ofc21C
Panama, Panama
Email: admin@ccireg.com
697. abcdomain (ABCDOMAIN LLC)
1 apt. 4 Adonc, Yerevan 0014, Armenia
Email: info@internet.am
698. CSL Computer Service Langenbach GmbH d/b/a jocker.com
Hansaallee 191-193,
40549 Dusseldorf,
Germany
Email: sales@cls.de

…Defendants

699. 1cinevood.cool
Email: c38a2cc9731843fe9fabfba557a0d2ed.protect@withheldforprivacy.com
700. 1moviesfd.boats
Email: abuse@namecheap.com
701. 1shows.com
Email: ef436edf9b344d4589ba91c8de0b4b74.protect@withheldforprivacy.com
702. 5movierulz.ag
Email: abuse@dynadot.com
703. 5movierulz.camp
Email: abuse@dynadot.com
704. 5movierulz.report
Email: 675e1169bd3e46c09931e5905992a14d.protect@withheldforprivacy.com
705. 7filmywap.net
Email: filmywap.connect@proton.me
706. 123moviesfree9.pics
Email: abuse@namecheap.com
707. 720pflix.autos
Email: 720pflix.com@gmail.com
708. 7starhd.hockey
Email: 7starhd.com@gmail.com

<!-- page 71 -->

709. 7starhd.je

78

Email: 7starhd.com@gmail.com
710. 7sttarhd.xyz
Email: azanssg42@gmail.com
711. 9xmovies.limo
Email: 9xmovies.com@gmail.com
712. bdhdmusic23.ink
Email: abuse@namecheap.com
713. bollyflix.gr.com
Email: bollyflix@protonmail.com
714. bolly-flix.store
Email: abuse@spaceship.com
715. ddrmovies.loan
Email: azanssg42@gmail.com
716. downloadhub.moi
Email: domainabuse@tucows.com
717. downloadhubs.top
Email: myteam0006@gmail.com
718. extramovies.coupons
Email: extramovies.top@gmail.com
719. filmy4wap.bar
Email: voiseries@protonmail.com
720. filmycab.shop
Email: abuse@namecheap.com
721. fmovies24-to.com
Email: compliance@tucows.com
722. full4movies.coupons
Email: e75a6de2a11d49508c4dc5f9526c035a.protect@withheldforprivacy.com
723. fullymaza.autos
Email: pwp-1dce4af0add6100fd7d92cb1cd64888f@privacyguardian.org

<!-- page 72 -->

724. hdmovies23.monster

79

Email: bdmusic23life@gmail.com
725. hindilinks4u.email
Email: 44aeb22f6d1642899ba75b0574feb3ce.protect@withheldforprivacy.com
726. jalshamoviez.am.in
Email: jalshamoviez123@gmail.com
727. khatri-maza.biz
Email: myteam0006@gmail.com
728. kmmovies.biz
Email: tobyjoneswebmaster@gmail.com
729. moviesrock.dog
Email: domain@apiname.com
730. moviezguru.best
Email: 89fed7b8c06a446e8f9142ccb4b917c9.protect@withheldforprivacy.com
731. moviezwap.dad
Email: moviezwaphd@gmail.com
732. sdmovies-point.mom
Email: myteam0006@gmail.com
733. skymovieshd.farm
Email: skymoviesHD.in@gmail.com
734. techyinformer.in
Email: techyinformer12544@gmail.com
735. uhdmovies.top
Email: voiterranova@protonmail.com
736. vegamovies.energy
Email: 98297e22bd1c4321a9f91c4302b3a059.protect@withheldforprivacy.com
737. vegamoviies.biz
Email: voiseries@protonmail.com
738. watch5movierulz.cc
Email: dbb2cafa36b947ff9f03b02c5623b1f1.protect@withheldforprivacy.com

<!-- page 73 -->

80

739. watchmovierulz.uno
Email: abuse@nicenic.net
740. wlext.is
Email: WLEXT@tuta.io
741. ydesiserials.com
Email: abuse@spaceship.com
742. OVI HOSTING PVT LTD

#505, 1st Stage, 4th Block Extension,
BDA Layout, HBR Layout, Bengaluru-560043.
Email:finance@hostingraja.in

Place: New Delhi
Date: 20.03.2025

…Defendants

Yatinder Garg | Rimjhim Tiwari | Ishi Singh
(D/1330/2015) |(D/4021/2022) | (D/1977/ 2024)
Saikrishna and Associates
Advocates for the Plaintiffs
57 Jor Bagh, First Floor,
New Delhi, 110003

<!-- page 74 -->

$~15
*
IN THE HIGH COURT OF DELHI AT NEW DELHI
+

CS(COMM) 809/2024
STAR INDIA PVT LTD
Through:

.....Plaintiff
Mr. Siddharth Chopra, Mr. Yatinder
Garg, Ms. R. Tiwari and Ms. Ishi
Singh, Advocates

Versus
VEGAMOVIES.PET & ORS.
.....Defendants
Through: Mr. Mrinal Ojha, Mr. Debarshi
Dutta, Mr. Arjun Mookerjee and
Mr. Samyak Bilal, Advocates for
D-24
CORAM:
HON'BLE MR. JUSTICE SAURABH BANERJEE
ORDER
%
20.09.2024
I.A. 39806/2024 (pre-litigation mediation)
1.

The plaintiff vide the present application seeks exemption from

instituting pre-litigation mediation.
2.

Considering the averments made in the present application wherein

the plaintiff seeks urgent ad-interim reliefs and in view of Yamini
Manohar vs. T.K.D. Krithi 2023 SCC OnLine 1382 and Chandra Kishore
Chaurasia vs. R. A. Perfumery Works Private Limited 2022:DHC:4454DB, the plaintiff is exempted from instituting pre-litigation mediation.
3.

Accordingly, the present application is allowed and disposed of.

I.A. 39803/2024 (exemption)
4.

Exemption allowed as sought, subject to all just exceptions.

5.

The application stands disposed of.

CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Page 1 of 15

<!-- page 75 -->

I.A. 39804/2024 (under Section 80 CPC)
6.

This is an application seeking exemption from serving notice under

Section 80(2) of the Code of Civil Procedure, 1908(CPC) to exempt the
plaintiff from issuing notice to the defendant no.44, Department of
Telecommunications (‘DoT’) and defendant no.45, the Ministry of
Electronics and Information Technology (‘MEITY’) under Section 80 of
the CPC, as the relief being claimed against the said defendants is limited
to ensure compliance of any orders of this Court in favour of the plaintiff.
7.

For the reasons stated in the application and the arguments

advanced by the learned counsel for the plaintiff, the present application is
allowed.
8.

Accordingly, the present application is disposed of.

I.A. 39805/2024 (additional documents)
9.

The plaintiff vide the present application seeks time of thirty days to

file additional documents.
10.

For the reasons stated in the application and the arguments

advanced by the learned counsel for the plaintiff, the present application is
allowed, the plaintiff will be at liberty to file additional documents within
thirty days, albeit, strictly as per the provisions of the Commercial Courts
Act, 2015 and Delhi High Court (Original Side) Rules, 2018.
11.

Accordingly, the present application is disposed of.

CS(COMM) 809/2024
12.

The plaintiff by way of the present suit seeks permanent injunction

restraining defendants engaged in infringing the plaintiff’s exclusive rights
and copyrights and for rendition of accounts, damages, etc.
13.

Let the plaint be registered as a suit.

CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Page 2 of 15

<!-- page 76 -->

14.

Upon filing of the process fee, issue summons of the suit to the

defendants through all permissible modes returnable before the Joint
Registrar on 18.12.2024.
15.

The summons shall state that the written statement(s) be filed by the

defendants within a period of thirty days from the date of the receipt of the
summons. Written statement(s) be filed by the defendants along with
affidavit(s) of admission/ denial of documents of the plaintiff, without
which the written statement(s) shall not be taken on record.
16.

Replication thereto, if any, be filed by the plaintiff within a period

of fifteen days from the date of receipt of written statement(s). The said
replication, if any, shall be accompanied by with affidavit(s) of admission/
denial of documents filed by the defendants, without which the replication
shall not be taken on record within the aforesaid period of fifteen days.
17.

If any of the parties wish to seek inspection of any document(s), the

same shall be sought and given within the requisite timelines.
18.

List before the Joint Registrar for completion of pleadings on

18.12.2024. It is made clear that if any party unjustifiably denies any
document(s), then it would be liable to be burdened with costs.
19.

List before the Court on 27.01.2025.

I.A. 39802/2024-Stay (Order XXXIX rule 1 & 2 CPC, 1908)
20.

The plaintiff seeks an injunction restraining the defendant nos.1-23

from hosting, streaming, reproducing, distributing, making available to the
public and/ or communicating to the public, or facilitating the same, on
their websites, through the internet in any manner whatsoever, any
cinematograph work/ content/ programme/ television show to which the
plaintiff has a copyright and to block access to the defendant nos.1-23
CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Page 3 of 15

<!-- page 77 -->

websites identified by the plaintiff in the instant suit.
21.

As per the pleadings and after hearing arguments of the learned

counsel for the plaintiff, the following emerge:21.1. The plaintiff namely, Star India Private Limited, is the owner of
content. Plaintiff claims to be leading entertainment and media company
in India and is engaged in the business of production of popular content,
broadcast on its Star channels and online platform Disney+Hotstar.
21.2. Novi Digital Entertainment Private Limited has merged with the
plaintiff, i.e., Star India Private Limited, as on 27.05.2024 and all rights,
interests, and liabilities of Novi Digital Entertainment Pvt. Ltd. stand
transferred to and vested in Star India Private Limited. Thus, all the
references to the Novi are attributed to Star India Private Limited.
21.3. The Star channels and the content aired therein occupy a
commanding position and have acquired tremendous goodwill and
reputation in the entertainment industry and amongst the people.
21.4. Disney+ Hotstar currently offers the widest range of content in
India on Disney+ Hotstar offers over 100,000 hours of TV shows and
movies across 8 languages, Disney+ originals, latest American shows,
blockbuster Hollywood movies and content from international studios,
exclusive new content from the Hotstar Specials label, regional and
national news, and coverage of every major global sporting event. As per
the Axis My India report of December 2023, Disney+ Hotstar is the
preferred choice for majority of the OTT viewers.
21.5. The works created by plaintiff include sound recordings
accompanied with visuals and qualify as cinematograph film under
Section 2(f) of the Copyright Act, 1957 (the Act) and, therefore, are
CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Page 4 of 15

<!-- page 78 -->

entitled to protection by virtue of Section 13(1) read with Sections 13(2)
and (5) of the Act.
21.6. The content in question, in this application is cinematograph films
(plaintiff’s’ works), an illustrative list of which included in the plaint are
extracted as under:-

S.
Name of the Plaintiff’s
No.
Content
1.
Special Ops

S.
No.
22.

2.
3.

23.
24.

4.
5.
6.
7.
8.
9.
10.

Life Hill Gayi
The Legend of Hanuman
(all seasons)
Lootere
Koffee
with
Karan
(allseasons)
Ghar Wapsi
The Freelancer
Aakhri Sach
Aarya (all seasons)

14.

City of Dreams
seasons)
Taaza Khabar
Human
Criminal
Justice
seasons)
Showtime

15.
16.
17.
18.
19.

Saas Bahu aur Flamingo
Brahma Mudi
Anurager Choowa
Bodhua
Roshnai

11.
12.
13.

25.
26.
27.
28.
29.
30.

(all 31.
32.
33.
(all 34.
35.
36.
37.
38.
39.
40.

CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Name of the Plaintiff’s
Content
Gunde
Ninda
GudiGantalu
Guppedantha Manasu
Karthika Deepam
Nuvvu Nenu Prema
Nagendrans
Honeymoons
Bad Cops
Anupamaa
10:29 ki Aakhri Dastak
Ghum Hai Kisikey
Pyaar Mei
Jhanak
Shaitani Rasmein
Teri Meri Dooriyan
Yeh Rishta Kya Kehlata
Hai
Commander
Karan
Saxena
Bigg Boss Telugu
Aaha Kalyanam
Baakiyalakshmi
Chinna Marumagal
Mahanandhi
Page 5 of 15

<!-- page 79 -->

20.
21.

Bigg Boss Malyalam
Bigg Boss Tamil

41.
42.

Pandian Stores
Aaha Kalyanam

21.7. The plaintiff, therefore, claim to have exclusive rights under Section
14(d) read with Section 17 of the Act.
21.8. Grievance of plaintiff is against defendant nos.1-23 who are hosting
and operating the respective domain names/websites (infringing domains/
websites) tabulated by plaintiff are extracted as under:S. No.

Website Names

1

vegamovies.pet

2

filmywap.rest

3

luxmovies.lol

4

movies4u.diy

5

manaletelugumovies.cc

6

new1themoviespalace.online

7

prmovies.food

8

movies4u.fun

9

gogodramas.su

10

extramovies.my

11

hdmovie2.id

12

flixerabd.store

13

hdmovies23.help

14

11xmovies.lat

15

hdmovie22.com

16

ajker.in 220,157

17

mkvin.skin

CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Page 6 of 15

<!-- page 80 -->

18

0gomovies.cam

19

tamildhool.app

20

anupama.net

21

baalveer.pk

22

tamildhoollll.cc

23

kurumbi.com

21.9. Further, these infringing domains/ websites are carrying and
disseminating content, consisting of plaintiff’s copyrighted works, without
any license or authorization. More than twenty of plaintiff’s works are
being unauthorisedly made available by defendant nos.1-23. Further, legal
notices were sent to these infringing domains/ websites operated by
defendants to take down infringing content. However, none of them have
responded to the said legal notices.
21.10. The defendant nos.24 to 34 are various Domain Name Registrars
(DNRs) through which defendant nos.1-23 websites are registered. They
control access to these websites and are in a position to ensure that access
to these infringing websites is not available.
21.11. Further, defendant nos.35 to 43 are various Internet Service
Providers (ISP) available domestically in India who provide access to
internet in India. They control access to internet and are in a position to
ensure that access to these infringing websites is not available.
21.12. The defendant no.44 is DoT, while defendant no.45 is MEITY,
which forms a part of the Government of India and are the overall
regulators of the internet environment in the country. They have been
called upon for the purpose of ensuring that the ISPs are in compliance
CS(COMM) 809/2024

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 11/11/2024 at 11:09:00

Page 7 of 15
