---
doc_id: "e5a3ae49fa12ccfd"
source_url: "https://mnre.gov.in/static/uploads/2026/01/9046b9b11c00c9dfebb59a98b84bfc43.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "RE-Statistics 2024-25"
date: "2025-12-01"
pages: 121
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b7404674b5a48c2"
---

<!-- page 1 -->

RENEWABLE ENERGY STATISTICS
2024-25

Government of India
Ministry of New & Renewable Energy
Statistics Division

A

<!-- page 2 -->

i

<!-- page 3 -->

ii

<!-- page 4 -->

iii

<!-- page 5 -->

iv

<!-- page 6 -->

v

<!-- page 7 -->

Contents
Sl. No.

CONTENTS

PAGE NO.

Scope & Coverage

1

Introduction

2

Highlights

3-8

ALL INDIA STATUS
INSTALLED CAPACITY
Chapter 1
Chapter 2

Installed Capacity - RE and Non-RE sector
Table 1.1 Cumulative installed capacity since 2014-15
Installed Capacity - Wind, Solar, Small Hydro & Bioenergy (RES)
sector
Table 2.1 Cumulative installed Capacity under RES since 2014-15

10-13
10
14-20
14

ENERGY GENERATION
Chapter 3

Energy Generation - RE and Non-RE sector
21-23
Table 3.1 Year-wise All India Energy Generation since 2014-15
21
Chapter 4
Energy Generation – Wind, Solar, SHP & Bioenergy (RES) sector
24-27
Table 4.1 Year-wise Energy Generation under RES since 2014-15
24
INSTALLED CAPACITY & ENERGY GENERATION DURING -2024-25 and SDG-NIF
Chapter 5

Chapter 6

Monthly Installed Capacity and Electricity Generation during 202425
Table 5.1 Monthly Capacity Addition during 2024-25
Table 5.2 Monthly Sector Wise RE Capacity Addition during 2024-25
Table 5.3 Monthly Electricity Generation during 2024-25
Table 5.4 Monthly Electricity Generation under RES during 2024-25
Sustainable Development Goal-NIF
Table 6.1 SDG – NIF Indicators 7.b.1/12. a.1- Installed renewable energy
generating capacity in the country (in watts per capita)
Table 6.2 SDG Indicator 7.2.1- RE share in the total installed electricity
generation
STATEWISE STATUS

28-30
29
29
30
30
31-33
31
32

POTENTIAL AND INSTALLED CAPACITY
Chapter 7

Estimated RE Potential and Installed Capacity in RE and Non-RE
sector
Table 7.1 Estimated potential in RE sector
Table 7.2 State wise Non-RE and RE Cumulative Installed Capacity as on
31.03.2018 and 31.03.2025

vi

35-38
36
37-38

<!-- page 8 -->

Chapter 8

Installed capacity in RE sector

39-46

Table 8.1 Region wise/State wise RE Cumulative Installed Capacity from
2017-18 to 2024-25
Table 8.2 RE cumulative installed capacity as on 31.03.2025

39-40

Table 8.3 Cumulative installed capacity of bio-power and solar power as
on 31.03.2025
Table 8.4 Installation of Off-grid/Decentralized Renewable Energy Systems/Devices as on 31.03.2025
Table 8.5 Share of RE in cumulative installed capacity as on 31.03.2025

44

43

45
46

ENERGY GENERATION
Chapter 9

Chapter 10

Chapter 11

Chapter 12

Chapter 13

Energy Generation – RE and Non-RE sector

47-49

Table 9.1 Share (%) of RE generation in total Energy Generation during
2024-25
Table 9.2 State-wise Renewable Energy Generation during 2024-25

48

Top 5 States in Renewable Energy Installed Capacity

50-52

10.1 Top 5 states in RE installed capacity and their Contribution in the
Country’s cumulative RE Installed Capacity
10.2 Contribution of various RE sources of top 5 RE installed capacity
states within the respective state’s RE installed capacity
10.3 Contribution of various RE sources of top 5 RE installed capacity
states in RE generation within the respective states
Rajasthan

49
50
51
52
53-59

Table 11.1.1 Installed Capacity under RE and Non-RE sector since 201718
Table 11.2.1 Installed Capacity under Solar, wind, Biopower and Small
Hydro Power (RES) since 2014-15
11.3 Energy Generation during 2024-25

54

Gujarat

60-66

Table 12.1.1 Installed Capacity in RE and Non-RE sector since 2017-18

61

Table 12.2.1: Installed Capacity under Solar, wind, Bio Power and Small
Hydro Power (RES) since 2014-15
12.3 Energy Generation during 2024-25

63

Tamil Nadu

67-73

56
59

66

Table 13.1.1 Installed Capacity in RE and Non-RE sector since 2017-18

68

Table 13.2.1: Installed Capacity under Solar, wind, Bio Power and Small
Hydro Power (RES) since 2014-15
13.3 Energy Generation during 2024-25

70

vii

73

<!-- page 9 -->

Chapter 14

Karnataka

74-80

Table 14.1.1 Installed Capacity in RE and Non-RE sector since 2017-18

75

Table 14.2.1: Installed Capacity under Solar, wind, Bio Power and Small
Hydro Power (RES) since 2014-15
14.3 Energy Generation during 2024-25

77

Chapter 15

Maharashtra

80
81-87

Table 15.1.1 Installed Capacity in RE and Non-RE sector since 2017-18

82

Table 15.2.1: Installed Capacity under Solar, wind, Bio Power and Small
Hydro Power (RES) since 2014-15
15.3 Energy Generation during 2024-25

84
87

INTERNATIONAL STATUS
WORLD WISE ANALYSIS
Chapter 16

Installed Capacity

89-95
89

Chapter 17

Table 16.1.1 Cumulative electricity installed capacity under RE & Non-RE
sectors since 2015
Table 16.2.1 Installed Capacity under solar, wind, renewable hydro and
bioenergy from 2015 to 2024
Energy Generation

Table 17.1.1 Energy generation in RE and Non-RE sector from 2015 to
2023
Table17.2.1 Energy Generation under solar, wind, renewable hydro and bioenergy from 2015 to 2023
REGION WISE ANALYSIS
Chapter 18

Installed Capacity and Energy Generation
Table18.1.1 Total RE & Non-RE Installed capacity from 2015 to 2024

Table 18.3.1 Electricity generation from RE & Non-RE Generation from
2015 to 2023
COUNTRY WISE ANALYSIS
Chapter 19

93
96-100
96
99

101-106
101
105

Installed Capacity and Energy Generation

107-110

Table 19.1.1 Top 10 countries by electricity installed capacity under
RE sector as on 31st December, 2024
Table 19.2.1 Top 10 countries by electricity generation from RE sources
during 2023
Metadata - Annexure

107

viii

109
111-112

<!-- page 10 -->

SCOPE & COVERAGE

Scope: Renewable Energy Statistics 2024-25 presents a comprehensive overview of the
renewable energy sector through detailed statistics on electricity installed capacity and
electricity generation. The publication covers developments at national, state, and
international levels, offering insights into the current status and growth of renewable
energy sources under electricity sector.
Coverage: At national and state levels, the analysis is limited to installed capacity and
energy generation from utilities. Pumped storage is included under large hydro. For
international statistics, International Renewable Energy Agency (IRENA) includes
electricity installed capacity and electricity generation from both utility and non-utility
power plants in their publication. Unlike national classification, IRENA excludes pumped
storage from hydropower, considering only "renewable hydro" as part of the renewable
energy .
Data Sources:
Non-Renewable Energy and Large Hydro: Installed capacity data is sourced
from the National Power Portal of the Central Electricity Authority (CEA), while energy
generation figures have been taken from the website of CEA, Ministry of Power.
Renewable Energy (Solar, Wind, Bio, and Small Hydro): Installed capacity data
is from Ministry of New and Renewable Energy (MNRE).
International Data: Installed capacity and energy generation figures are drawn
from IRENA’s publication Renewable Energy Statistics 2025. Share of Renewable energy
(rounded to two decimal places) is used to estimate the electricity installed capacity and
electricity generation from non-renewable sources for each country.
Reference Period: National data on installed capacity and energy generation is reported
on a financial year basis (April–March), while international data follows the calendar
year (January–December).



1

<!-- page 11 -->

INTRODUCTION
Energy is the heartbeat of our planet, intricately linked to the climate challenge we face
today. The rapid growth of the global population and advances in civilization have resulted in an
exponential growth in energy demand. Despite the well-known environmental and health risks
posed by fossil fuels, our dependence on them persists.
To address the growing energy demand and mitigate climate change risks, transitioning
from fossil fuels to renewable energy is crucial. To accomplish this objective, India's power sector
is also undergoing a transformative journey, brimming with enthusiasm for tapping into Renewable
Energy from diverse renewable sources.
In line with its mandate, Ministry of New & Renewable Energy has launched multiple
initiatives to encourage the widespread adoption and production of renewable energy technologies,
with the goal of accelerating India’s shift to clean energy and reducing reliance on fossil fuels. PMSurya Ghar: Muft Bijli Yojana stands as the world’s largest domestic rooftop solar initiative,
targeting the electrification of one crore households with solar energy by March 2027. This
transformative scheme not only promotes sustainability but also enhances energy affordability by
empowering millions of families to generate clean power at the grassroots level. Complementing
this effort, the Pradhan Mantri Kisan Urja Suraksha evam Utthaan Mahabhiyan (PM-KUSUM)
supports the deployment of solar pumps and grid-connected renewable power plants on barren and
agricultural lands, strengthening rural livelihoods and reducing the agricultural sector's reliance on
fossil fuels. In parallel, National Green Hydrogen Mission envisions India as a global leader in
green hydrogen production and utilization. As a clean energy vector, green hydrogen holds
immense potential to decarbonize hard-to-abate sectors such as fertilizer manufacturing, steel
production, heavy transport, and shipping. Together, these flagship initiatives are accelerating
India's transition towards a sustainable, affordable, and inclusive clean energy future. During
2024–25, Ministry rolled out a series of progressive initiatives to accelerate India’s clean energy
transition while fostering inclusive and sustainable growth. A key milestone was the launch of the
Viability Gap Funding (VGF) Scheme for 1,000 MW offshore wind energy projects. Ministry also
introduced Model Solar Village initiative under PM-Surya Ghar: Muft Bijli Yojana, aiming to
establish one solar-powered model village in every district. To advance green hydrogen adoption,
a dedicated scheme was launched to support pilot projects for hydrogen production and utilization
in residential and community settings. In a significant move to empower tribal populations, MNRE
unveiled the New Solar Power Scheme for Tribal and PVTG Habitations/Villages under PM
JANMAN and DA JGUA , targeting electrification in remote areas. Additionally, National
Bioenergy Programme was revised to include updated Central Financial Assistance (CFA) rates
for pellet and briquette manufacturing plants, promoting biomass utilization and strengthening the
country’s renewable energy mix.
The Ministry’s effective policy measures have led to significant progress, reflected in the
rise of renewable energy capacity installations and increased green energy generation. This
publication highlights the transformative evolution of the renewable energy sector across national,
state, and international levels.

2

2

<!-- page 12 -->

HIGHLIGHTS
ALL INDIA STATUS
Installed Capacity:
As on 31st March 2025, India’s total installed power generation capacity reached to 475.21 GW,
reflecting a substantial increase of 72.18% from 275.99 GW of 2014–15. A major highlight of this
transformation has been the rapid expansion of installed capacity under renewable energy sources ,
which recorded a growth of 170.69% over the decade. Within this segment, solar, wind, bio power,
and small hydro power sources experienced a combined growth of over 330%, showcasing the
country’s strong commitment to clean energy.
The year 2024–25 marked a significant milestone, with annual addition of installed capacity under
renewable energy sector hitting a record of 29.53 GW, far outpacing 3.72 GW added by non-renewable
sources. This was accompanied by a sharp rise in the annual growth rate of installed capacity under
renewable energy sector , which reached 15.50%, compared to just 1.5% under non-renewable energy
sector.
At the end of 2024–25, installed capacity under renewable energy accounted for 46.32% of India’s
total electricity installed capacity, while non-fossil sources collectively contributed 48.04%.
As per Renewable Energy Statistics 2025 published by International Renewable Energy Agency
(IRENA), India ranks 4th globally in total renewable installed capacity and holds the 3rd position in
solar installed capacity, reflecting its strong international standing in clean energy.

Electricity Generation:
During 2024–25, India’s total electricity generation reached 1824.12 Billion Units (BU), marking a
substantial increase of 65.02% from 1105.38 BU of 2014–15. A key driver of this growth has been the
rising share of renewable energy in the electricity generation which generated 403.64 BU, accounting
for 22.13% of the total electricity generated in the country.
Electricity generation from wind, solar, small hydro, and bio-energy reached 255.01 Billion Units
(BU), during 2024-25 , a sharp rise from 61.72 BU of 2014–15. Solar power has emerged as the leading
contributor, with its generation growing at a compound annual growth rate (CAGR) of 41.13% since
2014–15.
As per Renewable Energy Statistics 2025 by IRENA, India ranks 5th worldwide in total electricity
energy generation from renewable energy sources and holds the 3rd position in electricity generation
from solar power.

3

3

<!-- page 13 -->

STATE WISE STATUS

Installed capacity:
 As on 31st March 2025, Rajasthan, Gujarat, Tamil Nadu, Karnataka, and Maharashtra are the top
5 states in Renewable Energy installed capacity, collectively contributed 63.19% of country’s total
electricity installed capacity under renewable energy sector.


Rajasthan, Gujarat, Maharashtra, Tamil Nadu, and Karnataka accounted for 73.17% of the installed
capacity under solar power sector of the country.

 Wind energy was highly concentrated in the states of Gujarat, Tamil Nadu, Karnataka, Maharashtra,
Rajasthan, Andhra Pradesh, and Madhya Pradesh contributing about 99.59% of total wind power
installed capacity.
 Bioenergy sector was mainly driven by Maharashtra, Uttar Pradesh, Karnataka, and Tamil Nadu, which
together accounted for 71.37% of installed capacity under bioenergy sector.
 Installed capacity under Large hydro power was primarily contributed by Himachal Pradesh,
Uttarakhand, Karnataka, Jammu & Kashmir, Maharashtra, and Telangana, making up 57.66% of the
total installed capacity of the sector.

Electricity Generation during 2024-25:
 During 2024–25, Rajasthan, Gujarat, Karnataka, Himachal Pradesh, Tamil Nadu and Maharashtra
emerged as the leading states in generation of electricity from renewable sources. Together, they
accounted for approximately 65% of the country’s total generation of electricity from renewable
sources.
 Rajasthan, Gujarat, Tamil Nadu, Karnataka, Andhra Pradesh and Maharashtra led solar power
generation in India, together accounting for over 81% of the nation’s total electricity generation from
solar power.
 Gujarat, Tamil Nadu, Karnataka, Maharashtra, Andhra Pradesh and Rajasthan emerged as the key
players in wind energy, collectively producing about 94% of India’s total electricity generation from
wind power.
 In the bioenergy segment, Maharashtra, Uttar Pradesh, Karnataka, Chhattisgarh, West Bengal and
Punjab together accounted for approximately 78% of the country’s renewable energy generation from
bio-based sources.
 Himachal Pradesh, Jammu & Kashmir, Uttarakhand and Karnataka were the top 4 contributors in the
electricity generation from large hydro power , collectively producing 56% of India’s total electricity
generation from the source.

4

<!-- page 14 -->

Top 5 states in India in electricity Installed Capacity under Renewable Energy:
RAJASTHAN

I.

 As on 31st March 2025, Rajasthan led the country in renewable energy installed capacity, reaching
34.14 GW, which accounted for 15.51% of the total installed capacity . Over the past seven years,
state’s renewable energy capacity has grown 4.68 times, significantly outpacing the 1.21 fold increase
in non-renewable energy installed capacity. Notably, in 2021-22, installed capacity under renewable
energy sector in Rajasthan surpassed that of non-renewable sources for the first time.
 Share of renewable energy in Rajasthan’s total electricity installed capacity has risen sharply, from
40.51% of 2017-18 to 72.45% by 2024-25. Within the renewable energy segment, solar power continues
to dominate, contributing 82.86% of the installed capacity, followed by wind power with a share of
15.26%.
 Rajasthan also ranked as the top state in electricity generation from renewable energy sources during
2024-25, producing 57.35 Billion Units (BU), representing 14.21% of the country’s electricity
generation from Renewable Energy sources. The state remained a leader in electricity generation from
solar, wind, biopower, and small hydro power sources also with a combined electricity generation of
56.45 BU, accounting for 22.14% of the country’s electricity generation from these sources.
 During 2024-25, electricity generation from renewable sources contributed 43.86% to Rajasthan’s
overall power generation. Of this, solar power was the major contributor with 85.61%, while wind
power accounted for 12.10%.
GUJARAT

II.

 As on 31st March 2025, Gujarat ranked as the second-largest contributor to renewable energy installed
capacity in India, with a cumulative installation of 33.39 GW, accounting for 15.17% of the total
electricity installed capacity of the country. During 2017-18 to 2024-25, state’s renewable energy
installed capacity expanded by nearly 3.58 times, compared to a modest 1.06-fold increase under nonrenewable installed capacity. A significant milestone was achieved in 2023-24, when renewable energy
installed capacity surpassed that of non-renewable sources for the first time.
 Share of installed capacity under renewable energy sector in Gujarat’s total installed capacity grew
substantially from 28.45% of 2017-18 to 57.36% by 2024-25. Within the renewable energy electricity
installed capacity as on 31st March 2025 , solar power leads with a 55.39% share, followed by wind
power having 37.96%.
 In 2024-25, Gujarat emerged as the second-highest electricity generator under renewable energy
in the country, producing 52.00 Billion Units (BU), representing 12.88% of India’s total electricity
generation from renewable energy sources. The state also held the second position in electricity
generation from solar, wind, bioenergy and small hydro power sources, collectively producing 45.97
BU and contributing 18.03% to the national total from these technologies.
 Renewable sources contributed 32.97% of Gujarat’s total electricity generation during 2024-25. Within
this, wind power accounted for the largest share with 48.92%, followed by solar power having 38.88%.

5

<!-- page 15 -->

III.

TAMIL NADU

 As on 31st March, 2025, Tamil Nadu ranked third in the country in terms of renewable energy installed
capacity, with a total of 25.24 GW, contributing 11.47% to the national total. Over the last seven years,
the state’s installed capacity under renewable energy sector has grown 1.88 times, compared to a 1.07fold increase in non-renewable energy installed capacity.
 Share of renewable energy in Tamil Nadu’s total installed capacity enhanced from 44.70% of 201718 to 58.59% by 2024-25. Wind power remained the dominant source within the renewable installed
capacity, accounting for 46.51%, followed by solar power with a share of 40.23%.
 In 2024-25, Tamil Nadu ranked 5th nationally in electricity generation from renewable energy sources,
producing 38.41 Billion Units (BU), which represented 9.52% of India’s total electricity generation
from RE sources. In the case of electricity generation from solar, wind, bioenergy, and small hydro
sources, state ranked fourth, with a total generation of 33.81 BU, contributing 13.26% to the country’s
electricity generation from these sources.
 Renewable energy accounted for 29.52% of Tamil Nadu’s total electricity generation during 2024-25.
Electricity generation from wind power contributed the largest share within this segment with a share
of 45.11%, followed closely by solar power having 40.98%.
IV.

KARNATAKA

 As on 31st March 2025, Karnataka ranked fourth in the country for electricity installed capacity under
renewable energy sector, reaching 23.92 GW, which accounted for 10.87% of India’s total electricity
installed capacity under RE sector . Over the past seven years, the state’s renewable energy installed
capacity grew 1.47 times by 2024-25, compared to a 1.02-fold increase in non-renewable energy
installed capacity.
 Share of renewable energy in Karnataka’s total installed capacity has risen from 60.71% to 68.98%
over the last 7 years. Within this sector, solar energy leads with a share of 40.47%, followed by wind
energy having 30.74% share.
 In 2024-25, Karnataka ranked third in India for electricity generation from renewable energy sources
producing 48.14 Billion Units (BU), which constituted 11.93% of the country’s electricity generation
from RE sources. Specifically for solar, wind, bio power, and small hydro power, the state also ranked
third, contributing 34.09 BU, with a share of 13.37% of the total electricity generation from these
sources.
 During 2024-25, renewable energy accounted for 48.10% of Karnataka’s total electricity generation.
Of this, solar power contributed 32.61%, while wind power generated 28.29%.
V.

MAHARASHTRA

 As on 31st March 2025, Maharashtra ranked fifth in India for electricity installed capacity under
renewable energy sector with 22.40 GW, representing a 10.18% share of total electricity installed
capacity under renewable energy sector of the country. Over the past 7 years, the state’s renewable
energy installed capacity has expanded 1.94 times by 2024-25, while non-renewable energy sector saw
a marginal decline of 0.02 times.

6

<!-- page 16 -->

 Share of renewable energy in Maharashtra’s total electricity installed capacity has grown
significantly from 27.86% to 43.35% over the past 7 years. Within this installed capacity,
solar power leads with a share of 47.71% followed by wind power having 23.59% share.
 In 2024-25, Maharashtra was in sixth position in the country in electricity generation from renewable
energy sources, producing 25.23 Billion Units (BU), which contributed 6.25% to the country’s total
electricity generation from RE sources. For electricity generation from solar, wind, bio power and
small hydro power, Maharashtra ranked fifth, with 19.59 BU, accounting for 7.68% of India’s total
from these sources.
 During 2024-25, electricity generation from renewable energy sources contributed 14.82% to
Maharashtra’s total power generation. Within this, solar energy was the largest contributor with a share
of 30.62%, closely followed by wind energy having 30.36% share.

INTERNATIONAL STATUS
Installed capacity:


As on 31st December 2024, global installed capacity of renewable energy reached a total of 4442.76
GW as per Renewable Energy Statistics-2025 published by International Renewable Energy agency
(IRENA). The share of renewable energy in worldwide installed capacity has risen from 29.50% of
2014 to 46.20% by 2024.



In 2024, global renewable energy sector reached a significant milestone. The year witnessed a
record-breaking installation of 581.86 GW of renewable energy installed capacity, against 55.66 GW
installations from non-renewable sources.



Among renewable energy sources, solar energy experienced the most substantial growth, rising from
225.72 GW of 2015 to 1866.31 GW by 2024, while wind energy increased from 416.39 GW to 1132.66
GW during the period.



Installed capacity under Renewable energy sector has consistently achieved annual growth rates
exceeding 7.78%, while growth of installed capacity under non-renewable sector has remained below
3 % since 2016.



During the past five years, around 80% of annual installed capacity additions have been driven by the
renewable energy sector.



Asia had the largest expansion of 1651.77 GW in installed capacity under Renewable energy sources
during 2016 to 2024 followed by Europe with an expansion of 386.24 GW.



China leads the global renewable energy sector with an installed capacity of 1817.96 GW followed by
United States with 427.89 GW, as on 31st December, 2024. Brazil ranked third with 213.86 GW while
India secured fourth position with 204.48 GW of RE installed capacity. Germany was in 5th position
with an installation of 178.65 GW. Together, top 5 countries accounted for around 64 % of the world’s
total installed capacity under Renewable energy sector.

7

<!-- page 17 -->



Among the top 5 countries in the Renewable Energy installed capacity, China, USA, India and Germany
had their largest share of capacity installations from solar power in their respective country as on
December 2024. In the case of wind power capacity installations among these countries Germany
held the largest share of 40.76% in the country and Hydro Power installation was dominated in
Brazil’s RE sector with a contribution of 51.43% of its capacity installations.

Electricity Generation from Renewable Energy sources:


During 2023, total electricity generation from renewable energy sources reached 8928.49 TWh, a
significant increase from 5516.41 TWh of 2015 with an increase in share from 22.7% of 2015 to
around 30 %.



Asia expanded its energy generation from Renewable Energy sector from 2033.20 TWh of 2015 to
4007.63 TWh during 2023, followed by Europe with an expansion from 1174.08 TWh to 1626.36
TWh.
*****

8

<!-- page 18 -->

9

<!-- page 19 -->

INSTALLED CAPACITY
CHAPTER 1
Installed Capacity - RE and Non-RE sector
1.1 Installed Capacity in RE and Non-RE sector: As on 31st March, 2025, India’s cumulative

installed power generation capacity reached 475.21 GW, marking a substantial increase of 72.18% from
275.99 GW of 2014–15. The most notable progress has been in the renewable energy sector which
witnessed a remarkable capacity growth of 170.69% during this period. Even more striking is the rise
in installations from solar, wind, bio power, and small hydro power sources, which collectively grew by
app roximately 331.49% during the same period. Annual installed capacity additions under Renewable
energy sector peaked in 2024–25 with a record of 29.5d3 GW, significantly outpacing 3.72 GW added by
non-renewable sector. Since 2017–18, annual growth rate of installed capacity under renewable energy
sector has consistently exceeded 6%, reaching 15.50% in 2024–25. By the end of 2024–25, renewable
energy accounted for 46.32% of India’s total installed capacity, with non-fossil sources collectively
contributing 48.04%. As detailed data in subsequent chapters will further illustrate, the decade has been
defined not just by quantitative expansion, but by a qualitative transformation towards a cleaner, greener,
and more inclusive energy future.

Table 1.1 Cumulative Installed Capacity since 2014-15

(in GW)

Mode-wise Breakup (GW)
Non-RE

Year

Renewables (RE)

Nuclear

5.78
5.78

194.68
216.46

41.27
42.78

40.04

81.31

2015-16

188.9
210.68

47.09

2016-17

218.33

6.78

225.11

44.48

2017-18

222.91
226.28

6.78
6.78

229.69
233.06

45.29
45.40

230.6
234.73

6.78
6.78

237.38
241.51

2022-23

236.11
237.27

6.78
6.78

2023-24

243.22

2024-25
Gr
(2014-15
to 202425)
CAGR
(2014-15
to 202425)

2014-15

2018-19
2019-20
2020-21
2021-22

Total

Large
Hydro

Thermal

RES*

Total

Grand
Total

Growth(%)
RES

RE

..

Share(%)
Total

RES

RE

..
10.99

14.51
15.37

29.46
29.34

89.87

275.99
306.33

..
17.61

58.56

103.04

328.15

24.36

10.53
14.65

7.12

17.85

31.40

70.65
79.41

115.94
124.81

345.63
357.87

20.65
12.40

12.52
7.65

5.33
3.54

20.44
22.19

33.54
34.88

45.70
46.21

88.26
95.80

133.96
142.01

371.34
383.52

11.14
8.54

7.33
6.01

3.76
3.28

23.77
24.98

36.07
37.03

242.89
244.05

46.72
46.85

109.89
125.16

156.61
172.01

399.5
416.06

14.71
13.90

10.28

27.51
30.08

39.20
41.34

8.18

251.4

46.93

143.64

190.57

441.97

14.77

9.83
10.79

4.17
4.15
6.23

32.50

43.12

246.94

8.18

255.12

47.73

172.37

220.10

475.21

20.00

15.50

7.52

36.27

46.32

30.73%

41.52%

31.05%

15.65%

331.49%

170.69%

72.18%

2.72%

3.53%

2.74

1.46%

15.72%

10.47%

5.58%

Source: Ministry of New and Renewable Energy(MNRE) and Central Electricity Authority (CEA)
RES*- Comprising of Solar, Wind, Bio-Power and Small Hydro Power
Gr=Growth (%)CAGR=Compound Annual Growth Rate

10

<!-- page 20 -->

Fig 1.1 Share of Renewable Energy
As on 31st March 2015 (GW)

As on 31st March 2025 (GW)

194.68
GW,
70.53%

255.12
GW,
53.68%

81.31
GW,
29.46%

Non RE

RE

220.1
GW,
46.32%

Non RE

RE

Over the last decade, Renewable Energy (RE) sector has made a remarkable contribution to India’s
power generation landscape, significantly enhancing its share in the total installed capacity. In 2014–15,
renewable energy accounted for just 29.46% of the country’s total installed power capacity. By 2024–25, this
share had surged to an impressive share of 46.32%, underscoring the sector’s central role in driving India’s
clean energy transition.

Fig 1.2 Trend in Cumulative Installed Capacity
300

Installed Capacity (GW)

250
200

216.46

225.11

233.06

241.51

242.89

244.05

81.31

251.4

190.57

89.87

103.04

115.94

124.81

133.96

142.01

50
0

Non RE

11

255.12
220.1

194.68

150
100

229.69

237.38

RE

156.61

172.01

<!-- page 21 -->

The graph illustrates the installed power generation capacity in India during the last decade under
Non-Renewable Energy (Non-RE) and Renewable Energy (RE) sector. Over the years, installed capacity
under Non-RE sector has shown a relatively slow and steady increase, from 194.68 GW of 2014–15 to 255.12
GW by 2024–25. Against this, installed capacity under RE has seen a more rapid and consistent growth,
rising from 81.31 GW to 220.10 GW during the same period. Notably, the gap between Non-RE and RE
installed capacities has narrowed significantly, shrinking from 113.37 GW of 2014–15 to just 35.02 GW by
2024–25. While installed capacity under Non-RE still holds a slight lead, RE is quickly catching up and could
potentially surpass Non-RE in the near future.

Fig 1.3 Year wise capacity addition (in %).

CAPACITY ADDITION(IN %)

8.56

90%

3.94

100%

50%

29.53

RE
Non RE
21.78

40%

15.4

14.6

18.56

8.05

9.15

12.9

60%

8.87

13.17

70%

21.65

INSTALLED CAPACITY(%)

80%

0%

Data shown inside the bar diagram represents the installed capacity in GW.

12

3.72

1.16

1.38

7.35

4.13

4.32

3.37

10%

4.58

20%

8.65

30%

<!-- page 22 -->

Fig 1.4 Year wise growth (%) in installed capacity

18
16
14

12.52

12.51
11.19

12

Growth(in %)

15.50

14.65

10.28

10

8

10.53

7.65

2

10.79

7.33

6.34

6.01

6
4

9.83

4.00
3.01
2.03

1.85

1.47

1.74
0.57

1.48
0.48

0

Non RE

RE

In terms of year-on-year capacity addition and growth rates, renewable energy (RE) sector has
demonstrated impressive and sustained progress compared to non-renewable energy (non-RE) sector, which
includes traditional thermal and nuclear sources. The year 2024–25 marked a significant milestone, with
renewable energy installed capacity additions hitting a record of 29.53 GW far outpacing 3.72 GW added
by non-renewable sources. The graph on year wise growth highlights a sharp divergence in growth trends
between Renewable Energy (RE) and Non-Renewable Energy (Non-RE) from 2014–15 to 2024–25. Growth
of Non-RE sector declined steadily from 12.51% to just 1.48%, reflecting a slowdown in fossil-fuel-based
expansion. On the other hand, growth of installed capacity under RE sector enhance from 6.34% to a peak of
15.50%, overtaking Non-RE in 2016–17 and maintaining the lead since. After a brief dip around 2020–21, RE
growth rebounded strongly, indicating renewed momentum in clean energy deployment.

*****

13

<!-- page 23 -->

CHAPTER 2
Installed capacity - Wind, Solar, Small Hydro and Bio Energy
(RES) Sector
2.1

Installed Capacity under RES: Ministry of New and Renewable Energy (MNRE), entrusted

with the vital mandate of promoting sustainable energy solutions, has been at the forefront of India’s transition
towards a cleaner and greener energy future. As part of its comprehensive efforts, the Ministry actively
supports the development and deployment of various renewable energy sources, including Wind, Solar, Bio
Energy, and Small Hydro Power. Over the last decade, the impact of these initiatives has been particularly
pronounced in the Solar Power sector, which has experienced an unprecedented surge in installed capacity.
From a modest 3.99 GW of 2014–15, solar installed capacity shoot up to an impressive installations of 105.65
GW by 2024–25, reflecting a staggering growth rate of 2547.87%. This exponential rise highlights not only
the Ministry’s effective policy framework and incentives but also the rapid adoption of solar technologies
across diverse regions of the country.
Parallelly, the Wind Power sector has also made significant strides, with installed capacity growing
by 114.21% over the same ten-year period. While the growth rate in wind energy may be more moderate
compared to solar, it nonetheless underscores the sustained commitment to expanding India’s renewable
energy installed capacity. Alongside solar and wind, other renewable segments such as Bio Power and Small
Hydro Power continue to contribute to the sector’s diversification and resilience. This chapter delves into
a detailed analysis of installed capacity across Solar, Wind, Bio Power, and Small Hydro Power sectors,
exploring trends, shares, growth etc.

Table 2.1: Cumulative Installed Capacity under RES since 2014-15
Year

Small
Hydro
Power

Wind
Power

Bio-Power
BM
Waste to
Power/ Energy
Cogen.
8.31
0.24
8.67
0.25
8.84
0.28
9.36
0.31
9.78
0.32
9.88
0.35
10.15
0.39
10.21
0.48
10.25
0.55
10.36
0.59
10.74
0.84
29.24% 250.00%

2014-15
4.06
23.44
2015-16
4.27
26.78
2016-17
4.38
32.28
2017-18
4.49
34.15
2018-19
4.59
35.63
2019-20
4.68
37.74
2020-21
4.79
39.25
2021-22
4.85
40.36
2022-23
4.94
42.63
2023-24
5.00
45.89
2024-25
5.10
50.04
Gr (2014-15 to
25.62%
114.21%
2024-25)
CAGR (2014-15 to
2.31%
7.92%
2.60% 13.35%
2024-25)
*RES comprises of Solar, Wind, Small Hydro Power & Bio-Power
Gr=Growth (%)
CAGR=Compound Annual Growth Rate

14

Solar Power

(in GW)
Total
RES
Capacity

3.99
7.12
12.78
22.35
29.10
35.60
41.24
54.00
66.78
81.81
105.65
2547.87%

40.04
47.09
58.56
70.65
79.41
88.26
95.80
109.89
125.16
143.64
172.37
330.49%

38.77%

15.72%

Growth
(%)

17.87
24.36
20.65
12.4
11.14
8.54
14.71
13.9
14.77
20

<!-- page 24 -->

Fig 2.1 Share of various sources in RES Cumulative Installed capacity
5.1 GW,
2.96%

As on 31st March 2015
3.99 GW,
9.97%

As on 31st March 2025

4.06 GW,
10.14%

50.04 GW,
29.03%

8.55 GW,
21.35%

105.65GW
, 61.29%

23.44
GW,58.54%

11.58 GW,
6.72%
Small Hydro Power

Wind Power

Small Hydro Power

Wind Power

Bio-Power

Solar Power

Bio-Power

Solar Power

Above pie diagrams reveal a dramatic shift in the composition of India’s electricity installed capacity
under Solar, Wind, Bio Power and Small Hydro Power. At the end of 2014-15, Wind Power dominated the
mix, accounting for 58.54% of the total installed capacity under these sources followed by Bio-Power with a
share of 21.35%, Small Hydro Power having 10.14% contribution , and Solar Power with just 9.97%.
By the end of 2024-25, Solar Power emerges as the clear leader, making up 61.29% of the total
installed capacity under RES. Share of Wind Power declines significantly to 29.03% though its absolute
installed capacity more than doubles. Share of Bio-Power and Small Hydro Power reduced considerably to
6.72% and 2.96% respectively, indicating slower growth relative to solar power and wind power. Solar energy
has experienced explosive growth, becoming the backbone of India’s renewable sector, while wind power
remains significant but relatively diminished in share.

2.2

Trend in cumulative installed capacity under RES

The trend in Renewable Energy Sources (RES) cumulative installed capacity from 2014-15 to 202425 shows a clear and dynamic growth pattern across different technologies. Solar power exhibits the most
remarkable surge, growing from just 3.99 GW in 2014-15 to a substantial 105.65 GW by 2024-25, reflecting
rapid adoption and technological advancement. Wind power also shows steady growth, increasing from
23.44 GW to 50.04 GW over the same period, maintaining its position as a significant contributor to the
installed capacity under renewable sources. Bio-power capacity rises gradually from 8.55 GW to 11.58 GW,
indicating modest but consistent expansion. Small hydro power shows the slowest growth, increasing slightly
from 4.06 GW to 5.10 GW, suggesting limited new additions. Overall, the data highlights solar power as the
fastest-growing renewable source, reshaping the energy landscape, while wind power remains a stable and
major component, with bio-power and small hydro power contributing smaller but steady shares to the total
renewable capacity. (Ref Fig 2.2)

15

<!-- page 25 -->

Fig 2.2 Trend in RES cumulative Installed Capacity
120

100

Installed Capacity (GW)

80

60

40

20

0

201415

201516

201617

201718

201819

201920

202021

202122

202223

202324

202425

Small Hydro Power

4.06

4.27

4.38

4.49

4.59

4.68

4.79

4.85

4.94

5

5.1

Wind Power

23.44

26.78

32.28

34.15

35.63

37.74

39.25

40.36

42.63

45.89

50.04

Bio-Power

8.55

8.92

9.12

9.67

10.1

10.23

10.54

10.69

10.8

10.95

11.58

Solar Power

3.99

7.12

12.78

22.35

29.1

35.6

41.24

54

66.78

81.81

105.65

Small Hydro Power

Wind Power

Bio-Power

Solar Power

2.3 Year wise growth in installed capacity under RES
Year-wise growth in installed capacity of renewable energy (RE) sources under Solar, wind, BioPower and Small Hydro power from 2014-15 to 2024-25 shows distinct trends across different technologies.
Solar power demonstrates the highest growth rates, peaking between 2015-16 and 2017-18 with growth
close to 80%, before stabilizing to a more moderate range of 15% to 30% in later years, reflecting rapid
initial expansion followed by steady scaling. Wind power exhibits fluctuating growth, starting strong
with growth rates over 11% and peaking at 20.54% in 2016-17, then dipping to lower single digits before
rising again to about 9% by 2024-25. Bio-power growth remains relatively steady but modest, generally
between 1% and 6%, indicating gradual increase of installed capacity. Small hydro power shows the

16

<!-- page 26 -->

slowest and most stable growth, consistently around 1% to 7%, reflecting limited new installed capacity
additions. Overall, solar power leads the growth momentum, while wind power shows variable but
sustained progress, with bio-power and small hydro power growing steadily but at a slower pace.

Fig 2.3 Year wise growth (%) in installed capacity
90

80

70

Growth( in %)

60

50

40

30

20

10

0

201415

201516

201617

201718

201819

201920

202021

202122

202223

202324

202425

Small Hydro Power

6.84

5.17

2.58

2.51

2.23

1.96

2.35

1.25

1.86

1.21

2.00

Wind Power

11.03

14.25

20.54

5.79

4.33

5.92

4.00

2.83

5.62

7.65

9.04

Bio-Power

4.52

4.33

2.24

6.03

4.45

1.29

3.03

1.42

1.03

1.39

5.75

Solar Power

41.49

78.45

79.49

74.88

30.20

22.34

15.84

30.94

23.67

22.51

29.14

17

<!-- page 27 -->

Fig 2.4 Year wise installed capacity addition (in%)
Fig 2.4 Year wise installed capacity addition (in%)
100%

0.26

0.21

0.37
90%

0.11

0.2

0.37

0.11

0.55
1.87

0.1

0.09

0.13

0.43

2.11

1.48

0.11

0.31

0.06

0.09

0.15

0.11

0.15

0.63

2.27

3.26

4.15

12.78

15.03

23.84

1.11

0.06

0.1

1.51

Capacity Addition(in %)

80%
5.5

70%
60%

3.42

2.32

50%
12.76
40%

9.57

6.75

6.50

5.64

30%
3.13

20%

5.66

1.17
10%
0%

2014-15 2015-16 2016-17 2017-18 2018-19 2019-20 2020-21 2021-22 2022-23 2023-24 2024-25

Solar Power

Wind Power

Bio Power

Small Hydro Power

Data shown inside the bar diagram represents the installed capacity in GW.

In 2024–25, the solar sector marked a historic milestone by recording its highest-ever annual capacity
addition of 23.84 GW, with total installed capacity rising from 81.81 GW of 2023–24 to 105.65 GW. Rapid
annual installed capacity addition under Solar power from 1.17 GW during 2014-15 to 23.84 during 2024-25
highlights its central role in India’s transition to a cleaner energy installed capacity. Wind power installations
exhibited noticeable fluctuations over the years , however, continues to contribute significantly to the renewable
energy landscape. Meanwhile, Small Hydro Power (SHP) and Bio Power, though holding smaller shares in
the overall renewable energy capacity, also experienced inconsistent growth patterns. Their capacity additions
varied year-on-year. While these sources may not match the scale of solar and wind, they play an important
role in enhancing energy access and supporting regional energy needs, especially in remote and rural areas.
Various categories of Solar Power installations: Within the solar power sector, Ground-Mounted
Solar systems constituted the largest share of 79.40% of the installed capacity across the country totalling an
installation of 83.89 GW . This also constitutes hybrid Solar components, which integrate solar with wind or
storage solutions. These utility-scale projects, often set up in solar parks and dedicated zones, have been

18

<!-- page 28 -->

instrumental in accelerating solar deployment due to their scale, ease of integration with the grid, and policy
support. Following ground-mounted systems, Rooftop Solar installations accounted for a significant portion
of 16.11% with an installation of 17.02 GW. Off -grid systems including installations under the KUSUM
scheme (Kisan Urja Suraksha evam Utthaan Mahabhiyan), aimed at promoting solar pumps for farmers, have
also contributed 4.49% of the solar installed capacity amounting to 4.74 GW.

Fig. 2.5 Various categories of Solar Power installations

As on 31.03.2025
4742.89 MW,
4.49%
17017.44 MW,
16.11%

83886.16 MW,
79.40%

Ground Mounted Solar

Rooftop Solar

Oﬀ-grid Solar/ KUSUM

Various categories of Bio Power installations: As on March 31, 2025, Bio-Power sector is
predominantly led by Biomass Power and Bagasse Cogeneration, which together account for the largest share
of 84.79% of the total installed capacity. Non-Bagasse Biomass Cogeneration contributes 7.96%, followed by
Off-grid Waste to Energy projects with share of 4.58%, and Waste to Energy plants having share of 2.67%.
These technologies leverage agricultural residues, sugarcane waste, and other organic materials to generate
electricity and heat, providing a sustainable and circular energy solution, particularly in agrarian and industrial
states.

19

<!-- page 29 -->

Fig 2.6 Various categories of Bio Power installations

As on 31.03.2025

530.87 MW,
4.58%

309.34 MW,
921.79 MW, 2.67%
7.96%

9821.32 MW, 84.79%

BM
Power/Bag asse Cogen.

BM
Cogen. (Non- Bagasse)

Waste to Energy

Waste to Energy (Oﬀ-grid)

*****

20

<!-- page 30 -->

ENERGY GENERATION
CHAPTER 3
Energy Generation - RE and Non-RE sector
3.1 Energy generation from RE and Non-RE sector:

India’s total electricity generation
reached 1824.12 Billion Units (BU) during 2024–25, marking a significant rise of 65.02% from 1105.38 BU
of 2014–15. A notable highlight of this progress is the increasing contribution of renewable energy sources,
which generated 403.64 BU in 2024–25, accounting for 22.13% of the total power generation. This represents
a remarkable 111.37% increase in renewable energy generation compared to 2014–15, indicating India’s firm
commitment to a cleaner and more sustainable energy future.
This chapter presents a detailed year-wise analysis of India’s total electricity generation
from both renewable and non-renewable sources between 2014–15 to 2024–25. The trends reveal
a clear shift towards renewable energy, showcasing India’s strategic transition from conventional
fossil-based generation to a more balanced and environmentally sustainable power system.

Table 3.1 Year-wise All India Energy Generation since 2014-15
(in BU)
Non-RE
Year
2014-15
2015-16
2016-17
2017-18
2018-19
2019-20
2020-21
2021-22
2022-23
2023-24
2024-25
Gr (2014-15
to 2024-25)
CAGR (201415 to 2024-25)

Thermal Nuclear
878.32
943.79
994.22
1037.10
1072.22
1042.75
1032.51
1114.71
1206.15
1326.29
1363.79

36.10
37.41
37.92
38.30
37.81
46.47
43.03
47.11
45.83
47.94
56.68

RE
Large
Total Hydro
914.42
981.2
1032.14
1075.4
1110.03
1089.22
1075.54
1161.82
1251.98
1374.23
1420.47

129.24
121.38
122.38
126.10
134.89
155.77
150.30
151.63
162.10
134.05
148.63

55.27%

57.01% 55.34% 15.00%

4.50%

4.61%

4.50%

RES*

61.72
65.78
81.55
101.84
126.76
138.34
147.25
170.91
203.55
225.84
255.01

Total

190.96
187.16
203.93
227.94
261.65
294.11
297.55
322.54
365.66
359.89
403.64

313.17 111.37%
%
1.41% 15.24% 7.77%

Grand
Total

Share (%)
RE
RES*

1105.38
1168.37
1236.08
1303.34
1371.68
1383.33
1373.09
1484.36
1617.58
1734.12
1824.12

17.28
16.02
16.50
17.49
19.08
21.26
21.67
21.73
22.61
20.75
22.13

5.58
5.63
6.60
7.81
9.24
10.00
10.72
11.51
12.58
13.02
13.98

Growth
RE RES*
…
-1.99
8.96
11.77
14.79
12.41
1.17
8.40
13.37
-1.58
12.16

…
6.58
23.97
24.88
24.47
9.14
6.44
16.07
19.10
10.95
12.92

65.02%
5.14%

Source: CEA , Ministry of Power (MoP)

*RES constitutes Solar, Wind, Bio-Power & Small Hydro Power
Gr=Growth (%)
CAGR=Compound Annual Growth Rate

21

Source: CEA, Ministry of Power (MoP)

<!-- page 31 -->

Fig 3.1

Share of Renewable Energy
During 2024-25

During 2014-15
190.96 BU,
17.28%

403.64 BU, 22.13%

1420.47 BU, 77.87%

914.42 BU,
82.72%

RE

Non RE

RE

Non RE

India’s renewable energy share in electricity generation rose from 17.28% of 2014-15 to 22.13%
by 2024-25, nearly doubling in absolute terms from 190.96 BU to 403.64 BU. Meanwhile, non-renewable
energy’s share dropped from 82.72% to 77.87%, despite an increase in total electricity generation.

Renewable Energy Generation (in BU)

Fig 3.2 Trend in Energy Generation
1600
1374.23

1400
1200
1000

914.42

981.2

1032.14

1075.4

1110.03 1089.22 1075.54

1161.82

1420.47

1251.98

800
600
400
200

190.96

187.16

203.93

227.94

261.65

294.11

297.55

322.54

365.66

359.89

403.64

0

RE

Non-RE

The graph shows the trend in electricity generation under renewable energy (RE) and non-renewable

22

<!-- page 32 -->

energy (Non-RE) sources in India during different years starting from 2014-15 to 2024-25. Electricity generation
from Non-RE sources consistently remains higher, increasing from 914.42 BU of 2014-15 to 1420.47 BU by
2024-25, with some fluctuations between 2019-20 and 2020-21. Meanwhile, electricity generation from RE
sources shows steady growth, rising from 190.96 BU to 403.64 BU over the same period. Despite occasional
minor dips, renewable energy steadily gains ground, reflecting India’s gradual shift towards cleaner energy
sources, though non-renewables still dominate in electricity generation.

Fig 3.3 Year wise growth in Energy Generation (%)
16

14.79

14
11.77

12

Growth(in %)

10
8

12.16
9.76

8.96

8.40

7.30

7.76

8.02
5.19

6

4.19

4

3.36

3.22
1.17

2
0
-2

13.37

12.41

-1.87

-1.99

-1.26

-1.58

-4

RE

Non-RE

The graph illustrates the annual growth rates of electricity generation from renewable energy (RE) and
non-renewable energy (Non-RE) sources in India from 2015-16 to 2024-25. Renewable energy shows highly
variable growth, with sharp peaks of 14.79% during 2018-19 and 13.37% during 2022-23 and some dips,
including a notable decline of 1.58% during 2023-24. Overall, RE growth rates in electricity generation
remain mostly positive and fluctuate significantly, reflecting dynamic expansion and occasional slowdowns.
On the other hand, growth of electricity generation from non-renewable energy sources is steadier but generally
declining over the period, dropping from 7.30% of 2015-16 to just 3.36% by 2024-25, with minor negative
growth years around 2019-20 and 2020-21.

*****

23

<!-- page 33 -->

CHAPTER 4
Energy Generation - Wind, Solar, Small Hydro & Bio Energy (RES)
Sector
4.1

Energy generation from RES sector: In 2024–25, electricity generation from wind, solar,

small hydro, and bio-energy reached 255.01 Billion Units (BU), marking a significant increase from 61.72 BU
recorded in 2014–15. This reflects the substantial progress India has made in scaling up renewable energy over
the past decade. The data indicates a strong upward trend in electricity generation from Renewable Energy
source with solar power emerging as the dominant contributor in recent years. Since 2014–15, electricity
generation from solar power has grown at a compound annual growth rate (CAGR) of 41.13%, underscoring
its rapid expansion and increasing role in the national energy mix. Overall, RES has witnessed a robust CAGR
of 15.24% over the past ten years. A detailed analysis of energy generation trends across various renewable
energy sources is presented in this chapter.

Table 4.1 Year-wise Energy Generation under RES since 2014-15
(in BU)
Year
2014-15
2015-16
2016-17
2017-18
2018-19
2019-20
2020-21
2021-22
2022-23
2023-24
2024-25
Gr % (2014-15
to 2024-25)
CAGR (2014-15
to 2024-25)

Wind

Solar

Biomass

33.77
4.60
33.03
7.45
46.00
13.50
52.70
25.80
62.04
39.27
64.65
50.13
60.15
60.40
68.64
73.48
71.81
102.01
83.39
115.98
83.35
144.15
146.82% 3033.70%
9.46%

41.13%

3.16
3.73
4.20
3.41
2.76
2.94
3.51
3.48
3.16
3.42
3.74
18.35%
1.70%

Bio-Power
Bagasse Waste to
Energy

Total

Small
Hydro

Grand
Total

11.78
12.95
9.96
11.87
13.56
10.80
11.30
12.57
12.86
10.83
9.34
-20.71%

0.35
0.27
0.21
0.36
0.43
0.37
1.62
2.27
2.53
2.75
2.87
720.00%

15.29
16.95
14.37
15.64
16.75
14.11
16.43
18.32
18.55
17.00
15.94
4.25%

8.06
8.35
7.67
7.70
8.70
9.45
10.26
10.46
11.17
9.49
11.57
43.55%

61.72
65.78
81.55
101.84
126.76
138.34
147.25
170.91
203.55
225.83
255.01
313.17%

-2.29%

23.42%

0.42%

3.68%

15.24%

Growth
(%)
…
6.58
23.97
24.88
24.47
9.14
6.44
16.07
19.10
10.95
12.92

Source: CEA, MoP

Gr=Growth (%)
CAGR=Compound Annual Growth Rate

During 2014-15 to 2024-25, electricity generation from Solar, Wind, Biopower and small Hydro Power
saw remarkable expansion, led overwhelmingly by solar power. Electricity generation from Solar power grew
exponentially from just 4.60 BU to 144.15 BU marking a growth of 3033.7% and a staggering CAGR of
41.13% during last decade. Wind energy also expanded significantly, growing 146.82% with a CAGR of 9.46%
during the same period. However, bio-power remained largely stagnant, with minimal growth in biomass
and waste-to-energy by a decline in bagasse-based electricity generation. Waste-to-energy, though small in
absolute terms, posted an impressive 720% growth, reflecting its rising role in the energy mix. Small hydro
grew moderately by 43.55%, maintaining its position as a minor yet steady contributor. Overall, electricity
generation from these sources more than quadrupled from 61.72 BU of 2014-15 to 255.01 BU by 2024-25,
recording a CAGR of 15.24% .

24

<!-- page 34 -->

Fig 4.1 Share of various RE sources of RES in Energy Generation

During 2014-15
4.60BU,
7.45%

During 2024-25
11.57 BU,
4.54%

8.06 BU ,
13.06%

15.29BU ,
24.77%

83.35 BU,
32.68%
144.15 BU,
56.53%

33.77 BU,
54.71%

15.94 BU ,
6.25%

Small Hydro Power

Wind Power

Small Hydro Power

Wind Power

Bio-Power

Solar Power

Bio-Power

Solar Power

Above charts highlight a dramatic shift in India’s electricity generation from Solar , Wind, Bio power
and Small Hydro Power between 2014-15 and 2024-25. During 2014-15, wind power was the dominant
source, contributing 54.71% among these , followed by bio-power at 24.77%. Small hydro Power and solar
power accounted for 13.06% and 7.45%, respectively.
By 2024-25, solar power had surged to become the largest contributor, generating 144.15 BU, which
is 56.53% of the total electricity generation from these sources from just 4.60 BU which was 7.45% during
2014-15. Share of wind power declined to 32.68% despite absolute growth. Bio-power slightly increased
in electricity generation but dropped to 6.25% of the share, and small hydro declined further to 4.54% but
increased in absolute terms. This comparison highlights a major transformation as solar power has now
overtaken wind as the primary renewable energy source, marking a clear shift towards solar-led growth in
India’s renewable energy profile.

4.2

Trend in year wise electricity Generation under RES:

During 2014-15 to 2024-25, electricity generation from Solar , Wind, Bio power and Small Hydro
Power underwent a notable transformation, with solar power emerging as the dominant source. Electricity
generation from Solar Power surged from just 4.6 BU during 2014-15 to 144.15 BU in 2024-25, reflecting
exponential growth. Wind power, which was the leading source in 2014-15 with 33.77 BU, grew steadily
reaching around 83.35 BU in 2024-25. Bio-power generation, including biomass, bagasse, and waste-toenergy, remained largely stable, hovering between 15BU and 18 BU over the years. Small Hydro Power
contributed modestly throughout the period, with a slight increase from 8.06 BU to 11.57 BU.

25

<!-- page 35 -->

Fig 4.2 Trend in year wise energy Generation

Re ne wa ble Ene rgy Ge ne ra tio n ( in BU)

160

140

120

100

80

60

40

20

0

Wind Power

4.3

Solar Power

Bio-Power

Small Hydro Power

Yearwise growth(%) in Energy Generation :

The year-wise growth trends of electricity generation from Solar , wind, Bio power and Small Hydro
Power sources from 2015-16 to 2024-25 reveal a highly dynamic landscape, especially for solar power. Solar
Power consistently recorded the highest growth rates, peaking at 91.11% in 2017-18, followed by strong
double-digit increases in most of the years. Wind power displayed moderate and fluctuating growth, with a
high of 39.27% in 2016-17 but tapering off in later years, even dipping slightly in 2020-21 and 2024-25. Biopower showed irregular growth, with alternating years of expansion and contraction. Growth of electricity
generation from Small hydro power remained volatile and modest, often dipping into negative territory,
including -15.04% in 2023-24, though rebounding with 21.92% in 2024-25. Overall, the data underscores the
clear leadership of solar power in growth, while other sources showed more variability (Fig 4.3).

26

<!-- page 36 -->

Fig 4.3 Yearwise growth(%) in Energy Generation

100

Growth (in %)

80

60

40

20

0

-20

-40

201516

201617

201718

201819

201920

202021

202122

202223

202324

202425

Wind Power

-2.19

39.27

14.57

17.72

4.21

-6.96

14.11

4.62

16.13

-0.05

Solar Power

61.96

81.21

91.11

52.21

27.65

20.49

21.66

38.83

13.69

24.29

Bio-Power

10.86

-15.22

8.84

7.10

-15.76

16.44

11.50

1.26

-8.36

-6.24

Small Hydro Power

3.60

-8.14

0.39

12.99

8.62

8.57

1.95

6.79

-15.04

21.92

*****

27

<!-- page 37 -->

INSTALLED CAPACITY AND ELECTRICITY GENERATION
DURING -2024-25 & SDG-NIF
Chapter 5
Monthly Installed Capacity and Electricity Generation during
2024-25
5.1 Monthly Installed Capacity and Electricity Generation during 2024-25 :
Installed capacity additions during 2024–25 were overwhelmingly led by renewable energy, with
monthly additions ranging from 1.11 GW to 5.42 GW, while installed capacity under Non Renewable Energy
remained negligible. Thermal capacity actually declined in April (by 0.22 GW) and March (by 0.65 GW) with
only modest monthly additions of up to 1.7 GW between December and February. Nuclear capacity remained
unchanged throughout the period, and installed capacity additions under large hydro sector was minimal,
0.04 GW in October and 0.76 GW in March. Renewable energy additions peaked at 5.42 GW in March,
contributing to exceptional year-on-year growth rates of 596.30% in September, 402.86% in October, and
283.87% in August. Solar energy led the charge, with monthly additions reaching 3.69 GW in December and
an impressive 682.35% year-on-year growth in September. Wind capacity remained volatile, adding 1.45 GW
in March and registering year-on-year surges of 227.27% in October and 95.95% in March. In contrast, small
hydro and bio-power made only marginal contributions. Overall, capacity growth in 2024–25 was almost
entirely driven by solar, with wind playing a significant but secondary role.
During 2024–25, total monthly electricity generation ranged between 134 BU and 168 BU.
Electricity generation from Non-renewable sources dominated contributing monthly generation between
107.08 BU and 132.73 BU. However, their performance remained weak, with year-on-year declines in
August (-3.89%), September (-5.67%), and October (-2.33%), despite a peak growth of 15.30% in May.
Monthly Electricity generation from Renewable energy (RE) sources ranged from 25.39 BU to 44.28 BU and
emerged as the primary driver of overall growth. Notable year-on-year increases were recorded in January
(27.49%), March (25.86%), and November (22.60%), although a slight dip occurred in August (-2.76%).
Monthly Electricity generation form Solar registered consistent growth, rising from 12.02 BU in April to
16.81 BU in March, with strong year-on-year growth exceeding 36% in November, January, and March.
Electricity generation from Wind power peaked at 13.63 BU in July and spiked by 38.34% in January. Large
hydro reached 21.57 BU in August, supporting year-on-year gains of over 28% in October and November.
Overall, renewable sources, particularly solar anchored electricity generation growth in 2024–25, while nonrenewables remained largely stagnant or declined across several months.
Details of Monthly installed capacity addition as well as electricity generation from various sources
during 2024-25 are stipulated in this chapter.

28

<!-- page 38 -->

Table 5.1 Monthly Capacity Addition during 2024-25
Month

Non-RE
Thermal

Apr-24
May-24
Jun-24
Jul-24
Aug-24
Sep-24
Oct-24
Nov-24
Dec-24
Jan-25
Feb-25
Mar-25
2024-25

RE

Nuclear

-0.22
0
0
0
0
0.06
0
0
1.32
1.52
1.69
-0.65
3.72

Total

0
0
0
0
0
0
0
0
0
0
0
0
0

-0.22
0
0
0
0
0.06
0
0
1.32
1.52
1.69
-0.65
3.72

Large
Hydro

0
0
0
0
0
0
0.04
0
0
0
0
0.76
0.8

RES

1.11
1.9
1.43
2.2
2.37
1.88
1.72
2.3
3.92
2.72
2.51
4.66
28.72

Total

1.11
1.9
1.43
2.19
2.38
1.88
1.76
2.3
3.92
2.73
2.51
5.42
29.53

Grand
Total

(in GW)

Year on Year Growth
(in %)
RES
RE

0.89
1.9
1.43
2.19
2.38
1.93
1.76
2.31
5.24
4.25
4.2
4.76
33.24

109.43
75.93
-50.17
76.00
282.26
596.30
391.43
303.51
230.25
121.14
73.10
-34.09

109.43
75.93
-50.17
75.20
283.87
596.30
402.86
283.33
221.31
120.16
71.92
-23.34

Note : Growth ‘-100.00’ reflects the absence of additions in 2024–25, in contrast to additions recorded in 2023–24
and ‘ …’ represents no capacity addition during 2023-24
Source: MNRE and CEA

Table 5.2 Monthly Sector Wise RE Capacity Addition during 2024-25
Year on Year Growth (in %)

RE

Month
Solar

Wind

Bio
SHP Power

Large
Hydro

Apr-24

0.83

0.27

0.01

0

0

May-24

1.64

0.26

0

0

0

Jun-24

1.19

0.24

0

0

0

Jul-24

1.74

0.42

0.03

0.01

0

Aug-24

2.22

0.11

0.03

0

0

Sep-24

1.33

0.17

0.01

0.36

0

Oct-24

1.36

0.36

0

0.02

0.04

Nov-24

2.05

0.24

0

0

0

Dec-24

3.69

0.2

0.02

0.01

0

Jan-25

2.47

0.21

0

0.05

0

Feb-25

2.24

0.22

0

0.05

0

Mar-25

3.08

1.45

0

0.13

0.76

…

Large
Hydro
…

…

-100.00

…

-57.89

-100.00

-100.00

…

65.71

147.06

50.00

…

…

382.61

-26.67

…

-100.00

…

682.35

88.89

…

…

…

466.67

227.27

-100.00

…

…

606.90

-11.11

…

…

-100.00

265.35

11.11

…

0.00

-100.00

149.49

-8.70

…

…

-100.00

76.38

22.22

…

…

…

-50.56

95.95

-100.00

18.18

…

Solar
176.67

Wind
12.50

SHP
…

121.62

-21.21

-47.81

Bio
Power

(in GW)
GW)
(in

2024-25
23.84
4.15
0.1
0.63
0.8
Note: Growth ‘-100.00’ reflects the absence of additions in 2024–25, in contrast to additions recorded in
Note: Growth ‘-100.00’ reflects the absence of additions in 2024–25, in contrast to additions recorded in 2023–24
and ‘ …’ represents no capacity addition during 2023-24

Source: MNRE and CEA

29

<!-- page 39 -->

Table 5.3 Monthly Electricity Generation during 2024-25
(inBU)
BU)
(in

Non-RE

Month
Apr-24
May-24
Jun-24
Jul-24
Aug-24
Sep-24
Oct-24
Nov-24
Dec-24
Jan-25
Feb-25
Mar-25
2024-25

RE

Thermal Nuclear

Total

123.50
128.05
120.87
111.40
104.20
102.15
114.11
104.23
107.97
114.38
110.40
122.63
1363.79

127.71
132.73
125.09
116.20
109.69
107.08
118.88
109.04
113.05
119.20
114.55
127.35
1420.47

4.21
4.68
4.22
4.80
5.49
4.93
4.77
4.81
5.08
4.82
4.15
4.72
56.68

Grand
Total

Year on Year Growth(in %)

Large
RES
Total
Non-RE RES
RE
Hydro
8.11
18.62
26.75
154.46
11.18
11.68
5.27
12.59
22.51
35.10
167.83
15.30
8.69
8.74
14.18
23.05
37.23
162.32
11.15
1.99
0.79
17.56
25.97
43.53
159.73
8.48
14.15
7.03
21.57
22.71
44.28
153.97
-3.89
-3.68
-2.76
20.57
22.40
42.97
150.05
-5.67
12.49
18.59
14.46
17.70
32.16
151.04
-2.33
14.86
20.68
8.63
16.76
25.39
134.43
0.71
18.95
22.60
7.75
19.77
27.53
140.58
3.00
17.92
20.02
7.39
21.18
28.57
147.77
-1.68
31.88
27.49
6.97
20.19
27.17
141.72
1.22
12.20
13.55
8.76
24.15
33.10
160.45
3.95
25.23
25.86
148.63
255.01
403.64 1824.12
Source: Central Electricity Authority (CEA)
Source: Central Electricity Authority (CEA)

RES*- Comprising of Solar, Wind, Bio-Power and Small Hydro Power

Table 5.4 Monthly Electricity Generation under RES during 2024-25
(in
(in BU)
BU)
Month
Apr-24
May24
Jun-24
Jul-24
Aug-24
Sep-24
Oct-24
Nov-24
Dec-24
Jan-25
Feb-25
Mar25
202425

RE

Small
Solar
Wind Hydro
Bio Power
12.02 4.73
0.58
1.29
12.65 8.26
11.45 10.13
10.36 13.63
10.16 10.27
11.30 8.87
12.26 3.24
11.25 3.11
10.71 5.75
12.29 5.64
12.91 4.59

0.75
0.78
1.32
1.60
1.61
1.46
0.86
0.81
0.63
0.56

0.86
0.70
0.66
0.68
0.61
0.75
1.54
2.51
2.64
2.12

16.81

5.13

0.62

1.58

144.15 83.35

11.57

15.94

Year on Year Growth(in %)
Large
Small
Bio
Hydro Solar
Wind
Hydro
Power
8.11
16.50
11.30
-0.74
-15.11

Large
Hydro
-7.10

12.59

17.35

1.72

2.58

-20.92

8.82

14.18
17.56
21.57
20.57
14.46
8.63
7.75
7.39
6.97

19.13
22.77
8.92
22.58
19.93
43.80
24.58
36.38
23.92

-12.31
9.46
-17.15
0.22
-8.74
-12.27
12.41
38.34
-6.42

5.59
5.92
29.19
31.97
50.95
11.15
37.29
31.25
27.27

-0.94
6.71
10.45
-1.02
10.56
-20.94
1.62
5.60
-4.93

-1.05
-2.01
-1.78
26.04
28.65
30.36
25.61
16.38
17.54

8.76

37.51

12.14

31.91

-21.39

24.79

148.63

Source: Central Electricity Authority (CEA)

****

30

<!-- page 40 -->

CHAPTER 6
Sustainable Development Goal -National Indicator Framework
(SDG-NIF)
6.1 SDG-NIF :

India has demonstrated remarkable progress towards achieving Sustainable
Development Goal-7 (SDG 7), which aims to ensure access to affordable, reliable, sustainable, and modern
energy for all. One of the metrics for tracking this advancement is indicator 7.b.1/12.a.1, which measures the
installed renewable energy generating capacity per capita (in watts). Over the past decade, India’s per capita
renewable energy capacity has more than doubled, increasing from 64.04 watts of 2014–15 to 156.31 watts
by 2024–25. This significant growth reflects the expansion of the country’s total installed capacity under
renewable energy from around 81.2 GW to over 220 GW during the same period. Notably, the most substantial
annual increase occurred between 2023–24 and 2024–25, when per capita renewable installed capacity surged
by 14.5%, jumping from 136.56 watts to 156.31 watts.
Another national indicator for measuring the goal is the indicator 7.2.1 which measures the share of
RE in India’s total electricity generation. This indicator has shown a consistent upward trajectory over the past
decade. From 16.02% of 2015-16, RE contribution in overall electricity generation rose steadily, reaching
a peak of 22.61% in 2022-23. Despite a marginal dip to 20.75% in 2023-24, the share recovered to 22.13%
in 2024-25, with renewable generation increasing to 403.64 BU out of the total 1824.22 BU. This progress
highlights India’s ongoing commitment to building a sustainable energy future and enhancing energy access
for its growing population. Details of these indicators are stipulated in this chapter.

Table 6.1 SDG – NIF Indicators 7.b.1/12. a.1- Installed renewable energy generating
capacity in the country (in watts per capita)

Year

Installed electricity generation capacity in
renewable energy (in Watt)

Watts per capita

2014-15
2015-16
2016-17
2017-18
2018-19
2019-20
2020-21
2021-22
2022-23
2023-24
2024-25

81217520000
89874800000
103036610000
115944860000
124811220000
133954520000
142012610000
156607900000
172009980000
190572680000
220096350000

64.04
69.98
79.29
88.25
93.97
99.77
104.65
114.29
124.38
136.56
156.31

31

<!-- page 41 -->

Fig 6.1 Installed renewable energy generating capacity in the country (in watts per capita)

Watts per capita

156.31

160
140
120
100
64.04

80

69.98

79.29

88.25

93.97

99.77

104.65

114.29

124.38

136.56

60
40
20
0

2014-15 2015-16 2016-17 2017-18 2018-19 2019-20 2020-21 2021-22 2022-23 2023-24 2024-25

Table 6.2 SDG Indicators 7.2.1 RE share in the total installed electricity generation

Year

Overall generation (in
BU)

Generation through RE
(in BU)

Share of RE (in %)

2015-16

1168.37

187.16

16.02

2016-17

1236.08

203.93

16.50

2017-18

1303.34

227.94

17.49

2018-19

1371.68

261.65

19.08

2019-20

1383.33

294.11

21.26

2020-21

1373.09

297.55

21.67

2021-22

1484.36

322.54

21.73

2022-23

1617.58

365.66

22.61

2023-24

1734.12

359.89

20.75

2024-25

1824.22

403.64

22.13

32

<!-- page 42 -->

Fig 6.2 RE share in the total installed electricity generation

Share of RE (in %)
25
21.67

21.73

2020-21

2021-22

21.26

22.61

22.13
20.75

19.08

20
16.02

16.5

17.49

15

10

5

0

2015-16

2016-17

2017-18

2018-19

2019-20

*****

33

2022-23

2023-24

2024-25

<!-- page 43 -->

34

<!-- page 44 -->

POTENTIAL AND INSTALLED
CAPACITY
CHAPTER 7
Estimated RE potential and Installed Capacity in RE and Non-RE
sector
7.1 Estimated Renewable Energy Potential:

India possesses substantial renewable energy
potential across diverse sources such as solar, wind, hydro, and bioenergy. Government of India consistently
undertakes initiatives to evaluate and update the estimated capacities of these resources. As per the latest
assessments, the country’s estimated potential for Solar Power, Wind Power, Hydro Power, and Bio Power
is as follows:

Solar Power:
As per the report “Solar PV Potential of India (Ground Mounted)” published by National Institute
of Solar Energy (NISE), in September 2025 estimated country’s solar power potential is 3343.37 GW. The
country has been actively working to harness this potential, achieving 3rd rank globally in installed solar
capacity as well as electricity generation from solar power.

Wind Power:
National Institute of Wind Energy (NIWE) in 2023, India’s wind power potential has been estimated
at 1163.86 GW at 150 meters above ground level. India ranks 4th in the world for wind installed capacity,
reflecting significant progress in harnessing its wind energy potential.

Hydro Power:
 Large Hydro Power: India possesses substantial hydro power potential due to its numerous

rivers and dams. According to Exploitable capacity identified by Central Electricity Authority,
Ministry of Power, Large Hydro Power has the estimated potential of 133.41 GW in the country.

 Small Hydro Power: As per the assessment done by IIT Roorkee in 2016, India’s estimated
potential for small hydro power (up to 25 MW) is 21.13 GW.
Biomass Power:
Administrative Staff College of India, in 2021 estimated country’s bio-energy power potential as
42.27 GW. India ranks 3rd globally in bioenergy installed capacity. State wise Renewable Energy estimated
potential has been described in Table 7.1.

35

<!-- page 45 -->

Table 7.1 Estimated potential in RE Sector

STATES / UTs

Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
UT of Jammu &
Kashmir
Ladakh
Jharkhand
Karnataka
Kerala
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Orissa
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Chandigarh
Dadar & Nagar
Haveli & Daman and
Diu
Delhi
Lakshadweep
Pondicherry
Others
Total

Wind
Power
123336
246
459
4023
2749
14
180790
593
239
1
16
169251
2621
55423
173868
55

12129
428
284250
95107
54717
510
49
1281
1245

Small
Hydro
Power
409.32
2064.92
201.99
526.98
1098.2
4.7
201.97
107.4
3460.34

Bio-energy
Biomass
Bagasse
Power
Cogeneration
1999.49
279.6
18.46
321.89
964.37
346.6
353.68
32.97
2637.84
554.7
1353.35
362.1
69.71

1707.45

82.82

227.96
3726.49
647.15
820.44
786.46
99.95
230.05
168.9
182.18
286.22
578.28
51.67
266.64
604.46
102.25
46.86
460.75
1664.31
392.06
7.27

146.31
1793.88
778.41
2516.42
2629.55
62.31
68.54
2.90
53.90
298.72
3022.11
1299.55
4.73
1560.08
1678.36
34.35
2800.31
93.34
1741.74
18.13
0.15

17

1762.1

3917

414.4

639.3
117.4
4925.7
215.1

2.16

(in MW)
Solar
Power*
299312.12
467.52
19173.13
32991.49
126484.29
6752.35
243219.9
6468.1
21501.61
8588.94
8556.64
51831.29
223278.99
12404.71
318972.16
486678.68
2293.92
14674.1
612.21
190.96
139474.33
9210.19
828781.44
254.46
204765.06
140451.26
9105.85
97842.99
4436.24
22742.39
594.22
22.42
498.31

Large
Hydro
2596
50394
643
130.1
1311
550
18305
12971.5
300
4414.4
2472.75
2819
3144
615
2026
1926.7
325
2824.5
1300.73
411
6051
1785.2
1302
501.6
13481.35
809.2

550.22
31
408
1163856

1.39
5.00
21133.62

28446.91

* Ground Mounted

195.9
284.4
13818.4

3343378.39

133410.03

Source: MNRE & CEA

36

<!-- page 46 -->

7.2

State wise Installed Capacity under RE and Non -RE sector:

During 2018-19 to 2024-25, India’s renewable energy (RE) installed capacity increased from 116 GW
to 220 GW, registering an impressive growth of over 89.8%. Installed capacity under Non-renewable energy
(Non-RE) rose modestly by about 11%, from around 230 GW to 255GW indicating a significant policy and
investment shift towards clean energy.
Among states, Rajasthan witnessed the most dramatic RE growth in installed capacity, leaping from
7,289 MW to 34,136 MW, an addition of nearly 27,000 MW , making it the top RE state in 2024-25. Gujarat
followed with a rise from 9,339 MW to 33,393 MW. Tamil Nadu retained its strong position, expanding from
13,452 MW to 25,241 MW. Karnataka and Maharashtra rounded out the top five, reaching 23,917 MW and
22,401 MW respectively.
States like Madhya Pradesh, Andhra Pradesh, and Himachal Pradesh also posted considerable gain in
RE installed capacity. Himachal Pradesh’s installed capacity was entirely renewable and grew from 10,514
MW to 12,196 MW, driven by hydro resources. Smaller states and UTs such as Goa, Delhi, and Chandigarh
showed noteworthy percentage increases, albeit from a smaller base. Table 7.2 provides detailed data on
installed capacity across various states and Union Territories as on 31st March 2018 and 31st March 2025.

Table 7.2 State wise Non-RE and RE Cumulative Installed Capacity as on 31.03.2018 and
31.03.2025 (in MW)

Sr. No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20

Year

Up to 31st March,2018

Up to 31st March,2025

States/UTs
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland

Non-RE
16507.20
0.00
1103.95
5480.00
22968.00
48.00
23483.41
5971.59
0.00
175.00
4590.00
10513.12
693.54
0.00
17065.00
29833.08
36.00
0.00
0.00
0.00

Non-RE
17905.34
0.00
1347.36
9060.00
23688.00
48.00
24828.41
5761.59
0.00
175.00
5570.00
10755.25
693.54
0.00
22000.00
29273.09
36.00
0.00
0.00
0.00

37

RE
8060.58
517.00
378.39
346.18
785.42
1.08
9339.45
510.49
10514.30
3650.22
320.14
16241.59
2282.06
0
6445.13
11519.21
115.28
418.85
100.16
108.51

RE
12114.48
1270.46
582.65
539.26
1828.46
58.43
33393.03
2449.94
12196.19
3624.42
434.06
23917.64
3853.38
142.59
10827.70
22401.46
124.24
395.11
135.86
110.84

<!-- page 47 -->

Sr. No.
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36

Year

Table 7.2 contd.
Up to March,2025

Up to March,2018
States/UTs

Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Chandigarh
Dadar & Nagar
Haveli/Daman & Diu
Delhi
Lakshadweep
Pondicherry
Others
Grand Total

Non-RE

RE

Non-RE

7680.00
6540.00
10703.10
0.00
16638.90
6682.50
1132.10
23776.10
450.00
14495.00
40.05
0.00

2364.94
2626.98
7289.36
2222.98
13451.7
6507.48
24.53
3447.25
4379.83
1747.46
12.05
26.01

0.00

16.07

3048.40
0.00
32.50

123.03
3.14
0.34
47.66
115945.00

229687.00

RE

9600.00
5680.00
12982.83
0.00
17841.38
10242.50
1067.60
29968.14
664.00
13567.00
92.71

2958.84
3270.42
34136.34
2344.67
25241.36
7688.34
37.25
6223.91
5010.77
2112.18
35.16

0.00
0.00

78.85
51.87

2208.40
26.83
32.50

397.40
4.97
54.51
49.31
220096.35

255115.46

Source: National Power Portal (NPP), MoP & MNRE

*****

38

<!-- page 48 -->

CHAPTER 8
Installed capacity in RE sector
8.1

Region wise /state wise installed capacity in RE sector

Between 2017–18 and 2024–25, India witnessed a remarkable transformation in its electricity installed
capacity, nearly doubling from 116 GW to over 220GW. This growth was predominantly concentrated in the
Western, Northern, and Southern regions, driven by strong contributions from states like Gujarat, Maharashtra
,Rajasthan, Karnataka, Tamil Nadu, and Andhra Pradesh. The Southern Region leads India’s renewable energy
capacity with over 33%, followed by the Western and Northern Regions, while the Eastern and North-Eastern
regions lag behind. Solar energy dominates India’s renewable mix, complemented by wind, large hydro, biopower, and small hydro power. States like Rajasthan and Karnataka demonstrate high shares of installed
capacity exceeding 60%, while some northeastern states achieve 100% renewable capacity, mainly through
hydro power. For detailed state-wise and region-wise data on RE installed capacity from 2017–18 to 2024–25,
please refer to Table 8.1.

Table 8.1 Region wise / State wise RE Cumulative Installed Capacity from 2017-18 to
2024-25
2022-23

(in MW)
(in MW)
2023-24 2024-25

1242.13
11303.49

1362.09
11330.42

1832.92 2449.94
11356.16 12196.18

3588.11

3551.61

3556.12

3595.37

89.00
2743.80
10812.35
4563.07

136.44
2864.12
17451.62
4985.12

137.79
2961.93
22809.05
5282.65

139.79
142.59
3163.92 3270.42
27103.89 34136.34
5697.17 6223.91

4909.14
58.69
302.26
52710.14

4971.94 5010.77
65.52
78.85
340.51
397.4
58267.19 67530.82

517.00

4437.96
4589.24
4787.15
41.36
45.97
55.17
218.62
246.43
270.12
36286.95 38357.09 46646.97
NORTH-EASTERN REGION
655.69
955.98
1256.27
1257.34

1259.75

1259.90 1270.46

378.39
115.28
418.85
100.16
108.51
24.53
1662.72

414.58
118.66
372.18
101.20
108.51
24.53
1795.35

534.04
122.73
372.48
133.49
110.71
33.61
2566.81

542.29
123.49
395.07
135.78
110.84
34.47
2601.84

STATES / UTs

2017-18

2018-19

Haryana
Himachal
Pradesh
Jammu &
Kashmir
Ladakh
Punjab
Rajasthan
Uttar
Pradesh
Uttarakhand
Chandigarh
Delhi
Total

510.49
10514.30

519.11
10707.75

547.19
10768.91

762.51
10916.61

3650.22

3664.10

3581.11

0.00
2626.98
7289.36
3447.25

0.00
2522.38
8223.73
3739.46

89.00
2566.86
10134.97
3900.97

4379.83
26.01
123.03
32567.47

4426.88
35.52
180.35
34019.28

Arunachal
Pradesh
Assam
Manipur
Meghalaya
Mizoram
Nagaland
Tripura
Total

2019-20 2020-21 2021-22
NORTHERN REGION

433.86
120.43
372.18
102.52
108.51
28.91
2122.39

437.67
121.84
372.18
103.45
108.58
29.57
2429.56

39

504.05
122.70
372.48
104.37
108.71
30.9
2500.55

3624.42

582.65
124.24
395.11
135.86
110.84
37.25
2656.41

<!-- page 49 -->

Table 8.1 Contd
.

STATES / UT's

2017-18

2018-19

2019-20

2020-21

2021-22

2022-23

2023-24 2024-25

WESTERN REGION

785.42

850.77

864.89

886.52

989.08

1419.82

1683.39 1828.46

1.08
9339.45
6445.13
11519.21
16.07

4.09
10697.72
6864.87
12421.69
19.93

5.29
12683.77
7285.75
12822.27
25.32

7.95
15204.25
7526.97
13382.85
46.01

20.34
18577.90
7703.88
13704.08
46.18

26.88
21425.85
8140.08
15804.50
46.47

45.47
27461.72
9333.37
17530.12
46.47

58.43
33393.03
10827.7
22401.46
51.87

28106.36

30859.07

33687.29
37054.55
EASTERN REGION

41041.46

46863.6

56100.54

68560.95

Bihar

346.18

352.23

365.09

376.63

387.35

389.60

450.15

539.26

Jharkhand

320.14

267.87

273.80

288.21

307.14

324.19

395.55

434.06

Odisha

2364.94

2681.68

2686.38

2715.63

2771.64

2782.57

2825.03

2958.84

Sikkim

2222.98

2222.99

2223.05

2223.05

2338.79

2341.80

2344.15

2344.67

West Bengal

1747.46

1849.29

1888.03

1923.44

1928.15

1962.77

1982.13

2112.18

12.05

17.22

17.68

34.71

34.74

35.16

35.16

35.16

7013.75

7391.28

7454.03

7561.67

7767.81

7836.09

8032.17

8424.17

Chhattisgarh
Goa
Gujarat
Madhya Pradesh
Maharashtra
Dadar & Nagar
Haveli/Daman &
Diu
Total

Andaman &
Nicobar
Total

SOUTHERN REGION
Andhra Pradesh

8060.58

9560.02

10091.40

10696.10

10821.6

10970.20

11029.30

12114.48

Karnataka

16241.60

17524.40

18918.10

19149.30

19593.8

20408.40

21441.90

23917.64

Kerala

2282.06

2290.71

2304.35

2428.92

2527.2

2957.10

3229.46

3853.38

Tamil Nadu

13451.7

14909.40

16588.8

17476.70

18277.5

20098.60

22161.60

25241.36

Telangana

6507.48

6405.96

6442.85

6796.59

7364.79

7510.97

7604.40

7688.34

Lakshadweep

3.14

3.14

3.27

3.27

3.27

3.27

4.97

4.97

Pondicherry

0.34

3.32

5.69

9.51

13.69

35.53

49.91

54.51

Total

46546.9

50696.95

54354.46

56560.39

58601.85

61984.07

65521.54

72874.68

Others

47.66

49.31

49.31

49.31

49.31

49.31

49.31

49.31

115944.90

124811.20

133954.50

142012.60

156607.90

172010.00

190572.70

220096.35

Grand Total

Source:
MNRE
&&
NPP
, MoP
Source:
MNRE
NPP,
MoP

8.2

Share of various regions in the installed capacity as on 31.03.2025:

As on 31st March 2025, Southern Region leads India’s renewable energy installed capacity, contributing
the highest share at 33.13%, reflecting strong growth in states like Karnataka, Tamil Nadu, and Andhra Pradesh.
Western Region follows closely with 31.15%, driven by major contributions from Gujarat and Maharashtra.
Northern Region holds a 30.68% share, with Rajasthan playing a dominant role in the region’s rise. On the
other hand, Eastern Region accounts for only 3.83%. North Eastern Region contributes the least at just 1.21%,
indicating minimal capacity expansion and limited renewable infrastructure in the area. The chart highlights
the regional imbalance in renewable energy growth, with southern and western states leading the transition
(Ref Fig 8.1).

40

<!-- page 50 -->

Fig 8.1 Region wise RE Installed Capacity

(in MW)

As on 31.03.2025

North East , 2656.41 ,
1.21%
Northern , 67530.82 ,
30.68%

Southern , 72923.99 ,
33.13%

Eastern , 8424.17 ,
3.83%
Western , 68560.95 ,
31.15%

Northern

8.3

Western

Eastern

Southern

North East

Installed Capacity under RE as on 31.03.2025:

As on 31st March, 2025, Rajasthan, Gujarat, Tamil Nadu, Karnataka, and Maharashtra emerged as the
leading contributors to India’s renewable energy (RE) installed capacity. Collectively, these states accounted
for a substantial share of 63.19% of the country’s total installed renewable energy capacity. In the solar energy
sector, the top five contributing states were Rajasthan, Gujarat, Maharashtra, Tamil Nadu, and Karnataka.
These states together accounted for an impressive share of 73.17% of the total solar power capacity installed
in the country. Wind energy segment continued to be concentrated in a few key states, with Gujarat, Tamil
Nadu, Karnataka, Maharashtra, Rajasthan, Andhra Pradesh & Madhya Pradesh contributing approximately
99.59% of the total installed wind power capacity. This indicates the high regional concentration of wind
energy potential and development in coastal and high-wind corridor states. Bioenergy sector also experienced
significant growth, primarily driven by Maharashtra, Uttar Pradesh, Karnataka, and Tamil Nadu. These four
states together contributed about 71.37% of the country’s total installed bioenergy capacity, benefiting from
agricultural and industrial biomass availability. In the case of large hydro power, the contribution was led by

41

<!-- page 51 -->

Himachal Pradesh, Uttarakhand, Karnataka, Jammu & Kashmir, Maharashtra, and Telangana, which
together accounted for 57.66% of the country’s total large hydro installed capacity. This reflects the
geographical advantage of these states, particularly in the Himalayan and Western Ghats regions, which
offer significant hydroelectric potential. This distribution highlights both the geographical concentration
and the regional strengths in different RE segments, reflecting how state-specific natural resources and
policies shape India’s renewable energy landscape. (Refer table 8.2)

8.4

State wise installed capacity of Various categories of Solar and Bio Power as on
31.03.2025:

India’s renewable energy installed under bio-power and solar power shows diverse contributions
across states. Bagasse cogeneration dominates bio-power, with Maharashtra, Uttar Pradesh, and Karnataka
leading. Solar power is heavily concentrated in ground-mounted installations, led by Rajasthan, Gujarat,
and Tamil Nadu. Rooftop solar is significant in Gujarat, Maharashtra, Rajasthan and Kerala. Smaller states
and UTs like Chandigarh, Delhi, and Andaman & Nicobar focus on rooftop and off-grid solar. Overall, this
mixes highlights India’s robust bio-energy base alongside a rapid expansion of solar, supporting its clean
energy transition with a balance of centralized and distributed generation (Refer Table 8.3)

8.5

Installation of Off-grid / Decentralized Renewable Energy Systems / Devices as
on 31.03.2025:

The data showcases India’s extensive deployment of decentralized renewable energy systems across
states and UTs, highlighting biogas plants, solar photovoltaic (SPV) pumps, and various SPV systems.
Biogas plants are widely installed, with Maharashtra, Karnataka, and Uttar Pradesh leading in numbers,
supporting rural energy needs. SPV pumps, crucial for sustainable agriculture, have significant adoption
in Maharashtra, Haryana and Rajasthan. Details of Off-Grid / Decentralized Renewable Energy Systems
/ Devices installed under schemes of MNRE are stipulated in table 8.4

8.6

Renewable energy share in the total installed capacity within the state:

The penetration of renewable energy (RE) in the overall power generation capacity varies
significantly across states and Union Territories (UTs). As on 31st March, 2025, 100% of the total installed
power capacity comes from renewable energy sources in respect of the States/UTs of Arunachal Pradesh,
Himachal Pradesh, Meghalaya, Mizoram, Nagaland, Sikkim, Ladakh, Chandigarh, Dadar & Nagar Haveli
and Daman & Diu..
In addition, Uttarakhand, Kerala, Manipur, Rajasthan, Karnataka, Jammu & Kashmir and Puducherry
report a renewable energy share ranging between 60% and 100% of their total installed capacity. (Refer
table 8.5).

42

<!-- page 52 -->

Table 8.2 RE cumulative installed capacity as on 31.03.2025
(in MW)
States /UTs
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Islands
Chandigarh

"Dadar & Nagar
Haveli/
Daman & Diu"
Delhi
Lakshadweep
Pondicherry
Others
Total

Small Hydro
Power
163.31
140.61
34.11
70.70
76.00
0.05
106.64
73.50
1000.71
189.93
4.05
1284.73
276.52
45.79
123.71
384.28
5.45
55.03
45.47
32.67
115.63
176.10
23.85
55.11
123.05
90.87
16.01
49.10
233.82
98.50
5.25

5100.55

Wind Bio
Power Power

Solar
Power

4377.15

594.02
0.00
2.00
140.22
285.42
1.94
122.25
311.47
10.20
0.00
20.14
1912.95
2.50
0.00
155.46
2998.30
0.00
13.80
0.00
0.00
64.22
576.59
206.27
0.00
1046.62
221.67
0.00
2309.14
148.53
351.86
0.00

5370.00
14.85
196.54
328.34
1347.04
56.44
18496.66
2064.97
204.26
74.49
199.87
9679.66
1538.94
7.80
5118.38
10687.27
13.79
4.28
30.39
3.17
624.44
1421.43
28286.47
7.56
10153.58
4842.10
21.24
3364.07
593.07
320.62
29.91

0.00

78.85

78.85

3.75

48.12

51.87

84.00
313.40
0.00
4.97
0.00
54.51
0.00
45.01
11583.32 105646.49

397.40
4.97
54.51
49.31
220096.35

12677.48

7351.10
71.27
3195.15
5284.61

5208.75
11739.91
128.10

4.30

50037.82

43

Large
Hydro
1610.00
1115.00
350.00
120.00
1990.00
10981.02
3360.00
210.00
3689.20
1964.15
89.00
2235.00
3047.00
105.00
322.00
60.00
75.00
2154.55
1096.30
411.00
2282.00
2178.20
2405.60
501.60
4035.35
1341.20

47728.17

Total
Capacity
12114.48
1270.46
582.65
539.26
1828.46
58.43
33393.03
2449.94
12196.19
3624.42
434.06
23917.64
3853.38
142.59
10827.70
22401.46
124.24
395.11
135.86
110.84
2958.84
3270.42
34136.34
2344.67
25241.36
7688.34
37.25
6223.91
5010.77
2112.18
35.16

<!-- page 53 -->

Table 8.3

Cumulative installed capacity of bio-power and solar
power as on 31.03.2025.
(in MW)

States/Uts
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman &
Nicobar Islands
Chandigarh
Dadra & Nagar
Haveli /
Daman & Diu
Delhi
Lakshadweep
Pondicherry
Others
Total (MW)

BM
Power/
Bagasse
Cogen.
378.10
112.50
272.09
65.30
151.40

Bio-Power
Waste
BM
Waste
to
Cogen.
to
Energy
(Non
Energy
(OffBaggasse)
grid)
113.57
53.16
49.19
2.00
26.40
2.50
12.00
111.26
9.20

1.94
7.50
11.20

1.32
10.83
37.45
37.61
1.00

1868.91

19.10
20.20
2.27

1.00

1.04
22.84
0.23

92.50
2907.30

14.85
16.40

15.40
12.59

32.71
62.01

13.80
50.40
299.50
134.15

8.82
231.79
2.00

10.75
59.60

5.00
34.55
10.52

969.10
158.10

43.55
3.30

6.40
45.80

27.57
14.47

1985.50
72.72
300.00

165.26
60.00
43.52

158.38
15.81
8.34

3.75
84.00

9821.32

921.79

309.34

44

530.87

Solar Power
Ground
Mounted
Solar

Rooftop
Solar

Hybrid
Solar
Comp.

Off-grid
Solar/
KUSUM

4990.86
1.27
126.00
196.06
848.91
1.95
12482.93
266.80
145.05
2.49
21.00
8862.80
323.21
6.00
4503.24
5994.70
0.60
0.00
22.00
0.00
512.00
886.27
23985.22
0.52
9150.98
4360.49
5.10
2717.45
298.40
240.35
25.05

290.80
6.68
61.10
111.00
107.40
53.00
5105.20
828.50
24.63
42.20
93.04
696.70
1190.80
1.80
513.10
3298.20
7.11
0.21
2.00
1.00
70.10
453.80
1515.80
5.12
932.20
472.90
4.80
321.90
273.71
67.13
4.59

0.00
0.00
0.00
0.00
0.00
0.00
813.50
0.00
0.00
0.00
0.00
81.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
1980.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00
0.00

88.34
6.90
9.44
21.28
390.73
1.49
95.03
969.67
34.58
29.80
85.83
39.16
24.93
0.00
102.04
1394.37
6.08
4.07
6.39
2.17
42.34
81.36
805.45
1.92
70.40
8.71
11.34
324.72
20.96
13.14
0.27

6.34
14.30

71.70
33.82

0.00
0.00

0.81
0.00

302.10
0.00
53.30
0.00
17017.44

0.00
0.00
0.00
0.00
2874.50

1.46
2.52
0.18
45.01
4742.89

9.84
2.45
1.03
0.00
81011.66

<!-- page 54 -->

Table 8.4 Installation of Off-grid / Decentralized Renewable Energy Systems / Devices
as on 31.03.2025

State/UT
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Chandigarh
Dadar & Nagar Haveli
Daman & Diu
Delhi
Lakshadweep
Puducherry
Others*
Total

Biogas
Plants
(Nos)
268652
3621
139485
130440
60738
4245
439402
64366
47718
3201
7890
515386
154462
0
388333
945345
2178
11156
5857
7953
271980
191157
73597
9044
224129
316749
4052
441845
367169
1293
97
169
681
0
578
0
17541
5120509

Solar Photovoltaic (SPV) Systems

SPV
Pumps
(Nos.)
34045
473
45
2813
119282
145
21745
155664
881
2327
36953
9402
826
0
25138
332122
118
117
77
68
15233
17605
152497
0
55491
424
4389
91995
1056
653
5
12
0
0
90
0
21
4621
10,86,333

SLS
(Nos.)
16,460
25,008
29,538
54,147
4,538
707
5,004
34,625
98,800
39,076
14,344
5,694
1,735
16,808
10,420
32,767
5,800
20,325
16,045.0
19,109.0
43,758
8,934.0
504
41,419
2,458
15,517
302,532
43,803
18,203
1,490
901
301
4,465
417
9,150
944,802

HLS
(Nos.)
22,972
35,065
46,879
12,303
42,232
393
9,253
56,727
22,592
144,316
9,450
52,638
41,912
7,920
3,497
24,583
14,874
12,060
1,045.0
5,274.0
8,626
187,968.0
15,059
298,641
32,723
235,909
91,595
145,332
468
275
600
25
140,273
1,723,479

SL
(Nos.)
77,803
218,551
647,761
1,735,227
3,311
1,093
31,603
93,853
33,909
51,224
790,515
7,781
54,367
529,101
239,297
69,722
97,360
155,217
30,766.0
99,843.0
17,495
225,851.0
45,200
16,818
142,000
364,012
2,351,205
165,071
17,662
6,296
1,675
4,807
5,289
1,637
125,797
8,459,119

PP
(KWP)
3,816
963
1,605
6,905
31,373
33
13,577
4,571
21,606
8,130
3,770
7,854
16,268
7,654
3,858
1,581
2,004
3,895
1,506.0
2,321.5
2,066
1,04,449.0
850
13,053
7,450
867
10,638
4,060
1,730
167
730
1,269
2,190
121
23,885
3,16,816

SLS =Street Lightening System, HLS=Home Lightening System, SL=Solar Lantern, PP= Power Plants,
SPV=Solar Photo Voltaic

45

<!-- page 55 -->

Table 8.5

Share of RE in Cumulative Installed Capacity as on 31.03.2025
(in MW)

STATES / Uts
Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Chandigarh
Dadar & Nagar
Haveli/Daman & Diu
Delhi
Lakshadweep
Pondicherry
Others
Total

Non RE
17905.34
0.00
1347.36
9060.00
23688.00
48.00
24828.41
5761.59
0.00
175.00
5570.00
10755.25
693.54
0.00
22000.00
29273.09
36.00
0.00
0.00
0.00
9600.00
5680.00
12982.83
0.00
17841.38
10242.50
1067.60
29968.14
664.00
13567.00
92.71
0.00
0.00

RES
10504.48
155.46
232.65
539.26
1708.46
58.43
31403.03
2449.94
1215.17
264.42
224.06
20228.44
1889.23
53.59
8592.70
19354.46
19.24
73.11
75.86
35.84
804.29
2174.12
33725.34
62.67
23063.16
5282.74
37.25
5722.31
975.42
770.98
35.16
78.85
51.87

2208.40
26.83
32.50

397.40
4.97
54.51
49.31

255115.46

172368.18

RE
Hydro
1610.00
1115.00
350.00
0.00
120.00
0.00
1990.00
0.00
10981.01
3360.00
210.00
3689.20
1964.15
89.00
2235.00
3047.00
105.00
322.00
60.00
75.00
2154.55
1096.30
411.00
2282.00
2178.20
2405.60
0.00
501.60
4035.35
1341.20
0.00
0.00
0.00
0.00
0.00
0.00
47728.16

*****

46

Total
12114.48
1270.46
582.65
539.26
1828.46
58.43
33393.03
2449.94
12196.18
3624.42
434.06
23917.64
3853.38
142.59
10827.70
22401.46
124.24
395.11
135.86
110.84
2958.84
3270.42
34136.34
2344.67
25241.36
7688.34
37.25
6223.91
5010.77
2112.18
35.16
78.85
51.87

Grand
Total
30019.82
1270.46
1930.01
9599.26
25516.46
106.43
58221.44
8211.53
12196.18
3799.42
6004.06
34672.89
4546.92
142.59
32827.70
51674.55
160.24
395.11
135.86
110.84
12558.84
8950.42
47119.17
2344.67
43082.74
17930.84
1104.85
36192.05
5674.77
15679.18
127.87
78.85
51.87

Share (%)
RES
RE
34.99
40.35
12.24
100.00
12.05
30.19
5.62
5.62
6.70
7.17
54.90
54.90
53.94
57.36
29.84
29.84
9.96
100.00
6.96
95.39
3.73
7.23
58.34
68.98
41.55
84.75
37.58
100.00
26.18
32.98
37.45
43.35
12.01
77.53
18.50
100.00
55.84
100.00
32.33
100.00
6.40
23.56
24.29
36.54
71.57
72.45
2.67
100.00
53.53
58.59
29.46
42.88
3.37
3.37
15.81
17.20
17.19
88.30
4.92
13.47
27.50
27.50
100.00
100.00
100.00
100.00

397.40
4.97
54.51
49.31

2605.80
31.80
87.01
49.31

15.25
15.63
62.65

15.25
15.63
62.65

36.27

46.32

220096.34

475211.80

<!-- page 56 -->

ENERGY GENERATION
CHAPTER 9
Energy generation - RE and Non-RE Sector
9.1

Share of Renewable Energy in total electricity generation during 2024-25:

India’s renewable energy landscape in 2024–25 reflects strong regional leadership in various
sectors. States like Rajasthan, Gujarat, and Karnataka have emerged as multi-sector leaders, while
others contribute significantly within specialized domains like large hydro or bioenergy. This regional
diversification is vital for achieving national renewable energy targets and ensuring energy security
through sustainable means. During 2024–25, Rajasthan, Gujarat, Karnataka, Himachal Pradesh, and
Tamil Nadu emerged as the top five states in renewable energy generation. Together, they accounted for
approximately 59% of the country’s total renewable energy generation. (Refer table 9.1)

9.2

Generation of electricity from various Renewable Energy Sources:

Data on electricity generation from renewable energy (RE) sources reflects a well-diversified
mix of sources, with total electricity generation from RE sources reaching 403.64 BU. Solar energy
leads with 144.15 BU, driven by states like Rajasthan, Gujarat, Tamil Nadu, and Karnataka. Rajasthan
tops the list with over 49 BU, making it India’s solar powerhouse. Wind power generation, at 83.35
BU, is concentrated in coastal and high-wind regions such as Gujarat, Tamil Nadu, and Karnataka.
Electricity generation from Large hydro contributes 148.63 BU predominantly from hilly states like
Himachal Pradesh, Uttarakhand, and Jammu & Kashmir, where natural terrain favours hydroelectric
generation. Electricity generation from Bio power sees significant generation in Maharashtra, Uttar
Pradesh, and Karnataka, supporting rural energy and waste management. (Refer Table 9.2)
State wise electricity generation during 2024-25 from RE and Non RE sector , Solar Power,
Wind power, Large Hydro Power, Small Hydro Power, Bio Power is described in this chapter.

47

<!-- page 57 -->

Table 9.1 Share (%) of RE generation in Total Energy Generation during 2024-25
(in
(inMU
MU) )

RE
STATES / UTs

Non-RE

Grand Total

Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa

72866.98
0.00
8195.19
60757.75
166431.38
0.00

RES
Hydro
Total
15902.23
3303.08 19205.31
1.88
4205.16
4207.04
514.36
998.75
1513.11
445.10
0.00
445.10
3225.93
419.42
3645.35
65.24
0.00
65.24

Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Chandigarh
Dadar & Nagar
Haveli/Daman & Diu
Delhi
Lakshadweep
Pondicherry
Total

105728.84
30443.93
0.00
0.00
38812.21
51948.33
1.53
0.00
146116.76
145015.63
0.00
0.00
0.00
0.00
68638.78
33575.21
73418.10
0.00
91714.75
56969.20
5099.65
166214.34
837.76
93168.16
374.18
0.00
0.00

45973.98
6028.52
2237.62
0.00
3148.14 39386.29
395.17 15200.65
23.89
269.12
34085.85
14056.00
2723.14
6733.99
0.00
413.06
12567.32
7606.73
19591.19
5635.24
8.68
706.37
116.65
905.58
77.49
240.30
98.62
215.02
1297.75
6285.36
3146.91
4126.11
56447.88
905.80
12.35
2012.67
33807.45
4602.73
7641.70
5270.78
5.97
0.00
7708.76
1273.74
933.72 15183.82
1966.51
2649.70
39.00
0.00
8.79
0.00
28.63
0.00

3878.01
66.94
204.95
1420478.56

748.95
0.09
12.24
255009.18

52002.50
2237.62
42534.43
15595.82
293.01
48141.85
9457.13
413.06
20174.05
25226.43
715.05
1022.23
317.79
313.64
7583.11
7273.02
57353.68
2025.02
38410.18
12912.48
5.97
8982.50
16117.54
4616.21
39.00
8.79
28.63

0.00
748.95
0.00
0.09
0.00
12.24
148633.99 403643.17

Share (%)

RES
RE
17.27
20.86
0.04 100.00
5.30
15.59
0.73
0.73
1.90
2.14
100.0
100.00

92072.29
4207.04
9708.30
61202.85
170076.73
65.24

157731.34 29.15
32681.55
6.85
42534.43
7.40
15595.82
2.53
39105.22
0.06
100090.18 34.06
9458.66 28.79
413.06
0.00
166290.81
7.56
170242.06 11.51
715.05
1.21
1022.23 11.41
317.79 24.38
313.64 31.44
76221.89
1.70
40848.23
7.70
130771.78 43.17
2025.02
0.61
130124.93 25.98
69881.68 10.94
5105.62
0.12
175196.84
4.40
16955.30
5.51
97784.37
2.01
413.18
9.44
8.79 100.00
28.63 100.00
4626.96
67.03
217.19
1824121.73

16.19
0.13
5.64
13.98

32.97
6.85
100.00
100.00
0.75
48.10
99.98
100.00
12.13
14.82
100.00
100.00
100.00
100.00
9.95
17.80
43.86
100.00
29.52
18.48
0.12
5.13
95.06
4.72
9.44
100.00
100.00
16.19
0.13
5.64
22.13

Source: CEA, MoP

48

<!-- page 58 -->

Table 9.2 State-wise Renewable Energy generation during 2024-25.
(in MU)
States /UTs

Andhra Pradesh
Arunachal Pradesh
Assam
Bihar
Chhattisgarh
Goa
Gujarat
Haryana
Himachal Pradesh
Jammu & Kashmir
Jharkhand
Karnataka
Kerala
Ladakh
Madhya Pradesh
Maharashtra
Manipur
Meghalaya
Mizoram
Nagaland
Odisha
Punjab
Rajasthan
Sikkim
Tamil Nadu
Telangana
Tripura
Uttar Pradesh
Uttarakhand
West Bengal
Andaman & Nicobar
Chandigarh
Dadar & Nagar
Haveli/Daman & Diu
Delhi
Lakshadweep
Pondicherry
Total

Small Hydro
Power

Wind
Power

Bio
Power

Solar
Power

Large
Hydro

Total

294.36
0.58
208.55
14.54
139.34
0.00
205.98
314.64
3040.90
395.17
6.25
2259.49
814.29
0.00
482.19
855.48
0.00
116.65
52.11
98.62
457.20
734.01
4.15
12.35
256.60
74.48
0.00
179.00
353.40
183.30
14.40
0.00
0.00

7235.04
0.00
0.00
0.00
0.00
0.00
25440.90
0.00
0.00
0.00
0.00
13620.33
119.85
0.00
4712.84
7659.71
0.00
0.00
0.00
0.00
0.00
0.00
6941.26
0.00
17326.66
290.60
0.00
0.00
0.00
0.00
0.00
0.00
0.00

379.35
0.00
0.30
104.70
1563.31
8.14
107.62
452.96
0.00
0.00
0.00
2506.40
77.17
0.00
248.56
3350.80
0.00
0.00
0.00
0.00
53.80
1040.17
400.85
0.00
484.89
334.85
0.00
2563.71
248.52
1462.46
0.00
0.00
12.76

7993.48
1.30
305.52
325.86
1523.27
57.11
20219.48
1470.02
107.24
0.00
17.64
15699.63
1711.83
0.00
7123.73
7725.20
8.68
0.00
25.38
0.00
786.75
1372.73
49101.62
0.00
15739.30
6941.75
5.97
4966.06
331.80
320.75
24.59
8.79
15.87

3303.07
4205.16
998.75
0.00
419.42
0.00
6028.52
0.00
39386.29
15200.65
269.12
14056.00
6733.99
413.06
7606.73
5635.24
706.37
905.58
240.30
215.02
6285.36
4126.11
905.80
2012.67
4602.73
5270.78
0.00
1273.74
15183.82
2649.70
0.00
0.00
0.00

19205.31
4207.04
1513.11
445.10
3645.35
65.24
52002.50
2237.62
42534.43
15595.82
293.01
48141.85
9457.13
413.06
20174.05
25226.43
715.05
1022.23
317.79
313.64
7583.11
7273.02
57353.68
2025.02
38410.18
12912.48
5.97
8982.50
16117.54
4616.21
39.00
8.79
28.63

0.00
0.00
0.00
11568.03

0.00
0.00
0.00
83347.19

542.41
0.00
0.00
15943.73

206.53
0.09
12.24
144150.21

0.00
0.00
0.00
148633.98

748.95
0.09
12.24
403643.17

Source: CEA, MoP

*****

49

<!-- page 59 -->

CHAPTER 10
Top 5 states in Renewable Energy Installed Capacity
10.1
Top 5 states in RE installed capacity and their contribution in the country’s
cumulative RE Installed Capacity: Rajasthan, Gujarat, Tamil Nadu, Karnataka and Maharashtra

were the top 5 states in terms of their installed capacity under Renewable energy sector in the country.
Total share of renewable energy in installed capacity as on 31.03.2025 shows that Rajasthan emerges as
the frontrunner with the largest share, standing at approximately 15.51%, followed closely by Gujarat with
15.17% share. States of Tamil Nadu, Karnataka and Maharashtra contributes with shares of 11.47%, 10.87%
and 10.18% respectively. Remarkably, these five states collectively command a significant portion, accounting
for around 63% of India’s total installed capacity under renewable energy sector driven largely by solar and
wind energy initiatives. (Refer Fig 10.1)

Fig 10.1 Top 5 states in RE installed capacity and its share (%)
(in MW)

(in MW)

RE Installed Capacity as on 31.03.2025
Remaining States,
81006.52 MW,
36.81%

Gujarat, 33393.03
MW,15.17%
Rajasthan,
34136.34 MW,
15.51%

Tamil Nadu,
25241.36 MW,
11.47%

Maharashtra,
22401.46 MW,
10.18%

Karnataka,
23917.64 MW,
10.87%

50

<!-- page 60 -->

10.2 Contribution of various RE sources of top 5 RE installed capacity states within the
respective state’s RE installed Capacity: Analysis of the contribution of various renewable energy
sources of the top 5 states within their respective RE installed capacity as on 31st March 2025, revealed that
solar power had the largest share in all the states except Tamil Nadu. Rajasthan exhibits the highest reliance
on solar power, with 82.86% of its RE installed capacity coming from solar, followed by 15.26% from wind;
other sources are minimal. Gujarat also prioritizes solar energy (55.39%), but maintains a substantial share
of wind power at 37.96%, with small contributions from bio power and hydro power sources. Tamil Nadu
presents a more balanced installed capacity mix, with wind energy dominating by 46.51%, closely followed
by solar (40.23%), and smaller yet notable shares from bio energy (4.15%) and large hydro power (8.63%).
Karnataka leads in diversification, with solar accounting for 40.47%, wind 30.74%, and appreciable inputs
from bio power (8.0%), large hydro power (15.42%), and small hydro (5.37%). Maharashtra also has a mixed
portfolio, with solar (47.71%), wind (23.59%), bio power (13.38%), and large hydro power (13.60%) all
contributing significantly. This analysis highlights how states like Karnataka and Maharashtra adopt a more
balanced RE strategy, while Rajasthan and Gujarat emphasize solar dominance (Refer Fig 10.2).

Fig 10.2 Share of various RE sources of top 5 RE installed capacity states within the state’s
RE installed capacity
(As on 31.03.2025)
90

82.86

80

Share in RE Installed Capacity(in %)

70
60

55.39

50

47.71

46.51

30.74

30
20

23.59
15.42

15.26

10
0

40.47

40.23

37.96

40

8.63

5.96
0.07

1.20

0.60
Rajasthan

0.32

0.49

0.37
Gujarat

Small Hydro Power

4.15

Tamil Nadu

Wind Power

Bio Power

51

5.37

13.38 13.60

8.00

1.72
Karnataka

Solar Power

Maharashtra
Large Hydro

<!-- page 61 -->

10.3 Contribution of various RE sources of top 5 RE installed capacity states in RE
generation within the respective states: Share of various renewable energy (RE) sources within
the total electricity generation from RE sources of the top five states reflects distinct energy profiles shaped
by regional resources. Rajasthan dominates with solar power contributing a massive 85.61% of its total RE
generation, while wind power plays a smaller role having share of 12.10%. Other sources like Bio Power,
Small Hydro Power, and Large Hydro Power have minimal shares. Gujarat shows a more balanced approach,
with wind power leading with a share of 48.92%, followed by solar power having share of 38.88%, and large
hydro contributing 11.59%. Tamil Nadu relies heavily on wind power (45.11%) and solar power (40.98%),
with moderate contributions from large hydro (11.98%) and minor bio power and small hydro power shares.
Karnataka presents a diverse mix with solar power (32.61%), wind power (28.29%), and large hydro (29.20%)
contribute nearly equally, complemented by Bio Power (5.21%) and Small Hydro Power(4.69%). Maharashtra
has a similar spread with solar power (30.62%), wind power (30.36%), and Large Hydro (22.34%), alongside
Bio Power (13.28%) and Small Hydro Power(3.39%). (Refer Fig. 10.3)

Fig 10.3 Share of the various RE sources of top 5 RE installed capacity states within their
respective total RE generation

85.61

(During
(During 2024-25)
90
80

Gujarat

Small Hydro Power

Tamil Nadu

Wind Power

Bio Power

*****

52

30.62

30.36

22.34
3.39

4.69

1.26

0.67

0.40

0.70
Rajasthan

0.21

0

1.58

10

5.21

11.98

11.59

12.10

20

13.28

30

29.20

28.29

40

32.61

40.98

38.88

50

45.11

48.92

60

0.01

Share in RE Generation (in %)

70

Karnataka

Solar Power

Large Hydro

Maharashtra

<!-- page 62 -->

CHAPTER 11
RAJASTHAN
RAJASTHAN
11.1 ofStatus
of RE
and Non-RE
Sector
in Rajasthan:
11.1 Status
RE and
Non-RE
Sector in
Rajasthan:
Rajasthan has emerged as a leading state in India’s renewable energy transition,
Rajasthan
has
emerged
in India’s
renewable
energy
transition,
driven
driven by a sharp
rise as
in aitsleading
installedstate
capacity
in recent
years. As
on 31st
March 2025,
theby a sharp
rise in its installed
capacity
in recent
Aswas
on 31st
March
2025,
state’s total
installed
power capacity
state’s total
installed
power years.
capacity
at 47.12
GW,
withthe
renewable
energy
accounting
was at 47.12 GW, with renewable energy accounting for a dominant 72.45% share, up from 40.51% of 2017–
for a dominant 72.45% share, up from 40.51% of 2017–18. During this seven-year period,
18. During this seven-year period, Rajasthan’s renewable energy installed capacity grew from 7.29 GW to
energy
installed
capacity
grew
from 7.29 the
GW
to 34.14
GW,increase of
34.14 GW,Rajasthan’s
registering arenewable
remarkable
growth
of 368.30%
which
far surpassed
overall
capacity
registering
a
remarkable
growth
of
368.30%
which
far
surpassed
the
overall
capacity
161.88% and the modest 21.30% rise in installed capacity under Non RE. The state contributed 15.51% to
capacity
under
RE. The remained
increase
161.88% installed
and the modest
21.30%
rise in installed
the country’s
total of
renewable
capacity.
The year-on-year
growth
in RE
hasNon
consistently
state contributed
15.51% towhile
the country’s
renewable
installed
capacity.
above 12.82%,
except in 2020–21,
non-RE total
installed
capacity
witnessed
eitherThe
noyear-ongrowth or annual
growth rates
6.17%.
milestone
achieved
2021–22
when, for
thenonfirst time, the
yearbelow
growth
in RE A
hassignificant
consistently
remainedwas
above
12.82%,inexcept
in 2020–21,
while
installed RE
capacity
in
the
state
exceeded
non-RE
installed
capacity,
supported
by
a
record
annual
RE installed capacity witnessed either no growth or annual growth rates below 6.17%. A growth of
61.40%. Rajasthan’s
energy
landscape
is predominantly
shaped
solar
which
significant renewable
milestone was
achieved
in 2021–22
when, for the
first by
time,
thepower,
installed
RE expanded
exponentially
from
1000.23
MW
of
2014–15
to
28286.47
MW
by
2024–25,
reflecting
a
2728%
growth
with a
capacity in the state exceeded non-RE installed capacity, supported by a record annual
CAGR of 39.68%. Wind energy installed capacity also increased from 3308.58 MW to 5208.75 MW, marking
growth of 61.40%. Rajasthan’s renewable energy landscape is predominantly shaped by
a growth of 57.43% with a CAGR of 4.64% while bio power installations enhanced from 119.97 MW to
exponentially
1000.23 has
MWshifted
of 2014–15
to 28286.47
solar
power,
206.27 MW
during
thewhich
same expanded
period. The
technology from
composition
dramatically
over the decade
MW
by
2024–25,
reflecting
a
2728%
growth
with
a
CAGR
of
39.68%.
Wind
energy
from wind power accounting for 74.31% of RE installed capacity in 2014–15 to solar occupying a dominant
installed
also increased from 3308.58 MW to 5208.75 MW, marking a growth of
share of 83.87%
bycapacity
2024–25.
57.43% with a CAGR of 4.64% while bio power installations enhanced from 119.97 MW
Transformation
in installed
is mirrored
energy
generation
as well. During
to 206.27 MW
during capacity
the same
period. inThe
technology
composition
has 2024–25,
shifted the state
generated adramatically
total of 130.77
Units (BU)
electricity,
out of which
BU amounting
to 43.86% was
overBillion
the decade
from of
wind
power accounting
for57.35
74.31%
of RE installed
generated from
renewable
sources.
Rajasthan
was
the
highest
electricity
generating
state
from
RE sources in
capacity in 2014–15 to solar occupying a dominant share of 83.87% by 2024–25.
the country during the year, contributing 14.21% of India’s total renewable generation. For energy generated
from solar, wind, bio power, and small hydro power, Rajasthan maintained its top position, producing 56.45
Transformation
in installed
capacityofiselectricity
mirrored of
in the
energy
generation
as well. Energy
BU accounting for
22.14 % of the
total generation
country
from Renewable
sources. During 2024–25, the state generated a total of 130.77 Billion Units (BU) of electricity, out
of which 57.35 BU amounting to 43.86% was generated from renewable sources. Rajasthan
was the
highest electricity
stateNon-RE
from REsector
sourcessince
in the2017-18
country during
the year,
Details
of installed
capacity generating
under RE and
, installed
capacity under
Solar Power,
Wind
Power,
Small
Hydro
Power
since
2014-15,
electricity
generation
from
various
contributing 14.21% of India’s total renewable generation. For energy generated from solar, sources of
Renewablewind,
Energy
analysis
in respect
of the maintained
state of Rajasthan
is elaborated
in this chapter.
biosector
power,and
andtheir
small
hydro power,
Rajasthan
its top position,
producing
56.45 BU accounting for 22.14 % of the total generation of electricity of the country from
Renewable Energy sources.
Details of installed capacity under RE and Non-RE sector since 2017-18 , installed
capacity under Solar Power, Wind Power, Small Hydro Power since 2014-15, electricity
generation from various sources of Renewable Energy sector and their analysis in respect
of the state of Rajasthan is elaborated in this chapter.

53

53

<!-- page 63 -->

INSTALLED CAPACITY
Table 11.1.1: Installed Capacity IN RE and Non-RE sector since 2014-15
(in
(in MW)
MW)
Year

Non-RE

Total

7289.36
8223.73
10134.97
10812.35
17451.62
22809.05
27103.89
34136.34
368.30%

10703.13
11363.13
12023.13
12023.13
12683.13
12682.83
12982.83
12982.83
21.30%

17992.49
19586.86
22158.10
22835.48
30134.75
35491.88
40086.72
47119.17
161.88%

24.68%

2.80%

14.74%

RE

2017-18
2018-19
2019-20
2020-21
2021-22
2022-23
2023-24
2024-25
Gr (2017-18 to
2024-25)
CAGR (2017-18
to 2024-25)

Share (%)
RE
Non-RE
40.51
59.49
41.99
58.01
45.74
54.26
47.35
52.65
57.91
42.09
64.27
35.73
67.61
32.39
72.45
27.55

Growth (%)
RE
Non-RE
12.82
23.24
6.68
61.40
30.70
18.83
25.95

6.17
5.81
0.00
5.49
0.00
2.37
0.00

Source:
Source:NPP,
NPP,MoP
MoP&
&MNRE
MNRE

Gr=Growth (%) ,CAGR=Compound Annual Growth Rate

Fig. 11.1.1 Share of RE in Installed Capacity (in MW)

As on 31st March 2018 (MW)

As on 31st March 2025 (MW)

12982.83,
27.55%

7289.36 ,
40.51%
10703.13 ,
59.49%

Non RE

34136.34,
72.45%

RE

Non RE

RE

Over the last seven years, Rajasthan’s energy sector has undergone a major transformation, with
a clear and important move away from traditional non-renewable energy sources towards renewable energy
sources like solar and wind. As on 31st March 2018, renewable energy contributed 40.51% of the state’s total
installed power capacity, while non-renewable sources dominated with a share of 59.49%. By 31st March
2025, this scenario had reversed dramatically, renewable energy capacity commanding a share of 72.45% ,
whereas share of non-renewable reduced to 27.55% of the total.

54

<!-- page 64 -->

Fig 11.1.2 Trend in installed Capacity
40
35

Ins ta lle d Ca p a c ity (in GW)

34.14
30
27.10

25
22.81

20
17.45
15
10.70

11.36

10
7.29

5
0

2017-18

12.02

12.02

10.13

10.81

2019-20

2020-21

12.68

12.68

12.98

12.98

2021-22

2022-23

2023-24

2024-25

8.22

2018-19

Non-RE

RE

Fig 11.1.3 Growth (%) in installed Capacity
70
61.40
60

Growth (in % )

50
40
30.70
30
20
10
0

25.95

23.24
18.83
12.82

6.17

5.81

6.68

5.49

0.00
2018-19

2019-20

0.00

2020-21

2021-22

2022-23

-10
Non-RE

55

RE

2.37
2023-24

0.00
2024-25

<!-- page 65 -->

Rajasthan has demonstrated remarkable growth in installed RE capacity between 2017–18 and 2024–
25. The installed capacity under RE sector expanded from 7,289.36 MW of 2017–18 to 34,136.34 MW
by 2024–25, registering a phenomenal overall growth of 368.30% and a Compound Annual Growth Rate
(CAGR) of 24.68%. The most significant annual increase occurred in 2021–22, when the state added over
61% more installed capacity than the previous year.
On the other hand, the installed capacity of Non-RE sector in the state has remained largely stagnant
over the same period. It increased only slightly from 10,703.13 MW of 2017–18 to 12,982.83 MW by 2024–
25, representing a modest 21.30% overall growth with a CAGR of just 2.80%. Notably, Non-RE installed
capacity saw no addition in multiple years. The widening gap between RE and Non-RE growth underscores
Rajasthan’s strategic transition towards a cleaner energy and its critical role in achieving India’s national
renewable energy targets.

11.2 Installed Capacity under Wind, Solar, Small Hydro & Bio Energy (RES):
Renewable energy landscape of Rajasthan has transformed significantly over the past decade, with
solar power leading the growth. Installation of Solar power capacity has registered a Compound Annual
growth rate of 39.68% and that of wind power was 4.64%. Details of installed capacity under RES is given in
the Table 11.2.1.

Table 11.2.1: Installed Capacity under Solar, wind, Bio Power and Small Hydro Power
(RES) since 2014-15
(in MW)
Year

23.85

3308.52

119.97

1000.23

4452.57

Growth
(%)
20.83

2015 -16
2016 -17

23.85
23.85

3994.02
4281.72

119.97
125.13

1346.09
1907.99

5483.93
6338.69

23.16
15.59

2017 -18
2018 -19

23.85
23.85

4297.72
4299.72

125.13
125.13

2431.66
3364.03

6878.36
7812.73

8.51
13.58

2019 -20

23.85

4299.72

125.13

5275.27

9723.97

24.46

2020 -21
2021 -22

23.85
23.85

4326.82
4326.82

125.08
125.08

5925.6
12564.87

10401.35
17040.62

6.97
63.83

2022 -23
2023 -24

23.85
23.85

5193.42
5195.82

125.08
125.64

17055.7
21347.58

22398.05
26692.89

31.44
19.18

2024 -25

23.85

5208.75

206.27

28286.47

33725.34

26.35

Gr (2014-15 to
202 4-25)

0.00%

57.43%

71.93%

2728.00%

657.44%

CAGR (2014-15
to 202 4-25)

0.00%

4.64%

5.57%

39.68%

22.44%

2014 -15

Small
Power

Hydro

Wind Power

Bio-Power

Gr=Growth (%)
CAGR=Compound Annual Growth Rate

56

Solar Power

Total

<!-- page 66 -->

Fig 11.2.1 Share (%) in Cumulative Installed capacity
As on 31st March 2025 (MW)

As on 31st March 2015 (MW)
119.97 ,
2.69%

23.85 ,
0.54%

23.85,
0.07%
5208.75,
15.44%

1000.23 ,
22.46%

206.27,
0.61%

28286.47,
83.87%

3308.52 ,
74.31%

Small Hydro Power

Wind Power

Small Hydro Power

Wind Power

Bio-Power

Solar Power

Bio-Power

Solar Power

While comparing the renewable energy installed capacity under Solar Power , Wind power, Small
Hydro Power and Bio Power as on 31st March 2015 and 31st March 2025, it is observed a clear and significant
shift towards solar power. As on 31st March 2015 , wind power dominated with 74.31%, followed by solar
power with a share of 22.46%. By 31st March 2025, share of solar power has surged dramatically to 83.87%,
becoming the dominant source while share of wind power reduced to 15.44%.

Fig 11.2.2 Trend in cumulative Installed Capacity
30000

Installed Capacity (in MW)

Installed Capacity (in MW)

250
200
150
100
50
0

25000
20000
15000
10000
5000

0

Small Hydro Power

Bio-Power

Wind Power

Solar Power

Graphs show the installed capacity for small hydro power remained nearly constant at around 23.85 MW
from 2014-15 to 2024-25, showing no significant growth. Bio-power installed capacity stayed stable at
approximately 125 MW until 2023-24, after which it saw a sharp increase to about 206 MW in 2024-25. In

57

<!-- page 67 -->

contrast, wind power capacity experienced moderate growth from 3308.52 MW of 2014-15 to 5208.75 MW
by 2024-25. The most dramatic change occurred in solar power installed capacity, which grew exponentially
from 1000.23 MW of 2014-15 to a staggering 28,286.47 MW by 2024-25, highlighting solar energy’s rapid
expansion and dominance in the renewable energy sector in the state of Rajasthan.

Fig 11.2.3 Year wise growth (%) in installed capacity
120

Growth(in %)

100

80

60

40

20

0

-20

201415

201516

201617

201718

201819

201920

202021

202122

202223

202324

202425

Small Hydro Power

0.00

0.00

0.00

0.00

0.00

0.00

0.00

0.00

0.00

0.00

0.00

Wind Power

18.80

20.72

7.20

0.37

0.05

0.00

0.63

0.00

20.03

0.05

0.25

Bio-Power

0.00

0.00

4.30

0.00

0.00

0.00

-0.04

0.00

0.00

0.45

64.18

Solar Power

32.26

34.58

41.74

27.45

38.34

56.81

12.33

112.04

35.74

25.16

32.50

The growth rates highlight significant variation among renewable energy sources between 2014-15
and 2024-25. Small Hydro Power remained stagnant with zero growth throughout the period. Wind Power
experienced fluctuating growth, with peaks in 2015-16 (20.72%) and 2022-23 (20.03%), but mostly remained
under 10% in other years. Solar Power demonstrated the most dynamic growth, with consistently high rates,
peaking at 112.04% in 2021-22. Although growth slowed in some years, solar energy maintained robust
expansion, underscoring its emerging dominance in renewable installed capacity growth.

58

<!-- page 68 -->

ENERGY GENERATION
11.3 Energy generation during 2024-25:
During 2024–25, Rajasthan generated a total of 130.77 Billion Units (BU) of electricity, out of which
57.35 BU amounting to 43.86% was generated from renewable sources. Rajasthan was the highest electricity
generation state from RE sources in the country during the year, contributing 14.21% of India’s total electricity
generation from RE sources. In the case of electricity generation from solar, wind, bio power, and small
hydro power, Rajasthan maintained its top position, producing 56.45 BU accounting for 22.14 % of the total
electricity generation. Solar power was the major contributor from RE sector with 49.10 BU, representing
37.55% of the total electricity generation of the state. Wind power followed with 6.94 BU (5.31%), while
bio-power and small hydro power contributed marginally with 0.40 BU (0.31%) and 0.004 BU (0.0032%),
respectively. Additionally, large hydro power accounted for 0.91 BU, comprising 0.69% of total generation
from RE sources in the state.

Fig 11.3.1 RE share in total energy generation during 2024-25
( in MU)

49101.62,
37.55%

73418.1, 56.14%

57353.68, 43.86%

400.85, 0.31%

6941.26, 5.31%

905.8,
0.69%
4.15,
0.00%

Non RE

Small Hydro Power

Wind Power

*****

59

Bio Power

Solar Power

Large Hydro

<!-- page 69 -->

CHAPTER 12
GUJARAT

12.1

Status of RE and Non-RE sector in Gujarat:

As on 31st March 2025, Gujarat emerged as the second-largest contributor to India’s
electricity installed capacity under RE sector, following Rajasthan, with a total RE
installation of 33.39 GW, representing 15.17% of the national installed capacity under RE
sector. Over the seven-year period from 2018-19 to 2024–25, Gujarat’s RE installed
capacity expanded significantly from 9.34 GW to 33.39 GW, registering a 257.55% growth
and reflecting a CAGR of approximately 19.96%. Electricity installed capacity under NonRE sector increased only marginally, from 23.49 GW to 24.83 GW, a modest 5.73% growth
with a CAGR of 0.80%. Share of RE in the state’s total installed capacity enhanced from
28.45% of 2017–18 to 57.36% by 2024–25, indicating a structural transformation in its
installed capacity. The year 2024–25 marked a notable milestone with an annual RE
capacity addition of around 6000 MW driven largely by solar energy installed capacity.
Solar energy remained the backbone of Gujarat’s RE portfolio, accounting for 18.50 GW
covering 58.90% of the total RE installed capacity in the state , followed by wind energy
with installed capacity of 12.68 GW covering share of 40.37%.
However, in terms of electricity generation from RE sources , wind energy took the
lead, contributing 48.92% of the total RE generation in the state, while solar power
accounted for 38.88%. During 2024–25, Gujarat generated 52 BU of electricity from
renewable sources, which constituted 32.97% of its total electricity generation. This
performance positioned Gujarat as the second -highest state in the country in terms of
electricity generation from Renewable Energy Sources, contributing 12.88% to India’s total
renewable energy generation. Furthermore, Gujarat ranked second in combined electricity
generation from solar, wind, bio power , and small hydro power, producing 45.97 BU of
electricity, which amounted to 18.03% of the national total from these technologies.
Details of installed capacity under RE and Non-RE sector since 2017-18 , installed
capacity under Solar Power, Wind Power, Small Hydro Power since 2014-15, electricity
generation from various sources of Renewable Energy sector and their analysis in respect
of the state of Gujarat is elaborated in this chapter.

60

<!-- page 70 -->

INSTALLED CAPACITY
Table 12.1.1 Installed Capacity under RE and Non-RE sector since 2017-18
(in MW)

Year

Non-RE

RE

2017-18
2018-19
2019-20
2020-21
2021-22
2022-23
2023-24
2024-25
Gr (2017-18 to
2024-25)
CAGR (2017-18
to 2024-25)

Total

9339.39
10697.72
12683.77
15204.25
18577.90
21425.85
27461.72
33393.03
257.55%

23483.41
23483.41
24223.41
24083.41
24083.41
24083.41
25483.41
24828.41
5.73%

32822.00
34181.13
36907.18
39287.66
42661.31
45509.26
52945.13
58221.44
77.39%

19.96%

0.80%

8.53%

Share (%)
RE
28.45
31.30
34.37
38.70
43.55
47.08
51.87
57.36

Growth (%)

Non-RE

RE

71.55
68.70
65.63
61.30
56.45
52.92
48.13
42.37

14.54
18.57
19.87
22.19
15.33
28.17
21.60

Non-RE
0.00
3.15
-0.58
0.00
0.00
5.81
-2.57

Source:
NPP,
& MNRE
Source:
NPP,
MoPMoP
& MNRE

Gr=Growth (%)
CAGR=Compound Annual Growth Rate

Fig. 12.1.1 Share of RE Installed Capacity
As on 31st March 2018 (MW)

As on 31st March 2025 (MW)

9339.39,
28.45%

24828.41 ,
42.64%

33393.03 ,
57.36%

23483.41 ,
71.55%

Non RE

RE

Non RE

RE

The pie charts compare the installed capacity under RE sector and Non- RE sector in Gujarat as on
31st March 2018 and 31st March 2025. As on 31st March 2018, Non-Renewable Energy (Non-RE) dominated
with 71.55% while Renewable Energy (RE) contributed 28.45%. By 31st March 2025, this balance shifts
significantly, with RE installed capacity rising to 57.36% and Non-RE installed capacity declining to 42.64%.

61

<!-- page 71 -->

Fig12.1.2 Trend in installed Capacity
40
33.39

Ins ta lle d Ca p a c ity (GW)

35
30

27.46
23.48

25

23.48

24.22

24.08

24.08

24.83

2023-24

2024-25

21.43

18.58

20

25.48

24.08

15.2

15

9.34

10

10.7

12.68

5
0

2017-18

2018-19

2019-20

2020-21

2021-22

RE

2022-23

Non RE

The graph shows the trend of installed capacity under Renewable Energy (RE) and Non-Renewable
Energy (Non-RE) sources from 2017-18 to 2024-25. RE installed capacity exhibits a steady and significant
increase from 9.34 GW of 2017-18 to 33.39 GW by 2024-25, reflecting strong growth. On the contrary,
installed capacity under Non-RE remains almost flat, fluctuating slightly around 24 GW throughout the
period. Notably, RE installed capacity surpasses Non-RE installed capacity around 2023-24, marking a
pivotal shift towards cleaner energy sources.

Fig 12.1.3 Year wise Growth (%) in installed Capacity
30
28.17
25

22.19
18.57

Growth (in % )

20
15

21.60

19.87

15.33

14.54

10
5.81
3.15

5
0
-5

0.00

2018-19

2019-20

-0.58

0.00

2020-21

2021-22

0.00
-2.57

RE

Non-RE

62

2022-23

2023-24

2024-25

<!-- page 72 -->

Year-wise growth in capacity installation reveals a clear contrast between renewable energy (RE) and
non-renewable energy (Non-RE) sectors from 2018-19 to 2024-25. Renewable energy shows consistent and
strong growth throughout this period, starting at 14.54% in 2018-19 and reaching a peak of 28.17% in 202324, before slightly declining to 21.60% in 2024-25. This indicates a steady expansion and increasing focus
on renewable sources whereas non-renewable energy growth remains largely stagnant, fluctuating near zero
with occasional small positive growth, such as 3.15% in 2019-20 and 5.81% in 2023-24, but also experiencing
declines in installed capacity by 2.57% during 2024-25.

12.2

Installed capacity under Solar, Wind, Bio Power and Small Hydro Power (RES):

Gujarat’s renewable energy landscape has transformed significantly over the past decade, marked by
robust growth across all major clean energy technologies. Solar power has emerged as the leading driver of
this transformation, registering a remarkable increase of 1728.29% from 2014–15 to 2024–25, with a high
CAGR of 33.72%. Wind power, a traditional strength of Gujarat, also saw steady growth of 256.49% over
same period, with a CAGR of 13.55%. A key milestone was achieved in 2023–24, when installed capacity
under solar power surpassed that of wind power for the first time and the trend has continued during 2024-25
also. Meanwhile, bio-power and small hydro power grew by 54.98% and 544.74% respectively during the
period with consistent capacity additions over the years. Details of installed capacity under Solar power, Wind
Power, Bio Power and Small Hydro Power is given in Table 12.2.1.

Table 12.2.1: Installed Capacity under solar, wind, bio power and small hydro power
(RES) since 2014-15
(in MW)
Year

Wind Power

Bio-Power

Solar Power

3556.22
3948.62
5340.62
5613.42
6073.07
7541.52
8561.82
9209.22
9978.92
11722.72
12677.48
256.49%

78.88
78.92
79.99
81.24
95.03
96.53
99.87
109.26
110.73
112.48
122.25
54.98%

1011.69
1137.82
1278.19
1626.19
2478.32
2986.77
4469.87
7180.03
9254.56
13544.88
18496.66
1728.29%

4663.33
5181.9
6715.34
7349.39
8707.66
10693.77
13214.25
16587.90
19435.85
25471.72
31403.03
573.40%

CAGR (2014-15
20.49%
13.55%
to 2024-25)
Gr=Growth (%)
CAGR=Compound Annual Growth Rate(%)

4.48%

33.72%

21.01%

2014-15
2015-16
2016-17
2017-18
2018-19
2019-20
2020-21
2021-22
2022-23
2023-24
2024-25
Gr (2014-15 to
2024-25)

Small Hydro
Power
16.54
16.54
16.54
28.54
61.24
68.95
82.69
89.39
91.64
91.64
106.64
544.74%

63

Total

Growth (%)
6.55
11.12
29.59
9.44
18.48
22.81
23.57
25.53
17.17
31.06
23.29

<!-- page 73 -->

Fig 12.2.1 Share of various sources in RES Cumulative Installed capacity
As on 31st March 2025 (MW)

As on 31st March 2015 (MW)
16.54,
0.35%

78.88,
1.69%

106.64,
0.34%
12677.48,
40.37%

1011.69,
21.69%
18496.66,
58.90%
3556.22,
76.26%

122.25,
0.39%
Small Hydro Power

Wind Power

Small Hydro Power Wind Power

Bio-Power

Solar Power

Bio-Power

Solar Power

As on March 2015, Gujarat’s renewable energy landscape was primarily driven by wind power, which
held a dominant share of 76.26% followed by Solar power accounting for 21.69% of the total renewable
energy installed capacity. Bio-power contributed a modest 1.69% while Small Hydro Power had the least
presence with a share of 0.35%.
A decade later, as on 31st March 2025, renewable energy profile of the state underwent a significant
transformation. Installed capacity under solar power emerged as the leading source, commanding a share of
58.90% . Wind power, although still significant, had a reduced share of 40.37%. Bio-power and Small Hydro
Power maintained marginal shares of 0.39% and 0.34% respectively.

Fig 12.2.2 Trend in cumulative Installed Capacity
20000

Installed Capacity (in MW)

Installed Capacity (in MW)

120
100
80
60
40
20
0

18000
16000
14000
12000
10000
8000
6000
4000
2000
0

Small Hydro Power

Bio-Power

Wind Power

64

Solar Power

<!-- page 74 -->

The cumulative installed capacity trends from 2014-15 to 2024-25 show varied growth patterns across
renewable energy sources. Small Hydro Power steadily increases, particularly after 2017-18, reaching over
100 MW by 2024-25. Bio-Power capacity remains relatively stable, with only slight growth. Wind Power
experiences consistent growth, rising from around 3,500 MW to nearly 12700 MW, though its pace slows after
2022-23. Solar Power shows the most significant surge, starting at about 1,000 MW and accelerating sharply
after 2018-19 to reach around 18,500 MW by 2024-25, overtaking wind power. This highlights solar energy
as the fastest-growing renewable source, driving the overall expansion in renewable installed capacity.

Fig 12.2.3 Year wise growth (%) in installed capacity
140

Growth (in %)

120

100

80

60

40

20

0

201415

201516

201617

201718

201819

201920

202021

202122

202223

202324

202425

Small Hydro Power

6.41

0.00

0.00

72.29

114.34

12.48

19.93

8.10

2.52

0.00

16.37

Wind Power

5.67

11.03

35.25

5.11

8.19

24.18

13.53

7.56

8.36

17.47

8.14

Bio-Power

14.35

0.05

1.36

1.56

16.97

1.58

3.46

9.40

1.35

1.58

8.69

Solar Power

9.17

12.47

12.34

27.23

52.40

20.52

49.66

60.63

28.89

46.36

36.56

Year-wise growth (%) in installed capacity across renewable energy sources from 2014-15 to 202425 reveals distinct patterns. Small Hydro Power saw its most significant surge between 2017-18 and 201819, peaking at 114.34%, followed by a sharp decline and more modest growth in later years. Wind Power
experienced fluctuating growth, with a peak of 35.25% in 2016-17, but growth slowed considerably in the
following years, showing intermittent increases. Growth in installed capacity under Bio-Power remained
largely stagnant, with minor spikes in 2014-15 and 2018-19, indicating limited expansion. In contrast, Solar
Power displayed consistent and robust growth, especially from 2016-17 to 2021-22, with a high of 60.63%
in 2021-22. Despite minor dips, it remained the leading contributor to renewable energy capacity expansion.
Overall, the data highlights solar energy as the primary growth driver, while other sources showed slower or
inconsistent increases.

65

<!-- page 75 -->

ENERGY GENERATION
12.3 Energy Generation during 2024-25:
During 2024–25, Gujarat recorded a total electricity generation of 157.73 BU, of which 52 BU equivalent
to 32.97%, was generated from renewable energy (RE) sources. Among the renewable sources, wind power
emerged as the leading contributor with 25.44 BU, followed closely by solar power, which generated 20.22
BU. Together, wind and solar accounted for over 87.80% of the total electricity generation from RE sources
in the state. Large hydro power contributed 6.03 BU, while small hydro power and bio-power added 0.21 BU
and 0.11 BU, respectively.
Importantly, Gujarat held the second position nationally in electricity generation from renewable
energy sources during the year, with its 52 BU of electricity generation accounting for 12.88% of India’s total
electricity generation from renewable energy sources. Gujarat also ranked second in electricity generation
from solar, wind, bio-power, and small hydro power combined with a total of 45.97 BU, contributing 18.03%
to the country’s cumulative electricity generation from these technologies. Fig 10.3 depicts the detailed share
of electricity generation from RE and Non-RE sources in the total energy generation in the state of Gujarat.

Fig 12.3.1 RE share in total electricity generation during 2024-25

(in MU)

107.62,
0.07%

20219.48,
12.82%
105728.84, 67.03%

52002.5, 32.97%
25440.9,
16.13%
6028.52,
3.82%
205.98, 0.13%

Non RE

Small Hydro Power

Wind Power

*****

66

Bio Power

Solar Power

Large Hydro

<!-- page 76 -->

CHAPTER 13
TAMIL NADU
TAMIL NADU

13.1 Status of RE and Non-RE sector in Tamil Nadu: Tamil Nadu continues to

play a leading role in India's renewable energy landscape, demonstrating consistent
growth in both electricity installed capacity and electricity generation. As on 31st March
2025, total installed electricity capacity in the state reached at 43.08 GW, out of which
25.24 GW was from renewable energy sources. This translates to a 58.59 % share of
renewable energy in the total installed capacity, up from 44.70 % of 2017–18. Over this
period, renewable energy installed capacity in the state has grown by 87.64 %, with a
CAGR of 9.41 %, significantly outpacing the growth of non-renewable energy installed
capacity. With this achievement, Tamil Nadu secured the third position nationally in
terms of renewable energy installed capacity, contributing 11.47 % to the country's total
as on 31st March 2025. Wind power continues to be the leading source in Tamil Nadu’s
renewable energy installed capacity reaching 11.74 GW by 2024–25, a growth of over
57 % since 2014–15. The most striking increase has been observed in solar energy, which
surged from 0.16 GW of 2014–15 to 10.15 GW by 2024–25, reflecting a growth of over
6,374 % and a CAGR of 51.75%.
In terms of electricity generation, Tamil Nadu recorded a total of 130.12 BU
during 2024–25, of which 38.41 BU having share of 29.52 % was generated from
renewable energy sources. Wind power was the largest contributor within the renewable
segment, followed by solar power. At the national level, Tamil Nadu ranked fifth in total
renewable energy generation, accounting for 9.52% of the country’s electricity
generation from Renewable energy sources. The state also ranked fourth in electricity
generation from solar, wind, bio-power, and small hydro power combined, with a total
of 33.81 BU, representing 13.26 % of the national total from these technologies. The
next sections present an in-depth review of Tamil Nadu's electricity profile, emphasizing
the growth of Renewable Energy sector.
Details of installed capacity under RE and Non-RE sector since 2017-18,
installed capacity under Solar Power, Wind Power, Small Hydro Power since 2014-15,
electricity generation from various sources of Renewable Energy sector and their
analysis in respect of the state of Tamil Nadu is elaborated in this chapter.

67

<!-- page 77 -->

INSTALLED CAPACITY
Table 13.1.1 Installed Capacity in RE and Non-RE sector since 2017-18
(in MW)
Year

Non-RE

RE

Share (%)

Total

RE

Growth (%)

Non-RE

RE

Non-RE

2017-18

13451.72

16638.88

30090.60

44.70

55.30

2018-19

14909.39

16338.88

31248.27

47.71

52.29

10.84

-1.80

2019-20

16588.84

16688.88

33277.72

49.85

50.15

11.26

2.14

2020-21

17476.67

16838.88

34315.55

50.93

49.07

5.35

0.90

2021-22

18277.50

17363.88

35641.38

51.28

48.72

4.58

3.12

2022-23

20098.55

17363.88

37462.43

53.65

46.35

9.96

0.00

2023-24

22161.62

17778.00

39939.62

55.49

44.51

10.26

2024-25

25241.36

17841.38

43082.74

58.59

41.41

13.90

2.38
0.36

Gr (2017-18 to
2024-25)
CAGR (2017-18
to 2024-25)

87.64%

7.23%

43.18%

9.41%

1.00%

5.26%
Source : NPP, MoP and MNRE

Gr=Growth (%)
CAGR=Compound Annual Growth Rate

Fig. 13.1.1 Share in RE Installed Capacity (in MW)
As on 31st March 2018 (MW)

As on 31st March 2025 (MW)

13451.72 ,
44.70%

17841.38,
41.41%

16638.88 ,
55.30%

Non RE

25241.36 ,
58.59%

RE

Non RE

RE

The pie charts clearly depict a significant shift in the installed capacity as on 31st March 2018 and
31 March 2025, marked by a growing dominance of Renewable Energy (RE) in the total installed capacity.
As on 31st March 2018, RE accounted for 44.70% of the total installed capacity, while Non-Renewable
Energy (Non-RE) held the majority share of 55.30%. However, by 31st March 2025, the scenario had
reversed, RE installations surged to a 58.59% share, whereas Non-RE’s share declined to 41.41%.
st

68

<!-- page 78 -->

Fig 13.1.2 Trend in installed Capacity
30
25.24

Installed Capacity(GW)

25

22.16

20

16.64
13.45

15

16.34

18.28

17.48

16.69

14.91

16.59

2018-19

2019-20

20.10

16.84

17.36

17.36

2020-21

2021-22

2022-23

17.78

17.84

2023-24

2024-25

10
5
0

2017-18

RE

Non-RE

The graph illustrates the installed capacity under Renewable Energy (RE) and Non-Renewable Energy
(Non-RE) sources from 2017-18 to 2024-25. As on 31st March 2018, RE installed capacity was at 13.45
GW, noticeably lower than 16.64 GW. Over the years, installed capacity under RE witnessed consistent and
accelerated growth, surpassing Non-RE in 2020-21, where RE reached 17.48 GW compared to 16.84 GW of
capacity installations under Non-RE. The gap between the two lines continued to widen thereafter. By 202425, RE capacity surged to 25.24 GW, while Non-RE grew modestly to 17.84 GW, expanding the gap to 7.4
GW in favour of RE.

Fig 13.1.3 Year wise growth (%) in installed capacity
Fig 13.1.3 Year wise growth (%) in installed capacity
16

13.90

14
12

10.84

11.26
9.96

Growth (in % )

10

10.26

8
5.35

6
4

3.12

2.14

2
0

4.58

0.90

2.38
0.36

0.00

-1.80

-2
-4

2018-19

2019-20

2020-21

2021-22
RE

Non-RE

69

2022-23

2023-24

2024-25

<!-- page 79 -->

The graph shows the year-wise growth (%) in installed capacity under Renewable Energy (RE) and
Non-Renewable Energy (Non-RE) sources from 2018-19 to 2024-25. Installed capacity under RE exhibits
a consistently higher growth rate than that of Non-RE throughout the period, reflecting strong momentum
in renewable sector expansion. RE growth peaked at 13.90% in 2024-25, following a gradual rebound from
a dip to 4.58% in 2021-22. However, Non-RE growth remained subdued, even turning negative in 201819 (-1.80%), and never exceeding 3.12% in any year. The fluctuating but overall stagnant trend in Non-RE
contrasts sharply with the accelerating growth in RE.

13.2

Installed Capacity under Wind, Solar, Small Hydro & Bio Energy (RES):

Installed capacity under Renewable Energy Sources (RES) in Karnataka has seen significant growth
from 2014-15 to 2024-25, primarily driven by solar power. Installed capacity under solar witnessed an
exponential rise from 156.83 MW in 2014-15 to 10,153.58 MW by 2024-25, marking an exceptional growth
of 6374.26% and a CAGR of 51.75%. Wind power, while already established, grew steadily from 7,455.09
MW to 11,739.91 MW, registering an increase of 57.48% with a CAGR of 4.65%. Bio-power showed
marginal growth of 13.02% over the decade, increasing from 926.06 MW to 1,046.62 MW, with a low CAGR
of 1.23%, indicating limited addition of installed capacity. In contrast, small hydro power remained unchanged
at 123.05 MW throughout the period. Overall, total installed capacity under RES expanded from 8,661.03
MW to 23,063.16 MW, a rise of 166.29% with a CAGR of 10.29%, underscoring a decisive shift towards
renewable energy, predominantly led by solar capacity installations. Installed capacity under RES sector from
2014-15 is stipulated in Table 13.2.1.

Table 13.2.1: Installed Capacity under Solar, wind, Bio Power and Small Hydro Power
(RES) since 2014-15
(in MW)
Small Hydro
Year
Power
Wind Power
2014-15
123.05
7455.09
2015-16
123.05
7613.89
2016-17
123.05
7861.46
2017-18
123.05
8197.09
2018-19
123.05
8968.91
2019-20
123.05
9304.34
2020-21
123.05
9608.04
2021-22
123.05
9866.37
2022-23
123.05
10017.17
2023-24
123.05
10603.54
2024-25
123.05
11739.91
Gr(2014-15 to
0.00%
57.48%
2024-25)
CAGR(2014-15
0.00%
4.65%
to 2024-25)
Gr=Growth (%)
CAGR=Compound Annual Growth Rate

Bio-Power
926.06
926.06
926.67
977.52
1020.52
1021.69
1039.91
1042.70
1043.70
1045.45
1046.62
13.02%

Solar Power
156.83
1090.57
1728.52
1950.86
2618.71
3961.56
4527.47
5067.18
6736.43
8211.38
10153.58
6374.26%

1.23%

51.75%

70

Total
8661.03
9753.57
10639.7
11248.52
12731.19
14410.64
15298.47
16099.3
17920.35
19983.42
23063.16
166.29%
10.29%

Growth (%)
3.10
12.61
9.09
5.72
13.18
13.19
6.16
5.23
11.31
11.51
15.41

<!-- page 80 -->

Fig 13.2.1 Share (%) in Cumulative Installed capacity
As on 31st March 2015 (MW)
156.83 ,
1.81%

926.06 ,
10.69%

123.05,
0.53%

123.05 ,
1.42%

As on 31st March 2025 (MW)

10153.58,
44.03%

11739.91,
50.90%

7455.09 ,
86.08%
1046.62,
4.54%
Small Hydro Power

Wind Power

Small Hydro Power

Wind Power

Bio-Power

Solar Power

Bio-Power

Solar Power

Composition of Tamil Nadu’s renewable energy installed capacity has undergone a major transformation
over the past decade. Wind power dominated with a share of 86.08% having 7455.09 MW installation, followed
by Bio-Power installation of 926.06 MW with a share of 10.69%. Solar power had a share of 1.81% having
installation of 156.83 MW and Small Hydro Power had the least share of 1.42% with a cumulative installation
of 123.05 MW. However, as on 31st March 2025, Tamil Nadu’s renewable energy landscape became more
diversified. Wind power continued to hold the highest share at 50.90% with an installed capacity of 11.74 GW.
Solar power registered a significant increase, contributing 44.03% with 10.15 GW, emerging as the secondlargest source. Bio-power accounted for 4.54% with 1.05 GW, while small hydro power constituted 0.53% of
the total renewable capacity, with no change in its installed capacity.

14000

1000

12000

Installed Capacity (MW)

1200

800
600
400

Small Hydro Power

10000
8000

6000
4000
2000
0

2024-25

2023-24

2022-23

2021-22

2020-21

2019-20

2018-19

2016-17

2015-16

0

2017-18

200

2014-15

Installed Capacity (MW)

Fig 13.2.2 Trend in cumulative Installed Capacity

Wind Power

Bio-Power

71

Solar Power
