---
doc_id: "e8e64910daab4fab"
source_url: "https://www.mea.gov.in/images/26-r-s-legalheirs.pdf"
ministry: "External Affairs (MEA)"
title: "Transfer of Registration Certificate issued under the Emigration Act, 1983 to the legal heirs"
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "08ceb2ab46c1d9ee"
---

<!-- page 1 -->

No. Z-11025/252/2013-Emig.
Government of India
Ministry of Overseas Indian Affairs
&&&
Akbar Bhawan, Satya Marg, Chankyapuri,
New Delhi-110 021, Dated 2. & November, 2013
To

All Protectors of Emigrants

Subject: Regarding transfer of Registration Certificate issued under the
Emigration Act, 1983 to the legal heirs.
Sir,

I am directed to say that the issue relating to transfer of
Registration Certificate issued under the Emigration Act, 1983 to the legal
heirs raised during the meeting held on 5 June, 2013 under the
Chairmanship of the Hon’ble Minister of Overseas Indian Affairs with the
representatives of RAs Associations has been considered and a view has
been taken that if the proprietor of the agency requests transfer of the
Registration certificate in the name of his legal heir or a legal heir of the
proprietor of the recruiting agency applies for grant of the existing RC to

___ be issued in his name, this will be considered subject to the condition that

the legal heir fulfils all requirements as per the Emigration Act/Rules and

instructions, and if found to be eligible, a fresh Registration Certificate will
be issued in the same title of the Agency.

2. This issues with the approval of the competent authority.
Yours faithfully, .
/ NN OTEANAS

हु (Krishan Kumar)

Deputy Secretary to the Govt. of India

Tel. No. 011-24197910
