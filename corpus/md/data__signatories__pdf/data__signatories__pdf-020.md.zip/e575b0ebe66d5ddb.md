---
doc_id: "e575b0ebe66d5ddb"
source_url: "https://www.isro.gov.in/media_isro/pdf/Tenders/2026/PTH_02_12062026.pdf"
ministry: "Department of Space"
title: "URSC/PUBLIC TENDER NOTICE NO.PT-H-02/26-27 Dated:09.06.2026      316.42 KB"
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b7bfd3779b4e8074"
---

<!-- page 1 -->

भारत सरकार, अंतररक्ष तवभाग /Government of India, Department of Space
यू.आर. राव उपग्रह केन्द्र (यू.आर.एस.सी.)/ U R Rao Satellite Centre [URSC]
(पूवि में इसरो उपग्रह केन्द्र/ (Formerly known as ISRO Satellite Centre)
एच.ए.एि. एयरपोटि रोड, तवमानपुरा पोस्ट,
HAL Airport Road, Vimanapura Post,
बेंगिूरु/Bengaluru - 560 017
भारत/India

URSC/PUBLIC TENDER NOTICE NO.PT-H-02/26-27

09.06.2026

भारत के राष्ट्रपतत की ओर से व. प्रधान, क्रय एवं भंडार, यू.आर. राव उपग्रह केन्द्र(यू.आर.एस.सी.),द्वारा तनम्न तिखित
मद की आपूतति के तिए केवि ई-प्रापण के जररए तनतवदाएं आमंतित हैं ।
On behalf of the President of India, Sr. Head, Purchase & Stores, U R Rao Satellite Centre [URSC]
invites tenders ONLY through e-procurement for supply of the following.

दो भाग निनिदा/Two Part Tenders
क्र.सं.
Sl. No.

निनिदा संदभभ
TENDER REFERENCE

संनिप्त नििरण
BRIEF DESCRIPTION

01

URSC/CE/FACILITIES/2026000599

औद्योनगक श्रेणी का ऑपरे टर कंसोल

Industrial Grade Operator Console

बोली प्रस्तुत करिे की प्रारं नभक नतनि/Bid Submission Start Date

:11.06.2026 (15.00 Hrs.)

बोली स्पष्टीकरण की नतनि /Bid Clarification Date up to

:25.06.2026 (16.00 Hrs.)

बोली प्रस्तुत करिे की नियत नतनि/Bid Submission Due Date

:01.07.2026 (14.30 Hrs.)

बोली खुलिे की नतनि/Bid Opening Date

:01.07.2026 (15.00 Hrs.)

वैध तडतजटि हस्ताक्षर प्रमाणपि (डी.एस.सी) रिनेवािे इच्छु क तनतवदाकार https://eproc.isro.gov.in पर
िॉग-इन करके अपना प्रस्ताव ऑनिाईन भेज सकते हैं। कोई तनतवदा शुल्क िागू नहीं है।
Interested Tenderers having valid Digital Signature Certificate [DSC] may login to
https://eproc.isro.gov.in and submit Offers online. No Tender fees applicable.
तनतवदाएँ उपयुिक्त तवतनतदि ष्ट् ततति पर िोिी जाएँ गी। पाि तवक्रेताओं की दर बोिी (दो-भाग तनतवदाओं के मामिे में)
िुिने की समय सूची बाद में सूतचत की जाएगी। बोिी-संबंधी तववरण प्रततभागी तवक्रेताओं द्वारा इसरो ई-प्रापण पोटि ि
पर िॉग-इन करके दे िे जा सकते हैं।
Tenders will be opened on the date specified above. Schedule for opening of the Price Bid (in
case of Two Part Tenders) of Qualified Vendors will be intimated later. Bidding details can be
seen by the participated vendors by logging into ISRO e-procurement portal.
उपयुिक्त के संबंध में यतद कोई शुखददपि/अनुशेष होगा, तो उसे हमारे ई-पोटि ि एवं वेबसाइट पर प्रकातशत तकया जाएगा।
Corrigendum/Addendum, if any, related to above shall be hosted in our e- portal and Website.

Sd/ि. प्रधाि, क्रय ि भंडार /Sr. Head, Purchase & Stores
