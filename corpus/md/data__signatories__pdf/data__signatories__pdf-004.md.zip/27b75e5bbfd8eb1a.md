---
doc_id: "27b75e5bbfd8eb1a"
source_url: "https://www.labour.gov.in/static/uploads/2025/06/ab25fbd27c2ecb3b7a3fb61a0ea10d4d.pdf"
ministry: "Labour and Employment (MoLE)"
title: "Office Order No. of 2016 (12/08/2016) (Office Order- 25-2016)"
date: "2016-08-12"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3cd7f4a5ef159489"
---

<!-- page 1 -->

No. A-31011/ 07/2015-CLS.I
Government of India
Ministry of Labour & Employment

*****
New Delhi dated the 1ih August, 2016

OFFICE ORDER NO. 25 of 2016
The following Central Labour Service Officers in the Junior
Administrative Grade in the Pay Scale of PB-3(Rs.15,600-39,100) with Grade
Pay Rs. 7600/ - are granted Non-functional Selection Grade (NFSG) in the Pay
Scale of PB-4 (Rs.37,400-67,000/ -) with Grade Pay of Rs. 8700/ - in terms of
guidelines contained in DOP&T's OMs No. 28038/ 01/ 88-Estt(D) dated
09.10.1989 and No. 22/ 01/ 2000- CRD dated 06.06.2000 with effect from the
date(s) mentioned against their names:-

s.
No.

Name of the Officer
(Date of birth)
1 S.C. Sharma
(20-01-1956)

Designation & Place of
posting
LWC(C), Naval Headquarters,
New Delhi (Retired)

Date of NFSG
02.06.2015

2.

K.V. Ravindranath
(23-09-1956)

Dy.CLC(C), Hyderabad

28.05.2015

3.

K.V. Subramanian
(18-04-1959)

Dy.CLC(C), Bangalore

28.05.2015

4.

S.K. Das
(08-07-1959)

Dy.CLC(C), Dehradun

29.05.2015

5.

K.K.H.M. Syam
Sunder
(18-09-1959)
M.M.J. Rao
(04.04.1955)

Dy.CLC(C), Jabalpur

29.05.2015

Dy.CLC(C), Chennai
(Retired)
Dy.CLC(C), Dhanbad

30.04.2015

6.

03 .06.2015

7.

A.K. Samantray
(17-03-1962)

8.

S.C. Joshi
(21-07-1962)

WC(C), Ajmer

29.07.2015

9.

Srinivas Venkalaya
(18-06-1958)

LWC(C), Heavy Vehicle
Factory, Avadi, Chennai

03.06.2015

10.

D. Job Prince
(04-06-1956)

WC(C), Tirunveli
(Retired)

15.06.2015

<!-- page 2 -->

I'

t

11.

Allu K. Pratap
(15.06.1958)

Dy. CLC(C), Cochin

08.06.2015

12.

Siya Ram Saha
(09.01.1959)
Anil Kumar Sinha
(30.11.1957)

LWC(C), OFB, Kolkata

10.06.2015

WC(C), Guwahati

16.06.2015

13.
14.

Yash Pal
(01.05.1959)

Dy. CLC(C)
Delhi

01.07.2015

15.

Martin Joseph
(12.11.1958)

WC(C),
Cannore

01.08.2015

2.

The pay of all the aforesaid Officers may be fixed under FR-22(1) (a) (2).

3.

This issues with approval of the Competent Authority.

Under Secretary to the Govt. of India
Distributions:1. The Officers concerned.
2. The CLC(C), Ministry of Labour & Employment, New Dellhi.
3. DGLW, Ministry of Labour & Employment, New Delhi.
4. Labour Welfare Commissioner (Central), Naval Headquarters, Ministry
of Defence, 'A' Block, New Delhi-110011.
5. Director General Ordnance Factory Board, S.K. Bose Marg, Kolkata.
6. Personal files of the Officers concerned .
7. OL Division- for Hindi version.
8. Officer Order Bundle.
