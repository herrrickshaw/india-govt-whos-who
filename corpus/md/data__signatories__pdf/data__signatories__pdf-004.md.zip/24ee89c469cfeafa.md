---
doc_id: "24ee89c469cfeafa"
source_url: "https://mohua.gov.in/static/uploads/2025/10/486ee06438cccd43f521a143a8d181db.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Delhi Rent Control Rules,1959"
date: "1959-02-03"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "27c0fc19aa5dfb87"
---

<!-- page 1 -->

REGISTERED No. D. 221

of

The Gazette

India

EXTRAORDINARY
PART II—Section 3—Sub-section (i)

PUBLISHED BY AUTHORITY
No. 13 ]

NEW DELHI, TUESDAY, FEBRUARY 3,1959/MAGHA 14,1880

MINISTRY OF HOME AFFAIRS
NOTIFICATION
New Delhi, the 3rd February 1959
G.S.R. 139.—In exercise of the powers conferred by section 56 of the Delhi
Rent Control Act, 1958 (59 of 1958), the Central Government hereby makes the
following rules:—
CHAPTER I
PRELIMINARY

1. Short title.—These rules may be railed the Delhi Rent Control Rules, 1959
2. Definitions.—In these rules, unless the context otherwise requires,—
(a) "Act" means the Delhi Rent Control Act, 1958;
(b) "form" means a form appended to these rules;
(c) "recognised agent" means a person holding a power of attorney
authorising him to act on behalf of his principal or an agent empowered by written authority under the hand of his principal;
(d) "section" means a section of the Act.
CHAPTER II
APPLICATIONS TO THE CONTROLLER

3. Application under Sections 9, 13, 14 or 19(1).—-(1) Every application to the
Controller under section 9, section 13, section 14 or sub-section (1) of section 19
shall be in Form 'A'.
(2) An application under section 13 shall also give particulars of the sum or
consideration the circumstances under which such payment was made and
the
been contravened.
(3) An application for permission to re-let premises under sub-section (1) of
section 19 shall also state the grounds on which the premises are sought to be relet in whole or in part.
4. Application for re-entry.—An application by a tenant under sub-section (2)
of section 19 or under sub-section (3) of section 20 for putting him in possession
of thepremisesofpart thereof shall be made within six months from the date
onwhichthecause of action for re-entry arises and shall state the grounds on
which such possession is claimed.
p

r

o

v

i

s

i

o

n

of

the

Act

o

r

o

f

t

h

e

D

e

l

h

i

-

A

j

m

e

r

R

e

n

t

C

o

n

t

r

o

l

A

c

t

,

1

9

5

2

,

w

h

i

c

h

h

a

s

5. Application for recovery of possession under section 21.—An application for
recovery of possession under section 21 by the landlord shall be made within
six months from the date of expiry of the period, of tenancy.
6. Farm of other application.—An application not herein before specified in
these rules shall, so far as may be, be made in Form 'A' and shall state the
grounds on which it is made.

( 39 )

<!-- page 2 -->

_j£

lilt GA/Kll'h

O l INDIA

I.X J R A O « . l > t N A R V

[ifAK'L I t

7. Manner in which applications are to be made.—(1) Every application under
the Act shall be signed and verified in the manner prescribed under rules 14 and
15 of Order VI of the First Schedule to the, Code of Civi] Procedure, 1908, and
shall be presented by the applicant or his recognised agent to the Controller.
(2) Every such application shall be accompanied by a copy or sufficient number of copies thereof for SOTVICP on Iho respondent or respondents mentioned
therein.
8. Appearance before Controller.—A party may appear before the Controller
either in person or by a recognised agent provided that if the Controller so directs
tho party shall appear in person.
CHAPTER III
RECEIPT AND DEPOSIT OF RENT

9. Receipt of r«ot—A receipt required to be given by the landlord or his
authorised agent under subjection (2) of section 26 in respect of rent paid for
any premises shall be in Form 'B\
10. Deposit of rent.—(I) A deposit of vent under section 27 shall be made in
cash and shall be accompanied by an application by the tenant in Form 'C.
(2) On such deposit being made, the Controller shall send a copy or copies
of the application accompanying the deposit, by registered post with acknowledgment due, at the cost of the applicant, to the landlord or persons claiming to be
ftntitled to the rent with an endorsement of the. date of the deposit.
11. Payment of rent deposited.—The Controller shall order the amount of rent
deposited to be paid to the landlord or persons entitled to the rent either In
cash or by cheque.
12. Accounting of deposits,—Subject to provisions of section 29, all sums
deposited shall be treated as Civil Court deposits and accounted for and d«alt with
according to the rules of Civil Court deposits in force- in Civil Courts in Dttlhi.
CHAPTER IV
HOTELS AND LODGING HOUSES

13. Recovery ot possession from the lodger.—An application by the manager
of a hotel or the owner of a lodging house for a certificate, under section 34 shall
contain the grounds for the recovery of possession from the lodger of th« accommodation provided to him and shall be made in writing and accompanied by an
affidavit in support of the allegations contained therein,
14. Certificate to be sent to the manager.—A certificate issued under section
34 by the Controller shall be sent to the manager of the. hotel or the owner of
the lodging house concerned with a copy thereof to the lodger concerned by
registered post with acknowledgement due.
15. Display of notice of fair rates.—The manager of every hotel or the
owner of every lodging house shall display a notice of the fair rates fixed by
the: Controller and a copy of the relevant provisions of the Act and rules relating
thereto in s conspicuous manner in the hotel or the lodging house, as the case
may be.
16. Application to the Controller.—Every application to thy Controller under
Chapter V of the. Act including an application for certificate under section 34 shall
be in forrn 'D' and shall be delivered to the Controller either in person or through
a recognised agent or sent 1o his office by registered post.
CHAPTER V
APPEAL AND TRANSFER APPLICATIONS

17. Form of appeal.—(1) Every appeal to the Rent Control Tribunal under
section 38 shall be preferred in the form of a memorandum signed by the appellant or his recognised agent and presented either m person or through a recognised agent to the Tribunal or to such officer as it may appoint in this behalf.
(2) Every such memorandum shall be accompanied by a copy of the order
nt tho Controller appealed from and shall set forth concisely and under distinct
heads, the, grounds of objection to the order appealed from without any argu
ment or narrative; and such grounds shall be numbered consecutively,

<!-- page 3 -->

• E C .

J

(

i

)

J

T

H

E

G

A

Z

E

T

T

E

O

P

I

N

T

J

I

A

E

X

T

R

A

O

R

D

I

N

A

R

Y

18. Application for transfer of proceedings.—An application, for transfer
proceedings under sub-section (4) of section 38 shall be accompanied by
affidavit in support of the allegations contained in the application.

4

!

of
an

19. Appearance before Tribunal.-—A party may appear before the Rent Control
Tribunal either in person or by a recognised agent provided that if the Rent
Control Tribunal so directs, the' party shall appeal; in person,
CHAPTER VI
FEES

20. Process fees.—(1) Process fees for processes under the Act shall be levied
as prescribed In the. rules made by the Punjab High Court under section 20 of
the Court-fees Act, 1870, as to cost of processes in Civil Courts,
(2) For the purposes of this rule, the Court of the Controller shall be deemed
to be, a Civil Court of Third Grade and the Court of the Rent Control Tribunal
shall be deemed to be a Civil Court of Second Grade.
CHAPTER VII
NOTICES

21. Notice relating to sui)-tenancy.—A notice of the creation or termination of
a sub-tenancy required under section 17 shall be in Form 'E\
22. Service of notice, etc.—Unless otherwise provided by the Act, any notice
or intimation required or authorised by the Act to be served on any person shall
be served—
(a) by delivering it to the person; 01'
(b) by forwarding it to the person by registered post with acknowledgment due.
CHAPTER VIII
MISCELLANEOUS

23. Code of Civil Procedure to be generally followed.—In deciding any question relating to procedure not specifically provided by the Act and these rules,
the Controller and the Rent Control Trbunal shall, as far as possible, be guided
by the provisions contained in the Code, of Civil Procedure, 1S08.
24. Registers to be maintained by the Controller and Tribunal.—Th«r Controller
and the Rent Control Tribunal shall maintain such of the registers prescribed
for use in Civil Couris in Delhi as may be necessary.
APPENDIX
FORM

'A'

(See rule 3)
Before
Name

Controller.
Petitioner.

Versus
Name..,

, Respondent.

'fixation of standard rent
increase of standard rent
eviction" of Tenant ~
Under Section
_____
("Strike out whatever is inapplicable)
Application for

(1) Municipal No. of the premises and the name, if any.
(2) Street and municipal ward or division in which the premises are situated
(3) (a) Name and address of the landlord.
fb) Name and address of the tenant/tenants.

<!-- page 4 -->

42

THE GAZETTK OI INDIA EXTRAORDINARY

[PART II

(4) Whether the premises are residential or non-resid«ntial.
(5) In the case of residential premises, the number of parsons occupying the
same and in the case of non-residential premises, the, purpose for which they «re
used and the number of employees, ii any, working therein.
(6) Whether any furniture is supplied by the landlord for use in the premises.
(7) Details of fittings, if any, providt-d by lh( landlord.
(8) Details of accommodation available together with particulars as regards
ground urea, garden and out-houses, If any. (Plan 10 be attached).
(9) Whether the. premises are occupied by a single tenant or by more than
one tenant.
(10), Amenities available in regard to lighting, waier, sanitation and the like.
(11) Monthly rent together with details of house-tax, electricity, water and
other charges paid by the tenant.
(12) (a) Date of completion nf ronstrur'tinn of the premises and Hi? rost thereof
(b) Whether completion report was obtained from tbe local authority and the
date thereof.
(13) Rateable value as entered ill the last property assessment book of the
Delhi Municipal Corporation, New Delhi Municipal Committoe or fh<- Delhi
Cantonment Board, as the case may be.
(14) Date on which the premises were let to the tenant and details of agreement, if any, with the landlord. (Attested copy of the agreement to be attached).
(15) Whether the, rent of the premises has been fixed under the New Delhi
House Rent Control Order, 1939, or the Delhi Rent Control Ordinance, 1944, or
the Delhi and Ajmer Merwara Rent Control Act, 1947, or the Delhi and Ajmer
Rent Control, Act. 1952, or the, Delhi Rent Control Act, 1958; and if so, the amount
of such rent and the date from which it took elWt.
•(16)Whether there are any sub-tenants and if so, the date of such subletting, accommodation sub-let, whether with or without the. written consent of
the landlord and the rent charged from sub-tenant.
**H7) Whether any additions or alterations have been made since the r<;nt
was fixed as stated under item No. 15; and if so, the date on which surh additions
or alterations were made,, the cost of such additions or alterations and whether
they were carried out with the approval of the tenant or of the controller.
t(18) (a) The grounds on which the eviction of the tenant is sought.
(b) Whether notice required has been given; and if so, particulars thereof.
(Copies of such notice and the tenant's reply, if any, should be furnished.)
(10) Any other relevant information
(20) Relief claimed.
(Verification1).
Place:
Date:
(Signature of applicant/recognised agent).
*Thls information should be given in applications for eviction due to unauthorised sub-letting.
'
••Tins Information should be given in applications lor increase of rent due
to additions or alterations.
iTlik information should bp given in application for ovidion of TetKint.^.

<!-- page 5 -->

••«. » (i)]

THE GAZETTE OF INDIA EXTRAORDINARY

43

FORM 'B'

(See rule 0)
Forvi of Rent Receipt and Counterfoil
Counterfoil
•
Serial No,
N&m<* of tb« landlord:—
Address of the landlordReceived with thanks from
a sum of Rs. (in figures)
(in words)
only as payment of rent at Rs
per
for
the period ,
for the premises
this day the
day of the month of
in the Tear
Signature or thumb impresgion
of the landlord or authorised affent.
*The rent charged includes:—
(1) Rates, cesses and taxes of the local authority.
" ( 2 ) Electric charges.
" ( 3 ) Water charges.
••(4)
**(5)
*It docs not includa:—
(1) Rates, cesses and taxes of the local authority.
<$) Electricity charges.
(3) Water charges.
(4)
(5)
" Strike out whatever Is inapplicable.
**State the exact charges if possible.
Rent Receipt.
Name of the landlord;—
Address of the landlord:—
Received with thanks from
a sum of Rs. (in figures)
only as payment of rent at Re.
per
the period
for the premise?:
this day the
day of the month of

Serial No.

(in words')

in the year

Signature or thumb impression
____
_
°?__the landlord or authorised agent.
*Thp rqnt charged includes:—
(1) Rates, cesses and taxes of the local authority,
•*(2) Electric charges.
**.(?). Water charges
**(4)
••(5) ...*
;
It does not include:—
(1) Rates, cesses and taxes of the local authority.
(2) Electric charges.
(3) Water charges.
(4)
_(5) • - ^
+.Strike .out y/hateyer is inapplicable.
•"State thf "xsct charges if possible

for

<!-- page 6 -->

44

THE GAZETTE OF INDIA EXTRAORDINARY
FOBM

[PAUT II

"C'

(See rule JO)

Application for deposit of rant
Before Controller
Name

Petitioner.
Versus

Name

Landlord(1) The premises for which the rent is deposited with a description sufficient tor identifying the premises.
(2) The period for which the rent is deposited and the rate per month.
(3) The name and address of the landlord or the person or persona claiming to be entitled to such rent,
(4) The reasons and circumstances for which the application for depositing
the rent is made,
(5) The amount of the rent deposited.
(6) Whether electricity, water charges, property tax, etc. are included in the
rent and if so, particulars thereof.
(7) How the rent was tendered to the landlord—whether in persons or by
postal money-order or by cheque, etc., and "whether it was refused by
him in writing or otherwise.
(8) Whether there is a bona. fide doubts as to the person or persona to whom
the rent is payable and if so, why.
(9) Date on which the rent was last paid to the landlord and the receipt,
if any, obtained from him thorefor.
(10) Any other relevant information.
The statements made above are true to the best of my knowledjfe and belief
and I,
the applicant/recognised agent signed the
application on the1
day of 10
Signature of the applicant/
recognised agent.
FORM

'D'

(See rule 16)
Application for fixation of fair rate/revision of fair rate/certificate to recover
possession of accommodation.
Before
Controller.
Name
Applicant.
Verms
Name
Respondent.
(1) Name, addrees, location, etc. of the hotel or lodging house.
(2) Rates charged for boarding, lodging and other services,
(3) Whether fair rate has already been fixed and If so. the date on which
such rate was fixed and details of such fair rate,
(4) Other relevant information as to why the rates are considered excessive
or why revision of rates is required or as to why recovery of possession from the lodge is asked for.
Verification:
Place:
Date:
Signature of applicant/recognised
Agent.

<!-- page 7 -->

V*c S (i)J

THE GAZETTE OF INDIA KM KAOKLUNARY
FORM

45

'E*

(See rule 21)

Form of notice regarding creation or termination of sub-tenancy
1. No. of the premises and name, if any.
2. Street and municipal ward or division in which the premises are situated.
3. Name of the tenant.
4. Name of the sub-tenant.
5. Details of the portion sub-let.
6. Rent payable by the sub-tenant.
7. Purpose for which sub-let—residential or non-residential and if latter, the
naturw of business, etc., and the number of employees, if any, working therein,
8. Date of creation/termination of the sub-tenancy.
9. Any other relevant information.
Signature of tenant/sub-tenant.
[No. 34/1/69-Delhi.]
MARI SHAHMA, Addl. Secy.

PRINTED IN INBIA BY THE GENERAL MANAGER, GOVT. OF INDIA FHESS
NHW DKLHl AND PUBLISHED BY THE MAN1GER OF PUBLICATIONS, DELHI, 195&

<!-- page 8 -->
