---
doc_id: "26bf16cd1b8f4fad"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/09/f87fe113da3612d06c085e7c595f8a91.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Tender Enquiry on two bid pattern (Technical & Financial) for printing of Annual Report 2019-20 of DPIIT"
date: "2019-09-05"
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "afc5485b7750e0e0"
---

<!-- page 1 -->

F. No. D-15013/06/2019-GA
Government of India
Ministry of Commerce & Industry
Department for Promotion of Industry and Internal Trade
(GA Section)
Udyog Bhavan, New Delhi.
Date:$1'4November, 2019

Tender Notice
Subject:

Tender Enquiry on two bid pattern (Technical & Financial) for printing of Annual Report 2019-20
of Department for Promotion of Industry and Internal Trade.

Online quotations are hereby Invited at Central Public Procurement (CPPP) Portal (www.eprocure.gov.in)
from reputed, experienced and financially sound printing firms, for printing of Annual Report of the Ministry of
Commerce & Industry. The detailed general terms and conditions of the contract are given in Annexure•'A'. The
technical bid format at Annexure-'B' and financial bid format is at Annexure-'C'.
2.
The bid will be accepted as an e-tender only and intending bidders must be registered with the Central
Public Procurement Portal (CPPP) i.e. http://eprocure.gov.ln/eprocure/app. The detailed schedule of e-tender is
as under:-

SI. No.

SCHEDULE OF TENDER

DATE AND TIME

1.

Date of issue of Tender Document

2.

Last Date & time for submission of EMO

Up to 3.00 P.M. on
25.11.2019

3.

Last Date & Time for online submission of Tender Document

Up to 3.30 P.M. on
25.11.2019

4.

Date and time for opening of Tender Document

05.11.2019

26.11.2019
At 3.30 P.M.
(In R.No. 271-A,
Udyog Bhawan,
New Delhi)

3.
Interested printers may submit their tenders online at http://eprocure.gov.in/eprocure/app. As per the
prescribed Performa. Tenders are to be submitted only online
through e-Procurement Portal
http://eprocure.gov.in/eprocure/app. Tenders sent by any other mode will not be accepted. No tender documents
will be accepted after the expiry of stipulated date and time under any circumstances whatsoever.
4.
Earnest Money Deposit (EMO) of Rs.15,000/- (Rupees Fifteen Thousand only) in the form of crossed
Demand Draft/Bankers Cheque in favour of DDO (Cash), Department for Promotion of Industry and Internal
Trade Udyog Bhawan, New Delhi should be submitted in a sealed cover super scribed with 'Quotation for Printing
of Annual Report of the Ministry of Commerce & Industry' in the Department for Promotion of Industry and Internal
Trade in Room No. 271-A, Udyog Bhawan, New Delhi on or before 25.11.2019 by 3.30 PM. EMO should be valid for
a period of at least 45 (forty five) days from the date of opening of the tender. In case EMO is submitted late or not
submitted at all, the bid will be considered unresponsive and incomplete and will be summarily rejected . The firms

<!-- page 2 -->

registered with MSME and NSIC should submit a copy of EMO Exemption certificate for claiming exemption from
EMO submission.
5.
The sample of the last year's printed report is available in GA Section in Room No. 21, Udyog Bhavan, New
Delhi and may be collected from there for reference.
6.
After financial evaluation of the technically qualified bids order shall be placed on the lowest offer which
conforms to the bid norms.
7.

The EMO shall be returned to the unsuccessful bidders after finalization of the tender.

The bidding documents including Annexure B & C are downloadable may be seen and downloaded from DPIIT
website (dpiit.nic.ln).
/

(~~umar)
Under Secretary to the Govt. of India
Tele: 23063697

Copy to:

NIC, DPIIT with a request for placing the complete Tender enquiry along with terms and
conditions in this Department Web site and same may kindly be removed on 26.11 .2019
at 3.30 P.M. Copy of tenders enquiry is enclosed.

Copy for information to:
1.

Reception Officer, Department for Promotion of Industry and Internal Trade, Gate No. 12, Udyog
Bhawan, New Delhi.

2.

CISF, Udyog Bhawan, New Delhi.

<!-- page 3 -->

ANNEXURE-'A'
TERMS AND CONDITIONS FOR AWARD OF CONTRACT FOR PRINTING
OF ANNUAL REPORT 2019-20 (ENGLISH AND HINDI SEPARATELY)

1.
ITEMS & QUANTITY REQURIED TO BE PRINTED: Description of the items
proposed to be
printed are given hereunder. Rates must be quoted separately for Annual Report (English & Hindi) in
Annexure C in figure and in words in the prescribed proforma. The approximate number of pages and
required quantity is indicated below:
Size 21.5 cm x 27.5 (cut size}
SI.No.

1.

Description
Annual Report 2019-20

No. of Pages
200 approx.

No. of copies
1000

(English)
2.

Annual Report 2019-20
(Hindi)

200 approx.

500

3. Extra pages will be charged on Pro-rata basis
4. Photographs : 30 nos. approx. to be provided by Department to the extent possible and
remaining photos/art work to be arranged by the Printers
5. e-Book of the final printed Annual Report 2018-19 will be provided by the

Printer.
2.

SPECIFICATION
•

Outer and Inner Page:
Outer/Cover Pa es
Inner/Text Pages

Text pages 130 GSM Indian Art paper- 4 colours
rintin
Multi-Colour offset

Perfect Binding

•

Binding:

•

Design and layout of Annual Report: Same design and layout for Hindi and English version)

3.

PRE-PRESS JOB
►
►
►
►

Text of both the documents will be provided by the Department in electronic format (MS Word/PDF)
Pre-press job such as DTP work including Designing/creative options to be done with the printer's own DTP
to the satisfaction of the Department.
Proof reading of the manuscript by a good professional proof-reader. Colour Machine Proof (Dummy to be
submitted for approval for specified number of pages (e.g. cover page, photographs pages etc.)
e-Book of the final printed Annual Report 2019-20 will be provided by the Printer.

<!-- page 4 -->

4.

SCHEDULE OF WORK

The work should be completed in all respects and material should be delivered within stipulated days form
the date of placement of printing order as mentioned below:
(a)
(b)

(c)

5.

Design / layout and first proofs of design and
text for design selection/ correction
Second proof/ final proof

Printed product delivery at Udyog Bhawan,
New Delhi.
QUOTATION
►
►

6.

Within five days of order placement/ handing
over of Pen Drive or hard copies.
Within two days after first proof. If complete
corrections have not been carried out in first
proof, next proof would be submitted urgently.
Within ten days after final proof.

The rate quoted should be inclusive of paper, creative options, plate layout design, proof reading,
positives, printing, laminating binding etc. and supply of the Annual Report at Udyog Bhavan.
Vendor should be able to execute all the required jobs together, part quotation will not be
entertained.

AGENCY

The bidder should have latest high quality color printing machines of their own. They should have latest
DTP software and hardware & sufficient manpower to operate it.
7.

PENALTY
In case of default in maintaining time schedule, the Department will impose a penalty of amount equivalent
to 5% of the total tender cost per day subject to a maximum of 10 days. Delay beyond the scheduled time in
excess of 10 days will be deemed to have the Printing Order cancelled. The Department will not way be held
responsible for the loss, whatsoever, attributed due to the delay in print of Annual Report.
8.

Eligibility criteria

The following eligibility criteria are needed to be fulfilled to be considered for the Tender:
(a) Photocopy of PAN Card along with Income Tax Return for the last two years (i.e. 2017-2018 & 201819)
(b) Photocopy of GST Registration Certificate/Number;
(c) Turnover of Rs.50.00 Lakh and above for the last 2 years (i.e. 2017-2018 & 2018-19)
(d) Experience certificate for the last 3 years (i.e. 2016-17, 2017-2018 & 2018-19) for printing of Annual
Report in Government Departments/Ministries (or) similar Govt. job;
(e) Location of Press/Unit- The location of the Press/Workshop should be within 7 Kms. Radius of Udyog
Bhawan, so that vendor is available whenever required in Udyog Bhawan on an urgent basis or staff of
the Department reaches to the Press/Workshop for proof reading & verification of the printing work.
Note:

The vendor must ensure safe custody and maintain confidentiality of the printing material supplied by the
Department.

<!-- page 5 -->

OTHER TERMS & CONDITIONS
i.

RATES ONCE QUOTED SHALL BE TREATED AS FINAL.

ii.

The tender validity period is 90 days from the date of opening tender. The rates quoted by the bidders will remain
valid for a period of 90 days or till the date of finalization of tender, whichever is earlier.

iii.

Tender Evaluation Committee will open the Financial Bids of only those bidders who stands qualified on the basis of
details provided in Technical Bid

iv.

The commercial offer would be inclusive of statutory levies like GST, etc., to be indicated and included in the
Financial Bid Format. However, the bidder shall indicate the actual rates of all statutory levies and charges.

v.

The tender document must be filled in neatly and clearly. Incomplete or conditional tenders will not be
entertained;

vi.

Tenderer will not be allowed to withdraw his offer after opening of the tender. EMO shall be forfeited at the risk of
tenderer, if the tenderer fails to honor the contract;

vii.

Supply order, after due compliance of all formalities, will be placed on the selected supplier to effect the supply

viii.

The selected Firm will be required to supply one sample each of the material to be printed for the approval of the
competent authority. No final printing should be resorted to unless otherwise specifically asked for by the
Department. The selected firm shall ensure the delivery of the items in the office of the Department. No separate
charges shall be paid for delivery of goods.

Ix.

The contract will remain operative for a period of one year from date of award of the same and the vendor /printer
may be asked to print additional copies on multiple of 50 copies at a time. Charges for the additional number of
copies will be determined as per the quoted rates.

x.

The Department reserves the right to conduct performance review of any item during the contract period and
deficiencies, if any, noticed will be required to be rectified and compliance reported. If the tenderer fails to rectify the
deficiencies or fails to comply with other direction/instructions of the Department his contract is liable to be
terminated. The Department further reserves the right to suo moto terminate the contract at any point of time without
giving any prior notice.

xi.

Any request for increase in quoted and/ or accepted rates will not be entertained for any reason during the currency
of the contract. However changes in statutory levies would be acceptable subject to indication of prevailing, rates on
the date of opening and submission of proof of revised rates.

xii.

The rates must be written in figure as well as in words. In case of discrepancy between rates in figures and
words, the rates in words would be taken as final.

xiii.

Canvassing in any form is strictly prohibited and tender of the tenderer who resorts to such activities will be
summarily rejected;

xiv.

The EMO shall be forfeited in case the firm does not fulfill/ produce the documents/ promises made before this
Department or any committee constituted by this Department for this purpose;

xv.

Performance Security: An amount of Rs.30,000/- (Rupees Thirty thousand only) will be the "Security Deposit" in
the case of successful lowest bidder, which may be furnished in the form of Fixed Deposit Receipt from a
Commercial bank or Bank Guarantee from a Commercial bank in acceptable form. The Performance Security
should be valid for a period of sixty days beyond the date of completion of all contractual obligations of the

<!-- page 6 -->

contractor including warranty obligations. Earnest Money will be refunded to the successful bidder on receipt of
Performance Security;
xvi.

The Department reserves the right to reject any or all the bids in full or part or not to award the contract to the lowest
bidder without assigning any reason therefor and giving any compensation. The decision of the Department in this
regard shall be final and binding on all;

xvii.

TDS, and other applicable taxes as per prevailing rates, will be deducted before making the payment;

xviii.

The lowest quoted bidder (L-1) shall be chosen on the basis of total bid price received;

xix.

No advance payments shall be made. On successful and timely completion of works, all the bills submitted by the
executing firm would accompany with the work vouchers duly signed by the concerned officers/officials of the
Department. Payments will be made on receipt of pre-receipted bills (in triplicate) provided the approved claim will
be released only after satisfactory completion of works and due recommendations of the competent authority;

xx.

The Department reserves the right to impose any other conditions for regulating the contract in public interest;

xxi.

In case the successful bidder is found in breach of any condition(s)/tender at any stage, legal action as per
rules/laws shall be initiated against the agency concerned. In that case Earnest Money DeposiU Performance
security shall be forfeited after giving proper opportunity through show cause notice;

xxii.

All disputes are subject to the jurisdiction of courts in the National Capital Territory of Delhi and Agreement will be
governed by and be construed in accordance with the laws of India;

xxiii.

Interested firms/parties will have to submit unconditional acceptance to the above terms and conditions at the time of
submission of the tender;

xxiv.

The Tender of tenderer who does not fulfill any of the above conditions and incomplete tenders are liable to be
summarily rejected at the risk and cost of the tenderer only and any further correspondence in this regard will not be
entertained.

xxv.

No separate transportation charges/labour charges will be paid for obtaining and delivering the order or replacing the
material not found as per the specification;

xxvi.

This Department reserves the right to accept or reject the tender in full or in part without assigning any reason.

xxvii.

The contract will be valid for a period of one year from the date of issuance of order. The period of the contract can
be extended further by one or more years subsequently subject to the satisfactory performance for printing of Annual
Report 2019-20.

xxviii.

The printers have such equipment's like 3-4 colour offset printing machines, folding machines, cutting machine,
binding machine, and also other equipment's as may be required for the printing works of Annual Report.

<!-- page 7 -->

ANNEXURE-' B'
TECHNICAL BID INFORMATION
S.No.

1.

INFORMATION - - - - - - 1

ITEM
Name of the Printer & Owner
(With Tel/Mob. Nos.)

2.

Office Address
(Tel./FAYJ.Mob.No//E-mail.

3.

Address of the Printing Press
Tel./FAYJ.Mob.No.

- - -Contact
- Person(s) Name
- - ----------

4.

---

Tel./FAYJ.Mob.No

5.

Year of Establishment (Supported by copy of valid
Registration)

6

Annual Turnover for the last 2 financial years i.e. 2017-18
and 2018-19.
Co_py of the ITR, and Balanc~ sheet to be u load~
PAN No .. /TAN1 No./GST Reg.No

7.

8.

List
of
major
clients
departments/organizations.

9

Samples of at least two similar printing works done In any
Ministry/Department during the last three years ( 2016-17,
2017-18 & 2018-19) to be submitted physically.

10.

List of Qualified technical manpower available in-house for
design, layout, printing, etc. work.

including

government

- - - --l

- - - - - ------ --1---------------i

11 .

Infrastructure available in-house for design, printingetc
(su_pporled b list of such facilities).
12.
Work Orders/Performance certificates Issued by at least 3
(three) Ministries/Deptts./PSUs during the last three years
(2016-17, 2017-18 and 2018-19). (Self-certified copied to
be u loadf}d)
------Self-certif-ic~at-io-n -by the firm that the Firm has not been13. blacklisted by any Govt. D~tL
_
_
14.
Whether Terms & Conditions issued the Department are
~--~
ac_c_ep~l_
ab_le_to_t_
he_F
_ir_m_ _ _ _ _ _ _ _ _ _ _ _.___,_ _ _ _ _ _ _ _ _ __,

(Signature of Owner I Authorized Representative)

<!-- page 8 -->

ANNEXURE-'C'
FINANCIAL BID FORMAT

Rate (in Rupees) [Rates
of statutory levies like
GST to be indicated and
included
-- @ per copy=

Quantity

Description Work

--------

Annual Report 2019-20 (English)

-

1000 copies Cover

Total Cost
(Rate in Rupees)

+200 pages
Annual Report 2019-20 (Hindi)

-

500 copies

@per copy=

Cover +200 pages

- - - - - - ~ - - - -- --~

Design cost for 200 pages

-

@per copy=

Proofing 200 pages

@ per copy=

Color Dummy Report 1 (One) Set

@per copy=

l_

- - Tota-I V
- alu_e_o_f_O_
ffe_r___

---------

-

~ - - - - - - - - ----------

( Signature of Owner I Authorized Representative )
