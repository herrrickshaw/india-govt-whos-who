---
doc_id: "27d6beaa1ea481aa"
source_url: "https://www.dot.gov.in/static/uploads/2025/08/9517b21e2f348c567adef924fb2ee7b6.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Taken on Strength in respect of officer of ITS Gr A -reg"
date: "2025-07-23"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2fd8bd4c7894589b"
---

<!-- page 1 -->

12-5/2025-STG-I

I/3299004/2025

No. 12-5/2025-STG-I
Government of India/भारत सरकार
Ministry of Communications/संचार मं ालय
Department of Telecommunications/दरू संचार िवभाग
Sanchar Bhawan/संचार भवन
*****
20, Ashoka Road, New Delhi
Dated the 23rd July, 2025
OFFICE ORDER/कायालय आदेश
Sub: Taken on Strength in respect of officer of ITS Gr. A -reg.
In terms of this oﬃce order No. 12-4/2024-STG-I(iii) dated 27.06.2025 and
subsequent relieving from Delhi LSA w.e.f. 01.07.2025(F/N) vide their order dated
01.07.2025, Sh. Jayant Kumar [Staﬀ No. 20110], an oﬃcer in HAG of ITS Group
‘A’, has reported for duty as Sr. DDG(PG), DoT HQs on 01.07.2025 (F/N).
2.
Therefore, Sh. Jayant Kumar is hereby taken on strength of Department of
Telecommunications (HQs) w.e.f. 01.07.2025(F/N).
3.

This issues with the approval of Competent Authority.

(Sunil Kumar/सुनील कुमार)
Under Secretary to the Govt. of India/
अवर स चव, भारत सरकार

Copy to:

Tel/दरू भाष : 011-2303 6282
E-mail/ई-मेल: sunil.kmr70@nic.in

1. PPS to Secretary (T);
2. Member(S) / Member(T) / Member(F)/ DG (T);
3. Additional Secretary (T)/ Advisor(O) / Advisor(T);
4. CVO, DoT (HQs.);
5. DDG(C&A)/DDG(Accounts)/DDG(IT)/DDG (Pers)/ DDG (Estt.), DoT HQs;
6. Admin. I-IV/Cash/Pension/Library/G-I/G-II/PFP/PHP/RTI/Vig.I Sec., DoT
(HQs);
7. Pay Bill Section, DoT (HQs);
8. ADG (APAR)/ ADG (Staff)/ US(SNG)/ AO(SGT), DoT (HQs);
9. The officer concerned;
10. Order Bundle /PA to US (SGT) – for uploading on the website of DoT.
