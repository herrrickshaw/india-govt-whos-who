---
doc_id: "294bbae9adb1f5ac"
source_url: "https://master-tourism.digifootprint.gov.in/static/uploads/2025/06/f9416aca2c48f87b1999a807d2be00b3.pdf"
ministry: "Tourism"
title: "Guidelines of Swadesh Darshan 2.0 Scheme"
date: "2025-08-04"
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "7fb7201e9a2ba0cd"
---

<!-- no text layer: pending OCR -->
