---
doc_id: "2481f1c1caedbe5d"
source_url: "https://mohfw-dohfw.gov.in/static/uploads/2025/10/792bcd57f08a4a1d8b7176719c502059.pdf"
ministry: "Department of Health and Family Welfare (DoHFW)"
title: "Framing of Recruitment Rules to the post of Dental Assistant/Technician/Hygienist, RHTC Hospital"
date: "2024-10-10"
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "848d31846b253de4"
---

<!-- page 1 -->

F.No.A. I 20 I 8 I 0612024 -W-II (FTS :-8259682)

Govemment of India

Ministry of Health and Family Welfare
Department of Health and Family Welfare
Nirman Bhavan New Delhi-ll00ll
Dated 30th Algrtst, 2024

NOTICE
This Ministry is examining a proposal for framing of Recruitment Rules

for the posts of Dental Assistant/Technician/tlygienist in RHTC Hospital,
Najafgarh, Directorate General of Health Services, Ministry of Health & Family
tn this regard, draft Recruitrnent Rules have been approved by the

welfare.

Competent AuthoritY.

2,BeforetakinguptheproposalforframingtheRecruitrnentRuleswith
the DoP&T and other agencies for finalizing the Recruitrnent Rules, comments,

if any, are invited from all stakeholders in the matter within a period of thifi
days from the date of notification in the website of the Ministry of Health

and

Family welfare. The objections/suggestions received from the stakeholders
within the specified period shall be considered by the Ministry as per
rules/requirement.

The comments may be fumished to the undersigned in Room No' 401-D'
to
D Wing, Nirman Bhawan' New Delhi-110011 and the soft copy may be sent

3.

anuradha.ramakrishan@nic.in

r

- vI

\..,r&z

{$J""2-'

(Anuradha Ramakrishnan)
Under SecretarY to Govt' of India
TeL23061640

<!-- page 2 -->

n

33HffiXl3lfl',,1 *,'**

^,,o'
RURAL HEALTH TRAINING CENTRE
NAJAFGARH, NEW DELHI.I 10043

Notification

G.S.R..... -In exercise of the powers conferred by the proviso to article 309 of the Constitution, the
president hereby makes the foltowing rules regulating the method of recruitrnent to the post ofDental
Assistant/Technician/Ilygienist in the Ministry of Health and Family Welfare, Directorate General of
Health services, RHTC Hospital, New Delhi, namely:-

l. Short title and commencement. -(l) These rules may be called the Ministry of Health and Family
wetfare, Directorate General of Health Services, RHTC Hospital, New Delhi, Dental
Assistant/TechnicialAlygienis! Group'C' post, Recruitment Rules, 2024'
2. Application- These rules shall apply to the posts as specified in the column (1) of the Schedule
Gazette.
annexe to these rules. They shall come into force on the date oftheir publication in the Ofhcial
posts, their
3. Number of posts, classification and level in pay matrix. - The number of the said
(2)
to (a) of
classification and level in the pay mafix attached thereto shall be as specified in columns
the said Schedule.

4. Method of recruitment, age-.limit, qualifications, etc.-The method of recruitrnent, age-limit
qualifications and other matters relating to the said posts shall be as specified in columns

(5) to (13) of

the said Schedule.

5. Disqualification. - No Person, -

l. who has entered into or contracted a marriage with a person having a spouse living; or
2. who, having a spouse living, has entered into or contracted a marriage with any
be eligible for appointnent to the said posts:

person, shall

permissible under the
Provided that the Central Govemment may, if satisfied that such marriage is
are other
personal law applicable to such person and the other palty to the marriage and that there
the operation of this rule'
lrounds for so doing, exempt any person from

it is necessary or expedient
6. power to relax. - Where the Central Govemment is of the opinion that
with theunion
in
consultation
and
in
writing
so to do, it may, by order and for reasons to be recorded
to any class or
Service Commission, relax any of the provisions of these rules with respect
Public

category ofPersons.

7, Saving. - Nothing in these rules shall affect reservation, relaxation of age-limit and
other
required to be provided for the Scheduled castes, the Scheduled Tribes, the
other

persons' in accordance with the
"on""rsio-r.
Backward Classes, the Ex-servicemen and other spocial categories of
orders issued by the Central Govemment from time to time in this regard'

<!-- page 3 -->

DRAFT SCH-EDULE
Recruitrnent Rules for the post of Dental Assistant/Technician/Hygienist

Name ol Number ol Classificatio Level in Whether Age.limit for Educational and
posts.

posts.

n.

pay

selection direct recruits.

matrix.

post or

recruits.

non
selection
post.

(l)
Dental

(2)
*01 (2024

Assistant/Te
chnician./Hy to

gienist

dependent

Central t

Service, *;",,.0"'l

l8 to 27 Years I (i) l2th class pass
Biology as a
applicabl
I

I

Group 'C'.1 (Rs.

I

Non-Gazette I 29200-921
Non-l
workload.
0n

3oo)l

o.

Ministerial.

(1)

(6)

(s)
General I Level-5 inl Not
(4)

(3)

other qualification
required for direcl

(Relaxable fod Iiom a
Government I Board or institute;
servants up tol (ii) Two years

five years inl in Dental
accordance I from a

with

thel Instihrte:

lnstructrons ofl (iii) Registered

I

orders issued bvl Dental Council

the
I

c"nt India as
"tl
Govemment). I Hygienist;
I Essential experience:l

Note I :
I

I

ThJ one year expenence asl
crucial dut"l Dental Hygienist in al
for determiningl recognised Hospital.

the

I

ue"-l

limit shall be Note I : Qualificationsl

I

as advertised by are relaxable at thel

the

lSelection
lCommission.

Staff discretion

sraff

of

tne]

Selection

Commission ot]
Lcompetent au*rority
lfn. .."ron. to be
in
l."corded
in
the
case
lwriting
candidates
lof
lotherwise well

lqualified.

qualification(s)

regarding experience
is relaxable at the

discretion of
Staff

the

Selection
OT

<!-- page 4 -->

competent authorityl
for the reasons to bel
recorded in writingl

in the case o{

candidates belongingl
to Scheduled Castes

and

Scheduled

Tribes. if

at any]

stage of selection,

the

Staff

Selection Commission
or competent authority

is of the

opinion
sufftcient
o{
candidates from

that
number

these communities
possessing the
requisite experience
are not

likely to

be available to
fill
up the
vacancies reserved for
them.

case of recruitment
or by deputation
grades from

absorption is to be made.

be filled

contract)/absorption :

confirmation
Committee

<!-- page 5 -->

direct recruits.

Statutory organisation
Sector Undertakings

A) (i) holding analogous Posts
basis in the parent

consisting of:

Superintenden!

Chairman;

i) with 5 (five) years of
in the post in the
Level-4 (Rs. 25
1100/-) in the parent cadre

2.

Head

-Member;

Administration,

including short-term contract
Hospital

including short-term
anotier ex-cadre Post

the Central Govemment
inarilv not to exceed

2. - The maximum age
appointrnent by

including short-term contact
be not exceeding
as on the closing date o

3: Only Central or

Dfuectorate

General
