---
doc_id: "2725ebb2ab8b7aec"
source_url: "https://www.dot.gov.in/static/uploads/2026/02/75b42c49cca624cb8810f419e91f497f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "CS COMM 861 of 2023 in the Honble High Court of Delhi: DoT instructions dated 27.02.2026 to ISPs"
date: "2026-02-27"
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2597678a74954dd6"
---

<!-- page 1 -->

4-10/2025-DGT/4(Part-III)

I/3371304/2026

By Email/DoT Website
File No.:4-10/2025-DGT/4(Part-III)
Government of India
Ministry of Communications
Department of Telecommunications
Director General Telecom HQ
nd
2 Floor, UIDAI HQ, New Delhi -110001
Date:

-02-2026

To
All Licensees with Internet Service Authorization
Subject: CS (COMM) 861 of 2023: (Fabindia Limited Vs. Ashok Kumar/John
Doe & Ors.) in the Hon’ble High Court of Delhi.
Please find enclosed the Hon'ble High Court of Delhi order dated 04.12.2023
in the captioned case.
2.
Please refer to para 19(ii) and 19(iii) of the said Court order in respect of
blocking access to the 1 no. of website as enumerated in para 3 of the affidavit
dated 19.02.2026 filed by the plaintiff.
3.
In view of the above, all Licensees with Internet Service Authorization are
hereby instructed to take immediate necessary action in respect of blocking access
to the said website(s){domain(s), as per the enclosed list, in compliance with the said
court orders.
Encl: A/A

ADG (T)
Email: adgnt.hq-dgt-dot@gov.in
Copy to:
i.)
Ministry of Electronics and Information Technology (MeitY), New Delhi
(cyberlaw-legal@meity.gov.in) - Requested to take action as per the said Court order/
enclosed Annexure pl.
ii.)
Ms. Simran Karkhur (simran.karkhur@mplawoffices.in), Plaintiﬀ's Counsel- For
kind information and with a request to take action as per the enclosed List pl.

<!-- page 2 -->

4-10/2025-DGT/4(Part-III)

I/3371304/2026

CS(COMM) 861/2023:
Website(s)/domain(s)IUrl
1)

Fabindiakurti.com

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

$~24
*

IN THE HIGH COURT OF DELHI AT NEW DELHI

+

CS(COMM) 861/2023
FABINDIA LIMITED
..... Plaintiff
Through: Mr. Viraj Datar, Sr. Advocate
with Mr. Dipankar Vig, Mr. Pranay Sarkar,
Mr. Kunal Juneja, Ms. Ujjwala Gupta and
Mr. Saurav Joon, Advs.
versus
ASHOK KUMAR/JOHN DOE AND ORS.
..... Defendants
Through: Mr.
Harish Vaidyanathan
Shankar, CGSC with Mr. Srish Kumar
Mishra, Mr. Alexander Mathai Paikaday and
Mr. Krishnan V., Advs. for the Registrar of
Trade Marks for Defendants 4 and 5
CORAM:
HON'BLE MR. JUSTICE C. HARI SHANKAR
ORDER
04.12.2023

%
CS(COMM) 861/2023
1.

I have heard Mr. Viraj Datar, learned Senior Counsel for the

plaintiff and Mr. Krishnan V., learned Counsel, who appears on behalf
of Mr. Harish Vaidyanathan Shankar for Defendants 4 and 5

2.

The plaintiff is a renowned Indian retail company which

specializes in production and sale of a wide range of handcrafted
products.

It has been using the mark “Fabindia” and is also the

proprietor of over hundred registered trade marks including the
following:
CS(COMM) 861/2023

Page 1 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 15 -->

S.
PARTICULARS
NO
1.
Wordmark: FABINDIA
(DEVICE)
Proprietor: FABINDIA
LIMITED
Application Number: 759211
Class / Classes: 25
Status: Registered
2.
Wordmark: FABINDIA
CELEBRATE INDIA
Proprietor: FABINDIA
OVERSEAS PRIVATE
LIMITED
Application
Number: 2845335
Class / Classes: 25
Status: Registered
3.
Wordmark: FABINDIA
Proprietor: FABINDIA
OVERSEAS PRIVATE
LIMITED
Application
Number: 2845351
Class / Classes: 25
Status: Registered
4.
Wordmark: FABINDIA
Proprietor: FABINDIA
OVERSEAS PRIVATE
LIMITED
Application
Number: 2845356
Class / Classes: 35
Status: Registered
5.
Wordmark: Fabindia
Experience Centre
Proprietor: FABINDIA
OVERSEAS PRIVATE
LIMITED
Application
Number: 3696348
Class / Classes: 35
Status: Registered
6.
Wordmark: Fabindia
Experience Centre celebrate
INDIA
Proprietor: FABINDIA
OVERSEAS PRIVATE
LIMITED
CS(COMM) 861/2023

TRADE MARK

Page 2 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 16 -->

Application
Number: 3696350
Class / Classes: 35
Status: Registered

3.

7.

Wordmark: FAB INDIGO
Proprietor: FABINDIA
OVERSEAS PVT. LTD.
Application
Number: 3325457
Class / Classes: 25
Status: Registered

8.

Wordmark: FAB NATURALS
Proprietor: FABINDIA
LIMITED
Application
Number: 3325462
Class / Classes: 25
Status: Registered

The plaintiff has a network of over “Fabindia” stores retailing

its products across India, including 28 owned experience centers, 185
company-owned and company-operated stores and 96 franchiseeowned and franchisee-operated stores. These outlets house the
company's product and service offerings under a single umbrella,
providing customers with an experiential and comprehensive Fabindia
retail experience.

4.

Averring thus, the plaint also provides the figures of sales

revenue earned by the plaintiff, both in the individual segments as
well as overall revenue earned by the plaintiff, using the mark
“Fabindia”, during the year 2022-2023 alone, on e-commerce
platforms, is to the tune of ₹ 95 crores, the plaintiff’s earnings are ₹
167 crores against sale of apparels, ₹ 1073.49 crores in the home and
lifestyle segment, ₹ 25.48 crores by sale of accessories, ₹ 14.76 crores
CS(COMM) 861/2023

Page 3 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 17 -->

in the personal care segment and ₹ 1280.74 crores in the food and
beverages segments.

The plaintiff claims to have expended

considerable amounts towards advertisement and promotion of the
“Fabindia” mark, the amount spent towards the said purposes in 20222023 itself totalling to ₹ 30.97 crores.

5.

The plaintiff is aggrieved by the fact that several fake websites

have, which claim to be authorized sellers/resellers of the plaintiff’s
products invited customers to purchase the plaintiff’s products from
their websites.

The plaintiff claims to have received complaints

regarding such unlawful activities. Inasmuch as the identities of the
persons running the websites are unknown, the plaintiff has impleaded
them under one heading “Ashok Kumar/John Doe, as Defendant 1.
The said products stated to be sold across the Shopify and Pay – U
websites, who have, therefore, been impleaded as Defendants 2 and 3.
The

most

recent

such

fake

website

is

stated

to

be

https://fabsinida.shop/?syclid=36439983-0773-4b9c-bc6288695bfd482b. Para 21 of the plaint provides the IDs of some other
such fake websites, who are holding themselves out as authorized
retailers of the plaintiff.

These IDs are https://fabindia.shop/,

https://fabindia.club/, https://fabindia.live/, https://fabindia.fashion/,
https://fabindia.design/, https://fabindia.store/, https://fabindia.xyz/ ,
https://fabindia.xyz/policies/contact-information,
https://fabsindia.co.in/.,https://fabsinida.shop/?syclid=364399830773-4b9c-bc62-88695bfd482b and https://fabindya.com/.

6.

The plaintiff claims to have received, till date, 1114 complaints

at its customer care hotline, regarding proliferation of such fake/rogue
CS(COMM) 861/2023

Page 4 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 18 -->

websites, with the number increasing day-by-day.

7.

In these circumstances, the plaintiff wrote to Defendants 2 and

3 on 9 June 2023 and 12 June 2023, calling on them to take down the
offending websites, which were mimicking the plaintiff’s original
“Fabindia” website. There has been little response to these requests,
except that, on some occasions, Defendant 2 has taken down a few
websites.

It is asserted, even thereafter, websites on both the

platforms of Defendants 2 and 3 continued to proliferate.

8.

The plaintiff has provided screenshots of the websites of the

defendants alongside the website of the plaintiff. A glance at the said
screenshots reveals that the defendants are clearly imitating the look
and feel of the plaintiff’s website.

These screenshots may be

reproduced thus:
“PICTURE A – ORIGINAL WEBSITE OF FAB INDIA

CS(COMM) 861/2023

Page 5 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 19 -->

PICTURE B – THIRD PARTY MISUSING FAB INDIA'S
PICTURE AND TRADE MARK

9.

The plaint asserts that the plaintiff has not licensed or

authorized any website except its own authorized website to use the
mark “Fabindia” or any other identical mark.

10.

It is in these circumstances that the plaintiff has approached this

Court by means of the present suit, seeking a decree of permanent
CS(COMM) 861/2023

Page 6 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 20 -->

injunction, restraining any website from using, in any manner
whatsoever, the plaintiff’s trade mark/trade name “Fabindia” or any
variation thereof, in any manner whatsoever, either for providing retail
services in the segments in which the plaintiff operates or in any other
allied goods or services.

11.

Additionally, the plaint seeks a decree of permanent injunction

against Defendants 2 and 3 from allowing any third party to latch on
to the plaintiff’s listing or use the plaintiff’s “Fabindia” mark.
Direction has also been sought to Defendants 4 and 5 to ensure
compliance of the aforesaid directions by calling upon various internet
service providers to block access to the websites identified by the
plaintiff in the present suit or any other website, which uses
“Fabindia” mark and is notified by the plaintiff.

Additionally, a

direction has been sought to Defendant 6, NIXI to block access to any
website using “Fabindia” mark, to which attention of Defendant 6 may
be drawn by the plaintiff. The plaint also seeks damages, rendition of
account, costs and other alike reliefs.

12.

Let the plaint be registered as a suit. Issue summons in the suit.

Summons are accepted on behalf of Defendants 4 and 5 by Mr.
Krishnan V., who appears on behalf of Mr. Harish Vaidyanathan
Shankar.

13.

Written statement, accompanied by affidavit of admission and

denial of the documents filed by the plaintiff be filed within 30 days
with advance copy to learned Counsel for the plaintiff who may file
replication thereto, accompanied by affidavit of admission and denial
CS(COMM) 861/2023

Page 7 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 21 -->

of the documents filed by the defendants within 30 days thereof.

14.

List before the learned Joint Registrar (Judicial) for completion

of the pleadings, admission and denial of documents and marking of
exhibits on 6 February 2024, whereafter the matter would be placed
before the Court for case management hearing and further
proceedings.

I.A. 24111/2023(Order XXXIX Rules 1 and 2 of the CPC)

15.

This is an application by the plaintiff under Order XXXIX

Rules 1 and 2 of the Code of Civil Procedure, 1908 (CPC) seeking
interlocutory injunctive reliefs.

16.

Issue notice, returnable before the Court on 6 March 2024.

Notice is accepted on behalf of Defendants 4 and 5 by Mr. Krishnan
V., who appears on behalf of Mr. Harish Vaidyanathan Shankar.
Notice be also issued to the remaining defendants by all modes.
17.

Reply be filed within four weeks with advance copy to learned

Counsel for the plaintiff who may file rejoinder thereto, if any, within
four weeks thereof.

18.

Inasmuch as the present case involves fraud websites, which are

fraudulently holding themselves out to be retailers/resellers of the
plaintiff and are, on that basis, inviting consumers to purchase the
plaintiff’s products from the said websites, immediate interlocutory
orders are justified. Prayer clause in this application reads thus:
CS(COMM) 861/2023

Page 8 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 22 -->

“In light of the afore-mentioned facts and circumstances,
the Plaintiff most respectfully prays that the Hon'ble Court may
kindly be pleased to grant ex-parte ad-interim and/or interim
injunction:
a.
Restraining the Defendants, their partners,
proprietors, officers, servants, employees and all others in
capacity of principal or agent acting for and on their
behalf, or anyone claiming through, by or under it and any
other website identified by the Plaintiff to be infringing its
trademark, copyright, any and all other exclusive rights,
restraining them from in any manner whatsoever from
infringing, latching, exhibiting, making available for
viewing,
leveraging,
providing
access
and/or
communicating to the public, through the internet, in any
manner whatsoever, the Plaintiff's trade mark/ name
"Fabindia", and its variations including but not limited to
"Fabindia" either as a trademark, trade name, corporate
name, domain name or in any manner whatsoever, in
respect of same and similar good, amounting to unfair
competition and commercial misappropriation of the
Plaintiff's rights.
b.
Restraining the Defendants, their directors,
partners, proprietors, officers, servants, employees and all
other in capacity of principal or agent acting for and, on
their behalf, or anyone claiming through, by or under it,
restraining them from impersonating the Plaintiff
company, endeavouring to market identical or similar
products, and from engaging in the sale or attempted sale
of counterfeit or substandard products of the Plaintiff
Company.
c.
Restraining the Defendant No. 4 and 5, their
directors, partners, proprietors, officers, servants,
employees and all other in capacity of principal or agent
acting for and on their behalf, or anyone claiming through,
by or under it to ensure compliance of this order by calling
upon the various internet service providers registered
under it to block access to the various websites identified
by the Plaintiff's in the instant suit other websites that may
subsequently be notified by the Plaintiff's to be infringing
its exclusive rights.
d.
Restraining
Unknown
and
Unidentified
Defendants, and shutting down their illegal webpages,
domains, websites etc, created to obtain illegal gains,
monetary or otherwise, for infringing the Plaintiff's
trademarks and by riding over the goodwill and reputation
that the Plaintiff has attained/achieved over several years
CS(COMM) 861/2023

Page 9 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 23 -->

of use, advertisement, promotion of its brand "Fabindia" in
numerous jurisdictions around the world/globe including,
India;
e.
Pass any such other order(s) as this Hon'ble Court
may deem fit and proper in the interest of justice and in
favour of the Plaintiff Company and against the
Defendants.”

19.

Having heard Mr. Datar, learned Senior Counsel for the

plaintiff and Mr. Krishnan V, learned Counsel for Defendants 4 and 5,
the following interim orders are passed by this Court to remain in
force till the next date of hearing.

(i)

The defendants, as well as all other acting on their behalf,

are restrained from infringing, latching, exhibiting, making
available for viewing, leveraging, providing access and/or
communicating to the public through internet, in any manner
whatsoever, the plaintiff’s trade mark “Fabindia” and its
variations, either as a trade mark or trade name or corporate
name or domain name or in any manner whatsoever in respect
of retail services or any other allied goods of services.

(ii)

Defendants 4 and 5 are directed to call upon the various

internet service providers registered under them to block access
to the following websites identified by the plaintiff in paras 20
and 21 of the plaint and noted in para 5 (supra)
“https://fabindia.shop/,
https://fabindia.club/,
https://fabindia.live/,
https://fabindia.fashion/,
https://fabindia.design/,
https://fabindia.store/,
CS(COMM) 861/2023

Page 10 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 24 -->

https://fabindia.xyz/,
https://fabindia.xyz/policies/contact-information,
https://fabsindia.co.in/.,
https://fabsinida.shop/?syclid=36439983-0773-4b9c-bc6288695bfd482b and https://fabindya.com/.”
(iii) In order to ensure that the plaintiff is not required to
come again and again to the Court, this injunction shall extend
to any other website/domain name using the mark “Fabindia” to
which the plaintiff draws the attention of the defendants. In
case, any such new infringing website comes up, the plaintiff
shall file an additional affidavit before this Court drawing
attention of the Court to the said website.
(iv) Defendants 9 and 10 are directed to disclose, forthwith,
identities of the persons, who own/operate the websites noted in
para 5 (supra). Upon such information being provided, the
plaintiff shall forthwith implead the said persons by filing an
amended memo of parties in that regard. If any such amended
memo of parties is filed, summons in the suit and notice in the
present application, in the aforesaid terms, shall be issued to
such newly impleaded parties as well for due compliance in
accordance with the order passed today.
(v)

Defendant 6 is also directed to block access to the

domain names/websites identified hereinbefore.

20.

Compliance of Order XXXIX Rule 3 of the CPC be effected on

the unserved defendants within a week from today.

CS(COMM) 861/2023

Page 11 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 25 -->

I.A. 24112/2023 (Exemption)
21.

Subject to the plaintiff filing legible copies of any dim or

illegible documents within 30 days, exemption is granted for the
present.

22.

The application is disposed of.

I.A. 24113/2023 (Order XI Rule 1(4) of the CPC)
23.

This application seeks permission to file additional documents.

The plaintiff is permitted to place additional documents on record in
accordance with Order XI Rule 1(4) of the Code of Civil Procedure,
1908 (CPC) as amended by the Commercial Courts Act within four
weeks from today.

24.

The application stands disposed of accordingly.

I.A. 24114/2023 (Exemption from advance service)
25.

This is an application for exemption from advance service. The

service stands exempted inasmuch as the identity of the persons
pertaining to infringing websites are concerned, they are unknown.
As such, there can be no service of advance notice on them.

26.

The application is disposed of.

I.A. 24115/2023 (Section 12A of the Commercial Courts Act, 2015)

CS(COMM) 861/2023

Page 12 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 26 -->

27.

In view of the nature of the present dispute, there has not been

pre-institution mediation, the application is disposed of accordingly.

C.HARI SHANKAR, J
DECEMBER 4, 2023
rb
Click here to check corrigendum, if any

CS(COMM) 861/2023

Page 13 of 13

This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the QR code shown above.
The Order is downloaded from the DHC Server on 21/11/2025 at 09:59:17

<!-- page 27 -->

Annexure
Subject: Action requested to be taken by MEITY and Plantiff for effective removal of
content for viewing by public at large within India as per the said orders of
Hon’ble Court.
It is observed that a number of orders of Hon’ble Court are issued for blocking of
websites every month. There are around more than 2700 ISPs in India and these ISPs
are connected among themselves in a mesh network. DOT is instructing each of the ISPs
through emails/through its website for blocking of the websites as ordered by the Hon’ble
Courts. Ensuring compliance of the orders by each of the ISPs is a time-consuming and
complex task especially in view of multiplicity of orders of Hon’ble Courts, multiplicity of
websites to be blocked and multiplicity of ISPs.
2.

Allocation of Business Rules inter-alia sates thus:-

‘Policy matters relating to information technology; Electronics; and Internet (all
matters other than licensing of Internet Service Provider)’.
3.
In view of above and in order to ensure effective removal by content for viewing
by public at large, the plantiff is requested to do a trace route of the web server hosting
the said website. In case the web server happens to be in India, the plantiff may inform
the same to Meity who may direct the owner of such web server to stop transmission of
content as per IT Act and as directed by the Hon’ble Court so that the content would be
blocked from the source itself and the exercise of blocking by 2700 ISPs would not be
required.
4.
In case such server is located abroad i.e. outside India then access to such
URL/website can be blocked through the international internet gateways which are much
less in number. This would result in timely and effectively removal of undesirable content
for viewing by public at large as is the requirement as per the orders of Hon’ble Court.
