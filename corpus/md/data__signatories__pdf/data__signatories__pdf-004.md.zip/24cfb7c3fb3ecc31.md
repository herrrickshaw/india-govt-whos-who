---
doc_id: "24cfb7c3fb3ecc31"
source_url: "https://www.dahd.gov.in/static/uploads/2025/06/2ff947f200ee571f36f20cc2922d6b61.pdf"
ministry: "Department of Animal Husbandry and Dairying (DoAHD)"
title: "Shri Jagat Hazarika, Advisor, is hereby appointed as part-time Chief Vigilance Officer (CVO) in the DAHD for an initial period of three years."
date: "2025-06-04"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "13e986ce2eabe5ee"
---

<!-- page 1 -->

A-22011/1/2024-Admin.1/(E-29016)
Government of India
Ministry of Fisheries, Animal Husbandry and Dairying
Department of Animal Husbandry and Dairying
Krishi Bhawan, New Delhi — 110001
Dated, thecWune, 2025
OFFICE ORDER
In pursuance of the approval conveyed by the Central Vigilance Commission
(CVC) vide its letter No. 4X-CVO-15-Part(1)-60567 dated 27.05.2025, Shri Jagat
Hazarika, Advisor, is hereby appointed as part-time Chief Vigilance Officer (CVO) in
the Department of Animal Husbandry and Dairying for an initial period of three years
from the date of assumption of charge of the post or until further orders, whichever is
earlier.
2 Shri Jagat Hazarika is requested to assume charge of the duties of part-time
CVO with immediate effect and thereafter, the necessary entry shall be made in the
CVOIS portal maintained by the Commission.
3. The vigilance profile of Shri Jagat Hazarika, as sought by the CVC, is being
obtained from the cadre controlling authority and will be forwarded to the Commission
upon receipt.
This issues with the approval of the Secretary, AHD
(Pankaj Kumar Sinha)
Under Secretary to the Government of India
Tel: 011-23382779
Email: pk.sinha88@gov.in
Copy to:
1. Shri Jagat Hazarika, Advisor (Stats.), D/o AH&D.
2. Sr. PPS to Secretary, AHD
3. Sr. PPS/PPS to AS(C&DD)/AS(LH)/JS(Admin & Coord)/Advisor(Stats.)
4. Shri Anirban Biswas, Under Secretary, Central Vigilance Commission, Satarkta
Bhawan, GPO Complex, Block A, INA, New Delhi-110023
5. Vigilance Section/Personnel Section, AHD |
6. NIC Cell — for uploading on Department's website/e-office Notice Board. |
7. Personal File/Order Bundle/Guard File/Spare Copies.
|
