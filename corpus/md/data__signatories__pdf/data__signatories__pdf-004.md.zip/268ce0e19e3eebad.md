---
doc_id: "268ce0e19e3eebad"
source_url: "https://www.dhr.gov.in/static/uploads/2025/10/680b811e57667a1da8cd2ff085cf9510.pdf"
ministry: "Department of Health Research (DHR)"
title: "Public opinion/ comments/suggestions sought for the Policy on Research Infrastructure Sharing Ecosystem (P-RISE)"
date: "2023-02-01"
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "23b28f793b25b133"
---

<!-- page 1 -->

POLICY ON

Research Infrastructure
Sharing Ecosystem (P-RISE)

2023

<!-- page 2 -->

<!-- page 3 -->

Policy on Research Infrastructure
Sharing Ecosystem (P-RISE)
A Document for sharing of DHR-ICMR Research
Infrastructure for Integrated Healthcare Approach
2023

<!-- page 4 -->

©Indian Council of Medical Research
Year of Publication: 2023
All rights reserved
Patron:

Dr. Rajiv Bahl
Secretary, Department of Health Research &
Director General, Indian Council of Medical Research, Delhi

Guidance:

Smt. Anu Nagar, Joint Secretary, Department of Health Research, Delhi

Committee Members:
•

Dr. Rajni Kant, Chairperson, Scientist G & Head, Division of Policy & Communication,
ICMR Headquarter, Delhi & Director ICMR- Regional Medical Research Center, Gorakhpur

•

Dr. Ashwani Kumar, Director ICMR-Vector Control Research Centre, Puducherry

•

Dr. Santasabuj Das, Director, ICMR-National Institute of Occupational Health,
Ahmedabad

•

Dr. Nabendu S. Chatterjee, Scientist G & Head, Basic Medical Sciences, ICMRHeadquarter, Delhi

•

Dr. Harpreet Singh, Scientist F & Head, Biomedical Informatics, ICMR, Headquarter, Delhi

•

Dr. Balu V Gopal, Project Scientist C, Department of Health Research, Delhi

Research and Analysis Support :
•

Dr. Enna Dogra Gupta, Scientist C, Division of Policy and Communication, ICMRHeadquarter, Delhi

•

Dr. Priya Gaur, Project Scientist C, Division of Policy and Communication, ICMRHeadquarter, Delhi

•

Dr. Rajeev Singh, Scientist C, ICMR- Regional Medical Research Centre, Gorakhpur

•

Dr. Niraj Kumar, Technical Officer -B, ICMR-Regional Medical Research Centre, Gorakhpur

Designing Support:

Global Health Strategies, Delhi

<!-- page 5 -->

Abbreviations

AMC:

Annual Maintenance Charge

BSL:

Biosafety Level

CIF:

Central Instrumentation Facility

DG:

Director General

DHR:

Department of Health Reseach

GFR:

General Finance Rules

HR:

Human Resource

ICMR HQ:

Indian Council of Medical Research Headquarter

MoHFW:

Ministry of Health and Family Welfare

MoU:

Memorandum of Understanding

MSME:

Micro, Small and Medium Enterprises

P-RISE:

Policy on Research Infrastructure Sharing Ecosystem

<!-- page 6 -->

<!-- page 7 -->

Contents

1. Background

1

2. Purpose and Scope

2

3. Objectives

2

'JSJ‫ܪ‬YXTKYMJ7JXJFWHM.SKWFXYWZHYZWJ8MFWNSL5TQNH^

3

,JSJWFQ9JWRXFSI(TSINYNTSXKTW8MFWNSL7JXJFWHM.SKWFXYWZHYZWJ

3

5WTHJIZWJKTW7JXJFWHM.SKWFXYWZHYZWJ8MFWNSL

4

7JXUTSXNGNQNY^TKYMJ8YFPJMTQIJWX

5

(TRUQFNSY7JIWJXXFQ

8

)NXXJRNSFYNTSTK57.8*FSI(.+TK.(27.SXYNYZYJX

8

*YMNHFQ7JVZNWJRJSYX

8

1JLFQ7JVZNWJRJSYX

9

<!-- page 8 -->

<!-- page 9 -->

Policy on Research Infrastructure Sharing Ecosystem (PRISE) | Page 1

1. Background
Department of Health Research (DHR) works with
a mandate of promotion and coordination of basic,
applied clinical, and operational research through
infrastructure, manpower, and skill development in
cutting edge areas along with the implementation of
such researches for better health outcomes and human
well-being. Department of Health Research comprises
the Indian Council of Medical Research (ICMR), an
autonomous body, and its network of institutions
across the country.
ICMR, the apex medical research body in India has
always made substantial efforts to promote biomedical
health research in the country. ICMR recognizes the
growing need from the Indian research community for
access to cutting-edge state-of-the-art technologies
and instruments for medical and scientific research.
ICMR, through its institutes, has developed a strong
network of biomedical research laboratories in the
country. These sophisticated laboratories created
and maintained over the years in ICMR can also be
effectively and optimally utilized for scientific research
and academic growth of the country in the health
research sector. The initiative of sharing and effectively
utilizing these research laboratories generated through
public funds, with researchers across the country will
promote health research by ensuring quality research
outcomes and facilitating innovative research.
Currently, access to cutting-edge and state-of-art
facilities in health research infrastructure has limited
access in India, due to the high cost of equipment’s
and their subsequent maintenance and running cost.
A limited pool of trained manpower who handles such
sophisticated instruments is another bottleneck.
However, the number of researchers in the health sector
is increasing day by day, and thereby it is imperative

that mechanisms for access to critical scientific
infrastructure should be in place to provide support
to deserving researchers/ institutions who lack such
facilities. The medical/dental/pharmacy colleges/
universities and other research-oriented institutions
represent a large pool of researchers whose scientific
outcome gets confined or compromised due to limited
or no access to the required research infrastructure.
This lacuna can be sealed to a maximum extent by
making available the existing laboratory resources to
all researchers in the country.
Considering the necessity of having a structured
research infrastructure sharing and access policy,
this document is formulated to provide guidance on
appropriate sharing and responsible management of
research infrastructure available in ICMR institutes.

<!-- page 10 -->

Page 2 | Policy on Research Infrastructure Sharing Ecosystem (PRISE)

2. Purpose and Scope
The purpose of the policy is to provide a structured
overview for sharing of advanced research facilities in
ICMR laboratories (high tech research infrastructure
in the country even through institutes in Tier II cities)
with researchers from medical colleges/universities
and other institutions. This will help:
•

•
•
•
•

The overall purpose is to facilitate and encourage
biomedical research in India and support research
and development of health technologies to improve
health of citizens and contribute towards make in India
mission for diagnostics, therapeutics and vaccines.

Facilitate access to sophisticated instrumentation
to researchers working in institutions with limited
infrastructure, enabling them to perform good
research.
Encourage research outreach and networking.
Improve quality data health research.
Ensure cost-effective research outcomes.
Avoid duplication of Research Infrastructure.

This policy may be referred by all researchers from
Medical Colleges/Universities/R&D facilities/Startups/ MSME industries for utilizing the infrastructure
facilities of the above given institutions for the purpose
of Research and Development.

3. Objectives
1. To establish access to a centralized network of
scientific research infrastructure within ICMR
to fulfill the research needs of all researchers
across the country thereby ensuring optimal use
of available research infrastructure.

2. To develop a provision of incentivization to the
host institutes/researchers to support sharing and
utilization of ICMR research facilities.

<!-- page 11 -->

Policy on Research Infrastructure Sharing Ecosystem (PRISE) | Page 3

ׄ‫ خ‬ƵȁƵ˛ɈȺȌǏɈǘƵªƵȺƵƊȲƧǘ
Infrastructure Sharing Policy
1. To ensure optimal use of research instrument/
facility available at ICMR institutes through sharing
with Indian research community.
2. To reduce cost involved in procurement and
maintenance of research infrastructure by
sharing of established state-of-the art equipment/
infrastructure at ICMR institutes, thereby enhancing
the efficiency of expenditure made by DHR-ICMR,
MoHFW.

3. To resolve the unmet needs of researchers/
scholars/ academicians/ private organizations
towards access to state of the art research
infrastructure
thereby
promoting
research
activities and improving scientific output of the
country.

5. General Terms and
Conditions for Sharing
Research Infrastructure
1. The host institute will list all the sharable
instrument/ facility available at respective institute
in the P-RISE portal. Basic general instruments
may be included in Central Instrumentation Facility
(CIF). It is mandatory that all equipment costing
above 10 lakhs to be included in CIF and listed in
portal.
2. Only those institutes listed in P-RISE portal will
come under the purview of this policy.
3. Host institute should ensure that at least 20% of

the user time of each equipment be allocated to
external users.
4. Centralized instrumentation facility shall be
responsible for maintaining the online log
regarding the availability, usage and maintenance
of instrument/ facility at each institute.
5. Only trained and skilled /certified operators of
the host institutes will be allowed to operate the
facilities of ICMR.

<!-- page 12 -->

Page 4 | Policy on Research Infrastructure Sharing Ecosystem (PRISE)

6. The services shall be availed by the external user
under supervision of host institute only, as per the
time slot assigned.
7. Liabilities of the host institute include ensuring the
availability of equipment in the portal, maintenance
of equipment at laboratories as per the terms
of procurement, AMC and timely disposal of
equipment as per GFR 2017.
8. Charges for maintenance and running costs of
the instruments may be taken from requesters.
For utilization of instrument/ facility at ICMR
institutes, charges shall be proposed uniformly
by a central committee on the user, based on the
type of equipment utilized, number of samples to

be processed and reagents utilized, factoring time
etc. The pricing may be tiered for government &
private institutions /universities/ industries /
MSMEs.
9. The applicants with fund limitation will have
provisions to request for subsidization, which will
be decided by the respective institution based
on the quality of research proposal on caseto-case basis. Such request may be submitted
by the requester through portal in advance to
the respective institute. There is provision of
incentivization to the host institutes /researchers
through a scheme to encourage the process of
sharing/effective utilization of the instrument/
facility by the research community.

6. Procedure for Research
Infrastructure Sharing
1. Each ICMR institute will set up a central
instrumentation facility (CIF) to which all sharable
equipment will be linked. Till the CIF is established,
existing facilities may be open for utilization.
2. Research Infrastructure sharing will be promoted
through an online system where all shareable
instruments/facilities of ICMR institutes will be
listed with trained manpower.
3. Researchers will be allowed to raise a request for

booking through the portal, which will be confirmed
by the institute.
4. The portal must clearly maintain an update
of facilities which are non-utilized, optimally
utilized or over-utilized, for optimal distribution of
resources.
5. All ICMR intra-institutional booking will also have
to be done through the portal.

<!-- page 13 -->

Policy on Research Infrastructure Sharing Ecosystem (PRISE) | Page 5

6. There will be a 4-level hierarchy implemented while
accessing the CIF of ICMR institutes through the
online portal with individual responsibilities as
detailed in section 7.
7. CIF nodal officer will be the nodal contact for
booking and processing who will further confirm the
booking and communicate back after confirmation
of slot availability from technical contact. Reports
issued will be released with approval of Instrument
in charge.

minimum period that will not exceed one month
from generation of the report.
9. Ownership and Copyright: No ICMR institute/CIF
facility members will have ownership/copyright on
any of the tests done or result generated unless
agreed before the test is conducted, in case of
instances like collaboration, mutual agreement
etc. However, the efforts of ICMR may be
acknowledged by the user writing any manuscript/
research paper/ report.

8. Data retention and disposal: Research data and
related records must be retained only for the

7. Responsibility of
the Stakeholders
‫ خ‬Ǐ˛ƧƵȌǏ§ٌªX²0ƊɈX!wª
RƵƊƮȱɐƊȲɈƵȲȺ
a. A unit will be set up at the ICMR Head Quarter
to centrally monitor and facilitate the research
infrastructure sharing mechanism of DHR-ICMR. The
ZSNY\NQQHTTWINSFYJ\NYMYMJSTIFQTK‫ܪ‬HJWTKNSIN[NIZFQ
institutes for facilitation.

b. ICMR-HQ shall develop user-friendly and interactive
portal with public access and simple dashboard
display with a single window approval process and
maintained centrally at ICMR HQ.
c.

The Central Committee will be responsible for deciding
on the charges for usage of instruments subjected to
approval of DG, ICMR to maintain the uniformity of
pricing across all ICMR institutes.

<!-- page 14 -->

Page 6 | Policy on Research Infrastructure Sharing Ecosystem (PRISE)

d. An independent committee to review the appropriate
implementation and utilization of facilities needs to be
put in place.
e.

•

Any complaints may be addressed to the in-charge of
P-RISE unit at ICMR HQ (whose details will be displayed
in the portal). Complaint redressal mechanisms are

•

also inbuilt in the portal.
f.

DHR/ICMR funded labs and other institutions will be
encouraged to join this policy to share their research
infrastructure with needy researchers. Provisions will
be available in the portal once a request is made to
ICMR HQ to add such institutes voluntarily willing to
share their facilities through an MoU, as approved by
the oversight committee at ICMR-HQ.

‫ خ‬X!wªXȁȺɈǞɈɐɈƵȺ
a. The institute will be responsible for purchase,
maintenance and providing HR support for the
instrument listed in P-RISE.
b. The institute will maintain usage log for each
equipment/ facility listed in P-RISE.
c.

The following hierarchy will be responsible maintaining
the activities of CIF.
•
•

Head of the institute: Governance and
Monitoring of CIF facility.
(.+ 3TIFQ TK‫ܪ‬HJW <NQQ GJ NS HMFWLJ TK (.+
facility and routing of test requests received,
HTS‫ܪ‬IJSYNFQNY^ TK YMJ IFYFNSKTWRFYNTS
generated and coordinate redressal of

complaints. The Director of the institute will
NIJSYNK^STIFQTK‫ܪ‬HJW
Instrument in charge: The person in charge
of the Department /Division in which the
instrument is placed.
Technical Contact: Person in charge of handling
or using the instrument. Dedicated technical
staff may be assigned for instrument.

d. All samples should be received along with the form
signed by authorized personnel (requester).
e.

Upon receiving the sample sent/handed over by a
requester, the technical person/staff should assess
the quality of processing and note the comments on
the same in the portal.

f.

In case of samples with compromised processing
quality, the technical person/staff with approval of
the instrument in charge can reject the sample from
accepting and modify the booking.

g. In case, the samples are of unknown/known infectious
material (of high risk), the bio safety level can be
requested by the user and the central committee or the
STIFQTK‫ܪ‬HJWRF^QTTPNSYTYMJXZNYFGNQNY^TK'81XUFHJ
to be provided for working to the requester.
h. Samples once tested will not be retained/ stored by the
host institute.
i.

Appropriate training to be imparted to users/custodians
at regular intervals to ensure quality optimal use of the
instrument.

<!-- page 15 -->

Policy on Research Infrastructure Sharing Ecosystem (PRISE) | Page 7

j.

Robust referral mechanisms for sending requests
from one lab to another.

k.

The Technical contact will advise/suggest the
requester the quality of reagents, chemicals, supplies
etc to be brought or carrying out the work.

l.

d. The Data/result generated will be transferred only
to requester through the portal or in originals as
requested by the requester.
e.

Requesters are encouraged to approach the CIF
STIFQ TK‫ܪ‬HJW GJKTWJ LJSJWFYNSL GTTPNSL WJVZJXY KTW
information regarding sample preparation, quality
requirements, biosafety precautions and analysis
parameters before the actual use takes place.

f.

It is encouraged that users should provide preprocessed samples depending on the experimental
requirement and the equipment to be used thereof. The
ICMR institutes will not be responsible for processing
or analysis of the data generated from the equipment.

A ‘Quality Control’ system is mandatory at the institute
level.

m. Complaint redressal system may be developed at
institute level to resolve issues that comes under the
purview of this document.
n. Revenue generated would be utilized for maintenance
of CIF instruments.

!‫ خ‬ªƵȺƵƊȲƧǘƵȲȺ
a. Requesters should belong to a registered medical /
research academic organization /MSMEs /industry.

g. Only samples for research purposes are entertained.
Routine samples from hospitals/ patient care shall not
be entertained through this facility.
h. Sample processing and submission may be done
according to the instructions either available in the
UTWYFQTWFXNSXYWZHYJIG^YMJ(.+STIFQTK‫ܪ‬HJW
i.

b. Requests should be submitted and received through
proper channel via the online portal.
c.

Requester should make sure for submission of
samples without compromising quality. In case of
temperature/light sensitive samples, requester should
take additional precaution to maintain the same.

In case of unsatisfactory data obtained, the complaint
may be raised according to the Complaint Redressal
mechanism mentioned in section 8.

<!-- page 16 -->

Page 8 | Policy on Research Infrastructure Sharing Ecosystem (PRISE)

8. Complaint Redressal
In case of any complaint, the researcher may approach the Head of the respective ICMR institute where the test
was conducted. Also, the portal will have inbuilt complaint redressal mechanisms for transparency.

9. Dissemination of P-RISE
and CIF of ICMR Institutes
1. All information related to P-RISE and CIF facility of
Individual ICMR institutes will be available on the
portal.

2. All ICMR institutional website will be integrated
with the ICMR P-RISE portal.

10. Ethical Requirements
1. The CIF nodal officer will have all rights to ask the
requester to submit a copy of the ethics committee
or any other regulatory approvals as appropriate
at any time point for processing the sample/
releasing the reports.
2. ICMR will have no ownership on the data derived
unless previously committed by the user as in case
of a collaboration or agreement.
3. User is bound to reveal the character, behavior
and properties of all types of samples submitted

through the portal to the CIF nodal officer and
technical officer in view of the potential harm such
samples may cause and precautions to be taken.

<!-- page 17 -->

Policy on Research Infrastructure Sharing Ecosystem (PRISE) | Page 9

11. Legal Requirements
1. It is the responsibility of all researchers and staff
of ICMR institutes to ascertain and comply with
any legal, ethical, or contractual confidentiality
conditions relating to execution of the commitment
made vide this policy.

3. ICMR CIF will not be responsible for any
discrepancies/malpractices
performed
or
happened on the sample submitted by the requester
before it is brought to CIF facility and after being
taken from CIF facility.

2. Steps may be taken to ensure the confidentiality of

4. The ICMR institute will not be responsible for any
failure in data acquisition due to machine failure/
loss of sample.

data /test report generated for the requester.

<!-- page 18 -->

<!-- page 19 -->

<!-- page 20 -->

Website: www.icmr.gov.in
