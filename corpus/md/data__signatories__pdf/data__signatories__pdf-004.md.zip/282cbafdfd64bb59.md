---
doc_id: "282cbafdfd64bb59"
source_url: "https://www.dot.gov.in/static/uploads/2025/07/1e0701a54401997022ac2313e8f0787f.pdf"
ministry: "Department of Telecommunications (DoT)"
title: "Taken on strength - Sh Arvind kumar chaudhary Staff No. 96581 JAG Level P&T Building works Group A service dt 22.04.25"
date: "2025-04-23"
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f08062baae0468e2"
---

<!-- page 1 -->

6-1/2014-EW(E)-Part(1)

1/3269931/2025

No. 06-01/2014-EW(E)-Part(1)

Government of India
Ministry of Communications

Department of Telecommunications
(A&E Section)
618-A, Mahanagar Doorsanchar Bhawan,
JLN Marg, New Delhi-110 002
Dated: 22.04.2025

Office
Sh. Arvind Kumar Chaudhary,

officer of P&T
Posts,

Building

Bengaluru

vide

Works
DoT

Department

EWP-Part(1)

dated 08.04.2025

No.

of Posts,

Hg, New Delhi.
2.

SE(Electrical), Staff No. 96581,

Gr. ‘A" Service

order

relieved from

Or

on transfer from

6-1/2014-EW(E)

Bengaluru

dated

a JAG

Level

Department
27.12.2024

vide their Order No.

of
and

1-18/2024-

has reported for duty on 21.04.2025 (F/N) in Dol

He has been taken on the strength of DoT Hg, New Delhi w.e.f. 21.04.2025

(FN).
3.

This issues with the approval of Competent Authority.
Digitally

signed

Awadhesh

Date:

by

Kumar

Singh

22-04-2025

16:07:43

)

(Awadhesh Kumar Singh)
Director (Electrical)
Ph.No.: 011-23218925

Email: direlect-dot@nic.in

OCoONOO
O~
WN

=

To,

. Sr. PPS to Secretary (T)
. Sr. PPS to Member (S), DoT HQ

. Sr. DDG (BW)/ DDG(Estt.), DoT HQ
. CE(Electrical), DoP

. CAO/PAO/DDO concerned
. Section Officer (G-1/G-1I/ Cash/Pay Bill/PAO/Admin-1V)

. Officer Concerned
. Order Bundle
. Director (EW) with a request to upload on the DoT website.
