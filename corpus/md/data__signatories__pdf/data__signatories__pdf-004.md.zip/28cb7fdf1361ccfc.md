---
doc_id: "28cb7fdf1361ccfc"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/e13bd52e525c7306cc69f024e8ead0a9.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Clarification regarding exemptions under Quality (Control) Order, 2009 (Benchmarking)"
date: "2025-07-02"
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4d89ea6abcd4aa99"
---

<!-- page 1 -->

Most Immediate
No. 16(12)/2012-LR
Government of India
Ministry of Comnierce & Industry
Department of Industrial Policy & Promotion
(LR Section)
Udyog Bhawan, New Delhi
: 25.07.2013
Dated
OFFICE MEMORANDUM

Subject : Exemption of tyres imported by domestic tyre manufacturing companies and
Original Equipment Manufacturers (OEMs) for benchmarking, homologation
and calibration purposes from the purview of Quality (Control) Order, 2009 for
Pneumatic Tyres and Tubes for Automotive Vehicles.
The undersigned is directed to say that an issue regarding import of certain quantity of
tyres by the tyre manufacturing companies for benchmarking purposes was under
consideration. The matter was considered in the inter Ministerial meeting on 29.05.2013
under the Chairmanship of Additional DGFT and it has been decided to allow import of 150
(No.) of tyres of each size (without BIS marking) for benchmarking, homologation and
calibration purposes by the
domestic tyre manufacturers
and
Original Equipment
Manufacturers (OEMs) under Clause 3 (d} of the Quality Control Order, 2009 with the following
stipulations:(i)

The quantity of tyres imported by the tyre manufacturers and OEMs for
benchmarking, homologation and calibration purposes should not exceed

beyond 150 tyres of each size.
(ii)

Only domestic tyre manufacturing companies and OEMs would be entitled to
import such tyres for benchmarking, homologation and calibration purposes and
they would keep proper entries in their records and

(iii)

Domestic tyre manufa cturers and OEMs have to give a clear undertaking to the
custom authorities that such imported tyres will be used exclusively for
benchmarking, homologation and calibration purposes and would not be sold in
the market to other consumers.

2.
The aforesaid quantity of 150 tyres of each size will be exempted from mandatory BIS
marking under the Quality (Control) Order, 2009 for Pneumatic Tyres and Tubes for Automotive
Vehicles.
Yours fa ithfully,

�
(Babu Lal)

Director
Telefax : 23063212
1.

Department of Consumer Affairs,
(Shri Ashok Jain, Director (BIS),
Krishi Bhavan, New Delhi

<!-- page 2 -->

-2-

2.

Director (Customs),
Central Board of Excise & Customs,
Department of Revenue, 2 Floor,
North Block, New Delhi.

3.

Director General of Foreign Trade,
(Shri D.K. Singh, Addl. DGFT),
Department of Commerce,
Udyog Bhawan, New Delhi.

4.

Bureau of Indian Standards
(Kind Attn : Shri Afzal Amanullah, IAS, Director General)
Manak Bhava n,
9 Bahadur Shah Zafar Marg,
New Delhi.

5.

Ministry of Road Transport and Highways,
(Shri Anand Prakash, Director),
Room No. 531, Transport Bhawan,
1, Parliament Street, New Delhi-1

6.

Automotive Tyre Manufacturers' Association (ATMA),
(Shri Rajiv Budhraja, Director General),
PHD House, ( 4 Floor), Opp. Asian Games Village,
Siri Fort Institutional Area, New Delhi-110016

7.

Society of Indian Automobile Manufacturers (SIAM),
(Shri Sugato Sen, Deputy Director General),
Core 4-B, 5 Floor, India Habitat Centre,
Lodi Road, New Delhi-110003

8.

All India Tyre Dealers Federation,
(Shri S.P. Singh, Convenor),
865/32, Guru Nanak House, S.P. Mukherjee Marg,
�
New Delhi - 110006.

9.

Indian Tyre Technical Advisory Committee (ITTAC),
(Shri T. Chakravarthy, Secretary General),
PHD House (4 Floor),
August Kranti Marg,
New Delhi - 110016.
