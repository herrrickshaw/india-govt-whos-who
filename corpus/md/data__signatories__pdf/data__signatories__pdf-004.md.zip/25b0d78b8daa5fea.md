---
doc_id: "25b0d78b8daa5fea"
source_url: "https://www.dpiit.gov.in/static/uploads/2025/07/c4653e899a84144a3f7f8339bf2851be.pdf"
ministry: "Department for Promotion of Industry and Internal Trade (DPIIT)"
title: "Press Note No. 3 (2009 Series) Dated: 13th February 2009 issued by Department of Industrial Policy & Promotion, MoC"
date: "2025-07-14"
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b54ea92fc76c3d04"
---

<!-- page 1 -->

Government of India
Ministry of Commerce & Industry
Department of Industrial Policy & Promotion
(FC Section)
Press Note No 3 (2009 Series)

Subject:

Guidelines for transfer of ownership or control of Indian companies in
sectors with caps from resident Indian citizens to non-resident entities.

At present, the transfer of shares from residents to non-residents, including
acquisition of shares in an existing company, is on the automatic route, subject to the
sectoral policy on FDI. Concerns have been raised on recent acquisitions of certain Indian
companies by non-resident entities in sectors with caps. Accordingly, guidelines for transfer
of ownership or control of Indian companies in sectors with caps from resident Indian
citizens to non-resident entities have been formulated and are enumerated below.
2.0

Definitions:

2.1 The term ‘Resident Indian Citizen’ shall be interpreted in line with the
definition of ‘person resident in India’ as per FEMA, 1999, read in conjunction with the
Indian Citizenship Act.
2.2

A ‘non resident entity’ means a ‘person resident outside India’ as defined

under FEMA 1999.
2.3 The term ‘Indian Company’ means a company registered or incorporated in
India as per the Indian Companies Act, 1956.
2.4 For the purpose of these guidelines, an Indian company may be taken as being:
•

“owned” by resident Indian citizens and Indian companies, which are owned

and controlled by resident Indian citizens, if more than 50% of the equity interest in it is
beneficially owned by resident Indian citizens and Indian companies, which are owned and
controlled ultimately by resident Indian citizens;

1

<!-- page 2 -->

•

“controlled” by resident Indian citizens and Indian companies, which are

owned and controlled by resident Indian citizens, if the resident Indian citizens and Indian
companies, which are owned and controlled by resident Indian citizens, have the power to
appoint a majority of its directors.
2.5 Further, for the above purpose, an Indian company may be taken as being:
• “owned” by ‘non resident entities’, if more than 50% of the equity interest in it is
beneficially owned by non-residents
• “controlled” by ‘non resident entities’, if non-residents have the power to appoint
a majority of its directors.
2.6 Foreign investment shall include all types of foreign investments i.e. FDI,
investment by FIIs, NRIs, ADRs, GDRs, Foreign Currency Convertible Bonds (FCCB) and
convertible preference shares, regardless of whether the said investments have been made
under Schedule 1, 2, 3 and 6 of FEMA (Transfer or Issue of Security by Persons Resident
Outside India) Regulations.
Guidelines for transfer of ownership or control of Indian

3.0

companies in sectors with caps from resident Indian citizens to non-resident entities in
sectors with caps:
3.1

In sectors with caps, including interalia defence production, air

transport services, ground handling services, asset reconstruction companies, private sector
banking, broadcasting, commodity exchanges, credit information companies, insurance,
print media, telecommunications and satellites, Government approval/FIPB approval would
be required in all cases where:
3.1.1 An Indian company is being established with foreign investment and is owned
by a non-resident entity or
3.1.2 An Indian company is being established with foreign investment and is
controlled by a non-resident entity or
3.1.3 The control of an existing Indian company, currently owned or controlled by
resident Indian citizens and Indian companies, which are owned or controlled by resident
Indian citizens, will be/is being transferred/passed on to a non-resident entity as a

2

<!-- page 3 -->

consequence of transfer of shares to non-resident entities through amalgamation, merger,
acquisition etc. or
3.1.4 The ownership of an existing Indian company, currently owned or controlled
by resident Indian citizens and Indian companies, which are owned or controlled by
resident Indian citizens, will be/is being transferred/passed on to a non-resident entity as a
consequence of transfer of shares to non-resident entities through amalgamation, merger,
acquisition etc.
3.2 It is clarified that these guidelines will not apply for sectors/activities where
there are no foreign investment caps, that is, 100% foreign investment is permitted under
the automatic route.
4.0 These guidelines will issue in modification of paragraph 2(e) of Press Note 4 of
2006 and will be effective from the date of issue of this Press Note. FDI policy announced
vide Annex to Press Note 7(2008) dated 16th June 2008 stands amplified to the above
extent.
GOPAL KRISHNA
Joint Secretary to the Government of India
D/o IPP F.No. 12/22/2007-FC
dated the 13th February 2009

3
