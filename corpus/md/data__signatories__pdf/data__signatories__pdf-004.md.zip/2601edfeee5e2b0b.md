---
doc_id: "2601edfeee5e2b0b"
source_url: "https://mnre.gov.in/static/uploads/2026/10/1c8b572d6def0d408f501e9dc6de006a.pdf"
ministry: "New and Renewable Energy (MNRE)"
title: "Revised Guidelines for Installation of prototype wind turbine models dated 25/06/2026"
date: "2026-06-25"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "1342f5807b5d0c3f"
---

<!-- page 1 -->

Government of India
Ministry of New and Renewable Energy
Atal Akshaya Urja Bhawan, Opposite CGO Complex,
Lodhi Road, New Delhi 110003
|
Dated: 25 June, 2026
Office Memorandum
Subject: Amendment to the "Revised Guidelines for installation of prototype
wind turbine models"- Reg.
The undersigned is directed to refer "Revised Guidelines for installation of
prototype wind turbine models” dated 12.06.2025 issued by this Ministry.
2: The para 5 of the said guidelines is amended as under;
Existing Clause Amended Clause
75 नि For each prototype wind turbine model, maximum 3
For each prototype m ind! Nos of wind turbines will be allowed for
turbine model, maximum 3 we issioning. Th
के ‘ न synchronization/commissioning. The scheduled
Nos of wind turbines will गा type wi .,
power generated from the prototype wind turbine
be allowed for
oe models may be purchased by DISCOMs/any other
synchronization / ri ri
commissionin entity at a mutually agreed tariff or tariff regulated
9 under CERC/concerned SERC regulation.
3. The para 8 of the said guidelines is amended as under;
Existing Clause Amended Clause
Serial production and
installation ofp rototy, pe Installation of prototype wind turbines will not be
wind turbines will not be कं $ ri a .
; - allowed until the wind turbine model is included in the
allowed until the wind ALMM (Wind) list
turbine model is included "
in RLMM.
4. The other paras/provisions of the said guidelines are unchanged.
5. This issues with approval of competent authority.
<a
Rishikesh Vaishnav
Scientist-C
Copy To: All Concerned
