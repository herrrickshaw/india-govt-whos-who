---
doc_id: "24bdc8dfe6fe7e33"
source_url: "https://powermin.gov.in/static/uploads/2026/05/d831f25e40d660d452713d52c4ad1dfb.pdf"
ministry: "Power"
title: "Appellate Tribunal for Electricity (Salaries, Allowances and other Conditions of Service of Chairperson and Members) Rules Amended in 2018"
date: "2018-05-24"
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e42910f8df437a2a"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la-

343]
No. 343]

ubZ fnYyh] c`gLifrokj] ebZ 24] 2018@T;s’ 3] 1940
NEW DELHI, THURSDAY, MAY 24, 2018/JYAISTHA 3, 1940
िवुत मं ालय

अिधसूचना
नई दली, तारीख: 24 मई, 2018

सा.का.
सा.का.िन.
िन. 485(
485(अ).—कीय सरकार, िवुत अिधिनयम, 2003 (2003 का 36) क धारा 176 क उप-धारा (2)
के ख%ड (ञ) (ारा )द* शि,य- का )योग करते 0ए, कीय िवुत िविनयामक आयोग (अ3य4 तथा सद6य- के वेतन, भ*े
तथा सेवा क अ8य शत9) िनयम, 2004 का और संशोधन करने के िलए िन=िलिखत िनयम बनाती है, अथाAत:्
1.

संि नाम और ारंभ - (1) इन िनयम- का संि4C नाम कीय िवुत िविनयामक आयोग (अ3य4 तथा सद6य- के
वेतन, भ*े तथा सेवा क अ8य शत9) संशोधन िनयम, 2018 है।

(2) ये राजपE म उनके )काशन क तारीख को )वृ* ह-गे।

2.

कीय िवुत िविनयामक आयोग (अ3य4 तथा सद6य- के वेतन, भ*े तथा सेवा क अ8य शत9) िनयम, 2004 (िजसम
इसके पHात् उ, िनयम कहा गया है) म िनयम 4 के 6थान पर, िन=िलिखत िनयम रखा जाएगा, अथाAत:्

"4. वेतन: (1) अ3य4 )ितमास चार लाख पचास हजार Iपये का वेतन )ाC करने का हकदार होगा और पूणA-कािलक

सद6य )ितमास चार लाख Iपये का वेतन )ाC करे गा, जो सरकारी आवास तथा 6टाफ कार क सुिवधा के िबना होगा:
परं तु जहाँ अ3य4 उNतम 8यायालय का 8यायाधीश या कसी उN 8यायालय का मुOय 8यायमूPत रहा है वहाँ वह,

यथाि6थित, उNतम 8यायालय के 8यायाधीश या उN 8यायालय के मुOय 8यायमूPत को यथा अनुQेय वेतन )ाC करने का
हकदार होगा।

2894 GI/2018

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) उप-िनयम (1) के अनुसार अ3य4 और पूणA-कािलक सद6य का वेतन समय-समय पर िव* मंEालय (Rय िवभाग)

(ारा जारी आदेश- के अनुसार पुनरीि4त कया जाएगा।"
3.

उ, िनयम- म िनयम 9 म, (क)

उप-िनयम (1) म शSद, अ4र, अंक तथा कोTक "80,000 I.(िनयत) के वेतनमान म वेतन" के 6थान पर शSद,

अ4र, अंक और कोTक "वेतन मैUVWस म वेतन का 6तर 17 (225000 I.)" रखे जाएंगे;
(ख)

उप-िनयम (2) के परं तक
ु
म शSद, अ4र, अंक तथा कोTक "80,000 I.(िनयत) के वेतनमान म वेतन" के 6थान
पर शSद, अ4र, अंक और कोTक "वेतन मैUVWस म वेतन का 6तर 17 (225000 I.)" रखे जाएंगे।

4.

उ, िनयम- के िनयम 10 म शSद, अ4र, अंक तथा कोTक "80,000 I.(िनयत) के वेतनमान म वेतन" के 6थान पर
शSद, अ4र, अंक और कोTक "वेतन मैUVWस म वेतन का 6तर 17 (225000 I.)" रखे जाएंगे।

5.

उ, िनयम- के िनयम 14 म शSद, अ4र, अंक तथा कोTक "80,000 I.(िनयत) के वेतनमान म वेतन" के 6थान पर
शSद, अ4र, अंक और कोTक "वेतन मैUVWस म वेतन का 6तर 17 (225000 I.)" रखे जाएंगे।

6.

उ, िनयम- के िनयम 15 म शSद, अ4र, अंक तथा कोTक "80,000 I.(िनयत) के वेतनमान म वेतन" के 6थान पर
शSद, अ4र, अंक और कोTक "वेतन मैUVWस म वेतन का 6तर 17 (225000 I.)" रखे जाएंगे।
[फा.सं.25/2/2018-आरए%डआर]

घनZयाम )साद, मुOय अिभयंता

ट पण:
पण: मूल िनयम अिधसूचना संOया सा.का.िन.177(अ) तारीख 08 माचA, 2004 (ारा भारत के राजपE, असाधारण म
)कािशत कए गए थे और भारत के राजपE, असाधारण तारीख 19 माचA, 2010 म अिधसूचना संOया
सा.का.िन.196(अ) तारीख 19 माचA, 2010 (ारा त\पHात् ]प से संशोिधत कए गए।

MINISTRY OF POWER
NOTIFICATION
New Delhi, the 24th May, 2018
G.S.R. 485(E).—In exercise of the powers conferred by clause (j) of sub-section (2) of section 176 of the
Electricity Act, 2003 (36 of 2003), the Central Government hereby makes the following rules further to amend the
Central Electricity Regulatory Commission (Salary, Allowances and other Conditions of Service of Chairperson and
Members) Rules, 2004, namely:1.

Short title and commencement. – (1) These rules may be called the Central Electricity Regulatory Commission
(Salary, Allowances and other Conditions of Service of Chairperson and Members) Amendment Rules, 2018.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

In the Central Electricity Regulatory Commission (Salary, Allowances and other Conditions of Service of
Chairperson and Members) Rules, 2004 (hereinafter referred to as the said rules), for rule 4, the following rule shall
be substituted, namely:“4. Pay . – (1) The Chairperson shall be entitled to receive a pay of four lakh fifty thousand rupees per mensem and
the whole-time Members shall receive a pay of four lakh rupees per mensem, without facility of Government
accommodation and staff car:

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(i)º

Hkkjr dk jkti=k % vlk/kj.k

3

Provided that where the Chairperson has been a Judge of the Supreme Court or Chief Justice of a High Court, he
shall be entitled to receive pay as admissible to a Judge of the Supreme Court or the Chief Justice of a High Court,
as the case may be.
(2) The pay of Chairperson and whole-time Members as per sub-rule (1) shall stand revised in accordance with the
orders issued by the Ministry of Finance (Department of Expenditure) from time to time.”;
3.

In rule 9 of the said rules, (a)

in sub-rule(1), for the words, letters, figures and brackets “pay in the pay scale of Rs.80,000 (fixed)”, the
words, figures, brackets and letters, “pay in level-17 in the pay matrix (Rs.225000)” shall be substituted;

(b)

in the proviso under sub-rule (2), for the words, letters, figures and brackets “pay in the pay scale of
Rs.80,000 (fixed)”, the words, figures, brackets and letters, “pay in level-17 in the pay matrix (Rs.225000)”
shall be substituted.

4.

In rule 10 of the said rules, for the words, letters, figures and brackets “pay in the pay scale of Rs.80,000 (fixed)”,
the words, figures, brackets and letters, “pay in level-17 in the pay matrix (Rs.225000)” shall be substituted.

5.

In rule 14 of the said rules, for the words, letters, figures and brackets “pay in the pay scale of Rs.80,000 (fixed)”,
the words, figures, brackets and letters, “pay in level-17 in the pay matrix (Rs.225000)” shall be substituted.

6.

In rule 15 of the said rules, for the words, letters, figures and brackets “pay in the pay scale of Rs.80,000 (fixed)”,
the words, figures, brackets and letters, “pay in level-17 in the pay matrix (Rs.225000)” shall be substituted.
[F. No. 25/2/2018-R&R]
GHANSHYAM PRASAD, Cheif Engineer

Note : The principal rules were published in the Gazette of India, Extraordinary vide notification number G.S.R. 177(E)
dated the 8th March, 2004 and subsequently amended vide notification number G.S.R. 196(E), dated the 19th
March, 2010 in the Gazette of India Extraordinary dated the 19th March, 2010.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed
by ALOK KUMAR
Date: 2018.05.28
14:56:19 +05'30'

ALOK
KUMAR
