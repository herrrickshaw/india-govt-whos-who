---
doc_id: "28c2be8cda1dcc20"
source_url: "https://mohua.gov.in/static/uploads/2025/11/15ed970ff691e3b962f8cdf20eb799b2.pdf"
ministry: "Housing and Urban Affairs (MoHUA)"
title: "Release of 30,37,800001- as 1 installment of Central Assistance to the StateGovernment of Punjab for 85 BLC (New) projects approved in 47 4hCSMCmeeting held on 25092019 under Pradhan Mantri Awas Yojana (Urban)[PMAY (U)] Mission for the financial year"
date: "2021-02-13"
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "612e045166e1101e"
---

<!-- page 1 -->

https://pfms.nic.in/SanctionlTemplateAdvice.aspx?AdviceNum=qQ...

PAO(Secttj/ HUA/Admin/Advice/ 2020-21/fe 3'l,
GOVERNMENT OF INDIA
PAO(Sectt.), Ministry of Housing and Urban Affairs
507-C Wing, Nirman Bhawan, New Delhi
Telephone No: 23062664 Fax No: 23062664
To,
The General Manager,
Reserve Bank of India,
Central Accounts Section,
Additional Office Building,
East High Court Road,
NAGPUR 440 001

[No:
Code
1707
lAdvice No: 5 40
,Advice Date: 1 15/02/2021

-

Sir,
Please debit our account with Rs.30,37,80,000/- (Thirty Crore Thirty Seven Lakh Eighty
Thousand Only.) by contra credit to the following accounts of the Governments with the amounts
mentioned against each:

Month and Year of Accounts: February,2021
Sl.No. Name of State
the State Code
1

PUNJAB

113

Scheme Code

1989-STATE AND UT
GRANTS UNDER PMAY
(URBAN)

The Amount to be Settled: February,2021
Amount Sanction No. and Date

30,37,80,000 N-11011/86/2019-HFA-I-UD
(FTS 9074817) dated
13/02/2021

GRAND TOTAL: 30,37,80,000

Signature of the authorized official

1,09
(Pawan Kumar Bhatnagar)
Sr. Accounts Officer
1. 0,10 the Accountant General (A&E), Punjab, Sector-17, Chandigarh-160017
3Ah. Jagdish Prasad, US (HFA-I) M/o Housing and Urban Affairs, New Delhi-110011

f()

,

/N~ ~'o
ut

t

Pawan Kumar hatnagar
Sr. Accounts Officer
,

/415> yr4
VA

of 1

15-Feb-21 5:13 PM

<!-- page 2 -->

<!-- page 3 -->

N-I 101 118612019-HFM-UD (FTS: 9074817)
Government of India
Ministry of Housing and Urban Affairs
HFA Mission Directorate
(HFA4 Division)
Nrman Bhawan, New Delhi.
Dated: 13 February, 2021
To
Pay and Accounts Officer (Sectt),
Ministry of Housing and Urban Affairs,
Nimian Bhawan New Delhi -11
Sub Release of 30,37,800001- as 1 installment of Central Assistance to the State
Government of Punjab for 85 BLC (New) projects approved in 47 4h CSMC
meeting held on 25092019 under Pradhan Mantri Awas Yojana (Urban)
[PMAY (U)] Mission for the financial year 2020-21
Sir,
I am directed to convey the Sanction of the President of India to release of
30,37,80,000/- (Rupees Thirty Crore Thirty Seven lakh and Eighty Thousand only)

to the State Government of Punjab as 1st installment of Central Assistance for 85 BLC
(New) projects approved in 47th CSMC meeting held on 2509 2019 held under Pradhan
Mantri Awas Yojana (PMAY)- Housing for All (Urban) Mission (for Scheduled Castes
Component) under Allocation for the FY 2020-2 1 Details of the projects areas under

# Project-wise details are annexed.
2 Based on decision of CSMC meeting under Pradhan Mantri Awas Yojana (PMAY) Housing for All (HFA) (Urban) Mission and on the recommendations made by MOHUA,
the amount of centralgrant is being released subject to following conditions alongwith
observations of CSMC
L Necessary sanctions/ approvals/ compliances required under the statutory or
other regulatory regime as applicable would be obtained by the authonty(ies)
concerned with the project(s)
ii. The State Government and implementing agency shall put in place a monitoring
system to ensure that the project(s) achieve scheduled milestone and envisaged
outcomes including implementation of reforms and other conditionalities required
under the scheme
Contd. 21-

<!-- page 4 -->

iii- Utilize the grant in accordance with the approved guidelines for the
implementation of the Scheme of Pradhan MantTI Awas Yojana (PMAY) -Housing
for All (I-WA) (Urban) Mission.
W. Furnish the Utilization certificates of the Grant released in the prescribed format as
per GFR— 2017 as provided in the scheme guidelinesv.

The funds may be utilized for the purpose and within selected categorised
beneficiary for Which these are given. Otherwise these will have to be refunded
along with interest as per provisions for GFR-2017.

A.

The State must ensure geo4agging of photographs to monitor progress of the
house constniction before release of each instalment to beneficiaries.

vi The agencies responsible for implementation of PMAY(U) should get themselves
registered on PFMS portal
V141.

The State Government should validate the demand assessment data and remove

the ineligible beneficiaries in order to make the housing requirement realistic
State to ensure that adequate infrastructure is ensured including individual water,
sanitation and electric connection
x. State Government to ensure that there is no duplication I change in the identified
beneficiaries

ix

A..

xii

Transfer of funds to different entities may be made through PFMS, as applicable
and where there is an element of cash transfers to individual beneficiaries, the
same may be made through PFMS/D8T mode, as applicable
State Government should ensure that there is no violation of Model Code of
Conduct while releasing funds to Implementing Agencies/ULBslBenefictanes

3
Payment may kindly be made to the State Government immediately The funds
may thereafter be released to the implementing agencies without any delay failing which
the amounts would be recovered from the State Government with interest for the period
of default
4
Additional allocation through 2nd supplementary Demand for Grants 2020-21 for
PMAY-U is yet to be received Therefore, in pursuance to the DEA OM No 714112019-BA
(P11) dated 0601 2021 conveying authorization for incurring excess expenditure of Rs
6000.00 crore over and above BE allocation for PMAY(U) by invoking Appendix —10 under
Rule 61 and 69 of GFR 2017 the expenditure involved will be debited from head
3601.06.502-01.02,35 (Scheduled Caste Components) under. demand No 57 of Ministry
of Housing and Urban Affairs for the year 2020-21 and will be transferred to the following
head of account on regularization after receiving the Od SDG 2020-21
Major Head
Sub-Major Head
Minor Head
Sub Head
Detailed Head
Object Head

3601
06
789
17
01
17.01.35

Grants-in-aid to State Governments
Centrafly Sponsored Schemes
Scheduled Castes Component
Urban Housing Other Grants
Pradhan Mantn Awas Yojana (Urban)
Grants for Creation of Capital Assets
-

<!-- page 5 -->

<!-- page 6 -->

Do

,..

?

,

'

-

>

?

IM

,-

q

to
"

--

:c

•

?:

~

3
9v

:

--

3

=7

=-3

-

:--

-::

;z

'-.

r

:

---

.-.

t

.

'

;

_•c--i

z

t.

•

-

=S=.

F'ig

c-

-

0
n

Ax

o

c;Z

o

o

ø
-

;

;

;

;;

;:;

-

f•4

;

to
4,

.

o

'

p-j

1

r

-Q

•

0

0

At

•

-

_J

_

0%

T-'

i-"

0

0

10.

8
c

§

r

0
D

8
0

;

C

?

o

-'

V

z
.

(b
im

I-

to

D

0

.

c

t,,

_'

X

0.

,

C
Pd

.-.
&J

I-

4,

5

-.
t.3

0.

-

0
mc1

R;

co

--

fo

z
!

to

40

th

uj

CL

go

2.i'
w.z

a

w-,,O

1
'C

i_J

•

,

.

'

5_
*4

.

;-,

-

g

.-o
xc

•'

.'

SI
vr

CL

'

im
-

?

!!

I

441

I

<!-- page 7 -->

<!-- page 8 -->

_3

J

NJ

Nj

r

t._

N

z

CD

r

t4

r

r

=

r

r

r

=
F3

r

rl

n'

-

-

-,

•-C?

;-* --

-

--.-r-

--.--

-

-

l=
z

:Ef

W

1(!fI

An

T_

,_
oZ
w

li

._#
i- 0

Ef!

j:i

0

0

•..

q

oZ
.. 0

ID

u
0

At

o

,J

o to

o

..-

0

,

to

,.

to

o

b

-

40

,_&

t;.

0

-

;9j:

10

•.J

0

-c

-

::-:

:low

..

t.

rw

]

!z(iI

0

I,

c

-

--

•0
0
g
0

t

L?'

U
..-

.-

n

4.,

-

o
c

0

o
0

0

0

n
0

,
C

0

0

0

0

0

o

4=

-4

0

b

c
C

o
0
8
0

a

a

0
8
0

Pi
cc

4.,.

f-j

Ln

.

t

o

j

o

_

NJ

8

46
.

,J,

-

*_*

4_

p4

.,._

J

0•

•.

t4

4•_

...-4

•

...

-.

0

•t

o

.

0

.

4Q
g

.

.

.

4—

-

4

4-.

. o

8

VIA

.-

c

______

§.

to
fQ

<!-- page 9 -->

—

e

to

03

'.J

CD

to

,

-.

,

•;

-

£.

;

-

.
i

;

-'

3

.

C

or

—

CL

CL

so

-

,'>r'

-—

:

r'

Gi*
- ."'

cs

i
t

pr

g2:

H; :!

I!!!tt jj:j !JiL :E:9 1I'! E1t IJIt
P.

0r

E.—

:

;2

:fl

:U

itP

Im

ma -'

zo

1-4
4Z

.

D

tw

10
to

tj
un
40

u

NJ

d

4z

a

l
it

W,

.4

:-

..

1,?

14

.4

(

•.

,,J

U,

0

U'

un

co

,JI

LA

t,'

IQ

o

w

C,

km
II

-.

I-.

00

0

,.
.4

C,

C,

.

C,

D

1'

L

co

L,j

to

o

C,

Is'

tp

C,

0

C

::;

.

,.

0

C,

•

.3

,

D

f

•0

• I%

.1

I

I

,

•D

Jt

'1

•

__

<!-- page 10 -->

..

.

,-'

;

U-

-

-

.

,-

,

-

.

r

r-

r•

r
,

,p

Ir

p-

ir

ML

£

3

IV

---

.- -- >f

'

r_*

--

*x?

b Z

lax

do

,J

- 0

- a
.0

,_

..

c

c

C

C

C

,

-

,.

;

o
*b

c

-

a

O

.-

*_

,

o

Ij

p

•-

.j

,_J

C

- a

,-

%

+_

_J
-

.
,_j

a

,

-.

*_

Q

4- o

%

.

C)

C

o
0

J

C
0
C
0

4J

u

CL

:j

,,

,_,
-

VD 10

!:i

;

-:

C

c

IL
—

.

6j

t

:•

D

in

it
Li

I

10 *

2*_

;!

CL

40

2z*t b

..

*

:;:

0
C
Cl
0

t'J

0
C

0
0
0
0

C

Ut

s.
.

C

Co

0
0
C

0
0
OF
0

,-

tn

•..
I..'

C
-J
f.

0
0
0
0

0
0
0
C

C

-:

1J
it

0
0
0
0

C
'-3
',

,

0
0
0
0

0
0
0
0

0
0
0
0

41b

I-.

t7

J
0

I.-

p.)

L

•

....

'

Im

00

C
b

ci

0
•

§

0
b
8

.-.
.
C

C

•

0
b

D

0

P
0

P

?

9

g

§

§
'-.

4.1

0

b

9

C
§

1.2

C'

0'

0'

o

0'

<!-- page 11 -->

Li'

M

.D

-

Q

;

VD
w-

0

a

—

J

im

-

4A

r

4.R

cl

OD

o

C

-

Im

zu
IN

fu

uu
to

—E

el

a;rl

2'
w_

UT

uu
;

;:g 42

•-__

_z_

I

tJ

0
•,J

cJ

t-

0

c7

a

.- C

w

p.J

8

i-.'

L,

9
co

U,

8

o

l,

w

ck

00

D

m

c,
-. C

c

o t

o&

o

O C

i- C
* t

C

D

P.-'

fJ

_

..

t_

a

8

8

§

§

w

irc

+C tD

D

:1

Nj

pi

rj

tn .

,_•

a'

v'

Ui

A

yj

ico

UI

tJ
0

I-•
I

00

::::

00

I-.

w
0

w

00

a

00

4n.

NJ
'f

I-

UI

•

o

'00

C

S

p

o

0

0

8

p
8

:

C.

-

p

O

,.

(.

8

c
I-.

_

o
- .-

t;

gx

LIT

An

to_

-€
,

o

;—!

r

n

--

o.f:

H1 UU

7 BF

:L

3

•

0

0

9

0

8

8

9

0
0

<!-- page 12 -->

a

a'

m

C'

I

fn

1p

_•

T I,

)

:

i
-

,

AE

pr

ZT

-

-

,

-

vr3

z x 3.

nw

z-

..i t1i 4(

gt

-.

;

t 4L

-

.

.-

••_i
76

-W

c—

'-

70

_

'1111

-

ol

-

...--

:::---

E-

-

-

Tj

D

D

- 0
W W

-- I.-

;:

0
LD

4-

- 0

.-

- in

(L

_.

a

.j

%:

IC

LO

C D
,.J

t-.

.J

C

OC

;D

:k•

C
C

C
LIM

140

.0

C

O

AV

'

,.

fW

U,
UI

D

C

C

C
C
C
C

3

;

D

.-

C
C
C

C
C
C)

C
0
C
C
C

u

U

C
C
C
C

C

:

A

I-.
'j

-

C

fQ

p,

C
C
0
C

C
C
C
C

C
C
C
C

'

Ui

Tj

•.,J
C

C
C
C
C

C
C
C
C

pJ

-

C

C
C
C
C

'

tJ

p
'

uJ

NJ

C

C
C

C
•:

C

C

0

C'
(

C

0
C

C
C

C

C

C

g
C

C

C

C
9

.
C

o

C

C

C

C

C

C

C

C

C

C

C
C
g
C

C

C
C

CD

t
,

C

,

C

C

C

Q

C

C

-

<!-- page 13 -->

c

c.

00
tj

cm

to

E

rl

C

,

-4

-

' I'

r

!
.

.

AA

;1:

1-7

si
-

..

.,.

CA

cr

:

:

,

lw

=

!'.

o *

!

h

=

!
,

z-;--

!h

z;

!_

o

f_,

..

D

W LD

fl

LN

;

•,J
b

:;

CL

_u

_J

,

,.J

.D D
t..

tJ

fkj

•?

IQ

wl

,.J

fl

c
,to W

cC

c
D

,
_!

*J
i

c,

02

-

',

im

z

th

-

o
.-'

00

M

t."

4M
§

§

§

tA

§

z2I
§

8

. w
2 'A

w
a

-.

j

t.

rJ

CD

,
_J

411

b

C'

-

w

'!

O

LA

a'

,______ - - LJ

to

m

C4

lks

as

.-.

•_3

a

LO

<!-- page 14 -->
