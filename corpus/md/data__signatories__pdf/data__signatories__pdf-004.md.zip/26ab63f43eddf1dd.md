---
doc_id: "26ab63f43eddf1dd"
source_url: "https://dof.gov.in/static/uploads/2025/09/2e79ca8e62bb05fc461333eff53f1056.pdf"
ministry: "Department of Fisheries (DoF)"
title: "Celebration of international Yoga Day Department of Fisheries Ministry of Fisheries, Animal Husbandry and Dairying 09th May , 2022"
date: "2022-05-09"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "baff4e301ae5dc6a"
---

<!-- page 1 -->

Celebration of international Yoga Day
Department of Fisheries
Ministry of Fisheries, Animal Husbandry and Dairying
09"" May , 2022
Department of Fisheries , Government of India is going to Organize
International Yoga Day this year on 09.05.2022(Monday) as per
following schedule.
The Program at Porbandar, Varanasi , Chennai are being graced by
Hon’ble Ministers of the Ministry of Fisheries, Animal Husbandry and Dairying.
Places | __ Date & Timing |
Porbandar , Chennai , Kochi , New Delhi, | 09"" May , 2022
| Hyderabad , Bengaluru, Vizag etc. | 6.30 AM to 7.30 AM in the |
Morning
निया 09"" May , 2022 |
4 PM to 7:30 PM in the
_ Evening |
FR \s 5 \2022
le
DY. ae Jeet.
Dvoecdc
