---
doc_id: "24c44fde0ae8bfe0"
source_url: "https://www.legalaffairs.gov.in/static/uploads/2026/10/415f84414eb614205629a71e334a5d3e.pdf"
ministry: "Department of Legal Affairs (DoLA)"
title: "Order dated 08.10.2026: Acceptance of resignation of Dr. Nitesh Mozika , DSGI, High Court of Meghalaya at Shilong w.e.f. 06.10.2026"
date: "2026-10-09"
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "2ca96e85e16c828e"
---

<!-- page 1 -->

J-11014/5/2023-JUDICIAL 1/27690/2026
No. J-11014/5/2023-Judicial/ E. 98588
Government of India
Ministry of Law and Justice
Department of Legal Affairs
(Judicial Section)
24108, Kartavya Bhawan-2, New Delhi,
Dated the 8"" Oct., 2026
ORDER
The President is pleased to accept the resignation of Dr. Nitesh Mozika, Deputy Solicitor
General of India for High Court of Meghalaya at Shilong, on account of being appointed as Additional
Solicitor General for India before the High Court of Meghalaya at Shilong, with effect from 06.10.2026.
2. Consequently, the name of Dr. Nitesh Mozika, Senior Advocate figuring at serial number ‘5’ in
the Order No. J-11014/5/2020-Judicial dated 08.09.2020 read with No. J-11014/5/2023-Judicial dated
30.08.2023 and No. J-11014/5/2023-Judicial/E.98588 dated 03.09.2026, stands deleted.
3. Hindi version of this order will follow. Digitally signed by
Manindra Choudhary
Date: 08-10-2026
19:46:06
(Manindra Choudhary)
Assistant Legal Adviser
Copy (through email) to:
1. PS to Hon'ble MoS (IC) L&J.
2. PSO to LS/All AS and JS in the main Secretariat of Department of Legal Affairs.
3. The Registrar, High Court of Meghalaya.
4. The ASGI, High Court of Meghalaya.
5. Cash (LA) Section for discontinuing payment of retainership fee to aforesaid ex-Dy. SGI, w.e.f.
06.07.2026.
6. The Pay & Accounts Office, Department of Legal Affairs, New Delhi.
7. LIMBS section of this Department.
8. To be uploaded on website of this Department i.e. www.legalaffairs.gov.in under tab
‘Judicial Section’ in the link “Orders related to empanelment of Advocates for Union of India”.
9. Hindi Section, Department of Legal Affairs, for translation of this order.
10. Office/spare copies. Digitally signed by
Ramesh Kairamkonda
Date: 09-10-2026
09:55:35
(Ramesh Kairamkonda)
Section Officer (Judicial)
Tel. 011-24016111
Email: judicial-dla@nic.in
