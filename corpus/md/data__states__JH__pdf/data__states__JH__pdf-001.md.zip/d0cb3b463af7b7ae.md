---
doc_id: "d0cb3b463af7b7ae"
source_url: "https://jserc.org/pdf/tender_2024f.pdf"
ministry: "Jharkhand State Electricity Regulatory Commission, Jharkhand"
title: "4th Extension on submission of bid for Consultancy job"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2d2cbe7d15f91738"
---

<!-- page 1 -->

Jharkhand State Electricity Regulatory Commission
1st Floor, Jharkhand State Housing Board (Old Head Quarter), Harmu Housing
Colony, Ranchi-834002
Website : www.jserc.org

email : info@jserc.org

ADDENDUM
Reference is invited on the notice inviting bid for consultancy job in regulatory
matters from capable and experienced consultants in the field. The last date for submission
of bid was 31st October 2024. Due to unavoidable circumstances the last date for
submission of bid, opening of technical bids as well as for business presentation has been
extended as under :Last date of submission of bids -

05th December 2024 at 04.00 P.M

Opening of technical bids

-

05th December 2024 at 04.30 P.M

Business Presentation

-

06th December 2024 at 04.00 P.M

Sd/( Rajendra Prasad Nayak )
Secretary
