---
doc_id: "ec7c69fd8f79fcf6"
source_url: "http://www.sajha.in/wp-content/uploads/2024/03/Corrigendum-for-Website-Tender_Final.pdf"
ministry: "Sports Authority of Jharkhand, Jharkhand"
title: "Click here to View/Download"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f26a6a0e5d4eb5ae"
---

<!-- page 1 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

Govt. of Jharkhand
Sports Authority of Jharkhand
(Department of Tourism, Art-Culture, Sports & Youth Affairs)
Gate No. - 28, Birsa Munda Football Stadium, Morhabadi, Ranchi
Email: sajha9@gmail.com
Clarifications and Updates:

Tender ID - SAJHA/60 - Development of Integrated Website and Mobile Application for
Sports Authority of Jharkhand (SAJHA)
Following the queries raised by bidders during the pre-bid meeting convened on March 18, 2024,
at 4:00 PM and queries received via email, the Request for Proposal (RFP) has undergone the
following modifications and updates.
S. No
1

2

RFP CLAUSE

UPDATED CLAUSE/ CLARIFICATION

1. Time Schedule of Tender
5. Bid Due Date – 28.03.2024,
11:00 AM.
2. Terms & Conditions
c) Bid Submission

1. Time Schedule of Tender
5. Bid Due Date – 24.04.2024,
04:00 PM.

All bids must be accompanied by
a non-refundable Bid fee/Tender
Cost INR Rs. 25,000/- (Rupees
Twenty-Five Thousand Only) in
form of Bank Draft and Earnest
Money Deposit (EMD) of INR
5,00,000 /- (Rupees Five Lakhs
Only) in the form of Demand Draft
valid for period of 3 months.

2. c) Bid Submission:
All bids must be accompanied by a nonrefundable Bid fee/Tender Cost INR Rs.
25,000/- (Rupees Twenty-Five Thousand
Only) in form of Bank Draft/ Bank
Guarantee and Earnest Money Deposit
(EMD) of INR 5,00,000 /- (Rupees Five
Lakhs Only) in the form of Demand Draft
valid for period of 3 months.
Additionally, MSME Registered in
Jharkhand will be exempted from Bid
Fees/ Tender Cost of Rs. 25,000/-.

D(b): Place of development and
Operations

D(b) A dedicated room for operations will
be provided by SAJHA. Cost associated
with other resources to be borne by the
bidder.

4. Instructions to Bidders:
Earnest Money Deposit (EMD)

3

a) The bidder is required to
submit Earnest money (EMD) of
Rs. - 5,00,000/-. (Rupees Five
Lakh Only) The EMD should be in
the form of Demand Draft in
favour of Sports Authority of
Jharkhand, Payable at Ranchi.

The exemption for MSMEs registered
outside of Jharkhand will be granted in
accordance with the Jharkhand
Procurement Policy.

Page 1 of 12

<!-- page 2 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

b) The MSME'S will be exempted
from submission of the EMD's as
per the Jharkhand Procurement
policy. The MSME's must have to
submit Certificate of Registrations
as a MSME’s
c) The Tender Found without
EMD as above shall be
summarily rejected.

4

5. Eligibility Criteria for Bidders:
B. MSMEs shall be given
relaxation on EMD & Security
Deposits provided the MSMEs
must have Software Development
as their NIC Code on or before
the date of Publishing of this
tender.

5

5. Eligibility Criteria for Bidders:
C. Experience criteria – Bidder
should have order worth more
than 1 crore in field of IT /
Software based product for
central Govt / State PSU/
Software based product for
Sports Data Management in last
two financial years.

6

5. Eligibility Criteria for Bidders:
G. Turnover – Last three
financial average Turnover should
be more than 1.5 cr.

7

6. Scope of Work
The Server must be hosted on
Dedicated Cloud Based Server.

5. Eligibility Criteria for Bidders:
MSMEs shall be given relaxation
on EMD & Security Deposits
provided the bidder has a valid
MSME Certificate. The bidders
must have Software Development
as their NIC Code (i.e., NIC 2 –
digit code must be 62) on or
before the date of publishing the
tender.
5. Eligibility Criteria for Bidders:
C. Experience criteria –
Bidder should have order worth
more than 1 crore in field of IT/
Software based product for
Central Government/ State
Government/ PSU/ Software
based product in the last two
financial years.
5. Eligibility Criteria for Bidders:
G. Turnover – Last Three
Financial Average Turnover
should be more than 1.5 crores.
6. Scope of Work
The Server must be hosted on Dedicated
Cloud Based Server. (The hosting
charges will be borne by the Bidder)
Additionally, the quoted price (for 1st
year) should consider approximately
3000 athletes.
With following server configuration:
1. Number of concurrent users
handling 1,000 users.
2. Scalability weekly backup
support.

8

6.Scope of Work

Refer Annexure – ‘A’ for detailed scope of
work.

Page 2 of 12

<!-- page 3 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

9

9. Technical Bid Evaluation
Criteria

Refer Annexure – ‘B’ for updated
Technical Bid Evaluation Criteria.

10

11. General Terms &
Conditions:
Payment Milestone

Refer Annexure ‘C’ for updated/ modified
payment milestones.

8.Proposal Evaluation

8.Proposal Evaluation

11

B. Financial Evaluation:
The Commercial Bids will be opened,
in the presence of Bidder’s or their
representatives who wish to attend
the Commercial Bid opening on date
and time to be communicated to all
the technically qualified Bidders.
Financial evaluation will be based on
the Least Quote (L1) basis.

B. Financial Evaluation:
The Financial Bids of only the
Technically Qualified Bidders shall be
opened in the presence of the
Bidder’s representatives who wish to
attend. For financial evaluation, the
service fee inclusive of GST shall be
considered for the entire lifecycle of
the project (03 Years).

Page 3 of 12

<!-- page 4 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

ANNEXURE – ‘A’
6. SCOPE OF WORK
B. Scope of Service
In order to provide an integrated and centralized Digital Solution to the Sports ecosystem of
Jharkhand, Sports Authority of Jharkhand has decided to develop the Sports Portal for One Stop
Solutions that includes but is not limited to the following:
1.

Centralised Sports Repositories for all Stakeholders like Athletes, Coach, Technical
Officials, Sport Federation, Academies and Venue Owners of the State that will serve as
the base for digital presence for further activities like real time attendance, sports
participation, awards, Training, Venue Booking etc.

(A centralised Sports Person Registration system is a comprehensive database and
management platform designed to consolidate and organise information about individuals
involved in sports activities. This system serves as a centralised repository for storing,
managing, and updating records related to sports persons)
2.

Athlete Management System
a.
b.
c.
d.

3.

Athlete Registration: Allows athletes to register their profiles with relevant
information such as personal details, sports history, achievements, and medical
records.
Profile Management: Athletes can manage their profiles, update information, and
add new achievements or records.
Performance Tracking: Enables tracking of athletes' performance metrics,
including competition results, training data, and fitness assessments.
Training Programs: Provides access to training programs tailored to individual
athletes' needs and goals, with the ability to track progress and performance.

Verification and Nomination Management System
a.

Verification Process: Enables verification of athletes, coaches, technical officials,
and other stakeholders by validating their credentials, certifications, and eligibility
criteria.
b.
Document Upload: Allows users to upload relevant documents, such as
identification proof, certifications, and medical records, for verification purposes.
c.
Verification Status Tracking: Provides users with real-time updates on the status
of their verification process, including any pending actions or requirements.
d.
Nomination Management: Allows authorized users (e.g., coaches, team
managers) to nominate verified athletes or officials for participation in training
programs, competitions, or other sports events.
e.
Notification System: Sends notifications to users regarding the status of their
verification and nomination requests, as well as any updates or changes to the
process.
4. Communication Management System
a. Announcements and Alerts: Enables administrators to send announcements, alerts,
and notifications to all or specific groups of stakeholders.
b. Event Calendar: Includes an event calendar displaying upcoming events, training
sessions, competitions, and other relevant activities.

Page 4 of 12

<!-- page 5 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

5.

Academy Management System
a. Academy Registration: Allows sports academies to register their profiles with
relevant information such as location, facilities, coaching staff, and programs offered.
b. Profile Management: Enables academies to manage their profiles, update
information, and add new programs or facilities.
c. Participant Registration: Allows athletes to register for training programs, camps,
and other activities offered by the academy.
d. Attendance Tracking: Tracks attendance of participants in training programs and
other activities, providing insights into participation and engagement.

6.

Training Programs Management System
a. Program Creation: Allows administrators to create training programs, including
specifying program objectives, duration, schedule, and location.
b. Participant Registration: Enables athletes to register for training programs, providing
necessary information such as age, skill level, and medical history.
c. Coach Assignment: Assigns coaches to training programs based on their expertise
and availability.
d. Session Scheduling: Creates schedules for training sessions, including dates, times,
and locations.
e. Attendance Tracking: Tracks attendance of athletes in training sessions, providing
insights into participation and engagement.

7.

Venue, and Infrastructure Management
a. Venue Registration: Allows venue owners to register their venues with relevant
information such as location, facilities, capacity, and availability.
b. Facility Management: Manages venue facilities, including sports fields, courts,
tracks, gyms, swimming pools, and equipment.
c. Booking System: Enables users to book venues for sports events, training programs,
and other activities, including checking availability and making reservations.
d. Availability Calendar: Displays the availability of venues, allowing users to plan and
schedule activities accordingly.

8.

Booking Management System
a. Venue Selection: Allows users to browse available venues, view details such as
location, facilities, and capacity, and select the desired venue for booking.
b. Date and Time Selection: Enables users to select the date and time for their booking,
checking the availability of the venue for the chosen slot.
c. Payment Processing: Integrates with payment gateways to facilitate online payment
for bookings, including handling of fees, deposits, and refunds.
d. Booking Calendar: Provides a calendar view of bookings, showing booked and
available slots for each venue.
e. Notification System: Sends notifications to users regarding the status of their
booking requests, including confirmation, rejection, or modification.

9.

Attendance tracking at sports events or training sessions
a. Participant Check-in: Allows participants to check-in to sports events or training
sessions using a mobile app or web interface.
Page 5 of 12

<!-- page 6 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

b. Real-time Tracking: Tracks attendance in real-time, providing immediate feedback on
participant presence.
c. Barcode/QR Code Scanning: Uses barcode or QR code scanning for quick and easy
check-in of participants.
d. Manual Check-in: Allows organizers to manually check-in participants if barcode or
QR code scanning is not available.
e. Attendance Reports: Generates attendance reports for events or sessions, showing
the number of participants present and absent.
f. Automated Notifications: Sends automated notifications to participants reminding
them to check-in or informing them of their attendance status.
g. Integration with Registration System: Integrates with the registration system to
ensure that only registered participants are allowed to check-in.
h. Privacy and Security: Ensures that participant attendance data is secure and
complies with data protection regulations.
i. Access Control: Provides access control features to restrict entry to events or
sessions based on attendance status.
10. Accreditation Management System
a. Accreditation Application: Allows stakeholders to apply for accreditation by
submitting relevant information and documents.
b. Verification Process: Verifies the authenticity of accreditation applications, including
validating credentials and checking eligibility criteria.
c. Accreditation Categories: Supports different accreditation categories based on the
role and level of involvement of stakeholders, such as athletes, coaches, officials, and
media.
d. Digital Accreditation Card Generation: Generates digital accreditation cards for
accredited stakeholders, containing relevant information and access permissions.
e. Access Control: Controls access to sports events and facilities based on
accreditation status, ensuring only accredited stakeholders are allowed entry.
f. Accreditation Status Tracking: Enables stakeholders to track the status of their
accreditation application and receive updates on approval or rejection.
g. Accreditation Renewal: Allows stakeholders to renew their accreditation for
subsequent events or seasons.
h. Accreditation Revocation: Enables organizers to revoke accreditation for
stakeholders who violate rules or regulations.
i. Accreditation Database: Maintains a central database of accredited stakeholders,
including their profiles and accreditation history.
11. Tournament Management System (TMS)
a. Tournament Creation: Allows organizers to create tournaments, specifying details
such as name, dates, venue, format, and rules.
b. Participant Registration/Entry: Enables teams or individuals to register/Entry for
tournaments, providing necessary information and documents.
c. Bracket Generation: Generates tournament brackets or schedules based on the
number of participants and tournament format.
d. Match Scheduling: Creates schedules for matches, including dates, times, and
venues, ensuring no scheduling conflicts.
e. Results Recording: Allows officials/Event Managers to record match results,
including scores, winners, and any violations or incidents.

Page 6 of 12

<!-- page 7 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

12. Digital Certificate issuance system for achievements, Training Programs, and
participation
a. Certificate Template Creation: Allows administrators to create custom certificate
templates, including designs, fields, and logos.
b. Certificate Issuance: Enables administrators to issue certificates to stakeholders,
selecting the appropriate template and entering relevant information.
c. Certificate Management: Manages issued certificates, including tracking issuance
dates, expiration dates, and reissuance if necessary.
d. Notification System: Sends notifications to stakeholders when certificates are issued
or available for download.
e. Customization Options: Allows customization of certificates based on the type of
achievement or participation, including adding personalized messages or logos.
f. Integration with Athlete Management System: Integrates with the athlete
management system to automatically issue certificates for achievements recorded in
the system.
13. Simple Chatbot (English & Hindi)
a. Information Retrieval: Provides users with information about achievements, training
programs, and participation in sports events based on their queries.
b. Notification Alerts: Sends notifications to users about upcoming events,
achievements, or changes in their participation status.
c. FAQ Support: Answers frequently asked questions about achievements, training
programs, and participation.
d. Feedback Collection: Collects feedback from users about their experience with
training programs or events.
14. Grievance and Complaint Redressal System
a. Grievance Submission: Allows stakeholders to submit grievances or complaints
through the system, providing details such as nature of grievance, date, and parties
involved.
b. Grievance Tracking: Enables stakeholders to track the status of their grievances,
including updates and resolutions.
15. Sports Specific Assessment guidelines for Coaches and Trainers
(Standard Khelo India Guidelines and any other guidelines that may be issued/developed
in due course of time)
a. Allow users to create accounts or log in via email, social media, or guest mode.
b. Provide a personalized dashboard displaying recommended tutorials, recent activities,
and progress.
c. Curate a comprehensive library of sports tutorials categorized by sport, skill level, and
topic.
d. Offer engaging tutorials comprising videos, step-by-step guides, animations, and
interactive quizzes.
16. Grants, Schemes, and Scholarship Management System
a. Grant and Scholarship Listings: Provides a comprehensive list of available grants,
schemes, and scholarships for users to explore.
Page 7 of 12

<!-- page 8 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

b. Application Submission: Allows users to submit applications for grants, schemes,
and scholarships directly through the app.
c. Application Tracking: Enables users to track the status of their applications, receiving
updates on the progress and outcome.
d. Notification System: Sends notifications to users about new grants, schemes, and
scholarships, as well as updates on their applications.
e. Document Submission: Allows users to submit required documents for their
applications, such as proof of eligibility or academic records.
f. Review and Approval Process: Facilitates the review and approval process for
applications, ensuring timely processing and transparency.
17. Assessment and Evaluation System
a. Assessment creation tools for designing and conducting assessments.
b. Data collection tools for collecting performance data from assessments.
c. Reporting and analytics tools for generating reports and insights from assessment
data.
d. Feedback mechanisms for providing feedback to athletes and coaches based on
assessment results.
e. Integration with the portal's dashboard for real-time monitoring of assessment
activities.
18. Providing Sports Specific and Subject Matter Experts related to IT Integration of Multiple
Modules
19. Interface for dedicated Dashboard for all Stakeholders
C.

TECHNICAL FEATURES OF THE SPORTS PORTAL
1.
Should be bilingual (Hindi & English)
2.
Role-based Access Control System Implementation
3.
Online Chat Window functionality (Hindi & English)
4.
Panel for SMS & Email alert
5.
Panel to send Push Notification
6.
Social Media Integration (Prominent Social Media Platforms like Facebook, X,
Instagram)
7.
Integration of Feedback & Suggestions module
8.
Various Analytics & Statistics as required from time to time
9.
Pages should be attractive, rich with information & relevant infographics
10.
Pages should be User friendly and responsive

Page 8 of 12

<!-- page 9 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

ANNEXURE – ‘B’
TECHNICAL BID EVALUATION CRITERIA
Sr.
No
A

1

2

3

Particulars

Documentary Evidence

Technical Bid Evaluation
Relevant Experience:
Bidder must have executed Website and
Application projects as per subject matter
of Sports technology (should involve
registration of athletes, Accreditation, and
communication system through app,
recording of records and results) or govt
project with Portals, application on IOS
and android in the last three Years.
Marking Scheme:(Projects value size)
More than 4 projects - 10 marks
More than 3 projects - 5marks
More than 1 project - 3 marks
Quality Certification
a)
CMMI Level 3 or above– (03 Marks)
b)
ISO 27001 – (01Marks)
c)
ISO 9001 certifications – (01
Marks)
Go Live on NIC or SDC Server
(Experience in Deployment/ Installation of
Web Portal/App on NIC or SDC for any
State Govt./ Central Govt/Govt.
Undertaking (funded by govt.) through
bidders' own development Account.)

Maximum
Marks
70

a. Letter of
Award/Agreement/Completion
Certificate
b. The details should be
certified by the Statutory
Auditor of the Company or
Company Secretary

10

Proof of Empanelment Letter
& Certifications

5

Deployment/Installation
Certificate issued from Govt.
Agency/Department & Record
of Deployment from SDC.
Proof of deployment of
Server, SSL Certificate

10

Page 9 of 12

<!-- page 10 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

Working Experience:
The agency must have at least five years
of experience in Software, Website, and
Mobile App development, operations, and
maintenance with dedicated expertise in
the sports technology area(s) where the
end user is Government/ or a govt. funded
agency.

4

5

Marking Scheme:
- Any single project more than 3 Crores:
20 Marks
- Any single project more than 2 Crores:
8 Marks
- Any single project more than 1 Crore: 5
Marks
A maximum of 02 projects can be
submitted.
OR
Any E- Governance project where the end
user is Government/ PSU
Where the project order value is more
than Rupees 50 Lakh in a similar industry
and must have undertaken an assignment
in Central/State Government, PSU10 Marks

To deliver quality projects it is essential to
follow quality norms to be among the core
team of the organization, any team
member who has been in the system for
more than 3 years should hold PMP or
Prince 2 practitioner certificate

a. Copy of Work Order and
Completion Certificates/
Phase Completion Certificate
from the client, OR
b. Copy of Work Order and
Self Certificate of Completion
certified by the Statutory
Auditor or the Company
Secretary, OR
c. Copy of client certificate as
documentary proof for the
stated criteria and project
status.

20

Copy of Certificate from
recognized Institute.

5

Page 10 of 12

<!-- page 11 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

Manpower Experience
Marking Scheme:
a) Chief Technology Officer
15 Years Work Experience –05 Marks,
10 years Work Experience -03 Marks
05 years Work Experience- 02 Marks
6

b) Project Head
15 Years Work Experience – 10 Marks
10 years Work Experience - 05 Marks
05 years Work Experience- 03 Marks
c) Sports Automation and Digitization
(Subject Matter Experts)
15 Years Work Experience – 05 Marks
10 years of Work Experience -03 Marks
05 years of Work Experience- 02 Marks

CVs of respective team
members.
CVs of Key people to be
deployed highlighting only the
relevant experience to be
presented during the
presentation

20

Remarks-The capacity in
which each head worked
(designation) in the relevant
events is to be mentioned
specifically.

Presentation Score
Technical Presentation -Concept and Design Presentation (PPT’s)
B

Approach & Methodology but not limited to the following:
1. Understanding of the work for SAJHA website and Mobile App
development - 5marks
2. Demo for similar nature of work in past - 5 marks
3. Innovative ideas and suggestions - 10 marks
4. Detailed Project Plan and Road Map - 10 marks

30

Page 11 of 12

<!-- page 12 -->

SAJHA/60 - Development of Integrated Website and Mobile Application for Sports Authority of Jharkhand

ANNEXURE – ‘C’
PAYMENT MILESTONES
Sl.
No

Milestone

1

Preparation and finalization of FRS

2

Submission of Wireframes/UI/UX of Website and
Application

3

Activation of Registration Module of all Categories
with Verification and Nomination System

4

5

6

7

8

Completion of following Deliverables (Web
Portal):
1) Communication Management System
2) Simple Chatbot System
3) Accreditation Management System
4) Digital Certificate Issuance System
5) Grievance and Complaint Redressal System
FAT and Go Live of following Modules:
1) Sports Games Management System for use of
state games
2) Attendance tracking at sports events or training
sessions
FAT and Go Live of following Modules:
1) Academy Management System &Training
Programs Management System
2) Booking Management System
3) Venue, and Infrastructure Management
4) Grants, Schemes, and Scholarship
Management System
FAT and Go Live of following Modules:
1) Sports Specific Assessment guidelines for
Coaches and Trainers
2) Athlete Management System
3) Assessment and Evaluation System
Code Handover and Knowledge Transfer

% of
Payment

Additional
Requirement

20 %

Documentary Proof

10 %

Documentary Proof

10 %

Documentary Proof

20%

Documentary Proof

20%
(5% will be
released
on
Documentary Proof
completion
of each
task)

15%

Documentary Proof

5%

Documentary Proof

Note:
The remaining terms, conditions, and clauses of the Request for Proposal (RFP) shall continue
to apply without modification.
Sd/Deputy Director
Sports Authority of Jharkhand

Page 12 of 12
