---
doc_id: "5b1fc42bfe75c0fa"
source_url: "https://jrhms.jharkhand.gov.in/uploads/tenders/e521b799-505a-4a6d-8440-b3c81c35f916.pdf"
ministry: "Jharkhand Rural Health Mission Society"
title: "NHM/Nam/03/2026 — Selection of Patient Provider Support Agency for TB related Services under NTEP for 17 Districts  (Expired)"
date: ""
pages: 64
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eb5da9cc3bcd24b9"
---

<!-- page 1 -->

Request for Proposal (RFP)
for
Selection of Patient Provider Support Agency (PPSA) for Providing
Tuberculosis Related Services under NTEP for [17 Districts] of
[Jharkhand].

Tender Ref No: NHM/NAM/03/2026

<!-- page 2 -->

Table of Contents
ABBREVIATIONS ................................................................................................................................... .- 4 DISCLAIMER ........................................................................................................................................- 5 Section I – Request for Proposals for Selection of Patient Provider Support Agency (PPSA) .........- 7 Section II – Instructions to Proposers..............................................................................................- 10 A. GENERAL INFORMATION .............................................................................................................- 10 1.

Introduction ............................................................................................................................. - 10 -

2.

Code of Integrity ...................................................................................................................... - 10 -

3.

Conflict of Interest ................................................................................................................... - 11 -

4.

Eligible Proposers..................................................................................................................... - 12 -

5.

Number of Proposals: .............................................................................................................. - 12 -

6.

Right to reject any or all Proposals: ......................................................................................... - 12 -

7.

Acknowledgement by Proposer,.............................................................................................. - 13 -

8.

Selection of Agency.................................................................................................................. - 13 -

B. RFP DOCUMENT ...........................................................................................................................- 14 9.

Content of RFP Document ....................................................................................................... - 14 -

10.

Clarifications of RFP Document ........................................................................................... - 14 -

11.

Pre-Bid Meeting ................................................................................................................... - 14 -

12.

Amendments to RFP Document .......................................................................................... - 15 -

C. PREPARATION OF PROPOSALS ....................................................................................................- 16 13.

Preparation of Proposals ..................................................................................................... - 16 -

14.

Documents establishing the compliance of Services........................................................... - 17 -

15.

Period of validity of Proposals ............................................................................................. - 17 -

16.

Earnest Money Deposit (EMD) ............................................................................................ - 17 -

17.

Documentation .................................................................................................................... - 18 -

D. SUBMISSION AND OPENING OF PROPOSALS .............................................................................- 20 18.

Submission of Proposals ...................................................................................................... - 20 -

19.

Deadline for Submission of Proposals ................................................................................. - 20 -

20.

Late Proposals...................................................................................................................... - 20 -

21.

Opening of Proposals........................................................................................................... - 20 -

E. EVALUATION OF PROPOSALS.......................................................................................................- 21 22.

Basic Principles..................................................................................................................... - 21 -

23.

Preliminary Scrutiny and Determination of Substantial Responsiveness of Proposals....... - 21 -

24.

Clarification of Proposals ..................................................................................................... - 22 -

25.

Fraud and Corrupt Practices ................................................................................................ - 22 -

26.

Fulfilment of the Qualification Criteria ................................................................................ - 23 -

27.

QualificationCriteria............................................................................................................. - 23 -

28.

Technical Evaluation ............................................................................................................ - 25 -

<!-- page 3 -->

29.

Final Selection......................................................................................................................... . - 26 -

30.

Procurement Entity’s Right to Accept Any Proposal, and to Reject Any or All Proposals ... - 28 -

F. AWARD OF CONTRACT.................................................................................................................- 29 31.

Award Criteria ...................................................................................................................... - 29 -

32.

Notification of Award........................................................................................................... - 29 -

33.

Performance Security .......................................................................................................... - 29 -

34.

Signing of Contract............................................................................................................... - 29 -

35.

Exclusion of Proposal/ Disqualification................................................................................ - 29 -

Section III – Scope of Services..........................................................................................................- 31 Section IV – TERMS AND CONDITIONS ............................................................................................- 38 1.

Use of contract documents and information .......................................................................... - 38 -

2.

Intellectual Property Rights ..................................................................................................... - 38 -

3.

Insurance ................................................................................................................................. - 38 -

4.

Duration of hiring of services of PPSA ..................................................................................... - 38 -

5.

Payments ................................................................................................................................. - 38 -

6.

Performance Review, Incentives & Penalty provisions. .......................................................... - 39 -

7.

Signing of the contract............................................................................................................. - 40 -

8.

Start of the services ................................................................................................................. - 40 -

9.

Sub-Contracts........................................................................................................................... - 40 -

10.

Modification to Contract ..................................................................................................... - 40 -

11.

IncomeTax Deduction at Source .......................................................................................... - 40 -

12.

Force Majeure...................................................................................................................... - 40 -

13.

Termination of Contract ...................................................................................................... - 41 -

14.

Notices ................................................................................................................................. - 42 -

15.

Resolution of disputes ......................................................................................................... - 42 -

Section IV – Proposal Forms ............................................................................................................- 43 1.

Letter of Technical Proposal .................................................................................................... - 43 -

2.

Proposer Information Form ..................................................................................................... - 45 -

3.

Letter of Financial Proposal ..................................................................................................... - 47 -

4.

Form of Price Schedule ............................................................................................................ - 48 -

Annexure 1: Proposal Covering Letter............................................................................................. - 49 Annexure 2: Authorization Letter for Signing of Proposal............................................................... - 51 Annexure 3: Particulars Of The Proposer’s
Organisation…………………………………………………………………………….- 53 Annexure 4:- 54 - Declaration by Proposer ..................................................................................... - 54 Annexure 5:- 55 Annexure 6:- 56 - Unconditional Undertaking................................................................................. - 56 Annexure 7: Statement of experience in implemetationon of health/social sector programs ...... - 57 -

<!-- page 4 -->

Annexure 8: Statement of experience in working in TB
programs .............................................................. …- 57 Annexure 9 Proforma For Bank Guarantee For Performance
Security…………………………………………………..- 59 -61
Annexure 10: Guidance documents on performance linked payment plan
………………………………………- 61 -62

DISCLAIMER
ACF

Active Case Finding

AERB

Atomic Energy Regulatory Board

AY

Assessment Year

FY

Financial Year

CB-NAAT

Cartridge Based Nucleic Acid Amplification Test

C&DST

Culture and Drug Susceptibility Test

DBT

Direct Benefit Transfer

DHS

District Health Society

DOTS

Directly Observed Treatment Short course

DR-TB

Drug Resistant – Tuberculosis

DTC

District Tuberculosis Centre

EMD

Earnest Money Deposit

EPF

Employee Provident Fund

ESI

Employee State Insurance

FDC

Fixed Dose Combinations

F-ICTC

Facility Integrated Counselling and Testing Centers

LLP

Limited Liability Partnership

GST

Goods and Services Tax

HIV

Human Immunodeficiency Viruses

ITR

Income Tax Returns

ITP

Instructions to Proposers

TBI

TB Infection

LoI

Letter of Intent

MDR – TB

Multi - Drug Resistant Tuberculosis

MoA

Memorandum of Association

MSME

Micro, Small & Medium Enterprises

NACO

National Aids Control Organization

NHM

National Health Mission

NIC

National Informatics Centre

NPY

Nikshay Poshan Yojana

NTEP

National Tuberculosis Elimination Program

PPIA

Private - Provider Interface Agency

PPM

Public Private Mix

PPMC

Public Private Mix Coordinators

PPSA

Patient Provider Support Agency (PPSA)

<!-- page 5 -->

PS

Performance Security

QCBS

Quality and Cost Based Selection

NTEP

National Tuberculosis Elimination Programme

RFP

Request for Proposal

RR

Rifampicin Resistant

SOP

Standard Operating Procedures

STCI

Standards of TB Care in India

STO

State Tuberculosis Officer

TB

Tuberculosis

UIDAI

Unique Identification Authority of India

WHO

World Health Organization

<!-- page 6 -->

1. This Request for Proposal (RFP) document is neither an agreement nor an offer by the National Health
Mission, (hereinafter referred to as “NHM JH NTEP”) to the prospective Proposers or any other person.
The purpose of this RFP is to provide information to the interested parties that may be useful to them in
the formulation of their Proposal pursuant to this RFP. The term “Agency” denotes any proposer, who
is empaneled for PPSA in the concerned State.

2. Procurement Entity does not make any representation or warranty as to the accuracy, reliability or
completeness of the information in this RFP document and it is not possible for procurement entity to
consider particular needs of each party who reads or uses this document. RFP includes statements
which reflect various assumptions and assessments arrived at by procurement entity in relation to the
statement of work. Such assumptions, assessments and statements do not purport to contain all the
information that each Proposer may require. Each prospective Proposer should conduct its own
assessment and analysis and check the accuracy, reliability and completeness of the information
provided in this RFP document and obtain independent advice from appropriate sources.

3. Procurement Entity will not have any liability to any prospective Proposer/ Firm/ or any other person
under any laws (including without limitation the law of contract and tort), the principles of equity,
restitution or unjust enrichment or otherwise for any loss, expense or damage which may arise from or
be incurred or suffered in connection with anything contained in this RFP document, any matter
deemed to form part of this RFP document, the award of the Assignment, the information and any other
information supplied by or on behalf of procurement entity or their employees, any agency or otherwise
arising in any way from the selection process for the assignment. Procurement entity will also not be
liable in any manner whether resulting from negligence or otherwise however caused arising from
reliance of any Proposer upon any statements contained in this RFP.

4. Procurement Entity will not be responsible for any delay in receiving the Proposals. The issue of this RFP
does not imply that procurement entity is bound to select a Proposer or to appoint the selected
Proposer, as the case may be, for the services and procurement entity reserves the right to
accept/reject any or all of Proposals submitted in response to RFP document at any stage without
assigning any reasons whatsoever. Procurement Entity also reserves the right to withhold or withdraw
the process at any stage with intimation to all who submitted RFP Proposal.

5. The information given is not exhaustive on account of statutory requirements and should not be
regarded as a complete or authoritative statement of law. Procurement entity accepts no responsibility
for the accuracy or otherwise for any interpretation or opinion on the law expressed herein.

6. Procurement Entity reserves the right to change/ modify/ amend any or all provisions of this RFP
document. Such revisions to the RFP / amended RFP will be made available on the e-procurement
portal - jharkhandtenders.gov.in

<!-- page 7 -->

Section I – Request for Proposals for Selection of Patient Provider Support
Agency (PPSA)
RFP Ref. No.NHM/NAM/03/2026

Dated: 18.09.2026

A. The Procurement Entity intends to select agency (ies) via e-tendering for working as a Patient Provider
Support Agency (PPSA) for providing Tuberculosis (TB) related services under National Tuberculosis
Elimination Program (NTEP) in 17 districts in the state of Jharkhand. with the aim of increasing
notification of TB patients who seek care in private sector, and ensuring successful treatment out
comes. The PPSA shall work as an interface agency between the State Health Society, NTEP, NHM, and
private health sector, and shall be providing patient centric services at all levels. The PPSA as a package
shall cover entire spectrum of services including provider management, diagnostic linkages, drug
linkages, HIV testing, DST linkages, facilitating notification, provider incentives and patient support
services.
B.

This RFP is being issued for 2 Clusters (17 district) of Jharkhand State. Details of districts / clusters are
provided below

Table-1- Annual TB Patient Estimate.

Table-1- Annual NTEP Patient Estimate

District
Giridih
Bokaro
Ramgarh
Hazaribag
Kodarma
Chatra
Latehar
Plamu
Garhwa

Cluster

Cluster 2

Total
Ranchi
Lohardaga
Gumla
Khunti
Saraikela
East Singhbhum
West Singhbhum
Simdega

Cluster 3

Total
C.

No. of TB Patients
1180
1690
385
654
435
179
60
1100
567
6250
4800
125
190
70
700
2100
150
70
8250

The RFP Document may be freely downloaded by interested eligible Proposers from the e-procurement
portal - jharkhandtenders.gov.in

D. The Proposer/agency can propose for either one or more clusters / districts. However, in case the
Proposer applies for two or more cluster / districts, then it shall be required to submit applicable
Earnest Money Deposit (EMD) and Performance Security (PS) for respective cluster / districts separately.
The payment of EMD is not applicable to the entities falling under Micro, Small & Medium Enterprises
(MSME) having valid Udyog Aadhar Memorandum (UAM) registration certificate and UAM number for
Jharkhand state. All the Proposers who are eligible to avail the exemptions for EMD, must

<!-- page 8 -->

E.

F.

upload/provide the Udyog Aadhar Memorandum (UAM) registration certificate and UAM number for
Jharkhand state.
The Proposers, who have downloaded the RFP Documents, shall be solely responsible for checking
above gem portals for any addendum/amendment issued, subsequent to publication of this RFP and
take the same into consideration while preparing and submitting their Proposals.
The official representatives from the Agency are invited to attend the pre-bid meeting at the address
mentioned in the Table below. Please note that non-attendance at the pre-bid meeting will not be the
cause of disqualification of the Proposers.

G. Proposals must be submitted online on the e-procurement portal - jharkhandtenders.gov.in on or before
the last date of submission as mentioned in NIT by adhering to the Proposal submission process
specified in Section D. Submission and Opening of Proposals at the e-procurement portal
jharkhandtenders.gov.in
H. The technical proposal will be opened on ……………….. In the presence of the Proposers’ designated
representatives who choose to attend. Please note that non-attendance at the pre-proposal meeting will
not be the cause of disqualification of the proposers.
I.

At any time prior to the deadline for submission of Proposal, Procurement Entity may, for any reason
deemed fit by it, modify the RFP document by issuing suitable amendment(s) to it. Such amendment will
be notified on the e-procurement jharkhandtenders.gov.in only. Any agency who has downloaded the
RFP should check for amendments, if any, issued on the gem portal and Procurement Entity will not
issue a separate communication to them. Procurement Entity shall not be responsible in any manner, if
the prospective Proposers miss any notifications placed on the given gem portal.

J.

Procurement Entity will not accept any Proposal which will be received after the stipulated date and
time.

K.

Schedule of Events:

Sr
Particular
No
1
Tender No:
2
3
4
5
6

7
8
9
10

Name of Work
Date of Publication of RFP
Document
Last Date of receiving written
queries
Pre-bid Meeting Date/Time
/Venue
Last Date / Time for receipt of
Proposals (Technical and Financial
Proposals)
Date / time for opening of
Technical Proposal
Date/time for opening of Financial
Proposal
Earnest Money Deposit (EMD)
Amount (INR)
Contact Person

Details
NHM/NAM/03/2026
Selection of “Patient Provider Support Agency” for TB Care in Private
Sector in the State of Jharkhand 17 districts
19.09.2026
Queries should be submitted through e-mail by …………..
25.09.2026 at 03:00 PM
09.10.2026 up to 05:00 PM

13.10.2026 at 3:00PM
To be notified
INR 200000/- through Online Payment Gateway

9110943588

Note –
a)
b)

Interested Proposers may obtain further information about this Request for Proposal (RFP) from the
office of NHM JH, NAMKUM,RANCHI
Schedule May Change in case if any day is declared a Holiday.

<!-- page 9 -->

L.

The Bid shall be accompanied by Earnest Money Deposit (EMD)/Bid Security INR 2,00,000/- (Rs Two
Lakh only) online, via Integrated Payment gateway available over e-procurement portal, refundable no
later than 225 (two hundred and twenty-five) days from the Bid Due Date, except in the case of the
Selected Bidder whose Bid Security shall be retained till it has provided a Performance Security under
the Agreement. The Bidders shall provide Bid Security through The Bid shall be summarily rejected if it
is not accompanied by the Bid Security.
Payment of RFP EMD is not applicable to the entities falling under Micro, Small & Medium Enterprises
(MSME) having valid Udyog Aadhar Memorandum (UAM) registration certificate and UAM number for
Jharkhand state. Proposers, who are eligible to avail the exemptions, must upload Udyog Aadhar
Memorandum (UAM) registration certificate and UAM number for Jharkhand state along with their
Proposal.

M. Other than above-cited entities, no Proposer is exempted from submitting the EMD. Proposals without
EMD shall be summarily rejected.
N. The technical and financial Proposals must be submitted / uploaded through e-procurement portal jharkhandtenders.gov.in before the date and time specified in the RFP. The Procurement Entity doesn't
take any responsibility for the delay / non-submission of Proposal / Non-Reconciliation of online
Payment caused due to non-availability of internet connection, network traffic / holidays or any other
reason.
O. The Proposal documents shall be submitted in the mode as mentioned below:
(1) Earnest Money Deposit
(EMD)

Online
Note: All Interested bidders shall submit the EMD/Bid Security of
Amount Rs. 2,00,000 per cluster in through Online Payment Gateway
…………………

(2) Technical Proposal(s)

Online

(3) Financial Proposal(s)

Online

A. All Interested bidders shall submit the EMD/Bid Security of Amount Rs. 2,00,000 per cluster in through
Online Payment Gateway.
B.

Procurement Entity reserves the right to accept or reject any or all Proposals or change the terms and
conditions of RFP or cancel the RFP without assigning any reasons at any stage and time.

C.

No contractual obligation whatsoever shall arise from the RFP document/process unless and until a
formal contract is signed and executed between Procurement Entity and the Agency.

D. Procurement Entity disclaims any factual or other errors in the RFP document (the onus is purely on
each Proposers to verify such information) and the information provided therein are intended only to
help the Proposers to prepare a Proposal in accordance with the terms and conditions as set out in this
RFP document/process
E.

For further enquiry and information, please contact on the following numbers during office hours (10:30
AM to 05:00 PM) on all working daysConsultant Procurement Cell:-9110943588

F.

All further notifications/corrigendum/addendum, if any, shall be posted on e-procurement portal jharkhandtenders.gov.in and shall be binding on all the Proposers.

<!-- page 10 -->

Section II –Instructions to Proposers
A. GENERAL INFORMATION
1. Introduction
1.1.

In connection with the Request for Proposal (RFP) for Selection of Patient Provider Support Agency
(PPSA), the Procurement Entity will select an Agency in accordance with the method of selection
specified in the RFP. The selection of Agency shall be on the basis of an evaluation by Procurement
Entity through the selection process specified in this RFP (the “Selection Process”). Proposers shall be
deemed to have understood and agreed that no explanation or justification for any aspect of the
Selection Process will be given and that Procurement Entity’s decisions are final without any right of
appeal whatsoever.

1.2.

The Proposers are invited to submit Technical and Financial Proposals (collectively called as “the
Proposal”), as specified in the Schedule of RFP, for the services required for the assignment. The
Proposal will form the basis for grant of award of work order to the selected Agency. The Agency shall
carry out the assignment in accordance with the Scope of Work (the “SoW”) in Section IV.

1.3.

This Section provides the relevant information as well as instructions to assist prospective Proposer in
preparation and submission of Proposals. It also includes the mode and procedure to be adopted by
the Procurement Entity for receipt, opening, scrutiny and evaluation of Proposals and subsequent
placement of award of contract.

1.4.

The Proposer shall bear all costs and expenditure incurred and/or to be incurred by it in connection
with its Proposal including preparation, submission and subsequently processing the same. The
Procurement Entity shall, in no case be responsible or liable for any such cost, expenditure etc.
regardless of the conduct or outcome of the bidding process.

1.5.

The Procurement Entity is not bound to accept any Proposal and reserves the right to annul the
selection process at any time prior to execution of the Contract, without thereby incurring any liability
to the Proposers.

1.6.

Proposal submitted by the Proposer and all subsequent correspondences and documents relating to
the Proposal exchanged between the Proposer and the Procurement Entity, shall be written in English
language. All correspondence and other documents pertaining to the contract which are exchanged by
the parties shall be written in the same language.

1.7.

Dispute Resolution: If any dispute or difference of any kind whatsoever arises between the parties in
connection with or arising out of or relating to or under this RFP, the parties shall promptly and in
good faith negotiate with a view to its amicable resolution and settlement. In the event no amicable
resolution or settlement is reached within a period of thirty (30) days from the date on which the
above-mentioned dispute or difference arose, such dispute or difference shall be finally settled by
competent authority, whose decision shall be final.

1.8.

Registration of Proposer: To participate in the e-tendering process, the Proposer is required to get
itself registered with State Government Centralized e-procurement portal - jharkhandtenders.gov.in
The Proposer is required to visit gem portal.

1.9.

Digital Signature certificate (DSC): Each Proposer is required to obtain a Class-III Digital Signature
Certificate (DSC).

2. Code of Integrity
2.1. The Procurement Entity and all officers or employees of the Procurement Entity, whether involved in
the procurement process or otherwise, and Proposers and their representatives or Consultants or
Service Providers participating in a procurement process or other persons involved, directly or indirectly
in any way in a procurement process shall maintain an unimpeachable standard of integrity.

<!-- page 11 -->

2.2. The Procurement Entity prescribes to uphold the code of integrity, which prohibits officers or
employees of Procuring Entity and Proposers, the following:
(i)

any offer, solicitation or acceptance of any bribe, reward or gift or any material benefit,
either directly or indirectly, in exchange for an unfair advantage in the procurement process
or to otherwise influence the procurement process;
(ii) any omission, including a misrepresentation that misleads or attempts to mislead so as to
obtain a financial or other benefit or avoid an obligation;
(iii) any collusion, Proposal rigging or anti-competitive behaviour to impair the transparency,
fairness and progress of the procurement process;
(iv) improper use of information shared between the Procurement Entity and the Proposers
with an intent to gain unfair advantage in the procurement process or for personal gain;
(v) any financial or business transactions between the Proposer and any officer or employee of
the Procurement Entity, who are directly or indirectly related to RFP or execution process of
contract;
(vi) any coercion including impairing or harming or threatening to do the same, directly or
indirectly, to any party or to its property to influence the procurement process;
(vii) any obstruction of any investigation or audit of a procurement process;
(viii) making false declaration or providing false information for participation in  procurement process or to secure a contract;
 disclosure of Conflict of Interest;
 disclosure by the Proposer of any previous transgressions with any entity in India or any
other country during the last three years or of any debarment by any other Procurement
Entity.
2.3. In case of any breach of the Code of Integrity by a Proposer or a prospective Proposer, as the case may
be, the Procurement Entity after giving a reasonable opportunity of being heard, may take appropriate
measures including –
(i) exclusion of the Proposer from the procurement process;
(ii) calling off of pre-contract negotiations;
(iii) forfeiture or encashment Earnest Money Deposit;
(iv) recovery of payments made by the Procurement Entity along with interest thereon at bank
rate;
(v) cancellation of the relevant contract and recovery of compensation for loss incurred to the
Procurement Entity;
(vi) debarment of the Proposer from participation in any future procurements of any Procuring
Entity for a period not exceeding three years.

3. Conflict of Interest
3.1. Conflict of Interest for a Procurement Entity or its personnel and Proposers is considered to be a
situation in which a party has interests that could improperly influence the performance of its duties or
responsibilities, contractual obligations, or compliance with applicable laws and regulations
3.2. The situations in which a Procuring Entity or its personnel may be considered to be in Conflict of Interest
include, but are not limited to the following a)

Conflict of Interest occurs when the private interests of a Procurement Entity or its
personnel, such as personal, non-official, extra- professional or other relationships or
personal financial assets, interfere or appear to interfere with the proper performance of
its professional functions or obligations as a procurement official;

b)

within the procurement environment, a conflict of interest may arise in connection with
such private interests as personal investments and assets, political or other social activities
and affiliations while in the service of the Procurement Entity, employment after
retirement from service or of relatives or the receipt of a gift that may place the
Procurement Entity or its personnel in a position of obligation;

c)

Conflict of Interest also includes the use of assets of the Procurement Entity including
human, financial and material assets, or the use of the office of the Procurement Entity or
knowledge gained from official functions for private gain or to prejudice the position of
someone the Procurement Entity or its personnel does not favour;

<!-- page 12 -->

d)

Conflict of Interest may also arise in situations where the Procurement Entity or any of its
personnel is seen to benefit directly or indirectly or allow a third party, including family,
friends or someone they favour, to benefit directly or indirectly from the decision or action
of the Procurement Entity.

3.3. The situations in which Proposers participating in a procurement process or their representatives may
be considered to be in Conflict of Interest include, but are not limited to the following –
a)

If they or their personnel or representatives have any relationship or financial or business
transactions or interests with any official of the Procurement Entity that are directly or
indirectly involved in or related to the procurement process or execution of contract;

b)

If they receive or have received any direct or indirect subsidy from any other Proposer;

c)

If they have the same legal representative for purposes of the Proposal;

d)

If they have a relationship with each other, directly or through common third parties that
puts them in a position to have access to information about or influence on the Proposal of
another;

e)

If they participate in more than one Proposal in the same bidding process;

f)

If they have controlling partners in common;

g)

If a Proposer or any of its affiliates participated as a consultant in the preparation of the
design or technical specifications of the subject matter of procurement of the bidding
process or were involved in such preparation in any way;

3.4. In the ‘Letter of Technical Proposal’ to be submitted by the Proposer, as per format given in Section IV Proposal Forms, all Proposers shall provide a signed statement that the Proposer is neither associated
nor has been associated directly or indirectly with the consultant or any other entity that has prepared
the design, specifications and other documents for the subject matter of procurement.
3.5. In case of a holding company having more than one independent unit or more than one unit having
common business ownership or management, only one unit shall be allowed to submit Proposal or
quote to prevent any Conflict of Interest. Similar restrictions shall apply to closely related sister or
subsidiary companies. Such Proposers must proactively declare such sister or subsidiary company or
common business or management units in similar lines of business.

4. Eligible Proposers
4.1. Proposer should be any legal or other entity including without limitation a company registered in India
under the Indian Companies Laws or incorporated outside India under relevant laws of incorporation
under country of its origin, or a society registered under Societies Registration Act, 1860 or any other
Indian law for registration of societies, a registered trust under Indian Trusts Act, 1882 or any other
Indian law for registration of public trust or a sole proprietorship or partnership registered under the
relevant laws of incorporation;
4.2. The Proposer can’t be an individual or group of individuals.
4.3. In the ‘Letter of Technical Proposal’ to be submitted by the Proposer, as per format given in Section IV Proposal Forms, Proposers shall provide a signed statement that the Proposer fulfils the eligibility
requirements given in the RFP document.

5. Number of Proposals:
5.1. Proposer shall submit more than one Proposal per cluster/district (mentioned in section I). A Proposer
bidding shall not be entitled to submit another Proposal either individually or as a member of any
proposer.

6. Right to reject any or all Proposals:
6.1. Notwithstanding anything contained in this RFP, the Procurement Entity reserves the right to accept or
reject any Proposal and to annul the selection process and reject all Proposals, at any time without any
liability or any obligation for such acceptance, rejection or annulment, and without assigning any
reasons thereof.

<!-- page 13 -->

6.2. Without prejudice to the generality of above, the Procurement Entity reserves the right to reject any
Proposal if:
• At any time, a material misrepresentation is made or discovered, or
• The Proposer does not provide, within the time specified by the Procurement Entity, the
supplemental information sought by the Procurement Entity for evaluation of the Proposal.
6.3. Such misrepresentation/ improper response by the Proposer may lead to the disqualification of the
Proposer. If such disqualification/ rejection occurs after the Proposals have been opened and the
highest-ranking Proposer gets disqualified/ rejected, then the Procurement Entity reserves the right to
consider the next best Proposer or take any other measure as may be deemed fit in the sole discretion
of the Procurement Entity, including annulment of the Selection Process.

7. Acknowledgement by Proposer,
7.1. It shall be deemed that by submitting the Proposal, the Proposer has:
• made a complete and careful examination of the RFP;
• received all relevant information requested from the Procurement Entity;
• accepted the risk of inadequacy, error or mistake in the information provided in the RFP or furnished
by or on behalf of the Procurement Entity;
• satisfied itself about all matters, things and information, including matters herein above, necessary
and required for submitting an informed Proposal and performance of all its obligations there under;
• acknowledged that it does not have a Conflict of Interest; and
• agreed to be bound by the undertaking provided by it under and in terms hereof.
7.2. The Procurement Entity and/ or its advisors/ officials shall not be liable for any omission, mistake or
error on the part of the Proposer in respect of any of the above or on account of any matter or thing
arising out of or concerning or relating to RFP or the selection process, including any error or mistake
therein or in any information or data given by the Procurement Entity and/ or its officials.

8. Selection of Agency
8.1. Procurement Entity shall be adopting the QCBS (Quality and Cost Based Selection) methodology for
selection of agency for each division, where in 60% weight age shall be given to technical evaluation
score based on the technical Proposals and 40% weight age shall be given to the financial evaluation
score based on the financial Proposal.
8.2. The contract agreement in each cluster/ district shall be signed at State Level between the
Proposer[whose combined score i.e. technical and financial evaluation) is the highest in the concerned
cluster(s)/district (s)] and Procurement Entity, subject to all conditions laid down in the RFP document.
8.3. As part of the evaluation, a Proposer must fulfil the Minimum Qualification Criteria. In case a Proposer
does not fulfil the Minimum Qualification Criteria, the Proposal of such a Proposer will not be evaluated
further.

<!-- page 14 -->

B. RFP DOCUMENT
9. Content of RFP Document
9.1.

The RFP Document include the following Sections:





Section I
Section II
Section III
Section IV

Notice Inviting Proposals
Instructions to Proposers
Scope of Work
Proposal Forms

9.2.

Unless downloaded directly from the Procurement Entity’s e-procurement portal jharkhandtenders.gov.in ,Procurement Entity shall not be responsible for the correctness of the RFP
document, responses to requests for clarification, the minutes of the Pre-bid meeting, if any, or
amendment(s) to the RFP Document in accordance with ITP Para 9.

9.3.

Proposers are expected to examine all instructions, forms, terms, and specifications in the RFP
documents and to furnish with its proposal all information or documentation as is required by the RFP
documents.

10. Clarifications of RFP Document
10.1. A prospective Proposer requiring any clarification regarding terms &conditions, technical specifications
etc. given in the RFP documents may submit written request for clarifications on email prochealth@jharkhandmail.gov.in .
10.2. All the Proposers will be notified of response to clarifications only through e-procurement portal jharkhandtenders.gov.in Any Proposer who has downloaded the RFP document should watch for
clarifications, if any, issued on the above-mentioned portal. Procurement Entity will not issue separate
communication to them.
10.3. The Procurement Entity shall not be responsible in any manner if a prospective Proposer fails to notice
any notifications placed on the e-procurement portal - jharkhandtenders.gov.in

11. Pre-Bid Meeting
11.1. In order to provide response to any doubt regarding terms and conditions, scope of work and any other
matter given in the RFP document, a pre-bid meeting has been scheduled to be held in the office of
Procurement Entity as per details given hereunder:
Date & Time:
Venue:
Contact Details:

11.2. During the pre-bid meeting, the clarification sought by representative of prospective Proposers shall be
responded appropriately. However, they shall clarify and will be asked to submit their written request as
specified in terms of Clause 10. The Procurement Entity shall upload written response on the email
proc-health@jharkhandmail.gov.in to such requests for clarifications, without identifying its source. In
case required, amendments, in terms of Clause12, above shall be issued, which shall be binding on all
prospective Proposers.

<!-- page 15 -->

12. Amendments to RFP Document
12.1. At any time prior to the deadline for submission of proposals, the Procurement Entity may, for any
reason deemed fit by it, modify the RFP by issuing suitable amendment(s) to it.
12.2. To afford the Proposers a reasonable time for taking the amendments into account, or for any other
reason, the Procurement Entity may at its discretion extend the proposal submission date.
12.3. Such an amendment will be notified on e-procurement portal - jharkhandtenders.gov.in and the same
shall be binding to all prospective Proposers.
12.4. Any Proposer who has downloaded the RFP document should watch for amendment, if any, issued on
the above e-procurement portal - jharkhandtenders.gov.in and the Procurement Entity will not issue
separate communication to them. The Procurement Entity shall not be responsible in any manner if
prospective Proposers miss any notifications placed on mentioned e-procurement portal jharkhandtenders.gov.in

<!-- page 16 -->

C.PREPARATIONOF PROPOSALS
13. Preparation of Proposals
13.1. The Proposal documents shall be submitted in the mode as mentioned below: -

(1)

Earnest Money Deposit (EMD)

Online
Note: All Interested bidders shall submit the EMD/Bid Security of
Amount Rs. 2,00,000 per cluster in through Online Payment
Gateway

(2)

Technical Proposal

Online

(3)

Financial Proposal

Online

13.1. Proposers are requested not to submit the hard copy of Financial Proposal. In case the hard copy of
financial proposal is submitted, the proposal shall be straight away rejected. Also, uploading of the
financial proposal in technical proposal will result in rejection of the proposal.
13.2. The Technical Proposal should provide the documents as prescribed in this RFP. No information related
to financial proposal should be provided in the technical proposal.
13.3. The RFP shall be duly signed and approved by the authorized person / appropriate authority, at the
appropriate places as indicated in the RFP documents and all other pages of the RFP including printed
literature, if any shall be initialed by the same person(s) signing the RFP. The RFP shall not contain any
erasure or overwriting, except as necessary to correct any error made by the Proposer and, if there is
any such correction; the same shall be initialed by the person(s) signing the RFP. The entire document
being part of RFP document should be page numbered. The Authorization Letter shall also be furnished
along with the RFP.
13.4. Proposers should note the last date of Proposal submission, as specified in Schedule of RFP, for
submission of Proposals. Except as specifically provided in this RFP, no supplementary material will be
entertained by the Procurement Entity, and the evaluation will be carried out only based on documents
received by the closing time of Proposal due date as specified in Schedule of RFP. Proposers will
ordinarily not be asked to provide additional material information or documents subsequent to the date
of submission, and unsolicited material if submitted will be summarily rejected. For the avoidance of
doubt, the Procurement Entity reserves the right to seek clarifications in case the Proposal is nonresponsive on any aspects.
13.5. A person signing (manually or digitally) the RFP form or any documents forming part of the contract on
behalf of another shall be deemed to warranty that he has authority to bind such other persons and if,
on enquiry, it appears that the persons so signing had no authority to do so, the Procurement Entity
may, without prejudice to other civil and criminal remedies, cancel the contract and hold the signatory
liable for all cost and damages.
13.6. Financial Proposal: While preparing the Financial Proposal, Proposers are expected to take into account
the various requirements and conditions stipulated in this RFP document. The Financial Proposal should
be a lump sum Proposal inclusive of all the costs including but not limited to all taxes associated with
the assignment. While submitting the Financial Proposal, the Proposer shall ensure the following:
a. The Proposer shall submit the Financial Proposal as per the instruction provided in this RFP
document and in online mode only.
b. The financial Proposal submitted in any other format will be treated as non-responsive. The
Proposer will be required to download the financial Proposal file, from e-tendering portal and
quote the prices in prescribed format before uploading it. The Proposer(s) shall not rename the
financial Proposal files downloaded. If an Proposer quotes, “Nil” charges in consideration, the
Proposal shall be treated as unresponsive and shall not be considered.
c. All the costs associated with the procurement shall be included in the Financial Proposal. These
shall normally cover remuneration for all the personnel (Expatriate and Resident, in the field,
office, etc.), accommodation, travel, transportation, equipment, printing, primary or secondary
data collection, meetings, documentations etc. The total amount indicated in the Financial
Proposal shall be without any condition attached or subject to any assumption and shall be final
and binding. In case any assumption or condition is indicated in the Financial Proposal, it shall be

<!-- page 17 -->

considered non-responsive and liable to be rejected.
d. The Financial Proposal shall take into account all the expenses and tax liabilities and cost of
insurance specified in the work order/Contract (as the case may be), levies and other
impositions applicable under the prevailing law. Further, all payments shall be subjected to
deduction of taxes at source as per applicable laws.
13.7. The rates quoted shall be considered for first year operations. For subsequent years, market
adjusted increased rate will be considered as per mutual consent of both parties.
13.8. Proposers shall express the price of their services in Indian Rupees only.

14.

Documents establishing the compliance of Services

13.2. To establish the conformity of the services to the RFP document, the Proposer shall furnish as part of
its Proposal a detailed item by item commentary, demonstrating substantial responsiveness to the
Scope of work, and if applicable, a statement of deviations and exceptions to the provisions of the
Section III - Scope of work.
13.3. Standards of the services specified by the Procurement Entity in the Section III – Scope of work, are
intended to be indicative and not exhaustive. The Proposer may offer other services, provided that it
demonstrates, to the Procurement Entity’s satisfaction, that the substitutions ensure substantial
equivalence or are superior to those specified in the Section III – Scope of work.

15.

Period of validity of Proposals

15.1. The price offered in the financial proposal by the Proposer for the applicable geography, shall be
valid till 1 (one) year from the end date of the proposal submission and the validity may be extended
as per mutual consent.
15.2. In exceptional circumstances, prior to the expiration of the proposal validity period, the Procurement
Entity may request Proposers to extend the period of validity of their proposals. The request and the
responses shall be made in writing. A Proposer may refuse the request without forfeiting its bid
security. A Proposer granting the request shall not be required or permitted to modify its Proposal.

16.

Earnest Money Deposit (EMD)1

16.1. All Interested bidders shall submit the EMD/Bid Security of Amount Rs. 2,00,000 through Online Payment Gateway
16.2. One Bidder will be eligible for bidding maximum for two clusters.
16.3. Payment of RFP EMD is not applicable to the entities falling under Micro, Small & Medium
Enterprises (MSME) having valid Udyog Aadhar Memorandum (UAM) registration certificate and
UAM number for Jharkhand state. Proposers, who are eligible to avail the exemptions, must upload
Udyog Aadhar Memorandum (UAM) registration certificate and UAM number for Jharkhand state

16.4. Other than above-cited entities, no Proposer is exempted from submitting the EMD as mentioned in
the RFP document. Proposals without EMD shall be summarily rejected.

16.5. Unsuccessful Proposer's EMD will be discharged/ returned within a period of 30 days after award of
contract to the successful Proposer.

16.6. Proposer shall not be entitled for any interest on EMD /Security deposit.
16.7. The successful Proposer's EMD will be discharged after signing the Contract and submitting the
security deposit as stipulated.

16.8. The EMD shall be forfeited:

<!-- page 18 -->

a). Proposer fails to accept the purchase order.
b). If a Proposer withdraws its Proposal during the period of Proposal validity as specified in the RFP.
c). In case of a successful RFP, if the Proposer fails:
i). To sign the Contract in accordance with terms and conditions. OR
ii). To furnish security deposit as per RFP.

17.

Documentation

17.1. Following documents must be submitted through online mode on e-procurement portal jharkhandtenders.gov.in
a). Proposal covering letter, as per “Annexure - 1”
b). Authorization Letter for signing of Proposal in favour of signatory to RFP documents as per
“Annexure 2”.
c). Particulars of the Proposers, as per “Annexure - 3”
d). Self-attested copy of establishment of the entity under Companies Act 1956/2013, Indian
Societies Registration Act 1860, Indian Trust Act 1882, or LLP registered under LLP Act 2008 or
registered under any other Act of India (as applicable)
e). Self-Attested copy of the Memorandum of Association (MoA) /Deeds / Bye-laws or such other
document evidencing vision, mission, objective and rules and regulations
f). Self-attested copy of audited balance sheet and statement of :
(i) Income and Expenditure account (In case of for non-profit organizations)
(ii) Profit and Loss (In case of for-profit organizations).
g). Self-attested copy of the Income Tax Returns (ITR) acknowledgement for three financial years
(FY) i.e.2022-23, 2023-24 & 2024-25.
h). Self-attested copy of the PAN Card, GST Registration Certificate (if applicable), GST Exemption
Certificate (if any), ESI & EPF registration certificate, MSME Registration Certificate (if applicable)
issued by the appropriate authority valid as on date of submission of RFP documents.
i).

Certified copy of Certification of 12 A/80G Registration (submit documented proof) or a valid
exemption certificate, if applicable.

j).

Certificate from Statutory Auditor & Audited financial statements shall be submitted by the
Proposer for the stated financial years ascertaining the average annual turnover and Positive net
worth of the proposer in the last Three (3) Financial Years (i.e. 2022-23, 2023-24 & 2024-25).
However, in case of non-profit organizations may have negative net worth.

k). A declaration attested by notary republic or sworn before the Executive Magistrate, from the
Proposer in the format given in the “Annexure 4” to the effect that the firm has neither been
declared as defaulter or black-listed/banned/ convicted by any court of law for any criminal or
civil offences or declared ineligible by any State/ UT Government or Govt. of India or any local
Self Government body or public sector undertaking in India for participation in future Proposals
for unsatisfactory performance, corrupt, fraudulent or any other unethical business practices or
for any other reason, as on date of submission Proposal document.
l).

Self-attested copy of the registration document showing incorporation of the Proposer and Self
Declaration by the Director/ Partner/ CEO or Authorized Signatory of the Proposer, Copy of
Agreement / Work Order / Letter of Notification of Award; and Client’s Certificate on satisfactory
completion and/or satisfactory progress report of project ascertaining that the Proposer have 3
(three) years of experience (both completed and ongoing projects/contracts [projects with
experience and contract period less than 1 (one) year would not be considered for eligibility
matrix]) in Health and any Central / State Govt Organization / PSU in the State/ Country in the
last 5 years as on due date for submission of Proposal.

m). Preference will be given to the organizations who have experience of working in Tuberculosis
program.

<!-- page 19 -->

n). Affidavit from the Proposer mentioning the key professionals indicating that the Proposer has
mid-level (more than 3 years experienced) supervisory staff having significant experience of
working in health and/ any Central / State Govt Organization / PSU as per Annexure 5.
o). Undertaking on a non-judicial stamp paper mentioning that - The Proposer shall inform
Procurement Entity of any such pending suits/ enquiry/ investigation against the Proposer in any
court of law, legal authority, paralegal authority which may hamper the execution of works under
this RFP.
p). Self-Declaration on company letter head regarding all ongoing litigations, if any.
q). Proposed Concept plan and methodology (Provider/ Patient Management plan / Operational
Plan, Creativity and innovations, Implementation Plan (Proposed HR Structure with onrogaram
for project implementation, Monitoring & Evaluation, Data management, Operational model with
timelines, analysis, reporting)), as specified in technical scoring matrix.
r). Policies and procedures of the Proposer as specified in eligibility criteria matrix.
s). Proof of registration on NGO – DARPAN portal or in any GoI portal.
t). Copy of last three years Annual Reports.
u). Proof of annual documents submission to registrar of societies/trusts/companies’/ registrar
of companies.
v). Evidence of local office premises or declaration for establishment of local office premise in the
district of the State where it wants to operate once contract is awarded.
w). Unconditional undertaking as per Annexure-6.
x). Statement of experience of implementing health and any Central / State Govt Organization / PSU
in any three years of the last five Financial Years (2020-21, 2021-22,2022-23, 2023-24 & 202425) as per Annexure-7 and proof of experience (a) Work order / Contract document /MOU/
Agreement and (b) Client’s certificate on satisfactory completion of the projects and/or
satisfactory progress report of project mentioning the details stated in the statement of
experience.
y). Statement of experience of working in TB program with any Central / State Govt Organization /
PSU in any three years of the last five Financial Years (2020-21, 2021-22,2022-23, 2023-24 &
2024-25) as per Annexure-7 and proof of experience (a) Work order / Contract document /MOU/
Agreement and
(b) Client’s certificate on satisfactory completion of the projects and/or satisfactory progress
report of project mentioning the details stated in the statement of experience.

<!-- page 20 -->

D. SUBMISSION AND OPENING OF PROPOSALS
18.

Submission of Proposals

18.1. Proposals are to be mandatorily submitted through online mode to the e-procurement portal jharkhandtenders.gov.in at a time for the technical and financial Proposals using the Digital Signature
Certificate (DSC). The documents will get encrypted (transformed into non-readable formats).

18.2. Each Proposer is required to obtain a Class-III Digital Signature Certificate (DSC) for submission of
Proposals.

19.

Deadline for Submission of Proposals

19.1. Proposals must be received by the Procurement Entity at the e-procurement portal jharkhandtenders.gov.in and no later than the date and time specified in the RFP document.

19.2. The date of submission and opening of Proposals shall not be extended except when –
a). sufficient number of Proposals have not been received within the given time and the
Procurement Entity is of the opinion that further Proposals are likely to be submitted if time is
extended; or
b). the RFP is required to be substantially modified as a result of discussions in pre-bid meeting or
otherwise and the time for preparations of Proposals by the prospective Proposers appears to be
insufficient for which such extension is required.
c). Or as decided by the competent authority of Procurement Entity.

19.3. In cases where the time and date of submission of Proposals is extended, an amendment to the RFP
shall be issued, in which case all rights and obligations of the Procurement Entity and Proposers
previously subject to the deadline shall thereafter be subject to the deadline extended.

19.4. If the due date for submission of Proposals is not a working day, the Proposals shall be received and
opened at the same time and hour on the next working day.

20.

Late Proposals

20.1. The Procurement Entity’s officer authorized to receive the Proposals shall not receive any Proposal that
is submitted personally by hand after the time and date fixed for submission of Proposals under any
circumstances.

21.

Opening of Proposals

21.1. Each Proposal received shall be opened by the Proposal Opening Committee in the presence of the
Proposers or their authorised representatives who choose to be present. However, non-attendance of
the Proposer in the meeting will not be the cause of disqualification

21.2. The Procurement Entity will open the proposals at the specified date and time. In case the specified
date of proposal opening falls on / is subsequently declared a holiday or closed day for the Procurement
Entity, the proposals will be opened, on the next working day.

21.3. The Proposal opening committee shall announce the following details(a) The name of the Proposer and whether there is a substitution or modification;
(b) the Proposal security; and
(c) any other details as the Committee may consider appropriate.

21.4. The Proposal Opening Committee shall prepare a record of the proceedings of the Proposal opening
that shall include the name of the Proposers and whether there is a withdrawal, substitution, or
modification.

<!-- page 21 -->

E. EVALUATION OF PROPOSALS
22.

Basic Principles

22.1. Proposals will be evaluated based on the instructions given in terms & conditions already incorporated
in Section II: Instructions to Proposers of the RFP document and without recourse to extrinsic evidence.
No new criteria will be brought in while evaluating the Proposals.

22.2. Information relating to the evaluation of Proposals and recommendation of contract award, shall not be
disclosed to Proposers or any other persons not officially concerned with the bidding process until
information on Contract Award is formally communicated to all Proposers

22.3. Any effort by a Proposer to influence the Procurement Entity in the evaluation or contract award
decisions may result in the rejection of its Proposal.

23.

Preliminary Scrutiny and Determination of Substantial Responsiveness of Proposals

23.1. The proposals will be scrutinized by the Proposal Evaluation committee appointed by the Procurement
Entity, to determine whether they are complete and meet the essential and important requirements,
conditions and whether the Proposer is eligible and technically qualified as per criteria laid down in this
RFP. The Proposal Evaluation Committee shall conduct a preliminary evaluation of the Proposals at the
beginning to assess the prima-facie responsiveness and record its findings thereof particularly in respect
of the following:
a). that the Proposal is signed, as per the requirements listed in the Proposal documents;
b). that the Proposal has been sealed as per instructions in the RFP documents;
c). the Proposal is valid for the period, specified in the RFP documents;
d). that the Proposal is accompanied by due Proposal Security declaration;
e). that the Proposal is unconditional (unconditional undertaking as per Annexure- 6;
f). that the Proposer has agreed to give the required performance security; and
g). Proposers must meet the eligibility and qualification requirements given in the RFP document.

23.2. The Proposals assessed responsive as above shall be examined to determine their substantial
responsiveness, in particular, to confirm that all requirements of RFP Documents have been met
without any material deviation, reservation or omission where;


“deviation” is a departure from the requirements specified in the Proposal documents;



“reservation” is the setting of limiting conditions or withholding from complete acceptance of the
requirements specified in the Proposal Documents; and



“omission” is the failure to submit part or all of the information or documentation required in the
Proposal documents.

23.3. A “material deviation, reservation, or omission” is one that,
a). If accepted shall: (i)

effect in any substantial way the scope, quality, or performance of the subject matter of
procurement specified in the Proposal documents; or
(ii) limit in any substantial way, inconsistent with the Proposal Documents, the rights of the
procurement entity or the obligation of the Proposer under the proposed contract; or

b). if rectified would unfairly affect the competitive position of other Proposers presenting
substantially responsive Proposals;

23.4. The Proposal Evaluation Committee shall regard a Proposal as substantially responsive if it conforms to
all requirements set out in the RFP document, or contains minor deviations that do not materially alter
or depart from the characteristics, terms, conditions and other requirements set out in the RFP
document, that is, there is no material deviation, or if it contains errors or oversights that can be
corrected without any change in the substance of the Proposal;

<!-- page 22 -->

23.5. The Proposal Evaluation Committee may waive non-conformities in the Proposal that do not constitute
a material deviation, reservation or omission and deem the Proposal to be responsive;

23.6. The Proposal Evaluation Committee may request the Proposer to submit necessary information or
documents which are historical in nature like audited statements of accounts, tax clearance certificate,
PAN, or any other documents etc. within stipulated time provided by the committee. Failure of the
Proposer to comply with the request within the stipulated time shall result in the rejection of its
Proposal.

23.7. Proposals that are not responsive or contain any material deviation shall be rejected. Proposals declared
as non-responsive shall be excluded from any further evaluation.

23.8. The Proposals, which do not meet the aforesaid requirements are liable to be treated as non-responsive
and may be ignored. The decision of the Procurement Entity as to whether the Proposer is eligible and
qualified or not and whether the Proposal is responsive or not shall be final and binding on the
Proposers. Financial Proposals of only those Proposers, who qualify on technical Proposal, will be
considered and opened.

24.

Clarification of Proposals

24.1. To facilitate evaluation of Proposals, the Procurement Entity may, at its sole discretion, seek
clarifications in writing from any Proposer regarding its Proposal. Notwithstanding anything contained in
the RFP, the Procurement Entity reserves the right not to take into consideration any such clarifications
sought for evaluation of the Proposal.

24.2. At any point in time during the bidding process, if required by the Procurement Entity, it is the
Proposers’ responsibility to provide required evidence of their eligibility as per the terms of the RFP, to
the satisfaction of the Procurement Entity. If no response is received by due date, the Procurement
Entity, shall evaluate the offer as per available information. The technical evaluation committee of the
Procurement Entity can verify the facts and figures quoted in the Proposal. The Procurement Entity
reserves the right to conduct detailed due diligence of the information provided by the Proposers for
technical and financial evaluation.

24.3. No change in the prices or substance of the Proposal shall be sought, offered, or permitted, except to
confirm the correction of arithmetic errors discovered by the Committee in the evaluation of the
financial Proposals

24.4. No substantive change to qualification information or to a submission, including changes aimed at
making an unqualified Proposer, qualified or an unresponsive submission, responsive shall be sought,
offered or permitted under any circumstances;

24.5. All communication generated as above shall be included in the record of the procurement proceedings.

25. Fraud and Corrupt Practices
25.1. The Proposers and their respective officers, employees, agents and advisers shall observe the highest
standard of ethics during the selection process. Notwithstanding anything to the contrary contained
herein, the Procurement Entity may reject an application without being liable in any manner
whatsoever to the proposer if it determines that the Proposer has, directly or indirectly or through an
agent, engaged in corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice in the selection process.

25.2. Without prejudice to the rights of the Procurement Entity hereinabove, if a proposer is found by the
Procurement Entity to have directly or indirectly or through an agent, engaged or indulged in any
corrupt practice, fraudulent practice, coercive practice, undesirable practice or restrictive practice
during the Selection Process, such Applicant shall not be eligible to participate in any RFP issued by the
Procurement Entity during a period of 3 (three) years from the date such Applicant is found by the
Procurement Entity to have directly or indirectly or through an agent, engaged or indulged in any
corrupt practice, fraudulent practice, coercive practice, undesirable practice or restrictive practice, as
the case may be.

25.3. For the purposes of this Clause, the following terms shall have the meaning hereinafter respectively
assigned to them:
(i) “Corrupt practice” means (i) the offering, giving, receiving, or soliciting, directly or indirectly, of
anything of value to influence the actions of any person connected with the Selection Process
(for avoidance of doubt, offering of employment to, or employing, or engaging in any manner

<!-- page 23 -->

whatsoever, directly or indirectly, any official of the Procurement Entity who is or has been
associated in any manner, directly or indirectly, with the Selection Process.
(ii) “Fraudulent practice” means a misrepresentation or omission of facts or suppression of facts
or disclosure of incomplete facts, in order to influence the Selection Process.
(iii) “Coercive practice” means impairing or harming or threatening to impair or harm, directly or
indirectly, any person or property to influence any person’s participation or action in the
Selection Process.
(iv) “Undesirable practice” means (i) establishing contact with any person connected with or
employed or engaged by the Procurement Entity with the objective of canvassing, lobbying or
in any manner influencing or attempting to influence the Selection Process; or (ii) having a
Conflict of Interest, and
(v) “Restrictive practice” means forming a cartel or arriving at any understanding or arrangement
among Applicants with the objective of restricting or manipulating a full and fair competition in
the Selection Process.

26. Fulfilment of the Qualification Criteria
26.1. As part of the evaluation, a Proposer must fulfil the Minimum Qualification Criteria. In case a Proposer
does not fulfil the Minimum Qualification Criteria, the Proposal of such a Proposer will not be evaluated
further.

27.

Qualification Criteria

27.1. The qualification criteria for a Proposer to qualify for technical Proposal evaluation are listed below:
Sr
no

Eligibility criteria for Proposers per cluster / district

Recommended Criteria
The Proposer should be an established entity under
Companies Act 1956/2013, Indian Societies
1
Registration Act 1860, Indian Trust Act 1882, or LLP
registered under LLP Act 2008 or registered under
any other Act of India.
2

3

4

5

Certified copy of the MoA / deeds / bye-laws or
such other document evidencing vision, mission,
objective and rules and regulations
Proposer should have 3 (three) years of experience
(both completed and ongoing projects/contracts
[projects with experience and contract period less
than 1 (one) year would not be considered for
eligibility matrix]) in Health and any Central / State
Govt Organization / PSU in the last 5 years as on
due date for submission of Proposal. Proposer
should submit the following documents in support
of fulfillment of Proposer’s qualification, along with
its Proposal.
Preference will be given to the organization who
have experience of working in Tuberculosis program
and will be considered for evaluation.
The Proposer should have a Positive Net Worth in
the last Three (3) Financial Years (i.e. 2022-23, 202324 & 2024-25)
However, in case of nonprofit organizations may
have negative net worth.
The Proposer must have average annual turnover
of–

Mandatory Documents to be submitted as evidence

Self-attested copy of certificate of registration under any
other law applicable under the laws of India.

Self-Attested copy of the MoA / deeds / bye-laws or
such other document evidencing vision, mission,
objective and rules and regulations

 Registration document showing incorporation of the
Proposer and Self Declaration by the Director/
Partner/ CEO or Authorized Signatory of the Proposer.
 Copy of Agreement / Work Order / Letter of
Notification of Award; and
 Client’s Certificate on satisfactory completion and/or
satisfactory progress report of project

Certificate from Statutory Auditor & Audited financial
statements shall be submitted by the Proposer for the
stated financial years.
Certificate from Statutory Auditor & Audited financial
statements shall be submitted by the Proposer for the

<!-- page 24 -->

Sr
no

6

7

Eligibility criteria for Proposers per cluster / district

Mandatory Documents to be submitted as evidence

a) Rs. 5,00,00,000 (Five Crore rupees) if Proposal
for 1 cluster/ district,
b) Additional Rs. 5,00,00,000 (Five Crore rupees)
every additional cluster/ district will be required.

stated financial years along with audited balance sheet
and
(a) Statement of Income and Expenditure account. (if
the Proposer is for non-profit entity)
(b) Statement of Profit and Loss (if the Proposer is for
profit entity).

Certification of 12A and/or 80G Registration For
Nonprofit organization

Self-attested copy of Certificate issued by the
appropriate authority valid as on date of
submission of RFP documents.

Valid Certificate of 12A and/or 80G Registration (submit
documented proof), if applicable
Self-attested copies of
1. PAN Card
2. GST Registration Certificate (if applicable)
3. GST Exemption Certificate (in any)
4. Copy of Income Tax Return (with computation) filed
and submitted by the Proposer for three financial
years FY 2022-23, 2023-24 & 2024-25.
5. ESI & EPF registration certificate.
6. MSME Registration Certificate (if applicable)
1. Accounting/Financial policies
2. Internal control policies, risk matrix and procedures
3. Procurement guidelines
4. HR and Administrative Policies

8

Policies and Procedures of the Proposer

9

The Proposer must not be (i) Blacklisted / banned /
convicted by any court of law for any criminal or
civil offences/ declared ineligible by any entity of
any State Government or Govt. of India or any local
Self Government body or public sector undertaking
in India for participation in future Proposals for
unsatisfactory performance, corrupt, fraudulent or
any other unethical business practices or for any
other reason, as on date of submission (upload) of
online Proposal document.

Affidavit attested by Notary Republic or sworn before
Executive Magistrate

10

The Proposer shall inform Procurement Entity of
any such pending suits/ enquiry/ investigation
against the Proposer in any court of law, legal
authority, paralegal authority which may hamper
the execution of works under this RFP

Undertaking to be submitted on a non-judicial stamp
paper

11

The Proposer shall declare all ongoing litigations, if
any.

Self-Declaration on Company Letter Head

12

The Proposer should be registered
on the Government of India’s
(GoI) portal, DARPAN, https://ngodarpan.gov.in/
maintained by NITI Aayog, Govt. of India.

Proof of registration DARPAN or any GoI portal

13

Unconditional undertaking

14

Undertaking to be submitted on a non-judicial stamp
paper
Statement of experience of implementing health and As per Annexure-7 and proof of experience (a) Work
any Central / State Govt Organization / PSU in any
order / Contract document /MOU/ Agreement and (b)
three years of the last five Financial Years (2020-21, Client’s certificate on satisfactory completion of the
2021-22,2022-23, 2023-24 & 2024-25)
projects and/or satisfactory progress report of project
mentioning the details stated in the statement of
experience.

<!-- page 25 -->

Sr
no

Eligibility criteria for Proposers per cluster / district

Mandatory Documents to be submitted as evidence

15

Statement of experience of working in TB program
with any Central / State Govt Organization / PSU in
any three years of the last five Financial Years
(2020-21, 2021-22,2022-23, 2023-24 & 2024-25)

As per Annexure-7 and proof of experience (a) Work
order / Contract document /MOU/ Agreement and (b)
Client’s certificate on satisfactory completion of the
projects and/or satisfactory progress report of project
mentioning the details stated in the statement of
experience.

Additional criteria/document
1

Copy of last three years Annual Reports

2

Proof of annual documents submission to registrar of societies/trusts/companies/ registrar of companies

3

Evidence of local office premises or declaration for establishment of local office premise in the district of the
State where it wants to operate once contract is awarded.

4

Any other relevant detail, statutory requirements and compliance -PF, IT/GST, ESI, LWF, PT

5

Such other document/s as may be relevant at the point of assessment.

28.

Technical Evaluation

28.1. The committee (“Evaluation Committee”) appointed by the Procurement Entity will carry out the
evaluation of Proposals based on the following evaluation matrix. If required, the Procurement Entity
may seek specific clarifications from any or all Proposer (s) at this stage. Technical evaluation of only
those Proposer(s) shall be carried out of those meeting all the defined minimum pre-qualification
criteria. After the technical evaluation each Proposal will be given a technical mark as detailed below.
The maximum points/ marks to be given under each of the evaluation criteria are:

Technical Evaluation Matrix (District-wise)
SN

Particulars

Criteria / Sub-criteria

1

Experience of implementing health (a) Minimum 3 years
and any Central / State Govt
(b) > 3 years, ≤ 5 years
Organization / PSU, in any three
years of the last five Financial
Years (2020-21, 2021-22, 2022-23, (c) > 5 years
2023-24 & 2024-25).

Allocation of
Marks

Weightage
(Total Marks)

5 marks
10 marks
15 marks
15 marks

Experience of working in TB
program with any Central / State
Govt Organization / PSU in any
two years of the last five Financial
Years (2020-21, 2021-22, 2022-23,
2023-24 & 2024-25).

(a) Minimum 2 years

5 marks

(b) > 2 years, ≤ 5 years

10 marks

(c) > 5 years

15 marks

(a) INR 5 Crore

5 marks

3

The Proposer should have an
average annual financial turnover
of INR 5 Crore (Rupees Five Crore)
per cluster / district in the last
Three (3) Financial Years (2022-23,
2023-24 & 2024-25).

(b) Additional 1 mark for every
additional INR 1 Crore average
annual financial turnover above
INR 5 Crore

Additional 15
marks

20 marks

4

Any Experience in public health
(Door-to-Door program) in the last

Experience demonstrated with
valid supporting documents

10 marks

10 marks

2

15 marks

<!-- page 26 -->

SN

5

6

7

Allocation of
Marks

Particulars

Criteria / Sub-criteria

three years. Supporting
documents: MOU

(MOU)

Experience in running clinical
facilities / sample collection at any
Government / any Central / State
Govt Organization / PSU in the last
three years.
Supporting documents: MOU /
Work Order, Payment receipt to
be attached.

2 hospitals

05 marks

3 hospitals

10 marks

4 hospitals

15 marks

5 hospitals

20 marks

Organization must have healthspecific human resource (MBBS,
MD, DM, BHMS, BDS or any
recognized by MCI/NMC of India)
deployed in Government sector/
any Central / State Govt
Organization / PSU. Documents
need to attach CV and
Appointment letter.

1 to 10 personnel

05 marks

10 to 15 personnel

10 marks

1.1 Provider / Patient
Management Plan / Operational
Plan:
• Provider Mapping and
Engagement
• Notification support
• Handling linkages (free
diagnostics – X-ray, sputum
microscopy, Molecular Testing,
DST services; drug distribution
models for NTEP-provided FDC;
co-morbidity testing linkages)
• Patient support, Treatment
adherence and follow-up till
treatment outcome reporting
• Contact Investigation and TB
Preventive Treatment
• Linkages for DR-TB patients
• Facilitate incentives

03 marks

1.2 Creativity and Innovations

02 marks

2. Implementation Plan (Proposed
HR structure with organogram for
project implementation,

05 marks

Concept plan and methodology
Concept plan for executing the
project in the concerned cluster /
district with Technical
Presentation.
(Online of Technical Presentation
to be submitted along with
proposal)

Weightage
(Total Marks)

20 marks

10 marks

10 marks

<!-- page 27 -->

SN

Particulars

Criteria / Sub-criteria

Allocation of
Marks

Weightage
(Total Marks)

Monitoring & Evaluation, Data
management, Operational model
with timelines, analysis, reporting)
Total Marks

100 Marks

Note: All claims under Sl. No. 4, 5 & 6 must be substantiated with the specified
supporting documents (MOU, Work order, Performance certificate, payment received
copy), failing which no marks shall be awarded for the respective criterion.

29.

Final Selection

29.1. Technical Proposal of the qualified Proposers shall be evaluated before opening the Financial Proposal.
29.2. The technical score would be calculated for each Proposer by the Procurement Entity and all the
Proposers who gets a minimum of 60 marks out of 100 would only be considered for financial
evaluation. Proposers who get a technical score of less than 60 out of 100 would not be considered for
the financial evaluation.

29.3. Procurement Entity shall adopt the QCBS (Quality and Cost Based Selection) methodology for selection
of agency for each cluster / district: where in 60% weight age shall be given to technical evaluation score
based on the technical Proposals submitted by the Proposer and 40% weight age shall be given to the
financial evaluation score based on the financial Proposal submitted by the Proposer.

29.4. In case of two or more Proposers quoting the same value, the Proposer having the higher annual
average turnover as per the eligibility criterion would be the first in sequence.

29.5. The combined score of the technical and financial evaluation of the technically qualified Proposers as
per the eligibility criteria, shall be calculated as per the formula:
Score (S) = (T/T High X 60) + (C Low/C X 40)
where:
T = Technical evaluation score of the Proposer
T High = Highest Technical score amongst the Proposers
C Low = Lowest quote of financial Proposal amongst the Proposers
C = Quote of financial Proposal by the Proposer.
And the Proposer, securing the highest score shall be shortlisted for the concerned assignment.
For example,
Three Proposer(s) A, B and C, have applied for a particular assignment. Technical score shall be
arrived at by treating the marks of the Proposer scoring the highest marks (assuming Proposer A) in
the technical evaluation as 100. The technical score of other Proposers (B,C etc.) shall be computed
using the formula:

<!-- page 28 -->

Technical Score = Marks of B/ Marks of the Highest Scorer (Assumed Proposer A) X 100.
Similarly, financial score of the Proposers, shall be arrived at taking the cost quoted by the L1
(Lowest Proposal quoted) Proposer i.e., let the lowest quoted Proposer be C, as 100. Marks of the
other Proposers shall be calculated using the formula:
Financial Score = Cost of L1 Proposer /Cost quoted by Proposer X 100.

A

79

B

85

C

91

(79/91)*100
= 86.813
(85/91)*100
= 93.406
(91/91)*100
= 100

86.813*60/100
= 52.08
93.406*60/100
= 56.043
100*60/100 =
60

2300
2417
2576

(2300/2300)*100
= 100
(2300/2417)*100
= 95.156
(2300/2576)*100
= 89.285

100*40/100
= 40
95.156*40/100
= 38.063
89.285*40/100
= 35.714

Combined Score
(Tech Weightage + Fin.
Weightage)

Financial Weightage
(40%)

Financial Score
(Cost of L1 Proposer /Cost
quoted by Proposer X 100)

Quoted Value (In INR)

Technical Weightage
(60%)

Technical Score
(Marks of Proposer/ Marks of
the Highest Scorer X 100)

Proposer

Technical Marks - as scored in
technical evaluation

A "combined score" shall be arrived at, taking into account both technical and financial scores of
each Proposer with a weightage of 60% for technical score and 40% for Financial score. The
successful Proposer shall be the one who has the highest combined score. For example,

92.08
94.106
95.714

Hence, Proposer C, with the highest score of 95.714 becomes the successful Proposer.

29.6. The selection/ allocation of the cluster/ districts would happen based on the following below mentioned
criteria:
(i) For each cluster/district, the H1 (highest successful Proposer) for that cluster/ district will
be offered to take up the contract. If the same agency is H1 in more than one cluster/
district, the agency may have the option to select the cluster/districts.
(ii) After the first round of allocations, if there are any clusters/ districts that are left, agencies
that are H2 (second highest successful Proposer) for those districts may be offered to take
up the contract through negotiation. If the same agency is H2 in more than one of the
remaining cluster/ districts, the agency may have the option to select the districts.

29.7. In case of more than one Proposer with equal highest score up to 3 decimals in a cluster/district, then
the Proposer with the highest financial score shall be declared as the shortlisted Proposer for the
particular cluster/ district.

29.8. In case, the shortlisted Proposer/service provider denies/fails to honour the contract agreement /Letter
of Intent(LoI), the Procurement Entity shall be at the freedom to negotiate with the Proposer, with the
next highest combined score CS2, and CS3 (in this order), responsive Proposers with their consent to
enter into an agreement with the Procurement Entity for working as a Patient Provider Support Agency

<!-- page 29 -->

(PPSA) for providing Tuberculosis (TB) related services under National Tuberculosis Elimination Program
(NTEP) in the concerned clusters/ district (s).

29.9. The Procurement Entity reserves the right to accept in part or in full any proposal or reject any
proposal(s) without assigning any reason or to cancel the tendering process and reject all proposals at
any time prior to award of contract, without incurring any liability, whatsoever to the affected
Proposer(s).
29.10. The Procurement Entity reserves the right at the time of Contract award and/or during validity of
contract, to increase or decrease the scope of services without any change in unit price or other terms
and conditions.
29.11. The Procurement Entity will notify the successful Proposer(s) in writing by issuing a Letter of Intent (LoI),
that its proposal has been accepted for the concerned district, briefly indicating there in the essential
details like description of services and corresponding prices accepted, subject to the contract agreement
to be signed between the parties “floated from this RFP” having the terms and conditions etc., therein.
The Proposer shall within 7 days of issue of the Letter of Intent (LoI), give his acceptance.
29.12. The successful Proposer must furnish to the Procurement Entity the required Performance Security as
applicable for the concerned cluster/district, before executing the contract/signing of the contract
agreement positively failing which the EMD will be forfeited, and the award will be cancelled, and
Proposer may also be blacklisted. Relevant details about the performance security have been provided
in the RFP document.
29.13. The contract agreement will be signed between State Health Mission and the selected service provider
for each cluster/district and will be required to be signed within 21 days of the issue of the Letter of
Intent(LoI). The stamp duty and registration charges, if any levied by the Central or State governments
or any other statutory body, payable on the contract agreement will be borne by the service provider.

30.

Procurement Entity’s Right to Accept Any Proposal, and to Reject Any or All
Proposals

30.1. The Procurement Entity reserves the right to accept or reject any Proposal, and to cancel / annul the
bidding process and reject all Proposals at any time prior to contract award, without thereby incurring
any liability to the Proposers for which the Procurement Entity shall keep record of clear and logical
reasons properly for any such action / recall of bidding process. In case of cancellation / annulment, all
Proposals submitted and specifically, EMD, shall be promptly returned to the Proposers.

<!-- page 30 -->

F. AWARD OF CONTRACT
31.

Award Criteria

31.1. The Procurement Entity shall award the Contract to the Proposer whose Proposal has secured highest
total combined score during evaluation of Proposals.

32.

Notification of Award

32.1. Prior to the expiration of the period of Proposal validity, the Procurement Entity shall notify the
successful Proposer, in writing, that its Proposal has been accepted. The notification letter (hereinafter
and in the Conditions of Contract and Contract Forms called the “Letter of Acceptance”) shall specify the
sum that the Procurement Entity will pay the Service Provider in consideration of the Delivery /
Performance of Services (hereinafter and in the Conditions of Contract and Contract Forms called “the
Contract Price”).

32.2. Until a formal Contract is prepared and executed, the Letter of Acceptance shall constitute a binding
Contract.

33.

Performance Security2

33.1. Within fifty (15) days of the receipt of Letter of Acceptance from the Procurement Entity, the
successful Proposer, if required, shall furnish the Performance Security equivalent to 5% of contract
value, using the Performance Security Form included as Annexure - 9, or another Form acceptable to
the Procuring Entity.

33.2. Failure of the successful Proposer to submit the above-mentioned Performance Security or sign the
Contract shall constitute sufficient grounds for the annulment of the award and forfeiture of the EMD.
In that event the Procuring Entity may award the Contract to the next lowest evaluated Proposer,
whose Proposal is substantially responsive and is determined by the Procuring Entity to be qualified to
perform the Contract satisfactorily.

33.3. The validity of the performance security shall be for a period of 60 days beyond the date of completion
of all contractual obligations.

34.

Signing of Contract

34.1. Promptly after notification of Award, the Procurement Entity shall send the successful Proposer the
Contract Agreement.

34.2. Within fifty (15) days of receipt of the Contract Agreement, the successful Proposer shall sign, date,
and return it to the Procurement Entity.

35.

Exclusion of Proposal/ Disqualification

35.1. Procurement Entity may exclude or disqualify a Proposal if:
a) The information submitted, concerning the qualifications of the Proposer, was false or constituted a
misrepresentation; or

b) The information submitted, concerning the qualifications of the Proposer, was materially inaccurate or incomplete; and

c) The Proposer is not qualified as per pre-qualification/ eligibility criteria mentioned in the RFP
document, even after seeking clarifications/ additional documents by committee;

d) The Proposal materially departs from the requirements specified in the Proposal or it contains
false information;

e) The Proposer submitting the Proposal, his agent or anyone acting on his behalf, gave or agreed to
give to any officer or employee of the NHM or other governmental authority a gratification in any
form or any other thing of value so as to unduly influence the Selection Process;

2

https://doe.gov.in/sites/default/files/Performance%20Security_0.pdf

<!-- page 31 -->

f)

A Proposer, in the opinion of the Procurement Entity, has a conflict of interest materially affecting
fair competition.

g) A Proposal shall be excluded/ disqualified as soon as the cause for its exclusion/disqualification is
discovered.

<!-- page 32 -->

Section III – Scope of Services

3.1 The Agency shall perform all activities as detailed in Annexure 1, including but not limited to:
- Private provider mapping, engagement, sensitization
- Real-time notification on NIKSHAY
- Sample collection (2 samples/patient) & transport to NTEP labs
- Linkages for free diagnostics and anti-TB drugs
- HIV, DM, NAAT testing coordination (100% NAAT upfront)
- Treatment adherence support & counselling (home visits + telephonic)
- Patient & provider incentive facilitation
- Contact investigation & TPT management
- Adverse drug reaction (ADR) reporting
- Long-term follow-up shall be conducted every 6 months for a period of 2 years post-treatment
outcome or till the subsistence of the contract period, whichever is later, subject to a maximum period
of 3 years from the date of execution of the contract.
Prohibition: The Agency shall not charge any amount from TB patients.

3.2 Roles of both parties:
SN

1

Service Area

Role of Agency

Private

 Private sector mapping and
landscape analysis and networking
of private providers in Hub & Spoke
model- Quarterly

Provider
engagement

 Sensitization /Capacity Building of
private providers (private hospitals,
clinics, nursing homes,

Role of NTEP (State authority in
case of contract executed)
 Issue authority letter to agency
for reaching out to private providers to
facilitate NTEP services

 Regular payment of eligible
provider incentives as per NTEP
guidelines

<!-- page 33 -->

SN

Service Area

Role of Agency
charitable
/
trust
hospitals,
chemists/pharmacists, laboratories, etc) on
notification and other related services in
coordination with NTEP

Role of NTEP (State authority in
case of contract executed)
 Data

sharing

of

existing

registered health facilities and their
activities

 Registration of engaged providers
on Nikshay Portal with account
details
 Regular update on NTEP services
through in-person/clinic visits
as
well
as
engaging/mobilizing them to CMEs /
Workshops (IMA, IAP, FOGSI etc).
 Facilitate collection of account
details / Ensure AADHAR based face
authentication/as per the latest
guidelines on Ni-kshay of patients.
 Collection of drug sale data from
private
sector
with
Implementation of H1 Register and
data sharing with the DTO quarterly.

2

 Facilitate real-time enrolment of
presumptive cases and notification
on Nikshay.

Notification
support

3

Diagnosis

3.a

Knowledge
Attitude
Practices

 Develop strategies and visit to
Private health facility to increase
private sector notifications

/
/

 Promote and advocate
microbiological confirmation over
clinical diagnosis and appraise on
the availability of diagnostic
modalities under NTEP.
 100% upfront NAAT of all
presumptive case.

 Provide Nikshay log in credentials
to agency with access as per
services under agreement

 Ensure availability of free tests/
NAAT as per estimated patient load

<!-- page 34 -->

SN

Service Area

Role of Agency

Role of NTEP (State authority in
case of contract executed)

 Regular update on Universal DST
services for all TB patients.

 IEC and ACSM supported by NTEP
 Ensure / Establish sample collection
centers in private health care
facility /community with 2 Sample
collection from every patient
 Identify designated areas as well as
nodal persons for sample collection
and packaging in each Private
Health facility
 Counsel and train, the patient on
expectorating a good sample
 Ensure accurate packaging and
labelling of collected specimen as
per the NTEP guidelines
3.b

Sample Collection
and transportation

 Transportation of samples from
identified collection centers to the
linked TB laboratories as per NTEP
guidelines

 Provide the agency with SOPs,
NTEP formats for sample collection
and packaging as well as access to
Nikshay user credentials
 Train concerned staff on specimen
collection, packaging, and
transportation with requisite safety
precautions as per NTEP guidelines
 Identify and specify laboratory
linkages

 Ensure appropriate specimen
storage facility (as per NTEP
guidelines) in case of delays in
transport

 Provide a prototype / sufficient
supply of sputum sample container
and specification for
(procurement) of sample collection
containers.

 Coordinate with corresponding
laboratories for delivery of result in
timely manner

 Provide results of the sample
transported by agency as per TAT
recommended under NTEP

 Maintain biological specimen
examination request form and
sputum collection register.
 Ensure timely delivery of results to
the specimen collection center &/or
patients.
 Bio -safety standards compliance for
sample collection, packaging

<!-- page 35 -->

SN

Service Area

Role of NTEP (State authority in
case of contract executed)

Role of Agency
and transport

 Ensure that all TB patients are put
on treatment timely
 Promote use of NTEP provided free
drugs
 Linkages to NTEP provided drugs
(based on patient’s willingness),
Private PHI will be dispensing drugs.
4

Treatment

 Develop drug delivery models,
identify stocking points considering
the convenience of patients and
providers and ensuring no
possibilities of stockouts

 Forecasting of drugs including
private sector patients
 Ensure regular supply of drugs to
agency for further distribution to
patients

 Recording and reporting as per
NTEP in Nikshay Portal/ DVDMS
 ADR Sensitization and support for
redressal
5

Public Health Action
 Ensure 100% HIV Testing of all

5.a

HIV Testing

TB patients and updating in the Ni-kshay
Portal through linkages with public facilities

 Support for HIV testing

 Ensure 100% Diabetes status
testing of all TB patients and
Diabetes
5.b

5.c

Testing

Treatment
Adherence and
Outcome

 Support
updating in the Ni-kshay Portal through
linkages with public facilities

appropriate
facilities

 Counselling and treatment
adherence support to all TB patients
through home visits as well as
telephonic follow up at regular
intervals as well as update on
Nikshay covering following aspects:
o

TB

infection

and

Diabetes
public

testing

at

health

 Providing standard operating
procedures, training and reference
material to the agency
 Timely payment to all eligible
beneficiaries as per NTEP
guidelines


<!-- page 36 -->

SN

Service Area

Role of NTEP (State authority in
case of contract executed)

Role of Agency



disease
































o

Contact screening and TB
Preventive
Treatment

o

Nikshay Poshan Yojana
/ linkages with other social
security schemes, as per
applicability


Contact
Investigation andTB

6

Preventive
Treatment
(TPT)

o

Nutritional Assessment
and Support

o

Follow up visits
investigation

o

Adverse effect reporting

o

Status of outcome, before
submitting the outcome
report cure, last and final
test of the patient shall be
undertaken.

o

Long term follow-up

o

Promoting
Bharat app

TB

and

Mukt

 Ensure availability of tests as per
estimated patient load

 Contact tracing should be done by
home visit within 7 days of diagnosis
of all private sector patients with
STS/TBHV.

 Visit to index patient’s home by
STS/TBHV

 Agency will enter all contacts in TPT
register

completion by Sahiya

 Maintain TPT treatment card
(Second copy)
 Ensure TPT must be given to all
eligibles by Sahiya -Coordinate with
respective Sahiya.
 Adherence monitoring and
management of ADR
 Counsel the patients and family

• TPT initiation and follow up till

 Forecasting of drugs including
private sector patients
 Ensure regular supply of drugs to
agency for further distribution to
patients
 Provision of SOPs/ IEC and
training material to support the

<!-- page 37 -->

SN

Service Area

Role of NTEP (State authority in
case of contract executed)

Role of Agency
on the importance of treatment
completion

PPSAs and private providers.

 Update records / reports
 Provide checklist for invoice
submission

7

Payment
Agency1

to

 Complete validation/verification
within 30 days of invoice
submission with 10% sample cross
check

 Timely submission of invoice along
with supporting documents as per
agreement

 Provision of details in case of
penalty

 Provide justification / clarity
wherever sought by NTEP

8

State/ District
Review

 Prepare
and
participate
all periodic review

 Timely Payment to agency as per
provisions in the contract within 30
days post verification of invoice (It
will be subject to availability of
fund)

in

 State/ District will inform the
agency.

ARTICLE 4: FINANCIAL OBLIGATIONS & PAYMENT MATRIX
4.1 Monthly Invoicing:
The Agency shall raise an invoice (with GST) by the 7th day of the succeeding month to the respective District Tuberculosis
Centre (DTC), along with supporting documents and progress report.

4.2 Payment Key Indicators & Penalties (Pro-rata deduction applicable for underachievement):

Sl.
No
.

Payment
amount (%
of the
quoted
value)

1
10%

Key Indicators

Performance Indicator*

Number of TB
patients notified

At least 95% of TB notifications against target; In case
of non-achievement, the payment will be made
on pro-rata basis. There will be no restriction for PPSA
for achieving higher no. of notification over

<!-- page 38 -->

and above estimated targets as per the MoU.
2

AADHAR based
face
Authentication/V
alidated
bank
account details

At least 95% AADHAR based face Authentication/
validated account details out of the notified TB patients.
In case of non-achievement, the payment will be made
on pro-rata basis.

10%

NAAT

At least 80% of patients should have undergone the
NAAT out of the notified TB patients. In case of nonachievement (Less than 70%), the payment will be made
on
pro-rata
basis.
Agency will be submitting 2 sample per patient to
NAAT labs.

5%+5%=10%

HIV
and
Testing

10%

Contact tracing
and
chemoprophylax
is (TPT)

15%

Successful
Outcome

5%

3

4

5

DM

6

All notified TB patients should have undergone both HIV
& DM testing, In case of non-achievement, (Less than
95% i- HIV and Less Than 90% -DM) the payment will be
made on pro-rata basis
At least 90% of the notified TB patients should have their
contacts screened and enter all contacts in TPT register.
Coordinate with STS and Sahiya for TPT initiation for
eligible contacts (as per NTEP guidelines). Maintain TPT
treatment card.
At least 85% of the patients should have successful
outcome out of the notified TB patients. In case of nonachievement, the payment will be made on pro-rata basis

7



10%

Maintain Treatment cards as per the
guidelines

Treatment
Adherence





8

9

Daily monitoring of medication.

Update in Ni-Kshay Portal

10%

Follow
ups
during Treatment

As per the regimen

10%

Long
Follow up

At least 90% of the treatment outcome given
patients.

5%

Mapping and
Registration of
Private Provider
in Ni-kshay Portal,
including Bank
Account details

10

term

Facilitate that all private health facilities from which
patients have been notified are registered on the Nikshay portal along with their bank account details.

<!-- page 39 -->

11

5%

DCM

Differentiated
TB
recommendation

Care

as

per

the

NTEP

Overachievement: No upper restriction; payment shall be made for additional notified patients at the same rate.

4.3 Verification & Penalty for Discrepancy:
The Procurement Entity shall validate 10% of cases (stratified random sampling) and keep validation record for five years/ as per NHM
norms, after end of contract with agency. If discrepancy is found in Key Indicators i.e. patient notification, bank account/ Aadhar based
face authentication, NAAT, HIV and DM testing, TPT, successful outcome, treatment adherence, follow up during treatment, long term
follow up, private provider mapping with bank account updating and DCM a penalty equal to the percentage of discrepancy shall be
deducted from the total amount claimed under the respective Key Indicators. In the event of any failure, malfunction, or downtime of
machines/equipment used for conducting NAAT, HIV, Diabetes or other diagnostic tests, or due to any disruption/failure of the Nikshay
Portal, Aadhaar Authentication mobile applications, software systems, internet connectivity, or any other related systems/services
attributable to the Department or any third-party agency engaged by the Government, the PPSA shall not be held liable or penalized for
any consequential delay, disruption, or non-performance arising therefrom.

4.4 Withholding of Payment:
If the Agency fails to submit complete documentation (as and when required/requested) or if verification reveals >15% discrepancy, NHM
may withhold full payment until rectification.

4.5 Last Quarter Adjustment:
Payments for the first 9 months shall be treated as provisional payments and shall be released without any deductions, except applicable
penalties, if any. Final settlement for the year shall be made in the last quarter after adjustment of pro-rata achievements and applicable
penalties, if any.

4.6 Fund Availability Clause:
Payment shall be made within 30 days of verification, subject to availability of funds from the Government of India/State
Government/District authorities. Delayed payment arising solely due to non-availability of funds shall not attract any interest liability, and
the Agency shall continue the work during such period. However, it shall be mandatory for the District/Procurement Entity to release the
payment within a maximum period of 3 (three) months from the date of post verification, failing which the Agency shall have the right to
suspend the work/services until settlement of all pending dues, without any liability or penalty on the Agency.

<!-- page 40 -->

Section IV – TERMS AND CONDITIONS
1. Use of contract documents and information
1.1 The Agency shall not, without the Procurement Entity’s prior written consent, disclose the contract or
any provision thereof or any information furnished by or on behalf of the Procurement Entity in
connection therewith, to any person other than the person(s) employed by the Agency in the
performance of the contract emanating from this Tender Document. Further, any such disclosure to
any such employed person shall be made in confidence and only so far as necessary for the purposes
of such performance for this contract.
1.2 Further, the Agency shall not, without the Procurement Entity’s prior written consent, make use of any
document or information mentioned in sub-clause 1.1 above except for the sole purpose of
performing this contract.
1.3 Except the contract issued to the Agency, every other document mentioned in sub-clause 1.1 above
shall remain the property of the Procurement Entity and, if advised by the Procurement Entity, all
copies of all such documents shall be returned to the Procurement Entity on completion of the
Agency’s performance and obligations under this contract.

2. Intellectual Property Rights
2.1. The agency shall, at all times, indemnify and keep indemnified the Procurement Entity, free of cost,
against all claims which may arise in respect of goods & services to be provided by the agency under
the contract for infringement of any intellectual property rights or any other right protected by patent,
registration of designs or trademarks. In the event of any such claim in respect of alleged breach of
patient, registered designs, trademarks etc. being made against the Procurement Entity, it shall notify
the agency of the same and the agency shall, at his own expenses take care of the same for settlement
without any liability to the Procurement Entity.

3. Insurance
3.1. The agency shall be responsible for insuring all the IT machines and equipment’s, human resource, etc.
for accident, theft, damage, burglary etc.
3.2. The Procurement Entity shall not be responsible for damages of any kind or for any
mishap/injury/accident caused to any personnel/property of the agency while performing duty as
mentioned under the contract. All liabilities, legal or monetary, arising in that eventuality shall be
borne by agency.

4. Duration of hiring of services of PPSA
4.1. The duration of contract shall be 3 (three) years from the date of commencement of services. The
performance of contract shall be reviewed annually by the committee constituted by the Procurement
Entity. The tenure may be extended for a further period of 1 or more years based on the satisfactory
performance of work done by the agency and any other conditions mutually agreed by the agency and
Procurement Entity. Any extension shall not be the right of the agency. The contract can be
terminated in case performance is rated unsatisfactory.
Category

Percentage slab

TB patients/Contact notified for verification of notification, bank account,
HIV and DM testing, DST and TPT

At least 5%

TB patients with successful treatment outcomes

At least 5%

4.2. Any performance related payments shall be adjusted in the last two months of each year.

5. Performance Review, Incentives & Penalty provisions.
5.1. The Procurement Entity will organize quarterly review of the agency. The cost of which may be borne
by the Procurement Entity.

<!-- page 41 -->

5.2. The Procurement Entity shall assess the performance of the Agency based on the Key Performance
Indicators (KPIs).
5.3. Notwithstanding, as contained otherwise, and besides above as the case may be, the penalties may be
imposed for each occurrence as per the identified Key Performance Indicators (KPIs). The applicable
penalty will be deducted from monthly/quarterly invoice.

Parameters

Applicable Penalty

Discrepancy found on verification of TB
patients notification, bank account, HIV and
DM testing, DST and TPT

Double the amount quoted by the agency per
case discovered of false information / listing on
NIKSHAY
Double the amount quoted by the agency per
case discovered of false information / listing on
NIKSHAY

Discrepancy found on verification of TB
patients with successful treatment outcomes

<!-- page 42 -->

6. Signing of the contract
6.1. The contract agreement between Procurement Entity and the agency should be executed within 21
days of the issue of the Letter of Intent (LoI) by the Procurement Entity for the concerned cluster/
district. The selected agency must have to submit the Performance Security before the execution of
the contract and
6.2. Non-fulfilment of above condition will result in cancellation of the award and forfeiture of the EMD
with consequential action if so desired.

7. Start of the services
7.1. The agency shall establish project offices, in each of the cluster/ district and recruit and depute the
human resource in full conformity to the contract, within 45 days from the date of signing of the
contract agreement with the Procurement Entity. If the services are not rolled-out within this timeline,
Procurement Entity or the authorities decided by Procurement Entity may impose a penalty of INR
10,000/- per day of delay.
7.2. If agency fails to start the services beyond 60 days, the contract may be terminated, and the selected
agency may be blacklisted and might result in forfeiture of performance security/bank guarantee to
which, the selected agency shall have no claims. In such a case, the Procurement Entity shall be at
freedom to negotiate with CS2, and then CS3… (in this order) responsive proposers for the concerned
cluster /district with their consent to enter into an agreement with the Procurement Entity, for
providing services as mentioned in the tender document, at the rate quoted by the last service
provider.

8. Sub-Contracts
The selected Agency shall not assign or sub-contract the Contract or any part thereof to any other
agency without the prior written permission of the Procurement Entity. In such an event, where the
Contract or any part thereof is sub-contracted to any other agency, it must not cause delay in initiating
operations as per contract beyond 45 days from the date of signing of the contract agreement with
the Procurement Entity.

9. Modification to Contract
The contract when executed by the parties shall constitute the entire contract between the parties in
connection with the jobs / services and shall be binding upon the parties. Modification, if any, to the
contract shall be in writing and with the consent of both the parties.

10. Income Tax Deduction at Source
Income tax deduction at source and other taxes shall be made at the prescribed rates from the
agency’s bills under the prevailing rate(s).

11. Force Majeure
11.1. Neither contracted agency will be liable in respect of failure to fulfill its obligations, if the said failure
is entirely due to Acts of God, Governmental restrictions or instructions, natural calamities or
catastrophe, epidemics or disturbances in the country.

<!-- page 43 -->

11.2. Force Majeure shall not include (i) any event which is caused by the negligence or intentional action
of a contracted agency or by or of such agency’s agents or employees, nor (ii) any event which a
diligent Agency could reasonably have been expected both to take into account at the time of being
assigned the work and avoid or overcome with utmost persistent effort in the carrying out of its
obligations hereunder.
11.3. An agency affected by an event of Force Majeure shall immediately notify the Procurement Entity
within 7 working days of such event, providing sufficient and satisfactory evidence of the nature and
cause of such event, and shall similarly give written notice of the restoration of normal conditions as
soon as possible.
11.4. The failure of an agency to fulfill any of its obligations under the work order/ Contract shall not be
considered to be a breach of, or default under the work order/ Contract insofar as such inability arises
from an event of Force Majeure, provided that the agency affected by such an event: - has taken all
precautions, due care and reasonable alternative measures in order to carry out the terms and
conditions of the work order/ Contract, and has informed the other party within 7 days from the
occurrence of such an event, including the dates of commencement and estimated cessation of such
event of Force Majeure; and the manner in which the Force Majeure event(s) affects the Party’s
obligation(s) under the work order/ Contract.

12. Termination of Contract
12.1. Any agency found to be involved in fraudulent practices (misrepresentation or omission of facts or
suppression/hiding of facts or disclosure of incomplete facts), in order to secure eligibility to the
bidding process during the submission of bid or after release of Letter of Intent(LoI) or agreement
formalization, shall be liable for punitive action amounting to blacklisting of the agency, including the
forfeiture of concerned EMD (Bid Security) and/or Performance Security also.
12.2. The Procurement Entity, without prejudice to any other contractual rights and remedies available to
it, may, by written notice of default sent to the Agency, terminate the contract in whole or in part, if
the agency fails to perform services as specified in the present contract read with the terms of the
contract agreement or any other contractual obligations within the time period specified in the
contract or for any breach of the contract, the performance security maybe forfeited and other
suitable action may also be taken against the service provider.
12.3. In the event the Procurement Entity terminates the contract in whole or in part, the Procurement
Entity may carry out risk purchase of services similar to those cancelled, with such terms and
conditions and in such manner as it deems fit and the Agency shall be liable to the Procurement Entity
for the extra expenditure, if any, incurred by the Procurement Entity for arranging such services.
12.4. In the case of the termination of contract, any unspent balance, if any shall be refunded by the
agency to the Procurement Entity.
12.5. Termination for In solvency: If the agency becomes bankrupt or otherwise insolvent, it will inform to
the Procurement Entity with the 30 days of written notice to terminate the contract. The Procurement
Entity reserves the right to terminate, without any compensation, whatsoever, to the Agency, and
Procurement Entity may forfeit the performance security.
12.6. Termination by Mutual Consent: In the event the Procurement Entity &Agency mutually agrees to
terminate the contract, either party shall give 90 days of written notice to the other party and after
the consent of both parties agreement may be terminated without any Legal or Financial Obligation on
any Party to the contract.
12.7. Termination for Force Majeure: In event that a Force Majeure event continues for 90 (ninety) days
and/or Procurement Entity or the Agency does not see any feasibility of continuing the project due to a
Force Majeure event, then Procurement Entity may, on expiry of 90 (ninety) days or at any period
before that in event of no for esee ability of project, issue a termination notice to the Agency,
terminating the Contract with immediate effect. The Agency shall be awarded 30 (thirty) days to
complete any pending activities and clear the premises provided by Procurement Entity. Payments for
works done prior to the commencement of the Force Majeure period shall be duly paid to the Agency
by Procurement Entity.

<!-- page 44 -->

13. Notices
Notice, if any, relating to the contract given by one party to the other, shall be sent in writing or by email or facsimile or post. The addresses of the parties for exchanging such notices will be the
addresses as incorporated in the contract.

14. Resolution of disputes
Any dispute or difference or claim arising out of or in relation to this contract, will be settled by
Chairperson, Procurement Entity as per the extant law of land through the competent court of law in
state under the territorial jurisdiction of concerned cluster district only.

<!-- page 45 -->

Section IV – Proposal Forms
1. Letter of Technical Proposal

Date: [insert date (as day, month and year) of Proposal Submission]
Proposal Ref. No.: [insert number of bidding process]

To: [insert complete name of Procuring Entity]

(a)

We have examined and have no reservations to the RFP Document, including Addenda issued in accordance
with instructions to Proposers;

(b)

We meet the eligibility requirements and have no Conflict of Interest in accordance with the clause;

(c)

We offer to perform the services in conformity with the RFP Document and in accordance with the Scope of
Work given in Section III;

(d)

Our Proposal shall be valid for a period fixed for the Proposal submission deadline in accordance with the
RFP Document, and it shall remain binding upon us and may be accepted at any time before the expiration
of that period;

(e)

If our Proposal is accepted, we commit to obtain a performance security in accordance with the RFP
Document;

(f)

We are not participating, as a Proposer or as a subcontractor, in more than one Proposal in this bidding
process;

(g)

We, along with any of our subcontractors, suppliers, consultants, manufacturers, or service providers for
any part of the contract, are not debarred by any procuring entity under the State Government, the Central
Government or any State Government or any Public Undertaking, Autonomous body, Authority by
whatever name called under them;

(h)

We hereby certify that we have taken steps to ensure that no person acting for us or on our behalf will
engage in any activities which is in contravention of the Code of Integrity proscribed in RFP Document;

(i)

We hereby certify that we are neither associated nor has been associated directly or indirectly with the
consultant or any other entity that has prepared the design, specifications and other documents for the
subject matter of procurement or is being proposed as Project Manager for the contract

(j)

We hereby certify that we have fulfilled our obligations to pay all such taxes as payable to the Central
Government or the State Government or any local authority;

(k)

We hereby certify that we are not insolvent, in receivership, bankrupt or being wound up, not have its
affairs administered by a court or a judicial officer, not have its business activities suspended and must not
be the subject of legal proceedings for any of the foregoing reasons;

(l)

We hereby certify that our directors and officers have not been convicted of any criminal offence related to
their professional conduct or the making of false statements or misrepresentations as to their qualifications

<!-- page 46 -->

to enter into a procurement contract within a period of three years preceding the commencement of the
procurement process, or not have been otherwise disqualified pursuant to debarment proceedings;
(m) We understand that this Proposal, together with your written acceptance thereof included in your
notification of award, shall constitute a binding contract between us, until a formal contract is prepared and
executed; and
(n)

We understand that you are not bound to accept the lowest evaluated Proposal or any other Proposal that
you may receive.

Name of the Proposer
Name of the person duly authorized to sign the Proposal
on behalf of the Proposer
Title of the person signing the Proposal
Signature of the person named above
Date signed

<!-- page 47 -->

2. Proposer Information Form
[The Proposer shall fill in this Form in accordance with the instructions indicated below. No alterations
to its format shall be permitted and no substitutions shall be accepted.]
Date: [insert date (as day, month and year) of Proposal Submission]
Proposal Ref. No.: [insert number of bidding process]

1. Proposer’s Name [insert Proposer’s legal name]
2. Proposer’s year of registration: [insert Proposer’s year of registration]
3. Proposer’s Address: [insert Proposer’s legal address]

4. Proposer’s Authorized Representative Information
Name: [insert Authorized Representative’s name]
Address: [insert Authorized Representative’s Address]
Telephone/Fax numbers: [insert Authorized Representative’s telephone/fax numbers]
Email Address: [insert Authorized Representative’s email address]
6.

Attached are copies of original documents of [check the box(es) of the attached original documents]

Self-attested copy of certificate of registration under any other law applicable under the laws of India,
Self-Attested copy of the MoA / deeds / bye-laws or such other document evidencing vision, mission,
objective and rules and regulations
Certificate from Statutory Auditor & Audited financial statements shall be submitted by the Proposer for
the stated financial years
PAN Card
GST Registration Certificate (if applicable)
GST Exemption Certificate (in any)
Copy of Income Tax Return (with computation) filed and submitted by the Proposer for three financial years
FY 2022-23, 2023-24, 2024-25.
ESI & EPF registration certificate.
MSME Registration Certificate (if applicable)
Accounting/Financial policies
Internal control policies, risk matrix and procedures
Procurement guidelines
HR and Administrative Policies
Affidavit attested by Notary Republic or sworn before Executive Magistrate
Undertaking to be submitted on a non-judicial stamp paper

<!-- page 48 -->

Self-Declaration on Company Letter Head
Proof of registration on NGO – DARPAN portal
Undertaking to be submitted on a non-judicial stamp paper

<!-- page 49 -->

3. Letter of Financial Proposal

Date: [insert date (as day, month and year) of Proposal Submission]
Proposal Ref. No.: [insert number of bidding process]

To: [Central TB Division]

(a)

We have examined and have no reservations to the RFP Document, including Addenda issued in accordance
with Instructions to Proposers;

(b)

We hereby submit Financial Proposal for total per patient cost of Rs.
and duties / GST)

(c)

The duly filled Price Schedule, in accordance with instructions given in ITP Para 12 is annexed hereto; and

(d)

We understand that you are not bound to accept the lowest evaluated Proposal or any other Proposal that
you may receive.

Name of the Proposer
Name of the person duly authorized to sign the Proposal
on behalf of the Proposer
Title of the person signing the Proposal
Signature of the person named above
Date signed

(inclusive of all taxes

<!-- page 50 -->

4(a) Form of Price Schedule for Cluster-2
A

B

C

D

E= C X D

E + GST

G

Sr.
No.

Brief Description
of Services

Indicative No.
of Patient for
Year-3

Fee per Patient
(exclusive of
taxes and
duties / GST
(Rs.)

Total contract
amount
(exclusive of
taxes and duties
/ GST)

Taxes and Duties
/ GST (payable if
contract is
awarded) as
currently
applicable

Total contract
amount
(inclusive of
taxes and
duties / GST)

I
18,750
(6250
x3
years)

4(b) Form of Price Schedule for Cluster-3
A

B

C

D

E= C X D

E + GST

G

Sr.
No.

Brief Description
of Services

Indicative No.
of Patient for
Year-3

Fee per Patient
(exclusive of
taxes and
duties / GST
(Rs.)

Total contract
amount
(exclusive of
taxes and duties
/ GST)

Taxes and Duties
/ GST (payable if
contract is
awarded) as
currently
applicable

Total contract
amount
(inclusive of
taxes and
duties / GST)

I
24,750
(8250
x3
years)

Note:1.

The Indicative No. of patient may vary as per the availability of actual patient.

Signature and seal of Proposer’s authorized signatory

<!-- page 51 -->

Annexure 1:

Proposal Covering Letter
[On the Letter head of the Proposer]
Date:
To
Mission Director
NHM JH Jharkhand]
Re: RFP for selection of service providers for working as a Patient Provider Support Agency (PPSA) for providing
Tuberculosis (TB) related services under National Tuberculosis Elimination Program (NTEP) in ............. districts
in the state of ……………….
Dear Sir / Madam,
We, the undersigned, offer for selection of service providers for working as a Patient Provider Support Agency
(PPSA) for providing Tuberculosis (TB) related services under National Tuberculosis Elimination Program (NTEP)
program in ……….. cluster/districts in the state of ………………., in the cluster/ district ......................... <Mention the
name of the cluster/ districts>, in accordance with your Request for Proposal vide Ref No ................................... dated
. .............. We are hereby submitting our Proposal for the same.
We hereby declare that all the information and statements made in this proposal are true and accept that any
misinterpretation contained in it may lead to our disqualification.
Our proposal is binding upon us and subject to the modifications resulting from project specific contract and contract
negotiations.
We understand that the Procurement Entity, may cancel the selection process at any time and that you are neither
bound to accept any proposal you receive nor to select the agency, without incurring any liability to the Proposers.
We acknowledge the right of Procurement Entity to reject our Proposal without assigning any reason or otherwise
and hereby waive our right to challenge the same on any account whatsoever.
We shall make available to Procurement Entity any additional information it may find necessary or require
supplementing or authenticate the proposal.
We certify that in the last three years, we have neither failed to perform on any contract, as evidenced by imposition
of a penalty or a judicial pronouncement or arbitration award, nor been expelled from any project or contract nor
have had any contract terminated for breach on our part.
We declare that:
a.
b.
c.

We have examined and have no reservations to the RFP Documents, including any Addendum issued by
Procurement Entity;
We have not directly or indirectly or through an executive engaged or indulged in any corrupt practice,
fraudulent practice, coercive practice, undesirable practice, or restrictive practice; and
We hereby certify that we have taken steps to ensure that no person acting for us or on our behalf will engage in
any corrupt practice, fraudulent practice, coercive practice, undesirable practice or restrictive practice.

<!-- page 52 -->

d.
e.
f.

g.

h.
i.
j.
k.

We declare that We/any member of the Agency, are/is not a Member of a/any other company applying for this
RFP.
We certify that in this regard that we have not been convicted by a court of law.
We hereby irrevocably waive any right which we may have at any stage at law or howsoever otherwise arising to
challenge or question any decision taken by Procurement Entity in connection with the selection of agency or in
connection with the selection process itself in respect of this RFP.
We agree and understand that the proposal is subject to the provisions of the RFP document. In no case, I/We
shall have any claim or right of whatsoever nature if the assignment is not awarded to me/us or our proposal is
not opened.
We agree to keep this offer valid for one year from the proposal due date specified in RFP.
The Power of Attorney (PoA) in favor of the authorized signatory to sign and submit this Proposal and
documents is also attached herewith.
In the event of my/our Agency being selected, I/We agree to enter into a contract for the services awarded to us
by the Procurement Entity.
We agree and undertake to abide by all the terms and conditions of the RFP document. In witness thereof, I/we
submit this proposal under and in accordance with the terms of the RFP document.
Yours sincerely,
Authorized Signature [In full and initials]:
Name and Title of Signatory:
Name of Company:

<!-- page 53 -->

Annexure 2:

Authorization Letter for Signing of Proposal
(On Non – judicial stamp paper of Rs .......... /- duly attested by notary public)
POWER OF ATTORNEY

Know all men by these present, we
(name and address of the registered office of
the Lead Proposer) do hereby constitute, appoint and authorize Ms. / Mr.
R/o (
address of residence) who is presently employed with us and holding the position of
as our authorized representative, to do in our name and on our
behalf, all such acts, deeds and things necessary in connection with or incidental to the Proposal of the
firm/ organization,
for “Selection of service providers for working as a Patient
Provider Support Agency (PPSA) for providing Tuberculosis (TB) related services under National
Tuberculosis Elimination Program (NTEP) in ……… clusters / districts in the state of …………” (the
“Project”), including signing and submission of all documents and providing information / responses to
Procurement Entity, representing us in all matters in connection with our Proposal for the said Project.

We hereby agree to ratify all acts, deeds and things lawfully done by our said attorney pursuant to this
Power of Attorney and that all acts, deeds and things done by our aforesaid attorney shall and shall
always be deemed to have been done by us. Dated this of ........... month of 2026.

For …………………………………………..
(Name, Designation, and address)

Accepted
… ..................... (Signature)
(Name , title and address of the Attorney)

Date:
Note:
(i) The mode of execution of the Power of Attorney (PoA) should be in accordance with the
procedure , if any, laid down, by the applicable law and the charter documents of the executants

<!-- page 54 -->

and when it is so required the same should be under common seal affixed in accordance with the
required procedure.
(ii) In case, an authorized director of the Proposer/agency signs the Proposal, a certified copy of the
appropriate resolution/document conveying such authority may be enclosed in lieu of the Power
of Attorney (PoA).

<!-- page 55 -->

Annexure 3:

Particulars Of The Proposer’s Organisation
Name and full address of the organization
Details of Registered Office
Address
Telephone No(s)
Fax No(s)
E-mail address(Official):
Organization gem portal: Year of
Incorporation:
Turn Over of the Organization (in lacs)
2022-23:
2023-24:
2024-25:
Income Tax Registration number (PAN)
Goods and Services Tax(GSTN):
Type of organization (Company/Society/Trust)
Registered in Planning Commission Portal for NGOs/NGO Darpan or
Any GoI Portal
Name and addresses and designation of the persons who will
represent the Proposer while dealing with the Procurement Entity
(Attach letter of authority)
Has the organization blacklisted by any state or central government
entity or any of its undertakings
(Authorized Signatory)
Name:
Designation & Authority:
Place:
Date:
Stamp:

<!-- page 56 -->

Annexure 4:

Declaration by Proposer
Format for Affidavit Notary attested or sworn before executive magistrate certifying that Entity/Promoter(s) /
Director(s)/Members of Entity are not Blacklisted (On a Stamp Paper of INR 100)
Affidavit
I, M/s ..................................... , (the names and addresses of the registered office) hereby certify and confirm that we
or any of our promoter(s) / director(s) are not blacklisted/barred/convicted by any court of law for any criminal or
civil offences/declared ineligible by Delhi State Health Mission/DHS or any other entity of GoI or any entity of state
government or Govt. of India, or any local self-government body or public undertaking in India for participating in
future Proposals for unsatisfactory performance, corrupt, fraudulent or any other unethical business practices or for
any other reasons, as on date of submission ( upload) of online Proposal document.
And that we are hereby, declaring all ongoing litigations (if any) where our promoter(s)/director(s) are involved, and
as mentioned below:

1.
2.
3.
4.

We further confirm that we are aware that, our Application for the captioned Project would be liable for rejection in
case any material misrepresentation is made or discovered at any stage of the Bidding Process or thereafter during
the contract period and the amounts paid till date shall stand forfeited without further intimation.

Dated this............................................. Day of .......................... , 2026
Name of the Proposer/agency…………………………
Signature of the Authorized Person:……………….
Name of the Authorized Person:……………
Designation of the Authorized Person:……………….

<!-- page 57 -->

Annexure 5:

Affidavit for experienced manpower by the agency/Proposer
(On Non – judicial stamp paper of Rs.100/- duly attested by notary public/executive magistrate)

We ………………………………………….< Mention the name of the agency/Proposer>, having its registered office at
………………………………………………………………………………………………………………………………………………………………………………..<
Mention the registered office address>, have the sufficient number of mid-level (more than 3 years experienced)
supervisory staff of working in Health/ any Central / State Govt Organization / PSU, as required for working as a
Patient Provider Support Agency (PPSA) for providing Tuberculosis (TB) related services under National Tuberculosis
Elimination Program (NTEP) program in the concerned district namely,………………………..< Mention the name of the
district (s), in the state of ……………………...
We are listing the name of manpower with more than 3 years’ experience working in any Central / State Govt
Organization / PSU, working with us:
S.No

Place of
Contract

Name
of
Client,
Contact
details (email
ID and Phone
number)

Year
of
commencement
of the services of
conducting Test
pursuant to the
work
order/contract.

Year
of
end
of
contract (if
any)

Thematic
Area
(TB/HIV/primary
education etc)

Name of the Proposer/agency…………………………
Signature of the Authorized Person:……………….
Name of the Authorized Person:……………
Designation of the Authorized Person:……………….
Enclosed: Curriculum Vitae/Resume of the professionals mentioned in the affidavit.

<!-- page 58 -->

Annexure 6:

Unconditional Undertaking
(Duly signed scanned copy to be attached with technical Proposal)
To
[Mission Director
NHM, Jharkhand]

Madam/Sir,
ACCEPTANCE OF PROCUREMENT ENTITY RFP CONDITIONS
1.

The RFP document for the work of “Selection of service providers for working as a Patient Provider
Support Agency (PPSA) for providing Tuberculosis (TB) related services under National Tuberculosis
Elimination Program (NTEP) in …… cluster/ districts in the state of ………” has been published by
Procurement Entity and I/We hereby certify that I / we have inspected and read the entire terms and
conditions of the RFP document downloaded from gem portal, i.e.,
… .......................................... and I / We shall abide by the conditions / clauses contained therein.

2.

I / We hereby unconditionally accept the RFP conditions of Procurement Entity RFP document in its
entirety for the above work.
The contents of RFP document have been noted wherein it is clarified that after unconditionally
accepting the RFP conditions in its entirety, it is not permissible to put any remarks / conditions in the
price Proposal and the same has been followed in the present case. In case, this provision of the RFP is
found violated after opening price Proposal, I / We agree that the proposal shall be rejected.
‘That I / We declare that I / we have not paid and will not pay any bribe or approach for any influence
on any officer of Procurement Entity during the course of procurement or execution, and further if any
officer of Procurement Entity asks for bribe / gratification, I / We will immediately report it to the
Appropriate Authority of Procurement Entity.

3.

4.

Date :
(Signature of the Proposer with rubber stamp)

Yours faithfully,

<!-- page 59 -->

Annexure 7:

Statement of experience implementing health and/or social sector program
Experience of implementing health and/or social sector program with any Central / State Govt
Organization / PSU, in any three years of the last five Financial Years (2020-21, 2021-22,2022-23, 2023-24
& 2024-25) in following format.(Add rows if required)
Experience of implementing health and/or social sector program
S.
N.

Name of
the any
Central /
State
Govt
Organiza
tion /
PSU

Client
Contact
Details
:Name,
Designation,
Address,
Phone No.
& E-mail Id

Project/
Assignment
name
Agreement
No. & date

Description
of work/
services
undertaken/
provided

Project
Area /
Location

Team Size /
No. of
manpower
engaged

Agreem
ent price
of
Project /
assignm
ent (In
Rs Lakh)

Date of
commen
cement

Date of
comple
tion

Total
Period of
contract
(in
months)

Current
status of
the
project /
assignm
ent
(Complet
ed /
Ongoing)

1
2

Note : Please enclose proof of experience and Client’s Certificate on satisfactory completion of
assignment from clients
a) Work order / Contract document /MOU/ Agreement and
b) Client’s Certificate on satisfactory completion and/or satisfactory progress report of project
mentioning the details stated in the above experience statement

Document
submitted
as proof of
experience
(Work order
/ Contract
document
/MOU/
Agreement/
Performanc
e
certificates
or
experience
certificates
issued by
client)
mentioning
the details
stated here

<!-- page 60 -->

Annexure 8:

Statement of experience of working in TB program

Experience of working in TB program with any Central / State Govt Organization / PSU in any two years of
the last five Financial Years (2020-21, 2021-22,2022-23, 2023-24 & 2024-25)in following format.(Add rows
if required)

Experience of working in TB program
S.
N.

Name of
the any
Central /
State
Govt
Organiz
ation /
PSU

Client
Contact
Details
:Name,
Designation,
Address,
Phone No.
& E-mail Id

Project/
Assignment
name
Agreement
No. & date

Description
of work/
services
undertaken/
provided

Project
Area /
Location

Team Size /
No. of
manpower
engaged

Agreem
ent price
of
Project /
assignm
ent (In
Rs Lakh)

Date of
commen
cement

Date of
comple
tion

Total
Period of
contract
(in
months)

1
2

Note: Please submit proof of experience and Client’s Certificate on satisfactory completion of
assignment from clients
a) Work order / Contract document /MOU/ Agreement and
b) Client’s Certificate on satisfactory completion and/or satisfactory progress report of project
mentioning the details stated in the above experience statement

Current
status of
the
project /
assignm
ent
(Complet
ed /
Ongoing)

Document
submitted
as proof of
experience
(Work order
/ Contract
document
/MOU/
Agreement/
Performanc
e
certificates
or
experience
certificates
issued by
client)
mentioning
the details
stated here

<!-- page 61 -->

Annexure 9:

Proforma For Bank Guarantee For Performance Security
(To be stamped in accordance with Stamp Act)
Ref: Bank Guarantee No.:

Date:

To
[Mission Director
NHM, Jharkhand]
Dear Sir,

WHEREAS ............................(Name of Proposer) hereinafter called "the Proposer", has been identified and selected
for the district of ...................... (Mention the name of the district), and has undertaken, in pursuance of Contract
dated ...... 2026 (hereinafter referred to as “the Contract") to implement the [Request for Proposal for selection of
service providers for working as a Patient Provider Support Agency (PPSA) for providing Tuberculosis (TB) related
services under National Tuberculosis Elimination Program (NTEP) program in …….. districts in the state of
…………………………...
AND WHEREAS it has been stipulated in the said Contract that the Proposer shall furnish a Bank Guarantee ("the
Guarantee") from a Scheduled Bank for the services/performance of the [Request for Proposal for selection of service
providers for working as a Patient Provider Support Agency (PPSA) for providing Tuberculosis (TB) related services
under National Tuberculosis Elimination Program (NTEP) program in ………. Cluster/ Districts in the state of
……………………. as per the contract. WHEREAS we ("the Bank", which expression shall be deemed to include it
successors and permitted assigns) have agreed to give the Procurement Entity the Guarantee:
THEREFORE, the Bank hereby agrees and affirms as follows:
1.

The Bank hereby irrevocably and unconditionally guarantees the payment of ............... , to the Procurement
Entity under the terms of their contract dated on account of full or partial non-performance / nonimplementation and/ or delayed and/ or defective performance / implementation. Provided, however, that
the maximum liability of the Bank towards Procurement Entity, under this Guarantee shall not, under any
circumstances, exceed in aggregate.
2. In pursuance of this Guarantee, the Bank shall, immediately upon the receipt of a written notice from
Procurement Entity) stating full or partial non-implementation and/ or delayed and or defective
implementation, which shall not be called in question, in that behalf and without delay/demur or set off,
pay to Procurement Entity any and all sums demanded by Procurement Entity under the said demand
notice, subject to the maximum limits specified in Clause 1 above. A notice from Procurement Entity to the
Bank shall be sent by Registered Post (Acknowledgement Due) at the following address: Attention
Mr ........................... (Mention the official address of the Proposer)
3. This Guarantee shall come into effect immediately upon execution and shall remain in force for a period of
38 months from the date of its execution.
4. The liability of the Bank under the terms of this Guarantee shall not, in any manner whatsoever, be
modified, discharged, or otherwise affected by:
a. any change or amendment to the terms and conditions of the Contract or the execution of any
further contracts/Agreements.
b. any breach or non-compliance by the Proposer with any of the terms and conditions of any
contracts/credit arrangement, present or future, between Proposer and the Bank.

<!-- page 62 -->

5.

6.

7.

The Bank also agrees that Procurement Entity at its option shall be entitled to enforce this Guarantee
against the Bank as a Principal Debtor, in the first instance without proceeding against agency and not
withstanding any security or other guarantee that Procurement Entity may have in relation to the
Proposer’s liabilities.
The Bank shall not be released of its obligations under these presents by reason of any act of omission or
commission on the part of Procurement Entity or any other indulgence shown by Procurement Entity or by
any other matter or thing whatsoever which under law would, but for this provision, have the effect of
relieving the Bank.
This guarantee shall be governed by the laws of India and only the courts of Delhi, shall have exclusive
jurisdiction in the adjudication of any dispute which may arise hereunder.

Dated this the ………………. Day of........................ 2026

Witness

(Signature)

(Official Address)

(Signature) (Name)

(Name) Bank Rubber Stamp

Designation with Bank

<!-- page 63 -->

Annexure 10:

Guidance documents on performance linked payment plan
1.

The information mentioned in this section, is for the purpose of bringing greater understanding on the
performance linked payment plan.

2.

We have taken the following assumptions, namely:
2.1 Target no. of patients (from private sector): 1,000 (used to make the calculations easier)
2.2 Price quoted by the bidder for the complete services till the treatment: 1,000 (used to make the
calculations easier)
2.3 Total expected payment from the project (Rs.): 10,00,000 (Ten lakh rupees) (Multiplied values in 2.1 to
the values in 2.2)
2.4 For making the calculations easier, we have not considered any penalties or taxes in the calculations.
2.5 Considering the performance evaluation criteria:
Sr No
1
2
3
4
5
6

Parameters
Weightage
Number of TB patients 25%
notified
Validated bank account 15%
details
UDST
20%
HIV and DM Testing
10%
Contact
tracing
and 5%
chemoprophylaxis (TPT)
Successful Outcome
25%

Targets
80%

Of the private sector target

80%

Of the patients notified

70%
80%
80%

Of the patients notified
Of the patients notified
Of the patients notified

85%

Of the patients notified

2.6 We have assumed that we have received the data for each of the parameters (Notification, Bank
Details, DST, HIV +DM, TPT and Outcome) via NIKSHAY of all the notified patients for the year 2019.
2.7 Methodology of Pro-rata Calculations:
2.7.1

Considering the price quoted as Rs 1,000, and the performance evaluation criteria mentioned
in sub-clause 2.4, we have made this table: -

Sr No

Parameters

Weight age

1
2
3
4

Number of TB patients notified
Validated bank account details
UDST
HIV and DM Testing
Contact tracing and chemoprophylaxis
(TPT)
Successful Outcome

25%
15%
20%
10%

Equivalent value in
Rs.
250
150
200
100

5%

50

25%

250

5
6

In the case of notifications, the target is kept at 80% of the private sector target notified i.e., 1000 *80%
= 800. Therefore, if the agency achieves 800 or more notifications in the year, then the calculated
payment would be 25%*1000 = Rs.250 per patient notified. However, if the agency, achieves less than
800 notifications (i.e., 80% of the private sector target, here 500 notifications for example), then the
pro-rata weightage may be calculated as [(initial weightage/notification target %)*notification
achievement %] i..e [(25%/80%)*50%] = 15.62%. Hence the amount paid per patient may be

<!-- page 64 -->

15.62%*1000 = Rs. 156.20 per patient. (Note the calculations may be rounded up to maximum of 2
places of decimal.)
2.8 Understanding payment mechanism via cases representing agencies performance in a year’s time:
Case 1 : Achieved notification targets but didn’t meet other targets (for Bank details, DST, HIV+DM,
TPT & Outcome)
M
3

M
4

M
5

M
6

M
8

M
9

82

85

79

91

86

54

66

60

59

58

39

41

32

30

33

53

61

54

66

60

25

36

39

41

32

55

53

61

54

66

SI

Parameters

M1

M2

1

Notification

84

83

82

80

90

70

2

Bank details

52

56

55

53

61

3

UDST

35

30

25

36

4

HIV + DM

52

56

55

5

TPT

35

30

6

Outcome

52

56

M
7

M
10

M1
1

M
12

Total

Achievemen
Performance
ts

88

1000

100%

66

60

700

70%

Shortfall

38

31

30

400

40%

Shortfall

59

58

66

60

700

70%

Shortfall

30

33

38

31

30

400

40%

Shortfall

60

59

58

66

60

700

70%

Shortfall

Overachieved

(Note: For a patient notified in a particular quarter, the payments for parameters like DST, Bank details, HIV +DM
and Outcome may be made in subsequent quarters based on the actual achievements)
Paramet
ers

M
1

M
2

M
3

M
4

M
5

M
6

M
7

M
8

M
9

M
10

M
11

M
12

Total

Notificat 262.
ion
50

259.
38

256.
25

250.
00

281.
25

218.
75

256.
25

265.
63

246.
88

284.
38

268.
75

275.
00

3,125.
00

Bank
details

97.5
0

105.
00

103.
13

99.3
8

114.
38

101.
25

123.
75

112.
50

110.
63

108.
75

123.
75

112.
50

1,312.
50

UDST

100.
00

85.7
1

71.4
3

102.
86

111.
43

117.
14

91.4
3

85.7
1

94.2
9

108.
57

88.5
7

85.7
1

1,142.
86

HIV +
DM

65.0
0

70.0
0

68.7
5

66.2
5

76.2
5

67.5
0

82.5
0

75.0
0

73.7
5

72.5
0

82.5
0

75.0
0

875.0
0

TPT

21.8
8

18.7
5

15.6
3

22.5
0

24.3
8

25.6
3

20.0
0

18.7
5

20.6
3

23.7
5

19.3
8

18.7
5

250.0
0

Outcom
e

152.
94

164.
71

161.
76

155.
88

179.
41

158.
82

194.
12

176.
47

173.
53

170.
59

194.
12

176.
47

2,058.
82

Indicativ 699.
e payout 82

703.
55

676.
94

696.
86

787.
09

689.
09

768.
05

734.
06

719.
69

768.
53

777.
06

743.
43

8,764.
18

Achievem
ents

Calculation
logic
Rs 250 x
notificatio
n
achievem
ents
Rs 150 x
bank
details
achievem
ents
Rs 200 x
DST
achievem
ents
Rs 100 x
HIV +DM
achievem
ents
Rs 50 x
TPT
achievem
ents
Rs 250 x
Outcome
achievem
ents
