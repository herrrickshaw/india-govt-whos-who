---
doc_id: "bc794c1eeb4cc9ee"
source_url: "https://cm.jharkhand.gov.in/sites/default/files/Covid_Notification_2024-11/Press_Release_2-29-10-2021.pdf"
ministry: "Chief Minister's Office, Jharkhand"
title: "Download PDF"
date: ""
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "2157b3c003cf783f"
---

<!-- page 1 -->

मुख्यमंत्री सचिवालय
प्रेस ववज्ञप्ति
रांिी,

: 29/10/2021

- 540/2021

29

2021
,

=========================
ज

ग

/

:-

आ

=======================

आज
ज

आ

-19

<!-- page 2 -->

1.

500

2.

500

,

3. 500

4.

ए

50%

ए
ए

प
/

प ए

प

,

प

औ

5.
6.

,

7.10

ए

,
ऊप

ए

8.

, प

9.

ए

10.

प

12.

-

13.

प

प

ई

प

11.
ई

औ

प

प

प

,

ठ प

प

प

ई

ए
प

ई

प

50%
प

प

,

<!-- page 3 -->

14.

ई

प

ए

आ
,

###

प

ग

ग
ग

, आ

ग
,

आ

=======================
#Team PRD(CMO)

,

ज

,
,

,
ज
,

ग
