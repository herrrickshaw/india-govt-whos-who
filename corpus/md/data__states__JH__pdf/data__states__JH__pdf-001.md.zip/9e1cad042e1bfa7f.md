---
doc_id: "9e1cad042e1bfa7f"
source_url: "https://jcsti.jharkhand.gov.in/document/NOTICE_NOTIFICATION/Notice-Hindi.pdf"
ministry: "Jharkhand Council on Science, Technology and Innovation"
title: "View"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "71b7ffe2dec00e89"
---

<!-- page 1 -->

lkbZal flVh ifjlj] fpjkSnh] eksjkcknh] jkWph] >kj[k.M&834008

foKku ds ckjs esa fnypLi rF;] ge vius nSfud thou esa ftu phtksa dk mi;ksx djrs gSa os dSls dke
djrh gSa] >kj[kaM ds lalk/ku] dksf'kdkvksa esa vaxd dSls dk;Z djrs gSa] tyok;q ifjorZu vkSj varfj{k esa
çdk'k dh ;k=k ds ckjs esa jkspd rF; tkuus ds fy, vius ifjokj vkSj nksLrksa ds lkFk jkaph foKku
dsaæ vkSj ojkgfefgj rkjkeaMy dk nkSjk djsaA
gjs&Hkjs cxhps esa j[kh gekjh çn'kZfu;ksa ds lkFk [ksyrs gq, foKku dk Hkh vkuan ysaA ojkgfefgj
rkjkeaMy esa gekjs xzgksa dks le>us ds fy, “To Worlds Beyond” ij ,d rkjkeaMy 'kks ns[ksaA
lkbal ikdZ] Mk;uklksj ikdZ] dkj ikfdaZx vkfn
>kj[k.M ds lalk/ku] dks;yk [knku] tyok;q ifjorZu] çdk'k dh ;k=k] çdk'k la'ys"k.k] euksjatd
foKku] phtsa dSls dke djrh gSa] cPpksa dk dksuk ij çn'kZfu;kaA

rkjkeaMy 'kks “To Worlds Beyond” ¼vof/k 28 feuV½ vkSj varfj{k ds bfrgkl ij çn'kZuh

ços'k 'kqYd % #0 20@& çfr O;fä ¼o;Ld½
ços'k 'kqYd % #0 10@& çfr O;fä ¼cPps] vk;q 3&12 o"kZ ds chp½
ços'k 'kqYd % U;wure 25 Nk=ksa ds lewg esa Ldwyh cPpksa ds fy, çfr O;fä 10 #i;s
rkjkeaMy 'kks ds fy, ços'k 'kqYd % #0 50@& çfr O;fä ¼o;Ld½
rkjkeaMy 'kks ds fy, ços'k 'kqYd % #0 30@& çfr O;fä ¼cPps½
rkjkeaMy 'kks ds fy, ços'k 'kqYd % #0 20@& çfr O;fä ¼U;wure 25 Nk=ksa ds lewg esa Ldwyh cPps½
2 ifg;k okgu & #0 10@& çfr ;wfuV
4 ifg;k okgu & #0 20@& çfr ;wfuV
cl & #0 40@& çfr ;wfuV
g0@&
dk;Zikyd funs'kd
