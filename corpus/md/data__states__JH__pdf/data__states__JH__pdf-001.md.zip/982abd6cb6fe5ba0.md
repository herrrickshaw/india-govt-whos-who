---
doc_id: "982abd6cb6fe5ba0"
source_url: "https://cdn.s3waas.gov.in/s3ed265bc903a5a097f61d3ec064d96d2e/uploads/2026/03/17738351983430.pdf"
ministry: "Hazaribagh"
title: "Tender (1 MB)"
date: ""
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "950a919d93c8cf5a"
---

<!-- page 1 -->

Tender for the Request for Empanelment of Reputed Agencies
for Supply & Installation of Post-Harvest Management
Components under the Scheme

^^d`f"k fu;kZr ,oa d`f"k foi.ku&lg&iksLV gkosZLV vk/kkjHkwr lajpuk dk
fodkl** of Department of Horticulture, Government of
Jharkhand for Hazaribag District

Office of District Horticulture Officer, Hazaribag
Department of Agriculture, Animal Husbandry & Cooperative Government of Jharkhand
Shankarpur, Barkagaon Road, Hazaribag-825301

Short Term Tender Notice for RFE
Page | 1

<!-- page 2 -->

<!-- page 3 -->

Office of District Horticulture Officer, Hazaribag
Department of Agriculture, Animal Husbandry & Cooperative Government of Jharkhand
Shankarpur, Barkagaon Road, Hazaribag-825301

Tender for the Request for Empanelment for Reputed Agencies for
Supply & Installation of Post-Harvest Management Components under
the Scheme ^^d`f"k fu;kZr ,oa d`f"k foi.ku&lg&iksLV gkosZLV vk/kkjHkwr lajpuk dk
fodkl**of Department of Horticulture, Government of Jharkhand for
Hazaribag districts.
Office of District Horticulture Officer, Hazaribag is the nodal agency for the implementation of the
scheme d`f"k fu;kZr ,oa d`f"k foi.ku&lg&iksLV gkosZLV vk/kkjHkwr lajpuk dk fodkl” in the district. Under this
scheme, 70% subsidy will be given by the government and the rest 30% will be borne by the beneficiary
himself, and whereas 95% subsidy will be given by the government for schedule caste/tribe &
economically poor and in that case only the rest 5% will be borne by the beneficiary himself. The
Office of District Horticulture Officer, Hazaribag will not be liable for ensuring the payment of the
beneficiary's share to the respective agency. Under the scheme the quantity of the items will be variable,
since it will depend on the availability of eligible beneficiaries. Since it is not the direct procurement
or purchase of goods by the department, the department is only liable to release the subsidy part of the
items on completion of the work, but to safeguard the interest of the beneficiary, Office of the District
Horticulture Officer, Hazaribag invites a short term tender for the empanelment of technically sound,
reputed manufacturing agencies for the supply and installation of various components of post-harvest
management at a competitive L1 rate as decided through this tender. Since the beneficiary’s share is
also involved in the execution of the work, the beneficiaries will be free to select any agency from the
list of empaneled agencies.
Area

Nature of work

Supply and installation of various components To supply & install the various components of the
of under the scheme asper the availability of the Post-Harvest Management as per the availability of
eligible beneficiary in light of the sanction the eligible beneficiary and their choice of selecting
order issued by the department from time to the agency at a defined time and location.
time.
i.

Reputed manufacturing agencies (hereinafter referred to as “Bidders”) are required to submit
only one application for supply and installation of the various components of the Post-Harvest
Management as mentioned in the tender (RFE) documents under the scheme.

ii.

The bidder can obtain the tender document from the office of the District Horticulture Officer,
Hazaribag and read carefully before final submission of the required document.

iii.

Arrange all the necessary documents of the bid proposal. Number (page) them in order, signed
and submit the hard copy of the bid in a sealed envelope at the Office of the District Horticulture
Officer, Hazaribag before the due date and time according to the respective eligibility
conditions. Fill up all the necessary information and submit the documents.
Page | 3

<!-- page 4 -->

iv. Bidders eligible as per the qualifying conditions will be shortlisted based on the information

provided by them.
v.

Before final submission, check fulfilment of all necessary conditions and document carefully.

vi. Pay the required EMD as defined in the tender document, and mention the details in the

submitted tender also.
vii. Every page of the Bid document must be self-attested by the bidder himself or by the authorized

personnel.

Page | 4

<!-- page 5 -->

DISCLAIMER
1. Though adequate care has been taken while issuing this RFE document, the applicant
agency/firm should satisfy himself that the document is complete in all respects. Intimation of
any discrepancy shall be given to this office (as mentioned below) immediately. If no intimation
is received by this office within 3 days from the date of commencement of the RFE bid
documents, then this office shall consider that the document received by the Bidder is complete
in all respects and that the bidder is satisfied that the RFE bid document is complete in all
respect.
2. Office of The District Horticulture Officer, Hazaribag reserves the right to change any or all of
the provision of this RFE bid documents before due date of submission. Such changes would
be intimated to all parties procuring this RFE bid document before date of submission.
3. Office of The District Horticulture Officer, Hazaribag reserves the right to reject any or the
entire bid without assigning any reason whatsoever. No correspondence will be entertained on
this account.
4. The information in this bid document has been prepared to assist the firm/s in preparing the
non-binding tender and it is clarified that: i. It does not constitute an invitation to offer or an offer in relation to the transaction.
ii. This document does not constitute any contract or agreement of any kind whatsoever.
iii. Neither the information in this document nor any other written or oral information in
relation to the requirement or otherwise is intended to form the basis of or the inducement
for any investment activity or any decision to enter into any contract or arrangement in
relation to the transition and should not be relied on as such. Neither Office of District of
Horticulture Officer, Hazaribag nor the employees or advisors shall be liable to any
interested party or any entity under any law including the law of contract, tort, the
principle of restitution or unjust enrichment or otherwise for any loss, expenses or damage
which may arise, or be incurred, or suffered, in connection with this document, or any
matter that may be deemed to form part of this document, or any other information
supplied by or on behalf of, Office of District of Horticulture Officer, Hazaribag or the
employees or advisors or otherwise arising in any way from the selection process
mentioned herein.
iv. Failure to provide information that is essential to evaluate the applicant’s qualifications or
substantiation of the information supplied, shall result in disqualification of the applicant.

District Horticulture Officer,
Hazaribag.

Page | 5

<!-- page 6 -->

Contents
Contents
SECTIONI: BACKGROUND
SECTIONII: OBJECTIVE & SCOPE OF WORK
SECTIONIII: ELIGIBILITY CRITERIA
3.1General Eligibility
3.2TechnicalEligibility
3.3Consortium
3.4 List of documents to be submitted aspart of response to TENDER
3.5Disqualification
SECTIONIV-EVALUATION AND SELE CTIONPROCEDURE
4.1Evaluationprocess
4.2Selection
SECTIONV: TERMS AND CONDITIONS OF AGREEMENT
5.1Nativity
5.2Relationship
5.3 Right to rejection and Right to annulment
5.4Noobligation
5.5Confidentiality
5.6PeriodofSelection
5.7Indemnity
5.8Onlyone application
5.9Amendment
5.10Disclaimer
5.11BindingClause
5.12bidder’scodeofIntegrity
5.13CodeofIntegrityforProcurementEntity
5.14Agency’s Obligation
5.15 Conflictof Interest
5.16Non-DisclosureAgreement
5.17IntellectualPropertyRights
5.18Arbitration
5.20ApplicableLaw
Annexure I: Application Format for Empanelment
Annexure II: Minimum Required Documents for Technical Eligibility
Annexure III: Format of Authority Letter
Annexure IV: Financial Bid (BOQ)
Annexure V: Responsibility of Material Supplier Whom Work is Awarded
Annexure VI: Declaration
Annexure VII: Declaration
Annexure VIII: Tentative Project Cost and List of Items
Annexure IX: Affidavit for Price Fall
Annexure X: Technical Specifications of Items

Page Number
7
7-8
8
8-16
17-18
18
18
18-19
19
19
19
20
20
20
20
20
20
20
20-21
21
21
21-22
22
22
22-23
23
23
23-24
24
24
24
25
26
27
28
29
30
31
32
33
34-40
Page | 6

<!-- page 7 -->

Section I: Background of the Scheme
Jharkhand is located between 21˚ to 24˚N latitude and 84˚ to 87˚E longitude with elevation range
between450-1000m. Above sea level. Thus, the plateauendowed with varying climatic condition
suitable for growing large number of horticulture crops. Horticulture in this region is largely a
backyard practice in spite of the excellent soil and climatic conditions. Different kinds of fruits
and vegetables crops are grown in Jharkhand considering the agro-climatic suitability and
prospects. But post-harvest losses in Jharkhand are significant (15 to 20% as estimated),
primarily driven by poor infrastructure leading to substantial quality and quantity loss in
perishables vegetables and fruits, with issues stemming from inefficient harvesting, handling,
and lack of modern sorting-grading/packaging/storage/cooling facilities, requiring better postharvest management infrastructures at village level to improve farmer incomes and food security
by minimizing the post-harvest losses of vegetables and fruits. Hence to minimize the postharvest losses the Department of Horticulture, Govt. of Jharkhand has programmed to implement
various schemes for promoting the post-harvest management of horticultural crops.

Section II: Objective & Scope of Work
Scope of work includes an indicative list of works which the empaneled agencies would
be subjected to during the three years contract period.
The empaneled agency would be required to supply, erect & install the required materials
and equipment of post-harvest management at different places in the districts as per the
direction of the concerned District Horticulture Officer/officer in charge.
i.

Thespecificationofthe components installed by the empaneled agency should be
asper the tender document and technical sanctioned estimate.

ii.

The supply and installation of the required materials and equipment of post-harvest
management by the empaneled agency shall be based on requirements of
farmers/beneficiaries.

iii.

Beneficiary will be free to buy the required materials and equipment from any of
them "Empaneled Agency" to exe cute the schemes.

iv.

Noclaimwillbeentertainedafterwardsforanyincreaseinthemarketpriceorotherwise.

v.

Delivery:Theempaneledagencyshallhavetomakeavailablethematerialatthebeneficiary's site/
sale-point as identified by the District Horticulture Officer of the district. All the
charges such as octroi, packing, forwarding, freight, insurance loading and
unloading, clearance etc. will be borne by the empaneled agency.

vi.

Participation in the tender will automatically imply the acceptance, on part of the
participating bidder, of all the terms and conditions of this tender document for
empanelment.

vii.

Specification: As per tender document.

viii. The empaneled agency must demonstrate the functioning of the equipment at the

Page | 7

<!-- page 8 -->

time of supply and installation of the material to the beneficiary.
ix.

The rates of all items shall remain valid upto three years of contract period.

Section III: Eligibility Criteria
3.1GeneralEligibility
A. LANGUAGEOFTENDERSUBMISSION
The Tender must be prepared & submitted in English language only. If any document
which is not in English, it should be accompanied with translated and attested certified
in English version.
B. SUBMISSIONOF TENDER
i.

Not more than one Tender offer will be accepted from any bidder. If a bidder
participates in the Tender offer, representing more than one bid by one
organization under one or different name, then such multitude of bid shall amount
to collusive activity and appropriate action should be taken by Directorate of
Horticulture, Jharkhand under fraud and corrupt practices.

ii. Tender offer must be submitted through in hard copy only. The Part-I Technical

Bid along with earnest money in form of bank draft, bid document and all required
documents must be sealed in a envelop (first envelope)and only the Part-II
Financial Bid (Annexure – IV) in the second envelop should be sealed and then
both the envelope must be submitted in third separate bigger envelopes duly super
scribed as Part-I Technical Bid and Part-II Financial Bid, respectively and also
super scribing “Tender for the Request of Empanelment of Reputed Agencies for
Supply & Installation of Post-Harvest Management Components under the Scheme
d`f"k fu;kZr ,oa d`f"k foi.ku&lg&iksLV gkosZLV vk/kkjHkwr lajpuk dk fodkl Department of
Horticulture, Government of Jharkhand for Hazaribag districts”and addressed to
the Office of District Horticulture Officer, Shankarpur, Barkagaon Road,
Hazaribag-825301. The bidder should also super scribe on the top of the third
bigger envelope the tender notice no., date & time of opening of the bid & details
of earnest money deposited otherwise such bid will not be considered in any case
and summarily rejected without opening.
iii. The offer should be given in the prescribed format asper tender document.
iv. The submission of offer by any Bidder implies that they have read the terms and
conditions of the tender and have made themselves fully aware of the scope and
specifications of the required components of post-harvest management. Any
addition or omission to the original offer will not be entertained. In this regard the
bidder needs to give a declaration duly signed and stamped as per Annexure VI.
v. Individual signing of the offer should have valid digital signature and signing other
Page | 8

<!-- page 9 -->

related documents will attach valid acceptable proof of his authority to sign on
behalf of the Bidder as per Annexure III.
vi. The bidder should fill up the required information the Technical Bid in prescribed

formats as per Annexure I, II, III, IV, VI, VII& IX and should submit the all
relevant documents as desired, failing which the bids will be rejected.
vii. Completed tender form along with EMD can only be submitted along with the

Technical Bid, Part-I.
viii. Bidder should deposit the EMD as per the instructions specified in the tender

document.
Tenderers must submit a declaration along with the Technical Bid, in the form of an
affidavit on Rs.100/-. non-judicial stamp paper duly notarized, stating; That no other
Firm/Sister concern/Associate belonging to the same group is Participating/ submitting in
this process, (Annexure VI).
C. VALIDITYOFTHEBID
The rates quoted by the bidders shall be valid for three years period from the schedule date of
empanelment of the agencies.
D. PRESENCEOFBIDDERS
All the Bidders or their authorized representative, who respond to this notification, may
be present on the date, time, and place of opening of Technical Bids and Financial Bid,
at their own cost.
E. RATESOFFERED
i.

Rates submitted by the bidder should be firm and free from all escalations.

ii.

The bidder should quote rates F.O.R. destinations at site, inclusive of applicable
taxes, levies, duties transportations etc.

iii. Bidder should quote the rate as per the specification of the units. The prices should
be inclusive of all handling, packaging, transportation, taxes etc. if any to the point
of delivery as per the direction of officers in charge.
iv. Rates should be quoted in the format as per Annexure enclosed (Annexure IV) in
the Financial Bid.
v.

As and when Government of India or the State Government will increase the rates
of GST that will be Applicable without affecting the approved rate finalized in
bid.

F. ISSUEOFCORRIGENDUM
i.

A prospective bidder requiring any clarification on the tender documents may
submit queries in writing within three days from the date of commencement of the
RFE bid document.
Page | 9

<!-- page 10 -->

ii.

The Office of District Horticulture Officer, Hazaribag atitssole discretion may
provide response to the queries.

iii. If it feels necessary may modify the tender document by a corrigendum.
iv. Anycorrigendumshallbedeemedtobeincorporatedintothistenderdocument.
v. Any further corrigendum(s) to this tender shall be published only on the
newspaper.
G. AMENDMENTOFTENDERDOCUMENT
TENDER once submitted cannot be amended. However, for any change in the bidding
documents clause 6.7 of Jharkhand Procurement of Goods and Services manual, 2024
will be followed.
H. DEADLINEFORSUBMISSIONOFTHEBIDS
i.

The bids will be received through offline on or before schedule date & time
only.The bid document can be sent by post/courier/or by hand. In case of delivery
in person, the document may be dropped in the proposal box kept for this purpose
at the Office of District of Horticulture Officer, Hazaribag at the address
Shankarpur, Barkagaon Road, Hazaribag-825301

ii.

The Office of District of Horticulture Officer, Hazaribag reserves the rights to extend
the deadline or for making any other change in the Bid document by issuing an
amendment in this regard before the end of time and date for submission. The
District Horticulture Officer, Hazaribag also reserves the right to cancel the bid
without declaring any reason.

I. VALIDITYOF TENDER
The tender shall be effective from the date of circulation by Office of District of
Horticulture Officer, Hazaribag, valid for three years of contract period from the schedule
date of empanelment of the agencies.
J. EARNEST MONEY DEPOSIT(E.M.D.)
i.

The bidder is required to submit EMD of Rs. 2.15 Lakhs through Demand Draft,
payable at Hazaribag.

ii.

As per Jharkhand Procurement policy 2014 (amendment 2019) vide Memo No.
1342, Dated 16.07.19/ Jharkhand Procurement of Goods and Services Manual,
2024., MSEs firms shall be exempted from EMD. (Provided the
firm/organization is registered under the trade related to the tendered items only).

iii. E.M.D. of all unsuccessful Bidders will be returned. (As per clause 6.5.5 of
Jharkhand Procurement of Goods and Services Manual, 2024)
iv. E.M.D. will not carry any interest.
v.

No adjustments will be made from previously submitted EMD.
Page | 10

<!-- page 11 -->

vi. For successful bidding the bidder is required to submit EMD and Bid document
required well before the end of due submission date and time.
vii. E.M.D. of bidder will be forfeited if the Bidder at any time prior to its rejection
withdraws the bid while the bid is still valid and in case of successful Bidder,
fails to sign the agreement within the specified time limit.
K. FINANCIALBID
i. Financial bidistobe submitted asper format given in Annexure IV/(BOQ).
Financial bid should not be submitted along with technical bid in a same envelope,
if so then bid will be summarily rejected.
ii. Bidder may submit rates for all items or less items as they wish to quote but the
EMD amount will be same.
L. SECURITY DEPOST
i. The successful bidder shall furnish security deposit of 05% of Value of the
Subject matter of BID after the issue of "Letter of Intent" from the Office of
District Horticulture Officer, Hazaribag inform of DD/Bank Guarantee in favor
of District Horticulture Officer, Hazaribag payable at Hazaribag.
ii.

AsperJharkhandProcurementpolicy2014(amendment2019)videMemoNo.1342,
Dated16.07.19 MSMEs shall be required to deposit only 10% of Security
Deposit (SD). The security deposit shall be kept as a security to be pledged in
the favour of District Horticulture Officer, Hazaribag. (To get the benefit of
MSME, the firm should be registered under the relevant field to the tendered
items). No other MSME registration code will be accepted. Security Deposit will
returned only after getting satisfactory report from concerned districts.

iii. Once the successful bidder submits the security deposit then the EMD will b e
returned to the successful bidders.
iv. This security deposit shall be forfeited, in case of failure of execution of supply
as per the supply order placed time to time or supply of any substandard material
reported to be found, and agreement will be terminated, and the Bidder may be
debarred or blacklisted for submission of further rate contract.
v.

This security deposit shall be forfeited, in case of failure of execution of
supply/work as per the supply/work order placed time to time or supply of any
substandard material reported to be found or failed to supply and installation of
the tendered components on approved rate then agreement will be terminated
and the Bidder may be debarred or blacklisted for submission of further tender.

M. PURCHASEORDER&SUPPLYF.O.R.DESTINATION
i.

The concerned District Horticulture Officer will be issuing supply /work
Page | 11

<!-- page 12 -->

order on the approved rates as finalized in the tender as per the farmer’s
choice of agency. Order quantity to each empaneled agency will depend on
the farmer’s choice of selecting agency for supply and installation of the
tendered items.
ii. In any case of reporting of inferior quality, the empaneled agency will have
to take back the material at his own risk and cost.
iii. The Bidder has to deliver the requisite quantity of the required items F.O.R.
destination through District Horticulture Office as described in the order,
which can be beneficiary’s site or any other place as the case may be, with
their own mode of proper transportation, in proper shape and condition to
the consignee, within reasonable/stipulated time schedule.
iv. All the required components of Post-Harvest Management should be
supplied/installed within stipulated time as quoted in supply/work order.The
work should be done as per the quality specifications mentioned in the tender
document and in accordance with as per technically sanctioned estimate as
required. Before starting the supply/installation works the executing agencies must
sanguine about the assurance of beneficiary’s share.
v.

The authority issuing the order reserves the right to cancel whole or part of
the supply orders of those empaneled agencies, who are found to be defaulter
for delay in supply/installation. In case if delay in work occurs due to
beneficiary’s end then the agency will intimate the same to the concerned
District Horticulture Officer.

vi. The empanelled agency shall undertake to provide one year warranty after the
date of billing (i.e., repairs) against natural wear and tear (excluding the natural
calamities, vandalism and any other forced action).
vii. The empaneled firm must provide free after sales service to the farmers for
at least one year. This may include the material cost, transportation of
material and installation cost. The empaneled firm should be able to supply
spare parts up to three years if any to the farmers on cost basis after
completion of warranty period.
viii. In the event of any receipt of written complaints from the office of concerned
district horticulture officer regarding after sales service and incase of supply
of defective/substandard material, the empaneled firm shall have to rectify
the defects within a period of three months, in failure of such appropriate
penal action will be taken by the competent authority.
ix. The empaneled agencies should not sublet or assign his contract or any part of
other vendors or local suppliers.
N. PROCESS OF FINAL ISATAION OF RATES
i. After consent of parties and execution of agreement, rates will be circulated as
required.
ii. No offer will be accepted if the rates are quoted with the condition of minimum
single order of half/full truck load etc.
O. PRICEFALL CLAUSE
Page | 12

<!-- page 13 -->

i. The price charges for the offered item supplied under the contract by the bidder
shall, in no case exceed the lowest price on which the bidder sells to other parties,
private or Government bodies.
ii. If at any time during the said period, the bidders reduce the sale price of such
offered item to any other person/organization at a price lower than the price
chargeable under the contract, the bidder shall forthwith notify such reduction in
rate to Directorate of Horticulture. The price payable under the contract for the
item supplied after the date of coming into force, of such reduction in sale price
shall stand correspondingly reduced as per Jharkhand Procurement of Goods and
Services Manual 5.8.2.8
iii. District Horticulture Officer shall be entitled to recover any amount paid in
excess to the bidder in respect of sale which takes place after the reduction of
price by the Bidder.
iv. If the rate of similar products (with same specification) is found lower within the
State of Jharkhand, Office of District Horticulture Officer, Hazaribag will have
full power to recover the excess amount paid.
v. The bidders shall submitan affidavit in this regards as mentioned in AnnexureIX.
P. MODEOF PAYMENT
i.

Payment of agency Bill will be made only after getting standard report of no
objection by concerned field officers/beneficiary.

ii.

Supply/work order will be released to the empaneled agencies as per choice of
the beneficiary by the competent authority. Payment of subsidy part will be
made as per prevalent norms of the government. No interest will be payable on
the delayed payment by the competent authority.

iii. The empaneled agency will have to submit all the invoices, receipts and
challans at the office of concerned DHO/officer in charge to process the
subsidy part of the payment if any. The concerned DHO/ office in charge will
not be liable for ensuring the payment of the beneficiary's share to the
respective agency for their supply/works.
iv. District Horticulture Officer/officer in charge shall release subsidy part of the
payment against supply/completion of the work for the offered items and after
compliance of all the criteria fixed by District Horticulture Officer, Hazaribag.
Page | 13

<!-- page 14 -->

v.

All payments against the supplies/works will be made only in the name of the
agency on whom the orders for supply are issued. No payment will be made in
the name of any other person or firm.

vi.

If due to any mistake extra payment is made to the Supplier, it will be
responsibility of the supplier to point out extra payment and return to concerned
DHO. The concerned DHO will have full authority to adjust such payments
from future payments or pending bills or next bills due for payment.

Q. PROCESS TO BE CONFIDENTIAL
i.

Information relating to the process of examination, clarification, evaluation,
and comparison of bids and recommendations for the award of contract shall
not be disclosed to Bidders or any other persons not officially concerned with
such process.

ii.

Any effort by the Bidder to influence any officials of the department for
processing of bids or award decisions may result in the rejection of their bid.

R. FOR CEMAJEURE CLAUSE
Neither party shall be held responsible for the non-fulfillment of their obligations
under this agreement due to the exigency of one or more of the force majeure events,
such as but not limited to acts of God, war, flood, earthquakes, strikes, lockouts,
epidemics, riots, civil commotions provided on the occurrence and cessation of any
such event the party affected there by shall give a notice in writing to the other party
within one month of such occurrence or cessation together with the measures taken by
it to mitigate and minimize the adverse effects of such force majeure event. If the force
majeure conditions continue beyond six months, the parties shall jointly decide the
future course of action.
S. FRAUD AND CORRUPTPRACTICES:
The Office of District Horticulture Officer, Hazaribag requires all the Bidders should
observe the highest standard of ethics.
In pursuant to this policy, following has been defined. Corrupt Practice ‟means
behavior on the part of officials in the public or private sector by which they
improperly and unlawfully enrich themselves and or those close to them, or induce
others to do so, by misusing the position in which they are placed, and includes the
offering, giving, receiving, or soliciting of anything of value. “Fraudulent Practice‟
Page | 14

<!-- page 15 -->

means a misrepresentation of facts in order to influence an evaluation process of
execution to the detriment of the Government and includes collusive practice among
Bidders (prior to or after bid submission) designed to establish bid price at artificial
non-competitive level.
In such an event the Office of District of Horticulture Officer, Hazaribag shall forfeit
the EMD and debar or blacklist the BIDDER from participating in future bidding
processes of the office for a period of three years.
T. COMPENSATION OF LOSSES OCCUR REDDUETOSUBST AND
ARDDEFECTIV SUPPLY AND DEBARRING/ BLACK LISTING OF
SUPPLIER:
i. The Office of District of Horticulture Officer, Hazaribag/ DHO reserves its
right to reject the lot / stock, if any material is not found conforming to
specifications mentioned in the supply/work order or not found up to the mark
and should be replaced immediately by the supplier on receipt of intimation
from the consignee, at their own cost. In case the consignment is not replaced
as specified, the consignee may have such material removed at the supplier’s
risk and the expenses incurred being liable to be recovered from Security
Deposit, or from any sum due or which may become due to the supplier. No
responsibility shall attach to the consignee for the safe custody of material
supplied in excess and not so removed.
ii. In case the competent authority feels that the continuation of the rates under
the contract is not desirable, keeping in view the substandard supplied
Materials, the selected agency will be terminated for the same, after issuing a
notice, to explain the reason to the satisfaction of the competent authority. The
Bidders can also be debarred or blacklisted by the Office of District of
Horticulture Officer, Hazaribag, to carry any further supply of such items in
the department for a fixed period, if it is found essential in the interest of the
state.
U. TERMINATION OF CONTRACT
i. In case at any point of time bidder is found providing false information, Office
of District of Horticulture Officer, Hazaribag will not execute any rate offered
under contract (during process) or will cancel its contract and the bidder canal
so be debarred or black listed from participating in future bidding processes of
the Office of District of Horticulture Officer, Hazaribag for a period of 03
years.
ii.

The Bidder, if breaches any condition or Clause of the Contract the Office of
District of Horticulture Officer, Hazaribagis entitled to Terminate the Contract
and entitled to demand and recover the loss incurred to it due to such
termination of the Contract.
Page | 15

<!-- page 16 -->

iii.

If the Government scheme is closed or partly revised or modified, due to
incidental decision of State/Central Government or any amendment and the
proceedings of purchase is stopped or revised or modified by the Office of
District of Horticulture Officer, Hazaribag as a result of which the contract will
automatically come to an end or partly continues, the Bidder is not entitled to
demand/ receive any type of loss amount or cannot initiate any legal
proceedings against Office of District of Horticulture Officer, Hazaribag .

iv.

In case of the any of the conditions in the TENDER document are not fulfilled
by the successful bidders it shall amount deemed termination of contract,
furthermore it shall amount to Suspension/Debarment/Blacklisting of Bidder
as adopted by Office of District of Horticulture Officer, Hazaribag.

V. CONSEQUENCES OF CONSUMER FORUMAND ANY COURT OF LAW
WITH BIDDER
The bidder shall own full responsibility for the consequences arising out of consumer
forum or any court of law. In case any user approaches the Consumer Forum or any
court of law with the complaint regarding substandard of ordered material supplied
to him through the bidder.
W. JURISDICTION
In all cases of legal dispute, only the Hazaribag Courts shall be having the
jurisdiction.
All the necessary affidavit may be done through any Notary Office of Jharkhand or
other notary office of the India.
X.EXECUTIONOFAGREEMENT
The successful bidder will have to execute an agreement on Rs. 100/- non-judicial
stamp paper of required value with the Office of District of Horticulture Officer,
Hazaribag in the prescribed format.
Y.SCOPE OF SUPPLY/ WORK:The bidder has to supply offered items of Post-Harvest Managementas per the
technical specification of item mentioned in Annexure X. The bidder can apply for
one or multiple components of the tender, as per his wish.
Agency should not sublet or assign his contract or any part of it to other vendors or
local suppliers. Notwithstanding anything else contained to the contrary in this tender
Document, the Office of District of Horticulture Officer, Hazaribag, reserves the right
to cancel/withdraw/modify, fully or partially the “invitation for tender‟ or to accept /
reject one or all the tender without assigning any reason and shall bear no liability
whatsoever consequent upon such a decision.
Page | 16

<!-- page 17 -->

3.2Technical Eligibility
The bidder must be the registered entity in India, formed to carry out the business
of manufacturing, supply& sale of agriculture equipment, machinery and
prefabricated structures. The bidder must enclose a self-attested copy of the valid
company’s Certificate of Incorporation/Entity’s registration certificate etc.
ii. The bidder should furnisha self- attested copy of a valid PAN no. of income tax
department and GST registration certificate.
iii. The bidder should furnish a self-attested copy of GST return file documents of last
year 2024-25 and it should match with Audited Balance Sheet Bidder Turnover is
more than Rs 3 Crore then bidder.
iv. The bidder agency must submit their Bylaws/MoA & AoA/Partnership Deed etc.,
which are as applicable for the bidder.
v. The bidder should furnish a self-attested copy of IT Return of the last three
consecutive Financial Years 2022-23, 2023-24 and 2024-25.
vi. The bidder must have work experience in supply & installation of the minimum
total 15nos. of evaporative low energy type cold room (capacity 8MT)/climatecontrolled pre-cold unit/post-harvest pack house (Size: 6mx9m) unit in any two
years in out of the last five years for the empanelment. In proof of this, the bidder
mandatorily submits the work order along with corresponding invoice bill voucher,
concerned payment proof as shown in bank statement, e-way bill of concerned
supply and the work completion certificate. All work experience must be of
government sector/beneficiary under any government schemes whereas work
experience for bidder’s self-project under any government scheme will not be
considered.
vii. The bidder must have the average annual turnover of minimum three cores for the
last three consecutive years, F.Y. 2022-23, 2023-24 and 2024-25. The bidder must
submit the details of the audited balance sheet for these three years, certified by a
CA for each year, along with the UDIN number, which was generated during the
time of balance sheet certification. Self-attested copy of CA certified average annual
turnover certificate (with UDIN) in the relevant field of offered items for 2022-23,
2023-24 and 2024-25.
viii. The bidder should furnish a self-attested copy of a valid ISO 9001:2015 certificate
in the relevant field.
ix. The bidder must be the manufacturer, in proof of this the bidder should submit the
valid document. The bidder should be registered entity in India since last five years.
x. An undertaking (self-declaration) that the bidder is not blacklisted by a central/ state
government institution and that there has been no litigation with any government
department on account of any types of supply/service/works must be submitted as
per Annexure VII.
Note:i.

a)

If the evaluation committee feels it necessary, it may request verification of the
above documents from the issuing authority. The above-specified documents, terms
& conditions are mandatory for any bidder to qualify for selection.

b) For MSME relaxation as per Jharkhand Procurement Policy2014 (as amended vide
Page | 17

<!-- page 18 -->

memo No. 1342, dated 16.07.19). An MSME firm should produce a District
Industrial Centre verification certificate (in the relevant field) of Jharkhand for
consideration for relaxation. For the MSME claim, the firm should also have its
offices and operations in Jharkhand.
c)

Since the all work is technical in nature and it is not a purchase of the product by
the department, as here the beneficiary's share is also involved, and the beneficiaries
are free to select the agency. To safeguard the larger interest of the
beneficiaries/farmers, the empanelment of technically sound, reputed
manufacturing agencies is to be done through this tender, so that the quality
standards of the said products remain ensured without compromising quality and
specification of the product. Hence all bidders needs the requisite work experience,
turnover and need to fulfill the other technical eligibility criteria as mentioned
herein above.

d) In case of interpretation of languages, the decision of the District Horticulture
Officer, Hazaribag, will be final.

3.3 Consortium
Consortium is not allowed ; any type of joint venture, authorization and dealership, etc., are
not allowed.

3.4 List of documents to be submitted as part of the response to the tender
All documents must be properly signed and submitted with proper marking of page
number. The response to tender should be submitted in hard copy in the Office of District
Horticulture Officer, Hazaribag. Any types of documents will be not accepted for the
evaluation purpose after submission and opening of the bid.

3.5 Disqualification
District Horticulture Officer, Hazaribag may at its sole discretion and at any time during
the evaluation of application, disqualify any applicant, if the applicant:
i.

Submitted the application after the response deadline.

ii. Made misleading or false representations in the forms, statements and attachments

submitted in proof of the eligibility requirements.
iii. Exhibited a record of poor performance such as abandoning works, not properly

completing the contractual obligations, inordinately delaying completion or
financial failures, etc. in any project in the preceding three years.
iv. Submitted an application that is not accompanied by required documentation or is

non- responsive.
v. Failed to provide clarification related to, when sought.
vi. Submitted more than one application on its own, or incomplete application.
vii. Declared ineligible/blacklisted by the Government of India/State/UT government.
Page | 18

<!-- page 19 -->

Or is in litigation with government of Jharkhand during the present tender process.

SECTIONIV-EVALUATIONANDSELECTIONPROCEDURE
The District Horticulture Officer, Hazaribag will constitute a screening/evaluation Committee
to evaluate the proposals submitted. During the evaluation of the proposal Office of District
Horticulture Officer, Hazaribag may, at its discretion, ask the bidders for clarification on their
applications. The process for selection is as follows.

3.6 Evaluation Process
Scrutiny of eligibility criteria, as mentioned for responsiveness to the tender, will be done by a
screening/evaluation Committee to determine whether the documents have been properly
signed, qualification criteria fulfilled, and all relevant papers submitted. The response to the
tender not conforming to requirements will be rejected.
In the first stage, Technical Evaluation will be done based on documents submitted asper
Annexure I and Annexure II. Financial Proposal of only technically qualified bidders will be
opened in second stage.

3.7 Selection
1. Its hall be deemed that by submitting the bid, the bidder has understood the scope, the

contents of the tender document and all other relevant information pertaining to this
tender.
2. The total cost of the material including taxes, duties and all other expenses quoted by
the bidder shall be considered for financial price evaluation.
3. In the second stage, Financial Proposal of only technically qualified agencies will be
opened, for further evaluation. Rate of each component will be determined based on
L1. The technically qualified another agency who wish to work on L1 rate will also
be empaneled. This fixed price after approval of competent authority will be final
and applicable under mentioned schemes. Agencies shortlisted for empanelment will
be issued an empanelment letter and, the agency must submit its acceptance in written
to the District Horticulture Officer, Hazaribag.
4. District Horticulture Officer, Hazaribag shall not be liable for any mistake or error by
the bidder in respect of their quotes.
5. The agencies empaneled will be required to sign an agreement with Office of District
Horticulture Officer, Hazaribag, accepting the terms and conditions. After signing of
the agreement, no variation or modification in the terms of the agreement shall be
made except by written amendment signed by both parties.

SECTIONV: TERMS AND CONDITIONS OF AGREEMENT
The agency selected will have to sign an agreement with District Horticulture Officer,
Hazaribag as per prescribed format on mutually agreed terms and conditions.
Page | 19

<!-- page 20 -->

5.1 Nativity
The organization must be incorporated in India asper GOI guidelines.

5.2 Relationship
Neither party shall use the other parties name or any service or proprietary name, mark or
logo of the other party for promotional purpose without first having obtained the other
party’s prior written approval.

5.3 Right to rejection and right to annulment
Office of District Horticulture Officer, Hazaribag reserves the right to reject any request
and to annul the process and reject all such requests at any time, without thereby incurring
any liability to the affected applicant(s) or any obligation to inform the affected applicant(s)
of the grounds for such decision.

5.4 No obligation
Office of District Horticulture Officer, Hazaribag does not guarantee that any Bidders shall
be awarded any project / assignment as a result of this tender.

5.5 Confidentiality
Information relating to evaluation of application and recommendations concerning awards
shall not be disclosed to the Bidders who submitted the applications or to other persons not
officially concerned with the process. The undue use by any applicant of confidential
information related to the process may result in the rejection of their application.

5.6 Period of Selection
Office of District Horticulture Officer, Hazaribag shall empanel the agencies for a period
of three years from the schedule date of empanelment of the agencies and the duration
may be extended through mutual consent for a further period based on period icre view
to assess the performance during the specified duration at the same terms and
conditions.

5.7 Indemnity
The selected Agency will indemnify the Office of District Horticulture Officer, Hazaribag,
against all third-party claims of infringement of patent, trademark/copyright or industrial
design rights arising from the use of software/ hardware/ manpower, etc. and related
services or any part thereof. District Horticulture Officer, Hazaribag, stand indemnified
from any claims that the hired manpower may opt to have by virtue of working on the
project for whatever period.
Page | 20

<!-- page 21 -->

Office of District Horticulture Officer, Hazaribag also stand indemnified from any
compensation arising out of accidental loss of life or injury sustained by the hired
manpower while working on the project.

5.8 Only one application
An applicant can submit only one proposal on its own. If an applicant submits more than
one proposal, only one proposals shall be considered.

5.9 Amendment
At any time prior to deadline for online submission of applications, Office of District
Horticulture Officer, Hazaribag may for any reason, modify this document. The
corrigendum document shall be notified through website and such amendments shall be
binding on all Bidders.

5.10 Disclaimer
This tender is not an offer by the Office of District Horticulture Officer, Hazaribag, but an
invitation to receive responses from eligible interested Bidders as post-harvest structures
and equipment supplying agency for Office of District Horticulture Officer, Hazaribag.
The Office of District Horticulture Officer, Hazaribag will select Bidder who fulfil the
eligibility criteria. No contractual obligation whatsoever shall arise from this process.
The evaluation shall be strictly based on the information and supporting documents
provided by the Bidders in the application submitted online by them. It is the responsibility
of the Bidders to provide all supporting documents necessary to fulfil the mandatory
eligibility criteria. In case, information required by Office of District Horticulture Officer,
Hazaribag is not provided by applicant, Office of District Horticulture Officer, Hazaribag
may choose to proceed with evaluation based on information provided and shall not request
the applicant for further information. Hence, responsibility for providing information as
required in this form lies solely with applicant.
Though adequate care has been taken while issuing this tender document, the applicant
Bidder should satisfy himself that the document is complete in all respects. Intimation of
any discrepancy shall be given to this office (as mentioned below) immediately. If no
intimation is received by this office within 3 days from the date of commencement & sale
of the tender documents, then this office shall consider that the document received by the
Bidder is complete in all respects and that the bidder is satisfied that the tender Document
is complete in all respect.
Page | 21

<!-- page 22 -->

5.11 Binding Clause
All decisions taken by the Office of District Horticulture Officer, Hazaribag regarding this
contract shall be final and binding on all concerned parties.

5.12 Bidder’s Code of Integrity
The Agency is responsible for and obliged to conduct all contracted activities as defined
in the scope of work in accordance with the Contract. Bidder shall:1. Not offer any bribe, reward or gift or any material benefit either directly or indirectly

2.
3.
4.
5.
6.

in exchange for an unfair advantage in tender process or to otherwise influence the
tender process.
Not misrepresent information that misleads or attempts to mislead to obtain a
financial or other benefit or avoid an obligation.
Not indulging in collusion with other bidders to impair the transparency, fairness,
and progress of the procurement process.
Not misuse any information shared between the procuring entity and the bidders
with an intent to gain an unfair advantage in the procurement process.
Not indulge in any coercion to any party or to its property to influence the
procurement process.
No to be struct any investigation or audit of a procurement process

7. Disclose conflict of interest, if any.
8. Disclose debarment by any other procuring entity in past or present if any, it is

mandatory.
9. In case of breach of integrity by Bidders, the Office of District Horticulture Officer,

Hazaribagh shall act as per the provisions of Jharkhand Procurement of Goods and
Services Manual.

5.13 Code of Integrity for Procurement Entity
All the officers or employees of the procuring entity shall:5.13.1 Maintain anunimpe achablest and ard of integrity.
5.13.2 Act in accordance with the provisions of tender Manual and guidelines issued by
the tendering entity.
5.13.3 Not allow any bidder to have access to information on this tender before such
information is available to the public at large.
5.13.4 Not intentionally use unnecessarily restrict iveor tailored specification sort terms
of reference that may discourage competition.
5.13.5 Not solicitor accept any favour or reward or gift from anyone who has soughtoris
seeking procurement from the procuring entity.
5.13.6 Not have a financial interest in any bidder(s).
5.13.7 Not disclose proprietary and source selection information to any person other than
a person authorized to receive such information.
5.13.8 Treat all bidder sina fair and equitable manner in line with the principle of fairness,
integrity, and transparency.
Page | 22

<!-- page 23 -->

5.13.9 Provide all bidders with identical information at the same time.
5.13.10 Apply the criteria of evaluation as specified in the bidding documents and under
no circumstances shall introduce new evaluation criteria during the evaluation
process.
5.13.11 Protect the interest soft he procuring entity under all circumstances.
5.13.12 Maintain confidentiality of all bids.
5.13.13 Ensure that the selection of bidder is not influenced by personal reasons
attributable to concerned officials in any manner.
5.13.14 Disclose conflict of interest, if any.

5.14Agency’s Obligations
The Agency will be obliged to work closely with the district office’s staff, act within its
own authority and abide by directives issued by the Office of District Horticulture Officer,
Hazaribag.The Agency will abide by the job safety measures prevalent in India and will
free the Office of District Horticulture Officer, Hazaribag from all demandros
responsibilities arising from accidentsor loss of life the cause of which is the Agency’s
negligence. The Agency will pay all indemnities arising from such incidents and will not
hold the Office of District Horticulture Officer, Hazaribagh responsible or obligated.
The Agency will be responsible for managing the activities of its personnel or subcontracted personnel and will hold itself responsible for any misdemeanor.
TheAgencyis expected to maintain high level of professional ethics and will not act in any
manner, which is detrimental to District Horticulture Officer, Hazaribag’s interest.

5.15Conflict of Interest
Bidder shall furnish an affirmative statement as to the existence of, absence of, or
potential for conflict of interest on the part of the Bidder due to prior, current, or proposed
contracts, engagements, or affiliation with the Department. Additionally, such disclosure
shall address all potential elements (time frame for service delivery, resource, financial
or other) that would adversely impact the ability of the Bidder to complete the
requirements.

5.16Non-Disclosure Agreement
The Agency will treat as confidential all data and information about the Office of District
Horticulture Officer, Hazaribag, obtained in the execution of its responsibilities, in strict
confidence and will not reveal such information to any other party without the prior
written approval of the Office of District Horticulture Officer, Hazaribag. All agency
shortlisted shall submit a Non-Disclosure Agreement to District Horticulture Officer,
Hazaribag.

5.17 Intellectual Property Rights
Page | 23

<!-- page 24 -->

Office of District Horticulture Officer, Hazaribag shall own and have a right in perpetuity
to use all Intellectual Property Rights which have arisen out of or in connection with the
implementation of this Contract, including all processes, products, software,
specifications, reports, drawings and other documents which have been developed by the
agency during the performance of Services and for the purposes of inter-alia use or sublicense of such services.
The agency undertakes to disclose all Intellectual Property Rights arising out of or in
connection with the performance of the services to District Horticulture Officer,
Hazaribag and execute all such agreements/documents and file all relevant applications,
effect transfers and obtain all permits and approvals that may be necessary in this regard
to effectively transfer and conserve the Intellectual Property Rights of Office of District
Horticulture Officer, Hazaribag.
The agency shall ensure that while it uses any software, hardware, processes or material
in the course of performing the services, it does not infringe the Intellectual Property
Rights of any person and the Agency shall keep District Horticulture Officer, Hazaribag
indemnified against all costs, expenses and liabilities howsoever, arising out of any
illegal or unauthorized use (piracy) or in connection with any claim or proceedings
relating to any breach or violation of any permission/license terms or infringement of
any Intellectual Property Rights by the Agency during the course of performance of the
Services.

5.18Arbitration
If a dispute arises out of or in connection with this contract, or in respect of any defined
legal relationship associated there with or derived therefrom, the parties agree to submit
that dispute to arbitration under GOJ guidelines.

5.20 Applicable Law
The agency shall be governed by the laws and procedures established by Govt of India,
within the framework of applicable legislation and enactment made from time to time
concerning such commercial dealings/processing/planting material supply.

Page | 24

<!-- page 25 -->

Annexure I: Application Format for Empanelment

Sl.

Particulars

1.
2.
3.

Name of the Agency
Complete mailing address with contact no (E-mail ID)
Postal address and contact no. of contact person and
address and contact no. of office located in Jharkhand.
Details of Bank Account
PAN No.:
GST No.:
Copy of valid required license/certificate from competent
authority.
Enclose self-attested copy of annual turnover, balance
sheet etc. signed from competent authority.
EMD (Earnest Money Deposit)
Self-attested copy of Details of GST registration. (In case
of non-registration in Jharkhand, Registration with
Jharkhand commercial taxes Department is mandatory.
Any firm registered with commercial tax department of
other state must be registered in Jharkhand within three
months from the date of selection, otherwise, contract
Would get cancelled/terminated.)
Authority letter(annexure-iii), Financial bid online
(annexure-iv), Responsibility of supplier (annexure-v),
Declaration (annexure-vi & vii) and Price fall (annexure- ix)

4.
5.
6.
7.
8.
9.

10.

11.

Document
Details enclosed
(Yes/No)

Page
No.

Page | 25

<!-- page 26 -->

Annexure II: Minimum Required Documents for Technical Eligibility
Name of the Bidder :Sl.

Attached Document

1.

Dully filled–in application form in prescribed format. (Annexure-I)

2.

Self-at tested copy of company’s certificate of incorporation/entity’s registration certificate

Self-attested copy of PAN Card and GST registration certificate.
Self-attestedcopyofvalidISO9001:2015certificateinthe offered components.
5. Self-attested copy of bylaws/MoA & AoA/ partnership deed as applicable.
Self-attested copy of req ui red GST return file docum ents for the F.Y 2024 -25 as
6.
per t echni cal eli gi bil it y crit eri a.
Self-attested copy of IT Return for last three consecutive financial year 2022-23, 2023-24
7. and 2024-25
8. Self-attested copy of audited balance sheet (with UDIN) for F.Y2022-23, 2023-24 and
2024-25, CA certified turnover certificate (with UDIN) for the financial years 22-23,2324and24-25as per technical eligibility criteria.
9. EMD (Earnest Money Deposit)
10. Self- attested copy of work experience as per technical eligibility criteria.
11. MSME registration certificate/UAM (if applicable) with DIC certificate
Annexure–VI (notarized)
12.
3.
4.

13.

Annexure–VII (notarized)

14.

Annexure–IX (notarized)

15.

Any other documents as required for this tender.

Note:

The

above

documents

will

be

the

basis

of

technical

eligibility.

Page | 26

<!-- page 27 -->

Annexure III: Format of Authority Letter
(On Letter Head of the Bidder)

Mr./Mrs.

(Name & address with telephone no. of authorized representative of the bidder) is working with/on
behalf of our company as our authorized representative for the State of Jharkhand.
She/he is authorized to submit, sign, collect & correct the all tender documents on behalf of
company/ bidder agency.

Seal of the Company: -

Signature of Director/Authorized Signatory :-

Dated: -

Name:Designation:-

Name of Representative:Specimen Signature of Representative:(Must be attested by the Director/
Authorized Signatory of the Bidder)

Page | 27

<!-- page 28 -->

Annexure IV- Financial Bid (BOQ)
To,
The District Horticulture Officer,
Hazaribag

Sir,
I / we do hereby quote the rate for supply and installation of various components of post-harvest
management for the beneficiaries under the scheme in Hazaribag district in accordance with the
specifications in all respects and instructions in the tender bid document.
SI.

Components of Post-Harvest
Management

1

Tomato Sorting & Grading Unit

2

Climate-Controlled Pre-Cooling

Offered Price (Per unit) Offered Price per Unit
(INR)
(INR)
(in Words)
(in Digit)

Unit (Capacity 1MT)
3

Evaporative/Low Energy Cold
Room Unit (Capacity 8MT)

4

Packhouse (9mtrx6mtr)

5

Weighing Machine (Capacity
200Kg)

Rates/Price quoted are inclusive of GST & all other applicable charges such as octroi, packing,
forwarding, freight, insurance loading, clearance and unloading costs at destination.
The rates should be quoted in Indian Rupees only, both in figures and words in such a way that
interpolation is not possible and all over-writings should be strictly avoided or rewritten and
correction should be duly attested prior to the submission of tender bid.

Page | 28

<!-- page 29 -->

Annexure V: Responsibility of material supplier whom work is awarded
1. To make available the offered components of post-harvest management in the

districts/blocks as directed by Office of District Horticulture Officer, Hazaribag.
2. If quality of the c o n c e r n e d materials is found inferior, the payment will not be given and

will be levied penalty.
3. Forged billing will lead to black listing of the companies.

Page | 29

<!-- page 30 -->

Annexure VI: Declaration
NootherFirm/SisterConcern/AssociateBelongingtotheSameGroupisParticipating/
Submitting this Tender.
(UploadonRs.100.00Non-JudicialStampPaperNotarizedCopy)

We have gone through the complete Bid documents and understood the instruction to the bidder,
and we accept the Terms & Conditions mentioned in this Bid documents.
We M/s. …………………………………………, hereby bid the prospective tender having any
common partners/Directors/Managing Partners etc. or having any other common criteria shall be
considered as Sister/Group/Associates Company/ Concern/Company. In such cases, only one of
them will be eligible for participating in the tender.
Wedeclarethattheentiresubmitteddocumentisoriginal&truetomyknowledge.
Date: -

Authorized Person’s Signature:-

Name:Witness(Name &Signature):Address:-

Address:Nameof the Firm:Sealof the Bidder:-

Page | 30

<!-- page 31 -->

Annexure VII :Declaration
(UploadonRs.100.00Non-JudicialStampPaperNotarizedCopy)
We have gone through the complete tender bid documents and understood the instruction to the
bidder, and we accept the Terms &Conditions mentioned in this TENDER documents.
We M/s… …………………………………………………………, here by provide our lowest
Rates for the Tender for the supply through the Office of District Horticulture Officer, Hazaribag,
conforming to the specifications mentioned in Annexures of these TENDER documents.
1.1 We Declares that:We undertake to supply and install such quantities of items, as we may be called upon to supply
under the conditions hereto, during the allotted period from the date of execution of the
agreement, on the rates specified in the agreement, at the places to be specified by the District
Horticulture Officer, Hazaribag, within the specified delivery period.
We do undertake that on receipt of supply order, we shall be able to supply and install the
required quantity of units within fortyfive days. In case of default of supply beyond the stated
period, Office of District Horticulture Officer, Hazaribag may take penal action which may
amount to return of the stock, whole or part of it, which will be taken back on our own cost.
We do undertake to compensate suitably in case of supply of poor quality of materials, after
due verification by a joint team of our organization and the officers of Department of
Horticulture, Govt. of Jharkhand.
We hereby agree to abide by and fulfil all the terms of this offer and all the conditions of
contract or in default then to forfeit and pay to the Office of District Horticulture Officer,
Hazaribag, his successors, the penalties or sum of money mentioned in the said conditions. Our
agency has never been disqualified due to the allegation for using any kind of fake documents
in any previous government tender.
We accept that the Earnest Money Deposit by us shall be retained by Office of District
Horticulture Officer, Hazaribag, on account of the Security Deposit specified in clause of the
said conditions of contract.
1.2 Wedeclarethatwehavenotbeenblacklisted/debarredbyanyInstitute/Authorityduringparticipatin
g of the present tender.
1.3 We declare that the entire submitted document is original & true to my knowledge.
Date:-

Authorized Person’s Signature:Name:-

Witness(Name & Signature):-

Address:-

Address:-

Nam of the Firm:Seal of the Bidder:-

Page | 31

<!-- page 32 -->

Annexure VIII: List of Items
Items
SI.
1 Tomato Sorting & Grading Unit

Remarks

4

Quantity is not fixed, component
wise physical target/quantity will
Climate-Controlled Pre-Cooling Unit (Capacity be determined as per the
1MT)
availability of eligible farmers/
Evaporative/Low Energy Cold Room Unit beneficiaries under the scheme.
(Capacity 8MT)
Packhouse (9mtrx6mtr)

5

Weighing Machine (Capacity 200Kg)

2
3

Page | 32

<!-- page 33 -->

Annexure IX: Affidavit for Price Fall
(UploadonRs.100.00Non-JudicialStampPaperNotarizedCopy)
WehavegonethroughthecompleteTENDERdocumentsandunderstoodtheinstructiontothe bidder
We M/s……………………………………………., here by declares hat:i.

The price charges for the offered item supplied under the contract by us shall, in no case
exceed the lowest price on which we sells to other parties, private or Government bodies
in Jharkhand.

ii.

If at any time during the said period, we reduce the sale price of such offered item to any
other person/organization in Jharkhand at a price lower than the price chargeable under
the contract, we shall forthwith notify such reduction in rate to Office of District
Horticulture Officer, Hazaribag. The price payable under the contract for the item supplied
after the date of coming into force, of such reduction in sale price shall stand
correspondingly reduced as per Jharkhand Procurement of Goods and Services Manual
5.8.2.8

iii.

Office of District Horticulture Officer, Hazaribag shall be entitled to recover any amount
paid in excess to us in respect of sale which takes place after the reduction of price by us.

iv.

If the rate of similar products (with same specification) is found lower within the State of
Jharkhand, Office of District Horticulture Officer, Hazaribag will have full power to
cancel and recover the excess amount paid.

Date:-

Authorized Person’s Signature: Name:-

Witness(Name & Signature):-

Address:-

Address:-

Name of the Firm:Seal of the Bidder:-

Page | 33

<!-- page 34 -->

Annexure X: BOQ/ Technical Specification of Items sfor Post-Harvest
Management
List of Components: A. Tomato Sorting & Grading Unit
B. Climate-Controlled Pre-Cooling Unit
C. Packhouse
D. Evaporative/Low Energy Cold Room Unit
E. Weighing Machine

A. BOQ for Tomato Sorting Grading Unit:Sl.N

Item Description

No.

Length
(M)

Width
(M)

Height
(M)

Qty

Unit

i

ii

iii

iv

v

vi

vii

viii

1

Supply of post-harvest sorting and grading
machine for tomato. Diverging roller grader
(Parallel rollers with adjustable gaps) type
machine having capacity 150 – 300 kg per hour
(scalable based on roller length), 3 to 4 stages
(e.g., Small/Cull, Medium, Large, and Extra
Large), Single-phase AC motor, Cylindrical
PVC rollers for food safety, Manual
adjustment: Using threaded bolts (butterfly
nuts) to manually calibrate the gap between
rollers, Frame: Mild Steel (MS) angle iron or
square tubing, primed and painted to prevent
rust, Feeding hopper: Gravity-fed inclined tray
with a padded surface to prevent bruising,
Collection trays: Sloped chutes lined with foam
or soft rubber to ensure "soft landing" for sorted
tomatoes, 0.5 HP Single-phase induction motor
(1400+ RPM), Speed reduction: Chain/Belt
and pulley system or a simple gearbox to
reduce roller speed to 80–120 RPM (slow
enough to prevent fruit ejection) with sheet
metal protection guard, Driver transfer: Chain
and sprocket or friction drive to rotate the
rollers in opposite directions (upward and
outward) to prevent fruit from jamming, Direct
to crate: Appropriate Height so that standard
plastic crates fit directly under the chutes.

1

1.00

No.

1
1

1.00
1.00

Set
Set

1.000

1.00

Set

48.00

No.

2
3
4
5

Installation of all machineries at site
On site operational training to the
user/beneficiary.
Electrical work, wiring etc. all complete with
all electrical connection up to the maximum
10meter distance from the power source.
Supply of foldable plastic crates for the purpose
of fruits/vegetable handling & storage at site.

1.000

0.550

0.360

0.280

Page | 34

<!-- page 35 -->

B. BOQ of Climate-Controlled Pre-Cooling Unit:- (Capacity 1 MT) for Vegetable Fruits.
Sl.N

Item Description

No.

Length
(M)

Width
(M)

Height
(M)

Qty

Unit

i

ii

iii

iv

v

vi

vii

viii

1

Supply of climate controlled pre cooling
unit,Capacity: 1MT, Temperature range:+4°C to
+8°C, Dimension: 2.4m x 1.8m x 2.4m
(L×W×H), Base frame: MS Channel & RHS,
Insulation panel: 60mm Thickness High-density,
Modular PUF (Polyurethane Foam) panels with
Cam-lock for easy assembly, Body Material:
PPGI, Cooling Unit: Indoor Evaporator (forced
air) and Outdoor Air-cooled Condensing unit,
Refrigeration Unit: 1 TR 8000 BTUs/Hrs.1.5 HP
air-cooled condensing unit, Refrigerant: 407a
(CFC Free), Control: Microprocessor-based
digital temperature controller, Interior Features:
Internal
LED
(Moisture-proof),
Power
Requirement: 230V, 50 Hz ,Single Phase, Door
System: Flush-type or overlap Single swing door
with heavy-duty gaskets and an internal safety
release handle, Floor: Anti-skid aluminum
checkered plate for durability.

1

2.40

1.80

2.40

1.00

No.

1
1

1.00
1.00

Set
Set

1.000

1.00

Set

2
3

Installation of all machineries at site
On
site
operational
training
user/beneficiary.

4

Electrical work, wiring etc. all complete with all
electrical connection up to the maximum 10meter
distance from the power source.
Supply of foldable plastic crates for the purpose
of fruits/vegetable handling & storage at site.

5

to

the

1.000

0.550

0.360

0.280

120.00

No.

L

B

H

Qty

Unit

(M)

(M)

(M)

III

IV

V

VI

VII

VIII

12

0.3

0.3

0.6

0.648

m3

12

0.3

0.3

0.6

0.648

m3

Top chord

4

3.2

12.8

mtr

Top chord

12

0.125

1.5

mtr

Door Frame

1

6

6

mtr

20.3

mtr

2.03

mtr

22.33

mtr

C. BOQ of Pack House Unit:- (Size : 9 Mtr X 6 Mtr.)
SI.

I
1
2
3

Description

II
Earth Work excavation in foundation and
Plinth
Providing P.C.C. 1:2:4 in foundation and
plinth Post & Support
Supply of G.I pipe

No

Supply of 20mm X 20mm GI SHS 2 mm

Wastage

0.1

Page | 35

<!-- page 36 -->

Supply of 32mm X 32mm GI SHS 2 mmWt.
Bottom chord

4

0.355

1.42

mtr

Door

1

7.8

7.8

mtr

Wastage
Supply of 47mm X 47mm GI SHS 2 mmWt.
Door Frame

2

0.1

3
Wastage

0.1

9.22

mtr

0.922

mtr

10.142

mtr

6

mtr

6

mtr

0.6

mtr

6.6

mtr

12

mtr

Supply of 65mm X 35mm X 15mm GI CLC
2 mmWt.
Window frame

4

3

4

1.2

4.8

mtr

Purlin

12

9.4

112.8

mtr

3

6.4

19.2

mtr

3

5.2

15.6

mtr

16.8

mtr

1.68

mtr

18.48

mtr

Wastage

0.1

Supply of 60mm X 40mm GI SHS 2 mmWt.
Top chord

4

6.4

25.6

mtr

Bottom chord

2

2

4

mtr

29.6

mtr

2.96

mtr

32.56

mtr

Wastage

0.1

Supply of 60mm X 60mm GI SHS 2 mmWt.
Post

12

3.1

37.2

mtr

Bottom chord

2

6.2

12.4

mtr

49.6

mtr

4.96

mtr

54.56

mtr

Wastage

4

5

0.1

S/F/F M.S Plate specially designed Bracket
Type.A

16

No.

Type.B

16

No.

Type.C

16

No.

Type.D

16

No.

Type.E

70

No.

Nut Bolt cleat and fitting accessories

1

set

Page | 36

<!-- page 37 -->

6

Supplying of Galvalumecoloured sheets made
of High Strength Base Steel ,Light weight
coating galvalume 55% Aluminium & Zinc
Alloy,with nine layer of protection coat,pre
treatment for corrosion resistance, TCT 0.45
mm

30

7.87

3.48

821.628

Ft2

5

8.86

3.48

154.164

Ft2

18

11.15

3.48

Wastage

7
8
9
10
11
12

0.1

S/F/F of Galvalume sheet Fabricated Roof
Ridge 9 mtr.
S/F/F of Galvalume sheet Fabricated Gable &
Corner flasings 23.2mtr.
Labour charge for fixing of cladding
Materials……
S/F/F of Door leaf including flashing etc.
S/F/F of window including flashing
etc(1.2X1.2 mtr. Size)
Earth work excavation
in foundation and

698.436

Ft2

1674.228

Ft2

167.4228

Ft2

1841.651

Ft2

1

no

1

no

155.5974

m2

1

no

2

no

plinth…….

13

15

29

0.75

0.675
less

14.68125
0.648
14.68125

M3
M3
M3

1

29

0.75

0.075

1.63125

M3

1

8.5

5.5

0.10

4.675

M3

6.30625

M3

0.97875
4.675
1.08
6.73375
0.03888
6.69487

M3
M3
M3
M3
M3
M3

Providing sand filling in
foundation and plinth …. Area

14

1

Providing PCC M-100 with nominal mix of
(1:3:6) in filling in plinth & sunken slab of
toilet with approved quality of stone metal
grade III (53 to 22.4mm size) and clean coarse
sand of F.M. 2.5 to 3 including screening,
shuttering, mixing cement concrete in
mixture, placing in position, vibration,
striking, curing taxes and royalty all complete
as per building specification & direction of
E/I.
foundation and plinth…
foundation
floor
Plinth protection

1
1
1

29
8.5
32

0.45
5.5
0.45

0.075
0.10
0.075

Less Post

12

0.075

0.072

0.60

foundation

1

29

0.45

13.05

M²

floor

1

8.5

5.5

46.75

M²

Plinth protection

1

37

0.45

16.65

M²

76.45

M²

Providing brick flat soling in

Page | 37

<!-- page 38 -->

16

Providing brick work in
foundation 1:6

Less Post P.C.C.
17

1
1

29
29

0.45
0.25

0.15
0.30

1.9575
2.175
4.1325
0.324
3.8085

12

0.3

0.3

0.30

1

29

0.25

0.45

3.2625

12
1

0.25
1.2

0.25
0.3

0.3
0.3

3.2625
0.225
0.108
2.9295

2

29

0.45

26.1

1

29

0.25

7.25

M3
M3
M3
M3
M3

Providing brick work in super
structure 1:6

less post P.C.C.
lessDoor area.

18

M3
M4
M3

Providing 12 mm th cement
plaster 1:6
entire wall

19

20
21
22

33.35

M²

33.35
5.00

SQM
Nos.

1

Set

2.847055
7.665312
6.025383
5220.253

MT
M3
M3
no

Providing two coats of snowcem of approved
make & shade over a coat of cement primer
on new surface including preparing the
plastered surface smooth with sand paper,
scaffolding , curing and taxes etc. all complete
as per building specification direction of E/I.
Supply of foldable plastic crates for the
purpose of fruits/vegetable handling & storage
at site.
Supply of 1 no. of plastic Table & chair at
site.
Carraige of Material
Cement 10Km

1.00
0

0.550

0.360

0.280

1
1.98

Sand (1K+8P)9K
Stone Chips (1K+7P)8K
Bricks15km

1000

D. BOQ of Evaporative/Low Energy Cold Room Unit:- For Vegetable Crops ( Capacity 8 MT)
Sl.N

Item Description

No.

Length
(M)

Width
(M)

Height
(M)

Qty

Unit

i

ii

iii

iv

v

vi

vii

viii

1

Supply of Evaporative Low Energy Cooling
Unit System for storage of vegetables/fruits:(Capacity to cool 8MT) Evaporative Cooling
Chamber :PCGI sheet fabricated chamber, size
of the unit is 1500mm x 750mm x 1950mm.
compartment is for cooling and evaporation
process includes provision for water storage
and circulation, two nos. of submersible pad
pumps dipped in stored water and supplying

1

1.00

No.

Page | 38

<!-- page 39 -->

2
3
4
5
6

7

cold water to evaporative cooling cellulose pad
celdek 100mm thick impregnated cellulose at
4c velocity of 1 to 3m/s to give efficiency from
60 to 95% and 101, 520 BTUs/Hrs. 7.56 Lpm
per sqft. One 186 watts, 450mm air extraction
fan at top for cold air transfer through duct to
the storage room. Water chilling Chamber:
PCGI sheet fabricated chamber for cooling
system size of the unit is 1450mm x 700mm x
150mm, consists of 1 no. of 1.5 ton capacity
compressor which chills water up to 6°C for
more cooling effects. Chiller coil with motor
and fan inside the base, copper tubes, and a 1/4
hp mono block pump, to suck water from PVC
water tank of storage capacity 100L, connected
with water level indicator to operate pump as
per water required, hermetically protected
compressor
unit
mounted
in
lower
compartment fitted with 9” dia fan used for
cooling refrigerant vapour and circulating
cooled refrigerant back to copper tubes fitted in
upper compartment for cooling circulating
water. Canopy/Shed: Prefabricated canopy,
size: 1530mm x 770mm made of light tubular
frame structure of G.I pipe 1” and PCGI sheet
is provided to protect it from rain and direct sun
light. Base : Base made of M.S angle/pipe 1” x
1”, height 4”, one inside unit which is
connected through ducts with 2 nos. of exhaust
fan size 6” operated through remote. Control
System: System controller includes auto
controller for water level maintain for tank
along with one temperature and humidly
monitor and with one main on/off switch.
Electrical Fitting: Minor electrical fitting items
including electrical cables, socket, and
switches plug etc. Duct: High energy insulated
aluminum duct of 6"dia, up to max. 3mtr length
for transferring cool air to the storage room for
cooling of fruits/ vegetables etc.
Installation cost of the cooling unit system at
site
On site operational training to the
user/beneficiary.
Supply of digital weighing balance
Electrical work, wiring etc. all completec with
all electrical connection up to the maximum
10meter distance from the power source.
Providing
room
for
cooling,
size:12ft(L)x12ft(W)x10ft(H)/ 1440 cubic ft
by beneficiary,10" thick 1:4/1:6 brick wall,
100mm thick 1:3:6 pcc floor and 1:1.5:3 RCC
roof, duly plastered 10-12mm and painted both
side wall and inside roof, with standard door
Supply of foldable plastic crates for the
purpose of fruits/vegetable handling & storage
at site.

1

1.00

Set

1

1.00

Set

1.000

1.00

Set

1.000

1.00

Set

1

3.66

3.66

3.05

1.00

No.

1.000

0.550

0.360

0.280

120.00

No.

Page | 39

<!-- page 40 -->

E. BOQ of Weighing Balance :SI.
1
2
3
4
5
6
7
8
9
10

Item
Product
Capacity
Display
Platform
Material
Tare
Facility
Overload
Protection
Stabilization
time
Mobility
Warranty

Description
Vegetable/Fruits Weighing Balance
Up to 200Kg
Digital Type
500mm x 500mm
Steel Pipe Fabricated with Stainless Steel Platform
Provided
Provided
3 Second
Fixed / Portable
Minimum 12 months

Page | 40
