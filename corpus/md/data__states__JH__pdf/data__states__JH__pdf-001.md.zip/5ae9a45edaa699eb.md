---
doc_id: "5ae9a45edaa699eb"
source_url: "https://cdn.s3waas.gov.in/s32bb232c0b13c774965ef8558f0fbd615/uploads/2018/06/2018061179.pdf"
ministry: "West Singhbhum"
title: "S.I.A Notification (Action Requested) (109,110,111-A)"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f7d1a5456ea5d91a"
---

<!-- page 1 -->

ftrdr qwrtroft -116- sqrrfi oT E.Fqrtrq, sR4ft frETry, q6qmr
1fuor T{rd'T vrur)
Tfr sr-dq, g"rqfq-q silr Tq-d-**errq=T q sfud sfu6q efq qnrqRrf,r ol
sTtrolq

1ffi

- 2o1s t5 rrFr - Er

ruffiT##go,
oTtuq-{r *ic<r

}o)@T"r.

to11-q:-

ff/ s] f q

(i) qR{iFqT ?Fr qFr- r}iqfi- qi1.6rrc1qr (B-.sffi $qr) q.l furytur mrd r
s-trrfud qR-{Ftr{r ar €f*q
Tjrcfq + fuq rsilrFfd .rfr or frKn w
qffisfl *d eilT \rgdTr{ogo Enr cildfrd
y,frfra #* r
I

6i

fr.

$-w or

aiffql

;il-q

ircn

de d"

3l-{d

ftEE q)
tffi nfr

160, 164, 551, 552, 553, 555, 592, 591, 590, 589,
5BB, 587, 615, 616, 649, 648, 650. 647, 646. 645.

1

671, 672, 673, 703, 704, 493, 492, 479, 472, 471,
971, 463, 456, 399, 397, 396, 394, 345. 344, 343.

q€frc|{I

326

gqR-grft

7.2is \ro-g

342, 339, 335, 333, 1072, 1073, 310, 3.11, 307, 303,

304, 162, 557, 560, 580, 5Bl, 586, 585, 632, 633,
634, 637, 638, 639, 641, 643, 754, 753, 74g, 748,
746, 745, 744, 743, 739, 738, 797, 706, 707, 964,
965. 966, 969, 972, 980, 986, 985, 984, 988, 989,
1033, 1046, 1083, 1075, 309, 308

eg R{e sqr- 96

E-d -

7.215 $o

ft

(ii) ggo ot(ogo d eW Btrq
gc+ furrroqrq
smr.fn t_
(6) wrwf (g) q{mq (s{) f"l ut"
ET{d/E-{-{rfd
(iii)gsdTrgoyo of shrqr
d ftrfd frfu d o d erqq wf oq
ry "ftNF
q*rft gq erfuq \rsdr$ogo
sR+il{q ft=fi qrw fi qenfurh q.F- urT *q*f,,
sr*u-s/cEd 6Tqfcq, EqR1irft, y1r"-s.a o,rqfdq, q{rq.ergq,
{. .td,
or-qtcrq,
fuEW iT{.rqT + "6rqffii B-qEq d,T ;qr qtrafi^frETT
fucrr S
:- chaibasa.nic.in { ff tg1
t
(iv) "r{Er€T
Td oerq fu' gs 3i-qfu d +{H sfi-s-{ ereircil qrr sf,t*T
*t
-*+ -'at .iR* g{ * d
qs E-S er-Efr cnt< qXq os n
o iJGf \rgo3fir$ogo qtF-f{ 6T tIrI :- Navdrishti, Flat No.Z/C,
Rameshwaram
Apartment Ashok Kuni, Argora, Ranchi- B340Oz
o { n-d - navdrishti(dgmail.com

ffi

*

qM

t

Me

d

fr*

* **

f

t

/

\ J}/e
fu-or r1_ord-+ q-offfi
Ai-z.l I
^tr{:H
HEt+t, ---J-Es t$ t
\!.!errrr
d

,irH.\e
V.,t
tr\ '
\r^rbl'

\ rl \

rZf,

orq{GlfEfffi

qffi R+h"qr$qlRT

}^Y\

d

fofurg'b
fum <-qfqzrref
-s6-Bq]|qil

qM P€-d.fl-qrgqrsr

<!-- page 2 -->

fufl.Eo-sltrorft -r!16- sqrytr o-r orqf{q, sfufr frETq, qr{Ersr
(fudr T{-dq vruf
Tfr st-dq, g-fifqq oflr g-+ffiQrq-{ q sF"rd sfufiq *q qn-qRfal oT
3Ttr-flT

- zols 6 qFr - s

M

goen{og" o1 eTfqfir
td mqq - 6 er w-fucn U,

ftni6:- \4s1\ V

oTfuqq-{T ln-rql J\ oV*1our"

(i) qffiqqT {l q-q- Gieflt- q{ErNfEI @rsr rftqr) q*r ffiTr ord

t

rl_e[f{ d fuq rffrF{d aR ot fuftTn gq
rtrrfuf, qffifir or r{ffrq ffi
qRq)-wil f{ oil-{ geoerr$ogo FItt orranko Yilffd frt
I

qlqT 6l

fr.

q|JII

ffie d"

qzIeI

R6s q)

tufrTfr

{iwr

il-g

1, 4, 206, 209, 210, 207, 208, 211, 212, 294, 301

312

gdTsTIsTT
1

--=----j-,$ rl

E+il\E{

302, 303, 304, 305, 191, 192, 198, 197, 199, 201
205, 202, 6, 7, 33, 661, 464, 465, 466, 468, 670
671, 672, 673, 674, 675, 970, 685, 969, 688, 690
752, 751, 793, 809, 813, 815, 816, 817, 818, 861
432, 435, 437, 438,992, 457,458. 459

eg qrd {srr- 60

4.71s Vds

E-d4.715 {o

(ii) gflo 3il-{ogo d ryu stqq eft gw DrqFodrq ftrcrd sr<Ffd t'(o) qqrq* (9 silsq (s{) (.r) rtro gq-+r{Zgq-{r{d
qfu-qr
orfu{+rr d
(iiix'qdil-$ogo
frfq 4 sr6 d er.w Wf oq
qrqfr \d sffuq gsos{r$ogo sfril{q
rnqr fr qerrRrfr riqB-d qrq tiqr+o,
vqs-s/Giqf, orqff,q, qqnTflt, si-Equ.ild{ o.rqfi4-q, qq-qrergx fuitr T. cn-f{
orqff,q,
ftrEW qr{={rsr + orqffii fr sqoq, *.} aen
RiEW
qriErqT frrdl d
:- chaibasa.nic.in fr fr tut "il e-6-f,r t
gs
erofu d q)rn sqf.s{ cTerrrT w seqq 6Ti fr1 o..H dlRrgr gi t d
(iv)rr6 oerq fu'
qs EA Gr-qfr eN vg< o-q *n
o tfwl gsou(ogo gor$ $T lrrl :- Navdrishti, Flat No.Z/C, Rameshwaram
Apartment, Ashok Kuni, Argora, Ranchi- B3+OO?
o { n-d - navdrishti(ogmail.com

d

trT
ftd

w

t

d

qffi

qM

Me

t

i

\fu-or -t-er$-c q-ilfufiTtr
,,C>,,+t\:,-,,f ,,,,
qlQqlHl
Nql<qfl | ltl6+l+1,
'

-{*=-

{

'h,-', \\u
!t45lB
-..\i'
I I

\]'

qR-qfr

d@,,tn'r
fu6r qu_srfMr
-T|6-sqrgK
qpqfr fr-d-tr qrgqr€T

<!-- page 3 -->

I

t

.yqgffi o-r E-fqlf,q, qM ffiEW, qrf,ffn
firor T{rdq ynq|
TF 3t-dq, g-"f"T ofl{ grd-{Rrqq if s|dfr qfufiq efs qn-,qpfilr uor

fuf,r Eusrkfl-S -s6-

sTtrrR .|ffi

- 2o1s t5 rrFT - Er

. .\y€Tr{o{o of sTFqwT
& frqq - 6 or w-$qq 6y
eTBq-qT lrqr

I ] ) \p/X.eio

tf s]f

PqB;:-

U

(i) qR:fq-fl 6-r qFr- eiqrs- rrr€rfirEr ffisr fiqr) qqT frqfur qrd
rwrfud qft+q-{r or sf*q ffi'r1-erft + qs
tfr or frtrR w
r

qffiqqi f{ of{ gwoeir$ogo gr$ srr@rfdd sqrfuf, qr{ "*rfr"
t

800, 802, 798, 803, 806, 816, 817, 818, Arg, e2o.
821, 843, 844, 838, 842, 846, 845, 847, B4B, 849,
850, 851, 859, 860, 876, 877, 878, 87g,880, 881,
882, 883, BB4, 885, 886, 887, 902, 903, 904, 905,

4.941 \rfr-g

906, 907, 967, 969, 970, 983, 984, 991, sg2, 1702,

Eqn-grft,

994, 996, 1699, 1002, 1008. 1015, .1016, 1018,

1017,

1021, 1022, 1023, 1024, 1026, 1031, 10g2, 1033,
1034. 1039, 1040, 1042, 1043, 1044, 1059, 1060.
1070, 1072, 1073, 1074, 1075, 1078, 1079, 1081,
1086, '1091, 1092, 1102, 1103, 1104, 1105, 1146.
1

157, 1 158

ecT RTe $sII- 93

(ii) gso eilfio{o d vgu sirq efly gw fuqroam fuFd cr-ilrfd
', :-' -.
(o) quqd (s) $dH"T (sf) fO uf"

E-{rd/g-{Tr{d

trf,

t-

liii;gsoeTr$ogo o1 ubvr
d_
ftfq 4 qr6
qr+'ft qq sTfrq \rsdr-{og"
"fug1+r
sfttii{ fofi .rrqr tt q*nfurn

T

rqu-s/3ffid d.|qrfq, qiqr{qrft.

*

d qi-"{r Wf or 6x
€dBd urq riqrqf,,

STWF O-rqlfrq, qrFrarw, fuilr

3Nh
r
"ppqfdqT q
+fd*
d
qtrq,ft
;ffi"T
+n HrT
fu_dw
qT*{rsr frdI d .ft"{" :- chaibasa.nic.in .ft
Me
fr tg-r * o* t
(iv)TE oerq fu' W ea-qfu d +rH qfig{ c{er{r ?rq B6l-r
*i # -'.S ;iR", g{ t d
qe rd sr-qfr eil-< qu or

orqfdq, -R"t

f

t'n
o gw[ gsovr$ogo Eor{ ?b't rr-+T :- Navdrishti, Frat No.Z/c,
Apartment, Ashok Kunj, Argora, Ranchi- B34O0Z

Rameshwaram

o { n-d - navdrishti(ogmail.com

r\
\\

\\

S

9",5'T{rdq qEfffi
S*trw
S*'
\rl{\8 Vc)\l
fu-dT

'

\%l'

lrY\

\*trt
frET ##il',t
qffi ft-d.tr
"rSqrqT

-7
