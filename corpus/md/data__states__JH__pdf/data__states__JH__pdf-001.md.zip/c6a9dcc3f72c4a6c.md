---
doc_id: "c6a9dcc3f72c4a6c"
source_url: "https://rcd.jharkhand.gov.in/fileupld/guideline/SOP_for_Monitoring_and_Compliance_of_Safety_norms_on_the_Highways.pdf"
ministry: "Road Construction Department, Jharkhand"
title: "View"
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "9c13f303354218be"
---

<!-- page 1 -->

१
न WwW €
= सं0सं0-05 / विविध-05--63 / 204 ae 8 (S)
oh झारखण्ड सरकार दट
ra पथ निर्माण विभाग
प्रेषक,
मुरारी भगत,
: अभियंता प्रमुख,
| L ‘cs प0०नि0०वि०, झारखण्ड, राँची।
a a a
ie सेवा में, = )
"og, oo cS (ato), Yr (0८
७० ¢ ४४ प0०नि0०वि0, झारखण्ड, राँची।
७.
a wer मुख्य अभियंता (ato),
v राष्ट्रीय उच्च पथ उपभाग,
झारखण्ड, राँची।
i; J राँची, दिनांक: (हक |2-/2/
१0 विषय:- Guidelines / SOP for monitoring and complaince of all safety norms on the
\ Highways.
WaT:— MORT&H, New Delhi @I WaT#-RW/NH-2903/04/2020-S&R (P&B)
दिनोक- 09.44.2020
महाशय, ६
उपर्युक्त विषयक प्रासंगिक पत्र की छायाप्रति नियमानुसार अग्रेत्तर कार्रवाई हेतु इस पत्र के
साथ संलग्न कर भेजी जा रही है।
अनु0:-यथो क्त | विश्वासभाजन,
we
४2204, (मुरारी भगत)
"he अभियंता प्रमुख,
yr 'प०नि०वि0, झारखण्ड, राँची।
Ser
Scanned by CamScanner

<!-- page 2 -->

९ No RW/NH-2903/0! /2020-S&R(P&B) ye /
A ¥ Government of India कर SY
; Ministry of Road Transport & Highways ४. डे aa ors x 2227
\ नो (Road Safety Engineering Zone) “Se
| Transport Bhawan, 4, Parliament Street, New Dethi-0004
New Delhi dated the 09" November 2020
To,
. The Chief Secretaries of all the State Governments/UTs.
2. The Principal Secretaries/ Secretaries of all States/ UTs Public Works
Department dealing with National Highways, other centrally sponsored
schemes,
3. All Engineers-in-Chief and Chief Engineers of Public Works Department of
States/ UTs dealing with National Highways, other centrally sponsored
schemes.
4. The Director General (Border Roads), Seems Sadak Bhawan, Ring Road, New
Delhi - 000.
ge 5. The Chairman, National Highways Authority of India, G-5 & 6, Sector-0,
Le Dwarka, New Delhi - 0075.
“ x 7_,~% 6 The Managing Director, NHIDCL, PTI Building, New Delhi-40004
7, All CE-ROs, ROs and ELOs of the Ministry.
शक
Subject: Guidelines/SOP for monitoring and compliance of all safety norms on the
& ® Highways
wy = Ministry and its executing agencies follow standard bidding documents of (i) FIDIC
aye base Item Rate Bid (ITB) Contracts, (ii) Engineering Procurement Contract (EPC), (iii)
at Hybrid Annuity Mode Concession Agreement and (iv) BOT(Toll/Annuity) Concession
wea Agreements, While (i) and (ii) are financed through 00% budget Provisions, (iii) and (iv)
८०५ ye are financed with investment models of Debt/Equity with investment recovery through toll
eri or Annuity receipts. While, all the above model contracts have provisions to make the
eg contractor/concessionaire responsible for safety auditing at design stage, during
Keg construction, while opening to traffic and during operations; the provisions for
|, appointment of Safety Auditor by Contractor is made in the Model EPC documents. These
‘J.- provisions are made to ensure safety compliances where the contractor is to deliver at a
é fixed price and own all responsibilities of successful project.
es" 2) Despite ali due diligences made as above, due to divergent nature of traffic and driver
N% behavior, it may be possible at some spots where all above fails and accidents/fatalities
takes places. In order to save precious human lives, such spots need to be attended
AN AL
Scanned by CamScanner

<!-- page 3 -->

|
immediately for identification of problems and rectifications. There may be such spots on
the highways, awaiting development, where such spots are to be dealt on priority. The
“Protocol for identification and rectification of road accident black spots on National
Highways” has been prepared and issued to all concerned vide this ministry OM no.
RW/NH/507/09/205/P&M(RSCE) dated 28” October 2045 (Annex-4 ). This ministry has
also issued following directions for effective rectification of Blackspots:

i) OM No. RW/NH-29047/2/205/PEM (RSCE) dated 7 December 205 on
“Preparation and submission of proposals for rectification of identified road
accident black spots on National Highways.” (Annex-2)

ii) OM No. RW/NH-290I/2/205-P&M(RSCE) dated 47४ September 206 on
“Immediate cautionary measures for alerting road users at identified black
spots” (Annex-3)

iii) Circular no. RW-NH-290ii/0I/20I9-S&R(P&B) dated 26% August 20i9 on
“Rectification of Accident Black Spot - Preparation of proposal and
sanction/approval regarding.” (Annex-4)

3) Further this ministry through NIC is developing a Blackspot MIS portal

http: //422.76.47.24/bs/auth/users/togin.cshtml 76.47.24/bs/auth/users/login.cshtml where details of all blackspots, ids,

photographs, and rectification status and post rectification feedback shall be collected and
monitored.

4) While reviewing the measures taken and strategy of Blackspots rectification, need has
been felt to issue following guidelines for identification of problems, proposing/preparing
proposals for suitable rectification measures:

4.) The Blackspot shall be thoroughly inspected, a detailed layout drawing of existing site
prepared duly marked with (i) all geometric features of existing road, (ii) all permanent
and temporary structures within ROW, (iii) traffic flows along and across the road
(separately marked fast moving motorable, slow moving motorable, non motorable and
pedestrian), (iv) conflict points identified and marked on layout drawing;

4.2) Suitable measures for elimination of all conflict points derived and marked on the
layout of existing spot with traffic flows along and across the road (separately marked fast
moving motorable, slow moving motorable, non motorable and pedestrian); conflict points,
remaining if any, identified and marked on layout drawings;
4,3) Justification for conflict points which could not be removed, shall be prepared along
with other suggestive measures for minimization of accidents/fatalities.
4.4) Cost estimates be prepared for the proposed measures adopting quicker construction
methods and works got sanctioned.

rt
eek a
Scanned by CamScanner

<!-- page 4 -->

EE >> लक नलीलीलीलीलदीनीलिनशीनीमीलीनिकन शशि शशि कि न शशि शिशिशिशिशिशिकक कक.
yi Emphasis be given to complete the rectification Process within 6 months.
4.6) Pending permanent rectification, temporary measures shall be taken, immediately on
noticing the Black Spot, to avoid conflicts/accidents.
4.7) Photographic evidence of Blackspots pre and Post rectification be kept along with
three years feedback vigil on the rectified site to monitor results of rectification. In case
of post rectification accidents on the spot, the reasons of failure be identified and urgent
action for further improvements be taken.
4.8) Steps taken as above be immediately updated on Black Spot MIS portal
http://422.76.47,24/bs/auth/users/togin.cshtml.. 76.47.24/bs/auth/users/login.cshtml :
5) This issues with the approval of Competent Authority.
Yours faithfully
bt veer fats
bere (Dhan Veer Sahu)
mihi NE ७ Executive Engineer (Road Safety)
Copy to:
i. All CEs in the Ministry of Road Transport & Highways
2. The Secretary General, Indian Road Congress
3. Technical circular file of Road Safety Engineering Section
4. NIC - for uploading on Ministry’s website under “What’s new”
Copy for kind information to:
i. Sr. PPS to Secretary (RT&H)
2. PPS to DG (RD) & SS
3. PPS to AS&FA
4, PS to ADG-I
5. PS to JS(T)/ JS(H)/ JS(LA&C)/ JS(EIC)
Scanned by CamScanner

<!-- page 5 -->

कारक
 च्शखचचचच च चचऊझ
Bi; भारत सरकार ey, oa.
S Government of India
re सडक परिवहन और राजमार्ग मंत्रालय
Nit i — of Road ie en = wrth.
ie aftaes aan, 2 dae ant, a ~ 440004 गा
seen पायतें वाक्षाइ9०7 8#३%ढ॥, 4 ?क्राकज्ाशां 509७६, ।४७७ Delhi-440004 == ]
॥३०. २५४॥३/5047/09/2045/ए&# (२506) 09॥20: 28.40.2045
OFFICE MEMORANDUM
Subject: Protoco! for identification and rectification of road accident black spots
on National Highways
The present Road Safety scenario on road network in general and on National
Highways in particular with a high rate of accidents leaves much to be desired, Though
the roads especially National Highways were expected to be developed adopting all
Safety Engineering measures including design stage Road Safety Audit at the time of
preparation of DPRs and Pre-opening Stage Road Safety Audit after completion of the
development work, , a significant number of locations even on NHs have remained prone
to accidents on the road network in the country including NH network which has already
been developed in one scheme or the other, due to several reasons and constraints in the
development and maintenance. For improvement of such locations a systematic approach
is required which includes a common definition for road accident black spots on NHs and
a sequence of actions with time frame for removal of those black Spots. For this purpose
the following is the protocol for road accident black Spots on National Highways
2. Definition of Road Accident Black spot on National Highways: of Road Accident Black spot on National Highways: Road Accident Black
spot is a stretch of National Highway of about 500m in length in which either 5 road
accidents (in all three years put together involving fatalities/grievous injuries) took place
during the last 3 calendar years or 0 fatalities (in all three years put together) took place
during the last 3 calendar years
3. Forwarding the road accident data on NHs to Transport Research Wing (TRW) of the road accident data on NHs to Transport Research Wing (TR f
MORTH: The accident data (keeping in view the above definition of accident black spot)
giving the specific location of black spot, limits of the black Spot stretch (Up to a length of
about 500 m), Number of accidents involving fatalities’ grievous injuries, number of
fatalities if any during a calendar year are to be forwarded by police authorities/National
Crime Records Bureau so as to reach TRW of Ministry of Road Transport & Highways by
34* March, of the subsequent calendar year( For example Road accident data of the year
met 205 is to be forwarded to TRW by 3™ March 206).
की 4. Forwarding of compiled road accident black spot data on National Highways by of compiled road accident black spot data on National Highwa' by
TRW to Road Safety Cell(Engineering) of MORTH: Transport Research Wing of MORTH
shall compile/analyse road accident data on NHs of a particular calendar year based on
the above definition and furnish the black Spot details along with details of accidents/
fatalities to Road Safety Cell(Engineering) of MORTH by 3°' May of the subsequent
calendar year (For example black spot data based on road accident data of the year 2045
is to be forwarded to RSCE of MORT&H by 34* May2046).
Page l of 2
सभी पत्र सचिव, भारत सरकार, सड़क परिवहन और राजमार्ग मंत्रालय, को उनके नाम पर नहीं बल्कि पद के पते पर भेजे जाने चाहिए। तार “ट्रांसपोर्ट”
‘Al communication shouldbe addressed fo the Secretary tothe Government of india, Ministy of Road Transport & Highways, by tle NOT by name. Telegram : TRANSPORT”
Scanned by CamScanner

<!-- page 6 -->

हर Remedial measures for Rectification ectification of Road accident black spots on NHs: Road accident black spots on NHs: The
concerned executing agency should take necessary actions for preliminary inspection,
framing of proposal and obtaining of approvals/sanctions as per the guidelines given in
OM No RW/NH-507/ 709/2075 / P&M (RSCE) dated 080205 and obtain
sanctions/approvals for rectification of the accident black spots identified based on
accident details of a particular Calendar year by 34“ March of the next to subsequent
Calendar year (For example sanctions of remedial measures for black spots based on
road accident data of the year 2045 by 3i" March 207)The execution of the remedial
measures including acquisition of the land for implementation of the road safety measures
for removal of black spots should be taken up on top priority and should be completed in
minimum possible time commensurate with the size/ complexity of the remedial measures
as per the respective contract conditions. In any case. short term measures like
installation of road signs, road markings, speed reduction measures and repair of
damages causing unsafe conditions on the National Highway shall be taken up
immediately and completed within 3 months of identification of the road accident black
spot. The progress of the execution of these remedial measures should be regularly (on
quarterly basis) raported to Road Safety Cell (Engineering) of Ministry of Road I tansport
& Highways.
6. Feedback on effectiveness of aeeoback on effectiveness of remedial measures taken:
Concerned executing agencies who executed the remedial measures should obtain Road
accident data of the location/stretch where remedial measures are executed, from
concerned Police Authorities on a calendar year basis after the remedial measures are
executed and should communicate to the Road Safety Cell (Engineering) by 34* March of
the subsequent calendar year till 3 years after completion of remedial measures or the
declaration of the remedial measures as effective by Road Safety Cell (Engineering)
whichever is later.
This issues with the approval of Secretary (RT&H).
(Ravi Prasad)
Chief Engineer (Road Safety)
To
Chief Engineer-P-7 /P-2P-3/P-4/P-5/P-6/P-7/NER/PLIMON-I/EAP/NHDP-IV/ LWE/S&R
RY/S&R (B)
oe NHAI [Attention: Chief General Manager (Road Safety)]/
Director General Border Roads/Managing Director, NHIDCL, Director, |AHE.
Joint Secretary (Transport), Senior Advisor, Transport Research Wing.
All Secretaries of PWDs, Chief Engineers of NH, Chief Engineers of project zones,
Regional Officers of MORT&H, DGBR, NHAI, NHIDCL
Copy for information to: PS to Hon'ble Minister (RTH & S), PS to Hon'ble Minister of State
for RTH & S, PS to Secretary (RT&H), Sr. PPS to DG (RD) & SS, Chief Secretaries of
Concerned States & UTs, PPS to ADG-I ADG-II, Coordinator-I, II & tl.
Page 2 of 2
Scanned by CamScanner

<!-- page 7 -->

हर भरत सरकार es; AS.
3 Government of india
“ i के सड़क परिवहन और राजमार्ग मंत्रालय mh
Ih bh Ministry of Road we = nes — किम.
& uRags 444, 4 Wee ari, 7: - 40004 | गा
Gey Transport Bhawan, 4 Parliament Street, New Delhi- 0004 ==
सत्यमेव जयते SEES
No. RW/NH-2904 4/2/20i5/P&M (RSCE) Dated: 07" December, 205
Office Memorandum /
Sub: Preparation and submission of proposals for rectification of identified road
accident black spots on National Highways
Repeated road accidents and fatalities are taking place in some locations on
NHs due to various reasons, which are being identified as road accident black spots. In
view of the great loss, being caused by the road accidents to the economy, apart from
irreparable loss of precious human lives, it is essential to identify, investigate and rectify
these road accident black spots wherever the accidents are being caused due to road
related deficiencies. Ministry has already issued guidelines on this subject. While
designing remedial measures at the identified road accident black spots on NHs, a
balanced approach needs to be adopted keeping in view the improvement projects in
progress or in contemplation on the black spot stretch while simultaneously meeting the
objective of minimizing the accident potential at the accident black spots in minimum
possible time, so that, no major investments are rendered superfluous due to other
improvement projects taken up within a short duration.
2. Various measures to be taken for minimizing accident potential at the identified
toad accident black spots on NHs can be classified into different categories viz., Short
term, Medium term/interim and Long term depending on the requirement of resources
for taking up these immediate” actions and other site conditions. Typical examples of
short term, Medium term/interim and Long term measures at Road accident black spots
on National Highways are as below:
(i) Short term measures:
Applicable to Non-urban sections & Urban Sections:
Road signs, speed limits/speed breakers, pavement markings, delineators, pedestrian
railings, crash baits barriers, studs/ cats eye etc. ————_
Applicable only to Urban Séctions:
Restriction. of certain typ8S"6f Vehicles, one way streets, reversible lanes, bus lanes,
restriction on movement of different types of Vehicles by timé/ by lane 6te™”
(ii) Interim/Medium term measures: are psig at cures ot black spot locatic widening at curves at black s; ions,
improving Pobre Seen an et and_vertical metry at black spots, Fe pode enero lestrian
facilities like Zebra crossings, rai 7 street lights, crash barriers, improving junctions,
provision of _fact-paths, ea te sight distance etc. within available land(as far as.
possible), signalization and ‘removing of obstructions
{ili) Long term measures : Provision of bypasses, provision of service roads, provision
of grade separated inter-changes, provision of vehicular & pedestrian under-passes,
foot over bridges, different measures acquiring additional land wherever required. >
3. National Highway stretches which are identified for capacity augmentation and
other improvements, (by executing agencies) would be in different stages of
improvement like OPR preparation, land acquisition/utility shifting, bidding and
completion of residual pre-construction activities before fixing of appointed
date/commencement date etc., and may take durations varying from 4 to 3 years for
Page Lof2.
_ eeeeeSSSSSSSSSSSSsFseseseseF
| सभी पत्र सचिव, भारत सरकार, सड़क परिवहन और राजमार्ग मंत्रालय, को उनके नाम पर नहीं बल्कि पद के पते पर भेजे जाने चाहिए। तार : “ट्रांसपोर्ट'
All communication should be addressed to the Secretary to the Government of India, Ministry of Road Transport & Highways, by lite NOT by name. Telegram : TRANSPORT”
Scanned by CamScanner

<!-- page 8 -->

D xzezzme development depending on the conditions of individual projects. Therefore, the
following approach may be adopted in formulating various measures at the black spots ce
on NHs for avoiding major superfluous expenditure while meeting the objective of
reducing accident potential at the black spots in minimum possible time.
4 Short term measures may be adopted where: the contemplated improvements at
road accident black Spots after their completion are likely to be used by the trafficiroad
7 users for less than a year before other improvement projects are executed on the
। Stretch under consideration. interim/medium_term. measures including short term
measures may be adopted where the contemplated improvements at the road accident
black spots are likely to be used by traffic/road users for more than a year, before other
improvement projects are executed on the stretch under consideration. Long term
measures including interim/medium term/short term measures may be adopted as per
the site and traffic requirements where no major improvement proposals are
contemplated on the stretch under consideration or where the trafficroad users
continue to use the proposed long term measures even after the major improvement
works in contemplation are executed ( e.g. the improvements carried out on urban
stretch of the National Highway will continue to be used by the traffic/road users even
after completion of the bypass)
5. Adequate care may be taken in preparing accurate base maps base maps drawn to a
suitable scale indicating all the features of road and | toad environment through survey
investigations, in superimposing the proposed improvements and in furnishing other
trafficroad user related data while framing and forwarding the proposais. The
executing agency at the level of Chief Engineer (NH) or equivalent may record a
Cérlificate white forwarding the proposals for improvements at the road accident black
spots, about the likely duration of usage —of_(7e proposed improvements | usage of the proposed rovements by the
trafficfroad users before other major improvements are executed on the | under
consideration duly taking into account the ars St Ser maprovement. proj of other improvement projects in
progress! in contemplation. This certificate May accompany every proposal for road
accident black spot rectification. so as to avoid loss of time in processing the proposals
for sanction. Tt लक
6. This issues with the approval of competent authority. This may be circulated to
all concerned. 4
(Ravi Prasad)
Chief Engineer (Road Safety)
To
Chief Engineer-P-4/P-2/P-3/P-4/P-5/P-6/P-7/NER/PLIMON-I/EAP/NHDP-IV/ LWE/S&R
(RY/S&R (8)
Chairman, NHAI [Attention: Chief General Manager (Road Safety))/ Director General
. Border Roads/Managing Director, NHIDCL, Director, IAHE / Joint Secretary
(Transport), Senior Advisor, Transport Research Wing.
All Secretaries of PWDs, Chief Engineers of NH, Chief Engineers of project zones,
Regional Officers of MORT&H, DGBR, NHAI, NHIOCL
Copy for information to: PS to Hon'ble Minister (RTH & S), PS to Hon'ble Minister of
State for RTH & S, PS to Secretary (RT&H), Sr. PPS to DG (RD) & SS, Chief
Secretaries of Concerned States & UTs, PPS to ADG-I ADG-II, Coordinator-I, f & {ll.
Page 2 of 2
Scanned by CamScanner

<!-- page 9 -->

EE LLL _>______्ननन्
A भारत सरकार (RT,
ea Government of India fy,
7 | ४ सड़क परिदहन और राजमार्ग मंत्रालय FA}
0! it ह Ministry of Road Transport & Highways पर es itt
(५ परिवहन मवन,॥ संसद मार्ग, नई Re - 440004 पा ar
ane qt ¥ Street, - SS
a Transport Bhawan, { Parllament Street, New Dethi-440007 ===
RWINH-2807 /2/205-P&M (RSC E) 440 387शा#९ 2046
Office Memorandum
Sub: Immediate cautionary measures for alerting road users at identified
black spots. ee
identifying and rectifying road accident Black Spots is a2 continuous
engineering activity towards improvement of road Safety. Guidelines for this activity
have already been issued vide this office memorandum of even number dated 08-
40-2045, 28-40-205 & 07-42-2045.
2 Long term permanent measures require detailed survey _ investigations,
preparation of detailed Proposals and their implementation which take some time.
Therefore, it is essential fo caution and alert the road users about accident black
Spot if the same is resulting from Geficiencies in toad / road environment. For this
Purpose the following approach and guidelines may be is may 68 followed. ~~
3 Some or all of the following signages shall be installed at the identified biack
spots immediately for cautioning/alerting road users.
(i) Cautionary accident black spot signs (Newly designed and indicated in
i Annexure | enclosed) at both ends
(i) Solar red blinking signals at both the ends
ne
(ii) | Rumble Strips together with Tumble strip sign
{iv) “Restriction ends” sign
4. An indicative sketch showing the sons ond shapes-of and shapes of the above signs is
at Annexure-I, Sizes, shapes, ‘ocations and other §} ns of all the signs
including the newly designed sign indicated at ()) above shall be as per IRC-67-2042
or its latest edition. Era eeaee
= In case the identified black spot contains sub-spots, the signs shall be
installed for each of the sub-spots. a
6. In case there are no road / Si hm ad 7 शशट telated deficiencies at the
identified black spot, the abovi 7०६ 66. Ned“aROIE should be
intimated to Ministry that there are no road related deficiencies at that particular spot
7. Not withstanding the installation of the above cautionary "erat loi
tarm_ measures should be designed and implemented for EI
rectifying thé’ Black spots as per the guidelines already issued.
parmanent™ long term measures are implemented, the above cautionary
measures should be removed. मल
Page lof 2 OS
wel yr ete, en सरकार, सड़क after ओर राजा dare, @ Gwe aa WRG Kes Ww Od we Ad wh WII ORT GA
‘Al commmurication shoud be adgressed to the Secretary to the Govemment of Inia, Misty of Road Transport & Highways, by Gite NOT by name. Telegram : “TRANSPORT”
Scanned by CamScanner

<!-- page 10 -->

«
y case the cost involved in the above measures for all the identified black
spots put together iT the jurisdiction of a regional office is small, the same can be
met from either Ordinary repairs or Contingencies ¢ jencies of an. rig orig NH. yo i H_work (even if
the ongoing work"is fof falling on the K Spot stretch as has already been
specified in the guidelines), —
9. In case the cost involvement for the above measures for all the identified
black spots in the jurisdiction of a Regional Office put together is substantial
approximate cost for the same may be furnished in a single list by each RO for
Administrative/Financial approval. This may be furnished within two weeks of issue
of this OM. ~
40. The above cautionary measures may be executed through short tender notice
and completed within three months for all the black spots so far identified and
notified. I case of future black spots, these cautionary measures shall be
implemented within two months of notifying the identified black spots by the
competent road _authofity (In case Of National Highways, Ministry of Road Transport
& Highways).
44. Implementation of long term measures must be carried out as a parallel
activity for final rectification of the black spot as cautioning of road users is “only an
inftriédiate measure. है
42. The above guidelines may be treated as most igen and the action taken be
reported immediately fo Road Safety (Engineering) mail ID
g@.rsce.morth@amail.com . This activity will be monitored at the highest level and
would be intimated to concemed authorities including Honourable Supreme Court
Committee on Road Safety.
Enclosure: As above BS. <,
(Ravi Prasad)
Chief Engineer (Road Safety)
To
Chief _Engineer-P-4/P-2/P-3/P-4/P-5/P-6/P-TINER/PLIMON-VEAP/ NHDP-IV/ LWE/
S&R(RY/S&R(B)/ SPZ
Chairman, NHAI [Kind attention: Chief General Manager (Road Safety)]/
Director General Border Roads/Managing Director, NHIDCL.
All Secretaries of PWDs, Chief Engineers of NH, Chief Engineers of project zones,
. Regional Officers of MORT&H
Copy for information to: PS to Hon’ble Minister (RTH & S), PS to Hon’ble Minister of
State for RTH & S(PR), PS to Hon'ble Minister of State for RTH & S(MM), PS to
Secretary (RT&H), Sr. PPS to DG (RD) & SS, PPS to AS&FA, Chief Secretaries of
All States & UTs, PPS to ADG, Coordinator-I & ill, PS to JS-EIC, LA &EAP / JS
(Transport)/ JS(Highways), Senior Advisor (Transport Research Wing), PS to CE
(Road Safety).
Page 2 of 2
Scanned by CamScanner
