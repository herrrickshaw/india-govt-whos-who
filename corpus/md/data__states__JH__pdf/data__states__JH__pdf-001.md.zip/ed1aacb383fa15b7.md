---
doc_id: "ed1aacb383fa15b7"
source_url: "https://cdn.s3waas.gov.in/s3e165421110ba03099a1c0393373c5b43/uploads/2026/06/17823872396805.pdf"
ministry: "Ramgarh"
title: "Net Tender 02 (3 MB)"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "793c7865959a7694"
---

<!-- page 1 -->

gI{€TU-g S$DN

orqfuilq: fudr

rN qflffi, {rrrrd

oTfrorcffii-frq ftfu{r oTrriT'r qffir so

- ozlzozo-zz

t

Tdq Er{T rilo GryffisT oi qfr-d fuqT qrf,T fu q{ zozo-zz d frq
ft'IrT-iftq iT-Gq]tPI rs, ffio 23.06.2026 d Arr <r-q q)-w+ d Grd.fd fuflfo q-(q
frq B-sreft) oi qa sro F-r$ dfu,T +d q,t .rr[ffi fu-ql urqr t r
sT-g dffi"
wa fu d-Ed G{Bfr-drT <rRr zooo / Ko (d eqrq) qra t I gw rd-cr+ef sro
Grr[ffiGt frfr<T GrrqB.a fuqT urnr t r E-q-fi rnre argffieiT qro
.rr[ffi tg 5.di-q-( frB<T furm 02.02.2026 d Gil-irfl 02:30 e-d To fu-mT q.Er
oTqfcq, RTqrG Tfi-fi'R fuqT ql$qT gq
03.0r.2026 o) erq<T-fl o+,oo qd
fthET r+ft.fr d rrqel Grq.{ lg-qrrflf, grqrd d orqrdq zner d GH qr$.fr I F.frqT
3ilqrnT ig.il-qarfr ytd www.ramgarh.nic,in gq fu-dT rtatri oTqfdq, nq-rra d

ffi

-

t

t

r1qqT Erg q{ ter ur qcraT

t

H-fi

B/ qrd fuqT qr e-m-il t

t

tudrfu
1lqr-61

<!-- page 2 -->

snqT{fi'Ylfr

zM

1. mT-$ dfutT i-e or ({ qrEr qfr trqr$ \-q
d v+red G +d(
xr
qz{ dr<TO !-fr s q-.f +c{ d Ev u-gn fu-qr qiq.r
2 mr-$ dfur +d ow G fr-a nqdl-q oi q-wft darT Bq{ of r-€fr q !-.+f,
qrr hTd of qft w q.ole drrr{f 3rM dlr
3. sT-$ dfurT i-i Gil{ffi fu rnro or e€s Tq e-{qr {+Ed E{ d ergw
r+rrd frh-qrildr C orqiApT d qnqq qfr-d fr-qr rnrqT
4. (GSr in) fttl o$ zozs-zo C E-r+tqfr H-d-,T @-<;rr erM d-.n
5. GTErqx Rfq d frq,il fi-{ T@rm-{ q* zozz-ze r} 2024_zs n-o or tqT

N

t

t

t

r

t

t

f

G{fr-md e}-qr

t

6 Td fr srrs's q(cnr{ d q-{fl-ft znrufdq q mddfu,T +c ailTffi o-Ei or

fr-.rf, frq q{ o-r Grg,fi qql-ut q{ wgf, o-FrT eTFrqrd e}.n
T. frR-Erqrdr C orA qe fr
r-S eti oell sq-d fr-s-€ frrfi
r

d

fi qrnftu

qrqIaRI { GN-irD--o- qrrrflr d TS eli or qftrflffird qrrq qt qd.q

o-q=rr erFzrrd e)-qr

t

8. frfrqT C eia=T_e{em ftffitS fr u-rgd fuq- qr$,TT, g6 ftTWS- fi sqffi
q-Ffd Glcfwro cftrA-q id qrqri der gq ftTq$ w n-o-ffi trKlci Gifud
fuqT q+JTr r gn ftrmrd fr e-o-++t fr-f,inT d sTfrR-qd qfrTft qrft d sq
q irfrT qlo-zoooo/$rqr or ilo grq-c, Gi ftr{ft .t vl$q-qo +fi 6Rr
Hrfr fuqT TqT Ei qq fu-f,r qd=r q-oiffi, gtwtr d qeqm t qrq.ro fr
griq E)=n, Yq {qt ftffirS fr frfr"ET q-{, ({ qwtq (€qg ylo a-e,
qfrqE-{ uo r+R-o) Tsr wgqT I {s ftrqT+ q-q ffiq qknq Grfua fuqT
flyTT I ss q.Drq q-r.d .rS d ftrEr6 of Tfr frT$r6 q fr srd-d-{
"mr-f,dfu,T +d d frq ft.fr-ET" GrfuT o-{ dqT M
U6{q-( oa e-{gf,
foql cln t I ftfr=Er o-fre Er<T q-{gf, dfrffi frfr-ET q-6-A d"ft ui$.fr,
a-frffi rq t rnhd ftfr-qrfldr mr fr, ffiq frfr"ET trffi qr$.ft wfrI
ffiq e-Kitcr E{qE 3io gq rT-<} fr Grfu-d- Et"fl qrRq,ow GilTffi
7+r+tfo B-q@-q of 5ar d-fr ilRq
e. fr-fuET d rl.rer rr-f,.q {aft q-MZurqrqM rssrffiro et.fl. eillq{fi t
r0.frft-Et t {nnei qrTffiF-df/m-nT @) m-r-$ dfu.I +d q,t GilTffi xoIq-dl
GrTil-Rd rTrffii d GrJsq fu-dr rrf,q orqff,-q, q1qarc d oTqfdu GTetclT
oTqfdq gRT frqfR-d {€lEr dzn frqfRd rrcrq {ft-qT d eilqq qilqT ov ffi
o-{ql etn, Xw+ot 6 qqesi d ergun srxffi q-S frrq qfi of R€{fr ii
{ffiq-a q-} orfr r{* q Gtdfr gv uffi nRr s-< oq fr qr-S-.ft
rr.qR frfuqT d e-hrd Grr[ffim-df7ffier fuft otrurcrqr en-ft sr[ffi q,-{i fr
emqef E\ qrd t, ai sEl R€Tfr t[ qerq r+irc{ sr[ffi/ffifl. of qfr'Itfr
irfrT Gcd ot qd.ft delT sftr ({ q{ fr gqTi r+rnd ftfuqrflET7
Gtr[ffiildf7ffi-m a qtor kqT ur+n
12. frfuil d Blud Htr orqT-taT d qfro^d oTd Et-i/ftfr-qT of qd oT
sdq-q e{Qrcrr oTd d dRTq frrift rft ow d zrT-tft fr.qrE Ei-i of RedR fr
r

r

r

I

frq-eri tg trfmT( q.r+frq qifldq, Rr+.rd or et-qr

t

<!-- page 3 -->

fr frfuET qfi qrd q fr--rT znr{ut- qary, frrifr .ft gflq e=t{ qd
EqqT d qRfid-{ o-{i, frfrET GrTq-rur @1 Rrd fr fr--rT 6nq qary er-{S-qd
o-G eiem frwfl e-{i, ofiox fu-dT frfr<T eft.fr d qrs g{fucr d.qr

13. fu.rrq R-a

r

14.frfuil ft-rTo 02.07.2026 d Grq-iTq-{ 02:30 e-d e.D fu-dt q(wr o-rqfdq,
rrq-T_a d {S-f,ri of qr}.ft Tq H-o 03.02.2026 @i Gil{Eq 04:00 q-d
ftEET efr-ft d TrrsT Gritr rl={E-flf, glfl1-6 d orqfd-tT o&r q trffi
qrS.ft t t fr"fufl-ETdT qqq e+erat B-r-d gRT qrf*E-d qfua frfufl. d qnr d
rro-fr t'r

qle :- frtq qn-rrft tg frrfr ,ft o-rd fu{s fr o-rqff,q t sq-d o-{ orerqr

orqff,q d qil{r qg t st-w fu-{n qp q-6-ilr t

I

*M
{E-ird

I
