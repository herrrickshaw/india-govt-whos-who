---
doc_id: "bcf01dc61af8f1f9"
source_url: "https://jserc.org/pdf/tender_2024b.pdf"
ministry: "Jharkhand State Electricity Regulatory Commission, Jharkhand"
title: "2nd Modification in tender after Pre-Bid Meeting"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "59dbd67e2347a61b"
---

<!-- page 1 -->

2nd Clarification / Modification in respect of the Tender for “Appointment of Consultant for Assistance in Determination of Tariff and
Formulation of Regulations”

Sl No
1

RFP Clause

Tender Document Reference

Clause 3.1
Qualifying Requirement
1.b The bidder must have done at least a single work Qualifying Requirement
of Rs. 50 lakhs or more in the past 3 (each) financial Sl. 1(b)
years (i.e. 1st April, 2021 to 31st March, 2024) of
providing assistance to any government power
Utility (in India) or Electricity Regulatory
Commission in India. The bidder is required to
submit work order and certificate indicating the
value of work awarded in support.

Comments of JSERC

The clause will be read as:
Qualifying Requirement

1.b The bidder must have done
consulting works for a Utility or
Commission of at least Rs. 50
lakhs or more in a financial fear
during last 3 financial years (i.e.
1st April, 2021 to 31st March,
2024). The bidder is required to
submit work order and certificate
indicating the value of work
awarded in support.
