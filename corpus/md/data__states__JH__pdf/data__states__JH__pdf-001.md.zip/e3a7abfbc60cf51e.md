---
doc_id: "e3a7abfbc60cf51e"
source_url: "https://tourism.jharkhand.gov.in/cms/Application/uploadDocuments/Tender/Notification_20250908_202658.pdf"
ministry: "Tourism Department, Jharkhand"
title: "Response to Queries"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "bce1403e34d433d9"
---

<!-- page 1 -->

rt
~~. JHARKHAND TOURISM DEVELOPMENT CORPORATION L
an (A GOVT.OF JHARKHAND UNDERTAKING oe
हे )
Mahatma Gandhi Marg, Ranchi-83400 G2
iTec ISO 9004: 2045 Cortifiod हे!
Registration No.- U63040JH2002SGC0I256
Telephone No.- 065}- हे
reat nasa ste Letter Nox 845/ 2025
ate: 0%: 02025
IC
uw wan race yt
3 विवि ता iuaintonenestana
able Private Sector Player for Operation, Maintenance and
Management of Hotel Prabhat Vihar at Netarhat and Hotel Sarovar Vihar &
Paryatan Vihar at Patratu Jharkhand
REP No. 8i8/JTDCL dated 22.08.2025
Clause
Page No
4.५ Page no. Financial Contributions and | Kindly provide a clear Refer
ae Approvals illustration for calculation of | Annexure 4
2.4.2 . All revenues from the | revenue in line with the clause | & 2 below
Project shall be deposited | stating that the Minimum | for
directly in a bank or banks | Guarantee Revenue shall be | illustration
designated by the Authority | increased by 0% every 3
and in accounts established | years. All. payment
in the name of Owner and|+ Please clarify whether the is exclusive
under the sole control of the | Minimum Guarantee Revenue is of GST and
Authority ("Project Revenue | to be considered inclusive of | GST shall
Accounts") as more | GST or exclusive of GST. be payable
particularly defined over and
« Kindly confirm whether the | above the
revenue will remain fixed for} Minimum
the entire concession period of Guarantee
40 years, except for the 0% | Revenue.
escalation every 3 years? or it
will get extended depending Kindly refer
upon the escalation in every 3 गत हे
i 9, हा ol
years with 0%. oie eh
the RFP.
2. Page no. (ii) Fee for Revenue from | Please clarify whether the | Clause is
57, clause | Associated Activities: the | revenue to be quoted by the | self-
no. 6.2, | Authority shall pay the bidder (for sharing of 80%) explanatory.
46.2.4 . Operator 80% of the gross | should be considered inclusive
(i) revenue (including revenue in | of GST or exclusive of GST.
cash generated and
deposited from Associated
Activities) generated from
Associated Activities.
b) Along with the Fee as
mentioned above, the
Authority shall also pay the
GST at applicable rates to the कि
Operator. के ()
eS) ८2)
3 x B
Saree हज
ee

<!-- page 2 -->

Tt
i Noy
4 Page No c “reuse as per RFp Queries/ Clarification Response
Aa : oe 'nvolved of INR 40,000 Kindly clarify the following: » "Replacement |
or More at one point of time | What is the exact meanini fF oe
in the replacement of fittings, | “at on i ime”: 6 कह of a
: 7 a © point of time”? « In rticula
fixtures & furniture’s or case rep), i i eet
Placement is required | items
janacement of any related during the event, will the entire (fittings,
won st" Moneve the |e a es | ue
Major Maintenance cost does | support कि 7 aoe ae
i rr such major | or
not includes cost of | maintenance? + The clause | replacement
consumables required for day | mentions reimbursement/claim | of any
to day routine maintenance | of expenses by the Operator— related
of the Project Facility please confirm whether | items, civil
reimbursement will be allowed maintenance
only for expenses above works etc.)
=0,000 per instance, or for | is more than
all such major maintenance Rs |
expenses. 40,000.00,
then only it
will be
eligible to be
considered
as major
maintenance
a For
example, if
there is a
need to
replace an
AC and the
AC cost is
more than
२5 0,000,
then it will
be treated
as major
maintenance
Gi | Kindly confirm whether we may | Since _ the
ce use the same Technical Bid | tender has
documents that were submitted | been
in response to the first call of changed, हु
this RFP. Additionally, we | the Bidder is
request the Authority to kindly | required (०
allow us to adjust/consider the | submit
Tender Fee and EMD already Technical
submitted for the first call | Bid ments
against the reissued tender. eral
The tender
fee cannot
be adjusted
and the
- 4 same is
L—_—> Pr
Developing’
Ks vo
(it)
3 Toc oY /
छाए (5

<!-- page 3 -->

ATT 7
Clause TT
s pane No Clause as per RFP | Queries/ Clarification | Response |
| required to
| be |
| submitted
again,
८ however if
the Emo |
| (छत
| | security) in
| the first call
|| is submitted
| |oy way of
| demand
| | draft, the
| | Same can be
——— 2 a | used
| 5. | _ | Revenue Sharing with JTDC: | Kindly refer
The tender does not provide a | the
| clear explanation of the | Annexure १
| revenue sharing model with|& 2 below
JTDC. I request you to kindly | for
| share the detailed structure of | illustration
revenue sharing so that we can |
| understand our responsibilities |
and commitments better.
6. Bidding & Selection | The 7]
Procedure: Authority |
The tender does not adequately | has adopted
outline the detailed bidding | single stage |
procedure and the | two envelop,
selection/evaluation criteria. It | comprising
would be very helpful if JTDC | of Technical
could provide a transparent and | and
step-by-step explanation _ of | Financial |
how the bidding and selection | Bid, towards
will be conducted. selection of
suitable
private
sector
player for
undertaking
the project.
Bidder
having
minimum
eligibility
criteria shall
be evaluated
in line with
Clause 3.2
of the
Volume i of
= *_A_| the RFP.
8६४९०.
‘( it)
3 =
S\ soc /§

<!-- page 4 -->

T क्र
Clause
S| ठ No/ cI.
| Only Bidder
है who
é qualifies the
P minimum
Pe eligibility
y criteria and
whose bids
are found
responsive
Co per
clause 2,23
of the
Volume of
the RFP will
be eligible
for opening
of their
financial bid.
The Bidder
shall submit
its financial
bid in the
format as
attached at
appendix II.
Bidder who
quotes the
lowest
Annual
Authorizatio
n Fee to the
Authority
shall
ordinarily be
declared as
| selected
Bidder.
Revenue Data of Existing | Bidder are
Hotels: advised to
In order to properly assess the | visit JTDCL
viability of investing efforts and | office to see
resources, I request you to/ the revenue
share theannual revenue | details.
details of Hotel Prabhat
Vihar, Netarhat, which is
already operational under
JTDC. This data will help us
evaluate whether the
opportunity is commercially
Dg
No Bank Guarantee. Please | RFP
remove it provisions to
को गे stay :
Zeiten |)
हे it 2
= 3
s
5 ivoc /§,
S 2९०
88000 “2

<!-- page 5 -->

_
हर Clause
##
4 i0 CR turn over to be removed | RFP
A Provisions to
P iO. stay
45% Management fee of the | RFP
| | gross revenue Provisions to
stay
i. No minimum guarantee. Please | RFP
remove it. provisions tc
stay
72, Technical support fee of 4.5 | शि?
lakh Per month during | provisions t
renovation plus stay
हि. Renovation cost is of the | RFP
| | il ay
stay
7.95 tte
हे, ्ब्ः 2,
या
2 ड़
०० (३,
P78
* RancthS,

<!-- page 6 -->

4: 4
का
Gjustration of Revenue Adjustments in ८ Annexure i
© tor the First year of Operations, ‘ase of Minimum Guarantee Revenue of INR .44 crore to the Authori
© Location: Prabhat Vihar at Netarhat Jharkhand uthority
sf an:
Case : Surplus Revenue
Description Annual
Revenue (in Bi Revenue to
Lacs) \dders Revenue to Operator JTDCL
Revenue from Core Activity ——“Tg0 Quote (from JTDCL) (in Lacs) | _ mu) Lacs)
Revenue from Associated|  _ as . ae ae
Activity 400 80% 80 = aan
Total Revenue on 0 चआ | कि
Payment by Operator to} CSS Se
compensate Revenue
deficit of JTDCL (Minimum . = : :
Guarantee Revenue) of 444
lacs
Total Revenue earned by
Respective Party after 280 446
Payment
08५९ 2: 0शी0६ २९५९१७९
Annual Revenue to
Description Revenue (in Bidders Revenue to Operator 3TDcL
Lacs) Quote (from JTDCL) (in Lacs) (in Lacs)
Annual
Revenue (in Bidders Revenue to Operator (from
Lacs) Quote JTDCL) Revenue to JTDC
Revenue from Core Activity t—Se5 [30% 8
7 oe _ 7 7 पा a ee 7 2
Activity se
Total Revenue ee ee |
Payment by Operator to
compensate Revenue 3
deficit of JTDCL (Minimum -
Guarantee Revenue of 444
lacs)
Total Revenue earned by a
Respective Party _ after 240
Payment Ye
r
@
a Loo Sy
s it ८
S| (5
कर 3 |
5. =
Z\ sae /s
PAS,
* Ranch?

<!-- page 7 -->

Anne
Je: ee Adjustments in case of जाता ier
ii ear oO! i
/ for as ne siden Uarantee Revenue of INR 3.i0 crore to the Authority
© tocation: var Vihar and P, a
v Sryatan Vihar at Patratu, Jharkhand
4 Annus SCT
= . nual
Description Revenue (in Bidders Revenue to Operator (from Revenue to
Lacs) Quote JTDCL) JTDCL
Revenue from Core Activity |" 400 | कुछ | Aintacsy | (in Lacs)
Revenue from Associated |} | 420 | 280 |
Activity 200 |
--+-++- 80%
Total Revenue _ छत SY a : Mi का =|
Payment by Operator to|. 7} —— t =o _|
compensate Revenue \
deficit of JTDCL (Minimum \
Guarantee Revenue) of 3i0 \
lacs “al
Total Revenue earned b' 280 320 \
ye |. | \
Respective Party after \
Payment
Case 2: Deficit Revenue
Annual Bidders Revenue to Operator (from मल कर
Description Revenue (in कु IJTDCL) गजणएए
Lacs) Quote (in Lacs) (in Lacs)
\
[ Revenue from Core Activity ee | 245
Activity 200 80% See |
Total Revenue ee 285 _
Payment by Operator to -25 °
compensate Revenue
deficit of JTDCL (Minimum
Guarantee Revenue of 30
lacs)
320
Total Revenue earned by 550 240
Respective Party after
Payment
@
: Ge 2S
हि 3
[J =a \\
2 Q}\
# oS
* Ranchi *
we
