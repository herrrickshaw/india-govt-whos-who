---
doc_id: "bf1477cedfa1acd7"
source_url: "https://forest.jharkhand.gov.in/admin/deptorders/departmental-orders_275.pdf"
ministry: "Department of Forest, Environment & Climate Change, Jharkhand"
title: "SELECTION OF CONSULTANT FOR SETTING UP OF PROJECT MONITORING UNIT(PMU) FOR DEVEL....."
date: ""
pages: 67
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f6fafb36e292807c"
---

<!-- page 1 -->

Executive Director-cum-Member Secretary,
Jharkhand Eco Tourism Authority
Van Bhawan, P.O.-Doranda, Ranchi-834002.
E-mail : membersecretaryjeta@gmail.com
Reference No: 14 /2026

Date: 23/10/2026
Notice Inviting Tender(NIT)

Jharkhand Eco Tourism Authority (JETA), Government of Jharkhand, invites online
applications from eligible and experienced agencies for “SELECTION OF CONSULTANT
FOR SETTING UP OF PROJECT MONITORING UNIT (PMU) FOR DEVELOPMENT OF
ECOTOURISM PROJECTS IN SELECTED FOREST LOCATIONS IN JHARKHAND”.
The document can be downloaded from the website http://jharkhandtenders.gov.in.
Particulars

Details

Mode of Tendering

Online through Jharkhand e-Procurement Portal

Tender Portal

https://jharkhandtenders.gov.in/

Tender Document Fee

₹1,180/- including GST @18% (Non-refundable)

Earnest Money Deposit (EMD)

₹2,00,000/-

RFP Publication Date

27/10/2026 by 10:00 AM

Last Date for Receiving Queries/Clarifications

03/11/2026 by 03:00 PM

Pre-Bid Meeting

06/11/2026, 11:00 AM Onwards at Office of Executive
Director cum CCF, Wildlife, Van Bhawan Doranda , Ranchi

Submission Deadline

17/11/2026 by 05:00 PM

Technical Opening and Presentation

19/11/2026 at 11:00 AM

Financial Opening

20/11/2026 at 11:00 AM

Period of Empanelment

Period of Three (03) Years extendable upto One (01) Year

Address for Communications

Office of Executive Director cum CCF, Wildlife, Van Bhawan
Doranda , Ranchi
Website: https://forest.jharkhand.gov.in/
Email: msjetajhk@gmail.com

●

JETA reserves the right to amend/change the RFP schedule through corrigendum/addendum.

●

JETA reserves the right to amend, modify, withdraw or cancel the RFP process without assigning any reason.

●

Applicants are advised to regularly visit the Jharkhand e-Procurement Portal for corrigenda, addenda,
clarifications and other updates.
Sd/Executive Director-cum-Member Secretary
Jharkhand Eco Tourism Authority

<!-- page 2 -->

SELECTION OF CONSULTANT FOR SETTING UP OF PROJECT MONITORING UNIT
(PMU) FOR DEVELOPMENT OF ECOTOURISM PROJECTS IN SELECTED FOREST
LOCATIONS IN JHARKHAND
E-BID REFERENCE: 14/2026
Date: 23/10/2026

AUTHORITY:
Jharkhand Eco Tourism Authority (JETA)
JETA,
Van Bhawan, Forest Officers' Colony, Doranda, Ranchi, Jharkhand –
834002

WEBSITE: https://forest.jharkhand.gov.in/

Page 1 of 66

<!-- page 3 -->

Contents
1. DISCLAIMER ............................................................................................................................................ 4
1.1

INSTRUCTIONS FOR E-BIDDING ........................................................................................................... 4

1.2

NOTICE INVITING APPLICATIONS ......................................................................................................... 5

2.

INSTRUCTIONS FOR SUBMISSION OF APPLICATION ................................................................................. 7

2.1.

Background ......................................................................................................................................... 7

2.2.

Submission of Bids .............................................................................................................................. 8

2.3.

Schedule of Bidding Process ................................................................................................................ 9

2.4.

Pre-Bid Meeting ................................................................................................................................ 10

2.5.

Bid Due Date (BDD) ........................................................................................................................... 11

2.6.

Amendments to Bid .......................................................................................................................... 11

2.7.

Late Applications ............................................................................................................................... 11

2.8.

Modifications/ Substitution/ Withdrawal of Applications .................................................................. 12

2.9.

Cost of Application ............................................................................................................................ 12

2.10.

Right to reject any or all Applications............................................................................................. 12

2.11.

Bid Process .................................................................................................................................... 13

2.12.

Validity of Applications .................................................................................................................. 13

3.

ELIGIBILITY CRITERIA ............................................................................................................................. 13

3.1.

Conditions of Eligibility ...................................................................................................................... 13

3.2.

Qualification Criteria ......................................................................................................................... 14

4.

EVALUATION OF APPLICATIONS ............................................................................................................ 15

4.1.

Opening and Evaluation of Applications ............................................................................................ 15

4.2.

Tests of Responsiveness .................................................................................................................... 16

4.3.

Evaluation of Experience of the Bidder .............................................................................................. 16

4.4.

EVALUATION PARAMETERS ............................................................................................................... 16

6.

Terms of Tenure for the PMU ................................................................................................................ 20

6.1.

Allocation of Work ............................................................................................................................ 20

6.2.

Performance Security ........................................................................................................................ 20

6.3.

Payments Terms................................................................................................................................ 20

6.4.

Penalty Provision............................................................................................................................... 21

6.5.

Termination ...................................................................................................................................... 21

6.6.

Indemnification ................................................................................................................................. 22

6.7.

Applicable Laws................................................................................................................................. 22

SCHEDULE A: TERMS OF REFERENCE ............................................................................................................. 23
1.

Roles, Responsibilities and Scope of Services of PMU ............................................................................ 23

1.1.

Job Descriptions for the Personnel to be deployed ............................................................................ 24
Page 2 of 66

<!-- page 4 -->

1.2.

General Obligations of the PMU ........................................................................................................ 26

1.3.

Activities excluded from the scope of service of the personnel deployed under the PMU .................. 26

2.

Preparation of Project Reports assigned by JETA ................................................................................... 26

2.1.

Detailed Scope (Including but not limited to) ..................................................................................... 27

2.2.

Situation Analysis and Infrastructure Gap Assessment....................................................................... 28

2.3.

Stakeholder consultations ................................................................................................................. 28

2.4.

Preparation of Site Development Potential Report ............................................................................ 29

2.5.

Regulatory Framework ...................................................................................................................... 29

2.6.

Capacity Building Requirements of Local Communities ...................................................................... 29

FORMATS FOR SUBMISSION OF APPLICATION .............................................................................................. 30
APPENDIX A: FORMAT FOR COVERING LETTER-CUM PROJECT UNDERTAKING .............................................. 30
APPENDIX B: FORMAT FOR DETAILS OF THE BIDDER ..................................................................................... 32
APPENDIX C: FORMAT FOR SIMILAR EXPERIENCE OF THE BIDDER ................................................................. 34
APPENDIX C1: Format for Certificate from Independent /Statutory Auditor of the Bidder ............................. 35
APPENDIX D: FORMAT FOR FINANCIAL CAPACITY OF THE BIDDER ................................................................. 36
APPENDIX E: FORMAT FOR CERTIFICATE FROM INDEPENDENT/STATUTORY AUDITOR OF THE BIDDER ......... 37
APPENDIX F: FORMAT FOR POWER OF ATTORNEY ........................................................................................ 39
APPENDIX G: FORMAT FOR FINANCIAL PROPOSAL ........................................................................................ 41
APPENDIX J : EMD DECLARATION ................................................................................................................. 45
SCHEDULE B: Draft Consultancy Agreement .................................................................................................. 46
APPENDIX K: GENERAL CONDITIONS OF THE CONTRACT ............................................................................... 48

Page 3 of 66

<!-- page 5 -->

1.

DISCLAIMER
The information contained in this Bid or subsequently provided to the bidder, whether verbally or in
documentary or in any other form by or on behalf of Jharkhand Eco Tourism Authority (JETA)
Department of Forests, Government of Jharkhand (herein after referred as JETA) or any of its
employees, is provided to the bidder on the terms and conditions set out in this Bid and such other
terms and conditions subject to which such information is provided.
This Bid is not an agreement or an offer by the JETA to the prospective bidder or any other
person. The purpose of this Bid is to provide bidders with information that may be useful to them
in the formulation & submission of their bids pursuant to this Bid.
This Bid may not be appropriate for all persons, and it is not possible for the JETA and its employees
to consider the objectives, technical expertise and particular needs of each party who reads or uses
this Bid. The assumptions, assessments, statements and information contained in this Bid, may not
be complete, accurate, adequate or correct. Each bidder should, therefore, conduct its own
investigations and analysis and should check the accuracy, adequacy, correctness, reliability and
completeness of the assumptions, assessments and information contained in this Bid and obtain
independent advice from appropriate sources. Information provided in this Bid to the bidders may
be on a wide range of matters, some of which may depend upon interpretation of law. The
information given is not intended to be an exhaustive account of statutory requirements and should
not be regarded as a complete or authoritative statement of law. The JETA accepts no responsibility
for the accuracy or otherwise for any interpretation or opinion on the law expressed herein.
The JETA and its employees/advisors make no representation or warranty and shall have no liability
to any person including any bidder under any law, statutory rules or regulations or tort, principles of
restitution or unjust enrichment or otherwise for any loss, damages, cost or expense which may
arise from or be incurred or suffered on account of anything contained in this Bid or otherwise,
including accuracy, adequacy, correctness, reliability or completeness of the Bid and any
assessment, assumption, statement or information contained therein or deemed to form part of
this Bid or arising in any way in this selection process.
The JETA also accepts no liability of any nature whether resulting from negligence or otherwise
however caused arising from reliance of any bidder upon the statements contained in this Bid. The
JETA may in its absolute discretion, but without being under any obligation to do so, update, amend
or supplement the information, assessment or assumption contained in this Bid.
The issue of this Bid does not imply that the JETA is bound to select a bidder or appoint the selected
bidder as the case may be, for the job and the JETA reserves the right to reject all or any of the
applications/bids without assigning any reasons whatsoever.

1.1 INSTRUCTIONS FOR E-BIDDING
The bidding process for this Bid will be completed online through e-Procurement Portal. The bidder
has to register with his/her Digital Signature Certificate (DSC) in the e-Biding system and
subsequently he/she will be allowed to carry out his/her e-bid submission activities. Registering the
Digital Signature Certificate (DSC) is a one-time activity. Before proceeding to register his/her DSC,
the bidder should first log on to the e- Biding system using the user login option on the home page
with the login id and password with which he/she has registered. For successful registration of DSC
on e-procurement portal https://jharkhandtenders.gov.in/, the bidder must ensure that he/she
should possess class-2/class-3 DSC issued by any certifying authorities approved by the controller of
certifying
authorities,
Government
of
India,
as
the
e-procurement
website
Page 4 of 66

<!-- page 6 -->

https://jharkhandtenders.gov.in/ is presently accepting DSCs issued by these authorities only. The
bidder can obtain user login id and perform DSC registration exercise even before e-bid submission
date starts. The bidder shall be required to use own digital signature while uploading its bid. The
bidder shall be required to upload the bid using its digital signature only. Failure to comply or usage
of digital signature of any other firm shall be liable for rejection of the bid.
The bidders must upload all the required documents (which would form the technical proposal)
electronically in the pdf format, except for the financial proposal, which will be electronically
uploaded on the prescribed BOQ format only on the e- Bid portal https://jharkhandtenders.gov.in/.
It is suggested that the pdf files should be made in grayscale using the minimum readable
appropriate resolution so that the size of the files is minimized for fast uploading on the e-Bid portal
https://jharkhandtenders.gov.in/. The required electronic documents for each document label of
technical (project details, annexures, etc.) Schedules/packets can be clubbed together to make
single label file. The size of single label file should not exceed 40 MB size. The technical presentation
has to be submitted as a part of the Technical Proposal.
Along with uploading the e-bids online, the demand draft towards the Bid fee and the earnest
money deposit (EMD)/EMD Securing Declaration has to be submitted in original (hard copy) in a
separate envelop on or before the last date & time of the Bid submission date at the address given
below. The demand drafts should be drawn in favour of ‘JETA, Government of Jharkhand’, and
payable at ‘Ranchi’, Van Bhawan, Forest Officers' Colony, Doranda, Ranchi, Jharkhand - 834002. Bids
without EMD/ EMD Securing Declaration and documentary proof of such exemption will be
summarily rejected and shall not be considered for further evaluation.
1.2 NOTICE INVITING APPLICATIONS
1.2.1

JETA invites Bids on behalf of the Department of Forests, Environment & Climate Change,
Government of Jharkhand, from eligible Consultants for setting up of PMU for a period of Three (3)
years and more fully detailed in Schedule A through E- Procurement Portal.

1.2.2

Bids are to be submitted through E- Procurement Portal within the last date and time for submission
of Bids. Consultants are required to submit Technical Bid and Financial Bid simultaneously. No
physical submission of Bids shall be accepted.

1.2.3

The Consultant are advised to note the Eligibility criteria and Qualification criteria specified in the
Clause 3.1 & 3.2 of the RFP Document to qualify for award of the Consultancy Agreement.

1.2.4

The Consultant scoring the highest combined score shall be ranked first. The Consultant scoring the
highest combined score shall be declared as selected Consultant for the Assignment in accordance
with the procedures described in this RFP Document.

1.2.5

All notifications, changes and amendments to the RFP Document will be posted only on the EProcurement Portal which shall form part of the Original RFP Document.

1.2.6

Other details can be seen in the RFP documents.

1.2.7

For any additional information or clarification regarding the RFP, the interested Consultant/s, may
contact office of the undersigned at the address given below on all working days during office hours.

1.2.8

JETA reserves the right to accept or reject or cancel any or all the Proposals or to abandon the
procurement without assigning any reasons thereof.
Page 5 of 66

<!-- page 7 -->

1.2.9

Schedule of Bidding Process is as under:
S. NO

DESCRIPTION

DATE/DETAILS
th

1.

Issue of the Bid document on the e- Bid
portal https://jharkhandtenders.gov.in/

2.

Bid fee

INR 1,000 + 18% GST payable in the form of
demand draft, in favour of ‘Jharkhand Ecotourism
Authority’, Payable at Ranchi

3.

Earnest Money Deposit (EMD)

As detailed in Clause 2.1.8

4.

Pre bid meeting [in person/virtually]

5.
6.

Bid Due Date
Opening of Technical Proposal and Opening
of Financial Proposal
Technical Presentation

On 6th November 2026 AT 11.00 am IST at Office
of Executive Director cum CCF, Wildlife, Van
Bhavan, Doranda, Ranchi.
17th November 2026
19th November 2026

7.

27 October 2026

20th November 2026

1.2.10 Consultants who are specifically exempted from submitting the EMD should submit the EMD
Declaration Form as provided in this RFP. Proposals without EMD Declaration and documentary
proof of such exemption will be summarily rejected and shall not be considered for further
evaluation. The place of opening e-bids:
_________________________________________________________________________________
Any queries should be submitted at Office of Executive Director cum CCF, Wildlife, Van Bhavan, Doranda,
Ranchi and msjetajhk@gmail.com with subject: “Bid for Selection of Consultant for Selection of
Consultant for Setting up PMU for Development of Eco-Tourism Projects in Selected Forest
Locations in Jharkhand – queries” before the stipulated date.

Page 6 of 66

<!-- page 8 -->

2. INSTRUCTIONS FOR SUBMISSION OF APPLICATION
2.1. Background
2.1.1.JETA, Government of Jharkhand is continuously endeavoring to promote Eco Tourism in the state by
identifying sites around selected forest areas and plan the development works at already identified
sites. The State is endowed with unique biodiversity and climate which makes the preferred choice
of destination for eco-tourism. Jharkhand is one of the most preferred destinations for tourists,
both inside and outside the country and also strives to ensure accelerated development of tourism
related infrastructure, increasing employment opportunities, augmenting resources of the State as
also showcasing the rich cultural heritage and traditions of the State.
2.1.2.JETA now intends to appoint a Consultant for establishing a Project Management Unit (PMU) at
Department of Forests (the “Eco Tourism PMU”) to assist JETA in facilitating development of Eco
Tourism Projects including but not limited to conducting site surveys, site assessments, stakeholder
consultations, review of regulatory frameworks, environmental compliances leading to preparation
of assessment reports, as per scope provided in the Schedule A: TERMS OF REFERENCE (TOR).
2.1.3.Pursuant thereto, JETA invites eligible Consultants (the “Consultant”) fulfilling the eligibility criteria
as specified in this document to participate in the Bidding Process. The JETA intends to select and
appoint a Project Management Unit (PMU) who shall deploy the required number of personnel with
specific skills and experiences for providing the services described in the TOR- Schedule A.
2.1.4.The PMU is intended to be a self-sufficient team that shall provide the services of a team of
executives and support staff with skills and experience commensurate with the task requirements
to operate from the JETA approved location in Ranchi. The minimum requirement of the personnel
to be stationed at Ranchi is given in ‘Consultant Team Requirements’.
2.1.5.The scope of services to be provided by the PMU shall include and not limited to the services
provided in TOR- Schedule A and shall also be governed by the provisions of the Consultancy
Agreement to be entered into between the selected Consultant and the JETA (the “Consultancy
Agreement”) which sets forth the detailed terms and conditions for grant of the right to the
selected Consultant (the “Right”).
2.1.6.The Bidders shall furnish an Earnest Money Deposit of Rs.2,00,000 (INR 2 Lakhs Only), (the
"Earnest Money Deposit" or “EMD”) in the form of a Demand Draft /FDR/TDR issued by a
Nationalized Bank or a Scheduled Bank in India, drawn in favor of “Jharkhand Ecotourism
Authority’, and payable at ‘Ranchi’, Jharkhand, India” along with the Bids. JETA shall not be liable
to pay any interest on the EMD so made and the same shall be interest free.
.
2.1.7.The EMD amount shall remain valid for a period of 90 (Ninety) days from the Bid due date, or
beyond any period of extension subsequently as determined by JETA from time to time. The Bid
shall be summarily rejected if it is not accompanied by the EMD/EMD Securing Declaration.
2.1.8.The EMD shall be returned to the unsuccessful Bidders within a period of 90 (Ninety) days from the
date of selection of consultants. The successful Consultant is required to replace the EMD with
Performance Security will be equal to 5% of the Total of Personnel Costs as per Appendix G, in the
form of BG as per Schedule K issued by a Nationalized Bank or a Scheduled Bank in India, drawn in
favor of “Jharkhand Ecotourism Authority, and payable at ‘Ranchi’ Jharkhand, India”, with a
validity of the Agreement duration. The EMD/ Application Security Deposit shall be forfeited if the
Bidder:

Page 7 of 66

<!-- page 9 -->

● Furnishes any information or document which is misleading or untrue in any material respect;
● Engages in a corrupt practice, fraudulent practice, coercive practice, undesirable practice or
restrictive practice and
● If the Consultant fails to provide the Performance Security and execute the Contract for with
JETA within the stipulated time or any extension thereof provided by JETA.
2.1.9.Consultant who are specifically exempted for submitting the EMD should submit supporting
documents along with provide a declaration as per Appendix provided in this RFP. The exemption
and relaxation in EMD is subject to the validity & acceptance of the supporting documents by JETA.
2.2.

Submission of Bids

2.2.1. All communications including the submission of Bids should be addressed to:
Jharkhand Eco Tourism Authority (JETA), Van Bhawan, Forest Officers' Colony, Doranda, Ranchi,
Jharkhand – 834002
E-MAIL: msjetajhk@gmail.com
All communications, including the envelopes, should contain the required information, to be
marked at the top in bold letters: “Bid for Selection of Consultant for Setting up a PMU for
Development of Eco Tourism Projects in selected forest locations in Jharkhand”
2.2.2.The issue of this document does not imply that the JETA is bound to select applicants for this RFP
and JETA reserves the right to reject all or any of the applications without assigning any reasons
whatsoever.
2.2.3.The Bidder shall upload each of the following documents as part of the Technical Proposal in the
specified format as provided in the document, on or before the Bid Due Date. The bidder shall
provide all the information as per this RFP document. JETA will evaluate only those proposals that
are received in the required format and are complete in all respects. The bidder shall prepare the
electronic copy for the e-bids (in pdf format) and upload the e-bids on e-Bid portal
https://jharkhandtenders.gov.in/ through the bidder’s digital signature certificate (DSC). The
documents accompanying the Technical Proposal shall include the following:
A. Technical Proposal Documents (Envelope 1)
a. Format For Covering Letter-Cum Project Undertaking in the prescribed format at Appendix A;
b. Details of Bidder in the prescribed format at Appendix B along with supporting documentary proofs;
c. Similar experience of the Bidder in the prescribed format at Appendix C, along with supporting
documentary proofs;
d. Certificate from Independent /Statutory Auditor of the Bidder at Appendix C1
e. Financial capacity of the Bidder in the prescribed format at Appendix D, along with supporting
documentary proofs;
f. Particulars of the Key Personnel in the prescribed format at Appendix E, along with supporting
documentary proofs;
g. Power of Attorney (on stamp paper and duly notarized) for signing of Bids on behalf of the Bidder in
the prescribed format at Appendix F.
h. Comments and Suggestions of Consultant on the Terms of References and Description of the
Methodology and Work Plan for Performing the Assignment in the format prescribed at Appendix
H;
i. Format of Curriculum Vitae of Proposed Key Professional Staff proposed position in the format
prescribed at Appendix I;
j. any other information considered relevant.

Page 8 of 66

<!-- page 10 -->

B. Financial Proposal Documents (Envelope 2)
i. Format for Financial Proposal as per Appendix G
Financial Bid document shall comprise of consultancy/ Monthly fee in the form of lumpsum
quote (the “Consultancy Fee”) for establishing the PMU for development of ecotourism
projects in Jharkhand.
In preparing the Financial Bid, Bidders are expected to take into account the requirements and
conditions of the RFP Documents. The Financial Bid should follow Standard Forms (Appendix G
Form-1 and Form-2). It lists all costs associated with the Assignment, including (a)
remuneration for staff, and (b) other expenses such as subsistence (per diem, housing),
transportation (national and local, for mobilization and demobilization), insurance, surveys and
training, if it is a major component of the Assignment. If appropriate, these costs should be
broken down by activity.
The amount quoted in the Financial Bid shall be without any condition attached or subject to
any assumption and shall be final and binding. In case any assumption or condition is indicated
in the Financial Bid, it shall be considered non-responsive and liable to be rejected.
The duration of the project support consultancy agreement shall be Three Years initially which
may be extended for a further period of One Year. The Consultancy Fee shall be incremented
by 5 (Five) percent of fees after each year of completion of services, on previous year's fees,
provided that the services are continued after satisfactory performance.
All duties, taxes, and other levies payable by the Consultant except GST under the Consultancy
Agreement, or for any other cause, shall be deemed to be included in the amount quoted by
the Consultant.
ii. BOQ
2.2.4.The Bidder should submit a Power of Attorney as per the format enclosed as Appendix F,
authorizing the signatory of the Application to commit the Bidder. The Application must be properly
signed by the authorized representative (the “Authorized Representative”) as detailed below:
(a) In case the sole proprietor himself is signing the Proposals, the Power of Attorney is not required to
be submitted. However, if the Proposals are signed by any other person other than the sole
proprietor, the Power of Attorney is required to be submitted in the format at Appendix F.

(b) by a partner or a duly authorized person holding the Power of Attorney, in case of a partnership
firm or a limited liability partnership firm; or
(c) by a duly authorized person holding the Power of Attorney, in case of a Company.
Applications submitted by fax, telex, or e-mail shall not be entertained and shall be rejected. All
bids are to be submitted online via https://jharkhandtenders.gov.in/. The JETA reserves the right to
seek original documents for verification of any of the documents or any other additional documents
upon opening of the Applications.
2.2.5.The Application and all related correspondence and documents shall be written in English language.
Supporting documents and printed literature furnished by the Bidders along with the Applications
may be in any other language provided that they are accompanied by an appropriate translation in
English language. Supporting materials that are not translated into English may not be considered.
For the purpose of interpretation and evaluation of the application, the English language translation
shall prevail.
2.3.

Schedule of Bidding Process
Page 9 of 66

<!-- page 11 -->

JETA endeavors to adhere to the following schedule:
Sl No

1.

2.

Event
Description
Last
date
for
receiving
queries/clarificati
ons from the
Bidders

Application
Date

4.

Opening
Applications

3rd November, 2026 by 3:00 PM

Office of Executive Director cum CCF, Wildlife, Van Bhavan,
Doranda, Ranchi, Jharkhand – 834002

Details of Pre- Bid
Meeting

3.

Date

Due

Date & Time: 6th November, 2026 at 11:00 am
17th November, 2026

th
of Technical Bid: 19 November, 2026 at 11 AM

Technical Presentation: 19th November, 2026 at 11 AM Onwards
Financial Bid: 20th November, 2026 at 11 AM

5.
6.

Selection of
the
Consultant
Earnest
Money
Deposit

Will be intimated to the Selected Consultant
As detailed in Clause 2.1.8

2.4.
Pre-Bid Meeting
2.4.1.To clarify and discuss issues with respect to the Bid Document, JETA may hold Pre- Bid Meeting on
the date and time indicated in NIT, the Schedule of Bidding Process.
2.4.2.Prior to the Pre-Bid Meeting, the Bidders may submit a list of queries if any. Bidders must formulate
their queries and forward the same to the JETA by the last date of receiving queries mentioned in
Clause 2.3, Schedule of Bid Process in writing or by e-mail to the officer designated in Clause 2.4.6
below. The envelopes/ communication shall clearly bear the following identification/ title:
“Queries/Request for Additional Information: “Bid for Selection of Consultant for Setting up a
PMU for Development of Eco Tourism Projects in Jharkhand”
2.4.3.The responses to queries raised by the Bidders during the Pre- Bid Meeting will be uploaded on the
e-Procurement Portal without identifying the sources. JETA may, in its sole discretion or based on
inputs provided by Bidders that it considers acceptable, amend the Bid Document.
2.4.4.The Bidders may note that the JETA will not entertain any deviations to the RFP at the time of
submission of the Applications or thereafter.
2.4.5.Attendance in the Pre- Bid Meeting is not mandatory for submitting the Application. However,
subsequent to the conference, the JETA may not respond to queries from any agency which has not
participated in the Pre-Application Conference.
2.4.6.All correspondence / enquiries should be submitted to the following in writing by email:
ATTN. OF: The JETA, Van Bhawan, Forest Officers' Colony, Doranda, Ranchi, Jharkhand – 834002
Page 10 of 66

<!-- page 12 -->

E-mail: msjetajhk@gmail.com
The purpose of the meeting will be to clarify issues and to answer questions on any matter that may
be raised at that stage. The Consultant may submit any queries in writing or by email at the mailing
address, prior to the date of Pre-bid meeting.
2.5.
Bid Due Date (BDD)
2.5.1.The bidders should submit their bids online only in the ‘Submission’ module of the e-Bid portal
https://jharkhandtenders.gov.in/. The bids should be submitted only from the bid submission start
date till the bid submission end date and time given in the e- Bid portal
https://jharkhandtenders.gov.in/. Therefore, bidders are advised to submit the e-bids well in time.
2.5.2.All proposals and accompanying documentation will become the property of the JETA and will not be
returned. The bidders should submit their e-bid considering the server time displayed on the e-Bid
portal https://jharkhandtenders.gov.in/. The server time is the time by which the e-bid submission
activity will be allowed till the permissible time on the last/end date of submission of e-bids indicated
in the e-Bid schedule. Once the e-bid submission date and time is over, the bidders cannot submit
their e-bid. The bidders shall only be held responsible for any delay and whatsoever reason in
submission of e-bid. The procedure for submission of e-bids by the bidders on the e-Bid portal
https://jharkhandtenders.gov.in/ is already available on the portal and has also been explained in the
Bid document under ‘instructions for e- Biding’ section.
2.6.
Amendments to Bid
2.6.1.At any time prior to the Application Due Date, as indicated in Clause 2.3, Schedule of RFP, the JETA
may, for any reason, whether at its own initiative or in response to clarifications requested by a
Bidder, amend the RFP document by the issuance of Addenda or amendment. Any Addenda or
amendment issued would be published only in Department of Forests Website and
https://jharkhandtenders.gov.in/; the same shall be binding on the Bidders.
2.6.2.In order to afford Bidders reasonable time to take the Addendum into account, or for any other
reason, the JETA may, at its discretion, extend the Application Due Date. Information about
extension of the Application Due Date will be published only in the Department of Forests Website
and https://jharkhandtenders.gov.in/.
2.7.

Late Applications

2.7.1.The server time indicated in the bid management window on the e-Bid portal
https://jharkhandtenders.gov.in/ will be the time by which the e-bids submission activity will be
allowed till the permissible date and time scheduled in the e-Bid. Once the e-bids submission date
and time is over, the bidder cannot submit his/her bid. Bidder has to start the e-bid submission
well in advance, so that the submission process passes off smoothly. The bidder only, will be held
responsible if his/her e- bids are not submitted in time due to any reasons. It shall be deemed that
prior to the submission of the proposal, the bidder has:

a. Made a complete and careful examination of terms and conditions/requirements, and other
information as set forth in this Bid document.
b. Received all such relevant information as it has requested from the JETA, and.
c. Made a complete and careful examination of the various aspects of the project.
The JETA shall not be liable for any mistake or error or neglect by the bidder in respect of the
above.
Page 11 of 66

<!-- page 13 -->

2.8.

Modifications/ Substitution/ Withdrawal of Applications

2.8.1.Withdrawal: At any point of time, a bidder can withdraw his/her e-bids submitted online before the
e-bids submission end date and time. For withdrawing, the bidder should first log in using his/her
login id and password and subsequently by his/her digital signature certificate on the e
procurement portal https://jharkhandtenders.gov.in/. The bidder should then select ‘My Bids’
option in the ‘Bid Submission’ menu. The page listing all the bids submitted by the bidder will be
displayed. Click ‘View’ to see the details of the bid to be withdrawn. After selecting the ‘Bid
Withdrawal’ option, the bidder has to click ‘Yes’ to the message "Do you want to withdraw this bid"
displayed in the ‘Bid Information’ window for the selected bid. The bidder also has to enter the bid
withdrawing reasons and upload the letter giving the reasons for withdrawing before clicking the
‘Submit’ button. The bidder has to confirm again by pressing ‘OK’ button before finally withdrawing
his / her selected bid. Once the bidder has withdrawn his/her bid he/she cannot re-submit this bid
again.
2.8.2.Resubmission: The bidder can resubmit his/her e-bids as and when required till the bid submission
end date and time. The new bid will replace the e-bids submitted earlier. The payment made by the
bidder earlier will be used for revised e-bids and the new bid submission summary generated after
the successful submission of the revised e-bids will be considered for evaluation purposes. For
resubmission, the bidder should first log in using his/her login id and password and subsequently by
his/her
digital
signature
certificate
on
the
e-Bid
procurement
portal
https://jharkhandtenders.gov.in/. The bidder should then select ‘My Bids’ option in the ‘Bid
Submission’ menu. The page listing all the bids submitted by the bidder will be displayed. Click
‘View’ to see the details of the bid to be resubmitted. After selecting the ‘Bid Resubmission’ option,
click ‘Encrypt & Upload’ to upload the revised e-bids documents by following the methodology
provided in clause submission of e-bids above.
2.8.3.The bidders can submit their revised bids as many times as possible by uploading their e-bids
documents within the scheduled date & time for submission of e- bids. No e-bids can be
resubmitted subsequently after the deadline for submission of e- bids.
2.9.

Cost of Application
The Bidders shall be responsible for all the costs associated with the preparation of their
Applications and their participation in the bid Process including subsequent negotiation, visits to the
JETA, etc. The JETA will not be responsible or in any way liable for such costs, regardless of the
conduct or outcome of the Bid.

2.10.

Right to reject any or all Applications

2.10.1. Notwithstanding anything contained in this Document, the JETA reserves the right to accept or
reject any Application and to annul the bid Process and reject all Applications, at any time without
any liability or any obligation for such acceptance, rejection or annulment, and without assigning
any reasons thereof.
2.10.2. The JETA reserves the right to verify all statements, information and documents submitted by
the Bidder in response to the Bid. Failure of the JETA to undertake such verification shall not
relieve the Bidder of its obligations or liabilities hereunder nor will it affect any rights of the JETA
Page 12 of 66

<!-- page 14 -->

thereunder.

2.11.

i.

ii.
2.12.

Bid Process
Each Bidder shall submit a maximum of one (1) Proposal for the Assignment, in response to this RFP
document. Any Bidder, who submits more than one Proposal for the Assignment shall be
disqualified.
The JETA intends to adopt a QCBS single stage bidding process for selection of the firm for PMU. The
Proposal would be evaluated on the basis of the evaluation criteria set out in this RFP document in
order to identify the successful Bidder (“Successful Bidder”). The Successful Bidder is required to
enter into a Consultancy Agreement with The JETA and the draft of the same is set out in Appendix
J. The fees shall be paid to the PMU by The JETA in the manner as set out in the Draft Consultancy
Agreement.
Validity of Applications

2.12.1.
The applications shall be valid for a period of not less than 120 (one hundred twenty) the
Application Due Date (“Application Validity Period”). The validity of application may be extended
by mutual consent of the respective applicant and the JETA.
2.12.2.
The Consultant is not allowed to modify, vary, revoke or withdraw, the Bid during the original
or extended validity period. Further, during this period, the consultant is expected to keep available
the key professional staff proposed for the assignment.
2.12.3.
In case the last day on which the Bids are to remain valid falls on/subsequently declared a
holiday or closed day for JETA, the Bid Validity shall automatically deemed to be extended to the
next working day.
2.12.4.
A Bid valid for a shorter period than the period specified in Clause 2.12.1 above shall be
rejected by JETA as non-responsive.
2.12.5.
Before the expiry of original validity period, JETA may solicit the Consultant's consent to an
extension of the period of validity. The request and the responses thereto shall be made in writing
or by e-mail or by fax or through E-Procurement Portal. The Earnest Money Deposit/ EMD
declaration shall also be suitably extended. A Consultant may refuse the request without forfeiting
its Earnest Money Deposit. A Consultant granting the request will not be required or permitted to
modify its Bids.
3.

ELIGIBILITY CRITERIA
3.1. Conditions of Eligibility
3.1.1.The Bidders must read carefully the minimum conditions of eligibility (the “Conditions of
Eligibility”) provided herein. Applications of only those Bidders who satisfy the following
Conditions of Eligibility will be considered for evaluation.

A.

The Bidder should be a single business entity (the “Single Business Entity”). A Single Business
Entity shall mean a company incorporated under the Companies Act, 1956 and/ or the Companies
Act, 2013 or a sole proprietorship firm registered under the Proprietorship Act, 1908 or
partnership firm registered under the Indian Partnership Act, 1932 or a Limited Liability
Partnership Firm registered under Limited Liability Partnership Act, 2008.
Page 13 of 66

<!-- page 15 -->

If the Bidder is:
i.
ii.

iii.

B.

The company, should furnish copy of the certificate of incorporation and memorandum of
association as a proof of identity.
A sole proprietorship firm and a Limited Liability Partnership firm should furnish copy of the
registration certificate, GST or IT returns for the last three financial years preceding the
Application Due Date as a proof of identity.
A registered partnership firm should furnish a copy of the IT returns for the last three financial
years preceding the Proposal Due Date, copy of the registration certificate under the registrar of
firms and a copy of the partnership deed executed between the partners as a proof of identity.
Joint Venture or Consortium is not allowed to participate in this Bidding Process.

3.1.2.The Bidder should have been providing consultancy services at least for last 10 years in India,
preceding the BDD (Bid Due Date).
3.1.3.The Bidder should not be barred by JETA or Government of Jharkhand from participating in its
projects and if such bar subsists as on the Application Due Date shall not be eligible to participate
in this bid process.
3.1.4.The Bidder in the last 3 (three) years should have neither failed to perform on any contract, as
evidenced by imposition of a penalty by an arbitral or judicial authority or a judicial
pronouncement or arbitration award against the Bidder, nor been expelled from any
project/provision of service or contract nor have had any contract terminated for breach by such
Bidder.
3.2.

Qualification Criteria
The Bidder should have in the last (10) Financial years preceding the PDD (Proposal Due Date),
undertaken the following category of eligible assignments:
S.No
1

2

3

PQ Criteria
The Bidder should be a single business
entity (the “single business entity”). a
single business entity shall mean a
company incorporated under the
companies act, 1956 and/ or the
companies act, 2013, or partnership firm
registered under the Indian partnership
act, 1932 or a limited liability
partnership firm registered under limited
liability partnership act, 2008 with
minimum 20 years of existence on the day
of the submission of e-bid.
The bidding entity must have minimum
average annual turnover of Rs 50 Crore in
the last three financial years (i.e. 2022-23,
2023-24 and 2024-25).
Category 1: Experience of at least 4
assignments in tourism sector as PMU for
any central / state or their agencies in last

Support Documents
Incorporation Certificate Under
Companies
act 1956/2013, and other applicable
acts.
● Incorporation Certificate
Partnership deeds
● Pan Card & GST details
● Other relevant documents
supporting the
legal status.

CA Certificate / Audited balance
sheets for the last three financial
years (i.e. 2022-23, 2023-24 and
2024-25).
Ongoing and Completed
assignments will be
acceptable by showcasing
Page 14 of 66

<!-- page 16 -->

4

5

6

7

7 years as Lead Consultant. The duration
of each PMU assignment shall not be less
than 12 months and the consultancy fee of
such project should be at least Rs. 1 Cr
excluding taxes;
Category 2: Experience in completion of 5
advisory projects related to Eco-Tourism/
forestry (relevant to Agro-forestry, NonTimber Forest Produce (NTFP), &
Biodiversity Management Plan), ecosensitive zones, and wildlife corridors for
any Central / State Govt Tourism
authority. A completed project will be
considered.
The bidding entity must not be blacklisted
/ terminated /
debarred by any state or central
government or them
agencies and should not have been found
guilty of any
criminal offence by any court of law, in the
last five (5) years.
The bidding entity must minimum 10 years
of experience in government consulting
and advisory domain.
The bidding entity must have branch office
in Ranchi and main office in any other city.

agreements/workorders.

Completion certification from the
authority will be
accepted.

Affidavit (Appendix-E format only)
by the authorized signatory

Ongoing and Completed
assignments will be
acceptable by showcasing
agreements/work orders.
Valid Rent Agreement/Copy of
Latest Electricity Bill/Any other
relevant documentary proof
establishing the same.

Note:
3.2.1.1. Financial Capacity of parent/subsidiary/associate company(ies) of the Bidder would not be
considered for the purpose of evaluation
3.2.1.2. Bidder/Consultant/Firm should submit CA Certificate as documentary proof for Turnover and Networth
4.

EVALUATION OF APPLICATIONS
4.1. Opening and Evaluation of Applications

4.1.1. The JETA shall open the Applications on the date specified in Clause 2.3, Schedule of RfP Process will
be in the presence of the Bidders who choose to attend.
4.1.2. The JETA will examine and evaluate the Applications in accordance with the provisions set out in
this Section 4.
4.1.3. To facilitate evaluation of Applications, the JETA may, at its sole discretion, seek clarifications in
writing from any Bidders regarding its Applications.
4.1.4. Any information contained in the Application shall not in any way be construed as binding on the
Page 15 of 66

<!-- page 17 -->

JETA, its agents, successors or assigns, but shall be binding on the Bidder, if the Bidder is
subsequently selected on the basis of such information.
4.2.

Tests of Responsiveness

4.2.1.Prior to evaluation of Applications, the JETA will determine whether each Application is responsive
to the requirements of the Bid Document. An Application shall be considered responsive only if:
a) it is received by the Application Due Date including any extension thereof pursuant to Clause 2.5.1;
b) it contains the information and documents as requested in the Bid Document;
c) it contains information in the form and formats specified in the Bid Document;
d) it provides the information in reasonable detail. (“Reasonable Detail”) means that, but for minor
deviations, the information can be reviewed and evaluated by the JETA without communication
with the Bidder). The JETA reserves the right to determine whether the information has been
provided in reasonable detail;
e) it does not contain any condition or qualification; and
f) it is not non-responsive in terms hereof.
4.2.2.The JETA reserves the right to reject any Application which is non-responsive and no request for
alteration, modification, substitution or withdrawal shall be entertained by the JETA in respect of
such Application.
4.2.3. Applications which are found to be non-responsive shall be rejected.
4.3.

Evaluation of Experience of the Bidder
All the Bidders whose Applications are found to be responsive as per Clause 4.2.1 and have fulfilled
the Conditions of Eligibility specified in Section 3 shall be ranked on the basis of the marks obtained
in accordance with the parameters set out in the table below:

4.4.

EVALUATION PARAMETERS

Sl.
No.

1

Parameter

Senior Advisor
(Ecotourism)

Evaluation Criteria
PROJECT ADVISORY TEAM (Backstopping)
Masters in Forestry/ Environment/ Rural
development/ Zoology/ Life Science with
minimum 30 years of experience in forestry/
eco-tourism /rural tourism sector. Should
have advised on at least 10 projects related
to preparation of policies, feasibility studies,
DPR preparation, Transaction Advisory and
Program Management for eco-tourism
projects.

Maximum
Marks
5

Page 16 of 66

<!-- page 18 -->

Project Advisor
(Tourism)

2

Bachelor of Architecture/ Civil Engineer/
Tourism with Masters in Architecture/
Planning/ Tourism, with minimum of 20
years of experience in tourism sector. Should
have advised on at least 10 projects related
to preparation of policies, feasibility studies,
DPR preparation, Transaction Advisory and
Program Management for eco/Rural-tourism
projects.

5

Proposed Team (Based out of Client’s Office)

Masters in MBA/ Planning/ Forestry
10 years

1

10

Team Leader
Expert with Experience in development of
Eco Tourism projects across India

Masters in
Tourism/ Architecture/ Planning
8 years

2

Projects Architect

3

Procurement Expert

4

Civil Engineer

5

Tourism Expert

5

District Ecotourism
Consultants (DEC) –
3 Nos.

Architect with experience in working on
projects related to Ecotourism sector
including preparation of concepts, master
plans, detailed designs, BoQs etc.
MBA with B. Tech/ B.E.
5 - 7 years
Preparation of RfPs/ Contract/ bid process
management for selection of contractors for
execution.
BE
5 - 7 years
Experience in Budgeting, Estimation, cost
evaluation, cash flow statements etc.
Bachelor’s Degree in any discipline
5 - 7 years
Experience in tourism/ecotourism planning
and destination development.
Bachelors in any domain
0-2 years

5

5

2.5

2.5

Research Associates/ work experience in
ecotourism.

RELEVANT POJECT EXPEREINCE

Page 17 of 66

<!-- page 19 -->

Experience of at least 4
assignments in tourism sector DOCUMENTARY EVIDENCE: Ongoing and
Category 1 as PMU for any central / state Completed assignments will be acceptable
or their agencies in last 10
by showcasing Letter of award /agreement
years as Lead Consultant. The / contract/work order / completion
duration of each PMU
certificate (The documentary evidence
assignment shall not be less must clearly list the detailed scope of work,
than 12 months, and the
to assess the scale of the project)
consultancy fee of such
project should be at least Rs.
1 Cr excluding taxes;
MARKING:
For 0-2 Projects – 5 marks
For 2-4 Projects – 7.5 marks
Above 4 Projects – 10 marks
Experience in completion of 5 DOCUMENTARY EVIDENCE: Completed
advisory projects related to assignments will be acceptable by
showcasing Letter of award /agreement /
Category 2 Eco-Tourism/ forestry
(relevant to Agro-forestry,
contract/work order and completion
Non-Timber Forest Produce certificate (The documentary evidence
(NTFP), & Biodiversity
must clearly list the detailed scope of work,
Management Plan), ecoto assess the scale of the project)
sensitive zones, and wildlife
corridors for any Central /
State Govt Tourism authority.
A completed project will be
considered.
MARKING:
For 0-2 Projects – 5 marks
For 2-4 Projects – 7.5 marks
Above 4 Projects – 10 marks
Experience of Policy
DOCUMENTARY EVIDENCE: Ongoing and
Development and
Completed assignments will be acceptable
Category 3 implementation support for by showcasing Letter of award /agreement /
Tourism, Forestry and agro- contract/work order / completion certificate
value chain for minimum 5 clearly stating policy development as part of
States, atleast one of the
scope of work or completed activity (The
project should be in
documentary evidence must clearly list the
Jharkhand (Maximum 6
detailed scope of work, to assess the scale of
Projects)
the project)

10

10

15

MARKING:
For 0-3 Projects – 5 marks
For 3-5 Projects – 10 marks
Above 5 Projects – 15 marks

5.

Technical Presentation

Technical Presentation
- Demonstration on Understanding of
the Project (10 marks)
- Approach & Methodology (20 marks)

30

Page 18 of 66

<!-- page 20 -->

Total

(i)
(ii)

100

Note:
All above information should be supported by either a chartered accountant certificate or client
certificate.
The bidder shall be a single entity. Consortium, academic and voluntary organizations are not
eligible to participate in the selection process under this RFP.

4.4.1.The Bidder is required to achieve a minimum score of 70 marks in their technical proposal.
4.4.2.Evaluation of Financial Proposal

(i)

(ii)

Only those Bidders whose Technical Proposals score at least 70 marks out of 100 shall qualify for
further consideration, and shall be ranked from highest to the lowest on the basis of their technical
score (ST) (“Technically Qualified bidders”).
Financial bids of only the Technically Qualified bidders shall be opened for evaluation. Each Financial
Proposal will be assigned a financial score (SF). For financial evaluation, the total cost indicated in
the Financial Proposal will be considered. The JETA will determine whether the Financial Proposals
are complete, unqualified and unconditional. The cost indicated in the Financial Proposal shall be
deemed as final and reflecting the total cost of services. Omissions, if any, in costing any item shall
not entitle the firm to be compensated and liability to fulfil its obligations as per the TOR within the
total quoted price shall be that of the Consultant. The lowest Financial Proposal (FM) will be given a
financial score (SF) of 100 points. The financial scores of other proposals will be computed as
follows:
SF = 100 × FM/F
(F=amount of Financial Proposal)
(a) Combined and final evaluation
- Proposals will finally be ranked according to their combined technical (ST) and financial (SF) scores as
follows:
S= ST × TW + SF × FW
Where S is the combined score, and TW and FW are weights assigned to Technical Proposal and
Financial Proposal that shall be 0.70 and 0.30 respectively.
Selection of Successful Bidder: Final ranking of all proposals shall be done with weightage of 80:20
70:30. Weightage of 70% shall be given to technical competence and 30% to the fee quoted in
financial proposal.

(iii)

4.4.3.

Award of Consultancy

(i)

In the event of acceptance of the Proposal of the Preferred Bidder with or without negotiations, the
authority shall declare the Preferred Bidder as the Successful Bidder. The JETA will notify the
Successful Bidder through a Letter of Acceptance (LoA) that its Proposal has been accepted.

(ii)

The Successful Bidder shall execute the Consultancy Agreement within one week of the issue of LoA
or within such further time as the authority may agree to in its sole discretion. Failure of the
Page 19 of 66

<!-- page 21 -->

a.
b.
(iii)

Successful Bidder to comply with the requirement shall constitute sufficient grounds for the
annulment of the LoA and forfeiture of the EMD. In such an event, the authority reserves the right
to:
either invite the next best Bidder for negotiations; or
take any such measures as may be deemed fit in the sole discretion of the authority, including
annulment of the bidding process.
The selected Project Management Unit shall, not later than 1(one) month from the date of
intimation of its selection as successful Bidder , get the CVs of the team members to be deployed in
Ranchi approved from the JETA, sign the agreement for the PMU and deploy the team members in
Ranchi. If CVs of team member/s is/are not approved, the personnel shall be changed and the CVs
of other personnel/s of required education and experience shall be submitted by the consultant for
approval. Provided further that in the event of any delay in signing the agreement on the part of the
consultant or getting approval of CV of any member or delay in deployment of any team member, a
time extension upto 30 days may be given on written application of the consultant by the Director.

6. Terms of Tenure for the PMU
6.1.1. The PMU shall be valid initially for a period of 3 (three) years. JETA reserves the right to extend
the same on yearly basis up to 1 (one) additional year on the same or mutually agreed terms &
conditions subject to Periodical review of their performance.
6.1.2. JETA will reject the Application of a Bidder, if it determines that the Bidder has, directly or through
an agent, engaged in corrupt, fraudulent, unfair trade, coercive or collusive practices. If any
Bidder/ Key Personnel makes a false averment regarding his qualification, experience or other
particulars, the Bidder and the Key Personnel shall be liable to be debarred for any future
assignments of the State Government for a period of 3 (three) years.

6.1.

Allocation of Work
Mere establishment of PMU with JETA does not guarantee allocation of work. A separate work
order will be issued to the Selected Consultant for each assignment. The Selected Consultant shall
not assign its responsibilities to any other agencies, in whole or in part, to perform its obligation
under the Contract.

6.2.

Performance Security
The Selected Consultant shall for due performance and fulfillment of the terms of the
LOA/Contract furnish to JETA, an unconditional and irrevocable Bank Guarantee as Performance
Security equal to 5% of the Total of Personnel Costs as per Appendix G in the form of BG as per
Schedule K issued by a Nationalized Bank or a Scheduled Bank in India, drawn in favor of “JETA,
Government of Jharkhand’, and payable at ‘Ranchi’Jharkhand, India”, with a validity of the
Agreement duration.

6.3.

Payments Terms

a.
b.

Payment will be made as per the payment milestones stated in the RFP and in
accordance with the terms and conditions of the RFP.
The payment towards the deployment of PMU Personnel shall be made on the monthly
basis.
Page 20 of 66

<!-- page 22 -->

c.

6.4.

6.5.

The total LoA/Work Order Price to be quoted by the Consultant shall be exclusive of
GST, as applicable.

Penalty Provision

a.

In case of delay in execution of the assigned work by the Selected Consultant, JETA may
impose a penalty of 0.2% of the Consultancy Fee payable with respect to each Project
per day or part thereof of delay (subject to maximum of 10.0% of the Consultancy Fee).
If the delay is beyond 3 weeks if attributable to the Consultant then JETA may annul the
assignment and shall be free to get it done from other agencies at the risk and costs of
the appointed agencies.

b.

If any of the services performed by the Agencies fail to conform to the specifications of
the assigned assignment or in the event of failure of the assignment due to indifferent
(such as inadequate interaction with JETA), negligent (such as quality of deliverable not
up to the mark), non-supportive attitude (such as non-engagement of adequate
resources in the prescribed time frame), of the Agencies and JETA decides to terminate
the Contract because of such failure, then a sum equal to 10 % of the Contract Price
shall be recovered from the Agencies. This shall be without prejudice to other remedies
available under law and the Contract with JETA.

Termination

a.

Without prejudice to any other right or remedy it may have, either party may terminate
the Agreement at any time by giving three months advance notice in writing to the
other party.

b.

JETA reserves the right to terminate Agreement in any of following circumstances:

I.

Bidder becomes insolvent, bankrupt, resolution is passed for winding up of the
Bidder’s organization
II.
Information provided to JETA is found to be incorrect;
III.
if the Selected Consultant is found to be engaged in corrupt, fraudulent, unfair trade
practices, coercive or collusive. These terms are defined as follows:
i. "Corrupt practice" means the offering, giving, receiving or soliciting of anything of
value to influence the action of JETA or any personnel in agreement executions.
ii. "Fraudulent practice" means a misrepresentation of facts, in order to influence a
procurement process or the execution of a Contract, to JETA, and includes collusive
practice among applicants designed to establish proposal prices at artificially high or
non-competitive levels and to deprive JETA of the benefits of free and open
competition.
iii. “Unfair trade practices” means supply of services different from what is ordered on,
or change in the Scope of Work which was agreed to.
iv. ”Coercive practices” means harming or threatening to harm, directly or indirectly,
persons or their property to influence their participation in the execution of Contract.
v. “Collusive practices” means a scheme or arrangement between two or more
applicants with or without the knowledge of the JETA, designed to establish prices at
artificial, non-competitive levels;

Page 21 of 66

<!-- page 23 -->

6.6.

6.7.

Indemnification

a.

The Selected Consultant will indemnify JETA against any misuse of brand name, logo
and promotional activities. For any misuse of brand name, logo and promotional
activities, the Selected Consultant themselves will be held responsible. JETA will take
necessary legal actions for such cases.

b.

JETA will not be responsible for any miscommunication or harm caused to any party
because of any misrepresentation of its name and logo by the Selected Consultant.

Applicable Laws

a.

Applicable Law would mean the laws and any other instruments having the force of law
in India as they may be issued and in force from time to time.

b.

All legal disputes between the parties shall be subject to the jurisdiction of the Courts
situated in Ranchi only.

Page 22 of 66

<!-- page 24 -->

SCHEDULE A: TERMS OF REFERENCE

1. Roles, Responsibilities and Scope of Services of PMU
Jharkhand, often referred to as the “Land of Forests,” is endowed with vast natural assets, rich
biodiversity, and a vibrant socio-cultural fabric, making it a high-potential destination for
ecotourism in India. Nearly one-third of the State’s geographical area is under forest cover,
comprising diverse ecosystems such as sal-dominated forests, riverine landscapes, waterfalls, and
wildlife habitats. The State’s protected area network includes Betla National Park, Palamau Tiger
Reserve, around 10 Wildlife Sanctuaries, and the Udhwa Lake Bird Sanctuary (a designated
Ramsar Site), offering a strong foundation for developing nature-based tourism experiences.
Recognizing the need to sustainably harness this potential, the Government of Jharkhand has
established the Jharkhand Ecotourism Authority (JETA) as the nodal institution for planning,
development, promotion, and management of ecotourism in the State. JETA plays a pivotal role in
aligning conservation priorities with tourism development, promoting responsible travel practices,
facilitating community participation, and positioning Jharkhand as an emerging ecotourism
destination. The Jharkhand Ecotourism Policy 2021 further reinforces this vision by emphasizing
integrated destination development, infrastructure enhancement, capacity building, and effective
marketing of ecotourism products.
Despite the availability of significant natural assets and an enabling policy framework, ecotourism
in Jharkhand remains relatively underdeveloped and fragmented. There exists a need for a
structured, mission-driven, and professionally managed approach to identify priority
destinations, develop high-quality visitor infrastructure, create market-oriented tourism products,
strengthen branding and outreach, and ensure community-led livelihood generation. Additionally,
effective coordination across multiple stakeholders—including forest divisions, tourism
departments, private operators, and local communities—remains critical for achieving scalable
impact.
While JETA and the Forest Department possess strong capabilities in conservation and forestry
management, the development and commercialization of ecotourism as a sustainable economic
sector require specialized expertise, dedicated resources, and continuous program management
support. This includes aspects such as destination planning, investment structuring, experience
design, private sector engagement, marketing strategy, capacity building, and monitoring of
outcomes.
In this context, it is proposed to establish a dedicated Ecotourism Project Management Unit
(PMU) to support JETA in driving the State’s ecotourism agenda in a focused, professional, and
outcome-oriented manner. The PMU will act as a strategic and technical arm of JETA, bringing
together multidisciplinary expertise to plan, implement, and scale ecotourism initiatives across
the State. It will play a critical role in transforming Jharkhand’s ecotourism landscape by enabling
sustainable development, enhancing tourist experiences, and generating inclusive livelihood
opportunities for local communities.
The objectives of the establishing the PMU is to assist in:
● Creation of ecotourism assets areas administered by JETA.
● Incentivization of ecotourism facilities
● Development of ecotourism related services
● Ecotourism certification
● Branding, marketing and promotion of ecotourism in Jharkhand.
Scope of Work
The scope of work envisaged to be undertaken by the PMU is as follows:
● Project conceptualization and Master planning of assets created for physical infrastructure.
Page 23 of 66

<!-- page 25 -->

● Preparing Institutional Plan for JETA to carry out Forest and ecotourism related
development activities.
● Reviewing the DPRs submitted by other agencies and consultants to JETA.
● Assisting in selection of consultants, operators, vendors etc by drafting and legal vetting of
EOIs, RFQs, RFPs, contracts, agreements and by assisting in bid process management.
● Assisting in contract management, drafting legal notices to various parties, provide legal
opinion in various project related events / cases, legal vetting of RFPs, contracts, Letter of
awards, work orders etc.
● Providing assistance in Manpower Recruitment Process management for different profiles.
● Project Monitoring of progress of various technical consultants appointed by JETA related
to ecotourism & Forestry projects.
● Coordination with the back-end team and the DTC Personnel deployed at the time of
execution of various DPRs at ecotourism destinations.
● To identify the schemes for availing grants for projects in Jharkhand and assist JETA in all
documentations for applying for such grants.
● To assist JETA in discussion with multilateral and bilateral funding agencies and in
applicable documentation and also in making presentations.
● To conceive public private partnerships projects at identified ecotourism destinations and
facilitate it’s on ground execution.
● To attend meetings and visit other cities to attend meeting, workshop etc.

1.1.

Job Descriptions for the Personnel to be deployed

a) Job Description for the Team Leader
Job responsibility shall include the following:
i.

Assist the back-end team in conceptualization, identification of optimum tourism
products and facilities for the identified sites.

ii.

Lead the PMU team to Conceptualize and prepare master plans with the inputs from
the back-end team.

iii.

Assist the team to write / review the RFP, contracts to check the scope of work /
services during the preparation of Bid documents for selection of contractors/ experts/
sub-consultants/ Project Monitoring Consultants, as required including conditions
precedent, obligation of consultant / contractor and those of JETA.

iv.

Review and approve all drawings prepared by the Team.

v.

Coordinate with the Project Site offices and appointed PMC for the smooth execution of
the project on ground.

vi.

To conceive public private partnerships projects at identified tourism destinations and
facilitate it’s on ground execution.

vii.

Assist JETA in making presentation in different forums.

viii.

Assist JETA in various negotiations with the vendors and contractors.

ix.

Identify the schemes of Government of India and multi-lateral agencies for Jharkhand
for funding projects

x.

Prepare monthly activity schedule and plans

xi.

Undertake other activity as assigned by JETA.

Page 24 of 66

<!-- page 26 -->

b) Job Description for the Project Architect
Job responsibility shall include the following:
i. Undertake preparation of masterplans and architectural drawings and details in

consultation with the Team Leader and the back-end Team.
ii. Undertake Infrastructure Gap Assessment at the project sites along with the

infrastructure expert.
iii. Take up site visits and identify the surveys that need to be undertaken for preparation of

masterplan.
iv. Undertake other activity assigned by the Team Leader.

c) Job Description for Procurement Expert
Job responsibility shall include the following:
i.

Assist in process of Infrastructure Gap Assessment at the Sites

ii.

Assist JETA in any other procurement documentation.

iii.

Assist JETA in evaluation of EoIs, RFQs and prepare evaluation reports.

iv.

Undertake other activity assigned by the Team Leader.

d) Job Description for the Civil Engineer
Job responsibility shall include the following:
i.

Prepare the BOQs and detailed estimates for the projects

ii.

Assist in undertaking all surveys and review the survey report

iii.

Review the structural drawings and GFCs prepared by the PMC.

iv.

Coordinate with the appointed PMC for smooth execution of the project on ground.

v.

To assist in budgeting, analysis, estimation, cost evaluation, expenditure planning,
preparing cash flow statements etc.

vi.

Any other activity assigned by the Team Leader

e) Job Description for Tourism Expert

f)

i.
Support planning and development of ecotourism destinations and tourism products.
ii.
Assist in preparation of tourism development plans and project proposals.
iii.
Support development of sustainable tourism experiences and visitor facilities.
iv.
Coordinate with Government departments, local stakeholders and communities.
v.
Assist in identification of tourism opportunities and potential destinations.
vi.
Support implementation and monitoring of ecotourism projects.
vii.
Provide technical inputs on tourism-related matters to the PMU.
Job Description for District Ecotourism Consultants (DEC)
i.

Data collection pertaining to footfalls, status of infrastructure, other data points
pertaining to tourism and forestry.

ii.

Undertaking infrastructure gap assessment at designated areas.

iii.

Assisting in monitoring of the projects at designated areas.

iv.

Assisting in conducting any further studies on the sites/ designated areas.
Page 25 of 66

<!-- page 27 -->

1.2.

v.

Assistance in stakeholder’s consultations.

vi.

Submission of monthly progress report pertaining to progress made on the designated
sites.

General Obligations of the PMU
(i)

(ii)

(iii)

(iv)
(v)

The personnel shall perform the services and carry out its obligations with all due
diligence, efficiency and economy, in accordance with generally accepted professional
standards and practices, and shall observe sound management practices, and employ
appropriate technology and safe and effective equipment, machinery, materials and
method.
The personnel shall always act, in respect of any matter relating to the Contract or to be
Services, as faithful advises to the JETA, and shall at all times support and safeguard the
JETA’s legitimate interests in any dealings with Sub-Consultants or third parties.
The personnel shall hold the JETA’s interests paramount, without any consideration for
future work, and strictly avoid conflict with other assignments or their own corporate
interest.
The personnel shall individually be responsible for up-keeping the files, records,
documents etc. for projects they are working with
The firm that has formed the PMU will not be allowed to apply or submit proposal in the
activities for which PMU Personnel has been involved in:
● Drafting of RFP/EoI/RFQ
● Drafting of scope of services
● Drafting of eligibility and evaluation conditions/ parameters
● Evaluation of proposals / EoIs / RFQs received

1.3.

Activities excluded from the scope of service of the personnel deployed under the PMU
The following activities shall not be within the scope of PMU:
i.

Traffic survey and studies

ii.

Door to door survey, primary data collection for different survey, studies etc.

iii.

Construction Supervision and Quality Assurance including preparation of GFCs

iv.

Any other activity that is not within the competency of the Consultant

The above activities shall be out of scope of the PMU, however the firm that have deployed the
PMU shall not deny and shall carry out the same within a reasonable time, for which it will be
paid at mutually agreed fees, where the rates are not specifically mentioned in this RFP.
Preparation of Project Reports assigned by JETA
v.

2.

The scope of services to be provided by the Consultant as described below is general but is not
exhaustive i.e., does not mention the entire incidental services required to be carried out. The
services shall be provided all in accordance with true intent and meaning, regardless of whether the
same may or may not be particularly described, provided that the same can be reasonably inferred
there from. The scope of services shall also be governed by the provisions of the contract (the
“Contract/LOA”) to be entered into between the Consultant and JETA which sets forth the detailed
terms and conditions for grant of the right to the Consultant (the “Right”). There may be several
incidental services & assignments, which are not mentioned herein but will be necessary to complete
the work in all respects.
Page 26 of 66

<!-- page 28 -->

The overall intent of the appointment of the PMU is facilitation of holistic development of
sustainable ecotourism/rural tourism projects in Jharkhand. Jharkhand tourism department
envisages development of holistic development of sustainable tourism projects in the state for
promoting community development by providing the alternate source of livelihood to local
community, enhancing biodiversity conservation and sustenance of ecosystems services in
environmentally sensitive areas of the state. The consultants shall advise and facilitate development
of permissible and ecologically sound eco-rural tourism infrastructure. Consultant may be tasked any
other assignments as may be directed by JETA.

2.1.

Detailed Scope (Including but not limited to)
Identification of New and lesser-known areas having eco, rural, agri tourism potential in addition to
popular destinations within Jharkhand.

• The following would be considered for the assessment of development potential
• Accessibility and connectivity
• Disaster vulnerability and development area
• Environment (Protection) Act, 1986, and notifications issued thereunder

•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•
•

including Environment Impact Assessment Notification, various waste
management rules currently in force. In addition, Wildlife (Protection) Act,
1972, Forest (Conservation) Act, 1980, Water (Prevention of Control of
Pollution) Act, 1974 and Air (Prevention and Control of Pollution) Act, 1981
Potential economic sectors for development (eco-rural tourism products) and other related
support infrastructure etc.)
Infrastructure development
Tourism/ natural resources
Existing situation assessment should be done as part of the assessment report which shall
include but not be limited to the following:
Review of existing proposal, sectorial policies, strategies available
Demographic Characteristics
Regional Economic base assessment & Economic sector assessment
Transport sector assessment
Infrastructure and utilities assessment
Geomorphological studies
Environment mapping and its assessment
Heritage and conservation
Base Mapping
Ecosensitivity analysis
Identification of Local Art and craft and ways for its development
Land Bank Assessment for development of Eco Tourism Projects
Land suitability Assessment
Accessibility and Connectivity
• Accessibility and Connectivity Consultant shall study accessibility to the project
destinations. The study shall include analysis of traffic volume and frequency for all
existing transport modes including air, water and road, while projecting the future
scenario.

Page 27 of 66

<!-- page 29 -->

2.2.

Situation Analysis and Infrastructure Gap Assessment

•

The consultant shall carry out demand-supply analysis of the available infrastructure, both
physical and social, and identify gaps in future infrastructure requirements based on
projected population and tourist inflow. The analysis shall identify Strengths, Weaknesses,
Opportunities and Challenges (SWOC) of each component.

•
•
•
•
•
•
•
•
•
•
•
•

2.3.

Assessment of Physical Infrastructure shall include but not limited to
Water Supply (potable) and treatment
Sanitation
Solid waste management
Power (including cooking fuel)
Telecommunication/ ICT
Social Infrastructure assessment shall include but not limited to
Health
Civil Supplies
Security
Disaster Management
The consultant shall also conduct option-analysis and recommend suitable sizing and
configuration for actionable opportunities for development of infrastructure in the
identified project destinations.

Stakeholder consultations

•

The consultant at this stage is required to conduct interactions/ discussions with all
relevant departments/ stakeholders of Jharkhand.

•

The discussions/ interactions should be aimed at validating all the preliminary analysis
done based on the information/ data collected as well as identification of development
potential.

•

The consultant shall also submit a Stakeholder Consultation Report. This report shall spell
out clearly, but not be limited to the following: a) Schedule of Consultations b) List of
Participants c) Methodologies and formats for discussions d) Discussion outcomes

-

Carrying Capacity Study

•

The Consultant shall assess the carrying capacity of the project locations based upon scientific
principles. This shall be based on availability of suitable land, permitted activities etc. Needs of
the local people would be accorded priority while determining carry capacity for tourism
development. The consultant shall also provide a framework for continued monitoring and
evaluation, as well as framework for periodic revision of carrying capacity based on
environmental quality, tourist/resident behavior pattern and technological advancement.
Wherever sites have been specified, carrying capacity would be determined for each of the sites
and its influence zone.

Page 28 of 66

<!-- page 30 -->

2.4.

Preparation of Site Development Potential Report

•

Site Selection Presentation

•

Once the report is finalized by JETA, Government of Jharkhand, the Consultant may be required
to make a presentation defining the rationale for development potential of the in the selected
project sites. The changes as suggested by JETA will be required to be incorporated in the report
and submitted for final approval.

•

After thorough analysis and deliberations with relevant stakeholders, consultants will submit and
present draft site development potential report for holistic development of the short-listed sites
incorporating all the analyses mentioned above paras

•

The draft Site Development Potential report shall also clearly spell out various issues and gaps in
infrastructure, livelihood creation, economic activities, etc. and provide broad recommendations
for mitigating the same. In this regard, the Consultant would also conduct (1) Constructability
Review and (2) Value Engineering session with stakeholders, the details of which would be
provided by the Client at a later date. Constructability is part of the design process.
Constructability reviews during preliminary design consists of (a) viability of constructing the
design as proposed i.e., can it be built in a cost-effective manner or are there better alternative
(b) ensures incorporation of sustainability during construction (material sourcing, recycling,
water usage, storage etc) (c) ensures environmental, health and safety practices as per program
standards. The consultant shall further undertake an assessment of the institutional framework,
statutory clearances/approvals, regulatory roadblocks, legal encumbrances etc. that govern
development proposals envisaged, and will suggest suitable action points on the same.

2.5.

Detailed financial assessment of the identified projects (stand-alone or package) will need to
be undertaken to understand the overall project financial viability. Various assumptions for
revenue, cost and others, including basis which are used by it in the financial model needs to
be clearly highlight in the model.

•

The consultant would undertake overall financial feasibility of the finalized projects as per
the Detailed Project Report of Development. The consultant would bring out various
assumptions for revenue, cost and others, including basis thereof, which are used by it in the
financial model. The analysis shall include all the elements of the project.

Regulatory Framework

•

2.6.

•

The Consultant shall review and assess appropriate institutional, legal and regulatory framework
for development of the Project through different options including the public private partnership
mode.
Capacity Building Requirements of Local Communities

•

The Consultant shall propose list of capacity building activities including training calendar of
subjects proposed to be delivered with the identified stakeholders for building sensitization and
awareness of the proposed projects for further execution.

Page 29 of 66

<!-- page 31 -->

FORMATS FOR SUBMISSION OF APPLICATION
APPENDIX A: FORMAT FOR COVERING LETTER-CUM PROJECT UNDERTAKING
(On the Letterhead of the Bidder)
To
The JETA
Van Bhawan, Forest Officers' Colony, Doranda, Ranchi, Jharkhand – 834002
E-mail: _____________________________
Dear Sir:
Ref: Selection of Consultant for Setting up a PMU for Development of Eco Tourism Projects in Select
Forest Areas of Jharkhand

1.

Being duly authorized to represent and act on behalf of………………………………….
(Hereinafter referred to as “the Bidder”) and having reviewed and fully understood all
of the information provided in the RfP document provided to us by the JETA in respect
of the captioned project, the undersigned hereby submits the Applications in response
to the Bid Document.

2.

I/We have studied the Document carefully and understand that we shall have no claim,
right or title arising out of any documents or information provided to us by the JETA or
in respect of any matter arising out of or concerning or relating to the Bid Process.

3.

This statement is made for the express purpose of qualifying as a Bidder for the
aforesaid Bid.

4.

I/We shall make available to the JETA any additional information it may find necessary
or require supplementing or authenticate the qualification statement.

5.

I/We certify that in the last three years, we have neither failed to perform on any
contract, as evidenced by imposition of a penalty by an arbitral or judicial authority or a
judicial pronouncement or arbitration award, nor been expelled from any project or
contract by any public authority nor have had any contract terminated by any public
authority for breach on our part.

6.

I/We understand that you may cancel the Bid Process at any time and that you are
neither bound to accept any application that you may receive nor to invite the Bidders,
without incurring any liability to the Bidders.

7.

My/Our Application is consistent with all requirements of submission as stated in the
RfP Document or in any of the subsequent communication issued by the JETA. I/We
would be solely responsible for any errors or omissions in our application.

8.

I/We understand that any omission, commission or misstatement in facts provided by
us will make our Application invalid at any time during the Bid Process and the JETA
reserves the right to take appropriate action accordingly.

Page 30 of 66

<!-- page 32 -->

9.

I/We understand that the JETA reserves the right to accept or reject any or all the
Applications and reserves the right to withhold and/or cancel the bid Process without
assigning any reason or otherwise.

10.

I/We hereby irrevocably waive any right which we may have at any stage at law or
howsoever otherwise arising to challenge or question any decision taken by the JETA in
connection with the selection of Consultant, or in connection with the bid Process
itself, in respect of the above-mentioned activities and the terms and implementation
thereof.

11.

I/We agree and undertake to abide by all the terms and conditions of the RfP
Document.

12.

I/We offer a EMD of Rs.
accordance with the RfP Document.

13.

The [Earnest Money Deposit/EMD Declaration] 1 in the required manner is attached.

14.

Notwithstanding any qualifications or conditions, whether implied or otherwise,
contained in my/our Application, I/we hereby represent and confirm that my/our
Application is unqualified and unconditional in all respects.

/- (INR _

Only) to the JETA in

....................................................
Signature of the Authorized Person

....................................................
Name of the Authorized Person

Date

1

……………

Strike out whichever is not applicable.

Page 31 of 66

<!-- page 33 -->

APPENDIX B: FORMAT FOR DETAILS OF THE BIDDER
(On the Letterhead of the Bidder)
Sl No

Particulars

Details

1.

Name of the Bidder

---

2.

Status of the Bidder
(Company,
Sole
Proprietorship, Partnership
Firm,
Limited
Liability
Partnership Firm)

Supporting Documents required
to be submitted along with this
Form

In case of a company
● Attach
a
copy
of
Certificate
of
Incorporation/ Memorandum
of
Association
● Copy of GST certificate
In case of a Sole Proprietorship,
Limited Liability Partnership
Firm)
● Attach a copy of Memorandum
of Association
● Copy of GST certificate

3.

Address of the Bidder:

4.

Bidder Income Tax PAN No.

5.

Bidder GST

In case of a Partnership Firm
● Copy of the IT returns for the
last three financial years
preceding Application Due Date
● Copy of the registration
certificate under the registrar of
firms and
● Copy of the partnership deed
executed between the partners
as a proof of
identity
Address:
Attach a copy of the latest
telephone bill, ownership deed,
Name & Designation lease/ rental agreement, or any
documentary
proof
of the Contact Person: other
evidencing the claim.
Phone No:
Fax No:
Mobile
No.
Email Id:
Attach copy of PAN
Attach copy of Registration
Certificate (if applicable)
GST registration certificate
Page 32 of 66

<!-- page 34 -->

6.

7.

8.

Number of years of
experience
in
tourism/ eco, Ruraltourism sector.
Details of any lawsuits pending
in any of the courts in India or
abroad.
Can you provide a dedicated
team to service JETA? Yes/ No

Page 33 of 66

<!-- page 35 -->

Assignment Name:

APPENDIX C: FORMAT FOR SIMILAR EXPERIENCE OF THE BIDDER
(On the Letterhead of the Bidder)
Country:

Location within Country:

Key professional staff Provided by Your
Firm/entity(profiles):

Name of Client:

No. of Staff:

Address:

No. of Staff-Months;
assignment:

Start Date (Month/Year):

Completion Date (Month/Year):

Name of Associated Consultants, if any:

duration

of

Approx. Value of Services (Rs.__):

No. of Months of Key professional staff,
provided by Associated Consultants:

Name of Senior Staff (Project Director/Coordinator, Team Leader) involved and functions performed:

Narrative Description of Assignment:

Description of Actual Services Provided by Your Staff:

Instructions:
i.
The experience cited must comply with the qualification criteria specified in Clause 3.2 of
the RFP Document.
ii. Experience of parent/subsidiary/associate Company (ies) of the Bidder would not be
considered for evaluation.
iii. Separate Appendix – C is required to be submitted by the Bidder with respect
t
to each assignment for which the Bidder is claiming its experience.
iv.
The experience claimed by the Bidder with respect to each such assignment should be
substantiated with
a. a copy of completion certificate issued by the respective client for each assignment or
satisfactory certificate along with other documents including photographs to
substantiate the claim.
b. Certificate of an Independent/ Statutory Auditor as per format at Appendix below:
v.
The evidence submitted in (iii) shall be considered collectively for evaluation.
Page 34 of 66

<!-- page 36 -->

APPENDIX C1: Format for Certificate from Independent /Statutory Auditor of the Bidder
(On the Letterhead of Independent/Statutory Auditor)
Date:
TO WHOMSOEVER IT MAY CONCERN
We have verified the relevant statutory and other records of M/s
the Bidder] and certify the following activities have been undertaken by

[Name

of
_

[Name of the Bidder]. The details of the client, tenure of the assignment and total fee received
with respect to each assignment are specified in the table below:
S. No

Name of
Assignment

Name of
Client

Address
of Client

Duration

1.

Start Date:
Completion
Date:

2.

Start Date:
Completion
Date :

3.

Start Date:
Completion
Date :

4.

Start Date:
Completion
Date :

5.

Start Date:
Completion
Date :

6.

Start Date:
Completion
Date :

Total Fee
Received
(in Rs)

This certificate is being issued to be produced before___________________, Government of
Jharkhand (JETA), for the “BID FOR SELECTION OF CONSULTANT FOR SETTING UP OF PMU FOR
DEVELOPMENT OF ECO TOURISM PROJECTS IN SELECT FOREST AREAS IN JHARKHAND”

Signature
and
Seal
of
the
Independent/Statutory
Auditor
clearly
indicating his/her membership number

Page 35 of 66

<!-- page 37 -->

APPENDIX D: FORMAT FOR FINANCIAL CAPACITY OF THE BIDDER
(On the Letterhead of the Bidder)
(In INR Crores)
Bidder Type

Annual Turnover
2022-23

2023-24

2024-25

Average Annual
Turnover*

Company
Sole Proprietorship Firm
Partnership Firm
Limited Liability
Partnership
TOTAL
Turnover from consultancy services from Indian Operations
Instructions:

1.

2.

3.
4.

Bidder should provide details of its own Financial Capacity specified in Clause
3.3. Financial Capacity of parent/subsidiary/associate company (ies) of the Bidder
would not be considered for the purpose of evaluation.
Bidder shall attach copies of the balance sheets, financial statements and Annual
Reports for 3 (three) years preceding the Application Due Date (i.e 2019-20, 2020-21
and 2021-22). The financial statements shall:
(a) reflect the financial situation of the Bidder;
(b) be audited by an Independent/statutory auditor;
(c) be complete, including all notes to the financial statements; and
(d) correspond to accounting periods already completed and audited (no statements
for partial periods shall be requested or accepted).
Bidder shall also provide the name and address of the Bankers to the Bidder.
Bidder shall provide an Independent/ Statutory Auditor’s certificate in the format
provided
below
specifying
the
turnover
of
the
Bidder.

Page 36 of 66

<!-- page 38 -->

APPENDIX E: FORMAT FOR CERTIFICATE FROM INDEPENDENT/STATUTORY AUDITOR OF
THE BIDDER
(On the Letterhead of the Independent Auditor / Statutory Auditor)

Date:
We have verified the relevant statutory and other records of M/s
[Name of the Bidder], and certify that the Turnover is as follows:

• Year 1 (2012-23) = Rs
• Year 2 (2023-24) = Rs
• Year 3 (2024-25) = Rs

Crores (INR
Crores (INR
Crores (INR

Crores)
Crores)
Crores)

*Turnover from consulting operations in India
This certificate is being issued to be produced before__________________, Government of
Jharkhand (JETA), for the “BID FOR SELECTION OF CONSULTANT FOR SETTING UP OF PMU FOR
DEVELOPMENT OF ECO TOURISM PROJECTS IN SELECT FOREST AREAS IN JHARKHAND

Page 37 of 66

<!-- page 39 -->

APPENDIX E: Particulars of the Key Personnel Experience
Relevant Experience of the Key Personnel that Best Illustrate Qualifications2
(To be submitted on the letter head of the Consultant)
(Refer Clause 3.3 of the RFP Document)
Name of Key Personnel:
Designation of Key Personnel:
Name of the Assignment:
Name of Consulting Firm where employed:
Description of services performed by
the Key Personnel (including designation):
Name of client and Address:
(indicate whether public or private)
Name, telephone no. and fax no.
of client’s representative:
capital cost of the Project
(in Rs. crore or US$ million):
Start date and finish date of the services
(month/ year):
Brief Description of the Assignment

It is certified that the aforesaid information is true and correct to the best of my knowledge
and belief.
(Signature and name of Key Personnel)
- Comments and Suggestions of Consultant on the TOR and on Data, Services, and Facilities to be
provided by JETA
(Refer Clause _____ of the RFP Document)
On the Terms of Reference:
1.
2.
3.
4.
5.
On the data, services, and facilities to be provided by JETA
1.
2.
3.
4.
5.

2

Prepare details as appropriate for the consultancy assignment.

Page 38 of 66

<!-- page 40 -->

APPENDIX F: FORMAT FOR POWER OF ATTORNEY
(On the applicable value of Stamp Paper)
Power of Attorney

Know all men by these presents, we, ......................................... (Name of Bidder and address of
the registered office) do hereby constitute, nominate, appoint and authorize Mr.
/Ms........................................
son/daughter/wife
and
presently
residing
at........................................, who is presently employed with us and holding the position of
.................... as our true and lawful attorney (hereinafter referred to as the “Authorized
Representative”) to do in our name and on our behalf, all such acts, deeds and things as are
necessary or required in connection with or incidental to submission of our Application for Bid
for Bid for Selection of Consultant for Setting up a PMU for Development of Eco Tourism
Projects in Jharkhand appointed by the JETA, Government of Jharkhand (the “JETA”)
including but not limited to signing and submission of all applications, proposals and other
documents and writings, participating in pre-application conference and other conferences
and providing information/ responses to the JETA, representing us in all matters before the
JETA, signing and execution of all contracts and undertakings consequent to acceptance of our
Application and generally dealing with the JETA in all matters in connection with or relating to
or arising out of our Application for the said Project and/or upon award thereof to us till the
entering into of the Contract with the JETA.
AND, we do hereby agree to ratify and confirm all acts, deeds and things lawfully done or
caused to be done by our said Authorized Representative pursuant to and in exercise of the
powers conferred by this Power of Attorney and that all acts, deeds and things done by our said
Authorized Representative in exercise of the powers hereby conferred shall and shall always be
deemed to have been done by us.
IN WITNESS WHEREOF WE, .................... THE ABOVE NAMED PRINCIPAL HAVE EXECUTED THIS
POWER OF ATTORNEY ON THIS .................... DAY OF
20**
For .......................................
(Signature, name, designation and address)

Witnesses:
1.
2.
Notarised
........................................
(Signature,
name,

,

Accepted
designation

and

address

of

the

Attorney)

Page 39 of 66

<!-- page 41 -->

Notes:
The mode of execution of the Power of Attorney should be in accordance with the procedure, if
any, laid down by the applicable law and the charter documents of the executant(s) and when it
is so required the same should be under common seal affixed in accordance with the required
procedure. The Power of Attorney should be executed on a non-judicial stamp paper of Rs. 100
(Hundred) and duly notarised by a notary public.
Wherever required, the Bidder should submit for verification the extract of the charter
documents and other documents such as a resolution/power of attorney in favour of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of the Bidder.
For a Power of Attorney executed and issued overseas, the document will also have to be
legalised by the Indian Embassy and notarised in the jurisdiction where the Power of Attorney is
being issued. However, Bidders from countries that have signed the Hague Legislation
Convention, 1961 need not get their Power of Attorney legalised by the Indian Embassy if it
carries a conforming Appostille certificate.

Page 40 of 66

<!-- page 42 -->

APPENDIX G: FORMAT FOR FINANCIAL PROPOSAL
(On the letterhead of the Bidder)
FORM 1- SUMMARY OF COSTS (Per Year)
Item No.
I
II
III
IV

Note:
1.
2.

3.

Description3
PERSONNEL COSTS
Remuneration for Professional Personnel
(inclusive of all personal allowances)
Remuneration for Support Personnel
(inclusive of all personal allowances)
Office Consumables like stationery, communication
etc.
Miscellaneous Expenses
Total of Personnel Costs
GST Amount
TOTAL Consultancy Fee (including GST) – Lumpsum

Amount (INR)

Miscellaneous Expenses in Item A IV shall not exceed 15% (fifteen per cent) of the total Cost under
Item A.
Payments will be made as per stipulations of the Special Conditions of Consultancy. The break-up
of cost as given in form-3 is to facilitate assessment of reasonableness of costs and conducting
negotiations in accordance with clause 6 of the Information to Consultant and for determining
remuneration for additional services.
When requested by the Client for the purposes of making payments or part payments, valuing
changes or evaluating claims, or for such other purposes as the Client may reasonably require, the
Consultant shall provide the Client with a breakdown of any composite or lump sum items
included in the Forms.

FORM 2- BREAKDOWN OF COSTS
I.

REMUNERATION FOR PROFESSIONAL STAFF (Per Month)

No.

Position

Name

AI
A1

Remuneration
for
Professional Personnel
(including all personal
allowances)

Name

Mandate
Rate4 (INR)

Total Mandate

Amount (INR)

1.
2.
3.
4.
5.
6.
Sub-Total
3
4

Modify the items as appropriate for the Consultancy Assignment.
Provide the break up of the rates to show the basic salary, social costs and overhead

Page 41 of 66

<!-- page 43 -->

II.

REMUNERATION FOR SUPPORT STAFF(Per Month)

No.

Position

Name

Mandate
Rate5 INR)

Total
Mandate

Amount(INR )

1.
2.
3.
4.
5.
Total :
* Provide the breakup of the rates to show the basic salary, social costs and overhead,
_____________________________
● Prepare details as appropriate for the consultancy assignment

5

Provide the break up of the rates to show the basic salary, social costs and overhead

Page 42 of 66

<!-- page 44 -->

APPENDIX H - Description of the Methodology and Work Plan for Performing the Assignment
(Refer Clause _____ of the RFP Document)
The proposed methodology and work plan shall be described as follows:
1.
Understanding of TOR (not more than two pages)
The Consultant shall clearly state its understanding of the TOR and also highlight its important
aspects. The Consultant may supplement various requirements of the TOR and also make precise
suggestions if it considers this would bring more clarity and assist in achieving the Objectives laid
down in the TOR.
2.
Methodology and Work Plan (not more than three pages)
The Consultant will submit its methodology for carrying out this assignment, outlining its approach
toward achieving the Objectives laid down in the TOR. The Consultant will submit a brief write up
on its proposed team and organisation of personnel explaining how different areas of expertise
needed for this assignment have been fully covered by its Proposal. It would also need to highlight
any innovative ideas and specify/suggest any unique value addition that may be used for the
implementation of the Project. The Consultant should specify the sequence and locations of
important activities, and provide a quality assurance plan for carrying out the Consultancy
Services.
Note:
1. The Consultant will also separately submit the manpower deployment plan proposed.
2. Marks will be deducted for writing lengthy and out of context responses

Page 43 of 66

<!-- page 45 -->

APPENDIX I - Format of Curriculum Vitae of Proposed Key Professional Staff Proposed Position
(Refer to Clause ____ of the RFP Document)
Name of Consultant:
Name of Staff:
Profession:
Date of Birth:
Years with Firm/Entity:
Nationality:
Membership in Professional Societies:
Detailed Tasks Assigned:
Key Qualifications:
[Give an outline of staff member’s experience and training most pertinent to tasks on assignment. Describe
degree of responsibility held by staff member on relevant previous assignments and give dates and locations.
Use about half a page.]
Education:
[Summarize college/university and other specialized education of staff member, giving names of schools,
dates attended, and degrees obtained. Use about one quarter of a page.]
Employment Record:
[Starting with present position, list in reverse order every employment held. List all positions held by staff
member since graduation, giving dates, names of employing organizations, titles of positions held, and
locations of assignments. For experience in last ten years, also give types of activities performed and Client
references, where appropriate. Use about two pages.]
Languages:
[For each language indicate proficiency: excellent, good, fair, or poor; in speaking, reading, and writing ]
Certification:
I, the undersigned, certify that to the best of my knowledge and belief, these data correctly describe me, my
qualifications, and my experience.
Date:
[Signature of staff member and authorized representative of the Consultant] Day/Month/Year
Full name of staff member:______________________________________
Full name of authorized representative: ___________________________
Notes:
1. Use separate form for each Key Personnel
2. Each page of the CV shall be signed in ink by both the Personnel concerned and by the Authorised
Representative of the Consultant firm along with the seal of the firm. Photocopies will not be considered
for evaluation.

Page 44 of 66

<!-- page 46 -->

APPENDIX J : EMD DECLARATION
(To be submitted on the letterhead of the Consultant)
I hereby submit a declaration that the Bid submitted by the undersigned, on behalf of the Consultant
___________ (Name of the Consultant), shall not be withdrawn or modified during the period of validity or
extended period of validity.
I, on behalf of the Consultant ____________( Name of the Consultant), also accept the fact that in case the
Bid is withdrawn or modified during the period of its validity/extended validity period or if we fail to sign the
contract in the case the contract is awarded to us or we fail to submit a Performance Security and additional
performance security, if any, before the deadline fixed in the Request for Proposal, then ___________(
Name of the Consultant) will be debarred for participation in the Selection process for the procurement of
JETA for a period of one year from the date of default.
(Signature of the Authorized Signatory,
Official Seal)

Page 45 of 66

<!-- page 47 -->

SCHEDULE B: Draft Consultancy Agreement

THIS AGREEMENT (“Consultancy Agreement”) is made on the

this day of

2023 at Ranchi.

BETWEEN
Department of Forests, Government of Jharkhand (hereinafter referred to as “JETA” or the "First
Party" which expression shall, unless it be repugnant to the context or meaning thereof, include its
administrators, successors and assigns) of One Part
AND
---------------------firm having its registered office at (hereinafter referred to as the
“Consultant” or the "Second Party") which expression shall, unless it be repugnant to the context or
meaning thereof, include its administrators, successors and permitted assigns) of the Other Part
JETA and the Consultant are collectively referred to as 'Parties' and individually as “Party”.

WHEREAS

A.

Department of Forests (JETA), Government of Jharkhand (The JETA) intended to select and
appoint a Project Support Consultant (PMU) through this RFP for providing services as
described more particularly in scope of services as part of this RFP.

B.

In response to the request for proposal, proposals were received and after evaluating the
same, the Proposal submitted by the Consultant has been accepted and Letter of Acceptance
No. --------------------------- dated was issued.

C.

The Consultant covenants to undertake the Assignment as set forth in the Terms of Reference
(As in Schedule A, hereinafter referred to as “the Services”) and to perform, fulfill, comply
with and observe all and singular provisions, conditions and requirements of this Agreement
by deploying dedicated personnel with specified qualification, experience and skill sets.

D.

In consideration thereof, JETA will pay to the Consultant fee (hereinafter referred to as “the
Fee” As in Appendix G) and will perform, fulfill, comply with and observe all singular
provisions, conditions and requirements to the Agreement.

E.

JETA hereby appoints M/s
the

as the Consultant on the conditions as laid down in

agreement and in the following annexure appended hereto and forming an integral part of
this Agreement and the Consultant accepts the appointment :Appendix E

Qualifications and competence of the key professional staff
Page 46 of 66

<!-- page 48 -->

Appendix G

Fees offered by the consultant and accepted by JETA

Appendix H

Roles, Responsibilities and Broad Scope of Work of Project
Support Consultant (PMU) and Minimum Qualification and
Experience of Expert and Office Assistants
General Conditions of Contract

Appendix K

NOW THIS AGREEMENT WITNESSES that the parties hereto have caused this contract to be signed
in their respective names as on the day and year first above mentioned,
SIGNED, SEALED AND DELIVERED ON THIS DAY AND YEAR FIRST HEREIN ABOVE MENTIONED

JETA, Ranchi, Jharkhand - First Party

By the hands of its authorized signatory
---------------------------------Authorized Signatory of First Party

Name: Designation: Address:
Authorized Signatory of Second Party
Name:
Designation:
Address:
In the presence of:
1.,

Name : Address:
2.

Name

:

Address:

Page 47 of 66

<!-- page 49 -->

APPENDIX K: GENERAL CONDITIONS OF THE CONTRACT
1. RELATIONSHIP BETWEEN THE PARTIES
Nothing contained herein shall be construed as establishing a relation of employer and employee or
agent as between JETA and the Consultant (PMU). The PMU, subject to this Agreement, should have
complete charge of personnel performing the Services and the Consultant shall be fully responsible
for the Services performed by it or on its behalf hereunder. The Agreement shall commence on the
date it is executed by the Parties.
2. DURATION OF THE AGREEMENT
The duration of the project support consultancy agreement shall be 3 (Three) Years initially which
may be extended for a further period of One Year. The monthly fee shall be incremented by 5 (five)
percent of fees after each year of completion of services, on previous year's fees, provided that the
services are continued after satisfactory performance.
3. MODE OF PAYMENT
A.

For Deployment of PMU Personnel to at JETA
(i)

By 10th day of each month the PMU shall raise invoice for the monthly fee for the
previous month, along with the list of works done in the previous month, list of issues /
critical activities, if any and attendance sheet of all personnel showing days of absence,
duly certified by the Project Manager. The fees as approved under the RFP shall be paid
within 15 days from the date of receipt of the invoice, complete in all respect. However,
the first monthly fees shall be paid one month after the actual deployment of the staff at
Ranchi. The fees shall be inclusive of all expenses of the personnel deployed and
overheads & miscellaneous expenses and profit. It shall also be inclusive of all taxes,
surcharges out pocket expenses which may be incurred by the consultant towards travel
within Ranchi, documentation and communication except the GST, which will be paid
separately, as agreed here under.

(ii)

Any travel carried out by the Key Personnel outside Ranchi shall be done as per the
written as per instruction of the Department. The cost of travel, local conveyance, food,
lodging in the host city and out of pocket expenses shall be paid by JETA, provided that
the travel is made with the prior written approval of the _____________ JETA or when
the travel has been made as per the written instruction of JETA. The eligibility for the
travel for the deployed personnel would be economy class airfare or AC 2-Tier for travel,
on actual and the eligibility for lodging and boarding shall be business hotel
accommodation, and commuting expenses as admissible to Class I Officer of the State
Government. JETA would provide in advance suitable amounts to the staff to undertake
the travel, and settle the advances on submission of bills by the PMU personnel.

(iii)

JETA may request visit of any other official of the Consultant’s organization of the PMU
for any expert/ Project Advisor for advice and discussion. For such instances, cost of
travel from the location of such official to Ranchi, cost of local conveyance in Ranchi, cost
of food, accommodation and out of pocket expenses shall be paid by JETA, along with
Page 48 of 66

<!-- page 50 -->

cost of man-days for the visiting personnel for the days spend for such discussions, based
on the cost per man-day for such personnel, which will be stated by the PMU in its
communication, while confirming the dates and name of visiting personnel(s). The
payment shall be made within 7 working days upon on submission of invoice along with
original bills, tickets, boarding passes and supporting documents.
(iv)

The data card, internet connection, phone, scanner, photocopier, fax, printer Color and
Black and white, printer ink, papers, office stationaries and other consumables shall be
provided by the JETA as per the requirement, along with space for the team to operate
from the office of the JETA with lights and office furniture like chairs, tables etc.at its
cost.

(v)

The GST shall be payable extra by JETA at the then prevailing rate on every payment
made to the PMU against invoice, including those for paying the travel cost of any
personnel of the Consultant’s organization.

(vi)

Income tax as applicable shall be deducted at source from every payment, as per
applicable laws.

4. PENALTY FOR DEFAULT
All personnel deployed under PMU shall be eligible for leaves for a cumulative period of 30
working days in a year. The leaves cannot be availed for more than 15 working days at one time.
The Team Members of the PMU shall obtain written approval of the leave from the
____________, JETA.
For any reason whatsoever, if any team member remains absent from duty for a cumulative
period of more than 30 working days in a year or more than 15 working days at one time, the
consultant shall deploy a personnel of equal or higher qualification and experience under
intimation to the Director .
In the event the requirement of additional personnel JETA shall communicate such requirement
to the Consultant in writing. The Consultant shall deploy such personnel with requisite skill set
within 60 days from the date of such communication to the satisfaction of the JETA. The fee for
such personnel shall be paid on pro-rata basis to be calculated on the existing monthly fixed fee
for the PMU.

5. TERMINATION OF THE AGREEMENT
This Agreement shall be effective on the date hereof and shall continue in full force until
completion of the Services or terminated earlier as per the Clause (i), (ii) & (iii) below:
i.

JETA shall have right to review the performance of the PMU and if JETA is not desirous of
continuation of the services of the PMU on ground of unsatisfactory performance or breach of
any term or condition of the contract it may terminate the agreement by giving notice of 30 days
and by providing reasonable opportunity to be heard.
Page 49 of 66

<!-- page 51 -->

ii.

JETA or the PMU may terminate the agreement by giving the termination notice of three months
in advance.

iii.

If JETA terminates the agreement, not as a result of any default by the Consultant, then JETA shall
make the following payments to the Consultant for the Services performed till the date of
termination but no other claim on any ground shall be allowed :a.
b.
c.

remuneration pursuant to Clause 6 for Services satissfactorily performed prior to the
effective date of termination;
reimbursable expenditures pursuant to Clause 6 hereof for expenditures actually incurred
prior to the date of termination; and
in the case of termination pursuant to paragraphs (c), reimbursement of any reasonable cost
incident to the prompt and orderly termination of the Agreement.

The communication of termination of this Agreement shall be by means of written notice
(“Termination Notice”)

iv.

6. RESPONSIBILITIES AND OBLIGATIONS OF THE CONSULTANT
The Consultant shall:
a. provide the Services as set out in Schedule A
b. exercise the degree of skill, care and diligence normally exercised by members of the profession

performing services of a similar nature;
be bound to comply with any written direction of JETA to vary the scope sequence or timing of
the Services; and
d. use all reasonable efforts to inform itself of JETA’s requirements for the Deliverables for which
purpose the Consultant shall consult JETA throughout the performance of the Services.
c.

CONFIDENTIALITY AND PUBLICITY
The Consultant shall treat the details of the output of the assignment and the Services as
confidential and for the Consultants own information only and shall not publish or disclose the
details of the output, deliverables / milestones submitted to JETA or the Services in any
professional or technical journal or paper or elsewhere in any manner whatsoever without the
previous consent in writing of JETA.
1.

Consultants’ Personnel and Sub-Consultant

4.1

Description of Personnel
a) The Consultant shall employ and provide such qualified and experienced Personnel as may be
required to carry out the Services.
b) The titles, agreed job descriptions, minimum qualifications and estimated periods of engagement
in the carrying out of the Services of the Consultants' Key Personnel are described in Appendix C.
The estimate of Personnel costs and man day rates are specified in Appendix C of this Agreement.
Page 50 of 66

<!-- page 52 -->

c) Adjustments with respect to the estimated periods of engagement of Key Personnel set forth in
the aforementioned Appendix-C may be made by the Consultant by written notice to JETA,
provided that: (i) such adjustments shall not alter the originally estimated period of engagement
of any individual by more than 20% (twenty per cent) or one week, whichever is greater, and (ii)
the aggregate of such adjustments shall not cause payments under the Agreement to exceed the
Consultancy Fee set forth in Clause 6.2 of this Agreement. Any other adjustments shall only be
made with the written approval of JETA.
d) If additional work is required beyond the scope of the Services specified in Appendix A, the
estimated periods of engagement of Key Personnel, set forth in the Appendix of the Agreement
may be increased by agreement in writing between JETA and the Consultant, provided that any
such increase shall not, except as otherwise agreed, cause payments under this Agreement to
exceed the Consultancy Fee set forth in Clause 6. 2.
4.2
a.

Approval of Key Personnel
The Key Personnel and Sub-Consultants listed in Appendix C of the Agreement are hereby approved
by JETA. No other Key Personnel and Sub-Consultants shall be engaged without prior approval of
JETA.

b.

If the Consultant hereafter proposes to engage any person as Key Personnel and Sub-Consultants, it
shall submit to JETA its proposal along with a CV of such person. JETA may approve or reject such
proposal within 14 (fourteen) days of receipt thereof. In case the proposal is rejected, the Consultant
may propose an alternative person for the JETA’s consideration. In the event JETA does not reject a
proposal within 14 (fourteen) days of the date of receipt thereof under this Clause 4.2, it shall be
deemed to have been approved by JETA.

4.3

Removal and/or Replacement of Personnel
a. JETA expects all the Key Personnel to be available during implementation of the Assignment.
Substitution of Key Personnel can be allowed in compelling or unavoidable situations only and
substitute shall be of equivalent or higher credentials to the satisfaction of JETA. Such
substitution may ordinarily be limited to not more than 30% of the total Key Personnel, subject to
equally, or better, qualified and experienced personnel being provided to the satisfaction of JETA.
b. Replacement of first 10% of Key Personnel will be subject to reductions of remuneration. The
remuneration is to be reduced, say by 5% of the remuneration which would have been paid to
the original Key Personnel, from the date of the replacement till completion of the Agreement
period. In case of the next 10% replacement, the reduction in remunerations may be equal to say
10% and the third 10% replacement such reduction may be equal to 15% 6.
c. Any further substitution may lead to disqualification of the Consultant or termination of the
Agreement. The Consultant shall provide a substitute within [15] working days in the event of any
Key Personnel leaving the job for the reasons stated above. The delay by the Consultant in
providing a substitute beyond [15] working days will attract pre- agreed liquidated damages@
Rs.500/- per day on the Consultant.

6

In case such percentages are not relevant, or for some other practical considerations, for a particular agreement, the Client may formulate a suitable
mechanism following the given logic, which should be specified in the RFP Document.

Page 51 of 66

<!-- page 53 -->

d. Substitution of the Team Leader will not normally be considered and may lead to disqualification
of the Consultant or termination of the Agreement
e. If JETA finds that any of the Personnel have (i) committed serious misconduct or has been
charged with having committed a criminal action, or (ii) have reasonable cause to be dissatisfied
with the performance of any of the Personnel, then the Consultant shall, at JETA's written request
specifying the grounds therefor, forthwith provide as a replacement a person with qualifications
and experience acceptable to JETA.
f. The Consultant shall have no claim for additional costs arising out of or incidental to any removal
and/or replacement of Personnel.
4.4

Working Hours, Overtime, Leave, etc.
a. The holidays, working hours and the timings for working days shall be in accordance with those
prevailing in JETA.
b. The Consultant Personnel shall not be entitled to be paid for overtime nor to take paid sick leave
or vacation leave except as specified in Appendix C hereto, and except as specified in such
Appendix, the Consultancy Fee shall be deemed to cover these items. Any taking of leave by
Personnel shall be subject to the prior approval by the Contractor who shall ensure that absence
for leave purposes will not affect the continuity of Services.
c. The deployed personnel may have to work on Saturdays, Sundays, holidays and also on extended
hours, to support JETA in the event of contingencies and urgency. For workings on such additional
hours and on holidays no extra payment shall be made to the Consultant.

I.1

Force Majeure

I.1.1

Definition
a) For the purposes of this Agreement, "Force Majeure" means an event which is beyond the
reasonable control of a Party, and which makes a Party's performance of its obligations under the
Agreement impossible or so impractical as to be considered impossible under the circumstances.
Such events may include but not limited to acts of JETA either in its sovereign or agreement
capacity, war, hostilities, acts of the public enemy, sabotage, riots, civil disorder, earthquake,
floods, fire, explosion, storm, revolution, epidemic outbreak, quarantine restrictions and freight
embargoes or other extreme adverse weather conditions, strikes, lockouts or other industrial
action (except where such strikes, lockouts or industrial action are within the power of the Party
invoking Force Majeure to prevent), confiscation or any other action by government agencies.
b) Force Majeure shall not include (i) any event which is caused by the negligence or intentional
action of a Party or such Party’s Sub-Consultant or agents or employees, nor (ii) any event which a
diligent Party could reasonably have been expected to both (A) take into account at the time of
the conclusion of this Agreement, and (B) avoid or overcome in the carrying out its obligations
hereunder.
c) Force Majeure shall not include insufficiency funds or failure to make any payment required
hereunder.
Page 52 of 66

<!-- page 54 -->

I.1.2

No Breach of Agreement
The failure of a Party to fulfill any of its obligations under the Agreement shall not be considered to
be a breach of, or default under this Agreement insofar as such inability arises from an event of
Force Majeure, provided that the Party affected by such an event (a) has taken all reasonable
precautions, due care and reasonable alternative measures in order to carry out the terms and
conditions of this Agreement, and (b) has informed the other Party as soon as possible about the
occurrence of such an event.

I.1.3

Measures to be taken
a) A Party affected by an event of Force Majeure shall take all reasonable measures to remove such
Party’s inability to fulfil its obligations hereunder with a minimum of delay.
b) A Party affected by an event of Force Majeure shall notify the other Party of such event as soon
as possible, and in any event not later than 14 (fourteen) days following the occurrence of such
event, providing evidence of the nature and cause of such event, and shall similarly give notice of
the restoration of normal conditions as soon as possible.
c) The Parties shall take all reasonable measures to minimise the consequences of any event of
Force Majeure.

I.1.4

Extension of Time
Any period within which a Party shall, pursuant to this Agreement, complete any action or task, shall
be extended for a period equal to the time during which such Party was unable to perform such
action as a result of Force Majeure.

I.1.5

Payments
During the period of their inability to perform the Services as a result of an event of Force Majeure,
the Consultant shall be entitled to continue to be paid under the terms of this Agreement, as well as
to be reimbursed for additional costs reasonably and necessarily incurred by them during such
period for the purposes of the Services and in reactivating the Service after the end of such period.

I.1.6

Consultation
Not later than 30 (thirty) days after the Consultant has, as the result of an event of Force Majeure,
become unable to perform a material portion of the Services, the Parties shall consult with each
other with a view to agreeing on appropriate measures to be taken in the circumstances.

I.2

Suspension
JETA may by written notice of suspension to the Consultant, suspend all payments to the Consultant
hereunder if the Consultant fail to perform any of their obligations under this Agreement, including
the carrying out of the Services, provided that such notice of suspension (i) shall specify the nature of
the failure, and (ii) shall request the Consultant to remedy such failure within a period not exceeding
thirty (30) days after receipt by the Consultant of such notice of suspension.

3.1

Insurance to Be Taken out by the Consultant
Page 53 of 66

<!-- page 55 -->

The Consultant (a) shall take out and maintain in the joint name of JETA and the Consultant, and
shall cause any Sub-Consultant to take out and maintain, at their (or the Sub- Consultants', as the
case may be) own cost but on terms and conditions approved by JETA, insurance against the risks,
and for the coverage, as shall be specified in the SCC or any applicable law including Labour Laws;
and (b) at JETA's request, shall provide evidence to JETA showing that such insurance has been taken
out and maintained and that the current premiums have been paid. No insurance shall be cancelled,
modified or allowed to expire or lapse during the term of this Agreement.
3.2

Consultants’ Actions Requiring JETA’s Prior Approval

T
a. entering into a subcontract for the performance of any part of the Services, it being understood
(i) that the selection of the Sub- Consultant and the terms and conditions of the subcontract shall
have been approved in writing by JETA prior to the execution of the subcontract, and (ii) that the
Consultant shall remain fully liable for the performance of the Services by the Sub- Consultant
and its Personnel pursuant to this Agreement;
b. appointing such members of the Personnel not listed by name in Appendix C (“Key Personnel and
Sub- Consultant”), and
c. any other action that may be specified in the SC.
5.1

Services and Facilities
JETA shall make available to the Consultant and the Personnel, for the purposes of the services and
free of any charge, the services, facilities and property described in Appendix D at the times and in
the manner specified in said Appendix D, provided that if such services, facilities and property shall
not be made available to the Consultant as and when so specified, the Parties shall agree on (i) any
time extension that it may be appropriate to grant to the Consultant for the performance of the
Services, (ii) the manner in which the Consultant shall procure any such services, facilities and
property from other sources, and (iii) the additional payments, if any, to be made to the Consultant
as a result thereof at the cost determined by JETA.
OTHER CONDITIONS
a. The Consultant shall deploy the personnel / experts within 30 days from the date of signing of
this agreement. The payment of the monthly fee to the consultant shall be done on pro-rata
based on the actual deployment of the resources.
b. In the event, any contribution required by any of the experts of the Consultant’s organization,
Consultant shall provide such services on mutually agreed terms and conditions. The Consultant
shall arrange to submit such contribution of such expert within 7 days from the date of receipt of
such communication with the necessary documents from JETA.
c. JETA may request review / comments of any expert of the Consultant’s organization on any
document prepared by the PMU. The Consultant shall arrange to submit such contribution of
such expert within 7 days from the date of receipt of such communication with the necessary
documents from JETA. No additional fee shall be paid to the consultant for reviewing and
commenting on any document by an internal expert of the Consultant’s organization.
Page 54 of 66

<!-- page 56 -->

d. In the event JETA desires the Consultant to perform such additional services which are not within
the Terms of Reference, the Consultant shall agree to perform such additional services on such
renegotiated, modified and new terms and conditions as may be mutually agreed by the Parties.
e. JETA shall provide to the Consultant documents/ information/ reports as may be required by the
Consultant to enable it to provide the Services. JETA undertakes and agrees to furnish to the
Consultant from time to time such other documents/ reports/ information in its possession
and/or knowledge as it may consider relevant to perform the Services, as and when such
information is received by/ available with the JETA.

Page 55 of 66

<!-- page 57 -->

f.

All intellectual property conceived, originated, devised, developed or created by the Consultant,
its agents, specifically for the purpose of rendering the Services, shall vest with JETA unless
otherwise agreed, between JETA and the Consultant. JETA as sole beneficial owner shall be
entitled to use such intellectual property for the purpose of the Project

g. Unless otherwise agreed, JETA shall have the copyright on all the reports, documents, maps etc.,
authored, prepared or generated during the course of the Services to be provided by the
Consultant.
7. COMPLIANCE WITH LAWS
The Consultant shall take due care that all its documents comply with all relevant laws and
statutory regulations and ordinances, guidelines in force which includes all laws in force and
effect as of the date hereof and which may be promulgated or brought into force and effect
hereinafter in India including judgments, decrees, injunctions, writs of or orders of any court of
record, as may be in force and effect during the subsistence of this Agreement applicable to the
Consultant.
8. GOVERNING LAW AND JURISDICTION
This Agreement shall be governed by the laws of India. The Courts at Raipur shall have jurisdiction
over all matters arising out of or relation to this Agreement.
9. DISPUTE RESOLUTION
Amicable Resolution
Any dispute, difference or controversy of whatever nature between the Parties, howsoever
arising under, out of or in relation to this Agreement (the "Dispute") shall in the first instance be
attempted to be resolved amicably through discussions between the Parties.
Arbitration
Procedure
Any Dispute which is not resolved amicably within 30 days, the same shall be referred to the sole
arbitration of an independent arbitrator appointed by mutual consent of the Parties, or, failing
such consent within 15 days, by the High Court of Jharkhand, whose decision shall be final and
binding on both the Parties. Such arbitration shall be governed by the Arbitration and Conciliation
Act, 1996 (“Arbitration Act”).
Place of Arbitration
The place of arbitration shall ordinarily be Ranchi but by agreement of the Parties, the arbitration
hearings, if required, may be held elsewhere.
English Language
Page 56 of 66

<!-- page 58 -->

The request for arbitration, the answer to the request, the terms of reference, any written
submissions, any orders and awards shall be in English and, if oral hearings take place, English
shall be the language to be used in the hearings.
Enforcement of Award
The Parties agree that the decision or award resulting from arbitration shall be final and binding
upon the Parties and shall be enforceable in accordance with the provision of the Arbitration Act
subject to the rights of the aggrieved parties to secure relief from any higher forum.
Performance during Dispute Resolution
Pending the submission of and/or decision on a dispute and until the arbitral award is published;
the Parties shall continue to perform their respective obligations under this Agreement, without
prejudice to a final adjustment in accordance with such award
10. SEVERABILITY
In the event that any provision of this Agreement is held to be invalid or unenforceable, the
remaining provisions of this Agreement will remain in full force and effect.
11. WAIVER
Waiver by either Party of any default by the other Party in the observance and performance of
any provision of or obligations under this Agreement:

i
ii
iii

shall not operate or be construed as a waiver of any other or subsequent default hereof or of
other provisions or obligations under this Agreement;
shall not be effective unless it is in writing and executed by a duly authorised representative of
such Party; and
shall not affect the validity or enforceability of this Agreement in any manner.
Neither the failure by either Party to insist on any occasion upon the performance of the terms,
conditions and provisions of this Agreement or any obligation hereunder nor time or other
indulgence granted by a Party to the other Party shall be treated or deemed as waiver/breach of
any terms, conditions or provisions of this Agreement.

12. MODIFICATION
Modification of the terms and conditions of the Agreement, including any modification of the
scope of the Services, may only be made by written agreement between the Parties.
13. NOTICES
Unless otherwise stated, notices to be given under this Agreement including but not limited to a
notice of waiver of any term, breach of any term of this Agreement and termination of this
Agreement, shall be in writing and shall be given by hand delivery, recognized courier, mail, telex
or facsimile transmission and delivered or transmitted to the Parties at their respective addresses
mentioned hereinabove.
Page 57 of 66

<!-- page 59 -->

14. TRANSFER OR ASSIGNMENT
No Party may assign its interests in the Agreement without the prior written consent of the other
Party. Unless specifically stated to the contrary, in any written consent to an assignment, no
assignment shall release or discharge the assignor from any obligation under this Agreement.

15. VARIATIONS
JETA may, by written notice to the Consultant, direct the Consultant to vary the scope, sequence
or timing of the Services with suitable compensation for such variation to be agreed mutually and
the Consultant shall be bound to comply with that direction.

Page 58 of 66

<!-- page 60 -->

Schedule 1: Scope of service of the PMU

To be appended before signing of the Agreement

Reference

invited

to

Appendix

J

to

the

RFP

Page 59 of 66

<!-- page 61 -->

Schedule 2: Financial Bid of the PMU

To

be

appended

before

signing

of

the

Agreement

Page 60 of 66

<!-- page 62 -->

Schedule 3: Name of the Key personnel of the PMU to be deployed at office of JETA

Name of the Project Manager: To be appended before signing of the Agreement

Name and designation and key personnel of the PMU to be deployed at office of JETA: To be appended

Page 61 of 66

<!-- page 63 -->

Schedule 4: Letter of Award issued

To

be

appended

before

signing

of

the

agreement

Page 62 of 66

<!-- page 64 -->

Schedule 5: Services and Facilities to be provided by JETA
[List here under:

Services, facilities and property to be made available to the Consultant by JETA.]

Page 63 of 66

<!-- page 65 -->

Schedule 6: Form of Bank Guarantee for Performance Security Deposit
(PROFORMA OF BANK GUARANTEE)7
To
_____________________________________ [name]
_____________________________________ [address]
WHEREAS________________________________________[name and address of Consultant] (hereafter
called the “Consultant”) has undertaken, in pursuance of Letter of Acceptance (LOA) No.
_______________Dated_____________ for ____________[name of the Services] (hereinafter called the
“Services”).
AND WHEREAS the Agreement requires the Consultant to furnish an {Performance Security/ Additional
Performance Security} for due and faithful performance of its obligations, under and in accordance with the
Agreement, during the {Agreement Period} in a sum of Rs….. cr. (INR ………..….. crore) (the “Guarantee
Amount”8).
AND WHEREAS we, ………………….. through our branch at …………………. (the “Bank”) have agreed to furnish this
Bank Guarantee (hereinafter called the “Guarantee”) by way of Performance Security.
NOW, THEREFORE, the Bank hereby, unconditionally and irrevocably, guarantees and affirms as follows:
1. The Bank hereby unconditionally and irrevocably guarantees the due and faithful performance of the
Consultant ‘s obligations during the {Agreement Period} under and in accordance with the Agreement, and
agrees and undertakes to pay to JETA, upon its mere first written demand, and without any demur,
reservation, recourse, contest or protest, and without any reference to the Consultant, such sum or sums up
to an aggregate sum of the Guarantee Amount as JETA shall claim, without JETA being required to prove or
to show grounds or reasons for its demand and/or for the sum specified therein.
2. A letter from JETA, under the hand of an officer not below the rank of [______], that the Consultant has
committed default in the due and faithful performance of all or any of its obligations under and in
accordance with the Agreement shall be conclusive, final and binding on the Bank. The Bank further agrees
that the Client shall be the sole judge as to whether the Consultant is in default in due and faithful
performance of its obligations during and under the Agreement and its decision that the Consultant is in
default shall be final and binding on the Bank, notwithstanding any differences between JETA and the
Consultant, or any dispute between them pending before any court, tribunal, arbitrators or any other
authority or body, or by the discharge of the Consultant for any reason whatsoever.
3. In order to give effect to this Guarantee, JETA shall be entitled to act as if the Bank were the principal
debtor and any change in the constitution of the Consultant and/or the Bank, whether by their absorption
with any other body or corporation or otherwise, shall not in any way or manner affect the liability or
obligation of the Bank under this Guarantee.
4. It shall not be necessary, and the Bank hereby waives any necessity, for JETA to proceed against the
Consultant before presenting to the Bank its demand under this Guarantee.
5. JETA shall have the liberty, without affecting in any manner the liability of the Bank under this Guarantee,
7
8

To be issued by a Scheduled Bank in India only
Guarantee Amount for Performance Security shall be calculated as per Contract

Page 64 of 66

<!-- page 66 -->

to vary at any time, the terms and conditions of the Agreement or to extend the time or period for the
compliance with, fulfillment and/ or performance of all or any of the obligations of the Consultant contained
in the Agreement or to postpone for any time, and from time to time, any of the rights and powers
exercisable by JETA against the Consultant, and either to enforce or forbear from enforcing any of the terms
and conditions contained in the Agreement and/or the securities available to JETA, and the Bank shall not be
released from its liability and obligation under these presents by any exercise by the JETA of the liberty with
reference to the matters aforesaid or by reason of time being given to the Consultant or any other
forbearance, indulgence, act or omission on the part of JETA or of any other matter or thing whatsoever
which under any law relating to sureties and guarantors would but for this provision have the effect of
releasing the Bank from its liability and obligation under this Guarantee and the Bank hereby waives all of its
rights under any such law.
6. This Guarantee is in addition to and not in substitution of any other guarantee or security now or which
may hereafter be held by JETA in respect of or relating to the Agreement or for the fulfillment, compliance
and/or performance of all or any of the obligations of the Consultant under the Agreement.
7. Notwithstanding anything contained hereinbefore, the liability of the Bank under this Guarantee is
restricted to the Guarantee Amount and this Guarantee will remain in force for the period specified in
paragraph 8 below and unless a demand or claim in writing is made by JETA on the Bank under this
Guarantee all rights of JETA under this Guarantee shall be forfeited and the Bank shall be relieved from its
liabilities hereunder.
8. The Guarantee shall cease to be in force and effect on **** . Unless a demand or claim under this
Guarantee is made in writing before expiry of the Guarantee, the Bank shall be discharged from its liabilities
hereunder.
9. The Bank undertakes not to revoke this Guarantee during its currency, except with the previous express
consent of JETA in writing, and declares and warrants that it has the power to issue this Guarantee and the
undersigned has full powers to do so on behalf of the Bank.
10. Any notice by way of request, demand or otherwise hereunder may be sent by post addressed to the
Bank at its above referred branch, which shall be deemed to have been duly authorized to receive such
notice and to effect payment thereof forthwith, and if sent by post it shall be deemed to have been given at
the time when it ought to have been delivered in due course of post and in proving such notice, when given
by post, it shall be sufficient to prove that the envelope containing the notice was posted and a certificate
signed by an officer of JETA that the envelope was so posted shall be conclusive.
11. This Guarantee shall come into force with immediate effect and shall remain in force and effect for up to
the date specified in paragraph 8 above or until it is released earlier by JETA pursuant to the provisions of the
Agreement.
12. This Guarantee is subject to the Uniform Rules for Demand Guarantees (URDG) 2010 Revision, ICC
Publication No. 758, except that the supporting statement under Article 15(a) is hereby excluded.
Signed and sealed this ………. day of ……….., 20……… at ………..
SIGNED, SEALED AND DELIVERED
For and on behalf of the Bank by:
(Signature)
(Name)
(Designation)
Page 65 of 66

<!-- page 67 -->

(Code Number)
(Address)

Schedule 7: Final version of the RFP document

To be appended before signing of the Agreement

Page 66 of 66
