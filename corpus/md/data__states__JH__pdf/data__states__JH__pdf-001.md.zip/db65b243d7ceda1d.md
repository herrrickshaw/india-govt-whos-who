---
doc_id: "db65b243d7ceda1d"
source_url: "https://cdn.s3waas.gov.in/s310a7cdd970fe135cf4f7bb55c0e3b59f/uploads/2025/09/17573287727304.pdf"
ministry: "Garhwa"
title: "Agriculture_Tender (5 MB)"
date: ""
pages: 22
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "c3ec784a0f153f92"
---

<!-- page 1 -->

To,
District Horticulture Officer,
Garhwa
Ref: Your E.O.URFP notice 90.-.........ceeeseeeerece SH DACOG. ce seseereaereceneeeeeee
Subject: Submission of financial proposal of the E.O.VRFP for floral garden in vacant land/
terrace available with households in urban areas and adjoining urban areas & government
premises in the District under Horticulture Department, Govt. of Jharkhand.
Sir,
I! we do hereby propose rates for floral garden in vacant land/ terrace available with households
in urban areas and adjoining urban areas & government premises in the district Garhwa in accordance
with the opecifications mentioned in the £.0./RFP document in all respects and instructions in the
annexures.
S. | Particulars | Description | Pot Rate
No. size Quotation
Rs.)
| | Foliage and Shade Loving Plants. |) | J]
Aglaonema | Parrot 25cm
Jungle plant | size of
(three in Earther
one), having} pot /
ht. 30 om Plastic
and pot
above with
20 to 25
leaves,
dove 25cm | Each
variety size of
having ht. Earthen}
30 cm to pot /
45 cm with Plastic
8 to 40 pot
leaves
3 Pseudo 25 Each
‘ bractatum | cm
plants, size
having ht. 30} of
cm and Eart
above with 3) hen
to 4 suckers | pot
& 20 to I
25 leaves Pla
stic
pot
Aglaonema | 20cm
marentifoliu | size of
m Earthe!
pot /
l|Page

<!-- page 2 -->

:
variety Plastic
having ht. | pot
23 था 0
30 cm with
8 to 0
leaves

Araucaria Araucaria | 20 Each
cookie cm
havinght. | size
60 cm to of
75 cm, Eart
straight, hen
well pot
developed, | /
fresh and Pla
healthy stic
with luch pat
green
leaves
from
bottom to
top
Araucaria | 25 Each
cookie om
having ht. size
75 cm to of
90 cm, Eart
straight. hen
well pot
developed, | /
fresh and Pla
healthy stic
with lush pot
green
leaves

7 Areca Palm | Areca 25

HI Palm om
having ht. size
90 cm to of
.20m Eart
with4to5 | hen
suckers, pot
fresh and /
healthy Pla
with lush आए
green foliage| pot.
Areca 25
Paim cm
havinght. | size
7.20 m to of
7.50m Eart
with 5to6 | hen
suckers, pot
fresh and i

2|Page

<!-- page 3 -->

with lush stic
green foliage) pot.
9 Areca 25 Each
न palm cm
having ht. size
7.50 m to of
4.80 m Eart
with 6to8 | hen
suckers, pot
well /
developed, | Pla
fresh and stic
healthy pot.
with lush
| een foliage!
40 Croton Croton 20 Each
= Challenger | cm
variety size
having ht. of
30cmand | Eart
above, well | hen
developed | pot
with fullof | /
fresh and Pla
healthy stic
leaves. pot.
44 Croton baby | 20
x golden em
variety size
having ht.30 | of
cm and Eart
above, hen
well pot
developed | /
with fullof | Pla
fresh and | sti
healthy pot
leaves.
Croton Baby] 25 Each
Golden plant} cm
(three in size
one), having | of
ht. Eart
30cm, multi} hen
branches, | pot
well !
developed | Pla
with fresh sic
and por
es ||
3|Page

<!-- page 4 -->

43. Croton Golden (Broad Leaves) having | 25 cm size of Each
ht. 60 cm to 75 cm with 3 to 4 Earthen pot /
branches, well developed, fresh and Plastic pot.
healthy leaves.

44. Croton Duck Foot (Elite) having ht. 45 | 25 cm size of
cm and above with 3 to 4 branches, Earthen pot /
well developed, fresh and healthy Plastic pot.
leaves.

i5. Croton Petra having ht. 45 cm & 25cm sizeof | Each
above with 2 to 3 branches, well Earthen pot /
developed, Plastic pot.

Tresn and healthy leaves.
Dieffenbachi| Dieffenbachia Tropic-snow having ht. | 25 cm size of
a 60 cm & above with 8 - 0 leaves, Earthen pot /
well Plastic pot.
developed, fresh & healthy.

Ww. Dieffenbachia Mosaic having ht. 30cm | 25 om size of Each
to 45 cm with 0-72 leaves, well Earthen pot /
developed, fresh and healthy Plastic pot.
Dieffenbachia Maculata having ht. 45 | 25 cm size of
cm to 60 cm with 5 and above leaves, | Earthen pot /
well developed, fresh and healthy & Plastic pot.
attractive
variegated foliage.

Dracaena Dracaena ‘Song of India’ piant(three | 25 cm size of
in one), having ht. 30 cm and above, Earthen pot /
multibranched, well Plastic pot.
developed with fresh and healthy
leaves.

20. Dracaena ‘Song of India’ variegated 20 cm size of
having ht. 30 cm to 45 cm, well Earthen pot /
developed, Plastic pot.
fresh & healthy foliage with bright
leaves.

24. Dracaena Kedarnath having ht. 30cm | 20cmsizeof | Each
& above, well developed with good Earthen pot /
colorful foliage. Plastic pot.

Dracaena Marginata having ht. 30cm | 20cm size of
to 45 cm with colorful leaves, fresh Earthen pot /
and Plastic pot.
healthy.

23. Dracaena Mahatma having 20 cm size of Each
ht. 30 cm to 45 cm, well Earthen pot /

4|Page

<!-- page 5 -->

कि developed, fresh and healthy | Plastic pot.
foliage.

24. Dracaena Rosea having hl. | 20 cm size of
30 cm & above with 8 to0 Earthen pot /
leaves, well developed, fresh | Plastic pot.
and healthy in.

Dracaena Victoria having ht. | 25 cm size of
30 cm & above. well Earthen pot /
developed with full of Plastic pot.
leaves, fresh and healthy in

Dracaena 25 cm size of
Fragrans’Massangeana” Earthen pot /
having ht. 30 cm & above Plastic pot.
with full of leaves, well

developed, fresh and healthy

27. Dracaena Warneckii having | 20 cm size of
ht. 30 cm to 45 cm. with Earthen pot /
goed colour foliage, well Plastic pot.
developed, fresh and
healthy.

Livistona Palm Livistona Palm having ht. 30 | 25 cm size of
cm to 45 cm, well developed | Earthen pot /
with 5 to 6 leaves, fresh & Plastic pot
healthy foliage

29. | Money Plant Money Plant Broad Leaves | 25cm Top dia
mounted on moss stick 90 x48cem
cm ht., 3 to 4 plants in each | Bottom dia x
pot, well developed with full 25cm
of fresh & healthy leaves Perpendicular

height Earthen
pot / Plastic
pot.

30. | Money Plant Money Piant Golden leaves | 25 cm size of
mounted on moss stick Earthen pot /
90cm ht, having 3 plants at | Plastic pot.
equal distance, well
developed with full of fresh,
shinning and healthy leaves
from bottom to top.

34. | Philodendron Philodendron Buraundy 25cmsizeof | Fach
plant mounted on moss stick | Earthen pot /
90 cm ht., well developed Plastic pot.
with full of fresh & healthy
leaves from bottom to top.

32. Philodendron Oxicodium 25 cm size of
mounted on moss stick 90 | Earthen pot /
cm ht., having 3 plants Plastic pot.
placed at equal distance,

Well developed with full of
fresh & healthy leaves.
5|Page

<!-- page 6 -->

33. Philodendron Oxicodium 25cm Top dia Each
Golden Colour Mountedon | x 8 cm
muss stick 90 cm ht. having | Bottom dia x
3 plants placed at equal 25cm
distance, well developed Perpendicular
with full of fresh & healthy height Earthen
leaves. pot / Plastic
pot.
Philodendron Oxicodium 25 cm size of
Golden Colour Mounted on Earthen pot /
moss stick 4.20 m ht., Plastic pot.
having 3 to 4 plants placed
at equal distance, well
developed with full of fresh
& healthy leaves.
Philodendron Oxicodium 25 cm size of
mounted on moss stick .20 | Earthen pot /
mht., having 3 plants placed | Plastic pot.
at equal distance, well
developed with full of fresh
& healthy leaves.
Philodendron Selloum 25 cm size of |
having ht. 30 cm to 45 cm Earthen pot /
with 8 to 0 leaves, well Plastic pot.
developed, fresh and healthy
foliage.
37. Philodendron Selloum 30 cm size of Each
having ht. 45 cm to 60 cm Earthen pot /
with 2 to 6 leaves, well Plastic pot.
developed, fresh and healthy
foliage.
Philodendron Ceylon gold 5 cm size of Each
having ht. 30.cm to 45 cm Earthen pot /
with 8 toi0 leaves, well Plastic pot.
developed, fresh & healthy
bright colour leaves.
Philodendron Xanadu 25 cm size of
having 5 to 20 leaves, well Earthen pot /
developed with full of fresh | Plastic pot.
& healthy leaves.
Philodendron Moonlight 25 cm size of Each
having ht. 30 cm to 45 cm Earthen pot /
with 40 to 2 leaves, well Plastic pot.
developed, fresh & healthy
bright colour leaves.
44. | Phoenix Palm Phoenix Palm havinght. 75 | 25 cm size of
cm to 90 cm with 0 to 5 Earthen pot /
or more leaves, well Plastic pot.
developed, fresh and
healthy.
6|Page

<!-- page 7 -->

42. | Rhapis Palm | Rhapis Palm having ht.45 cm to60 | 25 cm size of Each
cm with 5 to 7 suckers, well Earthen pot /
developed, full Plastic pot.
of fresh and healthy leaves.

Rhapis Palm having ht. 75 cm to 90 | 25cm size
cm with 2 to 5 equal suckers, well | Earthen pot/
developed, full of fresh & Plastic pot.
healthy leaves from bottom to top.

Seaforthia Seaforthia Palm having ht. 90cm to. 20 cm size of

Palm 4.20 m with 6-8 suckers, well Earthen pot /
developed, fresh and healthy lush Plastic pot.
green
leaves from bottom to top.

45. Seaforthia Palm having ht 25 cm size of
4.20 m. to 50 m. with 8-0 suckers, | Earthen pot /
well developed, Plastic pot.
fresh and healthy lush green leaves
from bottom to top.

Schefflera Schefflera high colour having ht. 25 | 25 cm size of Each
cm to 30 cm, Earthen pot /
well developed with fresh & healthy Plastic pot.
foliage.

47. Schefflera high colour plant (three in | 30 cm size of Each
one), having ht. 25 cm to 30 cm, well | Earthen pot /
developed with fresh and healthy Plastic pot.
foliage.

Schefflera Green plant (three in 25 cm size of
one), mounted on moss stick 90 cm, | Earthen pot /
well developed with full of fresh & Plastic pot.
healthy leaves from bottom to top

with rich

foliage.

Schefflera Variegated mounted on 25 cm size of
moss stick 90 cm At, 3 to 4 plants Earthen pot /
placed in each pot at equal distance, | Plastic pot.
well developed with full of fresh &

healthy bright

leaves from bottom to top.

Syngonium Syngonium golden mounted on 25 cm size of
moss stick 90 cm ht., 3 to 4 plants Earthen pot /
placed in each pot at equal Plastic pot.
distance, well developed with full of
fresh & healthy leaves from
bottom to top.

7| Page

<!-- page 8 -->

54. ‘Syngonium Variegated mounted on | 25 cm size of
moss stick 90 cm ht., 3 to 4 plants Earthen pot /
placed in each pot at equal distance, | Plastic pot.
well developed with full of fresh &
healthy leaves from
bottom to top.
खफा ता
|
Allyssum Allyssum white in full 20 cm Earthen
bloom well developed fresh & Pot/Plastic Pot.
healthy.
Anemone Anemone hybrid (3 in one) variety | 25 cm Earthen
well developed with fresh & healthy | Pot/Plastic Pot.
Flower in
full bloom.
Antirrhinum Antirrhinum Hybrid Dwarf variety (3 in | 25 cm Earthen
one) well developed with fresh & Pot/Plastic Pot.
healthy Flower multi branch in full
bloom.
Antirrhinum variety, well developed, | 30 cm Earthen
fresh & healthy multi branched 30 to | Pot/Plastic Pot.
45 cm ht, in full bloom with
stacking.
Asiatic lilly Asiatic lilly hybrid variety (Sinone) | 25 cm Earthen
in each pot having in full bloom 3 to 5 | Pot/Plastic Pot.
flowers 30 to 45 cm ht. well
developed.
57. | Aster Aster Hybrid variety in different colour,) 20 cm Earthen
well developed with fresh & healthy Pot/Plastic Pot.
foliage in full bloom
25 to 30 cm ht.
Bigonia Bigonia rex having 75 to 25 cm ht., | 20 cm Earthen
well developed with fresh & healthy | Pot/Plastic Pot.
foliage with
40 to 2 flowers in bloom.
Brachycome | Brachycome well developed with fresh] 25 cm Earthen
& healthy foliage with 00 to 20 Pot Plastic Pot.
flowers stacking with green painted
bamboo stick.
Calceolaria Calceolaria hybrid variety in full bloom | 20 cm Earthen | Each
well developed Pot/Plastic Pot.
with fresh & healthy foliage.
ला |
developed with fresh & Pot/Plastic Pot.
8|Page

<!-- page 9 -->

ae healthy foliage in full bloom.

Chrysanthemu| Chrysanthemum double variety, well | 25cm Earthen

m developed, having 45 to 60 cm ht., Pot
with 6 and above flowers with half
blooming condition, fresh and
healthy with
bamboo stacking.

Chrysanthemum single variety in 25cm Earthen | Each
different colour well developed having| Pot

45 to 60 cm ht., minimum 00 and

above half bloom flowers open well

stacked with bamboo stick having

three layer tiding by thread fresh

and healthy foliage.

Chrysanthemum single named 30cmEarthen | Each
variety in different colour well Pot

developed, having 45 to 60 cm ht.,

minimum 60 and above half bloom

flowers well stacked with bamboo

stick having three layer tied by

thread fresh and healthy

foliage.

Cineraria Cineraria dwarf in different 20cm Earthen | Each
colour with fresh & healthy foliage well) Pol/Plastic Pot.
developed.

Cineraria Hybrid dwarf variety in 25cm Earthen | Each
different colour well developed with Pot/Plastic Pot.
fresh &
healthy foliage in bloom.
es Clarkia Clarkia well developed with fresh & | 25 cm Earthen
healthy foliage, 5 to 6 branch in full | Pot/Plastic Pot.
bloom with
stacking.

Clianthus Clianthus well developed,with fresh | 25cm Earthen | Each
& healthy foliage in bloom 30 Pot/Plastic Pot.
to 45 cm ht, with stacking.

69. | Coleus Coleus broad leaves having 3 to 4 25cm Earthen | Each
branches equal well developed with Pot/Plastic Pot.
fresh & healthy foliage in different
colour.
70. Coleus broad leaves having 25cm Earthen | Each
5 to 6 branches equal well Pot/Plastic Pot.
9|Page

<!-- page 10 -->

developed with fresh & healthy foliage
in different
colour.

7\. | Cyclamen Cyclamen hybrid variety 25 cm Earthen
fresh & healthy in full bloom well Pot/Plastic Pot.
developed.

2. Cyclamen hybrid variety specimen 5-6) 35cm Earthen | Each
fresh & Tray/ Nand,
healthy in full bloom well developed.

73. Dahlia double kenya variety in 25 cm Earthen
different colour well developed with 3 | Pot/Plastic Pot.
to 4 flowers in half bloom, good
foliage stacked with Green
painted Bamboo sticks, 45 to 60 cm
height in

74. Dahlia single in different colour with | 20 cm Earthen
fresh & healthy foliage well developed | Pot/Plastic Pot.
with
6 to 8 half blooming buds.

75. | Daisy Daisy well developed with 20 cm Earthen
fresh & healthy foliage in full bloom Pov/Plastic Pot.
in

76. eee Dianthus dwarf in different colour fresh} 20 cm Earthen
& healthy Pot/Plastic Pot.
bloom.

77. Dianthus in different colour well 25 cm Earthen
developed with fresh & Poi/Plastic Pot.
healthy foliage 30 cm ht., in full bloom
with stacking.

78. | Freesia Freesia hybrid 6 to 8 in full bloom, | 25 cm Earthen
with fresh and healthy flower and Pot/ Plastic Pot.
foliage stacked with Green painted
bamboo sticks.

79. | Gazania Gazania hybrid in different colour | 25cm Earthen
well developed with fresh & healthy | Pol/Plastic Pot.
foliage with
full bloom .

. Geranium Geranium double variety having 30 25 cm Earthen
cm ht., in different colour well Pot/ Plastic Pot.
developed with fresh & healthy
foliage (3 in one)
well bloomed. |

84. | Gerbera Gerbera Hybrid, well developed, with | 25 cm Earthen
fresh and healthy foliage, fully | Pot/Plastic Pot.

blooms.
i0|Page
