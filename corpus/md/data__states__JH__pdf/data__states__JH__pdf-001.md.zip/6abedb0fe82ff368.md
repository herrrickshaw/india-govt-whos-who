---
doc_id: "6abedb0fe82ff368"
source_url: "https://onlinejsic.jharkhand.gov.in/suchna/uploads/circular/eccbc87e4b5ce2fe28308fd9f2a7baf3.pdf"
ministry: "Jharkhand State Information Commission, Jharkhand"
title: "Guidelines for RTI"
date: ""
pages: 22
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f9accafbb7b5b6b8"
---

<!-- page 1 -->

का (F - oe
4 igre E aN f
s SS on 4
a os SA
bi
ihe
|

<!-- page 2 -->

anes
wi

<!-- page 3 -->

es rele ail i
PEEP ea ee. phi
है § a ४0077 हि हा
| 877 50007
ee oer Fee EEF ४०2
| pila: GEE
| 668 .
|
|

<!-- page 4 -->

| ५, ,.. ee ae .......... 38
SE होड़ FIER £2 FEGHEREETE
HoH tie |
=e 5 Zeke BEe EEE fs :

Hy iE Hie jt:
He HE i Big aria
EUR ge al By 8८ 9 88६
Fy tie 8857 £ 88875:
है 66 8 7:05 08/
४2 46657 हट Ta
86 08788 5888 855 (दि

| ee
fy THULE Hap pia
pe PRE pity He
गीत हा THEY
467 Prat
ee pEREPETE. SefEEEE ae
8 PEEEEeuEHT 0 68

B B & oc
Ma
|

<!-- page 5 -->

HEE HEE : A
ah yy tied EEE 7 é na
8 LE है an
citegtie Betre, Be steslis EEr
FEVER SH) BUG hig
€ Eg Re eatEctte rt
ह6 हि 6 हित |
| $ BS a
Tree Beer EEEE PEEERSEEE PERE
ale GHE HE HEHE
sere Gece bile. Pscestenegi cd |
Hi ct Hu EEG
EEE: 6 3ey = Ese SUT Ree
PH ph UE nan
8 6 85 80865
|

<!-- page 6 -->

Ee EEEgs E<ERS
Be yu? E eel efist | EE
६ ४8६ “व “2 FE att
= t: : Ewe d : é £5 u Ee Ep
EF re : ६58०० ६ है Bigs eee é fl
HE fied? PEEL ne HoT is
: Fe 5 ee REbe Ee ~ Bé
| EE EE Hd Halal HH H a
be EEE IGN eee
i ES Ee BE $ F_ &5FE हिट
| है RET हू है & 8६. ६६ ६६ ५१228
HE uel ai isl th tikes
“ © £2 sEB ce rede ४7756
erat REEBS

<!-- page 7 -->

| गा SEE® E EEE a (ह ७ १88 छल
पल pees = EE 526०४
tee Gian HHa
४६:४०: ६६ Serie pete P EET Es |
: @ ह 6 ; EE “EF
REE Ti) Hey
 bpebttcet eptkire fbeprice |
EppEltiey tells yi PeePEeede
ai 2668, Telia
हि = EE edi Ee «Tren f
gh Hit piel
हि हि ६१ ६86४ Et bars if
CHEE, cue HEE |
| है 67 Papy ise Scie
Edsepiies FE rede है ४६228 |
€ हिट EF डर £ i x
HAN ४8 १ 68888 8 al ;
हि 5 ४ E ड़ g ~
|

<!-- page 8 -->

है है OAS REESE EE
i Hs rene. |
sli! ede GEE
= हि १2 fel F Ee Ege EE
| Lepeaedt AE isp il
| ae HEE TH i Tie
bes EE £ १०882 i i हे है
| biel pli ; age adeli chs
re ai 49065 Bald? rt
agepe ptPtee belt a
| 83६६ 88 हक पे हाई
| Hue ae AEDT EEE
8 588: HOSP
४ 30 2 0 ४०2 १8665 2886९
Eee gE pest Pee pene 6 62
5 i § E ४ pies ig
mae 870 8 8
व
3 8 i
|

<!-- page 9 -->

| EE & €¢8 हक Fy 2 7 | जी ya
Et 6 ट्रिक EES Fens E :
FE FE 6 6 - &- zg
HG HALT Gaited fy
Blydijiin Gallia &
BU Ge
| teed itt sETEEE | ४758 ६87 i i E
| = Sate = Se re BE StS &
p ह
PEE OCR EE gE € FE , E
| ha ue HL ३ rey
| pitted ali PeeeGb® § £e
Hinge gl Hie ed
Hiri peu iis! HOPPE
URRneahy Ge Bu;
HAMPER GEE
© हि ER « ड़ ie, fenee E |
site gitert Ha Hie. Ss |
ier i Ei 2 a

<!-- page 10 -->

nd ££ £ 6 E ie =

Ha Ee §

zEE rite 7587 हृ

aie ob BREED 287: 67858 :

Te ih aH

| et : Hii GHEE EE

gee : dail Eee hitpe!

fe पट हि 8६57: 8 5६ Ee

Hee idly [pill

RE. ah ४६20 25708 हि |

OC zB

* ERSt egg

l « eRe ef€ Etre

F F ४ EEE_ Fe E i peeks

Pima i sree flag

| £ ६6% ae 28 हे ०

रा EH

| ad Aad व |

| EET HE कब एक

| 868 MEH pitts ;

६ 85868 7488 ge Fly fi y

के eg (कि Es |
. "«
