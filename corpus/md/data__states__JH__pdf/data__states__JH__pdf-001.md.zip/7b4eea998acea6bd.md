---
doc_id: "7b4eea998acea6bd"
source_url: "https://cdn.s3waas.gov.in/s301f78be6f7cad02658508fe4616098a9/uploads/2020/05/2020050877.pdf"
ministry: "Khunti"
title: "Guideline for ePass"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1d3f349aaad7e153"
---

<!-- page 1 -->

How To apply for a Vehicle E-Pass Management System
Visit - https://epassjharkhand.nic.in
Or
Call – 8864001093 (for any query related to epass)
ePass Request Type:
Three types of request can be requested using this portal.
1. Inter State – Out Side from Jharkhand.
2. Inter District within Jharkhand .
3. Within District (from one area to other area in same district)

Flow of Application: (For Applicant)
a. In initial stage citizen has to register into the portal
b. Login into the portal
c. Complete the profile details and uploads the required ID card.
d. Apply for e-Pass
