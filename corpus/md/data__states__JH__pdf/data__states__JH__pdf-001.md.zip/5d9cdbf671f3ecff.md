---
doc_id: "5d9cdbf671f3ecff"
source_url: "https://jcsti.jharkhand.gov.in/document/ACTS_RULES/MoA_JCSTI.pdf"
ministry: "Jharkhand Council on Science, Technology and Innovation"
title: "Memorandam of Association"
date: ""
pages: 15
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b61024cbb989b880"
---

<!-- page 1 -->

ry

[vItr,MORANDT]M

oF
ASSOCIATIOI\

0 hl

(s

F.-l

(J

\

rtl
r)

di

,II{A RI(I{AND COTT NCIL ON SL- [t'NC I],
]-ECI-IN O LOGY AND INNOVATION

laly-

tr

<!-- page 2 -->

t

W

CONTENT'S

.ry'

I

Merncrrafl dun-. of' Association

2

Ru les ancl R.egulailons

3

Govet'tt nt;trl. Resrt I tr liorl

4

A;tPerrrl.t

(1

.t'

I

2

<!-- page 3 -->

Wq?

^.,

2

IUEI}TOTIANDUM OF ASSOCIATION
.I [I A R I( I{A N D CO IJN(] I

L

t, ON SCI II,NCD, TI,CTINOLOGY AND INNO\/A TI ON

Narne: The name of the Society is
Ilr rtova t ittrr

)

''

The Registerecl Officc t,f the Cotrrrcil shall he situatecl irr the Secretariat
Hottse. Dotartda' ltanclti - 814002 (.lharkharrcl) ancl at arry olher place

at Nellal

as cleterr,inecJ by

the Socicty flrorn tirrre to tirne.
J

The Coulrcil shall Lre arr Auterr.rornous lnstituticrn.

4

Otr.iectives: The tr[r.iects [or.rvhich the 5*'.,, is establislred

i;

are :

r'o identily ateas itt r';lriclr Scierrcc & Techrrology can Lre utilizecl for.t6c
acltievetltent oI the socio-ec,ottomic ob.iectives oI
tlre State arrcl irr ;rartictrlar
tackiirrg the 1l|o[rlertts ol'backrvarclrress, urrenrployrrrent
adcl|essing ill;ell'tr-r tlte Droblerns oI rural areas.

arrrl pover.t1,, arrcl o['

and untler;lrivileged sectiorr ol-tlrc

society strclt 1s Schedr-rlecl Castes, Schedule l'ribes. l-andless

l-alrorrr, z\r tisarrs.

Srrra lllN4argirral [iar rrrels \\/s111sl1 ancl yout6.

ii)

-[o

advise llrc Statc Covetntncttt orr policies arrcl rneasures

Science, Teclrnologl' attd lltnovation ancl its utilization [or

r]ecessal.y lo llr.orrot(:

achieverrrerrt ,I socio-

r:corr,:rnr ic o b_i ecrt i ves.

iii)

To irritiate, supl)ort. ltronrote arrcl cool.dinate,;_rreleraltly
sttclt as Reseatclr. Sttl'e)'s, Desigrr arrcl l-)evelol:rnerrt
irrcltrrlirrg clerirorr.stl-atiorr cr['trrrcriects are lil<e11, 19 l-ulllll

helll irr tlte oPlittrttrrr trtiliz-atiolt oIttattrrnl resourcr]s

by e.slablishirrg net\\,()t.l(s.

lrroiecls arrrl ;rroi1r.ap1rlcs.
the specific obir..,-.1iy.-., ,,,r,

as u,ell ns hrrnralr rrrs.rrrces,['

llre.(,t;rle

ir')

-l-o

v)

-fo.rdvise

p'c;lare. or assist irr trre prella'atiurr (rIscierrce

& -r-ecrrrr.rog),arrcr Iurrorari,ri

plarrs lirr llrc Statc

{lrc. Stirte C-ioverrrrnerrI rrn policies ancJ rirea.strres

tlevelopttletrt arlcl tleplol'ttteitt oIscicnce ancl J'echnolog,

vi)

l-o llt'clnrlte, tlre ;lc';;trlarization of'scierrcc and tlre

relalirrg to llrr:

rrrar;rr-l\^/el. r.esorrrces.

spread oIscrerrlific le rrilrcr arrrl

attittr<le atnolrg tlre peol;lc oIthe State.

vii)

1-o :;tr;lplerlt(:ttt itttcl cont;.rlcnrcrrt- tlre orr-goirrg techrrical
Covettttttettt.

3

ct'[olt.s ol' thc Srarr.

<!-- page 4 -->

t

I

tyAl/

viii)

'T''.r

itlleract rvilh tlre tlrganisatiorr ancl irrstilutions of'othe. State or Natio,,{

[:odies ettgageri in the areas ot'science't'echnology ani: lrrrrovatiorr qr sinrit.
lelated o[iectives

ix)

To iderrtily priorit5'areas of Sciertce & Technology on long-lerrrr clevelopnrent r-rl

x)

'i'tt establislt, tlr assist irr

lhe establishnrent of the infrast -rcture, institutions.

organizatiorrs etc. necessary to achieve the aforesaid.ob.iectiver

;(i) ,

To take any otlrer steps rvltich are relevant to the appli atiorr of Scierrce.
'l-e.chrrologl,arrd

x ii)

x

iii)

Irrrrovatiorr to the problerns of the State.

l-o function as the scientiflc bridge betrveen the covt. arrd the rr rsses.

'l-o bUild the irriage of .lliarkharrd as stato corrduetive

to th, aclvancenrent o['

lnforrrtation Technology and Bio.Technologli and other appropr ate'fechnolog.v.

xiv)

T,b establish Patent Facilitation Centre irt Itanchi.

xv)

To creale arvareness about lnlellectual Propcrty Rights es[:ecially paterrt-s irr
neighbourirrg region ol th is centre.

xvi)

To sensitize scierrtisls, reseafch scholars, 'students, rrniversity cQ, grass root
idhovators.

5.

Functiorrs: The Society u,ill have the tbllorving functions:

5.1. (A)
l)

r\ctivities t'eln(ecl to phnriing:

1-o prepare short-terrn and lotrg-ternt lllans itt the areas of Scierrce, Technol<rut

arrd lrrnovation as an integral part o[tlre socio-econornic developrrrent plans ol'
the State.
2)

l)

l'cr iclerttili areas of ;lliority arrti specific plo.iect and prograrrrnres lbr Scierrct.&
'l'ecirrrolog5,aml othet'a;:propria!e tec.lrrrological
activities relevarrI to the Stat,:.
-lqclrnolrlur,
'l'c,
trlrdertake s|:ecilic activiries directlS, itr the fielcls of Sciertce &
atrd to protrrotc arrd assisl other organizations in itrr;llerrrerrting the objectivei'e't
the Council.

4)

'l'o consider', if trecessary, tlre establishrnent ol'appropriate irr[rastructure,.lrrcl
irrstitutiorrs lbr carryirrg or"rt priorit-v activi[ies irr the field of Technology relevnnt

to the Stale

4

<!-- page 5 -->

(B)

{;?'to -

Corrrltilatiott irrrrl Ii.rchalrge of tlntu i'eler,nlrt to scicrrce, L eclrrrolog.l, :rrr(l
I.lr trova tion:

s)

To

prel)are Directories/lrrverr(ories and rtrake, assesstnent ol' [gllprr,irrg

rrra.io r' r'esources irr lhe State:

a)

lrrstitrrtiois [acilitatiorr lor research arrd trairrirrg in various
Sc: ierrce

b)
c)
6)

fr,:l.Js oI

& Teclrrrsl6gy.

Scientific and ltclrnical lr4anporver.
Mineral Resou.rces.

.

Periodical15' publish reports on lrnportant Science,

Technology & lnnovalion

activities rvhich are relevant to .lhal:khand.

7)
t
(c)

Exchange bf experiences with otlidr stale Councils through
ihter-Slale Visits, rvorl<slrop, senrinars, s,vtnposia

organization ol

etc.

Sttitlies a n il Sni-r,elrs :

8)

To sponsot' studies and sufVeys at State Level on issues

ot problerrs rvlerc

inputs lrorrr the areas of Science, Techrrology & lnnovation

9)

can prrovirle

soltltions to the pressirrg pro[:lerns ol' the society e.g.

drinkipg u,ater,

ho,sing, cnerg)', llreventivc rieartrr car,e. foocr preser,vatiori,

etc.

'fo encourage Studies relating to Futgre

^rr.al

Researcli (incluclipg Fulrolog),)"
relevant to the problelns of the State, includirig r.r,asteland
and rvaters6ecl
nlanagement.

l0)

To make ttse o['attcl involve rvhatever f-easible professional

bodies, societies ancl

edttcational instiltrtes irr the carrying oi.tt stutlies, survey, etc.

ll)

5y the Cosncil.

To llrotttote sttttlies and surrie,\.s related to

lllolrlenrs of environnrent, specifical6,
relaterl to the t'cqttirements oIthe State. rvith errrphasis

on specific case sfudics.

elc.

(D) Techrrical u(ilizntiorr :rrrrl liurr-e;lrerreurship Dcvelopment.
l2) Dernonstraliorr arrcl evaluatiorr .State-specific or region_specilic technologies. lrr
this task, ittleracliort rvith National ltesearch Developnrent Corporatiorr

(IrlRD1..)

l-1) To tnaitttaitr a cell [or;lrovett technologies f'or the beneflt of eritl.eprerrerrrs o['t;1e
State arrd to develop ap;lropriatc rrrechariisrns fot thg applicatio.rr,

clisseminatiorr

ancl transfer of strclt technologies l'or prf,ctical applicalion at various

leyels in

the State.

_5

,

<!-- page 6 -->

\P

'l-echrrologi.s.crt:valrt

l4)

to'rrr:lrdcvcltrrrrrrert irr trre area

trral' Lre givcrr s;;ecial allcrrtiolr.

lo lttake ef'fbrts 1o rrtoclernize lraclitional

l5)

ternoval oIclr.rrrlgery fi.onr rnantral

l6)

'['o

technologies for trctter elllcierrcv

anti

laLrour.

llronlote ancl-qttcotlrage agerrcies ar trre state

scalirrg of tec.rrnorogies riorrr pirot,rant

le'er to urrclerrake the

lrl)-

lever to procruction rever.

l7) To sullport and encourage the utilization
of
Science,'fechlrolog-v& Innovatiolr.

l8)

oIagricrr irrrr.c CtlCt't', ,.rt.

consuttancy organization.s

To t'evier, cxi'stirrg l)l'ogrartlrres oI errtreprerretrt.srrilr

,acti.. prarrs li:r' trreir irrrllrbvcirrerrr,

;ttrdies.arrcr
dpp'rlpriate
prog'arllllres of ecltrcatiorr arrd

cle'elo,rrrerrr arrcr de

arrrr iricrrti[1' n,.,,,

'isc

,r,",.,n,:"

tiaining accorclirrg to t6e r.er;rri,er,errls

df the errt,epr.cr.,eJ,,s.

(E)

ltesenr.ch nirtl Developrrrcnt:

l9)

To icle,tif\' localiott c'r'egiori specific

Jr',blerr5 fbr'q566pc;1 hlrcl cleveroprrerrt.

tal<ing irrlo accotrrrt of pr.eserrt nrirl [utrrr.e

20)

-l'0

rieer.ls.

organize secto'al / therratic rvorl<.slr,ll,'er,iriars

state/states u,hele e\/er altpropr.iate, arrcl

irr c.o_oltcratio, rrith other.

rrse lhese to lor.rrrrrlr.ric. R&l)

piogr.arrrntes.

2l I

'l-o

22)

-l-o

errcotrrage arrrl hellr talerrtcrl scierrtisl irr lr.orrlline

research.

iderrtili' cottlllctetrI tesearch groul)s or institrrtiorrs rr,hich

car e\ecrtc tlre

a[rove l)rogr.anln]es

(F)

Poprrlnr.isa(iorr ofgsiql;c1,1

2-l)

.f-o

firnction as an e|rective cararl,st [locr-t, rbr popura,.isati,rrr

lc*els .l- societ--r' tlt.orrgh
rr I i I i sa t ir.r

74)

-l'o

lr o I r,o I r

r r r I

of scierrcc ;rr iril

'itriotr.s ,lca,s rvith ;:arl rcular errrl:rlrrsis L, thc

a r ;, a ge rrc i e.s.

Dt'otltote scit:trtific tettrper in Coi,errrrrre rrt DeJrar.lnrerrt. lrublic agerrcies,

Urr ivcrsit ies a rrd of her. eclucatiolral irrst i t r rtiorrs.

2-5) l,culcatirrg scierrrilic terrrper irr rhe psyche oIthe 1:eople at largc.
G)

l';r iclr t lr lrtl Illrr)r,:r liolr

26)

Or'$nrrisatiott ttf';lto61l';tlttlites ori gerreral au,ltLrttess:rs u,ell as grr sJtecillc

issrrc:l;

orr Itrtelleclrral Plolrer'{1, lligirts flifr) i,icltr,llrrs 11616111 ccrlr,r,r,tglits, geograllhlcll
irrdicaliolrs clr'

6

il1

<!-- page 7 -->

'l-o

27)

,)l'rr''tr;t.: L1 'eei.! ;r 1:.-i,l,1c-r, ;!scl,,.:!:

j
l.,il :11;1...r1r1..,r ztfr.:ct;.- - ,^,,r1,',rrl

tale lrtecl arrcl briqhi rnirrct.s.

28)

(I'f)

Facilitation of aplllic.ctiorr to

l)nter,[ filirrg

Olher Activitics:

29)

-l-o

rrrairrlairr liai.stlrr rvi;lt varioli; Cer,l*,i

agerrcie:s arrrl l)cpar.tnlertis as rvt,ll

j0)

-l-o

rs,,rrrits ol. lhese ngerrr-:i,.:s, i,r,lilie,,;rr{

llr.ovicle encolrasenterrt lo )/out:1, scierrtist ll,iitrrgh

tra i rr i ng o;r;ror.ttrrr i t ics.

3l)

.icierrce, -l.cr;l:rr61,,r.,;;;.6-t [;,1r11r,r;;.gr1

a rva r.tls. scho la,.slr i

32)

rro lo91, a rrcl I rr rrovat iorr

cI rr,,)rn;rr i;r Ijcierrcc.

acl i v it ies.

1'o iderrtiry nrr<r Jrrorr'ore scierrc€,

.-ec.,i-rog7 a,d rn re.,ari,..r;r progr.lrr,,es

tl:e lren:fii of \veal(er st ctiorr.s, l:arrclicap.rr,J,

l3)

!;Ir,cl.i,, r,i..i[:,.r,.::rrrrrar.,

lt etc.

To idelrti[1'atld ;ltcltttole l)r'og,ranrrrres [br irrvol'en.,crrt
'l-ech

st,ttc:;.

arrd diSa[ ,e{l

rlristalldtiorr, corrrnrissiorrirrg and lndirilerratrcc
for stor'age of,data & vital statisticS

[or

;]ct..so,r.

oIa in[or:lration ccr;llc irr tlre sti:.c

ol-the State.

l4)

Esta bl ishrrrerrt of rrrodern pla netari

l5)

Esta[:lishrnenl oI a Rerrewablc llrrerg1,

i.rnrs

llotl-co11\/entional errcr.g1, ilr reproles(

r\pplication Centre. for prr6p;rg;1[io:r ol.

rttral ar.eas

36) Establishr,ettt attcl tttairrtertahce of a Rerrrote sensing centre
resourcbs data rrsiilg Satellite Teclinologl,

for. usirrg natiorral

I-or Socio-Econoniic.i

cle'elolri,errt crf.

the State
6

Rrrles nrrd Reguta{ion.s ol'Jhnrl<tranrl
Coirrrciloll Scicttce, Techrrologt,alrtl
lrr ltova tiorr.

(i) Shorl Title: These Rttles ancl l{cgulations slrall be callecl

Rules ol'.lharkharrcl cotrncil

on Scierrce, Techrrology ancl llrnovatiorr.

(ii) Definitions: ltr the present Merrrorarrchrrri ol- Association
Regttlaliorrs of Jlra.khanticotrncil on scierrce. Technologir
is arrl,thing repugnarrt irr the sub.iect

anrl the llules nnrl

antJ lnrrovariorr trrrlessj6cre

ol.corrlexL.

(i)

"(,ourcit" nreans or'.rrrarkhancr courrcir

(ii)

"COtnntiltee" lrrealls Erecutive Corriririltec

orr scierrce, Technologl,ancr Inrlovariorr.

of Jhar,kharrcl Courrcil on Scierce.

1'echrrologl, ancl lrrnoval iorr,
;

(iii)

"cio,er*r,eirt" rnea^s covernli:errt ofJrTarkhahd.

(ir)

"\'ear" meansybnr ti'orn the r'r april ro

7

-rf

srr;rarch

or.a J;artictrro,.r,"o,..

<!-- page 8 -->

tr"'

w

(u)

"[)residettl / Vice-Pt'esidetrt" nleans Presiclent / Vice-President of the .lharlih ;t 1:1
Clotrrrcil orr Scicrrce.

-l'echnology

I

arrd Jrrlrovation.

7.

(i)

(l)

Chief N4 inister', Covt. of.lharkhand

(2)

(l)
(4)

Metttbers of llte Corntcil : The Courrtilshall rorrsist otthe I'olloryirrg rrre.rrrl,crs

Mirtister, Deptt. of Science.& 1-echrrolog1,. Govt. o[.lharkhand Dcveloprnerrt cornrnissiorrer, Covt. ol-.lharkharrd
Secretar\. Deptt. ol'Firrarrcc. Covt. ol".lharklrant{

(7)

of'.llrarklialrcl
Cltairtnan or his Representative, IJ.E.C. Rarichi
Representative of De;ltt.of science & Teclrnolbgy, covt.of -

(8)

lndia
Represerrtative of Deptt.of F,nvirornnental & Ecology, Oovt. ol'

(5)
(6)

Secretarl,, Deptt. of'Energ1,, povt

.

pr.eside nt

Vice Pr.e si<le rr(
Nlerrrber
Mlenrbcr

Merlt,er
Me.rnlrer

Menrber
Ir4enrber

lnd ia

(e)
( l0)

(ll)
( t2)

( l3)

nafi.r.,,,o,ive of Non.Corrverrtional Ener,gl, Soulces, Covt. of

N,lenrber'

lndia
Representttiye ol' C,S.l.R,New Delh i

N4etnber

Ilc;rresentativc of irrdian Council of Agrictrltural Research.
Nert DClhi
(epreserrlative ol' E.R.C. Of A.1.C.1".E.

Represenlative of

' lt4enrber
Metrr'trer

Nalional Mctallurgical l,aLrorator.y.

Me nrtrr:r

Represerrtative ol' Central Irrstitute of Minirtg iincl Fuel

Mernber

.lanrshedpur
( t4)

Research. Dharrbarl
( t5)

Trv6 p,'|,r"ipal of Errgineerin_u Collcges to be nornirrated by

lr4e tuber

Governrrrerrt o[.] lrark hand
( t6)

Trvs 1s11o*ned Scierrtists/Technologists to be norrrirrated by

lr4ern ller

( le)

Govenltnent oI J hall<lrancl
Represerrtative oI National Research Developrnent Corporation
ol'lndia. Nerv Delhi
Five heacls of Degrtt/Scicntists oI arr-r, Urriversitl, ol' .]lrarkhand
lo bc rrorrrirrated [r1,Govcrnrrrerrt of .lharkhancl.
Secrctar-\'. Deptt. oIScierrce ct l'cchnolog),, Covt. of Jlrarkhand

(20)

Director. Depll, o[scierrce cQ, TechnoloBy. Covt. of .lharkhancl

(211

Repre sentative of'llokirro lspat Steel l,td

(12)

Itcllrescnlative ol' l rrdiarr Oil Corpor atiun. Goverruncrrt ol lndia

Ir lenrllcr

(23)

lleprese rrtativc o l' Ferti I iser Corpora tiorr ot- I nd ia

Metrrtrer'

(24)
(25)

Representative ol' Deptt.ol Irrfonn.tiorr Technologl,,Covt.of
lndia
Director or' l-l is Reprensatative. I.l.T. K harirgpur

N,lcrnbcr

(26)

lle;lresenlh tive o I ll trra I l)eveloplirent Dept t.Govt.oI I rrdia,

Nrlclnl'rcr

(271

Tltree public Re;rreserrtative intercstecl"in Scillrce

N4enr lrer

( l7)
( lB)

B

lr4enrber'
N4enrher
N4ern [rer'

.lt.l\4errrlrcr
Scc.l3llat r'
i\,lcnrber

f'rlernbcr

<!-- page 9 -->

fi o6
(ii)

'l-he

Chiet' lr4inister, Gr)r,enrment of'Jharkhand shall be the president of the Corrncil

arrd the lvlinister. Deplu'ttttent of Science & Techrrology, Governrrrcit of Jharkhanrl

shall be the Vice-Presidetrt of the .Council. Director Departlnerit, o[ Science &
Technolo1E1,, Governtt'tent of .lharkhand shall be the Joint Uentber,t$ectetary

i ::i

of the

.

Cotrncil and Executive Director. Jharkhand Council on Science & TCi,frriglop), shall be
the .loirrt

"$ecretary.

,,,

'i,

'

(iii) All rnembers of the Council, other than ex-oFficio rnenrbers, I a,to" hold rheir
:'
rnenrberghip for a-period of the three years frorn the date of notihcatiorr of their
notninatiotr urtless their rnerrrbcrship is terrninated liy rhe State Gover,rintent.

(ir)

Where any person is the rrrenrber of the Couneil by reason of the ciffileor of the post

held b1' lriln, his ntetrrbership of the Council shall be tern'iinated when he ceases to

hold thet otfice or post, and against this vacarrcy; his successor"in office shall
I

atltornatically becohre a lnetnber of tlie Coliflcil
(v)

The Exicutivo Corrtrnittee siiail pass tlie lrudgfi of the Courrcil for'd yeii'or part there

of as it cleerhs proper. ln financial mdtters, the Executive Conrtit'ltted:sirall take all
decisiorts. Tlle Executive Comnrittee shall also have the power to dpliointauclitor for a
vear or part thereiore. as iFconsiders proper. The audit report shall be placed be[ore

..

,

the general b,ody for persual & approval,

(ri)

The Anrrual Ceneial Meeting of the Counoil shall be field once eVery lissr at such tinre,
date and plarie as the President of the Councit.rnay decide. At this rheeting thc reporl

o[ the nranagemerrt of the Courtcil for t]ie prerrious financ.ial yehr togethcr rt,ith atr
audited copy of the i:alance-sheet, inconre and expetrditure 0ccoutit and.tlte aLrditor's
report. arrcl any other rna(ter that nray be placed befor'e it by the Exectrtive Conrnrittee.
shall be subnritted for approval.

lvii)

All rneeting of the Clouncil shall be callecl by a rrotice under thb siltratule ot'the
Merrrber Secretary or tlre Chairnran of the Council or any other officer airthori.sed bri
thern ft'rr this

lviii)

'

purpose

l

E,r,ery notice for the Arrnual Meeting or any other meeting ol'the Courreil, shall statc

the date. tirne and place of such rneeting and shall be delivered b),hand or sent b.rr
registered post to eve.rv rnenlber, not less then l5 days before the'date'appoirttecl l'or
the Meeting

(ix)

'fhe President or in his abserrce thd Vice-President, shall preside all.tlre.riteelirrg.s of'tlrt:

Council. ln the abserrce oI the, Vice-Presideht, aily nletnbei'iridicatecl by llre
Presiderit/Vice.Presiderrt shall preside*

+

i

(x)

One-tlrircl of the medrbers shall forrn tlle quorum at a lneetilig

(xi)

Decisiotrs in the rrreeting of the Cotrncil shailbe takerr [:y sirnple nraiorltSl'
9

W

<!-- page 10 -->

\M

..i\

ll. (i) 'l-hc
I
2
3
4
5
6
7
t

U

Iixerrrtivc Corrrrrrillcc slrall consist oI tlrr: [ollorvirrg officc-l-telrt'et's:

lvlirrister. Deplt. of Scierrc0 cQ Technology, Govt. ,:f jharkhand
Developrnenl Comrrrissiorrer, Govt. of .lharkharrd

Chaittrran (Er-nlt,
\/ice-Clrair rriarr( l-x-of ij,. t..

Secrerary. Deptt. oIScience ct Technologl, Covl. of Jharkhand

lr4 errr Lrcr Secrel ilr _r,

Secr:atary, Depattetnenl of Finarrce, Covt. of Jhirkhand

lvlernber' (t.x-o llic io)

Secreatarv.Departrneni'ol' PlanrringarrclDevelopment,
Oovt. of Jhalkharrd
Representative of Depll. ol'Scierrce & 1-echrrology, Govl. of inclia.

N4ernLrer( Ex-ol"trc io )

.

N4ernber

Representative of Induslries Deptl, Covt. of .lharkhancl

lr4crrr l:c r'

Orre menther frorrr'each ol'the Departrrrents (PWD, Mirres and

N4etnlrer

Energl')

9

Orre nrenrtrer 16 bg 6erltitrirted by lhe Stale Covt. from any

N4 enr L'rer

Urrivr'riity o f Jharkharrrl

l0

Relrr:sentatlve of Bio-Ter:htrology, fronl ziny university <rf

Melutrer

JhJtkhand
I

I

., Dir"e,'t>i', Deptt. of Scierrce & Techrrology, Govt. of Jharkirarrtl

Melrrbe r

I

12 , Represerrtative of Deptt. oINon-corrverrtiorral Energy source,

Member

i3

Merntrer

(ii)

Co'vt,
of lhdla
i

Reirreserithtive oFIt Deptt, Govt, of lndia

The rnetirliership of Executive Corntnlttee shall be for a period of three years fronl
tlre datc oI norriinatiorr. unless tertrrinated by the Council.

(iii)

Tlr'e lixeitrtive Cornrrrittee shali nreet ordinarilyonce in 3 rnonl.hs at such tirrre, clate
i

arttl ;llade as the Chairrnan rrray decide. But ernergent meeting of the llxecrrtive
Corrrniitiee niay be callecl atry tinre by lhe Chairrrran or the MenrbEr-Secretary of I re

Itxectttive Cornrnittee. A Nolice o[ seven days rvitl be requirecl for an orcl;rar1,
rneeting nrrd that of 24 hours for an etriergent meeting.

(ir)

One l'hircl of the rnerrrbers oItlre Executive Conrnrittee sliall fonrr the quor nr, l'hc
requirernent of the quorurn slrall not. honever, appl),to adjournerl rneeting:

(v)

'T'he

Executive (-lornrrrittee nrav dispose of sonre ve,ry urgent rnatter by cir ;trlatiorr oI

papers, if so desiretl b1'tlre Chairnran. All decisions thus lnade shall

lr ieportcd ar

tlrr next rrreeling of the Executive Cornrrrittee.
(ui)

It shall hc the duty ol'the Executivc Conrnrittee to tal<e appropriatt: Jec.isions attr.l
isslre irrstructiorrs lo persorrs, crr irrstitutions concerned, fo.1 lirlt!llrnerrt ol'llr,:
ob.iectivcs relatecl to thc lleltl olactivities of the Cotrncil.

y'vit)

Thc Exectrtive Corrtnrittie slrlll liave florver to inake rules, regulations ancl b)'larvs not
it.tcotlsi-sleltt witlt tircse rrrles for' the corrdtrot of aclnrlitlstrntlve, l'ln.arrclal nrlcl olttel'

r0

<!-- page 11 -->

,4.tiiii*

Ao,,

,---..-. ,

\

al'lhir.s of'llre Cotrrrcil irr lurtheratrcc ol'its olr.iectives arrd also to arrrerrtl thern u,herr
necessa ry.

I

t.i'iii) -flre Executlve Cornrnittee shall h6vs 116rv3;'to create ;rosts, to a1lgroi,11 oi'ic,ers arrcl
other staf Iacoorrlirrg to the procecltrre laid clorvrl [ly i1.

(ix)

l'he Executive Cornnrittee slrnll have pou,er to invite experts or concenled individtrals
of repule, lo participale in the clisctlsiion at arry nrecting of thc Erccutive Cernmittce.

(x)

Decisiorrs in thi: tleetitigs crf lhe llxecutive Conrttrittee .shall ltc lakerr [:1, sirnple
tttaiolil.r'.

g. EltnOs of lho Corrncil:

ii

(i )

All accQtrnts of the Cottrrcil shall lre operatccl.iointly by the Executivc Dircctoi'
an<i Mertrtrer Secretarl' of the Cotrncil.

(i:)

Ihcre ihall be a corrsolirjated l'uncl oi (lre Courrcil tvhich r','oukl cotts;,1 of rhe
f

6ll6rviitg:

(a) Fttrrds rnade availaltle by the Cerrtral Govet'nntetrt, State Co\,erttntettI t)t'attt,
Covelnrnelrl 1r' Norr.Ciovertirtletlt [rorlies. For ease itt accotinting sel]atltte
accotnlt. shall Ue thdilltttined [ot'ftrrid frorn dif'lbr'etlt sotttces.

(b) lrrteiest otr lhe lirrirl ac.curttttlated iti [lie corrsctlidated l-trrrd'
(c) lr,coiite ft'otrt cotistlltatrc)'ahtl/or ittrtrrovable llroperty oI the C]ourrcil.
(d) lncr)lne fi'orrr Lrrrblications, l)atentsi clesigri$ etc. cl'[ec,lecl or rlet,elopcd bv lhc
Cotrncil.

(e)

'p-1'6rr1

arry legilirrrate sotirce.

(iii) ,ill the Iirrrds rlf tlre Cor.rncil shall lrc l(c1r! irr l]atrli Accotrttl ol',,itr thc l-o'r1r o['(ir-rvl
Secrrrities or,:lepc''sils irr strcft lolrrr as deerrretl propct'in any natiotralizecltullrl( arrrl tlrc

Mcrirber.secretarr,ol tlrc Cotrrrcil arrcl Exectrtivc Ditcclot'ol'the f-crtttrcilshall opcr;ttt
llrc llnrtk Accotttrls.

(ir)

['lrc acc6urrt oIirrcorrre ancl expcttcliture of llre Cotrrtcil shall bc auclitecl ct'er)')'ear l-.'-\

a leprrterl Clartererl AccotrrrlanI clul1, n11t',o1,rterl.b), lhe ll.xectttivc Ctltrtrrritlec. Ilrc
autliiccl accourrt:;hall [lc plac.etl Lrel'ore lhc ('ouncil aflet scrtttittlr [Y 11,. l:.xettttivt''
C,rrrrpi(tee aqd a copy 6f lhe sallte, afier a1:lltoval ti['thc

(lotrticil, shall b': sctrt to lltc

Delltt 6f Scicnce tt'l'cc:hhology; Covet'rrrttent oI lrrtlia 't ;ttt-\' olhet'of'[lccs' rvltcre iott:
lhe firrrtl rvas tlratle 6r'irilable to tlrc C-otrnc'il.

il

-fi7

<!-- page 12 -->

.l

d@

t,.

l(1. J'orr,er- lo lr.arr.s:rcl firrlrrrci;rl ntxl(ct..\:

(i)

l'he (-tlrrrrcil,shall ltitt'e (ltc righl to acqrrire, sell, irrvcst arr<l lranslcr such nlo\,irblc lrrr:
ittttttoVable l)l'operl-v;irrcl assels as il rlecrn.s prol)er. l'he Council

carr pr.arrt l0arrs arrtl

aclvarrces arrd receive loarrs arrd advances.

(ii)

All the lrroper(ies of'fie Cotrrtcil shall vcst irr thc E.recutive C'orrrrrriilee ancl ;rrr.1
cxecrttic'rr regardin-U propert), shall be clonc joirrtli, lrV Merrrber gsqrgl.rv

c,l. llre

cottltciI lttcl F,xectrtive Direc.lo1 OI tlie c.trrrcil.

(iii) l(trles regardirrg iterrr (i) arrcl (ii) a[rovc shall l:e fj.arrrcrl bl,tlre Executive Corrrrrrittec.
ll. (i) Por'cr' ;rrrcl [,rrcliorrs .I lixecrrti'e C0rrrrrril(ee
(a) The r\ilrrtihisttnliorr arrd N4atiagerilent ineluclirrg gerrerai superinlcn(le6ce,
:

clilrictir)rr,

control arld otlter relarecl lliartcial rrralt6r's oi rire,Courrcil inoltrrling

lhe porr.er t(r

. lttqtrirtl arrd sell l)roFei't)', tlte pot\r€r tci l'ti.(€ loilns aghirrs sectrr.ill, or olherwise,
ii

1cr

itdvartce llloIe)' arrd lo Irial{e alJl)ointrlreirl shall be cdnducterl b), ll,e l]xectrtivc
;r'

Corrrrriitlee

(t,) The decision ol'Executive Cornniittee sltall lie tal<en bl,sirri;ile rrrliioritl,oIrnetrrbr:r.s
lrtesenl irr llte rrreelirrg,

1ii) I,oivcr' :rrr(l fitttctiotis of oillce-trenl.er.s:

'(a)"1-hc Ghaittrrnri ol irr his al-rSerrce lhe Vice" Chairrnarr

shnil pr.csirle all thc

rrtecliiigs ol llrt' l:.tectttive'Cotlrnillee. ltr the alrscncc oI Chairrrrarr arrrl \1icc-

ChaiItttflti, the rrtetnbet's l)tesdtrl irr lhd tnGeling of'llie Execrrtive (='orillitlcc
sltall olect a presirlirrg ol'ljeer lor lhat rireetiirg onl1,.

(tr) Arrv rnccrirrg of lirectrlir/e (:onrriiltec -shall be corrverrecl orrll,alicr.gcttirrp
corrtierrt ol'tlre (. hairrnnrr of'the l;xce Lttive CorrirrriIce.

(c) Tht; N4(:trrbcr Se.,;relitt'),ol- thc Execrrlive Corrrrrrittee shall lrave lhe
cOnvelte nleelitlt oI the l],rectrtive Corrrrrriltcc arrd slrall

;rorvcr tc

1;iepare agerrda, agerrrlir

llotr:s alt(l olltet necessai'y llapers lbr placirrg bc[oro Ihe rrrerrrbers ol'[-.,rectrlivr:
C,orrrrn itlce.

(iii)

IrrsPcclisrr rtl'Rcgistcrs: Arry rrrelrrber ol-lhc Excctrlivc CorrrrniItetr shall hirr,e

Fo\\,r-,r

to ittsltccl tegisle rs arrcl palrers ol'lhe (-'ouncil.
12. Ol'ficers urrrf slnll ot'lhc Courrcil:

'l-he posI ttitrlei'tlre

Cotrtrcii carr he createcl b_\, llre ExocLrtiVe Corlrrtiuee;rnrl Ihe

[ixecutive Dit'r:t:tbr rvill be tlig;rfl1;llplstltltive ht!atl ol'the Cotrrrcil vrrhr.r will i:re
arrstrreratllt to ilre l.letrrber Sccr'ctlrryioI tlrr: cotrncil arri.l Ch;rirt'rierl oF ljxecrrlive

t2

.

<!-- page 13 -->

The Executivt: Dit'ectot'shall be as-sisted by a team oIscientific personnel

& office staff. ]']re ttttnrber oI posts, enrolunrents there oI ancl the strength of tlre

nrirristerial staff under the Council, shall be der-ermirred by the Executive
Conrntitl:ee [t'ot'lr timrl to tinre, with approval oIthe Chairntan oIthe Council,
l

J. Anrenclrrrelrt anrt ttiss,llutiolr

(i) The ltr.rles and Regulations of the Council can be amended by a 213'd nra.ioritv of
tnetlt[ers preseltt irr tlte nteeting of the Cor.rrrcil and a majority of tlre total nrenrbers

of the Council. But such atnenclnretrl shall beconre effective only after approval b1,
the State Covernrlerrt.

(ii) The council carr be dissolved by lhe 3/5 rnajority ot cerrerar body.

(iii) On dissoh.rtiorr of the Council, all the assets and liabilities of the Council shall tre
given to the State Government.

14. Misc:
Aril' other nratter not specifically laid dorvn above shall be govelned by the. provisions crl'
Societies Registration Act 1860.

Certified thot thi.s is the true & cortect copy of rules & Regulot:ion olsocietlr

')

2

1

C-b* A' r'.. P *

")

T"4'il'

t\ )

tl

M

(.u " k- ,S"{;. .r7k r\e+

<!-- page 14 -->

I(BSOLTJ'TtON I(IIGAITDING RI'GISTIIA TION

Irr tlre preeling ol' the C.ouncil lrc'lcl orr 18.10.2011 (liiglrtccrrtlr Oclolrr:t I r|l
'Ilrerrsarrcl

Tlrirtct:n) at Rarrclri. 11n6 lsllcrwirrg tcsoltrti<ttt tvas discttssed attd ap;lrovetl.

'l-lrc rrrcctirrli trlarrirlotrsll, resolvecl that the..lhall<lrarrrl Cottttcil rltt Scit:ltce ,'"
fcclrrrology shotrlcl be Rerrarrrecl as Cottttcil ott Scietrce T'cchtrologl' artcl lttttovalirltt ittt,l
rcgistetecl alter Ilarrarrring the Courrcil rvitlr I{evisecl tttetttotanr]trttr attd rules a1ll-rettrlctl ltct'e trt
tr,rrlet' lhe Societies l(cgistratiorr Ar:t XXI of' lti60.

l'lre trreetitrg lrlrtlter lesol\/ed tlrat tlrc E,xectttivc Director Slrri 1... Srittivitsrrtr ol tltr:
.lharklralrl C6rrrrcil olt Science. Teclrrrology ancl lnnovatiotr. Covcrtrtttcnt rtl'.lltatlilrarrLl slrotrlrl
he eirtlusterl ivitlr tlre task ot'takilrg liecessary action for I{egistr'ntiotr oI lhc (-outr::il Itt),1:t'
Socicty Registration Act XXl. l8(r0.

Tlre [ollorvirrg prelrbers \\'etg preserrt tvhile tlre above statctl les()luliott rvn:; hcitttl
arlopletl:I . Slrr i l-lenrarrI Sot'ett

Chiel'[r4 irrister

.r [)r. A.[.. Parrcle.l'

A dd i tiorra l Clr ie f' Sccrel at'1'' l )cPl l. o l' scictrce & 1't:cl rrr<rlop-i

..t. Slrri A.l( Sarkar

Deve loptttettt Clottt nt issiolter'

,l filrri A.P Sirrgh

Sect'etat5,. Deplt. ol' Finnrice

.5. Silu i

lt. St'ittivitstttt

.loitrI Sccrctarr -cttrrt-l:]..-cclrlile l)itcclt'r, l)cItl ol'sciclrcc .t I r.:'-ltttr'rlrtPv

(r. Slrri \/il<tartr Ciatrr

Spec iirl .Secrelat v F.ttet'gv Dcptt.

/. Slrli [].1r. Slralrna

ILF..C l{arrclri

li. Slrri Angircl Kr.rslrrvaha
() lihri l.).C'.loshi

CIN4I;ll Dharrbacl

NI{DC Nerv Delhi

('ertil'ied'tfifi tfte 4(1pt,c i.s a tnte coltv of t.[rc resotilttort. regardiug rcilisttul.iort.

A
lic,-rr't:larl

Dc|(l ttl' Stir.lttt'c &'l'r:t.lttr"llt,i
.l lta tl.rhittit i

(efiifict{ t.{int. I, hryotu tfie diouc rn.entione[ persotts wfi.c [Lury .rigrrct{ it mi Fre.rt;ttce.

l;rer'

rfffu)r

.lh;rrkltarrtl (,otrtrcil rttt Sci'',icu
'l cchrr,iltrgt aitr.l ltttr(tt;tl itrtl

t4

<!-- page 15 -->

tr
(@=
4

(i) -lhe Executive Conunittee shall consist of the following office-bearers
Chairman (Ex-Officio)

Minister, Science & TechnologY

Vice-Chairman

Developmeut Corntnissiotter, Govt. of Jharkhand

2

3.
4.
5.
6.

(Ex-Officio)
Member-Secretary

Comntissioner-cutn-Secretary,
Deptt. of Scibnce & TechnologY
Finance Commissiotter. Govt. of Jharkhand

Member (Ex-Officio)

Comrnissioner-Planning, Govt' ofJharkhand

Member (Ex-Officio)
Mernber

Representative of Deptt. of Science & Technology,

Govt. of lndia
Mernber

7. Representative ofBiotechnology
8. Representative of Deptt. of Non-Conventional

Member

Energy Sources, Govt. of India
Mernber

Representative of Industries

9

Deptt., Govt. of Jharkhand

Three members to be ttominated by the State
Government fi'orn Jharkharrd Electricity Board,
P.W.D. Irrigation Deptt., Road Deptt', Agriculture

N'lenrtrer

II

One member to be notninated by tlre State Govt' frqtn
arry UttiversitY of Jharkhand

Mernber

t7.

Director, Science & Technology and Information

Member

t0

Dept., Mines Deptt., Energy' Deptt', Forest Deptt',
Govt. of Jharkhand

Technology, Govt. of Jharkharrd.
t3

(ii)

Member

Representative of I.T. Deptt., Govt. of [ndia

The mernbership of Executive committee shall be for a

period of tluee

years from the date of nomination, unless tenninated by the

l5
:-

-:::g:.---_

council'
