---
doc_id: "dfebbf5ae022d8ad"
source_url: "https://jrhms.jharkhand.gov.in/uploads/tenders/37876991-0700-4002-af5a-07eaec6ace9b.pdf"
ministry: "Jharkhand Rural Health Mission Society"
title: "GEM/2026/B/7849662 — Hiring of Social Media Agency  (Expired)"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8520027927c1536a"
---

<!-- page 1 -->

Government of Jharkhand
Jharkhand Rural Health Mission Society
Department of Health, Medical Education & Family Welfare
Namkum, Ranchi.
Phone No: 0651-2261000, 2261856 & 2261002 Mail ID: proc-health@jharkhandmail.gov.in

Tender Notice No. GEM/2026/B/7849662

Date: 29/07/2026

Tender Notice Through GeM Portal
Jharkhand Rural Health Mission Society, Namkum, Ranchi invites separate Technical and price Bids
(Two Bid System) through tender from the registered and eligible firms for “SELECTION OF
SOCIAL MEDIA MANAGEMENT AGENCY FOR THE DEPARTMENT OF HEALTH,
MEDICAL EDUCATION AND FAMILY WELFARE, GOVERNMENT OF JHARKHAND”.

The Blank tender documents with detailed conditions can be obtained through web site
http://gem.gov.in.
Sl. No.

Particulars

1

Name of Work

2

Publication Date of Tender on website

3
4
5
6

Pre-Bid Meeting Date and Time

Details
SELECTION OF SOCIAL MEDIA
MANAGEMENT AGENCY FOR THE
DEPARTMENT
OF
HEALTH,
MEDICAL
EDUCATION
AND
FAMILY WELFARE, GOVERNMENT
OF JHARKHAND.
29/07/2026
06/08/2026 at 03:00 PM (R.C.H. Conference
Hall, Namkum, Ranchi, Jharkhand-834010)

Last Date & time for receipt of bid on 25/08/2026 at 02:00 PM
website
Date & time of opening of Technical Bid 25/08/2026 at 02:30 PM
through website
Earnest Money Deposit (EMD)

2,00,000/- (Two Lakh Only)

Contact no. of procurement person

9110943588
Note:-The above dates may change due to abrupt declaration of holidays.
Hard copies of Technical Bid will not be entertained.

7

Sd-/-

State Nodal Officer Procurement Cell
Jharkhand Rural Health Mission Society,
Namkum, Ranchi.

<!-- page 2 -->

बड सं या/Bid Number : GEM/2026/B/7849662
दनांक /Dated: 29-07-2026

बड द तावेज़ / Bid Document

बड ववरण/
ववरण/ Bid Details
बड बंद होने क तार ख/
ख/समय /Bid End Date/Time

25-08-2026 14:00:00

बड खुलने क तार ख/
ख/समय /Bid Opening

25-08-2026 14:30:00

Date/Time
बड पेशकश वैधता (बं
(बंद होने क तार ख से) /Bid Offer
Validity (From End Date)

180 (Days)

मं ालय/
ालय/रा य का नाम /Ministry/State Name

Jharkhand

वभाग का नाम/Department
नाम
Name

Health Medical Education And Family Welfare Department
Jharkhand

संगठन का नाम /Organisation Name

N/a

कायालय का नाम /Office Name

Jharkhand Rural Health Mission Society

िशकायत िनवारण के संपक ववरण/
ववरण Contact details of HOD Email id :proc-health@jharkhandmail.gov.in
Buyer Email id: santosh79.nhm@gmail.com
Grievance redressal

व तु

Hiring of Social Media Agency - Content creation, Content
response and content moderation, Campaign Management,
As per RFP, Basic reporting and analytics; Hindi, English, As
per RFP; Facebook, Twitter, Instagram, YouTube, As per RFP

ण
े ी /Item Category

अनुबंध अविध /Contract Period

3 Year(s)

बडर का यूनतम औसत वा षक टनओवर (3 वष का)
का)
/Minimum Average Annual Turnover of the
bidder (For 3 Years)

500 Lakh (s)

उ ह ं/समान सेवा के िलए अपे

त वगत अनुभव के

वष/Years
वष
of Past Experience Required for
same/similar service

3 Year (s)

टनओवर पा ता मानदं ड /Turnover eligibility criteria

To be verified by the buyer at the time of technical
evaluation

एमएसएमई के िलए अनुभव के वष और टनओवर से छूट दान
क गई है /MSE Relaxation for Years of
Experience and Turnover

No

टाटअप के िलए अनुभव के वष और टनओवर से छूट दान
क गई है /Startup Relaxation for Years of
Experience and Turnover

No

1/7

<!-- page 3 -->

बड ववरण/
ववरण/ Bid Details

व े ता से मांगे गए द तावेज़/Document required
from seller

या आप िन वदाकार

Experience Criteria,Bidder Turnover,Certificate (Requested
in ATC),Additional Doc 1 (Requested in ATC),Additional Doc
2 (Requested in ATC),Additional Doc 3 (Requested in
ATC),Additional Doc 4 (Requested in ATC)
*In case any bidder is seeking exemption from Experience /
Turnover Criteria, the supporting documents to prove his
eligibility for exemption must be uploaded for evaluation by
the buyer

ारा अपलोड कए गए द तावेज़ को

िन वदा म भाग लेने वाले सभी िन वदाकार को दखाना
चाहते ह? संदभ मेनू है /Do you want to show
documents uploaded by bidders to all
bidders participated in bid?
बड लगाने क समय सीमा

Yes (Documents submitted as part of a clarification or
representation during the tender/bid process will also be
displayed to other participated bidders after log in)

वतः नह ं बढ़ाने के िलए

आव यक बड क सं या।
या। / Minimum number of

3

bids required to disable automatic bid
extension
दन क सं या,
या, जनके िलए बड लगाने क समयसमय-सीमा
बढ़ाई जाएगी।
जाएगी। / Number of days for which Bid

7

would be auto--extended
ऑटो ए सटशन अिधकतम कतनी बार कया जाना है । /
Number of Auto Extension count
बड से रवस नीलामी स

2

य कया/Bid
कया
to RA enabled Yes

रवस नीलामी यो यता िनयम/RA
िनयम
Qualiﬁcation Rule

H1-Highest Priced Bid Elimination

बड का

Two Packet Bid

कार/Type
कार
of Bid

तकनीक मू यांकन के दौरान तकनीक

प ीकरण हे तु

अनुमत समय /Time allowed for Technical
Clarifications during technical evaluation

2 Days

मू यांकन प ित/Evaluation
ित
Method

Total value wise evaluation

मू य दशाने वाला व ीय द तावेज ेकअप आव यक है /
Financial Document Indicating Price
Breakup Required

Yes

म य थता खंड /Arbitration Clause

No

सुलह खंड /Mediation Clause

No

ईएमड

ववरण/EMD
ववरण
Detail

एडवाईजर बक/Advisory Bank

State Bank of India

ईएमड रािश/EMD Amount

200000

ईपीबीजी ववरण /ePBG Detail

2/7

<!-- page 4 -->

एडवाइजर बक/Advisory Bank

State Bank of India

ईपीबीजी

ितशत (%)/ePBG Percentage(%)

5.00

ईपीबीजी क आव यक अविध (माह) /Duration of ePBG

38

required (Months).

(a). जेम क शत के अनुसार ईएमड छूट के इ छुक बडर को संबंिधत केटे गर के िलए बड के साथ वैध समिथत द तावेज़ तुत करने है । एमएसई
केटे गर के अंतगत केवल व तुओं के िलए विनमाता तथा सेवाओं के िलए सेवा दाता ईएमड से छूट के पा ह। यापा रय को इस नीित के दायरे से
बाहर रखा गया है ।/EMD EXEMPTION: The bidder seeking EMD exemption, must submit the valid supporting document
for the relevant category as per GeM GTC with the bid. Under MSE category, only manufacturers for goods and
Service Providers for Services are eligible for exemption from EMD. Traders are excluded from the purview of this
Policy.
(b).ईएमड और संपादन जमानत रािश, जहां यह लागू होती है , लाभाथ के प
in favour of Beneficiary, wherever it is applicable.
(c).ईएमड और संपादन जमानत रािश लाभाथ के प
the buyer in the form of a surety bond.

म होनी चा हए। / EMD & Performance security should be

म होनी चा हए। / Earnest Money Deposit (EMD) shall also be accepted by

लाभाथ /Beneficiary :
Mission Director
Jharkhand Rural Health Mission Society, Health Medical Education and Family Welfare Department Jharkhand
(Aviyan Nideshak Rastriya Swasthya Mission)

UIN Number NCTGC2415P
बोली वभाजन लागू नह ं कया गया/ Bid splitting not applied.
एमआईआई अनुपालन/MII
ालन
Compliance
एमआईआई अनुपालन/MII Compliance

Yes

एमएसई खर द वर यता/MSE
यता
Purchase Preference
एमएसई खर द वर यता/MSE Purchase Preference

No

1. The minimum average annual financial turnover of the bidder during the last three years, ending on 31st
March of the previous financial year, should be as indicated above in the bid document. Documentary evidence in
the form of certified Audited Balance Sheets of relevant periods or a certificate from the Chartered Accountant /
Cost Accountant indicating the turnover details for the relevant period shall be uploaded with the bid. In case the
date of constitution / incorporation of the bidder is less than 3-year-old, the average turnover in respect of the
completed financial years after the date of constitution shall be taken into account for this criteria.
2. Years of Past Experience required: The bidder must have experience for number of years as indicated above in
bid document (ending month of March prior to the bid opening) of providing similar type of services to any
Central / State Govt Organization / PSU. Copies of relevant contracts / orders to be uploaded along with bid in
support of having provided services during each of the Financial year.
3. Estimated Bid Value indicated above is being declared solely for the purpose of guidance on EMD amount and
for determining the Eligibility Criteria related to Turn Over, Past Performance and Project / Past Experience etc.
This has no relevance or bearing on the price to be quoted by the bidders and is also not going to have any
impact on bid participation. Also this is not going to be used as a criteria in determining reasonableness of
quoted prices which would be determined by the buyer based on its own assessment of reasonableness and
based on competitive prices received in Bid / RA process.

3/7

<!-- page 5 -->

4. Reverse Auction would be conducted amongst all the technically qualified bidders except the Highest quoting
bidder. The technically qualified Highest Quoting bidder will not be allowed to participate in RA. However, H-1
will also be allowed to participate in RA in following cases:
i. If number of technically qualified bidders are only 2 or 3.
ii. If Buyer has chosen to split the bid amongst N sellers, and H1 bid is coming within N.
iii. In case Primary product of only one OEM is left in contention for participation in RA on elimination of H-1.
iv. If L-1 is non-MSE and H-1 is eligible MSE and H-1 price is coming within price band of 15% of Non-MSE L-1
v. If L-1 is non-MII and H-1 is eligible MII and H-1 price is coming within price band of 20% of Non-MII L-1
अित र

यो यता /आव
/आव यक डे टा/Additional
ा
Qualification/Data Required

Geographic Presence Required. Also specify the documents to be uploaded by Service Provider in
Compliance of this condition.:As per RFP
Scope of Work/Creative Brief:1785316053.pdf
Payment Terms:1785316057.pdf

This Bid is based on Least Cost Method Based Evaluation (LCS). The technical qualification
parameters are:-

Parameter Name

Max
Marks

Min
Marks

Evaluation
Document

Seller Document
Required

LCS technical parameters as per
document

100

70

View file

Yes

Total Minimum Passing Technical Marks: 70

Pre Bid Detail(s)
मू य िभ नता खंड द तावेज़ /Pre-Bid
Date and Time

ीी बड थान/Pre-Bid
थान
Venue

06-08-2026 15:00:00

R.C.H. Conference Hall, Namkum, Ranchi, Jharkhand-834010

Hiring Of Social Media Agency - Content Creation, Content Response And Content
Moderation, Campaign Management, As Per RFP, Basic Reporting And Analytics;
Hindi, English, As Per RFP; Facebook, Twitter, Instagram, YouTube, As Per RFP ( 36 )
तकनीक

विश याँ /Technical Specifications
ववरण/
ववरण Specification

मू य/
य Values

कोर / Core
Social Media

Content creation , Content response and content moderation ,
Campaign Management , As per RFP , Basic reporting and analytics

Language Versions

Hindi , English , As per RFP

Handles Required

Facebook , Twitter , Instagram , YouTube , As per RFP

एडऑन /Addon(s)
Fresh photoshoot for creating a
photobank

NA

4/7

<!-- page 6 -->

ववरण/
ववरण Specification
Developing video content of 1-2
minute duration with fresh shoot

े ता

मू य/
य Values
NA

ारा िनधा रत यूनतम मू य/Minimum
य
Floor Price defined by Buyer

े ता ारा िनधा रत यूनतम मू य/Minimum Floor Price
defined by Buyer

अित र

विश

No

द तावेज़ /Additional Specification Documents

परे षती/
षती/ रपो टग अिधकार /Consignees/Reporting Officer and Quantity

.सं. /S.N
o.

1

परे षती/
षती/ रपो टग
अिधकार /Consignee
Reporting/Officer

Santosh Kumar

े ता

पता/Address
पता

ारा जोड़ गई बड क

834010,Jharkhand Rural Health
Mission Society, G V I Campus,
Tata Road, Namkum, Ranchi

संसाधन क मा ा
/ Quantity
(Number of
Months for
which Social
Media
Agency is
required)

36

अित र आव यकता
/Additional
Requirement

N/A

वशेष शत /Buyer Added Bid Specific Terms and Conditions

1. Generic
OPTION CLAUSE 25% : The buyer can increase or decrease the contract quantity or contract duration up
to 25 percent at the time of issue of the contract. However, once the contract is issued, the contract
quantity or contract duration can only be increased up to 25 percent. Bidders are bound to accept the
revised quantity or duration.
For lumpsum-based service contracts, the buyer may increase the scope of work and contract value up to
25 percent with the consent of the service provider
2. Buyer Added Bid Specific ATC
Buyer uploaded ATC document Click here to view the file .

अ वीकरण/Disclaimer
The Additional Terms and Conditions (ATC) have been incorporated by the Buyer after approval of their
Competent Authority. The Buyer ,is solely responsible for the impact of these clauses on the bidding process, its
outcome, and consequences thereof including any restriction arising in the bidding process due to these ATCs
and including the modification of technical specifications and / or terms and conditions governing the bid.All
representations / grievances pertaining to the ATC clauses shall be raised with the buyer organization directly
and not with GeM.If any of the clause(s) is/are incorporated by the Buyer regarding the following, the bid &

5/7

<!-- page 7 -->

resultant contract shall be treated as null & void. Further, GeM reserves the right, at its sole discretion, to cancel
the bid forthwith, without issuance of any prior notice or intimation :1. Publishing Custom / BOQ bids for items for which regular GeM categories are available (unless such
Custom / BOQ item is bunched with the major regular product Category Item).
2. Mandating procurement of / from specific Brand / Make / Model / Manufacturer / Dealer except in case of
Single Bid / Proprietary Article Certificate (PAC) Buying.
3. Inclusion of disqualification criteria related to suspension of seller / service provider, where such
suspension period has already expired.
4. Mandating submission of documents in physical form as a pre-requisite to qualify bidders.
5. Publishing bids on GeM for procurement of works.
6. Procurement of Goods by creating a Service bid on GeM & vice-versa.
7. Seeking sample with bid or approval of samples during bid evaluation process. However, trial / sample, as
the case may be, shall be permitted in cases where trial / sample are allowed as per approved and
published procurement policy of the Buyers’ controlling Ministry / Department / State / Public Sector
Enterprises Headquarters. If there is any violation of trial / sample clause with regard to approved policy
of the Buyers’ Ministry / Department / State / Public Sector Enterprises Headquarters, then this is to be
determined and redressed by the concerned Buyer Organisation only.
8. Seeking experience from specific organization / department / institute only or from foreign / export
experience.
9. Creating bid for items from incorrect categories.
10. Reference of conditions published on any external site or reference to external documents/clauses.
11. Asking for any Tender fee / Bid Participation fee, as the case may be.
12. Buyer added ATC Clauses which are in contravention of clauses defined in bid detail section, including
specifications, EMD Detail, ePBG Detail and MII and MSE Purchase Preference sections of the bid, unless
otherwise allowed by the applicable GeM GTC.
13. Any ATC clause in contravention with GeM GTC Clause 4 (xiii) (h) will be invalid. In case of multiple L1
bidders against a service bid, the buyer shall place the Contract by selection of a bidder amongst the L-1
bidders through a Random Algorithm executed by GeM system.
14. In a category based bid, adding additional items, through buyer added, additional scope of work/
additional terms and conditions/or any other document. If buyer needs more items along with the main
item, the same must be added through bunching category based items or by bunching custom catalogues
or bunching a BoQ with the main category based item, the same must not be done through ATC or Scope
of Work.
Further, if any seller has any objection/grievance against these additional clauses or otherwise on any aspect of
this bid, they can raise their representation against the same by using the Representation window provided in
the bid details field in Seller dashboard after logging in as a seller. Buyer is duty bound to reply to all such
representations and would not be allowed to open bids if he fails to reply to such representations.

All GeM Sellers/Service Providers shall ensure full compliance with all applicable labour laws,
including the provisions, rules, schemes and guidelines under the four Labour Codes i.e. the Code
on Wages, 2019; the Industrial Relations Code, 2020; the Occupational Safety, Health and Working
Conditions Code, 2020; and the Code on Social Security, 2020 as and when notified and brought into
force by the Government of India.
For all provisions of the Labour Codes that are pending operationalisation through rules, schemes or
notifications, the corresponding provisions of the pre-existing labour enactments (such as The
Minimum Wages Act, 1948, The Payment of Wages Act, 1936, The Payment of Bonus Act, 1965, The
Equal Remuneration Act, 1976, The Payment of Gratuity Act, 1972, etc. and relevant State Rules)
shall continue to remain applicable.
The Seller/ Service Providers shall, therefore, be responsible for ensuring compliance under:
All notified and enforceable provisions of the new Labour Codes as mentioned hereinabove;
and
All operative provisions of the erstwhile Labour Laws until their complete substitution.
All obligations relating to wages, social security, safety, working conditions, industrial relations etc.
and any other statutory requirements shall be strictly met by the Seller/ Service Provider. Any non-

6/7

<!-- page 8 -->

compliance shall constitute a breach of the contract and shall entitle the Buyer to take appropriate
action in accordance with the contract and applicable law.
This Bid is governed by the General Terms and Conditions, conditions stipulated in Bid and Service
Level Agreement specific to the Service, as the case may be, as provided in the Marketplace.
However, in case of Service, if any condition specified in General Terms and Conditions is
contradicted by the conditions stipulated in Service Level Agreement specific to said Service, then it
will over-ride the conditions in the General Terms and Conditions.
This Bid is governed by the सामा य िनयम और शत/General Terms and Conditions, conditions stipulated in Bid and
Service Level Agreement specific to this Service as provided in the Marketplace. However in case if any condition
specified in सामा य िनयम और शत/General Terms and Conditions is contradicted by the conditions stipulated in
Service Level Agreement, then it will over ride the conditions in the General Terms and Conditions.
जेम क सामा य शत के खंड 26 के संदभ म भारत के साथ भूिम सीमा साझा करने वाले दे श के बडर से खर द पर
भारत के साथ भूिम सीमा साझा करने वाले दे श का कोई भी बडर इस िन वदा म बड दे ने के िलए तभी पा
स म

ितबंध के संबंध म

होगा जब वह बड दे ने वाला

ािधकार के पास पंजीकृ त हो। बड म भाग लेते समय बडर को इसका अनुपालन करना होगा और कोई भी गलत घोषणा कए जाने

व इसका अनुपालन न करने पर अनुबंध को त काल समा

करने और कानून के अनुसार आगे क कानूनी कारवाई का आधार होगा।/In terms

of GeM GTC clause 26 regarding Restrictions on procurement from a bidder of a country which shares a land border with India, any bidder from a country which shares a
land border with India will be eligible to bid in this tender only if the bidder is registered with the Competent Authority. While participating in bid, Bidder has to undertake
compliance of this and any false declaration and non-compliance of this would be a ground for immediate termination of the contract and further legal action in
accordance with the laws.

---ध यवाद /Thank You---

7/7
