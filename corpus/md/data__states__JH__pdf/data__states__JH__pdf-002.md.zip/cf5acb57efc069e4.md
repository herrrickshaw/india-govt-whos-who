---
doc_id: "cf5acb57efc069e4"
source_url: "https://tourism.jharkhand.gov.in/cms/Application/uploadDocuments/Tender/Other2_20250701_225404.pdf"
ministry: "Tourism Department, Jharkhand"
title: "RFP Volume II"
date: ""
pages: 104
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a029666a680b8fb0"
---

<!-- page 1 -->

RFP No. 583/JTDCL dated 01.07.2025

Request For Proposal

Selection of Suitable Private Sector Player
Operation, Maintenance and Management of
Hotel Prabhat Vihar, Netarhat, Jharkhand.

VOLUME II - Draft Authorization Agreement (DAA)

<!-- page 2 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

TABLE OF CONTENTS
TABLE OF CONTENTS ....................................................................................................................................... 2
PART I PRELIMINARY ........................................................................................................................................ 6
ARTICLE 1

1.1.
1.2.
1.3.
1.4.

Definitions
Interpretation
Measurements and arithmetic conventions
Priority of agreements, clauses and schedules:

ARTICLE 2

2.1
PART II

7.1
7.2
7.3

8.1

25
31
32
32
33
33
33
33
34

OBLIGATION OF THE AUTHORITY ........................................................................................ 35

General Obligations of the Authority

35

REPRESENTATIONS, WARRANTIES AND UNDERTAKINGS .............................................. 38

Representations and warranties of the Operator
Representations, warranties and Covenants of the Authority
Disclosure

ARTICLE 8

21
22
23
23
23
23

OBLIGATION OF THE OPERATOR ........................................................................................ 25

General Obligations of the Operator
Obligations relating to Project Agreements
Obligation relating to employment of foreign nationals
Obligations relating to aesthetic quality of the Project Facilities
Sole purpose of the Operator
EHS Standards and L&FS Standards
Obligations relating to Taxes
Obligations relating to information
Obligations relating to other charges

ARTICLE 7

18
19
19
20

CONDITION PRECEDENT ....................................................................................................... 21

Conditions Precedent (CP)
Obligation to Satisfy Conditions Precedent
Damages for delay by the Authority
Damages for delay by the Operator
Commencement of the Authorization Period
Termination upon delay

ARTICLE 6

6.1

GRANT OF AUTHORIZATION ................................................................................................. 18

The Authorization
Authorization Period
Actions in Support of the Authorization
Substitution of the Authority

ARTICLE 5

5.1
5.2
5.3
5.4
5.5
5.6
5.7
5.8
5.9

13

THE AUTHORIZATION .................................................................................................................... 17

ARTICLE 4

4.1
4.2
4.3
4.4
4.5
4.6

9
9
11
11

SCOPE OF THE PROJECT ...................................................................................................... 13

Scope of the Work

ARTICLE 3

3.1
3.2
3.3
3.4

DEFINITIONS AND INTERPRETATION..................................................................................... 9

38
39
40

DISCLAIMER ............................................................................................................................ 41

Disclaimer

Request for Proposal - Volume II: Draft Authorization Agreement

41

Page 2 of 104

<!-- page 3 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

PART III

OPERATION ................................................................................................................................... 42

ARTICLE 9

9.1
9.2
9.3

PERFORMANCE SECURITY ................................................................................................... 43

Performance Security
Appropriation of Performance Security
Release of Performance Security

ARTICLE 10

PROJECT FACILITY ................................................................................................................ 45

10.1 The Project Facility
ARTICLE 11

12.1
12.2
12.3
12.4
12.5
12.6

13.1
13.2
13.3
13.4

16.1
16.2
16.3
16.4
16.5

17.1
17.2
17.3
17.4
17.5
17.6

54
54
55

56
56
57
57
58

: FORCE MAJEURE ................................................................................................................. 59

Force Majeure
Non-Political Event
Indirect Political Event
Political Event
Duty to report Force Majeure Event
Effect of Force Majeure Event on the Authorization

ARTICLE 18

53
53

TARIFF AND FEE ..................................................................................................................... 56

Tariff Structure
Payment of Management Fee by the Authority
Interest on Delayed Payments
Disputed Amounts
Keys Reserved for the Authority

ARTICLE 17

52

: CHANGE OF SCOPE ............................................................................................................. 54

15.1 Change of Scope
15.2 Procedure for Change of Scope
15.3 Payment for Change of Scope
ARTICLE 16

52
52

HOSPITALITY CUM TOURISM SERVICES ............................................................................. 53

14.1 Quality of Services
14.2 Hotel Management System
ARTICLE 15

48
49
49
50
50
51

MONITORING OF OPERATION AND MAINTENANCE ........................................................... 52

Monthly Status Reports
Inspection
Tests 52
Remedial measures

ARTICLE 14

47

OPERATION AND MAINTENANCE ......................................................................................... 48

O&M Obligations of the Operator
Maintenance Requirements
Safety, breakdowns and accidents
Overriding powers of the Authority
Excuse from performance of obligations
Authority's right to take remedial measures

ARTICLE 13

45

ENTRY INTO COMMERCIAL SERVICE .................................................................................. 47

11.1 Commercial Operation Date
ARTICLE 12

43
43
44

59
59
59
59
60
60

: EVENTS OF DEFAULT .......................................................................................................... 62

Request for Proposal - Volume II: Draft Authorization Agreement

Page 3 of 104

<!-- page 4 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

18.1
18.2
18.3
18.4
18.5

The Authority Event of Default
Authorizee Event of Default
Termination due to Event of Default
Rights of the Authority on Termination
Accrued Rights of Parties

ARTICLE 19

62
62
64
66
66

: LIABILITY AND INDEMNIFICATION ..................................................................................... 68

19.1 Liability to Third Parties
19.2 Indemnification
19.3 Risk and Liability
ARTICLE 20

68
68
68

: INSURANCE ........................................................................................................................... 69

20.1 Coverage
20.2 Evidence of Insurance Coverage
ARTICLE 21

21.1
21.2
21.3
21.4
21.5
21.6
21.7
21.8
21.9

: TRANSFER OF PROJECT ..................................................................................................... 70

Scope of Transfer
Right of the Authority to choose Insurance and Contractor Warranties
Assignment of Contracts
Condition of the Facility upon Transfer
Passing of Risk
Transfer Costs
Handing Over Procedure
Effect of Transfer
Deemed Transfer

ARTICLE 22

ARTICLE 23

25.1
25.2
25.3
25.4
25.5
25.6
25.7
25.8
25.9

77
77
77
77

REDRESSAL OF PUBLIC GRIEVANCES ............................................................................... 78

24.1 Complaints Register
24.2 Redressal of complaints
ARTICLE 25

76
76

: ACCOUNTS AND AUDIT ....................................................................................................... 77

Audited accounts
Appointment of Auditors
Certification of claims by Statutory Auditors
Set-off

ARTICLE 24

70
70
70
70
71
71
71
72
73

: DISPUTE RESOLUTION ........................................................................................................ 76

22.1 Amicable Settlement
22.3 Performance during Dispute Resolution

23.1
23.2
23.3
23.4

69
69

78
78

MISCELLANEOUS ................................................................................................................... 79

Amendments
Severance of Terms
Interest for Delayed Payment
Language
Notices
Governing Law
Original Document
Relationship
Survival

Request for Proposal - Volume II: Draft Authorization Agreement

79
79
79
79
79
80
80
80
81

Page 4 of 104

<!-- page 5 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

25.10 Authorized Representative
25.11 Waiver
25.12 Others
ARTICLE 26

81
81
81

DEFINITIONS............................................................................................................................ 83

26.1 Definitions

83

SCHEDULE A: PROJECT SITE & FACILITY .................................................................................................... 91
SCHEDULE B: OPERATION & MAINTENANCE PLAN ................................................................................... 95
SCHEDULE C: FINANCIAL QUOTE OF THE AUTHORIZEE ........................................................................... 96
SCHEDULE D: DRAWINGS............................................................................................................................... 97
SCHEDULE E: PERFORMANCE SECURITY.................................................................................................... 98
SCHEDULE F: MAINTENANCE REQUIREMENTS ......................................................................................... 101

Request for Proposal - Volume II: Draft Authorization Agreement

Page 5 of 104

<!-- page 6 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

PART I PRELIMINARY

Request for Proposal - Volume II: Draft Authorization Agreement

Page 6 of 104

<!-- page 7 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

This AUTHORIZATION AGREEMENT (Agreement) is entered into on this _______20___ at
_______.
BETWEEN
1. Managing Director, Jharkhand Tourism Development Corporation Limited, with its
principal office at _____________ (hereinafter referred to as the Authority which
expression shall, unless repugnant to the context or meaning thereof, include its
administrators, successors and permitted assigns) of One Part;
AND
2. […………………….. a company incorporated under the provisions of the Companies Act,
1956/2013, bearing corporate identification number [●] with its registered office at [●],
India (hereinafter referred to as the “Operator” which expression shall, unless repugnant
to the context or meaning thereof, include its successors and permitted assigns and
substitutes) of the Other Part.
The Authority and the Operator shall collectively be referred to as “Parties” and individually as a
“Party”.
WHEREAS:
A. The Government of Jharkhand is considering private sector participation to augment the
tourism facilities in Jharkhand with special emphasis on developing eco-tourism resorts
at identified locations in the State of Jharkhand. For this purpose, the Government has
empowered the Authority to undertake Selection of Suitable Private Sector Player for
Operation, Maintenance and Management of Prabhat Vihar (New Complex) (hereinafter
referred to as the Project).
B. The details of Project Site and its location are as under:
Project Site

Geo-coordinates

Hotel Prabhat Vihar Complex

23°28’26.1”N 84°16’43.9”E

C. The Authority had invited proposals for the selection of an Operator through the
competitive route for the operations and management of the Project from bidders,
including [●] (the “Successful Bidder”) by issuing the Request for proposal (“RFP”)
document dated [●] 2025 containing inter-alia the minimum qualification for a bidder; the
technical and commercial parameters and the terms and conditions for the operations and
management of the Project.
D. Pursuant to the terms of the RFP, bids were received by the Authority on or before [last
date of bid submission post extension if any]. The Selected Bidder had also submitted its
bid for the Project (the “Bid”).

Request for Proposal - Volume II: Draft Authorization Agreement

Page 7 of 104

<!-- page 8 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

E. Following the evaluation of the bids submitted by the Bidders, including that of the
Selected Bidder, the Authority had accepted the Bid.
F. Subsequently, the Authority had issued the letter of award no. [●] dated [●] (the “Letter of
Award” or “LOA”) to the Selected Bidder, interalia, requiring it to incorporate a private
limited company under the Companies Act (as defined hereinafter) and execution of this
Agreement within 30 (thirty) days of the date of issue thereof.
NOW, THEREFORE, in consideration of the promises and mutual covenants herein contained,
the adequacy of which is hereby acknowledged and confirmed, the terms and conditions of this
Agreement are set out below.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 8 of 104

<!-- page 9 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 1

DEFINITIONS AND INTERPRETATION

1.1.

Definitions

1.1.1

The words and expressions beginning with capital letters and defined in this Agreement
(including those in Article 26) shall, unless the context otherwise requires, have the
meaning ascribed thereto herein, and the words and expressions defined in the
Schedules and used therein shall have the meaning ascribed thereto in the Schedules.

1.2.

Interpretation

1.2.1

In this Agreement, except where the context otherwise requires:
a)

references to any legislation or any provision thereof shall include amendment or
reenactment or consolidation of such legislation or any provision thereof so far as
such amendment or re-enactment or consolidation applies or is capable of applying
to any transaction entered into hereunder;

b)

references to laws of India or Indian law or regulation having the force of law shall
include the laws, acts, ordinances, rules, regulations, bye-laws or notifications which
have the force of law in the territory of India and as from time to time may be
amended, modified, supplemented, extended or re-enacted;

c)

references to a “person” and words denoting a natural person shall be construed
as a reference to any individual, firm, company, corporation, society, trust,
government, state or agency of a state or any association or partnership (whether
or not having separate legal personality) of two or more of the above and shall
include successors and assigns;

d)

the table of contents, headings or sub-headings in this Agreement are only for
convenience of reference and shall not be used in, and shall not affect, the
construction or interpretation of this Agreement;

e)

the words “include” and “including” are to be construed without limitation and shall
be deemed to be followed by “without limitation” or “but not limited to” whether or
not they are followed by such phrases;

f)

references to “construction” or “building” include, unless the context otherwise
requires, investigation, design, developing, engineering, procurement, delivery,
transportation, installation, processing, fabrication, testing, commissioning and
other activities incidental to the construction, and “construct” or “build” shall be
construed accordingly;

g)

references to “development” include, unless the context otherwise requires,
construction, renovation, refurbishing, augmentation, up-gradation and other
activities incidental thereto, and “develop” shall be construed accordingly;

h)

any reference to any period of time shall mean a reference to that according to
Indian Standard Time;

i)

any reference to “hour” shall mean a period of 60 (sixty) minutes commencing either
on the hour or on the half hour of the clock, which by way of illustration means 5.00

Request for Proposal - Volume II: Draft Authorization Agreement

Page 9 of 104

<!-- page 10 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

(five), 6.00 (six), 7.00 (seven) and so on being hours on the hour of the clock and
5.30 (five thirty), 6.30 (six thirty), 7.30 (seven thirty) and so on being hours on the
half hour of the clock;
j)

any reference to “day” shall mean a reference to a calendar day;

k)

references to a “business day” shall be construed as a reference to a day (other
than a Sunday or a statutory holiday as declared by the Government of Jharkhand
on which Banks in State of Jharkhand are generally open for business;

l)

any reference to month shall mean a reference to a calendar month as per the
Gregorian calendar;

m) references to any date, period or Project Milestone shall mean and include such
date, period or Project Milestone as may be extended pursuant to this Agreement;
n)

any reference to any period commencing 'from' a specific date or date and 'till' or
'until' a specific day or date shall include both such days or dates; provided that if
the last day of any period computed under this Agreement is not a business day,
then the period shall run until the end of the next business day;

o)

the words importing singular shall include plural and vice versa;

p)

references to any gender shall include the other and the neutral gender;

q)

“lakh” means a hundred thousand (1,00,000) and “crore” means ten million
(10,000,000);

r)

“indebtedness” shall be construed so as to include any obligation (whether incurred
as principal or surety) for the payment or repayment of money, whether present or
future, actual or contingent;

s)

save and except as otherwise provided in this Agreement, any reference, at any
time, to any agreement, deed, instrument, licence or document of any description
shall be construed as reference to that agreement, deed, instrument, licence or
other document as amended, varied, supplemented, modified or suspended at the
time of such reference; provided that this Clause 1.2.1 (s) shall not operate so as to
increase liabilities or obligations of the Authority hereunder or pursuant hereto in
any manner whatsoever;

t)

any agreement, consent, approval, authorisation, notice, communication,
information or report required under or pursuant to this Agreement from or by any
Party shall be valid and effective only if it is in writing under the hand of a duly
authorised representative of such Party in this behalf and not otherwise;

u)

the Schedules and Recitals to this Agreement form an integral part of this
Agreement and shall be in full force and effect as though they were expressly set
out in the body of this Agreement;

v)

references to Recitals, Articles, Sub-Articles, provisos or Schedules in this
Agreement shall, except where the context otherwise requires, mean references to
Recitals, Articles, Sub-Articles, provisos and Schedules of or to this Agreement;
reference to an Annexure shall, subject to anything to the contrary specified therein,
be construed as a reference to an Annexure to the Schedule in which such reference

Request for Proposal - Volume II: Draft Authorization Agreement

Page 10 of 104

<!-- page 11 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

occurs; and reference to a paragraph shall, subject to anything to the contrary
specified therein, be construed as a reference to a paragraph of the Schedule or
Annexure, as the case may be, in which such reference appears;
w) the damages payable by either Party to the other of them, as set forth in this
Agreement, whether on per-diem basis or otherwise, are mutually agreed genuine
pre-estimate of loss and damages likely to be suffered and incurred by the Party
entitled to receive the same and are not by way of penalty (the “Damages”); and
x)

time shall be of the essence in the performance of the Parties’ respective
obligations. If any time period specified herein is extended, such extended time shall
also be of the essence.

1.2.2

Unless expressly provided otherwise in this Agreement, any documentation required to
be provided or furnished by the Operator to the Authority shall be provided free of cost
and in 3 (three) copies, and if the Authority is required to return any such documentation
with their comments and/or approval, they shall be entitled to retain 2 (two) copies thereof.

1.2.3

The rule of upgradation and construction, if any, that a contract should be interpreted
against the Party responsible for the drafting and preparation thereof, shall not apply.

1.2.4

Any word or expression used in this Agreement shall, unless otherwise defined or
construed in this Agreement, bear its ordinary English meaning and, for these purposes,
the General Clauses Act, 1897 shall not apply.

1.3.

Measurements and arithmetic conventions

1.3.1

All measurements and calculations shall be in the metric system and calculations done to
2 (two) decimal places, with the third digit of 5 (five) or above being rounded up and below
5 (five) being rounded down.

1.4.

Priority of agreements, clauses and schedules:
(a) This Agreement, and all other agreements and documents forming part of or referred
to in this Agreement are to be taken as mutually explanatory and, unless otherwise
expressly provided elsewhere in this Agreement, the priority of this Agreement and
other documents and agreements forming part hereof or referred to herein shall, in
the event of any conflict between them, be in the following order:
i.
the Agreement;
ii.

all other agreements and documents forming part hereof or referred to herein;

iii.

the LOA issued to the Selected Bidder;

iv.

written addenda to the Bid document such as RFP, response to queries, etc;

v.

Bid document; and

vi.

Bid;

(b) Subject to the provisions of Clause 1.4 (a), in case of ambiguities or discrepancies
within this Agreement, the following shall apply:

Request for Proposal - Volume II: Draft Authorization Agreement

Page 11 of 104

<!-- page 12 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

i.

between two or more Articles of this Agreement, the provisions of a specific
Article relevant to the issue under consideration shall prevail over those in
other Articles;

ii.

between the Articles of this Agreement and the Schedules, the Articles shall
prevail;

iii.

between any two Schedules, the Schedule more relevant to the issue under
consideration shall prevail;

iv.

between the written description on the Drawings and the Specifications and
Standards, the latter shall prevail;

v.

between the dimension scaled from the Drawing and its specific written
dimension, the latter shall prevail; and

vi.

between any value written in numerals and that in words, the latter shall
prevail.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 12 of 104

<!-- page 13 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 2

SCOPE OF THE PROJECT

2.1 Scope of the Work
2.1.1 The Selected Operator/ Authorizee shall be responsible for the full operational,
maintenance, and management services of the Hotel, ensuring high standards of guest
service, facility upkeep, and compliance with applicable laws and standards at its own
cost unless mentioned otherwise in this Agreement. The Operator shall also manage and
provide food and beverage services, including all restaurants and bars within the
premises.:
•

•

•

Operation Management
▪

Staff recruitment, training, and management to deliver quality service and
maintain high employee morale as per good industry practices.

▪

Ensure security of the Project Facility by employing adequate security staffs
for 24 hour security of the Project Facility.

▪

Day-to-day management of hotel operations, including front desk,
housekeeping, concierge, and guest services. Handle procurement and
inventory control for cleaning materials and equipment at its own cost.

▪

Implement and maintain standard operating procedures (SOPs) for all
departments.

▪

Ensure compliance with applicable health, safety, and hospitality regulations.

▪

Implement and manage guest satisfaction programs, customer feedback
systems, and service recovery processes.

Maintenance and Facility Management
▪

Conduct preventive and corrective maintenance programs as per Good
Industry Practices.

▪

Maintain the physical condition of guest rooms, public areas, back-of-house,
and external premises.

▪

Maintain a 24/7 technical support and emergency response system.

Food and Beverage Services
▪

Operate and manage all food and beverage outlets, including restaurants,
bars, room service, and banquet services.

▪

Menu planning, food quality control, and supplier management.

▪

Ensure compliance with food safety and hygiene regulations.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 13 of 104

<!-- page 14 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

•

•

•

•

▪

Manage culinary and service staff to ensure a high standard of hospitality.

▪

Conduct regular promotions, events, and marketing for F\&B outlets.

▪

Handle procurement and inventory consumables for smooth functioning of
F&B services.

Marketing and Sales
▪

Develop and execute marketing and sales strategies to drive occupancy and
revenue.

▪

Manage digital marketing, online travel agency (OTA) listings, and social
media presence.

▪

Establish partnerships and packages to attract leisure, business, and group
travel segments.

▪

Conduct public relations and promotional events as required.

Legal and Compliance
▪

Ensure all activities are in compliance with local laws, labor regulations, and
environmental standards.

▪

Handle legal matters related to operations, including disputes with guests,
staff, or suppliers, in consultation with the Authority.

Insurance and Risk Management
▪

Implement risk mitigation and safety protocols.

▪

Maintain adequate insurance coverage for liability and personnel as agreed
with the Authority.

Scope Exclusion: The Authorizee scope excludes Major Maintenance of the Project
Facility. For the purpose of this Agreement, Major Maintenance includes:
▪

Cost involved of INR 10,000 or more at one point of time in the replacement of
fittings, fixtures & furniture’s or replacement of any related items, civil
maintenance works etc.

▪

However, the Major Maintenance cost does not includes cost of consumables
required for day to day routine maintenance of the Project Facility

2.1.2 Roles & Responsibilities of the Authority: The Authority retains overall Authority-ship and
strategic oversight of the hotel property. While day-to-day management is delegated to
the Operator, the Authority plays a critical role in governance, capital planning, financial
oversight, and protecting long-term asset value.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 14 of 104

<!-- page 15 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

•

•

•

•

Authority-ship and Asset Responsibility
▪

Retain legal Authority-ship of the land, building, and all fixed assets.

▪

Fund and approve long-term capital investments, major renovations, or
expansions.

▪

Fund all operative expenses excluding expenses on food & beverages, staff/
manpower laundry services and utility charges.

▪

Implement Hotel Management System for reservations, POS, accounting.

▪

Maintain insurance coverage for property damage, business interruption, and
Authority-related liabilities.

▪

Conduct public relations and promotional events as required.

▪

Manage digital marketing, online travel agency (OTA) listings, and social
media presence.

Oversight and Strategic Direction
▪

Approve the hotel's annual business plan, including budgets, marketing
strategy, capital expenditure plans, as proposed by the Operator.

▪

Monitor hotel performance through regular reviews of financial and operational
reports submitted by the Operator.

▪

Set strategic objectives or limitations for the Operator (e.g., branding, target
markets, sustainability goals).

Financial Contributions and Approvals
▪

All revenues from the Project shall be deposited directly in a bank or banks
designated by the Authority and in accounts established in the name of Owner
and under the sole control of the Authority ("Project Revenue Accounts") as
more particularly defined under Clause 16.1.3, which monies may be swept or
transferred into other Authority accounts as often as Authority determines.

▪

Provide funding for initial fit-out and capital improvements unless otherwise
agreed.

▪

Operation & Maintenance of the Project Site.

Contractual and Legal Roles
▪

•

Retain legal and tax responsibilities for Authority-ship structure, local taxes,
and compliance.

Capital Expenditure and Long-Term Planning

Request for Proposal - Volume II: Draft Authorization Agreement

Page 15 of 104

<!-- page 16 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

•

▪

Approve and fund capital expenditure budgets (CAPEX), refurbishment plans,
expansion and major maintenance works as advised by the Operator.

▪

Plan for long-term asset value preservation, including periodic property
upgrades and brand compliance.

Limitations (Non-Interference in Day-to-Day Operations)
▪

The Authority shall not interfere in daily hotel operations or personnel
management, except where specifically provided for in the Draft Authorization
Agreement.

▪

Any direction to the Operator should be made through the agreed governance
structure (e.g., Authority's Representative or formal meeting process).

Request for Proposal - Volume II: Draft Authorization Agreement

Page 16 of 104

<!-- page 17 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

PART II

THE AUTHORIZATION

Request for Proposal - Volume II: Draft Authorization Agreement

Page 17 of 104

<!-- page 18 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 3

GRANT OF AUTHORIZATION

3.1

The Authorization

3.1.1

In accordance with the provisions of this Authorization Agreement, the Applicable
Laws and the Applicable Approvals, the Authority hereby grants (with effect from
Appointed Date) to the Authorizee/ Operator the exclusive right, permission, leave and
licence rights in respect of the Project Facility (Schedule A) free of any Encumbrances, to
Operate, Maintain & Manage the Project Facility, together with all and singular rights,
liberties, privileges, easements and appurtenances whatsoever to the said Project
Facility, hereditaments or premises or any part thereof belonging to or in any way
appurtenant thereto or enjoyed therewith, for the duration of the Authorization Period and,
for the purposes permitted under this Agreement, and for no other purpose whatsoever
(hereinafter the “Authorization”);, and the Authorizee hereby accepts the Authorization
and agrees to implement the Project subject to and in accordance with the terms and
conditions set forth herein. For avoidance of doubt, it is clarified that at all times the
Authority shall have the absolute, unencumbered legal Authorityship rights in respect of
the Project Facility and the Project Site and the Authorizee shall only be entitled to
exercise its Authorization and/or Operate, Maintain and Manage the Project Facility in
Good Working Condition/good condition (as the case may be) till the expiry or earlier
termination of the Authorization Period.

3.1.2

Subject to and in accordance with the provisions of this Agreement, the License hereby
granted shall oblige or entitle (as the case may be) the Authorizee to:
a. Exclusive right of way, access, to the Project Facility for t h e purpose of
Operate, maintain and manage the Project Facility as per the terms of this
Authorization Agreement;
b. bear and pay all costs, expenses and charges in connection with or
incidental to the performance of the obligations of the Authorizee under this
Authorization Agreement;
c. perform and fulfil all of the Authorizee’s obligations under and in accordance
with this Agreement;
d. not assign, transfer or sublet or create any lien or Encumbrance on this
Agreement and/or Project Site and/or Project Facility or the Authorization
hereby granted or on the whole or any part of the Project Facility nor transfer
or part possession thereof, save and except as expressly permitted by this
Agreement.
e. Notwithstanding anything to the contrary contained herein, it is hereby clearly
understood, agreed, confirmed and recorded between the Parties as follows:
i.
the legal possession in respect of the Project Facility/ Project Site shall
continue to vest in the Authority and the Authorizee shall only be entitled to
exclusive license to undertake the implementation of the Project in terms
hereof and shall not be entitled to use of the Project Facility for any purpose
other than those expressly permitted in terms hereof.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 18 of 104

<!-- page 19 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ii.

iii.

iv.

the grant of Authorization in terms hereof shall not vest or create any
proprietary interest in the Project Facility/ Project Site or any part thereof in
favour of the Authorizee or any other person claiming under the Authorizee.
The Authorizee shall not in any manner sell, transfer, assign, mortgage,
charge, create any lien or otherwise create Encumber in respect of the
Authorized/ Licensed Project Facility or the Project Site, or assign or
transfer this Authorization Agreement in favour of any person at any time
and for any reason whatsoever; save and except as otherwise provided in
terms of the Authorization.
The Authorizee acknowledges, accepts and confirms that the covenant
contained herein forms the essence of this Agreement and shall duly bind
the Authorizee and/or any person claiming under it.

3.2

Authorization Period

3.2.1

The Authorizee has been granted the Authorization to operate, maintain and manage the
Project Facility for a Authorization period of 5 (five) years commencing from the Appointed
Date.

3.2.2

The Authorization Period may be further be extended by the Authority for another 5 (Five)
years provided that the Operator is not in the breach of the terms & conditions of this
Agreement.

3.2.3

It is agreed that upon the expiry of the Authorization Period after 10 (Fifty) years, the same
shall not be extended on mutual consent basis without an open competitive bidding
process.

3.2.4

The Authority agrees that it will not unduly or unreasonably interfere with the exercise by
Operator of its managerial rights and authority hereunder, and agrees specifically that it
will not seek to appoint other parties to conduct any portion of Project operations (other
than expansion, maintenance and repairs required to be performed by Authority), or
otherwise seek to exert direct supervision, control or management of Project operations,
all subject, however, to Authority's rights as expressly set forth in this Agreement.

3.3

Actions in Support of the Authorization
a. The Authority shall, on best effort basis, and subject always to Authorizee
fulfilling the eligibility criteria and duly complying with all requirements,
render such assistance as the Authorizee may reasonably require, from time to time,
for availing and obtaining all Applicable Approvals and f o r completion of formalities
relating to the Project provided the Authorizee is in compliance with the rules,
regulations and guidelines prescribed by the Statutory Authorities;
b. The Authority shall, on best effort basis, provide all assistance and recommendations
to the Statutory Authority, in support of the Authorizee’s applications for Applicable
Approvals that m a y b e needed from time to time for the implementation of
the Project provided that the Authorizee has made the requisite applications and is

Request for Proposal - Volume II: Draft Authorization Agreement

Page 19 of 104

<!-- page 20 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

in compliance with the necessary norms and regulations
Authority for the grant of such Applicable Approvals.

of

the

Statutory

3.4

Substitution of the Authority

3.4.1

The Parties expressly agree that the Authority may, in pursuance of any re-organisation
or restructuring undertaken in pursuance of Applicable Laws or in the event the Authorityship of the Project Site is transferred from the Authority to any other public entity,
substitute itself by any other public entity having the capacity to undertake and discharge
the duties and obligations of the Authority with a similar or greater creditworthiness, and
upon such substitution, all the functions, rights and obligations of the Authority under this
Agreement shall be deemed to be transferred to the substituted entity in accordance with
and subject to Applicable Laws; provided, however, that prior to any such substitution, the
Parties shall, on a best endeavour basis, make such arrangements and enter into such
further agreements as may be necessary for performance of their respective obligations
hereunder.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 20 of 104

<!-- page 21 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 4

CONDITION PRECEDENT

4.1

Conditions Precedent (CP)

4.1.1

Save and except as expressly provided herein, the respective rights and obligations
of the Parties under this Authorization Agreement shall be subject to the satisfaction in
full of the conditions precedent specified in this Clause 4.1.

4.1.2

Condition Precedent to be fulfilled by the Authorizee: The Conditions Precedent required
to be satisfied by the Authorizee shall be deemed to have been fulfilled when the
Authorizee shall have:

4.1.3

a)

procured within six months from date of execution of this Agreement (“Effective
Date”) or such later date as may be mutually agreed by Parties, all the Applicable
Approvals/ permits specified in terms hereof unconditionally or if subject to
conditions then all such conditions shall have been satisfied in full and such
Applicable Approvals/ permits are in full force and effect.

b)

provided the Performance Security to the Authority pursuant to Article 9;

c)

Prepared, submitted and get an approval on the Operation Plan for the Project
Facility in accordance with Article 12 of this Authorization Agreement;

d)

Undertaking joint survey of the Project Facility including the equipments/
machineries/ fittings & fixtures.

The performance of obligations set out herein by the Authorizee shall be subject to
fulfilment of following Conditions Precedents by the Authority.
a)

Hand over the Project Facility to the Authorizee after completion of all remedial
works as decided in the joint survey by the Authority and the Authorizee.

b)

Undertaking joint survey of the Project Facility in order to determine if the assets
which are to be handed over to the Authorizee are in functional & operational and
in Good Working Condition, and recording the same in and by way of executing
a written memorandum, which would also set out therein the detailed list/inventory
of the equipments and/or fittings / fixtures being handed over in Good Working
Condition; and a separate list (“Punch List”) of equipments/ machinery (including
parts/sub-assemblies) determined as required to be repaired / replaced / added /
installed in order to bring the Hotel in functional condition in consultation with the
Authorizee, shall be also drawn simultaneous with such hand over.
The Authority shall complete the remedial works towards fulfillment of the Punch
List items before the Appointed Date or such later date as mutually agreed, and
forthwith upon completion of the same notify the Authorizee in respect of holding
of a joint survey of the same with a view to determine whether the
installed/repaired/replaced machines/equipments conform to Good Working
Condition. In case the parties, pursuant to such joint survey determines that the
Punch List items [including its machines/equipments] conforms to Good Working

Request for Proposal - Volume II: Draft Authorization Agreement

Page 21 of 104

<!-- page 22 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Condition (as evidenced by recording the same in a written inventory
memorandum) Authority shall issue to Authorizee operation certificate in respect
of such Punch List items. In the event, pursuant to such joint inspection, any
disagreement/dispute arises as to non-performance of the Punch List equipments
as per the Good Working Condition, Authority may (in the event it determines any
remedial work is required) address the remedial works (including replacing the
sub-parts/sub-assemblies of such equipments) to ensure Good Working Condition
or in case Authority determines (in its sole discretion) that Punch List equipments
already are operational under Good Working Condition and the dispute raised by
Authorizee does not reasonably hold good, select (in its sole discretion) to
terminate the Authorization Agreement in which case neither party shall be held
to be under any liability arising from such termination, save and except as
otherwise provided in terms hereof and particularly the Authorization Agreement.
c)

provide the Authorizee the warranty card, user manuals, annual maintenance
contract documents related to the procured equipments/ machineries/ fittings &
fixtures. .

4.1.4

Each Party shall make all reasonable endeavours to satisfy the Conditions Precedent
within the time stipulated i n r e s p e c t t h e r e o f and shall provide the other Party with
such reasonable cooperation as may be required to assist that Party in satisfying
the Conditions Precedent for which that Party is responsible.

4.2

Obligation to Satisfy Conditions Precedent
i.

Each Party shall make all reasonable endeavours at its respective cost and
expense to comply in full with the Conditions Precedent relating to it within
maximum six months of the Effective Date or such later date as may be mutually
agreed by Parties; provided however that such condition precedent for completion
whereof specific time period has been prescribed herein shall be completed within
such time period.

ii.

In the event that any of the Conditions Precedent has not been fulfilled with the
time period specifically prescribed or such time period as may be mutually agreed
by Parties, then (subject to terms hereof) Authority [in case of non-fulfilment of
Authorizee Condition Precedent] or Authorizee [in case of non-fulfilment of
Authority Condition Precedent] may terminate this Agreement.
Provided however that neither Party shall be entitled to terminate this Agreement if
non-fulfilment of condition precedent by either party is result and/or consequence
of Force Majeure event.
Provided further that in the event Agreement is terminated on account of nonfulfilment of Authorizee condition precedent, then Authority shall be entitled to
appropriate and forfeit the Bid Security; which in termination on account of other
reasons [ i.e reason not attributable to Authorizee non-performance] shall be
returned/released to the Authorizee, without any interest thereon, provided there
are no outstanding claims of the Authority on the Authorizee.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 22 of 104

<!-- page 23 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

4.3

Damages for delay by the Authority

4.3.1

In the event that: (i) the Authority does not procure fulfilment or waiver of the Condition
Precedent set forth in Clause 4.1.3 within the period specified in respect thereof; and (ii)
the delay has not occurred as a result of breach of this Agreement by the Operator or due
to Force Majeure Event, the Authority shall pay Damages to the Operator of an amount
calculated at the rate of 0.1% (zero point one per cent) of the Performance Security for
each day’s delay until the fulfilment of such Conditions Precedent, subject to a maximum
amount equal to the Bid Security.

4.4

Damages for delay by the Operator

4.4.1

In the event that: (i) the Operator does not procure fulfilment or waiver of any or all of the
Conditions Precedent set forth in Clause 4.1.2 within the period specified in that Clause ;
and (ii) the delay has not occurred as a result of breach of this Agreement by the Authority
or due to Force Majeure Event, the Operator shall pay Damages to the Authority of an
amount calculated at the rate of 0.2% (zero point two per cent) of the Performance
Security for each day’s delay until the fulfilment or waiver of such Conditions Precedent,
up to the maximum amount equal to the Bid Security and upon reaching such maximum
amount, the Authority may, in its sole discretion and subject to the provisions of Clause
9.1, terminate the Agreement. Provided that in the event of delay by the Authority in
procuring fulfilment of the Conditions Precedent specified in Clause Error! Reference
source not found., no Damages shall be due and payable by the Operator under this
Clause 4.4 until the date on which the Authority shall have procured fulfilment of the
Conditions Precedent specified in Clause Error! Reference source not found..

4.5

Commencement of the Authorization Period

4.5.1

The Appointed Date shall be the date when both the parties satisfied or waived the
Condition Precedent, as the case may be,
The Commencement of Authorization and Operation shall be the Appointed Date. For
avoidance of doubt, the Parties agree that the Operator may, upon occurrence of the
Appointed Date hereunder, by notice convey the particulars thereof to the Authority, and
shall thereupon be entitled to commence development of the Project in accordance with
the terms of this Agreement.

4.5.2

4.6

Termination upon delay

4.6.1

Without prejudice to the provisions of Clause 4.3 and Clause 4.4, and subject to the
provisions of Clause 9.2, the Parties expressly agree that in the event the Appointed Date
does not occur, for any reason whatsoever, within a period of 360 (three hundred and
sixty) days from the Execution Date or the extended period provided in accordance with
this Agreement, then all rights, privileges, claims and entitlements of the Operator under
or arising out of this Agreement shall be deemed to have been waived by, and to have

Request for Proposal - Volume II: Draft Authorization Agreement

Page 23 of 104

<!-- page 24 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ceased with the concurrence of the Operator and the Agreement may be terminated by
the non-defaulting Party. Provided, however, that in the event the delay in occurrence of
the Appointed Date is for reasons attributable to the Operator, the Performance Security
or the Bid Security, as the case may be, of the Operator shall be encashed and
appropriated by the Authority as Damages thereof.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 24 of 104

<!-- page 25 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 5

OBLIGATION OF THE OPERATOR

5.1

General Obligations of the Operator

5.1.1

In addition to and not in derogation or substitution of any of its other obligations
under this Agreement, the Authorizee shall have the following obligations at its own
cost:
a. The Authorizee shall operate, maintain and manage the Project Facility in
accordance with the Operation Plan as approved by the Authority and Good
Industry Practices.
b. The Authorizee shall undertake operation of the Project facility by itself and will not
outsource to the third party its obligation in full.
c. Authorizee shall, during the Operations Period and subsistence of this Agreement:
i.
shall have requisite organisation and designate and appoint suitable
officers/ representatives as it may deem appropriate to supervise the
Project Facility, to deal with the Authority and to be responsible for all
necessary exchange of information required pursuant to this Agreement;
ii.
shall, for the purposes of determining that the Project Facility is being
maintained in accordance with the O&M Requirements as mentioned
under the Approved Operation Plan, the Authorizee shall with due
diligence carry out all necessary and periodical Tests in accordance with
and as per the instructions of the Authority or its Authorised representatives
and such Tests shall be carried out under the supervision of the
Authority or its Authorised Representatives. The Authorizee shall maintain
proper record of such Tests and the remedial measures taken to cure the
defects or deficiencies, if any, indicated by the Test results.
d. The Operator shall maintain in Authority's name or in Operator's name, as
determined and agreed by Authority and Operator, or both, as may be required by
Legal Requirements, all licenses or permits required for the ongoing operation of
the Project and its related facilities, and Operator shall operate the Project in
compliance with all material Legal Requirements including the rules, regulations or
orders of any agency or instrumentality establishing life safety or fire safety
standards applicable to the Project. Authority and Operator shall cooperate with
each other in all reasonable respects as may be necessary or advisable to permit
the Project to be operated in compliance with Legal Requirements, including,
without limitation, preparation and execution of required applications for operational
licenses and permits, execution of necessary consents, providing necessary
information regarding Authority, Operator or the Project, as applicable, and
submitting to requirements of local police and governmental officials regarding
specialized licenses such as liquor licenses.

5.1.2

Recruitment, Training and Remuneration

Request for Proposal - Volume II: Draft Authorization Agreement

Page 25 of 104

<!-- page 26 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

a.

The Authorizee shall at its cost and expenses recruit and train all personnel required
for the operation, maintenance and management of the Project Facilities under this
Agreement.
b. The recruitment, training and remuneration of the personnel, employees and
staff required for the operation, maintenance and management of the Project shall
be the responsibility of the Authorizee and be in compliance with all statutory
provisions enacted under the Labour and other Applicable Laws.
c. Provided, no personnel, staff or employee under the Authorizee whether temporary
or permanently employed for the purposes of implementation of this Project shall,
under any circumstances, be deemed to be in employment with the Authority or
Government of Jharkhand and the Authorizee shall ensure that its operations are
conducted in a manner so that any employer- employee relationship is not imputed
between the Authority and the employees, personnel and staff of the Authorizee.
d. Authorizee shall ensure that all staff engaged in the delivery of the services are all
times properly and adequately notified, trained and instructed in accordance with
Good Industry Practice and the standards of their relevant professional body, if any,
in the execution of their duties and information records are maintained
accordingly.
e. Authorizee shall ensure that all staff are properly and presentably dressed in
appropriate uniforms and work wears (including protective clothing and foot-wears
wherever required), maintain a high standard of personal hygiene commensurate
with their allocated tasks and wear identification badges at all times while working
in the Project Facility.
f. In the event that the Authority decides that a particular staff/personnel should
be removed from the position due to lack of requisite qualification, training or
has consistently demonstrated lack of capability in providing the required services,
the Authorizee shall have to abide by such decision and act on the advice of the
Authority promptly. The decision of the Authority in this regard shall be final.
5.1.3

FOOD & BEVERAGES SERVICE:
Food and Beverages (F&B) is a critical component of the management agreement.
This typically covers all aspects of operating the hotel's dining facilities and services.
The Authorizee shall handles all aspects of the hotel's dining experience to ensure
profitability, efficiency, and guest delight.
a. Designing and regularly updating menus for all F&B outlets (restaurants, bars,
room service, banquets, catering) to align with current culinary trends, guest
preferences, and the hotel's brand standards.
b. Considering nutritional aspects, dietary restrictions, and sourcing locally/sustainably
where possible.
c. Experimenting with flavors, textures, and presentations to create unique dining
experiences.
d. Concept Development: Creating distinct concepts for different F&B outlets within the
hotel (e.g., fine dining, casual bistro, themed bar).
e. Pricing and Cost Control:

Request for Proposal - Volume II: Draft Authorization Agreement

Page 26 of 104

<!-- page 27 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

i.

Developing pricing strategies for all menu items to maximize revenue
while remaining competitive.
ii.
Implementing stringent cost control measures for food, beverages, and
labor, including managing inventory and reducing waste.
iii.
Monitoring revenues and expenses to ensure profitability.
f. Marketing and Promotions:
i.
Developing and executing marketing strategies to promote the hotel's F&B
offerings to in-house guests and external customers.
ii.
Budgeting and Financial Management: Preparing annual operating
budgets for the F&B department, managing finances, and providing
regular financial reports to the Authority.
g. Operational Management:
i.
Overseeing the day-to-day operations of all restaurants, bars, cafes, and
lounges.
ii.
Ensuring high-quality service, efficient order taking, and accurate delivery.
iii.
Maintaining cleanliness, ambiance, and service standards.
iv.
Room Service: Managing the room service department, including order
taking, food preparation, delivery, and billing.
v.
Planning, organizing, and executing food and beverage services for
events, conferences, weddings, and other special occasions.
vi.
Managing logistics, staffing, and coordination with event planners.
vii.
Supervising kitchen operations, including food preparation, cooking, and
plating.
viii.
Ensuring adherence to recipes, quality standards (taste, presentation,
temperature), and consistency.
ix.
Sourcing and purchasing all food and beverage supplies.
x.
Implementing efficient inventory systems to minimize waste and ensure
product availability.
xi.
Ensuring proper storage and security of F&B products.
xii.
Establishing and enforcing strict food safety regulations and hygiene
standards across all F&B areas.
xiii.
Conducting regular inspections and audits.
xiv.
Equipment Maintenance: Ensuring all F&B equipment is in proper
operational condition and regularly cleaned and maintained. Notifying
engineering immediately of any repair needs.
xv.
Hiring, training, and supervising all F&B staff, including chefs, cooks,
waiters, bartenders, hostesses, and stewards.
xvi.
Developing and implementing comprehensive training programs for F&B
staff on service standards, menu knowledge, responsible alcohol service,
food safety, and customer service skills.
xvii.
Performance Management: Evaluating staff performance, addressing
issues, and implementing strategies for improvement.
xviii.
Shift Scheduling: Managing staff schedules to ensure adequate coverage
for all F&B operations.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 27 of 104

<!-- page 28 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

xix.

xx.
xxi.
xxii.
5.1.4

Customer Service: Ensuring all guests receive exceptional customer
service, from greeting and order taking to handling complaints and special
requests promptly and professionally.
Quality Assurance: Continuously monitoring the quality of food,
beverages, and service to ensure guest satisfaction.
Feedback and Improvement: Collecting guest feedback (surveys, reviews)
and using it to identify areas for improvement and innovation.
Compliance: Adhering to all relevant legislation and regulations related to
food service and alcohol.

SECURITY
a. Authorizee shall provide security services for maintaining a secure environment
within the Project Facility and responding to security incidents within the Project
Facility. Authorizee shall ensure that all system and controls are in place and
are functional to safeguard property, cash and commodities
b. The security shall be provided 24 hours per day, 365 days per year.
c. Authorizee shall:
i.
provide a security service to ensure the safety and security of all guests,
staff and bona fide visitors to the Project Facility;
ii.
provide professional integrated security services on a scheduled and
reactive basis, which are efficient, effective and timely;
iii.
maintain the safety of all persons, and their belongings, within the Project
Facility. This includes the protection of guests, staff, service providers
and visitors against violent acts or abuse;
iv.
protect the Project Facility and property, guests, staff, and visitors against
theft, vandalism, malicious tampering and criminal damage; and
v.
ensure only bona fide visitors are allowed access to the Project Facility.
This includes restricting access of undesirable persons to the Project
Facility in general and restricting access to sensitive areas to authorised
personnel only.
d. Authorizee shall provide reports on all incidences of crime to the concerned
government department and to the Authority within the Project Facility.

5.1.5

LINEN AND LAUNDRY SERVICES:
a. The Authorizee shall provide comprehensive linen and laundry service to ensure
clean and appropriate linen is available in all areas in volumes necessary to support
the smooth running of the Project Facility.
b. The Authorizee shall:
i.
Provide a proactive and reactive clean linen supply service.
ii.
Ensure that the handling and transport of all linen fully complies with the
good practices to minimize the risk of contamination within the facilities
iii.
Manage the linen stock to maximize efficiencies while maintaining high
service standards at all times including emergency demands of the
Project.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 28 of 104

<!-- page 29 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

iv.
All linen storage places shall comply with the control of infection practices.
v.
All linen shall be clean and serviceable
c. Authorizee shall have option to use the onsite laundry or offsite option for laundering
of linen and in all cases should abide by all the applicable environmental rules and
regulations as applicable.
d. Curtain and blind laundering: Authorizee shall ensure that all curtains and blinds
are clean all time.
5.1.6

PEST CONTROL
a. Authorizee shall undertake regular and periodic pest control to ensure that facility
is free from the pests and rodents. It shall ensure the use of chemicals for pest
control is in compliance with statutory compliance and banned chemicals are not
used for this purpose. Authorizee shall maintain the record on number, type
and location of infestation reported and signed and dated pest control activity
reports.

5.1.7

WASTE MANAGEMENT
a. Authorizee shall put in place comprehensive waste management plan for managing
and undertaking the safe segregation, handling, transport and disposal of waste.

5.1.8

EQUIPMENT MAINTENANCE
a. Authorizee shall undertake comprehensive planned and proactive maintenance of
equipment to ensure that equipment is safe, accurate and working to optimum
performance and to achieve maximum availability and continuity of services by
minimizing the inconvenience caused by equipment breakdowns and
interruptions, and achieving effective delivery of service from all medical
equipment and services by maintaining standards set by the equipment
manufacturer. For abundant clarity, the Authorizee shall have alternate
arrangements during any sort of maintenance/repair of equipment’s/ machines/
apparatus to ensure delivery of services as envisaged in this Agreement is not
hampered/ hindered/ stopped.
b. The maintenance shall include:
i.
Planned protective maintenance designed to keep unplanned
breakdown and disruptions minimum;
ii.
Reactive maintenance providing rectification or arranging similar
system to provide continuity of services; and
c. Authorizee shall maintain logbook of planned and reactive maintenance.
d. Authorizee shall enter into Comprehensive Maintenance Contract with equipment
manufacturers/ suppliers valid throughout the Authorization Period. Authorizee shall
enter into appropriate contractual arrangement for supply of spare parts and
equipment parts/components. Authorizee should also ensure to get these
equipment insured at their own cost, the day the equipment is installed at the Project
Facility.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 29 of 104

<!-- page 30 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

5.1.9

e. Authorizee shall ensure sufficient stocks of materials and consumables are
maintained for the provisions of the services and that such materials shall be
stored in a clean and tidy manner in earmarked areas.
f. Scope Exclusion: The Authorizee scope excludes Major Maintenance of the Project
Facility. For the purpose of this Agreement, Major Maintenance includes:
a. Cost involved of INR 10,000 or more at one point of time in the
replacement of fittings, fixtures & furniture’s or replacement of any related
items, civil maintenance works etc.
b. Provided however, in case of delay by the Authority in undertaking the
Major Maintenance resulting in revenue loss or operational loss, the
Authorizee will undertake such Major Maintenance (after informing the
Authority), the cost of which will be reimburse by the Authority on actual
basis.
RECORD KEEPING AND REPORTING
a. All records and plans related to the Project and Project Facility shall be kept at
the Project Facility. The list of records to be maintained shall include following:
i.
The Project Agreement, its Schedules and the project documents
including all amendments to such agreements.
ii.
Records relating to the appointment and supersession of the
Authorizee’s representative and the Authority’s representative.
iii.
Project data documents
iv.
Records relating to any specialist or statutory inspections of the
Facilities.
v.
Notices, reports, results and certificates relating to completion of the
Works and completion of the commissioning activities.
vi.
All operation and maintenance manuals
vii.
Documents relating to events of Force Majeure, delay events, Events of
Default and Relief Events and the consequences of the same.
viii.
All formal notices, reports or submissions made to or received from the
Authority in connection with the provision of services, the monitoring of
performance, or the availability of the facilities.
ix.
All certificates, licences, registrations or warranties related to the
provision of Project Facility and services.
x.
Records related to Taxes.
xi.
Documents relating to Testing.
xii.
Records required by Law and all Consents.
xiii.
Documents relating to insurance and insurance claims.
xiv.
All other records, notices or certificates required to be produced
and/or maintained by Authorizee pursuant to Authorization
Agreement or any Project Document.
b. Authorizee shall report to the Authority in agreed format and quality and at agreed
frequency.
c. Compliant register shall be available at Project Facility at all the times. The
Complaint register shall be made available to the Authority as and when asked for.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 30 of 104

<!-- page 31 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

5.2

Obligations relating to Project Agreements

5.2.1

It is expressly agreed that the Operator shall, at all times, be responsible and liable for all
its obligations under this Agreement. Notwithstanding anything contained in the Project
Agreements or any other agreement, and no default under any Project Agreement or any
other agreement shall excuse the Operator from its obligations or liability hereunder.

5.2.2

Before finalisation, the Operator shall submit to the Authority the drafts of all Project
Agreements and the operation and maintenance contract (if any) or any amendments or
replacements thereto for its review and comments, and the Authority shall have the right
but not the obligation to undertake such review and provide its comments and
observations, if any, to the Operator. Operator shall appropriately consider all such
comments or observations. Within 7 (seven) days of execution of any Project Agreement
or amendment thereto, the Operator shall submit to the Authority a true copy thereof, duly
attested by a Director of the Operator, for its record. For avoidance of doubt, it is agreed
that the review and comments or observations by the Authority on any Project Agreement
or failure or omission of the Authority to review and/ or comment hereunder shall not be
construed or deemed as acceptance of any such agreement or document by the Authority.
No review and/or observation of the Authority and/or its failure to review and/or convey its
observations on any document shall relieve the Operator of its obligations and/or liabilities
under this Agreement in any manner whatsoever nor shall the Authority be liable for the
same in any manner whatsoever.

5.2.3

Notwithstanding anything to the contrary contained in this Agreement, the Operator shall
not sub-Authorization, assign or in any manner create an Encumbrance on any of the
Project Assets as the case may be, without prior written approval of the Authority, which
approval the Authority may, in its discretion, deny if such sub-Authorization, assignment
or Encumbrance has or may have a Material Adverse Effect on the rights and obligations
of the Authority under this Agreement or Applicable Laws.

5.2.4

The Operator shall procure that each of the Project Agreements contains provisions that
entitle the Authority to step into such agreement, in its sole discretion, in substitution of
the Operator in the event of Termination or Suspension (the “Covenant”). For the
avoidance of doubt, it is expressly agreed that in the event the Authority does not exercise
such rights of substitution within a period not exceeding 90 (ninety) days from the Transfer
Date, the Project Agreements shall be deemed to cease to be in force and effect on the
Transfer Date without any liability whatsoever on the Authority and the Covenant shall
expressly provide for such eventuality. The Operator expressly agrees to include the
Covenant in all its Project Agreements and undertakes that it shall, in respect of each of
the Project Agreements, procure and deliver to the Authority an acknowledgment and
undertaking, in a form acceptable to the Authority, from the counter party(ies) of each of
the Project Agreements, where such counter party(ies) shall acknowledge and accept the
Covenant and undertake to be bound by the same and not to seek any relief or remedy
whatsoever from the Authority in the event of Termination or Suspension.

5.2.5

Notwithstanding anything to the contrary contained in this Agreement, the Operator
agrees and acknowledges that selection or replacement of the Contractor and execution

Request for Proposal - Volume II: Draft Authorization Agreement

Page 31 of 104

<!-- page 32 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

of the Project Agreement shall be subject to the prior approval of the Authority from
national security and public interest perspective, the decision of the Authority in this behalf
being final, conclusive and binding on the Operator and undertake that it shall not give
effect to any such selection or contract without prior approval of the Authority. For
avoidance of doubt, it is expressly agreed that approval of the Authority hereunder shall
be limited to national security and public interest perspective, and the Authority shall
endeavour to convey its decision thereon expeditiously. It is also agreed that the Authority
shall not be liable in any manner on account of grant or otherwise of such approval and
that such approval or denial thereof shall not in any manner absolve the Operator or its
Contractors from any liability or obligation under this Agreement.
5.2.6

It is expressly agreed that the Operator shall allow expansion of the Project Facility,
in case the Authority so desire. In such a case, the Operator shall coordinate and
discuss the expansion plan with the Authority so that the such expansion by the
Authority of the Project facility can take place without hampering the Operation of
the Project Facility. Further, the Operator shall have to undertake the Operation,
Maintenance and Management of the expanded Project Facility or such expanded
facility within the Project Site on, if the Authority so wished to provide the same to
the Operator on similar terms & conditions.

5.3

Obligation relating to employment of foreign nationals

5.3.1

The Operator acknowledges, agrees and undertakes that employment of foreign
personnel by the Operator and/or its Contractors and their sub-contractors shall be in
accordance with Applicable Laws and subject to grant of Applicable Permits, including
employment or residential visas and work permits. The Operator shall obtain such
Applicable Permits at its own cost and expense. Notwithstanding anything to the contrary
contained in this Agreement, refusal of or inability to obtain any such permit or approval
by the Operator or any of its Contractors or sub-contractors shall not constitute a Force
Majeure Event, or allow any extension of time to the Operator for performance of its
obligations under this Agreement and shall not in any manner excuse the Operator from
the performance and discharge of its obligations and liabilities under this Agreement.

5.4

Obligations relating to aesthetic quality of the Project Facilities

5.4.1

The Operator shall maintain a high standard in the appearance and aesthetic quality of
the Project Facilities and achieve integration of the Project Facilities with the character of
the surrounding landscape through both appropriate design and sensitive management
of all visible elements for all the Project Site. The Operator shall engage professional
architects of repute for ensuring that the design of the Project Facilities meets the
aforesaid aesthetic standards.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 32 of 104

<!-- page 33 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

5.5

Sole purpose of the Operator

5.5.1

The Operator shall not, except with the prior written consent of the Authority, be or become
directly or indirectly engaged, concerned or interested in any business other than the
business incidental or consequential to the provisions of this Agreement.

5.6

EHS Standards and L&FS Standards

5.6.1

The Operator shall at all times and throughout the Authorization Period comply with
Applicable Laws including the relevant “Environmental, Health and Safety” (the “EHS”)
rules and regulations and “Life and Fire Safety Standards” (the “L&FS Standards”).

5.6.2

The Operator shall prepare and comply with the performance standards, including an
environmental and sustainability plan stating how the Operator intends to manage and
mitigate risks in relation to EHS. Such performance standards shall take into consideration
the principles set out in:
(a)

National EHS regulations (http://www.moef.nic.in/ and others);

(b)

Real Estate (Regulation and Development) Act, 2016;

(c)

National Building Code of India published by BIS (http://www.bis.org.in/) and
other statutory BIS standards applicable to projects of similar nature; and

(d)

L&FS Standards;

5.7

Obligations relating to Taxes

5.7.1

The Operator shall pay within the prescribed time, at all times during the subsistence of
this Agreement, all Taxes including GST, fees, levies, duties, cesses and all other
statutory charges payable in respect of the Operation of the Project Facilities.

5.8

Obligations relating to information

5.8.1

Without prejudice to the provisions of Applicable Laws, Applicable Permits and this
Agreement, upon receiving a notice from the Authority for any information that it may
reasonably require or that it considers may be necessary to enable it to perform any of its
functions, the Operator shall provide such information to the Authority forthwith and in the
manner and form required by the Authority.

5.8.2

After receiving a notice from the Authority for reasoned comments on the accuracy and
text of any information relating to the Operator’s activities under or pursuant to this
Agreement which the Authority proposes to publish, the Operator shall provide such
comments to the Authority in the manner and form required by the Authority.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 33 of 104

<!-- page 34 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

5.9

Obligations relating to other charges

5.9.1

The Operator shall make timely payments for all utility services in respect of the Project
Site, Project Assets, Project Facilities and Project Infrastructure, including water, sewage,
electricity, telecommunication, internet and cable charges etc.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 34 of 104

<!-- page 35 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 6

OBLIGATION OF THE AUTHORITY

6.1

General Obligations of the Authority

6.1.1

The Authority shall, at its own cost and expense, undertake, comply with and perform all
its obligations set out in this Agreement.

6.1.2

Hand over the Project Facility to the Authorizee after completion of all remedial works as
decided in the joint survey by the Authority and the Authorizee.
In case the Parties, pursuant to such joint survey determines that the Punch List items
[including its machines/equipments] conforms to Good Working Condition (as evidenced
by recording the same in a written inventory memorandum) Authority shall issue to
Authorizee operation certificate in respect of such Punch List items.
6.1.3 Provide Operator the sole and exclusive right and full authority to direct, manage and
control all aspects of the Operation, maintenance and Management including promotion
and marketing of the Project (and its constituent facilities and amenities) in a manner
consistent with the Project Standard, as Operator in its reasonable discretion deems
advisable, subject only to the express provisions and limitations set forth in this Agreement
(including Clause 5.1.2 above). Without limiting the generality of the foregoing, Operator
shall have the power and authority, on behalf of Authority, to:
6.1.3.1
establish rates for hotel usage including room rates for individuals and groups,
charges for room service, food and beverage and for use of recreational,
entertainment or other guest facilities or amenities at the Project. It being understood
and agreed that the Operator shall have the right, in his/her discretion, to grant
discounted or complimentary rooms, food, beverage or other services when he/she
reasonably deems the same to be in the best business interests of the Project,
consistent with Operator's standard policies and procedures in effect from time to time,
and generally in accordance with industry standards regarding the same;
6.1.3.2
establish labour policies and terms of employment (including wage rates and fringe
benefits and other items comprising Employee Costs) and arrange for and oversee
the hiring, promotion, discharge, supervision and training of all project employees;
6.1.3.3
establish and maintain a system of accounting and record keeping, in accordance with
Clause 5.1.9;
6.1.3.4
develop and implement an appropriate records management and retention system,
and retention policies, providing for the maintenance, storage and destruction of
Project records;
6.1.3.5
use reasonable efforts to maintain the Project in good condition and repair throughout
the Term including all portions of the Building Systems, Furniture, Fixtures and
Operating Equipment, all in accordance with maintenance programs established by
Operator from time to time;
6.1.3.6
procure all necessary inventories of food, beverages and other consumables, and
Operating Equipment for the Project;

Request for Proposal - Volume II: Draft Authorization Agreement

Page 35 of 104

<!-- page 36 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

6.1.3.7

take such actions as Operator shall reasonably determine to be necessary to comply
with applicable Legal Requirements (to the extent within Operator's reasonable control
to do so); and
6.1.3.8
take such other actions as Operator reasonably determines to be appropriate to
operate the Project to the Project Standard.
6.1.4 Provide access to all necessary infrastructure facilities and utilities, including water,
electricity and telecommunication facilities at rates and on terms no less favourable to the
Authorizee than those generally available to commercial customers receiving substantially
equivalent facilities/utilities.
6.1.5

Provide adequate parking (minimum 50% of the available parking area) space within the
Project Site.

6.1.6

The Authority shall be solely responsible for providing all necessary funds/ undertake for
major capital expenditures, renovations, property improvements, and expansions as
identified in a mutually approved Capital Budget/ otherwise.
The Authority shall undertake all Major Maintenance work as required from time to time.
The Authority shall pay within the prescribed time, at all times during the subsistence of
this Agreement, all Taxes including GST, fees, levies, duties, cesses and all other
statutory charges payable in respect of the of the Project Facilities.

6.1.7
6.1.8

6.1.9 Create Project Revenue Accounts as more particularly defined under Clause 16.1.3.
6.1.10 The Authority shall furnish to the Operator all Drawings for the Project Site which includes
but not limited to:
• Architectural Drawings
• Structural Drawings
• HVAC Drawings
• Electrical & Plumbing Drawings
• Firefighter Drawings
• Landscape Drawings
• Miscellaneous Drawings
6.1.11 Subject to and in accordance with the provisions of this Agreement and Applicable Laws,
the Authority agrees to undertakes to observe, comply with and perform the following:
a)

upon written request from the Operator, and subject to the Operator complying with
Applicable Laws, provide reasonable support and assistance to the Operator in
procuring Applicable Permits required from any Government Instrumentality for
implementation and operation of the Project, subject to the Operator submitting its
applications complete in all respect in a timely manner. The Authority agrees and
undertakes that it shall not unreasonably delay or withhold provision of any such
reasonable support or assistance to the Operator;

b)

upon written request from the Operator, provide reasonable assistance to the
Operator in obtaining access to all necessary infrastructure facilities and utilities,
including water and electricity at rates and on terms no less favourable to the
Operator than those generally available to commercial customers receiving
substantially equivalent services;

Request for Proposal - Volume II: Draft Authorization Agreement

Page 36 of 104

<!-- page 37 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

c)

not do or omit to do any act, deed or thing which may in any manner violate the
provisions of this Agreement;

d)

support, cooperate with and facilitate the Operator in the implementation and
operation of the Project in accordance with the provisions of this Agreement;

Notwithstanding anything in this Article, the Authority shall not be required to provide any
financial support or financial assistance to the Operator.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 37 of 104

<!-- page 38 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 7

REPRESENTATIONS,
UNDERTAKINGS

WARRANTIES

7.1

Representations and warranties of the Operator

7.1.1

The Operator represents, warrants and undertakes to the Authority that:

AND

a)

it is duly organised and validly existing under the laws of India, and hereby expressly
and irrevocably waives any immunity in any jurisdiction in respect of this Agreement
or matters arising thereunder including any obligation, liability or responsibility
hereunder;

b)

it has full power and authority to execute and perform its obligations under this
Agreement and to carry out the transactions contemplated hereby;

c)

it has taken all necessary corporate and other actions under Applicable Laws to
authorise the execution and delivery of this Agreement and to validly exercise its
rights and perform its obligations under this Agreement;

d)

it has the financial standing and capacity to undertake the Project in accordance
with the terms of this Agreement;

e)

this Agreement constitutes its legal, valid and binding obligation, enforceable
against it in accordance with the terms hereof, and its obligations under this
Agreement shall be legally valid, binding and enforceable obligations against it in
accordance with the terms hereof;

f)

it is subject to the laws of India, and hereby expressly and irrevocably waives any
immunity in any jurisdiction in respect of this Agreement or matters arising
thereunder including any obligation, liability or responsibility hereunder;

g)

the information furnished in the Bid and as updated on or before the Execution Date
is true and accurate in all respects as on the Execution Date;

h)

the execution, delivery and performance of this Agreement shall not conflict with,
result in the breach of, constitute a default under, or accelerate performance
required by any of the terms of its memorandum and articles of association or any
Applicable Laws or any covenant, contract, agreement, arrangement,
understanding, decree or order to which it is a party or by which it or any of its
properties or assets is bound or affected;

i)

there are no actions, suits, proceedings, or investigations pending or, to its
knowledge, threatened against it at law or in equity before any court or before any
other judicial, quasi-judicial, Government Instrumentality or other authority, the
outcome of which may result in the breach of this Agreement or which individually
or in the aggregate may result in any material impairment of its ability to perform any
of its obligations under this Agreement;

Request for Proposal - Volume II: Draft Authorization Agreement

Page 38 of 104

<!-- page 39 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

j)

it has no knowledge of any violation or default with respect to any order, writ,
injunction or decree of any court or any legally binding order of any Government
Instrumentality which may result in any Material Adverse Effect on its ability to
perform its obligations under this Agreement and no fact or circumstance exists
which may give rise to such proceedings that would adversely affect the
performance of its obligations under this Agreement;

k)

it has complied with Applicable Laws in all material respects and has not been
subject to any fines, penalties, injunctive relief or any other civil or criminal liabilities
which in the aggregate have or may have a Material Adverse Effect on its ability to
perform its obligations under this Agreement;

l)

it shall at no time undertake or permit any Change in ownership;.

m)

all its rights and interests in the Project shall pass to and vest in the Authority on the
Transfer Date free and clear of all liens, claims and Encumbrances, without any
further act or deed on its part or that of the Authority, and that none of the Project
Assets shall be acquired by it, subject to any agreement under which a security
interest or other lien or Encumbrance is retained by any Person, save and except
as expressly provided in this Agreement;

n)

no representation or warranty given by it contained herein or in any other document
furnished by it to the Authority, including the Bid or to any Government
Instrumentality in relation to Applicable Permits contains or shall contain any untrue
or misleading statement of material fact or omits or shall omit to state a material fact
necessary to make such representation or warranty not misleading;

o)

no sums, in cash or kind, have been paid or shall be paid, by it or on its behalf, to
any person by way of fees, commission or otherwise for securing the Authorization
or entering into this Agreement or for influencing or attempting to influence any
officer or employee of the Authority in connection therewith;

p)

all information provided by the {Selected Bidder/ Consortium Member} in response
to the Request for Proposal or otherwise, is to the best of its knowledge and belief,
true and accurate in all material respects;

q)

agree that the execution, delivery and performance by it of this Agreement and all
other agreements, contracts, documents and writings relating to this Agreement
constitute private and commercial acts and not public or government acts;

r)

consents generally in respect of the enforcement of any judgment against it in any
proceedings in any jurisdiction to the giving of any relief or the issue of any process
in connection with such proceedings; and

s)

further representations as may be added depending on the specific circumstances
of the Operator.

7.2

Representations, warranties and Covenants of the Authority

7.2.1

The Authority represents, warrants and covenants to the Operator that

Request for Proposal - Volume II: Draft Authorization Agreement

Page 39 of 104

<!-- page 40 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

a)

it has full power and authority to execute, deliver and perform its obligations under
this Agreement and to carry out the transactions contemplated herein and that it has
taken all actions necessary to execute this Agreement, exercise its rights and
perform its obligations, under this Agreement;

b)

it has taken all necessary actions under Applicable Laws to authorize the execution,
delivery and performance of this Agreement;

c)

it has the financial standing and capacity to perform its obligations under this
Agreement;

d)

this Agreement constitutes a legal, valid and binding obligation enforceable against
it in accordance with the terms hereof;

e)

it has no knowledge of any violation or default with respect to any order, writ,
injunction or any decree of any court or any legally binding order of any Government
Instrumentality which may result in any Material Adverse Effect on the Authority's
ability to perform its obligations under this Agreement; and

f)

it has good, legal and valid right to Project Site and has the power and authority to
handover Project Site to the Operator for the development of the Project in
accordance with the provisions of this Agreement.

7.3

Disclosure

7.3.1

In the event that any occurrence or circumstance comes to the attention of either Party
that renders any of its aforesaid representations or warranties untrue or incorrect, such
Party shall immediately notify the other Party of it. Such notification shall not have the
effect of remedying any breach of the representation or warranty that has been found to
be untrue or incorrect nor shall it adversely affect or waive any right, remedy or obligation
of a Party under this Agreement.

7.3.2

Neither the Authority nor any of its agents or employees shall be liable to the Operator in
contract, tort, including negligence or breach of statutory duty, statute or otherwise as a
result of:
a)

any inaccuracy, omission, unfitness for any purpose of inadequacy of any kind
whatsoever in the data disclosed by the Authority to the Operator in relation to the
Project; and/or

b)

any failure to make available to the Operator any materials, documents, drawings,
plans or other information relating to the Project.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 40 of 104

<!-- page 41 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 8

DISCLAIMER

8.1

Disclaimer

8.1.1

The Operator acknowledges that prior to the execution of this Agreement, the Operator
has, after a complete and careful examination, made an independent evaluation of the
Request for Proposals, Scope of the Project, Specifications and Standards, Project Site,
existing structures, local conditions, physical qualities of ground, subsoil and geology,
availability of Users, market potential and all information provided by the Authority or
obtained procured or gathered otherwise, and has determined to its satisfaction the
accuracy or otherwise thereof and the nature and extent of difficulties, risks and hazards
as are likely to arise or may be faced by it in the course of performance of its obligations
hereunder. The Authority makes no representation whatsoever, express, implicit or
otherwise, regarding the accuracy, adequacy, correctness, reliability or completeness of
any assessment, assumption, statement or information provided by it and the Operator
confirms that it shall have no claim whatsoever against the Authority in this regard.

8.1.2

The Operator acknowledges and hereby accepts the risk of inadequacy, mistake or error
in or relating to any of the matters set forth in Clause 8.1.1 above and hereby
acknowledges and agrees that the Authority shall not be liable for the same in any manner
whatsoever to the Operator, Associates or any person claiming through or under any of
them.

8.1.3

The Parties agree that any mistake or error in or relating to any of the matters set forth in
Clause 8.1.1 above shall not vitiate this Agreement or render it voidable.

8.1.4

In the event that either Party becomes aware of any mistake or error relating to any of the
matters set forth in Clause 8.1.1, that Party shall immediately notify the other Party,
specifying the mistake or error; provided, however, that a failure on part of the Authority
to give any notice pursuant to this Clause 8.1.4 shall not prejudice the disclaimer of the
Authority contained in Clause 8.1.1 and shall not in any manner shift to the Authority any
risks assumed by the Operator pursuant to this Agreement.

8.1.5

Except as otherwise provided in this Agreement, all risks relating to the Project shall be
borne by the Operator and the Authority shall not be liable in any manner for such risks
or the consequences thereof.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 41 of 104

<!-- page 42 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

PART III

OPERATION

Request for Proposal - Volume II: Draft Authorization Agreement

Page 42 of 104

<!-- page 43 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 9

PERFORMANCE SECURITY

9.1

Performance Security

9.1.1

The Operator shall, for the performance of its obligations hereunder during the
Construction Period, provide to the Authority on or before the Appointed Date, the
following irrevocable and unconditional guarantee from a Schedule Commercial
Nationalized Bank for a sum equivalent to Rs. 70,00,000.00 (Rupees Seventy Lacs only)
substantially in the format set forth in Schedule E (the “Performance Security”). The
Operator shall maintain and keep in force the Performance Security for the entire duration
of the Performance Security Period in accordance with this Article 9. Until such time the
Performance Security is provided by the Operator pursuant hereto and the same comes
into effect, the Bid Security shall remain in force and effect, and upon such provision of
the Performance Security pursuant hereto, the Authority shall release the Bid Security to
the Operator

9.1.2

Notwithstanding anything to the contrary contained in this Agreement, in the event that
the Performance Security is not provided by the Operator within the above specified
period, the Authority shall have the right to encash the Bid Security and appropriate the
proceeds thereof as Damages, and thereupon all rights, privileges, claims and
entitlements of the Operator under or arising out of this Agreement shall be deemed to
have been waived by, and to have ceased with the concurrence of the Operator, and this
Agreement shall be deemed to have been terminated by mutual agreement of the Parties.

9.2

Appropriation of Performance Security

9.2.1

Upon occurrence of an Operator Default or failure to meet any Condition Precedent or
failure to make any payment which becomes due and payable to the Authority under and
in accordance with this Agreement, the Authority shall, without prejudice to its other rights
and remedies hereunder or in law, be entitled to encash and appropriate the amounts due
and payable as liquidated damages from the Performance Security as Damages for such
Operator Default or failure to meet any Condition Precedent or failure to pay such amounts
which are due and payable by the Operator to the Authority under and in accordance with
the provisions of this Agreement. Upon such encashment and appropriation of the
Performance Security, the Operator shall, within 15 (fifteen) days thereof, replenish, in
case of partial appropriation, the Performance Security to its original level, and in case of
appropriation of the entire Performance Security provide a fresh Performance Security,
as the case may be, failing which the Authority shall be entitled to terminate this
Agreement in accordance with Article 18Error! Reference source not found. Upon such
replenishment or furnishing of a fresh Performance Security, as the case may be, the
Operator shall be entitled to an additional Cure Period of 60 (Sixty) days for remedying
the Operator Default or for satisfying any Condition Precedent, and in the event of the
Operator not curing its default or meeting such Condition Precedent within such Cure

Request for Proposal - Volume II: Draft Authorization Agreement

Page 43 of 104

<!-- page 44 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Period, the Authority shall be entitled to encash and appropriate such Performance
Security as Damages, and to terminate this Agreement in in accordance with Article 18.

9.3

Release of Performance Security

9.3.1

The Performance Security shall remain in force and effect for a period of 6 (six) months
from the Transfer of the Project (the “Performance Security Period”); provided, however,
that the Performance Security shall not be released if the Operator is in breach of this
Agreement. Upon request made by the Operator for release of the Performance Security
along with the particulars which establish satisfaction of the requirements specified in this
Clause 9.3, the Authority shall release the Performance Security forthwith.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 44 of 104

<!-- page 45 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 10 PROJECT FACILITY
10.1

The Project Facility

10.1.1

Rights, Title and Use of the Project Site and Project Facility

a) The Authorizee shall have the right to the use of Project Site & Project Facility in
accordance with the provisions of this Agreement and for this purpose it may regulate the
entry and use of the same by third parties.
b) The Project Site including the Project Facility developed thereon belongs to the Authority
and shall continue to be the property of the Authority.
c) The Authorizee shall not part with or create any Encumbrance on the whole or any part of
the Project Site, save and except as set forth and permitted under this Agreement.
d) The Authorizee shall not without the prior written approval of the Authority use the Project
Facility for any purpose other than for the purpose of the Project and purposes incidental
or ancillary thereto.
e) The Authorizee shall allow access to and use of the Project Site for laying/ installing/
maintaining telegraph lines, electric lines or for such other public purposes as the Authority
may specify. Provided that such access or use shall not result in a Material Adverse Effect
and that the Authority shall, in the event of any physical damage to the Project Site/
Project Facility/ on account thereof, ensure that the Project Site/ Project Facility is
promptly restored at its cost and expenses.
f) Provided further, that to the extent such access and use allowed by the Authorizee affects
the performance of any of its obligations hereunder, the Authorizee shall not be deemed
or construed to be in breach of its obligations nor shall it incur/ suffer any liability on
account thereof.
g) The Authorizee shall not demolish the existing structures within the Project Site.

10.1.2

Peaceful Possession

The Authority, as Licensing Authority, hereby warrants that:
a) The Project facility together with the necessary right of way/ way-leaves:
i.
has been acquired through the due process of law
ii.
belongs to and is vested in the Authority and that the Authority has full powers to
hold, dispose of and deal with the same consistent, inter alia, with the
provisions of this Agreement and that the Authorizee shall, in respect of the
Project Site, have no liability regarding any compensation payment on account of
rehabilitation/ resettlement or land acquisition of any Persons affected thereby.
b) The Authorizee shall, subject to complying with the terms and conditions of this
Agreement, remain in peaceful possession and enjoyment of the Project Site or part
thereof until expiry of the Authorization Period. In the event, the Authorizee is obstructed
by any Person claiming any right, title or interest in or over the Project Site or any part
thereof or in the event of any enforcement action including any attachment, distraint,
appointment of receiver or liquidator being initiated by any Person claiming to have any
Request for Proposal - Volume II: Draft Authorization Agreement

Page 45 of 104

<!-- page 46 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

interest in/charge on the Project Site or any part thereof, the Authority shall, if
called upon by the Authorizee, defend such claims and proceedings and also keep
the Authorizee indemnified against any consequential loss or damages which the
Authorizee may suffer, on account of any such right, title, interest or charge.
10.1.3

Applicable Permits
The Authorizee shall obtain and maintain all Applicable Permits in such sequence as is
consistent with the requirements of the Project.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 46 of 104

<!-- page 47 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 11 ENTRY INTO COMMERCIAL SERVICE
11.1

Commercial Operation Date

11.1.1 The Appointed Date shall be the date of start of Commercial Operation and thereupon
the Operator shall be entitled to put such Project Facility on commercial operations
(“Project COD”), provided however, that the entry of any Project Facility into commercial
service shall always be subject to compliance in accordance with the provisions of this
Agreement and subject to Applicable Laws, Applicable Permits and Good Industry
Practice.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 47 of 104

<!-- page 48 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 12 OPERATION AND MAINTENANCE
12.1 O&M Obligations of the Operator
12.1.1 The Operator shall submit a detailed operational plan for Operation, Maintenance and
Management of the Project Facility to the Authority for approval and carry out the
operation as per the approved Operational Plan (Schedule B). (the ”Approved Operational
Plan”).
12.1.2 The operation plan so prepared by the Operator shall be in line with 3-star category Hotel
requirements as detailed out in Annexure III of the revised guideline for approval of hotels
and star classification/ re-classification of Ministry of Tourism (H&R Division), Government
of India, dated 19.02.2018 or as revised from time to time.
12.1.3 During the Operation Period, the Operator shall operate and maintain the Project and the
Project Infrastructure in accordance with this Agreement and if required, modify, repair or
otherwise make improvements to the Project Assets and the Project Infrastructure to
comply with the provisions of this Agreement, Applicable Laws and Applicable Permits,
and conform to Specifications and Standards and Good Industry Practice. The obligations
of the Operator hereunder shall include:
a)

ensuring safe, hygienic and efficient Hospitality cum Tourism Services and
maintaining a high standard of cleanliness and hygiene in the Project Facilities;

b)

undertaking operation and maintenance of the Project Facilities in an efficient,
coordinated and economical manner, in compliance with the Specification and
Standards;

c)

undertaking operation and maintenance of the Project Infrastructure in
accordance with the Specification and Standards, operation and maintenance
manual provided by the original equipment manufacturers and the terms of this
Agreement to ensure that the Operator is able to optimally use the Project
Infrastructure during the Operation Period such that the Project is selfsustained;

d)

carrying out preventive maintenance of the Project Facilities and Project
Infrastructure;

e)

undertaking routine maintenance including prompt repairs of all elements and
components of the Project Facilities and Project Infrastructure so as to ensure
compliance with the Maintenance Requirements and the Specification and
Standards;

f)

providing round the clock security at the Project Site and preventing with the
assistance of the concerned law enforcement agencies, any encroachments
on or authorised entry on the Project Site;

Request for Proposal - Volume II: Draft Authorization Agreement

Page 48 of 104

<!-- page 49 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

g)

protection of environment and provision of equipment and materials therefor
in accordance with the Applicable Laws, Applicable Permits, terms of this
Agreement and Good Industry Practice;

h)

operation and maintenance of all communication, control and administrative
systems necessary for the efficient operation of the Project Facilities and
Project Infrastructure and for providing Hospitality cum Tourism Services in
conformity with the Good Industry Practice;

i)

maintaining a public relations unit to interface with and attend to suggestions
from the Users, Government Instrumentality, media and other agencies;

j)

complying with the Safety Requirements; and

k)

operation and maintenance of all Project Assets diligently and efficiently and
in accordance with Applicable Laws, Applicable Permits, Good Industry
Practice and provisions of this Agreement;

l)

responsible for the acts or defaults of any of its contractors, its agents or
employees, as if they were the acts or defaults of the Operator.

12.1.4 The cope of Operator under Operation, Maintenance and management excludes Major
maintenance like replacement of components and parts, repairs to structures, and repairs
and development of associated facilities, including the Project Infrastructure;
12.1.5 If the Operator fails to comply (for any activity undertaken by him after taking over the
Project facility, however the Operator shall not be liable for past liability arising out of the
default on the part of the Authority) with any directions issued by the Authority or any
Government Instrumentality acting under any Applicable Laws, as the case may be, and
is liable to pay a penalty under the provisions of Applicable Laws, such penalty shall be
borne solely by the Operator, and shall not be claimed from the Authority. For avoidance
of doubt, payment of any penalty under the provisions of Applicable Laws shall be in
addition to and independent of the Damages payable under this Agreement. In the event
the Authority is required to pay any penalty to the Government Instrumentality under any
Applicable Laws then the Authority shall be entitled to be indemnified by the Operator
under Article 19.

12.2 Maintenance Requirements
12.2.1 The Operator shall procure that at all times during the Operation Period, the Project
Facilities and the Project Infrastructure are maintained in accordance with the provisions
of this Agreement, Applicable Laws, Applicable Permits and Good Industry Practice
(Schedule F).

12.3 Safety, breakdowns and accidents
12.3.1 The Operator shall ensure safe conditions at the Project Site for the Users and the
Authority, and in the event of unsafe conditions, damage, breakdowns and accidents, it
shall follow the relevant operating procedures in conformity with the provisions of this
Request for Proposal - Volume II: Draft Authorization Agreement

Page 49 of 104

<!-- page 50 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Agreement, Applicable Laws, Applicable Permits and Good Industry Practice. In the event
of occurrence of any damage, breakdowns and/or accidents, the Operator shall undertake
removal of obstruction and debris without delay.
12.3.2 Operator's responsibility for rescue operations in the Project Facilities and Project
Infrastructure shall include safe evacuation of all Users, visitors and staff from the affected
area as an initial response to any particular incident requiring evacuation and shall also
include prompt and safe removal of dangerous spills, leakages, debris or any other
obstruction, which may endanger or interrupt the Hospitality and tourism services.

12.4 Overriding powers of the Authority
12.4.1 If in the opinion of the Authority, the Operator is in material breach of its obligations under
this Agreement and in particular, the Maintenance Requirements, and such breach is
causing or is likely to cause material hardship or danger to any person or property, the
Authority may, without prejudice to any of its rights under this Agreement including
Termination thereof, by notice require the Operator to take reasonable measures
immediately for removing such hardship or danger as the case may be.
12.4.2 In the event the Operator, upon notice under Article Error! Reference source not found.,
fails to rectify or remove any hardship or danger within a reasonable period, the Authority
may take over the performance of any or all the obligations of the Operator to the extent
deemed necessary by it for removing such hardship or danger; provided that the exercise
of such overriding powers by the Authority shall be of no greater scope and of no longer
duration than is reasonably required in the circumstances which caused the exercise of
such overriding power by the Authority; provided further that any costs and expenses
incurred by the Authority in discharge of its obligations hereunder shall be deemed to be
O&M Expenses, and the Authority shall be entitled to recover them from the Operator in
accordance with the provisions of Article 12 along with the Damages specified therein.

12.5 Excuse from performance of obligations
12.5.1 The Operator shall not be considered in breach of its obligations under this Agreement if
any part of the Project Facilities are not available to Users, or the Project Infrastructure is
not available for the use of the Project Facilities on account of any of the following for the
duration thereof:
(a)

a Force Majeure Event;

(b)

measures taken to ensure the safe use of the Project Facilities and Project
Infrastructure, except when unsafe conditions occurred because of failure of the
Operator to perform its obligations under this Agreement; or

(c)

compliance with a request from the Authority or the directions of any Government
Instrumentality, the effect of which is to close all or any part of the Project
Facilities or Project Infrastructure.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 50 of 104

<!-- page 51 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Provided, that any such event and particulars thereof shall be notified by the Operator to
the Authority without any delay.
Notwithstanding the above, the Operator shall keep all unaffected parts of the Project
Facilities open to Users provided that Hospitality cum Tourism Services can be provided
safely.

12.6 Authority's right to take remedial measures
12.6.1 In the event the Operator does not maintain, repair and/or rectify any defects and
deficiencies in the Project Facility or any part thereof in conformity with the Maintenance
Requirements and fails to commence remedial works within [15 (fifteen)] days of receipt
of the O&M Inspection Report or notice in this behalf from the Authority, the Authority,
without prejudice to its rights under this Agreement including Termination thereof, be
entitled to undertake such remedial measures at the risk and cost of the Operator, and to
recover its cost from Operator. In addition to recovery of the aforesaid cost, a sum equal
to [20% (twenty per cent)] of such cost shall be paid by the Operator to the Authority as
Damages. For avoidance of doubt, the rights of the Authority under this Clause Error!
Reference source not found. shall be without prejudice to its rights and remedies under
Clause Error! Reference source not found..

Request for Proposal - Volume II: Draft Authorization Agreement

Page 51 of 104

<!-- page 52 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 13 MONITORING
MAINTENANCE

OF

OPERATION

AND

13.1 Monthly Status Reports
13.1.1 During Operation Period or any time after Project COD, the Operator shall, no later than
7 (seven) days after the close of every Accounting Year, furnish to the Authority an annual
report, in a mutually agreed format, stating in reasonable detail the condition of the Project
Facilities and Project Infrastructure, including its compliance or otherwise with the
Maintenance Requirements and the Safety Requirements, and shall promptly give such
other relevant information as may be required by the Authority. In particular, such report
shall separately identify and state in reasonable detail the defects and deficiencies that
require rectification.

13.2 Inspection
13.2.1 The Authority shall inspect the Project Facilities and the Project Infrastructure at regular
interval (least once a month). It shall make a report of such inspection at the Project Site
(the “O&M Inspection Report”) stating in reasonable detail the defects or deficiencies, if
any, with particular reference to the Maintenance Requirements and Safety Requirements
and send a copy thereof to the Authority and the Operator within 7 (seven) days of such
inspection.

13.3 Tests
13.3.1 If required and deemed fit by the Authority, for determining that the Project Facilities and
the Project Infrastructure conforms to the Maintenance Requirements, the Authority shall
require the Operator to carry out, or cause to be carried out, tests specified by it in
accordance with Good Industry Practice. The Operator shall, with due diligence, carry out
or cause to be carried out all such tests in accordance with the instructions of the Authority
and furnish the results of such tests forthwith to the Authority.

13.4 Remedial measures
13.4.1 The Operator shall repair or rectify the defects or deficiencies, if any, set forth in the O&M
Inspection Report or in the test results referred to in Clause 13.3 and furnish a report in
respect thereof to the Authority within 15 (fifteen) days of receiving the O&M Inspection
Report; provided that where the remedying of such defects or deficiencies is likely to take
more than 15 (fifteen) days, the Operator shall submit progress reports of the repair works
once every week until such works are completed in conformity with this Agreement.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 52 of 104

<!-- page 53 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 14 HOSPITALITY CUM TOURISM SERVICES
14.1 Quality of Services
14.1.1 The Operator shall procure that all Users in the Project Facilities receive quality services
in accordance with the provisions of this Agreement and Good Industry Practices.
14.1.2 The Operator shall procure and ensure that all personnel engaged in the provision of
Hospitality cum Tourism Services including lifeguards, are suitably qualified and receive
sufficient training and instructions in accordance with Good Industry Practice and
standards of their relevant professional body, if any, for execution of their duties, which
shall at a minimum, be compliant with the performance standards set out at Schedule C.
The Operator shall regularly supervise and monitor the performance of the personnel to
ensure that they comply with this Agreement, Applicable Laws and Good Industry
Practice.
14.1.3 The Operator shall address to any complaints received by the Users in a prompt and
effective manner and take all reasonable efforts to accommodate the requests of the
Users.

14.2 Hotel Management System
14.2.1 All bookings and invoicing for the Project shall be undertaken through a dedicated Hotel
Management System (HMS System) implemented by the Authority. However, the
Operator shall have the right to finalize the pricing of hotel, right to grant discounted or
complimentary rooms, food, beverage or other services when he/she reasonably deems
the same to be in the best business interests of the Project. The Authority shall also share
the data in terms of the Bookings undertaken, payment collected from the Users under
Core Services and Associated Services. All rights of managing HMS system shall be
provided by the Authority to the Operator.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 53 of 104

<!-- page 54 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 15 : CHANGE OF SCOPE
15.1 Change of Scope
15.1.1 The Authority may, notwithstanding anything to the contrary contained in this Agreement,
require the provision of additional works and services which are not included in the Scope
of the Project as contemplated by this Agreement (the “Change of Scope”). Provided that,
the Authority shall be entitled to require the Authorizee to undertake any Change of Scope
only during the Construction Period. Any such Change of Scope shall be made in
accordance with the provisions of this Article 15 and the costs thereof shall be expended
by the Authorizee and reimbursed to it by the Authority in accordance with Clause 15.3.
15.1.2 Any works or services which are provided under and in accordance with this Article 15shall
form part of the Project Facilities and Project Infrastructure and the provisions of this
Agreement shall apply mutatis mutandis to such works or services.

15.2 Procedure for Change of Scope
15.2.1 In the event of the Authority determining that a Change of Scope is necessary, it shall
issue to the Authorizee a notice specifying in reasonable detail the works and services
contemplated thereunder (the “Change of Scope Notice”).
15.2.2 Upon receipt of a Change of Scope Notice, the Authorizee shall, with due diligence,
provide to the Authority such information as is necessary, together with preliminary
Documents in support of:
a)

the impact, if any, which the Change of Scope is likely to have on the Project
Completion Schedule if the works or services are required to be carried out during
the Construction Period;

b)

the options for implementing the proposed Change of Scope and the effect, if any,
each such option would have on the costs and time thereof, including a detailed
breakdown by work classifications specifying the material and labour costs
calculated in accordance with the schedule of rates applicable to the works assigned
by the Authority to its contractors, any impact on the operations or the cost of
operation of the Project Facilities and Project Infrastructure, along with the proposed
premium or discount on such rates; provided that the cost incurred by the Authorizee
in providing such information shall be reimbursed by the Authority as reasonable;
and

c)

its likely impact on the Gross Revenue and profitability of the Project.

15.2.3 Upon receipt of information set forth in Clause 15.2.2, if the Authority decides to proceed
with the Change of Scope, it shall convey its preferred option to the Authorizee, and the
Parties shall, make good faith efforts to agree upon the time and costs for implementation
thereof. Upon reaching an agreement, the Authority shall issue an order (the “Change of
Scope Order”) requiring the Authorizee to proceed with the performance thereof. In the
event that the Parties are unable to agree, the Authority may, by issuing a Change of

Request for Proposal - Volume II: Draft Authorization Agreement

Page 54 of 104

<!-- page 55 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Scope Order, require the Authorizee to proceed with the performance thereof pending
resolution of the Dispute.
15.2.4 The provisions of this Agreement, insofar as they relate to Development Works and Tests,
shall apply mutatis mutandis to the works undertaken by the Authorizee under this Article
15.

15.3 Payment for Change of Scope
15.3.1 Within 7 (seven) days of issuing a Change of Scope Order, the Authority shall make an
advance payment to the Authorizee of a sum equal to 20% (twenty per cent) of the cost
of Change of Scope as agreed hereunder, and in the event of a Dispute, 20% (twenty per
cent) of the cost. The Authorizee shall, after commencement of work, present to the
Authority bills for payment in respect of the works in progress or completed works, as the
case may be, supported by such Documents as is reasonably sufficient for the Authority
to determine the accuracy thereof. Within 30 (thirty) days of receipt of such bills, the
Authority shall disburse to the Authorizee such amounts as are certified by the Authority,
as reasonable and after making a proportionate deduction for the advance payment made
hereunder, and in the event of any Dispute, final adjustments thereto shall be made under
and in accordance with the Dispute Resolution Procedure in Article 22.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 55 of 104

<!-- page 56 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 16 TARIFF AND FEE
16.1 Tariff Structure
16.1.1 The Operator may determine the tariff structure for different categories of rooms and other
services in such manner as it deems fit; provided however, that such tariffs shall not be
combined with any facility or service that is not directly connected with the Hotel.
16.1.2 The Operator may, for occupancy of Keys in the Project by Users, levy and recover such
tariffs as it may determine from time to time and shall also be entitled to charge market
related rates for other services and allied infrastructure such as retail outlets, telephone,
telefax, laundry, food, beverages, liquor, recreation amenities (pool, health club, spa,
sauna, fitness facility, outdoor catering, vending machines, Wi-Fi services and any other
relevant service (the “Associated Activities”). The Operator may also recover rent or fee
for use of commercial or other spaces of every description and kind, provided by the
Operator.
16.1.3 All revenue shall go directly to the Authority designated project specific accounts. Towards
the same, the Authority shall create 2 project specific accounts (Project Revenue
Accounts) to:
i.

Account 1 (Revenue from Core Activities): For Revenue generated from Core
activities like room rent and space rent out for MICE & other activities.
ii.
Account 2 (Revenue from Associated Activities): Directly receiving and
managing all revenue arising out of food & beverages, bar, spa services, laundry
Services to the guests and other incidental services. The Authority shall provide the
necessary infrastructure and access to the Operator for efficient revenue collection
processes that feed directly into the Authority's system.
16.1.4 To the extent possible, the Operator shall not promote cash transaction. The Operator
shall endeavour to keep the cash transaction to below 5% of the total revenue.
16.1.5 Any cash received by the Operator shall be deposited in the Authority designated project
specific account by the next working day of the receipt of such amount with due
information to the Authority about the same and also to keep a record of the same.

16.2

Payment of Management Fee by the Authority

16.2.1 In consideration of the Operation, Maintenance and Management of the Project Facility in
terms of this Agreement, the Authority shall pay to the Operator the following:
a)

Management Fee shall consist of the following:
(i) Fee for Revenue from Core Activities: the Authority shall pay the Operator a
Management fee equivalent to percentage of Gross Revenue earned by the
Authority from the Core Activities (….% of gross revenue) as quoted by the
Successful Bidder in its Bid (Schedule C).

Request for Proposal - Volume II: Draft Authorization Agreement

Page 56 of 104

<!-- page 57 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

(ii) Fee for Revenue from Associated Activities: the Authority shall pay the
Operator 80% of the gross revenue (including revenue in cash generated and
deposited from Associated Activities) generated from Associated Activities.
b)

Along with the Fee as mentioned above, the Authority shall also pay the GST at
applicable rates to the Operator.

c)

The Authority shall pay the above-mentioned fee within 15 days of issuance of invoice
by the Operator.

For illustration: If the total revenue earned by the Authority is 2 crores from the
Core Services and 1 crore from the Associated Activities, and if the Operator quote
is 50% of gross revenue from the Core Activities then, the Operator is eligible for
Management Fee as per the following:
1.
2.

Management Fee against Core Activities: 50%*2 crores = INR 1 crores; and
80% Fee from the Associated Activities: 80%*1 crore = INR 0.80 crore.

Total Management Fee payable to the Operator = INR 1.8 crores plus GST at
applicable rate. However, actual payment of this shall be done on the monthly
basis.
d) Provided that In case the net revenue earned by the Authority (revenue left after
paying the Management fee) from the Project is less than INR 1.41 crore for the
first Financial year (Minimum Guarantee Revenue) of Operation (to be
calculated on the pro-rata basis), the Bidder/ Operator shall pay such deficit
amount to make the net revenue of the Authority to INR 1.41 crores for the first
Financial year of Operation (to be calculated on the pro-rata basis). The amount
of Minimum Guarantee Revenue shall be increased by 10% every 3 years.

16.3 Interest on Delayed Payments
16.3.1 All amounts due and payable by the Authority under the provisions of this Agreement shall
be paid on or before the time period stipulated in Clause 16.2.1 (d). In the event of delay
beyond such period the Authority shall pay interest for the period of delay, calculated at
the rate specified in the Clause 26.3 of this Agreement.

16.4 Disputed Amounts
16.4.1 The Operator shall, within 10 (ten) days of receiving the Fee (both for Core Services and
Associated Services), notify the Authority of the disputed amounts along with details
thereof (the “Disputed Amounts”) if any. Within 15 (fifteen) days of receiving such notice,
the Authority shall present any information or evidence as may be reasonably required for
determining that such Disputed Amounts are payable/ not payable. The Authority may, if
necessary, meet a representative of the Operator for resolving the dispute and in the event
that the dispute is not resolved the Dispute Resolution Procedure in accordance with the
Article 22 shall apply.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 57 of 104

<!-- page 58 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

16.4.2 If any amount is payable by either Party upon determination of a dispute regarding any
Disputed Amount, such amount shall be deemed to be payable on the date when it first
became due and interest for the period of delay shall be due and payable at the rate
specified in Clause 26.3.

16.5 Keys Reserved for the Authority
16.5.1 The Operator shall made available 2 suite rooms, free of cost (including breakfast for 2
persons per guest rooms) as & when requisition in respect thereof is received by the
Operator from the Authority. Such request shall be made by the Authority at least 2 days
in advance.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 58 of 104

<!-- page 59 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 17 : FORCE MAJEURE
17.1 Force Majeure
As used in this Agreement, the expression “Force Majeure” or “Force Majeure Event”
shall mean occurrence in India of any or all of Non-Political Event, Indirect Political
Event and Political Event, as defined in sub-clauses 17.1, 17.2 and 17.3 respectively,
if it affects the performance by the Party claiming the benefit of Force Majeure (the
“Affected Party”) of its obligations under this Agreement and which act or event (i) is
beyond the reasonable control of the Affected Party, and (ii) the Affected Party could
not have prevented or overcome by exercise of due diligence and following Good
Industry Practice, and (iii) has Material Adverse Effect on the Affected Party.

17.2 Non-Political Event
A Non-Political Event shall mean one or more of the following acts or events:
a. strikes or boycotts (other than those involving the Authorizee, Contractors or
their respective employees/representatives, or attributable to any act or
omission of any of them) interrupting supplies and services and/or the
upgradation, operation and maintenance of the Project Facility for a
continuous period of 24 (twenty four) hours and an aggregate period,
exceeding 30 (thirty) days in a financial year, and not being an Indirect Political
Event set forth in Clause 17.3;
b. any judgement or order of any court of competent jurisdiction or statutory
authority made against the Authorizee in any proceedings for reasons other
than (i) failure of the Authorizee to comply with any Applicable Law or
Applicable Permit, or (ii) on account of breach of any Applicable Law or
Applicable Permit or of any contract, or (iii) enforcement of this
Agreement, or (iv) exercise of any of its rights under this Agreement by the
GoJ;

17.3 Indirect Political Event
An Indirect Political Event shall mean an act of war (whether declared or undeclared),
invasion, armed conflict or act of foreign enemy, blockade, embargo, riot, insurrection,
terrorist or military action, civil commotion or politically motivated sabotage which
prevents operation of the Project facility by the Authorizee for period exceeding a
continuous period of 30 (thirty) days in a financial year.

17.4 Political Event
A Political Event shall mean one or more of the following acts or events by GoJ or GoI:

Request for Proposal - Volume II: Draft Authorization Agreement

Page 59 of 104

<!-- page 60 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

a. compulsory acquisition in national interest or expropriation of the Project Site
Assets, if any created by the Authorizee under the Project or rights of the
Authorizee;
b. unlawful or unauthorised or without jurisdiction revocation of, or refusal to renew
or grant without valid cause, any clearance, license, permit, no
objection certificate, consent, approval or exemption required by the
Authorizee to perform their respective obligations under this Authorization
Agreement; provided that such delay, modification, denial, refusal or revocation
did not result from the Authorizee’s inability or failure to comply with any
condition relating to grant, maintenance or renewal of such clearance, license,
no objection certificate, exemption, consent, approval or permit; or
c. any event or circumstance of a nature analogous to any of the foregoing.

17.5 Duty to report Force Majeure Event
17.5.1 Upon occurrence of a Force Majeure Event, the Affected Party shall by notice report such
occurrence to the other Party forthwith. Any notice pursuant hereto shall include full
particulars of:
a. the nature and extent of each Force Majeure Event with evidence in support
thereof;
b. the estimated duration and the effect or probable effect which such Force
Majeure Event is having or will have on the Affected Party’s performance of its
obligations under this Agreement;
c. the measures which the Affected Party is taking or proposes to take for
alleviating the impact of such Force Majeure Event; and
d. any other information relevant to the Affected Party’s claim.
17.5.2 The Affected Party shall not be entitled to any relief for or in respect of a Force
Majeure Event unless it shall have notified the other Party of the occurrence of the
Force Majeure Event as soon as reasonably practicable, and in any event not later than
7 (Seven) days after the Affected Party knew, or ought reasonably to have known,
of its occurrence, and shall have given particulars of the probable material effect
that the Force Majeure Event is likely to have on the performance of its obligations under
this Agreement.

17.6 Effect of Force Majeure Event on the Authorization
17.6.1 The Authorizee shall be eligible for extensions as provided hereunder only on the
occurrence of Force Majeure Events, with respect to the Project.
a. at any time after the Appointed Date, if any Force Majeure Event occurs:
I.
before COD, the Authorization Period shall be extended by a period
equal in length to the duration for which such Force Majeure Event
subsists; or

Request for Proposal - Volume II: Draft Authorization Agreement

Page 60 of 104

<!-- page 61 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

II.

after COD, whereupon the Authorizee is unable to operate and maintain
the Project Facility in terms of the Authorization Agreement despite
making best efforts, the Authorization Period shall be extended by a
period, equal in length to the period during which the Authorizee was
unable to perform its obligation under the Agreement.
17.7 Save and except as expressly provided in this Article 17, neither Party shall be liable in
any manner whatsoever to the other Party in respect of any loss, damage, cost,
expense, claims, demands and proceedings relating to or arising out of occurrence or
existence of any Force Majeure Event or exercise of any right pursuant hereto.

17.8 Notwithstanding anything contained in this Article 17, in case Force Majeure Event
subsists for a continuous period of thirty days , Authority shall be entitled to terminate this
Agreement in which case the Authority shall pay to the Authorizee the pro-rata
Management Fee (fee from Core Activities and Associated Activities) and payable in
terms hereof until date of such termination.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 61 of 104

<!-- page 62 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 18 : EVENTS OF DEFAULT
18.1 The Authority Event of Default
a.

Each of the following events or circumstances, to the extent not caused by a
default of the Authorizee or Force Majeure, shall be considered for the purposes
of this Authorization Agreement as events of default of the Authority (“the
Authority Event of Default”) which, if not cured within the time period permitted, if
any, shall provide the Authorizee with the right to terminate this Authorization
Agreement in accordance with Article 18 hereof:
I.

II.

a Material
Breach by
the Authority of its obligations under
this Authorization Agreement which is not remedied within 90 days from
the date [or such later date as parties may mutually agree,) of receipt of
written notice from the Authorizee specifying such breach and requiring
the Authority to remedy the same;
a breach of any express representation or warranty by the Authority which
has a Material Adverse Effect and such breach is not remedied within 90
(Ninety) days from the date (or such later date as parties may mutually
agree) of receipt of written notice from the Authorizee specifying such
breach and requiring the GoJ to remedy the same.

18.2 Authorizee Event of Default
a. Each of the following events or circumstances, to the extent not caused by a
default of the Authority or Force Majeure, shall be considered for the purposes
of this Authorization Agreement as Events of Default of the Authorizee
(“Authorizee Event of Default”) which, if not cured within 15 days of notice
as issued by the Authority, if any, shall provide the GoJ, with the right to
terminate this Authorization Agreement in accordance with Article 18 hereof:
I.
Material Breach of its obligations under the Authorization Agreement
which has a Materially Adversely Effect on the Authority or the Project
and such breach is not remedied within 15 days of notice as issued by
the Authority of specifying such breach and requiring the Authorizee to
remedy the same;
II.
The Performance Security has been encashed and appropriated in
accordance with Clause 9.2 and the Authorizee fails to replenish or
provide fresh Performance Security within a Cure Period of 15 (fifteen)
days;
III.
subsequent to the replenishment or furnishing of fresh Performance
Security in accordance with Clause 9.2, or cure the Authorizee Event of
Default, as the case may be, for which whole or part of the Performance
Security was appropriated, within a Cure Period of 60 (Sixty) days;
IV.
For each default of Approved Operation Plan, the Authority shall deduct
2% of the Performance Security, subject to a maximum of 6% in a quarter.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 62 of 104

<!-- page 63 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

V.

VI.
VII.

VIII.

IX.

X.

XI.

XII.
XIII.

XIV.

XV.

XVI.

Continuous failure to adherence to the Approved Operation Plan. In case,
the failure of Authorizee to adhere to Approved Operation Plan resulted
in deduction of Management Fee by more than 6% in a quarter for more
than 2 quarter in a year, such failure shall be treated as Authorizee Events
of Default.
subject to the provisions of this Authorization Agreement failure to take
possession or achieve Project COD on or before the Appointed Date;
a breach of any express representation or warranty by the Authorizee
which has a Material Adverse Effect and such breach is not remedied
within 15 days of notice as issued by the Authority from the Authority
specifying such breach and requiring the Authorizee to remedy the same;
any actions or omissions attributable to Authorizee, including delay
on the part of the Authorizee to discharge any of its obligations, that
has a Material Adverse Effect on the implementation of the Project;
dissolution of the Authorizee pursuant to Applicable Law, except for the
purpose of a merger, consolidation or reorganization that does not affect
the ability of the resulting entity to perform all the obligations
of the Authorizee under this Authorization Agreement and provided
further that such resulting entity expressly assumes all such obligations;
declaration of insolvency or the appointment of a liquidator in a
proceeding for dissolution of the Authorizee after lawful notification and
due hearing, which declaration or appointment has not been set aside
within 60 (Sixty) days thereof;
failure of the Authorizee to procure requisite Approval with respect to any
change in the functioning, management and operation process of the
Project Facility;
Abandonment of the Project by the Authorizee;
if there is a change in the rights of ownership of the Authorizee or in the
powers of any trustee/member of the governing body to direct
the management or the policies of the Authorizee where such change
would be reasonably likely to have a Material Adverse Effect on the ability
of the Authorizee to comply in all material respects with its obligation
under this Authorization Agreement;
Authorizee creates or permits to subsist any Encumbrance, or otherwise
transfers or disposes of all or any of its rights and benefits under this
Agreement or any Project Agreement to which the Authorizee is a party.
If the Authorizee sub-Authorizations, encumbers, sells/transfer any part
or whole of the Project Site/Project Facility to any person in any form or
under any arrangement, device or method
Such other events which have been specifically set out in terms hereof
as Authorizee Event of Default.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 63 of 104

<!-- page 64 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

18.3 Termination due to Event of Default
a. Termination for Authorizee Event of Default
I. Without prejudice to any other right or remedy which the Authority may have
in respect thereof under this Agreement, upon the occurrence of a
Authorizee Event of Default, the Authority may immediately terminate this
Agreement by issue of Termination Notice in the manner set out under
Clause 18.3(d).
II. If the Authority decides to terminate this Agreement pursuant to Clause
18.3 a (I), it shall in the first instance issue Notice of intention to terminate
to the Authorizee. Within 30 days of receipt of the Notice of intention to
terminate, the Authorizee shall submit to the Authority in sufficient detail,
the manner in which it proposes to cure the underlying Event of Default (the
“Authorizee's Proposal to Rectify”). In case of non-submission of the
Authorizee's Proposal to Rectify within the said period of 15 days, the
Authority shall be entitled to terminate this Agreement by issuing
Termination Notice.
III. If the Authorizee's Proposal to Rectify is submitted within the period
stipulated therefor, the Authorizee shall have further period of 15 days
(“Cure Period”) to remedy/ cure the underlying Event of Default. If, however
the Authorizee fails to remedy/ cure the underlying Event of Default within
such further period allowed, the Authority shall be entitled to terminate this
Agreement, by issue of Termination Notice.
b. Termination for the Authority Event of Default
I. Without prejudice to any other right or remedy which the
Authorizee may have in respect thereof under this Agreement, upon the
occurrence of the Authority Event of Default, the Authorizee shall be
entitled to terminate this Agreement by issuing Termination Notice.
II. If the Authorizee decides to terminate this Agreement pursuant to Clause
18.3 b (I), it shall in the first instance issue Notice of intention to terminate
to the Authority. Within 30 days of receipt of Notice of intention to
terminate, the Authority shall forward to the Authorizee its proposal
to remedy/ cure the underlying Event of Default (the "the Authority’s
Proposal to Rectify”). In case of non submission of the Authority’s
Proposal to Rectify within the period stipulated therefor, Authorizee
shall be entitled to terminate this Agreement by issuing Termination
Notice.
III. If the Authority’s Proposal to Rectify is forwarded to the Authorizee within
the period stipulated therefor, the Authority shall have further period of 30
days to remedy/ cure the underlying Event of Default. If, however the
Authority fails to remedy/ cure the underlying Event of Default within such
further period allowed, the Authorizee shall be entitled to terminate this
Agreement by issuing Termination Notice.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 64 of 104

<!-- page 65 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

c. Completion of 10 years from the Appointed Date
Before the completion of 5 years from the Appointed Date, the Authority shall
review the performance of the Authorizee. If the Authority is of a view that
the performance of the Authorizee is in compliance with the terms of the
Agreement, the Authority may in its sole discretion, subject always to the
Authorizee not being in any material default of its obligations hereunder, consider
granting another Authorization term of 5 years to the Authorizee on such terms as
Authority would then deem appropriate.
In the event Authority does not decide to grant another Authorization term to the
Authorizee, then upon expiry of the Authorization Period, vacant possession in
respect of all the Project Facility [along with Project Site and all assets] shall revert
to Authority free and clear from all Encumbrances.
d. Termination Notice
If a Party, having become entitled to do so, decide to terminate this Agreement
pursuant to the preceding sub clause 18.3 (a) or (b), (c) it shall issue Termination
Notice setting out:
I. in sufficient detail the underlying Event of Default;
II. the Termination Date which shall be a date occurring not earlier than seven
days from the date of Termination Notice;
III. the estimated termination payment including the details of computation
thereof; and,
IV. any other relevant information.
e. Obligation of Parties
Following issue of Termination Notice by either Party, the Parties shall
promptly take all such steps as may be necessary or required to ensure that:

f.

I. until Termination the Parties shall, to the fullest extent possible,
discharge their respective obligations so as to maintain the continued
operation of the Project Facility,
II. the termination payment, if any, payable by the Authority in accordance
with the terms hereof is paid to the Authorizee on the Termination Date
and
III. the Project Facility is handed back to the Authority by the Authorizee
on the Termination Date free from any Encumbrance along with any
payment that may be due by the Authorizee to the Authority as per the
Provisions of Article 21.
Termination Payments
I. In case of termination of the Authorization Agreement on account of
Authority Event of Default, the Authorizee, shall forthwith transfer and hand
over the peaceful possession of the Project Facility, together with Project
Site and all movable & immovable assets created by the Authority to the
Authority without any Encumbrances, charge or lien. In such
circumstances, the Authority shall, provided there are no outstanding

Request for Proposal - Volume II: Draft Authorization Agreement

Page 65 of 104

<!-- page 66 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

claims of the Authority on the Authorizee, pay to the Authorizee by way of
termination payments the following within 180 days of the Transfer Date:
a. Pro-rata amount of Management Fee payable in terms hereof until
date of termination,
II. Upon Termination of this Agreement on account of Authorizee
Event of Default, the Authorizee shall not be entitled to receive any payment
from the Authority and also the Performance Security as provided by the
Authorizee shall be forfeited.

18.4 Rights of the Authority on Termination
a. Upon Termination of this Agreement for any reason whatsoever, the Authority
shall upon making (subject to terms hereof) the Termination Payment, if any, to
the Authorizee have the power and authority to:
I.
enter upon and take possession and control of the Project Site / Project
Facility forthwith;
II.
prohibit the Authorizee and any person claiming through or under the
Authorizee from entering upon/ dealing with the Project Site /Project
Facility
b. Notwithstanding anything contained in this Agreement, the Authority shall
not, as a consequence of Termination or otherwise, have any obligation
whatsoever including but not limited to obligations as to compensation for loss
of employment, continuance or regularisation of employment, absorption or
re-employment on any ground, in relation to any person in the employment
of or engaged by the Authorizee in connection with the Project, and the
handback of the Project Facility by the Authorizee to the Authority shall be free
from any such obligation.

18.5 Accrued Rights of Parties
Notwithstanding anything to the contrary contained in this Agreement,
Termination pursuant to any of the provisions of this Agreement shall be
without prejudice to accrued rights of either Party including its right to claim
and recover money damages and other rights and remedies which it may have in
law or contract. The rights and obligations of either Party under this Agreement,
including without limitation those relating to the Termination Payment, shall survive
the Termination but only to the extent such survival is necessary for giving
effect to such rights and obligations.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 66 of 104

<!-- page 67 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Request for Proposal - Volume II: Draft Authorization Agreement

Page 67 of 104

<!-- page 68 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 19 : LIABILITY AND INDEMNIFICATION
19.1 Liability to Third Parties
19.1.1 A Party shall promptly inform the other Party of any claims or proceedings or anticipated
claims or proceedings against the other Party in respect of which the other Party is entitled
to be indemnified under this Article 19 as soon as a Party becomes aware of the same.
Each Party shall give reasonable assistance to the other in defending such claims and
the Party giving such assistance shall be entitled to be indemnified to the extent of the
costs incurred by it in this regard;
19.1.2 None of the Parties shall permit any claim or proceedings referred to in Clause 19.1.1
above to be settled without the prior written consent of the other Party;
19.1.3 The GoJ shall not be liable in any manner whatsoever for the obligations and liabilities
incurred by the Authorizee for the Project Facility during the Authorization Period and for
the Authorizee’s contracts with Third Parties.

19.2 Indemnification
The Authorizee shall indemnify, defend and hold harmless the GoJ during and after
the term of this Authorization Agreement from and against all liabilities, damages,
losses, expenses, deaths, demands, actions, proceedings, costs and claims of any
nature whatsoever, including without limitation legal fee and expenses, suffered by the
GoJ or any Third Party as a result of or arising out of or in any way connected with
the acts, omissions, negligence, nuisance, breach of this Authorization Agreement
and failure
to perform obligations hereunder of or by the Authorizee and its
employees, agents, representatives and Contractors, including the use or violation of
any copyright work or literary property or patented invention, article or appliance,
except to the extent that such injury, damage or loss is attributable to a negligent or
wilful act or omission of the GoJ.

19.3 Risk and Liability
19.3.1 Except as
expressly
provided
in
the
Authorization Agreement, the
Authorizee shall carry out and perform its rights and obligations under the Authorization
Agreement at its own cost and risk. It shall be fully responsible for and shall bear the
financial risks in relation to the Project and all its rights and obligations under or pursuant
to the Authorization Agreement.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 68 of 104

<!-- page 69 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 20 : INSURANCE
20.1 Coverage
20.1.1 The Authorizee shall, on and from the date of taking over the possession of the Project
Site and Project Facility if any, up to the end of Authorization Period, maintain or cause
to be maintained, at its own expense, the following insurance policies in the name of the
Authority:
I.
II.

Fire & Theft;
Loss or damage to Equipments/Instruments/machines installed in the
Project Facility and Assets created by the GoJ and the Authorizee,
due to events like earthquake, floods, lightening etc.; and
III.
In respect of claims for personal injury to or death of any person employed
by theAuthorizee or its Contractor, subcontractors and arising out of such
employment.
20.1.2 The premiums payable on insurance coverage as indicated above, including any costs
and expenses incidental to the procurement and enforcement of such insurance coverage
shall be borne by the Authorizee.

20.2 Evidence of Insurance Coverage
20.2.1

The Authorizee shall furnish to the GoJ copies of certificates of insurance in
respect of the Insurance Policies referred to in Clause 20.1 as soon as reasonably
practicable after they are received by the Authorizee and from time to time shall
furnish evidence to the GoJ that all premiums have been paid, and that the relevant
policies remain in existence. In the event that the Authorizee fails to maintain the
Insurance Policies as required under this Authorizee Agreement, the GoJ may take
such required policies and recover the costs and expenses incurred in this regard from
the Authorizee.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 69 of 104

<!-- page 70 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 21 : TRANSFER OF PROJECT
21.1 Scope of Transfer
21.1.1 The Authorizee shall at the end of the Authorization Period or earlier termination of the
Authorization Agreement, as the case may be, forthwith and in any case not later than 60
days from expiry or earlier termination of the Agreement, hand over to the Authority, Project
Site, Project Facility and all other Assets created/installed during the Authorization Period
by the Authority, free and clear of any liability, charge, lien, Encumbrances along with all
of the Authorizee’s right, title and interest in the Assets constructed/installed by the
Authorizee on the Project Site. The Authorizee shall also deliver to the Authority on such
date such operating manuals, plans, design drawings and other information as may
reasonably be required by the Authority to enable it to continue the operation of the
Project Facility;
a. All service contracts/Project Agreements of the Authorizee shall specify the Transfer
Date & its corresponding effect. Failure to specify the Transfer Date & its
corresponding effect in the service contracts shall not adversely affect the Authority
and the Authorizee shall be solely responsible for handover of the Project Facility
along with Project Site and Assets on the Transfer Date at its own risk & cost.

21.2 Right of the Authority to choose Insurance and Contractor
Warranties
21.2.1 the Authority shall on the Transfer Date have the right to chose and retain all or any of
the unexpired Insurance Policies, contractor warranties in relation to the Project Facility.
The Authorizee shall ensure that any rights which are to be so assigned are capable of
assignment and such assignment has been approved under the terms of the relevant
contract by the counterparty to the Authorizee.

21.3 Assignment of Contracts
21.3.1 The Authority may, in its sole and absolute discretion, have the right to choose and retain
on the Transfer Date all or any of the contracts, equipment maintenance contracts, supply
contracts and all other contracts except service contracts with the Staff and Faculty
relating to the Institute, entered into by the Authorizee and subsisting as on the Transfer
Date;

21.4 Condition of the Facility upon Transfer
21.4.1 On the Transfer Date the Project Facility a n d t h e P r o j e c t A s s e t s shall be in fair,
usable/habitable and in a state of good working conditions as per Good Industry
Practices, subject to normal wear and tear, having regard for the nature, construction
and life of the facilities, constructions, structures etc ..
21.4.2
Request for Proposal - Volume II: Draft Authorization Agreement

Page 70 of 104

<!-- page 71 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

21.5 Passing of Risk
21.5.1 Until the Transfer Date, all risks shall lie with the Authorizee for loss of or damage to the
whole or any part of the Project Facility, Project Site and the Assets created by the
Authorizee during the Authorization Period. On and from the Transfer Date all risks
except risks arising out of service contracts, if any, in relation to the transferred Project
Facility, Project Site and the Assets created by the Authorizee during the Authorization
Period shall be deemed to have been transferred to and lie with the Authority.

21.6 Transfer Costs
21.6.1 The Authorizee shall transfer the possession of Project Site, Project Facility along with all
the Assets, to the GoJ free from any charge, Encumbrance, liability or obligation in terms
of this Authorization Agreement, through appropriate legal document executed in respect
thereof, if any;
21.6.2 The Authorizee shall be responsible for the costs and expenses with the transfer of the
possession of the Project Facility, Project Site and Assets. The Authorizee hereby
undertakes to indemnify the Authority against any liability arising out of any statutory liability
till the Transfer Date that may be sought to be or is imposed on a later date on the Authority
by any statutory authorities, in relation to the Project Facility and the assets there under.

21.7 Handing Over Procedure
21.7.1 Two months prior to the expiry of the Authorization Period the Authority and the
Authorizee shall meet and agree by mutual consensus on detailed procedures for the
handing over of the possession of the Project Facility and Assets. In the event the
handing over of the possession of Project Facility, is required pursuant to Article 17
hereof, the Parties shall meet to agree on such procedures as soon as possible and in
any event within 3 (three) days of either Party giving notice to the other Party requesting
such meeting. At the time of such meeting, the Authorizee shall submit a detailed list of
the structures, equipment, Assets created by the Authority to be handed over to the
Authority in terms hereof and the names of its representatives in charge of such transfer,
and the Authority shall inform the Authorizee of the identity of its representatives in charge
of the handing over procedure;
21.7.2 During the two month period prior to the handing over of the Project Facility at the expiry
of the Authorization period, the Authorizee shall provide such training services to the
representatives and employees of the Authority as may be reasonably necessary for them
to operate and maintain the Project Facility efficiently and safely following such transfer;
21.7.3 Notwithstanding anything contained in this Authorization Agreement, in the event the
Parties do not go through the transfer procedure, the Authority shall suo-moto re-enter the
Project Facility and take possession of the Project Facility and Assets created by the
Authority on the Project Facility.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 71 of 104

<!-- page 72 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

21.7.4 The Authorizee shall hand over to the Authority or its nominated agency all documents
including the operations manuals, designs, documents, and records relating to the Users,
bookings made and such other information relating to the Project and the Project Assets.
21.7.5 To the extent possible the Authorizee shall assign to the Authority or its nominated agency
at the time of handover/ transfer all unexpired guarantees and warranties by subcontractors and suppliers and all insurance policies in respect of the Project Facility and
assets.
21.7.6 The Authorizee shall at its cost remove from the Site all such moveable assets which are
not taken over by or transferred to the Authority or its nominated agency. In the event the
Authorizee fails to remove such objects within the stipulated time, the Authority or its
nominated agency may remove and transport or cause removal and transportation of such
objects, after giving the Authorizee notice of its intention to do so to a suitable location for
safe storage. The Authorizee shall be liable to bear the reasonable cost and the risk of
such removal, transportation and storage.
21.7.7

21.8 Effect of Transfer
21.8.1 Licenses and Permits: All transferable licenses or permits relating to the Project which
have been obtained in the name of Operator shall be transferred and assigned to Authority
or the Successor Manager and Operator shall provide Authority with a complete listing of
all permits and licenses (whether or not transferable and whether in Operator's name or in
the name of Authority) as soon as reasonably practicable prior to the effective date of
termination so as to permit Authority or Successor Manager sufficient time to apply for new
licenses or permits or to effect transfer to Authority's name or the name of Successor
Manager. With respect to any non-transferable licenses or permits, Operator agrees that it
shall cooperate reasonably with Authority and Successor Manager in obtaining new
licenses or permits, and, in connection therewith, shall surrender or agree to surrender
corresponding licenses or permits to the extent applicable solely to the Project which are
then carried in Operator's name
21.8.2 on the Transfer Date the Authorizee shall hand over peaceful possession, of the Project
Facility, Project Site and Assets to the GoJ and the Authorizee, its Contractors, subcontractors, agents, employees appointed by the
Authorizee shall vacate the
Project Facility, Assets if any;
21.8.3 The personnel of the Authorizee shall continue to be the employees of the Authorizee and
reverting back of the Project Facility/ Premises shall not in any manner affect their status
as employees of the Authorizee and they shall have no claim to any type of employment
or compensation from the Authority.
21.8.4 From the Transfer Date, the obligations and the rights of the Authorizee under this
Authorization Agreement shall terminate vis-à-vis the Authority and the Authority shall
take over the Project Facility and its operation and maintenance and any other rights

Request for Proposal - Volume II: Draft Authorization Agreement

Page 72 of 104

<!-- page 73 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

or obligations arising out of this Authorization Agreement which either expressly or
implicitly survive termination of this Authorization Agreement.
21.8.5 The Authorizee or its nominee(s) or sub-contractor or sub-Authorizee, and or persons
claiming through or under them, as the case may be, shall cease to conduct all commercial
activities within the Project Site from the Transfer Date.
21.8.6 Pursuant to the reverting back of the possession of the Project Facility/ to the Authority,
the obligations and the rights of the Authorizee under this Authorization Agreement shall
terminate vis-à-vis the Authority and the Authorizee shall no longer act in its capacity as
Authorizee in relation or pursuant to this Authorization Agreement.
21.8.7 The handover of immovable property comprising the Project Facility and the Project Assets
shall be deemed to be a termination of all right of way and Authorization rights granted to
the Authorizee in relation to the Project Site and the Project Facility. The movable assets
installed by the Authorizee comprising the Project and the Project Assets shall be deemed
to be transferred by delivery of possession.
21.8.8 On the Transfer Date, the possession of the Project Facility along with all the movable &
immovable assets (created by the Authority) shall revert back to the Authority or its
nominee, free and clear of any charges, liens and Encumbrances created or suffered by
the Authorizee.

21.9 Deemed Transfer
21.9.1 Notwithstanding anything contained in this Authorization Agreement, failure of the
Authorizee to;
a. handover the physical possession of the Project Facility along with the Project
Site and all Assets created by the Authority and Authorizee on the Project Site ;
and
b. execute a conveyance deed, if required, stating that the Authorizee shall have
no claim on the Project Facility along with the Project Site, Assets if any created
by the Authorizee on the Project Site.
c. shall not adversely affect the transfer of the Project Facility along with Project
Site and all Assets created by the Authority and Authorizee on the Project Site to
the Authority
Notwithstanding anything contained above, on the end of the Authorization Period
the Project Facility along with the Project Site with all its Assets created by the Authority
and the Authorizee shall be deemed to have reverted to the Authority on the expiry of
the Authorization Period or on the date of termination of this Authorization
Agreement, as the case may be, and from such date the Authority shall be deemed to
have assumed full Authorityship/ charge over such Project Facility without any liability
and/or Encumbrance, whatsoever, towards the Authorizee or any person claiming through
it.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 73 of 104

<!-- page 74 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Request for Proposal - Volume II: Draft Authorization Agreement

Page 74 of 104

<!-- page 75 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

Request for Proposal - Volume II: Draft Authorization Agreement

Page 75 of 104

<!-- page 76 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 22 : DISPUTE RESOLUTION
22.1

Amicable Settlement

22.1.1 In the event that any dispute, controversy or claim arises among the Parties in connection
with or under this Authorization Agreement or the interpretation of any of its provisions or
upon the occurrence of an Event of Default, GoJ and the Authorizee shall constitute a
consultation panel consisting of one senior representative appointed by each Party, and
such consultation panel shall endeavour to resolve such dispute, controversy or claim. All
such disputes shall be amicably settled through mutual consultation and negotiation
between the representatives in the consultation panel. The decision of the consultation
panel shall be binding upon the Parties. Each Party shall bear all the expenses of its
representative. The Parties hereto agree to use their respective best efforts to resolve all
disputes arising hereunder through the consultation panel. The consultation panel shall
be situated at Ranchi.

22.2 In the event the Parties are unable to resolve any dispute, controversy, or claim in
accordance with sub-clause 22.1, such dispute, controversy or claim shall be referred to
courts at Ranchi.

22.3

Performance during Dispute Resolution

22.3.1 Pending the submission of a dispute, controversy or claim to
the
consultation
panel or to the arbitral tribunal, and thereafter until the final decision of the consultation
panel or the arbitral tribunal, as the case may be, the Parties shall continue to perform
all of their obligations under this Authorization Agreement, without prejudice to a final
adjustment in accordance with such decision. Further, this Authorization Agreement
shall
remain subsisting and operative during the consultation or adjudication
proceedings and no payment due and payable to either Party shall be withheld except
the payment in dispute, if any.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 76 of 104

<!-- page 77 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 23 : ACCOUNTS AND AUDIT
23.1

Audited accounts

23.1.1 The Authorizee shall maintain books of accounts (project specific account) recording all
its receipts including income, expenditure, payments, assets and liabilities, in accordance
with this Agreement, Applicable Laws, Applicable Permits and Good Industry Practice.
The Authority shall have the right to inspect the Revenue records of the Authorizee in the
event of any discrepancy or error being found, the same shall be rectified and such
rectified account shall form the basis of payments by either Party under this Agreement.

23.2

Appointment of Auditors

23.2.1 The Authorizee shall appoint and have during the subsistence of this Agreement as its
Auditors/ Statutory Auditor (as the case may be), a firm having at least 05 (five) practicing
Chartered Accountants on its rolls. All fees and expenses of the Statutory Auditors shall
be borne by the Authorizee.
23.2.2 Notwithstanding anything to the contrary contained in this Agreement, the Authority shall
have the right but not the obligation, to appoint at its cost from time to time and at any
time, another firm of chartered accountants (the “Additional Auditors”) to audit and verify
all those matters, expenses, costs, realisations and things which the Statutory Auditors
are required to do, undertake or certify pursuant to this Agreement.

23.3

Certification of claims by Statutory Auditors

23.3.1 Any claim or document provided by the Authorizee to the Authority in connection with or
relating to receipts, income, payments, costs, expenses, accounts or audit, and any matter
incidental thereto shall be valid and effective only if certified by its Auditor/ Statutory
Auditors. For avoidance of doubt, such certification shall not be required for exchange of
information in the normal course of business.

23.4

Set-off

23.4.1 In the event any amount is due and payable by the Authority to the Authorizee, it may setoff any sums payable to it by the Authorizee and pay the balance remaining. Any exercise
by the Authority of its rights under this Clause 23.4 shall be without prejudice to any other
rights or remedies available to it under this Agreement or otherwise.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 77 of 104

<!-- page 78 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 24 REDRESSAL OF PUBLIC GRIEVANCES
24.1 Complaints Register
24.1.1 The Authorizee shall maintain a public relations office at the Project Facilities where it
shall keep a register (the “Complaint Register”) open to public access at all times for
recording of complaints by Users (the “Complainant”) in compliance with the minimum
standards set out in Clause 14. Information relating to the availability of and access to the
Complaint Register shall be prominently displayed by the Authorizee at the Project
Facilities and its website so as to bring it to the attention of all Users.
24.1.2 The Complaint Register shall have appropriate columns including the complaint number,
date, name and address of the Complainant, substance of the complaint and the action
taken by the Authorizee. Immediately after a complaint is registered, the Authorizee shall
give a receipt to the Complainant stating the date and complaint number.
24.1.3 Without prejudice to the provisions of Clause 24.1.1 and Clause 24.1.2, the Authority may,
in consultation with the Authorizee, specify the procedure for making complaints in
electronic form and for responses thereto.

24.2 Redressal of complaints
24.2.1 The Authorizee shall inspect the Complaint Register every day and take prompt and
reasonable action for redressal of each complaint. The action taken shall be briefly noted
in the Complaint Register and a reply stating the particulars thereof shall be sent by the
Authorizee to the Complainant under a certificate of posting.
24.2.2 Within 7 (seven) days of the close of each month, the Authorizee shall send to the
Authority and to the Independent Expert a true photocopy each of all the pages of the
Complaint Register on which any entry has been recorded during the course of such
month, and upon perusal thereof, the Authority may, in its discretion, advise the
Authorizee to take such further action as the Authority may deem appropriate for a fair
and just redressal of any grievance. The Authorizee shall consider such advice and inform
the Authority of its decision thereon, and if the Authority is of the opinion that the
Complainant is entitled to further relief, it may refer the matter to the competent forum for
its disposal under the Consumer Protection Act, 1986, and advise the Complainant to
pursue the complaint at his own risk and cost.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 78 of 104

<!-- page 79 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

ARTICLE 25 MISCELLANEOUS
25.1 Amendments
Except as otherwise provided herein, no modification, amendment or waiver of any
provision of this Authorization Agreement shall be effective unless such modification,
amendment or waiver is approved in writing by each of the Parties.

25.2 Severance of Terms
Whenever possible, each provision of this Authorization Agreement shall be interpreted
in such manner as to be effective and valid under Applicable Law, but if any provision of
this Authorization Agreement is held to be invalid, illegal or unenforceable in any respect
under any Applicable Law or rule in any jurisdiction, such invalidity, illegality or
unenforceability shall not affect any other provision or any other jurisdiction, but this
Authorization Agreement shall be reformed, construed and enforced in such jurisdiction
as if such invalid, illegal or unenforceable provision had never been contained herein.

25.3 Interest for Delayed Payment
The Parties hereto agree that payments due from one Party to the other Party under the
provisions of this Agreement shall be made within the period set forth therein, and if no
such period is specified, within 15 (fifteen) days of receiving a demand along with the
necessary particulars. In the event of delay beyond such period, the defaulting Party shall
pay interest for the period of delay calculated at a rate equal to 4% (four per cent) above
the Bank Rate and recovery thereof shall be without prejudice to the rights of the Parties
under this Agreement including Termination thereof.
Unless otherwise specified, any interest payable under this Agreement shall accrue on a
daily outstanding basis and shall be compounded on the basis of quarterly rates

25.4 Language
All notices, certificates, correspondence or other communications under or in connection
with this Authorization Agreement shall be in English.

25.5 Notices
Any notice to be given hereunder shall be in writing and shall either be delivered
personally or sent by registered post, telex, facsimile transmission, electronic mail or
other means of telecommunication in permanent written form. The addresses and
numbers for service of notice shall be given to the Parties at their respective addresses
set forth below:

Authorizee

: .......................................

Request for Proposal - Volume II: Draft Authorization Agreement

Page 79 of 104

<!-- page 80 -->

Selection of Suitable Private Sector Player Operation, Maintenance and Management of Hotel Prabhat Vihar Netarhat, Jharkhand

..........................................
..............................................
................................................
..................................................
Authority

: .......................................
..........................................
..............................................
................................................
..................................................

or such other address, telex number, or facsimile number as may be notified by that
Party to any other Party from time to time, and shall be deemed to have been made or
delivered (i) in the case of any communication made by letter, when delivered by
hand, by recognized international courier or by mail (registered, return receipt
requested) at that address and (ii) in the case of any communication made by telex
or facsimile, when transmitted properly addressed to such telex number or
facsimile number. In case any Party changes its address, communication numbers,
or directed attention as set forth above, it shall notify the other Parties in writing prior
to the adoption thereof.

25.6 Governing Law
This Authorization Agreement shall be governed by and construed in accordance with the
Laws of India and the courts at Ranchi shall have jurisdiction over the disputes arising
between the Parties.

25.7 Original Document
This Authorization Agreement is made in two original copies, each having the same
contents and the Parties have read and thoroughly understood the contents hereof
and have hereby affixed their respective signatures and seals before witnesses.

25.8 Relationship
Nothing in this Authorization Agreement shall constitute or be deemed to constitute
a partnership between the Parties or confer on any Party any authority to bind the
other or to contract in the name of the other or to incur any liability or obligation on
behalf of the other or make or deem to be the agent of the other in any way.

Request for Proposal - Volume II: Draft Authorization Agreement

Page 80 of 104
