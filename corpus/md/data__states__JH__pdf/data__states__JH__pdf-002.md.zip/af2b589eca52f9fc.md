---
doc_id: "af2b589eca52f9fc"
source_url: "https://jcsti.jharkhand.gov.in/document/guidelines/Guidelines_Procurement.pdf"
ministry: "Jharkhand Council on Science, Technology and Innovation"
title: "View"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9fb02fea9b9b4d55"
---

<!-- page 1 -->

STANDARD OPERATTNG PROCEDURE (SOP) F'OR PROCUREMENT OF
GOODS AI\TD SERVICES AT JIIARICIAND COI]NCIL ON SCMNCE
TECHNOLOGY AND INNOVATION
1. Introduction
The Jharkhand Council on Science, Technology and lnnovation (JCSTI) is committed to ensuring that

all procurement activities are conducted in a transparent, efficient, economical, fair, and accountable
manner, while upholding the highest standards of financial propriety and public trust. The Department

of Finance, Government of Jharkhand has notified the Jharkhand Procurement of Goods and Services
Manual, dated 04.10.2024 which lays down the principles, procedures, methods, and governance
mechanisms for procurement of goods and services. The Manual is applicable to State Govemment
Departments or a unit thereof or its attached or subordinate office/offrces who have been authorized
of
in this regard by competent authority to take decision regarding procurement of goods or services
that value.

In order to operationalize the provisions of the Jharkhand Procurement of Goods and Services

Manual,

Science
2024 within the institr,rtional context of JCSTI, Regional Science Centre, Ranchi and District
This SoP shall be
Centers in Jharkhand, this Standard operating Procedure (SoP) has been prepared.
and any
read in conjunction with the Jharkhand Procurement of Goods and Services Manual,2024,
issued by the
subsequent amendments, notifications, circulars, guidelines, orders, or instuctions
this SOP and
Govemment of Jharkhand from time to time. In the event of any inconsistency between
shall prevail. All
the prevailing provisions of the Manual or any Government notification, the latter
within JCSTI shall
officers, officials, committees, and stakeholders involved in procurement activities
with the
adhere to the provisions of this Sop and shall be responsible for ensuring compliance
Jharkhand Procurement of Goods and Services Manual, 2024.

2. Applicability of the SOP
The Sop shall be applicable to procurements done by JCSTI, Regional Science Centre,
District Science Centers and their constituent units like Planetariums and Innovation Hubs.

Ranchi,

3. Procuring Entity and Procurement Oflicer
The following table mentions the Procuring Entity and Procurement officer as

per the Offrce/ Centre

Procuring the Goods and Services

Office /
JCSTI

r

Procuring EntitY

Procurement Officer/ Buyer
Executive Director, JCSTI

JCSTI

s-$)

Paoe 116

<!-- page 2 -->

Office / Institution

Procuring Entity

Procurement Officer/ Buyer

Regional Science Centre,

Regional Science Centre,

In-Charge/ Director/Flead of

Ranchi

Ranchi

Regional Science Centre, Ranchi

District Science Centers

District Science Centers

Curator, District Science Centre

Each procuring entity shall be considered distinct, and they must maintain an independent profile on

the Government e-Marketplace (GeM) Portal. Furthermore, all procurement activities pertaining to a

particular Procuring Entity shall be undertaken exclusively by that entity. No other Procuring Entity
shall carry out procurement on its behalf.

4. Procurement Committees
The procurement process shall be undertaken through the constitution and involvement of such
committees as required under the provisions of the Jharkhand Procurement of Goods and Services
Manual, 2024. The roles, responsibilities, and functioning of these committees shall be in accordance

with the applicable provisions of the Manual and any instructions issued by the Government of
Jharkhand from time to time. The committees mentioned are meant only for internal scrutiny,
recommendation, and approval. They shall not replace, bypass, or override any provision of the
Manual.
4.1. The composition of the committees for any procurement at JCSTI shall be as follows:

Committee / Officer

Composition

I

Buyer/ Procurement

Officer
Consignee

Executive Director, JCSTI
Technical Officer, JCSTI
a

Executive Director, JCSTI - Chairperson

a

In-Charge Regional Science Centre, Ranchi- Member

Procurement Committee/

a

Nominated Member from Department of Finance- Member

Bid Evaluation

a

Nominated Member for Department of cabinet Secretariat and Mgilance

Committee

Bid Preparation
Committee

r

- Member
a

Technical Officer, JCSTI- Member

a

Accounts Officer, JCSTI- Member

o Technical Officec JCSTI
r Accounts Officer, JCSTI
o Curator of Regional Science Centre, Ranchi

Paoe 216

<!-- page 3 -->

Composition

Commiffee / Officer

Any subject matter expert as nominated by the chairperson of

a

Procurement Committee

Bid Vetting Officer

Accounts Officer, JCSTI

a

4.2. Thecomposition of the committees for any procurement at Regional Science Centre, Ranchi shall
be as follows:

Composition

Committee / Officer
Buyer/ Procurement

In-Charge/ Director/Head of Regional Science Centre' Ranchi

Oflicer
Science Centre

Curator,

In-charge

a

/ Director I Head of Regional Science Centre, Ranchi -

Chairperson
Procurement Committee/

Bid Evaluation
Committee

Bid Preparation

o Curator Regional Science Centre, Ranchi- Member
o DistrictAccounts Offrcet Ranchi- Member
r ChiefMentor, Innovation Hub- Member
o Accounts Officer, Regional Science Centre- Member
. Any other member as nominated by the chairperson
a

Curator Regional Science Cenfe, Ranchi

a

Chief Mentor, Innovation Hub

a

Junior Mentor, Innovation Hub

a

Any subject matter expert as nominated by the chairperson of

Committee

Procurement Committee

Bid Vetting Offrcer

a

Accounts Offrcer, Regional Science Centre, Ranchi

4.3. The composition of the committees for any procurement at

District Science centers shall be as

follows:
Composition

Committee / Officer

Buyer/ Procurement Curator, District Science Centre
Officer
Consignee

Curator, District Science Centre
a

Procurement Committee /

Bid Evaluation
Committee

r

In-charge

/ Director / Head of Regional Science Centre, Ranchi -

Chairperson

o Curator, District Science Centre- Member
o District Accounts Officer- Member
Paae 316

<!-- page 4 -->

Committee / Officer

Composition

o Chief Mentor, Innovation Hub / Education Offrcer- Member
r Accounts Officer, District Science Centre- Member- Member
. Any other member as nominated by the chairperson
Bid Preparation
Committee

r Curator, District Science Centre
o Chief Mentor, Innovation Hub / Education Officer
. Any subject matter expert as nominated by the chairperson of
Procurement Committee

Bid Vetting Officer

a

Accounts Officet District Science Centre

5. Powers for BudgetarT Approvals and Administrative Sanctions
The following authorities shall have the powers to provide budgetary and administrative approval on
the procurement requisition within their respective financial limits as below:
Procurement Value (in INR)

Approval Authority

E

o Executi ve Director, JCSTI for expenses from funds of JCSTI
o In-Charge / Director / Head of Regional Science Centres for
Upto l0 Lakhs

expenses out oftheir respective Funds

r Curator, District Science Centres for expenses out of their
respective Funds

Above 10 Lakhs and upto I Crore
Above 1 Crore and upto 2.5 Crore

Member Secretary , Executive Committee, JCSTI

Additional Chief Secretary / Principal Secretary / Secretary,
Department of Higher and Technical Education, Govt. Jharkhand

Above 2.5 Crore and upto 15 Crore

Hon'ble

of Executive

Committee

Above 15 Crore

Executive Committee, JCSTI

6. Steps of Procurement:
The procurement process for goods and services shall involve the following

activities undertaken in

the order stated below:

6.1. Need Assessment and Annual pnocurement plan

(a) While determining the need for procurement of goods and services,

the procuring entity shall

consider and assess its essentiality by ascertaining whether the procurement

is essential for

public needs, official purpose or approved activities.^

Y

ss$I
Pane 416

<!-- page 5 -->

(b) Each Procuring Entity as mentioned in Section - 03 of the SoP shall prepare an annual
procurement plan at the beginning of every financial year based on its approved activities,

projects, maintenance requirements, and budget provisions and with approval from its
Procurement Officer as mentioned in Section - 04 of this SoP shall share it with Executive
Director, JCSTI.

(c) The Executive Director, JCSTI shall prepare the Annual Procurement Plan of its Office and
after consolidating the Annual Procurement Plan from all other Oflices / Procuring Entities
shall place it for information of the Executive Committee, JCSTI.

(d) The procurement plan shall contain the indicate heads and the estimated budget under each
head of Procurement. It may be noted that the Annual Procurement Plan is for estimation
purposes only and each Office / Procuring Entity shall have the Authority to undertake
Procurement, subject to available of actual funds and approval of the Competent Financial

Authority as mentioned in Section - 05 of this SoP.

6.2. Requisition of Goods/Services

(a) For every procurement, the concerned Procuring Entity shall prepare a requisition of the items
to be procured along with its quantity, purpose, estimated cost, source of funds, and basic
specification.

O) The requisition of the procurement shall be submitted to the Procurement Officer, who shall
approve or seek the approval of the Competent Authority in accordance with the provisions
mentioned in Section 5 of this SoP.

(c) After approval from the Competent Authority, the procurement shall be undertaken by the
procedure prescribed in the Jharkhand Procurement of Goods and Services Manual, 2024.
6.3. Selection of procurement Method: Upon approval on the requisition by the competent authority,
the Procurement Committee / Bid Evaluation Committee shall determine the appropriate method

of procurement based on the provisions of the Jharkhand Procurement of Goods and Services
Manual,2024.
6.4. preparation Tender Documents and Invitation for Bids: In case preparation of Bids is required
as per the Procurement Method as mentioned in Section 6.3, the Procurement Committee / Bid

Evaluation Committee shall prepare the required documents and forward it to the Bid Vetting
Authority for vetting. In case, the value of the subject maffer of the procurement is equal to or
above INR I Crores, the tender documents shall be prepared by the Bid Preparation Committee.

0)

\,$\

Paoe 516

<!-- page 6 -->

For procurements below INR I Crores, the Procurement Committee / Bid Evaluation Committi
may or may not engage the Bid Preparation Committee for preparing the Bid Documents. The bid

documents must be approved by the procurement offrcer and published on GeM or any other
platforms as per the Jharkhand Procurement of Goods and Services Manual,2024.
6.5. Evaluation of Bids and Awarding of Contract: The bids/offers received shall be evaluated by
the Procurement / Bid Evaluation Committee of the respective procurement entities. The quorum

for meetings of the Committee shall be 50% of its total members. The bid evaluation committee

shall select the appropriate bidder based on the terms and conditions prescribed in the Bid
Document and the provisions ofthe Jharkhand Procurement of Goods and Services Manual, 2024.

After successful selection of the Winning Bid, the recommendations of the Procurement / Bid
Evaluation Committee shall be sent to the appropriate Competent Authority as prescribed in
Section 05 for this SoP for approval.

6.6. Contract Management and Performance Monitoring: After issuance of a Purchase Order,
Work Order, or Contract Agreement, the Procurement Offrcer and Consignee shall ensure proper

monitoring of contract execution. Deliverables, timelines, quality standards, warranties, service
obligations, and other contractual requirements shall be monitored and documented.
6.7. Maintenance of Procurement Records: Each Procuring Entity shall maintain complete
procurement records, either in physical or electronic form, including requisitions, approvals,
tender documents, bid evaluation reports, purchase orders, contracts, invoices, payment records,

inspection reports, correspondence, and completion certificates. Records shall be preserved for
such period as prescribed under applicable Government rules and audit requirements.

6.8. Disbursement of Funds: It is clarified that, for all procurements, once the approval of the
Competent Authority has been received on the selection of any entity, any payments within the

value arrived at in the bid or estimated value of procurement, the Procuring Officer of each
individual entity shall have full powers for disbursement of funds till the approved value and no
additional approvals shall be required by any otherAuthority or Officer.

7. Powers to Amend the SOP:
Based on the recommendations of the Procurement Committees of different procuring entities, any

provision of the SOP can be amended with the approval of the Executive Committee JCSTI.

r

p\q
Pane 616
