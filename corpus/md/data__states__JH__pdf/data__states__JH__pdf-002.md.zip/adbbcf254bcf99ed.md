---
doc_id: "adbbcf254bcf99ed"
source_url: "https://finance.jharkhand.gov.in/updates/eco-serv2013-14/FiscalPolicy.pdf"
ministry: "Finance Department, Jharkhand"
title: "Fiscal Policy"
date: ""
pages: 38
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e5a7e5c1fa88ceda"
---

<!-- page 1 -->

Government of Jharkhand

FISCAL POLICY STRATEGY STATEMENT
AND
MEDIUM TERM FISCAL PLAN

Department of Finance
2014

<!-- page 2 -->

GOVERNMENT OF JHARKHAND

STATEMENTS PRESENTED
ALONGWITH ANNUAL BUDGET 2014-15
UNDER THE JHARKHAND FISCAL RESPONSIBILITY AND
BUDGET MANAGEMENT RULES, 2007 (as amended)

<!-- page 3 -->

INDEX

Sl.

Form

Rule

Description

Page

1.

I

Rule 4 (1)

Fiscal Policy Strategy Statement

1

2.

II

Rule 4 (2)

Medium Term Fiscal Plan

15

3.

III

Rule 6

Disclosure Statement

21

4.

IV

Rule 7

Special Statement on Number of Employees and
related Salaries

23

5.

V

Rule 8

Statement of Deferred Liabilities

33

<!-- page 4 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

1

Form – I

FISCAL POLICY STRATEGY STATEMENT
{See Rule 4 (1)}

OVERVIEW OF THE STATE’S ECONOMY
The economy of the State of Jharkhand has performed well since its formation in November, 2000. The Gross
State Domestic Product (GSDP) of the state grew at an average annual rate (CAGR) of 7.10 percent in real
terms during the period 2004-05 to 2012-13 amidst the year-to-year fluctuations in the growth rate. During
the 11th Five Year period (i.e. between 2007-08 and 2011-12), the state experienced an average annual
growth (CAGR) of 7.67 percent. The main driver of this growth has been the services or the tertiary sector
which grew at a CAGR of 11.37 percent in real terms between 2004-05 and 2012-13. The services sector
grew at a much higher rate of 12.55 percent during the 11th Five Year Plan period. The secondary sector, on
the other hand, grew at a much slower pace at 3.07 percent per annum between 2004-05 and 2012-13 and
during the 11th Plan Period its CAGR was much lower at 1.86 percent.
Fig 1: Sectoral Composition of GSDP at constant 2004-05 prices (%)

The sector wise analysis suggests that there has been a shift in the sectoral contribution to the GSDP. The share
of the secondary sector which was the major contributor to the GSDP has been declining. Its share in the GSDP
declined from 41.2 percent in 2004-05 to 30.3 percent in 2012-13 as can be seen from fig 1. The share of the
tertiary or the services sector, on the other hand, has increased considerably during this period. The share of
the tertiary sector increased from 32.9 percent in 2004-05 to about 45.0 percent in 2012-13. The share of the
primary sector which includes agriculture and animal husbandry, forestry, fishing, mining and quarrying, which
contributed about 25.8 percent to the GSDP in 2004-05 declined marginally and was 24.6 per cent in 2012-13.

<!-- page 5 -->

2

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

For the year 2011-12, the estimated share of the primary sector at 25.0 percent in Jharkhand is much higher
than the all-India share of 16.2 percent. Even the contribution of the secondary sector at 31.5 percent is
much higher in Jharkhand than the all-India share of 25.4 percent, and this reflects the key strength of the
State in terms of industrialization. The contribution of the tertiary sector to the GSDP is 48.61 per cent.
The growth trend and its composition provide a rough road map for policy as well as pointing out opportunities
for growth that can be obtained by focusing on the primary and the tertiary sectors. The growth of the
secondary sector definitely provides key pointers for the State to create an enabling environment for further
development of this sector. The growth momentum in the secondary sector is possible with increased
infrastructure creation as well as by creating a climate for larger flow of private investments to the State. At
the same time, there is considerable scope for growth in the primary sector as well. The agricultural sector
is marked by significant variability in production and productivity in different years, requiring the State to
make investments in irrigation and farm technology.
Table 1: Growth and Composition of GSDP (at constant prices 2004-05)
(Rs. in crores)
Sectors

2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

Total GSDP

59757.7

57848.4

59225.7

71377.1

70129.5

77240.0

89491.1

95912.1

103426.5

-3.20

2.38

20.52

-1.75

10.14

15.86

7.17

7.83

9241.9

10405.0

10988.4

12809.2

12013.3

12549.7

13032.2

13730.3

3.65

12.58

5.61

16.57

-6.21

4.46

3.84

5.36

6732.9

6244.5

6297.1

7769.4

8333.3

10794.8

10909.9

11741.6

3.21

-7.25

0.84

23.38

7.26

29.54

1.07

7.62

15974.8

16649.5

17285.6

20578.6

20346.5

23344.4

23942.1

25471.9

3.46

4.22

3.82

19.05

-1.13

14.73

2.56

6.39

20594.3

19411.2

28082.8

21259.8

22648.5

26790.5

30230.7

31385.5

-16.41

-5.75

44.67

-24.30

6.53

18.29

12.84

3.82

21279.3

23165.1

26008.8

28291.1

34245.1

39356.2

41739.3

46569.1

8.13

8.86

12.28

8.78

21.05

14.93

6.06

11.57

1576.6

1947.1

2291.3

2447.1

2948.2

3613.5

4031.3

4701.0

14.68

23.50

17.68

6.80

20.48

22.57

11.56

16.61

2282.4

2494.3

2582.9

2447.2

3136.8

4931.1

4960.4

5602.9

7.92

9.29

3.55

-5.25

28.18

57.20

0.59

12.95

growth (%)
1 Agriculture & Allied

8916.7

growth (%)
2 Mining & Quarrying

6523.4

growth (%)
3 Primary Sector (1+ 2)

15440.2

growth (%)
4 Secondary Sector

24638.4

growth (%)
5 Service Sector

19679.2

growth (%)
a Banking & Insurance

1374.7

growth (%)
2114.8

b Real Estate
growth (%)

Note: Growth refers to percent change over the previous year

<!-- page 6 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

3

FISCAL PERFORMANCE
The fiscal situation of Jharkhand which deteriorated significantly until 2005–06, manifested itself in rising
revenue and improving fiscal deficits. The fiscal strategies followed by the Government of Jharkhand since
2006-07 involving reforms in the areas of commercial taxes, introduction of the Value Added Tax (VAT),
emphasis on resource mobilization in the form of non-tax revenues, the policy expenditure management
which focused on rationalising revenue expenditure, by containing the committed component of non-plan
revenue expenditure such as salary and wages, interest payments and pension payments have all favourably
worked towards an improved fiscal situation of the State.
The improved scenario could be sustained as the Government was able to contain its Gross Fiscal Deficit,
and also have a revenue surplus in the years 2006-07, 2007-08 and 2008-09. In 2009-10, the revenue deficit
was a meager Rs. 9.78 crores which recovered to a revenue surplus of Rs. 836.39 crores in the following year
(i.e., in 2010-11). The State is in revenue surplus since 2010-11 (see fig 2). This has helped the Government to
allocate greater resources towards social and economic services, and to increase Plan Expenditure, especially
on Capital account, and bring down the level of debt liabilities as a percentage of GSDP.
Fig 2: Trends of Deficit (-)/Surplus(+)
(in Rs. crores)

Note: Positive values indicate surplus while negative values stand for deficit

<!-- page 7 -->

4

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

The overall fiscal scenario of the State of Jharkhand has improved in recent periods. The Gross Fiscal Deficit
has come down from its peak level of Rs. 5,603.00 crores in 2005–06 to Rs. 3,012.16 crores in 2009–10
and in 2011-12 the Fiscal Deficit stood at Rs. 1,925.17 crores in 2011-12 (with the lowest level Rs. 910.53
crores achieved in 2006–07) as can be seen from fig 2. However, in 2012-13 the Gross Fiscal deficit has
again increased considerably to Rs. 3406.44 crores. As a proportion of the State’s GSDP, the Fiscal Deficit
decreased from a peak of 9.2 percent in 2005–06 to 2.10 percent in 2012-13 (see fig 3). The revenue account
had a surplus for several years. As a percentage of GSDP, the Revenue Deficit improved from a deficit of (-)
0.53 percent in 2004-05 to reach a surplus of 1.42 percent in 2007.08 and was 0.84 percent in 2012-13 as can
be seen from fig 3. The Primary Deficit of Jharkhand was in surplus in only three years during the period
2004-05 to 2011-12, viz., 2006-07, 2010-11 and 2011-12. In the remaining years between 2004-05 and 201213, there was a deficit as can be seen from figures 2 and 3. Since 2008-09, both FD and PD as a percentage of
GSDP, have improved considerably indicating improvement in the fiscal situation of the State. However, in
2012-13, there has been a marginal deterioration in the two ratios as can be seen from fig 3.
Fig 3: Deficits as Percentage of GSDP

The outstanding liabilities of the Government that had reached its peak of 29.01 percent of the GSDP in
2006–07 steadily decreased since then, reaching 22.51 percent in 2010-11 and 21.39 percent in 2012-13. The
overall fiscal trends for the state of Jharkhand for the period 2004-05 to 2012-13 are shown in table 2.

<!-- page 8 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

5

Table 2: Overall Fiscal Trends during 2004-05 to 2012-13
(Rs. in Crores)
2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

Own Revenue Receipts

3435.24

4184.57

4438.90

5074.75

5697.99

6754.26

8519.52

9992.11

11759.21

Own Tax Revenue

2382.79

2758.05

3188.51

3473.35

3746.19

4500.12

5716.63

6953.89

8223.58

Own Non Tax Revenue

1052.45

1426.52

1250.39

1601.40

1951.80

2254.14

2802.89

3038.22

3535.63

Central Transfers

3225.27

4279.31

5570.92

6951.80

7514.89

8364.20

10261.60

12427.34

13010.35

Total Revenue Receipts

6660.51

8463.88

10009.82

12026.55

13212.88

15118.46

18781.12

22419.45

24769.56

Revenue Expenditure

6975.91

8490.82

9063.94

10831.97

12876.90

15128.24

17944.74

20991.58

23399.87

NPRE

4995.73

6352.39

6632.25

7852.09

9063.70

11369.76

11940.92

13345.30

15656.61

PRE

1980.18

2138.43

2431.69

2979.88

3813.20

3758.48

6003.81

7646.29

7743.26

Capital Expenditure

1910.22

5585.87

1872.15

3181.20

3469.47

3023.02

2971.86

3376.47

4819.24

Total Expenditure

8886.13

14076.69

10936.09

14013.18

16346.37

18151.26

20916.60

24368.05

28219.11

Revenue Deficit

-315.40

-26.94

945.88

1194.58

335.99

-9.77

836.39

1427.87

1369.69

-0.53

-0.04

1.41

1.42

0.38

-0.01

0.66

1.00

0.84

-2218.04

-5603.00

-910.52

-1942.41

-3114.58

-3011.00

-2111.36

-1925.18

-3406.44

-3.71

-9.20

-1.36

-2.31

-3.55

-2.99

-1.66

-1.35

-2.10

-1076.72

-4183.45

702.86

-184.38

-1227.70

-703.55

116.18

341.90

-1015.19

-1.80

-6.87

1.05

-0.22

-1.40

-0.70

0.09

0.24

-0.62

13511.69

17360.07

19417.37

21614.58

24083.98

27165.04

28655.07

30663.79

34768.87

(as % of GSDP)

22.61

28.51

29.01

25.75

27.43

27.00

22.51

21.57

21.39

GSDP (at current prices)

59757.72

60900.54

66934.75

83949.59

87793.93

100620.68

127281.05

142164.54

162557.14

(as % of GSDP)
Fiscal Deficit
(as % of GSDP)
Primary Deficit
(as % of GSDP)
Outstanding liabilities

Note: 1) Negative value for Revenue Deficit, Fiscal Deficit and Primary Deficit indicate deficit while positive value indicate surplus;
2) NPRE: Non-Plan Revenue Expenditure; PRE: Plan Revenue Expenditure

GROWTH OF TAX REVENUE
Own revenues of a State consists of own tax revenues and own non-tax revenues. Own tax revenue is the
major source of own revenues of the state accounting for about 69.93 percent of own revenue receipts in
2012-13. The own revenue receipts of Jharkhand grew at a CAGR of 16.63 percent during the period 200405 to 2012-13.
During 2012-13, the State’s own revenues comprised Rs. 8,223.58 crores as tax revenue and Rs. 3,535.63
crores as non-tax revenue (see table 3). Own tax revenues of Jharkhand grew at 18.26 percent while non-tax
revenues by 16.37 percent during 2012-13 over 2011-12. As a percentage of GSDP, the State’s own tax and
non-tax revenue were 5.06 percent and 2.18 percent, respectively, in 2012-13.

<!-- page 9 -->

6

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

The Own Tax Revenues of Jharkhand grew at a CAGR of 16.75 percent during the period 2004-05 to 201213. The main contributor to the growth in own tax revenue has been revenues from the taxes on sales, trades
etc., i.e., sales tax or commercial taxes which accounted for about 78.1 percent of the total own tax revenues
of the state in the year 2012-13 as can be seen from table 3.
The Government of Jharkhand introduced the Value Added tax (VAT) with effect from 1st April 2006.
Introduction of VAT resulted in an increase in revenues for the State. The revenues from sales tax increased
at a CAGR of 16.58 percent during 2004-05 to 2012-13. Growth of revenue from sales taxes was very
significant. After including compensation from the Central Government on account of VAT and Central
Sales Tax (CST), the total revenue generated from sales taxes rose from Rs. 4,473.44 crores in 2010-11 to
Rs. 5,522.02 crores in 2011-12 and further to Rs. 6421.61 crores in 2012-13, thus, growing at 16.29 percent
between 2011-12 and 2012-13. The other important contributors to the own tax revenues have been the
State Excise, Stamps and Registration fees and Tax on vehicles.
Table 3: Trends in State’s Own Revenue Receipts

(Rs. in crores)

2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

3435.2

4184.6

4438.9

5074.8

5698.0

6754.3

8519.5

9992.1

11759.2

1 Own Tax Revenue

2382.8

2758.1

3188.5

3473.4

3746.2

4500.1

5716.6

6953.9

8223.6

(as % of GSDP)

3.99

4.53

4.76

4.14

4.28

4.47

4.49

4.89

5.06

Sales tax

1881.53

2212.03

2556.90

2845.88

2996.19

3597.20

4473.43

5522.02

6421.61

State excise

145.76

161.64

129.62

156.86

205.46

322.75

388.34

457.08

577.92

Taxes on vehicles

130.24

138.32

218.27

135.66

201.56

234.21

312.37

391.92

465.36

Stamps & registration fees

86.59

91.93

122.02

156.26

192.16

238.20

328.35

401.17

492.40

Taxes on goods &
passengers

78.19

96.66

74.19

71.07

54.02

12.44

21.08

40.95

0.51

Land revenue

17.47

17.66

36.35

26.26

53.33

41.28

130.65

52.94

96.38

Other taxes

43.01

39.81

51.16

81.54

50.47

54.04

62.41

87.80

169.40

1052.5

1426.5

1250.4

1601.4

1951.8

2254.1

2802.9

3038.2

3535.6

1.76

2.34

1.87

1.91

2.22

2.24

2.20

2.14

2.18

A

Own Revenue Receipts

2 Own Non Tax Revenue
(as % of GSDP)

The buoyancy of own taxes during the period 2004-05 to 2012-13 has been 1.15. Sales tax and state excise
have a buoyancy of 1.13 and 1.48, respectively, for this period. All other state taxes have a buoyancy of less
than 1 with the exception of stamps and registration fees and taxes on vehicles which had a buoyancy of 1.81
and 1.20, respectively. Factors that had contributed to such buoyant revenue growth in sales/commercial tax
collection included the resumption in the economic growth after the recession of 2008-09, the roll-back of
tax rate in diesel from 14.5 percent to 20 percent with effect from February 2010, enhancement of the rate of

<!-- page 10 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

7

tax on foreign liquor from 35 percent to 50 percent effective September from 2010 and most importantly, the
sanction of VAT/CST compensation from the Government of India received during 2007-08 and 2011-12.
Given the low taxable capacity of the State of Jharkhand, as determined by its low per capita income,
improved revenue mobilization has been made possible through better tax administration and compliance.
Reform initiatives have been undertaken by the state government in the form of strengthening of the tax
administration, such as a special drive for new registration of dealers, with more than 5,000 new dealers
registered in the recent past; and better tax administration concerning the speedy recovery of dues and
speedy disposal of cases.

EXPENDITURE POLICY
Jharkhand Government’s expenditure management policy aims at rationalising revenue expenditure, by
containing the committed component of non-plan revenue expenditure such as salary and wages, interest
payments and pension payments. Some of the other initiatives by the state government included the
following:
i.

Attempting to undertake some of the essential functions of the Government, wherever there is a
necessity, on short-term contract employment and consolidated remuneration basis, in order to
reduce salary expenditure,

ii. Introduction of the Defined Contributory Pension Scheme for all the employees joining from
December 2004,
iii. Gradual rationalization in subsidies, and reduction of debt servicing liabilities by swapping and
buying back of the high cost loans, and recourse to accessing the low cost market based borrowing
options.
The Total Expenditure of the State grew at a CAGR of 15.54 percent between 2004-05 and 2012-13. The major
component of Total Expenditure is Revenue Expenditure in general and Non-Plan Revenue Expenditure
(NPRE) in particular as can be seen from table 4 which presents the trends and composition of Total
Expenditure for Jharkhand for the period 2004-05 to 2011-13. Expenditure on salary, pension and interest
payments together accounts for more than 75 percent of the non-plan revenue expenditure of the state in
2012-13. Due to the efforts of the state government, the share of these committed expenditures in the state’s
total revenue expenditure has been coming down. Its share declined from about 60.2 percent in 2009-10 to
50.3 percent in 2012-13.
There has been an attempt to enhance the capital content of government expenditures. The capital expenditure
increased from Rs. 3,181.20 crores in 2007-08 to Rs. 3,469.49 crores in 2008–09, Rs. 3,376.46 crores in 201112 and further to Rs. 4819.2 crores in 2012-13. Loans and advances given by the State Government to Boards,

<!-- page 11 -->

8

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

Corporations, Cooperatives, and government employees were Rs. 597.66 crores in the year 2007-08, which
have decreased to Rs. 307.57 crores in 2010–11 and Rs. 217.10 crores in 2011-12. However, it increased to
Rs. 600.8 crores in 2012-13. The Government focuses on generating productive capacity of the economy
through capital expenditure and developmental activities pertaining to social and economic services.
Table 4: Trends in Government Expenditure and Its Components
(Rs. in Crores)
2009-10

2010-11

2011-12

2012-13

2009-10

2010-11

2011-12

2012-13

Actual

Actual

Actual

Actual

Actual

Actual

Actual

Actual

8886.1

14076.7

10936.1

14013.2

16346.4

18151.3

20916.6

24368.1

14.9

23.1

16.3

16.7

18.6

18.0

16.4

17.1

6975.9

8490.8

9063.9

10832.0

12876.9

15128.2

17944.7

20991.6

78.5

60.3

82.9

77.3

78.8

83.3

85.8

86.1

4995.7

6352.4

6632.3

7852.1

9063.7

11369.8

11940.9

13345.3

(As % of RE)

71.6

74.8

73.2

72.5

70.4

75.2

66.5

63.6

Interest payment (IP)

1141.3

1419.6

1613.4

1758.0

1886.9

2307.5

2227.5

2267.1

Pensions

620.1

657.2

679.0

818.3

988.4

1680.8

2081.1

2296.7

Salaries

2116.5

2325.9

2517.7

2984.6

3800.7

5125.4

5434.1

6150.0

IP, Pension & Salaries

3877.9

4402.6

4810.0

5560.9

6676.0

9113.7

9742.7

10713.8

(As % of RE)

55.6

51.9

53.1

51.3

51.8

60.2

54.3

51.0

(As % of NPRE)

77.6

69.3

72.5

70.8

73.7

80.2

81.6

80.3

1980.2

2138.4

2431.7

2979.9

3813.2

3758.5

6003.8

7646.3

28.4

25.2

26.8

27.5

29.6

24.8

33.5

36.4

1910.2

5585.8

1872.1

3181.2

3469.5

3023.0

2971.9

3376.5

(As % of TE)

21.5

39.7

17.1

22.7

21.2

16.7

14.2

13.9

Capital Outlay

1333.4

1839.0

1461.3

2583.5

3051.3

2703.0

2664.3

3159.4

Loans & Advances

576.8

3746.8

410.8

597.7

418.2

320.0

307.6

217.1

59757.7

60900.5

66934.8

83949.6

87793.9

100620.7

127281.1

142164.5

Item
Total Expenditure (TE)
(As % of GSDP)
Revenue Expenditure (RE)
(As % of TE)
Non-plan rev expd (NPRE).

Plan rev. expd. (PRE)
(As % of RE)
Capital Expenditure

GSDP (current prices)

The trends in composition of total revenue expenditure by services namely, General, Economic and Social
services are shown in table 5. The expenditure on account of general services occupies the dominant position
followed by expenditure on social services and economic services. Share of expenditure on economic services
is the least among the three services. Since 2004-05, we see that the share of general services in total revenue
expenditure has declined from 42.2 percent in 2004-05 to 37.2 percent in 2012-13 while that of economic
services has increased from 21.6 percent to 27.3 percent. The share of social service, however, increased to

<!-- page 12 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

9

42.6 percent in 2008-09, after which it declined sharply and in 2012-13 it was around 35.5 percent of the
total revenue expenditure.
Table 5: Composition of total Revenue Expenditure by Activities
(Rs. in Crores)

General Services
(% of RE)
Social Services
(% of RE)
Economic Services
(% of RE)
Revenue Expenditure

2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

2943.1

3577.4

3810.0

4537.5

4834.6

6521.3

6924.7

7767.1

8696.5

42.2

42.1

42.0

41.9

37.5

43.1

38.6

37.0

37.2

2523.6

3060.3

3327.3

4327.0

5474.6

5694.4

6773.4

7365.5

8308.6

36.2

36.0

36.7

39.9

42.5

37.6

37.7

35.1

35.5

1509.2

1853.1

1924.6

1967.4

2532.5

2912.4

4246.5

5859.0

6394.8

21.6

21.8

21.2

18.2

19.7

19.3

23.7

27.9

27.3

6975.8

8490.8

9061.9

10831.9

12841.6

15128.0

17944.6

20991.6

23399.9

Government expenditures are prioritized keeping in view the priorities in the Eleventh Five Year Plan of
Jharkhand which emphasizes on improving the quality of life of the people by providing access to basic
facilities such as health, education safe drinking water, sanitation, etc. In the initial two years of the 11th
Five Year (2007-08 and 2008-09), there was an increase in the share of expenditure on social services but
thereafter the share of expenditure on social services in total revenue expenditure has declined. This trend
seems to have reversed in 2012-13 with the share of social services marginally increasing to 35.5. The State
Government is committed for increase in expenditure in the social sector. As per the 2013-14 (RE), the
share of social services in total revenue expenditure has been around 41.0 percent and is budgeted to be
41.05 percent in 2014-15 (BE). The share of expenditure on economic services has also been increasing in
recent years and in 2012-13, its share was 27.3 percent. All these reflect an increasing focus of the Jharkhand
government on social and economic services.

DEBT MANAGEMENT AND MEDIUM TERM DEBT SUSTAINABILITY
The outstanding liabilities of the Government of Jharkhand comprises internal debt of the state, loans and
advances from the Government of India, small savings & provident fund excluding NSSF loans, reserve
funds and other obligations. Internal debt of the state comprises market borrowings of the state government
and borrowing from other financial institutions, Way and Means advances and NSSF loans. The outstanding

<!-- page 13 -->

10

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

liabilities of the Government of Jharkhand for the period 2004-5 to 2012-13 are shown in table 6. Internal
debt is the most important component of the total outstanding liabilities accounting for about 72.48 percent
of the total liabilities of the state in 2012-13.
Table 6: State Government’s Budgetary Borrowings
(Rs. in Crores)
2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

13511.7

17360.1

19417.4

21614.6

24084.0

27165.0

28655.1

30663.8

34768.9

22.61

28.51

29.01

25.75

27.43

27.00

22.51

21.57

21.39

1. Internal Debt

9652.8

13017.8

14422.6

15858.9

17568.2

19880.0

21131.4

22285.8

25201.6

a. Market loans

3317.4

3558.2

3820.0

4740.7

5978.5

7652.3

7850.2

8635.6

11780.6

b. NSSF loans

5402.6

7036.4

8250.5

8375.9

8429.8

9100.0

10056.5

9983.7

9784.2

c. Loan from other
FIs

924.1

2414.3

2343.3

2733.4

3159.9

3127.7

3224.7

3515.2

3636.8

d. Ways & Means

8.9

8.9

8.9

8.9

0.0

0.0

0.0

151.3

0.0

2. Loans & advances
from GoI

2991.8

2846.4

2701.2

2540.3

2404.1

2271.5

2167.2

2024.2

2024.4

3. Small Savings, & PF.

278.0

490.5

719.5

881.4

1081.0

1353.4

1458.1

1527.7

1549.9

4. Reserve Funds

69.1

125.5

282.5

416.0

368.4

681.8

458.6

353.5

230.1

5. Other liabilities

519.9

879.9

1291.6

1918.1

2662.2

2978.3

3439.8

4472.6

5762.9

Outstanding Debt
(as % of GSDP)

The debt management strategy of the Government also maintains debt to GSDP ratio by maintaining the
fiscal parameters within their sustainable levels, thereby, making the debt servicing compatible with the
current revenue and capital receipts over the medium run. The outstanding level of Government debt was
Rs. 34,768.87 crores at the end of the financial year 2012–13, which increased from Rs. 30,663.79 crores
in 2011–12. The current level of debt translates to 21.39 percent of the GSDP in 2012–13. It has, over the
years, declined from its peak of 29.01 percent in 2006–07. The decrease in outstanding liabilities of the
government after 2006-07 was due to decrease in the loans from the Government of India mainly on account
of debts consolidation and debt, write-off facility provided by the 12th Finance Commission. As a result of
this loan write-off and consolidation of all government of India debts and conversion of all these debt into
low interest bearing debts the share of interest payments in the total liabilities of the Jharkhand government
has declined. Loans & advances from the Central Government not only declined in absolute terms between
2004-05 and 2012-13, their share in total liabilities also declined sharply from 22.14 percent to 5.82 percent
during this period.
Judged by the debt related indicators as presented in table 7 (debt to GSDP, interest service to revenue
receipts, debt outstanding to revenue receipts, etc), the level of debt for the Government in 2012-13 at 21.39

<!-- page 14 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

11

percent of the GSDP is considered sustainable, and promises to be within the achievable target of the 27.80
percent as envisaged by the 13th Finance Commission (tables 7 and 8).
Table 7: Trends in Debt Indicators
(Rs. in Crores)

2002-03

Total
Outstanding
Liabilities

Net Debt
incurred
during the
year

Interest
Payment

Total
Revenue
Receipts

Revenue
Deficit/
Surplus

Interest
Payments/
Liabilities

Interest
Payments/
Revenue
Receipts

Debt Outstanding/
GSDP

Revenue
Deficit as per
cent of net
Loan Incurred

8,923.32

1,118.95

1,418.95

4,936.78

-572.7

15.90

28.74

20.36

-51.18

2003-04

10,569.48

1,646.16

1,182.32

5,637.77

231.84

11.19

20.97

20.01

Revenue
Surplus

2004-05

13,511.69

2,942.21

1,141.32

6,660.51

-315.4

8.45

17.14

22.61

-10.72

2005-06

17,360.07

3,848.38

1,419.55

8,463.88

-26.94

8.18

16.77

28.51

-0.70

2006-07

19,417.37

2,057.30

1,613.38

10,009.82

945.88

8.31

16.12

29.01

Revenue
Surplus

2007-08

21,614.58

2,197.21

1,758.03

12,026.35

1,194.38

8.13

14.62

25.75

Revenue
Surplus

2008-09

24,083.98

2,469.40

1,886.88

13,205.88

335.98

7.83

14.28

27.43

Revenue
Surplus

2009-10

27,165.02

3,081.04

2,307.45

15,118.46

-9.78

8.49

15.26

27.00

-0.32

2010-11

28,655.06

1,490.04

2,227.54

18,781.12

836.39

7.77

11.86

24.80

Revenue
Surplus

2011-12

30,663.77

2,008.71

2267.08

22419.45

1427.87

7.39

10.11

23.59

Revenue
Surplus

2012-13

34868.99

4205.22

2391.25

24769.56

1369.69

6.86

9.65

21.45

Revenue
Surplus

Table 8: 13th Finance Commission Proposal and MTFP Targets
(In Percent)
Item

200708

200809

200910

201011

2011-12

Actual Actual Actual Actual Actual

2012-13

13th FC
Proposed

Actual

13th FC
Proposed

Revenue Deficit (RD)/GSDP

1.42

0.38

-0.01

0.66

1.00

0.00

0.84

0.00

Gross Fiscal Deficit (GFD)/
GSDP

-2.31

-3.55

-3.11

-1.66

-1.35

3.00

-2.10

3.00

Outstanding Debt/GSDP

25.75

27.43

27.00

22.51

21.57

28.50

21.39

27.80

Jharkhand Government’s debt management policy takes cognizance of the possible future increases in
payment obligations emerging out of the explicit government guarantees and implicit financial commitments,
typically known as contingent liabilities. No off-budget borrowings under Article 293 of the Constitution of
India were made by the State since 2006–07. The State Government does not take recourse to borrowing for
discharging the repayment liability. The State Government aims at maintaining the debt portfolio to provide
reasonable cost stability over time, by choosing appropriate composition of borrowing sources as well as
maturity.

<!-- page 15 -->

12

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

The State Government has taken steps to reduce the burden of debt servicing on account of interest
payment. The macro focus of the government continues to remain on maintaining the level of debt within
a sustainable level, as recommended by the Thirteenth Finance Commission, and at the same time creating
more fiscal space by way of higher revenue receipts and ensuring efficiency of expenditure use, particularly
dovetailing borrowing for capital outlays. Table 9 presents the year-wise debt relief and interest rate relief on
account of consolidation, as on 31st March, 2010. The debt consolidation was effected from the year 2007-08
consequent to the enactment of Fiscal Responsibility and Budget Management (FRBM) Act in May 2007.
The State Government was able to obtain benefit of debt restructuring by swapping high cost loans and
restructuring of high cost NSSF loans.
Table 9: Year Wise Debt Relief and Interest Rate Relief on Account of Consolidation
Total Debt
Consolidation
2099.10

2007-08

2008-09

2009-10

2007-10

Debt
Relief

Interest
Relief

Debt
Relief

Interest
Relief

Debt
Relief

Interest
Relief

Debt
Relief

Interest
Relief

104.96

81.00

104.96

71.83

104.96

60.81

314.88

213.64

PRIORITIES FOR FISCAL STRATEGY
The Government of Jharkhand enacted the Jharkhand Fiscal Responsibility and Budget Management Act,
2007 on 10th May 2007 for ensuring fiscal stability, debt sustainability, and greater transparency in the fiscal
operation of the Government as recommended by the Twelfth Finance Commission. Under the Act the state
Government was to eliminate Revenue Deficit (RD) by the end of March 2009 and restrict the Fiscal Deficit
(FD) up to 3 percent of the GSDP by March 2009.
The economic recession impacted the finances of several Indian states, through the slowdown in growth
impacting the revenue base, and a fall in the rate of growth of receipts from central taxes. The fiscal correction
path as laid down in the FRBM Act of several Indian states got halted since 2008–09. As countercyclical
measures, the Government was allowed to deviate from the FRBM targets by the Government of India.
Other targets such as revenue and primary deficits were also relaxed in order to allow the state fiscal system
to adapt to the exogenous shocks.
However, the Thirteenth Finance Commission recommended a new and revised roadmap for fiscal
consolidation, thereby, linking all grants and debt relief facilities to the achievement of the targets.
Accordingly, the State government revised some of its key fiscal targets in the FRBM (Amendment) Act,
2011 and 2012 as well as in its Mid-Term Fiscal Plan (MTFP). The revised target laid down in the FRBM
Act, 2011 and 2012 of the state are
i.
ii.
iii.

Reducing its RD to zero at the end of 31 March 2012
Reducing the FD to 3 percent of its GSDP by the end of 31 March 2012, and
Debt-GSDP ratio at 28.5 percent in 2011-12

<!-- page 16 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

13

The State’s FRBM commitments are in line with the Thirteenth Finance Commission targets, which will
be maintained such that the State avails in full the grants and debt relief facilities as recommended by the
Commission. The State has achieved the targets set in the FRBM Act by eliminating the Revenue Deficit
in 2006-07. RD has been in surplus since then with the exception of one year i.e., 2009-10 when the deficit
in RD was only Rs. 9.8 crores. As a percent of the GSDP, the RD increased from a deficit of 0.53 percent in
2004-05 to a surplus of 1.42 percent in 2007-08 and in 2012-13, it was around 0.84 percent of GSDP. The RD
as a percentage of GSDP was budgeted to be 1.85 percent in 2013-14 (BE) and is expected to decrease in the
financial year 2014-15.
As per the recommendations of the Thirteenth Finance Commission, the State Government is required to
reduce its FD-GSDP ratio to 3.0 percent in 2011-12 and thereafter maintain it at that level till 2014-15. The
current trend of FD-GSDP ratio indicates that the State Government has adhered to the fiscal consolidation
path suggested by the Thirteenth Finance Commission. The FD-GSDP ratio was (-) 2.10 percent in 2012-13
and (-) 2.39 percent in 2013-14 (BE).
The improvement in the fiscal scenario of Jharkhand and the fact that it could adhere to its FRBM targets can
be attributed mainly to the State Government’s efforts to raise revenues and not to expenditure contraction.
In per capita terms, the total revenue expenditure of Jharkhand.net of interest payments increased at a
CAGR of 16.25 percent between 2004-05 and 2010-11. In contrast to this, the CAGR of per capita total
revenue expenditure net of interest payments of all states was 15.31 percent during this period.
The Fiscal Strategy for the year 2014-15 and beyond would have the following:
•

The State will continue to pursue a growth oriented fiscal strategy, presently focusing on maintaining a
revenue surplus framework, and broadening the tax base with regard to VAT, excise, motor vehicles tax,
stamps and registration fees and other taxes and non-tax revenues. Continued focus on strengthening
of the tax administration within the Department for Commercial Taxes, supported by the drive for new
registration of dealers, and speedy recovery of dues and disposal of cases.

•

Government’s expenditure management will focus on the rationalization of revenue expenditure,
with monitoring of the non-plan revenue expenditure on account of interest payments, pensions and
administrative services, and increasing the component of capital expenditure content of all sectors.
Expenditure management policy will emphasize on capital outlays, by ensuring commercial viability in
critical sectors such as irrigation, power, transport and departmental undertakings.

•

Government debt management policy will also consider reduction of debt servicing liabilities by
swapping and buying back of the high cost loans, taking full advantage of the debt relief facilities as
provided by the 13th Finance Commission, by maintaining debt sustainability over the medium term
within the amended FRBM targets, and recourse to access the low cost market borrowing options.

<!-- page 17 -->

<!-- page 18 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

15

Form – II

MEDIUM TERM FISCAL PLAN
{See Rule 4 (2)}
(A)

FISCAL INDICATORS – ROLLING TARGETS ASSUMED IN THE MEDIUM TERM FISCAL
PLAN (MTFP)

As per the Rule 4 (2) of the Fiscal Responsibility and Budget Management (FRBM) Act in May 2007 (as
amended in 2010) the State Government is required to lay before the State Legislature, in every financial year
the three years rolling target for fiscal indicators with specifications of the underlying assumptions.
The important fiscal indicators for the three years 2010-11, 2011-12 and 2012-13, the Budgeted figures for
2013-14 as well as rolling targets for the following two years 2014-15 and 2015-16 are shown in thetable
below :Table 10 : Trends in Deficits and Rolling Targets Assumed
Actual

Actual

Actual

Budget
Estimate

Targets for Next Two
Years

2010-11

2011-12

2012-13

2013-14

2014-15

2015-16

Revenue Deficit
(as per cent of GSDP)

0.66

1.00

0.84

-1.85

1.80

2.00

Fiscal Deficit
(as per cent of GSDP)

-1.66

-1.35

-2.10

-2.69

-2.60

-2.40

Primary Deficit
(as per cent of GSDP)

0.09

0.24

-0.62

0.94

0.51

0.53

Total outstanding Liabilities
(as per cent of GSDP)

22.51

21.57

21.39

25.29

25.00

25.50

(B)

ASSUMPTIONS UNDERLYING THE FISCAL INDICATORS

GROSS STATE DOMESTIC PRODUCT (GSDP): The State GSDP at current prices grew from a minimum
of 1.91 per cent in 2005-06 to a maximum of 26.50 percent in 2010-11. Its rate of growth in 2011-12 and
2012-13 is, respectively, 11.69 percent and 14.34 percent. In real terms the growth rate varied from a
minimum of (-)3.20 percent in 2005-06 to a maximum of 20.52 per cent in 2007-08, and in 2011-12 and
2012-13 it has grown at a real rate of 7.17 percent and 7.83 percent, respectively.
However, in the last five years, on an average the growth rate at current prices has been well above 14
percent and in real terms it has been between 7.5 to 8 percent per annum. The part of this variation can be
attributed to variations in rainfall which affects the primary sector significantly and also due to variation

<!-- page 19 -->

16

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

in the secondary or the industrial sector of the state. The GSDP for the last three- four years has, however,
been remarkable in spite of the fact that the rainfall was 30-50 per cent below the normal level. The 13th
Finance Commission estimated GSDP growth rates of 14.50 percent for the years 2012-13 and 2013-14.
The average growth rate of GSDP in constant prices during 2000–01 and 2010–11 (provisional estimate at
constant 2004–05 prices) was 9 per cent per annum for the State of Jharkhand, which comes to be above the
national average which is estimated at above 8 per cent per annum. Therefore a conservative growth estimate
of GSDP at 14 per cent at current prices is presumed for the next few years. This growth is achievable given
the vast potential in the State.
Table 11: Total GSDP at Current and Constant Prices from 2004-05 to 2012-13
(Rs. in Crores)
2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

GSDP at Current
Prices

59757.7

60900.5

66934.8

83949.6

87793.9

100620.7

127281.1

142164.5

162557.1

Growth Rate Over
Previous Year

20.51

1.91

9.91

25.42

4.58

14.61

26.50

11.69

14.34

GSDP at Constant
Prices (2004-05)

59757.7

57848.4

59225.7

71377.1

70129.5

77240.0

89491.1

95912.1

103426.5

Growth Rate over
Previous year

7.75

-3.20

2.38

20.52

-1.75

10.14

15.86

7.17

7.83

1.

REVENUE RECEIPTS
(a)

State’s Own Tax Revenue: There has been a decline in the rate of growth of Own Tax Revenue
of the State since 2010-11. In 2010-11, the own tax revenues grew at 27 percent. However, in
2011-12 and 2012-12, it grew, at 21.6 and 18.3 percent, respectively. The slippage happened
due to less collection in various heads of land revenue and commercial taxes. However, in the
last 5 years, the own tax revenue grew at a CAGR of 18.8 percent. The buoyancy of own tax
revenue during this period has been 1.30. Considering the projected GSDP growth rate of 14
percent during 2013-14 and 2014-15, and assuming the tax buoyancy to remain the same as
1.30, State’s own tax revenues are projected to grow at the rate of 18.20 percent per annum in
the next two years. This rate of growth is achievable given the Government’s consistent efforts
in streamlining the compliance and tax administration system.

(b)

Non–Tax Revenue: State's non-tax revenue collection during 2012-13 was Rs. 3,535.63 crores,
an increase of 16.37 percent over 2011-12. However, the rate of growth of non-tax revenue in
2011-12 over 2010-11 was 8.40 percent. Thus there is a lot of volatility in the growth of nontax revenues. In the last 5 years, the non-taxes grew at a CAGR of more than 17 percent. Given

<!-- page 20 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

17

the volatility in the State’s Own Non-Tax Revenue component, this is projected on an average
to grow at 17.5 percent during 2013-14 and 2014-15.

2.

(c)

Devolution: The 13th Finance Commission has recommended the share of the State of
Jharkhand in sharable taxes (other than service tax) at 2.802 percent of the national total
of the sharable taxes, which is lower than the Twelfth Finance Commission recommended
award of 3.361 percent. Based on the 13th Finance Commission’s estimate, the State will
receive a sum of Rs 406 billion during the award period 2010-15, thus, on an average the State
is expected to receive Rs. 8,120 crores per year. In 2012-13, the share in central taxes has been
Rs. 8188.1 crores, an increase of 33 percent over the previous year’s figures. Since 2010-11 (i.e.,
the 1st year of the award of the 13th Finance Commission), the share in central taxes has been
growing at an annual rate of 32.6 percent. For 2013-14 and 2014-15, we assume devolution to
grow annually at 33 percent.

(d)

Grants from the Centre (State Plan): The State Plan grants from the Centre have been
estimated by considering the loan and grant component separately, thereby, allocating loan
component to be raised from the Open Market Borrowing, as recommended by the 13th
Finance Commission. For the years 2013-14 and 2014-15, a moderate rate of 15 per cent
growth in Centre’s Grant has been assumed. However, in case of Additional Central Assistance
for Externally Aided Projects also, the same level has been assumed for the subsequent years
of projection.

(e)

Grants from Central Government (CSPS & CPS): Both CSPS and CPS grants have been
assumed to grow at 10 per cent over the budget estimates for the year 2012-13 and also for the
subsequent years. However, the expenditure on account of the CSPS and CPS grants has also
been assumed to be equal to the grant received, thereby, making the net effect on the revenue
account as neutral.

CAPITAL RECEIPTS
(a)

Recovery of Loans & Advances – The recovery of loans and advances given by the State
Government was Rs. 44.22 crores in 2007-08, Rs 18.90 crores in 2008-09, Rs. 20.68 crores
2009-10, Rs. 24.12 crores in 2010-11, Rs. 23.42 crores in 2011-12 and Rs. 43.11 crores in 201213. This has been maintained with slight modifications.

(b)

Borrowings – The State Government in projection of the expenditure and the revenue receipts,
has assumed that the Borrowings will not exceed 3 per cent of the GSDP as recommended by
the 13th Finance Commission and the mandate stipulated in the State FRBM Act.

(c)

No other receipt has been assumed on this account by the State Government in the MTFP.

<!-- page 21 -->

18

3.

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

EXPENDITURE
(a)

Revenue Account:
Salary and Pension: The State Government has taken several measures to contain the nonplan revenue expenditure on account of salary and pension liabilities. New recruitments for
various Departments of the Government like Health, Education, Infrastructure Development
and Maintenance of Law and Order etc. are undertaken keeping in the view that the
implementation of plans and programmes are not constrained by shortages of man-power.
Similarly, the Defined Contributory Pension Scheme for all the employees joining on or
after 01.12.2004 will continue. Thus, the State Government is committed to reduce revenue
expenditures without compromising on essential public services.
Interest Payments: Interest payments on all outstanding liabilities were Rs 2,391.25 crores
in 2012-13. Over the years there has been a decline in interest payments as a percentage of
outstanding liabilities of the state. Interest payment as a percent of outstanding liabilities was
8.5 percent in 2009-10 and since then has declined gradually to 6.9 percent in 2012-13. As there
is a limit on the annual borrowings of the state imposed by its fiscal deficit and outstanding
debt targets as per the fiscal correction recommended by the 13th Finance Commission, we
assume that the interest payments as a percent of the state’s outstanding liabilities to gradually
decline to 6.5 percent in 2014-15.
Subsidies: Efforts to limit subsidies will continue. However, given the poverty level in the
State, the Government is committed to provide food subsidy to the underprivileged in the
MTFP.
Maintenance Expenditure – The maintenance of roads and bridges and buildings, grants
for Education and Health Sectors, etc are important. Steps have been taken to keep the levels
of expenditure for these sectors above the recommended level by the Finance Commission,
wherever necessary, in keeping with the actual need as well while projecting the expenditure
in MTFP.
Calamity Relief – The State suffers from recurrent natural calamity such as drought and
hailstorms. As a result it suffers substantial losses. Accordingly provisions have been
made towards State's share of contribution to SDRF in the MTFP in accordance with the
recommendations of the 13th Finance Commission.
Capital Outlay – The total capital outlay was Rs. 3,297.38 crores in the year 2011-12, which
is higher than Rs. 2,791.70 crores in 2010-11. The capital outlays as a percentage of GSDP
constituted 2.3 per cent of the GSDP in 2011-12. In 2012-13, it increased to around 2.9 percent

<!-- page 22 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

19

of the GSDP. Increase in capital expenditure is required so as to boost the productive capacity
of the State’s economy. Capital Outlay as a percentage of GSDP has been budgeted to be 3.9 in
2013-14 (BE).
(C)

ASSESSMENT OF SUSTAINABILITY
The State had a revenue surplus of Rs 1194.58 crores in 2007-08 and Rs 335.99 crores in 2008-09, but
suffered a modest Revenue Deficit of Rs 9.77 crores in 2009-10, due to surge in revenue expenditure
and recovered the next year. The Revenue Deficit was in surplus again in 2010-11 and has been in
surplus since then. In 2012-13 it was Rs. 1369.69 crores and Rs. 3163.82 crores in 2013-14 (BE). It
is expected that with revenue buoyancy supported by enhanced transfers under the 13th Finance
Commission recommendations the State will have surplus in future years.
The outstanding liabilities of Jharkhand as a percent of its GSDP were 21.39 percent in 2012-13. The
13th Finance Commission had recommended a path for reducing outstanding liabilities during its
award period. As a result, the liabilities of the state are expected to further come down in 2013-14
and 2014-15. This will help in keeping the interest payment component under non-plan revenue
expenditure under control.
Overall the fiscal deficit is projected at 3 per cent of the GSDP in 2013-14 and 2014-15, respectively.
As the State of Jharkhand suffers from poor infrastructure and considering the need to support the
growth of the industrial and the tertiary sectors, it is prudent to increase the capital expenditure. The
fiscal deficit has been maintained below 3 percent level after giving boost to capital outlays from 2.3
percent of the GSDP in 2011-12 to 2.9 percent in the next year.

<!-- page 23 -->

<!-- page 24 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

21

FORM-III

DISCLOSURE STATEMENT
{See Rule -6)
There is no significant change in the accounting standards, policies and practices during the Financial Year
2013-14. However, since the year 2014-15, following changes are being undertaken:
•

The “Others” head has been further sub-divided and specified:

•

Medical reimbursement, which earlier was a part of the salary, has now been kept under a separate unit

•

The arrear after the creation of the state, which earlier was a part of the salary, has been kept under a
separate unit

•

The TA being given to retired persons is also put separately

•

Pension, before the creation of the state and after the creation of the state, has also been kept under a
separate unit

This sub-division into separate heads has made the work of monitoring easier.
•

Capital expenditure and revenue expenditure has been centrally locked.

<!-- page 25 -->

<!-- page 26 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

23

FORM-IV

DISCLOSURE STATEMENT
(See Rule-7)
There is no significant change in the accounting standards, policies and practices during the Financial Year
2012-13.
NON-PLAN
DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

TOTAL

Demand No: 1 -Agriculture Department
1

2401

1651

25292721

28851414

1365000

5342770

60851905

1

2402

329

6321280

6665073

2380000

788409

16154762

1

2415

41

806258

918815

0

166628

1891701

1

2435

40

709141

816001

0

150914

1676056

1

3451

61

1433065

1664319

0

441899

3539283

1

3475

54

1096610

1184622

0

160445

2441677

2176

35659075

40100244

3745000

7051065

86555384

Total
Demand No: 2 - Animal Husbandary Department
2

2403

2469

39795815

42442961

5844192

6264090

94347058

2

3451

18

520350

564849

100000

99794

1284993

2487

40316165

43007810

5944192

6363884

95632051

Total
Demand No: 3 -Building Construction Department
3

2052

9

280180

311410

0

76036

667626

3

2059

1191

25209248

27775099

9986500

5000485

67971332

1200

25489428

28086509

9986500

5076521

68638958

Total

Demand No: 4- Cabinet Secretariat & Co- Ordination department
4

2013

115

1996794

2118474

200000

804574

5119842

4

2052

99

1863480

2016300

601000

385325

4866105

4

2070

15

405350

444941

1000

96079

947370

4

2205

11

199160

216258

675000

50307

1140725

240

4464784

4795973

1477000

1336285

12074042

Total

<!-- page 27 -->

24

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

TOTAL

Demand No.-5- Secretariat of the Governor
5

2012

Total

140

2126860

2206754

0

435070

4768684

140

2126860

2206754

0

435070

4768684

264

4207315

4479417

100000

592395

9379127

264

4207315

4479417

100000

592395

9379127

226

4328620

4752562

0

1326141

10407323

226

4328620

4752562

0

1326141

10407323

Demand No: 6- Election Department
6

2015

Total
Demand No: 7- Vigilance Department
7

2070

Total
Demand No: 8- Civil Aviation Department
8

2070

7

184325

199422

0

27010

410757

8

3053

9

151925

167081

0

33963

352969

16

336250

366503

0

60973

763726

Total
Demand No: 9- Co-operative Department
9

2425

946

18460287

19726455

4387023

3076293

45650058

9

3451

72

1350570

1540749

0

411009

3302328

1018

19810857

21267204

4387023

3487302

48952386

Total
Demand No: 10- Energy Department
10

2045

21

343770

383223

0

96929

823922

10

2059

222

3034920

3339558

0

804806

7179284

10

2801

0

0

0

0

0

0

10

3451

3

136690

143526

0

14176

294392

246

3515380

3866307

0

915911

8297598

Total
Demand No: 11-Excise and Prohibitation Department
11

2039

398

6390840

6979603

0

1285115

14655558

11

2052

7

344910

368877

0

39438

753225

405

6735750

7348480

0

1324553

15408783

Total
Demand No: 12-Finance Department
12

2052

553

12082700

13074137

0

2413670

27570507

12

2054

288

5684287

6099553

0

832469

12616309

12

2058

40

491660

541026

170000

116983

1319669

881

18258647

19714716

170000

3363122

41506485

Total

<!-- page 28 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

25

TOTAL

Demand No: 16 - National Savings Department
16

2047

Total

57

946704

1004960

0

175394

2127058

57

946704

1004960

0

175394

2127058

Demand No: 17 -Finance (Commercial Tax) Department
17

2040

1342

26325790

28638325

0

6290103

61254218

17

2052

35

966720

1058737

0

225680

2251137

1377

27292510

29697062

0

6515783

63505355

Total

Demand No: 18 - Food Supply and Commerce Department
18

3451

35

911155

986534

0

190311

2088000

18

3456

647

11765314

11935470

0

1421945

25122729

682

12676469

12922004

0

1612256

27210729

Total
Demand No: 19- Forest & Environment Department
19

2406

3785

75960425

80232229

36200000

7666441

200059095

19

3451

57

1296300

1410677

1171704

307610

4186291

3842

77256725

81642906

37371704

7974051

204245386

Total

Demand No: 20-Health, Medical Education and Family Welfare Department
20

2210

11057

222131202

235530625

916602500

32707737

1406972064

20

2211

6302

46662210

49175092

22822000

6588909

125248211

20

2251

28

903790

983000

1300000

189304

3376094

17387

269697202

285688717

940724500

39485950

1535596369

12

388350

420368

0

93795

902513

12

388350

420368

0

93795

902513

Total
Demand No: 21 - Higher Education Department
21

2202

Total
Demand No: 22 - Home Department
22

2052

138

3261440

3561859

0

806714

7630013

22

2055

220004

2674750474

2917544441

94033738

837601544

6523930197

22

2056

542

8105852

8821112

0

1385798

18312762

22

2070

656

9363330

10268304

15087176

2312192

37031002

22

2235

101

1586220

1682761

0

254228

3523209

221441

2697067316

2941878477

109120914

842360476

6590427183

Total

<!-- page 29 -->

26

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

TOTAL

Demand No: 23- Industry Department
23

2851

595

9283900

9863198

4647000

1444742

25238840

23

2852

112

2262220

2436241

642000

430879

5771340

23

3451

42

911615

997518

0

217096

2126229

749

12457735

13296957

5289000

2092717

33136409

Total

Demand No: 24- Information and Public Relation Department
24

2220

219

4782548

5144316

0

1133907

11060771

24

2251

8

228178

247987

0

56036

532201

227

5010726

5392303

0

1189943

11592972

Total

Demand No: 25- Institutional Finance & Programme Implementation Department
25

2052

Total

20

462410

504016

0

97390

1063816

20

462410

504016

0

97390

1063816

Demand No: 26- Labour, Employment and Training Department
26

2210

228

4863938

5297399

0

1166877

11328214

26

2230

1435

31457641

34591675

300000

6971226

73320542

26

2235

317

6347800

6673592

0

756778

13778170

26

2251

36

817062

883120

0

175244

1875426

2016

43486441

47445786

300000

9070125

100302352

Total
Demand No: 27- Law Department
27

2014

13730

217136693

227893055

14608000

15421304

475059052

27

2052

52

1247972

1346075

1500000

315137

4409184

13782

218384665

229239130

16108000

15736441

479468236

1152

22518960

24545863

1200000

4927467

53192290

1152

22518960

24545863

1200000

4927467

53192290

Total
Demand No: 28 -Jharkhand High Court
28

2014

Total
Demand No: 29- Mines and Geology Department
29

2853

419

7971839

8582998

0

1607947

18162784

29

3451

17

342132

373520

0

88051

803703

436

8313971

8956518

0

1695998

18966487

Total

<!-- page 30 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

27

TOTAL

Demand No: 30- Minority Welfare Department
30

2250

3

126832

134853

0

31666

293351

30

2251

26

344658

369032

0

181652

895342

29

471490

503885

0

213318

1188693

6

113850

124583

100000

29520

367953

6

113850

124583

100000

29520

367953

1261

18618010

15952918

0

6317924

40888852

1261

18618010

15952918

0

6317924

40888852

Total
Demand No: 31- Parliamentary Affairs
31

2052

Total
Demand No: 32 Jharkhand Assembly
32

2011

Total

Demand No: 33 Personnel and Administrative Reforms Department
33

2051

11

358788

384289

0

52552

795629

33

2052

143

2976130

3263552

0

584554

6824236

33

2070

187

2081820

2255225

0

294594

4631639

33

2220

14

441330

472638

0

82366

996334

355

5858068

6375704

0

1014066

13247838

37

908749

981905

0

199303

2089957

37

908749

981905

0

199303

2089957

Total
Demand No: 34- Jharkhand Public Service Commisssion
34

2051

Total
Demand No: 35- Planning and Development Department
35

2052

62

1562253

1699168

0

355753

3617174

35

2053

71

2067664

2187011

0

278392

4533067

35

3454

302

6697980

7211805

0

1249613

15159398

435

10327897

11097984

0

1883758

23309639

3458

53769600

57584156

0

7631696

118985452

3458

53769600

57584156

0

7631696

118985452

Total

Demand No: 36-Drinking Water and Sanitation Department
36

2215

Total
Demand No: 37-Rajbhasha Department
37

2052

18

309700

339888

0

56918

706506

37

2053

309

5796550

6108227

3662560

745594

16312931

37

2070

1

19860

21693

154666

5072

201291

328

6126110

6469808

3817226

807584

17220728

Total

<!-- page 31 -->

28

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

TOTAL

Demand No: 38-Registration Department
38

2030

Total

187

3171566

3502768

0

575501

7249835

187

3171566

3502768

0

575501

7249835

34

874620

951117

0

201774

2027511

34

874620

951117

0

201774

2027511

Demand No: 39-Disaster Management Department
39

2235

Total
Demand No: 40-Revenue and Land Reform Department
40

2029

4610

77576520

84845172

18300000

13043742

193765434

40

2052

289

5569160

6045025

0

1094280

12708465

40

2053

2189

36060700

38933895

0

5282000

80276595

40

2070

35

402540

452070

0

99953

954563

40

3454

1

11970

13409

0

3569

28948

40

3475

6

147460

160713

0

29669

337842

7130

119768350

130450284

18300000

19553213

288071847

Total
Demand No: 41-Road Construction Department
41

3054

4360

91814789

99136206

11686143

14817336

217454474

41

3451

17

585860

657157

1675000

147826

3065843

41

5054

8

231680

256706

0

64616

553002

4385

92632329

100050069

13361143

15029778

221073319

Total
Demand No: 42-Rural Development Department
42

2501

0

0

0

0

0

0

42

2505

0

0

0

0

0

0

42

2515

3159

65759160

69056361

960000

5161500

140937021

42

3451

77

1759420

1904952

0

423482

4087854

42

4515

0

0

0

0

0

0

3236

67518580

70961313

960000

5584982

145024875

Total
Demand No: 43-Science and Technology Department
43

2203

712

13464423

14738686

7955000

2432773

38590882

43

3451

6

236450

254994

200000

49190

740634

718

13700873

14993680

8155000

2481963

39331516

Total

<!-- page 32 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

29

TOTAL

Demand No: 44-Middle, Primary and Public Education Department
44

2202

27

566728

601363

0

89011

1257102

44

2205

13

190239

205210

0

41912

437361

44

2251

61

1661814

1804545

0

411566

3877925

101

2418781

2611118

0

542489

5572388

Total
Demand No: 45-Information Technology Department
45

2203

1

7430

8222

0

2261

17913

45

3451

17

535650

575033

89452

109446

1309581

18

543080

583255

89452

111707

1327494

Total
Demand No: 46-Tourism Department
46

3451

15

415170

452730

390584

91134

1349618

46

3452

42

769468

843233

0

194112

1806813

57

1184638

1295963

390584

285246

3156431

Total
Demand No: 47- Transport Department
47

2041

234

4427560

4761501

0

992850

10181911

47

3451

24

564360

614838

0

112757

1291955

258

4991920

5376339

0

1105607

11473866

Total
Demand No: 48- Urban Development Department
48

2217

21

452560

497029

0

90512

1040101

48

2251

43

1301730

1416379

0

320356

3038465

64

1754290

1913408

0

410868

4078566

Total
Demand No: 49-Water Resources Department
49

2700

6388

115772770

128366325

159918104

28793121

432850320

49

2701

7228

143009344

152805887

175976340

25821522

497613093

49

3451

134

2865410

3156103

3988000

742483

10751996

13750

261647524

284328315

339882444

55357126

941215409

3364

67980029

73480743

94681370

13730940

249873082

3364

67980029

73480743

94681370

13730940

249873082

Total
Demand No: 50- Minor Irrigation Department
50
Total

2702

<!-- page 33 -->

30

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

BASIC PAY

DA

ARREAR

OTHERS

TOTAL

Demand No: 51-Welfare Department
51

2225

2341

40354126

42835102

0

6291360

89480588

51

2251

51

1255164

1361605

0

291545

2908314

2392

41609290

44196707

0

6582905

92388902

Total
Demand No:52- Art, Culture and Youth Department
52

2204

189

2936081

3224847

0

774402

6935330

52

2205

42

636170

696125

1246200

160688

2739183

52

2251

33

640340

697988

0

162878

1501206

264

4212591

4618960

1246200

1097968

11175719

207

3801972

3917672

0

648757

8368401

207

3801972

3917672

0

648757

8368401

190

3468030

3702757

3050000

612060

10832847

190

3468030

3702757

3050000

612060

10832847

Total
Demand No: 53- Fisheries Department
53

2405

Total
Demand No: 54- Dairy Department
54

2404

Total
Demand No: 55-Rural Works Department
55

2505

187

4403500

4667775

0

479233

9550508

55

2515

1604

23183190

24380171

0

4927984

52491345

55

3451

24

670620

731035

0

155408

1557063

55

4515

1164

27441990

29470140

0

3676185

60588315

2979

55699300

59249121

0

9238810

124187231

Total

Demand No: 56-Panchayati Raj and N.R.E.P.(special division) Department
56

2015

41

645520

702579

0

164404

1512503

56

2515

3227

50935365

54901739

0

9956439

115793543

56

3451

14

449418

488689

0

92295

1030402

3282

52030303

56093007

0

10213138

118336448

7

218380

235179

0

35276

488835

7

218380

235179

0

35276

488835

Total
Demand No: 57-Housing Department
57
Total

2251

<!-- page 34 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

DEMAND NO

MAJOR CODE

WORK_STRENGTH

ARREAR

OTHERS

31

BASIC PAY

DA

TOTAL

9614

212681406

225317473

8141559

31448614

477589052

9614

212681406

225317473

8141559

31448614

477589052

61705

1288089063

1353333099

0

148239550

2789661712

61705

1288089063

1353333099

0

148239550

2789661712

Demand No: 58- Secondary Education Department
58

2202

Total
Demand No: 59-Primary Education Department
59

2202

Total

Demand No: 60- Social Welfare, Women and Child Development Department
60

2235

97

1698266

1849124

0

391313

3938703

60

2251

28

747309

814496

0

175381

1737186

Total

125

2445575

2663620

0

566694

5675889

Grand Total

392398

5958898875

6404539496

1628098811

1305937749

15297474931

<!-- page 35 -->

<!-- page 36 -->

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

33

Form -V

STATEMENT OF DEFERRED LIABILITIES
(See Rule-8)

While presenting the Annual Budget for the current year, the State Government shall furnish statement
showing the deferred liabilities on the following accounts:i)

State’s matching share
State’s matching share under Centrally Sponsored Plan schemes (CSS) has been adequately
provided. In the year 2013-14, Rs. 1269.9 crores has been provided as state’s matching contribution
to CSS.

ii)

Bills presented in the treasury but not en-cashed:
As on 31.03.2013 bills presented in the Treasury but not en-cashed are Nil.

iii)

Central Assistance received but not utilized at the end of a particular financial year.
As per the information provided by various Administrative Departments, out of the Central
Assistance received up to 31.03.2013, the Utilization Certificates pending as on 31.03.2013 were
Rs. 3622.52 crores; Rs. 1895.77 crores of the Central Assistance to State Plans and Rs. 1726.75 crores
of the received . The Utilization Certificates pending in respect of Central Assistance received
during 2013-14 are being utilized along with unutilized Central Assistance.

iv)

Un-disbursed amount lying in the Civil Deposits.
The closing balance of Civil Deposit forms a part of deferred liability of the State Government.
In terms of the note below the Rules No. 300 of Jharkhand Treasury Code, money should not be
drawn from the treasury simply on the ground that the charges have been sanctioned by competent
authority, nor is it permissible to draw money from the Treasury and then to place it in Deposit in
order or avoid lapse of allotment.
Further, Rule 535 of the said Code directs that no money shall be received for deposits in the Public
Accounts unless they are such as by virtue of any statutory provision or of any general or special
orders of the government.
Accordingly, within the ambit of the said rules, transfer of Budgeted funds to Civil Deposit distorts the
total expenditure reflected in the accounts, the Finance Department has issued several instructions
in 2004-05, 2005-06, 2006-07 and 2007-08 prohibiting such transfers.

<!-- page 37 -->

34

FISCAL POLICY STRATEGY STATEMENT AND
MEDIUM TERM FISCAL PLAN

The transfer of Budgeted funds to Civil Deposit is declining from the year 2002-03 as may be seen
from the table below :Table 12: Statement showing details of amount kept under 8443-Civil Deposits
(Rs. in Crores)

Year

Opening Balance

Deposit

Withdrawal

Closing Balance

2002-03

130.14

363.83

315.83

178.14

2003-04

178.14

252.62

257.38

173.38

2004-05

173.38

213.19

134.21

252.36

2005-06

252.36

473.41

229.21

496.56

2006-07

496.56

396.56

307.52

585.60

2007-08

585.60

732.19

459.59

858.20

2008-09

858.20

1,319.46

743.87

1,433.80

2009-10

1,433.80

575.33

583.72

1,425.41

2010-11

1,425.41

1,072.54

887.48

1,610.46

2011-12

1,610.46

1,564.38

1,001.91

2,172.93

2012-13

2172.93

1754.05

1221.49

2705.49

Releases from Civil Deposit are being regulated by instructions issued by the Finance Department from time
to time based on actual requirement at a particular point of time and preparedness of the field functionaries
for spending the money.

<!-- page 38 -->

707_(02-14) Annapurna Press

0651-2331800
