---
doc_id: "d2031ebcce25cd1d"
source_url: "https://cdn.s3waas.gov.in/s310a7cdd970fe135cf4f7bb55c0e3b59f/uploads/2026/04/17759061024862.pdf"
ministry: "Garhwa"
title: "01_2026-27_Sairat_Bandobasti_ SBNagar_Corrigendum (375 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8b588e80944ba884"
---

<!-- page 1 -->

01/2026-27

f¢

15.04.2026 (yato 4100 go

fi# 15.04.2026 (3r40 03.0o qu )

IİG 3../fio 10.04.2026
yfafetfy :

aftferft -

yfaffy
yfaftfy

H40 02.00

T)
