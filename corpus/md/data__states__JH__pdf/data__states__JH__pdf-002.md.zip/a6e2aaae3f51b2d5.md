---
doc_id: "a6e2aaae3f51b2d5"
source_url: "https://tourism.jharkhand.gov.in/cms/Application/uploadDocuments/Tender/Tender_RFP_20250304_171529.pdf"
ministry: "Tourism Department, Jharkhand"
title: "TENDER DOCUMENT/RFP"
date: ""
pages: 26
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c2d52ff1857c7486"
---

<!-- page 1 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

RFP No:- 284 /

Dated:-04/03/2025

REQUEST FOR PROPOSAL (RFP)
FOR
SELECTION OF AN AGENCY FOR DESIGN, SUPPLY,
INSTALLATION, OPERATION AND MAINTENANCE, SUPPORT FOR
INTERACTIVE DIGITAL TOUCH SCREEN SMART KIOSK AT
DESIGNATED LOCATIONS FOR JHARKHAND TOURISM
BRANDING & PROMOTION (Call-3)

Directorate of Tourism
Govt. of Jharkhand
Department of Tourism, Art Culture, Sports and Youth Affairs
MDI Building, 2nd Floor, Dhurwa, Ranchi-834004Phone:(0651)2400493,
email:dirjharkhandtourism@gmail.com, Web:https://tourism.jharkhand.gov.in

1

<!-- page 2 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

CONTENT
1

INTRODUCTION .............................................................................................................. 5

2

SCOPE OF WORK ............................................................................................................ 5

3

DELIVERABLES, TIMELINES AND PAYMENT SCHEDULE ................................. 10

4

SUGGESTED LOCATION TO DISPLAY THE KIOSK ............................................... 11

5

TECHNICAL MINIMUM ELIGIBILITY CRITERIA. .................................................. 12

6

FINANCIAL PROPOSAL EVALUATION .................................................................... 13

7

TENDER FEE .................................................................................................................. 14

8

EMD (EARNEST MONEY DEPOSIT)........................................................................... 14

9

PERFORMANCE SECURITY FEE ................................................................................ 14

10 FORCE MAJEURE .......................................................................................................... 14
11 TERMINATION OF THE CONTRACT ......................................................................... 15
12 PENALTY ........................................................................................................................ 15
13 VALIDITY OF BID ......................................................................................................... 15
14 CURRENCIES OF BID AND PAYMENT ..................................................................... 16
15 DISPUTES........................................................................................................................ 16
16 ACKNOWLEDGMENT BY AGENCY .......................................................................... 16
17 RIGHT TO REJECT ANY OR ALL PROPOSALS ........................................................ 16
18 SUBMISSION OF PROPOSAL- PACKING, SEALING & MARKING ....................... 16
19 AMENDMENT/ MODIFICATION ................................................................................. 18
20 LATE SUBMISSION ....................................................................................................... 18
21 CONSORTIUM / JOINT VENTURE .............................................................................. 18
22 MODIFICATIONS AND WITHDRAWAL OF PROPOSALS ...................................... 18
ANNEXURE -1 LEGAL ENTITY OF AGENCY .................................................................. 19
ANNEXURE -2 NOT BLACKLISTED .................................................................................. 20
ANNEXURE -3 SIMILAR WORK EXPERIENCE ............................................................... 21
ANNEXURE -4 ANNUAL TURNOVER............................................................................... 22
ANNEXURE-8 PRE BID QUERY FORMAT........................................................................ 23
ANNEXURE-9 UNDERTAKING .......................................................................................... 24
ANNEXURE-10 FINANCIAL PROPOSAL .......................................................................... 25

2

<!-- page 3 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

Disclaimer
The information contained in this RFP document or subsequently provided to Agency(s)
whether verbally or in documentary form by or on behalf of the Department of Tourism,
Government of Jharkhand or any of their employees or advisors, is provided to the Agency(s)
on the terms and conditions set out in this RFP Document and all other terms and conditions
subject to which such information is provided.
This RFP Document is not an agreement and is not an offer or invitation by the Tendering
Authority to any party other than the Agency who are qualified to submit the Bids
(“Agency”). The principle of this RFP Document is to provide the Agency(s) with
information to support the formulation of their Proposals. This RFP Document does not
purport to contain all the information each Agency may entail. This Document may not be
apposite for all persons, and it is not possible for Tendering Authority, its employees, or
advisors to consider the investment objectives, financial situation, and needs of each Agency
who reads or uses this RFP Document. Each Agency should conduct its own investigations
and analysis and should check the accuracy, reliability and completeness of the information
in this Document and where necessary obtain independent advice from appropriate sources.
The Tendering Authority, its employees and advisors make no representation or warranty and
shall incur no liability under any law, statute, rules or regulations as to the accuracy,
reliability or completeness of this Document. The Tendering Authority may in its absolute
discretion, but without being under any obligation to do so, update, improve or supplement
the information in this RFP Document.

3

<!-- page 4 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

Schedule of RFP Process
Department of Tourism (DoT) invites Proposals for “Selection of an Agency for Design,
Supply, Installation, Operation and Maintenance, Support for Interactive Digital Touch
Screen Smart Kiosk at Designated Locations for Jharkhand Tourism Branding &
Promotion for Jharkhand Tourism”
Interested firms/ parties / agencies are advised to download and study the RFP document
carefully and must satisfy all eligibility conditions stated in this document in this regards
from Department of Tourism website in the link below:
https://tourism.jharkhand.gov.in/tender
Table 1
Important Dates and Information
Office of Issue

Directorate of Tourism Govt. of
Jharkhand

Date of Issue
Last date and time for submission of bid

04.03.2025
20.03.2025 11:00 AM

Date and time for bid opening

20.03.2025 11:30 AM

Venue:

Directorate of Tourism Govt. of Jharkhand,
MDI Building, 2Nd Floor, Director Tourism
Office

Bid Reference Number

4

<!-- page 5 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

1 INTRODUCTION
1.1 Department of Tourism, Government of Jharkhand (hereinafter referred to as “DoT” or
“Authority” or “Department”) aims to develop Jharkhand as one of most preferred
tourist destinations in India. Concerted efforts are being put in place by DoT to position
the state prominently in the domestic and international tourist source markets. In this
background, DoT has decided to enhance its presence and expand its digital footprint in
promoting the tourism potential of the state with the global and regional tourists in a
holistic manner.
1.2

Accordingly, DoT intends to appoint an agency (hereinafter referred to as “Agency”)
for Design, Supply, Installation, Operation and Maintenance, Support for Interactive
Digital Touch Screen Smart Kiosk at Designated Locations for Jharkhand Tourism
Branding & Promotion for a period of Two (2) years (hereinafter referred to as
“contract duration”). Extend for an additional two (2) years on a year-on-year basis,
subject to satisfactory performance.

2 SCOPE OF WORK
2.1 Design and Customization:
2.1.1 Develop interactive digital touch screen smart kiosks customized that helps
Jharkhand Tourism branding and awareness.
2.1.2 Design user-friendly interfaces and intuitive navigation systems for seamless
user interaction with a customized Jharkhand tourism-specific digital map
'Make in India'. Incorporating necessary MAP APIs.As
2.1.2.1 Dynamic Maps
2.1.2.2 Directions Maps
2.1.2.3 Places Details
2.1.2.4 Place Nearby Search
2.1.3

Incorporate multimedia content, including images, videos, text, and VR
Setup to showcase tourist attractions, cultural heritage sites, and other points
of interest within Jharkhand, content, images, videos, Site Information and
VR device Directorate of Tourism will give.
Table 2
Features and Benefit

#

Features

Benefit

1

Interactive
Kiosk

Bidder has to supply a simple, easy to use solutions not only gives
recognition but also cultivate loyalty and add speed & efficiency.

2

Discovery

Bidder has to provide the implementation of Digital Experience
Platform; visitors can be presented with a fully interactive overview
of all Accommodation and information. This interface allows users
to browse, search or choose their content.
5

<!-- page 6 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

3

Educate
Visitors

Communicating all the information to customers. By implementing
Digital Experience Platform, the Marketing team can present all upto-date information without technical hassle through CMS to
Visitors. Such information could be –
1. Virtual display of Hotels, Events, Tourism Sites, Rout & Map etc.
2. Offers & Promotions
3. FAQs, Key Contacts, etc.

4

Feedback
system

Bidder should provide a great way to incorporate customer surveys
and get real public feedback about the product, customer support etc
and identify their needs as compared to paper based
feedback/survey. Having satisfied customers is arguably the best
ROI you could ask for.

5

Way
finding

Bidder must provide the implementation of Digital Experience
Platform. Hence can be presented with a fully interactive overview of
the entire space all with a clear indication of "you are here." This
interface can allow users to choosewhat visitor spots they are looking
for. The platform can then display the quickest route to that location.
Customized tourism specific map.

6

Communica With auto-updating in no time, hotel teams can easily communicate
tion
with their guests by displaying banners for any message.

2.2

FEATURESLIST :-Bidder must have Software Solution proposes following modules
for complete digital experience

Table 3

Functional Feature List
#

Features

Details

1

Dynamic pages
creation

Admin can create any group, subgroup, pages and link with any
kind of hierarchy. Creation of pages can be done from Admin
CMS. Each page or group can have images, banners, text, video,
tables, links etc. CMS admin can add/edit/delete any of the info.

2

Search/filter

Users can search the whole Kiosk, Tourist Destinations,
Accommodation unit etc. by any keyword and he can also filter
results by his choice/preference.

6

<!-- page 7 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

3

Enquiry/Survey

We provide admin an option to create any number forms which
can be used for getting user feedback, ask a query, conduct any
survey etc. Once an admin createsa form, he can connect the
form with any of the pages. On Kiosk users, see that form to
quick fill. Admin get all those responses from CMS and can reply
to any response.

4

Add references

Admin has an option on CMS to add any links on any page. This
could be any website page, pdf, social media page, Google map
link etc.

5

Image gallery

Admin can add any number of images in any product with a
caption. This helps users to create an image gallery or quickly
understand that page or testimonial, etc.

6

Offline
availability of
content

All Kiosks sync data from the server and store content locally to
run offline also. This is again a most important features Kiosks
may not have internet access. It auto checks any update on the
server and only downloads incremented data upon use so users
do not need to wait for Kiosk content.

7

Video

Admin can upload videos on app/web App. Each Video min. 35
MB is allowed to upload.

8

ExportImport

For bulk uploading on data having features of export and import.

9

Kiosk Information Agency has to develop a section in which Admin can see the all
device functioning/Non-functioning status, Active and damage
device condition in admin dashboard.

10

MIS Report

2.3

2.4

All type of MIS report need to display in admin section, related to
kiosk, How many people are using which device, to search for
what, Visitors report & feedback etc.

Supply and Procurement by selected agency:
2.3.1 Procure all necessary hardware components, including touch screen displays,
interactive panels, processors, and connectivity devices.
2.3.2 Source software applications, licenses, and content management systems
required for kiosk operation and content delivery.
2.3.3 Ensure compliance with relevant industry standards, technical specifications,
and safety regulations for digital signage and interactive kiosk systems.
Space Allocation and Manpower supply:
2.4.1 Availability of space at airport, railway station or any other place suggested
by the department will be the responsibility of the agency. In this regard, the
DoT can provide the required documents to the agency for allotment of
space. However, the entire responsibility including payment for this will be
of the agency.

7

<!-- page 8 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

2.4.2

The agency has to provide 2manpower for 16 hours (8 hours shift each) at
railway station and airport for kiosk safety, security and VR Device (VR
Device provided by DoT) handling.
2.4.3 For the safety of the kiosk installed at the railway station, its outer body
should be made of metal or it should have a metal cover or there should be
some such arrangement so that it cannot be damaged easily
2.4.4 The Directorate of Tourism will reimburse the space rent on monthly as
per actual invoice basis. Agency have to submit monthly maintenance bill,
manpower salary and actual bill of the space rent.
2.5 Installation and Deployment:
2.5.1 Agency should conduct site surveys and assessments to identify suitable
locations for smart kiosk deployment as per location suggested by directorate
of tourism.
2.5.2 Prepare installation plans and layouts, considering factors such as visibility,
accessibility, internet facility and power supply requirements.
2.5.3 Install and configure smart kiosks at designated locations, ensuring proper
mounting, connectivity, and integration with existing infrastructure.
2.6 Operation and Management:
2.6.1 Manage day-to-day operations of smart kiosks, including content updates,
software maintenance, and system monitoring.
2.6.2 Implement remote monitoring tools and protocols to track kiosk
performance, uptime, and user interactions.
2.6.3 Provide technical support and troubleshooting assistance to users, addressing
inquiries, issues, and feedback in a timely manner.
2.7 Maintenance and Support:
2.7.1 Establish regular maintenance schedules and protocols to ensure the ongoing
functionality and reliability of smart kiosks.
2.7.2 Conduct preventive maintenance activities, such as hardware inspections,
software updates, and cleaning procedures.
2.7.3 Offer helpdesk support services, including remote assistance, on-site repairs,
and replacement of faulty components as needed.
2.8 User Engagement and Feedback:
2.8.1 Develop interactive features and engagement tools to encourage user
participation and feedback collection.
2.8.2 Analyse user metrics, usage patterns, and feedback data to optimize kiosk
content, usability, and effectiveness.
2.8.3 Implement mechanisms for user surveys, ratings, and reviews to gather
insights and improve the overall user experience.
2.9 Reporting and Performance Metrics:
2.9.1 Generate regular reports and performance metrics to track key performance
indicators (KPIs) related to kiosk usage, engagement, and impact, monthly
report send to directorate.
2.10 Compliance and Quality Assurance:
2.10.1 Conduct quality assurance checks and audits to maintain high standards of
performance, security, and usability for smart kiosk deployments.
2.10.2 Agency fully responsive for any faulty related to kiosk deploy hardware,
software any kind of hacking etc.
8

<!-- page 9 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

2.11 Collaboration and Coordination:
2.11.1 Coordinate with local authorities, vendors, and service providers to facilitate
smooth execution of installation, maintenance, and support activities.
2.12 Documentation and Knowledge Transfer:
2.12.1 Maintain comprehensive documentation, including user manuals, technical
specifications, maintenance logs, and operational procedures for smart kiosk
systems.
2.12.2 Facilitate knowledge transfer sessions and training workshops for Jharkhand
Tourism staff and stakeholders to ensure effective utilization and
management of smart kiosk assets.
2.13 Innovation and Continuous Improvement:
2.13.1 Stay abreast of emerging technologies, trends, and best practices in
interactive digital signage and tourism promotion to drive innovation and
continuous improvement.
2.13.2 Proactively propose enhancements, upgrades, and new features to enhance
the functionality, relevance, and impact of smart kiosk deployments over
time.
2.14 Technical Specification for Interactive Digital Smart Kiosk
Memory Storage
RAM Size
Operating System
Hardware Interface
Response Time
Resolution
Special Features
Standing screen display size
Display Type
Image Aspect Ratio
Supported Video, Images types
Resolution
Audio output mode
Speaker Surround Sound Channel
Configuration
Audio Wattage
Voltage
Wattage
Power Source
Refresh Rate
Total USB ports
Connector Type
Supports Bluetooth Technology



6‎ 4 GB (Minimum)
‎6BG (Minimum)
‎diArdnA
‎
IMDH
‎,BSG
‎not more than 8 Milliseconds
‎not less than 4K
‎talF
‎Vertical kiosk 55 Inches
‎DEM
‎9:61 approx.
‎
GGEB
‎,GNB, MPEG-4, mp4, MPEG1, MPEG2, AVI,
m2ts, mkv, MOV, .ts
‎
GnxxaP
‎09:3x0483 (Minimum)
‎SFxrxd
‎Adaod
‎slFFP‎03
‎
sdaFP
‎903
‎
slFFP
‎03
‎cdrAxA‎EaxCFrnC
‎ ‎:303
IH
‎0(Minimum)
‎ -sn
tn
‎sxP

Note: This Scope of Work outlines the responsibilities, deliverables, and expectations for the
selected agency in designing, supplying, installing, operating, maintaining, and supporting
interactive digital touch screen smart kiosks for Jharkhand Tourism branding & promotion.

9

<!-- page 10 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

3 DELIVERABLES, TIMELINES AND PAYMENT SCHEDULE
3.1 The selected agency shall achieve the following deliverables:
Table 4
Deliverable & Timeline
S.No.

Deliverable details

Description

Timeline

1

Requirement Analysis

1. Requirement analysis and prepare a full
road map including software design,
2. The agency must ensure that the final
design of Kiosk & Software is approved
by the Directorate of Tourism

T + 1months

2

Software
Development &
Testing in kiosk and
get user acceptance
testing from the DoT

1. Software Development
2. Final User Acceptance Testing approval
by the DoT and the designated person
prescribed by the DoT.

2 months

3

Kiosk Deployment at
Designated Location

1. Software Integration in Kiosk &
2. Successful delivery of the Device at
location suggested by DoT

2 Month

Kiosk Maintenance
and support

1. The agency should ensure to provide
maintenance, Damages-Repair and
support and monthly reports to
directorate of tourism for all contract
period

4

Monthly
Software Maintenance
and Support

3.2

2. The agency should ensure to provide
maintenance support, content update or
anything related to software changes
update on time to time.

Terms of Payment
Table 5
Payment Conditions

S.No.

1

Deliverable details

Payment Terms

Software development
& Kiosk Procurement

1 Time Payment
(After Successfully Kiosk
Installation at designated
location)

Terms of Deduction
(If any)

DoT is reserve the right to
deduct the amount if
1. Given Timeline exceeded.

10

<!-- page 11 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

2

2. If the work is not up to the
satisfaction of DoT

Software & Kiosk
Maintenance
(Manpower Salary,
Software Maintenance,
Kiosk Maintenance,
Hardware Damages
equipment & repair,
Electricity bill, Internet
bill, etc.)

3

Reimbursement of rent
of railway station and
airport space

Monthly Payment

3. If the kiosk quality is not
good

(After Successfully Kiosk
Installation)

4. If the maintenance service
is not find as satisfactory.

Monthly Payment
(Payment on actual bill
basis)

Note:
i.

“T” - Date of issue of Letter of Award (LoA)

ii.

“DoT” – Directorate of Tourism

iii.

Quarterly report shall be submitted in both hard and soft copy after incorporating changes
suggested by DoT committee (if any). The report shall include detailed data and analysis for
all activities and way forward.

iv.

DPR, SOP, User Manual and other necessary Documents of the software and Kiosk have to
submit by the agency.

v.

Agency have to share the progress and planning strategy in every month (or as required by the
DoT) review meeting, No TA/DA will be given to the agency for any review meeting.

vi.

Any hardware and software damages will be compensated by the Agency. The cost of
equipment and repairs will be borne by the Agency for the entire maintenance period.

4

SUGGESTED LOCATION TO DISPLAY THE KIOSK

4.1

Approx. 15 Kiosk at designated location. (6 from Category A + 6 from Category B + 3
from category C)
("Note: The following are suggested locations. The exact location will be finalized at the time
of kiosk installation.")
Category A: No Man powerand no space rent Zone
1) Hotel Birsa Vihar, Ranchi
2) Paryatan Vihar Patratu, Ramgarh
3) Hotel Prabhat Vihar Deluxe, Netarhat, Latehar
4) Radisson Blu Hotel, Ranchi
5) Corridors of Tourism Secretariat
6) Corridors of Tourism Directorate
7)
11

<!-- page 12 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

Category B:Suggested Railway Stations (Manpower, Rental Space Required Zone)
1) Ranchi Railway Station
2) Patna Railway Station
3) Howrah railway station
4) Bhubaneswar railway station
5) Chennai central railway station
6) Chhatrapati Shivaji Terminal Railway station Mumbai
7) Ahmedabad junction railway station
8) Jaipur Junction
9) Bhopal Railway station
10) New Delhi Railway Station
11) Secunderabad Railway Staton, Hydrabad
12) Krantivira Sangolli Rayanna Bengaluru Station
13) Deoghar railway station
Category C: Suggested Airports (Manpower, Rental Space Required Zone)
1) Birsa Munda Airport, Ranchi
2) Jayprakash Narayan International Airport, Patna
3) Netaji Subhash Chandra Bose International Airport, Kolkata
4) Biju Patnaik International Airport, Bhubaneshwar
5) Chennai International Airport, Chennai Airport
6) Chhatrapati Shivaji Maharaj International Airport, Mumbai
7) Sardar Vallabhbhai Patel International Airport, Ahmadabad
8) Jaipur International Airport, Jaipur
9) Raja Bhoj International Airport, Bhopal
10) Indira Gandhi International Airport, Delhi
11) Kempegowda International Airport Bengaluru, Bengaluru
12) Rajiv Gandhi International Airport, Hyderabad
13) Deoghar Airport
4.2

Note: this is a tentative data, Agency have to share the approx.& average rent for the
space cost for the identified destination as per clause 4, DoT reserve the right to
increase or decrease the numbers of kiosk or change the location of the kiosk.

5

TECHNICAL MINIMUM ELIGIBILITY CRITERIA.
To be eligible for pre-qualification and short-listing for evaluation of Financial Bid, the
agency shall fulfil the following eligibility conditions.

S. No.

1

Eligibility Criteria
Legal Entity
a. The Agency must only be an
entity incorporated/ registered
under the Indian Companies
Act 2013/1965 or a Limited
Liability Partnership registered
under the LLP Act 2008 or a

Supported documents to be Submitted
The Agency must submit a proof of
Registration of the legal entity (Certificate of
Incorporation, PAN, GSTIN registration
certificate).
Documents Named: ”Annexure -1 Legal
Entity”

12

<!-- page 13 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

2

3

4

5

6

7

proprietorship firm, No other
legal entities are allowed to
bid.
b. The company should have a
minimum experience of 5
years
Not Blacklisted
Any Department / Agency / PSU in
any State or Central Government of
India as on date of submission of Bid
should not blacklist the Agency.
Similar Work Experience

Self-declaration from the bidder in company
letter head, signed by authorized signatory
Documents Named: ” Annexure-2Not
Blacklisted”

The Agency/OEM having successfully
completed at least two projects
involving the supply and installation of a. Documentary proof (Work Order along
with Completion Certificate
a minimum of 10 interactive kiosks for
government/ PSU/ corporation/ or
Documents Named: ” Annexure-3Similar
leading private organizations, with a
Work Experience”
project cost of not less than INR 20
lakhs each, within the last 5 years
preceding the proposal submission due
date.
a) The details should be certified by the
Annual Turnover
Statutory Auditor of the Company or
The bidding agency should have
Company Secretary
average annual turnover of Rs1 crore
in the last 3 financial years (2021-22,
Documents Named: ” Annexure-4Annual
2022-23& 2023-24)
Turnover”
ISO 27001 and ISO 9001 certifications
ISOCertificates
The Agency must have a valid ISO
27001 and ISO 9001 certifications as Documents
Named:
”
Annexureon date of submission of this RFP
5ISOCertificates ”
Compliance certificates on OEMs
Bidder
must
submit
technical
letterhead
Specification of the product as clause
2.14
Documents Named: ” Annexure-6Technical
Specification”
brochures/ catalogue
Bidders must submit details of the
quoted item i.e. brochures/ catalogue
Documents
Named:
”
Annexurebased on clause 2.14
7Brochures/ catalogue”

6 FINANCIAL PROPOSAL EVALUATION
6.1 Lowest Tender/Bid/Quotation Clause:
The contract shall be awarded to the bidder who submits the lowest tender, bid, or
quotation, provided that:
13

<!-- page 14 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

1. The bidder complies with all the mandatory requirements outlined in the
tender document.
2. The bidder's offer is deemed responsive, meaning it conforms in all material
respects to the terms and conditions, specifications, and requirements of the
tender documents.
3. The bidder is evaluated as capable of fulfilling the contract requirements based
on criteria such as financial stability, technical expertise, and past performance
in relevant field.
4. The bidder passes any additional due diligence checks that the procuring entity
may conduct, including but not limited to background checks, verification of
credentials, and site visits.
6.2

Right to Reject:


7

The DoT reserves the right to reject the lowest tender, bid, or quotation if:
1. The bid is found to be abnormally low and raises concerns about the bidder's
ability to perform the contract satisfactorily.
2. There are reasons to believe that the lowest bid is not genuine or is submitted
as part of collusion or bid-rigging.
3. The bid, despite being the lowest in terms of price, does not meet the required
quality standards or specifications. Or any reason that appears that a
satisfactory result will not be achieved.

TENDER FEE
No tender fee is required

8

EMD (EARNEST MONEY DEPOSIT)
The Bidder shall furnish an Earnest Money Deposit of Rs.1,00,000/- (Rupees one Lac
Only) (the "Earnest Money Deposit" or “EMD”) in the form of a Demand Draft
(DD)/Bank Guarantee (BG) by a Nationalized Bank or a Scheduled Bank in India, drawn
in favour of “Director Tourism,” payable at “Ranchi'' along with bid documents. DOT
shall not be liable to pay any interest on the EMD so made and the same shall be interest
free.

9

PERFORMANCE SECURITY FEE
After the selection of the agency, 5% Demand Draft (DD)/Bank Guarantee (BG) of
the order value must be deposited as performance security until the contract end date.

10 FORCE MAJEURE
For the Purpose of this contract, “Force Majeure” means an event which is beyond the
reasonable control of the DoT. The terms "Force Majeure" as implied herein shallmean
an act of God, War, Civil riots, fire directly affecting the performance of the contract,
floods and Acts and Regulations of respective Government of the two parties, namely the
DoT and the Agency. Both upon the occurrence of such cause and upon its termination,
the party alleging that it has been rendered unable as aforesaid, shall within seventy two
hours of the alleged beginning and ending thereof intimate the other party giving full
particulars and satisfactory evidence in support of its claim. If deliveries are suspended
by force majeure conditions lasting for more than 2 (two) months, the Organization shall
have the option of cancelling this contract in whole or part at its discretion without any
14

<!-- page 15 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

liability on its part. Force Majeure shall not include insufficiency of funds or inability to
make any payment required hereunder.

11 TERMINATION OF THE CONTRACT
a. In case of deficiency or non-fulfilment of obligations as per the scope of work or
quarterly deliverables, DoT shall serve a notice to the concerned agency to rectify /
fulfil the obligations within a specified period of not more than 30 days to rectify
or fulfil the deliverables assigned by DoT, failing which DoT shall be at the liberty
to execute the work through any other agency at the cost of the selected agency.
DoT also reserves the right to cancel the contract.
b. DoT reserves the right to terminate the agreement in case of deficiency in services
or poor performance of the agency for any subsequent month/ quarter/ year. For
this, DoT shall intimate the agency in the Monthly review meeting of the
corresponding year. In this respect, the view of DoT about the performance is final
and binding.
c. DoT reserves the right to drop or remove any or all scope of work deemed not
suitable or in line with the objectives for DoT which may necessitate termination of
contract. However, in such scenario DoT shall provide a maximum time period of
1 months to the agency to terminate the contract and complete all the requisite
formalities and responsibilities assigned.
d. The department has the right to terminate the contract at any time without any prior
notice, if the work is not found satisfactory.
12 PENALTY
12.1 Failure in fulfilment of deliverables as indicated in Table no 4, DoT can imposed the
penalty of 10% as per deliverables
12.2 If the work is not of a standard satisfactory to the Department or suggested by the
Department: like slow performance, resolution of the photo, video is not good,
applications poor performances, the Department reserves the right to make financial
deductions of 10 % from the payment.
12.3 Forfeiture of Performance Bank Guarantee in case of failure to successfully perform /
complete the deliverables and/ or in case of any midway unilateral withdrawal from the
contract.
12.4 On account of circumstances beyond the control of the agency like natural calamities or
force majeure event or any other unforeseen events and upon formal notification by the
appropriate authority, DoT may give extended time to the agency to complete the
deliverables and in such a case will not hold up the payment that is due for that
particular stage.
12.5 Department will give the 15 days extra as a grace periods to complete the deliverables
as per clause 3.
12.6 If any segment is not completed, its payment will not be released.
13 VALIDITY OF BID
Proposal shall remain valid for 180 (One Hundred and Eighty) days from the last dateof
submission. A proposal valid for a shorter period shall be rejected as nonresponsive.

15

<!-- page 16 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

14 CURRENCIES OF BID AND PAYMENT
The prices shall be quoted by the Agency in Indian Rupees (INR) only.
15 DISPUTES
All legal disputes are subject to the jurisdiction of Courts in Ranchi only.
16 ACKNOWLEDGMENT BY AGENCY
It shall be deemed that by submitting the Proposal, the Agency has:
16.1 Made a complete and careful physical examination of the requirements for the project
(Design, Supply, Installation, Operation and Maintenance, Support for Interactive
Digital Touch Screen Smart Kiosk at Designated Locations for Jharkhand Tourism
Branding & Promotion), details mentioned RFP, general condition of contract,
submission formalities and evaluation mechanism.
16.2 Received all relevant information requested from DoT.
16.3 Acknowledged and accepted the risk of inadequacy, error or mistake in the information
provided in this invitation document or furnished by or on behalf of DoT.
16.4 Satisfied itself about all matters, things and information necessary and required for
submitting the proposal and performance of all of its obligations there under.
16.5 Agreed to be bound by the undertaking provided by it under and in terms hereof.
DoT shall not be liable for any omission, mistake or error on the part of the Agency in
respect of any of the above or on account of any matter or thing arising out of or
concerning or relating to this invitation document or the selection process, including
any error or mistake therein or in any information or data given by the DoT.
17 RIGHT TO REJECT ANY OR ALL PROPOSALS
Notwithstanding anything contained in this invitation document, DoT reserves the right
to accept or reject any proposal and to annul this selection process and reject all
proposals, at any time during the bidding process without any liability or any obligation
for such acceptance rejection or annulment, and without assigning any reasons thereof.
DOT, also, reserves the right to reject any Proposal if:
e. At any time, a material misrepresentation is made or uncovered, or
f. The Agency does not submit in time any information or clarification asked for
18 SUBMISSION OF PROPOSAL- PACKING, SEALING & MARKING
Duly sealed proposal from the Agency filled in all respect must reach DoT at theaddress,
time and date specified in the RFP through Speed/ Regd. Post/ courier/ hand
delivery.The Financial Proposal (Part B) must be inserted inseparate sealed envelopes,
along with Agency’s name and address in the left-handcorner of the envelope and super
scribed in the following manner.
Part-A:
Technicalminimum eligibility criteria proposal for Selection of an agency for
Design, Supply, Installation, Operation and Maintenance, Support for Interactive
Digital Touch Screen Smart Kiosk at Designated Locations for Jharkhand
Tourism Branding & Promotion
16

<!-- page 17 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

Part-B:
Financial Proposal for Selection of an agency for Design, Supply, Installation,
Operation and Maintenance, Support for Interactive Digital Touch Screen Smart
Kiosk at Designated Locations for Jharkhand Tourism Branding & Promotion

The Agency’s Name & address shall be mentioned in the left-hand corner of the outer
envelope. The inner and outer envelopes shall be addressed to DoT, Ranchi at the following
address:
Director,
Directorate of Tourism
M.D.I. Building,
2nd Floor, Dhurwa, Ranchi-4
Email: - dirjharkhandtourism@gmail.com
Note:
1. If the outer envelope and the financial proposal envelope is not sealed and marked as
mentioned above, then DoT will assume no responsibility for the tender’s
misplacement or premature opening. Telex, Email, cable or facsimile tenders will be
rejected.
2. The opening of the Financial Proposal shall be made after evaluation of eligibility
criteria and as per the scheduled dates which shall be intimated by DoT to the eligible
Agency.
3. Agencies are advised to prepare their documents with proper sequence and
indexing as per described clause 5, without indexing the bid shall be considered
non-responsive.

17

<!-- page 18 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

19 AMENDMENT/ MODIFICATION
At any time prior to the deadline for submission of Proposal, the DoT may, for any reason,
whether at its own initiative or in response to clarifications requested by an Agency, modify
any of the terms mentioned in this RFP document by the issuance of Addendum /
Amendment. All such amendments/ addendum will be published only on the website
mentioned below and will be binding on all. In order to abide by the issuance of the
amendment or allow the Agency for giving a reasonable time for considering an amendment
into their proposal, or for any other reason, DoT may, in its sole discretion, extend the
Proposal Due Date.
20 LATE SUBMISSION
Proposal received after the deadline for submission prescribed by DoT will not be entertained
and be rejected.
21 CONSORTIUM / JOINT VENTURE
Agencies are NOT allowed to form consortium/Joint Venture for participating in the bid.
22 MODIFICATIONS AND WITHDRAWAL OF PROPOSALS
No modifications to the Proposals shall be allowed once it is received by DoT.

18

<!-- page 19 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE -1 LEGAL ENTITY OF AGENCY
(On the Letter head of the Agency)

a) Name of the Agency:
b) Incorporation (i.e. Company, Partnership or Proprietorship):
c) Registered Office Address with telephone, fax, website and email:
d) Date of Incorporation (Please attach copy of certificate of incorporation /
Registration):
e) Name of the contact Person (Authorised Signatory):
f) Designation:
g) Mobile Number &Telephone Number:
h) E-mail Address:
i) Fax Number:
j) GST Registration number:
k) Pan Card:
l) Average Annual Turnover:

Duly signed by the Authorised Signatory of the Agency
(Name, Title and Address of the Authorised Signatory)

19

<!-- page 20 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE -2 NOT BLACKLISTED
(On the Letter Head of the Agency)

I/We Proprietor/ Partner(s)/ Director(s) of M/s______________________________ hereby
certified that, I/we M/s ____________________________________ have not blacklisted or
debarred by any Ministry/ Departments of Central/ State Government, International bodies
like United Nations, World Bank or any other organisation/ Funding Agencies as on date.
In case the above information found false I/We are fully aware that the tender/ contract will
be rejected / cancelled by DoT, Jharkhand and EMD/PBG shall be forfeited. In addition to
the above DoT, Jharkhand will not be responsible to pay the bills for any completed /
partially completed work.

Duly signed by the Authorised Signatory of the Agency
(Name, Title and Address of the Authorised Signatory)

20

<!-- page 21 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE -3 SIMILAR WORK EXPERIENCE

Sno.

Parameters
Project Title

Details

1
Project Description
2
Location
3
Name of Client
4
5

Total value of work order
(In Indian Rupees), as applicable
No. of manpower/ experts engaged

6
Project Start and end date
7
Other Information relating to Project
8
9

Copy of the work order, completion
certificate to be submitted

*Please use separate sheet for single pro

Duly signed by the Authorised Signatory of the Agency
(Name, Title and Address of the Authorised Signatory)
Note: Documentary proof (Work Order along with Completion Certificate etc of related
projects) with project citation

21

<!-- page 22 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE -4 ANNUAL TURNOVER
Name of the Agency:
________________________________________________________

Sn.
1
2

Particulars
Turnover (in INR
Crore)
Average Annual
Turnover for last
3
years

FY 2021-22

FY 2022-23

FY 2023-24

(in INR Crore)

Note:
1. Attach certified copies of Annual Audited Balance Sheets, P & L statement and IT
Returns Certificate for last 3 (Three) years.
2. The above data must be submitted by Agency, duly certified by either Statutory
Auditor or Chartered Accountant.

Signed
Signature of CA/ Statutory Auditors
(Name of the Authorised Signatory)

(with seal & registration no.)

Place:
Date:

22

<!-- page 23 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE-8 PRE BID QUERY FORMAT

Interested parties shall submit their queries in the following format

Clause No/ Page No

Query/ Modifications Requested

Remark/ Reason

Sn.

Note:
Agencys shall submit their query or modification in soft copy to
dirjharkhandtourism@gmail.com on or before the pre bid query submission due date.

23

<!-- page 24 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE-9 UNDERTAKING
(On the Letter Head of the Agency)
Date:--------------------To,
Director
Directorate of Tourism,
MDI Building, 2nd Floor,
HEC Campus, Dhurwa
Ranchi-834004.
Jharkhand.
Ref: Selection of an agency for Design, Supply, Installation, Operation and
Maintenance, Support for Interactive Digital Touch Screen Smart Kiosk at Designated
Locations for Jharkhand Tourism Branding & Promotion

Dear Sir,
We have examined in detail and have understood the terms and conditions stipulated in the
RFP issued by DoT. Our Proposal is consistent with all requirements of submission as stated
in the RFP or in any of the subsequent communication issued by the DoT. We would be
solely responsible for any errors or omissions in our Proposal.
We hereby declare that we have read and understood the rules governing the development of
project as given above, examined and understood and satisfied ourselves regarding the
content of the various agreements, declarations and deeds to be executed and do hereby
undertake to execute them when called upon to do so, and commit in unequivocal terms, in
letter and spirit, that the project shall be implemented as per the comprehensive stipulations
and requirements that have been spelt out by the DoT, in this RFP and Bidding Documents
including adherence to the areas / capacities / specifications / regulations as have been
detailed by the DoT in this regard.
We also commit to abide by the decision of DoT on all matters relating to the implementation
of the Project and thereafter, the Operations and Maintenance of the Projects.

Yours Faithfully

Duly signed by the Authorised Signatory of the Agency
(Name, Title and Address of the Authorised Signatory)

24

<!-- page 25 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

ANNEXURE-10 FINANCIAL PROPOSAL

To,
Director
Directorate of Tourism,
MDI Building, 2nd Floor,
HEC Campus, Dhurwa
Ranchi-834004.
Jharkhand.

Ref: Selection of an agency for Design, Supply, Installation, Operation and
Maintenance, Support for Interactive Digital Touch Screen Smart Kiosk at Designated
Locations for Jharkhand Tourism Branding & Promotion

We, the undersigned, offer to provide the services for Design, Supply, Installation, Operation
and Maintenance, Support for Interactive Digital Touch Screen Smart Kiosk at Designated
Locations for Jharkhand Tourism Branding & Promotion for Department of Tourism,
Jharkhand in accordance with the subject
RFP in accordance with your Request for Proposal dated, our Financial
Proposal as per details mentioned below:

Financial Bid
Part A
Sn.

1

Quotation for

Procurement & Installation
of digital Interactive Touch
Screen Kioskwith
Application/User interface
development & Digital
Map API procurement &
Integration

Payment
Term

1 Time
Payment

Total Qty

Unit Price

Total Price

(in INR)

(in INR)

15
Minimum 4
API (clause
2.1.2)

Part A Total

25

<!-- page 26 -->

Selection Of An Agency For Design, Supply, Installation, Operation And Maintenance, Support For Interactive Digital Touch Screen Smart
Kiosk At Designated Locations For Jharkhand Tourism Branding & Promotion

Part B
Sn.

Quotation for

Payment Term

1

Operation & Maintenance of
digital interactive Kiosk Damage
repair if require& Services

Monthly
Payment

2

Operation & Maintenance of
Application & Digital MAP

Monthly
Payment

3

Operation & Maintenance of
Electricity Power, 2Manpower,
Internet etc.

Monthly
Payment

4

Reimbursement of Space Rent on
actual bill basis, average rate for
all 9 location as per clause 4

Monthly
Payment

Unit Amount for
one month
(in INR)

Total Amount (in INR)
for 24 Months

Part B Total

Grand Total

Part A Total + Part B Total

Note:
1. The above quote shall be exclusive of applicable GST
2. The costs for hosting, server, and Google Play Console account will be paid by DoT
on an actual bill basis. The hosting and server services will be purchased for a
duration of 5 years.
3. The extension amount is based on the Part B financial amount, with an additional
10% increment applied year-on-year after 2 years.
Our Financial Proposal shall be binding upon us for the assignment and this proposal would
be valid in accordance with the proposal validity mentioned in the subject RFP from the last
date of submission of proposal.
The Financial Proposal is without any condition.

Yours faithfully,
For and on behalf of (Name of Agency)
Duly signed by the Authorised Signatory of the Agency
(Name, Title and Address of the Authorised Signatory)

26
