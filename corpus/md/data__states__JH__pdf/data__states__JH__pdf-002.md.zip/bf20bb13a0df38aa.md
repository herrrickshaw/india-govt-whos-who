---
doc_id: "bf20bb13a0df38aa"
source_url: "https://jserc.org/pdf/notice-thirdmember.pdf"
ministry: "Jharkhand State Electricity Regulatory Commission, Jharkhand"
title: "Notice for the appointment to the post of Third Member (Independent Member) for the Consumer Grievance Redressal Forum of Jharkhand Bijli Vitran Nigam Limited at Ranchi, Hazaribagh, Chaibasa, Medininagar and Dumka"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46e0fb5b1e87d603"
---

<!-- page 1 -->

Jharkhand State Electricity Regulatory Commission
1st Floor, Jharkhand State Housing Board (Old Headquarter), Harmu Housing Colony, Ranchi 834002
Website: www.jserc.org
Email:info@jserc.org

Advertisement No. – 04/2022

NOTICE
Applications are invited for appointment to the post of Third Member (Independent
Member) for the Consumer Grievance Redressal Forum of Jharkhand Bijli Vitran
Nigam Limited at Ranchi, Hazaribagh, Chaibasa, Medininagar and Dumka. The details
of the posts, age, tenure, pay etc. are available on the website of the Commission at
www.jserc.org/thirdmember.pdf . The interested candidates, who fulfil the criteria and are
willing for the above post, may apply through registered/speed post only, so as to reach the
undersigned latest by 06.01.2023
By Order of the Commission
Sd/(Rajendra Prasad Nayak)
Secretary
