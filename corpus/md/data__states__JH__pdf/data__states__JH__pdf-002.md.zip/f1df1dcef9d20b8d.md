---
doc_id: "f1df1dcef9d20b8d"
source_url: "https://bmtu.ac.in/uploads/Assets/syllabus/amendmentnotification-science21-01-202501212025054055983.pdf"
ministry: "Birsa Munda Tribal University, Jharkhand"
title: "Amendment Ordinance"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "87a784d6ad42c087"
---

<!-- page 1 -->

ee (2) tata
fj \ द्रायबल युनिवर््रिंटी,
a ॥ राजपिपला
Birsa Munda
Tribal University,
ae Rajpipla
"eg ipip
बा.गं.द्रय.युनि,/गर्म&/॥.नं.२३७/७[ ०५ . 0. | १८ थी ३८ २०२५ त. ९६।०९॥२०२७०
बंयाए lu:
(१) खत्रेगी 5येरीन। नोटीडी3शन #मां5: ट्र(य.युनि./नर्म६/$॥.गं.२३7/नोटीईीइश०,/२३८१ थी २४००/२०२४
ll.09/09/202%
(२) जे38३ ६ 8-योईडीनेटरनी १0. 3१/१२/२०२४ नी धरणास्त
(3) परामर्शन-व-स्थायी समितिनी अर्यवाही नोंध १. 0१/०१/२०२५
(४) मान.$लपतिश्रीनी मंछुर थयेल्र नोंघ, त(,.२१/०१/२०२प
सुधारा-गोडटिहवि8शन
zu Ast giana yAaRA, eawluctt ata ceel-(a) el yot-2ozx al NEP-2020
UA WA Wg weet (YMalw wal Remo weeasy wa Med wuani Aa MAM vas
ध्स्वामां यावेल,
बंयाए(-(२) थी vez weerusuot नियमोमां सुधारा-वधारा यंजे ABBIAs sl-wsTAreecil
ता. 3१/१२/२०२४ नी ६रण[स्त HAA.
बंय३७-(३) थी वबंयाए-(२) मुष्णन। सुधारायों जमलित घनावव। परामर्शन-व-स्थ!यी समितिनी
ता, 0१/0१/२०२प नी अर्यवाही नोंधघ थी 65राचवामा यावेल,
69त तमाम Otol tala ES AULRL-(2) Yor WHAd Wa Wy AletoU (YwWAYW wal
BAe) ot Meda we WA wAa Moi wpe yu wiani ys सुधार गोटीही3शन Yaa
me seal जावे छे.
ya we wWslotor सुयित सुधार
4 2 3
“q | Ord. = 42: Ord. = 42:

A regular candidate having obtained minimum marks for | A regular candidate having obtained minimum marks for passing

passing in CCE (i.e. 9 out of 25 & 8 out of 50) and SEE (i.e. | in CCE (i.e. 9 out of 25, 8 out of 50, 3 out of 35 & 5 out of 75

9 out of 25 & i8 out of 50) or more but fails to obtain | (3+4 Credit Theory & Practical)) and SEE (i.e. 9 out of 25, 8 out

minimum 36% aggregate and In Zoology ordinance 40% | of 50, 3 ०७६ of 35 & 5 ०७६०5 (3+ Credit Theory & Practical)

aggregate. marks will be required to re-appear in both the | or more but fails to obtain minimum 36% aggregate marks will be
component viz CCE and SEE. In such a case candidate will | required to re-appear in both the component viz CCE and SEE. In
not be required to keep term for the respective semester. | such a case candidate will not be required to keep term for the

The marks of the examination in which the student has | respective semester. The marks of the examination in which the

passed will be carried forward. student has passed will be carried forward.

“No. | CCE SEE Require "| CCE SEE Bs Require
(Continuous & | (Semester to (Continuous & (Semester to
Comprehensive | End Appear Comprehensive End Appear
Evaluation) Evaluation) in Evaluation) Evaluation) in Exam

Exam [oe le a

कस Ea | a

Phone : 02640-299682 अकिशनल ट्रेनिंग सेन्टर (वी.टी.सी.), आरटीओ कार्यालय के बगल में, बाबडी रोड, वाबडी -
Enel dnfotemtureesin craft, Fret- fer - गुजरात - ३९११४५
Need, Val = Rajpipiay Narmada’ ० 5038 बम

<!-- page 2 -->

Only Fail Both
| &*
Only SEE)
Fail Both
(CCE &
SEE)
2 F RA RA
The new curriculum as per NEP 2020 is not only student | The new curriculum as per NEP 2020 is not only student centric in
centric in the teaching-learning processes but also in their | the teaching-learning processes but also in their evaluation
evaluation process. The evaluation consists of the following | process. The evaluation consists of the following two
two components: The component consists of Continuous | components: The component consists of Continuous and
and Comprehensive Evaluation (CCE) and the second | Comprehensive Evaluation (CCE) and the second component
component consists of the Semester end examination. The | consists of the Semester end examination. The division of marks
division of marks between the two shall be 50:50 in the NEP | between the two shall be 50:50 in the NEP 2020; the evaluation
2020; the evaluation process shall follow the norm that the | process shall follow the norm that the faculty, who teaches the
faculty, who teaches the course, shall conduct the | course, shall conduct the Continuous and Comprehensive
Continuous and Comprehensive Evaluation (CCE). The | Evaluation (CCE). The concerned faculty shall be accountable for
concerned faculty shall be accountable for transparency and | transparency and reliability of entire evaluation of the student in
reliability of entire evaluation of the student in the | the concerned Course
concerned Course In each course, every credit carries 25 marks, of which 50% marks.
In each course, every credit carries 25 marks, of which 50% | is assigned for CCE and rest 50% marks for SEE.
marks is assigned for CCE and rest 50% marks for SEE.
4credit | 2credit | 3 2 Credit
Evaluation 4 credit 2 credit subjects | subjects | Credit Practical
मु subjects subjects (Marks) | (Marks) | Theory | (Marks)
(Marks) (Marks) (Marks)
४ CCE (50%) Final marks | 25 2 | CCE (50%) | Final 25 45
50 marks
2 SEE (50%) Final marks | 25 50
50 SEE (50%) | Final 25 35 5
(धो marks
50
en [i00 0 | [30 |
3, | R3 R3
Semester End Evaluation (SEE): The SEE carries 50% of the | Semester End Evaluation (SEE): The SEE carries 50% of the marks
marks assigned to a course. SEE shall be of 2% hours for 4 | assigned to a course. SEE shall be of 2 hours for 4 credit theory
credit course (75 Marks) and % hours in case of 2 credit | course (50 marks), % hours for 3 credit Theory course (35
courses. The controller of the examination will conduct this | Marks) and hours in case of 4 credit Practical courses (5
examination. Paper setting and evaluation will be done by | marks) and 2 hour in case of 2 credit theory course(25 Marks).
the internal and external examiners. This examination shall | The controller of the examination will conduct this examination.
be conducted as per a schedule which shall be notified in | Paper setting and evaluation will be done by the internal and
advance. external examiners. This examination shall be conducted as per a
The backlog exam will be conducted twice a year just after | schedule which shall be notified in advance.
the result declared of the semester evaluation. Students | The backlog exam will be conducted twice a year just after the
~ shall have a second chance to clear their backlog and avoid | result declared of the semester evaluation. Students shall have a
the burden to carry forward the backlog with the next | second chance to clear their backlog and avoid the burden to
semester exam. carry forward the backlog with the next semester exam.
Appearance in all the evaluations is mandatory and no | Appearance in all the evaluations is mandatory and no exemption
exemption can be granted except in the following case: can be granted except in the following case:
4. ॥ case of inability to attend the exam due to reasons | l. In case of inability to attend the exam due to reasons
considered genuine by the controller of examination in | considered genuine by the controller of examination in
consultation with the Registrar/VC. consultation with the Registrar/VC.
2. In case of medical emergency, a certificate from the | 2. In case of medical emergency, a certificate from the registered
registered medical practitioner must be produced before | medical practitioner must be produced before the
the commencement of exams. The authority will then take | commencement of exams. The authority will then take final
final decision on the recommendation for exemption. decision on the recommendation for exemption.
y | RS R-5
Practical Examination: Practical examination (wherever | Practical Examination: SEE Practical examination (wherever
applicable) shall be conducted at the end of every semester. | applicable) shall be conducted at the end of every semester. The
The examination shall be conducted as per norms decided | examination shall be conducted as per norms decided by the
by the concerned authority of the University concerned authority of the University.
y | B7. R7
pe unt Grass aiid Grade Points : Letter Grades and Grade Points
The Semester Grade Point Average (SGPA) is computed
The Semester Grade Point Average (SGPA) is computed from the
from the grades as a measure of the student’s performance inet a Wisnalra of tha atUdanLe certoninahee भी? का
in a given semester. The SGPA is based on the grades of the | 8@0°° ३: P 8
Phone : 02640-29682 वॉकेशनल ट्रेनिंग सेन्टर (वी.टी.सी.), आरटीओ कार्यालय के वगल में, बावडी रोड, वाबडी -
Email: info@bmtu.ac. in राजपिपला, जिला- तर्मदा - गुजरात - ३९३ १४५
Website: ww.bmtu.ac.in Vocational Training Center (VIC), Nr. RTO Office, Vavdi
Road, Vavdi - Rajpipla, Narmada’- Gajarat ~ 293445

<!-- page 3 -->

current term, while the Cumulative Grade Point Average | semester. The SGPA is based on the grades of the current term,
(CGPA) is based on the grades in all courses taken after | while the Cumulative Grade Point Average (CGPA) is based on the
joining the programme of study. grades in all courses taken after joining the programme of study.
The relative grading system provides the relative | The relative grading system provides the relative performance of
performance of a student to a group/class wherein the | a student to a group/class wherein the student is ranked in a
student is ranked in a group/class based on relative level of | group/class based on relative level of achievements. BMTU may
achievements. BMTU may also mention the marks obtained | also mention the marks obtained by the students in each course
by the students in each course and a weightage average of | and a weightage average of marks on the Grade sheet for the
marks on the Grade sheet for the benefits of the students. benefits of the students.
Sr.No. | Letter Grade Grade [Sr.No. ]| Grade Point | Marks (In %) |
Point ae
[4 | O (outstanding) 96.0-00 [2 | At(Excellent) [9 | 86.0-95.9
[2 [As (Excelient) [9 | 86.0-95.9 ||[3 | AlVeryGooa) [8 | 76.0-85.9
[3 | A(VeryGood) [8 | 76.0-85.9 4 | B+ (Good) 66.0-75.9
aes 66.0-75.9 B (Above 56.0-65.9
B (Above 56.0-65.9 Average)
Average) [6 __| C (Average) 46.0-55.9
[6 [४2०० 46.0-55.9 [ii (pass) Rava sss)
es 0| 36.0-45.9 [8 | F (Fail) [o | Below 36.0
(80 कि) 5००० ॥| Below36.0 |/[9 | Ab (Absent) 2000 005 |
9 Ab (Absent)
Minimum passing marks for each pattern of evaluation
Minimum passing marks for each pattern of evaluation | (formative and summative):
= eed eo aes |
aS
a |
|
(मान.इलपतिश्रीनी मर थयेल्ष नोंध, १..२१/०१/२०२५)
85 fap
fo Q
iS a 5.$लसयिव
Dist. Narmada 2 a कु
a ig zu Yst glaaa yaa
oa Vy
<2
aR राष्पीपला
नल रवन :
“5 *. परीक्ष। Maurisall wa DBdrlls A-wsTAez, Meat ys aiana yxAaAA, awllucnr wrcaadl ws.
eo Asatot MBuzall, Mea yst ataaa yal, ewllucit
o scl wMaissll, Qea rst giana yal, ewlluct
© Burol aut, Mea yst giana yMaAA, awlluct
eo udlett eto, Aut Ast gtaaa yal, awlluct
o wlll, eget wg wea AAA wa स!यन्ध, रपीपला, अमलवाएरी ULB.
© wold तमाम... अमलवबारी साइ.
* यहेश 88ले
eo well Aen Adweall, Meat rst gana yYMaWA, ewluct Actaise ue UAtu seat स(३.
सबिनय oS zallott ;
2 Alot. gcrulashl, Aza Ast gia YAMA, ewrfluct wet wz
Phone : 02640-299682 बॉकेशनल ट्रेनिंग सेन्टर (वी.टी.सी.), आरटीओ कार्यालय के बगल में, वावडी रोड, वावडी -
Pec व चर ले शहर > शनपर “दर ह ६
