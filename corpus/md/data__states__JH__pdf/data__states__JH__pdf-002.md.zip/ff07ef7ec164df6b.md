---
doc_id: "ff07ef7ec164df6b"
source_url: "https://cm.jharkhand.gov.in/sites/default/files/Covid_Notification_2024-11/covid19_02-06-2021.pdf"
ministry: "Chief Minister's Office, Jharkhand"
title: "Download PDF"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "054d84f9525aa242"
---

<!-- page 1 -->

Government of Jharkhand
Home, Prison & Disaster Management Department
(Disaster Management Division)
ORDER
Whereas, the Ministry of Home Affairs has issued lockdown/Unlock orders vide Order
dated 24.03.2020, Order dated 5.04.2020, Order dated 04 .05.2020, Order dated
7.05.2020, Order dated 30.05.2020, Order dated 29.06.2020, Order dated 29.07.2020,
Order dated 29.08.2020,Order dated 30.09.2020, Order dated 27.0.2020,Order dated
25.4.2020, Order dated 28.2.2020,Order dated 27.04.2024 “00 0860 26.02.2024,
Order dated 23.03.202 and Order dated 29.04.2024 due to the prevailing COVID 49
situation;
Whereas, in exercise of the powers, conferred under Section 0(2)(I) of the Disaster
Management Act 2005, the Union Home Secretary and Chairman, National Executive
Committee has issued an order dated 27.05.2024 directing that the containment
measures and national directives for effective control of COVID-I9 as communicated
vide Ministry of Health and Family Welfare DO Number Z 2804 5/85/202-DM Cell dated
25.04.202 would remain in force upto 30.06.2024 ;
Whereas, in exercise of the power conferred under section 22(2)(h) of the Disaster
Management Act, 2005, the undersigned in his Capacity as Chairperson, State Executive
Committee has issued directions to all the Departments of Government of Jharkhand
and all the District Administrations for the strict implementation of Guidelines and State
Directivesvide Order no 234 dated 2.05.202 amended vide Order number 338 dated
25.05.202! valid upto 6 AM on 03.06.2024
Whereas the Ministry of Home Affairs vide order dated 27.05.202/ has mandated state
government to take all necessary measures to promote COVID-9 appropriate behaviour
and has also authorised the state, based on its assessment of the situation, to impose
local restrictions at district/sub-district and city/ward level, with a view to contain the
spread of COVID-9;
Whereas the situation of COVID-9 has been reviewed and it has been observed that
there has been a fall in the number of new COVID-9 cases as well as fall in positivity
but at the same time it is anticipated that gatherings and Congregations may pose a
considerable threat of spread of COVID-9;
Whereas, in exercise of the powers under section 4 8(2)(d) of the Disaster Management
Act, 2005, the State Disaster Management Authority has directed the undersigned to
issue an order with guidelines for the containment of COVID | 9; ee a
क

<!-- page 2 -->

Now therefore, in exercise of the power conferred under section 22(2)(h) of the Disaster
Management Act, 2005 the undersigned, in his Capacity as Chairperson, State Executive
Committee, hereby directs all the Departments of Government of Jharkhand and all the
District Administrations to ensure that SwasthyaSurakshasaptah is observed by all
from 6 AM on 03.06.2024 till 6 AM on0.06.2024;

(. All shops shall be permittedto open till 2 PM dailyin Chatra, Dumka,
Giridih, Godda, Jamtara,Khunti , Koderma, Latehar, Lohardaga, Pakur,
Palamau, Sahebganj, Sarikela, Simdega and West Singhbhum
districts.

2. In Bokaro,Deoghar, Dhanbad, Purvi Singhbhum, Garhwa, Gumla,
Hazaribag, Ramgarh and Ranchi districts all shops shall be permitted
to open till 2 PM daily with the exception of garment / cloth/ jewellery/
footwear/ cosmetics shops which shall continue to remain closed.

3, Above mentioned timing restrictions shall not be applicable to medicine
shops/ diagnostic centres/  clinics/ hospitals/ petrol pumps/LPG
outlets/CNG outlets/restaurants doing home delivery/dhabas located
on national/state highways/cold storages/warehouses/ unloading of
goods.

4. Unhindered transportation/logistics of all goods is permitted.

5. In hotels the use of Banquet halls and sit in dining is prohibited.

6. Restaurants are permitted to do home delivery of products. Sit in
dining is prohibited.

7, All activities previously permitted shall continue to be permitted.

8. All religious places/places of worship are permitted to open but visitors
are prohibited.

9. All indoor or outdoor congregations of more than 5 persons are
prohibited in the state with the exception of last rites related functions
with upper limit 20 persons and marriage rituals as mentioned below.

2 Jie

<!-- page 3 -->

0. Marriage shall be held at home or in court. Marriage shall not be held
at any public place including community hall/ banquet hall etc. Use of
loudspeaker/Du/firecrackers is prohibited in marriage. Marriage
processions are prohibited. Not more than 4 persons shall attend the
Marriage including bride/bridegroom/person for solemnising the
marriage. At least 3 days prior information shall be given to the nearest
police station.

.Alll processions are prohibited.

(2.All educational _ institutions including — schools/colleges/ITIs/skill
development centres/coaching institutions/training institutions shall
remain closed. Digital content/ online education may be provided to the
students.

3. All examinations to be conducted by various authorities of Government
of Jharkhand shall be postponed.

/4.All ICDS centres shall be closed. Home delivery of National Food
Security Act entitlements shall be ensured.

5. All fairs and exhibitions are prohibited.

6.Shopping malls/Movie halls/ multiplexes / theatres/ assembly halls/
Banquet halls/bars/ clubs/ salons/ department stores selling multiple
categories of products like garments, cosmetics etcshall remain
closed.

7. All Stadiums/gymnasiums/swimming pools/parks shall be closed.

8.Bus transport shall be prohibited except for use by district
administration or for use by Industrial/Mining undertakings for

Movement of personne! with the permission of district administration.

9. Movement of persons is permitted from 3 PM to 6 AM only with respect

to activities permitted beyond 2 PM, air/rail related travel, attending last

rites and for discharge of any duty related to control of COVID-9,

<!-- page 4 -->

20. With regard to e pass the following provisions shall prevail:
i. For any kind of inter state and inter district movement by
personal vehicle the person shall carry E-Pass, valid photo
identity card and valid ticket in case of air/rail related travel. E
Pass can be downloaded from epassjharkhand.nic.in.

ii. _E pass shall not be required for intra district movement.

ili, Intrastate public transport by commercially registered taxis
shall be permitted without E pass.

iv. All movement into the state by personal vehicle or taxi shall be
permitted only on producing E pass.

v. Vehicles of Government of India/Government of
Jharkhand/other state governments shall be exempt from the
requirement of Epass.

vi. Vehicles. passing through the state shall not be required to
produce E pass.

vii. District administration shall make suitable arrangements
including setting up of properly manned border check posts for
implementing the above directions. SSP/SP Shall deploy police
personnel in adequate number for implementing the directions.

24. Haats in rural/urban areas shall be permitted only on the condition that
adequate arrangements for ensuring social distancing is ensured,

Marking of circles on ground shall be done to ensure social distancing

22. All persons travelling to Jharkhand shall undergo quarantine for 7 days
as per the following guidelines,

i. Every person coming/returning to Jharkhand by air/rail/road
Shall register his/her personal details on the website of
Government of Jharkhand (www jharkhandtravel.nic.in)
preferably before his/her departure for Jharkhand and in any
case not later than the day of arrival in the state of Jharkhand,

ii, Every person coming/returning to Jharkhand by air/rail/road
shall stay in home quarantine for a period of 7 days observing
guidelines issued by Department of Health and Family Welfare
and Medical Education in this regard.

ili. The district administration shall take all necessary measures to
ensure the compliance of home quarantine directions and all
the instructions issued from time to time in this regard.

4

<!-- page 5 -->

iv. _ In case the district administration comes to the conclusion that
the conditions at the home of the person are not appropriate for
home quarantine, or the concerned person is not following the
guidelines of home quarantine, then the district administration is
authorised to put the person in institutional quarantine facility.

v. Above directions shall not apply to personnel of airlines, people
passing through the state during interstate movement,
Government of India officials on official duty, persons who
undertake daily interstate travel for purpose of mining/
construction/ industrial/ agriculture/health care related activities
and persons who travel back from Jharkhand within 72 hours of
arrival in the state.

23.No person without mask/face cover shall be permitted entry in any
government office/ railway station/ airport/ bus/ taxi/ auto rickshaw /
any other public place like shop etc.
24. The guidelines and state directives annexed shall be followed.
25. Any person violating these guidelines or the attached State directives
will be liable to be proceeded against as per the provisions of Section
54 to 60 of the Disaster Management Act 2005, besides legal action
under Section 88 of the IPC and other legal ee as applicable.
g
(Sukhdev Singh)
Chief Secretary,
Jharkhand.
Memo no. 374/¢s/REs Ranchi, Dated:,..02, 94’ 2024
Copy to — Principal Secretary to Chief Minister/PS to all Ministers/All Additional Chief
Secretary/Principal Secretary/Secretary/Director General of Police/All Divisional
commissioner/DIG/DC/SSP/SP, Jharkhand for information and necessary action.
Copy to Secretary, Ministry of Home Affairs, Government of es Ministry of
Health and Family Welfare, Government of India. हा
०७
Chief Secretary,
Jharkhand
5

<!-- page 6 -->

Guidelines on the measures to be taken by Departments of Government of
Jharkhand/District Administrations for containment of COVID-9.

i. The directions and national directives communicated vide Order dated
27.05.202 (annexed) of Ministry of Home Affairs; Government of India shall be
implemented.

2. The examinees of all examinations conducted by Government of India authorities
shall be exempted from restrictions related to movement out of Containment
Zone(s) for the purpose of examinations and their admit card shall be treated as
entry pass for this purpose. SOP dated 0.09.2020 (annexed) issued by Ministry
of Health and Family Welfare shall be complied with.

3. Hotels,Restaurantsand other hospitality units such as guest
house/Dharamshala/lodge etc shall comply with the SOP on preventive measures
laid down by Ministry of Health and Family Welfare,Government of India in this
regard on 04.06.2020(annexed).

4. All domestic travellers shall comply with the guidelines for domestic travel
(air/train/inter-state bus travel) issued by Ministry of Health and Family
WelfareGovernment of India, on 24.05.2020 in this regard (annexed).

5. All international travellers on Vande Bharat and Air Transport Bubble flights shall
comply with the SOP issued by Ministry of Home Affairs,Government of India on
22.08.2020 in this regard (annexed).

6. All domestic air travel.shall be in accordance with guidelines issued by Ministry of
Civil Aviation, Government of India on 25.05.2020(annexed),

7. Offices shall comply with the SOP on preventive measures laid down by Ministry
of Health and Family Welfare,Government of India in this regard on 04.06.2020
(annexed).

8. The state directives as annexed shall be adhered to while carrying out the
permitted activities. yee

=
(Sukhdev Singh)
Chief Secretary,
Jharkhand.
6

<!-- page 7 -->

State State Directives for COVID-9 Management for COVID-9 Management
{. Wearing of face cover/mask is compulsory in public places, in work places, and
during transport.

2. Individuals shall maintain social distance of do gazkidooriin public places.

3. Spitting in public places is prohibited.

4. Persons above 65 years, persons with co-morbidities, pregnant women and
children below the age of 40 years are advised to stay at home, except for
essential and health purposes.

5. District authorities may advise individuals to install the AarogyaSetu application on
compatible mobile phones and regularly update their health status on the app.
Shops

6. Provision for sanitizer will be made at all entry point.

7. All persons in charge of shops will ensure that the number of persons entering the

shop shall not exceed the number required to maintain social distance.

8. Wearing of face cover/mask is compulsory by workers and customers.

9. Hand gloves may be worn by all the workers,

0. Shops would ensure frequent sanitisation throughout the day of all points which
frequently come into human contact eg. door handles, surface of table/counter
etc.

(4. Shops would ensure sanitisation of entire workplace and common facilities at the
beginning of the day and end of the day.

(2. Shops to ensure that any worker suffering from fever/cough/breathing problem
does not attend the Shop and is referred to nearest health facility.

3. Any customer apparently having cough/breathing problems to be denied entry
and may be asked to immediately contact health facility.
»)
Be
(Sukhdev Singh)
Chief Secretary,
Jharkhand
7
