---
doc_id: "2fd4990f4ddb1bfe"
source_url: "http://www.sajha.in/wp-content/uploads/2024/03/Food-tender-COE-Football-Morabadi.pdf"
ministry: "Sports Authority of Jharkhand, Jharkhand"
title: "Click here to View/Download"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08a937d1fd114b1d"
---

<!-- page 1 -->

¼i;ZVu] dyk] laLd`fr] [ksy&dwn ,oa ;qok dk;Z foHkkx½
xsV laŒ&29] fcjlk eq.Mk QqVckWy LVsfM;e] eksjkcknh] jk¡ph&834008
Email : - sajha9@gmail.com, Website :- www.sajha.in

(Rate Contract)
NIT No.

i;ZVu] dyk&laLd`fr] [ksydwn ,oa ;qokdk;Z foHkkx] >kj[k.M] jk¡ph vUrxZr >kj[k.M [ksy izkf/kdj.k
ds v/khu lsUVj vkWQ ,Dlsyl
sa ¼,dyO; dsUnz½] QqVckWy izf'k{k.k dsUnz] fcjlk eq.Mk QqVckWy LVsfM;e]
eksjkcknh] jk¡ph ds izf'k{kq f[kykfM+;ksa dks Fresh & Hygienic Hkkstukfn dh O;oLFkk gsrq fuEuor~ esU;w ds vuqlkj
izfr dSMsV ¼f[kykM+h½ dks izfrfnu dh nj (Per day per plate Rate) izkfIr (Rate Contract) gsrq bPNqd
dSVjj@QeZ@izfr"Bku ls eqgjcan fufonk vkeaf=r dh tkrh gS%&
Menu for Centre of Excellence (Eklava Kendra) under Sports Authority of Jharkhand, Ranchi
Meal

MONDAY

TUESDAY

WEDNESDAY

THURSDAY

FRIDAY

SATURDAY

Dates

Dates

SUNDAY

MORNING
Dry fruit/packet foodpre training

Dates

Dates

Dates

Dates

During training

Lemon water

Lemon water

Lemon water

Lemon water

Fruit-post training

Banana (4Pc)

Banana (4Pc)

Banana (4Pc)

Banana (4Pc)

Lemon
water
Banana
(4Pc)

Lemon water
Banana (4Pc)

BREAKFAST
English

Wheat Bread

Wheat Bread

Wheat Bread

Wheat Bread

Wheat
Bread

Wheat Bread

Milk Dalia

Cornflakes

Puri with
Bhaji/Idli
Paneer
burji

Indian breakfast item

Dalia Upma

Cornflakes

Milk Dalia

Salty Vermicelli
(Sewai)

for veg

Paneer bhuji

paneer cubes
Tawa fry

Paneer burji

Paneer burji

paneer
cubes Tawa
fry

Paneer burji

Egg(for non veg)

Boiled Egg (2
Pc)

Boiled Egg (2 Pc)

Boiled Egg (2 Pc)

Boiled Egg (2 Pc)

Boiled Egg
(2 Pc)

Boiled Egg (2
Pc)

Dairy

Milk (200 ml)

Milk (200 ml)

Milk (200 ml)

Milk (200 ml)

Milk (200
ml)

Milk (200 ml)

Accompaniments

Butter/Jam

Butter/Jam

Butter/Jam
LUNCH

Butter/Jam

Butter/Jam

Butter/Jam

Salad

Green Salad

Green Salad

Green Salad

Green Salad

Green Salad

Green Salad

Green
Salad

Vegetable

Seasonal Veg

Seasonal Veg

Seasonal Veg

Seasonal Veg

Seasonal
Veg

Seasonal Veg

Seasonal
Veg

Non-Veg

Fish

Fish/Chicken stew

Fish

Fish

Fish/Chicke
n stew

Fish

Mutton
curry

Special Veg-item

Mushroom+Pane
er

Soyabean+paneer
Curry

Mashroom+paneer

Mushroom+paneer

Soyabean+p
aneer curry

Mushroom+pa
neer

Mushroo
m+Paneer

Dal

Dal

Dal

Dal

Dal

Dal

Dal

Curd

Curd/Raita

Curd/Raita

Curd/Raita

Curd/Raita

Curd/Raita

Curd/Raita

Chapati & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Other

Whole fruit (1
Pc)/ Juice
(200ml)

Whole fruit (1 Pc)/
Juice (200ml)

Whole fruit (1 Pc)/
Juice (200ml)

Whole fruit (1 Pc)/
Juice (200ml)

Whole fruit
(1 Pc)/ Juice
(200ml)

Whole fruit (1
Pc)/ Juice
(200ml)

Boiled
Egg (2
Pc)
Double
Toned
Milk
(250ml)

Dal
Curd/Rait
a
Roti &
Rice
Whole
fruit (1
Pc)/ Juice
(200ml)

EVENING
Packed food pre
training

chikki/laddoo

chikki/laddoo

Biscuit

chikki/laddoo

chikki/laddoo

Biscuit

Snack post training

Boiled chana,
peanuts

Sprout

Boiled chana,
peanuts salad

Boiled chana, peanuts
salad

Sprout

Boiled
chana,
peanuts
salad

Green Salad

Green Salad

Green Salad

Green Salad

Green Salad

Green Salad

Green Salad

Green
Salad

Chicken

Chicken

Chicken

Chicken

Chicken

Chicken

Egg Curry

Paneer

Mashroom+pane
er

Paneer

Paneer

DINNER

Non-Veg (for nonvegetarians)
Veg-item (for
vegetarians

Paneer

Mashroom+paneer

Paneer

<!-- page 2 -->

Vegetable

Seasonal Veg.

Seasonal Veg.

Seasonal Veg.

Seasonal Veg.

Seasonal Veg.

Seasonal Veg.

Pulse

Dal

Dal

Dal

Dal

Dal

Dal

Chapati & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Roti & Rice

Sweet Dish (Rice
kheer)
Turmeric Milk
(200ml)

Sweet Dish (Rice
kheer)
Turmeric Milk
(200ml)

Sweet Dish (Rice
kheer)
Turmeric Milk
(200ml)

Sweet Dish (Rice
kheer)
Turmeric Milk
(200ml)

Sweet Dish (Rice
kheer)
Turmeric Milk
(200ml)

Sweet Dish
(Rice kheer)
Turmeric Milk
(200ml)

Dessert
Bed time

Seasonal
Veg.
Dal
Roti &
Rice
Sweet/Ice
cream

Dal Moong, Masoor, Chana, Rajma, Chhole, Arahar; Rish-Rohu/katla
The above mentioned food item are subject to availability and can be changed accordingly.
The above mentioned menu has been updated based on the direction of competent Authority
Rate Quoted should be per person/per plate (Including GST)

1.

lsUVj vkWQ ,Dlsyl
sa ¼,dyO; dsUnz½ ds izf'k{kq f[kykfM+;ksa dks esU;w ds vuq:i 'kq) ,oa rktk
vYikgj@Hkkstukfn f[kykus dk iw.kZ nkf;Ro p;fur dSVjj dk gh gksxkA Hkkstu esa fdlh Hkh rjg dh =qfV
;k esU;w dk vuqikyu ugha gksus rFkk lle; vkiwfÙkZ ugha fd;s tkus vkfn dh iw.kZ ftEesokjh p;fur dSVjj
dh gksxh rFkk rRlac/a kh f'kdk;r feyus ij dSVjj ds foi= Hkqxrku esa ls dVkSrh lfgr
,djkjukek@dk;kZns'k jÌ djus ,oa dkuwuh dkjZokbZ djus dk vf/kdkj dk;Zdkjh funs'kd] >kj[k.M [ksy
izkf/kdj.k dks gksxkA

2.

bl fufonk }kjk p;fur ,tsl
a h dk fu/kkZfjr nj (Rate Contract) vkns'k fuxZr ds frfFk ls ,d ¼01½ o"kZ
ds fy, ekU; gksxk rFkk dk;Z lrks"a kizn gksus ij vxys 01 o"kZ ds fy, vof/k foLrkfjr dh tk ldrh gSA

3.

>kj[k.M [ksy izkf/kdj.k vUrxZr lapkfyr lsUVj vkWQ ,Dlsyl
sa ¼,dyO; dsUnz½ tgk¡ p;fur dSVjj }kjk
Hkkstukfn dh vkiwfrZ dh tkuh gS%&
lsUVj vkWQ ,Dlsyl
sa ] QqVckWy izf'k{k.k dsUnz] fcjlk eq.Mk QqVckWy LVsfM;e]
1.

eksjkcknh] jk¡phA

ckyd &32 ,oa ckfydk &32

4.
i.

nj fu/kkZj.k (Rate Contract) gsrq vfr vYidkyhu fufonk nks fyQkQk O;oLFkk vUrxZr gksx
a As
fyQkQksa ds Åij rduhdh chM (Technical Bid) ,oa foÙkh; chM (Financial Bid) Li"V fy[kk gksuk
pkfg,A

ii.

rduhdh chM fyQkQk & rduhdh chM fyQkQk ds vanj fuEu LovfHkizekf.kr vfHkys[k miyC/k
djkuk vko';d gksxk %& (i) QeZ dk uke ,oa iwjk irk (ii) fuca/ku la[;k (iii) FSSAI ykbZll
sa
(iv) iSu uaŒ (v) thŒ,lŒVhŒ uaŒ (vi) lacfa /kr {ks= esa dk;Z djus dk vuqHko laca/kh vfHkys[k lacaf/kr
fufonknkrk QeZ }kjk foxr 03 o"kksZa esa Hkkjr ljdkj@jkT; ljdkj vFkok PSUs dks lQyrkiwoZd
dk;Z djus dk vuqHko gksuk pkfg,] rRlac/a kh dk;kZns'k layXu djuk gksxkA (vii) vk;dj fjVuZ
¼foÙkh; o"kZ 2020&21] 2021&22] 2022&23 vFkkZr ,lslesUV o"kZ 2021&22] 2022&23] 2023&2024
(viii) dkyh lwph esa ntZ ugha gksus lacaf/kr Lo?kksf"kr 'kiFk i= (ix) lacaf/kr fufonknkrk QeZ dk
vkSlr okf"kZd VuZvksoj U;wure ₹1]00]000]00@& gksuk vfuok;Z gS] blds fy, fucaf/kr pkVZMZ
vdkmaVsUV dk lfVZfQdsV tek djuk vfuok;Z gksxkA
foÙkh; chM (Financial Bid) fyQkQk esa fufonknkrk] vkiwfÙkZ dh tkus okyh Hkkstu lac/a kh mijksDr
fooj.kh (menu) gsrq Per Person/Per Plate/Serving (Inclusive of GST) esU;w nj dk mYys[k djsx
a As
fufonknkrk dks thŒ,lŒVhŒ dk vyx izfr bdkbZ nj ¼lHkh dj lfgr½ Li"V 'kCnksa esa vafdr
jguk pkfg,A foÙkh; chM ds fyQkQs esa foÙkh; nj dsoy Printed/Typed gksuk pkfg,A gLrfyf[kr

iii.

<!-- page 3 -->

(Hand Written) foÙkh; chM dks vLohdk;Z dj fn;k tk,xk ,oa bl laca/k esa dksbZ Hkh nkok ekU;
iv.

v.

ugha gksxkA
rduhdh :i ls ;ksX; ik;s tkus dh Lohd`fr mijkar gh ;ksX; ik;s x, fufonknkrkvksa dks foÙkh;
chM [kksyh tk,xhA dqy foÙkh; nj ¼dj lfgr½ ij gh lQy@U;wure (L1) fufonknkrkvksa dk
fu/kkZj.k fd;k tk,xkA
izR;sd fufonknkrk dks vxz/ku (EMD) ds :i esa ₹5]00]000@& ¼ik¡p yk[k :i;s½ ek= jkf'k
fMekaM Mªk¶V Sports Authority of Jharkhand, Morabadi, Ranchi ds uke ls tek djuk gksxkA
lQy fufonknkrk ds EMD dh jkf'k dks lqjf{kr tek j[kk tk,xk ,oa ,djkjukek dh vof/k
lekfIr ds mijkar fcuk fdlh C;kt ds okil ykSVk;k tk,xkA vlQy fufonknkrk dks
EMD/Bank Draft /B.G. okil dj fn;k tk;sxkA

vi.

os fufonknkrk@QeZ] tks MSME ¼>kj[k.M½ esa iathd`r gSa] mudks >kj[k.M ljdkj ds MSME
fu;e ds vuqlkj Exemption lqfo/kk ykxw gksxkA

vii.

fufonknkrk dks fufonk 'kqYd ds :i esa ₹10]000 ¼nl gtkj :i;s½ ek= jkf'k dk fMekaM Mªk¶V
Sports Authority of Jharkhand, Morabadi, Ranchi ds uke ls tek djuk gksxk] tks fdlh Hkh
ifjfLFkfr esa okil ugha fd;k tk,xkA

viii.

lHkh lsUVj vkWQ ,Dlsyl
sa dh f[kykfM+;ksa dks vkiwfrZ dh tkus okyh Hkkstukfn fuxZr dk;kZns'k ds
vkyksd esa xq.koÙkk dh tk¡p] f[kykfM+;ksa dh lgefr ds mijkUr ftyk [ksy inkf/kdkjh@izf'k{kd
}kjk lR;kfir djusa ds mijkUr larks"ktud ik;s tkus ij Hkqxrku gsrq fcy@foi= ,tsl
a h }kjk
dk;Zdkjh funs'kd] >kj[k.M [ksy izkf/kdj.k ds inuke ls >kj[k.M [ksy izkf/kdj.k ds dk;kZy; esa
tek djus ds i'pkr Hkqxrku ij fu.kZ; fy;k tk;sxk] fdlh izdkj dh vfxze jkf'k Hkqxrs; ugha
gksxhA
ix.

Hkkstukfn esa mi;ksx gksusokys lHkh rkth lkefxz;k¡] LoPN ,oa lkQ&lqFkjs miLdjksa@orZuksa dh
O;oLFkk p;fur dSVjj@QeZ@izfr"Bku dks Lo;a djuh gksxh rFkk foHkkx@dk;kZy; }kjk bl gsrq
fdlh izdkj dk vyx ls dksbZ Hkqxrku vFkok vfxze ugha fn;k tk;sxkA
x.

vkiwfÙkZ fd;s tkus okys Hkkstu gsrq 'kq) ,oa lkQ lkefxz;ks]a miLdjksa dk iz;ksx] LokLF;dj jlksbZ]
cjru ,oa mudh lqj{kk dk nkf;Ro fufonknkrk dk gh gksxkA lkefxz;ksa ,oa miLdjksa ds [kksus] pksjh
gksus vFkok {kfrxzLr gksus dh fLFkfr esa bldh izfriwfÙkZ ugha dh tk,xhA
xi.

 fufonk lefiZr djus dh vafre frfFk ,oa le; 11-03-2024 dks iwokZŒ 11%00 cts rd gSA
 fufonk ¼rduhdh izLrko ,oa foÙkh; izLrko½ [kksyus dh frfFk ,oa le; 11-03-2024 dks
viŒ 04%00 cts gSA
 fufonk lefiZr djus dk LFkku >kj[k.M [ksy izkf/kdj.k dk dk;kZy;] xsV uaŒ&28] fcjlk
eq.Mk QqVckWy LVsfM;e] eksjgkcknh] jk¡ph esa dk;Z fnol ds viŒ 6%00 cts rd gSA
 vafre frfFk ,oa le; ds ckn lefiZr fufonk ij fdlh izdkj dk fopkj ugha fd;k
tk;sxkA
 fcuk dkj.k crk;s fdlh ;k lHkh fufonk dks jÌ djus dk lokZf/kdkj dk;Zdkjh funs'kd]
>kj[k.M [ksy izkf/kdj.k] eksjkcknh] jk¡ph dks lqjf{kr jgsxkA

gñ@&

<!-- page 4 -->

>kj[k.M [ksy izkf/kdj.kA
