---
doc_id: "ace67cf0c6ec2c49"
source_url: "https://labour.and.nic.in/webPages/pdf/Gazette_MemberConstitution_ANIBOCWWB.pdf"
ministry: "Labour, Employment & Training Department, Andaman & Nicobar"
title: "Gazette for constitutes members ANI BOCWW Board"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1a5c4aec6c43e16c"
---

<!-- page 1 -->

v.Meku rFkk

fudksckj jkti=

Andaman And

Nicobar Gazette
vlk/kkj.k
EXTRAORDINARY

Published by Authority
No. 51, Sri Vijaya Puram, Thursday, June 12, 2025

ANDAMAN AND NICOBAR ADMINISTRATION
OFFICE OF THE LABOUR COMMISSIONER
SRI VIJAYA PURAM

****
NOTIFICATION
th

Sri Vijaya Puram, dated the 12 June, 2025.
No. 51/2025/ F.No.M-227/2/2024-Estt.(BOCW)-ANIBWB_AN.— In exercise of the powers conferred
by Sub-Section (1) of Section 18 of the Building and other Construction Workers (Regulation of Employment
th

& Condition of Service) Act., 1996 (27 of 1996) read with Notification No. S.O. 668(E) dated 14 July, 2000
issued by the Ministry of Home Affairs, Government of India and in supersession of Notification
No. 82/2022/F. No. 2-1/B.C/LC-2012/Vol.III dated 22

nd

July, 2022, the Lieutenant Governor (Administrator),

Andaman and Nicobar Islands, hereby constitutes Andaman and Nicobar Islands Building and other
Construction Workers Welfare Board with effect from 22

nd

July, 2025 for the period of 03 years with the

below mentioned composition to exercise the power conferred on and perform the function assigned to it
under the said Act and Rules within the limit of Territorial Jurisdiction of Andaman and Nicobar Islands.
Secretary (Labour), A & N Administration

- Chairperson

Central Government Nominee
1.

Welfare Commissioner, GOI, LWO, Kolkata

- Member

Representative of the State Government
1.

Director of Industries, A & N Administration

- Member

2.

Director of Rural Development & Panchayat ,

- Member

A & N Administration
3.

Any Female Secretary, A & N Administration

- Member

(Recommended by Chief Secretary)
Representative of the Employers of the Building & other Construction Works
1.

Chief Engineer, APWD, Sri Vijaya Puram

- Member

2.

Superintending Engineer (Civil)

- Member

Municipal Council, Sri Vijaya Puram
3.

Conservator of Forests (HQ), A & N Administration
Van Sadan, Haddo, Sri Vijaya Puram

- Member

<!-- page 2 -->

2

THE ANDAMAN AND NICOBAR EXTRAORDINARY GAZETTE, JUNE 12, 2025

Representative of the Employees of the Building & other Construction Workers
1.

Shri K. P. Aboobacker, State General Secretary

- Member

INTUC, Sri Vijaya Puram
2.

Shri Sunil Kumar Ghosh, General Secretary

- Member

BMS, Sri Vijaya Puram
3.

Shri S.P. Kalairajan, Secretary

- Member

CITU, Sri Vijaya Puram
Labour Commissioner, A & N Administration

- Member Secretary

By Order and in the name of the Lieutenant Governor (Administrator),
Andaman and Nicobar Islands

Sd./Additional Secretary (Labour) / Labour Commissioner

MGPSVP—51/Gazette/2025— 40 Copies.

(P/DTP-2)
