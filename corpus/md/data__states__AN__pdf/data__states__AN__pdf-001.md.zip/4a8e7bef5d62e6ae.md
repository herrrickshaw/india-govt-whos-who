---
doc_id: "4a8e7bef5d62e6ae"
source_url: "https://rdpri.andamannicobar.gov.in/admin-pannel/whatsnew/78-Corrigendum.pdf"
ministry: "Rural Development & Panchayat Department, Andaman"
title: ".pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d26a06ef707a9200"
---

<!-- page 1 -->

F.No.3-249/DAY-NRLM/RD/2021-22/ 257
ANDAMAN AND NICOBAR ADMINISTRATION

DIRECTORATE OF RD, PRIS & URBAN LOCAL BODIES
MARINE HILL, PORT BLAIR

(Andanan & Nicobar Island's RuralLivelihood Mission)

Port Blair, dated/etu, faiE a&August, 2024
CORRIGENDUM
This invites reference to the Vacancy Notice uploaded in

on 27.07.2024 to

Website of A&N Administration i.e. www.andaman.gov.in

invite applications for filling up of following posts
at Block Levels under DAY-NRLM

No.
1.
2.

purely on contractual basis

scheme:

Name of the Posts

S1.

Cluster Coordinator

Data Entry Operator

No. of Posts

Level of
Service
Block
Block

02
02

date for Personal
Due to administrative reasons, the
PM to
postponed from 03.09.2024 at 04:00

candidates who have been shortlisted for the

prior to the
Hill, Port Blair one hour

Interview has been

12.09.2024 at 03:00 PM, The

aforesaid posts are required to be

and ULB's, A&N
present in the Directorate of RD, PRIs

Original Documents for

the Official

Administration, Marine

aforesaid interview timing with all

their

verification.
2

hgslstant

Director (RD/ Panch.)
