---
doc_id: "ccb27b07db5a73de"
source_url: "https://dhs.andamannicobar.gov.in/Document/35af031c4-cde4-455f-bca6-2bae22d6cca2.pdf"
ministry: "Health Department, Andaman & Nicobar"
title: "Applications are invited from Indian Nationals for appointment on Deputation/Short Term Contract basis for the post of Chairperson, Andaman and Nicobar Allied and Healthcare Council, A&N Administration for an initial period of 02 years and extenable based on performance and existing rules."
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b30bb7d2b8748eca"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

Recent Passport
Size Photograph

ANNEXURE-I

(Self-attested)

PROFORMA
NAME AND PARTICULARS OF CANDIDATE FOR THE POST OF
CHAIRPERSON, ANDAMAN AND NICOBAR ALLIED AND HEALTHCARE
COUNCIL
1. PERSONAL DETAILS
Particulars

Details

Full Name (in Block Letters)
Father's/Husband's Name
Date of Birth
Age as on Closing Date
Nationality
Present Address (Office)
Permanent Address
Telephone No.
Mobile No.
E-mail ID
Aadhaar No.
Present Designation
Name of Present Employer/Organization
2. PROFESSIONAL DETAILS
Particulars

Details

Profession
Field(s) of Specialization
Registration Number
Name of Council/Board
Date of Registration

Page 1 of 6

<!-- page 4 -->

3. ACADEMIC QUALIFICATIONS
Sl. Qualification
N
o.
1
Graduation
2

Post Graduation

3

Ph.D.

4

Additional
Qualification(s)

Subject/Specialization

Year of Percentage/C
Passing
GPA

University/Instit
ution

4. EXPERIENCE
A. Total Experience
Category

Number of Years

Before Post Graduation
After Post Graduation
Academic Experience
Clinical Experience
Research Experience
Administrative Experience
Total Experience
B. Experience Before Post Graduation
Sl. No.

Designation

Institution/Organization

From

To

Nature of Duties

1
2
C. Experience After Post Graduation
Sl. No.

Designation

1
2
3
4

Page 2 of 6

<!-- page 5 -->

5. LEADERSHIP / ADMINISTRATIVE EXPERIENCE
Total Leadership Experience: ________ Years
Sl. No.

Designation

Institution/Organiz
ation

From

To

Administrative
Responsibilities

1
2
3
4

6. DETAILS OF CONTRIBUTION TO ALLIED AND HEALTHCARE PROFESSIONS
A. Policy Formulation / Regulatory Experience

Please provide details of significant contributions made at National, State, Union Territory or
Institutional Level.

B. Education and Training

C. Healthcare Administration

D. Research and Innovation

7. EXPERIENCE IN RURAL / REMOTE / TRIBAL / ISLAND / UNDERSERVED AREAS
Sl. No.

Institution/Organizat Area
ion

Period

Nature of Work

1
2

Page 3 of 6

<!-- page 6 -->

8. PUBLICATIONS
A. Research Publications
Category

Number

PubMed Indexed Publications
Other Peer Reviewed Publications
Books
Book Chapters
Monographs

(Attach separate list)
B. Important Publications

9. RESEARCH PROJECTS / CONSULTANCIES
Sl.
No.
1

Project Title

Funding Agency

Role

Year

Awarding Organization

Year

2
10. AWARDS AND RECOGNITIONS
Sl. No.

Award/Recognition

1
2
3
11. FELLOWSHIPS / MEMBERSHIPS OF PROFESSIONAL BODIES
Sl. No.

Fellowship/Membership

Organization

1
2
3

Page 4 of 6

<!-- page 7 -->

12. EXTRA-CURRICULAR / SOCIAL / PROFESSIONAL ACTIVITIES

13. PRESENT EMPLOYMENT DETAILS
Particulars

Details

Present Post Held
Organization
Nature of Appointment

Permanent / Temporary / Contract

Pay Level / Pay Matrix
Basic Pay
Total Emoluments Drawn
14. DETAILS OF RETIREMENT (IF APPLICABLE)
Particulars

Details

Date of Retirement
Post Held at Retirement
Organization
15. VIGILANCE / DISCIPLINARY STATUS
Particulars

Yes/No

Details

Whether any disciplinary proceedings are pending
Whether any vigilance case is pending/contemplated
Whether any criminal case is pending
Whether any penalty has been imposed during the last 10
years

All relevant documents must be self-attested and enclosed along with the application form.

Page 5 of 6

<!-- page 8 -->

ANNEXURE-II
// DECLARATION //
I hereby declare that all information furnished above is true and correct to the best of
my knowledge and belief. I further declare that I have no conflict of interest that would affect
the discharge of my duties as Chairperson, Andaman and Nicobar Allied and Healthcare
Council.
I understand that if any information furnished by me is found to be false or incorrect,
my candidature/appointment shall be liable to cancellation.
Place: ______________________
Date: _______________________
Full Name and Signature of the Applicant

Page 6 of 6
