---
doc_id: "6a558fafdb4ed21b"
source_url: "https://forest.and.nic.in/WebPages/ActsNRules/NATIONALFORESTPOLICY-1988.pdf"
ministry: "Environment & Forest Department, Andaman & Nicobar"
title: "The National Forest Policy, 1988"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c1cb45233333ef6b"
---

<!-- page 1 -->

NATIONAL FOREST POLICY
1988

GOVERNMENT OF INDIA
MINISTRY OF ENVIRONMENT AND FORESTS
NEW DELHI

<!-- page 2 -->

No. 3-1/86-FP
Ministry of Environment and Forests
(Department of Environment, Forests & Wildlife)
Paryavaran Bhavan, CGO Complex,
Lodi Road, New Delhi - 110003.
Dated the 7th December, 1988.
RESOLUTION
National Forest Policy, 1988
1. PREAMBLE
1.1. In Resolution No.13/52/F, dated the 12th May, 1952, the Government of India in
the erstwhile Ministry of Food and Agriculture enunciated a Forest Policy to be
followed in the management of State Forests in the country. However, over the
years,* forests in the country have suffered serious depletion. This is attributable to
relentless pressures arising from ever-increasing demand for fuel-wood, fo dder and
timber; inadequacy of protection measures; diversion of forest lands to non-forest
uses without ensuring compensatory afforestation and essential environmental
safeguards; and the tendency to look upon forests as revenue earning resource.
The need to review the situation and to evolve, for the future, a new strategy of forest
conservation has become imperative. Conservation includes preservation,
maintenance, sustainable utilisation, restoration, and enhancement of the natural
environment. It has thus become necessary to review and revise the National Forest
Policy.
2. BASIC OBJECTIVES
2.1 The basic objectives that should govern the National Forest Policy - are the
following:
•

Maintenance of environmental stability through preservation and, where
necessary, restoration of the ecological balance that has been adversely
disturbed by serious depletion of the forests of the country.

•

Conserving the natural heritage of the country by preserving the remaining
natural forests with the vast variety of flora and fauna, which represent the
remarkable biological diversity and genetic resources of the country.

•

Checking soil erosion and denudation in the catchment areas of rivers, lakes,
reservoirs in the "interest of soil and water conservation, for mitigating floods
and droughts and for the retardation of siltation of reservoirs.

•

Checking the extension of sand-dunes in the desert areas of Rajasthan and
along the coastal tracts.

<!-- page 3 -->

•

Increasing substantially the forest/tree cover in the country through massive
afforestation and social forestry programmes, especially on all denuded,
degraded and unproductive lands.

•

Meeting the requirements of fuel-wood, fodder, minor forest produce and small
timber of the rural and tribal populations.

•

Increasing the productivity of forests to meet essential national needs.

•

Encouraging efficient utilisation of forest pro duce and maximising substitution
of wood.

•

Creating a massive people's movement with the involvement of women, for
achieving these objectives and to minimise pressure on existing forests.

2.2 The principal aim of Forest Policy must be to ensure environmental stability and
maintenance of ecological balance including atmospheric equilibrium which are vital
for sustenance of all lifeforms, human, animal and plant. The derivation of direct
economic benefit must be subordinated to this principal aim.
3. ESSENTIALS OF FOREST MANAGEMENT
3.1 Existing forests and forest lands should be fully protected and -their productivity
improved. Forest and vegetal cover should be in creased rapidly on hill slopes, in
catchment areas of rivers, lakes and reservoirs and ocean shores and, on semi-arid,
and and desert tracts.
3.2 Diversion of good and productive agricultural lands to forestry should be
discouraged in view of the need for increased food production.
3.3 For the conservation of total biological diversity, the network of national parks,
sanctuaries, biosphere reserves and other protected areas should be strengthened
and extended adequately.

3.4 Provision of sufficient fodder, fuel and pasture, specially in areas adjoining forest,
is necessary in order to prevent depletion of forests beyond the sustainable limit.
Since fuelwood continues to be the predominant source of energy in rural areas, the
programme of afforestation should be intensified with special emphasis on
augmenting fuelwood production to meet the requirement of the rural people.
3.5 Minor forest produce provides sustenance to tribal population and to other
communities residing in and around the forests. Such produce should be protected,
improved and their production enhanced with due regard to generation of
employment and income.
4. STRATEGY

<!-- page 4 -->

4.1 Area under Forests
The national goal should be to have a minimum of one-third of the total land area of
the country under forest or tree cover. In the hills and in mountainous regions, the aim
should be to maintain two-third of the area under such cover in order to prevent
erosion and land degradation and to ensure the stability of the fragile eco-system.
4.2 Afforestation, Social Forestry & Farm Forestry
4.2.1 A massive need-based and time bound programme of afforestation and tree
planting, with particular emphasis on fuelwood and fodder development, on all
degraded and denuded lands in the country, whether forest or non-forest land, is a
national imperative.
4.2.2 It is necessary to encourage the planting of trees alongside of roads, railway
lines, rivers and streams and canals, an d on other unutilised lands under
State/corporate, institutional_ or private ownership. Green belts should be raised in
urban/industrial areas as well as in arid tracts. Such a programme will help to check
erosion and desertification as well as improve the microclimate.
4.2.3 Village and community lands, including those on foreshores and environs of
tanks, not required for other productive uses, should be taken up for the development
of tree crops and fodder resources. Technical assistance and other inputs
necessary for initiating such programmes should be provided by the Government.
The revenues generated through such programmes should belong to the
panchayats where the lands are vested in them; in all other cases, such revenues
should be shared with the local communities in order to provide an incentive to them.
The vesting, in individuals, particularly from the weaker sections (such as landless
labour, small and marginal farmers, scheduled castes, tribals, women) of certain
ownership rights over trees, could be considered, subject to appropriate regulations;
beneficiaries would be entitled to usufruct and would in turn be responsible for their
security and maintenance.
4.2.4 Land laws should be so modified wherever necessary so as to facilitate and
motivate individuals and institutions to undertake tree-farming and grow fodder plants,
grasses and legumes on their own land. Wherever degraded lands should be made
available for this purpose either on lease or on the basis of a tree-patta scheme.
Such leasing of the land should be subject to the land grant rules and land ceiling
laws. Steps necessary to encourage them to do so must be taken. Appropriate
regulations should govern the felling of trees on private holding.
4.3 Management of State Forests
4.3.1 Schemes and projects which interfere with forests that clothe steep slopes,
catchments of rivers, lakes, and reservoirs, geologically unstable terrain and such
other ecologically sensitive areas should be severely restricted. Tropical rain/moist
forests, particularly in areas like Arunachal Pradesh, Kerala, Andaman & Nicobar
Islands, should be totally safeguarded.

<!-- page 5 -->

4.3.2 No forest should be permitted to be worked without - the Government having
approved the management plan, which should be in a prescribed format and in
keeping with the National Forest Policy. The Central Government should issue
necessary guidelines to the State Governments in this regard and monitor
compliance.
4.3.3 In order to meet the growing needs for essential goods and services which the
forests provide, it is necessary to enhance forest cover and productivity of the
forests through the application of scientific and technical inputs. Production forestry
programmes, while aiming at enhancing the forest cover in the country, and meeting
national needs, should also be oriented to narrowing, by the turn of the century, the
increasing gap between demand and supply of fuelwood. No such programme,
however, should entail clear-felling of adequately stocked natural forests. Nor should
exotic species be introduced, through public or private sources, unless long-term
scientific trials undertaken by specialists in ecology, forestry and agriculture have
established that they are suitable and have no adverse impact on native vegetation
and environment.
4.3.4 Rights and Concessions
4.3.4.1 The rights and concessions, including grazing, should always remain related
to the carrying capacity of forests. The capacity itself should be optimised by
increased investment, silvicultural research and development of the area.
Stall-feeding of cattle should be encouraged'. The requirements of the community,
which cannot be met by the rights and concessions so determined, should be met by
development of social forestry outside the reserved forests.
4.3.4.2 The holders of customary rights and concessions in forest areas should be
motivated to identify themselves with the protection and development of forests from
which they derive benefits. The rights and concessions from forests should primarily
be for the bonafide use of the communities living within and around forest areas,
specially the tribals.
4.3.4.3 The life of tribals and other poor living within and near forests revolves around
forests. The rights and concessions enjoyed by them should be fully protected. Their
domestic requirements of fuelwood, fodder, minor forest produce and construction
timber should be the first charge on forest produce. These and substitute materials
should be made available through conveniently located depots at reasonable prices.
4.3.4.4 Similar consideration should be given to scheduled castes and other poor
living near forests. However, the area, which such consideration should cover, would
be determined by the carrying capacity of the forests.
4.3.5 Wood is in short supply. The long-term solution for meeting the existing gap lies
in increasing the productivity of forests, but to relieve the existing pressure on forests
for the demands of railway sleepers, construction industry (particularly in the publicsector), furniture and panelling, mine-pit props, paper and paper board etc.
substitution of wood needs to be taken recourse to. Similarly, on the front of domestic
energy, fuelwood needs to be substituted as far as practicable with alternate sources

<!-- page 6 -->

like bio-gas, LPG and solar energy. Fuel-efficient "Chulhas" as a measure of
conservation of fuelwood need to be popularised in rural areas.
4.4 Diversion of Forest Lands for Non-forest purposes
4.4.1 Forest land or land with tree cover should not be -treated merely as a resource
readily available to be utilised for various projects and programmes, but as a national
asset which requires to be properly safeguarded for providing sustained benefits to
the entire community. Diversion of forest land for any non-forest purpose should be
subject to the most careful examinations by specialists from the standpoint of social
and envir6nmental costs and benefits. Construction of dams and reservoirs, mining
and industrial development and expansion of agriculture should be consistent with
the needs for conservation of trees and forests. Projects which involve such
diversion should at least provide in their investment budget, funds for
regeneration/compensatory afforestation.
4.4.2 Beneficiaries who are allowed mining and quarrying in forest land and in land
covered by trees should' be required to repair and re-vegetate the area in
accordance with established forestry practices. No mining lease should be granted
to any party, private or public, without a proper mine management plan appraised
from the environmental angle and enforced by adequate machinery.
4.5 Wildlife Conservation
Forest Management should take special care of the needs of wildlife conservation,
and forest management plans should include prescriptions for this purpose. It is
specially essential to provide for "corridors" linking the protected areas in order to
maintain genetic continuity between artificially separated sub-sections of migrant
wildlife.
4.6 Tribal People and Forests
Having regard to the symbiotic relationship between the tribal people and forests, a
primary task of all agencies responsible for forest management, including the forest
development corporations should be to associate the tribal people closely in the
protection, regeneration and development of forests as well as to provide gainful
employment to people living in and around the forest. While safeguarding the
customary rights and interests of such people, forestry programmes should pay
special attention to the following:
•

One of the major causes for degradation of forest is illegal cutting and removal
by contractors and their labour. In order to put, an end to this practice,
contractors should be replaced by institutions such as tribal cooperatives,
labour cooperatives, government corporations, etc. as early as possible;

•

Protection, regeneration and optimum collection of minor forest produce along
with institutional arrangements for the marketing of such produce;

<!-- page 7 -->

•

Development of forest villages on par with revenue villages;

•

Family oriented schemes for improving the status of the tribal beneficiaries;
and

Undertaking integrated are a development programmes to meet the needs of the
tribal, economy in and around the forest areas, including the provision of alternative
sources of domestic energy on a subsidised basis, to reduce pressure on the
existing forest areas.
4.7 Shifting Cultivation
Shifting cultivation is affecting the environment .and productivity of land adversely.
Alternative avenues of income, suitably harmonised with the right landuse practices,
should be devised to discourage shifting cultivation. Efforts should be made to
contain such cultivation within the area already affected, by propagating improved
agricultural practices. Area already damaged by such cultivation should be
rehabilitated through social forestry and energy plantations.
4.8 Damage to Forests from Encroachments, Fires and Grazing
4.8.1 Encroachment on forest lands has been on the increase. This trend has to be
arrested and effective action taken to prevent its continuance. There, should be no
regularisation of existing encroachments.
4.8.2 The incidence of forest fires in the country is high. Standing trees and fodder
are destroyed on a large scale and natural regeneration annihilated by such fires.
Special precautions should be taken during the fire season. Improved and modern
management practices should be adopted to deal with forest fires.
4.8.3 Grazing in forest areas should be regulated with the involvement of the
community Special conservation areas, young plantations and regeneration areas
should be fully protected. Grazing and browsing in forest areas need to be controlled.
Adequate grazing fees should be levied to discourage people in forest areas from
maintaining large herds of non-essential livestock.
4.9 Forest-based Industries
The main considerations governing the establishment of forest-based industries and
supply of raw material to them should be as follows:
•

As far as possible, a forest-based industry should raise the raw material
needed for meeting its own requirements, preferably by establishment of a
direct relationship between the factory and the individuals who can grow the
raw material by supporting the individuals with inputs including credit, constant
technical advice and finally harvesting and transport services.

<!-- page 8 -->

•

No forest-based enterprise, except that at the village or cottage level, should
be permitted in the future unless it has been first cleared after a careful scrutiny
with regard to assured availability of raw material. In any case, the fuel, fodder
and timber requirements of the local population should not be sacrificed for this
purpose.

•

Forest-based industries must not only provide employment to local people on
priority but also involve them fully in raising trees and raw-material.

•

Natural forests serve as a gene pool resource and help to maintain ecological
balance. Such forests will not, therefore, be made available to industries for '
undertaking plantation and for any other activities.

•

Farmers, particularly small and marginal farmers, would be encouraged to
grow, on marginal/degraded lands available with them, wood species required
for industries. These may also be grown along with fuel and fodder species on
community lands not required for pasture purposes, and by Forest
department/corporations on degraded forests, not earmarked for natural
regeneration.

•

The practice of supply of forest produce to industry at concessional. prices
should cease. Industry should be encouraged to use alternative raw materials.
Import of wood and wood products should be liberalised.

•

The above considerations will, however, be subject to the current policy
relating to land ceiling and land-laws.

4.10 Forest Extension
Forest conservation programme cannot succeed without the willing support and
cooperation of the people. It is essential, therefore, to inculcate in the people, a direct
interest in forests, their. development and conservation, and to make them conscious
of the value of trees, wildlife and nature in general. This can be achieved through the
involvement of educational institutions, right from the primary stage. Farmers and
interested people should be provided opportunities through institutions like Krishi
Vigyan Kendras, Trainers' Training Centres to learn agrisilvicultural and silvicultural
techniques to ensure optimum use of their land and water resources. Short term
extension courses and lectures should be organised in order to educate farmers. For
this purpose, it is essential that suitable programmes are propagated through mass
media, audio -visual aids and the extension machinery.
4.11 Forestry Education
Forestry should be recogr1is ed both as a scientific discipline as well as a profession.
Agriculture universities and institutions, dedicated to the development of forestry
education should formulate curricula and courses for imparting academic education
and promoting postgraduate research and professional excellence, keeping in view
the manpower needs of the country. Academic and professional qualifications - in

<!-- page 9 -->

forestry should be kept in view for recruitment to the Indian Forest Service and the
State Forest Service. Specialised and orientation courses far developing better
management skills by inservice training need to be encouraged, taking into account
the latest development in forestry and related disciplines.
4.12 Forestry Research
With the increasing recognition of the importance of forests for environmental health,
energy and employment, emphasis must be laid on scientific forestry research,
necessitating adequate strengthening of the research base as well as new priorities
for action. Some broad priority areas of research and development needing special
attention are:
•

Increasing the productivity of wood and other forest produce per unit of area
per unit time by the application of modern scientific and technological methods.

•

Revegetation of barren/marginal/waste/mined lands and watershed areas.

•

Effective conservation and management of existing forest resources (mainly
natural forest eco-systems).

•

Research related to social forestry for rural/ tribal development.

•

Development of substitutes to replace wood and wood products.

•

Research related to wildlife and management of national parks and
sanctuaries.

4.13 Personnel Management
Government policies in personnel management for professional foresters and forest
scientists should aim at enhancing their professional competence and status and
attracting and retaining qualified - and motivated personnel, keeping in view
particularly -the Arduous nature of duties they have to perform, often in remote and
inhospitable places.
4.14 Forest Survey and Data Base
Inadequacy of data regarding forest resources is a matter of concern because this
creates a false sense of complacency. Priority needs to. be accorded to completing
the survey of forest resources in the country on scientific lines and to updating
information. For this purpose, periodical collection, collation and publication of reliable
data on relevant aspects of forest management needs to be improved with recourse
to modern technology and equipment.
4.15 Legal Support and Infrastructure Development

<!-- page 10 -->

Appropriate legislation should be undertaken, supported by adequate infrastructure,
at the Centre and State levels in order to implement the Policy effectively.
4.16 Financial Support for Forestry
The objectives of this revised Policy cannot be achieved without the investment of
financial and other r6sources on a substantial scale. Such investment is indeed fully
justified considering the contribution of forests in maintaining essential ecological
processes and life support systems and in preserving genetic diversity. Forests
should not be looked upon as a source of revenue. Forests are a renewable natural
resource. They are a national asset to be protected and enhanced for the well-being
of the people and the Nation.
(K.P.Geethakrishnan)
Secretary to the Government of India
