---
doc_id: "bbdfbd886a3eef2d"
source_url: "https://dhs.andamannicobar.gov.in/Document/GuidelineInEnglishPMJAY.pdf"
ministry: "Health Department, Andaman & Nicobar"
title: "Guidelines for AB-PMJAY"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "75c1986cab361888"
---

<!-- no text layer: pending OCR -->
