---
doc_id: "ca6aa6fa2da64af8"
source_url: "https://labour.and.nic.in/webPages/pdf/ANI-ChildAdolesceneLabourRehabilitationFundScheme.pdf"
ministry: "Labour, Employment & Training Department, Andaman & Nicobar"
title: "Gazette for A & N Islands Child and Adolescent Labour Rehabilitation Fund Scheme"
date: ""
pages: 4
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "bfc6216dbc12a922"
---

<!-- page 1 -->

(@) | ५
अण्डमान तथा Frente राजपत्र
We ;
Andaman And en Nicobar Gazette
असाधारण
EXTRAORDINARY
प्राधिकार से प्रकाशित
Published by Authority
Bg UE SUR, सोमवार, ठ अगस्त, 2णछ
_ NO, 86, Port Blair, Monday, August 05, 2024 7फहझऔ 86, Port Blair, Monday, August 05, 2024
P-1850927/1/2023-Lab.Ins-I-LAB_AN/747
श्रम आयुक्त एवं डी ई टी का कार्यालय
OFFICE OF THE LABOUR COMMISSIONER & DET
अण्डमान तथा निकोबार प्रशासन
ANDAMAN AND NICOBAR ADMINISTRATION
सप्लाई लाईन, पोर्ट ब्लेयर
SUPPLY LINE, PORT BLAIR- 744101
NOTIFICATION
Port Blair, dated the 5"" August, 2024
No.81/2024/F.No.P-1850927/1/2023-Lab.Ins-I-LAB_AN/747.—In exercise of the powers
conferred by Section 14-B of the Child and Adolescent Labour (Prohibition and Regulation) Act, 1986
read with Government of India, Ministry of Home Affairs Notification No. SO 1081(E) dated 24/11/1988
and in pursuance of Rule 2 (da) of the A & N Islands Child and Adolescent Labour (Prohibition and
Regulation) Rules, 1997, the Lieutenant Governor (Administrator), A & N Islands is pleased to constitute
a scheme namely

4. Short Title, Extent of Application and Commencement :- The scheme shall be called the “A & N
Islands Child and Adolescent Labour Rehabilitation Fund Scheme” and shall be operative within the
Jurisdiction of the Union Territory of A & N Islands from the date of publication of this Notification in
the Official Gazette.

2. Objective :- The objective is to provide statutory financial assistance to the child or adolescent:
rescued in accordance with the provision of the Child and Adolescent Labour (Prohibitions and
Regulation) Act, 1986.

3. Definitions:~ in this Fund, unless the context otherwise requires:-

a. “Act” means the Child and Adolescent Labour (Prohibition and Regulation) Act, 1986.

b. “Appropriate Government’ means in relation to operation of these Funds, the Lt. Governor
(Administrator), A & N Islands.

c. “High Yielding” means high profit deriving scheme of any Nationalized Bank.
All the other terms, which are not defined herein, carry the same Meaning as given under the

Child and Adolescent Labour (Prohibition and Regulation) Act, 1986.

4. Constitution of Fund :- The fund shall comprise of the following :~

i. Amount of the fine released from the employer of the Child and Adolescent as per Section 14-B

(1) of the Act,

<!-- page 2 -->

2 THE ANDAMAN AND NICOBAR EXTRAORDINARY a ER NICOBAR EXTRAORDINARY GAZETTE, AUGUST 05, 2023 AUGUST 05, 2023
A NN SS

ii, An amount of Rs.15,000/- (Rupees Fifteen Thousand only) credited by Secretary (Labour &
Employment), A & N Administration in accordance with Section 14-B (2) of the Act.

ii. As per the directions of the Hon'ble Supreme Court of India in Writ Petition (C) No. 465 / 1986,
dated 10.12.1996, the amount of compensation collected at the rate of Rs. 20,000/- (Rupees
Twenty Thousand Only) per child or adolescent from the employer who engaged the child /
adolescent and the contribution, if any, made by the appropriate Government.

iv. Any other amount permissible to be credited to this fund by order of any Court of Law or by
order of the Appropriate Government.

v. The amount credited to the Fund shall be deposited in Nationalized Banks or invested in high-
yielding schemes as per the directions of the Secretary (Labour & Employment).

vi. The amount deposited or invested and the interest accrued on it, shall be paid to the child or
adolescent, in whose favour such amounts credited or invested in the Nationalized Banks,

vil. In case of any doubts, in opening and operation of the account, Labour Commissioner, A & N
Administration shall seek directions from the Secretary (Labour & Employment) and in such
cases, the directions given by the Secretary (Labour & Employment), is final and binding.

5. Constitution of Advisory Committee :—

i, An Advisory Committee shall be constituted for the purpose of managing the affairs of the fund.

The Committee shall comprise of the following officers :
a. Labour Commissioner e Chairman
b. Assistant Labour Commissioners (Port Blair / Rangat / Hut Bay) e Members
c. Assistant Commissioners (South Andaman / North & Middle
Andaman / Nicobar) ¢ Members
d. Director, Department of Social Welfare e Member
e. Development District Lead Bank Manager (South Andaman /
N & M Andaman / Nicobar) ° Members
f District Child Protection Officer (South Andaman / N & M
Andaman / Nicobar) e Members
g. Labour Inspector, Port Blair e Member Secretary

i, The Committee shall meet periodically, preferably at least once in a quarter to discuss and

decide on all issues related to the management of the fund.
6. Condition for eligibility to receive Fund / Corpus Income :—

i, The Child or Adolescent should have been employed in contravention of the provisions of the
Child and Adolescent Labour (Prohibition and Regulation) Act, 1986.

ii, The Child or Adolescent so employed should have been duly Rescued from the employment.

ili. The Child or Adolescent so rescued shall be admitted in appropriate school, or special training
center or any other learning system established and working as per Section 4 of Right to
Education Act, 2009 or any other system created under law.

iv. The Child or Adolescent admitted to school/college shall continue in school / college.

v. The full details of Child / Adolescent including photographs, Aadhaar card, Mobile number, if
any, shall be collected by the concerned person / Inspector.

vi. The concerned person / Inspector who rescues the Child / Adolescent shall collect the Bank
account details of the Child / Adolescent so rescued or their parents / guardians compulsory or
take steps for opening of a zero balance account in any Nationalized Bank :

Provided that the benefit given to the beneficiary child or adolescent / parent / guardian from the
fund at Sub-clause (iii) of clause 4 ceases to be Operative, if the child would not be sent by the
parent/ guardian for education.

7. Powers and Functions of the Labour Commissioner :— The Labour Commissioner, A & N
Administration shall control and shall be responsible for management of the affairs of the fund
constituted under the scheme, including the following :-

<!-- page 3 -->

THE ANDAMAN AND NICOBAR EXTRAORDINARY GAZETTE, AUGUST 05, 2024 3

i. It shall be his duty to ensure fulfillment of the objective of this scheme including implementation
of the directives of the Supreme Court Judgement and for this purpose, he shall have all powers
to adopt and follow such procedures as he deems fit.

ii, He shall supervise and manage the work of the Inspectors appointed under Section 16 and
Section 17 of the Child and Adolescent Labour (Prohibition and Regulation) Act, 1986 and issue
such directives as are necessary for recovering all the compensation amount from such of the
employees who employ Child or Adolescent in contravention of the provisions of the Act.

iii, He shall initiate all necessary steps expeditiously for getting funds from the Appropriate
Government, as its contribution at the rate of Rs.15,000/- (Rupees fifteen thousand only) per
Child or Adolescent employed in contravention of the provisions of the Act.

iv. He is also empowered to invest Corpus amount in any high yielding scheme. He is also
empowered to determine the quantum of amount to be given to the beneficiary / parents of the
Child / Adolescent labour and that quantum of amount shall be equivalent of the amount earned
on Corpus Fund deposited on behalf of each Child / Adolescent labour.

v. He shall also exercise such powers as deemed fit to prudently Operate the funds to support the
Child / Adolescent rescued.

: 8. Maintenance of Registers :-

i. Aregister shall be maintained by the Assistant Labour Commissioner, in the Office of the Labour
Commissioner, for South Andaman District and the Assistant Labour Commissioner, Rangat and
Hut Bay for North & Middle Andaman and Nicobar District respectively for the purpose of
keeping particulars regarding the list of beneficiaries and that of the Child and Adolescent labour
rescued from employment in contraventions of the provisions of the Act and quantum of amount

हे granted to the parents of the child and all other relevant factors.

ii, The Assistant Labour Commissioner of Port Blair, Rangat and Hut Bay shall send a monthly
statement of their respective District to the Secretary (Labour & Employment), A & N
Administration furnishing the above particulars on or before the 5 of every month.

9. Audit of Funds :- The annual audit of the accounts of the Fund shall be conducted by a Chartered
Accountant, He shall be given access to all the books / information maintained by the ALC (Port
Blair), ALC (Rangat) and ALC (Hut Bay) relating to accounts and vouchers thereto and shall
thereafter sign the Auditor's declaration indication separately on the form under his tour, a statement
showing in what respect he finds the accounts to be incorrect, un- vouchered or not.

The particulars given in this statement shall indicate:

a, Every payment which appears to be unauthorized or contrary to the provisions of the fund;

b. The amount of any deficiency or loss which appears to have been Incurred by the negligence or
misconduct of any person; and

c. The amount of any sum which ought to have been but not brought to account by any person.

By Order and in the name of the Lieutenant Governor
of A & N Islands
Sd/-
j (K. SRINIVASA)
Additional Secretary (Labour)
MGPPB—86/Gazette/2024—35 Copies (P/DTP-2) OO

<!-- page 4 -->

i
