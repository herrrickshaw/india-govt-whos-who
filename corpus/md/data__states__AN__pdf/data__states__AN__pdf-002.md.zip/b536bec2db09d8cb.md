---
doc_id: "b536bec2db09d8cb"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 1
method: "tesseract:eng+hin"
script: "LATIN"
needs_ocr: false
sha1: "6a59547b101ac4f7"
---

<!-- page 1 -->

अण्डमान तथा निकोबार प्रशासन
ANDAMAN AND NICOBAR ADMINISTRATION
निदेशालय पशुपालन एवं पशुसेवा विभाग
Directorate of Animal Husbandry & Veterinary Services
FOR IK
. elt
Port Blair, dated the 18 Jan.,2024
Gs
ORDER NO. 27544
The following transfer and postings amongst the Veterinary Compounders as
Stop - gap arrangement is ordered with effect from 20.01.2024 to 30.01.2024 with
immediate effect.
S.No.| __Name | From _ To
1. Shri.Bhabananda Howlader Veterinary Hospital Veterinary
Junglighat Dispensary,Manglutan
2. | Ms.G.Gangeshwari Training -+ Hospital,
— बा isPKPadhing Lente Dollyguni | Junglighat,
3. Ms.P.K.Fathima -do- -do-
"Note: - S.No, 1 will move first. 7 गम
This has the approval of the competent authority.
Assistant Director(Admn)
F.No.PF/4-1/DAH/T&P/2019-20/
OFFICE ORDER BOOK
COPY TO:
1. The Senior Accounts Officer, DAH&VS, Port Blair for information and necessary action.
2. PA to Director for information of Director(AH&VS).
3. The Senior Veterinary Officer, Zonal Office, LFC, Dollygunj for information.
4. The Senior Veterinary Officer, Veterinary Hospital, Junglighat for information and n.a
5. The Senior Veterinary Officer, Veterinary Hospital, Manglutan for information and n.a
6. The Incharge/SVO, Training Centre, Dollygunj for information and n.a
7. All the concerned Veterinary Compounders & Trainees through their Senior Veterinary
Officers /Incharge for information and necessary action at their end.
8. The Nodal Officer(IT), DAH&VS with the request to upload this Order in the Department’s
website.
9. Personal file of the concerned.
10. Office Copy. a
Sofas
rst 24
i Director (Admn)
\v\l By
