---
doc_id: "1fbdeb7db645a5ca"
source_url: "https://cdnbbsr.s3waas.gov.in/s35352696a9ca3397beb79f116f3a33991/uploads/2025/09/202509261662093513.pdf"
ministry: "Electronics and Information Technology Department, Haryana"
title: "E-Tender ID: 2025_HRY_473189 – Procurement for upgradation of Servers, Storage & IT related Equipment through Central Public Sector Units (PSU’s)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "069a92209253d79b"
---

<!-- page 1 -->

Pre-bid Meeting Notice (E-Tender ID: 2025_HRY_473189)
Procurement for upgradation of Servers, Storage & IT related Equipment through
Central Public Sector Units (PSU’s) –in a Single Bid System for New Haryana
Secretariat, Sector-17, Chandigarh

The Pre-bid meeting will be held through video conference with details as below:
Date & Time: 29.09.2025, 12:00 PM (noon)
Monday, September 29 · 12:00 – 1:00pm
Time zone: Asia/Kolkata
Google Meet joining info
Video call link: https://meet.google.com/kmq-teew-jsx
