---
doc_id: "1fdca7dd25a3a57b"
source_url: "https://cdnbbsr.s3waas.gov.in/s35352696a9ca3397beb79f116f3a33991/uploads/2026/10/202610211905037252.pdf"
ministry: "Electronics and Information Technology Department, Haryana"
title: "Notification Dated – 31.05.2010 – UID Implemention"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "00861b049f6374fd"
---

<!-- page 1 -->

[Extract from

(Extra.), dated

tte
rnment Gaze

Haryana Gove

NT
GOVERNME
Y
TECHNOLOG
FORMATION

HARYANA

T FOR IN

SECRETARIA

सचिवालय

योगिकी
सूचना प्रौद्

9th Floor

2010]

the 31st May,

t

l Secretaria

Haryana Civi
Notification

y, 2010

The 31st Ma

tion

D Implementa

State Level UI
t in the State.
of UID projec

a
sed to constitute
ryana is plea

of Ha
-The Governor
ementation
4/1SIT/1311.
y, Haryana for impl
ar
No. Admn./36
et
cr
Se
f
ie
Ch
of
owing:e Chairmanship
ittee under th
comprise the foll

Comm

mmittee shall

l Implementation Co

The State Leve

Chairman
Member

ary, Haryana
1. Chief Secret
gement
Disaster Mana
Revenue and
y,
ar
et
cr
Se
l
pa
2. Princi

Member

ning
nce and Plan

Member

etary, Fina
ster, Haryana
(o Chief Mini
incipal Secretary

3. Principal Secr
4. Pr

Member

logy
formation Techno

Member

ary, In

cret
5. Principal Se

Member

Health

Principal Secretary,
d Employment
etary, Labour an
cr
Se
l
pa
ci
in
Pr
7.
Supplies
etary, Food and
8. Principal Secr
etary, Education
9. Principal Secr
nchayati Raj
lopment and Pa
ve
De
l
ra
Ru
y,
cretar
10. Principal Se

6.

AI
11. DDGUID

Member
Member

Member

Member

Member Secretary

nee

or his nomi

ion Technology

cretary, Informat

12. Special Se

Te

nces:
rms of Refere

all take all
1. The Committee sh

decisions reia

e with

in the Stat

e UID Project
gaging manpower,
, Procurement, en

tation of th
ted to implemen

cies

Finances. Agen

DAI,
in the State.
ements with UI
UD Project
OUs and agre
tivities of the
ac
d
respect to the M
te
la
re
d
owing
nts, roll out an
ble for the foll
hiring consulta
so be responsi
al
ll
wii
e
te
e Commit
Project.
to above, th
to the UID
2. In addition
issues relating
g
in
lv
so
re
d
nt.
monitoring an

on,
complishme
(3) Coordinati
of
sful project ac
s for succes
st delimitation
on
ti
es
gg
su
y
per the late
ar
s
(a
ss
ce
ts
ne
ya
g
nt
ha
Panc
e and Ce re
(b) Providin
ages of the State,
mes (both Stat
ll
he
vi
sc
of
d
s
re
st
nt
li
ce
d
etc. and
d family
authenticate
individual an
,NREGS, RSBY
e,
se
at
ba
(c) Providing
St
ta
e
da
th
L
in
BP
)
cies
ers (PDS),
the Constituen
ration card hold
e project.
ke database of
li
d)
re
relevant for th
so
be
on
sp
se with UIDAI.
base that may
ta
da
r
he
ot
of State databa
y
g
in
ar
on an
n
sh
io
of
at
t
rm
info
ising ou
PR surveys
solving issues ar
n processes of'N
nitoring and re
ee
mo
,
tw
on
be
ti
ce
na
en
di
ag
(d) Coor
er conver
e residents.
ssness and bett
numbers of th
D
forts for seamle
ef
UI
e
of
iz
e
on
su
hr
is
nc
(e) To sy
ecial invitee.
India and the
sociated as a Sp
the Census of
can be as
nt
me
conducted by
rt
pa
De
e
y or Head of th
tive Secretar
r Administra
rh.
3. Any othe
ll be at Chandiga
of Committee sha
r
te
ar
qu
ad
He
4. The
d when required.
e will meet as an
departments.
5. The Committe
eir respective
drawn from th
be
l
al
sh
s
er
mb
y, by the me
6. TA/DA., if an
Y. S. MALIK,

to
incipal Secretary
issioner and Pr
ana,
Government, Hary
Department.
ation Technology
rm
fo
In
d
an
s
ic
on
ectr

Financial Comm

El

Chandigarh:

10
The 31st May, 20

P., Chd.

47292-C.S.-H.G.
