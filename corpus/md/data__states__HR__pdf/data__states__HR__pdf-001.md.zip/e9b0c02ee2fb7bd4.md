---
doc_id: "e9b0c02ee2fb7bd4"
source_url: "https://www.mansadevi.org.in/pdf/Advtflower7.pdf"
ministry: "Shri Mata Mansa Devi Shrine Board (SMMDSB), Panchkula, Haryana"
title: "Chaiter Mela 2026 tender notice"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "ca7e09da9b3cb4f1"
---

<!-- page 1 -->

I EEEEE_ >> >>, नमक लक क कक क शक कक की कक
‘
>
____ Public Notice/Re-Tender Notice
Sr. | Name of Department /Board/Corp. | Name of Work/Notice/Tender Opening Date EMD/ e-tender portal Nodal Tender No.
No | Authority Closing Date(Time) (Approx.) in Officer/Contact
. Rs. Detail/E-mail
4. | Shri Mata Mansa Devi Shrine Board, | Hiring of Agency for Providing Flower | Start Date 50,000/- https://etenders.hry.nic.in 0272-2920988/ 2026_HBC_49883_4
Panchkula Decoration at Shri Mata Mansa Devi Shrine | 06:00 pm jaimansadevima
www.mansadevi.org.in Complex, Panchkula, HR. 06.03.2026 a@gmail.com
End Date
2:00 AM
2.03.2026
2, | Shri Mata Mansa Devi Shrine Board, | Hiring of Agency for Providing Flower | Start Date 25,000/- https://etenders.hry.nicin 072-2920988/ 2026_HBC_49885_4
Panchkula Decoration at Shri Kali Mata Mandir, Kalka, | 06:00 PM jaimansadevima
www.mansadevi.org.in Panchkula, HR. 06.03.2026 a@gmail.com
End Date
:00 AM
2.03.2026
nets
Ye ५5३०६ Or ps
हे aN शा 2
Meenu aah e patitia
E. (Civ sh Pa
3.6. (५ Rakes SDE
rrr ७५७७क्‍ल्‍ कर...
