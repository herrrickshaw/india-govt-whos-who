---
doc_id: "ae0ecfcd6bf79d50"
source_url: "https://cdnbbsr.s3waas.gov.in/s3cf2226ddd41b1a2d0ae51dab54d32c36/uploads/2026/10/202610291691158111.pdf"
ministry: "Directorate of Secondary Education, Haryana"
title: "Transfer/Adjustment/Guest/Misc. Orders. (29.10.2026)"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cd325d9dfaa21fc4"
---

<!-- page 1 -->

QFFICE OF DIRECTOR GENERAL SECONDARY EDUCATION, H8RYANA
PANCH KULA
Order No. 18/582-2026 PGT-III(9)

Dated Panchkula, the 28.10.2026

Smt. Poonam Kumarl (1027979) PGT English, Government Senior
Se>codary School, Chhapera [869J, Nub is hereby granted ChUd Care Leave w.eJ.
02.11.2026 to 31.12.2026 (60 Days) subject to fulfillment of the prOVision of Rule-46
of Hal'Yana CIvil Services (Leave) Rules, 2016.
Note:-

The applicant shall I'e-joln her services after completion of
stipulated period of child care leave failing which she will be
liable for punitive action.

Endst No. Even

Harpreet Kaur, HCS
Joint Director (MSS)
0/0 Director General Secondary Education,
Haryana Panch kula
Dated Panchkula, the 29.10.2026

Regd Post
A copy is forwarded to the follOWing for information and necessary
action:1. DEO Nuh W.n. letter No. E-l/2026/1700 dated 13.10.2026 to make compliance
with ol·der.
2. The Principal, Government Senior Secodary School, Chhapera (869) Nuh is
hereby directed to make entry of this order In service hook of the incumbent
and maintain the record of child care leave availed by the applicant/Incumbent
as per Rule 46(8) of HCS (Leave) Rules, ZQ16.
2. Smt. Poonam Kumari (1027979) PGT English, Government Senior Secodary
School, Chhapera [869], Nuh [email:- ]
Cell for uploading tile orders on web portal.
5. Office record.

vnT

(2zf!;.v~-al.c.l
__

f

Superj

'-v't

cent PGT-Ill

'!,..e •
.

or Director General Secondary Education,

Haryana, Panchkula

.
•• >

.'

<!-- page 2 -->

OFFICE OF DIRECTOR GENERAL SECONDARY EDUCATION,
HARYANA, PANCHKULA
Order No. 20/387-2024 PGT-IV (2)

Dated, Panchkula, the, 27.10.2026

Smt. Sangeeta, POT Physics, PM Shri Government Senior Secondary
School, Pawti (4303), Block Samalkha, District Panipat is hereby granted Child
Care Leave from 27.10.2026 to 31.03.2027 (156 Days) subject to fulfillment of
the Provision of Rule, 46 of Haryana Civil Services (Leave) Rules, 2016.

J1TENDER KUMAR, lAS
DIRECTOR GENERAL SECONDARY EDUCATION
HARYANA,PANCHKULA
Endst. No. Even
Dated Panchkula, the, .23.10. :?o:2(,
A copy is forwarded to the following for information and necessary

action:1.

District Education Officer, Panipat vide their letter No. E-2/26/775
Dated 12.10.2026.

2.

Principal, PM SJ"l..1i Government Senior Secondary School, Pawti (4303),
Block Samalk..':ta, District Panipat is directed to ensure that the eeL
orders to be updated in the service book.

3.

Smt. Sangeeta, PGT Physics, PM Shri Government Senior Secondary
School, Pawti (4303), Block Samalkha, District Panipat.

'vi!(' iT Cell for uploading the orders on website of Directorate.

~("J-{,

Superintendent, PGT-IV,
for Director General Secondary Education,
Haryana,Panchkula

'U

<!-- page 3 -->

OFFICE OF DIRECTOR GENERAL SECONDARY EDUCATION

HARYANA,PANCHKULA
ORDER
Order No. 12/33-2025 HRlVIE-I(6)

Dated Panchkula, the 23.10.2026

Child Care Leave is hereby granted to Smt. Shilpa Nagar, Clerk, 0 I [)
Block Eduation Officer, Hisar w.e.f28.10.2026 to 18.01.2027 (83 Days) subject
to fulfillment of provisions as per Rule 46 of HCS (Leave) Rules, 2016.
Note:-

The applicant shall re-join her services after completion of
stipulated period of child care "leave failing which she will be
liable for punitive action.
Harpreet Kaur, Res
Joint Director (WISS)
0/0 Director General Secondary Education,
Haryana Panchkula
Dated, Panchkula, the ?-!11~)').»rv6

Endst. No. Even

A copy of above is forwarded to the following for information and
necessary action:1. The District Education Officer, Risar.

2. Block Eduation Officer, Hisar is hereby directed to make entry in Service
book for the said period.
3 ...flmt. Shilpa Nagar, Clerk, 010 Block Eduation Officer, Hisar.
...A( IT Cell for uploading the orders on website.

bt~I~6

Superintendent HRME-I
for Director General Secondary Education
--<t Haryana, Panchkula

<!-- page 4 -->

GOVERNMENT OF HARYANA 1 ~ 'fIffiR

r:m:n. m"lifn C!lt tqlr,m'

Directorate School Education
~fuan~IRYm

EJ....'Itl..... C.,lt....., ,.f\J O.,d"p<;l~'"

r'(~tlii'1;~,q~ljM:f.il.~";j~-t'i)

!U \~.Mt~~~!·~~J.~.t!!

'W«r'ttr?:tl""l~
l.<Uld '11<1 nom n;:ltkJ\'::'~A tv r '1'1.'

www.schooleducationharyana.gov.in l.edusec~ndaryhry@pn~iLcom
Off.: Shiksha Sadan, Sector 5, Panchkula, Haryana 134109 (India) - Tel: 91(0172)-2560246 Fax: 91(0172)-2560253
'liRlfum; film '!IG'f, ~ 5 ~1>1109 ('Iffil) W'J'I; 91 (0172) 2560246
91 (0172) 2560253

m:

ORDER
No. 4/39-2026 HRME-l (4)
Dated 15.10.2026
In continuation of this order No.4/39-2026 HRME-I (4) dated 30.06.2026:
02.07.2026. the deputation period of Sh. Rakesh Kumar (037015). Clerk % DI':O
Yamunanagal' (4610) to GHS Nanda!. Rohtak (2758) is further extend for 90 days or till
implementation of online transfer drive for said cadre. whichever is earlier.
Note:l.
The officer/official will be relieved immediately.
2.
No T AiDA and joining time will be admissible to the officer/official if he/sh<:
has been shifted on his/her request after exercising option.
3.
If any discrepancy is noticed in this order or there is a violation of transl"r
policy, it should be brought to the notice of Competent Authority/Concerned
branch within three days and the order be not implemented.
4.
The officer/official will update his profile in MIS Portal when helshe
join/relieve 1Tom his present working station and also supply the information 10
the Directorate.
5.
Concerned 000 is also requested to update and approved MIS data of thL'
officer/official at your own level.

JlTENDER KUMAR, lAS
DlRECTOR GENERAL SECONDARY EDUCAnON
HARYANA, PANCHKULA

(?IIU

Endst No. 4/39-2026 HRME-I (4)
Dated, Panchlmla, the J!:-?
A copy is forwarded to the following for information and necessary action:1.
Accountant General (A&E). Haryana, Chandigarh.
2.
OSD/CM w.r.t. dispatch No. 46773 dated 07.10.2026.
3.
District Education Officer Yamunanagar & Rohtak.
4.
l-Ieamaster, Govt High School Nandal (2758), Rohtak.
5.
Treasury Officer concerned.
~ .../ Sh. Rakesh Kumar (037015), Clerk. % DEO Yan1Unanagar.
q: IT Cell (H.Q) for uploading the order on official website.

~tl'lS

SUPERINTENDENT HRME-l
for DlRECTOR GENERAL SECONDARY EDUCAnON
~ARYANA,PANCHKULA

t;i\
~

D:'v\sSistullt 4\Transfer and Adjllslmcnl\Ordcr\Tr:lnsrcr Advisory.docx

<!-- page 5 -->

OFFICE OF DIRECTOR GENERAL SECONDARY EDUCATION,
HARYANA,PANCHKULA
Order No. 20/442-2026 PGT-IV (2)

Dated, Panchkula, the 28.10.2026

Smt. Renu Bala, PGT Physics, CMEEEGSSS Aherwan
[3424], Fatehabad is hereby granted the Child Care Leave from
29.10.2026 to 31.12.2026 (64 days) subject to fulfIllment of the
Provision of Rule, 46 of Haryana Civil Services (Leave) Rules, 2016.

DR. RICHA RATHEE, HCS

ADDITIONAL DIRECTOR (ADMN.)
0/0 DIRECTOR GENERAL SECONDARY EDUCATION
HARYANA, PANCHKULA
Endst. No. Even

Dated Panchkula, the: 28.10.2026

A copy is forwarded to the following for information and
necessary action:1.

District Education Officer, Fatehabad in reference of your
office letter No. E-I-2026/2258 dated 14.10.2026.

2.

Principal, CMEEEGSSS Aherwan [3424], Fatehabad is directed
to ensure that the CCL orders to be updated in her service
book.

3.

Smt. Renu Bala, PGT Physics, CMEEEGSSS Aherwan [3424],
Fatehabad.

/

LT Cell for uploading the orders on website of Directorate.

~~o1.?i'O,~,

\ArSuperintendent PGT-IV
for Dire~orJXeneralSecondary Education
~aryana, Panchkula

<!-- page 6 -->

GOVERNMENT OF HARYANA/~"ffiQjf(

lmu, ~ "'" ~

Directorate School Education
~ftraTr~

EducatiDn, Culture and Devdopmcnt

q>ffil- "IT _f<rq
Lead mc from Darkness to Light

Off: Shiksha Sadan, Sector 5, Panch kula, Haryana-134109(lndia) - Tel: 91(0172)-Z560Z46 Fax: 91(0172)-Z560Z53
~: fmr <lG'I. 'ilm 5 ~-134109 ('lffiI) '?'J!1l: 91 (0172) 2560246
91 (0172) 2560253

m:

e-mail: edusecondaryhry(aJgmail.com - site: www.schooleducationharyana_gov_in

To be substuted bearing Same Number and Date

To
The District Education Officer
Kamal
Memo No. 21/86-2026 HRME-l (3)
Dated Panchkula, the
Subject:-

Regarding No Objection Certificate in Hew of deputation in Govt.
of Haryana Branch of Future, Haryana.

*******
In reference the subject cited above.
No ubejection certificate is hereby issued to Sh. Arun Kumar, Clerk
Government Middle School Halwana (Kamal)(4268) on his selection to the post
of Clerk & Sh. Gu1ab Sharma, Peon-cum-Chowkidar % BEO lndri, Kamal on
his selection to the post of Peon-cum-Chowkidar on deputation basis for one
year in the Directorate of Furute Department, Haryana, Panchkula, subjecl lo
the fulfilment of following terms and conditions'1. He/She will get relieved fr-;)fn the Concerned School/Office.
2.

In case any dues and pendency of any inquiry comes to the
notice of the DeparIJ11cnt against the official then this NOC will
deemed to be stood cancelled.

srl--

Superintendent HRME-I
for Director General Secondary Education,
Haryana, Panchkula
Endst. No. Even
Dated:- ;'23-1o-~U
A copy is forwarded to the following for information and necessary
action please'1. Dil "ctorate of Furute Department, Haryana, Panchkula.
2. Block Education Officer, 1nOO, District Kamal.
3. Sh. Arun Kumar, Clerk ,Govemment Middle School Halwana Disu'ict Karnal
4. Sh. Gulab Sharma. Peon-cum.-Chowkidar % Block Education Officer, Indr;.
District Karnal
IT Cell.

V

~,c

Superintendent HRlVIE-I
for Director General Secondary Education,
Haryana, ~anchkula
D;\Mamta\Hindi Letters With Logo - 2024.Docx

$\
~J.
@
.•..
