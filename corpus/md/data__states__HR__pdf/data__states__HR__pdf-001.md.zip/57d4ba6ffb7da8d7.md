---
doc_id: "57d4ba6ffb7da8d7"
source_url: "https://fdaharyana.gov.in/PDF/DepartmentalServiceRules/Group%20B%20Service%20Rules%20Field.pdf"
ministry: "Food and Drugs Administration Department, Haryana"
title: "Group B Service Rules Field"
date: ""
pages: 33
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3d447fc08934e303"
---

<!-- page 1 -->

Haryana Government Gazette
EXTRAORDINARY
Published by Authority
© Govt. of Haryana
No. 191-2018/Ext.] CHANDIGARH, TUESDAY, NOVEMBER 13, 2018 (KARTIKA 22, 1940 SAKA)

gfj;k.kk ljdkj
[kk| rFkk vkS"kf/k iz’kklu foHkkx
vf/klwpuk
fnukad 13 uoEcj] 2018
la[;k lk- dk-fu-@lfo-@vuqPNsn 309@30@13@2017&5,p0ch0&III.— Hkkjr ds lafo/kku ds
vuqPNsn 309 ds ijUrqd }kjk iznŸk 'kfDr;ksa dk iz;ksx djrs gq,] gfj;k.kk ds jkT;iky] blds }kjk]
gfj;k.kk [kk| rFkk vkS"kf/k iz’kklu foHkkx v/khuLFk dk;kZy; ¼oxZ [k½ lsok esa fu;qDr O;fDr;ksa dh HkrhZ
rFkk mudh lsok dh 'krksZa dks fofu;fer djus ds fy, fuEufyf[kr fu;e cukrs gaS] vFkkZr~%&
Hkkx&I&lkekU;
¼1½ ;s fu;e gfj;k.kk [kk| rFkk vkS"kf/k iz’kklu foHkkx v/khuLFk dk;kZy; ¼oxZ [k½ lsok laf{kIRk uke rFkk
izkjEHkA
fu;e] 2018] dgs tk ldrs gSaA
¼2½ ;s blds izdk’ku dh frfFk ls ykxw gksx
a sA
ifjHkk"kk,aA
2.
bu fu;eksa esa] tc rd lanHkZ ls vU;Fkk visf{kr u gks] &
¼d½ ^^vk;ksx** ls vfHkizk; gS] gfj;k.kk yksd lsok vk;ksx(
¼[k½ ^^lh/kh HkrhZ** ls vfHkizk; gS] lsok esa ls inksUufr }kjk ;k Hkkjr ljdkj ;k fdlh jkT;
ljdkj dh lsok esa igys ls yxs fdlh in/kkjh ds LFkkukUrj.k ls vU;Fkk dh xbZ dksbZ
fu;qfDr(
¼x½ ^^ljdkj** ls vfHkizk; gS] iz’kkldh; foHkkx esa gfj;k.kk ljdkj (
¼?k½ ^^laLFkk** ls vfHkizk; gS]&
(i)
gfj;k.kk jkT; esa ykxw fof/k }kjk LFkkfir dksbZ LkaLFkk ( ;k
(ii)
bu fu;eksa ds iz;kstu ds fy, ljdkj }kjk ekU;rkizkIRk dksbZ vU; laLFkk (
¼M+½ ^^ekU;rkizkIr fo”ofo|ky;** ls vfHkizk; gS] &
(i)
Hkkjr esa fof/k }kjk fuxfer dksbZ fo’ofo|ky; ( ;k
(ii)
dksbZ vU; fo’ofo|ky;]tks bu fu;eksa ds iz;kstu ds fy, ljdkj }kjk
ekU;rkizkIr fo’ofo|ky; ?kksf’kr fd;k x;k gks (
¼p½ ^^lsok** ls vfHkizk; gS] gfj;k.kk [kk| rFkk vkS"kf/k iz’kklu foHkkx v/khuLFk dk;kZy;
¼oxZ [k½ lsokA
1.

(3549)

<!-- page 2 -->

3550

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Hkkx&II lsok esa HkrhZ
inksa dh la[;k
vkSj Lo:IkA

lsok esa bu fu;eksa ds ifjf’k"V d esa n’kkZ, x, in 'kkfey gksaxs %
ijUrq bu fu;eksa dh dksbZ Hkh ckr ,sls inksa dh la[;k esa o``f) ;k deh djus ;k fofHkUUk inukeksa
vkSj osruekuksa okys u, in LFkk;h vFkok vLFkk;h :i ls cukus ds fy, ljdkj ds vUrfuZfgr vf/kdkj
ij izHkko ugha MkysxhA

lsok esa fu;qDr
fd, x,
mEehnokjksa dh
jk"Vªh;rk
vf/kokl rFkk
pfj=A

4.
¼1½ dksbZ Hkh O;fDr] lsok esa fdlh in ij rc rd fu;qDr ugha fd;k tk,xk] tc rd fd
og fuEufyf[kr u gks]&
¼d½ Hkkjr dk ukxfjd ( ;k
¼[k½ usiky dh iztk ( ;k
¼x½ HkwVku dh iztk %
ijUrq izoXkZ ¼[k½ ;k ¼x½ ls lacaf/kr ,slk O;fDr gksxk ftlds i{k esa Hkkjr ljdkj }kjk
ik=rk dk izek.k&i= tkjh fd;k x;k gksA
¼2½ dksbZ Hkh O;fDr] ftldh n’kk esa ik=rk dk izek.k&i= vko”;d gks] vk;ksx ;k fdlh
vU; HkrhZ izkf/kdj.k }kjk lapkfyr ijh{kk ;k lk{kkRdkj ds fy, izfo"V fd;k tk ldrk gS] fdUrq
fu;qfDr dk izLrko mls dsoy Hkkjr ljdkj }kjk vko”;d ik=rk izek.k&i= tkjh fd, tkus ds ckn
gh fn;k tk ldrk gSA
¼3½ dksbZ Hkh O;fDr] lsok esa fdlh in ij lh/kh HkrhZ }kjk rc rd fu;qDRk ugha fd;k tk,xk
tc rd og viuh vafre mifLFkfr ds fo’ofo|ky;] egkfo|ky;] fo|ky; ;k laLFkk] ;fn dksbZ gks] ds
iz/kku] 'kS{kf.kd vf/kdkjh ls pfj= izek.k&i= vkSj nks vU; ftEesnkj O;fDr;ksa ls tks mlds laca/kh u
gkas] fdUrq mlds O;fDrxr thou esa ml ls Hkyh&Hkkafr ifjfpr gkas vkSj tks mlds fo’of|ky;]
egkfo|ky;] fo|ky; ;k laLFkk ls lacaf/kr u gkas] mlh izdkj ds izek.k&i= izLrqr u djsA

vk;qA

5.
dksbZ Hkh O;fDr lsok esa fdlh in ij lh/kh HkrhZ }kjk fu;qDr ugha fd;k tk,xk] tks vk;ksx ;k
fdlh vU; HkrhZ izkf/kdj.k dks vkosnu djus dh vfUre frfFk ls Bhd igys ekl ds izFke fnu dks
fuEufyf[kr of.kZr ds vuqlkj U;wure vk;q lhek ls de vkSj vf/kdre vk;q lhek ls vf/kd dk gksA

3.

Øe
la[;k

inuke

U;wure vk;q lhek ¼o"kZ½

vf/kdre vk;q lhek ¼o"kZ½

1

jktdh; fo’ys"kd

25

42

2

ofj"B oSKkfud vf/kdkjh
¼thok.kq foKku½

22

42

3

ofj"B oSKkfud vf/kdkjh
¼nok jlk;u 'kkL=½

22

42

4

ofj"B oSKkfud vf/kdkjh
¼vkS"k/k foKku½

22

42

5

vkS"kf/k fu;a=.k vf/kdkjh

21

42

6

[kk| lqj{kk vf/kdkjh

21

42

lsok esa inksa ij fu;qfDr;ka ljdkj }kjk dh tk,axhA

fu;qfDr
izf/kdkjhA

6.

vgZrk,aA

7.
dksbZ Hkh O;fDr] lsok esa fdlh Hkh in ij rc rd fu;qDr ugha fd;k tk,xk] tc rd og lh/kh
HkrhZ dh n’kk esa] bu fu;eksa ds ifjf’k"V [k ds [kkuk 3 esa vkSj lh/kh HkrhZ ls vU;Fkk fu;qfDr dh n’kk
esa] iwoksZDr ifjf’k"V [k ds [kkuk 4 esa fofufnZ"V vgZrk,a rFkk vuqHko u j[krk gks%
ijUrq lh/kh HkrhZ }kjk fu;qfDr dh n’kk esa ;fn visf{kr vuqHko j[kus okys vuqlwfpr tkfr;ksa]
fiNM+s oxksZ] HkwriwoZ lSfudksa vkSj 'kkjhfjd :i ls fodykax mEehnokj i;kZIr la[;k muds fy, vkjf{kr
fjDr inksa dks Hkjus ds fy, miyC/k u gks] rks HkrhZ izkf/kdj.k ds foosd ij vuqHko lEca/kh vgZrkvksa esa
ipkl izfr’kr rd dh <hy nh tk ldrh gS] ,slk djus ds fy, fyf[kr :i esa dkj.k fn, tk,axsA

<!-- page 3 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
fujgZrk,aA
dksbZ Hkh O;fDr] &
¼d½ ftlus thfor ifr@iRuh okys O;fDr ls foOkkg dj fy;k gS ;k fookg dh lafonk dj
yh gS % ;k
¼[k½ ftlus ifr@ iRuh ds thfor gkssrs gq,] fdlh vU; O;fDr ls fookg dj fy;k gS ;k
fookg dh lafonk dj yh gS]
lsok esa fdlh Hkh in ij fu;qfDr dk ik= ugha gksxk%
ijUrq ;fn ljdkj dh lUrqf"V gks tk, fd ,sls O;fDr rFkk fookg ds nwljs i{k ij ykxw Loh;
fof/k ds v/khu ,slk fookg vuqKs; gS rFkk ,slk djus ds vU; vk/kkj Hkh gaS] rks og fdlh O;fDr dks
bl fu;e ds ykxw gksus ls NwV ns ldrh gSA
HkrhZ dk <axA
9.
(1)
lsok esa HkrhZ fuEufyf[kr <ax ls dh tk,xh]&
¼1½
ofj"B jktdh; fo’ys"kd dh n’kk es&
a
(i)
jktdh; fo’ys"kd@ofj"B oSKkfud vf/kdkjh ¼thok.kq foKku½@ofj"B
oSKkfud vf/kdkjh ¼vkS"k/kh; jlk;u½@ofj"B oSKkfud vf/kdkjh
¼vkS"k/k foKku½ esa ls inksUufr }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼2½
jktdh; fo’ys"kd dh n’kk es&
a
(i)
lh/kh HkrhZ }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼3½ inkfHkfgr vf/kdkjh dh n’kk esa&
(i)
[kk| lqj{kk vf/kdkjh esa ls inksUufr }kjk( ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼4½
ofj"B vkS"kf/k fu;a=.k vf/kdkjh dh n’kk esa&
(i)
vkS"kf/k fu;a=.k vf/kdkjh esa ls inksUufr }kjk ( ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼5½
mi yksd fo’ys"kd dh n’kk esa&
(i)
lgk;d yksd fo’ys"kd esa ls inksUufr }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼6½
ftyk yksd fo’ys"kd dh n’kk esa &
(i)
lgk;d yksd fo’ys"kd esa ls inksUufr }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼7½
ofj"B oSKkfud vf/kdkjh ¼thok.kq foKku½ dh n’kk esa&
(i)
lh/kh HkrhZ }kjk % ;k
(ii) fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼8½
ofj"B oSKkfud vf/kdkjh ¼vkS"k/kh; jlk;u½ dh n’kk esa&
(i)
lh/kh HkrhZ }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼9½ ofj"B oSKkfud vf/kdkjh ¼vkS"k/k foKku½ dh n’kk esa&
(i)
lh/kh HkrhZ }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
8.

3551

<!-- page 4 -->

3552

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

¼10½

v/kh{kd dh n’kk esa&
(i)
mi v/kh{kd esa ls inksUufr }kjk % ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh@deZpkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼11½ vkS"kf/k fu;a=.k vf/kdkjh dh n’kk esa&
(i)
lh/kh HkrhZ }kjk( ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼12½ [kk| lqj{kk vf/kdkjh dh n’kk esa&
(i)
lh/kh HkrhZ }kjk% ;k
(ii)
fdlh jkT; ljdkj ;k Hkkjr ljdkj dh lsok esa igys ls gh yxs fdlh
vf/kdkjh ds LFkkukUrj.k ;k izfrfu;qfDr }kjkA
¼2½
lHkh inksUufr;ka] tc rd vU;Fkk ls micfU/kr u gks] T;s"Brk ,oa ;ksX;rk ds vk/kkj ij
dh tk,axh vkSj dsoy T;s"Brk gh ,slh inksUufr;kas ds fy, dksbZ vf/kdkj iznku ugha djsxhA
ifjoh{kkA

10.
¼1½ lsok esa fdlh Hkh in ij fu;qDr O;fDr] ;fn og lh/kh HkrhZ }kjk fu;qDr fd;k x;k gks]
rks nks o"kZ dh vof/k ds fy, vkSj ;fn vU;Fkk fu;qDr fd;k x;k gks] rks ,d o"kZ dh vof/k ds fy,
ifjoh{kk ij jgsxk %
ijarq(&
¼d½ ,slh fu;fqDRk ds ckn fdlh vuq:i ;k mPprj in ij izfrfu;qfDr ij O;rhr dh
xbZ dksbZ vof/k ifjoh{kk dh vof/k esa fxuh tk,xh (
¼[k½ LFkkukUrj.k }kjk fdlh fu;qfDr dh n’kk esa] lsok esa fdlh in ij fu;qfDr ls
igys] fdlh led{k vFkok mPprj in ij fd, x, dk;Z dh dksbZ vof/k]
fu;qfDr izkf/kdkjh ds foosd ij] bl fu;e ds v/khu fu;r ifjoh{kk vof/k dh
vksj fxuus dh vuqefr nh tk ldrh gS( vkSj
¼x½ LFkkukiUu fu;qfDr dh dksbZ Hkh vof/k ifjoh{kk ij O;rhr dh xbZ vof/k ds :i
esa fxuh tk,xh] fdUrq dksbZ Hkh O;fDr ftlus ,sls LFkkukiUu :i esa dk;Z fd;k
gS] ifjoh{kk dh fofgr vof/k iwjh gksus ij] fdlh fjfDr ij iq"V fd, tkus dk
gdnkj ugha gksxkA
¼2½ ;fn fu;qfDr izf/kdkjh dh jk; esa ifjoh{kk dh vof/k ds nkSjku fdlh O;fDr dk dk;Z ;k
vkpj.k larks"ktud u jgk gks] rks og(&
¼d½ ;fn ,slk O;fDr lh/kh HkrhZ }kjk fu;qDr fd;k x;k gks] rks mls mldh lsokvksa ls
vyx dj ldrk gS ( vkSj
¼[k½ ;fn ,slk O;fDr lh/kh HkrhZ ls vU;Fkk fu;qDr fd;k x;k gks] rks] &
(i)
mls mlds iwoZ in ij izfrofrZr dj ldrk gS ( ;k
(ii)
mlds laca/k esa fdlh ,slh vU; jhfr esa dkjZokbZ dj ldrk gS tks mldh
iwoZ fu;qfDr ds fuca/ku rFkk 'krsZa vuqKkr djsA
¼3½ fdlh O;fDr dh ifjoh{kk vof/k iwjh gksus ij] fu;qfDr izf/kdkjh(&
¼d½ ;fn mldh jk; esa mldk dk;Z ;k vkpkj.k larks"ktud jgk gks] rks] &
(i)
,sls O;fDr dk]s ;fn og fdlh LFkk;h fjfDr ij fu;qDr fd;k x;k gks
mldh fu;qfDr dh frfFk ls iq"V dj ldrk gS ( ;k
(ii) ,sls O;fDr dks ;fn og fdlh vLFkk;h fjfDr ij fu;qDr fd;k x;k gk]s
rks mls LFkk;h fjfDr gksus dh frfFk ls iq"V dj ldrk gS (
(iii) ;fn dksbZ LFkk;h fjfDRk u gk]s rks ?kksf"kr dj ldrk gS fd mlus viuh
ifjoh{kk vof/k larks"ktud <ax ls iwjh dj yh gS ( ;k

<!-- page 5 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

¼[k½

;fn mldk dk;Z ;k vkpj.k mldh jk; esa larks"ktud u jgk gks] rks] &
(i)
;fn og lh/kh HkrhZ }kjk fu;qDr fd;k x;k gks] rks mls lsok ls gVk
ldrk gS] vkSj ;fn vU;Fkk fu;qDr fd;k x;k gks] rks mls mlds iwoZ in
ij izfrofrZr dj ldrk gS ;k mlds laca/k esa ,slh vU; jhfr esa dkjZokbZ
dj ldrk gS] tks mldh iwoZ fu;qfDr ds fuca/ku rFkk 'krsZa vuqKkr djs(
;k
(ii) mldh ifjoh{kk vof/k c<+k ldrk gS vkSj mlds ckn ,sls vkns’k ikfjr
dj ldrk gS tks og ifjoh{kk dh izFke vof/k dh lekfIr ij dj
ldrk Fkk %
ijUrq ifjoh{kk dh dqy vof/k] ftlesa c<+kbZ xbZ vof/k] ;fn dksbZ gS] Hkh 'kkfey
gS] rhu o"kZ ls vf/kd ugha gksxhA
lsok ds lnL;ksa dh ijLij T;s"Brk lsok esa fdlh Hkh in ij] muds yxkrkj lsok dky ds T;s"BrkA
vuqlkj fuf’pr dh tk,xh %
ijUrq tgka lsok esa fofHkUu laoxZ gks] ogka izR;sd laoxZ ds fy, T;s"Brk vyx&vyx fuf’pr
dh tk,xh %
ijUrq ;g vkSj fd lh/kh HkrhZ }kjk fu;qDr lnL;ksa dh n’kk esa] T;s"Brk fu;r djrs le;
vk;ksx }kjk fu/kkZfjr ;ksX;rk Øe Hkax ugha fd;k tk,xk %
ijUrq ;g vkSj fd ,d gh frfFk dks fu;qDr nks ;k nks ls vf/kd lnL;ksa dh n’kk esa mudh
T;s"Brk fuEufyf[kr :i ls fuf’pr dh tk,xh%&
¼d½ lh/kh HkrhZ }kjk fu;qDr lnL; inksUufr ;k LFkkUkkUrj.k }kjk fu;qDr lnL; ls T;s"B
gksxk (
¼[k½ inksUufr }kjk fu;qDr lnL;] LFkkukUrj.k }kjk fu;qDr lnL;ksa ls T;s"B gksxk (
¼x½ inksUufr }kjk vFkok LFkkukUrj.k }kjk fu;qDr lnL;ksa dh n’kk esa] T;s"Brk ,slh
fu;qfDr;ksa esa ,sls lnL;ksa dh T;s"Brk ds vuqlkj fuf’pr dh tk,xh] ftuls ;s inksUUkr
;k LFkkukrfjr fd, x, Fks ( vkSj
¼?k½ fofHkUUk laoxksZa ls LFkkukUrj.k }kjk fu;qDr lnL;ksa dh n’kk esa] mudh T;s"Brk osru ds
vuqlkj fuf’pr dh tk,xh] vf/keku ,sls lnL; dks fn;k tk,xk tks viuh igys dh
fu;qfDr esa mPPkrj in ij osru ys jgk Fkk] vkSj ;fn feyus okys osru dh nj Hkh
leku gks] mudh fu;qfDr;ksa esa muds lsok dky ds vuqlkj] vkSj ;fn lsok dky Hkh
leku gk]s rks vk;q esa cM+k lnL; vk;q esa NksVs lnL; ls T;s"B gksxkA

11.

¼1½ lsok dk dksbZ Hkh lnL;] fu;qfDr izkf/kdkjh }kjk] gfj;k.kk jkT; esa vFkok mlds ckgj lsok djus dk
nkf;RoA
fdlh Hkh LFkku ij] lsok djus ds fy, vkns’k fn, tkus ij ,slk djus ds fy, nk;h gksxkA
¼2½ lsok ds fdlh lnL; dks lsok ds fy, fuEufyf[kr ds v/khu Hkh izfrfu;qDr fd;k tk
ldrk gS]&
(i)
dksbZ dEiuh] laxe ;k O;f"V&fudk;] pkgs og fuxfer gks ;k ugha] ftldk iw.kZ
;k vf/kdka’k LokfEkRo ;k fu;=a.k jkT; ljdkj ds ikl gS] ;k gfj;k.kk jkT; ds
Hkhrj] uxj fuxe ;k LFkkuh; izkf/kdj.k(
(ii)
dsUnzh; ljdkj ;k ,slh daiuh] laxe ;k O;f"V fudk;] pkgs og fuxfer gks ;k
ugha] ftldk iw.kZ ;k vf/kdka’k LokfEkRo ;k fu;a=.k dsUnzh; ljdkj ds ikl gksa ;
;k
(iii) dksbZ vU; jkT; ljdkj] vUrjkZ"Vªh; laxBu] Lok;r fudk;] ftldk fu;a=.k
jkT; ljdkj ds ikl u gks ;k dksbZ xSj&ljdkjh fudk;%
ijUrq lsok ds fdlh Hkh lnL; dks mldh lgefr ds fcuk [k.M ¼ii½ ;k [k.M ¼iii½ esa fufnZ"V
dsUnzh; ;k fdlh vU; jkT; ljdkj ;k fdlh laxBu ;k fudk; dh lsok ds v/khu izfrfu;qDr ugha
fd;k tk,xkA

12.

3553

<!-- page 6 -->

3554

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

osru] NqV~Vh]
isa’ku rFkk vU;
ekeysA

13.
¼1½ osru] NqV~Vh] is’a ku rFkk vU; lHkh ekeyksa ds laCka/k esa ftudk bu fu;eksa esa Li"V :i
ls micU/k ugha fd;k x;k gS] lsok ds lnL; gfj;k.kk flfoy lsok ¼lkekU;½ fu;e] 2016] gfj;k.kk
flfoy lsok ¼osru½ fu;e] 2016] gfj;k.kk flfoy lsok ¼vodk’k½ fu;e] 2016] gfj;k.kk flfoy lsok
¼ljdkjh deZpkjh HkŸks½ fu;e] 2016] gfj;k.kk flfoy lsok ¼lkekU; Hkfo"; fuf/k½ fu;e] 2016] gfj;k.kk
flfoy lsok ¼ljdkjh deZpkjh vkpj.k½ fu;e] 2016] gfj;k.kk flfoy lsok ¼n.M rFkk vihy½ fu;e]
2016] gfj;k.kk flfoy lsok ¼;k=k HkŸkk½ fu;e] 2016] gfj;k.kk flfoy lsok ¼is’a ku½ fu;e] 2016 rFkk
,sls fofu;eksa }kjk 'kkflr gksaxs tks l{ke izkf/kdkjh }kjk Hkkjr ds lafo/kku ds v/khu ;k jkT; fo/kku
e.My }kjk cukbZ xbZ rFkk ml le; ykxw fdlh fof/k ds v/khu viuk, vFkok cuk, x, gksa vFkok
blds ckn viuk, ;k cuk, tk,a%
ijarq gfj;k.kk flfoy lsok ¼isa’ku½ fu;e] 2016 ds mica/k mu lsok ds lnL;ksa dks ykxw ugha
gksaxs tks izFke tuojh] 2006 dks ;k mlds ckn fu;qDr fd, x, gSa ¼e`R;q ,oa lsok fuo`fr minku dks
NksM+dj½A
¼2½ dksbZ ljdkjh deZpkjh tks lsok ;k in ls lsokfuo`Ÿk gksrk gS] rks vf/kof"kZrk isa’ku ¼fdUrq
isa’ku dh fdlh vU; fdLe ds fy, ugha½ ds fy, vgdZ lsok esa ifjo/kZu djus ds fy, ik= gksxk(&
¼i½
mldh lsok dh vof/k ls ,d pkSFkkbZ ls vuf/kd okLrfod vof/k( ;k
¼ii½ okLrfod vof/k] ftlls HkrhZ ds le; mldh vk;q iPphl o"kZ ls vf/kd gksrh gS( ;k
¼iii½ ikap o"kZ dh vof/k;
buesa ls tks Hkh de gks] ;fn og lsok ;k in] ftl ij ljdkjh vf/kdkjh dh fu;qfDr dh xbZ gS]
fuEufyf[kr eas ls dksbZ ,d gS]&
¼d½ ftlds fy, oSKkfud izkS|ksfxdh ;k O;kolkf;d {ks= esa fof’k"V ;ksX;rk vFkok LukrdksŸkj
vuqla/kku ;k vgZrk ;k vuqHko vfuok;Z gS ( vkSj
¼[k½ ftl ij lkekU;r% iPphl o"kZ ls vf/kd vk;q ds mEeh}kj HkrhZ fd, x, gSa %
ijarq ;g NwV mu ljdkjh deZpkfj;ksa dks vuqKs; gksxh] ftudh]&
¼i½
fu;qfDr lh/kh HkrhZ }kjk dh xbZ gS vkSj u dh inksUufr }kjk (
¼ii½ okLrfod vgZd lsok vf/kof"kZrk lsokfuo`fŸk ds le; nl o"kZ ;k blls vf/kd gS(
¼iii½ fdlh ,sls in ij fu;qfDr] ftlds fy, HkrhZ fu;eksa esa ;g fof’k"V micU/k varfoZ"V gS
fd ftlesa og lsok ;k in gS] tks bl fu;e dk ykHk ys ldrk gS%
ijarq mifu;e ¼2½ ds micU/k mu lsok ds lnL;ksa ij ykxw ugha gksaxs tks
izFke tuojh] 2006 dks ;k mlds ckn fu;qDr gq, gSa ¼e`R;q ,oa lsok fuo`fr minku dks NksM+dj½A
¼3½ mifu;e ¼2½ esa fufnZ"V NwV mlh foHkkx esa ;k fdlh vU; foHkkx esa fdlh vU; in ls ,sls in ij
Ik’pkr~orhZ fu;qfDr dks Hkh ykxw gksxh %
ijarq ljdkjh deZPkkjh ;k rks viuh iwoZorhZ vgZd lsok dks vf/kof"kZrk isa’ku ds fy,
fglkc esa ysus ds fy, gdnkj gksxk ;k mifu;e ¼2½ ds v/khu NwV izkIr djus dk gdnkj gksxkA og
bl vk’k; ds fodYi dk iz;ksx in xzg.k djus dh frfFk ls ,d o"kZ dh vof/k ds Hkhrj djsxkA ,d
ckj fodYi dk fd;k x;k iz;ksx vfUre gksxkA
fVIi.k%& bl fu;e ds v/khu NwV iznku djus dk fu.kZ; iz’kklfud foHkkx }kjk foŸk foHkkx ds ijke’kZ
ls HkrhZ dh frfFk ls nks o"kZ ds Hkhrj fy;k tk,xkA
14.
¼1½ vuq’kklu] 'kkfLr;ksa rFkk vihyksa ls lacf/kr ekeyksa esa] lsok ds lnL; gfj;k.kk flfoy
lsok ¼n.M rFkk vihy½ fu;e] 2016] }kjk 'kkflr gksaxs %
ijUrq ,slh 'kkfLr;ksa dk Lo:i tks yxkbZ tk ldrh gaS] ,slh 'kkfLr;ka yxkus ds fy, l’kDr
izkf/kdkjh rFkk vihy izkf/kdkjh] Hkkjr ds lafo/kku ds vuqPNsn 309 ds v/khu cukbZ xbZ fdlh fof/k ;k
fu;eksa ds micU/kksa ds v/khu jgrs gq, os gksx
a s] tks bu fu;eksa ds ifjf’k"V x esa fofufnZ"V gaSA
¼2½ gfj;k.kk flfoy lsok ¼n.M rFkk vihy½ fu;e] 2016] ds fu;e 9 ds [k.M ¼x½ ;k [k.M
¼?k½ ds v/khu vkns’k ikfjr djus ds fy, l{ke izkf/kdkjh rFkk vihy izkf/kdkjh Hkh ogh gksaxs tks bu
fu;eksa ds ifjf’k"V ?k esa fofufnZ"V gSaA
15.
lsok dk izR;sd lnL;] Lo;a Vhdk yxok,xk ;k tc ljdkj fdlh fo’ks"k ;k lk/kkj.k vkns’k
}kjk ,slk funZ’s k djs] iqu% Vhdk yxok,xkA
16.
lsok ds izR;sd lnL; ls] tc rd mlus igys gh Hkkjr ds izfr rFkk fof/k }kjk ;Fkk LFkkfir
Hkkjr ds lafo/kku ds izfr jktfu"Bk dh 'kiFk u ys yh gks] ,slk djus dh vis{kk dh tk,xhA

vuq’kklu]
'kkfLr;ka rFkk
vihysaA

Vhdk yxokukA
jktfu"Bk dh
'kiFkA

<!-- page 7 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

3555

tgka ljdkj dh jk; esa bu fu;eksa ds fdlh mica/k esa <hy nsuk vko’;d ;k mfpr gks] ogka <hy nsus dh
og dkj.k vfHkfyf[kr djrs gq,] vkns’k }kjk] O;fDr;ksa ds fdlh oxZ ;k izoxZ ds ckjs esa ,slk dj 'kfDrA
ldrh gSA

17.

bu fu;eksa esa fdlh ckr ds gksrs gq, Hkh] fu;qfDr izkf/kdkjh] ;fn og fu;qfDr vkns’k esa fo’ks"k fo’ks"k micU/kA
fuca/ku rFkk 'krsZa yxkuk lehphu le>s] rks og ,slk dj ldrk gSA

18.

bu fu;eksa esa nh xbZ dksbZ Hkh ckr] jkT; ljdkj }kjk] bl laca/k esa le;&le; ij tkjh fd, vkj{k.kA
x, vkns’kksa ds vuqlkj vuqlwfpr tkfr;ksa] fiNM+s oxksZ] HkwriwoZa lSfudksa] 'kkjhfjd :i ls fodykax
O;fDr;ksa ;k O;fDr;ksa ds fdlh vU; oxZ ;k izoxZ dks fn, tkus ds fy, visf{kr vkj{k.kksa rFkk vU;
fj;k;rksa dks izHkkfor ugha djsxh %

19.

ijUrq bl izdkj fd, x, vkj{k.kksa dh dqy izfr’krrk fdlh Hkh le; ipkl izfr’kr ls vf/kd
ugha gksxhA
gfj;k.kk vkS"kf/k ¼xzqi [k½] lsok fu;e] 1989 rFkk gfj;k.kk LokLF; foHkkx fpfdRlk bŸkj fujlu rFkk
O;ko`fRr;kaA
iz;ksx’kkyk] jkT; lsok ¼xqzi ^[k^½ lsok fu;e] 1998] blds }kjk] fujflr fd, tkrs gSa %

20.

ijUrq bl izdkj fujflr fu;eksa ds v/khu fd;k x;k dksbZ vkns’k ;k dh xbZ dksbZ dkjZokbZ bu
fu;eksa ds vuq:i mica/kksa ds v/khu fd;k x;k vkns’k vFkok dh xbZ dkjZokbZ le>h tk,xhA

<!-- page 8 -->

3556

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

ifjf’k"V d

¼nsf[k, fu;e&3½
Øe
la[;k

inuke

1

2

inksa dh la[;k

osrueku

LFkk;h

vLFkk;h

tksM+

3

4

5

6

1

Okfj"B jktdh; fo’ys"kd

&

1

1

izos’k Lrj-9 (lSy&1)₹ 53100/-

2

jktdh; fo’ys"kd

1

&

1

izos’k Lrj-9 (lSy&1)₹ 53100/-

3

inkfHkfgr vf/kdkjh

&

22

22

izos’k Lrj-9 (lSy&1)₹ 53100/-

4

Okfj"B vkS"kf/k fu;a=.k
vf/kdkjh

07

03

10

izos’k Lrj-7 (lSy&1)₹ 44900/-

5

mi yksd fo’ys"kd

1

&

1

izos’k Lrj-7 (lSy&1)₹ 44900/-

6

ftyk yksd fo’ys"kd

&

1

1

izos’k Lrj-7 (lSy&1)₹ 44900/-

7

ofj"B oSKkfud vf/kdkjh
¼thok.kq foKku½

1

&

1

izos’k Lrj-7 (lSy&1)₹ 44900/-

8

Okfj"B oSKkfud vf/kdkjh
¼vkS"k/kh; jlk;u½

1

&

1

izos’k Lrj-7 (lSy&1)₹ 44900/-

9

Okfj"B oSKkfud vf/kdkjh
¼vkS"k/kh; foKku½

1

&

1

izos’k Lrj-7 (lSy&1)₹ 44900/-

10

v/kh{kd

02

&

02

izos’k Lrj-7 (lSy&1)₹ 44900/-

11

vkS"kf/k fu;a=.k vf/kdkjh

24

22

46

izos’k Lrj-6 (lSy&1)₹ 35400/-

12

[kk| lqj{kk vf/kdkjh

21

24

45

izos’k Lrj-4 (lSy&1)₹ 25500/-

<!-- page 9 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

3557

ifjf'k"V [k

¼nsf[k, fu;e&7½
Øe
la[;k
1
1

2

inuke
2
ofj"B jktdh;
fo’ys"kd

jktdh; fo’ys"kd

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
rFkk vuqHko] ;fn dksbZ gks rks
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
3
4
inksUufr }kjk &
(i) jktdh; fo’ys"kd ds #i esa ikap o"kZ dk
vuqHko (
;k
(ii) Okfj"B
oSKkfud vf/kdkjh ¼thok.kq
foKku½@ Okfj"B oSKkfud vf/kdkjh
¼vkS"k/kh; jlk;u½ @ Okfj"B oSKkfud
vf/kdkjh ¼vkS"k/k foKku½ ds #i esa nl
o"kZ dk vuqHko(
LFkkukarj.k ;k izfrfu;qfDr }kjk &
(i) ofj"B jktdh; fo’ys"kd ds :i esa nks o"kZ
dk vuqHko( rFkk
(ii) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA
¼1½¼d½
fdlh
ekU;rkizkIr LFkkukUrj.k ;k Ikzfrfu;qfDRk }kjk &
fo’ofo|ky; ls fpfdRlk 'kkL= ;k (i) jktdh; fo’ys"kd ds :i esa nks o"kZ dk
foKku ;k QkesZlh ;k vkS"k/kh;
vuqHko( rFkk
jlk;u esa Lukrd ;k bl iz;kstu ds (ii) ¼d½ fdlh ekU;rkizkIr fo’ofo|ky; ls
fy, dsUnzh; ljdkj }kjk ekU;rkizkIr
fpfdRlk 'kkL= ;k foKku ;k QkesZlh ;k
vkSj vf/klwfpr led{k ;ksX;rk j[krk
vkS"k/kh; jlk;u esa Lukrd ;k bl
gks vkSj fpfdRlk 'kkL= ;k foKku ;k
iz;kstu ds fy, dsUnzh; ljdkj }kjk
QkesZlh ;k vkS"k/kh; jlk;u esa
ekU;rk izkIr vkSj vf/klwfpr led{k
Lukrd ds ckn fuEufyf[kr ds
;ksX;rk j[krk gks vkSj fpfdRlk ;k foKku
fu;a=.kk/khu fdlh iz;ksx’kkyk ls
;k QkesZlh ;k vkS"k/kh; jlk;u esa Lukrd
vkS"kf/k;ksa ds ijh{k.k esa ikap o"kZ dk
ds ckn fuEufyf[kr ds fu;a=.kk/khu fdlh
vuqHko j[krk gks %&
iz;ksx’kkyk ls vkS"kf/k;ksa ds ijh{k.k esa ikap
(i) vkS"kf/k vkSj izlk/ku lkexzh
o"kZ dk vuqHko j[krk gks %&
vf/kfu;e] 1940 ds v/khu
(i)
vkS"kf/k vkSj izlk/ku lkexzh
fu;qDr fd;k x;k dksbZ
vf/kfu;e] 1940 ds v/khu fu;qDr fd;k
jktdh; fo’ys"kd;
x;k dksbZ jktdh; fo’ys"kd(
(ii) fu;qfDr
izkf/kdkjh }kjk
(ii)
fu;qfDr izkf/kdkjh }kjk iz;kstu
iz;kstu ds fy, vuqeksfnr
ds fy, vuqeksfnr iz;ksx’kkyk ijh{k.k
laLFkk
;k iz;ksx’kkyk
laLFkk dk v/;{k ;k vkS"kf/k esa ijh{k.k esa
ijh{k.k dk v/;{k ;k vkS"kf/k
nks o"kZ dk izf’k{k.k iwjk dj fy;k gks]
ds ijh{k.k esa nks o"kZ dk
ftlesa dsUnzh; vkS"kf/k iz;ksx’kkyk esa
izf’k{k.k iwjk dj fy;k gks]
vkS"kf/k vkSj izlk/ku lkexzh fu;e] 1945
ftlesa
dsUnzh;
vkS"kf/k
dh vuqlwph x esa nh xbZ enas 'kkfey gkas;
iz;ksx’kkyk esa vkS"kf/k vkSj
;k
izlk/ku lkexzh fu;e] 1945
¼[k½ fdlh ekU;rkizkIr fo’ofo|ky; ls
dh vuqlwph x esa nh xbZ enas
fpfdRlk 'kkL= ;k foKku ;k QkesZLkh ;k
'kkfey gka;s ;k
vkS"k/kh; jlk;u esa LukrdksŸkj fMxzh
¼[k½ fdlh ekU;rkizkIr fo’ofo|ky;
j[krk gks ;k ,sls iz;kstu ds fy, dsUnzh;
ls fpfdRlk 'kkL= ;k foKku ;k
ljdkj }kjk ekU;rkizkIr vkSj vf/klwfpr
QkesZLkh ;k vkS"k/kh; jlk;u esa
dksbZ led{k ;ksX;rk j[krk gks ;k ,d
LukrdksŸkj fMxzh j[krk gks ;k
fo"k; ds lkFk vkS"kf/k;ksa ds fo’ys"k.k vkSj

<!-- page 10 -->

3558

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Øe
la[;k
1

inuke
2

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a
rFkk vuqHko] ;fn dksbZ gks rks
3
,sls iz;kstu ds fy, dsUnzh;
ljdkj }kjk ekU;rkizkIr vkSj
vf/klwfpr dksbZ led{k ;ksX;rk
j[krk gks ;k ,d fo"k; ds lkFk
vkS"kf/k;ksa ds fo’ys"k.k vkSj
vkS"k/kh; esa mijksDr ijh{kk ikl
djds dSfeLV laLFkk ¼Hkkjr½ dk
lg;qDr fMIyksek j[krk gks vkSj
mijksDr LukrdksŸkj fMxzh ;k
fMIyksek izkIr djus ds ckn
fuEufyf[kr ds fu;a=.kk/khu
fdlh iz;ksx’kkyk esa vkS"kf/k;ksa ds
ijh{k.k esa rhu o"kZ dk vuqHko
j[krk gks %&
(i) vkS"kf/k vkSj izlk/ku lkexzh
vf/kfu;e] 1940 ds v/khu
fu;qDr fd;k x;k dksbZ jktdh;
fo’ys"kd %
(ii) fu;qfDr izkf/kdkjh }kjk bl
iz;kstu ds fy, vuqeksfnr
laLFkku ;k ijh{k.k iz;ksx’kkyk
dk v/;{k ;k vkS"kf/k ds ijh{k.k
esa nks o"kZ dk izf’k{k.k iwjk dj
fy;k gks] ftlesa dsUnzh; vkS"kf/k
iz;ksx’kkyk esa vkS"kf/k vkSj izlk/ku
lkexzh fu;e] 1945 dh vuqlwph
x esa nh xbZ enas 'kkfey gkas] ;k
fVIi.k % vkS"kf/k vkSj izlk/ku lkexzh
fu;e] 1945] dh vuqlwph esa enksa ds
ijh{k.k ds Ikz;kstu ds fy,]&
(i) mijksDr [k.M ¼d½ ;k [k.M
¼[k½ ds v/khu fu;qDr O;fDr
vkSj ftuds ikl fpfdRlk
'kkL= ;k 'kjhj fdz;k foKku ;k
vkS"k/k foKku ;k lw{e tho
foKku ;k QkeZl
s h esa fMxzh gks]
dh fu;qfDr izkf/kdkjh }kjk
vuqeksfnr
laLFkku
;k
iz;ksx’kkyk esa mDr enksa ds
ijh{k.k esa de ls de Ng ekl
dh vof/k ds fy, vuqHko ;k
izf’k{k.k gksuk pkfg,%
(ii) mDr [k.M ¼d½ ;k [k.M ¼[k½
ds v/khu fu;qDr fd, x,
O;fDr] fdUrq ftuds ikl
mijksDr fo"k;ksa esa mikf/k ugha
gS] ds ikl vkS"kf/k vkSj izlk/ku
lkexzh fu;e] 1945 dh vuqlwph
x esa of.kZr vkS"kf/k ds ijh{k.k

lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
4
vkS"k/kh; esa mijksDr ijh{kk ikl djds
dSfeLV laLFkk ¼Hkkjr½ dk lg;qDr
fMIyksek j[krk gks vkSj mijksDr
LukrdksŸkj fMxzh ;k fMIyksek izkIr djus
ds ckn fuEufyf[kr ds fu;a=.kk/khu
fdlh iz;ksx’kkyk esa vkS"kf/k;ksa ds ijh{k.k
esa rhu o"kZ dk vuqHko j[krk gks %&
(i) vkS"kf/k vkSj izlk/ku lkexzh vf/kfu;e]
1940 ds v/khu fu;qDr fd;k x;k dksbZ
jktdh; fo’ys"kd %
(ii) fu;qfDr izkf/kdkjh }kjk bl iz;kstu ds
fy, vuqeksfnr laLFkku ;k ijh{k.k
iz;ksx’kkyk dk v/;{k ;k vkS"kf/k ds
ijh{k.k esa nks o"kZ dk izf’k{k.k iwjk dj
fy;k gks] ftlesa dsUnzh; vkS"kf/k iz;ksx’kkyk
esa vkS"kf/k vkSj izlk/ku lkexzh fu;e] 1945
dh vuqlwph x esa nh xbZ enas 'kkfey gkas]
;k
fVIi.k % vkS"kf/k vkSj izlk/ku lkexzh fu;e]
1945] dh vuqlwph esa enksa ds ijh{k.k ds
Ikz;kstu ds fy,(&
(i) mijksDr [k.M ¼d½ ;k [k.M ¼[k½ ds
v/khu fu;qDr O;fDr vkSj ftuds ikl
fpfdRlk 'kkL= ;k 'kjhj fØ;k foKku ;k
vkS"k/k foKku ;k lw{e tho foKku ;k
QkeZslh esa fMxzh gks] dh fu;qfDr izkf/kdkjh
}kjk vuqeksfnr laLFkku ;k iz;ksx’kkyk esa
mDr enksa ds ijh{k.k esa de ls de Ng
ekl dh vof/k ds fy, vuqHko ;k
izf’k{k.k gksuk pkfg,%
(ii) mDr [k.M ¼d½ ;k [k.M ¼[k½ ds v/khu
fu;qDr fd, x, O;fDr] fdUrq ftuds
ikl mijksDr fo"k;ksa esa mikf/k ugha gS] ds
ikl vkS"kf/k vkSj izlk/ku lkexzh fu;e]
1945 dh vuqlwph x esa of.kZr vkS"kf/k ds
ijh{k.k esa] fu;qfDr izkf/kdkjh }kjk
vuqeksfnr laLFkk ;k iz;ksx’kkyk esa de ls
de rhu o"kZ dh vof/k ds fy, vuqHko ;k
izf’k{k.k gksuk pkfg, ;k vkS"kf/k;ksa ds
ijh{k.k ftuesa dsUnzh; vkS"kf/k Ikz;ksx’kkyk
es]a vkS"kf/k vkSj izlk/ku lkexzh fu;e]
1945 dh mDr vuqlwph x esa nh xbZ ensa
'kkfey gksa] esa nks o"kZ dk ijh{k.k iw.kZ
fd;k gks; rFkk
(3) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA

<!-- page 11 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Øe
la[;k
1

inuke
2

3

inkfHkfgr vf/kdkjh

4

ofj"B vkS"kf/k
fu;aa=.k vf/kdkjh

3559

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
rFkk vuqHko] ;fn dksbZ gks rks
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
3
4
esa] fu;qfDr izkf/kdkjh }kjk
vuqeksfnr laLFkk ;k iz;ksx’kkyk
esa de ls de rhu o"kZ dh
vof/k ds fy, vuqHko ;k
izf’k{k.k gksuk pkfg, ;k
vkS"kf/k;ksa ds ijh{k.k ftuesa
dsUnzh; vkS"kf/k Ikz;ksx’kkyk esa]
vkS"kf/k vkSj izlk/ku lkexzh
fu;e] 1945 dh mDr vuqlwph
x esa nh xbZ ensa 'kkfey gksa] esa
nks o"kZ dk ijh{k.k iw.kZ fd;k
gks; rFkk
(2) eSfVªd ;k mPprj f’k{kk Lrj
rd fgUnh@laLd`rA
&&
inksUufr }kjk&
[kk| lqj{kk vf/kdkjh ds #i esa vkB o"kZ dk
vuqHko ¼jktdh; [kk| fujh{kd ¼xqzi&x½ ds in
dks [kk| lqj{kk vf/kdkjh ¼xqzi&[k½ ds #i esa
inkfHkfgr fd;k tkrk gS rFkk jktdh; [kk|
fujh{kd ds in ds vuqHko dks inkfHkfgr
vf/kdkjh dh inksUufr ds fy, fxuk tk,xk½(
LFkkukUrj.k ;k izfrfu;qfDr }kjk &
(i) inkfHkfgr vf/kdkjh ds #i esa nks o"kZ dk
vuqHko ( rFkk
(ii) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA
inksUufr }kjk &
vkS"kf/k fu;a=.k vf/kdkjh ds #i esa ikap o"kZ dk
vuqHko;
LFkkukarj.k ;k izfrfu;qfDr }kjk &
(i) ofj"B vkS"kf/k fu;a=.k vf/kdkjh ds #i esa
nks o"kZ dk vuqHko(
(ii) QkesZlh esa vFkok vkS"k/kh; jlk;u esa
f}rh; Js.kh esa Lukrd fMxzh(
(iii) vkS"kf/k vkSj izlk/ku lkexzh fu;e] 1945
ls layXu vuqlwph x esa fofufnZ"V nzO;ksa esa
ls de ls de ,d nzO; ds fofuek.kZ esa
Ms< o"kZ dk vuqHko(
vFkok
ykbZlsal izkf/kdkjh }kjk bl iz;kstu ds fy,
vuqeksfnr fdlh iz;ksx’kkyk esa vuqlwph x esa
fofufnZ"V nzO;ksa esa ls de ls de ,d nzO; ds
ijh{k.k esa Ms< o"kZ dk vuqHko(
vFkok
vuqlwph x esa fofufnZ"V fdlh nzO; dk
fofuek.kZ djus okyh QeksZa ds fujh{k.k dk rhu
o"kZ dk vuqHko( rFkk
(iv) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA

<!-- page 12 -->

3560

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Øe
la[;k
1
5

inuke

6

2
mi yksd fo’ys"kd

ftyk yksd
fo’ys"kd

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
rFkk vuqHko] ;fn dksbZ gks rks
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
3
4
inksUufr }kjk &
(i) lgk;d yksd fo’ys"kd ds #i esa nks o"kZ
dk vuqHko( rFkk
(ii) [kk| vifeJ.k fuokj.k fu;e] 1955 ds
fu;e 6 ds mi&fu;e ¼2½ ds v/khu ,sls
iz;kstuksa ds fy, dsUnzh; ljdkj }kjk
fu;qDr cksMZ }kjk yksd fo’ys"kd ds #i esa
fu;qfDr ds fy, ;ksX; ?kksf"kr fd;k x;k
gks rFkk izkf/kdkjh }kjk vf/klwfpr fd;k
x;k gks;
;k
[kk| lqj{kk vkSj ekud fu;e] 2011 ds
fu;e 2-1-4 ds mi&fu;e ¼1½ ds [k.M (ii)
ds v/khu dsUnzh; ljdkj }kjk fu;qDr cksMZ
}kjk [kk| fo’ys"kd ds :i esa fu;qfDr ds
fy, ;ksX; ?kksf"kr fd;k x;k gks rFkk
izkf/kdkjh }kjk vf/klwfpr fd;k x;k gksA
LFkkuakj.k ;k izfrfu;qfDr }kjk &
(i) mi yksd fo’ys"kd ds #i esa nks o"kZ dk
vuqHko( RkFkk
(ii) [kk| vifeJ.k fuokj.k fu;e] 1955 ds
fu;e 6 ds mi&fu;e ¼2½ ds v/khu ,sls
iz;kstuksa ds fy, dsUnzh; ljdkj }kjk
fu;qDr cksMZ }kjk yksd fo’ys"kd ds #i esa
fu;qfDr ds fy, ;ksX; ?kksf"kr fd;k x;k
gks rFkk izkf/kdkjh }kjk vf/klwfpr fd;k
x;k gks;
;k
[kk| lqj{kk vkSj ekud fu;e] 2011 ds
fu;e 2-1-4 ds mi&fu;e ¼1½ ds [k.M
(ii) ds v/khu fu;qDr cksMZ }kjk [kk|
fo’ys"kd ds :i esa fu;qfDr ds fy, ;ksX;
?kksf"kr fd;k x;k gks rFkk izkf/kdkjh }kjk
vf/klwfpr fd;k x;k gks( rFkk
(iii) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA
inksUufr }kjk &
(i) lgk;d yksd fo’ys"kd ds #i esa nks o"kZ
dk vuqHko( rFkk
(ii) [kk| vifeJ.k fuokj.k fu;e] 1955 ds
fu;e 6 ds mi&fu;e ¼2½ ds v/khu ,sls
iz;kstuksa ds fy, dsUnzh; ljdkj }kjk
fu;qDr cksMZ }kjk yksd fo’ys"kd ds #i esa
fu;qfDr ds fy, ;ksX; ?kksf"kr fd;k x;k
gks rFkk izkf/kdkjh }kjk vf/klwfpr fd;k
x;k gks;
;k

<!-- page 13 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Øe
la[;k
1

7

inuke
2

ofj"B oSKkfud
vf/kdkjh
¼thok.kq foKku½

3561

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
rFkk vuqHko] ;fn dksbZ gks rks
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
3
4
[kk| lqj{kk vkSj ekud fu;e] 2011 ds
fu;e 2-1-4 ds mi&fu;e ¼1½ ds [k.M (ii)
ds v/khu dsUnzh; ljdkj }kjk fu;qDr cksMZ
}kjk [kk| fo’ys"kd ds :i esa fu;qfDr ds
fy, ;ksX; ?kksf"kr fd;k x;k gks rFkk
izkf/kdkjh }kjk vf/klwfpr fd;k x;k gksA
LFkkuakj.k ;k izfrfu;qfDr }kjk &
(i) mi yksd fo’ys"kd ds #i esa nks o"kZ dk
vuqHko( RkFkk
(ii) [kk| vifeJ.k fuokj.k fu;e] 1955 ds
fu;e 6 ds mi&fu;e ¼2½ ds v/khu ,sls
iz;kstuksa ds fy, dsUnzh; ljdkj }kjk
fu;qDr cksMZ }kjk yksd fo’ys"kd ds #i esa
fu;qfDr ds fy, ;ksX; ?kksf"kr fd;k x;k
gks rFkk izkf/kdkjh }kjk vf/klwfpr fd;k
x;k gks;
;k
[kk| lqj{kk vkSj ekud fu;e] 2011 ds
fu;e 2-1-4 ds mi&fu;e ¼1½ ds [k.M
(ii) ds v/khu fu;qDr cksMZ }kjk [kk|
fo’ys"kd ds :i esa fu;qfDr ds fy, ;ksX;
?kksf"kr fd;k x;k gks rFkk izkf/kdkjh }kjk
vf/klwfpr fd;k x;k gks( rFkk
(iii) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA
(i) lw{e tho foKku ;k tho LFkkukUrj.k@ izfrfu;qfDr }kjk &
jlk;u esa izFke Js.kh esa ekLVj (i) ofj"B oSKkfud vf/kdkjh ¼thok.kq foKku½
fMxzh(
ds #i esa nks o"kZ dk vuqHko; rFkk
;k
(ii) lw{e tho foKku ;k tho jlk;u foKku
Lkw{e tho foKku rduhd }kjk tho
esa izFke Js.kh esa ekLVj fMxzh(
foKku laca/kh vkS"kf/k;ksa ds fo’ys"k.k
;k
esa fdlh ekU;rkizkIr iz;ksx’kkyk ls Lkw{e tho foKku rduhd }kjk tho foKku
,d o"kZ ds vuqHko lfgr lw{e tho laca/kh vkS"kf/k;ksa ds fo’ys"k.k esa fdlh
foKku ;k tho jlk;u foKku ;k ekU;rkizkIr iz;ksx’kkyk ls ,d o"kZ ds vuqHko
thok.kq foKku esa f}rh; Js.kh esa lfgr lw{e tho foKku ;k tho jlk;u
ekLVj fMxzh] lw{e tho foKku foKku ;k thok.kq foKku esa f}rh; Js.kh esa
rduhd }kjk tho foKku laca/kh ekLVj fMxzh] lw{e tho foKku rduhd }kjk
vkS"kf/k;kas esa fo’ys"k.k ds fy, fdlh tho foKku laca/kh vkS"kf/k;kas esa fo’ys"k.k ds
ekU;rkizkIr Ikz;ksx’kkyk ls rhu o"kZ fy, fdlh ekU;rkizkIr Ikz;ksx’kkyk ls rhu o"kZ
ds vuqHko lfgr lw{e tho foKku esa ds vuqHko lfgr lw{e tho foKku esa izFke
izFke Js.kh ch ,l lh ¼vkulZ½ ;k Js.kh ch ,l lh ¼vkulZ½ ;k lw{e tho foKku
lw{e tho foKku ;k tho jlk;u ;k tho jlk;u foKku ;k thok.kq foKku esa
foKku ;k thok.kq foKku esa ,d ,d fo"k; ds lkFk izFke Js.kh esa ch- ,l- lhfo"k; ds lkFk izFke Js.kh esa ch ,l ¼vkulZ½( rFkk
lh ¼vkulZ½( rFkk
(iii) eSfVªd ;k mPprj f’k{kk Lrj rd
(ii) eSfVªd ;k mPprj f’k{kk Lrj
fgUnh@laLd`rA
rd fgUnh@laLd`rA

<!-- page 14 -->

3562

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Øe
la[;k
1

inuke
2

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
rFkk vuqHko] ;fn dksbZ gks rks
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
3
4

8

ofj"B oSKkfud
vf/kdkjh
¼vkS"k/kh; jlk;u½

(i)

jlk;u ;k QkesZlh esa izFke Js.kh LFkkukUrj.k ;k izfrfu;qfDr }kjk&
esa ekLVj fMxzh(
(i) ofj"B oSKkfud vf/kdkjh ¼vkS"k/kh; jlk;u½
;k
ds #i esa nks o"kZ dk vuqHko; rFkk
tho foKku laca/kh vkS"kf/k;ksa ds (ii) jlk;u ;k QkesZlh esa izFke Js.kh esa ekLVj
fo’ys"k.k esa fdlh ekU;rkizkIr
fMxzh (
iz;ksx’kkyk ls ,d o"kZ ds vuqHko
;k
lfgr jlk;u ;k QkesZlh esa f}rh; tho foKku laca/kh vkS"kf/k;ksa ds fo’ys"k.k esa
Js.kh esa ekLVj fMxzh( ;k
fdlh ekU;rkizkIr iz;ksx’kkyk ls ,d o"kZ ds
fdlh ekU;rkizkIr Ikz;ksx’kkyk ls vuqHko lfgr jlk;u ;k QkesZlh esa f}rh;
tho foKku laca/kh vkS"kf/k;kas ds Js.kh esa ekLVj rFkk ( ;k
fo’ys"k.k esa rhu o"kZ ds vuqHko fdlh ekU;rkizkIr Ikz;ksx’kkyk ls tho foKku
lfgr jlk;u esa ch ,l lh ¼vkulZ½ laca/kh vkS"kf/k;kas ds fo’ys"k.k esa rhu o"kZ ds
@tho jlk;u esa ch ,l lh vuqHko lfgr jlk;u esa ch ,l lh ¼vkulZ½
¼vkulZ½@ch&QkekZ esa izFke Js.kh( @tho
jlk;u
esa
ch
,l
lh
rFkk
¼vkulZ½@ch&QkekZ esa izFke Js.kh( rFkk
(ii) eSfVªd ;k mPprj f’k{kk Lrj rd
(iii) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA
fgUnh@laLd`rA

9

ofj"B oSKkfud
vf/kdkjh
¼vkS"k/k foKku½

(i) vkS"k/k

10

v/kh{kd

11

vkS"kf/k fu;aa=.k
vf/kdkjh

foKku esa izFke Js.kh esa LFkkukUrj.k ;k izfrfu;qfaDr }kjk &
ekLVj fMxzh(
(i) ofj"B oSKkfud vf/kdkjh ¼vkS"k/k foKku½
;k
ds #i esa nks o"kZ dk vuqHko; rFkk
tho foKku laca/kh vkS"kf/k;ksa ds (ii) vkS"kf/k foKku esa izFke Js.kh esa ekLVj
fo’ys"k.k dks ;Fkk ykxw vkS"k/k foKku
fMxzh(
esa fdlh ekU;rkizkIr iz;ksx’kkyk ls
;k
,d o"kZ ds vuqHko lfgr vkS"k/k
foKku esa f}rh; Js.kh esa ekLVj tho foKku laca/kh vkS"kf/k;ksa ds fo’ys"k.k dks
;Fkk ykxw vkS"k/k foKku esa fdlh ekU;rkizkIr
fMxzh(
iz;ksx’kkyk ls ,d o"kZ ds vuqHko lfgr vkS"k/k
;k
foKku esa f}rh; Js.kh esa ekLVj fMxzh( ;k
tho foKku laca/kh vkS"kf/k;ksa ds tho foKku laca/kh vkS"kf/k;ksa ds fo’ys"k.k dks
fo’ys"k.k dks ;Fkk ykxw vkS"k/k foKku ;Fkk ykxw vkS"k/k foKku esa fdlh ekU;rkizkIr
esa fdlh ekU;rkizkIr iz;ksx’kkyk ls iz;ksx’kkyk ls rhu o"kZ ds vuqHko lfgr
rhu o"kZ ds vuqHko lfgr ch&QkekZ ch&QkekZ ;k vkS"k/k foKku esa ,d fo"k; ds
;k vkS"k/k foKku esa ,d fo"k; ds lkFk ch ,l lh esa izFke Js.kh( rFkk
lkFk ch ,l lh esa izFke Js.kh( rFkk
(iii) eSfVªd ;k mPprj f’k{kk Lrj rd
(ii) eSfVªd ;k mPprj f’k{kk Lrj rd
fgUnh@laLd`rA
fgUnh@laLd`rA
inksUufr }kjk &
mi v/kh{kd dss #i es nks o"kZ dk vuqHko(
LFkkukarj.k ;k izfrfu;qfDr }kjk &
mi v/kh{kd dss #i esa nks o"kZ dk vuqHkoA
¼d½ QkesZlh esa vFkok vkS"k/kh; LFkkukarj.k ;k izfrfu;qfDr }kjk &
jlk;u esa f}rh; Js.kh esa 1- vkS"kf/k fu;aa=.k vf/kdkjh dss #i es nks o"kZ
Lukrd fMxzh;
dk vuqHko; rFkk
¼[k½ vkS"kf/k vkSj izlk/ku lkexzh 2- ¼d½ QkesZlh esa vFkok vkS"k/kh; jlk;u esa
fu;e] 1945 ls layXu vuqlwph
f}rh; Js.kh esa Lukrd fMxzh( ;k
x esa fofufnZ"V nzO;ksa esa ls de
¼[k½ vkS"kf/k vkSj izlk/ku lkexzh fu;e]

<!-- page 15 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Øe
la[;k
1

12

inuke

3563

lh/kh HkrhZ ds fy, 'kS{kf.kd vgZrk,a lh/kh HkrhZ ls vU;Fkk fu;qfDr ds fy, 'kS{kf.kd
rFkk vuqHko] ;fn dksbZ gks rks
vgZrk,a rFkk vuqHko] ;fn dksbZ gks rks
2
3
4
ls de ,d nzO; ds fofuekZ.k esa
1945 ls layXu vuqlwph x esa fofufnZ"V
nzO;ksa esa ls de ls de ,d nzO; ds
Ms< o"kZ dk vuqHko;
fofuek.kZ esa Ms< o"kZ dk vuqHko(
vFkok
vFkok
ykbZlsal izkf/kdkjh }kjk iz;kstu
ykbZ
l
s
a
l
iz
k
f/kdkjh
}kjk iz;kstu ds fy,
ds fy, vuqeksfnr fdlh iz;ksx’kkyk
esa vuqlwph x esa fofufnZ"V nzO;ksa esa ls vuqeksfnr fdlh iz;ksx’kkyk esa vuqlwph x esa
de ls de ,d nzO; ds ijh{k.k esa fofufnZ"V nzO;ksa esa ls de ls de ,d nzO; ds
ijh{k.k esa Ms< o"kZ dk vuqHko;
Ms< o"kZ dk vuqHko;
vFkok
vFkok
vuqlwph x esa fofufnZ"V fdlh nzO; dk
vuqlwph x esa fofufnZ"V fdlh nzO;
fofuek.kZ
djus okyh QeksZa ds fujh{k.k dk rhu
dk fofuekZ.k djus okyh QeksZa ds
fujh{k.k dk rhu o"kZ dk vuqHko; o"kZ dk vuqHko; rFkk
rFkk
3- eSfVªd ;k mPprj f’k{kk Lrj rd
¼x½ eSfVªd ;k mPprj f’k{kk Lrj
fgUnh@laLd`rA
rd fgUnh@laLd`rA
fVIi.kh& vfuok;Z vgZrk ds #i esa
fofgr vuqHko fofgr U;wure 'kS{kf.kd
vgZrk,a izkIr djus dh frfFk ds
Ik’pkr~ fxuk tk,xkA
[kk| lqj{kk vf/kdkjh 1- [kk| lqj{kk vf/kdkjh ,d LFkkukarj.k ;k izfrfu;qfDr }kjk &
iw.kZdkfyd vf/kdkjh gksxk vkSj 1- [kk| lqj{kk vf/kdkjh dss #i es nks o"kZ dk
frfFk ftldks og bl izdkj
vuqHko; rFkk
fu;qDr
fd;k
x;k
gks] 2- [kk| lqj{kk vf/kdkjh ,d iw.kZdkfyd
fuEufyf[kr j[krk gks; &
vf/kdkjh gksxk vkSj frfFk ftldks og bl
¼d½ fdlh ekU;rkizkIr fo’ofo|ky;
izdkj fu;qDr fd;k x;k gks] fuEufyf[kr
ls [kk| izkS|ksfxdh ;k Ms;jh
j[krk gks; &
izkS|ksfxdh ;k tSo izkS|ksfxdh ;k
rsy izkS|ksfxdh ;k d`f"k foKku ¼d½ fdlh ekU;rkizkIr fo’ofo|ky; ls [kk|
izkS|ksfxdh ;k Ms;jh izkS|ksfxdh ;k tho
;k i’kq fpfdRlk foKku ;k
izkS|ksfxdh ;k rsy izkS|ksfxdh ;k d`f"k
tho jlk;u foKku ;k lw{e
foKku ;k i’kq fpfdRlk foKku ;k tSo
tho foKku esa fMxzh ;k jlk;u
jlk;u foKku ;k lw{e tho foKku esa
foKku esa ekLVj fMxzh ;k
fMxzh ;k jlk;u foKku esa ekLVj fMxzh
fpfdRlk 'kkL= esa fMxzh; ;k
;k fpfdRlk 'kkL= esa fMxzh( ;k
¼[k½ dsUnzh; ljdkj }kjk vf/klwfpr
dksbZ vU; led{k@ekU;rk ¼[k½ dsUnzh; ljdkj }kjk vf/klwfpr dksbZ vU;
led{k@ekU;rk izkIr vgZrk] ;k
izkIr vgZrk; ;k
¼x½
[kk|
izkf/kdj.k }kjk vuqeksfnr ;Fkk
¼x½ [kk| izkf/kdj.k }kjk vuqeksfnr
fofufnZ
"
V fdlh ekU;rk izkIr laLFkk ;k
;Fkk fofufnZ"V fdlh ekU;rk
la
L
Fkku
ds v/khu izf’k{k.k lQyrkiwoZd
izkIr laLFkk ;k laLFkku ds
iw
j
k
fd;k
gks; rFkk
v/khu izf’k{k.k lQyrkiwoZd
3eS
f
Vª
d
;k
mPprj f’k{kk Lrj rd
iwjk fd;k gks; rFkk
fgUnh@laLd`rA
2- eSfVªd ;k mPprj f’k{kk Lrj rd
fVIi.k%
fgUnh@laLd`rA
[k.M (iii) esa of.kZr izf’k{k.k mEeh}kj ds p;u
fVIi.k%
[k.M (iii) esa of.kZr izf’k{k.k mEeh}kj ds ckn fd;k tk,xk vkSj tks lQyrkiwoZd
ds p;u ds ckn fd;k tk,xk vkSj izf’k{k.k iwjk djsaxsa mUgsa [kk| lqj{kk vf/kdkjh
tks lQyrkiwoZd izf’k{k.k iwjk djsaxsa ds #i esa fu;qDr fd;k tk,xkA
mUgsa [kk| lqj{kk vf/kdkjh ds #i esa
fu;qDr fd;k tk,xkA

<!-- page 16 -->

3564

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Ifjf’k"V x

¿nsf[k, fu;e&14¼1½À
dze
la[;k

inuke

fu;qfDr
izkf/kdkjh

'kkfLr dk Lo:i

'kkfLr yxkus ds
fy, l’kDr
izkf/kdkjh

vihy
vf/kdkjh

1

2

3

4

5

6

Okfj"B jktdh; fo’ys"kd

ljdkj

Lkjdkj

Lkjdkj

1

¼I½ Yk?kq 'kkfLr;ka&
gfj;k.kk flfoy lsok ¼n.M
rFkk vihy½ fu;e] 2016 esa
;Fkk fofufnZ"V(
¼II½ cM+h 'kkfLr;ka&

2

jktdh; fo’ys"kd

3

inkfHkfgr vf/kdkjh

4

ofj"B vkS"kf/k
vf/kdkjh

5

mi yksd fo’ys"kd

6

ftyk yksd fo’ys"kd

7

ofj"B oSKkfud vf/kdkjh

gfj;k.kk flfoy lsok ¼n.M
rFkk vihy½ fu;e] 2016 esa
;Fkk fofufnZ"V(

fu;a=.k

¼thok.kq foKku½
8

ofj"B oSKkfud vf/kdkjh
¼vkS"k/kh; jlk;u½

9

ofj"B oSKkfud vf/kdkjh
¼vkS"k/k foKku½

10

v/kh{kd

11

vkS"kf/k fu;a=.k vf/kdkjh

12

[kk| lqj{kk vf/kdkjh

<!-- page 17 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

3565

ifjf’k"V ?k

¿nsf[k, fu;e&14 ¼2½À
Øe

inuke

vkns’k dk Lo:i

vkns’k djus ds
fy, l’kDr
izkf/kdkjh

vihy
izkf/kdkjh

2

3

4

5

¼d½ isa’ku dks 'kkflr djus okys
fu;eksa fd v/khu mls vuqKs;
vfrfjDr is’a ku dh vf/kdre
jkf’k esa deh djuk ;k jksduk(
rFkk

Lkjdkj

Lkjdkj

la[;k
1
1

Okfj"B jktdh; fo’ys"kd

2

jktdh; fo’ys"kd

3

inkfHkfgr vf/kdkjh

4

ofj"B
vkS"kf/k
vf/kdkjh

5

mi yksd fo’ys"kd

6

ftyk yksd fo’ys"kd

7

ofj"B oSKkfud vf/kdkjh

¼[k½ mldh vf/kof"kZrk ds fy, fu;r
vk;q ds gksus ls vU;Fkk fu;qfDr
dh lekfIrA
fu;a=.k

¼thok.kq foKku½
8

ofj"B oSKkfud vf/kdkjh
¼vkS"k/kh; jlk;u½

9

ofj"B oSKkfud vf/kdkjh
¼vkS"k/k foKku½

10

v/kh{kd

11

vkS"kf/k fu;a=.k vf/kdkjh

12

[kk| lqj{kk vf/kdkjh

#ijke tksoy]
vij eq[; lfpo] gfj;k.kk ljdkj]
LokLF; foHkkxA

<!-- page 18 -->

3566

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
HARYANA GOVERNMENT
FOOD AND DRUGS ADMINISTRATION DEPARTMENT
Notification
The 13th November, 2018
No.; G.S.R.77/Const/Art.309/30/13/2017-5HBIII.— In exercise of the powers conferred by
the proviso to article 309 of the Constitution of India, the Governor of Haryana hereby makes the
following rules, regulating the recruitment and conditions of service of persons appointed to the
Haryana Food and Drugs Administration Department, Subordinate Offices (Group B) Service,
Namely:PART- I- GENERAL

Short title and
commencement.

1.
(1)
These rules may be called the Haryana Food and Drugs Administration Department,
Subordinate Offices (Group B) Service Rules, 2018.
(2)
They shall come into force at once.

Definitions.

2.

In these rules, unless the context otherwise requires,(a)
“Commission” means the Haryana Public Service Commission;
(b)
“direct recruitment” means an appointment made otherwise than by promotion from
within the Service or by transfer of an official already in the Service of the
Government of India or any State Government ;
(c)
“Government” means the Haryana Government in the Administrative Department;
(d)
“Institution “means,(i)
any institution established by law in force in the State of Haryana ; or
(ii)
other institution recognised by the Government for the purpose of these rules;
(e)
“recognised university” means,(i)
any university incorporated by law in India; or
(ii)
any other university which is declared by the Government to be a recognised
university for the purpose of these rules;
(f)
“Service” means the Haryana Food and Drugs Administration Department,
Subordinate Offices (Group B) Service.
PART II—RECRUITMENT TO SERVICE

Number and
Character of
posts.

3.

Nationality,
domicile and
character of
candidates
recruited to the
services.

4.

The Service shall comprise the post shown in Appendix A to these Rules :
Provided that nothing in these rules shall affect the inherent right of the Government to
make additions to or reductions in the number of such posts or to create new posts, with different
designations and scales of pay, either permanently or temporarily.
(1)

No person shall be appointed to any post in the Service, unless he is-]
(a)
a citizen of India; or
(b)
a subject of Nepal; or
(c)
a subject of Bhutan :
Provided that a person belonging to any of the categories (b) or (c) shall be a person
in whose favour a certificate of eligibility has been issued by the Government.
(2)
A person in whose case a certificate of eligibility is necessary may be admitted to an
examination or interview conducted by the Commission or any other recruiting authority but the
offer of appointment may be given only after the necessary eligibility certificate has been issued to
him by the Government.
(3)
No person shall be appointed to any post in the Service by direct recruitment, unless
he produces a certificate of character from the principal, academic officer of the university, college,
school or institution last attended, if any and similar certificates from two other responsible
persons, not being his relatives who are well acquainted with him in his private life and are
unconnected with his university, college, school or institution.

<!-- page 19 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
5.
No person shall be appointed to the Service by direct recruitment to the following posts who
is less than the lower and more than the upper age limit as mentioned below on first day of the
month next proceeding the last date of submission of applications to the Commission :-

6.

Serial
Number

Designation of the Post

Lower age limit
(years)

Upper age limit
(Years)

1

Government Analyst

25

42

2

Senior Scientific Officer
(Bacteriology)

22

42

3

Senior Scientific Officer
(Pharmaceutical Chemistry)

22

42

4

Senior Scientific Officer
(Pharmacology)

22

42

5

Drugs Control Officer

21

42

6

Food Safety Officer

21

42

Appointment to the post in the Service shall be made by the Government;

7.
No person shall be appointed to any post in the Service, unless he is in possession of
qualifications and experience specified in column 3 of Appendix B of these rules in case of direct
recruitment and those specified in column 4 of the aforesaid Appendix in case of appointment
other than by direct recruitment:
Provided that in case of appointment by direct recruitment, the qualifications regarding
experience shall be relaxable to the extent of fifty percent at the discretion of the Commission. In
case sufficient number of candidates belonging to Schedule Castes, Backward Classes,
Ex-Servicemen and Physically Handicapped categories, possessing the requisite experience, are
not available to fill up the vacancies reserved for them, after recording reasons for so doing in
writing.
8.

3567
Age

Appointing
authority.
Qualifications.

Disqualifications.

No person, (a)

who has entered into or contracted a marriage with a person having a spouse living;
or

(b)

who having a spouse living, has entered into or contracted a marriage with any
person, shall be eligible for appointment to any post in Service:

Provided that the Government may, if satisfied, that such marriage is permissible under the
personal law applicable to such person and the other party to the marriage and there are other
grounds for so doing, exempt any person from the operation of this rule.
9.

(1)

Recruitment to the service shall be made,(1)

(2)

(3)

In case of Senior Government Analyst –
(i)

by promotion amongst Government Analysts/Senior Scientific
Officers; or

(ii)

by transfer or deputation of an officer already in the service of any
State Government or the Government of India;

In case of Government Analyst (i)

by direct recruitment ; or

(ii)

by transfer or deputation of an officer already in the service of any
State Government or the Government of India;

In the case of Designated Officer (i)

by promotion amongst Food Safety Officers; or

(ii)

by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

Method of
recruitment.

<!-- page 20 -->

3568

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
(4)

In case of Senior Drugs Control Officer(i)
(ii)

(5)

(6)

In case of Deputy Public Analyst (i)

by promotion amongst Assistant Public Analysts; or

(ii)

by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In case of District Public Analyst (i)
(ii)

(7)

by promotion amongst Deputy Superintendents ; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In case of Drugs Control Officer (i)
(ii)

(12)

by direct recruitment ; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In the case of Superintendent (i)
(ii)

(11)

by direct recruitment ; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In the case of Senior Scientific Officer (Pharmacology)(i)
(ii)

(10)

by direct recruitment ; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In the case of Senior Scientific Officer (Pharmaceutical Chemistry)(i)
(ii)

(9)

by promotion amongst Assistant Public Analysts; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In case of Senior Scientific Officer (Bacteriology) (i)
(ii)

(8)

by promotion from amongst Drugs Control Officers ; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

by direct recruitment; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;

In the case of Food Safety Officer(i)
(ii)

by direct recruitment ; or
by transfer or deputation of an officer already in the Service of any
State Government or the Government of India;
(2)
All promotions, unless otherwise provided, shall be made on seniority-cum-merit
basis and seniority alone shall not confer any right to such promotion.
Probation.

10.
(1)
Persons appointed to the post in the Service shall remain on probation for a period of
two years, if appointed by direct recruitment and one year, if appointed otherwise :
Provided that—
(a)
any period, after such appointment, spent on deputation on a corresponding or
a higher post shall count towards the period of probation;
(b)
any period of work in equivalent or higher rank, prior to appointment to any
post in the Service may, in the case of appointment by transfer, at the
discretion of the appointing authority, be allowed to count towards the period
of probation fixed under this rule; and

<!-- page 21 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
(c)

any period of officiating appointment shall be reckoned as period spend
on probation but no person who has so officiated shall, on the completion
of the prescribed period of probation, be entitled to be confirmed, unless
he is appointed against a permanent vacancy.

(2)
If, in the opinion of the appointing authority, the work or conduct of a person
during the period of probation is not satisfactory, it may,(a)

if such person is appointed by direct recruitment, dispense with his
Services; and

(b)

if such person is appointed by otherwise than by direct recruitment,(i)

revert him to his former post; or

(ii)

deal with him in such other manner as the terms and conditions of
his previous appointment permit.

(3)
On the completion of the period of probation of a person, the appointing
authority may,(a)

(b)

if his work or conduct has, in its opinion, been satisfactory,(i)

confirm such person from the date of his appointment; if
appointed against a permanent vacancy; or

(ii)

confirm such person from the date from which a permanent
vacancy occurs, if appointed against a temporary vacancy; or

(iii)

declare that he has completed his probation satisfactory, if there is
no permanent vacancy; or

If his work or conduct has, in its opinion, been not satisfactory;(i)

dispense with his Service, if appointed by direct recruitment, if
appointed otherwise, revert him to his former post or deal with
him in such other manner, as the terms and conditions of previous
appointment permit; or

(ii)

extend his period of probation and thereafter pass such order, as it
could have passed on the expiry of the first period of probation :

Provided that the total period of probation including extension if any,
shall not exceed three years.
11.
Seniority, inter se of the members of the Service shall be determined by the length of
continuous service on any post in the Service:
Provided that where there are different cadres in the Service, the seniority shall be
determined separately for each cadre :
Provided further that in the case of members appointed by direct recruitment, the order
of merit determined by the Commission, shall not be disturbed in fixing the seniority :
Provided further that in the case of two or more members appointed on the same date,
their seniority shall be determined as follows :(a)
a member appointed by direct recruitment shall be senior to a member appointed
by promotion or by transfer;
(b)
a member appointed by promotion shall be senior to a member appointed by
transfer ; and
(c)
in the case of a member appointed by promotion or by transfer, seniority shall be
determined according to the seniority of such members in the appointments from
which they were promoted or transferred; and
(d)
in the case of members appointed by transfer from different cadres, their
seniority shall be determined according to pay, preference being given to a
member, who was drawing a higher rate of pay in his previous appointment and
if the rates of pay drawn are also the same, then by the length of their Service in
the appointments; and if the length of such Service is also the same, the older
member shall be senior to the younger member.

Seniority.

3569

<!-- page 22 -->

3570
Liability to
serve.

Pay, leave,
pension and all
other matters.

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
12.
(1)
A member of the Service shall be liable to serve at any place, whether within or
outside the State of Haryana, on being ordered so to do by the appointing authority.
(2)
A member of the Service may also be deputed to serve under ,(i)
a company, an association or a body of individuals whether incorporated or
not, which is wholly or substantially owned or controlled by the State
Government, a Municipal Corporation or a local authority or university
within the State of Haryana;
(ii)
the Central Government or a company, an association or a body of
individuals, whether incorporated or not, which is wholly or substantially
owned or controlled by the Central Government; or
(iii)
any other State Government, an international organisation, an autonomous
body not controlled by the Government or a private body:
Provided that no member of the Service shall be deputed to serve the Central or any other
State Government or organisation or body referred to in clauses (ii) or (iii) except with his
consent.
13.
(1)
In respect of pay, leave, pension and all other matters, not expressly provided for in
these rules, the members of the Service shall be governed by the Haryana Civil Services (General)
Rules, 2016, the Haryana Civil Services (Pay) Rules, 2016, the Haryana Civil Services (Leave)
Rules, 2016, the Haryana Civil Services (Allowances to Government Employees) Rules, 2016, the
Haryana Civil Services (General Provident Fund) Rules, 2016, the Haryana Civil Services
(Government Employee conduct) Rules, 2016, the Haryana Civil Services (Punishment and
Appeal) Rules, 2016, the Haryana Civil Services (Travelling Allowances) Rules, 2016, the
Haryana Civil Services (Pension) Rules, 2016, and by such rules and regulations, as may have
been, or may hereafter, be adopted or made by the competent authority of India under the
Constitution of India or under any law for the time being in force made by the State Legislature :
Provided that the Haryana Civil Services (Pension) Rules, 2016 shall not be applicable to
those members of Service who are appointed on or after 1st January, 2006.
(2)
A person who retires from Service or post shall be eligible to add his Service
qualifying for superannuation pension (but not for any other class of pension) –
(i)
the actual period not exceeding one-forth of the length of his Service; or
(ii)
the actual period by which his age at the time of recruitment exceeds twentyfive years; or
(iii) a period of five years,
Whichever is less, if the Service or post to which the Government employee is appointed is
one(a)
for which post-graduate research or specialist qualification, or experience in
scientific, technological or professional fields is essential; and
(b)
to which candidates of more than twenty-five years of age are normally recruited :
Provided that this concession shall be admissible to a Government employee(i)
appointed by direct recruitment and not by promotion ;
(ii)
who has actual qualifying service of ten years or more at the time of superannuation
retirement;
(iii) appointed to a post, the recruitment rules of which contain a specific provision that
the service or post is one which carries the benefit of this rule :
Provided that the provision of above said sub-rule (2) shall not be applicable to those
members of service who are appointed on or after 1stJanuary, 2006.
(3)
The concession referred to sub-rule(2) shall also be admissible on subsequent
appointment from any other post to such a post in the same or any other department:
Provided that Government employee shall be entitled either to count his past qualifying
service for superannuation pension or to get concession under sub-rule (2). He shall exercise an
option to this effect within one year from the date of joining. The option once exercised shall be
final.
Note : The decision to grant the concession under the rule shall be taken within two years from
the date of recruitment by the Administrative Department in consultation with the Finance
Department.

<!-- page 23 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
14.
(1)
In matters relating to discipline, penalties and appeals, members of the Service
shall be governed by the Haryana Civil Services(Punishment and Appeal) Rules, 2016, as
amended from time to time:

3571
Discipline,
penalties and
appeals.

Provided that the nature of penalties which may be imposed, the authority empowered to
impose such penalties and appellate authority shall, subject to the provisions of any law or rules
made under article 309 of the Constitution of India, be such as are specified in Appendix C to
these rules.
(2)
The authority competent to pass an order under clause (c) or clause (d) of rule 9 of
the Haryana Civil Services (Punishment and Appeal) Rules, 2016 and appellate authority shall be
as specified in Appendix D to these rules.
15.
Every member of the Service shall get himself vaccinated or re-vaccinated if and when the
Government so directs by a special or general order.

Vaccination.

16.
Every member of the Service, unless he has already done so, shall be required to take the
oath of allegiance to India and to the Constitution of India as by law established.

Oath of
allegiance.

17.
Where the Government is of the opinion that it is necessary or expedient to do so, it may,
by order, for reasons to be recorded in writing, relax any of the provisions of these rules with
respect to any class or category of persons.

Power of
relaxation.

18.
Notwithstanding anything contained in these rules, the appointing authority may impose
special terms and conditions in the order of appointment, if it is deemed expedient to do so.

Special
provisions.

19.
Nothing contained in these rules shall affect reservations and other concessions required
to be provided for Scheduled Casts, Backward Classes, Ex-Serviceman, Physically Handicapped
persons or any other class or category of persons in accordance with the orders issued by the State
Government in this regard from time to time:

Reservations.

Provided that the total percentage of reservations so made shall not exceed fifty per cent at
any time.
20.
The Haryana Drugs (Group B), Service Rules, 1989 and Haryana Health Department NonMedical Laboratory Service (Group B) State Service Rules, 1998 are hereby repealed :
Provided that any order made or action taken under the rules so, repealed shall be deemed
to have been made or taken under the corresponding provisions of these rules.

Repeal and
savings.

<!-- page 24 -->

3572

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
APPENDIX-A
(see rule 3)

Serial
number

Designation of Post

Number of Posts

Pay Scale of Post

Permanent

Temporary

Total

1

2

3

4

5

6

1.

Senior Government Analyst

-

1

1

FPL-9(Cell-I) ₹53100/-

2.

Government Analyst

1

-

1

FPL-9(Cell-I) ₹53100/-

3.

Designated Officer

-

22

22

FPL-9(Cell-I) ₹53100/-

4.

Senior Drugs Control Officer

7

3

10

FPL-7(Cell-I) ₹44900/-

5.

Deputy Public Analyst

1

-

1

FPL-7(Cell-I) ₹44900/-

6.

District Public Analyst

-

1

1

FPL-7(Cell-I) ₹44900/-

7.

Senior Scientific Officer
(Bacteriology)

1

-

1

FPL-7(Cell-I) ₹44900/-

8.

Senior Scientific Officer
(Pharmaceutical Chemistry)

1

-

1

FPL-7(Cell-I) ₹44900/-

9.

Senior Scientific Officer
(Pharmacology)

1

-

1

FPL-7(Cell-I) ₹44900/-

10.

Superintendent

02

-

02

FPL-7(Cell-I) ₹44900/-

11.

Drugs Control Officer

24

22

46

FPL-6(Cell-I) ₹35400/-

12.

Food Safety Officer

21

24

45

FPL-4(Cell-1)₹25500/-

<!-- page 25 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

3573

Appendix B
(see rule 7 )
Serial
number

1

Designation

2

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4

1

Senior
Government
Analyst

--

By promotion :(i) Five
years
Experience
as
Government Analyst;
or
(ii) Ten years Experience as Senior
Scientific Officer (Bacteriology)/
Senior
Scientific
Officer
(Pharmaceutical
Chemistry)/
Senior
Scientific
Officer
(Pharmacology) .
By transfer/deputation :(i)
Two years Experience as senior
Government Analyst; and
(iii) Hindi or Sanskrit upto Matric or
Higher Education.

2

Government
Analyst

1(a)A graduate in medicine or
science
or
Pharmacy
or
Pharmaceutical Chemistry of a
recognised university or has an
equivalent qualification recognised
and notified by the Central
Government for such purpose and
having five years experience after
graduation in Medicine or Science
or Pharmacy or Pharmaceutical
Chemistry in the testing of drugs in
a laboratory under the control of –(i)
a Government Analyst appointed
under the Drugs and Cosmetics Act,
1940; or (ii) the Head of an
Institution or testing laboratory
approved for the purpose by the
appointing
authority
or
has
completed two years training on
testing of drugs, including items
stated in Schedule C of the Drugs
and Cosmetics Rules, 1945 in
Central Drugs Laboratory ; or
(b) Possesses a postgraduate degree
in medicine or Science or Pharmacy
Pharmaceutical chemistry of a
recognised university of has an
equivalent qualification recognised
and notified by the Central
Government for such purpose or
possesses
the
Associateship
Diploma of the Institution of

By transfer/ deputation :1. Two Years experience as Government
Analyst;
2. (a) A graduate in medicines or science
or
Pharmacy
or
Pharmaceuticals
Chemistry of recognised university or has
an equivalent qualification recognised and
notified by the Central Government for
such purpose and having five years
experience after graduation in Medicine or
Pharmaceuticals Chemistry in the testing
of drugs in a laboratory under the control
of – (i) a Government Analyst appointed
under the Drugs and Cosmetics Act, 1940
; or (ii) the Head of an Institution of
testing laboratory approved for the
purpose by the appointing authority or has
completed two years training on testing of
drugs, including items stated in Schedule
C of the Drugs and Cosmetics Rules, 1945
in Central Drugs Laboratory ; or
(b) Possesses a postgraduate degree in
medicine or Science or Pharmacy
Pharmaceutical
chemistry
of
a
recognised university or has an
equivalent qualification recognised and
notified by the Central Government for
such purpose or possesses the
Associateship Diploma of the Institution
of Chemists (India) obtained by passing
the said examination with ‘Analysis of

<!-- page 26 -->

3574

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Serial
number

1

Designation

2

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4

Chemists (India) obtained by
passing the said examination with
‘Analysis
of
Drugs
and
Pharmaceuticals ’as one of the
subjects and after obtaining the said
post-graduate degree or diploma
possesses three years experience in
the testing of drugs in a laboratory
under the control of (i) a
Government Analyst appointed
under the said Act ; or (ii) the Head
of an Institution or testing
laboratory approved for the purpose
by the appointing authority or has
completed two years training in
testing of drugs, including items
stated in Schedule C of the Drugs
and Cosmetics Rules, 1945 in
Central Drugs Laboratory ;
Note- For the purpose of
examination of items in Schedule C
of the Drugs and Cosmetics Rules,
1945:(i) The persons appointed under
clause (a) of column (b) above and
having degree in medicine or
physiology or Pharmacology or
Microbiology or Pharmacy should
have experience or training in
testing of said items in an institution
or laboratory approved by the
appointing authority for a period of
not less than six months ;
(ii) The Person appointed under
clause (a) or column (b) above but
not having degree in the above
subjects should have experience or
training in testing of drugs
mentioned in Schedule C of the
Drugs and Cosmetics Rules, 1945
for not less than three years in an
institution or laboratory approved
by the appointing authority or have
completed two years training on
testing of drugs including items
stated in the said schedule C of the
Drugs and Cosmetics Rules, 1945 in
Central Drugs Laboratory; and
2. Hindi or Sanskrit upto Matric or
Higher Education.

Drugs and Pharmaceuticals ’as one of
the subjects and after obtaining the said
post-graduate degree or diploma
possesses three years experience in the
testing of drugs in a laboratory under the
control of (i) a Government Analyst
appointed under the said Act ; or (ii) the
Head of an Institution or testing
laboratory approved for the purpose by
the appointing authority or has
completed two years training in testing
of drugs, including items stated in
Schedule C of the Drugs and Cosmetics
Rules, 1945, in Central Drugs
Laboratory ;
Note- For the purpose of examination of
items in Schedule C of the Drugs and
Cosmetics Rules, 1945:(i) The persons appointed under clause
(a) of column (b) above and having
degree in medicine or physiology or
Pharmacology or Microbiology or
Pharmacy should have experience or
training in testing of said items in an
institution or laboratory approved by the
appointing authority for a period of not
less than six months ;
(ii) The Person appointed under clause
(a) or column (b) above but not having
degree in the above subjects should have
experience or training in testing of drugs
mentioned in Schedule C of the Drugs
and Cosmetics Rules, 1945 for not less
than three years in an institution or
laboratory approved by the appointing
authority or have completed two years
training on testing of drugs including
items stated in the said Schedule C of the
Drugs and Cosmetics Rules, 1945 in
Central Drugs Laboratory; and
3. Hindi or Sanskrit upto Matric or
Higher Education.

<!-- page 27 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
Serial
number

1
3

4

5

Designation

3575

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4

Designated
Officer

--

By promotion :08 years experience as Food Safety
Officer [the post of Government Food
Inspector (Group-C) will hereafter be
designated as Food Safety Officer
(Group-B)
and
experience
as
Government Food Inspector will be
counted for promotion as Designated
Officer].
By transfer/deputation:(i) Two
Years
Experience
as
Designated Officer; and
(ii) Hindi or Sanskrit upto Matric or
Higher Education.

Senior Drugs
Control Officer

--

By promotion :Five years experience as Drugs Control
Officer.
By transfer/deputation :(i)
Two years experience as Senior
Drugs Control Officer;
(ii) Second Class Bachelor degree in
Pharmacy
Or
Pharmaceutical Chemistry;
(iii) 1½
years
experience
in
manufacturing of at least one of the
substances specified in Schedule C
appended to the Drugs and
Cosmetics Rules, 1945;
Or
1½ years experience in testing of at least
one of the substances specified in the said
Schedule C in a laboratory approved for
the purpose by the licensing authority;
Or
Three years experience in inspection of
Firms manufacturing any of the
substances specified in the said
Schedules-C; and
(iv) Hindi or Sanskrit upto Matric or
Higher Education.

Deputy Public
Analyst

--

By promotion(i) Two years experience as Assistant
Public Analyst ;
(ii) has been declared qualified for
appointment as a Public Analyst by
the Board appointed and notified
by the Central Government for

2

<!-- page 28 -->

3576

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Serial
number

1

Designation

2

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4
such purposes under sub-rule(2) of
rule 6 of the prevention of Food
Adulteration Rules, 1955;
or
has been declared qualified for
appointment as a Food Analyst by
a Board appointed and notified by
the Authority as per clause (ii) of
sub- rule (1) of rule 2.1.4 of the
Food Safety and Standards
Rules,2011.
By transfer/ deputation :(i)
Two years experience as Deputy
Public Analyst ;
(ii)
has been declared qualified for
appointment as a Public Analyst
by a Board appointed and notified
by the Central Government for
such purposes under sub-rule(2)
of rule 6 of the prevention of
Food Adulteration Rules, 1955;
or
has been declared qualified for
appointment as a Food Analyst
by a Board appointed
and
notified by the Authority as per
clause (ii) of sub- rule(1) of rule
2.1.4 of Food Safety and
Standards Rules, 2011; and
(iii) Hindi or Sanskrit upto Matric or
Higher Education.

6

District Public
Analyst

--

By promotion(i) Two years experience as Assistant
Public Analyst ;
(ii) has been declared qualified for
appointment as a Public Analyst by
the Board appointed and notified by
the Central Government for such
purposes under sub-rule(2) of rule 6
of the prevention of Food
Adulteration Rules, 1955;
or
has been declared qualified for
appointment as a Food Analyst by a
Board appointed and notified by the
Authority as per clause (ii) of subrule (1) of rule 2.1.4 of the Food
Safety and Standards Rules, 2011.

<!-- page 29 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
Serial
number

1

Designation

2

3577

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4
By transfer/ deputation :(i) Two years experience as District
Public Analyst ;
(ii) has been declared qualified for
appointment as a Public Analyst by
the Board appointed and notified
by the Central Government for
such purposes under sub-rule(2) of
rule 6 of the prevention of Food
Adulteration Rules, 1955;
or
has been declared qualified for
appointment as a Food Analyst by
a Board appointed and notified by
the Authority as per clause (ii) of
sub- rule (1) of rule 2.1.4 of Food
Safety and Standards Rules, 2011;
and
(iii) Hindi or Sanskrit upto Matric or
Higher Education.

7

Senior Scientific
Officer
(Bacteriology)

(i) 1st Class Master’s degree in
Microbiology or Bio-Chemistry,
or 2nd Class Master’s degree in
Microbiology or Bio-Chemistry
or Bacteriology with one year’s
experience from a recognised
laboratory in Bio-logical Drugs
Analysis by Microbiological
Techniques ;
OR
1st Class B.Sc. (Honours) in
Microbiology or 1st Class B.Sc.
(Honours) with Microbiology or
Bio-chemistry or Bacteriology as
one of the subjects with three years
experience from a recognised
laboratory for the Analysis of
Biological Drugs by Microbiology
techniques ; and
(ii) Hindi or Sanskrit upto Matric or
Higher Education.

By transfer/deputation:(i) Two years experience as Senior
Scientific Officer (Bacteriology) ;
(ii) 1st Class Master’s degree in
Microbiology or Bio-Chemistry, or
2nd Class Master’s degree in
Microbiology or Bio-Chemistry or
Bacteriology with one year’s
experience from a recognised
laboratory in Bio-logical Drugs
Analysis by
Microbiological
Techniques;
OR
1st Class B.Sc. (Honours) in
Microbiology or 1st Class B.Sc.
(Honours) with Microbiology or
Bio-chemistry or Bacteriology as
one of the subjects with three years
experience from a recognised
laboratory for the Analysis of
Biological Drugs by Microbiology
techniques ; and
(iii) Hindi or Sanskrit upto Matric or
Higher Education.

8

Senior Scientific
Officer
(Pharmaceutical
Chemistry)

(i) 1st Class Master’s degree in
chemistry or Pharmacy or 2nd
Class Master’s degree in
chemistry or Pharmacy with

By transfer/deputation:(i)
Two years experience as Senior
Scientific Officer
(Pharmaceutical Chemistry);

<!-- page 30 -->

3578

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

Serial
number

1

Designation

2

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4

one year experience from a
recognised laboratory in the
analysis of Biological Drugs ;
OR
1st Class B.Sc. Honours in
Chemistry B.Sc. (Honours) in
Bio-Chemistry/B. Pharma with
3 years experience in the
analysis of Biological Drugs
from a recognised laboratory;
and
(ii) Hindi or Sanskrit upto Matric or
Higher Education.

(ii)

(iii)
9

Senior Scientific
Officer
(Pharmacology)

1st Class Master’s degree in
chemistry or Pharmacy; or 2nd
Class
Master’s
degree
in
chemistry or Pharmacy with one
year experience from a recognised
laboratory in the analysis of
Biological Drugs ;
OR
1st Class B.Sc. Honours in
Chemistry/ B.Sc. (Honours) in
Bio-Chemistry/ B. Pharma with
3 years experience in the analysis
of Biological Drugs from a
recognised laboratory; and
Hindi or Sanskrit upto Matric or
Higher Education.

(i) 1st Class Master’s degree in By transfer / deputation:Pharmacology ; or
(i) Two years experience as Senior
2nd Class Master’s degree in
Scientific Officer (Pharmacology);
Pharmacology with one year (ii) 1st Class Master’s degree in
experience in a recognised
Pharmacology ; or
laboratory in Pharmacology as
2nd
Class Master’s degree in
applicable to Biological Drugs
Pharmacology with one year
Analysis ;
experience
in
a
recognised
OR
laboratory in Pharmacology as
1st Class B. Pharma or B.Sc.
applicable to Biological Drugs
with Pharmacology as one of
Analysis ;
the subjects with 3 years
OR
experience
in
recognised
1st Class B. Pharma or B.Sc. with
laboratory in Pharmacology as
Pharmacology as one of the
applicable to Biological Drugs
subjects with 3 years experience in
Analysis; and
recognised
laboratory
in
(ii) Hindi or Sanskrit upto Matric
Pharmacology as applicable to
or Higher Education.
Biological Drugs Analysis; and
(iii) Hindi or Sanskrit upto Matric or
Higher Education.

10

Superintendent

--

11

Drugs Control
Officer

1. (a)
Second Class Bachelor
degree in Pharmacy
Or
Pharmaceutical Chemistry;
(b)
1½ years experience in
manufacturing of at least one of the

By promotion :Two years experience as Deputy
Superintendent;
By transfer/deputation :Two years experience as Deputy
Superintendent.
By transfer/ deputation :1. Two years experience as Drugs
Control Officer;
2. (a) Second Class Bachelor degree in
Pharmacy

<!-- page 31 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
Serial
number

1

12

Designation

2

Food Safety
Officer

3579

Academic
qualifications
and
experience, if any, for an
appointment
by
direct
requirement

Academic
qualifications
and
experience, if any, for an appointment
by other than direct requirement

3

4

substances specified in Schedule C
appended to the Drugs and
Cosmetics Rules, 1945;
Or
1½ years experience in testing of at
least one of the substances specified
in the said Schedule C in a
laboratory approved for the purpose
by the licensing authority;
Or
Three years experience in inspection
of Firms manufacturing any of the
substances specified in the said
Schedules C; and
2. Hindi or Sanskrit upto Matric
or Higher Education.

Or
Pharmaceutical Chemistry;
(b) 1½years experience in manufacturing
of at least one of the substances specified
in Schedule C appended to the Drugs
and Cosmetics Rules 1945;
Or
1½years experience in testing of at least
one of the substances specified in the
said Schedule C in a laboratory approved
for the purpose by the licensing
authority;
Or
Three years experience in inspection of
Firms manufacturing any of the
substances specified in the said
Schedules C; and
3. Hindi or Sanskrit upto Matric or
Higher Education.

1. Food Safety Officer shall be a By transfer / deputation:whole time officer and shall on the 1. Two years experience as Food Safety
date on which he is so appointed, Officer;
possesses the following:
2. Food Safety Officer shall be a whole
(i) a degree in Food Technology or time officer and shall on the date on
Dairy
Technology
or which he is so appointed, possesses the
Biotechnology
or
Oil following qualifications:
Technology or Agricultural (i) a degree in Food Technology or
Science or Veterinary Sciences
Dairy Technology or Biotechnology
or
Bio
chemistry
or
or Oil Technology or Agricultural
Microbiology
or
Master’s
Science or Veterinary Sciences or
Degree in Chemistry or degree
Bio chemistry or Microbiology or
in Medicine from a recognized
Master’s Degree in Chemistry or
university, or
degree in Medicine from a
(ii) any other equivalent/ recognized
recognized university, or
qualification notified by the (ii) any other equivalent/ recognized
Central Government, and
qualification notified by the Central
(iii) has successfully completed
Government, and
training as specified by the (iii) has successfully completed training
Food Authority in a recognized
as specified by the Food Authority in
institute or Institution approved
a recognized institute or Institution
for the purpose; and
approved for the purpose; and
2. Hindi or Sanskrit upto Matric or 3. Hindi or Sanskrit upto Matric or
Higher Education.
Higher Education.
Note:- Training mentioned at Note:- Training mentioned at serial
serial number (iii) will be given number (iii) will be given after
after selection of the candidate selection of the candidate and those
and those who will complete who will complete successful training
successful training will be will be appointed as FSO.
appointed as FSO.

<!-- page 32 -->

3580

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)
APPENDIX C
[see rule 14(1)]

Serial
number

1

Designation
posts

of

2

1

Senior
Government
Analyst

2

Government
Analyst

3

Designated
Officer

4

Senior Drugs
Control Officer

5

Deputy Public
Analyst

6

District Public
Analyst

7

Senior Scientific
Officer
(Bacteriology)

8

Senior Scientific
Officer
(Pharmaceutical
Chemistry)

9

Senior Scientific
Officer
(Pharmacology)

10

Superintendent

11

Drugs Control
Officer

12

Food Safety
Officer

Appointing
authority

Nature of Penalty.

Authority
empowered
to
impose
penalty

Appellate
authority

3

4

5

6

Government

(I) Minor Penalties As specified in the Haryana Civil
Services (Punishment and Appeal)
Rules, 2016;

Government

Government

(II) Major Penalties :
As specified in the Haryana Civil
Services (Punishment and Appeal)
Rules, 2016.

<!-- page 33 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 13, 2018 (KRTK. 22, 1940 SAKA)

3581

APPENDIX D
[see rule 14(2)]
Serial
number

Designation of posts

Nature of order

Authority
empowered to
make the order

Appellate
authority

1

2

3

4

5

Government

Government

1

Senior Government
Analyst

2

Government Analyst

3

Designated Officer

4

Senior Drugs Control
Officer

5

Deputy Public Analyst

6

District Public Analyst

7

Senior Scientific
Officer (Bacteriology)

8

Senior Scientific
Officer
(Pharmaceutical
Chemistry)

9

Senior Scientific
Officer
(Pharmacology)

10

Superintendent

11

Drugs Control Officer

12

Food Safety Officer

(I)

(II)

reducing or withholding the
amount of ordinary or additional
pension admissible under the rules
governing pension;
terminating the appointment of a
member of the Service otherwise
than on his attaining the age fixed
for superannuation;

ROOP RAM JOWEL,
Additional Chief Secretary to Government Haryana,
Health Department.

8432—C.S.—H.G.P., Pkl.
