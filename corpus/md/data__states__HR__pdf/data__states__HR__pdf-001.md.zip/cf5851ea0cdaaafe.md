---
doc_id: "cf5851ea0cdaaafe"
source_url: "https://hpgcl.org.in/uploads/notification/1893.pdf"
ministry: "Haryana Power Generation Corporation Limited, Haryana"
title: "Revision of HKRNL Wage Rates Nigam Wage Rates in the State of Haryana w.e.f. 01.07.2025"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f4f0b096802252f"
---

<!-- page 1 -->

HARYANA POWER GENERATION CORPORATION LTD

@

HPGCL
AN l5O: 9001, ISO: 14001 &
ISO:45001 COMPANY

Reod, Office: C-7, U,ria Bhawan. Sector-6. Panchkula
Corporate ldentitv Number: U45207HR19975GC033517
Website: www.hpqcl.orq.in
Telephone No. 0172-5023426

E-mail: dsgenl@hpgcl.org.in

From

Chief Engineer/Admn.,
HPGCL, Panchkula.
To

1.
2.
3.
4.
5.
6.
7.

All Chief Engineers in HPGCL.
Chief Accounts Officer, HPGCL, Panchkula.
Company Secy,, HPGCL, Panchkula.
1.R., HPUs, HPGCL, Panchkula.
XEN/FTPS, HPGCL, Faridabad,
AII FA & CAOs, HPGCL.
All Dy. Secy./Under Secy. in HPGCL, Panchkula.
Memo ruo. cnt

5 ,orrrroc-529(Vor- vn)t l8q3

Dated: Z6 .og.zozs

Subject: Revision of HKRNL Wage Rates (Nigam Wage Rates) in the State of
Haryana w.e.f. 01.07.2025.
Enclosed please find herewith a copy of Memo no. HKRNL/Finance/1683
12.09.2025
vide which revised wage rates for the manpower deployed through
dated
HKRNL has been supplied. These rates will be effective from 01 .07.2025.
This issues with the approval of Managing Director, HPGCL, please.
DA/As

above.

\l\

\4,*--

(Varun t*dmar)
Dy. Secy./Genl.,
for Chief Engineer/Admin.,
HPGCL, Panchkula.

1

2
3

4
5

6
7

SPS to Managing Director, HPGCL, Panchkula.
SPS to Director (Technical-l), HPGCL, Panchkula
SPS to Director (Technical-ll), HPGCL, Panchkula.
SPS to Director (Technical-lll), HPGCL, Panchkula
SPS to Director/Finance, HPGCL, Panchkula,
PA to Chief Engineer/Admin., HPGCL, Panchkula.
XEN/lT, HPGCL, Panchkula. lt is requested to host the above said memo on
HPGCL website.

<!-- page 2 -->

HaRverua

ofllce: -Kaushal Bhawa
No.

To

:

;'
\t.
1
5.
6.
7,
8.

T;

}GUS HAL ROZGAR NIGAM LTMTTED

Regl stered

I

,4

n, lP-2, Scrtor-3, Panchkula
Scctor- I

,It

illlI" Admlntstreuye Secrererter to Govern?nonr, Haryana.

A.ll the Hoada of Deperrment. tn the glete ol Haryene.

The Dlvlslonnl Cornml;elonere,

Arn ba !e/Ka nra l/Farlda ba d/Hlsn ilRotrta t a nd G urugre m Admt nletrailve

Dlvlslonc ln ttre Stete ol Haryena.
The Reglsrar, PunJab and Hiryane Hlgh Court, Chanctlgarh.
All the Managlng Dtroctors/Chlef l\drnlnlctralorc ol
Boarde/Corporallonrl State Publlc Soctot Undortaklngt ln the State
of Haryana.
All Clralrpersone/CEOs of all Statutory Bodlee of Govt. ol Haryana.
Roglstrar of all Unlvoreltles ln the State ol Haryana.
All Deputy Conrnrlsslonorg ln the State ol Haryana.

Memo No.._ HKRNL/Financel 1 6 83

Dated.- t a- a1_2o2. S

Revision of HKRNL Wage Rates (Nigam Wage Rates) in the State of
Haryana w.e.f. 01.O7.2025Please refer to the subject cited above.
The State Government has approved an increase ol 5o/o in Nigam Wage
Rates (Level-l to Level-lll) tor the manpower deployed through HKRNL w.e.f.
A1.07.2025 as under:Revised New Nigam Wage Rates (w.e.f. 01.O7.20251
ln Dlstricts of Category-lll
ln Districts of Category-ll
ln Districts of Category-l
Exp.
Exp.
Exp. >
Exp.0
Exp.
Exp. >
Exp.
Exp.
Exp.>
>5-10
>5-10
>5-10
-5
10
10
10
0-5
0-5

Sub:-

years

years

years

years

years

years

years

years

years

Base
rate

Base
rate +
10%

Base
rate +
20%

Base
rate

Base
rate +
10%

Base
rate +
20%

Base
rate

Base
rate +
10%

Base
rate +
20%

Level-l

2A,900

23,A00

25,700

L8,45O

20,300

22150

18,880

20,550

Level-ll

24,500
75,300

27,O50

29,550

24,300

26,500

22,900

25,0N

27,850

30,350

22,050
22,800

25,700

27,350

23,500

25,750

Levels

Level-lll

This issues with the Concurrence of Fina
vide their U O No. 1213312022-1FG1115928 dated 26.08.202

17,o50
20,800
2L,450

Department as conveyed

Chief Exec
Officer
Haryana Kaushal Rozgar Nigam Limited
Panchkula, Haryana
CC:1. PS to Principal Secretary for information of WPS YE&E
2. lT Division HKRNL to implement the same immediately.
