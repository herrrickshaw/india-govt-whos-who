---
doc_id: "27b9caead6521abe"
source_url: "https://jamabandi.nic.in/DeedTemplatesNew/Hindi/Transfer%20of%20Plot%20House%20with%20in%20MC%20Hindi.pdf"
ministry: "Jamabandi, Land Records, Haryana"
title: "HIndi(pdf)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "263c9cd427fa0150"
---

<!-- page 1 -->

lEifr vUrj.k nLrkost ¼rcnhy eyfd;r½
gfj;k.kk ljdkj xtV vf/klwpuk 16 twu 2014 ds vuqlkj LVkEi “kwYd ls eqDr A

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dk@dh gwa tks fd ,d

IykV@edku@ nqdku u0 ---------------------------------------------- jdck-------------------------------- oxZ xt ftldh lhek o
iSekbZ”k fuEu izdkj ls gS%&
iwoZ%&

------ QqV---------- bap----------------if”pe%&

mrj%&

------ QqV---------- bap----------------nf{k.k%&

------ QqV---------- bap--------------------- QqV---------- bap----------------

fLFkr fdyk@[kljk ua0---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- dkykSuh------------------------------------ vUn:u uxj ikfydk@uxj fuxe -----------------------esjh@gekjh viuh c:os jftLVªh u0--------------------- frfFk --------------------------- lc jftLVªkj------------------ [kjhn
vuqlkj c:os bUrdky ua0 ------------------------- o vuqlkj tekcUnh o’kZ ------------------------------ Hkkj jfgr-eyfd;r
gS A tks gj izdkj ds Hkkj ls ikd o lkQ gS A ftl ij eSusa dksbZ Hkh dtZ ljdkjh v/kZ ljdkjh ;k xSj
ljdkjh cSad ;k laLFkk fdlh O;fDr@ O;fDr;ksa ls ugha fy;k gqvk gS Hkkj eqDr gS A eSjs -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- dks mijksDr
fyf[kr IykV@edku@nqdku reke ekydku vf/kdkjh lfgr tks eq>s IykV@edku@nqdku lacaf/kr
izkIr gS A varj.k ¼rcnhy½ djuk pkgrs@pkgrh gwa A D;ksafd IykV@edku@nqdku etdwj ds varj.k
¼rcnhy½ dk eq>s iqjk vf/kdkj gkfly gS A vr% eSa vius gks”kks gokl [kqn jtkeUnh fcuk fdlh ds
fl[kk;s cgdk;s mijksDr IykV@edku@nqdku vFkkZr tks Hkh IykV@edku@nqdku mijksDr fyf[kr esa
eq>s crkSj ekfyd gd gkfly gS] ds lHkh vf/kdkj fcuk izfrQy ds fcuk dksbZ /ku jkf”k vftZr fd;s
vius---------------------------------------------------------------------------------------------------------------------------------------------------------------

dks

varj.k

¼rcnhy½ dj fn;k gS A vkt ds ckn varj.k “kqnk IykV@edku@nqdku ls esjk ;k esjs fdlh Hkh
mrjkf/kdkjh dk dksbZ rkYywd okLrk ugha jgk gS A varj.k ¼rcnhy½ “kqnk IykV@edku@nqdku es fdlh
izdkj dk dksbZ uqDl ;k gtZ ik;k tkos ;k fdlh dkuwuh ;k okd;kfr =qfV ds dkj.k varj.k izkIrdrkZ
ds LokfeRo ls fudy tkos rks mldk eSa Lo;a ftEesokj gqaxk A bl izdkj varj.k xzg.kdrkZ
IykV@edku@nqdku mijksDr fyf[kr dk iw.kZ :Ik ls ekfyd o Lokeh gks x;k gS A ftls og ftl rkSj
ls pkgs bLrseky dj ldsxk A mls vkxs varj.k ¼rcnhy½ djus dk Hkh mls iw.kZ vf/kdkj gkfly gksxk A
dCtk ekSdk ij varj.k izkIrdrkZ dk ekydkuk vly esa djk fn;k gS A uxj fuxe @ uxj ikfydk ds
fjdkMZ es varj.k “kqnk IykV@edku@nqdku xzg.kdrkZ ds uke rcnhy fd;s tkus es eq>@gesa dksbZ Hkh
vkifRr ugha gksxh A vr% ;g varj.k ys[k ¼rcnhy eyfd;r½ fu;ekuqlkj fu’ikfnr dj nh gS rkfd
izek.k jgs A ftl i<+ lqu o le> dj eSusa vius gLrk{kj@vaxqBk fd;s gS A vkt -------------------------------fnukad ----------------------------------xokg

xokg Z

varj.k drkZ

izkIrdrkZ
