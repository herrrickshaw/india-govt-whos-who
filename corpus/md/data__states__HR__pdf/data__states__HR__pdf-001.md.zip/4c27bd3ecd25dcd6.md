---
doc_id: "4c27bd3ecd25dcd6"
source_url: "https://cdnbbsr.s3waas.gov.in/s3194cf6c2de8e00c05fcf16c498adc7bf/uploads/2026/10/20261008313076397.pdf"
ministry: "Food, Civil Supplies and Consumer Affairs Department, Haryana"
title: "Haryana State Training Policy 2020"
date: ""
pages: 21
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "083b3729b158929e"
---

<!-- page 1 -->

का. - BT :
् Government of Haryana/eftamm acare
6 Directorate, Food, Civil Supplies and Consumer Affairs Department
न CY) iP निदेशालय, खाद्य, नागरिक आपूर्ति एवं उपभोक्‍ता मामले विभाग
विषय:- Implemention of suo motu disclosure under Section 4 of Right to
information Act-2005- issue of Guideline regarding.
क्या राज्य जन सूचना अधिकारी-कम-अधीक्षक, मुख्यालय अपने पत्र
BAH-RTI- 2026/8570 fH 27.09.2026 F By निदेशक, स्थापना शाखा-[, मुख्यालय अपने
पत्र कमांक 6ई()-2025/9305 दिनांक 05.0.2026 की ओर ध्यान देने का कष्ट करेगे?
विषयांकित मामले में आपको अवगत करवाया जाता है कि प्रशिक्षण शाखा,
मुख्य सचिव, हरियाणा सरकार, कार्यालय द्वारा जारी हिंदायतें क0 22/24/202-272. दिनांक
73.07.2020 द्वारा जारी हिदायतो को अपलोड करने के लिए उप निदेशक, LM, yen
मौखिक आदेशानुसार श्री राजन गोसाई, उप अधीक्षक, मुख्यालय को दिनांक 28.09.2026 को
५७58]. के माध्यम से उपलब्ध करवाई जा चुकी है तथा मौखिक रूप से भी बार बार
अनुरोध भी किया गया है।
अत; प्रशिक्षण शाखा, मुख्य सचिव, हरियाणा सरकार, कार्यालय द्वारा जारी
Haryana State Training Policy 2020 जोकि क0 22/24/202-2]78. दिनांक 73.07.2020
(प्रति सलंग्न) द्वारा जारी की गई है। आपकी सेवा में आवश्यक कार्यवाही हेतू प्रेषित है।
सलंग्न- उपरोक्तानुसार।
¥; élre
उप-अधीक्षक,
प्रशिक्षण शाखा
सेवा में
i. उप निदेशक, स्थापना शाखा-[, मुख्यालय।
2. राज्य जन सूचना अधिकारी-कम-अधीक्षक, मुख्यालय।
अशा0 कमांक टी0एसी0-/2026/ |१५॥4 frais, wire 06] blag
Noki- Me Havyang ४ A Ties Mey ee 2a is Sey eotaded #
. v oy widh dhs left Per Lac a n/a + 260७
एताआ्राछए॥॥. 200, 30 Bays Building, Sector: I7-B, ¢ handigarh/ 35a) Hse, 30 aa freer, Set i7-a,
चण्डीगढ़
ease visit us at hiipv/haryanalood.nic.in | |
E-mail/-trer, labfood08@gmail.com
aus BH 26
खाद्य नागरिक हि (पल are
हरियाणा, चण्डीमड

<!-- page 2 -->

TS
|
: क्‍
No. 22/24/202-2Trg.
HARYANA GOVERNMENT
CHIEF SECRETARY'S OFFICE
TRAINING BRANCH |
Dated Chandigarh, the 3% July, 2020 |
i All Administrative Secretaries in Haryana State |
Subject:- Haryana State Training Policy, 2020.
Respected/Sir/Madam, “<a |
I am directed to refer to the subject noted above and to inform you that
realizing the need for development of human resources to meet the challenges,
Government of India issued the National Training Policy, 202, which inter alia,
recommended that each state should formulate a training policy based on or similar to
the National Training Policy,
. The Haryana State Training Policy, 2020 has been formulated to fulfill the
need for a formal, articulated framework within which training needs to be conducted
at the State level.
Therefore, copies of Haryana State Training Policy, 2020 (both Hindi &
English, at Annexure-A & B) have been circulated on website of
http://csharyana,gov.in and also forwarded to you for its circulation &
implementation in all the Departments/Boards & Corporations and further necessary
action accordingly.
Yours Faithfully,
eae
Superintendent, Training,
for Chief Secretary to Govt., HR
Endst, No. 22/24/202-2Trg, Dated Chandigarh, the i3ts July, 2020
A copy is forwarded to the following for:-
i, The Director General, Haryana Institute of Public Administration, HIPA
Complex, Plot No. 76, Sector-8, Gurugram w.r.t her D.O. No.
DHIPA/937 dated 24.7.208 with the request to take all the required
further actions in the matter at their own level.
2. The Secretary, Council of Ministers (in Cabinet Branch) w,r.t, their U.O. |
No.9/98/2020-2 Cabinet dated 06.07.2020 for information. |
—-
for Chief Secretary to Govt., Payee |
Ahjn |

<!-- page 3 -->

= ie HARYANA STATE TRAINING POLICY 2020
\

4. PREAMBLE:

The Governmentf Haryana is committed to provide efficient, transparent and |
time bound governance of high quality to the people of Haryana, For this purpose |
Government of Haryana is also committed to maintain a high degree of efficiency, ।
| integrity and skill of the human resources at all levels of the hierarchy. Training is |
the most effective and time tested tool for bringing about good governance, |
enhancing the performance levels of employees and for taking the State to greater
heights. In addition to training the employees, it is also necessary to upgrade the
| skills and improve the attitude of citizens so that they can play a more effective role
in the governance of the State. The State Training Policy envisages the ultimate
| objective of achieving ‘Training for All’ and to provide the necessary
| infrastructure, institutions and personnel for achieving this objective.

2, BACKGROUND: |

2. Government of India had issued a National Training Policy in 996 through a set of
operational guidelines for the development of the human resources of the

Government, Subsequently there have been major changes in the country in terms
of rapid economic growth, devolution of funds and functions to the Panchayats and
Municipalities and enhanced transparency through the enactment of the Right to

] Information Act and =e to Services Act, globalization, climate change and
threats to internal security. This has multiplied the challenges before the civil |
services as they have to meet the increasing expectations and needs of the citizens
and have to keep on upgrading their knowledge and skills continuously.

2.2 Realizing the need for development of human resources to meet the challenges,
Government of India issued the National Training Policy, 2042, which inter alia,
recommended that each state should formulate a training policy based on or similar
to the National Training Policy. The Haryana State Training Policy, 2020 has been |
formulated to fulfil the need for a formal, articulated framework within which
training needs to be conducted at the state level. |

|
dy

<!-- page 4 -->

=

|
23 The Department of Personnel & Training circulated a Model State Training Policy |
for adoption by the states, The Haryana State Training Policy has been drafted with
this model as the basis. |
3. TRAINING OBJECTIVES ; |
Through the State Training Policy, the Government of Haryana shall aim at the |
following:- |
Develop a professional, impartial and efficient civil service at all levels to enable it |
to be responsive, committed, result oriented, transparent, accountable and change- |
oriented towards inclusive growth and empowerment of citizens,

Equip all functionaries of the government and Urban Local Bodies/ Panchayati Raj |
Institutions with adequate knowledge and skills, bring about positive attitudinal |
changes, and build their capacity to enhance performance at individual as well as
organizational levels with a view to bringing about good-governance. To inculcate |
in the functionaries ethical values, positive attitude, commitment to work and |
empathy towards vulnerable sections of society.

Promote organizational responsibility, commitment and accountability towards |
training and capacity building in government departments and organizations,

To establish a link between the career Progression of employees and capacity |
building, |
To impart necessary skills to citizens as well as civil society organizations and to
bring about attitudinal changes among them so that they can become partners in the |
development process of the State, |

To sensitize employees and citizens of Haryana towards social issues, such as

gender disparity, treatment of deprived sections of society, etc, |

To coordinate, promote and facilitate training and understanding of roles and |

responsibilities of elected representatives of Panchayati Raj Institutions and Urban
Local Bodies. |

To identify the gaps in the competency levels of individuals and organizations and
to use training as an effective tool for bridging the competency gaps for their current |
and future roles, |
|
|

aS ee a a ee ae की खा"

<!-- page 5 -->

= TRAINING CONCERNS AND TARGET:
(A) TRAINING CONCERNS:
Social, political and economic ambience is subject to constant change. The
government machinery would have to be continuously attuned to the changing
needs, Training interventions for the Civil Services would, therefore, focus on:

@ Responsiveness to the diverse and changing needs and expectations of the |
citizens and organizational, technological, economic and political |
developments.

() Commitment to constitutional provisions, legal and ethical values and good

governance.

(@ Awareness of technological, economic, environmental, social, legal and |
administrative developments

@ Transparency in public service and governance to ensure probity

in public life.
© Accountability to ensure high performance in every professional
field and cost effective methods of delivery
(B) TRAINING TARGETS:
4. All employees of Government of Haryana, State undertakings, State funded co-
a= institutions including Panchayati Raj Institutions and Local Bodies shall
be provided with training to equip them with the competencies for their current
and future jobs. Such training will be imparted:
a, At the time of their entry into service,
b. At appropriate intervals in the course of their careers. |
4.2 Training for all: Training will be imparted to all categories of civil servants
from the lowest to the highest levels.
4.3 Induction Training at the time of entry into service shall be imparted in the
following manner:
i, Haryana Civil Service officers: six months including three months district .
on-the-job secretariat training and practical revenue training
li, Other Group A officers: Six months including on-the-job training
87

<!-- page 6 -->

=
ite Group B officers: One to three months including on-the-job training
iv. Group C officials: Four weeks including on-the-job training |
v. Group D officials: Four weeks including on-the-job training
4.4 A combined foundational course for all officers of HCS and allied services shall be |
conducted by HIPA. ‘Pride of My State’ should be part of the JFC and other long
term training programs to be organised by HIPA & other training institutes, |
Messages by the Hon’ble Chief Minister should be a part of every training program |
covering various aspects of Public Administration & Governance. |

4.5 Training interventions would be prepared on the basis of requirements of
each level, encompassing, inter alia, functional skills, professional skills,
interpersonal, behavioral and public relations skills, organizational skills,
policy formulation, planning and policy analysis ete. |

4.6 — Facilities of training shall be made available to all employees to meet the needs of
individuals and organizations as and when they arise through a mix of |
conventional courses, distance and e-learning.

4.7 Departments/ Organizations shall provide suitable training to employees before or
after promotion to posts of higher responsibility for a period adequate to equip
such employees with the competency to handle the additional responsibilities,
Similar training shall also be imparted to employees coming on deputation from |
other organizations.

4.8 — Training and Capacity building in the areas of Urban and Rural Development is of |
Paramount importance especially in the backdrop of the 73td and 74th
Amendments of the Constitution which have brought about a radical change in the |
status and functioning of the Panchayati Raj Institutions and Urban Local Bodies. It
is imperative that the officers and staff are sensitized in the functioning of the
tassroots institutions of rural and urban governance.

et ee 0 3]

<!-- page 7 -->

z 4.9 Refresher Training shall be imparted to all Group A, Band C employees for a
period of no less than five days once in every five years.
= IAS officers allottedto Haryana shall be given practical training in Revenue along
with theoretical training.

4.. The trainees who don't successfully complete the training programs may be
relegated to attend the same training program again until they possess the required
level of competency. The probation period shall be extended of those employees
who do not pass the induction training programs. Some other actions like non-
inclusion in foreign training programs may also be imposed upon the trainees who
don’t successfully complete the training program. Suitable incentives may be
considered on completion of the Induction/ in-service training programs. The
related provisions may be inserted in the corresponding Service Rules.

42 Training Programs on Ethics & Integrity, soft skills, Language & Etiquettes along
with stress management etc. may be organized quarterly. In these (and others too)
training programs, case studies with current examples should be taken up in the
training of participants for motivation,

4.3_ Training programs for JEs/ MEs and other engineering staff should be organized
regularly at leading Engineering Institutes where the newer technology and the
improved methods can be taught to the trainees.

4.4 Sanctioned Posts should make provision for training and leave reserve to ensure |
that efficiency of an establishment doesn’t suffer while sending employees for |
training.

|

4.5... 5शांग् retired officers with distinguished career record may be assigned for दर
mentoring of the newly appointed officers to guide them towards public service.

4.6 Spiritual/ Yoga institutes should also be made partners in the training program for
instilling ethics and positive attitude among the trainees.

<!-- page 8 -->

के

गन्ना

|
a Types OF TRAINING: |
a, State government employees will receive technical training, administrative and
in- service training, and for selected categories foreign training also, |

b. — Composition and implementation of technical training
This type of training is undertaken by the concerned department and the
Primary technical work of the institutes affiliated to that concerned |
department under the supervision and control of HIPA, Every department and
existing training institute will be responsible for design, development, planning, |
coordination, and implementation of technical training as well as for |
evaluating the trainees and certifying them, It is necessary for the departments to |
extend compulsory training to such officers who have been appointed after |
transferand who need Specialized knowledge to carry work as per the nature of the |
job. The concerned departments should Prepare an annual training Programme for |
technical training and make budgetary provision for expenditure and inform |
HIPA of the details of the annual training programme and budgetary |
provisions for the same.
Ae Composition and implementation of administrati ve and in service training . |
This form of training aims at making suitable change in knowledge, skills |

and attitude. Such training is necessary for the staff of all departments. The areas |
for such training include Public administration, social responsibility, project |
management, good governance, management skill, financial issues, human |
resource development, establishment, related laws, computer training etc, |
This training being important for general capacity building of the
administration and for motivation and suitable functioning, that must be
compulsorily given to employees on all posts. The responsibility for this training
will lie with HIPA as it is the apex training institute as well as that which will |
build up, plan, Prepare expert trainers, evaluate, Organize examinations and
grant certificates, and also with Divisional administrative institutes and district |
administrative training centres. This training will be compulsory to the staff, |
Particularly after the staffis appointed. |

|

।

|

|

<!-- page 9 -->

| TLS Oe Sa ne a SG TE | ,

Officers / staff will be given training as indicated in the stages below for
the durations to be decided from time to time. It will be necessary to determine
the duration of the training for junior level staff in terms of hours than in days.

Types of Training:
i, Foundation Training
ii, After promotion training
iii. RefresherTraining
iv. After transfer training:

This training will be extended to only such officers and staff who have
being transferred outside their department and whose nature of work has changed
after the transfer. The duration of this training will be between and 3 days. (7 to
2] hours)

v. Orientation training
vi. Foreign Training: — (Detailed at Point No. ] of this policy).
6, TRAINING NEED ANALYSIS:
6.. Every department/ organization shall prepare a training plan which addresses the
gap between the existing and the required competency and provide opportunities
to the employees to develop their competencies on the basis of TNA in association
with the STIs. Haryana Institute of Public Administration and other State Training
Institutions (such as HIRD/ HRMI/ Patwar Training School/SCERT & DIETs) shall
conduct Training Need Analysis every year in every/corresponding
department(s) to determine the competency gaps and to formulate training
programmes to bridge these gaps.
6.2 However, the Administrative Department can undertake Training Need Analysis
by some other means regarding general or specific topic at its own level with |
| approval of the Nodal Department at any time. |
| 6.3 State Government may give responsibility to any other public/private or |
| autonomous agency to conduct Training Need Analysis on general or specific topic, |
| if it desires so. |
| |
| |
| |
। |
|
| |
| |
a ea eee ee ee ef RS te
W

<!-- page 10 -->

हट = |
|
64 Questionnaire for the Training Need Analysis will be circulated among the
departments by HIPA to evaluate the training needs of all the departments for all |
the cadres, |
6.5 HIRD in association with HIPA shall prepare the Training Need Analysis for |
elected Panchayati Raj Institutions functionaries. |
7. TRAINING RELATED HUMAN RESOURCE: |
7A It is necessary that all departments must take special care to maintain quality of
human resources related to training. Thus procedure to select qualified and efficient |
candidates both as regular trainers and trainers on deputation and to extend |
motivational benefits needs to be established so that those who have M.Phil, Ph.D
degrees or have cleared NET or SET, and have training experience are willing to be |
regular trainer for purposes of training as well as suitable government officers are
| drawn to, |
7.2 To maintain consistency in training, the training institutes should be
prompted to appoint regular trainers up to the extent of 25% and those with field
experience as trainers on deputation to the extent of 25%, and the remaining 50%
through external trainers. The last group will consist of retired officers, trainers on
contract and guest faculty. Similarly, the training institutes should be induced to |
organize trainer development programmes for trainers, to extend opportunities
within the country and abroad for administrative research. Suitable incentives |
shall be provided to trainers.
8. ROLE OF DEPARTMENTS AND ORGANIZATIONS: |
Each Department/Organization of Government of Haryana shall adopt a
Systematic Approach to Training (SAT) and shall: |
i) Ensure that the Systematic Approach to Training (S.A.T.) cycle, comprising the
following stages are adhered to in all training interventions; |
> Identification of Training Needs |
> Planning and Designing of Training.
> Development of Trainers |
> Development of Training Material |
