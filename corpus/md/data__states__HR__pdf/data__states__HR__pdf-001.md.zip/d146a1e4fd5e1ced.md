---
doc_id: "d146a1e4fd5e1ced"
source_url: "https://haryana-rtsc.gov.in/public/storage/guidelinesnew/CGxoaDwjoKU5URubAfWdc2LXB5Eeos8S14jvAXKV.pdf"
ministry: "Haryana Right To Service Commission, Haryana"
title: "Auto Appeal System (AAS) Manual"
date: ""
pages: 59
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ff901830688e64a5"
---

<!-- page 1 -->

Auto Appeal System

(AAS)

URL: https://aas.saralharyana.nic.in

Version 2.2.2
Released on 7th March 2024

<!-- page 2 -->

Index
S.No.

Topic

Page No.

1.

Introduction

3

2.

Process Flow

4

3.

First Grievance Redressal Authority (1st GRA)

5

4.

Second Grievance Redressal Authority (2nd GRA)

26

5.

Designated Officer (DO)

30

6.

Chief Commissioner – HRTSC

33

7.

Commissioner - HRTSC

47

8.

AAS Nodal Officer

52

9.

CM Window Appeals - Monitoring User

58

2|Auto Appeal System (AAS)

<!-- page 3 -->

Introduction
Auto Appeal System (AAS) - A system to file auto appeals on behalf of eligible persons as soon as the
notified timeline for the application is breached and a facility to applicants to file appeal in other cases.
Appeals can only be filed for the Services that are notified under Haryana Right To Service Act, 2014 and
also on-boarded on Saral Tracker.


Auto Appeal:
For any application that crosses notified timeline, an automatic appeal would be raised on behalf of
eligible persons and assigned to the First Grievance Redressal Authority of the service.
This appeal would be auto escalated to Second Grievance Redressal Authority if no action or final
decision is made by First Grievance Redressal Authority in 30 working days of the appeal submission.
In case no action or final decision is made by Second Grievance Redressal Authority in 30 working days
of the appeal submission to the said authority then this appeal would be auto escalated to RTS
Commission.



Appeal filed through Antyodaya Saral Portal or through Antyodaya Saral Helpline :
Appeal can be filed by Applicant on Antyodaya Saral Portal (https://saralharyana.gov.in) or through
Antyodaya Saral Helpline (0172-3968400) in following cases:
Applicant is dissatisfied with the final decision on the appeal by First Grievance Redressal Authority or
Second Grievance Redressal Authority.
Application disposed off with in notified timeline.

3|Auto Appeal System (AAS)

<!-- page 4 -->

Process flow

4|Auto Appeal System (AAS)

<!-- page 5 -->

First Grievance Redressal Authority (1st GRA)
1st GRA logs in to the Auto Appeal System (AAS) - https://aas.saralharyana.nic.in

Note: ‘Forgot Password’ option can be used to reset password. Password will be sent to the Email id of the
User.
Logged in User will view all his/her roles e.g. in this case it is 1st GRA and 2nd GRA

5|Auto Appeal System (AAS)

<!-- page 6 -->

Click on First Grievance Redressal Authority role, user will see all his/her locations

On clicking Location, user will land to the following screen. This screen will list all the appeals filed to
him/her of the selected location

6|Auto Appeal System (AAS)

<!-- page 7 -->

On click of appeal, following details will appear. For the sake of explaining, this screen is marked with
sections 1 to 5 as follows:

1

3

2

4

5

Section 1:
a) By clicking icon

, list of all appeals can be filtered as per types of action, appeal date & service

7|Auto Appeal System (AAS)

<!-- page 8 -->

b) By clicking

icon, user can select number of appeals to be viewed at a time

c)

icon, appeals list can be exported to excel

By clicking

d) By clicking

icon, appeals list can be exported to pdf

e) By clicking

icon, appeals list can be printed

f)

Search box is also given to search appeal

Section 2:
List of all the appeals under the 1st GRA, their respondents & source appears here

8|Auto Appeal System (AAS)

<!-- page 9 -->

Section 3:
Details of each appeal can be viewed by the 1st GRA. The timeline bar shows 30 working days for 1st GRA to
take action on appeal. Red colour shows number of working days elapsed since appeal submission and green
colour shows working days left.

Appeal and application details are shown at the time of submission of appeal so ‘Track Status’ button is
given to view current status along with details of the application/appeal submitted by the eligible person.

9|Auto Appeal System (AAS)

<!-- page 10 -->

Section 4:
a) Appellant/Respondent Details: Details of appellant, designated officer, 1st GRA (in case of Commission
login), 2nd GRA (in case of Commission login) and additional respondent(s) (if any) can be viewed by clicking
icon

On click of ‘Add additional respondent’ button, the following pop-up appears where respondent details can
be saved.

10 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 11 -->

b) Action History: Actions taken on the appeal can be viewed in Action History

Section 5:
Actions that can be taken by 1st GRA:
a) Appeal Resolved – to resolve the appeal
b) Dismiss Appeal – to dismiss the appeal
c)

Issue Directions – to issue directions to Designated Officer (DO)

d) Call for Hearing – to call Appellant & Designated Officer for hearing
e) Reschedule Hearing Date – to reschedule hearing date.
f)

Interim Order – to pass interim orders

g) Final Judgement – to pass final judgement on the appeal

a) Appeal Resolved : 1st GRA can resolve the appeal
b) Dismiss Appeal: 1st GRA can dismiss the appeal
c)

Issue Directions: 1st GRA can issue directions as shown in following screen.

Attendance/Reply Details: 1st GRA can record attendance of attendees and may ask reply from
Appellant/DO/Respondent (if any) by checking checkbox and entering due date of reply.

11 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 12 -->

Download Template: This option is provided to download prefilled template (shown below) for the selected
action by the authority. This template is a word document which can be edited as per requirement and can
be printed, signed and scanned for uploading orders/judgement.

Email Preview: SMS/Email alerts would be sent to Appellants and Designated Officer. Email preview shows
the content that will be sent to Appellants & Designated Officer and it can be edited if needed be.

12 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 13 -->

1s GRA will select Action, enters directions in ‘Order’ textbox, upload directions in pdf format if required, fill
CAPTCHA code and click ‘Submit’ button.

Once directions are issued to DO, DO can login and view the directions issued to him and enter reply details
accordingly. This is explained in Designated Officer section (Refer page 23)

d) Call For Hearing: 1st GRA can call DO & eligible person for hearing

13 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 14 -->

e) Reschedule Hearing Date: 1st GRA can also reschedule the Hearing Date

f) Interim Order: 1st GRA can pass Interim order on the appeal and may also call for hearing by setting hearing
date & time. 1st GRA will records details of attendees and may ask reply from Appellant/DO/Respondent (if
any) by checking checkbox and entering due date of reply.

14 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 15 -->

On click of ‘View & Upload Reply’ button, following pop-up will be visible where 1st GRA can view reply filed
by Appellant/DO can be viewed and provision is also made to upload reply on the behalf of replier if reply is
received through other means like email etc.

1s GRA will enters Interim order in ‘Order’ textbox, upload order in pdf format if required, fill CAPTCHA code
and click ‘Submit’ button.

Once submitted, the following message is displayed on the screen.

15 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 16 -->

g) Final Judgement: 1st GRA can pass Final Judgement on the appeal as shown below.
1st GRA will records details of attendees and enter final judgement in ‘Order’ box
For passing final judgement, ‘Upload Judgement’ is mandatory. This will also be sent to HOD and/or
Administrative Secretary email if ‘Send Email’ option is checked

File Reply Version 2.0 :
Haryana Right to Service Commission (HRTSC) can now seek reply from 1st GRA also. This option is provided
to view & file reply. Click ‘Open Menu’ to view the menu and then click ‘File Reply’.

16 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 17 -->

On clicking File Reply, following screen will be displayed. On left section, appeals will be listed on which
Haryana Right to Service Commission (HRTSC) is seeking reply from the logged in user i.e 1st GRA in this case.

On click of appeal, details like order date and reply due date will be displayed. Reply can be filed by entering
details like reply, reply date and uploading reply document (if required) and clicking ‘Submit’ button as
shown below:

Assign Designated Officer Version 2.2 :
CM Window has been integrated with Auto Appeal System (AAS). AAS Nodal Officer and First Grievance
Redressal Authority need to assign Designated Officer (DO) for the appeals generated corresponding to the
grievances received from CM Window. Appeals corresponding to the services whose First Grievance
Redressal Authority (1st GRA) is either at State level or at District level will be visible to First Grievance
Redressal Authority (1st GRA) for Designated Officer assignment.

17 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 18 -->

These appeals would be visible to the First Grievance Redressal Authority (1st GRA) (for taking action on
appeal) only if their Designated Officers will be assigned.
Logged in User will land to the following screen. Click on ‘Assign Designated Officer’ button as below:

.
Following screen will be visible:

On selecting Department, all the services whose appeals have been generated corresponding to CM Window
grievances will be shown in Service dropdown. Now select service name and click ‘GO’ button, all the records
would be displayed as shown in the following screen.
1st GRA can do following:
i) Assign Designated Officer
ii) Reject Appeal

18 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 19 -->

i) Assign Designated Officer:

These records contains Appeal Reference Id, Appeal date and CM Window grievance related details. On
clicking icon for Grievance Document, CM Window document can be previewed as below:

19 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 20 -->

Select Designated Officer against each row as shown below:

Click on ‘Assign Designated Officer’ button, following message will be shown:

Now go to Home screen by clicking option ‘Home ’ from Menu, click on the Location as below:

20 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 21 -->

Appeal(s) whose designated officer(s) was assigned would now be visible to 1st GRA. Now 1st GRA may take
action on appeal.

Note: By clicking icon , list of all appeals can be filtered on various parameters including ‘Appeal Source’.
On selecting ‘CM Window’ in Appeal Source parameter, only CM Window appeals will be filtered as shown
below:

21 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 22 -->

ii) Reject Appeal:
On reviewing the details of the CM window grievance, if it is found that department/service of the appeal
does not match with the grievance then it can be rejected as explained below.
Click on ‘Reject’ button as shown below:

Select Rejection reason and enter remarks and click on ‘Reject’ button

22 | A u t o A p p e a l S y s t e m ( A A S )

Version 2.2.2

<!-- page 23 -->

Following message will be shown:

Click ‘Yes’ to reject the appeal and ‘Cancel’ to close the pop-up box.

Reports: Click ‘Open Menu’ to view the menu

User can click Cause List/Appeal reports from the menu shown below:

23 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 24 -->

a) Cause List: Cause List of all the Appeals can be viewed for a given date. Search and print provision is
also provided

b) Appeals Report: Appeal Register (List of all the Appeals) can be viewed. Appeals can be filtered between
two appeal dates and also by selecting one or more status. Search, Export to Excel/Pdf and print provision is
also provided.

On clicking Appeal, following pop-up will appear displaying ‘Appeal History’ along with Directions Issued/
Replies/ Order/ Judgement documents (if any)
24 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 25 -->

25 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 26 -->

Second Grievance Redressal Authority (2nd GRA)
2nd GRA logs in to the Auto Appeal System (AAS) - https://aas.saralharyana.nic.in

Logged in User will view all his/her roles e.g. in this case it is 2nd GRA. Click on Second Grievance Redressal
Authority role, user will see all his/her locations

On clicking Location, user will land to the following screen. This screen will list all the appeals of the selected
location that are auto- escalated to him/her as no final decision was made by 1st GRA within 30 working days
of appeal submission and appeals filed by eligible person through Antyodaya Saral portal and helpline in case
he/she is dissatisfied with final judgement by 1st GRA. On click of appeal, following details will appear. This
screen is already explained in detail in Section First Grievance Redressal Authority (1st GRA) (Refer Page 5).

26 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 27 -->

Actions that can be taken by 2nd GRA:
a) Appeal Resolved – to resolve the appeal
b) Dismiss Appeal – to dismiss the appeal
c)

Issue Directions – to issue directions to Designated Officer (DO)

d) Call for Hearing – to call Appellant & Designated Officer for hearing
e) Reschedule Hearing Date – to reschedule hearing date.
f)

Interim Order – to pass interim orders

g) Final Judgement – to pass final judgement on the appeal

a) Appeal Resolved : 2nd GRA can resolve the appeal
b) Dismiss Appeal: 2nd GRA can dismiss the appeal
c)

Issue Directions: 2nd GRA can issue directions.

d) Call For Hearing: 2nd GRA can call DO & eligible person for hearing

27 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 28 -->

On click of ‘Submit’ button, there is provision to book Video Conferencing(VC) on date of call for hearing. On
clicking ‘Yes’, Video Conferencing(VC) will be booked on NIC Meet along with Call for hearing other wise call
for hearing action will be submitted without booking Video Conferencing(VC).

28 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 29 -->

e) Reschedule Hearing Date: 2nd GRA can also reschedule the Hearing Date
f) Interim Order: 2nd GRA can pass Interim order on the appeal along with hearing. 2nd GRA will record
details of attendees and may ask reply from Appellant/DO/Respondent as explained in 1st GRA Section
g) Final Judgement: 2nd GRA can pass Final Judgement on the appeal as shown below.
2nd GRA will records details of attendees and may also impose penalty of Rs.250/- to Rs.5000/- on
Designated Officer/Additional Respondents and can disburse compensation to eligible person from the
penalty levied.
Final judgement can be entered in ‘Order’ box. For passing final judgement, ‘Upload Judgement’ is
mandatory. This will also be sent to HOD and/or Administrative Secretary email if ‘Send Email’ option is
checked

Eligible
Person
Details

File Reply Version 2.0 :
Haryana Right to Service Commission (HRTSC) can now seek reply from 2nd GRA also. ‘File Reply’option is
provided to view & file reply. Here appeals will be listed on which Haryana Right to Service Commission
(HRTSC) is seeking reply from the logged in user i.e 2nd GRA in this case. This process is already explained in
detail in Section First Grievance Redressal Authority (1st GRA) (Refer Page 5).

29 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 30 -->

Designated Officer (DO)
DO logs in to the Auto Appeal System (AAS) - https://aas.saralharyana.nic.in
DO can respond to the Directions issued by Grievance Redressal Authorities/Haryana Right to Service
Commission (HRTSC)

DO will select the Location

30 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 31 -->

Appeals related to DO will appear here. DO can view directions given by Grievance Redressal Authorities/
HRTSC and enter reply details.

On clicking ‘Submit’ button, reply will be submitted. This reply can be viewed in ‘Action History’

31 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 32 -->

Reports:
Replies submitted by DO can be viewed in ‘Reply Submitted’ report.

Appeals can be filtered between two appeal dates. Search, Export to Excel/Pdf and print provision is also
provided.

32 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 33 -->

Chief Commissioner - HRTSC
Chief Commissioner logs in to the Auto Appeal System (AAS) - https://aas.saralharyana.nic.in

Logged in User will land to the following screen. This screen will list appeals of all the departments (except
those assigned to the Commissioner) that are auto- escalated to him/her as no final decision was made by
2nd GRA within 30 working days of appeal submission and appeals filed by eligible person through Antyodaya
Saral portal and helpline in case he/she is dissatisfied with final judgement by 2nd GRA.

33 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 34 -->

On click of appeal, following details will appear. This screen is already explained in detail in Section First
Grievance Redressal Authority (1st GRA) (Refer Page 5).

Actions that can be taken by Chief Commissioner:
a) Appeal Resolved – to resolve the appeal
b) Dismiss Appeal – to dismiss the appeal
c)

Issue Directions – to issue directions and seek reply from Appellant, Designated Officer (DO), Additional
Version 2.0
Respondent, 1st GRA and/or 2nd GRA

d) Call for Hearing – to call Appellant & Designated Officer for hearing
e) Reschedule Hearing Date – to reschedule hearing date.
f)

Interim Order – to pass interim orders and seek reply from Appellant, Designated Officer (DO),
Version 2.0
Additional Respondent, 1st GRA and/or 2nd GRA

g) Final Judgement – to pass final judgement on the appeal

a) Appeal Resolved : Chief Commissioner can resolve the appeal
b) Dismiss Appeal: Chief Commissioner can dismiss the appeal
c) Issue Directions: Chief Commissioner can issue directions to and seek reply from Appellant, Designated
Officer (DO), Additional Respondent, 1st GRA and/or 2nd GRA. This process is already explained in detail in
Section First Grievance Redressal Authority (1st GRA) (Refer Page 5).

34 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 35 -->

35 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 36 -->

On click of ‘View & Upload Reply’ button, following pop-up will be visible where reply filed by Appellant,
Designated Officer (DO), 1st GRA and/or 2nd GRA can be viewed and provision is also made to upload reply on
the behalf of replier, if reply is received through other means like email etc.

d)

Call For Hearing: Chief Commissioner can call DO & eligible person for hearing

36 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 37 -->

On click of ‘Submit’ button, there is provision to book Video Conferencing(VC) on date of call for hearing. On
clicking ‘Yes’, Video Conferencing(VC) will be booked on NIC Meet along with Call for hearing other wise call
for hearing action will be submitted without booking Video Conferencing(VC).

e) Reschedule Hearing Date: Chief Commissioner can also reschedule the Hearing Date
e) Interim Order: Chief Commissioner can pass Interim order on the appeal along with hearing Chief
Commissioner will record details of attendees and may ask reply from Appellant, Designated Officer
(DO), Additional Respondent, 1st GRA and/or 2nd GRA. . This process is already explained in detail in
Section First Grievance Redressal Authority (1st GRA) (Refer Page 5).
f)

Final Judgement: Chief Commissioner can pass Final Judgement on the appeal as shown below.
Chief Commissioner records details of attendees and may also impose penalty of up to Rs.20,000/- on
Designated Officer/Additional Respondents and can disburse compensation to eligible person from the
penalty levied.
Final judgement can be entered in ‘Order’ box. For passing final judgement, ‘Upload Judgement’ is
mandatory. This will also be sent to HOD and/or Administrative Secretary email if ‘Send Email’ option is
checked

37 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 38 -->

Eligible
Person
Details

Grant Permission: Chief Commissioner may grant/revoke permission of the department(s) to the
Commissioner through this module for hearing the appeals. Commissioner would then be able to take action
on appeals and/ or suo moto appeals of the departments assigned to him/her.
Click ‘Open Menu’ to view the menu

38 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 39 -->

Click ‘Grant permission’

Following screen will be displayed:
Select Commissioner from Commissioner dropdown list to whom permission is to be granted, check/uncheck
checkbox for Suo Moto and Auto Appeal against the department and click ‘Submit’ button.
Note: Changes done here for auto appeals will be reflected next day. Appeals filed through Antyodaya Saral
portal and helpline will be visible in real time.

39 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 40 -->

40 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 41 -->

On click of ‘Submit’, following message will appear:

Transfer of Appeals: Chief Commissioner may transfer or take back individual appeals from the
Commissioner through this module.
Click ‘Open Menu’ to view the menu and select ‘Transfer of Appeals’, following screen will be displayed:
There are two options as highlighted on the screen below :
A) Allocation
B) Reallocation

41 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 42 -->

A) Allocation: Chief Commissioner may transfer appeals to commissioner through this option

3
1

2

Section 1:
Select Department(s) and /or District(s) to view appeals of the selected departments/districts and click
‘Show’ button to view appeals.
By clicking

icon, appeals list can be printed

Search box is also given to search appeal from the list.

Section 2:
List of Appeals will be displayed in this section and appeals can be selected/deselected by check/uncheck
checkbox given againt each appeal.

Section 3:
Select Commissioner from Commissioner dropdown to whom appeals are to be transferred and click
‘Transfer’ button.

42 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 43 -->

B) Reallocation: Chief Commissioner may take back appeals or reallocate to another Commissioner through
this option

3
1

2

Section 1:
Select Commissioner from Commissioner dropdown from whom to take back appeals and click ‘Show’ button
to view appeals.
By clicking

icon, appeals list can be printed

Search box is also given to search appeal from the list.

Section 2:
List of Appeals will be displayed in this section and appeals can be selected/unselected by check/uncheck
checkbox given againt each appeal.

Section 3:
Select Chief Commissioner/ Commissioner from Commissioner dropdown to whom appeals are to be
reallocated and click ‘Reallocate button
43 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 44 -->

Reports: Click ‘Open Menu’ to view the menu and click Cause List/Appeal reports, following screen will be
displayed:
a) Cause List: Cause List of all the Appeals can be viewed for a given date. Search and print provision is also
provided

b) Appeals Report: Appeal Register (List of all the Appeals) can be viewed. Appeals can be filtered between
two appeal dates and also by selecting one or more status.
Search, Export to Excel/Pdf and print provision is also provided.

44 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 45 -->

On clicking Appeal, following pop-up will appear displaying ‘Appeal History’ along with Directions Issued/
Replies/ Order/ Judgement documents (if any).

c) CM Window Appeals - Summary Report:

Version 2.2.1

‘CM Window Appeals - Summary Report’ is available to monitor summarized view of CM window appeals as
shown below:

45 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 46 -->



By clicking




By clicking
icon, appeals list can be exported to excel
Search box is provided to search in the appeals list

icon, user can select number of appeals to be viewed at a time

d) CM Window Appeals - Detailed Report: Version 2.2.1
‘CM Window Appeals - Detailed Report’ is available to monitor detailed view of all the CM window appeals
as shown below.

Here ‘Pending for DO Assignment’ means whether DO assigment is already done or pending. ‘Status’ shows
appeal status i.e. whether any action is taken on appeal by the concerned authority or not.


By clicking




By clicking
icon, appeals list can be exported to excel
Search box is provided to search in the appeals list

icon, user can select number of appeals to be viewed at a time

46 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 47 -->

Commissioner - HRTSC
Commissioner logs in to the Auto Appeal System (AAS) - https://aas.saralharyana.nic.in

Logged in User will land to the following screen. This screen will list appeals of the department(s) assigned to
him by Chief Commissioner that are auto- escalated to him/her as no final decision was made by 2 nd GRA
within 30 working days of appeal submission and appeals filed by eligible person through Antyodaya Saral
portal and helpline in case he/she is dissatisfied with final judgement by 2nd GRA.

47 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 48 -->

On click of appeal, following details will appear. This screen is already explained in detail in Section First
Grievance Redressal Authority (1st GRA) (Refer Page 5).

Actions that can be taken by Commissioner:
a) Appeal Resolved – to resolve the appeal
b) Dismiss Appeal – to dismiss the appeal
c)

Issue Directions – to issue directions and seek reply from Appellant, Designated Officer (DO), Additional
Version 2.0
Respondent, 1st GRA and/or 2nd GRA

d) Call for Hearing – to call Appellant & Designated Officer for hearing
e) Reschedule Hearing Date – to reschedule hearing date.
f)

Interim Order – to pass interim orders and seek reply from Appellant, Designated Officer (DO),
Version 2.0
Additional Respondent, 1st GRA and/or 2nd GRA

g) Final Judgement – to pass final judgement on the appeal

a) Appeal Resolved : Commissioner can resolve the appeal
b) Dismiss Appeal: Commissioner can dismiss the appeal
c)

Issue Directions: Commissioner can issue directions to and seek reply from Appellant, Designated
Officer (DO), Additional Respondent, 1st GRA and/or 2nd GRA. This process is already explained in detail in
Section First Grievance Redressal Authority (1st GRA) (Refer Page 5).

48 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 49 -->

On click of ‘Submit’ button, the following Success message appears.

d) Call For Hearing: Commissioner can call DO & eligible person for hearing
e) Reschedule Hearing Date: Commissioner can also reschedule the Hearing Date
f) Interim Order: Commissioner can pass Interim order on the appeal along with hearing. Commissioner
will record details of attendees and may ask reply from Appellant, Designated Officer (DO), Additional
Respondent, 1st GRA and/or 2nd GRA. This process is explained in 1st GRA Section
g) Final Judgement: Commissioner can pass Final Judgement on the appeal as shown below.
Commissioner records details of attendees and may also impose penalty of up to Rs.20,000/- on
Designated Officer/Additional Respondents and can disburse compensation to eligible person from the
penalty levied.
Final judgement can be entered in ‘Order’ box. For passing final judgement, ‘Upload Judgement’ is
mandatory. This will also be sent to HOD and/or Administrative Secretary email if ‘Send Email’ option is
checked

49 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 50 -->

Reports: Click ‘Open Menu’ to view the menu and click Cause List/Appeal reports from the menu shown
below:
a) Cause List: Cause List of all the Appeals can be viewed for a given date. Search and print provision is also
provided

50 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 51 -->

b) Appeals Report: Appeal Register (List of all the Appeals) can be viewed. Appeals can be filtered between
two appeal dates and also by selecting one or more status.
Search, Export to Excel/Pdf and print provision is also provided.

On clicking Appeal, pop-up will appear displaying ‘Appeal History’ along with Directions Issued/ Replies/
Order/ Judgement documents (if any).

51 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 52 -->

AAS Nodal Officer

Version 2.2

CM Window has been integrated with Auto Appeal System (AAS). AAS Nodal Officer and First Grievance
Redressal Authority need to assign Designated Officer (DO) for the appeals generated corresponding to the
grievances received from CM Window. Appeals corresponding to the services whose First Grievance
Redressal Authority (1st GRA) is neither at State level nor at District level will be visible to AAS Nodal Officer
for Designated Officer assignment.
These appeals would be visible to the First Grievance Redressal Authority (1st GRA) (for taking action on
appeal) only if their Designated Officers will be assigned.
AAS Nodal Officer logs in to the Auto Appeal System (AAS) - https://aas.saralharyana.nic.in with the user
credentials already shared with them for https://login.saralharyana.nic.in

Logged in User will land to the following screen.

On selecting Department, all the services whose appeals have been generated corresponding to CM Window
grievances will be shown in Service dropdown. Now select service name and click ‘GO’ button, all the records
would be displayed as shown in following screen.
AAS Nodal Officer can perform following actions:
i) Assign Designated Officer
ii) Reject Appeal

52 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 53 -->

i) Assign Designated Officer:

These records contains Appeal Reference Id, Appeal date and CM Window grievance related details. On
clicking icon under Grievance Document, CM Window document can be previewed as below:

53 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 54 -->

Select Designated Officer against each row as shown below:

Click on ‘Assign Designated Officer’ button, following message will be shown:

54 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 55 -->

Now Designated Officer is successfully assigned and these Appeal(s) would be visible in 1st GRA login as
shown below and he/she may take action on the appeal(s).

ii) Reject Appeal:
On reviewing the details of the CM window grievance, if it is found that department/service of the appeal
does not match with the grievance then it can be rejected as explained below.
Click on ‘Reject’ button as shown below:

55 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 56 -->

Select Rejection reason and enter remarks and click on ‘Reject’ button

Following message will be shown:

Click ‘Yes’ to reject the appeal and ‘Cancel’ to close the pop-up box.

Reports:
CM Window Appeals - Detailed Report:

Version 2.2.1

56 | A u t o A p p e a l S y s t e m ( A A S )

Version 2.2.2

<!-- page 57 -->

Click ‘Open Menu’ to view the menu and click ‘CM Window Appeals - Detailed Report’ from the menu to
view/monitor all the CM window appeals related to AAS Nodal Officer’s department(s) as shown below:

Here ‘Pending for DO Assignment’ means whether DO assigment is already done or pending. ‘Status’ shows
appeal status i.e. whether any action is taken on appeal by the concerned authority or not.


By clicking

icon, user can select number of appeals to be viewed at a time



By clicking

icon, appeals list can be exported to excel



Search box is provided to search in the appeals list

57 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 58 -->

CM Window Appeals - Monitoring User Version 2.2.1
CM Window has been integrated with Auto Appeal System (AAS). For monitoring such appeals, following
reports are available in Auto Appeal System (AAS):
i. CM Window Appeals - Summary Report
ii. CM Window Appeals - Detailed Report

CM Window Appeals - Monitoring User logs in to the Auto Appeal System (AAS) https://aas.saralharyana.nic.in

Logged in user will land to the following screen:
i. CM Window Appeals - Summary Report: It shows summarized information of CM Window appeals.



By clicking




By clicking
icon, appeals list can be exported to excel
Search box is provided to search in the appeals list

icon, user can select number of records to be viewed at a time

58 | A u t o A p p e a l S y s t e m ( A A S )

<!-- page 59 -->

ii. CM Window Appeals - Detailed Report:
Click ‘Open Menu’ to view the menu and click ‘CM Window Appeals - Detailed Report’ from the menu to
view/monitor detailed view of all the CM window appeals as shown below:

Here ‘Pending for DO Assignment’ means whether DO assigment is already done or pending. ‘Status’ shows
appeal status i.e. whether any action is taken on appeal by the concerned authority or not.


By clicking




By clicking
icon, appeals list can be exported to excel
Search box is provided to search in the appeals list

icon, user can select number of appeals to be viewed at a time

*********** End ***********

59 | A u t o A p p e a l S y s t e m ( A A S )
