---
doc_id: "eea99c9e733afc6d"
source_url: "https://csharyana.gov.in/wp-content/uploads/2026/10/Orders-dated-15.10.2026.pdf"
ministry: "Chief Secretary Office, Haryana"
title: "Posting or Transfer of HCS Officers."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f441d4331d0da933"
---

<!-- page 1 -->

ORDER

The Governor of Haryana is pleased to make posting/transfer of the following
HCS officers with immediate effect:-

Name and Designation

Sr.
No.
1.

2.

Posted/Transferred as

Remarks

Shri Sumeet Sihag, HCS Zonal

Administrator,
HSAMB, Karnal, in addition
to his present duties.

Relieving Shri

(2016), Sub Divisional Officer
(Civil), Assandh.

Satish Kumar, HCS
(2011) of the said

Ms. Monika, HCS (2023),

Zonal

Against a vacant

Joint Director (Administration

and Mid-day Meals),

charge.

Administrator,
HSAMB, Hisar.

post.

Elementary Education,
Haryana.

Dated Chandigarh

the 1Sth October, 2026

ANURAG RASTOGI
Chief Secretary to Government, Haryana

No. 1/'159/2026-1Sll

Dated Chandigarh, the 15th October,2026

A copy, each, is fonruarded to the officers concerned for information and
necessary action.

Deputy Secretary to Government, Haryana,
Person nel Depa rtment.J.

No.

1/159/2026-15ll

Dated Chandigarh, the 15th October,2O2G

A copy, each, is foru,uarded for information and action, where necessary to the
following:Secretary to Governor, Haryana.
All the Additional Chief Secretaries, Principal Secretaries and Commissioner &
Secretaries to Government, Haryana.
Director General, Haryana lnstitute of Public Administration, HIPA Complex,
Sector 18, Gurugram.
Resident Commissioner, Government of Haryana, Haryana Bhawan, New Delhi.
All concerned Heads of Departments/MDs of Boards/Corporations.
Commissioners, Ambala/Faridabad/Gurugram/Hisar/Karnal/Rohtak Divisions.
Chief Electoral Officer, Haryana.
Director General, lnformation, Public Relations & Languages, Haryana.
Secretary to Government, Haryana, Secretariat Establishment Department.
All the Deputy Commissioners in Haryana.
Principal Accountant General (A & E) and (Audit), Haryana, Chandigarh.
Secretary,Lokayukta,Haryana.
Secretary, Haryana Public Service Commission.
Secretary, Haryana Vidhan Sabha, Chandigarh.
Secretary, House Allotment Committee, U.T., Chandigarh.
Deputy Controller (Finance & Accounts) Rents, U.T., Chandigarh.
SlO, NlC, Haryana Civil Secretariat, Chandigarl

1.
2.
3.

4.
5.
6.
7.
B.
9.
10.
11.
12.
13.
14.
15.
16.
17.

Deputyr"###,
Personnel

Department.

Haryana,

).

<!-- page 2 -->

No. 1/159/2026-1Sll

Dated Chandigarh, the 1sth October,2026

A copy, each, is forwarded to the Chief Principal Secretary/ Deputy Principal
secretary/Deputy Principal Secretary-lt/oSD(SG)/ oSD(vK)/ oSD (RSy oSD (NpMy

OSD(BBB)/ OSD (RN)/ OSD (VS)/ Special Senior Secretaries/ Senior Secretaries/
Secretaries/ Private Secretaries to Chief Minister/ Ministers/ Speaker for the information
of Chief Minister/ Ministers/ Speaker.

) . , ,___-l\r_
Deputy

a"ffi;ment,
Personnel Department

No. 1/159/2026-1Sll

Haryana,

)r

Dated Chandigarh, the 1sth Octob er, 2O2O

A copy, each, is fonryarded to the DDOs Concerned with the request that the
LPC, leave salary & pension contributions of officers concerned should be issued within
7 days of relinquishing of the charge, in the prescribed format as notified vide Gazette
Notification No. 1110512025-2FR115592, dated 01.04.2026, and a copy thereof shall
invariably be endorsed to the Chief Secretary to Government, Haryana (in Services-lV
Branch) for record and further action.
Deputy Secretary to G-dvernment, Haryana,
Personnel Department.

J_

INTERNAL DISTRIBUTION
1. Secy./CS.
2. Supdt.,services-l,lll,lV,V & PAR Cell/HR l, ll, & lll Br.
3. Sr. A.O., AIS (GlS).
4. Supdt., Training /Accounts/ Estt.-1, ll & lll Br.
5. RA at RA's Residence.
6. Secy./SPS.
7. ll?, Computer Section.
8. Lib., Haryana Civil Secretariat.
9. Llaison Officer, Telephones 10.25ll, 35ll,45ll, SSll, 65ll & 75Il.
