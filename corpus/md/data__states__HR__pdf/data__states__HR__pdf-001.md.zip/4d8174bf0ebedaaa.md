---
doc_id: "4d8174bf0ebedaaa"
source_url: "https://cdnbbsr.s3waas.gov.in/s3333ac5d90817d69113471fbb6e531bee/uploads/2025/09/202509151574327012.pdf"
ministry: "Civil Aviation Department, Haryana"
title: "VAT reduction Notification dated 01 August 2025 for RCS UDAN Operations at Hisar (Size: 770 KB, Format: PDF, Language: English/Hindi)"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ad04f7d08826d600"
---

<!-- page 1 -->

Haryana Government Gazette
EXTRAORDINARY
Published by Authority
© Govt. of Haryana
No. 133-2025/Ext.] CHANDIGARH, FRIDAY, AUGUST 1, 2025 (SRAVANA 10, 1947 SAKA)

vkcdkjh rFkk djk/kku foHkkx
fnukad 1 vxLr] 2025
/ST-1.— pwfa d] gfj;k.kk ds jkT;iky dh larfq"V gks xbZ gS fd ,slh ifjfLFkfr;ka fo|eku gSa] ftuds
dkj.k yksdfgr esa rqjUr dkjZokbZ djuk vko';d gS;
blfy,] vc gfj;k.kk eky vkSj lsok dj vf/kfu;e] 2017 ¼2017 dk 19½ dh /kkjk 174 dh mi&/kkjk ¼1½ ds [k.M
¼i½ ds lkFk ifBr gfj;k.kk ewY; of/kZr dj vf/kfu;e] 2003 ¼2003 dk 6½ dh /kkjk 59 dh mi&/kkjk ¼1½ ds ijUrqd ds
lkFk ifBr mDr mi-/kkjk ds v/khu çnÙk 'kfä;ksa dk ç;ksx djrs gq,] gfj;k.kk ds jkT;iky] blds }kjk] iwoZ uksfVl dh
“krZ dks vfHkeqDr djrs gq,] mä vf/kfu;e ls layXu vuqlwph d esa] bl vf/klwpuk ds jkti= esa izdk”ku dh frfFk lss
fuEufyf[kr la'kks/ku djrs gSa] vFkkZRk~%&
gfj;k.kk ewY; of/kZr dj vf/kfu;e] 2003 ¼2003 dk 6½ es]a vuqlwph d esa] [kkuk 1] 2 rFkk 3 ds uhps &
¼i½
Øe la[;k 3 d rFkk mlds lkeus çfof"V;ksa ds LFkku ij] fuEufyf[kr Øe la[;k rFkk mlds lkeus
çfof"V;k¡ çfrLFkkfir dh tk,axh] vFkkZRk~%&
1
Þ3d

2
foekuu VjckbZu bZa/ku izfof’V 7] 3[k rFkk 3x ds v/;/khu

3
20%”;

¼ii½ Øe la[;k 3[k rFkk mlds lkeus çfof"V;ksa ds LFkku ij] fuEufyf[kr Øe la[;k rFkk mlds lkeus
çfof"V;k¡ çfrLFkkfir dh tk,axh] vFkkZRk~%&
1
Þ3[k

2
3
1%”;
tc foekuu VjckbZu bZa/ku {ks=h; la;kstdrk ;kstuk
¼vkj0lh0,l0½&mM+ku lfgr lHkh gokbZ vM~Mksa ij lHkh ;k=h mM+kuksa
dks cspk tkrk gS] rks blds lkFk layXu çek.ki= izLrqr djus dh 'krZ
ds v/;/khuA
fVIi.k: mijksä çfof"V jkti= esa çdk'ku dh frfFk ls çHkkoh gksxh vkSj 6 tqykbZ] 2027 rd ykxw jgsxhA
(1726)

<!-- page 2 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 1, 2025 (SRVN. 10, 1947 SAKA)

1727

@
1%

;

¼iii½ Øe la[;k 3x rFkk mlds lkeus çfof"V;ksa ds LFkku ij] fuEufyf[kr Øe la[;k rFkk mlds lkeus
çfof"V;k¡ çfrLFkkfir dh tk,axh] vFkkZRk~%&
1
Þ3x

2
tc foekuu VjckbZu bZa/ku O;ogkjh dks cspk tkrk gS] tks lHkh
,evkjvks ¼j[kj[kko] ejEer vkSj vksojgky½ xfrfof/k;ksa vkSj gokbZ
lkgfld xfrfof/k;ksa esa mi;ksx fd;k tkrk gS] rks blds lkFk
layXu çek.ki= izLrqr djus dh 'krZ ds v/;/khuA

3
1%”;

fVIi.k: mijksä çfof"V jkti= esa çdk'ku dh frfFk ls çHkkoh gksxh vkSj 6 tqykbZ] 2027 rd ykxw jgsxhA

Øe la[;k&
çekf.kr fd;k tkrk gS fd uhps fn, x, fooj.k ds vuqlkj foekuu VjckbZu bZa/ku
¼,0Vh0,Q0½ & ¼foekuu VjckbZu bZa/ku cspus okys O;ogkjh dk uke½ ls [kjhnk x;k gSA
Øe
la[;k

chtd la[;k

fnukad

Ekk=k

ewY;

fnukad %
,;jykbal ds izkf/k—r vf/kdkjh@gokbZ lkgfld xfrfof/k ds vk;kstd ds gLrk{kj ---------------------------------------------------------,;jykbal ds izkf/k—r vf/kdkjh@gokbZ lkgfld xfrfof/k ds vk;kstd dk uke vkSj inuke ---------------------------------------*,d çek.ki= esa dsoy ,d frekgh ds [kjhn fooj.k 'kkfey gksx
a sA**A

vkf”kek cjkM+]
vk;qDr ,oa lfpo] gfj;k.kk ljdkj]
vkcdkjh rFkk djk/kku foHkkxA

<!-- page 3 -->

1728

HARYANA GOVT. GAZ. (EXTRA.), AUG. 1, 2025 (SRVN. 10, 1947 SAKA)
HARYANA GOVERNMENT
EXCISE AND TAXATION DEPARTMENT
Notification
The 1st August, 2025

No. 35/ST-1.— Whereas, the Governor of Haryana is satisfied that circumstances exist, which render it
necessary to take immediate action in public interest;
Now, therefore, in exercise of the powers conferred by sub-section (1) of section 59 read with proviso to the
said sub-section of the Haryana Value Added Tax Act, 2003 (6 of 2003), read with the clause (i) of sub-section (1) of
section 174 of the Haryana Goods and Service Tax Act, 2017 (19 of 2017), the Governor of Haryana hereby makes
the following amendment in Schedule A appended to the said Act, with effect from date of its notification, by
dispensing with the condition of previous notice, namely:AMENDMENT
In the Haryana Value Added Tax Act, 2003 (6 of 2003), in Schedule A, under columns 1, 2 and 3(i)

for serial number 3A and entries thereagainst, the following serial number and entries thereagainst shall
be substituted, namely:1
“3A

(ii)

2
Aviation Turbine Fuel subject to entry 7, 3B and 3C.

3
20%”;

for serial number 3B and entries thereagainst, the following serial number and entries thereagainst shall
be substituted, namely:1
“3B

2
Aviation Turbine Fuel (ATF) when sold to All passenger
flights including under Regional Connectivity Scheme (RCS)UDAN, at all airports, subject to the condition of the submission
of the certificate appended herewith.

3
1%”;

Note: The above entry shall be effective from the date of publication in the Official Gazette and would
be applicable upto 6th July, 2027.
Explanation:(iii)

Flights that do not carry any passengers but operate only for refueling/parking
shall not be eligible for concessional rate of 1%.;

for serial number 3C and entries thereagainst, the following serial number and entries thereagainst shall
be substituted, namely:1
“3C

2
Aviation Turbine Fuel (ATF) when sold to the dealer which
get used in all MRO (Maintenance, Repair and Overhaul)
activities and air adventure activities, subject to the condition
of the submission of the certificate appended herewith.

3
1%”;

Note: The above entry shall be effective from the date of publication in the Official Gazette and would
be applicable upto 6th July, 2027.

<!-- page 4 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 1, 2025 (SRVN. 10, 1947 SAKA)

1729

CERTIFICATE FOR PURCHASE OF ATF
AT CONCESSIONAL RATE UNDER ENTRY NO. 3B and 3C
Serial No.____
Certified that Aviation Turbine Fuel (ATF) as detailed below has been
purchased from the - (Name of the dealer selling Aviation Turbine Fuel).
Serial No.

Invoice No.

Date

Quantity

Amount

Date:
Signature of Authorized Officer of the Airlines/Organizer of air adventure activity
....................................................
Name and designation of Authorized Officer of the Airlines/ Organizer of air adventure
activity ...............................
*One certificate shall contain purchases details of one quarter only.”

ASHIMA BRAR,
Commissioner and Secretary to Government Haryana,
Excise and Taxation Department.

12016—C.S.—H.G.P., Pkl.
