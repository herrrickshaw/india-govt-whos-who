---
doc_id: "2c6fbf6eb7dee5e3"
source_url: "https://cdnbbsr.s3waas.gov.in/s3194cf6c2de8e00c05fcf16c498adc7bf/uploads/2026/10/202610081855371218.pdf"
ministry: "Food, Civil Supplies and Consumer Affairs Department, Haryana"
title: "The Haryana Enforcement Draft Rules ,2026"
date: ""
pages: 104
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "befaf34c7b4a06f2"
---

<!-- page 1 -->

Haryana Government Gazette
EXTRAORDINARY
Published by Authority
© Govt. of Haryana
No. 155-2026/Ext.] CHANDIGARH, THURSDAY, OCTOBER 8, 2026 (ASVINA 16, 1948 SAKA)

gfj;k.kk ljdkj
[kk|] ukxfjd vkiwfrZ rFkk miHkksDrk ekeys foHkkx
vf/klwpuk
fnukad 8 vDrwcj] 2026
la[;k ,y-,e-&2026@izorZu@19662.— fu;eksa dk fuEufyf[kr izk:i] ftls gfj;k.kk ds
jkT;iky fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dk dsUnzh; vf/kfu;e 1½ dh /kkjk 53 ds v/khu
iznRr 'kfDr;ksa dk iz;ksx djrs gq, rFkk dsUnzh; ljdkj ls ijke’kZ djus ds ckn] cukus dk izLrko djrs
gaS rFkk /kkjk 53 dh mi/kkjk ¼4½ }kjk ;Fkk visf{kr] blds }kjk] ,sls O;fDr;ksa dh tkudkjh ds fy,
izdkf’kr fd;k tkrk gS] ftuds buls izHkkfor gksus dh lEHkkouk gS(
blds }kjk uksfVl fn;k tkrk gS fd jkti= es bl vf/klwpuk ds izdk’ku dh frfFk ls ,d lIrkg
dh vof/k dh lekfIr ij ;k ds ckn ljdkj fu;eksa ds izk:i ij] ,sls vk{ksikssa rFkk lq>koksa] ;fn dksbZ
gks]a ds lkFk tks vk;qDr ,oa lfpo gfj;k.kk ljdkj] [kk|] ukxfjd vkiwfrZ ,oa miHkksDrk ekeys foHkkx
}kjk izk:i fu;eksa ds laca/k esa fdlh O;fDr ls bl izdkj fofufnZ"V vof/k dh lekfIr ls iwoZ izkIr fd,
tk,a] fopkj djsxhA
12-

¼1½
¼2½
¼1½

Lkaf{kIr uke] rFkk
;s fu;e gfj;k.kk fof/kd eki foKku ¼izorZu½ fu;e] 2026 dgs tk ldrs gSA
izkjEHkA
;s jkti= esa buds izdk’ku dh frfFk ls ykxw gksx
a As
ifjHkk"kk,a A
bu fu;eksa es]a tc rd lanHkZ ls vU;Fkk visf{kr u gks]&
¼d½ Þvf/kfu;eÞ ls vfHkizk; gS] fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dk dsUnzh;
vf/kfu;e 1½(
¼[k½ Þiz’kkldh; lfpoß ls vfHkizk; gS] iz’kkldh; lfpo] gfj;k.kk ljdkj] [kk|]
ukxfjd vkiwfrZ ,oa miHkksDrk ekeys foHkkx(
¼x½ Þvihy izkf/kdkjhß ls vfHkizk; gS]&
¼i½
fu;a=d& ;fn lacaf/kr fof/kd eki foKku vf/kdkjh }kjk ikfjr vkns’k ds
fo:) vihy dh tkrh gS(
¼ii½ iz’kkldh; lfpo& ;fn fu;a=d }kjk ikfjr vkns’k ds fo:) vihy dh
xbZ gS(
(2643)

<!-- page 2 -->

2644

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼?k½

dfri; ekeyksa
esa ckV] eki ;k
la[;k dk
mi;ksxA
¼/kkjk 10½
tCr fd, x,
ckV ;k eki
vkfn dk fuiVku
djukA
[/kkjk 16¼1½]

ÞO;klekiuÞ ls vfHkizk; gS] lHkh izfØ;k] tks fdlh ckV ;k eki dh =qfV;ksa ds eku
dk fu/kkZj.k djus vkSj ;fn vko’;d gks] rks ,sls ckV ;k eki ds vU;
eki&oSKkfudxq.kksa dk fu/kkZj.k djus ds fy, vko’;d gksa vkSj blesa fdlh ckV ;k
eki ds xst&fpg~uksa vFkok eki&fpg~uksa dh okLrfod fLFkfr vFkok dqN ekeyks esa
ekih tkus okyh ek=k ds laxr eku ds lEcU/k esa dsoy dqN izeq[k fpg~uksa dk
fu/kkZj.k djuk Hkh 'kkfey gS(
¼³½ ÞfunsZ’k ekud iz;ksx’kkykÞ ls vfHkizk; gS] dsUnzh; ljdkj }kjk LFkkfir iz;ksx’kkyk]
tgka funsZ’k ekud] f}rh;d ekud vkSj dk;Zdkjh ekud vuqjf{kr fd, tkrs gSa(
¼p½ Þiathd`r O;fDrÞ ls vfHkizk; gS] bu fu;eksas ds fu;e 5 ds v/khu iathd`r fofuekZrk]
ejEerdrkZ vFkok O;ogkjh(
¼N½ Þiathdj.k izkf/kdkjhÞ ls vfHkizk; gS] fu;U=d] fof/kd eki foKku] gfj;k.kk vFkok
jkT; ljdkj }kjk fu;qDr dksbZ vf/kdkjh] tks mi fu;U=d] fof/kd eki foKku dh
inoh ls uhps dk u gks(
¼t½ ÞvuqlwphÞ ls vfHkizk; gS] bu fu;eksa ls layXu vuqlwph(
¼>½ ÞckV ;k eki dk Lo&LkR;kiuÞ ls vfHkizk; gS] ,sls fofuekZrk] tks dsUnzh; ljdkj
vFkok jkT; ljdkj }kjk ljdkjh vuqeksfnr ijh{k.k dans z ds :Ik esa vuqeksfnr gSa]
}kjk fufeZr ,sls ckV ;k eki ds lEcU/k esa bl vf/kfu;e vFkok blds v/khu cuk,
x, fu;eksa esa ;Fkk fofgr jhfr esa ckV ;k eki dk lR;kiu(
¼¥½ Þdq’ky deZdkjÞ ls vfHkizk; gS] ,slk O;fDr] ftldks fu;a=d }kjk ckV ;k eki dh
ejEer gsrq dkS’ky izek.ki= tkjh fd;k x;k gks(
¼V½ ÞjkT; ljdkjÞ ls vfHkizk; gS] iz’kkldh; foHkkx esa gfj;k.kk jkT; dh ljdkj(
¼B½ Þijh{k.k ckV ;k ekiÞ ls vfHkizk; gS] ,sls ckV ;k eki] tks dsoy ’kq}rk dh n`f"V
ls dk;Zdkjh ekud ckV ;k eki dh izfrd`fr gks(
¼M½ ÞlR;kiu izkf/kdkjhÞ ls vfHkizk; gS] fu;a=d] fof/kd eki foKku gfj;k.kk] fof/kd
eki foKku vf/kdkjh vFkok bl vf/kfu;e ds v/khu dsUnzh; ljdkj ;k jkT;
ljdkj }kjk vf/klwfpr ljdkjh vuqeksfnr ijh{k.k dsUnzA
¼2½
bu fu;eksa esa iz;qDr rFkk vifjHkkf"kr fdUrq mDr vf/kfu;e vFkok blds v/khu dsUnzh;
ljdkj }kjk cuk, x, fu;eksa esa ifjHkkf"kr ’kCnksa vkSj vfHkO;fDr;ksa ds ogh vFkZ gksx
a s] tks Øe’k% mDr
vf/kfu;e vFkok mlds v/khu dsUnzh; ljdkj }kjk cuk, x, fu;eksa esa mUgsa fn, x, gSaA
3iSdsV esa j[kh oLrqvksa ls fHkUu fdlh eky] eky ds oxZ vFkok opuc)rk ds lEcU/k esa dksbZ
laO;ogkj] O;ogkj ;k lafonk] vuqlwph 1 esa ;Fkk fofufnZ"V otu] eki ;k la[;k ds vuqlkj dh tk,xhA

4¼1½
fdlh Hkh vlR;kfir vkSj@;k vLVkfEir ckV ;k eki dks ml O;fDr dks okil dj fn;k
tk,xk] ftlls ,slk ckV ;k eki tCr fd;k x;k Fkk] ;fn fof/kd eki foKku vf/kdkjh ml O;fDr ds
vijk/k dk iz’keu dj nsrk gS vkSj ,slk lR;kiu vkSj@;k LVkEiu djokus ds fy, vuqlwph& IV esa
fofufnZ"V lR;kiu vkSj@;k LVkEiu Qhl lfgr fu;e 14 ds mifu;e ¼3½ esa fofufnZ"V vfrfjDr Qhl
ds Hkqxrku ij ,sls ckV vkSj eki dh okilh ds iUnzg fnu ds Hkhrj mudk lR;kiu vkSj LVkEiu djok;k
tkrk gSSA
¼2½
vf/kfu;e dh /kkjk 15 ds v/khu tCr vkSj fu:) fd, x, fdlh Hkh ckV ;k eki ;k oLrq
;k eky ¼[kjkc gksus okys@’kh?kz izkd`frd {k; ;k vU;Fkk½ ;k lEcfU/kr nLrkost] tks fdlh U;k;ky; esa
dk;Zokgh vFkok lEHkkO; dk;Zokgh ds v/;/khu gSa] vkSj U;k;ky; ds le{k fof/kd eki foKku vf/kdkjh
}kjk izLrqr fd, tkus gaS] dks U;k;ky; esa dk;Zokfg;ksa ds fu"d"kZ ds ckn fof/kd eki foKku vf/kdkjh
}kjk vius dCts esa fy;k tk,xk vkSj U;k;ky; ds vkns’kksa ds vuqlkj dk;Zokgh dh tk,xh%
ijUrq U;k;ky; ds vkns’kksa ds vHkko esa] CkkV ;k eki ;k oLrq ;k eky ¼[kjkc gksus okys@’kh?kz
izkd`frd {k; ;k vU;Fkk½ ;k lEcfU/kr nLrkostksa ds lECka/k esa fu;a=d }kjk fd, x, fo’ks"k vkns’k esa
fufnZ"V funsZ’k ds vuqlkj dk;Zokgh dh tk,xh vkSj mldh lkexzh csph tk,xh vkSj vkxeksa dks jkT;
ljdkj ds ikl tek djok;k tk,xk%

<!-- page 3 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

ijUrq ;g vkSj fd ;fn og O;fDRk] ftlus vijk/k fd;k gS] tCr@fu:) fooj.kh ij
gLrk{kj djus ls budkj djrk gS] rks fof/kd eki foKku vf/kdkjh dks vipkjh O;fDr }kjk ,slhs bUkdkjh
ds le; ij mifLFkRk de ls de nks O;fDr;ksa ds gLrk{kj izkIr djus pkfg,A vipkjh O;fDr dks YkkSVk,
x, eky ds ekeys es]a og opu nsxk fd og nks"kiw.kZ eky dks mlds nks"kksa dks lq/kkjs fcuk ugha cspsxk%
ijUrq ;g vkSj fd fu;a=d ;k ml }kjk bl fufeRr izkf/kd`r vf/kdkjh ;g fu.kZ; djus
ds fy, vafre izkf/kdkjh gksxk fd tCr vkSj fu:} fd;k x;k eky Rofjr ;k izkd`frd {k; ds v/;/khu
gSA
¼3½
tgka vf/kfu;e dh /kkjk 15 dh mi/kkjk ¼1½ ds v/khu tCr fd, x, eky] Rofjr ;k
izkd`frd {k; ds v/;/khu ugha gSa] rks fof/kd eki foKku vf/kdkjh] vijkph O;fDr vkSj mlds vfHkdrkZ
;k vU; O;fDr] ftlus vijk/k fd;k gS] dks fu;U=d }kjk ;Fkk fofufnZ"V ,slh tCrh dk uksfVl nsus ds
ckn] vf/kfu;e ds v/khu vfHk;kstu ds iz;kstu ds fy, eky dks j[k ldrk gSA
¼4½
mi&fu;e ¼2½ vkSj ¼3½ esa fufnZ"V ekyks]a tks fdlh U;k;ky; esa dk;Zokgh vFkok lEHkkO;
dk;Zokgh ds v/;/khu ugha gaS] dk fuiVku] mijksDr ekyksa dh tCrh ds fnu ls uCcs fnu dh lekfIr ds
ckn] fu;a=d }kjk fd, x, lkekU; ;k fo’ks"k vkns’k esa fufnZ"V funsZ’kksa ds vuqlkj fd;k tk,xkA
5¼1½
izR;sd fofuekZrk] ejEerdrkZ ;k O;ogkjh iathdj.k izkf/kdkjh dks iathdj.k izek.ki= ds
vuqeksnu ds fy, vuqlwph-V esa ;Fkk fofufnZ"V iathdj.k Qhl ds lkFk vuqlwph&II, III ;k IV, tSlh Hkh
fLFkfr gks] esa vkosnu izLrqr djsxk%
ijUrq ;fn ejEerdrkZ ds :Ik esa iathdj.k ds fy, vkosnd OkS;fDrd ls fHkUu gS] rks vkosnd
}kjk Lokeh@Hkkxhnkj@ funs’kd@lnL;@ deZpkjh] tSlh Hkh fLFkfr gks] ds laca/k esa fu;a=d }kjk
vuqlwph&III ds vuqlkj tkjh dkS’ky izek.ki= dh izfr iathdj.k ds fy, vkosnu djrs le; fn;k
tk,xk%
ijUrq ;g vkSj fd vkosnd ds iathdj.k ds le; ij bl izdkj mfYyf[kr dkS’ky izek.ki= ds
fooj.k esa ifjorZu] ;fn dksbZ gks] ds ekeys esa mls iathdj.k izkf/kdkjh dks lwfpr fd;k tk,xk] ftlesa
foQy jgus ij iathdj.k jn~n fd;k x;k le>k tk,xk%
ijUrq ;g vkSj fd fdlh fofuekZrk }kjk fufeZr fdlh ckV ;k eki] ftldk fuekZ.k gfj;k.kk jkT;
ls fHkUu fdlh vU; jkT; esa fd;k tkrk gS vkSj mldk mi;ksx gfj;k.kk jkT; esa Hkh fd;k tkrk gS] dh
ejEer djus ds fy, fofuekZrk }kjk mldk iathdj.k djokus dh vko’;drk ugha gksxh] fdUrq fofuEkkZrk
dks ejEer djus ds ckjs esa lEcfU/kr fof/kd eki foKku vf/kdkjh dks vfxze esa lwfpr djuk gksxk%
ijUrq ;g vkSj fd ,sls fofuekZrk] ejEerdrkZ ;k O;ogkjh] tks gfj;k.kk fof/kd eki foKku ¼izorZu½]
fu;e 2011 ds v/khu vuqKfIr/kkjd gSa] dks bu fu;eksa ds jkti= esa izdk’ku dh frfFk ls Ng ekl ds
Hkhrj iathdj.k izkf/kdkjh dks iathdj.k izek.ki= ds vuqeksnu ds fy, vuqlwph-V ds vuqlkj iathdj.k
Qhl ds lkFk vuqlwph&II, III ;k IV tSlh Hkh fLFkfr gks] esa vkosnu izLrqr djuk gksxk%
ijUrq ;g vkSj fd iwoZ esa izkIr dh xbZ vuqKfIr ds laca/k esa Hkqxrku dh xbZ jkf’k dk lek;kstu
vuqKfIr dh 'ks"k vof/k dh lhek rd fd;k tk,xkA
¼2½
iathdj.k izkf/kdkjh] mi&fu;e ¼1½ esa vkosnu izkIr gksus ij] fofuekZrk] ejEerdrkZ ;k
O;ogkjh] tSlh Hkh fLFkfr gks] dks vuqlwph&VI, VII ;k VIII tSlh Hkh fLFkfr gks] esa iathdj.k izek.ki=
tkjh djsxkA
¼3½
iathdj.k izek.ki= esa ifjorZu ;k izfrfyfi iathdj.k izek.ki= tkjh djus ds fy, Qhl]
vuqlwph-V ds vuqlkj iathdj.k Qhl dk vk/kk gksxhA
¼4½
bu fu;eksa ds v/khu iathd`r izR;sd ejEerdrkZ }kjk vuqlwph-IX ds vuqlkj /kujkf’k]
izR;sd iathdj.k izek.ki= ds fy, jkT; ljdkj ds ikl izfrHkwfr ds :i esa tek djokbZ tk,xhA
¼5½
iathdj.k izkf/kdkjh] bu fu;eksa ds v/khu iathd`r fofuekZrkvks]a ejEerdrkZvksa vkSj
O;ogkfj;ksa dk vuqlwph-X ds vuqlkj ,d jftLVj cuk, j[ksxkA
¼6½
bu fu;eksa ds v/khu iathd`r izR;sd fofuekZrk] ejEerdrkZ ;k O;ogkjh] iathdj.k izek.ki=
ds fucU/kuksa vkSj ’krksZa vFkok fu;a=d }kjk tkjh fd, x, fdUgha lkekU; ;k fo’ks"k funsZ’kksa vkSj ’krksZa ds
vuqlkj ,slh dk;Z’kkyk@midj.k@vkStkj@ jftLVj bR;kfn cuk, j[ksxkA
¼7½
bu fu;eksa ds v/khu tkjh fd, x, izR;sd iathdj.k izek.ki= dks iathd`r O;fDr }kjk
ml ifjlj] tgka iathd`r O;fDr O;olk; djrk gS] esa fdlh lgtn`’; LFkku ij iznf’kZr fd;k tk,xkA

2645

fofuekZrkvks]a
ejEerdrkZvksa vkSj
O;ogkfj;ksa dk
iathdj.kA
[/kkjk 23 ¼2½]

<!-- page 4 -->

2646

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼8½
bu fu;eksa ds v/khu tkjh fd;k x;k iathdj.k izek.ki= u rks fcØh ;ksX; gksxk vkSj u
gh gLrkUrj.k ;ksX; gksxkA
¼9½
tgka bu fu;eksa ds v/khu fdlh Hkh iathd`r O;fDr ds O;olk; dks mRrjkf/kdkj] fuoZlh;r
;k olh;rh] okfjl ;k olh;rnkj] tSlh Hkh fLFkfr gks] ds }kjk gLrkUrfjr fd;k tkrk gS] rks ,sls O;fDr
dk mRrjkf/kdkjh ;k fof/kd okfjl] tSlh Hkh fLFkfr gks] ,slk O;fDr ;k rks mlds vius uke ls ;k fdlh
vU; ds uke ls rc rd O;olk; ugha djsxk tc rd ,sls gLrkUrj.k dh frfFk ds ckn lkB fnu dh
vof/k dh lekfIr ls iwoZ mRrjkf/kdkjh ;k fof/kd okfjl] fu;a=d dks bu fu;eksa ds vuqlkj iathdj.k
izek.ki= tkjh djus ds fy, vkosnu ugha djrk gS%
ijUrq bl fu;e dh dksbZ Hkh ckr] mijksDr lkB fnu dh vof/k ds fy, iathd`r O;fDr ds :Ik
esa O;olk; djus ds fy, mRrjkf/kdkjh ;k fof/kd okfjl dks izfrf"k} djus okyh ugha le>h tk,xh vkSj
;fn og ,sls iathdj.k ds fy, vkosnu djrk gS] rks tc rd fu;a=d }kjk iathdj.k izek.ki= iznku

dkS’ky izek.k
i=A
[/kkjk 23 ¼2½]

ugha fd;k tkrk gS ;k vuqlwph-XI esa fufnZ"V iz:i esa fyf[kr :Ik esa uksfVl }kjk lwfpr ugha fd;k tkrk
gS] fd ,slk iathdj.k mldks iznku ugha fd;k tk ldrk%
ijUrq ;g vkSj fd tgka bu fu;eksa ds v/khu fdlh Hkh iathd`r O;fDr dk O;olk; fcØh] migkj]
iV~Vs ;k vU;Fkk }kjk gLrkUrfjr fd;k tkrk gS] ogka vUrfjrh ;k iV~Vns kj] tSlh Hkh fLFkfr gks] ,sls
O;olk; dks ;k rks mlds vius uke ls ;k fdlh vU; O;fDr ds uke ls rc rd ugha djsxk tc rd
mlus ,sls O;olk; dks djus ds fy, iathdj.k izek.ki= izkIr u dj fy;k gksA
6¼1½
fofuekZrk] tks dsoy mlds }kjk fufeZr ckV ;k eki dh ejEer djrk gS] ls fHkUu ,slk
O;fDr] fu;a=d dks vuqlwph&XII ds vuqlkj Qhl ds lkFk vuqlwph&XIII esa dkS’ky izek.ki= tkjh djokus
ds fy, vkosnu djsxk%
ijUrq dksbZ Hkh O;fDr ckV ;k eki dh ejEer djus ds fy, dkS’ky izek.ki= izkIr djus ds fy,
rc rd ik= ugha gksxk tc rd og fu;a=d }kjk le;&le; ij tkjh fd, x, lkekU; ;k fo’ks"k
vkns’kksa esa fofufnZ"V 'kS{kf.kd ;ksX;rk,a] rduhdh l{kerk ugha j[krk gks vkSj ,sls fucU/ku vkSj 'krksZa dks
iwjk ugha djrk gksA
¼2½
fu;a=d] mi&fu;e ¼1½ esa vkosnu izkIr gksus ds ckn] ejEerdrkZ dks vuqlwph& XIV esa
dkS’ky izek.ki= tkjh djsxkA

vfHkys[kksa vkSj
jftLVjksa dks
cuk, j[kukA
¼/kkjk 17½

7bu fu;eksa ds v/khu iathd`r izR;sd fofuekZrk] ejEerdrkZ ;k O;ogkjh vuqlwph -XV, XVI ;k XVII
tSlh Hkh fLFkfr gks] esa vfHkys[kksa vkSj jftLVj cuk, j[ksxk vkSj fu;U=d dks vuqlwph -XVIII, XIX ;k XX
tSlh Hkh fLFkfr gks] esa izR;sd frekgh ds vuqorhZ ekl ds nlosa fnu rd =Sekfld] fu;rdkfyd
fjiksZVZ@fooj.kh izLrqr djsxkA

iathdj.k dk
fuyacu vkSj
izfrlagj.kA
/kkjk 23 ¼2½

8¼1½
fu;a=d ;k bl fufeRr ml }kjk izkf/kd`r ,slk vU; vf/kdkjh] ;fn fo’okl dk ,slk
dkj.k j[krk gS fd bu fu;eksa ds v/khu tkjh fd, x, fdlh iathdj.k izek.ki= ds /kkjd us ,slk
iathdj.k izek.ki= tkjh djus ds fy, fdlh Hkh vkosnu esa ;k mlds laca/k esa dksbZ dFku fd;k gS] tks
fdlh rkfRod fof’kf"V;ksa esa xyr ;k vLkR; gS ;k fdlh fof/k ;k vf/kfu;e ;k mlds v/khu cuk, x,
fdlh Hkh fu;e ;k fd, x, vkns’k ds fdlh Hkh micU/k dk mYya?ku djrk gS] rks ,sls iathdj.k izek.ki=
ds /kkjd ds fo:) tkap ds iwjk gksus rd ,sls iathdj.k dks fuayfcr dj ldrk gS%
ijUrq ,slk iathdj.k izek.ki= rc rd fuyafcr ugha fd;k tk,xk tc rd mlds /kkjd dks
vuqlwph- XXI ds vuqlkj izLrkfor dkjZokbZ ds fo:) dkj.k crkus ds fy, ;qfDr;qDr volj u ns fn;k
x;k gks%
ijUrq ;g vkSj fd tgka bl mi&fu;e esa fufnZ"V tkap] iathdj.k izek.ki= ds fuyacu dh frfFk
ls rhu ekl dh vof/k ds Hkhrj iwjh ugha dh tkrh gS] rks ,slk fuyEcu iwoksZDr vof/k dh lekfIr ij
jn~n gks tk,xkA
¼2½
fu;a=d ;k bl fufeRr ml }kjk izkf/kd`r ,slk vU; vf/kdkjh] ;fn ,slh tkap] tks og
mfpr le>s] djus ds ckn larq"V gks tkrk gS fd iathdj.k izek.ki= ds /kkjd us mi&fu;e ¼1½ esa
fufnZ"V Lo:i dk feF;k ;k xyr c;ku fn;k gS] ;k mDr mi&fu;e esa ;Fkk fufnZ"V fof/k ds mica/kksa
dk mYya?ku fd;k gS] rks og ,sls iathdj.k dk izfrlagj.k djsxk%
ijUrq ,slk dksbZ iathdj.k rc rd jn~n ugha fd;k tk,xk tc rd fd mlds /kkjd dks
vuqlwph-XXI ds vuqlkj izLrkfor dkjZokbZ ds fo:) dkj.k crkus dk ;qfDr;qDr volj ugha fn;k x;k
gksA

<!-- page 5 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼3½
izR;sd O;fDr] ftldk iathdj.k fuyafcr dj fn;k x;k gS] ,sls fuyacu ds rqjUr ckn]
iathd`r O;fDr ds :Ik esa dk;Z djuk can dj nsxk vkSj rc rd O;olk; nksckjk ’kq: ugha djsxk tc
rd fd ,sls fuaycu ds vkns’k dks jn~n vFkok vfHk’kwU;] tSlh Hkh fLFkfr gks] ugha dj fn;k tkrk gSA
¼4½
izR;sd iathd`r O;fDr] ftldk iathdj.k izfrlagfjr dj fn;k x;k gS] ,sls izfrlagj.k
dh frfFk ls lkB fnu dh vof/k ds Hkhrj ;k fu;a=d ;k bl fufeRr ml }kjk izkf/kd`r ,sls vU;
vf/kdkjh }kjk] Ik;kZIr dkj.k n’kkZ;s tkus ij] ,slh vfrfjDr vof/k ds Hkhrj] tks rhu ekl ls vf/kd u
gks] ckV ;k eki] tks ,sls izfrlgaj.k dh frfFk dks mlds dCts] vfHkj{kk ;k fu;U=.k eas Fkk] dks vuqer
djsxk vFkok dk fuiVku djsxk vkSj ,slk djus esa vlQy jgus ij] fu;a=d ;k ml }kjk bl fufeRr
izkf/kd`r dksbZ vU; vf/kdkjh] fyf[kr esa ckV ;k eki dks tCr dj ldsxk vkSj mldk fuIkVku dj
ldsxk vkSj mldh vkxeksa dks fu;a=d }kjk ;Fkk fofufnZ"V vuqlkj forfjr dj ldsxk%
ijUrq iathd`r O;fDr }kjk fu;a=d ;k jkT; ljdkj] tSlh Hkh fLFkfr gks] dks ,sls izfrlagj.k dh
frfFk ls lkB fnu ds Hkhrj vihy dh xbZ gks vkSj ;fn bl izdkj dh xbZ vihy esa jkgr nh xbZ gS]
rks mifu;e ¼4½ ds vuqlkj dksbZ dkjZokbZ ugha dh tk,xhA
9¼1½
funsZ’k ekud& funsZ’k ekudksa dks fof/kd eki foKku ¼jk"Vªh; ekud½ fu;e] 2011 ds
v/khu ;Fkk fofgr ,sls LFkku ij] ,slh jhfr esa vkSj ,slh vfHkj{kk esa j[kk tk,xkA
¼2½
f}rh;d ekud]&
¼d½ f}rh;d ekudksa dks ,sls LFkku ij] ,slh jhfr esa rFkk ,slh vfHkj{kk esa j[kk tk,xk]
tks fu;a=d }kjk fofufnZ"V dh tk,(
¼[k½ f}rh;d ekudksa dh la[;k] fdLe ,oa fofunZs’k ,sls gksx
a s] tks fof/kd eki foKku
¼lkekU;½ fu;e] 2011 esa ;Fkk fofgr gS(a
¼x½ izR;sd f}rh;d ekud dk lR;kiu] fof/kd eki foKku ¼jk"Vªh; ekud½ fu;e]
2011 ds v/khu ;Fkk fofgr jhfr esa vkSj ,sls fu;rdkfyd varjkyksa ij fdlh
funZs’k ekud iz;ksx’kkyk esa djk;k tk,xk vkSj ;fn ,sls lR;kiu ij os vf/kfu;e
}kjk vFkok ds v/khu LFkkfir ekudksa ds vuq:Ik ik, tkrs gS] rks] ;FkkfLFkfr] mUgsa
LVkfEir fd;k tk ldsxk vFkok LkR;kiu izek.ki= tkjh fd;k tk,xkA
¼3½
dk;Zdkjh ekud]&
¼d½ dk;Zdkjh ekudksa dks fof/kd eki foKku vf/kdkjh dh vfHkj{kk esa j[kk tk,xk(
¼[k½ dk;Zdkjh ekudksa dh la[;k] fdLe ,oa fofunZs’k ,sls gksx
a s] tks fof/kd eki foKku
¼lkekU;½ fu;e] 2011 esa ;Fkk fofgr gS(a
¼x½ izR;sd dk;Zdkjh ekud dk lR;kiu] fof/kd eki foKku ¼jk"Vªh; ekud½ fu;e]
2011 ds v/khu ;Fkk fofgr jhfr esa vkSj ,sls fu;rdkfyd varjkyksa ij fdlh
funZs’k ekud iz;ksx’kkyk ;k f}rh;d ekud iz;ksx’kkyk esa djk;k tk,xk vkSj
;fn ,sls lR;kiu ij os vf/kfu;e }kjk vFkok ds v/khu LFkkfir ekudksa ds vuq:Ik
ik, tkrs gS] rks] ;FkkfLFkfr] mUgsa LVkfEir fd;k tk ldsxk vFkok LkR;kiu
izek.ki= tkjh fd;k tk,xkA
¼4½
f}rh;d ekud rqyk]&
¼d½ izR;sd ,sls LFkku ij] tgk¡ f}rh;d ekud ckV j[ks tkrs gSa] f}rh;d ekud
rqykvksa dk ,d lsV vuqjf{kr fd;k tk,xk(
¼[k½ f}rh;d ekud rqykvksa dh la[;k] fdLe ,oa fofunsZ’k ,sls gkax
s s] tks fof/kd eki
foKku ¼lkekU;½ fu;e] 2011 esa ;Fkk fofgr gS(
¼x½ izR;sd f}rh;d ekud rqyk dk lR;kiu ckjg ekl dh vof/k esa de&ls&de
,d ckj fd;k tk,xk rFkk ;fn vko’;d gks] rks mls vf/kfu;e esa fofgr lqxzkfgrk
rFkk vU; eki oSKkfud xq.kksa dh lhekvksa ds Hkhrj mls lgh djus gsrq funsZ’k
ekud iz;ksx’kkyk }kjk vFkOkk fu;a=d ;k bl fufer ml }kjk izkf/kd`r fdlh
,sls vU; vf/kdkjh }kjk O;ofLFkr dh tk,xhA
¼5½
dk;Zdkjh ekud rqyk]&
¼d½ izR;sd ,sls LFkku ij] tgk¡ dk;Zdkjh ekud ckV j[ks tkrs gSa] dk;Zdkjh ekud
rqykvksa dk ,d lsV vuqjf{kr fd;k tk,xk(

2647

funs’Z k] f}rh;d
rFkk dk;Zdkjh
ekudks@
a ekud
rqykvksa dk
vuqj{k.k A
/kkjk 24¼1½

<!-- page 6 -->

2648

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼[k½

dk;Zdkjh ekud rqykvksa dh la[;k] fdLe ,oa ,oa fofunsZ’k ,sls gksx
a s] tks fof/kd
eki foKku¼lkekU;½ fu;e] 2011 esa ;Fkk fofgr gSa(
¼x½ izR;sd dk;Zdkjh ekud rqyk dk lR;kiu ckjg ekl dh vof/k esa de&ls&de ,d
ckj fd;k tk,xk rFkk ;fn vko’;d gks] rks mls fof/kd eki foKku ¼lkekU;½
fu;e] 2011 esa fofgr lqxzkfgrk rFkk vU; eki oSKkfud xq.kksa dh lhekvksa ds Hkhrj
lgh djus gsrq funsZ’k ekud iz;ksx’kkyk }kjk vFkok fdlh ,sls LFkku ij] tgk¡
f}rh;d ekud vuqjf{kr fd, tkrs gSa] O;ofLFkr dh tk,xhA
ckV ;k eki dh 10- ,slk izR;sd ckV ;k eki] tks fdlh laO;ogkj esa vFkok laj{k.k ds fy, mi;ksx esa yk;k tkrk gS
HkkSfrd fo’ks"krk,¡] vFkok mi;ksx esa yk;k tkuk vk’kf;r gS] mldh HkkSfrd fo’ks"krk,¡] vkd`fr] lajpukRed fooj.k] lkexzh]
vkd`fr rFkk
dk;Z’khyrk] lgulhek vkSj ,sls vU; fooj.k] vf/kfu;e vFkok fof/kd eki foKku ¼lkekU;½ fu;e] 2011
lajpukRed
ds v/khu fofgr fofunsZ’kksa ds vuq:Ik gksx
a sA
fooj.kA
/kkjk 24¼1½
cqfy;u ckV]
dSjV ckV vkfn
dk mi;ksxA
/kkjk 24¼1½

ckV ;k eki dk
lR;kiu vkSj
fujh{k.kA
/kkjk 24¼1½

11- ¼1½
fof/kd eki foKku ¼lkekU;½ fu;e] 2011 esa ;Fkk fofufnZ"V cqfy;u ckVksa ls fHkUu fdlh
vU; ckV dk mi;ksx] lksu]s pkanh] IysfVue vkSj iSysfM;e bR;kfn ls cus vkHkw"k.kksa ;k vU; cgqeYq ; oLrqvksa
lfgr cqfy;u eas fdlh laO;ogkj esa ugha fd;k tk,xkA
¼2½
fof/kd eki foKku ¼lkekU;½ fu;e] 2011 esa ;Fkk fofufnZ"V dSjsV ckV ls fHkUu fdlh vU;
ckV dk mi;ksx] cgqewY; jRuksa ds fdlh Hkh laO;ogkj esa ugha fd;k tk,xkA
¼3½
izR;sd udn jlhn] chtd] fcy ;k vuqeku iphZ esa] cgqewY; jRuksa ds fdlh Hkh laO;ogkj
ds lEcU/k esa dSjVs otu dh bdkb;ksa vkSj bdkb;kas dh varjkZ"Vªh; iz.kkyh }kjk fofufnZ"V bdkb;ks]a vFkkZr
fdyksxzke] xzke ;k feyhxzke] tSlh Hkh LFkfr gks] nksuksa dk ek=k ds fy, mYys[k fd;k tk,xkA
¼4½
udn jlhn] chtd] fcy ;k vuqeku iphZ es]a cqfy;u esa izR;sd laO;ogkj ds lEcU/k es]a
rkSy midj.kksa ds mi;ksxdrkZ dks ’kq} cqfy;u otu vkSj cgqewY; /kkrq ,oa cgqewY; jRuksa ds fy,
vyx&vyx jkf’k lfgr cgqewY; /kkrqvksa tSls lksuk] pkanh] IysfVue] iSyfs M;e vkfn dh ’kq}rk dk mYys[k
^dSjVs ^ ;k ^ikVZ~l izfr gtkj^] tSlh Hkh fLFkfr gks] ds vuqlkj gksxk%
ijUrq miHkksDrkvksa ls rkSy midj.kksa ds mi;ksxdrkZ }kjk iqjkuh cgqeYw ; /kkrqvksa tSls lksuk] pkanh]
IysfVue] iSysfM;e bR;kfn ;k ,slh iqjkuh cgqeYw ; /kkrqvksa ds vkHkw"k.kksa dh [kjhn ls lEcfU/kr izR;sd
laO;ogkj esa] ,slk mi;ksxdrkZ laO;ogkj ds iwjk gksus ls iwoZ vkSj blds ckn cgqeYw ; /kkrq vkSj cgqewY;
jRuksa ds fy, i`Fkd :i ls ’kq} cqfy;u otu vkSj jkf’k lfgr ,slh iqjkuh cgqewY; /kkrqvksa ;k ,slh iqjkuh
cgqewY; /kkrqvksa ds vkHkw"k.kks]a tSlh Hkh fLFkfr gks]s dh ’kq}rk dk ^dSjVs * ;k ^ikVZ~l* ^izfr gtkj*] tSlh Hkh
fLFkfr gks] ds vuqlkj udn jlhn] fctd] fcy ;k vuqeku iphZ esa mYys[k djsxkA
¼5½
fof/kd eki foKku ¼lkekU;½ fu;e] 2011 esa ;Fkk fofufnZ"V dsoy oxZ d ;k oxZ [k ds
rqyknaM ;k mPp ;FkkFkZrk oxZ ¼oxZ&AA½ ;k fo’ks"k ;FkkFkZrk oxZ ¼oxZ&A½ dk xSj&Lopkfyr rkSy midj.k]
tks ,d feyhxzke ;k mlls de lR;kiu Ldsy varjky okys gSa] mi&fu;e ¼1½ vkSj ¼2½ esa fufnZ"V
laO;ogkj esa mi;ksx fd, tk,axsA
¼6½
fof/kd eki foKku vf/kdkjh] fu;U=d }kjk ;Fkk fofufnZ"V ,sls <ax dk mi;ksx djrs gq,
fdlh Hkh cgqewY; /kkrq] tks cqfy;u esa fdlh Hkh laO;ogkj esa csph tkrh gS] ’kq}rk dk fujh{k.k vkSj ijh{k.k
^dSjVs * ;k ^ikVZ~l izfr gtkj*] tSlh Hkh fLFkfr gks] ds vuqlkj dj ldrk gSA fujh{k.k vkSj ijh{k.k ds
iz;kstu gsrq] fof/kd eki foKku vf/kdkjh dks fu;a=d }kjk ,sls midj.k] tks vko’;d gks] dh vkiwfrZ
dh tk ldrh gSA
12- ¼1½
fdlh Hkh laO;gkj ;k laj{k.k ds fy, fdlh Hkh ckV ;k eki dk mi;ksx djus okyk izR;sd
O;fDr] LkR;kiu ds fy, ,sls ckV ;k eki dks ml frfFk dks ;k mlls igys] ftldkss lR;kiu visf{kr gS]
lR;kiu izkf/kdkjh] ftlds vf/kdkj {ks= esa bls mi;ksx esa yk;k tkrk gS] ds dk;kZy; esa ;k ,sls vU;
LFkku ij] tks lR;kiu izkf/kdkjh }kjk bl fufeRr fofufnZ"V fd;k tk,] ij izLrqr djsxk%
ijUrq ,slk fofuekZrk] ftls dsUnzh; ljdkj ;k jkT; ljdkj }kjk ljdkjh vuqeksfnr ijh{k.k dsUnz
ds :Ik esa vuqeksfnr fd;k x;k gS] mlds }kjk fufeZr ,sls ckV ;k eki ds Lo&LkR;kiu ds fy, ik=
gksxk(
ijUrq ;g vkSj fd tgka dksbZ ckV ;k eki ,sls Lo:i dk gS] ftls mldss LFkku ls gVk;k ugha tk
ldrk gS ;k gVk;k ugha tkuk pkfg,] ,sls ckV ;k eki dk mi;ksx djus okyk O;fDr] LkR;kiu izkf/kdkjh
dks ml frfFk] ftldks lR;kiu djokuk visf{kr gS] ls de ls de rhl fnu igys fjiksVZ djsxkA

<!-- page 7 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2649

¼2½
tgka dksbZ ckV ;k eki ,sls Lo:i dk gS] ftls mldss LFkku ls gVk;k ugha tk ldrk gS
;k gVk;k ugha tkuk pkfg,] lR;kiu izkf/kdkjh ,sls ckV ;k eki dks mldh vofLFkfr ds LFkku ij gh
mldk LkR;kiu djus ds fy, vko’;d dne mBk,xkA
¼3½
mi&fu;e ¼2½ esa fufnZ"V ckV ;k eki ds lR;kiu gsrq] mi;ksxdrkZ ,slh lqfo/kk,a iznku
djsxk] tks fu;a=d }kjk fofufnZ"V dh tk,aA
¼4½
lR;kiu ds fy, izLrqr izR;sd ckV ;k eki Lo;a esa iw.kZ gksxk] ftlesa eksgj Hkh ’kkfey
gSA
¼5½
izR;sd ckV ;k eki dks lkQ&lqFkjh voLFkk esa lR;kfir fd;k tk,xk vkSj ;fn vko’;d
gks] rks lR;kiu izkf/kdkjh }kjk Lokeh ;k mi;ksxdrkZ ls bl iz;kstu ds fy, vko’;d O;oLFkk djus
dh vis{kk dh tk,xhA
¼6½
dksbZ Hkh fof/kd eki foKku vf/kdkjh vius vf/kdkj {ks= ds Hkhrj fdlh Hkh iwoZ&iSd~M
oLrq] ckV ;k eki] ftldk mi;ksx fdlh Hkh laO;gkj ;k laj{k.k ds fy, fd;k tk jgk gS ;k fd;k
tkuk vk’kf;r gS ;k fd, tkus dh laHkkouk gS] dk fujh{k.k vkSj ijh{k.k djus ds fy,] ;FkklaHko
ckj&ckj] izR;sd ifjlj dk nkSjk dj ldrk gSA fof/kd eki foKku vf/kdkjh] lR;kiu ;k fujh{k.k ds
iz;kstu gsrq] ijh{k.k ckV ;k eki] ekud ckV ;k eki] dk;Zdkjh ekud ckV ;k eki] ;k fdlh vU;
Kkr ckV ;k eki dk mi;ksx dj ldrk gSA
¼7½
mi;ksxdrkZ }kjk fdlh Hkh ckV ;k eki ds lR;kiu ls igys dsUnzh; ljdkj }kjk tkjh
izfr:i dk vuqeksnu izek.ki=] lR;kiu izkf/kdkjh dks izLrqr fd;k tk,xkA ,sls ckV ;k eki dk
mi;ksxdrkZ izfr:i dk vuqeksnu ds ,sls izek.ki= dh ,d izfr vuqjf{kr j[ksxkA lR;kiu izkf/kdkjh
izfreku dk vuqeksnu esa ,sls izek.ki= dh la[;k dks vuqlwph-XXII esa ;Fkk fofgr lR;kiu izek.ki= esa
Hkh ’kkfey djsxkA
¼8½
lR;kiu ds izek.ki= dh oS/krk vkSj fdlh Hkh ckV ;k eki ds lR;kiu ds fy,
fu;rdkfyd varjky ,sls gksx
a s] tks fof/kd eki foKku ¼lkekU;½ fu;e] 2011 esa fofgr gaSA
13- ¼1½
lR;kiu izkf/kdkjh] ;fn lR;kiu ds ckn] mldk ;g lek/kku gks tkrk gS fd ,slk ckV ckV ;k eki dk
;k eki vf/kfu;e }kjk ;k mlds v/khu LFkkfir ekudksa ds vuq:Ik gS] rks og izR;sd CkkV ;k eki ij LVkEiuA
dsUnzh; ljdkj ;k jkT; ljdkj] tSlh Hkh fLFkfr gks] esa leqfpr izkf/kdkjh }kjk tkjh dh xbZ le:i /kkjk 24¼1½
fMtkbu dh eksgj yxkbZ tk,xh] tks iz’kklfud iz;kstu gsrq] lR;kiu izkf/kdkjh] ftlds }kjk LVkfEir
dh xbZ gS] }kjk vkcafVr la[;k dks bafxr djsxh%
ijUrq ;fn fdlh ckV ;k eki ds vkdkj ;k izd`fr ds dkj.k ml ij eksgj yxkuk okaNuh; ;k
O;ogk;Z ugha gS] rks lR;kiu izkf/kdkjh ,slh dk;Zokgh djsxk] tks fu;a=d }kjk lkekU; ;k fo’ks"k vkns’k
}kjk fyf[kr esa funsZ’k fn, tk,aA
¼2½
lR;kiu izkf/kdkjh] flok, mlds tc ,sls ckV ;k eki ds vkdkj ;k izd`fr ds dkj.k
,slk djuk vO;ogk;Z gks] izR;sd lR;kfir ckV ;k eki ij LVkEiu dk o"kZ vkSj ml dh frekgh fpfg~Ukr
djsxkA
O;k[;k% ,d o"kZ pkj frekfg;ksa ls feydj cusxk] ftldh izFke frekgh tuojh] Qjojh vkSj ekpZ
ds ekl dh gksxh ftls ^d* ds :Ik esa fpfg~Ukr fd;k tk,xk] f}rh; frekgh vizSy] ebZ vkSj twu ds ekl
dh gksxh ftls ^[k* ds :Ik esa fpfg~Ukr fd;k tk,xk( r`rh; frekgh tqykbZ] vxLr vkSj flRkacj ds ekl
dh gksxh] ftls *x* ds :Ik esa fpfg~Ukr fd;k tk,xk
vkSj prqFkZ frekgh vDVwcj] uoEcj vkSj fnlacj
ds ekl dh gksxh ftls ^?k* ds :Ik esa fpfg~Ukr fd;k tk,xkA
¼3½
lR;kiu vkSj LVkEiu ds iwjk gksus ij] lR;kiu izkf/kdkjh vuqlwph&XXII esa fufnZ"V iz:i
esa lR;kiu dk izek.ki= tkjh djsxk%
ijUrq tgka lR;kiu ljdkjh vuqeksfnr ijh{k.k dans z }kjk fd;k x;k gS] ogka lR;kiu fpg~u
rFkk izek.ki= ,slk gksxk] tks fof/kd eki foKku ¼ljdkjh vuqeksfnr ijh{k.k dans z½ fu;e] 2013 vkSj
jkT; ljdkj }kjk] le;&le; ij bl lEcU/k esa cUkk, x, fu;eksa esa ;Fkk fofgr gksx
a sA
¼4½
lR;kiu ij vLohd`r fd, x, fdlh Hkh CkkV ;k eki dks vko’;d ejEer ds fy,
mi;ksxdrkZ dks okil dj fn;k tk,xk vkSj ejEer ds ckn ,sls ckV ;k eki dks lR;kiu Qhl ds
Hkqxrku ij u, fljs ls lR;kiu ds fy, Lohdkj fd;k tk ldrk gSA
¼5½
tgka lR;kiu izek.ki= xqe gks tkrk gS ;k u"V gks tkrk gS ;k fod`r gks tkrk gS] rks
,sls izek.ki= dk /kkjd] lR;kiu izek.ki= dh izfrfyfi tkjh djus ds fy, lR;kiu izkf/kdkjh] ftlus
izek.ki= tkjh fd;k Fkk] dks fu;U=d }kjk ;Fkk fofufnZ"V jhfr esa] ,slh Qhl] tks ikap lkS :Ik, vFkok
lR;kiu Qhl] tks lR;kiu ds le; izHkk;Z lR;kiu Qhl ds nlos fgLls ds cjkcj gksxh] tks Hkh vf/kd
gks] ds lkFk rqjUr vkosnu djsxkA

<!-- page 8 -->

2650

lR;kiu vkSj@;k
LVkEiu ds fy,
QhlA
/kkjk 24¼1½

Qhl dk laxzg.k
vkSj [ktkus esa
tek djokukA
/kkjk 24¼1½

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼6½
mi&fu;e ¼5½ ds v/khu vkosnu izkIr gksus ij] lR;kiu izkf/kdkjh vkosnd dks MwIyhdsV
¼izfrfyfi½ lR;kiu izek.ki= tkjh djsxkA
¼7½
,slk O;fDr] ftl dks lR;kiu dk izeik.ki= tkjh fd;k x;k gS] og ml ifjlj esa fdlh
lgtn`’; LFkku ij izek.ki= iznf’kZr djsxk] ftlesa CkkV ;k eki dk mi;ksx fd;k tkrk gS%
ijUrq Hkze.k’khy foØsrk ds ekeys es]a lacaf/kr foØsrk izek.ki= vius ikl j[ksxk%
ijUrq ;g vkSj fd okgu VSad vkSj VSDlhehVj ds ekeys eas] lR;kiu izek.ki= ,sls okgu ds lkFk
j[kk tk,xkA
14- ¼1½
fof/kd eki foKku vf/kdkjh ds ekeys esa] fdlh ckV ;k eki ds LkR;kiu vkSj@;k LVkEiu
ds fy, Hkqxrku ;ksX; Qhl vuqlwph-XXIII esa ;Fkk fofufnZ"V vuqlkj gksxh vkSj ljdkjh vuqeksfnr ijh{k.k
dsUnz ds ekeys esa] fdlh ckV ;k eki ds LkR;kiu vkSj LVkEiu ds fy, Hkqxrku ;ksX; Qhl] fof/kd eki
foKku ¼ljdkjh vuqeksfnr ijh{k.k dsUnz½ fu;e] 2013 vFkok jkT; ljdkj }kjk] le; le; ij bl
fufeRr ;Fkk fofgr fu;eksa ds vuqlkj gksxhA
¼2½
mifu;e ¼1½ esa nh xbZ fdlh ckr ds gksrs gq, Hkh] ;fn mi;ksxdrkZ ds vuqjks/k ij] lR;kiu
izkf/kdkjh ds dk;kZy; ls fHkUu fdlh vU; LFkku esa ckV ;k eki dk lR;kiu fd;k tkuk visf{kr gS] rks
fof/kd eki foKku vf/kdkjh ds ekeys esa] mi;ksxdrkZ }kjk fdlh ckV ;k eki ds LkR;kiu vkSj@;k
LVkEiu ds fy, vuqlwph-XXIII esa ;Fkk fofufnZ"V Qhl ds Ms< xq.kk Qhl dk Hkqxrku fd;k tk,xk vkSj
blds lkFk&lkFk mijksDr lR;kiu vkSj@;k LVkEiu ds fy, vko’;d vU; lqfo/kk, Hkh miyC/k
djok,xkA ljdkjh vuqeksfnr ijh{k.k dsUnz ds ekeys esa] mi;ksxdrkZ }kjk fdlh ckV ;k eki ds LkR;kiu
vkSj@;k LVkEiu ds fy, Qhl] fof/kd eki foKku ¼ljdkjh vuqeksfnr ijh{k.k dsUnz½ fu;e] 2013 vFkok
jkT; ljdkj }kjk] le; le; ij bl fufeRr ;Fkk fofgr fu;eksa esa ;Fkk fofgr vuqlkj gksxh%
ijUrq ;fn mi;ksxdrkZ ckV ;k eki ds lR;kiu vkSj@;k LVkEiu ds fy, vko’;d lqfo/kk,a miyC/k
ugha djokrk gS] rks lR;kiu izkf/kdkjh mijksDr ds lEcU/k esa mi;ksxdrkZ ls vuqlwph&XXIV vkSj fof/kd
eki foKku ¼ljdkjh vuqeksfnr ijh{k.k dsUnz½ fu;e] 2013 vFkok jkT; ljdkj }kjk] le; le; ij bl
fufeRr cuk, x, fu;eksa esa ;Fkk fofgr ifjogu vkSj gSaMfyax izHkkj izHkkfjr djsxkA
ijUrq fuEufyf[kr ;Fkkor fdlh Hkh ckV ;k eki ds lR;kiu vkSj@;k LVkEiu ds fy, dksbZ
vfrfjDr Qhl izHkkfjr ugha dh tk,xh] vFkkZr~%&
¼i½
isVªksfy;e inkFkksZa rFkk vU; nzO;ksa ds fy, okgu dh Vadh] ikuh ls fHkUUk vU; nzO;ksa
ds fy, eki iz.kkyh ¼bZU/ku forjd] nzfor iSVªksfy;e xSl] nw/k forjd½] lEihfMr
izkd`frd xSl forjd] xSj&Lopkfyr rkSy ;a= tSls /keZdkaVk] IysVQkeZ e’khu] Øsu
Ldsy] Lopkfyr xzsfoesfVªd ¼HkkjkRed½ fQfyax ;a=] Lopfyr jsy /keZdkaVk] Lopkfyr
vlr~r ;ksxhdj.k rkSy ;a=] vkSj ,sls vU; ckV ;k eki] ftUgsa muds LFkku ls
gVk;k ugha tk ldrk vkSj gVk;k ugha tkuk pkfg,(
¼ii½ ,sls ckV ;k eki ds fofuekZrk ;k O;ogkjh ds ifjlj esa ckV ;k ekiA
¼3½
;fn lR;kiu vkSj@vFkok LVkEiu ds izek.ku dh lekfIr ds ckn] lR;kiu izkf/kdkjh dks
iqu% lR;kiu vkSj@vFkok LVkEiu ds fy, dksbZ CkkV ;k eki izLrqr fd;k tkrk gS] rks ,sls iqu% lR;kiu
vkSj@vFkok LVkEiu ds fy, izFke frekgh] f}rh; frekgh] r`rh; frekgh] prqFkZ frekgh ;k mlds Hkkx ds
fy, Qhl] vuqlwph&XXIII esa fofufnZ"V Qhl dk Øe’k% Ms< xq.kk] nks xq.kk] v<kbZ xq.kk vkSj rhu xq.kk
gksxh vkSj vkxs blh izdkj izHkkfjr dh tk,xhA
¼4½
;fn lR;kiu@fujh{k.k ds le; ij dksbZ ckV ;k eki xyr ik;k tkrk gS] rks ckV ;k
eki esa ik, x, nks"kksa ds ckjs esa lEcfU/kr O;fDr dks lwfpr djrs gq, mls vkB fnu dh vuf/kd vof/k
ds Hkhrj nks"kksa dks nwj djrs gq, mijksDr ckV ;k eki dks O;ofLFkr djus ds fy, okil dj fn;k tk,xkA
vko’;d O;oLFkhdj.k fd, tkus mijkUr] lgh ik, tkus ij ,sls ckV ;k eki dks vuqlwph -XXIII esa
fofufnZ"V Qhl ds Hkqxrku ij LkR;kfir vkSj@vFkok LVkfEir fd;k tk,xkA
15- ¼1½
fof/kd eki foKku vf/kdkjh }kjk LkR;kiu vkSj@vFkok LVkEiu ds fy, fdlh O;fDr ls
lax`ghr dh xbZ Qhl dks leqfpr ys[kk&’kh"kZ ds v/khu ljdkjh [ktkuk esa tek djok;k tk,xk vkSj
vuqlwph-XXV esa fufnZ"V iz:i esa lEcfU/kr O;fDr dks jlhn tkjh djsxk vkSj ,slh jlhn dh izfr] fu;U=d
dks vxszf"kr djsxkk vkSj mldh ,d izfr fjdkMZ esa Hkh j[ksxkA
¼2½
fof/kd eki foKku vf/kdkjh] vuqlwph-XXVI esa Qhl vkSj izHkkjksa ds fy, jftLVj vuqjf{kr
djsxk] ftlesa fnu&izfrfnu lax`ghr dh xbZ Qhl vkSj izHkkjksa ds fooj.k ntZ fd, tk,axsA

<!-- page 9 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2651

16- ¼1½
fdlh ckV ;k eki] ftls bu fu;eksa ds v/khu fof/kor lR;kfir vkSj@;k LVkfEir fd;k
x;k gS] dks gfj;k.kk jkT; ds Hkhrj izR;sd LFkku ij vf/kfu;e }kjk ;k blds v/khu LFkkfir ekudksa
ds vuq:Ik le>k tk,xk] tc rd fd fujh{k.k ;k tkap djus ij ;g ik;k tkrk gS fd ,slk ckV ;k
eki] vf/kfu;e }kjk ;k blds v/khu LFkkfir ekudksa ds vuq:Ik ugha jg x;k gSA
¼2½
fdlh ckV ;k eki] tks vf/kfu;e ds v/khu fof/kor lR;kfir vkSj@;k LVkfEir gS] vFkok
lR;kfir vkSj@;k LVkfEir fd;k x;k le>k x;k gS] dks dsoy bl rF; fd mldk mi;ksx ml LFkku]
ftl ij bls ewy :Ik ls lR;kfir vkSj@;k LVkfEir fd;k x;k Fkk] ls fHkUu gfj;k.kk jkT; ds Hkhrj
fdlh Hkh vU; LFkku ij fd;k tk jgk gS( ds dkj.k iqu% LkR;kfir vkSj@;k LVkfEir djokus dh
vko’;drk ugha gksxh%
ijUrq tgka ,d LFkku ij LFkkfir lR;kfir ckV ;k eki dks fo[kafMr dj fn;k tkrk gS vkSj
fdlh vU; LFkku ij iqu% LFkkfir fd;k tkrk gS] rks ,sls ckV ;k eki dks rc rd mi;ksx esa ugha yk;k
tk,xk tc rd fd mls iqu% fof/kor lR;kfir vkSj@;k LVkfEir ugha fd;k x;k gks vFkok lR;kiu
vkSj@;k LVkEiu dk izek.ki= tkjh ugha fd;k gks] tSlh Hkh fLFkfr gks] bl ckr ds gksrs gq, Hkh fd ,sls
ckV ;k eki dk fu;rdkfyd lR;kiu vkSj@;k LVkEiu visf{kr ugha gqvk gS%
ijUrq ;g vkSj fd tgka ml LFkku ls fHkUUk fdlh vU; LFkku@vofLFkfr ij fdlh ckV ;k eki
dh ejEer dh xbZ gS] tgka bls mi;ksx esa yk;k tkuk gS] ejEerdrkZ] ,sls ckV ;k eki] ftldh mlds
}kjk fof/kor ejEer dh tk,] mi;ksxdrkZ dks lkSaius ls igys] ml fof/kd eki foKku vf/kdkjh ds
le{k lR;kiu vkSj@;k LVkEiu ds fy, izLrqr djsxk] ftlds vf/kdkj {ks= esa bls mi;ksx esa yk;k
tkuk gS] bl ckr ds gksrs gq, Hkh fd ,sls ckV ;k eki dk fu;rdkfyd lR;kiu vkSj@;k LVkEiu
visf{kr ugha gqvk gSA

fof/kor lR;kfir
vkSj@;k LVkfEir
ckV ;k eki dh
oS/krkA
/kkjk 24¼1½

17- ¼1½
fof/kd eki foKku vf/kdkjh dks vius drZO;ksa dk fuoZgu djus ds fy, dk;Zdkjh ekud
ckV ;k eki@f}rh;d ekud ckV ;k eki] ijh{k.k ckV ;k eki] dk;Zdkjh ekud rqyk] f}rh;d ekud
rqyk vkSj ,sls vU; ckV ;k eki midj.kksa lfgr ,sls vU; midj.k iznku fd, tk,axs] tks le;&le;
ij fu;a=d }kjk vuqeksfnr fd, tk,aA
¼2½
izR;sd fof/kd eki foKku vf/kdkjh dks ,slh MkbZ] iap] isij lhy] fLVdj vkSj ,sls vU;
midj.k iznku fd, tk,axs] tks lR;kiu eksgj yxkus ds fy, vko’;d gks ldrs gaS] ftudk fMtkbu
vkSj la[;k fu;a=d }kjk vuqeksfnr dh tk,xhA
¼3½
izR;sd fof/kd eki foKku vf/kdkjh dks eksgjksa dks feVkus ds fy, v"Vdks.k LVkj MkbZ ds
mi;qDr vkdkj ds iap iznku fd, tk,xsA

dk;Zdkjh ekud]
f}rh;d ekud]
midj.k bR;kfn
dh vkiwfrZ djukA
/kkjk 24¼1½

18- ¼1½
vius ifjlj esa fdlh Hkh laO;ogkj esa M.Mh okyh rjktw dk mi;ksx djus okyk izR;sd
O;fDr rjktw dks LVSaM ;k gqd }kjk ,d tathj ls yVdk,xk%
ijUrq mDr mi&fu;e Hkze.k’khy foØsrk ij ykxw ugha gksxkA
¼2½
izR;sd ckV ;k eki dk mi;ksx lkQ&lqFkjh voLFkk esa vkSj mfpr izdk’k O;oLFkk esa
fd;k tk,xkA
¼3½
dksbZ Hkh ckV ;k eki] ftls ;Fkkor lR;kfir vkSj@;k LVkfEir fd;k x;k gS] dks fu;a=d
;k lacaf/kr fof/kd eki foKku vf/kdkjh dh fyf[kr vuqefr ds fcuk mls mlds LFkku ls fo[kf.Mr ;k
gVk;k ugha tk,xkA
¼4½
lHkh ?kVdks]a Hkkxks]a ckV ;k eki ds fcanq] tks /kks[kk&/kM+h okyh gsj&Qsj dh vk’kadk okys
gka]s mUgsa lR;kiu ds ckn lqjf{kr :Ik ls lhy fd;k tk,xk] tgka dgha ykxw gksA
¼5½
rkSy midj.k dh lVhdrk dh mfpr tkap lqfuf’pr djus ds fy,] mi;ksxdrkZ izR;sd
eki midj.k ds LFkku ij] midj.k dh {kerk ds nlosa fgLls ;k ,d gtkj fdyksxzke] tks Hkh de gks]
ds cjkcj fof/kor LkR;kfir vkSj@;k LVkfEir ckV j[ksxkA mi;ksxdrkZ lgh otu lqfuf’pr djus ds
fy, gj fnu bu ckVksa ds lkFk rkSy midj.k dh tkap djsxkA vuqKs; lhek ls vf/kd fdlh Hkh =qfV
ds ekeys esa] mi;ksxdrkZ ,sls rkSy midj.k dk mi;ksx djuk can dj nsxk vkSj lEcfU/kr fof/kd eki
foKku vf/kdkjh dks bls fQj ls lR;kfir vkSj@;k LVkfEir djus ds fy, lwfpr djsxkA miHkksDRkk Hkh
rkSy midj.k dh lVhdrk dh tkap dj ldrk gS%
ijUrq fu;a=d mu O;kikj ifjljksa] tgka rkSy midj.kksa dh la[;k ,d ls vf/kd gS] esa vuqjf{kr
fd, tkus okys lR;kfir vkSj@;k LVkfEir ckVksa dh dqy la[;k fufnZ"V dj ldrk gSA

CkkV ;k eki
bR;kfn dk
mi;ksxA
/kkjk 24¼1½

<!-- page 10 -->

2652

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼6½
[kqnjk O;ogkjh] isVªksy@Mhty bdkbZ ls mfpr forj.k lqfuf’pr djus ds fy, vius iai
ifjlj esa lacaf/kr fof/kd eki foKku vf/kdkjh }kjk lR;kfir ikap yhVj {kerk okyk eki j[ksxk vkSj
izR;sd isVªksy@Mhty bdkbZ dh uksty ls lgh forj.k lqfuf’pr djus ds fy, izfrfnu uksty ls
isVªksy@Mhty dh fudklh dh tkap djsxkA fdlh isVªksy@Mhty bdkbZ dh uksty ls isVªksy@Mhty ds
de forj.k ds ekeys esa] [kqnjk O;ogkjh mijksDr uksty ls isVªksy@Mhty dk forj.k djuk rqjUr can
dj nsxk vkSj ml isVªksy@Mhty bdkbZ dks fQj ls lR;kiu djus ds fy, lEcfU/kr fof/kd eki foKku
vf/kdkjh dks lwfpr djsxkA
¼7½
mi;ksxdrkZ izR;sd Lkh,uth] ,y,uth] ,yihth] gkbZMªkstu vkSj vU; xSlh; bZU/ku
fMLiSUljksa ds fy, ijh{k.k lR;kiu ;U= dk mi;ksx djsxk vkSj fof/kd eki foKku ¼lkekU;½ fu;e]
2011] fof/kd eki foKku ¼ljdkjh vuqeksfnr ijh{k.k dans z½ fu;e 2013 vkSj jkT; ljdkj }kjk] le;&le;
ij bl lEcU/k esa cUkk, x, fu;eksa esa vf/kdfFkr izfØ;k dh Hkh vuqikyuk djsxkA
¼8½
fu;a=d ;k lacaf/kr fof/kd eki foKku vf/kdkjh] ckV ;k eki ;k igys ls iSd~M dh xbZ
oLrq dh vfHkj{kk j[kus okys O;fDr ls fdlh Hkh ckV ;k eki ;k igys ls iSd~M dh xbZ oLrq ls lEcfU/kr
fdlh Hkh nLrkost ;k vU; fjdkWMZ ;k tkudkjh ds izLrqrhdj.k dh vis{kk djsxk vkSj mDr O;fDr ,slh
ekax dh vuqikyuk djsxkA
¼9½
;fn mi;ksxdrkZ vius LokfeRok/khu vkSj ml }kjk iz;qDr fdlh Hkh ckV ;k eki dks cspus
dk vk’k; j[krk gS] rks og mijksDr CkkV ;k eki dks cspus ls iwoZ fu;a=d ;k lacaf/kr fof/kd eki foKku
vf/kdkjh dh vuqefr izkIr djsxkA
¼10½ fdlh Hkh laO;ogkj esa fdlh Hkh ckV ;k eki dk mi;ksx djus okyk izR;sd O;kikjh] izR;sd
miHkksDrk dks csps x, ;k [kjhns x, eky dh ek=k vkSj eky ds fy, izHkkfjr dh xbZ jkf’k ds fooj.k
n’kkZrs gq, fcy ;k jlhn tkjh djsxkA
vijk/kksa ds
19- vf/kfu;e ;k mlds v/khu cuk, x, fu;eksa ds v/khu fd, x, vijk/kksa ds iz’keu ds fy, iz’keu
iz’keu gsrq
/kujkf’k ,slh gksxh] tks vuqlwph-XXVIII ds vuqlkj gSA iz’keu /kujkf’k leqfpr ^^ys[kk ’kh"kZ** ds v/khu
iz’keu /kujkf’kA
ljdkjh [ktkus esa tek djokbZ tk,xh%
/kkjk 48¼1½ ,oa
ijUrq fdlh ,sls O;fDr] tks vf/kfu;e ;k blds v/khu cuk, x, fu;eks]a ds micU/kksa dk mYya?ku
/kkjk 53¼2½¼Pk½
djrk gS] dks mijksDr mYya?ku ds laca/k esa vuqlwph-XXVII ds vuqlkj lq/kkj uksfVl tkjh fd;k tk,xk]
tgka Hkh ykxw gksA
vihyA
20- bl vf/kfu;e ;k bu fu;eksa ds micU/kksa ds v/khu dh xbZ fdlh dkjZokbZ ;k fd, x, fdlh
/kkjk 50
vkns'k ds fo:) vihy] vuqlwph-XXX ds vuqlkj Qhl ds lkFk vuqlwph&XXIX esa lacaf/kr vihy izkf/kdkjh
dks dh tk,xhA
’kkfLrA
21- tks dksbZ Hkh bu fu;eksa ds fdlh Hkh micU/k dk mYya?ku djrk gS] ftlds mYya?ku ds laca/k esa
/kkjk 53¼3½
'kkfLr ckjs vf/kfu;e esa dksbZ micU/k ugha fd;k x;k gS] rks og ,slh 'kkfLr] tks ,d yk[k :Ik, rd dh
gks ldsxh] ds fy, nk;h gksxkA mijksDr ds vfrfjDr iathdj.k izek.k&i= ;k lR;kiu izek.k&i=] tSlh
Hkh fLFkfr gks] dk fuaycu ;k izfrlagj.k Hkh fd;k tk,xkA
vuqlwph dk
22- jkT; ljdkj] vkns’k }kjk] bu fu;eksa ls layXu vuqlwph dks la’kksf/kr dj ldrh gSA
la’kks/kuA
fujlu vkSj
O;ko`fRrA

23-

gfj;k.kk fof/kd eki foKku ¼izorZu½ fu;e] 2011] blds }kjk] fujflr fd, tkrs gS%
ijUrq bl izdkj fujflr fu;eksa ds v/khu dh xbZ dksbZ ckr ;k dh xbZ dksbZ dkjZokbZ] bu fu;eksa
ds rRLFkkuh mica/kksa ds v/khu dh xbZ ckr ;k dh xbZ dkjZokbZ le>h tk,xhA

<!-- page 11 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2653

vuwlwph&I
[nsf[k, fu;e 3]

d

[k

Hkkx [k esa fofufnZ"V oLrqvksa ls fHkUu ¼iSd~M oLrqvksa ls fHkUu½ esa CkkV] eki vkSj la[;k dk iz;ksx
¼d½
otu] ;fn oLrq Bksl] v/kZ&Bksl] fpifpih ;k Bksl ds feJ.k rFkk nzO; ds :i esa csph tkrh gS(
¼[k½
yEckbZ] ;fn oLrq js[kh; eki }kjk csph tkrh gS(
¼x½
{ks=] ;fn oLrq {ks= eki }kjk csph tkrh gS(
¼?k½• Ekk=k] ;fn oLrq nzO; ds :i esa ;k D;qfcd eki }kjk csph tkrh gS( ;k
¼³½
la[;k] ;fn oLrq la[;k }kjk csph tkrh gSA
fuEufyf[kr oLrq,a ¼iSd~M oLrqvksa ls fHkUu½ oLrq ds fo:} n’kkZ, x, vuqlkj otu] eki ;k la[;k }kjk csph
tk,a%
Øe
oLrq
;fn ?kks"k.kk otu] eki ;k la[;k ds :i esa ;k
la[;k
muesa ls nks ;k vf/kd ds :i esa vfHkO;Dr dh
tkuh gSA
1
,jkslksy mRikn
otu
2
rjy :i esa ,flM
otu ;k ek=k
3
vkWVksxSl ¼vkWVkseksckby ds fy, rjy isVªksfy;e vk;ru
xSl½
4
laihfMr ;k rjyhd`r xSl ¼fdUrq rjyhd`r otu vkSj crk, x, rkieku vkSj ncko ij otu
isVªksfy;e xSl ugha½
;k lerqY; ek=k
5
laihfM+r izkd`frd xSl
otu
6
rjy ukbVªkstu
otu ;k ek=k
7
rjyhd`r izkd`frd xSl
otu
8
eD[ku ¼ewaxQyh dk eD[ku lfgr½] iuhj] ngh] otu
?kh
9fo|qr dscy] fctyh ds rkj] ckM+ yxkus ds rkj yEckbZ ;k otu
10
Qy vkSj lfCt;ka
la[;k ;k otu
11
HkV~Vh dk rsy
otu ;k ek=k
12
ckyksa dk rsy ¼fcuk lqxaf/kr½
otu ;k ek=k
13
Hkkjh vof’k"V bZa/ku rsy
otu
14
’kgn] ekYV vdZ] xksYMu flji Vªsdy] xqM+
otu
15
vkblØhe vkSj blh izdkj vU; tes gq, mRikn otu
16
vkS|ksfxd Mhty bZa/ku
vk;ru
17
vylh dk rsy vkSj vU; ouLifr rsy
otu ;k ek=k
18
rjy jlk;u
otu ;k ek=k
19
rjy isVªksfy;e xSl
otu
20
fdy] ydM+h ds isp
a
la[;k ;k otu
21
isVa ¼isLV isVa ;k Bksl isVa ds vykok½] rFkk okfuZ’k vk;ru
vkSj okfuZ’k LVs;j] busey
22
ßikiM+Þ
la[;k ;k otu
23
ßlekslkÞ] ßdpkSjhÞ] ßxksyxIikÞ] ßfVDdhÞ] ßMkslkÞ] la[;k
ßbMyhÞ] ßfyêhÞ
24
pk;] dkWQh] twl] is; ¼’khry is; lfgr½
vk;ru ;k la[;k ¼?kksf"kr vk;ru ds lkFk½

<!-- page 12 -->

2654

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

25
26
27
28
29
30
31
32
33
34
35
36

lykn] idh gqbZ nky@ lCth O;atu@ fcj;kuh
isLV isVa ] Bksl isVa
IykfLVd ;k fljsfed ;k /kkrq ds lkeku
feBkbZ
Ukedhu ¼elkysnkj½
ikWidkWuZ] LohV dkWuZ
jsMhesM oL=
lkWl] lHkh izdkj
LVhy vkSj yksgk
diM+k
Vk;j vkSj V~;wc
lwr

otu ;k la[;k ¼?kksf"kr otu ds lkFk½
otu
otu ;k la[;k
otu ;k la[;k
otu
otu ;k la[;k ¼?kksf"kr otu ds lkFk½
la[;k vkSj vkdkj
otu
otu ¼vk;keksa ds lkFk½
otu ;k yEckbZ
la[;k
lwr dk otu ;k yEckbZ

<!-- page 13 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&II
[nsf[k, fu;e 5¼1½]
fofuekZrk ds :i esa iathdj.k ds fy, vkosnu
lsok esa]
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------Øe
la[;k
1
2
3

4
5
6

7
8

9

oLrq dk fooj.k
vkosnd
dh
Js.kh
¼O;fDrxr@,p;w,Q@
QeZ@daiuh@lkslkbVh@foHkkx@U;kl@vU;½
vkosnd dk uke
¼,p;w,Q@ QeZ@ daiuh@ lkslkbVh@ foHkkx@ U;kl @
vU; ds ekeys esa QeZ @dEiuh vkfn dk uke Hkjs½
¼d½
izek.k lfgr vkosnd dk irk A
¼[k½
fofuekZ.k bdkbZ dk irk ¼;fn iathd`r
dk;kZy; dk irk vyx gS½
¼x½
D;k ifjlj LokfeRo esa gS@fdjk, ij fy;k
x;k gS@iês ij fy;k x;k gS ¼nLrkost
ls
fof/kor lefFkZr½A
LFkkiuk dh frfFk ¼QeZ@ daiuh@ lkslkbVh@ foHkkx@ U;kl
@ vU; ds ekeys es½a
O;fDrxr@ekfyd@Hkkxhnkj@funs’kd@lnL;¼;ks½a ] tSlk
ykxw gks] dk uke] vk/kkj la[;k vkSj irk] izek.k ds lkFk
¼d½
oSV@th,lVh dh iathdj.k la[;k
¼[k½
O;kolkf;d dj dh iathdj.k la[;k] ;fn
ykxw gks
¼x½
iSu@VSu dk fooj.k
fofuekZ.k bdkbZ esa fofuekZ.k ;k vU; xfrfof/k;ksa dh izd`fr
ftlds fy, iathdj.k fd;k tkuk gSA
fufeZr fd, tkus okys izLrkfor ckV ;k eki dh Jsf.k;ka
¼izR;sd Js.kh dk fooj.k fn;k tkuk gS½%
¼d½
lHkh izdkj ds ckV
¼[k½
{kerk eki] yEckbZ eki vkfnA
¼x½
cherjktw] dkmaVj Ldsy vkfnA
¼?k½
xSj&Lopkfyr rkSy midj.k
¼³½
Lopfyr rkSy midj.k
¼p½
vk;ru ekius ds midj.k
¼N½
vU; ¿bu fu;eksa dh vuqlwph&X vkSj
fof/kd ekiu foKku ¼lkekU;½ fu;e] 2011 esa
lyaXu vuqlwfp;ksa ds vuqlkjÀ
fu;kstr fd, x,@fu;ksftr fd, tkus ds fy, izLrkfor
O;fDr;ksa dh la[;kA
(i)
dq’ky
(ii)
dq’ky ls vU;Fkk

vkosnd }kjk Hkjk
tkuk gS

fof/kd eki foKku
vf/kdkjh dh fVIi.kh

2655

<!-- page 14 -->

2656

10

11
12
13
14

15

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼d½

,slk eksuksxzke ;k VsªMekdZ ftls fufeZr fd,
tkus okys ckV ;k eki ij vafdr fd;k
tkuk gks

¼[k½
D;k VsªMekdZ iathd`r gS ;k ugha\ ;fn gka]
rks
fooj.k nsaA
ckV ;k eki ds fuekZ.k ds fy, iz;qDr e’khujh] midj.k]
lgk;d midj.k dk fooj.kA
fctyh dusD’ku dh miyC/krkA fooj.k nsaA
D;k vkius igys bl jkT; esa ;k dgha vkSj fofuekZrk ds
vuqKfIr@iathdj.k izek.ki= ds fy, vkosnu fd;k gS\ ;fn
gka] rks fooj.k nsaA
¼d½
fufeZr fd, tkus okys izLrkfor oLrq¼vks½a ds
fy, Hkkjr ljdkj ls izkIr ekWMy vuqeksnu
izek.ki=ksa dk fooj.k
¼[k½
D;k fofufeZr dh tkus okyh izLrkfor oLrq,a
jkT; ds Hkhrj ;k jkT; ds ckgj ;k nksuksa esa
csph tk,axh\
tek fd, x, iathdj.k 'kqYd dk fooj.k ¼tSlk fd
vuqlwph&X esa fofufnZ"V gS½%
¼d½
jkf’k ¼₹½
¼[k½
thvkj,u la[;k
¼x½
lhvkbZ,u la[;k
¼?k½
fnukad
vkosnd }kjk ?kks"k.kk

;g ?kks"k.kk dh tkrh gS fd eSau@
s geus fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dks dsUnzh; vf/kfu;e 1½ gfj;k.kk
fof/kd eki foKku ¼izorZu½ fu;e] 2026 vkSj mDr vf/kfu;e ds v/khu cuk, x, lHkh vU; fu;eksa dks i<+ fy;k gSA eSa@ge
mDr vf/kfu;e vkSj blds v/khu cuk, x, lHkh fu;eksa ds mica/kksa dh ikyuk djus ds fy, lger gw¡@gSaA mijksDr ds
vfrfjDr bl laca/k esa dsUnzh; ljdkj] jkT; ljdkj vkSj fu;a=d }kjk] le;&le; ij] tkjh fd, x, lHkh vkns’kksa vkSj
funsZ’kksa dh Hkh ikyuk djus ds fy, lger gw¡@gSaA
Åij nh xbZ lHkh tkudkjh esj@
s gekjs loksZÙke Kku ds vuqlkj lR; vkSj lgh gS vkSj blesa dqN Hkh fNik;k ugha
x;k gSA ;fn mijksDr rF;@tkudkjh fdlh Hkh Lrj ij vlR; ;k xyr ikbZ tkrh gS] rks eSa@ge fof/k ds vuqlkj fdlh
Hkh dkjZokbZ dk lkeuk djus ds fy, mÙkjnk;h gqaxk@gksx
a sA
LFkku%

-------------------------

izkf/kd`r gLrk{kdrkZ dk

fnukad% -------------------------

gLrk{kj] uke vkSj inuke

<!-- page 15 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2657

vuwlwph&III
[nsf[k, fu;e 5¼1½s]

ejEerdrkZ ds iathdj.k ds fy, vkosnu
lsok esa]
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------Øe
la[;k
1
2
3

4
5
6

7

8

en dk fooj.k
vkosnd dh Js.kh ¼O;fDrxr@,p;w,Q@ QeZ@ daiuh@
lkslkbVh@ foHkkx@ U;kl@vU;½
vkosnd dk uke
¼,p;w,Q@ QeZ@ daiuh@ lkslkbVh@ foHkkx@ U;kl@ vU;
ds ekeys esa QeZ @dEiuh vkfn dk uke Hkjs½
¼d½
izek.k ds lkFk vkosnd dk irk
¼[k½
dk;Z’kkyk@ejEer bdkbZ dk irk ¼;fn iathd`r
dk;kZy; dk irk fHkUu gS½
¼x½
D;k ifjlj LokfeRo esa gS@fdjk, ij fy;k x;k
gS@iês ij fy;k x;k gS] ¼nLrkostksa }kjk fof/kor lefFkZr½
LFkkiuk dh frfFk ¼QeZ@daiuh@lkslkbVh@foHkkx @U;kl@vU;
ds ekeys es½a
O;fDrxr@ekfyd@Hkkxhnkjks@
a funs’kd¼dks½a @lnL;¼vks½a ] tSlk
ykxw gks] dk uke] vk/kkj la[;k vkSj irs ds izek.k ds lkFk
¼d½
oSV@th,lVh dh iathdj.k la[;k
¼[k½
O;kolkf;d dj dh iathdj.k la[;k] ;fn ykxw gks
¼x½
iSu@VSu dk fooj.k
ejEer ds fy, izLrkfor otu ;k eki dh Jsf.k;ka ¼izR;sd Js.kh
dk fooj.k fn;k tkuk gS½%
¼d½
lHkh izdkj ds ckV
¼[k½
{kerk eki] yEckbZ eki vkfn ¿uhps Øe la[;k
¼N½ vkSj ¼t½ esa of.kZr oLrqvksa ls fHkUuÀ
¼x½
che rjktw] dkmaVj Ldsy bR;kfnA
?k½
xSj&Lopkfyr rkSy midj.k Js.kh&I vkSj II
¿uhps Øe la[;k ¼>½ ls fHkUuÀ
¼³½
xSj&Lopkfyr rkSy midj.k Js.kh&III vkSj IV
¿uhps Øe la[;k ¼>½ ls fHkUuÀ
¼p½
Lopkfyr rkSy midj.k
¼N½
VSad yksjh
¼t½
HkaMkj.k VSad
¼>½
/keZ dkaVk
¼´½
vk;ru ekius ds midj.k
¼V½
vU; ¿bu fu;eksa dh vuqlwph&X vkSj fof/kd eki foKku
¼lkekU;½ fu;e] 2011 ls lyaXu vuqlwfp;ksa ds vuqlkjÀ
fu;ksftr fd, x,@fu;ksftr fd, tkus ds fy, izLrkfor
O;fDr;ksa dh la[;k
(i) dq’ky
(ii) dq’ky ls fHkUu

vkosnd }kjk Hkjk fof/kd eki foKku
tkuk gS
vf/kdkjh dh fVIi.kh

<!-- page 16 -->

2658

9

10
11
12
13
14
15

16

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

lapkyu dk {ks=%
¼d½ dsna z ¼fof/kd eki foKku vf/kdkjh dk {ks= ftlds
vf/kdkj {ks= esa] ejEerdrkZ dh dk;Z’kkyk fLFkr gS½
¼[k½ iwjk ftyk ¼;fn ogka fdlh ftys esa ,d ls vf/kd dsna z
gSa½
¼x½ iwjk jkT;
fu;a=d }kjk tkjh dkS’ky izek.ki= dk fooj.k
ckV ;k eki dh ejEer ds fy, iz;qDr e’khujh] midj.k] lgk;d
midj.k dk fooj.k
fctyh dusD’ku dh miyC/krk dk fooj.k
D;k vkids ikl lR;kfir ijh{k.k ckV vkSj eki bR;kfn dk i;kZIr
LVkWd gS\ fooj.k nsAa
D;k vkius igys bl jkT; esa ;k dgha vkSj ejEerdrkZ dh
vuqKfIr@iathdj.k izek.ki= ds fy, vkosnu fd;k gS\ ;fn gka]
rks fooj.k nsaA
dq’ky deZdkj dk fooj.k
Øe
dq’ky deZdkj dkS’ky
ds dkS’ky izek.ki=
dk uke vkSj {ks= dk uke dh la[;k vkSj
la[;k
firk dk uke
frfFk
tek dh xbZ iathdj.k Qhl dk fooj.k ¼tSlk fd vuqlwph&X esa
fufnZ"V gS½%
¼d½
jkf’k ¼₹½
¼[k½
thvkj,u la[;k
¼x½
lhvkbZ,u la[;k
¼?k½
fnukad
vkosnd }kjk ?kks"k.kk

;g ?kks"k.kk dh tkrh gS fd eSau@
s geus fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dks dsUnzh; vf/kfu;e 1½ gfj;k.kk
fof/kd eki foKku ¼izorZu½ fu;e] 2026 vkSj mDr vf/kfu;e ds v/khu cuk, x, lHkh vU; fu;eksa dks i<+ fy;k gSA eSa@ge
mDr vf/kfu;e vkSj blds v/khu cuk, x, lHkh fu;eksa ds mica/kks a dh ikyuk djus ds fy, lger gw¡@gSaA mijksDr ds
vfrfjDr bl laca/k esa dsUnzh; ljdkj] jkT; ljdkj vkSj fu;a=d }kjk] le;&le; ij] tkjh fd, x, lHkh vkns’kksa vkSj
funsZ’kksa dh Hkh ikyuk djus ds fy, lger gw¡@gSaA
Åij nh xbZ lHkh tkudkjh esj@
s gekjs loksZÙke Kku ds vuqlkj lR; vkSj lgh gS vkSj blesa dqN Hkh fNik;k ugha
x;k gSA ;fn mijksDr rF;@tkudkjh fdlh Hkh Lrj ij vlR; ;k xyr ikbZ tkrh gS] rks eSa@ge fof/k ds vuqlkj fdlh
Hkh dkjZokbZ dk lkeuk djus ds fy, mÙkjnk;h gqaxk@gksx
a sA
LFkku%

-------------------------

izkf/kd`r gLrk{kdrkZ dk

fnukad% -------------------------

gLrk{kj] uke vkSj inuke

<!-- page 17 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2659

vuwlwph&IV
[nsf[k, fu;e 5¼1½]

O;ogkjh ds :i esa iathdj.k ds fy, vkosnu
lsok esa]
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------Øe
la[;k

en dk fooj.k

1

vkosnd dh Js.kh ¼O;fDrxr @ ,p;w,Q@ QeZ@ daiuh@ lkslkbVh@
foHkkx@ U;kl @ vU;½
vkosnd dk uke
¼,p;w,Q@ QeZ@ daiuh@ lkslkbVh@ foHkkx@ U;kl@ vU; ds ekeys
esa QeZ @dEiuh vkfn dk uke Hkjs½
d½ izek.k ds lkFk vkosnd dk irkA
[k½ nqdku@LFkkiuk dk irk ¼;fn iathd`r dk;kZy; dk irk fHkUu gS½
x½
D;k ifjlj LokfeRo esa gS@fdjk, ij fy;k x;k gS@iês ij fy;k
x;k gS] ¼nLrkostksa }kjk fof/kor lefFkZr½A
LFkkiuk dh frfFk ¼QeZ@ daiuh@ lkslkbVh@ foHkkx@ U;kl @ vU;
ds ekeys es½a
O;fDrxr@ekfyd@Hkkxhnkjks@
a funs’kd¼dks½a @lnL;] tSlk ykxw gks] dk
uke] vk/kkj la[;k vkSj irs ds izek.k ds lkFk
¼d½
oSV@th,lVh dh iathdj.k la[;k
¼[k½
O;kolkf;d dj dh iathdj.k la[;k] ;fn ykxw gks
¼x½
iSu@VSu dk fooj.k
csps tkus ds fy, izLrkfor ckV ;k eki dh Jsf.k;ka ¼izR;sd Js.kh dk
fooj.k fn;k tkuk gS½%
¼d½
ckV
¼[k½
{kerk eki] yEckbZ eki vkfnA
¼x½
cherjktw] dkmaVj Ldsy vkfnA
¼?k½
xSj&Lopkfyr rkSy midj.k
¼³½
Lopkfyr rkSy midj.k
¼p½
vk;ru ekius ds midj.k
¼N½
vU; ¿bu fu;eksa dh vuqlwph&X vkSj fof/kd eki foKku
¼lkekU;½ fu;e] 2011 ls lyaXu vuqlwfp;ksa ds vuqlkjÀ
D;k vki jkT;@ns’k ds ckgj ds LFkkuksa ls yk,@vk;kr fd, x, ckV
;k eki vkfn dks cspuk pkgrs gSa\
;fn gka] rks vkiwfrZ ds lzksr dks bafxr djsa vkSj iznku djsa%
¼d½ fofuekZrk ds VsªMekdZ@eksuksxzke dk fooj.k vkSj iathdj.k
izek.ki= fooj.kA
¼[k½ ckV ;k eki ds vk;krd dh iathdj.k la[;k] ;fn dksbZ gksA
¼x½ dsUnzh; ljdkj }kjk ekWMy ds vuqeksnu dk fooj.k A
D;k vkius igys bl jkT; esa ;k dgha vkSj O;ogkjh dh vuqKfIr@
iathdj.k izek.ki= ds fy, vkosnu fd;k gS] \ ;fn gka] rks fooj.k nsaA

2
3

4
5
6

7

8

9

vkosnd }kjk fof/kd eki foKku
Hkjk tkuk gS vf/kdkjh dh
fVIi.kh

<!-- page 18 -->

2660

10

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

tek dh xbZ iathdj.k Qhl dk fooj.k ¼tSlk fd vuqlwph&X esa fofufnZ"V
gSa½%
¼d½
jkf’k ¼₹½
¼[k½
thvkj,u la[;k
¼x½
lhvkbZ,u la[;k
¼?k½
fnukad
vkosnd }kjk ?kks"k.kk

;g ?kks"k.kk dh tkrh gS fd eSaus@geus fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dks dsUnzh; vf/kfu;e 1½ gfj;k.kk
fof/kd eki foKku ¼izorZu½ fu;e] 2026 vkSj mDr vf/kfu;e ds v/khu cuk, x, lHkh vU; fu;eksa dks i<+ fy;k gSA eSa@ge
mDr vf/kfu;e vkSj blds v/khu cuk, x, lHkh fu;eksa ds mica/kksa dh ikyuk djus ds fy, lger gw¡@gSaA mijksDr ds
vfrfjDr bl laca/k esa dsUnzh; ljdkj] jkT; ljdkj vkSj fu;a=d }kjk] le;&le; ij] tkjh fd, x, lHkh vkns’kksa vkSj
funsZ’kksa dh Hkh ikyuk djus ds fy, lger gw¡@gSaA
Åij nh xbZ lHkh tkudkjh esj@
s gekjs loksZÙke Kku ds vuqlkj lR; vkSj lgh gS vkSj blesa dqN Hkh fNik;k ugha
x;k gSA ;fn mijksDr rF;@tkudkjh fdlh Hkh Lrj ij vlR; ;k xyr ikbZ tkrh gS] rks eSa@ge fof/k ds vuqlkj fdlh
Hkh dkjZokbZ dk lkeuk djus ds fy, mÙkjnk;h gqaxk@gksx
a sA

LFkku%

-------------------------

izkf/kd`r gLrk{kdrkZ dk

fnukad% -------------------------

gLrk{kj] uke vkSj inuke

<!-- page 19 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2661

vuqlwph&V
[nsf[k, fu;e 5¼1½ rFkk 5¼3½]

CkkV rFkk Ekki&rksy ds fofuekZrk] ejEerdrkZ o O;ogkjh ds fy, iathdj.k Qhl
Øe la[;k

iathdj.k 'kqYd

1
2

fofuekZrk ds fy,
ejEerdrkZ ds fy,

3

O;ogkjh ds fy,

jkf’k ¼₹½
50000@& ckV ;k eki dh izR;sd Js.kh@ekWMy ds fy,
(i)
20000@& ckV ;k eki dh izR;sd Js.kh@lVhdrk oxZ ds fy,] ,d
dsna z ds fy,
(ii)
50000@& ckV ;k eki dh izR;sd Js.kh@lVhdrk oxZ ds fy,] ftys
ds fy,] tgka ,d ls vf/kd dsna z gSaA
(iii)
150000@& ckV ;k eki dh izR;sd Js.kh@lVhdrk oxZ ds
fy,] jkT; ds fy,
20000@& ckV ;k eki dh lHkh Jsf.k;ksa ds fy,

<!-- page 20 -->

2662

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuwlwph&VI
[nsf[k, fu;e 5¼2½]

ckV ;k eki ds fuekZ.k ds fy, iathdj.k izek.ki=
la[;k----------------------------@o"kZ%--------------1-

blds }kjk----------------------------------- ¿iathd`r O;fDr ¼O;fDr;ksa½s dk uke vkSj irkÀ dks ckV ;k eki dh
fuEufyf[kr Jsf.k;ksa dk fuekZ.k djus ds fy, iathdj.k dk izek.ki= iznku fd;k tkrk gS%
Øe la[;k

2-

ckV ;k eki dk fooj.k

;g iathdj.k izek.k i= dsoy Åij fufnZ"V vkosnd dh----------------------------------------------------------------------- ij fLFkr mudh
fofuekZ.k bdkbZ ds fy, ekU; gS

3-

fofuekZrk uhps fn, x, fucU/kksa vkSj 'krksaZ dk ikyu djsxk mlds }kjk ,slk djus esa foQyrk dh n’kk esa ;g iathdj.k
izek.ki= jí fd, tkus ds fy, nk;h gSA

4-

fofuekZrk }kjk mi;ksx fd;k tk jgk VsªMekdZ@eksuksxzke fuEukuqlkj gS ------------------------------------------------

iathdj.k ds fucU/k ,oa 'krsa%Z
v-

iathd`r O;fDr¼;ks½a ] ftlds i{k esa ;g iathdj.k izek.ki= tkjh fd;k x;k gS%&
¼d½

vf/kfu;e vkSj blds v/khu cuk, x, fu;eksa ds lHkh lEcfU/kr micU/kksa dk le;&le; ij ;Fkk la’kksf/kr
dk vuqikyu djsxk(

¼[k½

vf/kfu;e ;k blds v/khu cuk, x, le;&le; ij ;Fkk la’kksf/kr fu;eksa ds micU/kksa dk dksbZ mYya?ku djus
dks izksRlkfgr ;k leFkZu ugha djsxk(

¼x½

bl iathdj.k izek.ki= dks blls lEcfU/kr ifjlj ds fdlh lgtn`’; fgLls esa iznf’kZr djsxk(

¼?k½

fu;a=d }kjk fn, x, fdlh Hkh lkekU; ;k fo’ks"k funsZ’kksa dk ikyu djsxk(

¼M+½

bl iathdj.k ds fuyEcu] ;fn dksbZ gks] dks vfHk’kwU; djus rd fofuekZrk ds :i esa dk;Z djuk can dj nsxk
rFkk bl izdkj O;olk; iqu% 'kq: ugha djsxk(

¼p½

O;olk; ds can gksus rFkk@vFkok iathdj.k izek.ki= ds izfrlagj.k dh n’kk esa] iathdj.k izek.ki= dk leiZ.k
djsxk(

¼N½

jkT; ds Hkhrj ;k ckgj mi;ksx ds fy,] tSlh Hkh fLFkfr gks] fufeZr ckV ;k eki dks fcØh ls igys lR;kiu
rFkk eksgj yxkus ds fy, lR;kiu izkf/kdkjh] ftlds vf/kdkj {ks= esa mldks mi;ksx esa yk;k tkuk gS] dks
izLrqr djsxk vFkok tks fu;a=d }kjk funsZf’kr fd;k tk,A

<!-- page 21 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vk-

2663

O;fDrxr lss fHkUu iathd`r O;fDr ¼O;fDr;ks½a ] ds la?kVu esa fdlh Hkh ifjorZu dh fjiksVZ iathdj.k izkf/kdkjh dks rqjar]
fdUrq rhl fnu ds vi’pkr dh tk,xhA
b-

bu fu;eksa dh dksbZ Hkh ckr iathd`r O;fDr ¼O;fDr;ks½a dks dksbZ Hkh fu/kkZ;Z vFkok gLrkarj.kh; vf/kdkj iznku
ugha djsxhA

bZ-

bl iathdj.k izek.ki= ds tkjh gksus ds ckn fofgr izR;sd 'krZ ml O;fDr ¼O;fDr;ks½a ds fy, ck/;dkjh gksxh]
ftUgsa ;g iathdj.k izek.ki= iznku fd;k x;k gSA

fVIi.k% fdlh O;fDr ls fHkUu iathd`r O;fDr ¼O;fDr;ks½a dh n’kk es]a ,sls iathd`r O;fDr ¼O;fDr;ks½a ds O;olk; esa dksbZ Hkh
fgr j[kus okys lHkh O;fDr;ksa ij Åij of.kZr fucU/ku rFkk 'krsZa ck/;dkjh gksx
a hA

LFkku%

------------------------------

fnukad% ------------------------------

¼gLrk{kj½
iathdj.k izkf/kdkjh dk uke ,oa inuke
¼eksgj ds lkFk½

<!-- page 22 -->

2664

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuwlwph&VII
[nsf[k, fu;e 5¼2½]

ckV ;k eki dh ejEer ds fy, iathdj.k izek.ki=
la[;k----------------------------@o"kZ%--------------1-

blds }kjk----------------------------------- ¿iathd`r O;fDr ¼O;fDr;ks½a dk uke vkSj irkÀ dks ckV ;k eki dh
fuEufyf[kr Jsf.k;ksa dh ejEer djus ds fy, iathdj.k dk izek.ki= iznku fd;k tkrk gS%
Øe la[;k

2-

ckV ;k eki dk o.kZu

;g iathdj.k izek.ki= dsoy Åij mfYyf[kr vkosnd ds fy, -------------------------¼ij½ fLFkr mudh
dk;Z’kkyk@ejEer djus ds lEcU/k esa oS/k gSA

3ejEerdrkZ uhps fn, x, fucU/kuksa vkSj 'krksZa dk ikyu djsxkA mlds }kjk ,slk djus esa foQyrk dh n’kk esa ;g
iathdj.k izek.ki= jí fd, tkus ds fy, nk;h gSA
4iathd`r O;fDr dks mijksDr Øe la[;k 1 esa of.kZr o.kZu ds ckV ;k eki dh fuEu of.kZr {ks= ¼{ks=ks½a esa ejEer
djus ds fy, izkf/kd`r fd;k tkrk gS -----------------------------------------------------------------------------5-

dq’ky deZdkjksa vkSj dkS’ky izek.ki= dk fooj.k%&
Øe la[;k

dq’ky deZdkjkas dk uke vkSj firk
dk uke

dkS’ky ds {ks= dk uke

dkS’ky izek.ki= dh la[;k
vkSj frfFk

iathdj.k ds fucU/k rFkk 'krsZa%
v-

vk-

iathd`r O;fDr ¼;ks½a ] ftlds i{k esa ;g iathdj.k izek.k i= tkjh fd;k x;k gS%&
¼d½

vf/kfu;e vkSj blds v/khu cuk, x, le;&le; ij ;Fkk la’kksf/kr fu;eksa ds lEcfU/kr lHkh micU/kksa dk
vuqikyu djsxk(

¼[k½

vf/kfu;e ;k blds v/khu cuk, x, le;&le; ij ;Fkk la’kksf/kr fu;eksa ds micU/kksa dk mYya?ku djus dks
izksRlkfgr ugha djsxk ;k leFkZu ugha djsxk(

¼x½

bl iathdj.k izek.ki= dks blls lEcfU/kr ifjlj ds fdlh lgtn`’; fgLls esa iznf’kZr djsxk(

¼?k½

fu;a=d }kjk fn, x, fdlh Hkh lkekU; ;k fo’ks"k funsZ’kksa dk ikyu djsxk(

¼M+½

bl iathdj.k ds fuyEcu] ;fn dksbZ gks] dks vfHk’kwU; djus rd ejEerdrkZ ds :i esa dk;Z djuk can dj
nsxk rFkk bl izdkj O;olk; iqu% 'kq: ugha djsxk(

¼p½

O;olk; ds can gksus rFkk@vFkok iathdj.k izek.ki= ds izfrlagj.k dh n’kk esa] iathdj.k izek.ki= dk leiZ.k
djsxk(

¼N½

fof/kor~ lfoZl@ ejEer fd, x, ckV ;k eki] tSlh Hkh fLFkfr gks] dks miHkksDrk dks lqiqnZxh ls igys lR;kiu
,oa eksgj yxkus ds fy, lR;kiu izkf/kdkjh] ftlds vf/kdkj {ks= esa mldks mi;ksx esa yk;k tkuk gS] vFkok
tSlk fu;a=d }kjk funsZf’kr fd;k tk,] dks izLrqr djsxk A

ejEer dk dk;Z fu;eksa }kjk ;Fkk fu/kkZfjr dq’ky deZdkjksa }kjk fd;k tk,xkA
b-

dq’ky deZdkjksa esa fdlh Hkh ifjorZu dh fjiksVZ iathdj.k izkf/kdkjh dks rqjar] fdUrq rhl fnu ds vi’pkr
vo’; dh tk,xhA

bZ-

O;fDrxr lss fHkUu iathd`r O;fDr ¼O;fDr;ks½a ] ds la?kVu esa fdlh Hkh ifjorZ u dh fjiksVZ iathdj.k izkf/kdkjh
dks rqjra ] fdUrq rhl fnu ds vi’pkr vo’; dh tk,xhA

m-

bu fu;eksa dh dksbZ Hkh ckr iathd`r O;fDr ¼O;fDr;ks½a dks dksbZ Hkh fu/kkZ;Z vFkok gLrkarj.kh; vf/kdkj iznku
ugha djsxhA

<!-- page 23 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2665

Å-

bl iathdj.k izek.ki= ds tkjh gksus ds ckn fofgr izR;sd 'krZ ml O;fDr ¼O;fDr;ks½a ds fy, ck/;dkjh gksxh]
ftUgsa ;g iathdj.k izek.ki= iznku fd;k x;k gSA

_-

ckV ;k eki ds fy, vf/kdre ejEer izHkkjksa dh LFkkiuk ds fy, fu;a=d lefUor dk;ZØe dks ,sls LFkku
ij vkSj ,slh jhfr esa dj ldrk gS] tSlk og mfpr le>sA ejEerdrkZ vf/kdre ejEer izHkkjksa dh ,slh lhek
dk ikyu djsxkA

fVIi.k% fdlh O;fDrxr lss fHkUu iathd`r O;fDr ¼O;fDr;ks½a dh n’kk esa] ,sls iathd`r O;fDr ¼O;fDr;ks½a ds O;olk; esa dksbZ
Hkh fgr j[kus okys lHkh O;fDr;ksa ds fy, Hkh Åij mfYyf[kr fucU/ku ,oa 'krsZa ck/;dkjh gksaxhA
LFkku%

------------------------------

fnukad% ------------------------------

¼gLrk{kj½
iathdj.k izkf/kdkjh dk uke rFkk inuke
¼eksgj ds lkFk½

<!-- page 24 -->

2666

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuwlwph&VIII
[nsf[k, fu;e 5¼2½]

ckV ;k eki ds O;ogkjh ds fy, iathdj.k izek.ki=
la[;k----------------------------@o"kZ%--------------1-

blds }kjk] ----------------------------------- ¿iathd`r O;fDr ¼O;fDr;ks½a dk uke vkSj irkÀ dks ckV ;k eki dh fuEufyf[kr Jsf.k;ksa
dk ysu nsu djus ds fy, iathdj.k dk izek.ki= iznku fd;k tkrk gS%
Øe la[;k

ckV ;k eki dk o.kZu

2-

;g iathdj.k izek.ki= dsoy Åij mfYyf[kr vkosnd ds fy,-------------------------ij fLFkr muds dkjckj ifjljksa ds lEcU/k
esa ekU; gSA
3O;ogkjh uhps fn, x, fucU/kuksa vkSj 'krksZa dk ikyu djsxkA mlds }kjk ,sl k djus esa foQyrk dh n’kk esa ;g
iathdj.k izek.k i= jí fd, tkus ds fy, nk;h gSA
iathdj.k ds fucU/ku rFkk 'krsZa%
viathd`r O;fDr ¼O;fDr;ks½a ] ftlds i{k esa ;g iathdj.k izek.k i= tkjh fd;k x;k gS%&
¼d½ vf/kfu;e vkSj blds v/khu cuk, x, le;&le; ij ;Fkk la’kksf/kr fu;eksa lss lEcfU/kr lHkh micU/kksa dk
vuqikyu djsxk(
¼[k½ vf/kfu;e ;k blds v/khu cuk, x, le;&le; ij ;Fkk la’kksf/kr fu;eksa ds micU/kksa dk mYya?ku djus dks
izksRlkfgr ugha djsxk ;k leFkZu ugha djsxk(
¼x½ bl iathdj.k izek.ki= dks blls lEcfU/kr ifjlj ds fdlh lgtn`’; fgLls esa iznf’kZr djsxk(
¼?k½ fu;a=d }kjk fn, tkus okys fdlh Hkh lkekU; ;k fo’ks"k funsZ’kksa dk ikyu djsxk(
¼M+½ bl iathdj.k izek.ki= ds fuyEcu] ;fn dksbZ gks] dks vfHk’kwU; djus rd O;ogkjh ds :i esa dk;Z djuk can
dj nsxk rFkk bl izdkj O;olk; iqu% 'kq: ugha djsxk(
¼p½ O;olk; ds can gksus dh n’kk esa rFkk@vFkok iathdj.k izek.ki= ds izfrlagj.k djus dh n’kk esa] iathdj.k
izek.k i= dk leiZ.k djsxk(
¼N½ ckV ;k eki dks cspus ls igys lR;kiu izkf/kdkjh] ftlds vf/kdkj {ks= esa mldks mi;ksx esa yk;k tkuk gS]
vFkok tSls fu;a=d }kjk funsZf’kr fd;k tk,] dks izLrqr djsxkA
¼t½ fdlh Hkh xSj&ekud ckV ;k eki dh fcØh] izLrkfor] vuko`Ùk ugha djsxk ;k vius dCts esa ugha j[ksxkA
vk- O;fDrxr lss fHkUu iathd`r O;fDr ¼O;fDr;ks½a ] ds la?kVu esa fdlh Hkh ifjorZu dh fjiksVZ iathdj.k izkf/kdkjh dks rqjar]
fdUrq rhl fnu ds vi’pkr dh tk,xhA
bbu fu;eksa dh dksbZ Hkh ckr iathd`r O;fDr ¼O;fDr;ks½a dks dksbZ Hkh fu/kkZ;Z vFkok gLrkarj.kh; vf/kdkj iznku
ugha djsxhA
bZbl iathdj.k izek.ki= ds tkjh gksus ds ckn fofgr izR;sd 'krZ ml O;fDr ¼O;fDr;ks½a ij ck/;dkjh gksxh]
ftUgsa ;g iathdj.k izek.ki= iznku fd;k x;k gSA
fVIi.k% fdlh O;fDrxr lss fHkUu iathd`r O;fDr ¼O;fDr;ks½a dh n’kk esa] Åij of.kZr fucU/ku rFkk 'krsZa ,sls iathd`r O;fDr
¼O;fDr;ks½a ds O;olk; esa dksbZ Hkh fgr j[kus okys lHkh O;fDr;ksa ij ck/;dkjh gksxhA

LFkku%

------------------------------

fnukad% ------------------------------

¼gLrk{kj½
iathdj.k izkf/kdkjh dk uke ,oa inuke
¼eksgj ds lkFk½

<!-- page 25 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2667

vuqlwph&IX
[nsf[k, fu;e 5¼4½]

iathd`r ejEerdrkZ }kjk tek djokbZ tkus okyh izfrHkwfr
o.kZu
ejEerdrkZ ds fy, tek izfrHkwfr

jkf’k ¼₹½
100000@& ckV ;k eki dh izR;sd Js.kh@lVhdrk oxZ ds fy,] ,d dsna z ds fy,

<!-- page 26 -->

2668

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&X
[nsf[k, fu;e 5¼5½]

ckV ;k eki ds iathd`r fofuekZrkvks]a ejEerdrkZvksa vkSj O;ogkfj;ksa dk jftLVj
iathdj.k
izek.k
i= dh
la[;k
vkSj
frfFk

fofuekZrk@
ejEerdrkZ@
O;ogkjh dk
uke vkSj irk

fofuekZrk
ds
dkj[kkus
@fofuekZ.k
bZdkbZ dk
LFkku

ejEerdrkZ
dh
dk;Z’kkyk
@ejEer
bZdkbZ dk
LFkku

fofufeZr@
ejEer dh
xbZ@csph
tkus okyh
oLrq,a

mi;ksx
fd, tkus
okys
VsªMekdZ@
eksuksxzke

1

2

3

4

5

6

iathdj.k (i) vihy
izek.k i= nk;j
ds
djus dh
fuyacu@ frfFk]
izfrlagj.k ;fn dksbZ
djus ds gksA
laca/k esa (ii) vihy
vkns’kksa
esa fu.kZ;
dh la[;k dh frfFk
vkSj frfFk (iii) vihy
Lohd`r
;k
vLohd`rA
7
8

iat
a hdj.k fVIi.kh]
izkf/kdkjh ;fn
ds
dksbZ gks
gLrk{kj

9

10

fVIi.k% [kkuk la[;k 3 vkSj 4 O;ogkfj;ksa ls lEcfU/kr ugha gSa] [kkuk la[;k 6 ejEerdrkZvksa vkSj O;ogkfj;ksa ls lEcfU/kr
ugha gSaA

<!-- page 27 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2669

vuqlwph&XI
[nsf[k, fu;e 5¼9½]

mÙkjkfèkdkj@gLrkarj.k ij iathdj.k çek.ki= nsus ls budkj djus dh lwpuk
Øekad@vkj-,- ¼fof/kd eki½---------------------

fnukad-------------------

lsok esa]
vkosnd dk uke ----------------------------------------------------------------------------------------------------------------------------------irk

------------------------------------------------------------------------------------------------------------------------------------------------------

fo"k;%
lanHkZ%

iathdj.k izek.ki= ds gLrkarj.k ds fy, vuqjks/kA
----------------------- ds i{k essa tkjh fd, x, iathdj.k izek.k i= la[;k---------------- fnukad--------------------ds gLrkarj.k ds fy,

vkidk vkosnuA
vkidks] blds }kjk] lwfpr fd;k tkrk gS fd iathdj.k dks vkids uke ij ;k ml O;fDr] ftlds i{k esa iwoksZDr
vuqjks/k fd;k x;k gS] ds uke ij gLrkarj.k ds fy, mijksDr of.kZr vuqjks/k ds fy, vkids vkosnu dks vf/kfu;e@fu;eksa
dh ykxw /kkjkvks@
a fu;eksa dks /;ku esa j[krs gq, tkapk x;k gS vkSj bls fuEufyf[kr vk/kkjksa ij vLohd`r dj fn;k x;k gS%
Øe la[;k
¼1½

vuqjks/k dks bUkdkj@ vLohd`r djus ds
dkj.k
¼2½

vf/kfu;e@fu;eksa dh lEcfU/kr /kkjk ¼/kkjk,a½@ fu;e
¼fu;eksa½@iathdj.k izek.k i= dh 'krsZa
¼3½

blfy,] vkidks mi;qZDr iathdj.k izek.ki= ds v/khu vuqKs; O;olk; dks rqjar jksdus dk funsZ’k fn;k tkrk gS]
,slk u djus ij vkids fo:) fof/k ds vuqlkj mfpr dkjZokbZ 'kq: dh tk,xhA

iathdj.k izkf/kdkjh ds gLrk{kj]
uke rFkk inuke eksgj ds lkFk

<!-- page 28 -->

2670

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XII
[nsf[k, fu;e 6¼1½]

dkS’ky izek.ki= ds fy, vkosnu Qhl
fooj.k

jkf’k (₹)

dkS’ky izek.ki= ds fy, vkosnu Qhl

izR;sd vkosnu ds fy, 1000/-

<!-- page 29 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2671

vuwlwph&XIII
[nsf[k, fu;e 6¼1½s]

dkS’ky izek.ki= tkjh djus ds fy, vkosnu
lsok esa]
fu;a=d] fof/kd eki foKku] gfj;k.kk
Øe
la[;k

oLrq dk fooj.k

1
2

vkosnd dk uke vkSj irk
¼d½
vk/kkj la[;k
¼[k½
iSu
'kS{kf.kd ;ksX;rk
rduhdh ;ksX;rk] ;fn dksbZ gks
ml {ks= esa vuqHko ftlds fy, dkS’ky izek.k i= dk vkosnu fd;k x;k
gS ¼izek.k lyaXu fd;k tkuk gS½A
ckV ;k eki dh Jsf.k;ka] ftuds fy, dkS’ky izek.ki= dk vkosnu fd;k
x;k gSA ¼izR;sd Js.kh dk fooj.k fn;k tkuk gS½%
¼d½ lHkh izdkj ds ckV
¼[k½ {kerk eki] yEckbZ eki bR;kfn ¿uhps Øe la[;k ¼N½ vkSj ¼t½
esa of.kZr oLrqvksa ls fHkUuÀ
¼x½ che rjktw] dkmaVj Ldsy bR;kfnA
¼?k½ xSj&Lopkfyr rkSy midj.k Js.kh&I vkSj II ¿uhps Øe la[;k ¼>½
esa of.kZr oLrq,a ls fHkUuÀ
¼³½ xSj&Lopkfyr rkSy midj.k Js.kh&III vkSj IV ¿uhps Øe la[;k
¼>½ esa of.kZr oLrqvksa ls fHkUuÀ
¼p½ Lopkfyr rkSy midj.k
¼N½ VSad ykjh
¼t½ HkaMkj.k VSad
¼>½ /keZ dkaVk
¼´½ vk;ru ekius ds midj.k
¼V½ vU; ¿bu fu;eksa dh vuqlwph&X vkSj fof/kd eki foKku ¼lkekU;½
fu;e] 2011 ls lyaXu vuqlwfp;ksa ds vuqlkjÀ
D;k vkius igys bl jkT; esa dgha vkSj dkS’ky izek.k i= ds fy, vkosnu
fd;k gS@iznku fd;k x;k gS\ ;fn gka] rks fooj.k nsaA

3
4
5
6

7
8

tek dh xbZ iathdj.k Qhl dk fooj.k ¼tSlk vuqlwph&X esa fofufnZ"V
gS½%
¼d½
jkf’k ¼₹½
¼[k½
thvkj,u la[;k
¼x½
lhvkbZ,u la[;k
¼?k½
fnukad

vkosnd }kjk fof/kd eki foKku
Hkjk tkuk gS vf/kdkjh
dh
fVIi.kh

<!-- page 30 -->

2672

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

?kks"k.kk
;g ?kks"k.kk dh tkrh gS fd eSaus@geus fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dks dsUnzh; vf/kfu;e 1½ gfj;k.kk
fof/kd eki foKku ¼izorZu½ fu;e] 2026 vkSj mDr vf/kfu;e ds v/khu cuk, x, lHkh vU; fu;eksa dks i<+ fy;k gSA eSa@ge
mDr vf/kfu;e vkSj blds v/khu cuk, x, lHkh fu;eksa ds mica/kksa dh ikyuk djus ds fy, lger gw¡@gSaA mijksDr ds
vfrfjDr bl laca/k esa dsUnzh; ljdkj] jkT; ljdkj vkSj fu;a=d }kjk] le;&le; ij] tkjh fd, x, lHkh vkns’kksa vkSj
funsZ’kksa dh Hkh ikyuk djus ds fy, lger gw¡@gSaA
Åij nh xbZ lHkh tkudkjh esj@
s gekjs loksZÙke Kku ds vuqlkj lR; vkSj lgh gS vkSj blesa dqN Hkh fNik;k ugha
x;k gSA ;fn mijksDr rF;@tkudkjh fdlh Hkh Lrj ij vlR; ;k xyr ikbZ tkrh gS] rks eSa@ge fof/k ds vuqlkj fdlh
Hkh dkjZokbZ dk lkeuk djus ds fy, mÙkjnk;h gqaxk@gksx
a sA

LFkku%

--------------------------

fnukad% -------------------------

gLrk{kj vkSj uke

<!-- page 31 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2673

vuwlwph&XIV
[nsf[k,fu;e 6¼2½a]

dkS’ky izek.ki=
izek.ki= la[;k--------------------------------------------------tkjh djus dh frfFk-----------@-----------@---------;g izekf.kr fd;k tkrk gS fd Jh@Jherh@lqJh -----------------------------------------------------------------------------------------iq=@iq=h@
ifr@iRuh---------------------------------------------------------------------------------------------- fuoklh-----------------------------------------------fof/kd eki foKku vf/kfu;e]
2009 vkSj mlds v/khu cuk, x, fu;eksa ds micU/kksa ds v/khu ckV ;k eki dh ejEer djus esa rduhdh :i ls l{ke vkSj
visf{kr dkS’ky j[kus okyk ik;k x;k gSA
bl izek.ki= ds /kkjd dks fuEufyf[kr ckV ;k eki dh fdLe@Jsf.k;ksa dh ejEer ds mís’; ls] fof/kd eki foKku vf/kfu;e]
2009 rFkk blds v/khu cuk, x, fu;eksa vkSj le;&le; ij tkjh fd, x, funsZ’kks]a tSlh Hkh fLFkfr gks] ds micU/kksa ds
vuqikyu ds v/;/khu dq’ky deZdkj ds :i esa ekU;rk nh tkrh gSA
;ksX;rk dk fooj.k %
C;ksjs
uhps
,slh fdLe@Jsf.k;ka ftuds fy, izek.k i= tkjh fd;k tk uhps of.kZr lEcfU/kr Jsf.k;ksa dk p;u djsa%
jgk gSA
¼d½ lHkh izdkj ds ckV
¼[k½ {kerk eki] yEckbZ eki vkfn ¿uhps Øe
la[;k ¼N½ vkSj ¼t½ esa of.kZr oLrqvksa lss
fHkUuÀ
¼x½ che rjktw] dkmaVj Ldsy vkfnA
¼?k½ xSj&Lopkfyr rkSy midj.k Js.kh&I vkSj II ¿uhps
Øe la[;k ¼>½ of.kZr oLrq lss
fHkUuÀ
¼³½ xSj&Lopkfyr rkSy midj.k Js.kh&III vkSj IIII
¿uhps Øe la[;k ¼>½ of.kZr oLrq
lss fHkUuÀ
¼p½ Lopkfyr rkSy midj.k
¼N½ VSad yksjh
t½ HkaMkj.k VSad
¼>½ /keZ dkaVk
¼´½ vk;ru ekius ds midj.k
¼V½ vU; ¿bu fu;eksa dh vuqlwph&X vkSj fof/kd eki
foKku ¼lkekU;½ fu;e] 2011 ls lyaXu vuqlwfp;ksa
ds vuqlkjÀ
izek.ki= dh oS/krk
fVIi.k% ;g izek.k i= dsoy fof/kd eki foKku vf/kfu;e] 2009 vkSj blds v/khu cuk, x, fu;eksa ds v/khu ejEer drkZ
ds :i esa O;olk; djus ds mís’; ls ekU; gksxkA
;g izek.ki= vf/kfu;e vkSj blds rgr cuk, x, fu;eksa ds fdlh micU/k] le;&le; ij ;Fkk la’kksf/kr ;k
fu;a=d }kjk fdlh lkekU; ;k fo’ks"k funsZ’k tkjh fd, tk,aA

LFkku%

---------------------------

fnukad% ---------------------------

fu;a=d ds gLrk{kj vkSj eksgj

<!-- page 32 -->

2674

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XV
[nsf[k, fu;e 7]

ckV ;k eki ds fofuekZrkvksa }kjk cuk, j[ks tkus okyk jftLVj
1-

fofuekZrk dk uke vkSj irk

---------------------------------------------------------------------------

2-

laidZ la[;k vkSj bZey
s vkbZMh

---------------------------------------------------------------------------

3-

(i)

iathdj.k izek.k i= la[;k

---------------------------------------------------------------------------

(ii)

iathdj.k izek.k&i= tkjh djus dh frfFk

---------------------------------------------------------------------------

(iii)

fufeZr fd, tk jgs ckV ;k eki dk fooj.k%

---------------------------------------------------------------------------

Øe la[;k
4-

ckV ;k eki dk fooj.k

ckV ;k eki ds fofuekZ.k vkSj laO;ogkj dk ¼ekl&okj½ ,oa ¼Js.kh&okj½ fooj.k%&

Øe
la[;k

ekl vkSj o"kZ ckV ;k eki fiNys ekl ds
dk uke
dk o.kZu
[kkuk la[;k 13
ls ykbZ xbZ fcuk
fcØh oLrqvksa dh
ek=k ¼la[;k esa½

1

2

3

4

ekl
ds dqy LVkWd
nkSjku
¼4$5½
fofufeZr
oLrqvksa dh
ek=k ¼la[;k
esa½
5
6

jkT;@ns’k ds ckgj csph xbZ oLrqvksa dh ek=k ¼la[;k esa½
csph xbZ dqy
oLrq,a ¼7$10½
jkT;@ns’k dk csph xbZ oLrqvksa pkyku la- vkSj
uke
dh la[;k
fnukad
9
10
11
12

jkT; ds Hkhrj csph xbZ
oLrqvksa dh ek=k ¼la[;k esa½
csph
xbZ pkyku laoLrqvksa dh vkSj fnukad
la[;k
7

8

Ckdk;k LVkWd
¼6&12½
13

fVIi.kh] ;fn dksbZ
gks
14

*fVIi.k% fofuekZrk dks ckV ;k eki dh izR;sd Js.kh ds fy, vyx ls mijksDr izk:i esa fooj.k cuk, j[kuk gSA
5-

iathdj.k izek.ki= ds fuyacu@izfrlagj.k djus ds vkns’kks]a ;fn dksbZ gks] dk fooj.k ---------------------------

6-

iathdj.k izek.ki= ds izfrlagj.k vkns’kks]a ;fn dksbZ gks] dk fooj.k

--------------------------

fofuekZrk ds gLrk{kj vkSj eksgj

<!-- page 33 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2675

vuqlwph&XVI
[nsf[k, fu;e 7]

ckV ;k eki ds ejEerdrkZvksa }kjk cuk, j[ks tkus okyk jftLVj
1-

ejEerdrkZ dk uke vkSj irk

---------------------------------------------------------------------------

2-

laidZ la[;k vkSj bZey
s vkbZMh

---------------------------------------------------------------------------

3-

(i)

iathdj.k izek.ki= la[;k

---------------------------------------------------------------------------

(ii)

iathdj.k izek.k&i= tkjh djus dh frfFk

---------------------------------------------------------------------------

(iii)

ejEer ds fy, izkf/kd`r ckV ;k eki dh Jsf.k;ka%

---------------------------------------------------------------------------

Øe la[;k
4-

ckV ;k eki dk o.kZu

dq’ky deZdkj dk fooj.k%

Øe la[;k

5-

dq’ky deZdkj dk uke vkSj dkS’ky ds {ks= dk uke
firk dk uke

dkS’ky izek.k i= dh la[;k vkSj frfFk

ejEer fd, x, ckV ;k eki dk fooj.k%

Øe
la[;k

frfFk

1

2

mi;ksxdrkZ dk uke ftlls ejEer ds fy, izkIr ckV izkIr ek=k mi;ksxdrkZ dks tkjh
ejEer ds fy, ckV ;k eki ;k eki dk o.kZu
¼la[;k esa½
dh xbZ jlhn dh la[;k
izkIr gqvk
rFkk frfFk
3
4
5
6

ejEer izHkkj dh lR;kiu 'kqYd dh Lkjdkj ds ikl mi;ksxdrkZ dks ykSVkus ds fy, fVIi.kh] ;fn dksbZ
tek djkbZ jkf’k ykSVkbZ xbZ ek=k yafcr
ek=k gks
jkf’k ¼₹½
jkf’k ¼₹½
¼la[;k esa½
¼la[;k esa½
¼₹½
7
8
9
10
11
12
6- iathdj.k izek.ki= ds fuyacu@izfrlagj.k djus ds vkns’kks]a ;fn dksbZ gks] dk fooj.k

---------------------------

7- iathdj.k izek.ki= ds izfrlagj.k vkns’kks]a ;fn dksbZ gks] dk fooj.k

---------------------------

ejEerdrkZ ds gLrk{kj vkSj eksgj

<!-- page 34 -->

2676

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XVII
[nsf[k, fu;e 7]

ckV ;k eki ds O;ogkfj;ksa }kjk cuk, j[ks tkus okyk jftLVj
1-

O;ogkjh dk uke vkSj irk

---------------------------------------------------------------------------

2-

laidZ la[;k vkSj bZey
s vkbZMh

---------------------------------------------------------------------------

3-

(i)

iathdj.k izek.k i= la[;k

---------------------------------------------------------------------------

(ii)

iathdj.k izek.k&i= tkjh djus dh frfFk%

---------------------------------------------------------------------------

(iii)

csps tk jgs ckV ;k eki dh fooj.k%

Øe la[;k

ckV ;k eki dk o.kZu

4- ckV ;k eki ds fcØh vkSj laO;ogkj dk ¼ekl&okj½ ,oa ¼Js.kh&okj½ fooj.k%
Øe
la[;k

ekl
ckV ;k fiNys ekl
vkSj o"kZ eki dk ds [kkuk
dk uke o.kZu
la[;k 14
ls yk;k
x;k
vueksYM
LVkWd

1

2

3

4

ekl ds nkSjku
jkT; ds Hkhrj
[kjhnh
xbZ
oLrqvksa
dh
ek=k ¼la[;k esa½
ds lkFk&lkFk
vkiwfrZdrkZvksa
dk fooj.k
5

ekl ds nkSjku dqy LVkWd
jkT; ds ckgj ¼4$5$6½
ls [kjhnh xbZ
oLrqvksa
dh
ek=k ¼la[;k esa½
ds lkFk&lkFk
vkiwfrZdrkvksa
dk fooj.k
6
7

jkT; ds Hkhrj csph
xbZ ek=k
csph xbZ chtd
oLrqvksa
la[;k
dh la[;k vkSj
fnukad
8

9

jkT;@ns’k ds ckgj csph xbZ oLrqvksa dh ek=k
csph xbZ dqy
Ckdk;k LVkWd
oLrq
,
a
¼8$11½
¼7&13½
jkT;@ns’k dk
csph xbZ oLrqvksa dh pkyku la- vkSj
uke
la[;k
fnukad
10
11
12
13
14

fVIi.kh] ;fn
dksbZ gks
15

*fVIi.k% O;ogkjh dks ckV ;k eki dh izR;sd Js.kh ds fy, vyx ls mijksDr iz:i esa fooj.k cuk,

j[kuk gSA

5-

iathdj.k izek.ki= ds fuyacu@izfrlagj.k djus ds vkns’kks]a ;fn dksbZ gks] dk fooj.k ---------------------------

6-

iathdj.k izek.ki= ds izfrlagj.k vkns’kks]a ;fn dksbZ gks] dk fooj.k

---------------------------

foØsrk ds gLrk{kj vkSj eksgj

<!-- page 35 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2677

vuqlwph&XVIII
[nsf[k, fu;e 7]

fofuekZrk }kjk ,slh frekgh ds r`rh; ekl dh vafre frfFk ls nl fnu ds Hkhrj izR;sd frekgh ds fy, izLrqr dh tkus okyh
fu;rdkfyd fooj.kh
1-

fofuekZrk dk uke%

---------------------------------------------------------------------------

2-

fofuekZrk dk irk%

---------------------------------------------------------------------------

3-

laidZ Qksu la[;k vkSj bZesy vkbZMh%

---------------------------------------------------------------------------

4-

VsªMekdZ@eksuksxzke%

---------------------------------------------------------------------------

5-

iathdj.k izek.ki= la[;k%

---------------------------------------------------------------------------

6-

fjiksVZ dk ekl%

vizSy ¼frekgh&, ds fy,½@tqykbZ ¼frekgh&ch ds fy,½@ vDVwcj¼frekgh&lh
ds fy,½@tuojh ¼frekgh&Mh ds fy,½

7-

ckV ;k eki ds fuekZ.k vkSj laO;ogkj dk fooj.k ¼d`i;k fuEufyf[kr rkfydk esa lacaf/kr Jsf.k;ksa ds fy, vyx ls

oLrqokj fooj.k ns½a %
Øe la[;k

frekgh
¼,@ch@lh@Mh½
vkSj o"kZ

1

2

ckV ;k eki fiNyh
frekgh ds
dk o.kZu
[kkuk la[;k
13 ls ykbZ
xbZ fcuk
fcdh
oLrqvksa dh
ek=k
¼la[;k esa½
3
4

frekgh ds dqy LVkWd
nkSjku
¼4$5½
fofufeZr
oLrqvksa dh
ek=k ¼la[;k
esa½

frekgh ds nkSjku jkT; ds
Hkhrj csph xbZ oLrqvksa dh
ek=k ¼la[;k esa½
csph
xbZ chtd
oLrqvksa dh la[;k vkSj
la[;k
fnukad

5

7

6

frekgh ds nkSjku jkT;@ns’k ds ckgj csph xbZ oLrqvksa dh frekgh ds nkSjku
csph xbZ dqy
ek=k ¼la[;k esa½
oLrq
,a ¼7$10½
jkT;@ns’k dk csph xbZ oLrqvksa pkyku la- vkSj
uke
dh la[;k
fnukad
9
10
11
12

cdk;k LVkWd
¼6&12½

13

8

fVIi.kh] ;fn dksbZ
gks

14

*fVIi.k %fofuekZrk dks ckV ;k eki dh izR;sd Js.kh ds fy, vyx ls mijksDr izk:i esa fooj.k cuk, j[kuk gSA

LFkku% -------------------------fnukad% -----------------------

fofuekZrk ds gLrk{kj ,oa eksgj

<!-- page 36 -->

2678

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XIX
[nsf[k, fu;e 7]

ejEerdrkZ }kjk ,slh frekgh ds r`rh; eghus dh vafre frfFk ls nl fnu ds Hkhrj izR;sd frekgh ds fy, izLrqr dh tkus
okyh fu;rdkfyd fooj.kh
1-

ejEerdrkZ dk uke%

---------------------------------------------------------------------------

2-

ejEerdrkZ dk irk%

---------------------------------------------------------------------------

3-

laidZ Qksu la[;k vkSj bZesy vkbZMh%

----------------------------------------------------------------------------

4-

iathdj.k izek.ki= la[;k%

--------------------------------------------------------------------------

5-

fjiksVZ dk ekl%

vizSy ¼frekgh&, ds fy,½@tqykbZ ¼frekgh&ch ds fy,½@
vDVwcj¼frekgh&lh ds fy,½@tuojh ¼frekgh&Mh ds fy,½

6-

dq’ky deZdkjksa dk fooj.k

Øe la[;k

7-

dq’ky deZdkjksa dk uke vkSj firk dk uke

dkS’ky ds {ks= dk uke

dkS’ky izek.ki= dh la[;k
vkSj frfFk

ejEer fd, x, ckV ;k eki dk fooj.k ¼Js.kh&okj½%

Øe la[;k

frekgh
ckV ;k eki dk fiNyh
frekgh
¼,@ch@lh@Mh½ vkSj fooj.k
rd fooj.kh ds
o"kZ
fy, yfEcr ek=k
¼la[;k esa½

frekgh ds nkSjku
ejEer ds fy,
izkIr ek=k ¼la[;k
esa½

1

2

5

lR;kiu 'kqYd dh jkf’k ¼₹½

3

4

frekgh ds nkSjku
,df=r ejEer
'kqYd dh jkf’k
¼₹½ esa½
6

frekgh ds nkSjku frekgh ds var esa fVIi.kh] ;fn dksbZ gks
ejEer ds ckn ykSVkbZ fooj.kh ds fy, yafcr
xbZ ek=k ¼la[;k esa½
ek=k ¼la[;k esa½

frekgh ds nkSjku frekgh ds nkSjku
,df=r ’kqYd
ljdkj ds ikl tek
fd;k x;k
7
8
9

10 ¼4$5&9½

11

*fVIi.k% ejEerdrkZ dks ckV ;k eki dh izR;sd Js.kh ds fy, mijksDr izk:i esa fooj.k vyx ls cuk, j[kuk gSA

LFkku% -------------------------fnukad% -----------------------

ejEerdrkZ ds gLrk{kj ,oa eksgj

<!-- page 37 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2679

vuqlwph&XX
[nsf[k, fu;e 7]

O;ogkjh }kjk ,slh frekgh ds r`rh; eghus dh vafre frfFk ls nl fnu ds Hkhrj izR;sd frekgh ds fy, izLrqr dh tkus okyh
fu;rdkfyd fooj.kh
1-

O;ogkjh dk uke%

---------------------------------------------------------------------------

2-

O;ogkjh dk irk%

---------------------------------------------------------------------------

3-

laidZ Qksu la[;k vkSj bZesy vkbZMh%

---------------------------------------------------------------------------

4-

iathdj.k izek.ki= la[;k%

---------------------------------------------------------------------------

5-

fjiksVZ dk ekl%

vizSy ¼frekgh&, ds fy,½@tqykbZ ¼frekgh&ch ds fy,½@
vDVwcj¼frekgh&lh ds fy,½@tuojh ¼frekgh&Mh ds fy,½

6-

ckV ;k eki dh Js.kh ¼d`i;k fuEufyf[kr rkfydk esa lacaf/kr Jsf.k;ksa ds fy, vyx ls oLrqokj fooj.k nsa½%

Øe
la[;k

frekgh
¼,@ch@
lh@Mh½
vkSj o"kZ

fiNyh frekgh
ds [kkuk la[;k
13 ls fcuk
fcdh oLrqvksa
dk o.kZu vkSj
ek=k ¼la[;k esa½

1

2

3

vkiwfrZdrkZvksa ds
fooj.k
lfgr
frekgh ds nkSjku
jkT; ds vUnj
[kjhnh xbZ oLrqvksa
dk o.kZu vkSj
ek=k ¼la[;k esa½
4

vkiwfrZdrkvksa ds dqy LVkWd
fooj.k
lfgr ¼3$4$5½
frekgh ds nkSjku
jkT; ds ckgj
[kjhnh xbZ oLrqvksa
dk o.kZu vkSj ek=k
¼la[;k esa½
5
6

jkT;@ns’k ds ckgj csph xbZ ek=k
csph xbZ dqy
oLrq
,a ¼7$10½
jkT;@ns’k dk csph xbZ oLrqvksa pkyku la- vkSj
uke
dh la[;k
fnukad
9
10
11
12

jkT; ds Hkhrj csph
xbZ ek=k
csph xbZ chtd
oLrqvksa
la[;k
dh
vkSj
la[;k
fnukad
7

cdk;k LVkWd
¼6&12½
13

8

fVIi.kh] ;fn dksbZ
gks
14

*fVIi.k% O;ogkjh dks ckV ;k eki dh izR;sd Js.kh ds fy, mijksDr izk:i esa fooj.k cuk, j[kuk gSA
LFkku% -------------------------fnukad% -----------------------

O;ogkjh ds gLrk{kj ,oa eksgj

<!-- page 38 -->

2680

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XXI
[nsf[k, fu;e 8¼1½ vkSj 8¼2½]

iathdj.k ds fuyacu@izfrlagj.k djus ds fy, dkj.k crkvks uksfVl
Øekad@vkj-,- ¼fof/kd eki½---------------------

fnukad--------------------------------

lsok esa]
iathd`r O;fDr dk uke

-----------------------------------------------------------------------------

irk

-----------------------------------------------------------------------------

iathdj.k la[;k

-----------------------------------------------------------------------------

fo"k;%

iathdj.k izek.k i= ds fuyacu@izfrlagj.k djus ds fy, dkj.k crkvks uksfVlA

lanHkZ vkidk fofuekZrk@ejEerdrkZ@ O;ogkjh iathdj.k izek.ki= la[;k------------------------------------------------- fnukad------------------------fofuekZrk@ejEerdrkZ@O;ogkjh ds :i esa vkids------------------------¼LFkku½ ij fd, tk jgs O;olk; ds laca/k esa-------------------fujh{k.k@vkSpdfujh{k.k@f’kdk;r dh rkjh[k--------------------------- ds ifj.kkeLo:i] iathdj.k ds vf/kfu;e@fu;eksa@’krksaZ dh
dfFkr vfu;ferrk@[k.Mu@mYya/ku ds ckjs esa esjs ikl ;g fo’okl djus ds izFke n`"V;k dkj.k gSa fd vkius fuEufyf[kr
/kkjkvks@
a fu;eksa@’krksZa dk mYya?ku fd;k gS%&
Øe la[;k
¼1½

vfu;ferrkvks@
a [k.Mu@mYya?kuksa dh izd`fr
¼2½

iathdj.k izek.k i= ds vf/kfu;e@fu;e@’krksZa dh
/kkjk¼vks½a @fu;e¼vks½a
¼3½

rFkkfi] bl ekeys esa vkxs c<+us ls igys] eSa vkidks vf/kfu;e@fu;eksa dh /kkjk@fu;e ds vuqlkj vkids fo#)
dkjZokbZ D;ksa ugha dh tkuh pkfg, ds ckjs] dkj.k crkus dk volj iznku djuk mfpr le>krk gw¡A bl uksfVl ij vkidk
fyf[kr mÙkj] bl uksfVl dh frfFk ls iUnzg fnu ds Hkhrj v/kksgLrk{kjh dks igqap tkuk pkfg,A
d`i;k /;ku nsa fd ;fn vkidk mÙkj vuqc} vof/k ds Hkhrj izkIr ugha gksrk gS] rks ;g ekuk tk,xk fd vki vkids
}kjk fd, x, vf/kfu;e@fu;eksa@iathdj.k dh 'krksZa ds mijksDr of.kZr [k.Mu@mYya?kuksa@vfu;ferrkvksa ls lger gSa]
vkSj vkids iathdj.k izek.ki= ds fuyacu@izfrlagj.k djus ds fy, ,d ,di{kh; dkjZokbZ vf/kfu;e@fu;eksa ds micU/kksa
ds vuqlkj dh tk,xhA

iathdj.k izkf/kdkjh ds gLrk{kj]
uke ,oa inuke eksgj ds lkFk

<!-- page 39 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2681

vuqlwph&XXII
[nsf[k, fu;e 12¼7½ vkSj 13¼3½]

lR;kiu izek.ki=
lR;kiu izek.k i= la[;k-------------------------------------------

fnukad% ------------------------------------------------------------------

mi;ksxdrkZ@fofuekZrk@ejEerdrkZ@O;ogkjh dk uke vkSj irk------------------------------------------------------------------lR;kiu izkf/kdkjh dk uke] inuke rFkk dsna z dk uke%-------------------------------------------------------------------------------------lR;kiu izkf/kdkjh dh igpku la[;k ------------------------------------------------------------------------------------------------------------------eSa blds }kjk] izekf.kr djrk@djrh gw¡ fd eSaus mijksDr of.kZr mi;ksxdrkZ@fofuekZrk@ejEerdrkZ@O;ogkjh ls lacaf/kr
fuEufyf[kr ckV ;k eki dks lR;kfir fd;k gS ,oa eksgj yxkbZ gS vFkok vLohdkj dj fn;k gS%
Øe
la[;k

ckV ;k eki ckV ;k eki dk fooj.k
dk LFkku
¼{kerk@ewY;oxZ@Js.kh@fuekZ.k@midj.k
la[;k@ekWMy vuqeksnu la[;k@dsQSDVj vkfn½

1

2

3
¼lR;kfir vkSj

LVkafEir½

4
¼vLohd`r½

lR;kiu
'kqYd ¼₹½

5

ifjogu
dqy ¼₹½
vkSj@;k
¼5$6½
gSaMfyax 'kqYd
vkfn ¼₹½] ;fn
dksbZ gks
6
7

dqy ¼vadksa esa½
dqy ;ksx ¼[kkuk 7½ ¼’kCnksa esa½
tek jkf’k dh dks"kkxkj jlhn@udn jlhn la[;k--------------------------- frfFk--------------------------------dks"kkxkj dk uke-------------------------------------------------vxys lR;kiu dh frfFk--------------------------lR;kiu izkf/kdkjh ds gLrk{kj
eksgj ds lkFk

fVIIk.k%&

1-

;g izek.ki= O;kolk; ifjlj ds lgtn`’; LFkku ij iznf’Zkr fd;k tkuk pkfg,A

2-

;fn lR;kiu dh vkxkeh frfFk ls igys fdlh Hkh ckV ;k eki dh ejEer dh tkrh gS ] rks mi;ksxdrkZ
bls mi;ksx esa ykus ls igys fofgr Qhl ds Hkqxrku ij ejEer rFkk LVkEiu ds ckn lR;kfir djok,xkA

<!-- page 40 -->

2682

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XXIII

[nsf[k, fu;e 14¼1½] 14¼2½] 14¼3½ rFkk 14¼4½]
ckV ,oa eki ds lR;kiu vkSj eksgj yxkus ds fy, Hkqxrku ;ksX; Qhl
Øe
la[;k

lR;kiu vkSj eksgj yxkus ds fy, Qhl

1
¼d½ cqfy;u ckV

¼[k½ dSjsV ckV

¼x½ csyukdkj nLrk fdLe ckV

¼?k½ pknjh /kkrq ckV ¼cqfy;u ls fHkUu½
¼M½

ckV
ewY; oxZ
1 ,eth ls 1 fdyksxzke
1 fdyksxzke ls Åij
10 fdyksxzke rd
1,eth (0.005 lh) ls
400,eth (2 lh)
400,eth (2 lh) ls Åij
100xzke (500 lh) rd
1 xzke ls 500 xzke
1 fdyks ls 2 fdyksxzke
5 fdxzk ls 10 fdyksxzke
1 feyhxzke ls 500 feyhxzke

¼₹½ izfr Hkkx
50
100
50
100
20
30
50
20

yksgk "kV~dks.kh; nLrk fdLe ckV rFkk 1 xzke ls 500 xzke
lekukUrj "kV~Qyd ckV%
1 fdyksxzke ls 2 fdyksxzke

20

5 fdyksxzke ls 10 fdyksxzke

50

30

20 fdyksxzke ls 50 fdyksxzke 100
¼p½

mPp {kerk rksy e’khu ds ijh{k.k ds fy, 100 fdyksxzke
ekud ckV
200 fdyksxzke
fdyksxzke

200
ls

500 500

1000 fdyksxzke

1500

2000 fdyksxzke ls 5000 3000
fdyksxzke
2

eki
¼d½ {kerk eki

20 yhVj rd

50

50 yhVj

100

100 yhVj vkSj mlls vf/kd

igys 100 yhVj ds
fy, 200 #i, vkSj
izR;sd vfrfjDr 100
yhVj ;k mlds Hkkx
ds fy, 20 #i, dh
nj ls vf/kdre
10]000@& #i, ds
v/;/khu

<!-- page 41 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¼[k½ yEckbZ eki
(i)
vUkE;

(ii)

3

diM+k@IykfLVd@cquk gqvk@LVhy Vsi
(iii)
QksfYMax Ldsy
(iv)
losZ{k.k tathj
MaMh okyh rjktw
¼d½ Js.kh d vkSj [k
¼[k½ Js.kh x vkSj ?k

4

5

6

vLopkfyr rksy midj.k
¼d½ eSdsfudy ¼,ukykWx½ vkSj
Js.kh III vkSj IIII

2683

0-5 ehVj ls 1 ehVj
¼v’kkafdr izR;sd lseh ij½
0-5 ehVj ls 2 ehVj
¼vuk’kkafdr½
lVhdrk oxZ- I, II, III
0-5 ehVj ls 1 ehVj
dksbZ Hkh yEckbZ

50

5 fdyksxzke rd
5 fdyksxzke ls Åij
50 fdyksxzke rd
50 fdyksxzke ls Åij

200
400
100
300

bysDVªkWfud 200 fdyksxzke rd
200 fdyksxzke ls Åij 1 Vu
rd
1 Vu ls Åij 20 Vu rd
20 Vu ls Åij 100 Vu rd
100 Vu ls Åij
¼[k½ eSdsfudy vkSj bysDVªkWfuDl oxZ I vkSj II
50 fdyksxzke rd
50 fdyksxzke ls Åij 200
fdyksxzke rd
200 fdyksxzke ls Åij 1 Vu
rd
1 Vu ls Åij 10 Vu rd
10 Vu ls Åij
Lopkfyr rksy midj.k
50 fdyksxzke rd
50 fdyksxzke ls Åij 200
fdyksxzke rd
200 fdyksxzke ls Åij 1 Vu
rd
1 Vu ls Åij 10 Vu rd
10 Vu ls Åij
vk;ru ekid midj.k
¼d½ ;ksxdj.k ds lkFk fMLiSfUlx iai
izR;sd uksty
¼[k½ izek.khdj.k eki o vU; midj.k
50 yhVj rd
50 yhVj ls Åij 100 yhVj
rd
100 yhVj ls vf/kd

50
5 izfr ehVj
50
500

300
500
2000
4000
5000
400
600
1000
3000
6000
400
600
1000
3000
6000
4000
500
1000
igys 100 yhVj ds
fy, 1000 vkSj izR;sd
vfrfjDr 100 yhVj
;k mlds Hkkx ds fy,
500
vf/kdre
10]000@& #i;s ds
v/;/khu

<!-- page 42 -->

2684

7

8

9
10
11
12
13
14
15
16
17
18
19
20

21

22
23
24
25
26
27

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

¶yks ehVj

js[kh; ekid midj.k

100 yhVj@feuV dh izokg
nj rd
100 yhVj ls Åij 500
yhVj@feuV rd
500 yhVj@feuV ls vf/kd
rd
vkWVks fjD’kk ehVj
VSDlh ehVj
vU; ehVj

3000 izfr bZdkbZ
5000 izfr bZdkbZ
10000 izfr bZdkbZ

200 izfr bZdkbZ
500 izfr bZdkbZ
igys 1000 ehVj ;k
mlds Hkkx ds fy,
100 vkSj izR;sd
vfrfjDr 100 ehVj
;k Hkkx ds fy, 10
vf/kdre 5000@&
#i;s ds v/;/khu
fpfdRlk FkekZehVj
izR;sd bZdkbZ
10
ikuh dk ehVj
izR;sd bZdkbZ
100
iSx ekid
izR;sd bZdkbZ
100
lh,uth fMLisl
a j
izR;sd uksty
4000
,yihth fMLisl
a j
izR;sd uksty
4000
dkmaVj e’khu@dkmaVj Ldsy
izR;sd bZdkbZ
100
;ksxdj.k dkmaVj
izR;sd bZdkbZ
1000
fLizax@lkj.khc) rqyk
10 fdyksxzke rd
50
10 fdyksxzke ls Åij
200
fdpu Ldsy
izR;sd bZdkbZ
100
O;fDr Hkkj ekid e’khu vkSj ckFk:e Ldsy
izR;sd bZdkbZ
200
cPps ;k f’k’kq dk Hkkj ekid e’khu ¼Ldsy½
izR;sd bZdkbZ
100
Lopkfyr xfreku jsy@jksM rksylsrq ¼osfczt½
izR;sd yksM fjlsIVj ds fy, 5000
izR;sd ;ksxdj.k midj.k ds 5000
fy,
Lopkfyr xzsfoeSfVªd HkkjkRed Hkjko midj.k
10 fdyksxzke rd ds izR;sd 1000
yksM fjlsIVj ds fy,
10 fdyksxzke ls Åij ds 2000
izR;sd yksM fjlsIVj ds fy,
vlarr ;ksxdj.k Lopkfyr Hkkj ekid midj.k izR;sd yksM fjlsIVj ds fy, 3000
¼;ksxdj.k gkWij ekid½
larr ;ksxdj.k Hkkj ekid midj.k ¼csYV ekid½
izR;sd yksM fjlsIVj ds fy, 3000
fujh{k.k Hkkj ekid o Hkkj oxhZdj.k e’khu
izR;sd bZdkbZ
3000
fLQXekseSuksehVj ¼jDrpki ekius dh iz.kkyh½
izR;sd bZdkbZ
100
yksM lSy
5 ds ,urd
2000
5 ds ,uls Åij
5000
xSl ehVj
?kjsyw
500
okf.kfT;d
2000

<!-- page 43 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

28

ÅtkZ ehVj

29

vknZzrk ehVj ¼fMftVy½
vknzZrk ehVj ¼eSuqvy½
okguksa ds fy, xfr ehVj
'okl fo’ys"kd
cgq&vk;keh ¼foferh;½ ekid midj.k

30
31
32

vkS|ksfxd
?kjsyw
okf.kfT;d
vkS|ksfxd
izR;sd bZdkbZ
izR;sd bZdkbZ
izR;sd bZdkbZ
izR;sd bZdkbZ
izR;sd bZdkbZ

2685

2000
1000
3000
5000
1000
1000
10000
2500
3000

fVIi.k %& ;g lwph dsoy funs’Z kkRed gS vkSj iwjh ugha gSA jkT; ljdkj le;&le; ij dsUnzh; ljdkj }kjk vfèklwfpr
fdlh Hkh u, ckV ;k eki dks blesa 'kkfey dj ldrh gSA blh rjg] lR;kiu Qhl Hkh jkT; ljdkj fu/kkZfjr djsxhA vxj
dksbZ ,slk ckV ;k eki] tks bl vuqlwph dk fgLlk ugha gS vkSj ftlds fy, jkT; ljdkj }kjk dksbZ Qhl fu/kkZfjr ugha
fd;k x;k gS] rks ml le; rd dsUnzh; ljdkj }kjk fofgr Qhl gh ykxw gksxhA

<!-- page 44 -->

2686

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XXIV
[nsf[k, fu;e 14¼2½]

ckV ,oa eki ds lR;kiu rFkk LVkEiu ds fy, ns; ifjogu vkSj lapkyu izHkkj
Ø0
la[;k

o.kZu

fu;e 13¼2½ ds v/khu ifjogu vkSj lapkyu izHkkj
bZdkbZ
jkf’k ¼₹½ esa

1

rksylsrq

izR;sd bZdkbZ

2

izR;sd izfr"Bku

3

isVªksy@Mhty@lh,uth@,yihth@vU;
fQfyax LVs’ku
ckV ;k eki ds fofuekZrk

4

xSj&Lopkfyr rkSy midj.k ¼rksylsrq ls fHkUu½

izR;sd izfr"Bku

5
6

Lopkfyr otu midj.k@Lopkfyr xzsfoesfVªd izR;sd izfr"Bku
Hkjko midj.k vkfnA
izokg@cYd ehVj vkSj HkaMkj.k VSad vkfnA
izR;sd izfr"Bku

7

Lopkfyr jsy@lM+d rksylsrq

izR;sd bZdkbZ

8

vk;ru ekid midj.k

izR;sd izfr"Bku

9

vU;

izR;sd izfr"Bku

izR;sd izfr"Bku

5000 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
2500 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
2500 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
1000 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
2500 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
5000 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
5000 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
5000 #i;s vkSj okLrfod vk/kkj
ij bZa/ku izfr fujh{k.k ¼foftV½
1000 i;s vkSj okLrfod vk/kkj ij
bZa/ku izfr fujh{k.k ¼foftV½

<!-- page 45 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2687

vuqlwph&XXV

[nsf[k, fu;e 15¼1½]
Qhl jlhn
iqLrd la[;k-------------------------------------------

Øe la[;k%-------------------------------------

Jh@Jherh@lqJh@eSltZ------------------------------------------------------------------------¼uke ,oa irk½ ls ¼₹½ --------------------dh jkf’k ¼’kCnksa esa-------------------------------------------½ lR;kiu Qhl@iathdj.k Qhl @iz’keu Qhl @vU; Qhl ;k izHkkj ds :i esa izkIr dhA
fnukad%-------------------------------fof/kd eki foKku vf/kdkjh ds gLrk{kj
eksgj ds lkFk

<!-- page 46 -->

2688

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XXVI

[nsf[k, fu;e 15¼2½]
'kqYd ;k izHkkj ds laxzg.k dk jftLVj
iqLrd la[;k-------------------------------------------

i`"B Øe la[;k%-------------------------------

fof/kd eki foKku vf/kdkjh dk uke] inuke ,oa igpku la[;k% -----------------------------------------------------------------------dsna z rFkk ftyk dk uke -----------------------------------------------------------------------------------------------------------------------------------------------------frfFk

mi;ksxdrkZ@
fofuekZrk@
ejEerdrkZ@
O;ogkjh@vU;
dk uke ,oa irk

lR;kiu
ckV ;k
izek.ki=
eki dk
la[;k ¼tgka fooj.k
Hkh ykxw gks½

,df=r 'kqYd@izHkkj dh ,df=r
jlhn
fdLe
¼lR;kiu jkf’k ¼₹½ la[;k@iq
'kqYd@iathdj.k
Lrd laesa
'kqYd@vihy ds fy, 'kqYd@
iz’kklu
'kqYd@izfrHkwfr
tek@ ifjogu 'kqYd@
gS.Mfyax 'kqYd@vU;

dqy ,df=r jkf’k ¼#-½ ------------------------------------------------------------------------------------------------------------------------------------------------------ljdkjh [k+tkus esa jkf’k tek djkus dh jlhn@thvkj,u la[;k ¼,a½---------------------------------------frfFk--------------------bl iz:i ds i`"B dh nwljh vksj fof/kor~ fpidkbZ xbZ dks"kkxkj jlhn dh ewy izfr dh lR;kfir izfr lkIrkfgd
vk/kkj ij lgk;d fu;a=d@mi fu;a=d@fu;a=d dks Hksth tk,xhA
fnukad% -----------------------

fof/kd eki foKku vf/kdkjh ds gLrk{kj
eksgj ds lkFk

<!-- page 47 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2689

vuqlwph&XXVII

[nsf[k, fu;e 19]
lq/kkj uksfVl
uksfVl la[;k-------------------------------------------

fnukad%--------------------------------------

lsok esa]
--------------------------------------------------------------------------------------------------------------fo"k;%

lq/kkj uksfVl A

vkids----------------------------------- ¼LFkku½ ij fd, tk jgs O;olk; ds laca/k esa----------------------------fujh{k.k@vkSpd
fujh{k.k@f’kdk;r rkjh[k------------------------ ds ifj.kkeLo:i] esjs ikl ;g fo’okl djus ds izFke n`"V;k dkj.k gS fd vkius
fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dk dsUnzh; vf/kfu;e 1½ vkSj blds v/khu cuk, x, fu;eksa ds laca/k esa dfFkr
vfu;ferrk,a@[k.Mu@mYya?ku djrs gq, fuEufyf[kr /kkjkvks@
a fu;eksa dk mYya?ku fd;k gS&
Øe la[;k

vfu;ferrkvks@
a [k.Mu@mYya?kuksa dh izd`fr

vf/kfu;e@fu;eksa dh lEcfU/kr /kkjk,a

¼1½

¼2½

¼3½

2- blfy,] vkidks blds }kjk mijksDr of.kZr vfu;ferrkvks@
a [k.Mu@mYya?kuksa dks lq/kkjus ds fy, vko’;d lq/kkjkRed
mik; djus ds fy, funsZf’kr fd;k tkrk gS rkfd bUgsa bl uksfVl ds tkjh gksus dh rkjh[k ls lkr ¼7½ fnol ds vUnj
fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dk dsUnzh; vf/kfu;e 1½ vkSj blds v/khu cuk, x, lqlaxr fu;eksa ds micU/kksa
ds vuqlkj mls iwjk fd;k tk ldsA
3- vkidks mijksDr rkfydk ds [kkuk la[;k 2 esa mfYyf[kr vfu;ferrkvks@
a [k.Mu@mYya?kuksa ls lacaf/kr O;kolkf;d
xfrfof/k;ksa dks rqjar can djus gsrq funsZf’kr Hkh fd;k tkrk gS vkSj Åijof.kZr iSjk la[;k 2 esa mfYyf[kr lq/kkj dh vof/k ds
vUnj bls lq/kkjsaA
4- mijksDr of.kZr vuqc/a k vof/k ds vUnj vuqikyuk uk fd;s tkus dh n’kk esa bls nwljk vijk/k ekuk tk,xk vkSj ,slh
?kVuk esa] vki ,oa lHkh O;fDr] tSlh Hkh fLFkfr gks] mijksDr O;olk; izfr"Bku ds lEcU/k esa O;olk; lapkfyr fd;s tkus ds
fy, ftEesnkj gksx
a s] fof/kd eki foKku vf/kfu;e] 2009 ¼2010 dk dsUnzh; vf/kfu;e 1½ vkSj blds v/khu cuk, x, fu;eksa
ds micU/kksa ds varxZr dkjZokbZ ds fy, fcuk fdlh vkSj lwpuk ds vfHk;kstu vkSj@;k vijk/kksa ds iz’keu lfgr ‘’kkfLr
vkfn] tSlh Hkh fLFkfr gks] ds fy, mÙkjnk;h gksx
a sA blds vykok] iathdj.k izek.k i= vkSj@;k lR;kiu izek.k i= ds
fuyacu@izfrlagj.k djus dh dkjZokbZ] tks ykxw gks] izkjEHk Hkh dh tk ldrh gSA
5- ;g uksfVl vuqikyu ds mís’; ls vkidks vkSj mijksDr O;olk; izfr"Bku ls lacaf/kr lHkh O;fDr;ksa dks ;Fkk fof/kor
rkehy fd;k x;k le>k tk,xkA

fof/kd eki foKku vf/kdkjh ds gLrk{kj
eksgj ds lkFk

<!-- page 48 -->

2690

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XXVIII
[nsf[k, fu;e 19]

fofHkUu vijk/kksa ds fy, iz’keu /kujkf’k
Øe
la[;k

vijk/k dh Lo:i vf/kfu;e
,oa /kkjk
dh /kkjk ds
vuq:i
'kkfLr

iz’keu Qhl ¼₹½ esa

Js.kh

1

2

3

4

ekud ckV] eki ;k 25
la[;ku ls fHkUu
ckV] eki ;k la[;k
dk iz;ksx djuk
rFkk j[kuk
[/kkjk 8¼3½]

ckV ;k eki esa 26
ifjorZu
[/kkjk 26]

ekudksa ds vuq:i 27
ugha gksus okys ckV
;k eki dk fuekZ.k
;k fcØh
[/kkjk 8¼4½]

fofgr ls fHkUu ckV 28
eki ;k la[;k ls

izFke vijk/k f}rh;
vijk/k

lq/kkj
uksfVl
O;fDrxr@fganw la;qDr lq/kkj
ifjokj
uksfVl
Lokeh@
LokfeRo lq/kkj
QeZ@lgHkkxh@ Hkkxhnkjh uksfVl
QeZ
lnL;
lq/kkj
lfefr@U;klh@U;kl
uksfVl
funs’kd
@dEiuh lq/kkj
ljdkjh foHkkx@ LFkkuh; uksfVl
izkf/kdj.k
Qsjh okys
5000@&

2500@&

r`rh; vFkok
i'pkrorhZ
vijk/k
200000@&

5000@&

200000@&

10000@&

200000@&

25000@&

200000@&

100000@&

300000@&

10000@&

O;fDrxr @fgUnw la;qDr
ifjokj
Lokeh@
LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
lnL;
lfefr@U;klh@U;kl
funsZ’kd@
dEiuh
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
O;fDrxr@ fgUnw la;qDr
ifjokj@Lokeh@ LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ@
lnL;
@lfefr@U;klh@ U;kl]
funs’kd@
dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k

10000@&

50000@&

25000@&

100000@&

vnkyr esa
Hkjk tkuk gS
vnkyr esa
Hkjk tkuk gS
vnkyr esa
Hkjk tkuk gS

25000@&

100000@&

50000@&

100000@&

lq/kkj
uksfVl

50000@&

300000@&

lq/kkj
uksfVl

100000@&

400000@&

Qsjh okys

lq/kkj
uksfVl

2500@&

100000@&

Qsjh okys

vnkyr esa
Hkjk tkuk gS
vnkyr esa
Hkjk tkuk gS

<!-- page 49 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

oLrqvks]a dh Js.kh];k
opu ds laO;ogkj
;k O;ogkj ;k
vuqc/a k
[/kkjk 10]

5

6

7

ckV]
eki
;k 29
la[;ku ds ekud
bdkbZ ds :i ls
fHkUu m}`.k ;k
m}?kks"k.kk djus ;k
fuxZr djuk ;k
ewY; lwph dk
izn’kZu ;k ewY;
lwph esa ifjorZu
djuk
[/kkjk 11]

dfFkr oLrq] pht 30
;k lsok ds lEcU/k
esa lafonk ;k vU;
djkj esa ckV] eki
;k la[;k }kjk
fofufnZ"V ek=k dh
vf/kdrk ;k ls de
fdlh Hkh fdLe dh
oLrq] pht ;k lsok
dh ekax] izkIr djus
dh ;k ekax ;e
izkIr djokus dh
izFkk] fjokt] nLrwj
;k <ax [/kkjk 12]
fofuekZrk] O;ogkjh 31
o ejEedrkZ }kjk
nLrkostks dks izLrqr
u djuk rFkk
vfHkys[k] jftLVj
dk vuqj{k.k u
djuk vkSj ekaxs
tkus ij ckV] eki
nLrkost ;k fofgr

O;fDrxr@ fgUnw la;qDr
ifjokj
Lokeh@ LokfeRo
QeZ@lgHkkxh@
Hkkxhnkjh QeZ
lnL;@
lfefr@U;klh@
U;kl
funsZ’kd@ dEiuh
ljdkjh foHkkx @LFkkuh;
izkf/kdj.k
Qsjh okys

2691

lq/kkj
uksfVl
lq/kkj
uksfVl

10000@&

100000@&

25000@&

100000@&

lq/kkj
uksfVl

30000@&

150000@&

lq/kkj
uksfVl

50000@&

200000@&

lq/kkj
uksfVl
O;fDrxr@ fgUnw la;qDr lq/kkj
ifjokj
uksfVl
Lokeh@LokfeRo
lq/kkj
QeZ@lgHkkxh@ Hkkxhnkjh uksfVl
QeZ
lnL;
lq/kkj
@lfefr@U;klh@ U;kl uksfVl
funs’kd@
dEiuh@ lq/kkj
ljdkjh foHkkx@ LFkkuh; uksfVl
izkf/kdj.k
Qsjh okys
1000@&

2500@&

100000@&

10000@&

100000@&

25000@&

100000@&

30000@&

150000@&

50000@&

200000@&

5000@&

O;fDrxr @fgUnw la;qDr
ifjokj
Lokeh@
LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
lnL;
@lfefr@U;klh@
U;kl
funs’kd@
dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
Qsjhokys

5000@&

10000@&

10000@&

20000@&

vnkyr esa
Hkjk tkuk gS
vnkyr esa
Hkjk tkuk gS
vnkyr esa
Hkjk tkuk gS

10000@&

20000@&

vnkyr esa
Hkjk tkuk gS

10000@&

20000@&

vnkyr esa
Hkjk tkuk gS

5000@&

50000@&

10000@&

50000@&

10000@&

50000@&

15000@&

100000@&

lq/kkj
uksfVl
O;fDrxr @fgUnw la;qDr lq/kkj
ifjokj
uksfVl
Lokeh@
LokfeRo lq/kkj
QeZ@lgHkkxh@ Hkkxhnkjh uksfVl
QeZ
lnL;
lq/kkj
@lfefr@U;klh@U;kl uksfVl

<!-- page 50 -->

2692

8

9

10

11

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

jftLVj dk izLrqr
u fd;k tkuk
[/kkjk 15¼1½] 15¼2½
vkSj 17]
vlR;kfir ckV ;k 33
eki ds iz;ksx ds
fy, 'kkfLr
[/kkjk 24 ¼1½ vkSj
33]

vekud ckV ;k eki 34
ds }kjk oLrqvksa dk
foØ; ;k forj.k ds
fy, 'kkfLr
[/kkjk 34]

vekud ckV] eki 35
;k la[;k }kjk lsok
iznku djus ds fy,
'kkfLr
[/kkjk 35]

fofuekZrk@
36¼1½
O;ogkjh@ [kqnjk
O;kikjh }kjk fMCck
can oLrq ds laca/k esa

funs’kd@
dEiuh@ lq/kkj
ljdkjh foHkkx@ LFkkuh; uksfVl
izkf/kdj.k

25000@&

Qsjhokys
O;fDrxr @fgUnw la;qDr
ifjokj
Lokeh@
LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
lnL;
@lfefr@U;klh@
U;kl
funs’kd
@dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
Qsjhokys

2000@&
5000@&

vnkyr esa Hkjk tkuk gS
vnkyr esa Hkjk tkuk gS

10000@&

vnkyr esa Hkjk tkuk gS

10000@&

vnkyr esa Hkjk tkuk gS

10000@&

vnkyr esa Hkjk tkuk gS

lq/kkj
uksfVl
O;fDrxr @fgUnw la;qDr lq/kkj
ifjokj
uksfVl
Lokeh@
LokfeRo lq/kkj
QeZ@lgHkkxh@ Hkkxhnkjh uksfVl
QeZ
lnL;
lq/kkj
@lfefr@U;klh@
uksfVl
U;kl
funs’kd
@dEiuh@ lq/kkj gsrw
ljdkjh foHkkx@ LFkkuh; uksfVl
izkf/kdj.k
Qsjhokys
lq/kkj
uksfVl
O;fDrxr @fgUnw la;qDr lq/kkj
ifjokj
uksfVl
Lokeh@
LokfeRo lq/kkj
QeZ@lgHkkxh@ Hkkxhnkjh uksfVl
QeZ
lnL;
lq/kkj
@lfefr@U;klh@U;kl uksfVl
funs’kd
@dEiuh@ lq/kkj
ljdkjh foHkkx@ LFkkuh; uksfVl
izkf/kdj.k
Qsjhokys
lq/kkj
uksfVl
O;fDrxr @fgUnw la;qDr lq/kkj
ifjokj
uksfVl

100000@&

1500@&

50000@&

2500@&

50000@&

10000@&

50000@&

10000@&

75000@&

25000@&

100000@&

1500@&

50000@&

2500@&

50000@&

10000@&

50000@&

10000@&

75000@&

25000@&

100000@&

5000@&

2500000@&

20000@&

2500000@&

<!-- page 51 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

?kks"k.kk dk vuqikyu
djuk
[/kkjk 18¼1½]

12

13

14

15

16

fofuekZrk
}kjk 36¼2½
fMCck can oLrq esa
'kq) ek=k ekax dk
vuqikyu djuk
[/kkjk 18¼1½]

feF;k lwpuk ;k 41¼1½
feF;k
foojf.k;k¡ ¼2½
nsus ds fy, 'kkfLr
[/kkjk 41]

iathdj.k izek.k i= 45
ds fcuk ckV ;k eki
ds fuekZ.k ds fy,
’kkfLr
[/kkjk 23
vkSj 45]

iathdj.k izek.k i= 46
ds fcuk ckV ;k eki
dh ejEer ;k
foØ;
djus ds
fy, 'kkfLr
[/kkjk 23 vkSj 46]

iathdj.k izek.k i= 47
ds lkFk NsM+NkM+

Lokeh@
LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
lnL;
lfefr@U;klh@U;kl
funsZ’kd dEiuh ljdkjh
foHkkx LFkkuh; izkf/kdj.k
Qsjhokys
O;fDrxr @fgUnw la;qDr
ifjokj
Lokeh@
LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
lnL;
@lfefr@U;klh@ U;kl
funs’kd
@dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
vkSj O;fDrxr @fgUnw la;qDr
ifjokj
Lokeh@
LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
lnL;
@lfefr@U;klh@
U;kl
funs’kd
@dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
O;fDrxr@ fgUnw la;qDr
ifjokj@Lokeh@ LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ@lnL;@
lfefr@U;klh@U;kl
funs’kd
@dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
O;fDrxr @ fgUnw la;qDr
ifjokj@Lokeh@ LokfeRo
QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
@lnL;@
lfefr@U;klh@U;kl
funs’kd
@dEiuh@
ljdkjh foHkkx@ LFkkuh;
izkf/kdj.k
O;fDrxr @ fgUnw la;qDr
ifjokj@Lokeh@ LokfeRo

2693

lq/kkj
uksfVl

50000@&

2500000@&

lq/kkj
uksfVl
lq/kkj
uksfVl
10000@&
10000@&

50000@&

2500000@&

50000@&

5000000@&

25000@&
50000@&

50000@&
200000@&

25000@&

100000@&

500000@&

50000@&

200000@&

1000000@&

100000@&

500000@&

5000000@&

lq/kkj
uksfVl
lq/kkj
uksfVl

1000@&

200000@&

2000@&

200000@&

lq/kkj
uksfVl

3000@&

300000@&

lq/kkj
uksfVl

5000@&

500000@&

lq/kkj
uksfVl

10000@&

200000@&

lq/kkj
uksfVl

20000@&

500000@&

lq/kkj
uksfVl

5000@&

200000@&

lq/kkj
uksfVl

5000@&

500000@&

lq/kkj
uksfVl

10000@&

200000@&

<!-- page 52 -->

2694

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

djus
ds fy,
'kkfLr [/kkjk 47]

17

vf/kfu;e ds v/khu
cuk, x, fu;eksa ds
fdlh Hkh micU/k dk
mYya?ku
[/kkjk 52¼3½ vkSj
53¼3½]

QeZ@lgHkkxh@ Hkkxhnkjh
QeZ
@lnL;@
lfefr@U;klh@U;kl
funs’kd
@dEiuh@ lq/kkj
20000@&
500000@&
ljdkjh foHkkx@ LFkkuh; uksfVl
izkf/kdj.k
52¼3½] 53¼3½ Qsjhokys
2000@& #i,] fuyacu ;k izfrlagj.k ds
dkj.kA
O;fDrxr@ fgUnw la;qDr 5000@&#i,] fuyacu ;k izfrlagj.k ds
ifjokj
dkj.kA
Lokeh@
LokfeRo 10000@&#i,] fuyacu ;k izfrlagj.k ds
QeZ@lgHkkxh@ Hkkxhnkjh dkj.kA
QeZ
lnL;
50000@&#i,] fuyacu ;k izfrlagj.k ds
@lfefr@U;klh@ U;kl dkj.kA
funs’kd
@dEiuh@ 100000@&#i,] fuyacu ;k izfrlagj.k ds
ljdkjh foHkkx@ LFkkuh; dkj.kA
izkf/kdj.k

<!-- page 53 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2695

vuqlwph&XXIX
[nsf[k, fu;e 20]

vihy
fof/kd eki foKku vf/kdkjh@fu;a=d ds vkns’k ds fo:) vihy%
1-

vihydrkZ dk uke vkSj irk-----------------------------------------------------------------------------------------------------------------------------------

2-

fof/kd eki foKku vf/kdkjh@fu;a=d ds vkns’k dh la[;k ,oa frfFk ftlds fo:) vihy dh xbZ gS ¼vkns’k dh izfr
layXu djsa½----------------------------------------------------------------------------------------------------------------------

3-

D;k vihydrkZ O;fDrxr :i ls ;k izkf/kd`r izfrfuf/k ds ek/;e ls lquokbZ pkgrk gS
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

4-

vihy ds vk/kkj ¼lgk;d nLrkost layXu djsa½ -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

5-

vihy ds fy, Qhl dk fooj.k ¼jlhn@pkyku la[;k ,oa frfFk½-----------------------------------------------------------

frfFk ------------------------------

vihydrkZ ds gLrk{kj

<!-- page 54 -->

2696

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

vuqlwph&XXX
[nsf[k, fu;e 20]

vihy ds fy, Qhl
Øe la[;k

o.kZu

jkf’k (₹)esa

1

fu;a=d dks vihy

2000/- izfr vihy

2

jkT; ljdkj dks vihy

5000/- izfr vihy

---------------------------------------------------------------------

veuhr ih0 dqekj]
iz/kku lfpo] gfj;k.kk ljdkj]
[kk|] ukxfjd vkiwfrZ ,oa miHkksDrk ekeys foHkkxA

<!-- page 55 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2697

HARYANA GOVERNMENT
FOOD, CIVIL SUPPLIES AND CONSUMER AFFAIRS DEPARTMENT
Notification
The 8th October, 2026
No. LM-2026/Enforcement/19662.— The following draft of the rules which the Governor
of Haryana proposes to make in exercise of the powers conferred by section 53 of the Legal
Metrology Act, 2009 (Central Act 1 of 2010) after consultation with the Central Government is
hereby published as required under sub-section (4) of section 53 for the information of persons likely
to be affected thereby.
Notice is hereby given that the draft of the rules shall be taken into consideration
by the State Government on or after the expiry of a period of one week from the date of publication
of this notification in the Official Gazette, together with objections or suggestions, if any, which
may be received in writing by the Administrative Secretary to Government, Haryana, Food, Civil
Supplies and Consumer Affairs Department, from any person with respect of the draft of the rules,
before the expiry of the period so specified.
1.

(1)
(2)

These rules may be called the Haryana Legal Metrology (Enforcement) Rules, 2026.
They shall come into force on the date of their publication in the Official Gazette.

Short title and
commencement.

2.

(1)

In these rules, unless the context otherwise requires,(a) "Act" means the Legal Metrology Act, 2009 (Central Act 1 of 2010);
(b) "Administrative Secretary" means the Administrative Secretary to Government,
Haryana, Food, Civil Supplies and Consumer Affairs Department;
(c) "appellate authority" means(i) the Controller- if the appeal is filed against the orders passed by the
concerned Legal Metrology Officer;
(ii) the Administrative Secretary-if the appeal is filed against an order passed
by the Controller;
(d) "calibration" means all the operations which are necessary for the purpose of
determining the values of the errors of weight or measure and, if necessary, to
determine the other metrological properties of such weight or measure and
includes the actual fixating of the positions of the gauge marks or scale-marks
of a weight or measure, or in some cases, of certain principal marks only, in
relations to the corresponding values of the quantity to be measured;
(e) "reference standards laboratory" means a laboratory established by the Central
Government, where reference standards, secondary standards and working
standards are maintained;
(f) "registered person" means a manufacturer, repairer or dealer registered under
rule 5;
(g) "registering authority" means the Controller, Legal Metrology, Haryana or any
officer appointed by the State Government not below the rank of Deputy
Controller, Legal Metrology;
(h) "Schedule" means the Schedule appended to these rules;
(i) "self-verification of weight or measure" means the verification of the weight or
measure by manufacturer, who is approved as Government Approved Test
Centre (GATC) by the Central Government or by the State Government in
relation to such weight or measure manufactured by him, in such a manner
prescribed by the Act and the rules made thereunder;
(j) "skilled worker” means a person to whom a skill certificate has been issued by
the Controller for the repair of weights or measures;
(k) "State Government” means the Government of the State of Haryana in the
administrative department;
(l) "test weight or measure” means a weight or measure which is a replica of a
working sṣtandard weight or measure in respect of accuracy only

Definitions.

<!-- page 56 -->

2698

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
(m) "verifying authority" means the Controller, Legal Metrology Officer or the
government approved test centre notified by the Central Government or State
Government under the Act.
(2) Words and expressions used in these rules and not defined but defined in the Act shall
have the meanings respectively assigned to them in the Act.

Use of weight,
measure or number
in certain cases.
section 10.
Disposal of seized
weight or measure
etc.
section 16 (1).

3.
Any transaction, dealing or contract in respect of any goods, class of goods or undertaking,
other than pre-packaged commodities shall be made by weight, measure or number as specified
as per Schedule-I.
4.
(1) Any unverified weight or measure shall be returned to the person from whom such
weight or measure was seized, if that person gets the offence compounded by the Legal Metrology
Officer and the same weight or measure is verified and stamped within fifteen days of such return,
on payment of such fee as specified in sub-rule (3) of rule 14.
(2) Any weight or measure or article or goods (perishable/speedy natural decay or
otherwise) or related documents seized under section 15 of the Act, which are subject to the
proceedings in a court and produced by the Legal Metrology Officer before the court, shall be
taken possession of by the Legal Metrology Officer after conclusion of the proceedings in the
court and dealt with in accordance with the orders of the court:
Provided that in the absence of any orders of the court, the weight or measure or
article or goods (perishable/ speedy natural decay or otherwise) or related documents shall be
dealt with as the Controller may by a special order direct and the material thereof shall be sold
and the proceeds credited to the State Government:
Provided further that if the person, who has committed the offence, refuses to sign
the seizure details, the Legal Metrology Officer shall obtain the signatures of at least two persons
present at the time of such refusal by the offender. In the case of goods returned to the offender,
he shall give an undertaking that he shall not sell the defective goods without rectifying their
defects thereon:
Provided further that the Controller or any officer authorized by him in this behalf
shall be the final authority to decide whether the goods seized are subject to speedy or natural
decay.
(3) Where the goods seized under sub-section (1) of section 15 of the Act are not subject
to speedy or natural decay, the Legal Metrology Officer may retain the package for the purpose
of prosecution under the Act after serving notice of seizure to the offender or his agent or any
other person who has committed the offence.
(4) The goods referred to in sub-rule (2) and (3), which are not subject to proceedings in
any court, shall be disposed of after the expiry of ninety days from the date of such seizure, as the
Controller may direct by a general or special order.

Registration of
manufacturers,
repairers and
dealers.

5.
(1) Every manufacturer, repairer or dealer shall submit an application as per ScheduleII, III or IV respectively along with the registration fee as per Schedule-V to the registering
authority for grant of registration certificate along with self-declaration:

section 23 (2).

Provided that in case the applicant for registration as repairer is other than an
individual, the copy of certificate of skill as per Schedule-XIV issued by the Controller in respect
of either the proprietor, partner, director, member, employee, as the case may be, shall be attached
at the time of making the application for registration:
Provided further that in case of change, if any, in the details of the Certificate of
Skill so mentioned at the time of registration of the applicant, the same shall be informed to the
registering authority failing which the registration shall be deemed to be revoked:
Provided further that repair of any weight or measure manufactured by the
manufacturer in a State other than in the State of Haryana, the manufacturer may not need to
register it, but the manufacturer shall have to inform the concerned Legal Metrology Officer in
advance about carrying out the repairs:

<!-- page 57 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2699

Provided further that such manufacturer, repairer or dealer, who are holder of licences
under the Haryana Legal Metrology (Enforcement) Rules, 2011, shall have to apply to the
registering authority for grant of registration certificate as per Schedule-II, III or IV, as the case
may be, alongwith registration fee as per Schedule-V within six months of the publication of these
rules in the Official Gazette:
Provided further that the licence fee previously deposited shall be adjusted to the
extent of the remaining period of the licence.
(2) The registering authority, on receipt of an application under sub-rule (1), shall issue
a registration certificate to the manufacturer, repairer, or dealer, as the case may be, in ScheduleVI, VII or VIII respectively, as the case may be.
(3) The fee for alteration in the registration certificate or for issuing a duplicate
registration certificate shall be half of the registration fee as per Schedule-V.
(4) Every repairer registered under these rules shall deposit the amount as per ScheduleIX as a security deposit with the State Government for each registration certificate.
(5) The registering authority shall maintain a register of manufacturers, repairers, and
dealers registered under these rules as per Schedule-X.
(6) Every manufacturer, repairer or dealer registered under these rules shall maintain
such workshop/equipment/ tools/register, etc., in accordance with the terms and conditions of the
registration certificate or any general or special directions and conditions issued by the Controller.
(7) Every registration certificate issued under these rules shall be displayed by the
registered person at a conspicuous place in the premises where the registered person conducts
business.
(8) A registration certificate issued under these rules shall neither be saleable nor
transferable.
(9) Where the business of any registered person under these rules is transferred by
succession, intestate or testamentary, the successor or legal heir of such person, as the case may
be, shall not carry on the business either in his name or in any other name unless, before the expiry
of a period of sixty days from the date of such transfer, the successor or legal heir applies to the
Controller for the issuance of a registration certificate in accordance with these rules:
Provided that nothing contained in this rule shall be deemed to prohibit the successor
or legal heir from carrying on the business as a registered person for the said period of sixty days,
and if they apply for such registration, until the registration certificate is granted by the Controller
or has been issued notice of refusal as per Schedule-XI:
Provided further that where the business of any registered person under these rules is
transferred by sale, gift, lease or otherwise, the transferee or lessee, as the case may be, shall not
carry on such business either in his name or in the name of any other person until they have
obtained a registration certificate for carrying on such business.
6.
(1) A person other than a manufacturer who only repairs weights or measures
manufactured by them, shall apply to the Controller for the issuance of a skill certificate as per
Schedule-XIII along with the fee as per Schedule-XII:

Skill certificate.
[section 23 (2)]

Provided that a person shall not be eligible to obtain a skill certificate for repairing
weights or measures unless he possesses the educational qualifications and technical competence
as specified by the Controller by issuing general or special order in this behalf.
(2) The Controller, after receiving the application under sub-rule (1), shall issue a skill
certificate to the repairer as per Schedule-XIV.
7.
Every manufacturer, repairer or dealer registered under these rules shall maintain records
and registers in Schedule-XV, XVI or XVII as the case may be, and shall submit a quarterly
periodic report/return to the Controller in Schedule-XVIII, XIX or XX, as the case may be, by
the tenth day of the month succeeding each quarter.

Maintenance of
records and
registers.
section 17

<!-- page 58 -->

2700
Suspension and
revocation of
registration.
section 23 (2)

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
8.
(1) The Controller or such other officer authorized by him on his behalf may, if he has
any reasonable cause to believe that the holder of any registration certificate issued under these
rules has made any statement in, or in relation to, any application for the issue of such registration
certificate, which is incorrect or false in any material particular or has contravened any provisions
of law or any provisions of the Act, rules or orders made thereunder, suspend such registration
till the completion of an enquiry against the holder of such registration certificate:
Provided that no such registration certificate shall be suspended unless the holder
thereof has been given a reasonable opportunity of showing cause against the proposed action, as
per Schedule-XXI:
Provided further that where the enquiry referred to in this sub-rule is not
completed within a period of three months from the date of suspension of a registration certificate,
such suspension shall, on the expiry of the period aforesaid, stand revoked.
(2) The Controller or such other officer authorized by him on his behalf may, if he is
satisfied, after making such enquiry, as he may think fit, that the holder of a registration certificate
has made a false or incorrect statement, of the nature referred to in sub-rule (1), or has contravened
provisions of law as referred to in that sub-rule, revoke such registration:
Provided that no such registration shall be revoked unless the holder thereof has been
given a reasonable opportunity of showing cause against the proposed action, as per ScheduleXXI.
(3) Every person whose registration has been suspended shall immediately after such
suspension, stop functioning as registered person and shall not resume business as such until the
order of such suspension has been revoked or stands vacated, as the case may be.
(4) Every registered person whose registration has been revoked shall, within a period of
sixty days from the date of such revocation or within such further period not exceeding three
months from such date, as the Controller or any other officer authorized by him in this behalf
may, on sufficient cause being shown, allow, dispose of the weight or measure which were in his
possession, custody or control on the date of such revocation and in the event of his failure to do
so, the Controller or any other officer authorized by him, in writing, in this behalf, may seize and
dispose of the weight or measure and distribute the proceeds thereof in such manner, as may be
specified by the Controller:
Provided that the registered person whose registration has been revoked, has
preferred an appeal to the Controller or to the State Government, as the case may be, within sixty
days from the date of such revocation and in case any relief has been granted in the appeal so
preferred, no action shall be taken as per sub-rule (4).

Maintenance of
reference,
secondary and
working
standards/standard
balances.
section 24(1).

9.
(1) Reference Standard- Reference standards shall be kept at such place, in such manner
and under such custody as prescribed under the Legal Metrology (National Standards) Rules,
2011.
(2)

(3)

Secondary Standard(a)

secondary standards shall be kept at such place, in such manner and under such
custody as may be specified by the Controller;

(b)

number, type and specifications of secondary standards shall be such as
prescribed in the Legal Metrology (General) Rules, 2011;

(c)

verification of every secondary standard shall be got done in a reference
standard laboratory in the manner and at such periodic intervals as prescribed
under the Legal Metrology (National Standards) Rules, 2011, and if upon such
verification they are found to conform to the standards established by or under
the Act, they may be stamped or a verification certificate may be issued, as the
case may be.

Working Standard(a)

working standards shall be kept under the custody of the Legal Metrology
Officer;

<!-- page 59 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2701

(b)

(4)

(5)

number, type and specifications of working standards shall be such as
prescribed in the Legal Metrology (General) Rules, 2011;
(c) verification of every working standard shall be got done in a reference standard
laboratory or secondary standard laboratory in the manner and at such periodic
intervals as prescribed under the Legal Metrology (National Standards) Rules,
2011, and if upon such verification they are found to conform to the standards
established by or under the Act, they may be stamped or a verification certificate
may be issued, as the case may be.
Secondary Standard Balance(a) set of secondary standard balances shall be maintained at every such place
where secondary standard weights are kept;
(b) number, type and specifications of secondary standard balances shall be such
as prescribed in the Legal Metrology (General) Rules, 2011;
(c) verification of every secondary standard balance shall be done at least once in
a period of twelve months, and if necessary, it shall be adjusted within the limits
of sensitivity and other metrological properties prescribed in the Act by a
reference standard laboratory or the Controller or any other officer authorized
by him in this behalf.
Working Standard Balance(a) set of working standard balances shall be maintained at every such place where
working standard weights are kept;
(b) number, type and specifications of working standard balances shall be such as
prescribed in the Legal Metrology (General) Rules, 2011;
(c) verification of every working standard balance shall be done at least once in a
period of twelve months, and if necessary, it shall be adjusted within the limits
of sensitivity and other metrological properties prescribed in the Legal
Metrology (General) Rules, 2011 by a reference standard laboratory or at any
such place where secondary standards are maintained.

10.
Every such weight or measure which is used or intended to be used in any transaction
or for protection, its physical characteristics, shape, structural details, material, workmanship,
tolerance limits and such other details shall conform to the specifications prescribed under the
Act or the Legal Metrology (General) Rules, 2011.

Physical
characteristics,
shape and structural
details of weight or
measure.
section 24(1).

11. (1) No weight other than bullion weights as specified in the Legal Metrology (General)
Rules, 2011, shall be used in any transaction in bullion including ornaments made of gold, silver,
platinum and palladium etc.
(2) No weight other than carat weights as specified in the Legal Metrology (General)
Rules, 2011, shall be used in any transaction of precious stones.
(3) In every cash memo, invoice, bill or estimate slip, both carat weight units and units
specified by the International System of Units, i.e., kilogram, gram or milligram, as the case may
be, shall be mentioned for quantity in respect of any transaction of precious stones.
(4) In the cash memo, invoice, bill or estimate slip, in respect of every transaction in
bullion, the user of weighing instruments shall mention the net bullion weight and the purity of
precious metals like gold, silver, platinum, palladium etc. according to "carat" or "parts per
thousand", as the case may be, along with separate amounts for precious metal and precious
stones:
Provided that in every transaction relating to the purchase of old precious metals like
gold, silver, platinum, palladium etc. or ornaments of such old precious metals by the user of
weighing instruments from consumers, such user shall mention the purity of such old precious
metals or ornaments of old precious metals, as the case may be, according to "carat" or "parts per
thousand" in the cash memo, invoice, bill or estimate slip before and after the completion of the
transaction, along with net bullion weight and amount separately for precious metal and precious
stones.

Use of bullion
weights, carat
weights etc.
section 24(1).

<!-- page 60 -->

2702

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
(5) Only non-automatic weighing instruments of Class A or Class B beam scale or High
Accuracy Class (Class-II) or Special Accuracy Class (Class-A) specified in the Legal Metrology
(General) Rules, 2011, which have a verification scale interval of one milligram or less, shall be
used in any transaction specified in sub-rules (1) and (2).
(6) The Legal Metrology Officer may inspect and test the purity of any precious metal
sold in any transaction in bullion according to "carat" or "parts per thousand", as the case may be,
using such method as specified by the Controller. For the purpose of inspection and testing, the
Legal Metrology Officer may be supplied with such instruments by the Controller as may be
necessary.

Verification and
inspection of weight
or measure.
section 24(1).

12. (1) Every person using any weight or measure in any transaction or for protection shall
present such weight or measure for verification on or before the date on which verification is
required, at the office of the verifying authority in whose jurisdiction it is used, or at such other
place as the verifying authority may specify in this behalf:
Provided that such manufacturer who has been approved as a Government Approved
Test Centre by the Central Government or State Government shall be eligible for self-verification
of weights or measures manufactured by him:
Provided further that where any weight or measure is of such nature that it cannot be
moved or should not be moved from its place, the person using such weight or measure shall
report to the verifying authority at least thirty days before the date on which verification is
required.
(2) Where any weight or measure is of such nature that it cannot be moved or should not
be moved from its place, the verifying authority shall take necessary steps to verify such weight
or measure at the place of its location.
(3) For the verification of weights or measures specified in sub-rule (2), the user shall
provide such facilities as may be specified by the Controller.
(4) Every weight or measure presented for verification shall be complete in itself, which
also includes the seal.
(5) Every weight or measure shall be verified in a clean condition, and if necessary, the
verifying authority shall require the owner or user to make necessary arrangements for this
purpose.
(6) Any Legal Metrology Officer may, as often as possible, visit any premises within his
jurisdiction to inspect and test any pre-packed commodity, weight or measure which is being
used, intended to be used, or likely to be used in any transaction or for protection. The Legal
Metrology Officer may use test weights or measures, standard weights or measures, working the
purpose of verification or inspection.
(7) Before the verification of any weight or measure, the user shall present the model
approval certificate issued by the Central Government to the Verifying Authority. The user of
such weight or measure shall maintain a copy of such model approval certificate. The Verifying
Authority shall also include the number of such model approval certificate in the verification
certificate as prescribed as per Schedule-XXII.
(8) The validity of the certificate of verification and the periodic intervals for verification
of any weight or measure shall be such as prescribed in the Legal Metrology (General) Rules,
2011.

Stamping of weight
or measure.
section 24(1).

13. (1) The verifying authority, if satisfied after verification that such weight or measure
conforms to the standards established by or under the Act, shall affix a stamp of uniform design
issued by the competent authority of the Central Government or the State Government, as the
case may be, on every weight or measure. For administrative purposes, this stamp shall indicate
the number allotted to the verifying authority by whom it is stamped:
Provided that if due to the size or nature of any weight or measure it is not desirable
or practicable to affix a stamp on it, the verifying authority shall take such action as directed in
writing by the Controller by general or special order.

<!-- page 61 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2703

(2) The verifying authority shall mark the year of stamping and its quarter on every
verified weight or measure, except when it is impracticable to do so due to the size or nature of
such weight or measure.
Explanation: A year shall consist of four quarters, where the first quarter shall be of the months
of January, February, and March which shall be marked as 'A' , the second quarter shall be of the
months of April, May, and June which shall be marked as 'B' , the third quarter shall be of the
months of July, August, and September which shall be marked as 'C', and the fourth quarter shall
be of the months of October, November, and December which shall be marked as 'D'.
(3) On completion of verification and stamping, the verifying authority shall issue a
certificate of verification in the format specified as per Schedule-XXII:
Provided that where verification has been done by a Government Approved Test
Centre, the verification mark and certificate shall be such as prescribed in the Legal Metrology
(Government Approved Test Centres) Rules, 2013 and the rules made by the State Government
in this behalf from time to time.
(4) Any weight or measure rejected upon verification shall be returned to the user for
necessary repairs, and after repair, such weight or measure may be accepted afresh for verification
upon payment of the verification fee.
(5) Where a certificate of verification is lost, destroyed, or defaced, the holder of such
certificate shall immediately apply to the verifying authority who issued the certificate for the
issuance of a duplicate certificate of verification, in the manner specified by the Controller, along
with a fee which shall be five hundred rupees or equivalent to one-tenth of the verification fee
chargeable at the time of verification, whichever is higher.
(6) Upon receipt of an application under sub-rule (5), the verifying authority shall issue
a duplicate (copy) certificate of verification to the applicant.
14. (1) In the case of a Legal Metrology Officer, the fee payable for the verification and/or
stamping of any weight or measure shall be as per Schedule-XXIII. In the case of a Government
Approved Test Centre (GATC), the fee payable for the verification and/or stamping of any weight
or measure shall be in accordance with the Legal Metrology (Government Approved Test Centre)
Rules, 2013, or as per the rules prescribed by the State Government from time to time in this
regard.
(2) Notwithstanding anything contained in sub-rule (1), if at the request of the user, the
verification of a weight or measure is required to be carried out at a location other than the office
of the verifying authority, then:
In the case of a Legal Metrology Officer, the user shall pay one and a half times (1.5x)
the fee as per Schedule-XXIII for the verification and/or stamping of such weight or measure,
and shall also provide all other necessary facilities required for the said verification and stamping.
In the case of a Government Approved Test Centre, the fee payable by the user for
the verification and/or stamping of any weight or measure shall be as prescribed under the Legal
Metrology (Government Approved Test Centre) Rules, 2013, or the rules prescribed by the State
Government from time to time in this regard:
Provided that if the user fails to provide the necessary facilities required for the
verification and/or stamping of the weight or measure, the verifying authority shall charge the
user transportation and handling charges as per Schedule-XXIV, the Legal Metrology
(Government Approved Test Centre) Rules, 2013, or the rules framed by the State Government
from time to time in this regard:
Provided further that no additional fee shall be charged for the verification and/or
stamping of the following weights or measures in situ (on-site), namely:(i)
vehicle tanks for petroleum products and other liquids; measuring systems for
liquids other than water (such as fuel dispensers, liquefied petroleum gas (LPG)
dispensers, milk dispensers); compressed natural gas (CNG) dispensers; nonautomatic weighing instruments such as weighbridges (Dharamkanta),
platform machines, crane scales; automatic gravimetric filling instruments;
automatic rail-weighbridges; automatic discontinuous totalizing weighing
instruments; and such other weights or measures which cannot or should not
be moved from their location.

Fees for verification
and/or stamping
section 24 (1).

<!-- page 62 -->

2704

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
(ii)

weights or measures located within the premises of a manufacturer or dealer of
such weights or measures.

(3) If, after the expiry of the validity of the verification and/or stamping certificate, a
weight or measure is presented to the verifying authority for re-verification and/or re-stamping,
the fee charged for such re-verification and/or re-stamping for the first quarter, second quarter,
third quarter, fourth quarter, or any part thereof, shall be one and a half times (1.5x), two
times (2x), two and a half times (2.5x), and three times (3x) the fee as per Schedule-XXIII
respectively, and shall continue to be charged progressively in the same manner.
(4) If any weight or measure is found to be incorrect/defective at the time of verification
or inspection, the concerned person shall be informed of the defects found in the weight or
measure. The weight or measure shall be returned to them to rectify the defects and adjust it
within a period not exceeding eight (8) days. After the necessary adjustments are made, and upon
being found correct, such weight or measure shall be verified and/or stamped upon payment of
the standard fee as per Schedule-XXIII.
Collection of fees
and deposition into
the treasury.
section 24(1).

15. (1) The fee collected from any person by the Legal Metrology Officer for verification
and/or stamping shall be deposited into the Government Treasury under the appropriate
accounting head. The officer shall issue a receipt to the concerned person in the format as per
Schedule-XXV, forward a copy of such receipt to the Controller, and retain one copy in the
official records.
(2) The Legal Metrology Officer shall maintain a register for fees and charges in the
format as per Schedule-XXVI, in which the details of the fees and charges collected day-to-day
shall be entered.

Validity of duly
verified and/or
stamped weight or
measures.
section 24(1)

16. (1) Any weight or measure, which has been duly verified and/or stamped under these
rules, shall be deemed to conform to the standards established by or under the Act at every place
within the State of Haryana, unless it is found upon inspection or testing that such weight or
measure no longer conforms to the standards established by or under the Act.
(2) A weight or measure, which is duly verified and/or stamped under the Act, or is
deemed to have been verified and/or stamped, shall not require re-verification and/or re-stamping
merely by reason of the fact that it is being used at any other place within the State of Haryana
different from the place where it was originally verified and stamped:
Provided that where a verified weight or measure installed at one location is
dismantled and re-installed at another location, such weight or measure shall not be brought into
use until it has been duly re-verified and/or re-stamped, or a certificate of verification and/or
stamping has been issued, as the case may be, notwithstanding that the periodic verification and/or
stamping of such weight or measure has not become due:
Provided further that where a weight or measure has been repaired at a place/location
other than the place where it is to be used, the repairer, before delivering such weight or measure
duly repaired by him to the user, shall produce it for verification and/or stamping before the Legal
Metrology Officer under whose jurisdiction it is to be brought into use, notwithstanding that the
periodic verification and/or stamping of such weight or measure has not become due.

Supply of working
standards,
secondary
standards,
equipment, etc.

17. (1) The Legal Metrology Officer shall be provided with working standard weights or
measures/secondary standard weights or measures, test weights or measures, working standard
balances, secondary standard balances, and such other equipment, including other weight or
measure instruments, as may be approved by the Controller, from time to time.

section 24(1)

(2) Each Legal Metrology Officer shall be provided with such dies, punches, paper seals,
stickers, and other equipment as may be necessary for affixing verification stamps, the design and
quantity of which shall be approved by the Controller.
(3) Each Legal Metrology Officer shall be provided with punches of an appropriate size
of an octagon star die for obliterating stamps.

<!-- page 63 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
18. (1) Every person using a beam scale (hanging scale) in any transaction within his
premises shall suspend the scale from a stand or hook by a chain:

2705
Use of weights,
measures, etc.
section 24(1)

Provided that the said sub-rule shall not apply to an itinerant vendor (mobile vendor).
(2) Every weight or measure shall be used in a clean condition and under proper lighting
arrangements.
(3) No weight or measure, which has been duly verified and/or stamped, shall be
dismantled or removed from its place without the written permission of the Controller or the
concerned Legal Metrology Officer.
(4) All components, parts, or points of a weight or measure, which are susceptible to
fraudulent manipulation or tampering, shall be securely sealed after verification, wherever
applicable.
(5) To ensure proper testing of the accuracy of a weighing instrument, the user shall
maintain, at the location of each measuring instrument, duly verified and/or stamped weights
equal to one-tenth of the capacity of the instrument or one thousand kilograms, whichever is less.
The user shall test the weighing instrument with these weights every day to ensure correct weight.
In the case of any error exceeding the permissible limits, the user shall stop using such weighing
instrument and inform the concerned Legal Metrology Officer for its re-verification and/or restamping. A consumer may also check the accuracy of the weighing instrument:
Provided that the Controller may specify the total number of verified and/or stamped
weights to be maintained in business premises where the number of weighing instruments is more
than one.
(6) To ensure proper delivery from a retail petrol/diesel unit, the retail dealer shall keep
a five litres capacity measure verified by the concerned Legal Metrology Officer in their pump
premises and shall daily check the discharge of petrol/diesel from each nozzle to ensure correct
delivery. In the case of short delivery of petrol/diesel from the nozzle of any petrol/diesel unit,
the retail dealer shall immediately stop delivery of petrol/diesel from the said nozzle and inform
the concerned Legal Metrology Officer for re-verification of that petrol/diesel unit.
(7) The user shall utilize a test verification apparatus for all CNG, LNG, LPG, Hydrogen,
and other gaseous fuel dispensers and shall also comply with the procedure laid down in the Legal
Metrology (General) Rules, 2011, the Legal Metrology (Government Approved Test Centre)
Rules, 2013, and the rules to be framed by the State Government in this regard.
(8) The Controller or the concerned Legal Metrology Officer may require the production
of any document, other record, or information relating to any weight or measure or pre-packaged
commodity from the person having custody of such weight or measure or pre-packaged
commodity and the said person shall comply with such demand.
(9) If the user intends to sell any weight or measure owned and used by him, he shall
obtain the permission of the Controller or the concerned Legal Metrology Officer prior to selling
the said weight or measure.
(10)
Every trader using any weight or measure in any transaction shall issue a bill
or receipt to every consumer, showing the details of the quantity of goods sold or purchased and
the amount charged for the goods.
19. The compounding amount for the compounding of offences committed under the Act or
the rules made thereunder shall be as per Schedule-XXVIII. The compounding amount shall be
deposited into the government treasury under the appropriate "Head of Account":
Provided that any person who violates the provisions of the Act or the rules made
thereunder shall be issued an improvement notice as per Schedule-XXVII in respect of the said
violation, wherever applicable.
20. An appeal against any action taken or any order passed under the provisions of this Act or
these rules shall be made to the concerned appellate authority in Schedule-XXIX, along with the
fee as per Schedule-XXX.

Compounding
amount for
compounding of
offences.
section 48(1) and
section 53(2)(f)

Appeal.
section 50

<!-- page 64 -->

2706

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

Penalty.
section 53(3)

21. Whoever violates any provision of these rules, for the violation of which no penalty has
been provided in the Act, shall be liable to such penalty which may extend to one lakh rupees. In
addition to the above, suspension or revocation of the registration certificate or verification
certificate, as the case may be, shall also be carried out.

Amendment of
Schedules.

22.

The State Government may, by order, amend the Schedules appended to these rules.

Repeal and savings.

23.

The Haryana Legal Metrology (Enforcement) Rules, 2011 are hereby repealed:

Provided that anything done or any action taken under the rules so repealed shall be deemed
to have been done or taken under the corresponding provisions of these rules.

<!-- page 65 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2707

SCHEDULE-I
[see rule 3]
A

B

Use of weight, measure or number in commodities except specified in part B (other than packaged
commodities)
(a) weight, if the commodity is sold as solid, semi-solid, viscous or a mixture of solid and liquid;
(b)
length, if the commodity is sold by linear measure;
(c)
area, if the commodity is sold by area measure;
(d)
volume, if the commodity is sold as liquid or sold by cubic measure; or
(e)
number, if the commodity is sold by number.
The following commodities (other than packaged commodities) may be sold by weight, measure or
number as shown against the commodity:
Sr. No.
Commodity
Whether declaration to be expressed in
terms of weight, measure or number or
two or more of them.
1
Aerosol products
Weight
2
Acids in liquid form
Weight or volume
3
Autogas (Liquid Petroleum Gas for automobiles)
Volume
4
Compressed or liquefied gas (but not liquefied Weight and equivalent volume at stated
petroleum gas)
temperature and pressure.
5
Compressed Natural Gas
Weight
6
Liquid Nitrogen
Weight or Volume
7
Liquefied Natural Gas
Weight
8
Butter (including peanut butter), Cheese, curd, ghee
Weight
9
Electric cables, Electric wire, Fencing wire
Length or Weight
10
Fruits and vegetables
Number or Weight
11
Furnace oil
Weight or Volume
12
Hair oil (un-perfumed)
Weight or Volume
13
Heavy residual fuel oil
Weight
14
Honey, malt extract, golden syrup treacle, molasses
Weight
15
Ice cream and other similar frozen products
Weight
16
Industrial diesel fuel
Volume
17
Linseed oil and other vegetable oils
Weight or Volume
18
Liquid chemicals
Weight or Volume
19
Liquid petroleum gas
Weight
20
Nails, wood screws
Number or Weight
21
Paint (other than paste paints or solid paint), varnish Volume
and varnish stairs, enamels
22
“Papad”
Number and Weight
23
“Samosa”, “Kachori”, “Golgappa”, “Tikki”, “Dosa”, Number
“Idli”, “Litti”
24
Tea, Coffee, Juice, Drinks (including soft drinks)
Volume or Number (With declared
volume)
25
Salad, Cooked Daal/Vegetable Dishes/Biryani
Weight or Number (With declared
weight)
26
Paste paint, solid paint
Weight
27
Plastic or ceramic or metal goods
Weight or Number
28
Sweets
Weight or Number
29
Savouries,
Weight
30
Popcorn, Sweet Corn
Weight or Number (With declared
weight)
31
Readymade garments
Number and size
32
Sauces, all kinds
Weight
33
Steel and Iron
Weight (With dimensions)
34
Textiles
Weight or Length
35
Tyres and tubes
Number
36
Yarn
Weight or Length of Yarn

<!-- page 66 -->

2708

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-II
[see rule 5 (1)]
APPLICATION FOR REGISTRATION AS MANUFACTURER
To
---------------------------------------------------------------------------------------------------------------------------

Sr.
No.

Particulars of the item

1

Category of the Applicant (Individual/ HUF/ Firm/
Company/ Society/ Dept./ Trust/ Others)

2

Name of the Applicant
(fill name of Firm/ Company etc. in case of HUF/ Firm/
Company/ Society/ Dept./ Trust/ Others)

3

a)
b)
c)

Address of the Applicant with proof.
Address of the Manufacturing unit (if the address of
the registered office is different)
Whether premises are owned/ rented/ taken on lease
(duly supported by documents).

4

Date of Establishment (in case of Firm/ Company/ Society/
Dept./ Trust/Others)

5

Name(s), Aadhar Number and address(es) with proof, of
Individual/ Proprietor/ Partners/ Director(s)/ Member(s), as
applicable

6

a)
b)
c)

Registration Number of VAT/GST
Registration Number of Professional Tax, if
applicable
PAN/TAN details

7

Nature of manufacturing or other activities at the
manufacturing unit for which registration is applied.

8

Categories of weight or measure proposed to be
manufactured (details of each Category to be given):
(a) Weights of all types
(b) Capacity Measures, Length Measures etc.
(c) Beam Scales, Counter Scale etc.
(d) Non-Automatic Weighing Instruments
(e) Automatic Weighing Instruments
(f) Volumetric Measuring Instruments
(g) Others {As per Schedule-X of these Rules and the
Schedules appended to the Legal Metrology
(General) Rules, 2011}

9

The number of persons employed/ proposed to be
employed.
(i) Skilled
(ii) Other than Skilled

To be filled by the
Applicant

Comments of the
Legal Metrology
Officer

<!-- page 67 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
10

a)
b)

The monogram or trademark intended to be imprinted
on weight or measure to be manufactured.
Whether the trademark is registered or not? If yes,
give details.

11

Details of machinery, tools, accessories used for
manufacturing of Weight or Measure.

12

Availability of electricity connection. Give details.

13

Have you previously applied for a Manufacturer’s License/
Registration Certificate, either in this State or elsewhere? If
yes, give details.

14

(a)

(b)
15

2709

Details of Model Approval Certificates obtained
from Government of India for the item(s) proposed
to be manufactured,
Whether the item(s) proposed to be manufactured will
be sold within the State or out of the State or both.

Details of registration fee deposited (as specified in the
Schedule-X):
(a) Amount (₹)
(b) GRN No.
(c) CIN No.
(d) Date
Declaration by the applicant

It is hereby declared that I/ We have read the Legal Metrology Act, 2009, the Haryana Legal Metrology
(Enforcement) Rules, 2026, and any other Rules made under the Act. I/We agree to abide by all the provisions of the
Act and the Rules aforementioned, and also the administrative orders and instructions issued or to be issued
thereunder.
All the information furnished above is true and correct to the best of my/our knowledge and nothing herein
has been concealed. In case the above facts/information are found to be false or incorrect at any stage, I/we will be
liable to face any action as per law.

Place: …………………………
Date: …………………………

Signature, Name and Designation
of the Authorized Signatory

<!-- page 68 -->

2710

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-III
[see rule 5 (1)]
APPLICATION FOR REGISTRATION AS REPAIRER
To
----------------------------------------------------------------------------------------------

Sr.
No.

Particulars of the item

1

Category of the Applicant (Individual/ HUF/ Firm/
Company/ Society/ Dept./ Trust/ Others)
Name of the Applicant
(fill name of Firm/ Company etc. in case of HUF/ Firm/
Company/ Society/ Dept./ Trust/ Others)
a) Address of the Applicant with proof.
b) Address of the Workshop/Repairing unit (if the address
of the registered office is different)
c) Whether premises are owned/ rented/ taken on lease,
(duly supported by documents).
Date of Establishment (in case of Firm/ Company/ Society/
Dept./ Trust/ Others)
Name(s), Aadhar Number and address(es) with proof, of
Individual/ Proprietor/ Partners/ Director(s)/Member(s), as
applicable
a) Registration Number of VAT/GST
b) Registration Number of Professional Tax, if applicable
c) PAN/TAN details
Categories of weight or measure proposed to be repaired
(details of each Category to be given):
(a) Weights of all types
(b) Capacity Measures, Length Measures etc. {other than
items mentioned at Sr. No.(g) & (h) below}
(c) Beam Scales, Counter Scale etc.
(d) Non-Automatic Weighing Instruments Class-I & II
{other than items mentioned at Sr. No.(i) below}
(e) Non-Automatic Weighing Instruments Class-III & IIII
{other than items mentioned at Sr. No.(i) below}
(f) Automatic Weighing Instruments
(g) Tank Lorry
(h) Storage Tanks
(i) Weigh Bridge
(j) Volumetric Measuring Instruments
(k) Others {As per Schedule-X of these Rules and the
Schedules appended to the Legal Metrology (General)
Rules, 2011}
The number of persons employed/ proposed to be employed.
(i) Skilled

2

3

4
5

6

7

8

To be filled by
the Applicant

Comments of the
Legal Metrology
Officer

<!-- page 69 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

9

10
11
12
13
14

15

16

2711

(ii) Other than Skilled
Area of operation:
a) Centre (Area of the Legal Metrology Officer in whose
jurisdiction, the workshop of the Repairer is situated)
b) Whole District (if there are more than one Centres in a
District)
c) Whole State
Details of Certificate of Skill issued by the Controller
Details of machinery, tools, accessories used for repairing of
Weight or Measure.
Availability of electricity connection. Give details.
Have you sufficient stock of verified Test Weights and
Measures etc.? Give details.
Have you previously applied for Repairer’s License/
Registration Certificate, either in this State or elsewhere? If
yes, give details.
Details of Skilled Workers
Sr. Name
& Name of the field Number
&
No. Father’s name of skill
Date
of
of the Skilled
Certificate of
Worker
Skill
Details of registration fee deposited (as specified in the
Schedule-X):
(a) Amount(₹)
(b) GRN No.
(c) CIN No.
(d) Date

Declaration by the applicant
It is hereby declared that I/ We have read the Legal Metrology Act, 2009, the Haryana Legal Metrology
(Enforcement) Rules, 2026, and any other Rules made under the Act. I/We agree to abide by all the provisions of the
Act and the Rules aforementioned, and also the administrative orders and instructions issued or to be issued
thereunder.
All the information furnished above is true and correct to the best of my/our knowledge and nothing herein
has been concealed. In case the above facts/information are found to be false or incorrect at any stage, I/we will be
liable to face any action as per law.
Place: …………………………
Date: …………………………

Signature, Name and Designation
of the Authorized Signatory

<!-- page 70 -->

2712

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-IV
[see rule 5 (1)]
APPLICATION FOR REGISTRATION AS DEALER

To
--------------------------------------------------------------------------------------------------------------------------Sr.
No.

Particulars of the item

1

Category of the Applicant (Individual/ HUF/ Firm/ Company/
Society/ Dept./ Trust/ Others)

2

Name of the Applicant
(fill name of Firm/ Company etc. in case of HUF/ Firm/ Company/
Society/ Dept./ Trust/ Others)

3

a)
b)
c)

Address of the Applicant with proof.
Address of the Shop/Establishment (if the address of the
registered office is different)
Whether premises are owned/ rented/ taken on lease (duly
supported by documents).

4

Date of Establishment (in case of Firm/ Company/ Society/ Dept./
Trust/Others)

5

Name(s), Aadhar Number and address(es) with proof, of Individual/
Proprietor/ Partners/ Director(s)/Member(s) as applicable

a)
6
b)
c)

Registration Number of VAT/GST
Registration Number of Professional Tax, if applicable
PAN/TAN details

7

Categories of weight or measure proposed to be sold (details of
each Category to be given):
(a) Weights
(b) Capacity Measures, Length Measures etc.
(c) Beam Scales, Counter Scale etc.
(d) Non-Automatic Weighing Instruments
(e) Automatic Weighing Instruments
(f) Volumetric Measuring Instruments
(g) Others {As per Schedule-X of these Rules and the Schedules
appended to the Legal Metrology (General) Rules, 2011}

8

Do you intend to sale Weight or Measure etc., brought/imported
from places outside the State/Country?
If so, indicate source of supply and provide:
(a) Details of Manufacturer's Trademark/ Monogram and
Registration Certificate Details.
(b) Registration Number of Importer of Weight or Measure, if any.
(c) Details of Approval of Model by Central Government.

9

Have you previously applied for a Dealer’s License/Registration
Certificate, either in this State or elsewhere? If yes, give details.

To be
filled by
the
Applicant

Comments of
the Legal
Metrology
Officer

<!-- page 71 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
10

2713

Details of registration fee deposited (as specified in the ScheduleX):
(a) Amount(₹)
(b) GRN No.
(c) CIN No.
(d) Date
Declaration by the applicant

It is hereby declared that I/ We have read the Legal Metrology Act, 2009, the Haryana Legal Metrology
(Enforcement) Rules, 2026, and any other Rules made under the Act. I/We agree to abide by all the provisions of the
Act and the Rules aforementioned, and also the administrative orders and instructions issued or to be issued
thereunder.
All the information furnished above is true and correct to the best of my/our knowledge and nothing herein
has been concealed. In case the above facts/information are found to be false or incorrect at any stage, I/we will be
liable to face any action as per law.
Place: …………………………
Date: …………………………

Signature, Name and Designation
of the Authorized Signatory

<!-- page 72 -->

2714

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-V
[see rule 5(1) and 5(3)]
Registration Fees for Manufacturers, Repairers & Dealers of Weights & Measures.
Amount in (₹)

Sr.
No.

Registration Fee

1.

For Manufacturer

50000/- for each category/Model of Weight or Measure

2.

For Repairer

i)

20000/- for each category/ accuracy class of Weight or Measure for a
Centre

ii)

50000/- for each category/ accuracy class of Weight or Measure for a
District where there are more than one centres

iii)

150000/- for each category/ accuracy class of Weight or Measure for
the State

3.

For Dealer

20000/- for all categories of Weight or Measure

<!-- page 73 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2715

SCHEDULE-VI
[see rule 5 (2)]
REGISTRATION CERTIFICATE TO MANUFACTURE WEIGHT OR MEASURE
No………………….../ Year :………………..
1.

The Certificate of Registration is hereby granted to………………………… {(name and address of
registered person(s)} to Manufacture the following categories of Weight or Measure:-

Sr. No.

the

Description of Weight or Measure

2.

The Registration Certificate is valid only for the applicant referred above in respect of their
manufacturing unit located at ………………………………………………………………………….….

3.

The Manufacturer shall comply with the terms and conditions noted below. In case of failure to do so, this
Registration Certificate is liable to be revoked.

4.

The trademark/monogram being used by the Manufacturer is as under…………………………
TERMS AND CONDITIONS OF REGISTRATION:

A.

The registered person(s), in whose favour this Registration Certificate is issued, shall. -

(a) comply with all the relevant provisions of the Act and Rules made thereunder as amended from
time to time;

(b) not encourage or countenance any infringement of the provisions of the Act or the Rules made
thereunder as amended from time to time;

(c) exhibit this Registration Certificate in some conspicuous part of the premises to which it relates;
(d) comply with any general or special directions that may be given by the Controller;
(e) stop functioning as Manufacturer and shall not resume business as such until the suspension, if
any, of this registration stands vacated;

(f)

surrender the Registration Certificate in the event of closure of business and/ or revocation of
Registration Certificate;

(g) present the weight or measure, as the case may be, manufactured and meant for use within the
State or outside the State, to the Verifying Authority in whose jurisdiction it is to be put into
use or as may be directed by the Controller, for verification and stamping before sale.

B.

Any change in the constitution of the Registered Person(s) other than the individual shall be reported
to the Registering Authority immediately but not later than 30 days.

C.

Nothing in this Rule shall confer on the Registered Person(s) any assignable or transmissible right.

D.

Every condition prescribed after the issue of this Registration Certificate shall be binding on the
person(s) to whom the Registration Certificate has been granted.

Note: In case of the registered person(s) other than an individual, the terms and conditions mentioned above
shall also be binding on all persons having any interest in the business of such registered person(s).

Place ………………..
Date ………………..

(Signature)
Name & Designation of the Registering Authority
(With Seal)

<!-- page 74 -->

2716

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

SCHEDULE-VII
[see rule 5 (2)]
REGISTRATION CERTIFICATE TO REPAIR WEIGHT OR MEASURE
No………………….../ Year :………………..
1.
The Certificate of Registration is hereby granted to………………………… {(name and address of the
registered person(s)} to Repair the following categories of weight or measure:Sr. No.
2.
3.
4.
5.

Description of Weight or Measure

The Registration Certificate is valid only for the applicant referred above in respect of their Workshop/
Repairing unit located at ……………….
The Repairer shall comply with the terms and conditions noted below. In case of failure to do so, this
Registration Certificate is liable to revoked.
The Registered Person is authorized to repair weight or measure of the description mentioned at Sr. No. 1
above in the area(s) mentioned below: …….
Details of Skilled Worker(s) and Certificate of Skill:Sr.
No.

Name & Father’s name of the Name of the field Number & Date of Certificate
Skilled Worker
of skill
of Skill

TERMS AND CONDITIONS OF REGISTRATION:
A. The registered person(s), in whose favour this Registration Certificate is issued, shall. (a) comply with all the relevant provisions of the Act and Rules made thereunder as amended from
time to time;
(b) not encourage or countenance any infringement of the provisions of the Act or the Rules made
thereunder as amended from time to time;
(c) exhibit this Registration Certificate in some conspicuous part of the premises to which it relates;
(d) comply with any general or special directions that may be given by the Controller;
(e) stop functioning as Repairer and shall not resume business as such until the suspension, if any, of
this registration stands vacated;
(f) surrender the Registration Certificate in the event of closure of business and/ or revocation of
Registration Certificate;
(g) present the weight or measure, as the case may be, duly serviced/repaired to the Verifying Authority
in whose jurisdiction it is to be put into use or as may be directed by the Controller, for verification
and stamping before delivery to the user, even before the due date of next verification.
B. The repairing work shall be done by the Skilled Worker(s) as prescribed by the Rules.
C. Any change in Skilled Worker(s) shall be reported to the Registering Authority immediately but not later
than 30 days.
D. Any change in the constitution of the Registered Person(s) other than the individual shall be reported to
the Registering Authority immediately but not later than 30 days.
E. Nothing in this Rule shall confer on the Registered Person(s) any assignable or transmissible right.
F. Every condition prescribed after the issue of this Registration Certificate shall be binding on the
person(s) to whom the Registration Certificate has been granted.
G. The Controller may cause a coordinated programme to be undertaken, at such place and in such manner,
as he may think fit, for the establishment of maximum repairing charges for a weight or measure. The
repairer shall abide by such ceiling of maximum repairing charges.
Note: In case of the registered person(s) other than an individual, the terms and conditions mentioned above
shall also be binding on all persons having any interest in the business of such registered person(s).
Place ………………..
Date ………………..

(Signature)
Name & Designation of the Registering Authority
(With Seal)

<!-- page 75 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2717

SCHEDULE-VIII
[see rule 5 (2)]
REGISTRATION CERTIFICATE FOR DEALER OF WEIGHT OR MEASURE
No………………….../ Year :………………..
1.

The Certificate of Registration is hereby granted to………………………… {(name and address of the registered
person(s)} to deal in the following categories of weight or measure:Sr. No.

Description of Weight or Measure

2.

The Registration Certificate is valid only for the applicant referred above in respect of their business premises
located at ……………….

3.

The dealer shall comply with the terms and conditions noted below. In case of failure to do so, this Registration
Certificate is liable to be revoked.
TERMS AND CONDITIONS OF REGISTRATION:
A.

The registered person(s), in whose favour this Registration Certificate is issued, shall, -

a)

comply with all the relevant provisions of the Act and Rules made thereunder as amended from time
to time;

b)

not encourage or countenance any infringement of the provisions of the Act or the Rules made
thereunder as amended from time to time;

c)
d)
e)

exhibit this Registration Certificate in some conspicuous part of the premises to which it relates;

f)

surrender the Registration Certificate in the event of closure of business and/ or revocation of
Registration Certificate;

g)

present the weight or measure, as the case may be, to the Verifying Authority in whose jurisdiction it
is to be put into use or as may be directed by the Controller, before sale;

h)

not sell or offer, expose or possess for sale any non-standard weight or measure.

comply with any general or special directions that may be given by the Controller;
stop functioning as dealer and shall not resume business as such until the suspension, if any, of this
registration stands vacated;

B.

Any change in the constitution of the Registered Person(s) other than the individual shall be reported to the
Registering Authority immediately but not later than 30 days.

C.

Nothing in this Rule shall confer on the Registered Person(s) any assignable or transmissible right.

D.

Every condition prescribed after the issue of this Registration Certificate shall be binding on the person(s)
to whom the Registration Certificate has been granted.

Note: In case of the registered person(s) other than an individual, the terms and conditions mentioned above shall
also be binding on all persons having any interest in the business of such registered person(s).

(Signature)
Place ………………..

Name & Designation of the Registering

Date ………………..

Authority
(With Seal)

<!-- page 76 -->

2718

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-IX
[see rule 5(4)]
Security to be deposited by the registered Repairer.
Description

Amount in (₹)

Security Deposit for Repairer

100000/- for each category/ accuracy class of Weight or Measure for a Centre

<!-- page 77 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)

2719

SCHEDULE-X
[see rule 5(5)]
Register of Registered Manufacturers, Repairers and Dealers of Weight or Measure
Number and
Date of
Registration
Certificate

1

Name & address
of the
Manufacturer/
Repairer/ Dealer

2

Location of
factory/

Location of
workshop/

manufacturing
unit of the
Manufacturer

repairing unit
of the
Repairer

3

4

Articles to be
manufactured/
repaired/ sold

5

Trademark/
monogram to
be used

6

Number and Date of
orders regarding
suspension/
revocation of
Registration
Certificate

7

i)

Date of filing of
appeal, if any.

ii) Date of decision in
appeal

Signature
of the
Registering
Authority

Remarks,
if any

9

10

iii) Appeal accepted or
rejected.

8

Note: Column no. 3 & 4 do not pertain to Dealers, column no. 6 does not pertain to Repairers and Dealers.

<!-- page 78 -->

2720

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-XI
[see rule 5(9)]
NOTICE OF REFUSAL TO GRANT REGISTRATION CERTIFICATE
ON SUCCESSION/TRANSFER

No. /RA(LM)……………….
Date……………………….
To
Name of the applicant ...................................................................
Address ...........................................................................................
Subject:

Request for transfer of the Registration Certificate.

Reference-

Your application for transfer of Registration Certificate No……………Dated………. issued in
favour of………………………………

You are hereby informed that your application for the aforementioned request for transfer of the
registration in your name or in the name of the person in whose favour the aforesaid request has been made, has been
examined in the light of the applicable sections/rules of the Act/Rules, and the same has been declined on the following
grounds:

Sr. No.
(1)

Ground(s) for refusal/ rejection of the request
(2)

Relevant Section(s)/ Rule(s) of the Act/ Rules/
Condition(s) of Registration Certificate
(3)

You are therefore, directed to stop the business permissible under the abovementioned Registration
Certificate immediately, failing which appropriate action as per law shall be initiated against you.

Signature, Name & Designation
of Registering Authority, with stamp.

<!-- page 79 -->

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-XII
[see rule 6(1)]
Application Fee for Certificate of Skill
Description

Amount in (₹)

Application Fee for Certificate of Skill

1000/- for each application

.

2721

<!-- page 80 -->

2722

HARYANA GOVT. GAZ. (EXTRA.), OCT. 8, 2026 (ASVN. 16, 1948 SAKA)
SCHEDULE-XIII
[see rule 6(1)]

APPLICATION FOR ISSUE OF CERTIFICATE OF SKILL
To
The Controller Legal Metrology, Haryana.
Sr.
No.

Particulars of the item

1

Name and address of the Applicant

2

a) Aadhar Number
b) PAN

3

Educational Qualification

4

Technical Qualification, if any.

5

Experience in the field for which the Certificate of Skill
is applied (Proof to be attached).

6

Categories of weight or measure for which Certificate
of Skill is applied. (details of each Category to be
given):
(a) Weights of all types
(b) Capacity Measures, Length Measures etc.
{other than items mentioned at Sr. No.(g) & (h)
below}
(c) Beam Scales, Counter Scale etc.
(d) Non-Automatic Weighing Instruments ClassI & II {other than items mentioned at Sr. No.(i)
below}
(e) Non-Automatic Weighing Instruments ClassIII & IIII {other than items mentioned at Sr.
No.(i) below}
(f) Automatic Weighing Instruments
(g) Tank Lorry
(h) Storage Tanks
(i) Weigh Bridge
(j) Volumetric Measuring Instruments
Others {As per Schedule-X of these Rules and the
Schedules appended to the Legal Metrology (General)
Rules, 2011}

7

Have you previously applied for/ been granted the
Certificate of Skill, either in this State or elsewhere? If
yes, give details.

To be filled by
the Applicant

Comments of the Legal
Metrology Officer
