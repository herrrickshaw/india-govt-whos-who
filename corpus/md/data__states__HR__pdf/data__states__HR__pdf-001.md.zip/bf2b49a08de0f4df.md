---
doc_id: "bf2b49a08de0f4df"
source_url: "https://cdnbbsr.s3waas.gov.in/s308f2ec55c27be23eca76762a1ceeb85a/uploads/2026/02/202602031846877862.pdf"
ministry: "Fisheries Department, Haryana"
title: "Information regarding Online Transfer Policy"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "77a4aef621e53eb2"
---

<!-- page 1 -->

To

All Clerk
(Cadre-90)

/

Memo No. EA-II-20261 / 72/'
panchkula Dated ol.- o)-

P.2l

Subject:- Intimation regarding choice filling stage under Online
Transfer Policy.

It is hereby informed to all employees of the cadre that as per the
prescribed schedule, the Choice Filling Stage was proposed to commence

w.e.f. 02-02-2026.
However, since the process of voluntary consent withdrawal by
the employees is still under progress and thereafter final rationalisation is to be
undertaken, the Choice Filling Stage could not be initiated on the scheduled
date i.e., 02-02-2026.

Accordingly, the revised date for commencement of the Choice
Filling Stage shall be intimated shortly, please.

Nodal Officer-OTP
Fisheries Department, Haryana

<!-- page 2 -->

To

All Assistant & Others
(Cadre-60)

/( 7l
o)- ")- 2a) 5

Memo No. ,O-11-29261
Panchkula Dated

Subject:- Intimation regarding choice lilling stage under online Transfer
PolicY.

It is hereby informed to all employees of the cadre that as per the
prescribed schedule, the Choice Filling Stage was proposed to commence w.e.f.
02-02-2026.
However, since the process of voluntary consent withdrawal by the
employees is still under progress and thereafter final rationalisation is to be
undertaken, the Choice Filling Stage could not be initiated on the scheduled date

i.e.,02-02-2026.

Acccrdingly , the revised date for comlnencement of the Choice
Filling Stage shall be intimated shortly, please.

N

Officer-OTP
Fisheries Department, Haryana

<!-- page 3 -->

To

All Fisheries Officer
(Cadre-77)
Memo No. EA-ll-20261 /

/ l"

;;;;hd;";;;-;a- o2- 2'2 6
Subject:- Intimation regarding choice filling stagc under Online
Transfer PolicY.

It is hereby informed to all employees of the cadre that as per
the prescribed schedule, the Choice Filling Stage was proposed to commence

w.e.f. 02-02-2026.
However, since the process of voluntary consent withdrawal by
the employees is still under progress and thereafter final rationalisation is to
be undertaken, the choice Filling stage could not be initiated on the
scheduled date i.e., 02-02-2026.

Accordingly , the revised clate for comlnencement of the Choice

Filling Stage shall be intimated shortly, picase.
Nodal Officer-OTP
Fisheries Department, Haryana
