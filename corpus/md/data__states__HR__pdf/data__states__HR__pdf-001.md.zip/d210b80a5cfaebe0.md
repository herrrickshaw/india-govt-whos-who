---
doc_id: "d210b80a5cfaebe0"
source_url: "https://hsvphry.org.in/documents/tender_notices/tender_202610301456_56ad7.pdf"
ministry: "Haryana Shehri Vikas Pradhikaran, Haryana"
title: "BOQ"
date: ""
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "edd1940c9d69df10"
---

<!-- page 1 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
Tender No: CITO/HSVP/322848

Dated: 29.10.2026

Request for Proposal
For
HSVP Helpline Services

Information Technology Wing
Haryana Shehri Vikas
Pradhikaran C-3, Sector 6,
Panchkula, Haryana E-mail:
citohsvp@gmail.com
www.hsvphry.org.in

<!-- page 2 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026

Table of Contents
1. INTRODUCTION ..................................................................................................................................................... 4
ABOUT HSVP .................................................................................................................................................... 4
1.1 LIST OF ABBREVIATIONS .................................................................................................................................... 4
1.2 ELIGIBILITY CRITERIA ........................................................................................................................................ 5
1.3 TENDER ACTIVITIES SCHEDULE.......................................................................................................................... 5
2. PROJECT DESCRIPTION...................................................................................................................................... 6
2.1 BRIEF SCOPE OF WORK ...................................................................................................................................... 6
2.1.1 Other Requirements ............................................................................................................................. 7
A.
Software and Systems Requirements ........................................................................................ 7
B.
Manpower Requirements .......................................................................................................... 7
C.
Performance Metrics ................................................................................................................ 7
D.
Additional Requirements .......................................................................................................... 7
E.
Documentation Requirements .................................................................................................. 8
2.2 CALL HANDLING PROCEDURE ............................................................................................................................ 8
Query-Related Calls ............................................................................................................................ 9
Grievance-Related Calls ...................................................................................................................... 9
2.3 FUNCTIONAL REQUIREMENTS ........................................................................................................................... 10
Interactive Voice Response System (IVRS) ...................................................................................... 10
Call Record Management (CRM) ...................................................................................................... 10
Grievance Management System (GMS) ............................................................................................ 10
2.4 OUTGOING CALLS ............................................................................................................................................ 11
2.5 MANAGEMENT INFORMATION SYSTEM (MIS) REPORTS .................................................................................... 12
2.6 RESILIENT OPERATIONS ................................................................................................................................... 12
2.7 CALL CENTRE TIMINGS AND HOLIDAYS ........................................................................................................... 12
2.8 LANGUAGES..................................................................................................................................................... 12
2.9 SEAT CAPACITY AND SCALABILITY .................................................................................................................. 12
2.10 CONNECTIVITY WITH HSVP’ S INTRANET APPLICATION .................................................................................... 12
2.11 PROFILE OF CSES ............................................................................................................................................ 13
2.12 TRAINING OF CSES .......................................................................................................................................... 13
2.13 CONFIDENTIALITY OF INFORMATION ................................................................................................................ 13
2.14 PROJECT GO-LIVE AND SCALE-UP ................................................................................................................... 13
2.15 ACCEPTANCE OF THE HSVP HELPLINE CALL CENTRE SETUP ........................................................................... 13
2.16 COMPLIANCE WITH LAWS AND REGULATIONS .................................................................................................. 14
2.17 MISCELLANEOUS ACTIVITIES OF THE SUCCESSFUL BIDDER............................................................................... 14
3. INSTRUCTIONS TO BIDDERS ........................................................................................................................... 14
3.1 GENERAL INSTRUCTIONS .................................................................................................................................. 14
3.2 PURCHASE OF RFP DOCUMENT ........................................................................................................................ 14
3.3 ELIGIBLE BIDDERS ........................................................................................................................................... 15
3.4 COST OF BIDDING ............................................................................................................................................ 15
3.5 AMENDMENTS TO BIDDING DOCUMENTS .......................................................................................................... 15
3.6 CLARIFICATION ON BIDDING DOCUMENTS ........................................................................................................ 15
3.7 LANGUAGE OF BID ........................................................................................................................................... 15
3.8 BIDDING DOCUMENT ....................................................................................................................................... 15
3.9 BID PRICE ........................................................................................................................................................ 15
3.10 PERIOD OF VALIDITY........................................................................................................................................ 15
3.11 ACCEPTANCE OF TERMS ................................................................................................................................... 16
3.12 INSTRUCTIONS TO BIDDERS FOR E-TENDERING ................................................................................................. 16
3.13 MODIFICATION AND WITHDRAWAL OF BIDS ..................................................................................................... 17
3.14 PAYMENT SCHEDULE ....................................................................................................................................... 17
3.15 TERMINATION OF CONTRACT ........................................................................................................................... 17
4. BID EVALUATION AND TECHNICAL EVALUATION CRITERIA............................................................. 18
4.1 BID EVALUATION ............................................................................................................................................. 18
4.2 TECHNICAL EVALUATION CRITERIA ................................................................................................................. 18
4.3 CONTACTING HSVP ........................................................................................................................................ 18
4.4 HSVP’S RIGHT TO ACCEPT OR REJECT ANY BID OR ALL BIDS ......................................................................... 19
4.5 SIGNING OF CONTRACT .................................................................................................................................... 19
4.6 CONTRACT PERIOD .......................................................................................................................................... 19
4.7 ACTIVITIES AFTER AWARD OF CONTRACT ........................................................................................................ 19

Page 2 of 21

<!-- page 3 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
4.8

LIQUIDATED DAMAGES .................................................................................................................................... 19

5. SERVICE LEVEL PARAMETERS AND PENALTIES ..................................................................................... 20
5.1 UNATTENDED CALLS (ROUTED TO CSES BUT NOT RESPONDED TO) ................................................................. 20
5.2 DELAY IN ANSWERING CALLS .......................................................................................................................... 20
5.3 POOR CALL HANDLING DETECTED IN AUDITS OF RECORDED CALLS................................................................. 20
5.4 CALLER COMPLAINTS ABOUT POOR RESPONSE OR MISBEHAVIOUR BY A CSE ................................................... 20
ANNEXURE 1: BID PRICE SCHEDULE .................................................................................................................. 21
ANNEXURE 2: DETAILS OF CALL VOLUME (JUN 2025 – AUG 2026)............................................................. 21

Page 3 of 21

<!-- page 4 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
1. Introduction
Online bids are invited from reputed Indian Call Centre service providers for outsourcing HSVP
helpline services. Interested bidders may submit the bids online on https://etenders.hry.nic.in. on or
before. 16.11.2026 till 12:30 PM.
About HSVP
The Haryana Shehri Vikas Pradhikaran (HSVP), was constituted under the Haryana Urban
Development Authority Act, 1977. A statutory body of Haryana Government, HSVP’s mandate is to
promote and secure development of urban areas in a systematic and planned way with the power to
acquire, sell and dispose-off property, both movable and immovable; use this acquired land for
residential, industrial, recreational and commercial purposes, to other bodies for providing houses to
economically weaker sections of the society and to undertake building works.
After mid-2006, HSVP adopted IT initiative for process efficiency because the transactions between
HSVP and its allottees became so huge that handling such transactions manually was a gigantic task
and affecting the productivity of the organization.
It has been HSVP’s constant effort to provided most innovative programs aimed to

⮚ Improve transparency in HSVP’s operations
⮚ Improve service delivery process of HSVP
⮚ Cut down the lengthy processes for the convenience of its allottees
Keeping in track with its aim, HSVP has undertaken various IT initiatives about 3.25 Lakh allottees
across the state of Haryana
To enquire about various queries allottees visit different Estate Offices daily with numerous queries.
These queries are presently answered in person at the HSVP offices. For the convenience of such
allottees, HSVP intends to start a telephone-based Helpline service for its allottees so that the queries
of the allottees can be answered over the phone. This Call Centre will act as an interface for the
allottees to get their queries answered instantly by HSVP. Also, for the convenience of citizens,
HSVP proposes to establish a Grievance Management System wherein the citizens can call to log a
complaint about a service provided by HSVP (e.g. Water, Sewerage, Roads, Parks) through a TollFree number 1800 180 3030.
For more information on HSVP, please visit www.hsvphry.org.inabbreviations used in this document
HSVP Helpline Services
1.1 List of Abbreviations
Abbreviation

Full Form

AT

Acceptance Test

BPO

Business Process Outsourcing

CA

Chartered Accountant

CRM

Call Record Management

Page 4 of 21

<!-- page 5 -->

CSE

Request for Proposal for HSVP Helpline Services – HSVP 2026
Customer Service Executive

DD

Demand Draft

FAQs

Frequently Asked Questions

FY

Financial Year

GMS

Grievance Management System

HSVP

Haryana Shehri Vikas Pradhikaran

ITB

Instructions to Bidders

IVRS

Interactive Voice Response System

LAN

Local Area Network

LOI

Letter Of Intent

MIS

Management Information System

OSP

Other Service Provider

RFP

Request For Proposal

SLA

Service Level Agreements

SMS

Short Message Service

TRAI

Telecom Regulatory Authority of India

w.r.t.

with respect to

1.2 Eligibility Criteria
•

The service provider must have a valid business registration, which can include a
company registration, partnership registration, or sole proprietorship registration.

•

The service provider must have a minimum of 5 years of experience in managing
helpline services.

•

The service provider must have prior experience in handling customer service operations
for government or large organizations.

•

The service provider must have a valid GST registration.

•

The service provider must have a minimum annual turnover of ₹3 crore in each of the last
three financial years.

•

The service provider must submit copies of their income tax returns for the last three
financial years.
1.3 Tender Activities Schedule
Activity

Date

RFP available on website https://etenders.hry.nic.in..

30.10.2026

Last date for sending written clarifications through e-mail on
citohsvp@gmail.com Till 12:30 PM

03.11.2026

Pre Bid Meeting at 03:00 PM in the Conference, Hall, HSVP,
Sec-6,Pkl

04.11.2026

Replies to queries raised in pre-bid meeting

06.11.2026

Bid submission date&Time

16.11.2026 till 12:30 PM

Prequalification/Technical BidOpening

16.11.2026 till 04:00 PM

Bid Document Fee

Rs 5,000/- (nonrefundable)

Processing Fee in ₹ (18.00% GST Incl.)

Rs 1,180/-

Earnest Money Deposit

Rs. 5,00,000/-

Page 5 of 21

<!-- page 6 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
Note 1: Submission of Documents - Online Bidders will also required to physically submit the Bid
Document and other document related to prequalification, technical parameter / Technical
bid etc. The documents duly binded, properly tagged and numbered shall be sent through
speed post or courier by 16.11.2026 till 03:30 PM.
Note

2:

The

commercial

bid

should

only

be

submitted

through

online

mode.

2. Project Description
2.1 Brief Scope of Work
1 HSVP invites bids from eligible Call Centre operators to offer their services for operation of the
HSVP Helpline Services.
2 The successful bidder will be responsible for handling end-to-end operations of the Call Centre
operations for HSVP.
3 The Call Centre will be for inbound, outbound calls & SMS alerts on the mobile number of the
allottees. Majority of the call volume will be inbound calls from the allottees/citizens/general
public
a. Request for Information or
b. Submit a Grievance.
Outbound calls will be made by the CSEs to the concerned officials at HSVP and to high value
customers of HSVP. e,g : Payment reminder calls for Water Bill Payment and also call back to be
made to the callers in case the call is unattended due to all agents busy attending to other callers.
4

The infrastructure for operations and CSEs will be owned and managed by the Successful Bidder.

5

The Successful Bidder will have to provide Call Centre Services using a Toll FreeNumber
1800180 3030 preferably from BSNL. This number shall be accessible from all Mobile and
Landline networks. The cost shall be borne by the service provider.

6

The Successful Bidder will be responsible for providing a Call Record Management system and
also a Grievance Management System (GMS).

7

It is proposed to have a centralized Call Centre number for HSVP which will serve to the queries
and grievances of the citizens in two languages, i.e., English and Hindi.

8

In the beginning, the HSVP Call Centre may have 10 seats. The CSEs should be able to handle
calls in English and Hindi language both. The Call Centre shall operate from 8 AM to 8 PM on all
7 days of a week including National and Government holidays (except Holi and Diwali) with 10
agents available at all the time from 8 AM to 8 PM. In addition to the CSE’s, service providers
are required to have supervisory staff dedicated for the helpline like team leaders, quality analyst
and trainers etc.The monthly review meeting to be attended by senior officials of the company at
Panchkula HQ.

9 HSVP shall have the right to vary quantities i.e., no. of seats/ shifts in the Call Center, at the time
of award of the contract and/or subsequently at any time during the contract period. For the

Page 6 of 21

<!-- page 7 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
proposed helpline bidder will ensure that 10 agents plus the supervisory staff is available at all the
time from 8 AM till 8 PM.
10 HSVP officials may inspect the Call Centre at any time during the currency of the contract.
2.1.1 Other Requirements
A. Software and Systems Requirements:
(i) Customer Relationship Management (CRM) Software.
(ii) Grievance Management System (GMS).
(iii) Call Center Software with features such as call recording, call routing, and call analytics.
(iv) API Integration with websites /portals as and when required.
(v) SMS and email alert systems for grievance tracking and updates.
(vi) Mobile app development with all required functionalities to serve the allottees effectively.
B.

Manpower Requirements:
 Trained operators so that at any given time a minimum of 10 operators are available from 8 AM to 8
PM.
 A team leader or supervisor to oversee operations and ensure quality control.
 Proficiency in relevant software and helpline management systems.
 Operators should have excellent communication skills in English and Hindi.

C.

Performance Metrics:
 Response time to incoming calls.
 Resolution time for grievances and complaints.
 Customer satisfaction rating.

D.

Requirements:
(i)

Premises: The service provider must use their own premises for providing the service
and other infrastructure.

(ii)

Monitoring Mechanism: Implement a robust monitoring mechanism

(iii) Feedback Mechanism: Establish a structured feedback mechanism with clear templates
and reporting hierarchies to ensure that allottee feedback is gathered, analyzed, and acted
upon systematically.
(iv) Call Audits: Conduct regular, documented call audits with findings reported to higher
authorities, ensuring transparency and continuous improvement in service quality.
(v)

Non-Compliance Reporting: Ensure that any non-compliance or deviation from
contractual obligations is immediately reported and acted upon, with penalties imposed
for any lapses.

Page 7 of 21

<!-- page 8 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
E.

Documentation Requirements:
(i)

Company Profile: Detailed profile of the service provider, including history, services
offered, and organizational structure.

(ii)

Experience Certificates: Evidence of previous experience, including certificates or
references from similar engagements which should clearly add up to a minimum of 5
years of experience.

(iii) Financial Statements: Audited financial statements for the last three financial years.
(iv) Personnel Details: Detailed CVs of key personnel who will be involved in the project.
(v)

Statutory Documents:(a) Copy of business registration certificate (company, partnership,
or sole proprietorship). (b) GST registration certificate. (c) Income tax return
acknowledgments for the last three financial years.

(vi) Technical Proposal: Detailed proposal outlining the service delivery approach, software,
and systems to be used in addition details related to all other points mentioned under
Software and system requirements, Manpower requirements, performance metrics and
additional requirements.
(vii) Financial Proposal: Financial proposal including monthly cost for minimum uptime of
10 operators for all 7 days from 8 AM to 8 PM, including all ancillary costs such as
software, phone bills, internet, salaries. No additional payments shall be made beyond
the quoted/negotiated price.
(viii) Compliance Declaration: Declaration of compliance with all statutory and regulatory
requirements.

2.2 Call Handling Procedure
1. The HSVP Helpline would receive the calls from allottees/ citizens through a toll free
number.
2. Calls should be answered within 3 rings with hold time not more than 15 seconds.
3. The caller can choose from the language options English or Hindi through an IVRS.
4. The caller should then be prompted by the IVRS to choose whether he/she has a query or a
grievance; this would be in the language previously selected by the caller.
5. Based on the response, the caller should be connected to a CSE.
6. All interactions will be logged and maintained in the Call Center for analysis at a later stage.
7. The Successful Bidder should also provide Voice Logging facility for recording and playing
back CSE’s conversations so that it can be used to monitor agent performance on random
basis and to provide proof of transaction records.
8. The incoming calls from the citizens will be of broadly two types:
(i) Query related calls – Seeking information about the allottees account or any new
schemes floated by HSVP.
(ii) Grievance related calls – Grievance about any services rendered by HSVP.

Page 8 of 21

<!-- page 9 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
i.

Query-Related Calls
1. These calls will usually be made by present allottees or applicants of various schemes of
HSVP. An allottee may call to inquire about his account details (e.g. next payment due date)
2. The CSE should establish the identity of the caller with reference to information available in
the Intranet Application.
3. The CSE will respond to information requested by the citizen(s) by looking up the details in
HSVP’s Intranet Application. The Successful Bidder will be given access to HSVP’s
Intranet Application so as to lookup the information required by the caller.
4. The CSEs should record the name, address, contact details, queries, scheme type, reply to the
query etc. in a suitable format which is approved by HSVP. The information would be stored
in the CRM and would be used for the purpose of preparing MIS reports which is to be
submitted at HSVP HQ along with the raising of every invoice/bill. The information would
be required for analysis by HSVP at regular intervals.
5. Upon a response to the complete satisfaction of the caller’s query the CSE should also log
the details requested in the CRM and then disconnect the call.
6. If in case, the CSE is unable to respond to the request of the caller, the CSE should redirect
the call to Grievance Related Calls.

ii.

Grievance-Related Calls
1. These calls may be made by the allottees of HSVP’s or using services provided by HSVP
(Roads, Electricity, Sewerage, Parks, water billing etc.) to report a grievance about the
services.
2. The CSE should record the complaint with all the necessary details in the GMS. The caller
information should also be logged in the GMS.
3. The CSE should then provide the Grievance ID that is generated by the GMS. This will be
used in tracking the status of the Grievance.
4. The CSE should now forward the complaints to concerned authority in HSVP via Email,
SMS or Phone, following up / escalating whenever required. These all activities will have to
be managed through a Grievance Management System.
5. Depending on the type of complaint and severity of the complaint the CSE should notify the
concerned authority of the grievance.
6. These requests should reflect in the GMS access given to HSVP’s team. They should also be
notified of the Request through system generated emails sent to the concerned HSVP
officers. The email body should contain the exact request/grievance of the caller.
7. The HSVP official, each having an unique user ID and password for accessing the GMS via
internet from a regional office should only be able to view the Grievances, severity and their
status (i.e. Grievance logged / Work in Progress / Escalated / Closed) which are specific to
their location.
8. The CSE will also have to make outbound calls in cases where:
a. A grievance is of a high priority and needs to be notified to the concerned authority
of HSVP immediately.
b. An escalation has to be made of a high-priority grievance due to non-resolution of

Page 9 of 21

<!-- page 10 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
the grievance in the defined timelines.
9. Escalation of a Grievance: In case the Grievance is not closed by the concerned authority
within the pre-defined timelines, the GMS should be capable of auto-escalating the
Grievance to the higher authority. Depending on the severity of the Grievance, the CSEs
may also be required to call the higher authority notifying the escalation due to non-closure
of the Grievance.
b. Functional Requirements
i.

Interactive Voice Response System (IVRS)
1. The IVRS should support English & Hindi languages.
2. It shall be possible to customize the IVRS welcome prompt, menu and sub-menus as per the
requirement of HSVP.
3. It shall have Automatic Call Distribution feature based on Skill, Idleness, and utilization of
each CSE.
4. It should also support to hold calls in case all the CSEs are busy.
5. It should be able to generate MIS reports automatically.

ii.

Call Record Management (CRM)
The Call Record Management will have to be developed/ maintained/ customized by the successful
bidder. The CRM should be capable of logging the following details:

•

Name of Caller

•

Exact Query of the caller

•

Category of Query/Grievance

•

Sub Category of Query/Grievance

•

Brief Response of the CSE to the Query/Grievance

•

Time of call

•

Name of CSE who handled the call

The CRM should be capable of auto-generating a query/Grievance ID for each query/grievance
recorded. Facility for searching the call record database on various attributes and combination of attributes
should be provided. The application may also have the provision to build database of FAQs and their
standard answers. Database of all calls received since start of the HSVP Helpline should be maintained in
the CRM. The CRM application should have a report generation module providing various MIS and
statistical reports based on the call records database as required by HSVP from time to time.The user
should be given the choice to set various filters like period (from-date and to-date), time of day, category
of query and various other attributes and their combinations while generating an MIS report from the
database. Some ad-hoc/on-demand MIS Reports may also need to be generated as and when required by
HSVP.SMS functionality should also be available for sending SMS for grievance calls to customers &
HSVP officers.
2.3.3

Grievance Management System (GMS)
The Grievance Management System will have to be developed/ customized/ maintained by the successful
bidder. The GMS should allow the CSE to log the following details:

Page 10 of 21

<!-- page 11 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
•
•

Caller Name

Address
•

Nature of Grievance

•

Severity of Grievance (will be pre-defined by HSVP)

•

Concerned Authority responsible for resolution of the Grievance (pre-fetched from
data already fed in the GMS)

•

Time of logging the Grievance

•

CSE’s Name who logged the call

1. Once the Grievance is logged, the concerned authority (will be pre-defined by HSVP) should be
notified via Email, SMS or Phone Call depending on the severity of the Grievance.
2. Although a Phone Call to the concerned authority will depend on the Severity of Grievance, an
email/SMS has to be sent for every grievance logged.
3. A grievance link to be created on HSVP website to log grievances for monitoring wing & Estate
offices.
4. A grievance link to be created on HSVP website for consumers to register grievances related to
plots, water billing, sewage, roads, horticulture or any other services provided by HSVP, these
grievances should be integrated with the GMS and SMS along with the complaint no. should be
generated instantly upon registration of grievance on HSVP Portal.
5. The GMS should also be integrated with website/portal and real time data of the grievances
registered and resolved/pending should be available at any given point of time.
6. All customization during the currency of the contract should be duly handed over to HSVP after
expiry of contract.
7. A functionality of the WhatsApp messaging for information dissemination may also be added.
(iii)

Access of the GMS to the regional offices of HSVP:
1. The successful bidder should also provide access to the GMS to the regional offices of HSVP.
2. The HSVP official, each having an unique user id and password for accessing the GMS via
internet from a regional office should only be able to view the Grievances, severity and their status
(i.e. Grievance logged / Work in Progress / Escalated / Closed) which are specific to their
locations.
3. The concerned HSVP official should be able to update the status of the Grievance to ‘Work In
Progress’ & ‘Closed’.
4. A super user access should also be provided at the Panchkula Head Office of HSVP where the
GMS should reflect status of Grievances across all regions.
5. SMS functionality should also be available for sending SMS for grievance calls to customers &
HSVP officers.

2.4. Outgoing Calls
The CSE may have to call the various officers of HSVP for escalation purpose. All the call details –
like calls made to which number, duration of call, date and time of the call etc. details will have to be
provided by successful bidder on a regular basis.

Page 11 of 21

<!-- page 12 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026

2.5 Management Information System (MIS) Reports
The Successful bidder shall install necessary software and make available the same to HSVP to use
the same for generating reports on operation of the Call Centre.
MIS Reports:
Few sample reports are as below. These are only indicative. Exact reports will be decided afterwards
of the contract.










Number of incoming calls handled
Number of outgoing calls placed
Average talk time for calls handled - measured
Average active time per call
Summary of the interval of time required for handling incoming calls
Number of calls exceeding threshold (i.e. calls waiting in queue longer than given time)
Average time in queue by call type
Number of abandoned calls

The Successful Bidder will provide any other reports relevant to demonstrate the functioning of the
Call Centre. The required report must be generated from the system automatically not manually
2.6. Resilient Operations
The successful bidder should have provisions to have a backup location wherein the Call Centre
operations of HSVP can temporarily shift, till resumption of original status, in case of any failures
related to people, technology or natural calamities.

2.7. Call Centre Timings and Holidays
The Call Centre will operate initially for 12 hours (8 AM to 8 PM) on all seven days in a week and
therefore making the Call Centre available to the citizens, including national holidays, Sundays,
(excluding Holi and Diwali) etc.
2.8. Languages
The Call Centre’s CSEs will initially use two languages – Hindi and English.
2.9. Seat Capacity and Scalability
Presently, HSVP proposes to establish a Call Centre with 10 seats. Depending on the call volume, the
successful bidder should be in a position to scale up/down their operations, at the request of HSVP.
2.10.

Connectivity with HSVP’s Intranet Application
HSVP will make provisions to enable the Successful Bidder to access the Intranet Application.
The Successful Bidder will have to make provisions to have secure access to the Intranet
Application using Industry-best Firewall, IDS, connectivity etc. The Successful Bidder will have
to bear the costs of Internet or any other connectivity that may be required to access HSVP’s
Intranet Application.

Page 12 of 21

<!-- page 13 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
2.11. Profile of CSEs
The following are the indicative requirements for the CSEs
1. Preferably, the CSEs should have a previous experience of working with HSVP. This will help
them to better understand a caller’s needs.
2. Basic Qualification – at least a Graduate degree.
3. Desirable Experience – 6 months to 1 year of BPO / Call Centre experience
4. CSE’s communication skills – soft and polite voice, well behaved, un-argumentative and trustworthy
5. The appointment of the CSEs should be to the satisfaction of HSVP.
2.12. Training of CSEs
1. HSVP will provide classroom training to the complete (first) batch of CSEs and supervisory
staff.
2. This training will cover the HSVP’s Intranet Application (which will be used to answer most
of the Query-related calls) and various property schemes for the general public.
3. The Successful Bidder will have to make sure that ALL the CSEs who will be involved in
the operations have to attend the training.
4. A CSE who has not attended the training provided by HSVP will not be allowed to
participate in the operations for a period of first 6 months after the operations go live.
5. Training of any CSE being recruited / replaced in HSVP’s operations will be the
responsibility of the Successful Bidder.

6.

Although HSVP will not charge the Successful Bidder for any training, the Successful
Bidder will bear all other charges during the trainings. (e.g. Lodging, Conveyance)

2.13.

Confidentiality of Information

During the course of the operations, the Successful Bidder and the CSEs may get access to
information of allottees and/or HSVP which may be sensitive in nature. The Successful Bidder
should take enough measures to contain the distribution and restrict access of such information. Also,
the CSEs should never disclose the information of an allottee without validating the identity of a
caller.
Further, the Call Center shall have capability to logically partition the switching system to avoid
interference with other set of users.
2.14.

Project Go-Live and Scale-Up

The Successful Bidder would be required to make the project LIVE within a period of 3 weeks from
the date of issue of work order. Any scale-up or scale down of operations, as per the request of HSVP
will have to be effected as and when required based on a mutually agreeable timelines. Any increase
or decrease of the number of CSEs will be at the same rate, the rate quoted by the bidder during the
submission of the bid.
2.15.

Acceptance of the HSVP Helpline Call Centre Setup

Acceptance Test (AT) of the HSVP Helpline shall be conducted by HSVP and/or any appointed third

Page 13 of 21

<!-- page 14 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
party after the same is offered by the successful bidder for acceptance. The tests to be carried out test
procedure, test equipment and tools, and expected test results are to be provided by the successful
bidder to meet all the specified parameters/ service requirements. The Test procedures /Test results
shall be approved by HSVP and/or any appointed third party. Acceptance will be given subject to
satisfactory performance failing which the order shall stand automatically cancelled.
The AT has to be performed within one month of the Call Centre Operations
2.16.

Compliance with Laws and Regulations

HSVP will not be responsible for any operation and/or management related activities of the
Successful Bidder’s call centre operations. The Successful Bidder will be expected to comply with
any laws and regulations or licenses required by the TRAI or any other Governmental Body.
2.17.

Miscellaneous Activities of the Successful Bidder

The successful bidder will be responsible for the complete end to end solution and successful
implementation of the Call Centre operations.
An indicative list is provided below:
1. Development/ Customization/ Installation/ Maintenance of the softwares, for CRM, GMS.
The IT infrastructure that is maintained by the successful bidder should be able to support
the volume of transactions (Detail of volume of transactions is enclosed as Annexure 2). All
will be included as part of the project.
2. Development of Mobile App system as per time lines mentioned in clause 4.7
3. Infrastructure setup including office space, telephones and systems etc. for CSE.
4. MIS reporting tool etc.
The bidder shall submit the software, data and other intellectual property of HSVP upon the
completion of contract with HSVP.

3 Instructions to Bidders
3.1 General Instructions
The Successful Bidder will be responsible for providing end-to-end services are mentioned in this
RFP.
The Successful Bidder and the CSEs have to maintain confidentiality about all the applications,
database and network set up of the HSVP and should not divulge it to any person/ organization not
related to the HSVP. In this regard the short-listed vendor will be required to execute confidentiality
cum non-disclosure agreement with the HSVP.
3.2 Purchase of RFP document
The Complete RFP document can be downloaded online from the portal https://etenders.hry.nic.in by
the bidders registered on the Portal. The bids to be submitted online are required to be digitally
signed; the bidders are therefore advised to obtain Digital Signature at the earliest. For further details,
terms and conditions please visit the website https://etenders.hry.nic.in.

Page 14 of 21

<!-- page 15 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
The scanned images of the RFP Cost / EMD are required to be uploaded at the time of Online
Submission, the Bidders are therefore required to keep the scanned copies of prequalification and
other documents of the above mentioned documents ready.
3.3 Eligible Bidders
Eligibility of the bidders shall be on the basis of the criteria mentioned in 1.2 of this RFP
3.4 Cost of Bidding
The Bidder shall bear all costs associated with the preparation and submission of the Bid and HSVP
will, in no case, be responsible or liable for those costs, regardless of the conduct or outcome of the
bidding process.
3.5 Amendments to Bidding Documents
At any time prior to the last date and time for submission of bids, the HSVP may, for any reason,
modify the Bidding Document by amendments at the sole discretion of the HSVP. All amendments
will be updated on the HSVP website with appropriate markings. The amendments may also be
delivered by hand / courier or through e-mail to all bidders, who have received the bidding document.
For this purpose bidders must provide name of the contact person, mailing address, telephone
number, email id and FAX numbers on the covering letter sent along with the bids. All clarifications
will be hosted on HSVP’s website. In order to allow eligible Bidders a reasonable time to take the
amendment into account in preparing their bids, HSVP, at its discretion, may extend the deadline for
the submission of bids.
3.6 Clarification on Bidding Documents
Bidder, requiring clarification on the RFP may submit queries/ clarifications to HSVP in writing on
the Bidder’s Letterhead at the address indicated above, before the deadline for the submission of the
bid. HSVP will not respond to any queries received after this date. All such clarifications will be
hosted on HSVP website www.hsvphry.org.inand https://etenders.hry.nic.in. The identity of the
bidder seeking clarification will not be disclosed in this document.
3.7 Language of Bid

The Bid prepared by the Bidder, as well as all correspondence and documents relating to the Bid
exchanged by the Bidder and HSVP, shall be written in English. Supporting documents and printed
literature furnished by the bidder may be in another language provided they are accompanied by an
accurate translation of the relevant pages in English. For the purposes of interpretation of the bid, the
translation shall govern. Information supplied in another language without proper translation shall be
rejected.
3.8. Bidding Document
The bidder is expected to examine all instructions, forms, terms & conditions and technical
specifications in the Bidding Document. Submission of a bid not responsive to the Bidding
Document in every respect will be at the bidder’s risk and may result in the rejection of its bid
without any further reference to the bidder.
3.9. Bid Price
The bidder shall indicate the prices in Indian Rupees only.
3.10. Period of Validity

Page 15 of 21

<!-- page 16 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
Bids shall remain valid for 180 days from the date of bid opening prescribed by HSVP. A bid valid
for a shorter period shall be rejected by the HSVP as non-responsive.

3.11. Acceptance of Terms
All Bidders, by submitting the Bid/Proposal in response to this RFP document shall be deemed to
have accepted all the terms and conditions of this document.
Note 2:- The price bids are to be submitted mandatory online.

3.12.Instructions to Bidders for E-Tendering
These conditions will over-rule the conditions stated in the tender documents, wherever relevant and

applicable.
1.

Registration of bidders on E-tendering Portal:All the Bidders intending to participate in the tenders processed online, are required to get
registered on the Electronic Tendering System on the Portal https://etenders.hry.nic.in

2.

Obtaining a Digital Certificate:
2.1

The Bids submitted online are required to be signed electronically with a Digital
Certificate to establish the identity of the bidder online. These Digital Certificates
are issued by an Approved Certifying Authority, by the Controller of Certifying
Authorities, Government of India.

2.2

In case of online tendering, if the digital certificate issued to the authorized user of a
firm is used for signing and submitting a bid, it will be considered equivalent to a
no-objection certificate/power of attorney /lawful authorization to that User. The
firm has to authorize a specific individual through an authorization certificate signed
by all partners to use the digital certificate as per Indian Information Technology
Act 2000. Unless the certificates are revoked, it will be assumed to represent
adequate authority of the user to bid on behalf of the firm in HSVP tenders as per
Information Technology Act 2000. The digital signature of this authorized user will
be binding on the firm.

2.3

In case of any change in the authorization, it shall be the responsibility of
management / partners of the firm to inform the certifying authority about the
change

and to obtain the digital signatures of the new person / user on behalf of the firm /
company. The procedure for application of a digital certificate however will remain
the same for the new user.
2.4

The same procedure holds true for the authorized users in a private/Public limited
company or L&C Society. In this case, the authorization certificate will have to be
signed by the directors of the company.

Page 16 of 21

<!-- page 17 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
3

Set up of machine:
In order to operate on the electronic tender management system, the user’s machine is
required to be set up. A help file on setting up of the system can be downloaded from
the home page of the website - https://etenders.hry.nic.in

4

Online Viewing of Detailed Notice Inviting Tenders:
The bidders can view the detailed N.I.T and the time schedule (Key Dates) for all the tenders
floated through the electronic tendering system on the HSVP’s e-tenders website
https://etenders.hry.nic.in

5

Download of Tender Documents:
The tender documents can be downloaded by the registered user from the Electronic
Tendering System through the Portal https://etenders.hry.nic.inand www.HSVP.org.in

6

Key Dates:
The bidders are strictly advised to follow dates and times as indicated in the Notice Inviting
Tenders. The date and time will be binding on all bidders. All online activities are time
tracked and the system enforces time locks that ensure that no activity or transaction can take
place outside the start and end dates and the time of the stage as defined in the Notice
Inviting Tenders.

8

Submission of actual online bids:
Bidders have to submit their bids online and upload the relevant documents. The process is
required to be completed within the date and time as stated in the Notice Inviting Tenders
(Key Dates). The electronic bids of only those Bidders who have submitted their bid within
the stipulated time, as per the tender time schedule (Key Dates), will be accepted by the
system. A Bidder who does not submit his bid within the stipulated time will not be allowed
to submit his bid by the E-Tendering System.

Note:-Bidders participating in e-tendering shall check the validity of his/her Digital Signature
Certificate before bidding in the Tenders floated online at e-tendering website
https://etenders.hry.nic.in
3.13. Modification and Withdrawal of Bids
Valid bids once submitted will be treated, as final and no further correspondence will be
entertained on this. No bid will be modified after the deadline for submission of bids.
No bidder shall be allowed to withdraw the bid, if the bidder happens to be a successful bidder.
3.14. Payment Schedule
The successful bidder will be paid on a monthly basis for the call center operations on the
submission of original bills. This will be done only after submission of the required MIS
reports to HSVP. Any penalties applicable on the billed period will be deducted from the
bill amount.
3.15. Termination of contract
HSVP reserves the right to terminate the contract at any point during the period of contract
without stating reasons.

Page 17 of 21

<!-- page 18 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026

4. Bid Evaluation and Technical Evaluation criteria.
4.1. Bid Evaluation
1. Bidders having scored a minimum of 70% marks as defined in technical criteria will be
considered technically qualified and financial bid of all technically qualified bidder will be
opened.
2. Contract will be awarded to the lowest bidder (L1) in the financial bid.
4.2. Technical Evaluation Criteria
Technical Proposals will be evaluated based on following criteria:

Sr. No

Evaluation Criteria

1

Quality of the Technical Bid document

2

Bidder’s understanding of the RFP document and the responsiveness
of the bidder in providing the required information and documents in
the
bid document.
Proposed plan for HSVP Helpline setup w.r.t.:
1. Infrastructure available in the existing call center of the bidder
where HSVP Helpline is proposed to be set up
2. Proposed setup of HSVP Helpline in the existing call center
location
3. Proposed network diagram with equipment, servers, system
software, security components etc.
4. Make, model and configuration of the servers, desktops, LAN
etc. to be used.
5. Provisions for regular Data backup

7

6. Proposed Call Flow architecture and associated processes.
Adherence to the functional requirements of CRM & GMS
Applications in the software’s proposed.
Proposed Business Continuity Plan for HSVP Helpline setup
(including manpower, technology or natural calamities etc.)
Experience in handling a similar project (Case Study)
Monitoring Tools/methods proposed
1. Proposed methodology for ensuring that the call center processes
are being followed and that telephone connections are not
misused.
2. Provision of trained supervisors for monitoring of call center.
Voice Logging Facility for recording and playing back of CSEs
conversation at random basis.
Scale Up /Scale Down capacity in terms of manpower of the proposed

8

Call Center where HSVP Helpline is proposed.
Awards / Recognitions received by the Bidder for the Facility that the

3
4
5
6

Bidder wishes to propose for HSVP’s Helpline Services.

Max Marks
(70 Marks)

5 Marks

30 Marks

10 Marks
5 Marks
5 Marks
5 Marks

5 Marks
5 Marks

4.3. Contacting HSVP
Any effort by bidder to influence HSVP in the bid evaluation, bid comparison or contract award
decision may result in the rejection of the Bidder’s bid. HSVP's decision will be final and without
prejudice and will be binding on all parties.

Page 18 of 21

<!-- page 19 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
4.4. HSVP'S Right to Accept or Reject Any Bid or All Bids
The HSVP reserves the right to accept or reject any bid as well as scrap bidding process and reject all
bids at any time prior to award of contract, without thereby incurring any liability to the affected
bidder or bidders or any obligation to inform the affected bidder or bidders of the ground for the
HSVP's action.

4.5. Signing Of Contract
The successful bidder will be issued letter of intent and the successful bidder will have to sign the
agreement with HSVP within 7 days of the issuance of LoI. The successful Bidder shall furnish
Performance Bank Guarantee to HSVP for an amount equal to 10% of the order value with a validity
of 3 months more than the expiry of the contract. HSVP may forfeit the Performance Bank Guarantee
for any failure on part of Bidder to complete its obligations under the Agreement. The Performance
Bank Guarantee shall be denominated in Indian Rupees and shall be absolutely , irrevocably and
unconditional guarantee in the form of a Bank Guarantee issued by a Nationalized/Scheduled
Commercial Bank and payable at Panchkula in the format provided by HSVP.
4.6. Contract Period
The contract period will be for a period of one year and may be extended at the discretion of HSVP
based on mutually agreed terms and conditions. At any point during the contract the dissatisfactory
performance may result in termination of contract with one month notice. The Chief
Administratorwill be final authority on all matters related to the execution of contract including but
not limited to termination and extension.

4.7. Activities after Award of Contract
Sr.

Activity

No.

Timeline

Signing of LOI and/or Contract Agreement

T

2

HSVP Helpline Services Go Live

T+3 weeks

3

Mobile app

T + 6 Weeks

1

4.8. Liquidated Damages
If the supplier fails to offer the services and system within the periods specified in the Bid, HSVP
shall, without prejudice to its other remedies under the Bid, deduct from the PBG, as liquidated
damages, a sum equivalent to 1% of the Bid price for each week or part thereof of delay until Final
Acceptance, up to a maximum deduction of the 10%.
If the delay is more than 4 weeks, HSVP has the right to terminate the contract and encash the PBG.

Page 19 of 21

<!-- page 20 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026
5. Service Level Parameters and Penalties
5.1. Unattended Calls (Routed to CSEs but Not Responded To)
Penalty as mentioned below will be levied on the Successful Bidder on each monthly billing cycle.
S.
No.

Unattended calls (as % of total calls routed to CSEs)

Penalty per month

1

Less than 1%

nil

2

1% - 2%

2% of monthly payment

3

2% - 3%

4% of monthly payment

4

3% - 4%

6% of monthly payment

5

4% - 5%

8 % of monthly payment

6

Beyond 5%

10% of monthly payment

5.2. Delay in Answering Calls
If the CSEs answer the calls after a delay of 15 seconds then a Penalty as mentioned below will be
levied on the Successful Bidder on each monthly billing cycle.
S. No.

Calls answered after 10 seconds (as % of total calls attended by all

Penalty per month

CSEs)

1

Less than 1%

nil

2

1% - 2%

Rs. 1000

3

2% - 3%

Rs. 2000

4

Beyond 3%

Rs. 4000

5.3. Poor Call Handling Detected in Audits of Recorded Calls
Calls handled by the CSEs will be monitored through checks on the recorded calls. If it is found that
a CSE is providing wrong/incomplete information or is misbehaving with the caller or is not
responding properly, a penalty of Rs. 1000/- will be imposed on every such instance and will be
deducted from running payments/security deposit.
5.4. Caller Complaints about Poor Response or Misbehaviour by a CSE
If complaint(s) are received from callers regarding misbehavior and/or poor response by any CSE,
and if such complaint(s) are established to be true beyond reasonable doubt, a penalty of Rs. 2000/will be imposed/deducted from running payments/security deposit on every such instance.
5.5. During the Course of the Call Centre Operations HSVP reserves the right to modify the
existing SLAs/penalties and/or introduce new SLAs/penalties.

Page 20 of 21

<!-- page 21 -->

Request for Proposal for HSVP Helpline Services – HSVP 2026

Annexure 1: Bid Price Schedule
Name of the Bidder:

Monthly Basic Call Center Charges per CSE (To
maintain 12 hours operations with 10 agents available
at all the time from 8 AM to 8:00 PM all 07 days a
week

including

National

Holidays

&Sundays

In Figures: Rs.
In Words : Indian Rupees

(excluding Holi and Diwali, etc.). The charges must
include all ancillary costs such as software, phone bills,
internet, salaries. No additional payments shall be made
beyond the quoted amount.

The above price shall remain valid for the entire tenure of the contract, subject to extension up to the
date of formal tender allotment as a gap-filling exercise.
•

Financial proposal including monthly cost for minimum uptime of 10 operators for all 7 days
(excluding Holi and Diwali, etc.) from 8 AM to 8 PM, including all ancillary costs such as
software, phone bills, internet, salaries. No additional payments shall be made beyond the quoted
amount.

•

The above prices shall be inclusive of all taxes as applicable.

Annexure 2: Details of Call Volume (June 2025 to August 2026)
Month

Calls Received

Jun-25

4877

Jul-25

5669

Aug-25

4833

Sep-25

5246

Oct-25

4514

Nov-25

4183

Dec-25

5015

Jan-26

8708

Feb-26

5368

Mar-26

6302

Apr-26

5659

May-26

3219

Jun-26

5078

Jul-26

6068

Aug-26

5435

Grand Total

80174

Page 21 of 21
