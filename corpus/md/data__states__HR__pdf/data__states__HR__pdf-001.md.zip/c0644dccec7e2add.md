---
doc_id: "c0644dccec7e2add"
source_url: "https://haryanatax.gov.in/Website_Content_Files/GST_Circulars/2025/2025_12_01_02.pdf"
ministry: "Excise and Taxation Department, Haryana"
title: "Instruction regarding taking up Suo-Moto Cases for Audit/Scrutiny under the HGST Act, 2017.)(Memo No. 1217/GST-II dated 29.11.2025)"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "a0704906ab8b40e7"
---

<!-- page 1 -->

है 9
Ye
oS)
आबकारी एवं कराधानविभाग, हरियाणा ie
EXCISE & TAXATION DEPARTMENT, HARYANA
वाणिज्य भवन, प्लाट न. 4 -3 ,सैक्टर - 5 ,पंचकूला - 34209
Vanijya Bhawan, Plot No. ] -3, Sector 5, Panchkula- 3409
Ph: 072-2590990, 2590935
To
All the Additional Excise & Taxation Commissioner
All the Joint Excise & Taxation Commissioner (Range)
All the Deputy Excise & Taxation Commissioner (ST)

In the State of Haryana

Memo No. \2'7 /qgr-,dated 24] poo
Subject: Instructions regarding taking up Suo-Moto Cases for

Audit/Scrutiny under the HGST Act, 207.

Your attention is invited to the subject cited above. In this
context, it is hereby directed that whenever any suo-moto case is
proposed to be taken up for audit or scrutiny, the same shall be
submitted with a clear, specific, and duly justified reasons and must also
include the tentative quantum of tax evasion on the basis of available
records, intelligence inputs, data analysis, or any other verifiable source
of information.

Further, it is mandated that every such proposal for initiating
suo-moto audit/scrutiny shall first be examined and recommended by
the Deputy Excise and Taxation Commissioner (DETC) concerned and
after the DETC’s recommendations, the case file shall be forwarded to the
Joint Excise and Taxation Commissioner (Range) for obtaining the

ie necessary approval.

All field formations shall ensure strict compliance with these
instructions. Any initiation of suo-moto action without adherence to the

: above-mentioned procedure shall be viewéd seriously,
" रा This issues with the approval of the competent authority.
: : ‘ save . :
Jt. Excise & Taxation missioner (GST-II)
O/o Excise & Taxation Commissioner
Head Office, Panchkula

<!-- page 2 -->

A copy is forwarded to the following for kind information.

l. PS to Commissioner & S Exci T न

Haryana ecretary, Excise & Taxation Department
2. PA to Excise arid Taxation Commissioner
: ce anes
Jt. Excise & Taxation Commissioner (GST-I])
O/o Excise & Taxation Commissioner
Head Office, Panchkula
