---
doc_id: "c8ea7d3f93b8ecd5"
source_url: "https://fdaharyana.gov.in/PDF/DepartmentalServiceRules/Service%20Rules%20Ministerial%20Staff%20HQ%20Group%20C%20amendment.PDF"
ministry: "Food and Drugs Administration Department, Haryana"
title: "Service Rules Ministerial Staff HQ Group C amendment"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9a6eeed308626aa5"
---

<!-- page 1 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 8, 2013
(KRTK. 17, 1935 SAKA)

1929

'WEI-Rut f4'4[4aittifv9T
ft-91-T. 8 -111-61.Z, 2013
3T-14-4 309
fiffit1T9i1foTcY140 32/f1Td0/31-10 309/2013.-4M'
C
1 ,"-ciL1id, T4=1* um,
g7, 6 Rmull
qz:ItTT
ft:pi
i4-vo-Rrff cN.)
04-4) Acu f444, 1984

ICI TIT
4cci

qR./ct)

t,
1. t fir 61411°11 ifrfezi N711c-14 f"f4-w cr4

(441-4) .4)11 (fi7T19-9") fa N 2013,

cf.) v11 frw . t ►
2.

kiqvi 1

6f4z1luti t4k-P21 NYlle14

i co6r 41241 t)
"sw.— (1)

ft141 9

"4111zi (Tif—TT) t)11 fti-PE, 1984 P4, Te4,
7rtrrr, arzrfq:—
114, 1-.-11ZiR9c1 f'44-4

qftki
1, 31mew4, c b3 dc1-iF11.1 ziruffit4
coui Etair f
-*'PT
P
(P4-LIV'< 3Ttfrq71-9'
Aof
(1"1-1 3TRPW
7rth
Rrd-wer-ff
Garr (Rt-I..t
-ff2r-r
(70
.4-.e
r.4.)
t i 171-1-1V 341-1t7r9- R.rr -Ozeici-i i <I.1-4 L1T T 'AC
qiq 4 ard-rm-u 7r-4/31go1 tfifft t ‘i-Ncr,01- fall-P4/0--m-rall 4 TrIft
TR fMzr-4-, armewwl, cof*o ac1.141-1 3TR-114
fiffq-4ff f
ff4-w
61)1
arg-w
arruftft4
3i Ti 114b5
fa-491 W
ET
Rz*
Tmft
ik
4al^1cl
f
fftrr 7
qg
cc ut
zrr
3rd zrerr 3Tdf rd 3T4 Ty twur Lr,aarr trt0 -16f 1 t
,fl ,r4 1-11:1c11 rtaiT
altffrcrzm err
zrr
e( wftEe c)c-1-14-11.-1
crro) Th-T f4w-Fr 61411 I arra
tr.0't.)
crf4to dc1.ii .1 arm-ff?2rwl col Ift
31-re-A--4
It 31-4 TT4T 0411
zratrfreff 3Truftf4 t

41 -41 414
(2) ‘34-4-114(11t crlfifiEft 4-6taR 4711 4 k;c1-, c4 (14>
RI‘TE1 tif1c11
1
(1.-1
"T41
Rc,
c 1)4A-Ittt 3110rTzi-9tir41W-r 3T If
g-41#
f
~1 u al
tlift I T.(
ictur N‘91.er.-01.) 3T
01) 3TAT4 ac1-1411-1 4 1)1 acl -rte3TM-I
fir \344qCIN
61111
11) c \Ichl trtrair 3T-4 .161 4
cbt.)
61)4K
c401/(aa t f 1 31TELF0' .t6 "cif•(.) 1)4-11R1I 4 trar -041-ccr 4),<
tr-4fiTdwr/Irft Ive4fr t fMtrw -uvrr arrEieww
tfi
I IriNic 31014
t 4 qEtacr ftRrrR.
0
.ttrA.)
.1c71-1
4
t1vt1
41*-11"
tail
(7cf)+-4te.1 311:11t74T9" CU TTfk,
3rd wR--41 611 f0-4 &Ewa ,46.) "cR ■it) c111-11i 104f1d cry fkufT
wz -rr

'1

(3)

f4-40 ftT1-4
-W1-/4.M 4
6141full fitcOlt, Tff- gm, 6
(6N 0i) zrr tkcoN g1/1 zfzegitu f 1 3TRT Cry cr))
31-PdftwE
1-110E1M4i
au fzp-r (4) 4 zmi w4-4fArd
f4z14
3TIRTH
(t)7 tiispi-r
**r -q-14-41t-1t1)1

<!-- page 2 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 8, 2013
(KRTK. 17, 1935 SAKA)

1930

c 4)144Hit 341;ftit7r9- mil \Rm
LI ET ti
ZT&TT
Wlflccr T44tAZT ~l
cp
q1-)101 q&'-Tr ( tIttrA.)
TRIT3T--@Aft-U f fl 3T1
Vif4V -7"th 1 NO.-I Trt tNcw g
f4ft-d zici
I f4Z1-91
7441'ti I71qi fttrr TZ1T
Tcr A ,rellcok f+-zrt 4-4-TT
4ta.zr
(4)

(5)

(s)

(1,44-itIt 3Tiftft7rq -t1T)czt-i A 7wi- 417401 LI&T.
cciqi ck4q14R,i,t,
Itiqq5w-i
A.),514-c 0,11

-aTT

4rTfat A '4-1 ,1,pai- `c6) ' (Key) --01";) cif d
fZiNct,I 4 qzii A,
3.11)-41 A Aft f4-9z 30 Yitsq -IT ft---4t A •q14 fib 25 7r-wirTfri
Erftru-d
zi--4-fetTr
zi-tf44
1-,.-16I5ci -th-Tzr-d-r 7R31-4 c nc1 cp4T4INI
Lit-Acit Li&LTE
0?-c.iczi-f
9.ct./t. cp. (4),-4 zip4
1411- 8D,rictd tr cni-Litke
34-04-Fff
v.Tt
(ii) "R-P&tli
(.)(ce 1'131'f-47-4-#.1 *I) '(-114
kft-W 4)4-41

-q

(iii)

cni-wit 3a-It*71-9
tot l -4rOtt
t4
vrcTiLqi

(1.3t1-4.
31117 Wrf40. f+--#.1 111-'4401 1111-ci

r Ottlf- c61 4-o-rr9

TrraTR--d-r
1
-q--qt

LITRITff tar c .,-q1 (Nc4. 4t-4)
Nz.N*14N-r-4tr);

1.**.aNc-f.
Rttiuti

114

ft Lim •• -Td't

(iv) .344,41,4/ 4,4-10L4

i 1 ft .3,411qc1H uTRT
"ff2.1T c16 .)41:151)1 ctc) t14-N-1
Lit-Am 4a$-Tr
ft lilt( Cn+- ce 311fifticrffff UZIT fZ(.1c71.-1
r
61'20,1 gm TIT •-kcoN lei vrRr-- fel 31- :1
4ir4 pit 4
Th'r fa-f4
4t gki 0,\91 11111u1-7
7491.-11 714111; Ci2Tr

3Toft

(v)

V-24. (ON 2l1. - TEI-t)
3Rr-4Tr \3,-41qcmI N2
3T+T1 r 3T T mei, 4(,-11Z-N1 3iIE6
RTRZli cb) VITTfad'
-4 .4 44. wErtt 3f-Tr
T2T
cr.) coot 3@(1.)zi-i 13.).T4fecr ft-4311:34
w 4,1 ,ot -)•
\41)D1?-41 l aftuffr ci21T &full

zit

co to-{

-Terrfit,

coi-ruifZ441

3Tcgrq Wftff
1--rttafr (-r.4.tt.t.)

61,ii

(v)
\34N (rci
c71.-1
3i-1114.7z9 .Tert.
4ai-r

qf4U
3i
1,41 trrTar
Afu-d-

<!-- page 3 -->

. 1931

HARYANA GOVT. GAZ. (EXTRA.), NOV. 8, 2013
(KRTK. 17, 1935 SAKA)

3.

-341

"firt-./1.TIWRIETF" 7164 u161

IP 31171

WT9 TH,

f+--zrr 1I rr 1
3 tfT1T, LIR items

4.

#&.41 7

iT111#, v§11-9T 3

VrOWTftfff c61

"(i)
11

1-11-q 1 SIItc1
f{
10+2);"

1e14

ilTri#, UT-9T 372TT 4

tA

10+2 TIT f
01dir4 #140

4741 Ti-C4:11 8

PE'44-11,1

(i)

3Traft-qu 3TR:11 Thr'i <711 14—
10+27TT

q141
e-1104) ZIT Tir .

(i)

"RR (101 f

11d-T4

(ii) •ftzlii 9
t I" 1

3H-1 chi

*cH do it4t/#*-cirt -cb-r

(iii)
511•1;

(iv) FfiEFf 9

4711 7

-altr

* I" I
c6) '44T 3N

(i) 10+2 zIT 49T

1.11 ii+il~l

10+2;

FA:0-w # 4)41 g 31.74711
A-oir
-crq ER gi-cr
3T21-4T ci Tr 31ThR' Ef 40
cft1 3T-Tra;
14i-c1 c1 I r

/ 111(V1

qi)L-1 cry•

+2.1F1

d•-14-11.1

51I 1;

(iii) ffizfli 9

H1-1 4-1

(ii) *ft Tr

.(14-11-;
( ii)

\"11c1ct) TIT *+1 cti TWIT&

3Ttif-d;:—

Trq vi'd-wrft-d

ITV

-Eft .1+.-11 R5c-1

(i)

zmfq-:—

4urf—I;
ifkgrff c1)1-1 cM.

-srur-. TA* 6N1.11 ‘-kct)k,

ft3TrTr, utrT11

<!-- page 4 -->

1932

HARYANA GOVT. GAZ. (EXTRA.), NOV. 8, 2013
(KRTK. 17, 1935 SAKA)
[Authorised English Translation'

HARYANA GOVERNMENT
HEALTH DEPARTMENT
Notification
The 8th November, 2013
No. G.S.R. 32/ConstJArt.309/2013.—In
exercise of the power conferred by the proviso
to article 309 of the Constitution of India, the Governor
of Haryana hereby makes the following
rules to further amend the Haryana Health Directorate Ministerial (Group C) Service Rules, 1983,
namely :1.
These rules may be called the Haryana Health Directorate Ministerial (Group C)
Service (Amendment) Rules, 2013.
2.

In the Haryana Health Directorate Ministerial (Group C) Service
Rules, 1983
(hereinafter called the said rules), after rule 9, the following rule shall be inserted, namely:—
"9A. (1) Typing test is substituted with the State Eligibility Test in Computer
Appreciation and Applications (SETC) as a part of service requirement for
Clerks, Steno-typists, Junior Scale Stenographers and Senior Scale
Stenographers. The State Eligibility Test in Computer Appreciation and
Applications (SETC) shall be a post requisite condition/qualification which
all the newly recruited/appointed Clerks, Steno-typists, Junior Scale
Stenographers and Senior Scale Stenographers in the Government
Departments/Organizations shall have to qualify. The existing Clerks, who
have been promoted from Group-D and Restorer etc. who have not passed
the typing test till date as required under the Service Rules shall have an
option either to pass the typing test or the State Eligibility Test in Computer
Appreciation and Application (SETC). The Steno-typists, Junior Scale
Stenographers and Senior Scale Stenographers shall also have to qualify
stenography tent as prescribed in the Service Rules.
(2) The candidate shall have to qualify the State Eligibility Test in Computer
Appreciation and Applications (SETC) within the probation period of two
years, extendable by one year in case of direct recruit. The candidate
appointed against the aforesaid categories of posts in Group C shall not be
entitled to earn any increment in his/her pay scale till he/she qualifies the
said test, failing which the services of such employees shall be dispensed
with. The persons who are promoted to the post of Clerk and Steno-typist
shall also qualify the State Eligibility Test in Computer Appreciation and
Applications (SETC) within the period of probation of one year extendable
by one year, failing which he/she will be reverted back.
(3) The Government of Haryana hereby authorizes the Haryana State
Electronic Development Corporation Limited (HARTRON) or any other
agency as prescribed by the Government, as the authorized Agency for
conducting the State Eligibility Test in Computer Appreciation and
Applications (SETC), alongwith a test in typing speed in accordance with
the syllabus as the State Government may specify in this regard from time
to time, besides the syllabus already provided in sub-rule (4) of this rule.

<!-- page 5 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 8, 2013
(KRTK. 17, 1935 SAKA)

1933

The 'pass' certificate issued by HARTRON or any other agency, as
approved by the Government, would be accepted as an evidence of the
fulfilment of the prescribed condition in the Service Rules.
(4) The syllabus for the State Eligibility Test in Computer Appreciation and
Applications (SETC) would contain Word processing, Internet Browsing
and E-mail management only.
(5) In the case of Clerks, typing speed of 30 words per minute in English and
25 words per minute in Hindi converted with equivalent key depressions ;n
both cases as the typing speed, would be tested on computers.
(6) The employees possessing the following qualifications are exempted from
taking the State Eligibility Test in Computer Appreciation and Applications
(SETC):(i)

M. Tech./B.Tech. (Computers), M.C.A., B.C.A. or Diploma in
Computers from the recognized institutions e.g. Polytechnics;

(ii)

Basic Computer Literacy Certificate from any recognized centre
established under the National Institute of Electronics and
Information Technology (NIELIT) [erstwhile DOEACC Society];

(iii) Haryana State – Certificate in Information Technology [HS-CITJ
from the Authorised Learning Centres (ALCs) of the HKCL;
(iv) Candidates/employees who have already passed the SETC and the
same is valid at the time of joining the service. The State Eligibility
Test in Computer Appreciation and Applications (SETC) passed by
any candidate earlier shall be considered valid for a period of five
years from the date of issue of such certificate by HARTRON or any
other agency authorized by the Government; and
(v)

Physically disabled candidates i.e. amputation of hand (left and Right)
Amputation of upper limbs, Paralysis of Radial Nerve (Radial Nerve
Palsy) of either upper limb. Declination degenerative disorder
effecting the nervous system which may cause paralysis and atrophy
of the hand and its muscles and Visually Handicapped.
However, these employees, with the exception of those mentioned
under sub-para (v) above, shall be required to clear the 'typing test'
being part of the State Eligibility Test in Computer Appreciation and
Applications (SETC).".

3. In the said rules, for the words "Clerk/Store-keeper" wherever occurring, the word
"Clerk" shall be substituted.
4.

In the said rules, in Appendix B,—
I

against serial number 7, under column 3, for existing item (i), the following item
shall be substituted, namely:—
"(i) 10+2 or Graduate or its equivalent (For ex-servicemen 10+2 only)";

<!-- page 6 -->

HARYANA GOVT. GAZ. (EXTRA.), NOV. 8, 2013
(KRTK. 17, 1935 SAKA)

1934

II

against serial number 8, under columns 3 and 4, for the existing items, the
following items shall be substituted, namely:—

In the case of other than ex-serviceman(i)

10+2 or Graduate from a recognised
University or its equivalent;

(ii)

Knowledge of Hindi/Sanskrit upto
Matric level;

(iii)

Omitted in view of rule 9A.

(i)

10+2;

(ii)

Five years' experience on any group
C posts whose scale of pay is less
than that of a Clerk, or any Group D
post or combined experience on
Group C and Group D posts;

(iii)

Knowledge of Hindi/Sanskrit upto
Matric level;

(iv)

Omitted in view of rule 9A.

In case of ex-serviceman:(i)

10+2 or fifteen years service in
the Army and Army Certificate
Class-I.

(ii)

Omitted in view of rule 9A.

NAVRAJ SANDHU,
Principal Secretary to Government Haryana,
Health Department, Chandigarh.
