---
doc_id: "e36fcf7efc22eca4"
source_url: "https://cdnbbsr.s3waas.gov.in/s3b2ab001909a8a6f04b51920306046ce5/uploads/2026/10/20261023967520486.pdf"
ministry: "Elementary Education Department, Haryana"
title: "Transfer/Adjustment/Guest/Misc. Orders. (23.10.2026)"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6e89b1f2cd85b248"
---

<!-- page 1 -->

Directorate of Elementary Education/~--

GOVERNMENT OF HARYANA/~ ~

__
~.~'l't-....

Directorate of Elementary Education

~tmr~

....ml",_"-

~. ~~ ~c fro~~~kness to Light

e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Dated, Panchkula, the 16.10.2026

Order No. 08/434·2026 D&L (1)

Smt. Mukesh Rani (063719), TGT Sanskrit, GHS Mattershhyam
(1247), Distt. Hisar is hereby granted the following leave:Rules applicable
From
Sr.No. Name of
Leave
As per Rule-46 of Haryana Civil Service
21.10.2026
Child
(Leave) Rules, 2016 and Finance
to
1.
care
Department Notification No. 11/12/2021
leave
29.12.2026
(70 Davs)
3FR/25615 Dated 23.02.2023.
With permission to Affix/Suffix holidays.
1.
2.

3.

4.

That the official would have continues to officiate in class-III during her
proceeding on leave with permission to Affix/Suffix holidays.
That she would draw the usual HRA and other allowances during the period of
leave and she is likely to return to the post to which these allowances are
attached.
That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
That alternate arrangement be made before employee's going on CCl so that
there would be no adverse effect on the studies of the students.

Monika (HCS)
Joint Director (Admn. & MOM)
Directorate of Elementary Education
Haryana, Panch kula
Endst. No. Even:

Dated, Panchkula, the

,q 1/0/2 b

A copy is forwarded to the following for information and necessary action:1. District Elementary Education Officer, Hisar w.r.t. their Memo No.
E·1I/2026/2340 Dated 09.10.2026 to make compliance with order.
2. Accountant General (A&E) Haryana, Chandigarh
3. Principal/Head Master, GHS Mattershhyam (1247), Distt. Hisar.
4. Smt. Mukesh Rani (063719), TGT Sanskrit, GHS Mattershhyam (1247),
Distt. Hisar.
~ IT/Cell.

k

I

,

Eduution, Culture ,nd Development I

~:y

Supe ntendent, D&L
for Director Elementary Education,
'-4iaryana, Panchkula

<!-- page 2 -->

Directorate of Elementary Education !~T\;'l--

GOVERNMENT OF HARYANA/6ftmurr m<fiR

Directorate of Elementary Education

~fmr~
e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Order No. 08/423-2026 D&L (2)

Dated, Panchkula, the 16.10.2026

Smt. Nisha Rani (6009264), TGT Science, GCSSS Mithi Sureran
(3046), Sirsa hereby granted the following leave:i

Sr. No. Name of Leave
Child Care
1.
Leave

From
16.10.2026 to
30.12.2026
(76 days)

i

Rules applicable
As per Rule-46 of Haryana Civil Service
(Leave) Rules, 2016 and Finance
Department Notification No. 11/12/2021- i
3FR/25615 Dated 23.02.2023.

-

With permission to Affix/Suffix holidays.
1.
2.
3.
4.
5.

That the official would have continues to officiate in class-Ill during her
proceeding on leave with permission to Affix/Suffix holidays.
That she would draw the usual HRA and other allowances during the period of
leave and she is likely to return to the post to which these allowances are attached.
That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
That alternate arrangement be made before employee's going on CCL so that there
would be no adverse effect on the studies of the students.
Child care leave shall be admissible during the probation period, provided that probation
period shall be extended by the period of child care leave availed.

Monika, HCS
Joint Director, (Admn. & MDM)
Haryana, Panchkula
Endst. No. Even:
Dated, Panchkula, the /q /!tJ)L 6
A copy is forwarded to the following for information and necessary action:1.
District Elementary Education Officer, Sirsa W.r.t. their Memo No. E6/2026/5558 dated 28.09.2026 to make compliance with order.
Accountant General (A&E) Haryana, Chandigarh.
2.
Principal/Head Master, GGSSS Mithi Sureran (3046), Sirsa.
3.
Smt. Nisha Rani (6009264), TGT Science, GGSSS Mithi Sureran
4.
(3046), Sirsa.
IT/Cell

~~

Superintcnd;nt D&L
for Director Elementary Education,
~aryana,Panchkula
'. A it 2Q26\Amit 2Q26\Sanction 2Q26\CCL 2Q26.doc
-----!-----otr.:-Shikshasa-daTr,Sedor5-;-Pam:hkula,Haryamr1341'09ilndia)-"Te-1:-91i01i'2)256024OFax:-9t(OT72)2560253r-------t~: ~Jmff0. ~ 5 ~-134109(lTml)~: 9-1P172)2580246 $m: 91(0172)2580253

<!-- page 3 -->

- - - - - - - - - - - - - - - - - - - - - - - - - - - - Directorate of Elementary Education / ~ fu;r ~

GOVERNMENT OF HARYANA / ~ ~

~TT, ~ ~ fct<:nm
Education, Culture and Development

Directorate Elementary Education

;ftfWp fmr ~~

<f<1fjl "IT ~fu"r~

Lead me from Darkness to Light

E-mail: eduprimaryhry@gmail.com - Site: www.harprathmik.gov.in

Order No. 8/416-2026 D&L (1)

Dated, Panchkula, the 19.10.2026

Smt. Deepshikha (6004481), TGT Science, GMS Bhogpur (3743), District
Panchkula is hereby granted the following leave:Name of
From
Leave
Child care
21.10.2026 to 05.12.2026
(~g days)
leave
WIth perrmsslOn to Affix/Suffix holidays.

Sr.
No.
l.

Rules applicable
As per Rule-46 of Haryana Civil
Services (Leave) Rules, 2016

1.

That the official would have continues to officiate in class-III during her proceeding
on leave with permission to Affix/Suffix holidays.
2.
That she would draw the usual HRA and other allowances during the period of leave
and she is likely to rehlrn to the post to which these allowances are attached.
3.
That the officer/official would have continued to officiate in Class-llJ hut she
proceeds on leave during above period.
4.
That alternate arrangement be made before employee's going on CCL so that there
would be no adverse effect on the studies of the students.
Note- If any official shall remain on CCL more than 90 days then her post will be
considered as vacant. The official on return from CCL shall report to the
Directorate for further posting.
Monika, HCS
Joint Director Admn.
Directorate of Elementary Education
Haryana, Panchkula

I qIto /26

Endst. No. Even:
Dated, Panchkula, the
A copy is forwarded to the following for information and necessary acti6n:Regd.
1.

_

District Elementary Education Officer, Panchkula W.r.t. their Memo No. E-IIl/2026/256
dated 06.10.2026 and directed to arrange the specific alternate arrangement for smooth
functioning of education classes during the above mentioned CCl period.

2.

Accountant General (A&E) Haryana, Chandigarh.

3.

Principal/ Head Master, GMS Bhogpur (3743), District Panchkula.

r~~eepShikha (6004481), TGT Science, GMS Bhogpur (37430:~:::hkUla

supel~tendent

D&L
for 'Qi~ector Elementary Education
~aryana, Panchkula
E:\Amit 20261NK- 2026 dataID&Llccl,going abroadlCCL Sanclion.docx
Office: Plol No. 1B. Shiksha Sadan, Sector 5, Panchkula, Haryana 134109 (Indi,,) - Tel: 91(017~).256D189 Fax: 91(0172)-2560188
ifITIlfor!l: ijw,c '10 ,1ft. ~r 'fflT'f, ~R'I 5 ~H34'09 t~lffi) 'iY'lJ1l . )1 (0172) 2560189 ~. 91 (0172) 2560188

<!-- page 4 -->

Directorate of Elementary Education/~--

GOVERNMENT OF HARYANA/~ ~

Directorate of Elementary Education

fmrr, ~ t:!ei F<roorn
Educa[ion, Culture and Developmen[

~~~

<fl'fffi-'lT~

e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Lead me from Darkness to Light

Order No.

08/164-2026 D&L (3)

Dated, Panchkula, the 16.10.2026

In continuation of this office order No. 08/164-2026 D&L (3) dated
16.07.2026, the child care leave Smt. Seema

(1003978), TGT Math, GSSS

Garouli Khurd (757), Distt. Gurugram is hereby extended w.eJ. 24.10.2026 to
24.12.2026 (62 days) subject to fulfillment of the provisions of Rule-46 of Haryana
Civil Service (Leave) Rules, 2016 and Finance Department Notification No.
11/12/2021-3FR/25615 Dated 23.02.2023.

Endst. No. Even:

Monika, HCS
Joint Director, (Admn. & MDM)
Haryana, Panchkula
Dated, Panch kula, the Il/X/#"£

A copy is forwarded to the following for information and necessary
action:Regd.
1.

District Elementary Education Officer, Gurugram.

2.

Accountant General (A&E) Haryana, Chandigarh.

3.

Principal/ Head Master, GSSS Garouli Khurd (757), Distt.
Gurugram.

4.

o

Smt. Seema (1003978), TGT Math, GSSS Garouli Kurd (757),
Distt. Gurugram.
IT/Cell

L~;-.;

superin~endent D&L

for Director Elementary Education
~aryana, Panchkula

i

I

----J----~~~~~~~~~~~~-_::_~~==============-+I
E:\Amil 2n26\NK~ 2026 data\O&L 8rallch\NK 202S\2026\CCL Extend 2026.doc

~_..i-

_ _ _\------{)tr.:-ShikshaSau<ITI.Se-ctor5;"1"am:hkota;1taryamrt3"41 091lndiar=-'f-er.-91iOtn)2S60246""FaJr.9ttOt72)256025-:l
..

~: ~. ~ 5 ~-134109t'fml)~ : 9-1t>m):2560240 m: 91(0172)2560253

1

<!-- page 5 -->

Directorate of Elementary Education /~rfc1l{-

GOVERNMENT OF HARY ANA/~ "ffiCIlR

Directorate of Elementary Education

~n, ~ "f"i t>r"""
Education, Culture ...nd Devldopment

~fm"~
e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Dated, Panch kula, the 16.10.2026'

Order No. 08/315-2026 D&L (1)

Smt. Sarita Kumari , TGT Sanskrit, GSSS Niyamatpur (3943), Distt.
Narnaul hereby granted the following leave:;

Sr. No. Name of Leave
Child Care
Leave
1.

From
17.10.2026 to
29.12.2026
(74 days)

,I
Rules applicable
As per Rule-46 of Haryana Civil Service I
(Leave) Rules, 2016 and Finance i
Department Notification No. 11/12/2021- I
3FR/25615 Dated 23.02.2023.

With permission to Affix/Suffix holidays.
1.
2.
3.
4.
5.

That the official would have continues to officiate in class-III during her
proceeding on leave with permission to Affix/Suffix holidays.
That she would draw the usual HRA and other allowances during the period of
leave and she is likely to return to the post to which these allowances are attached.
That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
That alternate arrangement be made before employee's going on CCL so that there
would be no adverse effect on the studies of the students.
Child care leave shall be admissible during the probation period, provided that probation
period shall be extended by the period of child care leave availed.

Monika, HCS
Joint Director, (Admn. & MDM)
Haryana, Panch kula
Endst. No. Even:
Dated, Panchkula, the )'./0·202<A copy is forwarded to the following for information and necessary action:1.
District Elementary Education Officer, Narnaul W.r.t. their Memo No. E1/20261780 dated 09.10.2026 to make compliance with order.
2.
Accountant General (A&E) Haryana, Chandigarh.
3.
Principal/Head Master, GSSS Niyamatpur (3943), Distt. NarnauI.
4.
Smt. Sarita Kumari , TGT Sanskrit, GSSS Niyamatpur (3943), Distt.
~

Narnaul.
IT/Cell
Superintendent D&L
for Director Elementary Education,
~ Haryana, Panchkula

. Amit 202 Amit 2 2

an ti

2 2

2 26 doc

_ _ _ _t--_ _-O~hiks"haSadan;-Se"ctorS;"1'arn:trkula;_HaTYamr1"31ttO!1(trrdi<r)~-'fel~1-(01(2)2
560240f'ar91'(1l1f2)25602S3
~: ~,~ 5 ~-134109(!lml)~: 9-1~172)2560246 $m: 91(0172)2560253

,
1
I

<!-- page 6 -->

Directorate of Elementary Educalion!~I,\;l(-

GOVERNMENT OF HARYANA/~

mern

I

Directorate of Elementary Education

~tmr~
e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Order No. 08/287-2024 D&L (2)

Dated, Panchkula, the 16.10.2026

Smt. Ranju Rani, (6007832) TGT Science, GMS Bansogate (1834),
Distt. Karnal hereby granted the following leave:Sr. No. Name of Leave
Child Care
Leave
1.

From
21.10.2026 to
21.12.2026
(62 days)

Rules applicable
As per Rule-46 of Haryana Civil Service
(Leave) Rules, 2016 and Finance
Department Notification No. 11/12/20213FR/25615 Dated 23.02.2023.

With permission to Affix/Suffix holidays.
1.
2.
3.
4.
5.

That the official would have continues to officiate in class-III during her
proceeding on leave with permission to Affix/Suffix holidays.
That she would draw the usual HRA and other allowances during the period of
leave and she is likely to return to the post to which these allowances are attached.
That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
That alternate arrangement be made before employee's going on CCL so that there
would be no adverse effect on the studies of the students.
Child care leave shall be admissible during the probation period, provided that probation
period shall be extended by the period of child care leave availed.

Monika, HeS
Joint Director, (Admn. & MDM)
Haryana, Panch kula

/()l. r~

Endst. No. Even:
Dated, Panch kula, the 16
A copy is forwarded to the following for information and necessary action:1.
District Elementary Education Officer, Jhajjar w.r.L their Memo No. E1/2026/2782 dated 01.10.2026 to make compliance with order.
Accountant General (A&E) Haryana, Chandigarh.
2.
Principal/Head Master, GMS Bansogate (1834), Distt. Karnal.
'3.
Smt. Ranju Rani, (6007832) TGT Science, GMS Bansogate (1834),
4.

~

Distt. Karnal
IT/Cell

L}~

Superi~tcndent D&L
for Director Elementary Education,
Haryana, Panchkula ~

,

<!-- page 7 -->

Directorale of Elementary Educalion/>Jlf01"fllll1lf.'l~"lr'1­

GOVERNMENT OF HARYANA/~ ~

fWln.~""-'"

Directorate of Elementary Education

Educ.uion, Culture J,nd D~vt!opmut

~ftIm~
e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Order No. 08/431-2026 D&L (1)

Dated, Panch kula, the 16.10.2026

Smt. Anu (6010233), TGT Drawing, GSSS Sarhaul (0860), Distt.
Gurugram hereby granted the following leave:Sr. No. Name of Leave
Child Care
Leave
1.

Rules applicable
As per Rule-46 of Haryana Civil Service
(Leave) Rules, 2016 and Finance
Department Notification No. 11/1212021- i
['
3FR/25615 Dated 23.02.2023.

From
22.10.2026 to
18.12.2026
(58 days)

With permission to Affix/Suffix holidays.
1.

That the official would have continues to officiate in class-III during her
proceeding on leave with permission to Affix/Suffix holidays.
2. That she would draw the usual HRA and other allowances· during the period of
leave and she is likely to return to the post to which these allowances are attached.
3. That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
4. That alternate arrangement be made before employee's going on CCL so that there
would be no adverse effect on the studies of the students.
5. Child care leave shall be admissible during the probation period, provided that probation
period shall be extended by the period of child care leave availed.

Monika, HCS
Joint Director, (Admn. & MDM)
Haryana, Panch kula

~

Endst. No. Even:
Dated, Panchkula, the 16f<)
A copy is forwarded to the following for information and necessary action:1.
District Elementary Education Officer, Gurugarm W.r.t. their Memo No.
E-1/2026/1749 dated 20.08.2026 to make compliance with order.
2.
Accountant General (A&E) Haryana, Chandigarh.
3.
Principal/Head Master, GSSS Sarhaul (0860), Distt. Gurugram
4.
Smt. Anu (6010233), TGT Drawing, GSSS Sarhaul (0860), Distt.
Gurugram
IT/Cell

~b 'Y(

Superi ten dent D&L
for Director Elementary Education,
Haryana, Panchkula L
.

mi 2 2 Arn't 2 2

anen n 2 2

2 2

e

<!-- page 8 -->

- - - - - - - - - - - - - - - - - - - - - - - - - - Diroctorate of Elementary Education /

GOVERNMENT OF HARYANA / ~ ~

r~

m~

~nm, ~ l:f<'l' f4cfin::r
Education, Culture and Development

Directorate Elementary Education

~~~~~
E-mail: dandlbranch6@gmail.com - Site: www.harprathmik.gov.in

Order No. 03/22-2026 D&L (1)

Dated: 15.10.2026

Sh. Rajeev, DPE (5019733), GMSSSS Khairi (2321), District Kurukshetra
who was placed under deemed suspension w.e.f. 19.06.2026 vide order No.
03/22-2026 D&L(3) dated 17.07.2026, is hereby reinstated without prejudice to
disciplinary action pending against him and also without prejudice to the decision
to be taken regarding the period for which he has remained under suspension.
Upon re-instatement, he is posted in GMSSSS Khairi (2321), District
Kurukshetra against a vacant post subject to the condition that he will participate
in next transfer drive.

Manita Malik, lAS
Director of Elementary Education
Haryana, Panch kula
Endst No. Even
Dated Panchkula the, 16.10.2026
A copy is forwarded to the following for information and necessary action:Regd.
1.
Accountant General (A&E) Haryana, Chandigarh.
2.

Deputy Commissioner, Kurukshetra W.r.t. Elec-2026/745 dated 24.08.2026.

3.

District Elementary Education Officer, Kurukshetra with a direction to join
the incumbent in said school and report may be sent through email.
dandlbranch6@gmail.com and also directed to send draft of charge sheet
against the official within 3 days positively. Further, the suspension
allowance of the incumbent be released w.e.f. 19.06.2026.

4.

District Elementary Education Officer, Sonepat.

5.

Principal, GMSSSS Khairi (2321), District Kurukshetra.

6.

Sh. Rajiv, DPE (5019733), GMSSS Khairi (2321), District Kurukshetra.

7.

PA /DGEE.

~ 1.T. Cell (HQ)

n
super~ent

nb<"?(D&L)

for I}i~ector Elementary Education,
.
Cf Haryana, Panchkula

E:\Amit 2026\NK- 2026 data\D&L Branch\NK 2025\2026\English Folder Order\Suspension
orders latest.docx

_

<!-- page 9 -->

Directorate of Elementary Education /~~I[(.I'l--

GOVERNMENT OF HARYANA/~ tRCIiN

Directorate of Elementary Education

tmlT, ~ q<I I'r»;m
Education, Culture :J.lld De....elopmcot

~ftIm~
e-mail: eduprimaryhry@gmail.com - site: www.hamrathmik.gov.in

Order No. 08/111-2026 D&L (1)

Dated, Panch kula, the] 6.1 0.2026

Smt. Suman, (6008505) TGT Art, GSSS Talao (3260), Distt. Jhajjar
hereby granted the following leave:I

Sr. No. Name of Leave
Child Care
Leave
1.

From
21.10.2026 to
30.12.2026
(71 days)

I

Rules applicable
As per Rule-46 of Raryana Civil Service i
(Leave) Rules, 2016 and Finance
Department Notification No. 11/12/20213FR/25615 Dated 23.02.2023.

With permission to Affix/Suffix holidays.
1.

2.
3.
4.
5.

That the official would have continues to officiate in class-III during her
proceeding on leave with permission to Affix/Suffix holidays.
That she would draw the usual HRA and other allowances during the period of
leave and she is likely to return to the post to which these allowances are attached.
That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
That alternate arrangement be made before employee's going on eCL so that there
would be no adverse effect on the studies of the students.
Child care leave shall be admissible during the probation period, provided that probation
period shall be extended by the period of child care leave availed.

Monika, RCS
Joint Director, (Admn. & J\1DM)
Haryana, Panchkula
Endst. No. Even:
Dated, Panch kula, the Jq If ol2C,
A copy is forwarded to the following for information and necessary action:1.
District Elementary Education Officer, Jhajjar W.r.t. their Memo No. E1/2026/1396 dated 01.10.2026 to make compliance with order.
2.
Accountant General (A&E) Haryana, Chandigarh.
3.
Principal/Head Master, GSSS Talao (3260), Distt. Jhaj,jar .
4.
Smt. Suman, (6008505) TGT Art, GSSS Talao ~260)'Distt. Jha.jjar.

~ IT/Cell

1

i

-------tI

V'-Superi tendent D&L
for Di!:..e~r Elementary Education,
V"'Haryana, Panchkula
'

E'\Amit 2Q26\Amit 2Q26\Sanction 2Q26\CCL 2Q26.doc
- - - - - - - ---. --_ _-!-!----IOff::-$-hikshasa"dan-;-Se-ctor5-;-Pancnkula;-tlaryana1'3'41 09-(lrrdra")~4"e-1:-9t{01"?2)2560246-FaX:-9l(01"?2)2560253--------- -i-'-

I

~: ~. ~ 5 ~-1341D9(>lm1)~: g.1:Qlm)2560246 $ffi: 91(D172)256D253

<!-- page 10 -->

Directorate of Elementary EdUCatiO~ / l()r.tili~~If.'l~lllr

GOVERNMENT OF HARYANA/~ m<IiR

Directorate of Elementary Education

~fmT~

~,~"",.,....,.
Education, Culture and Development

""'""'-

Lead m.~ from D~ess to Light'

e-mail: eduprimaryhry@gmail.com - site: www.harprathmik.gov.in

Dated, Panch kula, the 16.10.2026

Order No. 08/428-2026 D&L (2)

Smt. Sharmila, TGT English, GGHS Lohani, Distt. Bhiwani is hereby
granted the following leave:Rules applicable
From'
Sr.No. Name of
Leave
As per Rule-46 of Haryana Civil Service
Child
20.10.2026
care
(Leave) Rules, 2016 and Finance
1.
to
Department Notification No. 11/12/2021·
leave
28.12.2026
(70 Days)
3FR/25615 Dated 23.02.2023.
With permission to Affix/Suffix holidays.
1.
2.

3.
4.

That the official would have continues to officiate in class-III during her
proceeding on leave with permission to Affix/Suffix holidays.
That she would draw the usual HRA and other allowances during the period of
leave and she is likely to return to the post to which these allowances are
attached.
That the officer/official would have continued to officiate in Class-III but she
proceeds on leave during above period.
That alternate arrangement be made before employee's going on CCl so that
there would be no adverse effect on the studies of the students.

Monika (HCS)
Joint Director (Admn. & MDM)
Directorate of Elementary Education
Haryana, Panchkula
I

Dated, Panch kula, the;21 J/o/}

Endst. No. Even:

A copy is forwarded to the following for information and necessary action:1. District Elementary Education Officer, Bhiwani w.r.t. their Memo No.
E-11/2026/424 Dated 09.10.2026 to make compliance with order.
2. Accountant General (A&E) Haryana, Chandigarh
3. Principal/Head Master, GGHS Lohani, Distt. Bhiwani.
4. Smt. Sharmila, TGT English, GGHS Lohani, Distt. Bhiwani.

~ IT/Cell.

~ ,'~

Superin endent, D&L
for Director Elementary Education,
~aryana, Panch kula

'n22

L2

D

----+-----off;:-st1iikshaSa1jaarrr,I'SlSe~cllolor-S5,;-f'P'a.rallC1lclrlklkuul1lar,1, arry.
y:amr134t091l"dia) • Tel. 91 (0 172)2560246 Fax. 91 (0 172)25'60253
~ ~. ~ 5 ~-134109(>lm!)~: 9-111472)2560246 1ffil: 91(0172)2560253
HHil'

~

I
I

I

<!-- page 11 -->

- - - - - - - - - - _ - - - - - - - - - - - - - - DirecloraleofElemenlaryEducation / ~ ~~---

GOVERNMENT OF HARYANA / ~ ~

~, ~ qcf

Directorate Elementary Education

;ft~fmT~~

fctcnrn

Education, Culture and Development

tf'mT -.:rr ~"IRI'\'i'"l
Lead me from Darkness to J -ight .

----_._- ---E-mail: eduprimaryhry@gmail.com - Site: www.harprathmik.gov.in

Regd.
From
Director Elementary Education
Haryana, Panchkula
To
District Elementary Education Officer
Kaithal
Memo No. 07/249-2026 D&L (1) .
Dated, Panchkula
Subject:-

Regarding the permission/NOC to go abroad to Sh. Rajesh Kumar
(1024723), JBT, GPS Lender Kima (13896), Distt. Kaithal.
************

Kindly refer to your office memo no. E-IIi/2026/5310 dated 06.10.2026 on the
subject cited above.
The Permission/NOC to go abroad is hereby granted to Sh. Rajesh
Kumar (1024723), JBT, GPS Lender Kima (13896), Distt. Kaithal from 15.11.2026
to 31.12.2026 (47 days Earned Leave) on following terms and conditions:1. He/She will visit Australia from 15.11.2026 to 31.12.2026 (47 days Earned
Leave) after getting the leave sanctioned from the competent authority and will not
get the leave extended while being abroad.
2. He/She will hand over his/her charge to the senior most teachers as the case may
be before proceeding on leave.
3. He/she will bear all the expenses on the said tour from his/her own pocket and the
State would not bear any expense incurred by him/her.
4. He/she will not accept any assignment by any Govt. or the NGO or anybody while
on foreign visit.
5. He/She will not be doing any such activity which may be detrimental to the
bilateral relations of India with the said country (s) being visited by him/her.
6. He/She will not be doing anything, which may be termed as detrimental to the
sovereignty of India.
7. He/She will not be inviting any liability during his/her stay at abroad which may
result into losses to Govt. in any matter.
S.lf any, criminal case/Departmental Proceeding (s) is filed againt teacher from the
date of issue of present permission to go abroad till the date of departure, then the
permission to go abroad will be stand cancelled automatically.
9. The other terms and conditions will be same W/Additional Chief Secretary to
Govt. Haryana Finance Department letter No. 07/08-2010-4FR/18354 Dated
15.10.2025 which mentioned on point no. 2 (C) 1 to 10.

,<""\!r! r
Superintendent (D&L)
for Director Elementary Education
.
Haryana, Panchkula
Endst No. Even
Dated, Panch kula, thec9J
A copy is forwarded to the following for information and necessary action:Principal/HeadMaster/Mistress, GPS Lender Kima (13896), Distt. Kaithal.
1.
2.
Sh. Rajesh Kumar (1024723), JBT, GPS Lender Kima ~96)' Distt. Kaithal.
I.T. Cell
\1
Office Copy .
't:.4.
Superi endent (D&L)
for Director Elementary Education
"" Haryana, Panchkula

Iloilo

./S

1:::\AI11I1 11)1(l\N"- )ll>'; i1:o1:o\I).~·' Hr·",,-l, 1\,\1( If}),,\JI))/,lj :.•;...... J.". ".,,1 (',·.1 ... -,.,.- I... ~

<!-- page 12 -->

GOVERNMENT OF HARYANA/~ ffiCPR

Directorate: Elerl1e~ntaty Edllcation,
Hary"ana
Tf)~ ftnm' ~llT{iI1l ~

f:lTl!IT, ~(1!f\'f ~ f<l'li1i'l

Education, Cultt!\"(~ ~lId Dcv::lopmcnt

I

-

~.,-;

~

.,.

.
t:!;
fim:wl N, ~~r . ,Z',.,

'. ~n.Q.Ql.'~u£~tio.n,,H"'Yal!~'

~

.1,

~

'f'f{-!t ljf wllf'cr\t!ll

\~.

.

Lead me jj'om Darkness to Light

----------_._----

ORDER NO: 05/21 ~2026 TGl Pro, (2)

DATED, PANCHKUlA, THE 12.10.2026

VVhereas, the following teacher who was earlier allotted station vide Directorate
Order No. 15/17-2024 TGT Pro(2) dated 06.02.2026 after promotion from the post of .JBT to
the post of TGT English. Now, he has requested vide his representation to forgo/revert from
said promotion.
Hence, considering upon his representation he is hereby permit to ior90/revert
his promotion from the post of TGT English as per provision of rule, 31 of HCS (General)
Rules. 2016 & Rules 14 of HCS (ACP) Rules, 2016. The details is as under:-

~.
I

1.

l
Name
of
the Place of posting as TGT
Remarks
I
English
Employee(ID)
Sh. Rajesh Kumar Government
Girls
Senior . Forgo/reverted as JBT
(1029994)
Secondary School Ellenabad i
(Sirsa) [3051]
i
I

I
I

L

I
Note:

1.The further posting order of abovesaid teacher wil! be deddJedJ by
DEED concerned being appointing-cum- competent authority,

Monika, HCS
Joint Director Administration
0/0 Director Elementary Education
Haryana, Panchkuia

ENDST No. OS/21-2026 TGT Pro.(2)

DATED, PANCHKUlA, THE /1... {~ . ?--'"

A copy of above is forwarded to the follOWing for information and further
necessaryaction:i. Accountant General (A&E) Haryana, Chandigarh.
2. District Elementary Education Officer Sirsa.
3. DEEO Hisar with direction to take further necessary action as per Sub rule 14 of

HCS (ACP) Rules, 2016 under intimation to this office.
4. PA StaffNV/Joint Director Admn.
5. Head of the institutions, Concerned.

6. Official, Concerned.
~T. Cell, HQ for uploading the orders on the official website.

8. PRT/ART.
9. Spare copy for the main file of TGT English promotion.

.-

Administrative Officer

for Dir~ctor Elementary Educatioll1l
'1.4 Hnryana, J>andnkula

O-\Allmad Slr\Promotion Forgo ORDERS.doc

OHi;;~.: Plot No. 16, Shil,,;na Sadan, Seclor 5, Panchl<lIla. Haryana 134'109 (India) - Tel: 9·I(0'l72)..25G024G F·,w· "Hln;-,'" '>c.'"',,'''
'i"lIj\<P~: <mIG"'fD 1~1. ~llffr -<fi:.T ·.IIm"" "n7(=" •n" "" ,,,......, .. -

<!-- page 13 -->

GOVERNMENT OF HARYANA/6ftm'un "fR'ifiR

Directorate EleUle,ntary Edllcation~
lIaryana
tti~ ftIan' ~~ ~

~lT, ~ ~ Fcl'l1ffi
Educatioll, Culture and Devdopmtnt
I

"

~~~SC~OOlJ,dll~ati9!1' tl~fY~na )i'.ii
~,~J f<ttlrn'! f~[(jrr, ~1"I'f

'lUi

__i1'ffit
- _0_-'1T ~1ITr'M<r
.
Lead me from Darkness to Light

(TO BE SUBST!TUTED BEARiNG SAME NO. AND DATE)
O~DER NO: 05/31·2026 TGl Pro. (2)

DATED~ PANCHKUlA, THE 14.10.2026

V\/hereas, the following teachers who were earlier promoted vide Directorate
Order No. 05/07-2023 TGT Pro (2) dated 24.06.2024 and 13.08.2024 to the post of TGT
Physical Education from PTi(C&V). Now, they have requested vide their representations to

forgolrevert from said promotion.
Hence, considering upon their representations they are hereby permit to
forgo/revert their promotion from the post of TGT Physical Education as per provision of

rule, 31 of HCS (General) Rules, 2016 & Rules 14 of HCS (ACP) Rules, 2016. The details is
as under:-

ISLNO.

i

1.

Name
of
Employee(ID)

the

Sh. Nitin (5022758)

I-~Sh.

I

Present Place of posting as
TGT Physical Education
GHS Bugana(1194), Hisar

II
j
Fargo/reverted as PTI i

1

(C&V)

Rohtash

F orgolreverted as PTI
ii
(C&V)

GSSS Neoli Kalan (Hisar).

(5022481)

Note:

Remarks

._--- I

'i .The further postin91 order of abovesaid teaclher shaH be dlecndJed by
DEEO Hisar being appointing~cumucompetent a~thority.

Monika, HCS
Joint Director Administration
0/0 Dnrector Elementary EducaUon
lHaryana, PanchlktllllclJ
i ~

;

DATED. PANCHKUlA, THE! . "l') - ~

ENDST No. 05/31-2026 TGT Pro.(2)

A copy of above is forwarded to the following for information and further
necessary action:-1. Accountant General (A&E) Haryana, Chandigarh.
2_ District Elementary Education Officer Hisar with direction to take further
necessary action as per Sub rule 14 of HCS (ACP) Rules, 20'16 under intimation
to this office,.

3. PA StaffNV/,Joint Director Admn.
4. Head ofTO the institutions, Concerned.

5_ Official, Concerned.
~Cell, HQ for uploading the orders on the official website.

7. Assistant l\lo. 1 for seniroity.

8. Spare copy for the main file of TGT Phy. Education promotion.
"

\\'\
I

'-

./" \ ,

~

_

~

AdministraHvc OHker

for Dnrector E~cmclr1ltary EdllJlcaUnm::
f- Hm-yamlL, JP21nd]~mll:,n
<

!

O:\Ahmad Sir\Prornotion ~orgo ORDERS.doc

Oftice: Plot No, 1B, Shil<sha Sadan, Sector 5, Panchl<Ula, Haryana 134109 (India) - Tel: 91(0172)-2560246 Fa)(: !l1(017L)-25G0251
rn17ff;-;rn'

i'i-nlr;r ;'fn

-\ii\

hll1lH "J".l?";;J

~;1;-.1"J I; ri~I;=f

~'.l.'''rln 1-r'r:1~\ -:r:'>'.... ..,.' •

" ..

f.............\ ,.,.............

,.~~-............

I .. .•_.... \

.......... " .. -

<!-- page 14 -->

GOVERNMENT OF HARYANA/~ ~

Directorate Elementa-ry Education)
Haryana
lfi~~~~~
ORDER NO: 15/23-2026 TGT Pro. (2)

:::-~_ ('j~_~~ _f:l~Education. Culture aod Development

<f'ffit"'lT ~

-1eal!~e~!i:~m D8Ikne~s toLight

DATED, PANCHKULA, THE 12.10.2026

Whereas, the following teacher who was placed at the disposal of the Directorate
of Elementary Education after forgo/reverted from the post of PGT Hindi to C&V Hindi for
station allotment vide memo No. 04/17-2026 PGT-I (1) dated 03.08.2026. The detail of the
teacher is as under:-

Sr.No. Name
of
the Place of posting as PGT Hindi
Employee(ID)
Ms.
Lalita Rani GSSS, Uncha Samana, District
1.
(099852)
Kamal

Remarks
Forgo/Reverted as
C&V Hindi

Note:- Hence, the DEEO concerned is directed to decide the further
posting order of abovesaid teacher as C&V Hindi being appointing-cumcompetent authority.

Monika, HCS
Joint Director Administration
0/0 Director Elementary Education
Haryana, Panchkula

DATED,PANCHKULA,THE\r:fo'>O~

ENDST No. 15/23-2026 TGT Pro.(2)

A copy of above is forwarded to the following for information and further
necessary action:1. Accountant General (A&E) Haryana, Chandigarh.
2. District Elementary Education Officer Kamal with direction to take further
necessary action as per Sub rule 14 of HCS (ACP) Rules, 2016 under intimation
to this office.
3. PA StafflW/Joint Director Admn.
4. Head of the institution, Concerned.
5. Official, Concerned.

~Cell, HQ for uploading the orders on the official website.
7. PRT/ART.
8. Spare copy for the main file of TGT English promotion.

~

Administr~r

for Director Elementary Education
.:;4 Haryana, Panchkula

I1

D:lAhmad SirlPromotion Forgo ORDERS.doc

Office' Plot No. 1B Shiksha Sadan, Sector 5, Panch kula, Haryana 134109 (India) - Tel: 91(0172)-2560246 Fax: 91(0172)-2560253
.

~

U;;rr;7;::rn -i~ 9nrn ~ ~.c:: ~

.".l'AAnn

I-rrr.r=r' ~'t'l1tI"

.......

(,. ........\

...

~...........

~

_.

1-.--\ -------

<!-- page 15 -->

- - - - - - - - - - - - - - - - - - - - - - - - - - Direcloralc of Elcmenlary Educalion / ~ m~

GOVERNMENT OF HARYANA / ~ ~

Directorate Elementary Education

If)~~~~

~, ~ ~ fclcf;rn
Education, Culture and Development

~"ITvo:r~

Lead me from Darkness to Light

Regd.
To
District Elementary Education Officer,
Sirsa.
Memo No. 07/245-2026 D&L (1)
Dated, Panchkula 16.10.2026
Subject:-

Regarding granting permission of going abroad - Sh. Satpal Singh

(039635), TGT Punjabi GMSSSS Rania, (2840) District Sirsa from
10.11.2026 to 10.12.2026.
*****************

Kindly refer on the subject cited above.
The
Permission/NOC to
go abroad
is hereby granted to
abroad Sh. Satpal Singh (039635), TGT Punjabi GMSSSS Rania, (2840) District
Sirsa from 10.11.2026 to 10.12.2026 on following terms and conditions:1. He/She will visit to go Canada from 10.11.2026 to 10.12.2026 after getting the leave

2.
3.
4.
5.
6.
7.
8.

sanctioned from the competent authority and will not get the leave extended while being
abroad.
He/She will hand over his/her charge to the senior most teachers as the case may be
before proceeding on leave.
He/she will bear all the expenses on the said tour from his/her own pocket and the State
would not bear any expense incurred by him/her.
He/she will not accept any assignment by any Govt. or the NGO or anybody while on
foreign visit.
He/She will not be doing any such activity which may be detrimental to the bilateral
relations of India with the said country (s) being visited by him/her.
He/She will not be doing anything, which may be termed as detrimental to the sovereignty
of India.
He/She will not be inviting any liability during his/her stay at abroad which may result into
losses to Govt. in any matter.
If any, criminal case/Departmental proceeding(s) is filed against teacher from the date of
issue of present permission to go abroad till the date of departure, then the permission to
go abroad will be stand cancelled automatically.

9. The other terms and conditions will be same W/Additional Chief Secretary to Govt.
Haryana Finance Department letter No. 07/08-201 0-4FR/18354 dated 15.10.2025 which
mentioned on point no. 2(C) 1 to 10.
Note:- If the above mentioned teacher has been assigned duty for SIR and Census work,
He/She shall not be relieved.

-..sci/'

Superintendent (D&L)
for Director Elementary Education,
Haryana, Panch kula
Endst No. Even
Dated, Panchkula, 16.10.2026
A copy is forwarded to the following for information and necessary action:

1.
2.
~

4.

_

Principal/Head Master/Mistress, GMSSS Rania, (2840) District Sirsa.
Sh. Satpal Singh (039635), TGT Punjabi GMSSSSRania, (2840) District Sirsa.
IT/Cell.
Office copy.

~b;t

Superintendent (D&L)
for Dife.ftor Elementary Education,
41-taryana, Panchkula

Office: Plot No. 1B, ShiKsha Sadan, Sector 5, Panchkula. Haryana 134~09 (India) - Tel: 91(0172)-2560;8 Fa,' 31(0172)-25l 0188
~: ~c '1 1<\1. ~r~ "IG'1..\1i:fC< 5 q"'!bo!T··-134109 (riEll) 1JS<fi . 9' (0172: 2580189 q;,!'i1 q- 'em\ "'>60·88

<!-- page 16 -->
