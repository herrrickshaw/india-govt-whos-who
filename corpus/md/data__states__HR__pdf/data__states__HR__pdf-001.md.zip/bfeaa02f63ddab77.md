---
doc_id: "bfeaa02f63ddab77"
source_url: "https://highereduhry.ac.in/Notices/Notice202610301618075122.pdf"
ministry: "Higher Education Department, Haryana"
title: "Regarding Suspension Order of Ms. Monu Devi, Assistant Professor in English."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "44d4710fea9c4bde"
---

<!-- page 1 -->

HARYANA GOVEFINMENT
HIGHER EDUCATION DEPARTMENT
ORDER

The Governor of Haryana is pleasecl to place services of Ms. Monu
Devi, Assistant Professor in English, Pt.N.R..S Government College, Rohtak
under suspension with immediate effect. During the period of suspension,
Ms. Monu Devi, Assistant Professor will dreLw such subsistance allowances
as is permissible under rules.
The headquarter of Ms. Monu Devi, Assistant Professor duing the
period of suspension will be Office of Principal Government College Jhajjar
and she will not leave her headquater without obtaining prior permission of
competent authority.

Apoorva Kumar Singh, IAS
Additional Chief Secretar5r to Govt. Haqrana,
Higher Education Department,
Cheuedigarh.

Endst. No. 07l 26-2026 Vig(1)
Dated, Chandigarh, the 05. 1 O.2026
Endst. No. : Even

Dated, Panchkula, the 3o. lo.LDL!

A copy is forwarded to the foilowing for inforrnation & necessary action:-

1. J'he Principal Accountant General (AikE) Haryana, Chandigarh.
2. PS/EM, PS/ACSHE, PS/DHE , PA/JDA
3. Treasury Officer concerned.
4. Principal, Pt.N.R.S Government College, Rohtak is requested to
deliver the suspension order to Ms. Mlonu Devi, Assistant Professor.
5. Principal, Government College, Jhajjar is requested to send the
joining report to this office.
6. Ms. Monu Devi Assistant Professor in English, Pt.N.R.S Government
College, Rohtak
7.
Superintendent College- 1, College-Ill, Accounts Branch, College-Vll
8. ;$uperintendent HRMS (Local).
gt Incharge, IT CelI for uploading the sajd order on the web-portal of
Higher Education Department, Haryana panchkula.

z^r

(@;e

Dy. Superiht-endent Vigilance
for Additional chief Secretrary to Government of Haryana
Higher Education Department, Haryana]rl-
