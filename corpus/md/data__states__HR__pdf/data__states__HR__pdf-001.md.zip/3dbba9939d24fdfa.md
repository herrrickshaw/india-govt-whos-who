---
doc_id: "3dbba9939d24fdfa"
source_url: "https://hsvphry.org.in/documents/notices/NEWS_202610231041_dddef559.pdf"
ministry: "Haryana Shehri Vikas Pradhikaran, Haryana"
title: "NEWS     Provisional appointment to the post of Accountant in HSVP        23 Oct 2026   Open"
date: ""
pages: 6
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e1ac701ff7db9a22"
---

<!-- page 1 -->

| No, EA-5-2026/37090 Dated: 22.0.2026
To
L. Ms. PINKI D/o Sh. Ramesh Chand,
VPO- JAISINGHPURA, ASIAN ,
City/Village: JAIL SINGH PURA,
Tehsil: Assandh, District: Karnal
2. Manjeet Singh S/O Late Sh, Puran Mal, /
City/Village: PEHRAWER, Tehsil: Rohtak, District: Rohtak
3. Urmila Deswal D/o Sh. Jai Narayan Deswal
H NO 997/2i, PREM NAGAR, ROHTAK,
City/Village: ROHTAK, Tehsil: Rohtak,
District: Rohtak
4. Meenu Sharma D/o Sh. Ram Kumar
34, Power Colony, Industrial Area Phase 2, Panchkula,
City/Village: PANCHKULA, Tehsil: Panchkula, District: Panchkula
5. Bhupinder Kumar S/o Sh. Kishori Lal
Near Sewa Bharti School, Ashok Nagar, Fatehabad ,
City/Village: FATEHABAD, Tehsil: Fatehabad, District: Fatehabad
6. Deepak Yadav S/o Sh .Raj Kumar Yadav,
Village- Kaliawas, P.O.- Garhi Harsaru, Gurugram,
City/Village: KALIAWAS, Tehsil: Farrukhnagar, District: Gurugram
7. Rajni D/o Sh Hanuman
NEAR DUMARKHA KALAN BUS STAND,
City/Village: DUMARKHA KALAN, Tehsil: Uchana, District: Jind
8. Archna Kumari D/o Sh. Banarasi Dass,
H.No. 523, BEHIND HOLYCHILD SCHOOL, RAJIV NAGAR,
City/Village: SONIPAT, Tehsil: Sonipat, District: Sonipat
9. Kuldeep s/o Sh. Daya Ram Ghodela ,
City/Village: NEEMLA, Tehsil: Ellenabad, District: Sirsa
i0 Sumit Rautela S/o Sh. Kamal Singh,
House No. 68-C, Housing Board Complex, Sector-4 ,
City/Village: PANCHKULA, Tehsil: Panchkula, District: Panchkula
i2. Monika D/o Sh. Ram Kishan,
H.No 353,Gali Aalmal Naya bazar Bhiwani ,
City/Village: BHIWANI, Tehsil: Bhiwani, District: Bhiwani
2. Neeraj Goyal S/o Sh. Ramesh Kumar,
HOUSE NO, 996, SECTOR 9-ii, NEAR POLICE STATION,,
City/Village: HISAR, Tehsil: Hisar, District: Hisar.
43. Rekha Rani S/o Sh .Jai Kumar,
VPO PADHANA TEHSIL NILOKHERI DISTT KARNAL,
City/Village: PADHANA, Tehsil: Nilokheri, District: Karnal
=e ots

<!-- page 2 -->

ox
44. Akshay Kumar Yadav S/o Sh. Mahesh Kumar Yadav, है
H No. 09, MOHALLA GALIWALA, VPO MUSEPUR, Es
DIST REWARI, City/Village: MUSEPUR,
Tehsil: Rewari, District: Rewari
5 Naresh Kumar S/o Midhu Ram Arora,
V. BHUDHA BHANA P.O.- NAGOKI,
City/Village: SIRSA, Tehsil: Sirsa, District: Sirsa
6 Karan Singh S/o Sh. Mohinder Singh,
R/o Badyarangran , City/Village: HISAR,
Tehsil: Hisar, District: Hisar
7. Vijay Kumar S/o Sh. Kapoor Singh,
H.No. 84, GALI No. 9, SURYA NAGAR,
City/Village: HISAR, Tehsil: Hisar, District: Hisar
48. | Rajesh Kumar S/o Sh Ram Dhari Singh,
City/Village: NILAHERI, Tehsil: Matenhail,
District: Jhajjar.
i9. Poonam Pawar D/o Sh. Randhir Singh,
003 FF, sector 9 Panchkula, City/Village: Panchkula,
Tehsil/ District: Panchkula.
20. Arjun S/o Sh. Om Parkash,
H.NO 832, VPO KARHANS, NEAR GEETA LAW COLLEGE ,
City/Village: KARHANS, Tehsil: Samalkha, District: Panipat
2i Amit Kumar S/o Sh. Subhash Chander,
H.No. 62, Gali No 9, Karan Vihar, Near Sector 6,
City/Village: KARNAL, Tehsil: Karnal, District: Karnal.
22.  Vijender Singh S/o Sh. Iqbal Singh,
HOUSE NO. 2532, HOUSING BOARD COLONY,
SECTOR 5, City/Village: PANCHKULA,
Tehsil: Panchkula, District: Panchkula
23. Rajat Kumar S/o Sh. Jagbir Singh,
City/Village: CHANARTHAL, Tehsil: Shahbad,
District: Kurukshetra.
24. Deepak S/o Sh. Ram Kishor
VPO-AKBARPUR SIROHI, TEH-NANGAL CHOWDHARY,
City/Village: AKBARPUR, Tehsil: Nangal Chaudhary,
District: Mahendragarh
25. Vijay Nimbran S/o Sh. Vedpal,
BRAHAM KUMARI, GALI NO 4, OPPOSITE BRAHAM KUMARI ,
City/Village: NARWANA, Tehsil: Narwana, District: Jind
26. Yavan Walia S/o Sh. Baljit Walia,
City/Village: FATEHPUR, Tehsil: Fatehpur Pundri,
District: Kaithal
27.  Viraj S/o Sh. Sukhbir Singh,
HNO 53 SECTOR 2 SRINAGAR COLONY BAHALGARH ROAD,
City/Village: SONIPAT, Tehsil: Sonipat, District: Sonipat
—stz aes,

<!-- page 3 -->

28, Sunita Yadav D/o Sh, Raj Roop Yadav,
H.NO, DLO ANSAL TOWN SECTOR-36 KARNAL 432037,
City/Village: KARNAL, Tehsil: Karnal, District: Karnal
29, Manjeet Kaur D/o Sh, Dulara Singh,
Old Police Chowk! Street, Khanna colony , sirsa,
City/Village: SIRSA, Tehsil; Sirsa, District: Sirsa
30. Leela Soni D/o Sh. Gopal Son,
Hanuman Dhani Gall No. 2, near Vijay Attachaki Bhiwa,
City/Village: BHIWANI, Tehsil; Bhiwani, District: Bhiwani.
34,  Sanjeevan S/o Sh, Ram Niwas,
780/29 A GALI NO l DEV NAGAR SONIPAT-i34002 HR,
City/Village: SONIPAT, Tehsil: Sonipat, District: Sonipat.
32. Vikas S/o Sh. Rajender Kumar,
BABA KUNDI STREET NO 3 HN 223 NARWANA,
City/Village: NARWANA, Tehsil: Narwana, District: Jind.
33. Parul Rani D/o Sh. Surender Singh,
VPO DHANI PEER WALI, City/Village: HANSI, Tehsil: Hansi,
District: Hisar.
34, Pawan Kumar S/o Sh. Mani Ram
Ward No-i6, Canal Colony, 6 Footi Gali, H.N-i45,
City/Village: RATIA, Tehsil: Ratia, District: Fatehabad
35. Pawan S/o Sh. Ashok Kumar,
H.No. 78/2 W.No. 22 Rajiv Colony Near 32KV Power,
City/Village: ROHTAK, Tehsil: Rohtak, District: Rohtak
36. Bharti Nirmal D/o Sh. Rajinder Singh,
H, No.228, Sector 8, Huda Jagadhri, Distt. Yamunanagar,
City/Village: YAMUNANAGAR, Tehsil: Jagadhri, District: Yamunanagar
37 Neeraj Kumar S/o Sh. BholaNath,
258 Jankpuri Gaushalla Road, Near Balaji Mandir,
City/Village: KARNAL, Tehsil: Karnal, District: Karnal
38 Rajesh Kumar S/o Sh. Jai Bhagwan,
H NO, 45, NEAR MINI BANK, SATROD KHURD, City/Village: SATROD,
Tehsil: Hisar, District: Hisar
39. Suman D/o Lajpat Rai,
665A, Kailash Nagar, Model Town, Ambala City,
City/Village: AMBALA CITY, Tehsil: Ambala, District: Ambala
40 Tilak Raj S/o Sh. Madan Lal,
H NO 62 W NO 6 G NO 3 G NO 3 BHARAT NAGAR HISAR,
City/Village: HISAR, Tehsil: Hisar, District: Hisar
4. Naresh Kumar S/o Sh. Umed Singh,
VPO PAKASMA PANA KHADRAN, City/Village: PAKASMA,
Tehsil: Sampla, District: Rohtak *० २
~~ ots

<!-- page 4 -->

42 Jai Parkash S/o Sh. Bihari Lal, VPO- Pali, City/Village: PALI, NN

Tehsil: Rewari, District: Rewari >
Subject: Provisional appointment to the post of Accountant in Haryana ShehriVikas

Pradhikaran.
On the recommendation of the Haryana Staff Selection Commission conveyed vide its
letter No. HSSC/Confd./Recomm./02/44/2026/CA-4/538 dated 2.0.2026, made
against Advertisement No. 07/2024 (Group-C, Commerce cadre), Category No. 7i, you
are hereby offered provisional appointment to the post of Accountant in Haryana
ShehriVikas Pradhikaran, on the terms and conditions set out below. This offer is made
subject in its entirety to Parts C and D of this letter, which you are advised to read
before acting upon it.

PART A — ACTION REQUIRED OF YOU, AND by wr REQUIRED OF YOU, AND BY WHEN

t. Document verification.You shall appear in person for document verification from
23.0.2026 to 24.0.2026, between 09:00 AM and 05:00 PM, at the HSVP (HQ), Plot
No. C-3, Sector-6, Panchkula. You shall bring all the documents listed in Annexure-I
to this letter, in original, along with three (03) sets of self-attested photocopies. Failure
to appear on the specified dates and within the prescribed time shall result in the offer
being treated as declined and withdrawn by HSVP without any further notice.

2, Medical examination. You shall, before the date of joining in HSVP, get yourself
medically examined by the Chief Medical Officer/Principal Medical Officer of General
Civil Hospital in any district within Haryana, and produce a certificate of medical fitness
for entry into Government service in the prescribed form. The cost of the examination
shall be borne by you. Appointment is subject to your being found medically fit; if you
are found unfit, this offer shall stand withdrawn and no claim of any nature shall tie
against the Authority.

3. Affidavit and undertakings. While coming for document verification, you shall
require to furnish the affidavit at Annexure-II, duly sworn before a Notary Public
authority.

4, Biometric/facial verification. You shall present yourself for biometric and facial
verification as and when the team deputed by the Haryana Staff Selection
Commission/Haryana Shehri Vikas Pradhikaran.

5. Joining. On successful completion of the document verification, you will be asked to
submit the joining report within 5 days at HSVP HQ Panchkula. If you fail to join
within the prescribed period, and no extension has been granted in writing by the
competent authority, this offer shall stand automatically withdrawn, your name shall be
liable to be removed from the list of candidates recommended for appointment in
HSVP, and the fact shall be reported to the Haryana Staff Selection Commission.

PART B — PAY, PLACE AND CONDITIONS OF sew AND CONDITIONS OF SERVICE

6. Pay. You shall draw pay at the Functional Pay Level FPL-7 (Grade Pay %4,600/-). Along
with all due allowances as admissible under the rules, regulations, instructions and
orders of the State Government and of the HSVP as in force from time to time and as
amended from time to time.

7. Pension. You shall be governed by the pension scheme applicable at the time of
joining as notified by the State Government and as amended from time to time.

8. Probation. You shall be on probation for a period of two years, extendable up to three
years. Satisfactory completion of probation shall not be automatic and shall require an
express order of confirmation by the competent authority. During probation, and during
any extension thereof, your services are liable to be terminated at any time without
notice and without assigning any reason, if your work, conduct, performance or
suitability is not found satisfactory.

9. Place of posting and transfer. You shall be liable to serve at any place in the State
of Haryanaand shall be liable to transfer, deputation or re-deployment at the discretion
of the competent authority. No claim to posting at any particular station shall lie.

0.Governing rules.Your appointment and service shall be governed by the Haryana
Shehri Vikas Pradhikaran Act, 977, the HSVP Service Rules, 989, as amended from

ts

<!-- page 5 -->

time to time, and all other applicable rules, regulations, conduct and disciplinary rules,
statutory provisions, and executive instructions made or issued thereunder or by the
State Government or the HSVP, as applicable and as amended or in force from time to
time.
i.. Travelling allowance. No travelling allowance or other expense shall be payable to
you for the purpose of document verification, medical examination or joining.
PART C — THE PROVISIONAL CHARACTER OF THIS APPOINTMENT
i2.No vested right. The issue of this letter, your appearance at document verification,
and even your joining duty in pursuance hereof, shall not confer upon you any vested
right, entitlement, legitimate expectation or guarantee of appointment, of continuance
in service, or of regularisation. The appointment shall at all times remain subject to
verification, scrutiny and approval by the competent authority in accordance with the
applicable rules, regulations and procedure. In the event that your recommendation is
not approved, is rejected, is revised or is withdrawn by the competent authority or by
the HSSC, no claim for appointment, continuance, seniority, compensation, damages or
any other consequential benefit shall be maintainable against the HSVP on the basis of
this letter or of anything done in pursuance of it.
i3.Pending litigation. This appointment is expressly subject to the final outcome of CM-
5479-CWP-2026, CM-7032-CWP-2026 and RA-CW-5ii-2026 in CWP-7396-2025,
and of any other writ petition, appeal, review or proceeding pending or hereafter
instituted before the Hon’ble Punjab and Haryana High Court or any appellate Court or
forum touching Advertisement No. 07/2024 or the result declared thereunder on
4.06.2025. Should the merit list be revised, substituted or reshuffled, or your
candidature be displaced, in consequence of any such order, your appointment shall
stand modified, superseded or cancelled accordingly, without notice and without any
liability on the HSVP, and you shall have no right of objection, as undertaken by you
under clause 3 above. Any period of service rendered in the interregnum shall create
no equity in your favour.
4.Verification of documents and antecedents. The HSSC has recommended you
without medical examination and without any enquiry into your antecedents, and
without verification of the documents relating to your essential qualification, age,
caste/category, university and experience as claimed by you. Those documents shall be
got verified from the issuing authorities, and your character and antecedents shall be
verified in terms of Government instructions No. 52/06/208-3GSIII dated 5.03.20i8.
Should any document, certificate, declaration or information furnished by you be found
false, forged, fabricated, suppressed or incorrect in any material particular, or should
any adverse fact come to notice regarding your character or antecedents, your
appointment shall be liable to be cancelled and your services terminated forthwith,
without notice and without assigning any reason, notwithstanding that you may have
been confirmed in the meantime; such cancellation shall operate from the inception,
and the HSVP shall further be entitled to recover any emoluments Paid and to initiate
such criminal or other proceedings as may be warranted in law.
5.Validity of the recommendation. The recommendation of the HSSC is valid for one
year from the date of recommendation in terms of Chief Secretary’s instructions No.
42/06/209-2GS-I dated 25.06.209, and this offer is subject to and shall not survive
beyond that validity.
i6.Withdrawal before joining. The HSVP reserves the right to withdraw, modify or keep
in abeyance this offer at any time before you take charge of the post, in the event of
any administrative exigency, order of a competent Court, direction of the State
Government or the HSSC, or discovery of any fact bearing on your eligibility, and no
claim shall lie on that account.
PART D — YOUR OBLIGATIONS DURING SERVICE D — YOUR OBLIGATIONS DURING SERVI
i7.Resignation and termination. If you wish to resign, you shall give three months’
notice in writing if confirmed, and one month's notice if not confirmed, or pay salary in
lieu thereof as the case may be. The HSVP may, at its discretion, refuse to accept a
resignation tendered while disciplinary proceedings, an enquiry or a recovery is pending
against you. The HSVP may terminate your services by giving one month’‘s notice or
Pay in lieu thereof, without prejudice to its right to terminate your services without
notice.
sfx LS

<!-- page 6 -->

48.Higher studies. You shall not undertake any course of higher study without the prior
written permission of the competent authority, and no leave of any kind shall te
granted for pursuing higher studies. d
i9,.Marital status.You shall not be eligible for appointment if you have a living spouse
and marry another person.
20.0ther employment. You shall not hold any other appointment, office of profit, or
carry on any trade or business, during the subsistence of your service with the HSVP. If
you are presently in the employment of any Government, Board, Corporation or Public
Sector Undertaking, you shall produce a proper relieving order and no-objection
certificate as the case may be before the joining.
2.Address for service. All communications sent to you at the address given above, or
at such other address as you may last have intimated to the HSVP in writing, shall be
deemed to have been duly served upon you.
PART E — GENERAL
22.In the event of any inconsistency between this letter and the statutory rules,
regulations or instructions governing the post, the latter shall prevail. If any clause of
this letter is held unenforceable, the remaining clauses shall continue in full force. The
courts at Panchkula alone shall have jurisdiction in respect of any dispute arising out of
this letter.
Enclosures: Annexure-I & Annexure-II,Attestation form and Medical Fitness Certificate.
tos
Superintéendent(E)
for Chief Administrator, HSVP,
Panchkula.
Endst. No. EA-5-2026/37092 Dated: 22.0.2026
A copy is forwarded toAll the Civil Surgeon, General Hospital, with in the state, with the
request that the candidate, who has been selected for appointment in Haryana ShehriVikas
Pradhikaran, may kindly be medically examined as and when he/she appears, and a certificate
of medical fitness for entry into service in the prescribed form forwarded to this office. The
prescribed examination fee may kindly be realised from दि कि candidate at the time of
examination. 7
Supeririterent(E)
for Chief Administrator, HSVP,
Panchkula.
Endst. No. EA-5-2026/37092 Dated: 22.0.2026
A copy is forwarded to the Secretary, Haryana Staff Selection Commission,
Panchkula, with reference to that office letter No. HSSC/Confd./Recomm./04/4/2026/CA-
44/538 dated 2.0.2026, for information and necessary action, along with intimation that
the appointment letter has been issued incorporating the condition prescribed in para 2
thereof, and with a request to depute the biometric/facial verification team.
suet Bene)
for Chief Administrator, HSVP,
Panchkula.
