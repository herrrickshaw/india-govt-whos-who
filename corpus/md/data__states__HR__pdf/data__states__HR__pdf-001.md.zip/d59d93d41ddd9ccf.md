---
doc_id: "d59d93d41ddd9ccf"
source_url: "https://haryanatax.gov.in/Website_Content_Files/ExcisePolicy2025_27/Excise_Policy_2025_27_07.pdf"
ministry: "Excise and Taxation Department, Haryana"
title: "Public notice for registration for participation in e-tendering process for allotment of retail liquor licenses of Country Liquor (L-14A) and IMFL (L-2) for the year 2025-27 in the State of Haryana."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2ccd2ae10f5e42c"
---

<!-- page 1 -->

PUBLIC NOTICE
GOVERNMENT OF HARYANA
EXCISE & TAXATION DEPARTMENT
PUBLIC NOTICE FOR REGISTRATION & PARTICIPATION IN THE
PROCESS FOR ALLOTMENT OF L.IBF LICENSES FOR WHOLESALE
TRADE OF IMPORTED FOREIGN LIQUOR (BIO) IN THE STATE OF
HARYANA FOR THE EXCISE POLICY YEAR 2025-27,
This is for the information of the general public that L-IBF licenses for
wholesale trade of Imported Foreign Liquor (BIO) in the State of Haryana for

the Excise Policy Year 2025-27 shall be granted by way of inviting online
applications.
A11 the prospective eligible applicants will have to get themselves

.
I

registered before participating in the process ofL-lBF licenses.

The procedure for online registration and placing online application for

L-IBF license is available on the official website of the department i.e.
www.hary anatax.gov.in.
The number of wholesale licenses of IFL (BIO) in the State is fixed at more
than or equal to sixteen (16). In case, the number of eligible applications received

in first round is more than or equal to sixteen (16), the L-IBF licence shall be
granted to all the eligible applicants. In such a case, the department will not initiate

i

any further round(s) for allotment of L-lBFs in the State.

However, in case, the number of eligible applications received in first round

is less than sixteen (16), the department may initiate more round(s) for allotment

of remaining L-IBF licences. The number of remaining L-IBF licenses can be
calculated by subtracting the count ofL-lBF allotted in all previous round(s) from
sixteen ( I 6).

It is further provided that in case, the number of eligible applications in
second or any subsequent round exceeds the remaining number of L-IBF
licensees available for allotment in that particular round, then the grant of such

remaining L-IBF licence(s) shall be made by draw of lots amongst eligible
applicants ofthat particular round. For more details kindly refer to clause 9.5 of
the Excise Policy for the yeat2025-2 7 which is available on the official website
of the department i.e. www .hary anatax. gov.in
The License L-IBF shall be granted on fixed annual license fee of Rs. 8.25
Crore to be paid in accordance with the provisions of clause 9.5.3 of Excise Policy
2025-27.

The schedule for registration & participation in the process ofallotment of

L-1BF licenses is given below:-

.

<!-- page 2 -->

Starting Date & Time for registrat ion and 30.05.2025. 10:00 hrs
online submission of a lication:
Time for online 05.06.2025,18:00 hrs
Closing Date
submission of aPPlication:
Publication of list of eligible applicants on Q6.06.2025, l4:00 hrs

&

dep artmental website:

During the course of registration for application of L-18F, all the
prospective applicants will have to deposit the Earnest Money of Rs. 50 Lakh
(Rs. Fifty Lakh) and Application Fee of Rs 5 Lakh (Rs' Five Lakh)'

Theapplicationfeeshallbenon-refundableandnon-adjustable.The
Eamest Money shall be adjustable unless forfeited'

The eligible applicants shall have to deposit a security amount equal
to Rs. 1.25 Crore within a week of the date when the names of eligible
applicant(s) are published on the official website of the Department'
It is further informed that registration for L-IBF is separate from the

.

registration for allotment of zones of retail outlets'

TheDepartmentreservestherighttocancelthewholeprocesswithout
assigning any reason thereto in the interest ofrevenue'

The department reserves the right to disqualiff any application(s) if the
application is not complete or it is not found in order. The application(s) may
also be rejected if the applicant is found to be black listed or engaged in

any

malpractices.

Theapplication(s)mayalsoberejectedifanyparticularssubmittedbythe
applicant are found to be incorrect or fake.

TheannualminimumquotaoflFL(BIo)andscheduleofliftingshallbe
as prescribed in the Excise Policy.

The eligible applicant shall have to submit all other documents as are
required under the provisions of the notice, instructions and the Haryana Excise

Act, 1914 and the rules framed there under.

ThelicenseshallbegrantedbyExciseCollectorwiththepriorapprovalof

of

Excise Commissioner-cum- Financial Commissioner subject to the provisions
the Haryana Excise Act, 1914, rules framed there under and the Excise policy
2025.27.

The Excise Policy for the year 2025-27 is available on the official website
of the department i.e. www.haryanatax.gov.in'

VINAY PRATAP SINGH,IAS
Excise and Taxation Commissioner,
Haryana.

,
