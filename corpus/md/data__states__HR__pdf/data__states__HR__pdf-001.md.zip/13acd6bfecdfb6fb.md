---
doc_id: "13acd6bfecdfb6fb"
source_url: "https://bseh.org.in/uploads/files/56fed07d30d4fa337feb5ddeebb68de0.pdf"
ministry: "Board of School Education Haryana"
title: "E-TENDER  FOR PURCHASE OF INKLESS PADS FOR HTET-2026"
date: ""
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f8c4d046d6cd5160"
---

<!-- page 1 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

Tender Fee 1000/-(Non-refundable)

TENDER DOCUMENT FOR SUPPLY OF INKLESS PADS FOR
HTET-2026

Board of School Education Haryana,
Hansi Road,
Bhiwani-127021
Website: https://bseh.org.in
E-mail: asgen@bseh.org.in

Page 1 of 11

<!-- page 2 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

DOCUMENT CONTROL SHEET

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.

Name of Organization
Scope of work
Tender Type
Tender category
Tender fee (non-refundable
and non-adjustable)
Earnest money deposit
(EMD)
Bid Document Download /
Sale Start Date

Board of School Education Haryana, Bhiwani
Purchase of Inkless Pads for HTET-2026
OPEN
Purchase of Goods
Rs.1,000/- (One Thousand only)

Bid Submission Start Date

23-10-2026

Last date and time for
submission of Bids
Date and time of opening
of technical Bids
Tender should be
addressed to

Rs. 20,000/-(Twenty Thousand only)
23-10-2026

04-11-2026 (10:00 AM)
04-11-2026 (10:30 AM)
Secretary, Board of School Education Haryana, Bhiwani-127021

12.

Communication address

Assistant Secretary (General Branch)- 9466236459
Board of School Education Haryana, Bhiwani. Pin- 127021

13.

Period of completion of
work

As per Terms & Conditions of tender & Award letter

14.

Validity of contract/rates

Upto Two Years or till the finalization of next tender

Page 2 of 11

<!-- page 3 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

E-Tender Notice
The Secretary, Board of School Education Haryana, Bhiwani invites E-Tender complete in all
respect under Two bid system i.e. Technical Bid and Financial Bid from the bidders for Supply of Inkless
Pads for Thumb Impression in HTET-2026. Eligible and interested Bidders may obtain the E-Tender
Document from the Board’s website www.bseh.org.in and www.etenders.hry.nic.in Cost of this bid
document is Rs. 1000/- (One Thousand Only) & Earnest Money is Rs. 20,000/- (Twenty Thousand Only)
deposited on e-tender website and the proof of deposited slip should be enclosed/uploaded with the tender
document. Completely filled up documents shall be submitted only online to Secretary, Board of School
Education Haryana, Bhiwani till 04-11-2026(10:00AM). Technical Bids will be opened in the Board’s
committee room in the presence of bidders, who wish to present, on 04-11-2026(10:30AM) by the approved
committee. Financial Bid will be opened on the date to be intimated later on. Proprietors or their
representatives are advised to attend personally as the negotiations of rates. For complete details, login to the
Board’s website. www.bseh.org.in & www.etenders.hry.nic.in.

-SdSecretary
Board of School Education Haryana, Bhiwani

Page 3 of 11

<!-- page 4 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

Calendar of EventsSl. No.

1.
2.

Particulars

Date

Date & Time

of uploading of N.I.T. & other

Documents(online) (Publishing Date)
Bid submission Start Date (Online)
Last date of Receipt of any query in relation to tender

3.

documents

23-10-2026
23-10-2026
04-11-2026 (10:00 AM)

4.

Bid Submission Closing (Online)

04-11-2026 (10:00 AM)

5.

Bid opening date for Technical Proposals (Online)

04-11-2026 (10:30 AM)

6.

Opening of the Financial Proposal (Online)

To be intimated later on

Note: The above time is tentative and the Board may at its discretion change the same by issuing an

Addendum. BSEH reserves the right to modify the said schedule of Bidding Process at any time
during the Bidding Process at its sole discretion without assigning any reason or being liable for the
same in any manner whatsoever.

Page 4 of 11

<!-- page 5 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

TECHNICAL BID
Sr. No.

1.

Item Name

Specifications

No. of items required

Inkless Pad

1. Inkless Pad with non-smudgy ink to capture thumb impression
2. Size: Approximately 2-2½ inch diameter or diagonal
3. Colour of Ink and impression: Black & permanent.
4. Durability: Long lasting
5. Other Features: No labels on Inkless Pads and packing.
6. Fingerprints for waterproof.
7. Leaves no residue on the finger.
8. Non toxic and harmless for skin.
9. Fingerprint impressions can be scanned in to A.F.I.S. to insure
positive identification.
10. Capacity of each inkless pad should be minimum 600 thumb
impressions.

Page 5 of 11

2000 Unit

<!-- page 6 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

Terms, Conditions and Instructions to the Bidders
1.

The Bidder should be registered as a stationer/manufacturer.

2.

The cost of this bid document is Rs. 1000/- (Rs One Thousand only) [non refundable] and Earnest Money of
Rs. 20000/- (Rs. Twenty thousand only) deposited. Slips of deposited Cost and EMD should be enclosed and
uploaded with e-tender documents. Without this tender shall be rejected.

3.

The Bidder will submit two specimens of inkless pads, with slips pasted on them and slips should be signed
by the bidder along with stamp of the firm. Specimens will be returned to all bidders except successful bidder
after finalization of supplier firm.

4.

The Bids will be opened in the presence of bidders or their authorized representatives, who may wish to be
present. So it is advised that authorized representatives bring authority letters from their respective firms.

5.

The tender fee is non-refundable and non-adjustable.

6.

Bids without tender fee and/or EMD shall be rejected.

7.

Tender Documents can
www.etenders.hry.nic.in.

8.

The Board has the right to increase/decrease the quantity of Inkless Pads.

9.

Bids shall remain valid for 90 days from the last date of submission of Bids. Any Bid shown to be valid for a
shorter period than the period specified shall be rejected by the Board treating it as non-responsive.

10.

After receiving notification of award, firm has to deposit an agreement of Rs. 100/- Stamp Paper attested by
Notary along with 10% performance security of the value of work order within 10 days.

11.

If the firm did not submit contract form and/or performance security within prescribed time in the notification
of award, penalty of rupees 1000/- per day will be imposed for the next 02 days and after that earnest money
of the firm may be forfeited and work may be allotted to any other willing firm on L-1 rates.

12.

Earnest money and performance security will be returned after final payment to the firm.

13.

Completely filled up bid documents must be submitted only on-line to Secretary, BSEH, Bhiwani.

14.

The Bidder must fill in the requisite information in the Tender Documents at appropriate places.

15.

In case of supply of defected items two-times value of that items will be imposed as penalty on the bidder.
Earnest money, Performance security and amount of supply of inkless pads may be forfeited and firm may be
black listed in case of defect on large scale.

16.

Firm will supply the Inkless Pads (Made in India) within ten days from the date of supply order.

17.
18.

80% payment will be made after supply of goods and balance 20% payment will be released after examination.
The Secretary of the Board may extend/repeat the order for supply of Inkless Pads for the subsequent years
also on the rates previously approved by the Board on the same terms & conditions from the willing firm who
had supplied the Inkless Pads.

19.

The Secretary, Board of School Education Haryana, Bhiwani is the final competent authority to approve the
tender and to settle all issues related to the tender and even to relax or amend any of the terms & conditions
after issuance of the tender, if so required in any emergent situation in the interest of the Board for supply of

also

be

downloaded

Page 6 of 11

from

Board’s

website

www.bseh.org.in

&

<!-- page 7 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

Inkless Pads in the shortest time so as to hold the Board’s examinations in time and his orders shall be final
and binding for one and all, in all respects.
20.

All disputes or differences arising between the parties out of or relating to meaning and operation of effect of
the contract or breach thereof shall be settled by arbitration in accordance with the rules and regulations of
arbitrator. The sole arbitrator shall be appointed on mutual concurrence of both parties. However, it is the
discretion of the Chairman to accept or not decision of the Arbitrator. In case of any legal dispute the
jurisdiction will be Bhiwani.

21.
22.

Copy of GST Certificate shall also be attached with the bid.
The average turnover in the respective field should be more than 10 Lacs per year for the last two years i.e.
2024-2025 and 2025-2026. The tenderer should submit statement of financial accounts from their
bankers/chartered accountants. The name of the bank/firm along with full address is to be furnished on their
firm’s letter head.
The vendor shall ensure timely supply as per approved sample and rates during the currency of the rate
contract (except Govt. levy) failing which action like forfeiture of Performance Security and removal of their
name from the list of approved vendors at BSEH Bhiwani will be taken. The vendor will also submit an
undertaking (on a non-judicial stamp paper of RS. 100/- & attested by notary) to this effect, invariably as
under failing which their tender will not be considered for evaluation:
“I/We will supply the rate contact items under subject rate contract timely in accordance with tender
specifications and approved master sample during the currency of rate contract failing which my Performance
Security may be forfeited and my name may be removed from the list of approved vendors at BSEH
Bhiwani.”
Non-Blacklisting Certificate should be on Rs. 100/- non-judicial stamp paper attested by the Notary and
business for a period of at least last 3 years certificate shall also be attached.
A proof of ownership/partnership shall be submitted along with verification of address and telephone number.
A surprise visit to the premises by the representatives of the Board shall be made to assess the firm’s capacity
and standing.
Offline tender will not be accepted.
The tenderer is also required to submit performance report(s) from other similar organizations where the firm
is registered for supply of Inkless Pad. The firm should also submit list of organization where Inkless Pads
have been supplied before, failure to comply this clause will lead to rejection of the bid.
Rates should be quoted strictly as per the tender specifications and should be valid for a period of minimum
two years or till finalization of next tender and any deviation from specification will not be considered at all.
If the tenderer gives a false statement on any of the above information, the firm/supplier will not be
considered and their quotation/tender shall be deemed to be rejected and the security deposited will stand
forfeited.
The courts at Bhiwani only will be the legal jurisdiction in case of any dispute.
Address and contact details of the Board are:-

23.

24.
25.

26.
27.

28.
29.
30.

Secretary,
Board of School Education Haryana,
Hansi Road, Bhiwani-127021
Email : asgen@bseh.org.in
Website: www.bseh.org.in
Phone No. 01664-243336
Important Phone Numbers :Asstt. Secretary (General) : 9466236459
Superintendent (General) : 8053091972
Page 7 of 11

<!-- page 8 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

FINANCIAL BID
Sr.
No.

1.

No. of items
required

Item
Name

Specifications

Inkless
Pad

1. Inkless Pad with non-smudgy ink to
capture thumb impression
2. Size: Approximately 2-2½ inch diameter
or diagonal
3. Colour of Ink and impression: Black &
permanent.
4. Durability: Long lasting
5. Other Features: No labels on Inkless
Pads and packing.
6. Fingerprints for waterproof.
7. Leaves no residue on the finger.
8. Non toxic and harmless for skin.
9. Fingerprint impressions can be scanned
in to A.F.I.S. to insure positive
identification.
10. Capacity of each inkless pad should be
minimum 600 thumb impressions.

Base
Rates Per
Unit

GST
Extra

Total Cost Per Unit
In Figures
Rs. ………................

In words
Rs.…….....…………
2000 Unit

……………………
……………………
……………

We agree to bind by this offer if we are selected as the preferred bidder.

FOR AND ON BEHALF OF__________________
SIGNATURE______________________________
NAME____________________________________
DESIGNATION___________________________

COMPANY SEAL

Page 8 of 11

<!-- page 9 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

FORMAT OF UNDERTAKING
To,

Secretary,
Board of School Education Haryana,
Bhiwani - 127021
(Ph.: 01664- 243336)

R/Sir,
1.
2.
3.
4.
5.
6.
7.

I/We hereby submit our tender for the supply of Inkless Pad.
I/We enclosing herewith the proof of cost of bid document is deposited Rs. 1000/- (One Thousand Only) &
EMD Rs. 20,000/- (Twenty Thousand Only) to be deposited on E-tender website and the proof of deposited slip
should be enclosed/ uploaded with the tender documents.
I/We hereby agree to all the terms and conditions, stipulated by BSEH, Bhiwani.
I/We have noted that over-written entries shall be deleted unless duly cut & re-written and initialed.
Tender documents are duly signed by authorized signatory (No thumb impression should be affixed).
I/We Undertake to sign the contract/agreement within 5 working days from the issue of the letter of acceptance,
failing which my EMD and performance Security money deposited may be forfeited.
I/We further Undertake that in Price Bid/Financial Bid all statutory levies and taxes have been indicated
separately/included while quoting the prices wherever any levy/tax has not been indicated then it can be taken
that the price quoted are inclusive of all levies and taxes as applicable and I/we undertake to supply at this rate
only. Other terms & Conditions are also as per your requirements.
Yours faithfully,

Signature of Tenderer
with full Address

Note:
1.
Tender not accompanied with EMD/Bid Security and sample of Inkless pad shall be summarily
rejected.
2.
No thumb impression should be affixed.

Page 9 of 11

<!-- page 10 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

BIDDER’S PROFILE
1.(a)Name:
(b) Registration Details of the Bidder (Enclose certification of Company/Trust deed/Society deed):
(c) Country of incorporation:
(d) Address of the corporate headquarters and its branch office(s), if any, in India:
(e) Date of incorporation and/or commencement of business:
(f) GST No
(g) PAN No.
2 Brief description of the Bidder including detail so fits mainlines of business:
3 Details of individual(s)who will serve as the point of contact/communication for BSEH:
4. Particulars of the Authorized Signatory of the Bidder:
(a) Name:
(b) Designation:
(c) Address:
(d) Phone/Mobile Number:
(e) Fax Number:
(f) Email:
**Wherever applicable submit documentary evidence to facilitate verification.
We hereby declare that the information submitted above is true to the best of our knowledge. We understand that in
case any discrepancy is found in the information submitted by us our TENDER DOCUMENT is liable to be rejected.

Signature of the Authorized Signatory with date & seal

Page 10 of 11

<!-- page 11 -->

BOARD OF SCHOOL EDUCATION HARYANA, BHIWANI
TENDER NO.- BSEH/Tender/2026/01/Inkless Pad

Date-23-10-2026

Check list of the E-Tender Documents
Sr.
No.
1.

Tender Cost deposit slip as per clause no. 2

2.

Earnest Money Deposit slip as per clause no. 2

3.

Two Samples of Inkless Pads with Sign and stamp of the bidder

4.

Undertaking of the bidder as per instructions no. 23 of the Tender Document

5.

Non-blacklisting declaration as per clause no. 24

6.

Registration certificate of the firm as stationer as per clause no. 1

7.
8.

GST Registration certificate as per clause 21

9.
10.

Name of document

Available at
Page No.

Declaration regarding proprietorship/partnership/Pvt. Ltd.
(as per clause no. 25)
Statement of accounts for the last two years
2024-2025 and 2025-2026 as per clause no. 22

Performance report and list of organizations where the material have supplied
in the last 3 years ( as per clause no. 27)

Note:-All documents submitted along with the bid are to be page numbered, arranged as per
check list through on-line mode only.

Page 11 of 11
