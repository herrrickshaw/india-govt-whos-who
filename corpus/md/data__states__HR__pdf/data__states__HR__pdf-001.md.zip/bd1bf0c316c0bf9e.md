---
doc_id: "bd1bf0c316c0bf9e"
source_url: "https://dmer.haryana.gov.in/uploads/cand_images/PDF_document1.pdf"
ministry: "Directorate of Medical Education & Research, Haryana"
title: "Notification for admission to nursing, physiotherapy and paramedical courses session 2025-26  Download (0.64 MB)"
date: ""
pages: 35
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "968099c46620c424"
---

<!-- page 1 -->

Haryana Government Gazette
EXTRAORDINARY
Published by Authority
© Govt. of Haryana
No. 138-2025/Ext.] CHANDIGARH, FRIDAY, AUGUST 8, 2025 (SRAVANA 17, 1947 SAKA)
HARYANA GOVERNMENT
MEDICAL EDUCATION AND RESEARCH DEPARTMENT
Notification
The 8th August, 2025
No. 16/4/2024-6HB-IV.—
Subject:

Procedure for admission to Nursing (B.Sc. Nursing, Post Basic B.Sc. Nursing, M.Sc. Nursing &
Nurse Practitioner Critical Care Programme), Physiotherapy (BPT, MPT) and Paramedical
courses in Government and Private Institutions affiliated to Pt. BD Sharma UHS Rohtak for the
Academic Session 2025-26.
****

1.

The Governor of Haryana is pleased to notify this admission procedure for admission to Nursing,
Physiotherapy and Paramedical courses to be adopted for admission in the following Under Graduate
Courses and Post Graduate Courses for the Academic session 2025-26 in Government & Private
Institutions in the State of Haryana affiliated to Pt. B.D. Sharma University of Health Sciences, Rohtak:A.
Nursing
i.
B.Sc. Nursing
ii.
Post Basic B.Sc. Nursing
iii.
M.Sc. Nursing
iv.
Nurse Practitioner Critical Care Programme (NPCC)
B.
Physiotherapy
i.
Bachelor in Physiotherapy (BPT)
ii.
Masters in Physiotherapy (MPT)
C.
Paramedical courses
i.
B.Sc. Radiotherapy Technology
ii.
B.Sc. Radiography & Imaging Technology
iii.
Bachelor of Optometry
iv.
B.Sc. Perfusion Technology
v.
B.Sc. Operation Theatre
vi.
B.Sc. (Medical Laboratory Technology)
(1794)

<!-- page 2 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
2.

3.

4.

5.

6.

7.

1795

It is further notified that in Private Institutions affiliated to Pt. BD Sharma University of Health
Sciences,Rohtak,
i.
50% of the seats will be filled under State Quota seats
ii.
Remaining 50% of seats will be filled under the Management Category. Out of 50% of
Management Category seats, 15% seats will be in the Non-Resident Indian (NRI) Category.
iii.
5% of State Quota seats shall be reserved for Persons with Benchmark Disabilities. The
candidates applying under Persons with Benchmark Disabilities (PWBD) category shall have to
get the disability certificate issued by the Medical Board from any Government Medical College
or District Hospitals of Department of Health in the State of Haryana. Admissions to this
category shall be made as per State Government guidelines. In case of any dispute in the
disability percentage, the decision of Medical Board of PGIMS, Rohtak shall be final. Any
vacant seats in this category shall be filled up as per State Reservation Policy.
iv.
20% of seats (within the State Quota seats) in Post Basic B.Sc. Nursing; M.Sc. Nursing and
NPCC Course and Paramedical Courses in Government Nursing / Paramedical Institutes shall be
reserved for in-service candidates.
Pt. Bhagwat Dayal Sharma University of Health Sciences, Rohtak is authorized to conduct the Online
Combined Centralized Counselling as per Merit of Common Entrance Test (CET)-2025 conducted by Pt.
B.D Sharma UHS Rohtak for admission to all the Government and Private Institutes affiliated to Pt. BD
Sharma UHS Rohtak in the State of Haryana as per the procedure notified in this notification.
A.
The list of recognized Institutes and tentative seat distribution of all courses shall be available on
the website of university, i.e., https://uhsr.ac.in; & Department website, i.e.,
https://dmer.haryana.gov.in. and as well as on the admission web portal prior to commencement
of counselling.
B.
The admission shall be made in only those Institutes which have
i.
obtained NOC/LOP from State Government through Department of Medical Education and
Research (only) and are permitted for admission by Department of Medical Education &
Research for the current academic session.,
ii.
are affiliated with Pt. B.D Sharma University of Health Sciences, Rohtak,
iii.
are recognized/affiliated with Haryana Nurses & Nurse Midwives Council/Haryana State
Council of Physiotherapy as the case may be.
C.
The number of seats in each Institute are subject to the final approval of above-mentioned
regulatory authorities.
D.
Roster for all categories of seats including PWBD, EWS shall be maintained by Pt. BD Sharma
University of Health Sciences, Rohtak for allotment of seats under reserved categories.
A.
The State Reservation Policy shall be applicable for admission to all seats in Government Colleges
and for 50% State Quota seats in Private Colleges affiliated to Pt. B.D. Sharma University of
Health Sciences.
B.
Reservation for EWS Category shall be provided as per Haryana Government Notification dated
25.02.2019 (Annexure-I).
C.
The candidates will be required to submit Income and Asset Certificate issued from Competent
Authority as per Annexure-(I) of the said Notification dated 25.02.2019 or any amendments
thereof.
It is further notified that the dates and schedule of counselling shall be notified by Pandit Bhagwat Dayal
Sharma University of Health Sciences, Rohtak and also uploaded on the website of Pandit Bhagwat
Dayal Sharma University of Health Sciences, Rohtak i.e., www.uhsr.ac.in and on the website of
Directorate of Medical Education and Research i.e., https://dmer.haryana.gov.in. and Admission Web
Portal. The candidates are required to regularly visit the websites.
Eligibility Criteria:
A candidate desirous of seeking admission in Nursing, Physiotherapy and Paramedical courses shall be
eligible if she/he:
i. Is a citizen of India,
ii. Is a bona-fide resident of Haryana as per instructions issued by the Chief Secretary to Govt. of
Haryana, and, whose parent(s) produce(s) a Haryana Residence Certificate as per Government
instructions given in Annexure II, III & IV or any further amendments issued by State
Government from time to time,
iii. For Management Category, candidates from all over India shall be eligible, irrespective of
their State of domicile and place of study,

<!-- page 3 -->

1796

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
iv. Obtains an NOC issued by the Head of the Department (DGHS/UHS, Rohtak/Director of
concerned Medical College) as the case may be, if the candidate applies under category of
in-service candidates (Regular employees of Health Department / Medical Education
Department etc. of Government of Haryana). No in-service candidates shall be considered
without valid NOC.
v. Fulfils the minimum eligibility criteria, even if the candidate belongs to General/ SC/SC
(Deprived) / BC-A / BC-B / PWBD / EWS / ESM / FF etc, and is seeking admission under any
category of seats
a. No candidate who has failed to obtain the minimum eligibility marks in CET examination (i.e.
30 % General Category, 25% for SC/BC and PWBD candidates for the respective course) shall
be eligible for admission.
For B.Sc. Nursing Course:
a)
The minimum age for candidates desirous of seeking admission should not be less than
17 years as on 31.12.2025.
b)
The candidate must have passed Senior School Certificate examination (10+2) of Board of
School Education, Haryana or any Board recognized by Central Government / any State
Government with subjects of Physics, Chemistry, Biology and English Core/English
Elective and should have obtained at least 45% aggregate marks (40% marks for
SC/BC/PWBD category) in Physics, Chemistry, Biology & English (PCB & E) taken
together. However, the candidates should have obtained pass marks in each subject
separately.
For Post Basic B.Sc. Nursing Course:
a)
The candidate must have passed Senior School Certificate examination (10+2) of Board of
School Education, Haryana or any Board recognized by Central Government/Any State
Government.
i. Note: Those who have done Matric / 10+1 in or before 1986, will be eligible for
admission.
b)
Should have passed GNM examination and registered as GNM with any State Nursing
Council.
For M.Sc. Nursing Course:
a)
The candidate must have passed B.Sc. Nursing / B.Sc. (Honours) Nursing /Post Basic B.Sc.
Nursing with minimum of 55% aggregate marks (50% in case of SC/BC/PWBD
candidates).
b)
Must be a Registered Nurse or equivalent with any State Nursing Registration Council.
c)
Must have a Minimum 1 (one) year of work experience from Hospital of a Recognized
Medical College / Registered Hospital (registered with State Government) with minimum
100 beds or 01 year teaching experience from Nursing colleges affiliated from any Central
or State University. The work experience will be calculated from the date of registration in
the respective Parent Council till the last date of submission of form. The experience
attained both prior or after Post Basic B.Sc. Nursing shall be considered.
For Nurse Practitioner Critical Care Programme (NPCC)
a)
The Candidate must possess a registered B.Sc. / Post Basic B.Sc. (Nursing) degree with a
minimum of one-year Clinical experience from Hospital of Recognized Medical College /
Registered Hospital (registered with State Government) with minimum 100 beds,
b)
The candidate must have passed B.Sc. Nursing / Post Basic B.Sc. Nursing with minimum
of 55% aggregate marks (50% in case of SC/BC/PWBD candidates).
d)
Must be a Registered Nurse or equivalent with any State Nursing Registration Council.
For Bachelor of Physiotherapy (BPT)
a)
The minimum age for candidates desirous of seeking admission should not be less than
17 years as on 31.12.2025.
b)
The candidate must have passed Senior School Certificate examination (10+2) of Board of
School Education, Haryana or any Board recognized by Central Government / any State
Government with subjects of Physics, Chemistry, Biology and English Core / English
Elective and should have obtained at least 45% aggregate marks for General Category
(40% marks for SC/BC/PWBD category) in Physics, Chemistry, Biology & English
(PCB & E) taken together, however, the candidates should have obtained pass marks in
each subject separately.

<!-- page 4 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1797

For Master of Physiotherapy (MPT)
a) The candidate must have passed BPT Course from any recognized College of Physiotherapy.
b) She/he should have completed 6 months internship at or before the time of counselling.
c) Should be registered or must have applied for registration with the Haryana State Council for
Physiotherapy at the time of counselling (Documentary proof regarding the same has to be
produced at the time of counselling).
For Paramedical Courses: (i) B.Sc. Radiotherapy Technology, (ii) B.Sc. Radiography & Imaging
Technology, (iii) Bachelor of Optometry, (iv) B.Sc. Perfusion Technology, (v) B.Sc. Operation Theatre,
(vi) B.Sc. (Medical Laboratory Technology).
a) The minimum age for candidates desirous of seeking admission should not be less than 17 years
as on 31.12.2025.
b) The candidate must have passed Senior School Certificate examination (10+2) of Board of
School Education, Haryana or any Board recognized by Central Government/Any State
Government with subjects of Physics, Chemistry, Biology and English Core/English Elective
and should have obtained at least 45% aggregate marks for General Category (40% marks for
SC/BC/PWBD category) in Physics, Chemistry, Biology & English (PCB& E) taken together,
however, the candidates should have obtained pass marks in each subject separately.
c) In-service candidates. All in-service candidates (Regular employees of Health Department/
Medical Education Department) shall have to obtain an N.O.C. issued by the DGHS / UHS,
Rohtak / Director of concerned Medical College, as the case may be.
i. No in-service candidate shall be considered for admission without valid NOC
ii. 20% of seats in each paramedical course shall be reserved for In-service candidates.
iii. To qualify for In-service quota seat(s), the candidate(s) shall have to fulfil the following
eligibility criteria / conditions for each course as explained under:
a. Bachelor of Optometry (B. Optometry) Course: In-service candidates who
have passed the course of Opthalmic Assistant/Optometry/Orthotist (Minimum
2-year duration) from any recognized Board/ Council/ University. He/she should
have a minimum experience of 3 years or more as Optometrist/Opthalmic
Assistant from Government Institutes under Department of Health/Department of
Medical Education & Research, Government of Haryana.
b. B.Sc. in Operation Theatre (OT): In-service candidates who have passed
Diploma in Operation Theatre Technician (Minimum 2 year duration) from an
Institution/ Board/Council recognized by Haryana Government with a minimum
of 3-year experience as OT Assistant/OT Master from Government Institutes of
Department of Health/Department of Medical Education & Research, Government
of Haryana.
c. For B.Sc. Medical Lab Technology (B.Sc. MLT) Course: In-service candidates
who have passed diploma in MLT (Minimum 2-year duration) from Institutions/
Board/ Council recognized by Haryana Government and have a minimum of
3 years of regular service from Government Institutes of Department of
Health/Department of Medical Education & Research, Government of Haryana.
d. B.Sc. in Radiography & Imaging Technology: In-service candidates who have
passed diploma in Radiography (Minimum 2-year duration) from the Institutions/
Board/Council recognized by Haryana Government and have a minimum of
3 years of regular service from Government Institutes of Department of Health/
Department of Medical Education & Research, Government of Haryana.
e. For B.Sc. Radiotherapy Technology: In-service candidates who have passed
diploma in Radiotherapy (Minimum 2-year duration) from Institutions/
Board/Council recognized by Haryana Government and have a minimum of
3 years of regular service from Government Institutes of Department of Health/
Department of Medical Education & Research, Government of Haryana.
f. For B.Sc. Perfusion Technology: In-service candidates who have passed
diploma in Perfusion Technology (Minimum 2-year duration) from the
Institutions/Board/Council recognized by Haryana Government and have a
minimum of 3 years of regular service from Government Institutes of Department
of Health/Department of Medical Education & Research, Government of Haryana.

<!-- page 5 -->

1798

8.

9.
i.

ii.

iii.
iv.
v.

vi.

vii.

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Notes:
1. Seats remaining vacant in In-Service category shall be converted to Open merit seats Category
(of the same class: General / SC / BC / PWBD etc.)
2. The candidates who have been provisionally allotted seats will have to bring, in original, all the
relevant certificates/documents at the time of document verification without which admission to
any course shall not be granted. Attested photocopies of certificates/documents will not be
considered valid for the purpose of admission and the seat allocated to them online shall be
cancelled.
3. After exhaustion of merit list of In-service candidates, vacant seats (if any) shall be reverted to
their original category of seats and if still there is a vacancy, the same shall be converted to
unreserved category seats as per State Reservation Policy/Instructions.
4. After exhaustion of merit list of the candidates who have applied under various reserved
categories, vacant seats (if any) shall be reverted back to their original category(ies) of seats as per
State Reservation Policy and filled up as per merit after conversion (For eg. BC-A seat to BC-B
and finally to UR) and filled up in the 3rd round itself for both Government and Private Institutes.
However, in case of any seat falling vacant after the 3rd round in any category, it shall
first be offered to candidates belonging to original category of vacant seat of the previous round.
In case, if the seat still remains vacant, the same shall be filled as per system in the 3rd round and
so on. The conversion scheme shall be as per system followed by Medical Counseling Committee
(MCC) for filling up All India Quota seats and State Reservation Policy and any amendments
thereof.
5. All candidates who wish to participate in the 2nd round and subsequent rounds of counselling, shall
have to submit a security amount of Rs 1000/- for Government Colleges and Rs 5000/- in case they
want to participate in Private Colleges or both Government and Private Colleges. In case the
candidate does not join on the allotted seat during the second/ subsequent rounds, the security
amount shall be forfeited and if he/she joins, the same shall be adjusted in the tuition fee.
After commencement of Courses, if a candidate having joined the Institute leaves the course midway: (i) He/she will be debarred for next 3 years from applying for admission to any Nursing/
Physiotherapy/Paramedical degree course in the State.
(ii) He/she will have to pay the fee of the Academic Session during which he/she leaves the course
along with the 50% of fee of the next Academic Session.
Procedure for Admission:
The admissions under above stated categories will be made on the basis of Common Entrance Test 2025
(CET-2025) conducted by Pt. B.D Sharma University of Health Sciences, Rohtak. The schedule of
counselling, admissions and start of classes shall be in conformity with the schedule laid down by Indian
Nursing Council / State Government/Haryana Nurses & Nurse Midwives Council/Haryana State Council
of Physiotherapy/Pt. BD Sharma UHS, Rohtak as the case maybe.
The relative merit, among such candidates desirous of seeking admission shall be drawn as per the merit
of Common Entrance Test conducted by the University. Candidates (including in-service candidates)
should fulfil the minimum eligibility criteria examination for being granted admissions.
Admission will be made through Online Centralised Counselling from the list of registered candidates on
the admission web portal as per merit in respective qualifying examination (CET).
The choice of the course/institution exercised by the candidate on the Online Admission webportal will
be considered final and no further change will be allowed.
The allotment of the Institute/course shall be made strictly as per merit prepared/drawn on the basis of
qualifying examination (CET) and the choice/preference of the Subject/Course/Institute filled up by the
candidate on the online portal.
Personal appearance of the Candidates with all original documents shall be compulsory at the time of
reporting to the Admission Committee. Attested photocopies of certificates/documents will not be
considered valid for the purpose of admission.
All admissions shall be provisional subject to verification/checking of eligibility for admission as per the
original documents produced at the time of reporting to the Admission Committee.
The provisional allocation of the Seat/Institute online shall confer no legal right to the candidate for the
said seat and the seat shall be confirmed only after the document verification as per the specific period
notified.

<!-- page 6 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
viii.

ix.
x.

xi.
xii.

xiii.

xiv.

1799

The Admission Committee constituting of the following, shall be formed:
1
Dean Academic Affairs, Pandit Bhagwat Dayal Sharma Chairperson
University of Health Sciences, Rohtak
2
Director/Principal of all Government Nursing/
Member
Physiotherapy/Paramedical Institutions
3
Law Officer, Pandit Bhagwat Dayal Sharma University of Member
Health Sciences, Rohtak
4
A regular Professor, to be nominated by Director Medical Member Secretary
Education & Research, Haryana, Panchkula.
The Admission Committee will be responsible for taking decision for admission related matters likesupervision of admission web-portal, conduct of counselling, document verification, allocation of seats,
disputes thereof etc in accordance with existing rules and regulations.
The Director General Medical Education and Research, Haryana shall be the Appellate Authority to hear
the appeal for the decisions taken by the Admission Committee. Appeal can be sent with copy of decision
of Admission Committee to the Directorate of Medical Education & Research, Haryana, Panchkula,
4th floor, DHL Square, Plot no.9, IT Park, Sector 22, Panchkula, Haryana- 134112, email: dmerhry@nic.in; Website: https://dmer.haryana.gov.in/
Final number of seats in each course/institute under each Category will be available on the website- i.e.,
https://uhsr.ac.in; https://dmer.haryana.gov.in and also on the admission web portal.
Process for Admission to Management Category seats in Private Nursing/Physiotherapy/
Paramedical Institutes of Haryana:
Similar procedure as described above for counselling for filling up State Quota seats in Government and
Private Institutes will be followed for admissions to Management Category seats as per the eligibility
criteria.
(a) In case there is a vacancy after the first round of counselling due to any reason, such seats will be
filled up during the second round of counselling by the same process.
(b) Fresh registration shall be allowed for participating in the second round / Mop up
round/subsequent rounds. Fresh candidates will have to register themselves on the admission
web-portal.
(c) The candidates, who have joined on the allotted institute/course up-to 2nd Round shall not be
allowed to participate in the subsequent rounds.
(d) Seats remaining vacant after 2nd round shall be filled up in 3rd round/Mop Up round and
subsequent round(s) by way of conduct of Stray round/Extended Stray round (s) held before the
last date of admissions as notified by the State Government.
Tie – Braking
In case of a tie between two or more candidates having equal Marks/Merit, in entrance exam the inter-seranking of such candidates shall be determined as follows:For B. Sc. Nursing, BPT, Paramedical Courses:
1. A candidate with higher aggregate marks in the respective qualifying examination will be ranked
higher.
2. Still if there is a tie then, a candidate older in age will be ranked higher in merit
3. Still if there is a tie then, alphabetically the one who comes first.
For Post Basic B. Sc. Nursing Course:
1. A candidate with higher aggregate marks in General Nursing & Midwifery will be ranked
higher.
2. Still if there is a tie then, a candidate older in age will be ranked higher in merit
3. Still if there is a tie then, alphabetically the one who comes first.
For M. Sc. Nursing Course and Nurse Practitioner Critical Care Programme (NPCC):1. A candidate with higher aggregate marks in B.Sc. Nursing/B.Sc. Nursing Honors/Post Basic
B.Sc. Nursing course will be ranked higher.
2. Still if there is a tie then, a candidate older in age will be ranked higher in merit
3. Still if there is a tie then, alphabetically the one who comes first.
For MPT:1. A candidate with higher aggregate marks in BPT.
2. Still if there is a tie then, a candidate older in age will be ranked higher in merit
3. Still if there is a tie then, alphabetically the one who comes first.

<!-- page 7 -->

1800
xv.

xvi.

xvii.

10.

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
All Private Aided/Unaided Institutes will deposit a processing fee for counselling @Rs. 2000/- per
sanctioned intake of seats one week before the start of the counselling.
The fee for the seats filled during counselling shall be retained and the balance amount (corresponding to
the vacant seats) shall be Returned/Refunded to the Institute within six weeks of completion of
counselling process.
The Registration cum Counselling fee (Non-Refundable) shall be as under:
a) Rs. 1000/- for Unreserved Category.
b) Rs. 750/- for SC/SC-D/BC-A/& BC-B, PWBD, FF, ESM, EWS Category candidates of Haryana.
Eligible candidates seeking benefit under Post Matric Scholarship shall have to upload the following
documents in original at the time of document verification:
a. Caste Certificate.
b. Aadhar Card.
c. Account Number along-with IFSC Code.
d. PPP ID
Admission to NRI Category (NRIs/PIOs/OCIs/Foreign Nationals)
All admissions under NRI category seats shall be as per merit of CET-2025. Only CET qualified
candidates shall be eligible under NRI category. PIOs, OCIs and Foreign Nationals who are CET
qualified can also apply under the NRI category, however for admission under NRI quota Foreign
Nationals shall be considered only for any vacant seat left after exhausting the list of NRIs/PIOs/OCIs.
Preference of admission shall be as given below:
i.
Actual NRIs/OCIs/PIOs candidates who originally belonged to the State of Haryana.
ii.
Children of NRIs/OCIs/PIOs who originally belonged to Haryana State.
iii.

Actual NRIs/OCIs/PIOs who originally belonged to an Indian State and Union Territories
other than Haryana.

iv.

Children of NRIs/OCIs/PIOs who originally belonged to an Indian State and Union Territories
other than Haryana

v.

Real Brother and sister of candidate.

vi.

If the first-degree relation of the student is NRI and residing abroad and the candidate fulfils
the following condition: a) He should be the nearest relation.
b) In the definition of nearest relation, candidate having following blood relation:  Real Brother and sister of father i.e., real uncle and real aunt.
 Real brother and Sister of mother i.e., real maternal uncle and maternal aunt.
 Father and mother of father i.e., grandfather and grandmother.
 Father and mother of mother i.e., maternal grandfather and maternal
grandmother.
 First degree-paternal and maternal cousins.
 Such person should be NRI
c) Such persons should ordinarily be residing abroad.
d) Such person should have looked after such student as the guardian of the student and
evidence to that effect must have been produced by such person.
Foreign Nationals shall be considered for admission under NRI quota after exhausting the list
of NRIs/ PIOs/OCIs.

vii.

Notes:
 If sufficient number of eligible candidates under first category are available then they
will be admitted first even if students under subsequent category are higher in merit.
 The NRI students will have to give a Bank Guarantee/Surety Bond for the balance of
fee, if they opt to pay the fee in instalment as provided.
 If the seats still remain vacant after 2nd round these shall be converted to General
Category seats.

<!-- page 8 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
11.

12.

1801

Fee Structure
A. The Fee structure for Government Nursing, Physiotherapy, Paramedical courses is at
Annexure (V)
B. The Fee structure for Private Nursing and Physiotherapy courses is at Annexure (VI)
C. The fee for the First-year course shall be deposited by the successful candidates in the accountcounselling and admission on account for Department of Medical Education and Research
(DMER). The details will be available on the admission web portal.
D. The fee shall be transferred to the respective institute by the Chairman Admission Committee
within one month after completion of the admission process.
E. The Fee will be payable on annual basis only and the institutes shall not insist upon the
candidates to deposit fee for the entire course in advance (any violation will attract penal action
as per the Act, 2012).
F. The Tuition fee shall be adjusted if the candidate is shifted in subsequent counselling from one
Institute to another in the subsequent counselling. In case of request for withdrawal of admission
by a candidate the fee shall be refundable to the candidate, only if the request is made in person
along with original receipt of fee deposition and no request shall be entertained through e-mail.
The candidate will have to make the request at least 03 days prior to the last date prescribed for
admission to Nursing / Physiotherapy / Paramedical courses
G. In case of request for withdrawal of admission by a candidate after the last date of admission, the
fee shall NOT be refundable to the candidate except on account of death or serious mental
illness/serious grievous hurt.
H. No request for withdrawal of admission will be accepted through email. Candidates shall have to
physically give the resignation letter in the admitted Institute, along with obtaining a proper
receipt of the same from Admissions Section of the Institute concerned.
General Instructions:a. List of documents to be brought at the time of reporting to the institution is at Annexure- VII.
b. Admitted students will be required to pay fees and other charges as per the Notification.
c. All kind of fees like registration fee, tuition fee, security fee, caution fee, processing fee etc. will
be drawn in the account “Counselling and Admission on A/C for Department of Medical
Education & Research (DMER)”. The details shall be available on the Admission Web portal.
d. All candidates belonging to the Scheduled Castes/ Backward Classes/ EWS/ PWBD/ ESM/ FF
etc. must submit a certificate in the prescribed format issued from the competent authority
claiming the benefit of reservation.
e. The eligibility criteria for admission to Backward Classes shall be as per Haryana Government
Notification dated 16.07.2024 as amended from time to time. (Annexure-VIII).
f. Only Dependents of Freedom Fighters (FF) who wish to be considered for reservation as such
must submit a certificate from the Competent Authority along with undertaking (Annexure-IX).
g. The reservation to Ex-servicemen and their wards will be considered as per notification of
Haryana Government, General Service III Branch No. 22/10/2013-1 GSIII dated 10.08.2017.
(Annexure-X).
h. A candidate from reserved Category shall have the right to compete for admission in unreserved
Category seats as per his/her merit. In case a candidate does not fill up his reserve Category in
his application form, he/she will not be subsequently considered for admission against that
category. However, if a reserved Category candidate has availed any concession, such as
relaxation in upper age limit, qualification or permitted number of chances in written
examination etc., then he/she cannot be considered against Un-reserved seats.
i. Any candidate, if found to have submitted any false documents/claim benefit of reservation on
the basis of false documents will be liable for penal action as per relevant section of law and
his/her candidature shall be cancelled immediately and shall be debarred for admissions in
future.
j. The admission shall be made to only those Institutes which are
i. possess valid NOC issued by Department of Medical Education and Research and are
permitted for admission by Department of Medical Education & Research for the current
academic session.,
ii. are affiliated to Pt. BD Sharma UHS Rohtak,
iii. recognized by Haryana Nurses and Nurse Midwives Council (HN&NMC)/Haryana State
Council of Physiotherapy, and

<!-- page 9 -->

1802

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
The institutes that are unable to get such recognition/approval from Government and affiliation
from Haryana Nurses and Nurse Midwives Council/ Haryana State Council of Physiotherapy
shall not be considered for counselling
k. If any institute makes admissions on the seats more than the permitted seats, no registration
number will be provided to such candidates and legal action will be initiated against the erring
institute under The Haryana Private Health Sciences Educational Institutions (Regulation of
Admission, Fixation of Fee and Maintenance of Educational Standard) Act, 2012. The said
institute shall be completely and solely responsible for any legal damages arising out of such
issue.
l. If any Institute Charges any excess fee from any candidate other than the already notified fee or
fails to comply with any of the provisions of this notification, action against the Institute shall be
initiated as per provisions of The Haryana Private Health Sciences Educational Institutions
(Regulation of Admission, Fixation of Fee and Maintenance of Educational Standard) Act, 2012
of the Department.
m. All Institutes shall follow the Central/State Government Scheme guidelines for disbursement of
Post Matric Scholarship for SC/OBC Beneficiaries.
n. No Private Institution shall prevent any student (PMS Beneficiary) for attending classes/exam/
practical classes etc. or cause any financial/mental harassment of any kind in case any PMS
Beneficiary students. Scholarship fee is not deposited.
o. Any admission made by the Institute other than procedure adopted under this Notification will
be invalid.
p. Any amendments by State Government/Pt. BD Sharma UHS Rohtak shall have a binding on any
provisions contained in this Notification.

Chandigarh:
The 8th August, 2025.

SUDHIR RAJPAL,
Additional Chief Secretary to Government Haryana,
Medical Education & Research Department, Chandigarh.

<!-- page 10 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1803
Annexure -I

No.22/12/2019-1GS-III
Government of Haryana
General Administration Department
(General Services III Branch)
Dated Chandigarh, the 25th February, 2019
To
1.
2.
3.
4.
5.
6.
7.
Subject:-

All the Administrative Secretaries to Government, Haryana.
All Heads of Department in the State of Haryana.
All the Managing Directors/Chief Administrators of Boards /Corporations /Public Sector Undertakings
in Haryana.
The Registrar General of Punjab & Haryana High Court, Chandigarh.
All the Divisional Commissioners in the State of Haryana
All the Deputy Commissioners and Sub Divisional Officers (Civil) in the State of Haryana.
The Registrars of all the Universities of the State of Haryana.
Reservation for Economically Weaker Sections in Direct recruitment in Civil posts and
services as well as in admissions in Government/Government Aided Educational Institutions
in the State of Haryana.

I am directed to inform that Government of India has notified “THE CONSTITUTION (ONE
HUNDRED AND THIRD AMENDMENT) ACT, 2019” On 12th January, 2019 amending Article 15 & 16, which are
now read as under:Amendment of article 15
In Article 15 of the Constitution, after clause (5), the following clause shall be inserted namely:‘(6) Nothing in this article or sub-clauses (g) of clause(1) of article 19 or clause (2) of article 29 shall prevent the State
from making,a) Any special provision for the advancement of any economically weaker sections of citizens other than the
classes mentioned in clauses (4) and (5); and
b) Any special provision for the advancement of any economically weaker sections of citizens other than the
classes mentioned in clauses (4) and (5); in so far as such special provisions relate to their admission to
educational institutions including private educational institutions, whether aided or unaided by the State,
other than the minority educational institutions referred to in clause(1) of article 30, which in the case of
reservation would be in addition to the existing reservations and subject to a maximum of ten per cent of the
total seats in each category.
Explanation- For the purposes of this article and article 16, “economically weaker sections” shall be such as
may be notified by the State from time to time on the basis of family income and other indicators of
economic disadvantage.’
Amendment of article 16
In Article 16 of the Constitution, after clause (5), the following clause shall be inserted, namely:“(6) Nothing in this article shall prevent the State from making any provision for the reservation of appointments or
posts in favour of any economically weaker sections of citizens other than the classes mentioned in clause (4), in
addition to the existing reservation and subject to a maximum of ten per cent of the posts in each category”.
In the wake of above enabling provisions, State Government has considered the matter and decided to provide
benefits of reservation on a preferential basis in Civil Posts in all the Departments/Boards/Corporations/Local Bodies

<!-- page 11 -->

1804

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

and in Admissions to Government/Government Aided Educational Institutions to those Economically Weaker
Sections (EWSs) who are not covered under the existing scheme of reservation for the Scheduled Castes, Backward
Classes (Block-A) and Backward Classes (Block-B).
2. QUANTUM OF RESERVATION:
The persons belonging to EWSs who are not covered under the existing scheme of reservation for Scheduled
Castes, Backward Classes (Block-A) and Backward Classes (Block-B) shall get 10% reservation in direct recruitment
to Group A,B,C and D posts in the Departments/Boards/Corporations/Local Bodies of Government of Haryana and
also in admission to Government/Government Aided Educational Institutions in the State of Haryana.
3.
EFFECTING RESERVATION-ROSTER POINT:
3.1
Direct recruitment in case of Group-A & B
Roster point No. 11-20-30-40-51-60-70-80-90 and 99
3.2
Direct recruitment in case of Group-C &D
Roster point No. 4-14-24-34-43-53-66-76-83 and 94
3.3
Where in any recruitment year any vacancy earmarked for EWS cannot be filled up due to non availability of a
suitable candidate belonging to EWS, such vacancies for that particular recruitment year shall not be carried forward
to the next recruitment year as backlog and will be filled from unreserved category.
3.4
Persons belonging to EWS selected against the quota for persons with benchmark disabilities/ex-servicemen
shall be placed against the roster points earmarked for EWS.
4. CRITERIA OF INCOME & ASSESTS
4.1 Persons who are not covered under the existing scheme of reservation for Scheduled Caste, Backward Classes
(Block-A) and Backward Classess (Block-B) and whose family has gross annual income below Rs. 6.00 lakh (Rupees
six lakh only) are to be identified as EWSs for benefit of reservation Income shall also include income from all
sources i.e. salary, agriculture, business, profession etc. for the financial year prior to the year of application.
4.2 Also persons whose family owns or possesses any of the following assets shall be excluded from being identified
as EWS, irrespective of the family income:I. 5 acres of agricultural land and above.
II. Residential flat of 1000 sq. ft. and above.
III. Residential plot of 100 sq. Yards and above in notified municipalities.
IV. Residential plot of 200 sq. Yards and above in areas other than the notified municipalities.
V. Total immovable assets owned are valued at Rs. One Crore or more.
4.3 The property held by a “Family” in different locations or different places/cities would be clubbed while applying
the land or property holding test to determine EWS status.
4.4
The team “Family” for this purpose will include the person who applies for benefit of reservation, his/her
parents, spouse as well as children and siblings below the age of 18 years.
5.
INCOME AND ASSET CERTIFICATE ISSUING AUTHORITY AND VERIFICATION OF
CERTIFICATE:
5.1
The benefit of reservation under EWS can be availed upon production of an income and Asset Certificate
issued by a Competent Authority. The Competent Authority for EWS Income and Asset Certificate shall be
Tehsildar of the area where the applicant normally resides.
5.2
The prescribed format for EWS Income and Asset Certificate shall be as provided at Annexure-I.
5.3
The Officer who issues the certificate would do the same after carefully verifying all relevant documents
following due process as prescribed by the State.
5.4
The crucial date for submitting Income and Asset Certificate by the candidate may be treated as the closing
date for receipt of application for the post, except in cases where crucial date is fixed otherwise.
5.5
The appointing authorities should in the offer of appointment to the candidates claiming to be belonging to
EWS, include the following clause:“The appointment in provisional and is subject to the Income and asset certificate being verified through the
proper channels and if the verification reveals that the claim to belong to EWS is fake/false the services will be
terminated forthwith without assigning any further reasons and without prejudice to such further action as may
be taken under the provisions of the Indian Penal Code for production of fake/false certificate.”

<!-- page 12 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

5.6

6.

7.

1805

The appointing authority should verify the veracity of the Income and asset certificate submitted by the
candidate through the certificate issuing authority.
Instructions referred to above should be strictly followed so that it may not be possible for an unscrupulous
person to secure employment on the basis of a false claim and if any person gets an appointment on the basis of
such false claim, her/his services shall be terminated and penal action shall also be invoked.
ADJUSTMENT AGAINST UNRESERVED VACANCIES:
A person belonging to EWS cannot be denied the right to compete for appointment against an unreserved
vacancy. Persons belonging to EWS who are selected on the basis of merit and not on account of reservation
are not to be counted towards the quota meant for reservation.
The above scheme of reservation will be effective in respect of all direct recruitment vacancies to be notified
on or after 01.02.2019.

(Vijayendra Kumar, IAS)
Secretary, General Administration Department,
for Chief Secretary to the Government of Haryana.

<!-- page 13 -->

1806

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure (I) (i)
Government of Haryana
(Name & Address of the Authority issuing the certificate)
(ECONOMICALLY WEAKER SECTIONS)
INCOME DISCLOSURE CERTIFICATE

Certificate No…………………….

Date …………………………….

VALID FOR THE YEAR …………………………………
This is to certify that Shri/Smt/Kumari ……………………………………… son/daughter/wife of
………………………….….. is permanent resident of ………… village/street……………………………………..,
Post Office……………………..…………, District…………………………., Pin Code ………………………………
whose photograph is affixed below and attested below belongs to Economically Weaker Sections, Since the gross
annual income* of his/her family** is below Rs.6 Lakhs (Rupees Six Lakh only) for the Financial Year
………………..
It is further certified that His/her family does not own or possess any of the following assets***:
I. 5 acres of Agricultural Land and above.
II. Residential Flat of 1000 Sq. ft. and above.
III. Residential Plot of 100 Sq. Yards and above in notified Municipalities.
IV. Residential plot of 200 sq. yards and above in areas other than the notified municipalities.
V. Total immovable assets owned are valued at Rs.OneCrore or more.
2.
Shri/Smt/Kumari ………… belongs to the caste which is not recognized as a Scheduled Caste,
Backward Classes (Block-A) and Backward Classes (Block-B)
Recent Passport
Size attested

Signature with seal of office
Name
Designation

Photograph of the
applicant

*Note 1:
**Note 2:

***Note 3:

Income means income from all sources i.e. salary, agriculture, business profession etc.
The term “family’’ for this purpose will include the person, who applies for benefit of
reservation, his/her parents, spouse as well as children and siblings below the age of 18
years
The Property held by a “Family” in different locations or different places/cities are to be
clubbed while applying the land or property holding test to determine EWS status.

<!-- page 14 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1807
Annexure II

Copy of letter No. 62/17/95-6 GSI Dated, Chandigarh, the 3rd October, 1996 received from the Chief Secretary to
Government Haryana addressed to All Heads of Departments, Commissioners Ambala, Rohtak, Gurgaon and
Hisar Divisions, All Deputy Commissioners and all Sub Divisional Officers (Civil) in Haryana, The Registrar,
Punjab and Haryana High Court and all District and Session Judges in Haryana.
Subject:

“Bonafide residents of Haryana - Guidelines regarding”.

I am directed to invite your attention to Haryana Govt. letters noted in the margin on the subject
noted above vide which the instructions were issued regarding simplification of procedure for obtaining the
certificate of Domicile for the purpose of admission to educational institution (including technical/Medical
institution). The matter has been reconsidered in the light of judgment delivered by the Hon’ble Supreme Court of
India in the case of Dr. Pradeep Jain vs. Union of India and others reported as AIR 1984-SC-1421, wherein it has
been held that instead of the word ‘Domicile’ the word ‘Resident’ be used in the instructions issued by the State
Government and it has been decided to revise the Government instructions. Henceforth, the following categories of
persons would be eligible for the grant of Resident Certificate: i) Candidates, who have passed the examination qualifying there for selection in an institution from a
school/college in Haryana.
ii) Children/Wards (if parents are not living)/Dependents: (a) of the regular employees of Haryana State posted in or outside Haryana State or working on
deputation;
(b) of the regular employees of the statutory bodies/corporations established by or under an act of the
State of Haryana who are posted in Chandigarh or in Haryana or outside Haryana.
(c) of the regular employees of the Government of India posted in Chandigarh or in Haryana in
connection with the affairs of the Haryana Government;
iii) Children/wards (if parents not living)/dependents of persons who after retirement have permanently settled in
Haryana and draw their pensions from the treasuries situated in the State of Haryana.
iv) Children/wards (if parents are not living)/dependents of pensioners of Haryana Government irrespective of
the fact that the original home of the retiree is in a state other than Haryana or he has settled after retirement
in or outside Haryana;
v) Children/Wards (if parents are not living)/dependents of persons, who have permanent home in Haryana and
include persons who have been residing in Haryana for a period of not less than 15 years or who have
permanent home in Haryana but on account of their occupation they are living outside Haryana;
vi) The wives of such persons who are bonafide residents of Haryana irrespective of the fact that they had
belonged to any other State before marriage;
vii) Persons who were born in Haryana and produce a certificate to that effect; provided that the
parents/guardians (if parents are not living) of persons belonging to any one of the above mentioned
categories are:
a) Citizen of India;
b) Produce an affidavit to the effect that they or their children/wards (if parents are not
living)/dependents have not obtained the benefit of Resident in any other State.
2.
All candidates claiming to be bonafide residents of Haryana should produce a Haryana Resident Certificate
signed by the District Magistrate/General Assistant to Deputy Commissioner or Sub-Divisional Officer (Civil)
of the District/Sub-Divisions to which the candidates belong. Resident Certificates in respect of elsewhere or in
respect of the Children/Wards/Dependents of Haryana Govt. employees who are posted at Chandigarh, Delhi
or elsewhere or in respect of Children /Wards/ Dependents of pensioners of Haryana Govt. or in respect of the
Children/Wards/ Department of the employees of the Government of India posted at Chandigarh or in Haryana
in connection with the affairs of Haryana Government, or in respect of Children/Wards/Dependents of the
employees and retirees of the Statutory Bodies/Corporations of Haryana established by or under an Act of

<!-- page 15 -->

1808

3.

4.

5.
6.

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
the State of Haryana or a Central Act and located at Chandigarh, Haryana or outside Haryana, should be
by their respective Heads of Departments.
Candidates seeking admission in educational institutions (including Medical and technical institutions) located
in Haryana may not be required to produce Resident Certificate, if they have passed the examination from a
school/college situated in Haryana. For this purpose, a certificate of the Principal/Headmaster from concerned
institution where the children/wards studied last should be considered sufficient. The Principal/Headmaster of
the institution shall be competent to issue such certificate, which should be sufficient.
If a candidate is admitted on the basis of claim that he belongs to the State of Haryana but at any subsequent
time is discovered that his claim was false, the student shall be removed from the institution, all fees and other
dues paid up to the date of such removal shall be confiscated. The Principal/Headmaster may take such other
action against the student and his/her parents/guardians as he may deem proper in the circumstances of any
particular case.
For the purpose of uniformity for issuing certificate of Residence in the case of various categories to be issued
by the competent Authorities, proforma have been prescribed which are enclosed herewith.
These instructions may kindly be noted carefully for compliance and the receipt of this letter may please be
acknowledged.

<!-- page 16 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1809
Annexure III

U.O. No. 62/27/2003- 6 GSI
From:

Dated, Chandigarh the July 29, 2003

The Chief Secretary to Government Haryana

To
1.
2.
3.
4.
5.
6.

All the Heads of Departments in Haryana
The Commissioners Rohtak, Gurgaon, Hissar and Ambala divisions.
The Registrar, Punjab and Haryana High Court
All the Deputy Commissioners in Haryana
The Managing Directors of all Boards and Corporations in Haryana
The Registrars, MaharshiDayanand University, Rohtak, Kurukshetra University, Kurukshetra, Ch.
Charan Singh Haryana Agriculture University, Hissar, Guru Jambheshwar University, Hissar and
Ch. Devi Lal University, Sirsa.

Sub : Bonafide residents of Haryana – Guidelines regarding.
Sir,
I am directed to invite your attention to Haryana Government circular letter No. 62/17/95-6GSI, dated 3.10.96
and No. 62/32/2000 - GSI, dated 23.5.2003 on the subject noted above vide which the instructions were issued
regarding simplification of procedure for obtaining the certificate of resident purpose of admission to educational
institutions (including technical/ Medical institutions)
2.
The matter has been reconsidered by the State Government in view of the problems faced by the children and
wards of accredited journalists recognized by Government of Haryana and it has been decided that the children and
wards of the accredited journalists residing at Chandigarh and recognized by Government of Haryana would also be
eligible for the grant of Residence Certificate only for the purpose of admission in the academic institutions of
Haryana State.
3.
These instructions may kindly be noted carefully for compliance and the receipt of this letter may please be
acknowledged.
Yours faithfully,
Sd/Under Secretary General Administration
for Chief Secretary to Government Haryana
A copy is forwarded to all the Financial Commissioners and Principal Secretaries/ Commissioners and Secretaries to
Government of Haryana for information and necessary action.
Sd/Under Secretary General Administration
for Chief Secretary to Government Haryana

<!-- page 17 -->

1810

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure IV
Copy of letter No. 22/28/2003-3G.S.III Dated, Chandigarh the 30thJanuary, 2004.

From
The Chief Secretary to Government Haryana.
To
1.
2.
3.
4.
5.

All Heads of Departments in Haryana.
The Commissioners, Rohtak, Gurgaon, Hisar and Ambala Divisions.
The Registrar, Punjab and Haryana High Court, Chandigarh.
All the Deputy Commissioners in Haryana.
The Registrars, Maharshi Dayanand University, Rohtak, Kurukshetra University, Kurukshetra, Ch.
Charan Singh Haryana Agriculture University, Hisar, Guru Jambheshwar University, Hisar and Ch.
Devi Lal University, Sirsa (Haryana).
Dated, Chandigarh the 30th January, 2004.

Subject:

“Streamlining the procedure in the offices regarding issuing of Resident /Income Certificates
and the caste certificate to Scheduled Castes and Backward Classes”.

Sir,
I am directed to invite your attention to Haryana Government letters Nos. 62/17/95-2G.S.III, dated
03.10.96, No. 22/51/93-3G.S.III, dated 12.8.93 and even No. dated 14.10.97 on the subject noted above wherein
instructions regarding the caste certificates (SC/BC/OBC), and Resident certificates have been issued.
2.
The policy has been reviewed keeping in view the various courts judgments and the hardships caused to the
individuals in obtaining above quoted certificates. Government is of the view that the procedure be
institutionalized by delegating powers at proper level for ensuring speedy disposal of work without any
harassment or exploitation. The present modification of the policy also aims at simplifying the procedure for
obtaining certificate by an individual falling under the reserved categories.
The matter has also been reconsidered in depth by the State Government in view of the problems being faced
by the Government employees in obtaining these certificates. With a view to improve the existing system in
issuing various certificates, it has been decided by the Government that henceforth Circle Revenue Officers
(Tehsildar/NaibTehsildar-cum-Executive Magistrate) concerned will be authorized to issue Resident as well
as Caste Certificates (SC/BC/OBC) after getting the verification done through the subordinate revenue staff
in case of applicants residing in the rural area and through the Executive Officer/Secretary of the concerned
Municipal Committee/Municipal Council/Municipal Corporation concerned in case of applicants residing in
urban area. It has further been decided that in case of Haryana Government employees serving in the offices
located at Chandigarh/Panchkula and residing at Chandigarh/Panchkula, the Resident certificates and caste
certificate to SC/BC employees and for their children, may be issued by their respective Heads of
Departments also.
3.
The validity of Resident Certificate issued by the competent authority shall be as long as the holder of this
certificate maintains his residential address in Haryana State.
4.

SC certificate once issued shall be valid as long as the caste is not removed from the Schedule of the
Constitution and BC certificate shall be valid for life from the date of issue of the certificate or till the
applicant does not fall into creamy layer Category as defined from time to time. The applicant applying for
BC certificate would also submit a self declaration on simple paper that he does not fall under creamy layer
category. The format for this declaration is given at Annexure ‘A’ However, if the certificate has been
obtained by fraud or misrepresentation or concealment of facts or by some other means, the said certificate
shall be declared as invalid/non-est and benefit taken by the applicant will be withdrawn and a criminal case
shall be registered against the applicant misrepresenting the facts as well as against the guilty
officers/officials, if any. In addition, Social Justice & Empowerment Department, Haryana is being, directed
to finalize the modalities and procedure to constitute the Scrutiny Committee.

<!-- page 18 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

5.

1811

The files relating to Caste and Resident certificate shall be retained for 10 years and Register shall be retained
permanently. The proforma of the application form, Register and SC/BC certificates prescribed by the
Government shall be followed by all the Departments/Institutions in letter and spirit as it has come to the
notice of the Govt. that some Departments/Institutions demand such certificates in proforma which are at
variance with the proforma in which these certificates are being issued by the competent authorities
(Tehsildar / NaibTehsildar/HODs). It is, therefore, decided that the Departments/Institutions shall accept
these certificates only in the proforma in which these are being issued by the competent authorities which
have been prescribed by the Govt. itself (copy enclosed).
To make institutional arrangements, it has also been decided that in future the Resident and Caste certificates
will be issued to all the students studying in class 8th every year as per the time schedule given below:-

i.

Filling of application form by the parents/students.

1 st Nov. to 10th Nov.
every year

ii.

Verification by (a) Sarpanch/ Namberdar,
in case of rural areas and Municipal Councillors
in case of Urban areas.

upto 15 th November
every year

(b)Verification by Patwari in case of
rural areas /EO/Secy.(MC)
any other officer/official authorized by
the local body for the purpose in case
of urban areas.

30 th November

(c) Head Teacher/Head Master

upto 15th Dec.

iii.

Forwarding of application to CRO
by Head Teacher/Head Master

31st Dec.

iv.

Verification & issue of certificate
by CRO

upto 31st January
every year

6.

All application forms of a particular School may be sent to the Tehsildar / NaibTehsildar concerned preferably
at one go so that the certificates are issued and sent back to the Head masters of Government Schools/Private
Schools for distribution to the concerned students. The Head Teacher/Head Master shall be responsible for
getting the application forms filled and files prepared of all the students presently studying in Class-VIII to XII
will be issued these certificates during the months of January, 2004 to March, 2004. The schedule will be
finalized by the concerned Deputy Commissioner in this regard.

7.

It has been further decided that in case of SC/BC students claiming benefit under various welfare schemes upto
Class IX, the benefits will be given by the Head Master/Head Teacher after getting the verification done from
Sarpanch/ Namberdar/MC and a caste certificate issued by the CRO (Tehsildar / NaibTehsildar) may not be
demanded for this purpose by the School authorities.

8

The matter regarding issue of income certificate to the students for claiming various benefits in educational
institutions has been considered and it has been decided that in future the income certificate for educational
purpose will be issued by the CRO (Tehsildar / NaibTehsildar concerned) and income certificate for other
purposes by the SDO (C) concerned taking into account income of the applicant from various sources
including agriculture, trade, profession, salary etc. The verification will be got done through the subordinate
revenue staff in case of applicants residing in rural areas and through the Executive Officers/Secretary of the
concerned Municipal Committee/Council/Municipal Corporation in case of applicants residing in urban areas.

9.

It has also been brought to the notice of the Government that when posts are advertised, fairly large number of
candidates apply for such posts and Haryana Public Service Commission/Haryana Staff Selection Commission
/Department demand attested copies of Resident/Caste certificates and other documents from the candidates.
This creates not only financial problems for the unemployed youths but also increases the work load in the
offices. Similar is the position in case of admission to educational/professional Engineering institutions. To
give relief to the public, it has been decided that at the time of applying for job or for admission in educational
institutions including technical/professional institutions etc. self attested photo copy of the certificate about the
residence and caste status shall be sufficient and at the time of final interview/selection, original papers

<!-- page 19 -->

1812

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
including castes and Resident certificate issued by the competent authorities may be obtained/examined/
inspected by the concerned departments/institutions and attested copies thereof be kept in record. The fact may
also be cross checked/verified at the time of verification of the antecedents of the applicants before he/she joins
the Government service. Similar practice will be followed for degrees/mark sheets/other certificates of
academic qualifications. Necessary action to amend/revise the application form in this regard shall be taken by
Haryana Public Service Commission/ Haryana Staff Selection Commission/Head of the Departments/
Universities etc. at their own level under intimation to the Government.
These instructions may be brought to the knowledge of all for strict compliance.

Yours faithfully,
Sd/Special Secretary General Administration,
for Chief Secretary to Government Haryana

<!-- page 20 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1813
Annexure IV(A)

Affidavit Of The Parent /Guardian To Be Attested By Executive Magistrate/Oath Commissioner/Notary
Public.

I............................................................father/mother/guardian of Miss/Mr.............................................................
resident of.................................do hereby solemnly state and affirm as under:1.
That I am a Citizen of India.
2.
That neither the deponent nor the child/ward of the deponent have obtained the benefit of ‘Residence in any
other State.
Dated..........................

DEPONENT

VERIFICATION
Verified that the contents of my above affidavit are true and correct to the best of my knowledge and belief and
nothing has been concealed therein.
Dated.........................

DEPONENT

<!-- page 21 -->

1814

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure IV(B)

Haryana Resident Certificate (Residence Certificate To Be Issued By The Deputy Commissioner, Sub
Divisional Officer (Civil), G.A. To D.C.D.R.O. Em And Tehsildar).

Certified that Shri/Shrimati/Kumari ______________________________________Son/ Daughter of Shri
________________________________ Father/Guardian of Miss/ Mr. ______________________ name of child/ward
with full address hold Immovable property at _____________________________ (place and District) in the State of
Haryana for the past _________________ years.
OR
Certify
that
Miss/Mr.
_________________________________________Son/
Daughter
of
Shri
________________________ resident of ____________________
was born in Haryana as per birth certificate (Issued under the instructions of Haryana Govt. Letter No. 22/28/2003-3,
GS-III dated 30.1.2004).
No. ________
Tehsildar/NaibTehsildar
Signature of the Authority (mentioned above) (with seal)
Date :
The validity of Resident Certificate shall be as long as the holder of this certificate maintains his residential address in
Haryana State.

<!-- page 22 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1815
Annexure IV(C)

Residence Certificate To Be Issued By Head Of Department
Certified that Sh. ______________________________ S/o Sh. ___________________________ father of Miss/Mr.
_________________________ is an employee of the __________________ (Name of office)
______________________ of Haryana Government. He is working as _____________________, and is posted at
________________________. He has more than three years service at his credit.

Place:
Dated:

Head of the Department
(with seal)

<!-- page 23 -->

1816

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure IV(D)
Residence Certificate To Be Issued By The Principal/Headmasters Of The Government/Recognized
School/College.

It is certified that Miss/Mr. ……………………………..S/o/D/o Sh. ……………………….. has been a student
of this School/College for a period of ……………………………. Years, from ………………..to ……………….. He
left the school/college on ………………………..

Dated
Signature of Principal/Headmaster
of the School/College (with seal)

<!-- page 24 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1817
Annexure IV(E)

Residence Certificate To Be Issued By The Respective Head Of The Department In The Case Of The
Employees Of Government Of India
Certified that Sh. …………………………….. S/o Sh. ………………………… father of Miss/Mr.
………………………………………….is
an
employee
of
Government
of
India
working
as
…………………………….. He has been posted at Chandigarh/Haryana in connection with the affairs of Haryana
Government for the past three years.

Dated

Head of Department
(with seal)

<!-- page 25 -->

1818

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure IV(F)

Certificate Of Scheduled Caste
Certified that Mr./Miss................................... Son/Daughter of Sh.................................... Village/Ward
No..............................Teh...........................................District
.........................
Haryana
belongs
to
................................Caste. Which has been declared Scheduled Caste in the Constitution (Scheduled Castes) Order
1950.
Caste certificate shall be valid for life.

Dated.....................
Place :
Certificate from no other authority will be accepted.

Tehsildar/NaibTehsildar-cum- Executive
Magistrate/Head of the Department

<!-- page 26 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1819
Annexure-V

Fee Structure of B.Sc. Nursing/Post Basic B.Sc. Nursing/M.Sc. Nursing Courses in Government Colleges of the
State:
Particulars

B.Sc. Nursing

Post Basic B.Sc. Nursing

M.Sc. Nursing/NPCC

Tuition Fee

20000/-

25000/-

30000/-

Security Refundable

1500/-

2000/-

2500/-

Registration Fee

1000/-

1000/-

1000/-

Sports Fee

50/-

50/-

50/-

Youth Welfare Fee

500/-

500/-

500/-

Development Fund

1000/-

1000/-

1000/-

NSS Fund

10/-

10/-

10/-

Youth Red Cross Subscription
Fee

80/-

80/-

80/-

As per actual

As per actual

As per actual

24140/-

29640/-

35140/-

University Charges
Total
Hostel Fee

No room rent only electricity charges of Rs. 9000/- per annum

Fee Structure of BPT/MPT Courses in Government Colleges of the State:Particulars

BPT

MPT

Tuition Fee

20000/-

25000/-

Security Refundable

2500/-

2500/-

Registration Fee

-

1000/-

Sports Fee

50/-

50/-

Youth Welfare Fee

500/-

500/-

Development Fund

1000/-

1000/-

NSS Fund

10/-

10/-

Youth Red Cross Subscription Fee

65/-

80/-

University Charges

As per actual

-

Dr. Radha Krishan Fund

-

100/-

Holiday Home Fee

-

10/-

Total

24125/-

30250/-

<!-- page 27 -->

1820

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

Fee Structure of Paramedical Courses in Govt. Colleges:Particulars

Amount

Tuition Fee & Registration Fee

9000/-

Amalgamated Fund

665/-

University Charges

2670/-

Youth Red Cross Subscription Fee

80/-

Total

12415/-

<!-- page 28 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1821
Annexure- VI

Fee Structure of B.Sc. Nursing/Post Basic B.Sc. Nursing/M.Sc. Nursing and BPT/ MPT Courses in Private
Colleges of the State:
Fee Head
Annual Fee for
Annual Fee for
Annual Fee for
Annual Fee for
B.Sc. & Post Basic
M.Sc. Nursing
BPT Course
MPT Course
B.Sc. Nursing
Tuition Fee
Rs. 60,000/- with
Rs. 75,000/- with
Rs. 60,000 with
Rs. 1,00,000 with
including
annual increase of
annual increase of
annual increase of
annual increase of
Development
5%
5%
5%
5%
Charges
15% NRI seats
USD 15,000/- (for USD 15,000/- (for USD 15,000 (for the USD 30,000 (for the
the entire course)
the entire course)
entire course)
entire course)
Examination
Actual
Actual
Actual
Actual
Charges
University Charges
Actual
Actual
Actual
Actual
Library Fee
Rs. 3000/Rs. 3000/Rs. 3,000/Rs. 3,000/Sports and Medical Rs.2000/Rs.2000/Rs. 2,000/Rs. 2,000/Charges
Internet Charges
Rs.1000/Rs.1000/Rs. 1000/Rs. 1,000/Hostel Fee
Not more than Rs. Not more than Rs. Not more than Rs. Not more than Rs.
60,000/- or actual 60,000/- or actual 60,000/- or actual 60,000/- or actual
(whichever is less)
(whichever is less)
(whichever is less) + (whichever is less) +
No charges for fan No charges for fan Mess Charges on Mess Charges on
and lighting in the and lighting in the actual basis. No actual basis. No
hostel
hostel
charge for fan and charge for fan and
lighting in the hostel lighting in the hostel
Mess Charges
Actual
Actual
Transport fee (if
Actual
Actual
Actual
Actual
availed by the
student)
Equipment and
Rs. 2500/Rs. 2500/Maintenance
Charges

<!-- page 29 -->

1822

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure – VII
List of documents to be brought at the time of reporting to the Institution

The candidates, at the time of document verification must bring the following original certificates/documents/
testimonials along with two sets of duly attested photo copies. Any candidate, who fails to produce any of the required
certificate/document at the time of document verification, shall loose his/her candidature:
1.
Matriculation Certificate/High School Certificate/ICSE/CBSE Class 10th or its equivalent certificate as proof
of date of birth.
2.
Pass Certificate /DMC of qualifying examination i.e. 10+2.
3.
GNM/B.Sc. Nursing/Post Basic B.Sc. Nursing including DMC, Registration Certificates (if applicable).
4.
Certificate of good conduct/character from the Principal of the institution last attended.
5.
Service Certificate from the employer if applicable.
6.
Resident Certificate issued by competent authority of the State Government (if applicable).
7.
Certificate of Bonafide Resident issued by competent authority of the State Government (if applicable).
8.
PPP ID (If applicable).
9.
Caste Certificate issued by competent authority of the State Government (if applicable).
10.
Certificate of Disability issued by Competent Authority.
11.
Certificate of Dependent of Freedom Fighters issued by competent authority of the State Government (if
applicable).
12.
Certificate of ESM issued by competent authority of the State Government (if applicable).
13.
Income and Asset certificate for EWS Category candidates.
14.
Print out of Online Application form.
15.
CET Result Card.
16.
As proof of identification-Aadhar Card/PAN Card/Driving Licence/ Passport/Voter ID.
NRI candidates in addition should bring the following documents:1.
Equivalency Certificate issued by Association of Indian Universities, New Delhi, if applicable.
2.
Conversion Certificate of grading to percentage of marks, if applicable.
3.
Proof of NRI status in form of Passport, OCI/PIO/letter from Ministry of External Affairs/Embassy and
Bank Account Details etc.
Note: - Any Candidate, who fails to produce any of the required certificate/document at the time of document
verification, shall loose his/her claim to admission.

<!-- page 30 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1823
Annexure VIII

Haryana Government
WELFARE OF SCHEDULED CASTES AND BACKWARD CLASSES DEPARTMENT
Notification
The 16th July, 2024
No. 40/13/2024-1SW.--- In exercise of the powers conferred under clause (d) of Section 2 and Sub-section (2)
of Section 5 of the Haryana Backward Classes (Reservation in Services and Admission in Educational Institutions)
Act, 2016 (15 of 2016), and in supersession of the Haryana Government, Welfare of Scheduled Castes and Backward
Classes Department, notification No. 491-SW(1)-2021 dated the 17th November, 2021, the Governor of Haryana
hereby specifies the following criteria for exclusion of persons within the Backward Classes as Creamy Layer as per
Annexure appended hereto.
DESCRIPTION OF CATEGORY
1.
I.

II.

2.
CONSTITUTIONAL POSTS

TO WHOM RULE OF EXCLUSION SHALL
APPLY

3.
Son(s) and daughter(s) of
(a) President of India;
(b) Vice President of India;
(c) Judges of the Supreme Court and of the High Court;
(d) Chairman and Members of UPSC and of the State Public Service
Commission;
Chief Election Commissioner; Comptroller & Auditor General of
India;
(e) Persons holding Constitutional positions of like nature.
Son(s) and daughter(s) of
SERVICE CATEGORY
A. Group A / Class I Officers (a) parents, both of whom are Class I officers;
of the All India, Central (b) Parents, either of whom is a Class-I officer;
and State Services (Direct (c) Parents, both of whom are Class-I officers, but one of them dies
recruits)
or suffers permanent incapacitation;
(d) Parents, either of whom is a Class-I officer and such parent dies
or suffers permanent incapacitation and before such death or such
incapacitation has had the benefit of employment in any
International Organization like U.N, I.M.F, World Bank, etc.
for a period of not less than 5 years;
(e) Parents, both of whom are class I officers die or suffer permanent
incapacitation and before such death or such incapacitation of the
both, either of them has had the benefit of employment in any
International Organization like U.N, I.M.F, World Bank, etc. for
a period of not less than 5 years;
Provided that the rule of exclusion shall not apply in the following
cases:(a) Sons and daughters of parents either of whom or both of whom
are Class-I officers and such parent(s) dies/die or suffer
permanent incapacitation.
(b) A lady belonging to BC category has got married to a Class-I
officer, and may herself like to apply for a job.
Son(s) and daughter(s) of
B. Group B/Class II officers
of the Central and State
(a) Parents both of whom are Class II officers;
Services (Direct
(b) Parents of whom only the husband is a Class II officer and he gets
Recruitment)
into Class I at the age of 40 or earlier;
(c) Parents, both of whom are Class II officers and one of them dies
or suffers permanent incapacitation and either one of them has had
the benefit of employment in any International Organization like

<!-- page 31 -->

1824

II.

III.

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
U.N, I.M.F, World Bank, etc. for a period of not less than 5 years
before such death or permanent incapacitation;
(d) Parents of whom the husband is a Class I officer (Direct Recruit or
pre-forty promoted) and the wife is a Class II officer and the wife
dies; or suffers permanent incapacitation; and
(e) Parents, of whom the wife is a Class I officer (Direct Recruit or
pre-forty promoted) and the husband is a Class II officer and the
husband dies or suffers permanent incapacitation;
Provided that the rule of exclusion shall not apply in the following
cases:- Son(s) and daughter(s) of
(a) Parents both of whom are Class II officers and one of them dies or
suffer permanent incapacitation.
(b) Parents, both of whom are Class II officers and both of them die
or suffer permanent incapacitation, even though either of them has
had the benefit of employment in any International Organization
like U.N, I.M.F, World Bank, etc. for a period of not less than 5
years before their death or permanent incapacitation.
The criteria enumerated in A and B above in this Category shall apply
C. Employees in Public
mutatis mutandi to officers holding equivalent or comparable posts in
Sector Undertaking etc.
PSUs, Banks, Insurance Organizations, Universities, etc. and also to
equivalent or comparable posts and positions under private
employment pending the evaluation of the posts on equivalent or
comparable basis in these institutions, the criteria specified in
Category VI below shall apply to the officers in these institutions
Son(s) an daughter(s)
ARMED FORCES
INCLUDING PARA
Parents either or both of whom is or are in the rank of Colonel and
MILITARY FORCES:
above in the Army and to equivalent posts in the Navy and the Air
(Persons holding civil posts are
Force and the Para Military Forces: Provided that:not included)
(i) if the wife of an Armed Forces Officer is herself in the Armed
Forces (i.e., the category under consideration) the rule of
exclusion will apply only when she herself has reached the rank
of Colonel;
(ii) the service ranks below Colonel of husband and wife shall not be
clubbed together;
(iii) If the wife of an officer in the Armed Forces is in civil
employment, this shall not be taken into account for applying the
rule of exclusion unless she falls in the service category under
item No. II in which case the criteria and conditions enumerated
therein will apply to her independently.
PROFESSIONAL
CLASS Criteria specified against category VI shall apply.
AND THOSE ENGAGED IN
TRADE AND INDUSTRY
(I) Persons engaged in profession
as a Doctor, Lawyer,
Chartered Accountant,
Income Tax Consultants,
Financial or Management
Consultants, Dental
Surgeon, Engineer,
Architects, Computer
Specialists, Film Artists and
other Film Professionals,
Author, Play Writer, Sports
person, Sports Professionals,
Media Professionals or any
other vocations of like
status.
Criteria specified against category VI shall apply. Explanation:

<!-- page 32 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
(II) Persons engaged in trade,
business and industry.

IV.

PROPERTY OWNERS
A. Agricultural holdings

B. Plantations
(i) Coffee, tea, rubber, etc.
(ii) Mango, citrus, apple
plantations etc.
C. Vacant land and/or
buildings in urban areas or
urban agglomorations

VI.

INCOME / WEALTH TEST

Explanation: Wherever the
expression “permanent
incapacitation” occurs in this
Schedule, it shall mean
incapacitation which results in
putting an officer out of service.

Dated Chandigarh,
The

1825

(i)

Where the husband is in some profession and the wife is in a
Class II or lower grade employment, the income/wealth test shall
apply only on the basis of the husband’s income.
(ii) If the wife is in any profession and the husband is in employment
in a Class II or lower rank post, then the income/wealth criterion
shall apply only on the basis of the wife’s income and the
husband’s income shall not be clubbed with it.
Son(s) and daughter(s) of persons belonging to a family (father,
mother and minor children) which owns:(a) only irrigated land which is equal to or more than 85% of the
statutory area; or
(b) both irrigated and unirrigated land, as follows:(i) The rule of exclusion shall apply where the pre-condition exist
that the irrigated area (having been brought to a single type
under a common denominator) 40% or more of the statutory
ceiling limit for irrigated land (this being calculated by
excluding the unirrigated portion). If this precondition of not
less than 40% exists, then only the area of unirrigated land will
be taken into account. This shall be done by converting the
unirrigated land on the basis of conversion formula existing,
into the irrigated type. The irrigated area so computed from
unirrigated land shall be added to the actual area of irrigated
land and if after such clubbing together the total area in terms
of irrigated land is 80% or more of the statutory ceiling limit
for irrigated land, then the rule of exclusion shall apply and
disentitlement will occur;
(ii) The rule of exclusion shall not apply if the land holding of a
family is exclusively unirrigated.
Criteria of income/wealth specified in Category VI below shall apply.
Deemed as agricultural holding and hence criteria at A above under
this category shall apply.
Criteria specified in Category VI below will apply.
Explanation: Building may be used for residential, industrial or
commercial purpose and the like two or more such purposes.
Son(s) and daughter(s) of
(a) Persons having gross annual income of Rs.8 lakh or above or
possessing wealth above the exemption limit as prescribed in the
Wealth Tax Act, 1957 (Central Act 27 of 1957) for a period of three
consecutive years;
(b) Persons in categories I, II, III and V A who are not disentitled to
the benefit of reservation but have income from other sources of
wealth which shall bring them within the income/wealth criteria
mentioned in (a) above.
Explanation:
(i) Income from salaries or agricultural land shall not be clubbed.
(ii) The income criteria in terms of rupee shall be modified taking
into account the change in its value every three years. If the
situation, however, so demands, the interregnum may be less.

G. ANUPAMA,
Additional Chief Secretary to Government Haryana,
Social Justice, Empowerment, Welfare of Scheduled Castes and
Backward Classes and Antyodaya (SEWA) Department.

<!-- page 33 -->

1826

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)
Annexure-IX
(FOR DEPENDENTS OF FREEDOM FIGHTERS)
UNDERTAKING

I ____________ S/D of ____________________ R/o ____________________________ Teh.________________
Distt. hereby undertake as under:
That Sh./Smt. ______________________ S/D of Sh. _______________ R/o ______________________
Tehsil _______________ Distt. ______________ is /was Freedom Fighter and is/was my grandfather/ grandmother
(Paternal/Maternal).
Date:

Place:

Sign of applicant

It is verified that all the above contents are true to the best of my knowledge.

Sign of Father/Mother of applicant
( Who is/was dependent of Freedom Fighter)

Sign of applicant

<!-- page 34 -->

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

1827
Annexure-X

Government of Haryana
General Administration Department
General Services -III Branch
No. 22/10/2013-1GSIII
Dated Chandigarh, the 10th August, 2017
To
1.
2.
3.
4.
5.
6.
7.
Subject:

All the Additional Chief Secretaries/Administrative Secretaries to Government Haryana.
All Heads of Departments in the State of Haryana.
The Commissioners, Ambala/Hisar/Rohtak/Gurugram Division.
All the CAs/MDs of all Boards/Corporation/Public Sector Undertakings in Haryana
The Registrar General of Punjab & Haryana High Court, Chandigarh
All the Deputy Commissioners in the State of Haryana.
The Registrars of all the Universities in the State of Haryana.

Grant of reservation in admission in Government/Government Aided educational technical/
professional Institutions etc.

Sir/madam
I am directed to invite your kind attention to the Government instructions issued vide letter of even
number dated 15.07.2014 on the subject noted above.
It is intimated that Government of India, Ministry of Defence Department of Ex-Servicemen Welfare D(Res-II) has
intimated that vide letter number 6(1)/2017-D (Res-II) dated 19.05.2017, the following priorities for reservations of
preferences to the wards of Armed Forces personnel should be applied by States/UTs/Central/State Universities/
Autonomous Institutions for admission in medical/professional/non-professional courses:Priority-I:
Widows/Wards of Defence personnel killed in action.
Priority-II: Wards of disabled in action and boarded out from service.
Priority-III:
Widows/Wards of Defence Personnel who died while in with death attributable to military service.
Priority-IV:
Wards of disabled in service and boarded out with disability attributable to military service.
Priority V:
Wards of Ex-Servicemen and serving personnel who are in receipt of Gallantry Awards:
(i)
ParamVir Chakra
(ii)
Ashok Chakra
(iii)
SarvottamYaudhSeva Medal
(iv)
MahaVir Chakra
(v)
Kirti Chakra
(vi)
UttamYudhSeva Medal
(vii)
Vir Chakra
(viii)
Shaurya Chakra
(ix)
YudhSeva Medal
(x)
Sena, NauSena, VayuSena Medal
(xi)
Mention-in Despatches
Priority-VI:
Wards of Ex-servicemen
Priority-VII:
Wards of Serving Personnel.

<!-- page 35 -->

1828

HARYANA GOVT. GAZ. (EXTRA.), AUG. 8, 2025 (SRVN. 17, 1947 SAKA)

2.
The State Government has decided to adopt the above provision made by Govt. of India in their letter dated
19.05.2017 with the following amendements.
1.1 In Priority V, the words “and serving personnel” are removed.
1.2 The priority VII is altogether deleted.
Therefore, Para 5 of General Administration Department instructions even number dated 15.07.2014 is
amended to this extent.
The above instructions may please be brought to the notice of all concerned for strict compliance.

Yours faithfully
Sd/Superintendent, GS-III Branch
for Chief Secretary to Government Haryana
INTERNAL DISTRIBUTION
In charge NIC for hosting the above instructions on the State Government website.

12026—C.S.—H.G.P., Pkl.
