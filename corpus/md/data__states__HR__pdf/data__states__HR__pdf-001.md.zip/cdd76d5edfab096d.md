---
doc_id: "cdd76d5edfab096d"
source_url: "https://cdnbbsr.s3waas.gov.in/s35352696a9ca3397beb79f116f3a33991/uploads/2026/10/202610211313320927.pdf"
ministry: "Electronics and Information Technology Department, Haryana"
title: "Notification Dated -12.05.2000"
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f3622e1301b1bb88"
---

<!-- page 1 -->

~\7y- :
cocgimik «
Schedule ‘A’
6, HARYANA GOVERNMENT.
IMENT OF ELECTRONICS & INFORMATION TECHNOLOGY
NOTIFICATION :

Dated Chandigarh the — May ,2000
No:49/32/2000/IB(5) The Governor of Haryana is pleased to accord his approval for
the constitution of the Information Technology Initiative Fund for the e-Governance
(0 promote the Information Technology in the Haryana State,

The Fund shall have an initial Corpus of Rs. [0 Crore and shall be established
with the contribution from the profit making State PSUS,Co-operative institutions and
other public sector organizations.

Schedule B
|. Short title and commencement
; l. This fund may be called the Information Technology Initiative Fund fir e-
Governance.
2, It shall come into force on the date of its publication in the official Gazette,
3, Definitions :In this Fund, unless the context otherwise requires-
a) “Body” means the Governing Body constituted in the paragraph 5.
b) “Committee” means the executive Committee constituted in the
paragraph 9.
¢) “Fund” means the Information Technology Initiative Fund for e-
Governance.
2.Objects of the Fund:- The objects of the fund shall be
i i) ‘The fund shall be utilized for developing replicable and reusable models of
e-Governance in various State Government Offices ,Boards and
Corporations _ a os
ii) IP innovations in administration re-engineering
iii) TT supported resource optimization
iv) To develop Decision Support System, MIS, Intranet and other applicable
> enabling technologies in State Government offices , Boards and”
Corporations. _ — ऋचा
\) To impart special training, awareness and capacity building in the field
of IT various State Government Offices ,Boards and Corporations,
vi) Any other purpose which seeks to achieve the above said purposes.
.
|
|

<!-- page 2 -->

| Assets of the Fund पु
ie. :
initial capital of Rs.iG Crore sitll be piovided by the contribution from profit
\ pmaking Public sector undertakings , Co-operative institutions and other Public sector
organizations. हे
he fund shall aceept contributions from statutory bodies created under the Acis of
arliament or of the State Legislature, the International organizations and Private
bodies .
4.Vesting of the assets of the fund,
‘The Assets of the fund shall vest with the Secretariat for Information
१ SS ea
Technology.
rs '
5. Constitution of the Governing Body
The Governing body would comprise the following members.
|.) Principal Secretary to the Chief Minister Chairman
2.) Secretary, Finance Member
3.) Secretary, Planning Member
4.) Secretary, Co-operation Member
5.) Seeretary, Industries Member
6.) Secretary, Agriculture Member
7.) Secretary, Town & Country Planning Member
है... Seeretary, Education Member
9.) Secretary, Administrative Reforms Member
I0.) Secretary Electronics and Information Technology
Department. Member
Secretary
Any other member which Governing body decides to co-opts. .
| of the Governing Body: The Body shall meet at least once ina quarter to
ide policy matters or issues relating to the fund on which its decisions are sought :
the Executive Committee,
7.Quorum of the meeting of the Governing Body and decisions of the Body है
) The quorum for a meeting of the body shall be two- third of the body
af
हे if 9
fe

<!-- page 3 -->

- YY
ajy= है

2) The Governing body shall decide all matters by consensus provided that in
case of difference of opinion ,the resolution shall be put to vote and decided

न्‍ ? by majority of votes of the members present and voting and in case of
2 के equality of votes , the chairperson shall havea second or a casting vote.
| &.Conduet of Business of the Body.

I) The body may function not ithstanding any vacancy in its constitution
provided however ,that at no time the number of vacancies shall be such that
the total number of members are less than the quorum required fora meeting
of the body.

2) Subject to the provisions herein contained .the council may, with the
previous approval of the Haryana Government ,frame and vary from time to
time was it thinks fit sbye-laws for the conduct of its business. |

9.Executive committee: Day -to -day working of the fund shall be managed by an ,
Executive Committee comprise the following members :- : *t

') The Secretary to Government of} laryana Department of !
Electronies and Information Technology Chairman

2) Managing Director HSIDC Member |

3) Managing Director HFC Member

4) Managing Director , Hafed Member

3) CAMUDA Member

6) CA.HSAMB Member

7) Mb Warehousing Corporation Member |

8) Director, Industries Member

9) Managing Director. lartron Member

Secretary

The Executive Committee shall have the authority to call Upon experts to assist it in
its deliberations,
T0.Quorum

The quorum fora mecting of the Executive Committee shall be four of the total
है of members of the Committee of which at least one should be the Chairman,
:
| ?

<!-- page 4 -->

छः
E of the Executive Committee: The Body shall meet as often as necessary
Uinét Jess than four times in a year. '
2. Duration of membership: A member of the governing body हैं, Executive
Committee shall cease to be a member if he dies or resigns his memBer ship or is
moved/replaced by the Government :
73. Administrative Expenses:-Administrative expenses incurred by the body or
Committee such as salary allowances and travelling Allowances and daily Allowances
ofthe members can be legitimate charges on the funds of the fund.
4.Appointment of Staff:-
a) The Executive Committee may appoint such staff as they may consider
necessary for discharge of their functions. है |
h) The term and conditions of service of the staff may be
determined by bye-laws made by the Body.
pee
!S. The Treasurer of Fund Subject to any general or special directions given by the
Haryana Government management and administration of the fund shall be vested in
the Esceutive Committee of the Governing Bedy headed by the Seeretary ,
Electronics and Information Technology.
I6.Framing of Bye -laws:- The Governing Body may from time to time ,with
previous approval of the Haryana Government .make Bye-laws.
|) for regulation, management ,appointment of officers and their terms and
conditions and for any other purpose connected with the executiof and
management of objects of the Fund and f
2) forthe conduct of business of the Governing body. है
ली
7. Investment,
}) The Governing body shall deeide on the overall policy of 8. of the
न fund. The Committee shall invest the assets of the fund in a or more of
7 the mode of investments for the time being authorized Taw {gr the
investment of the trust money as the committee may think proper.
2) The Committee may invest moneys of the Fund not required immediately on
short term basis in fixed deposits/Certificates or such other selieme decided
hy the Governing body

<!-- page 5 -->

I8.Delegation of Powers.

') The Body may delegate any of its power excluding the pawerto decide
policy matters and the power to frame bye-laws to the committee,

3) The Commitee may delegate to one of its members ora sub-committee or
subcommittee created for the purpose of its powers as may be which in
opinion of the Committee care required to be exercised merely for ministerial

* acts involving no discretion or are considered necessary for common usage. |
I9. Contracts:

All comtracts and other assurance shall be executed in the name of the
Governing body and signed on their behalf by the Managing Director Hartron sin his
capacity as the member of the body and as member of the Committee duly authorized
By ine Gov erning body.

20... Power and Function of the Member Seeretary.
It shall be the duty of the \ lember Seeretary
Lo be the custodian of all r vvords of the Gov etning body and the Executive
Committee.
=) To conduct the official correspondence on behalf of the Body and the
Commitiee. ,
3) To issue all notices for convening the mectings of the Body and commitice.
4) To keep minutes of all meetings of the Body and the Committee and of such
other bodies and convening those Meetings.
5) To manage the, properties or the money under the furid ,to manage accounts
and execute all contracts on behalf of the Body.

<!-- page 6 -->

| +
6) To prepare the budget relating to the administrative expenses of the body and
committee such as expenditure on TA/DA of the members ,which shall be a
legitimate charge on the fund.
7) To exercise all other powers and execute such functions as may be assigned
to him by the Body or Committee.
2, Allocation of Fund:-
The Commitice shall determine the proportion of the total moncys of Fund
“which shall be applied for the purpose of specific scheme in a particular year.
Minimum administrative infrastructure shall be provided for operation of the fund |
after obtaining approval of the Goveming Body wherever necessary.
422. Withdrawal of Funds.
|. Withdrawal of funds from the accounts of the body shall be regulated ina

manner to be determined by the Committee.

2 Such withdrawals shall be made by cheques or requisition (as the case may be)
signed jointly by Member-Seeretary of Executive Committee and one more
member authorized in this behalf by the Executive Committee.

23, Remuneration to Members and officers
TAIDA. by the saembers shall be drawn from their respective departments.
i . e CG * . 4 .

Non —Official niembers of the Governing Body and Committee shall be entitled

to draw such remuneration and travelling and other allowances as may be '

specified by the Governing Body in bye-laws made by it. |
24. Audit of Accounts.

. ]. Accounts of all moneys and properties and of income and expenditure of the
Fund shall be maintained by the Managing Director, Hartron in the capacity
of Member Secretary and audited by the Chartered Accountant duly
appointed who shall certify that the expenditure from the fund has been
incurred in accordance with provisions of this fund.

2. A. statement of the annual accounts of the fund shall be approved by the
Governing body and after the same has been audited and certified by the
Chartered Accotumant and approved by the Governing body® shall be
subinitted by the MD Hartron in the capacity of Member Secretary of the
Fyccutive Committes to the Government of Harvanaievery year,

5.

<!-- page 7 -->

atl ( 3
| 5
. Annual report.
\report on the Working of the TT Initiative Fund for every year shall he
prepared in the Month of June by the Managing Director .Hartron in the
capacity of the Member Secretary of Executive Committee and after the
approval of the Governing Body .presented to the Government of Haryana.
Dated 0-05-2000 P.K. Chaudhery
Commissioner & Secretary to Govt. Haryana i
| Electronics & Information Technology Department. |
|
' iyist. No. No.49/32/2000- HBI-(3) Dated Chandigarh, the.fUMay.2000.
A copy is forwarded to the Accountant General (Haryana) for Information
pleass .
’
| f
ws . a a
| वॉक (3-५६ Pith
Superintendent Industires-I,
for Commissioner & Secretary to Govt. Haryana
Fleejronies & Information Technology Department.
Endst.No, No.49/32/2000-TIBI-(5 Dated Chandigarh, the, RMay,2000
\ A copy is forwarded to the Controller, Printing & Stauonary, U.T. Press
eg Chandigarh Administration with the request that the above notification may pleat be
५ published in Haryana Government extra ordinary gazette immediately and [50 copies |
Mn oud thercor be supplied to this department, .
LE नह
97 A here sash pou”
के Be कप लत है Superintendent Industires-l,
_ Chal east h et for Commissioner & Secretary to Govt. Haryana
4 Electronics & Information Technology Department.
Endst.No, No.49/32/2000-LIBI-(5) Dated Chandigarh, the,!*May,2000
,
i
A Copy is forwarded to the following for necessary action please ५;
॥ Commissioner & Secretary to िकलाए (00७. Electronics & Information
lechnology Department.
2 Managing Director, Haryana Stats Industrial Development Corporation,
Lad
3 Munaging Director Haryana Urban Development Authority
.
| ‘

<!-- page 8 -->

Managing Director ,Haryana State Cooperative Supply & Marketing
Federation Lid.
| Managing Director Haryana State Agriculture Marketing Board
6. Managing Director, Haryana Warehousing Corporation
7. Managing Director Haryana Financial Corporation
8, Managing Director , Haryana State Electronics Development
Corporation Ltd.
9, Managing Director Industrial Assistance Group
0, Managing Director, Harvana Dairy Development Cooperative :
lederation Ltd,
ul Managing Director, Harvana Tourism Development Corporation Ltd.
I2. Managing Director Haryana State Cooperative Apex Bank Lid
=f Asvnd  yeethe pense | a
Superintendent Industires-I,
for Commissioner & Seeretary to Govt: | larvana
Electronics & Information Technology Department.
\ Copy is forwarded to Financial Commissioner & Secretary to Government
Haryana for information and hecessary action with reference to their, U.O.No:
43/2000-SF.D IM /7343 Dated -05-2000 / ge 2 {
- 4//. / ४४.
Superintendent Industries-] ger" ~
for Commissioner & Secretary to Govt] laryana
Electronics & Information Technology Department
aL
atu
a ae. 7 ere 6; s+
The Financial Commissioner & Secretary to Government, | laryana .Finanee
Department .
UVLO Nost9 322000 TBI(5 $ Dated The }2.May,2000
हे
