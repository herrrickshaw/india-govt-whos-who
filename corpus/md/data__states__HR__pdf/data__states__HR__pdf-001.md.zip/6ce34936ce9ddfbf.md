---
doc_id: "6ce34936ce9ddfbf"
source_url: "https://csharyana.gov.in/wp-content/uploads/2026/10/GMRL.pdf"
ministry: "Chief Secretary Office, Haryana"
title: "Posting/transfer of IAS Officers."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d2914bfc813db8bb"
---

<!-- page 1 -->

ORDER

The Governor of Haryana is pleased to make posting/transfer of the following
IAS officers with immediate effect.Sr.
No.
1.

Posted/Transferred as

Name and Designation

Remarks

Director, Relieving Shri
Shri Ajay Kumar, IAS (HY:2013), Managing
Deputy Principal Secretary-ll to Gurugram Metro Rail Mukul Kumar,
Chief Minister, Haryana Limited (GMRL), in IAS (HY:2011) of
(DPSCM-ll), Chief Administrator, addition to his present the said charge.
Haryana Shehri Vikas duties.

Pradhikaran, Panchkula and
Managing Director, Haryana

Mass

Rapid

Transport

Corporation Limited.
Dated Chandigarh
the 30th October, 2026

ANURAG RASTOGI
Chief Secretary to Government, Haryana

No. 1/150/2026-1Sll

Dated Chandigarh, the 30th October,2026

A copy, each, is fonryarded to the officers concerend for information and
necessary action.

Deputy Secretary to Government, Haryana,
Personnel DeRartment*
No. 1/150/2026-1Sll

Dated Chandigarh, the 30th Octob er, 2026

A copy is forwarded to the Director (MRTS-I), Government of lndia, Ministry of
Housing & Urban Affairs, Department of Capital Development, Sankalp Bhawan, New
Delhi, with referece to his letter No. 1401113312026-MRTS-1, dated 26.10.2026 for
information and necessary action.

Deputy Secretary to
rnment, Haryana,
Personnel Department*

No. 1/150/2026-1Sll

Dated Chandigarh, the 30th Octob er, 2026

A copy, each, is forwarded for information and action, where necessary to the
following:Secretary to Governor, Haryana.
All the Additional Chief Secretaries, Principal Secretaries and Commissioner &
Secretaries to Government, Haryana.
Director General, Haryana lnstitute of Public Administration, HIPA Complex,
Sector 18, Gurugram.
4.
Resident Commissioner, Government of Haryana, Haryana Bhawan, New Delhi.
All concerned Heads of Departments/MDs of Boards/Corporations.
5.
Commissioners, Ambala/Faridabad/Gurugram/Hisar/Karnal/Rohtak Divisions.
6.
7.
Chief Electoral Officer, Haryana.
Director, lnformation, Public Relations & Languages, Haryana.
8.
9.
Secretary to Government, Haryana, Secretariat Establishment Department.
All the Deputy Commissioners in Haryana.
10.
11.
PrincipalAccountant General (A & E) and (Audit), Haryana, Chandigarh.
12.
Secretary, Lokayukta, Haryana.
13.
Secretary, Haryana Public Service Commission.
14.
Secretary, Haryana Vidhan Sabha, Chandigarh.
15.
Secretary, House Allotment Committee (U.T.), Chandigarh.

1.
2.

<!-- page 2 -->

-L16.
17.

Deputy Controller (Finance & Accounts) Rents, U.T., Chandigarh
SlO, NIC, Haryana Civil Secretariat, Chandigarh.

Deputy Secretaryfd-i3overnment, Haryana,
Personnel Department.;"
No. 1/150/2026-1Sll

Dated Chandigarh, the 30th Octob er, 2026

A copy, each, is fonryarded for information and action where necessary to the
following:Establishment Officer and Addl. Secretary to Government of lndia, Ministry of
Personnel, PG & Pensions Department of Personnel and Training, New Delhi.
Addl. Secretary to Government of lndia (S&V), Ministry of Personnel, P.G. &
Pensions, Department of Personnel & Training, Services Division (AlS-lll
Section), New Delhi.
Deputy Secretary to Government of lndia, Department of Personnel &
Administrative Reforms, New Delhi.
Documentation Officer, National lnstitute
Educational Planning
Administration, 17-8, Sri Aurbindo Marg, New Delhi.
Research Officer, Career Management Division, Department of Personnel and
Training, R.No. 215, North Block, New Delhi.
6.
Establishment Officer, C.M. Division, Department of Personnel and Training,
R.No. 215, North Block, New Delhi.

1.
2.

3.
4.
5.

of

Deputy Secretary to Government, Haryana,
Personnel Department.J..

No. 1/150/2026-1Sll

Dated Chandigarh, the 30th October,2026

A copy, each, is fonvarded to the Chief Principal Secretary/ Deputy Principal
Secretary/Deputy Principal Secretary-ll/OSD(SG)/ OSD(VK)/ OSD (RS)/ OSD (NPM)/
OSD(BBB)/ OSD (RN)/ OSD (VS)/ Special Senior Secretaries/ Senior Secretaries/
Secretaries/ Private Secretaries to Chief Minister/ Ministers/ Speaker for the
information of Chief Minister/ Ministers/ Speaker.
Deputy Secretary to Government, Haryana,
Personnel Departmen,

\

INTERNAL DISTRIBUTION
1. Secy./CS.
2. Supdt.,Services-l,lll,lV,V & PAR Cell/HR l, ll, & lll Br.
(GlS).
3. Sr. A.O., AIS
4. Supdt., Training /Accounts/ Estt.-1, ll & lll Br.
5. RA at RA's Residence.
6. Secy./SPS.
7 . llc, Computer Section.
8. Lib., Haryana Civil Secretariat.
9. Liaison Officer, Telephones 10. 25ll, 35ll,45ll, 55ll, 65ll & 75ll.
