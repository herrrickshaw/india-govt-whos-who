---
doc_id: "cdb094a6a48afdae"
source_url: "https://dhbvn.org.in/staticContent/employeearea/Office_Orders/Gazetted_Section/2026/496_25.08.2026_AE.pdf"
ministry: "Dakshin Haryana Bijli Vitran Nigam (DHBVN), Haryana"
title: "Office Order"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "17cdc863c6744e3d"
---

<!-- page 1 -->

DAKSHIN HARYANA BIJLI VITRAN NIGAM LIMITED
: L A Power Distribution & Retail Supply Utility, Govt. of Haryana
Due AN ISO 9004:2008 Compliant Utility, CIN: -U99999HR999SGC03465
CoE Registered Office: Vidyut Sadan, Vidyut Nagar, Hisar-25005 (Haryana)
: Office of the Superintending Engineer/Administration, DHBVNL, Hisar
www.dhbvn.org.in Email — seadmn@dhbvn.org.in, supdts{@dhbvn.org.in
Office Order No496/SE/Admn. Dated: 25/08/2026
Current Duty Charge (CDC) of the post of Assistant Engineer assigned to the ~
following JE/JE-I is hereby withdrawn with immediate effect:-
Sr. | Name & Designation Present Posting Order No. & date vide
No. which CDC was assigned
4. Ram Singh, JE-I CDC SDO/OP  S/Division,| No. 99/SE/Admn. dated
_| (HRMS ID : 9K3C4C) DHBVNL, Badhra _ 20.02.209
2. Shanker Lal, JE-I CDC SDO/OP  Si/Division, | No. 99/SE/Admn. dated
HRMS ID: 7R8053 DHBVNL, Kharia 20.02.209
Harsh Gupta, JE-| CDC SDO/OP S/Division No. | No. 99/SE/Admn. dated
HRMS ID: AD4D0) Ill, DHBVNL, NIT Faridabad _| 20.02.20i9
Rajinder Kumar, JE-I CDC SDO/OP  S/Division, | No. 99/SE/Admn. dated
HRMS ID: EQ0354' DHBVNL, Bawani Khera 20.02.2049
| | Narayan Parkash, JE-I CDC SDO/OP  S/Division, | No. 427/SE/Admn. dated
HRMS ID: 3TADFA\ DHBVNL, Dhigawan Jattan 05.08.2079
Shameem Ahmed, JE CDC SDO/OP Sub Division, | No. 99/SE/Admn. dated
(HRMS ID: 8FF83F) DHBVNL, Punhana 20.02.209
(Temporarily posted as CDC.
SDO/OP S/Division,
. DHBVNL, Khol.
Ashok Kumar, JE CDC SDO/OP  SiDivision, |No. 99/SE/Admn. dated
HRMS ID: 4F4A2C) DHBVNL, Julana 20.02.209
le | Ghanshyam Dass, JE-|_ [CDC SDO/OP  S/Division, |No. 99/SE/Admn. dated
HRMS ID: CG2355 DHBVNL, Firozpur Jhirka 20.02.209
| Parikshit Khokher, JE CDC SDO/OP  S/Division, | No. 424/SE/Admn. dated
HRMS ID: EAC035) DHBVNL, Berli (Rewari: 05.08.209
2. Consequent upon the above, all the above named Officials are hereby placed at
the disposal of SE/HR, DHBVNL, Hisar for further posting as JE-/JE.
This carries the approval of Managing Director, DHBVNL, Hisar.
seman Mn
DHBVNL, Hisar
Endst. No.Ch- }4 /GE-425/Vol-XVII (C) Dated: 26.08.2026
A copy of the above is forwarded to the following for information and further
necessary action please:-
4. DGP-cum-Director (Vigilance), HPUs, Panchkula.
2. All CEs/SEs/XENs in DHBVNL.
3. Chief Financial Officer, DHBVNL, Hisar.
4. SE/HR, DHBVNL, Hisar. It is requested to give further posting to the above
named officials.
5. All Chief Accounts Officers/Financial Advisors in DHBVNL.
6. Company Secretary, DHBVNL, Hisar.
ae
£70

<!-- page 2 -->

7. Chief Communication Officer, DHBVNL, Hisar.
8. All Under Secretaries in DHBVNL.
9. Sr. AO/Pay & Accounts, DHBVNL, Hisar.
0. Superintendent (Services-Il)(APARS/ACRs Cell), DHBVNL, Hisar.
4. All Sr. Medical Officers/Medical Officers in DHBVNL.
2. All Sectional Heads at Vidyut Sadan, Hisar.
4 43. All concerned officials.
Unde विकार ननर
for SE/Admn., DHBVNL, Hisar
Copy to:
4. SPS to Managing Director, DHBVNL, Hisar. .
2. SPS to Director (Operations)/(Projects)/(Finance), DHBVNL, Hisar.
3. PA to Chief Engineer/HR & Admn., DHBVNL, Hisar.
4. Personal files of the officials concerned.
