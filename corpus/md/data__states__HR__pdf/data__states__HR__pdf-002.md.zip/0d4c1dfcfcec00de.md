---
doc_id: "0d4c1dfcfcec00de"
source_url: "https://csharyana.gov.in/WriteReadData/Transfers-and-Promotions/Services-II/16194.pdf"
ministry: "Chief Secretary Office, Haryana"
title: "Posting/transfer of IAS/HCS Officers."
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dd12ad810220f285"
---

<!-- page 1 -->

ORDER

The Governor of Haryana is pleased to make posting/transfer of the following
IAS/HCS officers with immediate effect:Name and Designation

Sr.
No.

(Shri/Smt./Ms.)

1.

Aniruddh Yadav, IAS

Posted/Transferred as

Remarks

Additional Managing Relieving Shri Sonu

(HY:2023), Sub Divisional Director, HSIIDC and Bhatt, IAS (HY:2021) ot
Officer (Civil), Narnaul and CEO, Global City Project, the said charge.
Deputy CEO and Deputy Gurugram.

Managing Director,
Haryana Multi Modal
Logistic Hub Project
Limited.
2.

Aditi Singhania, IAS Sub Divisional Officer Vice Shri
Paras
(HY:2029, A.C.(U.T.), (Civil) Ellenabad.
Bhagoria, HCS (2023).
Gurugram.

3.

4.
5.

Rahul Kanwaria, IAS Sub Divisional Officer Vice Shri Gurvinder

(HY:2024),
A.C.(U.T.),Ambala.

(Civil), Pehowa.

Ruhani, IAS (HY.2024),

Sub Divisional Officer, Vice Shri

A.C.(U.T.), Rewari.

(Civil), Firozpur Jhirka.

Suman Yadav, IAS
(HY:202Q, A.C.(U.T.),

Singh, HCS (2023)
Laxmi

Narayan, HCS (2019)
Sub Divisional Officer Vice Shri Ramit Yadav,
(Civil), Uchana Kalan.
HCS (2020)

Yamunanagar.

L

6.

Yogesh Dilhor, IAS Sub Divisional Officer Vice Shri Ved Prakash,
(HY:2024), A.C.(U.T.),

(Civil), Dabwali.

HCS (2016)

Sonepat.
7.

Vijender Hooda, HCS District
(2013), CEO, Zila Parishad,

Charkhi Dadri and CEO,
DRDA, Charkhi Dadri.
8.

Municipal Relieving Shri Harbir
Commissioner, Charkhi Singh, HCS (2020) of
Dadri, in addition to his the said charge.
present duties.

Ved Prakash, HCS (2016), Additional Commissioner,

Sub Divisional Officer Municipal Corporation,
(Civil), Dabwali.

9.

Against a vacant post.

Hisar.

Laxmi Narayan, HCS Joint Director (Admn.), Against a vacant post.
(2019), Sub Divisional Shaheed Hasan Khan
Officer, (Civil), Firozpur Mewati Government
Jhirka.

Medical College, Nalhar
(Nuh).

10.

Ramit Yadav, HCS (2020),
Divisional Officer
(Civil), Uchana Kalan.

Sub

Joint Director, Haryana

lnstitute of

Against a vacant post.

Public

Administration (HIPA),
Gurugram.

11.

Gurvinder Singh, HCS

(2023), Sub Divisional
Officer (Civil), Pehowa.

Sub" ' Divisional Officer Relieving Shri Aniruddh

(Civil), Narnaul.

Yadav, IAS (HY:2023)
of the said charge.

<!-- page 2 -->

-L12.

Paras Bhagoria, HCS Joint Commissioner,
(2023), Sub Divisional Municipal Corporation,

Officer (Civil) Ellenabad.

Against a vacant post.

Karnal.

ANURAG RASTOGI
Chief Secretary to Government, Haryana

Dated Chandigarh
the 2nd September,2026

Dated Chandigarh, the 2nd September,2026

No. 1/13412026-1stl

A copy, each, is forwarded to the officers concerned for information and
necessary action.
Deputy Secretary to Government, Haryana,
Personnel Department. JDated Chandigarh, the 2nd September,2026

No. 1/13412026-13ll

A copy, each, is forwarded for information and action, where necessary to the
following:Secretary to Governor, Haryana.
All the Additional Chief Secretaries, Principal Secretaries and Commissioner &
Secretaries to Government, Haryana.
Director General, Haryana lnstitute of Public Administration, HIPA Complex,
Sector 18, Gurugram.
Resident Commissioner, Government of Haryana, Haryana Bhawan, New Delhi.

1.
2.
3.

4.
5.
6.
7.
8.
g.

10.
11.
12.
13.
14.
15.
16.

All concerned Heads of Departments/MDs of Boards/Corporations.
Commissioners, Ambala/Faridabad/Gurugram/Hisar/Karnal/Rohtak Divisions.
Chief Electoral Officer, Haryana.
Director General, lnformation, Public Relations & Languages, Haryana.
Government, Haryana, Secretariat Establishment
Special Secretary
Department.
All the Deputy Commissioners in Haryana.
Principal Accountant General (A & E) and (Audit), Haryana, Chandigarh.
Secretary, Lokayukta, Haryana.
Secretary, Haryana Public Service Commission.
Secretary, Haryana Vidhan Sabha, Chandigarh.
Secretary, House Allotment Committee (U.T.), Chandigarh.
SlO, NlC, Haryana Civil Secretariat, Chandigarh.

to

Deputy Secretary to Government, Haryana,
Personnel Department.,,No. 1/134/2026-1Sll

Dated Chandigarh, the 2nd September,2026

A copy, each, is forwarded for information and action where necessary to the
following:Establishment Officer and Addl. Secretary to Government of lndia, Ministry of
Personnel, PG & Pensions Department of Personnel and Training, New Delhi.
Addl. Secretary to Government of lndia (S&V), Ministry of Personnel, P.G. &
Pensions, Department of Personnel & Training, Services Division (AlS-lll
Section), New Delhi.
Deputy Secretary to Government of lndia, Department of Personnel &
Administrative Reforms, New Delhi.
Educational Planning
Documentation Officer, National lnstitute
Delhi.
New
Administration, 17-B, Sri Aurbindo Marg,
Research Officer, Career Management Division, Department of Personnel and
Training, R.No. 215, North Block, New Delhi.

1.
2.

3.
4.
S.

of

<!-- page 3 -->

-36.

and Training,
Establishment Officer, C.M. Division, Department of Personnel
R.No. 215, North Block, New Delhi'

Perso n nel DePartment'J.r

No. 1/134/2026-1Sll

Dated Chandigarh, the 2nd Septembet,2026

Principal sgcre!1v]
A copy, each, is fonrvarded to the chief Principal secretary/
osD(vK)/ OSD
Deputy Principal secretary/Deputy Principal secretary-ll/osD(scf/
Secretaries/
(RS)/ OSD (NPrr,ry-OSOtAegjl CjSO tnr.r)/ OSD (VS)/ Special Senior
Ministers/
senior secretaries/ secretaries/ private secretaries to chief Minister/
sp"rr"r for the information of chief Minister/ Ministers/ speaker'
D e p uty S ec reta ry-Io'G ove r n m e nt, Haryana,

Person nel DePartment. J..,.

No. 1/13412026-13ll

Dated Chandigarh, the 2nd September,2026

A copy, each, is fonryarded to the DDOs Concerned with the request that the
issued
LpC, leave salary i pension contributions of officers concerned should be vide
notified
as
format
prescribed
within 7 days of retinqlishing of the charge, in the

a copy thereof
(in
shall invariably be endorsed to the chief Secretary to Government, Haryana
Services-lV Branch) for record and further action'
Gazette Notification No. 11lO:5t2025-2FR/15592, dated 01.04.2026, and

Deputy Secretary totovernment, Haryana,
Personnel DePartment. L.

INTERNAL DISTRIBUTION
2. Supdt.,services-l,lll,lV,V & PAR Cell/HR l, ll, & lll Br'
1. Secy./CS.
4. Supdt., Training /Accounts/ Estt.-1, tl & lll Br'
3. Sr. A.O., AIS (GlS).
6. Secy./SPS.
5. RA at RA's Residence.
8. Lib., Haryana Civil Secretariat.
7 . llc, Computer Section.
2Sll, 3sll, 4sll, ssll, 6sll & 7sll.
10.
9. Liaison Officer, TelePhones
