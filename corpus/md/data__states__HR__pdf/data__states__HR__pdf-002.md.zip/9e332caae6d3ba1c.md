---
doc_id: "9e332caae6d3ba1c"
source_url: "https://cdn.s3waas.gov.in/s325b2822c2f5a3230abfadd476e8b04c9/uploads/2022/01/2022010460.pdf"
ministry: "Gurugram"
title: "Order of Suspension of classes in Universities and guidelines thereoff"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1e71004a6b843f2f"
---

<!-- page 1 -->

/
Order

Date: 02ndJ anuary,2022
Whereas, the COVID-19 has been declared as pandemic by the World Health

organization and National Disaster Management Authority, being satisfied that the district

is

threatened with COVID-l g pandemic.
Whereas, it is evident that there has been an exponential surge in the COVID

cases in the District Gurugram and necessary measures are to be ensured by District
Adminislration to contain the spread of COV]D-19 and also to ensure minimum collateral
damage to the system.

Whereas, keeping in view the emergence of Omicron variant and persistent

rise in COVID-19 cases in the district, in compliance of the State Disaster Management
Authority' Government of Haryana order no. DMC-SPO-2O2)r,41gg dated 01.01 .2022

and
clarification issued vide office memo no. DMC-sPo-2o21to2dated 02.01 .2022by Financiat

Commissioner Revenue and Additional Chief Secretary to Govt. Of Haryana, Revenue

Disaster Management Department, in continuation of this office order no. 01/MB

and

dated

01.01.2022 and in exercise of the powers conferred in me underrelevant provisions

of the
National Disaster Management Act, 200s, l, Dr. yash Garg, lAS, Deputy Gommissioner-

cum'Chairperson, Distrlct Dlsaster Management Authority, Gurugram do hereby clarify
that physical classes in Universities are also suspended. Students are allowed to remain
hostels subject to strict observance of COVID-19 appropriate behavioural norms and

distancing.

'

8. CEO, GMDA Gurugram.
9. Commissioner, Gurugram Division, Gurugram.
10. Commissioner of Police, Gurugram.
1 1. Commissioner, Municipal

Corporation, Gurugram/ Manesar.
(Hq./ManesarMesVEasUSouth/Traffi
DCP
c), Gurugram.
?.
l3.Additional Deputy Commissioner, Gurugram.
14.CEO, ZP, Gurugram.
1 5. sub Divisional offlce(c), Gurugram/sohna/pataudi/Badshahpur.
16. Estate Officer-l & ll, HSVP, Gurugram.
1 7. Joint Commissioner,1, 2, 3 and 4 Muncipal Corporation,
Gurugram.
1 8. District Revenue Officer, Gurugram.
1 9. District Development &panchayat Officer,
Gurugram.
20. Civil Surgeon, Gurugram.
1

in

social

<!-- page 2 -->

21.Joint Director, District lndustries and Commerce, Gurugram.
22. District Labour Commissioner-l & ll, Gurugram.
23. Deputy Director, Animal Husbandry and Dairying, Gurugram.
24. Regional Officer, Haryana State Pollution Control Board, Gurugram.
25. Registrars of Universities in district Gurugram.
26. Distt. Education Officer, Gurugram.
27. District Food Supply & Controller, Gurugram.
28.XEN, Panchayati Raj, Gurugram.
29. XEN, PHED, Gurugram.
30. Divisional Forest Officer Gurugram.
31.XEN, HSAMB, Gurugram.
32.XEN, HSVP Division No. 1 & ll, Gurugram.
33.XEN, PWD B&R (Prov. Divn.), Gurugram.
34. XEN, Horticulture, Gurugram.
35. All Tehsildars/NaibTehsildars in Gurugram.
36. All concerned Officers.
37. Executive Officer, Municipal Corporation, Gurugram.
38. Secretary, Market Committee Gurugram.
9. District Drug Controller, Gurugram.
.

District Public Relation Officer, Gurugram to ensure wide publicity through

prinUsocial Media.
.

District lnformation and Technology Officer, Gurugram.
to DC Gurugram.

. PA

Deputy $H,"",on",

-cum-Cha(filrson DDMA,
Gurugram
