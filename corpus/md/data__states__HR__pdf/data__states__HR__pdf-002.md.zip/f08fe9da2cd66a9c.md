---
doc_id: "f08fe9da2cd66a9c"
source_url: "https://hpgcl.org.in/uploads/tenderdoc/NITBFPCARTRIDGE.pdf"
ministry: "Haryana Power Generation Corporation Limited, Haryana"
title: "Download"
date: ""
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1d4cef605587c86d"
---

<!-- page 1 -->

Schedule-‘B-1’
(Referred to in regulation 7.1)
PANIPAT THERMAL POWER STATION
A Unit of Haryana Power Generation Corporation Ltd.
(Corporate identity Number : U45207HR1997SGC033517)

Assandh Road,Panipat - 132105
An ISO:9001, ISO: 1400and
OHSAS : 18001 certified
company

Ph:0180-2566006,Fax:0180-2566375, e-mail:ptpsxenproc1@gmail.com
Website:-www.hpgcl.org.in, GST No.-06AABCH4536J1ZM
Taxpayer Tradqe / Legal Name:- Haryana Power Generation Corporation Ltd.

ONLINE NOTICE INVITINGTENDER
Tender Enquiry No.
PTP/POM – 100990
Description of Item
Supply of Boiler Feed Pump (BFP)
Cartridge Assembly for 250MW, Unit7, PTPS, Panipat, HPGCL
Start date and time of tender uploading
10.08.2026
at 18:00 Hrs
Last date for submission of tender
09.09.2026
up to 13:00 Hrs
Technical Opening (Part-I)
16.09.2026
at 15:00 Hrs
Tender Fee (Non –refundable)
Rs.1,180/- (Exemption in Tender fee for MSME
Haryana firm only )

e-Service Fees (Non –refundable)
EMD

Rs.1,180/Rs. 5,31,000/-(Exemption in EMD for NSIC or
MSME Haryana firm )

General Terms & Conditions
As per Annexure-A
Technical Specifications & Quantity/ Schedule As per Annexure-B
of Delivery of Material
Statements of bidders
As per Annexure-C
Benefits/ Concessions to the Haryana Based
As per Annexure-D
Micro, Small And Medium Industrial Enterprises
Instructions to the Bidders for e-Tender
As per Annexure-E
GST Documents and Compliances
As Per annexure-F
Documents to be uploaded
As per Annexure-G
PBG Format
As per Annexure-H
1. Pre Qualifying Requirements (PQRs) / Eligibility Conditions for the Bidders:

The tender documents of only those bidders shall be considered who fulfill the
following eligibility criteria and submit documentary evidences in support of the same:(a) The bidder should be Original Equipment Manufacturer/ Supplier (OEM/OES)
or a registered vendor of HPGCL, as per Vendor Registration Policy for the
item.
OR
The bidder must have successfully executed purchase order of supplying
same/similar item(s) in HPGCL/NTPC/ any State Electricity Board/any
Public Sector Undertaking / any Corporation/Central Govt./ State
Government Undertaking/Semi Govt. or any Thermal/Hydel Power Plant
during last 07 years ending July-2026 along with copy of satisfactory
performance certificate/repeat order from the same organization. The
experience of execution of purchase order should be as under:

Single order of value not less than Rs. 2.12 Crore
or
 Two orders of value not less than Rs. 1.33 Crore each
or
 Three orders of value not less than Rs. 1.06 Crore each.
(a) The bidder should certify having testing facilities at its works (NDT is required) or
the testing will be carried out at any Govt. approved test laboratory acceptable to
HPGCL. HPGCL shall notify the list of the acceptable labs.
(b) The bidder should certify that it has not been blacklisted by any organization
presently. However, in case such certification is found wrong at a later stage,
then it will be construed as misrepresentation of facts and the bidder shall be
liable for blacklisting and other penal actions.
(c) Bidder has to supply valid GST registration certificate, as on date, of place of
supply.

Page 1 of 25

<!-- page 2 -->

(d) Average annual turnover of the bidder in the preceding three (03) financial years
viz 2022-23, 2023-24 & 2024-25 as on the date of bid opening, shall not be less
than Rs. 7,79,00,000/- Other income shall not be considered for arriving at
annual turnover.
(e) Bidder will have to submit following undertaking on its letter head:
(i)
That GST Registration Certificate of place of supply
i.e.,………………………is valid as on date.
(ii)
That no default has ever been made by bidder in filing the various
GST returns and deposit of GST dues with the department.
(iii)
That Bidder is having multiple registrations under GST i.e.,
…………………….and no default has ever been made by bidder in
filing the various GST returns and deposit of GST dues with the
department for above GST Numbers. If a default is found at a later
stage under a GST number even if the GST number pertains to some
other state, then it will be construed as misrepresentation of facts and
will make the vendor ineligible to participate in tender.
Note: - The firm should fill tender as per annexure-A of General Terms & Conditions and
submit authentic supporting documents for proving its credential. Original documents may be
asked for verification at the time of finalizing the tender. A certificate to the effect that the
tenderer is not black listed from any Public Sector undertakings of Central Govt./State
Govt./SEBs/Corporations/any other reputed thermal plant. Decision of the HPGCL regarding
fulfillment of pre qualification requirement shall be final and binding upon the bidders.

1. Conditions of the contract and other information can be had from the office of XEN/P-I
(ptpsxenproc1@gmail.com) on any working day prior to last date of submission of
tenders. The payment of Tender Document Fee and eService Fee can be made
online directly through Debit Cards & Internet Banking Accounts. The payment of
Earnest Money can be made by eligible bidders/ contractors online directly through
RTGS/NEFT.
2. Disqualification of the Bidder:i) Even though the bidders meet the above Qualifying Criteria they are subject to
be disqualified, if they have made misleading or false representations in the
forms, statements and attachments submitted in the proof of the qualification
requirements.
ii) The Bidders shall supply partnership deed in case of partnership firm /
Memorandum of Association and Article of Association in case of a company.
iii) Not withstanding anything stated above Haryana Power Generation
Corporation Ltd. reserves the right to assess the Tenderer capacity to perform
the contract should the circumstances warrant such assessment in the overall
interest of the Haryana Power Generation Corporation Ltd. In this regard the
decision of corporation will be final.
3. Before submitting tenders the instructions may be read carefully regarding submission
of tender. If any bidder finds discrepancies or omissions in the tender documents or is
in doubt as to the true meaning of any part, he shall clarify same from tender issuing
office in writing before the due date of submission of the bid.
4. Unless exempted specifically, tenders not accompanied with the prescribed
EMD/Cost of Tender shall be rejected. EMD/Cost of Tender shall be in the prescribed
mode of payment as asked in the NIT; otherwise, the tender shall be liable to be
rejected.
Note:
(i)
EMD is exempted only for the bidders as per instructions/guidelines
contained overleaf as well as at Sr. No.6 of Annexure-A (General T&Cs).
(ii)
Tender documents fee @ Rs. 1180/- is exempted only for Haryana based
Micro & Small firms as per guidelines mentioned in Annexure-D. Without
online submission of EMD & tender documents fee (except for eligible
bidders as per point (i) & (ii) above, the tender shall be rejected).
5. Tenders through Fax/ E-mail/ telegraphic tenders/speed post/registered post/courier
shall not be considered. Incomplete, obscure or irregular tender is liable for rejection.
If the Bidder deliberately gives wrong information in his tender, HPGCL reserves the
right to reject such tender at any stage.
6. The validity of the tender/ offer shall be for 120 days from the date of opening of
the price bid.
7. The tender documents can also be seen on HPGCL Website i.e.www.hpgcl.org.in
8. The tenderer will quote their rates strictly as per details of materials specifications.
9. a) Suo-moto revised price bid/supplementary Part-II will not be accepted after the last
date of submission of the tender. However, in case revised price bid is submitted by the
bidder Suo-moto but prior to the due date of submission of the tender, then the revised
Page 2 of 25

<!-- page 3 -->

price bid only, shall be opened and considered by the purchasing authority.
b) Negotiation Policy will be followed as per Haryana Govt./HPGCL negotiation policy
with amendment from time to time.
In case of Haryana based MSME firms, procedure as per G.O. No.-02.02.2016-41B11
(1) dated 20.10.2016 (Annexure-D) and shall be followed.
10.) Rates shall be quoted by the Bidder, item wise with price breakup on FOR
destination basis. No deviation in terms shall be allowed. However, if not provided
separately, then loading of Packing & Forwarding, Freight and Transit Insurance
shall be done, for comparison purposes, as under:
a) Packing & Forwarding: @ 0.5% of basic rate.
b) Freight: @ 4.0% of basic rate or the railway freight on the basis of published
goods tariff of Indian Railways or freight on the basis of publication/certification
of some approved transporter in case of any other mode of transport declared in
the NIT, whichever is higher.
c) Transit Insurance: @0.25% of basic rate.
d) Loading on account of deviation in payment terms shall be made @ 0.5% per
week or part thereof at the time of preparation of comparative statement.
11. Purchase preference of the tendered quantities may be allowed as per policy of
the State Government to the Industrial Units located in Haryana on the lowest
valid rates if Bidder so claim with requisite documentary evidence.
12. The bidders/ Suppliers shall observe the highest standards of ethics during the
submission of tender, procurement and execution of the contract. In case of
evidence of cartel formation by the bidder(s) EMD is liable to be forfeited.
13. The bidder shall bear all costs including bank charges, if any, associated with the
preparation and submission of his bid and the purchaser will in no case be
responsible or liable for those costs, regardless of the conduct or outcome of the
bidding process.
14. Any statutory taxes/ duties/ other levies, if to be charged extra should be clearly
indicated by Bidder in their offer separately, failing which it will be presumed that
their quoted prices are inclusive of all such statutory taxes/ duties/ other levies.
15. No provision for price escalation is made on any account. The price quoted by
the tenderer shall be FIRM till the contract is completed.
16. Normally the tenders should not differ from the Terms & Conditions and
technical specifications incorporated in the Tender Documents. In case of any
deviation the same shall be specifically mentioned on separate sheet otherwise
it will be presumed that tenderer agreed all terms & conditions as per Tender
Document.
17. Opening of Tender:
In cases where e-tenders are invited in two parts, the bidder shall upload their
technical offer containing documents, qualifying criteria, technical specifications,
schedule of deliveries and all other terms and conditions etc. except the rates (
Price-Bid ) in the part-I (Technical envelope). The price bid shall be submitted in
separate part-II format supplied by purchasing authority online. The committee
members shall open only part-I on scheduled date of opening of Technical bid. The
tenders shall be opened on the due date in the office of XEN/Proc-I PTPS, HPGCL
by tender opening committee comprising Executive Engineer and Sr. A.O. The
tender documents shall be downloaded and print outs taken.
a) The Price Bid (Part-II of the tender) shall be opened after Part-I of the tenders
have been scrutinized and evaluated. The Bidders whose Part-I have been
approved, will be allowed to participate in opening of Price Bid (Part-II). The
due date and time for opening of Price Bid (Part-II) shall be informed later on.
i) Earnest Money: - The Bidder shall deposit requisite Earnest Money (as
applicable) along with the tender to ensure that the Bidder takes up the
contract in right earnest.
ii) The EMD of the successful Bidder will be adjusted against security deposit in
the event of placement of order. EMD of unsuccessful Bidder will be refunded
on finalization of contract.
iii) No interest shall be payable on Earnest Money Deposit.
iv) HPGCL reserves the right to forfeit Earnest Money Deposit or part thereof in
circumstances which may indicate that the contractor is not earnest in
executing the contract. EMD shall also be forfeited in case the bidder does not
come forward for execution of the contract agreements and submission of
balance security deposit.
Page 3 of 25

<!-- page 4 -->

18.

If the Bidder withdraws his tender at any stage during the currency of his
validity period, the earnest money shall be forfeited in full in such cases.
19. Purchaser reserves the right to cancel the NIT or to change qualifying
requirement or to reject any or all the tenders so received without assigning any
reason.

Executive Engineer/Proc-I,
for CE/PTPS, HPGCL,PTPS, Panipat.

Page 4 of 25

<!-- page 5 -->

Information Regarding Online Payment of Tender Document, e-Service & EMD
Fee.
The Bidders can download the tender documents from the portal:
https://etenders.hry.nic.in
The Bidders shall have to pay for the Tender documents, EMD Fees & e-Service Fee
online by using the service of secure electronic payment gateway. The secure electronic
payments gateway is an online interface between contractors and online payment
authorization networks. The payment for Tender Document Fee and e-Service Fee can
be made by eligible bidders/ contractors online directly through Debit Cards & Internet
Banking Accounts and the Payment for EMD can be made online directly through
RTGS/ NEFT.
NOTE: If the tenders are cancelled or recalled on any grounds, the Tender Document
Fees & e-Service fee will not be refunded to the agency.
NOTE: Those agencies who are exempted from EMD should submit proof of related
documents at least 10 days before the end date of “Downloading of Tender
Documents & Bid Preparation” stage to publisher of the tender i.e. concerned
Executive Engineer of that Procurement Division.
The following are exempted from depositing the earnest money: i)
Public Sector Undertakings of the Central / Haryana State Government.
ii)
Firms borne on D.G.S.&D / DS&D Haryana rate contracts.
iii)
Firms registered with the Director of Industries, Haryana or registered with
National Small scale Industries Corporation, Govt. of India. MSME Haryana who
have filed Entrepreneur Memorandum in Haryana in respect of quoted items,
participate directly in tender not through any intermediaries (their
dealers/agent/distributors) will not subcontract to any other firm and to carry the
entire manufacturing at their enterprise. The exemption shall be for the specified
items which are available on Director of Industries, Haryana/ NSIC Rate
Contracts.
iv)
Haryana based Micro, Small and Medium Industrial Enterprises in the State
Public Procurement in line with G.O. No.-02.02.2016-41B11 (1) dated
20.10.2016 as per Annexure-D.
v)
Firms borne on the HPGCL’s approved list of suppliers which may have made a
permanent earnest money deposit of Rs.10.00 Lacs at the respective
Project/office of HPGCL or Rs. 20.00 Lacs for quoting anywhere in HPGCL, if
they quote the Registration number given by the respective project/office of
HPGCL in their tender papers.
The Bidders can submit their tender documents (Online) as per the dates mentioned in the
below mentioned key dates:Key Dates
Sr.
Expiry date and
Department Stage
Bidder’s Stage
Start date and time
No.
time
Tender Authorization &
10.08.2026
at 09.09.2026
at
------------1
Publishing
18:00 Hrs
13:00 Hrs
at
Downloading of Tender 10.08.2026
18:00 Hrs
Documents & Bid
09.09.2026 at
2
-----13:00 Hrs
Preparation& Bid
submission
09.09.2026
Last date of submission of
3
------at 13:00 Hrs
Bid online
4

Technical Opening (Part-I)

-----

5

Short listing of technical
bids & Opening of
Financial Bid

----

Page 5 of 25

16.09.2026
at 15:00 Hrs
Will be intimated to the firms on
their e-mail IDs

<!-- page 6 -->

Annexure-A
SCHEDULE ‘C-1’
(Referred to in regulation 7)

1)

GENERAL TERMS AND CONDITIONS OF CONTRACT (Supply order)
DEFINITIONS:
In the contract (as defined below) unless the context requires otherwise the words and expressions
defined below shall have the meaning hereinafter assigned to them.
a)
b)

2)

3)

The ‘Purchaser’ shall mean the HPGCL and shall include its successors in office and assigns.
The ‘Supplier/Manufacturer’ shall mean M/s.______________________ and shall include the
Supplier’s legal representatives, successors and assigns.
c) ‘Material’ shall mean and include the material to be supplied by the Supplier under the contract as
per contract.
d) ‘Specifications’ shall mean and include the specifications as detailed in the Annexure attached
herewith and drawings attached thereto as well as samples and patterns, (if any).
e) ‘Drawing’ shall mean the drawing/drawings annexed to the specification (if any) or as approved by
the purchaser.
f) The ‘Site’ shall mean and include lands & buildings over/ under upon where the materials are to be
installed and used in accordance with terms & conditions.
g) ‘Place of delivery’ shall mean the place of delivery at which the Supplier is responsible to deliver
the materials at the specified contract price.
h) The terms ‘F.A.S’, ’F.O.R’, ’F.O.B.’, ’C.I.F.’ and other shipping dispatch terms as used herein shall
have meaning in accordance with their usage in India.
i) ‘Work’ shall mean and include supply of all materials, plants and equipments and rendering of other
services by the supplier under this contract.
j)
‘Consignee’ shall mean the officer to whom the material is required to be dispatched or the person
specified in the purchase order.
k) ‘Contract’ shall mean the Notice Inviting the Tender, Tender Form, and conditions of contract with
their annexure and Purchase Order/ Acceptance of offer/ tender/ LOI/ LOA.
l) ‘Purchasing Authority’ shall mean the officer signing the acceptance of tender and shall include any
officer who has authority to execute the relevant contract on behalf of the Purchaser.
m) ‘Purchase Order’ shall mean an order of supply of material including the acceptance of the tender.
n) ‘Annexure’ shall mean the Annexure to the terms & conditions.
o) ‘Test’ shall mean such test as is prescribed by the ISI or by the HPGCL and/ or considered
necessary by the authorized agent of the Purchaser whether conducted/ performed or made by him
or any other agency acting under his direction.
p) ‘Delivery’ shall be deemed to take place on delivery of material in accordance with terms of the
Contract after test and inspection by the Purchaser or his authorized agent, to the consignee. If the
rates are ex-works, date of dispatch/ Goods Receipt (GR) and in case the rates are FOR
destination, date of receipt of material in store in good conditions shall be treated as date of
delivery.
q) ‘Inspecting Agency’ means the agencies nominated and authorized by the competent authority for
inspecting the material at the Works of the supplier or at the designated place of inspection
prescribed by the purchasing authority.
r) ‘Inspecting Officer’ means, officer of the Corporation appointed by the Chief Engineer or the
purchasing authority for inspection.
s) ‘Contract Value’ shall mean the bare value of the goods ‘ex-works price’ without taking into account
taxes, duties or any other incidental charges where the price is ex-works. But where the prices
given in the PO are on FOR destination basis inclusive or exclusive of GST etc., the ‘Contract
value’ would mean FOR destination prices, given in the PO inclusive of GST & other statutory
levies etc. as the case may be.
t) ‘Total Contract Value’ shall mean contract value plus statutory dues like GST etc. and any other
amount payable under contract.
PARTIES:
The parties to the Contract are the Supplier and the Purchaser, Legal address of the Parties to the
Contract is as under:
Supplier: M/s…………………………………………………………………….. on which P.O. is placed.
Purchaser: Panipat Thermal Power Station, Panipat (A unit of Haryana Power Generation
Corporation Ltd.)
For all purposes of the contract, including the arbitration there under, the address of the Supplier
mentioned above, shall be the address to which all communications addressed to the supplier shall
be sent, unless the Supplier has specifically intimated a change thereof.
AUTHORITY OF THE PERSON SIGNING THE CONTRACT ON BEHALF OF THE SUPPLIER:
It is presumed that the person who has signed these Tender-papers (including the terms and
conditions) has got authority to sign on behalf of the supplier. If it is discovered at any time that the
person so signing had no authority to do so, the purchaser without prejudice to any other right or
remedy available to him, may cancel the contract and make a purchase of the material at the risk and
cost of such person and hold such person liable to the purchaser for all costs and damages arising
from the cancellation of the contract including any loss which the purchaser may sustain on account
of such purchase.

4) RESPONSIBILITY OF THE SUPPLIER FOR EXECUTION OF THE CONTRACT:
i) Risk of Material: - The Supplier shall execute the Contract in all respect in accordance with these
terms & conditions. The materials and every constituent part thereof, whether in possession or control
of the Supplier, his agents or servants or in joint possession of the Supplier, his agent, Servants and the
Purchaser, shall remain in every respects at the risk of the Supplier and Supplier shall be responsible
for all loss, destruction, damage or deterioration of or to the material from any cause whatsoever while
the material after test and inspection is awaiting dispatch or delivery or in course of transit from the
Supplier to the consignee. The Supplier shall be entitled and responsible to make claims against the
Railway Administration or other carrier in respect of non-delivery, short delivery, miss-delivery, loss,
destruction, damage or deterioration of the material entrusted to such carrier by the Supplier for
transmission to the Consignee.
ii)
Consignee’s right of rejection: Not withstanding any approval which the Purchaser may have given
in respect of the material, it shall be lawful for the consignee to reject the material or any part therefore
of on behalf of purchaser within reasonable time after actual delivery thereof to him at the place or
destination specified in the Schedule. If the material or any part or portion thereof is not in all respect in
Page 6 of 25

<!-- page 7 -->

conformity with the terms and conditions of the contract, whether on account of loss, deterioration or
damage before dispatch or during transit or otherwise howsoever.
The provision relating to the removal of material rejected by the Purchaser or his
authorized Agent shall, mutatis mutandis, apply to material rejected by the consignee as herein
provided.
Subletting and assignment: The Supplier shall not, sublet, transfer or assign the contract or
any part there of or interest therein or advantage thereof in any part thereof in any manner whatsoever
without prior consent of the purchaser.

5)

PRICES:
(i)
Item wise prices with price breakup (i.e. cost price, freight, taxes and duties separately) shall be
quoted by the bidders on FOR destination basis and shall remain FIRM during the currency of
contract unless otherwise agree. No deviation in terms should be allowed. However if not
provided separately, then loading of Packing & Forwarding, Freight and Insurance shall be
done, for comparison purpose, as under:
a)
Packing & Forwarding: @ 0.5% of the basic rate.
b)

Freight

: @ 4.0% of the basic rate.

c)

Transit Insurance

: @ 0.25% of basic rate.

II) Goods & Service Tax Certificate: The Goods & Service Tax, if extra, shall be paid as per
actual within the delivery period of production of following certificate: a.) Certified that
transactions on which tax has been claimed will be included in the return to be submitted to the
GST authorities for assessment of GST and the amount claimed from the HPGCL shall be paid
to the GST authorities. b.) Certified that the goods on which GST has been charged have not
been exempted from GST Act or rules made there under. The charges on account of GST on
these goods are correct under the provisions of the relevant Act or rules made there under. C.)
Certified that we shall indemnify to HPGCL in case it is found at a later stage that the incorrect
payment has been recovered on account of GST by us.
d.) Certified that we are registered as dealer and our Haryana/CST no. is -----------------------.
Our GST No. is ………………….. (Signature of Supplier)
Note: Any increase in taxes & duties after the delivery period shall be on the supplier’s account
and shall not be borne by HPGCL (The above note shall not be applicable in case supplier is a
Govt./Semi-Govt./PSU)
Apart from above certificate, Supplier has to furnish all GST documents and
compliances of GST as per Annexure-F attached.
(ii)

(iii)

6)
7)

i)
ii)
iii)

iv)
v)

ESCALATION/ PRICE VARIATION CLAUSE:
No escalation shall be permitted in respect of any increase not arising out of the operation of
any law and statutory or mandatory order of the Govt. of India or the concerned State Govt. In
case the period of the purchase order for completion of supplies is more than one year and
Bidder wishes to include an escalation clause in his quotation then bidder should provide full
details of the escalation formula and bring out precisely the actual increase in the price of the
finished item for every rupee worth of increase in each item of raw material/ component of
wages, to which the escalation applies. The Bidder shall furnish such documentary evidence, as
may be required by the HPGCL, in support of the increase in respect of each item of raw
material/ component of wages etc. for which the escalation is claimed. No escalation/ price
variation shall be considered beyond the scheduled delivery period. However, for valuation of
L1 bidder the total contract value for the contract period shall be considered.
FOREIGN EXCHANGE VARIATION:
In case of the contract for procurement is in foreign currency then the applicability of the foreign
exchange variation should be clearly defined. The period of the applicability of the exchange
variation should be restricted according to the delivery schedule. Ordinarily the exchange
variation should not be permitted in the extended period of the delivery.
TECHNICAL PARTICULARS: Material as per the specifications given in Annexure -B is required.
Deviation in specifications will not be acceptable. It would therefore be in the interest of bidder to
study the specifications, drawings etc. in the tender schedules before quoting.
EARNEST MONEY AND SECURITY DEPOSIT:
Every bidder, while submitting his tender, shall be required to give the earnest money deposit
specified in the e-NIT. EMD through online mode at e-portal only shall be accepted. The
earnest money furnished by the successful tenderers on whom the purchase order is placed shall
be converted into security deposit as a guarantee for faithful and satisfactory execution of the
purchase order /ARC up to warranty period.
The EMD of the unqualified bidders will be returned by the purchaser without any interest, as
promptly as possible, within 30 days after declaration of qualification result and that of unsuccessful
bidders within 15 days of the execution of the contract with the selected bidder.
The following are exempted from depositing the earnest money:Public Sector Undertakings of the Central / Haryana State Government.
Firms borne on D.G.S.& D / DS&D Haryana rate contracts.
Firms registered with the Director of Industries, Haryana or registered with National Small scale
Industries Corporation, Govt. of India. The exemption shall be for the specified items which are
available on Director of Industries, Haryana/ NSIC Rate Contracts. Please refer Annexure-III of the
NIT for details.
Haryana based Micro, Small and Medium Industrial Enterprises in the State Public Procurement in
line with G.O. No.-02.02.2016-41B11 (1) dated 20.10.2016 as per Annexure-III of the NIT.
Firms borne on the HPGCL’s approved list of suppliers which may have made a permanent earnest
money deposit of Rs.10.00 Lacs at the respective Project/office of HPGCL or Rs. 20.00 Lacs for
quoting anywhere in HPGCL, if they quote the Registration number given by the respective
project/office of HPGCL in their tender papers.

The earnest money / security deposit shall be forfeited in part or in full under the following
circumstances:Page 7 of 25

<!-- page 8 -->

i)
ii)

iii)

iv)
v)

If the tenderer withdraws his tender at any stage during the currency of his validity
period.
If the P.O/ARC has been issued but the supplier refuses to comply with it, the EMD
deposited by him shall be forfeited in full, irrespective of whether the HPGCL sustains any
loss on account of his default or not. This forfeiture shall be without prejudice to the right of
HPGCL to claim any other damages as admissible under law as well as to take such
administrative action against the supplier as blacklisting etc.
Where the purchase order has been complied with but the supplier stops making the
supplies after partially fulfilling the purchase order, the security deposit shall be retained
and adjusted against any loss that may be caused to HPGCL through risk purchase from
alternative source and/or any other damage recoverable from the supplier under the terms
of contract.
In the event of breach of a contract in any manner, the security deposit shall be forfeited
and adjusted against the claim of HPGCL on the supplier for any damages or for any loss
sustained by HPGCL on account of such breach.
In the case of evidence of cartel formation by the bidder(s).

In case where the Performance Bank Guarantee has been agreed by the supplier, the security deposit
shall be released on the completion of the supplies. In other cases, the same shall be released only after
warrantee period on the certificate of the purchaser for satisfactory completion of the warrantee period.
No interest shall be paid on EMD for the period it remains deposited with HPGCL.

8)

Security Deposit: - Supplier shall deposit security equal to @2% of the value of order on receipt of
the indent/purchase order for its faithful execution. The earnest money, if any, shall be adjusted
towards security deposit. In case of default or non-fulfillment of terms & conditions of the purchase
order, the security deposit will be forfeited by the HPGCL. The security deposit shall be retained by
the purchaser for the entire period of contract including warranty period. No claim shall be made
against the purchaser either in respect of interest, if any, due on the security deposit / earnest
money or its depreciation in value.

9)

PAYMENT TERMS:
The payment shall be made along with full taxes after deducting GST TDS as per applicable rates. The
Bank Guarantee, if applicable, should be submitted on the HPGCL, prescribed format, on Non-Judicial
Stamp Paper of Rs.15/- and the same should be sent to Sr.A.O ,PTPS/RGTPP,Panipat along with the
bills & invoices under intimation to this office. Subject to any deductions which the purchaser may be
authorized to make under this contract, the payment for the material shall be made as under:“100% payment shall be made after 21 days of receipt of material at site in good condition and
after receipt of 10% PBG and submission of required documents."
10% PBG (or amended time to time by Govt.), valid for G/W period should be in favor of Sr.A.O, PTPS,
HPGCL Panipat. All bank charges shall be borne by supplier. Part payment & part supply there of
shall be applicable
Note: Receipt of material at site shall mean receipt of material in accordance with terms of the
Contract after test and inspection by the Purchaser or his authorized agent, along with the requisite
documents specified in clause no. 12.

10)

MODE OF PAYMENT:
Payment shall be released by the Sr. Accounts Officer, O&M-II, PTPS,Panipat by account payee
cheque payable at __________________________/RTGS/NEFT. For payment through
RTGS/NEFT, the supplier will provide complete bank details viz. Name of Bank/Branch, Account
Number, Type of Account, IFSC Code etc. to concerned Sr. Accounts Officer. The firm will provide
their GST registration No., HSN Code, PAN Number, place of business with address and a
unique invoice number suffix with concerned station (PTPS, RGTPP, DCRTPP, FTPS,
Corporate Office). So that the invoice could be distinguish with other place of business of
HPGCL i.e. PTPS, RGTPP, DCRTPP, FTPS, Corporate Office.

11) DELIVERY PERIOD AND DAMAGES FOR DELAY:(i)

The date of delivery of material as specified in the purchase order shall be the essence of the
contract between the supplier and the Corporation, and the delivery of each consignment must
be made as per delivery schedule.
(ii) Delivery period shall be strictly as per Annexure-B
(iii) No supplies/ consignments received after the date on which they were actually due according to the
terms of the purchase order, shall be accepted by the consignee, except with the written approval of
the purchasing authority. Even in case of acceptance of delayed supply the supplier shall be liable to
pay @ 0.5% per week or part thereof of the delay of the value of the goods so delayed where the part
supply is acceptable and of the PO value where part supply is not acceptable, subject to a maximum
of 5% of the total value of the delayed / undelivered supplies.
(iv) In case the delivery schedule provides lot wise delivery of material, lot wise penalty shall be imposed
(v) The material dispatched by a supplier after the expiry of the delivery period will not be accepted by
the Consignee without the approval of the Purchasing Authority.
(vi) The delivery period shall be reckoned from the 7th day of issue of P.O. / L.O.I. whichever is earlier.
(vii) Extension in Delivery Schedule: No extension of dates on which the delivery is due as per the terms
of Purchase Order shall be granted except under force-majeure circumstances as defined under
clause of the contract/PO. Acceptance of a delayed supply shall be at the sole discretion of the
Purchasing Authority and shall be subject to the levy and recovery of applicable liquidated damages
as prescribed under contract/PO.
(viii) In exceptional circumstance, where the supplier applies for a extension of the due date of delivery
well before the due date, and advances good and valid reasons for claiming extension to the
satisfaction of the Purchasing Authority, the Authority may grant such extension by amending the
relevant clauses of the Purchase Order, with no extra financial liability on HPGCL on account of
Page 8 of 25

<!-- page 9 -->

increase in statutory levies, etc. during the extended period. Further, in the event of grant of
extension, no penalty/liquidated damages in terms of clauses of contract/PO shall be leviable or
recoverable from the supplier.

12)

TESTS AND INSPECTIONS:The tests (Metallurgical test “NDT” of material is required) and inspections shall normally be
arranged at the supplier’s premises before the material is dispatched to the Corporation, and copy
of the inspection/ test report in such case shall be attached by the supplier in original along with
Railway Receipt/ GR and other requisite document as per P.O. For this purpose, the supplier shall
give at least 15 days notice to the purchasing authority to arrange for the inspection of goods
offered for dispatch, on different occasions, before dispatch if inspection is not waived off. In
addition to this, the supplier has to submit copy of test certificates along with inspection call.
Without test certificates, pre-dispatch inspection call will not be accepted and delay on this account
will be on the part of the supplier.
HPGCL has the right to get the pre-dispatch inspection done from third party along with HPGCL
representative.
In case, the supplier is not having its own testing facility and any agency has not been specifically
mentioned in the PO, then the supplier will submit the test certificates issued from any Govt.
approved laboratory.
Supplier shall ensure that all the facilities necessary for carrying out the inspection/prescribed tests
are made available to the inspection officer at the point of inspection to be carried out.
In case of non conduct of testing due to non availability of material, the charges of the inspecting
officers shall be borne by the supplier.
The inspection call received after expiry of delivery period may or may not be entertained.
Supplier shall dispatch the material with copy of inspection report and manufacturer test certificate,
immediately after inspection but not later than 10 days failing which the delay shall be on the part of
supplier for the purpose of L.D. In case of waiver of inspection, supplier shall dispatch the material
within 10 days of receipt of waiver letter or 15 days of dispatch of waiver letter whichever is earlier.

13)

Note:a)

DOCUMENTATION:The supplier shall submit a set of documents as detailed below well in time to the following offices for
processing his bill for pass and payment.
A)
Concerned Executive Engineer (Purchaser copy):
a) Acceptance of PO.
b) Readiness of material/ inspection call.
c) Copy of invoice with HSN code of each Item and their respective GST rate.
d) Copy of RR/ GR.
e) Advance intimation of dispatch.
f) Test Certificates.
g.) Copy of valid e-Way bill.
h.) Copy of GST R1& 3B return challans, GST Documents & Compliances to be made by the
supplier.
B)
Concerned Sr. A.O. (Accounts copy):
a) Copy of invoice in triplicate with HSN code of each Item and their respective GST rate.
b) GST Certificate.
c) Proof of Insurance charges.
d) Guarantee/ Warranty Certificate.
e) Interchangeability Certificate.
f) Copy of inspection report.
g) D.D on account of security deposit.
h) Performance Bank Guarantee.
i) Copy of R.R./ G.R.
j) Copy of valid e-Way bill.
k.) Copy of GST R1& 3B return challans, GST Documents & Compliances to be made by the
supplier.
C)
Concerned Executive Engineer/ Stores (Consignee copy):
a) Copy of invoice.
b) Copy of Inspection Report.
c) Dispatch particulars.
d) Copy of RR/GR.
e) Copy of valid e-Way bill.
D)
Appropriate branch of State Bank of India, if document are to be negotiated through Bank:
a) Copy of invoice/a unique Invoice No.
b) Original RR/ GR.
If the documents shown above are not sent to the appropriate office within due period then bank
document will not be retired and the responsibility for demurrage/ wharfage or auction of material
will be on the supplier’s account. No interest, what so ever on any account shall be paid by
HPGCL. Bank Charges if any shall be borne by the supplier.Our Taxpayer Trade/ Legal Name is
Haryana Power Generation Corporation Ltd. With GST No 06AABCH4536J1ZM. The firm must associate
word PTPS in suffix with their Unique Invoice No. and also upload same on auto populated details.

14)

PACKING:
The supplier shall provide for secure protection & packing of the equipment in accordance with the
best established Practices so as to protect the equipment from damages. Any breakage, damage
and/or pilferage including, when in transit, arising from faulty packing shall be the responsibility of the
supplier.All packages shall be visibly marked mentioning purchase order number & name of buyer in
bold letters & must contain copies of challans/ packing slips inside.

15)

MODE OF TRANSPORT:
The normal mode of transport for dispatch of material from supplier’s end shall be by train/ approved
road transporter of HPGCL.
Page 9 of 25

<!-- page 10 -->

16)

TRANSIT INSURANCE:
a)
The material shall be insured against all risks and loss for its full delivered value up to the
destination station. The insurance charges from dispatching station up to the destination station
will be borne as per provision in the PO. The Supplier shall produce insurance cover and also a
stamped acknowledgement receipt of the insurance company for the premium paid by them in
support of their claim, if any. The consignee shall report losses/ damage to the Supplier at the
earliest possible of the receipt of the consignment at the site.
It will, however, be the responsibility of the Supplier to prefer timely claim on the insurance
underwriters. The Supplier will make good the losses/ shortages, replace/ repair the damage to
the consignee irrespective of the claim lodged/ to be lodged with the insurance underwriters or
other appropriate authorities.
The Supplier shall supply or replace such material or parts as are lost in transit within
reasonable time based on the delivery period free of charges.
The Supplier shall be responsible for all loss, destruction, damage, deterioration of the material
from any causes whatsoever in the course of transit from the Supplier to the consignee. If
insurance is in the scope of consignee, the firm will intimate to the consignee in advance about
dispatch of material otherwise all the losses, if any will be in the account of supplier.
b)

In case of supply of material against documents through bank, no material shall be accepted
without proper transit insurance.

17)

PERFORMANCE BANK GUARANTEE:
Supplier shall submit bank guarantee of the Nationalized Bank equivalent to 10% of the order value in
the prescribed Performa valid up to 21 months from dispatch of material. Moreover, in the case of
Performance Security, the instructions issued by Director General Supplies and Disposal Department,
Haryana office order memo no. DGS&D/Admin/Performance security/2020 Dated 14.12.2020 shall be
followed.

18)

WARRANTY:
The supplier shall be made responsible to replace free of cost, with no transportation or insurance
cost to the Corporation, up to the destination the whole or any part of the material, which in normal
and proper use proves defective in quality or workmanship, subject to the condition that the defect is
noticed within 12 months from the date of use of material at site or 18 months from the date of
receipt, whichever period may expire earlier. The consignee or any other officer of the corporation
actually using the material will give prompt notice of each such defect to the supplier as well as the
Purchasing Authority and the Sr. A.O.. The replacement shall be effected by the supplier within
reasonable time, but not, in any case, exceeding 45 days. The supplier shall, also, arrange to remove
the defective supply within a reasonable period, but not exceeding 45 days from the date of issue of
the notice in respect thereof, failing which, the corporation shall reserve the right to dispose off the
defective material in any manner considered fit by it at the sole risk and cost of the supplier. Any sale
proceeds of the defective material after meeting the expenses incurred on its custody, disposal,
handling etc. shall, however, be credited to the supplier’s account and set off against any outstanding
dues of the corporation against the supplier.
The supplier shall furnish warranty certificate stating that, “we will be responsible to replace within 45
days of the date of issue of notice, free of cost, with no transportation or insurance-cost to the
Corporation, up to the destination the whole or any part of the material supplied by us against P.O.
No.- __________ dated _______, within a period of _____________which in normal and proper use
proves defective in quality or workmanship, within 12 months from the date the material is received by
the consignee or 18 months from the date of dispatch whichever is earlier”.

19)

The provisions shall, mutatis mutandis apply to the replaced material. In case the material is again
found to be defective within a period of 12 months of its replacement, it shall also have to be replaced
similarly (Guarantee/ warranty clause shall be applicable to the replaced material also).
FORCE MAJEURE:i.
Supplier shall not be liable for loss or damage due to delay in manufacturing or delivery of the
material / equipment on order as may result from any causes beyond arising out of
compliance with regulations, orders or instructions of the Central or State Governments, acts
of God, acts of civil & military authority, fires, floods, strikes, lock-outs, freight embargo,
war-risk, riot and civil commotion.
ii.
Whenever the supplier is not in a position to supply the material within the delivery period and
he wants extension in the due date (s) of delivery under this clause, he will request for such
extension of the delivery period along with all necessary evidence, before the expiry of the
schedule date(s) of delivery. In no case, the delivery period shall be extended under this
clause, if the request is received after the due date of delivery has expired. Extension in the
delivery period may be granted only for the period for which delay in the completion of the
supply is proved by the supplier for the circumstances mentioned in this clause.
iii.
In all such cases, HPGCL shall have the option to accept any portion of the balance material
and cancel the order for the rest, provided that if any material had been manufactured
exclusively for the purchaser under this contract, prior to the commencement of the force
majeure circumstance, it shall be accepted by the purchaser, and that secondly, the
cancellation will be without any liability of HPGCL for damages on the part of the supplier.
iv.
Non availability of raw material or any other similar cause shall not be considered as a force
majeure circumstance.
v.
The decision of HPGCL in all matters under this clause shall be final and binding on the
supplier.

Page 10 of 25

<!-- page 11 -->

20)

DEMURRAGES:
The Supplier shall be responsible for all demurrage charges due to late receipt of G.R. and nonreceipt of prior intimation of dispatch of material to the consignee. G.R. through bank other than
specified one will not be accepted. If any consignment and or its relevant shipping document are
dispatched to an incorrect address/ destination or parts of the case, the additional expenses involved
& delay in delivery shall be to the Supplier’s account.

21)

ARBITRATION:
All matters, questions, disputes, differences and / or claims arising out of and / or concerning, and /or
in connection with, and /or in consequence of, and /or relating to this contract, whether or not
obligations of either of both parties ( the Supplier and the Corporation) under this contract be
subsisting at the time of such dispute and whether or not this contract has been terminated or
purported to be terminated or completed, shall be referred to the sole arbitration to be appointed by
the mutual consent from panel of Arbitrators provided by HPGCL. The firm may give consent on
anyone from the panel. In case no consensus is arrived at between the parties, then aggrieved party
can approach the competent court of law for appointment of Sole Arbitrator. The award of the
Arbitrator shall be final and binding on the parties to this contract. Subject to aforementioned
provision, the provision of Arbitration & Conciliation Act, 1996 as amended from time to time and rules
made thereunder for the time being in force, shall apply to the Arbitration proceedings under the
clause.
It has been agreed between both the parties that the fee of the Arbitrator shall be governed by
Arbitration and Conciliation Act, 1996 as amend subject to condition that fees shall not exceed
Rs.10,00,000/LAWS GOVERNING CONTRACTS:
All contracts shall be governed by the laws of India for the time being in force.

22)

Irrespective of the place of delivery, place of performance or place of payment under a contract, the
contract shall be deemed to have been made at the place from which the acceptance of tender has
been issued.

23)

Jurisdiction of Courts: - The courts of the place from where the acceptance of tender has been issued
shall alone have exclusive jurisdiction to decide any dispute arising out of or in respect of the
contract.
RISK PURCHASE:
In the case of delay or non-supply of any or all the material on the dates they are due, the HPGCL will
have a right to refuse to accept such delayed supplies and to make the purchase of the material so
delayed or not supplied from any alternative source or through departmental manufacture, at the sole
risk and cost of the supplier. Any extra expenditure incurred on such purchase or departmental
manufacture shall be recoverable in full from the supplier in addition to the Corporation’s right or claim
for applicable liquidated damages or penalty.
Alternatively, the purchasing authority may cancel the purchase order due to non-fulfillment of its
terms(i.e. delivery) by the supplier and give notice for recovering the damages applicable to such
non-fulfillment under terms of the contract.
On completion of the supplies by the firm from whom risk purchase is effected, a full account,
including loss incurred on risk purchase, liquated and/or other damages claimable under the contract,
shall be payable by the supplier against whom the risk purchase is effected demanding legally that he
shall make good the amount within a reasonable period. Failing payment of the same by the supplier,
the amount of claim shall be recovered from his outstanding dues and/or security deposits against the
relevant contract or any other contract in operation, and for the balance, due process of law shall be
initiated.

24)

INTERCHANGEABILITY:
Supplier shall furnish interchangeability certificate, wherever applicable, that all the spares are
identical in construction, interchangeable and suitable to the equipment installed at site.
25) Replacement of Rejected Material:
(i)
Material found sub-standard or defective or not conforming to the prescribed specification in any
manner at consignee’s end shall not be accepted and intimation to this effect shall be given to the
supplier by the HPGCL. The supplier shall have to rectify or replace the defective / sub-standard
material forthwith, and in any case, within a period of 45 days from the date of original supply, failing
which the Corporation shall reserve the right to get the defect rectified at the supplier’s cost or to
dispose off such material and adjust the sale proceeds thereof, if any, against its claim on the supplier.
The supplier shall also be notified that all expenses involved in the replacement by way of handling,
transportation, storage, etc. shall be on his account.
(ii) In respect of the defective/sub standard supplies, the date on which such a supply is replaced shall
be reckoned as the effective date of delivery there against, and the delay shall be worked out
accordingly with reference to the date on which the supply was due as per the terms of contract, for the
purpose of determining penalties/ liquidate damages recoverable under clauses of the contract/PO.
Period of Guarantee / warrantee shall also be reckoned from the date of replacement.
(iii) The provisions of this condition (i) & (ii) shall apply mutatis mutandis to the material found-standard
or defective during the period of warranty.

26)

The material supplies should be declared as defective/ sub-standard, on the basis of detailed
inspection/ rejection report approved by the HPGCL.

27) SET OFF:
Any sum of money due and payable to the supplier under the contract (including security-deposit
returnable to the supplier) may be appropriated by the HPGCL and set-off against any claim of the
Corporation for the payment of a sum of money arising out of under that or any other contract
entered into by the supplier with the HPGCL.

Page 11 of 25

<!-- page 12 -->

28)

29)

PATENT RIGHT:
The supplier shall indemnify the Purchaser against all third-party claims of infringement of patent,
trademark or industrial design rights arising from use of the Goods supplied or any part thereof in
India.
PRESERVATION PROCEDURE:
Supplier shall submit the preservation procedure in detail provided by OEM for the storage or handling
of material in store.

30)

INTEREST: No interest, whatsoever on any account, shall be paid by HPGCL.

31)

DEVIATIONS: Any deviations from the specification mentioned in the NIT should be clearly indicated on
a separate sheet titled as STATEMENT OF DEVIATIONS.

32)

SUBLETTING AND ASSIGNMENT:
The Supplier shall not, sublet, transfer or assign the contract or any part thereof or interest therein or
advantage thereof in any part thereof in any manner whatsoever without prior consent of the
purchaser.
Note:1. Unless agreed otherwise the above terms and conditions of the contract will form the part of the
purchase order after finalizing the procurement proposal. The word Bidder where ever used above
shall be read as supplier. Above T&C are equally applicable in case of limited/ proprietary enquiry
as well. The non applicability/ modification in the aforesaid clauses if agreed shall be mentioned/
attached in/ with the purchase order specifically.
2. Purchasing authority shall put dated initials on each pages of the purchase order including the
above terms and conditions printed on both side of the paper.
3. Any other term not defined in instructions to the bidder or above terms and conditions should be
interpreted as defined in HPGCL Purchase Regulation “2015”.
4. The term “Bid” and “tender” and their derivatives (“Bidder/ Bidder” “Bidding/ Tendering”) are
synonymous. Singular also means plural.

33)

The validity of the tender/offer shall be for 120 days from the date of opening
of the price bid.

34) Quantity Variation : + 0%.
35) Terms and conditions of this NIT are governed by Works and Purchase Regulations of HPGCL, readily
available at website of HPGCL (hpgcl.org.in). Any amendment in ibid regulations shall automatically
apply to terms and conditions of the NIT.
XEN/Proc-I,
for CE/PTPS, PTPS,
HPGCL, Panipat.

Page 12 of 25

<!-- page 13 -->

ANNEXURE-B
SPECIFICATIONS/ SCHEDULE OF DEIVERY OF MATERIAL
(At least 15 days advance intimation shall be given by the Supplier to each consignee before the dispatch
of material failing which demurrage, warfage charges will be to the account of Supplier. Copies of such
intimation shall be sent to the purchaser also)
S. Code No.
Name of items
Qty. to be UOM Name of Consignee Due Date of Supply
No.
supplied
& Destination of
consignment
1
2
3
4
5
6
7
1
237341181 PUMP SPARES ITEM NAME: CARTRIDGE
2
EA
XEN/Stores, PTPS,
Within 04 months
000064
Panipat
from the date of
ASSEMBLY
issue of PO
EQUIPMENT: BOILER FEED PUMP
EQUIPMENT TYPE: WATER MAKE: WEIR
PUMPS LTD MODEL:FK6D30
ADDITIONAL INFORMATION: DRAWING
NUMBER:0-180-005-4193-RO

Note:
1. Bidder may check the sample from XEN/TG-V, PTPS, Panipat, for the above item before quoting their rates.
2. Quantity of the material can be reduced up to any extent at any stage before placement of PO at the sole discretion of HPGCL.
3. Item wise evaluation will be done for L-I and accordingly PO will be issued.

Signature & Stamp of Supplier

Additional Technical Specification Sheet
Material Description

: BFP Cartridge Assembly (FK6D30)

Model

: FK6D30

Design/Make

: Weir Pump Ltd.,/BHEL

Drawing No

: 0-180-005-4193-RO

Test: The following test will be carried out on the BFP cartridge before
assembly in the presence of purchasing agency/user: i.

BFP Cartridge Shaft Test: DP, UT & MPI.

ii.

On impellers: DP, UT, MPI & Balancing of Impellers.

iii.

Rotor Assembly: DP, UT, MPI & Balancing

iv.

Thrust Bearing: DP, UT test on pads of the bearing

v.

Journal Bearing: DP, UT test of the bearing

vi.

All the clearance and total float of the pump should be as per the design &
will be checked on physical inspection.

vii.

MOC sheet of the material used in BFP cartridge is attached below. The
T.C. of the material from NABL approved lab will be required & user can
also check the material at NABL approved lab in his presence.

viii.

The supplier will also meet the performance curve as designed by
OEM/OES.
After supply of the material at site, All the installation & commissioning
activities of BFP cartridge assembly will be carried out in the supervision
of supplier at free of cost.

Sr.
no.

1.
2.
3.
4.
5.
6.
7.
8.

Qty.
per
Set
1
2
1
2
1
1
1
1

Description
COUPLING PUMP HALF
OIL GUARD DE
INBOARD BRG. HOUSING
JOURNAL BRG. GLACIER
SLEEVE NUT RHDE SEAL
MECH. SEAL DE
SEAL HOUSING DE
BEARING BRACKET DE
Page 13 of 25

Material
STEEL
BS 1400 LB 2
ASTM A 216 Gr. WCA
TV 080 KSA 085 YM/MS
BS 2872 CA104
STEEL
BS 970 431 529 (ASTM:416)
ASIMA216 GRWCA

<!-- page 14 -->

9. 2
10. 2
11. 1
12. 2
13. 6
14. 6
15. 1
16. 1
17. 1
18. 1
19. 5
20. 5
21. 6
22. 6
23. 5
24. 4
25. 6
26. 5
27. 1
28. 1
29. 1
30. 1
31. 1
32. 1
33. 1
34. 1
35. 1
36. 16
37. 16
38. 16
39. 16
40. ---41. 1
42. 1
43. 1
44. 1
45. 1
46. 1

55. 1
56. 1
57. 3

‘O’ RING 0.139”x7.734” ID
‘O’ RING 0.139”x7.484” ID
WATER JACKET DE
‘O’ RING 0.139”x7.734” ID
BACK UP SEAL
‘O’ RING 0.275”x15.475” ID
SUCTION GUDE
PUMP CASING
PUMP SHAFT
1ST STAGE IMPLLER
IMPLLER WEAR RINGNECK
DIFFUSER WEAR RING
IMPLLER WEAR RINGEYE
PACKING RING
INTER STAGE DIFFUSER
INTER STAGE IMPLELLERS
IMPELLER KEY
ABUTMENT RING
LAST STAGE RINGSECTION
LAST STAGE IMPLLER
LAST STAGE DIFFUSER
SPRING DISC
BLANCE DRUM BUSH
BLANCE DRUM
DISCHARGE COVER
WATER JACKET NDE
BRG. BRACKET NDE
WASHER 42
CASING STUD M48
NUT M 42
STUD CAP
SET SCREW M10
MECHANCIAL SEAL NDE
SEAL HOUSING NDE
SLEEVE NUT L H NDE
OIL GUARD NDE
OIL SUMP COVER
GLACIERSPLIT FLOATING OIL
SEAL
GLACIER THRUST BRG.
THRUST COLLAR KEY
THRUST COLLAR NUT
‘O’ RING 0.139x7.234 ID
ENDCOVER NDEBRG HOUSING
BREATHER ¼” NPT
LOCK NUT LEFT HAND NDE
SEAL SLAVE
LOCK NUT LEFT HAND DE SEAL
SLAVE
OUT BOARD BRG HOSING
THRUST COLLER
OIL THROWER

58. 1
59. 1
60. 1
61. 1
62. 1
63. 1
64. 1
65. 1
66. 1
67. 1
68. 1
69. 2

2ND STAGE IMP. ASSLY.
3RD STAGE IMP. ASSLY.
4TH STAGE IMP. ASSLY.
5TH STAGE IMP. ASSLY.
1ST STAGE RING SECTON
2ND STAGE RING SECTON
3RD STAGE RING SECTON
4TH STAGE RING SECTON
‘O’ RING 0.275”X15.475”ID
‘O’ RING 0.275”X18.975” ID
COPPER COATED GASKET
‘O’ RING 0.139”x7.984” ID

47. 1
48. 1
49. 1
50. 1
51. -52. 2
53. 1
54. 1

Page 14 of 25

FLUORO CARBON
FLUORO CARBON
BS1504 425 C11(ASTM:A771-CA6NM)
FLUORO CARBON
PTFE
FLUORO CARBON
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 970 150 M19 (ASTM:A105- C0.25X)
BS 970 420 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11 (ASTM:A771- CA6NM)
FV 520 B
FV 520 B
FV 520 B
FV 520 B
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11 (ASTM:A771- CA6NM)
X 20 CR 13V
BS 970 316 S16
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11 (ASTM:A771- CA6NM)
FV 520 B
FV 520 B
BS 970 431 S 29 (AIST:416)
BS 970 150 M19
BS 1504 425 C11 (ASTM:A771- CA6NM)
ASTM A216GRWCA
AISI 321
ASME SA193GRB7
ASME SA193GRB7
MILD STEEL
STEEL
STEEL
BS 970 431 S 29 (AIST:416)
BS 2872 CA104
BS 1400 LB 2
IS 2062
BRONZE
TY 8159 2KP 2 KP
BS 970 431 IS29
BS 2872 CA104
FLUORO CARBON
DIN 1755 H II
STEEL
BS 2872 CA 104
BS 2872 CA 104
IS 210 GR 25
BS 970 817 M40/u
BS 970 431 S29 (ASTM: A276 TYPE
410HT
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11 (ASTM:A771- CA6NM)
BS 1504 425 C11
BS 1504 425 C11
BS 1504 425 C11
BS 1504 425 C11
BS 1504 425 C11
FLUORO CARBON
FLUORO CARBON
M.S
FLUORO CARBON

<!-- page 15 -->

ANNEXURE-C
STATEMENTS OF BIDDERS
1.

Name of Bidder

_______________________________

2.

Address of Head Office

_______________________________

3.

Correspondence Address

_______________________________
_______________________________

4.

Place of Business with Address

________________________________

5.

Legal status

________________________________

6.

PAN , TIN & GST Number of the Bidder (attached self attested photocopies)
PAN ______________________ TIN ________________________
GST No. _________________________.

7.

8.

9.

Bank Details (attached signed cancelled cheque):
i)

Bank Name & Address

ii)

Bank Account Number

iii)

Bank Branch Code

iv)

IFSC Code of Branch

v)

Nature of account (current/ saving/ OD/ CC)

Main lines of Business:
i)

____________________________ since______________

ii)

____________________________ since______________

iii)

____________________________ since______________

Past Experience:
Name of
Organization

10.

Period

Reference of
Contract

Order Value
contract wise

Any other:

Signature & Stamp of Bidder

Page 15 of 25

<!-- page 16 -->

Annexure-D
Benefits/ Concessions to the Haryana based Micro, Small and Medium Industrial
Enterprises in the State Public Procurement as under (G.O. No.-02.02.2016-41B11
(1) dated 20.10.2016):A. Concessions/ Benefits to Micro and Small Enterprises (MSEs):Sr.
No.
1

Area as part of
qualifying
requirements
Tender Fee

2

Earnest Money
Deposit (EMD)

3

Performance
Security

4

Turnover

5

Past
performance &
Experience

6

Purchase
Preference

Concessions/ benefits
allowed to MSEs

Eligibility

Exemption on the payment of
tender fee subjected to
fulfillment of conditions as per
eligibility.
Exemption on the payment of
Earnest Money Deposit (EMD)
subjected to fulfillment of
conditions as per eligibility.
90% concession on
performance security as
applicable to other Haryana
based firms subject to fulfillment
of condition as per eligibility.
a) Micro Enterprises:
Concession of 80% on
turnover condition imposed
as qualifying criteria.
b) Small Enterprises:
Concession of 70% on
turnover condition imposed
as qualifying criteria.
Exempted in respect of Past
Performance & Experience as
part of requirements of the
tender subject to fulfillment of
conditions as per eligibility.
50% of the total tendered
quantity providing quoting price
within band of L-1+15% by
bringing down their price to L-1
and subject to condition that it
agrees to fulfillment of other
terms & conditions of the tender
and further subject to fulfillment
to conditions as per eligibility.

Manufacturing Micro & Small Enterprises
(MSEs) (Including Khadi & village Industries/
Units)
who
have
filed
Entrepreneur
Memorandum in Haryana in respect of the
quoted items, participate directly in tender and
not through any intermediaries (their dealers/
agent/ distributors), will not subcontract to any
other firm and to carry the entire manufacturing
at their enterprise.
Concerned MSE will be required to submit the
copy of Entrepreneurs Memorandum in respect
of its category of Micro/ small issued to the firm
by the Industries Department Haryana as part
of Technical Bid.

Manufacturing Micro & Small Enterprises
(MSEs) (Including Khadi & village Industries/
Units)
who
have
filled
Entrepreneur
Memorandum in Haryana and further: a) Those MSEs have Quality Certification of
ISI/ ISO/ Ag Mark/ Quality Mark issued from
competent authority in State or Central
Govt. in respect of the items/ goods
mentioned in the tender.
OR/AND
b) Those who were registered with DGS&D/
NSI/ GOI Department/ State Govt.
Department/ GOI PSUs/ State Govt. PSUs
in respect of the item/ goods mentioned in
the tender.
The firm will be required to submit the detailed
information in respect of above through an
affidavit as per the format enclosed as
Annexure-D-1

B. Concessions/ benefits to Medium Enterprises:Sr.
No.
1

Area as part of
requirements
Past
Performance &
Experience

2

Purchase
Preference

Concessions benefits
allowed to MSEs
Exemption on requirements of
Past
Performance
&
Experience
as
per
the
requirements of the tender
subject to fulfillment of
conditions as per eligibility.
10% of the total tendered
quantity provided quoting
price within band of L-1+15%
by bringing down their price to
L-1 and subject to condition
that it agrees to fulfillment of
other terms & conditions of
the tender and further subject
to fulfillment of conditions as
per eligibility.

Eligibility
Manufacturing Medium Enterprises of the
state have filled Entrepreneur Memorandum
for quoted items in Haryana, participated
directly in tender and not through any
intermediaries
(their
dealers/
agents/
distributors), and will not subcontract to any
other firm and to carry the entire
manufacturing at their enterprises. This
concession will be applicable only for one
year to newly registered Medium Enterprises
or Medium Enterprises of state who are not
eligible in State Public Procurement due to
eligibility criteria of Past performance &
experience. The firm will be required to submit
the detailed information in respect to above
through an affidavit as per the format
enclosed at Annexure-D-2

Further, the benefit of discounting of 50% Haryana VAT revenue from the composite price bid for
the purpose of financial evaluation of the bids as per the policy guidelines issued vide GO No-2/
2010-41-B-II of dated 19.12.2011 will continued to be applicable to all Haryana billing firms
including MSMEs covered in the above policy scope.
The general guidelines for the apportionment of tendered quantity to the firms other than MSMEs,
MSEs and MEs will be as under:-

Page 16 of 25

<!-- page 17 -->

i)
ii)

iii)

iv)

v)

vi)

vii)

viii)

Purchase Preference to MSMEs will not be applicable if the tendered quantity is only
one.
Purchase preference for Medium Enterprises (MEs) will only be allowed on the
quantities in multiple of 10 say 10, 20, 30 and so on. The quantity less than 10 or in
between multiple of 10, 20, 30 will not be considered for Purchase Preference to MEs.
Negotiations will be held only with L1+5% firms. MSMEs as per above instructions
within the price range of L1+15% will be counter offered to match the finally arrived L1
rate. In case MSMEs within L1+15% range refuse to match the finally arrived L1 rate
then the entire 60% (50% for MSEs and 10% for MEs) of Purchase Preference will be
transferred to L1+5% category firms.
In case, no micro & Small Enterprises (MSEs) and Medium Enterprises (MEs) as per
eligibility criteria specified in the above instructions are within L1+15% range, the entire
100% tendered quantity will be distributed as per the existing guidelines.
In case there are no Micro & Small Enterprises (MSEs) within L1+15% range, the
Purchase Preference Quota of 50% of MSEs will stand transferred to open category
making it from 40% to 90%
In case there are no Medium Enterprises (MEs) within L1+15% range, the Purchase
Preference Quota of 10% of MEs will stand transferred to open category making it from
40% to 50%
In case no MSMEs, within L1+5% range and there is one MSE & one ME in L1+15%
range and further agree to match the arrived L-1 rate. The quantity will be distribution
will be upto 40% for firm other then MSME, upto 50% for MSE and upto 10% for ME
and so on.
In case there are MSMEs (both or either MSEs) within L1-5% range and there are
MSEs & MEs in L1+15% range. Negotiations will be carried out with all firms within
L1+5% as per existing guidelines to arrive at finally arrived L1 rate. The finally arrived
firm can be any other such a situation; apportionment will be done as per the existing
instructions of ratio of 70:30 or 50:25:25 & so on. Thereafter, offer will be given to MSE
and MEs within L1-15% range to match the finally arrived L1 rate and if they agree to
match the arrived L-1 rate, the apportionment of quantity will have many scenarios of
quantity apportionment may be as per Annexure-III enclosed with this notification.
However, there can be many more scenarios depending upon the number of MSMEs
within price range of L1+5% and L1+15%.
The above instructions will supersede the instructions as issued vide industries
& Commerce Department Haryana Order No. 2/2/2010-41-IB-II of dated 24.03.2015
related to concessions/ benefits to Haryana based Micro & Small Enterprises (MSEs)
including Khadi & Village Industrial Units.

Page 17 of 25

<!-- page 18 -->

Annexure-D-1
(Seeking benefits/ concessions in past performance/ Experience & Purchase Preference
by Haryana based manufacturing Micro & Small Enterprises (MSEs) in the state Public
Procurement)
(On non Judicial Stamp paper of Rs. 10/-)
I ________________________ S/o ________________________ aged __________residing at
______________________________Proprietor/ Partner/ Director of M/s __________________
___________________________ do hereby solemnly affirm and declare that:1. My/ our above noted enterprise M/s ___________________________ (name & Address)
___________________ has been issued manufacturing Entrepreneurs Memorandum in
Haryana by the District Industries Center _________________________________ under
acknowledgement No. ___________________ of dated ___________ (Self certified copy
of the same is attached as Annexure-A with this affidavit) and has been issued for
manufacture of the following items in category Micro/ Small Enterprise (please tick the
either) as under:i)
_________________________
ii)
_________________________
iii)
_________________________
2. That the quoted item(s) in the tender_____________________ is one (or more) of the
item for which my/ our above noted enterprise has been issued. Manufacturing
Entrepreneurs Memorandum by the Industry Department Haryana as per details at para
1 above.
3. That my/ our above mentioned manufacturing Micro/ Small Enterprises fulfills either or
both of the below mentioned eligibility criteria:i)
That my/our above mentioned enterprise has been issued quality certification of
ISI Mark/ ISO/ Ag. Mark/ any other quality mark_____________________(please
tick either of the option) by _______________________________(name of GOI/
State Govt. Agency/ Institution authorized by GOI/ State Govt.) on____________
and the same is valid from_____________ to _____________ in respect of item/
good (give name of item/ good) _____________________________ mentioned
in the tender (Self Certified Copy of the relevant certificate is attached as
Annexure ‘A’ with this affidavit).
ii)
That my/ our above mentioned enterprises has been registered with DGS&D,
GOI/ NSIC/ Govt. of India Departments/ State Govt. Department/ Govt. of India
Public Sector Undertaking (PSUs) or State Government Public Sector
Undertakings (PSUs) (Please tick one of the option as above) in respect of Name
of item/ goods/ work/ services ___________________ (Name) as mentioned in
the tender for the corresponding period of time of this tender. A self Certified
Copy of the same is attached as Annexure ‘B’ with this affidavit.
4. That in case the purchase order of the quoted item is issued to me/ us, it will not be
outsourced or subcontracted to any other firm and the entire manufacturing of the order
item shall be done In-house by our Enterprises based in Haryana (address mentioned as
at Sr. No.1) Further, the billing will be done from Haryana.

Dated:

DEPONENT

VERIFICATION:
Verified that the contents of para no. 1 to 4 of the above are true and correct to my
knowledge as per the official record and nothing has been concealed therein.

Dated:

DEPONENT

Page 18 of 25

<!-- page 19 -->

Annexure-D-2
(For seeking the benefits/ concessions by Haryana based manufacturing Medium
Enterprises in Past Performance/ Experience & Purchase Preference in the state Public
Procurement)
(On non Judicial Stamp paper of Rs. 10/-)
I ________________________ S/o ______________________ aged ____________ residing at
______________________________Proprietor / Partner / Director of M/s__________________
___________________________ do hereby solemnly affirm and declare that:1. M/s / our above noted enterprise M/s __________________ (name & Complete Address)
___________________ has been issued manufacturing Entrepreneurs Memorandum in
Haryana by the District Industries Center _________________________________ under
acknowledgement No. ____________________ of dated __________ (Self certified copy
of the same is attached as Annexure-A with this affidavit) and has been issued for
manufacture of the following items in category Medium Enterprise as under:i)
______________
ii)
______________
iii)
______________
iv)
______________
2. That my/ our above mentioned manufacturing Medium Enterprises meat all the remaining
terms & conditions of the tender except Past Performance/ Past Experience.
3. That my first Purchase Order under this benefit / concession was issued by State
Government Department/ State Government Agency (name of Deptt./ Agency)
___________________ vide P.O. No. ____________________ of dated ____________
for the supply of ______________________ (name of the item/ good/ works/ services)
was successfully complied by above mentioned Enterprises. A self certified copy of the
same is attached as Annexure-‘B’ with this affidavit.
4. That in case the Purchase Order of the quoted item is issued to me/ us, it will not be
outsourced or subcontracted to any other firm and the entire manufacturing of the order
item shall be done in-house by our enterprise based in Haryana, (address mentioned as
at Sr. No.1).
5. That we agree to the condition that this benefit / concession to the Medium Enterprise is
valid for one year from the date of getting the first supply order under State Public
Procurement.
6. That the billing will be done from Haryana.

Dated:

DEPONENT

VERIFICATION:
Verified that the contents of para no. 1 to 6 of the above are true and correct to my
knowledge as per the official record and nothing has been concealed there in.

Dated:

DEPONENT

Page 19 of 25

<!-- page 20 -->

Annexure-E
Instructions to bidders on Electronic Tendering System

1.

2.

3

4

These conditions will over-rule the conditions stated in the tender
documents, wherever relevant and applicable.
Registration of bidders on e-Procurement Portal:All the bidders intending to participate in the tenders processed online are
required to get registered on the centralized e-Procurement Portal i.e.
https://etenders.hry.nic.in Please visit the website for more details.
Obtaining a Digital Certificate:
2.1
The Bids submitted online should be encrypted and signed electronically
with a Digital Certificate to establish the identity of the bidder bidding
online. These Digital Certificates are issued by an Approved Certifying
Authority, by the Controller of Certifying Authorities, Government of India.
2.2
A Digital Certificate is issued upon receipt of mandatory identity (i.e.
Applicant’s PAN Card) and Address proofs and verification form duly
attested by the Bank Manager/ Post Master/ Gazetted Officer. Only upon
the receipt of the required documents, a digital certificate can be issued.
For more details please visit the website – https://etenders.hry.nic.in.
2.3
The bidders may obtain Class-II or III digital signature certificate from any
Certifying Authority or Sub-certifying Authority authorized by the
Controller of Certifying Authorities.
2.4
Bid for a particular tender must be submitted online using the digital
certificate (Encryption & Signing), which is used to encrypt the data and
sign the hash during the stage of bid preparation & hash submission. In
case, during the process of a particular tender, the user loses his digital
certificate (due to virus attack, hardware problem, operating system or
any other problem) he will not be able to submit the bid online. Hence, the
users are advised to keep a backup of the certificate and also keep the
copies at safe place under proper security (for its use in case of
emergencies).
2.5
In case of online tendering, if the digital certificate issued to the
authorized user of a firm is used for signing and submitting a bid, it will be
considered equivalent to a no-objection certificate/ power of attorney/
lawful authorization to that User. The firm has to authorize a specific
individual through an authorization certificate signed by all partners to use
the digital certificate as per Indian Information Technology Act, 2000.
Unless the certificates are revoked, it will be assumed to represent
adequate authority of the user to bid on behalf of the firm in the
department tenders as per Information Technology Act, 2000. The digital
signature of this authorized user will be binding on the firm.
2.6
In case of any change in the authorization, it shall be the responsibility of
management/ partners of the firm to inform the certifying authority about
the change and to obtain the digital signatures of the new person/ user on
behalf of the firm/ company. The procedure for application of a digital
certificate however will remain the same for the new user.
2.7
The same procedure holds true for the authorized users in a Private/
Public limited Company. In this case, the authorization certificate will have
to be signed by the directors of the company.
Opening of an Electronic Payment Account:
Tender document can be downloaded online. Bidders are required to pay the
tender documents fees online using the electronic payments gateway service.
For online payments guidelines, please refer to the Home page of the
e-tendering Portal https://etenders.hry.nic.in
Pre-requisites for online bidding:
In order to bid online on the portal https://etenders.hry.nic.in , the user machine
must be updated with the latest Java. The link for downloading latest java applet
is available on the Home page of the e-tendering Portal.

Page 20 of 25

<!-- page 21 -->

5

6

7

8

Online Viewing of Detailed Notice Inviting Tenders:
The bidders can view the detailed N.I.T and the time schedule (Key Dates) for all
the tenders floated through the single portal e-Procurement system on the Home
Page at: https://etenders.hry.nic.in
Download of Tender Documents:
The tender documents can be downloaded free of cost from the e-Procurement
portal https://etenders.hry.nic.in
Key Dates:
The bidders are strictly advised to follow dates and times as indicated in the
online Notice Inviting Tenders. The date and time shall be binding on all bidders.
All online activities are time tracked and the system enforces time locks that
ensure that no activity or transaction can take place outside the start and end
dates and the time of the stage as defined in the online Notice Inviting Tenders.
Bid Preparation (Technical & Financial) Online/ offline Payment of Tender
Document Fee, eService fee, EMD fees and Submission of Bid Seal (Hash)
of online Bids:
8.1
The online payment for Tender document fee, e-Service Fee & EMD can
be done using the secure electronic payment gateway. The Payment for
Tender Document Fee and eService Fee can be made by eligible bidders/
contractors online directly through Debit Cards & Internet Banking
Accounts and the Payment for EMD can be made online directly through
RTGS/ NEFT.
The secure electronic payments gateway is an online interface between
contractors and Debit card/ online payment authorization networks.
8.2
The bidders shall upload their technical offer containing documents,
qualifying criteria, technical specification, schedule of deliveries, and all
other terms and conditions except the rates (price bid).
The bidders shall quote the prices in price bid format only.
8.3
Submission of bids will be preceded by submission of the digitally signed
& sealed bid (Hash) as stated in the time schedule (Key Dates) of the
Tender.
NOTE:(A)
If bidder fails to complete the Online Bid Submission stage on the stipulated
date and time. His/her bid will be considered as bid not submitted, and
hence not appear during tender opening stage.
(B)
Bidders participating in online tenders shall check the validity of his/her
Digital Signature Certificate before participating in the online Tenders at the
portal https://etenders.hry.nic.in.
(C)
For any help, please refer to the ‘Home Page’ of the e-Procurement website
at https://etenders.hry.nic.in and click on the available link ‘Help for
Contractors’ to see Special Instructions to the Contractors/Bidders for the
e-submission of the bids online through this e-Procurement Portal.

Page 21 of 25

<!-- page 22 -->

Annexure-F
GST DOCUMENTS & COMPLIANCES TO BE MADE BY THE SUPPLIER
1. Supplier has to provide valid GST registration certificate, as on date, of place of supply.
2. Supplier will have to submit following undertaking on its letter head:
(i)
That GST Registration Certificate of place of supply i.e. GST No.,……………………is
valid as on date.
(ii)
That no default has ever been made by supplier in filing the various GST returns and
deposit of GST dues with the department.
(iii)
That Supplier is having multiple registrations under GST i.e., GST No….………, GST
No……………and no default has ever been made by supplier in filing the various
GST returns and deposit of GST dues with the department for above GST Numbers.
If a default is found at a later stage under a GST number even if the GST number
pertains to some other state, then it will be construed as misrepresentation of facts
and will make the supplier ineligible to participate in further tenders/enquiries along
with other penal/legal actions.
(iv)
The Goods & Service Tax, if extra, shall be paid as per actual within the delivery
period of production of following certificate: a.) Certified that transactions on which tax
has been claimed will be included in the return to be submitted to the GST authorities
for assessment of GST and the amount claimed from the HPGCL shall be paid to the
GST authorities. b.) Certified that the goods on which GST has been charged have
not been exempted from GST Act or rules made there under. The charges on account
of GST on these goods are correct under the provisions of the relevant Act or rules
made there under. C.) Certified that we shall indemnify to HPGCL in case it is found
at a later stage that the incorrect payment has been recovered on account of GST by
us. d.) Certified that we are registered as dealer and our Haryana/CST no. is ----------------------. Our GST No. is ………………….. (Signature of Supplier).
3. A CA certificate regarding validity of GST Registration will be submitted along with other documents of the
PO.
4. Supplier will submit copies of GSTR1 and GSTR3B/challans as evidence to deposit of GST with
certifications that GST collected from HPGCL (to be specified in exact rupees), has been paid to
Government vide this challan (specifying the challan number and date of deposit) and returns filed
(date of filing of return) includes the transaction of supply of Good or/and services to HPGCL.
5. Supplier will inform immediately the HPGCL about initiation of any proceeding (if any) against him
under the GST laws which may result in suspension or cancellation of GST number of the
Supplier/Vendor.
6. Undertaking to indemnify the HPGCL in case of any financial implication on HPGCL due to noncompliance of prescribed obligation under the GST law on part of the Supplier/vendor.
7. Copies of GSTR 1, GSTR 2A and GSTR 3B along with copies of invoices raised to HPGCL, duly
reconciled with three returns to be submitted before release of the security.
8. Receipt of Invoice:
i)
Supplier is to verify that the invoice is in Performa as specified under GST law (Section 31 to 34
of CGST Act read with rules 46 to 55A of the CGST rules deal with the Tax invoice, Credit notes
and debit notes) with correct GST number of HPGCL so that no difficulty is faced by HPGCL
while claiming Input Tax Credit of GST due to incorrect GST number and also to reconcile the
GST number and address of Supplier as per invoice with the GST number & address given in
tender documents/enquiry submitted by vendor and submit the duly verified invoice to accounts
wing.
ii)
After the implementation of the invoice w.e.f 01 Oct 2020 generation of e-invoice from common
e-invoice portal for B2B supplies by person having aggregate annual turnover of more than 500
Crs has been made compulsory and w.e.f.01 Jan 2021 Generation of e-invoice for GST
supplies by the person having aggregate turnover of more than Rs. 100 Crs. Has been made
compulsory and w.e.f. 01.04.2021 generation of e-invoice for GST supplies by the person
having aggregate turnover of more than Rs. 5 Crs. Is proposed to made compulsory. The
supplier has to furnish e-invoice containing the invoice reference number (IRN) and QR code. It
is worthwhile to note that any tax invoice including tax credit/ Debit note issued by such notified
person for B2B suppliers without following the e-invoicing procedure shall not be treated as a
valid document.
iii)
Supplier who are not generating e-invoice has to give an undertaking from the
following
format:
We M/s. ………………………….having PAN……………………………………..and GSTIN
Registration Number…………………………… hereby undertake that our Aggregate Turnover
(as per Section 2(6) of Central Goods and Services Tax Act, 2017) for FY 2019-20 does not
exceed the prescribed threshold (as on the date of this declaration) for generation a unique
Invoice Registration Number (IRN) and QR code as per the provisions of Central Goods and
Services Tax Act, 2017 and rules thereunder (“GST Law”). Further, we also undertake that if the
aggregate turnover of M/s………………………………………exceeds the current threshold or
revised threshold notified by Government of India at any future date, then we shall issue invoice
and credit note in compliance with the required provisions of GST Law. In case of any queries
from
the
any
state
or
Centre
Goods
and
Services
Tax
authorities,
M/s………………………………………..will be solely responsible.
Yours Truly,
For M/s…………………………………

9.

Authorized Signatory Name:
Designation:
Regarding EMD & BG:i)
EMD and Securities/Bank Guarantees taken by HPGCL against the Purchase Order may
be refunded only after payment of GST by Supplier/Vendor which was charged from
HPGCL.
ii)
In case of any issue arises w.r.t failure by the firm in GST compliances, all future
payments to be put on hold.
XEN/Proc-I
For SE/MM & Stores,
PTPS,HPGCL,Panipat

Page 22 of 25

<!-- page 23 -->

Annexure-G

Documents to be uploaded with the Tender Documents

NIT No.: PTP/POM-100990
Dated:10.08.2026
Sl.
Enclosures/ Documents required as per NIT
No.

1
2(a)
2(b)
2(c)
3(a)

3(b)

Cost of Tender Documents + e-Service Fees: Rs.2,360.00/(Exemption in Tender document fee is applicable only for
MSME, Haryana for manufacturer of similar item )
Earnest Money Deposit (EMD) (EMD amount: Rs.5,31,000/-)
EMD Exemption Certificate attached (If applicable, i.e., MSME,
Haryana/NSIC Certificate)
In case of availing exemption in EMD on account of MSME,
Haryana, Annexure-D1&D2 is applicable,
The bidder should be Original Equipment Manufacturer/
Supplier (OEM/OES) and must have successfully
executed purchase order of supplying same/similar item(s)
in HPGCL/NTPC/ any State Electricity Board/any Public
Sector Undertaking/any Corporation/Central Govt./ State
Government
Undertaking/Semi
Govt.
or
any
Thermal/Hydel Power Plant during last 07 years ending
July-2026 along with copy of satisfactory performance
certificate/repeat order from the same organization.
Proof that the bidder has executed at a Single order of the
value not less than Rs. 2.12 Crore (Uploaded) along with

Bidder Response
(Appropriate
option to be
ticked & upload
on e-portal)
Yes/ No
Yes/No

Yes/No
Yes/No
Yes/ No

Yes/ No

performance certificate.

3(c)

Proof that the bidder has executed Two orders, each having
value not less than Rs. 1.33 Crore each (Uploaded)
3(d) Proof that the bidder has executed Three orders, each having
value not less than Rs 1.06 Crore each (Uploaded)
4
Certificate that firm has not been black listed by any party/
organization. (Uploaded)
5
Copy of PAN No. (Uploaded)

Yes/ No

6

Copy of GST Registration No. (Uploaded)

Yes/ No
Yes/ No

7
8
9

GST documents and compliances of GST as per Annexure-F
(Uploaded)
Bidder will have to submit undertaking regarding GST on its
letter Head as per PQR Clause 1(f) (Uploaded)
Duly filled and signed Statement of Bidder as per Annexure-C
Scan copy of duly signed tender Document
Certificate of Testing facilities on Firm's letter head, attached.
(Uploaded)
Undertaking for acceptance of all terms & conditions of e-NIT.
(Uploaded)
Technical Specifications, Quantity & Delivery Schedule Sheet
Duly Stamped & Signed as per annexure-B (Uploaded)

10
11

Page 23 of 25

Yes/ No
Yes/ No
Yes/ No

Yes/ No
Yes/ No
Yes/ No
Yes/ No
Yes / No
Yes / No

<!-- page 24 -->

Annexure-H
PBG FORMAT

Page 24 of 25

<!-- page 25 -->

Page 25 of 25
