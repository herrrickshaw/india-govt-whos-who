---
doc_id: "abdf11edadceaeae"
source_url: "https://hpa.haryanapolice.gov.in/Documents/StandingOrder/105.pdf"
ministry: "Haryana Police Academy, Haryana"
title: "View"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b92c6552aa39d88e"
---

<!-- page 1 -->

'i'
1

i
,

t

\I
I

iil lil[(]t][
l!1 ny4ra_Strrls
i
i i li riC i'oit Gtil\uIlAL,s S'I'ANDING OIU)tiIt
N{J.a6n000,i
I'ri-rrrullio, of rhc corLstablcs ro Lrre rank of IIead corwtable' ilii"lt,, '
;iller complct"ion of 16 yearu regular qualifying gervice. ,, . ,;ii ,,
'I1re objcclivc of

this Standing Orrler is to rcmove

,.,,,i: i'i' ( 'rrir:li;ri;lcll riI ;r rvclftrre rncasul.c who luvc

ji

servcd tho Depa rlment

I

''', ', ilJr t iclr;l ,rrrprrlatigp but lrarrc trot bccn givep prolrotiotr.

'lhc Ilarvarra Coycnrruunt

''il '

hirs alao lakcn n dschiorr convcy-ed

iiir: lr;ircr i'Jo' 30/l/2(X)0-6ll(il dalcd 7-l-2000 to givc prornotio*
i,;r,i r- r,irrirlcrcrl l6 1,cars of service. 'I'he cligibiliry

I

criter:a of suclr pncrn otiong will be
Li

l:t.,".,i:

I

I. 'l he

lo sucl Con ritabl

ccolllc

cligible for p r0rno tion trll

corrrillclir;n oI l6 ,i,cal.s <;l'r.cg rlar rpralilyirrg scrvicc orr t.hc basia

o
,j.l

,.

.i.:

2, ()nly [hcne Conolablcl; rviil bc connirlcretl Ib

.

,i.

oI llxcrupteu IIcnd Ltorrntablcs who'I\rl{ll thc

,,!

.i

I ",. ],:
,

i'.::

,i) wirono irr(cgriti, hag, nor. bec'n tJoubrcd tluring lart l0 l,caro

.

i;

,i

SCI VICC.

tr) 'l'hc Cotrstablcs has not br;eu awarclecl arly lnaJor
dur-ittg, tlte lasl lrvo year-s

proceeclingp.ithe
,

cc,lrrplctiorr o{'sLrlccrl ycars oI' rycrryicc,

I

,i l

,:

j;

dn

l

errt of cclt.ru*:j,
dttr ing

lhc six nlonrlls irrrrnediatcly procecdhrg the

qlalc i:,o
,,:.

.cr;n4rletion of si.xtccn ycars of'scrvice.

,

!..,

,,

.l

scnrtiny of service records woulcl be cnrried ou[ lwicc in yenr in

:

;

.,

ir

rrrurrtlr of l)cccrrrbcr and,"Jurrc svcry ycar by, Supcriltcntlcntd

"
.i.
:..

l'}rllicc/Cltlttttttrtttdartl.g so as lo lirralinc and appruve lho prouroliollr

'i.;ir, -.

1'.4;, ,r;i

:ljii i

I;r{c.st lr1' 10'h Jauuary rrnd l0d' Jul.y of erery year.

I

4. 'l'hc Ilc;rtl Corrslablcs su prontulctl slurll irnrncrliatcly bo dcpulccl lo
ttrrtlcrgo :r tr;rinirrg colll',lo Ibr,z rrrcrutlrs nt P'I'Cr lvlntlfiuban [lro,

s,yllrliu:r ltr rvhich str:rll hc plcscribcrt lr-y l)ircclrr/lr'l'c. J'he
0lrjr:t;tive oI lrairrirrg rvill hc lu 1nc;rare euch corrstafics to updcd;uke
I

ll

irrvcr:(iLr,lliorr rvor

k rc(ilrirc(l lirr I Icrtt (hnslalile, [irch ruclr

l

<!-- page 2 -->

\_/

ii

c.tr.:rnlr(cc I Icad C<.rrrrtaltlo tvould bc rcqtrirctl lo I)as$ tlti'l coursc

rvitlrirr llro pt'obatiort pr;riotl u'lriclr will trc ottc ycnr.

5. Ilxcrnplc' Iicad Cortstablcs lo pronrolerl shJll excrcisc all powmr
of llcrd Constablcs ao pcr Police Itulls and odrer Acts/Itulea.

l

6. 'i'hc lrtt-rtttoliotr of llcad Corrstrll.rhx agairrrt tfio regulnr snttotioncd
posls of llcarl Corulables will conLinue to be madc as pcr P.I14'

I3.7 arrtl tlris prolnolioliwilluot allccl tltc satttc irt any wity'i'

' ;'ii

;

t'

7. The poot so upgrn,lc,l'urtler this policy will be lreated -ur p"rs6nul
poots md slrnll nutonrntioally be ilrorooscd '-or dccroosod
tl

upgrndulir.rrr or rctluctiou accorrlirg tu dre rctluirctttuttl uYsry ycar,

B. 'l hc c.rinting scltutrtc crl' pt'ontotiolt of' Cottslablcs as UCC slull

r

slarrrl wi{lrrtratvl ltcrtccRnth., Ilo}vcvcr, all tltorc rvlto ltavc ah'eatly

llccn pronroterl slrrll ltot lle rcverlcd

,it,
'

9. Such Iixcnrptcc Constnblcs rvlto fullil rcquirite cortditions undcr
rtrlc 13.7 r.rf I'l'l{ 193,1 rvill also bc errdrlcd to appcarlbrB'1 lcst"r
IU.Iixcnrptcu.llcntl Cottslaltlcs itt ordcr of rhcil rctriorit-y will bc '
clrlitlctt lo ncleclion irr loler school course as per lhclr quota fi{1,.!,

:

:

I LSuch li,xctrtptcr: Cotttrtablct, tvlto ltavc ac(luirad clisthction irs
$lrorlsnl.tn,cr.rnsistcnl riutsl.andirrg;rcr'furruance in jot/attainirrg ould

, ..;

or Silvcr Merlrl irr Alt Lxlir l)olicc Gutre/Duty MceUNaliotlal
pcr lhcir quqle

CinrrrcR rvill lru crrtillcd Ibr lorvcr sohool.

t
tJ),...'

.l

\

i i.rotl.

Ilire c(o

ff;;

/-\'L,

llatYnrta. I \ \'

En

6st" No. €69 - 5cl0g / Elll)-1

dated A-g-A00

r\ oop y 1s lo rulordod ls tha follo rd.ng fo r ln fb
trl d otrtct ampll rfl co t1,.
lnqoctor Cmortrl o f Poltco, C. I. D. Harycns, p mclkulo,
I n sp Ector Gm mqI , tl nrym s flrm sd PoLlc6r I'l ocltubql.
3,
Inqec'toro Gfisrql of Follco &nbqlsr 8ohLq( Gurgan
c^tlc-t
tqP I f CII CQ a'r.tl t.;
1n
Rqr
In qlecltor G11rertil
shllu I a.
Poll cR T sl ocornmunl c atl on ( llr.
D1 roctoro/ 5. C' fl.B. & F. 5. L
5.
Ilsryar E, I'1 Edfutr 8r. g- &01
6.
All Olobr{ct Supertn bm clrr ba" o fl Pslice ln llor Ifla.
/\11 Commrndcnt0 o f l1A0 B atLotrlono ln t{BryEn q
7
Superlnbenclmt of PollcB, Commm6, Norrsl.
B
5u p orlntcndcnL of Pollco
l'l u,llt,l oy o, Ilnr y fi srr f\ab a,l. o G dr [t.
9.
I ti.
tu orlrtLrri dqrb o I Pollco T0.J. tr-slnmunt oablon rlloryrn arP mctkU
:

,

ffi

,1'

iL
/ /','
,l

{-l;'

fb r

P. Sln
0.I.G.
rgr

C,li

rncto r G En ar ru o
ll,qty

,:

'i.

,l

I
