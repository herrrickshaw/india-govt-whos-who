---
doc_id: "cccd3df9cf215a24"
source_url: "https://highereduhry.ac.in/Notices/Notice202609251714497681.pdf"
ministry: "Higher Education Department, Haryana"
title: "Guidelines for CM Budget Announcement 35(xiv) 2026-27 - Haryana Patent Support, commercialization and Innovation faciliation policy (HPSCIFP), 2026-27"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "950a4583dc92dbcc"
---

<!-- page 1 -->

From

Additional Chief Secretary to Government of Haryarra,
Higher Education Department, Chandigarh
To

1. The Vice Chancellors,
All State Universities under the ambit of Higher Education Depdrtment2. Director General Department of Industries & Commerce & MSME; lst Floor,
SectorlT, Chandigarh

3. Director (Admin), Department of Information Technology Electronics &
Communication Haryana, 9th Floor, Haryana Civil Secretariat, Chandigarh-

4. The Principals

1

lri

All Govt./Govt. Aided Colleges situated in the State of Haryana.
Memo No: KW 1.8188-2026-UNP (3)
Dated, Panchkula, the 7f- ool-' ?p2-f
Subject:

Guidelines for CM Budget Announcement 35(xiv) 2026-27
Haryana Patent Support, Commercialization and Innovation
Facilitation Policy (HPSCIFP), 2026-27
,.*,rrrrrJrJr

Kindly refer to the subject cited above.

It is intimated that to promote innovation among students technical
institutions and Universities, the State Government has introduced a scheme namely
o'Haiyana Patent Support, Commercialization and Innovation Facilitation Policy

(HPSCIFP), 2026-27". The purpose of establishment of this announcement is to
promote innovation among students, technical institutions and Universities, 100
percent reimbursement of patent registration fees up to Rs. 50000/-

A copy of the guidelines regarding the scheme is hereby enclosed for
necessary action. These issues with the concurence of the competent authority.

Yg-

t -LINP

for Additional Chief Secretary to Govt. of Haryana,.
Higher Education Department, Chandigar[Enddt. No. Even
Dated,.Panchkula, the
A copy of the above is forwarded to the following for information and necessary
action:-

1. The Director General Technical Education Haryana, Panchkula with the request
to circulate these Guidelines among their HEIs

2. PS/OSD/CM for information of OSD/CM.
3. PS/HEM for information of HEM.

4. PSiChairperson, HSHEC forinformation and taking necessary action and

requested to consider the offline proposal till online portal is prepared being a

NodalAgency.

5. PS/ACSHE for information of W/ACSHE.
6. PS/DGHE for information of WDGHE.

7. Superintendent Budget and Planning (HQ) with the request to make necessary
arrangement for budget of Rs. I 1.00 Cr. for FY -2026-27 and make arrangement
for opening Head for the same, so that scheme may be operationalized.
8. AD-IT for uploading the notification on the Higher Education portal.
9. Superintendent College-1, College-IV Branch, Cordination at H.Q.

-LINP
for Additional Chief Secretary to Govt. of Haryana,
Hi gher Education Department, Chandig
S

a*,-

<!-- page 2 -->

HARYANA PATENT SUPPORT, COMMERCIALIZATION AND INNOVATION FACILITATION
POLICY (HPSCIFP)
Government of Haryana
Department of Higher Education
2026–27
Title of the Scheme
The Scheme shall be called the “Haryana Patent Support, Commercialization and Innovation
Facilitation Policy (HPSCIFP), 2026–27”
The Scheme is introduced in pursuance of the Budget Announcement for FY 2026–27 under
Para 35 (XIV) of the Budget Speech of Government of Haryana:
“To promote innovation among students of technical institutions and universities, 100
percent reimbursement of patent registration fees up to Rs. 50,000 shall be provided.”
Budget Announcement
FY 2026-27, para of 35 (XIV)
1. PREAMBLE
The Government of Haryana recognizes Intellectual Property Rights (IPR), innovation,
research commercialization and technology transfer as essential drivers of knowledge
economy development, entrepreneurship, industrial competitiveness and socio-economic
growth.
Higher Educational Institutions (HEIs), universities, incubation centres, start-ups,
researchers and innovators in Haryana are increasingly generating technologies, products,
software, designs and research outputs with strong societal and commercial potential.
However, lack of awareness, procedural complexity, limited professional support, weak
commercialization systems and financial barriers often restrict innovators from protecting
and utilizing their intellectual property.
The Government of Haryana therefore introduces the:
“Haryana Patent Support, Commercialization and Innovation Facilitation Policy (HPSCIFP)”
The Policy has been prepared after considering National IPR Policy, NEP 2020, Budget
Announcement FY 2026–27 and best practices adopted by State Universities.
The Policy seeks to promote a “Creative Haryana; Innovative Haryana” ecosystem through
innovation, intellectual property generation, commercialization, startup development and
knowledge-based economic growth.
1

<!-- page 3 -->

2. VISION
To transform Haryana into a leading innovation-driven State by building a strong intellectual
property ecosystem that supports invention, protection, commercialization and societal
deployment of technologies.
3. OBJECTIVES
The key objectives of the Policy are:
1.

To promote a robust intellectual property, innovation and commercialization ecosystem and
position Haryana as a leading innovation-driven State.

2.

To provide financial and institutional support for patent filing, examination, grant, technology
transfer and commercialization.

3.

To encourage students, faculty, researchers, startups, MSMEs and innovators to protect,
develop and commercialize innovative technologies and research outcomes.

4.

To strengthen industry-academia collaboration, innovation-led entrepreneurship, startup
creation and incubation support.

5.

To establish and strengthen Institutional IPR Cells, Technology Transfer Offices, Innovation
Facilitation Centres and digital innovation platforms.

6.

To promote awareness, capacity building, patent analytics, IP management and
commercialization support across Higher Educational Institutions.

7.

To support women innovators, rural innovators, grassroots innovations and priority sectors
including AI, green technologies, healthcare and agriculture.

4. NODAL AGENCY
The Policy shall be implemented by Haryana State Higher Education Council (HSHEC) in
coordination with the Department of Higher Education
HSHEC may issue operational guidelines, standard operating procedures (SOPs), application
formats and implementation instructions from time to time and shall coordinate with
 State Universities
 Government Colleges
 Incubation Centres
 IPR Cells
 Innovation and Start-up Centres




Industry and Corporate Partners
MSME Support Institutions
Research and Development Organizations

5. APPLICABILITY
The Policy shall apply to:

2

<!-- page 4 -->

A. Institutional Beneficiaries
1. Higher Educational Institutions (HEIs), including Universities and Colleges, located in
Haryana
2. State-funded incubation centres
3. Technology Transfer Offices (TTOs)
B. Individual Beneficiaries
1.
2.
3.
4.
5.
6.
7.
8.
9.

Faculty members of Govt. recognized Institutions of Haryana
Researchers
Students
Start-ups
MSMEs
Independent inventors residing in Haryana
Alumni innovators associated with Haryana institutions
Rural and grassroots innovators
Women innovators

Financial Structure
Tentative Budget required (per year)
No. of Patent granted6. DEFINITIONS
6.1 Patent
A patent means an exclusive legal right granted for an invention under the Patents Act,
1970.
6.2 Commercialization
Commercialization means licensing, assignment, transfer, market deployment,
manufacturing, incubation, start-up creation or industry adoption of patented technology.
6.3 Technology Transfer
Transfer of intellectual property rights or technologies from inventor/institution to industry,
enterprise or public user.
6.4 Consultant
A patent professional, patent agent, legal expert, technology transfer expert or IPR
facilitation agency empanelled by a University or HSHEC.
6.5 IPR Cell
3

<!-- page 5 -->

Institutional Intellectual Property Rights Cell established within a University or College.
6.6 Patent Registration Fee
Patent registration fee shall include expenditure related to prior art search, drafting, filing,
publication, examination, FER response, legal documentation and related patent processing
expenses.

7.Establishment of IPR Cells
To promote innovation, intellectual property protection, research commercialization and
technology transfer activities, Higher Educational Institutions (HEIs), Universities and
Colleges in Haryana may establish Institutional Intellectual Property Rights (IPR) Cells.
The Institutional IPR Cell shall function as the nodal institutional mechanism for facilitating
patent support, innovation promotion, intellectual property management and
commercialization activities within the institution.
8 .CONSULTANCY AND TECHNOLOGY TRANSFER SUPPORT
8.1 Empanelment of Consultants
Universities may empanel patent agents, IPR professionals, technology transfer experts,
commercialization experts, startup mentors, valuation professionals and legal experts
through transparent procedures.
8.2 Functions of Empanelled Consultants
Empanelled consultants may provide support for:
1.
2.
3.
4.
5.
6.

Patent drafting, prior art search and filing assistance;
FER response drafting and legal advisory services;
Technology valuation, licensing and commercialization strategy;
Industry matchmaking, investor linkage and market assessment;
Startup mentoring and incubation support;
Patent analytics and international filing guidance.

8.3 Remenuration to Consutlants
Consultancy support from filing to commercialization may be provided up to Rs. 20,000 per case,
subject to prescribed norms and approval.

8.4 Consultancy Support to Students
Universities shall provide handholding support to students for:


Idea screening and patentability assessment;

4

<!-- page 6 -->




Patent filing and procedural guidance;
Commercialization planning and startup integration.

8.5 Support to External Innovators
Universities may provide patent, technology transfer, commercialization, licensing and
incubation support to:







MSMEs;
Startups;
Rural and grassroots innovators;
Independent inventors;
Farmers;
Alumni; and Industry partners.

9. COMPONENTS OF THE POLICY
The Policy shall consist of the following components:
Component

Nature of Support

Component-I Patent Filing Support
Component-II Patent Publication & Examination Support
Component-III Patent Grant Incentive
Component-IV Commercialization Incentive
Component-V Institutional IPR Ecosystem Development
Component-VI Public Patent Facilitation Services
9.1 COMPONENT-I: PATENT FILING SUPPORT
The support may be availed through:
 Institutional IPR Cells
 Empanelled consultants
 Approved patent professionals
9.2. COMPONENT-II: PATENT PUBLICATION & EXAMINATION SUPPORT
Support may be provided for:

Patent publication charges;

Examination fees;

FER response support;

Legal documentation; and

Expedited examination support.
Priority may be given to student innovators, women innovators, deep-tech innovations and
emerging technologies.

5

<!-- page 7 -->

9.3. COMPONENT-III: PATENT GRANT INCENTIVE
Additional incentive may be provided upon grant of patent subject to prescribed norms and
approval by competent authority.
Priority may be accorded to:

Student innovators;

Faculty researchers;

Startups and MSMEs; and

Joint institutional patents.
9.4. COMPONENT-IV: COMMERCIALIZATION INCENTIVE
Commercialization support may be provided where patented technology is:

Licensed;

Commercialized;

Assigned;

Manufactured;

Adopted by industry; or

Utilized for startup creation.
Support may include incentives for:







Licensing agreements;
Technology transfer agreements;
Commercial product launch;
Patent-based startups; and
Revenue-generating technologies.
Universities may adopt suitable revenue-sharing mechanisms for inventors and
institutions.

9.5. COMPONENT-V: INSTITUTIONAL IPR ECOSYSTEM DEVELOPMENT
Financial assistance may be provided for:

Establishment of IPR Cells;

Patent Facilitation Centres;

Technology Transfer Offices;

Innovation awareness programmes; and

Capacity building and training activities.
9.6. COMPONENT-VI: PUBLIC PATENT FACILITATION SERVICES
Universities may establish Public Patent Facilitation Centres for providing support to:

General public;

MSMEs;

Farmers;

Rural innovators;

Women innovators; and

Startups
6

<!-- page 8 -->

Services may include:

Patent awareness;

Filing support;

Commercialization guidance;

Startup mentoring; and

Technology transfer facilitation.
10. FINANCIAL SUPPORT UNDER THE POLICY
10.1 Overall Financial Ceiling
Financial assistance up to Rs. 50,000 per patent application may be provided on
reimbursement basis, subject to actual expenditure and prescribed limits.
Activity

Maximum Support

Patent filling fee Reimbursement

Rs. 10,000 (Rs. 15,000)

Incentives for granted patent

Rs. 10,000 (Rs. 5,000)

Consultancy support from filling to commercialization Rs. 20,000
Renewal fees support

Rs. 5,000

Design filling support

Rs. 5,000

The support may include:









Filing
Publication
Examination
Granting
FER response
Legal support
Commercialization support
Prototype validation support

subject to actual expenditure and prescribed limits.
10.2 Number of Claims




Normally, assistance shall be limited to a maximum of one patent application per
applicant per financial year.
Additional support may be considered in exceptional cases with approval of competent
authority.

10.3 Mode of Financial Assistance
Financial support shall be provided:


Through reimbursement;
7

<!-- page 9 -->




Through institutional support mechanisms;
Through empanelled patent consultants.
11.IMPLEMENTATION AND GOVERNANCE FRAMEWORK

1. Eligibility and Coverage
Applicant must be an Institute. Applicants associated with Haryana may avail support for
patents, designs, utility innovations, technology transfer agreements and commercializable
software IP in accordance with prescribed guidelines.
2. Priority Categories
Priority may be given to student-led innovations, women and rural innovators, startups and
innovations in priority sectors including AI, deep-tech, healthcare, agriculture, green
technologies and strategic technologies.
3. Application and Documentation
Applications shall be submitted through prescribed portals or Institutional IPR Cells along
with relevant technical, commercialization and financial documents.
4. Evaluation and Approval
Universities may constitute expert committees for technical evaluation, commercialization
assessment and approval of applications.
5. Financial Assistance
Financial assistance shall be provided on reimbursement or incentive basis subject to
verification of claims and supporting documents.
6. Institutional Responsibilities
Universities and Institutional IPR Cells shall facilitate innovation promotion, patent support,
commercialization activities, industry collaboration and awareness.
7. Monitoring, Audit and Accountability
All assistance under the Policy shall be subject to monitoring, audit, technical verification
and physical review wherever required. False or fraudulent claims shall invite recovery,
debarment and legal action. State Level Committee may be constituted.
8. Confidentiality and Revenue Generation
Stakeholders shall maintain confidentiality of unpublished inventions. Institutions may
generate revenue through consultancy, licensing, incubation and technology transfer
activities.
8

<!-- page 10 -->

9. International Patent Support
Exceptional innovations with global commercialization potential may be considered for
international filing support subject to Government approval and budget availability.
10. Miscellaneous
Government may relax provisions of the Policy in deserving cases. Any matter relating to
interpretation of the Policy shall be decided by Government of Haryana and such decision
shall be final.
11. Effective Date
The Policy shall come into effect from the date of notification by Government of Haryana.

9

<!-- page 11 -->

ANNEXURE-I
APPLICATION FORM FOR PATENT SUPPORT
PART-A: BASIC DETAILS
1.
2.
3.
4.
5.
6.
7.
8.
9.

Name of Applicant:
Category:
Institution/Organization:
Address:
Mobile:
Email:
Aadhaar/Registration Number:
Bank Account Number
IFSC Code

PART-B: PATENT DETAILS
1.
2.
3.
4.
5.
6.
7.
8.

Title of Invention:
Patent Application Number:
Date of Filing:
Type of Patent:
Current Status:
Brief Description:
Commercial Potential:
Industry Sector:

PART-C: FINANCIAL ASSISTANCE CLAIMED
Component
Amount Claimed
Drafting
Filing
Publication
Examination
FER Response
Legal Support
Commercialization
Total

PART-D: COMMERCIALIZATION DETAILS
1. Licensing Agreement:
2. Technology Transfer Details:
3. Startup Details:

10

<!-- page 12 -->

4. Revenue Generated:
5. Industry Partner:
6. Commercial Product Details:
PART-E: DECLARATION
Certified that:
1.
2.
3.
4.

Information submitted is true.
No fraudulent claim has been made.
Applicable laws and regulations have been followed.
No duplicate reimbursement has been claimed from any Government scheme

Signature of Applicant
Signature of Institution Head (if applicable)
ANNEXURE-II
FORMAT FOR EMPANELMENT OF PATENT CONSULTANTS
1. Name of Consultant/Firm
2. Patent Agent Registration Number
3. Experience Details
4. Areas of Expertise
5. Number of Patents Handled
6. Commercialization Experience
7. Technology Transfer Experience
8. Fee Structure
9. Supporting Documents
10. Declaration
ANNEXURE-III
MODEL UNIVERSITY IPR CELL STRUCTURE
Suggested Structure
Position
Role
Chairperson
Overall supervision
IPR Coordinator Operational coordination
Legal Expert
Legal advisory
Industry Expert Commercialization support
Patent Consultant Filing support
Startup Expert
Startup linkage
Faculty Members Technical evaluation
11

<!-- page 13 -->

ANNEXURE-IV
UTILIZATION CERTIFICATE
Certified that the grant received under the Haryana Patent Support, Commercialization and
Innovation Facilitation Policy has been utilized for approved purposes.
Head

Amount

Filing
Publication
Examination
Legal
Commercialization
Total

Certified by:




Finance Officer
Head of Institution
Auditor

ANNEXURE-V
COMMERCIALIZATION INCENTIVE CLAIM FORMAT
1.
2.
3.
4.
5.
6.
7.

Patent Number:
Commercialization Type:
Licensing/Transfer Agreement:
Industry Partner:
Revenue Generated:
Startup Details:
Proof Attached:

ANNEXURE-VI
INDICATIVE BUDGET DISTRIBUTION
Component
Filing Support
Examination & Publication

Tentative Allocation
25%
15%

Grant Incentives
15%
Commercialization Incentives 20%
IPR Cell Development
10%
Consultancy & Facilitation
10%
Awareness & Capacity Building 5%

12
