---
doc_id: "3cfabc39e179fdc5"
source_url: "https://fdaharyana.gov.in/actsNotifications/DrugsPriceControlOrder2013.pdf"
ministry: "Food and Drugs Administration Department, Haryana"
title: "Drugs (Prices Control) Order,2013"
date: ""
pages: 67
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c046690d109204bc"
---

<!-- page 1 -->

To be published in the Gazette of India,
Extraordinary, Part II, Section 3, Sub-section(ii) dated 15th May 2013
Ministry of Chemicals and Fertilizers
(Department of Pharmaceuticals)
New Delhi
Dated 15th ___May 2013
25 Vaisakha Saka 1935
ORDER
S.O. 1221(E).– In exercise of the powers conferred by section 3 of the Essential Commodities
Act, 1955, (10 of 1955), and supersession of the Drug (Prices Control) Order, 1995, except as
respect to things done or omitted to be done before such supersession, the Central
Government hereby makes the following Order, namely:1. Short title and commencement.– (1) This Order may be called the Drugs (Prices Control)
Order, 2013.
(2) It shall come into force on the date of its publication in the Official Gazette.
2. Definitions.– (1) In this Order, unless the context otherwise requires,–
(a) “Act” means the Essential Commodity Act, 1955 (10 of 1955);
(b) "active pharmaceutical ingredients or bulk drug" means any pharmaceutical, chemical,
biological or plant product including its salts, esters, isomers, analogues and derivatives,
conforming to standards specified in the Drugs and Cosmetics Act, 1940 (23 of 1940) and
which is used as such or as an ingredient in any formulation;
(c) “brand” means a name, term, design, symbol, trademark or any other feature that
identifies one seller’s drug as distinct from those of other sellers;

1

<!-- page 2 -->

(d) "ceiling price" means a price fixed by the Government for Scheduled formulations in
accordance with the provisions of this Order;
(e) "dealer" means a person carrying on the business of purchase or sale of drugs, whether
as a wholesaler or retailer and includes his agent;
(f) "distributor" means a person engaged in the work of distribution of drugs and includes
an agent or a stockist for stocking drugs for sale to a dealer;
(g) “existing manufacturer” means manufacturer existing on the date of publication of this
order in the Official Gazette.
(h) "Form" means a form specified in the Second Schedule;
(i) "formulation" means a medicine processed out of or containing one or more drugs with
or without use of any pharmaceutical aids, for internal or external use for or in the
diagnosis, treatment, mitigation or prevention of disease and, but shall not include –
(i) any medicine included in any bonafide Ayurvedic (including Sidha) or Unani (Tibb)
systems of medicines;
(ii) any medicine included in the Homeopathic system of medicine; and
(iii) any substance to which the provisions of the Drugs and Cosmetics Act, 1940 (23
of 1940) do not apply;
(j) “generic version of a medicine” means a formulation sold in pharmacopeial name or
the name of the active pharmaceutical ingredient contained in the formulation, without
any brand name;
(k) "Government" means the Central Government;

2

<!-- page 3 -->

(l) "import" with its grammatical variations and cognate expressions means bringing a drug
into India from a place outside India for its sale;
(m) “local taxes” means any tax or levy (except excise or import duty included in retail
price) paid or payable to the Government or the State Government or any local body under
any law for the time being in force by the manufacturer or his agent or dealer;
(n) "manufacturer" for the purpose of this Order means any person who manufactures,
imports and markets drugs for distribution or sale in the country;
(o) “market share” means the ratio of domestic sales value (on the basis of moving annual
turnover) of a brand or a generic version of a medicine and the sum of total domestic sales
value of the all brands and generic versions of that medicine sold in the domestic market
having same strength and dosage form;
(p) “margin to retailer” for the purposes of this Order shall mean a percentage of price to
retailer;
(q) “market based data” means the data of sales related to a drug collected or obtained by
the Government as deemed fit, from time to time;
(r) “maximum retail price” means the ceiling price or the retail price plus local taxes and
duties as applicable, at which the drug shall be sold to the ultimate consumer and where
such price is mentioned on the pack;
(s) “moving annual turnover” in a particular month means cumulative sales value for
twelve months in domestic market, where the sales value of that month is added and the
corresponding sales of the same month in the previous year are subtracted;
(t) “National List of Essential Medicines” means National List of Essential Medicines, 2011
published by the Ministry of Health and Family Welfare as updated or revised from time to

3

<!-- page 4 -->

time and included in the first schedule of this order by the Government through a
notification in the Official Gazette;
(u) “new drug” for the purposes of this Order shall mean a formulation launched by an
existing manufacturer of a drug of specified dosages and strengths as listed in the National
List of Essential Medicines by combining the drug with another drug either listed or not
listed in the National List of Essential Medicines or a formulation launched by changing the
strength or dosages or both of the same drug of specified dosages and strengths as listed
in the National List of Essential Medicines.
(v) "non-scheduled formulation" means a formulation, the dosage and strengths of which
are not specified in the First Schedule;
(w) “pharmacoeconomics” means a scientific discipline that compares the therapeutic
value of one pharmaceutical drug or drug therapy to another;
(x) "price list" means a price list referred to in paragraphs 24 and 25 and includes a
supplementary price list;
(y) “price to retailer” means the price of a drug at which it is sold to a retailer which
includes duties and does not include local taxes;
(z) "retail price" means the price fixed by the Government for a new drug under paragraph
5;
(za) "retailer" means a dealer carrying on the retail business of sale of drugs to customers;
(zb) “scheduled formulation" means any formulation, included in the First Schedule
whether referred to by generic versions or brand name;
(zc) "schedule" means a Schedule appended to this Order;

4

<!-- page 5 -->

(zd) "wholesaler" means a dealer or his agent or a stockist engaged in the sale of drugs to
a retailer, hospital, dispensary, medical, educational or research institution or any other
agency;
(ze) “wholesale price index” means annual wholesale price index of all commodities as
announced by the Department of Industrial Policy and Promotion, Government of India,
from time to time.
(2) All other words and expressions used herein and not defined but defined in the Act or the
Drugs and Cosmetics Act, 1940 (23 of 1940) shall have the meanings respectively assigned to
them in the said Acts.
.3. Directions to manufacturers of active pharmaceutical ingredients or bulk drugs or
formulations.– The Government may, (i) with a view to achieve adequate availability and to regulate the distribution of drugs, in
case of emergency or in circumstances of urgency or in case of non-commercial use in
public interest, direct any manufacturer of any active pharmaceutical ingredient or bulk
drug or formulation to increase the production and to sell such active pharmaceutical
ingredient or bulk drug to such other manufacturer(s) of formulations and to direct
formulators to sell the formulations to institutions, hospitals or any agency as the case
may be;
(ii) for the purpose of giving any direction under sub-paragraph (i), call for such
information from manufacturers of active pharmaceutical ingredients or bulk drugs or
formulations, as it may consider necessary and such manufacturer shall furnish the
required information within such time the Government may fix.
4. Calculation of ceiling price of a scheduled formulation.– (1) The ceiling price of a scheduled
formulation of specified strengths and dosages as specified under the first schedule shall be
calculated as under:

5

<!-- page 6 -->

Step1. First the Average Price to Retailer of the scheduled formulation i.e. P(s) shall be
calculated as below:
Average Price to Retailer, P(s) = (Sum of prices to retailer of all the brands and
generic versions of the medicine having market share more than or equal to one
percent of the total market turnover on the basis of moving annual turnover of
that medicine) / (Total number of such brands and generic versions of the
medicine having market share more than or equal to one percent of total market
turnover on the basis of moving annual turnover for that medicine.)
Step2. Thereafter, the ceiling price of the scheduled formulation i.e. P(c) shall be
calculated as below:
P(c) = P(s).(1+M/100), where
P(s) = Average Price to Retailer for the same strength and dosage of the
medicine as calculated in step1 above.
M = % Margin to retailer and its value =16
(2) The ceiling price calculated as per sub-paragraph (1) and notified by the Government shall
be applicable to scheduled imported formulations also.

5. Calculation of retail price of a new drug for existing manufacturers of scheduled
formulations.– (1) The retail price of the new drug available in domestic market shall be
calculated as provided in sub-paragraph (1) of paragraph 4.

(2) (i) the price to retailer of a new drug, not available in domestic market, shall be fixed by
the Government on the principles of “Pharmacoeconomics” of the new drug, on the
recommendation of a Standing Committee of Experts formed under paragraph 15.

(ii) the retail price of such new drug shall be fixed by adding sixteen percent margin to
retailer on the price to retailer as fixed in item (i):

6

<!-- page 7 -->

6. Ceiling price of a scheduled formulation in case of no reduction in price due to absence of
competition.– (1) where the average price to retailer of a scheduled formulation, arrived at as
per the formula specified in sub-paragraph (1) of paragraph 4, has the effect of,(a) no reduction in average price to retailer with respect to the prices to retailer of the
schedule formulation; and
(b) there are less than five manufacturers for that formulation having one percent or more
market share,
the ceiling price shall be calculated as under:(i)

in the event of other strengths or dosage forms of the same scheduled

formulation is available in the list of scheduled formulation, the average price to
retailer shall be calculated as under:
Step1: First the Average Price to Retailer of such scheduled formulation i.e. P(s) shall
be calculated as under:
P(s) = Pm{1-(Pi1+Pi2+…)/(N*100)} Where,
Pm = Price to Retailer of highest priced scheduled formulation under
consideration.
Pi = % reduction in Average Price to Retailer of other strengths and
dosage forms (calculated as in step1 of sub-paragraph (1) of paragraph 4)
in the list of schedule formulations w.r.t the highest priced formulation
taken for calculating the average price to retailer of such strengths and
dosage forms.
N = Number of such other strengths or dosage forms or both in the list of
schedule formulations
Step2. Thereafter, the ceiling price of the scheduled formulation i.e. P(c) shall be
calculated as under:
P(c) = P(s).(1+M/100), where
P(s) = Average Price to Retailer of the scheduled formulation as
calculated in step1 hereinabove and
M = % Margin to retailer and its value=16
7

<!-- page 8 -->

(ii) in the event of other strengths or dosage forms of the scheduled formulation is
not available in the schedule but there are other scheduled formulations in same subtherapeutic category as that of the scheduled formulation, then the Ceiling Price shall
be calculated as under:
Step1: First the Average Price to Retailer of such scheduled formulation i.e. P(s) shall
be calculated as under:
P(s) = Pm{1-(Pi1+Pi2+…)/(N*100)}, Where,
Pm = Price of highest priced formulation taken for calculating the average
price to retailer of the formulation under consideration..
Pi = % reduction in Average Price to Retailer of other schedule
formulations (calculated as in step1 of sub-paragraph (1) of paragraph 4)
in same sub-therapeutic category as that of the scheduled formulation
under consideration w.r.t the highest priced formulation taken for
calculating the average price to retailer.
N = Number of such other schedule formulations in same sub-therapeutic
category as that of the scheduled formulation under consideration.
Step2. Thereafter, the ceiling price of the scheduled formulation i.e. P(c) shall be
calculated as under:
P(c) = P(s)*(1+M/100), where
P(s) = Average Price to Retailer of the scheduled formulation as
calculated in step1 above and
M = % Margin to retailer and its value=16
Explanation.- where the scheduled formulation under consideration is coming under
more than one sub-therapeutic category, the Average Price to Retailer of the
scheduled formulation shall be calculated after taking into consideration the
percentage reduction in Average Price to Retailer of other schedule formulations
under all such sub-therapeutic categories and the lowest average price to retailer
shall be taken for calculating the ceiling price of the scheduled formulation under
consideration;
8

<!-- page 9 -->

(iii) in case the other strengths or dosage forms of the scheduled formulation are not
available in the schedule and there is no sub therapeutic category of the scheduled
under consideration, the ceiling price shall be calculated as under:
Step1: First the Average Price to Retailer of such scheduled formulation i.e. P(s) shall
be calculated as under:
P(s) = Pm{1-(Pi1+Pi2+…)/(N*100)} Where,
Pm = Price of highest priced formulation taken for calculating the average
price to retailer of the formulation under consideration.
Pi = % reduction in Average Price to Retailer of other schedule
formulations (calculated as in step1 sub-paragraph (1) of paragraph 4) in
same therapeutic category as that of the scheduled formulation under
consideration w.r.t the highest priced formulation taken for calculating
the average price to retailer.
N = Number of such other schedule formulations in same therapeutic
category as that of the scheduled formulation under consideration.
Step2. Thereafter, the ceiling price of the scheduled formulation i.e. P(c) shall be
calculated as under:
P(c) = P(s).(1+M/100), where
P(s) = Average Price to Retailer of the scheduled formulation as calculated
in step1 above and
M = % Margin to retailer and its value=16
Explanation.- where the scheduled formulation under consideration is coming under
more than one therapeutic category, the Average Price to Retailer of the scheduled
formulation shall be calculated after taking into consideration the percentage
reduction in Average Price to Retailer of other schedule formulations under all such
therapeutic categories and the lowest average price to retailer shall be taken for
calculating the ceiling price of the scheduled formulation under consideration.
9

<!-- page 10 -->

(2) Notwithstanding anything contained in this paragraph, where the price has been fixed and
notified by the Government under the Drugs (Prices Control) Order, 1995 the provisions of subparagraph (1) shall not apply.

7. Margin to retailer.– While fixing a ceiling price of scheduled formulations and retail prices of
new drugs, sixteen percent of price to retailer as a margin to retailer shall be allowed.

8. Maximum retail price.– (1) The maximum retail price of scheduled formulations shall be
fixed by the manufacturers on the basis of ceiling price notified by the Government plus local
taxes wherever applicable, as under:
Maximum Retail Price = Ceiling price + Local Taxes as applicable
(2) The maximum retail price of a new drug shall be fixed by the manufacturers on the basis of
retail price determined by the Government plus local taxes wherever applicable, as under:
Maximum Retail Price = Retail Price + Local Taxes as applicable

9. Reference data and source of market based data.– (1) Initially, the source of market based
data shall be the data available with the pharmaceuticals market data specializing company –
IMS Health (IMS) and if the Government deems necessary, it may validate such data by
appropriate survey or evaluation.

(2) The Government may in the due course of time come out with other appropriate
mechanism of collecting or obtaining the market based data related to drugs and the decision
of Government with respect to collection or obtaining of data shall be final.

(3) The market based data, for fixing the ceiling price of scheduled formulations for the first
time after the notification of this order, shall be the data of May, 2012.

10

<!-- page 11 -->

(4) The market based data for fixing the retail price of new drugs available in the market, shall
be the data available for the month ending immediately before six months of receipt of
application for fixing the price of the new drug.

(5) The market based data for fixing the ceiling price of a scheduled formulation due to a
revision in the first schedule shall be the data available for the month ending immediately
before six month of notification of revision in the first schedule.

(6) Notwithstanding anything contained in this order, the reference date for the formulations
which are part of the Drugs (Prices Control) Order, 1995 shall be as per the provisions of
paragraph 10 of this Order.

10. Pricing of the formulations covered under Drugs (Prices Control) Order, 1995.– (1) The
prices of scheduled formulations, which are also specified in the First Schedule to the Drugs
(Prices Control) Order, 1995, fixed and notified under the provisions of the said order, up to 31 st
May, 2012, shall remain effective for further one year i.e. up to 30 th May’ 2013 and the
manufacturers may revise the prices of such scheduled formulations as per the annual
wholesale price index for the previous calendar year announced by Department of Industrial
Promotion and Policy and thereafter the formula as in sub- paragraph (1) of paragraph 4 of this
Order shall be applied for fixing the ceiling prices of such formulations.

(2) The prices of scheduled formulations, which are also specified in the First Schedule to the
Drugs (Prices Control) Order, 1995, fixed and notified under the provisions of Drugs (Prices
Control) Order,1995 after 31st May,2012, shall remain effective for one year from the date of
notification of such prices under Drugs (Prices Control) Order,1995 and immediately thereafter
the manufacturers may revise the prices as per the annual wholesale price index for the
previous calendar year announced by Department of Industrial Promotion and Policy and on
the 1st April of succeeding financial year, the formula as in sub-paragraph (1) of paragraph 4 of
this Order shall be applied for fixing the ceiling prices of such schedule formulations.
11

<!-- page 12 -->

(3) The prices of scheduled formulations, which are specified in the Drugs (Prices Control)
Order, 1995 but not specified in the First Schedule of this order, fixed and notified under the
provisions of the said order, up to 31st May,2012, shall remain effective for further one year i.e.
up to the 30thMay’2013 and thereafter prices of such formulations shall be regulated as in case
of other non-scheduled formulations as stated in paragraph 20 of this Order.

(4) The prices of scheduled formulations, which are specified in the Drugs (Prices Control)
Order, 1995 but not specified in the First Schedule of this order, fixed and notified under the
provisions of the said order, after 31st May,2012, shall remain effective for one year from the
date of notification of such prices and thereafter prices of such formulations shall be regulated
as in case of other non-scheduled formulations as stated in paragraph 20 of this Order.
11. Ceiling price or retail price of a pack.– (1) The average price to retailer calculated as per the
provisions in paragraphs 4, 5 and 6 shall be on the dosage basis, (per tablet, per capsule or
injection in volume as listed in first schedule) and the ceiling price or retail price of a pack shall
be reached by multiplying the same with the number or quantity in the pack as the case may
be.
(2) In the event of the unit of the dosage for a scheduled formulation not available in the first
schedule, the lowest pack size for that category of medicine, as specified in the Drugs and
Cosmetics Act, 1940 (23 of 1940) and the rules thereunder, shall be taken as unit dosage for
calculating the ceiling price or retail price as the case may be, for that scheduled formulation
and this shall be applicable while calculating the per unit price of even non-scheduled
medicines for arriving at the retail price in case of paragraph 5.
12. Price of formulations (branded or generic version) listed in the National List of Essential
Medicines, launched by a manufacturer.– (1) A manufacturer, launching a scheduled
formulation, shall be free to fix the price of the scheduled formulation equal to or below the
ceiling price fixed for that schedule formulation by the Government.

12

<!-- page 13 -->

(2) Where an existing brand is re-launched by another manufacturer the provisions of
paragraph 13 shall be applicable.
13.

Price of scheduled formulations for the existing manufacturers.– (1) All the existing

manufactures of scheduled formulations, selling the branded or generic or both the versions of
scheduled formulations at a price higher than the ceiling price (plus local taxes as applicable) so
fixed and notified by the Government, shall revise the prices of all such formulations downward
not exceeding the ceiling price (plus local taxes as applicable):
Provided, that in case of scheduled formulations produced or available in the market before the
date of notification of ceiling price, the manufacturers shall ensure within a period of forty-five
days of the date of such notification that the maximum retail price of such scheduled
formulation does not exceed the ceiling price (plus local taxes as applicable).

(2) All the existing manufactures of scheduled formulations, selling the branded or generic or
both the versions of scheduled formulations at a price lower than the ceiling price (plus local
taxes as applicable) so fixed and notified by the Government shall maintain their existing
maximum retail price.

(3) Annual increase in maximum retail price may be carried out as per the increase in the
wholesale price index with respect to previous year as per the provision of sub-paragraphs (2)
and (3) of paragraph 16.

Provided that in case of decline in wholesale price index, a corresponding reduction in the
prices shall be made as per the provision of sub-paragraph (4) of paragraph 16.

14. Fixation of ceiling price of scheduled formulations.– (1) The Government shall fix and
notify the ceiling prices of the scheduled formulations in accordance with the provisions of the
paragraphs 4 and 6, as the case may be, and no manufacturer shall sell the scheduled

13

<!-- page 14 -->

formulations at a price higher than the ceiling price (plus local taxes as applicable) so fixed and
notified by the Government.

(2) Where any manufacturer sells a scheduled formulation at a price higher than the ceiling
price (plus local taxes as applicable) fixed and notified by the Government, such manufacturers
shall be liable to deposit the overcharged amount along with interest thereon from the date of
such overcharging.

15. Fixation of retail price of a new drug for existing manufacturers of scheduled
formulations.– (1) The Government shall form a Standing Committee of such Experts, as it may
deem fit, within sixty days of notification of this order with a view to recommend the retail
prices of new drugs on the principles of “Pharmacoeconomics”.

(2) Where an existing manufacturer of a drug with dosages and strengths as specified in
National List of Essential Medicines launches a new drug, such existing manufacturers shall
apply for prior price approval of such new drug from the Government in Form-I specified under
Schedule-II of this Order.

(3) On receipt of the application under sub-paragraph (2), in the event of the new drug
available in domestic market, the Government shall fix the retail price of the new drug in
accordance with the provision of sub-paragraph(1) of paragraph 5 and in the event of the new
drug not available in domestic market, the Government shall forward the same to the Standing
Committee of Experts who shall examine the application on the principles of
“Pharmacoeconomics” and make recommendations of retail price of the new drug to the
Government within thirty days of the receipt of application.

(4) The Government shall, on receipt of recommendation under sub-paragraph (3), within thirty
days, fix the retail price of such new drug and such price shall be applicable to such applicant of
such new drug.
14

<!-- page 15 -->

(5) Where existing manufacturer of scheduled formulation fails to apply for prior approval of
the price of the new drug in Form-I, such manufacturer shall be liable to deposit the
overcharged amount over and above such price fixed and notified by the Government, if any,
along with interest thereon from the date of launch of the new drug, in addition to the penalty.

(6) No existing manufacturer of a scheduled formulation shall sell such a new drug at a price
higher than the retail price (plus local taxes as applicable) fixed by the Government for such
new drug and in case such a manufacturer is found to sell such a new drug at a price higher
than the retail price (plus local taxes as applicable) fixed by the Government, such
manufacturer of the new drug shall be liable to deposit the overcharged amount along with
interest from the date of overcharge, in addition to the penalty.

16. Revision of ceiling price of scheduled formulations.– (1) The Government shall revise the
ceiling prices of scheduled formulations as per the annual wholesale price index (WPI) for
preceding calendar year on or before 1st April of every year and notify the same on the 1st day
of April every year.

(2) The manufacturers may increase the maximum retail price (MRP) of scheduled formulations
once in a year, in the month of April, on the basis of the wholesale price index with respect to
previous calendar year and no prior approval of the Government in this regard shall be
required.

(3) Information about the revision, if carried out, shall be forwarded to the Government in
either electronic or physical form in Form-II within a period of fifteen days of such revision and
non-submission of information under this sub-paragraph shall be construed as non revision of
maximum retail price (MRP) and the concerned manufacturer shall be liable to deposit the
amount charged over and above the pre-revised maximum retail price (MRP), alongwith
interest thereon from the date of overcharging.
15

<!-- page 16 -->

(4) In case of decline in wholesale price index, there shall be a corresponding reduction in the
maximum retail price and in case of scheduled formulations produced or available in the
market before the date of notification of revised ceiling price, the manufacturers shall ensure
within a period of forty-five days of the date of such notification that the maximum retail price
(MRP) of such scheduled formulation does not exceed the revised ceiling price (plus local taxes
as applicable) and information about the revision shall be sent to the Government in either
electronic or physical form in Form-II within a period of fifteen days of such revision.

(5) Non-submission of information under the sub-paragraph (4) shall be construed as non
reduction in maximum retail price (MRP) and the concerned manufacturer shall be liable to
deposit the amount charged over and above the maximum retail price revised based on decline
in wholesale price index, alongwith interest thereon as overcharged amount from the date of
overcharging.
17. Amendment of the list of scheduled formulation.– (1) A decision to amend the first
schedule, clearly stating the reasons thereof, shall be taken by the Government within sixty
days of receipt of communication from the Ministry of Health and Family Welfare and the
amendment(s) or revision, if required, in the first schedule shall be notified and thereafter, the
ceiling price(s) for the medicine(s) added in the first schedule shall be fixed as per the
provisions of this order within a period of sixty days from the date of the notification.
(2) The medicines omitted from the first schedule shall fall under the category of non-scheduled
formulations.
18. Revision of ceiling price on the basis of moving annual turnover (MAT).– The revision of
ceiling prices on the basis of moving annual turnover value shall be carried out,(i) as and when the National List of Essential Medicines is revised by the Ministry of Health
and Family Welfare or five years from the date of fixing the ceiling price under this Order
whichever is earlier;
16

<!-- page 17 -->

(ii) when the number of manufacturers of a scheduled formulation, having price of a
scheduled formulation more than or equal to seventy five percent of the ceiling price fixed
and notified by the Government, has decreased by twenty five percent or more than the
number of manufacturers as existing on the reference date;
(iii) when the number of manufacturers of a scheduled formulation, having prices of their
scheduled formulation equal to or lower than twenty five percent of the ceiling price fixed
by the Government, has increased by twenty five percent or more than the number of
manufacturers as existing on the reference date.
Explanation.- For the purpose of items (ii) and (iii) the “reference date” shall be for first revision
of ceiling price May, 2012 and for second or subsequent revision the date of previous revision
of the ceiling price.
19. Fixation of ceiling price of a drug under certain circumstances.- Notwithstanding anything
contained in this order, the Government may, in case of extra-ordinary circumstances, if it
considers necessary so to do in public interest, fix the ceiling price or retail price of any Drug for
such period, as it may deem fit and where the ceiling price or retail price of the drug is already
fixed and notified, the Government may allow an increase or decrease in the ceiling price or the
retail price, as the case may be, irrespective of annual wholesale price index for that year.
20. Monitoring the prices of non-scheduled formulations.– (1) The Government shall monitor
the maximum retail prices (MRP) of all the drugs, including the non-scheduled formulations and
ensure that no manufacturer increases the maximum retail price of a drug more than ten
percent of maximum retail price during preceding twelve months and where the increase is
beyond ten percent of maximum retail price, it shall reduce the same to the level of ten
percent of maximum retail price for next twelve months.
(2) The manufacturer shall be liable to deposit the overcharged amount along with interest
thereon from the date of increase in price in addition to the penalty.

17

<!-- page 18 -->

21. Monitoring the availability of scheduled formulations.– (1) The Government shall monitor
the production and availability of scheduled formulations and the active pharmaceutical
ingredients contained in the scheduled formulation and the manufacturer of scheduled
formulations and the active pharmaceutical ingredients contained in the scheduled formulation
shall furnish the information as stated in Form-III of schedule-II of this Order quarterly.
(2) Any manufacturer of scheduled formulation, intending to discontinue any scheduled
formulation from the market shall issue a public notice and also intimate the Government in
Form-IV of schedule-II of this order in this regard at least six month prior to the intended date
of discontinuation and the Government may, in public interest, direct the manufacturer of the
scheduled formulation to continue with required level of production or import for a period not
exceeding one year, from the intended date of such discontinuation within a period of sixty
days of receipt of such intimation.
22. Recovery of dues accrued under the Drugs (Prices Control) Order, 1979 and to deposit the
same into the Drugs Prices Equalisation Account.– (1) Notwithstanding anything contained in
this order, the Government may by notice, require a manufacturer, importer or distributor as
the case may be, to deposit the amount which has accrued under the provisions of the Drugs
(Prices Control) Order, 1979 on or before the commencement of this order, into the Drugs
Prices Equalisation Account and the manufacturer, importer or distributor, as the case may be,
shall deposit the said amount into the said account within such time as the Government may
specify in the said notice.
(2) The existing amount, if any, in the Drugs Prices Equalisation Account on or before the date
of commencement of this Order, and the amount deposited under sub-paragraph (1) shall be
utilised for;(a) paying to the manufacturer, importer or distributor, as the case may be, the shortfall
between his retention price and the common selling price or, as the case may be, the
pooled price for the purpose of increasing the production, or securing the equitable
distribution and availability at fair prices, of drugs;
18

<!-- page 19 -->

(b) meeting the expenses incurred by the Government in discharging the functions under
this paragraph; and
(c) promoting higher education and research in Pharmaceutical Sciences and Technology
and for the purposes incidental thereto.
23. Recovery of overcharged amount under Drugs Prices Control Orders 1987 and 1995.–
Notwithstanding anything contained in this order, the Government shall by notice, require the
manufacturers, importer or distributor or as the case may be, to deposit the amount accrued
due to charging of prices higher than those fixed or notified by the Government under the
provisions of Drugs (Prices Control) Order, 1987 and Drugs (Prices Control) Order, 1995 under
the provisions of this Order.

24. Carrying into effect the price fixed or revised by the Government, its display and proof
thereof.– (1) For all the scheduled formulations having maximum retail price (MRP) higher than
ceiling price (plus local taxes as applicable), the manufactures shall revise the maximum retail
price (MRP) not exceeding the ceiling price (plus local taxes as applicable):

Provided that in case of scheduled formulations produced or available in the market before the
date of notification of ceiling price, the manufacturers shall ensure within a period of forty-five
days of the date of the notification that the maximum retail price of such scheduled
formulation does not exceed the ceiling price (plus local taxes as applicable).

(2) Every manufacturer of a schedule formulation intended for sale shall display in indelible
print mark, on the label of container of the formulation and the minimum pack thereof offered
for retail sale, the maximum retail price of that formulation based on the ceiling price notified
in the Official Gazette or ordered by the Government in this behalf with the words "Maximum
Retail Price" preceding it and the words 'inclusive of all taxes' succeeding it.

19

<!-- page 20 -->

(3) Every manufacturer shall issue a price list and supplementary price list, if required, in Form V
to the dealers, State Drugs Controllers and the Government indicating reference to such price
fixation or revision as covered by the order or Gazette notification issued by the Government,
from time to time.
(4) Every retailer and dealer shall display the price list and the supplementary price list, if any,
as furnished by the manufacturer, on a conspicuous part of the premises where he carries on
business in a manner so as to be easily accessible to any person wishing to consult the same.
25. Display of prices of non-scheduled formulations and price list thereof.– (1) Every
manufacturer of a non-Scheduled formulation intended for sale shall display in indelible print
mark, on the label of container of the formulation and the minimum pack thereof offered for
retail sale, the maximum retail price of that formulation with the words "Maximum Retail Price"
preceding it and the words 'inclusive of all taxes' succeeding it.
(2) Every manufacturer shall issue a price list and supplementary price list, if required, of the
non-Scheduled formulations in Form-V to the dealers, State Drugs Controllers and the
Government indicating changes, from time to time.
(3) Every retailer and dealer shall display the price list and the supplementary price list, if any,
as furnished by the manufacturer or importer, on a conspicuous part of the premises where he
carries on business in a manner so as to be easily accessible to any person wishing to consult
the same.
26. Control of sale prices of formulations.– No person shall sell any formulation to any
consumer at a price exceeding the price specified in the current price list or price indicated on
the label of the container or pack thereof, whichever is less.

27. Sale of split quantities of formulations.– No dealer shall sell loose quantity of any
formulation at a price which exceeds the pro-rata price of the formulation.

20

<!-- page 21 -->

28. Manufacturer, distributor or dealer not to refuse sale of drug.– Subject to the provisions of
the Drug and Cosmetics Act, 1940 (23 of 1940) and the rules made thereunder, (a) no manufacturer or distributor shall withhold from sale or refuse to sell to a dealer any
drug without good and sufficient reasons;
(b) no dealer shall withhold from sale or refuse to sell any drug available with him to a
customer intending to purchase such drug.
29. Maintenance of records and production thereof for inspection.– Every manufacturer shall
maintain records relating to the sales of individual active pharmaceutical ingredients or bulk
drugs manufactured or imported and marketed by him, as the case may be, and the sales of
formulations units and packs and also such other records as may be directed from time to time
by the Government and the Government shall have the power to call for any record and to
inspect such records at the premises of the manufacturer.

30. Power of entry, search and seizure.– (1) Any Gazetted Officer of the Central Government or
of a State Government, as the case may be, authorised by a general or special order by the
Central Government or by the State Government, as the case may be, in this behalf may, with a
view to securing compliance with this Order or to satisfy himself that the provision of this Order
have been complied with–
(a) enter and search any place;
(b) seize any drug, alongwith the containers, packages or coverings in which the drug is
found, in respect of which he suspects that any provision of this Order has been, is being, or
is about to be contravened, and thereafter take all measures necessary for securing
production of the drug, containers, packages or coverings, so seized, in a court of law and
for their safe custody pending such production;

21

<!-- page 22 -->

(c) seize any document, such as, cash memo or credit memo books, books of account and
records of purchase and sale of the drugs in respect of which he suspects that any provision
of this Order has been, is being, or is about to be contravened.
(2) The provisions of Code of Criminal Procedure, 1973 (2 of 1974), relating to search and
seizure shall, so far as may be, apply to searches and seizures under this Order.
31. Power to review.– Any person aggrieved by any notification issued or order made under
paragraphs 4, 5 and 6 of this Order, may apply to the Government for a review of the
notification or order within a period of thirty days of the date of publication of the notification
in the Official Gazette or the receipt of the order by him, as the case may be, and the
Government may make such order on the application as it may deem proper:
Provided that pending a decision by the Government on the application submitted under the
above paragraph, no manufacturer shall sell a scheduled formulation or a new drug, as the case
may be, at a price exceeding the ceiling price or retail price, as the case may be, fixed by the
Government of which a review has been applied for.
32. Non–application of the provisions of this order in certain cases.- The provisions of this
order shall not apply to, (i) a manufacturer producing a new drug patented under the Indian Patent Act, 1970 (39 of
1970) (product patent) and not produced elsewhere, if developed through indigenous
Research and Development, for a period of five years from the date of commencement of
its commercial production in the country.
(ii) a manufacturer producing a new drug in the country by a new process developed
through indigenous Research and Development and patented under the Indian Patent Act,
1970 (39 of 1970) (process patent) for a period of five years from the date of the
commencement of its commercial production in the country.

22

<!-- page 23 -->

(iii) a manufacturer producing a new drug involving a new delivery system developed
through indigenous Research and Development for a period of five years from the date of
its market approval in India:
Provided that the provision of this paragraph shall apply only when a document showing
approval of such new drugs from Drugs Controller General (India) is produced before the
Government.

Explanation.- Notwithstanding anything contained in this Order, for the purpose of this
paragraph “new drug” shall have the same meaning as is assigned to under rule 122E of the
Drugs and Cosmetics Rules, 1945;

File No.31011/17/2012-PI-II

(Shambhu Kallolikar)
Joint Secretary to the Government of India

23

<!-- page 24 -->

Schedule-I
(See Paragraphs-2(t),2(zb))
Symbols P, S and T appearing in NLEM 2011 denote essentiality at Primary, Secondary
and Tertiary levels respectively.
NATIONAL LIST OF ESSENTIAL MEDICINES 2011
Section: 1 – Anesthesia

1.1 General Anesthetics and Oxygen

Medicines

Category

Route of
Administration

Strengths

Ether

S, T

Inhalation

--

Halothane with
vaporizer

S, T

Inhalation

Isoflurane

S, T

Inhalation

Ketamine
Hydrochloride

P, S, T

Injection

Nitrous Oxide

P, S, T

Inhalation

Oxygen

P, S, T

Inhalation

Thiopentone Sodium

S, T

Injection

10 mg / ml,
50 mg / ml

0.5 g, 1 g powder

Added Medicines
Sevoflurane

T

Inhalation

Propofol

P,S,T

Injection

1% oil suspension

1.2 Local Anesthetics

Medicines

Route of
Administration/
Dosage Form

Category

24

Strengths

<!-- page 25 -->

Bupivacaine
Hydrochloride

S, T

Injection

Topical Forms,
Lignocaine
Hydrochloride

Lignocaine
Hydrochloride
+ Adrenaline

P, S, T

Injection,

P, S, T

0.25%, 0.5%, 0.5%
to be mixed with
7.5% glucose
solution

2-5%,
1-2%,

Spinal

5% +7.5%
Glucose

Injection

1%, 2% +
Adrenaline1:200,0
00

Added Medicines
EMLA cream

T

Cream

1.3 Preoperative Medication and Sedation for Short Term Procedures

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Atropine Sulphate

P, S, T

Injection

0.6 mg / ml

Tablets

5 mg

Injection,

5 mg / ml

Syrup,

2mg/5ml

Suppository

5 mg

P,S,T
Diazepam
S, T

1 mg / ml
Midazolam

P, S, T

Injection
5 mg / ml

Morphine Sulphate

Promethazine

S, T

Injection

10 mg / ml

P, S, T

Syrup

5 mg / 5 ml

25

<!-- page 26 -->

Section: 2 - Analgesics , Antipyretics, Nonsteroidal Antiinflammatory Medicines, Medicines used to treat Gout and
Disease Modifying Agents used in Rheumatoid Disorders
2.1: Non-Opioid Analgesics, Antipyretics and Nonsteroidal Anti-inflammatory
Medicines
Medicines

Category

Route of Administration/
Dosage Form

Acetyl Salicylic
Acid

P, S, T

Tablets

T

Tablets

50 mg

Injection

25 mg / ml

Tablets

200 mg, 400 mg

Syrup

100mg/5ml

P, S, T

Injection

150 mg / ml

P, S, T

Syrup

125 mg / 5ml

P, S, T

Tablets

500 mg

P, S, T

Suppository

80 mg, 170 mg

Strengths

325, 350 mg

Diclofenac
T
Ibuprofen

P, S, T

Paracetamol

2.2 Opioid Analgesics
Medicines

Morphine
Sulphate

Category

Route of Administration/
Dosage Form

Strengths

Injection

10 mg / ml

Tablets

10 mg

S, T

Added medicines
Tramadol

Fentanyl

Injection

50 mg/ml

Cap

50 mg,100 mg

S,T

S,T

Injection

26

50ug/ml

2ml ampoule

<!-- page 27 -->

2.3 Medicines used to treat Gout
Allopurinol

S, T

Tablets

100 mg

Colchicine

S, T

Tablets

0.5 mg

2.4 Disease modifying agents used in Rheumatoid disorders
Azathioprine

S, T

Tablets

Methotrexate

S,T

Tablets

Sulfasalazine

S, T

Tablets

50 mg
5mg, 7.5mg, 10mg
500 mg

Added medicines
Hydroxychloroquin
e phosphate

S,T

Tablets

200 mg

Leflunomide

S,T

Tablets

10mg, 20 mg tab

Section: 3 – Antiallergics and Medicines used in Anaphylaxis
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Adrenaline Bitartrate
Chlorpheniramine
Maleate
Dexchlorpheniramine
Maleate
Dexamethasone

P, S, T
P, S, T

Injection
Tablets

1 mg / ml
4 mg

P, S, T

Syrup

0.5 mg / 5 ml

P, S, T

Hydrocortisone Sodium
Succinate
Pheniramine Maleate
Prednisolone

P, S, T

Tablets
Injection
Injection

0.5 mg
4 mg / ml
100 mg

P, S, T
P, S, T

Injection
Tablets

22.75 mg / ml
5 mg, 10 mg,
20 mg

Promethazine

P, S, T

Tablets
Syrup

10 mg, 25 mg
5 mg / 5 ml

Added Medicines
Cetrizine

P,S,T

27

Tablets

10mg

Syrup

5 mg/ml

<!-- page 28 -->

Section: 4 - Antidotes and Other Substances used in Poisonings
4.1: Nonspecific
Medicines

Category

Route of Administration/
Dosage Form

Activated Charcoal

P,S,T

Oral

Strengths

4.2: Specific
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Atropine Sulphate

P,S,T

Injection

1 mg/ml

Specific Antisnake
venom

P,S,T

Calcium gluconate

P,S,T

Injection

100mg/ml

Desferrioxamine
mesylate

S, T

Injection

500mg

Methylthioninium
chloride (Methylene
blue)

S, T

Injection

10 mg / ml

Penicillamine

S, T

Tablets or Capsules

250 mg

Dimercaprol

S, T

Injection in oil

50 mg / ml

Flumazenil

T

Injection

0.1 mg / ml

Sodium Nitrite

S, T

Injection

30 mg / ml

Sodium Thiosulphate

S, T

Injection

250 mg/ ml

Naloxone

P,S,T

Injection

0.4mg/ml

Pralidoxime Chloride(2PAM)

P,S,T

Injection

25 mg/ml

Injection Polyvalent
Solution/ Lyophilyzed
Polyvalent Serum

Added medicines:
N-acetylcysteine

P,S,T

Injection

28

200 mg/ml(5
ml)

<!-- page 29 -->

Section: 5 – Anticonvulsants/ Antiepileptics
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Carbamazepine

P, S, T

Tablets

100mg

Syrup

200mg
100 mg/5ml

Diazepam

P,S,T

Injection

5 mg / ml

Magnesium sulphate

S,T

Injection

500 mg /ml

Phenobarbitone

P,S,T

Tablets

30 mg, 60 mg

ST

Injection

200 mg/ml

P,S,T

Syrup

20 mg/5ml

P,S,T

Capsules or Tablets

50 mg,

Syrup

100mg

Injection

25mg/ml

Phenytoin Sodium

50 mg/ml
Sodium Valproate

P,S,T

Tablets

200 mg,

Syrup

500mg
200 mg/5ml

T

Injection

100 mg/ml

Added Medicines
Lorazepam

T

Injection

29

2mg/ml

<!-- page 30 -->

Section: 6 – Anti-infective Medicines
6.1 Anthelminthics
6.1.1 Intestinal Anthelminthics
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Albendazole

P,S,T

Tablets

400 mg

Suspension

200 mg/ 5 ml

Added Medicines
Piperazine

P,S,T

Tablets

4.5 gm

Solution

750mg/5ml

6.1.2 Antifilarials
Medicines
Diethylcarbamazine
citrate

Category

Route of Administration/
Dosage Form

P,S,T

Tablets

Strengths

50 mg

6.1.3 Antischistosomals and Antitrematode Medicines
Medicines

Category

Route of Administration/
Dosage Form

Praziquantel

S, T

Tablets

Strengths
600 mg

6.2 Antibacterials
6.2.1 Beta lactam medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Amoxicillin

S,T

Powder for suspension

125 mg / 5 ml

Capsules

250 mg, 500 mg

Capsules

250 mg, 500 mg

Powder for suspension

125 mg / 5 ml

Injection

500 mg

Ampicillin

P,S,T

30

<!-- page 31 -->

Benzathine
Benzylpenicillin

P,S,T

Injection

6 lacs, 12 lacs
units

Cefotaxime

S, T

Injection

125 mg, 250 mg
500 mg

Ceftazidime

S, T

Injection

250mg, 1g

Ceftriaxone

S, T

Injection

250 mg, 1 g

Cephalexin

P,S,T

Syrup

125 mg / 5 ml

Capsules

250 mg, 500 mg

Capsules

250 mg, 500 mg

Injection

250 mg

Liquid

125mg/ 5 ml

Tablets

625 mg

Powder for suspension

228.5mg/5ml

Injection

600mg, 1.2gm

Tablet

100, 200mg

Cloxacillin

P,S,T

Added Medicines
Amoxicillin+Clavulinic
acid

Cefixime

T

T

6.2.2 Other antibacterials
Medicines

Category

Route of Administration/
Dosage Form

Amikacin

S, T

Injection

Azithromycin

Ciprofloxacin

S,T

P,S,T

Hydrochloride
Co-Trimoxazole

P,S,T

Strengths
250 mg / 2
ml

Tablets

100, 250,500mg

Suspension

100mg/5ml

Injection

500mg

Injection

200 mg /100 ml

Tablets

250 mg, 500 mg

Tablets

80 + 400 mg

(Trimethoprim +
Sulphamethoxazole)

160+800 mg
Suspension

31

40 + 200 mg / 5
ml

<!-- page 32 -->

Doxycycline

P,S,T

Erythromycin

Tablets

100 mg

Syrup

125 mg / 5 ml

Estolate

P,S,T

Tablets

250 mg, 500 mg

Gentamicin

P,S,T

Injection

10 mg/ml, 40
mg/ml

Metronidazole

P,S,T

200mg,400
mg
Tablet
Injection

500mg/100
ml

Syrup

100mg/5ml

Nitrofurantoin

P,S,T

Tablets

100 mg

Sulphadiazine

S, T

Tablets

500 mg

T

Injection

500 mg, 1 g

Vancomycin
Hydrochloride

6.2.3 Antileprosy medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Clofazimine

P,S, T

Capsules

50 mg, 100 mg

Dapsone

P,S, T

Tablets

50 mg, 100mg

Rifampicin

P,S, T

Capsules or Tablets

150 mg, 300 mg

6.2.4 Antituberculosis medicines
Medicines

Category

Route of Administration/
Dosage Form

Ethambutol

P,S,T

Tablets

Strengths

200 mg, 400
mg, 600 mg,
800 mg

Tablets

50 mg, 100 mg,
300 mg

Isoniazid

P,S,T

Syrup

100 mg/5ml

Ofloxacin

S, T

Tablets

100 mg, 200 mg

32

<!-- page 33 -->

Pyrazinamide

Rifampicin

Syrup

50 mg / 5 ml

Tablets

500 mg, 750
mg, 1000 mg,
1500 mg

Capsules/Tablets

50 mg, 150 mg,
300 mg,450 mg

P,S,T

Syrup

100 mg / 5 ml

P,S,T

Injection

0.75 g, 1 g

P,S,T

Streptomycin
Sulphate

6.3 Antifungal medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Amphotericin B

S, T

Injection

50 mg

Pessaries

100 mg, 200
mg,

Gel

2%

Clotrimazole

P,S,T

50 mg, 100 mg,
150 mg,

Fluconazole

Griseofulvin

Nystatin

S, T

Capsules or Tablets

200 mg

P,S,T

Capsules or Tablets

125 mg, 250 mg

Tablets

500,000 IU

Pessaries

100,000 IU

P,S,T

6.4 Antiviral medicines
6.4.1 Antiherpes medicines
Medicines

Category

Acyclovir

S, T

Route of Administration/
Dosage Form

Strengths

Tablets

200 mg, 400 mg

Injection

250 mg, 500 mg

Suspension

400 mg / 5 ml

6.4.2 Antiretroviral medicines
6.4.2.1 Nucleoside reverse transcriptase inhibitors

33

<!-- page 34 -->

Medicines

Category

Route of Administration/
Dosage Form

Strengths

Didanosine

S, T

Tablets

250 mg, 400 mg

Lamivudine

S, T

Tablets

150 mg

S, T

Tablets

150 mg +
200 mg+ 30
mg

S, T

Tablets

150 mg +
300 mg

Stavudine

S, T

Capsules

15 mg, 30
mg, 40 mg

Zidovudine

S, T

Tablets

100 mg, 300
mg

Lamivudine + Nevirapine
+ Stavudine

Lamivudine + Zidovudine

ADDED MEDICINES
Stavudine+

S,T

Tablets

30mg+ 150mg

S,T

Tablets

300mg+

Lamivudine
Zidovudine+
Lamivudine+

150mg+

Nevirapine

200mg

6.4.2.2 Non-nucleoside reverse transcriptase inhibitors

Medicines

Category

Route of Administration/
Dosage Form

Strengths

200 mg,
Efavirenz

Nevirapine

S, T

S, T

Capsules

600 mg

Capsules

200 mg

Suspension

50 mg / 5 ml

6.4.2.3 Protease inhibitors
Medicines

Category

Route of Administration/
Dosage Form

Indinavir

S, T

Capsules

34

Strengths

200 mg, 400
mg

<!-- page 35 -->

Nelfinavir

S, T

Capsules

250 mg

Capsules

100 mg,
400 mg / 5ml

Ritonavir

S, T

Syrup

Saquinavir

S, T

Capsules

200 mg

6.5 Antiprotozoal Medicines
6.5.1 Antiamoebic and Antigiardiasis medicines
Medicines

Category

Route of Administration/
Dosage Form

Diloxanide Furoate

P,S,T

Tablets

Metronidazole

P,S,T

Tablets

200 mg, 400 mg

Injection

500 mg /100 ml

Strengths
500 mg

6.5.2 Antileishmaniasis medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Amphotericin B

S, T

Injection

50 mg

Pentamidine Isothionate

S, T

Injection

200 mg

Sodium Stibogluconate

S, T

Injection

100 mg / ml

6.5.3 Antimalarial Medicines
6.5.3.1 For curative treatment
Medicines

Category

Route of Administration/
Dosage Form

Artesunate (To be used
only in combination with
Sulfadoxine
+Pyrimethamine)

P,S,T

Tablets

50 mg

Tablets

150 mg base

Injection

40 mg / ml

P,S,T

Syrup

50 mg / 5 ml

P,S,T

Tablets

2.5 mg, 7.5 mg

Chloroquine phosphate

Primaquine

35

Strengths

<!-- page 36 -->

Pyrimethamine
Quinine sulphate
Sulfadoxine +
Pyrimethamine

P,S,T

Tablets

25 mg

P,S,T

Tablets

300 mg

ST

Injection

300 mg / ml

P,S,T

Tablets

500 mg + 25 mg

Medicines added
Clindamycin

S,T

Tablet

150, 300mg

6.5.3.2 For prophylaxis
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Medicines added
Mefloquine

S,T

Tablet

250 mg base

6.5.4 Antipneumocystosis and Antitoxoplasmosis medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Co-Trimoxazole

P,S,T

Tablets

80 + 400 mg

(Trimethoprim +
Sulphamethoxazole)

Pentamidine Isothionate

160+800 mg
Suspension

S, T

Injection

40 + 200 mg / 5
ml
200 mg

Section: 7 –Antimigraine medicines
7.1: For treatment of acute attack

Medicines

Category

Route of
Administration/
Dosage Form

Acetyl Salicylic Acid

P,S,T

Tablets

300 - 350 mg

Dihydroergotamine

S, T

Tablets

1 mg

36

Strengths

<!-- page 37 -->

Paracetamol

P,S,T

Tablets

500 mg

7.2: For Prophylaxis

Medicines

Category

Route of
Administration/
Dosage Form

Propranolol
hydrochloride

P,S,T

Tablets

Strengths

10 mg, 40 mg

Section: 8 – Antineoplastic, immunosuppressives and medicines
used in palliative care
8.1: Immunosuppressive medicines

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Azathioprine

T

Tablets

50 mg

Cyclosporine

T

Capsules
Concentrate for
Injection

10 mg, 25 mg,
50 mg, 100 mg
100 mg/ml

8.2: Cytotoxic medicines

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Actinomycin D

T

Injection

0.5 mg

Alpha Interferon

T

Injection

3 million IU

Bleomycin

T

Injection

15 mg

Busulphan

T

Tablets

2 mg

Cisplatin

T

Injection

Cyclophosphami
de

T

Cytosine

T

37

10 mg / vial
50 mg / vial

Tablets

50 mg, 200 mg

Injection

500 mg

Injection

100 mg/vial

<!-- page 38 -->

arabinoside

500 mg/vial
1000 mg/vial

Danazol

T

Capsules

50 mg, 100 mg

Doxorubicin

T

Injection

10 mg, 50 mg

Etoposide

T

Capsules

100 mg

Injection

100 mg/ 5 ml vial

Flutamide

T

Tablet

250 mg

5-Fluorouracil

T

Injection

250 mg / 5 ml

Folinic Acid

T

Injection

3 mg / ml

Gemcitabine
hydrochloride

T

Injection

L- Asparaginase

T

Injection

5000 KU.

Melphalan

T

Tablet

2 mg, 5 mg

Mercaptopurine

T

Tablet

50 mg

Injection

100 mg / ml

Methotrexate

T

Tablet

2.5 mg

Injection

50 mg / ml

Mitomycin-C

T

Injection

10 mg

Paclitaxel

T

Injection

30 mg / 5 ml

Procarbazine

T

Capsules

50 mg

T

Injection

10 mg

T

Injection

1 mg / ml

Vinblastine
sulphate
Vincristine

200 mg
1 gm

Added medicines
Carboplatin

T

Injection

150 mg, 450 mg
vial

Dacarbazine

T

Injection

500 mg

Daunorubicin

T

Injection

20 mg vial

38

<!-- page 39 -->

Ifosfamide

T

Injection

1 gm/2ml vial

Mesna

T

Injection

200 mg

Oxaliplatin

T

Injection

50 mg vial

Imatinib

T

Tablets

100 mg, 400 mg

Chlorambucil

T

Tablets

2 mg

8.3: Hormones and antihormones

Medicines

Prednisolone

Category

Route of
Administration/
Dosage Form

Strengths

Tablets

5 mg

Injection

20 mg, 25 mg (as
sodium phosphate
or succinate)

S, T

Raloxifene

T

Tablets

60 mg

Tamoxifen
Citrate

T

Tablets

10 mg, 20 mg

8.4: Medicines used in palliative care

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Morphine
Sulphate

T

Tablets

10 mg

Tablets

4 mg, 8 mg

Injection

2 mg/ml

Syrup

2 mg/5 ml

Ondansetron

S, T

Added Medicines
Filgrastim

T

Injection

1 ml vial

Allopurinol

T

Tablets

100 mg

39

<!-- page 40 -->

Section: 9 –Antiparkinsonism medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Bromocriptine
Mesylate

S, T

Tablets

1.25 mg, 2.5 mg

Levodopa+
Carbidopa

P,S,T

Tablets

100 mg+10 mg
250 mg+25 mg
100 mg+25 mg

Trihexyphenid
yl
Hydrochloride

P,S,T

Tablets

2 mg

Section: 10 –Medicines affecting the blood
10.1: Antianaemia medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Cyanocobalami
n

P, S,T

Injection

1 mg/ml

Ferrous

P,S,T

Tablets

Tablets equivalent to
60 mg elemental
iron

Oral solution

25mg elemental iron
(as sulphate)/ml

Sulphate/
Fumrate

Folic Acid

P,S,T

Tablets

1 mg , 5mg

Iron Dextran

S, T

Injection

50 mg iron/ml

Pyridoxine

P,S,T

Tablets

10 mg

10.2: Medicines affecting coagulation
Medicines

Category

Route of Administration/
Dosage Form

Heparin Sodium

S, T

Injection

40

Strengths
1000 IU/ml
5000 IU/ ml

<!-- page 41 -->

Protamine

S, T

Injection

10 mg/ml

Phytomenadion
e

P, S, T

Injection

10 mg/ml

Warfarin sodium

S, T

Tablets

5 mg

Sulphate

Added Medicines
Enoxaparin

T

Injection

40mg, 60mg

Section: 11 –Blood products and Plasma substitutes
11.1: Plasma Substitutes
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Dextran-40

P,S,T

Injection

10%

Dextran-70

P,S,T

Injection

6%

Fresh frozen
plasma

T

Injection

Hydroxyethyl
Starch
(Hetastarch)

S, T

Injection

6%

Polygeline

S, T

Injection

3.5%

11.2: Plasma fractions for specific use
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Albumin

S, T

Injection

5%, 20 %

Cryoprecipitate

S, T

Injection

Factor VIII
Concentrate

S, T

Injection

Dried

S, T

Injection

Dried

Factor IX
Complex
(Coagulation
Factors II,VII,
IX,

41

<!-- page 42 -->

X)
Platelet Rich
Plasma

S, T

Injection

Section: 12 –Cardiovascular medicines
12.1: Antianginal medicines

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

75mg, 100mg,
Acetyl salicylic
acid

P,S,T

Tablets

350 mg
soluble/dispersible

Diltiazem

S, T

Tablets

Glyceryl
Trinitrate

P,S,T

Sublingual Tablets

0.5 mg

Injection

5mg/ml

Tablets

10 mg,

Isosorbide 5
Mononitrate/

P,S,T

20 mg

Dinitrate
Metoprolol

30 mg, 60 mg

P,S,T

Tablets

25 mg, 50 mg

Injection

1mg/ml

Added Medicines
Clopidogrel

T

Tablets

75 mg

12.2: Antiarrhythmic medicines

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

Adenosine

S,T

Injection

3 mg/ml

Amiodarone

S, T

Tablets
Injection

42

100 mg, 200 mg
50 mg/ml (3 ml
ampoule)

<!-- page 43 -->

S, T

Tablets
30 mg, 60 mg

Diltiazem
T

Esmolol

T

Lignocaine

S, T

Injection

Injection

5 mg/ ml
10 mg / ml

Injection

1%, 2%

Tablets

250 mg

Injection

100mg/ml

Tablets

40 mg, 80 mg

Injection

2.5mg/ml

Hydrochloride
Procainamide
Hydrochloride
Verapamil

T

S, T

12.3: Antihypertensive medicines

Medicines

Category

Route of
Administration/ Dosage
Form

Amlodipine

P,S,T

Tablets

Atenolol

P,S,T

Tablets

Enalapril

P,S,T

Tablets

2.5 mg, 5mg

Maleate

T

Injection

1.25mg/ml

Losartan

S, T

Tablets

25 mg,

Potassium
Methyldopa

P,S, T

Tablets

Tablets

S, T

Sustained release
tablets or capsules
Sodium

2.5 mg,
5 mg
50 mg,
100 mg

50 mg

Capsules
Nifedipine

Strengths

T

Injection

Nitroprusside

43

250 mg
5 mg, 10mg
10mg, 20mg
10mg, 20mg

50 mg/ 5 ml

<!-- page 44 -->

Added Medicines

Hydrochlorthiazi
de

12.5,
P,S,T

Tablets
25 mg

12.4: Medicines used in heart failure

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

Tablets

0.25 mg

Injection

0.25 mg/ml

Elixir

0.05 mg/ml
50 mg / ml

Digoxin
S, T

Dobutamine

S, T

Injection

Dopamine

S,T

Injection

40 mg / ml

Hydrochloride
12.5: Antithrombotic medicines

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

75mg,
Acetyl salicylic
acid

P,S,T

Tablets

100mg,
350 mg
soluble/dispersible

S, T

Injection

Heparin
Sodium

Streptokinase

1000 IU /ml
5000 IU/ml

S, T

Injection

750,000 IU
15,00,000
IU

Urokinase

T

Injection

44

500,000

<!-- page 45 -->

IU/ml
10,00,000 IU/ml
New Category - ADDED
12.6 Hypolipidemic Medicines
Atorvastatin

P,S,T

Tablets

5 mg, 10 mg

Section: 13 –Dermatological medicines (Topical)
13.1: Antifungal medicines

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Miconazole

P,S,T

Ointment or Cream

2%

13.2: Antiinfective medicines

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Acyclovir

S, T

Cream

5%

Framycetin
Sulphate

P,S,T

Cream

0.5%

Methylrosaniliniu
m Chloride
(Gentian Violet)

P,S,T

Aqueous solution

0.5%

Neomycin +
Bacitracin

P,S,T

Ointment

5 mg + 500 IU / g

Povidone
Iodine

P,S,T

Solution or Ointment

5%

Silver
Sulphadiazine

P,S,T

Cream

1%

13.3: Antiinflammatory and antipruritic medicines

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Betamethason

P,S,T

Cream / Ointment

0.05%

45

<!-- page 46 -->

e Dipropionate
Calamine

P,S,T

Lotion

13.4: Astringent Medicines

Medicines

Category

Route of
Administration/
Dosage Form

Zinc Oxide

P,S,T

Dusting Powder

Strengths

13.5: Medicines affecting skin differentiation and proliferation

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Coal Tar

P,S,T

Solution

5%

Dithranol

T

Ointment

0.1-2%

Glycerin

P,S,T

Solution

Salicylic Acid

P,S,T

Solution

5%

13.6: Scabicides and Pediculicides

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Benzyl benzoate

P,S,T

Lotion

25 %

Added Medicines
Permethrin

S,T

Cream

5%

Lotion

1%, 5%

Section: 14 –Diagnostic agents
14.1: Ophthalmic medicines
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Fluorescein

S, T

Eye drops

1%

Lignocaine

S, T

Eye Drops

4%

46

<!-- page 47 -->

Tropicamide

S, T

Eye drops

1%

14.2: Radiocontrast media
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Barium Sulphate

S, T

Suspension

100% w/v, 250%
w/v

Calcium Ipodate

S, T

Injection

3g

Iopanoic Acid

S, T

Tablets

500 mg

Meglumine
Iothalamate

S, T

Injection

60% w/v (iodine
=280 mg / ml)

Meglumine
Iotroxate

S, T

Solution

5-8 g iodine in
100-250 ml

Propyliodone

S, T

Oily, suspension

500-600 mg / ml

Sodium
Iothalamate

S, T

Injection

70% w/v(Iodine
=420 mg / ml)

Sodium
Meglumine
Diatrizoate

S, T

Injection

60% w/v(Iodine
conc. =292 mg /
ml), 76%
w/v(Iodine conc.
=370 mg / ml)

Section: 15 –Disinfectants and antiseptics
15.1: Antiseptics

Medicines

Category

Route of
Administration/ Dosage
Form

Acriflavin+Glycerin

P, S, T

Solution

Benzoin
Compound

P, S, T

Tincture

Cetrimide

P, S, T

Solution

47

Strengths

20% (conc. for
dilution)

<!-- page 48 -->

5% (conc. for
dilution)

Chlorhexidine

P, S, T

Solution

Ethyl Alcohol 70%

P, S, T

Solution

Gentian Violet

P, S, T

Paint

Hydrogen
Peroxide

P, S, T

Solution

6%

Povidone Iodine

P, S, T

Solution

5%, 10%

0.5%,
1%

15.2: Disinfectants

Medicines

Bleaching Powder

Category

Route of
Administration/ Dosage
Form

Strengths

Powder

Contains not less
than 30 % w/w of
available chlorine
(as per I.P)

P, S, T

Formaldehyde
Solution

P, S, T

Solution

Dilute 34 ml of
formaldehyde
solution with water
to produce 100 ml
(As per I.P)

Glutaraldehyde

S,T

Solution

2%

Potassium
Permanganate

P, S, T

Crystals for solution

Section: 16 –Diuretics
Route of
Administration/ Dosage
Form

Strengths

Injection

10 mg/ ml

Tablets

40mg

Medicines

Category

Furosemide

P,S,T

Hydrochlorothiazid
e

P,S,T

Tablets

Mannitol

P,S,T

Injection

48

25 mg,
50 mg
10%, 20%

<!-- page 49 -->

Spironolactone

P,S,T

Tablets

25 mg

Section: 17 – Gastrointestinal medicines
17.1: Antacids and other Antiulcer medicines
Route of
Administration/ Dosage
Form

Medicines

Category

Strengths

Aluminium
Hydroxide +
Magnesium
Hydroxide

P,S,T

Omeprazole

P,S,T

Capsules

10 mg, 20 mg, 40
mg

Ranitidine

P,S,T

Injection

25 mg / ml

Tablet
Suspension

Added Medicines
Pantoprazole

T

Injection

40 mg

Famotidine

P,S,T

Tablets

20 mg

17.2: Antiemetics

Medicines

Category

Domperidone

P,S,T

Metoclopramide

Promethazine

Route of
Administration/ Dosage
Form

Strengths

Tablets

10 mg

Syrup

1 mg / ml

Tablets

10 mg

Syrup

5 mg / 5 ml

Injection

5 mg / ml

Tablets

10 mg, 25 mg

Elixir or Syrup

5 mg / 5 ml

Injection

25 mg / ml

P,S,T

P,S,T

Added Medicines

49

<!-- page 50 -->

Ondansetron

S,T

Tablet

4mg, 8 mg

Syrup

2 mg/ml

Injection

2mg/ml

17.3: Antiinflammatory Medicines

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

Added Medicines
5-Amino salicylic
Acid

S,T

Tablets

400mg

(5-ASA)
17.4: Antispasmodic medicines

Medicines

Category

Dicyclomine
Hydrochloride

P,S,T

Hyoscine Butyl
Bromide

P,S,T

Route of
Administration/ Dosage
Form

Strengths

Tablets

10 mg

Injection

10 mg / ml

Tablets

10 mg

Injection

20 mg / ml

17.5: Laxatives

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

Bisacodyl

P,S,T

Tablets, Suppository

5 mg

Ispaghula

P,S,T

Granules

17.6: Medicines used in diarrhorea
17.6.1 Oral dehydration salts

Medicines

Category

Route of
Administration/ Dosage
Form

Strengths

Oral Rehydration

P,S,T

Powder for solution

Glucose: 13.5 g/L
Sodium chloride:

50

<!-- page 51 -->

2.6
g/L
Potassium chloride:
1.5 g/L
Trisodium citrate
dihydrate+: 2.9 g/L

Salts

Powder for dilution
in 200ml; 500 ml;
1000ml. (As per I.P)
17.6.2 Antidiarrhoeal medicines

Medicines

Route of
Administration/ Dosage
Form

Category

Strengths

Medicines added
Zinc Sulfate

P,S,T

Syrup

20 mg/5ml

Section: 18 –Hormones, other endocrine medicines and
contraceptives
18.1: Adrenal hormones and synthetic substitutes
Route of
Administration/
Dosage Form

Strengths

Tablets

0.5mg

Injection

4mg/ml

P, S,T

Injection

100 mg / ml

S,T

Injection

40 mg/ ml

Medicines

Category

Dexamethasone

S,T

Hydrocortisone
Sodium Succinate
Methyl Prednisolone

5mg,
Prednisolone

P, S,T

Tablets

10mg,
20mg

18.2: Androgens
Medicines

Category

Route of
Administration/

51

Strengths

<!-- page 52 -->

Dosage Form

Testosterone

Capsules

P,S,T

Injection

40mg(as
undecanoate)
25mg/ml(as
propionate)

18.3: Contraceptives
18.3.1: Hormonal Contraceptives

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Ethinylestradiol +
Levonorgesterol

P,S,T

Tablets

0.03 mg +0.15
mg

Ethinylestradiol +
Norethisterone

P,S,T

Tablets

0.035 mg +1.0
mg

Hormone Releasing
IUD

T

Levonorgesterol
Releasing

IUD

18.3.2: Intrauterine devices

Medicines

IUD containing
Copper

Category

Route of
Administration/
Dosage Form

Strengths

P,S,T
18.3.3: Barrier Methods

Medicines

Category

Condoms

P,S,T

Route of
Administration/
Dosage Form

Strengths

18.4: Estrogens

Medicines

Category

Route of
Administration/
Dosage Form

Ethinylestradiol

P,S,T

Tablets

18.5: Medicines used in Diabetes mellitus

52

Strengths

0.01mg
0.05mg

<!-- page 53 -->

18.5.1: Insulins and other Antidiabetic agents

Medicines

Category

Route of
Administration/
Dosage Form

Glibenclamide

P,S,T

Tablets

P,S,T

Injection

40 IU / ml

Intermediate
Acting(Lente/NPH
Insulin)

P,S,T

Injection

40 IU / ml

Metformin

P,S,T

Tablets

500mg

Insulin Injection
(Soluble)

Strengths

2.5 mg,
5mg

Added medicines
Premix Insulin 30:70
injection

P,S,T

Injection

40IU/ml

18.5.2 Medicines used to treat hypoglycemia

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Glucagon

T

Injection

1mg/ml

Added medicines
25% Dextrose

P,S,T

Injection

100 ml

18.6 Ovulation Inducers

Medicines

Category

Route of
Administration/
Dosage Form

Clomiphene citrate

T

Tablets

Strengths

50mg,
100mg

18.7 Progestogens

Medicines

Category

Route of
Administration/
Dosage Form

53

Strengths

<!-- page 54 -->

Medroxy
Progesterone Acetate
Norethisterone

P,S,T

Tablets

P,S,T

Tablets

5mg,
10mg
5mg

18.8 Thyroid and antithyroid medicines

Medicines

Category

Route of
Administration /
Dosage Form

Carbimazole

P,S,T

Tablets

Strengths

5mg,
10mg
50µg,
Levothyroxine

P,S,T

Tablets
100 µg

Iodine

S,T

Solution

8 mg / 5 ml

Section: 19 Immunologicals
19.1: Diagnostic agents

Drugs

Category

Route of
Administration/
Dosage Form

Strengths

Tuberculin,
Purified Protein
derivative

P,S,T

Injection

1 TU, 5 TU

19.2: Sera and immunoglobins

Drugs

Category

Route of
Administration/
Dosage Form

Strengths

Anti-D
immunoglobin
(human)

S, T

Injection

300 µg

Polyvalent
Antisnake
Venom

P,S,T

Injection

10 ml

P,S,T

Injection

250 IU, 500 IU

54

<!-- page 55 -->

Antitetanus
Human
immunoglobin

Diphtheria
Antitoxin

S, T

Injection

10,000 IU

Rabies
immunoglobin

P,S,T

Injection

150 IU / ml

19.3: Vaccines
19.3.1: For Universal Immunisation

Drugs

Category

Route of
Administration/ Dosage
Form

B.C.G Vaccine

P,S,T

Injection

D.P.T Vaccine

P,S,T

Injection

P,S,T

Injection

Measles Vaccine

P,S,T

Injection

Oral Poliomyelitis
vaccine (LA)

P,S,T

Solution

Hepatitis B
Vaccine

Strengths

19.3.2: For Specific Group of Individuals

Drugs

Category

Route of
Administration/ Dosage
Form

Rabies Vaccine

P,S,T

Injection

Tetanus Toxoid

P,S,T

Injection

Strengths

Section: 20 – Muscle Relaxants (Peripherally acting) and
Cholinesterase Inhibitors
Drugs

Category

Route of
Administration/ Dosage
Form

Strengths

S, T

Injection

10 mg / ml

Atracurium
besylate

55

<!-- page 56 -->

Neostigmine

S,T

Pyridostigmine

S, T

Succinyl choline

S,T

chloride

Tablets,

15 mg,

Injection

0.5mg/ml

Tablets,

60 mg,

Injection

1mg/ml

Injection

50 mg/ml

Added drugs
Vecuronium

P,S,T

Injection

2 mg/ml

Section: 21 – Ophthalmological Preparations
21.1: Anti-infective agents
Medicines

Category

Route of Administration/ Dosage
Form

Strengths

Chloramph
enicol

P,S,T

Drops/Ointment

0.4%, 1%

Ciprofloxa
cin
Hydrochlor
ide

P,S,T

Drops/Ointment

0.3%

Gentamici
n

P,S,T

Drops

0.3%

Miconazol
e

P,S,T

Drops

1%

Povidone
Iodine

S,T

Drops

0.6%

P,S,T

Drops

10%,20%

Sulphacet
amide
Sodium

21.2: Antiinflammaory agents
Medicines

Category

Route of Administration/ Dosage
Form

Strengths

Prednisolo
ne

P,S,T

Drops

0.1%

56

<!-- page 57 -->

Acetate
Prednisolo
ne
Sodium

P,S,T

Drops

1%

Phosphate
21.3: Local Anaesthetics
Medicines

Category

Route of Administration/ Dosage
Form

Strengths

Tetracaine
Hydrochlor
ide

P,S,T

Drops

0.5%

21.4: Miotics and Antiglucoma medicines
Medicines

Category

Route of Administration/ Dosage
Form

Strengths

Acetazola
mide

S,T

Tablets

250 mg

T

Drops

Pilocarpin
e

S,T

Drops

Timolol
Maleate

P, S, T

Drops

Betaxolol
Hydrochlor
ide

0.25%,
0.5%
2%,
4%
0.25%,
0.5%,

21.5: Mydriatics
Category

Route of Administration/ Dosage
Form

Strengths

P,S,T

Drops/Ointment

1%

Homatropi
ne

P,S,T

Drops

2%

Phenyleph
rine

P,S,T

Drops

5%

Medicines
Atropine
Sulphate

57

<!-- page 58 -->

21.6: Ophthalmic Surgical Aids

Medicines

Category

Route of Administration/ Dosage
Form

Strengths

Methyl
Cellulose

T

Injection

2%

Section: 22 – Oxytocics and Antioxytocics
22.1: Oxytocics
Medicines
Methyl
Ergometrine

Category

Route of Administration/
Dosage Form

Strengths

Tablets

0.125mg

Injection

0.2mg/ml
200mg

P,S,T

Mifepristone

T

Tablets

Oxytocin

S,T

Injection

5 IU/ ml,
10IU/ml

Added medicines
Misoprostol

T

Tablets

100ug

Route of Administration/
Dosage Form

Strengths

Tablets

2.5 mg

Injection

0.5 mg/ml

Tablets

10 mg

22.2: Antioxytocics
Medicines

Terbutaline
Sulphate

Category

S,T

Added Medicines
Nifedipine

S,T

58

<!-- page 59 -->

Betamethasone

P,S,T

Injection

4 mg/ml

Section: 23 – Peritoneal Dialysis Solution
Medicines
Intraperitoneal
Dialysis Solution

Category

Route of Administration/
Dosage Form

Strengths
4Of approximate
composition

T

Section: 24 – Psychotherapeutic Medicines
24.1: Medicines used in Psychotic Disorders
Medicines

Chlorpromazine
hydrochloride

Haloperidol

Category

Route of Administration/
Dosage Form

Strengths

Tablets

25 mg, 50mg, 100mg

Syrup

25mg/5ml

Injection

25mg/ml

Injection

5mg/ml

P,S,T

S, T

Added medicines
Olanzapine

T

Tablets

5mg,10mg

24.2: Medicines used in mood disorders
24.2.1: Medicines used in Depressive disorders
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Amitriptyline

P,S,T

Tablets

25 mg

Fluoxetine
hydrochloride

P,S,T

Capsules

20 mg

Imipramine

P,S,T

Tablets

25 mg, 75 mg

24.2.2: Medicines used in Bipolar disorders
Medicines
Lithium
Carbonate

Category

Route of Administration/
Dosage Form

Strengths

T

Tablets

300 mg

59

<!-- page 60 -->

Added Medicines
Sodium

P,S,T

Valproate

200 mg,

Tablets

500mg

24.3: Medicines used for Generalized Anxiety and Sleep Disorders
Medicines

Category

Route of Administration/
Dosage Form

Alprazolam

P,S,T

Tablets

Diazepam

P,S,T

Tablets

Strengths
0.25 mg,
0.5 mg
2 mg,
5mg

24.4: Medicines used for obsessive compulsive disorders and panic attacks
Medicines

Category

Route of Administration/
Dosage Form

Strengths

Added Medicines
Fluoxetine
hydrochloride

P,S,T

Capsules

20 mg

Section: 25 – Medicines acting on the respiratory tract
25.1: Antiasthmatic medicines
Medicines

Category

Route of Administration/
Dosage Form

Beclomethasone
Dipropionate

P,S,T

Inhalation

Hydrocortisone
sodium succinate

Salbutamol
sulphate

Strengths
50 µg,
250µg/dose
100 mg,

P,S,T

Injection

200mg,
400 mg

P,S,T

Added Medicines

60

Tablets

2mg, 4mg

Syrup

2mg/5ml

Inhalation

100µg/dose

<!-- page 61 -->

Ipratropium
bromide

Inhalation

20µg/metere
d dose

Route of Administration/
Dosage Form

Strengths

Tablets

10mg

Syrup

15mg/ 5ml

Tablets

30mg

P,S,T
25.2: Antitussives

Medicines

Category

Codeine phosphate

S,T

Dextromethorphan

P,S,T

Section: 26 – Solutions correcting water, electrolyte and acid-base
disturbances
26.1: Oral
Medicines

Category

Route of Administration/
Dosage Form

Strengths

P, S, T

Powder for Solution

As per IP

Oral
Rehydration
Salts
26.2: Parenteral

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Glucose

P, S, T

Injection

5% isotonic,
10%, 15%.

P, S, T

Injection

5% + 0.9%

Normal Saline

P, S, T

Injection

0.9%

N/2 Saline

S, T

Injection

N/5 Saline

S, T

Injection

P, S, T

Injection

11.2% Sol.

Ringer Lactate

P, S, T

Injection

As per IP

Sodium

P, S, T

Injection

As per IP

Glucose with
sodium chloride

Potassium
Chloride

61

<!-- page 62 -->

Bicarbonate
26.3: Miscellaneous

Medicines

Water for
Injection

Category

Route of
Administration/
Dosage Form

Strengths

P, S, T

Injection

2 ml, 5 ml, 10 ml

Section: 27 – Vitamins and Minerals

Medicines

Category

Route of
Administration/
Dosage Form

Strengths

Ascorbic Acid

P,S,T

Tablets

100 mg, 500 mg

P,S,T

Tablets

250 mg, 500 mg

Multivitamins (As per
Schedule V of Drugs and
Cosmetics Rules)

P,S,T

Tablets

Nicotinamide

P,S,T

Tablets

50 mg

Pyridoxine

P,S,T

Tablets

25 mg

Riboflavin

P,S,T

Tablets

5 mg

Thiamine

P,S,T

Tablets

100 mg

Calcium
carbonate

Tablets
Vitamin A

Vitamin D (Ergocalciferol)

P,S,T

P,S,T

5000 IU,

Capsules

50000 IU, 100000
IU,

Injection

50000 IU/ml

Capsules

0.25 mg, 1 mg

Added Medicines
Calcium
gluconate

P,S,T

Injection

100mg/ml in 10
ml
ampoule

62

<!-- page 63 -->

SCHEDULE-II
FORM - I
PROFORMA FOR APPLICATION FOR PRICE FIXATION / REVISION OF A NEW DRUG
FORMULATION RELATED TO NLEM FORMULATION
(See paragraphs 2(u),5,7,8,9,15)

1.

Name of the formulation:

2.

Name and address of the manufacturer/importer :

3.

Name of the Marketing Company, if any:

4.

Composition as per label claimed and approved by Drug Control Authorities:

5.

Drugs Control Authority Permission Number and Date (copy to be enclosed):

6.

Date of commencement of production / import:

7.

Type of formulation (Tablets/ Capsules/ Syrup/ Injection/ Ointment/ Powder etc.):

8.

Size of packs (10’s/ 100’s/ 1 ml/ 2 ml/ 10 ml/ 5 gms/ 10 gms etc.)

9.

Therapeutic category/ use of the formulation.

10. The Retail Price claimed for approval
11. Reason for submission of application for price fixation / revision.
12. Any other information relevant to product and its process of manufacturing/ packaging/
distribution.
_____________________________________________________________________________

The information furnished above is correct and true to the best of my knowledge and belief.

Place:

Authorized Signatory:

Name:
Date:

Designation:

63

<!-- page 64 -->

SCHEDULE-II
FORM - II
1.
2.
Sl.
No.

PROFORMA FOR SUBMISSION OF REVISED-PRICES FOR SCHEDULED FORMULATIONS
(See paragraph 16)
Name and address of the manufacturer / importer / distributor.
Name and address of the marketing company, if any.

Name
of
the
Product
(Formulation and its dosage
forms)

(1)

(2)

Composition
of scheduled
formulation/
new drug

(3)

Pack
Size

(4)

WPI
change
w.r.t
preceeding
Year

Price to retailer (incl. of E.D.)
(Rs.)

Maximum Retail Price (incl.
of E.D.&Taxes)

Ceiling
Price
(Notified)

(Rs.)
(Rs.)
Pre-Revised

Revised

Pre-Revised

Revised

(6)

(7)

(8)

(9)

(5)

Scheduled Formulations
Own Manufactured Formulations

Purchased/Imported Formulations

Notes:- In case of purchased formulation, name of the manufacturer shall be indicated.
The information furnished above is correct and true to the best of my knowledge and belief.
Place:

Authorised Signatory:
Name:
Designation:

Date:

64

(10)

Effective
Batch
No. and
date

(11)

<!-- page 65 -->

SCHEDULE-II
FORM – III
PROFORMA FOR QUARTERLY RETURN IN RESPECT OF PRODUCTION/IMPORT AND SALE OF NLEM DRUGS
(See paragraphs 21(1))
1. Name and address of the manufacturer/importer:
2. Name and address of marketing company, if any:
3. Details of production/import and sale for the Quarter of a Year: …………………
TABLE-A
Name of the
Scheduled
Formulation

Composition
/Strength

Dosage
Form

Unit(No/
kg/Ltr)

Production/Import Level
Previous
Year

(1)

(2)

(3)

Name of the
Bulk Drug/API
used in
Scheduled
Formulation

Unit
(Kg/
Ltr)

Installed
Capacity

(1)

(2)

(4)

(5)

Domestic Sale

Current Year
1
Quarter

st

2
Quarter

nd

3
Quarter

rd

4
Quarter

th

(6)

(7)

(8)

(9)

Previous
Year

(10)

Current Year
1
Quarter

st

2
Quarter

nd

3
Quarter

rd

4
Quarter

th

(11)

(12)

(13)

(14)

TABLE-B
Production/Import Level
Previous
Year

(3)

(4)

Domestic Sale

Current Year
st

1
Quarter
(5)

nd

2
Quarter
(6)

rd

3
Quarter
(7)

th

4
Quarter
(8)

Previous
Year

(9)

Current Year
st

rd

th

2 Quarter

3 Quarter

4 Quarter

(10)

(11)

(12)

(13)

Constraints, if any:
Note: (1) Production outsourced / carried out on job work basis should also be included
The information furnished above is correct and true to the best of my knowledge and belief.
Place:
Date:
65

nd

1 Quarter

Authorised Signatory:
Name:
Designation:

<!-- page 66 -->

SCHEDULE-II
FORM - IV
PROFORMA FOR SUBMISSION OF THE DETAILS IN RESPECT OF DISCONTINUATION
OF THE PRODUCTION AND/ OR IMPORT OF SCHEDULED FORMULATION
(See paragraphs 21(2))
1. Name of the formulation:
2. Name and address of the manufacturer/importer :
3. Name of the Marketing Company, if any:
4. Composition as per label claimed and approved by Drug Control Authorities:
5. Drugs Control Authority Permission Number and Date (copy to be enclosed):
6. Celling Price and date of notification:
7. Existing maximum retail price (MRP) and its effective date:
8. Therapeutic category as per NLEM:
9. Date of commencement of production / import
10. Proposed date of discontinuation:
11. Reasons for discontinuation of production / import:
12. Year-wise Production/Import during the last 5 years including current year
13. Year-wise sale during the last 5 years including current year
14. Whether any new drug as defined under Proviso of Definition of “New Drug” under
DPCO, 2013 has been launched or intended to be launched. If so, the details thereof:
15. Any other information relevant to discontinuation of scheduled formulation:

Authorized Signatory:
Place:
Name:
Date:
Designation:

66

<!-- page 67 -->

SCHEDULE-II
FORM - V
PROFORMA FOR PRICE LIST
(See paragraphs 2(x),24,25,26)
1. Name and address of the manufacturer / importer / distributor.
2. Name and address of the marketing company, if any.
TABLE-A
Sl. No.
(1)

Name of the Product (Formulation and its dosage
forms)
(2)
Scheduled Formulations
Own Manufactured Formulations

Composition approved by
Drug Control Authorities
(3)

Pack
Size
(4)

Price to retailer
(incl. of E.D.) (Rs.)
(5)

Maximum Retail Price (incl.
of E.D.&Taxes) (Rs.)
(6)

Pack
Size
(4)

Price to retailer
(incl. of E.D.) (Rs.)
(5)

Maximum Retail Price (incl.
of E.D.&Taxes) (Rs.)
(6)

Purchased/Imported Formulations

TABLE-B
Sl. No.
(1)

Name of the Product (Formulation and its
dosage forms)
(2)
Non-Scheduled Formulations
Own Manufactured Formulations

Composition approved
Drug Control Authorities
(3)

by

Purchased/Imported Formulations

Notes:-

In case of purchased formulation, name of the manufacturer shall be indicated.

The information furnished above is correct and true to the best of my knowledge and belief.
Authorised Signatory:
Name:
Designation:

Place:
Date:
67
