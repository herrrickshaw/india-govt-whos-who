---
doc_id: "eea8b08de91ba2eb"
source_url: "https://hpa.haryanapolice.gov.in/Documents/StandingOrder/9.pdf"
ministry: "Haryana Police Academy, Haryana"
title: "View"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5aeac8e45afc9a48"
---

<!-- page 1 -->

{l
POLICE DE ARTMENT

I.IARYANA STATE

DIRECTOR GENERAL'S STA.NDING ORDER NO. I/ 3
S rr oject

/2005

Promotion of the NGOs/ORs after completion of '!6 years, 30 years
and 35 years
Para-Vlll of the Standing Order No.103/2003 is modified as under -

All Corrstables who are given promotion under abrove nrentioned
icrrerne will be deputecl for two rnonths trairting progranrnle within the next one year

:oi lvfrr(jn syllaDus shall be prescribed by the Director, Haryana Police Acadenry,
i\.,l"r.rrrLrr-rLrr Tlre objective of the training to equip EIASls and E/HCs to assist the

!,$'rrl:ri;

'irf'-e

n'",eslig.rting Officers rn investigation. They shall be suitably trained to equip thern as

iernr readers to acl as ln-charges of Guards, Patrol PartylEscort Party, PCRs, Nakas,
t,,'

ir.'l;rc-,r Cycle riders etc. Tlrey may also be trainecl in conducting personal searches,

';etrrcle searches, corlbing operations, VIP Security cluties and law and order duttes,
The above guidelines/instructions may be cornplied witlr meticr-rlously.
i

Director Generd

lice, Haryana

.ii

'/-\ 0.\
I

;rir.

liz

-.,i.:r -..u.z /

(:

r--

")-,) ,.:./ It Ii.i: il'ateci: Purci*;ula iite )) i^ i i -.t 5'

--\ iii:1\ is Iurn aitieti tu sil ileaci oi Folrr:s ijllices tn iiar.,'ana tirr
:ilrci rlrirLron rlr)d strtct conrpliance.

,B )irarls

I

I

.i"-

'r

L)rtrutr,' Superrnten.lenl
i''.rr ,l-.lrrcctru Gcrtcral ,-rlP,:lie c. I{arvana.

/+L'

t.

. :..:

.;l'.i '.a) !'

I
