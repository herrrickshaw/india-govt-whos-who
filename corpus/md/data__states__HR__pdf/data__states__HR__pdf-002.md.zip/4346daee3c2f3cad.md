---
doc_id: "4346daee3c2f3cad"
source_url: "https://haryana-rtsc.gov.in/public/storage/guidelinesnew/xEqR4JPWuDSemhgnVprd6WedR4XzS9iV44N5fLx3.pdf"
ministry: "Haryana Right To Service Commission, Haryana"
title: "Instruction for Guidances of Designated Officer"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "45aecd4d43be1d41"
---

<!-- page 1 -->

HARYANA RIGHT TO SERVICE COMMISSION
S.C.O. No. 38 & 39 (2"d F,LOOR), SECTOR r7-A, CHANDIGARH-160017
webslte- https: / / haryana -rtsc.Eov.in/ Tele phone: O172-2711O5O

No. Z6S+

tl.o G. 2.3

Dated:

To
I . All Administrative Secretaries in the State

2. All Head of the Department in the State.
3. All Deputy Commissioner in the State.

General instructions for gu idance of Designated Olficer under
Section 17 (11 (sl of Haryana Rieh t to Service Act. 2O14.

Subject:

Sir/Madam,

I have been directed to invite your kind attention on the subject
cited above and to communicate that Section 17(1)(9) of the Haryana Right to
Service Act, 2074 empowers the Communication to Issue general instructions
for the guidance of Designated Officers, the First Grieuance Redressal Authoity,

and the Second Grieuance Redressal Authority. In exercise of this power, the
Commission has issued General Instructions for guidance of the Designated
Officers. A copy ofthese General Instructions has been annexed to this letter.

In this context, following is requested
i)

Please take a note of these General Instructions in case you are the
Designated Officer for any notified Seruice; and/or

ii)

Plea.se disseminate the General Instructions to your subordinate
Officers who have been entrusted the duties of Designated Officer.

This issues with the approval of Chief Commissioner, Haryana
Right to Service Commission.
Yours Sincerely

{b*

(Sube Khan)
Under Secretary-cum-Registrar
Haryana Right to Service Commission
Email:- rtsc-h
ov.tn

<!-- page 2 -->

sir, Section 17(1Xg) of the Act authorizes the Commission to lssue general instructions, not
inconsistent with the provisions the Act for the guidance of DO/FGRA/SGRA. A draft
guidelinein this regard for the DO is submitted for you kind perusal.

1. Timely Service Delivery:
aJ Prioritize the timely delivery of services to the eligible persons
ensuring adherence to the stipulated timeframes mentioned in the
Gazette Notifications relevant to your sphere of duties.

b) Proactively monitor pending service requests and take necessary
actions to expedite their resolution. Auto Appeal Software (AAS) be
checked at regular intervals keeping in mind the number of
applications received for service delivery to check for pendencies.

c) lf the application is incomplete or essential documents are missing,
sensitively communicate thc requirements to the citizen well in
advance, allowing them sufficient time to provide the necessary
information. This ensures that the citizen is aware of the deficiencies
and can rectiry them within the prescribed time limit.

2. Transparent Communicationi
a) Maintain transparent and regular communication with citizens
regarding their service requests.

b) Provide updates on the status of requests, additional requirements,
and estimated timelines for resolution.
c) 'l'o avoicl last-minutc rejectlons, review the contents of the citizen's

application in advance and communicate any deficiencies, if found,

to the applicant. The tendency to reject the application at the fag
end of the prescribed time period, on grounds of deficiency in the
application, must not be there.

d) Provide logical and self-contained reasons, citing relevant rules for
any rejections, if any.

3. Documentation and Record-Keeping:
a) Maintain accurate and up-to-date records of all service requests
received, including relevant details, actions taken and outcomes
as per Section 5 (13l of thc Act rcad with llegulation 4 of'the

Haryana Right to Service l{ules, 2014.

b) Ensure proper documentation of interactions, communications and
decisions related to service delivery.

c) Safely store and organize records for easy retrieval and reference as
mandated by the Act or the Commission.

4, Effective Examination of Subordinate Submissions:
a) When reviewing submissions or proposals made by subordinate
staff, do not accept them on face value.

b) Criticatly examine the submissions, ensuring their accuracy,
completeness ancl adhercnce to rclevant guidelines, procedures,

<!-- page 3 -->

and legal requirements.

c) Verify the information provided, conduct independent assessments
if necessary, and seek additional inputs or clarifications when
warranted.

5, Capacity Building of self and subordinate staff:
aJ Train your subordinate staff to enhance their knowledge and sk rs

in dealing with the cases of serwice delivery.

b) Stay updated on relevant laws, regulations, and procedures
governing service delivery and train your subordinates on the same.

c) continuously improve your citizen service skilrs, effecEive
communication and conflict resolution abilities.

6. Coordination with Relevant Departments:
a) Collaborate and coordinate with the concerned departments or
agencies to cnsure smooth service delivery.

b) Establish effective channels of communication to obtain necessary
information or support required for resolving service requests.

c) Regularly engage in interdepartmental meetings to address systemic
issues and streamline service delivery processes.

7. Monitoring and Evaluation:
a) comply with the monitoring and evaruation systems estabrished by
the Haryana Right to Service Commission.
b) Carry out a self-evaluation regularly and actively seek feedback to
ide ntify arcas tirr improvement.

8. Public Awareness and Outreach:
aJ Actively engage with citizens, addressing their queries and clari$ring

doubts related to service delivery.
