---
doc_id: "1edb2d2d26bbdd54"
source_url: "https://cdn.s3waas.gov.in/s3a01a0380ca3c61428c26a231f0e49a09/uploads/2022/04/2022041949.pdf"
ministry: "Karnal"
title: "Tender for refilling_compatible toners & General spares (3 MB)"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "315d3b8e4e80ce0f"
---

<!-- page 1 -->

.,H

3l

.t

+

-

o)

a

1fr

-;l
rt
il I
4

nq

{+
i+*s
Ti?4

+# l#d
& +ieIAd,
c!

ry
e)
4

4J

+

d',ff9$&:
3l 4aw

+
i
A*A
3
I

4.o],

-t

&

-+r

.a ft
*
s
iq
i
st
wT a g L 1$ I

^.1
qii ^1

el

='
x
-i.

-+.i

4d 9y

=

0e
-.: -r
-rg
ao

;Hslig

Bq F++434

./

o)

fi

E

d_r

'r' 3 N g a 4,

gs F d "'l
2-4
=il
x€l

€

I
-'{
63o

F-q

.{

€a
ill$4+4
\=

5al

tr/

<!-- page 2 -->

N) P

d

(D

lo
l1

=.

!

w

X
N

o

f
--.
o

Ol

N)

-

N.)

N

of
o 8q

o,

o)

€

{

-

o 6!

N)

N
!
6

=. N t\)
d

a

o

o)

- -

UJ

TI T o I.
f\) N) t\)
Ol
F
F F Ol TI 'Tl
!

'Tl

o o o

d
j-.

N)

LAJ

(,

O

(,
(r)

@

F t-

CD

o

d

=.
o- =. =. =. --.
tq ta ta xl la

€ 5s -T' -! I-o T' -!

'Tl

N
F

@

N.)

@

ul

ts

!D
o
:1

d

is

o

v

=
OJ
gq
o

t-

a

v

(D

=
gq

l(Jl
P

s{

z

vd=

o

N=

crcl

-J

I

o
z=
o, oo

(')

d

o)

d

LP

O)
(, ul
P Ol
o !F o
(, P
U)
(,
F
qJ
(,

w T1 !D ul

4

OJ

z

vr

i

N

,q

tq

NJtv!
al

o)

@

T
!

OJ

T
!
t-

ol N

@ (, ts

I-0 T T
T' !

o o o

ga

=. =.

@

P

.\

F

N
(/l N)

(Jl

(D

o)

-

o

5

o
tn

=.
CL
gq

-

q,

-(1

o

f

-{
o

at

=!

F
o

so

4.

o)

3

l

-o

0,

In
T'

OJ

zq, o
5
3 o
o

o

!
=.
5

-o

o,

oo-

f f, f, 33

r)
o) o)

(,r)

- t- t-o - r lr o
t- o o o o o
@ - - 1 I- o
o
o
o F ts
f\) 5

&f

LN

P

e
o:'
qtO
=3q .3* q .)m Flv FLfl (tl !oo
_3*

xo FX
NY

N=

o)

c) c) o

ul F

f, a f f f,

o)

Ol

co o o o o o

@

F

o,

(.) a)

F \

o

Tt

-

T'

d

.D

OJ

=
o

d

-@

!o

o o o oH
35 F6 (oN) q-dur
c) O
o
cmo)" oaoq- O
o,
o)
o)
E3
Lrl
e
(,
a
-=
+=
-'Tl
dtJ
4
?O)
=
o9
<#
>
o
r)(o
ts
(, =.
oo
oo
.<
oCO Q=6
x(o o00 t\)
P
oJoa^
o o
P6) on 9- P q1^ 3J@
atl UJ
U)
O
o,
(, (,
of
(.)
o
O
u'l
P !
T
-{q
-rQ
o-.
{ =@
<>N)
o
=V
oN)
co
#f
f;e.
xN)
o:
Oul
F
O
f@
fo
lo
N
5
alN
s=
z t--P
T - T o nn
m
m
a)
O c)
o
q) - I
o)
o)
o)
! T' E

3 o
f

l

r')

o

oa

=.

f

o)

(^)

ts
O

E'

z

o

0a

=.
o-

e

o
o)

F

ts

o

o
6

00

N
t!

o

t,
P

j-.
o ota
=
o o

-G' f,
o)

r')

N

ts

'Tl

r')

T'

o,
a

T

(1
=.

o

o,

ts

F !^,

P

=
o !c) !
o o
.) r) o
r)
o c)
'Tt an o) o, de + q) 50)
o,
TT

v

o)

o)

(.) r.)

3 =.
=.
=.
=. c =.
oo.
ga
tq
n
o o
o o o
o

<-

- 5lv\

o

o)

P ts ts ts ts
@ \ P 9t
o (o

N

o I
I r)
o) o) 1

P

f,
f, - f, + 3 f f,
:-.

:'-

(tl

@

3

-

o

@
o,

u

lw

7
o

q
zo

CL

o

=
o

c')

r)
o)

o)

N

N) N

N
(,

P

-

l5

.E

z l!

lo
la

v,

o
@

O

ts ts ts
ul o
N)
! ul N
ts

+ t

(D

6

I
T' ! T'
t- to) o) OJ

- -0
o o o
- -o -

!^,

ld

Iq,

lttr
ro

a
qi
I'

_ir

g

--

=.E
o(D
.+-

36

o,

I

3

-A

o'

Vl

vl

(

o
vl

:oo-o
oF

o-.

3
3

dq

:'o

o
o

5

o
vl

!to)

o

f+
gq

CL

gt|

f.

o
o,

o
o
=
o

g

;q
AE Ho
:-o

.+F

-g

co::o

a9

o

ooJ

rn- O
\-

;o f .+r
o
_-.(D
=oi(, .i:o) f
='
6E
o=

(D

o

9.r
OF
(-) \.
r:c)

Evl
a\.

--

o

EL

rct
0,

-- oo
o'q
LO_
=: o-

thf
q

o

ot o)

J

=
m
f1

vo
o
3

to)
o*
tod

d-

o

=
CL
o

{o

.o cn o)
-96 5ni

ii'q
f-{

=*c
o x'r5
il'9
o-<

ol

6q

-

O

8
nE; +'9o'
f f

o_a3*

i aqE

_.t

5a
oJ .<

3.8
-i(D

o-9

r-r
e
a n'qg
=.-d 69
-*
o)^

q- +6 g

PT

tlq'
l(.t
l.+

lo
lo
lo
l=
lr+

5til
ttr lr+

#to
;' l-

515
CL l-r'

lo'

=t9
r)
olo lf.

r-

or lc

;E

#la

^l<
{l=

lo
tl=

lr+
lc)

lz
lo

<!-- page 3 -->

J(D

u)N

i1 + ii

srr F

igiillil*3
i*ilrsi=r[

illFlo

-{ l|,

l5

'lo li

Pl{

UJ

N
N)

N

:5

foJ
.+
.]i

3€
o:t

3q
c

O5(D

d.

9o,
of

-o
c@

r+
J
of

Oo,
fvl

f
o
i+

vr

o

o-

f

OJ

-

o
o
o

f+

o
vl

5'

Ctrl

2,

J

ga

o

tf
(DO-

i l*a g ; i*ee:i;g[

r
i+g
+
q

E1lE*;11Fi[lEiili
1d
iil;
a
+[Fag]**3
e
g
ri;aiA3Es
a
I= sH:
H..q
"- ;aEfAHq+;

fr
rFEFrl*l;
HFq F i
Fgi4gItsE

g$EigBriiicl$i-a*ig'
-$ii
iige=;+cri
g
f 1g i
a*
ii$r,nr
+
3figiidi*
e
s*rH[3
3=a =*igF;gs-iq
i *;=;i5.i gs_
+3E.qTg.lq

; ti3g fr1 *gg +

66 oo
R
l/r5€
qo
o-=
o
6'9
o +

='.

3 '+
<.
il9 EE

\ -6
9?-. -(D
='=o
=+t
a 9,, s =o
il?

r
s Pq oo
(Dd
3o,B
tno
83
(D

fr+X ='

5a
9
o, cL

rD

o

FT

3
cvl

vl

-4.
o)

o
3
o)
o

=

o
o
f
o
o
o)
f

o-

o)

f
q

OJ

3

c='

:f

o)

c)
!

r)
r) m om T
o) o)

Ol (tl

F

T I T I
T' T' T' T'

F :

-

f

{ :

J

- -

P

CL

NJ

@

o
(,

!

= l

\,1

N t9
N N

TD

- -

o

6

f

o

fr -

o
5 O
z t-

l\) N)
O F
t\)

a

.D

5

ul

LA)

- -

+

o-

Ol

(J)

lJ
(rl

OJ
o
l
l
6
vr
t-I t- o o o o o
F EP
I
tJ1 @ a
llJ
'Tl
'T| 'Tl TI o o (t T' o =
o o
o
o
d
d
4
+ o
(, vao, te=o, ts
(o O
o
l\) t\) a
o
6)
o o o o N F
LP
T' ts
(, ! N)
Ol Ol F
lJ)
O u)
F F Ol 'Tl an
F
-lI ts
(, 'Tl u)
u,
O (-rl
o lJl
Ol
o v c
o- o T' T'
z o CL
(Jt o T' F (t'l
o
f
6
€
(tl
CL 5
N)

vI o
ol o

F
l\)
!
t
ol

o
3

!

.) r)
I
o,

'0 o)

:

ts ts ts F F
P ts ts P F
Ol (, 5 UJ N) F o :o
:o 6

f
r
= o 0 o o o o o o)r o,t- t- t-o) t-o)
o) o) o o
o o) o o

o-

5

!- I

l\) N

tt, I c) r) c) I
T' o) OJ q, !
o)

o
g

l=

lct.

TI
=
!

vr

o-

(D

vt

dt9
eli;'
aqt*+f,
o
Igl
a
i;*gi
el
- qd
oqox
EE'
Plil
3
BE 9=
g*ig
d
.: 8< 9+
r

+ 6-{
o
oo

=o
or='(D
=m
d-3

()F

P

*

<!-- page 4 -->

I

I

\

\

OJ

5

o,
a

i\

=

l=+

lE
\

Y4

?bi

(D

+

l$=
lF5

o-

$
l$+
leo e'

he s

E= E

€
I:B
[s: E

='

e 3E

lh1

l.:.

e
Eq
ld-s

E
l*g
a
1il3 4

*
Fa
l3='

P

AE
lilE 3
Li3 r
lsB gfr
lis*

g:

q.<

c,
o
tt,
= 3

IO

asSH
6
si
qd
€
vtulo

PP
PO
