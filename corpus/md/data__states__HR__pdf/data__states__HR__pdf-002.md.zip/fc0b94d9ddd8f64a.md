---
doc_id: "fc0b94d9ddd8f64a"
source_url: "https://dhbvn.org.in/staticContent/employeearea/Office_Orders/Gazetted_Section/2026/498_25.08.2026_SE.pdf"
ministry: "Dakshin Haryana Bijli Vitran Nigam (DHBVN), Haryana"
title: "Office Order"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "bd74b9e554f3f4a1"
---

<!-- page 1 -->

DAKSHIN HARYANA BIJLI VITRAN NIGAM LIMITED
(A Power Distribution & Retail Supply Utility, Government of Haryana)
52. (AN ISO 900:2008 Compliant Utility, CIN No, U99999HRI999SGC03465)
(7 के Registered Office: Vidyut Sadan, Vidyut Nagar, Hisar - 25 005 (Haryana)
Office of the Superintending Engineer/Administration, DHBVN, Hisar
www.dhbvn.org.in #®0662 — 223439; Email: seadmn@dhbvn.org.in & supdtsl@dhbvn.org.in
हे
Office Order No. 44§ /SE/Admn. Dated: 25.08.2026
Er. Sankalp Parihar, (7EE50), SE/Const. Circle, DHBVNL, Hisar will
look after the work of SE/Energy Audit, DHBVNL, Hisar also in public interest in
addition to his own present duties without any extra remuneration during leave
period of Er. Manju Punia, SE/Energy Audit, DHBVNL, Hisar.
This carries the approval of Managing Director, DHBVNL, Hisar.
<r Y
72४7]
5804 वायदा
DHBVNL, Hisar
Endst. No. Ch- 34 /DHGE-350/Vol-I Dated: 2S .08.2026
A copy of the above is forwarded to the following for information and
necessary action please:-
4. | “DGP-cum-Director/Vigilance, Panchkula.
2. All CEs/SEs/XENs in DHBVNL.
3. Legal Remembrancer, HPUs, Panchkula.
4. CFO, DHBVNL, Hisar.
5. All CAOs/FAs in DHBVNL.
. 6. Company Secretary, DHBVNL, Hisar.
7. CCO, DHBVNL, Hisar.
8. All Under Secretaries in DHBVNL.
9. Sr. AO/Pay & Accounts, DHBVNL, Hisar.
40. Supdt./S-II/APAR, O/o SE/Admn., DHBVNL, Hisar.
4{. Er. Sankalp Parihar, SE/Const. Circle, DHBVNL, Hisar.
Under See Secretary/HR-|
DHBVNL, Hisar
Copy to:-
4. SPS to Managing Director, DHBVNL, Hisar.
2. SPS/PS to Director/OPs/Projects/Finance, DHBVNL, Hisar.
3. PA to CE/HR& Admn., DHBVNL, Hisar.
4. Personal file of the officer concerned.
Posting Orders/2026 24
