---
doc_id: "e4a7cd61e5fb1af8"
source_url: "https://fdaharyana.gov.in/actsNotifications/GSR_144(E)_dated_17_02_2017.pdf"
ministry: "Food and Drugs Administration Department, Haryana"
title: "GSR 144(E) dated 17_02_2017"
date: ""
pages: 3
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "45252d12ec67a2d2"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)

izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 117]

ubZ fnYyh] 'kqØokj] iQjojh 17] 2017@ek?k 28] 1938

No. 117]

NEW DELHI, FRIDAY FEBRUARY 17, 2017/MAGHA 28, 1938

वा य और प रवार क याण मं ालय
( वा य और प रवार क याण िवभाग)

अिधसूचना
नई द ली, 17 फरवरी, 2017
सा.का.िन. 144(अ).—के

ीय सरकार का यह समाधान हो गया था क ‘ओसेलटािमवीर फासफे ट’ और

‘जनिमवीर’ औषिधयां महामारी के कारण उ प
िहत म आव यक थ और उ

होने वाली आपातकालीन अपे ा

को पूरा करने के िलए लोक

औषिधय और उन पर आधा रत िन मितय के दु पयोग के िनवारण के िलए उनके

िविनमाण, िव य और िवतरण को िविनयिमत और िनबिधत करना आव यक और समीचीन था;
और के
ारा द

ीय सरकार ने औषिध और साधन साम ी अिधिनयम, 1940(1940 का 23) क धारा 26ख

शि य का योग करते ए, भारत के राजप , असाधारण, भाग II, खंड 3, उपखंड (i) म कािशत

अिधसूचना सं यांक सा.का.िन. 677(अ), तारीख 15 िसत बर, 2009 ारा यह िनदेश दया था क कोई
‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’ औषिध वाली कसी िन मित का, उ

ि

अिधसूचना म िविन द रीित के

िसवाय, िव य या िवतरण के िलए िविनमाण नह करे गा या उसका िव य या टाक नह करे गा या िव य के िलए
सं द शत या

थािपत नह करे गा या िवत रत नह करे गा;

और औषिध तकनीक सलाहकार बोड ने औषिध और साधन साम ी िनयम, 1945 क अनुसूची भ म
िन द औषिधय के सम प ‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’ औषिधय के िव य को िनबिधत करने के
पर तारीख 15 नव बर, 2016 को िवचार कया और यह िसफा रश क क तारीख 15 िसत बर, 2009 क
अिधसूचना सा. का. िन. 677(अ) वापस ले ली जाएगी और उ औषिधय को उ िनयम क अनुसूची ज1 म
िन द औषिधय के समान िव य के िलए अनु ात कया जाएगा;
अतः अब, के ीय सरकार, औषिध और साधन साम ी अिधिनयम, 1940(1940 का 23) क धारा 26ख
ारा द शि य का योग करते ए और औषिध तकनीक सलाहकार बोड क िसफा रश के आधार पर और
917 GI/2017

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

भारत के राजप , असाधारण, भाग II, खंड 3, उपखंड (i) म कािशत भारत सरकार के वा य और प रवार
क याण मं ालय ( वा य िवभाग) क अिधसूचना सं यांक 677(अ), तारीख 15 िसत बर, 2009 को उन बात के
िसवाय अिध ांत करते ए, िज ह ऐसे अिध मण से पूव कया गया है या करने का लोप कया गया है, यह िनदेश
देती है क कोई

ि

‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’ औषिध वाली कसी िन मित का, िन िलिखत

रीित के िसवाय, िव य या िवतरण के िलए िविनमाण नह करे गा या उसका िव य या टाक नह करे गा या िव य
के िलए सं द शत या
(क) कोई

थािपत नह करे गा या िवत रत नह करे गा, अथात्;
ि

वयं या अपनी ओर से कसी अ य

ि

ारा औषध िनयं क (भारत) के िलिखत पूव

अनुमोदन के िबना िव य या िवतरण के िलए िविनमाण नह करे गा;
(ख) उ

अिधिनयम के अधीन बनाए गए औषिध और साधन साम ी िनयम, 1945 म उन िनयम क

अनुसूची ज1 म िविन द औषिधय क बाबत िविन द शत ‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’
औषिधय या उन पर आधा रत कसी िन मित को लागू ह गी:
पर तु औषध िनयं क(भारत) ‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’ औषिध या उन पर आधा रत
कसी िविन मित का िनयात, उन कारण से, जो लेखब

कए जाएं और के

ीय सरकार के परामश से

अनु ात कर सके गा;
(ग) ‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’ औषिध या उन पर आधा रत कसी िविन मित का

येक

िविनमाता, औषध िनयं क (भारत) को एक ऐसी मािसक िववरणी तुत करे गा, िजसम उनके ारा
िवतरक , टा क ट , वहा रय को येक मास के अंत तक दाय क गई ऐसी औषिधय क मा ा
अंत व हो ।
(घ) ऐसा

येक िवतरक, टा क ट और

वहारी, जो ‘ओसेलटािमवीर फासफे ट’ और ‘जनिमवीर’ औषिध

या उन पर आधा रत कसी िविन मित का टाक रखता है, यथाि थित, रा य या संघ-रा य े म संबंिधत
अनु ापन ािधकारी को ऐसी मािसक िववरणी तुत करे गा, िजसम येक मास के अंत तक उनके पास
उपल ध ऐसी ओषिधय क मा ा अंत व हो;
2.

यह अिधसूचना राजप म इसके काशन क तारीख से वृ होगी ।
[फा. सं. ए स.11014/10/2016-डी.आर.एस.]
कु दन लाल शमा,संयु

सिचव

ट पण: मूल अिधसूचना, भारत के राजप , असाधारण, भाग II, खंड 3, उपखंड (i) म अिधसूचना सं यांक सा.
का.िन. 677(अ), तारीख 15 िसत बर, 2009 ारा कािशत क गई थी ।

MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health and Family Welfare)
NOTIFICATION
New Delhi, the 17th February, 2017
G.S.R. 144(E).—Whereas the Central Government was satisfied that the drugs ‘Oseltamivir Phosphate’ and
‘Zanamivir’ were essential to meet the requirements of emergency arising due to epidemic and in public interest, and it
was necessary and expedient to regulate and restrict the manufacture, sale and distribution of the said drugs and
preparations based thereon for preventing their misuse;

<!-- page 3 -->

¹Hkkx IIµ[k.M 3(i)º

Hkkjr dk jkti=k % vlk/kj.k

3

And Whereas the Central Government in exercise of the powers conferred by section 26B of the Drugs and
Cosmetics Act, 1940 (23 of 1940), vide notification published in the Gazette of India, Extraordinary, Part II, Section 3,
Sub-section (i), number G.S.R. 677(E), dated the 15th September, 2009, directed that no person shall manufacture for sale
or distribution, or sell or stock, or exhibit or offer for sale, or distribute any preparation containing the drug ‘Oseltamivir
Phosphate’ or ‘Zanamivir’ except in the manner specified in the said notification;
And Whereas, the Drugs Technical Advisory Board considered the issue of restriction of sale of the drugs
‘Oseltamivir Phosphate’ and ‘Zanamivir’ similar to the drugs referred to in the Schedule X of the Drugs and Cosmetics
Rules, 1945 on 15th November, 2016 and recommended that the notification G.S.R. 677(E), dated the 15th September,
2009 shall be withdrawn and the said drugs be permitted for sale similar to the drugs referred to in the Schedule H1 of
the said rules;
Now, therefore, in exercise of the powers conferred by section 26B of the Drugs and Cosmetics Act, 1940 (23 of
1940) and on the basis of the recommendations of the Drugs Technical Advisory Board, the Central Government hereby
and in supersession of the notification of the Government of India, Ministry of Health and Family Welfare (Department
of Health) published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i), vide number G.S.R. 677(E)
dated the 15th September, 2009 except as respects things done or omitted to be done before such supersession directs that
no person shall manufacture for sale or for distribution or sale or stock or exhibit or offer for sale or distribute any
preparation containing the drug ‘Oseltamivir Phosphate’ or ‘Zanamivir’ except in the following manner, namely:(a) no person shall himself or by any other person on his behalf manufacture for sale or for distribution without the
prior approval in writing from the Drugs Controller General (India).
(b) the conditions specified in the Drugs and Cosmetics Rules, 1945 in respect of the drugs specified under
Schedule H1 to that rules shall apply to the drugs ‘Oseltamivir Phosphate’ and ‘Zanamivir‘ or any preparation
based thereon.
Provided that the Drugs Controller General (India) may allow export of the drug ‘Oseltamivir Phosphate’ and
‘Zanamivir’ or any preparation based thereon for reasons to be recorded in writing and in consultation with the
Central Government.
(c) every manufacturer of the drug ‘Oseltamivir Phosphate’ and ‘Zanamivir’ or any preparation based thereon shall
submit to the Drugs Controller General (India) a monthly statement, containing therein the quantity of such
drugs supplied by them to distributors, stockists, dealers by the end of every month.
(d) every distributor, stockist and dealer holding stocks of ‘Oseltamivir Phosphate’ and ‘Zanamivir’ or any
preparation based thereon shall submit to the concerned licensing authority in the State or Union territory, as
the case may be, a monthly statement, containing therein the quantity of such drugs available with them, by the
end of every month.
2. This notification shall come into force on the date of its publication in the Official Gazette.
[F.No. X.11014/10/2016-DRS]
K. L. SHARMA, Jt. Secy.
Note: The principal notification was published in the Official Gazette, Extraordinary, Part II, Section 3, Sub-section (i)
vide notification number G.S.R. 677(E) dated the 15th September, 2009.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.
Digitally signed

ALOK by ALOK KUMAR
2017.02.22
KUMAR Date:
16:27:49 +05'30'
