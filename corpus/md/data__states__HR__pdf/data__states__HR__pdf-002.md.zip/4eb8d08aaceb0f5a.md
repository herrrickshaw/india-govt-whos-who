---
doc_id: "4eb8d08aaceb0f5a"
source_url: "https://www.mansadevi.org.in/pdf/term-condition-25-1.pdf"
ministry: "Shri Mata Mansa Devi Shrine Board (SMMDSB), Panchkula, Haryana"
title: "श्री माता मनसा देवी पूजास्थल बोर्ड, पंचकुला में कंडम सामान की नीलामी हेतु नियम एवं शर्ते।"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3acf567b97ff4339"
---

<!-- page 1 -->

0172-2920988

fu;e ,oa 'krsZ
1-

cksyhnkrk dks cksyh izkjEHk gksus ls iwoZ 20]000@&:i;s crkSj iathdj.k&de&flD;ksfjVh jkf'k tek
djokuh gksxh tksfd vlQy cksyhnkrk dks uhykeh [kRe gksus ij yksVk nh tk;sxhA cksyh gsrq
iathdj.k fnukad 12-08-2025 dks izkr% 11-00 cts 'kq: gksdj nksigj 01-00 cts rd gksxh vkSj
uhykeh nksigj 02-00 cts 'kq: gksxhA fuf'pr le; ds ckn fdlh ls dksbZ flD;ksfjVh jkf'k ugh yh
tk;sxhA
2- uhykeh lumpsum vk/kkj ij dh tk;sxhA
3- uhykeh ds lkeku dk fjtoZ ewY; --------------------- + th0,l0Vh0 gksxkA
4- lQy cksyhnkrk dks uhykeh esa fn[kk;s x;s lkeku dks efUnj ifjlj ls fcuk iwtkLFky cksMZ dh
lEifr dks uqdlku igqpk;s vius [kpZ ij gVkuk@mBkuk gksxkA vxj bl izfdz;k esa iwtkLFky cksMZ
dh lEifRr dks fdlh Hkh rjg dk uqdlku igqWprk gS ;k dksbZ nq?kZVuk gksrh gS rks mldh ftEesokjh
Bsdsnkj dh gksxh vkSj Bsdsnkj dks tku ;k eky dh gqbZ gkfu dh HkjikbZ djuh iMsxhA
5- uhykeh fdlh ,d O;fDr@;k ,d ,tsl
a h dks vkcafVr dh tk;sxhA
6- lQy cksyhnkrk dks vf/kdre cksyh dh 25 izfr'kr jkf'k ekSds ij gh tek djokuh gksxh vkSj ckfd
dh 75 izfr'kr jkf'k cksyh NqVus ds 48 ?kUVs esa tek djokuh gksxhA l
7- vxj lQy cksyhnkrk cksyh dh jkf'k tek djokus esa vlQy jgrk gS rks nwljs vf/kdre cksyhnkrk
dks ekSdk fn;k tk;sxkA vxj nwljk vf/kdre cksyhnkrk Hkh cksyh dh jkf'k tek djokus esa vleFkZ
jgrk gS rks rhljh vf/kdre cksyhnkrk dks ekSdk fn;k tk;sxkA vxj lQy cksyhnkrk ftlds uke
uhykeh NksMh xbZ gks] cksyh ds fu;e ,oa 'krksZ dh ikyuk esa vlQy jgrk gS rks mldh flD;ksfjVh
jkf'k rFkk tek jkf'k tCr dj yh tk;sxhA
8- lQy cksyhnkrk dh flD;ksfjVh jkf'k lQy cksyhnkrk }kjk r; le; esa lkekuk mBkdj txg [kkyh
djus ds ckn vkSj v/kksgLrk{kjh dh larqf’V ds ckn gh okilh dh tk;sxhA vxj Bsd
s snkj r; le; esa
txg [kkyh djus esa vleFkZ jgrk gS rks mldh flD;ksfjVh jkf'k vkSj tek jkf'k tCr dj yh
tk;sxhA
9- uhykeh ls iwoZ lkeku dk fujh{k.k fd;k tk ldrk gSA ckn esa dksbZ Hkh Dyse ugha ekuk tk;sxkA
10- uhykeh lfefr cksyh dks ekuus ;k fcuk dkj.k fujLr djus dk vf/kdkj lqjf{kr j[krh gSA
11- cksyh dh iw.kZ jkf'k tek djokus ij gh cksyhnkrk uhykeh dk gdnkj ugha cu tkrk gS cksyh eq[;
iz'kkld] Jh ekrk eulk nsoh iwtkLFky cksMZ] iapdwyk dh fyf[kr eatwjh ds ckn gh ekU; ekuh
tk;sxhA
12- ykxw th,lVh cksyh jkf'k ds Åij vfrfjä 'kqYd ds :i esa olwyk tk,xkA

<!-- page 2 -->

0172-2920988

Jh ekrk eulk nsoh iwtkLFky cksMZ] iapdqykA
lkoZtfud [kqyh uhykeh lwpuk
Jh ekrk eulk nsoh iwtkLFky cksMZ] iapdqyk }kjk fofHkUu izdkj ds daMe lkeku tSls fd yksgk] IykfLVd]
fctyh dk lkeku] ikuh dh fQfVax ,oa byDVªkfs ud midj.k bR;kfn dh [kqyh uhykeh fnukad 12-08-2025
dks nksigj 02-00 cts desVh :e esa fu/kkZfjr dh xbZ gSA bPNqd O;fDr@ikfVZ;kW fu/kkZfjr frfFk o le;
ij desVh :e] Jh ekrk eulk nsoh iwtkLFky cksMZ] iapdwyk esa igqp dj [kqyh uhykeh dh izfdz;k esa Hkkx
ys ldrh gSA bPNqd O;fDr@ikVhZ dks [kqyh uhykeh dh izfdz;k esa Hkkx ysus ls iwoZ 20000@& :Ik;s dh
jkf'k crkSj /kjksgj tek djokuh gksxhA uhykeh dh iw.kZ tkudkjh o 'krsZ cksMZ dh osclkbZV
www.mansadevi.org.in ij ns[kh tk ldrh gSA
Email Id: jaimansadevimaa@gmail.com

lEidZ nwjHkk’k% 0172-2920988
