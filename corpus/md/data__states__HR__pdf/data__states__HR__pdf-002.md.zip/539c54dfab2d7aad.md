---
doc_id: "539c54dfab2d7aad"
source_url: "https://cicharyana.gov.in/uploads/pdf/SIC_IT2_01371.pdf"
ministry: "State Information commission (SIC), Haryana"
title: "SPIO and FAA Order Dated 12-10-2026"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "2da98a8828e0496b"
---

<!-- page 1 -->

@
=) RIGHT TO STATE INFORMATION COMMISSION, HARYANA,
pe INFORMATION Netaji Subhas Chandra Bose Suchana Bhawan
IP-8, Sector 3, Panchkula.
Telephone No. 072-27205
Email- ussichry@yahoo.co.in
ORDER
In supersession of all previous orders issued in this behalf and in pursuance of provisions of
sub-section | & 2 of Section 5 and 9 of the Right to Information Act, 2005 (22 of 2005), the following
officers are hereby designated as State Public Information Officers for disposal of RTI applications being
received in the State Information Commission, Haryana:-
Sr. Name and Designation of SPIO Work to be Assigned
No.
2 Sh. Darshan Kumar, Senior I. Smt. Simranjit Kaur, Reader(R-l)
Administrative Services (Consultant) 2. Sh. Chetan Kanojia, Clerk, (R-2)
3. Sh. Jit Singh, Reader (R-3)
4. Smt. Hema Rawal, Reader (R-5)
5. Smt. Rajpreet Kaur, Reader (R-6)
ay Sh. Vinod Kumar, Accounts Officer l, Purchase/Accounts Matter,
2. Audit and Budget
3. Expenditure and = maintenance ~—of
Vehicle/logbook etc.
3: Sh, Suraj Pal Raghav, Superintendent I. Establishment Branch
2. Smt. Manju, Reader (R-4)
3. Statistical of Commission (Annual Report
and MPR)
| 4. Online RTI Portal :
5. AppCoMs Web application
6. RTI applications related to Training and
fh Penalty recovei
Sh. Mukesh Antil, Accounts Assistant will be responsible to get the fee deposited, if it is
received in cash from the applicants.
Further, the First Appellate Authorities (FAAs) shall be as under:-
l. Sh. Surender Singh, HCS, Secretary — First Appellate Authority (FAA) in respect of matters
relating to the Administration Branch.
2. Sh. Rajesh Dhull, Registrar — First Appellate Authority (FAA) in respect of matters relating to
all the Readers.
These orders will come into force with immediate effect.
Dated Panchkula T.V.S.N. Prasad,
the 09' October, 2026 Chief Information Commissioner,
Ha शी (व
Endst. ७०. 204 28 CIC/2026/EA-I Dated the Panchkula l al o/ Oct., 2026.
A copy of the above is forwarded to the following for information and necessary action:-
l) PA/CIC
2) PA/Secretary.
3) Sh. Rajesh Dhull, Registrar
4) Sh. Darshan Kumar, Administrative Services (Consultant)
5) Sh. Vinod Kumar, Accounts Officer
6) Sh. Suraj Pal Raghav, Superintendent
7) Sh. Mukesh Antil, Accounts Assistant.
8) Programmer, IT Cell. है ue
Su aati ls
है for State Inform: mmission,
Haryai ne
