---
doc_id: "db9fddf52306dcde"
source_url: "https://dbtharyana.gov.in/data/documents/Guidelines-for-State-DBT-Cell.pdf"
ministry: "Direct Benefit Transfer (DBT), Haryana"
title: "Guidelines for DBT Cell"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8a6ff57c09d463cb"
---

<!-- page 1 -->

GUIDELINES FOR STATE
DBT CELL

DBT Mission
Cabinet Secretariat

<!-- page 2 -->

DBT Mission
Cabinet Secretariat

4th Floor,
Shivaji Stadium Annexe, Rajiv Chowk,
New Delhi - 110001
Website:
h p://cabsec.nic.in/dbt/origin.html

<!-- page 3 -->

Vision
“A governance regime which ensures a simple and
user-friendly Government to People (G2P) interface
and directly delivers en tlements to eligible
individuals and households in a fair, transparent,
eﬃcient and reliable manner.”

<!-- page 4 -->

Mission
To facilitate a paradigm shi in the process of delivering en tlements
to all those who are eligible through:
Ø Accurate iden ﬁca on and targe ng of the intended beneﬁciaries
Ø Re-engineering government processes for simpler ﬂow of

informa on and funds
Ø Promo on of Financial Inclusion
Ø Se

ng up of digital pla orms that are accessible, scalable and
reliable, providing user-friendly interfaces between the
Government and the beneﬁciaries

<!-- page 5 -->

Content
1) Evolu on of Direct Beneﬁt Transfers ........................................................................ 3
2) Need for State Level Engagement for DBT Implementa on ...................................... 3
3) Objec ves of DBT Cells ............................................................................................. 6
4) Proposed Architecture of State DBT Cell ................................................................... 6
5) Responsibility Matrix for Stakeholders ..................................................................... 7
6) Process Flow of Delivering Beneﬁts in the State (Both Cash & Kind) * ...................... 9
7) Frequently Asked Ques ons ..................................................................................... 11

2

<!-- page 6 -->

Direct Beneﬁt Transfer (DBT)
DBT is a major reform ini a ve to ensure be er and mely delivery of beneﬁts from Government to the people.
This marks a paradigm shi in the process of delivering beneﬁts like wage payments, fuel subsidies, food grain
subsidies etc. directly into the bank accounts of the beneﬁciaries, removing leakages and enhancing ﬁnancial
inclusion. Of late, with due espousal of the Government, DBT has evolved into a transforma ve mechanism which
ensures a smooth and eﬃcient interface between the Government and people.
The concept and scope of DBT ini a ve has been evolving over the years. DBT was rolled out in the country in 2013
in 43 districts, 24 selected Central Sector (CS) and Centrally Sponsored Schemes (CSS) in a phase-wise manner. In
Phase II, DBT was further expanded across the country on 12.12.2014 with 7 new scholarship schemes, and
modiﬁed DBTL for LPG subsidy and Na onal Rural Employment Guarantee Scheme (300 districts) brought under its
ambit. Currently, DBT is being implemented in 66 schemes of the Central Government across the country, delivering
beneﬁts to more than 30 crore beneﬁciaries with more than 100 crore DBT transac ons.
Apart from its extended spread, the deﬁni on of DBT has also expanded over the years. Today, DBT not only
encompasses direct transfer of cash beneﬁts, but also In-kind beneﬁt transfers and transfers to the service
providers/enablers within the Scheme design. In totality, DBT has progressed onto becoming a revolu onary
delivery mechanism, enabling the country to leapfrog genera ons of sub-op mal service delivery and migrate
directly to a cu ng-edge government delivery system.

Need for State-Level Engagement for DBT Implementa on
Over the past three years, DBT has shown promising results in a number of Schemes/pilots being run in across the
country. These include PAHAL (modiﬁed DBTL for LPG subsidy), Public Distribu on System (PDS) Puducherry,
Chandigarh and Mahatma Gandhi Na onal Rural Employment Guarantee Scheme (MGNREGS). In 2015-16, over 30
crore beneﬁciaries have received more than Rs 61,000 crore through DBT, including Rs 25,000 crore in MGNREGS,
and over Rs 21,000 crore in PAHAL.
The umbrella of DBT is thus expanding its spread; encompassing increasing number of schemes being implemented
across Ministries/Departments, its outreach thereby increasing in terms of number of beneﬁciaries, volume of
transac ons, etc.
Now, an ambi ous target of ensuring that all Central Sector & Centrally Sponsored welfare and subsidy schemes are
brought within the purview of DBT by March, 2017 has been set. This requires bringing in new mechanisms, reengineering of Government processes, and appropriate distribu on of authority and responsibility as well as
ﬁnancial resources for delivery public beneﬁts/services. The success of this endeavour will be par cularly
enhanced with coopera on and support from all the States which implement schemes and are the real interface for
the beneﬁciaries. A coordinated eﬀort between the Centre and State will enable faster: decision-making, eliminate
duplica on of eﬀorts and smoothen out diﬀerences, if any, hence fostering an easier transi on of schemes on to
DBT.

3

<!-- page 7 -->

It is to ensure such desired coordina on between the Centre Ministries and States that the States are being asked to
set up DBT Cells. These DBT Cells in the States are expected to be the one-stop point for coordina ng all eﬀorts for
bringing and implemen ng schemes on to DBT. The advantage of eﬃciency and eﬀec veness that these DBT Cells
will bring in the DBT implementa on exercise, as against the present system (which only duplicates eﬀorts) are
explained diagramma cally in Figures (1) and (2) below:
Figure 1 - Present Centre- State Structure for DBT Ini a ves
DBT Mission
DBT Mission coordinates with Central Ministries and
facilitate transi oning of schemes on DBT

Each Ministry receives the advisory and directs it to corresponding departments in the State.
Mul ple layers in decision-making

State Departments, a er receiving their direc ves, ini ate payment process.
Many-to-one direc on of ﬂow may create chaos, delay decision-making, burden the payment system
and aﬀect beneﬁts delivery.

District/ Block/ Panchayat Administra on
District Authori es receive informa on and facilitate the beneﬁt delivery
process of the beneﬁciaries.

4

<!-- page 8 -->

Figure 2 - Desired Map of Centre- State Coordina on with DBT Cell in States

DBT Mission
DBT Mission coordinates with Central Ministries and
facilitates transi oning of schemes on DBT

DBT Cell in each Ministry receives the advisory and pushes it to the State Cell which
is the one-stop point in the state.

State DBT Cell
Consolidates and si s the guidelines received and direct them to the respec ve
state departments; Unity of Command. Provides Technical, Implementa on and
Coordina on Support

District/ Block/ Panchayat Administra on
District Authori es receive informa on and facilitate the beneﬁt delivery process.

The DBT Cells shall work in tandem with the Centre and make the process of delivering beneﬁts on the DBT pla orm
more reliable, user-friendly and me-bound. Rather than following a blanket approach, these Cells shall have a
free hand to customise the implementa on process, methodology and approach according to their ground level
peculiari es. The two-way feedback loop between Centre and States shall facilitate cross-learning, induce novel
experiments and pilot studies and also promote healthy compe on among the States. This sort of proximity
between the States and Central Government can be mutually beneﬁcial, par cularly in developing more

5

<!-- page 9 -->

beneﬁciary-centric policies. As found in reforms of health, nutri on and educa on systems, some States may take
the lead in innova ng which can act as an exemplar for the Centre and other States.
Hence, in the spirit of MAXIMUM GOVERNANCE MINIMUM GOVERNMENT, State DBT cells are envisioned to
facilitate seamless coordina on for DBT implementa on of Central Sector and Centrally Sponsored Schemes and
also provide an opportunity to the States to adopt the DBT framework in the State-run Schemes as well.

Objec ves of DBT Cells
The State DBT cells shall primarily work towards coordina ng the implementa on of DBT in various schemes. The
Cells shall act as a nodal point for all the ac vi es and ma ers related to DBT opera ons in the State. As DBT
operates in an environment that involves mul ple stakeholders, the Cells shall be responsible for liaisoning with all
such stakeholders for the seamless transi oning of schemes to DBT. These State Level Cells, as a part of the
decentralised DBT architecture, will contribute towards achieving eﬀec ve delivery of government beneﬁts in the
country by:
© Coordina ng with Centre/Ministries and dissemina ng the direc ves to the respec ve departments in States
© Developing scheme/department-speciﬁc ICT applica ons to capture data pertaining to DBT more eﬀec vely.
© Closely monitoring and evalua ng the progress of various departments on DBT related indicators vis-a-vis

expected outcomes.
© Incorpora ng best prac ces and interna onal experiences to enhance the eﬀec veness of beneﬁts delivery.
© Partnering with mul -lateral agencies and consul ng ﬁrms to piggyback on their technological and industry
knowledge.

Proposed Architecture of State DBT Cell
In light of the expanded scope and renewed importance of DBT in the country, the state level DBT cells shall have
signiﬁcant responsibili es to fulﬁl. In order to fulﬁl such responsibili es, a well-deﬁned architecture for the DBT Cell
is required.
A State DBT Cell can be headed by Principal Secretary (Planning/IT/Finance) as deemed appropriate by the States.
The graphical representa on of this architecture is presented below:

Advisory
Board

State DBT
coordinator

Ÿ Chief Secretary/

equivalent rank
oﬃcer
Ÿ State Govt.
Department Heads
Ÿ Representa ves
from mul -lateral
agencies
Ÿ Representa ves
from Service

Implementa on
Support
Coordinator Technical Support

Principal Secretary
(Planning/IT/ﬁnance)

Coordinator - NonTechnical Support

Coordinator - Finance

6

<!-- page 10 -->

For ease of enuncia on, the DBT cell can be broken down into three components as below:
_ An Advisory Board may be cons tuted as a parallel body to the state-level DBT Cell. It shall comprise

representa ves from various enablers and stakeholders of DBT like all the government departments who run
schemes which fall under the purview of DBT, UIDAI, State Level Bankers' Commi ee (SLBC), IT Team, NIC, NPCI,
Telecom Service Providers (TSPs), etc. This Board may also include representa on from mul -lateral agencies like
World Bank, ADB etc. for bringing in their technical competence to the Cell's opera ons. The chief role of this
body will be to provide the Cell's execu ve body, holis c, well-rounded advisory and consul ng inputs. Since this
unit witnesses the representa on from all stakeholders, its advisory shall ensure that the Cell's opera ons are
not exclusionary and are in sync with the interests of DBT's various enablers. This body may meet once in a
quarter or in any other regular interval, as deemed ﬁt.
_ State DBT Coordinator: Principal Secretary (Planning/IT/Finance) or equivalent level oﬃcer can be nominated as

the State DBT Coordinator who shall act as the nodal oﬃcer for DBT related ma ers of the State. The DBT
Coordinator will be primarily involved in coordina on and liasioning with the heads of various departments.
Accordingly, the heads of various departments shall work in tandem with the State DBT Coordinator w.r.t se ng
up goals and deadlines, receiving direc ves from the Centre, strategising Cell's opera ons, etc. The DBT
Coordinator, supported by the Advisory Board and on the basis of the mandates received from the
Centre/Ministries, shall push diﬀerent departments to work towards DBT implementa on across Schemes.
_ Implementa on Support Layer: This layer cons tutes the opera onal part of the Cell. This layer may consist of

three coordinators who will be responsible for technical, non-technical and ﬁnance & admin support to the Cell's
opera ons. These coordinators will be directly repor ng to the DBT Coordinator. They may be Director or Oﬃcers
on Special Duty (OSD) rank personnel who will be elici ng coopera on and par cipa on from the grass root
levels for the Cell's opera ons.

Responsibility Matrix for Stakeholders
Level

Role

Responsibility

Resource
Persons

Ÿ Thought Leadership, introducing novel ideas which can

Advisory
Support

Thought
Leadership

be which can help in delivering beneﬁts in a more
eﬀec ve way.
Ÿ Partnership support by providing more long term, wider

Advisory
Board

and strategic inputs.
Ÿ Pushing Direc ves to the diﬀerent Department Heads (PS

Coordina on
Layer

Coordina on
& Liasioning

Level)
Ÿ Informa on Dissemina on to the Departments on

PS level
Oﬃcer

upcoming mandates.
Ÿ Facilita ng all kinds of IT support for implemen ng DBT

Implementa on
Support

Technical
Support

in the diﬀerent schemes.
Ÿ To func on as a research unit in developing

scheme/department-speciﬁc ICT applica ons which can
capture data related to DBT in a more eﬀec ve way.

CoordinatorTechnical
Support

7

<!-- page 11 -->

Ÿ Driving growth and achievement on all the IT related

indicators for successful implementa on of DBT, like
digi sa on of data, streamlining beneﬁciary databases,
running de-duplica on exercises, etc.
Ÿ Interac ng & liaisoning with all IT related stakeholders

like NIC, third-party consultants, telecom service
providers, etc.
Ÿ Enabling on-boarding of all the schemes on the live MIS

portal for capturing the informa on pertaining to DBT.

Ÿ Implemen ng customised ICT applica ons, as developed

by the technical support team.
Ÿ Based on the direc ves from above, se ng up goals and

deadlines for boarding schemes on DBT.
Ÿ Collec ng data from various departments and technical

support team on factors like Aadhaar enrolment, number
of beneﬁciaries, no. of ac ve bank accounts, rate of
Aadhaar seeding etc.
Ÿ Colla ng & analysing data points and churning progress

reports for the state, each department and scheme.

Implementa on
Support

NonTechnical
Support

Ÿ Monitoring Progress of each department against targets.
Ÿ Training & Capacity Building of State Oﬃcials on Ps & Qs

PS level
Oﬃcer

of DBT.
Ÿ Running innova ons in the state through

pilots/experiments.
Ÿ Organising exposure visits for the state/ district oﬃcials

in DBT progressive states for familiarising them with
model prac ces.
Ÿ Conduc ng benchmarking studies on Best Prac ces and

developing roadmap to incorporate those prac ces in the
state opera ons
Ÿ Incen vising DBT eﬀorts in the state.
Ÿ Linking of all ﬁnancial transac ons under diﬀerent

schemes on to PFMS pla orm.

Implementa on
Support

Finance
& Admin

Ÿ Budgets & funds ﬂow

CoordinatorFinance
& Admin

Ÿ F & A and other administra ve tasks

8

<!-- page 12 -->

Process Flow of Delivering Beneﬁts in the State (Both Cash & Kind) *
a) Process of Delivering Cash Beneﬁts
For schemes that involve cash beneﬁts to beneﬁciaries, funds are transferred from the Consolidated Fund of India
to the respec ve Central Ministries/ Departments based on budget alloca ons. Therea er, these funds are
transferred to the State Consolidated Fund of respec ve States or implemen ng agencies as per scheme speciﬁc
requirements.
For all DBT in cash schemes, Central Ministries/ Departments and the State Treasury will be registered on the
centralized Public Fund Management System (PFMS) portal. Therea er, the allocated funds ﬂow to the respec ve
State Departments/ Implemen ng Agencies of the schemes and consequently into the Bank/ Postal accounts of
the individual beneﬁciaries. State Departments/ Implemen ng agencies may be registered either on PFMS or
State's own electronic Fund Management System (e-FMS). In case there is a State e-FMS, it should be compa ble
with PFMS to ensure establishment of a reverse feedback loop.
Consolidated Fund of India
Central Ministries/Departments
PFMS as payment pla orm
State Consolidated Fund
State Departments/Implemen ng Agencies

{

{

e-FMS should be linked
to PFMS for reverse
feedback loop

PFMS/ State e-FMS as payment pla orm
Beneﬁciaries' Bank /Postal Accounts
* For Central and Centrally Sponsored Schemes (CSS)

9

<!-- page 13 -->

b) Process of Delivering Beneﬁts in Kind
In schemes that involve transfer of In-kind beneﬁts, Central Ministries/Departments allocate the goods for
distribu on to beneﬁciaries to the respec ve States/UTs as per budgetary requirements/pre-deﬁned scheme
criteria.
For all DBT In-kind schemes, State/UTs will send the allocated quan ty to the respec ve State Departments/
Implemen ng Agencies/District/Block/Panchayat Oﬃce responsible for disbursal of these beneﬁts. The respec ve
body will then distribute these beneﬁts to designated outlets/ ins tu ons meant for public distribu on. All these
public distribu on outlets will have PoS machines installed (preferably Aadhaar enabled). From these outlets,
en tled beneﬁts will be disbursed to the individual beneﬁciaries a er authen ca on at PoS.
Alloca on of goods/beneﬁts to States/UTs

State Departments/Implemen ng Agencies/District/Block/Panchayat Oﬃce

Distribu on of Beneﬁts to Designated Retail Outlets

Installa on of PoS machines (preferably Aadhaar enabled)

Delivery of en tled amount to beneﬁciaries a er authen ca on at PoS (preferably Aadhaar-based)

10

<!-- page 14 -->

Frequently Asked Ques ons
1. What is Direct Beneﬁt Transfer (DBT)?
Answer: Direct Beneﬁt Transfer or DBT is a major reform ini a ve launched by Government of India on 1 January
2013 to re-engineer the exis ng cumbersome delivery processes using modern Informa on and Communica on
Technology (ICT). This programme aims to transfer beneﬁts directly into the bank/postal accounts, preferably
Aadhaar seeded, of accurately targeted beneﬁciaries.
2. What is the background of Direct Beneﬁt Transfer?
Answer: A decision was taken in the mee ng of the Na onal Commi ee on Direct Cash Transfers held by the Prime
Minister that Direct Beneﬁt Transfers will be rolled out from 1st January, 2013 in 43 districts, 24 selected Central
Sector and Centrally Sponsored Schemes in a phase-wise manner beginning with 20 districts on 1.1.2013, 11
districts from 1.2.2013 and the remaining 12 districts from 1.3.2013.
3. How will DBT be implemented in Centrally Sponsored Schemes where both Centre and State share of funds
are involved?
Answer: Centrally Sponsored Schemes are funded by both the Central and State Government as per the deﬁned
shares under respec ve schemes. A er receipt of Central share in the State Consolidated Fund, the State
Government will add its share and then disburse the total fund amount to the beneﬁciaries. The State has to ensure
that these funds are disbursed directly to the bank/postal accounts of the beneﬁciaries. It is preferable that the
State uses PFMS pla orm to track the transfer of funds to the beneﬁciaries' bank/postal accounts. The State may
also develop its own e-FMS pla orm for fund disbursal. However, the State e-FMS should be linked to PFMS so that
reverse feedback loop can be established.
4. Is DBT applicable only to schemes that involve cash transfer?
Answer: Ini ally, DBT covered schemes that involve cash transfer to beneﬁciaries. As a part of reforms in Public
Distribu on System (PDS), Department of Food and Public Distribu on started DBT In-kind i.e. distribu on of food
grains to the beneﬁciaries a er biometric authen ca on at Fair Price Shops through Aadhaar-enabled Point of Sale
(PoS) devices. Cash or in-kind beneﬁts may be given to individual beneﬁciaries or communi es.
5. What schemes can come under the current DBT framework?
Answer: Under the purview of redeﬁned DBT framework, all schemes can be broadly classiﬁed into three
categories:
I) Cash Transfer from Government to Individual Beneﬁciary
Example: PAHAL, MGNREGA, NSAP etc.
ii) In-kind Transfer from Government to Individual Beneﬁciary
Example: Food grains and kerosene through PDS, Medicines, Books, Vaccines, etc.
iii) Payments from Government to service providers for running its schemes
Example: ASHA workers under NHM, Aanganwadi workers under ICDS, teachers in aided schools, sanita on staﬀ in
ULBs, etc. are not beneﬁciaries themselves but they are given salary, training, incen ves for their service to the
beneﬁciaries/community.

11

<!-- page 15 -->

6. How many schemes are presently reported to be on DBT?
Answer: As on 31.04.2016, 66 schemes of 15 Ministries/Departments are reported to be on DBT.
7. Is Aadhaar mandatory for DBT?
Answer: At present, Aadhaar is not mandatory for availing DBT in any of the welfare schemes of the Government.
DBT can be undertaken by digi sa on of beneﬁciary database and making payments directly to the bank account
through electronic transfer. However, Aadhaar seeding in beneﬁciary database and bank accounts is desirable to
achieve DBT objec ves in its true sense.
8. What is Aadhaar Seeding?
Answer: Aadhaar seeding is done by upda ng Aadhaar number in the beneﬁciary database and linking the
Aadhaar number with the bank account of the beneﬁciary in the Core Banking System (CBS).
9. Why is Aadhaar seeding desirable?
Answer: Aadhaar seeding of bank accounts in the beneﬁciary database will help in de-duplica on and curbing
leakages. Use of Aadhaar is beneﬁcial to ci zens as he or she will not have to carry mul ple iden ty proofs and will
provide a faster channel for receiving all welfare payments without any middle-men. Thus, Aadhaar seeding in
beneﬁciary database and bank accounts is desirable to achieve DBT objec ves in its true sense.
10. What is Na onal Payments Corpora on of India (NPCI)?
Answer: Na onal Payments Corpora on of India (NPCI) is an umbrella organisa on for all retail payments system in
India. It was set up with the guidance and support of the Reserve Bank of India (RBI) and Indian Banks' Associa on
(IBA). NPCI oﬀers a range of services like Na onal Financial Switch (NFS), Aadhaar Payment Bridge System (APBS),
Cheque Clearing, Immediate Payments Service (IMPS), Na onal Automated Clearing House (NACH), Electronic
Beneﬁt Transfer, RuPay cards, etc. As per government order released by Department of Expenditure, Ministry of
Finance, all DBT transac ons are to be routed through NPCI. While Aadhaar linked DBT transac ons will be routed
through APBS, non-Aadhaar transac ons will be routed through NACH.
11. Does the beneﬁciary need to have a bank account for availing beneﬁts & subsidies through APBS?
Answer: Yes, the beneﬁciary needs to have a bank account for availing the beneﬁts & subsidies through APBS.
12. What is NPCI mapper?
Answer: NPCI mapper is a repository of Aadhaar numbers maintained by the APB System and used for the purpose
of rou ng the APB transac ons to the des na on banks. The NPCI mapper contains Aadhaar number along with
Ins tu on Iden ﬁca on Number (IIN) of the bank to which the beneﬁciary has seeded his/her Aadhaar number.
13. Does NPCI maintain bank account details of the beneﬁciaries in NPCI mapper?
Answer: No. NPCI does not maintain bank account details of the beneﬁciaries like account number, IFS code and
branch address etc. of the beneﬁciary in NPCI mapper.

12

<!-- page 16 -->

14. What happens when a beneﬁciary seeds his/her Aadhaar number in mul ple bank accounts?
Answer: In case a beneﬁciary seeds his/her Aadhaar number in mul ple bank accounts, the previous mapping if
any in the NPCI mapper, gets overwri en by the fresh seeding of the Aadhaar number.
15. What is Public Financial Management System (PFMS)?
Answer: Public Financial Management System (PFMS) is a web-based online so ware applica on. PFMS is being
delivered and implemented by the Project cell in the oﬃce of CGA. The primary objec ve of PFMS is to facilitate
sound Public Financial Management System for Government of India (GoI) by establishing an eﬃcient fund ﬂow
system as well as a payment cum accoun ng network.
16. What is the importance of PFMS for DBT?
Answer: PFMS is the payment pla orm for disbursal of funds for the schemes covered under DBT. PFMS is crucial
for success of DBT ini a ve as it provides various stakeholders with a real me, reliable and meaningful
management informa on system and an eﬀec ve decision support system. It helps in tracking u liza on of funds
from the Central government upto the beneﬁciary.
17. Is PFMS pla orm mandatory for DBT implementa on?
Answer: Yes, PFMS has been made mandatory for payment accoun ng and repor ng under DBT w.e.f. April 1,
2015.
18. What is Pratyaksh Hanstantrit Labh (PAHAL)?
Answer: PAHAL/DBTL (Direct Beneﬁt Transfer for LPG Subsidy) is a scheme which provides the LPG subsidy amount
applicable on the domes c LPG cylinder directly into the consumer's bank account. At the me of LPG cylinder
delivery, consumer will have to pay the full price of the LPG cylinder.
19. What is Na onal Scholarship Portal (NSP)?
Answer: Launched by Hon'ble Prime Minister on 1st July, 2015 under 'Digital India', NSP is a one stop IT enabled
pla orm for disbursement of scholarships under diﬀerent Ministries/Departments.
20. What is Financial Inclusion and Last Mile Service Delivery?
Answer: Tradi onally, ﬁnancial inclusion has been understood to mean extension of ﬁnancial services to the
unbanked areas and providing universal access to banking services across the country. However, ﬁnancial inclusion
is much more than just opening bank accounts and it will be meaningful only when there is last mile service
delivery. Last mile connec vity/service delivery means transla ng ﬁnancial access into usage and making ﬁnancial
services or cash out facili es available at the doorstep of the beneﬁciaries. It cannot be denied that there has been a
quantum jump in banking access through various schemes and ini a ves of the government like Jan Dhan Yojana,
bringing Post Oﬃces on Core Banking Solu on (CBS) network, expansion of BC model, opening of new ATMs, etc.
However, last mile service delivery con nues to be a hurdle in achieving ﬁnancial inclusion.
21. What are the present challenges in last mile service delivery?
Answer: Last mile delivery issues can be addressed by examining the exis ng village-wise infrastructure and

13

<!-- page 17 -->

iden fying those villages which have no points of ﬁnancial presence. Village wise mapping exercise coordinated by
DBT Mission in collabora on with NIC and various Departments reveals that at present, only 1,74,691 out of
6,40,947 lakh villages (27%) have been covered by either Bank Branch, Bank Mitra, ATM, Post Oﬃce or Common
Service Centre (CSC). It is evident that there is a huge gap between ﬁnancially covered villages and uncovered ones.
22. What can be done to strengthen the ﬁnancial service infrastructure especially in the rural areas?
Answer: At present, various ini a ves to strengthen payment infrastructure in the rural areas are being taken up.
The Business Correspondents/Banking Correspondents (BC) Model, introduced by the RBI in 2006 allows banks to
provide service at people's doorstep through the use of third-party services. Some of the Common Service Centres
are presently func oning as BCs for various banks and delivering banking services. There is a gamut of other
services too that can also be leveraged to help achieve last mile service delivery. The BC model may be extended to
include en es such as Grameen Dak Sewaks (GDS), Fair Price Shops, Primary Agricultural Credit Socie es (PACS),
kirana shops, corporates and others. Transforma on of GDS as BCs or opera ng agents of India Post Payment Banks
(IPPB) by providing micro ATMs, bringing Post Oﬃces on CBS and enabling them to become Postal banks,
automa on of FP shops, are already in the pipeline. Another low-cost solu on can be u lisa on of the mobile
banking facility through phones for maximum possible government-to- person (G2P) payments. On 19 August
2015, the Reserve Bank of India gave licencec to eleven en es to launch payments banks to widen the spread of
payment and increase penetra on of ﬁnancial services in remote areas.
23. What are the DBT transac on charges and cash out incen ves applicable under DBT schemes?
Answer: As per latest Government Order released by Ministry of Finance dated 26.02.2016, it has been decided
that all DBT and PAHAL transac ons should be routed through NPCI. To facilitate DBT, compensa on is given to
banks to meet their administra ve cost. The commission is given in two parts, as described below:
i) Transac on charges
A transac on cost of Rs. 0.50/- would be payable for each transac on to be shared between the sponsor banks,
des na on en es and NPCI in accordance with the extant NPCI circular.
ii) Cash out incen ves
For MGNREGA, Maternity Beneﬁts (ICDS) and Pension Schemes, a ﬁxed component of Rs. 5/- per transac on and a
variable component of Rs. 0.50/- per Rs. 100 (transac on amount rounded up to the next hundred) subject to a
maximum of Rs. 5/- would be payable. This incen ve is provided to promote last mile delivery of ﬁnancial services.

14

<!-- page 18 -->
