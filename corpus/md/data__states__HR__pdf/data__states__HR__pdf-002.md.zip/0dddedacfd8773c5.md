---
doc_id: "0dddedacfd8773c5"
source_url: "https://cdn.s3waas.gov.in/s325b2822c2f5a3230abfadd476e8b04c9/uploads/2022/01/2022011398.pdf"
ministry: "Gurugram"
title: "Revised containment zones in District Gurugram order dated 12.01.2022"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5b7d5bbdf12f8b94"
---

<!-- page 1 -->

District Administration Gurugram
Date-12

Order

Subject:

2 22

Revised Containment Zone Order.
Whereas, under Section 2, 3 & 4 of the Epidemic Disease Act, 1897 and The Haryana

Epidemic Disease, COVID-19 Regulations, 2020 vide which the undersigned being the Chairperson

(DDMA) has been empowered under clause 12 (i) to designate and

seal any Geographical

area as

a

containment area for the isolation of cases.
And whereas, it is imperative to strictly observe the lockdown and isolation measures to

contain the further spread of COVID-19 in District Gurugram.
And whereas the undersigned being the Chairperson (DDMA) has been empowered u/s 34

of Disaster Management Act, 2005 to perform such functions as it deems necessary for Disaster
Management in the District.

Now, therefore, 1, Yash Garg, AS, District Magistrate Gurugram pursuant upon the

with the
by The Haryana Epidemic Disease, COVID-19 Regulations, 2020 along
Epidemic Diseases Act, 1897 and Disaster Management Act, 2005 and upon the recommendation of
DDMA Committee and Containment Review Committee. I hereby order containment of the following

power conferred

areas due to COVID-19 positive cases reported in these areas, to prevent the further spread of COVID-19:

Sr.

Block

Containment Zone

Name of PHC/

Buffer Zone

No. UPHC

Date of
Last

Tentative

Reported

14 days

Case in

post

Period of

heZone discharge
Gurugram

1|UPHC Ghata

2

FLAT NO. 90 TO 96 ,Block-D,suncity

Block-B and C suncity

Apartment, SECTOR 54,
GURUGRAM

Apartment, SECTOR

Flat No-dx-60 to 75 Kendriya Vihar

sector-56 Gurugram

Kriti Hospital Sector
56 Gurugram

BLOCK 35 FLAT A To C RAIL

Alaknanda Soceity

VIHAR 56 Gurugram

Sector 56 Gurugram

03-Jan-22

16-Jan-22

04-Jan-22

17-Jan-22

05-Jan-22

18-Jan-22

3-Jan-22

16-Jan-22

1-Jan-2

14-Jan-22

02-Jan-2

15-Jan-22

04-Jan-22

17-Jan-22

02-Jan-22

15-Jan-22

05-Jan-22

18-Jan-22

54, GURUGRAM

EAST On road

PHC Badshahpur

WEST - Park ,

Front Side PARK & Back sidE ON

NORTH- MARKET,

ROAD, EMMAR EMERALD

SOUTH-

PREMIER FLOURS, SEC. 65

FLOURS, EMMAR
EMERALD PREMIER

GURUGAON

FLOURS, SEC. 65

GURUGAON
EAST

On road

WEST Park, Tulip
Front Side Empty & Back side Empty

Voilat Sec. 69

Tulip Voilat Sec. 69 Gurugram

Gurugram

NORTH-Tower B-9,

SOUTH-TowerB-10
EAST Compound

WEST Park,

NORTH-Tower 3,
sOUTH-Tower -5, M3M Marlin Sec.
67 Gurugram

3

PHC Wazirabad

FLAT NO-401, to 417 TOWER-b1,

WORLD SPA APARTMENT,
SECTOR-30, GURUGRAM
4

UPHC Chanderlok

TOWER- B AND, TOWER-C
RIDGEWOOD ESATE, DLF PHASE

Megis

stric

coviD-19

4, GURUGRAM

EAST Compound
WEST Park
NORTH-Tower 3
SOUTH-Tower -5,

M3M Marlin Sec. 67

Gurugram

WORLD SPA
APARTMENT,

SECTOR-30,

GURUGRAM

HAMLITION COURT
DLF PHASE-4,

RIDGEWOOD
ESATE, DLF PHASE

4,GURUGRAM
TOWER NO. A AND 1TOWER NO.,| SUJJAN VIHAR SECPWO APPARMENT, SECTOR 43,

43 AD MAHALAXMI

Gurugram

APPARTMENT SEC-

43, Gurugram

<!-- page 2 -->

PWO APPARTMENT

ONLY 1 ToWER, MAHALAXMI

AND AGRIM

APARTMENT, SECTOR-43,

APPARTMENT SEC-

GURUGRAM

05-Jan-22

18-Jan-22

06-Jan-22

19-Jan-22

06-Jan-22

19-Jan-22

09-Jan-22

23-Jan-22

09-Jan-22

23-Jan-22

09-Jan-22

23-Jan-22

09-Jan-22

23-Jan-22

02-Jan

15-Jan-22

43, Gurugram

Quatab Enclave
DLF PHASE

H.NO BI TO BS DLF PHASE-1,

-

Market,

Gurugram

1,Gurugram

H.NO- 5700 TO 5710
DLF PHASE -4

H.NO- 5601 TO H.N- 5610, DLF

,NERA SUPER

PHASE 4, Gurugram

MARKET DLF

PHASE-4, Gurugram
H No.48 /25 /48/ 35 no- DLF PHASE-

1, Gurugram

H.no- 48/40 to 48/50,
DLF PHASE-1,

Gurugram

Block-H & G DIf
Phase-1, SILVER

Tower No.110 to 111, SILVER OAK

OAK APT, DLF

APT, DLF PHASE-1 GURUGRAM

PHASE-I

GURUGRAM
10th floor to 11 th floor, HARITAGJE

CITY, DLF PHASE 2, GURUGRAM

tower 11 and tower no0
12, HARITAGE CITY
, DLF PHASE 2,

GURUGRAM

near American school,
DLF PHASE-2,

12/1 to 12/15, DLF PHASE-2,
GURUGRAM

UPHC Tigra

GURUGRAM

Tower 3, Tower 2, UNIWORLD

Sohna road, subhasgh

GARDEN 1, SOHNA ROAD,

chowk, Sec 47,
Gurugram

SECTOR47, GURUGRAM

Tower C to D Legend

D Tower Legend Apartment,
SECTOR-57, GURUGRAM

57, GURUGRAM

BULDING 2, bani sqaure,

Nirvana Country Sec

HIBIESCUS SECTOR S0,
BLOCK A, BLOCK C, ROSE

18-Jan-22

07-Jan-22

20-Jan-22

Gurgaon Green Society

05-Jan-22

18-Jan-22

Suncity Society

06-Jan-22

19-Jan-22

08-Jan-22

22-Jan-22

10-Jan-22

24-Jan-22

SEC 49, GHASOLA

WoOD CITY SEC 49, Gurugram
17th FLOOR TO 19thFLOOR

05-Jan-22

50, Gurugram
ROSE WOODCITY

GURUGRAM_

PHC Garhi

17-Jan-22

Appartment, SECTOR-| 04-Jan-22

VILLAGE, Gurugram

Tower

D Heritage society Sec 102 dhankot,

Gurugramn
2nd FLOOR TO 4TH FLOOR Tower
7B, Emaar imperial Garden Sec l102

Gurugram
PHC Bhangrola
8

SI BLOCK SECTOR 82, Gurugram

H block SECTOR 82,

Gurugram

EAST POLICE

UPHC Sukhrali

STATION SEC 14,
WESTCOMMUNITY

CENTER SEC 14,
HNO493, SEC 14, Gurugram

NORTH-KV

SCHOOL SEC 14,
SOUTH JAIN
HOSPITAL SEC 14

(HNO 490 TO HNO

502)
Note:- Containment Zone will be considered de-notified as per the tentative period of 14 days
post discharge as mentioned in the order provided n0 new positive case is being reported in any
of the Containment Zone.

For combating the situation at hand, the following action plan is preseribed to carry out
social distancing and
Mrening of the suspects, testing of the suspected cases, quarantine, isolation,
Zone
Containment
in
the
effectively:
otker public health measures
number of Teams for conducting door to door screening/ thermal scanning of each
Sufficient
lcovin1

andeyery person of the entire households falling in the Containment Zone shall be deployed by the

Ci
Surgeon, Gurugram. All of them would work under the strict directions of the Civil Surgeon,
Gurugram. All the staff on duty shall be provided with personal protective equipments and other
required devices for screening/ thermal scanning etc. Gates/ Door Knobs of each and every

household will be properly sanitized.
(Action by: Civil Surgeon, Gurugram)

<!-- page 3 -->

Municipal Corporation,

will be fully sanitized by the
The entire area of Containment Zone
staff deployed for
be ensured by MCG that the
shall
It
Gurugram or other responsible agency.
equipments viZ.
is adequately provided with personal protective
of the

2.

locality
complete sanitization
norms.
and also follow social distancing
face masks, gloves, caps, sanitizers, shoe
Gurugram, MC's)
Commissioner, Municipal Corporation,
(Action by:

Movement of public of the

3

be restricted other than for
Zone shall be sealed by
number of Nakas etc. Further, all

inhabitants of Containment Zone shall

essential services and emergency

movements.

The

entire Containment

force and setting up of required
deployment of adequate police
of the containment
concerned shall identify the boundaries
ACP/SHOs
SDMs in coordination with
the
all
that
necessary essential
ensure
and exit point and also to
with

area

immediately along

services/emergency

entry

movements/authorized pass movement may be

facilitated.

(Action by: Commissioner of Police, Gurugram/SDM

Gurugram/Badshahpur)

Zone shall be done by the Executive Engineer
of Police, Gurugram and concerned
Commissioner
with
Gurugram in consultation

Necessary barricading of the Containment
PWD (B&R)

SDMs.
(Action by: Commissioner of Police, Gurugram,
Sufficient stock of personal protective equipments / device
kept at the control room by the Civil Surgeon, Gurugram.

5.

SDM's & XEN PWD (B&R)

and required medicines shall be

(Action by: Civil Surgeon, Gurugram)
Isolation/ COVID Hospital, Director, ESI and
6.
ESI, Sector 9A is declared as Containment/
health-care/medical facilities are in place to
Civil Surgeon, Gurugram shall ensure that all required
-

meet any emergency.

7.

(Action by: Director, ESI and Civil Surgeon, Gurugram)
shall deploy four & two
health teams constituted for door to door screening /

CEO, GMCBL, Gurugram and GM, Haryana Roadways Gurugram

buses respectively, exclusively for carrying the
back.
thermal scanning from Hospital to the Zones and drop them

(Action by: CEO, GMCBL/ GM Haryana Roadways, Gurugram)
8.

Demand of essential goods/commodities such as raw ration /milk/grocery/ medicine/

vegetables shall be worked out and list shall be prepared by the Zonal Administrator, HSAMB,
Gurugram in coordination with DFSC and MCG. There shall be separate packets of vegetables
would be ensured at the door step. The
ration/grocery items/ milk etc. and delivery of the same
and drop the packets at the door itself.
delivery personnel would wear personal protective equipments

He will not go inside of any house or make physical contact with any person. Accountability of the
essential goods/items received and distributed to the households shall be maintained by the above
officers in coordination with RWA's on daily basis for which they may deploy adequate staff from

their own office.

(Action by: MCG, DFSC, ZA, HSAMB, Gurugram)
9.

Regular power supply in the Containment Zone shall be ensured by SE, DHBVN, Gurugram.

(Action by: SE, DHBVN, Gurugram)
10.

Regular safe drinking water supply shall be ensured by the SE Public Health, Gurugram and

Municipal Corporation, Gurugram.
(Action by: SE Public Health & M.C. Gurugram)

I

Ambulances and other Para-medical staff shall be deployed by the Civil Surgeon, Gurugram.

COVID-19

(Action by: Civil Surgeon, Gurugram)

ruc
12
u

SDMs to ensure 100% coverage of Aarogya Setu App among the residents of Containment

Zones with the help of respective RWAs.

(Action by: SDM Gurugram/Badshahpur)

<!-- page 4 -->

The Sub Divisional Magistrate, Gurugram/Badshahpur will be Nodal Officer ensuring

demarcation of the Boundaries of Containment Zone Area, Barricading of Containment zone, with
to the residents of

entry/exit Gate, Display board regarding requisite information for convenience

the

Containment Zone.
The Cluster In-charge of respective Containment Zone will supervise the work of Incident

Commander.
The Incident Commander of the Containment Zone will function/work as per SOP.

All the officers/officials on duty shall perform/discharge their duties efficiently and any
officer/official will attract strict action under Section 51l to 60 of Disaster
of
on the

any
part
laxity
Management Act, 2005.
rict

9/s
DistrigMagistrate

coVID-19
Endst. No. 2 16

/M.B

Date 12

uugram

2-22

ura

A Copy of the above is forwarded to following for information and necessary action:

Commissioner, Gurugram Division, Gurugram.

Commissioner of Police Gurugram with the request to ensure that there is no movement

and the area remains completely contained except essential

services/essential mobility for

which pass shall be obtained in advance.

Administrator, HSVP, Gurugram.

Commissioner, Municipal Corporation, Gurugram.
CEO, GMCBL, Gurugram.
Addl. Deputy Commissioner, Gurugram.
Sub Divisional Magistrate Gurugram, Sohna, Pataudi, Badshahpur.
9

GM, Haryana Roadways, Gurugram.
ZA, HSAMB, Gurugram.

10

All Cluster In-Charge of Containment Zone, Gurugram
District Revenue Officer, Gurugram.

12
13
14

DDPO, Gurugram.
BDPO, Gurugram/Pataudi/Sohna/Farrukh Nagar.

15

Civil Surgeon, Gurugram.

16
7

XEN, HSAMB, Gurugram.

SE, DHBVNL- I & II, Gurugram.

D.F.S.C. Gurugram.
Executive Engineer -1& II, PWD (B&R), Gurugram.
District Marketing & Enforcement Officer, Gurugram.

18
19
20
21

Secretary, Market Committee Gurugram/Pataudi/Sohna/Farrukhnagar.
Gurugram/Pataudi/Sohna/Farrukhnagar.
Secretary Municipal Committee

22
23

All Incident Commander, Gurugram.

24

PA/DC, Gurugram.

DIPRO, Gurugram.

Districttágistrate

Oúrgram
