---
doc_id: "7facfa58fdedb809"
source_url: "https://haryanatax.gov.in/Website_Content_Files/News/2025/Regarding_Consent_filling_by_Clerks.pdf"
ministry: "Excise and Taxation Department, Haryana"
title: "Regarding Consent filling by Clerks (Field Cadre), Assistants (Field Cadre) and Taxation Inspectors on Intra Haryana Portal for implementation of Online Transfer Policy 2025"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3f93ab79750156bd"
---

<!-- page 1 -->

<!-- page 2 -->

District-wise list of Willing Clerks
Sr. No. Office Name
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62

DETC(Ex), Ambala
DETC(Ex), Ambala
DETC(Ex), Ambala
DETC(Ex), Bhiwani
DETC(Ex), Faridabad
DETC(Ex), Faridabad
DETC(Ex), Fatehabad
DETC(Ex), Gurgaon
DETC(Ex), Gurgaon
DETC(Ex), Gurgaon
DETC(Ex), Gurgaon
DETC(Ex), Gurugram(West)
DETC(Ex), Jagadhari
DETC(Ex), Jagadhari
DETC(Ex), Jhajjar
DETC(Ex), Jind
DETC(Ex), Jind
DETC(Ex), Kaithal
DETC(Ex), Kaithal
DETC(Ex), Karnal
DETC(Ex), Karnal
DETC(Ex), Kurukshetra
DETC(Ex), Mewat
DETC(Ex), Narnaul
DETC(Ex), Palwal
DETC(Ex), Panchkula
DETC(Ex), Panipat
DETC(Ex), Panipat
DETC(Ex), Rewari
DETC(Ex), Rewari
DETC(Ex), Sirsa
DETC(Ex), Sirsa
DETC(Ex), Sonepat
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Fatehabad
DETC(ST), Fatehabad
DETC(ST), Fatehabad
DETC(ST), Fatehabad
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)

Payee Code

Employee Name

4P4B1I
4K4B1N
4Q4B1Q
MAB8EG
2C16HG
2I172F
4E5QI5
3K2LCE
LDAWNR
TC4BKN
HIB8ME
4L4B2U
2J2BJJ
2R2BJK
SFAX3A
4J4B43
4L4B41
4M4BNH
CBAD71
4P4B3Y
QDAPNB
HCAQK5
HDAPG9
EBB83P
BAAQ9F
4P4B37
6D4L6M
6B4L6F
4N4BDH
2E5618
4C5QIP
4D5QIO
4K4BDK
3A36JD
3N02GS
4O4BCH
EDB8O2
4L4B4S
4O4B1S
ECB8NM
4K4BNJ
JFAX2T
SDAPVA
BDAQC9
MIB8QN
0H41W9
6I5QMD
9HB818
BGB835
FHB8QV
KDB8PV
LDB8RS
AH217Q
4E1GG3
4K4B42
AC217M
VAB8MH
8A56OJ
EFB8GQ
KEAKEU
4CAQ9B
9DB8VR

GAGAN GUPTA
MONIKA
POONAM AHUJA
SUSHIL KUMAR
SANJAY KUMAR
SURENDER KUMAR
PARVEEN KUMAR
DILRAJ singh
NAVEEN KUMAR
PRASHANT CHAUHAN
SUMITRA
RITU RANI
GITA CHAUDHARY
MAMTA GERA
RITU
SUKHVIR SINGH DHULL
SURENDER
ANURADHA KALRA
JAGBIR SINGH
KANTA RANI
NIRMAL SINGH
MAHAVIR SINGH
MOHAN PRAKASH SHARMA
NEERAJ KUMAR
RAHUL
GEETANJALI KANDWAL
MAMTA RANI
SURUCHI
ANITA YADAV
SUNITA
ANJALI BANSAL
RENU
MANJU BALA
BALJINDER SINGH
JYOTI SHARMA
KARANJIT KOCHHAR
MUKESH KUMAR
RAVINDER SINGH
RITU SAINI
SATBIR SINGH
VISHAL JOSHI
AJAY kumar
JAIPAL
NAVEEN KUMAR
SAJJAN KUMAR
KAPOOR SINGH
MAHENDER SINGH
MUKESH DABAR
NARESH
RITIK
SANDEEP PANWAR
SANJAY KUMAR
ANJU
MAHESH KUMAR
MUKESH KUMAR
SANJAY SHARMA
HOSHIYAR SINGH
KAPIL KUMAR
MAMTA
PARMOD KUMAR
PAWAN KUMAR
PRAVEEN KUMAR

Willing Category
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Disablity
Tenure
Tenure
Retirement
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

<!-- page 3 -->

Sr. No. Office Name
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125

DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Mewat

Payee Code

Employee Name

2G5616
7GAQ04
4R4B2X
HQAN9E
TE41S5
QBAPUF
RHB7TQ
6EB8JN
2JASMI
QGB883
HIB8NV
XJ9XBU
XQ422N
QFB8TJ
7EAQ06
QBB8SX
KD0ELM
QD0HG0
7FAQ05
7LB7C5
MM21DC
6J0BBG
VDB77L
VEB8K6
3I21OO
4B1GFY
VHB70F
UIB7YH
2N2BJX
IBB8V2
IHB8VN
IHB8UF
ICB8W0
7DAQ07
AF4VHV
LDAWT3
GR2N67
AH4VHT
1MAFYQ
4R4B44
2LANVC
VGB8KV
6CB8NL
6FB8BC
6EB8HP
3C36JB
GFB8HW
EFAWN5
2K2BJI
4L4BQO
GEB8KU
GFB8J3
GAB8GK
3B36JC
4O4BNO
6E4L4E
OFB82U
7EB8PY
6O3QUJ
4K4BNS
9HBJWT
7A3QEL
QIAP3Q

Ravi Shankar Prasad
SANDEEP KUMAR
AJAY KUMAR
KHARATI LAL
NAVEEN
SACHIN
AJAY
AJAY CHHOKER
KAMAL SHARMA
RAMAN SONI
SOMESH KUMAR
VIKASH KUMAR AMBAWAT
DEEPAK KUMAR
DINESH Yadav
KAVINDER
MAYANK KOCHAR
NARENDER
PARDEEP
PRADEEP KUMAR
AMIT KUMAR
MONIKA
PAWAN KUMAR
PRIYA
RAKESH
SHILPA
SUBHASH CHANDER
SUDHIR KUMAR
USHA
BALWINDER PAUL
DHEERAJ
JAGMINDER KUMAR
MOHIT
NEHA
JAGBIR
JITENDER SHARMA
NARESH KHATRI
RAVINDER SINGH
SANJAY AHLAWAT
SANJAY KUMAR
BALWINDER KUMAR
JITENDER
RAM KESH
POOJA GUPTA
SAHIL KUMAR
SUMIT CHAHAL
VIJAY SUNEJA
ANKIT KUMAR
ANKIT KUMAR
BHARAT BHUSHAN
DHARMENDER
GURMEET SINGH
JOGINDER KUMAR
MANISH
POONAM
RAJENDER SINGH
ROHIT Malik
ROHIT RAWAL
JAGROOP
MANOHAR SHARMA
RAGHURAJ SINGH
SAHIL NEHRA
SATPAL SINGH
JAGTAR

Willing Category
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

<!-- page 4 -->

Sr. No. Office Name
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
176
177
178
179
180
181
182

DETC(ST), Mewat
DETC(ST), Mewat
DETC(ST), Mewat
DETC(ST), Narnaul
DETC(ST), Narnaul
DETC(ST), Narnaul
DETC(ST), Narnaul
DETC(ST), Narnaul
DETC(ST), Palwal
DETC(ST), Palwal
DETC(ST), Palwal
DETC(ST), Palwal
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
Jt. ETC(Range), Gurgaon
Jt. ETC(Range), Hisar

Payee Code

Employee Name

VGAP17
GIB80J
NDAKWA
0D41W4
REB8RU
2F5617
5F41OE
2D5619
0D6DL1
9NA1MP
6H6BF8
6D6BED
4H1GG0
9BBEND
AO4VI3
4Q4BCO
7G3QEF
4J4B3V
ADAX33
7B5GUU
KDB937
7H5GTY
HGB98T
4L4B32
7AAQ01
6BAQYU
RAAQAY
4P41YM
LDB909
1P2VA3
4L4B3T
4N4B3R
3E16UR
6K0BBF
QGB83Q
5H8LAK
0R0O8V
4F1GG2
4E5QIN
5OAEUP
2D1GFP
4G1GG1
CDB855
4C1GFX
ABB87G
2H172G
9AB8AX
FGB8BB
8CB84B
9IB8B6
MAB8A2
8FB8FX
4O4B3Q
HCB87Q
JCB8ID
HFB8FF
AA217O

NIKHIL
SANJEEV
SONU
GHANSHYAM CHANDEL
LALITA
PUNAM YADAV
ROSHAN LAL
SANJAY YADAV
DEEPAK BAGHEL
LALIT KUMAR
ROHIT KUMAR
VIPIN
ANUP KUMAR
HARSHIT BEWAL
PANKAJ
REKHA
ASHOK KUMAR
BALINDER KUMAR
MANJEET
NEERAJ KUMAR
NIDHI RANI
PAWAN KUMAR
SACHIN CHHIKARA
ANUJ KUMAR
BIJENDER KUMAR
MITHUN KUMAR
SATYA WATI
SURENDER SINGH
UTTAM Singh
AJAY KUMAR
JAGJEET
KRISHAN KUMAR
SUMAN
VIKAS WADHWA
VIKASH
ABHISHEK
HARMEET
LABH CHAND
PARDEEP KUMAR
RAJ KUMAR
RAJ KUMAR
RAM KUMAR
SAHIL
SANJEEV KUMAR
VINIT
ADITYA
RASHMI
ROHIT
RUBI
SANDEEP
SATYANAND
VISHAL
YOGENDER
YOGESH
YOGESH
RAKESH KUMAR
SEEMA

Willing Category
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

<!-- page 5 -->

District-wise list of Willing Assistants
Sr. No. Office Name

Payee Code

Employee Name

Willing
Category

1
2

DETC(Ex), Gurgaon
DETC(Ex), Jind

1CAB2R
9C1AK2

SATISH KUMAR
MANOJ KUMAR

Tenure
Tenure

3
4
5
6
7
8
9
10

DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Bhiwani
DETC(ST), Faridabad(South)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)

XD02S5
WA1Q57
OI02SI
3F2V48
WG1Q5A
4A0B1S
VH1Q0F
0H61A2

ABHISHEK KUMAR
KAMNA RANI
SANGEETA
SATYA PAL
KULDEEP SAINI
PAWAN KUMAR
PAVITRA
RANBIR SINGH

Tenure
Tenure
Tenure
Disablity
Tenure
Retirement
Tenure
Retirement

11
12
13
14
15
16
17
18
19

DETC(ST/PGT), Gurgaon(E)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jhajjar

DD16EY
AK8BCK
3F9GTR
PC4LK8
LG9Q09
QI9GNY
0C36BV
8I4BVI
3H2LBR

VIRENDER KUMAR
PRINCE
SUMIT KUMAR
VIKRAM Singh
DINESH KUMAR
REKHA DEVI
GULJAR SINGH
SUSHIL kumar
RAMESH

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

20

DETC(ST), Jhajjar

3E2LBU

RAMESH Chander

Tenure

21
22
23
24
25
26
27
28

DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Palwal
DETC(ST), Panchkula
DETC(ST), Panchkula
Jt. ETC(Range), Gurgaon

6G17G8
0AA01O
7H96EA
6F17G9
IDAQDS
WA4BO9
RAAP7T
WC1Q4X

KRISHAN KUMAR
SAVITA
ANIL KUMAR
PARVEEN
MANOJ KUMAR
AMRITA TURKA
DHEERAJ Kumar
ANIL KUMAR

Tenure
Tenure
Tenure
Tenure
Disablity
Tenure
Tenure
Tenure

<!-- page 6 -->

District-wise list of Willing Taxation Inspectors
Sr. No. Office Name

Payee Code Employee Name

Willing Category

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29

DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Ambala
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST), Bhiwani
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST/PGT), Faridabad(E)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)

II4B4Q
TCAPHF
AG5GN2
WA4B69
6B1QBH
2G02E2
VF3AFY
DDBCYP
0CAYUM
1H2BOH
3H2LA1
6D4V5D
IC4BDN
3D2LAW
IG4B23
MEBCQW
RNAYHF
3H16TP
BA4Y8N
6E5QMQ
NA0LLO
WMADIM
QHBC9F
8DB8N0
RGBBG0
3E1QIS
8A4BVH
3B16SW
LEAKIP

ADARSH
BIRENDER SINGH
DEEPAK KUMAR
GURDYAL
MANDEEP SINGH
PARDEEP KUMAR
PRINCE
PRITIKA
SANJEEV KUMAR
VINOD KUMAR
DAYA NAND
DEVENDER
MUKESH
PANKAJ
SUNIL KUMAR
AMIR KHAN
EKANT
GULAB SINGH
MANOJ KUMAR
MANOJ KUMAR
RAVINDER KUMAR
SHAILENDER
SUNIL
AMIT KUMAR
ANIL
BISHAN KUMAR
MADAN PAL
NIHAL SINGH
NISCHAL KUMAR

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure

30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67

DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(North)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(South)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Faridabad(W)
DETC(ST), Fatehabad
DETC(ST), Fatehabad
DETC(ST), Fatehabad
DETC(ST), Fatehabad
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)

2C1732
JFBBI7
JFBBJO
1B2BNX
WCBBA5
NFAPX2
NG0L8M
4A16CU
3BBCXT
LA24GS
0FBC6S
XLB6O4
NA0LME
WFBBAT
WHBBI1
NE0L0E
BF7F75
UBAYXQ
WFBBE7
XBBB0F
6F1QCC
3G16X4
JDAXCC
6B5QLU
2EBCD2
AG213M
9HBC7G
6F5QMY
AC213H
5ABC4L
XI23BN
8A0BCD
6ABC60
RHAP02
4H5G1B
6F1QB4
AD213G
UIAXJG

PRADEEP KUMAR RAJORA
SANDEEP KUMAR
SHARVAN KUMAR
VIJAY SINGH
Bijender Singh
MOHIT
NASEEB SINGH
NEPAL SINGH
RAHUL CHOUHAN
Rakesh
Rinku
SHEESH PAL
VIJAY Kumar
AKSHAY KUMAR
DEEPAK JANGRA
GOURAV VERMA
GURMEET SINGH
KULDEEP
MANOJ KUMAR
NAVEEN KUMAR
RAM NIWAS
RAM SINGH
SANDEEP
SHANKAR
SUJAN SINGH
KAMLESH DEVI
RAMNIWAS
SUDESH MEHTA
SUNITA RANI
ABHISHEK DHANDA
AJMER SINGH
ANIL Kumar
ANIL KUMAR
BHUPENDER SINGH
DEVENDER KUMAR
KESHAV DEV
KRISHNA DEVI
MOHIT KUMAR

Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure

<!-- page 7 -->

Sr. No. Office Name

Payee Code Employee Name

Willing Category

68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96

DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST/PGT), Gurgaon(E)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurgaon(W)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)

2C5611
QA4CWX
JC4BP1
5BBC6I
2I5614
BIAW01
1DB8D8
3G1QIQ
NG0LC0
6ABCAW
6I0BMO
3G2L84
3IBC3P
PABBCU
CU4DBC
5CAXYW
2B5612
IB4BLP
7BB3YO
3BBC9H
NE0L1D
NF0LPO
UC66OC
LB4NQN
6B1QJ0
TIBB5G
4D3GKP
JF4BPP
6E1QAX

NAUNIHAL SINGH
PANKAJ
PAWAN KUMAR
PRADEEP
ROHTASH SINGH
SOMBIR
SUMER SINGH
SUNIL KUMAR
ANURAG SHARMA
ARUN
BAL KISHAN
DILBAG SINGH
GAURAV DAHIYA
KAPTAN SINGH
KHAJAN SINGH
MOHIT YADAV
NARENDER KUMAR
OMKAR SINGH
RISHI KAPOOR
SHIVENDER SOLANKI
SUNIL NAIN
SUSHIL KUMAR
VINOD KUMAR
VIRENDER
BAJRANG LAL
DEEPAK
DEEPAK SHARMA
HARPAL
JAGBIR SINGH

Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117

DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram (South)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Gurugram(North)
DETC(ST), Hisar

0DBCED
NC0LAO
VFAPDW
0EBCF2
2D02EW
RGAPGN
YFBB28
SBBBNX
4ABCCN
3F2LAC
TGAPL7
0I61AA
8HBC6R
VIAPGQ
PD0LMR
FA44CR
4CBCAE
4H4BDW
3D2LA5
SABBOF
2D02G3

PARVEEN KUMAR DAHIYA
RAJESH Kumar
RAKESH KUMAR
RAVINDER
SOHAN LAL
TARUN
VIKAS SINGH
ADITYA
IRFAN KHAN
KAVINDER Kumar
LALIT KUMAR
MAHESH PAL
MOHAMMAD IRSHAD
NEETU BALA
PRAVEEN KUMAR
ROHIT SHARMA
SANDEEP KUMAR
SANJAY KUMAR
SURESH KUMAR
VIKAS JANGRA
DILBAGH SINGH

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135

DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Hisar
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jagadhari

AF214D
WABBE3
2E1GFX
2A1GH8
IF4B24
8D21CR
4G5QHV
3ABCXC
4I4BCW
ID4B26
RFALXT
0I4BBJ
2H4BPM
0E36CJ
KCBCHR
7BBCOY
4D3GII
FBBHV5

KULDEEP KUMAR SHARMA
MOHIT KUMAR
OMPARKASH SINWER
RAJESH KAGRA
SAJJAN KUMAR
SURENDER KUMAR
VINOD KUMAR
AMIT VERMA
ANIL KUMAR
JITENDER KUMAR
MAJOR SINGH
RAJ Kumar
RAJESH KUMAR
RANDHIR SINGH
RAVINDER CHOPRA
RUPA RANI
SATISH MOHAN
SHALINI

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

<!-- page 8 -->

Sr. No. Office Name

Payee Code Employee Name

Willing Category

136
137
138
139
140
141
142
143
144
145
146
147
148
149

DETC(ST), Jagadhari
DETC(ST), Jagadhari
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jhajjar
DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Jind
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Kaithal

4B3GJ1
WH4B26
6H0B9B
3H16S8
3D2LB4
3D2V2L
6E0B95
0F3QA0
3A2V3E
3D4LQE
SFB7OE
ND0L8G
WEBBRM
1I3Q9O

SUNDER LAL
VIRENDER KUMAR
RANI DEVI
VED PAL SINGH
VIRENDER KUMAR
DEEPAK
PARVEEN KUMAR
RAJ KUMAR
SATISH KUMAR
SURENDER SINGH
Amandeep
DEEPAK KUMAR
RAHUL KUMAR
RAMDIYA

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure

150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
176

DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Kaithal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Karnal
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Kurukshetra
DETC(ST), Mewat
DETC(ST), Mewat

0A3Q9X
FCBD7E
4H5G0L
0AAQ2F
BI419A
ONAPOT
0A36CN
SLAXPR
0F36CI
RHBBKD
4C4BE0
3A4LPR
2BBCUX
7GAUXL
4G4BCG
RDBBIA
4A4BCM
TABBGV
4F4BD7
3I4LPS
2B9B5A
JE4BPQ
4G4BCY
0H3QAG
HFBC26
NE0L4S
BE1QFE

RAMESHWAR DASS DASS
RITU
SAJJAN Kumar
SHUSHIL SHARMA
AMIT SAINI
GOURAV
GURMEET SINGH
NARESH KUMAR
NEELAM KUMARI
NIRMAL
PAWAN Kumar
RAVINDER PARKASH
SATISH KUMAR
SATISH KUMAR
SATPAL SINGH
SUMIT Chechi
UMESH KUMAR
VISHAL
BALWINDER SINGH
GURMEET
OM PARKASH
RAJESH KUMAR
RAKESH
RENU BALA
SHISHPAL KUMAR
DAL CHAND
JOGINDER SINGH

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

177
178
179
180
181
182
183
184
185
186
187

DETC(ST), Narnaul
DETC(ST), Palwal
DETC(ST), Palwal
DETC(ST), Palwal
DETC(ST), Palwal
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panchkula
DETC(ST), Panchkula

0G41AE
3F1A5K
2A1725
2I560N
9A6B8J
4A4BD3
4C4BCK
4F4BDP
4A4BC4
DI4B0Q
6A5QMU

SULOCHANA CHAUDHARY
MADHU BALA
PUSHPA DEVI
RAJIV SINGH
VIJAY PAL
Devi Dayal
DHARAM Pal
MANOJ Kumar
POONAM Lata
SANDEEP CHAUDHARY
SANT SWAROOP

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

188
189
190
191
192
193
194
195
196
197
198
199

DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat
DETC(ST), Panipat

4I5G0T
NH0L2I
IGBCKV
RB3H2L
0H16YN
PK5GRF
4E5G0X
4B3GJJ
5B4LHN
BF4BW8
4E5G1N
SBBB02

AJAY KUMAR GAHLAWAT
AMIT
ANIL KUMAR
JITENDER SINGH
JOGINDER SINGH
MEENA
PROMILLA DEVI
RAJESH KAPOOR
RAJINDER SINGH
RAMESH KUMAR
SURESH
VIJAYANT SABHARWAL

Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

200
201

DETC(ST), Panipat
DETC(ST), Panipat

3F16VG
RFBB3N

VIKAS KUMAR BHARDWAJ
VINAY KUMAR

Tenure
Tenure

<!-- page 9 -->

Sr. No. Office Name

Payee Code Employee Name

202
203

DETC(ST), Rewari
DETC(ST), Rewari

RIAPPU
II4BMH

204
205
206
207
208

DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari
DETC(ST), Rewari

0H41VA
0B41VG
KE4B7P
2H560X
0E41VV

209
210
211
212
213
214
215
216
217
218
219
220
221
222
223
224
225
226
227
228
229
230

DETC(ST), Rewari
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Rohtak
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sirsa
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat
DETC(ST), Sonepat

4E4BCI
5B4LGX
6H4V5I
3A2LA8
6F4V43
7A1Q1R
FLAY91
9ABDVG
5E1G0R
6A0B99
4A4BEB
NK0LWU
4D5G16
IE4B25
3B4LQG
7EBCAR
IGBCGQ
3F4LCQ
4F5G0W
6D0B96
3A4LRG
EHBBTH

ABHIMANYU
AMAN KUMAR
MAHIPAL SINGH
MALHOTRA
MANISH KUMAR
RAJESH SHARMA
RAM SAWARUP
SAROJ YADAV
VIRENDER SINGH
NINANIYA
JITENDER KUMAR DANGI
MAHESH KUMAR
RAJESH KUMARI
SANJEEV KUMAR
SUDHIR KUMAR
DEEPAK KUMAR
KAVITA RANI
KRISHAN KUMAR
OM PARKASH
RAJESH KUMAR BASERA
SANDEEP KUMAR
AJAY KUMAR SAROHA
AMIT KUMAR DAHIYA
AMIT KUMAR
BIJENDER
HEMANT
JASVIR SINGH
RAJESH KUMAR
RAM AVTAR
RAVINDER MANN
VIRENDER

Willing Category
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Retirement
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure
Tenure

231

Excise & Taxation Commissioner

4J4B34

ANJU MAHENDRU

Representation approved
by Hon'ble CM

232

Excise & Taxation Commissioner

3I16UE

BHARAT SINGH NEGI

Representation approved
by Hon'ble CM

233

Excise & Taxation Commissioner

QC2BOX

BHOOP SINGH

Representation approved
by Hon'ble CM

234

Excise & Taxation Commissioner

6B17FN

DEEPAK KUMAR

Representation approved
by Hon'ble CM

235

Excise & Taxation Commissioner

4C4BDS

GURNAM Singh

Tenure

236

Excise & Taxation Commissioner

4O4B38

HEMA SHARMA

Representation approved
by Hon'ble CM

237

Excise & Taxation Commissioner

QM4L80

INDERJIT kaur

Representation approved
by Hon'ble CM

238

Excise & Taxation Commissioner

JD4LS5

JASBIR

Representation approved
by Hon'ble CM

239

Excise & Taxation Commissioner

0E4BBE

JYOTI

Tenure

240

Excise & Taxation Commissioner

6A9GO7

KRISHAN KUMAR

Representation approved
by Hon'ble CM

241

Excise & Taxation Commissioner

6F17FJ

KRISHAN KUMAR

Representation approved
by Hon'ble CM

242

Excise & Taxation Commissioner

DE16EX

KULDEEP

Representation approved
by Hon'ble CM

KULDEEP KUMAR

Representation approved
by Hon'ble CM

243

Excise & Taxation Commissioner

4Q4B2Y

<!-- page 10 -->

Sr. No. Office Name

Payee Code Employee Name

Willing Category

244

Excise & Taxation Commissioner

0F3GHC

PARDEEP KUMAR

Representation approved
by Hon'ble CM

245

Excise & Taxation Commissioner

4A4BOJ

PARVEEN KUMAR

Tenure

246

Excise & Taxation Commissioner

4J4B2W

PARVINDER KUMAR

Representation approved
by Hon'ble CM

247

Excise & Taxation Commissioner

BDBDWJ

PAWAN KUMAR

Tenure

248

Excise & Taxation Commissioner

4Q4B36

POOJA SHARMA

Representation approved
by Hon'ble CM

249

Excise & Taxation Commissioner

4M4B2T

PRADEEP KUMAR
SANDILYA

Representation approved
by Hon'ble CM

250

Excise & Taxation Commissioner

RB2LMG

SANDEEP

Representation approved
by Hon'ble CM

251

Excise & Taxation Commissioner

4G5G2T

SATPAL SINGH

Representation approved
by Hon'ble CM

252

Excise & Taxation Commissioner

5E4L4F

SHYAM CHAND

Representation approved
by Hon'ble CM

253

Excise & Taxation Commissioner

4O4B3H

SUBE SINGH

Representation approved
by Hon'ble CM

254
255

Excise & Taxation Commissioner
JT.ETC(Range), Rohtak

7G96DL
6D4V45

SUSHILA DEVI
RAJESH KUMAR

Representation approved
by Hon'ble CM
Tenure
