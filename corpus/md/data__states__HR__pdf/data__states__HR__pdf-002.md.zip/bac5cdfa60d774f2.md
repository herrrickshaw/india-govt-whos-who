---
doc_id: "bac5cdfa60d774f2"
source_url: "https://cdn.s3waas.gov.in/s3e56954b4f6347e897f954495eab16a88/uploads/2026/06/17810855727481.pdf"
ministry: "Hisar"
title: "Tender for the procurement of T-shirts and tentage by the AYUSH Department, Hisar, on the occasion of the 12th International Yoga Day 2026 (10-06-2026)"
date: ""
pages: 12
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "8331bf35f45baaf6"
---

<!-- page 1 -->

न व मी eee Se eee eee eee eee me
‘ # District Ayurvedic Officer, Hisar . = A 7 0 ff lo H .
( x ¥ 3
> Histrict Ayurvedic Officer, Hisar
X Ss wf Aq C
$s 50 Bedded AYUSH Hospital, Mayar, Hisar Contact No.74(9844299 (off)
DepartmentOf
AYUSH
—_————— 0 0 नतनोत3।आ।त
Tender No. DAO/HISAR/IYD/2026/ Dated:- 09.06.2026
Short Term Tender Notice
District Ayurdedic Officer, Hisar inviting sealed tenders for the Purchase of below mentioned items for
International Yoga Day 2026 .
i. Approx. 2500 White T-Shirts with Logo to be supplied on or before 8-06-2026.
2. Tentage items as per detail mentioned in terms & condition.
Detail Terms and conditions of items and DNIT can be obtained from O/o Distt. Ayurvedic
Officer, Hisar by hand/ by Email or can be downloaded from website of Distt. Administration
Hisar i.e. hisar.gov.in Undersigned may be contacted for any information or change.
[ Tender ID _| DAO/HSR/TYD/2026/0l_
Fee Date and time of Bid 5.06.2026 up to 5:00 PM in office of District
Submission by registered post or Ayurvedic Office, 50 Bedded AYUSH Hospital,
| By Hand | ____| Mayar, Hisar
| Tender Opening Date. Technical bid on 6.06.2026 (02:00 PM )
Bae Financial Bid on 6.06.2026 (03:00 PM)
Office of City Magistrate Hisar
Place of opening of Tender I* floor Mini Secretariate Hisar
Email:- daohisar2025@gmail.com Contact No.S4!GI68904
District ex Officer
2
ee j

<!-- page 2 -->

DEE \Q©0—0—0ClCO EEO लक
2
TERMS & CONDITIONS
(Regarding purchase of T-Shirts for 2'° International Yoga Day 2026)
l. Cloth material should be of GSM 60 minimum as per standard and bidder have to
submit the sample of T shirt at the time of opening of tender.
2. T-Shirt should be of white Color and round neck. Any change in color will be intimated
on the day of opening of tender.
3. Size should be Indian Standard.
4. Requirement of approx. 2500 T Shirt(200 Round Neck and 400 with-collar) of the size
as follows:-
a. 38” b. 40” c. 42” d. 44”
5. Quantity of T-Shirt can be increased 40% on higher side and 50% Lower side. |
6. Color and Size logo and position:-
a. International Yoga day Logo — Front Side (size)
b. IYD-2026 Back Side.
7. Consignee should be F.O.R. at the address:-
District Ayurvedic Office, 50 Bedded AYUSH Hospital, Mayar, Hisar
Delivery of Material should be on or before 8-06-2026.
8. Rate of T-Shirt should be inclusive of GST.
9. T-Shirt should be neat and clean.
0.Quality and Quantity should be properly maintained and will be checked by inspection
committee
.Change in size, quality, any other defect or not delivered on time will not be accepted.
If under any circumstance’s consignment will be accepted after levying penalty of 0% |
of total amount.
2.The successful bidder will have to deposit the Tender fee of Rs. 000/ and earnest |
money of Rs. 5000/- (Five thousand only) as security by way of Bank draft payable to |
District Ayurvedic Officer, Hisar before getting formal purchase order. |
3.In case of two or more bidders qualify and quote same lowest rates then on the spot |
revise option will be given to get to L-2. |
4.Purchase Committee reserves the right to split the order to more than one firm to get
the supplies in time & also reserves the right to cancel the tender without showing
any cause.
5.In case of failure to supply within stipulated time the purchase will be made at risk and
cost of the firm.
of
Distri dic Officer,

<!-- page 3 -->

ee कक किक कक कक भभ/$झफडऊफ़़़्््र्र्ऊ+़़्ऱ़़़़़॒॒॒- :+५फ-.
कं
TERMS & CONDITIONS
(Regarding Hiring of Tentage items for 2""_ International Yoga Day 2026)
| l, Rate per unit per day of the items should be mentioned in Financial Bid

2. Consignee should be F.O.R. at the venue of Yoga Day Celebration.

3. Tentage Material should be from the date of opening of tender upto 2-06-2026 or as
per the schedule of TYD 2026

4. Hiring rate of tentage items should be inclusive of GST.

5. Tentage items should be neat and clean

6. Quality and Quantity should be properly maintained and will be checked by
inspection committee.

7. Bad Quality & defective or not delivered in time will not be accepted. If under any
circumstances, consignment will be accepted after levying penalty of 0% of total
amount.

8. The successful bidder will have to deposit Tender cost of Rs.!000 and Earnest
Money of Rs. 5000/-(Five thousand only) as security by way of Bank draft payable
to District Ayurvedic Officer, Hisar before getting formal hiring order.

9. Incase two or more bidders qualify and quote same lowest rates then on the spot
revise option will be given to get to L-I.

0.Purchase Committee reserves the right to split the order to more than one firm to
get the supplies in time & also reserves the right to cancel the tender without
showing any cause

].In case of failure to supply within stipulated time the hire services will be made at
risk and cost of the firm.

Px
District Ayyrvedic Officer,
Hisar

<!-- page 4 -->

..____...._____€__॒_॒_॒_॒_॒_॒_॒_॒_॒_॒_॒____३ >> ििमिकि कक किक ली लकी लीक कक ककककशकककिकशकशकशकशकककशकककककिकिककककक कक कवि क_.ररऱ़]़़़्॑.़्.ऱऊ्-ऊ-्-्-््ऱ व
ANNEXURE- 2
OFFICE OF DISTRICT AYURVEDIC OFFICER , HISAR
TECHNICAL BID Form for purchase of T Shirt/Tentage
a Tender ID - “DAO/HSR/IYD/2026/0” की
| [Sr oe = Page = |

| eee a No. — िकजकि-ए |

| Cost of Tender Form (Rs. 000/-) Non- रा: || अअ |

| = le |

| | 9.0.

L eee 82888 ]५०.............-:-:-28८0......-: | ०००००

\2 Due date for Tender 5.06.2026 up to 5:00 PM |

| |

बी पा aE FT
3 Opening date and time of tender Technical bid on 6.06.2026 (02:00 PM )

| Financial Bid on 6.06.2026 (03:00 PM)
Seas

4 Name of the Agency / Firm / Proprietary |
concern registered & address

5 ' Telephone number of Authorized Person
with E-mail |

6 _| Registration number of the firm/ Agency | |

= ही (Ifany) i itt | मी aae aoa

a | PAN Card of Agency (Attach attested copy) |

|
eae 8 Details of Earnest Money | |
a) Amount Rs. 5000.00 |
| (6) D.D.No. a
| [c) In favour of
roe ‘Date of Issue
| . ९) Name of Issuing Bank
: ~ | GST No. ia |
_| (Attach Certified Copy) _

0 | Affidavit of not blacklisted by any Govt./ Semi |
Govt./ Deptt. of the State & not connected to |
any blacklisted firms (Duly attested by Notary

___| Public).
I] Any Other Information
2 Declaration by the bidder This is to certify that I/We before
signing this tender have read and fully
under stood all the terms and conditions
| contained herein and undertake myself
| /ourselves to abide by them.
Enclosed ----- Page with numbers
with —self-attested copies of |
documents.
|

<!-- page 5 -->

OL Eee ene eee Ss कक
2
े Signature of the bidder, Name, crf | fon
address (with seal) and email address with
contact no.
For Official Use ही --
4 Dairy No. with date of = up to
5.06.2026 up to 05:00 PM
i5 | Signature Committee Members fies eect
= मम मनन 82428 मनन लत |
|
| _

<!-- page 6 -->

न] न लय | व विन चकित की चल वि न की मन नमन न न a ae ee ae eet
Annexure-2
FINANCIAL BID FOR PURCHASE OF T- SHIRTS
To
The Distt. Ayurvedic Officer,
Hisar
Respected Madam / Sir,
LF OWe oe pceterctrernctrqeeeceeerce «+ Submitted the “bid for
Tender ID : “DAO/HSR/IYD /2026/02” dated ................000 fOr
Purchase of T-Shirts for International Yoga day 2026.
2. | / We thoroughly examined and understood instructions to tenders, scope
of work, term and conditions of contract given in the tender document and
those contained appendix of Term & condition of contract and agree to
abide by them.
3. |/We hereby offer to provide T Shirts for |YD 2026 at the following rates. |
/ We understand that | /We are not entitled to claim any enhancement of
rates on any account during the tenure of the contract.
[ Sr. No. | Description हूँ Quantity Rate |
l Supply of T -Shirts round neck with Logo for 200 |
| International Yoga Day 2026
2 Supply of T -Shirts with collar and Logo for International 400
Yoga Day 2026 |
| ‘Add: Statutory Obligations if any (Please Specify Each on the basis of groups)
| Rate withGST i |
Sct SEE
Signature of Authorized
Person Name &
Designation :
Name of Firm/Company/Agency :Contact Details :

<!-- page 7 -->

Annexure-3
} FINANCIAL BID FOR Hiring OF TENTAGE AND OTHER ITEMS
To
The Distt. Ayurvedic Officer,
Hisar
Respected Madam / Sir,

LD / We तन दम तल व कम मनन नमकीन की कक कप की + 0 मन मिस लिये bid for
Tender ID: “DAO/HSR/IYD /2026/02” dated .......sscsssresnnnenenseannee FOF Hiting of
Tentage and other Items for International Yoga day 2026.

4. | / We thoroughly examined and understood instructions to tenders, scope of work, term
and conditions of contract given in the tender document and those contained appendix of
Term & condition of contract and agree to abide by them.

5. | /We hereby offer to provide Tentage Items for IYD 2026 at the following rates. | / We
understand that | /We are not entitled to claim any enhancement of rates on any account
during the tenure of the contract. ————— cee eee

| Sr.No. | Description a Quantity

| | Supply of Tentage Items for International Yoga Day 2026 Rate/ item
|]. Stage I0 x 6ft

| stage 30 x20 with carpet | |
— 2. (Carpet 5X30 for 000 person on dt 9.6.2025 and 2000 person on dt

2I.6.2025

| a - He

| 3 vines (Gadda) 2 inch with white cover approximate 75 pe

[4 Kalen

fe — नि किक fe |

| 6 ables ae

7 |Table Cloths/cover
8 [Dunlop Chairs with cover
9 white chandni
| I0 Sound system with Podium Mike ,Cordless Mike, Collar Mike,
Mixer and battery back up on dt 9.6.2026 and 2.6.2025 without
battery backup
[TL [Red Carpet
[a jenset Silent with diesel
3 Ee & 8x20 with video coverage Seer
Signature of Authorized Person
Name & Designation :
Name of Firm/Company/Agency :Contact Details :

<!-- page 8 -->

कल a E
ey
4 TERMS, CONDITIONS AND GENERAL INSTRUCTIONS TO THE TENDERER ERMS, CON S AND GENERA STRUC 3 TO THE TENDE
(Tender ID. “DAO/Hsr/IYD /2026/ 04”)

The bidders are expected to read carefully all the terms and conditions of the tender

documents and theirsubmission will be taken as consent to abide

. The tender is “Two Bid’ document. The technical bid should contain all the
relevant information anddesired enclosures in the prescribed format along
with Earnest Money Deposit (EMD). The financial bid should contain only Price
bid document. In case, any bidder encloses the financial bid within technical
bid, the same shall be rejected summarily.

2. The tender form and other terms and conditions may be collected from the
Office of District Ayurvedic Officer Hisar by hand/ by Email or can be
downloaded from website ofDistt. administration hisar.gov.in . The bid must
accompany with the earnest money deposit fee of Rs. 5000/- (Five thousand )
in the form of demand draft of any scheduled bank drawnin favour of District
Ayurvedic Officer, Hisar at payable at Hisar.

3. The Tenders should be type written or handwritten but there should not be any
overwriting or cutting.Correction, if any, shall be made by neatly crossing out,
initialing, dating and rewriting. The name and signature of bidder’s authorized
person should appear on each page of the application. All pages of the tender
document shall be numbered and submitted as a package along with
forwarding letter on Firm’s letter head.

4. The Contracts concluded as a result of this Tender Inquiry shall be governed by
the ‘Terms & Conditions’ and other relevant instructions as contained in this
Tender Document.

5. The prices/rates quoted should be indicated in words as well as in figures. In
case of any discrepancy, lower amount/rates shall be considered as valid.

6. Bidders are requested to quote their prices on a firm & fixed basis
for the entire period of the Contract. Bids of the firms received with prices
quoted on variable basis shall be rejected without assigning any reasons and
no communication in this regard shall be entertained.

7. Quotations qualified by such vague and indefinite expressions such as “subject
to prior confirmation”, “subject to immediate acceptance” etc. will be treated
as vague offers and rejected accordingly. Any conditional tender shall be
rejected summarily.

8. Bidders are requested to enclose a copy of their valid certificate of PAN No.,
TAN No, Sale Tax/GST No. & Affidavit of not blacklisted by any Govt./ Semi
Govt./ Deptt. of the State & not connected to any blacklisted firms (Duly
attested by Notary Public) till date or any other document as requested by the
Office with their tender.

9. Tenders received without EMD amount by way of demand draft in favor of

<!-- page 9 -->

विन Cee ee ee a a eer re ee. eet Of ae eet eee Re (eee tee et | eee eee ety lot कक
fl
District Ayurvedic Officer, Hisar will not be considered at all and sha Il be
हे summarily rejected.

0. Refund of Earnest Money Deposit: The EMD submitted by unsuccessful bidders
i shall be returned to them without any interest whatsoever, within 60 days after
f conclusion of the contract with successful bidder. The EMD submitted by

successful bidders shall be returned to them after conclusion of the contract
with successful bidder according to conditions stipulated in the bid document.

4. Bidders may note that if the date of tender opening given in this Tender
Document is declared to be a gazette holiday, the tender shall be opened on
the next working day at the same timing. In such an event the closing hours for
receipt of tenders in the Office of District Ayurvedic Officer Hisar will stand
automatically extended up to 2.00 A.M. of the next working day in the
Government offices.

2. Late/delayed tenders received in the Office of District Ayurvedic Officer, Hisar
due to any reasonwhatsoever will not be accepted under any circumstances.

3. At any time prior to date of submission of tender, Tender Inviting Authority
may, for any reason, or decision, modify the terms & conditions of the tender
document by a corrigendum displayed at the Office of District Ayurvedic
Officer, Hisar In order to provide reasonable time to take the amendment into
account in preparing their bid, Tender Inviting Authority may or may not, at his
discretion, extend the date and time for submission of tenders.

4. Tendering firms are at liberty to be present or authorize a representative to be
present at the opening of the tender at the time and date as specified in the
Schedule. The name and address of the representative authorized to attend
the opening of the tender on behalf of a tendering firm should be indicated in
the tender. The representative so deputed should also bring with him a letter
of authority from the firm for having been authorized to be present at
the time ofopening of tender. Only one representative per firm shall be
permitted to attend the opening of the tender. The name and address of
permanent representative of the firm, if any, should also be indicated in the
tender.

The bidders having experience in similar field may be given preference.
5. DOCUMENTS COMPRISING THE BID:
The bids prepared by the bidder shall comprise of
(I) The Technical Bid and
(2) Financial Bid:
(DTECHNICAL BID: - To qualify in the Technical bid the firm should have the
minimum eligibility Criteria as under and the firm in this regard must submit the
documents in support of their eligibilitycriteria and the Tender is liable to be
rejected if the following documents are not received therewith:
(a) Duly filled format of Technical Bid as per Annexure “2”.
(b) The Technical bid should be accompanied by Demand Draft/ Bank
Guarantee of Rs. 5000/-(refundable) for EMD/bid security.

<!-- page 10 -->

eee Se ee eee न Eee ee ee ae eee ee sees ee See eae et eeaee ee oe
Jo
(० Attested copy of Name of the Agency / Firm / Proprietary concern registered
4 & address along withregistration no. (if any)

(d) Attested Copy of PAN Card

(e) Attested copy of GST No. as applicable

(f) Affidavit of not blacklisted by any Govt./ Semi Govt./ Dept. of the State & not connected
to any blacklisted firms (Duly attested by Notary Public) till date.

(g) The fee for tender documents will be Rs. ,000/- (Rupees One Thousand Only).
This fee shall be paid in the form of Demand Draft issued by a
nationalized/scheduled bank, drawn in favor of “ District Ayurvedic Officer,
Hisar payable at Hisar”. This fee is non-refundable. The tender fee draft should
be enclosed in separate cover superscripted “Tender fee”.

(2) FINANCIAL BID: - The financial bid shall contain:
Price Bid Form as per
(a) Annexure - 2 for T Shirts
(b) Annexure -3 for tentage Items

SEALING AND MARKING OF BIDS:

All the relevant documents, D.D. of earnest money deposit along with tender
document should beplaced in sealed envelope super scribed as Tender ID.
“DAO/HSR/TYD/2026/0!”. The biddershall seal the EMD along with the
Technical Bid and the Financial Bid in separate envelopes and keep them in
a bigger properly sealed envelope. The envelope containing the EMD along
with Technical Bid shall bear the name “TECHNICAL BID for Tender
ID. “DAO/HISAR/TYD/2026/0” The envelope containing the Financial
Bid shall bear the name “FINANCIAL BID for Tender ID.
“DAO/HISAR/TYD/2026/0!” on the envelope for avoiding any mismatch.
The sealed envelope shall be addressed as under:
(a) Addressed at the following address:
Office of District Ayurvedic Officer, Hisar
50 Bedded AYUSH Hospital, Mayar, Hisar
The envelopes shall be super scribed as TENDER ID.
“DAO/HISAR/IYD/2026/02” and the words ‘DO NOT OPEN BEFORE’ (due
date & time).

(b) The envelopes shall indicate the name and address of the bidders to
enable the bid to bereturned unopened in case it is declared ‘late’ or
rejected.

(c) Bids shall be delivered in person in the office of “District Ayurvedic Officer
50 Bedded AYUSH Hospital Mayar, Hisar” or shall be sent by
Registered/Speed Post the Purchaser shall not be responsible if the bids
are delivered elsewhere.
