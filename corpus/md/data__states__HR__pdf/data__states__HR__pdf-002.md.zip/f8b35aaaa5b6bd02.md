---
doc_id: "f8b35aaaa5b6bd02"
source_url: "https://cdn.s3waas.gov.in/s3e56954b4f6347e897f954495eab16a88/uploads/2026/06/17812399061802.pdf"
ministry: "Hisar"
title: "Tender for the procurement of T-shirts and tentage by the AYUSH Department, Hansi, on the occasion of the 12th International Yoga Day 2026 (12-06-2026)"
date: ""
pages: 12
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "11c42992524109bd"
---

<!-- page 1 -->

लॉ ®
छा .
Vistrict Ayurvedic Officer /Nodal
PVedic ICer oda
eportment of 0 i . | a
icer, hans!
___#Deputy Commissioner Office. Hansi
eputy Commissioner Office, Han
Tender No. DAO/Hansi/IYD/2026/0 Dated:- 0.06.2026
Short Term Tender Notice
District Ayurdedic Officer/Nodal Officer, Hansi inviting sealed tenders for the Purchase of below mentioned
items for International Yoga Day 2026.
i. Approx. 2500 White T-Shirts with Logo to be supplied on or before 48-06-2026.
2. Tentage items as per detail mentioned in terms & condition.
Detail Terms and conditions of items and DNIT can be obtained from O/o Distt. Ayurvedic
Officer, Hisar by hand/ by Email Undersigned may be contacted for any information or
change.
Tender ID DAO/HANSIAYD/2026/0
Last Date and time of Bid 5.06.2026 up to 5:00 PM in office of District
Submission by registered post or | Ayurvedic Office, 50 Bedded AYUSH Hospital,
By Hand Mayyar, Hisar
Tender Opening Date. Technical bid on 6.06.2026 (2:00 Noon )
Financial Bid on 6.06.2026 (0:00 PM)
Office of City Magistrate Hansi
Place of opening of Tender 2"4 Floor Mini Secretainate Hansi
Email:-daohisar2025@gmail.com Contact No.I663-258888
94(6995377
District 8s Officer/Nodal Officer,
Hansi

<!-- page 2 -->

@
7 TERMS & LERMS & CONDITIONS
i. Cloth material should be appropriate GSM as per standard and bidder have to submit
the sample of T shirt at the time of opening of tender. है
2. T-Shirt should be of white Color and round neck. Any change in color will be intimated
on the day of opening of tender.
3. Size should be Indian Standard.
4. Requirement of approx. 2500 T Shirt(200 Round Neck and 400 with-collar) of the size
as follows:-
3. 38/ b. 40” ८. 42” 0... 44”
5. ee of T-Shirt can be increased or decreased 40% on higher side and 50% Lower
side.
6. Color and Size logo and position:-
a. International Yoga day Logo —Front Side (size)
b. IYD-2026 Back Side.
7. Consignee should be F.O.R. at the address:-
D.C Office, Hansi
Delivery of Material should be on or before 8-06-2026.
8. Rate of T-Shirt should be inclusive of GST.
9. T-Shirt should be neat and clean.
0.Quality and Quantity should be Properly maintained and will be checked by inspection
committee
44. (988 ॥ size, quality, any other defect or not delivered on time will not be accepted.
If under any circumstance’s consignment will be accepted after levying penalty of 0%
of total amount.
2.The successful bidder will have to deposit the Tender fee of Rs. 000/ and earnest
money of Rs. 5000/- (Five thousand only) as security by way of Bank draft payable to
District Ayurvedic Officer, Hisar before getting formal purchase order.
3.In case of two or more bidders qualify and quote same lowest rates then on the spot
revise option will be given to get to L-I.
4.Purchase Committee reserves the right to split the order to more than one firm to get
the supplies in time & also reserves the right to cancel the tender without showing
any cause.
45.7 ८३५९ 0 failure to supply within stipulated time the purchase will be made at risk and
cost of the firm.
District ५० व... Officer,
Hansi

<!-- page 3 -->

J @
TERMS & CONDITIONS
Regarding Hiring of Tentage items for I2 International Yoga Day 2026)
का pl per unit per day of the items should be mentioned in Financial Bid
* ; onsignee should be F.O.R. at the venue of Yoga Day Celebration.

3. Tentage Material should be from the date of opening of tender upto 2-06-2026 or as
per the schedule of IYD 2026

4. Hiring rate of tentage items should be inclusive of GST.

5. Tentage items should be neat and clean

6. Quality and Quantity should be properly maintained and will be checked by
Inspection committee.

7. Bad Quality & defective or not delivered in time will not be accepted. If under any
circumstances, consignment will be accepted after levying penalty of 0% of total
amount.

8. The successfull bidder will have to deposit Tender cost of Rs.l000 and Earnest
Money of Rs. 5000/-(Five thousand only) as security by way of Bank draft payable
to District Ayurvedic Officer, Hisar before getting formal hiring order.

9. In case two or more bidders qualify and quote same lowest rates then on the spot
revise option will be given to get to L-I. :

0.Purchase Committee reserves the right to split the order to more than one firm to
get the supplies in time & also reserves the right to cancel the tender without
showing any cause :

].In case of failure to supply within stipulated time the hire services will be made at

risk and cost of the firm.
District कि. Officer,
Hansi.

<!-- page 4 -->

#४४६)९७१६- 3
OFFICE OF DISTRICT AYURVEDIC OFFICER /NODAL OFFICER,
HANSI
TECHNICAL BID Form for purchase of T Shirt/Tentage
Tender ID - “DAO/Hansi/!YD/2026/02”
Cost of Tender Form (Rs. 000/-) Non- Name of Bank....---+++08er0007*
refundable
D.D.
6... ००००००० ००० Dated.......-2+-+2%
Due date for Tender 7 5.06.2026 up to 5:00 PM
3 Opening date and time of tend Technical bid on 6.06.2026 (2:00 Noon
ae ) Financial Bid on 6.06.2026 (0i:00
[o.oo
4 Name of the Agency / Firm / Proprietary
concernregistered & address
5 Telephone number of Authorized Person
with E-mail
any
Details of Earnest Money
a) Amount Rs. 5000.00
ian a
GST No.
(Attach Certified Copy)
Affidavit of not blacklisted by any Govt./ Semi
Govt./ Deptt. of the State & not connected to
any blacklisted firms (Duly attested by Notary
Public).
hla न

<!-- page 5 -->

C—O
|
Declaration by the bidder e ee
This is to certify that I/We before
signing this tender have read and fully
under stood all the terms and conditions
contained herein and undertake myself
Jourselves to abide by them.
Enclosed ----- Page with numbers
3 with _ self-attested copies of
Si है |
contact no. al) and email address with
|| For Official Use
44 Dairy No. wi
. with dat -
6.06.2026 up to See OL mudet Receipt up to | |
Senstare Commice Members ry

<!-- page 6 -->

BP QQ >> हा ’ ©
a
A Annexure-2
/
FINANCIAL BID FoR PURCHASE OF T- SHIRTS
To
The Distt. Ayurvedic
Officer/Nodal Officer, Hansi
Respected Madam / Sir,
de We eae बम लाली bid) fOr,
Tender ID : “DAO/Hansi/IYD/2026/0” dated for
Purchase of T-Shirts for International Yoga day 2026.
2. I/We thoroughly examined and understood instructions to tenders, scope
of work, term and conditions of contract given in the tender document and
those contained appendix of Term & condition of contract and agree to
abide by them.
3. I/We hereby offer to provide T Shirts for YD 2026 at the following rates. |
/ We understand that | /We are not entitled to claim any enhancement of
rates on any account during the tenure of the contract.
Supply of T -Shirts round neck with Logo for International 200
Yoga Day 2026
2 upply of T -Shirts with collar and Logo for International
024 Day 2026 -
Add: Statutory Obligations if any (Please Specify Each on the basis of groups)
makina | |
Signature of Authorized
Person Name &
Designation :
Name of Firm/Company/Agency :Contact Details :

<!-- page 7 -->

FINAN Annexure-3
CIAL BID FoR
Hi
To ring OF TENTAGE AND OTHER ITEMS
The Distt :
Officer/N sh
Icer, Hansi
Respected Madam / Si
m
we ee
Tender ID : « नि नितिन लिन नितिन .submitted the bid for
Tentage and “MAO/Hansi/IYD/2026/0" ७०१९१ .....................०«««»«>+_>« गि' नह रण
4. I/We thorow hy {tems for International Yoga day 2026.
and conditions of examined and understood instructions to tenders, scope of work, term
Term & conditi contract given in the tender document and those contained appendix of
5. I/We hereby of of contract and agree to abide by them.
understand af 00 to provide Tentage Items for IYD 2026 at the following rates. |/We
duri at | /We are not entitled to claim any enhancement of rates on any account
luring the tenure of the contract.
[ Sr.No. ] [Quantity
7 Supply of Tentage Items for International Yoga Day 2026
Stage 0 x 6ft
Stage 30 x20 with carpet
2 ‘arpet 5X30 for 000 person on dt 9.6.2025 and 2000 person on dt
2.6.2025
[Mattress (Gadda) 2 inch with white cover approximate 75 pe ee
|
|... |
|! | |]
ee Dunlop Chairs with cover |
a a
Sound system with Podium Mike ,Cordless Mike, Collar Mike,
IMixer and battery back up on dt 9.6.2026 and 2.6.2025 without
battery backup
i |
enset Silent with diesel rsd
ILED & 8x20 with video coverage Ea
Signature of Authorized Person
Name & Designation :
Name of Firm/Company/Agency :Contact Details :

<!-- page 8 -->

.।ह तन 000--«--न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍न्‍ननननन-"
7 @
TERMS. CONDITIONS AND GENERAL INSTRUCTIONS TO THE TENDERER
(Tender ID. “"DAO/Hansi/IYD/2026/03 ”)
Psiaontahiahe paral read carefully all the terms and conditions of the tender
ssion will be taken as consent to abide

i. The tender is “Two Bid’ document. The technical bid should contain all the

relevant information anddesired enclosures in the prescribed format along

with Earnest Money Deposit (EMD). The financial bid should contain only Price

bid document. In case, any bidder encloses the financial bid within technical

bid, the same shall be rejected summarily.

2. The tender form and other terms and conditions may be collected from the
Office of District Ayurvedic Officer/Nodal Officer Hansi by hand/ by Email. The
bid must accompany with the earnest money deposit fee of Rs. 5000/- (Five
thousand ) in the form of demand draft of any scheduled bank drawnin favour
of District Ayurvedic Officer/Nodal Officer Hansi at payable at Hansi-

3. The Tenders should be type written or handwritten but there should not be any
overwriting or cutting.Correction, if any, shall be made by neatly crossing out,
initialing, dating and rewriting. The name and signature of bidder’s authorized
person should appear on each page of the application. All pages of the tender
document shall be numbered and submitted as a package along with
forwarding letter on Firm’s letter head.

4. The Contracts concluded as a result of this Tender Inquiry shall be governed by
the ‘Terms & Conditions’ and other relevant instructions as contained in this
Tender Document.

5. The prices/rates quoted should be indicated in words as well as in figures. In
case of any discrepancy, lower amount/rates shall be considered as valid.

6. Bidders are requested to quote their prices on a firm & fixed basis
for the entire period of the Contract. Bids of the firms received with prices
quoted on variable basis shall be rejected without assigning any reasons and
no communication in this regard shall be entertained.

7. Quotations qualified by such vague and indefinite expressions such as “subject
to prior confirmation”, “subject to immediate acceptance” etc. will be treated
as vague offers and rejected accordingly. Any conditional tender shall be
rejected summarily.

8. Bidders are requested to enclose a copy of their valid certificate of PAN No.,
TAN No, Sale Tax/GST No. & Affidavit of not blacklisted by any Govt./ Semi
Govt./ Deptt. of the State & not connected to any blacklisted firms (Duly |
attested by Notary Public) till date or any other document as requested by the
Office with their tender.

9. Tenders received without EMD amount by way of demand draft in favor of

<!-- page 9 -->

(9)
District Ayurvedic Officer/Nodal Officer Hansi will not be considered at all and
sha Il be summarily rejected,

a cea Deposit: The EMD submitted by unsuccessful gees
conclusion of the का oe i
successful bidders ae i with successful bidder. The a submitte: :

है @ returned to them after conclusion of the contrac

4 nae bidder according to conditions stipulated in the bid aie

Y note that if the date of tender opening given in this Tender

Document is declared to be a gazette holiday, the tender shall be opened on

the next working day at the same timing. In such an event the closing hours for

receipt of tenders in the Office of District Ayurvedic Officer/Nodal Officer

Hansi will stand automatically extended up to 2.00 A.M. of the next working
day in the Government offices,

42. Late/delayed tenders received in the Office of District Ayurvedic Officer, Hisar
due to any reasonwhatsoever will not be accepted under any circumstances.

3. At any time prior to date of submission of tender, Tender Inviting Authority
may, for any reason, or decision, modify the terms & conditions of the tender
document by a corrigendum displayed at the Office of District Ayurvedic
Officer/Nodal Officer Hansi In order to provide reasonable time to take the
amendment into account in preparing their bid, Tender Inviting Authority may
or may not, at his discretion, extend the date and time for submission of
tenders.

4. Tendering firms are at liberty to be present or authorize a representative to be
Present at the opening of the tender at the time and date as specified in the
Schedule. The name and address of the representative authorized to attend
the opening of the tender on behalf of a tendering firm should be indicated in
the tender. The representative so deputed should also bring with him a letter
of authority from the firm for having been authorized to be present at
the time ofopening of tender. Only one representative per firm shall be
permitted to attend the opening of the tender. The name and address of
permanent representative of the firm, if any, should also be indicated in the
tender.

The bidders having experience in similar field may be given preference.

45. DOCUMENTS COMPRISING THE BID:

The bids prepared by the bidder shall comprise of
(J) The Technical Bid and
(2) Financial Bid:

G)TECHNICAL BID: - To qualify in the Technical bid the firm should have the

minimum eligibility Criteria as under and the firm in this regard must submit the

documents in support of their eligibilitycriteria and the Tender is liable to be
rejected if the following documents are not received therewith:

(a) Duly filled format of Technical Bid as per Annexure “2”.

(b) The Technical bid should be accompanied by Demand Draft/ Bank

<!-- page 10 -->

Guarantee of Rs. 50
00/-(refundable) for EMD/bid security.
7 Attested copy of Name of th
& addr @ Agency / Firm / Proprietary concern registered
ess along withregistration no. (if any)

(१9) Attested Copy of PAN Card

(०) Attest

a ed copy of GST No. as applicable
idavit i

to any blow by any Govt./ Semi Govt./ Dept. of the State & not connected
rms (Duly attested by Notary Public) till date.

(g) The fee for tender docum t

hi ents will be Rs. ,000/- (Rupees One Thousand Only).
is A
fee shall be Paid in the form of Demand Draft issued by a
national
ationalized/scheduled bank, drawn in favor of “District Ayurvedic Officer,
Hisar”. This fee is non-refundable. The tender fee draft should be enclosed in
Separate cover superscripted “Tender fee”.
(2) FINANCIAL BID: - The financial bid shall contain:
Price Bid Form as per
(a) Annexure - 2 for T Shirts
(b) Annexure -3 for tentage Items

SEALING AND MARKING OF BIDS:

All the relevant documents, D.D. of earnest money deposit along with tender
document should beplaced in sealed envelope super scribed as Tender ID.
“DAO/HANSI/IYD/2026/0”. The biddershall seal the EMD along
with the Technical Bid and the Financial Bid in separate envelopes and keep
them in a bigger properly sealed envelope. The envelope containing the
EMD along with Technical Bid shall bear the name “TECHNICAL BID
for Tender ID. “DAO/HANSI/IYD/2026/0I” The envelope containing the
Financial Bid shall bear the name “FINANCIAL BID for Tender ID.
“DAO/HANSI/IYD/2026/0!” on the envelope for avoiding any mismatch.
The sealed envelope shall be addressed as under:
(a) Addressed at the following address:
District Ayurvedic Officer ,Hisar
The envelopes shall be super scribed as TENDER ID.

“DAO/HANSI/IYD/2026/02” and the words ‘DO NOT OPEN BEFORE’ (due

date & time).

(b) The envelopes shall indicate the name and address of the bidders to
enable the bid to bereturned unopened in case it is declared ‘late’ or
rejected. f हु धर ञ्ा दर ५

(©) Bids shall be delivered in person in the office of “District Ayurvedic
Officer,Hisar” or shall be sent by Registered/Speed Post the Purchaser
shall not be responsible if the bids are delivered elsewhere.

(a) Venue of Tender Opening: Tender will be opened in the office of “
